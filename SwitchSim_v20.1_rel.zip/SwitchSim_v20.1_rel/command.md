# SwitchSim v20.1 commands

Run commands from the directory containing `voqsim` and `tools`.

## Install

Runtime dependencies:

```powershell
python -m pip install -r requirements.txt
```

Runtime and test dependencies:

```powershell
python -m pip install -r requirements-dev.txt
```

## Native Windows PowerShell

Each example is one line and can be pasted directly.

Run one configuration without a full slot trace:

```powershell
Set-Location 'C:\path\to\SwitchSim_v20.1_rel'; python -m voqsim.cli 'C:\path\to\config.yaml' --output-dir 'C:\path\to\results\run_name' --no-slot-trace
```

Run all YAML and JSON configurations beneath a directory, sequentially:

```powershell
Set-Location 'C:\path\to\SwitchSim_v20.1_rel'; python -m voqsim.cli --batch-dir 'C:\path\to\configs' --output-root 'C:\path\to\results' --no-slot-trace --continue-on-error --quiet
```

Generate standard and compact scientific reports:

```powershell
Set-Location 'C:\path\to\SwitchSim_v20.1_rel'; python '.\tools\report_results.py' --sim-root '.' --output-dir 'C:\path\to\results\reports' 'C:\path\to\results'
```

Run the test suite:

```powershell
Set-Location 'C:\path\to\SwitchSim_v20.1_rel'; python -m pytest
```

## POSIX shell

Run one configuration without a full slot trace:

```bash
cd /path/to/SwitchSim_v20.1_rel && python3 -m voqsim.cli /path/to/config.yaml --output-dir /path/to/results/run_name --no-slot-trace
```

Run a configuration directory sequentially:

```bash
cd /path/to/SwitchSim_v20.1_rel && python3 -m voqsim.cli --batch-dir /path/to/configs --output-root /path/to/results --no-slot-trace --continue-on-error --quiet
```

Generate reports:

```bash
cd /path/to/SwitchSim_v20.1_rel && python3 tools/report_results.py --sim-root . --output-dir /path/to/results/reports /path/to/results
```

Run the test suite:

```bash
cd /path/to/SwitchSim_v20.1_rel && python3 -m pytest
```

## Simulator CLI flags

Syntax: `python -m voqsim.cli [CONFIG] [OPTIONS]`

| Argument or flag | Description |
| --- | --- |
| `CONFIG` | YAML or JSON simulator configuration. Required for single-run and migration modes; omit in batch, metadata-listing, or version mode. |
| `-o DIR`, `--output-dir DIR` | Single-run destination for telemetry, summary, and static run artifacts. |
| `--batch-dir DIR` | Recursively discover and run YAML and JSON configurations in a directory. Mutually exclusive with `CONFIG`. |
| `--output-root DIR` | Required batch destination. Each configuration maps to a distinct run directory. Existing nonempty run directories are not overwritten. |
| `--continue-on-error` | Continue to later configurations after a runtime failure. Batch mode only. |
| `--quiet` | Suppress the final JSON result payload on standard output. Run artifacts are still written. |
| `--no-slot-trace` | Compute online and compact metrics without writing `telemetry.jsonl`. |
| `--queue-capacity CAPACITY` | Override the configured queue capacity before validation. `CAPACITY` must be a positive integer or the exact case-sensitive string `NoDrop`. |
| `--version` | Print the simulator checkpoint version and exit. |
| `--list-schedulers` | Print implemented scheduler, constraint-family, and algorithm metadata as JSON and exit. |
| `--list-arrivals` | Print canonical arrival-family IID/stateful metadata as JSON and exit. |
| `--migrate-config` | Migrate the positional legacy configuration instead of running it. Requires `--output-config` and is mutually exclusive with simulation and batch overrides. |
| `--output-config PATH` | YAML or JSON destination used only with `--migrate-config`. |
| `-h`, `--help` | Print CLI help and exit. |

Metadata and migration commands:

```text
python -m voqsim.cli --version
python -m voqsim.cli --list-schedulers
python -m voqsim.cli --list-arrivals
python -m voqsim.cli old.yaml --migrate-config --output-config schema4.yaml
```

## Result reporter flags

Syntax: `python tools/report_results.py [OPTIONS] RESULTS_DIR`

The reporter recursively discovers completed runs and writes
`standard_metrics.csv` and `scientific_metrics.jsonl`.

| Argument or flag | Description |
| --- | --- |
| `RESULTS_DIR` | Simulation result tree to report. |
| `--output-dir DIR` | Report destination. Default: `RESULTS_DIR/reports`. |
| `--sim-root DIR` | SwitchSim v20.1 source directory containing `voqsim`. Default: the current directory. |
| `--cutoffs K0,K1,...` | Nonempty comma-separated nonnegative backlog thresholds. Default: `0,1,2,4,8,12,16,32,64`. These thresholds evaluate exact compact statistics; they do not truncate, bin, or remove observations. |
| `--stationary-interpretation` | Explicitly request stationary identities. Disabled by default because a finite trajectory does not establish stationarity. |
| `-h`, `--help` | Print reporter help and exit. |

