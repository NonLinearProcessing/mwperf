from __future__ import annotations

from dataclasses import dataclass, field
from numbers import Integral
from typing import Any, Iterable, Iterator, Mapping, Sequence

from .errors import ValidationError
from .queues import QueueCatalog, normalize_queue_id
from .types import FlowId, JSONValue, PortId, QueueId, VOQKey
from .utils import canonicalize_voq_key, normalize_for_json



def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": coerced, "minimum": 0})
    return coerced



def _normalize_metadata(value: Mapping[str, Any] | None) -> dict[str, JSONValue]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValidationError(
            "metadata must be a mapping",
            context={"value_type": type(value).__name__},
        )

    normalized: dict[str, JSONValue] = {}
    for raw_key, raw_value in value.items():
        if not isinstance(raw_key, str):
            raise ValidationError(
                "metadata keys must be strings",
                context={"key": raw_key, "key_type": type(raw_key).__name__},
            )
        normalized[raw_key] = normalize_for_json(raw_value)
    return dict(sorted(normalized.items()))



def _canonicalize_live_edges(
    live_edges: Iterable[Sequence[Any]],
    *,
    name: str = "live_edges",
) -> tuple[VOQKey, ...]:
    normalized: list[VOQKey] = []
    seen: dict[VOQKey, int] = {}
    for index, raw_edge in enumerate(live_edges):
        edge = canonicalize_voq_key(raw_edge)
        if edge in seen:
            raise ValidationError(
                f"{name} contains duplicate VOQ keys",
                context={"voq_key": edge, "first_index": seen[edge], "duplicate_index": index},
            )
        seen[edge] = index
        normalized.append(edge)
    normalized.sort()
    return tuple(normalized)


@dataclass(slots=True, frozen=True)
class FlowSpec:
    """Resolved immutable static VOQ identity descriptor.

    A ``FlowSpec`` is no longer the stochastic source definition. Instead it is
    the stable edge-to-flow-id catalog entry used by packets, telemetry, and
    later arrival-mask materialization.
    """

    flow_id: FlowId
    src_port: PortId
    dst_port: PortId
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    def __post_init__(self) -> None:
        flow_id = _validate_non_negative_int(self.flow_id, name="flow_id")
        src_port = _validate_non_negative_int(self.src_port, name="src_port")
        dst_port = _validate_non_negative_int(self.dst_port, name="dst_port")
        metadata = _normalize_metadata(self.metadata)

        object.__setattr__(self, "flow_id", flow_id)
        object.__setattr__(self, "src_port", src_port)
        object.__setattr__(self, "dst_port", dst_port)
        object.__setattr__(self, "metadata", metadata)

    @property
    def voq_key(self) -> VOQKey:
        """Return the unique VOQ this static catalog entry identifies."""

        return (self.src_port, self.dst_port)

    def to_dict(self) -> dict[str, JSONValue]:
        """Return a stable serialization-ready mapping."""

        return {
            "flow_id": self.flow_id,
            "src_port": self.src_port,
            "dst_port": self.dst_port,
            "metadata": normalize_for_json(self.metadata),
        }



def flow_spec_to_dict(flow_spec: FlowSpec | Mapping[str, Any]) -> dict[str, JSONValue]:
    """Return ``flow_spec`` as a stable serialization-ready mapping."""

    if isinstance(flow_spec, FlowSpec):
        return flow_spec.to_dict()
    if isinstance(flow_spec, Mapping):
        normalized = normalize_for_json(flow_spec)
        if not isinstance(normalized, dict):  # pragma: no cover - defensive only
            raise TypeError("normalize_for_json unexpectedly returned a non-dict for mapping input")
        return normalized
    raise ValidationError(
        "flow_spec must be a FlowSpec or mapping instance",
        context={"value_type": type(flow_spec).__name__},
    )



def flow_specs_to_list(flow_specs: Iterable[FlowSpec]) -> list[dict[str, JSONValue]]:
    """Serialize a static flow catalog into a stable list ordered by ``flow_id`` then VOQ."""

    normalized: list[FlowSpec] = []
    for index, flow_spec in enumerate(flow_specs):
        if not isinstance(flow_spec, FlowSpec):
            raise ValidationError(
                "flow_specs must contain FlowSpec instances",
                context={"index": index, "value_type": type(flow_spec).__name__},
            )
        normalized.append(flow_spec)
    normalized.sort(key=lambda spec: (spec.flow_id, spec.src_port, spec.dst_port))
    return [spec.to_dict() for spec in normalized]


@dataclass(slots=True, frozen=True)
class FlowPlan:
    """Immutable ordered collection of static edge-to-flow-id catalog entries.

    ``FlowPlan`` is a static support artifact derived from the compiled live edge
    set ``E+``. It provides deterministic synthetic ``flow_id`` values and stable
    lookup methods for runtime packet materialization and telemetry.
    """

    flows: tuple[FlowSpec, ...] = ()
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    _flow_id_to_flow: dict[int, FlowSpec] = field(init=False, repr=False)
    _voq_to_flow: dict[VOQKey, FlowSpec] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        flows = tuple(self.flows)
        metadata = _normalize_metadata(self.metadata)

        seen_flow_ids: dict[int, int] = {}
        seen_voqs: dict[VOQKey, int] = {}
        flow_id_to_flow: dict[int, FlowSpec] = {}
        voq_to_flow: dict[VOQKey, FlowSpec] = {}
        for index, flow in enumerate(flows):
            if not isinstance(flow, FlowSpec):
                raise ValidationError(
                    "FlowPlan entries must be FlowSpec instances",
                    context={"index": index, "value_type": type(flow).__name__},
                )
            if flow.flow_id in seen_flow_ids:
                raise ValidationError(
                    "FlowPlan contains duplicate flow_id values",
                    context={
                        "flow_id": flow.flow_id,
                        "first_index": seen_flow_ids[flow.flow_id],
                        "duplicate_index": index,
                    },
                )
            seen_flow_ids[flow.flow_id] = index
            if flow.voq_key in seen_voqs:
                raise ValidationError(
                    "FlowPlan contains duplicate VOQ assignments",
                    context={
                        "voq_key": flow.voq_key,
                        "first_index": seen_voqs[flow.voq_key],
                        "duplicate_index": index,
                    },
                )
            seen_voqs[flow.voq_key] = index
            flow_id_to_flow[flow.flow_id] = flow
            voq_to_flow[flow.voq_key] = flow

        object.__setattr__(self, "flows", flows)
        object.__setattr__(self, "metadata", metadata)
        object.__setattr__(self, "_flow_id_to_flow", flow_id_to_flow)
        object.__setattr__(self, "_voq_to_flow", voq_to_flow)

    def __iter__(self) -> Iterator[FlowSpec]:
        return iter(self.flows)

    def __len__(self) -> int:
        return len(self.flows)

    @property
    def size(self) -> int:
        return len(self.flows)

    @property
    def is_empty(self) -> bool:
        return len(self.flows) == 0

    @property
    def voq_keys(self) -> tuple[VOQKey, ...]:
        """Return catalog VOQ keys in plan order."""

        return tuple(flow.voq_key for flow in self.flows)

    @property
    def flow_ids(self) -> tuple[int, ...]:
        """Return catalog identifiers in plan order."""

        return tuple(flow.flow_id for flow in self.flows)

    def contains_voq(self, edge: Sequence[Any]) -> bool:
        try:
            canonical = canonicalize_voq_key(edge)
        except ValidationError:
            return False
        return canonical in self._voq_to_flow

    def contains_flow_id(self, flow_id: Any) -> bool:
        try:
            canonical = _validate_non_negative_int(flow_id, name="flow_id")
        except ValidationError:
            return False
        return canonical in self._flow_id_to_flow

    def flow_for_edge(self, edge: Sequence[Any], *, name: str = "edge") -> FlowSpec:
        canonical = canonicalize_voq_key(edge)
        try:
            return self._voq_to_flow[canonical]
        except KeyError as exc:
            raise ValidationError(
                f"{name} is not present in the FlowPlan",
                context={"voq_key": canonical},
            ) from exc

    def flow_id_for_edge(self, edge: Sequence[Any], *, name: str = "edge") -> int:
        return self.flow_for_edge(edge, name=name).flow_id

    def flow_for_id(self, flow_id: Any, *, name: str = "flow_id") -> FlowSpec:
        canonical = _validate_non_negative_int(flow_id, name=name)
        try:
            return self._flow_id_to_flow[canonical]
        except KeyError as exc:
            raise ValidationError(
                f"{name} is not present in the FlowPlan",
                context={"flow_id": canonical},
            ) from exc

    def edge_for_flow_id(self, flow_id: Any, *, name: str = "flow_id") -> VOQKey:
        return self.flow_for_id(flow_id, name=name).voq_key

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "size": self.size,
            "flows": [flow.to_dict() for flow in self.flows],
            "metadata": normalize_for_json(self.metadata),
        }

    @classmethod
    def from_live_edges(
        cls,
        live_edges: Iterable[Sequence[Any]],
        *,
        metadata: Mapping[str, Any] | None = None,
    ) -> "FlowPlan":
        return build_flow_plan_from_live_edges(live_edges, metadata=metadata)



def build_flow_plan_from_live_edges(
    live_edges: Iterable[Sequence[Any]],
    *,
    metadata: Mapping[str, Any] | None = None,
) -> FlowPlan:
    """Build a deterministic synthetic ``flow_id`` catalog from the static live set ``E+``.

    The input order does not matter. Live edges are canonicalized into stable
    row-major order, then assigned ``flow_id`` values starting at zero.
    """

    canonical_edges = _canonicalize_live_edges(live_edges)
    flows = tuple(
        FlowSpec(flow_id=index, src_port=edge[0], dst_port=edge[1])
        for index, edge in enumerate(canonical_edges)
    )
    return FlowPlan(flows=flows, metadata=_normalize_metadata(metadata))


@dataclass(slots=True, frozen=True)
class QueueFlowSpec:
    """Synthetic one-hop flow identity for one labeled queue."""

    flow_id: FlowId
    queue_id: QueueId
    legacy_voq: VOQKey | None = None
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "flow_id", _validate_non_negative_int(self.flow_id, name="flow_id"))
        object.__setattr__(self, "queue_id", normalize_queue_id(self.queue_id))
        object.__setattr__(
            self,
            "legacy_voq",
            None if self.legacy_voq is None else canonicalize_voq_key(self.legacy_voq),
        )
        object.__setattr__(self, "metadata", _normalize_metadata(self.metadata))

    def to_dict(self) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "flow_id": self.flow_id,
            "queue_id": self.queue_id,
            "metadata": normalize_for_json(self.metadata),
        }
        if self.legacy_voq is not None:
            payload["src_port"] = self.legacy_voq[0]
            payload["dst_port"] = self.legacy_voq[1]
            payload["legacy_voq"] = [self.legacy_voq[0], self.legacy_voq[1]]
        return payload


@dataclass(slots=True, frozen=True)
class QueueFlowPlan:
    """Immutable queue-ID-to-flow catalog for queue-addressed arrival laws."""

    flows: tuple[QueueFlowSpec, ...] = ()
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    _flow_id_to_flow: dict[int, QueueFlowSpec] = field(init=False, repr=False)
    _queue_to_flow: dict[QueueId, QueueFlowSpec] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        flows = tuple(self.flows)
        metadata = _normalize_metadata(self.metadata)
        by_id: dict[int, QueueFlowSpec] = {}
        by_queue: dict[QueueId, QueueFlowSpec] = {}
        for index, flow in enumerate(flows):
            if not isinstance(flow, QueueFlowSpec):
                raise ValidationError(
                    "QueueFlowPlan entries must be QueueFlowSpec instances",
                    context={"index": index, "value_type": type(flow).__name__},
                )
            if flow.flow_id in by_id:
                raise ValidationError(
                    "QueueFlowPlan contains duplicate flow_id values",
                    context={"flow_id": flow.flow_id},
                )
            if flow.queue_id in by_queue:
                raise ValidationError(
                    "QueueFlowPlan contains duplicate queue assignments",
                    context={"queue_id": flow.queue_id},
                )
            by_id[flow.flow_id] = flow
            by_queue[flow.queue_id] = flow
        object.__setattr__(self, "flows", flows)
        object.__setattr__(self, "metadata", metadata)
        object.__setattr__(self, "_flow_id_to_flow", by_id)
        object.__setattr__(self, "_queue_to_flow", by_queue)

    @property
    def size(self) -> int:
        return len(self.flows)

    @property
    def is_empty(self) -> bool:
        return not self.flows

    @property
    def flow_ids(self) -> tuple[int, ...]:
        return tuple(flow.flow_id for flow in self.flows)

    @property
    def queue_ids(self) -> tuple[QueueId, ...]:
        return tuple(flow.queue_id for flow in self.flows)

    def __iter__(self) -> Iterator[QueueFlowSpec]:
        return iter(self.flows)

    def __len__(self) -> int:
        return len(self.flows)

    def flow_for_queue(self, queue_id: Any, *, name: str = "queue_id") -> QueueFlowSpec:
        canonical = normalize_queue_id(queue_id, name=name)
        try:
            return self._queue_to_flow[canonical]
        except KeyError as exc:
            raise ValidationError(
                f"{name} is not present in the QueueFlowPlan",
                context={"queue_id": canonical},
            ) from exc

    def flow_id_for_queue(self, queue_id: Any, *, name: str = "queue_id") -> int:
        return self.flow_for_queue(queue_id, name=name).flow_id

    def flow_for_id(self, flow_id: Any, *, name: str = "flow_id") -> QueueFlowSpec:
        canonical = _validate_non_negative_int(flow_id, name=name)
        try:
            return self._flow_id_to_flow[canonical]
        except KeyError as exc:
            raise ValidationError(
                f"{name} is not present in the QueueFlowPlan",
                context={"flow_id": canonical},
            ) from exc

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "queue_space": "catalog",
            "size": self.size,
            "flows": [flow.to_dict() for flow in self.flows],
            "metadata": normalize_for_json(self.metadata),
        }


def build_flow_plan_from_live_queues(
    catalog: QueueCatalog,
    live_queue_ids: Iterable[QueueId],
    *,
    metadata: Mapping[str, Any] | None = None,
) -> QueueFlowPlan:
    """Assign compact flow IDs in queue-catalog order to the live queues."""

    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    requested = tuple(normalize_queue_id(queue_id) for queue_id in live_queue_ids)
    if len(set(requested)) != len(requested):
        raise ValidationError("live_queue_ids must be unique")
    requested_set = set(requested)
    for queue_id in requested:
        catalog.index_of(queue_id)
    ordered = tuple(queue_id for queue_id in catalog.queue_ids if queue_id in requested_set)
    flows = tuple(
        QueueFlowSpec(
            flow_id=index,
            queue_id=queue_id,
            legacy_voq=catalog.spec_for(queue_id).legacy_voq,
        )
        for index, queue_id in enumerate(ordered)
    )
    return QueueFlowPlan(flows=flows, metadata=_normalize_metadata(metadata))


__all__ = [
    "FlowSpec",
    "FlowPlan",
    "flow_spec_to_dict",
    "flow_specs_to_list",
    "build_flow_plan_from_live_edges",
    "QueueFlowSpec",
    "QueueFlowPlan",
    "build_flow_plan_from_live_queues",
]
