"""SwitchSim release identity kept free of package-import side effects."""

SIMULATOR_VERSION = "20.1.0"

__all__ = ["SIMULATOR_VERSION"]
