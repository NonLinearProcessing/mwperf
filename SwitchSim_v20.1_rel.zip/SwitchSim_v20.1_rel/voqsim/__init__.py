"""Generalized MaxWeight switch core with queue-count arrivals."""

from .batch import BatchResult, run_batch_dir
from .kernel import DEFAULT_OUTPUT_DIRNAME, ConfigSource, SimulationResult, Simulator, build_simulation
from .packet import Packet
from .queues import QueueBank, QueueCatalog, QueueSpec, ServiceDecision
from .sink import CompletionSink
from .traffic import ArrivalCountVector
from .version import SIMULATOR_VERSION

__all__ = [
    "__version__",
    "BatchResult",
    "DEFAULT_OUTPUT_DIRNAME",
    "ConfigSource",
    "SimulationResult",
    "Simulator",
    "Packet",
    "QueueSpec",
    "QueueCatalog",
    "QueueBank",
    "ServiceDecision",
    "ArrivalCountVector",
    "CompletionSink",
    "build_simulation",
    "run_batch_dir",
]

__version__ = SIMULATOR_VERSION
