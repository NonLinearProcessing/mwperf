from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from decimal import Decimal
import json
from numbers import Integral, Real
from pathlib import Path
import re
import tempfile
from typing import Any

import yaml

from .arrival_config import (
    COUNT_ARRIVAL_FAMILIES,
    parse_count_arrival_params,
)
from .errors import ConfigError
from .queues import MAX_QUEUE_LENGTH, QueueCatalog, QueueSpec, legacy_voq_queue_id
from .types import JSONValue, QueueId, QueueSnapshotMode, VOQKey
from .utils import canonical_json_dumps, normalize_for_json

CONFIG_SCHEMA_VERSION = "4.0.0"
PREVIOUS_CONFIG_SCHEMA_VERSION = "3.1.0"
SCHEMA_3_0_CONFIG_VERSION = "3.0.0"
LEGACY_CONFIG_SCHEMA_VERSION = "2.1.0"
MIGRATABLE_CONFIG_SCHEMA_VERSIONS = frozenset(
    {
        LEGACY_CONFIG_SCHEMA_VERSION,
        SCHEMA_3_0_CONFIG_VERSION,
        PREVIOUS_CONFIG_SCHEMA_VERSION,
    }
)
SUPPORTED_CONFIG_SCHEMA_VERSIONS = frozenset({CONFIG_SCHEMA_VERSION})
SUPPORTED_CONFIG_SUFFIXES = frozenset({".json", ".yaml", ".yml"})
NO_DROP_CAPACITY = "NoDrop"

_ALLOWED_TOP_LEVEL_KEYS = frozenset(
    {"schema_version", "run", "switch", "scheduler", "arrival", "telemetry", "metadata"}
)

_SUPPORTED_ALLOWED_EDGE_MODES = frozenset({"full", "explicit"})
_SUPPORTED_ALPHABET_CONSTRAINTS = frozenset({"unrestricted", "per_input_line_rate", "global_one_hot"})
_SUPPORTED_SWITCH_KINDS = frozenset({"generalized"})
_LEGACY_ARRIVAL_KEYS = frozenset({"mean_rate", "persistence", "parameterization", "init"})
_EDGE_KEY_RE = re.compile(r"^\s*[\[(]?\s*(\d+)\s*,\s*(\d+)\s*[\])]??\s*$")


class _DecimalSafeLoader(yaml.SafeLoader):
    """Safe YAML loader whose floating-point scalars become Decimal values."""


class _DecimalSafeDumper(yaml.SafeDumper):
    """Safe YAML dumper for exact schema-4 decimal number tokens."""


def _construct_yaml_decimal(loader: yaml.SafeLoader, node: yaml.Node) -> Decimal:
    token = loader.construct_scalar(node).replace("_", "")
    try:
        value = Decimal(token)
    except Exception as exc:
        raise ConfigError("YAML numeric scalar must be a finite decimal", context={"value": token}) from exc
    if not value.is_finite():
        raise ConfigError("YAML numeric scalar must be finite", context={"value": token})
    return Decimal(0) if value.is_zero() else value


def _represent_yaml_decimal(dumper: yaml.SafeDumper, value: Decimal) -> yaml.Node:
    if not value.is_finite():
        raise ConfigError("Cannot serialize a non-finite Decimal", context={"value": str(value)})
    token = format(Decimal(0) if value.is_zero() else value, "f")
    if "." in token:
        token = token.rstrip("0").rstrip(".")
    # Keep an explicit decimal point so a subsequent YAML load selects the
    # decimal constructor even when the value is mathematically integral.
    if "." not in token:
        token += ".0"
    return dumper.represent_scalar("tag:yaml.org,2002:float", token)


_DecimalSafeLoader.add_constructor("tag:yaml.org,2002:float", _construct_yaml_decimal)
_DecimalSafeLoader.add_implicit_resolver(
    "tag:yaml.org,2002:float",
    re.compile(
        r"^(?:[-+]?(?:[0-9][0-9_]*)?\.[0-9_]+(?:[eE][-+]?[0-9]+)?|"
        r"[-+]?[0-9][0-9_]*(?:[eE][-+]?[0-9]+))$"
    ),
    list("-+0123456789."),
)
_DecimalSafeDumper.add_representer(Decimal, _represent_yaml_decimal)


@dataclass(slots=True, frozen=True)
class RunConfig:
    """Run-level simulator configuration.

    Parameters
    ----------
    seed:
        Requested master seed from the user config. ``-1`` means generate a
        concrete seed at runtime and record it.
    actual_seed:
        Optional concrete master seed used for replayable resolved configs.
    """

    seed: int = -1
    slots: int = 1_000
    warmup_slots: int = 0
    termination: str = "fixed_slots"
    actual_seed: int | None = None
    output_dir: str | None = None

    def with_actual_seed(self, actual_seed: int) -> RunConfig:
        return replace(self, actual_seed=int(actual_seed))


@dataclass(slots=True, frozen=True)
class SwitchConfig:
    """Canonical queue-store configuration.

    ``legacy_crossbar`` retains the v16.8 square-VOQ fields and exposes an
    equivalent ordered :class:`~voqsim.queues.QueueCatalog`.  ``generalized``
    stores only an ordered queue catalog and a shared queue capacity.  The
    optional ``legacy_n_ports``/``legacy_voq`` metadata is a Patch-1 bridge for
    the three existing VOQ-addressed arrival families; it is not part of the
    generalized service constraint.
    """

    # The first three fields deliberately keep their v16.8 names and order so
    # direct legacy ``SwitchConfig(...)`` construction remains source-compatible.
    n_ports: int | None = None
    voq_capacity: int | None = None
    allow_self_traffic: bool = True
    kind: str = "generalized"
    queue_catalog: QueueCatalog | None = None
    queue_capacity: int | None = None
    legacy_n_ports: int | None = None

    @property
    def catalog(self) -> QueueCatalog:
        if self.queue_catalog is not None:
            return self.queue_catalog
        if self.kind == "legacy_crossbar" and self.n_ports is not None:
            return QueueCatalog.legacy_crossbar(self.n_ports)
        raise ConfigError(
            "switch configuration does not define a queue catalog",
            context={"switch_kind": self.kind},
        )

    @property
    def queues(self) -> tuple[QueueSpec, ...]:
        return self.catalog.specs

    @property
    def n_queues(self) -> int:
        return self.catalog.n_queues

    @property
    def capacity(self) -> int | None:
        return self.voq_capacity if self.kind == "legacy_crossbar" else self.queue_capacity

    @property
    def buffer_mode(self) -> str:
        """Return the scientific buffer policy represented by this config."""

        return NO_DROP_CAPACITY if self.capacity is None else "finite"

    @property
    def arrival_n_ports(self) -> int | None:
        """Return the VOQ coordinate extent available to legacy arrivals."""

        if self.kind == "legacy_crossbar":
            return self.n_ports
        return self.legacy_n_ports


@dataclass(slots=True, frozen=True)
class SchedulerConfig:
    """Scheduler selection and scheduler-specific parameters."""

    name: str = "crossbar_max_weight"
    params: dict[str, JSONValue] = field(default_factory=dict)
    # Resolved configs always carry the registry-derived service family.  The
    # default mirrors the default legacy scheduler so direct construction does
    # not create an internally inconsistent canonical object.
    service_family: str | None = "crossbar_matching"


@dataclass(slots=True, frozen=True)
class AllowedEdgesConfig:
    """Static exogenous-arrival support on the VOQ domain ``E0``."""

    mode: str = "full"
    edges: tuple[VOQKey, ...] = ()


@dataclass(slots=True, frozen=True)
class AlphabetEntryConfig:
    """One binary slot-arrival mask entry from the finite alphabet."""

    id: str | None
    edges: tuple[VOQKey, ...]
    probability: float | None = None


@dataclass(slots=True, frozen=True)
class KernelRowConfig:
    """One row entry from the finite-state arrival kernel."""

    state: str
    mask_id: str
    next_state: str
    probability: float


@dataclass(slots=True, frozen=True)
class InitialStateConfig:
    """Initial state selection for a finite-state arrival model."""

    state: str | None = None
    distribution: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True, frozen=True)
class ArrivalConfig:
    """Canonical exogenous-arrival configuration.

    The original binary VOQ laws retain their dedicated fields so schema-2.1
    migration and seeded replay remain unchanged.  Patch-2 queue-addressed
    count laws store their strict family-specific payload under ``params``.

    Queue IDs inside ``params`` are values in ordered record lists, never JSON
    mapping keys.  This preserves the distinction between integer and string
    queue identities through canonical serialization.
    """

    family: str
    allowed_edges: AllowedEdgesConfig = field(default_factory=AllowedEdgesConfig)
    alphabet_constraint: str = "unrestricted"
    alphabet: tuple[AlphabetEntryConfig, ...] = ()
    states: tuple[str, ...] = ()
    kernel: tuple[KernelRowConfig, ...] = ()
    initial: InitialStateConfig | None = None
    lambda_default: float | None = None
    lambda_overrides: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, JSONValue] = field(default_factory=dict)
    params: dict[str, JSONValue] = field(default_factory=dict)


@dataclass(slots=True, frozen=True)
class ObservationTargetConfig:
    """One exact queue-level observation target."""

    queue_id: QueueId
    gap: str


@dataclass(slots=True, frozen=True)
class ObservationConfig:
    """Compact sufficient-statistic observation configuration."""

    enabled: bool = False
    block_slots: int | None = None
    targets: tuple[ObservationTargetConfig, ...] = ()


@dataclass(slots=True, frozen=True)
class TelemetryConfig:
    """Telemetry and trace-output configuration."""

    format: str = "jsonl"
    queue_snapshot: QueueSnapshotMode = "sparse_nonzero"
    include_packet_events: bool = False
    include_scheduler_state: bool = False
    write_slot_trace: bool = False
    observation: ObservationConfig = field(default_factory=ObservationConfig)


@dataclass(slots=True, frozen=True)
class SimConfig:
    """Fully resolved simulator configuration."""

    run: RunConfig
    switch: SwitchConfig
    scheduler: SchedulerConfig
    arrival: ArrivalConfig
    telemetry: TelemetryConfig
    metadata: dict[str, JSONValue] = field(default_factory=dict)
    schema_version: str = CONFIG_SCHEMA_VERSION

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, Any]) -> "SimConfig":
        """Convenience constructor that routes through :func:`resolve_config`."""

        return resolve_config(mapping)

    def with_actual_seed(self, actual_seed: int) -> SimConfig:
        return replace(self, run=self.run.with_actual_seed(actual_seed))


def _ensure_mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ConfigError(f"{name} must be a mapping/object", context={"value_type": type(value).__name__})
    return value


def _coerce_bool(value: Any, *, name: str) -> bool:
    if not isinstance(value, bool):
        raise ConfigError(f"{name} must be a boolean", context={"value": value})
    return value


def _coerce_int(
    value: Any,
    *,
    name: str,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ConfigError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if minimum is not None and coerced < minimum:
        raise ConfigError(f"{name} must be >= {minimum}", context={"value": coerced, "minimum": minimum})
    if maximum is not None and coerced > maximum:
        raise ConfigError(f"{name} must be <= {maximum}", context={"value": coerced, "maximum": maximum})
    return coerced


def _coerce_optional_int(
    value: Any,
    *,
    name: str,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int | None:
    if value is None:
        return None
    return _coerce_int(value, name=name, minimum=minimum, maximum=maximum)


def _coerce_queue_capacity(
    value: Any,
    *,
    name: str,
    allow_nodrop_token: bool,
    allow_legacy_null: bool = False,
) -> int | None:
    """Parse the queue-buffer grammar without changing optimizer capacities.

    Canonical schema 3.1 accepts only a positive integer or the exact,
    case-sensitive token ``NoDrop``.  Schema-3.0 generalized configs used a
    null/omitted value for the same lossless behavior, so that one legacy form
    is migrated to the internal ``None`` representation.
    """

    if value is None:
        if allow_legacy_null:
            return None
        raise ConfigError(
            f"{name} must be a positive integer or {NO_DROP_CAPACITY!r}",
            context={"value": value},
        )
    if isinstance(value, str):
        if allow_nodrop_token and value == NO_DROP_CAPACITY:
            return None
        raise ConfigError(
            f"{name} must be a positive integer or the exact string {NO_DROP_CAPACITY!r}",
            context={"value": value},
        )
    return _coerce_int(value, name=name, minimum=1, maximum=MAX_QUEUE_LENGTH)


def _coerce_float(value: Any, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise ConfigError(f"{name} must be a real number", context={"value": value})
    return float(value)


def _coerce_optional_str(value: Any, *, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(f"{name} must be a string or null", context={"value": value})
    text = value.strip()
    if not text:
        raise ConfigError(f"{name} must not be empty", context={"value": value})
    if text != value:
        raise ConfigError(
            f"{name} must not contain leading or trailing whitespace",
            context={"value": value},
        )
    return value


def _normalize_token(value: Any, *, name: str) -> str:
    if not isinstance(value, str):
        raise ConfigError(f"{name} must be a string", context={"value": value})
    token = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in token:
        token = token.replace("__", "_")
    token = token.strip("_")
    if not token:
        raise ConfigError(f"{name} must not be empty", context={"value": value})
    return token


def _coerce_json_mapping(value: Any, *, name: str) -> dict[str, JSONValue]:
    mapping = _ensure_mapping(value, name=name)
    normalized: dict[str, JSONValue] = {}
    for raw_key, raw_value in mapping.items():
        if not isinstance(raw_key, str):
            raise ConfigError(
                f"{name} keys must be strings",
                context={"key": raw_key, "key_type": type(raw_key).__name__},
            )
        normalized[raw_key] = normalize_for_json(raw_value)
    return dict(sorted(normalized.items()))


def _decimal_to_runtime_number(value: Any) -> Any:
    """Convert non-arrival Decimal values to the pre-v4 runtime JSON types.

    The schema-4 loader retains decimal tokens exactly.  Arrival payloads keep
    those values all the way to their RNG boundary; scheduler implementations,
    however, still consume their established int/float parameter grammar.
    """

    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ConfigError("scheduler.params numbers must be finite", context={"value": str(value)})
        return float(value)
    if isinstance(value, Mapping):
        return {str(key): _decimal_to_runtime_number(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_decimal_to_runtime_number(item) for item in value]
    return value


def _ensure_sequence(value: Any, *, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ConfigError(f"{name} must be a sequence", context={"value_type": type(value).__name__})
    return value


def _canonicalize_edge_string(edge: VOQKey) -> str:
    return f"[{edge[0]},{edge[1]}]"


def _parse_voq_key(value: Any, *, name: str) -> VOQKey:
    sequence = _ensure_sequence(value, name=name)
    if len(sequence) != 2:
        raise ConfigError(f"{name} must contain exactly two coordinates", context={"value": list(sequence)})
    src_port = _coerce_int(sequence[0], name=f"{name}[0]", minimum=0)
    dst_port = _coerce_int(sequence[1], name=f"{name}[1]", minimum=0)
    return (src_port, dst_port)


def _parse_voq_key_text(value: Any, *, name: str) -> VOQKey:
    if not isinstance(value, str):
        raise ConfigError(f"{name} must be a string VOQ key", context={"value": value})
    match = _EDGE_KEY_RE.fullmatch(value)
    if match is None:
        raise ConfigError(
            f"{name} must use VOQ key syntax '[i,j]' or 'i,j'",
            context={"value": value},
        )
    return (int(match.group(1)), int(match.group(2)))


def _parse_edge_list(value: Any, *, name: str) -> tuple[VOQKey, ...]:
    sequence = _ensure_sequence(value, name=name)
    return tuple(_parse_voq_key(item, name=f"{name}[{index}]") for index, item in enumerate(sequence))


def _parse_queue_id(value: Any, *, name: str) -> QueueId:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ConfigError(
            f"{name} must be a non-negative integer or non-empty string",
            context={"value": value, "value_type": type(value).__name__},
        )
    if isinstance(value, int):
        if value < 0:
            raise ConfigError(f"{name} must be non-negative", context={"value": value})
        return int(value)
    text = value.strip()
    if not text:
        raise ConfigError(f"{name} must not be empty", context={"value": value})
    if text != value:
        raise ConfigError(
            f"{name} must not contain leading or trailing whitespace",
            context={"value": value},
        )
    return value


def _parse_queue_spec(value: Any, *, name: str) -> QueueSpec:
    if not isinstance(value, Mapping):
        return QueueSpec(queue_id=_parse_queue_id(value, name=name))

    aliases = {"queue_id": "id"}
    if "id" in value and "queue_id" in value:
        raise ConfigError(
            f"{name} cannot contain both 'id' and its alias 'queue_id'",
            context={"keys": ["id", "queue_id"]},
        )
    normalized = {aliases.get(key, key): item for key, item in value.items()}
    extras = sorted(set(normalized) - {"id", "legacy_voq"})
    if extras:
        raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
    if "id" not in normalized:
        raise ConfigError(f"Missing required key in {name}", context={"key": "id"})
    legacy_voq = None
    if normalized.get("legacy_voq") is not None:
        legacy_voq = _parse_voq_key(normalized["legacy_voq"], name=f"{name}.legacy_voq")
    return QueueSpec(
        queue_id=_parse_queue_id(normalized["id"], name=f"{name}.id"),
        legacy_voq=legacy_voq,
    )


def _parse_queue_catalog(value: Any) -> QueueCatalog:
    sequence = _ensure_sequence(value, name="switch.queues")
    specs = tuple(
        _parse_queue_spec(item, name=f"switch.queues[{index}]")
        for index, item in enumerate(sequence)
    )
    if not specs:
        raise ConfigError("switch.queues must not be empty")
    return QueueCatalog(specs)


def _derived_legacy_n_ports(catalog: QueueCatalog) -> int | None:
    mapped = [spec.legacy_voq for spec in catalog.specs if spec.legacy_voq is not None]
    if not mapped:
        return None
    return max(max(edge) for edge in mapped) + 1


def _normalize_queue_snapshot(value: Any) -> str:
    token = _normalize_token(value, name="telemetry.queue_snapshot")
    aliases = {"sparse_nonzero": "sparse_nonzero", "sparse_non_zero": "sparse_nonzero"}
    return aliases.get(token, token)


def _parse_run_config(raw: Mapping[str, Any]) -> RunConfig:
    allowed = {"seed", "requested_seed", "actual_seed", "slots", "warmup_slots", "termination", "output_dir"}
    extras = sorted(set(raw) - allowed)
    if extras:
        raise ConfigError("Unknown keys in run section", context={"unknown_keys": extras})

    if "seed" in raw and "requested_seed" in raw:
        raise ConfigError("run section cannot contain both 'seed' and 'requested_seed'")

    requested_seed = raw.get("requested_seed", raw.get("seed", -1))
    return RunConfig(
        seed=_coerce_int(requested_seed, name="run.seed"),
        slots=_coerce_int(raw.get("slots", 1_000), name="run.slots", minimum=1),
        warmup_slots=_coerce_int(raw.get("warmup_slots", 0), name="run.warmup_slots", minimum=0),
        termination=_normalize_token(raw.get("termination", "fixed_slots"), name="run.termination"),
        actual_seed=_coerce_optional_int(raw.get("actual_seed", None), name="run.actual_seed", minimum=0),
        output_dir=_coerce_optional_str(raw.get("output_dir", None), name="run.output_dir"),
    )


def _parse_switch_config(
    raw: Mapping[str, Any],
    *,
    source_schema_version: str,
) -> SwitchConfig:
    if "kind" not in raw:
        raise ConfigError("Missing required key in switch section", context={"key": "kind"})
    kind = _normalize_token(raw["kind"], name="switch.kind")
    if raw["kind"] != kind:
        raise ConfigError(
            "switch.kind must use canonical spelling",
            context={"value": raw["kind"], "canonical": kind},
        )
    if kind == "legacy_crossbar":
        raise ConfigError(
            "switch.kind='legacy_crossbar' is not valid in schema 4; use explicit config migration",
            context={"kind": kind, "replacement": "generalized"},
        )
    if kind not in _SUPPORTED_SWITCH_KINDS:
        raise ConfigError(
            "Unsupported switch.kind",
            context={"kind": kind, "allowed": sorted(_SUPPORTED_SWITCH_KINDS)},
        )

    extras = sorted(set(raw) - {"kind", "queues", "queue_capacity"})
    if extras:
        raise ConfigError("Unknown keys in generalized switch section", context={"unknown_keys": extras})
    if "queues" not in raw:
        raise ConfigError("Missing required key in generalized switch section", context={"key": "queues"})
    if "queue_capacity" not in raw:
        raise ConfigError(
            "Missing required key in switch section",
            context={"key": "queue_capacity"},
        )
    catalog = _parse_queue_catalog(raw["queues"])
    if any(spec.legacy_voq is not None for spec in catalog.specs):
        raise ConfigError(
            "switch.queues[].legacy_voq was removed in schema 4; crossbar topology belongs in scheduler.params.constraint",
            context={"removed_key": "legacy_voq"},
        )
    queue_capacity = _coerce_queue_capacity(
        raw["queue_capacity"],
        name="switch.queue_capacity",
        allow_nodrop_token=True,
    )
    return SwitchConfig(
        kind="generalized",
        n_ports=None,
        voq_capacity=None,
        allow_self_traffic=True,
        queue_catalog=catalog,
        queue_capacity=queue_capacity,
        legacy_n_ports=None,
    )


def _parse_scheduler_config(raw: Mapping[str, Any]) -> SchedulerConfig:
    if "name" not in raw:
        raise ConfigError("Missing required key in scheduler section", context={"key": "name"})
    extras = sorted(set(raw) - {"name", "params"})
    if extras:
        raise ConfigError("Unknown keys in scheduler section", context={"unknown_keys": extras})

    from .schedulers.registry import resolve_scheduler_name, resolve_scheduler_spec

    raw_name = _normalize_token(raw["name"], name="scheduler.name")
    if raw["name"] != raw_name:
        raise ConfigError(
            "scheduler.name must use canonical spelling",
            context={"value": raw["name"], "canonical": raw_name},
        )
    legacy_replacements = {
        "random_maximal": "crossbar_random_greedy_maximal",
        "islip_rga": "crossbar_random_grant_accept",
        "islip_canonical": "crossbar_islip",
        "canonical_islip": "crossbar_islip",
        "max_weight": "crossbar_max_weight",
        "maxweight": "crossbar_max_weight",
    }
    if raw_name in {"round_robin", "roundrobin"}:
        raise ConfigError(
            "scheduler was removed because it was a stateless slot-cyclic greedy policy, not conventional round robin",
            context={"scheduler": raw_name, "replacement": None},
        )
    if raw_name == "islip":
        raise ConfigError(
            "scheduler.name='islip' is ambiguous and cannot be migrated automatically",
            context={"scheduler": raw_name, "choose_one": ["crossbar_random_grant_accept", "crossbar_islip"]},
        )
    if raw_name in legacy_replacements:
        raise ConfigError(
            "legacy scheduler name is not valid in schema 4; use explicit config migration",
            context={"scheduler": raw_name, "replacement": legacy_replacements[raw_name]},
        )
    raw_params = _decimal_to_runtime_number(
        _coerce_json_mapping(raw.get("params", {}), name="scheduler.params")
    )
    try:
        canonical_name = resolve_scheduler_name(raw_name)
        if canonical_name != raw_name:
            raise ConfigError(
                "scheduler.name aliases are not valid in schema 4",
                context={"scheduler": raw_name, "canonical": canonical_name},
            )
        spec = resolve_scheduler_spec(raw_name, raw_params)
    except ConfigError as exc:
        raise ConfigError(
            "Invalid scheduler.name",
            context={"scheduler": raw_name, **dict(getattr(exc, "context", {}) or {})},
        ) from exc

    return SchedulerConfig(
        name=spec.name,
        params=dict(spec.params),
        service_family=spec.service_family,
    )


def _parse_allowed_edges_config(raw: Any) -> AllowedEdgesConfig:
    mapping = _ensure_mapping(raw, name="arrival.allowed_edges")
    extras = sorted(set(mapping) - {"mode", "edges"})
    if extras:
        raise ConfigError("Unknown keys in arrival.allowed_edges", context={"unknown_keys": extras})

    mode = _normalize_token(mapping.get("mode", "full"), name="arrival.allowed_edges.mode")
    if mode not in _SUPPORTED_ALLOWED_EDGE_MODES:
        raise ConfigError(
            "Unsupported arrival.allowed_edges.mode",
            context={"mode": mode, "allowed": sorted(_SUPPORTED_ALLOWED_EDGE_MODES)},
        )

    if mode == "full":
        if "edges" in mapping and _parse_edge_list(mapping.get("edges", ()), name="arrival.allowed_edges.edges"):
            raise ConfigError(
                "arrival.allowed_edges.edges must be omitted or empty when mode='full'",
                context={"mode": mode},
            )
        edges: tuple[VOQKey, ...] = ()
    else:
        edges = _parse_edge_list(mapping.get("edges", ()), name="arrival.allowed_edges.edges")

    return AllowedEdgesConfig(mode=mode, edges=edges)


def _parse_alphabet_entry(raw: Any, *, name: str, probability_required: bool) -> AlphabetEntryConfig:
    mapping = _ensure_mapping(raw, name=name)
    extras = sorted(set(mapping) - {"id", "edges", "probability"})
    if extras:
        raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
    if "edges" not in mapping:
        raise ConfigError(f"Missing required key in {name}", context={"key": "edges"})
    if probability_required and "probability" not in mapping:
        raise ConfigError(f"Missing required key in {name}", context={"key": "probability"})

    entry_id = _coerce_optional_str(mapping.get("id"), name=f"{name}.id")
    return AlphabetEntryConfig(
        id=None if entry_id is None else _normalize_token(entry_id, name=f"{name}.id"),
        edges=_parse_edge_list(mapping["edges"], name=f"{name}.edges"),
        probability=None if "probability" not in mapping else _coerce_float(mapping["probability"], name=f"{name}.probability"),
    )


def _parse_kernel_rows(raw: Any) -> tuple[KernelRowConfig, ...]:
    sequence = _ensure_sequence(raw, name="arrival.kernel")
    rows: list[KernelRowConfig] = []
    for index, item in enumerate(sequence):
        name = f"arrival.kernel[{index}]"
        mapping = _ensure_mapping(item, name=name)
        extras = sorted(set(mapping) - {"state", "mask", "mask_id", "next_state", "probability"})
        if extras:
            raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
        if "state" not in mapping:
            raise ConfigError(f"Missing required key in {name}", context={"key": "state"})
        mask_key = "mask_id" if "mask_id" in mapping else "mask"
        if mask_key not in mapping:
            raise ConfigError(f"Missing required key in {name}", context={"key": "mask_id"})
        if "next_state" not in mapping:
            raise ConfigError(f"Missing required key in {name}", context={"key": "next_state"})
        if "probability" not in mapping:
            raise ConfigError(f"Missing required key in {name}", context={"key": "probability"})

        rows.append(
            KernelRowConfig(
                state=_normalize_token(mapping["state"], name=f"{name}.state"),
                mask_id=_normalize_token(mapping[mask_key], name=f"{name}.{mask_key}"),
                next_state=_normalize_token(mapping["next_state"], name=f"{name}.next_state"),
                probability=_coerce_float(mapping["probability"], name=f"{name}.probability"),
            )
        )
    return tuple(rows)


def _parse_initial_state_config(raw: Any) -> InitialStateConfig:
    mapping = _ensure_mapping(raw, name="arrival.initial")
    extras = sorted(set(mapping) - {"state", "distribution"})
    if extras:
        raise ConfigError("Unknown keys in arrival.initial", context={"unknown_keys": extras})
    if "state" in mapping and "distribution" in mapping:
        raise ConfigError("arrival.initial must choose exactly one of 'state' or 'distribution'")
    if "state" not in mapping and "distribution" not in mapping:
        raise ConfigError("arrival.initial must contain either 'state' or 'distribution'")

    state = None
    distribution: dict[str, float] = {}
    if "state" in mapping:
        state = _normalize_token(mapping["state"], name="arrival.initial.state")
    if "distribution" in mapping:
        raw_distribution = _ensure_mapping(mapping["distribution"], name="arrival.initial.distribution")
        distribution = {}
        for raw_key, raw_value in raw_distribution.items():
            if not isinstance(raw_key, str):
                raise ConfigError(
                    "arrival.initial.distribution keys must be strings",
                    context={"key": raw_key, "key_type": type(raw_key).__name__},
                )
            distribution[_normalize_token(raw_key, name="arrival.initial.distribution key")] = _coerce_float(
                raw_value,
                name=f"arrival.initial.distribution[{raw_key!r}]",
            )
        distribution = dict(sorted(distribution.items()))

    return InitialStateConfig(state=state, distribution=distribution)


def _parse_lambda_overrides(raw: Any, *, name: str) -> dict[str, float]:
    mapping = _ensure_mapping(raw, name=name)
    overrides: dict[str, float] = {}
    for raw_key, raw_value in mapping.items():
        edge = _parse_voq_key_text(raw_key, name=f"{name} key")
        canonical_key = _canonicalize_edge_string(edge)
        if canonical_key in overrides:
            raise ConfigError("Duplicate lambda override for VOQ key", context={"voq_key": canonical_key})
        overrides[canonical_key] = _coerce_float(raw_value, name=f"{name}[{canonical_key}]")
    return dict(sorted(overrides.items(), key=lambda item: _parse_voq_key_text(item[0], name=name)))


def _parse_factorized_bernoulli_payload(raw: Mapping[str, Any]) -> tuple[float | None, dict[str, float]]:
    has_lambda_section = "lambda" in raw
    has_split_keys = "lambda_default" in raw or "lambda_overrides" in raw
    if has_lambda_section and has_split_keys:
        raise ConfigError(
            "arrival.factorized_bernoulli must use either 'lambda' or ('lambda_default', 'lambda_overrides'), not both",
        )

    if has_lambda_section:
        lambda_value = raw["lambda"]
        if isinstance(lambda_value, Mapping):
            extras = sorted(set(lambda_value) - {"default", "overrides"})
            if extras:
                raise ConfigError("Unknown keys in arrival.lambda", context={"unknown_keys": extras})
            lambda_default = None
            if "default" in lambda_value:
                lambda_default = _coerce_float(lambda_value["default"], name="arrival.lambda.default")
            lambda_overrides = _parse_lambda_overrides(lambda_value.get("overrides", {}), name="arrival.lambda.overrides")
            return (lambda_default, lambda_overrides)
        return (_coerce_float(lambda_value, name="arrival.lambda"), {})

    lambda_default = None if "lambda_default" not in raw else _coerce_float(raw["lambda_default"], name="arrival.lambda_default")
    lambda_overrides = _parse_lambda_overrides(raw.get("lambda_overrides", {}), name="arrival.lambda_overrides")
    return (lambda_default, lambda_overrides)


def _parse_arrival_config(raw: Mapping[str, Any]) -> ArrivalConfig:
    if "family" not in raw:
        raise ConfigError("Missing required key in arrival section", context={"key": "family"})
    legacy_keys = sorted(set(raw) & _LEGACY_ARRIVAL_KEYS)
    if legacy_keys:
        raise ConfigError(
            "Legacy arrival count-process keys are unsupported; use an explicit arrival.family payload",
            context={"legacy_keys": legacy_keys},
        )

    family = _normalize_token(raw["family"], name="arrival.family")
    if raw["family"] != family:
        raise ConfigError(
            "arrival.family must use canonical spelling",
            context={"value": raw["family"], "canonical": family},
        )
    legacy_replacements = {
        "bernoulli": "iid_independent_bernoulli",
        "factorized_bernoulli": "iid_independent_bernoulli",
        "iid_table": "iid_count_table",
        "markov_kernel": "markov_count_kernel",
    }
    if family in legacy_replacements:
        raise ConfigError(
            "legacy arrival family is not valid in schema 4; use explicit config migration",
            context={"family": family, "replacement": legacy_replacements[family]},
        )
    if family in {"markov_onoff", "poisson_modulated"}:
        reason = (
            "persistent Markov-modulated Poisson semantics are not supported by this revision"
            if family == "poisson_modulated"
            else "obsolete on/off count-process keys are scientifically ambiguous"
        )
        raise ConfigError(
            "legacy arrival family cannot be migrated automatically",
            context={"family": family, "reason": reason},
        )
    if family not in COUNT_ARRIVAL_FAMILIES:
        raise ConfigError(
            "Unsupported arrival.family",
            context={"family": family, "allowed": sorted(COUNT_ARRIVAL_FAMILIES)},
        )

    return ArrivalConfig(
        family=family,
        metadata=_coerce_json_mapping(raw.get("metadata", {}), name="arrival.metadata"),
        params=parse_count_arrival_params(family, raw),
    )


def _parse_telemetry_config(raw: Mapping[str, Any]) -> TelemetryConfig:
    extras = sorted(
        set(raw)
        - {
            "format",
            "queue_snapshot",
            "include_packet_events",
            "include_scheduler_state",
            "write_slot_trace",
            "observation",
        }
    )
    if extras:
        raise ConfigError("Unknown keys in telemetry section", context={"unknown_keys": extras})

    observation_raw = _ensure_mapping(raw.get("observation", {}), name="telemetry.observation")
    observation_extras = sorted(set(observation_raw) - {"enabled", "block_slots", "targets"})
    if observation_extras:
        raise ConfigError(
            "Unknown keys in telemetry.observation section",
            context={"unknown_keys": observation_extras},
        )
    target_rows = _ensure_sequence(
        observation_raw.get("targets", ()),
        name="telemetry.observation.targets",
    )
    targets: list[ObservationTargetConfig] = []
    for index, raw_target in enumerate(target_rows):
        name = f"telemetry.observation.targets[{index}]"
        target = _ensure_mapping(raw_target, name=name)
        extras = sorted(set(target) - {"queue_id", "gap"})
        missing = sorted({"queue_id", "gap"} - set(target))
        if extras:
            raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
        if missing:
            raise ConfigError(f"Missing required keys in {name}", context={"missing_keys": missing})
        gap = _normalize_token(target["gap"], name=f"{name}.gap")
        if gap not in {"none", "exact"}:
            raise ConfigError(
                f"{name}.gap must be 'none' or 'exact'",
                context={"value": gap},
            )
        targets.append(
            ObservationTargetConfig(
                queue_id=_parse_queue_id(target["queue_id"], name=f"{name}.queue_id"),
                gap=gap,
            )
        )

    block_slots = _coerce_optional_int(
        observation_raw.get("block_slots"),
        name="telemetry.observation.block_slots",
        minimum=1,
    )

    return TelemetryConfig(
        format=_normalize_token(raw.get("format", "jsonl"), name="telemetry.format"),
        queue_snapshot=_normalize_queue_snapshot(raw.get("queue_snapshot", "sparse_nonzero")),  # type: ignore[arg-type]
        include_packet_events=_coerce_bool(raw.get("include_packet_events", False), name="telemetry.include_packet_events"),
        include_scheduler_state=_coerce_bool(
            raw.get("include_scheduler_state", False),
            name="telemetry.include_scheduler_state",
        ),
        write_slot_trace=_coerce_bool(raw.get("write_slot_trace", False), name="telemetry.write_slot_trace"),
        observation=ObservationConfig(
            enabled=_coerce_bool(
                observation_raw.get("enabled", False),
                name="telemetry.observation.enabled",
            ),
            block_slots=block_slots,
            targets=tuple(targets),
        ),
    )


def _parse_schema_version(value: Any) -> str:
    if value is None:
        raise ConfigError(
            "schema_version is required; legacy inputs must use explicit config migration",
            context={"required": CONFIG_SCHEMA_VERSION},
        )
    if not isinstance(value, str):
        raise ConfigError("schema_version must be a string", context={"value": value})
    schema_version = value.strip()
    if not schema_version:
        raise ConfigError("schema_version must not be empty", context={"value": value})
    if schema_version in MIGRATABLE_CONFIG_SCHEMA_VERSIONS:
        raise ConfigError(
            "Legacy config schemas are accepted only by explicit config migration",
            context={
                "schema_version": schema_version,
                "canonical": CONFIG_SCHEMA_VERSION,
                "migration_required": True,
            },
        )
    if schema_version != CONFIG_SCHEMA_VERSION:
        raise ConfigError(
            "Unsupported config schema_version",
            context={
                "schema_version": schema_version,
                "supported": [CONFIG_SCHEMA_VERSION],
            },
        )
    return schema_version


def _serialize_switch(switch: SwitchConfig) -> dict[str, JSONValue]:
    queues: list[dict[str, JSONValue]] = []
    for spec in switch.catalog.specs:
        item: dict[str, JSONValue] = {"id": spec.queue_id}
        queues.append(item)
    payload: dict[str, JSONValue] = {
        "kind": "generalized",
        "queue_capacity": (
            NO_DROP_CAPACITY if switch.queue_capacity is None else switch.queue_capacity
        ),
        "queues": queues,
    }
    return payload


def _serialize_allowed_edges(config: AllowedEdgesConfig) -> dict[str, JSONValue]:
    payload: dict[str, JSONValue] = {"mode": config.mode}
    if config.mode == "explicit":
        payload["edges"] = [list(edge) for edge in sorted(config.edges)]
    return payload


def _alphabet_entry_sort_key(entry: AlphabetEntryConfig) -> tuple[str, str, str]:
    probability_key = "" if entry.probability is None else canonical_json_dumps(entry.probability)
    return (entry.id or "", canonical_json_dumps([list(edge) for edge in sorted(entry.edges)]), probability_key)


def _serialize_alphabet(entries: Sequence[AlphabetEntryConfig], *, include_probability: bool) -> list[dict[str, JSONValue]]:
    """Serialize alphabet entries without changing their resolved coordinate order.

    Alphabet entry order is semantically significant because it defines the mask
    indices used by iid categorical sampling and Markov kernels. The resolved
    config therefore preserves the configured/resolved entry order exactly so a
    replayed run rebuilds the same stochastic object.
    """

    payload: list[dict[str, JSONValue]] = []
    for entry in entries:
        item: dict[str, JSONValue] = {"edges": [list(edge) for edge in sorted(entry.edges)]}
        if entry.id is not None:
            item = {"id": entry.id, **item}
        if include_probability:
            item["probability"] = (
                None if entry.probability is None else float(entry.probability)
            )
        payload.append(item)
    return payload


def _serialize_initial(initial: InitialStateConfig | None) -> dict[str, JSONValue] | None:
    if initial is None:
        return None
    if initial.state is not None:
        return {"state": initial.state}
    return {
        "distribution": {
            key: float(initial.distribution[key])
            for key in sorted(initial.distribution)
        }
    }


def _sort_override_items(overrides: Mapping[str, float]) -> list[tuple[str, float]]:
    return sorted(overrides.items(), key=lambda item: _parse_voq_key_text(item[0], name="arrival.lambda_overrides"))


def _serialize_arrival(arrival: ArrivalConfig) -> dict[str, JSONValue]:
    normalized_params = normalize_for_json(arrival.params)
    if not isinstance(normalized_params, dict):  # pragma: no cover - dataclass typing is defensive only
        raise ConfigError("arrival.params must serialize as a mapping/object")
    payload: dict[str, JSONValue] = {"family": arrival.family}
    payload.update(normalized_params)
    payload["metadata"] = normalize_for_json(arrival.metadata)
    return payload


def resolved_config_to_dict(config: SimConfig, actual_seed: int | None = None) -> dict[str, JSONValue]:
    """Convert a resolved config object into a stable serialization-ready dictionary.

    When ``actual_seed`` is provided (or already stored in ``config.run.actual_seed``),
    the run section explicitly records both ``requested_seed`` and ``actual_seed``.
    Otherwise the unresolved form uses ``seed`` only.
    """

    concrete_seed = config.run.actual_seed if actual_seed is None else int(actual_seed)
    run_payload: dict[str, JSONValue] = {
        "slots": config.run.slots,
        "warmup_slots": config.run.warmup_slots,
        "termination": config.run.termination,
    }
    if config.run.output_dir is not None:
        run_payload["output_dir"] = config.run.output_dir
    if concrete_seed is None:
        run_payload["seed"] = config.run.seed
    else:
        run_payload["requested_seed"] = config.run.seed
        run_payload["actual_seed"] = concrete_seed

    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": run_payload,
        "switch": _serialize_switch(config.switch),
        "scheduler": {
            "name": config.scheduler.name,
            "params": normalize_for_json(config.scheduler.params),
        },
        "arrival": _serialize_arrival(config.arrival),
        "telemetry": {
            "format": config.telemetry.format,
            "queue_snapshot": config.telemetry.queue_snapshot,
            "include_packet_events": config.telemetry.include_packet_events,
            "include_scheduler_state": config.telemetry.include_scheduler_state,
            "write_slot_trace": config.telemetry.write_slot_trace,
            "observation": {
                "enabled": config.telemetry.observation.enabled,
                "block_slots": config.telemetry.observation.block_slots,
                "targets": [
                    {"queue_id": target.queue_id, "gap": target.gap}
                    for target in config.telemetry.observation.targets
                ],
            },
        },
        "metadata": normalize_for_json(config.metadata),
    }


def apply_queue_capacity_override(
    raw_config: Mapping[str, Any],
    capacity: int | str,
) -> dict[str, Any]:
    """Return a raw config copy with a canonical CLI capacity override.

    This operates on the raw mapping so the selected value replaces aliases
    and is present before config resolution and validation.  It changes only
    queue-buffer capacity; resource-packing optimizer capacities are untouched.
    """

    parsed = _coerce_queue_capacity(
        capacity,
        name="--queue-capacity",
        allow_nodrop_token=True,
    )
    external_value: int | str = NO_DROP_CAPACITY if parsed is None else parsed

    root = dict(_ensure_mapping(raw_config, name="config root"))
    if "switch" not in root:
        raise ConfigError("Missing required top-level config section", context={"section": "switch"})
    switch = dict(_ensure_mapping(root["switch"], name="switch"))
    if "kind" not in switch:
        raise ConfigError("Missing required key in switch section", context={"key": "kind"})
    kind = _normalize_token(switch["kind"], name="switch.kind")
    if kind != "generalized":
        raise ConfigError(
            "Unsupported switch.kind",
            context={"kind": kind, "allowed": sorted(_SUPPORTED_SWITCH_KINDS)},
        )

    switch["queue_capacity"] = external_value
    root["switch"] = switch
    return root


@dataclass(frozen=True, slots=True)
class _MigrationSwitch:
    payload: dict[str, Any]
    queue_ids: tuple[QueueId, ...]
    queue_by_edge: Mapping[VOQKey, QueueId]
    ambiguous_edges: frozenset[VOQKey]
    legacy_crossbar: bool
    n_ports: int | None
    allow_self_traffic: bool
    crossbar_constraint: dict[str, Any] | None


def _migration_decimal(value: Any, *, name: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (Decimal, Integral, Real)):
        raise ConfigError(
            f"{name} must be a numeric scalar",
            context={"value": value, "value_type": type(value).__name__},
        )
    result = value if isinstance(value, Decimal) else Decimal(str(value))
    if not result.is_finite():
        raise ConfigError(f"{name} must be finite", context={"value": str(value)})
    return Decimal(0) if result.is_zero() else result


def _migration_switch(
    raw: Mapping[str, Any],
    *,
    source_schema_version: str,
) -> _MigrationSwitch:
    raw_kind = _normalize_token(raw.get("kind", "legacy_crossbar"), name="switch.kind")
    kind = {
        "crossbar": "legacy_crossbar",
        "legacy": "legacy_crossbar",
        "legacy_crossbar": "legacy_crossbar",
        "generic": "generalized",
        "generalized": "generalized",
    }.get(raw_kind, raw_kind)
    if kind not in {"legacy_crossbar", "generalized"}:
        raise ConfigError(
            "Legacy switch kind cannot be migrated",
            context={"switch_kind": raw_kind, "source_schema_version": source_schema_version},
        )

    if kind == "legacy_crossbar":
        if "capacity" in raw and "voq_capacity" in raw:
            raise ConfigError("legacy switch defines both capacity and voq_capacity")
        allowed = {"kind", "n_ports", "capacity", "voq_capacity", "allow_self_traffic"}
        extras = sorted(set(raw) - allowed)
        if extras:
            raise ConfigError("Unknown keys in legacy switch section", context={"unknown_keys": extras})
        if "n_ports" not in raw:
            raise ConfigError("Legacy switch migration requires switch.n_ports")
        capacity_key = "voq_capacity" if "voq_capacity" in raw else "capacity"
        if capacity_key not in raw:
            raise ConfigError("Legacy switch migration requires switch.voq_capacity")
        n_ports = _coerce_int(raw["n_ports"], name="switch.n_ports", minimum=1)
        allow_self = _coerce_bool(raw.get("allow_self_traffic", True), name="switch.allow_self_traffic")
        capacity = _coerce_queue_capacity(
            raw[capacity_key],
            name=f"switch.{capacity_key}",
            allow_nodrop_token=True,
        )
        queue_ids = tuple(
            legacy_voq_queue_id(src, dst)
            for src in range(n_ports)
            for dst in range(n_ports)
        )
        queue_by_edge = {
            (src, dst): legacy_voq_queue_id(src, dst)
            for src in range(n_ports)
            for dst in range(n_ports)
        }
        constraint = {
            "inputs": list(range(n_ports)),
            "outputs": list(range(n_ports)),
            "edges": [
                {"queue_id": queue_by_edge[(src, dst)], "input": src, "output": dst}
                for src in range(n_ports)
                for dst in range(n_ports)
            ],
        }
        return _MigrationSwitch(
            payload={
                "kind": "generalized",
                "queue_capacity": NO_DROP_CAPACITY if capacity is None else capacity,
                "queues": [{"id": queue_id} for queue_id in queue_ids],
            },
            queue_ids=queue_ids,
            queue_by_edge=queue_by_edge,
            ambiguous_edges=frozenset(),
            legacy_crossbar=True,
            n_ports=n_ports,
            allow_self_traffic=allow_self,
            crossbar_constraint=constraint,
        )

    if "capacity" in raw and "queue_capacity" in raw:
        raise ConfigError("generalized switch defines both capacity and queue_capacity")
    allowed = {"kind", "queues", "capacity", "queue_capacity", "legacy_n_ports"}
    extras = sorted(set(raw) - allowed)
    if extras:
        raise ConfigError("Unknown keys in generalized switch section", context={"unknown_keys": extras})
    if "queues" not in raw:
        raise ConfigError("Legacy generalized switch migration requires switch.queues")

    raw_queues = _ensure_sequence(raw["queues"], name="switch.queues")
    queue_ids_list: list[QueueId] = []
    edge_candidates: dict[VOQKey, list[QueueId]] = {}
    for index, raw_queue in enumerate(raw_queues):
        name = f"switch.queues[{index}]"
        if isinstance(raw_queue, Mapping):
            if "id" in raw_queue and "queue_id" in raw_queue:
                raise ConfigError(f"{name} defines both id and queue_id")
            extras = sorted(set(raw_queue) - {"id", "queue_id", "legacy_voq"})
            if extras:
                raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
            id_key = "id" if "id" in raw_queue else "queue_id"
            if id_key not in raw_queue:
                raise ConfigError(f"{name} is missing id")
            queue_id = _parse_queue_id(raw_queue[id_key], name=f"{name}.{id_key}")
            if raw_queue.get("legacy_voq") is not None:
                edge = _parse_voq_key(raw_queue["legacy_voq"], name=f"{name}.legacy_voq")
                edge_candidates.setdefault(edge, []).append(queue_id)
        else:
            queue_id = _parse_queue_id(raw_queue, name=name)
        if queue_id in queue_ids_list:
            raise ConfigError("switch.queues contains duplicate queue IDs", context={"queue_id": queue_id})
        queue_ids_list.append(queue_id)
    if not queue_ids_list:
        raise ConfigError("switch.queues must not be empty")

    capacity_key = "queue_capacity" if "queue_capacity" in raw else "capacity"
    capacity_value = raw.get(capacity_key) if capacity_key in raw else None
    allow_legacy_null = source_schema_version == SCHEMA_3_0_CONFIG_VERSION
    capacity = _coerce_queue_capacity(
        capacity_value,
        name="switch.queue_capacity",
        allow_nodrop_token=True,
        allow_legacy_null=allow_legacy_null,
    )
    queue_by_edge = {
        edge: queue_ids[0]
        for edge, queue_ids in edge_candidates.items()
        if len(queue_ids) == 1
    }
    ambiguous = frozenset(edge for edge, queue_ids in edge_candidates.items() if len(queue_ids) != 1)
    return _MigrationSwitch(
        payload={
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY if capacity is None else capacity,
            "queues": [{"id": queue_id} for queue_id in queue_ids_list],
        },
        queue_ids=tuple(queue_ids_list),
        queue_by_edge=queue_by_edge,
        ambiguous_edges=ambiguous,
        legacy_crossbar=False,
        n_ports=(
            None
            if raw.get("legacy_n_ports") is None
            else _coerce_int(raw["legacy_n_ports"], name="switch.legacy_n_ports", minimum=1)
        ),
        allow_self_traffic=True,
        crossbar_constraint=None,
    )


def _migration_edge_queue_id(edge: VOQKey, switch: _MigrationSwitch, *, name: str) -> QueueId:
    if edge in switch.ambiguous_edges:
        raise ConfigError(
            "Legacy VOQ coordinate maps to multiple queues; migration cannot choose silently",
            context={"path": name, "legacy_voq": list(edge)},
        )
    try:
        return switch.queue_by_edge[edge]
    except KeyError as exc:
        raise ConfigError(
            "Legacy VOQ coordinate has no queue mapping",
            context={"path": name, "legacy_voq": list(edge)},
        ) from exc


def _migration_allowed_edges(raw: Mapping[str, Any], switch: _MigrationSwitch) -> tuple[VOQKey, ...]:
    allowed_raw = _ensure_mapping(raw.get("allowed_edges", {}), name="arrival.allowed_edges")
    extras = sorted(set(allowed_raw) - {"mode", "edges"})
    if extras:
        raise ConfigError("Unknown keys in arrival.allowed_edges", context={"unknown_keys": extras})
    mode = _normalize_token(allowed_raw.get("mode", "full"), name="arrival.allowed_edges.mode")
    if mode == "full":
        if allowed_raw.get("edges") not in (None, [], ()):
            raise ConfigError("arrival.allowed_edges.edges must be empty when mode='full'")
        if switch.legacy_crossbar:
            assert switch.n_ports is not None
            edges = tuple(iter_valid_voq_keys(switch.n_ports, switch.allow_self_traffic))
        else:
            if not switch.queue_by_edge and not switch.ambiguous_edges:
                raise ConfigError(
                    "Legacy full VOQ arrival domain has no legacy_voq mappings; migration cannot infer it"
                )
            edges = tuple(sorted(set(switch.queue_by_edge) | set(switch.ambiguous_edges)))
    elif mode == "explicit":
        edges = _parse_edge_list(allowed_raw.get("edges", ()), name="arrival.allowed_edges.edges")
    else:
        raise ConfigError(
            "Unsupported legacy arrival.allowed_edges.mode",
            context={"mode": mode, "allowed": ["explicit", "full"]},
        )

    seen: set[VOQKey] = set()
    for index, edge in enumerate(edges):
        if edge in seen:
            raise ConfigError(
                "Legacy arrival domain contains a duplicate edge",
                context={"legacy_voq": list(edge), "index": index},
            )
        seen.add(edge)
        if switch.n_ports is not None and (edge[0] >= switch.n_ports or edge[1] >= switch.n_ports):
            raise ConfigError(
                "Legacy arrival edge is outside switch dimensions",
                context={"legacy_voq": list(edge), "n_ports": switch.n_ports},
            )
        if switch.legacy_crossbar and not switch.allow_self_traffic and edge[0] == edge[1]:
            raise ConfigError(
                "Legacy arrival edge is self traffic while allow_self_traffic is false",
                context={"legacy_voq": list(edge)},
            )
        _migration_edge_queue_id(edge, switch, name=f"arrival.allowed_edges[{index}]")
    # The legacy VOQ domain canonicalized coordinates to row-major order before
    # sampling.  This order, including zero-rate Bernoulli coordinates, is a
    # trajectory-relevant part of migration.
    return tuple(sorted(edges))


def _migration_mask_counts(
    raw_edges: Any,
    *,
    allowed_edges: tuple[VOQKey, ...],
    alphabet_constraint: str,
    switch: _MigrationSwitch,
    name: str,
) -> list[dict[str, Any]]:
    edges = _parse_edge_list(raw_edges, name=name)
    allowed_set = set(allowed_edges)
    if len(set(edges)) != len(edges):
        raise ConfigError(f"{name} contains duplicate edges")
    for edge in edges:
        if edge not in allowed_set:
            raise ConfigError(f"{name} contains an edge outside arrival.allowed_edges", context={"legacy_voq": list(edge)})
    if alphabet_constraint == "global_one_hot" and len(edges) > 1:
        raise ConfigError(f"{name} violates global_one_hot")
    if alphabet_constraint == "per_input_line_rate":
        inputs = [edge[0] for edge in edges]
        if len(inputs) != len(set(inputs)):
            raise ConfigError(f"{name} violates per_input_line_rate")
    return [
        {
            "queue_id": _migration_edge_queue_id(edge, switch, name=name),
            "count": 1,
        }
        for edge in sorted(edges)
    ]


def _migration_arrival(raw: Mapping[str, Any], switch: _MigrationSwitch) -> dict[str, Any]:
    if "family" not in raw:
        raise ConfigError("Legacy arrival migration requires arrival.family")
    family = _normalize_token(raw["family"], name="arrival.family")
    if family in {"markov_onoff", "poisson_modulated"} or set(raw) & _LEGACY_ARRIVAL_KEYS:
        raise ConfigError(
            "Legacy arrival semantics are ambiguous and cannot be migrated",
            context={
                "family": family,
                "obsolete_keys": sorted(set(raw) & _LEGACY_ARRIVAL_KEYS),
                "reason": "persistent/obsolete count-process semantics are outside schema 4",
            },
        )

    metadata = raw.get("metadata", {})
    if family in COUNT_ARRIVAL_FAMILIES:
        payload = dict(raw)
        payload["family"] = family
        return payload

    replacements = {
        "bernoulli": "iid_independent_bernoulli",
        "factorized_bernoulli": "iid_independent_bernoulli",
        "iid_table": "iid_count_table",
        "markov_kernel": "markov_count_kernel",
    }
    if family not in replacements:
        raise ConfigError(
            "Unsupported legacy arrival family",
            context={"family": family, "known_legacy_families": sorted(replacements)},
        )
    common_keys = {"family", "allowed_edges", "alphabet_constraint", "metadata"}
    family_keys = {
        "bernoulli": {"lambda", "lambda_default", "lambda_overrides"},
        "factorized_bernoulli": {"lambda", "lambda_default", "lambda_overrides"},
        "iid_table": {"alphabet"},
        "markov_kernel": {"alphabet", "states", "kernel", "initial"},
    }
    extras = sorted(set(raw) - common_keys - family_keys[family])
    if extras:
        raise ConfigError(
            "Unknown or family-inapplicable keys in legacy arrival section",
            context={"family": family, "unknown_keys": extras},
        )
    allowed_edges = _migration_allowed_edges(raw, switch)
    constraint = _normalize_token(raw.get("alphabet_constraint", "unrestricted"), name="arrival.alphabet_constraint")
    if constraint not in _SUPPORTED_ALPHABET_CONSTRAINTS:
        raise ConfigError("Unsupported legacy alphabet constraint", context={"value": constraint})

    if family in {"bernoulli", "factorized_bernoulli"}:
        if constraint != "unrestricted":
            raise ConfigError(
                "factorized Bernoulli migration requires alphabet_constraint='unrestricted'",
                context={"alphabet_constraint": constraint},
            )
        has_lambda = "lambda" in raw
        has_split = "lambda_default" in raw or "lambda_overrides" in raw
        if has_lambda and has_split:
            raise ConfigError("Legacy Bernoulli config mixes lambda parameterizations")
        if has_lambda and isinstance(raw["lambda"], Mapping):
            lambda_section = _ensure_mapping(raw["lambda"], name="arrival.lambda")
            extras = sorted(set(lambda_section) - {"default", "overrides"})
            if extras:
                raise ConfigError("Unknown keys in arrival.lambda", context={"unknown_keys": extras})
            if "default" not in lambda_section:
                raise ConfigError("Legacy Bernoulli migration requires a default rate")
            default_rate = _migration_decimal(lambda_section["default"], name="arrival.lambda.default")
            override_raw = _ensure_mapping(lambda_section.get("overrides", {}), name="arrival.lambda.overrides")
        elif has_lambda:
            default_rate = _migration_decimal(raw["lambda"], name="arrival.lambda")
            override_raw = {}
        else:
            if "lambda_default" not in raw:
                raise ConfigError("Legacy Bernoulli migration requires a default rate")
            default_rate = _migration_decimal(raw["lambda_default"], name="arrival.lambda_default")
            override_raw = _ensure_mapping(raw.get("lambda_overrides", {}), name="arrival.lambda_overrides")
        overrides: dict[VOQKey, Decimal] = {}
        for raw_key, raw_value in override_raw.items():
            edge = _parse_voq_key_text(raw_key, name="arrival.lambda.overrides key")
            if edge in overrides:
                raise ConfigError("Duplicate legacy Bernoulli override", context={"legacy_voq": list(edge)})
            overrides[edge] = _migration_decimal(raw_value, name=f"arrival.lambda.overrides[{raw_key!r}]")
        outside = sorted(edge for edge in overrides if edge not in set(allowed_edges))
        if outside:
            raise ConfigError(
                "Legacy Bernoulli override lies outside arrival.allowed_edges",
                context={"legacy_voqs": [list(edge) for edge in outside]},
            )
        return {
            "family": "iid_independent_bernoulli",
            "rates": {
                "default": Decimal(0),
                "overrides": [
                    {
                        "queue_id": _migration_edge_queue_id(edge, switch, name="arrival.rates"),
                        "rate": overrides.get(edge, default_rate),
                    }
                    for edge in allowed_edges
                ],
            },
            "metadata": metadata,
        }

    alphabet = _ensure_sequence(raw.get("alphabet", ()), name="arrival.alphabet")
    outcomes: list[dict[str, Any]] = []
    outcome_ids: list[str] = []
    seen_counts: set[tuple[tuple[QueueId, int], ...]] = set()
    for index, raw_entry in enumerate(alphabet):
        entry_name = f"arrival.alphabet[{index}]"
        entry = _ensure_mapping(raw_entry, name=entry_name)
        allowed_entry_keys = {"id", "edges", "probability"}
        extras = sorted(set(entry) - allowed_entry_keys)
        if extras:
            raise ConfigError(f"Unknown keys in {entry_name}", context={"unknown_keys": extras})
        if "edges" not in entry:
            raise ConfigError(f"{entry_name}.edges is required")
        if family == "markov_kernel" and "id" not in entry:
            raise ConfigError(
                f"{entry_name}.id is required for markov_kernel migration",
                context={
                    "reason": "kernel mask references require explicit legacy outcome identity"
                },
            )
        raw_id = entry.get("id", f"outcome_{index:06d}")
        outcome_id = _normalize_token(raw_id, name=f"{entry_name}.id")
        if outcome_id in outcome_ids:
            raise ConfigError("Legacy alphabet contains duplicate outcome IDs", context={"id": outcome_id})
        outcome_ids.append(outcome_id)
        counts = _migration_mask_counts(
            entry["edges"],
            allowed_edges=allowed_edges,
            alphabet_constraint=constraint,
            switch=switch,
            name=f"{entry_name}.edges",
        )
        counts_key = tuple((row["queue_id"], row["count"]) for row in counts)
        if counts_key in seen_counts:
            raise ConfigError("Legacy alphabet contains duplicate outcomes", context={"index": index})
        seen_counts.add(counts_key)
        outcome: dict[str, Any] = {"id": outcome_id, "counts": counts}
        if family == "iid_table":
            if "probability" not in entry:
                raise ConfigError(f"{entry_name}.probability is required")
            outcome["probability"] = _migration_decimal(
                entry["probability"], name=f"{entry_name}.probability"
            )
        elif "probability" in entry:
            raise ConfigError(f"{entry_name}.probability is unused for markov_kernel")
        outcomes.append(outcome)

    if family == "iid_table":
        return {
            "family": "iid_count_table",
            "outcomes": outcomes,
            "metadata": metadata,
        }

    raw_states = _ensure_sequence(raw.get("states", ()), name="arrival.states")
    states = [_normalize_token(state, name=f"arrival.states[{index}]") for index, state in enumerate(raw_states)]
    if len(states) != len(set(states)):
        raise ConfigError("arrival.states contains duplicate canonical IDs")
    id_by_legacy_id = {outcome_id: outcome_id for outcome_id in outcome_ids}
    kernel_rows: list[dict[str, Any]] = []
    for index, raw_row in enumerate(_ensure_sequence(raw.get("kernel", ()), name="arrival.kernel")):
        row_name = f"arrival.kernel[{index}]"
        row = _ensure_mapping(raw_row, name=row_name)
        extras = sorted(set(row) - {"state", "mask", "mask_id", "next_state", "probability"})
        if extras:
            raise ConfigError(f"Unknown keys in {row_name}", context={"unknown_keys": extras})
        if "mask" in row and "mask_id" in row:
            raise ConfigError(f"{row_name} defines both mask and mask_id")
        mask_key = "mask_id" if "mask_id" in row else "mask"
        missing = [key for key in ("state", mask_key, "next_state", "probability") if key not in row]
        if missing:
            raise ConfigError(f"{row_name} is missing keys", context={"missing_keys": missing})
        legacy_outcome_id = _normalize_token(row[mask_key], name=f"{row_name}.{mask_key}")
        if legacy_outcome_id not in id_by_legacy_id:
            raise ConfigError(f"{row_name} references an unknown alphabet ID", context={"id": legacy_outcome_id})
        kernel_rows.append(
            {
                "state": _normalize_token(row["state"], name=f"{row_name}.state"),
                "outcome_id": id_by_legacy_id[legacy_outcome_id],
                "next_state": _normalize_token(row["next_state"], name=f"{row_name}.next_state"),
                "probability": _migration_decimal(row["probability"], name=f"{row_name}.probability"),
            }
        )
    if "initial" not in raw:
        raise ConfigError("Legacy markov_kernel migration requires arrival.initial")
    return {
        "family": "markov_count_kernel",
        "states": states,
        "outcomes": outcomes,
        "kernel": kernel_rows,
        "initial": raw["initial"],
        "metadata": metadata,
    }


def _migration_round_count(params: Mapping[str, Any], *, scheduler: str) -> int:
    keys = [key for key in ("k", "rounds", "num_rounds") if key in params]
    values: list[int] = []
    for key in keys:
        values.append(_coerce_int(params[key], name=f"scheduler.params.{key}", minimum=1))
    if len(set(values)) > 1:
        raise ConfigError(
            "Legacy scheduler specifies conflicting round counts",
            context={"scheduler": scheduler, **{key: params[key] for key in keys}},
        )
    return values[0] if values else 1


def _migration_scheduler(
    raw: Mapping[str, Any],
    switch: _MigrationSwitch,
    *,
    source_schema_version: str,
) -> dict[str, Any]:
    if "parameters" in raw and "params" in raw:
        raise ConfigError("Legacy scheduler defines both params and parameters")
    extras = sorted(set(raw) - {"name", "params", "parameters"})
    if extras:
        raise ConfigError("Unknown keys in legacy scheduler section", context={"unknown_keys": extras})
    name = _normalize_token(raw.get("name", "random_maximal"), name="scheduler.name")
    params = dict(_ensure_mapping(raw.get("params", raw.get("parameters", {})), name="scheduler.params"))
    if name in {"round_robin", "roundrobin"}:
        raise ConfigError(
            "round_robin cannot be migrated: it was a stateless slot-cyclic greedy policy with no canonical replacement",
            context={"scheduler": name, "replacement": None},
        )
    if name == "islip":
        raise ConfigError(
            "islip cannot be migrated because the legacy name is ambiguous",
            context={"choose_one": ["crossbar_random_grant_accept", "crossbar_islip"]},
        )
    mapped_name = {
        "random_maximal": "crossbar_random_greedy_maximal",
        "islip_rga": "crossbar_random_grant_accept",
        "islip_canonical": "crossbar_islip",
        "canonical_islip": "crossbar_islip",
        "max_weight": "crossbar_max_weight",
        "maxweight": "crossbar_max_weight",
    }.get(name, name)

    crossbar_names = {
        "crossbar_random_greedy_maximal",
        "crossbar_random_grant_accept",
        "crossbar_islip",
        "crossbar_max_weight",
    }
    if switch.legacy_crossbar:
        if mapped_name not in crossbar_names:
            raise ConfigError(
                "Legacy crossbar scheduler does not identify the crossbar constraint family",
                context={"scheduler": name},
            )
        if "constraint" in params:
            raise ConfigError("Legacy-crossbar scheduler unexpectedly contains an explicit constraint")
        assert switch.crossbar_constraint is not None
        params["constraint"] = switch.crossbar_constraint
    elif mapped_name in {
        "crossbar_random_greedy_maximal",
        "crossbar_random_grant_accept",
        "crossbar_islip",
    }:
        raise ConfigError(
            "Legacy matrix scheduler on a generalized switch cannot be migrated without a proven crossbar domain",
            context={"scheduler": name},
        )

    if mapped_name == "crossbar_random_greedy_maximal":
        non_constraint = set(params) - {"constraint"}
        if non_constraint and source_schema_version != LEGACY_CONFIG_SCHEMA_VERSION:
            raise ConfigError(
                "random_maximal legacy parameters were not behaviorally supported",
                context={"unknown_keys": sorted(non_constraint)},
            )
        params = {"constraint": params["constraint"]}
    elif mapped_name == "crossbar_random_grant_accept":
        allowed = {"k", "rounds", "num_rounds", "constraint"}
        extras = sorted(set(params) - allowed)
        if extras:
            raise ConfigError("islip_rga has unknown legacy parameters", context={"unknown_keys": extras})
        rounds = _migration_round_count(params, scheduler=name)
        params = {"constraint": params["constraint"], "rounds": rounds}
    elif mapped_name == "crossbar_islip":
        allowed = {
            "k", "rounds", "num_rounds", "constraint",
            "initial_grant_pointers", "initial_accept_pointers",
        }
        extras = sorted(set(params) - allowed)
        if extras:
            raise ConfigError("islip_canonical has unknown legacy parameters", context={"unknown_keys": extras})
        iterations = _migration_round_count(params, scheduler=name)
        migrated = {"constraint": params["constraint"], "iterations": iterations}
        for key in ("initial_grant_pointers", "initial_accept_pointers"):
            if key in params:
                migrated[key] = params[key]
        params = migrated
    return {"name": mapped_name, "params": params}


def migrate_config(raw_config: Mapping[str, Any], *, validate: bool = True) -> SimConfig:
    """Explicitly migrate one supported pre-v4 mapping into canonical schema 4.

    Normal config resolution never calls this function.  A migration either
    produces a fully validated canonical config or fails without guessing.
    """

    root = _ensure_mapping(raw_config, name="config root")
    if "schema_version" not in root:
        raise ConfigError(
            "Legacy migration requires an explicit schema_version; versionless inference is disabled"
        )
    source_version_raw = root["schema_version"]
    if not isinstance(source_version_raw, str):
        raise ConfigError("schema_version must be a string", context={"value": source_version_raw})
    source_version = source_version_raw.strip()
    if source_version == CONFIG_SCHEMA_VERSION:
        raise ConfigError(
            "Config is already schema 4 and must not be passed through legacy migration",
            context={"schema_version": source_version},
        )
    if source_version not in MIGRATABLE_CONFIG_SCHEMA_VERSIONS:
        raise ConfigError(
            "Unsupported legacy config schema_version",
            context={"schema_version": source_version, "migratable": sorted(MIGRATABLE_CONFIG_SCHEMA_VERSIONS)},
        )
    extras = sorted(set(root) - _ALLOWED_TOP_LEVEL_KEYS)
    if extras:
        raise ConfigError("Unknown keys in legacy config root", context={"unknown_keys": extras})
    if "switch" not in root or "arrival" not in root:
        missing = [key for key in ("switch", "arrival") if key not in root]
        raise ConfigError("Legacy config is missing required sections", context={"missing_sections": missing})

    migrated_switch = _migration_switch(
        _ensure_mapping(root["switch"], name="switch"),
        source_schema_version=source_version,
    )
    scheduler_raw = _ensure_mapping(root.get("scheduler", {}), name="scheduler")
    arrival_raw = _ensure_mapping(root["arrival"], name="arrival")
    telemetry_raw = dict(_ensure_mapping(root.get("telemetry", {}), name="telemetry"))
    # Preserve the old effective trace defaults explicitly; schema 4 defaults
    # are intentionally quiet.
    telemetry_raw.setdefault("include_packet_events", True)
    telemetry_raw.setdefault("write_slot_trace", True)

    canonical_raw: dict[str, Any] = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": dict(_ensure_mapping(root.get("run", {}), name="run")),
        "switch": migrated_switch.payload,
        "scheduler": _migration_scheduler(
            scheduler_raw,
            migrated_switch,
            source_schema_version=source_version,
        ),
        "arrival": _migration_arrival(arrival_raw, migrated_switch),
        "telemetry": telemetry_raw,
        "metadata": dict(_ensure_mapping(root.get("metadata", {}), name="metadata")),
    }
    return resolve_config(canonical_raw, validate=validate)


def resolve_config(raw_config: Mapping[str, Any], *, validate: bool = True) -> SimConfig:
    """Resolve a raw config mapping into the strongly typed canonical config."""

    root = _ensure_mapping(raw_config, name="config root")
    if "flows" in root:
        raise ConfigError(
            "Top-level 'flows' is unsupported; queue identities belong in switch.queues and arrivals belong under arrival",
            context={"removed_section": "flows", "schema_version": CONFIG_SCHEMA_VERSION},
        )

    extras = sorted(set(root) - _ALLOWED_TOP_LEVEL_KEYS)
    if extras:
        raise ConfigError("Unknown keys in config root", context={"unknown_keys": extras})

    source_schema_version = _parse_schema_version(root.get("schema_version"))
    run_section = _ensure_mapping(root.get("run", {}), name="run")
    switch_section = root.get("switch")
    arrival_section = root.get("arrival")
    scheduler_section = root.get("scheduler")
    telemetry_section = _ensure_mapping(root.get("telemetry", {}), name="telemetry")
    metadata_section = _ensure_mapping(root.get("metadata", {}), name="metadata")

    if switch_section is None:
        raise ConfigError("Missing required top-level config section", context={"section": "switch"})
    if arrival_section is None:
        raise ConfigError("Missing required top-level config section", context={"section": "arrival"})
    if scheduler_section is None:
        raise ConfigError("Missing required top-level config section", context={"section": "scheduler"})

    switch_config = _parse_switch_config(
        _ensure_mapping(switch_section, name="switch"),
        source_schema_version=source_schema_version,
    )
    scheduler_config = _parse_scheduler_config(
        _ensure_mapping(scheduler_section, name="scheduler")
    )

    arrival_config = _parse_arrival_config(
        _ensure_mapping(arrival_section, name="arrival")
    )

    config = SimConfig(
        schema_version=CONFIG_SCHEMA_VERSION,
        run=_parse_run_config(run_section),
        switch=switch_config,
        scheduler=scheduler_config,
        arrival=arrival_config,
        telemetry=_parse_telemetry_config(telemetry_section),
        metadata=_coerce_json_mapping(metadata_section, name="metadata"),
    )

    if validate:
        from .validation import validate_config

        validate_config(config)
    return config


def load_raw_config(path: str | Path) -> Mapping[str, Any]:
    """Load a raw YAML or JSON config file without resolving it."""

    config_path = Path(path)
    suffix = config_path.suffix.lower()
    if suffix not in SUPPORTED_CONFIG_SUFFIXES:
        raise ConfigError(
            "Unsupported config file extension",
            context={"path": str(config_path), "suffix": suffix or "<none>"},
        )

    try:
        text = config_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError("Failed to read config file", context={"path": str(config_path), "reason": str(exc)}) from exc

    try:
        if suffix == ".json":
            payload = json.loads(
                text,
                parse_float=Decimal,
                parse_constant=lambda token: (_ for _ in ()).throw(
                    ValueError(f"non-finite JSON number {token!r} is not allowed")
                ),
            )
        else:
            payload = yaml.load(text, Loader=_DecimalSafeLoader)
    except Exception as exc:  # pragma: no cover - exact parser errors vary by backend
        raise ConfigError("Failed to parse config file", context={"path": str(config_path), "reason": str(exc)}) from exc

    if payload is None:
        raise ConfigError("Config file is empty", context={"path": str(config_path)})
    return _ensure_mapping(payload, name="config root")


def load_config(path: str | Path, *, validate: bool = True) -> SimConfig:
    """Load, resolve, and optionally validate a YAML or JSON config file."""

    return resolve_config(load_raw_config(path), validate=validate)


def _render_config_mapping(payload: Mapping[str, Any], *, suffix: str) -> str:
    normalized = normalize_for_json(payload)
    if suffix == ".json":
        return canonical_json_dumps(normalized) + "\n"
    if suffix in {".yaml", ".yml"}:
        rendered = yaml.dump(
            normalized,
            Dumper=_DecimalSafeDumper,
            sort_keys=False,
            allow_unicode=True,
        )
        return rendered if rendered.endswith("\n") else rendered + "\n"
    raise ConfigError("Unsupported config file extension", context={"suffix": suffix or "<none>"})


def migrate_config_file(source_path: str | Path, out_path: str | Path) -> Path:
    """Migrate a legacy config file and atomically write canonical schema 4."""

    source = Path(source_path)
    destination = Path(out_path)
    suffix = destination.suffix.lower()
    if suffix not in SUPPORTED_CONFIG_SUFFIXES:
        raise ConfigError(
            "Unsupported migrated config extension",
            context={"path": str(destination), "suffix": suffix or "<none>"},
        )
    config = migrate_config(load_raw_config(source), validate=True)
    rendered = _render_config_mapping(resolved_config_to_dict(config), suffix=suffix)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(rendered)
            temp_name = handle.name
        Path(temp_name).replace(destination)
    except Exception:
        if temp_name is not None:
            Path(temp_name).unlink(missing_ok=True)
        raise
    return destination


def dump_resolved_config(config: SimConfig, actual_seed: int, out_path: str | Path) -> Path:
    """Write a resolved config file with the concrete ``actual_seed`` populated."""

    from .validation import validate_config, validate_seed

    concrete_seed = validate_seed(actual_seed, allow_minus_one=False, name="actual_seed")
    resolved = config.with_actual_seed(concrete_seed)
    validate_config(resolved)

    payload = resolved_config_to_dict(resolved, actual_seed=concrete_seed)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    suffix = out_path.suffix.lower()
    if suffix not in SUPPORTED_CONFIG_SUFFIXES:
        raise ConfigError(
            "Unsupported resolved config extension",
            context={"path": str(out_path), "suffix": suffix or "<none>"},
        )
    rendered = _render_config_mapping(payload, suffix=suffix)

    out_path.write_text(rendered, encoding="utf-8")
    return out_path


__all__ = [
    "CONFIG_SCHEMA_VERSION",
    "PREVIOUS_CONFIG_SCHEMA_VERSION",
    "SCHEMA_3_0_CONFIG_VERSION",
    "LEGACY_CONFIG_SCHEMA_VERSION",
    "MIGRATABLE_CONFIG_SCHEMA_VERSIONS",
    "NO_DROP_CAPACITY",
    "SUPPORTED_CONFIG_SCHEMA_VERSIONS",
    "SUPPORTED_CONFIG_SUFFIXES",
    "RunConfig",
    "SwitchConfig",
    "SchedulerConfig",
    "AllowedEdgesConfig",
    "AlphabetEntryConfig",
    "KernelRowConfig",
    "InitialStateConfig",
    "ArrivalConfig",
    "ObservationTargetConfig",
    "ObservationConfig",
    "TelemetryConfig",
    "SimConfig",
    "load_raw_config",
    "load_config",
    "apply_queue_capacity_override",
    "resolve_config",
    "migrate_config",
    "migrate_config_file",
    "resolved_config_to_dict",
    "dump_resolved_config",
]
