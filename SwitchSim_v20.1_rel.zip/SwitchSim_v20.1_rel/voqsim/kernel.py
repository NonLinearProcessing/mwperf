from __future__ import annotations

from collections.abc import Callable, Iterable
from contextlib import nullcontext
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from .config import SimConfig, load_config, resolve_config, resolved_config_to_dict
from .errors import ScheduleError, ValidationError
from .events import CommittedSlot
from .manifest import (
    RunManifest,
    build_service_model,
    hash_flow_plan,
    hash_resolved_config,
    hash_service_model,
)
from .queues import QueueBank, QueueCatalog, ServiceDecision
from .rng import (
    ARRIVAL_CATEGORICAL_SAMPLER,
    RNG_ENGINE_NAME,
    SEED_SCHEME_VERSION,
    RNGDomain,
    build_arrival_rng_for_slot,
    build_scheduler_rng_for_slot,
    resolve_master_seed,
)
from .schedulers.domain import QueueSchedulerDomain
from .schedulers.exact_gap import ExactGapCertificate
from .schedulers.registry import build_scheduler_for_domain
from .sink import CompletionSink
from .stats import GenericRunStats, RunSummary
from .telemetry import (
    DEFAULT_RUN_SUMMARY_FILENAME,
    DEFAULT_SLOT_TRACE_FILENAME,
    OBSERVATION_FORMAT_VERSION,
    CompactObservationRecorder,
    GenericSlotTraceBuilder,
    JsonlWriter,
    ObservationTarget,
    SummaryWriter,
    write_static_run_artifacts,
)
from .traffic.compiler import CompiledArrivalSpec, compile_arrival_spec
from .traffic.materializer import ArrivalMaterializer, MaterializedArrival, build_arrival_materializer
from .types import QueueId
from .utils import normalize_for_json
from .validation import validate_actual_seed, validate_config
from .version import SIMULATOR_VERSION

DEFAULT_OUTPUT_DIRNAME = "switchsim_run"
DEFAULT_OBSERVATION_FILENAME = "observations.sqlite3"


ConfigSource = SimConfig | Mapping[str, Any] | str | Path
CommittedSlotObserver = Callable[[CommittedSlot], None]


def _collect_exact_gap_certificates(
    *,
    scheduler: Any,
    catalog: QueueCatalog,
    q_before: np.ndarray,
    decision: ServiceDecision,
    target_queue_ids: tuple[QueueId, ...],
    slot: int,
) -> tuple[ExactGapCertificate, ...]:
    """Collect and independently validate all requested pending certificates.

    This function is called only after the production decision has passed its
    ordinary validation and before service or arrivals can mutate the system.
    It validates the complete returned batch before handing any certificate to
    the pending slot, which gives multi-target collection all-or-nothing
    semantics.
    """

    if not target_queue_ids:
        return ()
    certificate_method = getattr(scheduler, "exact_class_certificates", None)
    if not callable(certificate_method):
        raise ValidationError(
            "exact-gap observations require scheduler class-certificate support",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        )

    vector = np.asarray(q_before)
    if vector.ndim != 1 or vector.shape != (catalog.n_queues,):
        raise ValidationError(
            "exact-gap queue state must align with the queue catalog",
            context={"shape": tuple(vector.shape), "n_queues": catalog.n_queues},
        )
    snapshot = vector.view()
    snapshot.flags.writeable = False
    raw_certificates = certificate_method(
        snapshot,
        decision,
        target_queue_ids,
        slot=slot,
    )
    try:
        certificates = tuple(raw_certificates)
    except TypeError as exc:
        raise ValidationError(
            "scheduler exact_class_certificates must return an iterable",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        ) from exc
    if len(certificates) != len(target_queue_ids):
        raise ScheduleError(
            "scheduler returned an incomplete exact-gap certificate batch",
            context={
                "slot": slot,
                "expected_count": len(target_queue_ids),
                "actual_count": len(certificates),
            },
        )

    selected = frozenset(decision.selected_queue_ids)
    production_value = sum(int(vector[catalog.index_of(queue_id)]) for queue_id in selected)
    seen: set[QueueId] = set()
    validated: list[ExactGapCertificate] = []
    for position, (expected_queue_id, certificate) in enumerate(
        zip(target_queue_ids, certificates, strict=True)
    ):
        if not isinstance(certificate, ExactGapCertificate):
            raise ValidationError(
                "scheduler returned an invalid exact-gap certificate",
                context={"slot": slot, "position": position, "value_type": type(certificate).__name__},
            )
        if certificate.queue_id != expected_queue_id:
            raise ScheduleError(
                "scheduler exact-gap certificate order or identity is invalid",
                context={
                    "slot": slot,
                    "position": position,
                    "expected_queue_id": expected_queue_id,
                    "actual_queue_id": certificate.queue_id,
                },
            )
        if certificate.queue_id in seen:
            raise ScheduleError(
                "scheduler returned duplicate exact-gap certificates",
                context={"slot": slot, "queue_id": certificate.queue_id},
            )
        seen.add(certificate.queue_id)
        queue_index = catalog.index_of(certificate.queue_id)
        backlog = int(vector[queue_index])
        selected_class = int(certificate.queue_id in selected)
        if certificate.backlog != backlog:
            raise ScheduleError(
                "exact-gap certificate backlog disagrees with the production state",
                context={
                    "slot": slot,
                    "queue_id": certificate.queue_id,
                    "certificate_backlog": certificate.backlog,
                    "production_backlog": backlog,
                },
            )
        if certificate.selected_class != selected_class:
            raise ScheduleError(
                "exact-gap certificate selected class disagrees with the production decision",
                context={
                    "slot": slot,
                    "queue_id": certificate.queue_id,
                    "certificate_selected_class": certificate.selected_class,
                    "production_selected_class": selected_class,
                },
            )
        if certificate.production_value != production_value:
            raise ScheduleError(
                "exact-gap certificate objective disagrees with the production decision",
                context={
                    "slot": slot,
                    "queue_id": certificate.queue_id,
                    "certificate_production_value": certificate.production_value,
                    "production_value": production_value,
                },
            )
        if certificate.theta < 0:  # defensive; ExactGapCertificate enforces this.
            raise ScheduleError(
                "exact-gap certificate violates downward closure",
                context={"slot": slot, "queue_id": certificate.queue_id, "theta": certificate.theta},
            )
        validated.append(certificate)
    return tuple(validated)



def _load_resolved_config(config: ConfigSource) -> SimConfig:
    if isinstance(config, SimConfig):
        return validate_config(config)
    if isinstance(config, Mapping):
        return resolve_config(config, validate=True)
    if isinstance(config, (str, Path)):
        return load_config(config, validate=True)
    raise ValidationError(
        "config must be a SimConfig, mapping, or filesystem path",
        context={"value_type": type(config).__name__},
    )



def _resolve_effective_actual_seed(config: SimConfig) -> int:
    requested_seed = config.run.seed
    recorded_actual_seed = config.run.actual_seed

    if recorded_actual_seed is not None:
        actual_seed = validate_actual_seed(recorded_actual_seed, name="run.actual_seed")
        if requested_seed >= 0 and actual_seed != requested_seed:
            raise ValidationError(
                "run.actual_seed must equal run.seed when a fixed non-negative seed is requested",
                context={"requested_seed": requested_seed, "actual_seed": actual_seed},
            )
        return actual_seed

    return resolve_master_seed(requested_seed)


def validate_arrival_serviceability(
    compiled_arrival: CompiledArrivalSpec,
    scheduler: Any,
) -> tuple[QueueId, ...]:
    """Reject live arrival queues that the bound scheduler can never serve.

    Every canonical scheduler exposes its singleton-feasible queues via
    ``individually_serviceable_queue_ids``. The returned tuple is in canonical
    catalog order. Keeping this validation
    independent of artifact construction also lets CLI and batch preflight run
    it before creating an output directory.
    """

    if not isinstance(compiled_arrival, CompiledArrivalSpec):
        raise ValidationError(
            "compiled_arrival must be a CompiledArrivalSpec",
            context={"value_type": type(compiled_arrival).__name__},
        )
    catalog = compiled_arrival.queue_catalog
    if not isinstance(catalog, QueueCatalog):  # pragma: no cover - compiler invariant
        raise ValidationError("compiled arrival support is missing its queue catalog")

    missing = object()
    raw_serviceable = getattr(
        scheduler,
        "individually_serviceable_queue_ids",
        missing,
    )
    if raw_serviceable is missing:
        raise ValidationError(
            "canonical scheduler must expose individually_serviceable_queue_ids",
            context={
                "scheduler": getattr(scheduler, "name", type(scheduler).__name__)
            },
        )
    if isinstance(raw_serviceable, (str, bytes, bytearray)):
        raise ValidationError(
            "scheduler individually_serviceable_queue_ids must be an iterable of queue IDs",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        )
    try:
        supplied = tuple(raw_serviceable)
    except TypeError as exc:
        raise ValidationError(
            "scheduler individually_serviceable_queue_ids must be an iterable of queue IDs",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        ) from exc

    serviceable_set: set[QueueId] = set()
    for position, queue_id in enumerate(supplied):
        try:
            catalog.index_of(queue_id)
        except ValidationError as exc:
            raise ValidationError(
                "scheduler reported an individually serviceable queue outside its domain",
                context={
                    "scheduler": getattr(scheduler, "name", type(scheduler).__name__),
                    "position": position,
                    "queue_id": queue_id,
                },
            ) from exc
        if queue_id in serviceable_set:
            raise ValidationError(
                "scheduler individually_serviceable_queue_ids contains duplicates",
                context={
                    "scheduler": getattr(scheduler, "name", type(scheduler).__name__),
                    "queue_id": queue_id,
                },
            )
        serviceable_set.add(queue_id)

    canonical_serviceable = tuple(
        queue_id for queue_id in catalog.queue_ids if queue_id in serviceable_set
    )
    unserviceable_live = tuple(
        queue_id
        for queue_id in compiled_arrival.live_queue_ids()
        if queue_id not in serviceable_set
    )
    if unserviceable_live:
        raise ValidationError(
            "arrival support contains queues that the scheduler can never serve",
            context={
                "arrival_family": compiled_arrival.family,
                "scheduler": getattr(scheduler, "name", type(scheduler).__name__),
                "service_family": getattr(
                    getattr(scheduler, "scheduler_domain", None),
                    "service_family",
                    None,
                ),
                "unserviceable_live_queue_ids": list(unserviceable_live),
            },
        )
    return canonical_serviceable



def _resolve_output_dir(config: SimConfig, output_dir: str | Path | None) -> Path:
    if output_dir is not None:
        return Path(output_dir)
    if config.run.output_dir is not None:
        return Path(config.run.output_dir)
    return Path.cwd() / DEFAULT_OUTPUT_DIRNAME



def _summary_metadata(
    simulator: "Simulator",
    *,
    measurement_start: np.ndarray,
    measurement_end: np.ndarray,
) -> dict[str, Any]:
    capacity = simulator.config.switch.capacity
    return {
        "requested_seed": simulator.requested_seed,
        "actual_seed": simulator.actual_seed,
        "simulator_version": SIMULATOR_VERSION,
        "switch_kind": simulator.config.switch.kind,
        "n_queues": simulator.config.switch.n_queues,
        "service_family": simulator.config.scheduler.service_family,
        "scheduler": simulator.scheduler.name,
        "scheduler_algorithm_id": str(simulator.scheduler.algorithm_id),
        "scheduler_optimizer_id": (
            None
            if getattr(simulator.scheduler, "optimizer_id", None) is None
            else str(simulator.scheduler.optimizer_id)
        ),
        "scheduler_params": normalize_for_json(dict(simulator.config.scheduler.params)),
        "config_metadata": normalize_for_json(simulator.config.metadata),
        "arrival_family": simulator.compiled_arrival.family,
        "termination": simulator.config.run.termination,
        "configured_slots": simulator.config.run.slots,
        "warmup_slots": simulator.config.run.warmup_slots,
        "measurement_start_slot": simulator.config.run.warmup_slots,
        "measurement_end_slot_exclusive": simulator.config.run.slots,
        "measurement_slots": simulator.config.run.slots - simulator.config.run.warmup_slots,
        "schema_version": simulator.config.schema_version,
        "telemetry_format": simulator.config.telemetry.format,
        "queue_snapshot": simulator.config.telemetry.queue_snapshot,
        "include_packet_events": simulator.config.telemetry.include_packet_events,
        "include_scheduler_state": simulator.config.telemetry.include_scheduler_state,
        "write_slot_trace": simulator.config.telemetry.write_slot_trace,
        "compact_observations_enabled": simulator.config.telemetry.observation.enabled,
        "compact_observation_format": (
            OBSERVATION_FORMAT_VERSION
            if simulator.config.telemetry.observation.enabled
            else None
        ),
        "buffer_mode": simulator.config.switch.buffer_mode,
        "buffer_capacity_packets": capacity,
        "capacity_utilization_defined": capacity is not None,
        "measurement_start_occupancy_packets": sum(
            int(value) for value in measurement_start
        ),
        "measurement_end_occupancy_packets": sum(
            int(value) for value in measurement_end
        ),
        "execution_peak_occupancy_packets": simulator.switch.peak_occupancy(),
        "post_run_final_occupancy_packets": simulator.switch.total_occupancy(),
    }


def _observation_metadata(simulator: "Simulator") -> dict[str, Any]:
    """Return only scientific conditions needed to interpret the raw masses."""

    resolved = resolved_config_to_dict(simulator.config, actual_seed=simulator.actual_seed)
    run = dict(resolved["run"])
    run.pop("output_dir", None)
    scientific_config = {
        "schema_version": resolved["schema_version"],
        "run": run,
        "switch": resolved["switch"],
        "scheduler": resolved["scheduler"],
        "arrival": resolved["arrival"],
        "metadata": resolved["metadata"],
    }
    return {
        "simulator_version": SIMULATOR_VERSION,
        "scientific_config": scientific_config,
        "slot_convention": "pre_service_N; service; arrivals; post_arrival_N_prime",
        "initial_condition": "empty_queues",
        "requested_seed": simulator.requested_seed,
        "actual_seed": simulator.actual_seed,
        "rng": {
            "engine": RNG_ENGINE_NAME,
            "seed_scheme_version": SEED_SCHEME_VERSION,
            "numpy_version": np.__version__,
            "arrival_categorical_sampler": ARRIVAL_CATEGORICAL_SAMPLER,
            "domains": {
                "scheduler": int(RNGDomain.SCHEDULER),
                "arrival_model": int(RNGDomain.ARRIVAL_MODEL),
                "arrival_initial": int(RNGDomain.ARRIVAL_INITIAL),
            },
        },
    }


@dataclass(slots=True, frozen=True)
class SimulationResult:
    """Deterministic artifact bundle produced by :meth:`Simulator.run`."""

    requested_seed: int
    actual_seed: int
    output_dir: Path
    telemetry_path: Path | None
    observation_path: Path | None
    summary_path: Path
    summary: RunSummary
    static_artifacts: Mapping[str, Path]
    slots_run: int
    measurement_queue_ids: tuple[QueueId, ...] = field(repr=False)
    measurement_start_queue_lengths: tuple[int, ...] = field(repr=False)
    measurement_end_queue_lengths: tuple[int, ...] = field(repr=False)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "requested_seed": self.requested_seed,
            "actual_seed": self.actual_seed,
            "output_dir": str(self.output_dir),
            "summary_path": str(self.summary_path),
            "slots_run": self.slots_run,
            "static_artifacts": {key: str(path) for key, path in sorted(self.static_artifacts.items())},
            "summary": self.summary.to_dict(),
            "slot_trace_written": self.telemetry_path is not None,
            "compact_observations_written": self.observation_path is not None,
        }
        if self.telemetry_path is not None:
            payload["telemetry_path"] = str(self.telemetry_path)
        if self.observation_path is not None:
            payload["observation_path"] = str(self.observation_path)
            payload["observation_format"] = OBSERVATION_FORMAT_VERSION
        return payload


@dataclass(slots=True)
class Simulator:
    """Fully wired deterministic simulator runtime.

    The simulator owns the resolved runtime objects needed for one complete run:
    the compiled arrival model, deterministic packet materializer,
    queue store, completion path, scheduler plugin, telemetry writers, and
    online run statistics. Schema 4 has one topology-neutral queue-vector path
    with the following service-before-arrival slot order:

    1. observe ``q_before``
    2. schedule using ``q_before``
    3. service the selected queues
    4. complete departures at the sink
    5. sample the queue-count arrival vector
    6. materialize offered packets
    7. enqueue or drop at finite buffers
    8. observe ``q_after``
    9. finalize telemetry and online stats
    """

    config: SimConfig
    actual_seed: int
    compiled_arrival: CompiledArrivalSpec
    materializer: ArrivalMaterializer
    switch: QueueBank
    sinks: CompletionSink
    scheduler: Any
    output_dir: Path
    static_artifacts: Mapping[str, Path] = field(default_factory=dict)

    telemetry_path: Path | None = field(init=False)
    observation_path: Path | None = field(init=False)
    summary_path: Path = field(init=False)
    _has_run: bool = field(init=False, default=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.config, SimConfig):
            raise ValidationError(
                "config must be a SimConfig",
                context={"value_type": type(self.config).__name__},
            )
        validate_config(self.config)

        actual_seed = validate_actual_seed(self.actual_seed, name="actual_seed")
        if self.config.run.actual_seed is not None and actual_seed != self.config.run.actual_seed:
            raise ValidationError(
                "actual_seed does not match config.run.actual_seed",
                context={"actual_seed": actual_seed, "config.run.actual_seed": self.config.run.actual_seed},
            )
        if self.config.run.seed >= 0 and actual_seed != self.config.run.seed:
            raise ValidationError(
                "actual_seed must equal run.seed for fixed-seed configs",
                context={"actual_seed": actual_seed, "run.seed": self.config.run.seed},
            )
        if not isinstance(self.compiled_arrival, CompiledArrivalSpec):
            raise ValidationError(
                "compiled_arrival must be a CompiledArrivalSpec",
                context={"value_type": type(self.compiled_arrival).__name__},
            )
        if not isinstance(self.materializer, ArrivalMaterializer):
            raise ValidationError(
                "materializer must be an ArrivalMaterializer",
                context={"value_type": type(self.materializer).__name__},
            )
        if self.materializer.compiled is not self.compiled_arrival:
            raise ValidationError("materializer does not own the compiled arrival bundle")
        if self.config.switch.kind != "generalized":
            raise ValidationError(
                "schema-4 execution requires switch.kind='generalized'",
                context={"switch_kind": self.config.switch.kind},
            )
        if not isinstance(self.switch, QueueBank):
            raise ValidationError(
                "canonical execution requires a QueueBank",
                context={"value_type": type(self.switch).__name__},
            )
        if not isinstance(self.sinks, CompletionSink):
            raise ValidationError(
                "canonical execution requires a CompletionSink",
                context={"value_type": type(self.sinks).__name__},
            )
        if self.switch.catalog != self.config.switch.catalog:
            raise ValidationError(
                "QueueBank catalog does not match the resolved switch configuration"
            )
        if self.compiled_arrival.queue_catalog != self.switch.catalog:
            raise ValidationError(
                "compiled arrival catalog does not match the QueueBank catalog"
            )
        expected_arrival_queues = frozenset(
            self.compiled_arrival.allowed_queue_ids()
        )
        if self.switch.allowed_arrival_queue_ids != expected_arrival_queues:
            raise ValidationError(
                "QueueBank allowed arrival support does not match the compiled arrival support",
                context={
                    "switch_allowed_queue_ids": sorted(
                        self.switch.allowed_arrival_queue_ids or (),
                        key=lambda value: (isinstance(value, str), value),
                    ),
                    "compiled_allowed_queue_ids": sorted(
                        expected_arrival_queues,
                        key=lambda value: (isinstance(value, str), value),
                    ),
                },
            )

        output_dir = Path(self.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        object.__setattr__(self, "output_dir", output_dir)
        object.__setattr__(self, "actual_seed", actual_seed)
        telemetry_path = output_dir / DEFAULT_SLOT_TRACE_FILENAME if self.config.telemetry.write_slot_trace else None
        object.__setattr__(self, "telemetry_path", telemetry_path)
        observation_path = (
            output_dir / DEFAULT_OBSERVATION_FILENAME
            if self.config.telemetry.observation.enabled
            else None
        )
        object.__setattr__(self, "observation_path", observation_path)
        object.__setattr__(self, "summary_path", output_dir / DEFAULT_RUN_SUMMARY_FILENAME)

    @property
    def requested_seed(self) -> int:
        return self.config.run.seed

    @property
    def flow_plan(self):
        return self.compiled_arrival.flow_plan

    def _validate_pre_run_state(self) -> None:
        if self._has_run:
            raise ValidationError("Simulator instances are single-run; build a new simulator to replay a run")
        if not self.switch.is_empty():
            raise ValidationError("switch must be empty before a fresh run starts")

        # A run directory may be intentionally reused. Remove only the named
        # dynamic artifacts owned by the simulator, including artifacts that
        # the new configuration disables; otherwise an old trace or compact
        # database could be mistaken for output from the new run.
        trace_artifact = self.output_dir / DEFAULT_SLOT_TRACE_FILENAME
        observation_artifact = self.output_dir / DEFAULT_OBSERVATION_FILENAME
        for artifact in (
            trace_artifact,
            observation_artifact,
            Path(f"{observation_artifact}-wal"),
            Path(f"{observation_artifact}-shm"),
        ):
            artifact.unlink(missing_ok=True)
        if self.summary_path.exists():
            self.summary_path.unlink()

    def _prepare_runtime_state(self) -> GenericRunStats:
        self._validate_pre_run_state()
        self.scheduler.reset()
        self.materializer.reset(reset_arrival_model=True)
        catalog = self.config.switch.catalog
        live_queue_ids = self.compiled_arrival.live_queue_ids()
        return GenericRunStats.from_catalog(
            catalog,
            live_queue_ids=live_queue_ids,
            family=self.compiled_arrival.family,
            metadata=self.compiled_arrival.metadata,
            queue_capacity=self.config.switch.capacity,
        )

    def _sample_arrival(self, slot: int, *, arrivals_enabled: bool) -> MaterializedArrival:
        if not arrivals_enabled:
            materialized = self.materializer.materialize(self.materializer.empty_sample(slot))
        else:
            arrival_rng = build_arrival_rng_for_slot(self.actual_seed, slot)
            materialized = self.materializer.sample_and_materialize(slot, arrival_rng)
        return materialized

    def _run_slot(
        self,
        *,
        slot: int,
        arrivals_enabled: bool,
        capture_scheduler_state: bool,
        exact_target_queue_ids: tuple[QueueId, ...] = (),
    ) -> CommittedSlot:
        if not isinstance(self.switch, QueueBank):
            raise ValidationError("canonical slot path requires a QueueBank")
        if not isinstance(self.sinks, CompletionSink):
            raise ValidationError("canonical slot path requires a CompletionSink")

        # Keep q_before as one contiguous vector copy: it is both the immutable
        # scheduler input and the exact statistics/telemetry sample for the slot.
        q_before = self.switch.queue_lengths()
        q_before.flags.writeable = False
        scheduler_state_before = self.scheduler.state_dict() if capture_scheduler_state else None

        scheduler_rng = build_scheduler_rng_for_slot(self.actual_seed, slot)
        select_service = getattr(self.scheduler, "select_service", None)
        if not callable(select_service):
            raise ValidationError(
                "generalized scheduler must implement select_service",
                context={"scheduler": getattr(self.scheduler, "name", type(self.scheduler).__name__)},
            )
        scheduler_snapshot = q_before.view()
        scheduler_snapshot.flags.writeable = False
        decision = select_service(scheduler_snapshot, slot, scheduler_rng)
        scheduler_state_after = self.scheduler.state_dict() if capture_scheduler_state else None

        if not isinstance(decision, ServiceDecision):
            raise ValidationError(
                "generalized scheduler must emit a ServiceDecision",
                context={"value_type": type(decision).__name__},
            )
        decision = self.scheduler.validate_service_decision(decision, scheduler_snapshot)

        exact_gap_certificates = _collect_exact_gap_certificates(
            scheduler=self.scheduler,
            catalog=self.switch.catalog,
            q_before=q_before,
            decision=decision,
            target_queue_ids=exact_target_queue_ids,
            slot=slot,
        )

        # QueueBank.service is the hard atomic boundary: it resolves and checks
        # every identity, duplicate, occupancy, and packet head before the first
        # FIFO is mutated.  Constraint-specific schedulers validate feasibility
        # in their own domain before returning the decision.
        departures = self.switch.service(decision, slot=slot)
        completions = self.sinks.accept_departures(departures, slot=slot)
        materialized = self._sample_arrival(slot, arrivals_enabled=arrivals_enabled)
        admissions = self.switch.enqueue_or_drop(materialized.attempts, slot=slot)
        q_after = self.switch.queue_lengths()
        q_after.flags.writeable = False

        scheduler_name = str(self.scheduler.name)
        algorithm_id = str(self.scheduler.algorithm_id)
        raw_optimizer_id = getattr(self.scheduler, "optimizer_id", None)
        optimizer_id = None if raw_optimizer_id is None else str(raw_optimizer_id)
        builder = (
            GenericSlotTraceBuilder(
                slot=slot,
                catalog=self.switch.catalog,
                queue_snapshot_mode=self.config.telemetry.queue_snapshot,
                scheduler_id=scheduler_name,
                algorithm_id=algorithm_id,
                optimizer_id=optimizer_id,
            )
            .set_q_before(q_before)
            .set_service_decision(decision)
        )
        if capture_scheduler_state:
            builder = builder.set_scheduler_state_before(scheduler_state_before).set_scheduler_state_after(scheduler_state_after)
        record = (
            builder
            .add_departures(departures)
            .add_completions(completions)
            .set_materialized_arrival(materialized)
            .set_admissions(admissions)
            .set_q_after(q_after)
            .finalize()
        )
        return CommittedSlot(
            slot=slot,
            catalog=self.switch.catalog,
            q_before=q_before,
            q_after=q_after,
            service_decision=decision,
            departures=tuple(departures),
            offered=tuple(materialized.attempts),
            admissions=tuple(admissions),
            exact_gap_certificates=exact_gap_certificates,
            record=record,
        )

    @staticmethod
    def _normalize_observers(observers: Any) -> tuple[Any, ...]:
        if observers is None:
            return ()
        if callable(observers) or callable(getattr(observers, "observe", None)):
            normalized = (observers,)
        else:
            if isinstance(observers, (str, bytes, bytearray)):
                raise ValidationError("observers must be a callback, observer, or iterable of observers")
            try:
                normalized = tuple(observers)
            except TypeError as exc:
                raise ValidationError(
                    "observers must be a callback, observer, or iterable of observers",
                    context={"value_type": type(observers).__name__},
                ) from exc
        for index, observer in enumerate(normalized):
            if not callable(observer) and not callable(getattr(observer, "observe", None)):
                raise ValidationError(
                    "each committed-slot observer must be callable or implement observe(commit)",
                    context={"index": index, "value_type": type(observer).__name__},
                )
        return normalized

    def _record_measurement_commit(
        self,
        commit: CommittedSlot,
        *,
        telemetry_writer: JsonlWriter | None,
        stats: GenericRunStats,
        observers: tuple[Any, ...],
    ) -> None:
        """Synchronously publish one already-validated measurement commit."""

        if telemetry_writer is not None:
            telemetry_writer.write_slot(commit.record)
        if not isinstance(stats, GenericRunStats):  # pragma: no cover - invariant
            raise ValidationError(
                "unsupported statistics accumulator",
                context={"value_type": type(stats).__name__},
            )
        stats.update(
            commit.record,
            q_before_vector=commit.q_before,
            q_after_vector=commit.q_after,
        )
        for observer in observers:
            if callable(observer):
                observer(commit)
            else:
                observer.observe(commit)

    def run(
        self,
        *,
        observers: CommittedSlotObserver | Iterable[Any] | None = None,
    ) -> SimulationResult:
        """Execute one deterministic simulator run and return its artifact bundle."""

        stats = self._prepare_runtime_state()
        configured_slots = int(self.config.run.slots)
        warmup_slots = int(self.config.run.warmup_slots)
        if configured_slots < 0:  # pragma: no cover - config validation should already reject this
            raise ValidationError("config.run.slots must be non-negative", context={"slots": configured_slots})
        if not 0 <= warmup_slots < configured_slots:
            raise ValidationError(
                "config.run.warmup_slots must satisfy 0 <= warmup_slots < slots",
                context={"warmup_slots": warmup_slots, "slots": configured_slots},
            )
        normalized_observers = self._normalize_observers(observers)
        exact_target_queue_ids = (
            tuple(
                target.queue_id
                for target in self.config.telemetry.observation.targets
                if target.gap == "exact"
            )
            if self.config.telemetry.observation.enabled
            else ()
        )
        measurement_start: np.ndarray | None = None
        measurement_end: np.ndarray | None = None

        slot = 0
        observation_context = (
            CompactObservationRecorder(
                self.observation_path,
                window_start=warmup_slots,
                window_stop=configured_slots,
                block_slots=self.config.telemetry.observation.block_slots,
                targets=tuple(
                    ObservationTarget(
                        target_id=f"target_{self.config.switch.catalog.index_of(target.queue_id)}",
                        queue_id=target.queue_id,
                        gap_mode=target.gap,
                    )
                    for target in self.config.telemetry.observation.targets
                ),
                metadata=_observation_metadata(self),
            )
            if self.observation_path is not None
            else nullcontext(None)
        )
        writer_context = (
            JsonlWriter(self.telemetry_path, append=False, include_packet_events=self.config.telemetry.include_packet_events)
            if self.telemetry_path is not None
            else nullcontext(None)
        )
        # The observation database is the outer publication guard.  It must
        # remain nonterminal until every other run artifact and scientific
        # invariant has succeeded, so a later failure is recorded as FAILED
        # rather than leaving a poolable COMPLETE database behind.
        with observation_context as observation_recorder:
            with writer_context as telemetry_writer:
                measurement_observers = normalized_observers
                if observation_recorder is not None:
                    measurement_observers = (
                        observation_recorder.record_committed_slot,
                        *measurement_observers,
                    )

                def execute_slot(current_slot: int, *, arrivals_enabled: bool) -> CommittedSlot:
                    nonlocal measurement_start, measurement_end
                    in_measurement = warmup_slots <= current_slot < configured_slots
                    capture_scheduler_state = bool(
                        in_measurement
                        and telemetry_writer is not None
                        and self.config.telemetry.include_scheduler_state
                    )
                    commit = self._run_slot(
                        slot=current_slot,
                        arrivals_enabled=arrivals_enabled,
                        capture_scheduler_state=capture_scheduler_state,
                        exact_target_queue_ids=(
                            exact_target_queue_ids if in_measurement else ()
                        ),
                    )
                    if in_measurement:
                        if measurement_start is None:
                            # N_W is q_before at the first measured decision.
                            measurement_start = commit.q_before
                        # N_T is q_after for slot T-1.  Intermediate assignments
                        # are detached queue snapshots and do not change dynamics.
                        measurement_end = commit.q_after
                        self._record_measurement_commit(
                            commit,
                            telemetry_writer=telemetry_writer,
                            stats=stats,
                            observers=measurement_observers,
                        )
                    return commit

                if self.config.run.termination == "fixed_slots":
                    for slot in range(configured_slots):
                        execute_slot(slot, arrivals_enabled=True)
                    slots_run = configured_slots
                elif self.config.run.termination == "fixed_slots_then_drain":
                    for slot in range(configured_slots):
                        execute_slot(slot, arrivals_enabled=True)
                    slot = configured_slots
                    while not self.switch.is_empty():
                        backlog_before = self.switch.total_occupancy()
                        execute_slot(slot, arrivals_enabled=False)
                        backlog_after = self.switch.total_occupancy()
                        if backlog_after >= backlog_before:
                            raise ScheduleError(
                                "drain slot made no progress with arrivals disabled",
                                context={
                                    "slot": slot,
                                    "backlog_before": backlog_before,
                                    "backlog_after": backlog_after,
                                    "scheduler": self.scheduler.name,
                                    "algorithm_id": self.scheduler.algorithm_id,
                                    "optimizer_id": getattr(self.scheduler, "optimizer_id", None),
                                    "service_family": self.config.scheduler.service_family,
                                },
                            )
                        slot += 1
                    slots_run = slot
                else:  # pragma: no cover - config validation should already reject unknown modes
                    raise ValidationError(
                        "Unsupported run termination mode",
                        context={"termination": self.config.run.termination},
                    )

            # The trace context has closed successfully before publication.
            if measurement_start is None or measurement_end is None:  # pragma: no cover - guarded above
                raise ValidationError("measurement window did not produce its required boundaries")
            if self.config.switch.capacity is None and stats.dropped_packets != 0:
                raise ValidationError(
                    "a successful NoDrop run cannot contain dropped packets",
                    context={"dropped_packets": stats.dropped_packets},
                )

            summary = stats.finalize(
                metadata=_summary_metadata(
                    self,
                    measurement_start=measurement_start,
                    measurement_end=measurement_end,
                )
            )
            SummaryWriter(self.summary_path).write(summary)
            result = SimulationResult(
                requested_seed=self.requested_seed,
                actual_seed=self.actual_seed,
                output_dir=self.output_dir,
                telemetry_path=self.telemetry_path,
                observation_path=self.observation_path,
                summary_path=self.summary_path,
                summary=summary,
                static_artifacts=dict(sorted(self.static_artifacts.items())),
                slots_run=slots_run,
                measurement_queue_ids=self.config.switch.catalog.queue_ids,
                measurement_start_queue_lengths=tuple(int(value) for value in measurement_start),
                measurement_end_queue_lengths=tuple(int(value) for value in measurement_end),
            )

            # This is the final fallible publication action.  Any exception
            # above reaches the recorder context while it is still open and
            # causes the exact retained prefix to be marked non-poolable.
            if observation_recorder is not None:
                observation_recorder.complete()

        object.__setattr__(self, "_has_run", True)
        return result



def build_simulation(
    config: ConfigSource,
    *,
    output_dir: str | Path | None = None,
    include_arrival_support: bool = True,
) -> Simulator:
    """Build a fully wired simulator from a config object, mapping, or file path.

    The function resolves the concrete master seed, compiles the arrival
    model, instantiates the switch, scheduler, sinks, and materializer, and
    writes the deterministic static run artifacts for the chosen output
    directory.
    """

    resolved_config = _load_resolved_config(config)
    actual_seed = _resolve_effective_actual_seed(resolved_config)
    resolved_with_seed = resolved_config.with_actual_seed(actual_seed)
    validate_config(resolved_with_seed)

    compiled = compile_arrival_spec(resolved_with_seed, actual_seed=actual_seed, validate=False)
    materializer = build_arrival_materializer(compiled)
    if resolved_with_seed.switch.kind != "generalized":
        raise ValidationError(
            "schema-4 execution requires switch.kind='generalized'",
            context={"switch_kind": resolved_with_seed.switch.kind},
        )

    catalog = resolved_with_seed.switch.catalog
    switch = QueueBank(
        catalog,
        resolved_with_seed.switch.capacity,
        allowed_arrival_queue_ids=compiled.allowed_queue_ids(),
        check_arrival_support=True,
    )
    sinks = CompletionSink()
    service_family = resolved_with_seed.scheduler.service_family
    if service_family is None:  # pragma: no cover - validation owns this
        raise ValidationError(
            "scheduler must resolve to exactly one service family",
            context={"scheduler": resolved_with_seed.scheduler.name},
        )
    scheduler = build_scheduler_for_domain(
        resolved_with_seed.scheduler.name,
        resolved_with_seed.scheduler.params,
        QueueSchedulerDomain(
            queue_catalog=catalog,
            service_family=service_family,
        ),
    )

    # Bind and validate the complete runtime service domain before resolving or
    # creating the output directory. In particular, a resource-packing column
    # that exceeds capacity must not leave a partial run artifact tree behind.
    validate_arrival_serviceability(compiled, scheduler)

    output_path = _resolve_output_dir(resolved_with_seed, output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    service_model = build_service_model(resolved_with_seed)
    manifest = RunManifest(
        requested_seed=resolved_with_seed.run.seed,
        actual_seed=actual_seed,
        config_hash=hash_resolved_config(resolved_config_to_dict(resolved_with_seed, actual_seed=actual_seed)),
        flow_plan_hash=hash_flow_plan(compiled.flow_plan.to_dict()),
        service_model_hash=hash_service_model(service_model),
        simulator_version=SIMULATOR_VERSION,
        config_schema_version=resolved_with_seed.schema_version,
        switch_kind=resolved_with_seed.switch.kind,
        n_queues=resolved_with_seed.switch.n_queues,
        service_family=resolved_with_seed.scheduler.service_family,
        scheduler_name=resolved_with_seed.scheduler.name,
        scheduler_algorithm_id=str(scheduler.algorithm_id),
        scheduler_optimizer_id=(
            None
            if getattr(scheduler, "optimizer_id", None) is None
            else str(scheduler.optimizer_id)
        ),
        scheduler_params=resolved_with_seed.scheduler.params,
    )
    static_artifacts = write_static_run_artifacts(
        output_path,
        config=resolved_with_seed,
        actual_seed=actual_seed,
        manifest=manifest,
        compiled_arrival=compiled,
        service_model=service_model,
        include_arrival_support=include_arrival_support,
    )

    return Simulator(
        config=resolved_with_seed,
        actual_seed=actual_seed,
        compiled_arrival=compiled,
        materializer=materializer,
        switch=switch,
        sinks=sinks,
        scheduler=scheduler,
        output_dir=output_path,
        static_artifacts=static_artifacts,
    )


__all__ = [
    "DEFAULT_OUTPUT_DIRNAME",
    "DEFAULT_OBSERVATION_FILENAME",
    "ConfigSource",
    "SimulationResult",
    "Simulator",
    "validate_arrival_serviceability",
    "build_simulation",
]
