from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass
from numbers import Integral
from typing import Any, Callable, Protocol, runtime_checkable

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision
from ..types import JSONValue, QueueId
from ..utils import normalize_for_json


SchedulerFactory = Callable[[Mapping[str, JSONValue] | None], "QueueScheduler"]


def _normalize_scheduler_name(value: Any, *, name: str = "scheduler name") -> str:
    if not isinstance(value, str):
        raise ValidationError(f"{name} must be a string", context={"value": value})
    token = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in token:
        token = token.replace("__", "_")
    token = token.strip("_")
    if not token:
        raise ValidationError(f"{name} must not be empty", context={"value": value})
    return token


normalize_scheduler_name = _normalize_scheduler_name


def _validate_slot(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError("slot must be an integer", context={"value": value})
    slot = int(value)
    if slot < 0:
        raise ValidationError("slot must be >= 0", context={"value": slot, "minimum": 0})
    return slot


validate_scheduler_slot = _validate_slot


def _require_rng(value: Any) -> np.random.Generator:
    if not isinstance(value, np.random.Generator):
        raise ValidationError(
            "rng must be a numpy.random.Generator",
            context={"value_type": type(value).__name__},
        )
    return value


validate_scheduler_rng = _require_rng


def _normalize_params(params: Mapping[str, JSONValue] | None) -> dict[str, JSONValue]:
    if params is None:
        return {}
    if not isinstance(params, Mapping):
        raise ValidationError(
            "scheduler params must be a mapping",
            context={"value_type": type(params).__name__},
        )
    normalized: dict[str, JSONValue] = {}
    for key, value in params.items():
        if not isinstance(key, str):
            raise ValidationError(
                "scheduler params keys must be strings",
                context={"key": key, "key_type": type(key).__name__},
            )
        normalized[key] = normalize_for_json(value)
    return dict(sorted(normalized.items()))


normalize_scheduler_params = _normalize_params


def coerce_queue_vector(q_len: Any, *, expected_size: int | None = None) -> np.ndarray:
    """Validate a scheduler-facing one-dimensional queue-length vector.

    Runtime queue storage is already contiguous ``int64``.  The validation and
    copy here protect the public scheduler boundary; constraint-specific
    schedulers may safely retain or transform the returned array without being
    able to mutate live queues.
    """

    vector = np.asarray(q_len)
    if vector.ndim != 1:
        raise ValidationError(
            "queue lengths must be a one-dimensional vector",
            context={"shape": tuple(int(value) for value in vector.shape)},
        )
    if vector.size == 0:
        raise ValidationError("queue-length vector must be non-empty", context={"shape": (0,)})
    if expected_size is not None:
        if isinstance(expected_size, bool) or not isinstance(expected_size, Integral):
            raise ValidationError("expected_size must be an integer", context={"value": expected_size})
        if int(expected_size) < 1:
            raise ValidationError("expected_size must be >= 1", context={"value": int(expected_size)})
        if vector.shape[0] != int(expected_size):
            raise ValidationError(
                "queue-length vector has the wrong length",
                context={"length": int(vector.shape[0]), "expected_size": int(expected_size)},
            )

    if np.issubdtype(vector.dtype, np.integer):
        coerced = np.array(vector, dtype=np.int64, copy=True)
    else:
        if not np.issubdtype(vector.dtype, np.number):
            raise ValidationError(
                "queue-length vector must contain numeric values",
                context={"dtype": str(vector.dtype)},
            )
        if not np.all(np.isfinite(vector)):
            raise ValidationError(
                "queue-length vector must contain only finite values",
                context={"dtype": str(vector.dtype)},
            )
        floored = np.floor(vector)
        if not np.array_equal(vector, floored):
            raise ValidationError(
                "queue-length vector must contain integer-valued occupancies",
                context={"dtype": str(vector.dtype)},
            )
        coerced = np.array(floored, dtype=np.int64, copy=True)

    if np.any(coerced < 0):
        raise ValidationError(
            "queue-length vector must not contain negative occupancies",
            context={"minimum": int(coerced.min(initial=0))},
        )
    return coerced


validate_scheduler_queue_vector = coerce_queue_vector


def validate_scheduler_service_decision(
    decision: Any,
    q_len: Any,
    queue_catalog: QueueCatalog,
) -> ServiceDecision:
    """Validate generic scheduler output against identity and occupancy.

    Constraint feasibility is intentionally not inferred here.  It belongs to
    the constraint-specific scheduler/domain implementation.  This common
    boundary guarantees that malformed output cannot reach mutable queue state.
    """

    if not isinstance(queue_catalog, QueueCatalog):
        raise ValidationError(
            "queue_catalog must be a QueueCatalog",
            context={"value_type": type(queue_catalog).__name__},
        )
    vector = coerce_queue_vector(q_len, expected_size=queue_catalog.n_queues)
    if not isinstance(decision, ServiceDecision):
        raise ScheduleError(
            "scheduler must emit a ServiceDecision",
            context={"value_type": type(decision).__name__},
        )

    selected_ids = decision.selected_queue_ids
    seen: set[QueueId] = set()
    for queue_id in selected_ids:
        if queue_id in seen:
            raise ScheduleError(
                "scheduler service decision contains duplicate queues",
                context={"queue_id": queue_id},
            )
        seen.add(queue_id)
        try:
            queue_index = queue_catalog.index_of(queue_id)
        except ValidationError as exc:
            raise ScheduleError(
                "scheduler selected a queue outside its configured domain",
                context={"queue_id": queue_id},
            ) from exc
        if int(vector[queue_index]) <= 0:
            raise ScheduleError(
                "scheduler selected an empty queue",
                context={"queue_id": queue_id, "occupancy": int(vector[queue_index])},
            )
    return decision


@runtime_checkable
class QueueScheduler(Protocol):
    """Native generalized scheduler protocol."""

    @property
    def name(self) -> str: ...

    @property
    def params(self) -> Mapping[str, JSONValue]: ...

    @property
    def algorithm_id(self) -> str: ...

    def reset(self) -> None: ...

    def configure_for_domain(self, domain: Any) -> None: ...

    @property
    def individually_serviceable_queue_ids(self) -> tuple[QueueId, ...]: ...

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision: ...

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision: ...

    def state_dict(self) -> dict[str, JSONValue] | None: ...

    def to_dict(self) -> dict[str, JSONValue]: ...


@dataclass(slots=True)
class SchedulerBase(ABC):
    """Common validation and serialization helpers for scheduler plugins."""

    _params: dict[str, JSONValue]

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        self._params = _normalize_params(params)

    @property
    @abstractmethod
    def name(self) -> str:
        """Canonical scheduler name used by config and telemetry."""

    @property
    def params(self) -> Mapping[str, JSONValue]:
        return self._params

    @property
    def effective_params(self) -> Mapping[str, JSONValue]:
        """Canonical parameters, including constructor-resolved defaults."""

        return self._params

    @property
    def algorithm_id(self) -> str:
        """Stable implementation identity, separate from the public policy ID.

        Exact schedulers already expose ``optimizer_id``; for them the
        algorithm identity is deliberately identical.  Other schedulers may
        override this property with a class constant.
        """

        optimizer_id = getattr(self, "optimizer_id", None)
        if isinstance(optimizer_id, str) and optimizer_id:
            return optimizer_id
        return self.name

    def reset(self) -> None:
        """Reset any scheduler-internal state."""

    def state_dict(self) -> dict[str, JSONValue] | None:
        return None

    def to_dict(self) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "name": self.name,
            "algorithm_id": self.algorithm_id,
            "params": dict(self.params),
        }
        state = self.state_dict()
        if state is not None:
            payload["state"] = normalize_for_json(state)
        return payload

class QueueSchedulerBase(SchedulerBase, ABC):
    """Base class for native queue-vector/ServiceDecision schedulers."""

    __slots__ = ("_scheduler_domain",)

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        self._scheduler_domain: Any | None = None

    @property
    def scheduler_domain(self) -> Any | None:
        return self._scheduler_domain

    @property
    def individually_serviceable_queue_ids(self) -> tuple[QueueId, ...]:
        """Queues that are feasible when selected by themselves.

        The current crossbar, interval, node-exclusive, and conflict-graph
        feasible sets are downward closed and admit every catalog queue as a
        singleton. Resource-packing schedulers override this property because
        a column can exceed a resource capacity even when no other queue is
        selected. The kernel consumes the property once, after domain binding,
        to reject live arrival support that can never drain.
        """

        if self._scheduler_domain is None:
            raise ValidationError(
                "scheduler must be configured for a service domain before querying serviceability",
                context={"scheduler": self.name},
            )
        return self._scheduler_domain.queue_catalog.queue_ids

    def validate_for_domain(self, domain: Any) -> None:
        catalog = getattr(domain, "queue_catalog", None)
        family = getattr(domain, "service_family", None)
        if not isinstance(catalog, QueueCatalog) or not isinstance(family, str):
            raise ValidationError(
                "scheduler domain must expose service_family and a QueueCatalog",
                context={"value_type": type(domain).__name__},
            )

    def configure_for_domain(self, domain: Any) -> None:
        self.validate_for_domain(domain)
        if self._scheduler_domain is not None and self._scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )
        self._scheduler_domain = domain

    def validate_queue_select_inputs(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> tuple[np.ndarray, int, np.random.Generator]:
        if self._scheduler_domain is None:
            raise ValidationError(
                "scheduler must be configured for a service domain before selection",
                context={"scheduler": self.name},
            )
        catalog = self._scheduler_domain.queue_catalog
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        return vector, _validate_slot(slot), _require_rng(rng)

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        """Validate a selected service vector before queue mutation.

        This base implementation enforces the universal queue-ID and occupancy
        rules. Constraint-specific production schedulers must extend/override
        it with their own feasibility test; the kernel invokes this hook after
        every selection and before handing the decision to QueueBank.
        """

        if self._scheduler_domain is None:
            raise ValidationError(
                "scheduler must be configured for a service domain before selection",
                context={"scheduler": self.name},
            )
        return validate_scheduler_service_decision(
            decision,
            q_len,
            self._scheduler_domain.queue_catalog,
        )

    @abstractmethod
    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        """Select queues for one-packet service from a queue-length vector."""


__all__ = [
    "SchedulerFactory",
    "normalize_scheduler_name",
    "normalize_scheduler_params",
    "validate_scheduler_slot",
    "validate_scheduler_rng",
    "coerce_queue_vector",
    "validate_scheduler_queue_vector",
    "validate_scheduler_service_decision",
    "QueueScheduler",
    "SchedulerBase",
    "QueueSchedulerBase",
]
