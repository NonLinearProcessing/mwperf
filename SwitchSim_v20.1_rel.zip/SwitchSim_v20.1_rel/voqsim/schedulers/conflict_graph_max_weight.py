"""Exact MaxWeight scheduling under pairwise queue conflicts.

The catalog queues are the vertices of a simple undirected conflict graph.
An edge means that its two queues may not be served in the same slot.  Each
slot is solved exactly by the include/exclude maximum-weight-independent-set
recurrence from Section 3.4 of ``MaxWeight_Algorithms_and_Arrivals.md``.

Static conflicts and exact lexicographic bonuses are compiled once at domain
binding.  The exponential search uses dense integer bit masks, a per-decision
memo, and induced connected-component decomposition.  ``max_search_states``
is an optional hard safety limit: exhaustion raises :class:`ScheduleError`;
an approximate or incumbent schedule is never returned.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import JSONValue, QueueId
from .base import QueueSchedulerBase, coerce_queue_vector, validate_scheduler_slot
from .domain import normalize_service_family
from .exact_gap import ExactGapCertificate, assemble_exact_gap_certificates
from .exact_priority import canonical_priority, exact_lex_weights


_SERVICE_FAMILY = "pairwise_conflicts"
_ALLOWED_PARAM_KEYS = frozenset({"constraint", "priority", "max_search_states"})
_CONSTRAINT_KEYS = frozenset({"conflicts"})

_Conflict = tuple[QueueId, QueueId]


def _queue_id_sort_key(queue_id: QueueId) -> tuple[int, int | str]:
    """Total order for the disjoint integer and string queue-ID types."""

    return (0, queue_id) if isinstance(queue_id, int) else (1, queue_id)


def _require_list(value: Any, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(
            f"{name} must be a list",
            context={"value_type": type(value).__name__},
        )
    return list(value)


def _normalize_constraint(value: Any) -> tuple[dict[str, JSONValue], tuple[_Conflict, ...]]:
    if not isinstance(value, Mapping):
        raise ValidationError(
            "conflict_graph_max_weight requires a constraint mapping",
            context={"value_type": type(value).__name__},
        )
    fields = set(value)
    unknown = sorted(fields - _CONSTRAINT_KEYS)
    missing = sorted(_CONSTRAINT_KEYS - fields)
    if unknown or missing:
        raise ValidationError(
            "pairwise-conflict constraint must contain exactly conflicts",
            context={"unknown_keys": unknown, "missing_keys": missing},
        )

    raw_conflicts = _require_list(
        value["conflicts"],
        name="scheduler.params.constraint.conflicts",
    )
    conflicts: list[_Conflict] = []
    seen: dict[_Conflict, int] = {}
    for conflict_index, raw_conflict in enumerate(raw_conflicts):
        pair = _require_list(
            raw_conflict,
            name=f"scheduler.params.constraint.conflicts[{conflict_index}]",
        )
        if len(pair) != 2:
            raise ValidationError(
                "each pairwise conflict must contain exactly two queue identifiers",
                context={"conflict_index": conflict_index, "length": len(pair)},
            )
        left = normalize_queue_id(
            pair[0],
            name=f"scheduler.params.constraint.conflicts[{conflict_index}][0]",
        )
        right = normalize_queue_id(
            pair[1],
            name=f"scheduler.params.constraint.conflicts[{conflict_index}][1]",
        )
        if left == right:
            raise ValidationError(
                "pairwise conflicts must not contain self-loops",
                context={"conflict_index": conflict_index, "queue_id": left},
            )
        if _queue_id_sort_key(right) < _queue_id_sort_key(left):
            left, right = right, left
        edge = (left, right)
        if edge in seen:
            raise ValidationError(
                "pairwise-conflict constraint contains a duplicate undirected edge",
                context={
                    "conflict": [left, right],
                    "first_index": seen[edge],
                    "duplicate_index": conflict_index,
                },
            )
        seen[edge] = conflict_index
        conflicts.append(edge)

    conflicts.sort(
        key=lambda edge: (_queue_id_sort_key(edge[0]), _queue_id_sort_key(edge[1]))
    )
    canonical: dict[str, JSONValue] = {
        "conflicts": [[left, right] for left, right in conflicts]
    }
    return canonical, tuple(conflicts)


def _normalize_declared_priority(value: Any) -> tuple[QueueId, ...] | None:
    if value is None:
        return None
    raw_priority = _require_list(value, name="scheduler.params.priority")
    priority = tuple(
        normalize_queue_id(queue_id, name=f"scheduler.params.priority[{index}]")
        for index, queue_id in enumerate(raw_priority)
    )
    positions: dict[QueueId, int] = {}
    for index, queue_id in enumerate(priority):
        if queue_id in positions:
            raise ValidationError(
                "scheduler.params.priority contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": positions[queue_id],
                    "duplicate_index": index,
                },
            )
        positions[queue_id] = index
    return priority


def _normalize_search_limit(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(
            "scheduler.params.max_search_states must be a positive integer or null",
            context={"value": value},
        )
    limit = int(value)
    if limit < 1:
        raise ValidationError(
            "scheduler.params.max_search_states must be >= 1",
            context={"value": limit, "minimum": 1},
        )
    return limit


def _component_masks(mask: int, adjacency: tuple[int, ...]) -> tuple[int, ...]:
    """Return induced connected components in increasing vertex order."""

    remaining = mask
    components: list[int] = []
    while remaining:
        seed = remaining & -remaining
        component = seed
        frontier = seed
        while frontier:
            vertex_bit = frontier & -frontier
            frontier ^= vertex_bit
            vertex = vertex_bit.bit_length() - 1
            discovered = adjacency[vertex] & mask & ~component
            component |= discovered
            frontier |= discovered
        components.append(component)
        remaining &= ~component
    return tuple(components)


def _solve_mwis_prevalidated(
    eligible_mask: int,
    adjacency: tuple[int, ...],
    weights: tuple[int, ...],
    *,
    max_search_states: int | None,
    slot: int,
) -> int:
    """Return the exact selected-vertex mask for trusted dense inputs."""

    if eligible_mask == 0:
        return 0

    memo: dict[int, tuple[int, int]] = {0: (0, 0)}
    states_explored = 0

    def solve(mask: int) -> tuple[int, int]:
        nonlocal states_explored
        cached = memo.get(mask)
        if cached is not None:
            return cached

        states_explored += 1
        if max_search_states is not None and states_explored > max_search_states:
            raise ScheduleError(
                "conflict_graph_max_weight exact search exceeded max_search_states",
                context={
                    "slot": slot,
                    "max_search_states": max_search_states,
                    "states_explored": states_explored,
                },
            )

        # A singleton or an induced edgeless graph can be accepted in its
        # entirety because every eligible composite weight is strictly positive.
        # Check this before decomposing into singleton components so the common
        # unconstrained case remains one linear scan and one search state.
        scan = mask
        has_edge = False
        while scan:
            vertex_bit = scan & -scan
            scan ^= vertex_bit
            vertex = vertex_bit.bit_length() - 1
            if adjacency[vertex] & mask:
                has_edge = True
                break
        if not has_edge:
            score = 0
            scan = mask
            while scan:
                vertex_bit = scan & -scan
                scan ^= vertex_bit
                score += weights[vertex_bit.bit_length() - 1]
            result = (score, mask)
            memo[mask] = result
            return result

        components = _component_masks(mask, adjacency)
        if len(components) > 1:
            total_score = 0
            selected_mask = 0
            for component in components:
                component_score, component_selected = solve(component)
                total_score += component_score
                selected_mask |= component_selected
            result = (total_score, selected_mask)
            memo[mask] = result
            return result

        # Maximum induced degree is a deterministic, inexpensive branching
        # heuristic.  Lowest dense catalog index breaks equal-degree ties.
        scan = mask
        branch_vertex = -1
        branch_degree = -1
        while scan:
            vertex_bit = scan & -scan
            scan ^= vertex_bit
            vertex = vertex_bit.bit_length() - 1
            degree = (adjacency[vertex] & mask).bit_count()
            if degree > branch_degree:
                branch_vertex = vertex
                branch_degree = degree

        branch_bit = 1 << branch_vertex
        exclude_score, exclude_selected = solve(mask ^ branch_bit)
        include_remainder = mask & ~branch_bit & ~adjacency[branch_vertex]
        remainder_score, remainder_selected = solve(include_remainder)
        include_score = weights[branch_vertex] + remainder_score
        include_selected = branch_bit | remainder_selected

        # Exact lexicographic weights make distinct feasible selections unique.
        # Keep the exclude branch on a defensive equality for deterministic
        # behavior even if this trusted helper is reused with other weights.
        if include_score > exclude_score:
            result = (include_score, include_selected)
        else:
            result = (exclude_score, exclude_selected)
        memo[mask] = result
        return result

    try:
        return solve(eligible_mask)[1]
    except RecursionError as exc:
        raise ScheduleError(
            "conflict_graph_max_weight exact search exceeded the Python recursion depth",
            context={"slot": slot, "states_explored": states_explored},
        ) from exc


class ConflictGraphMaxWeightScheduler(QueueSchedulerBase):
    """Exact lexicographic MaxWeight on a declared pairwise-conflict graph."""

    __slots__ = (
        "_constraint",
        "_declared_conflicts",
        "_declared_priority",
        "_max_search_states",
        "_priority",
        "_primary_scale",
        "_priority_bonus",
        "_adjacency",
    )

    optimizer_id = "mwis_branch_memo_exact"
    service_family = _SERVICE_FAMILY

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        try:
            super().__init__(params=params)
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "conflict_graph_max_weight params must contain finite JSON-safe values",
                context={"error": str(exc)},
            ) from exc

        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "conflict_graph_max_weight received unsupported scheduler params",
                context={
                    "unknown_keys": unknown,
                    "allowed": sorted(_ALLOWED_PARAM_KEYS),
                },
            )
        if "constraint" not in self.params:
            raise ValidationError(
                "conflict_graph_max_weight requires scheduler.params.constraint"
            )

        constraint, conflicts = _normalize_constraint(self.params["constraint"])
        priority = _normalize_declared_priority(self.params.get("priority"))
        max_search_states = _normalize_search_limit(
            self.params.get("max_search_states")
        )
        self._params = {
            "constraint": constraint,
            "priority": None if priority is None else list(priority),
            "max_search_states": max_search_states,
        }
        self._constraint = constraint
        self._declared_conflicts = conflicts
        self._declared_priority = priority
        self._max_search_states = max_search_states
        self._priority: tuple[QueueId, ...] | None = None
        self._primary_scale = 0
        self._priority_bonus: tuple[int, ...] = ()
        self._adjacency: tuple[int, ...] | None = None

    @property
    def name(self) -> str:
        return "conflict_graph_max_weight"

    @property
    def priority(self) -> tuple[QueueId, ...] | None:
        return self._priority if self._priority is not None else self._declared_priority

    @property
    def constraint(self) -> Mapping[str, JSONValue]:
        return self._constraint

    @property
    def max_search_states(self) -> int | None:
        return self._max_search_states

    def state_dict(self) -> dict[str, JSONValue]:
        return {
            "scheduler_kind": self.name,
            "optimizer_id": self.optimizer_id,
        }

    def validate_for_domain(self, domain: Any) -> None:
        super().validate_for_domain(domain)
        family = normalize_service_family(domain.service_family)
        if family != _SERVICE_FAMILY:
            raise ValidationError(
                "conflict_graph_max_weight requires the pairwise_conflicts service family",
                context={"service_family": family},
            )

        catalog: QueueCatalog = domain.queue_catalog
        for conflict_index, (left, right) in enumerate(self._declared_conflicts):
            for endpoint, queue_id in (("left", left), ("right", right)):
                try:
                    catalog.index_of(queue_id)
                except ValidationError as exc:
                    raise ValidationError(
                        "pairwise conflict references a queue outside the catalog",
                        context={
                            "conflict_index": conflict_index,
                            "endpoint": endpoint,
                            "queue_id": queue_id,
                        },
                    ) from exc
        canonical_priority(catalog, self._declared_priority)

    def configure_for_domain(self, domain: Any) -> None:
        # Compile entirely into locals before the binding commit.  A malformed
        # graph or priority therefore cannot leave this scheduler half-bound.
        self.validate_for_domain(domain)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )

        catalog: QueueCatalog = domain.queue_catalog
        priority = canonical_priority(catalog, self._declared_priority)
        priority_bonus = exact_lex_weights((0,) * catalog.n_queues, catalog, priority)
        adjacency = [0] * catalog.n_queues
        for left, right in self._declared_conflicts:
            left_index = catalog.index_of(left)
            right_index = catalog.index_of(right)
            adjacency[left_index] |= 1 << right_index
            adjacency[right_index] |= 1 << left_index

        super().configure_for_domain(domain)
        self._priority = priority
        self._primary_scale = 1 << catalog.n_queues
        self._priority_bonus = priority_bonus
        self._adjacency = tuple(adjacency)

    def _compiled(
        self,
    ) -> tuple[QueueCatalog, tuple[QueueId, ...], tuple[int, ...]]:
        domain = self.scheduler_domain
        if domain is None or self._priority is None or self._adjacency is None:
            raise ValidationError(
                "conflict_graph_max_weight must be configured for a service domain before use"
            )
        return domain.queue_catalog, self._priority, self._adjacency

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, resolved_slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog, _priority, _adjacency = self._compiled()

        eligible_mask = 0
        weights = [0] * catalog.n_queues
        for queue_index, raw_length in enumerate(vector):
            length = int(raw_length)
            if length > 0:
                eligible_mask |= 1 << queue_index
                weights[queue_index] = (
                    self._primary_scale * length + self._priority_bonus[queue_index]
                )
        if eligible_mask == 0:
            return ServiceDecision.empty()

        selected_indices = self._solve_exact_indices(
            tuple(weights),
            eligible_mask,
            slot=resolved_slot,
        )
        return ServiceDecision.from_indices(selected_indices, catalog)

    def _solve_exact_indices(
        self,
        weights: tuple[int, ...],
        eligible_mask: int,
        *,
        slot: int,
        reserved_queue_index: int | None = None,
    ) -> tuple[int, ...]:
        """Invoke the trusted MWIS core for one explicit eligible mask."""

        _catalog, _priority, adjacency = self._compiled()
        selected_mask = _solve_mwis_prevalidated(
            eligible_mask,
            adjacency,
            weights,
            max_search_states=self._max_search_states,
            slot=slot,
        )
        selected_indices: list[int] = []
        while selected_mask:
            queue_bit = selected_mask & -selected_mask
            selected_mask ^= queue_bit
            selected_indices.append(queue_bit.bit_length() - 1)
        if reserved_queue_index is not None:
            selected_indices.append(reserved_queue_index)
        selected_indices.sort()
        return tuple(selected_indices)

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]:
        """Return exact full-conflict-graph class values for targets."""

        catalog, _priority, adjacency = self._compiled()
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        resolved_slot = validate_scheduler_slot(slot)
        eligible_mask = 0
        weights = [0] * catalog.n_queues
        for queue_index, raw_length in enumerate(vector):
            length = int(raw_length)
            if length > 0:
                eligible_mask |= 1 << queue_index
            # Forced-in empty targets still have a well-defined secondary
            # weight, although only raw primary values enter certificates.
            weights[queue_index] = (
                self._primary_scale * length + self._priority_bonus[queue_index]
            )
        exact_weights = tuple(weights)

        def solve_opposite(target_index: int, forced_class: int) -> tuple[int, ...]:
            target_bit = 1 << target_index
            if forced_class == 0:
                return self._solve_exact_indices(
                    exact_weights,
                    eligible_mask & ~target_bit,
                    slot=resolved_slot,
                )
            residual_mask = eligible_mask & ~target_bit & ~adjacency[target_index]
            return self._solve_exact_indices(
                exact_weights,
                residual_mask,
                slot=resolved_slot,
                reserved_queue_index=target_index,
            )

        return assemble_exact_gap_certificates(
            catalog=catalog,
            q_len=vector,
            production_decision=production_decision,
            target_queue_ids=target_queue_ids,
            solve_opposite_class=solve_opposite,
        )

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        checked = super().validate_service_decision(decision, q_len)
        catalog, _priority, adjacency = self._compiled()
        canonical = checked.canonical_for(catalog)

        selected_mask = 0
        for queue_id in canonical.selected_queue_ids:
            queue_index = catalog.index_of(queue_id)
            conflicting = adjacency[queue_index] & selected_mask
            if conflicting:
                conflicting_index = (conflicting & -conflicting).bit_length() - 1
                raise ScheduleError(
                    "service decision violates a declared pairwise conflict",
                    context={
                        "queue_id": queue_id,
                        "conflicts_with": catalog.queue_id_at(conflicting_index),
                    },
                )
            selected_mask |= 1 << queue_index
        return canonical


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> ConflictGraphMaxWeightScheduler:
    """Factory used by the scheduler registry."""

    return ConflictGraphMaxWeightScheduler(params=params)


__all__ = ["ConflictGraphMaxWeightScheduler", "build_scheduler"]
