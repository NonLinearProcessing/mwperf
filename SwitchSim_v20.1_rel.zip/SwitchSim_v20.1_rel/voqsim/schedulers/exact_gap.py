"""Exact forced-class MaxWeight certificates.

The five exact MaxWeight schedulers use this module to assemble and validate
topology-neutral certificates around their constraint-specific restricted
solves.  Certificate objectives are always the unencoded primary objective
``sum(q_j s_j)``.  Lexicographic priority weights may select a unique optimum,
but never enter ``v0``, ``v1``, ``gap``, or ``theta``.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from numbers import Integral
from typing import Any, Protocol, runtime_checkable

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import QueueId


def _exact_nonnegative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an exact integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be nonnegative", context={"value": result})
    return result


@dataclass(frozen=True, slots=True)
class ExactGapCertificate:
    """Exact full-constraint class values for one target and queue state."""

    queue_id: QueueId
    backlog: int
    selected_class: int
    production_value: int
    v0: int
    v1: int

    def __post_init__(self) -> None:
        queue_id = normalize_queue_id(self.queue_id)
        backlog = _exact_nonnegative_int(self.backlog, name="backlog")
        if isinstance(self.selected_class, bool) or not isinstance(self.selected_class, Integral):
            raise ValidationError(
                "selected_class must be the integer 0 or 1",
                context={"value": self.selected_class},
            )
        selected_class = int(self.selected_class)
        if selected_class not in (0, 1):
            raise ValidationError(
                "selected_class must be the integer 0 or 1",
                context={"value": selected_class},
            )
        production_value = _exact_nonnegative_int(
            self.production_value,
            name="production_value",
        )
        v0 = _exact_nonnegative_int(self.v0, name="v0")
        v1 = _exact_nonnegative_int(self.v1, name="v1")
        selected_value = v1 if selected_class else v0
        if selected_value != production_value:
            raise ScheduleError(
                "selected forced class value disagrees with the production objective",
                context={
                    "queue_id": queue_id,
                    "selected_class": selected_class,
                    "production_value": production_value,
                    "selected_value": selected_value,
                },
            )
        if backlog == 0 and selected_class != 0:
            raise ScheduleError(
                "an empty target cannot belong to the public production service decision",
                context={"queue_id": queue_id},
            )
        gap = v1 - v0
        theta = backlog - gap
        if theta < 0:
            raise ScheduleError(
                "exact forced-class values violate downward closure",
                context={
                    "queue_id": queue_id,
                    "backlog": backlog,
                    "v0": v0,
                    "v1": v1,
                    "theta": theta,
                },
            )
        if backlog > 0 and gap > 0 and selected_class != 1:
            raise ScheduleError(
                "positive exact gap requires target service",
                context={"queue_id": queue_id, "gap": gap},
            )
        if backlog > 0 and gap < 0 and selected_class != 0:
            raise ScheduleError(
                "negative exact gap forbids target service",
                context={"queue_id": queue_id, "gap": gap},
            )

        object.__setattr__(self, "queue_id", queue_id)
        object.__setattr__(self, "backlog", backlog)
        object.__setattr__(self, "selected_class", selected_class)
        object.__setattr__(self, "production_value", production_value)
        object.__setattr__(self, "v0", v0)
        object.__setattr__(self, "v1", v1)

    @property
    def gap(self) -> int:
        return self.v1 - self.v0

    @property
    def theta(self) -> int:
        return self.backlog - self.gap


@runtime_checkable
class ExactClassValueScheduler(Protocol):
    """Scheduler interface consumed by simulator and weighted-sampler probes."""

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]: ...


RestrictedSolve = Callable[[int, int], Iterable[int]]


def assemble_exact_gap_certificates(
    *,
    catalog: QueueCatalog,
    q_len: np.ndarray,
    production_decision: ServiceDecision,
    target_queue_ids: Sequence[QueueId],
    solve_opposite_class: RestrictedSolve,
) -> tuple[ExactGapCertificate, ...]:
    """Build certificates using one opposite-class solve per target.

    ``solve_opposite_class(target_index, forced_class)`` returns an internal
    feasible schedule as dense queue indices.  A forced class-1 result must
    contain its target even when that target has zero backlog; this is a
    value-only reservation and is never converted to a public service request.
    Every other selected index must have positive backlog.
    """

    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    vector = np.asarray(q_len)
    if vector.ndim != 1 or vector.shape != (catalog.n_queues,):
        raise ValidationError(
            "queue lengths must align with the queue catalog",
            context={"shape": tuple(vector.shape), "n_queues": catalog.n_queues},
        )
    if vector.dtype.kind not in {"i", "u"}:
        raise ValidationError("queue lengths must contain exact integers")
    if vector.size and int(vector.min()) < 0:
        raise ValidationError("queue lengths must be nonnegative")
    if not isinstance(production_decision, ServiceDecision):
        raise ValidationError(
            "production_decision must be a ServiceDecision",
            context={"value_type": type(production_decision).__name__},
        )
    if isinstance(target_queue_ids, (str, bytes, bytearray)):
        raise ValidationError("target_queue_ids must be a sequence of queue identifiers")
    try:
        raw_targets = tuple(target_queue_ids)
    except TypeError as exc:
        raise ValidationError("target_queue_ids must be an iterable") from exc

    selected_indices: set[int] = set()
    for queue_id in production_decision.selected_queue_ids:
        queue_index = catalog.index_of(queue_id)
        if queue_index in selected_indices:  # defensive; ServiceDecision rejects this first
            raise ScheduleError("production decision contains a duplicate queue")
        if int(vector[queue_index]) <= 0:
            raise ScheduleError(
                "production decision selected an empty queue",
                context={"queue_id": queue_id},
            )
        selected_indices.add(queue_index)
    production_value = sum(int(vector[index]) for index in selected_indices)

    target_indices: list[int] = []
    target_ids: list[QueueId] = []
    seen_targets: set[int] = set()
    for position, raw_target in enumerate(raw_targets):
        target_index = catalog.index_of(raw_target)
        if target_index in seen_targets:
            raise ValidationError(
                "exact gap targets must be unique",
                context={"position": position, "queue_id": catalog.queue_id_at(target_index)},
            )
        seen_targets.add(target_index)
        target_indices.append(target_index)
        target_ids.append(catalog.queue_id_at(target_index))

    certificates: list[ExactGapCertificate] = []
    for queue_id, target_index in zip(target_ids, target_indices, strict=True):
        selected_class = int(target_index in selected_indices)
        opposite_class = 1 - selected_class
        try:
            raw_restricted = tuple(solve_opposite_class(target_index, opposite_class))
        except (ScheduleError, ValidationError):
            raise
        except Exception as exc:
            raise ScheduleError(
                "exact opposite-class optimization failed",
                context={"queue_id": queue_id, "forced_class": opposite_class},
            ) from exc

        restricted_indices: set[int] = set()
        for position, raw_index in enumerate(raw_restricted):
            if isinstance(raw_index, bool) or not isinstance(raw_index, Integral):
                raise ScheduleError(
                    "restricted exact solve returned a non-integer queue index",
                    context={"queue_id": queue_id, "position": position, "value": raw_index},
                )
            index = int(raw_index)
            if not 0 <= index < catalog.n_queues:
                raise ScheduleError(
                    "restricted exact solve returned an out-of-domain queue index",
                    context={"queue_id": queue_id, "position": position, "index": index},
                )
            if index in restricted_indices:
                raise ScheduleError(
                    "restricted exact solve returned a duplicate queue index",
                    context={"queue_id": queue_id, "index": index},
                )
            if index != target_index and int(vector[index]) <= 0:
                raise ScheduleError(
                    "restricted exact solve selected a non-target empty queue",
                    context={"queue_id": queue_id, "selected_index": index},
                )
            restricted_indices.add(index)

        target_is_included = target_index in restricted_indices
        if target_is_included != bool(opposite_class):
            raise ScheduleError(
                "restricted exact solve violated the forced target class",
                context={
                    "queue_id": queue_id,
                    "forced_class": opposite_class,
                    "target_included": target_is_included,
                },
            )
        opposite_value = sum(int(vector[index]) for index in restricted_indices)
        v0 = production_value if selected_class == 0 else opposite_value
        v1 = production_value if selected_class == 1 else opposite_value
        certificates.append(
            ExactGapCertificate(
                queue_id=queue_id,
                backlog=int(vector[target_index]),
                selected_class=selected_class,
                production_value=production_value,
                v0=v0,
                v1=v1,
            )
        )
    return tuple(certificates)


__all__ = [
    "ExactGapCertificate",
    "ExactClassValueScheduler",
    "assemble_exact_gap_certificates",
]
