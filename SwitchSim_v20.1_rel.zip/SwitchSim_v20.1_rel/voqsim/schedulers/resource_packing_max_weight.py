"""Exact MaxWeight scheduling under fixed nonnegative resource capacities.

Queue ``q`` owns a nonnegative integer demand column.  A binary service
decision is feasible exactly when the sum of selected columns is no larger
than the declared capacity vector, componentwise.  Selected queues receive
one packet of service; resource demand does not change the unit-service rule.

The implementation follows Section 3.5 of
``MaxWeight_Algorithms_and_Arrivals.md``.  Static disjoint resource-support
components are compiled at domain binding.  Each slot is then solved exactly
by a memoized include/exclude recurrence, with infeasible-column pruning,
zero-demand elimination, an all-fit shortcut, and a safe objective upper
bound.  Python integers preserve the common exact lexicographic objective.

The algorithm is exponential in the worst case.  ``max_search_states`` can
place an explicit deterministic limit on nontrivial cache-miss states.  A
limit or interpreter recursion-depth failure raises :class:`ScheduleError`;
this scheduler never substitutes a heuristic or returns a partial incumbent.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import JSONValue, QueueId
from .base import QueueSchedulerBase, coerce_queue_vector, validate_scheduler_slot
from .domain import normalize_service_family
from .exact_gap import ExactGapCertificate, assemble_exact_gap_certificates
from .exact_priority import canonical_priority, exact_lex_weights


_SERVICE_FAMILY = "resource_packing"
_ALLOWED_PARAM_KEYS = frozenset({"constraint", "priority", "max_search_states"})
_CONSTRAINT_KEYS = frozenset({"resources", "capacity", "demands"})
_DEMAND_KEYS = frozenset({"queue_id", "demand"})

ResourceId = int | str
_DeclaredDemand = tuple[QueueId, tuple[int, ...]]
_Component = tuple[tuple[int, ...], tuple[int, ...]]


def _typed_id_sort_key(value: int | str) -> tuple[int, int | str]:
    """Total order that never compares integer and string identifiers."""

    return (0, value) if isinstance(value, int) else (1, value)


def _require_list(value: Any, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(
            f"{name} must be a list",
            context={"value_type": type(value).__name__},
        )
    return list(value)


def _nonnegative_integer(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(
            f"{name} must be a nonnegative integer",
            context={"value": value},
        )
    result = int(value)
    if result < 0:
        raise ValidationError(
            f"{name} must be >= 0",
            context={"value": result},
        )
    return result


def _normalize_max_search_states(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(
            "max_search_states must be a positive integer or null",
            context={"value": value},
        )
    limit = int(value)
    if limit < 1:
        raise ValidationError(
            "max_search_states must be >= 1 or null",
            context={"value": limit},
        )
    return limit


def _normalize_declared_priority(value: Any) -> tuple[QueueId, ...] | None:
    if value is None:
        return None
    raw = _require_list(value, name="scheduler.params.priority")
    priority = tuple(
        normalize_queue_id(queue_id, name=f"scheduler.params.priority[{index}]")
        for index, queue_id in enumerate(raw)
    )
    positions: dict[QueueId, int] = {}
    for index, queue_id in enumerate(priority):
        if queue_id in positions:
            raise ValidationError(
                "scheduler.params.priority contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": positions[queue_id],
                    "duplicate_index": index,
                },
            )
        positions[queue_id] = index
    return priority


def _normalize_constraint(
    value: Any,
) -> tuple[dict[str, JSONValue], tuple[_DeclaredDemand, ...]]:
    if not isinstance(value, Mapping):
        raise ValidationError(
            "resource_packing_max_weight requires a constraint mapping",
            context={"value_type": type(value).__name__},
        )
    fields = set(value)
    unknown = sorted(fields - _CONSTRAINT_KEYS)
    missing = sorted(_CONSTRAINT_KEYS - fields)
    if unknown or missing:
        raise ValidationError(
            "resource-packing constraint must contain exactly resources, capacity, and demands",
            context={"unknown_keys": unknown, "missing_keys": missing},
        )

    raw_resources = _require_list(
        value["resources"], name="scheduler.params.constraint.resources"
    )
    resources: list[ResourceId] = []
    resource_positions: dict[ResourceId, int] = {}
    for index, raw_resource in enumerate(raw_resources):
        resource = normalize_queue_id(
            raw_resource,
            name=f"scheduler.params.constraint.resources[{index}]",
        )
        if resource in resource_positions:
            raise ValidationError(
                "resource-packing constraint contains a duplicate resource identifier",
                context={
                    "resource": resource,
                    "first_index": resource_positions[resource],
                    "duplicate_index": index,
                },
            )
        resource_positions[resource] = index
        resources.append(resource)

    raw_capacity = _require_list(
        value["capacity"], name="scheduler.params.constraint.capacity"
    )
    if len(raw_capacity) != len(resources):
        raise ValidationError(
            "resource capacity length must equal the number of resources",
            context={
                "capacity_length": len(raw_capacity),
                "resource_count": len(resources),
            },
        )
    capacity = tuple(
        _nonnegative_integer(
            item, name=f"scheduler.params.constraint.capacity[{index}]"
        )
        for index, item in enumerate(raw_capacity)
    )

    raw_demands = _require_list(
        value["demands"], name="scheduler.params.constraint.demands"
    )
    demands: list[_DeclaredDemand] = []
    queue_positions: dict[QueueId, int] = {}
    for row_index, raw_row in enumerate(raw_demands):
        if not isinstance(raw_row, Mapping):
            raise ValidationError(
                "each resource demand row must be a mapping",
                context={
                    "demand_index": row_index,
                    "value_type": type(raw_row).__name__,
                },
            )
        row_fields = set(raw_row)
        unknown_row = sorted(row_fields - _DEMAND_KEYS)
        missing_row = sorted(_DEMAND_KEYS - row_fields)
        if unknown_row or missing_row:
            raise ValidationError(
                "each resource demand row must contain exactly queue_id and demand",
                context={
                    "demand_index": row_index,
                    "unknown_keys": unknown_row,
                    "missing_keys": missing_row,
                },
            )
        queue_id = normalize_queue_id(
            raw_row["queue_id"],
            name=f"scheduler.params.constraint.demands[{row_index}].queue_id",
        )
        if queue_id in queue_positions:
            raise ValidationError(
                "resource-packing constraint contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": queue_positions[queue_id],
                    "duplicate_index": row_index,
                },
            )
        raw_demand = _require_list(
            raw_row["demand"],
            name=f"scheduler.params.constraint.demands[{row_index}].demand",
        )
        if len(raw_demand) != len(resources):
            raise ValidationError(
                "queue demand length must equal the number of resources",
                context={
                    "queue_id": queue_id,
                    "demand_length": len(raw_demand),
                    "resource_count": len(resources),
                },
            )
        demand = tuple(
            _nonnegative_integer(
                item,
                name=(
                    f"scheduler.params.constraint.demands[{row_index}]"
                    f".demand[{resource_index}]"
                ),
            )
            for resource_index, item in enumerate(raw_demand)
        )
        queue_positions[queue_id] = row_index
        demands.append((queue_id, demand))

    # Resource list order is representational.  Canonicalize it and remap
    # every associated vector by the same permutation.
    permutation = tuple(
        sorted(range(len(resources)), key=lambda index: _typed_id_sort_key(resources[index]))
    )
    canonical_resources = tuple(resources[index] for index in permutation)
    canonical_capacity = tuple(capacity[index] for index in permutation)
    remapped_demands = [
        (
            queue_id,
            tuple(demand[index] for index in permutation),
        )
        for queue_id, demand in demands
    ]
    canonical_demands = tuple(
        sorted(remapped_demands, key=lambda item: _typed_id_sort_key(item[0]))
    )

    canonical: dict[str, JSONValue] = {
        "resources": list(canonical_resources),
        "capacity": list(canonical_capacity),
        "demands": [
            {"queue_id": queue_id, "demand": list(demand)}
            for queue_id, demand in canonical_demands
        ],
    }
    return canonical, canonical_demands


def _compile_components(
    demand_by_index: tuple[tuple[int, ...], ...],
    capacity: tuple[int, ...],
) -> tuple[tuple[int, ...], tuple[int, ...], tuple[_Component, ...]]:
    """Compile free, impossible, and disjoint positive-support components."""

    free: list[int] = []
    impossible: list[int] = []
    positive: list[int] = []
    supports: dict[int, tuple[int, ...]] = {}
    for queue_index, demand in enumerate(demand_by_index):
        if not any(demand):
            free.append(queue_index)
            continue
        if any(amount > capacity[index] for index, amount in enumerate(demand)):
            impossible.append(queue_index)
            continue
        positive.append(queue_index)
        supports[queue_index] = tuple(index for index, amount in enumerate(demand) if amount)

    # Union queue columns that share a positive-demand resource.  Components
    # then have disjoint supports and therefore independent capacity budgets.
    parent = {queue_index: queue_index for queue_index in positive}

    def find(queue_index: int) -> int:
        root = queue_index
        while parent[root] != root:
            root = parent[root]
        while parent[queue_index] != queue_index:
            next_index = parent[queue_index]
            parent[queue_index] = root
            queue_index = next_index
        return root

    def union(first: int, second: int) -> None:
        first_root = find(first)
        second_root = find(second)
        if first_root == second_root:
            return
        if first_root < second_root:
            parent[second_root] = first_root
        else:
            parent[first_root] = second_root

    first_by_resource: dict[int, int] = {}
    for queue_index in positive:
        for resource_index in supports[queue_index]:
            first = first_by_resource.setdefault(resource_index, queue_index)
            union(first, queue_index)

    queues_by_root: dict[int, list[int]] = {}
    for queue_index in positive:
        queues_by_root.setdefault(find(queue_index), []).append(queue_index)
    components: list[_Component] = []
    for queue_indices in queues_by_root.values():
        queue_tuple = tuple(sorted(queue_indices))
        resource_tuple = tuple(
            sorted({resource for queue_index in queue_tuple for resource in supports[queue_index]})
        )
        components.append((queue_tuple, resource_tuple))
    components.sort(key=lambda component: component[0][0])
    return tuple(free), tuple(impossible), tuple(components)


class ResourcePackingMaxWeightScheduler(QueueSchedulerBase):
    """Exact lexicographic MaxWeight for fixed-resource binary packing."""

    __slots__ = (
        "_constraint",
        "_declared_demands",
        "_declared_priority",
        "_max_search_states",
        "_priority",
        "_primary_scale",
        "_priority_bonus",
        "_capacity",
        "_demand_by_index",
        "_free_queue_indices",
        "_impossible_queue_indices",
        "_components",
        "_individually_serviceable",
    )

    optimizer_id = "binary_packing_memo_exact"
    service_family = _SERVICE_FAMILY

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        try:
            super().__init__(params=params)
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "resource_packing_max_weight params must contain finite JSON-safe values",
                context={"error": str(exc)},
            ) from exc

        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "resource_packing_max_weight received unsupported scheduler params",
                context={"unknown_keys": unknown, "allowed": sorted(_ALLOWED_PARAM_KEYS)},
            )
        if "constraint" not in self.params:
            raise ValidationError(
                "resource_packing_max_weight requires scheduler.params.constraint"
            )

        constraint, demands = _normalize_constraint(self.params["constraint"])
        priority = _normalize_declared_priority(self.params.get("priority"))
        max_search_states = _normalize_max_search_states(
            self.params.get("max_search_states")
        )
        self._params = {
            "constraint": constraint,
            "priority": None if priority is None else list(priority),
            "max_search_states": max_search_states,
        }
        self._constraint = constraint
        self._declared_demands = demands
        self._declared_priority = priority
        self._max_search_states = max_search_states
        self._priority: tuple[QueueId, ...] | None = None
        self._primary_scale = 0
        self._priority_bonus: tuple[int, ...] = ()
        self._capacity: tuple[int, ...] = tuple(constraint["capacity"])
        self._demand_by_index: tuple[tuple[int, ...], ...] | None = None
        self._free_queue_indices: tuple[int, ...] = ()
        self._impossible_queue_indices: tuple[int, ...] = ()
        self._components: tuple[_Component, ...] = ()
        self._individually_serviceable: tuple[QueueId, ...] | None = None

    @property
    def name(self) -> str:
        return "resource_packing_max_weight"

    @property
    def priority(self) -> tuple[QueueId, ...] | None:
        return self._priority if self._priority is not None else self._declared_priority

    @property
    def constraint(self) -> Mapping[str, JSONValue]:
        return self._constraint

    @property
    def max_search_states(self) -> int | None:
        return self._max_search_states

    @property
    def individually_serviceable_queue_ids(self) -> tuple[QueueId, ...]:
        if self._individually_serviceable is None:
            raise ValidationError(
                "resource_packing_max_weight must be configured before querying serviceability"
            )
        return self._individually_serviceable

    def state_dict(self) -> dict[str, JSONValue]:
        return {"scheduler_kind": self.name, "optimizer_id": self.optimizer_id}

    def validate_for_domain(self, domain: Any) -> None:
        super().validate_for_domain(domain)
        family = normalize_service_family(domain.service_family)
        if family != _SERVICE_FAMILY:
            raise ValidationError(
                "resource_packing_max_weight requires the resource_packing service family",
                context={"service_family": family},
            )

        catalog: QueueCatalog = domain.queue_catalog
        catalog_ids = set(catalog.queue_ids)
        declared_ids = {queue_id for queue_id, _demand in self._declared_demands}
        if declared_ids != catalog_ids:
            raise ValidationError(
                "resource-packing constraint must define exactly one demand column for every catalog queue",
                context={
                    "missing_queue_ids": [
                        queue_id for queue_id in catalog.queue_ids if queue_id not in declared_ids
                    ],
                    "out_of_domain_queue_ids": [
                        queue_id
                        for queue_id, _demand in self._declared_demands
                        if queue_id not in catalog_ids
                    ],
                },
            )
        canonical_priority(catalog, self._declared_priority)

    def configure_for_domain(self, domain: Any) -> None:
        # Compile into locals first so a failed bind cannot leave partial state.
        self.validate_for_domain(domain)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )
        catalog: QueueCatalog = domain.queue_catalog
        demand_by_id = dict(self._declared_demands)
        demand_by_index = tuple(demand_by_id[queue_id] for queue_id in catalog.queue_ids)
        capacity = tuple(self._constraint["capacity"])
        priority = canonical_priority(catalog, self._declared_priority)
        priority_bonus = exact_lex_weights((0,) * catalog.n_queues, catalog, priority)
        free, impossible, components = _compile_components(demand_by_index, capacity)
        impossible_set = set(impossible)
        serviceable = tuple(
            queue_id
            for queue_index, queue_id in enumerate(catalog.queue_ids)
            if queue_index not in impossible_set
        )

        super().configure_for_domain(domain)
        self._priority = priority
        self._primary_scale = 1 << catalog.n_queues
        self._priority_bonus = priority_bonus
        self._capacity = capacity
        self._demand_by_index = demand_by_index
        self._free_queue_indices = free
        self._impossible_queue_indices = impossible
        self._components = components
        self._individually_serviceable = serviceable

    def _compiled(
        self,
    ) -> tuple[
        QueueCatalog,
        tuple[tuple[int, ...], ...],
        tuple[int, ...],
        tuple[int, ...],
        tuple[_Component, ...],
    ]:
        domain = self.scheduler_domain
        if domain is None or self._priority is None or self._demand_by_index is None:
            raise ValidationError(
                "resource_packing_max_weight must be configured for a service domain before use"
            )
        return (
            domain.queue_catalog,
            self._demand_by_index,
            self._capacity,
            self._free_queue_indices,
            self._components,
        )

    def _solve_component(
        self,
        queue_indices: tuple[int, ...],
        resource_indices: tuple[int, ...],
        demand_by_index: tuple[tuple[int, ...], ...],
        capacity: tuple[int, ...],
        eligible: frozenset[int],
        weights: tuple[int, ...],
        search_counter: list[int],
        slot: int,
    ) -> tuple[int, ...]:
        eligible_globals = tuple(
            queue_index for queue_index in queue_indices if queue_index in eligible
        )
        if not eligible_globals:
            return ()

        local_demands = tuple(
            tuple(demand_by_index[queue_index][resource] for resource in resource_indices)
            for queue_index in eligible_globals
        )
        remaining_initial = tuple(capacity[resource] for resource in resource_indices)
        local_weights = tuple(weights[queue_index] for queue_index in eligible_globals)
        full_mask = (1 << len(eligible_globals)) - 1
        memo: dict[tuple[int, tuple[int, ...]], tuple[int, int]] = {}

        def prune(mask: int, remaining: tuple[int, ...]) -> int:
            result = mask
            cursor = mask
            while cursor:
                bit = cursor & -cursor
                local_index = bit.bit_length() - 1
                if any(
                    amount > available
                    for amount, available in zip(
                        local_demands[local_index], remaining, strict=True
                    )
                ):
                    result ^= bit
                cursor ^= bit
            return result

        def solve(mask: int, remaining: tuple[int, ...]) -> tuple[int, int]:
            mask = prune(mask, remaining)
            if not mask:
                return (0, 0)
            key = (mask, remaining)
            cached = memo.get(key)
            if cached is not None:
                return cached

            search_counter[0] += 1
            if (
                self._max_search_states is not None
                and search_counter[0] > self._max_search_states
            ):
                raise ScheduleError(
                    "resource-packing exact search exceeded max_search_states",
                    context={
                        "scheduler": self.name,
                        "slot": slot,
                        "max_search_states": self._max_search_states,
                        "states_explored": search_counter[0],
                    },
                )

            candidate_locals: list[int] = []
            aggregate = [0] * len(remaining)
            cursor = mask
            while cursor:
                bit = cursor & -cursor
                local_index = bit.bit_length() - 1
                candidate_locals.append(local_index)
                for resource, amount in enumerate(local_demands[local_index]):
                    aggregate[resource] += amount
                cursor ^= bit
            if all(
                used <= available
                for used, available in zip(aggregate, remaining, strict=True)
            ):
                result = (
                    sum(local_weights[index] for index in candidate_locals),
                    mask,
                )
                memo[key] = result
                return result

            # Branch first on the most constrained/high-value remaining item.
            # Every key is built only from immutable integers, so this order is
            # deterministic for a fixed queue vector and canonical config.
            branch_index = max(
                candidate_locals,
                key=lambda index: (
                    sum(
                        amount * (1 + len(remaining)) // (1 + available)
                        for amount, available in zip(
                            local_demands[index], remaining, strict=True
                        )
                    ),
                    local_weights[index],
                    -eligible_globals[index],
                ),
            )
            branch_bit = 1 << branch_index
            rest = mask ^ branch_bit
            taken_remaining = tuple(
                available - amount
                for available, amount in zip(
                    remaining, local_demands[branch_index], strict=True
                )
            )
            taken_score, taken_mask = solve(rest, taken_remaining)
            taken = (
                taken_score + local_weights[branch_index],
                taken_mask | branch_bit,
            )

            # Ignoring capacities gives a valid upper bound for the skip arm.
            # If it cannot improve on ``taken``, pruning it is exact.
            skip_upper_bound = sum(
                local_weights[index]
                for index in candidate_locals
                if index != branch_index
            )
            if taken[0] >= skip_upper_bound:
                result = taken
            else:
                skipped = solve(rest, remaining)
                result = taken if taken[0] > skipped[0] else skipped
            memo[key] = result
            return result

        _score, selected_mask = solve(full_mask, remaining_initial)
        return tuple(
            eligible_globals[local_index]
            for local_index in range(len(eligible_globals))
            if selected_mask & (1 << local_index)
        )

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, resolved_slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog, _demand_by_index, capacity, _free_indices, components = self._compiled()
        if not np.any(vector):
            return ServiceDecision.empty()

        eligible = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )
        has_active_component = any(
            any(queue_index in eligible for queue_index in queue_indices)
            for queue_indices, _resource_indices in components
        )
        # Preserve the cheap all-free/all-impossible production path: the core
        # does not inspect weights unless a positive-demand component is live.
        weights = (
            tuple(
                self._primary_scale * int(length) + bonus
                for length, bonus in zip(vector, self._priority_bonus, strict=True)
            )
            if has_active_component
            else (0,) * catalog.n_queues
        )
        selected_indices = self._solve_exact_indices(
            weights,
            eligible,
            capacity=capacity,
            slot=resolved_slot,
        )
        return ServiceDecision.from_indices(selected_indices, catalog)

    def _solve_exact_indices(
        self,
        weights: tuple[int, ...],
        eligible: frozenset[int],
        *,
        capacity: tuple[int, ...],
        slot: int,
        reserved_queue_index: int | None = None,
    ) -> tuple[int, ...]:
        """Run the trusted exact packing decomposition for one class."""

        _catalog, demand_by_index, _base_capacity, free_indices, components = self._compiled()
        selected_indices = [
            queue_index for queue_index in free_indices if queue_index in eligible
        ]
        active_components = tuple(
            (queue_indices, resource_indices)
            for queue_indices, resource_indices in components
            if any(queue_index in eligible for queue_index in queue_indices)
        )
        search_counter = [0]
        try:
            for queue_indices, resource_indices in active_components:
                selected_indices.extend(
                    self._solve_component(
                        queue_indices,
                        resource_indices,
                        demand_by_index,
                        capacity,
                        eligible,
                        weights,
                        search_counter,
                        slot,
                    )
                )
        except RecursionError as exc:
            raise ScheduleError(
                "resource-packing exact search exceeded the Python recursion limit",
                context={
                    "scheduler": self.name,
                    "slot": slot,
                    "states_explored": search_counter[0],
                    "max_search_states": self._max_search_states,
                },
            ) from exc

        if reserved_queue_index is not None:
            selected_indices.append(reserved_queue_index)
        selected_indices.sort()
        return tuple(selected_indices)

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]:
        """Return exact full-packing forced-class values for targets."""

        catalog, demand_by_index, capacity, _free, _components = self._compiled()
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        resolved_slot = validate_scheduler_slot(slot)
        impossible = set(self._impossible_queue_indices)
        for queue_id in target_queue_ids:
            target_index = catalog.index_of(queue_id)
            if target_index in impossible:
                raise ValidationError(
                    "exact gap target is not individually feasible under resource capacities",
                    context={
                        "queue_id": catalog.queue_id_at(target_index),
                        "demand": list(demand_by_index[target_index]),
                        "capacity": list(capacity),
                    },
                )

        weights = tuple(
            self._primary_scale * int(length) + bonus
            for length, bonus in zip(vector, self._priority_bonus, strict=True)
        )
        positive = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )

        def solve_opposite(target_index: int, forced_class: int) -> tuple[int, ...]:
            residual = positive - {target_index}
            if forced_class == 0:
                return self._solve_exact_indices(
                    weights,
                    residual,
                    capacity=capacity,
                    slot=resolved_slot,
                )

            target_demand = demand_by_index[target_index]
            residual_capacity = tuple(
                available - amount
                for available, amount in zip(capacity, target_demand, strict=True)
            )
            if any(value < 0 for value in residual_capacity):  # guarded above
                raise ScheduleError(
                    "forced-in resource-packing target is infeasible",
                    context={"queue_id": catalog.queue_id_at(target_index)},
                )
            return self._solve_exact_indices(
                weights,
                residual,
                capacity=residual_capacity,
                slot=resolved_slot,
                reserved_queue_index=target_index,
            )

        return assemble_exact_gap_certificates(
            catalog=catalog,
            q_len=vector,
            production_decision=production_decision,
            target_queue_ids=target_queue_ids,
            solve_opposite_class=solve_opposite,
        )

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        checked = super().validate_service_decision(decision, q_len)
        catalog, demand_by_index, capacity, _free, _components = self._compiled()
        canonical = checked.canonical_for(catalog)
        used = [0] * len(capacity)
        for queue_id in canonical.selected_queue_ids:
            queue_index = catalog.index_of(queue_id)
            for resource_index, amount in enumerate(demand_by_index[queue_index]):
                used[resource_index] += amount
        for resource_index, (amount, available) in enumerate(
            zip(used, capacity, strict=True)
        ):
            if amount > available:
                resources = self._constraint["resources"]
                raise ScheduleError(
                    "service decision exceeds a resource capacity",
                    context={
                        "resource": resources[resource_index],
                        "used": amount,
                        "capacity": available,
                    },
                )
        return canonical


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> ResourcePackingMaxWeightScheduler:
    """Factory used by the scheduler registry."""

    return ResourcePackingMaxWeightScheduler(params=params)


__all__ = ["ResourcePackingMaxWeightScheduler", "build_scheduler"]
