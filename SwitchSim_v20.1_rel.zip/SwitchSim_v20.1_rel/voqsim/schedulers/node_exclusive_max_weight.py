"""Exact MaxWeight scheduling for node-exclusive labeled links.

Each queue owns one labeled undirected link in a declared general graph. A
feasible decision selects at most one incident link at every vertex. Static
topology and exact lexicographic bonuses are compiled at domain binding; each
slot reduces eligible parallel labels to their unique best representative and
passes the resulting simple graph to the vendored exact Edmonds-Blossom core.

The implementation follows Section 3.2 of
``MaxWeight_Algorithms_and_Arrivals.md``. Scores are Python integers, so the
one-solve lexicographic encoding remains exact for catalogs of arbitrary size.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import JSONValue, QueueId
from ._blossom import _maximum_weight_matching_prevalidated
from .base import QueueSchedulerBase, coerce_queue_vector, validate_scheduler_slot
from .domain import normalize_service_family
from .exact_gap import ExactGapCertificate, assemble_exact_gap_certificates
from .exact_priority import canonical_priority, exact_lex_weights


_SERVICE_FAMILY = "node_exclusive_matching"
_ALLOWED_PARAM_KEYS = frozenset({"constraint", "priority"})
_CONSTRAINT_KEYS = frozenset({"vertices", "links"})
_LINK_KEYS = frozenset({"queue_id", "u", "v"})

VertexLabel = int | str
_Link = tuple[QueueId, VertexLabel, VertexLabel]


def _label_sort_key(value: int | str) -> tuple[int, int | str]:
    """Provide one total order for the disjoint integer/string label types."""

    return (0, value) if isinstance(value, int) else (1, value)


def _require_list(value: Any, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(
            f"{name} must be a list",
            context={"value_type": type(value).__name__},
        )
    return list(value)


def _normalize_vertex_label(value: Any, *, name: str) -> VertexLabel:
    if isinstance(value, bool):
        raise ValidationError(
            f"{name} must be a nonnegative integer or nonempty string",
            context={"value": value},
        )
    if isinstance(value, Integral):
        vertex = int(value)
        if vertex < 0:
            raise ValidationError(
                f"{name} integer must be >= 0",
                context={"value": vertex},
            )
        return vertex
    if isinstance(value, str):
        if not value or not value.strip():
            raise ValidationError(
                f"{name} string must be nonempty",
                context={"value": value},
            )
        if value != value.strip():
            raise ValidationError(
                f"{name} must not contain leading or trailing whitespace",
                context={"value": value},
            )
        return value
    raise ValidationError(
        f"{name} must be a nonnegative integer or nonempty string",
        context={"value": value, "value_type": type(value).__name__},
    )


def _normalize_vertices(value: Any) -> tuple[VertexLabel, ...]:
    raw_vertices = _require_list(value, name="scheduler.params.constraint.vertices")
    if not raw_vertices:
        raise ValidationError(
            "scheduler.params.constraint.vertices must contain at least one vertex"
        )
    vertices = tuple(
        _normalize_vertex_label(
            raw_vertex,
            name=f"scheduler.params.constraint.vertices[{index}]",
        )
        for index, raw_vertex in enumerate(raw_vertices)
    )
    positions: dict[VertexLabel, int] = {}
    for index, vertex in enumerate(vertices):
        if vertex in positions:
            raise ValidationError(
                "node-exclusive constraint contains a duplicate vertex",
                context={
                    "vertex": vertex,
                    "first_index": positions[vertex],
                    "duplicate_index": index,
                },
            )
        positions[vertex] = index
    return tuple(sorted(vertices, key=_label_sort_key))


def _normalize_constraint(value: Any) -> tuple[dict[str, JSONValue], tuple[_Link, ...]]:
    if not isinstance(value, Mapping):
        raise ValidationError(
            "node_exclusive_max_weight requires a constraint mapping",
            context={"value_type": type(value).__name__},
        )
    fields = set(value)
    unknown = sorted(fields - _CONSTRAINT_KEYS)
    missing = sorted(_CONSTRAINT_KEYS - fields)
    if unknown or missing:
        raise ValidationError(
            "node-exclusive constraint must contain exactly vertices and links",
            context={"unknown_keys": unknown, "missing_keys": missing},
        )

    vertices = _normalize_vertices(value["vertices"])
    vertex_set = set(vertices)
    raw_links = _require_list(
        value["links"],
        name="scheduler.params.constraint.links",
    )
    if not raw_links:
        raise ValidationError(
            "scheduler.params.constraint.links must contain at least one link"
        )

    links: list[_Link] = []
    queue_positions: dict[QueueId, int] = {}
    for link_index, raw_link in enumerate(raw_links):
        if not isinstance(raw_link, Mapping):
            raise ValidationError(
                "each node-exclusive link must be a mapping",
                context={
                    "link_index": link_index,
                    "value_type": type(raw_link).__name__,
                },
            )
        link_fields = set(raw_link)
        unknown_link = sorted(link_fields - _LINK_KEYS)
        missing_link = sorted(_LINK_KEYS - link_fields)
        if unknown_link or missing_link:
            raise ValidationError(
                "each node-exclusive link must contain exactly queue_id, u, and v",
                context={
                    "link_index": link_index,
                    "unknown_keys": unknown_link,
                    "missing_keys": missing_link,
                },
            )

        queue_id = normalize_queue_id(
            raw_link["queue_id"],
            name=f"scheduler.params.constraint.links[{link_index}].queue_id",
        )
        u = _normalize_vertex_label(
            raw_link["u"],
            name=f"scheduler.params.constraint.links[{link_index}].u",
        )
        v = _normalize_vertex_label(
            raw_link["v"],
            name=f"scheduler.params.constraint.links[{link_index}].v",
        )
        if u not in vertex_set:
            raise ValidationError(
                "node-exclusive link references an undeclared vertex",
                context={"link_index": link_index, "endpoint": "u", "vertex": u},
            )
        if v not in vertex_set:
            raise ValidationError(
                "node-exclusive link references an undeclared vertex",
                context={"link_index": link_index, "endpoint": "v", "vertex": v},
            )
        if u == v:
            raise ValidationError(
                "node-exclusive links must have two distinct endpoints",
                context={"link_index": link_index, "queue_id": queue_id, "vertex": u},
            )
        if queue_id in queue_positions:
            raise ValidationError(
                "node-exclusive constraint contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": queue_positions[queue_id],
                    "duplicate_index": link_index,
                },
            )

        # Endpoint order is not physical. Preserve parallel queue labels but
        # canonicalize their shared unordered pair for hashing and reduction.
        if _label_sort_key(v) < _label_sort_key(u):
            u, v = v, u
        queue_positions[queue_id] = link_index
        links.append((queue_id, u, v))

    links.sort(key=lambda link: _label_sort_key(link[0]))
    canonical: dict[str, JSONValue] = {
        "vertices": list(vertices),
        "links": [
            {"queue_id": queue_id, "u": u, "v": v}
            for queue_id, u, v in links
        ],
    }
    return canonical, tuple(links)


def _normalize_declared_priority(value: Any) -> tuple[QueueId, ...] | None:
    if value is None:
        return None
    raw_priority = _require_list(value, name="scheduler.params.priority")
    priority = tuple(
        normalize_queue_id(queue_id, name=f"scheduler.params.priority[{index}]")
        for index, queue_id in enumerate(raw_priority)
    )
    positions: dict[QueueId, int] = {}
    for index, queue_id in enumerate(priority):
        if queue_id in positions:
            raise ValidationError(
                "scheduler.params.priority contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": positions[queue_id],
                    "duplicate_index": index,
                },
            )
        positions[queue_id] = index
    return priority


class NodeExclusiveMaxWeightScheduler(QueueSchedulerBase):
    """Exact optional maximum-weight matching on a declared general graph."""

    __slots__ = (
        "_constraint",
        "_declared_links",
        "_declared_priority",
        "_priority",
        "_primary_scale",
        "_priority_bonus",
        "_vertices",
        "_link_by_queue_id",
        "_vertex_pair_by_index",
        "_parallel_groups",
    )

    optimizer_id = "edmonds_blossom_exact"
    service_family = _SERVICE_FAMILY

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        try:
            super().__init__(params=params)
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "node_exclusive_max_weight params must contain finite JSON-safe values",
                context={"error": str(exc)},
            ) from exc

        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "node_exclusive_max_weight received unsupported scheduler params",
                context={
                    "unknown_keys": unknown,
                    "allowed": sorted(_ALLOWED_PARAM_KEYS),
                },
            )
        if "constraint" not in self.params:
            raise ValidationError(
                "node_exclusive_max_weight requires scheduler.params.constraint"
            )

        constraint, links = _normalize_constraint(self.params["constraint"])
        priority = _normalize_declared_priority(self.params.get("priority"))
        self._params = {
            "constraint": constraint,
            "priority": None if priority is None else list(priority),
        }
        self._constraint = constraint
        self._declared_links = links
        self._declared_priority = priority
        self._priority: tuple[QueueId, ...] | None = None
        self._primary_scale = 0
        self._priority_bonus: tuple[int, ...] = ()
        self._vertices: tuple[VertexLabel, ...] = tuple(constraint["vertices"])
        self._link_by_queue_id: dict[QueueId, tuple[VertexLabel, VertexLabel]] = {}
        self._vertex_pair_by_index: tuple[tuple[int, int], ...] = ()
        self._parallel_groups: tuple[tuple[int, int, tuple[int, ...]], ...] = ()

    @property
    def name(self) -> str:
        return "node_exclusive_max_weight"

    @property
    def priority(self) -> tuple[QueueId, ...] | None:
        return self._priority if self._priority is not None else self._declared_priority

    @property
    def constraint(self) -> Mapping[str, JSONValue]:
        return self._constraint

    def state_dict(self) -> dict[str, JSONValue]:
        return {
            "scheduler_kind": self.name,
            "optimizer_id": self.optimizer_id,
        }

    def validate_for_domain(self, domain: Any) -> None:
        super().validate_for_domain(domain)
        family = normalize_service_family(domain.service_family)
        if family != _SERVICE_FAMILY:
            raise ValidationError(
                "node_exclusive_max_weight requires the node_exclusive_matching service family",
                context={"service_family": family},
            )

        catalog: QueueCatalog = domain.queue_catalog
        catalog_ids = set(catalog.queue_ids)
        declared_ids = {queue_id for queue_id, _u, _v in self._declared_links}
        if declared_ids != catalog_ids:
            raise ValidationError(
                "node-exclusive constraint must define exactly one link for every catalog queue",
                context={
                    "missing_queue_ids": [
                        queue_id
                        for queue_id in catalog.queue_ids
                        if queue_id not in declared_ids
                    ],
                    "out_of_domain_queue_ids": [
                        queue_id
                        for queue_id, _u, _v in self._declared_links
                        if queue_id not in catalog_ids
                    ],
                },
            )
        canonical_priority(catalog, self._declared_priority)

    def configure_for_domain(self, domain: Any) -> None:
        # Compile into locals first. A malformed topology or priority must not
        # leave the scheduler partially bound to a domain.
        self.validate_for_domain(domain)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )

        catalog: QueueCatalog = domain.queue_catalog
        priority = canonical_priority(catalog, self._declared_priority)
        priority_bonus = exact_lex_weights((0,) * catalog.n_queues, catalog, priority)
        vertices = tuple(self._constraint["vertices"])
        vertex_index = {vertex: index for index, vertex in enumerate(vertices)}
        link_by_queue_id = {
            queue_id: (u, v) for queue_id, u, v in self._declared_links
        }
        vertex_pair_by_index = tuple(
            tuple(
                sorted(
                    (
                        vertex_index[link_by_queue_id[queue_id][0]],
                        vertex_index[link_by_queue_id[queue_id][1]],
                    )
                )
            )
            for queue_id in catalog.queue_ids
        )
        grouped: dict[tuple[int, int], list[int]] = {}
        for queue_index, pair in enumerate(vertex_pair_by_index):
            grouped.setdefault(pair, []).append(queue_index)
        parallel_groups = tuple(
            (u, v, tuple(queue_indices))
            for (u, v), queue_indices in sorted(grouped.items())
        )

        super().configure_for_domain(domain)
        self._priority = priority
        self._primary_scale = 1 << catalog.n_queues
        self._priority_bonus = priority_bonus
        self._vertices = vertices
        self._link_by_queue_id = link_by_queue_id
        self._vertex_pair_by_index = vertex_pair_by_index
        self._parallel_groups = parallel_groups

    def _compiled(
        self,
    ) -> tuple[
        QueueCatalog,
        tuple[QueueId, ...],
        tuple[tuple[int, int], ...],
        tuple[tuple[int, int, tuple[int, ...]], ...],
    ]:
        domain = self.scheduler_domain
        if domain is None or self._priority is None or not self._vertex_pair_by_index:
            raise ValidationError(
                "node_exclusive_max_weight must be configured for a service domain before use"
            )
        return (
            domain.queue_catalog,
            self._priority,
            self._vertex_pair_by_index,
            self._parallel_groups,
        )

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog, _priority, _pairs, _parallel_groups = self._compiled()
        if not np.any(vector):
            return ServiceDecision.empty()

        weights = tuple(
            self._primary_scale * int(length) + self._priority_bonus[index]
            for index, length in enumerate(vector)
        )
        eligible = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )
        selected_indices = self._solve_exact_indices(weights, eligible)
        return ServiceDecision.from_indices(selected_indices, catalog)

    def _solve_exact_indices(
        self,
        weights: tuple[int, ...],
        eligible: frozenset[int],
        *,
        reserved_queue_index: int | None = None,
    ) -> tuple[int, ...]:
        """Reduce labels and invoke Blossom for one exact restricted class."""

        _catalog, _priority, pairs, parallel_groups = self._compiled()
        reserved_vertices: frozenset[int]
        if reserved_queue_index is None:
            reserved_vertices = frozenset()
        else:
            reserved_vertices = frozenset(pairs[reserved_queue_index])

        candidate_edges: list[tuple[int, int, int]] = []
        representative_by_pair: dict[tuple[int, int], int] = {}
        for u, v, queue_indices in parallel_groups:
            if u in reserved_vertices or v in reserved_vertices:
                continue
            best_queue_index = -1
            best_weight = -1
            for queue_index in queue_indices:
                if queue_index not in eligible:
                    continue
                weight = weights[queue_index]
                if weight > best_weight:
                    best_weight = weight
                    best_queue_index = queue_index
            if best_queue_index >= 0:
                pair = (u, v)
                candidate_edges.append((u, v, best_weight))
                representative_by_pair[pair] = best_queue_index

        if candidate_edges:
            # Parallel groups are compiled in increasing dense endpoint-pair
            # order; this emits one unique u<v edge per group. Use the trusted
            # core boundary to avoid repeated topology validation.
            matching = _maximum_weight_matching_prevalidated(
                len(self._vertices), candidate_edges
            )
        else:
            matching = ()

        selected_indices: list[int] = []
        used_vertices: set[int] = set()
        for raw_u, raw_v in matching:
            u, v = (raw_u, raw_v) if raw_u < raw_v else (raw_v, raw_u)
            pair = (u, v)
            try:
                queue_index = representative_by_pair[pair]
            except KeyError as exc:  # pragma: no cover - audited optimizer invariant
                raise ScheduleError(
                    "Blossom optimizer returned a structurally absent link",
                    context={"vertex_indices": [u, v]},
                ) from exc
            if u in used_vertices or v in used_vertices:  # pragma: no cover
                raise ScheduleError(
                    "Blossom optimizer returned a node-conflicting matching",
                    context={"vertex_indices": [u, v]},
                )
            used_vertices.add(u)
            used_vertices.add(v)
            selected_indices.append(queue_index)

        if reserved_queue_index is not None:
            selected_indices.append(reserved_queue_index)
        selected_indices.sort()
        return tuple(selected_indices)

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]:
        """Return exact labeled-matching forced-class values for targets."""

        catalog, _priority, _pairs, _parallel_groups = self._compiled()
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        validate_scheduler_slot(slot)
        weights = tuple(
            self._primary_scale * int(length) + self._priority_bonus[index]
            for index, length in enumerate(vector)
        )
        positive = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )

        def solve_opposite(target_index: int, forced_class: int) -> tuple[int, ...]:
            residual = positive - {target_index}
            if forced_class == 0:
                # Only the target label is removed. Parallel labels on the same
                # endpoint pair are reduced again by the trusted core.
                return self._solve_exact_indices(weights, residual)
            return self._solve_exact_indices(
                weights,
                residual,
                reserved_queue_index=target_index,
            )

        return assemble_exact_gap_certificates(
            catalog=catalog,
            q_len=vector,
            production_decision=production_decision,
            target_queue_ids=target_queue_ids,
            solve_opposite_class=solve_opposite,
        )

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        checked = super().validate_service_decision(decision, q_len)
        catalog, _priority, _pairs, _groups = self._compiled()
        canonical = checked.canonical_for(catalog)

        used_vertices: dict[VertexLabel, QueueId] = {}
        for queue_id in canonical.selected_queue_ids:
            try:
                u, v = self._link_by_queue_id[queue_id]
            except KeyError as exc:  # pragma: no cover - common validator guards this
                raise ScheduleError(
                    "scheduler selected a queue outside the node-exclusive constraint",
                    context={"queue_id": queue_id},
                ) from exc
            for vertex in (u, v):
                if vertex in used_vertices:
                    raise ScheduleError(
                        "service decision violates the one-link-per-node constraint",
                        context={
                            "queue_id": queue_id,
                            "vertex": vertex,
                            "conflicts_with": used_vertices[vertex],
                        },
                    )
                used_vertices[vertex] = queue_id
        return canonical


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> NodeExclusiveMaxWeightScheduler:
    """Factory used by the scheduler registry."""

    return NodeExclusiveMaxWeightScheduler(params=params)


__all__ = ["NodeExclusiveMaxWeightScheduler", "build_scheduler"]
