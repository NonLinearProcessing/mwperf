from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from ..errors import ConfigError, ValidationError
from ..types import JSONValue
from .adapter import bind_scheduler_to_domain
from .base import (
    QueueScheduler,
    SchedulerBase,
    SchedulerFactory,
    normalize_scheduler_name,
    normalize_scheduler_params,
)
from .domain import (
    SchedulerCapabilities,
    normalize_service_family,
)
from .conflict_graph_max_weight import ConflictGraphMaxWeightScheduler
from .crossbar_max_weight import CrossbarMaxWeightScheduler
from .interval_max_weight import IntervalMaxWeightScheduler
from .node_exclusive_max_weight import NodeExclusiveMaxWeightScheduler
from .crossbar_islip import CrossbarISlipScheduler
from .crossbar_random_grant_accept import CrossbarRandomGrantAcceptScheduler
from .crossbar_random_greedy_maximal import CrossbarRandomGreedyMaximalScheduler
from .resource_packing_max_weight import ResourcePackingMaxWeightScheduler

_RESERVED_SCHEDULERS = frozenset({
    "crossbar_random_greedy_maximal",
    "crossbar_random_grant_accept",
    "crossbar_islip",
    "crossbar_max_weight",
    "interval_max_weight",
    "node_exclusive_max_weight",
    "conflict_graph_max_weight",
    "resource_packing_max_weight",
})
_AMBIGUOUS_SCHEDULERS = frozenset({"islip"})
_RETIRED_SCHEDULERS = {
    "max_weight": "crossbar_max_weight",
    "maxweight": "crossbar_max_weight",
    "random_maximal": "crossbar_random_greedy_maximal",
    "islip_rga": "crossbar_random_grant_accept",
    "islip_canonical": "crossbar_islip",
    "canonical_islip": "crossbar_islip",
}
_REMOVED_SCHEDULERS = frozenset({"round_robin", "roundrobin"})
_REGISTRY: dict[str, SchedulerFactory] = {}
_CLASSES: dict[str, type[SchedulerBase]] = {}
_ALIASES: dict[str, str] = {}
_CAPABILITIES: dict[str, SchedulerCapabilities] = {}


@dataclass(frozen=True, slots=True)
class ResolvedSchedulerSpec:
    """Canonical scheduler identity and constructor-resolved parameters."""

    name: str
    algorithm_id: str
    params: dict[str, JSONValue]
    capabilities: SchedulerCapabilities

    @property
    def service_family(self) -> str | None:
        if len(self.capabilities.service_families) == 1:
            return self.capabilities.service_families[0]
        return None

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "name": self.name,
            "algorithm_id": self.algorithm_id,
            "params": dict(self.params),
            "capabilities": self.capabilities.to_dict(),
        }


def _normalize_aliases(aliases: Iterable[str] | None, *, canonical_name: str) -> tuple[str, ...]:
    if aliases is None:
        return ()
    normalized = tuple(normalize_scheduler_name(alias) for alias in aliases)
    if len(set(normalized)) != len(normalized):
        raise ValidationError("duplicate scheduler aliases are not allowed", context={"aliases": normalized})
    for alias in normalized:
        if alias in _REMOVED_SCHEDULERS:
            raise ValidationError(
                "removed scheduler names cannot be registered as aliases",
                context={"alias": alias, "reason": "policy was pruned"},
            )
        if alias in _RETIRED_SCHEDULERS:
            raise ValidationError(
                "retired scheduler names cannot be registered as aliases",
                context={"alias": alias, "replacement": _RETIRED_SCHEDULERS[alias]},
            )
        if alias == canonical_name:
            raise ValidationError(
                "scheduler alias must differ from the canonical name",
                context={"scheduler": canonical_name, "alias": alias},
            )
        if alias in _AMBIGUOUS_SCHEDULERS:
            raise ValidationError(
                "scheduler alias conflicts with an intentionally ambiguous reserved name",
                context={"scheduler": canonical_name, "alias": alias},
            )
    return normalized


def _coerce_factory(value: Any) -> tuple[SchedulerFactory, type[SchedulerBase] | None]:
    if isinstance(value, type) and issubclass(value, SchedulerBase):
        scheduler_cls = value

        def _factory(params: Mapping[str, JSONValue] | None = None) -> QueueScheduler:
            return scheduler_cls(params=params)

        return _factory, scheduler_cls

    if callable(value):
        return value, None

    raise ValidationError(
        "scheduler factory must be callable or a SchedulerBase subclass",
        context={"value_type": type(value).__name__},
    )


def resolve_scheduler_name(name: str) -> str:
    token = normalize_scheduler_name(name)
    return _ALIASES.get(token, token)


def _raise_ambiguous_scheduler_error(name: str) -> None:
    raise ConfigError(
        "scheduler name is ambiguous; choose the persistent-pointer iSLIP policy "
        "or the distinct randomized grant/accept policy",
        context={
            "scheduler": name,
            "allowed_replacements": ["crossbar_islip", "crossbar_random_grant_accept"],
        },
    )


def register_scheduler(
    name: str,
    factory: SchedulerFactory | type[SchedulerBase],
    *,
    aliases: Iterable[str] | None = None,
    capabilities: SchedulerCapabilities | None = None,
    replace: bool = False,
) -> None:
    requested_name = normalize_scheduler_name(name)
    if requested_name in _REMOVED_SCHEDULERS:
        raise ValidationError(
            "removed scheduler names cannot be registered",
            context={"scheduler": requested_name, "reason": "policy was pruned"},
        )
    if requested_name in _RETIRED_SCHEDULERS:
        raise ValidationError(
            "retired scheduler names cannot be registered",
            context={
                "scheduler": requested_name,
                "replacement": _RETIRED_SCHEDULERS[requested_name],
            },
        )
    # Replacing through an existing alias targets that alias's canonical
    # registration. A replacement must never create an alias-named registry
    # entry whose constructed scheduler advertises a different public name.
    canonical_name = _ALIASES.get(requested_name, requested_name) if replace else requested_name
    if canonical_name in _AMBIGUOUS_SCHEDULERS:
        raise ValidationError(
            "cannot register an intentionally ambiguous scheduler name",
            context={"scheduler": canonical_name},
        )
    existing_registration = canonical_name in _REGISTRY
    existing_aliases = tuple(alias for alias, target in _ALIASES.items() if target == canonical_name)
    effective_aliases = existing_aliases if replace and existing_registration and aliases is None else aliases
    normalized_aliases = _normalize_aliases(effective_aliases, canonical_name=canonical_name)
    factory_fn, scheduler_cls = _coerce_factory(factory)
    if capabilities is None:
        raise ValidationError(
            "scheduler registration requires explicit native capabilities",
            context={"scheduler": canonical_name},
        )
    if not isinstance(capabilities, SchedulerCapabilities):
        raise ValidationError(
            "scheduler capabilities must be a SchedulerCapabilities object",
            context={"scheduler": canonical_name, "value_type": type(capabilities).__name__},
        )

    if (existing_registration or canonical_name in _ALIASES) and not replace:
        raise ConfigError("scheduler name is already registered", context={"scheduler": canonical_name})

    # Validate the complete target namespace before changing any registry
    # table. Aliases already owned by the replaced scheduler are reusable;
    # collisions with every other scheduler remain errors.
    for alias in normalized_aliases:
        registered_directly = alias in _REGISTRY and alias != canonical_name
        alias_owner = _ALIASES.get(alias)
        owned_elsewhere = alias_owner is not None and alias_owner != canonical_name
        if registered_directly or owned_elsewhere:
            raise ConfigError(
                "scheduler alias is already registered",
                context={"scheduler": canonical_name, "alias": alias},
            )

    if replace and existing_registration:
        unregister_scheduler(canonical_name)

    _REGISTRY[canonical_name] = factory_fn
    _CAPABILITIES[canonical_name] = capabilities
    if scheduler_cls is not None:
        _CLASSES[canonical_name] = scheduler_cls
    else:
        _CLASSES.pop(canonical_name, None)
    for alias in normalized_aliases:
        _ALIASES[alias] = canonical_name


def unregister_scheduler(name: str) -> None:
    canonical_name = resolve_scheduler_name(name)
    _REGISTRY.pop(canonical_name, None)
    _CLASSES.pop(canonical_name, None)
    _CAPABILITIES.pop(canonical_name, None)
    aliases_to_remove = [alias for alias, target in _ALIASES.items() if target == canonical_name]
    for alias in aliases_to_remove:
        _ALIASES.pop(alias, None)


def is_scheduler_registered(name: str) -> bool:
    token = resolve_scheduler_name(name)
    if token in _AMBIGUOUS_SCHEDULERS:
        return False
    return token in _REGISTRY


def available_schedulers(*, implemented_only: bool = True) -> tuple[str, ...]:
    if implemented_only:
        return tuple(sorted(_REGISTRY))
    return tuple(sorted(set(_REGISTRY) | set(_RESERVED_SCHEDULERS)))


def get_scheduler_factory(name: str) -> SchedulerFactory:
    canonical_name = resolve_scheduler_name(name)
    if canonical_name in _RETIRED_SCHEDULERS:
        raise ConfigError(
            "scheduler was removed; use the exact replacement",
            context={
                "scheduler": canonical_name,
                "replacement": _RETIRED_SCHEDULERS[canonical_name],
            },
        )
    if canonical_name in _REMOVED_SCHEDULERS:
        raise ConfigError(
            "scheduler was removed without a behaviorally equivalent replacement",
            context={"scheduler": canonical_name, "reason": "policy was pruned"},
        )
    if canonical_name in _AMBIGUOUS_SCHEDULERS:
        _raise_ambiguous_scheduler_error(canonical_name)
    if canonical_name in _REGISTRY:
        return _REGISTRY[canonical_name]
    if canonical_name in _RESERVED_SCHEDULERS:
        raise ConfigError(
            "requested scheduler is reserved by the schema but not implemented in this checkpoint",
            context={"scheduler": canonical_name, "implemented": list(available_schedulers())},
        )
    raise ConfigError(
        "requested scheduler is unknown",
        context={"scheduler": canonical_name, "implemented": list(available_schedulers())},
    )


def scheduler_capabilities(name: str) -> SchedulerCapabilities:
    """Return registry-owned domain compatibility for a scheduler or alias."""

    canonical_name = resolve_scheduler_name(name)
    # Reuse the registry's established unknown/ambiguous diagnostics.
    get_scheduler_factory(canonical_name)
    return _CAPABILITIES[canonical_name]


def scheduler_supports_service(name: str, service_family: str) -> bool:
    return scheduler_capabilities(name).supports(normalize_service_family(service_family))


def scheduler_class_for_name(name: str) -> type[SchedulerBase]:
    canonical_name = resolve_scheduler_name(name)
    if canonical_name in _RETIRED_SCHEDULERS:
        get_scheduler_factory(canonical_name)
    if canonical_name in _AMBIGUOUS_SCHEDULERS:
        _raise_ambiguous_scheduler_error(canonical_name)
    if canonical_name in _CLASSES:
        return _CLASSES[canonical_name]
    if canonical_name in _REGISTRY:
        raise ConfigError(
            "requested scheduler is registered via a factory and has no unique scheduler class",
            context={"scheduler": canonical_name},
        )
    if canonical_name in _RESERVED_SCHEDULERS:
        raise ConfigError(
            "requested scheduler is reserved by the schema but not implemented in this checkpoint",
            context={"scheduler": canonical_name, "implemented": list(available_schedulers())},
        )
    raise ConfigError(
        "requested scheduler is unknown",
        context={"scheduler": canonical_name, "implemented": list(available_schedulers())},
    )


def build_scheduler(name: str, params: Mapping[str, Any] | None = None) -> QueueScheduler:
    factory = get_scheduler_factory(name)
    scheduler = factory(params)
    if not isinstance(scheduler, QueueScheduler):
        raise ValidationError(
            "registered scheduler factory produced an object that does not implement the QueueScheduler protocol",
            context={"scheduler": resolve_scheduler_name(name), "value_type": type(scheduler).__name__},
        )
    canonical_name = resolve_scheduler_name(name)
    emitted_name = normalize_scheduler_name(scheduler.name)
    if emitted_name != canonical_name:
        raise ValidationError(
            "registered scheduler produced an object with a mismatched canonical name",
            context={"registered_name": canonical_name, "scheduler_name": emitted_name},
        )
    return scheduler


def resolve_scheduler_spec(
    name: str,
    params: Mapping[str, Any] | None = None,
) -> ResolvedSchedulerSpec:
    """Resolve aliases and defaults through the scheduler's own constructor."""

    canonical_name = resolve_scheduler_name(name)
    scheduler = build_scheduler(canonical_name, params)
    effective = normalize_scheduler_params(
        getattr(scheduler, "effective_params", scheduler.params)
    )
    return ResolvedSchedulerSpec(
        name=canonical_name,
        algorithm_id=scheduler.algorithm_id,
        params=effective,
        capabilities=scheduler_capabilities(canonical_name),
    )


def canonical_scheduler_config(
    name: str,
    params: Mapping[str, Any] | None = None,
) -> dict[str, JSONValue]:
    spec = resolve_scheduler_spec(name, params)
    return {"name": spec.name, "params": dict(spec.params)}


def build_scheduler_for_domain(
    name: str,
    params: Mapping[str, Any] | None,
    domain: Any,
) -> QueueScheduler:
    """Construct and bind a native queue-vector scheduler to a domain."""

    canonical_name = resolve_scheduler_name(name)
    scheduler = build_scheduler(canonical_name, params)
    return bind_scheduler_to_domain(
        scheduler,
        domain,
        scheduler_capabilities(canonical_name),
    )


register_scheduler(
    "crossbar_random_greedy_maximal",
    CrossbarRandomGreedyMaximalScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("crossbar_matching",)),
)
register_scheduler(
    "crossbar_random_grant_accept",
    CrossbarRandomGrantAcceptScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("crossbar_matching",)),
)
register_scheduler(
    "crossbar_islip",
    CrossbarISlipScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("crossbar_matching",)),
)
register_scheduler(
    "crossbar_max_weight",
    CrossbarMaxWeightScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("crossbar_matching",)),
)
register_scheduler(
    "interval_max_weight",
    IntervalMaxWeightScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("nonoverlapping_intervals",)),
)
register_scheduler(
    "node_exclusive_max_weight",
    NodeExclusiveMaxWeightScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("node_exclusive_matching",)),
)
register_scheduler(
    "conflict_graph_max_weight",
    ConflictGraphMaxWeightScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("pairwise_conflicts",)),
)
register_scheduler(
    "resource_packing_max_weight",
    ResourcePackingMaxWeightScheduler,
    capabilities=SchedulerCapabilities.queue_vector(("resource_packing",)),
)


__all__ = [
    "SchedulerFactory",
    "resolve_scheduler_name",
    "register_scheduler",
    "unregister_scheduler",
    "is_scheduler_registered",
    "available_schedulers",
    "get_scheduler_factory",
    "scheduler_class_for_name",
    "build_scheduler",
    "scheduler_capabilities",
    "scheduler_supports_service",
    "ResolvedSchedulerSpec",
    "resolve_scheduler_spec",
    "canonical_scheduler_config",
    "build_scheduler_for_domain",
]
