"""Bind native queue-vector schedulers to explicit service domains."""

from __future__ import annotations

from typing import Any

from ..errors import ValidationError
from .base import QueueScheduler, QueueSchedulerBase
from .domain import SchedulerCapabilities, require_scheduler_domain


def bind_scheduler_to_domain(
    scheduler: Any,
    domain: Any,
    capabilities: SchedulerCapabilities,
) -> QueueScheduler:
    """Validate compatibility and bind one native scheduler transactionally."""

    checked_domain = require_scheduler_domain(domain)
    if not capabilities.supports(checked_domain.service_family):
        raise ValidationError(
            "scheduler is incompatible with the configured service family",
            context={
                "scheduler": getattr(scheduler, "name", type(scheduler).__name__),
                "service_family": checked_domain.service_family,
                "supported_service_families": list(capabilities.service_families),
            },
        )
    if capabilities.input_kind != "queue_vector" or capabilities.output_kind != "service_decision":
        raise ValidationError(
            "scheduler advertises a removed non-native interface",
            context=capabilities.to_dict(),
        )
    if not isinstance(scheduler, QueueScheduler):
        raise ValidationError(
            "queue-vector scheduler does not implement the QueueScheduler protocol",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        )
    if (
        checked_domain.service_family != "unconstrained"
        and isinstance(scheduler, QueueSchedulerBase)
        and type(scheduler).validate_service_decision
        is QueueSchedulerBase.validate_service_decision
    ):
        raise ValidationError(
            "constraint-specific queue scheduler must override validate_service_decision",
            context={
                "scheduler": getattr(scheduler, "name", type(scheduler).__name__),
                "service_family": checked_domain.service_family,
            },
        )
    configure = getattr(scheduler, "configure_for_domain", None)
    if not callable(configure):
        raise ValidationError(
            "queue-vector scheduler does not implement configure_for_domain",
            context={"scheduler": getattr(scheduler, "name", type(scheduler).__name__)},
        )
    configure(checked_domain)
    return scheduler


__all__ = ["bind_scheduler_to_domain"]
