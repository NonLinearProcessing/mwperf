"""Persistent-pointer iSLIP on a declared sparse/rectangular crossbar."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ValidationError
from ..queues import ServiceDecision
from ..types import JSONValue
from ._crossbar_heuristic import CompiledCrossbarTopology, CrossbarHeuristicBase


_ALLOWED_PARAM_KEYS = frozenset(
    {
        "constraint",
        "iterations",
        "initial_grant_pointers",
        "initial_accept_pointers",
    }
)


def _positive_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 1:
        raise ValidationError(
            f"{name} must be >= 1",
            context={"value": result, "minimum": 1},
        )
    return result


def _pointer_sequence(value: Any, *, name: str) -> tuple[int, ...] | None:
    if value is None:
        return None
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(f"{name} must be a list of integers")
    normalized: list[int] = []
    for index, item in enumerate(value):
        if isinstance(item, bool) or not isinstance(item, Integral):
            raise ValidationError(
                f"{name}[{index}] must be an integer",
                context={"value": item},
            )
        pointer = int(item)
        if pointer < 0:
            raise ValidationError(
                f"{name}[{index}] must be >= 0",
                context={"value": pointer},
            )
        normalized.append(pointer)
    return tuple(normalized)


class CrossbarISlipScheduler(CrossbarHeuristicBase):
    """iSLIP with persistent grant/accept pointers and first-iteration updates."""

    __slots__ = (
        "_iterations",
        "_initial_grant_pointers_cfg",
        "_initial_accept_pointers_cfg",
        "_n_inputs",
        "_n_outputs",
        "_grant_pointers",
        "_accept_pointers",
    )

    algorithm_id = "persistent_pointer_islip"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "crossbar_islip received unsupported scheduler params",
                context={"unknown_keys": unknown, "allowed": sorted(_ALLOWED_PARAM_KEYS)},
            )
        self._iterations = _positive_int(
            self.params.get("iterations", 1),
            name="scheduler.params.iterations",
        )
        self._initial_grant_pointers_cfg = _pointer_sequence(
            self.params.get("initial_grant_pointers"),
            name="scheduler.params.initial_grant_pointers",
        )
        self._initial_accept_pointers_cfg = _pointer_sequence(
            self.params.get("initial_accept_pointers"),
            name="scheduler.params.initial_accept_pointers",
        )
        canonical: dict[str, JSONValue] = {"iterations": self._iterations}
        if self.declared_constraint is not None:
            canonical["constraint"] = self.declared_constraint
        if self._initial_grant_pointers_cfg is not None:
            canonical["initial_grant_pointers"] = list(self._initial_grant_pointers_cfg)
        if self._initial_accept_pointers_cfg is not None:
            canonical["initial_accept_pointers"] = list(self._initial_accept_pointers_cfg)
        self._params = canonical

        self._n_inputs: int | None = None
        self._n_outputs: int | None = None
        self._grant_pointers: list[int] | None = None
        self._accept_pointers: list[int] | None = None

    @property
    def name(self) -> str:
        return "crossbar_islip"

    @property
    def iterations(self) -> int:
        return self._iterations

    def _initial_pointers(
        self,
        topology: CompiledCrossbarTopology,
    ) -> tuple[list[int], list[int]]:
        if self._iterations > min(topology.n_inputs, topology.n_outputs):
            raise ValidationError(
                "crossbar_islip iterations must not exceed the smaller port side",
                context={
                    "iterations": self._iterations,
                    "n_inputs": topology.n_inputs,
                    "n_outputs": topology.n_outputs,
                },
            )
        grant_cfg = self._initial_grant_pointers_cfg
        accept_cfg = self._initial_accept_pointers_cfg
        if grant_cfg is not None and len(grant_cfg) != topology.n_outputs:
            raise ValidationError(
                "scheduler.params.initial_grant_pointers length must equal the output count",
                context={"length": len(grant_cfg), "n_outputs": topology.n_outputs},
            )
        if accept_cfg is not None and len(accept_cfg) != topology.n_inputs:
            raise ValidationError(
                "scheduler.params.initial_accept_pointers length must equal the input count",
                context={"length": len(accept_cfg), "n_inputs": topology.n_inputs},
            )
        grant = list(grant_cfg) if grant_cfg is not None else [0] * topology.n_outputs
        accept = list(accept_cfg) if accept_cfg is not None else [0] * topology.n_inputs
        for output_rank, pointer in enumerate(grant):
            if pointer >= topology.n_inputs:
                raise ValidationError(
                    "scheduler.params.initial_grant_pointers contains an out-of-range input rank",
                    context={
                        "output_rank": output_rank,
                        "pointer": pointer,
                        "n_inputs": topology.n_inputs,
                    },
                )
        for input_rank, pointer in enumerate(accept):
            if pointer >= topology.n_outputs:
                raise ValidationError(
                    "scheduler.params.initial_accept_pointers contains an out-of-range output rank",
                    context={
                        "input_rank": input_rank,
                        "pointer": pointer,
                        "n_outputs": topology.n_outputs,
                    },
                )
        return grant, accept

    def configure_for_domain(self, domain: Any) -> None:
        topology = self.topology_for_domain(domain)
        grant, accept = self._initial_pointers(topology)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )
        if self._n_inputs is not None and (
            self._n_inputs != topology.n_inputs or self._n_outputs != topology.n_outputs
        ):
            raise ValidationError(
                "crossbar_islip cannot be rebound to different crossbar dimensions",
                context={
                    "configured_inputs": self._n_inputs,
                    "configured_outputs": self._n_outputs,
                    "observed_inputs": topology.n_inputs,
                    "observed_outputs": topology.n_outputs,
                },
            )
        super().configure_for_domain(domain)
        self._n_inputs = topology.n_inputs
        self._n_outputs = topology.n_outputs
        if self._grant_pointers is None or self._accept_pointers is None:
            self._grant_pointers = grant
            self._accept_pointers = accept

    def reset(self) -> None:
        if self._topology is None:
            self._grant_pointers = None
            self._accept_pointers = None
            return
        grant, accept = self._initial_pointers(self._topology)
        self._grant_pointers = grant
        self._accept_pointers = accept

    @staticmethod
    def _rr_select(candidates: Sequence[int], pointer: int, modulus: int) -> int:
        candidate_set = set(candidates)
        for offset in range(modulus):
            probe = (pointer + offset) % modulus
            if probe in candidate_set:
                return probe
        raise ValidationError("iSLIP arbitration received an empty candidate set")

    def state_dict(self) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "scheduler_kind": self.name,
            "algorithm_id": self.algorithm_id,
            "iterations": self._iterations,
        }
        if self._grant_pointers is not None and self._accept_pointers is not None:
            payload["grant_pointers"] = list(self._grant_pointers)
            payload["accept_pointers"] = list(self._accept_pointers)
        return payload

    def select_service(
        self,
        q_len,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        topology = self.topology
        catalog = self.scheduler_domain.queue_catalog
        assert self._grant_pointers is not None
        assert self._accept_pointers is not None
        if not np.any(vector > 0):
            return ServiceDecision.empty()

        unmatched_inputs = list(range(topology.n_inputs))
        unmatched_outputs = list(range(topology.n_outputs))
        selected: list[int] = []
        first_iteration_matches: list[tuple[int, int]] = []
        for iteration in range(self._iterations):
            if not unmatched_inputs or not unmatched_outputs:
                break
            grants: dict[int, int] = {}
            for output_rank in unmatched_outputs:
                requesters = [
                    input_rank
                    for input_rank in unmatched_inputs
                    if (
                        (queue_index := topology.queue_index_by_pair.get(
                            (input_rank, output_rank)
                        ))
                        is not None
                        and int(vector[queue_index]) > 0
                    )
                ]
                if requesters:
                    grants[output_rank] = self._rr_select(
                        requesters,
                        self._grant_pointers[output_rank],
                        topology.n_inputs,
                    )

            accepts: dict[int, int] = {}
            for input_rank in unmatched_inputs:
                granted_outputs = [
                    output_rank
                    for output_rank in unmatched_outputs
                    if grants.get(output_rank) == input_rank
                ]
                if granted_outputs:
                    accepts[input_rank] = self._rr_select(
                        granted_outputs,
                        self._accept_pointers[input_rank],
                        topology.n_outputs,
                    )

            if not accepts:
                break
            matched_inputs = sorted(accepts)
            matched_outputs = sorted(accepts.values())
            matches = [(input_rank, accepts[input_rank]) for input_rank in matched_inputs]
            if iteration == 0:
                first_iteration_matches = list(matches)
            selected.extend(
                topology.queue_index_by_pair[pair] for pair in matches
            )
            matched_input_set = set(matched_inputs)
            matched_output_set = set(matched_outputs)
            unmatched_inputs = [
                value for value in unmatched_inputs if value not in matched_input_set
            ]
            unmatched_outputs = [
                value for value in unmatched_outputs if value not in matched_output_set
            ]

        for input_rank, output_rank in first_iteration_matches:
            self._grant_pointers[output_rank] = (input_rank + 1) % topology.n_inputs
            self._accept_pointers[input_rank] = (output_rank + 1) % topology.n_outputs

        selected.sort()
        return ServiceDecision.from_indices(selected, catalog)


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> CrossbarISlipScheduler:
    return CrossbarISlipScheduler(params=params)


__all__ = ["CrossbarISlipScheduler", "build_scheduler"]
