"""Random-permutation greedy maximal scheduling on a declared crossbar."""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np

from ..errors import ValidationError
from ..queues import ServiceDecision
from ..types import JSONValue
from ._crossbar_heuristic import CrossbarHeuristicBase


_ALLOWED_PARAM_KEYS = frozenset({"constraint"})


class CrossbarRandomGreedyMaximalScheduler(CrossbarHeuristicBase):
    """Randomly permute live edges, then greedily construct a maximal matching.

    The random distribution is over permutations of edges, not uniformly over
    maximal matchings.  Candidate edges are ordered by canonical input rank and
    then output rank before applying the seeded permutation.
    """

    algorithm_id = "random_permutation_greedy_maximal"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "crossbar_random_greedy_maximal received unsupported scheduler params",
                context={"unknown_keys": unknown, "allowed": sorted(_ALLOWED_PARAM_KEYS)},
            )
        canonical: dict[str, JSONValue] = {}
        if self.declared_constraint is not None:
            canonical["constraint"] = self.declared_constraint
        self._params = canonical

    @property
    def name(self) -> str:
        return "crossbar_random_greedy_maximal"

    def state_dict(self) -> dict[str, JSONValue]:
        return {"scheduler_kind": self.name, "algorithm_id": self.algorithm_id}

    def select_service(
        self,
        q_len,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, rng = self.validate_queue_select_inputs(q_len, slot, rng)
        topology = self.topology
        catalog = self.scheduler_domain.queue_catalog
        candidates = tuple(
            queue_index
            for queue_index in topology.operational_queue_indices
            if int(vector[queue_index]) > 0
        )
        if not candidates:
            return ServiceDecision.empty()

        used_inputs: set[int] = set()
        used_outputs: set[int] = set()
        selected: list[int] = []
        for candidate_position in rng.permutation(len(candidates)).tolist():
            queue_index = candidates[int(candidate_position)]
            input_rank = topology.input_rank_by_queue[queue_index]
            output_rank = topology.output_rank_by_queue[queue_index]
            if input_rank in used_inputs or output_rank in used_outputs:
                continue
            selected.append(queue_index)
            used_inputs.add(input_rank)
            used_outputs.add(output_rank)
            if (
                len(used_inputs) == topology.n_inputs
                or len(used_outputs) == topology.n_outputs
            ):
                break
        selected.sort()
        return ServiceDecision.from_indices(selected, catalog)


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> CrossbarRandomGreedyMaximalScheduler:
    return CrossbarRandomGreedyMaximalScheduler(params=params)


__all__ = ["CrossbarRandomGreedyMaximalScheduler", "build_scheduler"]
