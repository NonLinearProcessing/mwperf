"""Exact integer weights for deterministic MaxWeight tie breaking.

The constraint-specific schedulers operate on dense queue vectors, while
configuration and telemetry use stable :class:`~voqsim.queues.QueueCatalog`
identifiers.  This module is the single translation point for a declared
queue-priority permutation and the exact one-solve objective from Section 2
of ``MaxWeight_Algorithms_and_Arrivals.md``.

No floating-point perturbation is used.  Python's arbitrary-precision
integers preserve both the primary MaxWeight objective and every secondary
priority bit for catalogs of any size.
"""

from __future__ import annotations

from collections.abc import Mapping
from numbers import Integral
from typing import Any

from ..errors import ValidationError
from ..queues import QueueCatalog
from ..types import QueueId


def _require_catalog(value: Any) -> QueueCatalog:
    if not isinstance(value, QueueCatalog):
        raise ValidationError(
            "catalog must be a QueueCatalog",
            context={"value_type": type(value).__name__},
        )
    return value


def canonical_priority(
    catalog: QueueCatalog,
    priority: Any = None,
) -> tuple[QueueId, ...]:
    """Return a strict full permutation of ``catalog`` queue identifiers.

    ``None`` selects catalog order.  An explicit iterable must contain every
    catalog queue exactly once.  Values are returned using the catalog's
    canonical identifier objects, so integer-like inputs cannot introduce a
    second representation of the same queue.
    """

    resolved_catalog = _require_catalog(catalog)
    if priority is None:
        return resolved_catalog.queue_ids
    if isinstance(priority, (str, bytes, bytearray)) or isinstance(priority, Mapping):
        raise ValidationError(
            "priority must be an iterable containing every queue identifier exactly once",
            context={"value_type": type(priority).__name__},
        )
    try:
        raw_priority = tuple(priority)
    except TypeError as exc:
        raise ValidationError(
            "priority must be an iterable containing every queue identifier exactly once",
            context={"value_type": type(priority).__name__},
        ) from exc

    canonical: list[QueueId] = []
    seen: dict[QueueId, int] = {}
    for rank, raw_queue_id in enumerate(raw_priority):
        try:
            queue_index = resolved_catalog.index_of(raw_queue_id)
        except ValidationError as exc:
            raise ValidationError(
                "priority contains a queue identifier outside the catalog",
                context={"priority_index": rank, "queue_id": raw_queue_id},
            ) from exc
        queue_id = resolved_catalog.queue_id_at(queue_index)
        if queue_id in seen:
            raise ValidationError(
                "priority contains a duplicate queue identifier",
                context={
                    "queue_id": queue_id,
                    "first_index": seen[queue_id],
                    "duplicate_index": rank,
                },
            )
        seen[queue_id] = rank
        canonical.append(queue_id)

    if len(canonical) != resolved_catalog.n_queues:
        missing = [queue_id for queue_id in resolved_catalog.queue_ids if queue_id not in seen]
        raise ValidationError(
            "priority must be a full permutation of the queue catalog",
            context={
                "length": len(canonical),
                "n_queues": resolved_catalog.n_queues,
                "missing_queue_ids": missing,
            },
        )
    return tuple(canonical)


def _canonical_queue_lengths(q_len: Any, catalog: QueueCatalog) -> tuple[int, ...]:
    if isinstance(q_len, (str, bytes, bytearray)) or isinstance(q_len, Mapping):
        raise ValidationError(
            "queue lengths must be a one-dimensional iterable in catalog order",
            context={"value_type": type(q_len).__name__},
        )
    try:
        raw_lengths = tuple(q_len)
    except TypeError as exc:
        raise ValidationError(
            "queue lengths must be a one-dimensional iterable in catalog order",
            context={"value_type": type(q_len).__name__},
        ) from exc
    if len(raw_lengths) != catalog.n_queues:
        raise ValidationError(
            "queue-length vector has the wrong length",
            context={"length": len(raw_lengths), "expected_size": catalog.n_queues},
        )

    lengths: list[int] = []
    for queue_index, raw_length in enumerate(raw_lengths):
        if isinstance(raw_length, bool) or not isinstance(raw_length, Integral):
            raise ValidationError(
                "queue lengths must contain nonnegative integers",
                context={"queue_index": queue_index, "value": raw_length},
            )
        length = int(raw_length)
        if length < 0:
            raise ValidationError(
                "queue lengths must contain nonnegative integers",
                context={"queue_index": queue_index, "value": length},
            )
        lengths.append(length)
    return tuple(lengths)


def exact_lex_weights(
    q_len: Any,
    catalog: QueueCatalog,
    priority: Any = None,
) -> tuple[int, ...]:
    """Return exact composite MaxWeight weights in catalog order.

    For ``m`` queues, queue ``priority[j]`` receives

    ``2**m * q_len[queue] + 2**(m - 1 - j)``.

    The secondary sum is at most ``2**m - 1``.  Consequently a one-unit
    primary-weight improvement always dominates the complete secondary term,
    and among primary maximizers the unique largest secondary binary number
    is precisely the lexicographically largest schedule in priority order.

    Empty queues intentionally receive their priority weight too.  Feasible
    schedulers must exclude them from selection, as required by the MaxWeight
    model; changing their objective to zero here would weaken that boundary.
    Queue occupancies and returned weights are arbitrary-precision integers.
    """

    resolved_catalog = _require_catalog(catalog)
    queue_lengths = _canonical_queue_lengths(q_len, resolved_catalog)
    resolved_priority = canonical_priority(resolved_catalog, priority)

    n_queues = resolved_catalog.n_queues
    primary_scale = 1 << n_queues
    weights = [primary_scale * length for length in queue_lengths]
    for rank, queue_id in enumerate(resolved_priority):
        queue_index = resolved_catalog.index_of(queue_id)
        weights[queue_index] += 1 << (n_queues - 1 - rank)
    return tuple(weights)


__all__ = ["canonical_priority", "exact_lex_weights"]
