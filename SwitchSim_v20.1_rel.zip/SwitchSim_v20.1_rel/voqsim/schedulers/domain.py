from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from numbers import Integral
from types import MappingProxyType
from typing import Any, Literal, Protocol, runtime_checkable

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision
from ..types import JSONValue, Matching, QueueId, VOQKey
from ..utils import normalize_for_json
from .base import normalize_scheduler_name


SchedulerInputKind = Literal["queue_vector"]
SchedulerOutputKind = Literal["service_decision"]


def normalize_service_family(value: Any, *, name: str = "service family") -> str:
    """Normalize a service-constraint family identifier.

    Constraint family names deliberately use the same conservative token rules
    as scheduler names.  The registry stores only canonical tokens so config
    validation, runtime binding, and artifact hashing cannot disagree because
    one path accepted a spelling alias that another path did not.
    """

    return normalize_scheduler_name(value, name=name)


@dataclass(frozen=True, slots=True)
class SchedulerCapabilities:
    """Static scheduler/domain compatibility advertised by the registry.

    Schema 4 has one native scheduler API: queue vectors in and
    :class:`ServiceDecision` objects out. Scheduler constructors must place
    their canonical physical feasible-set definition in
    ``effective_params['constraint']`` unless the service family is
    ``unconstrained``. Optimizer and tie-breaking controls belong outside that
    mapping.
    """

    input_kind: SchedulerInputKind
    output_kind: SchedulerOutputKind
    service_families: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.input_kind != "queue_vector":
            raise ValidationError(
                "scheduler capability input_kind is invalid",
                context={"input_kind": self.input_kind},
            )
        if self.output_kind != "service_decision":
            raise ValidationError(
                "scheduler capability output_kind is invalid",
                context={"output_kind": self.output_kind},
            )
        if not self.service_families:
            raise ValidationError("scheduler capabilities require at least one service family")

        normalized = tuple(
            normalize_service_family(value, name="scheduler capability service family")
            for value in self.service_families
        )
        if len(set(normalized)) != len(normalized):
            raise ValidationError(
                "scheduler capability service families must be unique",
                context={"service_families": list(normalized)},
            )
        object.__setattr__(self, "service_families", normalized)

    @classmethod
    def queue_vector(
        cls,
        service_families: Sequence[str],
    ) -> "SchedulerCapabilities":
        return cls(
            input_kind="queue_vector",
            output_kind="service_decision",
            service_families=tuple(service_families),
        )

    def supports(self, service_family: str) -> bool:
        return normalize_service_family(service_family) in self.service_families

    @property
    def native_service_decision(self) -> bool:
        return self.output_kind == "service_decision"

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "input_kind": self.input_kind,
            "output_kind": self.output_kind,
            "service_families": list(self.service_families),
        }


UNCONSTRAINED_QUEUE_CAPABILITIES = SchedulerCapabilities.queue_vector(("unconstrained",))


@runtime_checkable
class SchedulerDomain(Protocol):
    """Minimal service-domain interface consumed by generalized schedulers."""

    @property
    def service_family(self) -> str: ...

    @property
    def queue_catalog(self) -> QueueCatalog: ...


def require_scheduler_domain(value: Any) -> SchedulerDomain:
    if not isinstance(value, SchedulerDomain):
        raise ValidationError(
            "scheduler domain must expose service_family and queue_catalog",
            context={"value_type": type(value).__name__},
        )
    if not isinstance(value.queue_catalog, QueueCatalog):
        raise ValidationError(
            "scheduler domain queue_catalog must be a QueueCatalog",
            context={"value_type": type(value.queue_catalog).__name__},
        )
    normalize_service_family(value.service_family)
    return value


@dataclass(frozen=True, slots=True)
class QueueSchedulerDomain:
    """Concrete topology-neutral scheduler domain.

    Patch 1 uses this class for test schedulers and as the stable interface
    boundary between the kernel and future constraint-specific scheduler
    modules.  ``metadata`` is descriptive only; feasibility remains owned by
    the scheduler module named by ``service_family``.
    """

    queue_catalog: QueueCatalog
    service_family: str = "unconstrained"
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.queue_catalog, QueueCatalog):
            raise ValidationError(
                "queue_catalog must be a QueueCatalog",
                context={"value_type": type(self.queue_catalog).__name__},
            )
        object.__setattr__(self, "service_family", normalize_service_family(self.service_family))
        normalized_metadata: dict[str, JSONValue] = {}
        if not isinstance(self.metadata, Mapping):
            raise ValidationError(
                "scheduler domain metadata must be a mapping",
                context={"value_type": type(self.metadata).__name__},
            )
        for key, value in self.metadata.items():
            if not isinstance(key, str):
                raise ValidationError(
                    "scheduler domain metadata keys must be strings",
                    context={"key": key, "key_type": type(key).__name__},
                )
            normalized_metadata[key] = normalize_for_json(value)
        object.__setattr__(self, "metadata", MappingProxyType(dict(sorted(normalized_metadata.items()))))

    @property
    def queue_ids(self) -> tuple[QueueId, ...]:
        return self.queue_catalog.queue_ids

    @property
    def n_queues(self) -> int:
        return self.queue_catalog.n_queues

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.service_family,
            "queue_ids": list(self.queue_ids),
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class CrossbarSchedulerDomain:
    """Full-square compatibility domain for migration and parity tests.

    Canonical schema-v4 execution uses :class:`QueueSchedulerDomain` with an
    explicit crossbar constraint. This type remains only where an old
    full-square queue catalog must be interpreted without changing the five
    exact optimizer implementations or their parity fixtures.
    """

    queue_catalog: QueueCatalog
    n_ports: int
    service_family: str = field(default="crossbar_matching", init=False)
    _edge_by_index: tuple[VOQKey, ...] = field(init=False, repr=False)
    _flat_index_by_queue: np.ndarray = field(init=False, repr=False, compare=False)
    _is_dense_row_major: bool = field(init=False, repr=False)
    _queue_id_by_edge: Mapping[VOQKey, QueueId] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.queue_catalog, QueueCatalog):
            raise ValidationError(
                "queue_catalog must be a QueueCatalog",
                context={"value_type": type(self.queue_catalog).__name__},
            )
        if isinstance(self.n_ports, bool) or not isinstance(self.n_ports, Integral):
            raise ValidationError("n_ports must be an integer", context={"value": self.n_ports})
        n_ports = int(self.n_ports)
        if n_ports < 1:
            raise ValidationError("n_ports must be >= 1", context={"value": n_ports})
        object.__setattr__(self, "n_ports", n_ports)

        edge_by_index: list[VOQKey] = []
        queue_id_by_edge: dict[VOQKey, QueueId] = {}
        for queue_id in self.queue_catalog.queue_ids:
            edge = self.queue_catalog.legacy_voq_for(queue_id)
            if edge is None:
                raise ValidationError(
                    "crossbar scheduler domain requires legacy_voq metadata for every queue",
                    context={"queue_id": queue_id},
                )
            src_port, dst_port = edge
            if src_port < 0 or src_port >= n_ports or dst_port < 0 or dst_port >= n_ports:
                raise ValidationError(
                    "queue legacy_voq lies outside the crossbar",
                    context={"queue_id": queue_id, "legacy_voq": list(edge), "n_ports": n_ports},
                )
            if edge in queue_id_by_edge:
                raise ValidationError(
                    "crossbar scheduler domain cannot map two queues to one VOQ",
                    context={
                        "legacy_voq": list(edge),
                        "first_queue_id": queue_id_by_edge[edge],
                        "second_queue_id": queue_id,
                    },
                )
            edge_by_index.append(edge)
            queue_id_by_edge[edge] = queue_id

        object.__setattr__(self, "_edge_by_index", tuple(edge_by_index))
        flat_indices = np.fromiter(
            (src_port * n_ports + dst_port for src_port, dst_port in edge_by_index),
            dtype=np.intp,
            count=len(edge_by_index),
        )
        flat_indices.flags.writeable = False
        object.__setattr__(self, "_flat_index_by_queue", flat_indices)
        object.__setattr__(
            self,
            "_is_dense_row_major",
            len(edge_by_index) == n_ports * n_ports
            and all(flat_index == index for index, flat_index in enumerate(flat_indices.tolist())),
        )
        object.__setattr__(self, "_queue_id_by_edge", MappingProxyType(queue_id_by_edge))

    @classmethod
    def legacy_crossbar(cls, n_ports: int) -> "CrossbarSchedulerDomain":
        return cls(queue_catalog=QueueCatalog.legacy_crossbar(n_ports), n_ports=n_ports)

    @property
    def queue_ids(self) -> tuple[QueueId, ...]:
        return self.queue_catalog.queue_ids

    @property
    def n_queues(self) -> int:
        return self.queue_catalog.n_queues

    @property
    def edge_by_index(self) -> tuple[VOQKey, ...]:
        return self._edge_by_index

    def matrix_from_queue_lengths(self, queue_lengths: np.ndarray) -> np.ndarray:
        if queue_lengths.ndim != 1 or queue_lengths.shape[0] != self.n_queues:
            raise ValidationError(
                "queue-length vector does not match the crossbar queue catalog",
                context={
                    "shape": tuple(int(value) for value in queue_lengths.shape),
                    "n_queues": self.n_queues,
                },
            )
        # Compatibility-only conversion used by pre-v4 analysis fixtures.
        if self._is_dense_row_major:
            return np.array(queue_lengths.reshape((self.n_ports, self.n_ports)), dtype=np.int64, copy=True)
        matrix = np.zeros((self.n_ports, self.n_ports), dtype=np.int64)
        matrix.reshape(-1)[self._flat_index_by_queue] = queue_lengths
        return matrix

    def queue_ids_from_matching(self, matching: Matching) -> tuple[QueueId, ...]:
        selected: list[QueueId] = []
        for edge in matching:
            try:
                selected.append(self._queue_id_by_edge[edge])
            except KeyError as exc:
                raise ScheduleError(
                    "compatibility matching references a VOQ absent from the queue catalog",
                    context={"legacy_voq": list(edge)},
                ) from exc
        return tuple(selected)

    def service_decision_from_matching(self, matching: Matching) -> ServiceDecision:
        return ServiceDecision(selected_queue_ids=self.queue_ids_from_matching(matching))

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.service_family,
            "n_ports": self.n_ports,
            "queue_edges": [
                {"queue_id": queue_id, "legacy_voq": list(edge)}
                for queue_id, edge in zip(self.queue_ids, self._edge_by_index, strict=True)
            ],
        }


def coerce_crossbar_scheduler_domain(value: Any) -> CrossbarSchedulerDomain:
    if isinstance(value, CrossbarSchedulerDomain):
        return value
    catalog = getattr(value, "queue_catalog", None)
    n_ports = getattr(value, "n_ports", None)
    if isinstance(catalog, QueueCatalog) and n_ports is not None:
        return CrossbarSchedulerDomain(queue_catalog=catalog, n_ports=n_ports)
    raise ValidationError(
        "full-square compatibility conversion requires a CrossbarSchedulerDomain",
        context={"value_type": type(value).__name__},
    )


__all__ = [
    "SchedulerInputKind",
    "SchedulerOutputKind",
    "normalize_service_family",
    "SchedulerCapabilities",
    "UNCONSTRAINED_QUEUE_CAPABILITIES",
    "SchedulerDomain",
    "require_scheduler_domain",
    "QueueSchedulerDomain",
    "CrossbarSchedulerDomain",
    "coerce_crossbar_scheduler_domain",
]
