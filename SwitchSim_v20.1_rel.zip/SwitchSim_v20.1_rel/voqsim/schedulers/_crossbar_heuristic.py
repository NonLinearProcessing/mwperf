"""Shared sparse/rectangular crossbar domain for heuristic schedulers.

The exact MaxWeight scheduler owns the canonical public constraint grammar.
The heuristic schedulers deliberately reuse that compiler, then derive a
separate operational ordering by canonical input rank followed by canonical
output rank.  Queue-catalog order and queue-ID sort order therefore cannot
silently change arbitration or seeded random decisions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..errors import ScheduleError, ValidationError
from ..queues import ServiceDecision
from ..types import JSONValue, QueueId
from .base import QueueSchedulerBase
from .crossbar_max_weight import PortLabel, _Edge, _normalize_constraint
from .domain import QueueSchedulerDomain, normalize_service_family


_SERVICE_FAMILY = "crossbar_matching"


@dataclass(frozen=True, slots=True)
class CompiledCrossbarTopology:
    """Canonical bipartite topology plus algorithm-facing dense ranks."""

    constraint: dict[str, JSONValue]
    inputs: tuple[PortLabel, ...]
    outputs: tuple[PortLabel, ...]
    input_rank_by_queue: tuple[int, ...]
    output_rank_by_queue: tuple[int, ...]
    queue_index_by_pair: dict[tuple[int, int], int]
    operational_queue_indices: tuple[int, ...]

    @property
    def n_inputs(self) -> int:
        return len(self.inputs)

    @property
    def n_outputs(self) -> int:
        return len(self.outputs)


def compile_crossbar_topology(
    *,
    domain: QueueSchedulerDomain,
    declared_constraint: dict[str, JSONValue] | None,
    declared_edges: tuple[_Edge, ...],
    scheduler_name: str,
) -> CompiledCrossbarTopology:
    """Validate and compile one scheduler/domain combination transactionally."""

    if not isinstance(domain, QueueSchedulerDomain):
        raise ValidationError(
            f"{scheduler_name} requires the canonical queue scheduler domain",
            context={"value_type": type(domain).__name__},
        )
    family = normalize_service_family(domain.service_family)
    if family != _SERVICE_FAMILY:
        raise ValidationError(
            f"{scheduler_name} requires the crossbar_matching service family",
            context={"service_family": family},
        )
    catalog = domain.queue_catalog
    if declared_constraint is None:
        raise ValidationError(
            f"{scheduler_name} requires scheduler.params.constraint"
        )
    constraint, edges = declared_constraint, declared_edges

    catalog_ids = set(catalog.queue_ids)
    edge_ids = {queue_id for queue_id, _input, _output in edges}
    if edge_ids != catalog_ids:
        raise ValidationError(
            "crossbar constraint queue IDs must equal the queue catalog",
            context={
                "missing_queue_ids": [
                    queue_id for queue_id in catalog.queue_ids if queue_id not in edge_ids
                ],
                "extra_queue_ids": [
                    queue_id
                    for queue_id, _input, _output in edges
                    if queue_id not in catalog_ids
                ],
            },
        )

    inputs = tuple(constraint["inputs"])
    outputs = tuple(constraint["outputs"])
    input_rank = {label: index for index, label in enumerate(inputs)}
    output_rank = {label: index for index, label in enumerate(outputs)}
    edge_by_queue_id = {
        queue_id: (input_label, output_label)
        for queue_id, input_label, output_label in edges
    }
    input_rank_by_queue = tuple(
        input_rank[edge_by_queue_id[queue_id][0]] for queue_id in catalog.queue_ids
    )
    output_rank_by_queue = tuple(
        output_rank[edge_by_queue_id[queue_id][1]] for queue_id in catalog.queue_ids
    )
    queue_index_by_pair = {
        (input_rank_by_queue[index], output_rank_by_queue[index]): index
        for index in range(catalog.n_queues)
    }
    operational_queue_indices = tuple(
        sorted(
            range(catalog.n_queues),
            key=lambda index: (
                input_rank_by_queue[index],
                output_rank_by_queue[index],
            ),
        )
    )
    return CompiledCrossbarTopology(
        constraint=dict(constraint),
        inputs=inputs,
        outputs=outputs,
        input_rank_by_queue=input_rank_by_queue,
        output_rank_by_queue=output_rank_by_queue,
        queue_index_by_pair=queue_index_by_pair,
        operational_queue_indices=operational_queue_indices,
    )


class CrossbarHeuristicBase(QueueSchedulerBase):
    """Common parsing, domain binding, and feasibility validation."""

    __slots__ = ("_declared_constraint", "_declared_edges", "_topology")

    service_family = _SERVICE_FAMILY

    def __init__(self, params=None) -> None:
        super().__init__(params=params)
        if "constraint" in self.params:
            constraint, edges = _normalize_constraint(self.params["constraint"])
        else:
            constraint, edges = None, ()
        self._declared_constraint = constraint
        self._declared_edges = edges
        self._topology: CompiledCrossbarTopology | None = None

    @property
    def declared_constraint(self) -> dict[str, JSONValue] | None:
        if self._declared_constraint is None:
            return None
        return dict(self._declared_constraint)

    @property
    def topology(self) -> CompiledCrossbarTopology:
        if self._topology is None:
            raise ValidationError(
                "scheduler must be configured for a crossbar domain before use",
                context={"scheduler": self.name},
            )
        return self._topology

    def topology_for_domain(self, domain: Any) -> CompiledCrossbarTopology:
        super().validate_for_domain(domain)
        return compile_crossbar_topology(
            domain=domain,
            declared_constraint=self._declared_constraint,
            declared_edges=self._declared_edges,
            scheduler_name=self.name,
        )

    def validate_for_domain(self, domain: Any) -> None:
        self.topology_for_domain(domain)

    def configure_for_domain(self, domain: Any) -> None:
        topology = self.topology_for_domain(domain)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )
        super().configure_for_domain(domain)
        self._topology = topology

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        checked = super().validate_service_decision(decision, q_len)
        topology = self.topology
        catalog = self.scheduler_domain.queue_catalog
        canonical = checked.canonical_for(catalog)
        used_inputs: dict[int, QueueId] = {}
        used_outputs: dict[int, QueueId] = {}
        for queue_id in canonical.selected_queue_ids:
            queue_index = catalog.index_of(queue_id)
            input_rank = topology.input_rank_by_queue[queue_index]
            output_rank = topology.output_rank_by_queue[queue_index]
            if input_rank in used_inputs:
                raise ScheduleError(
                    "service decision violates the one-queue-per-input constraint",
                    context={
                        "queue_id": queue_id,
                        "conflicts_with": used_inputs[input_rank],
                    },
                )
            if output_rank in used_outputs:
                raise ScheduleError(
                    "service decision violates the one-queue-per-output constraint",
                    context={
                        "queue_id": queue_id,
                        "conflicts_with": used_outputs[output_rank],
                    },
                )
            used_inputs[input_rank] = queue_id
            used_outputs[output_rank] = queue_id
        return canonical


__all__ = [
    "CompiledCrossbarTopology",
    "CrossbarHeuristicBase",
    "compile_crossbar_topology",
]
