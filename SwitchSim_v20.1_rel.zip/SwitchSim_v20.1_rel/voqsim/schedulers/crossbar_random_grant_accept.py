"""Finite-round randomized grant/accept scheduling on a declared crossbar."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ValidationError
from ..queues import ServiceDecision
from ..types import JSONValue
from ._crossbar_heuristic import CrossbarHeuristicBase


_ALLOWED_PARAM_KEYS = frozenset({"constraint", "rounds"})


def _positive_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 1:
        raise ValidationError(
            f"{name} must be >= 1",
            context={"value": result, "minimum": 1},
        )
    return result


class CrossbarRandomGrantAcceptScheduler(CrossbarHeuristicBase):
    """Uniform-random output grants and input accepts for fixed rounds.

    Each slot starts without scheduler memory.  A finite number of rounds can
    leave an augmentable matching, so this policy deliberately makes no
    maximality or optimality claim.
    """

    algorithm_id = "uniform_random_grant_accept"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "crossbar_random_grant_accept received unsupported scheduler params",
                context={"unknown_keys": unknown, "allowed": sorted(_ALLOWED_PARAM_KEYS)},
            )
        self._rounds = _positive_int(
            self.params.get("rounds", 1),
            name="scheduler.params.rounds",
        )
        canonical: dict[str, JSONValue] = {"rounds": self._rounds}
        if self.declared_constraint is not None:
            canonical["constraint"] = self.declared_constraint
        self._params = canonical

    @property
    def name(self) -> str:
        return "crossbar_random_grant_accept"

    @property
    def rounds(self) -> int:
        return self._rounds

    @staticmethod
    def _uniform_choice(rng: np.random.Generator, candidates: Sequence[int]) -> int:
        if len(candidates) == 1:
            return int(candidates[0])
        return int(candidates[int(rng.integers(0, len(candidates)))])

    def configure_for_domain(self, domain: Any) -> None:
        topology = self.topology_for_domain(domain)
        if self._rounds > min(topology.n_inputs, topology.n_outputs):
            raise ValidationError(
                "crossbar_random_grant_accept rounds must not exceed the smaller port side",
                context={
                    "rounds": self._rounds,
                    "n_inputs": topology.n_inputs,
                    "n_outputs": topology.n_outputs,
                },
            )
        super().configure_for_domain(domain)

    def state_dict(self) -> dict[str, JSONValue]:
        return {
            "scheduler_kind": self.name,
            "algorithm_id": self.algorithm_id,
            "rounds": self._rounds,
        }

    def select_service(
        self,
        q_len,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, rng = self.validate_queue_select_inputs(q_len, slot, rng)
        topology = self.topology
        catalog = self.scheduler_domain.queue_catalog
        if not np.any(vector > 0):
            return ServiceDecision.empty()

        unmatched_inputs = list(range(topology.n_inputs))
        unmatched_outputs = list(range(topology.n_outputs))
        selected: list[int] = []
        for _round_index in range(self._rounds):
            if not unmatched_inputs or not unmatched_outputs:
                break

            grants: dict[int, int] = {}
            for output_rank in unmatched_outputs:
                requesters = [
                    input_rank
                    for input_rank in unmatched_inputs
                    if (
                        (queue_index := topology.queue_index_by_pair.get(
                            (input_rank, output_rank)
                        ))
                        is not None
                        and int(vector[queue_index]) > 0
                    )
                ]
                if requesters:
                    grants[output_rank] = self._uniform_choice(rng, requesters)

            accepts: dict[int, int] = {}
            for input_rank in unmatched_inputs:
                granted_outputs = [
                    output_rank
                    for output_rank in unmatched_outputs
                    if grants.get(output_rank) == input_rank
                ]
                if granted_outputs:
                    accepts[input_rank] = self._uniform_choice(rng, granted_outputs)

            if not accepts:
                break
            matched_inputs = sorted(accepts)
            matched_outputs = sorted(accepts.values())
            selected.extend(
                topology.queue_index_by_pair[(input_rank, accepts[input_rank])]
                for input_rank in matched_inputs
            )
            matched_input_set = set(matched_inputs)
            matched_output_set = set(matched_outputs)
            unmatched_inputs = [
                value for value in unmatched_inputs if value not in matched_input_set
            ]
            unmatched_outputs = [
                value for value in unmatched_outputs if value not in matched_output_set
            ]

        selected.sort()
        return ServiceDecision.from_indices(selected, catalog)


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> CrossbarRandomGrantAcceptScheduler:
    return CrossbarRandomGrantAcceptScheduler(params=params)


__all__ = ["CrossbarRandomGrantAcceptScheduler", "build_scheduler"]
