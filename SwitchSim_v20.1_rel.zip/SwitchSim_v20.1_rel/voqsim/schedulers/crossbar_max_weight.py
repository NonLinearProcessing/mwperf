"""Exact MaxWeight scheduling for sparse rectangular crossbars.

The public scheduler is native to the generalized queue-vector interface.  A
crossbar constraint is an optional bipartite matching instance: each declared
queue owns one structurally present input/output edge and each port can occur
in at most one selected edge.  Missing edges are not assigned a large finite
penalty.  They are absent from the sparse adjacency consumed by the exact
primal-dual assignment implementation below.

The assignment padding follows :mod:`MaxWeight_Algorithms_and_Arrivals.md`.
It adds one private dummy column per input, one private dummy row per output,
and the complete dummy-row/dummy-column zero block.  Consequently ports may be
left unmatched without adding a maximum-cardinality objective.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import JSONValue, QueueId
from .base import QueueSchedulerBase, coerce_queue_vector, validate_scheduler_slot
from .domain import CrossbarSchedulerDomain
from .exact_gap import ExactGapCertificate, assemble_exact_gap_certificates
from .exact_priority import canonical_priority, exact_lex_weights


_ALLOWED_PARAM_KEYS = frozenset({"constraint", "priority"})
_CONSTRAINT_KEYS = frozenset({"inputs", "outputs", "edges"})
_EDGE_KEYS = frozenset({"queue_id", "input", "output"})

PortLabel = int | str
_Edge = tuple[QueueId, PortLabel, PortLabel]


def _normalize_port_label(value: Any, *, name: str) -> PortLabel:
    """Return one stable port label shared by config and runtime validation."""

    if isinstance(value, bool):
        raise ValidationError(
            f"{name} must be a nonnegative integer or nonempty string",
            context={"value": value},
        )
    if isinstance(value, Integral):
        label = int(value)
        if label < 0:
            raise ValidationError(
                f"{name} integer must be >= 0",
                context={"value": label},
            )
        return label
    if isinstance(value, str):
        if not value or not value.strip():
            raise ValidationError(f"{name} string must be nonempty", context={"value": value})
        if value != value.strip():
            raise ValidationError(
                f"{name} must not contain leading or trailing whitespace",
                context={"value": value},
            )
        return value
    raise ValidationError(
        f"{name} must be a nonnegative integer or nonempty string",
        context={"value": value, "value_type": type(value).__name__},
    )


def _label_sort_key(value: int | str) -> tuple[int, int | str]:
    return (0, value) if isinstance(value, int) else (1, value)


def _require_list(value: Any, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(
            f"{name} must be a list",
            context={"value_type": type(value).__name__},
        )
    return list(value)


def _normalize_ports(value: Any, *, name: str) -> tuple[PortLabel, ...]:
    raw_ports = _require_list(value, name=name)
    if not raw_ports:
        raise ValidationError(f"{name} must contain at least one port")
    ports = tuple(
        _normalize_port_label(raw, name=f"{name}[{index}]")
        for index, raw in enumerate(raw_ports)
    )
    seen: dict[PortLabel, int] = {}
    for index, port in enumerate(ports):
        if port in seen:
            raise ValidationError(
                f"{name} contains a duplicate port",
                context={"port": port, "first_index": seen[port], "duplicate_index": index},
            )
        seen[port] = index
    return tuple(sorted(ports, key=_label_sort_key))


def _normalize_constraint(value: Any) -> tuple[dict[str, JSONValue], tuple[_Edge, ...]]:
    if not isinstance(value, Mapping):
        raise ValidationError(
            "scheduler.params.constraint must be a mapping",
            context={"value_type": type(value).__name__},
        )
    unknown = sorted(set(value) - _CONSTRAINT_KEYS)
    missing = sorted(_CONSTRAINT_KEYS - set(value))
    if unknown or missing:
        raise ValidationError(
            "crossbar constraint must contain exactly inputs, outputs, and edges",
            context={"unknown_keys": unknown, "missing_keys": missing},
        )

    inputs = _normalize_ports(value["inputs"], name="scheduler.params.constraint.inputs")
    outputs = _normalize_ports(value["outputs"], name="scheduler.params.constraint.outputs")
    input_set = set(inputs)
    output_set = set(outputs)

    raw_edges = _require_list(value["edges"], name="scheduler.params.constraint.edges")
    if not raw_edges:
        raise ValidationError("scheduler.params.constraint.edges must contain at least one edge")

    edges: list[_Edge] = []
    queue_positions: dict[QueueId, int] = {}
    pair_positions: dict[tuple[PortLabel, PortLabel], int] = {}
    for edge_index, raw_edge in enumerate(raw_edges):
        if not isinstance(raw_edge, Mapping):
            raise ValidationError(
                "each crossbar edge must be a mapping",
                context={"edge_index": edge_index, "value_type": type(raw_edge).__name__},
            )
        unknown_edge = sorted(set(raw_edge) - _EDGE_KEYS)
        missing_edge = sorted(_EDGE_KEYS - set(raw_edge))
        if unknown_edge or missing_edge:
            raise ValidationError(
                "each crossbar edge must contain exactly queue_id, input, and output",
                context={
                    "edge_index": edge_index,
                    "unknown_keys": unknown_edge,
                    "missing_keys": missing_edge,
                },
            )
        queue_id = normalize_queue_id(
            raw_edge["queue_id"],
            name=f"scheduler.params.constraint.edges[{edge_index}].queue_id",
        )
        input_port = _normalize_port_label(
            raw_edge["input"],
            name=f"scheduler.params.constraint.edges[{edge_index}].input",
        )
        output_port = _normalize_port_label(
            raw_edge["output"],
            name=f"scheduler.params.constraint.edges[{edge_index}].output",
        )
        if input_port not in input_set:
            raise ValidationError(
                "crossbar edge references an undeclared input port",
                context={"edge_index": edge_index, "input": input_port},
            )
        if output_port not in output_set:
            raise ValidationError(
                "crossbar edge references an undeclared output port",
                context={"edge_index": edge_index, "output": output_port},
            )
        if queue_id in queue_positions:
            raise ValidationError(
                "crossbar constraint contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": queue_positions[queue_id],
                    "duplicate_index": edge_index,
                },
            )
        pair = (input_port, output_port)
        if pair in pair_positions:
            raise ValidationError(
                "crossbar constraint contains duplicate input/output edges",
                context={
                    "input": input_port,
                    "output": output_port,
                    "first_index": pair_positions[pair],
                    "duplicate_index": edge_index,
                },
            )
        queue_positions[queue_id] = edge_index
        pair_positions[pair] = edge_index
        edges.append((queue_id, input_port, output_port))

    edges.sort(key=lambda edge: _label_sort_key(edge[0]))
    canonical: dict[str, JSONValue] = {
        "inputs": list(inputs),
        "outputs": list(outputs),
        "edges": [
            {"queue_id": queue_id, "input": input_port, "output": output_port}
            for queue_id, input_port, output_port in edges
        ],
    }
    return canonical, tuple(edges)


def _normalize_declared_priority(value: Any) -> tuple[QueueId, ...] | None:
    if value is None:
        return None
    raw_priority = _require_list(value, name="scheduler.params.priority")
    priority = tuple(
        normalize_queue_id(queue_id, name=f"scheduler.params.priority[{index}]")
        for index, queue_id in enumerate(raw_priority)
    )
    seen: dict[QueueId, int] = {}
    for index, queue_id in enumerate(priority):
        if queue_id in seen:
            raise ValidationError(
                "scheduler.params.priority contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_index": seen[queue_id],
                    "duplicate_index": index,
                },
            )
        seen[queue_id] = index
    return priority


def _maximum_weight_perfect_assignment(
    adjacency: Sequence[Mapping[int, int]],
) -> tuple[int, ...]:
    """Solve a sparse square maximum-weight assignment exactly.

    This is the primal-dual Kuhn--Munkres algorithm.  Only keys present in an
    adjacency mapping are physical arcs; a missing key remains structural
    absence throughout label and slack updates.  All arithmetic uses Python
    integers, including the exact lexicographic weights, so there is no finite
    infinity sentinel and no overflow bound.
    """

    n_rows = len(adjacency)
    if n_rows == 0:
        return ()

    normalized_rows: list[tuple[tuple[int, int], ...]] = []
    for row_index, raw_row in enumerate(adjacency):
        if not isinstance(raw_row, Mapping):
            raise ValidationError(
                "assignment adjacency rows must be mappings",
                context={"row": row_index, "value_type": type(raw_row).__name__},
            )
        items: list[tuple[int, int]] = []
        for raw_col, raw_weight in raw_row.items():
            if isinstance(raw_col, bool) or not isinstance(raw_col, Integral):
                raise ValidationError("assignment column index must be an integer")
            col = int(raw_col)
            if not 0 <= col < n_rows:
                raise ValidationError(
                    "assignment column index is out of range",
                    context={"row": row_index, "column": col, "dimension": n_rows},
                )
            if isinstance(raw_weight, bool) or not isinstance(raw_weight, Integral):
                raise ValidationError(
                    "assignment weights must be integers",
                    context={"row": row_index, "column": col, "weight": raw_weight},
                )
            items.append((col, int(raw_weight)))
        if not items:
            raise ScheduleError(
                "crossbar assignment row has no structurally allowed arc",
                context={"row": row_index},
            )
        items.sort()
        normalized_rows.append(tuple(items))

    return _maximum_weight_perfect_assignment_from_rows(tuple(normalized_rows))


def _maximum_weight_perfect_assignment_from_rows(
    normalized_rows: Sequence[Sequence[tuple[int, int]]],
) -> tuple[int, ...]:
    """Trusted hot-path variant over sorted structural ``(column, weight)`` arcs."""

    n_rows = len(normalized_rows)
    if n_rows == 0:
        return ()
    # Feasible dual labels for maximum-weight matching.
    row_label = [max(weight for _col, weight in row) for row in normalized_rows]
    col_label = [0] * n_rows
    col_for_row = [-1] * n_rows
    row_for_col = [-1] * n_rows

    for root in range(n_rows):
        in_tree_row = [False] * n_rows
        in_tree_col = [False] * n_rows
        predecessor_row = [-1] * n_rows
        slack: list[int | None] = [None] * n_rows
        slack_row = [-1] * n_rows
        queue: list[int] = []
        queue_head = 0

        def add_row(row: int) -> None:
            if in_tree_row[row]:
                return
            in_tree_row[row] = True
            queue.append(row)
            for col, weight in normalized_rows[row]:
                if in_tree_col[col]:
                    continue
                reduced = row_label[row] + col_label[col] - weight
                if reduced < 0:  # pragma: no cover - internal dual invariant
                    raise ScheduleError("Hungarian dual feasibility invariant failed")
                current = slack[col]
                if current is None or reduced < current or (
                    reduced == current and row < slack_row[col]
                ):
                    slack[col] = reduced
                    slack_row[col] = row

        def augment(exposed_col: int) -> None:
            col = exposed_col
            while col != -1:
                row = predecessor_row[col]
                if row < 0:  # pragma: no cover - internal alternating-tree invariant
                    raise ScheduleError("Hungarian augmenting path is incomplete")
                next_col = col_for_row[row]
                col_for_row[row] = col
                row_for_col[col] = row
                col = next_col

        add_row(root)
        augmented = False
        while not augmented:
            while queue_head < len(queue) and not augmented:
                row = queue[queue_head]
                queue_head += 1
                for col, weight in normalized_rows[row]:
                    if in_tree_col[col]:
                        continue
                    if row_label[row] + col_label[col] != weight:
                        continue
                    predecessor_row[col] = row
                    matched_row = row_for_col[col]
                    if matched_row == -1:
                        augment(col)
                        augmented = True
                        break
                    in_tree_col[col] = True
                    add_row(matched_row)

            if augmented:
                break

            candidates = [
                value
                for col, value in enumerate(slack)
                if not in_tree_col[col] and value is not None
            ]
            if not candidates:
                raise ScheduleError(
                    "crossbar padding did not admit a perfect assignment",
                    context={"root_row": root},
                )
            delta = min(candidates)
            for row in range(n_rows):
                if in_tree_row[row]:
                    row_label[row] -= delta
            for col in range(n_rows):
                if in_tree_col[col]:
                    col_label[col] += delta
                elif slack[col] is not None:
                    slack[col] -= delta

            # Newly tight slack arcs extend the alternating tree.  Iterating in
            # column order makes the implementation deterministic even when
            # multiple padded perfect assignments encode the same schedule.
            for col in range(n_rows):
                if in_tree_col[col] or slack[col] != 0:
                    continue
                row = slack_row[col]
                predecessor_row[col] = row
                matched_row = row_for_col[col]
                if matched_row == -1:
                    augment(col)
                    augmented = True
                    break
                in_tree_col[col] = True
                add_row(matched_row)

    if any(col < 0 for col in col_for_row):  # pragma: no cover - guarded above
        raise ScheduleError("Hungarian optimizer returned an incomplete assignment")
    return tuple(col_for_row)


class CrossbarMaxWeightScheduler(QueueSchedulerBase):
    """Exact optional maximum-weight matching on a declared crossbar."""

    __slots__ = (
        "_declared_constraint",
        "_declared_edges",
        "_declared_priority",
        "_active_constraint",
        "_priority",
        "_primary_scale",
        "_priority_bonus",
        "_edge_by_queue_id",
        "_edge_by_index",
        "_queue_arcs_by_row",
        "_row_by_input",
        "_col_by_output",
        "_queue_by_pair",
    )

    optimizer_id = "hungarian_exact"
    service_family = "crossbar_matching"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        try:
            super().__init__(params=params)
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "crossbar_max_weight scheduler params must contain finite JSON-safe values",
                context={"error": str(exc)},
            ) from exc
        unknown = sorted(set(self.params) - _ALLOWED_PARAM_KEYS)
        if unknown:
            raise ValidationError(
                "crossbar_max_weight received unsupported scheduler params",
                context={"unknown_keys": unknown, "allowed": sorted(_ALLOWED_PARAM_KEYS)},
            )

        if "constraint" in self.params:
            constraint, edges = _normalize_constraint(self.params["constraint"])
        else:
            constraint, edges = None, ()
        priority = _normalize_declared_priority(self.params.get("priority"))

        self._declared_constraint = constraint
        self._declared_edges = edges
        self._declared_priority = priority
        self._active_constraint: dict[str, JSONValue] | None = None
        self._priority: tuple[QueueId, ...] | None = None
        self._primary_scale = 0
        self._priority_bonus: tuple[int, ...] = ()
        self._edge_by_queue_id: dict[QueueId, tuple[PortLabel, PortLabel]] = {}
        self._edge_by_index: tuple[tuple[int, int], ...] = ()
        self._queue_arcs_by_row: tuple[tuple[tuple[int, int], ...], ...] = ()
        self._row_by_input: dict[PortLabel, int] = {}
        self._col_by_output: dict[PortLabel, int] = {}
        self._queue_by_pair: dict[tuple[int, int], QueueId] = {}

        canonical_params: dict[str, JSONValue] = {
            "priority": None if priority is None else list(priority),
        }
        if constraint is not None:
            canonical_params["constraint"] = constraint
        self._params = canonical_params

    @property
    def name(self) -> str:
        return "crossbar_max_weight"

    @property
    def priority(self) -> tuple[QueueId, ...] | None:
        return self._priority if self._priority is not None else self._declared_priority

    @property
    def constraint(self) -> Mapping[str, JSONValue] | None:
        return self._active_constraint if self._active_constraint is not None else self._declared_constraint

    def state_dict(self) -> dict[str, JSONValue]:
        return {
            "scheduler_kind": self.name,
            "optimizer_id": self.optimizer_id,
        }

    @staticmethod
    def _legacy_constraint(domain: CrossbarSchedulerDomain) -> tuple[dict[str, JSONValue], tuple[_Edge, ...]]:
        raw: dict[str, JSONValue] = {
            "inputs": list(range(domain.n_ports)),
            "outputs": list(range(domain.n_ports)),
            "edges": [
                {"queue_id": queue_id, "input": edge[0], "output": edge[1]}
                for queue_id, edge in zip(domain.queue_ids, domain.edge_by_index, strict=True)
            ],
        }
        return _normalize_constraint(raw)

    def _constraint_for_domain(self, domain: Any) -> tuple[dict[str, JSONValue], tuple[_Edge, ...]]:
        if self._declared_constraint is None:
            if not isinstance(domain, CrossbarSchedulerDomain):
                raise ValidationError(
                    "crossbar_max_weight requires scheduler.params.constraint for a generalized switch"
                )
            return self._legacy_constraint(domain)

        if isinstance(domain, CrossbarSchedulerDomain):
            raise ValidationError(
                "legacy crossbar domains derive topology from the switch and must omit "
                "scheduler.params.constraint"
            )
        return self._declared_constraint, self._declared_edges

    def validate_for_domain(self, domain: Any) -> None:
        super().validate_for_domain(domain)
        if domain.service_family != self.service_family:
            raise ValidationError(
                "crossbar_max_weight requires the crossbar_matching service family",
                context={"service_family": domain.service_family},
            )
        _constraint, edges = self._constraint_for_domain(domain)
        catalog_ids = set(domain.queue_catalog.queue_ids)
        edge_ids = {queue_id for queue_id, _input, _output in edges}
        if edge_ids != catalog_ids:
            raise ValidationError(
                "crossbar constraint queue IDs must equal the queue catalog",
                context={
                    "missing_queue_ids": [
                        queue_id for queue_id in domain.queue_catalog.queue_ids if queue_id not in edge_ids
                    ],
                    "extra_queue_ids": [
                        queue_id for queue_id, _input, _output in edges if queue_id not in catalog_ids
                    ],
                },
            )
        canonical_priority(domain.queue_catalog, self._declared_priority)

    def configure_for_domain(self, domain: Any) -> None:
        super().configure_for_domain(domain)
        constraint, edges = self._constraint_for_domain(domain)
        catalog: QueueCatalog = domain.queue_catalog
        priority = canonical_priority(catalog, self._declared_priority)
        priority_bonus = exact_lex_weights((0,) * catalog.n_queues, catalog, priority)

        inputs = tuple(constraint["inputs"])
        outputs = tuple(constraint["outputs"])
        row_by_input = {port: index for index, port in enumerate(inputs)}
        col_by_output = {port: index for index, port in enumerate(outputs)}
        edge_by_queue_id = {
            queue_id: (input_port, output_port)
            for queue_id, input_port, output_port in edges
        }
        edge_by_index = tuple(
            (
                row_by_input[edge_by_queue_id[queue_id][0]],
                col_by_output[edge_by_queue_id[queue_id][1]],
            )
            for queue_id in catalog.queue_ids
        )
        queue_by_pair = {
            edge_by_index[index]: catalog.queue_id_at(index)
            for index in range(catalog.n_queues)
        }
        queue_arcs_by_row: list[list[tuple[int, int]]] = [list() for _ in inputs]
        for queue_index, (row, col) in enumerate(edge_by_index):
            queue_arcs_by_row[row].append((col, queue_index))
        for row_arcs in queue_arcs_by_row:
            row_arcs.sort()

        self._active_constraint = constraint
        self._priority = priority
        self._primary_scale = 1 << catalog.n_queues
        self._priority_bonus = priority_bonus
        self._edge_by_queue_id = edge_by_queue_id
        self._edge_by_index = edge_by_index
        self._queue_arcs_by_row = tuple(tuple(row_arcs) for row_arcs in queue_arcs_by_row)
        self._row_by_input = row_by_input
        self._col_by_output = col_by_output
        self._queue_by_pair = queue_by_pair

    def _build_padded_rows_for_subset(
        self,
        exact_weights: tuple[int, ...],
        eligible: frozenset[int],
        *,
        reserved_queue_index: int | None = None,
    ) -> tuple[
        tuple[tuple[tuple[int, int], ...], ...],
        tuple[int, ...],
        tuple[int, ...],
    ]:
        if self._active_constraint is None:
            raise ValidationError("crossbar_max_weight has not been configured for a domain")
        reserved_row: int | None = None
        reserved_col: int | None = None
        if reserved_queue_index is not None:
            reserved_row, reserved_col = self._edge_by_index[reserved_queue_index]

        input_rows = tuple(
            row for row in range(len(self._row_by_input)) if row != reserved_row
        )
        output_cols = tuple(
            col for col in range(len(self._col_by_output)) if col != reserved_col
        )
        residual_row = {row: index for index, row in enumerate(input_rows)}
        residual_col = {col: index for index, col in enumerate(output_cols)}
        n_inputs = len(input_rows)
        n_outputs = len(output_cols)
        rows: list[tuple[tuple[int, int], ...]] = []

        # Real arcs were sorted and grouped once at bind time.  Per slot we
        # only filter eligibility and attach each residual input's private
        # dummy arc. A forced-in target removes its complete row and column;
        # no numeric sentinel is used to simulate reservation.
        for original_row in input_rows:
            row = residual_row[original_row]
            active_arcs = [
                (residual_col[col], exact_weights[queue_index])
                for col, queue_index in self._queue_arcs_by_row[original_row]
                if queue_index in eligible and col in residual_col
            ]
            active_arcs.append((n_outputs + row, 0))
            rows.append(tuple(active_arcs))

        dummy_columns = tuple((n_outputs + input_row, 0) for input_row in range(n_inputs))
        for output_col in range(n_outputs):
            rows.append(((output_col, 0), *dummy_columns))
        return tuple(rows), input_rows, output_cols

    def _solve_exact_indices(
        self,
        exact_weights: tuple[int, ...],
        eligible: frozenset[int],
        *,
        reserved_queue_index: int | None = None,
    ) -> tuple[int, ...]:
        """Solve one optional assignment, optionally behind a fixed target."""

        catalog = self.scheduler_domain.queue_catalog if self.scheduler_domain is not None else None
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError("crossbar_max_weight has not been configured for a domain")
        padded_rows, input_rows, output_cols = self._build_padded_rows_for_subset(
            exact_weights,
            eligible,
            reserved_queue_index=reserved_queue_index,
        )
        assignment = _maximum_weight_perfect_assignment_from_rows(padded_rows)
        selected_indices: list[int] = []
        for residual_row, residual_col in enumerate(assignment[: len(input_rows)]):
            if residual_col >= len(output_cols):
                continue
            pair = (input_rows[residual_row], output_cols[residual_col])
            queue_id = self._queue_by_pair.get(pair)
            if queue_id is not None:
                selected_indices.append(catalog.index_of(queue_id))
        if reserved_queue_index is not None:
            selected_indices.append(reserved_queue_index)
        selected_indices.sort()
        return tuple(selected_indices)

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        assert self.scheduler_domain is not None  # established by the validator above
        catalog: QueueCatalog = self.scheduler_domain.queue_catalog
        priority = self._priority
        if priority is None:  # pragma: no cover - configure_for_domain establishes this
            raise ValidationError("crossbar_max_weight priority has not been bound")
        if not np.any(vector):
            return ServiceDecision.empty()
        # The common exact-priority helper compiled the immutable secondary
        # bonus vector at domain bind.  Only the primary backlog term changes
        # per slot, avoiding repeated permutation validation and index lookup.
        weights = tuple(
            self._primary_scale * int(length) + bonus
            for length, bonus in zip(vector, self._priority_bonus, strict=True)
        )
        eligible = frozenset(
            queue_index
            for queue_index, length in enumerate(vector)
            if int(length) > 0
        )
        selected_indices = self._solve_exact_indices(weights, eligible)
        # Feasibility follows by construction.  The simulator invokes the
        # domain validator exactly once after selection and before mutation;
        # avoiding a duplicate vector copy here keeps the per-slot hot path
        # lean while direct callers may invoke validate_service_decision too.
        return ServiceDecision.from_indices(selected_indices, catalog)

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]:
        """Return exact full-crossbar values with one opposite solve per target."""

        if self.scheduler_domain is None:
            raise ValidationError("crossbar_max_weight has not been configured for a domain")
        catalog: QueueCatalog = self.scheduler_domain.queue_catalog
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        validate_scheduler_slot(slot)
        weights = tuple(
            self._primary_scale * int(length) + bonus
            for length, bonus in zip(vector, self._priority_bonus, strict=True)
        )
        positive = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )

        def solve_opposite(target_index: int, forced_class: int) -> tuple[int, ...]:
            if forced_class == 0:
                return self._solve_exact_indices(weights, positive - {target_index})
            # The target is added by the trusted core after its input/output
            # have been removed from the residual optional assignment. This
            # also implements the value-only reservation when its backlog is 0.
            return self._solve_exact_indices(
                weights,
                positive - {target_index},
                reserved_queue_index=target_index,
            )

        return assemble_exact_gap_certificates(
            catalog=catalog,
            q_len=vector,
            production_decision=production_decision,
            target_queue_ids=target_queue_ids,
            solve_opposite_class=solve_opposite,
        )

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        checked = super().validate_service_decision(decision, q_len)
        used_inputs: dict[PortLabel, QueueId] = {}
        used_outputs: dict[PortLabel, QueueId] = {}
        for queue_id in checked.selected_queue_ids:
            try:
                input_port, output_port = self._edge_by_queue_id[queue_id]
            except KeyError as exc:
                raise ScheduleError(
                    "scheduler selected a queue outside the crossbar constraint",
                    context={"queue_id": queue_id},
                ) from exc
            if input_port in used_inputs:
                raise ScheduleError(
                    "service decision violates the one-queue-per-input constraint",
                    context={
                        "queue_id": queue_id,
                        "input": input_port,
                        "conflicts_with": used_inputs[input_port],
                    },
                )
            if output_port in used_outputs:
                raise ScheduleError(
                    "service decision violates the one-queue-per-output constraint",
                    context={
                        "queue_id": queue_id,
                        "output": output_port,
                        "conflicts_with": used_outputs[output_port],
                    },
                )
            used_inputs[input_port] = queue_id
            used_outputs[output_port] = queue_id
        assert self.scheduler_domain is not None
        return checked.canonical_for(self.scheduler_domain.queue_catalog)


__all__ = ["CrossbarMaxWeightScheduler"]
