"""Exact MaxWeight scheduling for pairwise-nonoverlapping intervals.

Each queue owns one finite half-open interval ``[left, right)``.  Static
interval ordering and predecessor links are compiled once when the scheduler
is bound to its queue domain; a slot decision is then an exact ``O(m)``
weighted-interval dynamic program.  Scores use Python integers throughout so
the common one-solve lexicographic encoding cannot overflow.
"""

from __future__ import annotations

from bisect import bisect_right
from collections.abc import Mapping, Sequence
import math
from numbers import Real
from typing import Any

import numpy as np

from ..errors import ScheduleError, ValidationError
from ..queues import QueueCatalog, ServiceDecision, normalize_queue_id
from ..types import JSONValue, QueueId
from .base import QueueSchedulerBase, coerce_queue_vector, validate_scheduler_slot
from .domain import normalize_service_family
from .exact_gap import ExactGapCertificate, assemble_exact_gap_certificates
from .exact_priority import canonical_priority, exact_lex_weights


_SERVICE_FAMILY = "nonoverlapping_intervals"


def _queue_id_sort_key(queue_id: QueueId) -> tuple[int, int | str]:
    """Canonical total order for the two disjoint QueueId representations."""

    if isinstance(queue_id, int):
        return (0, queue_id)
    return (1, queue_id)


def _canonical_endpoint(value: Any, *, name: str) -> int | float:
    """Return one exact-in-config, finite, totally ordered endpoint.

    Scheduler parameters are JSON data, so supported endpoints are integers
    and finite binary64 values.  Booleans are rejected even though ``bool`` is
    an ``int`` subclass.  Integral floats (including negative zero) normalize
    to integers, making numerically identical JSON spellings hash identically.
    """

    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValidationError(
            f"{name} must be a finite real number",
            context={"value": value, "value_type": type(value).__name__},
        )
    if isinstance(value, int):
        return int(value)

    endpoint = float(value)
    if not math.isfinite(endpoint):
        raise ValidationError(
            f"{name} must be finite",
            context={"value": endpoint},
        )
    if endpoint.is_integer():
        return int(endpoint)
    return endpoint


class IntervalMaxWeightScheduler(QueueSchedulerBase):
    """Exact lexicographic MaxWeight under nonoverlapping-interval service.

    Canonical parameters have the form::

        {
            "constraint": {
                "intervals": [
                    {"queue_id": "q0", "left": 0, "right": 1},
                    ...
                ]
            },
            "priority": ["q0", ...]  # null means catalog order
        }

    Every catalog queue must occur exactly once.  Endpoints may be integers or
    finite real JSON numbers and must satisfy ``left < right``.  The interval
    list is compiled only at domain binding; selection consumes no randomness.
    """

    __slots__ = (
        "_declared_intervals",
        "_declared_priority",
        "_priority",
        "_priority_rank",
        "_primary_scale",
        "_priority_bonus",
        "_interval_by_index",
        "_ordered_indices",
        "_predecessors",
    )

    optimizer_id = "weighted_interval_dp_exact"
    service_family = _SERVICE_FAMILY

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        try:
            super().__init__(params=params)
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "interval_max_weight params must be canonical finite JSON data",
                context={"detail": str(exc)},
            ) from exc

        unknown = set(self.params) - {"constraint", "priority"}
        if unknown:
            raise ValidationError(
                "interval_max_weight received unknown scheduler params",
                context={"unknown_keys": sorted(unknown)},
            )

        constraint = self.params.get("constraint")
        if not isinstance(constraint, Mapping):
            raise ValidationError("interval_max_weight requires a constraint mapping")
        unknown_constraint = set(constraint) - {"intervals"}
        if unknown_constraint:
            raise ValidationError(
                "interval constraint contains unknown fields",
                context={"unknown_keys": sorted(unknown_constraint)},
            )

        raw_intervals = constraint.get("intervals")
        if (
            not isinstance(raw_intervals, Sequence)
            or isinstance(raw_intervals, (str, bytes, bytearray))
            or not raw_intervals
        ):
            raise ValidationError("constraint.intervals must be a nonempty list")

        declared: list[tuple[QueueId, int | float, int | float]] = []
        seen: dict[QueueId, int] = {}
        canonical_entries: list[dict[str, JSONValue]] = []
        for index, raw in enumerate(raw_intervals):
            if not isinstance(raw, Mapping):
                raise ValidationError(
                    "each interval must be a mapping",
                    context={"interval_index": index, "value_type": type(raw).__name__},
                )
            expected_fields = {"queue_id", "left", "right"}
            fields = set(raw)
            if fields != expected_fields:
                raise ValidationError(
                    "each interval must contain exactly queue_id, left, and right",
                    context={
                        "interval_index": index,
                        "missing_fields": sorted(expected_fields - fields),
                        "unknown_fields": sorted(fields - expected_fields),
                    },
                )

            queue_id = normalize_queue_id(
                raw["queue_id"],
                name=f"constraint.intervals[{index}].queue_id",
            )
            if queue_id in seen:
                raise ValidationError(
                    "interval constraint contains a duplicate queue_id",
                    context={
                        "queue_id": queue_id,
                        "first_index": seen[queue_id],
                        "duplicate_index": index,
                    },
                )
            left = _canonical_endpoint(
                raw["left"],
                name=f"constraint.intervals[{index}].left",
            )
            right = _canonical_endpoint(
                raw["right"],
                name=f"constraint.intervals[{index}].right",
            )
            if not left < right:
                raise ValidationError(
                    "interval endpoints must satisfy left < right",
                    context={"queue_id": queue_id, "left": left, "right": right},
                )

            seen[queue_id] = index
            declared.append((queue_id, left, right))
            canonical_entries.append(
                {"queue_id": queue_id, "left": left, "right": right}
            )

        # Input list order is not physical topology.  Canonicalize it without
        # comparing integer queue IDs directly with string queue IDs so service
        # model/config hashes are representation-invariant.
        declared.sort(key=lambda item: _queue_id_sort_key(item[0]))
        canonical_entries.sort(key=lambda item: _queue_id_sort_key(item["queue_id"]))

        raw_priority = self.params.get("priority")
        declared_priority: tuple[QueueId, ...] | None
        if raw_priority is None:
            declared_priority = None
        else:
            if isinstance(raw_priority, (str, bytes, bytearray)) or not isinstance(
                raw_priority, Sequence
            ):
                raise ValidationError("priority must be a list of queue identifiers")
            declared_priority = tuple(
                normalize_queue_id(queue_id, name=f"priority[{index}]")
                for index, queue_id in enumerate(raw_priority)
            )
            priority_positions: dict[QueueId, int] = {}
            for index, queue_id in enumerate(declared_priority):
                if queue_id in priority_positions:
                    raise ValidationError(
                        "priority contains a duplicate queue identifier",
                        context={
                            "queue_id": queue_id,
                            "first_index": priority_positions[queue_id],
                            "duplicate_index": index,
                        },
                    )
                priority_positions[queue_id] = index

        effective: dict[str, JSONValue] = {
            "constraint": {"intervals": canonical_entries},
            "priority": None if declared_priority is None else list(declared_priority),
        }
        self._params = effective
        self._declared_intervals = tuple(declared)
        self._declared_priority = declared_priority
        self._priority: tuple[QueueId, ...] | None = None
        self._priority_rank: tuple[int, ...] | None = None
        self._primary_scale = 0
        self._priority_bonus: tuple[int, ...] = ()
        self._interval_by_index: tuple[tuple[int | float, int | float], ...] | None = None
        self._ordered_indices: tuple[int, ...] | None = None
        self._predecessors: tuple[int, ...] | None = None

    @property
    def name(self) -> str:
        return "interval_max_weight"

    @property
    def priority(self) -> tuple[QueueId, ...] | None:
        return self._priority if self._priority is not None else self._declared_priority

    def state_dict(self) -> dict[str, JSONValue]:
        return {
            "scheduler_kind": self.name,
            "optimizer_id": self.optimizer_id,
        }

    def validate_for_domain(self, domain: Any) -> None:
        super().validate_for_domain(domain)
        family = normalize_service_family(domain.service_family)
        if family != _SERVICE_FAMILY:
            raise ValidationError(
                "interval_max_weight requires the nonoverlapping_intervals service family",
                context={"service_family": family},
            )

    def configure_for_domain(self, domain: Any) -> None:
        # Compile transactionally: malformed topology/priority data must not
        # leave an otherwise unusable scheduler half-bound to a domain.
        self.validate_for_domain(domain)
        if self.scheduler_domain is not None and self.scheduler_domain != domain:
            raise ValidationError(
                "scheduler cannot be rebound to a different service domain",
                context={"scheduler": self.name},
            )
        catalog: QueueCatalog = domain.queue_catalog

        interval_by_id = {
            queue_id: (left, right)
            for queue_id, left, right in self._declared_intervals
        }
        catalog_ids = set(catalog.queue_ids)
        declared_ids = set(interval_by_id)
        missing = tuple(queue_id for queue_id in catalog.queue_ids if queue_id not in declared_ids)
        extra = tuple(queue_id for queue_id in interval_by_id if queue_id not in catalog_ids)
        if missing or extra:
            raise ValidationError(
                "interval constraint must define exactly one interval for every catalog queue",
                context={"missing_queue_ids": list(missing), "out_of_domain_queue_ids": list(extra)},
            )

        priority = canonical_priority(catalog, self._declared_priority)
        priority_bonus = exact_lex_weights((0,) * catalog.n_queues, catalog, priority)
        priority_rank_by_id = {queue_id: rank for rank, queue_id in enumerate(priority)}
        priority_rank = tuple(priority_rank_by_id[queue_id] for queue_id in catalog.queue_ids)
        interval_by_index = tuple(interval_by_id[queue_id] for queue_id in catalog.queue_ids)
        ordered_indices = tuple(
            sorted(
                range(catalog.n_queues),
                key=lambda queue_index: (
                    interval_by_index[queue_index][1],
                    interval_by_index[queue_index][0],
                    priority_rank[queue_index],
                ),
            )
        )
        ordered_rights = tuple(interval_by_index[index][1] for index in ordered_indices)
        predecessors = tuple(
            bisect_right(
                ordered_rights,
                interval_by_index[queue_index][0],
                0,
                order_position,
            )
            for order_position, queue_index in enumerate(ordered_indices)
        )

        super().configure_for_domain(domain)
        self._priority = priority
        self._priority_rank = priority_rank
        self._primary_scale = 1 << catalog.n_queues
        self._priority_bonus = priority_bonus
        self._interval_by_index = interval_by_index
        self._ordered_indices = ordered_indices
        self._predecessors = predecessors

    def _compiled(
        self,
    ) -> tuple[
        QueueCatalog,
        tuple[QueueId, ...],
        tuple[tuple[int | float, int | float], ...],
        tuple[int, ...],
        tuple[int, ...],
    ]:
        domain = self.scheduler_domain
        if (
            domain is None
            or self._priority is None
            or self._interval_by_index is None
            or self._ordered_indices is None
            or self._predecessors is None
        ):
            raise ValidationError(
                "interval_max_weight must be configured for a service domain before use"
            )
        return (
            domain.queue_catalog,
            self._priority,
            self._interval_by_index,
            self._ordered_indices,
            self._predecessors,
        )

    def select_service(
        self,
        q_len: Any,
        slot: int,
        rng: np.random.Generator,
    ) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog, _priority, _interval_by_index, _ordered_indices, _predecessors = self._compiled()
        # The immutable secondary priority vector is compiled once at bind
        # time. Per slot only the backlog contribution changes.
        weights = tuple(
            self._primary_scale * int(length) + bonus
            for length, bonus in zip(vector, self._priority_bonus, strict=True)
        )
        eligible = frozenset(
            queue_index
            for queue_index, length in enumerate(vector)
            if int(length) > 0
        )
        selected_indices = self._solve_exact_indices(weights, eligible)

        # ServiceDecision order is a representation detail.  Catalog order is
        # stable across optimizers and keeps packet/service telemetry canonical.
        return ServiceDecision.from_indices(selected_indices, catalog)

    def _solve_exact_indices(
        self,
        weights: tuple[int, ...],
        eligible: frozenset[int],
    ) -> tuple[int, ...]:
        """Run the trusted interval DP over an explicit eligible subset."""

        _catalog, _priority, _interval_by_index, ordered_indices, predecessors = self._compiled()

        count = len(ordered_indices)
        scores = [0] * (count + 1)
        take_at = bytearray(count)
        for order_position, queue_index in enumerate(ordered_indices, start=1):
            skip_score = scores[order_position - 1]
            if queue_index in eligible:
                take_score = weights[queue_index] + scores[predecessors[order_position - 1]]
                if take_score > skip_score:
                    scores[order_position] = take_score
                    take_at[order_position - 1] = 1
                    continue
            scores[order_position] = skip_score

        selected_indices: list[int] = []
        cursor = count
        while cursor:
            if take_at[cursor - 1]:
                selected_indices.append(ordered_indices[cursor - 1])
                cursor = predecessors[cursor - 1]
            else:
                cursor -= 1

        # ServiceDecision order is a representation detail.  Catalog order is
        # stable across optimizers and keeps packet/service telemetry canonical.
        selected_indices.sort()
        return tuple(selected_indices)

    def exact_class_certificates(
        self,
        q_len: Any,
        production_decision: ServiceDecision,
        target_queue_ids: Sequence[QueueId],
        *,
        slot: int,
    ) -> tuple[ExactGapCertificate, ...]:
        """Return exact full-constraint forced-class values for targets."""

        catalog, _priority, interval_by_index, _ordered, _predecessors = self._compiled()
        vector = coerce_queue_vector(q_len, expected_size=catalog.n_queues)
        validate_scheduler_slot(slot)
        weights = tuple(
            self._primary_scale * int(length) + bonus
            for length, bonus in zip(vector, self._priority_bonus, strict=True)
        )
        positive = frozenset(
            index for index, length in enumerate(vector) if int(length) > 0
        )

        def solve_opposite(target_index: int, forced_class: int) -> tuple[int, ...]:
            if forced_class == 0:
                return self._solve_exact_indices(weights, positive - {target_index})

            target_left, target_right = interval_by_index[target_index]
            residual = frozenset(
                queue_index
                for queue_index in positive
                if queue_index != target_index
                and (
                    interval_by_index[queue_index][1] <= target_left
                    or target_right <= interval_by_index[queue_index][0]
                )
            )
            selected = self._solve_exact_indices(weights, residual)
            return tuple(sorted((*selected, target_index)))

        return assemble_exact_gap_certificates(
            catalog=catalog,
            q_len=vector,
            production_decision=production_decision,
            target_queue_ids=target_queue_ids,
            solve_opposite_class=solve_opposite,
        )

    def validate_service_decision(self, decision: Any, q_len: Any) -> ServiceDecision:
        validated = super().validate_service_decision(decision, q_len)
        catalog, _priority, interval_by_index, _ordered_indices, _predecessors = self._compiled()
        canonical = validated.canonical_for(catalog)

        selected = []
        for queue_id in canonical.selected_queue_ids:
            queue_index = catalog.index_of(queue_id)
            left, right = interval_by_index[queue_index]
            # The numeric catalog index prevents Python from ever comparing a
            # string queue ID with an integer ID when intervals are identical.
            selected.append((left, right, queue_index, queue_id))
        selected.sort()
        for previous, current in zip(selected, selected[1:]):
            if previous[1] > current[0]:
                raise ScheduleError(
                    "scheduler service decision contains overlapping intervals",
                    context={
                        "first_queue_id": previous[3],
                        "second_queue_id": current[3],
                        "first_interval": [previous[0], previous[1]],
                        "second_interval": [current[0], current[1]],
                    },
                )
        return canonical


def build_scheduler(
    params: Mapping[str, JSONValue] | None = None,
) -> IntervalMaxWeightScheduler:
    """Factory used by the scheduler registry."""

    return IntervalMaxWeightScheduler(params=params)


__all__ = ["IntervalMaxWeightScheduler", "build_scheduler"]
