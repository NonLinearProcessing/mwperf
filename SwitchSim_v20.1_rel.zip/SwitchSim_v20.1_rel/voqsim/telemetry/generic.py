from __future__ import annotations

"""Topology-neutral slot telemetry for generalized queueing switches.

This module intentionally does not know any service constraint.  The runtime
validates a :class:`~voqsim.queues.ServiceDecision` against the configured
scheduler domain before service; telemetry only verifies the universal queue
semantics (known/distinct/nonempty selected queues, one departure per selected
queue, and queue conservation).

This is the simulator's sole per-slot telemetry representation.
"""

from collections import Counter
from dataclasses import dataclass, field
from numbers import Integral
from typing import Any, Iterable, Mapping, Sequence, TypeAlias, TypeVar

import numpy as np

from ..errors import ValidationError
from ..events import AdmissionDecision, ArrivalAttempt, CompletionEvent, DepartureEvent, event_to_dict
from ..queues import QueueCatalog, ServiceDecision
from ..types import JSONValue, QueueSnapshotMode, Slot
from ..utils import normalize_for_json

GENERIC_TELEMETRY_SCHEMA_VERSION = "3.0.0"
GenericQueueSnapshot: TypeAlias = dict[str, JSONValue]

_EventT = TypeVar("_EventT")


def _non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": result})
    return result


def _optional_identifier(value: Any, *, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValidationError(f"{name} must be a string or null", context={"value": value})
    result = value.strip()
    if not result:
        raise ValidationError(f"{name} must not be empty")
    return result


def _identifier(value: Any, *, name: str) -> str:
    result = _optional_identifier(value, name=name)
    if result is None:
        raise ValidationError(f"{name} must be a string", context={"value": value})
    return result


def _telemetry_schema_version(value: Any) -> str:
    version = _identifier(value, name="schema_version")
    if version != GENERIC_TELEMETRY_SCHEMA_VERSION:
        raise ValidationError(
            "unsupported generic telemetry schema version",
            context={
                "schema_version": version,
                "supported": GENERIC_TELEMETRY_SCHEMA_VERSION,
            },
        )
    return version


def _optimizer_identifier(value: Any, *, algorithm_id: str) -> str | None:
    optimizer_id = _optional_identifier(value, name="optimizer_id")
    if optimizer_id is not None and optimizer_id != algorithm_id:
        raise ValidationError(
            "optimizer_id must equal algorithm_id for an exact scheduler",
            context={
                "algorithm_id": algorithm_id,
                "optimizer_id": optimizer_id,
            },
        )
    return optimizer_id


def _optional_mapping(value: Any, *, name: str) -> dict[str, JSONValue] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValidationError(f"{name} must be a mapping or null")
    normalized = normalize_for_json(dict(value))
    if not isinstance(normalized, dict):  # pragma: no cover - defensive
        raise ValidationError(f"{name} did not normalize to an object")
    return dict(sorted(normalized.items()))


def _snapshot_mode(value: Any) -> str:
    if not isinstance(value, str):
        raise ValidationError("queue_snapshot_mode must be a string", context={"value": value})
    mode = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in mode:
        mode = mode.replace("__", "_")
    mode = mode.strip("_")
    if mode not in {"dense", "sparse_nonzero", "disabled"}:
        raise ValidationError(
            "Unsupported queue snapshot mode",
            context={"mode": value, "allowed": ["dense", "sparse_nonzero", "disabled"]},
        )
    return mode


def queue_ids_from_catalog(catalog: Any) -> tuple[Any, ...]:
    """Return an ordered queue-ID tuple from a QueueCatalog-like object."""

    if not isinstance(catalog, QueueCatalog):
        raise ValidationError(
            "catalog must be a QueueCatalog",
            context={"value_type": type(catalog).__name__},
        )
    return catalog.queue_ids


def queue_index(catalog: Any, queue_id: Any, *, name: str = "queue_id") -> int:
    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    try:
        index = int(catalog.index_of(queue_id))
    except Exception as exc:
        raise ValidationError(
            f"{name} is not in the queue catalog",
            context={"queue_id": queue_id},
        ) from exc
    n_queues = catalog.n_queues
    if index < 0 or index >= n_queues:
        raise ValidationError(
            "catalog.index_of returned an out-of-range index",
            context={"queue_id": queue_id, "index": index, "n_queues": n_queues},
        )
    return index


def coerce_queue_vector(
    value: Any,
    *,
    catalog: Any,
    name: str,
    copy: bool = True,
) -> np.ndarray:
    """Validate a nonnegative integral queue vector and return an int64 copy."""

    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    raw = np.asarray(value)
    if raw.ndim != 1 or raw.shape != (catalog.n_queues,):
        raise ValidationError(
            f"{name} must be a one-dimensional vector aligned with the queue catalog",
            context={"shape": raw.shape, "expected_shape": (catalog.n_queues,)},
        )
    if raw.dtype.kind not in {"i", "u"}:
        # Reject float-valued arrays even when every element happens to be whole.
        raise ValidationError(f"{name} must contain integers", context={"dtype": str(raw.dtype)})
    if raw.dtype.kind == "u" and raw.size and int(raw.max()) > np.iinfo(np.int64).max:
        raise ValidationError(f"{name} contains a value outside int64 range")
    vector = np.asarray(raw, dtype=np.int64)
    if np.any(vector < 0):
        raise ValidationError(
            f"{name} must not contain negative occupancies",
            context={"minimum": int(vector.min())},
        )
    compact = np.ascontiguousarray(vector)
    return compact.copy() if copy else compact


def _serialize_validated_queue_vector(
    vector: np.ndarray,
    *,
    catalog: QueueCatalog,
    mode: str,
) -> GenericQueueSnapshot:
    if mode == "disabled":
        values: JSONValue = None
    elif mode == "dense":
        values = [int(value) for value in vector.tolist()]
    else:
        values = [
            [catalog.queue_id_at(int(index)), int(vector[index])]
            for index in np.flatnonzero(vector)
        ]
    return {
        "mode": mode,
        "representation": "queue_vector",
        "queue_order": "service_model.queues[index]",
        "values": values,
    }


def serialize_queue_vector_snapshot(
    q_len: Any,
    catalog: Any,
    mode: QueueSnapshotMode = "sparse_nonzero",
) -> GenericQueueSnapshot:
    """Serialize a flat queue vector with an explicit queue-ID coordinate system."""

    normalized_mode = _snapshot_mode(mode)
    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    vector = coerce_queue_vector(q_len, catalog=catalog, name="queue vector", copy=False)
    return _serialize_validated_queue_vector(vector, catalog=catalog, mode=normalized_mode)


def deserialize_queue_vector_snapshot(snapshot: Any, *, catalog: Any, name: str) -> np.ndarray | None:
    """Decode a generalized queue snapshot for online statistics."""

    if snapshot is None:
        return None
    if not isinstance(snapshot, Mapping):
        return coerce_queue_vector(snapshot, catalog=catalog, name=name)

    mode = snapshot.get("mode")
    if mode == "disabled":
        return None
    expected_ids = queue_ids_from_catalog(catalog)
    queue_order = snapshot.get("queue_order")
    if queue_order is not None and queue_order != "service_model.queues[index]":
        raise ValidationError(
            f"{name}.queue_order is unsupported",
            context={"queue_order": queue_order},
        )
    # Accept the short-lived development representation so a partially written
    # trace can still be diagnosed, but v17 writers never repeat this O(m) list.
    raw_ids = snapshot.get("queue_ids")
    if raw_ids is not None and tuple(raw_ids) != expected_ids:
        raise ValidationError(
            f"{name}.queue_ids does not match the queue catalog",
            context={"expected": list(expected_ids), "observed": list(raw_ids)},
        )
    values = snapshot.get("values")
    if mode == "dense":
        return coerce_queue_vector(values, catalog=catalog, name=f"{name}.values")
    if mode == "sparse_nonzero":
        if not isinstance(values, Sequence):
            raise ValidationError(f"{name}.values must be a sequence")
        vector = np.zeros((len(expected_ids),), dtype=np.int64)
        seen: set[Any] = set()
        for entry_index, raw_entry in enumerate(values):
            if not isinstance(raw_entry, Sequence) or isinstance(raw_entry, (str, bytes)) or len(raw_entry) != 2:
                raise ValidationError(
                    f"{name}.values[{entry_index}] must be [queue_id, occupancy]",
                    context={"value": raw_entry},
                )
            queue_id = raw_entry[0]
            if queue_id in seen:
                raise ValidationError(
                    f"{name}.values contains a duplicate queue ID",
                    context={"queue_id": queue_id},
                )
            seen.add(queue_id)
            occupancy = _non_negative_int(raw_entry[1], name=f"{name}.values[{entry_index}][1]")
            if occupancy == 0:
                raise ValidationError(
                    "sparse_nonzero snapshots must omit zero occupancies",
                    context={"queue_id": queue_id},
                )
            vector[queue_index(catalog, queue_id, name=f"{name} queue ID")] = occupancy
        return vector
    raise ValidationError(
        f"Unsupported {name} snapshot mode",
        context={"mode": mode, "allowed": ["dense", "sparse_nonzero", "disabled"]},
    )


def _event_queue_id(event: Any, *, catalog: Any, name: str) -> Any:
    try:
        queue_id = event.queue_id
    except Exception as exc:
        raise ValidationError(
            f"{name} must expose a generalized queue_id",
            context={"event_type": type(event).__name__},
        ) from exc
    queue_index(catalog, queue_id, name=f"{name}.queue_id")
    return queue_id


def _canonical_events(
    events: Iterable[_EventT],
    *,
    expected_type: type,
    catalog: Any,
    name: str,
) -> tuple[_EventT, ...]:
    if not isinstance(catalog, QueueCatalog):
        raise ValidationError("catalog must be a QueueCatalog")
    normalized = tuple(events)
    for index, event in enumerate(normalized):
        if not isinstance(event, expected_type):
            raise ValidationError(
                f"{name} must contain {expected_type.__name__} instances",
                context={"index": index, "value_type": type(event).__name__},
            )
        _event_queue_id(event, catalog=catalog, name=f"{name}[{index}]")
    return tuple(
        sorted(
            normalized,
            key=lambda event: (
                int(event.slot),
                catalog.index_of(event.queue_id),
                int(event.flow_id),
                int(event.packet_id),
            ),
        )
    )


def _packet_queue_map(events: Iterable[Any], *, catalog: QueueCatalog, name: str) -> dict[int, Any]:
    result: dict[int, Any] = {}
    for event in events:
        packet_id = int(event.packet_id)
        if packet_id in result:
            raise ValidationError(
                f"{name} contains a duplicate packet ID",
                context={"packet_id": packet_id},
            )
        result[packet_id] = _event_queue_id(event, catalog=catalog, name=name)
    return result


def _queue_id_counts(events: Iterable[Any], *, catalog: Any, accepted_only: bool = False) -> Counter[Any]:
    counts: Counter[Any] = Counter()
    for event in events:
        if accepted_only and not bool(getattr(event, "accepted", False)):
            continue
        counts[_event_queue_id(event, catalog=catalog, name="event")] += 1
    return counts


def _counts_payload(counts: Mapping[Any, int], *, catalog: Any) -> list[dict[str, JSONValue]]:
    return [
        {"queue_id": queue_id, "count": int(counts.get(queue_id, 0))}
        for queue_id in sorted(counts, key=catalog.index_of)
        if int(counts.get(queue_id, 0)) > 0
    ]


def _decision_queue_ids(decision: Any) -> tuple[Any, ...]:
    if not isinstance(decision, ServiceDecision):
        raise ValidationError(
            "service_decision must be a ServiceDecision",
            context={"value_type": type(decision).__name__},
        )
    return decision.selected_queue_ids


def _decision_payload(
    selected_queue_ids: tuple[Any, ...],
    *,
    scheduler_id: str | None,
    algorithm_id: str,
    optimizer_id: str | None,
) -> dict[str, JSONValue]:
    payload: dict[str, JSONValue] = {
        "format": "selected_queue_ids",
        "selected_queue_ids": list(selected_queue_ids),
        "algorithm_id": algorithm_id,
    }
    if scheduler_id is not None:
        payload["scheduler_id"] = scheduler_id
    if optimizer_id is not None:
        payload["optimizer_id"] = optimizer_id
    return payload


def _ratio(numerator: int, denominator: int) -> float:
    return 0.0 if denominator <= 0 else float(numerator) / float(denominator)


@dataclass(slots=True, frozen=True)
class GenericSlotRecord:
    """Canonical per-slot record for a topology-neutral queue catalog."""

    slot: Slot
    catalog: Any
    q_before: Any
    service_decision: Any
    algorithm_id: str
    departures: Iterable[DepartureEvent] = field(default_factory=tuple)
    completions: Iterable[CompletionEvent] = field(default_factory=tuple)
    offered_attempts: Iterable[ArrivalAttempt] = field(default_factory=tuple)
    admissions: Iterable[AdmissionDecision] = field(default_factory=tuple)
    q_after: Any = None
    queue_snapshot_mode: QueueSnapshotMode = "sparse_nonzero"
    arrival_outcome_id: str | None = None
    arrival_state_before: str | None = None
    arrival_state_after: str | None = None
    scheduler_id: str | None = None
    optimizer_id: str | None = None
    scheduler_state_before: Mapping[str, JSONValue] | None = None
    scheduler_state_after: Mapping[str, JSONValue] | None = None
    schedule_diagnostics: Mapping[str, JSONValue] | None = None
    schema_version: str = GENERIC_TELEMETRY_SCHEMA_VERSION

    schedule_metrics: Mapping[str, JSONValue] = field(init=False)
    slot_metrics: Mapping[str, JSONValue] = field(init=False)
    offered_by_queue: Mapping[Any, int] = field(init=False, repr=False)
    admitted_by_queue: Mapping[Any, int] = field(init=False, repr=False)
    dropped_by_queue: Mapping[Any, int] = field(init=False, repr=False)
    served_by_queue: Mapping[Any, int] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        slot = _non_negative_int(self.slot, name="slot")
        schema_version = _telemetry_schema_version(self.schema_version)
        if not isinstance(self.catalog, QueueCatalog):
            raise ValidationError("catalog must be a QueueCatalog")
        snapshot_mode = _snapshot_mode(self.queue_snapshot_mode)
        q_before_vector = coerce_queue_vector(
            self.q_before,
            catalog=self.catalog,
            name="q_before",
            copy=False,
        )
        q_after_vector = coerce_queue_vector(
            self.q_after,
            catalog=self.catalog,
            name="q_after",
            copy=False,
        )

        scheduler_id = _optional_identifier(self.scheduler_id, name="scheduler_id")
        algorithm_id = _identifier(self.algorithm_id, name="algorithm_id")
        optimizer_id = _optimizer_identifier(self.optimizer_id, algorithm_id=algorithm_id)
        arrival_outcome_id = _optional_identifier(
            self.arrival_outcome_id,
            name="arrival_outcome_id",
        )
        arrival_state_before = _optional_identifier(self.arrival_state_before, name="arrival_state_before")
        arrival_state_after = _optional_identifier(self.arrival_state_after, name="arrival_state_after")
        if (arrival_state_before is None) != (arrival_state_after is None):
            raise ValidationError("arrival_state_before and arrival_state_after must appear together")
        scheduler_state_before = _optional_mapping(self.scheduler_state_before, name="scheduler_state_before")
        scheduler_state_after = _optional_mapping(self.scheduler_state_after, name="scheduler_state_after")
        schedule_diagnostics = _optional_mapping(self.schedule_diagnostics, name="schedule_diagnostics")

        departures = _canonical_events(
            self.departures,
            expected_type=DepartureEvent,
            catalog=self.catalog,
            name="departures",
        )
        completions = _canonical_events(
            self.completions,
            expected_type=CompletionEvent,
            catalog=self.catalog,
            name="completions",
        )
        offered_attempts = _canonical_events(
            self.offered_attempts,
            expected_type=ArrivalAttempt,
            catalog=self.catalog,
            name="offered_attempts",
        )
        admissions = _canonical_events(
            self.admissions,
            expected_type=AdmissionDecision,
            catalog=self.catalog,
            name="admissions",
        )
        for collection_name, collection in (
            ("departures", departures),
            ("completions", completions),
            ("offered_attempts", offered_attempts),
            ("admissions", admissions),
        ):
            for index, event in enumerate(collection):
                if int(event.slot) != slot:
                    raise ValidationError(
                        f"{collection_name} must only contain events from this slot",
                        context={"slot": slot, "index": index, "event_slot": event.slot},
                    )

        offered_packets = _packet_queue_map(
            offered_attempts,
            catalog=self.catalog,
            name="offered_attempts",
        )
        admitted_packets = _packet_queue_map(
            admissions,
            catalog=self.catalog,
            name="admissions",
        )
        if offered_packets != admitted_packets:
            raise ValidationError(
                "Admission decisions must correspond exactly to offered attempts",
                context={
                    "offered_packet_queues": offered_packets,
                    "admission_packet_queues": admitted_packets,
                },
            )
        departure_packets = _packet_queue_map(
            departures,
            catalog=self.catalog,
            name="departures",
        )
        completion_packets = _packet_queue_map(
            completions,
            catalog=self.catalog,
            name="completions",
        )
        if departure_packets != completion_packets:
            raise ValidationError(
                "Completions must correspond exactly to departures",
                context={
                    "departure_packet_queues": departure_packets,
                    "completion_packet_queues": completion_packets,
                },
            )

        if not isinstance(self.service_decision, ServiceDecision):
            raise ValidationError(
                "service_decision must be a ServiceDecision",
                context={"value_type": type(self.service_decision).__name__},
            )
        canonical_decision = self.service_decision.canonical_for(self.catalog)
        selected_queue_ids = canonical_decision.selected_queue_ids
        selected_seen: set[Any] = set()
        for position, queue_id in enumerate(selected_queue_ids):
            queue_position = queue_index(self.catalog, queue_id, name=f"selected_queue_ids[{position}]")
            if queue_id in selected_seen:
                raise ValidationError(
                    "service_decision selects one queue more than once",
                    context={"queue_id": queue_id},
                )
            selected_seen.add(queue_id)
            if int(q_before_vector[queue_position]) <= 0:
                raise ValidationError(
                    "service_decision selects an empty queue",
                    context={"queue_id": queue_id},
                )

        offered_counts = _queue_id_counts(offered_attempts, catalog=self.catalog)
        admitted_counts = _queue_id_counts(admissions, catalog=self.catalog, accepted_only=True)
        dropped_counts = _queue_id_counts(
            (decision for decision in admissions if not decision.accepted),
            catalog=self.catalog,
        )
        served_counts = _queue_id_counts(departures, catalog=self.catalog)
        if any(count != 1 for count in served_counts.values()):
            raise ValidationError(
                "generalized service must remove at most one packet from each queue",
                context={"served_by_queue": dict(served_counts)},
            )
        if set(served_counts) != selected_seen:
            raise ValidationError(
                "departed queue IDs must equal selected queue IDs",
                context={
                    "selected_queue_ids": list(selected_queue_ids),
                    "departed_queue_ids": list(served_counts),
                },
            )

        expected_q_after = q_before_vector.copy()
        for queue_id in selected_queue_ids:
            expected_q_after[queue_index(self.catalog, queue_id)] -= 1
        for queue_id, count in admitted_counts.items():
            expected_q_after[queue_index(self.catalog, queue_id)] += int(count)
        if not np.array_equal(expected_q_after, q_after_vector):
            raise ValidationError(
                "q_after must equal q_before - service + admitted arrivals",
                context={
                    "q_before": q_before_vector.tolist(),
                    "selected_queue_ids": list(selected_queue_ids),
                    "admitted": _counts_payload(admitted_counts, catalog=self.catalog),
                    "expected_q_after": expected_q_after.tolist(),
                    "observed_q_after": q_after_vector.tolist(),
                },
            )

        primary_weight = sum(
            int(q_before_vector[queue_index(self.catalog, queue_id)])
            for queue_id in selected_queue_ids
        )
        schedule_metrics: dict[str, JSONValue] = {
            "selected_count": len(selected_queue_ids),
            "served_count": len(departures),
            "primary_maxweight_objective": int(primary_weight),
            "feasible": True,
        }
        if scheduler_id is not None:
            schedule_metrics["scheduler_id"] = scheduler_id
        schedule_metrics["algorithm_id"] = algorithm_id
        if optimizer_id is not None:
            schedule_metrics["optimizer_id"] = optimizer_id
        if schedule_diagnostics is not None:
            schedule_metrics["diagnostics"] = schedule_diagnostics

        offered_count = len(offered_attempts)
        admitted_count = sum(int(value) for value in admitted_counts.values())
        dropped_count = sum(int(value) for value in dropped_counts.values())
        slot_metrics: dict[str, JSONValue] = {
            "offered_count": offered_count,
            "admitted_count": admitted_count,
            "dropped_count": dropped_count,
            "completion_count": len(completions),
            "drop_fraction_of_offered": _ratio(dropped_count, offered_count),
            "total_q_before": int(np.sum(q_before_vector, dtype=np.int64)),
            "total_q_after": int(np.sum(q_after_vector, dtype=np.int64)),
        }

        object.__setattr__(self, "slot", slot)
        object.__setattr__(self, "schema_version", schema_version)
        object.__setattr__(self, "queue_snapshot_mode", snapshot_mode)
        object.__setattr__(self, "scheduler_id", scheduler_id)
        object.__setattr__(self, "algorithm_id", algorithm_id)
        object.__setattr__(self, "optimizer_id", optimizer_id)
        object.__setattr__(self, "arrival_outcome_id", arrival_outcome_id)
        object.__setattr__(self, "arrival_state_before", arrival_state_before)
        object.__setattr__(self, "arrival_state_after", arrival_state_after)
        object.__setattr__(self, "scheduler_state_before", scheduler_state_before)
        object.__setattr__(self, "scheduler_state_after", scheduler_state_after)
        object.__setattr__(self, "schedule_diagnostics", schedule_diagnostics)
        object.__setattr__(self, "departures", departures)
        object.__setattr__(self, "service_decision", canonical_decision)
        object.__setattr__(self, "completions", completions)
        object.__setattr__(self, "offered_attempts", offered_attempts)
        object.__setattr__(self, "admissions", admissions)
        object.__setattr__(self, "offered_by_queue", dict(offered_counts))
        object.__setattr__(self, "admitted_by_queue", dict(admitted_counts))
        object.__setattr__(self, "dropped_by_queue", dict(dropped_counts))
        object.__setattr__(self, "served_by_queue", dict(served_counts))
        object.__setattr__(self, "schedule_metrics", schedule_metrics)
        object.__setattr__(self, "slot_metrics", slot_metrics)
        object.__setattr__(
            self,
            "q_before",
            _serialize_validated_queue_vector(
                q_before_vector,
                catalog=self.catalog,
                mode=snapshot_mode,
            ),
        )
        object.__setattr__(
            self,
            "q_after",
            _serialize_validated_queue_vector(
                q_after_vector,
                catalog=self.catalog,
                mode=snapshot_mode,
            ),
        )

    @property
    def selected_queue_ids(self) -> tuple[Any, ...]:
        return _decision_queue_ids(self.service_decision)

    @property
    def selected_count(self) -> int:
        return int(self.schedule_metrics["selected_count"])

    @property
    def served_count(self) -> int:
        return int(self.schedule_metrics["served_count"])

    @property
    def primary_weight(self) -> int:
        return int(self.schedule_metrics["primary_maxweight_objective"])

    @property
    def primary_maxweight_objective(self) -> int:
        return self.primary_weight

    @property
    def offered_count(self) -> int:
        return int(self.slot_metrics["offered_count"])

    @property
    def admitted_count(self) -> int:
        return int(self.slot_metrics["admitted_count"])

    @property
    def loss_count(self) -> int:
        return int(self.slot_metrics["dropped_count"])

    @property
    def total_offered(self) -> int:
        return self.offered_count

    @property
    def total_admitted(self) -> int:
        return self.admitted_count

    @property
    def total_dropped(self) -> int:
        return self.loss_count

    def to_dict(self, *, include_packet_events: bool = True) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "schema_version": self.schema_version,
            "slot": self.slot,
            "q_before": self.q_before,
            "schedule": _decision_payload(
                self.selected_queue_ids,
                scheduler_id=self.scheduler_id,
                algorithm_id=self.algorithm_id,
                optimizer_id=self.optimizer_id,
            ),
            "arrivals": {
                "format": "queue_counts",
                "offered": _counts_payload(self.offered_by_queue, catalog=self.catalog),
                "admitted": _counts_payload(self.admitted_by_queue, catalog=self.catalog),
                "dropped": _counts_payload(self.dropped_by_queue, catalog=self.catalog),
            },
            "q_after": self.q_after,
            "schedule_metrics": normalize_for_json(dict(self.schedule_metrics)),
            "slot_metrics": normalize_for_json(dict(self.slot_metrics)),
        }
        if include_packet_events:
            payload["departures"] = [event_to_dict(event) for event in self.departures]
            payload["completions"] = [event_to_dict(event) for event in self.completions]
            payload["offered_attempts"] = [event_to_dict(event) for event in self.offered_attempts]
            payload["admissions"] = [event_to_dict(event) for event in self.admissions]
        if self.arrival_outcome_id is not None:
            payload["arrival_outcome_id"] = self.arrival_outcome_id
        if self.arrival_state_before is not None:
            payload["arrival_state_before"] = self.arrival_state_before
            payload["arrival_state_after"] = self.arrival_state_after
        if self.scheduler_state_before is not None:
            payload["scheduler_state_before"] = normalize_for_json(dict(self.scheduler_state_before))
        if self.scheduler_state_after is not None:
            payload["scheduler_state_after"] = normalize_for_json(dict(self.scheduler_state_after))
        return payload


@dataclass(slots=True)
class GenericSlotTraceBuilder:
    """Incrementally build one :class:`GenericSlotRecord`."""

    slot: Slot
    catalog: Any
    algorithm_id: str
    queue_snapshot_mode: QueueSnapshotMode = "sparse_nonzero"
    scheduler_id: str | None = None
    optimizer_id: str | None = None

    _q_before: Any = field(init=False, default=None, repr=False)
    _service_decision: Any = field(init=False, default=None, repr=False)
    _departures: tuple[DepartureEvent, ...] = field(init=False, default=(), repr=False)
    _completions: tuple[CompletionEvent, ...] = field(init=False, default=(), repr=False)
    _offered_attempts: tuple[ArrivalAttempt, ...] = field(init=False, default=(), repr=False)
    _admissions: tuple[AdmissionDecision, ...] = field(init=False, default=(), repr=False)
    _q_after: Any = field(init=False, default=None, repr=False)
    _arrival_outcome_id: str | None = field(init=False, default=None, repr=False)
    _arrival_state_before: str | None = field(init=False, default=None, repr=False)
    _arrival_state_after: str | None = field(init=False, default=None, repr=False)
    _scheduler_state_before: Mapping[str, JSONValue] | None = field(init=False, default=None, repr=False)
    _scheduler_state_after: Mapping[str, JSONValue] | None = field(init=False, default=None, repr=False)
    _schedule_diagnostics: Mapping[str, JSONValue] | None = field(init=False, default=None, repr=False)

    def __post_init__(self) -> None:
        self.slot = _non_negative_int(self.slot, name="slot")
        queue_ids_from_catalog(self.catalog)
        self.queue_snapshot_mode = _snapshot_mode(self.queue_snapshot_mode)  # type: ignore[assignment]
        self.scheduler_id = _optional_identifier(self.scheduler_id, name="scheduler_id")
        self.algorithm_id = _identifier(self.algorithm_id, name="algorithm_id")
        self.optimizer_id = _optimizer_identifier(
            self.optimizer_id,
            algorithm_id=self.algorithm_id,
        )

    def set_q_before(self, q_len: Any) -> GenericSlotTraceBuilder:
        if self._q_before is not None:
            raise ValidationError("q_before has already been set", context={"slot": self.slot})
        self._q_before = q_len
        return self

    def set_service_decision(self, decision: Any) -> GenericSlotTraceBuilder:
        if self._service_decision is not None:
            raise ValidationError("service_decision has already been set", context={"slot": self.slot})
        _decision_queue_ids(decision)
        self._service_decision = decision
        return self

    def set_schedule(self, decision: Any) -> GenericSlotTraceBuilder:
        """Compatibility spelling for kernel call sites."""

        return self.set_service_decision(decision)

    def set_scheduler_identity(
        self,
        scheduler_id: str,
        *,
        algorithm_id: str,
        optimizer_id: str | None = None,
    ) -> GenericSlotTraceBuilder:
        self.scheduler_id = _optional_identifier(scheduler_id, name="scheduler_id")
        self.algorithm_id = _identifier(algorithm_id, name="algorithm_id")
        self.optimizer_id = _optimizer_identifier(
            optimizer_id,
            algorithm_id=self.algorithm_id,
        )
        return self

    def set_schedule_diagnostics(self, diagnostics: Mapping[str, Any] | None) -> GenericSlotTraceBuilder:
        self._schedule_diagnostics = _optional_mapping(diagnostics, name="schedule_diagnostics")
        return self

    def set_scheduler_state_before(self, state: Mapping[str, Any] | None) -> GenericSlotTraceBuilder:
        if self._scheduler_state_before is not None:
            raise ValidationError("scheduler_state_before has already been set", context={"slot": self.slot})
        self._scheduler_state_before = _optional_mapping(state, name="scheduler_state_before")
        return self

    def set_scheduler_state_after(self, state: Mapping[str, Any] | None) -> GenericSlotTraceBuilder:
        if self._scheduler_state_after is not None:
            raise ValidationError("scheduler_state_after has already been set", context={"slot": self.slot})
        self._scheduler_state_after = _optional_mapping(state, name="scheduler_state_after")
        return self

    def add_departures(self, departures: Iterable[DepartureEvent]) -> GenericSlotTraceBuilder:
        self._departures += tuple(departures)
        return self

    def add_completions(self, completions: Iterable[CompletionEvent]) -> GenericSlotTraceBuilder:
        self._completions += tuple(completions)
        return self

    def set_offered_attempts(self, attempts: Iterable[ArrivalAttempt]) -> GenericSlotTraceBuilder:
        if self._offered_attempts:
            raise ValidationError("offered_attempts have already been set", context={"slot": self.slot})
        self._offered_attempts = tuple(attempts)
        return self

    def add_offered_attempts(self, attempts: Iterable[ArrivalAttempt]) -> GenericSlotTraceBuilder:
        self._offered_attempts += tuple(attempts)
        return self

    def set_admissions(self, admissions: Iterable[AdmissionDecision]) -> GenericSlotTraceBuilder:
        if self._admissions:
            raise ValidationError("admissions have already been set", context={"slot": self.slot})
        self._admissions = tuple(admissions)
        return self

    def add_admissions(self, admissions: Iterable[AdmissionDecision]) -> GenericSlotTraceBuilder:
        self._admissions += tuple(admissions)
        return self

    def set_arrival_sample(self, sample: Any) -> GenericSlotTraceBuilder:
        if int(sample.slot) != self.slot:
            raise ValidationError(
                "arrival sample slot does not match builder slot",
                context={"slot": self.slot, "sample_slot": sample.slot},
            )
        self._arrival_outcome_id = getattr(sample, "arrival_outcome_id", None)
        self._arrival_state_before = getattr(sample, "state_before", None)
        self._arrival_state_after = getattr(sample, "state_after", None)
        return self

    def set_materialized_arrival(self, materialized: Any) -> GenericSlotTraceBuilder:
        if int(materialized.slot) != self.slot:
            raise ValidationError(
                "materialized arrival slot does not match builder slot",
                context={"slot": self.slot, "materialized_slot": materialized.slot},
            )
        sample = getattr(materialized, "sample", None)
        if sample is not None:
            self.set_arrival_sample(sample)
        return self.set_offered_attempts(materialized.attempts)

    def set_q_after(self, q_len: Any) -> GenericSlotTraceBuilder:
        if self._q_after is not None:
            raise ValidationError("q_after has already been set", context={"slot": self.slot})
        self._q_after = q_len
        return self

    def finalize(self) -> GenericSlotRecord:
        missing = [
            name
            for name, value in (
                ("q_before", self._q_before),
                ("service_decision", self._service_decision),
                ("q_after", self._q_after),
            )
            if value is None
        ]
        if missing:
            raise ValidationError(
                "Cannot finalize an incomplete generalized slot record",
                context={"slot": self.slot, "missing": missing},
            )
        return GenericSlotRecord(
            slot=self.slot,
            catalog=self.catalog,
            q_before=self._q_before,
            service_decision=self._service_decision,
            algorithm_id=self.algorithm_id,
            departures=self._departures,
            completions=self._completions,
            offered_attempts=self._offered_attempts,
            admissions=self._admissions,
            q_after=self._q_after,
            queue_snapshot_mode=self.queue_snapshot_mode,
            arrival_outcome_id=self._arrival_outcome_id,
            arrival_state_before=self._arrival_state_before,
            arrival_state_after=self._arrival_state_after,
            scheduler_id=self.scheduler_id,
            optimizer_id=self.optimizer_id,
            scheduler_state_before=self._scheduler_state_before,
            scheduler_state_after=self._scheduler_state_after,
            schedule_diagnostics=self._schedule_diagnostics,
        )

    def to_slot_record(self) -> GenericSlotRecord:
        return self.finalize()


__all__ = [
    "GENERIC_TELEMETRY_SCHEMA_VERSION",
    "GenericQueueSnapshot",
    "GenericSlotRecord",
    "GenericSlotTraceBuilder",
    "queue_ids_from_catalog",
    "queue_index",
    "coerce_queue_vector",
    "serialize_queue_vector_snapshot",
    "deserialize_queue_vector_snapshot",
]
