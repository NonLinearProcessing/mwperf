from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, TextIO

import numpy as np

from ..config import SimConfig, dump_resolved_config, resolved_config_to_dict
from ..errors import ValidationError
from ..flows import FlowPlan, QueueFlowPlan
from ..manifest import (
    MANIFEST_SCHEMA_VERSION,
    RunManifest,
    build_service_model,
    hash_flow_plan,
    hash_resolved_config,
    hash_service_model,
    write_run_manifest,
    write_service_model,
)
from ..rng import ARRIVAL_CATEGORICAL_SAMPLER, RNG_ENGINE_NAME, SEED_SCHEME_VERSION
from ..schedulers.registry import build_scheduler
from ..traffic.compiler import CompiledArrivalSpec, compile_arrival_spec
from ..types import JSONValue
from ..utils import canonical_json_dumps, normalize_for_json
from ..version import SIMULATOR_VERSION
from .generic import GenericSlotRecord
from .schema import build_arrival_support_artifact, flow_plan_artifact

DEFAULT_SLOT_TRACE_FILENAME = "telemetry.jsonl"
DEFAULT_RUN_SUMMARY_FILENAME = "run_summary.json"
DEFAULT_FLOW_PLAN_FILENAME = "flow_plan.json"
DEFAULT_ARRIVAL_SUPPORT_FILENAME = "arrival_support.json"
DEFAULT_RESOLVED_CONFIG_FILENAME = "resolved_config.yaml"
DEFAULT_RUN_MANIFEST_FILENAME = "run_manifest.json"
DEFAULT_SERVICE_MODEL_FILENAME = "service_model.json"


def _coerce_path(value: str | Path, *, name: str) -> Path:
    if not isinstance(value, (str, Path)):
        raise ValidationError(
            f"{name} must be a filesystem path",
            context={"value_type": type(value).__name__},
        )
    return Path(value)


def _record_payload(record: GenericSlotRecord | Mapping[str, Any]) -> dict[str, JSONValue]:
    if isinstance(record, GenericSlotRecord):
        return record.to_dict()
    if isinstance(record, Mapping):
        normalized = normalize_for_json(dict(record))
        if not isinstance(normalized, dict):  # pragma: no cover - defensive only
            raise ValidationError("normalized slot record unexpectedly became non-dict")
        return normalized
    raise ValidationError(
        "record must be a GenericSlotRecord or mapping",
        context={"value_type": type(record).__name__},
    )


def _summary_payload(summary: Any) -> dict[str, JSONValue]:
    if isinstance(summary, Mapping):
        normalized = normalize_for_json(dict(summary))
        if not isinstance(normalized, dict):  # pragma: no cover - defensive only
            raise ValidationError("normalized summary unexpectedly became non-dict")
        return normalized
    to_dict = getattr(summary, "to_dict", None)
    if callable(to_dict):
        normalized = normalize_for_json(to_dict())
        if not isinstance(normalized, dict):  # pragma: no cover - defensive only
            raise ValidationError("summary.to_dict() unexpectedly normalized to a non-dict")
        return normalized
    raise ValidationError(
        "summary must be a mapping or summary-like object with to_dict()",
        context={"value_type": type(summary).__name__},
    )


def write_canonical_json(payload: Any, out_path: str | Path) -> Path:
    """Write one canonical JSON object terminated by a single newline."""

    path = _coerce_path(out_path, name="out_path")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_json_dumps(payload) + "\n", encoding="utf-8")
    return path


# Backward-compatible alias retained for artifact writing helpers.
write_json_artifact = write_canonical_json


@dataclass(slots=True)
class JsonlWriter:
    """Streaming canonical JSONL writer for per-slot telemetry records."""

    target: str | Path | TextIO
    append: bool = False
    include_packet_events: bool = True

    path: Path | None = field(init=False, default=None)
    _fh: TextIO = field(init=False, repr=False)
    _owns_handle: bool = field(init=False, default=False, repr=False)

    def __post_init__(self) -> None:
        target = self.target
        if isinstance(target, (str, Path)):
            path = _coerce_path(target, name="target")
            path.parent.mkdir(parents=True, exist_ok=True)
            mode = "a" if self.append else "w"
            handle = path.open(mode, encoding="utf-8", newline="")
            object.__setattr__(self, "path", path)
            object.__setattr__(self, "_fh", handle)
            object.__setattr__(self, "_owns_handle", True)
            return

        write = getattr(target, "write", None)
        if not callable(write):
            raise ValidationError(
                "target must be a filesystem path or writable text stream",
                context={"value_type": type(target).__name__},
            )
        object.__setattr__(self, "path", None)
        object.__setattr__(self, "_fh", target)
        object.__setattr__(self, "_owns_handle", False)

    def write_slot(self, record: GenericSlotRecord | Mapping[str, Any]) -> None:
        if isinstance(record, GenericSlotRecord):
            payload = record.to_dict(include_packet_events=self.include_packet_events)
        else:
            payload = _record_payload(record)
            if not self.include_packet_events:
                for field_name in ("departures", "completions", "offered_attempts", "admissions"):
                    payload.pop(field_name, None)
        self._fh.write(canonical_json_dumps(payload) + "\n")
        flush = getattr(self._fh, "flush", None)
        if callable(flush):
            flush()

    def write_slots(self, records: list[GenericSlotRecord | Mapping[str, Any]]) -> None:
        for record in records:
            self.write_slot(record)

    def flush(self) -> None:
        flush = getattr(self._fh, "flush", None)
        if callable(flush):
            flush()

    def close(self) -> None:
        if self._owns_handle:
            self._fh.close()

    def __enter__(self) -> "JsonlWriter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


@dataclass(slots=True)
class SummaryWriter:
    """Canonical JSON writer for run-summary payloads."""

    path: str | Path

    def write(self, summary: Any) -> Path:
        return write_canonical_json(_summary_payload(summary), self.path)

    def write_summary(self, summary: Any) -> Path:
        return self.write(summary)


def write_flow_plan_artifact(
    flow_plan: FlowPlan | QueueFlowPlan | Mapping[str, Any],
    out_path: str | Path,
) -> Path:
    return write_canonical_json(flow_plan_artifact(flow_plan), out_path)


# Backward-compatible alias retained for artifact-writing helpers.
write_flow_plan_json = write_flow_plan_artifact


def write_arrival_support_artifact(
    compiled_arrival: CompiledArrivalSpec | Mapping[str, Any],
    out_path: str | Path,
) -> Path:
    payload = (
        build_arrival_support_artifact(compiled_arrival)
        if isinstance(compiled_arrival, CompiledArrivalSpec)
        else normalize_for_json(dict(compiled_arrival))
    )
    if not isinstance(payload, dict):  # pragma: no cover - defensive only
        raise ValidationError("arrival support artifact must normalize to a mapping")
    return write_canonical_json(payload, out_path)


# Backward-compatible alias retained for artifact-writing helpers.
write_arrival_support_json = write_arrival_support_artifact
build_arrival_support_payload = build_arrival_support_artifact


def write_service_model_artifact(service_model: Mapping[str, Any], out_path: str | Path) -> Path:
    """Write the canonical topology/service definition for a run."""

    if not isinstance(service_model, Mapping):
        raise ValidationError(
            "service_model must be a mapping",
            context={"value_type": type(service_model).__name__},
        )
    return write_service_model(normalize_for_json(dict(service_model)), out_path)


def write_static_run_artifacts(
    out_dir: str | Path,
    *,
    config: SimConfig,
    actual_seed: int,
    manifest: RunManifest,
    flow_plan: FlowPlan | QueueFlowPlan | None = None,
    compiled_arrival: CompiledArrivalSpec | None = None,
    service_model: Mapping[str, Any] | None = None,
    include_arrival_support: bool = True,
) -> dict[str, Path]:
    """Write the deterministic static artifacts associated with one simulator run."""

    if not isinstance(config, SimConfig):
        raise ValidationError(
            "config must be a SimConfig",
            context={"value_type": type(config).__name__},
        )
    if not isinstance(manifest, RunManifest):
        raise ValidationError(
            "manifest must be a RunManifest",
            context={"value_type": type(manifest).__name__},
        )
    from ..validation import validate_actual_seed, validate_config

    validate_config(config)
    concrete_seed = validate_actual_seed(actual_seed)
    if config.run.actual_seed is not None and config.run.actual_seed != concrete_seed:
        raise ValidationError(
            "actual_seed disagrees with config.run.actual_seed",
            context={
                "actual_seed": concrete_seed,
                "config_actual_seed": config.run.actual_seed,
            },
        )
    if config.run.seed >= 0 and config.run.seed != concrete_seed:
        raise ValidationError(
            "actual_seed must equal the fixed config.run.seed",
            context={
                "actual_seed": concrete_seed,
                "run_seed": config.run.seed,
            },
        )
    # Force normalization of every manifest field before touching the output
    # path; unsupported metadata must not leave a partial replay bundle.
    normalized_manifest = normalize_for_json(manifest.to_dict())
    if not isinstance(normalized_manifest, dict):  # pragma: no cover - defensive
        raise ValidationError("manifest must normalize to an object")

    out_path = _coerce_path(out_dir, name="out_dir")

    # Resolve and validate the entire replay bundle before creating its output
    # directory.  The resolved config is authoritative; redundant manifest
    # fields and caller-supplied derived artifacts must agree with it exactly.
    expected_service_model = normalize_for_json(build_service_model(config))
    effective_service_model = (
        expected_service_model
        if service_model is None
        else normalize_for_json(dict(service_model))
    )
    if not isinstance(effective_service_model, dict):  # pragma: no cover - defensive
        raise ValidationError("service_model must normalize to an object")
    if canonical_json_dumps(effective_service_model) != canonical_json_dumps(expected_service_model):
        raise ValidationError("service_model does not match the resolved config")

    expected_compiled_arrival = compile_arrival_spec(
        config,
        actual_seed=concrete_seed,
        validate=False,
    )
    expected_flow_payload = expected_compiled_arrival.flow_plan.to_dict()

    effective_flow_plan = flow_plan
    if effective_flow_plan is None and compiled_arrival is not None:
        effective_flow_plan = compiled_arrival.flow_plan
    if effective_flow_plan is None:
        raise ValidationError(
            "flow_plan is required unless compiled_arrival is provided",
            context={"include_arrival_support": include_arrival_support},
        )
    effective_flow_payload = effective_flow_plan.to_dict()
    if canonical_json_dumps(effective_flow_payload) != canonical_json_dumps(expected_flow_payload):
        raise ValidationError("flow_plan does not match the resolved config")
    if compiled_arrival is not None:
        compiled_flow_payload = compiled_arrival.flow_plan.to_dict()
        if canonical_json_dumps(effective_flow_payload) != canonical_json_dumps(compiled_flow_payload):
            raise ValidationError("flow_plan does not match compiled_arrival.flow_plan")
        observed_arrival_support = build_arrival_support_artifact(compiled_arrival)
        expected_arrival_support = build_arrival_support_artifact(expected_compiled_arrival)
        if canonical_json_dumps(observed_arrival_support) != canonical_json_dumps(expected_arrival_support):
            raise ValidationError("compiled_arrival does not match the resolved config")

    expected_scheduler = build_scheduler(
        config.scheduler.name,
        config.scheduler.params,
    )
    expected_optimizer_id = getattr(expected_scheduler, "optimizer_id", None)
    expected_manifest_fields: dict[str, Any] = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "rng_engine": RNG_ENGINE_NAME,
        "rng_seed_scheme_version": SEED_SCHEME_VERSION,
        "numpy_version": np.__version__,
        "arrival_categorical_sampler": ARRIVAL_CATEGORICAL_SAMPLER,
        "simulator_version": SIMULATOR_VERSION,
        "requested_seed": config.run.seed,
        "actual_seed": concrete_seed,
        "config_schema_version": config.schema_version,
        "switch_kind": config.switch.kind,
        "n_queues": config.switch.n_queues,
        "service_family": config.scheduler.service_family,
        "scheduler_name": config.scheduler.name,
        "scheduler_algorithm_id": expected_scheduler.algorithm_id,
        "scheduler_optimizer_id": expected_optimizer_id,
        "scheduler_params": normalize_for_json(config.scheduler.params),
        "config_hash": hash_resolved_config(
            resolved_config_to_dict(config, actual_seed=concrete_seed)
        ),
        "flow_plan_hash": hash_flow_plan(effective_flow_payload),
        "service_model_hash": hash_service_model(effective_service_model),
    }
    for field_name, expected_value in expected_manifest_fields.items():
        observed_value = getattr(manifest, field_name)
        if canonical_json_dumps(observed_value) != canonical_json_dumps(expected_value):
            raise ValidationError(
                f"manifest {field_name} does not match the resolved run bundle",
                context={
                    "field": field_name,
                    "manifest_value": normalize_for_json(observed_value),
                    "expected_value": normalize_for_json(expected_value),
                },
            )

    observed_service_model_hash = hash_service_model(effective_service_model)
    if manifest.service_model_hash != observed_service_model_hash:  # defensive clarity after field loop
        raise ValidationError(
            "manifest service_model_hash does not match the service model artifact",
            context={
                "manifest_hash": manifest.service_model_hash,
                "observed_hash": observed_service_model_hash,
            },
        )

    if include_arrival_support and compiled_arrival is None:
        raise ValidationError(
            "compiled_arrival is required when include_arrival_support is True",
            context={"include_arrival_support": include_arrival_support},
        )

    out_path.mkdir(parents=True, exist_ok=True)
    if not include_arrival_support:
        # Reusing an output directory must not leave a support artifact from a
        # different run when this bundle explicitly omits it.
        (out_path / DEFAULT_ARRIVAL_SUPPORT_FILENAME).unlink(missing_ok=True)
    resolved_path = dump_resolved_config(config, concrete_seed, out_path / DEFAULT_RESOLVED_CONFIG_FILENAME)
    service_model_path = write_service_model_artifact(
        effective_service_model,
        out_path / DEFAULT_SERVICE_MODEL_FILENAME,
    )
    manifest_path = write_run_manifest(manifest, out_path / DEFAULT_RUN_MANIFEST_FILENAME)

    flow_plan_path = write_flow_plan_artifact(effective_flow_plan, out_path / DEFAULT_FLOW_PLAN_FILENAME)

    written: dict[str, Path] = {
        "resolved_config": resolved_path,
        "run_manifest": manifest_path,
        "service_model": service_model_path,
        "flow_plan": flow_plan_path,
    }

    if include_arrival_support:
        assert compiled_arrival is not None  # validated before filesystem mutation
        arrival_support_path = write_arrival_support_artifact(
            compiled_arrival,
            out_path / DEFAULT_ARRIVAL_SUPPORT_FILENAME,
        )
        written["arrival_support"] = arrival_support_path

    return written


__all__ = [
    "DEFAULT_SLOT_TRACE_FILENAME",
    "DEFAULT_RUN_SUMMARY_FILENAME",
    "DEFAULT_FLOW_PLAN_FILENAME",
    "DEFAULT_ARRIVAL_SUPPORT_FILENAME",
    "DEFAULT_RESOLVED_CONFIG_FILENAME",
    "DEFAULT_RUN_MANIFEST_FILENAME",
    "DEFAULT_SERVICE_MODEL_FILENAME",
    "write_canonical_json",
    "write_json_artifact",
    "JsonlWriter",
    "SummaryWriter",
    "write_flow_plan_artifact",
    "write_flow_plan_json",
    "write_arrival_support_artifact",
    "write_arrival_support_json",
    "build_arrival_support_payload",
    "write_service_model_artifact",
    "write_static_run_artifacts",
]
