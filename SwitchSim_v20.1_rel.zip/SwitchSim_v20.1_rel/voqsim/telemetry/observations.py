"""Compact scientific observations for measured queue trajectories.

This module deliberately does not depend on the JSONL slot trace.  It stores
only additive sufficient statistics at exact backlog levels and the boundary
distributions needed for finite-window analysis.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
import heapq
import json
import math
from numbers import Integral
from pathlib import Path
import sqlite3
import struct
from typing import Any, Iterable, Iterator, Mapping, Sequence
from urllib.parse import quote

from ..errors import ValidationError
from ..utils import canonical_json_dumps, normalize_for_json


OBSERVATION_FORMAT_VERSION = "2.0"
BINARY64_LATTICE_EXPONENT = -1074
BINARY64_NORMALIZED_MASS = 1 << -BINARY64_LATTICE_EXPONENT

MASS_INTEGER = "integer"
MASS_BINARY64_LATTICE = "binary64_lattice"

GAP_NONE = "none"
GAP_EXACT = "exact"

STATUS_WRITING = "writing"
STATUS_COMPLETE = "complete"
STATUS_FAILED = "failed"

_SQLITE_INT_MAX = (1 << 63) - 1
_MISSING = object()


def _nonnegative_int(value: Any, *, name: str, sqlite_sized: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be nonnegative", context={"value": result})
    if sqlite_sized and result > _SQLITE_INT_MAX:
        raise ValidationError(
            f"{name} is not representable by the observation format",
            context={"value": result},
        )
    return result


def _optional_exact_gap(
    value: Any,
    *,
    backlog: int,
    served: int,
    name: str = "gap",
) -> int | None:
    """Validate one optional exact gap against the observed decision.

    A missing value means that gap collection was not requested.  When a gap
    is present, the inexpensive pointwise certificate consequences are checked
    again at the telemetry boundary so malformed sampler input cannot enter a
    scientific record.
    """

    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer or null", context={"value": value})
    gap = int(value)
    if gap > backlog:
        raise ValidationError(
            "exact gap implies a negative competition value",
            context={"backlog": backlog, "gap": gap},
        )
    if backlog == 0:
        if served != 0 or gap > 0:  # served is defensive; the base check rejects it first.
            raise ValidationError(
                "an empty exact-gap target cannot be served or have a positive gap",
                context={"backlog": backlog, "served": served, "gap": gap},
            )
    elif gap > 0 and served != 1:
        raise ValidationError(
            "a positive exact gap at positive backlog requires service",
            context={"backlog": backlog, "served": served, "gap": gap},
        )
    elif gap < 0 and served != 0:
        raise ValidationError(
            "a negative exact gap at positive backlog forbids service",
            context={"backlog": backlog, "served": served, "gap": gap},
        )
    return gap


def _gap_contribution(gap: int, served: int, mass: int) -> tuple[int, int, int, int, int, int]:
    """Return ``(L-, L0, L+, T, sum(G+), sum(G-))`` for one sample."""

    if gap < 0:
        return mass, 0, 0, 0, 0, mass * -gap
    if gap > 0:
        return 0, 0, mass, 0, mass * gap, 0
    return 0, mass, 0, mass * served, 0, 0


def _scientific_pooling_key(metadata: Mapping[str, Any]) -> str:
    """Canonicalize scientific conditions while removing replication identity."""

    normalized = normalize_for_json(dict(metadata))
    if not isinstance(normalized, dict):
        raise ValidationError("observation metadata must be a mapping")
    # ``normalize_for_json`` returns fresh containers and deliberately retains
    # Decimal number tokens.  Mutating this copy avoids a binary64 or string
    # round trip before the scientific pooling key is formed.
    copied = normalized
    for key in ("actual_seed", "requested_seed", "ensemble_id"):
        copied.pop(key, None)
    scientific = copied.get("scientific_config")
    if isinstance(scientific, dict):
        run = scientific.get("run")
        if isinstance(run, dict):
            for key in ("seed", "actual_seed", "requested_seed"):
                run.pop(key, None)
    return canonical_json_dumps(copied)


def _pooling_unit_identity(state: "RunObservationState") -> tuple[Any, ...] | None:
    metadata = state.metadata
    if state.unit_kind == "simulator_run":
        value = metadata.get("actual_seed")
        if isinstance(value, bool) or not isinstance(value, Integral) or int(value) < 0:
            return None
        return (state.unit_kind, int(value))
    if state.unit_kind == "weighted_ensemble":
        seed = metadata.get("actual_seed")
        ensemble_id = metadata.get("ensemble_id")
        if isinstance(seed, bool) or not isinstance(seed, Integral) or int(seed) < 0:
            return None
        if isinstance(ensemble_id, bool) or not isinstance(ensemble_id, (Integral, str)):
            return None
        if isinstance(ensemble_id, Integral) and int(ensemble_id) < 0:
            return None
        if isinstance(ensemble_id, str) and not ensemble_id:
            return None
        return (state.unit_kind, int(seed), int(ensemble_id) if isinstance(ensemble_id, Integral) else ensemble_id)
    return None


def encode_bigint(value: int) -> bytes:
    """Encode an arbitrary-precision integer in one canonical representation."""

    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError("big integer value must be an integer", context={"value": value})
    number = int(value)
    if number == 0:
        return b"\x00"
    sign = b"\x01" if number > 0 else b"\x02"
    magnitude = abs(number)
    payload = magnitude.to_bytes((magnitude.bit_length() + 7) // 8, "big")
    return sign + payload


def decode_bigint(payload: bytes | bytearray | memoryview) -> int:
    """Decode and validate :func:`encode_bigint` output."""

    raw = bytes(payload)
    if raw == b"\x00":
        return 0
    if len(raw) < 2 or raw[0] not in (1, 2) or raw[1] == 0:
        raise ValidationError("non-canonical arbitrary-precision integer encoding")
    magnitude = int.from_bytes(raw[1:], "big")
    value = magnitude if raw[0] == 1 else -magnitude
    if encode_bigint(value) != raw:
        raise ValidationError("non-canonical arbitrary-precision integer encoding")
    return value


def binary64_lattice_numerator(value: float) -> int:
    """Return the exact numerator of finite ``value`` on the ``2**-1074`` lattice.

    Positive and negative zero both map to zero.  Observation weights must be
    nonnegative; negative values, infinities, and NaNs are rejected.
    """

    if isinstance(value, bool) or not isinstance(value, float):
        raise ValidationError("weight must be a binary64 float", context={"value": value})
    bits = struct.unpack(">Q", struct.pack(">d", value))[0]
    sign = bits >> 63
    exponent = (bits >> 52) & 0x7FF
    fraction = bits & ((1 << 52) - 1)
    if exponent == 0x7FF:
        raise ValidationError("weight must be finite", context={"value": value})
    if exponent == 0 and fraction == 0:
        return 0
    if sign:
        raise ValidationError("weight must be nonnegative", context={"value": value})
    if exponent == 0:
        return fraction
    return ((1 << 52) | fraction) << (exponent - 1)


def binary64_lattice_value(numerator: int) -> float:
    """Convert a lattice numerator for presentation, rounding only here."""

    if isinstance(numerator, bool) or not isinstance(numerator, Integral):
        raise ValidationError("numerator must be an integer", context={"value": numerator})
    try:
        return float(Fraction(int(numerator), 1 << -BINARY64_LATTICE_EXPONENT))
    except OverflowError:
        return math.inf if int(numerator) >= 0 else -math.inf


@dataclass(frozen=True, slots=True)
class ObservationTarget:
    """One selected queue and the additive-mass representation it uses."""

    target_id: str
    queue_id: Any
    mass_kind: str = MASS_INTEGER
    gap_mode: str = GAP_NONE

    def __post_init__(self) -> None:
        if not isinstance(self.target_id, str) or not self.target_id:
            raise ValidationError("target_id must be a nonempty string")
        if self.mass_kind not in {MASS_INTEGER, MASS_BINARY64_LATTICE}:
            raise ValidationError(
                "unsupported observation mass kind",
                context={"mass_kind": self.mass_kind},
            )
        if self.gap_mode not in {GAP_NONE, GAP_EXACT}:
            raise ValidationError(
                "unsupported observation gap mode",
                context={"gap_mode": self.gap_mode},
            )
        if isinstance(self.queue_id, bool) or not isinstance(self.queue_id, (int, str)):
            raise ValidationError(
                "queue_id must be an integer or string queue identifier",
                context={"queue_id": self.queue_id},
            )


@dataclass(frozen=True, slots=True)
class ObservationBlock:
    block_id: int
    start_slot: int
    stop_slot: int

    def __post_init__(self) -> None:
        block_id = _nonnegative_int(self.block_id, name="block_id", sqlite_sized=True)
        start = _nonnegative_int(self.start_slot, name="start_slot", sqlite_sized=True)
        stop = _nonnegative_int(self.stop_slot, name="stop_slot", sqlite_sized=True)
        if stop <= start:
            raise ValidationError(
                "observation block must be nonempty",
                context={"start_slot": start, "stop_slot": stop},
            )
        object.__setattr__(self, "block_id", block_id)
        object.__setattr__(self, "start_slot", start)
        object.__setattr__(self, "stop_slot", stop)


@dataclass(frozen=True, slots=True)
class StoredObservationTarget:
    target_id: str
    queue_id: Any
    mass_kind: str
    gap_mode: str


def make_observation_blocks(
    window_start: int,
    window_stop: int,
    block_slots: int | None = None,
) -> tuple[ObservationBlock, ...]:
    """Partition ``[window_start, window_stop)`` into consecutive blocks."""

    start = _nonnegative_int(window_start, name="window_start", sqlite_sized=True)
    stop = _nonnegative_int(window_stop, name="window_stop", sqlite_sized=True)
    if stop <= start:
        raise ValidationError("measurement window must be nonempty")
    width = stop - start if block_slots is None else _nonnegative_int(block_slots, name="block_slots")
    if width <= 0:
        raise ValidationError("block_slots must be positive")
    blocks: list[ObservationBlock] = []
    cursor = start
    while cursor < stop:
        next_cursor = min(cursor + width, stop)
        blocks.append(ObservationBlock(len(blocks), cursor, next_cursor))
        cursor = next_cursor
    return tuple(blocks)


@dataclass(frozen=True, slots=True)
class TargetSlotObservation:
    """One target queue's complete contribution from one committed slot."""

    target_id: str
    backlog_before: int
    backlog_after: int
    served: int
    offered: int
    admitted: int
    dropped: int
    gap: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.target_id, str) or not self.target_id:
            raise ValidationError("target_id must be a nonempty string")
        for field_name in (
            "backlog_before",
            "backlog_after",
            "served",
            "offered",
            "admitted",
            "dropped",
        ):
            value = _nonnegative_int(getattr(self, field_name), name=field_name, sqlite_sized=field_name.startswith("backlog"))
            object.__setattr__(self, field_name, value)
        if self.served not in (0, 1) or self.served > self.backlog_before:
            raise ValidationError(
                "served must be a feasible binary departure",
                context={"target_id": self.target_id, "served": self.served},
            )
        if self.offered != self.admitted + self.dropped:
            raise ValidationError("offered arrivals must equal admitted arrivals plus drops", context={"target_id": self.target_id})
        if self.backlog_after != self.backlog_before - self.served + self.admitted:
            raise ValidationError("target queue conservation failed", context={"target_id": self.target_id})
        object.__setattr__(
            self,
            "gap",
            _optional_exact_gap(
                self.gap,
                backlog=self.backlog_before,
                served=self.served,
            ),
        )


@dataclass(frozen=True, slots=True)
class WeightedTargetSample:
    """One weighted decision-time particle contribution for one target."""

    target_id: str
    backlog: int
    weight_numerator: int
    served: int
    offered: int = 0
    admitted: int = 0
    dropped: int = 0
    gap: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.target_id, str) or not self.target_id:
            raise ValidationError("target_id must be a nonempty string")
        backlog = _nonnegative_int(self.backlog, name="backlog", sqlite_sized=True)
        numerator = _nonnegative_int(self.weight_numerator, name="weight_numerator")
        served = _nonnegative_int(self.served, name="served")
        offered = _nonnegative_int(self.offered, name="offered")
        admitted = _nonnegative_int(self.admitted, name="admitted")
        dropped = _nonnegative_int(self.dropped, name="dropped")
        if served not in (0, 1) or served > backlog:
            raise ValidationError(
                "served must be a feasible binary departure",
                context={"target_id": self.target_id, "served": served},
            )
        if offered != admitted + dropped:
            raise ValidationError("offered arrivals must equal admitted arrivals plus drops", context={"target_id": self.target_id})
        object.__setattr__(self, "backlog", backlog)
        object.__setattr__(self, "weight_numerator", numerator)
        object.__setattr__(self, "served", served)
        object.__setattr__(self, "offered", offered)
        object.__setattr__(self, "admitted", admitted)
        object.__setattr__(self, "dropped", dropped)
        object.__setattr__(
            self,
            "gap",
            _optional_exact_gap(self.gap, backlog=backlog, served=served),
        )

    @classmethod
    def from_binary64(
        cls,
        *,
        target_id: str,
        backlog: int,
        weight: float,
        served: int,
        offered: int = 0,
        admitted: int = 0,
        dropped: int = 0,
        gap: int | None = None,
    ) -> "WeightedTargetSample":
        return cls(
            target_id=target_id,
            backlog=backlog,
            weight_numerator=binary64_lattice_numerator(weight),
            served=served,
            offered=offered,
            admitted=admitted,
            dropped=dropped,
            gap=gap,
        )


@dataclass(frozen=True, slots=True)
class WeightedBoundarySample:
    target_id: str
    backlog: int
    weight_numerator: int

    def __post_init__(self) -> None:
        if not isinstance(self.target_id, str) or not self.target_id:
            raise ValidationError("target_id must be a nonempty string")
        object.__setattr__(self, "backlog", _nonnegative_int(self.backlog, name="backlog", sqlite_sized=True))
        object.__setattr__(
            self,
            "weight_numerator",
            _nonnegative_int(self.weight_numerator, name="weight_numerator"),
        )

    @classmethod
    def from_binary64(cls, *, target_id: str, backlog: int, weight: float) -> "WeightedBoundarySample":
        return cls(target_id, backlog, binary64_lattice_numerator(weight))


@dataclass(frozen=True, slots=True)
class LevelRow:
    block_id: int
    target_id: str
    backlog: int
    mass_kind: str
    gap_mode: str
    exposure: int
    served: int
    gap_negative: int | None
    gap_zero: int | None
    gap_positive: int | None
    gap_zero_served: int | None
    gap_positive_sum: int | None
    gap_negative_sum: int | None


@dataclass(frozen=True, slots=True)
class BoundaryRow:
    block_id: int
    target_id: str
    side: str
    backlog: int
    mass_kind: str
    mass: int


@dataclass(frozen=True, slots=True)
class TargetBlockRow:
    block_id: int
    target_id: str
    mass_kind: str
    slots_observed: int
    decision_mass: int
    offered: int
    offered_square: int
    admitted: int
    admitted_square: int
    dropped: int


@dataclass(frozen=True, slots=True)
class SuppliedResponseRow:
    block_id: int
    target_id: str
    coefficient_kind: str
    coefficient_index: int
    value: float | None
    status: str
    exposure: int
    served: int


@dataclass(frozen=True, slots=True)
class RunObservationState:
    format_version: str
    unit_kind: str
    window_start: int
    window_stop: int
    status: str
    failure_reason: str | None
    metadata: Mapping[str, Any]


_DDL = """
CREATE TABLE run_state (
    singleton INTEGER NOT NULL PRIMARY KEY CHECK (singleton = 1),
    format_version TEXT NOT NULL,
    unit_kind TEXT NOT NULL CHECK (unit_kind IN ('simulator_run', 'weighted_ensemble')),
    window_start INTEGER NOT NULL CHECK (typeof(window_start) = 'integer' AND window_start >= 0),
    window_stop INTEGER NOT NULL CHECK (typeof(window_stop) = 'integer' AND window_stop > window_start),
    status TEXT NOT NULL CHECK (status IN ('writing', 'complete', 'failed')),
    failure_reason TEXT,
    metadata_json TEXT NOT NULL,
    CHECK ((status = 'failed') = (failure_reason IS NOT NULL)),
    CHECK (status <> 'complete' OR failure_reason IS NULL)
) WITHOUT ROWID;

CREATE TABLE targets (
    target_id TEXT NOT NULL PRIMARY KEY CHECK (length(target_id) > 0),
    queue_id_json TEXT NOT NULL,
    mass_kind TEXT NOT NULL CHECK (mass_kind IN ('integer', 'binary64_lattice')),
    gap_mode TEXT NOT NULL CHECK (gap_mode IN ('none', 'exact'))
) WITHOUT ROWID;

CREATE TABLE blocks (
    block_id INTEGER NOT NULL PRIMARY KEY CHECK (typeof(block_id) = 'integer' AND block_id >= 0),
    start_slot INTEGER NOT NULL CHECK (typeof(start_slot) = 'integer' AND start_slot >= 0),
    stop_slot INTEGER NOT NULL CHECK (typeof(stop_slot) = 'integer' AND stop_slot > start_slot),
    UNIQUE (start_slot),
    UNIQUE (stop_slot)
) WITHOUT ROWID;

CREATE TABLE target_blocks (
    block_id INTEGER NOT NULL,
    target_id TEXT NOT NULL,
    slots_observed INTEGER NOT NULL CHECK (typeof(slots_observed) = 'integer' AND slots_observed >= 0),
    decision_mass BLOB NOT NULL CHECK (typeof(decision_mass) = 'blob'),
    offered BLOB NOT NULL CHECK (typeof(offered) = 'blob'),
    offered_square BLOB NOT NULL CHECK (typeof(offered_square) = 'blob'),
    admitted BLOB NOT NULL CHECK (typeof(admitted) = 'blob'),
    admitted_square BLOB NOT NULL CHECK (typeof(admitted_square) = 'blob'),
    dropped BLOB NOT NULL CHECK (typeof(dropped) = 'blob'),
    PRIMARY KEY (block_id, target_id),
    FOREIGN KEY (block_id) REFERENCES blocks(block_id) ON DELETE RESTRICT,
    FOREIGN KEY (target_id) REFERENCES targets(target_id) ON DELETE RESTRICT
) WITHOUT ROWID;

CREATE TABLE levels (
    block_id INTEGER NOT NULL,
    target_id TEXT NOT NULL,
    backlog INTEGER NOT NULL CHECK (typeof(backlog) = 'integer' AND backlog >= 0),
    exposure BLOB NOT NULL CHECK (typeof(exposure) = 'blob'),
    served BLOB NOT NULL CHECK (typeof(served) = 'blob'),
    gap_negative BLOB,
    gap_zero BLOB,
    gap_positive BLOB,
    gap_zero_served BLOB,
    gap_positive_sum BLOB,
    gap_negative_sum BLOB,
    PRIMARY KEY (block_id, target_id, backlog),
    FOREIGN KEY (block_id, target_id) REFERENCES target_blocks(block_id, target_id) ON DELETE RESTRICT,
    CHECK (
        (
            gap_negative IS NULL AND gap_zero IS NULL AND gap_positive IS NULL
            AND gap_zero_served IS NULL AND gap_positive_sum IS NULL
            AND gap_negative_sum IS NULL
        )
        OR
        (
            typeof(gap_negative) = 'blob' AND typeof(gap_zero) = 'blob'
            AND typeof(gap_positive) = 'blob' AND typeof(gap_zero_served) = 'blob'
            AND typeof(gap_positive_sum) = 'blob' AND typeof(gap_negative_sum) = 'blob'
        )
    )
) WITHOUT ROWID;

CREATE TABLE boundaries (
    block_id INTEGER NOT NULL,
    target_id TEXT NOT NULL,
    side TEXT NOT NULL CHECK (side IN ('start', 'end')),
    backlog INTEGER NOT NULL CHECK (typeof(backlog) = 'integer' AND backlog >= 0),
    mass BLOB NOT NULL CHECK (typeof(mass) = 'blob'),
    PRIMARY KEY (block_id, target_id, side, backlog),
    FOREIGN KEY (block_id, target_id) REFERENCES target_blocks(block_id, target_id) ON DELETE RESTRICT
) WITHOUT ROWID;

CREATE TABLE supplied_responses (
    block_id INTEGER NOT NULL,
    target_id TEXT NOT NULL,
    coefficient_kind TEXT NOT NULL CHECK (coefficient_kind IN ('mu', 'tail')),
    coefficient_index INTEGER NOT NULL CHECK (typeof(coefficient_index) = 'integer' AND coefficient_index >= 0),
    value REAL,
    status TEXT NOT NULL CHECK (length(status) > 0),
    exposure BLOB NOT NULL CHECK (typeof(exposure) = 'blob'),
    served BLOB NOT NULL CHECK (typeof(served) = 'blob'),
    PRIMARY KEY (block_id, target_id, coefficient_kind, coefficient_index),
    FOREIGN KEY (block_id, target_id) REFERENCES target_blocks(block_id, target_id) ON DELETE RESTRICT,
    CHECK (value IS NULL OR typeof(value) = 'real')
) WITHOUT ROWID;
"""


def _decode_gap_columns(
    payloads: Sequence[bytes | bytearray | memoryview | None],
    *,
    gap_mode: str,
    context: Mapping[str, Any] | None = None,
) -> tuple[int | None, int | None, int | None, int | None, int | None, int | None]:
    """Decode one persisted all-present or all-absent exact-gap tuple."""

    if len(payloads) != 6:
        raise ValidationError("persisted gap tuple has the wrong arity")
    if gap_mode == GAP_NONE:
        if any(payload is not None for payload in payloads):
            raise ValidationError(
                "gap-disabled target contains persisted gap masses",
                context=dict(context or {}),
            )
        return (None, None, None, None, None, None)
    if gap_mode != GAP_EXACT:
        raise ValidationError(
            "persisted target has an unsupported gap mode",
            context={**dict(context or {}), "gap_mode": gap_mode},
        )
    if any(payload is None for payload in payloads):
        raise ValidationError(
            "exact-gap target is missing persisted gap masses",
            context=dict(context or {}),
        )
    decoded = tuple(decode_bigint(payload) for payload in payloads if payload is not None)
    if len(decoded) != 6:  # pragma: no cover - guarded by the missing-value check
        raise ValidationError("persisted exact-gap tuple is incomplete")
    return decoded  # type: ignore[return-value]


def _iter_level_totals(
    connection: sqlite3.Connection,
) -> Iterator[tuple[tuple[int, str], int, int]]:
    """Stream validated base and gap totals by target block."""

    current_key: tuple[int, str] | None = None
    exposure_total = 0
    served_total = 0
    cursor = connection.execute(
        """
        SELECT l.block_id, l.target_id, l.backlog, t.gap_mode,
               l.exposure, l.served,
               l.gap_negative, l.gap_zero, l.gap_positive,
               l.gap_zero_served, l.gap_positive_sum, l.gap_negative_sum
        FROM levels AS l JOIN targets AS t USING (target_id)
        ORDER BY l.block_id, l.target_id, l.backlog
        """
    )
    for row in cursor:
        (
            block_id,
            target_id,
            backlog,
            gap_mode,
            exposure_blob,
            served_blob,
            *gap_payloads,
        ) = row
        key = (block_id, target_id)
        if current_key is not None and key != current_key:
            yield current_key, exposure_total, served_total
            exposure_total = 0
            served_total = 0
        current_key = key
        exposure = decode_bigint(exposure_blob)
        served = decode_bigint(served_blob)
        if exposure < 0 or served < 0 or served > exposure:
            raise ValidationError(
                "invalid persisted level masses",
                context={
                    "block_id": block_id,
                    "target_id": target_id,
                    "backlog": backlog,
                    "exposure": exposure,
                    "served": served,
                },
            )
        gap_values = _decode_gap_columns(
            gap_payloads,
            gap_mode=gap_mode,
            context={
                "block_id": block_id,
                "target_id": target_id,
                "backlog": backlog,
            },
        )
        if gap_mode == GAP_EXACT:
            (
                gap_negative,
                gap_zero,
                gap_positive,
                gap_zero_served,
                gap_positive_sum,
                gap_negative_sum,
            ) = gap_values
            assert gap_negative is not None
            assert gap_zero is not None
            assert gap_positive is not None
            assert gap_zero_served is not None
            assert gap_positive_sum is not None
            assert gap_negative_sum is not None
            values = (
                gap_negative,
                gap_zero,
                gap_positive,
                gap_zero_served,
                gap_positive_sum,
                gap_negative_sum,
            )
            invalid_reason: str | None = None
            if min(values) < 0:
                invalid_reason = "gap masses and moments must be nonnegative"
            elif gap_negative + gap_zero + gap_positive != exposure:
                invalid_reason = "gap sign masses must sum to exposure"
            elif gap_zero_served > gap_zero or gap_zero_served > served:
                invalid_reason = "tied-and-served mass exceeds tie or service mass"
            elif backlog > 0 and served != gap_positive + gap_zero_served:
                invalid_reason = "positive-backlog service mass violates the exact response identity"
            elif backlog == 0 and any(
                value != 0
                for value in (served, gap_positive, gap_zero_served, gap_positive_sum)
            ):
                invalid_reason = "empty exact-gap targets cannot be served or have positive gaps"
            elif gap_positive_sum < gap_positive or gap_negative_sum < gap_negative:
                invalid_reason = "gap moment is smaller than its nonzero sign mass"
            elif gap_positive_sum > backlog * gap_positive:
                invalid_reason = "positive-gap moment exceeds the pointwise backlog bound"
            elif (gap_positive == 0) != (gap_positive_sum == 0):
                invalid_reason = "positive-gap mass and moment disagree on support"
            elif (gap_negative == 0) != (gap_negative_sum == 0):
                invalid_reason = "negative-gap mass and moment disagree on support"
            elif backlog * exposure - gap_positive_sum + gap_negative_sum < 0:
                invalid_reason = "persisted exact gaps imply a negative competition mass"
            if invalid_reason is not None:
                raise ValidationError(
                    "invalid persisted exact-gap level masses",
                    context={
                        "block_id": block_id,
                        "target_id": target_id,
                        "backlog": backlog,
                        "reason": invalid_reason,
                    },
                )
        exposure_total += exposure
        served_total += served
    if current_key is not None:
        yield current_key, exposure_total, served_total


def _iter_boundary_totals(
    connection: sqlite3.Connection,
) -> Iterator[tuple[tuple[int, str], dict[str, int]]]:
    """Stream validated start/end masses by target block."""

    current_key: tuple[int, str] | None = None
    side_totals: dict[str, int] = {}
    cursor = connection.execute(
        """
        SELECT block_id, target_id, side, backlog, mass
        FROM boundaries
        ORDER BY block_id, target_id, side, backlog
        """
    )
    for block_id, target_id, side, backlog, mass_blob in cursor:
        key = (block_id, target_id)
        if current_key is not None and key != current_key:
            yield current_key, side_totals
            side_totals = {}
        current_key = key
        mass = decode_bigint(mass_blob)
        if mass < 0:
            raise ValidationError(
                "invalid persisted boundary mass",
                context={
                    "block_id": block_id,
                    "target_id": target_id,
                    "side": side,
                    "backlog": backlog,
                    "mass": mass,
                },
            )
        side_totals[side] = side_totals.get(side, 0) + mass
    if current_key is not None:
        yield current_key, side_totals


def _validate_persisted_scientific_invariants(
    connection: sqlite3.Connection,
    *,
    unit_kind: str,
    window_start: int,
    window_stop: int,
    require_complete: bool,
) -> None:
    """Validate exact stored masses without materializing the sparse tables."""

    expected_block_id = 0
    expected_start = window_start
    saw_block = False
    for block_id, start_slot, stop_slot in connection.execute(
        "SELECT block_id, start_slot, stop_slot FROM blocks ORDER BY block_id"
    ):
        saw_block = True
        if block_id != expected_block_id or start_slot != expected_start or stop_slot <= start_slot:
            raise ValidationError(
                "persisted observation blocks do not partition the measurement window",
                context={
                    "block_id": block_id,
                    "expected_block_id": expected_block_id,
                    "start_slot": start_slot,
                    "expected_start_slot": expected_start,
                    "stop_slot": stop_slot,
                },
            )
        expected_block_id += 1
        expected_start = stop_slot
    if not saw_block or expected_start != window_stop:
        raise ValidationError(
            "persisted observation blocks do not cover the measurement window",
            context={"covered_stop": expected_start, "window_stop": window_stop},
        )

    required_mass_kind = MASS_INTEGER if unit_kind == "simulator_run" else MASS_BINARY64_LATTICE
    target_count = 0
    for target_id, mass_kind, gap_mode in connection.execute(
        "SELECT target_id, mass_kind, gap_mode FROM targets ORDER BY target_id"
    ):
        target_count += 1
        if mass_kind != required_mass_kind:
            raise ValidationError(
                "persisted target mass kind disagrees with the observation unit",
                context={
                    "target_id": target_id,
                    "unit_kind": unit_kind,
                    "mass_kind": mass_kind,
                },
            )
        if gap_mode not in {GAP_NONE, GAP_EXACT}:
            raise ValidationError(
                "persisted target has an unsupported gap mode",
                context={"target_id": target_id, "gap_mode": gap_mode},
            )
    if target_count == 0:
        raise ValidationError("persisted observations contain no targets")

    level_totals = iter(_iter_level_totals(connection))
    boundary_totals = iter(_iter_boundary_totals(connection))
    next_level = next(level_totals, None)
    next_boundary = next(boundary_totals, None)
    target_block_count = 0
    expected_target_blocks = expected_block_id * target_count
    target_blocks = connection.execute(
        """
        SELECT b.block_id, b.start_slot, b.stop_slot, t.target_id, t.mass_kind,
               x.slots_observed, x.decision_mass, x.offered, x.offered_square,
               x.admitted, x.admitted_square, x.dropped
        FROM blocks AS b CROSS JOIN targets AS t
        LEFT JOIN target_blocks AS x
          ON x.block_id = b.block_id AND x.target_id = t.target_id
        ORDER BY b.block_id, t.target_id
        """
    )
    for row in target_blocks:
        (
            block_id,
            start_slot,
            stop_slot,
            target_id,
            mass_kind,
            slots_observed,
            decision_blob,
            offered_blob,
            offered_square_blob,
            admitted_blob,
            admitted_square_blob,
            dropped_blob,
        ) = row
        target_block_count += 1
        key = (block_id, target_id)
        if slots_observed is None:
            raise ValidationError(
                "persisted target block is missing",
                context={"block_id": block_id, "target_id": target_id},
            )
        block_length = stop_slot - start_slot
        if slots_observed < 0 or slots_observed > block_length:
            raise ValidationError(
                "persisted target-block slot coverage is invalid",
                context={
                    "block_id": block_id,
                    "target_id": target_id,
                    "slots_observed": slots_observed,
                    "block_length": block_length,
                },
            )

        decision_mass = decode_bigint(decision_blob)
        offered = decode_bigint(offered_blob)
        offered_square = decode_bigint(offered_square_blob)
        admitted = decode_bigint(admitted_blob)
        admitted_square = decode_bigint(admitted_square_blob)
        dropped = decode_bigint(dropped_blob)
        if min(decision_mass, offered, offered_square, admitted, admitted_square, dropped) < 0:
            raise ValidationError(
                "invalid persisted target-block masses",
                context={"block_id": block_id, "target_id": target_id},
            )
        if offered != admitted + dropped:
            raise ValidationError(
                "persisted target-block arrival conservation failed",
                context={"block_id": block_id, "target_id": target_id},
            )

        per_slot_mass = 1 if mass_kind == MASS_INTEGER else BINARY64_NORMALIZED_MASS
        expected_decision_mass = slots_observed * per_slot_mass
        if decision_mass != expected_decision_mass:
            raise ValidationError(
                "persisted decision mass disagrees with slot coverage",
                context={
                    "block_id": block_id,
                    "target_id": target_id,
                    "decision_mass": decision_mass,
                    "expected": expected_decision_mass,
                },
            )

        level_exposure = 0
        if next_level is not None and next_level[0] == key:
            _, level_exposure, _ = next_level
            next_level = next(level_totals, None)
        if level_exposure != decision_mass:
            raise ValidationError(
                "persisted level exposure disagrees with decision mass",
                context={
                    "block_id": block_id,
                    "target_id": target_id,
                    "exposure": level_exposure,
                    "decision_mass": decision_mass,
                },
            )

        observed_sides: dict[str, int] = {}
        if next_boundary is not None and next_boundary[0] == key:
            _, observed_sides = next_boundary
            next_boundary = next(boundary_totals, None)
        for side, mass in observed_sides.items():
            if mass != per_slot_mass:
                raise ValidationError(
                    "persisted boundary mass is not normalized",
                    context={
                        "block_id": block_id,
                        "target_id": target_id,
                        "side": side,
                        "mass": mass,
                        "expected": per_slot_mass,
                    },
                )

        if require_complete:
            if slots_observed != block_length:
                raise ValidationError(
                    "complete observation has incomplete persisted slot coverage",
                    context={
                        "block_id": block_id,
                        "target_id": target_id,
                        "slots_observed": slots_observed,
                        "block_length": block_length,
                    },
                )
            if set(observed_sides) != {"start", "end"}:
                raise ValidationError(
                    "complete observation is missing a persisted block boundary",
                    context={
                        "block_id": block_id,
                        "target_id": target_id,
                        "observed_sides": sorted(observed_sides),
                    },
                )

    if target_block_count != expected_target_blocks or next_level is not None or next_boundary is not None:
        raise ValidationError("persisted scientific rows do not match the target-block structure")

    for row in connection.execute(
        """
        SELECT block_id, target_id, coefficient_kind, coefficient_index, exposure, served
        FROM supplied_responses
        ORDER BY block_id, target_id, coefficient_kind, coefficient_index
        """
    ):
        exposure = decode_bigint(row[4])
        served = decode_bigint(row[5])
        if exposure < 0 or served < 0 or served > exposure:
            raise ValidationError(
                "invalid persisted supplied-response masses",
                context={
                    "block_id": row[0],
                    "target_id": row[1],
                    "coefficient_kind": row[2],
                    "coefficient_index": row[3],
                    "exposure": exposure,
                    "served": served,
                },
            )


def _mapping_or_attribute(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        if name not in value:
            raise ValidationError("committed-slot observation is missing a field", context={"field": name})
        return value[name]
    if not hasattr(value, name):
        raise ValidationError("committed-slot observation is missing an attribute", context={"attribute": name})
    return getattr(value, name)


def _optional_mapping_or_attribute(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(name, default)
    return getattr(value, name, default)


class CompactObservationRecorder:
    """Single-owner recorder for one simulator run or weighted ensemble.

    ``soft_watermark_rows`` controls only when complete additive tuples are
    merged into SQLite.  It is not an observation limit: every scientific
    contribution is retained for every positive value of the setting.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        window_start: int,
        window_stop: int,
        targets: Sequence[ObservationTarget],
        block_slots: int | None = None,
        unit_kind: str = "simulator_run",
        metadata: Mapping[str, Any] | None = None,
        soft_watermark_rows: int = 65_536,
    ) -> None:
        self.path = Path(path)
        if self.path.exists():
            raise ValidationError("observation output path already exists", context={"path": str(self.path)})
        if unit_kind not in {"simulator_run", "weighted_ensemble"}:
            raise ValidationError("unsupported observation unit kind", context={"unit_kind": unit_kind})
        watermark = _nonnegative_int(soft_watermark_rows, name="soft_watermark_rows")
        if watermark == 0:
            raise ValidationError("soft_watermark_rows must be positive")
        if not targets:
            raise ValidationError("at least one observation target is required")
        normalized_targets = tuple(targets)
        if any(not isinstance(target, ObservationTarget) for target in normalized_targets):
            raise ValidationError("targets must contain ObservationTarget instances")
        target_ids = [target.target_id for target in normalized_targets]
        if len(set(target_ids)) != len(target_ids):
            raise ValidationError("observation target IDs must be unique")
        queue_ids = [target.queue_id for target in normalized_targets]
        if len(set(queue_ids)) != len(queue_ids):
            raise ValidationError("selected observation queue IDs must be unique")
        required_mass = MASS_INTEGER if unit_kind == "simulator_run" else MASS_BINARY64_LATTICE
        if any(target.mass_kind != required_mass for target in normalized_targets):
            raise ValidationError(
                "target mass kind does not match the observation unit",
                context={"unit_kind": unit_kind, "required_mass_kind": required_mass},
            )

        self.blocks = make_observation_blocks(window_start, window_stop, block_slots)
        self.targets = normalized_targets
        self._target_by_id = {target.target_id: target for target in normalized_targets}
        self._block_width = self.blocks[0].stop_slot - self.blocks[0].start_slot
        self._boundary_sides: dict[int, list[tuple[int, str]]] = {}
        for block in self.blocks:
            self._boundary_sides.setdefault(block.start_slot, []).append((block.block_id, "start"))
            self._boundary_sides.setdefault(block.stop_slot, []).append((block.block_id, "end"))

        self.window_start = self.blocks[0].start_slot
        self.window_stop = self.blocks[-1].stop_slot
        self.unit_kind = unit_kind
        self._soft_watermark_rows = watermark
        self._next_slot = self.window_start
        self._last_backlog: dict[str, int] = {}
        self._recorded_boundaries: set[int] = set()
        self._closed = False
        self._terminal = False

        # Level value order is H, S, L-, L0, L+, tied-and-served, sum(G+),
        # sum(G-).  Gap-disabled targets keep the final six in memory as zero;
        # they are persisted as NULL so absence cannot be mistaken for all ties.
        self._levels: dict[tuple[int, str, int], list[int]] = {}
        self._boundaries: dict[tuple[int, str, str, int], int] = {}
        self._target_blocks: dict[tuple[int, str], list[int]] = {}
        self._responses: dict[tuple[int, str, str, int], tuple[float | None, str, int, int]] = {}
        self._coverage: dict[tuple[int, str], int] = {
            (block.block_id, target.target_id): 0
            for block in self.blocks
            for target in self.targets
        }

        normalized_metadata = normalize_for_json(dict(metadata or {}))
        if not isinstance(normalized_metadata, dict):
            raise ValidationError("observation metadata must be a mapping")
        metadata_json = canonical_json_dumps(normalized_metadata)

        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._connection = sqlite3.connect(self.path)
            self._connection.execute("PRAGMA foreign_keys = ON")
            mode = self._connection.execute("PRAGMA journal_mode = DELETE").fetchone()[0]
            if str(mode).lower() != "delete":
                raise ValidationError("SQLite refused uncompressed single-file journal mode")
            self._connection.execute("PRAGMA synchronous = FULL")
            self._connection.create_function("bigint_add", 2, self._sqlite_bigint_add, deterministic=True)
            self._connection.executescript(_DDL)
            zero = encode_bigint(0)
            with self._connection:
                self._connection.execute(
                    "INSERT INTO run_state VALUES (1, ?, ?, ?, ?, 'writing', NULL, ?)",
                    (OBSERVATION_FORMAT_VERSION, unit_kind, self.window_start, self.window_stop, metadata_json),
                )
                self._connection.executemany(
                    "INSERT INTO targets(target_id, queue_id_json, mass_kind, gap_mode) VALUES (?, ?, ?, ?)",
                    [
                        (
                            target.target_id,
                            canonical_json_dumps(target.queue_id),
                            target.mass_kind,
                            target.gap_mode,
                        )
                        for target in self.targets
                    ],
                )
                self._connection.executemany(
                    "INSERT INTO blocks(block_id, start_slot, stop_slot) VALUES (?, ?, ?)",
                    [(block.block_id, block.start_slot, block.stop_slot) for block in self.blocks],
                )
                self._connection.executemany(
                    """
                    INSERT INTO target_blocks(
                        block_id, target_id, slots_observed, decision_mass,
                        offered, offered_square, admitted, admitted_square, dropped
                    ) VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (block.block_id, target.target_id, zero, zero, zero, zero, zero, zero)
                        for block in self.blocks
                        for target in self.targets
                    ],
                )
        except BaseException:
            connection = getattr(self, "_connection", None)
            if connection is not None:
                connection.close()
            # The constructor never returns a recorder for this path.  Remove
            # only the file it created; no caller data existed there before.
            if self.path.exists():
                self.path.unlink()
            raise

    @staticmethod
    def _sqlite_bigint_add(left: bytes, right: bytes) -> bytes:
        return encode_bigint(decode_bigint(left) + decode_bigint(right))

    def _ensure_open(self) -> None:
        if self._closed:
            raise ValidationError("observation recorder is closed")
        if self._terminal:
            raise ValidationError("observation recorder is already finalized")

    def _block_at(self, slot: int) -> ObservationBlock | None:
        if slot < self.window_start or slot >= self.window_stop:
            return None
        index = (slot - self.window_start) // self._block_width
        return self.blocks[index]

    def _level_contribution(
        self,
        *,
        target_id: str,
        served: int,
        gap: int | None,
        mass: int,
    ) -> list[int]:
        """Construct one complete additive tuple for the configured target."""

        target = self._target_by_id[target_id]
        if target.gap_mode == GAP_NONE:
            if gap is not None:
                raise ValidationError(
                    "gap-disabled target received an exact gap",
                    context={"target_id": target_id, "gap": gap},
                )
            gap_values = (0, 0, 0, 0, 0, 0)
        else:
            if gap is None:
                raise ValidationError(
                    "exact-gap target is missing its gap",
                    context={"target_id": target_id},
                )
            gap_values = _gap_contribution(gap, served, mass)
        return [mass, mass * served, *gap_values]

    @staticmethod
    def _committed_gap_for(committed_slot: Any, queue_id: Any) -> Any:
        """Read the ephemeral signed gap without depending on optimizer types."""

        gap_for = getattr(committed_slot, "gap_for", None)
        if callable(gap_for):
            return gap_for(queue_id)
        for attribute in ("gap_by_queue", "exact_gap_by_queue"):
            values = getattr(committed_slot, attribute, None)
            if isinstance(values, Mapping):
                return values.get(queue_id)
        certificates = getattr(committed_slot, "gap_certificates", None)
        if isinstance(certificates, Mapping):
            certificate = certificates.get(queue_id)
            if certificate is None:
                return None
            if isinstance(certificate, Mapping):
                return certificate.get("gap")
            return getattr(certificate, "gap", None)
        return None

    @property
    def pending_sparse_rows(self) -> int:
        return len(self._levels) + len(self._boundaries) + len(self._target_blocks) + len(self._responses)

    @staticmethod
    def _restore_mapping(
        destination: dict[Any, Any],
        previous: Mapping[Any, Any],
    ) -> None:
        for key, value in previous.items():
            if value is _MISSING:
                destination.pop(key, None)
            else:
                destination[key] = value

    def _promote_batch(
        self,
        *,
        levels: Mapping[tuple[int, str, int], Sequence[int]] | None = None,
        boundaries: Mapping[tuple[int, str, str, int], int] | None = None,
        target_blocks: Mapping[tuple[int, str], Sequence[int]] | None = None,
        coverage: Mapping[tuple[int, str], int] | None = None,
        last_backlog: Mapping[str, int] | None = None,
        next_slot: int | None = None,
        recorded_boundary: int | None = None,
    ) -> None:
        """Promote one already-validated scientific call as one logical batch."""

        level_delta = levels or {}
        boundary_delta = boundaries or {}
        target_block_delta = target_blocks or {}
        coverage_delta = coverage or {}
        backlog_delta = last_backlog or {}

        prior_levels = {key: self._levels.get(key, _MISSING) for key in level_delta}
        prior_boundaries = {key: self._boundaries.get(key, _MISSING) for key in boundary_delta}
        prior_target_blocks = {key: self._target_blocks.get(key, _MISSING) for key in target_block_delta}
        prior_coverage = {key: self._coverage.get(key, _MISSING) for key in coverage_delta}
        prior_backlog = {key: self._last_backlog.get(key, _MISSING) for key in backlog_delta}

        promoted_levels: dict[tuple[int, str, int], list[int]] = {}
        for key, delta in level_delta.items():
            if len(delta) != 8:
                raise ValidationError(
                    "level contribution must contain the complete base-and-gap tuple",
                    context={"key": key, "length": len(delta)},
                )
            old = self._levels.get(key)
            promoted_levels[key] = (
                [int(value) for value in delta]
                if old is None
                else [old[index] + int(value) for index, value in enumerate(delta)]
            )
        promoted_boundaries = {
            key: self._boundaries.get(key, 0) + int(delta)
            for key, delta in boundary_delta.items()
        }
        promoted_target_blocks: dict[tuple[int, str], list[int]] = {}
        for key, delta in target_block_delta.items():
            old = self._target_blocks.get(key)
            promoted_target_blocks[key] = (
                [int(value) for value in delta]
                if old is None
                else [old[index] + int(value) for index, value in enumerate(delta)]
            )
        promoted_coverage = {
            key: self._coverage[key] + int(delta)
            for key, delta in coverage_delta.items()
        }

        previous_next_slot = self._next_slot
        boundary_was_recorded = (
            recorded_boundary is not None and recorded_boundary in self._recorded_boundaries
        )
        try:
            self._levels.update(promoted_levels)
            self._boundaries.update(promoted_boundaries)
            self._target_blocks.update(promoted_target_blocks)
            self._coverage.update(promoted_coverage)
            self._last_backlog.update(backlog_delta)
            if recorded_boundary is not None:
                self._recorded_boundaries.add(recorded_boundary)
            if next_slot is not None:
                self._next_slot = next_slot
        except BaseException:
            self._restore_mapping(self._levels, prior_levels)
            self._restore_mapping(self._boundaries, prior_boundaries)
            self._restore_mapping(self._target_blocks, prior_target_blocks)
            self._restore_mapping(self._coverage, prior_coverage)
            self._restore_mapping(self._last_backlog, prior_backlog)
            if recorded_boundary is not None and not boundary_was_recorded:
                self._recorded_boundaries.discard(recorded_boundary)
            self._next_slot = previous_next_slot
            raise

    def _maybe_flush(self) -> None:
        if self.pending_sparse_rows >= self._soft_watermark_rows:
            self.flush()

    def record_slot(self, slot: int, observations: Iterable[TargetSlotObservation]) -> None:
        """Record one complete simulator slot after all queue checks succeed."""

        self._ensure_open()
        if self.unit_kind != "simulator_run":
            raise ValidationError("record_slot is only valid for simulator observations")
        concrete_slot = _nonnegative_int(slot, name="slot", sqlite_sized=True)
        if concrete_slot != self._next_slot:
            raise ValidationError(
                "simulator observation slots must be consecutive",
                context={"expected": self._next_slot, "observed": concrete_slot},
            )
        block = self._block_at(concrete_slot)
        if block is None:
            raise ValidationError("slot is outside the measurement window", context={"slot": concrete_slot})
        by_target: dict[str, TargetSlotObservation] = {}
        for row in observations:
            if not isinstance(row, TargetSlotObservation):
                raise ValidationError("observations must contain TargetSlotObservation instances")
            if row.target_id in by_target:
                raise ValidationError("a target appears more than once in a committed slot")
            by_target[row.target_id] = row
        if set(by_target) != set(self._target_by_id):
            raise ValidationError(
                "committed slot must contain every selected target exactly once",
                context={"expected": sorted(self._target_by_id), "observed": sorted(by_target)},
            )
        for target_id, row in by_target.items():
            previous = self._last_backlog.get(target_id)
            if previous is not None and row.backlog_before != previous:
                raise ValidationError(
                    "target backlog is discontinuous between committed slots",
                    context={"target_id": target_id, "expected": previous, "observed": row.backlog_before},
                )

        local_levels: dict[tuple[int, str, int], list[int]] = {}
        local_boundaries: dict[tuple[int, str, str, int], int] = {}
        local_target_blocks: dict[tuple[int, str], list[int]] = {}
        local_coverage: dict[tuple[int, str], int] = {}
        local_backlog: dict[str, int] = {}
        for target_id, row in by_target.items():
            row = by_target[target_id]
            local_levels[(block.block_id, target_id, row.backlog_before)] = self._level_contribution(
                target_id=target_id,
                served=row.served,
                gap=row.gap,
                mass=1,
            )
            key = (block.block_id, target_id)
            local_target_blocks[key] = [
                1,
                1,
                row.offered,
                row.offered * row.offered,
                row.admitted,
                row.admitted * row.admitted,
                row.dropped,
            ]
            local_coverage[key] = 1
            if concrete_slot == block.start_slot:
                local_boundaries[(block.block_id, target_id, "start", row.backlog_before)] = 1
            if concrete_slot + 1 == block.stop_slot:
                local_boundaries[(block.block_id, target_id, "end", row.backlog_after)] = 1
            local_backlog[target_id] = row.backlog_after
        self._promote_batch(
            levels=local_levels,
            boundaries=local_boundaries,
            target_blocks=local_target_blocks,
            coverage=local_coverage,
            last_backlog=local_backlog,
            next_slot=concrete_slot + 1,
        )
        self._maybe_flush()

    def record_committed_slot(self, committed_slot: Any) -> None:
        """Adapt a small attribute-based ``CommittedSlot`` protocol.

        The object must expose ``slot`` and ``target_observations``.  The latter
        may be an iterable of :class:`TargetSlotObservation`, or a mapping from
        target ID to objects/mappings carrying ``backlog_before``,
        ``backlog_after``, ``served``, ``offered``, ``admitted``, and ``dropped``.
        """

        slot = _mapping_or_attribute(committed_slot, "slot")
        if not isinstance(committed_slot, Mapping) and not hasattr(committed_slot, "target_observations"):
            q_before_for = getattr(committed_slot, "q_before_for", None)
            q_after_for = getattr(committed_slot, "q_after_for", None)
            if not callable(q_before_for) or not callable(q_after_for):
                raise ValidationError(
                    "committed slot must expose target_observations or queue accessors"
                )
            served_by_queue = _mapping_or_attribute(committed_slot, "served_by_queue")
            offered_by_queue = _mapping_or_attribute(committed_slot, "offered_by_queue")
            admitted_by_queue = _mapping_or_attribute(committed_slot, "admitted_by_queue")
            dropped_by_queue = _mapping_or_attribute(committed_slot, "dropped_by_queue")
            observations = [
                TargetSlotObservation(
                    target_id=target.target_id,
                    backlog_before=q_before_for(target.queue_id),
                    backlog_after=q_after_for(target.queue_id),
                    served=served_by_queue.get(target.queue_id, 0),
                    offered=offered_by_queue.get(target.queue_id, 0),
                    admitted=admitted_by_queue.get(target.queue_id, 0),
                    dropped=dropped_by_queue.get(target.queue_id, 0),
                    gap=(
                        self._committed_gap_for(committed_slot, target.queue_id)
                        if target.gap_mode == GAP_EXACT
                        else None
                    ),
                )
                for target in self.targets
            ]
            self.record_slot(slot, observations)
            return

        raw_observations = _mapping_or_attribute(committed_slot, "target_observations")
        normalized: list[TargetSlotObservation] = []
        if isinstance(raw_observations, Mapping):
            items = raw_observations.items()
        else:
            items = ((None, value) for value in raw_observations)
        for mapping_target_id, value in items:
            if isinstance(value, TargetSlotObservation):
                if mapping_target_id is not None and value.target_id != mapping_target_id:
                    raise ValidationError("committed-slot target key disagrees with its observation")
                normalized.append(value)
                continue
            target_id = mapping_target_id
            if target_id is None:
                target_id = _mapping_or_attribute(value, "target_id")
            normalized.append(
                TargetSlotObservation(
                    target_id=str(target_id),
                    backlog_before=_mapping_or_attribute(value, "backlog_before"),
                    backlog_after=_mapping_or_attribute(value, "backlog_after"),
                    served=_mapping_or_attribute(value, "served"),
                    offered=_mapping_or_attribute(value, "offered"),
                    admitted=_mapping_or_attribute(value, "admitted"),
                    dropped=_mapping_or_attribute(value, "dropped"),
                    gap=_optional_mapping_or_attribute(value, "gap"),
                )
            )
        self.record_slot(slot, normalized)

    def record_weighted_slot(self, slot: int, samples: Iterable[WeightedTargetSample]) -> None:
        """Atomically add one decision-time weighted population.

        The caller supplies the sampler's actual pre-resampling population; this
        method neither defines nor changes any sampler algorithm.
        """

        self._ensure_open()
        if self.unit_kind != "weighted_ensemble":
            raise ValidationError("record_weighted_slot is only valid for weighted ensembles")
        concrete_slot = _nonnegative_int(slot, name="slot", sqlite_sized=True)
        if concrete_slot != self._next_slot:
            raise ValidationError(
                "weighted observation slots must be consecutive",
                context={"expected": self._next_slot, "observed": concrete_slot},
            )
        block = self._block_at(concrete_slot)
        if block is None:
            raise ValidationError("slot is outside the measurement window", context={"slot": concrete_slot})
        # Reduce the input stream locally.  A generator failure or invalid late
        # sample therefore cannot leave a fractional slot in recorder state.
        accumulators: dict[str, list[int]] = {
            target_id: [0, 0, 0, 0, 0, 0]
            for target_id in self._target_by_id
        }
        sample_counts = {target_id: 0 for target_id in self._target_by_id}
        local_levels: dict[tuple[int, str, int], list[int]] = {}
        sample_count = 0
        for row in samples:
            if not isinstance(row, WeightedTargetSample):
                raise ValidationError(
                    "samples must contain WeightedTargetSample instances"
                )
            if row.target_id not in accumulators:
                raise ValidationError("weighted sample names an unconfigured target", context={"target_id": row.target_id})
            sample_count += 1
            sample_counts[row.target_id] += 1
            weight = row.weight_numerator
            totals = accumulators[row.target_id]
            totals[0] += weight
            totals[1] += weight * row.offered
            totals[2] += weight * row.offered * row.offered
            totals[3] += weight * row.admitted
            totals[4] += weight * row.admitted * row.admitted
            totals[5] += weight * row.dropped
            contribution = self._level_contribution(
                target_id=row.target_id,
                served=row.served,
                gap=row.gap,
                mass=weight,
            )
            if weight:
                level_key = (block.block_id, row.target_id, row.backlog)
                level = local_levels.setdefault(level_key, [0] * 8)
                for index, value in enumerate(contribution):
                    level[index] += value
        if sample_count == 0:
            raise ValidationError(
                "samples must be a nonempty collection of WeightedTargetSample instances"
            )
        if any(count == 0 for count in sample_counts.values()):
            raise ValidationError("weighted slot must contain every selected target")
        invalid_mass = {
            target_id: totals[0]
            for target_id, totals in accumulators.items()
            if totals[0] != BINARY64_NORMALIZED_MASS
        }
        if invalid_mass:
            raise ValidationError(
                "every target must observe exactly one normalized weighted decision mass",
                context={
                    "expected_mass": BINARY64_NORMALIZED_MASS,
                    "target_mass": {
                        target_id: totals[0]
                        for target_id, totals in accumulators.items()
                    },
                },
            )

        local_target_blocks: dict[tuple[int, str], list[int]] = {}
        local_coverage: dict[tuple[int, str], int] = {}
        for target_id, totals in accumulators.items():
            key = (block.block_id, target_id)
            local_target_blocks[key] = [
                1,
                totals[0],
                totals[1],
                totals[2],
                totals[3],
                totals[4],
                totals[5],
            ]
            local_coverage[key] = 1
        self._promote_batch(
            levels=local_levels,
            target_blocks=local_target_blocks,
            coverage=local_coverage,
            next_slot=concrete_slot + 1,
        )
        self._maybe_flush()

    def record_weighted_boundary(self, slot: int, samples: Iterable[WeightedBoundarySample]) -> None:
        """Record a canonical weighted population at a scientific block boundary."""

        self._ensure_open()
        if self.unit_kind != "weighted_ensemble":
            raise ValidationError("weighted boundaries are only valid for weighted ensembles")
        boundary_slot = _nonnegative_int(slot, name="slot", sqlite_sized=True)
        sides = self._boundary_sides.get(boundary_slot)
        if not sides:
            raise ValidationError("slot is not an observation block boundary", context={"slot": boundary_slot})
        if boundary_slot in self._recorded_boundaries:
            raise ValidationError("weighted boundary has already been recorded", context={"slot": boundary_slot})
        total_mass = {target_id: 0 for target_id in self._target_by_id}
        sample_counts = {target_id: 0 for target_id in self._target_by_id}
        local_boundaries: dict[tuple[int, str, str, int], int] = {}
        sample_count = 0
        for row in samples:
            if not isinstance(row, WeightedBoundarySample):
                raise ValidationError(
                    "samples must contain WeightedBoundarySample instances"
                )
            if row.target_id not in total_mass:
                raise ValidationError("weighted boundary names an unconfigured target", context={"target_id": row.target_id})
            sample_count += 1
            sample_counts[row.target_id] += 1
            total_mass[row.target_id] += row.weight_numerator
            if row.weight_numerator:
                for block_id, side in sides:
                    key = (block_id, row.target_id, side, row.backlog)
                    local_boundaries[key] = (
                        local_boundaries.get(key, 0) + row.weight_numerator
                    )
        if sample_count == 0:
            raise ValidationError(
                "samples must be a nonempty collection of WeightedBoundarySample instances"
            )
        if any(count == 0 for count in sample_counts.values()):
            raise ValidationError("weighted boundary must contain every selected target")
        if any(mass != BINARY64_NORMALIZED_MASS for mass in total_mass.values()):
            raise ValidationError(
                "every target must have exactly one normalized boundary mass",
                context={
                    "expected_mass": BINARY64_NORMALIZED_MASS,
                    "target_mass": total_mass,
                },
            )
        self._promote_batch(
            boundaries=local_boundaries,
            recorded_boundary=boundary_slot,
        )
        self._maybe_flush()

    def record_supplied_response(
        self,
        *,
        block_id: int,
        target_id: str,
        coefficient_kind: str,
        coefficient_index: int,
        value: float | None,
        status: str,
        exposure_numerator: int,
        served_numerator: int,
    ) -> None:
        """Retain a sampler-supplied coefficient beside its raw additive masses."""

        self._ensure_open()
        if self.unit_kind != "weighted_ensemble":
            raise ValidationError("supplied responses are only valid for weighted ensembles")
        concrete_block = _nonnegative_int(block_id, name="block_id", sqlite_sized=True)
        if concrete_block not in {block.block_id for block in self.blocks}:
            raise ValidationError("unknown observation block", context={"block_id": concrete_block})
        if target_id not in self._target_by_id:
            raise ValidationError("unknown observation target", context={"target_id": target_id})
        if coefficient_kind not in {"mu", "tail"}:
            raise ValidationError("coefficient_kind must be 'mu' or 'tail'")
        index = _nonnegative_int(coefficient_index, name="coefficient_index", sqlite_sized=True)
        if not isinstance(status, str) or not status:
            raise ValidationError("response status must be a nonempty string")
        if value is not None:
            if isinstance(value, bool) or not isinstance(value, float) or not math.isfinite(value):
                raise ValidationError("supplied response value must be a finite binary64 float or null")
        exposure = _nonnegative_int(exposure_numerator, name="exposure_numerator")
        served = _nonnegative_int(served_numerator, name="served_numerator")
        if served > exposure:
            raise ValidationError(
                "supplied response service cannot exceed exposure",
                context={"exposure": exposure, "served": served},
            )
        key = (concrete_block, target_id, coefficient_kind, index)
        row = (value, status, exposure, served)
        existing = self._responses.get(key)
        if existing is not None and existing != row:
            raise ValidationError("supplied response was recorded twice with different values")
        self._responses[key] = row
        self._maybe_flush()

    def _flush_in_transaction(self) -> None:
        if self._levels:
            ordered_levels = sorted(self._levels.items())
            gap_disabled = [
                (key, values)
                for key, values in ordered_levels
                if self._target_by_id[key[1]].gap_mode == GAP_NONE
            ]
            gap_exact = [
                (key, values)
                for key, values in ordered_levels
                if self._target_by_id[key[1]].gap_mode == GAP_EXACT
            ]
            if gap_disabled:
                self._connection.executemany(
                    """
                    INSERT INTO levels(block_id, target_id, backlog, exposure, served)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(block_id, target_id, backlog) DO UPDATE SET
                        exposure = bigint_add(levels.exposure, excluded.exposure),
                        served = bigint_add(levels.served, excluded.served)
                    """,
                    [
                        (
                            block_id,
                            target_id,
                            backlog,
                            encode_bigint(values[0]),
                            encode_bigint(values[1]),
                        )
                        for (block_id, target_id, backlog), values in gap_disabled
                    ],
                )
            if gap_exact:
                self._connection.executemany(
                    """
                    INSERT INTO levels(
                        block_id, target_id, backlog, exposure, served,
                        gap_negative, gap_zero, gap_positive, gap_zero_served,
                        gap_positive_sum, gap_negative_sum
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(block_id, target_id, backlog) DO UPDATE SET
                        exposure = bigint_add(levels.exposure, excluded.exposure),
                        served = bigint_add(levels.served, excluded.served),
                        gap_negative = bigint_add(levels.gap_negative, excluded.gap_negative),
                        gap_zero = bigint_add(levels.gap_zero, excluded.gap_zero),
                        gap_positive = bigint_add(levels.gap_positive, excluded.gap_positive),
                        gap_zero_served = bigint_add(levels.gap_zero_served, excluded.gap_zero_served),
                        gap_positive_sum = bigint_add(levels.gap_positive_sum, excluded.gap_positive_sum),
                        gap_negative_sum = bigint_add(levels.gap_negative_sum, excluded.gap_negative_sum)
                    """,
                    [
                        (
                            block_id,
                            target_id,
                            backlog,
                            *(encode_bigint(value) for value in values),
                        )
                        for (block_id, target_id, backlog), values in gap_exact
                    ],
                )
        if self._boundaries:
            self._connection.executemany(
                """
                INSERT INTO boundaries(block_id, target_id, side, backlog, mass)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(block_id, target_id, side, backlog) DO UPDATE SET
                    mass = bigint_add(boundaries.mass, excluded.mass)
                """,
                [
                    (block_id, target_id, side, backlog, encode_bigint(mass))
                    for (block_id, target_id, side, backlog), mass in sorted(self._boundaries.items())
                ],
            )
        if self._target_blocks:
            self._connection.executemany(
                """
                UPDATE target_blocks SET
                    slots_observed = slots_observed + ?,
                    decision_mass = bigint_add(decision_mass, ?),
                    offered = bigint_add(offered, ?),
                    offered_square = bigint_add(offered_square, ?),
                    admitted = bigint_add(admitted, ?),
                    admitted_square = bigint_add(admitted_square, ?),
                    dropped = bigint_add(dropped, ?)
                WHERE block_id = ? AND target_id = ?
                """,
                [
                    (
                        values[0],
                        encode_bigint(values[1]),
                        encode_bigint(values[2]),
                        encode_bigint(values[3]),
                        encode_bigint(values[4]),
                        encode_bigint(values[5]),
                        encode_bigint(values[6]),
                        block_id,
                        target_id,
                    )
                    for (block_id, target_id), values in sorted(self._target_blocks.items())
                ],
            )
        if self._responses:
            self._connection.executemany(
                """
                INSERT INTO supplied_responses(
                    block_id, target_id, coefficient_kind, coefficient_index,
                    value, status, exposure, served
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        block_id,
                        target_id,
                        kind,
                        index,
                        row[0],
                        row[1],
                        encode_bigint(row[2]),
                        encode_bigint(row[3]),
                    )
                    for (block_id, target_id, kind, index), row in sorted(self._responses.items())
                ],
            )

    def _clear_pending(self) -> None:
        self._levels.clear()
        self._boundaries.clear()
        self._target_blocks.clear()
        self._responses.clear()

    def _commit_database(self) -> None:
        """Small seam used by failure-injection tests around SQLite COMMIT."""

        self._connection.commit()

    def _poison_after_ambiguous_commit(self) -> None:
        # SQLite may have committed even when the client observed an error.
        # Discard all replayable deltas and permanently retire this recorder.
        self._clear_pending()
        self._terminal = True
        try:
            self._connection.close()
        except BaseException:
            pass
        self._closed = True

    def _commit_or_poison(self) -> None:
        try:
            self._commit_database()
        except BaseException:
            self._poison_after_ambiguous_commit()
            raise

    def _rollback_or_poison(self) -> None:
        try:
            self._connection.rollback()
        except BaseException:
            # A failed rollback also leaves transaction state unsuitable for
            # safe reuse, although it is not a COMMIT replay ambiguity.
            self._poison_after_ambiguous_commit()
            raise

    def flush(self) -> None:
        """Merge every currently buffered complete tuple into SQLite."""

        self._ensure_open()
        if self.pending_sparse_rows == 0:
            return
        try:
            self._connection.execute("BEGIN IMMEDIATE")
            self._flush_in_transaction()
        except BaseException:
            self._rollback_or_poison()
            raise
        self._commit_or_poison()
        self._clear_pending()

    def _validate_complete(self) -> None:
        if self._next_slot != self.window_stop:
            raise ValidationError(
                "measurement window is incomplete",
                context={"next_slot": self._next_slot, "window_stop": self.window_stop},
            )
        for block in self.blocks:
            expected = block.stop_slot - block.start_slot
            for target in self.targets:
                observed = self._coverage[(block.block_id, target.target_id)]
                if observed != expected:
                    raise ValidationError(
                        "observation block has incomplete slot coverage",
                        context={
                            "block_id": block.block_id,
                            "target_id": target.target_id,
                            "expected": expected,
                            "observed": observed,
                        },
                    )
        if self.unit_kind == "weighted_ensemble":
            required = set(self._boundary_sides)
            if self._recorded_boundaries != required:
                raise ValidationError(
                    "weighted block boundaries are incomplete",
                    context={
                        "missing": sorted(required - self._recorded_boundaries),
                        "unexpected": sorted(self._recorded_boundaries - required),
                    },
                )

    def _validate_persisted(self, *, require_complete: bool) -> None:
        _validate_persisted_scientific_invariants(
            self._connection,
            unit_kind=self.unit_kind,
            window_start=self.window_start,
            window_stop=self.window_stop,
            require_complete=require_complete,
        )

    def complete(self) -> None:
        """Atomically publish the pending scientific suffix and mark it complete."""

        self._ensure_open()
        self._validate_complete()
        try:
            self._connection.execute("BEGIN IMMEDIATE")
            self._flush_in_transaction()
            self._validate_persisted(require_complete=True)
            self._connection.execute("UPDATE run_state SET status = 'complete' WHERE singleton = 1")
        except BaseException:
            self._rollback_or_poison()
            raise
        self._commit_or_poison()
        self._clear_pending()
        self._terminal = True

    def fail(self, reason: str) -> None:
        """Retain the exact observed prefix while marking it non-poolable."""

        self._ensure_open()
        if not isinstance(reason, str) or not reason:
            raise ValidationError("failure reason must be a nonempty string")
        try:
            self._connection.execute("BEGIN IMMEDIATE")
            self._flush_in_transaction()
            self._connection.execute(
                "UPDATE run_state SET status = 'failed', failure_reason = ? WHERE singleton = 1",
                (reason,),
            )
        except BaseException:
            self._rollback_or_poison()
            raise
        self._commit_or_poison()
        self._clear_pending()
        self._terminal = True

    def close(self) -> None:
        if not self._closed:
            self._connection.close()
            self._closed = True

    def __enter__(self) -> "CompactObservationRecorder":
        return self

    def __exit__(self, exc_type: Any, exc: BaseException | None, traceback: Any) -> None:
        try:
            if exc is not None and not self._terminal:
                self.fail(f"{type(exc).__name__}: {exc}")
        finally:
            self.close()


class CompactObservationReader:
    """Read completed observations as primary-key-ordered streams."""

    def __init__(self, path: str | Path, *, require_complete: bool = True) -> None:
        self.path = Path(path)
        if not self.path.is_file():
            raise ValidationError("observation database does not exist", context={"path": str(self.path)})
        uri = "file:" + quote(str(self.path.resolve()), safe="/") + "?mode=ro"
        self._connection = sqlite3.connect(uri, uri=True)
        self._connection.execute("PRAGMA query_only = ON")
        self._closed = False
        row = self._connection.execute(
            """
            SELECT format_version, unit_kind, window_start, window_stop,
                   status, failure_reason, metadata_json
            FROM run_state WHERE singleton = 1
            """
        ).fetchone()
        if row is None:
            self.close()
            raise ValidationError("observation database has no run state")
        if row[0] != OBSERVATION_FORMAT_VERSION:
            self.close()
            raise ValidationError("unsupported observation format", context={"format_version": row[0]})
        self.state = RunObservationState(
            format_version=row[0],
            unit_kind=row[1],
            window_start=row[2],
            window_stop=row[3],
            status=row[4],
            failure_reason=row[5],
            metadata=json.loads(row[6], parse_float=Decimal),
        )
        if require_complete and self.state.status != STATUS_COMPLETE:
            self.close()
            raise ValidationError(
                "observation database is not complete",
                context={"status": self.state.status},
            )

    def _ensure_open(self) -> None:
        if self._closed:
            raise ValidationError("observation reader is closed")

    def iter_targets(self, *, target_id: str | None = None) -> Iterator[StoredObservationTarget]:
        """Stream configured targets in their stable identifier order."""

        self._ensure_open()
        sql = "SELECT target_id, queue_id_json, mass_kind, gap_mode FROM targets"
        params: tuple[Any, ...] = ()
        if target_id is not None:
            sql += " WHERE target_id = ?"
            params = (target_id,)
        sql += " ORDER BY target_id"
        cursor = self._connection.execute(sql, params)
        for stored_target_id, queue_id_json, mass_kind, gap_mode in cursor:
            yield StoredObservationTarget(
                stored_target_id,
                json.loads(queue_id_json, parse_float=Decimal),
                mass_kind,
                gap_mode,
            )

    def iter_blocks(self, *, block_id: int | None = None) -> Iterator[ObservationBlock]:
        """Stream exact scientific block intervals."""

        self._ensure_open()
        sql = "SELECT block_id, start_slot, stop_slot FROM blocks"
        params: tuple[Any, ...] = ()
        if block_id is not None:
            normalized_block_id = _nonnegative_int(
                block_id,
                name="block_id",
                sqlite_sized=True,
            )
            sql += " WHERE block_id = ?"
            params = (normalized_block_id,)
        sql += " ORDER BY block_id"
        cursor = self._connection.execute(sql, params)
        for block_id, start_slot, stop_slot in cursor:
            yield ObservationBlock(block_id, start_slot, stop_slot)

    def pooling_structure(self) -> tuple[Any, ...]:
        """Return the small scientific structure that level pooling must share."""

        self._ensure_open()
        targets = tuple(
            self._connection.execute(
                "SELECT target_id, queue_id_json, mass_kind, gap_mode FROM targets ORDER BY target_id"
            )
        )
        blocks = tuple(
            self._connection.execute(
                "SELECT block_id, start_slot, stop_slot FROM blocks ORDER BY block_id"
            )
        )
        return (
            self.state.format_version,
            self.state.unit_kind,
            self.state.window_start,
            self.state.window_stop,
            targets,
            blocks,
        )

    def iter_levels(
        self,
        *,
        target_id: str | None = None,
        block_id: int | None = None,
    ) -> Iterator[LevelRow]:
        self._ensure_open()
        sql = """
            SELECT l.block_id, l.target_id, l.backlog, t.mass_kind, t.gap_mode,
                   l.exposure, l.served,
                   l.gap_negative, l.gap_zero, l.gap_positive,
                   l.gap_zero_served, l.gap_positive_sum, l.gap_negative_sum
            FROM levels AS l JOIN targets AS t USING (target_id)
        """
        clauses: list[str] = []
        params: list[Any] = []
        if target_id is not None:
            clauses.append("l.target_id = ?")
            params.append(target_id)
        if block_id is not None:
            clauses.append("l.block_id = ?")
            params.append(_nonnegative_int(block_id, name="block_id", sqlite_sized=True))
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY l.block_id, l.target_id, l.backlog"
        cursor = self._connection.execute(sql, tuple(params))
        for row in cursor:
            gap_values = _decode_gap_columns(
                row[7:13],
                gap_mode=row[4],
                context={"block_id": row[0], "target_id": row[1], "backlog": row[2]},
            )
            yield LevelRow(
                row[0],
                row[1],
                row[2],
                row[3],
                row[4],
                decode_bigint(row[5]),
                decode_bigint(row[6]),
                *gap_values,
            )

    def iter_boundaries(
        self,
        *,
        target_id: str | None = None,
        block_id: int | None = None,
    ) -> Iterator[BoundaryRow]:
        self._ensure_open()
        sql = """
            SELECT b.block_id, b.target_id, b.side, b.backlog, t.mass_kind, b.mass
            FROM boundaries AS b JOIN targets AS t USING (target_id)
        """
        clauses: list[str] = []
        params: list[Any] = []
        if target_id is not None:
            clauses.append("b.target_id = ?")
            params.append(target_id)
        if block_id is not None:
            clauses.append("b.block_id = ?")
            params.append(_nonnegative_int(block_id, name="block_id", sqlite_sized=True))
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY b.block_id, b.target_id, b.side, b.backlog"
        cursor = self._connection.execute(sql, tuple(params))
        for row in cursor:
            yield BoundaryRow(row[0], row[1], row[2], row[3], row[4], decode_bigint(row[5]))

    def iter_target_blocks(
        self,
        *,
        target_id: str | None = None,
        block_id: int | None = None,
    ) -> Iterator[TargetBlockRow]:
        self._ensure_open()
        sql = """
            SELECT x.block_id, x.target_id, t.mass_kind, x.slots_observed,
                   x.decision_mass, x.offered, x.offered_square,
                   x.admitted, x.admitted_square, x.dropped
            FROM target_blocks AS x JOIN targets AS t USING (target_id)
        """
        clauses: list[str] = []
        params: list[Any] = []
        if target_id is not None:
            clauses.append("x.target_id = ?")
            params.append(target_id)
        if block_id is not None:
            clauses.append("x.block_id = ?")
            params.append(_nonnegative_int(block_id, name="block_id", sqlite_sized=True))
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY x.block_id, x.target_id"
        cursor = self._connection.execute(sql, tuple(params))
        for row in cursor:
            yield TargetBlockRow(
                row[0],
                row[1],
                row[2],
                row[3],
                *(decode_bigint(value) for value in row[4:]),
            )

    def iter_supplied_responses(
        self,
        *,
        target_id: str | None = None,
        block_id: int | None = None,
    ) -> Iterator[SuppliedResponseRow]:
        self._ensure_open()
        sql = """
            SELECT block_id, target_id, coefficient_kind, coefficient_index,
                   value, status, exposure, served
            FROM supplied_responses
        """
        clauses: list[str] = []
        params: list[Any] = []
        if target_id is not None:
            clauses.append("target_id = ?")
            params.append(target_id)
        if block_id is not None:
            clauses.append("block_id = ?")
            params.append(_nonnegative_int(block_id, name="block_id", sqlite_sized=True))
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY block_id, target_id, coefficient_kind, coefficient_index"
        cursor = self._connection.execute(sql, tuple(params))
        for row in cursor:
            yield SuppliedResponseRow(
                row[0], row[1], row[2], row[3], row[4], row[5], decode_bigint(row[6]), decode_bigint(row[7])
            )

    def integrity_check(self) -> None:
        """Validate SQLite structure and exact persisted scientific invariants."""

        self._ensure_open()
        result = self._connection.execute("PRAGMA integrity_check").fetchone()
        if result != ("ok",):
            raise ValidationError("SQLite integrity check failed", context={"result": result})
        foreign_keys = tuple(self._connection.execute("PRAGMA foreign_key_check"))
        if foreign_keys:
            raise ValidationError("SQLite foreign-key check failed", context={"rows": foreign_keys})
        _validate_persisted_scientific_invariants(
            self._connection,
            unit_kind=self.state.unit_kind,
            window_start=self.state.window_start,
            window_stop=self.state.window_stop,
            require_complete=self.state.status == STATUS_COMPLETE,
        )

    def close(self) -> None:
        if not self._closed:
            self._connection.close()
            self._closed = True

    def __enter__(self) -> "CompactObservationReader":
        return self

    def __exit__(self, exc_type: Any, exc: BaseException | None, traceback: Any) -> None:
        self.close()


def merge_level_streams(readers: Iterable[CompactObservationReader]) -> Iterator[LevelRow]:
    """Pool complete level rows without materializing any run's level set."""

    normalized_readers = tuple(readers)
    if not normalized_readers:
        return
    metadata_key: str | None = None
    identities: set[tuple[Any, ...]] = set()
    for reader_index, reader in enumerate(normalized_readers):
        if reader.state.status != STATUS_COMPLETE:
            raise ValidationError(
                "only complete statistical units may be pooled",
                context={"reader_index": reader_index, "status": reader.state.status},
            )
        key = _scientific_pooling_key(reader.state.metadata)
        if metadata_key is None:
            metadata_key = key
        elif key != metadata_key:
            raise ValidationError("observation units have incompatible scientific conditions")
        identity = _pooling_unit_identity(reader.state)
        if len(normalized_readers) > 1 and identity is None:
            raise ValidationError(
                "cannot verify independent scientific unit identity",
                context={"reader_index": reader_index, "unit_kind": reader.state.unit_kind},
            )
        if identity is not None:
            if identity in identities:
                raise ValidationError(
                    "duplicate independent scientific unit",
                    context={"reader_index": reader_index, "unit_kind": reader.state.unit_kind},
                )
            identities.add(identity)
    expected_structure = normalized_readers[0].pooling_structure()
    for reader in normalized_readers[1:]:
        if reader.pooling_structure() != expected_structure:
            raise ValidationError("observation structures are incompatible for pooling")

    streams = [iter(reader.iter_levels()) for reader in normalized_readers]
    heap: list[tuple[tuple[int, str, int], int, LevelRow]] = []
    for index, stream in enumerate(streams):
        row = next(stream, None)
        if row is not None:
            heapq.heappush(heap, ((row.block_id, row.target_id, row.backlog), index, row))
    while heap:
        key, index, row = heapq.heappop(heap)
        mass_kind = row.mass_kind
        gap_mode = row.gap_mode
        exposure = row.exposure
        served = row.served
        gap_values: list[int] | None
        raw_gap_values = (
            row.gap_negative,
            row.gap_zero,
            row.gap_positive,
            row.gap_zero_served,
            row.gap_positive_sum,
            row.gap_negative_sum,
        )
        if gap_mode == GAP_NONE:
            if any(value is not None for value in raw_gap_values):
                raise ValidationError("gap-disabled level row carries gap masses", context={"key": key})
            gap_values = None
        else:
            if any(value is None for value in raw_gap_values):
                raise ValidationError("exact-gap level row is missing gap masses", context={"key": key})
            gap_values = [int(value) for value in raw_gap_values if value is not None]
        replacement = next(streams[index], None)
        if replacement is not None:
            heapq.heappush(
                heap,
                ((replacement.block_id, replacement.target_id, replacement.backlog), index, replacement),
            )
        while heap and heap[0][0] == key:
            _, other_index, other = heapq.heappop(heap)
            if other.mass_kind != mass_kind or other.gap_mode != gap_mode:
                raise ValidationError(
                    "cannot pool level rows with different mass or gap kinds",
                    context={"key": key},
                )
            exposure += other.exposure
            served += other.served
            other_gap_values = (
                other.gap_negative,
                other.gap_zero,
                other.gap_positive,
                other.gap_zero_served,
                other.gap_positive_sum,
                other.gap_negative_sum,
            )
            if gap_values is None:
                if any(value is not None for value in other_gap_values):
                    raise ValidationError("gap-disabled level row carries gap masses", context={"key": key})
            else:
                if any(value is None for value in other_gap_values):
                    raise ValidationError("exact-gap level row is missing gap masses", context={"key": key})
                for value_index, value in enumerate(other_gap_values):
                    assert value is not None
                    gap_values[value_index] += value
            replacement = next(streams[other_index], None)
            if replacement is not None:
                heapq.heappush(
                    heap,
                    ((replacement.block_id, replacement.target_id, replacement.backlog), other_index, replacement),
                )
        emitted_gap_values: tuple[int | None, ...] = (
            (None, None, None, None, None, None)
            if gap_values is None
            else tuple(gap_values)
        )
        yield LevelRow(
            key[0],
            key[1],
            key[2],
            mass_kind,
            gap_mode,
            exposure,
            served,
            *emitted_gap_values,
        )


__all__ = [
    "OBSERVATION_FORMAT_VERSION",
    "BINARY64_LATTICE_EXPONENT",
    "BINARY64_NORMALIZED_MASS",
    "MASS_INTEGER",
    "MASS_BINARY64_LATTICE",
    "GAP_NONE",
    "GAP_EXACT",
    "STATUS_WRITING",
    "STATUS_COMPLETE",
    "STATUS_FAILED",
    "encode_bigint",
    "decode_bigint",
    "binary64_lattice_numerator",
    "binary64_lattice_value",
    "ObservationTarget",
    "ObservationBlock",
    "StoredObservationTarget",
    "make_observation_blocks",
    "TargetSlotObservation",
    "WeightedTargetSample",
    "WeightedBoundarySample",
    "LevelRow",
    "BoundaryRow",
    "TargetBlockRow",
    "SuppliedResponseRow",
    "RunObservationState",
    "CompactObservationRecorder",
    "CompactObservationReader",
    "merge_level_streams",
]
