"""Static artifact payloads shared by canonical telemetry writers."""

from __future__ import annotations

from typing import Any, Mapping

from ..errors import ValidationError
from ..flows import FlowPlan, QueueFlowPlan
from ..types import JSONValue
from ..utils import normalize_for_json


def flow_plan_artifact(
    flow_plan: FlowPlan | QueueFlowPlan | Mapping[str, Any],
) -> dict[str, JSONValue]:
    if isinstance(flow_plan, (FlowPlan, QueueFlowPlan)):
        return flow_plan.to_dict()
    normalized = normalize_for_json(flow_plan)
    if not isinstance(normalized, dict):
        raise ValidationError("flow_plan artifact must normalize to a mapping")
    return normalized


def build_arrival_support_artifact(compiled: Any) -> dict[str, JSONValue]:
    """Build the schema-2 queue-addressed arrival-support artifact."""

    catalog = getattr(compiled, "queue_catalog", None)
    model = getattr(compiled, "model", None)
    flow_plan = getattr(compiled, "flow_plan", None)
    if catalog is None or model is None or flow_plan is None:
        raise ValidationError(
            "compiled arrival must expose queue_catalog, model, and flow_plan",
            context={"value_type": type(compiled).__name__},
        )
    live_queue_ids = getattr(compiled, "live_queue_ids", None)
    if not callable(live_queue_ids):
        raise ValidationError("compiled arrival must expose live_queue_ids()")
    metadata = getattr(compiled, "metadata", {})
    if not isinstance(metadata, Mapping):
        raise ValidationError("compiled arrival metadata must be a mapping")
    return {
        "schema_version": "2.0.0",
        "family": str(compiled.family),
        "queue_space": catalog.to_dict(),
        "queue_ids": list(catalog.queue_ids),
        "live_queue_ids": list(live_queue_ids()),
        "support_size": int(compiled.support_size),
        "flow_plan": flow_plan.to_dict(),
        "model": (
            model.to_dict()
            if hasattr(model, "to_dict")
            else normalize_for_json(model)
        ),
        "metadata": normalize_for_json(dict(metadata)),
    }


__all__ = ["flow_plan_artifact", "build_arrival_support_artifact"]
