from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

import numpy as np

from .errors import ValidationError
from .rng import (
    ARRIVAL_CATEGORICAL_SAMPLER,
    RNG_ENGINE_NAME,
    SEED_SCHEME_VERSION,
)
from .utils import canonical_json_dumps, canonical_sha256_hexdigest, normalize_for_json
from .version import SIMULATOR_VERSION

if TYPE_CHECKING:
    from .config import SimConfig

MANIFEST_SCHEMA_VERSION = "2.2.0"
SERVICE_MODEL_SCHEMA_VERSION = "1.0.0"


@dataclass(slots=True, frozen=True)
class RunManifest:
    """Persistent metadata needed to replay a simulator run exactly."""

    requested_seed: int
    actual_seed: int
    rng_engine: str = RNG_ENGINE_NAME
    rng_seed_scheme_version: int = SEED_SCHEME_VERSION
    numpy_version: str = np.__version__
    arrival_categorical_sampler: str = ARRIVAL_CATEGORICAL_SAMPLER
    schema_version: str = MANIFEST_SCHEMA_VERSION
    config_hash: str | None = None
    flow_plan_hash: str | None = None
    service_model_hash: str | None = None
    simulator_version: str = SIMULATOR_VERSION
    config_schema_version: str | None = None
    switch_kind: str | None = None
    n_queues: int | None = None
    service_family: str | None = None
    scheduler_name: str | None = None
    scheduler_algorithm_id: str | None = None
    scheduler_optimizer_id: str | None = None
    scheduler_params: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "requested_seed": self.requested_seed,
            "actual_seed": self.actual_seed,
            "rng_engine": self.rng_engine,
            "rng_seed_scheme_version": self.rng_seed_scheme_version,
            "numpy_version": self.numpy_version,
            "arrival_categorical_sampler": self.arrival_categorical_sampler,
            "simulator_version": self.simulator_version,
            "config_schema_version": self.config_schema_version,
            "switch_kind": self.switch_kind,
            "n_queues": self.n_queues,
            "service_family": self.service_family,
            "scheduler_name": self.scheduler_name,
            "scheduler_algorithm_id": self.scheduler_algorithm_id,
            "scheduler_optimizer_id": self.scheduler_optimizer_id,
            "scheduler_params": normalize_for_json(dict(self.scheduler_params)),
            "config_hash": self.config_hash,
            "flow_plan_hash": self.flow_plan_hash,
            "service_model_hash": self.service_model_hash,
            "metadata": normalize_for_json(dict(self.metadata)),
        }


def hash_resolved_config(config: Any) -> str:
    """Hash a resolved config using canonical JSON serialization."""

    return canonical_sha256_hexdigest({"kind": "resolved_config", "payload": config})


def hash_flow_plan(flow_plan: Any) -> str:
    """Hash a flow plan using canonical JSON serialization."""

    return canonical_sha256_hexdigest({"kind": "flow_plan", "payload": flow_plan})


def build_service_model(config: "SimConfig") -> dict[str, Any]:
    """Build the canonical, topology-only service model for a resolved run.

    The artifact intentionally excludes scheduler runtime state and arrival
    configuration.  Generalized service constraints are scheduler-owned; their
    canonical definition is the effective ``scheduler.params.constraint``
    mapping.  Scheduler algorithm identity, exact-optimizer identity,
    priority, and optimizer tuning remain in the resolved config or run
    manifest, but do not change the physical feasible-set hash.
    """

    from .config import SimConfig

    if not isinstance(config, SimConfig):
        raise ValidationError(
            "config must be a SimConfig",
            context={"value_type": type(config).__name__},
        )

    switch = config.switch
    queue_entries: list[dict[str, Any]] = []
    for index, spec in enumerate(switch.catalog.specs):
        item: dict[str, Any] = {"index": index, "queue_id": spec.queue_id}
        if spec.legacy_voq is not None:
            item["legacy_voq"] = list(spec.legacy_voq)
        queue_entries.append(item)

    if switch.kind != "generalized":
        raise ValidationError(
            "service-model artifacts require a canonical generalized switch",
            context={"switch_kind": switch.kind},
        )
    service_family = config.scheduler.service_family
    if service_family is None:
        raise ValidationError(
            "SchedulerConfig must contain a canonical service_family"
        )
    if service_family != "unconstrained" and "constraint" not in config.scheduler.params:
        raise ValidationError(
            "scheduler params must contain canonical 'constraint' data",
            context={"service_family": service_family},
        )
    raw_constraint = config.scheduler.params.get("constraint", {})
    if not isinstance(raw_constraint, Mapping):
        # Scheduler constructors should normally reject this first. Keep this
        # local so artifact hashing cannot serialize an ill-defined model.
        raise ValidationError("scheduler.params.constraint must be a mapping")
    service: dict[str, Any] = {
        "family": service_family,
        "constraint": normalize_for_json(dict(raw_constraint)),
    }

    return {
        "schema_version": SERVICE_MODEL_SCHEMA_VERSION,
        "switch_kind": switch.kind,
        "queue_capacity": switch.capacity,
        "queues": queue_entries,
        "service": service,
    }


def hash_service_model(service_model: Any) -> str:
    """Hash a canonical service model independently of arrival configuration."""

    return canonical_sha256_hexdigest({"kind": "service_model", "payload": service_model})


def write_service_model(service_model: Any, out_path: str | Path) -> Path:
    """Write ``service_model.json`` using the same canonical JSON as its hash."""

    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_json_dumps(service_model) + "\n", encoding="utf-8")
    return path


def write_run_manifest(manifest: RunManifest, out_path: str | Path) -> Path:
    """Write a run manifest as canonical JSON.

    Returns the resolved path written to disk.
    """

    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_json_dumps(manifest.to_dict()) + "\n", encoding="utf-8")
    return path


__all__ = [
    "MANIFEST_SCHEMA_VERSION",
    "SERVICE_MODEL_SCHEMA_VERSION",
    "RunManifest",
    "hash_resolved_config",
    "hash_flow_plan",
    "build_service_model",
    "hash_service_model",
    "write_service_model",
    "write_run_manifest",
]
