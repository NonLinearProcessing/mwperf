"""Canonical payload helpers for queue-addressed count arrival laws.

Schema 4 stores each family's strict payload in ``ArrivalConfig.params``.
Older binary-mask forms are interpreted only by the explicit migration code
in :mod:`voqsim.config`; they are not runtime arrival families.

All probability tables remain ordered lists.  Their order is part of seeded
replay because it fixes the categorical outcome-to-index mapping.  Queue IDs
are values rather than JSON object keys so integer and string identities cannot
be conflated by JSON normalization.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from numbers import Integral, Real
from typing import Any

from .errors import ConfigError
from .types import JSONValue, QueueId


COUNT_ARRIVAL_FAMILIES = frozenset(
    {
        "iid_independent_bernoulli",
        "iid_count_table",
        "markov_count_kernel",
        "iid_independent_poisson",
        "iid_mixed_poisson",
        "deterministic_trace",
        "independent_marked_renewal",
        "independent_private_markov_renewal",
        "shared_joint_round_markov_renewal",
        "periodic_global_phase",
        "periodic_source_delays",
    }
)
SUPPORTED_ARRIVAL_FAMILIES = COUNT_ARRIVAL_FAMILIES

SUPPORTED_INTERARRIVAL_KINDS = frozenset(
    {"deterministic", "finite_pmf", "geometric_grid"}
)

MAX_ARRIVAL_COUNT = (1 << 63) - 1

_LEGACY_BINARY_FIELDS = frozenset(
    {
        "allowed_edges",
        "alphabet_constraint",
        "alphabet",
        "states",
        "kernel",
        "initial",
        "lambda",
        "lambda_default",
        "lambda_overrides",
    }
)

_FAMILY_FIELDS: dict[str, frozenset[str]] = {
    "iid_independent_bernoulli": frozenset({"rates"}),
    "iid_count_table": frozenset({"outcomes"}),
    "markov_count_kernel": frozenset(
        {"states", "outcomes", "kernel", "initial"}
    ),
    "iid_independent_poisson": frozenset({"rates"}),
    "iid_mixed_poisson": frozenset({"rates", "modulation"}),
    "deterministic_trace": frozenset({"events"}),
    "independent_marked_renewal": frozenset({"sources"}),
    "independent_private_markov_renewal": frozenset({"sources"}),
    "shared_joint_round_markov_renewal": frozenset(
        {"sources", "states", "initial", "outcomes"}
    ),
    "periodic_global_phase": frozenset({"period", "phase", "sources"}),
    "periodic_source_delays": frozenset({"period", "sources"}),
}


def _ensure_mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ConfigError(
            f"{name} must be a mapping/object",
            context={"value_type": type(value).__name__},
        )
    return value


def _ensure_sequence(value: Any, *, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ConfigError(
            f"{name} must be a sequence",
            context={"value_type": type(value).__name__},
        )
    return value


def _check_keys(
    mapping: Mapping[str, Any],
    *,
    name: str,
    allowed: frozenset[str] | set[str],
    required: frozenset[str] | set[str] = frozenset(),
) -> None:
    non_string = [key for key in mapping if not isinstance(key, str)]
    if non_string:
        raise ConfigError(
            f"{name} keys must be strings",
            context={"keys": non_string},
        )
    extras = sorted(set(mapping) - set(allowed))
    if extras:
        raise ConfigError(f"Unknown keys in {name}", context={"unknown_keys": extras})
    missing = sorted(set(required) - set(mapping))
    if missing:
        raise ConfigError(f"Missing required keys in {name}", context={"missing_keys": missing})


def _coerce_int(
    value: Any,
    *,
    name: str,
    minimum: int,
    maximum: int | None = None,
) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ConfigError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < minimum:
        raise ConfigError(
            f"{name} must be >= {minimum}",
            context={"value": result, "minimum": minimum},
        )
    if maximum is not None and result > maximum:
        raise ConfigError(
            f"{name} must be <= {maximum}",
            context={"value": result, "maximum": maximum},
        )
    return result


def _coerce_probability(value: Any, *, name: str) -> Decimal:
    """Parse retained-family probabilities without discarding Decimal input."""

    return _coerce_exact_probability(value, name=name)


def _coerce_exact_decimal(
    value: Any,
    *,
    name: str,
    minimum: Decimal = Decimal(0),
    maximum: Decimal | None = None,
) -> Decimal:
    """Return one finite canonical decimal without binary-float arithmetic.

    Programmatic configuration dictionaries historically contain Python
    ``float`` values, while schema-4 loaders retain decimal number tokens as
    ``Decimal``.  Converting through ``str`` gives both paths the same human
    decimal interpretation and, importantly, keeps all validation and moment
    identities in exact decimal arithmetic.
    """

    if isinstance(value, bool) or not isinstance(value, (Decimal, Integral, Real)):
        raise ConfigError(
            f"{name} must be a finite decimal number",
            context={"value": value, "value_type": type(value).__name__},
        )
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ConfigError(
            f"{name} must be a finite decimal number",
            context={"value": value},
        ) from exc
    if not result.is_finite():
        raise ConfigError(f"{name} must be finite", context={"value": value})
    if result < minimum:
        raise ConfigError(
            f"{name} must be >= {minimum}",
            context={"value": result, "minimum": minimum},
        )
    if maximum is not None and result > maximum:
        raise ConfigError(
            f"{name} must be <= {maximum}",
            context={"value": result, "maximum": maximum},
        )
    # One spelling for both signed decimal zeros makes canonical hashes stable.
    return Decimal(0) if result == 0 else result


def _coerce_exact_probability(value: Any, *, name: str) -> Decimal:
    return _coerce_exact_decimal(
        value,
        name=name,
        minimum=Decimal(0),
        maximum=Decimal(1),
    )


def _fraction_to_exact_decimal(value: Fraction) -> Decimal:
    denominator = value.denominator
    twos = 0
    fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:  # pragma: no cover - Decimal inputs always terminate
        raise ConfigError("Exact decimal value has a non-terminating expansion")
    # Direct integer scaling avoids dependence on the process Decimal context.
    places = max(twos, fives)
    scaled = value.numerator * (2 ** (places - fives)) * (5 ** (places - twos))
    if scaled == 0:
        return Decimal(0)
    digits = tuple(int(character) for character in str(abs(scaled)))
    return Decimal((1 if scaled < 0 else 0, digits, -places))


def _normalize_token(value: Any, *, name: str) -> str:
    if not isinstance(value, str):
        raise ConfigError(f"{name} must be a string", context={"value": value})
    token = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in token:
        token = token.replace("__", "_")
    token = token.strip("_")
    if not token:
        raise ConfigError(f"{name} must not be empty", context={"value": value})
    return token


def _parse_queue_id(value: Any, *, name: str) -> QueueId:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ConfigError(
            f"{name} must be a non-negative integer or non-empty string",
            context={"value": value, "value_type": type(value).__name__},
        )
    if isinstance(value, int):
        if value < 0:
            raise ConfigError(f"{name} must be non-negative", context={"value": value})
        return int(value)
    if not value or not value.strip():
        raise ConfigError(f"{name} must not be empty", context={"value": value})
    if value != value.strip():
        raise ConfigError(
            f"{name} must not contain leading or trailing whitespace",
            context={"value": value},
        )
    return value


def _queue_id_sort_key(queue_id: QueueId) -> tuple[int, int | str]:
    if isinstance(queue_id, int):
        return (0, queue_id)
    return (1, queue_id)


def _parse_probability_rows(
    raw: Any,
    *,
    name: str,
    coordinate_fields: tuple[str, ...],
) -> list[dict[str, JSONValue]]:
    rows: list[dict[str, JSONValue]] = []
    for index, item in enumerate(_ensure_sequence(raw, name=name)):
        row_name = f"{name}[{index}]"
        mapping = _ensure_mapping(item, name=row_name)
        allowed = frozenset((*coordinate_fields, "probability"))
        _check_keys(mapping, name=row_name, allowed=allowed, required=allowed)
        row: dict[str, JSONValue] = {}
        for field_name in coordinate_fields:
            value = mapping[field_name]
            if field_name == "queue_id":
                row[field_name] = _parse_queue_id(value, name=f"{row_name}.{field_name}")
            elif field_name == "d":
                row[field_name] = _coerce_int(
                    value,
                    name=f"{row_name}.{field_name}",
                    minimum=1,
                )
            else:  # pragma: no cover - private helper has a closed field set
                raise AssertionError(f"unsupported PMF coordinate field {field_name!r}")
        row["probability"] = _coerce_probability(
            mapping["probability"],
            name=f"{row_name}.probability",
        )
        rows.append(row)
    return rows


def _parse_initial(raw: Any, *, name: str) -> dict[str, JSONValue]:
    mapping = _ensure_mapping(raw, name=name)
    _check_keys(
        mapping,
        name=name,
        allowed=frozenset({"state", "distribution"}),
    )
    if ("state" in mapping) == ("distribution" in mapping):
        raise ConfigError(f"{name} must choose exactly one of 'state' or 'distribution'")
    if "state" in mapping:
        return {"state": _normalize_token(mapping["state"], name=f"{name}.state")}

    distribution = _ensure_mapping(mapping["distribution"], name=f"{name}.distribution")
    normalized: dict[str, JSONValue] = {}
    for raw_state, raw_probability in distribution.items():
        state = _normalize_token(raw_state, name=f"{name}.distribution key")
        if state in normalized:
            raise ConfigError(
                f"{name}.distribution contains duplicate canonical state ids",
                context={"state": state},
            )
        normalized[state] = _coerce_probability(
            raw_probability,
            name=f"{name}.distribution[{raw_state!r}]",
        )
    return {"distribution": {state: normalized[state] for state in sorted(normalized)}}


def _parse_trace_events(raw: Any) -> list[dict[str, JSONValue]]:
    aggregated: dict[tuple[int, QueueId], int] = {}
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.events")):
        name = f"arrival.events[{index}]"
        mapping = _ensure_mapping(item, name=name)
        required = frozenset({"slot", "queue_id", "count"})
        _check_keys(mapping, name=name, allowed=required, required=required)
        slot = _coerce_int(mapping["slot"], name=f"{name}.slot", minimum=0)
        queue_id = _parse_queue_id(mapping["queue_id"], name=f"{name}.queue_id")
        count = _coerce_int(
            mapping["count"],
            name=f"{name}.count",
            minimum=1,
            maximum=MAX_ARRIVAL_COUNT,
        )
        key = (slot, queue_id)
        total = aggregated.get(key, 0) + count
        if total > MAX_ARRIVAL_COUNT:
            raise ConfigError(
                "Aggregated deterministic arrival count exceeds int64 capacity",
                context={"slot": slot, "queue_id": queue_id, "count": total},
            )
        aggregated[key] = total

    ordered = sorted(
        aggregated.items(),
        key=lambda item: (item[0][0], _queue_id_sort_key(item[0][1])),
    )
    return [
        {"slot": slot, "queue_id": queue_id, "count": count}
        for (slot, queue_id), count in ordered
    ]


def _parse_cycle_entries(raw: Any, *, name: str) -> list[dict[str, JSONValue]]:
    aggregated: dict[tuple[int, QueueId], int] = {}
    for index, item in enumerate(_ensure_sequence(raw, name=name)):
        entry_name = f"{name}[{index}]"
        mapping = _ensure_mapping(item, name=entry_name)
        required = frozenset({"offset", "queue_id", "count"})
        _check_keys(mapping, name=entry_name, allowed=required, required=required)
        offset = _coerce_int(mapping["offset"], name=f"{entry_name}.offset", minimum=0)
        queue_id = _parse_queue_id(mapping["queue_id"], name=f"{entry_name}.queue_id")
        count = _coerce_int(
            mapping["count"],
            name=f"{entry_name}.count",
            minimum=1,
            maximum=MAX_ARRIVAL_COUNT,
        )
        key = (offset, queue_id)
        total = aggregated.get(key, 0) + count
        if total > MAX_ARRIVAL_COUNT:
            raise ConfigError(
                "Aggregated periodic arrival count exceeds int64 capacity",
                context={"offset": offset, "queue_id": queue_id, "count": total},
            )
        aggregated[key] = total

    ordered = sorted(
        aggregated.items(),
        key=lambda item: (item[0][0], _queue_id_sort_key(item[0][1])),
    )
    return [
        {"offset": offset, "queue_id": queue_id, "count": count}
        for (offset, queue_id), count in ordered
    ]


def _parse_periodic_sources(raw: Any, *, delayed: bool) -> list[dict[str, JSONValue]]:
    sources: list[dict[str, JSONValue]] = []
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.sources")):
        name = f"arrival.sources[{index}]"
        mapping = _ensure_mapping(item, name=name)
        allowed = frozenset({"id", "entries", "delay"} if delayed else {"id", "entries"})
        _check_keys(mapping, name=name, allowed=allowed, required=allowed)
        source: dict[str, JSONValue] = {
            "id": _normalize_token(mapping["id"], name=f"{name}.id"),
        }
        if delayed:
            source["delay"] = _coerce_int(
                mapping["delay"],
                name=f"{name}.delay",
                minimum=0,
            )
        source["entries"] = _parse_cycle_entries(mapping["entries"], name=f"{name}.entries")
        sources.append(source)
    return sources


def _parse_interarrival(raw: Any, *, name: str) -> dict[str, JSONValue]:
    mapping = _ensure_mapping(raw, name=name)
    if "kind" not in mapping:
        raise ConfigError(f"Missing required key in {name}", context={"key": "kind"})
    kind = _normalize_token(mapping["kind"], name=f"{name}.kind")
    if kind not in SUPPORTED_INTERARRIVAL_KINDS:
        raise ConfigError(
            f"Unsupported {name}.kind",
            context={"kind": kind, "allowed": sorted(SUPPORTED_INTERARRIVAL_KINDS)},
        )
    if kind == "deterministic":
        required = frozenset({"kind", "d"})
        _check_keys(mapping, name=name, allowed=required, required=required)
        return {
            "kind": kind,
            "d": _coerce_int(mapping["d"], name=f"{name}.d", minimum=1),
        }
    if kind == "finite_pmf":
        required = frozenset({"kind", "outcomes"})
        _check_keys(mapping, name=name, allowed=required, required=required)
        return {
            "kind": kind,
            "outcomes": _parse_probability_rows(
                mapping["outcomes"],
                name=f"{name}.outcomes",
                coordinate_fields=("d",),
            ),
        }

    required = frozenset({"kind", "d_min", "delta", "p"})
    _check_keys(mapping, name=name, allowed=required, required=required)
    return {
        "kind": kind,
        "d_min": _coerce_int(mapping["d_min"], name=f"{name}.d_min", minimum=1),
        "delta": _coerce_int(mapping["delta"], name=f"{name}.delta", minimum=1),
        "p": _coerce_probability(mapping["p"], name=f"{name}.p"),
    }


def _parse_independent_sources(raw: Any) -> list[dict[str, JSONValue]]:
    sources: list[dict[str, JSONValue]] = []
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.sources")):
        name = f"arrival.sources[{index}]"
        mapping = _ensure_mapping(item, name=name)
        allowed = frozenset({"id", "interarrival", "destination_pmf", "joint_pmf"})
        _check_keys(mapping, name=name, allowed=allowed, required=frozenset({"id"}))
        has_joint = "joint_pmf" in mapping
        has_factorized_piece = "interarrival" in mapping or "destination_pmf" in mapping
        has_complete_factorized = "interarrival" in mapping and "destination_pmf" in mapping
        if has_joint and has_factorized_piece:
            raise ConfigError(
                f"{name} must choose joint_pmf or factorized interarrival/destination_pmf"
            )
        if not has_joint and not has_complete_factorized:
            raise ConfigError(
                f"{name} requires joint_pmf or both interarrival and destination_pmf"
            )

        source: dict[str, JSONValue] = {
            "id": _normalize_token(mapping["id"], name=f"{name}.id")
        }
        if has_joint:
            source["joint_pmf"] = _parse_probability_rows(
                mapping["joint_pmf"],
                name=f"{name}.joint_pmf",
                coordinate_fields=("d", "queue_id"),
            )
        else:
            source["interarrival"] = _parse_interarrival(
                mapping["interarrival"],
                name=f"{name}.interarrival",
            )
            source["destination_pmf"] = _parse_probability_rows(
                mapping["destination_pmf"],
                name=f"{name}.destination_pmf",
                coordinate_fields=("queue_id",),
            )
        sources.append(source)
    return sources


def _parse_private_sources(raw: Any) -> list[dict[str, JSONValue]]:
    sources: list[dict[str, JSONValue]] = []
    required = frozenset(
        {"id", "states", "initial", "gaps", "transitions", "destination_pmf"}
    )
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.sources")):
        name = f"arrival.sources[{index}]"
        mapping = _ensure_mapping(item, name=name)
        _check_keys(mapping, name=name, allowed=required, required=required)
        states = [
            _normalize_token(state, name=f"{name}.states[{state_index}]")
            for state_index, state in enumerate(_ensure_sequence(mapping["states"], name=f"{name}.states"))
        ]

        gaps: list[dict[str, JSONValue]] = []
        for gap_index, item_gap in enumerate(_ensure_sequence(mapping["gaps"], name=f"{name}.gaps")):
            gap_name = f"{name}.gaps[{gap_index}]"
            gap_mapping = _ensure_mapping(item_gap, name=gap_name)
            gap_keys = frozenset({"state", "d"})
            _check_keys(gap_mapping, name=gap_name, allowed=gap_keys, required=gap_keys)
            gaps.append(
                {
                    "state": _normalize_token(gap_mapping["state"], name=f"{gap_name}.state"),
                    "d": _coerce_int(gap_mapping["d"], name=f"{gap_name}.d", minimum=1),
                }
            )

        transitions: list[dict[str, JSONValue]] = []
        for transition_index, item_transition in enumerate(
            _ensure_sequence(mapping["transitions"], name=f"{name}.transitions")
        ):
            transition_name = f"{name}.transitions[{transition_index}]"
            transition_mapping = _ensure_mapping(item_transition, name=transition_name)
            transition_keys = frozenset({"state", "next_state", "probability"})
            _check_keys(
                transition_mapping,
                name=transition_name,
                allowed=transition_keys,
                required=transition_keys,
            )
            transitions.append(
                {
                    "state": _normalize_token(
                        transition_mapping["state"], name=f"{transition_name}.state"
                    ),
                    "next_state": _normalize_token(
                        transition_mapping["next_state"],
                        name=f"{transition_name}.next_state",
                    ),
                    "probability": _coerce_probability(
                        transition_mapping["probability"],
                        name=f"{transition_name}.probability",
                    ),
                }
            )

        sources.append(
            {
                "id": _normalize_token(mapping["id"], name=f"{name}.id"),
                "states": states,
                "initial": _parse_initial(mapping["initial"], name=f"{name}.initial"),
                "gaps": gaps,
                "transitions": transitions,
                "destination_pmf": _parse_probability_rows(
                    mapping["destination_pmf"],
                    name=f"{name}.destination_pmf",
                    coordinate_fields=("queue_id",),
                ),
            }
        )
    return sources


def _parse_shared_sources(raw: Any) -> list[dict[str, JSONValue]]:
    sources: list[dict[str, JSONValue]] = []
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.sources")):
        name = f"arrival.sources[{index}]"
        mapping = _ensure_mapping(item, name=name)
        keys = frozenset({"id"})
        _check_keys(mapping, name=name, allowed=keys, required=keys)
        sources.append({"id": _normalize_token(mapping["id"], name=f"{name}.id")})
    return sources


def _parse_shared_outcomes(
    raw: Any,
    *,
    source_ids: Sequence[str],
) -> list[dict[str, JSONValue]]:
    outcomes: list[dict[str, JSONValue]] = []
    source_order = {source_id: index for index, source_id in enumerate(source_ids)}
    for index, item in enumerate(_ensure_sequence(raw, name="arrival.outcomes")):
        name = f"arrival.outcomes[{index}]"
        mapping = _ensure_mapping(item, name=name)
        keys = frozenset({"state", "next_state", "probability", "emissions"})
        _check_keys(mapping, name=name, allowed=keys, required=keys)
        emissions: list[dict[str, JSONValue]] = []
        for emission_index, emission_item in enumerate(
            _ensure_sequence(mapping["emissions"], name=f"{name}.emissions")
        ):
            emission_name = f"{name}.emissions[{emission_index}]"
            emission_mapping = _ensure_mapping(emission_item, name=emission_name)
            emission_keys = frozenset({"source_id", "d", "queue_id"})
            _check_keys(
                emission_mapping,
                name=emission_name,
                allowed=emission_keys,
                required=emission_keys,
            )
            emissions.append(
                {
                    "source_id": _normalize_token(
                        emission_mapping["source_id"],
                        name=f"{emission_name}.source_id",
                    ),
                    "d": _coerce_int(
                        emission_mapping["d"], name=f"{emission_name}.d", minimum=1
                    ),
                    "queue_id": _parse_queue_id(
                        emission_mapping["queue_id"], name=f"{emission_name}.queue_id"
                    ),
                }
            )
        # Emission order is not stochastic; canonicalize it to declared source
        # order while leaving invalid/duplicate references for validation.
        emissions.sort(
            key=lambda emission: source_order.get(
                str(emission["source_id"]), len(source_order)
            )
        )
        outcomes.append(
            {
                "state": _normalize_token(mapping["state"], name=f"{name}.state"),
                "next_state": _normalize_token(
                    mapping["next_state"], name=f"{name}.next_state"
                ),
                "probability": _coerce_probability(
                    mapping["probability"], name=f"{name}.probability"
                ),
                "emissions": emissions,
            }
        )
    return outcomes


def _parse_rate_spec(
    raw: Any,
    *,
    name: str = "arrival.rates",
    maximum: Decimal | None = None,
) -> dict[str, Any]:
    mapping = _ensure_mapping(raw, name=name)
    required = frozenset({"default", "overrides"})
    _check_keys(mapping, name=name, allowed=required, required=required)
    default = _coerce_exact_decimal(
        mapping["default"], name=f"{name}.default", maximum=maximum
    )

    overrides: list[dict[str, Any]] = []
    seen: dict[QueueId, int] = {}
    for position, raw_override in enumerate(
        _ensure_sequence(mapping["overrides"], name=f"{name}.overrides")
    ):
        row_name = f"{name}.overrides[{position}]"
        override = _ensure_mapping(raw_override, name=row_name)
        required_row = frozenset({"queue_id", "rate"})
        _check_keys(
            override,
            name=row_name,
            allowed=required_row,
            required=required_row,
        )
        queue_id = _parse_queue_id(override["queue_id"], name=f"{row_name}.queue_id")
        if queue_id in seen:
            raise ConfigError(
                f"{name}.overrides contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_position": seen[queue_id],
                    "duplicate_position": position,
                },
            )
        seen[queue_id] = position
        overrides.append(
            {
                "queue_id": queue_id,
                "rate": _coerce_exact_decimal(
                    override["rate"], name=f"{row_name}.rate", maximum=maximum
                ),
            }
        )
    # Override record order is semantically relevant for explicit migration of
    # legacy Bernoulli draw coordinates, including zero-rate coordinates.
    return {"default": default, "overrides": overrides}


def _parse_sparse_counts(raw: Any, *, name: str) -> list[dict[str, Any]]:
    counts: list[dict[str, Any]] = []
    seen: dict[QueueId, int] = {}
    for position, raw_count in enumerate(_ensure_sequence(raw, name=name)):
        row_name = f"{name}[{position}]"
        row = _ensure_mapping(raw_count, name=row_name)
        required = frozenset({"queue_id", "count"})
        _check_keys(row, name=row_name, allowed=required, required=required)
        queue_id = _parse_queue_id(row["queue_id"], name=f"{row_name}.queue_id")
        if queue_id in seen:
            raise ConfigError(
                f"{name} contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_position": seen[queue_id],
                    "duplicate_position": position,
                },
            )
        seen[queue_id] = position
        counts.append(
            {
                "queue_id": queue_id,
                "count": _coerce_int(
                    row["count"],
                    name=f"{row_name}.count",
                    minimum=1,
                    maximum=MAX_ARRIVAL_COUNT,
                ),
            }
        )
    counts.sort(key=lambda row: _queue_id_sort_key(row["queue_id"]))
    return counts


def _parse_count_outcomes(
    raw: Any,
    *,
    probabilities: bool,
    name: str = "arrival.outcomes",
) -> list[dict[str, Any]]:
    sequence = _ensure_sequence(raw, name=name)
    if not sequence:
        raise ConfigError(f"{name} must not be empty")
    outcomes: list[dict[str, Any]] = []
    seen_ids: dict[str, int] = {}
    seen_vectors: dict[tuple[tuple[int, int | str], ...], int] = {}
    probability_total = Fraction(0)
    for position, raw_outcome in enumerate(sequence):
        row_name = f"{name}[{position}]"
        outcome = _ensure_mapping(raw_outcome, name=row_name)
        required = {"id", "counts"}
        if probabilities:
            required.add("probability")
        _check_keys(
            outcome,
            name=row_name,
            allowed=required,
            required=required,
        )
        outcome_id = _normalize_token(outcome["id"], name=f"{row_name}.id")
        if outcome_id in seen_ids:
            raise ConfigError(
                f"{name} contains a duplicate outcome id",
                context={
                    "id": outcome_id,
                    "first_position": seen_ids[outcome_id],
                    "duplicate_position": position,
                },
            )
        seen_ids[outcome_id] = position
        counts = _parse_sparse_counts(outcome["counts"], name=f"{row_name}.counts")
        coordinate = tuple(
            (_queue_id_sort_key(row["queue_id"]), int(row["count"]))
            for row in counts
        )
        if coordinate in seen_vectors:
            raise ConfigError(
                f"{name} contains a duplicate count vector",
                context={
                    "first_position": seen_vectors[coordinate],
                    "duplicate_position": position,
                },
            )
        seen_vectors[coordinate] = position
        parsed: dict[str, Any] = {"id": outcome_id, "counts": counts}
        if probabilities:
            probability = _coerce_exact_probability(
                outcome["probability"], name=f"{row_name}.probability"
            )
            probability_total += Fraction(probability)
            parsed["probability"] = probability
        outcomes.append(parsed)
    if probabilities and probability_total != 1:
        raise ConfigError(
            f"{name} probabilities must sum exactly to 1",
            context={"sum": probability_total},
        )
    return outcomes


def _parse_markov_count_payload(raw: Mapping[str, Any]) -> dict[str, Any]:
    raw_states = _ensure_sequence(raw["states"], name="arrival.states")
    if not raw_states:
        raise ConfigError("arrival.states must not be empty")
    states: list[str] = []
    state_order: dict[str, int] = {}
    for position, raw_state in enumerate(raw_states):
        state = _normalize_token(raw_state, name=f"arrival.states[{position}]")
        if state in state_order:
            raise ConfigError(
                "arrival.states contains duplicate canonical state ids",
                context={"state": state},
            )
        state_order[state] = position
        states.append(state)

    outcomes = _parse_count_outcomes(raw["outcomes"], probabilities=False)
    outcome_order = {
        str(outcome["id"]): position for position, outcome in enumerate(outcomes)
    }

    kernel: list[dict[str, Any]] = []
    outgoing = {state: Fraction(0) for state in states}
    seen_coordinates: dict[tuple[str, str, str], int] = {}
    for position, raw_row in enumerate(
        _ensure_sequence(raw["kernel"], name="arrival.kernel")
    ):
        row_name = f"arrival.kernel[{position}]"
        row = _ensure_mapping(raw_row, name=row_name)
        required = frozenset({"state", "outcome_id", "next_state", "probability"})
        _check_keys(row, name=row_name, allowed=required, required=required)
        state = _normalize_token(row["state"], name=f"{row_name}.state")
        outcome_id = _normalize_token(
            row["outcome_id"], name=f"{row_name}.outcome_id"
        )
        next_state = _normalize_token(
            row["next_state"], name=f"{row_name}.next_state"
        )
        if state not in state_order or next_state not in state_order:
            raise ConfigError(
                f"{row_name} references an unknown state",
                context={"state": state, "next_state": next_state},
            )
        if outcome_id not in outcome_order:
            raise ConfigError(
                f"{row_name} references an unknown outcome",
                context={"outcome_id": outcome_id},
            )
        coordinate = (state, outcome_id, next_state)
        if coordinate in seen_coordinates:
            raise ConfigError(
                "arrival.kernel contains a duplicate transition coordinate",
                context={
                    "state": state,
                    "outcome_id": outcome_id,
                    "next_state": next_state,
                },
            )
        seen_coordinates[coordinate] = position
        probability = _coerce_exact_probability(
            row["probability"], name=f"{row_name}.probability"
        )
        outgoing[state] += Fraction(probability)
        kernel.append(
            {
                "state": state,
                "outcome_id": outcome_id,
                "next_state": next_state,
                "probability": probability,
            }
        )
    for state, total in outgoing.items():
        if total != 1:
            raise ConfigError(
                "arrival.kernel outgoing probabilities must sum exactly to 1",
                context={"state": state, "sum": total},
            )
    kernel.sort(
        key=lambda row: (
            state_order[str(row["state"])],
            outcome_order[str(row["outcome_id"])],
            state_order[str(row["next_state"])],
        )
    )

    initial_mapping = _ensure_mapping(raw["initial"], name="arrival.initial")
    _check_keys(
        initial_mapping,
        name="arrival.initial",
        allowed=frozenset({"state", "distribution"}),
    )
    if ("state" in initial_mapping) == ("distribution" in initial_mapping):
        raise ConfigError(
            "arrival.initial must choose exactly one of 'state' or 'distribution'"
        )
    if "state" in initial_mapping:
        initial: dict[str, Any] = {
            "state": _normalize_token(
                initial_mapping["state"], name="arrival.initial.state"
            )
        }
    else:
        raw_distribution = _ensure_mapping(
            initial_mapping["distribution"], name="arrival.initial.distribution"
        )
        exact_distribution: dict[str, Decimal] = {}
        for raw_state, raw_probability in raw_distribution.items():
            state = _normalize_token(
                raw_state, name="arrival.initial.distribution key"
            )
            if state in exact_distribution:
                raise ConfigError(
                    "arrival.initial.distribution contains duplicate canonical state ids",
                    context={"state": state},
                )
            exact_distribution[state] = _coerce_exact_probability(
                raw_probability,
                name=f"arrival.initial.distribution[{raw_state!r}]",
            )
        initial = {
            "distribution": {
                state: exact_distribution[state] for state in sorted(exact_distribution)
            }
        }
    if "state" in initial:
        initial_state = str(initial["state"])
        if initial_state not in state_order:
            raise ConfigError(
                "arrival.initial.state is unknown",
                context={"state": initial_state},
            )
    else:
        distribution = initial["distribution"]
        assert isinstance(distribution, dict)
        if set(distribution) != set(states):
            raise ConfigError(
                "arrival.initial.distribution must define every state exactly once",
                context={
                    "missing_states": sorted(set(states) - set(distribution)),
                    "unknown_states": sorted(set(distribution) - set(states)),
                },
            )
        exact_distribution = {state: distribution[state] for state in states}
        total = sum((Fraction(value) for value in exact_distribution.values()), Fraction(0))
        if total != 1:
            raise ConfigError(
                "arrival.initial.distribution must sum exactly to 1",
                context={"sum": total},
            )
        initial = {"distribution": exact_distribution}
    return {
        "states": states,
        "outcomes": outcomes,
        "kernel": kernel,
        "initial": initial,
    }


def _parse_modulation(raw: Any) -> dict[str, Any]:
    mapping = _ensure_mapping(raw, name="arrival.modulation")
    required = frozenset({"scope", "states"})
    derived = frozenset({"mean_multiplier", "second_moment_multiplier"})
    _check_keys(
        mapping,
        name="arrival.modulation",
        allowed=required | derived,
        required=required,
    )
    scope = _normalize_token(mapping["scope"], name="arrival.modulation.scope")
    if scope not in {"independent_queue", "shared"}:
        raise ConfigError(
            "arrival.modulation.scope must be 'independent_queue' or 'shared'",
            context={"scope": scope},
        )
    raw_states = _ensure_sequence(mapping["states"], name="arrival.modulation.states")
    if not raw_states:
        raise ConfigError("arrival.modulation.states must not be empty")
    states: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    probability_total = Fraction(0)
    exact_mean = Fraction(0)
    exact_second_moment = Fraction(0)
    for position, raw_state in enumerate(raw_states):
        name = f"arrival.modulation.states[{position}]"
        state = _ensure_mapping(raw_state, name=name)
        required_state = frozenset({"id", "probability", "multiplier"})
        _check_keys(
            state,
            name=name,
            allowed=required_state,
            required=required_state,
        )
        state_id = _normalize_token(state["id"], name=f"{name}.id")
        if state_id in seen_ids:
            raise ConfigError(
                "arrival.modulation.states contains duplicate ids",
                context={"id": state_id},
            )
        seen_ids.add(state_id)
        probability = _coerce_exact_probability(
            state["probability"], name=f"{name}.probability"
        )
        multiplier = _coerce_exact_decimal(
            state["multiplier"], name=f"{name}.multiplier"
        )
        probability_total += Fraction(probability)
        exact_mean += Fraction(probability) * Fraction(multiplier)
        exact_second_moment += (
            Fraction(probability) * Fraction(multiplier) * Fraction(multiplier)
        )
        states.append(
            {
                "id": state_id,
                "probability": probability,
                "multiplier": multiplier,
            }
        )
    if probability_total != 1:
        raise ConfigError(
            "arrival.modulation probabilities must sum exactly to 1",
            context={"sum": probability_total},
        )
    if exact_mean != 1:
        raise ConfigError(
            "arrival.modulation must satisfy E[M] == 1 exactly",
            context={"mean": str(exact_mean)},
        )
    mean_multiplier = _fraction_to_exact_decimal(exact_mean)
    second_moment_multiplier = _fraction_to_exact_decimal(exact_second_moment)
    expected_derived = {
        "mean_multiplier": mean_multiplier,
        "second_moment_multiplier": second_moment_multiplier,
    }
    for field_name, expected in expected_derived.items():
        if field_name not in mapping:
            continue
        supplied = _coerce_exact_decimal(
            mapping[field_name], name=f"arrival.modulation.{field_name}"
        )
        if supplied != expected:
            raise ConfigError(
                f"arrival.modulation.{field_name} does not match the configured states",
                context={"supplied": supplied, "expected": expected},
            )
    return {
        "scope": scope,
        "states": states,
        **expected_derived,
    }


def parse_count_arrival_params(
    family: str,
    raw: Mapping[str, Any],
) -> dict[str, JSONValue]:
    """Parse one new-family arrival section into its canonical ``params`` map."""

    if family not in COUNT_ARRIVAL_FAMILIES:
        raise ConfigError(
            "parse_count_arrival_params requires a count-valued family",
            context={"family": family},
        )
    # Shared Markov renewal intentionally owns top-level ``states`` and
    # ``initial`` fields.  They are legacy-only for the other five count laws.
    forbidden = sorted(set(raw) & (_LEGACY_BINARY_FIELDS - _FAMILY_FIELDS[family]))
    if forbidden:
        raise ConfigError(
            "Queue-addressed arrival families must not use legacy binary arrival fields",
            context={"family": family, "forbidden_keys": forbidden},
        )
    family_fields = _FAMILY_FIELDS[family]
    _check_keys(
        raw,
        name="arrival section",
        allowed=set(family_fields) | {"family", "metadata"},
        required=family_fields,
    )

    if family == "iid_independent_bernoulli":
        return {
            "rates": _parse_rate_spec(raw["rates"], maximum=Decimal(1))
        }
    if family == "iid_independent_poisson":
        return {"rates": _parse_rate_spec(raw["rates"])}
    if family == "iid_mixed_poisson":
        return {
            "rates": _parse_rate_spec(raw["rates"]),
            "modulation": _parse_modulation(raw["modulation"]),
        }
    if family == "iid_count_table":
        return {
            "outcomes": _parse_count_outcomes(
                raw["outcomes"], probabilities=True
            )
        }
    if family == "markov_count_kernel":
        return _parse_markov_count_payload(raw)
    if family == "deterministic_trace":
        return {"events": _parse_trace_events(raw["events"])}
    if family == "periodic_global_phase":
        return {
            "period": _coerce_int(raw["period"], name="arrival.period", minimum=1),
            "phase": _coerce_int(raw["phase"], name="arrival.phase", minimum=0),
            "sources": _parse_periodic_sources(raw["sources"], delayed=False),
        }
    if family == "periodic_source_delays":
        return {
            "period": _coerce_int(raw["period"], name="arrival.period", minimum=1),
            "sources": _parse_periodic_sources(raw["sources"], delayed=True),
        }
    if family == "independent_marked_renewal":
        return {"sources": _parse_independent_sources(raw["sources"])}
    if family == "independent_private_markov_renewal":
        return {"sources": _parse_private_sources(raw["sources"])}

    sources = _parse_shared_sources(raw["sources"])
    states = [
        _normalize_token(state, name=f"arrival.states[{index}]")
        for index, state in enumerate(_ensure_sequence(raw["states"], name="arrival.states"))
    ]
    return {
        "sources": sources,
        "states": states,
        "initial": _parse_initial(raw["initial"], name="arrival.initial"),
        "outcomes": _parse_shared_outcomes(
            raw["outcomes"],
            source_ids=[str(source["id"]) for source in sources],
        ),
    }


__all__ = [
    "COUNT_ARRIVAL_FAMILIES",
    "SUPPORTED_ARRIVAL_FAMILIES",
    "SUPPORTED_INTERARRIVAL_KINDS",
    "MAX_ARRIVAL_COUNT",
    "parse_count_arrival_params",
]
