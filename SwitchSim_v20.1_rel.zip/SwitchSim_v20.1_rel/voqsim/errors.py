from __future__ import annotations

from typing import Any, Mapping


class SimError(Exception):
    """Base exception for the simulator.

    Parameters
    ----------
    message:
        Human-readable error description.
    context:
        Optional key/value metadata used to enrich the final error string.
    """

    def __init__(self, message: str, *, context: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = str(message)
        self.context = dict(context or {})

    def __str__(self) -> str:
        if not self.context:
            return self.message
        rendered = ", ".join(f"{key}={value!r}" for key, value in sorted(self.context.items()))
        return f"{self.message} [{rendered}]"


class ConfigError(SimError):
    """Raised when configuration loading or normalization fails."""


class ValidationError(SimError):
    """Raised when validated simulator inputs are invalid or inconsistent."""


class ScheduleError(SimError):
    """Raised when a scheduler emits an invalid or inconsistent matching."""


__all__ = [
    "SimError",
    "ConfigError",
    "ValidationError",
    "ScheduleError",
]
