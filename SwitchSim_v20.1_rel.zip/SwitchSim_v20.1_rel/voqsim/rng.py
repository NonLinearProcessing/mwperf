from __future__ import annotations

from enum import IntEnum
import secrets
from numbers import Integral

import numpy as np

from .errors import ValidationError

SEED_SCHEME_VERSION = 1
RNG_ENGINE_NAME = "numpy.random.Generator(PCG64)"
ARRIVAL_CATEGORICAL_SAMPLER = "exact_decimal_integer_v1"
MAX_SEED_VALUE = (1 << 64) - 1
_WORD_MASK = (1 << 32) - 1


class RNGDomain(IntEnum):
    """Top-level deterministic RNG domains derived from the master seed.

    Each domain is a deterministic substream path component under the single
    recorded master seed. New domains should be added rather than reusing an
    existing value for a different stochastic concern, so replayability remains
    stable as the simulator grows.
    """

    FLOW_PAIR = 1
    FLOW_PARAMETER = 2
    SCHEDULER = 3
    ARRIVAL_MODEL = 4
    ARRIVAL_INITIAL = 5
    ARRIVAL_COMPILE = 6


def _validate_int(value: int, *, name: str, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < minimum:
        raise ValidationError(
            f"{name} must be >= {minimum}",
            context={"value": coerced, "minimum": minimum},
        )
    return coerced



def _validate_seed_value(seed: int, *, allow_minus_one: bool = False, name: str = "seed") -> int:
    if isinstance(seed, bool) or not isinstance(seed, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": seed})
    seed = int(seed)
    if allow_minus_one and seed == -1:
        return seed
    if seed < 0:
        raise ValidationError(f"{name} must be non-negative", context={"value": seed})
    if seed > MAX_SEED_VALUE:
        raise ValidationError(
            f"{name} exceeds the supported 64-bit range",
            context={"value": seed, "maximum": MAX_SEED_VALUE},
        )
    return seed



def resolve_master_seed(config_seed: int) -> int:
    """Resolve the requested config seed into the concrete master seed for a run.

    ``config_seed == -1`` means "draw one random seed and record it".
    Any other supported non-negative integer is used directly.
    """

    requested = _validate_seed_value(config_seed, allow_minus_one=True, name="config_seed")
    if requested == -1:
        return secrets.randbits(64)
    return requested



def _component_to_entropy_words(value: int) -> list[int]:
    """Encode a non-negative integer into an unambiguous sequence of 32-bit words."""

    value = _validate_seed_value(value, name="seed_component")
    if value == 0:
        chunks = [0]
    else:
        chunks: list[int] = []
        remaining = value
        while remaining:
            chunks.append(remaining & _WORD_MASK)
            remaining >>= 32
    return [len(chunks), *chunks]



def derive_seed_material(actual_seed: int, *path: int) -> tuple[int, ...]:
    """Return deterministic SeedSequence entropy words for ``actual_seed`` and ``path``.

    The representation is versioned and unambiguous, so the same logical seed path
    always produces the same entropy words.
    """

    actual_seed = _validate_seed_value(actual_seed, name="actual_seed")
    entropy_words: list[int] = [SEED_SCHEME_VERSION]
    entropy_words.extend(_component_to_entropy_words(actual_seed))
    for index, component in enumerate(path):
        component = _validate_int(component, name=f"path[{index}]", minimum=0)
        entropy_words.extend(_component_to_entropy_words(component))
    return tuple(entropy_words)



def make_seed_sequence(actual_seed: int, *path: int) -> np.random.SeedSequence:
    """Build a deterministic NumPy ``SeedSequence`` for the given seed path."""

    return np.random.SeedSequence(derive_seed_material(actual_seed, *path))



def make_rng(actual_seed: int, *path: int) -> np.random.Generator:
    """Construct a deterministic RNG from the master seed and an integer path."""

    return np.random.Generator(np.random.PCG64(make_seed_sequence(actual_seed, *path)))



def build_planner_pair_rng(actual_seed: int) -> np.random.Generator:
    """RNG stream for deterministic flow source/destination assignment."""

    return make_rng(actual_seed, int(RNGDomain.FLOW_PAIR))



def build_planner_param_rng(actual_seed: int) -> np.random.Generator:
    """RNG stream for deterministic flow parameter sampling."""

    return make_rng(actual_seed, int(RNGDomain.FLOW_PARAMETER))



def build_arrival_rng_for_slot(actual_seed: int, slot: int) -> np.random.Generator:
    """RNG substream for one slot of the concrete arrival model.

    This is the primary arrival-side RNG helper from step 4.1 onward. It is
    stable under the single master-seed design and isolates slotwise arrival-law
    randomness from scheduler tie-breaking and any future compile-time draws.
    """

    slot = _validate_int(slot, name="slot", minimum=0)
    return make_rng(actual_seed, int(RNGDomain.ARRIVAL_MODEL), slot)



def build_arrival_initial_rng(actual_seed: int) -> np.random.Generator:
    """RNG substream for arrival-model initialization, such as Markov initial state draws."""

    return make_rng(actual_seed, int(RNGDomain.ARRIVAL_INITIAL))



def build_arrival_compile_rng(actual_seed: int) -> np.random.Generator:
    """RNG substream reserved for future randomized arrival-support compilation."""

    return make_rng(actual_seed, int(RNGDomain.ARRIVAL_COMPILE))



def build_scheduler_rng_for_slot(actual_seed: int, slot: int) -> np.random.Generator:
    """RNG stream for scheduler tie-breaking within one slot."""

    slot = _validate_int(slot, name="slot", minimum=0)
    return make_rng(actual_seed, int(RNGDomain.SCHEDULER), slot)


__all__ = [
    "SEED_SCHEME_VERSION",
    "RNG_ENGINE_NAME",
    "ARRIVAL_CATEGORICAL_SAMPLER",
    "MAX_SEED_VALUE",
    "RNGDomain",
    "resolve_master_seed",
    "derive_seed_material",
    "make_seed_sequence",
    "make_rng",
    "build_planner_pair_rng",
    "build_planner_param_rng",
    "build_arrival_rng_for_slot",
    "build_arrival_initial_rng",
    "build_arrival_compile_rng",
    "build_scheduler_rng_for_slot",
]
