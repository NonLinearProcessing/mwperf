"""Canonical queue-count arrival samples."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral
from typing import Any

from ..errors import ValidationError
from ..types import JSONValue, Slot
from .counts import ArrivalCountVector


def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": result})
    return result


@dataclass(slots=True, frozen=True)
class ArrivalSample:
    """One queue-count arrival vector sampled for a simulation slot."""

    slot: Slot
    offered_counts: ArrivalCountVector
    state_before: str | None = None
    state_after: str | None = None
    arrival_outcome_index: int | None = None
    arrival_outcome_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "slot",
            _validate_non_negative_int(self.slot, name="slot"),
        )
        if not isinstance(self.offered_counts, ArrivalCountVector):
            raise ValidationError(
                "offered_counts must be an ArrivalCountVector",
                context={"value_type": type(self.offered_counts).__name__},
            )
        if self.arrival_outcome_index is not None:
            object.__setattr__(
                self,
                "arrival_outcome_index",
                _validate_non_negative_int(
                    self.arrival_outcome_index,
                    name="arrival_outcome_index",
                ),
            )
        for field_name in ("state_before", "state_after", "arrival_outcome_id"):
            value = getattr(self, field_name)
            if value is not None and not isinstance(value, str):
                raise ValidationError(
                    f"{field_name} must be a string or null",
                    context={"value": value},
                )

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "slot": self.slot,
            "offered_counts": self.offered_counts.to_dict(),
            "state_before": self.state_before,
            "state_after": self.state_after,
            "arrival_outcome_index": self.arrival_outcome_index,
            "arrival_outcome_id": self.arrival_outcome_id,
        }


__all__ = ["ArrivalSample"]
