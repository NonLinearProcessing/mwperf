"""Queue-addressed count-valued arrival laws.

The models in this module share a small runtime contract: samples are
``ArrivalCountVector`` objects in ``QueueCatalog`` order, stochastic state is
advanced only by sequential ``sample`` calls, and ``reset`` performs no hidden
draws.  That last property makes replay depend only on the caller-supplied RNG
stream while slot-isolated streams keep scheduling and arrivals independent.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from bisect import bisect_right
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from fractions import Fraction
import heapq
import math
from numbers import Integral, Real
from typing import Any, Protocol, TypeAlias

import numpy as np

from ..errors import ValidationError
from ..queues import QueueCatalog
from ..types import JSONValue, QueueId
from .arrivals import ArrivalSample
from .counts import MAX_ARRIVAL_COUNT, ArrivalCountVector


def _decimal_number(
    value: Any,
    *,
    name: str,
    minimum: Decimal = Decimal(0),
    maximum: Decimal | None = None,
) -> Decimal:
    """Validate one finite decimal while preserving its exact value."""

    if isinstance(value, bool) or not isinstance(value, (Decimal, Integral, Real)):
        raise ValidationError(
            f"{name} must be a finite decimal number",
            context={"value": value, "value_type": type(value).__name__},
        )
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValidationError(
            f"{name} must be a finite decimal number", context={"value": value}
        ) from exc
    if not result.is_finite():
        raise ValidationError(f"{name} must be finite", context={"value": value})
    if result < minimum:
        raise ValidationError(
            f"{name} must be >= {minimum}",
            context={"value": result, "minimum": minimum},
        )
    if maximum is not None and result > maximum:
        raise ValidationError(
            f"{name} must be <= {maximum}",
            context={"value": result, "maximum": maximum},
        )
    return Decimal(0) if result == 0 else result


def _exact_probability(value: Any, *, name: str) -> Decimal:
    return _decimal_number(
        value,
        name=name,
        minimum=Decimal(0),
        maximum=Decimal(1),
    )


def _fraction_to_decimal(value: Fraction) -> Decimal:
    """Convert a terminating base-10 fraction into a Decimal exactly."""

    denominator = value.denominator
    twos = 0
    fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:  # pragma: no cover - inputs originate as Decimal
        raise ValidationError("exact decimal moment has a non-terminating expansion")
    decimal_places = max(twos, fives)
    scaled = (
        value.numerator
        * (2 ** (decimal_places - fives))
        * (5 ** (decimal_places - twos))
    )
    if scaled == 0:
        return Decimal(0)
    digits = tuple(int(character) for character in str(abs(scaled)))
    return Decimal((1 if scaled < 0 else 0, digits, -decimal_places))


def _sampler_float(value: Decimal | Fraction, *, name: str) -> float:
    """Convert exactly validated input at the RNG boundary or fail loudly."""

    try:
        result = float(value)
    except OverflowError as exc:
        raise OverflowError(f"{name} is outside the sampler's float range") from exc
    if not math.isfinite(result):
        raise OverflowError(f"{name} is outside the sampler's finite float range")
    if value != 0 and result == 0.0:
        raise OverflowError(f"{name} underflows the sampler's positive float range")
    return result


def _preflight_poisson_rates(values: np.ndarray, *, name: str) -> None:
    """Ask the active NumPy build to validate Poisson parameters, draw-free.

    NumPy reserves a platform- and implementation-dependent guard band below
    the signed-integer limit for Poisson samples.  A zero-sized request runs
    that validation without producing a variate or touching a caller's RNG.
    """

    try:
        np.random.default_rng(0).poisson(
            lam=values,
            size=(0, *values.shape),
        )
    except ValueError as exc:
        raise OverflowError(
            f"{name} contains a value outside NumPy's supported Poisson range"
        ) from exc


class _ExactDecimalCategorical:
    """Exact finite categorical sampler backed by integer masses.

    Ordinary decimal tables (up to 18 effective decimal places after reducing
    common factors) use one vectorized ``Generator.integers`` call.  Larger
    denominators use raw-bit rejection, which is unbiased for every Python
    integer total and never converts a positive mass to binary floating point.
    """

    __slots__ = (
        "probabilities",
        "positive_indices",
        "integer_weights",
        "integer_total",
        "_cumulative",
        "_cumulative_int64",
    )

    def __init__(self, probabilities: Sequence[Decimal], *, name: str) -> None:
        exact = tuple(
            _exact_probability(value, name=f"{name}[{index}]")
            for index, value in enumerate(probabilities)
        )
        if not exact:
            raise ValidationError(f"{name} must not be empty")
        fractions = tuple(Fraction(value) for value in exact)
        if sum(fractions, Fraction(0)) != 1:
            raise ValidationError(
                f"{name} must sum exactly to 1",
                context={"sum": sum(fractions, Fraction(0))},
            )

        common_denominator = 1
        for probability in fractions:
            common_denominator = math.lcm(
                common_denominator, probability.denominator
            )
        all_weights = tuple(
            probability.numerator
            * (common_denominator // probability.denominator)
            for probability in fractions
        )
        positive = tuple(
            (index, weight)
            for index, weight in enumerate(all_weights)
            if weight > 0
        )
        if not positive:  # pragma: no cover - exact total-one invariant
            raise ValidationError(f"{name} has no positive probability mass")
        common_factor = 0
        for _index, weight in positive:
            common_factor = math.gcd(common_factor, weight)
        indices = tuple(index for index, _weight in positive)
        weights = tuple(weight // common_factor for _index, weight in positive)
        cumulative: list[int] = []
        running = 0
        for weight in weights:
            running += weight
            cumulative.append(running)

        positive_indices = np.asarray(indices, dtype=np.intp)
        positive_indices.flags.writeable = False
        cumulative_int64: np.ndarray | None = None
        if running <= int(np.iinfo(np.int64).max):
            cumulative_int64 = np.asarray(cumulative, dtype=np.int64)
            cumulative_int64.flags.writeable = False

        self.probabilities = exact
        self.positive_indices = positive_indices
        self.integer_weights = weights
        self.integer_total = running
        self._cumulative = tuple(cumulative)
        self._cumulative_int64 = cumulative_int64

    def _draw_arbitrary_tickets(
        self,
        rng: np.random.Generator,
        size: int,
    ) -> tuple[int, ...]:
        if size == 0:
            return ()
        total = self.integer_total
        if total == 1:
            return (0,) * size
        bit_count = (total - 1).bit_length()
        # NumPy bit generators do not all expose the same raw width:
        # MT19937 returns 32 random bits in a uint64 container, while PCG64,
        # Philox, and SFC64 return 64.  Low 32-bit chunks are uniform for all
        # supported generators, so using them keeps this fallback universal.
        chunk_bits = 32
        word_count = (bit_count + chunk_bits - 1) // chunk_bits
        mask = (1 << bit_count) - 1
        tickets: list[int] = []
        # Each rejection round is one vectorized raw-word request.  Since the
        # candidate width is minimal, acceptance probability is at least 1/2.
        while len(tickets) < size:
            remaining = size - len(tickets)
            raw = np.asarray(
                rng.bit_generator.random_raw(remaining * word_count),
                dtype=np.uint64,
            ).reshape((remaining, word_count))
            for row in raw:
                candidate = 0
                for word_index, word in enumerate(row):
                    candidate |= (int(word) & 0xFFFFFFFF) << (
                        chunk_bits * word_index
                    )
                candidate &= mask
                if candidate < total:
                    tickets.append(candidate)
        return tuple(tickets)

    def sample_indices(
        self,
        rng: np.random.Generator,
        *,
        size: int | None = None,
    ) -> int | np.ndarray:
        generator = _rng(rng)
        scalar = size is None
        resolved_size = 1 if scalar else _integer(size, name="size", minimum=0)
        if self._cumulative_int64 is not None:
            tickets = generator.integers(
                0,
                self.integer_total,
                size=resolved_size,
                dtype=np.int64,
            )
            positions = np.searchsorted(
                self._cumulative_int64, tickets, side="right"
            )
            selected = self.positive_indices[positions]
        else:
            tickets = self._draw_arbitrary_tickets(generator, resolved_size)
            selected = np.fromiter(
                (
                    int(self.positive_indices[bisect_right(self._cumulative, ticket)])
                    for ticket in tickets
                ),
                dtype=np.intp,
                count=resolved_size,
            )
        if scalar:
            return int(selected[0])
        return selected


def _exact_probabilities(
    raw: Sequence[Any],
    *,
    name: str,
) -> tuple[tuple[Decimal, ...], _ExactDecimalCategorical]:
    if not raw:
        raise ValidationError(f"{name} must not be empty")
    exact = tuple(
        _exact_probability(value, name=f"{name}[{index}]")
        for index, value in enumerate(raw)
    )
    return exact, _ExactDecimalCategorical(exact, name=name)


def _mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationError(f"{name} must be a mapping", context={"value_type": type(value).__name__})
    return value


def _sequence(value: Any, *, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(f"{name} must be a sequence", context={"value_type": type(value).__name__})
    return value


def _nonempty_sequence(value: Any, *, name: str) -> Sequence[Any]:
    sequence = _sequence(value, name=name)
    if not sequence:
        raise ValidationError(f"{name} must not be empty")
    return sequence


def _keys(
    value: Mapping[str, Any],
    *,
    name: str,
    required: set[str],
    optional: set[str] | None = None,
) -> None:
    optional = set() if optional is None else optional
    missing = sorted(required - set(value))
    if missing:
        raise ValidationError(f"{name} is missing required keys", context={"missing_keys": missing})
    extras = sorted(set(value) - required - optional)
    if extras:
        raise ValidationError(f"{name} contains unknown keys", context={"unknown_keys": extras})


def _integer(value: Any, *, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < minimum:
        raise ValidationError(f"{name} must be >= {minimum}", context={"value": result})
    return result


def _positive_count(value: Any, *, name: str) -> int:
    result = _integer(value, name=name, minimum=1)
    if result > MAX_ARRIVAL_COUNT:
        raise ValidationError(
            f"{name} exceeds the supported arrival-count range",
            context={"value": result, "maximum": MAX_ARRIVAL_COUNT},
        )
    return result


def _identifier(value: Any, *, name: str) -> str:
    if not isinstance(value, str) or not value or value.strip() != value:
        raise ValidationError(f"{name} must be a nonempty string without surrounding whitespace")
    return value


def _rng(value: Any) -> np.random.Generator:
    if not isinstance(value, np.random.Generator):
        raise ValidationError("rng must be a numpy.random.Generator", context={"value_type": type(value).__name__})
    return value


def _slot(value: Any) -> int:
    return _integer(value, name="slot", minimum=0)


def _canonical_queue(catalog: QueueCatalog, value: Any, *, name: str) -> tuple[int, QueueId]:
    try:
        index = catalog.index_of(value)
    except ValidationError as exc:
        raise ValidationError(f"{name} references a queue outside the catalog", context={"queue_id": value}) from exc
    return index, catalog.queue_id_at(index)


def _add_count(target: dict[int, int], index: int, count: int) -> None:
    updated = target.get(index, 0) + count
    if updated > MAX_ARRIVAL_COUNT:
        raise ValidationError(
            "Aggregated arrival count exceeds the supported range",
            context={"queue_index": index, "value": updated, "maximum": MAX_ARRIVAL_COUNT},
        )
    target[index] = updated


class _CountArrivalBase:
    family: str

    def __init__(self, catalog: QueueCatalog) -> None:
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError("catalog must be a QueueCatalog")
        self.catalog = catalog
        self._zero = ArrivalCountVector.zero(catalog)
        self._live_indices: tuple[int, ...] = ()

    def _set_live_indices(self, indices: set[int]) -> None:
        self._live_indices = tuple(index for index in range(self.catalog.n_queues) if index in indices)

    def live_queue_ids(self) -> tuple[QueueId, ...]:
        return tuple(self.catalog.queue_id_at(index) for index in self._live_indices)

    def _count_vector(self, counts: Mapping[int, int]) -> ArrivalCountVector:
        if not counts:
            return self._zero
        values = np.zeros(self.catalog.n_queues, dtype=np.int64)
        for index, count in counts.items():
            values[index] = count
        return ArrivalCountVector(values)

    def _count_vector_from_live(self, counts: Any) -> ArrivalCountVector:
        return self._count_vector_from_indices(self._live_indices, counts)

    def _count_vector_from_indices(
        self,
        indices: Sequence[int],
        counts: Any,
    ) -> ArrivalCountVector:
        values = np.zeros(self.catalog.n_queues, dtype=np.int64)
        sampled = np.asarray(counts)
        if sampled.shape != (len(indices),):
            raise ValidationError(
                "sampled arrival vector has an unexpected shape",
                context={
                    "shape": tuple(int(item) for item in sampled.shape),
                    "expected_shape": (len(indices),),
                },
            )
        if sampled.dtype.kind not in {"i", "u"} or sampled.dtype.kind == "b":
            raise ValidationError(
                "sampled arrival counts must be integers",
                context={"dtype": str(sampled.dtype)},
            )
        if np.any(sampled < 0):
            raise ValidationError("sampled arrival counts must be nonnegative")
        if sampled.dtype.kind == "u" and np.any(sampled > MAX_ARRIVAL_COUNT):
            raise ValidationError(
                "sampled arrival count exceeds the int64 limit",
                context={"maximum": MAX_ARRIVAL_COUNT},
            )
        # The checked assignment is exact.  No clipping or saturation is
        # permitted at this boundary.
        values[np.asarray(indices, dtype=np.intp)] = sampled
        return ArrivalCountVector(values)

    def reset(self, rng: np.random.Generator | None = None) -> None:
        if rng is not None:
            _rng(rng)


class _SequentialCountArrivalBase(_CountArrivalBase):
    def __init__(self, catalog: QueueCatalog) -> None:
        super().__init__(catalog)
        self._expected_slot = 0

    def _begin_slot(self, slot: Any, rng: Any) -> tuple[int, np.random.Generator]:
        resolved = _slot(slot)
        generator = _rng(rng)
        if resolved != self._expected_slot:
            raise ValidationError(
                "stateful count-valued arrival models require sequential slots beginning at zero",
                context={"expected_slot": self._expected_slot, "slot": resolved},
            )
        return resolved, generator

    def _finish_slot(self) -> None:
        self._expected_slot += 1

    def reset(self, rng: np.random.Generator | None = None) -> None:
        super().reset(rng)
        self._expected_slot = 0


@dataclass(slots=True, frozen=True)
class _Categorical:
    values: tuple[Any, ...]
    probabilities: tuple[Decimal, ...]
    _sampler: _ExactDecimalCategorical = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if len(self.values) != len(self.probabilities):
            raise ValidationError(
                "categorical values and probabilities must have equal length"
            )
        object.__setattr__(
            self,
            "_sampler",
            _ExactDecimalCategorical(
                self.probabilities,
                name="categorical probabilities",
            ),
        )

    def sample(self, rng: np.random.Generator) -> Any:
        return self.values[int(self._sampler.sample_indices(rng))]


def _initial_distribution(
    raw: Any,
    *,
    states: tuple[str, ...],
    state_to_index: Mapping[str, int],
    name: str,
) -> tuple[int | None, _Categorical | None, dict[str, JSONValue]]:
    mapping = _mapping(raw, name=name)
    if set(mapping) == {"state"}:
        state = _identifier(mapping["state"], name=f"{name}.state")
        if state not in state_to_index:
            raise ValidationError(f"{name}.state is unknown", context={"state": state})
        return state_to_index[state], None, {"state": state}
    if set(mapping) != {"distribution"}:
        raise ValidationError(f"{name} must contain exactly one of state or distribution")
    distribution = _mapping(mapping["distribution"], name=f"{name}.distribution")
    extras = sorted(set(distribution) - set(states))
    missing = sorted(set(states) - set(distribution))
    if extras or missing:
        raise ValidationError(
            f"{name}.distribution keys must exactly match states",
            context={"unknown_states": extras, "missing_states": missing},
        )
    probabilities = tuple(
        _exact_probability(
            distribution[state], name=f"{name}.distribution[{state!r}]"
        )
        for state in states
    )
    categorical = _Categorical(tuple(range(len(states))), probabilities)
    payload = {"distribution": {state: probabilities[index] for index, state in enumerate(states)}}
    return None, categorical, payload


def _states(raw: Any, *, name: str) -> tuple[tuple[str, ...], dict[str, int]]:
    sequence = _sequence(raw, name=name)
    if not sequence:
        raise ValidationError(f"{name} must not be empty")
    result: list[str] = []
    mapping: dict[str, int] = {}
    for position, value in enumerate(sequence):
        state = _identifier(value, name=f"{name}[{position}]")
        if state in mapping:
            raise ValidationError(f"{name} contains duplicate states", context={"state": state})
        mapping[state] = len(result)
        result.append(state)
    return tuple(result), mapping


def _rate_spec(
    catalog: QueueCatalog,
    raw: Any,
    *,
    name: str,
    maximum: Decimal | None,
) -> tuple[tuple[Decimal, ...], dict[str, Any], tuple[int, ...]]:
    rates = _mapping(raw, name=name)
    _keys(rates, name=name, required={"default", "overrides"})
    default = _decimal_number(
        rates["default"], name=f"{name}.default", maximum=maximum
    )
    resolved = [default] * catalog.n_queues
    seen_indices: dict[int, int] = {}
    override_payload: list[dict[str, Any]] = []
    explicit_indices: list[int] = []
    for position, raw_override in enumerate(
        _sequence(rates["overrides"], name=f"{name}.overrides")
    ):
        row_name = f"{name}.overrides[{position}]"
        override = _mapping(raw_override, name=row_name)
        _keys(override, name=row_name, required={"queue_id", "rate"})
        queue_index, queue_id = _canonical_queue(
            catalog, override["queue_id"], name=f"{row_name}.queue_id"
        )
        if queue_index in seen_indices:
            raise ValidationError(
                f"{name}.overrides contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_position": seen_indices[queue_index],
                    "duplicate_position": position,
                },
            )
        seen_indices[queue_index] = position
        rate = _decimal_number(
            override["rate"], name=f"{row_name}.rate", maximum=maximum
        )
        resolved[queue_index] = rate
        explicit_indices.append(queue_index)
        override_payload.append({"queue_id": queue_id, "rate": rate})
    payload = {
        "default": default,
        "overrides": override_payload,
    }
    return tuple(resolved), payload, tuple(explicit_indices)


def _sparse_count_vector(
    catalog: QueueCatalog,
    raw: Any,
    *,
    name: str,
) -> tuple[ArrivalCountVector, tuple[dict[str, Any], ...]]:
    values = np.zeros(catalog.n_queues, dtype=np.int64)
    seen: dict[int, int] = {}
    payload_by_index: dict[int, dict[str, Any]] = {}
    for position, raw_count in enumerate(_sequence(raw, name=name)):
        row_name = f"{name}[{position}]"
        row = _mapping(raw_count, name=row_name)
        _keys(row, name=row_name, required={"queue_id", "count"})
        queue_index, queue_id = _canonical_queue(
            catalog, row["queue_id"], name=f"{row_name}.queue_id"
        )
        if queue_index in seen:
            raise ValidationError(
                f"{name} contains a duplicate queue_id",
                context={
                    "queue_id": queue_id,
                    "first_position": seen[queue_index],
                    "duplicate_position": position,
                },
            )
        seen[queue_index] = position
        count = _positive_count(row["count"], name=f"{row_name}.count")
        values[queue_index] = count
        payload_by_index[queue_index] = {"queue_id": queue_id, "count": count}
    return (
        ArrivalCountVector(values),
        tuple(payload_by_index[index] for index in sorted(payload_by_index)),
    )


@dataclass(slots=True, frozen=True)
class CountOutcome:
    """One named queue-count vector used by a finite arrival law."""

    outcome_id: str
    counts: ArrivalCountVector
    probability: Decimal | None = None
    sparse_counts: tuple[dict[str, Any], ...] = ()

    @property
    def id(self) -> str:
        return self.outcome_id

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.outcome_id,
            "counts": [dict(row) for row in self.sparse_counts],
        }
        if self.probability is not None:
            payload["probability"] = self.probability
        return payload


def _count_outcomes(
    catalog: QueueCatalog,
    raw: Any,
    *,
    probabilities: bool,
    name: str,
) -> tuple[CountOutcome, ...]:
    raw_outcomes = _nonempty_sequence(raw, name=name)
    outcomes: list[CountOutcome] = []
    seen_ids: dict[str, int] = {}
    seen_vectors: dict[tuple[int, ...], int] = {}
    for position, raw_outcome in enumerate(raw_outcomes):
        row_name = f"{name}[{position}]"
        outcome = _mapping(raw_outcome, name=row_name)
        required = {"id", "counts"}
        if probabilities:
            required.add("probability")
        _keys(outcome, name=row_name, required=required)
        outcome_id = _identifier(outcome["id"], name=f"{row_name}.id")
        if outcome_id in seen_ids:
            raise ValidationError(
                f"{name} contains duplicate ids",
                context={"id": outcome_id, "first_position": seen_ids[outcome_id]},
            )
        counts, sparse_counts = _sparse_count_vector(
            catalog, outcome["counts"], name=f"{row_name}.counts"
        )
        coordinate = tuple(counts)
        if coordinate in seen_vectors:
            raise ValidationError(
                f"{name} contains duplicate count vectors",
                context={
                    "first_position": seen_vectors[coordinate],
                    "duplicate_position": position,
                },
            )
        seen_ids[outcome_id] = position
        seen_vectors[coordinate] = position
        probability = (
            _exact_probability(
                outcome["probability"], name=f"{row_name}.probability"
            )
            if probabilities
            else None
        )
        outcomes.append(
            CountOutcome(outcome_id, counts, probability, sparse_counts)
        )
    return tuple(outcomes)


class IIDCountTableArrival(_CountArrivalBase):
    """IID categorical table of named sparse queue-count vectors."""

    family = "iid_count_table"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"outcomes"})
        self.outcomes = _count_outcomes(
            catalog,
            params["outcomes"],
            probabilities=True,
            name="params.outcomes",
        )
        exact, sampler = _exact_probabilities(
            tuple(outcome.probability for outcome in self.outcomes),
            name="params.outcomes probabilities",
        )
        # The outcome records already carry the same exact Decimal objects;
        # retain the tuple as a convenient certified-law interface.
        self.probabilities = exact
        self._outcome_sampler = sampler
        live: set[int] = set()
        for outcome in self.outcomes:
            assert outcome.probability is not None
            if outcome.probability > 0:
                live.update(outcome.counts.nonzero_indices())
        self._set_live_indices(live)

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        generator = _rng(rng)
        outcome_index = int(self._outcome_sampler.sample_indices(generator))
        outcome = self.outcomes[outcome_index]
        return ArrivalSample(
            slot=resolved,
            offered_counts=outcome.counts,
            arrival_outcome_index=outcome_index,
            arrival_outcome_id=outcome.outcome_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "family": self.family,
            "outcomes": [outcome.to_dict() for outcome in self.outcomes],
            "live_queue_ids": list(self.live_queue_ids()),
        }


@dataclass(slots=True, frozen=True)
class MarkovCountKernelRow:
    state: str
    outcome_id: str
    next_state: str
    probability: Decimal

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "outcome_id": self.outcome_id,
            "next_state": self.next_state,
            "probability": self.probability,
        }


class MarkovCountKernelArrival(_SequentialCountArrivalBase):
    """Finite-state Markov kernel with reusable queue-count emissions."""

    family = "markov_count_kernel"

    def __init__(
        self,
        catalog: QueueCatalog,
        params: Mapping[str, Any],
        *,
        initial_rng: np.random.Generator | None = None,
    ) -> None:
        super().__init__(catalog)
        if initial_rng is not None:
            _rng(initial_rng)
        params = _mapping(params, name="params")
        _keys(
            params,
            name="params",
            required={"states", "outcomes", "kernel", "initial"},
        )
        self.states, state_to_index = _states(params["states"], name="params.states")
        self.outcomes = _count_outcomes(
            catalog,
            params["outcomes"],
            probabilities=False,
            name="params.outcomes",
        )
        outcome_to_index = {
            outcome.outcome_id: index for index, outcome in enumerate(self.outcomes)
        }
        width = len(self.outcomes) * len(self.states)
        exact_kernel = [
            [Decimal(0) for _ in range(width)] for _ in range(len(self.states))
        ]
        rows: list[MarkovCountKernelRow] = []
        seen_coordinates: set[tuple[int, int, int]] = set()
        for position, raw_row in enumerate(
            _sequence(params["kernel"], name="params.kernel")
        ):
            row_name = f"params.kernel[{position}]"
            row = _mapping(raw_row, name=row_name)
            _keys(
                row,
                name=row_name,
                required={"state", "outcome_id", "next_state", "probability"},
            )
            state = _identifier(row["state"], name=f"{row_name}.state")
            outcome_id = _identifier(
                row["outcome_id"], name=f"{row_name}.outcome_id"
            )
            next_state = _identifier(
                row["next_state"], name=f"{row_name}.next_state"
            )
            if state not in state_to_index or next_state not in state_to_index:
                raise ValidationError(
                    f"{row_name} references an unknown state",
                    context={"state": state, "next_state": next_state},
                )
            if outcome_id not in outcome_to_index:
                raise ValidationError(
                    f"{row_name} references an unknown outcome",
                    context={"outcome_id": outcome_id},
                )
            state_index = state_to_index[state]
            outcome_index = outcome_to_index[outcome_id]
            next_state_index = state_to_index[next_state]
            coordinate = (state_index, outcome_index, next_state_index)
            if coordinate in seen_coordinates:
                raise ValidationError(
                    "params.kernel contains a duplicate transition coordinate",
                    context={
                        "state": state,
                        "outcome_id": outcome_id,
                        "next_state": next_state,
                    },
                )
            seen_coordinates.add(coordinate)
            probability = _exact_probability(
                row["probability"], name=f"{row_name}.probability"
            )
            exact_kernel[state_index][
                outcome_index * len(self.states) + next_state_index
            ] = probability
            rows.append(
                MarkovCountKernelRow(
                    state, outcome_id, next_state, probability
                )
            )

        sampler_rows: list[_ExactDecimalCategorical] = []
        for state_index, state in enumerate(self.states):
            total = sum(
                (Fraction(value) for value in exact_kernel[state_index]),
                Fraction(0),
            )
            if total != 1:
                raise ValidationError(
                    "params.kernel outgoing probabilities must sum exactly to 1",
                    context={"state": state, "sum": total},
                )
            sampler_rows.append(
                _ExactDecimalCategorical(
                    tuple(exact_kernel[state_index]),
                    name=f"params.kernel probabilities for state {state!r}",
                )
            )
        self.kernel = tuple(rows)
        self._exact_kernel = tuple(tuple(row) for row in exact_kernel)
        self._sampler_kernel = tuple(sampler_rows)

        initial = _mapping(params["initial"], name="params.initial")
        if set(initial) == {"state"}:
            initial_state = _identifier(
                initial["state"], name="params.initial.state"
            )
            if initial_state not in state_to_index:
                raise ValidationError(
                    "params.initial.state is unknown",
                    context={"state": initial_state},
                )
            self.initial = {"state": initial_state}
            self._resolved_initial_state_index = state_to_index[initial_state]
        elif set(initial) == {"distribution"}:
            distribution = _mapping(
                initial["distribution"], name="params.initial.distribution"
            )
            extras = sorted(set(distribution) - set(self.states))
            missing = sorted(set(self.states) - set(distribution))
            if extras or missing:
                raise ValidationError(
                    "params.initial.distribution keys must exactly match states",
                    context={"unknown_states": extras, "missing_states": missing},
                )
            exact_initial, initial_sampler = _exact_probabilities(
                tuple(distribution[state] for state in self.states),
                name="params.initial.distribution",
            )
            self.initial = {
                "distribution": {
                    state: exact_initial[index]
                    for index, state in enumerate(self.states)
                }
            }
            if initial_rng is None:
                raise ValidationError(
                    "markov_count_kernel with a distributed initial state requires initial_rng"
                )
            generator = initial_rng
            assert generator is not None
            self._resolved_initial_state_index = int(
                initial_sampler.sample_indices(generator)
            )
        else:
            raise ValidationError(
                "params.initial must contain exactly one of state or distribution"
            )
        self.resolved_initial_state = self.states[self._resolved_initial_state_index]

        live: set[int] = set()
        for state_index, row in enumerate(self._exact_kernel):
            for flat_index, probability in enumerate(row):
                if probability > 0:
                    outcome_index, _next_state_index = divmod(
                        flat_index, len(self.states)
                    )
                    live.update(self.outcomes[outcome_index].counts.nonzero_indices())
        self._set_live_indices(live)
        self._current_state_index = self._resolved_initial_state_index

    @property
    def current_state(self) -> str:
        return self.states[self._current_state_index]

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved, generator = self._begin_slot(slot, rng)
        state_before_index = self._current_state_index
        transition_index = int(
            self._sampler_kernel[state_before_index].sample_indices(generator)
        )
        outcome_index, next_state_index = divmod(
            transition_index, len(self.states)
        )
        outcome = self.outcomes[outcome_index]
        result = ArrivalSample(
            slot=resolved,
            offered_counts=outcome.counts,
            arrival_outcome_index=outcome_index,
            arrival_outcome_id=outcome.outcome_id,
            state_before=self.states[state_before_index],
            state_after=self.states[next_state_index],
        )
        self._current_state_index = next_state_index
        self._finish_slot()
        return result

    def reset(self, rng: np.random.Generator | None = None) -> None:
        # The distributed initial state is resolved once from ARRIVAL_INITIAL
        # during construction.  Reset only restores it and consumes no draws.
        super().reset(rng)
        self._current_state_index = self._resolved_initial_state_index

    def to_dict(self) -> dict[str, Any]:
        return {
            "family": self.family,
            "states": list(self.states),
            "outcomes": [outcome.to_dict() for outcome in self.outcomes],
            "kernel": [row.to_dict() for row in self.kernel],
            "initial": dict(self.initial),
            "resolved_initial_state": self.resolved_initial_state,
            "live_queue_ids": list(self.live_queue_ids()),
        }


class _IIDRateArrivalBase(_CountArrivalBase):
    _maximum_rate: Decimal | None = None

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"rates"})
        self.rates, self._rates_payload, self._explicit_rate_indices = _rate_spec(
            catalog,
            params["rates"],
            name="params.rates",
            maximum=self._maximum_rate,
        )
        self._set_live_indices(
            {index for index, rate in enumerate(self.rates) if rate > 0}
        )

    def rate_for_queue(self, queue_id: QueueId) -> Decimal:
        return self.rates[self.catalog.index_of(queue_id)]

    def _live_rate_array(self) -> np.ndarray:
        # This is the sole Decimal-to-binary-float boundary for base rates.
        return np.asarray(
            [
                _sampler_float(
                    self.rates[index], name=f"rates[{index}]"
                )
                for index in self._live_indices
            ],
            dtype=float,
        )

    def _base_dict(self) -> dict[str, Any]:
        return {
            "family": self.family,
            "rates": {
                "default": self._rates_payload["default"],
                "overrides": [
                    dict(row) for row in self._rates_payload["overrides"]
                ],
            },
            "live_queue_ids": list(self.live_queue_ids()),
        }


class IIDIndependentBernoulliArrival(_IIDRateArrivalBase):
    family = "iid_independent_bernoulli"
    _maximum_rate = Decimal(1)

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog, params)
        default = self._rates_payload["default"]
        self._sample_indices = (
            tuple(range(self.catalog.n_queues))
            if default > 0
            else self._explicit_rate_indices
        )
        probabilities = np.asarray(
            [
                _sampler_float(
                    self.rates[index], name=f"rates[{index}]"
                )
                for index in self._sample_indices
            ],
            dtype=float,
        )
        probabilities.flags.writeable = False
        self._sampler_probabilities = probabilities

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        generator = _rng(rng)
        # Keep the legacy factorized-Bernoulli primitive for migrated replay:
        # one vectorized uniform draw, including explicitly retained zero-rate
        # coordinates, followed by an elementwise threshold.
        draws = (
            generator.random(size=len(self._sample_indices))
            < self._sampler_probabilities
        ).astype(
            np.int64,
            copy=False,
        )
        return ArrivalSample(
            slot=resolved,
            offered_counts=self._count_vector_from_indices(
                self._sample_indices, draws
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return self._base_dict()


class IIDIndependentPoissonArrival(_IIDRateArrivalBase):
    family = "iid_independent_poisson"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog, params)
        sampler_rates = self._live_rate_array()
        _preflight_poisson_rates(
            sampler_rates,
            name="independent Poisson rates",
        )
        sampler_rates.flags.writeable = False
        self._sampler_rates = sampler_rates

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        generator = _rng(rng)
        draws = generator.poisson(lam=self._sampler_rates)
        return ArrivalSample(
            slot=resolved, offered_counts=self._count_vector_from_live(draws)
        )

    def to_dict(self) -> dict[str, Any]:
        return self._base_dict()


@dataclass(slots=True, frozen=True)
class ModulationState:
    state_id: str
    probability: Decimal
    multiplier: Decimal

    @property
    def id(self) -> str:
        return self.state_id

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.state_id,
            "probability": self.probability,
            "multiplier": self.multiplier,
        }


class IIDMixedPoissonArrival(_IIDRateArrivalBase):
    family = "iid_mixed_poisson"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        # Validate the complete shape before delegating the common rate parser.
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"rates", "modulation"})
        super().__init__(catalog, {"rates": params["rates"]})
        modulation = _mapping(params["modulation"], name="params.modulation")
        _keys(
            modulation,
            name="params.modulation",
            required={"scope", "states"},
            optional={"mean_multiplier", "second_moment_multiplier"},
        )
        scope = _identifier(modulation["scope"], name="params.modulation.scope")
        if scope not in {"independent_queue", "shared"}:
            raise ValidationError(
                "params.modulation.scope must be 'independent_queue' or 'shared'",
                context={"scope": scope},
            )
        self.scope = scope
        states: list[ModulationState] = []
        seen_ids: set[str] = set()
        for position, raw_state in enumerate(
            _nonempty_sequence(
                modulation["states"], name="params.modulation.states"
            )
        ):
            row_name = f"params.modulation.states[{position}]"
            state = _mapping(raw_state, name=row_name)
            _keys(
                state,
                name=row_name,
                required={"id", "probability", "multiplier"},
            )
            state_id = _identifier(state["id"], name=f"{row_name}.id")
            if state_id in seen_ids:
                raise ValidationError(
                    "params.modulation.states contains duplicate ids",
                    context={"id": state_id},
                )
            seen_ids.add(state_id)
            states.append(
                ModulationState(
                    state_id,
                    _exact_probability(
                        state["probability"], name=f"{row_name}.probability"
                    ),
                    _decimal_number(
                        state["multiplier"], name=f"{row_name}.multiplier"
                    ),
                )
            )
        exact_probabilities, modulation_sampler = _exact_probabilities(
            tuple(state.probability for state in states),
            name="params.modulation.states probabilities",
        )
        del exact_probabilities
        exact_mean = sum(
            (
                Fraction(state.probability) * Fraction(state.multiplier)
                for state in states
            ),
            Fraction(0),
        )
        if exact_mean != 1:
            raise ValidationError(
                "params.modulation must satisfy E[M] == 1 exactly",
                context={"mean": str(exact_mean)},
            )
        exact_second_moment = sum(
            (
                Fraction(state.probability)
                * Fraction(state.multiplier)
                * Fraction(state.multiplier)
                for state in states
            ),
            Fraction(0),
        )
        self.modulation_states = tuple(states)
        self._modulation_sampler = modulation_sampler
        self.modulation_mean = _fraction_to_decimal(exact_mean)
        self.modulation_second_moment = _fraction_to_decimal(exact_second_moment)
        self.modulation_variance = _fraction_to_decimal(
            exact_second_moment - exact_mean * exact_mean
        )
        expected_derived = {
            "mean_multiplier": self.modulation_mean,
            "second_moment_multiplier": self.modulation_second_moment,
        }
        for field_name, expected in expected_derived.items():
            if field_name not in modulation:
                continue
            supplied = _decimal_number(
                modulation[field_name], name=f"params.modulation.{field_name}"
            )
            if supplied != expected:
                raise ValidationError(
                    f"params.modulation.{field_name} does not match the states",
                    context={"supplied": supplied, "expected": expected},
                )

        # Decimal multiplication and sampler-boundary conversion happen once,
        # before the first slot.  Sampling below is therefore only one exact
        # categorical state draw followed by one vectorized Poisson draw.
        conditional_rates = np.empty(
            (len(self.modulation_states), len(self._live_indices)),
            dtype=float,
        )
        for state_index, state in enumerate(self.modulation_states):
            for live_position, queue_index in enumerate(self._live_indices):
                theta = Fraction(self.rates[queue_index]) * Fraction(
                    state.multiplier
                )
                conditional_rates[state_index, live_position] = (
                    0.0
                    if theta == 0
                    else _sampler_float(
                        theta,
                        name=(
                            "conditional Poisson rate for modulation state "
                            f"{state.state_id!r}, queue "
                            f"{self.catalog.queue_id_at(queue_index)!r}"
                        ),
                    )
                )
        _preflight_poisson_rates(
            conditional_rates,
            name="mixed-Poisson conditional rates",
        )
        conditional_rates.flags.writeable = False
        self._conditional_rate_matrix = conditional_rates
        live_positions = np.arange(len(self._live_indices), dtype=np.intp)
        live_positions.flags.writeable = False
        self._live_positions = live_positions

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        generator = _rng(rng)
        if self.scope == "shared":
            state_indices: np.ndarray | int = int(
                self._modulation_sampler.sample_indices(generator)
            )
            conditional_rates = self._conditional_rate_matrix[state_indices]
        else:
            state_indices = self._modulation_sampler.sample_indices(
                generator,
                size=len(self._live_indices),
            )
            conditional_rates = self._conditional_rate_matrix[
                state_indices, self._live_positions
            ]
        draws = generator.poisson(lam=conditional_rates)
        return ArrivalSample(
            slot=resolved, offered_counts=self._count_vector_from_live(draws)
        )

    def to_dict(self) -> dict[str, Any]:
        payload = self._base_dict()
        payload["modulation"] = {
            "scope": self.scope,
            "states": [state.to_dict() for state in self.modulation_states],
            "mean_multiplier": self.modulation_mean,
            "second_moment_multiplier": self.modulation_second_moment,
        }
        return payload


class DeterministicTraceArrival(_CountArrivalBase):
    family = "deterministic_trace"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"events"})
        aggregated: dict[tuple[int, int], int] = {}
        for position, raw in enumerate(_sequence(params["events"], name="params.events")):
            event = _mapping(raw, name=f"params.events[{position}]")
            _keys(event, name=f"params.events[{position}]", required={"slot", "queue_id", "count"})
            event_slot = _integer(event["slot"], name=f"params.events[{position}].slot")
            queue_index, _ = _canonical_queue(catalog, event["queue_id"], name=f"params.events[{position}].queue_id")
            count = _positive_count(event["count"], name=f"params.events[{position}].count")
            key = (event_slot, queue_index)
            updated = aggregated.get(key, 0) + count
            if updated > MAX_ARRIVAL_COUNT:
                raise ValidationError("Aggregated deterministic trace count exceeds the supported range")
            aggregated[key] = updated

        by_slot: dict[int, dict[int, int]] = {}
        for (event_slot, queue_index), count in sorted(aggregated.items()):
            by_slot.setdefault(event_slot, {})[queue_index] = count
        self._by_slot = {event_slot: self._count_vector(counts) for event_slot, counts in by_slot.items()}
        self._events = tuple(
            {
                "slot": event_slot,
                "queue_id": catalog.queue_id_at(queue_index),
                "count": count,
            }
            for (event_slot, queue_index), count in sorted(aggregated.items())
        )
        self._set_live_indices({queue_index for _event_slot, queue_index in aggregated})

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        _rng(rng)
        return ArrivalSample(slot=resolved, offered_counts=self._by_slot.get(resolved, self._zero))

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.family,
            "events": [dict(event) for event in self._events],
            "live_queue_ids": list(self.live_queue_ids()),
        }


@dataclass(slots=True, frozen=True)
class _PeriodicSource:
    source_id: str
    delay: int
    entries: tuple[dict[str, JSONValue], ...]
    buckets: dict[int, tuple[tuple[int, int], ...]]


def _periodic_sources(
    catalog: QueueCatalog,
    raw_sources: Any,
    *,
    period: int,
    delayed: bool,
) -> tuple[_PeriodicSource, ...]:
    sources: list[_PeriodicSource] = []
    seen_ids: set[str] = set()
    required = {"id", "entries", "delay"} if delayed else {"id", "entries"}
    for source_position, raw_source in enumerate(_sequence(raw_sources, name="params.sources")):
        source = _mapping(raw_source, name=f"params.sources[{source_position}]")
        _keys(source, name=f"params.sources[{source_position}]", required=required)
        source_id = _identifier(source["id"], name=f"params.sources[{source_position}].id")
        if source_id in seen_ids:
            raise ValidationError("params.sources contains duplicate ids", context={"id": source_id})
        seen_ids.add(source_id)
        delay = _integer(source.get("delay", 0), name=f"params.sources[{source_position}].delay")
        aggregated: dict[tuple[int, int], int] = {}
        for entry_position, raw_entry in enumerate(_sequence(source["entries"], name=f"params.sources[{source_position}].entries")):
            entry = _mapping(raw_entry, name=f"params.sources[{source_position}].entries[{entry_position}]")
            _keys(entry, name="periodic entry", required={"offset", "queue_id", "count"})
            offset = _integer(entry["offset"], name="periodic entry offset")
            if offset >= period:
                raise ValidationError("periodic entry offset must be less than period", context={"offset": offset, "period": period})
            queue_index, _ = _canonical_queue(catalog, entry["queue_id"], name="periodic entry queue_id")
            count = _positive_count(entry["count"], name="periodic entry count")
            key = (offset, queue_index)
            updated = aggregated.get(key, 0) + count
            if updated > MAX_ARRIVAL_COUNT:
                raise ValidationError("Aggregated periodic count exceeds the supported range")
            aggregated[key] = updated
        mutable_buckets: dict[int, list[tuple[int, int]]] = {}
        normalized_entries: list[dict[str, JSONValue]] = []
        for (offset, queue_index), count in sorted(aggregated.items()):
            mutable_buckets.setdefault(offset, []).append((queue_index, count))
            normalized_entries.append(
                {"offset": offset, "queue_id": catalog.queue_id_at(queue_index), "count": count}
            )
        sources.append(
            _PeriodicSource(
                source_id=source_id,
                delay=delay,
                entries=tuple(normalized_entries),
                buckets={offset: tuple(bucket) for offset, bucket in mutable_buckets.items()},
            )
        )
    return tuple(sources)


class PeriodicGlobalPhaseArrival(_CountArrivalBase):
    family = "periodic_global_phase"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"period", "phase", "sources"})
        self.period = _integer(params["period"], name="params.period", minimum=1)
        self.phase = _integer(params["phase"], name="params.phase")
        if self.phase >= self.period:
            raise ValidationError("params.phase must be less than params.period")
        self.sources = _periodic_sources(catalog, params["sources"], period=self.period, delayed=False)
        buckets: dict[int, dict[int, int]] = {}
        live: set[int] = set()
        for source in self.sources:
            for offset, source_bucket in source.buckets.items():
                target = buckets.setdefault((offset + self.phase) % self.period, {})
                for queue_index, count in source_bucket:
                    _add_count(target, queue_index, count)
                    live.add(queue_index)
        self._buckets = {offset: self._count_vector(bucket) for offset, bucket in buckets.items()}
        self._set_live_indices(live)

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        _rng(rng)
        return ArrivalSample(
            slot=resolved,
            offered_counts=self._buckets.get(resolved % self.period, self._zero),
        )

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.family,
            "period": self.period,
            "phase": self.phase,
            "sources": [
                {"id": source.source_id, "entries": [dict(entry) for entry in source.entries]}
                for source in self.sources
            ],
            "live_queue_ids": list(self.live_queue_ids()),
        }


class PeriodicSourceDelaysArrival(_CountArrivalBase):
    family = "periodic_source_delays"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"period", "sources"})
        self.period = _integer(params["period"], name="params.period", minimum=1)
        self.sources = _periodic_sources(catalog, params["sources"], period=self.period, delayed=True)
        self._set_live_indices(
            {
                queue_index
                for source in self.sources
                for bucket in source.buckets.values()
                for queue_index, _count in bucket
            }
        )

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved = _slot(slot)
        _rng(rng)
        aggregated: dict[int, int] = {}
        for source in self.sources:
            if resolved < source.delay:
                continue
            offset = (resolved - source.delay) % self.period
            for queue_index, count in source.buckets.get(offset, ()):
                _add_count(aggregated, queue_index, count)
        return ArrivalSample(slot=resolved, offered_counts=self._count_vector(aggregated))

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.family,
            "period": self.period,
            "sources": [
                {
                    "id": source.source_id,
                    "delay": source.delay,
                    "entries": [dict(entry) for entry in source.entries],
                }
                for source in self.sources
            ],
            "live_queue_ids": list(self.live_queue_ids()),
        }


class _GapSampler(Protocol):
    def sample(self, rng: np.random.Generator) -> int: ...

    def to_dict(self) -> dict[str, JSONValue]: ...


@dataclass(slots=True, frozen=True)
class _DeterministicGap:
    d: int

    def sample(self, rng: np.random.Generator) -> int:
        _ = rng
        return self.d

    def to_dict(self) -> dict[str, JSONValue]:
        return {"kind": "deterministic", "d": self.d}


@dataclass(slots=True, frozen=True)
class _FiniteGap:
    values: tuple[int, ...]
    probabilities: tuple[Decimal, ...]
    _sampler: _ExactDecimalCategorical = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "_sampler",
            _ExactDecimalCategorical(
                self.probabilities,
                name="finite interarrival probabilities",
            ),
        )

    def sample(self, rng: np.random.Generator) -> int:
        return self.values[int(self._sampler.sample_indices(rng))]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "kind": "finite_pmf",
            "outcomes": [
                {"d": d, "probability": self.probabilities[index]}
                for index, d in enumerate(self.values)
            ],
        }


@dataclass(slots=True, frozen=True)
class _GeometricGridGap:
    d_min: int
    delta: int
    p: Decimal
    _sampler_p: float = field(init=False, repr=False)

    def __post_init__(self) -> None:
        probability = _exact_probability(self.p, name="geometric-grid p")
        if probability == 0:
            raise ValidationError("geometric-grid p must lie in (0, 1]")
        object.__setattr__(self, "p", probability)
        object.__setattr__(
            self,
            "_sampler_p",
            _sampler_float(probability, name="geometric-grid p"),
        )

    def sample(self, rng: np.random.Generator) -> int:
        failures = int(rng.geometric(self._sampler_p)) - 1
        return self.d_min + self.delta * failures

    def to_dict(self) -> dict[str, JSONValue]:
        return {"kind": "geometric_grid", "d_min": self.d_min, "delta": self.delta, "p": self.p}


def _gap_sampler(raw: Any, *, name: str) -> _GapSampler:
    mapping = _mapping(raw, name=name)
    kind = mapping.get("kind")
    if kind == "deterministic":
        _keys(mapping, name=name, required={"kind", "d"})
        return _DeterministicGap(_integer(mapping["d"], name=f"{name}.d", minimum=1))
    if kind == "finite_pmf":
        _keys(mapping, name=name, required={"kind", "outcomes"})
        values: list[int] = []
        probabilities: list[Decimal] = []
        seen_gaps: set[int] = set()
        for position, raw_outcome in enumerate(_nonempty_sequence(mapping["outcomes"], name=f"{name}.outcomes")):
            outcome = _mapping(raw_outcome, name=f"{name}.outcomes[{position}]")
            _keys(outcome, name="finite interarrival outcome", required={"d", "probability"})
            gap = _integer(outcome["d"], name="interarrival d", minimum=1)
            if gap in seen_gaps:
                raise ValidationError(
                    "finite interarrival PMF contains a duplicate gap",
                    context={"d": gap},
                )
            seen_gaps.add(gap)
            values.append(gap)
            probabilities.append(
                _exact_probability(
                    outcome["probability"], name="interarrival probability"
                )
            )
        return _FiniteGap(tuple(values), tuple(probabilities))
    if kind == "geometric_grid":
        _keys(mapping, name=name, required={"kind", "d_min", "delta", "p"})
        return _GeometricGridGap(
            _integer(mapping["d_min"], name=f"{name}.d_min", minimum=1),
            _integer(mapping["delta"], name=f"{name}.delta", minimum=1),
            _exact_probability(mapping["p"], name=f"{name}.p"),
        )
    raise ValidationError(
        f"{name}.kind is unsupported",
        context={"kind": kind, "allowed": ["deterministic", "finite_pmf", "geometric_grid"]},
    )


@dataclass(slots=True, frozen=True)
class _DestinationSampler:
    queue_indices: tuple[int, ...]
    queue_ids: tuple[QueueId, ...]
    probabilities: tuple[Decimal, ...]
    _sampler: _ExactDecimalCategorical = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "_sampler",
            _ExactDecimalCategorical(
                self.probabilities,
                name="destination probabilities",
            ),
        )

    def sample(self, rng: np.random.Generator) -> int:
        return self.queue_indices[int(self._sampler.sample_indices(rng))]

    def to_list(self) -> list[dict[str, JSONValue]]:
        return [
            {"queue_id": queue_id, "probability": self.probabilities[index]}
            for index, queue_id in enumerate(self.queue_ids)
        ]


def _destination_sampler(catalog: QueueCatalog, raw: Any, *, name: str) -> _DestinationSampler:
    indices: list[int] = []
    queue_ids: list[QueueId] = []
    probabilities: list[Decimal] = []
    seen_indices: set[int] = set()
    for position, raw_outcome in enumerate(_nonempty_sequence(raw, name=name)):
        outcome = _mapping(raw_outcome, name=f"{name}[{position}]")
        _keys(outcome, name=f"{name}[{position}]", required={"queue_id", "probability"})
        index, queue_id = _canonical_queue(catalog, outcome["queue_id"], name=f"{name}[{position}].queue_id")
        if index in seen_indices:
            raise ValidationError(
                f"{name} contains a duplicate queue coordinate",
                context={"queue_id": queue_id},
            )
        seen_indices.add(index)
        indices.append(index)
        queue_ids.append(queue_id)
        probabilities.append(
            _exact_probability(
                outcome["probability"],
                name=f"{name}[{position}].probability",
            )
        )
    return _DestinationSampler(
        tuple(indices),
        tuple(queue_ids),
        tuple(probabilities),
    )


class _PairSampler(Protocol):
    def sample(self, rng: np.random.Generator) -> tuple[int, int]: ...

    def to_dict(self) -> dict[str, JSONValue]: ...

    def live_indices(self) -> set[int]: ...


@dataclass(slots=True, frozen=True)
class _FactorizedPairSampler:
    gap: _GapSampler
    destination: _DestinationSampler

    def sample(self, rng: np.random.Generator) -> tuple[int, int]:
        # The specified factorized draw order is gap first, destination second.
        return self.gap.sample(rng), self.destination.sample(rng)

    def to_dict(self) -> dict[str, JSONValue]:
        return {"interarrival": self.gap.to_dict(), "destination_pmf": self.destination.to_list()}

    def live_indices(self) -> set[int]:
        return {
            index
            for index, probability in zip(self.destination.queue_indices, self.destination.probabilities, strict=True)
            if probability > 0
        }


@dataclass(slots=True, frozen=True)
class _JointPairSampler:
    gaps: tuple[int, ...]
    queue_indices: tuple[int, ...]
    queue_ids: tuple[QueueId, ...]
    probabilities: tuple[Decimal, ...]
    _sampler: _ExactDecimalCategorical = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "_sampler",
            _ExactDecimalCategorical(
                self.probabilities,
                name="joint renewal probabilities",
            ),
        )

    def sample(self, rng: np.random.Generator) -> tuple[int, int]:
        index = int(self._sampler.sample_indices(rng))
        return self.gaps[index], self.queue_indices[index]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "joint_pmf": [
                {
                    "d": self.gaps[index],
                    "queue_id": queue_id,
                    "probability": self.probabilities[index],
                }
                for index, queue_id in enumerate(self.queue_ids)
            ]
        }

    def live_indices(self) -> set[int]:
        return {
            index
            for index, probability in zip(self.queue_indices, self.probabilities, strict=True)
            if probability > 0
        }


def _pair_sampler(catalog: QueueCatalog, source: Mapping[str, Any], *, name: str) -> _PairSampler:
    has_joint = "joint_pmf" in source
    has_factorized = "interarrival" in source or "destination_pmf" in source
    if has_joint == has_factorized:
        raise ValidationError(f"{name} must choose exactly one of joint_pmf or factorized interarrival/destination_pmf")
    if has_joint:
        _keys(source, name=name, required={"id", "joint_pmf"})
        gaps: list[int] = []
        queue_indices: list[int] = []
        queue_ids: list[QueueId] = []
        probabilities: list[Decimal] = []
        seen_pairs: set[tuple[int, int]] = set()
        for position, raw_outcome in enumerate(_nonempty_sequence(source["joint_pmf"], name=f"{name}.joint_pmf")):
            outcome = _mapping(raw_outcome, name=f"{name}.joint_pmf[{position}]")
            _keys(outcome, name="joint renewal outcome", required={"d", "queue_id", "probability"})
            queue_index, queue_id = _canonical_queue(catalog, outcome["queue_id"], name="joint renewal queue_id")
            gap = _integer(outcome["d"], name="joint renewal d", minimum=1)
            pair = (gap, queue_index)
            if pair in seen_pairs:
                raise ValidationError(
                    "joint renewal PMF contains a duplicate (d, queue_id) coordinate",
                    context={"d": gap, "queue_id": queue_id},
                )
            seen_pairs.add(pair)
            gaps.append(gap)
            queue_indices.append(queue_index)
            queue_ids.append(queue_id)
            probabilities.append(
                _exact_probability(
                    outcome["probability"], name="joint renewal probability"
                )
            )
        return _JointPairSampler(
            tuple(gaps),
            tuple(queue_indices),
            tuple(queue_ids),
            tuple(probabilities),
        )
    _keys(source, name=name, required={"id", "interarrival", "destination_pmf"})
    return _FactorizedPairSampler(
        _gap_sampler(source["interarrival"], name=f"{name}.interarrival"),
        _destination_sampler(catalog, source["destination_pmf"], name=f"{name}.destination_pmf"),
    )


@dataclass(slots=True, frozen=True)
class _RenewalSource:
    source_id: str
    pairs: _PairSampler


class IndependentMarkedRenewalArrival(_SequentialCountArrivalBase):
    family = "independent_marked_renewal"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"sources"})
        sources: list[_RenewalSource] = []
        seen_ids: set[str] = set()
        live: set[int] = set()
        for position, raw_source in enumerate(_nonempty_sequence(params["sources"], name="params.sources")):
            source = _mapping(raw_source, name=f"params.sources[{position}]")
            source_id = _identifier(source.get("id"), name=f"params.sources[{position}].id")
            if source_id in seen_ids:
                raise ValidationError("params.sources contains duplicate ids", context={"id": source_id})
            seen_ids.add(source_id)
            pairs = _pair_sampler(catalog, source, name=f"params.sources[{position}]")
            live.update(pairs.live_indices())
            sources.append(_RenewalSource(source_id, pairs))
        self.sources = tuple(sources)
        self._set_live_indices(live)
        self._initialized = False
        self._heap: list[tuple[int, int]] = []
        self._pending_marks: list[int] = []

    def _initialize(self, rng: np.random.Generator) -> None:
        self._heap = []
        self._pending_marks = [0] * len(self.sources)
        for source_index, source in enumerate(self.sources):
            gap, queue_index = source.pairs.sample(rng)
            next_slot = -1 + gap
            self._pending_marks[source_index] = queue_index
            self._heap.append((next_slot, source_index))
        heapq.heapify(self._heap)
        self._initialized = True

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved, generator = self._begin_slot(slot, rng)
        if not self._initialized:
            self._initialize(generator)
        counts: dict[int, int] = {}
        while self._heap and self._heap[0][0] == resolved:
            event_slot, source_index = heapq.heappop(self._heap)
            _add_count(counts, self._pending_marks[source_index], 1)
            gap, queue_index = self.sources[source_index].pairs.sample(generator)
            self._pending_marks[source_index] = queue_index
            heapq.heappush(self._heap, (event_slot + gap, source_index))
        if self._heap and self._heap[0][0] < resolved:  # pragma: no cover - defensive invariant
            raise ValidationError("renewal event clock fell behind the sampled slot")
        result = ArrivalSample(slot=resolved, offered_counts=self._count_vector(counts))
        self._finish_slot()
        return result

    def reset(self, rng: np.random.Generator | None = None) -> None:
        super().reset(rng)
        self._initialized = False
        self._heap = []
        self._pending_marks = []

    def to_dict(self) -> dict[str, JSONValue]:
        sources: list[dict[str, JSONValue]] = []
        for source in self.sources:
            sources.append({"id": source.source_id, **source.pairs.to_dict()})
        return {"family": self.family, "sources": sources, "live_queue_ids": list(self.live_queue_ids())}


@dataclass(slots=True, frozen=True)
class _PrivateSource:
    source_id: str
    states: tuple[str, ...]
    fixed_initial: int | None
    random_initial: _Categorical | None
    initial_payload: dict[str, JSONValue]
    gaps: tuple[int, ...]
    transitions: tuple[_Categorical, ...]
    transition_rows: tuple[dict[str, JSONValue], ...]
    destination: _DestinationSampler

    def sample_initial(self, rng: np.random.Generator) -> int:
        if self.fixed_initial is not None:
            return self.fixed_initial
        if self.random_initial is None:  # pragma: no cover - construction invariant
            raise ValidationError("private renewal source has no initial distribution")
        return int(self.random_initial.sample(rng))


def _private_source(catalog: QueueCatalog, raw: Any, *, name: str) -> _PrivateSource:
    source = _mapping(raw, name=name)
    _keys(
        source,
        name=name,
        required={"id", "states", "initial", "gaps", "transitions", "destination_pmf"},
    )
    source_id = _identifier(source["id"], name=f"{name}.id")
    states, state_to_index = _states(source["states"], name=f"{name}.states")
    fixed_initial, random_initial, initial_payload = _initial_distribution(
        source["initial"], states=states, state_to_index=state_to_index, name=f"{name}.initial"
    )

    gaps_by_state: list[int | None] = [None] * len(states)
    for position, raw_gap in enumerate(_sequence(source["gaps"], name=f"{name}.gaps")):
        gap = _mapping(raw_gap, name=f"{name}.gaps[{position}]")
        _keys(gap, name="private gap", required={"state", "d"})
        state = _identifier(gap["state"], name="private gap state")
        if state not in state_to_index:
            raise ValidationError("private gap references an unknown state", context={"state": state})
        index = state_to_index[state]
        if gaps_by_state[index] is not None:
            raise ValidationError("private gaps contain a duplicate state", context={"state": state})
        gaps_by_state[index] = _integer(gap["d"], name="private gap d", minimum=1)
    if any(value is None for value in gaps_by_state):
        raise ValidationError("private gaps must define exactly one gap for every state")

    transition_values: list[list[int]] = [[] for _ in states]
    transition_probabilities: list[list[Decimal]] = [[] for _ in states]
    transition_rows: list[dict[str, JSONValue]] = []
    seen_transitions: set[tuple[int, int]] = set()
    for position, raw_transition in enumerate(_sequence(source["transitions"], name=f"{name}.transitions")):
        transition = _mapping(raw_transition, name=f"{name}.transitions[{position}]")
        _keys(transition, name="private transition", required={"state", "next_state", "probability"})
        current = _identifier(transition["state"], name="private transition state")
        next_state = _identifier(transition["next_state"], name="private transition next_state")
        if current not in state_to_index or next_state not in state_to_index:
            raise ValidationError("private transition references an unknown state")
        current_index = state_to_index[current]
        next_index = state_to_index[next_state]
        key = (current_index, next_index)
        if key in seen_transitions:
            raise ValidationError("private transitions contain a duplicate state pair")
        seen_transitions.add(key)
        probability = _exact_probability(
            transition["probability"], name="private transition probability"
        )
        transition_values[current_index].append(next_index)
        transition_probabilities[current_index].append(probability)
        transition_rows.append({"state": current, "next_state": next_state, "probability": probability})
    transitions = tuple(
        _Categorical(
            tuple(transition_values[index]),
            tuple(transition_probabilities[index]),
        )
        for index, state in enumerate(states)
    )
    destination = _destination_sampler(catalog, source["destination_pmf"], name=f"{name}.destination_pmf")
    return _PrivateSource(
        source_id,
        states,
        fixed_initial,
        random_initial,
        initial_payload,
        tuple(int(value) for value in gaps_by_state),
        transitions,
        tuple(transition_rows),
        destination,
    )


class IndependentPrivateMarkovRenewalArrival(_SequentialCountArrivalBase):
    family = "independent_private_markov_renewal"

    def __init__(self, catalog: QueueCatalog, params: Mapping[str, Any]) -> None:
        super().__init__(catalog)
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"sources"})
        sources: list[_PrivateSource] = []
        seen_ids: set[str] = set()
        live: set[int] = set()
        for position, raw_source in enumerate(_nonempty_sequence(params["sources"], name="params.sources")):
            source = _private_source(catalog, raw_source, name=f"params.sources[{position}]")
            if source.source_id in seen_ids:
                raise ValidationError("params.sources contains duplicate ids", context={"id": source.source_id})
            seen_ids.add(source.source_id)
            live.update(
                index
                for index, probability in zip(source.destination.queue_indices, source.destination.probabilities, strict=True)
                if probability > 0
            )
            sources.append(source)
        self.sources = tuple(sources)
        self._set_live_indices(live)
        self._initialized = False
        self._heap: list[tuple[int, int]] = []
        self._states_now: list[int] = []
        self._pending_marks: list[int] = []

    def _initialize(self, rng: np.random.Generator) -> None:
        self._heap = []
        self._states_now = [0] * len(self.sources)
        self._pending_marks = [0] * len(self.sources)
        for source_index, source in enumerate(self.sources):
            state = source.sample_initial(rng)
            queue_index = source.destination.sample(rng)
            self._states_now[source_index] = state
            self._pending_marks[source_index] = queue_index
            self._heap.append((-1 + source.gaps[state], source_index))
        heapq.heapify(self._heap)
        self._initialized = True

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved, generator = self._begin_slot(slot, rng)
        if not self._initialized:
            self._initialize(generator)
        counts: dict[int, int] = {}
        while self._heap and self._heap[0][0] == resolved:
            event_slot, source_index = heapq.heappop(self._heap)
            source = self.sources[source_index]
            _add_count(counts, self._pending_marks[source_index], 1)
            next_state = int(source.transitions[self._states_now[source_index]].sample(generator))
            next_mark = source.destination.sample(generator)
            self._states_now[source_index] = next_state
            self._pending_marks[source_index] = next_mark
            heapq.heappush(self._heap, (event_slot + source.gaps[next_state], source_index))
        if self._heap and self._heap[0][0] < resolved:  # pragma: no cover - defensive invariant
            raise ValidationError("private renewal event clock fell behind the sampled slot")
        result = ArrivalSample(slot=resolved, offered_counts=self._count_vector(counts))
        self._finish_slot()
        return result

    def reset(self, rng: np.random.Generator | None = None) -> None:
        super().reset(rng)
        self._initialized = False
        self._heap = []
        self._states_now = []
        self._pending_marks = []

    def to_dict(self) -> dict[str, JSONValue]:
        sources: list[dict[str, JSONValue]] = []
        for source in self.sources:
            sources.append(
                {
                    "id": source.source_id,
                    "states": list(source.states),
                    "initial": dict(source.initial_payload),
                    "gaps": [
                        {"state": state, "d": source.gaps[index]}
                        for index, state in enumerate(source.states)
                    ],
                    "transitions": [dict(row) for row in source.transition_rows],
                    "destination_pmf": source.destination.to_list(),
                }
            )
        return {"family": self.family, "sources": sources, "live_queue_ids": list(self.live_queue_ids())}


@dataclass(slots=True, frozen=True)
class _SharedOutcome:
    next_state: int
    probability: Decimal
    emissions: tuple[tuple[int, int], ...]
    payload_emissions: tuple[dict[str, JSONValue], ...]


class SharedJointRoundMarkovRenewalArrival(_SequentialCountArrivalBase):
    family = "shared_joint_round_markov_renewal"

    def __init__(
        self,
        catalog: QueueCatalog,
        params: Mapping[str, Any],
        *,
        horizon: int | None = None,
    ) -> None:
        super().__init__(catalog)
        self.horizon = None if horizon is None else _integer(horizon, name="horizon")
        params = _mapping(params, name="params")
        _keys(params, name="params", required={"sources", "states", "initial", "outcomes"})

        source_ids: list[str] = []
        source_to_index: dict[str, int] = {}
        for position, raw_source in enumerate(_nonempty_sequence(params["sources"], name="params.sources")):
            source = _mapping(raw_source, name=f"params.sources[{position}]")
            _keys(source, name=f"params.sources[{position}]", required={"id"})
            source_id = _identifier(source["id"], name=f"params.sources[{position}].id")
            if source_id in source_to_index:
                raise ValidationError("params.sources contains duplicate ids", context={"id": source_id})
            source_to_index[source_id] = len(source_ids)
            source_ids.append(source_id)
        self.source_ids = tuple(source_ids)

        self.states, state_to_index = _states(params["states"], name="params.states")
        self._fixed_initial, self._random_initial, self._initial_payload = _initial_distribution(
            params["initial"], states=self.states, state_to_index=state_to_index, name="params.initial"
        )

        outcomes_by_state: list[list[_SharedOutcome]] = [[] for _ in self.states]
        outcome_payloads: list[dict[str, JSONValue]] = []
        seen_outcomes: set[tuple[int, int, tuple[tuple[int, int], ...]]] = set()
        live: set[int] = set()
        for position, raw_outcome in enumerate(_nonempty_sequence(params["outcomes"], name="params.outcomes")):
            outcome = _mapping(raw_outcome, name=f"params.outcomes[{position}]")
            _keys(outcome, name=f"params.outcomes[{position}]", required={"state", "next_state", "probability", "emissions"})
            current = _identifier(outcome["state"], name="shared outcome state")
            next_state = _identifier(outcome["next_state"], name="shared outcome next_state")
            if current not in state_to_index or next_state not in state_to_index:
                raise ValidationError("shared outcome references an unknown state")
            probability = _exact_probability(
                outcome["probability"], name="shared outcome probability"
            )
            emissions_by_source: list[tuple[int, int] | None] = [None] * len(self.source_ids)
            payload_by_source: list[dict[str, JSONValue] | None] = [None] * len(self.source_ids)
            for emission_position, raw_emission in enumerate(_sequence(outcome["emissions"], name="shared outcome emissions")):
                emission = _mapping(raw_emission, name=f"shared outcome emissions[{emission_position}]")
                _keys(emission, name="shared outcome emission", required={"source_id", "d", "queue_id"})
                source_id = _identifier(emission["source_id"], name="shared outcome emission source_id")
                if source_id not in source_to_index:
                    raise ValidationError("shared outcome emission references an unknown source", context={"source_id": source_id})
                source_index = source_to_index[source_id]
                if emissions_by_source[source_index] is not None:
                    raise ValidationError("shared outcome contains duplicate emissions for a source", context={"source_id": source_id})
                gap = _integer(emission["d"], name="shared outcome emission d", minimum=1)
                queue_index, queue_id = _canonical_queue(catalog, emission["queue_id"], name="shared outcome emission queue_id")
                emissions_by_source[source_index] = (gap, queue_index)
                payload_by_source[source_index] = {"source_id": source_id, "d": gap, "queue_id": queue_id}
                if probability > 0:
                    live.add(queue_index)
            missing_sources = [
                self.source_ids[index]
                for index, emission in enumerate(emissions_by_source)
                if emission is None
            ]
            if missing_sources:
                raise ValidationError(
                    "shared outcome must contain exactly one emission for every source",
                    context={"missing_source_ids": missing_sources},
                )
            normalized = _SharedOutcome(
                state_to_index[next_state],
                probability,
                tuple(emission for emission in emissions_by_source if emission is not None),
                tuple(emission for emission in payload_by_source if emission is not None),
            )
            coordinate = (
                state_to_index[current],
                normalized.next_state,
                normalized.emissions,
            )
            if coordinate in seen_outcomes:
                raise ValidationError(
                    "shared outcome PMF contains a duplicate canonical outcome coordinate",
                    context={"state": current, "next_state": next_state},
                )
            seen_outcomes.add(coordinate)
            outcomes_by_state[state_to_index[current]].append(normalized)
            outcome_payloads.append(
                {
                    "state": current,
                    "next_state": next_state,
                    "probability": probability,
                    "emissions": [dict(emission) for emission in normalized.payload_emissions],
                }
            )
        self._outcomes = tuple(tuple(row) for row in outcomes_by_state)
        self._outcome_probabilities = tuple(
            tuple(outcome.probability for outcome in row)
            for row in self._outcomes
        )
        self._outcome_samplers = tuple(
            _ExactDecimalCategorical(
                probabilities,
                name=f"params.outcomes[{self.states[state_index]!r}] probabilities",
            )
            for state_index, probabilities in enumerate(
                self._outcome_probabilities
            )
        )
        self._outcome_payloads = tuple(outcome_payloads)
        self._set_live_indices(live)
        self._initialized = False
        self._state = 0
        self._clocks: list[int] = []
        self._pending: dict[int, dict[int, int]] = {}

    def _initialize(self, rng: np.random.Generator) -> None:
        if self._fixed_initial is not None:
            self._state = self._fixed_initial
        elif self._random_initial is not None:
            self._state = int(self._random_initial.sample(rng))
        else:  # pragma: no cover - construction invariant
            raise ValidationError("shared renewal model has no initial state")
        self._clocks = [-1] * len(self.source_ids)
        self._pending = {}
        self._initialized = True

    def _advance_finite_horizon_prefix(self, horizon: int, rng: np.random.Generator) -> None:
        # Equivalent to MATERIALIZE_JOINT_ROUNDS with this prefix horizon.  The
        # clocks only increase, so extending the prefix on the next slot never
        # changes already-returned buckets.
        while self._clocks and min(self._clocks) < horizon:
            row = self._outcomes[self._state]
            outcome_index = int(
                self._outcome_samplers[self._state].sample_indices(rng)
            )
            outcome = row[outcome_index]
            for source_index, (gap, queue_index) in enumerate(outcome.emissions):
                event_slot = self._clocks[source_index] + gap
                self._clocks[source_index] = event_slot
                if self.horizon is None or event_slot < self.horizon:
                    bucket = self._pending.setdefault(event_slot, {})
                    _add_count(bucket, queue_index, 1)
            self._state = outcome.next_state

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        resolved, generator = self._begin_slot(slot, rng)
        if self.horizon is not None and resolved >= self.horizon:
            raise ValidationError(
                "slot lies outside the configured arrival horizon",
                context={"slot": resolved, "horizon": self.horizon},
            )
        if not self._initialized:
            self._initialize(generator)
        self._advance_finite_horizon_prefix(resolved + 1, generator)
        counts = self._pending.pop(resolved, {})
        stale = [event_slot for event_slot in self._pending if event_slot < resolved]
        if stale:  # pragma: no cover - defensive invariant
            raise ValidationError("shared renewal materialization produced stale event buckets", context={"slots": stale})
        result = ArrivalSample(slot=resolved, offered_counts=self._count_vector(counts))
        self._finish_slot()
        return result

    def reset(self, rng: np.random.Generator | None = None) -> None:
        super().reset(rng)
        self._initialized = False
        self._state = 0
        self._clocks = []
        self._pending = {}

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.family,
            "sources": [{"id": source_id} for source_id in self.source_ids],
            "states": list(self.states),
            "initial": dict(self._initial_payload),
            "outcomes": [dict(outcome) for outcome in self._outcome_payloads],
            "live_queue_ids": list(self.live_queue_ids()),
        }


CountArrivalModel: TypeAlias = (
    IIDIndependentBernoulliArrival
    | IIDCountTableArrival
    | MarkovCountKernelArrival
    | IIDIndependentPoissonArrival
    | IIDMixedPoissonArrival
    | DeterministicTraceArrival
    | IndependentMarkedRenewalArrival
    | IndependentPrivateMarkovRenewalArrival
    | SharedJointRoundMarkovRenewalArrival
    | PeriodicGlobalPhaseArrival
    | PeriodicSourceDelaysArrival
)


_MODEL_BY_FAMILY: dict[str, type[CountArrivalModel]] = {
    IIDIndependentBernoulliArrival.family: IIDIndependentBernoulliArrival,
    IIDCountTableArrival.family: IIDCountTableArrival,
    MarkovCountKernelArrival.family: MarkovCountKernelArrival,
    IIDIndependentPoissonArrival.family: IIDIndependentPoissonArrival,
    IIDMixedPoissonArrival.family: IIDMixedPoissonArrival,
    DeterministicTraceArrival.family: DeterministicTraceArrival,
    IndependentMarkedRenewalArrival.family: IndependentMarkedRenewalArrival,
    IndependentPrivateMarkovRenewalArrival.family: IndependentPrivateMarkovRenewalArrival,
    SharedJointRoundMarkovRenewalArrival.family: SharedJointRoundMarkovRenewalArrival,
    PeriodicGlobalPhaseArrival.family: PeriodicGlobalPhaseArrival,
    PeriodicSourceDelaysArrival.family: PeriodicSourceDelaysArrival,
}


def build_count_arrival_model(
    family: str,
    catalog: QueueCatalog,
    params: Mapping[str, Any],
    *,
    horizon: int | None = None,
    initial_rng: np.random.Generator | None = None,
) -> CountArrivalModel:
    """Build one canonical Patch 2 queue-count arrival model.

    ``horizon`` is runtime metadata rather than an arrival parameter.  The
    shared-round law uses it to discard sampled events that cannot be observed
    during the run, while still advancing every source clock exactly as the
    finite-horizon specification requires.  ``initial_rng`` is the isolated
    ARRIVAL_INITIAL stream used only to resolve a distributed initial state
    for ``markov_count_kernel``; the resolved state is then reset draw-free.
    """

    if not isinstance(family, str):
        raise ValidationError("family must be a string", context={"value": family})
    try:
        model_type = _MODEL_BY_FAMILY[family]
    except KeyError as exc:
        raise ValidationError(
            "Unsupported count-valued arrival family",
            context={"family": family, "allowed": sorted(_MODEL_BY_FAMILY)},
        ) from exc
    if model_type is SharedJointRoundMarkovRenewalArrival:
        if initial_rng is not None:
            _rng(initial_rng)
        return model_type(catalog, params, horizon=horizon)
    if model_type is MarkovCountKernelArrival:
        if horizon is not None:
            _integer(horizon, name="horizon")
        return model_type(catalog, params, initial_rng=initial_rng)
    if horizon is not None:
        _integer(horizon, name="horizon")
    if initial_rng is not None:
        _rng(initial_rng)
    return model_type(catalog, params)


__all__ = [
    "CountArrivalModel",
    "CountOutcome",
    "MarkovCountKernelRow",
    "ModulationState",
    "IIDIndependentBernoulliArrival",
    "IIDCountTableArrival",
    "MarkovCountKernelArrival",
    "IIDIndependentPoissonArrival",
    "IIDMixedPoissonArrival",
    "DeterministicTraceArrival",
    "IndependentMarkedRenewalArrival",
    "IndependentPrivateMarkovRenewalArrival",
    "SharedJointRoundMarkovRenewalArrival",
    "PeriodicGlobalPhaseArrival",
    "PeriodicSourceDelaysArrival",
    "build_count_arrival_model",
]
