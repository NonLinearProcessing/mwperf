"""Dense count-valued arrival vectors in queue-catalog order."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from numbers import Integral
from typing import Any

import numpy as np

from ..errors import ValidationError
from ..queues import QueueCatalog
from ..types import JSONValue, QueueId, QueueIndex


MAX_ARRIVAL_COUNT = int(np.iinfo(np.int64).max)


class ArrivalCountVector:
    """Immutable nonnegative ``int64`` counts in ``QueueCatalog`` order.

    The dense representation is intentional: it is directly compatible with
    the flat queue bank and exposes a zero-copy read-only NumPy view to the
    materializer.  Stable queue IDs remain the public boundary; dense indices
    are an internal hot-path coordinate system.
    """

    __slots__ = ("_values", "_total", "_nonzero")

    def __init__(self, counts: Iterable[Any] | np.ndarray) -> None:
        if isinstance(counts, np.ndarray):
            raw = np.asarray(counts)
            if raw.ndim != 1:
                raise ValidationError(
                    "ArrivalCountVector must be one-dimensional",
                    context={"shape": tuple(int(item) for item in raw.shape)},
                )
            if raw.dtype.kind not in {"i", "u"} or raw.dtype.kind == "b":
                raise ValidationError(
                    "ArrivalCountVector values must be integers",
                    context={"dtype": str(raw.dtype)},
                )
            if raw.size == 0:
                raise ValidationError("ArrivalCountVector must not be empty")
            if np.any(raw < 0):
                raise ValidationError("ArrivalCountVector values must be nonnegative")
            if raw.dtype.kind == "u" and np.any(raw > MAX_ARRIVAL_COUNT):
                raise ValidationError(
                    "ArrivalCountVector value exceeds the int64 limit",
                    context={"maximum": MAX_ARRIVAL_COUNT},
                )
            values = np.array(raw, dtype=np.int64, order="C", copy=True)
        else:
            try:
                items = tuple(counts)
            except TypeError as exc:
                raise ValidationError(
                    "ArrivalCountVector values must be an iterable of integers",
                    context={"value_type": type(counts).__name__},
                ) from exc
            if not items:
                raise ValidationError("ArrivalCountVector must not be empty")
            normalized: list[int] = []
            for index, value in enumerate(items):
                if isinstance(value, bool) or not isinstance(value, Integral):
                    raise ValidationError(
                        "ArrivalCountVector values must be integers",
                        context={"index": index, "value": value},
                    )
                count = int(value)
                if not 0 <= count <= MAX_ARRIVAL_COUNT:
                    raise ValidationError(
                        "ArrivalCountVector values must lie in the int64 nonnegative range",
                        context={"index": index, "value": count, "maximum": MAX_ARRIVAL_COUNT},
                    )
                normalized.append(count)
            values = np.asarray(normalized, dtype=np.int64)

        # ``flatnonzero`` performs the dense scan in NumPy.  Only sparse active
        # coordinates cross back into Python, both for the cached materializer
        # iterator and for overflow-safe Python-integer accumulation.  This is
        # materially faster than a Python loop over every catalog queue.
        active_indices = np.flatnonzero(values)
        nonzero = tuple(
            (int(index), int(values[index]))
            for index in active_indices
        )
        total = sum(count for _index, count in nonzero)
        # Back the published ndarray with immutable bytes.  Merely clearing an
        # owning ndarray's WRITEABLE flag is insufficient: a caller can turn
        # that flag back on and invalidate the cached sparse/total metadata.
        # NumPy refuses to make a bytes-backed view writable.
        frozen_values = np.frombuffer(values.tobytes(order="C"), dtype=np.int64)
        frozen_values.flags.writeable = False
        self._values = frozen_values
        self._total = total
        self._nonzero = nonzero

    @classmethod
    def zero(cls, catalog_or_size: QueueCatalog | int) -> "ArrivalCountVector":
        size = (
            catalog_or_size.n_queues
            if isinstance(catalog_or_size, QueueCatalog)
            else catalog_or_size
        )
        if isinstance(size, bool) or not isinstance(size, Integral) or int(size) < 1:
            raise ValidationError("count-vector size must be an integer >= 1", context={"value": size})
        return cls(np.zeros(int(size), dtype=np.int64))

    @classmethod
    def from_mapping(
        cls,
        catalog: QueueCatalog,
        counts: Mapping[QueueId, Any],
    ) -> "ArrivalCountVector":
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError("catalog must be a QueueCatalog")
        if not isinstance(counts, Mapping):
            raise ValidationError("counts must be a queue-id mapping")
        values = np.zeros(catalog.n_queues, dtype=np.int64)
        for queue_id, raw_count in counts.items():
            if isinstance(raw_count, bool) or not isinstance(raw_count, Integral):
                raise ValidationError(
                    "arrival counts must be integers",
                    context={"queue_id": queue_id, "value": raw_count},
                )
            count = int(raw_count)
            if not 0 <= count <= MAX_ARRIVAL_COUNT:
                raise ValidationError(
                    "arrival counts must lie in the int64 nonnegative range",
                    context={"queue_id": queue_id, "value": count, "maximum": MAX_ARRIVAL_COUNT},
                )
            values[catalog.index_of(queue_id)] = count
        return cls(values)

    def validate_catalog(self, catalog: QueueCatalog, *, name: str = "arrival counts") -> None:
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError("catalog must be a QueueCatalog")
        if len(self) != catalog.n_queues:
            raise ValidationError(
                f"{name} length does not match the queue catalog",
                context={"length": len(self), "n_queues": catalog.n_queues},
            )

    @property
    def total_count(self) -> int:
        return self._total

    @property
    def nonzero_count(self) -> int:
        return len(self._nonzero)

    @property
    def array_view(self) -> np.ndarray:
        """Return the owned read-only contiguous vector without copying."""

        return self._values

    def to_array(self, *, copy: bool = True) -> np.ndarray:
        if copy:
            return self._values.copy()
        return self._values

    def nonzero_indices(self) -> tuple[QueueIndex, ...]:
        return tuple(index for index, _count in self._nonzero)

    def nonzero_items(self) -> tuple[tuple[QueueIndex, int], ...]:
        """Return cached ``(dense_index, count)`` pairs in catalog order."""

        return self._nonzero

    def count_at(self, index: Any) -> int:
        if isinstance(index, bool) or not isinstance(index, Integral):
            raise ValidationError("queue index must be an integer", context={"value": index})
        resolved = int(index)
        if not 0 <= resolved < len(self):
            raise ValidationError(
                "queue index is outside the arrival count vector",
                context={"index": resolved, "size": len(self)},
            )
        return int(self._values[resolved])

    def count_for(self, catalog: QueueCatalog, queue_id: QueueId) -> int:
        self.validate_catalog(catalog)
        return int(self._values[catalog.index_of(queue_id)])

    def active_queue_ids(self, catalog: QueueCatalog) -> tuple[QueueId, ...]:
        self.validate_catalog(catalog)
        return tuple(catalog.queue_id_at(index) for index in self.nonzero_indices())

    def to_dict(self, catalog: QueueCatalog | None = None) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "format": "queue_count_vector",
            "total_count": self.total_count,
            "dense": [int(value) for value in self._values],
        }
        if catalog is not None:
            self.validate_catalog(catalog)
            payload["nonzero"] = [
                {"queue_id": catalog.queue_id_at(index), "count": int(self._values[index])}
                for index, _count in self._nonzero
            ]
        return payload

    def __len__(self) -> int:
        return int(self._values.size)

    def __iter__(self):
        return (int(value) for value in self._values)

    def __getitem__(self, index: Any) -> int:
        return self.count_at(index)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, ArrivalCountVector) and np.array_equal(self._values, other._values)

    def __repr__(self) -> str:
        return f"ArrivalCountVector({[int(value) for value in self._values]!r})"


__all__ = ["MAX_ARRIVAL_COUNT", "ArrivalCountVector"]
