from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from ..config import ArrivalConfig, SimConfig, SwitchConfig
from ..errors import ValidationError
from ..flows import QueueFlowPlan, build_flow_plan_from_live_queues
from ..queues import QueueCatalog
from ..rng import build_arrival_initial_rng
from ..types import JSONValue, QueueId
from ..utils import normalize_for_json
from ..validation import validate_arrival_config
from .count_arrivals import CountArrivalModel, build_count_arrival_model

def _normalize_metadata(value: Mapping[str, Any] | None) -> dict[str, JSONValue]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValidationError(
            "metadata must be a mapping",
            context={"value_type": type(value).__name__},
        )

    normalized: dict[str, JSONValue] = {}
    for raw_key, raw_value in value.items():
        if not isinstance(raw_key, str):
            raise ValidationError(
                "metadata keys must be strings",
                context={"key": raw_key, "key_type": type(raw_key).__name__},
            )
        normalized[raw_key] = normalize_for_json(raw_value)
    return dict(sorted(normalized.items()))


def _resolve_effective_actual_seed(
    config: SimConfig,
    actual_seed: int | None,
) -> int | None:
    if actual_seed is not None:
        return int(actual_seed)
    if config.run.actual_seed is not None:
        return int(config.run.actual_seed)
    if config.run.seed >= 0:
        return int(config.run.seed)
    return None


def _build_count_model(
    *,
    family: str,
    catalog: QueueCatalog,
    params: Mapping[str, Any],
    horizon: int | None,
    actual_seed: int | None,
) -> CountArrivalModel:
    """Build one canonical count law with an isolated initialization stream.

    Only ``markov_count_kernel`` may consume initialization randomness. Its
    constructor receives the ARRIVAL_INITIAL stream, while every slot sample
    continues to receive its independent ARRIVAL_MODEL/slot stream from the
    kernel. A fixed initial state works without a resolved seed; a distributed
    initial state is rejected by the model factory when no concrete seed exists.
    """

    initial_rng = (
        build_arrival_initial_rng(actual_seed)
        if family == "markov_count_kernel" and actual_seed is not None
        else None
    )
    return build_count_arrival_model(
        family,
        catalog,
        params,
        horizon=horizon,
        initial_rng=initial_rng,
    )


@dataclass(slots=True, frozen=True)
class CompiledArrivalSpec:
    """Canonical queue-count model and its static queue/flow support."""

    model: CountArrivalModel
    queue_catalog: QueueCatalog
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    flow_plan: QueueFlowPlan = field(init=False)
    _live_queue_ids: tuple[QueueId, ...] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.queue_catalog, QueueCatalog):
            raise ValidationError(
                "queue_catalog must be a QueueCatalog",
                context={"value_type": type(self.queue_catalog).__name__},
            )
        model_catalog = getattr(self.model, "catalog", None)
        if model_catalog != self.queue_catalog:
            raise ValidationError(
                "count arrival model catalog does not match queue_catalog"
            )

        raw_live_queue_ids = tuple(self.model.live_queue_ids())
        requested: set[QueueId] = set()
        for position, queue_id in enumerate(raw_live_queue_ids):
            self.queue_catalog.index_of(queue_id)
            if queue_id in requested:
                raise ValidationError(
                    "count arrival model live_queue_ids must be unique",
                    context={"position": position, "queue_id": queue_id},
                )
            requested.add(queue_id)
        live_queue_ids = tuple(
            queue_id
            for queue_id in self.queue_catalog.queue_ids
            if queue_id in requested
        )

        object.__setattr__(self, "metadata", _normalize_metadata(self.metadata))
        object.__setattr__(self, "_live_queue_ids", live_queue_ids)
        object.__setattr__(
            self,
            "flow_plan",
            build_flow_plan_from_live_queues(self.queue_catalog, live_queue_ids),
        )

    @property
    def family(self) -> str:
        return self.model.family

    def live_queue_ids(self) -> tuple[QueueId, ...]:
        return self._live_queue_ids

    def allowed_queue_ids(self) -> tuple[QueueId, ...]:
        """Queues on which the configured law can offer a positive count."""

        return self._live_queue_ids

    @property
    def support_size(self) -> int:
        return len(self._live_queue_ids)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "family": self.family,
            "queue_space": self.queue_catalog.to_dict(),
            "live_queue_ids": list(self.live_queue_ids()),
            "support_size": self.support_size,
            "flow_plan": self.flow_plan.to_dict(),
            "metadata": normalize_for_json(self.metadata),
        }

def compile_arrival_model(
    config: SimConfig,
    *,
    actual_seed: int | None = None,
    validate: bool = True,
) -> CountArrivalModel:
    """Compile a resolved schema-4 config through the count-model factory."""

    if not isinstance(config, SimConfig):
        raise ValidationError(
            "config must be a SimConfig",
            context={"value_type": type(config).__name__},
        )
    if validate:
        validate_arrival_config(config.arrival, config.switch)
    return _build_count_model(
        family=config.arrival.family,
        catalog=config.switch.catalog,
        params=config.arrival.params,
        horizon=config.run.slots,
        actual_seed=_resolve_effective_actual_seed(config, actual_seed),
    )


def compile_arrival_spec(
    config: SimConfig,
    *,
    actual_seed: int | None = None,
    validate: bool = True,
) -> CompiledArrivalSpec:
    """Compile a resolved schema-4 config into one queue-count support bundle."""

    if not isinstance(config, SimConfig):
        raise ValidationError(
            "config must be a SimConfig",
            context={"value_type": type(config).__name__},
        )
    if validate:
        validate_arrival_config(config.arrival, config.switch)
    model = compile_arrival_model(
        config,
        actual_seed=actual_seed,
        validate=False,
    )
    return CompiledArrivalSpec(
        model=model,
        queue_catalog=config.switch.catalog,
        metadata=config.arrival.metadata,
    )


def compile_arrival_from_sections(
    switch: SwitchConfig,
    arrival: ArrivalConfig,
    *,
    actual_seed: int | None = None,
    horizon: int | None = None,
    validate: bool = True,
) -> CompiledArrivalSpec:
    """Compile canonical switch/arrival sections without constructing a run."""

    if not isinstance(switch, SwitchConfig):
        raise ValidationError(
            "switch must be a SwitchConfig",
            context={"value_type": type(switch).__name__},
        )
    if not isinstance(arrival, ArrivalConfig):
        raise ValidationError(
            "arrival must be an ArrivalConfig",
            context={"value_type": type(arrival).__name__},
        )
    if validate:
        validate_arrival_config(arrival, switch)
    model = _build_count_model(
        family=arrival.family,
        catalog=switch.catalog,
        params=arrival.params,
        horizon=horizon,
        actual_seed=actual_seed,
    )
    return CompiledArrivalSpec(
        model=model,
        queue_catalog=switch.catalog,
        metadata=arrival.metadata,
    )


__all__ = [
    "CompiledArrivalSpec",
    "compile_arrival_model",
    "compile_arrival_spec",
    "compile_arrival_from_sections",
]
