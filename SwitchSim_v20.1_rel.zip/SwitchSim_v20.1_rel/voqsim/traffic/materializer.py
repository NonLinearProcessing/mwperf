from __future__ import annotations

from dataclasses import dataclass, field
from numbers import Integral
from typing import Any, Iterable

import numpy as np

from ..errors import ValidationError
from ..events import ArrivalAttempt
from ..flows import QueueFlowPlan
from ..packet import Packet
from ..queues import QueueCatalog
from ..types import JSONValue, PacketId, QueueId
from ..utils import normalize_for_json
from .arrivals import ArrivalSample
from .compiler import CompiledArrivalSpec
from .counts import ArrivalCountVector


def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < 0:
        raise ValidationError(
            f"{name} must be >= 0",
            context={"value": coerced, "minimum": 0},
        )
    return coerced


def _require_rng(rng: Any) -> np.random.Generator:
    if not isinstance(rng, np.random.Generator):
        raise ValidationError(
            "rng must be a numpy.random.Generator",
            context={"value_type": type(rng).__name__},
        )
    return rng


def _canonicalize_count_attempts(
    attempts: Iterable[ArrivalAttempt],
    *,
    catalog: QueueCatalog,
) -> tuple[ArrivalAttempt, ...]:
    """Order offered units by queue-catalog identity and packet identity."""

    return tuple(
        sorted(
            attempts,
            key=lambda attempt: (
                catalog.index_of(attempt.queue_id),
                attempt.flow_id,
                attempt.packet_id,
            ),
        )
    )


@dataclass(slots=True, frozen=True)
class MaterializedArrival:
    """One queue-count sample and its exact offered packet attempts."""

    sample: ArrivalSample
    catalog: QueueCatalog
    attempts: tuple[ArrivalAttempt, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.catalog, QueueCatalog):
            raise ValidationError(
                "catalog must be a QueueCatalog",
                context={"value_type": type(self.catalog).__name__},
            )
        if not isinstance(self.sample, ArrivalSample):
            raise ValidationError(
                "sample must be an ArrivalSample",
                context={"value_type": type(self.sample).__name__},
            )
        if self.sample.offered_counts is None:
            raise ValidationError(
                "schema-4 materialization requires a queue-count ArrivalSample"
            )
        self.sample.offered_counts.validate_catalog(
            self.catalog,
            name="sample.offered_counts",
        )

        raw_attempts = tuple(self.attempts)
        seen_packet_ids: dict[int, int] = {}
        for index, attempt in enumerate(raw_attempts):
            if not isinstance(attempt, ArrivalAttempt):
                raise ValidationError(
                    "attempts must contain ArrivalAttempt instances",
                    context={"index": index, "value_type": type(attempt).__name__},
                )
            if attempt.slot != self.sample.slot:
                raise ValidationError(
                    "All materialized arrival attempts must belong to the sampled slot",
                    context={
                        "index": index,
                        "expected_slot": self.sample.slot,
                        "attempt_slot": attempt.slot,
                    },
                )
            if attempt.packet_id in seen_packet_ids:
                raise ValidationError(
                    "Materialized arrival attempts must carry unique packet_id values",
                    context={
                        "packet_id": attempt.packet_id,
                        "first_index": seen_packet_ids[attempt.packet_id],
                        "duplicate_index": index,
                    },
                )
            seen_packet_ids[attempt.packet_id] = index

        canonical_attempts = _canonicalize_count_attempts(
            raw_attempts,
            catalog=self.catalog,
        )
        observed: dict[int, int] = {}
        for attempt in canonical_attempts:
            queue_index = self.catalog.index_of(attempt.queue_id)
            observed[queue_index] = observed.get(queue_index, 0) + 1
        expected = dict(self.sample.offered_counts.nonzero_items())
        if observed != expected:
            raise ValidationError(
                "Materialized arrival attempts must exactly match the queue-count vector",
                context={"expected": expected, "observed": observed},
            )
        object.__setattr__(self, "attempts", canonical_attempts)

    @property
    def slot(self) -> int:
        return self.sample.slot

    @property
    def offered_counts(self) -> ArrivalCountVector:
        counts = self.sample.offered_counts
        if counts is None:  # pragma: no cover - construction invariant
            raise ValidationError("materialized arrival is missing offered counts")
        return counts

    def as_count_vector(self) -> ArrivalCountVector:
        return self.offered_counts

    @property
    def total_attempts(self) -> int:
        return len(self.attempts)

    @property
    def packet_ids(self) -> tuple[int, ...]:
        return tuple(attempt.packet_id for attempt in self.attempts)

    @property
    def flow_ids(self) -> tuple[int, ...]:
        return tuple(attempt.flow_id for attempt in self.attempts)

    @property
    def active_queue_ids(self) -> tuple[QueueId, ...]:
        return self.offered_counts.active_queue_ids(self.catalog)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "slot": self.slot,
            "sample": self.sample.to_dict(),
            "attempts": [attempt.to_dict() for attempt in self.attempts],
            "packet_ids": list(self.packet_ids),
            "flow_ids": list(self.flow_ids),
        }


@dataclass(slots=True)
class ArrivalMaterializer:
    """Deterministically expand queue-count samples into packet attempts."""

    compiled: CompiledArrivalSpec
    initial_packet_id: PacketId = 0
    _next_packet_id: PacketId = field(init=False, repr=False)
    _empty_count_vector: ArrivalCountVector = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.compiled, CompiledArrivalSpec):
            raise ValidationError(
                "compiled must be a CompiledArrivalSpec",
                context={"value_type": type(self.compiled).__name__},
            )
        initial_packet_id = _validate_non_negative_int(
            self.initial_packet_id,
            name="initial_packet_id",
        )
        object.__setattr__(self, "initial_packet_id", initial_packet_id)
        object.__setattr__(self, "_next_packet_id", initial_packet_id)
        object.__setattr__(
            self,
            "_empty_count_vector",
            ArrivalCountVector.zero(self.compiled.queue_catalog),
        )

    @property
    def catalog(self) -> QueueCatalog:
        return self.compiled.queue_catalog

    @property
    def model(self) -> Any:
        return self.compiled.model

    @property
    def flow_plan(self) -> QueueFlowPlan:
        return self.compiled.flow_plan

    @property
    def live_queue_ids(self) -> tuple[QueueId, ...]:
        return self.compiled.live_queue_ids()

    @property
    def next_packet_id(self) -> int:
        return self._next_packet_id

    def reset(
        self,
        *,
        next_packet_id: int | None = None,
        reset_arrival_model: bool = True,
        rng: np.random.Generator | None = None,
    ) -> None:
        """Reset deterministic state; arrival-model reset consumes no draws."""

        resolved_next_packet_id = (
            self.initial_packet_id
            if next_packet_id is None
            else _validate_non_negative_int(next_packet_id, name="next_packet_id")
        )
        object.__setattr__(self, "_next_packet_id", resolved_next_packet_id)
        if reset_arrival_model:
            self.model.reset(rng)

    def sample(self, slot: int, rng: np.random.Generator) -> ArrivalSample:
        sample = self.model.sample(slot, _require_rng(rng))
        if sample.offered_counts is None:
            raise ValidationError(
                "canonical arrival models must emit queue-count samples"
            )
        sample.offered_counts.validate_catalog(self.catalog)
        return sample

    def empty_sample(self, slot: int) -> ArrivalSample:
        return ArrivalSample(slot=slot, offered_counts=self._empty_count_vector)

    def _packet_for_queue(
        self,
        *,
        packet_id: int,
        slot: int,
        queue_id: QueueId,
    ) -> Packet:
        try:
            flow_id = self.flow_plan.flow_id_for_queue(queue_id)
        except ValidationError as exc:
            raise ValidationError(
                "ArrivalCountVector activates a queue outside the compiled live set",
                context={
                    "slot": slot,
                    "queue_id": queue_id,
                    "live_queue_ids": list(self.live_queue_ids),
                },
            ) from exc
        return Packet.for_queue(
            packet_id=packet_id,
            flow_id=flow_id,
            queue_id=queue_id,
            generation_slot=slot,
        )

    def materialize_attempts(
        self,
        sample: ArrivalSample,
    ) -> tuple[ArrivalAttempt, ...]:
        if not isinstance(sample, ArrivalSample):
            raise ValidationError(
                "sample must be an ArrivalSample",
                context={"value_type": type(sample).__name__},
            )
        if sample.offered_counts is None:
            raise ValidationError(
                "schema-4 materialization requires a queue-count ArrivalSample"
            )
        sample.offered_counts.validate_catalog(self.catalog)

        next_packet_id = self._next_packet_id
        attempts: list[ArrivalAttempt] = []
        for queue_index, count in sample.offered_counts.nonzero_items():
            queue_id = self.catalog.queue_id_at(queue_index)
            for _unit in range(count):
                packet = self._packet_for_queue(
                    packet_id=next_packet_id,
                    slot=sample.slot,
                    queue_id=queue_id,
                )
                attempts.append(ArrivalAttempt.from_packet(packet))
                next_packet_id += 1

        object.__setattr__(self, "_next_packet_id", next_packet_id)
        return tuple(attempts)

    def materialize(self, sample: ArrivalSample) -> MaterializedArrival:
        return MaterializedArrival(
            sample=sample,
            attempts=self.materialize_attempts(sample),
            catalog=self.catalog,
        )

    def sample_and_materialize(
        self,
        slot: int,
        rng: np.random.Generator,
    ) -> MaterializedArrival:
        return self.materialize(self.sample(slot, rng))

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "compiled": normalize_for_json(self.compiled.to_dict()),
            "initial_packet_id": self.initial_packet_id,
            "next_packet_id": self.next_packet_id,
        }


def build_arrival_materializer(
    compiled: CompiledArrivalSpec,
    *,
    initial_packet_id: int = 0,
) -> ArrivalMaterializer:
    return ArrivalMaterializer(
        compiled=compiled,
        initial_packet_id=initial_packet_id,
    )


__all__ = [
    "MaterializedArrival",
    "ArrivalMaterializer",
    "build_arrival_materializer",
]
