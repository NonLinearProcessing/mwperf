from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from decimal import Decimal, InvalidOperation
from fractions import Fraction
import math
from numbers import Integral, Real
from typing import Any, Final

from .config import (
    CONFIG_SCHEMA_VERSION,
    SUPPORTED_CONFIG_SCHEMA_VERSIONS,
    AllowedEdgesConfig,
    AlphabetEntryConfig,
    ArrivalConfig,
    InitialStateConfig,
    KernelRowConfig,
    ObservationConfig,
    ObservationTargetConfig,
    RunConfig,
    SchedulerConfig,
    SimConfig,
    SwitchConfig,
    TelemetryConfig,
)
from .arrival_config import (
    COUNT_ARRIVAL_FAMILIES,
    MAX_ARRIVAL_COUNT,
    SUPPORTED_INTERARRIVAL_KINDS,
    parse_count_arrival_params,
)
from .errors import ConfigError, ValidationError
from .queues import MAX_QUEUE_LENGTH, QueueCatalog
from .rng import MAX_SEED_VALUE
from .types import QueueId, VOQKey
from .utils import canonicalize_voq_key, iter_valid_voq_keys, normalize_for_json
from .schedulers.registry import (
    available_schedulers,
    build_scheduler_for_domain,
    is_scheduler_registered,
    resolve_scheduler_name,
    resolve_scheduler_spec,
)

# Compatibility export only. Validation itself consults the live scheduler
# registry so dynamically registered constraint schedulers are accepted.
SUPPORTED_SCHEDULERS: Final[frozenset[str]] = frozenset(available_schedulers())
SUPPORTED_ARRIVAL_FAMILIES: Final[frozenset[str]] = frozenset(COUNT_ARRIVAL_FAMILIES)
SUPPORTED_TERMINATION_MODES: Final[frozenset[str]] = frozenset({"fixed_slots", "fixed_slots_then_drain"})
SUPPORTED_ALLOWED_EDGE_MODES: Final[frozenset[str]] = frozenset({"full", "explicit"})
SUPPORTED_ALPHABET_CONSTRAINTS: Final[frozenset[str]] = frozenset({"unrestricted", "per_input_line_rate", "global_one_hot"})
SUPPORTED_INITIAL_MODES: Final[frozenset[str]] = frozenset({"state", "distribution"})
SUPPORTED_TELEMETRY_FORMATS: Final[frozenset[str]] = frozenset({"jsonl"})
SUPPORTED_QUEUE_SNAPSHOT_MODES: Final[frozenset[str]] = frozenset({"dense", "sparse_nonzero", "disabled"})

def _validate_int(value: Any, *, name: str, minimum: int, maximum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < minimum:
        raise ValidationError(f"{name} must be >= {minimum}", context={"value": coerced, "minimum": minimum})
    if maximum is not None and coerced > maximum:
        raise ValidationError(f"{name} must be <= {maximum}", context={"value": coerced, "maximum": maximum})
    return coerced


def _validate_decimal(
    value: Any,
    *,
    name: str,
    minimum: Decimal | None = None,
    maximum: Decimal | None = None,
) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (Decimal, Integral, Real)):
        raise ValidationError(f"{name} must be a numeric scalar", context={"value": value})
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValidationError(f"{name} must be a finite decimal number", context={"value": value}) from exc
    if not result.is_finite():
        raise ValidationError(f"{name} must be finite", context={"value": str(value)})
    if minimum is not None and result < minimum:
        raise ValidationError(f"{name} must be >= {minimum}", context={"value": str(result)})
    if maximum is not None and result > maximum:
        raise ValidationError(f"{name} must be <= {maximum}", context={"value": str(result)})
    return Decimal(0) if result.is_zero() else result


def _validate_probability(value: Any, *, name: str, upper_inclusive: bool = True) -> Decimal:
    probability = _validate_decimal(value, name=name)
    if upper_inclusive:
        ok = Decimal(0) <= probability <= Decimal(1)
        bounds = "[0, 1]"
    else:
        ok = Decimal(0) <= probability < Decimal(1)
        bounds = "[0, 1)"
    if not ok:
        raise ValidationError(f"{name} must lie in {bounds}", context={"value": probability, "range": bounds})
    return probability


def _validate_name(value: Any, *, name: str, allowed: frozenset[str]) -> str:
    if not isinstance(value, str):
        raise ValidationError(f"{name} must be a string", context={"value": value})
    token = value.strip().lower()
    if token not in allowed:
        raise ValidationError(
            f"Unsupported value for {name}",
            context={"value": value, "allowed": sorted(allowed)},
        )
    if value != token:
        raise ValidationError(
            f"{name} must use canonical spelling",
            context={"value": value, "canonical": token},
        )
    return token


def _require_canonical_token(value: Any, *, name: str) -> str:
    """Require the exact identifier form emitted by the config parser."""

    if not isinstance(value, str):
        raise ValidationError(f"{name} must be a string", context={"value": value})
    token = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in token:
        token = token.replace("__", "_")
    token = token.strip("_")
    if not token:
        raise ValidationError(f"{name} must not be empty", context={"value": value})
    if value != token:
        raise ValidationError(
            f"{name} must use canonical token spelling",
            context={"value": value, "canonical": token},
        )
    return token


def _validate_json_mapping(value: Any, *, name: str) -> None:
    if not isinstance(value, Mapping):
        raise ValidationError(
            f"{name} must be a mapping",
            context={"value_type": type(value).__name__},
        )
    for key in value:
        if not isinstance(key, str):
            raise ValidationError(
                f"{name} keys must be strings",
                context={"key": key, "key_type": type(key).__name__},
            )
    try:
        normalize_for_json(dict(value))
    except (TypeError, ValueError) as exc:
        raise ValidationError(
            f"{name} must contain canonical JSON-compatible values",
            context={"reason": str(exc)},
        ) from exc


def _validate_probability_mass(total: Decimal | Fraction, *, name: str) -> None:
    exact_total = total if isinstance(total, Fraction) else Fraction(total)
    if exact_total != 1:
        raise ValidationError(
            f"{name} must sum exactly to 1",
            context={"sum": str(exact_total)},
        )


def _validate_config_schema_version(value: str) -> str:
    # ``resolve_config`` accepts older input schemas and migrates them before
    # constructing SimConfig. A SimConfig itself is always canonical schema 3.
    if value != CONFIG_SCHEMA_VERSION:
        raise ValidationError(
            "SimConfig must use the canonical config schema_version",
            context={
                "schema_version": value,
                "canonical": CONFIG_SCHEMA_VERSION,
                "accepted_input_schemas": sorted(SUPPORTED_CONFIG_SCHEMA_VERSIONS),
            },
        )
    return value


def validate_seed(seed: Any, *, allow_minus_one: bool = True, name: str = "seed") -> int:
    """Validate a requested or concrete seed value."""

    if isinstance(seed, bool) or not isinstance(seed, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": seed})
    coerced = int(seed)
    if allow_minus_one and coerced == -1:
        return coerced
    if coerced < 0:
        raise ValidationError(f"{name} must be -1 or non-negative", context={"value": coerced})
    if coerced > MAX_SEED_VALUE:
        raise ValidationError(
            f"{name} exceeds the supported 64-bit range",
            context={"value": coerced, "maximum": MAX_SEED_VALUE},
        )
    return coerced


def validate_actual_seed(seed: Any, *, name: str = "actual_seed") -> int:
    """Validate a concrete resolved master seed."""

    return validate_seed(seed, allow_minus_one=False, name=name)


def validate_scheduler_name(name: Any) -> str:
    """Validate and resolve a scheduler name through the live registry."""

    if not isinstance(name, str):
        raise ValidationError("scheduler.name must be a string", context={"value": name})
    token = name.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in token:
        token = token.replace("__", "_")
    token = token.strip("_")
    if name != token:
        raise ValidationError(
            "scheduler.name must use canonical spelling",
            context={"value": name, "canonical": token},
        )
    replacements = {
        "random_maximal": "crossbar_random_greedy_maximal",
        "islip_rga": "crossbar_random_grant_accept",
        "islip_canonical": "crossbar_islip",
        "canonical_islip": "crossbar_islip",
        "max_weight": "crossbar_max_weight",
        "maxweight": "crossbar_max_weight",
    }
    if token in replacements:
        raise ValidationError(
            "legacy scheduler name is not valid in schema 4",
            context={"scheduler": token, "replacement": replacements[token]},
        )
    if token in {"round_robin", "roundrobin"}:
        raise ValidationError(
            "round_robin was removed because it was not a conventional persistent round-robin policy",
            context={"scheduler": token, "replacement": None},
        )
    if token == "islip":
        raise ValidationError(
            "scheduler.name 'islip' is ambiguous",
            context={"scheduler": token, "choose_one": ["crossbar_random_grant_accept", "crossbar_islip"]},
        )
    try:
        canonical = resolve_scheduler_name(token)
    except (ConfigError, ValidationError) as exc:
        raise ValidationError(
            "Unsupported value for scheduler.name",
            context={"value": name, "allowed": list(available_schedulers())},
        ) from exc
    if not is_scheduler_registered(canonical):
        raise ValidationError(
            "Unsupported value for scheduler.name",
            context={"value": name, "allowed": list(available_schedulers())},
        )
    if canonical != token:
        raise ValidationError(
            "scheduler.name aliases are not valid in schema 4",
            context={"scheduler": token, "canonical": canonical},
        )
    return canonical


def _validate_run_config(run: RunConfig) -> None:
    validate_seed(run.seed, allow_minus_one=True, name="run.seed")
    _validate_int(run.slots, name="run.slots", minimum=1)
    warmup = _validate_int(run.warmup_slots, name="run.warmup_slots", minimum=0)
    if warmup >= run.slots:
        raise ValidationError(
            "run.warmup_slots must be less than run.slots",
            context={"warmup_slots": warmup, "slots": run.slots},
        )
    _validate_name(run.termination, name="run.termination", allowed=SUPPORTED_TERMINATION_MODES)
    if run.output_dir is not None:
        if not isinstance(run.output_dir, str):
            raise ValidationError("run.output_dir must be a string or null", context={"value": run.output_dir})
        if not run.output_dir or not run.output_dir.strip():
            raise ValidationError("run.output_dir must not be empty", context={"value": run.output_dir})
        if run.output_dir != run.output_dir.strip():
            raise ValidationError(
                "run.output_dir must not contain leading or trailing whitespace",
                context={"value": run.output_dir},
            )

    if run.actual_seed is not None:
        actual_seed = validate_actual_seed(run.actual_seed, name="run.actual_seed")
        if run.seed >= 0 and actual_seed != run.seed:
            raise ValidationError(
                "run.actual_seed must equal run.seed when a fixed seed is requested",
                context={"run_seed": run.seed, "actual_seed": actual_seed},
            )


def _validate_switch_config(switch: SwitchConfig) -> None:
    if switch.kind != "generalized":
        raise ValidationError(
            "Schema-4 SimConfig requires switch.kind='generalized'",
            context={"kind": switch.kind, "allowed": ["generalized"]},
        )
    if switch.n_ports is not None or switch.voq_capacity is not None:
        raise ValidationError(
            "generalized switch must not define legacy n_ports/voq_capacity fields",
            context={"n_ports": switch.n_ports, "voq_capacity": switch.voq_capacity},
        )
    if switch.allow_self_traffic is not True:
        raise ValidationError(
            "switch.allow_self_traffic is a legacy-crossbar-only field",
            context={"switch_kind": switch.kind},
        )
    catalog = switch.queue_catalog
    if not isinstance(catalog, QueueCatalog):
        raise ValidationError(
            "generalized switch requires a QueueCatalog",
            context={"value_type": type(catalog).__name__},
        )
    if catalog.n_queues < 1:
        raise ValidationError("generalized switch queue catalog must not be empty")
    if switch.queue_capacity is not None:
        _validate_int(
            switch.queue_capacity,
            name="switch.queue_capacity",
            minimum=1,
            maximum=MAX_QUEUE_LENGTH,
        )
    if any(spec.legacy_voq is not None for spec in catalog.specs):
        raise ValidationError(
            "schema-4 switch queues must not carry legacy_voq metadata"
        )
    if switch.legacy_n_ports is not None:
        raise ValidationError("switch.legacy_n_ports was removed from schema 4")


def _validate_scheduler_config(scheduler: SchedulerConfig, *, switch: SwitchConfig) -> Any:
    canonical_name = validate_scheduler_name(scheduler.name)
    if not isinstance(scheduler.params, Mapping):
        raise ValidationError(
            "scheduler.params must be a mapping",
            context={"value_type": type(scheduler.params).__name__},
        )
    for key in scheduler.params:
        if not isinstance(key, str):
            raise ValidationError(
                "scheduler.params keys must be strings",
                context={"key": key, "key_type": type(key).__name__},
            )

    spec = resolve_scheduler_spec(canonical_name, scheduler.params)
    if spec.name != scheduler.name or dict(spec.params) != dict(scheduler.params):
        raise ValidationError(
            "SchedulerConfig must contain canonical effective scheduler parameters",
            context={
                "configured_name": scheduler.name,
                "canonical_name": spec.name,
                "configured_params": dict(scheduler.params),
                "effective_params": dict(spec.params),
            },
        )
    if scheduler.service_family != spec.service_family:
        raise ValidationError(
            "SchedulerConfig must contain the canonical registry-derived service_family",
            context={
                "configured_service_family": scheduler.service_family,
                "registry_service_family": spec.service_family,
            },
        )

    capabilities = spec.capabilities
    if capabilities.input_kind != "queue_vector" or capabilities.output_kind != "service_decision":
        raise ValidationError(
            "generalized switches require a queue-vector ServiceDecision scheduler",
            context={
                "scheduler": scheduler.name,
                "input_kind": capabilities.input_kind,
                "output_kind": capabilities.output_kind,
            },
        )
    if spec.service_family is None:
        raise ValidationError(
            "generalized scheduler registration must identify one service family",
            context={
                "scheduler": scheduler.name,
                "service_families": list(capabilities.service_families),
            },
        )
    # Generalized scheduler modules own their physical feasible-set model.
    # Every nontrivial family must expose its canonical topology under this
    # reserved parameter so service-model hashing cannot silently omit a
    # behaviorally relevant constraint. Optimizer/tie-breaking parameters stay
    # outside ``constraint`` and therefore do not change the topology hash.
    if spec.service_family != "unconstrained":
        if "constraint" not in scheduler.params:
            raise ValidationError(
                "generalized scheduler params must contain canonical 'constraint' data",
                context={
                    "scheduler": scheduler.name,
                    "service_family": spec.service_family,
                },
            )
        if not isinstance(scheduler.params["constraint"], Mapping):
            raise ValidationError(
                "scheduler.params.constraint must be a mapping",
                context={"scheduler": scheduler.name},
            )
    from .schedulers.domain import QueueSchedulerDomain

    return build_scheduler_for_domain(
        scheduler.name,
        scheduler.params,
        QueueSchedulerDomain(
            queue_catalog=switch.catalog,
            service_family=spec.service_family,
        ),
    )


def _validate_observation_config(
    observation: ObservationConfig,
    switch: SwitchConfig,
    bound_scheduler: Any,
) -> None:
    if not isinstance(observation, ObservationConfig):
        raise ValidationError(
            "telemetry.observation must be an ObservationConfig",
            context={"value_type": type(observation).__name__},
        )
    if not isinstance(observation.enabled, bool):
        raise ValidationError(
            "telemetry.observation.enabled must be a boolean",
            context={"value": observation.enabled},
        )
    if observation.block_slots is not None:
        _validate_int(
            observation.block_slots,
            name="telemetry.observation.block_slots",
            minimum=1,
        )
    if observation.enabled and not observation.targets:
        raise ValidationError(
            "enabled compact observations require at least one target"
        )
    seen: dict[QueueId, int] = {}
    for index, target in enumerate(observation.targets):
        if not isinstance(target, ObservationTargetConfig):
            raise ValidationError(
                "telemetry.observation.targets must contain ObservationTargetConfig values",
                context={"index": index, "value_type": type(target).__name__},
            )
        try:
            switch.catalog.index_of(target.queue_id)
        except ValidationError as exc:
            raise ValidationError(
                "observation target references a queue outside the switch catalog",
                context={"index": index, "queue_id": target.queue_id},
            ) from exc
        if target.queue_id in seen:
            raise ValidationError(
                "observation targets must be unique",
                context={
                    "queue_id": target.queue_id,
                    "first_index": seen[target.queue_id],
                    "duplicate_index": index,
                },
            )
        seen[target.queue_id] = index
        if target.gap not in {"none", "exact"}:
            raise ValidationError(
                "observation target gap must be 'none' or 'exact'",
                context={"index": index, "gap": target.gap},
            )
        if observation.enabled and target.gap == "exact":
            certificates = getattr(bound_scheduler, "exact_class_certificates", None)
            if not callable(certificates):
                raise ValidationError(
                    "gap='exact' requires a scheduler with exact class-certificate support",
                    context={
                        "index": index,
                        "queue_id": target.queue_id,
                        "scheduler": getattr(
                            bound_scheduler,
                            "name",
                            type(bound_scheduler).__name__,
                        ),
                    },
                )
            if getattr(bound_scheduler, "service_family", None) == "resource_packing":
                serviceable = getattr(
                    bound_scheduler,
                    "individually_serviceable_queue_ids",
                    (),
                )
                if target.queue_id not in serviceable:
                    raise ValidationError(
                        "exact-gap resource-packing target is individually infeasible",
                        context={"index": index, "queue_id": target.queue_id},
                    )


def _validate_telemetry_config(
    telemetry: TelemetryConfig,
    switch: SwitchConfig,
    bound_scheduler: Any,
) -> None:
    _validate_name(telemetry.format, name="telemetry.format", allowed=SUPPORTED_TELEMETRY_FORMATS)
    _validate_name(telemetry.queue_snapshot, name="telemetry.queue_snapshot", allowed=SUPPORTED_QUEUE_SNAPSHOT_MODES)
    if not isinstance(telemetry.include_packet_events, bool):
        raise ValidationError(
            "telemetry.include_packet_events must be a boolean",
            context={"value": telemetry.include_packet_events},
        )
    if not isinstance(telemetry.include_scheduler_state, bool):
        raise ValidationError(
            "telemetry.include_scheduler_state must be a boolean",
            context={"value": telemetry.include_scheduler_state},
        )
    if not isinstance(telemetry.write_slot_trace, bool):
        raise ValidationError(
            "telemetry.write_slot_trace must be a boolean",
            context={"value": telemetry.write_slot_trace},
        )
    _validate_observation_config(telemetry.observation, switch, bound_scheduler)


def _validate_edge_within_switch(edge: VOQKey, *, switch: SwitchConfig, name: str) -> VOQKey:
    src_port, dst_port = canonicalize_voq_key(edge)
    n_ports = switch.arrival_n_ports
    if n_ports is None:
        raise ValidationError(
            "legacy VOQ-addressed arrivals require switch.legacy_n_ports and queue legacy_voq mappings",
            context={"switch_kind": switch.kind},
        )
    _validate_int(src_port, name=f"{name}.src_port", minimum=0, maximum=n_ports - 1)
    _validate_int(dst_port, name=f"{name}.dst_port", minimum=0, maximum=n_ports - 1)
    if not switch.allow_self_traffic and src_port == dst_port:
        raise ValidationError(
            f"{name} contains a self-edge while switch.allow_self_traffic is disabled",
            context={"voq_key": (src_port, dst_port)},
        )
    normalized = (src_port, dst_port)
    if switch.kind == "generalized":
        matching_queue_ids = [
            spec.queue_id for spec in switch.catalog.specs if spec.legacy_voq == normalized
        ]
        if not matching_queue_ids:
            raise ValidationError(
                f"{name} is not mapped to a generalized queue",
                context={"voq_key": normalized},
            )
        if len(matching_queue_ids) > 1:
            raise ValidationError(
                f"{name} is ambiguous because multiple generalized queues share its legacy_voq",
                context={"voq_key": normalized, "queue_ids": matching_queue_ids},
            )
    return normalized


def _resolved_allowed_edges(allowed_edges: AllowedEdgesConfig, *, switch: SwitchConfig) -> tuple[VOQKey, ...]:
    if allowed_edges.mode == "full":
        if switch.kind == "legacy_crossbar":
            return tuple(iter_valid_voq_keys(int(switch.n_ports), allow_self_traffic=switch.allow_self_traffic))
        mapped: list[VOQKey] = []
        for spec in switch.catalog.specs:
            if spec.legacy_voq is not None:
                mapped.append(
                    _validate_edge_within_switch(
                        spec.legacy_voq,
                        switch=switch,
                        name=f"switch.queues[{len(mapped)}].legacy_voq",
                    )
                )
        if not mapped:
            raise ValidationError(
                "legacy arrival.allowed_edges.mode='full' requires generalized queue legacy_voq mappings; queue-addressed arrivals arrive in Patch 2",
                context={"switch_kind": switch.kind},
            )
        return tuple(mapped)
    return tuple(
        _validate_edge_within_switch(edge, switch=switch, name=f"arrival.allowed_edges.edges[{index}]")
        for index, edge in enumerate(allowed_edges.edges)
    )


def validate_allowed_edges_config(arrival: ArrivalConfig, switch: SwitchConfig) -> tuple[VOQKey, ...]:
    """Validate the static exogenous-arrival support set and return it in canonical order."""

    _validate_name(arrival.allowed_edges.mode, name="arrival.allowed_edges.mode", allowed=SUPPORTED_ALLOWED_EDGE_MODES)

    if arrival.allowed_edges.mode == "full" and arrival.allowed_edges.edges:
        raise ValidationError(
            "arrival.allowed_edges.edges must be empty when mode='full'",
            context={"mode": arrival.allowed_edges.mode, "edges": arrival.allowed_edges.edges},
        )

    edges = _resolved_allowed_edges(arrival.allowed_edges, switch=switch)
    if arrival.allowed_edges.mode == "explicit":
        seen: dict[VOQKey, int] = {}
        for index, edge in enumerate(edges):
            if edge in seen:
                raise ValidationError(
                    "arrival.allowed_edges contains duplicate VOQ keys",
                    context={"voq_key": edge, "first_index": seen[edge], "duplicate_index": index},
                )
            seen[edge] = index
    return tuple(sorted(edges))


def validate_mask_edges(
    mask_edges: Iterable[VOQKey],
    *,
    allowed_edges: Iterable[VOQKey],
    alphabet_constraint: str,
    switch: SwitchConfig,
    name: str,
) -> tuple[VOQKey, ...]:
    """Validate one binary arrival-mask edge list against ``E0`` and an optional alphabet constraint."""

    allowed = set(allowed_edges)
    normalized: list[VOQKey] = []
    seen: dict[VOQKey, int] = {}

    for index, raw_edge in enumerate(mask_edges):
        edge = _validate_edge_within_switch(raw_edge, switch=switch, name=f"{name}[{index}]")
        if edge not in allowed:
            raise ValidationError(
                f"{name} contains an edge outside the configured arrival support set E0",
                context={"voq_key": edge},
            )
        if edge in seen:
            raise ValidationError(
                f"{name} contains duplicate VOQ keys",
                context={"voq_key": edge, "first_index": seen[edge], "duplicate_index": index},
            )
        seen[edge] = index
        normalized.append(edge)

    if alphabet_constraint == "per_input_line_rate":
        per_input_counts: dict[int, int] = defaultdict(int)
        for src_port, _ in normalized:
            per_input_counts[src_port] += 1
            if per_input_counts[src_port] > 1:
                raise ValidationError(
                    f"{name} violates the per-input line-rate alphabet constraint",
                    context={"input_port": src_port, "edges": sorted(normalized)},
                )
    elif alphabet_constraint == "global_one_hot" and len(normalized) > 1:
        raise ValidationError(
            f"{name} violates the global one-hot alphabet constraint",
            context={"num_active_edges": len(normalized), "edges": sorted(normalized)},
        )

    return tuple(sorted(normalized))


def _reject_unused_arrival_fields(arrival: ArrivalConfig, *, fields: Mapping[str, Any], family: str) -> None:
    stale = {key: value for key, value in fields.items() if value not in (None, (), {}, [])}
    if stale:
        raise ValidationError(
            "ArrivalConfig contains fields that are not used by the selected arrival family",
            context={"family": family, "stale_fields": sorted(stale)},
        )


def _validate_alphabet_entries(
    entries: tuple[AlphabetEntryConfig, ...],
    *,
    allowed_edges: tuple[VOQKey, ...],
    switch: SwitchConfig,
    alphabet_constraint: str,
    require_probability: bool,
    require_id: bool,
    name: str,
) -> tuple[tuple[VOQKey, ...], ...]:
    if not entries:
        raise ValidationError(f"{name} must not be empty")

    seen_ids: dict[str, int] = {}
    seen_masks: dict[tuple[VOQKey, ...], int] = {}
    normalized_masks: list[tuple[VOQKey, ...]] = []

    for index, entry in enumerate(entries):
        if require_id and entry.id is None:
            raise ValidationError(f"{name}[{index}].id is required for this arrival family")
        if entry.id is not None:
            _require_canonical_token(entry.id, name=f"{name}[{index}].id")
            if entry.id in seen_ids:
                raise ValidationError(
                    f"{name} contains duplicate entry ids",
                    context={"id": entry.id, "first_index": seen_ids[entry.id], "duplicate_index": index},
                )
            seen_ids[entry.id] = index

        probability = entry.probability
        if require_probability:
            if probability is None:
                raise ValidationError(f"{name}[{index}].probability is required")
            _validate_probability(probability, name=f"{name}[{index}].probability", upper_inclusive=True)
        elif probability is not None:
            raise ValidationError(f"{name}[{index}].probability is not used by this arrival family")

        mask = validate_mask_edges(
            entry.edges,
            allowed_edges=allowed_edges,
            alphabet_constraint=alphabet_constraint,
            switch=switch,
            name=f"{name}[{index}].edges",
        )
        if mask in seen_masks:
            raise ValidationError(
                f"{name} contains duplicate arrival masks",
                context={"mask_edges": mask, "first_index": seen_masks[mask], "duplicate_index": index},
            )
        seen_masks[mask] = index
        normalized_masks.append(mask)

    return tuple(normalized_masks)


def validate_iid_table_arrival(arrival: ArrivalConfig, switch: SwitchConfig) -> None:
    """Validate the exact iid arrival support table ``(A, p)``."""

    _reject_unused_arrival_fields(
        arrival,
        fields={
            "states": arrival.states,
            "kernel": arrival.kernel,
            "initial": arrival.initial,
            "lambda_default": arrival.lambda_default,
            "lambda_overrides": arrival.lambda_overrides,
            "params": arrival.params,
        },
        family="iid_table",
    )
    allowed_edges = validate_allowed_edges_config(arrival, switch)
    masks = _validate_alphabet_entries(
        arrival.alphabet,
        allowed_edges=allowed_edges,
        switch=switch,
        alphabet_constraint=arrival.alphabet_constraint,
        require_probability=True,
        require_id=False,
        name="arrival.alphabet",
    )
    total_probability = sum(
        (Fraction(_validate_probability(entry.probability, name="arrival.alphabet probability"))
         for entry in arrival.alphabet if entry.probability is not None),
        Fraction(0),
    )
    _validate_probability_mass(total_probability, name="arrival.alphabet probabilities")
    _ = masks  # explicit retention documents that duplicate masks were checked


def _validate_initial_config(initial: InitialStateConfig | None, *, states: frozenset[str]) -> None:
    if initial is None:
        raise ValidationError("arrival.initial is required for family='markov_kernel'")

    has_state = initial.state is not None
    has_distribution = bool(initial.distribution)
    if has_state and has_distribution:
        raise ValidationError("arrival.initial must choose exactly one of 'state' or 'distribution'")
    if not has_state and not has_distribution:
        raise ValidationError("arrival.initial must contain either 'state' or 'distribution'")

    if has_state:
        _validate_name("state", name="arrival.initial mode", allowed=SUPPORTED_INITIAL_MODES)
        _require_canonical_token(initial.state, name="arrival.initial.state")
        if initial.state not in states:
            raise ValidationError(
                "arrival.initial.state references an unknown state",
                context={"state": initial.state, "states": sorted(states)},
            )
    else:
        _validate_name("distribution", name="arrival.initial mode", allowed=SUPPORTED_INITIAL_MODES)
        total = Fraction(0)
        for state, probability in initial.distribution.items():
            _require_canonical_token(state, name="arrival.initial.distribution key")
            if state not in states:
                raise ValidationError(
                    "arrival.initial.distribution references an unknown state",
                    context={"state": state, "states": sorted(states)},
                )
            total += Fraction(_validate_probability(probability, name=f"arrival.initial.distribution[{state!r}]", upper_inclusive=True))
        _validate_probability_mass(total, name="arrival.initial.distribution")


def validate_markov_kernel_arrival(arrival: ArrivalConfig, switch: SwitchConfig) -> None:
    """Validate the exact finite-state arrival kernel ``(C, A, R)``."""

    _reject_unused_arrival_fields(
        arrival,
        fields={
            "lambda_default": arrival.lambda_default,
            "lambda_overrides": arrival.lambda_overrides,
            "params": arrival.params,
        },
        family="markov_kernel",
    )

    allowed_edges = validate_allowed_edges_config(arrival, switch)
    if not arrival.states:
        raise ValidationError("arrival.states must not be empty for family='markov_kernel'")

    seen_states: dict[str, int] = {}
    for index, state in enumerate(arrival.states):
        _require_canonical_token(state, name=f"arrival.states[{index}]")
        if state in seen_states:
            raise ValidationError(
                "arrival.states contains duplicate state ids",
                context={"state": state, "first_index": seen_states[state], "duplicate_index": index},
            )
        seen_states[state] = index
    states = frozenset(arrival.states)

    masks = _validate_alphabet_entries(
        arrival.alphabet,
        allowed_edges=allowed_edges,
        switch=switch,
        alphabet_constraint=arrival.alphabet_constraint,
        require_probability=False,
        require_id=True,
        name="arrival.alphabet",
    )
    _ = masks
    mask_ids = frozenset(entry.id for entry in arrival.alphabet if entry.id is not None)

    if not arrival.kernel:
        raise ValidationError("arrival.kernel must not be empty for family='markov_kernel'")

    seen_rows: dict[tuple[str, str, str], int] = {}
    per_state_mass: dict[str, Fraction] = defaultdict(Fraction)
    for index, row in enumerate(arrival.kernel):
        _require_canonical_token(row.state, name=f"arrival.kernel[{index}].state")
        _require_canonical_token(row.mask_id, name=f"arrival.kernel[{index}].mask_id")
        _require_canonical_token(row.next_state, name=f"arrival.kernel[{index}].next_state")
        if row.state not in states:
            raise ValidationError(
                "arrival.kernel row references an unknown current state",
                context={"state": row.state, "row_index": index, "states": sorted(states)},
            )
        if row.next_state not in states:
            raise ValidationError(
                "arrival.kernel row references an unknown next_state",
                context={"next_state": row.next_state, "row_index": index, "states": sorted(states)},
            )
        if row.mask_id not in mask_ids:
            raise ValidationError(
                "arrival.kernel row references an unknown mask_id",
                context={"mask_id": row.mask_id, "row_index": index, "mask_ids": sorted(mask_ids)},
            )
        key = (row.state, row.mask_id, row.next_state)
        if key in seen_rows:
            raise ValidationError(
                "arrival.kernel contains duplicate transition rows",
                context={"row": key, "first_index": seen_rows[key], "duplicate_index": index},
            )
        seen_rows[key] = index
        per_state_mass[row.state] += Fraction(_validate_probability(
            row.probability,
            name=f"arrival.kernel[{index}].probability",
            upper_inclusive=True,
        ))

    for state in sorted(states):
        if state not in per_state_mass:
            raise ValidationError(
                "arrival.kernel is missing outgoing probability mass for a state",
                context={"state": state},
            )
        _validate_probability_mass(per_state_mass[state], name=f"arrival.kernel outgoing mass for state '{state}'")

    _validate_initial_config(arrival.initial, states=states)


def _parse_override_key_text(raw_key: str) -> VOQKey:
    if not isinstance(raw_key, str):
        raise ValidationError("arrival.lambda_overrides keys must be strings", context={"key": raw_key})
    text = raw_key.strip()
    for opener, closer in (("[", "]"), ("(", ")")):
        if text.startswith(opener) and text.endswith(closer):
            text = text[1:-1].strip()
            break
    parts = [part.strip() for part in text.split(",")]
    if len(parts) != 2 or any(part == "" for part in parts):
        raise ValidationError(
            "arrival.lambda_overrides keys must use VOQ syntax '[i,j]' or 'i,j'",
            context={"key": raw_key},
        )
    try:
        src_port = int(parts[0])
        dst_port = int(parts[1])
    except ValueError as exc:
        raise ValidationError(
            "arrival.lambda_overrides keys must use integer VOQ coordinates",
            context={"key": raw_key},
        ) from exc
    return (src_port, dst_port)


def validate_factorized_bernoulli_arrival(arrival: ArrivalConfig, switch: SwitchConfig) -> None:
    """Validate the exact compact iid Bernoulli specialization on the binary alphabet."""

    _reject_unused_arrival_fields(
        arrival,
        fields={
            "alphabet": arrival.alphabet,
            "states": arrival.states,
            "kernel": arrival.kernel,
            "initial": arrival.initial,
            "params": arrival.params,
        },
        family="factorized_bernoulli",
    )
    if arrival.alphabet_constraint != "unrestricted":
        raise ValidationError(
            "factorized_bernoulli is only exact for alphabet_constraint='unrestricted'",
            context={"alphabet_constraint": arrival.alphabet_constraint},
        )
    allowed_edges = validate_allowed_edges_config(arrival, switch)
    if arrival.lambda_default is None:
        raise ValidationError("arrival.lambda.default or arrival.lambda_default is required for family='factorized_bernoulli'")
    _validate_probability(arrival.lambda_default, name="arrival.lambda.default", upper_inclusive=True)

    seen_override_edges: dict[VOQKey, str] = {}
    allowed_edge_set = set(allowed_edges)
    for raw_key, probability in arrival.lambda_overrides.items():
        parsed_edge = _parse_override_key_text(raw_key)
        canonical_key = f"[{parsed_edge[0]},{parsed_edge[1]}]"
        if raw_key != canonical_key:
            raise ValidationError(
                "arrival.lambda_overrides keys must use canonical '[i,j]' syntax",
                context={"key": raw_key, "canonical_key": canonical_key},
            )
        edge = _validate_edge_within_switch(parsed_edge, switch=switch, name="arrival.lambda_overrides")
        if edge not in allowed_edge_set:
            raise ValidationError(
                "arrival.lambda_overrides references an edge outside the configured arrival support set E0",
                context={"voq_key": edge},
            )
        if edge in seen_override_edges:
            raise ValidationError(
                "arrival.lambda_overrides contains duplicate VOQ overrides",
                context={"voq_key": edge, "first_key": seen_override_edges[edge], "duplicate_key": raw_key},
            )
        seen_override_edges[edge] = raw_key
        _validate_probability(probability, name=f"arrival.lambda_overrides[{raw_key!r}]", upper_inclusive=True)


def _require_count_mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationError(
            f"{name} must be a mapping/object",
            context={"value_type": type(value).__name__},
        )
    return value


def _require_count_sequence(value: Any, *, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(
            f"{name} must be a sequence",
            context={"value_type": type(value).__name__},
        )
    return value


def _validate_exact_keys(
    mapping: Mapping[str, Any],
    *,
    name: str,
    expected: frozenset[str] | set[str],
) -> None:
    non_string = [key for key in mapping if not isinstance(key, str)]
    if non_string:
        raise ValidationError(
            f"{name} keys must be strings",
            context={"keys": non_string},
        )
    extras = sorted(set(mapping) - set(expected))
    missing = sorted(set(expected) - set(mapping))
    if extras or missing:
        raise ValidationError(
            f"{name} does not match the canonical schema",
            context={"unknown_keys": extras, "missing_keys": missing},
        )


def _validate_queue_id_in_catalog(value: Any, *, switch: SwitchConfig, name: str) -> Any:
    try:
        queue_index = switch.catalog.index_of(value)
    except ValidationError as exc:
        raise ValidationError(
            f"{name} is not present in switch.queues",
            context={"queue_id": value},
        ) from exc
    spec = switch.catalog.spec_at(queue_index)
    if (
        switch.kind == "legacy_crossbar"
        and not switch.allow_self_traffic
        and spec.legacy_voq is not None
        and spec.legacy_voq[0] == spec.legacy_voq[1]
    ):
        raise ValidationError(
            f"{name} targets a self queue while switch.allow_self_traffic is disabled",
            context={"queue_id": spec.queue_id, "legacy_voq": list(spec.legacy_voq)},
        )
    return value


def _validate_count(value: Any, *, name: str) -> int:
    return _validate_int(
        value,
        name=name,
        minimum=1,
        maximum=MAX_ARRIVAL_COUNT,
    )


def _validate_states(raw: Any, *, name: str) -> tuple[str, ...]:
    values = _require_count_sequence(raw, name=name)
    if not values:
        raise ValidationError(f"{name} must not be empty")
    states: list[str] = []
    seen: dict[str, int] = {}
    for index, state in enumerate(values):
        canonical = _require_canonical_token(state, name=f"{name}[{index}]")
        if canonical in seen:
            raise ValidationError(
                f"{name} contains duplicate state ids",
                context={
                    "state": canonical,
                    "first_index": seen[canonical],
                    "duplicate_index": index,
                },
            )
        seen[canonical] = index
        states.append(canonical)
    return tuple(states)


def _validate_count_initial(raw: Any, *, states: tuple[str, ...], name: str) -> None:
    mapping = _require_count_mapping(raw, name=name)
    allowed = frozenset({"state", "distribution"})
    non_string = [key for key in mapping if not isinstance(key, str)]
    extras = [] if non_string else sorted(set(mapping) - allowed)
    if non_string or extras:
        raise ValidationError(
            f"{name} contains unknown keys",
            context={"unknown_keys": extras, "non_string_keys": non_string},
        )
    if ("state" in mapping) == ("distribution" in mapping):
        raise ValidationError(f"{name} must choose exactly one of 'state' or 'distribution'")

    state_set = frozenset(states)
    if "state" in mapping:
        state = _require_canonical_token(mapping["state"], name=f"{name}.state")
        if state not in state_set:
            raise ValidationError(
                f"{name}.state references an unknown state",
                context={"state": state, "states": list(states)},
            )
        return

    distribution = _require_count_mapping(
        mapping["distribution"], name=f"{name}.distribution"
    )
    unknown_states = sorted(str(state) for state in set(distribution) - state_set)
    missing_states = [state for state in states if state not in distribution]
    if unknown_states or missing_states:
        raise ValidationError(
            f"{name}.distribution keys must exactly match the configured states",
            context={"unknown_states": unknown_states, "missing_states": missing_states},
        )
    probabilities: list[Decimal] = []
    for state, probability in distribution.items():
        canonical = _require_canonical_token(state, name=f"{name}.distribution key")
        if canonical != state:
            raise ValidationError(
                f"{name}.distribution keys must use canonical spelling",
                context={"state": state, "canonical": canonical},
            )
        if state not in state_set:
            raise ValidationError(
                f"{name}.distribution references an unknown state",
                context={"state": state, "states": list(states)},
            )
        probabilities.append(
            _validate_probability(
                probability,
                name=f"{name}.distribution[{state!r}]",
                upper_inclusive=True,
            )
        )
    _validate_probability_mass(sum((Fraction(value) for value in probabilities), Fraction(0)), name=f"{name}.distribution")


def _validate_source_ids(
    sources: Sequence[Any],
    *,
    name: str = "arrival.sources",
    id_only: bool = False,
    require_nonempty: bool = True,
) -> tuple[str, ...]:
    if require_nonempty and not sources:
        raise ValidationError(f"{name} must not be empty")
    source_ids: list[str] = []
    seen: dict[str, int] = {}
    for index, source_raw in enumerate(sources):
        source_name = f"{name}[{index}]"
        source = _require_count_mapping(source_raw, name=source_name)
        if id_only:
            _validate_exact_keys(source, name=source_name, expected=frozenset({"id"}))
        if "id" not in source:
            raise ValidationError(
                f"{source_name} is missing its source id",
                context={"missing_key": "id"},
            )
        source_id = _require_canonical_token(source["id"], name=f"{source_name}.id")
        if source_id in seen:
            raise ValidationError(
                f"{name} contains duplicate source ids",
                context={
                    "source_id": source_id,
                    "first_index": seen[source_id],
                    "duplicate_index": index,
                },
            )
        seen[source_id] = index
        source_ids.append(source_id)
    return tuple(source_ids)


def _validate_pmf_rows(
    raw: Any,
    *,
    name: str,
    coordinate_fields: tuple[str, ...],
    switch: SwitchConfig,
) -> None:
    rows = _require_count_sequence(raw, name=name)
    if not rows:
        raise ValidationError(f"{name} must not be empty")
    expected = frozenset((*coordinate_fields, "probability"))
    seen: dict[tuple[Any, ...], int] = {}
    probabilities: list[Decimal] = []
    for index, row_raw in enumerate(rows):
        row_name = f"{name}[{index}]"
        row = _require_count_mapping(row_raw, name=row_name)
        _validate_exact_keys(row, name=row_name, expected=expected)
        coordinate: list[Any] = []
        for field_name in coordinate_fields:
            value = row[field_name]
            if field_name == "d":
                value = _validate_int(value, name=f"{row_name}.d", minimum=1)
            elif field_name == "queue_id":
                value = _validate_queue_id_in_catalog(
                    value,
                    switch=switch,
                    name=f"{row_name}.queue_id",
                )
            else:  # pragma: no cover - closed helper contract
                raise AssertionError(f"unsupported PMF coordinate {field_name!r}")
            coordinate.append(value)
        coordinate_key = tuple(coordinate)
        if coordinate_key in seen:
            raise ValidationError(
                f"{name} contains duplicate PMF coordinates",
                context={
                    "coordinate": list(coordinate_key),
                    "first_index": seen[coordinate_key],
                    "duplicate_index": index,
                },
            )
        seen[coordinate_key] = index
        probabilities.append(
            _validate_probability(
                row["probability"],
                name=f"{row_name}.probability",
                upper_inclusive=True,
            )
        )
    _validate_probability_mass(sum((Fraction(value) for value in probabilities), Fraction(0)), name=name)


def _validate_trace_params(params: Mapping[str, Any], switch: SwitchConfig) -> None:
    _validate_exact_keys(params, name="arrival.params", expected=frozenset({"events"}))
    events = _require_count_sequence(params["events"], name="arrival.events")
    for index, event_raw in enumerate(events):
        name = f"arrival.events[{index}]"
        event = _require_count_mapping(event_raw, name=name)
        keys = frozenset({"slot", "queue_id", "count"})
        _validate_exact_keys(event, name=name, expected=keys)
        _validate_int(event["slot"], name=f"{name}.slot", minimum=0)
        _validate_queue_id_in_catalog(event["queue_id"], switch=switch, name=f"{name}.queue_id")
        _validate_count(event["count"], name=f"{name}.count")


def _validate_periodic_params(
    params: Mapping[str, Any],
    switch: SwitchConfig,
    *,
    delayed: bool,
) -> None:
    expected = (
        frozenset({"period", "sources"})
        if delayed
        else frozenset({"period", "phase", "sources"})
    )
    _validate_exact_keys(params, name="arrival.params", expected=expected)
    period = _validate_int(params["period"], name="arrival.period", minimum=1)
    if not delayed:
        _validate_int(params["phase"], name="arrival.phase", minimum=0, maximum=period - 1)
    sources = _require_count_sequence(params["sources"], name="arrival.sources")
    _validate_source_ids(sources, require_nonempty=False)
    source_keys = (
        frozenset({"id", "delay", "entries"})
        if delayed
        else frozenset({"id", "entries"})
    )
    for source_index, source_raw in enumerate(sources):
        source_name = f"arrival.sources[{source_index}]"
        source = _require_count_mapping(source_raw, name=source_name)
        _validate_exact_keys(source, name=source_name, expected=source_keys)
        if delayed:
            _validate_int(source["delay"], name=f"{source_name}.delay", minimum=0)
        entries = _require_count_sequence(source["entries"], name=f"{source_name}.entries")
        for entry_index, entry_raw in enumerate(entries):
            entry_name = f"{source_name}.entries[{entry_index}]"
            entry = _require_count_mapping(entry_raw, name=entry_name)
            keys = frozenset({"offset", "queue_id", "count"})
            _validate_exact_keys(entry, name=entry_name, expected=keys)
            _validate_int(
                entry["offset"],
                name=f"{entry_name}.offset",
                minimum=0,
                maximum=period - 1,
            )
            _validate_queue_id_in_catalog(
                entry["queue_id"], switch=switch, name=f"{entry_name}.queue_id"
            )
            _validate_count(entry["count"], name=f"{entry_name}.count")


def _validate_interarrival(raw: Any, *, name: str, switch: SwitchConfig) -> None:
    interarrival = _require_count_mapping(raw, name=name)
    if "kind" not in interarrival:
        raise ValidationError(f"{name} is missing kind", context={"missing_key": "kind"})
    kind = _validate_name(
        interarrival["kind"],
        name=f"{name}.kind",
        allowed=SUPPORTED_INTERARRIVAL_KINDS,
    )
    if kind == "deterministic":
        _validate_exact_keys(interarrival, name=name, expected=frozenset({"kind", "d"}))
        _validate_int(interarrival["d"], name=f"{name}.d", minimum=1)
        return
    if kind == "finite_pmf":
        _validate_exact_keys(
            interarrival,
            name=name,
            expected=frozenset({"kind", "outcomes"}),
        )
        _validate_pmf_rows(
            interarrival["outcomes"],
            name=f"{name}.outcomes",
            coordinate_fields=("d",),
            switch=switch,
        )
        return
    _validate_exact_keys(
        interarrival,
        name=name,
        expected=frozenset({"kind", "d_min", "delta", "p"}),
    )
    _validate_int(interarrival["d_min"], name=f"{name}.d_min", minimum=1)
    _validate_int(interarrival["delta"], name=f"{name}.delta", minimum=1)
    p = _validate_probability(
        interarrival["p"], name=f"{name}.p", upper_inclusive=True
    )
    if p <= 0.0:
        raise ValidationError(
            f"{name}.p must lie in (0, 1]",
            context={"value": p, "range": "(0, 1]"},
        )


def _validate_independent_renewal_params(
    params: Mapping[str, Any], switch: SwitchConfig
) -> None:
    _validate_exact_keys(params, name="arrival.params", expected=frozenset({"sources"}))
    sources = _require_count_sequence(params["sources"], name="arrival.sources")
    _validate_source_ids(sources)
    for index, source_raw in enumerate(sources):
        name = f"arrival.sources[{index}]"
        source = _require_count_mapping(source_raw, name=name)
        factorized_keys = frozenset({"id", "interarrival", "destination_pmf"})
        joint_keys = frozenset({"id", "joint_pmf"})
        keys = frozenset(source)
        if keys == joint_keys:
            _validate_pmf_rows(
                source["joint_pmf"],
                name=f"{name}.joint_pmf",
                coordinate_fields=("d", "queue_id"),
                switch=switch,
            )
        elif keys == factorized_keys:
            _validate_interarrival(source["interarrival"], name=f"{name}.interarrival", switch=switch)
            _validate_pmf_rows(
                source["destination_pmf"],
                name=f"{name}.destination_pmf",
                coordinate_fields=("queue_id",),
                switch=switch,
            )
        else:
            raise ValidationError(
                f"{name} must choose exactly one canonical renewal parameterization",
                context={
                    "keys": sorted(str(key) for key in source),
                    "factorized_keys": sorted(factorized_keys),
                    "joint_keys": sorted(joint_keys),
                },
            )


def _validate_private_markov_params(
    params: Mapping[str, Any], switch: SwitchConfig
) -> None:
    _validate_exact_keys(params, name="arrival.params", expected=frozenset({"sources"}))
    sources = _require_count_sequence(params["sources"], name="arrival.sources")
    _validate_source_ids(sources)
    source_keys = frozenset(
        {"id", "states", "initial", "gaps", "transitions", "destination_pmf"}
    )
    for source_index, source_raw in enumerate(sources):
        source_name = f"arrival.sources[{source_index}]"
        source = _require_count_mapping(source_raw, name=source_name)
        _validate_exact_keys(source, name=source_name, expected=source_keys)
        states = _validate_states(source["states"], name=f"{source_name}.states")
        state_set = frozenset(states)
        _validate_count_initial(source["initial"], states=states, name=f"{source_name}.initial")

        gaps = _require_count_sequence(source["gaps"], name=f"{source_name}.gaps")
        seen_gaps: dict[str, int] = {}
        for gap_index, gap_raw in enumerate(gaps):
            gap_name = f"{source_name}.gaps[{gap_index}]"
            gap = _require_count_mapping(gap_raw, name=gap_name)
            _validate_exact_keys(gap, name=gap_name, expected=frozenset({"state", "d"}))
            state = _require_canonical_token(gap["state"], name=f"{gap_name}.state")
            if state not in state_set:
                raise ValidationError(
                    f"{gap_name}.state references an unknown state",
                    context={"state": state, "states": list(states)},
                )
            if state in seen_gaps:
                raise ValidationError(
                    f"{source_name}.gaps contains duplicate state coordinates",
                    context={"state": state, "first_index": seen_gaps[state], "duplicate_index": gap_index},
                )
            seen_gaps[state] = gap_index
            _validate_int(gap["d"], name=f"{gap_name}.d", minimum=1)
        missing_gaps = [state for state in states if state not in seen_gaps]
        if missing_gaps:
            raise ValidationError(
                f"{source_name}.gaps must define every state exactly once",
                context={"missing_states": missing_gaps},
            )

        transitions = _require_count_sequence(
            source["transitions"], name=f"{source_name}.transitions"
        )
        if not transitions:
            raise ValidationError(f"{source_name}.transitions must not be empty")
        seen_transitions: dict[tuple[str, str], int] = {}
        row_probabilities: dict[str, list[Decimal]] = defaultdict(list)
        for transition_index, transition_raw in enumerate(transitions):
            transition_name = f"{source_name}.transitions[{transition_index}]"
            transition = _require_count_mapping(transition_raw, name=transition_name)
            keys = frozenset({"state", "next_state", "probability"})
            _validate_exact_keys(transition, name=transition_name, expected=keys)
            state = _require_canonical_token(
                transition["state"], name=f"{transition_name}.state"
            )
            next_state = _require_canonical_token(
                transition["next_state"], name=f"{transition_name}.next_state"
            )
            if state not in state_set or next_state not in state_set:
                raise ValidationError(
                    f"{transition_name} references an unknown state",
                    context={"state": state, "next_state": next_state, "states": list(states)},
                )
            coordinate = (state, next_state)
            if coordinate in seen_transitions:
                raise ValidationError(
                    f"{source_name}.transitions contains duplicate coordinates",
                    context={
                        "coordinate": list(coordinate),
                        "first_index": seen_transitions[coordinate],
                        "duplicate_index": transition_index,
                    },
                )
            seen_transitions[coordinate] = transition_index
            row_probabilities[state].append(
                _validate_probability(
                    transition["probability"],
                    name=f"{transition_name}.probability",
                    upper_inclusive=True,
                )
            )
        for state in states:
            if state not in row_probabilities:
                raise ValidationError(
                    f"{source_name}.transitions is missing an outgoing row",
                    context={"state": state},
                )
            _validate_probability_mass(
                sum((Fraction(value) for value in row_probabilities[state]), Fraction(0)),
                name=f"{source_name}.transitions outgoing mass for state '{state}'",
            )

        _validate_pmf_rows(
            source["destination_pmf"],
            name=f"{source_name}.destination_pmf",
            coordinate_fields=("queue_id",),
            switch=switch,
        )


def _validate_shared_markov_params(
    params: Mapping[str, Any], switch: SwitchConfig
) -> None:
    top_keys = frozenset({"sources", "states", "initial", "outcomes"})
    _validate_exact_keys(params, name="arrival.params", expected=top_keys)
    sources = _require_count_sequence(params["sources"], name="arrival.sources")
    source_ids = _validate_source_ids(sources, id_only=True)
    source_set = frozenset(source_ids)
    states = _validate_states(params["states"], name="arrival.states")
    state_set = frozenset(states)
    _validate_count_initial(params["initial"], states=states, name="arrival.initial")

    outcomes = _require_count_sequence(params["outcomes"], name="arrival.outcomes")
    if not outcomes:
        raise ValidationError("arrival.outcomes must not be empty")
    row_probabilities: dict[str, list[Decimal]] = defaultdict(list)
    seen_outcomes: dict[tuple[Any, ...], int] = {}
    for outcome_index, outcome_raw in enumerate(outcomes):
        outcome_name = f"arrival.outcomes[{outcome_index}]"
        outcome = _require_count_mapping(outcome_raw, name=outcome_name)
        outcome_keys = frozenset({"state", "next_state", "probability", "emissions"})
        _validate_exact_keys(outcome, name=outcome_name, expected=outcome_keys)
        state = _require_canonical_token(outcome["state"], name=f"{outcome_name}.state")
        next_state = _require_canonical_token(
            outcome["next_state"], name=f"{outcome_name}.next_state"
        )
        if state not in state_set or next_state not in state_set:
            raise ValidationError(
                f"{outcome_name} references an unknown state",
                context={"state": state, "next_state": next_state, "states": list(states)},
            )
        probability = _validate_probability(
            outcome["probability"],
            name=f"{outcome_name}.probability",
            upper_inclusive=True,
        )
        row_probabilities[state].append(probability)

        emissions = _require_count_sequence(
            outcome["emissions"], name=f"{outcome_name}.emissions"
        )
        seen_sources: dict[str, int] = {}
        emission_coordinate_by_source: dict[str, tuple[int, Any]] = {}
        for emission_index, emission_raw in enumerate(emissions):
            emission_name = f"{outcome_name}.emissions[{emission_index}]"
            emission = _require_count_mapping(emission_raw, name=emission_name)
            emission_keys = frozenset({"source_id", "d", "queue_id"})
            _validate_exact_keys(emission, name=emission_name, expected=emission_keys)
            source_id = _require_canonical_token(
                emission["source_id"], name=f"{emission_name}.source_id"
            )
            if source_id not in source_set:
                raise ValidationError(
                    f"{emission_name}.source_id references an unknown source",
                    context={"source_id": source_id, "source_ids": list(source_ids)},
                )
            if source_id in seen_sources:
                raise ValidationError(
                    f"{outcome_name}.emissions contains a duplicate source",
                    context={
                        "source_id": source_id,
                        "first_index": seen_sources[source_id],
                        "duplicate_index": emission_index,
                    },
                )
            seen_sources[source_id] = emission_index
            d = _validate_int(emission["d"], name=f"{emission_name}.d", minimum=1)
            queue_id = _validate_queue_id_in_catalog(
                emission["queue_id"], switch=switch, name=f"{emission_name}.queue_id"
            )
            emission_coordinate_by_source[source_id] = (d, queue_id)
        missing_sources = [source_id for source_id in source_ids if source_id not in seen_sources]
        if missing_sources:
            raise ValidationError(
                f"{outcome_name}.emissions must define every source exactly once",
                context={"missing_source_ids": missing_sources},
            )
        coordinate = (
            state,
            next_state,
            tuple(emission_coordinate_by_source[source_id] for source_id in source_ids),
        )
        if coordinate in seen_outcomes:
            raise ValidationError(
                "arrival.outcomes contains duplicate outcome coordinates",
                context={
                    "first_index": seen_outcomes[coordinate],
                    "duplicate_index": outcome_index,
                },
            )
        seen_outcomes[coordinate] = outcome_index

    for state in states:
        if state not in row_probabilities:
            raise ValidationError(
                "arrival.outcomes is missing a current-state row",
                context={"state": state},
            )
        _validate_probability_mass(
            sum((Fraction(value) for value in row_probabilities[state]), Fraction(0)),
            name=f"arrival.outcomes outgoing mass for state '{state}'",
        )


def _validate_rate_params(
    params: Mapping[str, Any],
    switch: SwitchConfig,
    *,
    bernoulli: bool,
) -> None:
    _validate_exact_keys(params, name="arrival.params", expected=frozenset({"rates"}))
    rates = _require_count_mapping(params["rates"], name="arrival.rates")
    _validate_exact_keys(rates, name="arrival.rates", expected=frozenset({"default", "overrides"}))
    upper = Decimal(1) if bernoulli else None
    _validate_decimal(rates["default"], name="arrival.rates.default", minimum=Decimal(0), maximum=upper)
    overrides = _require_count_sequence(rates["overrides"], name="arrival.rates.overrides")
    seen: dict[QueueId, int] = {}
    for index, raw_override in enumerate(overrides):
        name = f"arrival.rates.overrides[{index}]"
        override = _require_count_mapping(raw_override, name=name)
        _validate_exact_keys(override, name=name, expected=frozenset({"queue_id", "rate"}))
        queue_id = _validate_queue_id_in_catalog(
            override["queue_id"], switch=switch, name=f"{name}.queue_id"
        )
        if queue_id in seen:
            raise ValidationError(
                "arrival.rates.overrides contains a duplicate queue_id",
                context={"queue_id": queue_id, "first_index": seen[queue_id], "duplicate_index": index},
            )
        seen[queue_id] = index
        _validate_decimal(
            override["rate"], name=f"{name}.rate", minimum=Decimal(0), maximum=upper
        )


def _validate_sparse_count_rows(raw: Any, switch: SwitchConfig, *, name: str) -> None:
    rows = _require_count_sequence(raw, name=name)
    seen: dict[QueueId, int] = {}
    for index, raw_row in enumerate(rows):
        row_name = f"{name}[{index}]"
        row = _require_count_mapping(raw_row, name=row_name)
        _validate_exact_keys(row, name=row_name, expected=frozenset({"queue_id", "count"}))
        queue_id = _validate_queue_id_in_catalog(row["queue_id"], switch=switch, name=f"{row_name}.queue_id")
        if queue_id in seen:
            raise ValidationError(
                f"{name} contains a duplicate queue_id",
                context={"queue_id": queue_id, "first_index": seen[queue_id], "duplicate_index": index},
            )
        seen[queue_id] = index
        _validate_count(row["count"], name=f"{row_name}.count")


def _validate_finite_count_params(
    params: Mapping[str, Any],
    switch: SwitchConfig,
    *,
    markov: bool,
) -> None:
    outcomes = _require_count_sequence(params["outcomes"], name="arrival.outcomes")
    for index, raw_outcome in enumerate(outcomes):
        outcome = _require_count_mapping(raw_outcome, name=f"arrival.outcomes[{index}]")
        _validate_sparse_count_rows(
            outcome["counts"], switch, name=f"arrival.outcomes[{index}].counts"
        )


def _validate_mixed_poisson_params(params: Mapping[str, Any], switch: SwitchConfig) -> None:
    _validate_exact_keys(
        params,
        name="arrival.params",
        expected=frozenset({"rates", "modulation"}),
    )
    _validate_rate_params({"rates": params["rates"]}, switch, bernoulli=False)
    modulation = _require_count_mapping(params["modulation"], name="arrival.modulation")
    _validate_exact_keys(
        modulation,
        name="arrival.modulation",
        expected=frozenset({"scope", "states", "mean_multiplier", "second_moment_multiplier"}),
    )
    _validate_name(
        modulation["scope"],
        name="arrival.modulation.scope",
        allowed=frozenset({"independent_queue", "shared"}),
    )
    states = _require_count_sequence(modulation["states"], name="arrival.modulation.states")
    if not states:
        raise ValidationError("arrival.modulation.states must not be empty")
    total_probability = Fraction(0)
    mean = Fraction(0)
    second_moment = Fraction(0)
    seen_ids: set[str] = set()
    for index, raw_state in enumerate(states):
        name = f"arrival.modulation.states[{index}]"
        state = _require_count_mapping(raw_state, name=name)
        _validate_exact_keys(state, name=name, expected=frozenset({"id", "probability", "multiplier"}))
        state_id = _require_canonical_token(state["id"], name=f"{name}.id")
        if state_id in seen_ids:
            raise ValidationError("arrival.modulation.states contains duplicate IDs", context={"id": state_id})
        seen_ids.add(state_id)
        probability = _validate_probability(state["probability"], name=f"{name}.probability")
        multiplier = _validate_decimal(state["multiplier"], name=f"{name}.multiplier", minimum=Decimal(0))
        exact_probability = Fraction(probability)
        exact_multiplier = Fraction(multiplier)
        total_probability += exact_probability
        mean += exact_probability * exact_multiplier
        second_moment += exact_probability * exact_multiplier * exact_multiplier
    _validate_probability_mass(total_probability, name="arrival.modulation probabilities")
    if mean != 1:
        raise ValidationError("arrival.modulation must satisfy E[M] == 1 exactly", context={"mean": str(mean)})
    configured_mean = _validate_decimal(modulation["mean_multiplier"], name="arrival.modulation.mean_multiplier")
    configured_second = _validate_decimal(
        modulation["second_moment_multiplier"], name="arrival.modulation.second_moment_multiplier"
    )
    if Fraction(configured_mean) != mean or Fraction(configured_second) != second_moment:
        raise ValidationError(
            "arrival.modulation derived moments do not match its states",
            context={
                "mean_multiplier": str(configured_mean),
                "expected_mean": str(mean),
                "second_moment_multiplier": str(configured_second),
                "expected_second_moment": str(second_moment),
            },
        )


def validate_count_arrival_config(arrival: ArrivalConfig, switch: SwitchConfig) -> None:
    """Validate one canonical queue-addressed arrival-law configuration."""

    stale: list[str] = []
    if arrival.allowed_edges != AllowedEdgesConfig():
        stale.append("allowed_edges")
    if arrival.alphabet_constraint != "unrestricted":
        stale.append("alphabet_constraint")
    for field_name in (
        "alphabet",
        "states",
        "kernel",
        "initial",
        "lambda_default",
        "lambda_overrides",
    ):
        if getattr(arrival, field_name) not in (None, (), {}, []):
            stale.append(field_name)
    if stale:
        raise ValidationError(
            "Queue-addressed arrival families must not use legacy binary arrival fields",
            context={"family": arrival.family, "stale_fields": sorted(stale)},
        )

    params = _require_count_mapping(arrival.params, name="arrival.params")
    try:
        reparsed = parse_count_arrival_params(
            arrival.family,
            {"family": arrival.family, **dict(params)},
        )
    except ConfigError as exc:
        raise ValidationError(
            "ArrivalConfig.params does not satisfy the canonical family schema",
            context={"family": arrival.family, **dict(getattr(exc, "context", {}) or {})},
        ) from exc
    if reparsed != dict(params):
        raise ValidationError(
            "ArrivalConfig.params must use canonical ordering and representation",
            context={"family": arrival.family},
        )

    if arrival.family == "iid_independent_bernoulli":
        _validate_rate_params(params, switch, bernoulli=True)
    elif arrival.family == "iid_independent_poisson":
        _validate_rate_params(params, switch, bernoulli=False)
    elif arrival.family == "iid_mixed_poisson":
        _validate_mixed_poisson_params(params, switch)
    elif arrival.family == "iid_count_table":
        _validate_finite_count_params(params, switch, markov=False)
    elif arrival.family == "markov_count_kernel":
        _validate_finite_count_params(params, switch, markov=True)
    elif arrival.family == "deterministic_trace":
        _validate_trace_params(params, switch)
    elif arrival.family == "periodic_global_phase":
        _validate_periodic_params(params, switch, delayed=False)
    elif arrival.family == "periodic_source_delays":
        _validate_periodic_params(params, switch, delayed=True)
    elif arrival.family == "independent_marked_renewal":
        _validate_independent_renewal_params(params, switch)
    elif arrival.family == "independent_private_markov_renewal":
        _validate_private_markov_params(params, switch)
    elif arrival.family == "shared_joint_round_markov_renewal":
        _validate_shared_markov_params(params, switch)
    else:  # pragma: no cover - caller validates the family first
        raise ValidationError("Unsupported count-valued arrival family", context={"family": arrival.family})


def validate_arrival_config(arrival: ArrivalConfig, switch: SwitchConfig) -> None:
    """Validate a canonical schema-4 queue-count arrival configuration."""

    _validate_name(arrival.family, name="arrival.family", allowed=SUPPORTED_ARRIVAL_FAMILIES)
    _validate_json_mapping(arrival.metadata, name="arrival.metadata")

    validate_count_arrival_config(arrival, switch)


def validate_flow_plan_unique_voqs(flow_specs: Iterable[Any]) -> None:
    """Reject duplicate ``(src_port, dst_port)`` assignments in a static edge-to-flow-id catalog."""

    seen: dict[tuple[int, int], int] = {}
    for index, spec in enumerate(flow_specs):
        if isinstance(spec, Mapping):
            src_port = spec.get("src_port")
            dst_port = spec.get("dst_port")
        else:
            src_port = getattr(spec, "src_port", None)
            dst_port = getattr(spec, "dst_port", None)

        src = _validate_int(src_port, name=f"flow_specs[{index}].src_port", minimum=0)
        dst = _validate_int(dst_port, name=f"flow_specs[{index}].dst_port", minimum=0)
        key = (src, dst)
        if key in seen:
            raise ValidationError(
                "Flow plan contains duplicate VOQ assignments",
                context={"voq_key": key, "first_index": seen[key], "duplicate_index": index},
            )
        seen[key] = index


def validate_config(config: SimConfig) -> SimConfig:
    """Validate a resolved simulator config and return it unchanged on success."""

    if not isinstance(config, SimConfig):
        raise ValidationError(
            "config must be an instance of SimConfig",
            context={"value_type": type(config).__name__},
        )

    _validate_config_schema_version(config.schema_version)
    _validate_run_config(config.run)
    _validate_switch_config(config.switch)
    bound_scheduler = _validate_scheduler_config(config.scheduler, switch=config.switch)
    validate_arrival_config(config.arrival, config.switch)
    _validate_telemetry_config(config.telemetry, config.switch, bound_scheduler)
    _validate_json_mapping(config.metadata, name="metadata")
    return config


__all__ = [
    "SUPPORTED_SCHEDULERS",
    "SUPPORTED_TERMINATION_MODES",
    "SUPPORTED_ARRIVAL_FAMILIES",
    "SUPPORTED_ALLOWED_EDGE_MODES",
    "SUPPORTED_ALPHABET_CONSTRAINTS",
    "SUPPORTED_INITIAL_MODES",
    "SUPPORTED_TELEMETRY_FORMATS",
    "SUPPORTED_QUEUE_SNAPSHOT_MODES",
    "validate_seed",
    "validate_actual_seed",
    "validate_scheduler_name",
    "validate_allowed_edges_config",
    "validate_mask_edges",
    "validate_iid_table_arrival",
    "validate_markov_kernel_arrival",
    "validate_factorized_bernoulli_arrival",
    "validate_count_arrival_config",
    "validate_arrival_config",
    "validate_flow_plan_unique_voqs",
    "validate_config",
]
