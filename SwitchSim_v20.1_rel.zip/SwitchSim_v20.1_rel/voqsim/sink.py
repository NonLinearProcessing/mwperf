"""Topology-neutral packet completion sink."""

from __future__ import annotations

from dataclasses import dataclass
from numbers import Integral
from typing import Any, Iterable

from .errors import ValidationError
from .events import CompletionEvent, DepartureEvent
from .types import Slot


def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": result})
    return result


def _validate_departure_event(value: Any, *, index: int | None = None) -> DepartureEvent:
    if not isinstance(value, DepartureEvent):
        context: dict[str, Any] = {"value_type": type(value).__name__}
        if index is not None:
            context["index"] = index
        raise ValidationError(
            "departure must be a DepartureEvent instance",
            context=context,
        )
    return value


@dataclass(slots=True, frozen=True)
class CompletionSink:
    """Validate one-slot departure batches and stamp packet completion."""

    def accept_departure(self, departure: DepartureEvent) -> CompletionEvent:
        return CompletionEvent.from_departure(_validate_departure_event(departure))

    def accept_departures(
        self,
        departures: Iterable[DepartureEvent],
        *,
        slot: Slot | None = None,
    ) -> tuple[CompletionEvent, ...]:
        canonical_departures = tuple(
            _validate_departure_event(departure, index=index)
            for index, departure in enumerate(departures)
        )
        expected_slot = (
            None if slot is None else _validate_non_negative_int(slot, name="slot")
        )
        derived_slot: int | None = None
        completions: list[CompletionEvent] = []
        for departure in canonical_departures:
            if derived_slot is None:
                derived_slot = departure.slot
            elif departure.slot != derived_slot:
                raise ValidationError(
                    "CompletionSink.accept_departures can only process one slot at a time",
                    context={
                        "expected_slot": derived_slot,
                        "departure_slot": departure.slot,
                        "packet_id": departure.packet_id,
                    },
                )
            if expected_slot is not None and departure.slot != expected_slot:
                raise ValidationError(
                    "slot does not match the departure batch",
                    context={
                        "slot": expected_slot,
                        "departure_slot": departure.slot,
                        "packet_id": departure.packet_id,
                    },
                )
            completions.append(self.accept_departure(departure))
        # QueueBank emits catalog order; preserve positional correspondence.
        return tuple(completions)


__all__ = ["CompletionSink"]
