from __future__ import annotations

from collections import Counter
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from numbers import Integral, Real
from typing import Any, TypeAlias

import numpy as np

from .errors import ValidationError
from .telemetry.generic import (
    GenericSlotRecord,
    coerce_queue_vector,
    deserialize_queue_vector_snapshot,
    queue_ids_from_catalog,
    queue_index,
)
from .types import JSONValue
from .utils import normalize_for_json

GENERIC_RUN_SUMMARY_VERSION = "3.0.0"

_GenericBacklogMap: TypeAlias = dict[tuple[int, int], int]


def _exact_zeros(shape: int | tuple[int, ...]) -> np.ndarray:
    """Return an array of arbitrary-precision Python integer zeroes."""

    return np.zeros(shape, dtype=object)


def _exact_array_sum(values: np.ndarray) -> int:
    """Sum an array without any fixed-width reduction."""

    return sum(int(value) for value in values.flat)


def _increment_sparse(target: dict[Any, int], key: Any, value: int = 1) -> None:
    increment = int(value)
    if increment:
        target[key] = target.get(key, 0) + increment


def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": coerced, "minimum": 0})
    return coerced


def _validate_real(value: Any, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValidationError(f"{name} must be a real number", context={"value": value})
    coerced = float(value)
    if not np.isfinite(coerced):
        raise ValidationError(f"{name} must be finite", context={"value": coerced})
    return coerced


def _normalize_metadata(value: Mapping[str, Any] | None) -> dict[str, JSONValue]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValidationError(
            "metadata must be a mapping",
            context={"value_type": type(value).__name__},
        )
    normalized: dict[str, JSONValue] = {}
    for raw_key, raw_value in value.items():
        if not isinstance(raw_key, str):
            raise ValidationError(
                "metadata keys must be strings",
                context={"key": raw_key, "key_type": type(raw_key).__name__},
            )
        normalized[raw_key] = normalize_for_json(raw_value)
    return dict(sorted(normalized.items()))


def _rate(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _count_backlog_level_entry(
    *,
    backlog: int,
    sample_count: int,
    service_packets: int,
    offered_packets: int,
    admitted_packets: int,
    dropped_packets: int,
    q_after_total: int | None,
    slots_observed: int,
) -> dict[str, JSONValue]:
    """Summarize count-valued arrivals conditioned on one backlog level.

    Arrival and admission multiplicities are counts rather than Bernoulli
    indicators, so their conditional means may legitimately exceed one.
    Service remains binary per queue and slot in the current queueing core.
    """

    mean_q_after = (
        None
        if sample_count <= 0 or q_after_total is None
        else float(q_after_total) / float(sample_count)
    )
    mean_delta = None if mean_q_after is None else mean_q_after - float(backlog)
    return {
        "backlog_packets": int(backlog),
        "queue_slot_samples": int(sample_count),
        "service_packets": int(service_packets),
        "mean_service_packets_per_sim_slot": _rate(int(service_packets), int(slots_observed)),
        "service_probability_given_backlog": _rate(int(service_packets), int(sample_count)),
        "offered_packets": int(offered_packets),
        "mean_offered_packets_per_sim_slot": _rate(int(offered_packets), int(slots_observed)),
        "mean_offered_packets_given_backlog": _rate(int(offered_packets), int(sample_count)),
        "admitted_packets": int(admitted_packets),
        "mean_admitted_packets_per_sim_slot": _rate(int(admitted_packets), int(slots_observed)),
        "mean_admitted_packets_given_backlog": _rate(int(admitted_packets), int(sample_count)),
        "dropped_packets": int(dropped_packets),
        "mean_dropped_packets_per_sim_slot": _rate(int(dropped_packets), int(slots_observed)),
        "mean_dropped_packets_given_backlog": _rate(int(dropped_packets), int(sample_count)),
        "drop_fraction_of_offered_given_backlog": _rate(int(dropped_packets), int(offered_packets)),
        "mean_q_after_packets": mean_q_after,
        "mean_delta_q_packets": mean_delta,
    }


def _nearest_rank_percentile_from_counter(counter: Mapping[int, int], *, q: float) -> int | None:
    if not 0.0 < float(q) <= 1.0:
        raise ValidationError("q must lie in the interval (0, 1]", context={"q": q})
    total = sum(int(count) for count in counter.values())
    if total <= 0:
        return None
    rank = max(1, int(np.ceil(float(q) * float(total))))
    cumulative = 0
    for value, count in sorted((int(value), int(count)) for value, count in counter.items() if int(count) > 0):
        cumulative += count
        if cumulative >= rank:
            return value
    return None


@dataclass(slots=True)
class ExactDiscreteTracker:
    """Exact histogram-backed tracker for non-negative discrete metrics."""

    count: int = 0
    total: int = 0
    minimum: int | None = None
    maximum: int | None = None
    _counter: Counter[int] = field(default_factory=Counter, init=False, repr=False)

    def __post_init__(self) -> None:
        self.count = _validate_non_negative_int(self.count, name="count")
        self.total = _validate_non_negative_int(self.total, name="total")
        if self.count == 0:
            self.minimum = None
            self.maximum = None
            if self.total != 0:
                raise ValidationError("total must be zero when count is zero", context={"total": self.total})
            return
        if self.minimum is None or self.maximum is None:
            raise ValidationError("minimum and maximum are required when count > 0")
        self.minimum = _validate_non_negative_int(self.minimum, name="minimum")
        self.maximum = _validate_non_negative_int(self.maximum, name="maximum")

    @property
    def mean_or_none(self) -> float | None:
        if self.count == 0:
            return None
        return float(self.total) / float(self.count)

    def update(self, value: Any) -> None:
        observation = _validate_non_negative_int(value, name="value")
        self.count += 1
        self.total += observation
        self.minimum = observation if self.minimum is None else min(self.minimum, observation)
        self.maximum = observation if self.maximum is None else max(self.maximum, observation)
        self._counter[observation] += 1

    def percentile(self, q: float) -> int | None:
        return _nearest_rank_percentile_from_counter(self._counter, q=q)

    def to_dict(self, *, include_p95: bool = True) -> dict[str, JSONValue]:
        payload: dict[str, JSONValue] = {
            "count": self.count,
            "mean": self.mean_or_none,
            "min": self.minimum,
            "max": self.maximum,
        }
        if include_p95:
            payload["p95"] = self.percentile(0.95)
        return payload


@dataclass(slots=True)
class OnlineDiscreteTracker:
    """Fixed-memory tracker for non-negative discrete metrics.

    Unlike :class:`ExactDiscreteTracker`, this deliberately retains no value
    histogram. It is used for MaxWeight objective values, whose cardinality can
    grow with queue lengths and therefore with the duration of an overloaded
    run. Count, exact integer total, extrema, and mean remain available in O(1)
    space.
    """

    count: int = 0
    total: int = 0
    minimum: int | None = None
    maximum: int | None = None

    def __post_init__(self) -> None:
        self.count = _validate_non_negative_int(self.count, name="count")
        self.total = _validate_non_negative_int(self.total, name="total")
        if self.count == 0:
            self.minimum = None
            self.maximum = None
            if self.total != 0:
                raise ValidationError("total must be zero when count is zero", context={"total": self.total})
            return
        if self.minimum is None or self.maximum is None:
            raise ValidationError("minimum and maximum are required when count > 0")
        self.minimum = _validate_non_negative_int(self.minimum, name="minimum")
        self.maximum = _validate_non_negative_int(self.maximum, name="maximum")

    @property
    def mean_or_none(self) -> float | None:
        return None if self.count == 0 else float(self.total) / float(self.count)

    def update(self, value: Any) -> None:
        observation = _validate_non_negative_int(value, name="value")
        self.count += 1
        self.total += observation
        self.minimum = observation if self.minimum is None else min(self.minimum, observation)
        self.maximum = observation if self.maximum is None else max(self.maximum, observation)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "count": self.count,
            "mean": self.mean_or_none,
            "min": self.minimum,
            "max": self.maximum,
        }


@dataclass(slots=True)
class OnlineMoments:
    """Online mean / variance tracker using Welford's recurrence."""

    count: int = 0
    mean: float = 0.0
    _m2: float = field(default=0.0, init=False, repr=False)
    minimum: float | None = None
    maximum: float | None = None

    def __post_init__(self) -> None:
        self.count = _validate_non_negative_int(self.count, name="count")
        if self.count == 0:
            self.mean = 0.0
            if self.minimum is not None or self.maximum is not None:
                raise ValidationError("minimum/maximum require at least one observation")
        else:
            self.mean = _validate_real(self.mean, name="mean")
            self.minimum = None if self.minimum is None else _validate_real(self.minimum, name="minimum")
            self.maximum = None if self.maximum is None else _validate_real(self.maximum, name="maximum")

    @property
    def variance(self) -> float | None:
        if self.count == 0:
            return None
        return self._m2 / float(self.count)

    @property
    def population_variance(self) -> float | None:
        return self.variance

    @property
    def sample_variance(self) -> float | None:
        if self.count == 0:
            return None
        if self.count == 1:
            return 0.0
        return self._m2 / float(self.count - 1)

    @property
    def mean_or_none(self) -> float | None:
        if self.count == 0:
            return None
        return self.mean

    @property
    def total(self) -> float:
        if self.count == 0:
            return 0.0
        return self.mean * float(self.count)

    def update(self, value: Any) -> None:
        observation = _validate_real(value, name="value")
        next_count = self.count + 1
        delta = observation - self.mean
        next_mean = observation if self.count == 0 else self.mean + delta / float(next_count)
        delta2 = observation - next_mean
        if self.count > 0:
            self._m2 += delta * delta2
        self.count = next_count
        self.mean = next_mean
        self.minimum = observation if self.minimum is None else min(self.minimum, observation)
        self.maximum = observation if self.maximum is None else max(self.maximum, observation)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "count": self.count,
            "mean": self.mean_or_none,
            "variance": self.variance,
            "sample_variance": self.sample_variance,
            "min": self.minimum,
            "max": self.maximum,
        }


@dataclass(slots=True, frozen=True)
class RunSummary(Mapping[str, JSONValue]):
    """Deterministic run summary that also behaves like a mapping."""

    metrics: Mapping[str, JSONValue] = field(default_factory=dict)
    metadata: Mapping[str, JSONValue] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "metrics", normalize_for_json(dict(self.metrics)))
        object.__setattr__(self, "metadata", normalize_for_json(dict(self.metadata)))

    def __getitem__(self, key: str) -> JSONValue:
        if key == "metrics":
            return self.metrics
        if key == "metadata":
            return self.metadata
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        yield "metrics"
        yield "metadata"

    def __len__(self) -> int:
        return 2

    def to_dict(self) -> dict[str, JSONValue]:
        return {"metrics": self.metrics, "metadata": self.metadata}


@dataclass(slots=True)
class GenericRunStats:
    """Online statistics for topology-neutral queue-vector slot records.

    The generalized path deliberately reports no input/output utilization and
    no maximum-cardinality matching metric: neither object is defined for an
    arbitrary service constraint.  Scheduler-specific diagnostics remain on
    the slot record, while this accumulator tracks only universal quantities.
    """

    catalog: Any
    live_queue_ids: Iterable[Any] | None = None
    family: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    queue_capacity: int | None = None

    slots_observed: int = field(init=False, default=0)
    first_slot: int | None = field(init=False, default=None)
    last_slot: int | None = field(init=False, default=None)
    offered_packets: int = field(init=False, default=0)
    admitted_packets: int = field(init=False, default=0)
    dropped_packets: int = field(init=False, default=0)
    completed_packets: int = field(init=False, default=0)

    _queue_ids: tuple[Any, ...] = field(init=False, repr=False)
    _live_queue_ids: tuple[Any, ...] = field(init=False, repr=False)
    _live_indices: np.ndarray = field(init=False, repr=False)
    _live_index_set: frozenset[int] = field(init=False, repr=False)
    _metadata: dict[str, JSONValue] = field(init=False, repr=False)
    _offered_counts: np.ndarray = field(init=False, repr=False)
    _admitted_counts: np.ndarray = field(init=False, repr=False)
    _dropped_counts: np.ndarray = field(init=False, repr=False)
    _completed_counts: np.ndarray = field(init=False, repr=False)
    _served_counts: np.ndarray = field(init=False, repr=False)
    _q_before_sum: np.ndarray = field(init=False, repr=False)
    _q_after_sum: np.ndarray = field(init=False, repr=False)
    _q_before_max: np.ndarray = field(init=False, repr=False)
    _q_after_max: np.ndarray = field(init=False, repr=False)
    _q_before_samples: int = field(init=False, default=0, repr=False)
    _q_after_samples: int = field(init=False, default=0, repr=False)
    _hist_indices: np.ndarray = field(init=False, repr=False)
    _q_before_hist: _GenericBacklogMap | None = field(init=False, repr=False)
    _service_given_q_before: _GenericBacklogMap | None = field(init=False, repr=False)
    _offered_given_q_before: _GenericBacklogMap | None = field(init=False, repr=False)
    _admitted_given_q_before: _GenericBacklogMap | None = field(init=False, repr=False)
    _dropped_given_q_before: _GenericBacklogMap | None = field(init=False, repr=False)
    _q_after_sum_given_q_before: _GenericBacklogMap | None = field(init=False, repr=False)
    _selected_count: ExactDiscreteTracker = field(init=False, repr=False)
    _served_count: ExactDiscreteTracker = field(init=False, repr=False)
    _primary_weight: OnlineDiscreteTracker = field(init=False, repr=False)
    _sojourn: ExactDiscreteTracker = field(init=False, repr=False)
    _residence: ExactDiscreteTracker = field(init=False, repr=False)
    _queue_sojourn: dict[Any, ExactDiscreteTracker] = field(init=False, repr=False)
    _queue_residence: dict[Any, ExactDiscreteTracker] = field(init=False, repr=False)
    _drop_reasons: Counter[str] = field(init=False, repr=False)
    _scheduler_ids: Counter[str] = field(init=False, repr=False)
    _algorithm_ids: Counter[str] = field(init=False, repr=False)
    _optimizer_ids: Counter[str] = field(init=False, repr=False)
    _arrival_outcome_ids: Counter[str] = field(init=False, repr=False)
    _state_before_counts: Counter[str] = field(init=False, repr=False)
    _state_transition_counts: Counter[tuple[str, str]] = field(init=False, repr=False)
    _feasible_slots: int = field(init=False, default=0, repr=False)

    def __post_init__(self) -> None:
        queue_ids = queue_ids_from_catalog(self.catalog)
        family = self.family
        if family is not None:
            if not isinstance(family, str) or not family.strip():
                raise ValidationError("family must be a nonempty string or null")
            family = family.strip()
        capacity = self.queue_capacity
        if capacity is not None:
            capacity = _validate_non_negative_int(capacity, name="queue_capacity")
            if capacity < 1:
                raise ValidationError("queue_capacity must be >= 1")

        if self.live_queue_ids is None:
            live = queue_ids
        else:
            requested = tuple(self.live_queue_ids)
            if len(set(requested)) != len(requested):
                raise ValidationError("live_queue_ids must be unique")
            requested_set = set(requested)
            for queue_id in requested:
                queue_index(self.catalog, queue_id, name="live_queue_id")
            live = tuple(queue_id for queue_id in queue_ids if queue_id in requested_set)

        size = len(queue_ids)
        zeros = lambda: _exact_zeros(size)
        histogram = lambda: None if capacity is None else {}
        object.__setattr__(self, "family", family)
        object.__setattr__(self, "queue_capacity", capacity)
        object.__setattr__(self, "_queue_ids", queue_ids)
        object.__setattr__(self, "_live_queue_ids", live)
        live_indices = np.asarray([queue_index(self.catalog, queue_id) for queue_id in live], dtype=np.int64)
        object.__setattr__(self, "_live_indices", live_indices)
        object.__setattr__(self, "_live_index_set", frozenset(int(value) for value in live_indices.tolist()))
        object.__setattr__(self, "_metadata", _normalize_metadata(self.metadata))
        object.__setattr__(self, "_offered_counts", zeros())
        object.__setattr__(self, "_admitted_counts", zeros())
        object.__setattr__(self, "_dropped_counts", zeros())
        object.__setattr__(self, "_completed_counts", zeros())
        object.__setattr__(self, "_served_counts", zeros())
        object.__setattr__(self, "_q_before_sum", zeros())
        object.__setattr__(self, "_q_after_sum", zeros())
        object.__setattr__(self, "_q_before_max", zeros())
        object.__setattr__(self, "_q_after_max", zeros())
        object.__setattr__(self, "_hist_indices", np.arange(size, dtype=np.int64))
        object.__setattr__(self, "_q_before_hist", histogram())
        object.__setattr__(self, "_service_given_q_before", histogram())
        object.__setattr__(self, "_offered_given_q_before", histogram())
        object.__setattr__(self, "_admitted_given_q_before", histogram())
        object.__setattr__(self, "_dropped_given_q_before", histogram())
        object.__setattr__(self, "_q_after_sum_given_q_before", histogram())
        object.__setattr__(self, "_selected_count", ExactDiscreteTracker())
        object.__setattr__(self, "_served_count", ExactDiscreteTracker())
        object.__setattr__(self, "_primary_weight", OnlineDiscreteTracker())
        object.__setattr__(self, "_sojourn", ExactDiscreteTracker())
        object.__setattr__(self, "_residence", ExactDiscreteTracker())
        object.__setattr__(self, "_queue_sojourn", {})
        object.__setattr__(self, "_queue_residence", {})
        object.__setattr__(self, "_drop_reasons", Counter())
        object.__setattr__(self, "_scheduler_ids", Counter())
        object.__setattr__(self, "_algorithm_ids", Counter())
        object.__setattr__(self, "_optimizer_ids", Counter())
        object.__setattr__(self, "_arrival_outcome_ids", Counter())
        object.__setattr__(self, "_state_before_counts", Counter())
        object.__setattr__(self, "_state_transition_counts", Counter())

    @classmethod
    def from_catalog(
        cls,
        catalog: Any,
        *,
        live_queue_ids: Iterable[Any] | None = None,
        family: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        queue_capacity: int | None = None,
    ) -> "GenericRunStats":
        return cls(
            catalog=catalog,
            live_queue_ids=live_queue_ids,
            family=family,
            metadata={} if metadata is None else metadata,
            queue_capacity=queue_capacity,
        )

    def _validate_record(self, record: GenericSlotRecord) -> None:
        if not isinstance(record, GenericSlotRecord):
            raise ValidationError(
                "record must be a GenericSlotRecord",
                context={"value_type": type(record).__name__},
            )
        if queue_ids_from_catalog(record.catalog) != self._queue_ids:
            raise ValidationError("record catalog does not match GenericRunStats catalog")
        if self.last_slot is not None and record.slot <= self.last_slot:
            raise ValidationError(
                "GenericRunStats expects records in strictly increasing slot order",
                context={"last_slot": self.last_slot, "slot": record.slot},
            )

    def _increment_mapping(self, target: np.ndarray, counts: Mapping[Any, int]) -> None:
        for queue_id, count in counts.items():
            target[queue_index(self.catalog, queue_id)] += int(count)

    def _increment_conditioned_mapping(
        self,
        target: _GenericBacklogMap,
        counts: Mapping[Any, int],
        q_before: np.ndarray,
    ) -> None:
        for queue_id, count in counts.items():
            index = queue_index(self.catalog, queue_id)
            _increment_sparse(target, (index, int(q_before[index])), int(count))

    def _update_backlog_conditioned_metrics(
        self,
        *,
        record: GenericSlotRecord,
        q_before: np.ndarray | None,
        q_after: np.ndarray | None,
    ) -> None:
        if (
            q_before is None
            or self._q_before_hist is None
            or self._service_given_q_before is None
            or self._offered_given_q_before is None
            or self._admitted_given_q_before is None
            or self._dropped_given_q_before is None
        ):
            return

        for index, raw_backlog in enumerate(q_before):
            _increment_sparse(self._q_before_hist, (index, int(raw_backlog)))
        self._increment_conditioned_mapping(self._service_given_q_before, record.served_by_queue, q_before)
        self._increment_conditioned_mapping(self._offered_given_q_before, record.offered_by_queue, q_before)
        self._increment_conditioned_mapping(self._admitted_given_q_before, record.admitted_by_queue, q_before)
        self._increment_conditioned_mapping(self._dropped_given_q_before, record.dropped_by_queue, q_before)
        if q_after is not None and self._q_after_sum_given_q_before is not None:
            for index, raw_backlog in enumerate(q_before):
                _increment_sparse(
                    self._q_after_sum_given_q_before,
                    (index, int(raw_backlog)),
                    int(q_after[index]),
                )

    @staticmethod
    def _tracker(store: dict[Any, ExactDiscreteTracker], key: Any) -> ExactDiscreteTracker:
        tracker = store.get(key)
        if tracker is None:
            tracker = ExactDiscreteTracker()
            store[key] = tracker
        return tracker

    def update(
        self,
        record: GenericSlotRecord,
        q_before_vector: Any | None = None,
        q_after_vector: Any | None = None,
    ) -> "GenericRunStats":
        self._validate_record(record)
        q_before = (
            deserialize_queue_vector_snapshot(record.q_before, catalog=self.catalog, name="q_before")
            if q_before_vector is None
            else coerce_queue_vector(
                q_before_vector,
                catalog=self.catalog,
                name="q_before_vector",
                copy=False,
            )
        )
        q_after = (
            deserialize_queue_vector_snapshot(record.q_after, catalog=self.catalog, name="q_after")
            if q_after_vector is None
            else coerce_queue_vector(
                q_after_vector,
                catalog=self.catalog,
                name="q_after_vector",
                copy=False,
            )
        )

        if self.first_slot is None:
            self.first_slot = record.slot
        self.last_slot = record.slot
        self.slots_observed += 1
        self.offered_packets += record.offered_count
        self.admitted_packets += record.admitted_count
        self.dropped_packets += record.loss_count
        self.completed_packets += len(record.completions)

        self._increment_mapping(self._offered_counts, record.offered_by_queue)
        self._increment_mapping(self._admitted_counts, record.admitted_by_queue)
        self._increment_mapping(self._dropped_counts, record.dropped_by_queue)
        self._increment_mapping(self._served_counts, record.served_by_queue)
        for completion in record.completions:
            index = queue_index(self.catalog, completion.queue_id)
            self._completed_counts[index] += 1
            sojourn = int(completion.sojourn_slots)
            residence = int(completion.residence_slots)
            self._sojourn.update(sojourn)
            self._residence.update(residence)
            self._tracker(self._queue_sojourn, completion.queue_id).update(sojourn)
            self._tracker(self._queue_residence, completion.queue_id).update(residence)

        if q_before is not None:
            self._q_before_sum += q_before
            self._q_before_max = np.maximum(self._q_before_max, q_before)
            self._q_before_samples += 1
            if self.queue_capacity is not None and np.any(q_before > self.queue_capacity):
                raise ValidationError(
                    "q_before exceeds queue_capacity",
                    context={"slot": record.slot, "queue_capacity": self.queue_capacity},
                )
        if q_after is not None:
            self._q_after_sum += q_after
            self._q_after_max = np.maximum(self._q_after_max, q_after)
            self._q_after_samples += 1
            if self.queue_capacity is not None and np.any(q_after > self.queue_capacity):
                raise ValidationError(
                    "q_after exceeds queue_capacity",
                    context={"slot": record.slot, "queue_capacity": self.queue_capacity},
                )

        self._update_backlog_conditioned_metrics(
            record=record,
            q_before=q_before,
            q_after=q_after,
        )

        self._selected_count.update(record.selected_count)
        self._served_count.update(record.served_count)
        self._primary_weight.update(record.primary_weight)
        feasible = record.schedule_metrics.get("feasible")
        if feasible is not True:
            raise ValidationError(
                "GenericRunStats only accepts feasibility-validated service decisions",
                context={"slot": record.slot, "feasible": feasible},
            )
        self._feasible_slots += 1
        if record.scheduler_id is not None:
            self._scheduler_ids[record.scheduler_id] += 1
        self._algorithm_ids[record.algorithm_id] += 1
        if record.optimizer_id is not None:
            self._optimizer_ids[record.optimizer_id] += 1
        if record.arrival_outcome_id is not None:
            self._arrival_outcome_ids[record.arrival_outcome_id] += 1
        for decision in record.admissions:
            if not decision.accepted:
                self._drop_reasons[decision.reason] += 1

        before = record.arrival_state_before
        after = record.arrival_state_after
        if before is not None and after is not None:
            self._state_before_counts[before] += 1
            self._state_transition_counts[(before, after)] += 1
        return self

    def update_many(self, records: Iterable[GenericSlotRecord]) -> "GenericRunStats":
        for record in records:
            self.update(record)
        return self

    @staticmethod
    def _queue_backlog_counter(
        histogram: _GenericBacklogMap | None,
        index: int,
    ) -> Counter[int] | None:
        if histogram is None:
            return None
        return Counter(
            {
                backlog: int(value)
                for (queue_index_value, backlog), value in histogram.items()
                if queue_index_value == index and int(value) != 0
            }
        )

    def _sum_live_backlog_histogram(
        self,
        histogram: _GenericBacklogMap | None,
    ) -> Counter[int] | None:
        if histogram is None:
            return None
        result: Counter[int] = Counter()
        live = self._live_index_set
        for (index, backlog), value in histogram.items():
            if index in live:
                result[int(backlog)] += int(value)
        return result

    def _backlog_level_entries(
        self,
        *,
        sample_counts: Mapping[int, int],
        service_counts: Mapping[int, int],
        offered_counts: Mapping[int, int],
        admitted_counts: Mapping[int, int],
        dropped_counts: Mapping[int, int],
        q_after_totals: Mapping[int, int] | None,
    ) -> list[dict[str, JSONValue]]:
        entries: list[dict[str, JSONValue]] = []
        for backlog in sorted(int(value) for value in sample_counts):
            raw_sample_count = sample_counts[backlog]
            sample_count = int(raw_sample_count)
            if sample_count <= 0:
                continue
            q_after_total = None if q_after_totals is None else int(q_after_totals.get(backlog, 0))
            entries.append(
                _count_backlog_level_entry(
                    backlog=backlog,
                    sample_count=sample_count,
                    service_packets=int(service_counts.get(backlog, 0)),
                    offered_packets=int(offered_counts.get(backlog, 0)),
                    admitted_packets=int(admitted_counts.get(backlog, 0)),
                    dropped_packets=int(dropped_counts.get(backlog, 0)),
                    q_after_total=q_after_total,
                    slots_observed=self.slots_observed,
                )
            )
        return entries

    def _queue_backlog_levels_q_before(self, index: int) -> list[dict[str, JSONValue]]:
        if index not in self._live_index_set:
            return []
        if (
            self._q_before_hist is None
            or self._service_given_q_before is None
            or self._offered_given_q_before is None
            or self._admitted_given_q_before is None
            or self._dropped_given_q_before is None
        ):
            return []
        q_after_totals = (
            self._queue_backlog_counter(self._q_after_sum_given_q_before, index)
            if self._q_after_samples == self._q_before_samples
            else None
        )
        return self._backlog_level_entries(
            sample_counts=self._queue_backlog_counter(self._q_before_hist, index) or {},
            service_counts=self._queue_backlog_counter(self._service_given_q_before, index) or {},
            offered_counts=self._queue_backlog_counter(self._offered_given_q_before, index) or {},
            admitted_counts=self._queue_backlog_counter(self._admitted_given_q_before, index) or {},
            dropped_counts=self._queue_backlog_counter(self._dropped_given_q_before, index) or {},
            q_after_totals=q_after_totals,
        )

    def _queue_backlog_levels_summary(self) -> dict[str, JSONValue]:
        if (
            self._q_before_hist is None
            or self._service_given_q_before is None
            or self._offered_given_q_before is None
            or self._admitted_given_q_before is None
            or self._dropped_given_q_before is None
        ):
            overall: list[dict[str, JSONValue]] = []
        else:
            q_after_totals = (
                self._sum_live_backlog_histogram(self._q_after_sum_given_q_before)
                if self._q_after_samples == self._q_before_samples
                else None
            )
            overall = self._backlog_level_entries(
                sample_counts=self._sum_live_backlog_histogram(self._q_before_hist),
                service_counts=self._sum_live_backlog_histogram(self._service_given_q_before),
                offered_counts=self._sum_live_backlog_histogram(self._offered_given_q_before),
                admitted_counts=self._sum_live_backlog_histogram(self._admitted_given_q_before),
                dropped_counts=self._sum_live_backlog_histogram(self._dropped_given_q_before),
                q_after_totals=q_after_totals,
            )

        return {
            "sample_point": "q_before",
            "conditioned_on": "start_of_slot_queue_length_packets",
            "collection_status": (
                "complete"
                if self._q_before_hist is not None
                else "not_collected_use_selected_target_observation"
            ),
            "queue_set": "live_queues",
            "capacity_packets": self.queue_capacity,
            "live_queue_count": len(self._live_queue_ids),
            "overall_sample_basis": "live_queue_slots",
            "overall_total_queue_slot_samples": self.slots_observed * len(self._live_queue_ids),
            "per_queue_sample_basis": "one_queue_per_sim_slot",
            "overall": overall,
        }

    def _mean_queue_occupancy(self, index: int, *, after: bool) -> float | None:
        samples = self._q_after_samples if after else self._q_before_samples
        if samples <= 0:
            return None
        totals = self._q_after_sum if after else self._q_before_sum
        return float(totals[index]) / float(samples)

    def _utilization(self, value: float | int | None) -> float | None:
        if value is None or self.queue_capacity is None:
            return None
        return float(value) / float(self.queue_capacity)

    def _per_queue_summary(self) -> list[dict[str, JSONValue]]:
        entries: list[dict[str, JSONValue]] = []
        for index, queue_id in enumerate(self._queue_ids):
            offered = int(self._offered_counts[index])
            admitted = int(self._admitted_counts[index])
            dropped = int(self._dropped_counts[index])
            completed = int(self._completed_counts[index])
            served = int(self._served_counts[index])
            mean_before = self._mean_queue_occupancy(index, after=False)
            mean_after = self._mean_queue_occupancy(index, after=True)
            queue_sojourn = self._queue_sojourn.get(queue_id, ExactDiscreteTracker())
            queue_residence = self._queue_residence.get(queue_id, ExactDiscreteTracker())
            entries.append(
                {
                    "queue_id": queue_id,
                    "offered_packets": offered,
                    "admitted_packets": admitted,
                    "dropped_packets": dropped,
                    "served_packets": served,
                    "completed_packets": completed,
                    "offered_rate": _rate(offered, self.slots_observed),
                    "admitted_rate": _rate(admitted, self.slots_observed),
                    "drop_rate": _rate(dropped, self.slots_observed),
                    "service_rate": _rate(served, self.slots_observed),
                    "completion_rate": _rate(completed, self.slots_observed),
                    "drop_fraction_of_offered": _rate(dropped, offered),
                    "mean_occupancy_q_before": mean_before,
                    "mean_occupancy_q_after": mean_after,
                    "max_occupancy_q_before": None if self._q_before_samples == 0 else int(self._q_before_max[index]),
                    "max_occupancy_q_after": None if self._q_after_samples == 0 else int(self._q_after_max[index]),
                    "capacity_packets": self.queue_capacity,
                    "mean_utilization_q_before": self._utilization(mean_before),
                    "mean_utilization_q_after": self._utilization(mean_after),
                    "mean_sojourn_slots": queue_sojourn.mean_or_none,
                    "p95_sojourn_slots": queue_sojourn.percentile(0.95),
                    "mean_waiting_slots": queue_residence.mean_or_none,
                    "p95_waiting_slots": queue_residence.percentile(0.95),
                    "backlog_levels_q_before": self._queue_backlog_levels_q_before(index),
                }
            )
        return entries

    def metrics_dict(self) -> dict[str, JSONValue]:
        mean_total_before = (
            None
            if self._q_before_samples == 0
            else float(_exact_array_sum(self._q_before_sum)) / float(self._q_before_samples)
        )
        mean_total_after = (
            None
            if self._q_after_samples == 0
            else float(_exact_array_sum(self._q_after_sum)) / float(self._q_after_samples)
        )
        schedule = {
            "sample_count": self._selected_count.count,
            "feasible_slots": self._feasible_slots,
            "selected_count": self._selected_count.to_dict(),
            "served_count": self._served_count.to_dict(),
            "primary_maxweight_objective": self._primary_weight.to_dict(),
            "scheduler_ids": {key: int(value) for key, value in sorted(self._scheduler_ids.items())},
            "algorithm_ids": {key: int(value) for key, value in sorted(self._algorithm_ids.items())},
            "optimizer_ids": {key: int(value) for key, value in sorted(self._optimizer_ids.items())},
        }
        state_counts = {key: int(value) for key, value in sorted(self._state_before_counts.items())}
        transitions: dict[str, dict[str, int]] = {}
        for (src, dst), count in sorted(self._state_transition_counts.items()):
            transitions.setdefault(src, {})[dst] = int(count)
        return {
            "slots_observed": self.slots_observed,
            "first_slot": self.first_slot,
            "last_slot": self.last_slot,
            "offered_packets": self.offered_packets,
            "admitted_packets": self.admitted_packets,
            "dropped_packets": self.dropped_packets,
            "completed_packets": self.completed_packets,
            "drop_fraction_of_offered": _rate(self.dropped_packets, self.offered_packets),
            "mean_drops_per_slot": _rate(self.dropped_packets, self.slots_observed),
            "drop_reasons": {key: int(value) for key, value in sorted(self._drop_reasons.items())},
            "mean_total_occupancy_q_before": mean_total_before,
            "mean_total_occupancy_q_after": mean_total_after,
            "mean_sojourn_slots": self._sojourn.mean_or_none,
            "p95_sojourn_slots": self._sojourn.percentile(0.95),
            "max_sojourn_slots": self._sojourn.maximum,
            "mean_waiting_slots": self._residence.mean_or_none,
            "p95_waiting_slots": self._residence.percentile(0.95),
            "max_waiting_slots": self._residence.maximum,
            "schedule": schedule,
            "mean_selected_queue_count": self._selected_count.mean_or_none,
            "mean_served_packet_count": self._served_count.mean_or_none,
            "mean_primary_maxweight_objective": self._primary_weight.mean_or_none,
            "queue_backlog_levels": self._queue_backlog_levels_summary(),
            "per_queue": self._per_queue_summary(),
            "arrival": {
                "family": self.family,
                "live_queue_ids": list(self._live_queue_ids),
                "outcome_counts": [
                    {
                        "arrival_outcome_id": outcome_id,
                        "count": int(count),
                        "rate": _rate(int(count), self.slots_observed),
                    }
                    for outcome_id, count in sorted(self._arrival_outcome_ids.items())
                ],
                "state_occupancy_counts": state_counts,
                "state_transition_counts": transitions,
            },
        }

    def summary_metadata(self, extra: Mapping[str, Any] | None = None) -> dict[str, JSONValue]:
        payload = dict(self._metadata)
        payload.update(_normalize_metadata(extra))
        payload.setdefault("family", self.family)
        payload.setdefault("run_summary_version", GENERIC_RUN_SUMMARY_VERSION)
        payload.setdefault("queue_space", "catalog")
        payload.setdefault("n_queues", len(self._queue_ids))
        payload.setdefault("queue_ids", list(self._queue_ids))
        if self.queue_capacity is not None:
            payload.setdefault("queue_capacity", self.queue_capacity)
        return payload

    def finalize(self, *, metadata: Mapping[str, Any] | None = None) -> RunSummary:
        return RunSummary(metrics=self.metrics_dict(), metadata=self.summary_metadata(metadata))

    def to_summary(self, *, metadata: Mapping[str, Any] | None = None) -> RunSummary:
        return self.finalize(metadata=metadata)

    def to_dict(self, *, metadata: Mapping[str, Any] | None = None) -> dict[str, JSONValue]:
        return self.finalize(metadata=metadata).to_dict()


def summarize_records(
    records: Iterable[GenericSlotRecord],
    *,
    stats: GenericRunStats | None = None,
    **kwargs: Any,
) -> RunSummary:
    accumulator = stats if stats is not None else GenericRunStats(**kwargs)
    accumulator.update_many(records)
    return accumulator.finalize()


__all__ = [
    "GENERIC_RUN_SUMMARY_VERSION",
    "ExactDiscreteTracker",
    "OnlineDiscreteTracker",
    "OnlineMoments",
    "RunSummary",
    "GenericRunStats",
    "summarize_records",
]
