from __future__ import annotations

from dataclasses import dataclass, replace
from numbers import Integral
from typing import Any

from .errors import ValidationError
from .types import FlowId, JSONValue, PacketId, PortId, QueueId, Slot, VOQKey



def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": coerced, "minimum": 0})
    return coerced



def _validate_optional_non_negative_int(value: Any, *, name: str) -> int | None:
    if value is None:
        return None
    return _validate_non_negative_int(value, name=name)


def _validate_queue_id(value: Any, *, name: str = "queue_id") -> QueueId:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be a nonnegative integer or nonempty string", context={"value": value})
    if isinstance(value, Integral):
        normalized = int(value)
        if normalized < 0:
            raise ValidationError(f"{name} integer must be >= 0", context={"value": normalized})
        return normalized
    if isinstance(value, str) and value and value.strip() == value:
        return value
    raise ValidationError(
        f"{name} must be a nonnegative integer or nonempty string without surrounding whitespace",
        context={"value": value},
    )


@dataclass(slots=True, frozen=True)
class Packet:
    """Immutable packet metadata for one-hop generalized-switch traversal.

    The packet carries only control-plane information needed by the simulator:
    identity, stable queue identity, generation time, queue admission time, and
    completion time.  Source/destination ports are optional legacy VOQ metadata;
    they are not used as generalized queue identity.  State transitions are
    represented by returning stamped packet copies rather than mutating the
    object in place.
    """

    packet_id: PacketId
    flow_id: FlowId
    src_port: PortId | None
    dst_port: PortId | None
    generation_slot: Slot
    enqueue_slot: Slot | None = None
    completion_slot: Slot | None = None
    queue_id: QueueId | None = None

    def __post_init__(self) -> None:
        packet_id = _validate_non_negative_int(self.packet_id, name="packet_id")
        flow_id = _validate_non_negative_int(self.flow_id, name="flow_id")
        src_port = _validate_optional_non_negative_int(self.src_port, name="src_port")
        dst_port = _validate_optional_non_negative_int(self.dst_port, name="dst_port")
        if (src_port is None) != (dst_port is None):
            raise ValidationError(
                "src_port and dst_port must either both be set or both be null",
                context={"src_port": src_port, "dst_port": dst_port},
            )
        generation_slot = _validate_non_negative_int(self.generation_slot, name="generation_slot")
        enqueue_slot = _validate_optional_non_negative_int(self.enqueue_slot, name="enqueue_slot")
        completion_slot = _validate_optional_non_negative_int(self.completion_slot, name="completion_slot")

        if self.queue_id is None:
            if src_port is None or dst_port is None:
                raise ValidationError(
                    "queue_id is required when legacy port metadata is absent",
                    context={"packet_id": packet_id},
                )
            queue_id: QueueId = f"voq[{src_port},{dst_port}]"
        else:
            queue_id = _validate_queue_id(self.queue_id)

        if enqueue_slot is not None and enqueue_slot < generation_slot:
            raise ValidationError(
                "enqueue_slot must be greater than or equal to generation_slot",
                context={
                    "packet_id": packet_id,
                    "generation_slot": generation_slot,
                    "enqueue_slot": enqueue_slot,
                },
            )

        if completion_slot is not None and enqueue_slot is None:
            raise ValidationError(
                "completion_slot cannot be set before enqueue_slot",
                context={"packet_id": packet_id, "completion_slot": completion_slot},
            )

        if completion_slot is not None and completion_slot <= enqueue_slot:  # type: ignore[operator]
            raise ValidationError(
                "completion_slot must be strictly greater than enqueue_slot",
                context={
                    "packet_id": packet_id,
                    "enqueue_slot": enqueue_slot,
                    "completion_slot": completion_slot,
                },
            )

        object.__setattr__(self, "packet_id", packet_id)
        object.__setattr__(self, "flow_id", flow_id)
        object.__setattr__(self, "src_port", src_port)
        object.__setattr__(self, "dst_port", dst_port)
        object.__setattr__(self, "generation_slot", generation_slot)
        object.__setattr__(self, "enqueue_slot", enqueue_slot)
        object.__setattr__(self, "completion_slot", completion_slot)
        object.__setattr__(self, "queue_id", queue_id)

    @classmethod
    def for_queue(
        cls,
        *,
        packet_id: PacketId,
        flow_id: FlowId,
        queue_id: QueueId,
        generation_slot: Slot,
    ) -> Packet:
        """Construct a generalized packet without legacy port metadata."""

        return cls(
            packet_id=packet_id,
            flow_id=flow_id,
            src_port=None,
            dst_port=None,
            generation_slot=generation_slot,
            queue_id=queue_id,
        )

    @property
    def has_legacy_voq(self) -> bool:
        return self.src_port is not None

    @property
    def voq_key(self) -> VOQKey:
        """Return legacy VOQ metadata or fail for a topology-neutral packet."""

        if self.src_port is None or self.dst_port is None:
            raise ValidationError(
                "Packet has no legacy VOQ metadata",
                context={"packet_id": self.packet_id, "queue_id": self.queue_id},
            )
        return (self.src_port, self.dst_port)

    @property
    def is_enqueued(self) -> bool:
        """Whether the packet has been admitted into a VOQ."""

        return self.enqueue_slot is not None

    @property
    def is_completed(self) -> bool:
        """Whether the packet has reached its sink."""

        return self.completion_slot is not None

    @property
    def sojourn_slots(self) -> int | None:
        """Return total system sojourn once the packet completes."""

        if self.completion_slot is None:
            return None
        return self.completion_slot - self.generation_slot

    @property
    def residence_slots(self) -> int | None:
        """Return time from queue admission to completion, if complete."""

        if self.enqueue_slot is None or self.completion_slot is None:
            return None
        return self.completion_slot - self.enqueue_slot

    @property
    def waiting_slots(self) -> int | None:
        """Alias for :attr:`residence_slots` used by telemetry summaries."""

        return self.residence_slots

    def mark_enqueued(self, slot: Slot) -> Packet:
        """Return a copy stamped with ``enqueue_slot=slot``.

        Re-stamping the same slot is allowed and returns ``self`` for idempotent
        callers. Stamping a different slot after enqueue raises a validation
        error because queue admission is a one-time state transition.
        """

        stamped_slot = _validate_non_negative_int(slot, name="slot")
        if stamped_slot < self.generation_slot:
            raise ValidationError(
                "enqueue slot cannot precede packet generation",
                context={
                    "packet_id": self.packet_id,
                    "generation_slot": self.generation_slot,
                    "slot": stamped_slot,
                },
            )
        if self.enqueue_slot is not None:
            if self.enqueue_slot != stamped_slot:
                raise ValidationError(
                    "Packet enqueue_slot is already set to a different slot",
                    context={
                        "packet_id": self.packet_id,
                        "enqueue_slot": self.enqueue_slot,
                        "requested_slot": stamped_slot,
                    },
                )
            return self
        return replace(self, enqueue_slot=stamped_slot)

    def mark_completed(self, slot: Slot) -> Packet:
        """Return a copy stamped with ``completion_slot=slot``."""

        stamped_slot = _validate_non_negative_int(slot, name="slot")
        if self.enqueue_slot is None:
            raise ValidationError(
                "Packet must be enqueued before it can complete",
                context={"packet_id": self.packet_id, "slot": stamped_slot},
            )
        if stamped_slot <= self.enqueue_slot:
            raise ValidationError(
                "completion slot must be strictly greater than enqueue_slot",
                context={
                    "packet_id": self.packet_id,
                    "enqueue_slot": self.enqueue_slot,
                    "slot": stamped_slot,
                },
            )
        if self.completion_slot is not None:
            if self.completion_slot != stamped_slot:
                raise ValidationError(
                    "Packet completion_slot is already set to a different slot",
                    context={
                        "packet_id": self.packet_id,
                        "completion_slot": self.completion_slot,
                        "requested_slot": stamped_slot,
                    },
                )
            return self
        return replace(self, completion_slot=stamped_slot)

    def with_enqueue_slot(self, slot: Slot) -> Packet:
        """Backward-compatible alias for :meth:`mark_enqueued`."""

        return self.mark_enqueued(slot)

    def with_completion_slot(self, slot: Slot) -> Packet:
        """Backward-compatible alias for :meth:`mark_completed`."""

        return self.mark_completed(slot)

    def to_dict(self) -> dict[str, JSONValue]:
        """Return a stable serialization-ready mapping."""

        return {
            "packet_id": self.packet_id,
            "flow_id": self.flow_id,
            "queue_id": self.queue_id,
            "src_port": self.src_port,
            "dst_port": self.dst_port,
            "generation_slot": self.generation_slot,
            "enqueue_slot": self.enqueue_slot,
            "completion_slot": self.completion_slot,
            "sojourn_slots": self.sojourn_slots,
            "residence_slots": self.residence_slots,
        }



def packet_to_dict(packet: Packet) -> dict[str, JSONValue]:
    """Return ``packet`` as a stable serialization-ready mapping."""

    if not isinstance(packet, Packet):
        raise ValidationError(
            "packet must be an instance of Packet",
            context={"value_type": type(packet).__name__},
        )
    return packet.to_dict()


__all__ = ["Packet", "packet_to_dict"]
