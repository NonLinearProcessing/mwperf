from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from numbers import Integral
from typing import Any, Mapping

from ..errors import ValidationError
from ..traffic.compiler import CompiledArrivalSpec
from ..types import QueueId
from .step1 import ArrivalMarginal


@dataclass(frozen=True, slots=True)
class ArrivalMarginalResult:
    """Result of certifying a target's offered-arrival marginal.

    A missing marginal is explicit.  The adapter never estimates a law from a
    trajectory and never consumes the simulator's random stream.
    """

    family: str
    queue_id: QueueId
    marginal: ArrivalMarginal | None
    status: str


def _exact_parameter(value: object, *, name: str) -> Fraction:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be numeric, not boolean")
    if isinstance(value, Fraction):
        result = value
    elif isinstance(value, Decimal):
        if not value.is_finite():
            raise ValidationError(f"{name} must be finite", context={"value": str(value)})
        result = Fraction(value)
    elif isinstance(value, Integral):
        result = Fraction(int(value))
    elif isinstance(value, float):
        if value != value or value in {float("inf"), float("-inf")}:
            raise ValidationError(f"{name} must be finite", context={"value": value})
        result = Fraction.from_float(value)
    else:
        raise ValidationError(
            f"{name} must be an exact decimal, integer, fraction, or finite float",
            context={"value_type": type(value).__name__},
        )
    if result < 0:
        raise ValidationError(f"{name} must be non-negative", context={"value": str(value)})
    return result


def _queue_rate(model: object, target_index: int, queue_id: QueueId) -> Fraction:
    rates = getattr(model, "rates", None)
    if rates is not None:
        try:
            raw = rates[target_index]
        except (IndexError, KeyError, TypeError) as exc:
            raise ValidationError(
                "arrival model rates do not match the queue catalog",
                context={"queue_id": queue_id, "target_index": target_index},
            ) from exc
        return _exact_parameter(raw, name=f"arrival rate[{queue_id!r}]")
    rate_for_queue = getattr(model, "rate_for_queue", None)
    if callable(rate_for_queue):
        return _exact_parameter(
            rate_for_queue(queue_id),
            name=f"arrival rate[{queue_id!r}]",
        )
    raise ValidationError(
        "certified IID arrival model does not expose queue-ordered rates",
        context={"family": getattr(model, "family", type(model).__name__)},
    )


def _state_field(state: object, name: str) -> Any:
    if isinstance(state, Mapping):
        if name not in state:
            raise ValidationError(
                "mixed-Poisson modulation state is incomplete",
                context={"missing": name},
            )
        return state[name]
    if not hasattr(state, name):
        raise ValidationError(
            "mixed-Poisson modulation state is incomplete",
            context={"missing": name, "state_type": type(state).__name__},
        )
    return getattr(state, name)


def _count_at(outcome: object, target_index: int, queue_id: QueueId) -> int:
    counts = getattr(outcome, "counts", None)
    if counts is None and isinstance(outcome, Mapping):
        counts = outcome.get("counts")
    if counts is None:
        raise ValidationError("IID count-table outcome does not expose counts")
    count_at = getattr(counts, "count_at", None)
    if callable(count_at):
        value = count_at(target_index)
    elif isinstance(counts, Mapping):
        value = counts.get(queue_id, 0)
    else:
        try:
            value = counts[target_index]
        except (IndexError, KeyError, TypeError) as exc:
            raise ValidationError("IID count-table counts do not match the queue catalog") from exc
    if isinstance(value, bool) or not isinstance(value, Integral) or int(value) < 0:
        raise ValidationError("IID count-table counts must be non-negative integers")
    return int(value)


def _count_table_marginal(model: object, target_index: int, queue_id: QueueId) -> ArrivalMarginal:
    outcomes = getattr(model, "outcomes", None)
    if outcomes is None:
        outcomes = getattr(model, "entries", None)
    if outcomes is None:
        raise ValidationError("IID count-table model does not expose outcomes")
    pmf: dict[int, Fraction] = {}
    for position, outcome in enumerate(outcomes):
        raw_probability = (
            outcome.get("probability")
            if isinstance(outcome, Mapping)
            else getattr(outcome, "probability", None)
        )
        if raw_probability is None:
            raise ValidationError(
                "IID count-table outcome does not expose probability",
                context={"position": position},
            )
        probability = _exact_parameter(
            raw_probability,
            name=f"IID count-table probability[{position}]",
        )
        count = _count_at(outcome, target_index, queue_id)
        pmf[count] = pmf.get(count, Fraction(0)) + probability
    return ArrivalMarginal.from_pmf(pmf, family="iid_count_table")


def certified_target_arrival_marginal(
    compiled: CompiledArrivalSpec,
    queue_id: QueueId,
) -> ArrivalMarginalResult:
    """Return the exact fresh-IID target marginal when it is certified.

    Exact finite laws remain rational. Canonical Poisson and mixed-Poisson
    laws retain compact infinite-support parameters and provide controlled
    stop-loss evaluation. Stateful, periodic, renewal, and trace families
    remain available as raw observations but are not silently treated as IID.
    """

    if not isinstance(compiled, CompiledArrivalSpec):
        raise ValidationError(
            "compiled must be a CompiledArrivalSpec",
            context={"value_type": type(compiled).__name__},
        )
    assert compiled.queue_catalog is not None
    target_index = compiled.queue_catalog.index_of(queue_id)
    canonical_id = compiled.queue_catalog.queue_id_at(target_index)
    model = compiled.model

    if compiled.family == "iid_independent_bernoulli":
        probability = _queue_rate(model, target_index, canonical_id)
        if probability > 1:
            raise ValidationError(
                "target Bernoulli probability lies outside [0, 1]",
                context={"queue_id": canonical_id, "probability": str(probability)},
            )
        return ArrivalMarginalResult(
            compiled.family,
            canonical_id,
            ArrivalMarginal.from_pmf(
                {0: 1 - probability, 1: probability},
                family="iid_independent_bernoulli",
            ),
            "ok",
        )

    if compiled.family == "iid_count_table":
        return ArrivalMarginalResult(
            compiled.family,
            canonical_id,
            _count_table_marginal(model, target_index, canonical_id),
            "ok",
        )

    if compiled.family == "iid_independent_poisson":
        return ArrivalMarginalResult(
            compiled.family,
            canonical_id,
            ArrivalMarginal.poisson(_queue_rate(model, target_index, canonical_id)),
            "ok",
        )

    if compiled.family == "iid_mixed_poisson":
        states = getattr(model, "modulation_states", None)
        if states is None:
            raise ValidationError("IID mixed-Poisson model does not expose modulation states")
        state_parameters = tuple(
            (
                _exact_parameter(
                    _state_field(state, "probability"),
                    name=f"modulation state[{position}] probability",
                ),
                _exact_parameter(
                    _state_field(state, "multiplier"),
                    name=f"modulation state[{position}] multiplier",
                ),
            )
            for position, state in enumerate(states)
        )
        return ArrivalMarginalResult(
            compiled.family,
            canonical_id,
            ArrivalMarginal.mixed_poisson(
                _queue_rate(model, target_index, canonical_id),
                state_parameters,
            ),
            "ok",
        )

    return ArrivalMarginalResult(compiled.family, canonical_id, None, "not_fresh_iid")


__all__ = ["ArrivalMarginalResult", "certified_target_arrival_marginal"]
