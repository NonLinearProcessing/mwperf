from __future__ import annotations

from dataclasses import dataclass
from decimal import (
    Context,
    Decimal,
    DecimalException,
    ROUND_CEILING,
    ROUND_FLOOR,
    ROUND_HALF_EVEN,
)
from fractions import Fraction
import math
from types import MappingProxyType
from typing import Callable, Iterable, Mapping, Protocol, TypeAlias, runtime_checkable

from ..errors import ValidationError


RationalInput: TypeAlias = int | float | Decimal | Fraction
AnalysisNumber: TypeAlias = Fraction | float


def _fraction(value: RationalInput, *, name: str) -> Fraction:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be numeric, not boolean")
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValidationError(f"{name} must be finite", context={"value": str(value)})
        return Fraction(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValidationError(f"{name} must be finite", context={"value": value})
        return Fraction.from_float(value)
    raise ValidationError(
        f"{name} must be an int, finite float, or Fraction",
        context={"value_type": type(value).__name__},
    )


def _backlog(value: object, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValidationError(f"{name} must be a non-negative integer", context={"value": value})
    return int(value)


def _nonnegative(value: RationalInput, *, name: str) -> Fraction:
    result = _fraction(value, name=name)
    if result < 0:
        raise ValidationError(f"{name} must be non-negative", context={"value": value})
    return result


def _readonly(values: Mapping[int, Fraction]) -> Mapping[int, Fraction]:
    return MappingProxyType(dict(sorted(values.items())))


@dataclass(frozen=True, slots=True)
class CertifiedEvaluation:
    """A scalar together with an absolute error certificate.

    Exact finite-law calculations retain :class:`Fraction` values and use an
    exact zero error bound. A successful transcendental calculation uses a
    binary64 value with a conservative absolute error bound. Failed numerical
    work never carries a fabricated value.
    """

    value: AnalysisNumber | None
    error_bound: AnalysisNumber | None
    status: str

    @classmethod
    def exact(cls, value: RationalInput) -> "CertifiedEvaluation":
        return cls(_fraction(value, name="exact evaluation"), Fraction(0), "exact")

    @classmethod
    def unavailable(cls, status: str) -> "CertifiedEvaluation":
        if not isinstance(status, str) or not status:
            raise ValidationError("evaluation status must be a nonempty string")
        return cls(None, None, status)

    @property
    def available(self) -> bool:
        return self.value is not None and self.error_bound is not None and self.status in {
            "exact",
            "ok",
        }

    @property
    def is_exact(self) -> bool:
        return self.available and self.error_bound == 0

    @property
    def error(self) -> AnalysisNumber | None:
        return self.error_bound

    def __float__(self) -> float:
        if not self.available or self.value is None:
            raise TypeError("an unavailable certified evaluation has no float value")
        return float(self.value)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, CertifiedEvaluation):
            return (
                self.value,
                self.error_bound,
                self.status,
            ) == (other.value, other.error_bound, other.status)
        if isinstance(other, (int, float, Decimal, Fraction)) and self.is_exact:
            return self.value == other
        return NotImplemented


# Public semantic aliases: callers may prefer the operation-specific name.
NumericalResult = CertifiedEvaluation
StopLossResult = CertifiedEvaluation


@runtime_checkable
class CertifiedArrivalLaw(Protocol):
    """Law interface needed by the fresh-IID formula layer."""

    mean: Fraction
    variance: Fraction
    second_moment: Fraction
    fresh_iid: bool

    def stop_loss(self, x: int, cutoff: int) -> CertifiedEvaluation: ...

    def shifted_expectation(
        self,
        state: int,
        function: Callable[[int], int | Fraction],
    ) -> CertifiedEvaluation: ...


_POISSON_DECIMAL_PRECISION = 80
_POISSON_ABSOLUTE_TOLERANCE = Decimal("1e-45")
_POISSON_MAX_RECURRENCES = 1_000_000
_POISSON_DECIMAL_EMAX = 999_999_999
_POISSON_DECIMAL_EMIN = -999_999_999
_POISSON_MAX_FRACTION_DECIMAL_DIGITS = 100_000


class _PoissonNumericalFailure(Exception):
    def __init__(self, status: str) -> None:
        super().__init__(status)
        self.status = status


def _poisson_decimal_context(rounding: str) -> Context:
    return Context(
        prec=_POISSON_DECIMAL_PRECISION,
        rounding=rounding,
        Emax=_POISSON_DECIMAL_EMAX,
        Emin=_POISSON_DECIMAL_EMIN,
    )


def _decimal_fraction_interval(
    value: Fraction,
    lower_context: Context,
    upper_context: Context,
) -> tuple[Decimal, Decimal]:
    numerator = Decimal(value.numerator)
    denominator = Decimal(value.denominator)
    return (
        lower_context.divide(numerator, denominator),
        upper_context.divide(numerator, denominator),
    )


def _decimal_exp_interval(
    lower_argument: Decimal,
    upper_argument: Decimal,
    nearest_context: Context,
) -> tuple[Decimal, Decimal]:
    """Enclose exp on one Decimal interval.

    ``Decimal.exp`` is correctly rounded in ROUND_HALF_EVEN.  Moving one
    representable Decimal outward at each endpoint therefore encloses both the
    transcendental rounding error and the monotone image of the input interval.
    """

    lower_approximation = lower_argument.exp(context=nearest_context)
    upper_approximation = upper_argument.exp(context=nearest_context)
    lower = nearest_context.next_minus(lower_approximation)
    upper = nearest_context.next_plus(upper_approximation)
    if lower < 0:
        lower = Decimal(0)
    if upper > 1:
        upper = Decimal(1)
    return lower, upper


def _bounded_decimal_fraction(value: Decimal) -> Fraction:
    """Convert a Decimal endpoint without unbounded integer materialization."""

    if not value.is_finite():
        raise _PoissonNumericalFailure("poisson_numerical_failure")
    if value.is_zero():
        return Fraction(0)
    _sign, digits, exponent = value.as_tuple()
    numerator_digits = len(digits) + max(exponent, 0)
    denominator_digits = max(-exponent, 0)
    if (
        max(numerator_digits, denominator_digits)
        > _POISSON_MAX_FRACTION_DECIMAL_DIGITS
    ):
        raise _PoissonNumericalFailure("poisson_numeric_resource_limit")
    try:
        return Fraction(value)
    except MemoryError as exc:  # pragma: no cover - platform resource dependent
        raise _PoissonNumericalFailure("poisson_numeric_resource_limit") from exc


def _outward_float_bound(value: Fraction) -> float:
    """Round a non-negative exact bound toward positive infinity."""

    if value < 0:
        raise ValueError("an absolute error bound cannot be negative")
    candidate = float(value)
    if not math.isfinite(candidate):
        raise OverflowError("certified error bound is outside binary64")
    if Fraction.from_float(candidate) < value:
        candidate = math.nextafter(candidate, math.inf)
    if not math.isfinite(candidate):
        raise OverflowError("certified error bound is outside binary64")
    return candidate


def _rounded_certified_evaluation(
    center: Fraction,
    error: Fraction,
    *,
    failure_status: str,
) -> CertifiedEvaluation:
    """Round an exact center once and outward-round its total error."""

    if error < 0:
        return CertifiedEvaluation.unavailable(failure_status)
    try:
        value = float(center)
    except (OverflowError, ValueError):
        return CertifiedEvaluation.unavailable(failure_status)
    if not math.isfinite(value):
        return CertifiedEvaluation.unavailable(failure_status)
    conversion_error = abs(center - Fraction.from_float(value))
    try:
        bound = _outward_float_bound(error + conversion_error)
    except (OverflowError, ValueError):
        return CertifiedEvaluation.unavailable(failure_status)
    # A successful transcendental/approximate path is never advertised as
    # exact, even when its enclosure happens to collapse at binary64 scale.
    if bound == 0:
        bound = math.ulp(0.0)
    return CertifiedEvaluation(value, bound, "ok")


def _poisson_survival_decimal(
    rate: Fraction,
    threshold: int,
) -> tuple[Decimal, Decimal]:
    """Enclose ``P(Poi(rate) >= threshold)`` by directed Decimal arithmetic.

    The lower-tail branch is a finite sum. The upper-tail branch stops only
    when a geometric majorant for *all remaining terms* is below the declared
    tolerance. The recurrence limit is a resource guard: hitting it returns
    an unavailable status to the caller, never a truncated probability.
    """

    if threshold <= 0:
        return Decimal(1), Decimal(1)
    if rate == 0:
        return Decimal(0), Decimal(0)
    if threshold > _POISSON_MAX_RECURRENCES:
        raise _PoissonNumericalFailure("poisson_iteration_limit")

    lower_context = _poisson_decimal_context(ROUND_FLOOR)
    upper_context = _poisson_decimal_context(ROUND_CEILING)
    nearest_context = _poisson_decimal_context(ROUND_HALF_EVEN)
    try:
        theta_lower, theta_upper = _decimal_fraction_interval(
            rate,
            lower_context,
            upper_context,
        )
        # exp is monotone and theta lies in [theta_lower, theta_upper].
        term_lower, term_upper = _decimal_exp_interval(
            theta_upper.copy_negate(),
            theta_lower.copy_negate(),
            nearest_context,
        )

        recurrences = 0
        if Fraction(threshold) <= rate:
            # P(X >= k) = 1 - sum_{j=0}^{k-1} p_j. Directed subtraction
            # retains a nonzero enclosure even when the CDF is far below one
            # at the working precision.
            cdf_lower = term_lower
            cdf_upper = term_upper
            for index in range(1, threshold):
                denominator = Decimal(index)
                term_lower = lower_context.divide(
                    lower_context.multiply(term_lower, theta_lower),
                    denominator,
                )
                term_upper = upper_context.divide(
                    upper_context.multiply(term_upper, theta_upper),
                    denominator,
                )
                cdf_lower = lower_context.add(cdf_lower, term_lower)
                cdf_upper = upper_context.add(cdf_upper, term_upper)
                recurrences += 1
                if recurrences > _POISSON_MAX_RECURRENCES:  # pragma: no cover
                    raise _PoissonNumericalFailure("poisson_iteration_limit")
            lower = lower_context.subtract(Decimal(1), cdf_upper)
            upper = upper_context.subtract(Decimal(1), cdf_lower)
        else:
            # Reach p_k by interval recurrence, then bound the entire omitted
            # tail geometrically. No partial sum is returned without that
            # bound.
            for index in range(1, threshold + 1):
                denominator = Decimal(index)
                term_lower = lower_context.divide(
                    lower_context.multiply(term_lower, theta_lower),
                    denominator,
                )
                term_upper = upper_context.divide(
                    upper_context.multiply(term_upper, theta_upper),
                    denominator,
                )
                recurrences += 1
                if recurrences > _POISSON_MAX_RECURRENCES:
                    raise _PoissonNumericalFailure("poisson_iteration_limit")
            lower = term_lower
            upper = term_upper
            index = threshold
            while True:
                recurrences += 1
                if recurrences > _POISSON_MAX_RECURRENCES:
                    raise _PoissonNumericalFailure("poisson_iteration_limit")
                next_denominator = Decimal(index + 1)
                next_lower = lower_context.divide(
                    lower_context.multiply(term_lower, theta_lower),
                    next_denominator,
                )
                next_upper = upper_context.divide(
                    upper_context.multiply(term_upper, theta_upper),
                    next_denominator,
                )
                ratio_upper = upper_context.divide(
                    theta_upper,
                    Decimal(index + 2),
                )
                if ratio_upper >= 1:  # pragma: no cover - exact branch leaves margin
                    raise _PoissonNumericalFailure("poisson_numerical_failure")
                denominator_lower = lower_context.subtract(
                    Decimal(1),
                    ratio_upper,
                )
                remainder_upper = upper_context.divide(
                    next_upper,
                    denominator_lower,
                )
                if remainder_upper <= _POISSON_ABSOLUTE_TOLERANCE:
                    upper = upper_context.add(upper, remainder_upper)
                    break
                lower = lower_context.add(lower, next_lower)
                upper = upper_context.add(upper, next_upper)
                term_lower = next_lower
                term_upper = next_upper
                index += 1
    except DecimalException as exc:
        raise _PoissonNumericalFailure("poisson_numerical_failure") from exc

    lower = max(lower, Decimal(0))
    upper = min(upper, Decimal(1))
    if (
        not lower.is_finite()
        or not upper.is_finite()
        or lower > upper
    ):
        raise _PoissonNumericalFailure("poisson_numerical_failure")
    return lower, upper


def _poisson_stop_loss(rate: Fraction, x: int, cutoff: int) -> CertifiedEvaluation:
    residual = cutoff - x
    if residual <= 0:
        # A is non-negative, so (A-r)^+ = A-r when r <= 0.
        return CertifiedEvaluation.exact(rate - residual)
    if rate == 0:
        return CertifiedEvaluation.exact(0)
    if residual + 1 > _POISSON_MAX_RECURRENCES:
        return CertifiedEvaluation.unavailable("poisson_iteration_limit")
    try:
        survival_r_lower, survival_r_upper = _poisson_survival_decimal(
            rate,
            residual,
        )
        survival_next_lower, survival_next_upper = _poisson_survival_decimal(
            rate,
            residual + 1,
        )
        lower_context = _poisson_decimal_context(ROUND_FLOOR)
        upper_context = _poisson_decimal_context(ROUND_CEILING)
        theta_lower, theta_upper = _decimal_fraction_interval(
            rate,
            lower_context,
            upper_context,
        )
        residual_decimal = Decimal(residual)
        lower = lower_context.subtract(
            lower_context.multiply(theta_lower, survival_r_lower),
            upper_context.multiply(residual_decimal, survival_next_upper),
        )
        upper = upper_context.subtract(
            upper_context.multiply(theta_upper, survival_r_upper),
            lower_context.multiply(residual_decimal, survival_next_lower),
        )
        if upper < 0:
            raise _PoissonNumericalFailure("poisson_numerical_failure")
        lower = max(lower, Decimal(0))
        if not lower.is_finite() or not upper.is_finite() or lower > upper:
            raise _PoissonNumericalFailure("poisson_numerical_failure")
        lower_fraction = _bounded_decimal_fraction(lower)
        upper_fraction = _bounded_decimal_fraction(upper)
        center = (lower_fraction + upper_fraction) / 2
        error = (upper_fraction - lower_fraction) / 2
    except MemoryError:
        return CertifiedEvaluation.unavailable("poisson_numeric_resource_limit")
    except (DecimalException, OverflowError, ValueError):
        return CertifiedEvaluation.unavailable("poisson_numerical_failure")
    except _PoissonNumericalFailure as exc:
        return CertifiedEvaluation.unavailable(exc.status)
    return _rounded_certified_evaluation(
        center,
        error,
        failure_status="poisson_numerical_failure",
    )


def _weighted_evaluations(
    terms: Iterable[tuple[Fraction, CertifiedEvaluation]],
) -> CertifiedEvaluation:
    materialized = tuple(terms)
    for _weight, evaluation in materialized:
        if not evaluation.available:
            return CertifiedEvaluation.unavailable(evaluation.status)
    if all(evaluation.is_exact for _weight, evaluation in materialized):
        return CertifiedEvaluation.exact(
            sum(
                (
                    weight * _fraction(evaluation.value, name="exact evaluation value")
                    for weight, evaluation in materialized
                    if evaluation.value is not None
                ),
                Fraction(0),
            )
        )

    center = Fraction(0)
    bound = Fraction(0)
    for weight, evaluation in materialized:
        assert evaluation.value is not None and evaluation.error_bound is not None
        component_value = _fraction(
            evaluation.value,
            name="certified evaluation value",
        )
        component_error = _fraction(
            evaluation.error_bound,
            name="certified evaluation error bound",
        )
        if component_error < 0:
            return CertifiedEvaluation.unavailable("numerical_combination_failure")
        center += weight * component_value
        bound += abs(weight) * component_error
    return _rounded_certified_evaluation(
        center,
        bound,
        failure_status="numerical_combination_failure",
    )


def _subtract_exact(
    evaluation: CertifiedEvaluation,
    exact_value: Fraction,
) -> CertifiedEvaluation:
    if not evaluation.available:
        return evaluation
    assert evaluation.value is not None and evaluation.error_bound is not None
    if evaluation.is_exact:
        return CertifiedEvaluation.exact(
            _fraction(evaluation.value, name="exact evaluation value") - exact_value
        )
    center = _fraction(
        evaluation.value,
        name="certified evaluation value",
    ) - exact_value
    bound = _fraction(
        evaluation.error_bound,
        name="certified evaluation error bound",
    )
    return _rounded_certified_evaluation(
        center,
        bound,
        failure_status="numerical_combination_failure",
    )


def _subtract_from_exact(
    exact_value: Fraction,
    evaluation: CertifiedEvaluation,
) -> CertifiedEvaluation:
    """Return ``exact_value - evaluation`` without lossy operand conversion."""

    if not evaluation.available:
        return evaluation
    assert evaluation.value is not None and evaluation.error_bound is not None
    if evaluation.is_exact:
        return CertifiedEvaluation.exact(
            exact_value
            - _fraction(evaluation.value, name="exact evaluation value")
        )
    center = exact_value - _fraction(
        evaluation.value,
        name="certified evaluation value",
    )
    bound = _fraction(
        evaluation.error_bound,
        name="certified evaluation error bound",
    )
    return _rounded_certified_evaluation(
        center,
        bound,
        failure_status="numerical_combination_failure",
    )


@dataclass(frozen=True, slots=True)
class NormalizedLevelMasses:
    """Pooled raw level masses and their normalized scientific moments."""

    total_mass: Fraction
    exposure_mass: Mapping[int, Fraction]
    service_mass: Mapping[int, Fraction]
    p: Mapping[int, Fraction]
    s: Mapping[int, Fraction]
    response: Mapping[int, Fraction]
    departure_mean: Fraction | None
    backlog_mean: Fraction | None
    service_backlog_moment: Fraction | None
    status: str


def normalize_level_masses(
    exposure_mass: Mapping[int, RationalInput],
    service_mass: Mapping[int, RationalInput],
) -> NormalizedLevelMasses:
    """Pool additive masses before forming probabilities or responses.

    The same function accepts simulator integer counts and exact weighted
    numerator masses because a common fixed-lattice scale cancels on division.
    """

    exposure: dict[int, Fraction] = {}
    served: dict[int, Fraction] = {}
    for raw_n, raw_value in exposure_mass.items():
        n = _backlog(raw_n, name="exposure backlog")
        exposure[n] = _nonnegative(raw_value, name=f"exposure_mass[{n}]")
    for raw_n, raw_value in service_mass.items():
        n = _backlog(raw_n, name="service backlog")
        served[n] = _nonnegative(raw_value, name=f"service_mass[{n}]")

    levels = sorted(set(exposure) | set(served))
    for n in levels:
        exposure.setdefault(n, Fraction(0))
        served.setdefault(n, Fraction(0))
        if served[n] > exposure[n]:
            raise ValidationError(
                "service mass cannot exceed exposure mass",
                context={"backlog": n, "service": str(served[n]), "exposure": str(exposure[n])},
            )

    total = sum(exposure.values(), Fraction(0))
    if total == 0:
        return NormalizedLevelMasses(
            total_mass=Fraction(0),
            exposure_mass=_readonly(exposure),
            service_mass=_readonly(served),
            p=_readonly({}),
            s=_readonly({}),
            response=_readonly({}),
            departure_mean=None,
            backlog_mean=None,
            service_backlog_moment=None,
            status="no_exposure",
        )

    p = {n: exposure[n] / total for n in levels}
    s = {n: served[n] / total for n in levels}
    response = {n: served[n] / exposure[n] for n in levels if exposure[n] > 0}
    departure_mean = sum(s.values(), Fraction(0))
    backlog_mean = sum((n * p[n] for n in levels), Fraction(0))
    service_backlog_moment = sum((n * s[n] for n in levels), Fraction(0))
    return NormalizedLevelMasses(
        total_mass=total,
        exposure_mass=_readonly(exposure),
        service_mass=_readonly(served),
        p=_readonly(p),
        s=_readonly(s),
        response=_readonly(response),
        departure_mean=departure_mean,
        backlog_mean=backlog_mean,
        service_backlog_moment=service_backlog_moment,
        status="ok",
    )


@dataclass(frozen=True, slots=True)
class ArrivalMarginal:
    """Certified finite, Poisson, or finite mixed-Poisson target law.

    ``pmf`` is present only for genuinely finite laws. Infinite support is
    represented by its finite Poisson-mixture parameters and is never
    approximated by an enumerated table.
    """

    pmf: Mapping[int, Fraction] | None
    mean: Fraction
    second_moment: Fraction
    fresh_iid: bool = True
    variance: Fraction | None = None
    family: str = "finite_pmf"
    poisson_components: tuple[tuple[Fraction, Fraction], ...] = ()

    def __post_init__(self) -> None:
        if self.variance is None:
            object.__setattr__(self, "variance", self.second_moment - self.mean * self.mean)
        assert self.variance is not None
        if self.mean < 0 or self.variance < 0 or self.second_moment < 0:
            raise ValidationError("arrival moments must be non-negative")
        if self.pmf is None and not self.poisson_components:
            raise ValidationError("an infinite arrival law must provide certified components")
        if self.pmf is not None and self.poisson_components:
            raise ValidationError("an arrival law cannot be both finite and Poisson-mixture")

    @classmethod
    def from_pmf(
        cls,
        pmf: Mapping[int, RationalInput],
        *,
        fresh_iid: bool = True,
        family: str = "finite_pmf",
    ) -> "ArrivalMarginal":
        if not isinstance(family, str) or not family:
            raise ValidationError("arrival-law family must be a nonempty string")
        normalized: dict[int, Fraction] = {}
        for raw_a, raw_probability in pmf.items():
            a = _backlog(raw_a, name="arrival value")
            normalized[a] = _nonnegative(raw_probability, name=f"arrival pmf[{a}]")
        total = sum(normalized.values(), Fraction(0))
        if total != 1:
            raise ValidationError("arrival pmf must sum exactly to one", context={"sum": str(total)})
        mean = sum((a * probability for a, probability in normalized.items()), Fraction(0))
        second = sum((a * a * probability for a, probability in normalized.items()), Fraction(0))
        return cls(
            _readonly(normalized),
            mean,
            second,
            bool(fresh_iid),
            second - mean * mean,
            family,
        )

    @classmethod
    def poisson(
        cls,
        rate: RationalInput,
        *,
        fresh_iid: bool = True,
    ) -> "ArrivalMarginal":
        theta = _nonnegative(rate, name="Poisson rate")
        return cls(
            None,
            theta,
            theta + theta * theta,
            bool(fresh_iid),
            theta,
            "iid_independent_poisson",
            ((Fraction(1), theta),),
        )

    @classmethod
    def mixed_poisson(
        cls,
        rate: RationalInput,
        states: Iterable[tuple[RationalInput, RationalInput]],
        *,
        fresh_iid: bool = True,
    ) -> "ArrivalMarginal":
        base_rate = _nonnegative(rate, name="mixed-Poisson base rate")
        normalized: list[tuple[Fraction, Fraction]] = []
        multiplier_mean = Fraction(0)
        multiplier_second = Fraction(0)
        for index, (raw_probability, raw_multiplier) in enumerate(states):
            probability = _nonnegative(
                raw_probability,
                name=f"mixed-Poisson state[{index}] probability",
            )
            multiplier = _nonnegative(
                raw_multiplier,
                name=f"mixed-Poisson state[{index}] multiplier",
            )
            normalized.append((probability, base_rate * multiplier))
            multiplier_mean += probability * multiplier
            multiplier_second += probability * multiplier * multiplier
        if not normalized:
            raise ValidationError("mixed-Poisson states must not be empty")
        total = sum((probability for probability, _theta in normalized), Fraction(0))
        if total != 1:
            raise ValidationError(
                "mixed-Poisson probabilities must sum exactly to one",
                context={"sum": str(total)},
            )
        if multiplier_mean != 1:
            raise ValidationError(
                "mixed-Poisson multiplier mean must equal one",
                context={"mean": str(multiplier_mean)},
            )
        second = base_rate + base_rate * base_rate * multiplier_second
        variance = second - base_rate * base_rate
        return cls(
            None,
            base_rate,
            second,
            bool(fresh_iid),
            variance,
            "iid_mixed_poisson",
            tuple(normalized),
        )

    from_poisson = poisson
    from_mixed_poisson = mixed_poisson

    def expectation(self, function: Callable[[int], int | Fraction]) -> Fraction:
        if self.pmf is None:
            raise ValidationError(
                "generic expectations are unavailable for an infinite arrival law"
            )
        return sum(
            (probability * _fraction(function(a), name="arrival function value") for a, probability in self.pmf.items()),
            Fraction(0),
        )

    def shifted_expectation(
        self,
        state: int,
        function: Callable[[int], int | Fraction],
    ) -> CertifiedEvaluation:
        if isinstance(state, bool) or not isinstance(state, int):
            raise ValidationError("arrival expectation state must be an integer")
        if self.pmf is None:
            return CertifiedEvaluation.unavailable("generic_expectation_unavailable")
        return CertifiedEvaluation.exact(
            sum(
                (
                    probability
                    * _fraction(function(state + arrival), name="arrival function value")
                    for arrival, probability in self.pmf.items()
                ),
                Fraction(0),
            )
        )

    def stop_loss(self, x: int, cutoff: int) -> CertifiedEvaluation:
        if isinstance(x, bool) or not isinstance(x, int):
            raise ValidationError("stop-loss state must be an integer", context={"x": x})
        k = _backlog(cutoff, name="cutoff")
        if self.pmf is not None:
            return CertifiedEvaluation.exact(
                sum(
                    (
                        probability * max(int(x) + arrival - k, 0)
                        for arrival, probability in self.pmf.items()
                    ),
                    Fraction(0),
                )
            )
        return _weighted_evaluations(
            (
                weight,
                _poisson_stop_loss(component_rate, int(x), k),
            )
            for weight, component_rate in self.poisson_components
            if weight != 0
        )

    # Explicit spelling for callers that want to emphasize the certificate.
    stop_loss_evaluation = stop_loss


@dataclass(frozen=True, slots=True)
class CutoffResult:
    cutoff: int
    tau: Fraction
    service_tail_mass: Fraction
    backlog_tail_mass: Fraction
    service_backlog_tail_mass: Fraction
    tail_service: Fraction | None
    slack: Fraction | None
    association: Fraction | None
    tail_mean_share: Fraction | None
    compression_defect: Fraction | None
    status: str
    numerical_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"


def cutoff_analysis(
    masses: NormalizedLevelMasses,
    cutoff: int,
    arrival_mean: RationalInput | None,
    *,
    fresh_iid: bool = True,
    drops: RationalInput = 0,
) -> CutoffResult:
    k = _backlog(cutoff, name="cutoff")
    if masses.status != "ok":
        return CutoffResult(k, Fraction(0), Fraction(0), Fraction(0), Fraction(0), None, None, None, None, None, masses.status)

    tau = sum((p for n, p in masses.p.items() if n > k), Fraction(0))
    b = sum((m for n, m in masses.s.items() if n > k), Fraction(0))
    u = sum((n * p for n, p in masses.p.items() if n > k), Fraction(0))
    v = sum((n * m for n, m in masses.s.items() if n > k), Fraction(0))
    share = None if masses.backlog_mean in {None, 0} else u / masses.backlog_mean
    if tau == 0:
        return CutoffResult(k, tau, b, u, v, None, None, None, share, None, "no_tail_exposure")

    c = b / tau
    association = v - c * u
    if arrival_mean is None:
        return CutoffResult(k, tau, b, u, v, c, None, association, share, None, "arrival_law_unavailable")
    lam = _nonnegative(arrival_mean, name="arrival_mean")
    slack = c - lam
    defect = None if slack == 0 else association / slack
    if _nonnegative(drops, name="drops") > 0:
        status = "drop_affected"
    elif not fresh_iid:
        status = "not_fresh_iid"
    elif masses.departure_mean == 0:
        status = "no_observed_service"
    elif slack <= 0:
        status = "nonpositive_tail_slack"
    else:
        status = "ok"
    return CutoffResult(k, tau, b, u, v, c, slack, association, share, defect, status)


def cutoff_sweep(
    masses: NormalizedLevelMasses,
    cutoffs: Iterable[int],
    arrival_mean: RationalInput | None,
    *,
    fresh_iid: bool = True,
    drops: RationalInput = 0,
) -> tuple[CutoffResult, ...]:
    normalized = sorted({_backlog(cutoff, name="cutoff") for cutoff in cutoffs})
    return tuple(
        cutoff_analysis(masses, cutoff, arrival_mean, fresh_iid=fresh_iid, drops=drops)
        for cutoff in normalized
    )


def beta_k_evaluation(
    masses: NormalizedLevelMasses,
    cutoff: int,
    arrival: CertifiedArrivalLaw,
) -> CertifiedEvaluation:
    """Compute beta_K with the arrival law's numerical certificate."""

    if masses.status != "ok":
        return CertifiedEvaluation.unavailable(masses.status)
    if not arrival.fresh_iid:
        return CertifiedEvaluation.unavailable("not_fresh_iid")
    k = _backlog(cutoff, name="cutoff")
    terms: list[tuple[Fraction, CertifiedEvaluation]] = []
    for backlog in range(k + 1):
        exposure = masses.p.get(backlog, Fraction(0))
        service = masses.s.get(backlog, Fraction(0))
        if exposure != service:
            terms.append((exposure - service, arrival.stop_loss(backlog, k)))
        if service != 0:
            terms.append((service, arrival.stop_loss(backlog - 1, k)))
    return _weighted_evaluations(terms)


def beta_k(
    masses: NormalizedLevelMasses,
    cutoff: int,
    arrival: CertifiedArrivalLaw,
) -> CertifiedEvaluation:
    """Return beta_K with value, absolute error bound, and status."""

    return beta_k_evaluation(masses, cutoff, arrival)


def beta_k_value(
    masses: NormalizedLevelMasses,
    cutoff: int,
    arrival: CertifiedArrivalLaw,
) -> AnalysisNumber | None:
    """Compatibility value view; scientific output should retain ``beta_k``."""

    evaluation = beta_k_evaluation(masses, cutoff, arrival)
    return evaluation.value if evaluation.available else None


@dataclass(frozen=True, slots=True)
class EmpiricalErrorResult:
    cutoff: int
    observed_prefix_balance: Fraction | None
    fitted_prefix_balance: Fraction | None
    stationarity_residual: Fraction | None
    tail_association_term: Fraction | None
    prefix_balance_term: Fraction | None
    stationarity_term: Fraction | None
    total_error: Fraction | None
    fitted_tail_mass: Fraction | None
    fitted_mean: Fraction | None
    status: str


def empirical_error_accounting(
    masses: NormalizedLevelMasses,
    cutoff: CutoffResult,
    *,
    arrival_mean: RationalInput,
    arrival_second_moment: RationalInput,
    input_response: Mapping[int, RationalInput],
    fitted_prefix: Mapping[int, RationalInput],
    fitted_tail_mass: RationalInput | None = None,
    fitted_mean: RationalInput | None = None,
) -> EmpiricalErrorResult:
    if masses.status != "ok":
        return EmpiricalErrorResult(cutoff.cutoff, None, None, None, None, None, None, None, None, None, masses.status)
    if cutoff.tail_service is None or cutoff.slack is None or cutoff.association is None:
        return EmpiricalErrorResult(cutoff.cutoff, None, None, None, None, None, None, None, None, None, cutoff.status)

    k = cutoff.cutoff
    c = cutoff.tail_service
    responses = {int(n): _fraction(value, name=f"input_response[{n}]") for n, value in input_response.items()}
    fitted = {int(n): _nonnegative(value, name=f"fitted_prefix[{n}]") for n, value in fitted_prefix.items()}
    missing = tuple(n for n in range(k + 1) if fitted.get(n, 0) > 0 and n not in responses)
    if missing:
        return EmpiricalErrorResult(k, None, None, None, None, None, None, None, None, None, "decoder_profile_unsupported")

    c_observed = sum(
        (n * (c * masses.p.get(n, Fraction(0)) - masses.s.get(n, Fraction(0))) for n in range(k + 1)),
        Fraction(0),
    )
    c_fitted = sum(
        (n * fitted.get(n, Fraction(0)) * (c - responses.get(n, Fraction(0))) for n in range(k + 1)),
        Fraction(0),
    )
    lam = _nonnegative(arrival_mean, name="arrival_mean")
    m2 = _nonnegative(arrival_second_moment, name="arrival_second_moment")
    base = (m2 + lam - 2 * lam * lam) / 2
    assert masses.service_backlog_moment is not None and masses.backlog_mean is not None
    residual = masses.service_backlog_moment - lam * masses.backlog_mean - base

    tail_term = None if cutoff.slack == 0 else cutoff.association / cutoff.slack
    prefix_term = None if cutoff.slack == 0 else (c_fitted - c_observed) / cutoff.slack
    stationarity_term = None if cutoff.slack == 0 else -residual / cutoff.slack
    total = None if tail_term is None else tail_term + prefix_term + stationarity_term  # type: ignore[operator]
    status = cutoff.status if cutoff.status != "ok" else "ok"
    return EmpiricalErrorResult(
        k,
        c_observed,
        c_fitted,
        residual,
        tail_term,
        prefix_term,
        stationarity_term,
        total,
        None if fitted_tail_mass is None else _nonnegative(fitted_tail_mass, name="fitted_tail_mass"),
        None if fitted_mean is None else _nonnegative(fitted_mean, name="fitted_mean"),
        status,
    )


def _boundary_distribution(raw: Mapping[int, RationalInput], *, name: str) -> Mapping[int, Fraction]:
    masses: dict[int, Fraction] = {}
    for raw_n, raw_mass in raw.items():
        n = _backlog(raw_n, name=f"{name} backlog")
        masses[n] = _nonnegative(raw_mass, name=f"{name}[{n}]")
    total = sum(masses.values(), Fraction(0))
    if total <= 0:
        raise ValidationError(f"{name} must have positive total mass")
    return _readonly({n: value / total for n, value in masses.items()})


def _moment(distribution: Mapping[int, Fraction], function: Callable[[int], int]) -> Fraction:
    return sum((mass * function(n) for n, mass in distribution.items()), Fraction(0))


@dataclass(frozen=True, slots=True)
class FiniteWindowResult:
    slots: int
    eta_1: Fraction
    eta_2: Fraction
    expected_eta_1: Fraction | None
    expected_eta_2: Fraction | None
    z_from_endpoints: Fraction | None
    eta_k: Fraction | None
    beta_k: AnalysisNumber | None
    tail_slack_left: Fraction | None
    tail_slack_right: AnalysisNumber | None
    status: str
    beta_k_error_bound: AnalysisNumber | None = Fraction(0)
    tail_slack_right_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"

    @property
    def beta_error_bound(self) -> AnalysisNumber | None:
        return self.beta_k_error_bound


def finite_window_accounting(
    masses: NormalizedLevelMasses,
    start_boundary: Mapping[int, RationalInput],
    end_boundary: Mapping[int, RationalInput],
    slots: int,
    arrival: CertifiedArrivalLaw,
    *,
    cutoff: CutoffResult | None = None,
    drops: RationalInput = 0,
) -> FiniteWindowResult:
    if isinstance(slots, bool) or not isinstance(slots, int) or slots <= 0:
        raise ValidationError("slots must be a positive integer", context={"slots": slots})
    start = _boundary_distribution(start_boundary, name="start_boundary")
    end = _boundary_distribution(end_boundary, name="end_boundary")
    eta1 = (_moment(end, lambda n: n) - _moment(start, lambda n: n)) / slots
    eta2 = (_moment(end, lambda n: n * n) - _moment(start, lambda n: n * n)) / slots
    if masses.status != "ok":
        return FiniteWindowResult(
            slots,
            eta1,
            eta2,
            Fraction(0),
            Fraction(0),
            Fraction(0),
            None,
            None,
            None,
            None,
            masses.status,
            None,
            None,
            masses.status,
        )
    assert masses.departure_mean is not None
    assert masses.backlog_mean is not None
    assert masses.service_backlog_moment is not None
    expected_eta1 = arrival.mean - masses.departure_mean
    expected_eta2 = (
        2 * arrival.mean * masses.backlog_mean
        - 2 * masses.service_backlog_moment
        + (1 - 2 * arrival.mean) * masses.departure_mean
        + arrival.second_moment
    )
    z_endpoint = -((1 - 2 * arrival.mean) * eta1 + eta2) / 2

    eta_hinge = beta = left = right = None
    beta_error: AnalysisNumber | None = Fraction(0)
    right_error: AnalysisNumber | None = Fraction(0)
    numerical_status = "exact"
    if cutoff is not None:
        k = cutoff.cutoff
        eta_hinge = (_moment(end, lambda n: max(n - k, 0)) - _moment(start, lambda n: max(n - k, 0))) / slots
        beta_evaluation = beta_k_evaluation(masses, k, arrival)
        beta = beta_evaluation.value
        beta_error = beta_evaluation.error_bound
        numerical_status = beta_evaluation.status
        # b_K - lambda*tau_K remains identified even when tau_K is zero and
        # c_K=b_K/tau_K is therefore undefined.  Do not route this balance
        # quantity through c_K or the derived slack.
        left = cutoff.service_tail_mass - arrival.mean * cutoff.tau
        right_evaluation = _subtract_exact(beta_evaluation, eta_hinge)
        right = right_evaluation.value
        right_error = right_evaluation.error_bound
        if not right_evaluation.available:
            numerical_status = right_evaluation.status

    if _nonnegative(drops, name="drops") > 0:
        status = "drop_affected"
    elif not arrival.fresh_iid:
        status = "not_fresh_iid"
    elif masses.departure_mean == 0:
        status = "no_observed_service"
    elif cutoff is not None and numerical_status not in {"exact", "ok"}:
        status = numerical_status
    else:
        status = "ok"
    return FiniteWindowResult(
        slots,
        eta1,
        eta2,
        expected_eta1,
        expected_eta2,
        z_endpoint,
        eta_hinge,
        beta,
        left,
        right,
        status,
        beta_error,
        right_error,
        numerical_status,
    )


@dataclass(frozen=True, slots=True)
class InnovationResult:
    innovation: AnalysisNumber | None
    endpoint_drift: Fraction | None
    observed_mean: Fraction | None
    expected_next_mean: AnalysisNumber | None
    status: str
    numerical_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"


def weighted_innovation(
    masses: NormalizedLevelMasses,
    start_boundary: Mapping[int, RationalInput],
    end_boundary: Mapping[int, RationalInput],
    slots: int,
    arrival: CertifiedArrivalLaw,
    function: Callable[[int], int],
    *,
    drops: RationalInput = 0,
) -> InnovationResult:
    """Reconstruct J_f without retaining a per-slot innovation trace."""

    if isinstance(slots, bool) or not isinstance(slots, int) or slots <= 0:
        raise ValidationError("slots must be a positive integer", context={"slots": slots})
    if masses.status != "ok":
        return InnovationResult(None, None, None, None, masses.status)
    start = _boundary_distribution(start_boundary, name="start_boundary")
    end = _boundary_distribution(end_boundary, name="end_boundary")
    endpoint = (_moment(end, function) - _moment(start, function)) / slots
    observed = sum((mass * function(n) for n, mass in masses.p.items()), Fraction(0))

    terms: list[tuple[Fraction, CertifiedEvaluation]] = []
    for backlog in masses.p:
        exposure = masses.p.get(backlog, Fraction(0))
        service = masses.s.get(backlog, Fraction(0))
        if exposure != service:
            terms.append(
                (exposure - service, arrival.shifted_expectation(backlog, function))
            )
        if service != 0:
            terms.append((service, arrival.shifted_expectation(backlog - 1, function)))
    expected_evaluation = _weighted_evaluations(terms)
    if not expected_evaluation.available:
        return InnovationResult(
            None,
            endpoint,
            observed,
            None,
            expected_evaluation.status,
            None,
            expected_evaluation.status,
        )
    assert expected_evaluation.value is not None
    observed_and_endpoint = observed + endpoint
    innovation_evaluation = _subtract_exact(
        expected_evaluation,
        observed_and_endpoint,
    )
    if innovation_evaluation.value is not None:
        if isinstance(innovation_evaluation.value, Fraction):
            innovation: AnalysisNumber | None = -innovation_evaluation.value
        else:
            innovation = -float(innovation_evaluation.value)
    else:
        innovation = None
    if _nonnegative(drops, name="drops") > 0:
        status = "drop_affected"
    elif not arrival.fresh_iid:
        status = "not_fresh_iid"
    elif not innovation_evaluation.available:
        status = innovation_evaluation.status
    else:
        status = "ok"
    return InnovationResult(
        innovation,
        endpoint,
        observed,
        expected_evaluation.value,
        status,
        innovation_evaluation.error_bound,
        innovation_evaluation.status,
    )


__all__ = [
    "AnalysisNumber",
    "ArrivalMarginal",
    "CertifiedArrivalLaw",
    "CertifiedEvaluation",
    "CutoffResult",
    "EmpiricalErrorResult",
    "FiniteWindowResult",
    "InnovationResult",
    "NormalizedLevelMasses",
    "NumericalResult",
    "StopLossResult",
    "beta_k",
    "beta_k_evaluation",
    "beta_k_value",
    "cutoff_analysis",
    "cutoff_sweep",
    "empirical_error_accounting",
    "finite_window_accounting",
    "normalize_level_masses",
    "weighted_innovation",
]
