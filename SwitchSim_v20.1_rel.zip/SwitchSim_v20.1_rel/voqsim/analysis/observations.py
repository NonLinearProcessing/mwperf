from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
import math
from types import MappingProxyType
from typing import Iterable, Mapping

from ..errors import ValidationError
from ..telemetry.observations import (
    GAP_EXACT,
    GAP_NONE,
    MASS_BINARY64_LATTICE,
    STATUS_COMPLETE,
    CompactObservationReader,
    merge_level_streams,
)
from ..types import QueueId
from ..utils import canonical_json_dumps, normalize_for_json
from .step1 import (
    AnalysisNumber,
    CertifiedArrivalLaw,
    CertifiedEvaluation,
    CutoffResult,
    EmpiricalErrorResult,
    FiniteWindowResult,
    RationalInput,
    _subtract_exact,
    _subtract_from_exact,
    _weighted_evaluations,
)
from .step2 import (
    GapCompetitionResult,
    GapLevelResult,
    GapTailResult,
    IsolatedServerResult,
    StationaryTieResult,
    gap_competition_analysis,
    gap_level_analysis,
    gap_tail_analysis,
    isolated_server_analysis,
    stationary_tie_analysis,
)


def _cutoffs(values: Iterable[int]) -> tuple[int, ...]:
    result: set[int] = set()
    for value in values:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValidationError("cutoffs must be non-negative integers", context={"value": value})
        result.add(value)
    return tuple(sorted(result))


def _fraction(value: RationalInput, *, name: str) -> Fraction:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be numeric, not boolean")
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, Decimal) and value.is_finite():
        return Fraction(value)
    if isinstance(value, float) and math.isfinite(value):
        return Fraction.from_float(value)
    raise ValidationError(f"{name} must be an int, finite float, or Fraction")


def _compatibility_key(metadata: Mapping[str, object]) -> str:
    """Remove replication identity, while retaining every scientific condition."""

    normalized = deepcopy(dict(metadata))
    for key in ("actual_seed", "requested_seed", "ensemble_id"):
        normalized.pop(key, None)
    scientific = normalized.get("scientific_config")
    if isinstance(scientific, dict):
        run = scientific.get("run")
        if isinstance(run, dict):
            for key in ("seed", "actual_seed", "requested_seed"):
                run.pop(key, None)
    return canonical_json_dumps(normalize_for_json(normalized))


def _metadata_no_drop(metadata: Mapping[str, object]) -> bool:
    """Return true only when NoDrop is explicit in the scientific metadata."""

    policy = metadata.get("buffer_policy")
    if isinstance(policy, str) and policy == "NoDrop":
        return True
    if isinstance(policy, Mapping) and policy.get("mode") == "NoDrop":
        return True
    scientific = metadata.get("scientific_config")
    if not isinstance(scientific, Mapping):
        return False
    switch = scientific.get("switch")
    if not isinstance(switch, Mapping):
        return False
    return switch.get("queue_capacity") == "NoDrop" or switch.get("voq_capacity") == "NoDrop"


def _metadata_early_service_late_arrival(metadata: Mapping[str, object]) -> bool:
    """Recognize only documented service-before-arrival conventions."""

    convention = metadata.get("slot_convention")
    return convention in {
        "pre_service_N; service; arrivals; post_arrival_N_prime",
        "service_before_arrival",
        "service_before_arrivals",
        "early_service_late_arrival",
        "early-service/late-arrival",
    }


def _normalized_seed(value: object, *, name: str) -> int:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be a non-negative integer")
    if isinstance(value, int):
        result = value
    elif isinstance(value, str) and value and value.isascii() and value.isdigit():
        if len(value) > 1 and value.startswith("0"):
            raise ValidationError(f"{name} must use canonical decimal spelling")
        result = int(value)
    else:
        raise ValidationError(f"{name} must be a non-negative integer")
    if result < 0:
        raise ValidationError(f"{name} must be a non-negative integer")
    return result


def _actual_seed(metadata: Mapping[str, object]) -> int | None:
    value = metadata.get("actual_seed")
    if value is None:
        scientific = metadata.get("scientific_config")
        if isinstance(scientific, Mapping):
            run = scientific.get("run")
            if isinstance(run, Mapping):
                value = run.get("actual_seed")
    return None if value is None else _normalized_seed(value, name="actual_seed")


def _unit_identity(
    *,
    unit_kind: str,
    metadata: Mapping[str, object],
) -> tuple[object, ...] | None:
    """Return stable scientific-unit identity, never a path or file hash."""

    if unit_kind == "simulator_run":
        seed = _actual_seed(metadata)
        return None if seed is None else (unit_kind, seed)
    if unit_kind != "weighted_ensemble":
        raise ValidationError("unsupported observation unit kind", context={"unit_kind": unit_kind})
    seed = _actual_seed(metadata)
    ensemble_id = metadata.get("ensemble_id")
    if ensemble_id is None or seed is None:
        return None
    if isinstance(ensemble_id, bool) or not isinstance(ensemble_id, (int, str)):
        raise ValidationError("ensemble_id must be an integer or nonempty string")
    if isinstance(ensemble_id, int) and ensemble_id < 0:
        raise ValidationError("ensemble_id must be non-negative")
    if isinstance(ensemble_id, str) and not ensemble_id:
        raise ValidationError("ensemble_id must be nonempty")
    return (unit_kind, seed, ensemble_id)


def _require_weighted_scientific_metadata(
    metadata: Mapping[str, object],
    *,
    reader_index: int,
) -> None:
    """Reject weighted analysis whose scientific conditions are ambiguous."""

    required = {
        "actual_seed",
        "ensemble_id",
        "scientific_config",
        "slot_convention",
        "initial_condition",
        "random_streams",
        "buffer_policy",
        "weighting",
        "resampling",
    }
    missing = sorted(key for key in required if key not in metadata)
    invalid: list[str] = []
    for key in ("slot_convention", "initial_condition"):
        value = metadata.get(key)
        if key in metadata and not (
            (isinstance(value, str) and bool(value.strip()))
            or (isinstance(value, Mapping) and bool(value))
        ):
            invalid.append(key)
    for key in ("random_streams", "buffer_policy", "weighting", "resampling"):
        value = metadata.get(key)
        if key in metadata and not isinstance(value, Mapping):
            invalid.append(key)
        elif isinstance(value, Mapping) and not value:
            invalid.append(key)
    scientific = metadata.get("scientific_config")
    if not isinstance(scientific, Mapping):
        missing = sorted(set(missing) | {"scientific_config"})
    else:
        for key in ("arrival", "scheduler", "switch"):
            section = scientific.get(key)
            if key not in scientific:
                missing.append(f"scientific_config.{key}")
            elif not isinstance(section, Mapping) or not section:
                invalid.append(f"scientific_config.{key}")
        arrival = scientific.get("arrival")
        if isinstance(arrival, Mapping):
            family = arrival.get("family")
            if not isinstance(family, str) or not family.strip():
                invalid.append("scientific_config.arrival.family")
        scheduler = scientific.get("scheduler")
        if isinstance(scheduler, Mapping):
            name = scheduler.get("name")
            tie_policy = scheduler.get("tie_policy")
            if not isinstance(name, str) or not name.strip():
                invalid.append("scientific_config.scheduler.name")
            if not isinstance(tie_policy, (str, Mapping)) or not tie_policy:
                invalid.append("scientific_config.scheduler.tie_policy")
    if missing or invalid:
        raise ValidationError(
            "weighted ensemble lacks required scientific metadata",
            context={
                "reader_index": reader_index,
                "missing": sorted(set(missing)),
                "invalid": sorted(set(invalid)),
            },
        )


def _fitted_distribution(
    *,
    cutoff: int,
    fitted_prefix: Mapping[int, RationalInput],
    fitted_tail_mass: RationalInput | None,
    fitted_mean: RationalInput | None,
) -> tuple[dict[int, Fraction], Fraction | None, Fraction | None]:
    fitted: dict[int, Fraction] = {}
    for backlog, value in fitted_prefix.items():
        if isinstance(backlog, bool) or not isinstance(backlog, int):
            raise ValidationError(
                "fitted prefix backlog keys must be integers",
                context={"backlog": backlog},
            )
        if backlog < 0 or backlog > cutoff:
            raise ValidationError(
                "fitted prefix backlog lies outside the decoded prefix",
                context={"backlog": backlog, "cutoff": cutoff},
            )
        probability = _fraction(value, name=f"fitted_prefix[{backlog}]")
        if probability < 0:
            raise ValidationError("fitted prefix probabilities must be non-negative")
        fitted[backlog] = probability

    prefix_mass = sum(fitted.values(), Fraction(0))
    if prefix_mass > 1:
        raise ValidationError(
            "fitted prefix probability mass cannot exceed one",
            context={"prefix_mass": str(prefix_mass)},
        )
    implied_tail = 1 - prefix_mass
    tail = None
    if fitted_tail_mass is not None:
        tail = _fraction(fitted_tail_mass, name="fitted_tail_mass")
        if tail < 0 or tail > 1:
            raise ValidationError("fitted_tail_mass must lie in [0, 1]")
        if tail != implied_tail:
            raise ValidationError(
                "fitted prefix and tail probability masses must sum exactly to one",
                context={"prefix_mass": str(prefix_mass), "tail_mass": str(tail)},
            )

    mean = None
    if fitted_mean is not None:
        mean = _fraction(fitted_mean, name="fitted_mean")
        if mean < 0:
            raise ValidationError("fitted_mean must be non-negative")
        prefix_mean = sum(
            (backlog * probability for backlog, probability in fitted.items()),
            Fraction(0),
        )
        minimum_mean = prefix_mean + (cutoff + 1) * implied_tail
        if mean < minimum_mean:
            raise ValidationError(
                "fitted_mean is inconsistent with fitted prefix and tail masses",
                context={"minimum_mean": str(minimum_mean), "fitted_mean": str(mean)},
            )
        if implied_tail == 0 and mean != prefix_mean:
            raise ValidationError(
                "fitted_mean must equal the fitted prefix mean when tail mass is zero",
                context={"prefix_mean": str(prefix_mean), "fitted_mean": str(mean)},
            )
    return fitted, tail, mean


@dataclass(frozen=True, slots=True)
class BoundaryMoments:
    mass: int
    backlog: int
    backlog_square: int
    hinge: Mapping[int, int]

    def mean_backlog(self) -> Fraction:
        return Fraction(self.backlog, self.mass)

    def mean_backlog_square(self) -> Fraction:
        return Fraction(self.backlog_square, self.mass)

    def mean_hinge(self, cutoff: int) -> Fraction:
        return Fraction(self.hinge[cutoff], self.mass)


@dataclass(frozen=True, slots=True)
class PooledTargetBlock:
    """Exact pooled sufficient statistics with memory bounded by requested K."""

    unit_kind: str
    unit_count: int
    target_id: str
    queue_id: QueueId
    mass_kind: str
    gap_mode: str
    block_id: int
    start_slot: int
    stop_slot: int
    exposure: int
    served: int
    backlog_exposure: int
    backlog_square_exposure: int
    backlog_service: int
    prefix_exposure: Mapping[int, int]
    prefix_service: Mapping[int, int]
    tail_masses: Mapping[int, tuple[int, int, int, int]]
    start_boundary: BoundaryMoments
    end_boundary: BoundaryMoments
    slots_observed: int
    decision_mass: int
    offered: int
    offered_square: int
    admitted: int
    admitted_square: int
    dropped: int
    gap_negative: int | None
    gap_zero: int | None
    gap_positive: int | None
    gap_zero_served: int | None
    gap_positive_sum: int | None
    gap_negative_sum: int | None
    gap_negative_backlog: int | None
    gap_zero_unserved_backlog: int | None
    tail_gap_masses: Mapping[int, tuple[int, int]] | None
    no_drop: bool
    early_service_late_arrival: bool

    @property
    def length(self) -> int:
        return self.stop_slot - self.start_slot

    @property
    def departure_mean(self) -> Fraction:
        return Fraction(self.served, self.exposure)

    @property
    def backlog_mean(self) -> Fraction:
        return Fraction(self.backlog_exposure, self.exposure)

    @property
    def backlog_second_moment(self) -> Fraction:
        return Fraction(self.backlog_square_exposure, self.exposure)

    @property
    def service_backlog_moment(self) -> Fraction:
        return Fraction(self.backlog_service, self.exposure)

    @property
    def offered_mean(self) -> Fraction:
        return Fraction(self.offered, self.exposure)

    @property
    def offered_second_moment(self) -> Fraction:
        return Fraction(self.offered_square, self.exposure)

    @property
    def offered_variance(self) -> Fraction:
        return self.offered_second_moment - self.offered_mean * self.offered_mean

    def response(self, backlog: int) -> Fraction | None:
        exposure = self.prefix_exposure.get(backlog, 0)
        return None if exposure == 0 else Fraction(self.prefix_service.get(backlog, 0), exposure)

    def cutoff(self, cutoff: int, arrival: CertifiedArrivalLaw | None) -> CutoffResult:
        if cutoff not in self.tail_masses:
            raise ValidationError("cutoff was not requested while streaming", context={"cutoff": cutoff})
        tail_exposure, tail_service, tail_backlog, tail_backlog_service = self.tail_masses[cutoff]
        if self.exposure == 0:
            return CutoffResult(cutoff, Fraction(0), Fraction(0), Fraction(0), Fraction(0), None, None, None, None, None, "no_exposure")
        tau = Fraction(tail_exposure, self.exposure)
        b = Fraction(tail_service, self.exposure)
        u = Fraction(tail_backlog, self.exposure)
        v = Fraction(tail_backlog_service, self.exposure)
        share = None if self.backlog_exposure == 0 else Fraction(tail_backlog, self.backlog_exposure)
        if tail_exposure == 0:
            return CutoffResult(cutoff, tau, b, u, v, None, None, None, share, None, "no_tail_exposure")
        tail_rate = Fraction(tail_service, tail_exposure)
        association = v - tail_rate * u
        if arrival is None:
            return CutoffResult(cutoff, tau, b, u, v, tail_rate, None, association, share, None, "arrival_law_unavailable")
        slack = tail_rate - arrival.mean
        defect = None if slack == 0 else association / slack
        if self.dropped > 0:
            status = "drop_affected"
        elif not arrival.fresh_iid:
            status = "not_fresh_iid"
        elif self.served == 0:
            status = "no_observed_service"
        elif slack <= 0:
            status = "nonpositive_tail_slack"
        else:
            status = "ok"
        return CutoffResult(cutoff, tau, b, u, v, tail_rate, slack, association, share, defect, status)

    def beta_evaluation(
        self,
        cutoff: int,
        arrival: CertifiedArrivalLaw,
    ) -> CertifiedEvaluation:
        if cutoff not in self.tail_masses:
            raise ValidationError("cutoff was not requested while streaming", context={"cutoff": cutoff})
        if not arrival.fresh_iid:
            return CertifiedEvaluation.unavailable("not_fresh_iid")
        terms: list[tuple[Fraction, CertifiedEvaluation]] = []
        for backlog in range(cutoff + 1):
            exposure = Fraction(self.prefix_exposure.get(backlog, 0), self.exposure)
            service = Fraction(self.prefix_service.get(backlog, 0), self.exposure)
            if exposure != service:
                terms.append((exposure - service, arrival.stop_loss(backlog, cutoff)))
            if service != 0:
                terms.append((service, arrival.stop_loss(backlog - 1, cutoff)))
        return _weighted_evaluations(terms)

    def beta(
        self,
        cutoff: int,
        arrival: CertifiedArrivalLaw,
    ) -> CertifiedEvaluation:
        return self.beta_evaluation(cutoff, arrival)

    def beta_value(
        self,
        cutoff: int,
        arrival: CertifiedArrivalLaw,
    ) -> AnalysisNumber | None:
        evaluation = self.beta_evaluation(cutoff, arrival)
        return evaluation.value if evaluation.available else None

    def input_coefficients(self, cutoff: int) -> Mapping[str, object]:
        result: dict[str, object] = {
            "mu": {
                backlog: self.response(backlog)
                for backlog in range(1, cutoff + 1)
                if self.response(backlog) is not None
            }
        }
        tail = self.tail_masses.get(cutoff)
        result["c_K"] = None if tail is None or tail[0] == 0 else Fraction(tail[1], tail[0])
        return MappingProxyType(result)

    def competition(self) -> GapCompetitionResult:
        return gap_competition_analysis(
            exposure=self.exposure,
            backlog_exposure=self.backlog_exposure,
            gap_positive_sum=self.gap_positive_sum,
            gap_negative_sum=self.gap_negative_sum,
        )

    def gap_cutoff(
        self,
        cutoff: CutoffResult,
        *,
        stationary_interpretation: bool = False,
    ) -> GapTailResult:
        gap_tail = None if self.tail_gap_masses is None else self.tail_gap_masses[cutoff.cutoff]
        return gap_tail_analysis(
            cutoff,
            exposure=self.exposure,
            gap_positive_tail_sum=None if gap_tail is None else gap_tail[0],
            gap_negative_tail_sum=None if gap_tail is None else gap_tail[1],
            stationary_interpretation=stationary_interpretation,
        )

    def tie_decomposition(
        self,
        arrival: CertifiedArrivalLaw | None,
        *,
        stationary_interpretation: bool = False,
    ) -> StationaryTieResult:
        return stationary_tie_analysis(
            exposure=self.exposure,
            backlog_exposure=self.backlog_exposure,
            gap_negative_backlog=self.gap_negative_backlog,
            gap_zero_unserved_backlog=self.gap_zero_unserved_backlog,
            arrival=arrival,
            drops=self.dropped,
            stationary_interpretation=stationary_interpretation,
        )

    def isolated_server(
        self,
        arrival: CertifiedArrivalLaw | None,
        *,
        stationary_interpretation: bool = False,
        no_drop: bool | None = None,
        early_service_late_arrival: bool | None = None,
    ) -> IsolatedServerResult:
        if no_drop is not None and not isinstance(no_drop, bool):
            raise ValidationError("no_drop must be boolean when supplied")
        if early_service_late_arrival is not None and not isinstance(
            early_service_late_arrival,
            bool,
        ):
            raise ValidationError(
                "early_service_late_arrival must be boolean when supplied"
            )
        # Observation provenance is authoritative. Optional caller flags may
        # conservatively disable an interpretation, but can never upgrade a
        # finite-buffer artifact or an unsupported slot convention.
        effective_no_drop = self.no_drop and no_drop is not False
        effective_convention = (
            self.early_service_late_arrival
            and early_service_late_arrival is not False
        )
        return isolated_server_analysis(
            exposure=self.exposure,
            backlog_exposure=self.backlog_exposure,
            backlog_service=self.backlog_service,
            arrival=arrival,
            offered=self.offered,
            offered_square=self.offered_square,
            drops=self.dropped,
            no_drop=effective_no_drop,
            stationary_interpretation=stationary_interpretation,
            early_service_late_arrival=effective_convention,
        )


@dataclass(frozen=True, slots=True)
class InnovationCorrections:
    """Finite-window innovations and their explicit tail-balance closure.

    ``hinge`` is the uncorrected residual ``left - right``.  The final field
    records the exact algebraic closure implied by that definition; it is not
    an independent stationarity test.
    """

    cutoff: int
    backlog: Fraction
    backlog_square: Fraction
    hinge: AnalysisNumber | None
    status: str
    numerical_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"
    innovation_corrected_balance_residual: AnalysisNumber | None = None
    innovation_corrected_balance_residual_status: str = "unavailable"


@dataclass(frozen=True, slots=True)
class StreamingBlockAnalysis:
    pooled: PooledTargetBlock
    cutoffs: tuple[CutoffResult, ...]
    finite_windows: tuple[FiniteWindowResult, ...]
    innovations: tuple[InnovationCorrections, ...]
    gap_competition: GapCompetitionResult
    gap_cutoffs: tuple[GapTailResult, ...]
    stationary_tie: StationaryTieResult
    isolated_server: IsolatedServerResult

    @property
    def isolated_reference(self) -> IsolatedServerResult:
        return self.isolated_server

    @property
    def isolated_baseline(self) -> IsolatedServerResult:
        return self.isolated_server

    @property
    def isolated(self) -> IsolatedServerResult:
        return self.isolated_server


def pool_target_block(
    readers: Iterable[CompactObservationReader],
    *,
    target_id: str,
    block_id: int,
    cutoffs: Iterable[int],
) -> PooledTargetBlock:
    """Pool complete units in a streaming pass without retaining all levels."""

    units = tuple(readers)
    if not units:
        raise ValidationError("at least one complete observation reader is required")
    requested = _cutoffs(cutoffs)
    maximum = max(requested, default=-1)

    baseline: tuple[object, ...] | None = None
    compatibility: str | None = None
    no_drop = False
    early_service_late_arrival = False
    scientific_units: set[tuple[object, ...]] = set()
    exposure = served = backlog_exposure = backlog_square = backlog_service = 0
    prefix_exposure: dict[int, int] = {}
    prefix_service: dict[int, int] = {}
    tails: dict[int, list[int]] = {cutoff: [0, 0, 0, 0] for cutoff in requested}
    tail_gaps: dict[int, list[int]] = {cutoff: [0, 0] for cutoff in requested}
    gap_totals = [0, 0, 0, 0, 0, 0]
    gap_negative_backlog = 0
    gap_zero_unserved_backlog = 0
    boundaries = {
        "start": [0, 0, 0, {cutoff: 0 for cutoff in requested}],
        "end": [0, 0, 0, {cutoff: 0 for cutoff in requested}],
    }
    slots_observed = decision_mass = offered = offered_square = 0
    admitted = admitted_square = dropped = 0

    for reader_index, reader in enumerate(units):
        if reader.state.status != STATUS_COMPLETE:
            raise ValidationError(
                "only complete observation units may be pooled",
                context={"reader_index": reader_index, "status": reader.state.status},
            )
        if not isinstance(reader.state.metadata, Mapping):
            raise ValidationError(
                "observation unit has invalid scientific metadata",
                context={"reader_index": reader_index},
            )
        if reader.state.unit_kind == "weighted_ensemble":
            _require_weighted_scientific_metadata(
                reader.state.metadata,
                reader_index=reader_index,
            )
        targets = tuple(reader.iter_targets(target_id=target_id))
        blocks = tuple(reader.iter_blocks(block_id=block_id))
        if len(targets) != 1 or len(blocks) != 1:
            raise ValidationError(
                "requested target or block is absent",
                context={"reader_index": reader_index, "target_id": target_id, "block_id": block_id},
            )
        target = targets[0]
        block = blocks[0]
        identity = (
            reader.state.unit_kind,
            target.queue_id,
            target.mass_kind,
            target.gap_mode,
            block.start_slot,
            block.stop_slot,
        )
        key = _compatibility_key(reader.state.metadata)
        if baseline is None:
            baseline = identity
            compatibility = key
            no_drop = _metadata_no_drop(reader.state.metadata)
            early_service_late_arrival = _metadata_early_service_late_arrival(
                reader.state.metadata
            )
        elif identity != baseline or key != compatibility:
            raise ValidationError(
                "observation units have incompatible scientific conditions",
                context={"reader_index": reader_index, "target_id": target_id, "block_id": block_id},
            )

        unit_identity = _unit_identity(
            unit_kind=reader.state.unit_kind,
            metadata=reader.state.metadata,
        )
        if len(units) > 1 and unit_identity is None:
            required = (
                "actual_seed"
                if reader.state.unit_kind == "simulator_run"
                else "actual_seed and ensemble_id"
            )
            raise ValidationError(
                "cannot verify independent scientific unit identity",
                context={"reader_index": reader_index, "required_metadata": required},
            )
        if unit_identity is not None:
            if unit_identity in scientific_units:
                raise ValidationError(
                    "duplicate independent scientific unit",
                    context={"reader_index": reader_index, "unit_kind": reader.state.unit_kind},
                )
            scientific_units.add(unit_identity)

        for row in reader.iter_levels(target_id=target_id, block_id=block_id):
            if row.mass_kind != target.mass_kind:
                raise ValidationError("level mass kind disagrees with target declaration")
            if row.gap_mode != target.gap_mode:
                raise ValidationError("level gap mode disagrees with target declaration")
            gap_level_analysis(
                backlog=row.backlog,
                exposure=row.exposure,
                served=row.served,
                gap_negative=row.gap_negative,
                gap_zero=row.gap_zero,
                gap_positive=row.gap_positive,
                gap_zero_served=row.gap_zero_served,
                gap_positive_sum=row.gap_positive_sum,
                gap_negative_sum=row.gap_negative_sum,
            )
            exposure += row.exposure
            served += row.served
            backlog_exposure += row.backlog * row.exposure
            backlog_square += row.backlog * row.backlog * row.exposure
            backlog_service += row.backlog * row.served
            if row.backlog <= maximum:
                prefix_exposure[row.backlog] = prefix_exposure.get(row.backlog, 0) + row.exposure
                prefix_service[row.backlog] = prefix_service.get(row.backlog, 0) + row.served
            if target.gap_mode == GAP_EXACT:
                exact = (
                    row.gap_negative,
                    row.gap_zero,
                    row.gap_positive,
                    row.gap_zero_served,
                    row.gap_positive_sum,
                    row.gap_negative_sum,
                )
                if any(value is None for value in exact):
                    raise ValidationError("exact target has an incomplete gap tuple")
                values = tuple(int(value) for value in exact if value is not None)
                for index, value in enumerate(values):
                    gap_totals[index] += value
                gap_negative_backlog += row.backlog * values[0]
                gap_zero_unserved_backlog += row.backlog * (values[1] - values[3])
            elif target.gap_mode == GAP_NONE:
                if any(
                    value is not None
                    for value in (
                        row.gap_negative,
                        row.gap_zero,
                        row.gap_positive,
                        row.gap_zero_served,
                        row.gap_positive_sum,
                        row.gap_negative_sum,
                    )
                ):
                    raise ValidationError("base-only target contains exact gap masses")
                values = None
            else:
                raise ValidationError(
                    "unsupported target gap mode",
                    context={"gap_mode": target.gap_mode},
                )
            for cutoff in requested:
                if row.backlog > cutoff:
                    tail = tails[cutoff]
                    tail[0] += row.exposure
                    tail[1] += row.served
                    tail[2] += row.backlog * row.exposure
                    tail[3] += row.backlog * row.served
                    if values is not None:
                        tail_gaps[cutoff][0] += values[4]
                        tail_gaps[cutoff][1] += values[5]

        target_blocks = tuple(
            reader.iter_target_blocks(target_id=target_id, block_id=block_id)
        )
        if len(target_blocks) != 1:
            raise ValidationError("observation unit has no unique target-block total")
        totals = target_blocks[0]
        slots_observed += totals.slots_observed
        decision_mass += totals.decision_mass
        offered += totals.offered
        offered_square += totals.offered_square
        admitted += totals.admitted
        admitted_square += totals.admitted_square
        dropped += totals.dropped

        for row in reader.iter_boundaries(target_id=target_id, block_id=block_id):
            if row.side not in boundaries:
                raise ValidationError("unknown observation boundary side", context={"side": row.side})
            state = boundaries[row.side]
            state[0] += row.mass
            state[1] += row.backlog * row.mass
            state[2] += row.backlog * row.backlog * row.mass
            hinge = state[3]
            assert isinstance(hinge, dict)
            for cutoff in requested:
                hinge[cutoff] += max(row.backlog - cutoff, 0) * row.mass

    assert baseline is not None
    if exposure <= 0 or decision_mass != exposure:
        raise ValidationError(
            "pooled level exposure must equal pooled decision mass",
            context={"exposure": exposure, "decision_mass": decision_mass},
        )
    if served > exposure or offered != admitted + dropped:
        raise ValidationError("pooled observation masses violate conservation")
    if boundaries["start"][0] <= 0 or boundaries["end"][0] <= 0:
        raise ValidationError("pooled observation boundaries must have positive mass")

    def freeze_boundary(side: str) -> BoundaryMoments:
        raw = boundaries[side]
        hinge = raw[3]
        assert isinstance(hinge, dict)
        return BoundaryMoments(
            int(raw[0]),
            int(raw[1]),
            int(raw[2]),
            MappingProxyType(dict(sorted(hinge.items()))),
        )

    return PooledTargetBlock(
        unit_kind=str(baseline[0]),
        unit_count=len(units),
        target_id=target_id,
        queue_id=baseline[1],  # type: ignore[arg-type]
        mass_kind=str(baseline[2]),
        gap_mode=str(baseline[3]),
        block_id=block_id,
        start_slot=int(baseline[4]),
        stop_slot=int(baseline[5]),
        exposure=exposure,
        served=served,
        backlog_exposure=backlog_exposure,
        backlog_square_exposure=backlog_square,
        backlog_service=backlog_service,
        prefix_exposure=MappingProxyType(dict(sorted(prefix_exposure.items()))),
        prefix_service=MappingProxyType(dict(sorted(prefix_service.items()))),
        tail_masses=MappingProxyType(
            {cutoff: tuple(values) for cutoff, values in sorted(tails.items())}
        ),
        start_boundary=freeze_boundary("start"),
        end_boundary=freeze_boundary("end"),
        slots_observed=slots_observed,
        decision_mass=decision_mass,
        offered=offered,
        offered_square=offered_square,
        admitted=admitted,
        admitted_square=admitted_square,
        dropped=dropped,
        gap_negative=None if baseline[3] == GAP_NONE else gap_totals[0],
        gap_zero=None if baseline[3] == GAP_NONE else gap_totals[1],
        gap_positive=None if baseline[3] == GAP_NONE else gap_totals[2],
        gap_zero_served=None if baseline[3] == GAP_NONE else gap_totals[3],
        gap_positive_sum=None if baseline[3] == GAP_NONE else gap_totals[4],
        gap_negative_sum=None if baseline[3] == GAP_NONE else gap_totals[5],
        gap_negative_backlog=(
            None if baseline[3] == GAP_NONE else gap_negative_backlog
        ),
        gap_zero_unserved_backlog=(
            None if baseline[3] == GAP_NONE else gap_zero_unserved_backlog
        ),
        tail_gap_masses=(
            None
            if baseline[3] == GAP_NONE
            else MappingProxyType(
                {cutoff: tuple(values) for cutoff, values in sorted(tail_gaps.items())}
            )
        ),
        no_drop=no_drop,
        early_service_late_arrival=early_service_late_arrival,
    )


def iter_pooled_gap_levels(
    readers: Iterable[CompactObservationReader],
    *,
    target_id: str,
    block_id: int,
) -> Iterable[GapLevelResult]:
    """Stream pooled response/gap rows without retaining the level support."""

    units = tuple(readers)
    if not units:
        raise ValidationError("at least one complete observation reader is required")
    if not isinstance(target_id, str) or not target_id:
        raise ValidationError("target_id must be a nonempty string")
    if isinstance(block_id, bool) or not isinstance(block_id, int) or block_id < 0:
        raise ValidationError("block_id must be a non-negative integer")
    for reader_index, reader in enumerate(units):
        if reader.state.status != STATUS_COMPLETE:
            raise ValidationError(
                "only complete observation units may be pooled",
                context={"reader_index": reader_index, "status": reader.state.status},
            )
        if not isinstance(reader.state.metadata, Mapping):
            raise ValidationError(
                "observation unit has invalid scientific metadata",
                context={"reader_index": reader_index},
            )
        if reader.state.unit_kind == "weighted_ensemble":
            _require_weighted_scientific_metadata(
                reader.state.metadata,
                reader_index=reader_index,
            )

    found = False
    for row in merge_level_streams(units):
        if row.target_id != target_id or row.block_id != block_id:
            continue
        found = True
        yield gap_level_analysis(
            backlog=row.backlog,
            exposure=row.exposure,
            served=row.served,
            gap_negative=row.gap_negative,
            gap_zero=row.gap_zero,
            gap_positive=row.gap_positive,
            gap_zero_served=row.gap_zero_served,
            gap_positive_sum=row.gap_positive_sum,
            gap_negative_sum=row.gap_negative_sum,
        )
    if not found:
        raise ValidationError(
            "requested target or block is absent",
            context={"target_id": target_id, "block_id": block_id},
        )


def finite_window_from_pooled(
    pooled: PooledTargetBlock,
    cutoff: CutoffResult,
    arrival: CertifiedArrivalLaw | None,
) -> FiniteWindowResult:
    length = pooled.length
    eta1 = (pooled.end_boundary.mean_backlog() - pooled.start_boundary.mean_backlog()) / length
    eta2 = (
        pooled.end_boundary.mean_backlog_square()
        - pooled.start_boundary.mean_backlog_square()
    ) / length
    eta_hinge = (
        pooled.end_boundary.mean_hinge(cutoff.cutoff)
        - pooled.start_boundary.mean_hinge(cutoff.cutoff)
    ) / length
    if arrival is None:
        return FiniteWindowResult(
            length,
            eta1,
            eta2,
            None,
            None,
            None,
            eta_hinge,
            None,
            None,
            None,
            "arrival_law_unavailable",
            None,
            None,
            "arrival_law_unavailable",
        )
    expected_eta1 = arrival.mean - pooled.departure_mean
    expected_eta2 = (
        2 * arrival.mean * pooled.backlog_mean
        - 2 * pooled.service_backlog_moment
        + (1 - 2 * arrival.mean) * pooled.departure_mean
        + arrival.second_moment
    )
    z_endpoint = -((1 - 2 * arrival.mean) * eta1 + eta2) / 2
    beta_evaluation = pooled.beta_evaluation(cutoff.cutoff, arrival)
    beta = beta_evaluation.value
    # This is b_K - lambda*tau_K.  It is identified at zero tail exposure even
    # though c_K, c_K-lambda, and every compression quantity remain undefined.
    left = cutoff.service_tail_mass - arrival.mean * cutoff.tau
    right_evaluation = _subtract_exact(beta_evaluation, eta_hinge)
    right = right_evaluation.value
    if pooled.dropped > 0:
        status = "drop_affected"
    elif not arrival.fresh_iid:
        status = "not_fresh_iid"
    elif pooled.served == 0:
        status = "no_observed_service"
    elif not right_evaluation.available:
        status = right_evaluation.status
    else:
        status = "ok"
    return FiniteWindowResult(
        length,
        eta1,
        eta2,
        expected_eta1,
        expected_eta2,
        z_endpoint,
        eta_hinge,
        beta,
        left,
        right,
        status,
        beta_evaluation.error_bound,
        right_evaluation.error_bound,
        right_evaluation.status,
    )


def innovation_from_pooled(
    pooled: PooledTargetBlock,
    cutoff: CutoffResult,
    finite: FiniteWindowResult,
) -> InnovationCorrections:
    if finite.expected_eta_1 is None or finite.expected_eta_2 is None:
        raise ValidationError("innovation corrections require an arrival law")
    hinge: AnalysisNumber | None = None
    hinge_error: AnalysisNumber | None = Fraction(0)
    numerical_status = finite.numerical_status
    if finite.tail_slack_left is not None and finite.tail_slack_right is not None:
        if finite.tail_slack_right_error_bound is None:
            raise ValidationError(
                "finite-window tail slack has no numerical error bound"
            )
        right_evaluation = CertifiedEvaluation(
            finite.tail_slack_right,
            finite.tail_slack_right_error_bound,
            finite.numerical_status,
        )
        hinge_evaluation = _subtract_from_exact(
            finite.tail_slack_left,
            right_evaluation,
        )
        if hinge_evaluation.available:
            hinge = hinge_evaluation.value
            hinge_error = hinge_evaluation.error_bound
        else:
            hinge_error = None
        numerical_status = hinge_evaluation.status
    status = "ok" if pooled.mass_kind == MASS_BINARY64_LATTICE else "expectation_only"
    if finite.status != "ok":
        status = finite.status
    elif numerical_status not in {"exact", "ok"}:
        status = numerical_status
    corrected_residual = None if hinge is None else Fraction(0)
    corrected_residual_status = (
        "unavailable" if hinge is None else "algebraic_identity_by_construction"
    )
    return InnovationCorrections(
        cutoff.cutoff,
        finite.eta_1 - finite.expected_eta_1,
        finite.eta_2 - finite.expected_eta_2,
        hinge,
        status,
        hinge_error,
        numerical_status,
        corrected_residual,
        corrected_residual_status,
    )


def empirical_error_from_pooled(
    pooled: PooledTargetBlock,
    cutoff: CutoffResult,
    *,
    arrival: CertifiedArrivalLaw,
    fitted_prefix: Mapping[int, RationalInput],
    fitted_tail_mass: RationalInput | None = None,
    fitted_mean: RationalInput | None = None,
) -> EmpiricalErrorResult:
    """Account for an authoritative decoder result without implementing a decoder."""

    fitted, tail_mass, decoded_mean = _fitted_distribution(
        cutoff=cutoff.cutoff,
        fitted_prefix=fitted_prefix,
        fitted_tail_mass=fitted_tail_mass,
        fitted_mean=fitted_mean,
    )
    if cutoff.tail_service is None or cutoff.slack is None or cutoff.association is None:
        return EmpiricalErrorResult(
            cutoff.cutoff,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            tail_mass,
            decoded_mean,
            cutoff.status,
        )
    missing = [
        backlog
        for backlog in range(cutoff.cutoff + 1)
        if fitted.get(backlog, 0) > 0 and pooled.response(backlog) is None
    ]
    if missing:
        return EmpiricalErrorResult(
            cutoff.cutoff,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            tail_mass,
            decoded_mean,
            "decoder_profile_unsupported",
        )

    c = cutoff.tail_service
    c_observed = sum(
        (
            backlog
            * (
                c * Fraction(pooled.prefix_exposure.get(backlog, 0), pooled.exposure)
                - Fraction(pooled.prefix_service.get(backlog, 0), pooled.exposure)
            )
            for backlog in range(cutoff.cutoff + 1)
        ),
        Fraction(0),
    )
    c_fitted = sum(
        (
            backlog
            * fitted.get(backlog, Fraction(0))
            * (c - (pooled.response(backlog) or Fraction(0)))
            for backlog in range(cutoff.cutoff + 1)
        ),
        Fraction(0),
    )
    base = (arrival.second_moment + arrival.mean - 2 * arrival.mean * arrival.mean) / 2
    residual = pooled.service_backlog_moment - arrival.mean * pooled.backlog_mean - base
    if cutoff.slack == 0:
        tail_term = prefix_term = stationarity_term = total = None
    else:
        tail_term = cutoff.association / cutoff.slack
        prefix_term = (c_fitted - c_observed) / cutoff.slack
        stationarity_term = -residual / cutoff.slack
        total = tail_term + prefix_term + stationarity_term
    status = cutoff.status
    if (
        decoded_mean is not None
        and total is not None
        and total != decoded_mean - pooled.backlog_mean
    ):
        status = "empirical_accounting_mismatch"
    return EmpiricalErrorResult(
        cutoff.cutoff,
        c_observed,
        c_fitted,
        residual,
        tail_term,
        prefix_term,
        stationarity_term,
        total,
        tail_mass,
        decoded_mean,
        status,
    )


def analyze_pooled_target_block(
    readers: Iterable[CompactObservationReader],
    *,
    target_id: str,
    block_id: int,
    cutoffs: Iterable[int],
    arrival: CertifiedArrivalLaw | None,
    stationary_interpretation: bool = False,
    no_drop: bool | None = None,
    early_service_late_arrival: bool | None = None,
) -> StreamingBlockAnalysis:
    requested = _cutoffs(cutoffs)
    pooled = pool_target_block(
        readers,
        target_id=target_id,
        block_id=block_id,
        cutoffs=requested,
    )
    cutoff_results = tuple(pooled.cutoff(cutoff, arrival) for cutoff in requested)
    finite = tuple(
        finite_window_from_pooled(pooled, cutoff, arrival)
        for cutoff in cutoff_results
    )
    if arrival is None:
        innovations: tuple[InnovationCorrections, ...] = ()
    else:
        innovations = tuple(
            innovation_from_pooled(pooled, cutoff, window)
            for cutoff, window in zip(cutoff_results, finite, strict=True)
        )
    gap_competition = pooled.competition()
    gap_cutoffs = tuple(
        pooled.gap_cutoff(
            cutoff,
            stationary_interpretation=stationary_interpretation,
        )
        for cutoff in cutoff_results
    )
    stationary_tie = pooled.tie_decomposition(
        arrival,
        stationary_interpretation=stationary_interpretation,
    )
    isolated = pooled.isolated_server(
        arrival,
        stationary_interpretation=stationary_interpretation,
        no_drop=no_drop,
        early_service_late_arrival=early_service_late_arrival,
    )
    return StreamingBlockAnalysis(
        pooled,
        cutoff_results,
        finite,
        innovations,
        gap_competition,
        gap_cutoffs,
        stationary_tie,
        isolated,
    )


@dataclass(frozen=True, slots=True)
class UncertaintySummary:
    replication_units: int
    mean: float | None
    standard_error: float | None
    status: str


def independent_replication_uncertainty(values: Iterable[RationalInput]) -> UncertaintySummary:
    """Compute a standard error using complete runs/ensembles as the units."""

    samples = tuple(float(_fraction(value, name="replication value")) for value in values)
    if not samples:
        return UncertaintySummary(0, None, None, "no_replication_units")
    mean = math.fsum(samples) / len(samples)
    if len(samples) < 2:
        return UncertaintySummary(1, mean, None, "insufficient_replication")
    variance = math.fsum((value - mean) ** 2 for value in samples) / (len(samples) - 1)
    return UncertaintySummary(len(samples), mean, math.sqrt(variance / len(samples)), "ok")


__all__ = [
    "BoundaryMoments",
    "PooledTargetBlock",
    "InnovationCorrections",
    "StreamingBlockAnalysis",
    "UncertaintySummary",
    "pool_target_block",
    "finite_window_from_pooled",
    "innovation_from_pooled",
    "iter_pooled_gap_levels",
    "empirical_error_from_pooled",
    "analyze_pooled_target_block",
    "independent_replication_uncertainty",
]
