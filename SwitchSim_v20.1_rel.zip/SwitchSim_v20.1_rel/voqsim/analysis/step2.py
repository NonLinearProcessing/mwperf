"""Exact Step 2 gap, tie, and decoder-error decompositions.

All public calculations in this module consume pooled additive masses.  They
use :class:`fractions.Fraction` throughout so simulator integer records and
weighted binary64-lattice records follow the same arithmetic path.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
import math
from numbers import Integral
from typing import TypeAlias

from ..errors import ValidationError
from .step1 import (
    AnalysisNumber,
    CertifiedArrivalLaw,
    CutoffResult,
    RationalInput,
)


OptionalMass: TypeAlias = int | None


def _fraction(value: RationalInput, *, name: str) -> Fraction:
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be numeric, not boolean")
    if isinstance(value, Fraction):
        return value
    if isinstance(value, Integral):
        return Fraction(int(value))
    if isinstance(value, Decimal) and value.is_finite():
        return Fraction(value)
    if isinstance(value, float) and math.isfinite(value):
        return Fraction.from_float(value)
    raise ValidationError(f"{name} must be an int, finite float, or Fraction")


def _nonnegative_int(value: object, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be non-negative", context={"value": result})
    return result


def _gap_tuple(
    *,
    gap_negative: OptionalMass,
    gap_zero: OptionalMass,
    gap_positive: OptionalMass,
    gap_zero_served: OptionalMass,
    gap_positive_sum: OptionalMass,
    gap_negative_sum: OptionalMass,
) -> tuple[int, int, int, int, int, int] | None:
    raw = (
        gap_negative,
        gap_zero,
        gap_positive,
        gap_zero_served,
        gap_positive_sum,
        gap_negative_sum,
    )
    if all(value is None for value in raw):
        return None
    if any(value is None for value in raw):
        raise ValidationError("exact gap masses must be present as one complete tuple")
    names = (
        "gap_negative",
        "gap_zero",
        "gap_positive",
        "gap_zero_served",
        "gap_positive_sum",
        "gap_negative_sum",
    )
    return tuple(
        _nonnegative_int(value, name=name)
        for name, value in zip(names, raw, strict=True)
    )  # type: ignore[return-value]


@dataclass(frozen=True, slots=True)
class GapLevelResult:
    backlog: int
    exposure: int
    served: int
    gap_negative: int | None
    gap_zero: int | None
    gap_positive: int | None
    gap_zero_served: int | None
    gap_positive_sum: int | None
    gap_negative_sum: int | None
    response: Fraction | None
    strict_win_probability: Fraction | None
    tied_service_probability: Fraction | None
    response_identity_residual: Fraction | None
    status: str


def gap_level_analysis(
    *,
    backlog: int,
    exposure: int,
    served: int,
    gap_negative: OptionalMass,
    gap_zero: OptionalMass,
    gap_positive: OptionalMass,
    gap_zero_served: OptionalMass,
    gap_positive_sum: OptionalMass,
    gap_negative_sum: OptionalMass,
) -> GapLevelResult:
    """Report the strict-win and served-tie parts of one pooled response row."""

    n = _nonnegative_int(backlog, name="backlog")
    total = _nonnegative_int(exposure, name="exposure")
    service = _nonnegative_int(served, name="served")
    if total == 0:
        raise ValidationError("a persisted level row must have positive exposure")
    if service > total:
        raise ValidationError("service mass cannot exceed exposure mass")
    gaps = _gap_tuple(
        gap_negative=gap_negative,
        gap_zero=gap_zero,
        gap_positive=gap_positive,
        gap_zero_served=gap_zero_served,
        gap_positive_sum=gap_positive_sum,
        gap_negative_sum=gap_negative_sum,
    )
    response = Fraction(service, total)
    if gaps is None:
        return GapLevelResult(
            n,
            total,
            service,
            None,
            None,
            None,
            None,
            None,
            None,
            response,
            None,
            None,
            None,
            "gap_not_requested",
        )

    negative, zero, positive, zero_served, positive_sum, negative_sum = gaps
    if negative + zero + positive != total:
        raise ValidationError("gap sign masses must sum exactly to exposure")
    if zero_served > zero or zero_served > service:
        raise ValidationError("tied-and-served mass cannot exceed tie or service mass")
    if (positive == 0) != (positive_sum == 0):
        raise ValidationError("positive-gap mass and moment must vanish together")
    if (negative == 0) != (negative_sum == 0):
        raise ValidationError("negative-gap mass and moment must vanish together")
    if positive_sum < positive or negative_sum < negative:
        raise ValidationError("nonzero integral gaps must have magnitude at least one")
    if positive_sum > n * positive:
        raise ValidationError("positive-gap moment exceeds the pointwise backlog bound")
    if n * total - (positive_sum - negative_sum) < 0:
        raise ValidationError("pooled competition mass cannot be negative")
    if n == 0 and (
        service != 0 or positive != 0 or zero_served != 0 or positive_sum != 0
    ):
        raise ValidationError(
            "an empty target cannot depart, serve a tie, or have a positive exact gap"
        )
    if n > 0 and service != positive + zero_served:
        raise ValidationError(
            "positive-backlog service must equal strict-win plus tied-service mass"
        )

    strict_probability = Fraction(positive, total)
    tied_probability = Fraction(zero_served, total)
    residual = response - strict_probability - tied_probability
    return GapLevelResult(
        n,
        total,
        service,
        negative,
        zero,
        positive,
        zero_served,
        positive_sum,
        negative_sum,
        response,
        strict_probability,
        tied_probability,
        residual,
        "ok",
    )


@dataclass(frozen=True, slots=True)
class GapCompetitionResult:
    backlog_mean: Fraction
    gap_mean: Fraction | None
    competition_mean: Fraction | None
    absolute_gap_mean: Fraction | None
    competition_ratio: Fraction | None
    identity_residual: Fraction | None
    inequality_margin: Fraction | None
    status: str


def gap_competition_analysis(
    *,
    exposure: int,
    backlog_exposure: int,
    gap_positive_sum: OptionalMass,
    gap_negative_sum: OptionalMass,
) -> GapCompetitionResult:
    """Compute ``E Theta`` and ``E|G| / E Theta`` from pooled raw masses."""

    total = _nonnegative_int(exposure, name="exposure")
    backlog_total = _nonnegative_int(backlog_exposure, name="backlog_exposure")
    if total == 0:
        raise ValidationError("competition analysis requires positive exposure")
    backlog_mean = Fraction(backlog_total, total)
    if gap_positive_sum is None and gap_negative_sum is None:
        return GapCompetitionResult(
            backlog_mean, None, None, None, None, None, None, "gap_not_requested"
        )
    if gap_positive_sum is None or gap_negative_sum is None:
        raise ValidationError("positive and negative gap moments must be present together")
    positive = _nonnegative_int(gap_positive_sum, name="gap_positive_sum")
    negative = _nonnegative_int(gap_negative_sum, name="gap_negative_sum")
    signed = positive - negative
    competition_total = backlog_total - signed
    if competition_total < 0:
        raise ValidationError("pooled competition mass cannot be negative")
    gap_mean = Fraction(signed, total)
    competition_mean = Fraction(competition_total, total)
    absolute = Fraction(positive + negative, total)
    margin = absolute - abs(gap_mean)
    if margin < 0:
        raise ValidationError("absolute-gap inequality failed")
    ratio = None if competition_total == 0 else Fraction(positive + negative, competition_total)
    status = "zero_competition_scale" if competition_total == 0 else "ok"
    return GapCompetitionResult(
        backlog_mean,
        gap_mean,
        competition_mean,
        absolute,
        ratio,
        backlog_mean - competition_mean - gap_mean,
        margin,
        status,
    )


@dataclass(frozen=True, slots=True)
class GapTailResult:
    cutoff: int
    positive_gap_tail_mass: Fraction | None
    negative_gap_tail_mass: Fraction | None
    gap_association: Fraction | None
    competition_association: Fraction | None
    backlog_service_covariance: Fraction | None
    competition_service_covariance: Fraction | None
    gap_covariance_term: Fraction | None
    covariance_identity_residual: Fraction | None
    competition_compression_term: Fraction | None
    gap_compression_term: Fraction | None
    compression_total: Fraction | None
    status: str


def gap_tail_analysis(
    cutoff: CutoffResult,
    *,
    exposure: int,
    gap_positive_tail_sum: OptionalMass,
    gap_negative_tail_sum: OptionalMass,
    stationary_interpretation: bool = False,
) -> GapTailResult:
    """Split a cutoff's backlog-service association into competition and gap."""

    total = _nonnegative_int(exposure, name="exposure")
    if total == 0:
        raise ValidationError("tail analysis requires positive exposure")
    if gap_positive_tail_sum is None and gap_negative_tail_sum is None:
        return GapTailResult(
            cutoff.cutoff,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "gap_not_requested",
        )
    if gap_positive_tail_sum is None or gap_negative_tail_sum is None:
        raise ValidationError("tail gap moments must be present together")
    positive = _nonnegative_int(gap_positive_tail_sum, name="gap_positive_tail_sum")
    negative = _nonnegative_int(gap_negative_tail_sum, name="gap_negative_tail_sum")
    if cutoff.tau == 0 or cutoff.tail_service is None or cutoff.association is None:
        return GapTailResult(
            cutoff.cutoff,
            Fraction(positive, total),
            Fraction(negative, total),
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            cutoff.status,
        )

    a_positive = Fraction(positive, total)
    a_negative = Fraction(negative, total)
    c = cutoff.tail_service
    r_gap = (1 - c) * a_positive + c * a_negative
    r_competition = cutoff.association - r_gap
    covariance = cutoff.association / cutoff.tau
    competition_covariance = r_competition / cutoff.tau
    gap_covariance = r_gap / cutoff.tau
    covariance_residual = covariance - competition_covariance - gap_covariance

    competition_term = gap_term = compression_total = None
    if cutoff.slack is None:
        status = "arrival_law_unavailable"
    elif cutoff.status in {
        "drop_affected",
        "not_fresh_iid",
        "no_observed_service",
        "nonpositive_tail_slack",
    }:
        status = cutoff.status
    elif not stationary_interpretation:
        status = "stationarity_not_asserted"
    elif cutoff.slack <= 0:
        status = "nonpositive_tail_slack"
    else:
        competition_term = r_competition / cutoff.slack
        gap_term = r_gap / cutoff.slack
        compression_total = competition_term + gap_term
        status = "ok"

    return GapTailResult(
        cutoff.cutoff,
        a_positive,
        a_negative,
        r_gap,
        r_competition,
        covariance,
        competition_covariance,
        gap_covariance,
        covariance_residual,
        competition_term,
        gap_term,
        compression_total,
        status,
    )


@dataclass(frozen=True, slots=True)
class IsolatedServerResult:
    """Independent isolated-queue reference and its interpretation gate."""

    backlog_mean: Fraction
    unserved_backlog_moment: Fraction
    arrival_mean: Fraction | None
    arrival_variance: Fraction | None
    isolated_mean: Fraction | None
    raw_difference: Fraction | None
    contention_excess: Fraction | None
    identity_right_hand_side: Fraction | None
    identity_residual: Fraction | None
    difference_label: str
    baseline_status: str
    status: str
    empirical_arrival_mean: Fraction | None = None
    empirical_arrival_variance: Fraction | None = None
    empirical_arrival_second_moment: Fraction | None = None
    arrival_mean_residual: Fraction | None = None
    arrival_second_moment_residual: Fraction | None = None
    numerical_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"

    @property
    def isolated_reference(self) -> Fraction | None:
        return self.isolated_mean

    @property
    def m_iso(self) -> Fraction | None:
        return self.isolated_mean

    @property
    def contention_identity_residual(self) -> Fraction | None:
        return self.identity_residual

    @property
    def contention_status(self) -> str:
        return self.status

    @property
    def offered_mean(self) -> Fraction | None:
        return self.empirical_arrival_mean

    @property
    def offered_variance(self) -> Fraction | None:
        return self.empirical_arrival_variance

    @property
    def offered_second_moment(self) -> Fraction | None:
        return self.empirical_arrival_second_moment


def isolated_server_analysis(
    *,
    exposure: int,
    backlog_exposure: int,
    backlog_service: int,
    arrival: CertifiedArrivalLaw | None,
    offered: int | None = None,
    offered_square: int | None = None,
    drops: int = 0,
    no_drop: bool = False,
    stationary_interpretation: bool = False,
    early_service_late_arrival: bool = False,
) -> IsolatedServerResult:
    """Compute ``M_iso`` independently of exact-gap/tie observations.

    The reference and raw difference remain useful for finite buffers. The
    phrase ``contention_excess`` and the stationary identity are exposed only
    under the full NoDrop, stationary, early-service/late-arrival gate.
    """

    total = _nonnegative_int(exposure, name="exposure")
    backlog_total = _nonnegative_int(backlog_exposure, name="backlog_exposure")
    service_total = _nonnegative_int(backlog_service, name="backlog_service")
    dropped = _nonnegative_int(drops, name="drops")
    if total == 0:
        raise ValidationError("isolated-server analysis requires positive exposure")
    if service_total > backlog_total:
        raise ValidationError("backlog-service moment cannot exceed backlog exposure")
    if not isinstance(no_drop, bool):
        raise ValidationError("no_drop must be boolean")
    if not isinstance(stationary_interpretation, bool):
        raise ValidationError("stationary_interpretation must be boolean")
    if not isinstance(early_service_late_arrival, bool):
        raise ValidationError("early_service_late_arrival must be boolean")

    if (offered is None) != (offered_square is None):
        raise ValidationError("offered and offered_square must be provided together")
    if offered is None:
        empirical_mean = empirical_variance = empirical_second = None
    else:
        offered_total = _nonnegative_int(offered, name="offered")
        square_total = _nonnegative_int(offered_square, name="offered_square")
        if square_total < offered_total:
            raise ValidationError("offered_square cannot be less than offered")
        empirical_mean = Fraction(offered_total, total)
        empirical_second = Fraction(square_total, total)
        empirical_variance = empirical_second - empirical_mean * empirical_mean
        if empirical_variance < 0:
            raise ValidationError("empirical arrival variance cannot be negative")

    backlog_mean = Fraction(backlog_total, total)
    unserved = Fraction(backlog_total - service_total, total)
    if arrival is None:
        return IsolatedServerResult(
            backlog_mean,
            unserved,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "unavailable",
            "arrival_law_unavailable",
            "arrival_law_unavailable",
            empirical_arrival_mean=empirical_mean,
            empirical_arrival_variance=empirical_variance,
            empirical_arrival_second_moment=empirical_second,
        )
    if not arrival.fresh_iid:
        return IsolatedServerResult(
            backlog_mean,
            unserved,
            arrival.mean,
            arrival.variance,
            None,
            None,
            None,
            None,
            None,
            "unavailable",
            "not_fresh_iid",
            "not_fresh_iid",
            empirical_arrival_mean=empirical_mean,
            empirical_arrival_variance=empirical_variance,
            empirical_arrival_second_moment=empirical_second,
            arrival_mean_residual=(
                None if empirical_mean is None else empirical_mean - arrival.mean
            ),
            arrival_second_moment_residual=(
                None
                if empirical_second is None
                else empirical_second - arrival.second_moment
            ),
        )
    if arrival.mean >= 1:
        return IsolatedServerResult(
            backlog_mean,
            unserved,
            arrival.mean,
            arrival.variance,
            None,
            None,
            None,
            None,
            None,
            "unavailable",
            "lambda_not_below_one",
            "lambda_not_below_one",
            empirical_arrival_mean=empirical_mean,
            empirical_arrival_variance=empirical_variance,
            empirical_arrival_second_moment=empirical_second,
            arrival_mean_residual=(
                None if empirical_mean is None else empirical_mean - arrival.mean
            ),
            arrival_second_moment_residual=(
                None
                if empirical_second is None
                else empirical_second - arrival.second_moment
            ),
        )

    denominator = 1 - arrival.mean
    isolated = (
        arrival.variance + arrival.mean * (1 - arrival.mean)
    ) / (2 * denominator)
    difference = backlog_mean - isolated
    if not no_drop:
        interpretation_status = "no_drop_required"
    elif dropped > 0:
        interpretation_status = "drop_affected"
    elif not stationary_interpretation:
        interpretation_status = "stationarity_not_asserted"
    elif not early_service_late_arrival:
        interpretation_status = "unsupported_slot_convention"
    else:
        interpretation_status = "ok"

    if interpretation_status == "ok":
        contention = difference
        identity_rhs = unserved / denominator
        residual = difference - identity_rhs
        label = "contention_excess"
    else:
        contention = None
        identity_rhs = None
        residual = None
        label = "raw_difference"
    return IsolatedServerResult(
        backlog_mean,
        unserved,
        arrival.mean,
        arrival.variance,
        isolated,
        difference,
        contention,
        identity_rhs,
        residual,
        label,
        "ok",
        interpretation_status,
        empirical_arrival_mean=empirical_mean,
        empirical_arrival_variance=empirical_variance,
        empirical_arrival_second_moment=empirical_second,
        arrival_mean_residual=(
            None if empirical_mean is None else empirical_mean - arrival.mean
        ),
        arrival_second_moment_residual=(
            None
            if empirical_second is None
            else empirical_second - arrival.second_moment
        ),
    )


@dataclass(frozen=True, slots=True)
class StationaryTieResult:
    backlog_mean: Fraction
    strict_loss: Fraction | None
    lost_tie: Fraction | None
    total_loss: Fraction | None
    base_term: Fraction | None
    isolated_component: Fraction | None
    strict_loss_component: Fraction | None
    lost_tie_component: Fraction | None
    loss_component: Fraction | None
    decomposed_mean: Fraction | None
    decomposition_residual: Fraction | None
    status: str
    numerical_error_bound: AnalysisNumber | None = Fraction(0)
    numerical_status: str = "exact"


def stationary_tie_analysis(
    *,
    exposure: int,
    backlog_exposure: int,
    gap_negative_backlog: OptionalMass,
    gap_zero_unserved_backlog: OptionalMass,
    arrival: CertifiedArrivalLaw | None,
    drops: int = 0,
    stationary_interpretation: bool = False,
) -> StationaryTieResult:
    """Report descriptive losses and, when justified, the stationary mean split."""

    total = _nonnegative_int(exposure, name="exposure")
    backlog_total = _nonnegative_int(backlog_exposure, name="backlog_exposure")
    dropped = _nonnegative_int(drops, name="drops")
    if total == 0:
        raise ValidationError("tie analysis requires positive exposure")
    backlog_mean = Fraction(backlog_total, total)
    if gap_negative_backlog is None and gap_zero_unserved_backlog is None:
        return StationaryTieResult(
            backlog_mean,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "gap_not_requested",
        )
    if gap_negative_backlog is None or gap_zero_unserved_backlog is None:
        raise ValidationError("strict-loss and lost-tie masses must be present together")
    strict = Fraction(
        _nonnegative_int(gap_negative_backlog, name="gap_negative_backlog"), total
    )
    tied = Fraction(
        _nonnegative_int(
            gap_zero_unserved_backlog,
            name="gap_zero_unserved_backlog",
        ),
        total,
    )
    combined = strict + tied
    if arrival is None:
        return StationaryTieResult(
            backlog_mean,
            strict,
            tied,
            combined,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            "arrival_law_unavailable",
        )

    base = (
        arrival.second_moment
        + arrival.mean
        - 2 * arrival.mean * arrival.mean
    ) / 2
    if dropped > 0:
        status = "drop_affected"
    elif not arrival.fresh_iid:
        status = "not_fresh_iid"
    elif arrival.mean >= 1:
        status = "lambda_not_below_one"
    elif not stationary_interpretation:
        status = "stationarity_not_asserted"
    else:
        status = "ok"
    if status != "ok":
        return StationaryTieResult(
            backlog_mean,
            strict,
            tied,
            combined,
            base,
            None,
            None,
            None,
            None,
            None,
            None,
            status,
        )

    denominator = 1 - arrival.mean
    isolated = base / denominator
    strict_component = strict / denominator
    tied_component = tied / denominator
    loss_component = strict_component + tied_component
    decomposed = isolated + loss_component
    return StationaryTieResult(
        backlog_mean,
        strict,
        tied,
        combined,
        base,
        isolated,
        strict_component,
        tied_component,
        loss_component,
        decomposed,
        decomposed - backlog_mean,
        "ok",
    )


@dataclass(frozen=True, slots=True)
class DecoderMeanEstimate:
    """One authoritative decoder result; this class never performs decoding."""

    target_id: str
    cutoff: int
    fitted_mean: Fraction | None
    status: str

    @classmethod
    def create(
        cls,
        *,
        target_id: str,
        cutoff: int,
        fitted_mean: RationalInput | None,
        status: str,
    ) -> "DecoderMeanEstimate":
        if not isinstance(target_id, str) or not target_id:
            raise ValidationError("target_id must be a nonempty string")
        k = _nonnegative_int(cutoff, name="cutoff")
        if not isinstance(status, str) or not status:
            raise ValidationError("decoder status must be a nonempty string")
        mean = None if fitted_mean is None else _fraction(fitted_mean, name="fitted_mean")
        if mean is not None and mean < 0:
            raise ValidationError("fitted_mean must be non-negative")
        if status == "ok" and mean is None:
            raise ValidationError("a successful decoder result must include fitted_mean")
        return cls(target_id, k, mean, status)


@dataclass(frozen=True, slots=True)
class ReferenceMeanEstimate:
    target_id: str
    mean: Fraction | None
    status: str

    @classmethod
    def create(
        cls,
        *,
        target_id: str,
        mean: RationalInput | None,
        status: str,
    ) -> "ReferenceMeanEstimate":
        if not isinstance(target_id, str) or not target_id:
            raise ValidationError("target_id must be a nonempty string")
        if not isinstance(status, str) or not status:
            raise ValidationError("reference status must be a nonempty string")
        normalized = None if mean is None else _fraction(mean, name="reference mean")
        if normalized is not None and normalized < 0:
            raise ValidationError("reference mean must be non-negative")
        if status == "ok" and normalized is None:
            raise ValidationError("a successful reference must include its mean")
        return cls(target_id, normalized, status)


@dataclass(frozen=True, slots=True)
class ErrorSeparationResult:
    target_id: str
    cutoff: int
    compression: Fraction | None
    finite_window_construction: Fraction | None
    sampling: Fraction | None
    total: Fraction | None
    accounting_residual: Fraction | None
    compression_status: str
    construction_status: str
    sampling_status: str
    total_status: str
    status: str


def _difference(
    left_value: Fraction | None,
    left_status: str,
    left_name: str,
    right_value: Fraction | None,
    right_status: str,
    right_name: str,
) -> tuple[Fraction | None, str]:
    if left_status != "ok":
        return None, f"{left_name}:{left_status}"
    if right_status != "ok":
        return None, f"{right_name}:{right_status}"
    if left_value is None or right_value is None:
        raise ValidationError("successful estimates must contain numeric values")
    return left_value - right_value, "ok"


def authoritative_error_separation(
    *,
    sampler: DecoderMeanEstimate,
    finite_window: DecoderMeanEstimate,
    stationary: DecoderMeanEstimate,
    stationary_mean: ReferenceMeanEstimate,
) -> ErrorSeparationResult:
    """Separate compression, construction, and sampling without decoding.

    Inputs are authoritative decoder outputs or explicit failed-fit statuses.
    A failed intermediate fit never becomes a numerical error value.
    """

    target_ids = {
        sampler.target_id,
        finite_window.target_id,
        stationary.target_id,
        stationary_mean.target_id,
    }
    if len(target_ids) != 1:
        raise ValidationError("error-separation inputs must name the same target")
    if len({sampler.cutoff, finite_window.cutoff, stationary.cutoff}) != 1:
        raise ValidationError("error-separation decoder inputs must use the same cutoff")

    compression, compression_status = _difference(
        stationary.fitted_mean,
        stationary.status,
        "stationary_decoder",
        stationary_mean.mean,
        stationary_mean.status,
        "stationary_mean",
    )
    construction, construction_status = _difference(
        finite_window.fitted_mean,
        finite_window.status,
        "finite_window_decoder",
        stationary.fitted_mean,
        stationary.status,
        "stationary_decoder",
    )
    sampling, sampling_status = _difference(
        sampler.fitted_mean,
        sampler.status,
        "sampler_decoder",
        finite_window.fitted_mean,
        finite_window.status,
        "finite_window_decoder",
    )
    total, total_status = _difference(
        sampler.fitted_mean,
        sampler.status,
        "sampler_decoder",
        stationary_mean.mean,
        stationary_mean.status,
        "stationary_mean",
    )
    statuses = (
        compression_status,
        construction_status,
        sampling_status,
        total_status,
    )
    if all(status == "ok" for status in statuses):
        assert compression is not None
        assert construction is not None
        assert sampling is not None
        assert total is not None
        residual = total - compression - construction - sampling
        status = "ok" if residual == 0 else "error_separation_mismatch"
    else:
        residual = None
        status = "incomplete"
    return ErrorSeparationResult(
        sampler.target_id,
        sampler.cutoff,
        compression,
        construction,
        sampling,
        total,
        residual,
        compression_status,
        construction_status,
        sampling_status,
        total_status,
        status,
    )


__all__ = [
    "DecoderMeanEstimate",
    "ErrorSeparationResult",
    "GapCompetitionResult",
    "GapLevelResult",
    "GapTailResult",
    "IsolatedServerResult",
    "ReferenceMeanEstimate",
    "StationaryTieResult",
    "authoritative_error_separation",
    "gap_competition_analysis",
    "gap_level_analysis",
    "gap_tail_analysis",
    "isolated_server_analysis",
    "stationary_tie_analysis",
]
