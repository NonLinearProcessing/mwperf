from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path
import re
import sys
from typing import Sequence

from . import __version__
from .config import (
    CONFIG_SCHEMA_VERSION,
    NO_DROP_CAPACITY,
    apply_queue_capacity_override,
    load_raw_config,
    migrate_config_file,
    resolve_config,
)
from .arrival_config import COUNT_ARRIVAL_FAMILIES
from .errors import SimError
from .batch import run_batch_dir
from .kernel import build_simulation
from .schedulers.registry import (
    available_schedulers,
    scheduler_capabilities,
    scheduler_class_for_name,
)
from .utils import canonical_json_dumps


_CLI_POSITIVE_INTEGER_RE = re.compile(r"^[0-9]+$")


def _parse_queue_capacity_argument(value: str) -> int | str:
    if value == NO_DROP_CAPACITY:
        return NO_DROP_CAPACITY
    if not _CLI_POSITIVE_INTEGER_RE.fullmatch(value):
        raise argparse.ArgumentTypeError(
            f"queue capacity must be a positive integer or the exact string {NO_DROP_CAPACITY!r}"
        )
    capacity = int(value)
    if capacity < 1:
        raise argparse.ArgumentTypeError(
            f"queue capacity must be a positive integer or the exact string {NO_DROP_CAPACITY!r}"
        )
    return capacity


def build_arg_parser() -> argparse.ArgumentParser:
    """Build the command-line parser for one-shot simulator runs.

    The CLI intentionally stays thin: it resolves a config path, wires the
    simulator through :func:`voqsim.kernel.build_simulation`, executes exactly
    one deterministic run, and prints a canonical JSON result payload to
    ``stdout`` unless ``--quiet`` is requested.
    """

    parser = argparse.ArgumentParser(
        prog="switchsim",
        description=(
            "Run SwitchSim v20.1 schema-4 simulations or explicitly migrate an older YAML/JSON config."
        ),
    )
    parser.add_argument(
        "config",
        nargs="?",
        help="path to a resolved or unresolved YAML/JSON simulator config",
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        help="directory where telemetry, summary, and static run artifacts will be written",
    )
    parser.add_argument(
        "--batch-dir",
        help="directory containing multiple simulator config files to run in series",
    )
    parser.add_argument(
        "--output-root",
        help="batch-output root; each config is mapped to a unique run directory under this tree",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="continue executing later configs after a runtime failure in batch mode",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="suppress the final JSON result payload on stdout",
    )
    parser.add_argument(
        "--no-slot-trace",
        action="store_true",
        help="compute online summary metrics without writing telemetry.jsonl",
    )
    parser.add_argument(
        "--queue-capacity",
        type=_parse_queue_capacity_argument,
        metavar="CAPACITY",
        help=(
            "override the configured queue buffer before validation; use a positive integer "
            f"or the exact string {NO_DROP_CAPACITY!r}"
        ),
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="print the package checkpoint version and exit",
    )
    parser.add_argument(
        "--list-schedulers",
        action="store_true",
        help="print canonical scheduler, constraint-family, and algorithm metadata as JSON and exit",
    )
    parser.add_argument(
        "--list-arrivals",
        action="store_true",
        help="print canonical arrival-family IID/stateful metadata as JSON and exit",
    )
    parser.add_argument(
        "--migrate-config",
        action="store_true",
        help="explicitly migrate the positional legacy config instead of running it",
    )
    parser.add_argument(
        "--output-config",
        help="destination YAML/JSON path required by --migrate-config",
    )
    return parser



def _print_scheduler_names() -> None:
    names = available_schedulers(implemented_only=True)
    rows = []
    for name in names:
        capabilities = scheduler_capabilities(name)
        scheduler_cls = scheduler_class_for_name(name)
        algorithm_id = getattr(scheduler_cls, "optimizer_id", None)
        if not isinstance(algorithm_id, str):
            candidate = getattr(scheduler_cls, "algorithm_id", None)
            algorithm_id = candidate if isinstance(candidate, str) else name
        rows.append(
            {
                "name": name,
                "constraint_family": capabilities.service_families[0],
                "algorithm_id": algorithm_id,
            }
        )
    sys.stdout.write(canonical_json_dumps({"schedulers": rows}) + "\n")


def _print_arrival_names() -> None:
    fresh_iid = {
        "iid_count_table",
        "iid_independent_bernoulli",
        "iid_independent_poisson",
        "iid_mixed_poisson",
    }
    rows = [
        {
            "family": family,
            "temporal_status": "iid" if family in fresh_iid else "stateful",
            "fresh_iid": family in fresh_iid,
        }
        for family in sorted(COUNT_ARRIVAL_FAMILIES)
    ]
    sys.stdout.write(canonical_json_dumps({"arrivals": rows}) + "\n")



def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point.

    Returns a process-style integer exit code instead of calling ``sys.exit``
    directly so tests can invoke it safely.
    """

    parser = build_arg_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    selected_modes = sum(
        bool(value)
        for value in (
            args.version,
            args.list_schedulers,
            args.list_arrivals,
            args.migrate_config,
        )
    )
    if selected_modes > 1:
        sys.stderr.write(
            "error: --version, --list-schedulers, --list-arrivals, and --migrate-config are mutually exclusive\n"
        )
        return 2

    if args.version:
        sys.stdout.write(__version__ + "\n")
        return 0

    if args.list_schedulers:
        _print_scheduler_names()
        return 0

    if args.list_arrivals:
        _print_arrival_names()
        return 0

    config_arg = args.config
    batch_dir = args.batch_dir
    output_root = args.output_root

    if args.migrate_config:
        incompatible = {
            "--batch-dir": batch_dir,
            "--output-root": output_root,
            "--output-dir": args.output_dir,
            "--continue-on-error": args.continue_on_error,
            "--no-slot-trace": args.no_slot_trace,
            "--queue-capacity": args.queue_capacity,
        }
        used = [name for name, value in incompatible.items() if value not in (None, False)]
        if used:
            sys.stderr.write(
                "error: --migrate-config is mutually exclusive with " + ", ".join(used) + "\n"
            )
            return 2
        if config_arg is None:
            sys.stderr.write("error: legacy config path is required with --migrate-config\n")
            return 2
        if args.output_config is None:
            sys.stderr.write("error: --output-config is required with --migrate-config\n")
            return 2
        try:
            migrated_path = migrate_config_file(config_arg, args.output_config)
        except (SimError, OSError) as exc:
            sys.stderr.write(f"error: {exc}\n")
            return 2
        if not args.quiet:
            sys.stdout.write(
                canonical_json_dumps(
                    {
                        "migrated_config": str(migrated_path),
                        "schema_version": CONFIG_SCHEMA_VERSION,
                    }
                )
                + "\n"
            )
        return 0

    if args.output_config is not None:
        sys.stderr.write("error: --output-config is only valid with --migrate-config\n")
        return 2

    if config_arg is not None and batch_dir is not None:
        sys.stderr.write("error: config positional path and --batch-dir are mutually exclusive\n")
        return 2

    if batch_dir is not None:
        if output_root is None:
            sys.stderr.write("error: --output-root is required in batch mode\n")
            return 2
        if args.output_dir is not None:
            sys.stderr.write("error: --output-dir is only valid for single-run mode\n")
            return 2
        try:
            batch_result = run_batch_dir(
                batch_dir,
                output_root,
                continue_on_error=args.continue_on_error,
                write_slot_trace=False if args.no_slot_trace else None,
                queue_capacity_override=args.queue_capacity,
            )
        except (SimError, OSError) as exc:
            sys.stderr.write(f"error: {exc}\n")
            return 2

        if not args.quiet:
            sys.stdout.write(canonical_json_dumps(batch_result.to_dict()) + "\n")
        return 0 if batch_result.failed_runs == 0 and batch_result.completed_all_runs else 1

    if config_arg is None:
        sys.stderr.write(
            "error: config is required unless --version, --list-schedulers, --list-arrivals, "
            "--migrate-config, or --batch-dir is used\n"
        )
        return 2
    if output_root is not None:
        sys.stderr.write("error: --output-root is only valid in batch mode\n")
        return 2
    if args.continue_on_error:
        sys.stderr.write("error: --continue-on-error is only valid in batch mode\n")
        return 2

    try:
        config_source = config_arg
        if args.no_slot_trace or args.queue_capacity is not None:
            raw_config = load_raw_config(config_arg)
            if args.queue_capacity is not None:
                raw_config = apply_queue_capacity_override(raw_config, args.queue_capacity)
            loaded = resolve_config(raw_config, validate=True)
            if args.no_slot_trace:
                loaded = replace(loaded, telemetry=replace(loaded.telemetry, write_slot_trace=False))
            config_source = loaded
        simulator = build_simulation(config_source, output_dir=args.output_dir)
        result = simulator.run()
    except (SimError, OSError) as exc:
        sys.stderr.write(f"error: {exc}\n")
        return 2

    if not args.quiet:
        sys.stdout.write(canonical_json_dumps(result.to_dict()) + "\n")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
