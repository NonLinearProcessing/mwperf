from __future__ import annotations

from decimal import Decimal
from typing import Literal, TypeAlias

import numpy as np
import numpy.typing as npt

PortId: TypeAlias = int
Slot: TypeAlias = int
PacketId: TypeAlias = int
FlowId: TypeAlias = int
SeedValue: TypeAlias = int

# Queue identifiers are intentionally external, stable labels.  Runtime hot
# paths resolve them once through QueueCatalog and then operate on dense integer
# indices.  Booleans are rejected by QueueCatalog even though bool subclasses
# int in Python.
QueueId: TypeAlias = int | str
QueueIndex: TypeAlias = int

VOQKey: TypeAlias = tuple[PortId, PortId]
Matching: TypeAlias = tuple[VOQKey, ...]

QueueVector: TypeAlias = npt.NDArray[np.int64]
QueueSnapshotMode: TypeAlias = Literal["dense", "sparse_nonzero", "disabled"]

# ``Decimal`` is part of the schema-4 configuration representation.  It is
# emitted as a JSON number (never a quoted string) by ``canonical_json_dumps``.
JSONScalar: TypeAlias = str | int | float | Decimal | bool | None
JSONValue: TypeAlias = JSONScalar | list["JSONValue"] | dict[str, "JSONValue"]

__all__ = [
    "PortId",
    "Slot",
    "PacketId",
    "FlowId",
    "SeedValue",
    "QueueId",
    "QueueIndex",
    "VOQKey",
    "Matching",
    "QueueVector",
    "QueueSnapshotMode",
    "JSONScalar",
    "JSONValue",
]
