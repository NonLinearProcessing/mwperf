from __future__ import annotations

from dataclasses import asdict, is_dataclass
from decimal import Decimal
from enum import Enum
import json
import math
from numbers import Integral
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence, TypeVar

import numpy as np

from .errors import ValidationError
from .types import JSONValue, VOQKey

_T = TypeVar("_T")
_SENTINEL = object()


def _coerce_int(value: Any, *, name: str, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if minimum is not None and coerced < minimum:
        raise ValidationError(
            f"{name} must be >= {minimum}",
            context={"value": coerced, "minimum": minimum},
        )
    return coerced


def iter_valid_voq_keys(n_ports: int, allow_self_traffic: bool = True) -> Iterator[VOQKey]:
    """Yield valid VOQ keys in stable row-major order.

    The returned order is deterministic: input port major, output port minor.
    """

    n_ports = _coerce_int(n_ports, name="n_ports", minimum=1)
    if not isinstance(allow_self_traffic, bool):
        raise ValidationError(
            "allow_self_traffic must be a boolean",
            context={"value": allow_self_traffic},
        )

    for src_port in range(n_ports):
        for dst_port in range(n_ports):
            if not allow_self_traffic and src_port == dst_port:
                continue
            yield (src_port, dst_port)


def canonicalize_voq_key(key: Sequence[Any]) -> VOQKey:
    """Validate and normalize a VOQ key into ``(src_port, dst_port)`` form."""

    if len(key) != 2:
        raise ValidationError("VOQ key must contain exactly two coordinates", context={"key": tuple(key)})
    src_port = _coerce_int(key[0], name="src_port", minimum=0)
    dst_port = _coerce_int(key[1], name="dst_port", minimum=0)
    return (src_port, dst_port)


def _field_value(obj: Any, field_name: str, default: Any = "") -> Any:
    if isinstance(obj, Mapping):
        return obj.get(field_name, default)
    return getattr(obj, field_name, default)


def _stable_object_key(obj: Any, field_names: Sequence[str]) -> tuple[object, ...]:
    key_parts: list[object] = []
    for field_name in field_names:
        value = _field_value(obj, field_name, _SENTINEL)
        if value is _SENTINEL:
            key_parts.append((0, ""))
        elif isinstance(value, bool):
            key_parts.append((1, int(value)))
        elif isinstance(value, Integral):
            key_parts.append((1, int(value)))
        elif isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("Non-finite floats are not supported in canonical ordering")
            key_parts.append((2, value))
        else:
            key_parts.append((3, canonical_json_dumps(value)))
    return tuple(key_parts)


def canonicalize_arrival_attempts(attempts: Iterable[_T]) -> tuple[_T, ...]:
    """Return arrival attempts in stable serialized order."""

    field_names = (
        "slot",
        "src_port",
        "dst_port",
        "flow_id",
        "packet_id",
        "generation_slot",
    )
    return tuple(sorted(attempts, key=lambda item: _stable_object_key(item, field_names)))


def canonicalize_admission_decisions(decisions: Iterable[_T]) -> tuple[_T, ...]:
    """Return admission decisions in stable serialized order."""

    field_names = (
        "slot",
        "src_port",
        "dst_port",
        "flow_id",
        "packet_id",
        "accepted",
        "reason",
    )
    return tuple(sorted(decisions, key=lambda item: _stable_object_key(item, field_names)))


def _normalize_mapping(mapping: Mapping[Any, Any]) -> dict[str, JSONValue]:
    return {
        str(key): normalize_for_json(value)
        for key, value in sorted(mapping.items(), key=lambda item: str(item[0]))
    }


def normalize_for_json(value: Any) -> JSONValue:
    """Recursively normalize a value into a deterministic JSON-safe structure.

    Supported inputs include built-in scalar/container types, dataclasses, enums,
    :class:`pathlib.Path`, and common NumPy scalar / array types.
    """

    if value is None or isinstance(value, (str, int, bool)):
        return value

    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite floats are not supported in canonical JSON")
        return value

    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("Non-finite decimals are not supported in canonical JSON")
        # Decimal is intentionally retained.  Schema-4 arrival probabilities,
        # rates, and multipliers must not pass through binary64 merely to be
        # serialized.  ``canonical_json_dumps`` writes it as a JSON number.
        return Decimal(0) if value.is_zero() else value

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, Enum):
        return normalize_for_json(value.value)

    if is_dataclass(value):
        return normalize_for_json(asdict(value))

    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        return normalize_for_json(to_dict())

    if isinstance(value, np.ndarray):
        return normalize_for_json(value.tolist())

    if isinstance(value, np.integer):
        return int(value)

    if isinstance(value, np.floating):
        float_value = float(value)
        if not math.isfinite(float_value):
            raise ValueError("Non-finite NumPy floats are not supported in canonical JSON")
        return float_value

    if isinstance(value, np.bool_):
        return bool(value)

    if isinstance(value, Mapping):
        return _normalize_mapping(value)

    if isinstance(value, (list, tuple)):
        return [normalize_for_json(item) for item in value]

    if isinstance(value, (set, frozenset)):
        normalized_items = [normalize_for_json(item) for item in value]
        normalized_items.sort(key=_canonical_json_sort_key)
        return normalized_items

    raise TypeError(f"Unsupported type for canonical JSON normalization: {type(value)!r}")


def _canonical_json_sort_key(value: Any) -> str:
    return canonical_json_dumps(value)


def _canonical_decimal_token(value: Decimal) -> str:
    """Return a unique finite JSON-number spelling for one Decimal value."""

    if not value.is_finite():
        raise ValueError("Non-finite decimals are not supported in canonical JSON")
    if value.is_zero():
        return "0"
    # Fixed-point output is deliberately used rather than an exponent spelling:
    # numerically equal Decimal values therefore hash and serialize identically.
    token = format(value, "f")
    if "." in token:
        token = token.rstrip("0").rstrip(".")
    return token


def _canonical_json_encode(value: JSONValue) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Decimal):
        return _canonical_decimal_token(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite floats are not supported in canonical JSON")
        return json.dumps(value, allow_nan=False)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        return "[" + ",".join(_canonical_json_encode(item) for item in value) + "]"
    if isinstance(value, dict):
        return "{" + ",".join(
            json.dumps(key, ensure_ascii=False) + ":" + _canonical_json_encode(value[key])
            for key in sorted(value)
        ) + "}"
    raise TypeError(f"Unsupported normalized JSON value: {type(value)!r}")


def canonical_json_dumps(value: Any) -> str:
    """Serialize ``value`` into deterministic, whitespace-minimized JSON."""

    normalized = normalize_for_json(value)
    return _canonical_json_encode(normalized)


def canonical_sha256_hexdigest(value: Any) -> str:
    """Return the SHA-256 hash of the canonical JSON representation of ``value``."""

    import hashlib

    payload = canonical_json_dumps(value).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


__all__ = [
    "iter_valid_voq_keys",
    "canonicalize_voq_key",
    "canonicalize_arrival_attempts",
    "canonicalize_admission_decisions",
    "normalize_for_json",
    "canonical_json_dumps",
    "canonical_sha256_hexdigest",
]
