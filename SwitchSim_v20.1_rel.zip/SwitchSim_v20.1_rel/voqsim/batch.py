from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
import time
from typing import Iterable, Mapping

from .config import (
    SimConfig,
    apply_queue_capacity_override,
    load_raw_config,
    resolve_config,
)
from .errors import SimError, ValidationError
from .kernel import (
    SimulationResult,
    build_simulation,
    validate_arrival_serviceability,
)
from .manifest import build_service_model
from .schedulers.domain import QueueSchedulerDomain
from .schedulers.registry import build_scheduler_for_domain
from .traffic.compiler import compile_arrival_spec
from .utils import canonical_json_dumps

BATCH_MANIFEST_FILENAME = "batch_manifest.json"
BATCH_SUMMARY_FILENAME = "batch_summary.json"
RUNS_SUBDIRNAME = "runs"
_SUPPORTED_CONFIG_SUFFIXES = frozenset({".yaml", ".yml", ".json"})
_KNOWN_RUN_ARTIFACT_NAMES = frozenset(
    {
        "resolved_config.yaml",
        "run_manifest.json",
        "service_model.json",
        "arrival_support.json",
        "flow_plan.json",
        "run_summary.json",
        "telemetry.jsonl",
        BATCH_MANIFEST_FILENAME,
        BATCH_SUMMARY_FILENAME,
        # Supplied configuration bundles may carry these descriptive sidecars.
        "manifest.json",
        "validation_report.json",
    }
)


@dataclass(slots=True, frozen=True)
class BatchDiscoveredConfig:
    """One config file discovered under a batch root."""

    config_path: Path
    relative_path: Path

    def to_dict(self) -> dict[str, str]:
        return {
            "config_path": str(self.config_path),
            "relative_path": str(self.relative_path),
        }


@dataclass(slots=True, frozen=True)
class BatchPreparedRun:
    """A preflight-validated run ready for execution."""

    config_path: Path
    relative_path: Path
    resolved_config: SimConfig
    output_dir: Path

    def to_dict(self) -> dict[str, object]:
        return {
            "config_path": str(self.config_path),
            "relative_path": str(self.relative_path),
            "output_dir": str(self.output_dir),
            "requested_seed": self.resolved_config.run.seed,
            "scheduler": self.resolved_config.scheduler.name,
            "scheduler_params": dict(self.resolved_config.scheduler.params),
            "schema_version": self.resolved_config.schema_version,
            "switch_kind": self.resolved_config.switch.kind,
            "n_queues": self.resolved_config.switch.n_queues,
            "service_family": self.resolved_config.scheduler.service_family,
            "arrival_family": self.resolved_config.arrival.family,
        }


@dataclass(slots=True, frozen=True)
class BatchRunResult:
    """One executed batch member result."""

    config_path: Path
    relative_path: Path
    output_dir: Path
    status: str
    elapsed_seconds: float
    requested_seed: int | None = None
    actual_seed: int | None = None
    telemetry_path: Path | None = None
    observation_path: Path | None = None
    summary_path: Path | None = None
    error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "config_path": str(self.config_path),
            "relative_path": str(self.relative_path),
            "output_dir": str(self.output_dir),
            "status": self.status,
            "elapsed_seconds": self.elapsed_seconds,
        }
        if self.requested_seed is not None:
            payload["requested_seed"] = self.requested_seed
        if self.actual_seed is not None:
            payload["actual_seed"] = self.actual_seed
        if self.telemetry_path is not None:
            payload["telemetry_path"] = str(self.telemetry_path)
        if self.observation_path is not None:
            payload["observation_path"] = str(self.observation_path)
        if self.summary_path is not None:
            payload["summary_path"] = str(self.summary_path)
        if self.error is not None:
            payload["error"] = self.error
        return payload


@dataclass(slots=True, frozen=True)
class BatchResult:
    """Aggregated result payload for a batch execution."""

    batch_dir: Path
    output_root: Path
    total_configs: int
    attempted_runs: int
    successful_runs: int
    failed_runs: int
    continue_on_error: bool
    completed_all_runs: bool
    elapsed_seconds: float
    results: tuple[BatchRunResult, ...]
    manifest_path: Path
    summary_path: Path

    def to_dict(self) -> dict[str, object]:
        return {
            "batch_dir": str(self.batch_dir),
            "output_root": str(self.output_root),
            "total_configs": self.total_configs,
            "attempted_runs": self.attempted_runs,
            "successful_runs": self.successful_runs,
            "failed_runs": self.failed_runs,
            "continue_on_error": self.continue_on_error,
            "completed_all_runs": self.completed_all_runs,
            "elapsed_seconds": self.elapsed_seconds,
            "manifest_path": str(self.manifest_path),
            "summary_path": str(self.summary_path),
            "results": [result.to_dict() for result in self.results],
        }


def is_known_run_artifact(path: str | Path) -> bool:
    return Path(path).name in _KNOWN_RUN_ARTIFACT_NAMES


def is_candidate_config_file(path: str | Path) -> bool:
    candidate = Path(path)
    if not candidate.is_file():
        return False
    if candidate.name.startswith("."):
        return False
    if candidate.suffix.lower() not in _SUPPORTED_CONFIG_SUFFIXES:
        return False
    if is_known_run_artifact(candidate):
        return False
    return True


def discover_config_files(batch_dir: str | Path, *, recursive: bool = True) -> tuple[BatchDiscoveredConfig, ...]:
    root = Path(batch_dir)
    if not root.exists():
        raise ValidationError("batch_dir does not exist", context={"batch_dir": str(root)})
    if not root.is_dir():
        raise ValidationError("batch_dir must be a directory", context={"batch_dir": str(root)})

    iterator: Iterable[Path]
    if recursive:
        iterator = root.rglob("*")
    else:
        iterator = root.iterdir()

    discovered: list[BatchDiscoveredConfig] = []
    for path in iterator:
        if not is_candidate_config_file(path):
            continue
        discovered.append(BatchDiscoveredConfig(config_path=path, relative_path=path.relative_to(root)))

    discovered.sort(key=lambda item: item.relative_path.as_posix())
    if not discovered:
        raise ValidationError("no config files were found under batch_dir", context={"batch_dir": str(root)})
    return tuple(discovered)


def relative_output_dir_for_config(batch_dir: str | Path, config_path: str | Path, output_root: str | Path) -> Path:
    batch_root = Path(batch_dir)
    config_file = Path(config_path)
    try:
        relative_path = config_file.relative_to(batch_root)
    except ValueError as exc:  # pragma: no cover - internal misuse
        raise ValidationError(
            "config_path must lie under batch_dir",
            context={"batch_dir": str(batch_root), "config_path": str(config_file)},
        ) from exc
    return Path(output_root) / RUNS_SUBDIRNAME / relative_path.with_suffix("")


def _validate_target_output_dir_is_available(output_dir: Path) -> None:
    if output_dir.exists() and output_dir.is_file():
        raise ValidationError("target run output path exists as a file", context={"output_dir": str(output_dir)})
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValidationError("target run output directory already exists and is not empty", context={"output_dir": str(output_dir)})


def validate_no_output_collisions(prepared_runs: Iterable[BatchPreparedRun]) -> None:
    seen: dict[Path, Path] = {}
    for prepared in prepared_runs:
        output_dir = prepared.output_dir
        existing = seen.get(output_dir)
        if existing is not None and existing != prepared.config_path:
            raise ValidationError(
                "multiple config files map to the same batch output directory",
                context={
                    "output_dir": str(output_dir),
                    "first_config": str(existing),
                    "second_config": str(prepared.config_path),
                },
            )
        seen[output_dir] = prepared.config_path


def _override_slot_trace(config: SimConfig, *, write_slot_trace: bool | None) -> SimConfig:
    if write_slot_trace is None or config.telemetry.write_slot_trace == write_slot_trace:
        return config
    return replace(config, telemetry=replace(config.telemetry, write_slot_trace=write_slot_trace))


def _compile_preflight_models(config: SimConfig) -> None:
    """Purely construct static models so failures precede every batch run.

    An unresolved random master seed uses zero only for this throwaway
    structural compilation. The actual run still resolves and records its own
    master seed in :func:`build_simulation`.
    """

    compile_seed = config.run.actual_seed
    if compile_seed is None:
        compile_seed = config.run.seed if config.run.seed >= 0 else 0
    compiled = compile_arrival_spec(config, actual_seed=compile_seed, validate=False)
    service_family = config.scheduler.service_family
    if service_family is None:  # pragma: no cover - config validation owns this
        raise ValidationError(
            "scheduler must resolve to exactly one service family",
            context={"scheduler": config.scheduler.name},
        )
    scheduler = build_scheduler_for_domain(
        config.scheduler.name,
        config.scheduler.params,
        QueueSchedulerDomain(
            queue_catalog=config.switch.catalog,
            service_family=service_family,
        ),
    )
    validate_arrival_serviceability(compiled, scheduler)
    build_service_model(config)


def preflight_batch_configs(
    batch_dir: str | Path,
    output_root: str | Path,
    *,
    recursive: bool = True,
    write_slot_trace: bool | None = None,
    queue_capacity_override: int | str | None = None,
) -> tuple[BatchPreparedRun, ...]:
    batch_root = Path(batch_dir)
    output_base = Path(output_root)
    discovered = discover_config_files(batch_root, recursive=recursive)

    prepared: list[BatchPreparedRun] = []
    errors: list[str] = []

    for item in discovered:
        try:
            raw_config = load_raw_config(item.config_path)
            if queue_capacity_override is not None:
                raw_config = apply_queue_capacity_override(raw_config, queue_capacity_override)
            resolved_config = _override_slot_trace(
                resolve_config(raw_config, validate=True),
                write_slot_trace=write_slot_trace,
            )
            _compile_preflight_models(resolved_config)
            output_dir = relative_output_dir_for_config(batch_root, item.config_path, output_base)
            _validate_target_output_dir_is_available(output_dir)
            prepared.append(
                BatchPreparedRun(
                    config_path=item.config_path,
                    relative_path=item.relative_path,
                    resolved_config=resolved_config,
                    output_dir=output_dir,
                )
            )
        except (SimError, OSError) as exc:
            errors.append(f"{item.relative_path.as_posix()}: {exc}")

    if errors:
        raise ValidationError(
            "batch preflight failed; all configs must validate before execution starts",
            context={"errors": errors},
        )

    prepared.sort(key=lambda item: item.relative_path.as_posix())
    try:
        validate_no_output_collisions(prepared)
    except ValidationError as exc:
        raise ValidationError(
            "batch preflight failed; all configs must validate before execution starts",
            context={"errors": [str(exc)]},
        ) from exc
    return tuple(prepared)


def run_one_prepared(prepared: BatchPreparedRun) -> BatchRunResult:
    start = time.perf_counter()
    try:
        simulator = build_simulation(prepared.resolved_config, output_dir=prepared.output_dir)
        result: SimulationResult = simulator.run()
        elapsed = time.perf_counter() - start
        return BatchRunResult(
            config_path=prepared.config_path,
            relative_path=prepared.relative_path,
            output_dir=prepared.output_dir,
            status="success",
            elapsed_seconds=elapsed,
            requested_seed=result.requested_seed,
            actual_seed=result.actual_seed,
            telemetry_path=result.telemetry_path,
            observation_path=result.observation_path,
            summary_path=result.summary_path,
        )
    except Exception as exc:
        elapsed = time.perf_counter() - start
        return BatchRunResult(
            config_path=prepared.config_path,
            relative_path=prepared.relative_path,
            output_dir=prepared.output_dir,
            status="failed",
            elapsed_seconds=elapsed,
            error=f"{type(exc).__name__}: {exc}",
        )


def write_batch_manifest(output_root: str | Path, prepared_runs: Iterable[BatchPreparedRun]) -> Path:
    output_base = Path(output_root)
    output_base.mkdir(parents=True, exist_ok=True)
    manifest_path = output_base / BATCH_MANIFEST_FILENAME
    payload = {
        "prepared_runs": [prepared.to_dict() for prepared in prepared_runs],
    }
    manifest_path.write_text(canonical_json_dumps(payload) + "\n", encoding="utf-8")
    return manifest_path


def write_batch_summary(output_root: str | Path, batch_result: BatchResult) -> Path:
    output_base = Path(output_root)
    output_base.mkdir(parents=True, exist_ok=True)
    summary_path = output_base / BATCH_SUMMARY_FILENAME
    summary_path.write_text(canonical_json_dumps(batch_result.to_dict()) + "\n", encoding="utf-8")
    return summary_path


def run_batch(
    prepared_runs: Iterable[BatchPreparedRun],
    *,
    batch_dir: str | Path,
    output_root: str | Path,
    continue_on_error: bool = False,
) -> BatchResult:
    prepared = tuple(prepared_runs)
    output_base = Path(output_root)
    output_base.mkdir(parents=True, exist_ok=True)
    manifest_path = write_batch_manifest(output_base, prepared)

    start = time.perf_counter()
    results: list[BatchRunResult] = []
    halted_early = False

    for item in prepared:
        result = run_one_prepared(item)
        results.append(result)
        if not result.succeeded and not continue_on_error:
            halted_early = True
            break

    elapsed = time.perf_counter() - start
    attempted = len(results)
    success_count = sum(1 for result in results if result.succeeded)
    failed_count = attempted - success_count
    completed_all_runs = attempted == len(prepared) and not halted_early
    batch_result = BatchResult(
        batch_dir=Path(batch_dir),
        output_root=output_base,
        total_configs=len(prepared),
        attempted_runs=attempted,
        successful_runs=success_count,
        failed_runs=failed_count,
        continue_on_error=continue_on_error,
        completed_all_runs=completed_all_runs,
        elapsed_seconds=elapsed,
        results=tuple(results),
        manifest_path=manifest_path,
        summary_path=output_base / BATCH_SUMMARY_FILENAME,
    )
    summary_path = write_batch_summary(output_base, batch_result)
    return BatchResult(
        batch_dir=batch_result.batch_dir,
        output_root=batch_result.output_root,
        total_configs=batch_result.total_configs,
        attempted_runs=batch_result.attempted_runs,
        successful_runs=batch_result.successful_runs,
        failed_runs=batch_result.failed_runs,
        continue_on_error=batch_result.continue_on_error,
        completed_all_runs=batch_result.completed_all_runs,
        elapsed_seconds=batch_result.elapsed_seconds,
        results=batch_result.results,
        manifest_path=batch_result.manifest_path,
        summary_path=summary_path,
    )


def run_batch_dir(
    batch_dir: str | Path,
    output_root: str | Path,
    *,
    continue_on_error: bool = False,
    recursive: bool = True,
    write_slot_trace: bool | None = None,
    queue_capacity_override: int | str | None = None,
) -> BatchResult:
    prepared = preflight_batch_configs(
        batch_dir,
        output_root,
        recursive=recursive,
        write_slot_trace=write_slot_trace,
        queue_capacity_override=queue_capacity_override,
    )
    return run_batch(
        prepared,
        batch_dir=batch_dir,
        output_root=output_root,
        continue_on_error=continue_on_error,
    )


__all__ = [
    "BATCH_MANIFEST_FILENAME",
    "BATCH_SUMMARY_FILENAME",
    "RUNS_SUBDIRNAME",
    "BatchDiscoveredConfig",
    "BatchPreparedRun",
    "BatchRunResult",
    "BatchResult",
    "discover_config_files",
    "is_candidate_config_file",
    "is_known_run_artifact",
    "relative_output_dir_for_config",
    "validate_no_output_collisions",
    "preflight_batch_configs",
    "run_one_prepared",
    "run_batch",
    "run_batch_dir",
    "write_batch_manifest",
    "write_batch_summary",
]
