"""Topology-neutral queue identity and queueing-state primitives.

The generalized simulator uses stable external queue identifiers at its public
boundaries and dense integer indices in the runtime hot path.  Crossbar VOQs
are represented by an ordinary :class:`QueueCatalog` whose entries carry
optional ``(input, output)`` metadata; the queue bank itself has no knowledge
of crossbar constraints.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from numbers import Integral
from types import MappingProxyType
from typing import Any

import numpy as np

from .errors import ScheduleError, ValidationError
from .events import AdmissionDecision, ArrivalAttempt, DepartureEvent
from .packet import Packet
from .types import JSONValue, QueueId, QueueIndex, QueueSnapshotMode, QueueVector, Slot, VOQKey
from .utils import canonicalize_voq_key

MAX_QUEUE_LENGTH = int(np.iinfo(np.int64).max)


def normalize_queue_id(value: Any, *, name: str = "queue_id") -> QueueId:
    """Validate one stable external queue identifier.

    Integer identifiers are nonnegative.  String identifiers are preserved
    byte-for-byte, but must be nonempty and may not have leading or trailing
    whitespace.  This deliberately avoids implicit label rewriting.
    """

    if isinstance(value, bool):
        raise ValidationError(f"{name} must be a nonnegative integer or nonempty string", context={"value": value})
    if isinstance(value, Integral):
        queue_id = int(value)
        if queue_id < 0:
            raise ValidationError(f"{name} integer must be >= 0", context={"value": queue_id})
        return queue_id
    if isinstance(value, str):
        if not value or not value.strip():
            raise ValidationError(f"{name} string must be nonempty", context={"value": value})
        if value != value.strip():
            raise ValidationError(
                f"{name} must not contain leading or trailing whitespace",
                context={"value": value},
            )
        return value
    raise ValidationError(
        f"{name} must be a nonnegative integer or nonempty string",
        context={"value": value, "value_type": type(value).__name__},
    )


def legacy_voq_queue_id(src_port: Any, dst_port: Any) -> str:
    """Return the canonical stable identifier for one legacy crossbar VOQ."""

    edge = canonicalize_voq_key((src_port, dst_port))
    return f"voq[{edge[0]},{edge[1]}]"


def _validate_index(value: Any, *, n_queues: int, name: str = "queue_index") -> QueueIndex:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    index = int(value)
    if not 0 <= index < n_queues:
        raise ValidationError(
            f"{name} is outside the queue catalog",
            context={"value": index, "n_queues": n_queues},
        )
    return index


@dataclass(slots=True, frozen=True)
class QueueSpec:
    """One queue's stable identity and optional legacy VOQ metadata.

    ``legacy_voq`` is metadata, not identity.  Multiple labeled queues may
    therefore carry the same endpoint pair, which is required for parallel
    links in node-exclusive generalized switches.
    """

    queue_id: QueueId
    legacy_voq: VOQKey | None = None

    def __post_init__(self) -> None:
        queue_id = normalize_queue_id(self.queue_id)
        legacy_voq = None if self.legacy_voq is None else canonicalize_voq_key(self.legacy_voq)
        object.__setattr__(self, "queue_id", queue_id)
        object.__setattr__(self, "legacy_voq", legacy_voq)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "queue_id": self.queue_id,
            "legacy_voq": None if self.legacy_voq is None else [self.legacy_voq[0], self.legacy_voq[1]],
        }


@dataclass(slots=True, frozen=True, init=False)
class QueueCatalog:
    """Ordered queue catalog with O(1) stable-ID/dense-index translation."""

    specs: tuple[QueueSpec, ...]
    _queue_ids: tuple[QueueId, ...] = field(repr=False, compare=False)
    _index_by_id: Mapping[QueueId, QueueIndex] = field(repr=False, compare=False)
    _indices_by_voq: Mapping[VOQKey, tuple[QueueIndex, ...]] = field(repr=False, compare=False)

    def __init__(self, specs: Iterable[QueueSpec | QueueId]) -> None:
        normalized: list[QueueSpec] = []
        index_by_id: dict[QueueId, QueueIndex] = {}
        indices_by_voq: dict[VOQKey, list[QueueIndex]] = {}

        for index, raw_spec in enumerate(specs):
            spec = raw_spec if isinstance(raw_spec, QueueSpec) else QueueSpec(raw_spec)
            if spec.queue_id in index_by_id:
                raise ValidationError(
                    "Queue catalog contains duplicate queue identifiers",
                    context={
                        "queue_id": spec.queue_id,
                        "first_index": index_by_id[spec.queue_id],
                        "duplicate_index": index,
                    },
                )
            index_by_id[spec.queue_id] = index
            normalized.append(spec)
            if spec.legacy_voq is not None:
                indices_by_voq.setdefault(spec.legacy_voq, []).append(index)

        if not normalized:
            raise ValidationError("Queue catalog must contain at least one queue")

        frozen_voq_map = {edge: tuple(indices) for edge, indices in indices_by_voq.items()}
        object.__setattr__(self, "specs", tuple(normalized))
        object.__setattr__(self, "_queue_ids", tuple(spec.queue_id for spec in normalized))
        object.__setattr__(self, "_index_by_id", MappingProxyType(index_by_id))
        object.__setattr__(self, "_indices_by_voq", MappingProxyType(frozen_voq_map))

    @classmethod
    def legacy_crossbar(cls, n_ports: Any) -> QueueCatalog:
        """Build the full row-major ``N x N`` legacy VOQ catalog."""

        if isinstance(n_ports, bool) or not isinstance(n_ports, Integral) or int(n_ports) < 1:
            raise ValidationError("n_ports must be an integer >= 1", context={"value": n_ports})
        size = int(n_ports)
        return cls(
            QueueSpec(legacy_voq_queue_id(src_port, dst_port), legacy_voq=(src_port, dst_port))
            for src_port in range(size)
            for dst_port in range(size)
        )

    @property
    def n_queues(self) -> int:
        return len(self.specs)

    @property
    def queue_ids(self) -> tuple[QueueId, ...]:
        return self._queue_ids

    def __len__(self) -> int:
        return len(self.specs)

    def __iter__(self):
        return iter(self.specs)

    def index_of(self, queue_id: Any) -> QueueIndex:
        normalized = normalize_queue_id(queue_id)
        try:
            return self._index_by_id[normalized]
        except KeyError as exc:
            raise ValidationError(
                "queue_id is outside the queue catalog",
                context={"queue_id": normalized, "n_queues": self.n_queues},
            ) from exc

    def queue_id_at(self, queue_index: Any) -> QueueId:
        return self.specs[_validate_index(queue_index, n_queues=self.n_queues)].queue_id

    def spec_for(self, queue_id: Any) -> QueueSpec:
        return self.specs[self.index_of(queue_id)]

    def spec_at(self, queue_index: Any) -> QueueSpec:
        return self.specs[_validate_index(queue_index, n_queues=self.n_queues)]

    def legacy_voq_for(self, queue_id: Any) -> VOQKey | None:
        return self.spec_for(queue_id).legacy_voq

    def queue_ids_for_voq(self, edge: Sequence[Any]) -> tuple[QueueId, ...]:
        canonical = canonicalize_voq_key(edge)
        return tuple(self.specs[index].queue_id for index in self._indices_by_voq.get(canonical, ()))

    def queue_id_for_voq(self, edge: Sequence[Any]) -> QueueId:
        """Return the unique queue carrying ``edge`` metadata.

        Generalized catalogs may intentionally map parallel labeled queues to
        the same endpoints.  Such a reverse lookup is ambiguous and therefore
        fails explicitly instead of selecting an arbitrary representative.
        """

        canonical = canonicalize_voq_key(edge)
        matches = self._indices_by_voq.get(canonical, ())
        if not matches:
            raise ValidationError(
                "No queue in the catalog has the requested legacy VOQ metadata",
                context={"legacy_voq": canonical},
            )
        if len(matches) != 1:
            raise ValidationError(
                "Legacy VOQ metadata does not uniquely identify a queue",
                context={
                    "legacy_voq": canonical,
                    "queue_ids": [self.specs[index].queue_id for index in matches],
                },
            )
        return self.specs[matches[0]].queue_id

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "n_queues": self.n_queues,
            "queues": [spec.to_dict() for spec in self.specs],
        }


@dataclass(slots=True, frozen=True)
class ServiceDecision:
    """Binary service request expressed in stable external queue IDs."""

    selected_queue_ids: tuple[QueueId, ...] = ()

    def __post_init__(self) -> None:
        if isinstance(self.selected_queue_ids, (str, bytes, bytearray)):
            raise ValidationError(
                "selected_queue_ids must be an iterable of queue identifiers, not a string",
                context={"value": self.selected_queue_ids},
            )
        try:
            raw_ids = tuple(self.selected_queue_ids)
        except TypeError as exc:
            raise ValidationError(
                "selected_queue_ids must be an iterable of queue identifiers",
                context={"value_type": type(self.selected_queue_ids).__name__},
            ) from exc
        normalized = tuple(
            normalize_queue_id(queue_id, name=f"selected_queue_ids[{index}]")
            for index, queue_id in enumerate(raw_ids)
        )
        seen: dict[QueueId, int] = {}
        for index, queue_id in enumerate(normalized):
            if queue_id in seen:
                raise ScheduleError(
                    "ServiceDecision contains a duplicate queue identifier",
                    context={
                        "queue_id": queue_id,
                        "first_index": seen[queue_id],
                        "duplicate_index": index,
                    },
                )
            seen[queue_id] = index
        object.__setattr__(self, "selected_queue_ids", normalized)

    @classmethod
    def empty(cls) -> ServiceDecision:
        return cls(())

    @classmethod
    def from_indices(cls, queue_indices: Iterable[Any], catalog: QueueCatalog) -> ServiceDecision:
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError("catalog must be a QueueCatalog")
        return cls(tuple(catalog.queue_id_at(index) for index in queue_indices))

    @property
    def selected_count(self) -> int:
        return len(self.selected_queue_ids)

    def __len__(self) -> int:
        return len(self.selected_queue_ids)

    def __iter__(self):
        return iter(self.selected_queue_ids)

    def canonical_for(self, catalog: QueueCatalog) -> ServiceDecision:
        indexed = sorted((catalog.index_of(queue_id), queue_id) for queue_id in self.selected_queue_ids)
        return ServiceDecision(tuple(queue_id for _index, queue_id in indexed))

    def to_service_vector(self, catalog: QueueCatalog) -> QueueVector:
        vector = np.zeros(catalog.n_queues, dtype=np.int64)
        for queue_id in self.selected_queue_ids:
            vector[catalog.index_of(queue_id)] = 1
        return vector

    def to_dict(self) -> dict[str, JSONValue]:
        return {"selected_queue_ids": list(self.selected_queue_ids)}


def _normalize_capacity(value: Any, *, name: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer >= 1 or null", context={"value": value})
    capacity = int(value)
    if capacity < 1:
        raise ValidationError(f"{name} must be >= 1", context={"value": capacity})
    if capacity > MAX_QUEUE_LENGTH:
        raise ValidationError(
            f"{name} exceeds the int64 queue-length limit",
            context={"value": capacity, "maximum": MAX_QUEUE_LENGTH},
        )
    return capacity


class QueueBank:
    """High-throughput topology-neutral finite or RAM-only NoDrop queue bank.

    Queue lengths are maintained in a contiguous ``np.int64`` vector.  Public
    service requests use stable queue IDs, but validation resolves them to
    dense indices exactly once.  Every selected queue and head packet is fully
    checked before the first dequeue, giving atomic failure for invalid,
    duplicate, out-of-domain, empty, or same-slot service requests.
    """

    __slots__ = (
        "catalog",
        "_capacities",
        "_lengths",
        "_readonly_lengths",
        "_queues",
        "_total_occupancy",
        "_peak_occupancy",
        "_allowed_arrival_indices",
        "check_arrival_support",
    )

    def __init__(
        self,
        catalog: QueueCatalog,
        queue_capacity: int | None | Sequence[int | None] | Mapping[QueueId, int | None],
        *,
        allowed_arrival_queue_ids: Iterable[QueueId] | None = None,
        check_arrival_support: bool = True,
    ) -> None:
        if not isinstance(catalog, QueueCatalog):
            raise ValidationError(
                "catalog must be a QueueCatalog",
                context={"value_type": type(catalog).__name__},
            )
        if not isinstance(check_arrival_support, bool):
            raise ValidationError(
                "check_arrival_support must be a boolean",
                context={"value": check_arrival_support},
            )

        capacities = self._build_capacities(catalog, queue_capacity)
        allowed_indices = self._build_allowed_indices(catalog, allowed_arrival_queue_ids)
        lengths = np.zeros(catalog.n_queues, dtype=np.int64)
        readonly_lengths = lengths.view()
        readonly_lengths.flags.writeable = False

        self.catalog = catalog
        self._capacities = capacities
        self._lengths = lengths
        self._readonly_lengths = readonly_lengths
        self._queues = tuple(deque() for _index in range(catalog.n_queues))
        self._total_occupancy = 0
        self._peak_occupancy = 0
        self._allowed_arrival_indices = allowed_indices
        self.check_arrival_support = check_arrival_support

    @staticmethod
    def _build_capacities(
        catalog: QueueCatalog,
        raw: int | None | Sequence[int | None] | Mapping[QueueId, int | None],
    ) -> tuple[int | None, ...]:
        if isinstance(raw, Mapping):
            normalized: dict[QueueId, int | None] = {}
            for queue_id, value in raw.items():
                canonical = normalize_queue_id(queue_id)
                catalog.index_of(canonical)
                if canonical in normalized:
                    raise ValidationError("Duplicate queue capacity", context={"queue_id": canonical})
                normalized[canonical] = _normalize_capacity(value, name=f"capacity[{canonical!r}]")
            missing = [queue_id for queue_id in catalog.queue_ids if queue_id not in normalized]
            if missing:
                raise ValidationError(
                    "Per-queue capacity mapping is incomplete",
                    context={"missing_queue_ids": missing},
                )
            return tuple(normalized[queue_id] for queue_id in catalog.queue_ids)

        if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes, bytearray)):
            values = tuple(raw)
            if len(values) != catalog.n_queues:
                raise ValidationError(
                    "Per-queue capacity sequence length does not match queue catalog",
                    context={"length": len(values), "n_queues": catalog.n_queues},
                )
            return tuple(
                _normalize_capacity(value, name=f"queue_capacity[{index}]")
                for index, value in enumerate(values)
            )

        capacity = _normalize_capacity(raw, name="queue_capacity")
        return (capacity,) * catalog.n_queues

    @staticmethod
    def _build_allowed_indices(
        catalog: QueueCatalog,
        raw_queue_ids: Iterable[QueueId] | None,
    ) -> frozenset[QueueIndex] | None:
        if raw_queue_ids is None:
            return None
        indices: list[QueueIndex] = []
        seen: dict[QueueIndex, int] = {}
        for position, queue_id in enumerate(raw_queue_ids):
            index = catalog.index_of(queue_id)
            if index in seen:
                raise ValidationError(
                    "allowed_arrival_queue_ids contains duplicate queue identifiers",
                    context={
                        "queue_id": catalog.queue_id_at(index),
                        "first_index": seen[index],
                        "duplicate_index": position,
                    },
                )
            seen[index] = position
            indices.append(index)
        return frozenset(indices)

    @property
    def n_queues(self) -> int:
        return self.catalog.n_queues

    @property
    def queues(self) -> tuple[deque[Packet], ...]:
        """Diagnostic access to the FIFO deques; callers must not mutate them."""

        return self._queues

    @property
    def capacities(self) -> tuple[int | None, ...]:
        return self._capacities

    @property
    def is_no_drop(self) -> bool:
        """Whether every queue admits without a finite buffer-full branch."""

        return all(capacity is None for capacity in self._capacities)

    @property
    def allowed_arrival_queue_ids(self) -> frozenset[QueueId] | None:
        if self._allowed_arrival_indices is None:
            return None
        return frozenset(self.catalog.queue_id_at(index) for index in self._allowed_arrival_indices)

    def capacity_for(self, queue_id: QueueId) -> int | None:
        return self._capacities[self.catalog.index_of(queue_id)]

    def queue_lengths(self) -> QueueVector:
        """Return a writable copy of the dense queue-length vector."""

        return self._lengths.copy()

    def queue_lengths_view(self) -> QueueVector:
        """Return a zero-copy read-only view for trusted scheduler hot paths."""

        return self._readonly_lengths

    def total_occupancy(self) -> int:
        """Return exact current system occupancy in O(1)."""

        return self._total_occupancy

    def peak_occupancy(self) -> int:
        """Return exact peak system occupancy since construction or reset."""

        return self._peak_occupancy

    def is_empty(self) -> bool:
        return self._total_occupancy == 0

    def occupancy(self, queue_id: QueueId) -> int:
        return int(self._lengths[self.catalog.index_of(queue_id)])

    def nonempty_queue_ids(self) -> tuple[QueueId, ...]:
        return tuple(self.catalog.queue_id_at(int(index)) for index in np.flatnonzero(self._lengths))

    def snapshot(self, mode: QueueSnapshotMode = "dense") -> JSONValue:
        if mode == "dense":
            return self._lengths.tolist()
        if mode == "sparse_nonzero":
            return [
                [self.catalog.queue_id_at(int(index)), int(self._lengths[index])]
                for index in np.flatnonzero(self._lengths)
            ]
        if mode == "disabled":
            return None
        raise ValidationError(
            "Unsupported queue snapshot mode",
            context={"mode": mode, "allowed": ["dense", "sparse_nonzero", "disabled"]},
        )

    def _assert_index_consistency(self, index: QueueIndex) -> None:
        actual = len(self._queues[index])
        recorded = int(self._lengths[index])
        if actual != recorded:
            raise ValidationError(
                "QueueBank length vector is inconsistent with FIFO storage",
                context={
                    "queue_id": self.catalog.queue_id_at(index),
                    "queue_index": index,
                    "deque_length": actual,
                    "recorded_length": recorded,
                },
            )
        capacity = self._capacities[index]
        if capacity is not None and recorded > capacity:
            raise ValidationError(
                "QueueBank occupancy exceeds queue capacity",
                context={
                    "queue_id": self.catalog.queue_id_at(index),
                    "occupancy": recorded,
                    "capacity": capacity,
                },
            )

    def assert_internal_consistency(self) -> None:
        """Perform a full diagnostic consistency scan outside the hot path."""

        actual_total = 0
        for index in range(self.n_queues):
            self._assert_index_consistency(index)
            actual_total += len(self._queues[index])
        if self._total_occupancy != actual_total:
            raise ValidationError(
                "QueueBank total occupancy is inconsistent with FIFO storage",
                context={
                    "recorded_total_occupancy": self._total_occupancy,
                    "actual_total_occupancy": actual_total,
                },
            )
        if self._peak_occupancy < self._total_occupancy:
            raise ValidationError(
                "QueueBank peak occupancy is below current total occupancy",
                context={
                    "peak_occupancy": self._peak_occupancy,
                    "total_occupancy": self._total_occupancy,
                },
            )

    def _resolve_service_decision(
        self,
        decision: ServiceDecision,
        *,
        require_nonempty: bool,
        service_slot: int | None = None,
    ) -> tuple[tuple[QueueIndex, ...], ServiceDecision]:
        if not isinstance(decision, ServiceDecision):
            raise ScheduleError(
                "service decision must be a ServiceDecision",
                context={"value_type": type(decision).__name__},
            )

        indexed: list[tuple[QueueIndex, QueueId]] = []
        seen_indices: dict[QueueIndex, int] = {}
        for position, queue_id in enumerate(decision.selected_queue_ids):
            try:
                index = self.catalog.index_of(queue_id)
            except ValidationError as exc:
                raise ScheduleError(
                    "ServiceDecision selects a queue outside the queue catalog",
                    context={"queue_id": queue_id, "position": position},
                ) from exc
            if index in seen_indices:  # defensive if a noncanonical object bypasses __post_init__
                raise ScheduleError(
                    "ServiceDecision selects the same queue more than once",
                    context={
                        "queue_id": queue_id,
                        "first_position": seen_indices[index],
                        "duplicate_position": position,
                    },
                )
            seen_indices[index] = position
            indexed.append((index, queue_id))

        indexed.sort(key=lambda item: item[0])
        for index, queue_id in indexed:
            self._assert_index_consistency(index)
            occupancy = int(self._lengths[index])
            if require_nonempty and occupancy == 0:
                raise ScheduleError(
                    "ServiceDecision selects an empty queue",
                    context={"queue_id": queue_id, "queue_index": index},
                )
            if occupancy == 0:
                continue
            packet = self._queues[index][0]
            if packet.queue_id != queue_id:
                raise ValidationError(
                    "Queued packet identity does not match its QueueBank queue",
                    context={
                        "queue_id": queue_id,
                        "packet_queue_id": packet.queue_id,
                        "packet_id": packet.packet_id,
                    },
                )
            if packet.enqueue_slot is None:
                raise ValidationError(
                    "Queued packet is missing enqueue_slot",
                    context={"queue_id": queue_id, "packet_id": packet.packet_id},
                )
            if service_slot is not None and service_slot <= packet.enqueue_slot:
                raise ValidationError(
                    "Packet cannot be served in the same slot it was enqueued",
                    context={
                        "queue_id": queue_id,
                        "packet_id": packet.packet_id,
                        "service_slot": service_slot,
                        "enqueue_slot": packet.enqueue_slot,
                    },
                )

        indices = tuple(index for index, _queue_id in indexed)
        canonical = ServiceDecision(tuple(queue_id for _index, queue_id in indexed))
        return indices, canonical

    def validate_service_decision(
        self,
        decision: ServiceDecision,
        *,
        require_nonempty: bool = True,
    ) -> ServiceDecision:
        """Validate and return the decision ordered by catalog index."""

        _indices, canonical = self._resolve_service_decision(decision, require_nonempty=require_nonempty)
        return canonical

    def service(self, decision: ServiceDecision, slot: Slot) -> tuple[DepartureEvent, ...]:
        """Atomically serve exactly one packet from every selected queue."""

        if isinstance(slot, bool) or not isinstance(slot, Integral) or int(slot) < 0:
            raise ValidationError("slot must be an integer >= 0", context={"value": slot})
        service_slot = int(slot)
        indices, canonical = self._resolve_service_decision(
            decision,
            require_nonempty=True,
            service_slot=service_slot,
        )

        # Build every event before mutation.  Event validation or a bad head
        # packet can therefore never leave a partially serviced queue bank.
        departures: list[DepartureEvent] = []
        for index, queue_id in zip(indices, canonical.selected_queue_ids, strict=True):
            before = int(self._lengths[index])
            packet = self._queues[index][0]
            departures.append(
                DepartureEvent.from_packet(
                    packet,
                    slot=service_slot,
                    queue_occupancy_before=before,
                    queue_occupancy_after=before - 1,
                )
            )

        for index in indices:
            self._queues[index].popleft()
            self._lengths[index] -= 1
            self._total_occupancy -= 1
        return tuple(departures)

    def enqueue_or_drop(
        self,
        arrival_attempts: Iterable[ArrivalAttempt],
        slot: Slot,
    ) -> tuple[AdmissionDecision, ...]:
        """Admit a packet batch in deterministic queue/packet order.

        Multiple attempts for one queue are processed sequentially in the
        canonical catalog/packet order.
        """

        if isinstance(slot, bool) or not isinstance(slot, Integral) or int(slot) < 0:
            raise ValidationError("slot must be an integer >= 0", context={"value": slot})
        admission_slot = int(slot)
        indexed_attempts: list[tuple[QueueIndex, ArrivalAttempt]] = []

        # Validate the complete batch before constructing decisions or mutating
        # any FIFO.  This includes all out-of-domain/support checks.
        for position, attempt in enumerate(tuple(arrival_attempts)):
            if not isinstance(attempt, ArrivalAttempt):
                raise ValidationError(
                    "arrival_attempts must contain ArrivalAttempt instances",
                    context={"index": position, "value_type": type(attempt).__name__},
                )
            if attempt.slot != admission_slot:
                raise ValidationError(
                    "ArrivalAttempt slot does not match QueueBank admission slot",
                    context={
                        "index": position,
                        "attempt_slot": attempt.slot,
                        "admission_slot": admission_slot,
                        "packet_id": attempt.packet_id,
                    },
                )
            try:
                index = self.catalog.index_of(attempt.queue_id)
            except ValidationError as exc:
                raise ValidationError(
                    "ArrivalAttempt targets a queue outside the queue catalog",
                    context={"queue_id": attempt.queue_id, "packet_id": attempt.packet_id},
                ) from exc
            if (
                self.check_arrival_support
                and self._allowed_arrival_indices is not None
                and index not in self._allowed_arrival_indices
            ):
                raise ValidationError(
                    "ArrivalAttempt targets a queue outside the allowed arrival support",
                    context={"queue_id": attempt.queue_id, "packet_id": attempt.packet_id},
                )
            self._assert_index_consistency(index)
            indexed_attempts.append((index, attempt))

        indexed_attempts.sort(key=lambda item: (item[0], item[1].flow_id, item[1].packet_id))
        prospective_lengths: dict[QueueIndex, int] = {}
        decisions: list[tuple[QueueIndex, AdmissionDecision]] = []

        for index, attempt in indexed_attempts:
            before = prospective_lengths.get(index, int(self._lengths[index]))
            capacity = self._capacities[index]
            if capacity is None or before < capacity:
                if before >= MAX_QUEUE_LENGTH:
                    raise ValidationError(
                        "Queue occupancy cannot be represented by the int64 queue-length bank",
                        context={
                            "queue_id": self.catalog.queue_id_at(index),
                            "occupancy": before,
                            "maximum": MAX_QUEUE_LENGTH,
                        },
                    )
                after = before + 1
                decision = AdmissionDecision.accept(
                    attempt.packet,
                    slot=admission_slot,
                    queue_occupancy_before=before,
                    queue_occupancy_after=after,
                    voq_capacity=capacity,
                )
                prospective_lengths[index] = after
            else:
                decision = AdmissionDecision.dropped_buffer_full(
                    attempt.packet,
                    slot=admission_slot,
                    queue_occupancy_before=before,
                    queue_occupancy_after=before,
                    voq_capacity=capacity,
                )
            decisions.append((index, decision))

        # All validation and event construction has succeeded; commit in the
        # same canonical order used to compute occupancy-before/after fields.
        for index, decision in decisions:
            if decision.accepted:
                next_total = self._total_occupancy + 1
                self._queues[index].append(decision.packet)
                self._lengths[index] += 1
                self._total_occupancy = next_total
                if next_total > self._peak_occupancy:
                    self._peak_occupancy = next_total
        return tuple(decision for _index, decision in decisions)

    def reset(self) -> None:
        for queue in self._queues:
            queue.clear()
        self._lengths.fill(0)
        self._total_occupancy = 0
        self._peak_occupancy = 0


__all__ = [
    "MAX_QUEUE_LENGTH",
    "normalize_queue_id",
    "legacy_voq_queue_id",
    "QueueSpec",
    "QueueCatalog",
    "ServiceDecision",
    "QueueBank",
]
