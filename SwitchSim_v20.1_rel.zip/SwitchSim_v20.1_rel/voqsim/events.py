from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from numbers import Integral
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Mapping, TypeAlias

import numpy as np

from .errors import ValidationError
from .packet import Packet
from .types import FlowId, JSONValue, PacketId, PortId, QueueId, Slot, VOQKey

if TYPE_CHECKING:
    from .schedulers.exact_gap import ExactGapCertificate

ARRIVAL_ATTEMPT_EVENT_TYPE = "arrival_attempt"
ADMISSION_DECISION_EVENT_TYPE = "admission_decision"
DEPARTURE_EVENT_TYPE = "departure"
COMPLETION_EVENT_TYPE = "completion"

ADMISSION_REASON_ENQUEUED = "enqueued"
ADMISSION_REASON_BUFFER_FULL = "buffer_full"
SUPPORTED_ADMISSION_REASONS = frozenset({ADMISSION_REASON_ENQUEUED, ADMISSION_REASON_BUFFER_FULL})

AdmissionReason: TypeAlias = str
SimEvent: TypeAlias = "ArrivalAttempt | AdmissionDecision | DepartureEvent | CompletionEvent"



def _validate_non_negative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    coerced = int(value)
    if coerced < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": coerced, "minimum": 0})
    return coerced



def _validate_optional_non_negative_int(value: Any, *, name: str) -> int | None:
    if value is None:
        return None
    return _validate_non_negative_int(value, name=name)



def _normalize_reason(value: Any) -> str:
    if not isinstance(value, str):
        raise ValidationError("reason must be a string", context={"value": value})
    reason = value.strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in reason:
        reason = reason.replace("__", "_")
    reason = reason.strip("_")
    if reason not in SUPPORTED_ADMISSION_REASONS:
        raise ValidationError(
            "Unsupported admission reason",
            context={"reason": value, "allowed": sorted(SUPPORTED_ADMISSION_REASONS)},
        )
    return reason


@dataclass(slots=True, frozen=True)
class _PacketEventBase:
    """Validated base class shared by all packet-centric runtime events."""

    slot: Slot
    packet: Packet

    def __post_init__(self) -> None:
        slot = _validate_non_negative_int(self.slot, name="slot")
        if not isinstance(self.packet, Packet):
            raise ValidationError(
                "packet must be an instance of Packet",
                context={"value_type": type(self.packet).__name__},
            )
        object.__setattr__(self, "slot", slot)

    @property
    def packet_id(self) -> PacketId:
        return self.packet.packet_id

    @property
    def flow_id(self) -> FlowId:
        return self.packet.flow_id

    @property
    def queue_id(self) -> QueueId:
        # Packet.__post_init__ guarantees this is no longer None.
        queue_id = self.packet.queue_id
        if queue_id is None:  # pragma: no cover - defensive for forged objects
            raise ValidationError("Event packet is missing queue_id", context={"packet_id": self.packet_id})
        return queue_id

    @property
    def src_port(self) -> PortId | None:
        return self.packet.src_port

    @property
    def dst_port(self) -> PortId | None:
        return self.packet.dst_port

    @property
    def generation_slot(self) -> Slot:
        return self.packet.generation_slot

    @property
    def enqueue_slot(self) -> Slot | None:
        return self.packet.enqueue_slot

    @property
    def completion_slot(self) -> Slot | None:
        return self.packet.completion_slot

    @property
    def voq_key(self) -> VOQKey:
        return self.packet.voq_key

    @property
    def residence_slots(self) -> int | None:
        return self.packet.residence_slots

    @property
    def waiting_slots(self) -> int | None:
        return self.packet.waiting_slots

    def _packet_fields(self) -> dict[str, JSONValue]:
        voq_key: JSONValue
        if self.packet.has_legacy_voq:
            legacy = self.packet.voq_key
            voq_key = [legacy[0], legacy[1]]
        else:
            voq_key = None
        return {
            **self.packet.to_dict(),
            "voq_key": voq_key,
        }


@dataclass(slots=True, frozen=True)
class ArrivalAttempt(_PacketEventBase):
    """One offered exogenous packet materialized from one active arrival-mask coordinate."""

    def __post_init__(self) -> None:
        _PacketEventBase.__post_init__(self)
        if self.packet.generation_slot != self.slot:
            raise ValidationError(
                "ArrivalAttempt.slot must equal packet.generation_slot",
                context={
                    "packet_id": self.packet.packet_id,
                    "slot": self.slot,
                    "generation_slot": self.packet.generation_slot,
                },
            )
        if self.packet.enqueue_slot is not None or self.packet.completion_slot is not None:
            raise ValidationError(
                "ArrivalAttempt packet must be newly offered for the slot and not yet enqueued/completed",
                context={
                    "packet_id": self.packet.packet_id,
                    "enqueue_slot": self.packet.enqueue_slot,
                    "completion_slot": self.packet.completion_slot,
                },
            )

    @classmethod
    def from_packet(cls, packet: Packet) -> ArrivalAttempt:
        return cls(slot=packet.generation_slot, packet=packet)

    @property
    def event_type(self) -> str:
        return ARRIVAL_ATTEMPT_EVENT_TYPE

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "event_type": self.event_type,
            "slot": self.slot,
            **self._packet_fields(),
        }


@dataclass(slots=True, frozen=True)
class AdmissionDecision(_PacketEventBase):
    """Result of attempting to enqueue one offered packet into its VOQ."""

    accepted: bool
    reason: AdmissionReason
    queue_occupancy_before: int | None = None
    queue_occupancy_after: int | None = None
    voq_capacity: int | None = None

    def __post_init__(self) -> None:
        _PacketEventBase.__post_init__(self)
        if not isinstance(self.accepted, bool):
            raise ValidationError("accepted must be a boolean", context={"value": self.accepted})
        reason = _normalize_reason(self.reason)
        before = _validate_optional_non_negative_int(self.queue_occupancy_before, name="queue_occupancy_before")
        after = _validate_optional_non_negative_int(self.queue_occupancy_after, name="queue_occupancy_after")
        capacity = _validate_optional_non_negative_int(self.voq_capacity, name="voq_capacity")

        if self.packet.generation_slot != self.slot:
            raise ValidationError(
                "AdmissionDecision.slot must equal packet.generation_slot",
                context={
                    "packet_id": self.packet.packet_id,
                    "slot": self.slot,
                    "generation_slot": self.packet.generation_slot,
                },
            )

        if self.accepted:
            if reason != ADMISSION_REASON_ENQUEUED:
                raise ValidationError(
                    "Accepted AdmissionDecision must use reason='enqueued'",
                    context={"reason": reason},
                )
            if self.packet.enqueue_slot != self.slot:
                raise ValidationError(
                    "Accepted packet must be stamped with enqueue_slot equal to AdmissionDecision.slot",
                    context={
                        "packet_id": self.packet.packet_id,
                        "slot": self.slot,
                        "enqueue_slot": self.packet.enqueue_slot,
                    },
                )
            if self.packet.completion_slot is not None:
                raise ValidationError(
                    "Accepted packet cannot already be completed",
                    context={"packet_id": self.packet.packet_id, "completion_slot": self.packet.completion_slot},
                )
            if before is not None and after is not None and after != before + 1:
                raise ValidationError(
                    "Accepted admission must increase queue occupancy by exactly one",
                    context={
                        "queue_occupancy_before": before,
                        "queue_occupancy_after": after,
                        "packet_id": self.packet.packet_id,
                    },
                )
            if capacity is not None and before is not None and before >= capacity:
                raise ValidationError(
                    "Accepted admission cannot occur when the VOQ is already full",
                    context={
                        "queue_occupancy_before": before,
                        "voq_capacity": capacity,
                        "packet_id": self.packet.packet_id,
                    },
                )
        else:
            if reason != ADMISSION_REASON_BUFFER_FULL:
                raise ValidationError(
                    "Rejected AdmissionDecision currently only supports reason='buffer_full'",
                    context={"reason": reason},
                )
            if self.packet.enqueue_slot is not None:
                raise ValidationError(
                    "Dropped packet must not have enqueue_slot set",
                    context={"packet_id": self.packet.packet_id, "enqueue_slot": self.packet.enqueue_slot},
                )
            if self.packet.completion_slot is not None:
                raise ValidationError(
                    "Dropped packet cannot be completed",
                    context={"packet_id": self.packet.packet_id, "completion_slot": self.packet.completion_slot},
                )
            if before is not None and after is not None and after != before:
                raise ValidationError(
                    "Dropped admission must leave queue occupancy unchanged",
                    context={
                        "queue_occupancy_before": before,
                        "queue_occupancy_after": after,
                        "packet_id": self.packet.packet_id,
                    },
                )
            if capacity is not None and before is not None and before != capacity:
                raise ValidationError(
                    "Buffer-full drop requires queue_occupancy_before to equal voq_capacity",
                    context={
                        "queue_occupancy_before": before,
                        "voq_capacity": capacity,
                        "packet_id": self.packet.packet_id,
                    },
                )

        if capacity is not None:
            if before is not None and before > capacity:
                raise ValidationError(
                    "queue_occupancy_before cannot exceed voq_capacity",
                    context={
                        "queue_occupancy_before": before,
                        "voq_capacity": capacity,
                        "packet_id": self.packet.packet_id,
                    },
                )
            if after is not None and after > capacity:
                raise ValidationError(
                    "queue_occupancy_after cannot exceed voq_capacity",
                    context={
                        "queue_occupancy_after": after,
                        "voq_capacity": capacity,
                        "packet_id": self.packet.packet_id,
                    },
                )

        object.__setattr__(self, "reason", reason)
        object.__setattr__(self, "queue_occupancy_before", before)
        object.__setattr__(self, "queue_occupancy_after", after)
        object.__setattr__(self, "voq_capacity", capacity)

    @classmethod
    def accept(
        cls,
        packet: Packet,
        *,
        slot: Slot,
        queue_occupancy_before: int | None = None,
        queue_occupancy_after: int | None = None,
        voq_capacity: int | None = None,
    ) -> AdmissionDecision:
        """Create an accepted admission decision, stamping ``enqueue_slot`` if needed."""

        stamped_slot = _validate_non_negative_int(slot, name="slot")
        packet_for_event = packet.mark_enqueued(stamped_slot)
        after = queue_occupancy_after
        if after is None and queue_occupancy_before is not None:
            after = int(queue_occupancy_before) + 1
        return cls(
            slot=stamped_slot,
            packet=packet_for_event,
            accepted=True,
            reason=ADMISSION_REASON_ENQUEUED,
            queue_occupancy_before=queue_occupancy_before,
            queue_occupancy_after=after,
            voq_capacity=voq_capacity,
        )

    @classmethod
    def drop(
        cls,
        packet: Packet,
        *,
        slot: Slot,
        queue_occupancy_before: int | None = None,
        queue_occupancy_after: int | None = None,
        voq_capacity: int | None = None,
        reason: str = ADMISSION_REASON_BUFFER_FULL,
    ) -> AdmissionDecision:
        """Create a rejected admission decision."""

        stamped_slot = _validate_non_negative_int(slot, name="slot")
        after = queue_occupancy_after
        if after is None and queue_occupancy_before is not None:
            after = int(queue_occupancy_before)
        return cls(
            slot=stamped_slot,
            packet=packet,
            accepted=False,
            reason=reason,
            queue_occupancy_before=queue_occupancy_before,
            queue_occupancy_after=after,
            voq_capacity=voq_capacity,
        )

    @classmethod
    def dropped_buffer_full(
        cls,
        packet: Packet,
        *,
        slot: Slot,
        queue_occupancy_before: int | None = None,
        queue_occupancy_after: int | None = None,
        voq_capacity: int | None = None,
    ) -> AdmissionDecision:
        """Backward-compatible named constructor for a finite-buffer overflow."""

        return cls.drop(
            packet,
            slot=slot,
            queue_occupancy_before=queue_occupancy_before,
            queue_occupancy_after=queue_occupancy_after,
            voq_capacity=voq_capacity,
            reason=ADMISSION_REASON_BUFFER_FULL,
        )

    @property
    def event_type(self) -> str:
        return ADMISSION_DECISION_EVENT_TYPE

    @property
    def outcome(self) -> str:
        return "accepted" if self.accepted else "dropped_buffer_full"

    @property
    def queue_length_before(self) -> int | None:
        return self.queue_occupancy_before

    @property
    def queue_length_after(self) -> int | None:
        return self.queue_occupancy_after

    @property
    def queue_capacity(self) -> int | None:
        """Topology-neutral alias for the legacy ``voq_capacity`` field."""

        return self.voq_capacity

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "event_type": self.event_type,
            "slot": self.slot,
            **self._packet_fields(),
            "accepted": self.accepted,
            "reason": self.reason,
            "outcome": self.outcome,
            "queue_occupancy_before": self.queue_occupancy_before,
            "queue_occupancy_after": self.queue_occupancy_after,
            "voq_capacity": self.voq_capacity,
            "queue_capacity": self.queue_capacity,
        }


@dataclass(slots=True, frozen=True)
class DepartureEvent(_PacketEventBase):
    """Service completion from a VOQ in one slot before sink completion."""

    queue_occupancy_before: int | None = None
    queue_occupancy_after: int | None = None

    def __post_init__(self) -> None:
        _PacketEventBase.__post_init__(self)
        before = _validate_optional_non_negative_int(self.queue_occupancy_before, name="queue_occupancy_before")
        after = _validate_optional_non_negative_int(self.queue_occupancy_after, name="queue_occupancy_after")

        if self.packet.enqueue_slot is None:
            raise ValidationError(
                "DepartureEvent packet must have enqueue_slot set",
                context={"packet_id": self.packet.packet_id},
            )
        if self.packet.completion_slot is not None:
            raise ValidationError(
                "DepartureEvent packet must not already be completed",
                context={"packet_id": self.packet.packet_id, "completion_slot": self.packet.completion_slot},
            )
        if self.slot <= self.packet.enqueue_slot:
            raise ValidationError(
                "DepartureEvent.slot must be strictly greater than packet.enqueue_slot",
                context={
                    "packet_id": self.packet.packet_id,
                    "slot": self.slot,
                    "enqueue_slot": self.packet.enqueue_slot,
                },
            )
        if before is not None and before < 1:
            raise ValidationError(
                "queue_occupancy_before must be at least one for a departure",
                context={"queue_occupancy_before": before, "packet_id": self.packet.packet_id},
            )
        if before is not None and after is not None and after != before - 1:
            raise ValidationError(
                "Departure must reduce queue occupancy by exactly one",
                context={
                    "queue_occupancy_before": before,
                    "queue_occupancy_after": after,
                    "packet_id": self.packet.packet_id,
                },
            )

        object.__setattr__(self, "queue_occupancy_before", before)
        object.__setattr__(self, "queue_occupancy_after", after)

    @classmethod
    def from_packet(
        cls,
        packet: Packet,
        *,
        slot: Slot,
        queue_occupancy_before: int | None = None,
        queue_occupancy_after: int | None = None,
    ) -> DepartureEvent:
        after = queue_occupancy_after
        if after is None and queue_occupancy_before is not None:
            after = int(queue_occupancy_before) - 1
        return cls(
            slot=slot,
            packet=packet,
            queue_occupancy_before=queue_occupancy_before,
            queue_occupancy_after=after,
        )

    @property
    def event_type(self) -> str:
        return DEPARTURE_EVENT_TYPE

    @property
    def queue_length_before(self) -> int | None:
        return self.queue_occupancy_before

    @property
    def queue_length_after(self) -> int | None:
        return self.queue_occupancy_after

    @property
    def queue_residency_slots(self) -> int:
        enqueue_slot = self.packet.enqueue_slot
        if enqueue_slot is None:
            raise ValidationError("queue_residency_slots requires an enqueued packet", context={"packet_id": self.packet.packet_id})
        return self.slot - enqueue_slot

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "event_type": self.event_type,
            "slot": self.slot,
            **self._packet_fields(),
            "queue_occupancy_before": self.queue_occupancy_before,
            "queue_occupancy_after": self.queue_occupancy_after,
            "queue_residency_slots": self.queue_residency_slots,
        }


@dataclass(slots=True, frozen=True)
class CompletionEvent(_PacketEventBase):
    """Packet completion in the slot of switch departure.

    ``sink_port`` is retained as optional legacy routing metadata.  Generalized
    queue completions use ``None`` and are accepted by the topology-neutral
    completion sink.
    """

    sink_port: PortId | None = None

    def __post_init__(self) -> None:
        _PacketEventBase.__post_init__(self)
        sink_port = _validate_optional_non_negative_int(self.sink_port, name="sink_port")
        if self.packet.enqueue_slot is None:
            raise ValidationError(
                "CompletionEvent packet must have enqueue_slot set",
                context={"packet_id": self.packet.packet_id},
            )
        if self.packet.completion_slot != self.slot:
            raise ValidationError(
                "CompletionEvent.slot must equal packet.completion_slot",
                context={
                    "packet_id": self.packet.packet_id,
                    "slot": self.slot,
                    "completion_slot": self.packet.completion_slot,
                },
            )
        if self.slot <= self.packet.enqueue_slot:
            raise ValidationError(
                "CompletionEvent.slot must be strictly greater than packet.enqueue_slot",
                context={
                    "packet_id": self.packet.packet_id,
                    "slot": self.slot,
                    "enqueue_slot": self.packet.enqueue_slot,
                },
            )
        if self.packet.dst_port is None and sink_port is not None:
            raise ValidationError(
                "CompletionEvent.sink_port must be null when packet has no legacy destination",
                context={"packet_id": self.packet.packet_id, "sink_port": sink_port},
            )
        if self.packet.dst_port is not None and sink_port != self.packet.dst_port:
            raise ValidationError(
                "CompletionEvent.sink_port must equal packet.dst_port",
                context={
                    "packet_id": self.packet.packet_id,
                    "sink_port": sink_port,
                    "dst_port": self.packet.dst_port,
                },
            )
        object.__setattr__(self, "sink_port", sink_port)

    @classmethod
    def from_packet(cls, packet: Packet, *, slot: Slot) -> CompletionEvent:
        completed_packet = packet.mark_completed(slot)
        return cls(slot=slot, packet=completed_packet, sink_port=completed_packet.dst_port)

    @classmethod
    def from_departure(cls, departure: DepartureEvent) -> CompletionEvent:
        if not isinstance(departure, DepartureEvent):
            raise ValidationError(
                "departure must be an instance of DepartureEvent",
                context={"value_type": type(departure).__name__},
            )
        return cls.from_packet(departure.packet, slot=departure.slot)

    @property
    def event_type(self) -> str:
        return COMPLETION_EVENT_TYPE

    @property
    def sojourn_slots(self) -> int:
        sojourn = self.packet.sojourn_slots
        if sojourn is None:
            raise ValidationError(
                "Completed packet must have a defined sojourn",
                context={"packet_id": self.packet.packet_id},
            )
        return sojourn

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "event_type": self.event_type,
            "slot": self.slot,
            **self._packet_fields(),
            "sink_port": self.sink_port,
            "sojourn_slots": self.sojourn_slots,
            "residence_slots": self.residence_slots,
            "waiting_slots": self.waiting_slots,
        }



def event_to_dict(event: SimEvent) -> dict[str, JSONValue]:
    """Serialize any supported runtime event into a stable mapping."""

    if isinstance(event, (ArrivalAttempt, AdmissionDecision, DepartureEvent, CompletionEvent)):
        return event.to_dict()
    raise ValidationError(
        "Unsupported event type",
        context={"value_type": type(event).__name__},
    )


@dataclass(slots=True, frozen=True)
class CommittedSlot:
    """One fully validated service-before-arrival queue transition.

    A commit is constructed only after service and admissions complete and the
    ordinary slot-record builder validates conservation.  Its queue vectors
    are borrowed read-only snapshots, not extra full-vector copies.  Sparse
    event-count mappings expose the actual transition to topology-neutral
    observation consumers.
    """

    slot: Slot
    catalog: Any = field(repr=False, compare=False)
    q_before: np.ndarray = field(repr=False, compare=False)
    q_after: np.ndarray = field(repr=False, compare=False)
    service_decision: Any = field(repr=False, compare=False)
    departures: tuple[DepartureEvent, ...] = ()
    offered: tuple[ArrivalAttempt, ...] = ()
    admissions: tuple[AdmissionDecision, ...] = ()
    record: Any = field(default=None, repr=False, compare=False)
    exact_gap_certificates: tuple["ExactGapCertificate", ...] = ()

    _served_by_queue: Mapping[QueueId, int] = field(init=False, repr=False, compare=False)
    _offered_by_queue: Mapping[QueueId, int] = field(init=False, repr=False, compare=False)
    _admitted_by_queue: Mapping[QueueId, int] = field(init=False, repr=False, compare=False)
    _dropped_by_queue: Mapping[QueueId, int] = field(init=False, repr=False, compare=False)
    _gap_by_queue: Mapping[QueueId, int] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        slot = _validate_non_negative_int(self.slot, name="slot")
        queue_ids = tuple(getattr(self.catalog, "queue_ids", ()))
        if not queue_ids:
            raise ValidationError("CommittedSlot.catalog must expose a nonempty queue_ids tuple")
        if not callable(getattr(self.catalog, "index_of", None)):
            raise ValidationError("CommittedSlot.catalog must implement index_of(queue_id)")

        q_before = self._validate_queue_vector(self.q_before, len(queue_ids), name="q_before")
        q_after = self._validate_queue_vector(self.q_after, len(queue_ids), name="q_after")
        departures = self._validate_events(self.departures, DepartureEvent, slot=slot, name="departures")
        offered = self._validate_events(self.offered, ArrivalAttempt, slot=slot, name="offered")
        admissions = self._validate_events(self.admissions, AdmissionDecision, slot=slot, name="admissions")

        served = self._count_by_queue(departures, self.catalog, name="departure")
        offered_counts = self._count_by_queue(offered, self.catalog, name="offered arrival")
        admitted = self._count_by_queue(
            (decision for decision in admissions if decision.accepted),
            self.catalog,
            name="admission",
        )
        dropped = self._count_by_queue(
            (decision for decision in admissions if not decision.accepted),
            self.catalog,
            name="drop",
        )

        if Counter(event.packet_id for event in offered) != Counter(event.packet_id for event in admissions):
            raise ValidationError(
                "CommittedSlot requires exactly one admission decision per offered packet",
                context={"slot": slot},
            )

        selected = tuple(getattr(self.service_decision, "selected_queue_ids", ()))
        if len(set(selected)) != len(selected):
            raise ValidationError(
                "CommittedSlot service decision contains duplicate queue IDs",
                context={"slot": slot},
            )
        unknown_selected: list[QueueId] = []
        for queue_id in selected:
            try:
                self.catalog.index_of(queue_id)
            except ValidationError:
                unknown_selected.append(queue_id)
        if unknown_selected:
            raise ValidationError(
                "CommittedSlot service decision contains an unknown queue ID",
                context={"slot": slot, "queue_ids": unknown_selected},
            )
        if set(served) != set(selected):
            raise ValidationError(
                "CommittedSlot actual departures do not match the validated service decision",
                context={
                    "slot": slot,
                    "selected_queue_ids": list(selected),
                    "departure_queue_ids": list(served),
                },
            )
        if any(count != 1 for count in served.values()):
            raise ValidationError(
                "CommittedSlot supports at most one actual departure per selected queue",
                context={"slot": slot},
            )

        certificates = tuple(self.exact_gap_certificates)
        gap_by_queue: dict[QueueId, int] = {}
        if certificates:
            # Import lazily: queues own the runtime events, while the exact-gap
            # scheduler contract depends on queue identities. Eagerly importing
            # the scheduler module here would create a queue/events import cycle.
            # Keeping all exact-only work inside this branch also leaves the
            # observation-disabled committed-slot path unchanged.
            from .schedulers.exact_gap import ExactGapCertificate

            production_value = sum(int(q_before[self.catalog.index_of(queue_id)]) for queue_id in selected)
            for index, certificate in enumerate(certificates):
                if not isinstance(certificate, ExactGapCertificate):
                    raise ValidationError(
                        "CommittedSlot exact-gap certificate has an invalid type",
                        context={"slot": slot, "index": index, "value_type": type(certificate).__name__},
                    )
                queue_id = certificate.queue_id
                try:
                    queue_index = int(self.catalog.index_of(queue_id))
                except ValidationError as exc:
                    raise ValidationError(
                        "CommittedSlot exact-gap certificate references an unknown queue ID",
                        context={"slot": slot, "index": index, "queue_id": queue_id},
                    ) from exc
                if queue_id in gap_by_queue:
                    raise ValidationError(
                        "CommittedSlot exact-gap certificates contain a duplicate target",
                        context={"slot": slot, "queue_id": queue_id},
                    )
                backlog = int(q_before[queue_index])
                selected_class = int(queue_id in selected)
                actual_departure = served.get(queue_id, 0)
                if certificate.backlog != backlog:
                    raise ValidationError(
                        "CommittedSlot exact-gap backlog disagrees with q_before",
                        context={
                            "slot": slot,
                            "queue_id": queue_id,
                            "certificate_backlog": certificate.backlog,
                            "q_before": backlog,
                        },
                    )
                if certificate.selected_class != selected_class or actual_departure != selected_class:
                    raise ValidationError(
                        "CommittedSlot exact-gap selected class disagrees with the actual departure",
                        context={
                            "slot": slot,
                            "queue_id": queue_id,
                            "certificate_selected_class": certificate.selected_class,
                            "actual_departure": actual_departure,
                        },
                    )
                if certificate.production_value != production_value:
                    raise ValidationError(
                        "CommittedSlot exact-gap production value disagrees with the committed decision",
                        context={
                            "slot": slot,
                            "queue_id": queue_id,
                            "certificate_production_value": certificate.production_value,
                            "committed_production_value": production_value,
                        },
                    )
                if backlog > 0 and certificate.gap > 0 and actual_departure != 1:
                    raise ValidationError(
                        "CommittedSlot positive exact gap requires an actual departure",
                        context={"slot": slot, "queue_id": queue_id, "gap": certificate.gap},
                    )
                if backlog > 0 and certificate.gap < 0 and actual_departure != 0:
                    raise ValidationError(
                        "CommittedSlot negative exact gap forbids an actual departure",
                        context={"slot": slot, "queue_id": queue_id, "gap": certificate.gap},
                    )
                gap_by_queue[queue_id] = certificate.gap

        # The finalized record has already checked every coordinate.  Recheck
        # only the sparse coordinates touched by this transition so the common
        # hook does not allocate or scan another full queue vector.
        for queue_id in set(served) | set(admitted):
            index = int(self.catalog.index_of(queue_id))
            expected = int(q_before[index]) - served.get(queue_id, 0) + admitted.get(queue_id, 0)
            if expected < 0 or expected != int(q_after[index]):
                raise ValidationError(
                    "CommittedSlot violates queue conservation",
                    context={"slot": slot, "queue_id": queue_id},
                )

        if self.record is None or getattr(self.record, "slot", None) != slot:
            raise ValidationError(
                "CommittedSlot.record must be the finalized record for the same slot",
                context={"slot": slot, "record_slot": getattr(self.record, "slot", None)},
            )

        object.__setattr__(self, "slot", slot)
        object.__setattr__(self, "q_before", q_before)
        object.__setattr__(self, "q_after", q_after)
        object.__setattr__(self, "departures", departures)
        object.__setattr__(self, "offered", offered)
        object.__setattr__(self, "admissions", admissions)
        object.__setattr__(self, "exact_gap_certificates", certificates)
        object.__setattr__(self, "_served_by_queue", MappingProxyType(served))
        object.__setattr__(self, "_offered_by_queue", MappingProxyType(offered_counts))
        object.__setattr__(self, "_admitted_by_queue", MappingProxyType(admitted))
        object.__setattr__(self, "_dropped_by_queue", MappingProxyType(dropped))
        object.__setattr__(self, "_gap_by_queue", MappingProxyType(gap_by_queue))

    @staticmethod
    def _validate_queue_vector(value: Any, size: int, *, name: str) -> np.ndarray:
        vector = np.asarray(value)
        if vector.ndim != 1 or vector.shape != (size,):
            raise ValidationError(
                f"CommittedSlot.{name} must align with queue_ids",
                context={"shape": vector.shape, "expected_shape": (size,)},
            )
        if vector.dtype.kind not in {"i", "u"}:
            raise ValidationError(f"CommittedSlot.{name} must contain integers")
        if vector.dtype.kind == "u" and vector.size and int(vector.max()) > np.iinfo(np.int64).max:
            raise ValidationError(f"CommittedSlot.{name} contains a value outside int64 range")
        if vector.size and int(vector.min()) < 0:
            raise ValidationError(f"CommittedSlot.{name} must be nonnegative")
        vector.flags.writeable = False
        readonly = vector.view()
        readonly.flags.writeable = False
        return readonly

    @staticmethod
    def _validate_events(events: Any, event_type: type, *, slot: int, name: str) -> tuple[Any, ...]:
        normalized = tuple(events)
        for index, event in enumerate(normalized):
            if not isinstance(event, event_type):
                raise ValidationError(
                    f"CommittedSlot.{name} contains an invalid event",
                    context={"index": index, "value_type": type(event).__name__},
                )
            if event.slot != slot:
                raise ValidationError(
                    f"CommittedSlot.{name} event belongs to a different slot",
                    context={"slot": slot, "event_slot": event.slot, "index": index},
                )
        return normalized

    @staticmethod
    def _count_by_queue(events: Any, catalog: Any, *, name: str) -> dict[QueueId, int]:
        counts: Counter[QueueId] = Counter()
        for event in events:
            queue_id = event.queue_id
            try:
                catalog.index_of(queue_id)
            except ValidationError as exc:
                raise ValidationError(
                    f"CommittedSlot {name} references an unknown queue ID",
                    context={"queue_id": queue_id},
                ) from exc
            counts[queue_id] += 1
        return dict(counts)

    @property
    def queue_ids(self) -> tuple[QueueId, ...]:
        return tuple(self.catalog.queue_ids)

    @property
    def selected_queue_ids(self) -> tuple[QueueId, ...]:
        return tuple(getattr(self.service_decision, "selected_queue_ids", ()))

    @property
    def served_by_queue(self) -> Mapping[QueueId, int]:
        return self._served_by_queue

    @property
    def offered_by_queue(self) -> Mapping[QueueId, int]:
        return self._offered_by_queue

    @property
    def admitted_by_queue(self) -> Mapping[QueueId, int]:
        return self._admitted_by_queue

    @property
    def dropped_by_queue(self) -> Mapping[QueueId, int]:
        return self._dropped_by_queue

    @property
    def gap_by_queue(self) -> Mapping[QueueId, int]:
        """Exact signed gaps for the selected diagnostic targets in this slot."""

        return self._gap_by_queue

    @property
    def served_count(self) -> int:
        return sum(self._served_by_queue.values())

    @property
    def offered_count(self) -> int:
        return sum(self._offered_by_queue.values())

    @property
    def admitted_count(self) -> int:
        return sum(self._admitted_by_queue.values())

    @property
    def dropped_count(self) -> int:
        return sum(self._dropped_by_queue.values())

    def queue_index(self, queue_id: QueueId) -> int:
        try:
            return int(self.catalog.index_of(queue_id))
        except (KeyError, TypeError, ValidationError) as exc:
            raise ValidationError(
                "queue_id is not present in this CommittedSlot",
                context={"queue_id": queue_id},
            ) from exc

    def q_before_for(self, queue_id: QueueId) -> int:
        return int(self.q_before[self.queue_index(queue_id)])

    def q_after_for(self, queue_id: QueueId) -> int:
        return int(self.q_after[self.queue_index(queue_id)])

    def gap_for(self, queue_id: QueueId) -> int | None:
        """Return the exact signed gap, or ``None`` when it was not requested."""

        self.queue_index(queue_id)
        return self._gap_by_queue.get(queue_id)


__all__ = [
    "ARRIVAL_ATTEMPT_EVENT_TYPE",
    "ADMISSION_DECISION_EVENT_TYPE",
    "DEPARTURE_EVENT_TYPE",
    "COMPLETION_EVENT_TYPE",
    "ADMISSION_REASON_ENQUEUED",
    "ADMISSION_REASON_BUFFER_FULL",
    "SUPPORTED_ADMISSION_REASONS",
    "AdmissionReason",
    "SimEvent",
    "ArrivalAttempt",
    "AdmissionDecision",
    "DepartureEvent",
    "CompletionEvent",
    "CommittedSlot",
    "event_to_dict",
]
