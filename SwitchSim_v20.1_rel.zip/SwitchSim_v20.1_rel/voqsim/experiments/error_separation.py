"""Decoder-agnostic four-target error-separation accounting.

This module never constructs or decodes a response profile.  It accepts the
four authoritative scalar outputs needed by the scientific identity for each
complete independent replication unit and performs only the stated additive
decomposition and across-replicate uncertainty calculation.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
import math
from numbers import Integral, Real
import statistics
from typing import Any

from ..errors import ValidationError
from ..types import JSONValue, QueueId
from ..utils import canonical_json_dumps, normalize_for_json


STATUS_OK = "ok"
AUTHORITATIVE_FAILURE_STATUSES = (
    "no_exposure",
    "no_observed_service",
    "no_tail_exposure",
    "nonpositive_tail_slack",
    "unsupported_profile",
)
AUTHORITATIVE_STATUSES = frozenset({STATUS_OK, *AUTHORITATIVE_FAILURE_STATUSES})
TARGET_ROLES = (
    "benign_crossbar",
    "wireless_strip_compensation",
    "long_interval_compression",
    "large_hub_tail_stabilization",
)
_COMPONENTS = (
    "sampled_fit_mean",
    "finite_window_fit_mean",
    "stationary_fit_mean",
    "stationary_mean",
)
_TERM_COMPONENTS = {
    "compression": ("stationary_fit_mean", "stationary_mean"),
    "finite_window_construction": ("finite_window_fit_mean", "stationary_fit_mean"),
    "sampling": ("sampled_fit_mean", "finite_window_fit_mean"),
    "total": ("sampled_fit_mean", "stationary_mean"),
}
_DATASET_KEYS = ("sampler", "finite_window", "stationary_reference")
_REQUIRED_SCIENTIFIC_CONDITIONS = frozenset(
    {
        "arrival_law",
        "slot_convention",
        "initial_conditions",
        "scheduler_tie_policy",
        "target_definition",
        "independent_run_seeds",
        "sampler_ensemble_ids",
        "random_streams",
        "measurement_windows",
        "reporting_blocks",
        "buffer_policy",
        "sampler_weighting",
        "sampler_resampling",
    }
)


def _identifier(value: Any, *, name: str) -> str | int:
    if isinstance(value, bool) or not isinstance(value, (str, Integral)):
        raise ValidationError(f"{name} must be a string or integer", context={"value": value})
    if isinstance(value, str):
        if not value or value.strip() != value:
            raise ValidationError(f"{name} must be nonempty without surrounding whitespace")
        return value
    return int(value)


def _status(value: Any) -> str:
    if not isinstance(value, str) or not value or value.strip() != value:
        raise ValidationError("decoded output status must be a nonempty canonical string")
    if value not in AUTHORITATIVE_STATUSES:
        raise ValidationError(
            "decoded output status is not in the authoritative status vocabulary",
            context={"status": value, "allowed": sorted(AUTHORITATIVE_STATUSES)},
        )
    return value


def _mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationError(f"{name} must be a mapping")
    return value


def _sequence(value: Any, *, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValidationError(f"{name} must be a sequence")
    return value


def _dataset_mapping(value: Any, *, name: str) -> Mapping[str, Any]:
    mapping = _mapping(value, name=name)
    if set(mapping) != set(_DATASET_KEYS):
        raise ValidationError(
            f"{name} must define sampler, finite_window, and stationary_reference",
            context={"keys": sorted(str(key) for key in mapping)},
        )
    return mapping


def _measurement_window(value: Any, *, name: str) -> tuple[int, int]:
    raw = _sequence(value, name=name)
    if len(raw) != 2:
        raise ValidationError(f"{name} must be [W, T)")
    start, stop = raw
    if (
        isinstance(start, bool)
        or not isinstance(start, Integral)
        or isinstance(stop, bool)
        or not isinstance(stop, Integral)
    ):
        raise ValidationError(f"{name} endpoints must be integers")
    normalized = (int(start), int(stop))
    if normalized[0] < 0 or normalized[0] >= normalized[1]:
        raise ValidationError(f"{name} must satisfy 0 <= W < T")
    return normalized


def _reporting_blocks(
    value: Any,
    *,
    name: str,
    window: tuple[int, int],
) -> tuple[tuple[int, int], ...]:
    raw_blocks = _sequence(value, name=name)
    if not raw_blocks:
        raise ValidationError(f"{name} must contain at least one block")
    blocks = tuple(
        _measurement_window(raw_block, name=f"{name}[{index}]")
        for index, raw_block in enumerate(raw_blocks)
    )
    if blocks[0][0] != window[0] or blocks[-1][1] != window[1]:
        raise ValidationError(f"{name} must cover its exact measurement window")
    for left, right in zip(blocks, blocks[1:]):
        if left[1] != right[0]:
            raise ValidationError(f"{name} must be consecutive and nonoverlapping")
    return blocks


def _validate_scientific_conditions(
    value: Any,
    *,
    role: str,
    target_id: str | int,
) -> tuple[
    dict[str, JSONValue],
    dict[str, tuple[int, ...]],
    tuple[str | int, ...],
]:
    raw = _mapping(value, name="scientific_conditions")
    missing = sorted(_REQUIRED_SCIENTIFIC_CONDITIONS - set(raw))
    if missing:
        raise ValidationError(
            "scientific_conditions is missing required scientific identity",
            context={"missing": missing},
        )
    normalized = normalize_for_json(dict(raw))
    if not isinstance(normalized, dict):  # pragma: no cover - mapping normalizes to dict
        raise ValidationError("scientific_conditions could not be normalized")

    if normalized["slot_convention"] != "service_before_arrival":
        raise ValidationError("slot_convention must be 'service_before_arrival'")
    if normalized["buffer_policy"] != "NoDrop":
        raise ValidationError("four-target reference campaigns require buffer_policy='NoDrop'")
    for key in (
        "arrival_law",
        "scheduler_tie_policy",
        "sampler_weighting",
        "sampler_resampling",
    ):
        if not _mapping(normalized[key], name=f"scientific_conditions.{key}"):
            raise ValidationError(f"scientific_conditions.{key} must be nonempty")

    target = _mapping(
        normalized["target_definition"],
        name="scientific_conditions.target_definition",
    )
    for key in ("system_id", "system_kind", "queue_id"):
        if key not in target:
            raise ValidationError(f"target_definition requires {key}")
    if target["system_kind"] != role:
        raise ValidationError(
            "target_definition.system_kind must match the four-target role",
            context={"role": role, "system_kind": target["system_kind"]},
        )
    if target["queue_id"] != target_id:
        raise ValidationError("target_definition.queue_id must equal target_id")
    _identifier(target["system_id"], name="target_definition.system_id")

    initial = _dataset_mapping(
        normalized["initial_conditions"],
        name="scientific_conditions.initial_conditions",
    )
    if initial["sampler"] != initial["finite_window"]:
        raise ValidationError(
            "sampler and finite_window must use the exact same initial condition"
        )

    raw_windows = _dataset_mapping(
        normalized["measurement_windows"],
        name="scientific_conditions.measurement_windows",
    )
    windows = {
        key: _measurement_window(
            raw_windows[key],
            name=f"scientific_conditions.measurement_windows.{key}",
        )
        for key in _DATASET_KEYS
    }
    if windows["sampler"] != windows["finite_window"]:
        raise ValidationError(
            "sampler and finite_window must use the exact same [W,T) window"
        )

    raw_blocks = _dataset_mapping(
        normalized["reporting_blocks"],
        name="scientific_conditions.reporting_blocks",
    )
    for key in _DATASET_KEYS:
        _reporting_blocks(
            raw_blocks[key],
            name=f"scientific_conditions.reporting_blocks.{key}",
            window=windows[key],
        )

    raw_seeds = _dataset_mapping(
        normalized["independent_run_seeds"],
        name="scientific_conditions.independent_run_seeds",
    )
    seed_groups: dict[str, tuple[int, ...]] = {}
    all_seeds: list[int] = []
    for key in _DATASET_KEYS:
        values = _sequence(
            raw_seeds[key],
            name=f"scientific_conditions.independent_run_seeds.{key}",
        )
        if not values:
            raise ValidationError("every dataset requires at least one independent seed")
        seeds: list[int] = []
        for index, raw_seed in enumerate(values):
            if isinstance(raw_seed, bool) or not isinstance(raw_seed, Integral) or int(raw_seed) < 0:
                raise ValidationError(
                    "independent run seeds must be nonnegative integers",
                    context={"dataset": key, "index": index, "seed": raw_seed},
                )
            seeds.append(int(raw_seed))
        if len(seeds) != len(set(seeds)):
            raise ValidationError(f"{key} independent run seeds must be unique")
        seed_groups[key] = tuple(seeds)
        all_seeds.extend(seeds)
    if len(all_seeds) != len(set(all_seeds)):
        raise ValidationError("independent run seeds must be distinct across datasets")
    counts = {len(values) for values in seed_groups.values()}
    if len(counts) != 1:
        raise ValidationError("all datasets must declare the same replication count")

    raw_ensemble_ids = _sequence(
        normalized["sampler_ensemble_ids"],
        name="scientific_conditions.sampler_ensemble_ids",
    )
    ensemble_ids = tuple(
        _identifier(value, name=f"sampler_ensemble_ids[{index}]")
        for index, value in enumerate(raw_ensemble_ids)
    )
    if len(ensemble_ids) != len(seed_groups["sampler"]):
        raise ValidationError(
            "sampler ensemble IDs must match the declared sampler replication count"
        )
    if len(ensemble_ids) != len(set(ensemble_ids)):
        raise ValidationError("sampler ensemble IDs must be unique")

    random_streams = _dataset_mapping(
        normalized["random_streams"],
        name="scientific_conditions.random_streams",
    )
    for key in _DATASET_KEYS:
        if not _mapping(
            random_streams[key],
            name=f"scientific_conditions.random_streams.{key}",
        ):
            raise ValidationError(f"random_streams.{key} must be nonempty")

    return normalized, seed_groups, ensemble_ids


@dataclass(slots=True, frozen=True)
class ScientificUnitIdentity:
    """Scientific identity of one independent simulator or ensemble unit."""

    actual_seed: int
    ensemble_id: str | int | None = None

    def __post_init__(self) -> None:
        seed = self.actual_seed
        if isinstance(seed, bool) or not isinstance(seed, Integral) or int(seed) < 0:
            raise ValidationError("scientific-unit actual_seed must be a nonnegative integer")
        ensemble_id = self.ensemble_id
        if ensemble_id is not None:
            ensemble_id = _identifier(ensemble_id, name="scientific-unit ensemble_id")
        object.__setattr__(self, "actual_seed", int(seed))
        object.__setattr__(self, "ensemble_id", ensemble_id)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "ScientificUnitIdentity":
        if not isinstance(payload, Mapping):
            raise ValidationError("scientific-unit identity must be a mapping")
        if "actual_seed" not in payload or set(payload) - {"actual_seed", "ensemble_id"}:
            raise ValidationError(
                "scientific-unit identity requires actual_seed and optional ensemble_id"
            )
        return cls(
            actual_seed=payload["actual_seed"],
            ensemble_id=payload.get("ensemble_id"),
        )

    def to_dict(self) -> dict[str, JSONValue]:
        result: dict[str, JSONValue] = {"actual_seed": self.actual_seed}
        if self.ensemble_id is not None:
            result["ensemble_id"] = self.ensemble_id
        return result


@dataclass(slots=True, frozen=True)
class AuthoritativeDecodedValue:
    """One scalar emitted by an external authoritative decoder or estimator."""

    status: str
    value: float | None = None

    def __post_init__(self) -> None:
        status = _status(self.status)
        value = self.value
        if status == STATUS_OK:
            if isinstance(value, bool) or not isinstance(value, Real):
                raise ValidationError("status 'ok' requires a finite numeric value")
            value = float(value)
            if not math.isfinite(value):
                raise ValidationError("decoded output value must be finite")
            if value < 0:
                raise ValidationError("decoded queue mean must be nonnegative")
        elif value is not None:
            raise ValidationError("a non-ok decoded output must not carry a numeric value")
        object.__setattr__(self, "status", status)
        object.__setattr__(self, "value", value)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "AuthoritativeDecodedValue":
        if not isinstance(payload, Mapping):
            raise ValidationError("decoded output must be a mapping")
        extras = set(payload) - {"status", "value"}
        if extras or "status" not in payload:
            raise ValidationError(
                "decoded output requires status and optional value only",
                context={"unknown_keys": sorted(str(key) for key in extras)},
            )
        return cls(status=payload["status"], value=payload.get("value"))


@dataclass(slots=True, frozen=True)
class SeparationReplicate:
    """One complete independent replication unit for all four quantities."""

    replicate_id: str | int
    sampler_unit: ScientificUnitIdentity
    finite_window_unit: ScientificUnitIdentity
    stationary_reference_unit: ScientificUnitIdentity
    sampled_fit_mean: AuthoritativeDecodedValue
    finite_window_fit_mean: AuthoritativeDecodedValue
    stationary_fit_mean: AuthoritativeDecodedValue
    stationary_mean: AuthoritativeDecodedValue

    def __post_init__(self) -> None:
        object.__setattr__(self, "replicate_id", _identifier(self.replicate_id, name="replicate_id"))
        for unit_name in (
            "sampler_unit",
            "finite_window_unit",
            "stationary_reference_unit",
        ):
            if not isinstance(getattr(self, unit_name), ScientificUnitIdentity):
                raise ValidationError(f"{unit_name} must be a ScientificUnitIdentity")
        if self.sampler_unit.ensemble_id is None:
            raise ValidationError("sampler_unit requires an ensemble_id")
        if self.finite_window_unit.ensemble_id is not None:
            raise ValidationError("finite_window_unit must not carry an ensemble_id")
        if self.stationary_reference_unit.ensemble_id is not None:
            raise ValidationError("stationary_reference_unit must not carry an ensemble_id")
        for component in _COMPONENTS:
            if not isinstance(getattr(self, component), AuthoritativeDecodedValue):
                raise ValidationError(f"{component} must be an AuthoritativeDecodedValue")

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "SeparationReplicate":
        if not isinstance(payload, Mapping):
            raise ValidationError("replicate must be a mapping")
        expected = {"replicate_id", "scientific_units", *_COMPONENTS}
        if set(payload) != expected:
            raise ValidationError(
                "replicate must contain its ID, scientific units, and all four authoritative outputs",
                context={"keys": sorted(str(key) for key in payload)},
            )
        units = _dataset_mapping(
            payload["scientific_units"],
            name="replicate.scientific_units",
        )
        return cls(
            replicate_id=payload["replicate_id"],
            sampler_unit=ScientificUnitIdentity.from_mapping(units["sampler"]),
            finite_window_unit=ScientificUnitIdentity.from_mapping(units["finite_window"]),
            stationary_reference_unit=ScientificUnitIdentity.from_mapping(
                units["stationary_reference"]
            ),
            sampled_fit_mean=AuthoritativeDecodedValue.from_mapping(payload["sampled_fit_mean"]),
            finite_window_fit_mean=AuthoritativeDecodedValue.from_mapping(payload["finite_window_fit_mean"]),
            stationary_fit_mean=AuthoritativeDecodedValue.from_mapping(payload["stationary_fit_mean"]),
            stationary_mean=AuthoritativeDecodedValue.from_mapping(payload["stationary_mean"]),
        )

    def scientific_units_dict(self) -> dict[str, JSONValue]:
        return {
            "replicate_id": self.replicate_id,
            "sampler": self.sampler_unit.to_dict(),
            "finite_window": self.finite_window_unit.to_dict(),
            "stationary_reference": self.stationary_reference_unit.to_dict(),
        }

    @property
    def failure_statuses(self) -> tuple[tuple[str, str], ...]:
        return tuple(
            (component, getattr(self, component).status)
            for component in _COMPONENTS
            if getattr(self, component).status != STATUS_OK
        )

    def terms(self) -> tuple[float, float, float, float]:
        if self.failure_statuses:
            raise ValidationError("cannot compute terms for an incomplete replicate")
        sampled = float(self.sampled_fit_mean.value)  # type: ignore[arg-type]
        finite = float(self.finite_window_fit_mean.value)  # type: ignore[arg-type]
        stationary = float(self.stationary_fit_mean.value)  # type: ignore[arg-type]
        stationary_mean = float(self.stationary_mean.value)  # type: ignore[arg-type]
        compression = stationary - stationary_mean
        construction = finite - stationary
        sampling = sampled - finite
        total = sampled - stationary_mean
        return compression, construction, sampling, total

    def term_outcomes(self) -> dict[str, tuple[float | None, str]]:
        """Return every independently defined term and its own status."""

        outcomes: dict[str, tuple[float | None, str]] = {}
        for term, (left_name, right_name) in _TERM_COMPONENTS.items():
            left = getattr(self, left_name)
            right = getattr(self, right_name)
            if left.status != STATUS_OK:
                outcomes[term] = (None, f"{left_name}:{left.status}")
            elif right.status != STATUS_OK:
                outcomes[term] = (None, f"{right_name}:{right.status}")
            else:
                assert left.value is not None
                assert right.value is not None
                outcomes[term] = (float(left.value) - float(right.value), STATUS_OK)
        return outcomes


@dataclass(slots=True, frozen=True)
class CutoffCampaign:
    cutoff: int
    replicates: tuple[SeparationReplicate, ...]

    def __post_init__(self) -> None:
        if isinstance(self.cutoff, bool) or not isinstance(self.cutoff, Integral) or int(self.cutoff) <= 0:
            raise ValidationError("cutoff must be a positive integer")
        replicates = tuple(self.replicates)
        if len(replicates) < 2:
            raise ValidationError("each cutoff requires at least two independent replicates")
        ids = [replicate.replicate_id for replicate in replicates]
        if len(ids) != len(set(ids)):
            raise ValidationError("replicate IDs must be unique within a target and cutoff")
        object.__setattr__(self, "cutoff", int(self.cutoff))
        object.__setattr__(self, "replicates", replicates)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "CutoffCampaign":
        if not isinstance(payload, Mapping) or set(payload) != {"cutoff", "replicates"}:
            raise ValidationError("cutoff campaign requires exactly cutoff and replicates")
        raw_replicates = payload["replicates"]
        if isinstance(raw_replicates, (str, bytes)) or not isinstance(raw_replicates, Sequence):
            raise ValidationError("replicates must be a sequence")
        return cls(
            cutoff=payload["cutoff"],
            replicates=tuple(SeparationReplicate.from_mapping(item) for item in raw_replicates),
        )


@dataclass(slots=True, frozen=True)
class TargetCampaign:
    role: str
    target_id: QueueId
    scientific_conditions: Mapping[str, JSONValue]
    cutoffs: tuple[CutoffCampaign, ...]

    def __post_init__(self) -> None:
        if self.role not in TARGET_ROLES:
            raise ValidationError(
                "unknown four-target campaign role",
                context={"role": self.role, "allowed": list(TARGET_ROLES)},
            )
        target_id = _identifier(self.target_id, name="target_id")
        cutoffs = tuple(self.cutoffs)
        if not cutoffs:
            raise ValidationError("each target campaign requires at least one cutoff")
        values = [item.cutoff for item in cutoffs]
        if len(values) != len(set(values)):
            raise ValidationError("cutoffs must be unique within each target campaign")
        baseline_replicates = cutoffs[0].replicates
        replicate_ids = tuple(item.replicate_id for item in baseline_replicates)
        baseline_units = tuple(
            (
                item.sampler_unit,
                item.finite_window_unit,
                item.stationary_reference_unit,
            )
            for item in baseline_replicates
        )
        for cutoff in cutoffs[1:]:
            if tuple(item.replicate_id for item in cutoff.replicates) != replicate_ids:
                raise ValidationError(
                    "every cutoff must retain the same ordered independent replication units"
                )
            cutoff_units = tuple(
                (
                    item.sampler_unit,
                    item.finite_window_unit,
                    item.stationary_reference_unit,
                )
                for item in cutoff.replicates
            )
            if cutoff_units != baseline_units:
                raise ValidationError(
                    "scientific-unit identities must remain fixed across cutoffs"
                )
        conditions, seed_groups, ensemble_ids = _validate_scientific_conditions(
            self.scientific_conditions,
            role=self.role,
            target_id=target_id,
        )
        declared_replicates = len(seed_groups["sampler"])
        if declared_replicates != len(replicate_ids):
            raise ValidationError(
                "independent seed counts must equal the cutoff replication count",
                context={
                    "declared_replicates": declared_replicates,
                    "cutoff_replicates": len(replicate_ids),
                },
            )

        sampler_units = tuple(item.sampler_unit for item in baseline_replicates)
        finite_units = tuple(item.finite_window_unit for item in baseline_replicates)
        stationary_units = tuple(
            item.stationary_reference_unit for item in baseline_replicates
        )
        for name, units in (
            ("sampler", sampler_units),
            ("finite_window", finite_units),
            ("stationary_reference", stationary_units),
        ):
            if len(units) != len(set(units)):
                raise ValidationError(
                    f"{name} scientific units must be unique across replicates"
                )
        expected_sampler = {
            ScientificUnitIdentity(seed, ensemble_id)
            for seed, ensemble_id in zip(
                seed_groups["sampler"], ensemble_ids, strict=True
            )
        }
        if set(sampler_units) != expected_sampler:
            raise ValidationError(
                "sampler scientific units do not match declared seeds and ensemble IDs"
            )
        expected_finite = {
            ScientificUnitIdentity(seed) for seed in seed_groups["finite_window"]
        }
        if set(finite_units) != expected_finite:
            raise ValidationError(
                "finite-window scientific units do not match declared seeds"
            )
        expected_stationary = {
            ScientificUnitIdentity(seed)
            for seed in seed_groups["stationary_reference"]
        }
        if set(stationary_units) != expected_stationary:
            raise ValidationError(
                "stationary-reference scientific units do not match declared seeds"
            )
        object.__setattr__(self, "target_id", target_id)
        object.__setattr__(self, "scientific_conditions", conditions)
        object.__setattr__(self, "cutoffs", cutoffs)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "TargetCampaign":
        required = {"role", "target_id", "scientific_conditions", "cutoffs"}
        if not isinstance(payload, Mapping) or set(payload) != required:
            raise ValidationError("target campaign requires role, target_id, scientific_conditions, and cutoffs")
        raw_cutoffs = payload["cutoffs"]
        if isinstance(raw_cutoffs, (str, bytes)) or not isinstance(raw_cutoffs, Sequence):
            raise ValidationError("cutoffs must be a sequence")
        return cls(
            role=payload["role"],
            target_id=payload["target_id"],
            scientific_conditions=payload["scientific_conditions"],
            cutoffs=tuple(CutoffCampaign.from_mapping(item) for item in raw_cutoffs),
        )


@dataclass(slots=True, frozen=True)
class EstimateWithUncertainty:
    value: float | None
    standard_error: float | None
    independent_replicates: int
    status: str

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "value": self.value,
            "standard_error": self.standard_error,
            "independent_replicates": self.independent_replicates,
            "status": self.status,
        }


@dataclass(slots=True, frozen=True)
class ReplicateWithFailedInputs:
    replicate_id: str | int
    component_statuses: tuple[tuple[str, str], ...]
    term_statuses: tuple[tuple[str, str], ...]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "replicate_id": self.replicate_id,
            "component_statuses": {
                component: status for component, status in self.component_statuses
            },
            "term_statuses": {term: status for term, status in self.term_statuses},
        }


@dataclass(slots=True, frozen=True)
class CutoffSeparationReport:
    cutoff: int
    status: str
    compression: EstimateWithUncertainty
    finite_window_construction: EstimateWithUncertainty
    sampling: EstimateWithUncertainty
    total: EstimateWithUncertainty
    accounting_residual: float | None
    accounting_replicates: int
    replication_units: tuple[Mapping[str, JSONValue], ...]
    replicates_with_failed_inputs: tuple[ReplicateWithFailedInputs, ...]
    failed_input_status_counts: Mapping[str, int]
    term_failure_status_counts: Mapping[str, Mapping[str, int]]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "cutoff": self.cutoff,
            "status": self.status,
            "compression": self.compression.to_dict(),
            "finite_window_construction": self.finite_window_construction.to_dict(),
            "sampling": self.sampling.to_dict(),
            "total": self.total.to_dict(),
            "accounting_residual": self.accounting_residual,
            "accounting_replicates": self.accounting_replicates,
            "replication_units": [dict(item) for item in self.replication_units],
            "replicates_with_failed_inputs": [
                item.to_dict() for item in self.replicates_with_failed_inputs
            ],
            "failed_input_status_counts": dict(
                sorted(self.failed_input_status_counts.items())
            ),
            "term_failure_status_counts": {
                term: dict(sorted(counts.items()))
                for term, counts in sorted(self.term_failure_status_counts.items())
            },
        }


@dataclass(slots=True, frozen=True)
class TargetSeparationReport:
    role: str
    target_id: QueueId
    scientific_conditions: Mapping[str, JSONValue]
    cutoffs: tuple[CutoffSeparationReport, ...]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "role": self.role,
            "target_id": self.target_id,
            "scientific_conditions": dict(self.scientific_conditions),
            "cutoffs": [item.to_dict() for item in self.cutoffs],
        }


@dataclass(slots=True, frozen=True)
class FourTargetSeparationReport:
    targets: tuple[TargetSeparationReport, ...]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "analysis": "compression_construction_sampling_separation",
            "decoder_policy": "authoritative_outputs_only",
            "uncertainty_unit": "explicit_seeded_scientific_unit_per_term",
            "uncertainty_method": "sample_standard_error",
            "targets": [target.to_dict() for target in self.targets],
        }


def _summarize(values: Sequence[float]) -> EstimateWithUncertainty:
    count = len(values)
    if count == 0:
        return EstimateWithUncertainty(None, None, 0, "no_complete_replicates")
    mean = statistics.fmean(values)
    if count == 1:
        return EstimateWithUncertainty(mean, None, 1, "insufficient_independent_replicates")
    standard_error = statistics.stdev(values) / math.sqrt(count)
    return EstimateWithUncertainty(mean, standard_error, count, STATUS_OK)


def _separate_cutoff(campaign: CutoffCampaign) -> CutoffSeparationReport:
    term_names = tuple(_TERM_COMPONENTS)
    columns: dict[str, list[float]] = {term: [] for term in term_names}
    failed_inputs: list[ReplicateWithFailedInputs] = []
    status_counts: Counter[str] = Counter()
    term_status_counts: dict[str, Counter[str]] = {
        term: Counter() for term in term_names
    }
    complete_residuals: list[float] = []
    for replicate in campaign.replicates:
        failures = replicate.failure_statuses
        outcomes = replicate.term_outcomes()
        if failures:
            term_failures = tuple(
                (term, status)
                for term, (_value, status) in outcomes.items()
                if status != STATUS_OK
            )
            failed_inputs.append(
                ReplicateWithFailedInputs(replicate.replicate_id, failures, term_failures)
            )
            status_counts.update(status for _component, status in failures)
        for term, (value, status) in outcomes.items():
            if status == STATUS_OK:
                assert value is not None
                columns[term].append(value)
            else:
                term_status_counts[term][status] += 1
        if not failures:
            compression, construction, sampling, total = replicate.terms()
            complete_residuals.append(
                total - math.fsum((compression, construction, sampling))
            )

    summaries = {term: _summarize(columns[term]) for term in term_names}
    any_values = any(summary.independent_replicates for summary in summaries.values())
    if failed_inputs and any_values:
        overall_status = "partial_with_failed_replicates"
    elif failed_inputs:
        overall_status = "no_computable_terms"
    elif any(summary.status != STATUS_OK for summary in summaries.values()):
        overall_status = "insufficient_independent_replicates"
    else:
        overall_status = STATUS_OK
    residual = statistics.fmean(complete_residuals) if complete_residuals else None
    return CutoffSeparationReport(
        cutoff=campaign.cutoff,
        status=overall_status,
        compression=summaries["compression"],
        finite_window_construction=summaries["finite_window_construction"],
        sampling=summaries["sampling"],
        total=summaries["total"],
        accounting_residual=residual,
        accounting_replicates=len(complete_residuals),
        replication_units=tuple(
            replicate.scientific_units_dict() for replicate in campaign.replicates
        ),
        replicates_with_failed_inputs=tuple(failed_inputs),
        failed_input_status_counts=dict(status_counts),
        term_failure_status_counts={
            term: dict(counts) for term, counts in term_status_counts.items() if counts
        },
    )


def separate_four_target_campaign(
    campaigns: Iterable[TargetCampaign],
) -> FourTargetSeparationReport:
    """Apply the exact additive identity to four caller-defined target campaigns."""

    supplied = tuple(campaigns)
    for item in supplied:
        if not isinstance(item, TargetCampaign):
            raise ValidationError("campaigns must contain TargetCampaign values")
    by_role = {item.role: item for item in supplied}
    if len(by_role) != len(supplied):
        raise ValidationError("the four-target campaign contains a duplicate role")
    if set(by_role) != set(TARGET_ROLES):
        raise ValidationError(
            "the campaign must supply each required scientific target role exactly once",
            context={"required_roles": list(TARGET_ROLES), "supplied_roles": sorted(by_role)},
        )

    system_ids: dict[str | int, str] = {}
    target_definitions: dict[str, str] = {}
    for item in supplied:
        target = item.scientific_conditions["target_definition"]
        if not isinstance(target, Mapping):  # pragma: no cover - constructor validates
            raise ValidationError("target_definition must be a mapping")
        system_id = _identifier(target["system_id"], name="target_definition.system_id")
        if system_id in system_ids:
            raise ValidationError(
                "four-target roles must identify distinct scientific systems",
                context={
                    "system_id": system_id,
                    "first_role": system_ids[system_id],
                    "duplicate_role": item.role,
                },
            )
        system_ids[system_id] = item.role
        definition_key = canonical_json_dumps(dict(target))
        if definition_key in target_definitions:
            raise ValidationError(
                "four-target roles must use distinct target definitions",
                context={
                    "first_role": target_definitions[definition_key],
                    "duplicate_role": item.role,
                },
            )
        target_definitions[definition_key] = item.role

    reports = tuple(
        TargetSeparationReport(
            role=role,
            target_id=by_role[role].target_id,
            scientific_conditions=by_role[role].scientific_conditions,
            cutoffs=tuple(_separate_cutoff(cutoff) for cutoff in by_role[role].cutoffs),
        )
        for role in TARGET_ROLES
    )
    return FourTargetSeparationReport(reports)


def four_target_campaign_from_mapping(payload: Mapping[str, Any]) -> tuple[TargetCampaign, ...]:
    if not isinstance(payload, Mapping) or set(payload) != {"targets"}:
        raise ValidationError("campaign input requires exactly a targets sequence")
    raw_targets = payload["targets"]
    if isinstance(raw_targets, (str, bytes)) or not isinstance(raw_targets, Sequence):
        raise ValidationError("campaign targets must be a sequence")
    return tuple(TargetCampaign.from_mapping(item) for item in raw_targets)


__all__ = [
    "AUTHORITATIVE_FAILURE_STATUSES",
    "AUTHORITATIVE_STATUSES",
    "AuthoritativeDecodedValue",
    "CutoffCampaign",
    "CutoffSeparationReport",
    "EstimateWithUncertainty",
    "FourTargetSeparationReport",
    "ReplicateWithFailedInputs",
    "ScientificUnitIdentity",
    "STATUS_OK",
    "SeparationReplicate",
    "TARGET_ROLES",
    "TargetCampaign",
    "TargetSeparationReport",
    "four_target_campaign_from_mapping",
    "separate_four_target_campaign",
]
