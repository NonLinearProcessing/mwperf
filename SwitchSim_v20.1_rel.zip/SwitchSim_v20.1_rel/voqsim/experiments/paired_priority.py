"""Trace-verified paired-priority experiment for a lossless fan-in switch.

The experiment deliberately receives the realized vector-arrival trace as
data.  Each arm replays the declared source through the simulator's isolated
per-slot arrival RNG and is checked against that trace.  Thus equality is not
inferred from equal seeds or scheduler RNG consumption, and the full trace is
not copied into either run configuration or scientific report.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from numbers import Integral
from pathlib import Path
from typing import Any

import numpy as np

from ..config import (
    NO_DROP_CAPACITY,
    SimConfig,
    resolve_config,
    resolved_config_to_dict,
)
from ..errors import ScheduleError, ValidationError
from ..events import CommittedSlot
from ..kernel import build_simulation
from ..queues import ServiceDecision
from ..rng import (
    ARRIVAL_CATEGORICAL_SAMPLER,
    RNG_ENGINE_NAME,
    RNGDomain,
    SEED_SCHEME_VERSION,
    build_arrival_rng_for_slot,
)
from ..schedulers.domain import QueueSchedulerDomain
from ..schedulers.registry import build_scheduler_for_domain
from ..traffic.compiler import compile_arrival_model
from ..types import JSONValue, QueueId
from ..utils import canonical_sha256_hexdigest


_EXACT_MAX_WEIGHT_SCHEDULERS = frozenset(
    {
        "crossbar_max_weight",
        "interval_max_weight",
        "node_exclusive_max_weight",
        "conflict_graph_max_weight",
        "resource_packing_max_weight",
    }
)


def _nonnegative_int(value: Any, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValidationError(f"{name} must be an integer", context={"value": value})
    result = int(value)
    if result < 0:
        raise ValidationError(f"{name} must be >= 0", context={"value": result})
    return result


@dataclass(slots=True, frozen=True)
class RealizedVectorArrivalTrace:
    """One explicit count vector for every simulated slot."""

    queue_ids: tuple[QueueId, ...]
    vectors: tuple[tuple[int, ...], ...]

    def __post_init__(self) -> None:
        queue_ids = tuple(self.queue_ids)
        if len(queue_ids) < 2:
            raise ValidationError("a fan-in trace requires at least two queues")
        if len(set(queue_ids)) != len(queue_ids):
            raise ValidationError("trace queue_ids must be unique")
        vectors: list[tuple[int, ...]] = []
        for slot, raw_vector in enumerate(self.vectors):
            vector = tuple(
                _nonnegative_int(value, name=f"vectors[{slot}][{index}]")
                for index, value in enumerate(raw_vector)
            )
            if len(vector) != len(queue_ids):
                raise ValidationError(
                    "every arrival vector must align with queue_ids",
                    context={
                        "slot": slot,
                        "length": len(vector),
                        "expected_length": len(queue_ids),
                    },
                )
            vectors.append(vector)
        if not vectors:
            raise ValidationError("arrival trace must contain at least one slot")
        object.__setattr__(self, "queue_ids", queue_ids)
        object.__setattr__(self, "vectors", tuple(vectors))

    @property
    def slots(self) -> int:
        return len(self.vectors)

    @property
    def totals_by_queue(self) -> tuple[int, ...]:
        return tuple(
            sum(vector[index] for vector in self.vectors)
            for index in range(len(self.queue_ids))
        )

    def deterministic_events(self) -> list[dict[str, JSONValue]]:
        return [
            {"slot": slot, "queue_id": queue_id, "count": count}
            for slot, vector in enumerate(self.vectors)
            for queue_id, count in zip(self.queue_ids, vector, strict=True)
            if count
        ]

    def to_dict(self) -> dict[str, JSONValue]:
        """Return the exact shared stream definition, not a seed surrogate."""

        return {
            "queue_ids": list(self.queue_ids),
            "vectors": [list(vector) for vector in self.vectors],
        }

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "RealizedVectorArrivalTrace":
        if not isinstance(payload, Mapping):
            raise ValidationError("arrival trace must be a mapping")
        if set(payload) != {"queue_ids", "vectors"}:
            raise ValidationError(
                "arrival trace requires exactly queue_ids and vectors",
                context={"keys": sorted(str(key) for key in payload)},
            )
        raw_queue_ids = payload["queue_ids"]
        raw_vectors = payload["vectors"]
        if isinstance(raw_queue_ids, (str, bytes)) or not isinstance(raw_queue_ids, Sequence):
            raise ValidationError("arrival trace queue_ids must be a sequence")
        if isinstance(raw_vectors, (str, bytes)) or not isinstance(raw_vectors, Sequence):
            raise ValidationError("arrival trace vectors must be a sequence")
        vectors: list[tuple[Any, ...]] = []
        for slot, raw_vector in enumerate(raw_vectors):
            if isinstance(raw_vector, (str, bytes)) or not isinstance(raw_vector, Sequence):
                raise ValidationError(
                    "arrival trace vectors must contain sequences",
                    context={"slot": slot},
                )
            vectors.append(tuple(raw_vector))
        return cls(tuple(raw_queue_ids), tuple(vectors))


@dataclass(slots=True, frozen=True)
class ConditionalResponseLevel:
    backlog: int
    exposure: int
    served: int
    response: float

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "backlog": self.backlog,
            "exposure": self.exposure,
            "served": self.served,
            "response": self.response,
        }


@dataclass(slots=True, frozen=True)
class QueueRedistribution:
    queue_id: QueueId
    offered: int
    current_backlog_sum: int
    reversed_backlog_sum: int
    backlog_sum_change: int
    current_departures: int
    reversed_departures: int
    departure_change: int
    current_mean_backlog: float
    reversed_mean_backlog: float
    mean_backlog_change: float
    current_departure_rate: float
    reversed_departure_rate: float
    departure_rate_change: float
    current_response: tuple[ConditionalResponseLevel, ...]
    reversed_response: tuple[ConditionalResponseLevel, ...]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "queue_id": self.queue_id,
            "offered": self.offered,
            "current_backlog_sum": self.current_backlog_sum,
            "reversed_backlog_sum": self.reversed_backlog_sum,
            "backlog_sum_change": self.backlog_sum_change,
            "current_departures": self.current_departures,
            "reversed_departures": self.reversed_departures,
            "departure_change": self.departure_change,
            "current_mean_backlog": self.current_mean_backlog,
            "reversed_mean_backlog": self.reversed_mean_backlog,
            "mean_backlog_change": self.mean_backlog_change,
            "current_departure_rate": self.current_departure_rate,
            "reversed_departure_rate": self.reversed_departure_rate,
            "departure_rate_change": self.departure_rate_change,
            "current_response": [row.to_dict() for row in self.current_response],
            "reversed_response": [row.to_dict() for row in self.reversed_response],
        }


@dataclass(slots=True, frozen=True)
class PairedPriorityReport:
    queue_ids: tuple[QueueId, ...]
    current_priority: tuple[QueueId, ...]
    reversed_priority: tuple[QueueId, ...]
    slots: int
    offered_packets: int
    aggregate_backlog_path_equal: bool
    aggregate_backlog_sum: int
    final_aggregate_backlog: int
    redistribution: tuple[QueueRedistribution, ...]
    source_arrival_law: Mapping[str, JSONValue]
    realized_arrival_stream: Mapping[str, JSONValue]
    scheduler_name: str
    scheduler_params: Mapping[str, JSONValue]
    requested_seed: int
    actual_seed: int
    observation_block_slots: int | None
    config_metadata: Mapping[str, JSONValue]

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "experiment": "paired_fanin_priority",
            "slot_convention": "service_before_arrival",
            "buffer_mode": NO_DROP_CAPACITY,
            "shared_realized_vector_arrivals": True,
            "arrival_trace_validation": "exact_slotwise_source_rng_replay",
            "source_arrival_law": dict(self.source_arrival_law),
            "realized_vector_arrival_stream": dict(self.realized_arrival_stream),
            "initial_condition": "empty_queues",
            "measurement_window": [0, self.slots],
            "observation_block_slots": self.observation_block_slots,
            "requested_seed": self.requested_seed,
            "actual_seed": self.actual_seed,
            "random_streams": {
                "arrivals": {
                    "engine": RNG_ENGINE_NAME,
                    "seed_scheme_version": SEED_SCHEME_VERSION,
                    "numpy_version": np.__version__,
                    "categorical_sampler": ARRIVAL_CATEGORICAL_SAMPLER,
                    "domain": int(RNGDomain.ARRIVAL_MODEL),
                    "slot_isolated": True,
                },
                "arrival_initial": {
                    "engine": RNG_ENGINE_NAME,
                    "seed_scheme_version": SEED_SCHEME_VERSION,
                    "domain": int(RNGDomain.ARRIVAL_INITIAL),
                    "purpose": "markov_count_kernel_initial_state",
                },
                "scheduler": "exact_declared_priority",
            },
            "scheduler": self.scheduler_name,
            "scheduler_params": dict(self.scheduler_params),
            "config_metadata": dict(self.config_metadata),
            "queue_ids": list(self.queue_ids),
            "current_priority": list(self.current_priority),
            "reversed_priority": list(self.reversed_priority),
            "slots": self.slots,
            "offered_packets": self.offered_packets,
            "aggregate_backlog_path_equal": self.aggregate_backlog_path_equal,
            "aggregate_backlog_sum": self.aggregate_backlog_sum,
            "final_aggregate_backlog": self.final_aggregate_backlog,
            "queues": [row.to_dict() for row in self.redistribution],
        }

def _params_without_priority(config: SimConfig) -> dict[str, Any]:
    params = deepcopy(dict(config.scheduler.params))
    params.pop("priority", None)
    return params


def _validate_paired_configs(
    current: SimConfig,
    reversed_policy: SimConfig,
    trace: RealizedVectorArrivalTrace,
) -> tuple[tuple[QueueId, ...], tuple[QueueId, ...]]:
    if current.switch.catalog.queue_ids != trace.queue_ids:
        raise ValidationError("arrival trace queue_ids must equal the configured queue order")
    if reversed_policy.switch.catalog.queue_ids != trace.queue_ids:
        raise ValidationError("both paired configs must use the trace queue order")
    if current.switch != reversed_policy.switch:
        raise ValidationError("paired configs must use identical switches")
    if current.run != reversed_policy.run:
        raise ValidationError("paired configs must use identical run settings")
    if current.arrival != reversed_policy.arrival:
        raise ValidationError("paired configs must define the same source arrival law")
    if current.telemetry != reversed_policy.telemetry or current.metadata != reversed_policy.metadata:
        raise ValidationError("paired configs may differ only in scheduler priority")
    if current.scheduler.name != reversed_policy.scheduler.name:
        raise ValidationError("paired configs must use the same scheduler")
    if current.scheduler.name not in _EXACT_MAX_WEIGHT_SCHEDULERS:
        raise ValidationError("paired priority requires a built-in exact MaxWeight scheduler")
    if _params_without_priority(current) != _params_without_priority(reversed_policy):
        raise ValidationError("paired scheduler parameters may differ only in priority")
    if current.switch.capacity is not None:
        raise ValidationError("paired fan-in priority experiments require NoDrop")
    if current.run.termination != "fixed_slots":
        raise ValidationError("paired fan-in priority experiments require fixed_slots")
    if current.run.warmup_slots != 0:
        raise ValidationError(
            "paired fan-in path verification requires warmup_slots=0 so every transition is observed"
        )
    if current.run.slots != trace.slots:
        raise ValidationError(
            "run.slots must equal the number of realized arrival vectors",
            context={"slots": current.run.slots, "trace_slots": trace.slots},
        )
    if current.run.seed < 0 or current.run.actual_seed is not None:
        raise ValidationError(
            "paired configs require the same fixed non-negative seed and no pre-resolved actual_seed"
        )

    current_priority = tuple(current.scheduler.params.get("priority") or ())
    reverse_priority = tuple(reversed_policy.scheduler.params.get("priority") or ())
    if len(current_priority) != len(trace.queue_ids) or set(current_priority) != set(trace.queue_ids):
        raise ValidationError("current priority must be a complete queue permutation")
    if reverse_priority != tuple(reversed(current_priority)):
        raise ValidationError("the second priority must exactly reverse the first priority")
    return current_priority, reverse_priority


def _bind_scheduler_for_preflight(config: SimConfig) -> Any:
    """Bind the already-validated scheduler without creating run artifacts."""

    service_family = config.scheduler.service_family
    if service_family is None:  # pragma: no cover - resolve_config rejects this
        raise ValidationError("paired scheduler has no service family")
    domain = QueueSchedulerDomain(
        queue_catalog=config.switch.catalog,
        service_family=service_family,
    )
    return build_scheduler_for_domain(
        config.scheduler.name,
        config.scheduler.params,
        domain,
    )


def _validate_complete_fanin(config: SimConfig) -> None:
    """Prove that every singleton and no pair is feasible in this domain."""

    catalog = config.switch.catalog
    scheduler = _bind_scheduler_for_preflight(config)
    ones = np.ones(catalog.n_queues, dtype=np.int64)
    for queue_id in catalog.queue_ids:
        scheduler.validate_service_decision(ServiceDecision((queue_id,)), ones)
    for left_index, left in enumerate(catalog.queue_ids):
        for right in catalog.queue_ids[left_index + 1 :]:
            try:
                scheduler.validate_service_decision(
                    ServiceDecision((left, right)),
                    ones,
                )
            except ScheduleError:
                continue
            raise ValidationError(
                "configured service family is not fan-in: a queue pair is jointly feasible",
                context={"queue_ids": [left, right]},
            )


def _validate_trace_source_replay(
    config: SimConfig,
    trace: RealizedVectorArrivalTrace,
) -> None:
    """Replay the declared count law before creating either arm's artifacts.

    Replaying the actual model is stronger than family-specific support checks:
    it proves the supplied arbitrary nonnegative vectors are exactly those
    generated by the recorded seed, including Poisson multiplicities, finite
    count-table outcome identity, and stateful transitions. Markov initialization
    is independently derived inside ``compile_arrival_model`` from
    ARRIVAL_INITIAL; slot draws use only ARRIVAL_MODEL/slot streams.
    """

    model = compile_arrival_model(
        config,
        actual_seed=config.run.seed,
        validate=False,
    )
    model.reset()
    catalog = config.switch.catalog
    for slot, expected_vector in enumerate(trace.vectors):
        sample = model.sample(
            slot,
            build_arrival_rng_for_slot(config.run.seed, slot),
        )
        counts = sample.offered_counts
        if counts is None:
            raise ValidationError(
                "canonical paired source did not emit a queue-count vector",
                context={"family": config.arrival.family, "slot": slot},
            )
        counts.validate_catalog(catalog)
        realized_vector = tuple(int(value) for value in counts)
        if realized_vector != expected_vector:
            mismatches = [
                {
                    "queue_id": trace.queue_ids[index],
                    "expected": expected,
                    "realized": realized,
                }
                for index, (expected, realized) in enumerate(
                    zip(expected_vector, realized_vector, strict=True)
                )
                if expected != realized
            ]
            raise ValidationError(
                "arrival trace does not exactly replay the declared source RNG",
                context={
                    "family": config.arrival.family,
                    "slot": slot,
                    "mismatches": mismatches,
                },
            )


@dataclass(slots=True)
class _ArmAccumulator:
    trace: RealizedVectorArrivalTrace
    expected_total: int = 0
    next_slot: int = 0
    aggregate_backlog_sum: int = 0
    backlog_sums: list[int] | None = None
    departure_counts: list[int] | None = None
    response_exposure: list[dict[int, int]] | None = None
    response_served: list[dict[int, int]] | None = None

    def __post_init__(self) -> None:
        self.backlog_sums = [0] * len(self.trace.queue_ids)
        self.departure_counts = [0] * len(self.trace.queue_ids)
        self.response_exposure = [{} for _queue_id in self.trace.queue_ids]
        self.response_served = [{} for _queue_id in self.trace.queue_ids]

    def observe(self, commit: CommittedSlot) -> None:
        if commit.slot != self.next_slot:
            raise ValidationError(
                "paired experiment observed a nonconsecutive slot",
                context={"slot": commit.slot, "expected_slot": self.next_slot},
            )
        vector = self.trace.vectors[self.next_slot]
        if commit.queue_ids != self.trace.queue_ids:
            raise ValidationError("committed slot queue order differs from the arrival trace")
        before = sum(int(value) for value in commit.q_before)
        if before != self.expected_total:
            raise ValidationError(
                "fan-in aggregate backlog departed from the shared expected path",
                context={"slot": commit.slot, "observed": before, "expected": self.expected_total},
            )
        expected_service = int(before > 0)
        if commit.served_count != expected_service:
            raise ValidationError(
                "fan-in policy was not work conserving",
                context={"slot": commit.slot, "served": commit.served_count, "expected": expected_service},
            )
        observed_offered = tuple(commit.offered_by_queue.get(queue_id, 0) for queue_id in self.trace.queue_ids)
        observed_admitted = tuple(commit.admitted_by_queue.get(queue_id, 0) for queue_id in self.trace.queue_ids)
        if observed_offered != vector or observed_admitted != vector or commit.dropped_count:
            raise ValidationError(
                "an arm did not realize and admit the supplied vector-arrival trace exactly",
                context={"slot": commit.slot},
            )
        expected_after = max(before - 1, 0) + sum(vector)
        after = sum(int(value) for value in commit.q_after)
        if after != expected_after:
            raise ValidationError(
                "fan-in aggregate recurrence failed",
                context={"slot": commit.slot, "observed": after, "expected": expected_after},
            )

        assert self.backlog_sums is not None
        assert self.departure_counts is not None
        assert self.response_exposure is not None
        assert self.response_served is not None
        for index, queue_id in enumerate(self.trace.queue_ids):
            backlog = int(commit.q_before[index])
            served = commit.served_by_queue.get(queue_id, 0)
            self.backlog_sums[index] += backlog
            self.departure_counts[index] += served
            self.response_exposure[index][backlog] = (
                self.response_exposure[index].get(backlog, 0) + 1
            )
            self.response_served[index][backlog] = (
                self.response_served[index].get(backlog, 0) + served
            )
        self.aggregate_backlog_sum += before
        self.expected_total = expected_after
        self.next_slot += 1

    def finish(self) -> None:
        if self.next_slot != self.trace.slots:
            raise ValidationError(
                "paired experiment did not observe the complete trace",
                context={"observed_slots": self.next_slot, "expected_slots": self.trace.slots},
            )

    def conditional_response(self, queue_index: int) -> tuple[ConditionalResponseLevel, ...]:
        assert self.response_exposure is not None
        assert self.response_served is not None
        return tuple(
            ConditionalResponseLevel(
                backlog=backlog,
                exposure=exposure,
                served=self.response_served[queue_index].get(backlog, 0),
                response=self.response_served[queue_index].get(backlog, 0) / exposure,
            )
            for backlog, exposure in sorted(self.response_exposure[queue_index].items())
        )


def run_paired_fanin_priority(
    current_config: Mapping[str, Any],
    reversed_config: Mapping[str, Any],
    trace: RealizedVectorArrivalTrace,
    *,
    output_dir: str | Path,
) -> PairedPriorityReport:
    """Run and verify two priority arms against one explicit arrival trace.

    ``warmup_slots`` must be zero because the public committed-slot observer is
    measurement-only and this experiment promises verification of every slot.
    The returned report contains sufficient totals for redistribution analysis
    but deliberately omits a full slot trace.
    """

    if not isinstance(trace, RealizedVectorArrivalTrace):
        raise ValidationError("trace must be a RealizedVectorArrivalTrace")
    # Validate and compare the source laws before any output is created.  Both
    # arms execute these source laws directly; their isolated arrival RNG
    # streams are verified slot by slot against the supplied trace.
    source_current = resolve_config(deepcopy(dict(current_config)), validate=True)
    source_reversed = resolve_config(deepcopy(dict(reversed_config)), validate=True)
    current_priority, reverse_priority = _validate_paired_configs(
        source_current,
        source_reversed,
        trace,
    )
    # Topology is an experiment precondition.  Prove it before build_simulation
    # creates either arm's output directory or static artifacts.
    _validate_complete_fanin(source_current)
    _validate_complete_fanin(source_reversed)
    _validate_trace_source_replay(source_current, trace)

    root = Path(output_dir)
    current_simulator = build_simulation(source_current, output_dir=root / "current")
    current_accumulator = _ArmAccumulator(trace)
    current_simulator.run(observers=current_accumulator.observe)
    current_accumulator.finish()
    current_actual_seed = current_simulator.actual_seed

    # Build the second arm only after the first is complete so the paired
    # runner does not retain two full simulator states at once.
    reversed_simulator = build_simulation(
        source_reversed,
        output_dir=root / "reversed",
    )
    reversed_accumulator = _ArmAccumulator(trace)
    reversed_simulator.run(observers=reversed_accumulator.observe)
    reversed_accumulator.finish()

    if current_accumulator.aggregate_backlog_sum != reversed_accumulator.aggregate_backlog_sum:
        raise ValidationError("paired arms did not have equal aggregate backlog paths")
    if current_accumulator.expected_total != reversed_accumulator.expected_total:
        raise ValidationError("paired arms did not finish with equal aggregate backlog")

    assert current_accumulator.backlog_sums is not None
    assert reversed_accumulator.backlog_sums is not None
    assert current_accumulator.departure_counts is not None
    assert reversed_accumulator.departure_counts is not None
    redistribution: list[QueueRedistribution] = []
    for index, queue_id in enumerate(trace.queue_ids):
        current_backlog = current_accumulator.backlog_sums[index]
        reverse_backlog = reversed_accumulator.backlog_sums[index]
        current_departures = current_accumulator.departure_counts[index]
        reverse_departures = reversed_accumulator.departure_counts[index]
        backlog_change = reverse_backlog - current_backlog
        departure_change = reverse_departures - current_departures
        redistribution.append(
            QueueRedistribution(
                queue_id=queue_id,
                offered=trace.totals_by_queue[index],
                current_backlog_sum=current_backlog,
                reversed_backlog_sum=reverse_backlog,
                backlog_sum_change=backlog_change,
                current_departures=current_departures,
                reversed_departures=reverse_departures,
                departure_change=departure_change,
                current_mean_backlog=current_backlog / trace.slots,
                reversed_mean_backlog=reverse_backlog / trace.slots,
                mean_backlog_change=backlog_change / trace.slots,
                current_departure_rate=current_departures / trace.slots,
                reversed_departure_rate=reverse_departures / trace.slots,
                departure_rate_change=departure_change / trace.slots,
                current_response=current_accumulator.conditional_response(index),
                reversed_response=reversed_accumulator.conditional_response(index),
            )
        )

    source_payload = resolved_config_to_dict(source_current)
    source_arrival = source_payload["arrival"]
    if not isinstance(source_arrival, Mapping):
        raise ValidationError("resolved paired scientific configuration is malformed")

    return PairedPriorityReport(
        queue_ids=trace.queue_ids,
        current_priority=current_priority,
        reversed_priority=reverse_priority,
        slots=trace.slots,
        offered_packets=sum(trace.totals_by_queue),
        aggregate_backlog_path_equal=True,
        aggregate_backlog_sum=current_accumulator.aggregate_backlog_sum,
        final_aggregate_backlog=current_accumulator.expected_total,
        redistribution=tuple(redistribution),
        source_arrival_law=dict(source_arrival),
        realized_arrival_stream={
            "construction": "declared_source_with_slot_isolated_arrival_rng",
            "queue_ids": list(trace.queue_ids),
            "slots": trace.slots,
            "trace_sha256": canonical_sha256_hexdigest(
                {"kind": "realized_vector_arrival_trace", "payload": trace.to_dict()}
            ),
            "totals_by_queue": list(trace.totals_by_queue),
            "total_packets": sum(trace.totals_by_queue),
            "maximum_queue_count_in_one_slot": max(
                count for vector in trace.vectors for count in vector
            ),
            "actual_seed": current_actual_seed,
            "rng_engine": RNG_ENGINE_NAME,
            "seed_scheme_version": SEED_SCHEME_VERSION,
            "numpy_version": np.__version__,
            "arrival_categorical_sampler": ARRIVAL_CATEGORICAL_SAMPLER,
            "rng_domain": int(RNGDomain.ARRIVAL_MODEL),
            "rng_path": ["actual_seed", int(RNGDomain.ARRIVAL_MODEL), "slot"],
            "initial_rng_domain": int(RNGDomain.ARRIVAL_INITIAL),
            "initial_rng_path": [
                "actual_seed",
                int(RNGDomain.ARRIVAL_INITIAL),
            ],
        },
        scheduler_name=source_current.scheduler.name,
        scheduler_params=dict(source_current.scheduler.params),
        requested_seed=source_current.run.seed,
        actual_seed=current_actual_seed,
        observation_block_slots=source_current.telemetry.observation.block_slots,
        config_metadata=dict(source_current.metadata),
    )


__all__ = [
    "ConditionalResponseLevel",
    "PairedPriorityReport",
    "QueueRedistribution",
    "RealizedVectorArrivalTrace",
    "run_paired_fanin_priority",
]
