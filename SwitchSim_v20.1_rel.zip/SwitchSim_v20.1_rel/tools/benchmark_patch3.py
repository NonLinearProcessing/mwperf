"""Deterministic microbenchmark for the Patch-3 exact schedulers."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from voqsim.queues import QueueCatalog
from voqsim.schedulers import build_scheduler_for_domain
from voqsim.schedulers.domain import QueueSchedulerDomain


def _median_ms(select, q_len: np.ndarray, iterations: int) -> float:
    rng = np.random.default_rng(173)
    for slot in range(8):
        select(q_len, slot, rng)
    samples: list[int] = []
    for slot in range(iterations):
        started = perf_counter_ns()
        select(q_len, slot, rng)
        samples.append(perf_counter_ns() - started)
    return statistics.median(samples) / 1_000_000.0


def _crossbar(size: int, iterations: int) -> float:
    queue_ids = tuple(f"q-{i}-{j}" for i in range(size) for j in range(size))
    catalog = QueueCatalog(queue_ids)
    constraint = {
        "inputs": list(range(size)),
        "outputs": list(range(size)),
        "edges": [
            {"queue_id": f"q-{i}-{j}", "input": i, "output": j}
            for i in range(size)
            for j in range(size)
        ],
    }
    scheduler = build_scheduler_for_domain(
        "crossbar_max_weight",
        {"constraint": constraint},
        QueueSchedulerDomain(catalog, "crossbar_matching"),
    )
    q_len = np.fromiter(((index * 37 + 11) % 101 for index in range(size * size)), dtype=np.int64)
    return _median_ms(scheduler.select_service, q_len, iterations)


def _interval(size: int, iterations: int) -> float:
    queue_ids = tuple(f"q-{index}" for index in range(size))
    catalog = QueueCatalog(queue_ids)
    constraint = {
        "intervals": [
            {"queue_id": queue_id, "left": index, "right": index + 2}
            for index, queue_id in enumerate(queue_ids)
        ]
    }
    scheduler = build_scheduler_for_domain(
        "interval_max_weight",
        {"constraint": constraint},
        QueueSchedulerDomain(catalog, "nonoverlapping_intervals"),
    )
    q_len = np.fromiter(((index * 29 + 7) % 97 for index in range(size)), dtype=np.int64)
    return _median_ms(scheduler.select_service, q_len, iterations)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=100)
    args = parser.parse_args()
    if args.iterations < 1:
        parser.error("--iterations must be positive")

    observed = {
        "crossbar_dense_16x16_ms": _crossbar(16, args.iterations),
        "crossbar_dense_32x32_ms": _crossbar(32, args.iterations),
        "interval_256_ms": _interval(256, args.iterations),
        "interval_1024_ms": _interval(1024, args.iterations),
    }
    generous_environment_gates = {
        "crossbar_dense_16x16_ms": 25.0,
        "crossbar_dense_32x32_ms": 100.0,
        "interval_256_ms": 25.0,
        "interval_1024_ms": 100.0,
    }
    passed = all(observed[key] < limit for key, limit in generous_environment_gates.items())
    print(json.dumps({"observed": observed, "gates": generous_environment_gates}, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit("SwitchSim v19 Patch-3 regression performance smoke gate failed")
    print("SwitchSim v19 Patch-3 regression performance smoke gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
