"""Deterministic performance and safety gates for the Patch-5 schedulers.

This is a release smoke benchmark rather than a machine-comparison benchmark.
It exercises the public, domain-bound scheduler APIs and uses deliberately
generous ceilings so ordinary CI load does not make the check flaky.  The
instances cover the important performance shapes for both exponential exact
optimizers: trivial fast paths, independent-component decomposition, bounded
connected searches, arbitrary-size composite weights, and explicit search
limit failures.  A safety-limit case is successful only when ``ScheduleError``
is raised; returning an incumbent or any other approximation is a hard failure.
"""

from __future__ import annotations

import argparse
from collections.abc import Callable, Mapping, Sequence
import hashlib
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter_ns
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from voqsim.errors import ScheduleError
from voqsim.queues import MAX_QUEUE_LENGTH, QueueCatalog, ServiceDecision
from voqsim.schedulers.conflict_graph_max_weight import (
    ConflictGraphMaxWeightScheduler,
)
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.resource_packing_max_weight import (
    ResourcePackingMaxWeightScheduler,
)
from voqsim.types import QueueId
from voqsim.version import SIMULATOR_VERSION


_EXPECTED_VERSION = "19.0.0"
_FAST_PATH_QUEUES = 512
_CONFLICT_COMPONENTS = 60
_CONFLICT_CONNECTED_QUEUES = 30
_PACKING_COMPONENTS = 48
_PACKING_CONNECTED_QUEUES = 20
_BIGINT_QUEUES = 96


def _median_ms(operation: Callable[[], Any], iterations: int) -> float:
    """Return a per-call median after deterministic untimed warmups."""

    for _ in range(3):
        operation()
    samples: list[int] = []
    for _ in range(iterations):
        started = perf_counter_ns()
        operation()
        samples.append(perf_counter_ns() - started)
    return statistics.median(samples) / 1_000_000.0


def _decision_digest(decision: ServiceDecision) -> str:
    payload = json.dumps(
        decision.to_dict(),
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _bind_conflict(
    queue_ids: Sequence[QueueId],
    conflicts: Sequence[tuple[QueueId, QueueId]],
    *,
    priority: Sequence[QueueId] | None = None,
    max_search_states: int | None = None,
) -> tuple[ConflictGraphMaxWeightScheduler, QueueCatalog]:
    catalog = QueueCatalog(queue_ids)
    params: dict[str, Any] = {
        "constraint": {"conflicts": [list(pair) for pair in conflicts]},
        "priority": None if priority is None else list(priority),
        "max_search_states": max_search_states,
    }
    scheduler = ConflictGraphMaxWeightScheduler(params)
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="pairwise_conflicts")
    )
    return scheduler, catalog


def _bind_packing(
    queue_ids: Sequence[QueueId],
    capacity: Sequence[int],
    demands: Sequence[Sequence[int]],
    *,
    priority: Sequence[QueueId] | None = None,
    max_search_states: int | None = None,
) -> tuple[ResourcePackingMaxWeightScheduler, QueueCatalog]:
    catalog = QueueCatalog(queue_ids)
    params: dict[str, Any] = {
        "constraint": {
            "resources": [f"r{index}" for index in range(len(capacity))],
            "capacity": list(capacity),
            "demands": [
                {"queue_id": queue_id, "demand": list(demand)}
                for queue_id, demand in zip(queue_ids, demands, strict=True)
            ],
        },
        "priority": None if priority is None else list(priority),
        "max_search_states": max_search_states,
    }
    scheduler = ResourcePackingMaxWeightScheduler(params)
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="resource_packing")
    )
    return scheduler, catalog


def _timed_selection(
    scheduler: ConflictGraphMaxWeightScheduler | ResourcePackingMaxWeightScheduler,
    q_len: np.ndarray,
    iterations: int,
) -> tuple[float, ServiceDecision]:
    rng = np.random.default_rng(175)

    def select() -> ServiceDecision:
        return scheduler.select_service(q_len, 17, rng)

    decision = select()
    if scheduler.validate_service_decision(decision, q_len) != decision:
        raise RuntimeError("scheduler returned a noncanonical service decision")
    if select() != decision:
        raise RuntimeError("exact scheduler was nondeterministic on a fixed input")
    return _median_ms(select, iterations), decision


def _timed_limit_failure(
    scheduler: ConflictGraphMaxWeightScheduler | ResourcePackingMaxWeightScheduler,
    q_len: np.ndarray,
    iterations: int,
) -> tuple[float, Mapping[str, Any]]:
    rng = np.random.default_rng(175)
    first_context: dict[str, Any] | None = None

    def require_explicit_failure() -> None:
        nonlocal first_context
        try:
            scheduler.select_service(q_len, 23, rng)
        except ScheduleError as exc:
            if "exceeded max_search_states" not in exc.message:
                raise RuntimeError(
                    "safety-limit case raised the wrong ScheduleError"
                ) from exc
            context = dict(exc.context)
            if context.get("max_search_states") != 1:
                raise RuntimeError("safety-limit error omitted the configured limit")
            if not isinstance(context.get("states_explored"), int):
                raise RuntimeError("safety-limit error omitted its exact state count")
            if context.get("states_explored", 0) <= 1:
                raise RuntimeError("safety-limit error fired before exceeding the limit")
            if context.get("slot") != 23:
                raise RuntimeError("safety-limit error omitted the scheduling slot")
            if first_context is None:
                first_context = context
            elif context != first_context:
                raise RuntimeError("safety-limit failure was not deterministic")
            return
        raise RuntimeError(
            "exact scheduler silently returned an incumbent after its safety limit"
        )

    elapsed = _median_ms(require_explicit_failure, iterations)
    if first_context is None:  # pragma: no cover - guarded by operation above
        raise RuntimeError("safety-limit probe did not execute")
    return elapsed, first_context


def _conflict_cases(iterations: int) -> tuple[dict[str, float], dict[str, Any]]:
    observed: dict[str, float] = {}
    evidence: dict[str, Any] = {}

    # Empty occupancy must bypass even a large connected constraint graph.
    empty_ids = tuple(f"ce-{index:04d}" for index in range(_FAST_PATH_QUEUES))
    empty_conflicts = tuple(
        (empty_ids[index], empty_ids[(index + 1) % len(empty_ids)])
        for index in range(len(empty_ids))
    )
    empty_scheduler, _empty_catalog = _bind_conflict(
        empty_ids,
        empty_conflicts,
        max_search_states=1,
    )
    elapsed, decision = _timed_selection(
        empty_scheduler,
        np.zeros(len(empty_ids), dtype=np.int64),
        iterations,
    )
    if decision != ServiceDecision.empty():
        raise RuntimeError("conflict all-empty fast path returned service")
    observed["conflict_all_empty_ms"] = elapsed
    evidence["all_empty"] = {
        "conflicts": len(empty_conflicts),
        "queues": len(empty_ids),
        "selected": 0,
    }

    # An edgeless graph is accepted wholesale without exponential branching.
    edgeless_ids = tuple(f"cf-{index:04d}" for index in range(_FAST_PATH_QUEUES))
    edgeless_scheduler, _edgeless_catalog = _bind_conflict(
        edgeless_ids,
        (),
        max_search_states=1,
    )
    edgeless_lengths = np.fromiter(
        (1 + (index * 37 + 11) % 101 for index in range(len(edgeless_ids))),
        dtype=np.int64,
        count=len(edgeless_ids),
    )
    elapsed, decision = _timed_selection(
        edgeless_scheduler, edgeless_lengths, iterations
    )
    if decision.selected_queue_ids != edgeless_ids:
        raise RuntimeError("edgeless MWIS fast path did not select every live queue")
    observed["conflict_edgeless_ms"] = elapsed
    evidence["edgeless"] = {
        "decision_sha256": _decision_digest(decision),
        "queues": len(edgeless_ids),
        "selected": decision.selected_count,
    }

    # Independent triangles exercise component decomposition without a product
    # search.  Unequal backlogs give a simple independent expected result.
    component_ids = tuple(
        f"cd-{index:04d}" for index in range(3 * _CONFLICT_COMPONENTS)
    )
    component_conflicts: list[tuple[str, str]] = []
    expected_component_ids: list[str] = []
    component_lengths: list[int] = []
    for first in range(0, len(component_ids), 3):
        a, b, c = component_ids[first : first + 3]
        component_conflicts.extend(((a, b), (a, c), (b, c)))
        component_lengths.extend((2, 5, 11))
        expected_component_ids.append(c)
    component_scheduler, _component_catalog = _bind_conflict(
        component_ids,
        component_conflicts,
        max_search_states=5_000,
    )
    elapsed, decision = _timed_selection(
        component_scheduler,
        np.asarray(component_lengths, dtype=np.int64),
        iterations,
    )
    if decision.selected_queue_ids != tuple(expected_component_ids):
        raise RuntimeError("MWIS component decomposition changed the exact optimum")
    observed["conflict_decomposed_ms"] = elapsed
    evidence["decomposed"] = {
        "components": _CONFLICT_COMPONENTS,
        "decision_sha256": _decision_digest(decision),
        "queues": len(component_ids),
        "selected": decision.selected_count,
    }

    # A fixed connected circulant graph is large enough to exercise memoized
    # include/exclude search, while a hard exact-state bound prevents hangs.
    connected_ids = tuple(
        f"cc-{index:02d}" for index in range(_CONFLICT_CONNECTED_QUEUES)
    )
    connected_edges: set[tuple[str, str]] = set()
    for index in range(len(connected_ids)):
        for offset in (1, 4, 9):
            neighbor = (index + offset) % len(connected_ids)
            left_index, right_index = sorted((index, neighbor))
            connected_edges.add(
                (connected_ids[left_index], connected_ids[right_index])
            )
    connected_limit = 250_000
    connected_scheduler, _connected_catalog = _bind_conflict(
        connected_ids,
        tuple(sorted(connected_edges)),
        max_search_states=connected_limit,
    )
    connected_lengths = np.fromiter(
        (1 + (index * 53 + 19) % 127 for index in range(len(connected_ids))),
        dtype=np.int64,
        count=len(connected_ids),
    )
    elapsed, decision = _timed_selection(
        connected_scheduler, connected_lengths, iterations
    )
    if decision.selected_count < 1:
        raise RuntimeError("positive connected MWIS instance returned no service")
    observed["conflict_connected_bounded_ms"] = elapsed
    evidence["connected_bounded"] = {
        "conflicts": len(connected_edges),
        "decision_sha256": _decision_digest(decision),
        "max_search_states": connected_limit,
        "queues": len(connected_ids),
        "selected": decision.selected_count,
    }

    # Equal primary weights on a large clique reduce to the exact priority bit
    # vector.  The composite objective is far beyond fixed-width arithmetic.
    bigint_ids = tuple(f"cb-{index:02d}" for index in range(_BIGINT_QUEUES))
    bigint_priority = tuple(reversed(bigint_ids))
    bigint_conflicts = tuple(
        (bigint_ids[left], bigint_ids[right])
        for left in range(len(bigint_ids))
        for right in range(left + 1, len(bigint_ids))
    )
    bigint_scheduler, _bigint_catalog = _bind_conflict(
        bigint_ids,
        bigint_conflicts,
        priority=bigint_priority,
        max_search_states=500,
    )
    bigint_lengths = np.full(
        len(bigint_ids), MAX_QUEUE_LENGTH, dtype=np.int64
    )
    elapsed, decision = _timed_selection(
        bigint_scheduler, bigint_lengths, iterations
    )
    if decision != ServiceDecision((bigint_priority[0],)):
        raise RuntimeError("large-integer MWIS priority comparison was not exact")
    observed["conflict_bigint_clique_ms"] = elapsed
    evidence["bigint"] = {
        "composite_weight_min_bits": (MAX_QUEUE_LENGTH << len(bigint_ids)).bit_length(),
        "decision_sha256": _decision_digest(decision),
        "fixed_width_int64_bits": 64,
        "queues": len(bigint_ids),
        "selected_queue_id": bigint_priority[0],
    }

    limit_ids = tuple(f"cl-{index}" for index in range(9))
    limit_conflicts = tuple(
        (limit_ids[index], limit_ids[(index + 1) % len(limit_ids)])
        for index in range(len(limit_ids))
    )
    limit_scheduler, _limit_catalog = _bind_conflict(
        limit_ids,
        limit_conflicts,
        max_search_states=1,
    )
    elapsed, context = _timed_limit_failure(
        limit_scheduler,
        np.ones(len(limit_ids), dtype=np.int64),
        iterations,
    )
    observed["conflict_explicit_limit_failure_ms"] = elapsed
    evidence["explicit_limit"] = {
        "context": context,
        "outcome": "explicit_schedule_error",
    }
    return observed, evidence


def _packing_cases(iterations: int) -> tuple[dict[str, float], dict[str, Any]]:
    observed: dict[str, float] = {}
    evidence: dict[str, Any] = {}

    empty_ids = tuple(f"pe-{index:04d}" for index in range(_FAST_PATH_QUEUES))
    empty_capacity = (20, 20, 20, 20)
    empty_demands = tuple(
        (
            1 + index % 3,
            1 + (index * 3) % 4,
            1 + (index * 5) % 3,
            1 + (index * 7) % 5,
        )
        for index in range(len(empty_ids))
    )
    empty_scheduler, _empty_catalog = _bind_packing(
        empty_ids,
        empty_capacity,
        empty_demands,
        max_search_states=1,
    )
    elapsed, decision = _timed_selection(
        empty_scheduler,
        np.zeros(len(empty_ids), dtype=np.int64),
        iterations,
    )
    if decision != ServiceDecision.empty():
        raise RuntimeError("packing all-empty fast path returned service")
    observed["packing_all_empty_ms"] = elapsed
    evidence["all_empty"] = {
        "queues": len(empty_ids),
        "resources": len(empty_capacity),
        "selected": 0,
    }

    free_ids = tuple(f"pf-{index:04d}" for index in range(_FAST_PATH_QUEUES))
    free_capacity = (0, 0, 0)
    free_demands = tuple((0, 0, 0) for _ in free_ids)
    free_scheduler, _free_catalog = _bind_packing(
        free_ids,
        free_capacity,
        free_demands,
        max_search_states=1,
    )
    free_lengths = np.fromiter(
        (1 + (index * 31 + 7) % 97 for index in range(len(free_ids))),
        dtype=np.int64,
        count=len(free_ids),
    )
    elapsed, decision = _timed_selection(free_scheduler, free_lengths, iterations)
    if decision.selected_queue_ids != free_ids:
        raise RuntimeError("zero-demand packing fast path omitted a live queue")
    observed["packing_zero_demand_ms"] = elapsed
    evidence["zero_demand"] = {
        "capacity": list(free_capacity),
        "decision_sha256": _decision_digest(decision),
        "queues": len(free_ids),
        "selected": decision.selected_count,
    }

    # Four competing columns per otherwise disjoint resource must decompose
    # into independent exact subproblems.  Capacity two selects the two largest
    # backlogs in every component.
    component_ids = tuple(
        f"pd-{index:04d}" for index in range(4 * _PACKING_COMPONENTS)
    )
    component_capacity = tuple(2 for _ in range(_PACKING_COMPONENTS))
    component_demands: list[tuple[int, ...]] = []
    component_lengths: list[int] = []
    expected_component_ids: list[str] = []
    for component in range(_PACKING_COMPONENTS):
        for local_index, length in enumerate((2, 5, 9, 14)):
            component_demands.append(
                tuple(
                    1 if resource == component else 0
                    for resource in range(_PACKING_COMPONENTS)
                )
            )
            component_lengths.append(length)
            if local_index >= 2:
                expected_component_ids.append(component_ids[4 * component + local_index])
    component_scheduler, _component_catalog = _bind_packing(
        component_ids,
        component_capacity,
        component_demands,
        max_search_states=20_000,
    )
    elapsed, decision = _timed_selection(
        component_scheduler,
        np.asarray(component_lengths, dtype=np.int64),
        iterations,
    )
    if decision.selected_queue_ids != tuple(expected_component_ids):
        raise RuntimeError("packing decomposition changed the exact optimum")
    observed["packing_decomposed_ms"] = elapsed
    evidence["decomposed"] = {
        "components": _PACKING_COMPONENTS,
        "decision_sha256": _decision_digest(decision),
        "queues": len(component_ids),
        "resources": len(component_capacity),
        "selected": decision.selected_count,
    }

    # Every column uses resource zero, so this fixed multi-resource instance is
    # one connected support component.  Its explicit state bound is a hang and
    # accidental-unbounded-search sentinel, not an approximation threshold.
    connected_ids = tuple(
        f"pc-{index:02d}" for index in range(_PACKING_CONNECTED_QUEUES)
    )
    connected_capacity = (17, 15, 16, 14)
    connected_demands = tuple(
        (
            1 + index % 4,
            (index * 3 + 1) % 5,
            (index * 5 + 2) % 6,
            (index * 7 + 3) % 5,
        )
        for index in range(len(connected_ids))
    )
    connected_limit = 500_000
    connected_scheduler, _connected_catalog = _bind_packing(
        connected_ids,
        connected_capacity,
        connected_demands,
        max_search_states=connected_limit,
    )
    connected_lengths = np.fromiter(
        (1 + (index * 47 + 29) % 131 for index in range(len(connected_ids))),
        dtype=np.int64,
        count=len(connected_ids),
    )
    elapsed, decision = _timed_selection(
        connected_scheduler, connected_lengths, iterations
    )
    if decision.selected_count < 1:
        raise RuntimeError("positive connected packing instance returned no service")
    observed["packing_connected_bounded_ms"] = elapsed
    evidence["connected_bounded"] = {
        "capacity": list(connected_capacity),
        "decision_sha256": _decision_digest(decision),
        "max_search_states": connected_limit,
        "queues": len(connected_ids),
        "resources": len(connected_capacity),
        "selected": decision.selected_count,
    }

    bigint_ids = tuple(f"pb-{index:02d}" for index in range(_BIGINT_QUEUES))
    bigint_priority = tuple(reversed(bigint_ids))
    bigint_scheduler, _bigint_catalog = _bind_packing(
        bigint_ids,
        (1,),
        tuple((1,) for _ in bigint_ids),
        priority=bigint_priority,
        max_search_states=500,
    )
    bigint_lengths = np.full(
        len(bigint_ids), MAX_QUEUE_LENGTH, dtype=np.int64
    )
    elapsed, decision = _timed_selection(
        bigint_scheduler, bigint_lengths, iterations
    )
    if decision != ServiceDecision((bigint_priority[0],)):
        raise RuntimeError("large-integer packing priority comparison was not exact")
    observed["packing_bigint_capacity_one_ms"] = elapsed
    evidence["bigint"] = {
        "composite_weight_min_bits": (MAX_QUEUE_LENGTH << len(bigint_ids)).bit_length(),
        "decision_sha256": _decision_digest(decision),
        "fixed_width_int64_bits": 64,
        "queues": len(bigint_ids),
        "selected_queue_id": bigint_priority[0],
    }

    limit_ids = tuple(f"pl-{index}" for index in range(8))
    limit_scheduler, _limit_catalog = _bind_packing(
        limit_ids,
        (3,),
        tuple((1,) for _ in limit_ids),
        max_search_states=1,
    )
    elapsed, context = _timed_limit_failure(
        limit_scheduler,
        np.arange(1, len(limit_ids) + 1, dtype=np.int64),
        iterations,
    )
    observed["packing_explicit_limit_failure_ms"] = elapsed
    evidence["explicit_limit"] = {
        "context": context,
        "outcome": "explicit_schedule_error",
    }
    return observed, evidence


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run deterministic SwitchSim v19 Patch-5 performance gates."
    )
    parser.add_argument("--iterations", type=int, default=21)
    args = parser.parse_args()
    if args.iterations < 1:
        parser.error("--iterations must be positive")
    if SIMULATOR_VERSION != _EXPECTED_VERSION:
        raise SystemExit(
            f"expected SwitchSim {_EXPECTED_VERSION}, found {SIMULATOR_VERSION}"
        )

    conflict_observed, conflict_evidence = _conflict_cases(args.iterations)
    packing_observed, packing_evidence = _packing_cases(args.iterations)
    observed = {**conflict_observed, **packing_observed}

    # These ceilings are intentionally broad hang/regression sentinels.  The
    # connected exact searches are bounded independently by max_search_states.
    gates_ms = {
        "conflict_all_empty_ms": 100.0,
        "conflict_bigint_clique_ms": 1_000.0,
        "conflict_connected_bounded_ms": 3_000.0,
        "conflict_decomposed_ms": 1_000.0,
        "conflict_edgeless_ms": 500.0,
        "conflict_explicit_limit_failure_ms": 100.0,
        "packing_all_empty_ms": 100.0,
        "packing_bigint_capacity_one_ms": 1_000.0,
        "packing_connected_bounded_ms": 5_000.0,
        "packing_decomposed_ms": 2_000.0,
        "packing_explicit_limit_failure_ms": 100.0,
        "packing_zero_demand_ms": 500.0,
    }
    passed = set(observed) == set(gates_ms) and all(
        observed[name] < limit for name, limit in gates_ms.items()
    )
    report = {
        "evidence": {
            "conflict_graph_max_weight": conflict_evidence,
            "resource_packing_max_weight": packing_evidence,
        },
        "gates_ms": gates_ms,
        "iterations": args.iterations,
        "observed_median_ms": observed,
        "result": "PASS" if passed else "FAIL",
        "simulator_version": SIMULATOR_VERSION,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit("SwitchSim v19 Patch 5 performance gates failed")
    print("SwitchSim v19 Patch 5 performance gates: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
