#!/usr/bin/env python3
"""Report standard and compact scientific SwitchSim v20.1 batch results."""

from __future__ import annotations

import argparse
import csv
from dataclasses import fields, is_dataclass
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from math import comb
from numbers import Integral
from pathlib import Path
import json
import os
import sys
import tempfile
from typing import Any, Mapping, Sequence


DEFAULT_CUTOFFS = (0, 1, 2, 4, 8, 12, 16, 32, 64)
STANDARD_FILENAME = "standard_metrics.csv"
SCIENTIFIC_FILENAME = "scientific_metrics.jsonl"


def _bootstrap_simulator() -> Path:
    bootstrap = argparse.ArgumentParser(add_help=False)
    bootstrap.add_argument("--sim-root", default=".")
    args, _unknown = bootstrap.parse_known_args()
    sim_root = Path(args.sim_root).expanduser().resolve()
    if not (sim_root / "voqsim").is_dir():
        bootstrap.error(
            f"--sim-root must name a SwitchSim v20.1 source tree containing voqsim: {sim_root}"
        )
    sys.path.insert(0, str(sim_root))
    return sim_root


SIM_ROOT = _bootstrap_simulator()

from voqsim.analysis import (  # noqa: E402
    ArrivalMarginal,
    analyze_pooled_target_block,
    certified_target_arrival_marginal,
)
from voqsim.config import load_config  # noqa: E402
from voqsim.errors import SimError, ValidationError  # noqa: E402
from voqsim.telemetry import CompactObservationReader  # noqa: E402
from voqsim.traffic import compile_arrival_spec  # noqa: E402
from voqsim.utils import canonical_json_dumps  # noqa: E402


class ReportError(RuntimeError):
    """A result tree is incomplete or scientifically uninterpretable."""


def _parse_cutoffs(value: str) -> tuple[int, ...]:
    try:
        parts = [part.strip() for part in value.split(",")]
        if not parts or any(not part for part in parts):
            raise ValueError
        cutoffs = tuple(sorted({int(part) for part in parts}))
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "cutoffs must be a comma-separated list of non-negative integers"
        ) from exc
    if not cutoffs or cutoffs[0] < 0:
        raise argparse.ArgumentTypeError("cutoffs must be non-negative and nonempty")
    return cutoffs


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Recursively aggregate run_summary.json files and derive scientific "
            "metrics from compact observations.sqlite3 files."
        )
    )
    parser.add_argument("results_dir", type=Path, help="batch output tree to report")
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="report destination (default: RESULTS_DIR/reports)",
    )
    parser.add_argument(
        "--sim-root",
        type=Path,
        default=SIM_ROOT,
        help="SwitchSim v20.1 source tree (default: current directory)",
    )
    parser.add_argument(
        "--cutoffs",
        type=_parse_cutoffs,
        default=DEFAULT_CUTOFFS,
        metavar="K0,K1,...",
        help=(
            "backlog thresholds at which to evaluate the exact compact statistics; "
            "these do not truncate, bin, or remove observations"
        ),
    )
    parser.add_argument(
        "--stationary-interpretation",
        action="store_true",
        help=(
            "explicitly request stationary identities; off by default because a "
            "finite trajectory does not itself establish stationarity"
        ),
    )
    return parser


def _json_ready(value: Any) -> Any:
    """Convert analysis objects without deep-copying MappingProxyType values."""

    if value is None or isinstance(value, (str, int, bool, float, Decimal)):
        return value
    if isinstance(value, Fraction):
        return {"numerator": value.numerator, "denominator": value.denominator}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Enum):
        return _json_ready(value.value)
    if is_dataclass(value):
        return {field.name: _json_ready(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_ready(item) for item in value]
    if isinstance(value, (set, frozenset)):
        items = [_json_ready(item) for item in value]
        return sorted(items, key=canonical_json_dumps)
    if isinstance(value, Integral):
        return int(value)
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        return _json_ready(to_dict())
    raise TypeError(f"unsupported report value: {type(value)!r}")


def _exact_probability(value: Any) -> Fraction | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, Fraction):
        result = value
    elif isinstance(value, Decimal):
        if not value.is_finite():
            return None
        result = Fraction(value)
    elif isinstance(value, Integral):
        result = Fraction(int(value))
    else:
        return None
    return result if 0 <= result <= 1 else None


def _certify_geometric_binomial(config: Any, queue_id: Any) -> ArrivalMarginal | None:
    """Certify exactly IID Binomial arrivals encoded as independent renewals.

    A geometric grid with ``d_min = delta = 1`` is a Bernoulli event process
    on the integer slots. Independent sources aimed deterministically at one
    queue therefore sum to Binomial(k, p), but only when every source satisfies
    the stated structural conditions and the target's source probabilities
    agree exactly.
    """

    if config.arrival.family != "independent_marked_renewal":
        return None
    raw_sources = config.arrival.params.get("sources")
    if not isinstance(raw_sources, Sequence) or isinstance(raw_sources, (str, bytes)) or not raw_sources:
        return None

    target_probabilities: list[Fraction] = []
    for raw_source in raw_sources:
        if not isinstance(raw_source, Mapping):
            return None
        if set(raw_source) != {"id", "interarrival", "destination_pmf"}:
            return None
        interarrival = raw_source.get("interarrival")
        destinations = raw_source.get("destination_pmf")
        if not isinstance(interarrival, Mapping) or set(interarrival) != {
            "kind",
            "d_min",
            "delta",
            "p",
        }:
            return None
        if (
            interarrival.get("kind") != "geometric_grid"
            or interarrival.get("d_min") != 1
            or interarrival.get("delta") != 1
        ):
            return None
        probability = _exact_probability(interarrival.get("p"))
        if probability is None or probability == 0:
            return None
        if not isinstance(destinations, Sequence) or isinstance(destinations, (str, bytes)):
            return None
        if len(destinations) != 1 or not isinstance(destinations[0], Mapping):
            return None
        destination = destinations[0]
        if set(destination) != {"queue_id", "probability"}:
            return None
        if _exact_probability(destination.get("probability")) != 1:
            return None
        if destination.get("queue_id") == queue_id:
            target_probabilities.append(probability)

    if not target_probabilities or len(set(target_probabilities)) != 1:
        return None
    p = target_probabilities[0]
    source_count = len(target_probabilities)
    pmf = {
        count: Fraction(comb(source_count, count))
        * p**count
        * (1 - p) ** (source_count - count)
        for count in range(source_count + 1)
    }
    return ArrivalMarginal.from_pmf(
        pmf,
        family="certified_binomial_from_independent_geometric_renewal",
    )


def _arrival_law(config: Any, compiled: Any, queue_id: Any) -> tuple[Any, dict[str, Any]]:
    certification = certified_target_arrival_marginal(compiled, queue_id)
    if certification.marginal is not None:
        return certification.marginal, {
            "family": certification.family,
            "status": certification.status,
            "method": "canonical_fresh_iid_family",
            "mean": certification.marginal.mean,
        }
    binomial = _certify_geometric_binomial(config, queue_id)
    if binomial is not None:
        return binomial, {
            "family": certification.family,
            "status": "ok",
            "method": "exact_independent_geometric_binomial",
            "mean": binomial.mean,
        }
    return None, {
        "family": certification.family,
        "status": certification.status,
        "method": "unavailable",
        "mean": None,
    }


def _reported_cutoff(cutoff: Any) -> dict[str, Any]:
    """Give empirical cutoff quantities unambiguous report-only names."""

    compression = cutoff.compression_defect
    return {
        "cutoff": cutoff.cutoff,
        "tau": cutoff.tau,
        "service_tail_mass": cutoff.service_tail_mass,
        "backlog_tail_mass": cutoff.backlog_tail_mass,
        "service_backlog_tail_mass": cutoff.service_backlog_tail_mass,
        "tail_service": cutoff.tail_service,
        "slack": cutoff.slack,
        "association": cutoff.association,
        "tail_mean_share": cutoff.tail_mean_share,
        "finite_data_compression_expression": compression,
        "finite_data_status": cutoff.status,
        "arithmetic_error_bound": cutoff.numerical_error_bound,
        "arithmetic_status": cutoff.numerical_status,
        "compression_statistical_status": (
            "not_computed"
            if compression is None
            else "finite_data_estimate_no_stationarity_claim"
        ),
    }


def _compact_analysis(analysis: Any) -> dict[str, Any]:
    """Retain scientific totals and derived metrics, not duplicate level rows."""

    pooled = analysis.pooled
    pooled_totals = {
        "unit_kind": pooled.unit_kind,
        "unit_count": pooled.unit_count,
        "target_id": pooled.target_id,
        "queue_id": pooled.queue_id,
        "mass_kind": pooled.mass_kind,
        "gap_mode": pooled.gap_mode,
        "block_id": pooled.block_id,
        "start_slot": pooled.start_slot,
        "stop_slot": pooled.stop_slot,
        "exposure": pooled.exposure,
        "served": pooled.served,
        "backlog_exposure": pooled.backlog_exposure,
        "backlog_square_exposure": pooled.backlog_square_exposure,
        "backlog_service": pooled.backlog_service,
        "start_boundary": pooled.start_boundary,
        "end_boundary": pooled.end_boundary,
        "slots_observed": pooled.slots_observed,
        "decision_mass": pooled.decision_mass,
        "offered": pooled.offered,
        "offered_square": pooled.offered_square,
        "admitted": pooled.admitted,
        "admitted_square": pooled.admitted_square,
        "dropped": pooled.dropped,
        "gap_negative": pooled.gap_negative,
        "gap_zero": pooled.gap_zero,
        "gap_positive": pooled.gap_positive,
        "gap_zero_served": pooled.gap_zero_served,
        "gap_positive_sum": pooled.gap_positive_sum,
        "gap_negative_sum": pooled.gap_negative_sum,
        "gap_negative_backlog": pooled.gap_negative_backlog,
        "gap_zero_unserved_backlog": pooled.gap_zero_unserved_backlog,
        "no_drop": pooled.no_drop,
        "early_service_late_arrival": pooled.early_service_late_arrival,
    }
    return {
        "pooled_totals": pooled_totals,
        "cutoffs": tuple(_reported_cutoff(cutoff) for cutoff in analysis.cutoffs),
        "finite_windows": analysis.finite_windows,
        "innovations": analysis.innovations,
        "gap_competition": analysis.gap_competition,
        "gap_cutoffs": analysis.gap_cutoffs,
        "stationary_tie": analysis.stationary_tie,
        "isolated_server": analysis.isolated_server,
    }


STANDARD_FIELDS = (
    "run",
    "condition_id",
    "campaign",
    "scenario_id",
    "nominal_radial_load",
    "size",
    "requested_seed",
    "actual_seed",
    "arrival_family",
    "scheduler",
    "scheduler_algorithm_id",
    "scheduler_optimizer_id",
    "service_family",
    "n_queues",
    "configured_slots",
    "warmup_slots",
    "measurement_slots",
    "buffer_mode",
    "slots_observed",
    "offered_packets",
    "admitted_packets",
    "dropped_packets",
    "completed_packets",
    "drop_fraction_of_offered",
    "mean_total_occupancy_q_before",
    "mean_total_occupancy_q_after",
    "mean_sojourn_slots",
    "p95_sojourn_slots",
    "max_sojourn_slots",
    "mean_waiting_slots",
    "p95_waiting_slots",
    "max_waiting_slots",
    "mean_selected_queue_count",
    "mean_served_packet_count",
    "mean_primary_maxweight_objective",
    "measurement_start_occupancy_packets",
    "measurement_end_occupancy_packets",
    "execution_peak_occupancy_packets",
)


def _read_summary(path: Path) -> Mapping[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)
    except (OSError, ValueError) as exc:
        raise ReportError(f"cannot read {path}: {exc}") from exc
    if not isinstance(payload, Mapping):
        raise ReportError(f"run summary is not a JSON object: {path}")
    return payload


def _standard_row(results_root: Path, summary_path: Path, summary: Mapping[str, Any]) -> dict[str, Any]:
    metrics = summary.get("metrics")
    metadata = summary.get("metadata")
    if not isinstance(metrics, Mapping) or not isinstance(metadata, Mapping):
        raise ReportError(f"run summary lacks metrics/metadata objects: {summary_path}")
    schedule = metrics.get("schedule")
    if not isinstance(schedule, Mapping):
        schedule = {}
    config_metadata = metadata.get("config_metadata")
    if not isinstance(config_metadata, Mapping):
        config_metadata = {}
    size = config_metadata.get("size")
    return {
        "run": summary_path.parent.relative_to(results_root).as_posix(),
        "condition_id": config_metadata.get("condition_id"),
        "campaign": config_metadata.get("campaign"),
        "scenario_id": config_metadata.get("scenario_id"),
        "nominal_radial_load": config_metadata.get("nominal_radial_load"),
        "size": "" if size is None else canonical_json_dumps(size),
        "requested_seed": metadata.get("requested_seed"),
        "actual_seed": metadata.get("actual_seed"),
        "arrival_family": metadata.get("arrival_family"),
        "scheduler": metadata.get("scheduler"),
        "scheduler_algorithm_id": metadata.get("scheduler_algorithm_id"),
        "scheduler_optimizer_id": metadata.get("scheduler_optimizer_id"),
        "service_family": metadata.get("service_family"),
        "n_queues": metadata.get("n_queues"),
        "configured_slots": metadata.get("configured_slots"),
        "warmup_slots": metadata.get("warmup_slots"),
        "measurement_slots": metadata.get("measurement_slots"),
        "buffer_mode": metadata.get("buffer_mode"),
        "slots_observed": metrics.get("slots_observed"),
        "offered_packets": metrics.get("offered_packets"),
        "admitted_packets": metrics.get("admitted_packets"),
        "dropped_packets": metrics.get("dropped_packets"),
        "completed_packets": metrics.get("completed_packets"),
        "drop_fraction_of_offered": metrics.get("drop_fraction_of_offered"),
        "mean_total_occupancy_q_before": metrics.get("mean_total_occupancy_q_before"),
        "mean_total_occupancy_q_after": metrics.get("mean_total_occupancy_q_after"),
        "mean_sojourn_slots": metrics.get("mean_sojourn_slots"),
        "p95_sojourn_slots": metrics.get("p95_sojourn_slots"),
        "max_sojourn_slots": metrics.get("max_sojourn_slots"),
        "mean_waiting_slots": metrics.get("mean_waiting_slots"),
        "p95_waiting_slots": metrics.get("p95_waiting_slots"),
        "max_waiting_slots": metrics.get("max_waiting_slots"),
        "mean_selected_queue_count": metrics.get("mean_selected_queue_count"),
        "mean_served_packet_count": metrics.get("mean_served_packet_count"),
        "mean_primary_maxweight_objective": metrics.get("mean_primary_maxweight_objective"),
        "measurement_start_occupancy_packets": metadata.get("measurement_start_occupancy_packets"),
        "measurement_end_occupancy_packets": metadata.get("measurement_end_occupancy_packets"),
        "execution_peak_occupancy_packets": metadata.get("execution_peak_occupancy_packets"),
    }


def _temporary_path(output_dir: Path, final_name: str) -> tuple[Any, Path]:
    handle = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="",
        dir=output_dir,
        prefix=f".{final_name}.",
        suffix=".tmp",
        delete=False,
    )
    return handle, Path(handle.name)


def _audit_batch_summaries(results_root: Path) -> None:
    """Refuse a report that would silently exclude failed or unattempted runs."""

    failures: list[str] = []
    for path in sorted(results_root.rglob("batch_summary.json")):
        payload = _read_summary(path)
        total = payload.get("total_configs")
        successful = payload.get("successful_runs")
        failed = payload.get("failed_runs")
        completed = payload.get("completed_all_runs")
        if (
            isinstance(total, bool)
            or not isinstance(total, Integral)
            or isinstance(successful, bool)
            or not isinstance(successful, Integral)
            or isinstance(failed, bool)
            or not isinstance(failed, Integral)
            or not isinstance(completed, bool)
        ):
            failures.append(f"{path}: malformed batch completion fields")
            continue
        if int(failed) != 0 or not completed or int(successful) != int(total):
            failures.append(
                f"{path}: total_configs={int(total)}, successful_runs={int(successful)}, "
                f"failed_runs={int(failed)}, completed_all_runs={completed}"
            )
    if failures:
        raise ReportError(
            "batch completion audit failed; scientific reporting requires every run to succeed:\n  "
            + "\n  ".join(failures)
        )


def _report(args: argparse.Namespace) -> tuple[Path, Path, int, int]:
    results_root = args.results_dir.expanduser().resolve()
    if not results_root.is_dir():
        raise ReportError(f"results_dir is not a directory: {results_root}")
    _audit_batch_summaries(results_root)
    summaries = sorted(results_root.rglob("run_summary.json"))
    if not summaries:
        raise ReportError(f"no run_summary.json files found under {results_root}")

    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else results_root / "reports"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    standard_handle, standard_temporary = _temporary_path(output_dir, STANDARD_FILENAME)
    scientific_handle, scientific_temporary = _temporary_path(output_dir, SCIENTIFIC_FILENAME)
    scientific_rows = 0
    try:
        writer = csv.DictWriter(standard_handle, fieldnames=STANDARD_FIELDS)
        writer.writeheader()
        for summary_path in summaries:
            summary = _read_summary(summary_path)
            writer.writerow(_standard_row(results_root, summary_path, summary))

            run_dir = summary_path.parent
            resolved_path = run_dir / "resolved_config.yaml"
            observation_path = run_dir / "observations.sqlite3"
            if not resolved_path.is_file():
                raise ReportError(f"missing resolved config beside {summary_path}: {resolved_path}")
            if not observation_path.is_file():
                raise ReportError(f"missing compact observations beside {summary_path}: {observation_path}")

            config = load_config(resolved_path)
            if config.run.actual_seed is None:
                raise ReportError(f"resolved config does not record actual_seed: {resolved_path}")
            compiled = compile_arrival_spec(config, actual_seed=config.run.actual_seed)
            config_metadata = config.metadata
            with CompactObservationReader(observation_path) as reader:
                reader.integrity_check()
                targets = tuple(reader.iter_targets())
                blocks = tuple(reader.iter_blocks())
                if not targets or not blocks:
                    raise ReportError(f"observation database has no target blocks: {observation_path}")
                for target in targets:
                    arrival, certification = _arrival_law(config, compiled, target.queue_id)
                    for block in blocks:
                        analysis = analyze_pooled_target_block(
                            [reader],
                            target_id=target.target_id,
                            block_id=block.block_id,
                            cutoffs=args.cutoffs,
                            arrival=arrival,
                            stationary_interpretation=args.stationary_interpretation,
                        )
                        row = {
                            "run": summary_path.parent.relative_to(results_root).as_posix(),
                            "condition_id": config_metadata.get("condition_id"),
                            "campaign": config_metadata.get("campaign"),
                            "scenario_id": config_metadata.get("scenario_id"),
                            "target_id": target.target_id,
                            "queue_id": target.queue_id,
                            "block_id": block.block_id,
                            "block_start_slot": block.start_slot,
                            "block_stop_slot": block.stop_slot,
                            "cutoffs": args.cutoffs,
                            "stationary_interpretation_requested": args.stationary_interpretation,
                            "arrival_certification": certification,
                            "analysis": _compact_analysis(analysis),
                        }
                        scientific_handle.write(canonical_json_dumps(_json_ready(row)) + "\n")
                        scientific_rows += 1

        standard_handle.flush()
        scientific_handle.flush()
        os.fsync(standard_handle.fileno())
        os.fsync(scientific_handle.fileno())
        standard_handle.close()
        scientific_handle.close()
        standard_path = output_dir / STANDARD_FILENAME
        scientific_path = output_dir / SCIENTIFIC_FILENAME
        standard_temporary.replace(standard_path)
        scientific_temporary.replace(scientific_path)
        return standard_path, scientific_path, len(summaries), scientific_rows
    except Exception:
        standard_handle.close()
        scientific_handle.close()
        standard_temporary.unlink(missing_ok=True)
        scientific_temporary.unlink(missing_ok=True)
        raise


def main() -> int:
    args = _parser().parse_args()
    try:
        standard, scientific, runs, rows = _report(args)
    except (ReportError, SimError, ValidationError, OSError, TypeError, ValueError) as exc:
        sys.stderr.write(f"report failed: {exc}\n")
        return 1
    print(f"reported {runs} runs and {rows} target-block analyses")
    print(standard)
    print(scientific)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
