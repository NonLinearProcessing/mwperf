"""Deterministic performance smoke benchmark for the Patch-4 node scheduler.

The timings deliberately separate the dependency-free Blossom optimizer from
the public, domain-bound scheduler path.  They are release smoke checks, not
machine-comparison benchmarks: limits are intentionally generous so ordinary
CI load cannot turn a correct implementation into a flaky failure.
"""

from __future__ import annotations

import argparse
from collections.abc import Callable, Iterable, Sequence
from itertools import combinations
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter_ns
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers import build_scheduler_for_domain
from voqsim.schedulers._blossom import maximum_weight_matching
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.version import SIMULATOR_VERSION


_EXPECTED_VERSION = "19.0.0"
_SPARSE_VERTICES = 48
_DENSE_VERTICES = 24
_PARALLEL_LABELS = 4


def _median_ms(operation: Callable[[], Any], iterations: int) -> float:
    """Return a per-call median after deterministic untimed warmup calls."""

    for _ in range(5):
        operation()
    samples: list[int] = []
    for _ in range(iterations):
        started = perf_counter_ns()
        operation()
        samples.append(perf_counter_ns() - started)
    return statistics.median(samples) / 1_000_000.0


def _sparse_pairs(n_vertices: int) -> tuple[tuple[int, int], ...]:
    """Build a fixed sparse non-bipartite graph with a spanning cycle."""

    pairs: set[tuple[int, int]] = set()
    for u in range(n_vertices):
        for offset in (1, 2, 7):
            v = (u + offset) % n_vertices
            pairs.add((u, v) if u < v else (v, u))
    return tuple(sorted(pairs))


def _dense_pairs(n_vertices: int) -> tuple[tuple[int, int], ...]:
    return tuple(combinations(range(n_vertices), 2))


def _weighted_edges(
    pairs: Sequence[tuple[int, int]],
) -> tuple[tuple[int, int, int], ...]:
    """Use exact bigint weights resembling the scheduler's lex encoding."""

    edge_count = len(pairs)
    primary_scale = 1 << edge_count
    return tuple(
        (
            u,
            v,
            primary_scale * (((edge_index * 104_729 + 8_191) % 10_007) + 1)
            + (1 << (edge_count - 1 - edge_index)),
        )
        for edge_index, (u, v) in enumerate(pairs)
    )


def _assert_matching(
    n_vertices: int,
    pairs: Iterable[tuple[int, int]],
    matching: tuple[tuple[int, int], ...],
) -> None:
    available = set(pairs)
    used: set[int] = set()
    if not matching:
        raise RuntimeError("positive benchmark graph unexpectedly produced an empty matching")
    if tuple(sorted(matching)) != matching:
        raise RuntimeError("Blossom result is not canonical")
    for u, v in matching:
        if not (0 <= u < v < n_vertices) or (u, v) not in available:
            raise RuntimeError(f"Blossom returned structurally absent edge {(u, v)!r}")
        if u in used or v in used:
            raise RuntimeError("Blossom returned a node-conflicting matching")
        used.update((u, v))


def _core_case(
    n_vertices: int,
    pairs: tuple[tuple[int, int], ...],
    iterations: int,
) -> float:
    edges = _weighted_edges(pairs)

    def solve() -> tuple[tuple[int, int], ...]:
        return maximum_weight_matching(n_vertices, edges)

    _assert_matching(n_vertices, pairs, solve())
    return _median_ms(solve, iterations)


def _bound_scheduler(
    n_vertices: int,
    pairs: Sequence[tuple[int, int]],
    labels_per_pair: int,
) -> tuple[Any, QueueCatalog, dict[str, tuple[int, int]]]:
    queue_ids: list[str] = []
    links: list[dict[str, int | str]] = []
    pair_by_queue_id: dict[str, tuple[int, int]] = {}
    for edge_index, (u, v) in enumerate(pairs):
        for label_index in range(labels_per_pair):
            queue_id = f"q-{edge_index:04d}-{label_index}"
            # Reversed declarations exercise undirected-link canonicalization.
            declared_u, declared_v = (v, u) if label_index % 2 else (u, v)
            queue_ids.append(queue_id)
            links.append({"queue_id": queue_id, "u": declared_u, "v": declared_v})
            pair_by_queue_id[queue_id] = (u, v)

    catalog = QueueCatalog(queue_ids)
    constraint = {
        "vertices": list(range(n_vertices)),
        "links": links,
    }
    scheduler = build_scheduler_for_domain(
        "node_exclusive_max_weight",
        {"constraint": constraint},
        QueueSchedulerDomain(catalog, "node_exclusive_matching"),
    )
    return scheduler, catalog, pair_by_queue_id


def _positive_queue_lengths(n_queues: int) -> np.ndarray:
    return np.fromiter(
        (((queue_index * 37 + 11) % 101) + 1 for queue_index in range(n_queues)),
        dtype=np.int64,
        count=n_queues,
    )


def _assert_public_decision(
    scheduler: Any,
    catalog: QueueCatalog,
    pair_by_queue_id: dict[str, tuple[int, int]],
    q_len: np.ndarray,
    decision: ServiceDecision,
) -> None:
    checked = scheduler.validate_service_decision(decision, q_len)
    if checked != decision:
        raise RuntimeError("public scheduler returned a noncanonical decision")
    if not decision.selected_queue_ids:
        raise RuntimeError("positive public benchmark unexpectedly selected no queues")

    used_vertices: set[int] = set()
    for queue_id in decision.selected_queue_ids:
        u, v = pair_by_queue_id[str(queue_id)]
        if u in used_vertices or v in used_vertices:
            raise RuntimeError("public scheduler returned a node-conflicting decision")
        used_vertices.update((u, v))
        if q_len[catalog.index_of(queue_id)] <= 0:
            raise RuntimeError("public scheduler selected an empty queue")


def _scheduler_case(
    n_vertices: int,
    pairs: tuple[tuple[int, int], ...],
    labels_per_pair: int,
    iterations: int,
) -> tuple[float, Any, QueueCatalog, np.ndarray]:
    scheduler, catalog, pair_by_queue_id = _bound_scheduler(
        n_vertices,
        pairs,
        labels_per_pair,
    )
    q_len = _positive_queue_lengths(catalog.n_queues)
    rng = np.random.default_rng(174)

    def select() -> ServiceDecision:
        return scheduler.select_service(q_len, 0, rng)

    _assert_public_decision(
        scheduler,
        catalog,
        pair_by_queue_id,
        q_len,
        select(),
    )
    return _median_ms(select, iterations), scheduler, catalog, q_len


def _empty_case(
    scheduler: Any,
    catalog: QueueCatalog,
    iterations: int,
) -> float:
    q_len = np.zeros(catalog.n_queues, dtype=np.int64)
    rng = np.random.default_rng(174)

    def select() -> ServiceDecision:
        return scheduler.select_service(q_len, 0, rng)

    if select() != ServiceDecision.empty():
        raise RuntimeError("all-empty scheduler fast path returned nonempty service")
    return _median_ms(select, iterations)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run deterministic SwitchSim v19 Patch-4 performance smoke checks."
    )
    parser.add_argument("--iterations", type=int, default=51)
    args = parser.parse_args()
    if args.iterations < 1:
        parser.error("--iterations must be positive")
    if SIMULATOR_VERSION != _EXPECTED_VERSION:
        raise SystemExit(
            f"expected SwitchSim {_EXPECTED_VERSION}, found {SIMULATOR_VERSION}"
        )
    if any(name == "networkx" or name.startswith("networkx.") for name in sys.modules):
        raise SystemExit("Patch-4 benchmark unexpectedly loaded NetworkX")

    sparse_pairs = _sparse_pairs(_SPARSE_VERTICES)
    dense_pairs = _dense_pairs(_DENSE_VERTICES)

    observed = {
        "blossom_core_sparse_ms": _core_case(
            _SPARSE_VERTICES,
            sparse_pairs,
            args.iterations,
        ),
        "blossom_core_dense_ms": _core_case(
            _DENSE_VERTICES,
            dense_pairs,
            args.iterations,
        ),
    }
    sparse_scheduler_ms, _sparse_scheduler, _sparse_catalog, _sparse_q_len = (
        _scheduler_case(
            _SPARSE_VERTICES,
            sparse_pairs,
            1,
            args.iterations,
        )
    )
    dense_scheduler_ms, _dense_scheduler, _dense_catalog, _dense_q_len = (
        _scheduler_case(
            _DENSE_VERTICES,
            dense_pairs,
            1,
            args.iterations,
        )
    )
    parallel_scheduler_ms, parallel_scheduler, parallel_catalog, _parallel_q_len = (
        _scheduler_case(
            _DENSE_VERTICES,
            dense_pairs,
            _PARALLEL_LABELS,
            args.iterations,
        )
    )
    observed.update(
        {
            "node_scheduler_sparse_ms": sparse_scheduler_ms,
            "node_scheduler_dense_ms": dense_scheduler_ms,
            "node_scheduler_parallel_reduction_ms": parallel_scheduler_ms,
            "node_scheduler_all_empty_fast_path_ms": _empty_case(
                parallel_scheduler,
                parallel_catalog,
                args.iterations,
            ),
        }
    )

    # These are hang/regression sentinels, deliberately not tuned score gates.
    generous_environment_gates_ms = {
        "blossom_core_sparse_ms": 250.0,
        "blossom_core_dense_ms": 250.0,
        "node_scheduler_sparse_ms": 350.0,
        "node_scheduler_dense_ms": 350.0,
        "node_scheduler_parallel_reduction_ms": 500.0,
        "node_scheduler_all_empty_fast_path_ms": 25.0,
    }
    passed = all(
        observed[name] < limit
        for name, limit in generous_environment_gates_ms.items()
    )
    report = {
        "simulator_version": SIMULATOR_VERSION,
        "iterations": args.iterations,
        "instances": {
            "sparse": {
                "vertices": _SPARSE_VERTICES,
                "endpoint_pairs": len(sparse_pairs),
                "queue_labels": len(sparse_pairs),
            },
            "dense": {
                "vertices": _DENSE_VERTICES,
                "endpoint_pairs": len(dense_pairs),
                "queue_labels": len(dense_pairs),
            },
            "parallel": {
                "vertices": _DENSE_VERTICES,
                "endpoint_pairs": len(dense_pairs),
                "labels_per_pair": _PARALLEL_LABELS,
                "queue_labels": parallel_catalog.n_queues,
            },
        },
        "observed_median_ms": observed,
        "gates_ms": generous_environment_gates_ms,
        "result": "PASS" if passed else "FAIL",
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    if not passed:
        raise SystemExit("SwitchSim v19 Patch-4 performance smoke gate failed")
    print("SwitchSim v19 Patch-4 node-exclusive performance smoke gate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
