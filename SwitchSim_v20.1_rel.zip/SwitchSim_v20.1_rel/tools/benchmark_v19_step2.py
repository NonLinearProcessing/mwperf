#!/usr/bin/env python3
"""Measure v19 Step-2 runtime, peak RSS, and emitted output size."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.kernel import build_simulation


MODES = ("disabled", "gap_none", "exact_gap", "full_trace")
WORKLOADS = ("representative", "adversarial")


def _telemetry(mode: str, target_queue_ids: list[str]) -> dict[str, Any]:
    if mode not in MODES:
        raise ValueError(f"unsupported benchmark mode: {mode}")
    observation_enabled = mode in {"gap_none", "exact_gap"}
    gap_mode = "exact" if mode == "exact_gap" else "none"
    return {
        "format": "jsonl",
        "queue_snapshot": "dense",
        "include_packet_events": False,
        "include_scheduler_state": False,
        "write_slot_trace": mode == "full_trace",
        "observation": {
            "enabled": observation_enabled,
            "block_slots": 1_000,
            "targets": (
                [
                    {"queue_id": queue_id, "gap": gap_mode}
                    for queue_id in target_queue_ids
                ]
                if observation_enabled
                else []
            ),
        },
    }


def _run_config(*, slots: int, warmup_slots: int) -> dict[str, Any]:
    return {
        "seed": 190019,
        "slots": slots,
        "warmup_slots": warmup_slots,
        "termination": "fixed_slots",
    }


def _representative_config(
    mode: str,
    *,
    slots: int,
    warmup_slots: int,
) -> dict[str, Any]:
    allowed_edges = [
        [source, destination]
        for source in range(4)
        for destination in range(4)
        if source != destination
    ]
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": _run_config(slots=slots, warmup_slots=warmup_slots),
        "switch": {
            "kind": "legacy_crossbar",
            "n_ports": 4,
            "voq_capacity": "NoDrop",
            "allow_self_traffic": False,
        },
        "scheduler": {"name": "crossbar_max_weight", "params": {}},
        "arrival": {
            "family": "factorized_bernoulli",
            "allowed_edges": {"mode": "explicit", "edges": allowed_edges},
            "alphabet_constraint": "unrestricted",
            "lambda": 0.22,
        },
        "telemetry": _telemetry(mode, ["voq[0,1]"]),
        "metadata": {
            "benchmark_workload": "representative 4x4 crossbar",
        },
    }


def _adversarial_config(
    mode: str,
    *,
    slots: int,
    warmup_slots: int,
) -> dict[str, Any]:
    queue_ids = [f"q{index}" for index in range(12)]
    legacy_edges = [
        [source, destination]
        for source in range(4)
        for destination in range(4)
        if source != destination
    ]

    # An irregular connected graph exercises full-constraint MWIS class solves;
    # it is deliberately not a star, clique, interval surrogate, or other
    # topology with a special gap formula.
    conflict_indices: set[tuple[int, int]] = set()
    for index in range(12):
        for offset in (1, 3, 5):
            other = (index + offset) % 12
            left, right = sorted((index, other))
            conflict_indices.add((left, right))
    conflicts = [
        [queue_ids[left], queue_ids[right]]
        for left, right in sorted(conflict_indices)
    ]
    queues = [
        {"id": queue_id, "legacy_voq": legacy_edge}
        for queue_id, legacy_edge in zip(queue_ids, legacy_edges, strict=True)
    ]
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": _run_config(slots=slots, warmup_slots=warmup_slots),
        "switch": {
            "kind": "generalized",
            "queue_capacity": "NoDrop",
            "legacy_n_ports": 4,
            "queues": queues,
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": conflicts},
                "priority": queue_ids,
            },
        },
        "arrival": {
            "family": "factorized_bernoulli",
            "allowed_edges": {"mode": "explicit", "edges": legacy_edges},
            "alphabet_constraint": "unrestricted",
            "lambda": 0.08,
        },
        "telemetry": _telemetry(mode, queue_ids),
        "metadata": {
            "benchmark_workload": (
                "adversarial irregular 12-queue conflict graph; all targets exact"
            ),
        },
    }


def _config(
    workload: str,
    mode: str,
    *,
    slots: int,
    warmup_slots: int,
) -> dict[str, Any]:
    if workload == "representative":
        config = _representative_config(
            mode,
            slots=slots,
            warmup_slots=warmup_slots,
        )
    elif workload == "adversarial":
        config = _adversarial_config(
            mode,
            slots=slots,
            warmup_slots=warmup_slots,
        )
    else:
        raise ValueError(f"unsupported benchmark workload: {workload}")
    return deepcopy(config)


def _directory_bytes(root: Path) -> int:
    return sum(path.stat().st_size for path in root.rglob("*") if path.is_file())


def _run_once(
    workload: str,
    mode: str,
    *,
    slots: int,
    warmup_slots: int,
) -> dict[str, object]:
    with tempfile.TemporaryDirectory(
        prefix=f"switchsim-v19-{workload}-{mode}-"
    ) as temporary:
        output = Path(temporary) / "run"
        started = time.perf_counter()
        result = build_simulation(
            _config(
                workload,
                mode,
                slots=slots,
                warmup_slots=warmup_slots,
            ),
            output_dir=output,
        ).run()
        elapsed = time.perf_counter() - started
        return {
            "workload": workload,
            "mode": mode,
            "runtime_seconds": elapsed,
            "peak_rss_kib": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
            "output_bytes": _directory_bytes(output),
            "trace_bytes": (
                0
                if result.telemetry_path is None
                else result.telemetry_path.stat().st_size
            ),
            "observation_bytes": (
                0
                if result.observation_path is None
                else result.observation_path.stat().st_size
            ),
        }


def _child(args: argparse.Namespace) -> None:
    print(
        json.dumps(
            _run_once(
                args.workload,
                args.mode,
                slots=args.slots,
                warmup_slots=args.warmup_slots,
            )
        )
    )


def _median_fields(samples: list[dict[str, object]]) -> dict[str, float]:
    return {
        field: statistics.median(float(sample[field]) for sample in samples)
        for field in (
            "runtime_seconds",
            "peak_rss_kib",
            "output_bytes",
            "trace_bytes",
            "observation_bytes",
        )
    }


def _parent(args: argparse.Namespace) -> None:
    samples = {
        workload: {mode: [] for mode in MODES}
        for workload in WORKLOADS
    }
    script = Path(__file__).resolve()
    for _repeat in range(args.repeats):
        for workload in WORKLOADS:
            for mode in MODES:
                completed = subprocess.run(
                    [
                        sys.executable,
                        str(script),
                        "--child",
                        "--workload",
                        workload,
                        "--mode",
                        mode,
                        "--slots",
                        str(args.slots),
                        "--warmup-slots",
                        str(args.warmup_slots),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                samples[workload][mode].append(json.loads(completed.stdout))

    summary: dict[str, Any] = {
        "slots": args.slots,
        "warmup_slots": args.warmup_slots,
        "measurement_slots": args.slots - args.warmup_slots,
        "repeats": args.repeats,
        "workloads": {},
    }
    for workload in WORKLOADS:
        modes = {
            mode: _median_fields(samples[workload][mode])
            for mode in MODES
        }
        disabled = modes["disabled"]
        gap_none = modes["gap_none"]
        exact_gap = modes["exact_gap"]
        full_trace = modes["full_trace"]
        summary["workloads"][workload] = {
            "modes": modes,
            "ratios": {
                "gap_none_runtime_over_disabled": (
                    gap_none["runtime_seconds"] / disabled["runtime_seconds"]
                ),
                "exact_gap_runtime_over_disabled": (
                    exact_gap["runtime_seconds"] / disabled["runtime_seconds"]
                ),
                "exact_gap_peak_rss_over_disabled": (
                    exact_gap["peak_rss_kib"] / disabled["peak_rss_kib"]
                ),
                "exact_gap_output_over_full_trace": (
                    exact_gap["output_bytes"] / full_trace["output_bytes"]
                ),
            },
        }
    print(json.dumps(summary, indent=2, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--slots", type=int, default=10_000)
    parser.add_argument("--warmup-slots", type=int, default=2_000)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--workload",
        choices=WORKLOADS,
        default="representative",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--mode",
        choices=MODES,
        default="disabled",
        help=argparse.SUPPRESS,
    )
    args = parser.parse_args()
    if not 0 <= args.warmup_slots < args.slots:
        parser.error("require 0 <= warmup-slots < slots")
    if args.repeats < 1:
        parser.error("repeats must be positive")
    if args.child:
        _child(args)
    else:
        _parent(args)


if __name__ == "__main__":
    main()
