#!/usr/bin/env python3
"""Run focused v19 experiments from explicit JSON/YAML scientific inputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from voqsim.config import load_raw_config
from voqsim.experiments import (
    RealizedVectorArrivalTrace,
    four_target_campaign_from_mapping,
    run_paired_fanin_priority,
    separate_four_target_campaign,
)


def _load_mapping(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    with source.open("r", encoding="utf-8") as handle:
        if source.suffix.lower() == ".json":
            payload = json.load(handle)
        else:
            payload = yaml.safe_load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"{source} must contain a mapping")
    return payload


def _emit(payload: dict[str, Any], destination: str | None) -> None:
    rendered = json.dumps(payload, sort_keys=True, indent=2) + "\n"
    if destination is None:
        sys.stdout.write(rendered)
    else:
        Path(destination).write_text(rendered, encoding="utf-8")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    paired = subparsers.add_parser("paired-priority")
    paired.add_argument("--current-config", required=True)
    paired.add_argument("--reversed-config", required=True)
    paired.add_argument("--arrival-trace", required=True)
    paired.add_argument("--run-output-dir", required=True)
    paired.add_argument("--report")

    separation = subparsers.add_parser("separate-errors")
    separation.add_argument("--campaign", required=True)
    separation.add_argument("--report")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "paired-priority":
        trace = RealizedVectorArrivalTrace.from_mapping(_load_mapping(args.arrival_trace))
        report = run_paired_fanin_priority(
            load_raw_config(args.current_config),
            load_raw_config(args.reversed_config),
            trace,
            output_dir=args.run_output_dir,
        )
    else:
        campaigns = four_target_campaign_from_mapping(_load_mapping(args.campaign))
        report = separate_four_target_campaign(campaigns)
    _emit(report.to_dict(), args.report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
