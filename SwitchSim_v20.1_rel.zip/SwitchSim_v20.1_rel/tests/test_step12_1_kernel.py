from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.kernel import SimulationResult, Simulator, build_simulation


EXPECTED_STATIC_ARTIFACT_KEYS = {
    "resolved_config",
    "run_manifest",
    "flow_plan",
    "arrival_support",
    "service_model",
}


def _telemetry(*, write_slot_trace: bool = True) -> dict[str, object]:
    return {
        "format": "jsonl",
        "queue_snapshot": "dense",
        "include_packet_events": True,
        "include_scheduler_state": True,
        "write_slot_trace": write_slot_trace,
        "observation": {"enabled": False, "block_slots": None, "targets": []},
    }


def _base_config(arrival: dict[str, object], *, seed: int, slots: int) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": seed, "slots": slots, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 3,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": arrival,
        "telemetry": _telemetry(),
    }


def _deterministic_count_config() -> dict[str, object]:
    return _base_config(
        {
            "family": "iid_count_table",
            "outcomes": [
                {
                    "id": "paired",
                    "probability": 1,
                    "counts": [
                        {"queue_id": "q0", "count": 1},
                        {"queue_id": "q1", "count": 1},
                    ],
                }
            ],
        },
        seed=1234,
        slots=3,
    )


def _poisson_config(*, seed: int) -> dict[str, object]:
    return _base_config(
        {
            "family": "iid_independent_poisson",
            "rates": {
                "default": 0,
                "overrides": [
                    {"queue_id": "q0", "rate": Decimal("1.25")},
                    {"queue_id": "q1", "rate": Decimal("0.75")},
                ],
            },
        },
        seed=seed,
        slots=8,
    )


def _markov_seed_minus_one_config() -> dict[str, object]:
    return _base_config(
        {
            "family": "markov_count_kernel",
            "states": ["off", "on"],
            "outcomes": [
                {"id": "idle", "counts": []},
                {"id": "hit", "counts": [{"queue_id": "q0", "count": 2}]},
            ],
            "kernel": [
                {"state": "off", "outcome_id": "idle", "next_state": "off", "probability": Decimal("0.55")},
                {"state": "off", "outcome_id": "hit", "next_state": "on", "probability": Decimal("0.45")},
                {"state": "on", "outcome_id": "hit", "next_state": "on", "probability": Decimal("0.70")},
                {"state": "on", "outcome_id": "idle", "next_state": "off", "probability": Decimal("0.30")},
            ],
            "initial": {
                "distribution": {
                    "off": Decimal("0.35"),
                    "on": Decimal("0.65"),
                }
            },
        },
        seed=-1,
        slots=6,
    )


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_build_simulation_runs_count_runtime_and_writes_replay_bundle(tmp_path) -> None:
    simulator = build_simulation(_deterministic_count_config(), output_dir=tmp_path / "run")
    assert isinstance(simulator, Simulator)
    assert simulator.actual_seed == 1234
    assert simulator.requested_seed == 1234
    assert set(simulator.static_artifacts) == EXPECTED_STATIC_ARTIFACT_KEYS
    assert all(path.exists() for path in simulator.static_artifacts.values())

    result = simulator.run()
    assert isinstance(result, SimulationResult)
    assert result.actual_seed == 1234
    assert result.slots_run == 3
    assert result.telemetry_path.exists()
    assert result.summary_path.exists()

    records = _read_jsonl(result.telemetry_path)
    assert [record["slot"] for record in records] == [0, 1, 2]
    assert records[0]["arrival_outcome_id"] == "paired"
    assert records[0]["arrivals"]["offered"] == [
        {"queue_id": "q0", "count": 1},
        {"queue_id": "q1", "count": 1},
    ]
    assert records[1]["completions"][0]["queue_id"] == "q0"

    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
    assert summary["metrics"]["slots_observed"] == 3
    assert summary["metrics"]["offered_packets"] == 6
    assert summary["metrics"]["completed_packets"] == 2
    assert summary["metadata"]["schema_version"] == CONFIG_SCHEMA_VERSION
    assert summary["metadata"]["scheduler_algorithm_id"] == "mwis_branch_memo_exact"


def test_summary_only_mode_skips_slot_trace_and_preserves_metrics(tmp_path) -> None:
    config = _deterministic_count_config()
    config["telemetry"] = _telemetry(write_slot_trace=False)

    result = build_simulation(config, output_dir=tmp_path / "summary-only").run()

    assert result.telemetry_path is None
    assert not (result.output_dir / "telemetry.jsonl").exists()
    assert result.summary_path.exists()
    assert result.to_dict()["slot_trace_written"] is False
    assert "telemetry_path" not in result.to_dict()

    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
    assert summary["metrics"]["offered_packets"] == 6
    assert summary["metrics"]["completed_packets"] == 2
    assert summary["metadata"]["write_slot_trace"] is False


def test_same_fixed_seed_produces_identical_poisson_trace_and_artifacts(tmp_path) -> None:
    config = _poisson_config(seed=4321)
    result_a = build_simulation(config, output_dir=tmp_path / "run-a").run()
    result_b = build_simulation(config, output_dir=tmp_path / "run-b").run()

    assert result_a.actual_seed == result_b.actual_seed == 4321
    for filename in (
        "telemetry.jsonl",
        "run_summary.json",
        "flow_plan.json",
        "arrival_support.json",
        "service_model.json",
        "run_manifest.json",
        "resolved_config.yaml",
    ):
        assert (result_a.output_dir / filename).read_bytes() == (
            result_b.output_dir / filename
        ).read_bytes()


def test_seed_minus_one_replay_preserves_arrival_initial_and_slot_streams(tmp_path) -> None:
    first = build_simulation(_markov_seed_minus_one_config(), output_dir=tmp_path / "first")
    first_result = first.run()
    manifest = json.loads((first.output_dir / "run_manifest.json").read_text(encoding="utf-8"))
    assert manifest["requested_seed"] == -1
    assert manifest["actual_seed"] == first_result.actual_seed

    second = build_simulation(
        first.output_dir / "resolved_config.yaml",
        output_dir=tmp_path / "replay",
    )
    second_result = second.run()

    assert second_result.actual_seed == first_result.actual_seed
    assert second_result.requested_seed == -1
    assert second_result.telemetry_path.read_bytes() == first_result.telemetry_path.read_bytes()
    assert second_result.summary_path.read_bytes() == first_result.summary_path.read_bytes()
