from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.events import ArrivalAttempt
from voqsim.kernel import build_simulation
from voqsim.packet import Packet
from voqsim.queues import QueueBank, QueueCatalog, QueueSpec, ServiceDecision
from voqsim.schedulers import (
    QueueSchedulerBase,
    SchedulerCapabilities,
    register_scheduler,
    unregister_scheduler,
)


TEST_SCHEDULER_NAME = "test_select_all_nonempty_queues"


class _SelectAllNonemptyQueuesScheduler(QueueSchedulerBase):
    """Unconstrained queue-vector fixture that exposes kernel validation calls."""

    def __init__(self, params=None) -> None:
        super().__init__(params=params)
        self.validation_calls = 0

    @property
    def name(self) -> str:
        return TEST_SCHEDULER_NAME

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog = self.scheduler_domain.queue_catalog
        return ServiceDecision(
            tuple(
                catalog.queue_id_at(index)
                for index, occupancy in enumerate(vector)
                if int(occupancy) > 0
            )
        )

    def validate_service_decision(self, decision, q_len) -> ServiceDecision:
        self.validation_calls += 1
        return super().validate_service_decision(decision, q_len)


@pytest.fixture
def registered_generic_scheduler():
    register_scheduler(
        TEST_SCHEDULER_NAME,
        _SelectAllNonemptyQueuesScheduler,
        capabilities=SchedulerCapabilities.queue_vector(("unconstrained",)),
        replace=True,
    )
    try:
        yield
    finally:
        unregister_scheduler(TEST_SCHEDULER_NAME)


def _queue_attempt(
    *,
    packet_id: int,
    flow_id: int,
    queue_id: int | str,
    slot: int = 0,
) -> ArrivalAttempt:
    return ArrivalAttempt.from_packet(
        Packet.for_queue(
            packet_id=packet_id,
            flow_id=flow_id,
            queue_id=queue_id,
            generation_slot=slot,
        )
    )


def _canonical_runtime_config() -> dict[str, object]:
    return {
        "schema_version": "4.0.0",
        "run": {"seed": 17001, "slots": 2, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 4,
            "queues": [{"id": "left"}, {"id": "right"}],
        },
        "scheduler": {"name": TEST_SCHEDULER_NAME, "params": {}},
        "arrival": {
            "family": "iid_count_table",
            "outcomes": [
                {
                    "id": "both",
                    "counts": [
                        {"queue_id": "left", "count": 1},
                        {"queue_id": "right", "count": 1},
                    ],
                    "probability": Decimal(1),
                }
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "include_scheduler_state": False,
            "write_slot_trace": True,
            "observation": {"enabled": False, "block_slots": None, "targets": []},
        },
    }


def _preloaded_bank() -> QueueBank:
    catalog = QueueCatalog((QueueSpec("ready"), QueueSpec("also_ready"), QueueSpec("empty")))
    bank = QueueBank(catalog, queue_capacity=4)
    decisions = bank.enqueue_or_drop(
        (
            _queue_attempt(packet_id=1, flow_id=0, queue_id="ready"),
            _queue_attempt(packet_id=2, flow_id=1, queue_id="also_ready"),
        ),
        slot=0,
    )
    assert all(decision.accepted for decision in decisions)
    return bank


def _unchecked_duplicate_decision(queue_id: int | str) -> ServiceDecision:
    decision = object.__new__(ServiceDecision)
    object.__setattr__(decision, "selected_queue_ids", (queue_id, queue_id))
    return decision


def test_schema4_runtime_uses_native_queue_scheduler_and_service_decisions(
    tmp_path: Path,
    registered_generic_scheduler,
) -> None:
    simulator = build_simulation(
        _canonical_runtime_config(),
        output_dir=tmp_path / "generalized",
    )
    result = simulator.run()

    assert isinstance(simulator.switch, QueueBank)
    assert simulator.switch.catalog.queue_ids == ("left", "right")
    assert simulator.scheduler.validation_calls == 2
    assert result.summary.to_dict()["metrics"]["completed_packets"] == 2

    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]
    assert records[0]["schedule"]["selected_queue_ids"] == []
    assert records[1]["schedule"]["selected_queue_ids"] == ["left", "right"]
    assert records[1]["schedule"]["algorithm_id"] == TEST_SCHEDULER_NAME
    assert "optimizer_id" not in records[1]["schedule"]
    assert len(records[1]["departures"]) == 2


@pytest.mark.parametrize(
    "bad_decision,exception_type",
    [
        (("ready",), ScheduleError),
        (ServiceDecision(("ready", "outside")), ScheduleError),
        (ServiceDecision(("ready", "empty")), ScheduleError),
        (_unchecked_duplicate_decision("ready"), ScheduleError),
    ],
)
def test_queue_bank_rejects_invalid_service_decisions_atomically(
    bad_decision,
    exception_type,
) -> None:
    bank = _preloaded_bank()
    before = bank.queue_lengths()
    before_packet_ids = tuple(tuple(packet.packet_id for packet in queue) for queue in bank.queues)

    with pytest.raises(exception_type):
        bank.service(bad_decision, slot=1)

    np.testing.assert_array_equal(bank.queue_lengths(), before)
    assert tuple(tuple(packet.packet_id for packet in queue) for queue in bank.queues) == before_packet_ids
    bank.assert_internal_consistency()


def test_queue_bank_same_slot_rejection_is_atomic_and_empty_decision_is_valid() -> None:
    bank = _preloaded_bank()
    before = bank.queue_lengths()

    with pytest.raises(ValidationError):
        bank.service(ServiceDecision(("ready", "also_ready")), slot=0)
    np.testing.assert_array_equal(bank.queue_lengths(), before)

    assert bank.validate_service_decision(ServiceDecision.empty()) == ServiceDecision.empty()
    assert bank.service(ServiceDecision.empty(), slot=1) == ()
    np.testing.assert_array_equal(bank.queue_lengths(), before)


def test_queue_bank_preserves_same_queue_count_multiplicity_and_capacity_order() -> None:
    catalog = QueueCatalog((QueueSpec("burst"),))
    bank = QueueBank(catalog, queue_capacity=2)
    attempts = tuple(
        _queue_attempt(packet_id=packet_id, flow_id=0, queue_id="burst")
        for packet_id in range(3)
    )

    decisions = bank.enqueue_or_drop(attempts, slot=0)

    assert [decision.accepted for decision in decisions] == [True, True, False]
    assert [decision.queue_occupancy_before for decision in decisions] == [0, 1, 2]
    assert [decision.queue_occupancy_after for decision in decisions] == [1, 2, 2]
    assert tuple(packet.packet_id for packet in bank.queues[0]) == (0, 1)
    np.testing.assert_array_equal(bank.queue_lengths(), np.array([2], dtype=np.int64))
    bank.assert_internal_consistency()
