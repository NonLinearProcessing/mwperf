from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path

import pytest

from voqsim.config import (
    load_config,
    load_raw_config,
    resolve_config,
    resolved_config_to_dict,
)
from voqsim.errors import ValidationError
from voqsim.kernel import build_simulation
from voqsim.manifest import build_service_model, hash_resolved_config, hash_service_model
from voqsim.schedulers import (
    NodeExclusiveMaxWeightScheduler,
    build_scheduler,
    canonical_scheduler_config,
    resolve_scheduler_spec,
    scheduler_capabilities,
    scheduler_class_for_name,
    scheduler_supports_service,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"
NODE_EXAMPLE = CONFIG_DIR / "schema3_node_exclusive_max_weight.yaml"


def _config_hash(config) -> str:
    return hash_resolved_config(
        resolved_config_to_dict(config, actual_seed=config.run.seed)
    )


def _service_hash(config) -> str:
    return hash_service_model(build_service_model(config))


def _node_raw() -> dict[str, object]:
    return deepcopy(dict(load_raw_config(NODE_EXAMPLE)))


def test_node_scheduler_registry_class_capabilities_and_effective_params() -> None:
    raw = _node_raw()
    supplied_params = raw["scheduler"]["params"]
    expected_params = {
        "constraint": {
            "vertices": ["a", "b", "c", "d", "e"],
            "links": [
                {"queue_id": "ab-heavy", "u": "a", "v": "b"},
                {"queue_id": "ab-parallel", "u": "a", "v": "b"},
                {"queue_id": "bc", "u": "b", "v": "c"},
                {"queue_id": "ca", "u": "a", "v": "c"},
                {"queue_id": "de", "u": "d", "v": "e"},
            ],
        },
        "priority": ["ab-heavy", "de", "ab-parallel", "bc", "ca"],
    }

    scheduler = build_scheduler("node_exclusive_max_weight", supplied_params)
    spec = resolve_scheduler_spec("node_exclusive_max_weight", supplied_params)

    assert isinstance(scheduler, NodeExclusiveMaxWeightScheduler)
    assert scheduler_class_for_name("node_exclusive_max_weight") is NodeExclusiveMaxWeightScheduler
    assert scheduler.name == "node_exclusive_max_weight"
    assert scheduler.optimizer_id == "edmonds_blossom_exact"
    assert scheduler.params == scheduler.effective_params == expected_params
    assert spec.name == scheduler.name
    assert spec.params == expected_params
    assert spec.service_family == "node_exclusive_matching"
    assert spec.capabilities == scheduler_capabilities("node_exclusive_max_weight")
    assert spec.capabilities.to_dict() == {
        "input_kind": "queue_vector",
        "output_kind": "service_decision",
        "service_families": ["node_exclusive_matching"],
    }
    assert scheduler_supports_service(
        "node_exclusive_max_weight", "node-exclusive-matching"
    )
    assert not scheduler_supports_service(
        "node_exclusive_max_weight", "crossbar_matching"
    )
    assert canonical_scheduler_config(
        "node_exclusive_max_weight", supplied_params
    ) == {"name": "node_exclusive_max_weight", "params": expected_params}


def test_constraint_reordering_and_endpoint_orientation_are_hash_invariant() -> None:
    original = _node_raw()
    reordered = _node_raw()
    constraint = reordered["scheduler"]["params"]["constraint"]
    constraint["vertices"].reverse()
    constraint["links"] = [
        {"queue_id": link["queue_id"], "u": link["v"], "v": link["u"]}
        for link in reversed(constraint["links"])
    ]

    first = resolve_config(original)
    second = resolve_config(reordered)

    assert resolved_config_to_dict(first) == resolved_config_to_dict(second)
    assert _config_hash(first) == _config_hash(second)
    assert build_service_model(first) == build_service_model(second)
    assert _service_hash(first) == _service_hash(second)


def test_priority_changes_config_hash_but_not_physical_service_hash() -> None:
    original = _node_raw()
    reversed_priority = _node_raw()
    reversed_priority["scheduler"]["params"]["priority"].reverse()

    baseline = resolve_config(original)
    policy_variant = resolve_config(reversed_priority)

    assert baseline.scheduler.params["priority"] != policy_variant.scheduler.params["priority"]
    assert _config_hash(baseline) != _config_hash(policy_variant)
    assert build_service_model(baseline) == build_service_model(policy_variant)
    assert _service_hash(baseline) == _service_hash(policy_variant)


def test_isolated_vertex_and_link_topology_changes_affect_service_hash() -> None:
    baseline = resolve_config(_node_raw())

    isolated_raw = _node_raw()
    isolated_raw["scheduler"]["params"]["constraint"]["vertices"].append(
        "isolated"
    )
    isolated = resolve_config(isolated_raw)

    relinked_raw = _node_raw()
    links = relinked_raw["scheduler"]["params"]["constraint"]["links"]
    de_link = next(link for link in links if link["queue_id"] == "de")
    de_link["u"] = "c"
    de_link["v"] = "e"
    relinked = resolve_config(relinked_raw)

    baseline_hash = _service_hash(baseline)
    assert _service_hash(isolated) != baseline_hash
    assert _service_hash(relinked) != baseline_hash
    assert _service_hash(isolated) != _service_hash(relinked)


def test_node_scheduler_rejects_a_constraint_outside_the_queue_catalog_before_output_mutation(
    tmp_path: Path,
) -> None:
    raw = deepcopy(
        dict(
            load_raw_config(
                CONFIG_DIR / "4x4_iid_table_crossbar_max_weight_exact.yaml"
            )
        )
    )
    raw["scheduler"] = {
        "name": "node_exclusive_max_weight",
        "params": {
            "constraint": {
                "vertices": [0, 1],
                "links": [{"queue_id": "probe", "u": 0, "v": 1}],
            },
            "priority": ["probe"],
        },
    }
    sentinel = tmp_path / "sentinel.txt"
    sentinel.write_text("unchanged", encoding="utf-8")
    output_dir = tmp_path / "must-not-exist"
    before = {path.name: path.read_bytes() for path in tmp_path.iterdir() if path.is_file()}

    with pytest.raises(
        ValidationError,
        match="catalog queue",
    ):
        build_simulation(raw, output_dir=output_dir)

    assert not output_dir.exists()
    assert {path.name: path.read_bytes() for path in tmp_path.iterdir() if path.is_file()} == before


def test_supplied_node_example_runs_with_generic_node_exclusive_telemetry(
    tmp_path: Path,
) -> None:
    config = load_config(NODE_EXAMPLE)
    output_dir = tmp_path / "node-example"
    result = build_simulation(config, output_dir=output_dir).run()
    assert result.telemetry_path is not None
    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]

    assert result.slots_run == config.run.slots == 8
    assert len(records) == 8
    assert [record["schedule"]["selected_queue_ids"] for record in records] == [
        [],
        ["ab-heavy", "de"],
        ["ab-heavy", "de"],
        ["ab-heavy", "de"],
        ["ab-heavy", "de"],
        ["ab-heavy", "de"],
        ["ab-parallel"],
        ["ab-heavy"],
    ]
    assert {
        (record["schedule"]["format"], record["schedule"]["scheduler_id"], record["schedule"]["optimizer_id"])
        for record in records
    } == {
        (
            "selected_queue_ids",
            "node_exclusive_max_weight",
            "edmonds_blossom_exact",
        )
    }

    # The two node-exclusive links are disjoint, so the generalized service
    # family correctly permits their simultaneous departure in slots 1--5.
    assert [departure["queue_id"] for departure in records[1]["departures"]] == [
        "ab-heavy",
        "de",
    ]

    metrics = result.summary.to_dict()["metrics"]
    assert metrics["offered_packets"] == 15
    assert metrics["admitted_packets"] == 15
    assert metrics["dropped_packets"] == 0
    assert metrics["completed_packets"] == 12
    assert metrics["schedule"]["scheduler_ids"] == {
        "node_exclusive_max_weight": 8
    }
    assert metrics["schedule"]["optimizer_ids"] == {
        "edmonds_blossom_exact": 8
    }

    service_model = json.loads(
        (output_dir / "service_model.json").read_text(encoding="utf-8")
    )
    manifest = json.loads(
        (output_dir / "run_manifest.json").read_text(encoding="utf-8")
    )
    assert service_model["service"]["family"] == "node_exclusive_matching"
    assert "priority" not in service_model["service"]
    assert manifest["scheduler_name"] == "node_exclusive_max_weight"
    assert manifest["scheduler_params"]["priority"] == [
        "ab-heavy",
        "de",
        "ab-parallel",
        "bc",
        "ca",
    ]
    assert manifest["service_model_hash"] == hash_service_model(service_model)
