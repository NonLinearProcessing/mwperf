from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from voqsim.batch import BATCH_MANIFEST_FILENAME, BATCH_SUMMARY_FILENAME
from voqsim.cli import main

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"


def _load_yaml(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


def _expected_run_artifacts() -> set[str]:
    return {
        "telemetry.jsonl",
        "run_summary.json",
        "run_manifest.json",
        "resolved_config.yaml",
        "flow_plan.json",
        "arrival_support.json",
        "service_model.json",
    }


def _expected_summary_only_artifacts() -> set[str]:
    return {
        "run_summary.json",
        "run_manifest.json",
        "resolved_config.yaml",
        "flow_plan.json",
        "arrival_support.json",
        "service_model.json",
    }


def test_batch_runner_runs_all_valid_configs_in_relative_order_and_writes_unique_run_dirs(tmp_path: Path) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"

    config_a = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    config_b = _load_yaml(CONFIG_DIR / "4x4_iid_table_islip_canonical.yaml")

    _write_yaml(batch_dir / "group_a" / "first.yaml", config_a)
    _write_yaml(batch_dir / "group_b" / "nested" / "second.yaml", config_b)

    exit_code = main(["--batch-dir", str(batch_dir), "--output-root", str(output_root), "--quiet"])
    assert exit_code == 0

    first_out = output_root / "runs" / "group_a" / "first"
    second_out = output_root / "runs" / "group_b" / "nested" / "second"
    assert _expected_run_artifacts().issubset({path.name for path in first_out.iterdir()})
    assert _expected_run_artifacts().issubset({path.name for path in second_out.iterdir()})

    manifest = json.loads((output_root / BATCH_MANIFEST_FILENAME).read_text(encoding="utf-8"))
    summary = json.loads((output_root / BATCH_SUMMARY_FILENAME).read_text(encoding="utf-8"))
    assert [item["relative_path"] for item in manifest["prepared_runs"]] == [
        "group_a/first.yaml",
        "group_b/nested/second.yaml",
    ]
    assert summary["total_configs"] == 2
    assert summary["attempted_runs"] == 2
    assert summary["successful_runs"] == 2
    assert summary["failed_runs"] == 0
    assert summary["completed_all_runs"] is True


def test_batch_runner_no_slot_trace_applies_summary_only_mode_to_all_runs(tmp_path: Path) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"

    config_a = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    config_b = _load_yaml(CONFIG_DIR / "4x4_iid_table_islip_canonical.yaml")

    _write_yaml(batch_dir / "group_a" / "first.yaml", config_a)
    _write_yaml(batch_dir / "group_b" / "second.yaml", config_b)

    exit_code = main(["--batch-dir", str(batch_dir), "--output-root", str(output_root), "--no-slot-trace", "--quiet"])
    assert exit_code == 0

    first_out = output_root / "runs" / "group_a" / "first"
    second_out = output_root / "runs" / "group_b" / "second"
    assert _expected_summary_only_artifacts().issubset({path.name for path in first_out.iterdir()})
    assert _expected_summary_only_artifacts().issubset({path.name for path in second_out.iterdir()})
    assert not (first_out / "telemetry.jsonl").exists()
    assert not (second_out / "telemetry.jsonl").exists()

    summary = json.loads((output_root / BATCH_SUMMARY_FILENAME).read_text(encoding="utf-8"))
    assert summary["successful_runs"] == 2
    assert all("telemetry_path" not in item for item in summary["results"])
    for run_dir in (first_out, second_out):
        resolved = _load_yaml(run_dir / "resolved_config.yaml")
        assert resolved["telemetry"]["write_slot_trace"] is False


def test_batch_runner_preflight_rejects_invalid_config_before_any_runs_start(tmp_path: Path, capsys) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"

    valid_cfg = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    invalid_cfg = _load_yaml(CONFIG_DIR / "4x4_iid_table_islip_canonical.yaml")
    invalid_cfg["scheduler"]["name"] = "definitely_not_a_scheduler"

    _write_yaml(batch_dir / "ok.yaml", valid_cfg)
    _write_yaml(batch_dir / "bad.yaml", invalid_cfg)

    exit_code = main(["--batch-dir", str(batch_dir), "--output-root", str(output_root), "--quiet"])
    assert exit_code == 2
    stderr = capsys.readouterr().err
    assert "batch preflight failed" in stderr
    assert "bad.yaml" in stderr
    assert not (output_root / "runs").exists()


def test_batch_runner_ignores_per_config_output_dir_and_uses_batch_output_root(tmp_path: Path) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"
    ignored_dir = tmp_path / "ignored_output"

    config = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    config.setdefault("run", {})["output_dir"] = str(ignored_dir)
    _write_yaml(batch_dir / "sub" / "override.yaml", config)

    exit_code = main(["--batch-dir", str(batch_dir), "--output-root", str(output_root), "--quiet"])
    assert exit_code == 0

    effective_output = output_root / "runs" / "sub" / "override"
    assert effective_output.exists()
    assert _expected_run_artifacts().issubset({path.name for path in effective_output.iterdir()})
    assert not ignored_dir.exists()


def test_batch_runner_continue_on_error_runs_later_configs_and_returns_exit_one(
    tmp_path: Path,
    monkeypatch,
) -> None:
    import voqsim.batch as batch_mod

    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"

    config_a = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    config_b = _load_yaml(CONFIG_DIR / "4x4_iid_table_islip_canonical.yaml")

    _write_yaml(batch_dir / "a.yaml", config_a)
    _write_yaml(batch_dir / "b.yaml", config_b)

    real_build_simulation = batch_mod.build_simulation
    failed_once = {"done": False}

    def flaky_build_simulation(config, *, output_dir=None, include_arrival_support=True):
        if not failed_once["done"]:
            failed_once["done"] = True
            raise RuntimeError("synthetic runtime failure")
        return real_build_simulation(config, output_dir=output_dir, include_arrival_support=include_arrival_support)

    monkeypatch.setattr(batch_mod, "build_simulation", flaky_build_simulation)

    exit_code = main(
        [
            "--batch-dir",
            str(batch_dir),
            "--output-root",
            str(output_root),
            "--continue-on-error",
            "--quiet",
        ]
    )
    assert exit_code == 1

    summary = json.loads((output_root / BATCH_SUMMARY_FILENAME).read_text(encoding="utf-8"))
    assert summary["total_configs"] == 2
    assert summary["attempted_runs"] == 2
    assert summary["failed_runs"] == 1
    assert summary["successful_runs"] == 1
    assert summary["completed_all_runs"] is True

    second_output = output_root / "runs" / "b"
    assert second_output.exists()
    assert _expected_run_artifacts().issubset({path.name for path in second_output.iterdir()})


def test_batch_runner_detects_output_collisions_from_same_relative_stem(tmp_path: Path, capsys) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"

    config = _load_yaml(CONFIG_DIR / "2x2_iid_table_random_maximal.yaml")
    _write_yaml(batch_dir / "dup.yaml", config)
    (batch_dir / "dup.json").write_text(json.dumps(config), encoding="utf-8")

    exit_code = main(["--batch-dir", str(batch_dir), "--output-root", str(output_root), "--quiet"])
    assert exit_code == 2
    stderr = capsys.readouterr().err
    assert "batch preflight failed" in stderr
    assert "dup.yaml" in stderr or "dup.json" in stderr
    assert not (output_root / "runs").exists()
