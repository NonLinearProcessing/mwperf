from __future__ import annotations

from fractions import Fraction

import pytest

from voqsim.analysis import ArrivalMarginal, analyze_pooled_target_block, pool_target_block
from voqsim.errors import ValidationError
from voqsim.telemetry import (
    MASS_BINARY64_LATTICE,
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    WeightedBoundarySample,
    WeightedTargetSample,
    binary64_lattice_numerator,
)


def _weighted_metadata(*, ensemble_id: int = 0) -> dict[str, object]:
    return {
        "actual_seed": 180181,
        "ensemble_id": ensemble_id,
        "slot_convention": "pre_service_N; service; arrivals; post_arrival_N_prime",
        "initial_condition": "weighted_population_supplied_by_sampler",
        "random_streams": {"arrival": "seeded external fixture stream"},
        "buffer_policy": {"mode": "NoDrop", "drop_behavior": "fail_on_allocation_error"},
        "weighting": {"mass": "normalized_binary64", "instant": "production_decision"},
        "resampling": {"algorithm": "external_test_fixture", "instant": "after_transition"},
        "scientific_config": {
            "arrival": {"family": "iid_fixture", "pmf": {"0": 1.0}},
            "scheduler": {"name": "fixture", "tie_policy": "fixture"},
            "switch": {"kind": "fixture", "queue_capacity": "NoDrop"},
        },
    }


def _write_weighted_fixture(path, *, metadata=None) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=2,
        targets=[ObservationTarget("target", "q", MASS_BINARY64_LATTICE)],
        unit_kind="weighted_ensemble",
        metadata=_weighted_metadata() if metadata is None else metadata,
    )
    recorder.record_weighted_boundary(
        0,
        [
            WeightedBoundarySample.from_binary64(target_id="target", backlog=0, weight=0.5),
            WeightedBoundarySample.from_binary64(target_id="target", backlog=2, weight=0.5),
        ],
    )
    recorder.record_weighted_slot(
        0,
        [
            WeightedTargetSample.from_binary64(target_id="target", backlog=0, weight=0.5, served=0),
            WeightedTargetSample.from_binary64(target_id="target", backlog=2, weight=0.5, served=1),
        ],
    )
    recorder.record_weighted_slot(
        1,
        [
            WeightedTargetSample.from_binary64(target_id="target", backlog=0, weight=0.5, served=0),
            WeightedTargetSample.from_binary64(target_id="target", backlog=1, weight=0.5, served=1),
        ],
    )
    recorder.record_weighted_boundary(
        2,
        [WeightedBoundarySample.from_binary64(target_id="target", backlog=0, weight=1.0)],
    )
    half = binary64_lattice_numerator(0.5)
    one = binary64_lattice_numerator(1.0)
    recorder.record_supplied_response(
        block_id=0,
        target_id="target",
        coefficient_kind="mu",
        coefficient_index=1,
        value=1.0,
        status="ok",
        exposure_numerator=half,
        served_numerator=half,
    )
    recorder.record_supplied_response(
        block_id=0,
        target_id="target",
        coefficient_kind="mu",
        coefficient_index=2,
        value=1.0,
        status="ok",
        exposure_numerator=half,
        served_numerator=half,
    )
    recorder.record_supplied_response(
        block_id=0,
        target_id="target",
        coefficient_kind="tail",
        coefficient_index=0,
        value=1.0,
        status="ok",
        exposure_numerator=one,
        served_numerator=one,
    )
    recorder.complete()
    recorder.close()


def test_weighted_artifact_pools_and_reconstructs_zero_innovation(tmp_path) -> None:
    path = tmp_path / "weighted.sqlite3"
    _write_weighted_fixture(path)

    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=ArrivalMarginal.from_pmf({0: 1}),
        )
        supplied = tuple(reader.iter_supplied_responses(target_id="target"))

    scale = binary64_lattice_numerator(1.0)
    assert report.pooled.exposure == report.pooled.decision_mass == 2 * scale
    assert report.pooled.backlog_mean == Fraction(3, 4)
    assert report.pooled.departure_mean == Fraction(1, 2)
    assert report.finite_windows[0].eta_1 == Fraction(-1, 2)
    assert report.finite_windows[0].eta_2 == -1
    assert report.innovations[0].backlog == 0
    assert report.innovations[0].backlog_square == 0
    assert report.innovations[0].hinge == 0
    assert {(row.coefficient_kind, row.coefficient_index) for row in supplied} == {
        ("mu", 1),
        ("mu", 2),
        ("tail", 0),
    }


def test_weighted_pooling_requires_complete_scientific_metadata(tmp_path) -> None:
    path = tmp_path / "weighted.sqlite3"
    _write_weighted_fixture(path, metadata={"ensemble_id": 0})

    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match="required scientific metadata"):
            pool_target_block(
                [reader],
                target_id="target",
                block_id=0,
                cutoffs=[0],
            )


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("slot_convention", None),
        ("initial_condition", ""),
        ("random_streams", {}),
        ("buffer_policy", None),
        ("weighting", {}),
        ("resampling", None),
        ("scientific_config", {"arrival": None, "scheduler": None, "switch": None}),
    ],
)
def test_weighted_pooling_rejects_empty_scientific_metadata(tmp_path, key, value) -> None:
    path = tmp_path / "weighted.sqlite3"
    metadata = _weighted_metadata()
    metadata[key] = value
    _write_weighted_fixture(path, metadata=metadata)

    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match="required scientific metadata"):
            pool_target_block(
                [reader],
                target_id="target",
                block_id=0,
                cutoffs=[0],
            )
