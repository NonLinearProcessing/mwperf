from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from voqsim.batch import discover_config_files
from voqsim.config import CONFIG_SCHEMA_VERSION, load_config, resolve_config, resolved_config_to_dict
from voqsim.errors import ConfigError, ValidationError
from voqsim.manifest import build_service_model, hash_service_model


def _canonical_config(
    *,
    arrival: dict[str, object] | None = None,
    conflicts: list[list[str]] | None = None,
    queue_capacity: object = 8,
) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 41, "slots": 4},
        "switch": {
            "kind": "generalized",
            "queue_capacity": queue_capacity,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {
                    "conflicts": [["q0", "q1"]] if conflicts is None else conflicts,
                }
            },
        },
        "arrival": arrival
        or {
            "family": "deterministic_trace",
            "events": [{"slot": 0, "queue_id": "q0", "count": 1}],
        },
    }


def test_shipped_example_is_a_canonical_schema4_configuration() -> None:
    config = load_config(Path(__file__).parents[1] / "canonicalschema.json")

    assert config.schema_version == "4.0.0"
    assert config.switch.kind == "generalized"
    assert config.scheduler.name in {
        "crossbar_max_weight",
        "interval_max_weight",
        "node_exclusive_max_weight",
        "conflict_graph_max_weight",
        "resource_packing_max_weight",
        "crossbar_random_greedy_maximal",
        "crossbar_random_grant_accept",
        "crossbar_islip",
    }
    canonical = resolved_config_to_dict(config)
    assert resolved_config_to_dict(resolve_config(canonical)) == canonical


def test_generalized_queue_catalog_preserves_declared_identity_and_order() -> None:
    raw = _canonical_config()
    raw["switch"]["queues"] = [{"id": 1}, {"id": "1"}]  # type: ignore[index]
    raw["scheduler"]["params"]["constraint"] = {"conflicts": [[1, "1"]]}  # type: ignore[index]
    raw["arrival"] = {
        "family": "deterministic_trace",
        "events": [
            {"slot": 0, "queue_id": 1, "count": 1},
            {"slot": 0, "queue_id": "1", "count": 2},
        ],
    }

    config = resolve_config(raw)

    assert config.switch.catalog.queue_ids == (1, "1")
    assert [event["queue_id"] for event in config.arrival.params["events"]] == [1, "1"]


def test_schema4_rejects_non_int64_finite_queue_capacity() -> None:
    with pytest.raises((ConfigError, ValidationError), match="capacity|int64|range"):
        resolve_config(_canonical_config(queue_capacity=1 << 63))


def test_nontrivial_scheduler_requires_its_canonical_constraint_contract() -> None:
    raw = _canonical_config()
    raw["scheduler"]["params"] = {}  # type: ignore[index]

    with pytest.raises((ConfigError, ValidationError), match="constraint"):
        resolve_config(raw)


def test_service_model_hash_is_independent_of_arrival_law() -> None:
    baseline = resolve_config(_canonical_config())
    poisson = resolve_config(
        _canonical_config(
            arrival={
                "family": "iid_independent_poisson",
                "rates": {
                    "default": Decimal(0),
                    "overrides": [{"queue_id": "q1", "rate": Decimal("0.75")}],
                },
            }
        )
    )

    assert hash_service_model(build_service_model(baseline)) == hash_service_model(
        build_service_model(poisson)
    )


def test_service_constraint_changes_service_model_hash() -> None:
    no_conflict = resolve_config(_canonical_config(conflicts=[]))
    one_conflict = resolve_config(_canonical_config(conflicts=[["q0", "q1"]]))

    assert hash_service_model(build_service_model(no_conflict)) != hash_service_model(
        build_service_model(one_conflict)
    )


def test_resolved_config_does_not_alias_mutable_input() -> None:
    raw = _canonical_config()
    resolved = resolve_config(raw)
    raw["arrival"]["events"][0]["count"] = 99  # type: ignore[index]

    assert resolved_config_to_dict(resolved)["arrival"]["events"][0]["count"] == 1


def test_batch_discovery_ignores_bundle_sidecars(tmp_path: Path) -> None:
    (tmp_path / "run.yaml").write_text("schema_version: 4.0.0\n", encoding="utf-8")
    (tmp_path / "run_manifest.json").write_text("{}\n", encoding="utf-8")
    (tmp_path / "validation_report.json").write_text("{}\n", encoding="utf-8")
    (tmp_path / "service_model.json").write_text("{}\n", encoding="utf-8")

    discovered = discover_config_files(tmp_path)
    assert [item.relative_path.as_posix() for item in discovered] == ["run.yaml"]
