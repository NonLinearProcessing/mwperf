from __future__ import annotations

from itertools import combinations, product
from pathlib import Path
import random
from typing import Callable

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY
from voqsim.errors import ScheduleError
from voqsim.kernel import build_simulation
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.conflict_graph_max_weight import ConflictGraphMaxWeightScheduler
from voqsim.schedulers.crossbar_max_weight import CrossbarMaxWeightScheduler
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.interval_max_weight import IntervalMaxWeightScheduler
from voqsim.schedulers.node_exclusive_max_weight import NodeExclusiveMaxWeightScheduler
from voqsim.schedulers.resource_packing_max_weight import ResourcePackingMaxWeightScheduler
from voqsim.telemetry import CompactObservationReader, STATUS_FAILED


Feasible = Callable[[frozenset[int]], bool]
FAMILIES = (
    "crossbar",
    "interval",
    "node_exclusive",
    "conflict_graph",
    "resource_packing",
)


def _bind(scheduler, queue_ids: tuple[str, ...], service_family: str):
    catalog = QueueCatalog(queue_ids)
    scheduler.configure_for_domain(QueueSchedulerDomain(catalog, service_family))
    return scheduler, catalog


def _deterministic_topology(
    family: str,
    variant: int,
) -> tuple[object, QueueCatalog, Feasible]:
    """Build repeatable small topologies beyond the hand-written golden cases."""

    rng = random.Random(10_000 + 101 * variant + FAMILIES.index(family))
    queue_ids = tuple(f"q{index}" for index in range(5))
    priority = list(queue_ids)
    rng.shuffle(priority)

    if family == "crossbar":
        pairs = rng.sample(tuple(product(range(3), repeat=2)), len(queue_ids))
        scheduler, catalog = _bind(
            CrossbarMaxWeightScheduler(
                {
                    "constraint": {
                        "inputs": [0, 1, 2],
                        "outputs": [0, 1, 2],
                        "edges": [
                            {"queue_id": queue_id, "input": edge[0], "output": edge[1]}
                            for queue_id, edge in zip(queue_ids, pairs, strict=True)
                        ],
                    },
                    "priority": priority,
                }
            ),
            queue_ids,
            "crossbar_matching",
        )

        def feasible(selected: frozenset[int]) -> bool:
            return (
                len({pairs[index][0] for index in selected}) == len(selected)
                and len({pairs[index][1] for index in selected}) == len(selected)
            )

        return scheduler, catalog, feasible

    if family == "interval":
        universe = tuple(
            (left, right)
            for left in range(6)
            for right in range(left + 1, min(left + 4, 8))
        )
        intervals = rng.sample(universe, len(queue_ids))
        scheduler, catalog = _bind(
            IntervalMaxWeightScheduler(
                {
                    "constraint": {
                        "intervals": [
                            {"queue_id": queue_id, "left": interval[0], "right": interval[1]}
                            for queue_id, interval in zip(queue_ids, intervals, strict=True)
                        ]
                    },
                    "priority": priority,
                }
            ),
            queue_ids,
            "nonoverlapping_intervals",
        )

        def feasible(selected: frozenset[int]) -> bool:
            chosen = sorted(intervals[index] for index in selected)
            return all(left[1] <= right[0] for left, right in zip(chosen, chosen[1:]))

        return scheduler, catalog, feasible

    if family == "node_exclusive":
        edge_universe = tuple(combinations(range(5), 2))
        links = [rng.choice(edge_universe) for _queue_id in queue_ids]
        scheduler, catalog = _bind(
            NodeExclusiveMaxWeightScheduler(
                {
                    "constraint": {
                        "vertices": [0, 1, 2, 3, 4],
                        "links": [
                            {"queue_id": queue_id, "u": link[0], "v": link[1]}
                            for queue_id, link in zip(queue_ids, links, strict=True)
                        ],
                    },
                    "priority": priority,
                }
            ),
            queue_ids,
            "node_exclusive_matching",
        )

        def feasible(selected: frozenset[int]) -> bool:
            endpoints = [endpoint for index in selected for endpoint in links[index]]
            return len(endpoints) == len(set(endpoints))

        return scheduler, catalog, feasible

    if family == "conflict_graph":
        edge_universe = tuple(combinations(range(len(queue_ids)), 2))
        conflicts = [edge for edge in edge_universe if rng.randrange(3) == 0]
        if not conflicts:
            conflicts.append(edge_universe[variant % len(edge_universe)])
        scheduler, catalog = _bind(
            ConflictGraphMaxWeightScheduler(
                {
                    "constraint": {
                        "conflicts": [
                            [queue_ids[left], queue_ids[right]] for left, right in conflicts
                        ]
                    },
                    "priority": priority,
                }
            ),
            queue_ids,
            "pairwise_conflicts",
        )

        def feasible(selected: frozenset[int]) -> bool:
            return all(not ({left, right} <= selected) for left, right in conflicts)

        return scheduler, catalog, feasible

    if family == "resource_packing":
        capacity = (2 + variant % 2, 3)
        demand_universe = tuple(product(*(range(value + 1) for value in capacity)))
        demands = rng.sample(demand_universe, len(queue_ids))
        demands[-1] = (0, 0)
        scheduler, catalog = _bind(
            ResourcePackingMaxWeightScheduler(
                {
                    "constraint": {
                        "resources": ["r0", "r1"],
                        "capacity": list(capacity),
                        "demands": [
                            {"queue_id": queue_id, "demand": list(demand)}
                            for queue_id, demand in zip(queue_ids, demands, strict=True)
                        ],
                    },
                    "priority": priority,
                }
            ),
            queue_ids,
            "resource_packing",
        )

        def feasible(selected: frozenset[int]) -> bool:
            return all(
                sum(demands[index][resource] for index in selected) <= capacity[resource]
                for resource in range(len(capacity))
            )

        return scheduler, catalog, feasible

    raise AssertionError(f"unhandled family: {family}")


def _class_value(
    q_len: tuple[int, ...],
    feasible_sets: tuple[frozenset[int], ...],
    target: int,
    forced_class: int,
) -> int:
    values = []
    for selected in feasible_sets:
        if int(target in selected) != forced_class:
            continue
        if any(q_len[index] == 0 and index != target for index in selected):
            continue
        if forced_class == 0 and any(q_len[index] == 0 for index in selected):
            continue
        values.append(sum(q_len[index] for index in selected))
    assert values
    return max(values)


@pytest.mark.parametrize("family", FAMILIES)
@pytest.mark.parametrize("variant", range(3))
def test_deterministic_arbitrary_topologies_match_feasible_set_oracle(
    family: str,
    variant: int,
) -> None:
    scheduler, catalog, feasible = _deterministic_topology(family, variant)
    feasible_sets = tuple(
        selected
        for bits in product((0, 1), repeat=catalog.n_queues)
        if feasible(
            selected := frozenset(index for index, bit in enumerate(bits) if bit)
        )
    )
    states = [tuple(1 + (index + variant) % 3 for index in range(catalog.n_queues))]
    states.extend(
        tuple(
            0 if index == empty_target else 1 + (index + empty_target + variant) % 3
            for index in range(catalog.n_queues)
        )
        for empty_target in range(catalog.n_queues)
    )

    for state_index, q_len in enumerate(states):
        vector = np.asarray(q_len, dtype=np.int64)
        decision = scheduler.select_service(
            vector,
            10 * variant + state_index,
            np.random.default_rng(900 + state_index),
        )
        certificates = scheduler.exact_class_certificates(
            vector,
            decision,
            catalog.queue_ids,
            slot=10 * variant + state_index,
        )

        selected = frozenset(catalog.index_of(queue_id) for queue_id in decision.selected_queue_ids)
        assert selected in feasible_sets
        assert all(q_len[index] > 0 for index in selected)
        production_value = sum(q_len[index] for index in selected)
        assert production_value == max(
            sum(q_len[index] for index in candidate)
            for candidate in feasible_sets
            if all(q_len[index] > 0 for index in candidate)
        )

        for target, certificate in enumerate(certificates):
            assert certificate.v0 == _class_value(q_len, feasible_sets, target, 0)
            assert certificate.v1 == _class_value(q_len, feasible_sets, target, 1)
            assert certificate.production_value == production_value
            assert certificate.theta >= 0


def _search_limit_config() -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 29_001,
            "slots": 2,
            "warmup_slots": 1,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": ["q0", "q1", "q2"],
        },
        "scheduler": {
            "name": "resource_packing_max_weight",
            "params": {
                "constraint": {
                    "resources": ["r"],
                    "capacity": [2],
                    "demands": [
                        {"queue_id": "q0", "demand": [1]},
                        {"queue_id": "q1", "demand": [2]},
                        {"queue_id": "q2", "demand": [2]},
                    ],
                },
                "priority": ["q0", "q1", "q2"],
                "max_search_states": 1,
            },
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [
                {"slot": 0, "queue_id": "q0", "count": 1},
                {"slot": 0, "queue_id": "q1", "count": 1},
                {"slot": 0, "queue_id": "q2", "count": 3},
                {"slot": 1, "queue_id": "q0", "count": 4},
            ],
        },
        "telemetry": {
            "write_slot_trace": False,
            "observation": {
                "enabled": True,
                "block_slots": None,
                "targets": [{"queue_id": "q2", "gap": "exact"}],
            },
        },
    }


def test_opposite_class_search_limit_failure_is_pre_mutation_atomic(tmp_path: Path) -> None:
    simulator = build_simulation(_search_limit_config(), output_dir=tmp_path / "limited")
    measured_state = np.asarray([1, 1, 3], dtype=np.int64)

    # The production optimization fits within one explored state. Only the
    # opposite forced-out class needs a second state and exceeds the limit.
    production = simulator.scheduler.select_service(
        measured_state,
        1,
        np.random.default_rng(0),
    )
    assert production == ServiceDecision(("q2",))
    with pytest.raises(ScheduleError, match="exceeded max_search_states") as direct_error:
        simulator.scheduler.exact_class_certificates(
            measured_state,
            production,
            ("q2",),
            slot=1,
        )
    assert direct_error.value.context["states_explored"] == 2
    assert direct_error.value.context["max_search_states"] == 1

    commits: list[object] = []
    with pytest.raises(ScheduleError, match="exceeded max_search_states"):
        simulator.run(observers=commits.append)

    # Warmup arrivals formed the measured state. The failing measured slot did
    # not serve q2, sample its slot-1 arrivals, or publish an observation.
    assert simulator.switch.queue_lengths().tolist() == [1, 1, 3]
    assert commits == []
    assert simulator.observation_path is not None
    with CompactObservationReader(
        simulator.observation_path,
        require_complete=False,
    ) as reader:
        assert reader.state.status == STATUS_FAILED
        assert tuple(reader.iter_levels()) == ()
