from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import pytest

from voqsim.cli import main
from voqsim.config import dump_resolved_config, load_config

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"

EXAMPLE_CONFIGS = {
    "2x2_iid_table_random_maximal.yaml": 1001,
    "4x4_markov_kernel_random_maximal.yaml": 2002,
    "8x8_factorized_bernoulli_random_maximal.yaml": 3003,
    "4x4_iid_table_islip_canonical.yaml": 4004,
    "4x4_iid_table_crossbar_max_weight_exact.yaml": 5005,
    "patch2_deterministic_trace_max_weight.yaml": 172001,
    "patch2_periodic_global_phase_max_weight.yaml": 172002,
    "patch2_periodic_source_delays_max_weight.yaml": 172003,
    "patch2_independent_marked_renewal_max_weight.yaml": 172004,
    "patch2_independent_private_markov_renewal_max_weight.yaml": 172005,
    "patch2_shared_joint_round_markov_renewal_max_weight.yaml": 172006,
    "schema3_sparse_rectangular_crossbar_max_weight.yaml": 173001,
    "schema3_interval_max_weight.yaml": 173002,
    "schema3_node_exclusive_max_weight.yaml": 174001,
    "schema3_conflict_graph_max_weight.yaml": 175001,
    "schema3_resource_packing_max_weight.yaml": 175002,
}


@pytest.mark.parametrize("filename,expected_seed", EXAMPLE_CONFIGS.items())
def test_example_configs_round_trip_through_load_and_resolved_dump(
    tmp_path: Path,
    filename: str,
    expected_seed: int,
) -> None:
    config_path = CONFIG_DIR / filename
    config = load_config(config_path)

    assert config.run.seed == expected_seed
    assert config.schema_version == "4.0.0"
    assert config.switch.kind == "generalized"

    dumped_path = dump_resolved_config(config, expected_seed, tmp_path / f"resolved_{filename}")
    reloaded = load_config(dumped_path)

    assert reloaded == config.with_actual_seed(expected_seed)


@pytest.mark.parametrize("filename", sorted(EXAMPLE_CONFIGS))
def test_cli_main_runs_each_example_config_and_writes_expected_artifacts(
    tmp_path: Path,
    filename: str,
) -> None:
    config_path = CONFIG_DIR / filename
    output_dir = tmp_path / config_path.stem

    exit_code = main([str(config_path), "--output-dir", str(output_dir), "--quiet"])
    assert exit_code == 0

    expected_files = {
        "telemetry.jsonl",
        "run_summary.json",
        "run_manifest.json",
        "resolved_config.yaml",
        "flow_plan.json",
        "arrival_support.json",
        "service_model.json",
    }
    assert expected_files.issubset({path.name for path in output_dir.iterdir()})



def test_generalized_exact_example_records_scheduler_and_optimizer_identity(tmp_path: Path) -> None:
    config_path = CONFIG_DIR / "schema3_sparse_rectangular_crossbar_max_weight.yaml"
    output_dir = tmp_path / "generalized_exact"

    exit_code = main([str(config_path), "--output-dir", str(output_dir), "--quiet"])
    assert exit_code == 0

    resolved = load_config(output_dir / "resolved_config.yaml")
    service_model = json.loads((output_dir / "service_model.json").read_text(encoding="utf-8"))
    records = [
        json.loads(line)
        for line in (output_dir / "telemetry.jsonl").read_text(encoding="utf-8").splitlines()
    ]

    assert resolved.scheduler.name == "crossbar_max_weight"
    assert resolved.scheduler.params["priority"] == ["south", "north", "east", "west"]
    assert service_model["service"]["family"] == "crossbar_matching"
    assert {record["schedule"]["scheduler_id"] for record in records} == {"crossbar_max_weight"}
    assert {record["schedule"]["algorithm_id"] for record in records} == {"hungarian_exact"}
    assert {record["schedule"]["optimizer_id"] for record in records} == {"hungarian_exact"}



def test_cli_module_entrypoint_runs_one_command_path_and_emits_result_json(tmp_path: Path) -> None:
    config_path = CONFIG_DIR / "2x2_iid_table_random_maximal.yaml"
    output_dir = tmp_path / "module_run"

    completed = subprocess.run(
        [sys.executable, "-m", "voqsim.cli", str(config_path), "--output-dir", str(output_dir)],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    assert completed.stderr == ""

    payload = json.loads(completed.stdout)
    assert payload["actual_seed"] == 1001
    assert payload["requested_seed"] == 1001
    assert payload["output_dir"] == str(output_dir)
    assert Path(payload["telemetry_path"]).exists()
    assert Path(payload["summary_path"]).exists()



def test_cli_no_slot_trace_omits_telemetry_file_and_emits_summary_only_payload(tmp_path: Path) -> None:
    config_path = CONFIG_DIR / "2x2_iid_table_random_maximal.yaml"
    output_dir = tmp_path / "no_trace"

    completed = subprocess.run(
        [sys.executable, "-m", "voqsim.cli", str(config_path), "--output-dir", str(output_dir), "--no-slot-trace"],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    payload = json.loads(completed.stdout)
    assert payload["slot_trace_written"] is False
    assert "telemetry_path" not in payload
    assert Path(payload["summary_path"]).exists()
    assert not (output_dir / "telemetry.jsonl").exists()
    resolved = load_config(output_dir / "resolved_config.yaml")
    assert resolved.telemetry.write_slot_trace is False


def test_cli_version_and_list_schedulers_commands(capsys) -> None:
    assert main(["--version"]) == 0
    version_out = capsys.readouterr().out
    assert version_out == "20.1.0\n"

    assert main(["--list-schedulers"]) == 0
    schedulers = json.loads(capsys.readouterr().out)["schedulers"]
    assert schedulers == [
        {
            "algorithm_id": "mwis_branch_memo_exact",
            "constraint_family": "pairwise_conflicts",
            "name": "conflict_graph_max_weight",
        },
        {
            "algorithm_id": "persistent_pointer_islip",
            "constraint_family": "crossbar_matching",
            "name": "crossbar_islip",
        },
        {
            "algorithm_id": "hungarian_exact",
            "constraint_family": "crossbar_matching",
            "name": "crossbar_max_weight",
        },
        {
            "algorithm_id": "uniform_random_grant_accept",
            "constraint_family": "crossbar_matching",
            "name": "crossbar_random_grant_accept",
        },
        {
            "algorithm_id": "random_permutation_greedy_maximal",
            "constraint_family": "crossbar_matching",
            "name": "crossbar_random_greedy_maximal",
        },
        {
            "algorithm_id": "weighted_interval_dp_exact",
            "constraint_family": "nonoverlapping_intervals",
            "name": "interval_max_weight",
        },
        {
            "algorithm_id": "edmonds_blossom_exact",
            "constraint_family": "node_exclusive_matching",
            "name": "node_exclusive_max_weight",
        },
        {
            "algorithm_id": "binary_packing_memo_exact",
            "constraint_family": "resource_packing",
            "name": "resource_packing_max_weight",
        },
    ]
