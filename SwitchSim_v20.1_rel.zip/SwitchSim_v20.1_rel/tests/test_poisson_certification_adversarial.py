from __future__ import annotations

from decimal import Decimal, ROUND_UP, localcontext
from fractions import Fraction
import math
from types import SimpleNamespace

import pytest

from voqsim.analysis import (
    ArrivalMarginal,
    CertifiedEvaluation,
    FiniteWindowResult,
    analyze_pooled_target_block,
    cutoff_analysis,
    finite_window_accounting,
    normalize_level_masses,
)
from voqsim.analysis.observations import innovation_from_pooled
from voqsim.analysis.step1 import (
    _outward_float_bound,
    _subtract_exact,
    _weighted_evaluations,
)
from voqsim.telemetry import (
    MASS_BINARY64_LATTICE,
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    TargetSlotObservation,
)


def _as_fraction(value: Fraction | float) -> Fraction:
    return value if isinstance(value, Fraction) else Fraction.from_float(value)


def _certified_interval(
    evaluation: CertifiedEvaluation,
) -> tuple[Fraction, Fraction]:
    assert evaluation.available
    assert evaluation.value is not None and evaluation.error_bound is not None
    center = _as_fraction(evaluation.value)
    error = _as_fraction(evaluation.error_bound)
    return center - error, center + error


def _assert_contains(evaluation: CertifiedEvaluation, exact: Fraction) -> None:
    lower, upper = _certified_interval(evaluation)
    assert lower <= exact <= upper


def test_extreme_mixed_poisson_weight_does_not_break_certificate() -> None:
    probability = Fraction(4, 10**324)
    multiplier = 1 / probability
    base_rate = Fraction(4, 10**16)
    conditional_rate = base_rate * multiplier
    law = ArrivalMarginal.mixed_poisson(
        base_rate,
        (
            (probability, multiplier),
            (1 - probability, 0),
        ),
    )

    result = law.stop_loss(0, 1)

    # For r=1 the exact component is theta - 1 + exp(-theta), hence the
    # mixture lies strictly between these two exact rational endpoints.
    lower_truth = probability * (conditional_rate - 1)
    upper_truth = probability * conditional_rate
    lower, upper = _certified_interval(result)
    assert lower <= lower_truth
    assert upper >= upper_truth
    assert law.mean == base_rate


def test_weighted_evaluation_charges_exact_weight_conversion() -> None:
    probability = Fraction(4, 10**324)
    component = CertifiedEvaluation(1e308, math.ulp(0.0), "ok")

    result = _weighted_evaluations(((probability, component),))

    exact_center = probability * Fraction.from_float(1e308)
    _assert_contains(result, exact_center)


def test_subtract_exact_survives_binary64_cancellation() -> None:
    almost_one = Fraction(2**60 - 1, 2**60)
    approximate_one = CertifiedEvaluation(1.0, math.ulp(0.0), "ok")

    result = _subtract_exact(approximate_one, almost_one)

    _assert_contains(result, Fraction(1, 2**60))
    assert result.value != 0


def test_outward_float_bound_never_rounds_below_exact_bound() -> None:
    exact_bound = Fraction(1) + Fraction(1, 2**54)

    emitted = _outward_float_bound(exact_bound)

    assert Fraction.from_float(emitted) >= exact_bound
    assert Fraction.from_float(math.nextafter(emitted, -math.inf)) < exact_bound


def test_poisson_certificate_is_independent_of_ambient_decimal_context() -> None:
    law = ArrivalMarginal.poisson(Decimal("3.25"))
    baseline = law.stop_loss(0, 5)

    with localcontext() as context:
        context.prec = 2
        context.rounding = ROUND_UP
        constrained = law.stop_loss(0, 5)

    assert constrained == baseline


def test_theta_1000_near_mean_stop_loss_encloses_high_precision_oracle() -> None:
    theta = Decimal(1000)
    cutoff = 1000
    result = ArrivalMarginal.poisson(theta).stop_loss(0, cutoff)

    with localcontext() as context:
        context.prec = 240
        term = (-theta).exp()
        expected = Decimal(0)
        for count in range(4001):
            if count > cutoff:
                expected += Decimal(count - cutoff) * term
            term = term * theta / Decimal(count + 1)
        assert term < Decimal("1e-1000")
        assert result.value is not None and result.error_bound is not None
        center = Decimal.from_float(float(result.value))
        error = Decimal.from_float(float(result.error_bound))
        assert center - error <= expected <= center + error


@pytest.mark.parametrize("theta", (Decimal("1e10"), Decimal("1e300")))
def test_large_theta_stop_loss_remains_certified(theta: Decimal) -> None:
    result = ArrivalMarginal.poisson(theta).stop_loss(0, 1)

    assert result.status == "ok"
    # exp(-theta) is positive, so theta - 1 is a strict lower bound and must
    # not lie above the returned enclosure.
    lower, upper = _certified_interval(result)
    threshold = Fraction(theta) - 1
    assert lower <= threshold < upper


def test_stop_loss_outside_binary64_result_range_is_unavailable() -> None:
    result = ArrivalMarginal.poisson(Decimal("1e309")).stop_loss(0, 1)

    assert result.status == "poisson_numerical_failure"
    assert result.value is None
    assert result.error_bound is None


def test_extreme_decimal_endpoint_hits_controlled_resource_status(
    monkeypatch,
) -> None:
    import voqsim.analysis.step1 as step1

    monkeypatch.setattr(step1, "_POISSON_MAX_FRACTION_DECIMAL_DIGITS", 20)

    result = ArrivalMarginal.poisson(Decimal("1e-20")).stop_loss(0, 1)

    assert result.status == "poisson_numeric_resource_limit"
    assert result.value is None
    assert result.error_bound is None


class _ControlledApproximateLaw:
    mean = Fraction(0)
    variance = Fraction(0)
    second_moment = Fraction(0)
    fresh_iid = True

    def stop_loss(self, _state: int, _cutoff: int) -> CertifiedEvaluation:
        return CertifiedEvaluation(1.0, math.ulp(0.0), "ok")

    def shifted_expectation(self, _state, _function) -> CertifiedEvaluation:
        return CertifiedEvaluation.exact(0)


def test_finite_window_tail_subtraction_charges_cancellation() -> None:
    masses = normalize_level_masses({0: 1}, {0: 0})
    law = _ControlledApproximateLaw()
    cutoff = cutoff_analysis(masses, 0, law.mean)
    denominator = 2**60
    almost_one = Fraction(denominator - 1, denominator)

    result = finite_window_accounting(
        masses,
        {0: 1},
        {0: Fraction(1, denominator), 1: almost_one},
        1,
        law,
        cutoff=cutoff,
    )

    assert result.tail_slack_right is not None
    assert result.tail_slack_right_error_bound is not None
    evaluation = CertifiedEvaluation(
        result.tail_slack_right,
        result.tail_slack_right_error_bound,
        result.numerical_status,
    )
    _assert_contains(evaluation, Fraction(1, denominator))


def test_innovation_hinge_subtraction_charges_cancellation() -> None:
    denominator = 2**60
    almost_one = Fraction(denominator - 1, denominator)
    finite = FiniteWindowResult(
        slots=1,
        eta_1=Fraction(0),
        eta_2=Fraction(0),
        expected_eta_1=Fraction(0),
        expected_eta_2=Fraction(0),
        z_from_endpoints=Fraction(0),
        eta_k=Fraction(0),
        beta_k=1.0,
        tail_slack_left=almost_one,
        tail_slack_right=1.0,
        status="ok",
        beta_k_error_bound=math.ulp(0.0),
        tail_slack_right_error_bound=math.ulp(0.0),
        numerical_status="ok",
    )

    result = innovation_from_pooled(
        SimpleNamespace(mass_kind=MASS_BINARY64_LATTICE),
        SimpleNamespace(cutoff=0),
        finite,
    )

    assert result.hinge is not None and result.numerical_error_bound is not None
    evaluation = CertifiedEvaluation(
        result.hinge,
        result.numerical_error_bound,
        result.numerical_status,
    )
    _assert_contains(evaluation, -Fraction(1, denominator))
    assert result.hinge != 0


def _write_provenance_observation(
    path,
    *,
    capacity: int | str,
    slot_convention: str,
) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=4,
        targets=[ObservationTarget("target", "q", gap_mode="none")],
        metadata={
            "actual_seed": 7,
            "slot_convention": slot_convention,
            "scientific_config": {
                "arrival": {"family": "fixture"},
                "scheduler": {"name": "fixture", "tie_policy": "fixture"},
                "switch": {
                    "kind": "fixture",
                    "queue_capacity": capacity,
                },
            },
        },
    )
    for slot in range(4):
        recorder.record_slot(
            slot,
            [
                TargetSlotObservation(
                    target_id="target",
                    backlog_before=1,
                    backlog_after=1,
                    served=1,
                    offered=1,
                    admitted=1,
                    dropped=0,
                )
            ],
        )
    recorder.complete()
    recorder.close()


@pytest.mark.parametrize(
    ("capacity", "slot_convention", "expected_status"),
    (
        (
            8,
            "pre_service_N; service; arrivals; post_arrival_N_prime",
            "no_drop_required",
        ),
        ("NoDrop", "arrivals_before_service", "unsupported_slot_convention"),
    ),
)
def test_pooled_kwargs_cannot_upgrade_recorded_provenance(
    tmp_path,
    capacity: int | str,
    slot_convention: str,
    expected_status: str,
) -> None:
    path = tmp_path / f"provenance-{expected_status}.sqlite3"
    _write_provenance_observation(
        path,
        capacity=capacity,
        slot_convention=slot_convention,
    )
    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=ArrivalMarginal.from_pmf(
                {0: Fraction(1, 2), 1: Fraction(1, 2)}
            ),
            stationary_interpretation=True,
            no_drop=True,
            early_service_late_arrival=True,
        )

    assert report.isolated_server.status == expected_status
    assert report.isolated_server.difference_label == "raw_difference"
    assert report.isolated_server.contention_excess is None
