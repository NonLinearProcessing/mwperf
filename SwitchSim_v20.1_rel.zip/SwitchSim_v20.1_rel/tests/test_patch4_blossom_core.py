from __future__ import annotations

from functools import lru_cache
from itertools import combinations
import random

import pytest

from voqsim.schedulers._blossom import maximum_weight_matching


def _brute_force_optimum(
    n_vertices: int,
    edges: list[tuple[int, int, int]],
) -> int:
    edge_weight = {
        (min(u, v), max(u, v)): weight for u, v, weight in edges
    }

    @lru_cache(maxsize=None)
    def solve(available: int) -> int:
        if available == 0:
            return 0
        low_bit = available & -available
        u = low_bit.bit_length() - 1
        without_u = available ^ low_bit
        best = solve(without_u)  # Leave u unmatched.
        candidates = without_u
        while candidates:
            v_bit = candidates & -candidates
            candidates ^= v_bit
            v = v_bit.bit_length() - 1
            weight = edge_weight.get((u, v))
            if weight is not None:
                best = max(best, weight + solve(without_u ^ v_bit))
        return best

    return solve((1 << n_vertices) - 1)


def _matching_weight(
    matching: tuple[tuple[int, int], ...],
    edges: list[tuple[int, int, int]],
) -> int:
    weights = {(min(u, v), max(u, v)): weight for u, v, weight in edges}
    used: set[int] = set()
    total = 0
    assert matching == tuple(sorted(matching))
    for u, v in matching:
        assert u < v
        assert u not in used and v not in used
        assert (u, v) in weights
        used.update((u, v))
        total += weights[u, v]
    return total


def _assert_optimum(n_vertices: int, edges: list[tuple[int, int, int]]) -> None:
    matching = maximum_weight_matching(n_vertices, edges)
    assert _matching_weight(matching, edges) == _brute_force_optimum(
        n_vertices, edges
    )


@pytest.mark.parametrize(
    ("n_vertices", "edges"),
    [
        (0, []),
        (5, []),
        (3, [(0, 1, 4), (1, 2, 5), (2, 0, 6)]),
        (
            5,
            [
                (0, 1, 9),
                (1, 2, 8),
                (2, 3, 7),
                (3, 4, 6),
                (4, 0, 10),
            ],
        ),
        (
            7,
            [
                (0, 1, 11),
                (1, 2, 13),
                (2, 3, 17),
                (3, 4, 19),
                (4, 5, 23),
                (5, 6, 29),
                (6, 0, 31),
                (1, 5, 37),
            ],
        ),
        (
            9,
            [
                # Three disconnected components and one isolated vertex.
                (0, 1, 4),
                (1, 2, 9),
                (0, 2, 7),
                (3, 4, 12),
                (5, 6, 8),
                (6, 7, 20),
                (5, 7, 11),
            ],
        ),
        (
            6,
            [
                # The locally heaviest edge blocks a better two-edge choice.
                (0, 1, 15),
                (0, 2, 10),
                (1, 3, 10),
                (2, 4, 9),
                (3, 5, 9),
            ],
        ),
    ],
)
def test_odd_cycles_components_unmatched_and_greedy_traps(
    n_vertices: int,
    edges: list[tuple[int, int, int]],
) -> None:
    _assert_optimum(n_vertices, edges)


def test_arbitrary_precision_composite_weights_remain_exact() -> None:
    scale = 1 << 600
    edges = [
        (0, 1, 7 * scale + (1 << 299) + 3),
        (2, 3, 5 * scale + (1 << 211) + 7),
        (0, 2, 6 * scale + (1 << 401) + 11),
        (1, 3, 6 * scale + (1 << 401) + 13),
        (4, 5, -(1 << 900)),
    ]
    result = maximum_weight_matching(6, edges)
    assert result == ((0, 2), (1, 3))
    _assert_optimum(6, edges)


def test_signed_weights_use_optional_matching_semantics() -> None:
    edges = [
        (0, 1, -100),
        (1, 2, -2),
        (2, 3, 0),
        (3, 4, -1),
    ]
    result = maximum_weight_matching(5, edges)
    assert _matching_weight(result, edges) == 0
    assert all(
        dict(((min(u, v), max(u, v)), w) for u, v, w in edges)[edge] >= 0
        for edge in result
    )


def test_result_is_independent_of_input_edge_order() -> None:
    edges = [
        (0, 1, 9),
        (0, 2, 9),
        (1, 2, 9),
        (1, 3, 7),
        (2, 4, 7),
        (3, 4, 9),
        (3, 5, 6),
        (4, 5, 6),
    ]
    expected = maximum_weight_matching(6, edges)
    rng = random.Random(4017)
    for _ in range(100):
        shuffled = list(edges)
        rng.shuffle(shuffled)
        assert maximum_weight_matching(6, shuffled) == expected


@pytest.mark.parametrize(
    ("n_vertices", "edges", "expected"),
    [
        (
            7,
            [
                (1, 2, 9),
                (1, 3, 9),
                (2, 3, 10),
                (2, 4, 8),
                (3, 5, 8),
                (4, 5, 10),
                (5, 6, 6),
            ],
            ((1, 3), (2, 4), (5, 6)),
        ),
        (
            9,
            [
                (1, 2, 19),
                (1, 3, 20),
                (1, 8, 8),
                (2, 3, 25),
                (2, 4, 18),
                (3, 5, 18),
                (4, 5, 13),
                (4, 7, 7),
                (5, 6, 7),
            ],
            ((1, 8), (2, 3), (4, 7), (5, 6)),
        ),
        (
            11,
            [
                (1, 2, 45),
                (1, 5, 45),
                (2, 3, 50),
                (3, 4, 45),
                (4, 5, 50),
                (1, 6, 30),
                (3, 9, 35),
                (4, 8, 35),
                (5, 7, 26),
                (9, 10, 5),
            ],
            ((1, 6), (2, 3), (4, 8), (5, 7), (9, 10)),
        ),
        (
            13,
            [
                (1, 2, 45),
                (1, 7, 45),
                (2, 3, 50),
                (3, 4, 45),
                (4, 5, 95),
                (4, 6, 94),
                (5, 6, 94),
                (6, 7, 50),
                (1, 8, 30),
                (3, 11, 35),
                (5, 9, 36),
                (7, 10, 26),
                (11, 12, 5),
            ],
            ((1, 8), (2, 3), (4, 6), (5, 9), (7, 10), (11, 12)),
        ),
    ],
)
def test_nested_and_relabelled_blossom_regressions(
    n_vertices: int,
    edges: list[tuple[int, int, int]],
    expected: tuple[tuple[int, int], ...],
) -> None:
    """Exercise the upstream nested-blossom and expansion regressions."""

    assert maximum_weight_matching(n_vertices, edges) == expected


def test_all_unweighted_graphs_through_five_vertices_match_brute_force() -> None:
    for n_vertices in range(6):
        possible = list(combinations(range(n_vertices), 2))
        for edge_mask in range(1 << len(possible)):
            edges = [
                (u, v, 1)
                for bit, (u, v) in enumerate(possible)
                if edge_mask & (1 << bit)
            ]
            _assert_optimum(n_vertices, edges)


def test_random_weighted_graphs_match_exhaustive_enumeration() -> None:
    rng = random.Random(0xB10550)
    checked = 0
    for n_vertices in range(2, 10):
        possible = list(combinations(range(n_vertices), 2))
        for _ in range(240):
            density = rng.uniform(0.05, 0.95)
            edges = [
                (u, v, rng.randrange(-30, 51))
                for u, v in possible
                if rng.random() < density
            ]
            rng.shuffle(edges)
            _assert_optimum(n_vertices, edges)
            checked += 1
    assert checked == 1_920


@pytest.mark.parametrize(
    ("n_vertices", "edges", "error_type", "message"),
    [
        (True, [], TypeError, "n_vertices"),
        (-1, [], ValueError, "nonnegative"),
        (2, [(0, 0, 1)], ValueError, "self-loop"),
        (2, [(0, 1, 1), (1, 0, 2)], ValueError, "duplicate"),
        (2, [(0, 2, 1)], ValueError, "outside vertex domain"),
        (2, [(False, 1, 1)], TypeError, "endpoints"),
        (2, [(0, 1, True)], TypeError, "weight"),
        (2, [(0, 1, 1.5)], TypeError, "weight"),
        (2, [(0, 1)], ValueError, "exactly three"),
    ],
)
def test_invalid_graphs_fail_before_optimization(
    n_vertices: int,
    edges: list[tuple[int, int, int]],
    error_type: type[Exception],
    message: str,
) -> None:
    with pytest.raises(error_type, match=message):
        maximum_weight_matching(n_vertices, edges)
