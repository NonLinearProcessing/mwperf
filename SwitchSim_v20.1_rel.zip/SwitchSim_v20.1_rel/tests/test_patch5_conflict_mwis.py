from __future__ import annotations

from copy import deepcopy
import itertools
import random

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.conflict_graph_max_weight import (
    ConflictGraphMaxWeightScheduler,
    build_scheduler,
)
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.exact_priority import exact_lex_weights


QueueId = int | str
Conflict = tuple[QueueId, QueueId]


def _params(
    conflicts: tuple[Conflict, ...] | list[Conflict],
    *,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
    max_search_states: int | None = None,
) -> dict[str, object]:
    params: dict[str, object] = {
        "constraint": {"conflicts": [list(edge) for edge in conflicts]}
    }
    if priority is not None:
        params["priority"] = list(priority)
    if max_search_states is not None:
        params["max_search_states"] = max_search_states
    return params


def _build(
    queue_ids: tuple[QueueId, ...] | list[QueueId],
    conflicts: tuple[Conflict, ...] | list[Conflict],
    *,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
    max_search_states: int | None = None,
) -> tuple[ConflictGraphMaxWeightScheduler, QueueCatalog]:
    catalog = QueueCatalog(queue_ids)
    scheduler = ConflictGraphMaxWeightScheduler(
        _params(
            conflicts,
            priority=priority,
            max_search_states=max_search_states,
        )
    )
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="pairwise_conflicts")
    )
    return scheduler, catalog


def _select(
    scheduler: ConflictGraphMaxWeightScheduler,
    q_len: tuple[int, ...] | list[int] | np.ndarray,
    *,
    slot: int = 0,
    rng: np.random.Generator | None = None,
) -> ServiceDecision:
    if rng is None:
        rng = np.random.default_rng(527)
    return scheduler.select_service(np.asarray(q_len, dtype=np.int64), slot, rng)


def _oracle(
    catalog: QueueCatalog,
    conflicts: tuple[Conflict, ...] | list[Conflict],
    q_len: tuple[int, ...] | list[int],
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
) -> ServiceDecision:
    if priority is None:
        priority = catalog.queue_ids
    priority_indices = tuple(catalog.index_of(queue_id) for queue_id in priority)
    conflict_indices = tuple(
        (catalog.index_of(left), catalog.index_of(right))
        for left, right in conflicts
    )
    best_mask = 0
    best_key: tuple[int, tuple[int, ...]] = (-1, ())
    for mask in range(1 << catalog.n_queues):
        if any((mask >> index) & 1 and q_len[index] <= 0 for index in range(catalog.n_queues)):
            continue
        if any((mask >> left) & 1 and (mask >> right) & 1 for left, right in conflict_indices):
            continue
        key = (
            sum(q_len[index] for index in range(catalog.n_queues) if (mask >> index) & 1),
            tuple((mask >> index) & 1 for index in priority_indices),
        )
        if key > best_key:
            best_key = key
            best_mask = mask
    return ServiceDecision(
        tuple(
            queue_id
            for index, queue_id in enumerate(catalog.queue_ids)
            if (best_mask >> index) & 1
        )
    )


def _unchecked_duplicate_decision(queue_id: QueueId) -> ServiceDecision:
    decision = object.__new__(ServiceDecision)
    object.__setattr__(decision, "selected_queue_ids", (queue_id, queue_id))
    return decision


def test_path_maximizes_weight_instead_of_cardinality() -> None:
    conflicts: tuple[Conflict, ...] = (("heavy", "left"), ("heavy", "right"))
    scheduler, catalog = _build(("heavy", "left", "right"), conflicts)

    # One heavy queue has primary weight 10; the two compatible leaves total 9.
    assert _select(scheduler, (10, 6, 3)) == ServiceDecision(("heavy",))
    assert _select(scheduler, (10, 6, 3)) == _oracle(
        catalog, conflicts, (10, 6, 3)
    )
    assert scheduler.name == "conflict_graph_max_weight"
    assert scheduler.optimizer_id == "mwis_branch_memo_exact"
    assert scheduler.service_family == "pairwise_conflicts"


def test_empty_conflict_graph_selects_every_nonempty_queue() -> None:
    scheduler, _catalog = _build(("empty", 3, "busy", 9), ())

    assert _select(scheduler, (0, 7, 2, 0)) == ServiceDecision((3, "busy"))
    assert scheduler.effective_params == {
        "constraint": {"conflicts": []},
        "priority": None,
        "max_search_states": None,
    }


def test_components_are_combined_exactly() -> None:
    conflicts: tuple[Conflict, ...] = (
        ("a", "b"),
        ("b", "c"),
        ("x", "y"),
        ("x", "z"),
        ("y", "z"),
    )
    queue_ids = ("a", "b", "c", "isolated", "x", "y", "z")
    q_len = (4, 7, 4, 2, 8, 9, 1)
    scheduler, catalog = _build(queue_ids, conflicts)

    assert _select(scheduler, q_len) == _oracle(catalog, conflicts, q_len)
    assert _select(scheduler, q_len) == ServiceDecision(
        ("a", "c", "isolated", "y")
    )


@pytest.mark.parametrize("seed", range(80))
def test_small_random_graphs_match_exhaustive_enumeration(seed: int) -> None:
    source = random.Random(72_000 + seed)
    count = source.randrange(1, 11)
    queue_ids: tuple[QueueId, ...] = tuple(
        index if index % 3 == 0 else f"q{index}" for index in range(count)
    )
    conflicts: list[Conflict] = []
    for left in range(count):
        for right in range(left + 1, count):
            if source.random() < 0.34:
                conflicts.append((queue_ids[left], queue_ids[right]))
    priority_list = list(queue_ids)
    source.shuffle(priority_list)
    q_len = tuple(source.randrange(0, 20) for _ in range(count))
    scheduler, catalog = _build(queue_ids, conflicts, priority=priority_list)

    assert _select(scheduler, q_len, slot=seed) == _oracle(
        catalog, conflicts, q_len, priority_list
    )


def test_every_graph_on_four_vertices_matches_exhaustive_enumeration() -> None:
    queue_ids = ("a", "b", "c", "d")
    possible = tuple(itertools.combinations(queue_ids, 2))
    q_len = (5, 3, 8, 6)
    priority = tuple(reversed(queue_ids))
    for edge_mask in range(1 << len(possible)):
        conflicts = tuple(
            edge for index, edge in enumerate(possible) if (edge_mask >> index) & 1
        )
        scheduler, catalog = _build(queue_ids, conflicts, priority=priority)
        assert _select(scheduler, q_len) == _oracle(
            catalog, conflicts, q_len, priority
        )


def test_exact_priority_and_arbitrary_size_composite_weights() -> None:
    queue_count = 75
    queue_ids = tuple(f"q{index:02d}" for index in range(queue_count))
    conflicts = tuple(
        (queue_ids[left], queue_ids[right])
        for left in range(queue_count)
        for right in range(left + 1, queue_count)
    )
    priority = tuple(reversed(queue_ids))
    scheduler, catalog = _build(queue_ids, conflicts, priority=priority)
    q_len = np.ones(queue_count, dtype=np.int64)

    assert max(exact_lex_weights(q_len, catalog, priority)) > np.iinfo(np.int64).max
    assert _select(scheduler, q_len) == ServiceDecision((priority[0],))


def test_many_disconnected_components_do_not_create_a_deep_or_product_search() -> None:
    queue_count = 180
    queue_ids = tuple(f"q{index:03d}" for index in range(queue_count))
    conflicts: list[Conflict] = []
    for first in range(0, queue_count, 3):
        triple = queue_ids[first : first + 3]
        conflicts.extend(itertools.combinations(triple, 2))
    scheduler, _catalog = _build(queue_ids, conflicts)

    decision = _select(scheduler, np.ones(queue_count, dtype=np.int64))

    assert decision.selected_count == queue_count // 3
    assert decision.selected_queue_ids == queue_ids[::3]


def test_constraint_canonicalization_is_pair_and_list_order_invariant() -> None:
    first = ConflictGraphMaxWeightScheduler(
        {
            "constraint": {"conflicts": [["z", 4], ["b", "a"], [9, 2]]},
            "priority": ["z", 4, "b", "a", 9, 2],
            "max_search_states": 1234,
        }
    )
    second = ConflictGraphMaxWeightScheduler(
        {
            "max_search_states": np.int64(1234),
            "priority": ("z", 4, "b", "a", 9, 2),
            "constraint": {"conflicts": [[2, 9], ["a", "b"], [4, "z"]]},
        }
    )

    assert first.effective_params == second.effective_params
    assert first.effective_params["constraint"] == {
        "conflicts": [[2, 9], [4, "z"], ["a", "b"]]
    }


@pytest.mark.parametrize(
    "params",
    [
        {},
        {"constraint": {}},
        {"constraint": {"conflicts": [], "extra": 1}},
        {"constraint": []},
        {"constraint": {"conflicts": "a-b"}},
        {"constraint": {"conflicts": [["a"]]}},
        {"constraint": {"conflicts": [["a", "b", "c"]]}},
        {"constraint": {"conflicts": ["ab"]}},
        {"constraint": {"conflicts": [["a", "a"]]}},
        {"constraint": {"conflicts": [["a", "b"], ["b", "a"]]}},
        {"constraint": {"conflicts": [[True, "a"]]}},
        {"constraint": {"conflicts": [[-1, "a"]]}},
        {"constraint": {"conflicts": [[" padded ", "a"]]}},
        {"constraint": {"conflicts": []}, "unknown": 1},
        {"constraint": {"conflicts": []}, "max_search_states": True},
        {"constraint": {"conflicts": []}, "max_search_states": 0},
        {"constraint": {"conflicts": []}, "max_search_states": -3},
        {"constraint": {"conflicts": []}, "max_search_states": 1.5},
    ],
)
def test_malformed_constraints_and_limits_fail_strictly(params: dict[str, object]) -> None:
    with pytest.raises(ValidationError):
        ConflictGraphMaxWeightScheduler(params)


def test_out_of_domain_conflict_fails_transactionally() -> None:
    scheduler = ConflictGraphMaxWeightScheduler(
        _params((("a", "outside"),))
    )

    with pytest.raises(ValidationError, match="outside the catalog"):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(QueueCatalog(("a", "b")), "pairwise_conflicts")
        )
    assert scheduler.scheduler_domain is None


@pytest.mark.parametrize("priority", [[], ["a"], ["a", "a"], ["a", "outside"]])
def test_priority_must_be_an_exact_catalog_permutation(
    priority: list[QueueId],
) -> None:
    with pytest.raises(ValidationError, match="priority"):
        scheduler = ConflictGraphMaxWeightScheduler(
            _params((("a", "b"),), priority=priority)
        )
        scheduler.configure_for_domain(
            QueueSchedulerDomain(QueueCatalog(("a", "b")), "pairwise_conflicts")
        )
        assert scheduler.scheduler_domain is None


def test_wrong_service_family_and_rebinding_fail_transactionally() -> None:
    scheduler = ConflictGraphMaxWeightScheduler(_params(()))
    with pytest.raises(ValidationError, match="pairwise_conflicts"):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(QueueCatalog(("q",)), "crossbar_matching")
        )
    assert scheduler.scheduler_domain is None

    first = QueueSchedulerDomain(QueueCatalog(("q",)), "pairwise_conflicts")
    second = QueueSchedulerDomain(QueueCatalog(("other",)), "pairwise_conflicts")
    scheduler.configure_for_domain(first)
    with pytest.raises(ValidationError, match="rebound"):
        scheduler.configure_for_domain(second)
    assert scheduler.scheduler_domain == first


def test_public_decision_validator_accepts_independent_set_and_rejects_conflict() -> None:
    scheduler, _catalog = _build(
        ("a", "b", "c", "d"),
        (("a", "b"), ("b", "c")),
    )

    assert scheduler.validate_service_decision(
        ServiceDecision(("d", "c", "a")), [1, 1, 1, 1]
    ) == ServiceDecision(("a", "c", "d"))
    with pytest.raises(ScheduleError, match="pairwise conflict"):
        scheduler.validate_service_decision(
            ServiceDecision(("a", "b")), [1, 1, 1, 1]
        )


@pytest.mark.parametrize(
    "decision",
    [
        ("a",),
        ServiceDecision(("outside",)),
        ServiceDecision(("b",)),
        _unchecked_duplicate_decision("a"),
    ],
)
def test_public_decision_validator_rejects_bad_identity_or_occupancy(
    decision: object,
) -> None:
    scheduler, _catalog = _build(("a", "b"), (("a", "b"),))
    with pytest.raises(ScheduleError):
        scheduler.validate_service_decision(decision, [1, 0])


def test_search_state_limit_fails_explicitly_and_never_returns_an_incumbent() -> None:
    queue_ids = tuple(f"q{index}" for index in range(9))
    conflicts = tuple(
        (queue_ids[index], queue_ids[(index + 1) % len(queue_ids)])
        for index in range(len(queue_ids))
    )
    limited, _catalog = _build(
        queue_ids,
        conflicts,
        max_search_states=1,
    )

    for slot in (4, 5):
        with pytest.raises(ScheduleError, match="exceeded max_search_states") as error:
            _select(limited, [1] * len(queue_ids), slot=slot)
        assert error.value.context == {
            "slot": slot,
            "max_search_states": 1,
            "states_explored": 2,
        }

    unlimited, catalog = _build(queue_ids, conflicts)
    assert _select(unlimited, [1] * len(queue_ids)) == _oracle(
        catalog, conflicts, [1] * len(queue_ids)
    )


def test_empty_and_trivially_independent_inputs_succeed_under_tight_limit() -> None:
    scheduler, _catalog = _build(("a", "b", "c"), (), max_search_states=1)
    assert _select(scheduler, (0, 0, 0)) == ServiceDecision.empty()
    assert _select(scheduler, (1, 2, 3)) == ServiceDecision(("a", "b", "c"))


def test_recursion_exhaustion_is_translated_to_schedule_error(monkeypatch) -> None:
    import voqsim.schedulers.conflict_graph_max_weight as module

    scheduler, _catalog = _build(("a", "b"), (("a", "b"),))

    def exhaust(_mask: int, _adjacency: tuple[int, ...]) -> tuple[int, ...]:
        raise RecursionError("probe")

    monkeypatch.setattr(module, "_component_masks", exhaust)
    with pytest.raises(ScheduleError, match="Python recursion depth") as error:
        _select(scheduler, (1, 1), slot=91)
    assert error.value.context["slot"] == 91


def test_selection_is_rng_neutral_and_fixed_input_deterministic() -> None:
    scheduler, _catalog = _build(
        ("a", "b", "c", "d"),
        (("a", "b"), ("b", "c"), ("c", "d"), ("d", "a")),
        priority=("d", "c", "b", "a"),
    )
    rng = np.random.default_rng(8_102)
    before = deepcopy(rng.bit_generator.state)

    first = _select(scheduler, (7, 7, 7, 7), slot=3, rng=rng)
    after = deepcopy(rng.bit_generator.state)
    second = _select(scheduler, (7, 7, 7, 7), slot=3, rng=rng)

    assert first == second == ServiceDecision(("b", "d"))
    assert before == after == rng.bit_generator.state


def test_selection_requires_binding_and_valid_queue_inputs() -> None:
    scheduler = ConflictGraphMaxWeightScheduler(_params(()))
    with pytest.raises(ValidationError, match="configured"):
        _select(scheduler, (1,))

    scheduler.configure_for_domain(
        QueueSchedulerDomain(QueueCatalog(("q",)), "pairwise_conflicts")
    )
    for bad_q_len in ([[1]], [1, 2], [-1], [0.5]):
        with pytest.raises(ValidationError):
            scheduler.select_service(bad_q_len, 0, np.random.default_rng(1))


def test_factory_returns_canonical_scheduler() -> None:
    scheduler = build_scheduler(_params(()))
    assert isinstance(scheduler, ConflictGraphMaxWeightScheduler)
    assert scheduler.to_dict()["params"] == {
        "constraint": {"conflicts": []},
        "priority": None,
        "max_search_states": None,
    }
