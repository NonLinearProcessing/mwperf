from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.errors import ScheduleError, ValidationError
from voqsim.kernel import build_simulation, validate_arrival_serviceability
from voqsim.queues import ServiceDecision
from voqsim.schedulers import (
    QueueSchedulerBase,
    SchedulerCapabilities,
    register_scheduler,
    unregister_scheduler,
)
from voqsim.types import JSONValue


SUBSET_SCHEDULER = "patch5_serviceable_subset"
NEVER_SCHEDULER = "patch5_never_service"
ALL_SCHEDULER = "patch5_all_nonempty"


class _ServiceableSubsetScheduler(QueueSchedulerBase):
    @property
    def name(self) -> str:
        return SUBSET_SCHEDULER

    @property
    def individually_serviceable_queue_ids(self) -> tuple[int | str, ...]:
        if self.scheduler_domain is None:
            return super().individually_serviceable_queue_ids
        raw = self.params.get("serviceable", [])
        return tuple(raw)  # type: ignore[arg-type]

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog = self.scheduler_domain.queue_catalog
        selected = tuple(
            queue_id
            for queue_id in self.individually_serviceable_queue_ids
            if int(vector[catalog.index_of(queue_id)]) > 0
        )
        return self.validate_service_decision(ServiceDecision(selected), vector)


class _NeverServiceScheduler(QueueSchedulerBase):
    @property
    def name(self) -> str:
        return NEVER_SCHEDULER

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        return self.validate_service_decision(ServiceDecision.empty(), vector)


class _AllNonemptyScheduler(QueueSchedulerBase):
    @property
    def name(self) -> str:
        return ALL_SCHEDULER

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog = self.scheduler_domain.queue_catalog
        return self.validate_service_decision(
            ServiceDecision(
                tuple(
                    catalog.queue_id_at(int(index))
                    for index in np.flatnonzero(vector)
                )
            ),
            vector,
        )


@pytest.fixture
def patch5_schedulers():
    queue_capabilities = SchedulerCapabilities.queue_vector(("unconstrained",))
    register_scheduler(
        SUBSET_SCHEDULER,
        _ServiceableSubsetScheduler,
        capabilities=queue_capabilities,
        replace=True,
    )
    register_scheduler(
        NEVER_SCHEDULER,
        _NeverServiceScheduler,
        capabilities=queue_capabilities,
        replace=True,
    )
    register_scheduler(
        ALL_SCHEDULER,
        _AllNonemptyScheduler,
        capabilities=queue_capabilities,
        replace=True,
    )
    try:
        yield
    finally:
        unregister_scheduler(SUBSET_SCHEDULER)
        unregister_scheduler(NEVER_SCHEDULER)
        unregister_scheduler(ALL_SCHEDULER)


def _generalized_trace_config(
    scheduler: str,
    *,
    scheduler_params: Mapping[str, JSONValue] | None = None,
    arrival_queue: str = "live",
    termination: str = "fixed_slots",
) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 17501, "slots": 1, "termination": termination},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": ["live", "blocked"],
        },
        "scheduler": {"name": scheduler, "params": dict(scheduler_params or {})},
        "arrival": {
            "family": "deterministic_trace",
            "events": [{"slot": 0, "queue_id": arrival_queue, "count": 1}],
        },
        "telemetry": {"write_slot_trace": False},
    }


def test_live_individually_unserviceable_queue_is_rejected_before_output_mutation(
    tmp_path: Path,
    patch5_schedulers,
) -> None:
    output_dir = tmp_path / "must-not-exist"
    sentinel = tmp_path / "sentinel"
    sentinel.write_bytes(b"unchanged")

    with pytest.raises(ValidationError, match="scheduler can never serve") as caught:
        build_simulation(
            _generalized_trace_config(
                SUBSET_SCHEDULER,
                scheduler_params={"serviceable": ["live"]},
                arrival_queue="blocked",
            ),
            output_dir=output_dir,
        )

    assert caught.value.context == {
        "arrival_family": "deterministic_trace",
        "scheduler": SUBSET_SCHEDULER,
        "service_family": "unconstrained",
        "unserviceable_live_queue_ids": ["blocked"],
    }
    assert not output_dir.exists()
    assert sentinel.read_bytes() == b"unchanged"


def test_zero_probability_queue_is_not_live_and_does_not_block_construction(
    tmp_path: Path,
    patch5_schedulers,
) -> None:
    raw = _generalized_trace_config(
        SUBSET_SCHEDULER,
        scheduler_params={"serviceable": ["live"]},
    )
    raw["arrival"] = {
        "family": "independent_marked_renewal",
        "sources": [
            {
                "id": "source",
                "interarrival": {"kind": "deterministic", "d": 1},
                "destination_pmf": [
                    {"queue_id": "live", "probability": 1.0},
                    {"queue_id": "blocked", "probability": 0.0},
                ],
            }
        ],
    }

    simulator = build_simulation(raw, output_dir=tmp_path / "valid")

    assert simulator.compiled_arrival.live_queue_ids() == ("live",)
    assert validate_arrival_serviceability(
        simulator.compiled_arrival,
        simulator.scheduler,
    ) == ("live",)


def test_generalized_drain_raises_after_first_no_progress_slot(
    tmp_path: Path,
    patch5_schedulers,
) -> None:
    simulator = build_simulation(
        _generalized_trace_config(
            NEVER_SCHEDULER,
            termination="fixed_slots_then_drain",
        ),
        output_dir=tmp_path / "stalled-generalized",
    )

    with pytest.raises(ScheduleError, match="drain slot made no progress") as caught:
        simulator.run()

    assert caught.value.context == {
        "slot": 1,
        "backlog_before": 1,
        "backlog_after": 1,
        "scheduler": NEVER_SCHEDULER,
        "algorithm_id": NEVER_SCHEDULER,
        "optimizer_id": None,
        "service_family": "unconstrained",
    }
    assert simulator.switch.total_occupancy() == 1


def test_normal_generalized_drain_completes(
    tmp_path: Path,
    patch5_schedulers,
) -> None:
    result = build_simulation(
        _generalized_trace_config(
            ALL_SCHEDULER,
            termination="fixed_slots_then_drain",
        ),
        output_dir=tmp_path / "normal-drain",
    ).run()

    assert result.slots_run == 2
    assert result.summary.to_dict()["metrics"]["completed_packets"] == 0
    assert result.summary.to_dict()["metadata"]["post_run_final_occupancy_packets"] == 0
