from __future__ import annotations

import pytest

from voqsim.errors import ValidationError
from voqsim.events import ArrivalAttempt
from voqsim.packet import Packet
from voqsim.queues import QueueBank, QueueCatalog, ServiceDecision


def _attempt(packet_id: int, queue_id: str, slot: int) -> ArrivalAttempt:
    return ArrivalAttempt.from_packet(
        Packet.for_queue(
            packet_id=packet_id,
            flow_id=packet_id,
            queue_id=queue_id,
            generation_slot=slot,
        )
    )


def test_total_and_peak_follow_enqueue_service_and_reset() -> None:
    bank = QueueBank(QueueCatalog(["a", "b"]), None)

    assert bank.total_occupancy() == 0
    assert bank.peak_occupancy() == 0
    assert type(bank.total_occupancy()) is int
    assert type(bank.peak_occupancy()) is int
    assert bank.is_empty()

    first = bank.enqueue_or_drop(
        [_attempt(0, "a", 0), _attempt(1, "a", 0), _attempt(2, "b", 0)],
        slot=0,
    )
    assert all(decision.accepted for decision in first)
    assert bank.total_occupancy() == 3
    assert bank.peak_occupancy() == 3
    assert not bank.is_empty()
    bank.assert_internal_consistency()

    bank.service(ServiceDecision(("a", "b")), slot=1)
    assert bank.total_occupancy() == 1
    assert bank.peak_occupancy() == 3
    bank.assert_internal_consistency()

    second = bank.enqueue_or_drop(
        [_attempt(3, "a", 1), _attempt(4, "a", 1), _attempt(5, "b", 1)],
        slot=1,
    )
    assert all(decision.accepted for decision in second)
    assert bank.total_occupancy() == 4
    assert bank.peak_occupancy() == 4
    bank.assert_internal_consistency()

    bank.reset()
    assert bank.total_occupancy() == 0
    assert bank.peak_occupancy() == 0
    assert bank.is_empty()
    bank.assert_internal_consistency()


def test_finite_drops_do_not_change_total_or_peak() -> None:
    bank = QueueBank(QueueCatalog(["q"]), 1)

    decisions = bank.enqueue_or_drop(
        [_attempt(0, "q", 0), _attempt(1, "q", 0), _attempt(2, "q", 0)],
        slot=0,
    )

    assert [decision.accepted for decision in decisions] == [True, False, False]
    assert bank.total_occupancy() == 1
    assert bank.peak_occupancy() == 1
    bank.assert_internal_consistency()


def test_full_consistency_check_rejects_corrupt_total() -> None:
    bank = QueueBank(QueueCatalog(["q"]), None)
    bank.enqueue_or_drop([_attempt(0, "q", 0)], slot=0)
    bank._total_occupancy = 0

    with pytest.raises(ValidationError, match="total occupancy is inconsistent"):
        bank.assert_internal_consistency()


def test_full_consistency_check_rejects_peak_below_current_total() -> None:
    bank = QueueBank(QueueCatalog(["q"]), None)
    bank.enqueue_or_drop([_attempt(0, "q", 0)], slot=0)
    bank._peak_occupancy = 0

    with pytest.raises(ValidationError, match="peak occupancy is below"):
        bank.assert_internal_consistency()
