from __future__ import annotations

from copy import deepcopy
import math

import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY, load_config
from voqsim.errors import ValidationError
from voqsim.experiments import (
    AuthoritativeDecodedValue,
    CutoffCampaign,
    RealizedVectorArrivalTrace,
    ScientificUnitIdentity,
    SeparationReplicate,
    TARGET_ROLES,
    TargetCampaign,
    four_target_campaign_from_mapping,
    run_paired_fanin_priority,
    separate_four_target_campaign,
)


QUEUE_IDS = ("q0", "q1", "q2")


def _fanin_config(priority: tuple[str, ...]) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            # This seed realizes _trace() under the isolated arrival RNG.
            "seed": 462,
            "slots": 4,
            "warmup_slots": 0,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": queue_id} for queue_id in QUEUE_IDS],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {
                    "conflicts": [
                        ["q0", "q1"],
                        ["q0", "q2"],
                        ["q1", "q2"],
                    ]
                },
                "priority": list(priority),
            },
        },
        "arrival": {
            "family": "iid_independent_bernoulli",
            "rates": {"default": 0.3, "overrides": []},
        },
        "telemetry": {
            "write_slot_trace": False,
            "observation": {"enabled": False, "block_slots": None, "targets": []},
        },
    }


def _trace() -> RealizedVectorArrivalTrace:
    return RealizedVectorArrivalTrace(
        queue_ids=QUEUE_IDS,
        vectors=((1, 1, 1), (0, 0, 0), (0, 0, 0), (0, 0, 0)),
    )


def test_paired_priority_reuses_one_trace_and_reports_only_redistribution(tmp_path) -> None:
    report = run_paired_fanin_priority(
        _fanin_config(QUEUE_IDS),
        _fanin_config(tuple(reversed(QUEUE_IDS))),
        _trace(),
        output_dir=tmp_path / "paired",
    )

    assert report.aggregate_backlog_path_equal is True
    assert report.aggregate_backlog_sum == 6
    assert report.final_aggregate_backlog == 0
    by_queue = {row.queue_id: row for row in report.redistribution}
    assert by_queue["q0"].current_backlog_sum == 1
    assert by_queue["q0"].reversed_backlog_sum == 3
    assert by_queue["q0"].mean_backlog_change == 0.5
    assert by_queue["q2"].current_backlog_sum == 3
    assert by_queue["q2"].reversed_backlog_sum == 1
    assert by_queue["q2"].mean_backlog_change == -0.5
    assert sum(row.current_departures for row in report.redistribution) == 3
    assert sum(row.reversed_departures for row in report.redistribution) == 3
    payload = report.to_dict()
    assert payload["shared_realized_vector_arrivals"] is True
    assert payload["arrival_trace_validation"] == "exact_slotwise_source_rng_replay"
    assert "realized_vector_arrival_trace" not in payload
    provenance = payload["realized_vector_arrival_stream"]
    assert provenance["construction"] == "declared_source_with_slot_isolated_arrival_rng"
    assert provenance["queue_ids"] == list(QUEUE_IDS)
    assert provenance["slots"] == 4
    assert provenance["actual_seed"] == 462
    assert provenance["total_packets"] == 3
    assert provenance["maximum_queue_count_in_one_slot"] == 1
    assert payload["source_arrival_law"]["family"] == "iid_independent_bernoulli"
    assert "aggregate_path" not in payload
    current_q0 = {row.backlog: row for row in by_queue["q0"].current_response}
    reversed_q0 = {row.backlog: row for row in by_queue["q0"].reversed_response}
    assert (current_q0[1].exposure, current_q0[1].served, current_q0[1].response) == (
        1,
        1,
        1.0,
    )
    assert (reversed_q0[1].exposure, reversed_q0[1].served) == (3, 1)
    assert reversed_q0[1].response == pytest.approx(1 / 3)


def test_paired_priority_rejects_nonpriority_changes_and_nonfanin_topology(tmp_path) -> None:
    current = _fanin_config(QUEUE_IDS)
    changed = _fanin_config(tuple(reversed(QUEUE_IDS)))
    changed["metadata"] = {"different_scientific_condition": True}
    with pytest.raises(ValidationError, match="may differ only"):
        run_paired_fanin_priority(current, changed, _trace(), output_dir=tmp_path / "changed")

    nonfanin = _fanin_config(QUEUE_IDS)
    nonfanin["scheduler"]["params"]["constraint"]["conflicts"] = []  # type: ignore[index]
    nonfanin_reversed = deepcopy(nonfanin)
    nonfanin_reversed["scheduler"]["params"]["priority"] = list(reversed(QUEUE_IDS))  # type: ignore[index]
    rejected_root = tmp_path / "nonfanin"
    with pytest.raises(ValidationError, match="not fan-in"):
        run_paired_fanin_priority(
            nonfanin,
            nonfanin_reversed,
            _trace(),
            output_dir=rejected_root,
        )
    assert not rejected_root.exists()


def test_paired_priority_validates_source_law_before_trace_injection(tmp_path) -> None:
    current = _fanin_config(QUEUE_IDS)
    reversed_config = _fanin_config(tuple(reversed(QUEUE_IDS)))
    reversed_config["arrival"]["rates"] = {  # type: ignore[index]
        "default": 0.2,
        "overrides": [],
    }

    with pytest.raises(ValidationError, match="same source arrival law"):
        run_paired_fanin_priority(
            current,
            reversed_config,
            _trace(),
            output_dir=tmp_path / "source-law-mismatch",
        )
    assert not (tmp_path / "source-law-mismatch").exists()


def test_paired_priority_rejects_trace_outside_declared_source_support(tmp_path) -> None:
    impossible = RealizedVectorArrivalTrace(
        queue_ids=QUEUE_IDS,
        vectors=((2, 0, 0), (0, 0, 0), (0, 0, 0), (0, 0, 0)),
    )
    root = tmp_path / "impossible-source-trace"

    with pytest.raises(ValidationError, match="does not exactly replay"):
        run_paired_fanin_priority(
            _fanin_config(QUEUE_IDS),
            _fanin_config(tuple(reversed(QUEUE_IDS))),
            impossible,
            output_dir=root,
        )

    assert not root.exists()


def test_paired_priority_requires_exact_source_rng_replay(tmp_path) -> None:
    supported_but_wrong = RealizedVectorArrivalTrace(
        queue_ids=QUEUE_IDS,
        vectors=((0, 1, 1), (0, 0, 0), (0, 0, 0), (0, 0, 0)),
    )

    with pytest.raises(ValidationError, match="does not exactly replay"):
        run_paired_fanin_priority(
            _fanin_config(QUEUE_IDS),
            _fanin_config(tuple(reversed(QUEUE_IDS))),
            supported_but_wrong,
            output_dir=tmp_path / "wrong-source-realization",
        )


def _decoded(value: float) -> AuthoritativeDecodedValue:
    return AuthoritativeDecodedValue("ok", value)


def _replicate(replicate_id: str, offset: float, unit_index: int) -> SeparationReplicate:
    return SeparationReplicate(
        replicate_id=replicate_id,
        sampler_unit=ScientificUnitIdentity(
            100 + unit_index,
            f"ensemble-{unit_index}",
        ),
        finite_window_unit=ScientificUnitIdentity(200 + unit_index),
        stationary_reference_unit=ScientificUnitIdentity(300 + unit_index),
        sampled_fit_mean=_decoded(15.0 + offset),
        finite_window_fit_mean=_decoded(13.0 + offset / 2.0),
        stationary_fit_mean=_decoded(12.0 + offset / 2.0),
        stationary_mean=_decoded(10.0 + offset / 2.0),
    )


def _scientific_conditions(
    role: str,
    target_id: str,
    *,
    replicates: int = 2,
) -> dict[str, object]:
    return {
        "arrival_law": {"family": "fixture_iid", "parameters": {"load": 0.5}},
        "slot_convention": "service_before_arrival",
        "initial_conditions": {
            "sampler": "empty_queues",
            "finite_window": "empty_queues",
            "stationary_reference": "empty_queues",
        },
        "scheduler_tie_policy": {
            "scheduler": "fixture_max_weight",
            "tie_policy": "declared_priority",
        },
        "target_definition": {
            "system_id": f"{role}-system",
            "system_kind": role,
            "queue_id": target_id,
        },
        "independent_run_seeds": {
            "sampler": list(range(100, 100 + replicates)),
            "finite_window": list(range(200, 200 + replicates)),
            "stationary_reference": list(range(300, 300 + replicates)),
        },
        "sampler_ensemble_ids": [
            f"ensemble-{index}" for index in range(replicates)
        ],
        "random_streams": {
            "sampler": {"engine": "fixture", "domain": "sampler"},
            "finite_window": {"engine": "fixture", "domain": "ordinary_short"},
            "stationary_reference": {"engine": "fixture", "domain": "ordinary_long"},
        },
        "measurement_windows": {
            "sampler": [0, 100],
            "finite_window": [0, 100],
            "stationary_reference": [1000, 2000],
        },
        "reporting_blocks": {
            "sampler": [[0, 50], [50, 100]],
            "finite_window": [[0, 50], [50, 100]],
            "stationary_reference": [[1000, 1500], [1500, 2000]],
        },
        "buffer_policy": "NoDrop",
        "sampler_weighting": {"convention": "authoritative_external"},
        "sampler_resampling": {"convention": "authoritative_external"},
    }


def _campaigns() -> tuple[TargetCampaign, ...]:
    return tuple(
        TargetCampaign(
            role=role,
            target_id=f"{role}-target",
            scientific_conditions=_scientific_conditions(
                role,
                f"{role}-target",
            ),
            cutoffs=(
                CutoffCampaign(
                    4,
                    (_replicate("r0", 0.0, 0), _replicate("r1", 1.0, 1)),
                ),
            ),
        )
        for role in TARGET_ROLES
    )


def test_four_target_separation_uses_complete_independent_replicates() -> None:
    report = separate_four_target_campaign(_campaigns())
    assert tuple(target.role for target in report.targets) == TARGET_ROLES
    cutoff = report.targets[0].cutoffs[0]
    assert cutoff.status == "ok"
    assert cutoff.compression.value == pytest.approx(2.0)
    assert cutoff.finite_window_construction.value == pytest.approx(1.0)
    assert cutoff.sampling.value == pytest.approx(2.25)
    assert cutoff.total.value == pytest.approx(5.25)
    assert cutoff.accounting_residual == pytest.approx(0.0)
    assert cutoff.total.standard_error == pytest.approx(0.25)
    assert cutoff.total.independent_replicates == 2
    payload = report.to_dict()
    assert payload["decoder_policy"] == "authoritative_outputs_only"
    assert payload["uncertainty_unit"] == "explicit_seeded_scientific_unit_per_term"
    assert cutoff.replication_units[0]["sampler"] == {
        "actual_seed": 100,
        "ensemble_id": "ensemble-0",
    }


def test_four_target_separation_retains_failure_statuses_without_fabricating_values() -> None:
    campaigns = list(_campaigns())
    first = campaigns[0]
    failed = SeparationReplicate(
        replicate_id="failed",
        sampler_unit=ScientificUnitIdentity(102, "ensemble-2"),
        finite_window_unit=ScientificUnitIdentity(202),
        stationary_reference_unit=ScientificUnitIdentity(302),
        sampled_fit_mean=AuthoritativeDecodedValue("unsupported_profile"),
        finite_window_fit_mean=_decoded(13.0),
        stationary_fit_mean=_decoded(12.0),
        stationary_mean=_decoded(10.0),
    )
    campaigns[0] = TargetCampaign(
        role=first.role,
        target_id=first.target_id,
        scientific_conditions=_scientific_conditions(
            first.role,
            str(first.target_id),
            replicates=3,
        ),
        cutoffs=(CutoffCampaign(4, (*first.cutoffs[0].replicates, failed)),),
    )

    cutoff = separate_four_target_campaign(campaigns).targets[0].cutoffs[0]
    assert cutoff.status == "partial_with_failed_replicates"
    assert cutoff.compression.independent_replicates == 3
    assert cutoff.finite_window_construction.independent_replicates == 3
    assert cutoff.sampling.independent_replicates == 2
    assert cutoff.total.independent_replicates == 2
    assert cutoff.failed_input_status_counts == {"unsupported_profile": 1}
    failed_inputs = cutoff.replicates_with_failed_inputs[0]
    assert failed_inputs.replicate_id == "failed"
    assert dict(failed_inputs.component_statuses) == {
        "sampled_fit_mean": "unsupported_profile",
    }
    assert dict(failed_inputs.term_statuses) == {
        "sampling": "sampled_fit_mean:unsupported_profile",
        "total": "sampled_fit_mean:unsupported_profile",
    }
    assert cutoff.accounting_replicates == 2


def test_campaign_mapping_requires_all_roles_and_replicated_uncertainty_units() -> None:
    raw_targets = [
        {
            "role": role,
            "target_id": role,
            "scientific_conditions": _scientific_conditions(role, role),
            "cutoffs": [
                {
                    "cutoff": 12,
                    "replicates": [
                        {
                            "replicate_id": "r0",
                            "scientific_units": {
                                "sampler": {"actual_seed": 100, "ensemble_id": "ensemble-0"},
                                "finite_window": {"actual_seed": 200},
                                "stationary_reference": {"actual_seed": 300},
                            },
                            "sampled_fit_mean": {"status": "ok", "value": 4.0},
                            "finite_window_fit_mean": {"status": "ok", "value": 3.0},
                            "stationary_fit_mean": {"status": "ok", "value": 2.0},
                            "stationary_mean": {"status": "ok", "value": 1.0},
                        },
                        {
                            "replicate_id": "r1",
                            "scientific_units": {
                                "sampler": {"actual_seed": 101, "ensemble_id": "ensemble-1"},
                                "finite_window": {"actual_seed": 201},
                                "stationary_reference": {"actual_seed": 301},
                            },
                            "sampled_fit_mean": {"status": "ok", "value": 5.0},
                            "finite_window_fit_mean": {"status": "ok", "value": 4.0},
                            "stationary_fit_mean": {"status": "ok", "value": 3.0},
                            "stationary_mean": {"status": "ok", "value": 2.0},
                        },
                    ],
                }
            ],
        }
        for role in TARGET_ROLES
    ]
    parsed = four_target_campaign_from_mapping({"targets": raw_targets})
    report = separate_four_target_campaign(parsed)
    estimate = report.targets[0].cutoffs[0].total
    assert estimate.value == 3.0
    assert estimate.standard_error == 0.0
    assert estimate.status == "ok"

    with pytest.raises(ValidationError, match="each required scientific target role"):
        separate_four_target_campaign(parsed[:-1])


def test_campaign_preflight_rejects_incomplete_or_mismatched_scientific_identity() -> None:
    role = TARGET_ROLES[0]
    target_id = f"{role}-target"
    incomplete = _scientific_conditions(role, target_id)
    incomplete.pop("arrival_law")
    with pytest.raises(ValidationError, match="missing required scientific identity"):
        TargetCampaign(
            role=role,
            target_id=target_id,
            scientific_conditions=incomplete,
            cutoffs=(
                CutoffCampaign(
                    4,
                    (_replicate("r0", 0, 0), _replicate("r1", 1, 1)),
                ),
            ),
        )

    mismatched_window = _scientific_conditions(role, target_id)
    mismatched_window["measurement_windows"]["finite_window"] = [1, 100]  # type: ignore[index]
    with pytest.raises(ValidationError, match=r"exact same \[W,T\) window"):
        TargetCampaign(
            role=role,
            target_id=target_id,
            scientific_conditions=mismatched_window,
            cutoffs=(
                CutoffCampaign(
                    4,
                    (_replicate("r0", 0, 0), _replicate("r1", 1, 1)),
                ),
            ),
        )

    with pytest.raises(ValidationError, match="at least two"):
        CutoffCampaign(4, (_replicate("only", 0, 0),))


def test_campaign_preflight_rejects_reusing_one_system_for_multiple_roles() -> None:
    campaigns = list(_campaigns())
    second = campaigns[1]
    conditions = _scientific_conditions(second.role, str(second.target_id))
    conditions["target_definition"]["system_id"] = (  # type: ignore[index]
        campaigns[0].scientific_conditions["target_definition"]["system_id"]  # type: ignore[index]
    )
    campaigns[1] = TargetCampaign(
        role=second.role,
        target_id=second.target_id,
        scientific_conditions=conditions,
        cutoffs=second.cutoffs,
    )

    with pytest.raises(ValidationError, match="distinct scientific systems"):
        separate_four_target_campaign(campaigns)


def test_campaign_rejects_replayed_scientific_units_under_new_labels() -> None:
    role = TARGET_ROLES[0]
    target_id = f"{role}-target"
    first = _replicate("r0", 0.0, 0)
    replayed = SeparationReplicate(
        replicate_id="different-label",
        sampler_unit=first.sampler_unit,
        finite_window_unit=ScientificUnitIdentity(201),
        stationary_reference_unit=ScientificUnitIdentity(301),
        sampled_fit_mean=first.sampled_fit_mean,
        finite_window_fit_mean=first.finite_window_fit_mean,
        stationary_fit_mean=first.stationary_fit_mean,
        stationary_mean=first.stationary_mean,
    )

    with pytest.raises(ValidationError, match="sampler scientific units must be unique"):
        TargetCampaign(
            role=role,
            target_id=target_id,
            scientific_conditions=_scientific_conditions(role, target_id),
            cutoffs=(CutoffCampaign(4, (first, replayed)),),
        )


def test_decoded_status_contract_rejects_silent_missing_or_failed_values() -> None:
    with pytest.raises(ValidationError, match="requires a finite"):
        AuthoritativeDecodedValue("ok")
    with pytest.raises(ValidationError, match="must not carry"):
        AuthoritativeDecodedValue("unsupported_profile", math.nan)
    with pytest.raises(ValidationError, match="status vocabulary"):
        AuthoritativeDecodedValue("made_up_failure")
    with pytest.raises(ValidationError, match="nonnegative"):
        AuthoritativeDecodedValue("ok", -1.0)


def test_checked_in_16_queue_rho09_priority_templates_are_a_valid_pair() -> None:
    current = load_config("configs/v19_16q_fanin_rho09_priority_current.yaml")
    reversed_config = load_config("configs/v19_16q_fanin_rho09_priority_reversed.yaml")

    assert current.switch.n_queues == 16
    assert current.switch.capacity is None
    rates = current.arrival.params["rates"]
    resolved_rates = {
        row["queue_id"]: float(row["rate"])
        for row in rates["overrides"]
    }
    assert float(rates["default"]) == 0.0
    assert tuple(resolved_rates) == current.switch.catalog.queue_ids
    assert all(rate == pytest.approx(0.9 / 16) for rate in resolved_rates.values())
    assert sum(resolved_rates.values()) == pytest.approx(0.9)
    assert reversed_config.switch == current.switch
    assert reversed_config.run == current.run
    assert reversed_config.arrival == current.arrival
    assert reversed_config.metadata == current.metadata
    current_priority = tuple(current.scheduler.params["priority"])
    reversed_priority = tuple(reversed_config.scheduler.params["priority"])
    assert reversed_priority == tuple(reversed(current_priority))
