from __future__ import annotations

import json

import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.kernel import build_simulation


def _batch_config(
    *,
    queue_snapshot: str = "dense",
    write_slot_trace: bool = True,
) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 1234, "slots": 3},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 1,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": {
            "family": "iid_count_table",
            "outcomes": [
                {
                    "id": "batch",
                    "probability": 1,
                    "counts": [
                        {"queue_id": "q0", "count": 2},
                        {"queue_id": "q1", "count": 1},
                    ],
                }
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": queue_snapshot,
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": write_slot_trace,
            "observation": {"enabled": False, "block_slots": None, "targets": []},
        },
    }


def test_generic_summary_reports_latency_queue_and_schedule_metrics(tmp_path) -> None:
    result = build_simulation(_batch_config(), output_dir=tmp_path / "metrics").run()
    metrics = result.summary.to_dict()["metrics"]

    assert metrics["mean_sojourn_slots"] == pytest.approx(1.0)
    assert metrics["p95_sojourn_slots"] == 1
    assert metrics["max_sojourn_slots"] == 1
    assert metrics["mean_waiting_slots"] == pytest.approx(1.0)
    assert metrics["p95_waiting_slots"] == 1
    assert metrics["max_waiting_slots"] == 1
    assert metrics["drop_fraction_of_offered"] == pytest.approx(5 / 9)
    assert metrics["mean_drops_per_slot"] == pytest.approx(5 / 3)

    schedule = metrics["schedule"]
    assert schedule["sample_count"] == 3
    assert schedule["feasible_slots"] == 3
    assert schedule["selected_count"] == {
        "count": 3,
        "min": 0,
        "max": 1,
        "mean": pytest.approx(2 / 3),
        "p95": 1,
    }
    assert schedule["served_count"] == schedule["selected_count"]
    assert schedule["algorithm_ids"] == {"mwis_branch_memo_exact": 3}
    assert schedule["optimizer_ids"] == {"mwis_branch_memo_exact": 3}

    per_queue = {entry["queue_id"]: entry for entry in metrics["per_queue"]}
    assert per_queue["q0"]["max_occupancy_q_before"] == 1
    assert per_queue["q0"]["mean_utilization_q_after"] == pytest.approx(1.0)
    assert per_queue["q0"]["drop_fraction_of_offered"] == pytest.approx(0.5)
    assert per_queue["q0"]["mean_sojourn_slots"] == pytest.approx(1.0)
    assert per_queue["q1"]["drop_fraction_of_offered"] == pytest.approx(2 / 3)
    assert per_queue["q1"]["mean_sojourn_slots"] is None


def test_summary_retains_occupancy_metrics_when_slot_snapshots_are_disabled(tmp_path) -> None:
    result = build_simulation(
        _batch_config(queue_snapshot="disabled"),
        output_dir=tmp_path / "disabled-snapshots",
    ).run()
    first = json.loads(result.telemetry_path.read_text(encoding="utf-8").splitlines()[0])
    metrics = result.summary.to_dict()["metrics"]
    per_queue = {entry["queue_id"]: entry for entry in metrics["per_queue"]}

    assert first["q_before"] == {
        "mode": "disabled",
        "representation": "queue_vector",
        "queue_order": "service_model.queues[index]",
        "values": None,
    }
    assert first["q_after"]["values"] is None
    assert metrics["mean_total_occupancy_q_before"] == pytest.approx(4 / 3)
    assert metrics["mean_total_occupancy_q_after"] == pytest.approx(2.0)
    assert per_queue["q0"]["max_occupancy_q_before"] == 1
    assert per_queue["q0"]["max_occupancy_q_after"] == 1
    assert metrics["queue_backlog_levels"]["collection_status"] == "complete"


def test_summary_reports_backlog_conditioned_service_and_queue_metrics(tmp_path) -> None:
    result = build_simulation(_batch_config(), output_dir=tmp_path / "backlog").run()
    metrics = result.summary.to_dict()["metrics"]
    backlog = metrics["queue_backlog_levels"]
    overall = {entry["backlog_packets"]: entry for entry in backlog["overall"]}

    assert backlog["sample_point"] == "q_before"
    assert backlog["queue_set"] == "live_queues"
    assert backlog["live_queue_count"] == 2
    assert backlog["overall_total_queue_slot_samples"] == 6

    assert overall[0]["queue_slot_samples"] == 2
    assert overall[0]["service_packets"] == 0
    assert overall[0]["offered_packets"] == 3
    assert overall[0]["admitted_packets"] == 2
    assert overall[0]["dropped_packets"] == 1
    assert overall[0]["drop_fraction_of_offered_given_backlog"] == pytest.approx(1 / 3)
    assert overall[0]["mean_q_after_packets"] == pytest.approx(1.0)
    assert overall[0]["mean_delta_q_packets"] == pytest.approx(1.0)

    assert overall[1]["queue_slot_samples"] == 4
    assert overall[1]["service_packets"] == 2
    assert overall[1]["offered_packets"] == 6
    assert overall[1]["admitted_packets"] == 2
    assert overall[1]["dropped_packets"] == 4
    assert overall[1]["service_probability_given_backlog"] == pytest.approx(0.5)
    assert overall[1]["drop_fraction_of_offered_given_backlog"] == pytest.approx(2 / 3)
    assert overall[1]["mean_q_after_packets"] == pytest.approx(1.0)
    assert overall[1]["mean_delta_q_packets"] == pytest.approx(0.0)

    per_queue = {entry["queue_id"]: entry for entry in metrics["per_queue"]}
    q0 = {entry["backlog_packets"]: entry for entry in per_queue["q0"]["backlog_levels_q_before"]}
    q1 = {entry["backlog_packets"]: entry for entry in per_queue["q1"]["backlog_levels_q_before"]}
    assert q0[1]["service_packets"] == 2
    assert q0[1]["service_probability_given_backlog"] == pytest.approx(1.0)
    assert q0[1]["dropped_packets"] == 2
    assert q1[1]["service_packets"] == 0
    assert q1[1]["dropped_packets"] == 2


def test_summary_only_mode_retains_backlog_conditioned_metrics(tmp_path) -> None:
    result = build_simulation(
        _batch_config(queue_snapshot="disabled", write_slot_trace=False),
        output_dir=tmp_path / "summary-only",
    ).run()

    assert result.telemetry_path is None
    metrics = result.summary.to_dict()["metrics"]
    overall = {
        entry["backlog_packets"]: entry
        for entry in metrics["queue_backlog_levels"]["overall"]
    }
    assert overall[1]["service_packets"] == 2
    assert overall[1]["service_probability_given_backlog"] == pytest.approx(0.5)
    assert {entry["queue_id"] for entry in metrics["per_queue"]} == {"q0", "q1"}
