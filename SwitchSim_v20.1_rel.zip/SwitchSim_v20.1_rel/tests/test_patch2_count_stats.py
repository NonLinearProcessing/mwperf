from __future__ import annotations

import numpy as np
import pytest

from voqsim.events import ArrivalAttempt
from voqsim.packet import Packet
from voqsim.queues import QueueBank, QueueCatalog, ServiceDecision
from voqsim.stats import GenericRunStats
from voqsim.telemetry import GenericSlotTraceBuilder


def _attempt(packet_id: int, *, queue_id: str = "burst", slot: int = 0) -> ArrivalAttempt:
    return ArrivalAttempt.from_packet(
        Packet.for_queue(
            packet_id=packet_id,
            flow_id=0,
            queue_id=queue_id,
            generation_slot=slot,
        )
    )


def test_generic_backlog_statistics_report_conditional_count_means_above_one() -> None:
    catalog = QueueCatalog(("burst",))
    bank = QueueBank(catalog, queue_capacity=2)
    attempts = tuple(_attempt(packet_id) for packet_id in range(5))

    q_before = bank.queue_lengths()
    admissions = bank.enqueue_or_drop(attempts, slot=0)
    q_after = bank.queue_lengths()
    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(q_before)
        .set_service_decision(ServiceDecision.empty())
        .set_offered_attempts(attempts)
        .set_admissions(admissions)
        .set_q_after(q_after)
        .finalize()
    )

    stats = GenericRunStats.from_catalog(
        catalog,
        live_queue_ids=("burst",),
        queue_capacity=2,
    )
    stats.update(record, q_before_vector=q_before, q_after_vector=q_after)
    metrics = stats.metrics_dict()

    # Existing aggregate fields remain packet counts, not nonzero-arrival
    # indicators.
    assert metrics["offered_packets"] == 5
    assert metrics["admitted_packets"] == 2
    assert metrics["dropped_packets"] == 3

    conditioned = metrics["queue_backlog_levels"]
    assert conditioned["sample_point"] == "q_before"
    assert conditioned["queue_set"] == "live_queues"
    assert conditioned["capacity_packets"] == 2
    assert conditioned["live_queue_count"] == 1
    assert conditioned["overall_total_queue_slot_samples"] == 1
    assert len(conditioned["overall"]) == 1

    level = conditioned["overall"][0]
    assert level["backlog_packets"] == 0
    assert level["queue_slot_samples"] == 1
    assert level["offered_packets"] == 5
    assert level["admitted_packets"] == 2
    assert level["dropped_packets"] == 3
    assert level["mean_offered_packets_given_backlog"] == pytest.approx(5.0)
    assert level["mean_admitted_packets_given_backlog"] == pytest.approx(2.0)
    assert level["mean_dropped_packets_given_backlog"] == pytest.approx(3.0)
    assert level["mean_q_after_packets"] == pytest.approx(2.0)
    assert level["mean_delta_q_packets"] == pytest.approx(2.0)

    per_queue_level = metrics["per_queue"][0]["backlog_levels_q_before"][0]
    assert per_queue_level == level


def test_generic_backlog_statistics_are_bounded_and_exclude_nonlive_queues() -> None:
    catalog = QueueCatalog(("live", "inactive"))
    stats = GenericRunStats.from_catalog(
        catalog,
        live_queue_ids=("live",),
        queue_capacity=3,
    )

    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(np.asarray([2, 3], dtype=np.int64))
        .set_service_decision(ServiceDecision.empty())
        .set_q_after(np.asarray([2, 3], dtype=np.int64))
        .finalize()
    )
    stats.update(
        record,
        q_before_vector=np.asarray([2, 3], dtype=np.int64),
        q_after_vector=np.asarray([2, 3], dtype=np.int64),
    )
    metrics = stats.metrics_dict()

    overall = metrics["queue_backlog_levels"]["overall"]
    assert [entry["backlog_packets"] for entry in overall] == [2]
    per_queue = {entry["queue_id"]: entry for entry in metrics["per_queue"]}
    assert [entry["backlog_packets"] for entry in per_queue["live"]["backlog_levels_q_before"]] == [2]
    assert per_queue["inactive"]["backlog_levels_q_before"] == []


def test_generic_backlog_statistics_disable_histograms_for_unbounded_queues() -> None:
    catalog = QueueCatalog(("q",))
    stats = GenericRunStats.from_catalog(catalog, queue_capacity=None)
    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(np.asarray([0], dtype=np.int64))
        .set_service_decision(ServiceDecision.empty())
        .set_q_after(np.asarray([0], dtype=np.int64))
        .finalize()
    )

    stats.update(record, q_before_vector=np.asarray([0]), q_after_vector=np.asarray([0]))
    metrics = stats.metrics_dict()

    assert metrics["queue_backlog_levels"]["capacity_packets"] is None
    assert metrics["queue_backlog_levels"]["overall"] == []
    assert metrics["per_queue"][0]["backlog_levels_q_before"] == []


def test_generic_backlog_statistics_keep_sparse_levels_for_huge_finite_capacity() -> None:
    catalog = QueueCatalog(("q",))
    huge_capacity = 2**40
    stats = GenericRunStats.from_catalog(catalog, queue_capacity=huge_capacity)
    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(np.asarray([0], dtype=np.int64))
        .set_service_decision(ServiceDecision.empty())
        .set_q_after(np.asarray([0], dtype=np.int64))
        .finalize()
    )

    stats.update(record, q_before_vector=np.asarray([0]), q_after_vector=np.asarray([0]))
    metrics = stats.metrics_dict()

    assert metrics["queue_backlog_levels"]["capacity_packets"] == huge_capacity
    assert metrics["queue_backlog_levels"]["overall"][0]["backlog_packets"] == 0
    assert metrics["queue_backlog_levels"]["overall"][0]["queue_slot_samples"] == 1
    assert metrics["per_queue"][0]["backlog_levels_q_before"][0]["backlog_packets"] == 0


def test_generic_backlog_statistics_do_not_preallocate_capacity_by_queue_count() -> None:
    catalog = QueueCatalog(tuple(f"q{index}" for index in range(4_096)))
    stats = GenericRunStats.from_catalog(catalog, queue_capacity=512)

    assert stats._q_before_hist == {}
    assert stats._service_given_q_before == {}
    assert stats._offered_given_q_before == {}
