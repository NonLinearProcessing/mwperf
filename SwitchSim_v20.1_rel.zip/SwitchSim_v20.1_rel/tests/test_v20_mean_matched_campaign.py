from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

import pytest

from voqsim.analysis import (
    StreamingBlockAnalysis,
    analyze_pooled_target_block,
    certified_target_arrival_marginal,
)
from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY
from voqsim.kernel import build_simulation
from voqsim.telemetry import CompactObservationReader


_ARRIVAL_FAMILIES = (
    "iid_independent_bernoulli",
    "iid_independent_poisson",
)
_RATE = Decimal("0.3")
_CUTOFFS = (0, 1, 2, 8)
_WARMUP_SLOTS = 64
_STOP_SLOT = 512


@dataclass(frozen=True, slots=True)
class _Scenario:
    name: str
    seed: int
    queues: tuple[str, ...]
    target: str
    scheduler: str
    scheduler_params: dict[str, object]


_SCENARIOS = (
    _Scenario(
        name="crossbar",
        seed=7_700,
        queues=("q00", "q01", "q10", "q11"),
        target="q00",
        scheduler="crossbar_max_weight",
        scheduler_params={
            "constraint": {
                "inputs": ["i0", "i1"],
                "outputs": ["o0", "o1"],
                "edges": [
                    {"queue_id": "q00", "input": "i0", "output": "o0"},
                    {"queue_id": "q01", "input": "i0", "output": "o1"},
                    {"queue_id": "q10", "input": "i1", "output": "o0"},
                    {"queue_id": "q11", "input": "i1", "output": "o1"},
                ],
            },
            "priority": ["q00", "q01", "q10", "q11"],
        },
    ),
    _Scenario(
        name="hub_long_interval",
        seed=7_701,
        queues=("wide", "left", "right", "tail"),
        target="wide",
        scheduler="interval_max_weight",
        scheduler_params={
            "constraint": {
                "intervals": [
                    {"queue_id": "wide", "left": 0, "right": 4},
                    {"queue_id": "left", "left": 0, "right": 2},
                    {"queue_id": "right", "left": 2, "right": 4},
                    {"queue_id": "tail", "left": 4, "right": 5},
                ]
            },
            "priority": ["wide", "left", "right", "tail"],
        },
    ),
    _Scenario(
        name="wireless_strip",
        seed=7_702,
        queues=("q0", "q1", "q2", "q3", "q4"),
        target="q2",
        scheduler="conflict_graph_max_weight",
        scheduler_params={
            "constraint": {
                "conflicts": [
                    ["q0", "q1"],
                    ["q1", "q2"],
                    ["q2", "q3"],
                    ["q3", "q4"],
                ]
            },
            "priority": ["q2", "q1", "q3", "q0", "q4"],
        },
    ),
)


def _config(scenario: _Scenario, family: str) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": scenario.seed,
            "slots": _STOP_SLOT,
            "warmup_slots": _WARMUP_SLOTS,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": queue_id} for queue_id in scenario.queues],
        },
        "scheduler": {
            "name": scenario.scheduler,
            "params": deepcopy(scenario.scheduler_params),
        },
        "arrival": {
            "family": family,
            "rates": {"default": _RATE, "overrides": []},
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "sparse_nonzero",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": False,
            "observation": {
                "enabled": True,
                "block_slots": None,
                "targets": [{"queue_id": scenario.target, "gap": "exact"}],
            },
        },
    }


def _run_arm(
    scenario: _Scenario,
    family: str,
    output_dir: Path,
) -> tuple[object, StreamingBlockAnalysis]:
    simulator = build_simulation(_config(scenario, family), output_dir=output_dir)
    result = simulator.run()

    # This campaign deliberately emits only aggregated scientific observations.
    assert result.telemetry_path is None
    assert not (output_dir / "telemetry.jsonl").exists()
    assert result.observation_path is not None

    certification = certified_target_arrival_marginal(
        simulator.compiled_arrival,
        scenario.target,
    )
    assert certification.status == "ok"
    assert certification.marginal is not None

    with CompactObservationReader(result.observation_path) as reader:
        targets = tuple(reader.iter_targets())
        blocks = tuple(reader.iter_blocks())
        levels = tuple(reader.iter_levels())
        assert len(targets) == len(blocks) == 1
        assert targets[0].queue_id == scenario.target
        assert targets[0].gap_mode == "exact"
        assert (blocks[0].start_slot, blocks[0].stop_slot) == (
            _WARMUP_SLOTS,
            _STOP_SLOT,
        )
        assert sum(level.exposure for level in levels) == _STOP_SLOT - _WARMUP_SLOTS
        assert len(levels) < _STOP_SLOT - _WARMUP_SLOTS
        report = analyze_pooled_target_block(
            [reader],
            target_id=targets[0].target_id,
            block_id=blocks[0].block_id,
            cutoffs=_CUTOFFS,
            arrival=certification.marginal,
            stationary_interpretation=True,
        )
        reader.integrity_check()

    return certification.marginal, report


@pytest.mark.parametrize("scenario", _SCENARIOS, ids=lambda item: item.name)
def test_mean_matched_bernoulli_poisson_campaign(
    scenario: _Scenario,
    tmp_path: Path,
) -> None:
    configs = {family: _config(scenario, family) for family in _ARRIVAL_FAMILIES}
    bernoulli_config = configs["iid_independent_bernoulli"]
    poisson_config = configs["iid_independent_poisson"]

    # The arms differ only in the count law; rates, topology, optimizer,
    # priority/tie policy, seed, warmup, and measurement window are fixed.
    for section in ("run", "switch", "scheduler", "telemetry"):
        assert bernoulli_config[section] == poisson_config[section]
    assert bernoulli_config["arrival"]["rates"] == poisson_config["arrival"]["rates"]

    arms = {
        family: _run_arm(scenario, family, tmp_path / scenario.name / family)
        for family in _ARRIVAL_FAMILIES
    }
    bernoulli_law, bernoulli = arms["iid_independent_bernoulli"]
    poisson_law, poisson = arms["iid_independent_poisson"]

    assert bernoulli_law.mean == poisson_law.mean == Fraction(3, 10)
    assert bernoulli_law.variance == Fraction(21, 100)
    assert poisson_law.variance == Fraction(3, 10)

    for law, report in arms.values():
        assert report.pooled.no_drop is True
        assert report.pooled.dropped == 0
        assert report.pooled.gap_mode == "exact"
        assert report.pooled.exposure == _STOP_SLOT - _WARMUP_SLOTS

        # Competition scale is available and obeys its exact accounting
        # identity; finite-sample values are intentionally not equated across
        # the two arrival laws.
        competition = report.gap_competition
        assert competition.status == "ok"
        assert competition.competition_mean is not None
        assert competition.competition_mean > 0
        assert competition.competition_ratio is not None
        assert competition.identity_residual == 0
        assert competition.inequality_margin is not None
        assert competition.inequality_margin >= 0

        # The whole requested cutoff sweep survives.  A populated cutoff
        # exposes the compression defect and its exact gap decomposition.
        assert tuple(cutoff.cutoff for cutoff in report.cutoffs) == _CUTOFFS
        assert len(report.finite_windows) == len(report.innovations) == len(_CUTOFFS)
        assert len(report.gap_cutoffs) == len(_CUTOFFS)
        first_cutoff = report.cutoffs[0]
        first_gap = report.gap_cutoffs[0]
        assert first_cutoff.status == first_gap.status == "ok"
        assert first_cutoff.compression_defect is not None
        assert first_gap.compression_total == first_cutoff.compression_defect
        assert first_gap.covariance_identity_residual == 0

        # The deliberately high final cutoff has no observed tail.  That
        # construction failure remains an explicit status while endpoint and
        # arrival accounting remain available; no observation is discarded.
        failed_cutoff = report.cutoffs[-1]
        failed_gap = report.gap_cutoffs[-1]
        finite_window = report.finite_windows[-1]
        assert failed_cutoff.cutoff == _CUTOFFS[-1]
        assert failed_cutoff.status == "no_tail_exposure"
        assert failed_cutoff.compression_defect is None
        assert failed_gap.status == "no_tail_exposure"
        assert failed_gap.compression_total is None
        assert finite_window.status == "ok"
        assert finite_window.eta_k is not None
        assert finite_window.expected_eta_1 is not None
        assert finite_window.expected_eta_2 is not None

        # NoDrop + explicit stationarity + the simulator slot convention are
        # the full gate for naming the difference a contention excess.
        isolated = report.isolated_server
        assert isolated.baseline_status == isolated.status == "ok"
        assert isolated.difference_label == "contention_excess"
        assert isolated.isolated_mean is not None
        assert isolated.raw_difference is not None
        assert isolated.contention_excess == isolated.raw_difference
        assert isolated.identity_right_hand_side is not None
        assert isolated.identity_residual is not None
        assert isolated.arrival_mean == law.mean
        assert isolated.arrival_variance == law.variance

    # Equal means but different count variance must produce the corresponding
    # distinct isolated-server references; this is a mathematical comparison,
    # not a noisy equality assertion on the simulated trajectories.
    assert bernoulli.isolated_server.isolated_mean == Fraction(3, 10)
    assert poisson.isolated_server.isolated_mean == Fraction(51, 140)
