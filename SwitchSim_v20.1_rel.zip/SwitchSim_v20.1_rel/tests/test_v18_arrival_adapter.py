from __future__ import annotations

from decimal import Decimal
from fractions import Fraction

from voqsim.analysis import certified_target_arrival_marginal
from voqsim.queues import QueueCatalog
from voqsim.traffic import (
    CompiledArrivalSpec,
    IIDCountTableArrival,
    IIDIndependentBernoulliArrival,
    MarkovCountKernelArrival,
)


def _catalog() -> QueueCatalog:
    return QueueCatalog(("left", "right"))


def test_independent_bernoulli_adapter_returns_exact_decimal_law_without_sampling() -> None:
    catalog = _catalog()
    model = IIDIndependentBernoulliArrival(
        catalog,
        {
            "rates": {
                "default": Decimal("0.5"),
                "overrides": [{"queue_id": "left", "rate": Decimal("0.25")}],
            }
        },
    )
    compiled = CompiledArrivalSpec(model=model, queue_catalog=catalog)

    result = certified_target_arrival_marginal(compiled, "left")

    assert result.status == "ok"
    assert result.marginal is not None
    assert result.marginal.pmf == {0: Fraction(3, 4), 1: Fraction(1, 4)}
    assert result.marginal.mean == Fraction(1, 4)
    assert result.marginal.variance == Fraction(3, 16)
    assert result.marginal.second_moment == Fraction(1, 4)


def test_count_table_adapter_marginalizes_joint_count_vectors_exactly() -> None:
    catalog = _catalog()
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {"id": "idle", "probability": Decimal("0.5"), "counts": []},
                {
                    "id": "left",
                    "probability": Decimal("0.25"),
                    "counts": [{"queue_id": "left", "count": 2}],
                },
                {
                    "id": "both",
                    "probability": Decimal("0.25"),
                    "counts": [
                        {"queue_id": "left", "count": 2},
                        {"queue_id": "right", "count": 1},
                    ],
                },
            ]
        },
    )
    compiled = CompiledArrivalSpec(model=model, queue_catalog=catalog)

    left = certified_target_arrival_marginal(compiled, "left")
    right = certified_target_arrival_marginal(compiled, "right")

    assert left.marginal is not None
    assert left.marginal.pmf == {0: Fraction(1, 2), 2: Fraction(1, 2)}
    assert left.marginal.mean == 1
    assert right.marginal is not None
    assert right.marginal.pmf == {0: Fraction(3, 4), 1: Fraction(1, 4)}
    assert right.marginal.mean == Fraction(1, 4)


def test_count_table_adapter_preserves_exact_decimal_probability_mass() -> None:
    catalog = _catalog()
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {
                    "id": "left",
                    "probability": Decimal("0.1"),
                    "counts": [{"queue_id": "left", "count": 1}],
                },
                {
                    "id": "both",
                    "probability": Decimal("0.9"),
                    "counts": [
                        {"queue_id": "left", "count": 1},
                        {"queue_id": "right", "count": 1},
                    ],
                },
            ]
        },
    )
    result = certified_target_arrival_marginal(
        CompiledArrivalSpec(model=model, queue_catalog=catalog),
        "left",
    )

    assert result.status == "ok"
    assert result.marginal is not None
    assert result.marginal.pmf == {1: Fraction(1)}
    assert result.marginal.mean == 1


def test_stateful_count_kernel_is_not_misrepresented_as_fresh_iid() -> None:
    catalog = _catalog()
    model = MarkovCountKernelArrival(
        catalog,
        {
            "states": ["off", "on"],
            "outcomes": [
                {"id": "idle", "counts": []},
                {
                    "id": "packet",
                    "counts": [{"queue_id": "left", "count": 1}],
                },
            ],
            "kernel": [
                {
                    "state": "off",
                    "outcome_id": "idle",
                    "next_state": "on",
                    "probability": Decimal(1),
                },
                {
                    "state": "on",
                    "outcome_id": "packet",
                    "next_state": "off",
                    "probability": Decimal(1),
                },
            ],
            "initial": {"state": "off"},
        },
    )
    result = certified_target_arrival_marginal(
        CompiledArrivalSpec(model=model, queue_catalog=catalog),
        "left",
    )

    assert result.status == "not_fresh_iid"
    assert result.marginal is None
