from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from voqsim import ArrivalCountVector as PublicArrivalCountVector
from voqsim.config import CONFIG_SCHEMA_VERSION, resolve_config, resolved_config_to_dict
from voqsim.errors import ValidationError
from voqsim.kernel import build_simulation
from voqsim.queues import QueueBank, QueueCatalog, QueueSpec, ServiceDecision
from voqsim.schedulers import (
    QueueSchedulerBase,
    SchedulerCapabilities,
    register_scheduler,
    unregister_scheduler,
)
from voqsim.traffic.compiler import (
    CompiledArrivalSpec,
    compile_arrival_from_sections,
)
from voqsim.traffic.count_arrivals import DeterministicTraceArrival
from voqsim.traffic.counts import ArrivalCountVector
from voqsim.traffic.materializer import ArrivalMaterializer


COUNT_TEST_SCHEDULER = "patch2_select_all_nonempty"


class _SelectAllNonempty(QueueSchedulerBase):
    """Unconstrained queue scheduler used only to exercise the generic path."""

    @property
    def name(self) -> str:
        return COUNT_TEST_SCHEDULER

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        catalog = self.scheduler_domain.queue_catalog
        return ServiceDecision(
            tuple(
                catalog.queue_id_at(int(index))
                for index in np.flatnonzero(vector > 0)
            )
        )


@pytest.fixture
def count_test_scheduler():
    register_scheduler(
        COUNT_TEST_SCHEDULER,
        _SelectAllNonempty,
        capabilities=SchedulerCapabilities.queue_vector(("unconstrained",)),
        replace=True,
    )
    try:
        yield
    finally:
        unregister_scheduler(COUNT_TEST_SCHEDULER)


def _trace_config(*, switch: dict[str, object], scheduler: str) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 17201, "slots": 2, "termination": "fixed_slots"},
        "switch": switch,
        "scheduler": {"name": scheduler, "params": {}},
        "arrival": {
            "family": "deterministic_trace",
            "events": [
                {"slot": 0, "queue_id": "q", "count": 2},
                {"slot": 0, "queue_id": "q", "count": 3},
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "write_slot_trace": True,
        },
    }


def test_arrival_count_vector_is_owned_read_only_and_catalog_addressed() -> None:
    assert PublicArrivalCountVector is ArrivalCountVector
    source = np.array([0, 5, 2], dtype=np.int64)
    counts = ArrivalCountVector(source)
    source[1] = 99

    assert tuple(counts) == (0, 5, 2)
    assert counts.total_count == 7
    assert counts.nonzero_items() == ((1, 5), (2, 2))
    assert not counts.array_view.flags.writeable
    with pytest.raises(ValueError):
        counts.array_view[0] = 1
    with pytest.raises(ValueError):
        counts.array_view.flags.writeable = True

    catalog = QueueCatalog((QueueSpec("a"), QueueSpec("b"), QueueSpec("c")))
    assert counts.active_queue_ids(catalog) == ("b", "c")
    with pytest.raises(ValidationError, match="length does not match"):
        counts.validate_catalog(QueueCatalog(("a", "b")))


@pytest.mark.parametrize("bad", [[0, -1], [True, 0], [0.5, 1]])
def test_arrival_count_vector_rejects_invalid_coordinates(bad) -> None:
    with pytest.raises(ValidationError):
        ArrivalCountVector(bad)


def test_count_five_materializes_five_attempts_and_capacity_two_drops_three() -> None:
    catalog = QueueCatalog((QueueSpec("q"), QueueSpec("idle")))
    model = DeterministicTraceArrival(
        catalog,
        {
            "events": [
                {"slot": 0, "queue_id": "q", "count": 2},
                {"slot": 0, "queue_id": "q", "count": 3},
            ]
        },
    )
    compiled = CompiledArrivalSpec(model=model, queue_catalog=catalog)
    materializer = ArrivalMaterializer(compiled)

    materialized = materializer.sample_and_materialize(0, np.random.default_rng(9))
    assert materialized.offered_counts == ArrivalCountVector([5, 0])
    assert materialized.total_attempts == 5
    assert materialized.packet_ids == (0, 1, 2, 3, 4)
    assert [attempt.queue_id for attempt in materialized.attempts] == ["q"] * 5

    bank = QueueBank(catalog, queue_capacity=2, allowed_arrival_queue_ids=("q",))
    decisions = bank.enqueue_or_drop(materialized.attempts, slot=0)
    assert [decision.accepted for decision in decisions] == [True, True, False, False, False]
    assert [decision.queue_occupancy_before for decision in decisions] == [0, 1, 2, 2, 2]
    assert bank.occupancy("q") == 2


def test_count_materialization_uses_catalog_order() -> None:
    catalog = QueueCatalog(("first", "second"))
    model = DeterministicTraceArrival(
        catalog,
        {
            "events": [
                {"slot": 0, "queue_id": "second", "count": 1},
                {"slot": 0, "queue_id": "first", "count": 1},
            ]
        },
    )
    materializer = ArrivalMaterializer(
        CompiledArrivalSpec(model=model, queue_catalog=catalog)
    )

    materialized = materializer.sample_and_materialize(0, np.random.default_rng(10))
    assert [(item.packet_id, item.queue_id) for item in materialized.attempts] == [
        (0, "first"),
        (1, "second"),
    ]


def test_count_trace_runs_through_canonical_crossbar_with_generic_telemetry(tmp_path: Path) -> None:
    raw = _trace_config(
        switch={
            "kind": "generalized",
            "queue_capacity": 2,
            "queues": [{"id": "q"}],
        },
        scheduler="crossbar_max_weight",
    )
    raw["scheduler"]["params"] = {
        "constraint": {
            "inputs": ["i"],
            "outputs": ["o"],
            "edges": [{"queue_id": "q", "input": "i", "output": "o"}],
        }
    }

    result = build_simulation(raw, output_dir=tmp_path / "canonical_count").run()
    metrics = result.summary.to_dict()["metrics"]
    assert metrics["offered_packets"] == 5
    assert metrics["admitted_packets"] == 2
    assert metrics["dropped_packets"] == 3
    assert metrics["completed_packets"] == 1

    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]
    assert records[0]["slot_metrics"]["offered_count"] == 5
    assert records[0]["slot_metrics"]["admitted_count"] == 2
    assert records[0]["slot_metrics"]["dropped_count"] == 3
    assert [event["packet_id"] for event in records[0]["offered_attempts"]] == list(range(5))


def test_count_trace_runs_end_to_end_on_non_crossbar_queue_domain(
    tmp_path: Path,
    count_test_scheduler,
) -> None:
    raw = _trace_config(
        switch={
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": ["q", "parallel"],
        },
        scheduler=COUNT_TEST_SCHEDULER,
    )
    raw["arrival"]["events"] = [
        {"slot": 0, "queue_id": "q", "count": 2},
        {"slot": 0, "queue_id": "parallel", "count": 1},
    ]

    simulator = build_simulation(raw, output_dir=tmp_path / "generalized_count")
    result = simulator.run()
    metrics = result.summary.to_dict()["metrics"]

    assert isinstance(simulator.switch, QueueBank)
    assert metrics["offered_packets"] == 3
    assert metrics["completed_packets"] == 2
    assert simulator.switch.queue_lengths().tolist() == [1, 0]

    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]
    assert records[1]["schedule"]["selected_queue_ids"] == ["q", "parallel"]
    assert {event["queue_id"] for event in records[1]["departures"]} == {"q", "parallel"}


def test_stateful_count_arrivals_stop_at_horizon_during_drain(
    tmp_path: Path,
    count_test_scheduler,
) -> None:
    raw = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 17202,
            "slots": 3,
            "termination": "fixed_slots_then_drain",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": ["q"],
        },
        "scheduler": {"name": COUNT_TEST_SCHEDULER, "params": {}},
        "arrival": {
            "family": "independent_marked_renewal",
            "sources": [
                {
                    "id": "every_slot",
                    "interarrival": {"kind": "deterministic", "d": 1},
                    "destination_pmf": [{"queue_id": "q", "probability": 1.0}],
                }
            ],
        },
        "telemetry": {
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "write_slot_trace": True,
        },
    }
    simulator = build_simulation(raw, output_dir=tmp_path / "drain")
    result = simulator.run()
    metrics = result.summary.to_dict()["metrics"]

    assert result.slots_run == 4
    assert metrics["offered_packets"] == 3
    assert metrics["admitted_packets"] == 3
    # Primary statistics and the raw trace cover [W,T); the final departure
    # occurs during drain and is intentionally outside measurement.
    assert metrics["completed_packets"] == 2
    assert simulator.compiled_arrival.model._expected_slot == 3

    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]
    assert [record["slot"] for record in records] == [0, 1, 2]
    assert result.summary.to_dict()["metadata"]["post_run_final_occupancy_packets"] == 0


def test_seeded_stochastic_count_run_replays_identical_event_stream(
    tmp_path: Path,
    count_test_scheduler,
) -> None:
    raw = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 17203, "slots": 40, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 64,
            "queues": ["q", "r"],
        },
        "scheduler": {"name": COUNT_TEST_SCHEDULER, "params": {}},
        "arrival": {
            "family": "independent_marked_renewal",
            "sources": [
                {
                    "id": "finite",
                    "interarrival": {
                        "kind": "finite_pmf",
                        "outcomes": [
                            {"d": 1, "probability": 0.6},
                            {"d": 3, "probability": 0.4},
                        ],
                    },
                    "destination_pmf": [
                        {"queue_id": "q", "probability": 0.3},
                        {"queue_id": "r", "probability": 0.7},
                    ],
                },
                {
                    "id": "geometric",
                    "interarrival": {
                        "kind": "geometric_grid",
                        "d_min": 1,
                        "delta": 1,
                        "p": 0.75,
                    },
                    "destination_pmf": [
                        {"queue_id": "q", "probability": 0.5},
                        {"queue_id": "r", "probability": 0.5},
                    ],
                },
            ],
        },
        "telemetry": {
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "write_slot_trace": True,
        },
    }

    first = build_simulation(raw, output_dir=tmp_path / "replay_a").run()
    second = build_simulation(raw, output_dir=tmp_path / "replay_b").run()
    first_trace = first.telemetry_path.read_bytes()
    second_trace = second.telemetry_path.read_bytes()

    assert first_trace == second_trace
    assert first.summary_path.read_bytes() == second.summary_path.read_bytes()
    records = [json.loads(line) for line in first_trace.decode("utf-8").splitlines()]
    assert sum(record["slot_metrics"]["offered_count"] for record in records) > 0


def test_compiler_binds_shared_round_model_to_run_horizon(
    tmp_path: Path,
    count_test_scheduler,
) -> None:
    raw = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 17204, "slots": 5},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 16,
            "queues": ["fast", "slow"],
        },
        "scheduler": {"name": COUNT_TEST_SCHEDULER, "params": {}},
        "arrival": {
            "family": "shared_joint_round_markov_renewal",
            "sources": [{"id": "a"}, {"id": "b"}],
            "states": ["only"],
            "initial": {"state": "only"},
            "outcomes": [
                {
                    "state": "only",
                    "next_state": "only",
                    "probability": 1.0,
                    "emissions": [
                        {"source_id": "a", "d": 1, "queue_id": "fast"},
                        {"source_id": "b", "d": 1_000_000_000, "queue_id": "slow"},
                    ],
                }
            ],
        },
        "telemetry": {"write_slot_trace": False},
    }
    simulator = build_simulation(raw, output_dir=tmp_path / "shared_horizon")
    model = simulator.compiled_arrival.model
    assert model.horizon == 5

    result = simulator.run()
    assert result.summary.to_dict()["metrics"]["offered_packets"] == 5
    assert model._pending == {}


def test_section_compiler_only_bounds_shared_round_when_horizon_is_explicit(
    count_test_scheduler,
) -> None:
    raw = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 17205, "slots": 5},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 4,
            "queues": ["q"],
        },
        "scheduler": {"name": COUNT_TEST_SCHEDULER, "params": {}},
        "arrival": {
            "family": "shared_joint_round_markov_renewal",
            "sources": [{"id": "source"}],
            "states": ["only"],
            "initial": {"state": "only"},
            "outcomes": [
                {
                    "state": "only",
                    "next_state": "only",
                    "probability": 1.0,
                    "emissions": [
                        {"source_id": "source", "d": 2_000, "queue_id": "q"}
                    ],
                }
            ],
        },
        "telemetry": {"write_slot_trace": False},
    }
    config = resolve_config(raw)

    unbounded = compile_arrival_from_sections(config.switch, config.arrival)
    assert unbounded.model.horizon is None
    rng = np.random.default_rng(17205)
    for slot in range(1_001):
        unbounded.model.sample(slot, rng)

    bounded = compile_arrival_from_sections(
        config.switch,
        config.arrival,
        horizon=3,
    )
    assert bounded.model.horizon == 3
    rng = np.random.default_rng(17205)
    for slot in range(3):
        bounded.model.sample(slot, rng)
    with pytest.raises(ValidationError, match="outside the configured arrival horizon"):
        bounded.model.sample(3, rng)


def test_count_config_round_trip_preserves_canonical_event_aggregation(
    count_test_scheduler,
) -> None:
    raw = _trace_config(
        switch={"kind": "generalized", "queue_capacity": 4, "queues": ["q"]},
        scheduler=COUNT_TEST_SCHEDULER,
    )
    # Parsing canonicalizes duplicate same-slot coordinates; serializing and
    # resolving that canonical form must not change the aggregated counts.
    config = resolve_config(raw, validate=False)
    canonical = resolved_config_to_dict(config)
    replay = resolve_config(canonical, validate=False)
    assert resolved_config_to_dict(replay) == canonical
