from __future__ import annotations

from dataclasses import fields
from decimal import Decimal
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys

from voqsim.analysis import (
    ArrivalMarginal,
    CutoffResult,
    analyze_pooled_target_block,
    cutoff_analysis,
    finite_window_accounting,
    normalize_level_masses,
)
from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY
from voqsim.kernel import build_simulation
from voqsim.telemetry import (
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    TargetSlotObservation,
)


ROOT = Path(__file__).resolve().parents[1]


def _write_zero_tail_fixture(path: Path) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=3,
        targets=[ObservationTarget("target", "q")],
        metadata={"actual_seed": 1},
    )
    rows = (
        TargetSlotObservation("target", 2, 4, 0, 2, 2, 0),
        TargetSlotObservation("target", 4, 3, 1, 0, 0, 0),
        TargetSlotObservation("target", 3, 2, 1, 0, 0, 0),
    )
    for slot, row in enumerate(rows):
        recorder.record_slot(slot, [row])
    recorder.complete()
    recorder.close()


def _zero_tail_arrival() -> ArrivalMarginal:
    probability = Fraction(9, 10_000_000)
    return ArrivalMarginal.from_pmf({0: 1 - probability, 2: probability})


def test_zero_tail_keeps_computable_balance_and_hinge(tmp_path: Path) -> None:
    path = tmp_path / "zero-tail.sqlite3"
    _write_zero_tail_fixture(path)

    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[4],
            arrival=_zero_tail_arrival(),
        )

    cutoff = report.cutoffs[0]
    finite = report.finite_windows[0]
    innovation = report.innovations[0]
    assert cutoff.status == "no_tail_exposure"
    assert cutoff.tau == cutoff.service_tail_mass == 0
    assert cutoff.tail_service is None
    assert cutoff.slack is None
    assert cutoff.association is None
    assert cutoff.compression_defect is None
    assert finite.eta_k == 0
    assert finite.beta_k == Fraction(3, 10_000_000)
    assert finite.tail_slack_left == 0
    assert finite.tail_slack_right == Fraction(3, 10_000_000)
    assert innovation.hinge == -Fraction(3, 10_000_000)
    assert innovation.innovation_corrected_balance_residual == 0
    assert (
        innovation.innovation_corrected_balance_residual_status
        == "algebraic_identity_by_construction"
    )
    assert innovation.numerical_status == "exact"


def test_nonstreaming_zero_tail_balance_uses_identifiable_formula() -> None:
    masses = normalize_level_masses(
        {2: 1, 3: 1, 4: 1},
        {3: 1, 4: 1},
    )
    arrival = _zero_tail_arrival()
    cutoff = cutoff_analysis(masses, 4, arrival.mean)
    result = finite_window_accounting(
        masses,
        {2: 1},
        {2: 1},
        3,
        arrival,
        cutoff=cutoff,
    )

    assert cutoff.tail_service is None
    assert cutoff.slack is None
    assert cutoff.compression_defect is None
    assert result.tail_slack_left == 0
    assert result.tail_slack_right == Fraction(3, 10_000_000)


def _three_target_config() -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "metadata": {},
        "run": {
            "seed": 123,
            "slots": 8,
            "warmup_slots": 0,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": f"q{index}"} for index in range(11)],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": []},
                "priority": [f"q{index}" for index in range(11)],
            },
        },
        "arrival": {
            "family": "iid_independent_bernoulli",
            "metadata": {},
            "rates": {
                "default": Decimal(0),
                "overrides": [
                    {"queue_id": "q10", "rate": Decimal(1)},
                    {"queue_id": "q2", "rate": Decimal("0.5")},
                ],
            },
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "disabled",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": False,
            "observation": {
                "enabled": True,
                "block_slots": None,
                "targets": [
                    {"queue_id": "q10", "gap": "exact"},
                    {"queue_id": "q2", "gap": "none"},
                    {"queue_id": "q0", "gap": "none"},
                ],
            },
        },
    }


def _run_report(results: Path, output: Path, *, stationary: bool) -> list[dict]:
    command = [
        sys.executable,
        str(ROOT / "tools" / "report_results.py"),
        "--sim-root",
        str(ROOT),
        "--output-dir",
        str(output),
        "--cutoffs",
        "0,4",
    ]
    if stationary:
        command.append("--stationary-interpretation")
    command.append(str(results))
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
    return [
        json.loads(line)
        for line in (output / "scientific_metrics.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
    ]


def test_report_qualifies_compression_and_emits_three_targets(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    result = build_simulation(_three_target_config(), output_dir=run_dir).run()
    assert result.observation_path is not None
    with CompactObservationReader(result.observation_path) as reader:
        assert [(target.target_id, target.queue_id) for target in reader.iter_targets()] == [
            ("target_0", "q0"),
            ("target_10", "q10"),
            ("target_2", "q2"),
        ]

    ordinary = _run_report(tmp_path, tmp_path / "report", stationary=False)
    stationary = _run_report(
        tmp_path,
        tmp_path / "stationary-report",
        stationary=True,
    )
    expected_targets = [
        ("target_0", "q0"),
        ("target_10", "q10"),
        ("target_2", "q2"),
    ]
    assert [(row["target_id"], row["queue_id"]) for row in ordinary] == expected_targets
    assert [(row["target_id"], row["queue_id"]) for row in stationary] == expected_targets

    for rows, requested in ((ordinary, False), (stationary, True)):
        for row in rows:
            assert row["stationary_interpretation_requested"] is requested
            analysis = row["analysis"]
            assert len(analysis["cutoffs"]) == 2
            assert len(analysis["finite_windows"]) == 2
            assert len(analysis["innovations"]) == 2
            assert analysis["pooled_totals"]["target_id"] == row["target_id"]
            assert analysis["pooled_totals"]["queue_id"] == row["queue_id"]
            for cutoff in analysis["cutoffs"]:
                assert "compression_defect" not in cutoff
                assert "status" not in cutoff
                assert "numerical_status" not in cutoff
                assert "finite_data_compression_expression" in cutoff
                assert "finite_data_status" in cutoff
                assert "arithmetic_status" in cutoff
                assert cutoff["compression_statistical_status"] in {
                    "not_computed",
                    "finite_data_estimate_no_stationarity_claim",
                }
            for innovation in analysis["innovations"]:
                assert "innovation_corrected_balance_residual" in innovation
                assert innovation[
                    "innovation_corrected_balance_residual_status"
                ] == "algebraic_identity_by_construction"

    offered_by_target = {
        row["target_id"]: row["analysis"]["pooled_totals"]["offered"]
        for row in ordinary
    }
    assert offered_by_target["target_0"] == 0
    assert offered_by_target["target_10"] == 8
    assert 0 < offered_by_target["target_2"] < 8
    compression_statuses = {
        cutoff["compression_statistical_status"]
        for row in ordinary
        for cutoff in row["analysis"]["cutoffs"]
    }
    assert compression_statuses == {
        "not_computed",
        "finite_data_estimate_no_stationarity_claim",
    }

    cutoff_fields = {field.name for field in fields(CutoffResult)}
    assert "compression_defect" in cutoff_fields
    assert "status" in cutoff_fields
