from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path

import numpy as np

from voqsim.config import NO_DROP_CAPACITY, resolve_config
from voqsim.experiments.paired_priority import (
    RealizedVectorArrivalTrace,
    run_paired_fanin_priority,
)
from voqsim.kernel import build_simulation
from voqsim.rng import (
    build_arrival_initial_rng,
    build_arrival_rng_for_slot,
)
from voqsim.traffic.compiler import compile_arrival_model, compile_arrival_spec
from voqsim.traffic.materializer import ArrivalMaterializer


QUEUE_IDS = ("q0", "q1")


def _telemetry(*, write_slot_trace: bool = False) -> dict[str, object]:
    return {
        "format": "jsonl",
        "queue_snapshot": "dense",
        "include_packet_events": False,
        "include_scheduler_state": False,
        "write_slot_trace": write_slot_trace,
        "observation": {"enabled": False, "block_slots": None, "targets": []},
    }


def _fanin_config(
    arrival: dict[str, object],
    *,
    seed: int = 1,
    slots: int = 4,
    warmup_slots: int = 0,
    termination: str = "fixed_slots",
    capacity: object = NO_DROP_CAPACITY,
    priority: tuple[str, ...] = QUEUE_IDS,
    write_slot_trace: bool = False,
) -> dict[str, object]:
    return {
        "schema_version": "4.0.0",
        "run": {
            "seed": seed,
            "slots": slots,
            "warmup_slots": warmup_slots,
            "termination": termination,
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": capacity,
            "queues": [{"id": queue_id} for queue_id in QUEUE_IDS],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": list(priority),
            },
        },
        "arrival": arrival,
        "telemetry": _telemetry(write_slot_trace=write_slot_trace),
    }


def _count_table(count: int, *, queue_id: str = "q0") -> dict[str, object]:
    return {
        "family": "iid_count_table",
        "outcomes": [
            {
                "id": "batch",
                "probability": Decimal(1),
                "counts": [{"queue_id": queue_id, "count": count}],
            }
        ],
    }


def _poisson_arrival() -> dict[str, object]:
    return {
        "family": "iid_independent_poisson",
        "rates": {
            "default": Decimal(0),
            "overrides": [
                {"queue_id": "q0", "rate": Decimal("2.5")},
                {"queue_id": "q1", "rate": Decimal("1.5")},
            ],
        },
    }


def test_compiler_uses_arrival_initial_stream_and_materializer_is_count_only() -> None:
    raw = _fanin_config(
        {
            "family": "markov_count_kernel",
            "states": ["off", "on"],
            "outcomes": [
                {"id": "idle", "counts": []},
                {
                    "id": "batch",
                    "counts": [{"queue_id": "q1", "count": 3}],
                },
            ],
            "kernel": [
                {
                    "state": "off",
                    "outcome_id": "idle",
                    "next_state": "on",
                    "probability": Decimal(1),
                },
                {
                    "state": "on",
                    "outcome_id": "batch",
                    "next_state": "off",
                    "probability": Decimal(1),
                },
            ],
            "initial": {
                "distribution": {
                    "off": Decimal("0.25"),
                    "on": Decimal("0.75"),
                }
            },
        },
        seed=40,
        slots=2,
    )
    config = resolve_config(raw)
    compiled = compile_arrival_spec(config)

    reference_initial_rng = build_arrival_initial_rng(40)
    expected_index = int(
        reference_initial_rng.choice(2, p=np.asarray([0.25, 0.75]))
    )
    assert compiled.model.resolved_initial_state == ("off", "on")[expected_index]
    assert compiled.queue_catalog.queue_ids == QUEUE_IDS
    assert compiled.live_queue_ids() == ("q1",)

    materializer = ArrivalMaterializer(compiled, initial_packet_id=10)
    reset_rng = np.random.default_rng(99)
    before_reset = json.dumps(reset_rng.bit_generator.state, sort_keys=True)
    materializer.reset(rng=reset_rng)
    assert json.dumps(reset_rng.bit_generator.state, sort_keys=True) == before_reset

    sample = materializer.sample(0, build_arrival_rng_for_slot(40, 0))
    batch = materializer.materialize(sample)
    expected_count = 0 if expected_index == 0 else 3
    assert tuple(batch.offered_counts) == (0, expected_count)
    assert batch.packet_ids == tuple(range(10, 10 + expected_count))
    assert all(attempt.queue_id == "q1" for attempt in batch.attempts)
    assert all(attempt.src_port is None for attempt in batch.attempts)


def test_count_batches_preserve_nodrop_and_finite_buffer_semantics(tmp_path: Path) -> None:
    nodrop = resolve_config(
        _fanin_config(_count_table(5), slots=1, capacity=NO_DROP_CAPACITY)
    )
    nodrop_result = build_simulation(
        nodrop,
        output_dir=tmp_path / "nodrop",
    ).run()
    nodrop_metrics = nodrop_result.summary.to_dict()["metrics"]
    assert nodrop_metrics["offered_packets"] == 5
    assert nodrop_metrics["admitted_packets"] == 5
    assert nodrop_metrics["dropped_packets"] == 0

    finite = resolve_config(_fanin_config(_count_table(5), slots=1, capacity=2))
    finite_result = build_simulation(
        finite,
        output_dir=tmp_path / "finite",
    ).run()
    finite_metrics = finite_result.summary.to_dict()["metrics"]
    assert finite_metrics["offered_packets"] == 5
    assert finite_metrics["admitted_packets"] == 2
    assert finite_metrics["dropped_packets"] == 3


def test_warmup_consumes_arrivals_and_drain_creates_none(tmp_path: Path) -> None:
    raw = _fanin_config(
        {
            "family": "deterministic_trace",
            "events": [{"slot": 0, "queue_id": "q0", "count": 3}],
        },
        slots=2,
        warmup_slots=1,
        termination="fixed_slots_then_drain",
    )
    simulator = build_simulation(
        resolve_config(raw),
        output_dir=tmp_path / "warmup-drain",
    )
    observed = []
    result = simulator.run(observers=observed.append)

    # Slot 0 consumes and admits the batch, but the measurement observer starts
    # at slot 1. Drain continues after slot 1 with arrivals disabled.
    assert [commit.slot for commit in observed] == [1]
    assert tuple(observed[0].q_before) == (3, 0)
    assert observed[0].offered_count == 0
    assert result.summary.to_dict()["metrics"]["offered_packets"] == 0
    assert result.slots_run == 4
    assert simulator.switch.total_occupancy() == 0


def test_runtime_records_algorithm_without_inventing_heuristic_optimizer(
    tmp_path: Path,
) -> None:
    raw = {
        "schema_version": "4.0.0",
        "run": {"seed": 8, "slots": 2},
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": "q0"}],
        },
        "scheduler": {
            "name": "crossbar_random_greedy_maximal",
            "params": {
                "constraint": {
                    "inputs": ["i0"],
                    "outputs": ["o0"],
                    "edges": [
                        {"queue_id": "q0", "input": "i0", "output": "o0"}
                    ],
                }
            },
        },
        "arrival": _count_table(2),
        "telemetry": _telemetry(write_slot_trace=True),
    }
    output = tmp_path / "heuristic"
    result = build_simulation(resolve_config(raw), output_dir=output).run()
    manifest = json.loads((output / "run_manifest.json").read_text(encoding="utf-8"))
    trace = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]

    assert manifest["scheduler_algorithm_id"] == "random_permutation_greedy_maximal"
    assert manifest["scheduler_optimizer_id"] is None
    assert {
        row["schedule"]["algorithm_id"] for row in trace
    } == {"random_permutation_greedy_maximal"}
    assert all("optimizer_id" not in row["schedule"] for row in trace)


def test_paired_poisson_replays_arbitrary_count_vectors_with_provenance(
    tmp_path: Path,
) -> None:
    current_raw = _fanin_config(
        _poisson_arrival(),
        seed=1,
        slots=4,
        priority=QUEUE_IDS,
    )
    reversed_raw = deepcopy(current_raw)
    reversed_raw["scheduler"]["params"]["priority"] = list(  # type: ignore[index]
        reversed(QUEUE_IDS)
    )
    config = resolve_config(current_raw)
    model = compile_arrival_model(config)
    vectors = tuple(
        tuple(
            model.sample(slot, build_arrival_rng_for_slot(1, slot)).offered_counts
        )
        for slot in range(4)
    )
    assert max(count for vector in vectors for count in vector) > 1
    trace = RealizedVectorArrivalTrace(QUEUE_IDS, vectors)

    report = run_paired_fanin_priority(
        current_raw,
        reversed_raw,
        trace,
        output_dir=tmp_path / "paired-poisson",
    )
    payload = report.to_dict()
    provenance = payload["realized_vector_arrival_stream"]
    assert payload["source_arrival_law"]["family"] == "iid_independent_poisson"
    assert provenance["maximum_queue_count_in_one_slot"] > 1
    assert provenance["total_packets"] == sum(sum(vector) for vector in vectors)
    assert len(provenance["trace_sha256"]) == 64
    assert provenance["initial_rng_domain"] == 5
    assert report.aggregate_backlog_path_equal is True
