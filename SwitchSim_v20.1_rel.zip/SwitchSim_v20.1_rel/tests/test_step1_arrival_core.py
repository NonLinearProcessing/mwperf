from __future__ import annotations

from decimal import Decimal
import json

import numpy as np
import pytest
import voqsim.traffic.count_arrivals as count_arrivals_module

from voqsim.arrival_config import parse_count_arrival_params
from voqsim.errors import ConfigError, ValidationError
from voqsim.queues import QueueCatalog
from voqsim.traffic.count_arrivals import (
    IIDCountTableArrival,
    IIDIndependentBernoulliArrival,
    IIDIndependentPoissonArrival,
    IIDMixedPoissonArrival,
    IndependentMarkedRenewalArrival,
    IndependentPrivateMarkovRenewalArrival,
    MarkovCountKernelArrival,
    SharedJointRoundMarkovRenewalArrival,
    build_count_arrival_model,
)


def _state(rng: np.random.Generator) -> str:
    return json.dumps(rng.bit_generator.state, sort_keys=True)


def _counts(model, slot: int, rng: np.random.Generator) -> tuple[int, ...]:
    sample = model.sample(slot, rng)
    assert sample.offered_counts is not None
    return tuple(sample.offered_counts)


@pytest.fixture
def catalog() -> QueueCatalog:
    return QueueCatalog(("zeta", 7, "alpha", "silent"))


def _rates(*overrides: tuple[object, object], default: object = Decimal(0)):
    return {
        "default": default,
        "overrides": [
            {"queue_id": queue_id, "rate": rate}
            for queue_id, rate in overrides
        ],
    }


def _tiny_probability_pair() -> tuple[Decimal, Decimal]:
    probability = Decimal("4e-324")
    complement = Decimal((0, tuple([9] * 323 + [6]), -324))
    return complement, probability


def _tiny_rare_modulation() -> dict[str, object]:
    complement, probability = _tiny_probability_pair()
    return {
        "scope": "shared",
        "states": [
            {"id": "ordinary", "probability": complement, "multiplier": 0},
            {
                "id": "rare",
                "probability": probability,
                "multiplier": Decimal("2.5e323"),
            },
        ],
    }


def test_iid_poisson_draws_one_positive_rate_vector_in_catalog_order(
    catalog: QueueCatalog,
) -> None:
    model = IIDIndependentPoissonArrival(
        catalog,
        {
            "rates": _rates(
                ("alpha", Decimal("1.7")),
                (7, Decimal(0)),
                ("zeta", Decimal("0.4")),
            )
        },
    )
    actual_rng = np.random.default_rng(9182)
    reference_rng = np.random.default_rng(9182)
    expected_live = reference_rng.poisson(np.asarray([0.4, 1.7]))

    assert _counts(model, 0, actual_rng) == (
        int(expected_live[0]),
        0,
        int(expected_live[1]),
        0,
    )
    assert _state(actual_rng) == _state(reference_rng)
    assert model.live_queue_ids() == ("zeta", "alpha")
    assert model.rates == (
        Decimal("0.4"),
        Decimal(0),
        Decimal("1.7"),
        Decimal(0),
    )


@pytest.mark.parametrize("scope", ["shared", "independent_queue"])
def test_mixed_poisson_has_normative_vectorized_draw_order(
    catalog: QueueCatalog,
    scope: str,
) -> None:
    params = {
        "rates": _rates(
            ("alpha", Decimal("0.75")),
            ("zeta", Decimal("0.25")),
        ),
        "modulation": {
            "scope": scope,
            "states": [
                {
                    "id": "off",
                    "probability": Decimal("0.75"),
                    "multiplier": Decimal(0),
                },
                {
                    "id": "burst",
                    "probability": Decimal("0.25"),
                    "multiplier": Decimal(4),
                },
            ],
            "mean_multiplier": Decimal(1),
            "second_moment_multiplier": Decimal(4),
        },
    }
    model = IIDMixedPoissonArrival(catalog, params)
    actual_rng = np.random.default_rng(761)
    reference_rng = np.random.default_rng(761)
    if scope == "shared":
        ticket = int(reference_rng.integers(0, 4, size=1, dtype=np.int64)[0])
        state = 0 if ticket < 3 else 1
        rates = np.asarray([0.25, 0.75]) * np.asarray([0.0, 4.0])[state]
    else:
        tickets = reference_rng.integers(0, 4, size=2, dtype=np.int64)
        states = (tickets >= 3).astype(np.intp)
        rates = np.asarray([0.25, 0.75]) * np.asarray([0.0, 4.0])[states]
    expected_live = reference_rng.poisson(rates)

    assert _counts(model, 0, actual_rng) == (
        int(expected_live[0]),
        0,
        int(expected_live[1]),
        0,
    )
    assert _state(actual_rng) == _state(reference_rng)
    assert model.modulation_mean == Decimal(1)
    assert model.modulation_second_moment == Decimal(4)
    assert model.modulation_variance == Decimal(3)


def test_mixed_poisson_ordinary_decimal_state_draw_has_fixed_replay(
    catalog: QueueCatalog,
) -> None:
    model = IIDMixedPoissonArrival(
        catalog,
        {
            "rates": _rates(
                ("zeta", Decimal("0.1")),
                ("alpha", Decimal("0.3")),
            ),
            "modulation": {
                "scope": "shared",
                "states": [
                    {"id": "off", "probability": Decimal("0.8"), "multiplier": 0},
                    {"id": "on", "probability": Decimal("0.2"), "multiplier": 5},
                ],
            },
        },
    )
    actual_rng = np.random.default_rng(3847)
    reference_rng = np.random.default_rng(3847)

    expected: list[tuple[int, ...]] = []
    for _slot_index in range(8):
        ticket = int(reference_rng.integers(0, 5, size=1, dtype=np.int64)[0])
        multiplier = 0.0 if ticket < 4 else 5.0
        draws = reference_rng.poisson(
            np.asarray([0.1, 0.3]) * multiplier
        )
        expected.append((int(draws[0]), 0, int(draws[1]), 0))

    assert [
        _counts(model, slot, actual_rng) for slot in range(len(expected))
    ] == expected
    assert _state(actual_rng) == _state(reference_rng)


def test_mixed_poisson_retains_subnormal_decimal_state_mass_exactly(
    catalog: QueueCatalog,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = IIDMixedPoissonArrival(
        catalog,
        {
            "rates": _rates(("zeta", Decimal("1e-323"))),
            "modulation": _tiny_rare_modulation(),
        },
    )
    sampler = model._modulation_sampler

    assert sampler.integer_total == 25 * 10**322
    assert sampler.integer_weights == (sampler.integer_total - 1, 1)
    assert model._conditional_rate_matrix[:, 0].tolist() == [0.0, 2.5]
    assert model.modulation_mean == Decimal(1)
    monkeypatch.setattr(
        count_arrivals_module._ExactDecimalCategorical,
        "_draw_arbitrary_tickets",
        lambda self, rng, size: (self.integer_total - 1,) * size,
    )
    actual_rng = np.random.default_rng(8)
    reference_rng = np.random.default_rng(8)
    expected = int(reference_rng.poisson(np.asarray([2.5]))[0])

    assert _counts(model, 0, actual_rng) == (expected, 0, 0, 0)
    assert _state(actual_rng) == _state(reference_rng)


def test_mixed_poisson_rejects_nonfinite_conditional_rate_during_build(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="float range"):
        IIDMixedPoissonArrival(
            catalog,
            {
                "rates": _rates(("zeta", Decimal(1))),
                "modulation": _tiny_rare_modulation(),
            },
        )


def test_mixed_poisson_rejects_numpy_unsupported_conditional_rate_during_build(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="supported Poisson range"):
        IIDMixedPoissonArrival(
            catalog,
            {
                "rates": _rates(("zeta", Decimal(1))),
                "modulation": {
                    "scope": "shared",
                    "states": [
                        {
                            "id": "ordinary",
                            "probability": Decimal("0.9999999999999999999"),
                            "multiplier": 0,
                        },
                        {
                            "id": "rare",
                            "probability": Decimal("1e-19"),
                            "multiplier": Decimal("1e19"),
                        },
                    ],
                },
            },
        )


def test_mixed_poisson_rejects_underflowing_conditional_rate_during_build(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="underflows"):
        IIDMixedPoissonArrival(
            catalog,
            {
                "rates": _rates(("zeta", Decimal("1e-10000"))),
                "modulation": {
                    "scope": "shared",
                    "states": [
                        {"id": "one", "probability": Decimal(1), "multiplier": 1}
                    ],
                },
            },
        )


def test_shared_mixing_draws_state_even_for_an_all_zero_rate_law(
    catalog: QueueCatalog,
) -> None:
    model = IIDMixedPoissonArrival(
        catalog,
        {
            "rates": _rates(),
            "modulation": {
                "scope": "shared",
                "states": [
                    {"id": "off", "probability": Decimal("0.5"), "multiplier": 0},
                    {"id": "on", "probability": Decimal("0.5"), "multiplier": 2},
                ],
            },
        },
    )
    actual_rng = np.random.default_rng(22)
    reference_rng = np.random.default_rng(22)
    reference_rng.integers(0, 2, size=1, dtype=np.int64)
    reference_rng.poisson(np.asarray([], dtype=float))

    assert _counts(model, 0, actual_rng) == (0, 0, 0, 0)
    assert _state(actual_rng) == _state(reference_rng)
    assert model.live_queue_ids() == ()


def test_bernoulli_preserves_explicit_zero_draw_coordinates_and_order(
    catalog: QueueCatalog,
) -> None:
    params = {
        "rates": _rates(
            ("alpha", Decimal("0.8")),
            (7, Decimal(0)),
            ("zeta", Decimal("0.2")),
        )
    }
    model = IIDIndependentBernoulliArrival(catalog, params)
    actual_rng = np.random.default_rng(85)
    reference_rng = np.random.default_rng(85)
    expected = (
        reference_rng.random(size=3) < np.asarray([0.8, 0.0, 0.2])
    ).astype(np.int64)

    assert _counts(model, 0, actual_rng) == (
        int(expected[2]),
        int(expected[1]),
        int(expected[0]),
        0,
    )
    assert _state(actual_rng) == _state(reference_rng)
    assert model.live_queue_ids() == ("zeta", "alpha")


def test_count_table_preserves_outcome_identity_and_ignores_zero_mass_support(
    catalog: QueueCatalog,
) -> None:
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {
                    "id": "idle",
                    "probability": Decimal(1),
                    "counts": [],
                },
                {
                    "id": "impossible",
                    "probability": Decimal(0),
                    "counts": [{"queue_id": "alpha", "count": 9}],
                },
            ]
        },
    )
    sample = model.sample(4, np.random.default_rng(2))

    assert tuple(sample.offered_counts) == (0, 0, 0, 0)
    assert sample.arrival_outcome_id == "idle"
    assert sample.arrival_outcome_index == 0
    assert model.live_queue_ids() == ()


def test_count_table_draw_uses_declared_outcome_order(catalog: QueueCatalog) -> None:
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {"id": "first", "probability": Decimal("0.3"), "counts": []},
                {
                    "id": "second",
                    "probability": Decimal("0.7"),
                    "counts": [{"queue_id": "alpha", "count": 3}],
                },
            ]
        },
    )
    actual_rng = np.random.default_rng(719)
    reference_rng = np.random.default_rng(719)
    ticket = int(reference_rng.integers(0, 10, size=1, dtype=np.int64)[0])
    expected_index = 0 if ticket < 3 else 1
    sample = model.sample(0, actual_rng)

    assert sample.arrival_outcome_index == expected_index
    assert sample.arrival_outcome_id == ("first", "second")[expected_index]
    assert _state(actual_rng) == _state(reference_rng)


def test_arbitrary_decimal_categorical_fallback_is_unbiased_for_mt19937(
    catalog: QueueCatalog,
) -> None:
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {
                    "id": "first",
                    "probability": Decimal("0.10000000000000000001"),
                    "counts": [],
                },
                {
                    "id": "second",
                    "probability": Decimal("0.19999999999999999999"),
                    "counts": [{"queue_id": "zeta", "count": 1}],
                },
                {
                    "id": "third",
                    "probability": Decimal("0.7"),
                    "counts": [{"queue_id": "zeta", "count": 2}],
                },
            ]
        },
    )
    rng = np.random.Generator(np.random.MT19937(732))
    indices = model._outcome_sampler.sample_indices(rng, size=30_000)
    frequencies = np.bincount(indices, minlength=3) / len(indices)

    assert frequencies == pytest.approx([0.1, 0.2, 0.7], abs=0.015)


def test_arbitrary_decimal_vector_draw_matches_repeated_scalar_draws(
    catalog: QueueCatalog,
) -> None:
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {
                    "id": "first",
                    "probability": Decimal("0.10000000000000000001"),
                    "counts": [],
                },
                {
                    "id": "second",
                    "probability": Decimal("0.89999999999999999999"),
                    "counts": [{"queue_id": "zeta", "count": 1}],
                },
            ]
        },
    )
    vector_rng = np.random.default_rng(903)
    scalar_rng = np.random.default_rng(903)

    vector = model._outcome_sampler.sample_indices(vector_rng, size=64)
    scalar = np.asarray(
        [
            model._outcome_sampler.sample_indices(scalar_rng)
            for _index in range(64)
        ]
    )

    assert np.array_equal(vector, scalar)
    assert _state(vector_rng) == _state(scalar_rng)


def test_factorized_and_joint_renewal_keep_tiny_categorical_mass_live(
    catalog: QueueCatalog,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    common, rare = _tiny_probability_pair()
    monkeypatch.setattr(
        count_arrivals_module._ExactDecimalCategorical,
        "_draw_arbitrary_tickets",
        lambda self, rng, size: (self.integer_total - 1,) * size,
    )
    factorized = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "factorized",
                    "interarrival": {
                        "kind": "finite_pmf",
                        "outcomes": [
                            {"d": 3, "probability": common},
                            {"d": 1, "probability": rare},
                        ],
                    },
                    "destination_pmf": [
                        {"queue_id": "zeta", "probability": common},
                        {"queue_id": "alpha", "probability": rare},
                    ],
                }
            ]
        },
    )
    joint = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "joint",
                    "joint_pmf": [
                        {
                            "d": 3,
                            "queue_id": "zeta",
                            "probability": common,
                        },
                        {
                            "d": 1,
                            "queue_id": "alpha",
                            "probability": rare,
                        },
                    ],
                }
            ]
        },
    )

    assert factorized.live_queue_ids() == ("zeta", "alpha")
    assert joint.live_queue_ids() == ("zeta", "alpha")
    assert _counts(factorized, 0, np.random.default_rng(1)) == (0, 0, 1, 0)
    assert _counts(joint, 0, np.random.default_rng(1)) == (0, 0, 1, 0)
    factorized_payload = factorized.to_dict()["sources"][0]
    joint_payload = joint.to_dict()["sources"][0]
    assert factorized_payload["interarrival"]["outcomes"][1]["probability"] == rare
    assert factorized_payload["destination_pmf"][1]["probability"] == rare
    assert joint_payload["joint_pmf"][1]["probability"] == rare


def test_private_markov_renewal_keeps_tiny_categorical_mass_live(
    catalog: QueueCatalog,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    common, rare = _tiny_probability_pair()
    monkeypatch.setattr(
        count_arrivals_module._ExactDecimalCategorical,
        "_draw_arbitrary_tickets",
        lambda self, rng, size: (self.integer_total - 1,) * size,
    )
    model = IndependentPrivateMarkovRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "private",
                    "states": ["ordinary", "rare"],
                    "initial": {
                        "distribution": {"ordinary": common, "rare": rare}
                    },
                    "gaps": [
                        {"state": "ordinary", "d": 3},
                        {"state": "rare", "d": 1},
                    ],
                    "transitions": [
                        {
                            "state": "ordinary",
                            "next_state": "ordinary",
                            "probability": Decimal(1),
                        },
                        {
                            "state": "rare",
                            "next_state": "ordinary",
                            "probability": common,
                        },
                        {
                            "state": "rare",
                            "next_state": "rare",
                            "probability": rare,
                        },
                    ],
                    "destination_pmf": [
                        {"queue_id": "zeta", "probability": common},
                        {"queue_id": "alpha", "probability": rare},
                    ],
                }
            ]
        },
    )
    rng = np.random.default_rng(2)

    assert model.live_queue_ids() == ("zeta", "alpha")
    assert _counts(model, 0, rng) == (0, 0, 1, 0)
    assert _counts(model, 1, rng) == (0, 0, 1, 0)
    payload = model.to_dict()["sources"][0]
    assert payload["initial"]["distribution"]["rare"] == rare
    assert payload["transitions"][2]["probability"] == rare
    assert payload["destination_pmf"][1]["probability"] == rare


def test_shared_round_renewal_keeps_tiny_categorical_mass_live(
    catalog: QueueCatalog,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    common, rare = _tiny_probability_pair()
    monkeypatch.setattr(
        count_arrivals_module._ExactDecimalCategorical,
        "_draw_arbitrary_tickets",
        lambda self, rng, size: (self.integer_total - 1,) * size,
    )
    model = SharedJointRoundMarkovRenewalArrival(
        catalog,
        {
            "sources": [{"id": "source"}],
            "states": ["ordinary", "rare"],
            "initial": {
                "distribution": {"ordinary": common, "rare": rare}
            },
            "outcomes": [
                {
                    "state": "ordinary",
                    "next_state": "ordinary",
                    "probability": Decimal(1),
                    "emissions": [
                        {"source_id": "source", "d": 3, "queue_id": "zeta"}
                    ],
                },
                {
                    "state": "rare",
                    "next_state": "ordinary",
                    "probability": common,
                    "emissions": [
                        {"source_id": "source", "d": 3, "queue_id": "zeta"}
                    ],
                },
                {
                    "state": "rare",
                    "next_state": "rare",
                    "probability": rare,
                    "emissions": [
                        {"source_id": "source", "d": 1, "queue_id": "alpha"}
                    ],
                },
            ],
        },
    )

    assert model.live_queue_ids() == ("zeta", "alpha")
    assert _counts(model, 0, np.random.default_rng(3)) == (0, 0, 1, 0)
    payload = model.to_dict()
    assert payload["initial"]["distribution"]["rare"] == rare
    assert payload["outcomes"][2]["probability"] == rare


def test_renewal_categorical_probabilities_must_sum_exactly(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(ValidationError, match="sum exactly"):
        IndependentMarkedRenewalArrival(
            catalog,
            {
                "sources": [
                    {
                        "id": "source",
                        "interarrival": {
                            "kind": "finite_pmf",
                            "outcomes": [
                                {"d": 1, "probability": Decimal("0.5")},
                                {
                                    "d": 2,
                                    "probability": Decimal("0.5000000001"),
                                },
                            ],
                        },
                        "destination_pmf": [
                            {"queue_id": "zeta", "probability": Decimal(1)}
                        ],
                    }
                ]
            },
        )


def test_markov_count_kernel_resolves_initial_on_separate_rng_and_reset_is_draw_free(
    catalog: QueueCatalog,
) -> None:
    params = {
        "states": ["off", "on"],
        "outcomes": [
            {"id": "idle", "counts": []},
            {"id": "packet", "counts": [{"queue_id": 7, "count": 2}]},
        ],
        "kernel": [
            {
                "state": "off",
                "outcome_id": "idle",
                "next_state": "on",
                "probability": Decimal(1),
            },
            {
                "state": "on",
                "outcome_id": "packet",
                "next_state": "off",
                "probability": Decimal(1),
            },
        ],
        "initial": {
            "distribution": {"off": Decimal("0.25"), "on": Decimal("0.75")}
        },
    }
    initial_rng = np.random.default_rng(40)
    reference_initial_rng = np.random.default_rng(40)
    ticket = int(
        reference_initial_rng.integers(0, 4, size=1, dtype=np.int64)[0]
    )
    initial_index = 0 if ticket < 1 else 1
    model = MarkovCountKernelArrival(catalog, params, initial_rng=initial_rng)

    assert model.resolved_initial_state == ("off", "on")[initial_index]
    assert _state(initial_rng) == _state(reference_initial_rng)
    reset_rng = np.random.default_rng(901)
    before_reset = _state(reset_rng)
    model.reset(reset_rng)
    assert _state(reset_rng) == before_reset
    sample = model.sample(0, np.random.default_rng(5))
    assert sample.state_before == model.resolved_initial_state
    assert sample.arrival_outcome_id == ("idle", "packet")[initial_index]
    assert tuple(sample.offered_counts) == (
        (0, 0, 0, 0) if initial_index == 0 else (0, 2, 0, 0)
    )
    model.reset()
    assert model.current_state == model.resolved_initial_state

    with pytest.raises(ValidationError, match="requires initial_rng"):
        MarkovCountKernelArrival(catalog, params)


def test_markov_kernel_flattens_outcome_then_next_state_in_declared_order(
    catalog: QueueCatalog,
) -> None:
    model = MarkovCountKernelArrival(
        catalog,
        {
            "states": ["a", "b"],
            "outcomes": [
                {"id": "zero", "counts": []},
                {"id": "batch", "counts": [{"queue_id": "zeta", "count": 4}]},
            ],
            "kernel": [
                {"state": "a", "outcome_id": "zero", "next_state": "a", "probability": Decimal("0.1")},
                {"state": "a", "outcome_id": "zero", "next_state": "b", "probability": Decimal("0.2")},
                {"state": "a", "outcome_id": "batch", "next_state": "a", "probability": Decimal("0.3")},
                {"state": "a", "outcome_id": "batch", "next_state": "b", "probability": Decimal("0.4")},
                {"state": "b", "outcome_id": "zero", "next_state": "a", "probability": Decimal(1)},
            ],
            "initial": {"state": "a"},
        },
    )
    actual_rng = np.random.default_rng(991)
    reference_rng = np.random.default_rng(991)
    ticket = int(reference_rng.integers(0, 10, size=1, dtype=np.int64)[0])
    flat_index = int(np.searchsorted([1, 3, 6, 10], ticket, side="right"))
    expected_outcome, expected_next = divmod(flat_index, 2)
    sample = model.sample(0, actual_rng)

    assert sample.arrival_outcome_id == ("zero", "batch")[expected_outcome]
    assert sample.state_after == ("a", "b")[expected_next]
    assert _state(actual_rng) == _state(reference_rng)


def test_all_new_models_reset_without_consuming_rng(catalog: QueueCatalog) -> None:
    models = [
        IIDIndependentBernoulliArrival(
            catalog, {"rates": _rates(("zeta", Decimal("0.5")))}
        ),
        IIDCountTableArrival(
            catalog,
            {
                "outcomes": [
                    {"id": "zero", "probability": Decimal(1), "counts": []}
                ]
            },
        ),
        IIDIndependentPoissonArrival(
            catalog, {"rates": _rates(("zeta", Decimal("0.5")))}
        ),
        IIDMixedPoissonArrival(
            catalog,
            {
                "rates": _rates(("zeta", Decimal("0.5"))),
                "modulation": {
                    "scope": "shared",
                    "states": [
                        {
                            "id": "one",
                            "probability": Decimal(1),
                            "multiplier": Decimal(1),
                        }
                    ],
                },
            },
        ),
        MarkovCountKernelArrival(
            catalog,
            {
                "states": ["s"],
                "outcomes": [{"id": "zero", "counts": []}],
                "kernel": [
                    {
                        "state": "s",
                        "outcome_id": "zero",
                        "next_state": "s",
                        "probability": Decimal(1),
                    }
                ],
                "initial": {"state": "s"},
            },
        ),
    ]
    for model in models:
        rng = np.random.default_rng(102)
        before = _state(rng)
        model.reset(rng)
        assert _state(rng) == before


def test_arrival_parser_keeps_exact_decimals_and_reports_mixed_moments() -> None:
    parsed = parse_count_arrival_params(
        "iid_mixed_poisson",
        {
            "family": "iid_mixed_poisson",
            "rates": _rates((7, 0.1), default=0.2),
            "modulation": {
                "scope": "independent_queue",
                "states": [
                    {"id": "off", "probability": 0.8, "multiplier": 0},
                    {"id": "burst", "probability": 0.2, "multiplier": 5},
                ],
            },
        },
    )

    assert parsed["rates"]["default"] == Decimal("0.2")
    assert parsed["rates"]["overrides"][0]["rate"] == Decimal("0.1")
    assert parsed["modulation"]["mean_multiplier"] == Decimal(1)
    assert parsed["modulation"]["second_moment_multiplier"] == Decimal(5)
    assert parse_count_arrival_params(
        "iid_mixed_poisson",
        {"family": "iid_mixed_poisson", **parsed},
    ) == parsed


@pytest.mark.parametrize(
    "mutate,match",
    [
        (
            lambda value: value["modulation"]["states"][0].update(
                probability=Decimal("0.79")
            ),
            "sum exactly",
        ),
        (
            lambda value: value["modulation"]["states"][1].update(
                multiplier=Decimal("4.9")
            ),
            "E\\[M\\] == 1 exactly",
        ),
        (
            lambda value: value["modulation"].update(scope="queue"),
            "scope",
        ),
        (
            lambda value: value["rates"].update(default="0.1"),
            "finite decimal",
        ),
    ],
)
def test_mixed_parser_rejects_nonexact_or_ambiguous_payloads(mutate, match) -> None:
    raw = {
        "family": "iid_mixed_poisson",
        "rates": _rates(),
        "modulation": {
            "scope": "shared",
            "states": [
                {"id": "off", "probability": Decimal("0.8"), "multiplier": 0},
                {"id": "burst", "probability": Decimal("0.2"), "multiplier": 5},
            ],
        },
    }
    mutate(raw)
    with pytest.raises(ConfigError, match=match):
        parse_count_arrival_params("iid_mixed_poisson", raw)


def test_poisson_never_clips_rng_unrepresentable_finite_rate(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="float range"):
        build_count_arrival_model(
            "iid_independent_poisson",
            catalog,
            {"rates": _rates(("zeta", Decimal("1e10000")))},
        )


def test_positive_rate_underflow_fails_instead_of_becoming_a_zero_rate(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="underflows"):
        IIDIndependentPoissonArrival(
            catalog,
            {"rates": _rates(("zeta", Decimal("1e-10000")))},
        )


def test_poisson_rejects_numpy_unsupported_rate_during_build(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="supported Poisson range"):
        IIDIndependentPoissonArrival(
            catalog,
            {"rates": _rates(("zeta", Decimal("1e19")))},
        )


def test_all_zero_poisson_law_constructs_and_samples_without_rng_draw(
    catalog: QueueCatalog,
) -> None:
    model = IIDIndependentPoissonArrival(catalog, {"rates": _rates()})
    rng = np.random.default_rng(3)
    before = _state(rng)

    assert _counts(model, 0, rng) == (0, 0, 0, 0)
    assert _state(rng) == before


def test_geometric_grid_probability_stays_decimal_until_rng_boundary(
    catalog: QueueCatalog,
) -> None:
    probability = Decimal("0.1250000000000000000000000001")
    model = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "source",
                    "interarrival": {
                        "kind": "geometric_grid",
                        "d_min": 1,
                        "delta": 2,
                        "p": probability,
                    },
                    "destination_pmf": [
                        {"queue_id": "zeta", "probability": Decimal(1)}
                    ],
                }
            ]
        },
    )

    assert model.to_dict()["sources"][0]["interarrival"]["p"] == probability


def test_geometric_grid_positive_probability_cannot_underflow_to_zero(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(OverflowError, match="underflows"):
        IndependentMarkedRenewalArrival(
            catalog,
            {
                "sources": [
                    {
                        "id": "source",
                        "interarrival": {
                            "kind": "geometric_grid",
                            "d_min": 1,
                            "delta": 1,
                            "p": Decimal("1e-10000"),
                        },
                        "destination_pmf": [
                            {"queue_id": "zeta", "probability": Decimal(1)}
                        ],
                    }
                ]
            },
        )
