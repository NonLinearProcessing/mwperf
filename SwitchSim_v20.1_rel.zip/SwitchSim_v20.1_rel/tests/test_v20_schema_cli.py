from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path

import pytest

from voqsim.cli import main
from voqsim.config import (
    CONFIG_SCHEMA_VERSION,
    dump_resolved_config,
    load_config,
    load_raw_config,
    migrate_config,
    migrate_config_file,
    resolve_config,
)
from voqsim.errors import ConfigError
from voqsim.rng import build_arrival_initial_rng, build_arrival_rng_for_slot
from voqsim.traffic.compiler import compile_arrival_model


def _constraint(queue_ids=("q0", "q1")):
    return {
        "inputs": [0, 1],
        "outputs": [0, 1],
        "edges": [
            {"queue_id": queue_ids[0], "input": 0, "output": 1},
            {"queue_id": queue_ids[1], "input": 1, "output": 0},
        ],
    }


def _canonical() -> dict:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 7, "slots": 4},
        "switch": {
            "kind": "generalized",
            "queue_capacity": "NoDrop",
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "crossbar_max_weight",
            "params": {"constraint": _constraint()},
        },
        "arrival": {
            "family": "iid_independent_poisson",
            "rates": {
                "default": Decimal("0.1"),
                "overrides": [{"queue_id": "q0", "rate": Decimal("2.5")}],
            },
        },
    }


@pytest.mark.parametrize(
    ("path", "key"),
    [
        ((), "schema_version"),
        (("switch",), "kind"),
        (("scheduler",), "name"),
        (("arrival",), "family"),
    ],
)
def test_schema4_requires_explicit_discriminators(path, key) -> None:
    raw = _canonical()
    target = raw
    for part in path:
        target = target[part]
    target.pop(key)
    with pytest.raises(ConfigError):
        resolve_config(raw)


@pytest.mark.parametrize(
    ("section", "legacy", "replacement"),
    [
        ("arrival", "factorized_bernoulli", "iid_independent_bernoulli"),
        ("arrival", "iid_table", "iid_count_table"),
        ("arrival", "markov_kernel", "markov_count_kernel"),
        ("scheduler", "random_maximal", "crossbar_random_greedy_maximal"),
        ("scheduler", "islip_rga", "crossbar_random_grant_accept"),
        ("scheduler", "islip_canonical", "crossbar_islip"),
    ],
)
def test_schema4_rejects_legacy_names_with_replacement(section, legacy, replacement) -> None:
    raw = _canonical()
    key = "family" if section == "arrival" else "name"
    raw[section][key] = legacy
    with pytest.raises(ConfigError) as caught:
        resolve_config(raw)
    assert caught.value.context["replacement"] == replacement


def test_json_and_yaml_decimal_round_trip(tmp_path: Path) -> None:
    raw = _canonical()
    raw["arrival"] = {
        "family": "iid_mixed_poisson",
        "rates": {"default": Decimal("0.1"), "overrides": []},
        "modulation": {
            "scope": "shared",
            "states": [
                {"id": "off", "probability": Decimal("0.8"), "multiplier": Decimal(0)},
                {"id": "burst", "probability": Decimal("0.2"), "multiplier": Decimal(5)},
            ],
        },
    }
    config = resolve_config(raw)
    assert config.arrival.params["rates"]["default"] == Decimal("0.1")
    assert config.arrival.params["modulation"]["mean_multiplier"] == Decimal(1)
    assert config.arrival.params["modulation"]["second_moment_multiplier"] == Decimal(5)

    for suffix in (".json", ".yaml"):
        path = dump_resolved_config(config, 7, tmp_path / f"resolved{suffix}")
        loaded = load_config(path)
        assert loaded == config.with_actual_seed(7)
        assert isinstance(loaded.arrival.params["rates"]["default"], Decimal)


def _legacy_bernoulli() -> dict:
    return {
        "schema_version": "3.1.0",
        "run": {"seed": 11, "slots": 5},
        "switch": {
            "kind": "legacy_crossbar",
            "n_ports": 2,
            "voq_capacity": 8,
            "allow_self_traffic": False,
        },
        "scheduler": {"name": "random_maximal", "params": {}},
        "arrival": {
            "family": "factorized_bernoulli",
            "allowed_edges": {"mode": "explicit", "edges": [[1, 0], [0, 1]]},
            "alphabet_constraint": "unrestricted",
            "lambda": {"default": Decimal("0.25"), "overrides": {"[1,0]": Decimal(0)}},
        },
    }


def test_explicit_migration_preserves_legacy_bernoulli_draw_domain() -> None:
    config = migrate_config(_legacy_bernoulli())
    assert config.schema_version == "4.0.0"
    assert config.switch.kind == "generalized"
    assert config.scheduler.name == "crossbar_random_greedy_maximal"
    assert config.arrival.family == "iid_independent_bernoulli"
    assert config.arrival.params["rates"] == {
        "default": Decimal(0),
        "overrides": [
            {"queue_id": "voq[0,1]", "rate": Decimal("0.25")},
            {"queue_id": "voq[1,0]", "rate": Decimal(0)},
        ],
    }
    assert config.telemetry.include_packet_events is True
    assert config.telemetry.write_slot_trace is True

    # End-to-end replay check: explicit override order, rather than queue-catalog
    # order, drives one vectorized draw over both coordinates.  The zero-rate
    # second coordinate must still consume its uniform variate.
    actual_rng = build_arrival_rng_for_slot(11, 0)
    reference_rng = build_arrival_rng_for_slot(11, 0)
    draws = reference_rng.random(size=2)
    model = compile_arrival_model(config, actual_seed=11)
    sample = model.sample(0, actual_rng)
    assert tuple(sample.offered_counts) == (
        0,
        int(draws[0] < 0.25),
        0,
        0,
    )
    assert actual_rng.random() == reference_rng.random()


@pytest.mark.parametrize(
    "allowed_edges",
    [
        {"mode": "explicit", "edges": [[0, 1]]},
        {"mode": "full"},
    ],
)
def test_generalized_legacy_voq_ambiguity_fails_closed(allowed_edges) -> None:
    raw = _legacy_bernoulli()
    raw["switch"] = {
        "kind": "generalized",
        "queue_capacity": 8,
        "legacy_n_ports": 2,
        "queues": [
            {"id": "parallel-a", "legacy_voq": [0, 1]},
            {"id": "parallel-b", "legacy_voq": [0, 1]},
        ],
    }
    raw["scheduler"] = {
        "name": "node_exclusive_max_weight",
        "params": {
            "constraint": {
                "vertices": ["u", "v"],
                "links": [
                    {"queue_id": "parallel-a", "u": "u", "v": "v"},
                    {"queue_id": "parallel-b", "u": "u", "v": "v"},
                ],
            }
        },
    }
    raw["arrival"]["allowed_edges"] = allowed_edges
    raw["arrival"]["lambda"] = {"default": Decimal("0.25"), "overrides": {}}

    with pytest.raises(ConfigError, match="maps to multiple queues") as caught:
        migrate_config(raw)
    assert caught.value.context["legacy_voq"] == [0, 1]
    assert caught.value.context["path"] == "arrival.allowed_edges[0]"


def _legacy_iid_table() -> dict:
    raw = _legacy_bernoulli()
    raw["arrival"] = {
        "family": "iid_table",
        "allowed_edges": {"mode": "explicit", "edges": [[1, 0], [0, 1]]},
        "alphabet_constraint": "unrestricted",
        "alphabet": [
            {
                "id": "southbound",
                "edges": [[1, 0]],
                "probability": Decimal("0.3"),
            },
            {
                "id": "northbound",
                "edges": [[0, 1]],
                "probability": Decimal("0.7"),
            },
        ],
    }
    return raw


def test_iid_table_migration_preserves_outcome_identity_and_order() -> None:
    raw = _legacy_iid_table()

    outcomes = migrate_config(raw).arrival.params["outcomes"]
    assert [outcome["id"] for outcome in outcomes] == ["southbound", "northbound"]
    assert [outcome["probability"] for outcome in outcomes] == [
        Decimal("0.3"),
        Decimal("0.7"),
    ]
    assert [outcome["counts"] for outcome in outcomes] == [
        [{"queue_id": "voq[1,0]", "count": 1}],
        [{"queue_id": "voq[0,1]", "count": 1}],
    ]


def _legacy_markov_kernel() -> dict:
    raw = _legacy_bernoulli()
    raw["run"]["seed"] = 1
    raw["arrival"] = {
        "family": "markov_kernel",
        "allowed_edges": {"mode": "explicit", "edges": [[1, 0], [0, 1]]},
        "alphabet_constraint": "unrestricted",
        "states": ["on", "off"],
        "alphabet": [
            {"id": "packet", "edges": [[1, 0]]},
            {"id": "idle", "edges": []},
        ],
        # Deliberately not in canonical coordinate order.  Migration may
        # canonicalize row presentation, but it must preserve every coordinate.
        "kernel": [
            {
                "state": "off",
                "mask_id": "idle",
                "next_state": "off",
                "probability": Decimal("0.8"),
            },
            {
                "state": "on",
                "mask_id": "packet",
                "next_state": "off",
                "probability": Decimal("0.6"),
            },
            {
                "state": "off",
                "mask_id": "packet",
                "next_state": "on",
                "probability": Decimal("0.2"),
            },
            {
                "state": "on",
                "mask_id": "idle",
                "next_state": "on",
                "probability": Decimal("0.4"),
            },
        ],
        "initial": {
            "distribution": {
                "on": Decimal("0.25"),
                "off": Decimal("0.75"),
            }
        },
    }
    return raw


@pytest.mark.parametrize(
    ("family", "extra_key", "extra_value"),
    [
        ("factorized_bernoulli", "alphabet", []),
        ("iid_table", "initial", {"state": "unused"}),
        ("markov_kernel", "bogus_numeric", Decimal("0.5")),
    ],
)
def test_migration_rejects_unknown_or_family_inapplicable_arrival_fields(
    family, extra_key, extra_value
) -> None:
    raw = {
        "factorized_bernoulli": _legacy_bernoulli,
        "iid_table": _legacy_iid_table,
        "markov_kernel": _legacy_markov_kernel,
    }[family]()
    raw["arrival"][extra_key] = extra_value
    with pytest.raises(ConfigError, match="family-inapplicable") as caught:
        migrate_config(raw)
    assert caught.value.context["unknown_keys"] == [extra_key]


def test_markov_migration_never_guesses_missing_outcome_identity() -> None:
    raw = _legacy_markov_kernel()
    del raw["arrival"]["alphabet"][0]["id"]
    with pytest.raises(ConfigError, match="id is required for markov_kernel migration"):
        migrate_config(raw)


def test_markov_migration_preserves_kernel_identity_and_arrival_initial_domain() -> None:
    config = migrate_config(_legacy_markov_kernel())
    params = config.arrival.params

    assert params["states"] == ["on", "off"]
    assert params["outcomes"] == [
        {
            "id": "packet",
            "counts": [{"queue_id": "voq[1,0]", "count": 1}],
        },
        {"id": "idle", "counts": []},
    ]
    assert params["initial"] == {
        "distribution": {"on": Decimal("0.25"), "off": Decimal("0.75")}
    }
    assert {
        (row["state"], row["outcome_id"], row["next_state"]): row["probability"]
        for row in params["kernel"]
    } == {
        ("off", "idle", "off"): Decimal("0.8"),
        ("on", "packet", "off"): Decimal("0.6"),
        ("off", "packet", "on"): Decimal("0.2"),
        ("on", "idle", "on"): Decimal("0.4"),
    }

    initial_ticket = int(
        build_arrival_initial_rng(1).integers(0, 4, size=1)[0]
    )
    slot_ticket = int(
        build_arrival_rng_for_slot(1, 0).integers(
            0, 4, size=1
        )[0]
    )
    assert (initial_ticket, slot_ticket) == (1, 2)
    initial_choice = 0 if initial_ticket < 1 else 1
    transition_ticket = int(
        build_arrival_rng_for_slot(1, 0).integers(
            0, 5, size=1
        )[0]
    )
    transition_choice = 0 if transition_ticket < 1 else 3
    assert transition_choice == 3
    model = compile_arrival_model(config, actual_seed=1)
    assert model.resolved_initial_state == ("on", "off")[initial_choice]
    first = model.sample(0, build_arrival_rng_for_slot(1, 0))
    assert first.state_before == model.resolved_initial_state
    assert first.arrival_outcome_id == "idle"
    assert first.state_after == "off"
    assert tuple(first.offered_counts) == (0, 0, 0, 0)


@pytest.mark.parametrize("scheduler", ["islip_rga", "islip_canonical", "canonical_islip"])
def test_conflicting_legacy_scheduler_round_spellings_fail_closed(scheduler) -> None:
    raw = _legacy_bernoulli()
    raw["scheduler"] = {
        "name": scheduler,
        "params": {"k": 1, "rounds": 2, "num_rounds": 3},
    }
    with pytest.raises(ConfigError, match="conflicting round counts") as caught:
        migrate_config(raw)
    assert caught.value.context == {
        "scheduler": scheduler,
        "k": 1,
        "rounds": 2,
        "num_rounds": 3,
    }


@pytest.mark.parametrize(
    ("scheduler", "canonical_name", "canonical_key"),
    [
        ("islip_rga", "crossbar_random_grant_accept", "rounds"),
        ("islip_canonical", "crossbar_islip", "iterations"),
        ("canonical_islip", "crossbar_islip", "iterations"),
    ],
)
def test_equal_legacy_scheduler_round_spellings_have_one_exact_mapping(
    scheduler, canonical_name, canonical_key
) -> None:
    raw = _legacy_bernoulli()
    raw["scheduler"] = {
        "name": scheduler,
        "params": {"k": 2, "rounds": 2, "num_rounds": 2},
    }
    migrated = migrate_config(raw)
    assert migrated.scheduler.name == canonical_name
    assert migrated.scheduler.params[canonical_key] == 2
    assert not {"k", "num_rounds"}.intersection(migrated.scheduler.params)


@pytest.mark.parametrize("scheduler", ["round_robin", "roundrobin", "islip"])
def test_removed_or_ambiguous_scheduler_names_are_never_inferred(scheduler) -> None:
    legacy = _legacy_bernoulli()
    legacy["scheduler"] = {"name": scheduler, "params": {}}
    with pytest.raises(ConfigError) as migrated_error:
        migrate_config(legacy)
    if scheduler in {"round_robin", "roundrobin"}:
        assert migrated_error.value.context["replacement"] is None
    else:
        assert migrated_error.value.context["choose_one"] == [
            "crossbar_random_grant_accept",
            "crossbar_islip",
        ]

    canonical = _canonical()
    canonical["scheduler"]["name"] = scheduler
    with pytest.raises(ConfigError) as canonical_error:
        resolve_config(canonical)
    if scheduler in {"round_robin", "roundrobin"}:
        assert canonical_error.value.context["replacement"] is None
    else:
        assert canonical_error.value.context["choose_one"] == [
            "crossbar_random_grant_accept",
            "crossbar_islip",
        ]


def test_numeric_strings_are_rejected_in_canonical_and_migrated_arrivals() -> None:
    canonical = _canonical()
    canonical["arrival"]["rates"]["default"] = "0.1"
    with pytest.raises(ConfigError, match="finite decimal number"):
        resolve_config(canonical)

    canonical = _canonical()
    canonical["arrival"] = {
        "family": "iid_count_table",
        "outcomes": [
            {"id": "hit", "probability": "1.0", "counts": []},
        ],
    }
    with pytest.raises(ConfigError, match="finite decimal number"):
        resolve_config(canonical)

    legacy = _legacy_bernoulli()
    legacy["arrival"]["lambda"]["default"] = "0.25"
    with pytest.raises(ConfigError, match="numeric scalar"):
        migrate_config(legacy)

    legacy = _legacy_markov_kernel()
    legacy["arrival"]["initial"]["distribution"]["on"] = "0.25"
    with pytest.raises(ConfigError, match="finite decimal number"):
        migrate_config(legacy)

    legacy = _legacy_bernoulli()
    legacy["scheduler"] = {"name": "islip_rga", "params": {"rounds": "2"}}
    with pytest.raises(ConfigError, match="must be an integer") as caught:
        migrate_config(legacy)
    assert caught.value.context["value"] == "2"


def test_all_bundled_configs_are_directly_canonical_schema4() -> None:
    repository = Path(__file__).resolve().parents[1]
    config_dir = repository / "configs"
    paths = [repository / "canonicalschema.json"]
    paths.extend(
        sorted(
            path
            for path in config_dir.iterdir()
            if path.suffix.lower() in {".json", ".yaml", ".yml"}
        )
    )
    assert paths

    legacy_arrivals = {
        "bernoulli",
        "factorized_bernoulli",
        "iid_table",
        "markov_kernel",
        "markov_onoff",
        "poisson_modulated",
    }
    legacy_schedulers = {
        "random_maximal",
        "islip_rga",
        "islip_canonical",
        "canonical_islip",
        "max_weight",
        "maxweight",
        "round_robin",
        "roundrobin",
        "islip",
    }
    legacy_arrival_keys = {
        "allowed_edges",
        "alphabet_constraint",
        "alphabet",
        "lambda",
        "lambda_default",
        "lambda_overrides",
    }
    for path in paths:
        raw = load_raw_config(path)
        assert raw["schema_version"] == CONFIG_SCHEMA_VERSION, path
        assert raw["switch"]["kind"] == "generalized", path
        assert "legacy_n_ports" not in raw["switch"], path
        assert all("legacy_voq" not in queue for queue in raw["switch"]["queues"]), path
        assert raw["arrival"]["family"] not in legacy_arrivals, path
        assert not legacy_arrival_keys.intersection(raw["arrival"]), path
        assert raw["scheduler"]["name"] not in legacy_schedulers, path
        load_config(path)


def test_normal_resolution_never_migrates_legacy_input() -> None:
    with pytest.raises(ConfigError, match="explicit config migration"):
        resolve_config(_legacy_bernoulli())


def test_migration_cli_writes_loadable_schema4_config(tmp_path: Path, capsys) -> None:
    source = tmp_path / "legacy.json"
    destination = tmp_path / "canonical.yaml"
    source.write_text(json.dumps(_legacy_bernoulli(), default=str), encoding="utf-8")
    # json's default=str would turn Decimals into strings, which schema 4
    # correctly rejects.  Use ordinary numeric tokens for this legacy fixture.
    text = source.read_text(encoding="utf-8").replace('"0.25"', "0.25").replace('"0"', "0")
    source.write_text(text, encoding="utf-8")

    assert main([str(source), "--migrate-config", "--output-config", str(destination)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["schema_version"] == "4.0.0"
    assert load_config(destination).arrival.family == "iid_independent_bernoulli"


def test_failed_migration_does_not_replace_destination(tmp_path: Path) -> None:
    source = tmp_path / "legacy.json"
    destination = tmp_path / "canonical.json"
    raw = _legacy_bernoulli()
    raw["scheduler"]["name"] = "round_robin"
    source.write_text(json.dumps(raw, default=float), encoding="utf-8")
    destination.write_text("keep me\n", encoding="utf-8")
    with pytest.raises(ConfigError, match="no canonical replacement"):
        migrate_config_file(source, destination)
    assert destination.read_text(encoding="utf-8") == "keep me\n"


def test_discovery_commands_emit_machine_readable_metadata(capsys) -> None:
    assert main(["--list-schedulers"]) == 0
    schedulers = json.loads(capsys.readouterr().out)["schedulers"]
    assert {row["name"] for row in schedulers} == {
        "conflict_graph_max_weight",
        "crossbar_islip",
        "crossbar_max_weight",
        "crossbar_random_grant_accept",
        "crossbar_random_greedy_maximal",
        "interval_max_weight",
        "node_exclusive_max_weight",
        "resource_packing_max_weight",
    }
    assert all(row["constraint_family"] and row["algorithm_id"] for row in schedulers)

    assert main(["--list-arrivals"]) == 0
    arrivals = json.loads(capsys.readouterr().out)["arrivals"]
    by_family = {row["family"]: row for row in arrivals}
    assert by_family["iid_independent_poisson"]["fresh_iid"] is True
    assert by_family["markov_count_kernel"]["temporal_status"] == "stateful"
