from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import math
import sqlite3

import pytest

from voqsim.errors import ValidationError
from voqsim.telemetry.observations import (
    MASS_BINARY64_LATTICE,
    BINARY64_NORMALIZED_MASS,
    STATUS_COMPLETE,
    STATUS_FAILED,
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    TargetSlotObservation,
    WeightedBoundarySample,
    WeightedTargetSample,
    binary64_lattice_numerator,
    binary64_lattice_value,
    decode_bigint,
    encode_bigint,
    merge_level_streams,
)


def _sim_target() -> list[ObservationTarget]:
    return [ObservationTarget("q", 7)]


def _record_small_simulator(path, *, watermark: int, actual_seed: int = 1) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=2,
        window_stop=5,
        block_slots=2,
        targets=_sim_target(),
        metadata={
            "slot_convention": "service_before_arrivals",
            "actual_seed": actual_seed,
        },
        soft_watermark_rows=watermark,
    )
    recorder.record_slot(2, [TargetSlotObservation("q", 0, 2, 0, 2, 2, 0)])
    recorder.record_slot(3, [TargetSlotObservation("q", 2, 1, 1, 0, 0, 0)])
    recorder.record_slot(4, [TargetSlotObservation("q", 1, 1, 1, 1, 1, 0)])
    recorder.complete()
    recorder.close()


def _scientific_rows(path):
    with CompactObservationReader(path) as reader:
        return (
            reader.state,
            tuple(reader.iter_levels()),
            tuple(reader.iter_boundaries()),
            tuple(reader.iter_target_blocks()),
            tuple(reader.iter_supplied_responses()),
        )


def test_arbitrary_precision_integer_codec_is_canonical() -> None:
    values = [0, 1, -1, (1 << 4097) + 17, -((1 << 8193) + 9)]
    for value in values:
        encoded = encode_bigint(value)
        assert decode_bigint(encoded) == value
        assert encode_bigint(decode_bigint(encoded)) == encoded

    for malformed in (b"", b"\x01", b"\x02", b"\x01\x00", b"\x03\x01", b"\x00\x00"):
        with pytest.raises(ValidationError):
            decode_bigint(malformed)


def test_binary64_weights_are_exact_lattice_integers() -> None:
    smallest = float.fromhex("0x0.0000000000001p-1022")
    assert binary64_lattice_numerator(0.0) == 0
    assert binary64_lattice_numerator(-0.0) == 0
    assert binary64_lattice_numerator(smallest) == 1
    assert binary64_lattice_numerator(0.5) == 1 << 1073
    assert binary64_lattice_numerator(1.0) == 1 << 1074
    assert binary64_lattice_value(binary64_lattice_numerator(0.1)) == 0.1

    for invalid in (-0.25, math.inf, -math.inf, math.nan):
        with pytest.raises(ValidationError):
            binary64_lattice_numerator(invalid)
    with pytest.raises(ValidationError):
        binary64_lattice_numerator(1)  # type: ignore[arg-type]


def test_simulator_records_exact_levels_boundaries_and_event_totals(tmp_path) -> None:
    path = tmp_path / "observations.sqlite3"
    _record_small_simulator(path, watermark=2)

    with CompactObservationReader(path) as reader:
        assert reader.state.status == STATUS_COMPLETE
        assert reader.state.window_start == 2
        assert reader.state.window_stop == 5
        assert reader.state.metadata == {
            "actual_seed": 1,
            "slot_convention": "service_before_arrivals",
        }
        assert [
            (row.block_id, row.target_id, row.backlog, row.exposure, row.served)
            for row in reader.iter_levels()
        ] == [
            (0, "q", 0, 1, 0),
            (0, "q", 2, 1, 1),
            (1, "q", 1, 1, 1),
        ]
        assert [
            (row.block_id, row.target_id, row.side, row.backlog, row.mass)
            for row in reader.iter_boundaries()
        ] == [
            (0, "q", "end", 1, 1),
            (0, "q", "start", 0, 1),
            (1, "q", "end", 1, 1),
            (1, "q", "start", 1, 1),
        ]
        blocks = tuple(reader.iter_target_blocks())
        assert blocks[0].slots_observed == 2
        assert blocks[0].decision_mass == 2
        assert (blocks[0].offered, blocks[0].offered_square) == (2, 4)
        assert (blocks[0].admitted, blocks[0].admitted_square, blocks[0].dropped) == (2, 4, 0)
        assert blocks[1].slots_observed == 1
        assert (blocks[1].offered, blocks[1].offered_square) == (1, 1)
        reader.integrity_check()

    connection = sqlite3.connect(path)
    try:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
        assert not any(name.endswith(("-wal", "-shm")) for name in (item.name for item in tmp_path.iterdir()))
    finally:
        connection.close()


def test_observation_metadata_preserves_decimal_json_number_tokens(tmp_path) -> None:
    path = tmp_path / "decimal_metadata.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "queue")],
        metadata={
            "scientific_config": {
                "arrival": {
                    "family": "iid_count_table",
                    "probability": Decimal("0.5000"),
                }
            }
        },
    )
    recorder.record_slot(
        0,
        [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)],
    )
    recorder.complete()
    recorder.close()

    with sqlite3.connect(path) as connection:
        metadata_json = connection.execute(
            "SELECT metadata_json FROM run_state WHERE singleton = 1"
        ).fetchone()[0]
    assert '"probability":0.5' in metadata_json
    assert '"probability":"0.5"' not in metadata_json

    with CompactObservationReader(path) as reader:
        probability = reader.state.metadata["scientific_config"]["arrival"]["probability"]
        assert probability == Decimal("0.5")
        assert isinstance(probability, Decimal)
        reader.integrity_check()


def test_soft_watermark_changes_flush_timing_not_scientific_output(tmp_path) -> None:
    frequent = tmp_path / "frequent.sqlite3"
    deferred = tmp_path / "deferred.sqlite3"
    _record_small_simulator(frequent, watermark=1)
    _record_small_simulator(deferred, watermark=1_000_000)
    assert _scientific_rows(frequent) == _scientific_rows(deferred)


@dataclass
class _Committed:
    slot: int
    target_observations: dict[str, dict[str, int]]


@dataclass
class _KernelCommitted:
    slot: int
    queue_ids: tuple[int, ...]
    q_before: tuple[int, ...]
    q_after: tuple[int, ...]
    served_by_queue: dict[int, int]
    offered_by_queue: dict[int, int]
    admitted_by_queue: dict[int, int]
    dropped_by_queue: dict[int, int]

    def q_before_for(self, queue_id: int) -> int:
        return self.q_before[self.queue_ids.index(queue_id)]

    def q_after_for(self, queue_id: int) -> int:
        return self.q_after[self.queue_ids.index(queue_id)]


def test_committed_slot_adapter_needs_no_raw_slot_trace(tmp_path) -> None:
    path = tmp_path / "adapted.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=_sim_target(),
    )
    recorder.record_committed_slot(
        _Committed(
            0,
            {
                "q": {
                    "backlog_before": 1,
                    "backlog_after": 1,
                    "served": 1,
                    "offered": 1,
                    "admitted": 1,
                    "dropped": 0,
                }
            },
        )
    )
    recorder.complete()
    recorder.close()
    with CompactObservationReader(path) as reader:
        assert tuple(reader.iter_levels())[0].served == 1


def test_committed_slot_adapter_accepts_kernel_queue_contract(tmp_path) -> None:
    path = tmp_path / "kernel_adapted.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=_sim_target(),
    )
    recorder.record_committed_slot(
        _KernelCommitted(
            slot=0,
            queue_ids=(7, 9),
            q_before=(2, 3),
            q_after=(1, 3),
            served_by_queue={7: 1},
            offered_by_queue={},
            admitted_by_queue={},
            dropped_by_queue={},
        )
    )
    recorder.complete()
    recorder.close()
    with CompactObservationReader(path) as reader:
        assert [(row.backlog, row.exposure, row.served) for row in reader.iter_levels()] == [(2, 1, 1)]


def test_large_horizon_has_no_per_slot_lookup_allocation(tmp_path) -> None:
    recorder = CompactObservationRecorder(
        tmp_path / "large_horizon.sqlite3",
        window_start=10,
        window_stop=1_000_000_000_010,
        targets=_sim_target(),
    )
    assert len(recorder.blocks) == 1
    assert not hasattr(recorder, "_block_for_slot")
    assert recorder._block_at(999_999_999_999) == recorder.blocks[0]
    recorder.fail("test stops before simulating the large horizon")
    recorder.close()


def test_invalid_slot_does_not_partially_update_any_target(tmp_path) -> None:
    path = tmp_path / "atomic.sqlite3"
    targets = [ObservationTarget("a", 0), ObservationTarget("b", 1)]
    recorder = CompactObservationRecorder(path, window_start=0, window_stop=1, targets=targets)
    with pytest.raises(ValidationError):
        recorder.record_slot(
            0,
            [
                TargetSlotObservation("a", 0, 0, 0, 0, 0, 0),
                TargetSlotObservation("unknown", 0, 0, 0, 0, 0, 0),
            ],
        )
    assert recorder.pending_sparse_rows == 0
    recorder.fail("invalid committed slot")
    recorder.close()
    with CompactObservationReader(path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED
        assert tuple(reader.iter_levels()) == ()


def test_failed_prefix_is_retained_but_rejected_as_complete(tmp_path) -> None:
    path = tmp_path / "failed.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=2,
        targets=_sim_target(),
        soft_watermark_rows=1_000,
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 1, 0, 1, 1, 0)])
    recorder.fail("synthetic sampler failure")
    recorder.close()

    with pytest.raises(ValidationError):
        CompactObservationReader(path)
    with CompactObservationReader(path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED
        assert reader.state.failure_reason == "synthetic sampler failure"
        assert [(row.backlog, row.exposure) for row in reader.iter_levels()] == [(0, 1)]


def test_weighted_ingestion_preserves_exact_masses_and_boundaries(tmp_path) -> None:
    path = tmp_path / "weighted.sqlite3"
    target = ObservationTarget("q", "queue-q", MASS_BINARY64_LATTICE)
    recorder = CompactObservationRecorder(
        path,
        window_start=3,
        window_stop=4,
        targets=[target],
        unit_kind="weighted_ensemble",
        soft_watermark_rows=1,
    )
    recorder.record_weighted_boundary(
        3,
        [
            WeightedBoundarySample.from_binary64(target_id="q", backlog=0, weight=0.25),
            WeightedBoundarySample.from_binary64(target_id="q", backlog=2, weight=0.75),
        ],
    )
    recorder.record_weighted_slot(
        3,
        [
            WeightedTargetSample.from_binary64(
                target_id="q", backlog=0, weight=0.25, served=0, offered=2, admitted=1, dropped=1
            ),
            WeightedTargetSample.from_binary64(
                target_id="q", backlog=2, weight=0.75, served=1, offered=0, admitted=0, dropped=0
            ),
        ],
    )
    recorder.record_weighted_boundary(
        4,
        [
            WeightedBoundarySample.from_binary64(target_id="q", backlog=1, weight=0.5),
            WeightedBoundarySample.from_binary64(target_id="q", backlog=2, weight=0.5),
        ],
    )
    recorder.record_supplied_response(
        block_id=0,
        target_id="q",
        coefficient_kind="mu",
        coefficient_index=2,
        value=1.0,
        status="ok",
        exposure_numerator=binary64_lattice_numerator(0.75),
        served_numerator=binary64_lattice_numerator(0.75),
    )
    recorder.record_supplied_response(
        block_id=0,
        target_id="q",
        coefficient_kind="tail",
        coefficient_index=4,
        value=None,
        status="no_tail_exposure",
        exposure_numerator=0,
        served_numerator=0,
    )
    recorder.complete()
    recorder.close()

    quarter = binary64_lattice_numerator(0.25)
    half = binary64_lattice_numerator(0.5)
    three_quarters = binary64_lattice_numerator(0.75)
    one = binary64_lattice_numerator(1.0)
    with CompactObservationReader(path) as reader:
        levels = tuple(reader.iter_levels())
        assert [(row.backlog, row.exposure, row.served) for row in levels] == [
            (0, quarter, 0),
            (2, three_quarters, three_quarters),
        ]
        block = tuple(reader.iter_target_blocks())[0]
        assert block.slots_observed == 1
        assert block.decision_mass == one
        assert block.offered == half
        assert block.offered_square == one
        assert block.admitted == quarter
        assert block.admitted_square == quarter
        assert block.dropped == quarter
        boundaries = tuple(reader.iter_boundaries())
        assert sum(row.mass for row in boundaries if row.side == "start") == one
        assert sum(row.mass for row in boundaries if row.side == "end") == one
        responses = tuple(reader.iter_supplied_responses())
        assert [(row.coefficient_kind, row.coefficient_index, row.status) for row in responses] == [
            ("mu", 2, "ok"),
            ("tail", 4, "no_tail_exposure"),
        ]
        assert responses[0].exposure == three_quarters
        assert responses[0].served == three_quarters
        reader.integrity_check()


def test_weighted_population_requires_all_targets_with_equal_positive_mass(tmp_path) -> None:
    path = tmp_path / "weighted_invalid.sqlite3"
    targets = [
        ObservationTarget("a", "a", MASS_BINARY64_LATTICE),
        ObservationTarget("b", "b", MASS_BINARY64_LATTICE),
    ]
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=targets,
        unit_kind="weighted_ensemble",
    )
    with pytest.raises(ValidationError):
        recorder.record_weighted_slot(
            0,
            [WeightedTargetSample.from_binary64(target_id="a", backlog=0, weight=1.0, served=0)],
        )
    assert recorder.pending_sparse_rows == 0
    recorder.fail("invalid weighted population")
    recorder.close()


def test_weighted_population_requires_exact_unit_mass_at_every_call(tmp_path) -> None:
    path = tmp_path / "weighted_not_normalized.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "q", MASS_BINARY64_LATTICE)],
        unit_kind="weighted_ensemble",
    )
    assert BINARY64_NORMALIZED_MASS == binary64_lattice_numerator(1.0)
    with pytest.raises(ValidationError, match="normalized boundary mass"):
        recorder.record_weighted_boundary(
            0,
            [WeightedBoundarySample.from_binary64(target_id="q", backlog=0, weight=0.5)],
        )
    assert recorder.pending_sparse_rows == 0
    assert recorder._recorded_boundaries == set()
    with pytest.raises(ValidationError, match="normalized weighted decision mass"):
        recorder.record_weighted_slot(
            0,
            [
                WeightedTargetSample.from_binary64(
                    target_id="q", backlog=0, weight=0.5, served=0
                )
            ],
        )
    assert recorder.pending_sparse_rows == 0
    assert recorder._next_slot == 0
    recorder.fail("non-normalized input rejected")
    recorder.close()


def test_failed_input_streams_cannot_promote_half_a_scientific_call(tmp_path) -> None:
    simulator = CompactObservationRecorder(
        tmp_path / "broken_simulator_stream.sqlite3",
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("a", 0), ObservationTarget("b", 1)],
    )

    def broken_simulator_stream():
        yield TargetSlotObservation("a", 0, 0, 0, 0, 0, 0)
        raise RuntimeError("late simulator input failure")

    with pytest.raises(RuntimeError, match="late simulator input failure"):
        simulator.record_slot(0, broken_simulator_stream())
    assert simulator.pending_sparse_rows == 0
    assert simulator._next_slot == 0
    assert simulator._last_backlog == {}
    simulator.fail("broken input")
    simulator.close()

    weighted = CompactObservationRecorder(
        tmp_path / "broken_weighted_stream.sqlite3",
        window_start=0,
        window_stop=1,
        targets=[
            ObservationTarget("a", "a", MASS_BINARY64_LATTICE),
            ObservationTarget("b", "b", MASS_BINARY64_LATTICE),
        ],
        unit_kind="weighted_ensemble",
    )

    def broken_weighted_slot_stream():
        yield WeightedTargetSample.from_binary64(
            target_id="a", backlog=0, weight=1.0, served=0
        )
        raise RuntimeError("late weighted-slot input failure")

    with pytest.raises(RuntimeError, match="late weighted-slot input failure"):
        weighted.record_weighted_slot(0, broken_weighted_slot_stream())
    assert weighted.pending_sparse_rows == 0
    assert weighted._next_slot == 0

    def broken_boundary_stream():
        yield WeightedBoundarySample.from_binary64(
            target_id="a", backlog=0, weight=1.0
        )
        raise RuntimeError("late boundary input failure")

    with pytest.raises(RuntimeError, match="late boundary input failure"):
        weighted.record_weighted_boundary(0, broken_boundary_stream())
    assert weighted.pending_sparse_rows == 0
    assert weighted._recorded_boundaries == set()
    weighted.fail("broken input")
    weighted.close()


def test_ambiguous_commit_poison_closes_and_never_replays_pending_deltas(tmp_path) -> None:
    path = tmp_path / "ambiguous_commit.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=_sim_target(),
        soft_watermark_rows=1_000,
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)])
    actual_commit = recorder._commit_database

    def commit_then_report_failure() -> None:
        actual_commit()
        raise sqlite3.OperationalError("synthetic ambiguous COMMIT")

    recorder._commit_database = commit_then_report_failure  # type: ignore[method-assign]
    with pytest.raises(sqlite3.OperationalError, match="ambiguous COMMIT"):
        recorder.flush()
    assert recorder._closed
    assert recorder._terminal
    assert recorder.pending_sparse_rows == 0
    with pytest.raises(ValidationError, match="closed"):
        recorder.flush()

    with CompactObservationReader(path, require_complete=False) as reader:
        assert reader.state.status == "writing"
        assert [(row.exposure, row.served) for row in reader.iter_levels()] == [(1, 0)]
        reader.integrity_check()


def test_complete_validates_the_persisted_scientific_state(tmp_path) -> None:
    path = tmp_path / "corrupt_before_complete.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=_sim_target(),
        soft_watermark_rows=1,
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)])
    recorder._connection.execute(
        "UPDATE target_blocks SET decision_mass = ? WHERE block_id = 0 AND target_id = 'q'",
        (encode_bigint(0),),
    )
    recorder._connection.commit()
    with pytest.raises(ValidationError, match="decision mass"):
        recorder.complete()
    status = recorder._connection.execute(
        "SELECT status FROM run_state WHERE singleton = 1"
    ).fetchone()[0]
    assert status == "writing"
    recorder.close()


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        (
            ("UPDATE levels SET served = ? WHERE block_id = 0 AND target_id = 'q'", encode_bigint(2)),
            "level masses",
        ),
        (
            ("UPDATE levels SET exposure = ? WHERE block_id = 0 AND target_id = 'q'", encode_bigint(2)),
            "level exposure",
        ),
        (
            ("UPDATE target_blocks SET decision_mass = ? WHERE block_id = 0 AND target_id = 'q'", encode_bigint(0)),
            "decision mass",
        ),
        (
            ("UPDATE target_blocks SET slots_observed = 3 WHERE block_id = 0 AND target_id = 'q'", None),
            "slot coverage",
        ),
        (
            ("UPDATE boundaries SET mass = ? WHERE block_id = 0 AND target_id = 'q' AND side = 'start'", encode_bigint(2)),
            "boundary mass is not normalized",
        ),
        (
            ("DELETE FROM boundaries WHERE block_id = 0 AND target_id = 'q' AND side = 'end'", None),
            "missing a persisted block boundary",
        ),
    ],
)
def test_reader_integrity_rejects_corrupt_cross_table_invariants(
    tmp_path, mutation, message
) -> None:
    path = tmp_path / "corrupt_complete.sqlite3"
    _record_small_simulator(path, watermark=100)
    statement, parameter = mutation
    connection = sqlite3.connect(path)
    try:
        if parameter is None:
            connection.execute(statement)
        else:
            connection.execute(statement, (parameter,))
        connection.commit()
    finally:
        connection.close()
    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match=message):
            reader.integrity_check()


def test_streaming_level_merge_pools_additive_masses(tmp_path) -> None:
    first = tmp_path / "first.sqlite3"
    second = tmp_path / "second.sqlite3"
    _record_small_simulator(first, watermark=1)
    _record_small_simulator(second, watermark=100, actual_seed=2)
    with CompactObservationReader(first) as left, CompactObservationReader(second) as right:
        pooled = tuple(merge_level_streams([left, right]))
    assert [(row.block_id, row.backlog, row.exposure, row.served) for row in pooled] == [
        (0, 0, 2, 0),
        (0, 2, 2, 2),
        (1, 1, 2, 2),
    ]


def test_streaming_level_merge_rejects_duplicate_scientific_units(tmp_path) -> None:
    first = tmp_path / "first.sqlite3"
    replay = tmp_path / "replay.sqlite3"
    _record_small_simulator(first, watermark=1, actual_seed=7)
    _record_small_simulator(replay, watermark=100, actual_seed=7)
    with CompactObservationReader(first) as left, CompactObservationReader(replay) as right:
        with pytest.raises(ValidationError, match="duplicate independent scientific unit"):
            tuple(merge_level_streams([left, right]))


def test_streaming_merge_rejects_failed_units(tmp_path) -> None:
    path = tmp_path / "failed_pool.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=_sim_target(),
    )
    recorder.fail("no complete measurement")
    recorder.close()
    with CompactObservationReader(path, require_complete=False) as reader:
        with pytest.raises(ValidationError):
            tuple(merge_level_streams([reader]))


def test_complete_rejects_missing_slots_or_weighted_boundaries(tmp_path) -> None:
    incomplete = CompactObservationRecorder(
        tmp_path / "incomplete.sqlite3",
        window_start=0,
        window_stop=2,
        targets=_sim_target(),
    )
    incomplete.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)])
    with pytest.raises(ValidationError):
        incomplete.complete()
    incomplete.fail("incomplete")
    incomplete.close()

    weighted = CompactObservationRecorder(
        tmp_path / "missing_boundary.sqlite3",
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "q", MASS_BINARY64_LATTICE)],
        unit_kind="weighted_ensemble",
    )
    weighted.record_weighted_slot(
        0,
        [WeightedTargetSample.from_binary64(target_id="q", backlog=0, weight=1.0, served=0)],
    )
    with pytest.raises(ValidationError):
        weighted.complete()
    weighted.fail("missing boundary")
    weighted.close()
