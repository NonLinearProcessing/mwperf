from __future__ import annotations
from pathlib import Path
import numpy as np
import pytest
from voqsim.manifest import RunManifest, hash_flow_plan, hash_resolved_config, write_run_manifest
from voqsim.rng import (
    MAX_SEED_VALUE,
    RNGDomain,
    build_arrival_compile_rng,
    build_arrival_initial_rng,
    build_arrival_rng_for_slot,
    build_planner_pair_rng,
    build_planner_param_rng,
    build_scheduler_rng_for_slot,
    derive_seed_material,
    make_rng,
    resolve_master_seed,
)
from voqsim.utils import (
    canonical_json_dumps,
    iter_valid_voq_keys,
)
def _sample_stream(rng: np.random.Generator, count: int = 8) -> list[int]:
    return rng.integers(0, 1_000_000_000, size=count, endpoint=False).tolist()
def test_resolve_master_seed_fixed_seed_is_identity() -> None:
    assert resolve_master_seed(1234) == 1234
    assert resolve_master_seed(0) == 0
@pytest.mark.parametrize("bad_seed", [-2, True, 1.5, "7"])
def test_resolve_master_seed_rejects_invalid_values(bad_seed: object) -> None:
    with pytest.raises(Exception):
        resolve_master_seed(bad_seed)  # type: ignore[arg-type]
def test_resolve_master_seed_random_seed_is_in_supported_range() -> None:
    seed = resolve_master_seed(-1)
    assert isinstance(seed, int)
    assert 0 <= seed <= MAX_SEED_VALUE
def test_seed_material_is_deterministic_and_unambiguous() -> None:
    material_a = derive_seed_material(1234, int(RNGDomain.FLOW_PAIR), 1, 2)
    material_b = derive_seed_material(1234, int(RNGDomain.FLOW_PAIR), 1, 2)
    material_c = derive_seed_material(1234, int(RNGDomain.FLOW_PAIR), (1 << 32) + 2)
    assert material_a == material_b
    assert material_a != material_c
def test_same_seed_path_gives_same_rng_sequence() -> None:
    rng_a = make_rng(1234, int(RNGDomain.FLOW_PARAMETER), 7)
    rng_b = make_rng(1234, int(RNGDomain.FLOW_PARAMETER), 7)
    assert _sample_stream(rng_a) == _sample_stream(rng_b)
def test_different_rng_domains_are_isolated() -> None:
    actual_seed = 1234
    pair_seq = _sample_stream(build_planner_pair_rng(actual_seed))
    param_seq = _sample_stream(build_planner_param_rng(actual_seed))
    assert pair_seq != param_seq
def test_scheduler_rng_is_bound_to_slot() -> None:
    actual_seed = 5555
    seq_a = _sample_stream(build_scheduler_rng_for_slot(actual_seed, 12))
    seq_b = _sample_stream(build_scheduler_rng_for_slot(actual_seed, 12))
    seq_c = _sample_stream(build_scheduler_rng_for_slot(actual_seed, 13))
    assert seq_a == seq_b
    assert seq_a != seq_c
def test_arrival_initial_rng_is_deterministic() -> None:
    actual_seed = 4321
    seq_a = _sample_stream(build_arrival_initial_rng(actual_seed))
    seq_b = _sample_stream(build_arrival_initial_rng(actual_seed))
    assert seq_a == seq_b
def test_arrival_slot_rng_is_bound_to_slot() -> None:
    actual_seed = 2468
    seq_a = _sample_stream(build_arrival_rng_for_slot(actual_seed, 4))
    seq_b = _sample_stream(build_arrival_rng_for_slot(actual_seed, 4))
    seq_c = _sample_stream(build_arrival_rng_for_slot(actual_seed, 5))
    assert seq_a == seq_b
    assert seq_a != seq_c
def test_arrival_compile_rng_is_isolated_from_other_domains() -> None:
    actual_seed = 97531
    compile_seq = _sample_stream(build_arrival_compile_rng(actual_seed))
    pair_seq = _sample_stream(build_planner_pair_rng(actual_seed))
    assert compile_seq != pair_seq
def test_iter_valid_voq_keys_is_row_major_and_self_filterable() -> None:
    assert list(iter_valid_voq_keys(2, allow_self_traffic=True)) == [
        (0, 0),
        (0, 1),
        (1, 0),
        (1, 1),
    ]
    assert list(iter_valid_voq_keys(2, allow_self_traffic=False)) == [(0, 1), (1, 0)]
def test_hashing_is_stable_for_different_mapping_order() -> None:
    cfg_a = {"run": {"seed": 1234}, "switch": {"n_ports": 4, "capacity": 8}}
    cfg_b = {"switch": {"capacity": 8, "n_ports": 4}, "run": {"seed": 1234}}
    assert hash_resolved_config(cfg_a) == hash_resolved_config(cfg_b)
def test_manifest_records_requested_and_actual_seed_and_writes_canonical_json(tmp_path: Path) -> None:
    flow_plan = [
        {"flow_id": 0, "src_port": 0, "dst_port": 1, "metadata": {"edge": "[0,1]"}},
        {"flow_id": 1, "src_port": 1, "dst_port": 0, "metadata": {"edge": "[1,0]"}},
    ]
    manifest = RunManifest(
        requested_seed=-1,
        actual_seed=424242,
        scheduler_name="crossbar_max_weight",
        scheduler_algorithm_id="hungarian_exact",
        scheduler_optimizer_id="hungarian_exact",
        config_hash=hash_resolved_config({"run": {"seed": -1}}),
        flow_plan_hash=hash_flow_plan(flow_plan),
        metadata={"checkpoint": "v1", "notes": ["foundation", "reproducibility"]},
    )
    out_path = write_run_manifest(manifest, tmp_path / "run_manifest.json")
    payload = out_path.read_text(encoding="utf-8")
    assert out_path.exists()
    assert '"requested_seed":-1' in payload
    assert '"actual_seed":424242' in payload
    assert '"scheduler_algorithm_id":"hungarian_exact"' in payload
    assert '"scheduler_optimizer_id":"hungarian_exact"' in payload
    assert payload == canonical_json_dumps(manifest.to_dict()) + "\n"
