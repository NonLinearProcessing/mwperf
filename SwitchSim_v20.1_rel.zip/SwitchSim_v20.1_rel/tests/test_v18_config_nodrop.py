from __future__ import annotations

import numpy as np
import pytest

from voqsim import cli
from voqsim.config import (
    CONFIG_SCHEMA_VERSION,
    NO_DROP_CAPACITY,
    apply_queue_capacity_override,
    resolve_config,
    resolved_config_to_dict,
)
from voqsim.errors import ConfigError, ValidationError
from voqsim.events import ArrivalAttempt
from voqsim.packet import Packet
from voqsim.queues import MAX_QUEUE_LENGTH, QueueBank, QueueCatalog


def _schema4_config(capacity: object = 4) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 1, "slots": 2, "warmup_slots": 0},
        "switch": {
            "kind": "generalized",
            "queue_capacity": capacity,
            "queues": [{"id": "q"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {"constraint": {"conflicts": []}, "priority": ["q"]},
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [{"slot": 0, "queue_id": "q", "count": 1}],
        },
    }


def _schema4_heuristic_config(capacity: object = NO_DROP_CAPACITY) -> dict[str, object]:
    raw = _schema4_config(capacity)
    raw["scheduler"] = {
        "name": "crossbar_random_greedy_maximal",
        "params": {
            "constraint": {
                "inputs": [0],
                "outputs": [0],
                "edges": [{"queue_id": "q", "input": 0, "output": 0}],
            }
        },
    }
    return raw


def _attempt(packet_id: int, *, queue_id: str = "q", slot: int = 0) -> ArrivalAttempt:
    return ArrivalAttempt.from_packet(
        Packet.for_queue(
            packet_id=packet_id,
            flow_id=0,
            queue_id=queue_id,
            generation_slot=slot,
        )
    )


@pytest.mark.parametrize("capacity", [1, 17, MAX_QUEUE_LENGTH, NO_DROP_CAPACITY])
def test_schema4_capacity_grammar_accepts_only_finite_or_exact_nodrop(capacity) -> None:
    config = resolve_config(_schema4_config(capacity))

    expected_internal = None if capacity == NO_DROP_CAPACITY else capacity
    assert config.switch.capacity == expected_internal
    assert config.switch.buffer_mode == (NO_DROP_CAPACITY if expected_internal is None else "finite")
    assert resolved_config_to_dict(config)["switch"]["queue_capacity"] == capacity


@pytest.mark.parametrize(
    "capacity",
    [None, 0, -1, True, 1.0, "infinite", "Infinite", "nodrop", "NO_DROP", "16"],
)
def test_schema4_capacity_grammar_rejects_every_other_value(capacity) -> None:
    with pytest.raises(ConfigError):
        resolve_config(_schema4_config(capacity))


def test_schema4_requires_an_explicit_capacity() -> None:
    raw = _schema4_config()
    raw["switch"].pop("queue_capacity")  # type: ignore[union-attr]

    with pytest.raises(ConfigError, match="Missing required key"):
        resolve_config(raw)


def test_warmup_must_leave_at_least_one_measurement_slot() -> None:
    raw = _schema4_config()
    raw["run"]["warmup_slots"] = 2  # type: ignore[index]

    with pytest.raises(ValidationError, match="less than run.slots"):
        resolve_config(raw)


def test_capacity_override_precedes_schema4_validation() -> None:
    raw = _schema4_config(0)

    overridden = apply_queue_capacity_override(raw, NO_DROP_CAPACITY)
    config = resolve_config(overridden)

    assert overridden["switch"]["queue_capacity"] == NO_DROP_CAPACITY  # type: ignore[index]
    assert config.switch.capacity is None


@pytest.mark.parametrize("override,expected", [(NO_DROP_CAPACITY, None), (7, 7)])
def test_cli_capacity_override_is_applied_before_config_validation(
    tmp_path, monkeypatch, override, expected
) -> None:
    config_path = tmp_path / "config.yaml"
    raw = _schema4_config(0)
    import yaml

    config_path.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
    captured: dict[str, object] = {}

    class _Result:
        def to_dict(self):
            return {}

    class _Simulator:
        def run(self):
            return _Result()

    def _build(config, *, output_dir=None):
        captured["config"] = config
        return _Simulator()

    monkeypatch.setattr(cli, "build_simulation", _build)

    assert cli.main([str(config_path), "--queue-capacity", str(override), "--quiet"]) == 0
    assert captured["config"].switch.capacity == expected


@pytest.mark.parametrize("value", ["0", "-1", "infinite", "nodrop", "NoDrop ", "1.5"])
def test_cli_capacity_override_rejects_noncanonical_values(value) -> None:
    with pytest.raises(SystemExit) as caught:
        cli.build_arg_parser().parse_args(["config.yaml", "--queue-capacity", value])
    assert caught.value.code == 2


def test_nodrop_queuebank_uses_deques_and_admits_the_whole_valid_batch() -> None:
    bank = QueueBank(QueueCatalog(["q"]), None)

    decisions = bank.enqueue_or_drop((_attempt(index) for index in range(12)), slot=0)

    assert bank.is_no_drop
    assert all(decision.accepted for decision in decisions)
    assert all(decision.voq_capacity is None for decision in decisions)
    assert bank.occupancy("q") == 12
    assert bank.total_occupancy() == 12
    assert [packet.packet_id for packet in bank.queues[0]] == list(range(12))


def test_finite_buffer_behavior_is_unchanged() -> None:
    bank = QueueBank(QueueCatalog(["q"]), 1)

    decisions = bank.enqueue_or_drop([_attempt(0), _attempt(1)], slot=0)

    assert [decision.accepted for decision in decisions] == [True, False]
    assert decisions[1].reason == "buffer_full"
    assert bank.occupancy("q") == 1


def test_nodrop_representation_failure_precedes_all_batch_appends(monkeypatch) -> None:
    import voqsim.queues as queue_module

    monkeypatch.setattr(queue_module, "MAX_QUEUE_LENGTH", 1)
    bank = QueueBank(QueueCatalog(["q"]), None)

    with pytest.raises(ValidationError, match="cannot be represented"):
        bank.enqueue_or_drop([_attempt(0), _attempt(1)], slot=0)

    assert bank.occupancy("q") == 0
    assert len(bank.queues[0]) == 0
    assert bank.total_occupancy() == 0
    assert bank.peak_occupancy() == 0


def test_nodrop_allocation_failure_is_fatal_and_not_repaired() -> None:
    class _FailSecondAppend:
        def __init__(self) -> None:
            self.items: list[Packet] = []

        def __len__(self) -> int:
            return len(self.items)

        def __getitem__(self, index: int) -> Packet:
            return self.items[index]

        def append(self, packet: Packet) -> None:
            if self.items:
                raise MemoryError("injected allocation failure")
            self.items.append(packet)

        def clear(self) -> None:
            self.items.clear()

    bank = QueueBank(QueueCatalog(["q"]), None)
    failing_queue = _FailSecondAppend()
    bank._queues = (failing_queue,)  # type: ignore[assignment]

    with pytest.raises(MemoryError, match="injected allocation failure"):
        bank.enqueue_or_drop([_attempt(0), _attempt(1)], slot=0)

    # The run must abort; NoDrop deliberately has no rollback/retry subsystem.
    assert bank.occupancy("q") == 1
    assert len(failing_queue) == 1
    assert bank.total_occupancy() == 1
    assert bank.peak_occupancy() == 1


def test_total_occupancy_uses_exact_python_integer_arithmetic() -> None:
    class _SyntheticHugeQueue:
        def __len__(self) -> int:
            return MAX_QUEUE_LENGTH

    bank = QueueBank(QueueCatalog(["a", "b", "c"]), None)
    bank._lengths[:] = np.asarray([MAX_QUEUE_LENGTH, MAX_QUEUE_LENGTH, MAX_QUEUE_LENGTH])
    bank._queues = tuple(_SyntheticHugeQueue() for _ in range(3))  # type: ignore[assignment]
    bank._total_occupancy = 3 * MAX_QUEUE_LENGTH
    bank._peak_occupancy = 3 * MAX_QUEUE_LENGTH

    assert bank.total_occupancy() == 3 * MAX_QUEUE_LENGTH
    assert bank.peak_occupancy() == 3 * MAX_QUEUE_LENGTH
    assert type(bank.total_occupancy()) is int
    bank.assert_internal_consistency()


def test_cli_has_no_gzip_option() -> None:
    option_strings = {
        option
        for action in cli.build_arg_parser()._actions
        for option in action.option_strings
    }
    assert not any("gzip" in option or option.endswith(".gz") for option in option_strings)


@pytest.mark.parametrize("gap", ["none", "exact"])
def test_compact_observation_config_round_trips_canonically(gap: str) -> None:
    raw = _schema4_config(NO_DROP_CAPACITY)
    raw["telemetry"] = {
        "write_slot_trace": False,
        "observation": {
            "enabled": True,
            "block_slots": 1,
            "targets": [{"queue_id": "q", "gap": gap}],
        },
    }

    config = resolve_config(raw)
    emitted = resolved_config_to_dict(config)

    assert config.telemetry.observation.enabled is True
    assert config.telemetry.observation.block_slots == 1
    assert config.telemetry.observation.targets[0].queue_id == "q"
    assert emitted["telemetry"]["observation"] == raw["telemetry"]["observation"]


@pytest.mark.parametrize(
    "observation,match",
    [
        ({"enabled": True, "targets": []}, "at least one target"),
        (
            {
                "enabled": True,
                "targets": [
                    {"queue_id": "q", "gap": "none"},
                    {"queue_id": "q", "gap": "none"},
                ],
            },
            "unique",
        ),
        (
            {"enabled": True, "targets": [{"queue_id": "missing", "gap": "none"}]},
            "outside the switch catalog",
        ),
    ],
)
def test_compact_observation_config_rejects_invalid_scientific_targets(
    observation, match
) -> None:
    raw = _schema4_config()
    raw["telemetry"] = {"observation": observation}

    with pytest.raises((ConfigError, ValidationError), match=match):
        resolve_config(raw)


@pytest.mark.parametrize("block_slots", [0, -1, True, 1.5, "4"])
def test_compact_observation_block_width_is_null_or_positive_integer(block_slots) -> None:
    raw = _schema4_config()
    raw["telemetry"] = {
        "observation": {
            "enabled": True,
            "block_slots": block_slots,
            "targets": [{"queue_id": "q", "gap": "none"}],
        }
    }

    with pytest.raises(ConfigError):
        resolve_config(raw)


def test_exact_gap_requires_scheduler_certificate_support() -> None:
    raw = _schema4_heuristic_config()
    raw["telemetry"] = {
        "observation": {
            "enabled": True,
            "targets": [{"queue_id": "q", "gap": "exact"}],
        }
    }

    with pytest.raises(ValidationError, match="exact class-certificate support"):
        resolve_config(raw)


def test_disabled_exact_target_does_not_require_certificate_support() -> None:
    raw = _schema4_heuristic_config()
    raw["telemetry"] = {
        "observation": {
            "enabled": False,
            "targets": [{"queue_id": "q", "gap": "exact"}],
        }
    }

    config = resolve_config(raw)

    assert config.telemetry.observation.enabled is False
    assert config.telemetry.observation.targets[0].gap == "exact"


def _resource_packing_observation_config(
    *,
    capacity: int,
    demand: int,
    gap: str,
) -> dict[str, object]:
    raw = _schema4_config(NO_DROP_CAPACITY)
    raw["scheduler"] = {
        "name": "resource_packing_max_weight",
        "params": {
            "constraint": {
                "resources": ["r"],
                "capacity": [capacity],
                "demands": [{"queue_id": "q", "demand": [demand]}],
            },
            "priority": ["q"],
        },
    }
    raw["telemetry"] = {
        "observation": {
            "enabled": True,
            "targets": [{"queue_id": "q", "gap": gap}],
        }
    }
    return raw


@pytest.mark.parametrize(
    "capacity,demand",
    [
        (2, 2),
        (0, 0),
    ],
)
def test_exact_gap_accepts_individually_feasible_packing_target(
    capacity: int,
    demand: int,
) -> None:
    config = resolve_config(
        _resource_packing_observation_config(
            capacity=capacity,
            demand=demand,
            gap="exact",
        )
    )

    assert config.telemetry.observation.targets[0].gap == "exact"


def test_exact_gap_rejects_individually_infeasible_packing_target() -> None:
    with pytest.raises(ValidationError, match="individually infeasible"):
        resolve_config(
            _resource_packing_observation_config(
                capacity=1,
                demand=2,
                gap="exact",
            )
        )


def test_none_gap_allows_individually_infeasible_packing_target() -> None:
    config = resolve_config(
        _resource_packing_observation_config(
            capacity=1,
            demand=2,
            gap="none",
        )
    )

    assert config.telemetry.observation.targets[0].gap == "none"
