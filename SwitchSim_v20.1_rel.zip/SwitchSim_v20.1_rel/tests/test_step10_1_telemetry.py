from __future__ import annotations

from dataclasses import replace
import json

import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, resolve_config, resolved_config_to_dict
from voqsim.errors import ValidationError
from voqsim.kernel import build_simulation
from voqsim.manifest import (
    RunManifest,
    build_service_model,
    hash_flow_plan,
    hash_resolved_config,
    hash_service_model,
)
from voqsim.schedulers import build_scheduler
from voqsim.telemetry import SummaryWriter, write_static_run_artifacts
from voqsim.traffic.compiler import compile_arrival_spec
from voqsim.utils import canonical_json_dumps


def _count_config(
    *,
    include_packet_events: bool = True,
    include_scheduler_state: bool = True,
    queue_snapshot: str = "dense",
) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 1234, "slots": 3},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 1,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": {
            "family": "iid_count_table",
            "outcomes": [
                {
                    "id": "batch",
                    "probability": 1,
                    "counts": [
                        {"queue_id": "q0", "count": 2},
                        {"queue_id": "q1", "count": 1},
                    ],
                }
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": queue_snapshot,
            "include_packet_events": include_packet_events,
            "include_scheduler_state": include_scheduler_state,
            "write_slot_trace": True,
            "observation": {"enabled": False, "block_slots": None, "targets": []},
        },
    }


def _markov_config() -> dict[str, object]:
    config = _count_config(include_packet_events=False, include_scheduler_state=False)
    config["run"] = {"seed": 1234, "slots": 4}
    config["switch"] = {
        "kind": "generalized",
        "queue_capacity": 2,
        "queues": [{"id": "q0"}, {"id": "q1"}],
    }
    config["arrival"] = {
        "family": "markov_count_kernel",
        "states": ["off", "on"],
        "outcomes": [
            {"id": "idle", "counts": []},
            {"id": "hit", "counts": [{"queue_id": "q0", "count": 1}]},
        ],
        "kernel": [
            {"state": "off", "outcome_id": "hit", "next_state": "on", "probability": 1},
            {"state": "on", "outcome_id": "idle", "next_state": "off", "probability": 1},
        ],
        "initial": {"state": "off"},
    }
    return config


def _read_jsonl(path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def _manifest_for(config, compiled, *, actual_seed: int = 1234) -> RunManifest:
    service_model = build_service_model(config)
    scheduler = build_scheduler(config.scheduler.name, config.scheduler.params)
    return RunManifest(
        requested_seed=config.run.seed,
        actual_seed=actual_seed,
        config_hash=hash_resolved_config(
            resolved_config_to_dict(config, actual_seed=actual_seed)
        ),
        flow_plan_hash=hash_flow_plan(compiled.flow_plan.to_dict()),
        service_model_hash=hash_service_model(service_model),
        config_schema_version=config.schema_version,
        switch_kind=config.switch.kind,
        n_queues=config.switch.n_queues,
        service_family=config.scheduler.service_family,
        scheduler_name=config.scheduler.name,
        scheduler_algorithm_id=scheduler.algorithm_id,
        scheduler_optimizer_id=getattr(scheduler, "optimizer_id", None),
        scheduler_params=config.scheduler.params,
    )


def test_jsonl_records_preserve_count_splits_and_canonical_queue_order(tmp_path) -> None:
    result = build_simulation(_count_config(), output_dir=tmp_path / "run").run()
    records = _read_jsonl(result.telemetry_path)
    first = records[0]

    assert first["schema_version"] == "3.0.0"
    assert first["arrival_outcome_id"] == "batch"
    assert first["arrivals"] == {
        "format": "queue_counts",
        "offered": [
            {"queue_id": "q0", "count": 2},
            {"queue_id": "q1", "count": 1},
        ],
        "admitted": [
            {"queue_id": "q0", "count": 1},
            {"queue_id": "q1", "count": 1},
        ],
        "dropped": [{"queue_id": "q0", "count": 1}],
    }
    assert first["q_before"] == {
        "mode": "dense",
        "representation": "queue_vector",
        "queue_order": "service_model.queues[index]",
        "values": [0, 0],
    }
    assert first["q_after"]["values"] == [1, 1]
    assert first["slot_metrics"] == {
        "offered_count": 3,
        "admitted_count": 2,
        "dropped_count": 1,
        "completion_count": 0,
        "drop_fraction_of_offered": pytest.approx(1 / 3),
        "total_q_before": 0,
        "total_q_after": 2,
    }
    assert first["schedule"] == {
        "format": "selected_queue_ids",
        "scheduler_id": "conflict_graph_max_weight",
        "algorithm_id": "mwis_branch_memo_exact",
        "optimizer_id": "mwis_branch_memo_exact",
        "selected_queue_ids": [],
    }

    # The writer's output is canonical JSON, not merely equivalent JSON.
    assert result.telemetry_path.read_text(encoding="utf-8").splitlines()[0] == canonical_json_dumps(first)


def test_packet_events_and_scheduler_state_follow_telemetry_toggles(tmp_path) -> None:
    compact = build_simulation(
        _count_config(include_packet_events=False, include_scheduler_state=False),
        output_dir=tmp_path / "compact",
    ).run()
    full = build_simulation(_count_config(), output_dir=tmp_path / "full").run()

    compact_first = _read_jsonl(compact.telemetry_path)[0]
    full_first = _read_jsonl(full.telemetry_path)[0]
    for field in ("departures", "completions", "offered_attempts", "admissions"):
        assert field not in compact_first
        assert field in full_first
    assert "scheduler_state_before" not in compact_first
    assert "scheduler_state_after" not in compact_first
    assert full_first["scheduler_state_before"]["scheduler_kind"] == "conflict_graph_max_weight"
    assert full_first["scheduler_state_after"]["optimizer_id"] == "mwis_branch_memo_exact"


def test_markov_state_and_outcome_identity_are_recorded(tmp_path) -> None:
    result = build_simulation(_markov_config(), output_dir=tmp_path / "markov").run()
    records = _read_jsonl(result.telemetry_path)

    assert [
        (
            record["arrival_state_before"],
            record["arrival_outcome_id"],
            record["arrival_state_after"],
        )
        for record in records
    ] == [
        ("off", "hit", "on"),
        ("on", "idle", "off"),
        ("off", "hit", "on"),
        ("on", "idle", "off"),
    ]
    assert records[0]["arrivals"]["offered"] == [{"queue_id": "q0", "count": 1}]
    assert records[1]["arrivals"]["offered"] == []


def test_departures_and_completions_retain_packet_and_latency_identity(tmp_path) -> None:
    result = build_simulation(_count_config(), output_dir=tmp_path / "departures").run()
    second = _read_jsonl(result.telemetry_path)[1]

    assert second["schedule"]["selected_queue_ids"] == ["q0"]
    assert len(second["departures"]) == len(second["completions"]) == 1
    assert second["departures"][0]["packet_id"] == second["completions"][0]["packet_id"] == 0
    assert second["completions"][0]["queue_id"] == "q0"
    assert second["completions"][0]["sojourn_slots"] == 1
    assert second["completions"][0]["waiting_slots"] == 1


def test_static_run_artifacts_are_queue_addressed_and_identity_complete(tmp_path) -> None:
    result = build_simulation(_count_config(), output_dir=tmp_path / "artifacts").run()
    paths = result.static_artifacts

    assert set(paths) == {
        "resolved_config",
        "run_manifest",
        "flow_plan",
        "arrival_support",
        "service_model",
    }
    support = json.loads(paths["arrival_support"].read_text(encoding="utf-8"))
    service = json.loads(paths["service_model"].read_text(encoding="utf-8"))
    manifest = json.loads(paths["run_manifest"].read_text(encoding="utf-8"))

    assert support["schema_version"] == "2.0.0"
    assert support["family"] == "iid_count_table"
    assert support["live_queue_ids"] == ["q0", "q1"]
    assert support["model"]["outcomes"][0]["counts"] == [
        {"queue_id": "q0", "count": 2},
        {"queue_id": "q1", "count": 1},
    ]
    assert service["switch_kind"] == "generalized"
    assert service["service"] == {
        "family": "pairwise_conflicts",
        "constraint": {"conflicts": [["q0", "q1"]]},
    }
    assert manifest["schema_version"] == "2.2.0"
    assert manifest["rng_seed_scheme_version"] == 1
    assert manifest["numpy_version"]
    assert manifest["arrival_categorical_sampler"] == "exact_decimal_integer_v1"
    assert manifest["scheduler_algorithm_id"] == "mwis_branch_memo_exact"
    assert manifest["scheduler_optimizer_id"] == "mwis_branch_memo_exact"

    summary_path = SummaryWriter(tmp_path / "summary.json").write({"slots": 3, "generated": 9})
    assert json.loads(summary_path.read_text(encoding="utf-8")) == {"generated": 9, "slots": 3}


@pytest.mark.parametrize(
    "field_name",
    [
        "schema_version",
        "config_hash",
        "flow_plan_hash",
        "service_model_hash",
        "scheduler_algorithm_id",
        "scheduler_optimizer_id",
    ],
)
def test_static_artifact_preflight_rejects_manifest_drift_before_writing(
    tmp_path,
    field_name,
) -> None:
    config = resolve_config(_count_config())
    compiled = compile_arrival_spec(config, actual_seed=1234)
    manifest = _manifest_for(config, compiled)
    target = tmp_path / field_name

    with pytest.raises(ValidationError, match=field_name):
        write_static_run_artifacts(
            target,
            config=config,
            actual_seed=1234,
            manifest=replace(manifest, **{field_name: "bogus"}),
            compiled_arrival=compiled,
        )

    assert not target.exists()


def test_static_artifact_preflight_rejects_mismatched_count_model(tmp_path) -> None:
    config = resolve_config(_count_config())
    other_raw = _count_config()
    other_raw["arrival"] = {
        "family": "iid_count_table",
        "outcomes": [
            {
                "id": "batch",
                "probability": 1,
                "counts": [
                    {"queue_id": "q0", "count": 3},
                    {"queue_id": "q1", "count": 1},
                ],
            }
        ],
    }
    compiled = compile_arrival_spec(config, actual_seed=1234)
    wrong_compiled = compile_arrival_spec(resolve_config(other_raw), actual_seed=1234)
    target = tmp_path / "wrong-count-model"

    with pytest.raises(ValidationError, match="compiled_arrival does not match"):
        write_static_run_artifacts(
            target,
            config=config,
            actual_seed=1234,
            manifest=_manifest_for(config, compiled),
            compiled_arrival=wrong_compiled,
        )

    assert not target.exists()


def test_static_artifact_preflight_rejects_wrong_service_model(tmp_path) -> None:
    config = resolve_config(_count_config())
    compiled = compile_arrival_spec(config, actual_seed=1234)
    target = tmp_path / "wrong-service"

    with pytest.raises(ValidationError, match="service_model does not match"):
        write_static_run_artifacts(
            target,
            config=config,
            actual_seed=1234,
            manifest=_manifest_for(config, compiled),
            compiled_arrival=compiled,
            service_model={"schema_version": "1.0.0", "service": {"family": "wrong"}},
        )

    assert not target.exists()
