from __future__ import annotations

from itertools import product
import random

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.crossbar_max_weight import (
    CrossbarMaxWeightScheduler,
    _maximum_weight_perfect_assignment,
)
from voqsim.schedulers.domain import CrossbarSchedulerDomain, QueueSchedulerDomain
from voqsim.schedulers.exact_priority import exact_lex_weights


def _constraint(
    inputs,
    outputs,
    edges,
):
    return {
        "inputs": list(inputs),
        "outputs": list(outputs),
        "edges": [
            {"queue_id": queue_id, "input": input_port, "output": output_port}
            for queue_id, input_port, output_port in edges
        ],
    }


def _build(edges, qids=None, *, inputs=None, outputs=None, priority=None):
    if qids is None:
        qids = tuple(edge[0] for edge in edges)
    if inputs is None:
        inputs = sorted({edge[1] for edge in edges})
    if outputs is None:
        outputs = sorted({edge[2] for edge in edges})
    catalog = QueueCatalog(qids)
    params = {"constraint": _constraint(inputs, outputs, edges)}
    if priority is not None:
        params["priority"] = priority
    scheduler = CrossbarMaxWeightScheduler(params)
    scheduler.configure_for_domain(QueueSchedulerDomain(catalog, "crossbar_matching"))
    return scheduler, catalog


def _exhaustive_exact_schedule(edges, q_len, catalog, priority=None):
    """Independent subset oracle using the specified exact composite weights."""

    weights = exact_lex_weights(q_len, catalog, priority)
    best_weight = -1
    best: tuple[int, ...] | None = None
    for bits in product((0, 1), repeat=len(edges)):
        selected = tuple(index for index, bit in enumerate(bits) if bit)
        if any(q_len[index] == 0 for index in selected):
            continue
        if len({edges[index][1] for index in selected}) != len(selected):
            continue
        if len({edges[index][2] for index in selected}) != len(selected):
            continue
        weight = sum(weights[index] for index in selected)
        if weight > best_weight:
            best_weight = weight
            best = selected
    assert best is not None
    return tuple(catalog.queue_id_at(index) for index in best)


def test_sparse_rectangular_crossbar_leaves_isolated_and_empty_ports_unmatched() -> None:
    edges = (
        ("a", "in-0", "out-0"),
        ("b", "in-0", "out-2"),
        ("c", "in-2", "out-1"),
    )
    scheduler, _catalog = _build(
        edges,
        inputs=("in-0", "in-1", "in-2", "in-3"),
        outputs=("out-0", "out-1", "out-2"),
    )

    decision = scheduler.select_service([0, 8, 5], 0, np.random.default_rng(17))

    assert decision == ServiceDecision(("b", "c"))
    assert scheduler.optimizer_id == "hungarian_exact"
    assert scheduler.service_family == "crossbar_matching"


def test_nonuniform_lengths_optimize_maxweight_not_maximum_cardinality() -> None:
    # {b,c} has cardinality two and primary weight nine.  {a} has cardinality
    # one and primary weight ten, so optional MaxWeight must leave i1/o1 idle.
    edges = (
        ("a", "i0", "o0"),
        ("b", "i0", "o1"),
        ("c", "i1", "o0"),
    )
    scheduler, _catalog = _build(edges)

    assert scheduler.select_service([10, 6, 3], 9, np.random.default_rng(3)) == ServiceDecision(("a",))


def test_exact_lexicographic_selection_uses_declared_priority() -> None:
    edges = (
        ("a", 0, 0),
        ("b", 0, 1),
        ("c", 1, 0),
        ("d", 1, 1),
    )
    scheduler, _catalog = _build(edges, priority=("b", "c", "a", "d"))

    # Both diagonals have primary weight two.  The first priority bit selects
    # b, after which feasibility forces c.
    assert scheduler.select_service([1, 1, 1, 1], 0, np.random.default_rng(0)) == ServiceDecision(("b", "c"))


@pytest.mark.parametrize("seed", range(60))
def test_public_scheduler_equals_exhaustive_enumeration_on_small_instances(seed: int) -> None:
    random_source = random.Random(10_000 + seed)
    n_inputs = random_source.randint(1, 3)
    n_outputs = random_source.randint(1, 3)
    pairs = [
        pair
        for pair in product(range(n_inputs), range(n_outputs))
        if random_source.random() < 0.7
    ]
    if not pairs:
        pairs.append((random_source.randrange(n_inputs), random_source.randrange(n_outputs)))
    edges = tuple((f"q{index}", input_port, output_port) for index, (input_port, output_port) in enumerate(pairs))
    q_len = tuple(random_source.randrange(0, 8) for _edge in edges)
    priority = list(edge[0] for edge in edges)
    random_source.shuffle(priority)
    scheduler, catalog = _build(
        edges,
        inputs=range(n_inputs),
        outputs=range(n_outputs),
        priority=priority,
    )

    actual = scheduler.select_service(q_len, seed, np.random.default_rng(seed))
    expected = _exhaustive_exact_schedule(edges, q_len, catalog, priority)

    assert actual == ServiceDecision(expected).canonical_for(catalog)


def test_all_empty_queues_return_empty_service_without_consuming_rng() -> None:
    edges = (
        ("a", 0, 0),
        ("b", 0, 1),
        ("c", 1, 0),
        ("d", 1, 1),
    )
    scheduler, _catalog = _build(edges)
    rng = np.random.default_rng(441)
    before = rng.bit_generator.state

    decision = scheduler.select_service([0, 0, 0, 0], 0, rng)

    assert decision == ServiceDecision.empty()
    assert rng.bit_generator.state == before


def test_arbitrary_precision_composite_weights_survive_public_hungarian_path() -> None:
    # With seventy queues, every composite weight exceeds signed int64 even
    # for backlog one.  The single input makes the expected priority winner
    # transparent while exercising exact Python-integer Hungarian arithmetic.
    queue_count = 70
    edges = tuple((f"q{index:02d}", "input", f"out-{index:02d}") for index in range(queue_count))
    priority = tuple(reversed(tuple(edge[0] for edge in edges)))
    scheduler, catalog = _build(edges, inputs=("input",), priority=priority)

    weights = exact_lex_weights([1] * queue_count, catalog, priority)
    assert max(weights) > np.iinfo(np.int64).max
    assert scheduler.select_service(
        [1] * queue_count,
        0,
        np.random.default_rng(1),
    ) == ServiceDecision((priority[0],))


def test_sparse_assignment_treats_missing_arc_as_structural_absence() -> None:
    # A guessed finite forbidden cost could accidentally choose (row 1,col 0)
    # here when the genuine weights are still smaller.  Sparse adjacency has no
    # such value and correctly reports that no perfect assignment exists.
    huge_negative = -(1 << 400)
    with pytest.raises(ScheduleError, match="perfect assignment"):
        _maximum_weight_perfect_assignment(({0: huge_negative}, {0: huge_negative - 1}))


def test_sparse_assignment_accepts_unbounded_integer_weights_without_sentinel_collision() -> None:
    enormous = 1 << 500
    assignment = _maximum_weight_perfect_assignment(
        (
            {0: -enormous, 1: enormous + 7},
            {0: enormous + 3, 1: -enormous},
        )
    )
    assert assignment == (1, 0)


def test_sparse_assignment_never_materializes_a_missing_tempting_arc() -> None:
    enormous = 1 << 400
    assignment = _maximum_weight_perfect_assignment(
        (
            {0: -enormous, 1: -enormous - 1},
            {1: -enormous},
        )
    )
    # If the absent row-1/column-0 arc were represented by numeric zero, the
    # invalid other permutation would dominate these genuine negative arcs.
    assert assignment == (0, 1)


def test_constraint_canonicalization_is_order_invariant_and_mixed_id_safe() -> None:
    first = {
        "constraint": _constraint(
            ("input", 2, 0),
            ("output", 3),
            (("z", "input", 3), (4, 0, "output"), ("a", 2, 3)),
        ),
        "priority": ("z", 4, "a"),
    }
    second = {
        "priority": ["z", 4, "a"],
        "constraint": _constraint(
            (0, "input", 2),
            (3, "output"),
            (("a", 2, 3), ("z", "input", 3), (4, 0, "output")),
        ),
    }

    left = CrossbarMaxWeightScheduler(first)
    right = CrossbarMaxWeightScheduler(second)

    assert left.effective_params == right.effective_params
    assert left.effective_params == {
        "constraint": {
            "inputs": [0, 2, "input"],
            "outputs": [3, "output"],
            "edges": [
                {"queue_id": 4, "input": 0, "output": "output"},
                {"queue_id": "a", "input": 2, "output": 3},
                {"queue_id": "z", "input": "input", "output": 3},
            ],
        },
        "priority": ["z", 4, "a"],
    }


def test_constraint_rejects_parallel_pair_labels_as_ambiguous_crossbar_edges() -> None:
    with pytest.raises(ValidationError, match="duplicate input/output edges"):
        CrossbarMaxWeightScheduler(
            {
                "constraint": _constraint(
                    (0,),
                    (0,),
                    (("parallel-a", 0, 0), ("parallel-b", 0, 0)),
                )
            }
        )


def test_constructor_wraps_nonfinite_json_params_as_validation_error() -> None:
    with pytest.raises(ValidationError, match="finite JSON-safe"):
        CrossbarMaxWeightScheduler({"priority": [float("nan")]})


@pytest.mark.parametrize(
    "constraint,match",
    [
        (_constraint((0, 0), (0,), (("q", 0, 0),)), "duplicate port"),
        (_constraint((0,), (0,), (("q", 1, 0),)), "undeclared input"),
        (_constraint((0,), (0,), (("q", 0, 1),)), "undeclared output"),
        (_constraint((0,), (0,), (("q", 0, 0), ("q", 0, 0))), "duplicate queue_id"),
    ],
)
def test_invalid_constraint_is_rejected_before_binding(constraint, match) -> None:
    with pytest.raises(ValidationError, match=match):
        CrossbarMaxWeightScheduler({"constraint": constraint})


def test_constraint_must_cover_queue_catalog_exactly() -> None:
    scheduler = CrossbarMaxWeightScheduler(
        {"constraint": _constraint((0,), (0,), (("q0", 0, 0),))}
    )
    domain = QueueSchedulerDomain(QueueCatalog(("q0", "q1")), "crossbar_matching")

    with pytest.raises(ValidationError, match="must equal the queue catalog"):
        scheduler.configure_for_domain(domain)


def test_domain_validator_rejects_empty_and_physically_conflicting_selections() -> None:
    edges = (
        ("a", "i0", "o0"),
        ("b", "i0", "o1"),
        ("c", "i1", "o0"),
    )
    scheduler, _catalog = _build(edges)

    with pytest.raises(ScheduleError, match="empty queue"):
        scheduler.validate_service_decision(ServiceDecision(("b",)), [4, 0, 3])
    with pytest.raises(ScheduleError, match="per-input"):
        scheduler.validate_service_decision(ServiceDecision(("a", "b")), [4, 2, 3])
    with pytest.raises(ScheduleError, match="per-output"):
        scheduler.validate_service_decision(ServiceDecision(("a", "c")), [4, 2, 3])


def test_legacy_crossbar_domain_infers_the_complete_topology() -> None:
    domain = CrossbarSchedulerDomain.legacy_crossbar(2)
    scheduler = CrossbarMaxWeightScheduler()
    scheduler.configure_for_domain(domain)

    decision = scheduler.select_service([9, 8, 7, 0], 0, np.random.default_rng(2))

    assert decision == ServiceDecision(("voq[0,1]", "voq[1,0]"))
    assert scheduler.effective_params == {"priority": None}
    assert scheduler.constraint == {
        "inputs": [0, 1],
        "outputs": [0, 1],
        "edges": [
            {"queue_id": "voq[0,0]", "input": 0, "output": 0},
            {"queue_id": "voq[0,1]", "input": 0, "output": 1},
            {"queue_id": "voq[1,0]", "input": 1, "output": 0},
            {"queue_id": "voq[1,1]", "input": 1, "output": 1},
        ],
    }


def test_omitted_constraint_is_rejected_for_generalized_domain() -> None:
    scheduler = CrossbarMaxWeightScheduler()
    with pytest.raises(ValidationError, match="requires scheduler.params.constraint"):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(QueueCatalog(("q",)), "crossbar_matching")
        )


def test_explicit_constraint_is_rejected_for_legacy_domain() -> None:
    scheduler = CrossbarMaxWeightScheduler(
        {
            "constraint": _constraint(
                (0, 1),
                (0, 1),
                (
                    ("voq[0,0]", 0, 0),
                    ("voq[0,1]", 0, 1),
                    ("voq[1,0]", 1, 0),
                    ("voq[1,1]", 1, 1),
                ),
            )
        }
    )
    with pytest.raises(ValidationError, match="derive topology from the switch"):
        scheduler.configure_for_domain(CrossbarSchedulerDomain.legacy_crossbar(2))
