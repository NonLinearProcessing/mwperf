from __future__ import annotations

from dataclasses import fields
import sqlite3

import pytest

from voqsim.errors import ValidationError
from voqsim.telemetry.observations import (
    BINARY64_NORMALIZED_MASS,
    GAP_EXACT,
    GAP_NONE,
    MASS_BINARY64_LATTICE,
    CompactObservationReader,
    CompactObservationRecorder,
    LevelRow,
    ObservationTarget,
    TargetSlotObservation,
    WeightedBoundarySample,
    WeightedTargetSample,
    binary64_lattice_numerator,
    encode_bigint,
    merge_level_streams,
)


_GAP_FIELD_NAMES = (
    "gap_negative",
    "gap_zero",
    "gap_positive",
    "gap_zero_served",
    "gap_positive_sum",
    "gap_negative_sum",
)


def _record_exact(path, *, watermark: int = 100, actual_seed: int = 1) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=4,
        targets=[ObservationTarget("q", "q", gap_mode=GAP_EXACT)],
        metadata={"actual_seed": actual_seed, "slot_convention": "service_before_arrivals"},
        soft_watermark_rows=watermark,
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 1, 0, 1, 1, 0, gap=0)])
    recorder.record_slot(1, [TargetSlotObservation("q", 1, 0, 1, 0, 0, 0, gap=1)])
    recorder.record_slot(2, [TargetSlotObservation("q", 0, 2, 0, 2, 2, 0, gap=-3)])
    recorder.record_slot(3, [TargetSlotObservation("q", 2, 1, 1, 0, 0, 0, gap=0)])
    recorder.complete()
    recorder.close()


def _scientific_rows(path):
    with CompactObservationReader(path) as reader:
        return (
            reader.state,
            tuple(reader.iter_targets()),
            tuple(reader.iter_levels()),
            tuple(reader.iter_boundaries()),
            tuple(reader.iter_target_blocks()),
        )


def test_exact_gap_fields_share_the_sparse_level_row(tmp_path) -> None:
    path = tmp_path / "exact.sqlite3"
    _record_exact(path)

    with CompactObservationReader(path) as reader:
        target = tuple(reader.iter_targets())[0]
        assert target.gap_mode == GAP_EXACT
        rows = tuple(reader.iter_levels())
        assert [row.backlog for row in rows] == [0, 1, 2]
        assert [row.gap_mode for row in rows] == [GAP_EXACT] * 3

        zero, positive, tie = rows
        assert (
            zero.exposure,
            zero.served,
            zero.gap_negative,
            zero.gap_zero,
            zero.gap_positive,
            zero.gap_zero_served,
            zero.gap_positive_sum,
            zero.gap_negative_sum,
        ) == (2, 0, 1, 1, 0, 0, 0, 3)
        assert (
            positive.exposure,
            positive.served,
            positive.gap_negative,
            positive.gap_zero,
            positive.gap_positive,
            positive.gap_zero_served,
            positive.gap_positive_sum,
            positive.gap_negative_sum,
        ) == (1, 1, 0, 0, 1, 0, 1, 0)
        assert (
            tie.exposure,
            tie.served,
            tie.gap_negative,
            tie.gap_zero,
            tie.gap_positive,
            tie.gap_zero_served,
            tie.gap_positive_sum,
            tie.gap_negative_sum,
        ) == (1, 1, 0, 1, 0, 1, 0, 0)
        reader.integrity_check()

    connection = sqlite3.connect(path)
    try:
        columns = {row[1] for row in connection.execute("PRAGMA table_info(levels)")}
        assert set(_GAP_FIELD_NAMES) <= columns
        assert "gap_levels" not in {
            row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
    finally:
        connection.close()


def test_gap_none_is_explicitly_unavailable_not_an_all_tie_record(tmp_path) -> None:
    path = tmp_path / "none.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "q", gap_mode=GAP_NONE)],
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)])
    recorder.complete()
    recorder.close()

    with CompactObservationReader(path) as reader:
        target = tuple(reader.iter_targets())[0]
        row = tuple(reader.iter_levels())[0]
        assert target.gap_mode == GAP_NONE
        assert row.gap_mode == GAP_NONE
        assert tuple(getattr(row, name) for name in _GAP_FIELD_NAMES) == (None,) * 6
        reader.integrity_check()


def test_weighted_exact_gaps_use_the_binary64_lattice_without_rounding(tmp_path) -> None:
    path = tmp_path / "weighted.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[
            ObservationTarget(
                "q",
                "q",
                mass_kind=MASS_BINARY64_LATTICE,
                gap_mode=GAP_EXACT,
            )
        ],
        unit_kind="weighted_ensemble",
    )
    recorder.record_weighted_boundary(
        0,
        [
            WeightedBoundarySample.from_binary64(target_id="q", backlog=0, weight=0.25),
            WeightedBoundarySample.from_binary64(target_id="q", backlog=2, weight=0.75),
        ],
    )
    recorder.record_weighted_slot(
        0,
        [
            WeightedTargetSample.from_binary64(
                target_id="q", backlog=0, weight=0.25, served=0, gap=-2
            ),
            WeightedTargetSample.from_binary64(
                target_id="q", backlog=2, weight=0.75, served=1, gap=0
            ),
        ],
    )
    recorder.record_weighted_boundary(
        1,
        [WeightedBoundarySample.from_binary64(target_id="q", backlog=1, weight=1.0)],
    )
    recorder.complete()
    recorder.close()

    quarter = binary64_lattice_numerator(0.25)
    half = binary64_lattice_numerator(0.5)
    three_quarters = binary64_lattice_numerator(0.75)
    with CompactObservationReader(path) as reader:
        zero, tie = tuple(reader.iter_levels())
        assert zero.gap_negative == quarter
        assert zero.gap_negative_sum == half
        assert zero.gap_zero == zero.gap_positive == zero.gap_zero_served == 0
        assert tie.gap_zero == three_quarters
        assert tie.gap_zero_served == three_quarters
        assert tie.served == three_quarters
        assert sum(row.exposure for row in (zero, tie)) == BINARY64_NORMALIZED_MASS
        reader.integrity_check()


def test_missing_exact_gap_cannot_partially_promote_a_multi_target_slot(tmp_path) -> None:
    path = tmp_path / "atomic.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[
            ObservationTarget("a", "a", gap_mode=GAP_EXACT),
            ObservationTarget("b", "b", gap_mode=GAP_EXACT),
        ],
    )
    with pytest.raises(ValidationError, match="missing its gap"):
        recorder.record_slot(
            0,
            [
                TargetSlotObservation("a", 0, 0, 0, 0, 0, 0, gap=0),
                TargetSlotObservation("b", 0, 0, 0, 0, 0, 0),
            ],
        )
    assert recorder.pending_sparse_rows == 0
    assert recorder._next_slot == 0
    recorder.fail("invalid exact-gap slot")
    recorder.close()

    with CompactObservationReader(path, require_complete=False) as reader:
        assert tuple(reader.iter_levels()) == ()


def test_exact_gap_watermark_changes_only_flush_timing(tmp_path) -> None:
    frequent = tmp_path / "frequent.sqlite3"
    deferred = tmp_path / "deferred.sqlite3"
    _record_exact(frequent, watermark=1)
    _record_exact(deferred, watermark=1_000_000)
    assert _scientific_rows(frequent) == _scientific_rows(deferred)


def test_exact_gap_merge_sums_every_additive_field(tmp_path) -> None:
    first = tmp_path / "first.sqlite3"
    second = tmp_path / "second.sqlite3"
    _record_exact(first, actual_seed=1)
    _record_exact(second, actual_seed=2)
    with CompactObservationReader(first) as left, CompactObservationReader(second) as right:
        rows = tuple(merge_level_streams([left, right]))
    zero, positive, tie = rows
    assert (zero.exposure, zero.gap_negative, zero.gap_zero, zero.gap_negative_sum) == (
        4,
        2,
        2,
        6,
    )
    assert (positive.gap_positive, positive.gap_positive_sum, positive.served) == (2, 2, 2)
    assert (tie.gap_zero, tie.gap_zero_served, tie.served) == (2, 2, 2)


def test_arbitrarily_large_gap_moment_is_preserved_exactly(tmp_path) -> None:
    path = tmp_path / "huge.sqlite3"
    gap = -(1 << 5000)
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "q", gap_mode=GAP_EXACT)],
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0, gap=gap)])
    recorder.complete()
    recorder.close()
    with CompactObservationReader(path) as reader:
        row = tuple(reader.iter_levels())[0]
        assert row.gap_negative_sum == -gap
        reader.integrity_check()


@pytest.mark.parametrize(
    "statement",
    [
        "UPDATE levels SET gap_positive = ? WHERE target_id = 'q' AND backlog = 1",
        "UPDATE levels SET gap_positive_sum = ? WHERE target_id = 'q' AND backlog = 1",
        "UPDATE levels SET gap_zero_served = ? WHERE target_id = 'q' AND backlog = 2",
    ],
)
def test_reader_integrity_rejects_corrupt_exact_gap_invariants(tmp_path, statement) -> None:
    path = tmp_path / "corrupt.sqlite3"
    _record_exact(path)
    connection = sqlite3.connect(path)
    try:
        connection.execute(statement, (encode_bigint(2),))
        connection.commit()
    finally:
        connection.close()
    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match="exact-gap level masses"):
            reader.integrity_check()


def test_reader_integrity_enforces_pointwise_positive_gap_bound(tmp_path) -> None:
    path = tmp_path / "positive_bound.sqlite3"
    _record_exact(path)
    connection = sqlite3.connect(path)
    try:
        connection.execute(
            """
            UPDATE levels SET
                exposure = ?, served = ?,
                gap_negative = ?, gap_zero = ?, gap_positive = ?,
                gap_zero_served = ?, gap_positive_sum = ?, gap_negative_sum = ?
            WHERE target_id = 'q' AND backlog = 1
            """,
            tuple(encode_bigint(value) for value in (2, 1, 1, 0, 1, 0, 3, 1)),
        )
        connection.commit()
    finally:
        connection.close()
    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match="pointwise backlog bound"):
            reader.integrity_check()


def test_reader_integrity_rejects_gap_payload_on_gap_none_target(tmp_path) -> None:
    path = tmp_path / "none_corrupt.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("q", "q")],
    )
    recorder.record_slot(0, [TargetSlotObservation("q", 0, 0, 0, 0, 0, 0)])
    recorder.complete()
    recorder.close()

    zero = encode_bigint(0)
    connection = sqlite3.connect(path)
    try:
        connection.execute(
            """
            UPDATE levels SET
                gap_negative = ?, gap_zero = ?, gap_positive = ?,
                gap_zero_served = ?, gap_positive_sum = ?, gap_negative_sum = ?
            WHERE target_id = 'q'
            """,
            (zero, zero, zero, zero, zero, zero),
        )
        connection.commit()
    finally:
        connection.close()
    with CompactObservationReader(path) as reader:
        with pytest.raises(ValidationError, match="gap-disabled"):
            reader.integrity_check()


def test_public_level_row_exposes_named_logical_gap_fields() -> None:
    names = tuple(field.name for field in fields(LevelRow))
    assert names[-6:] == _GAP_FIELD_NAMES
