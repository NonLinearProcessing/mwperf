from __future__ import annotations

from collections.abc import Mapping

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, QueueSpec, ServiceDecision
from voqsim.rng import build_scheduler_rng_for_slot
from voqsim.schedulers import (
    QueueSchedulerBase,
    QueueSchedulerDomain,
    SchedulerBase,
    SchedulerCapabilities,
    build_scheduler_for_domain,
    register_scheduler,
    resolve_scheduler_spec,
    scheduler_capabilities,
    scheduler_supports_service,
    unregister_scheduler,
    validate_scheduler_service_decision,
)
from voqsim.types import JSONValue


class _FirstNonemptyQueuesScheduler(QueueSchedulerBase):
    algorithm_id = "test_first_nonempty"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        limit = int(self.params.get("limit", 2))
        if limit < 1:
            raise ValueError("limit must be positive")
        self._limit = limit
        self._params = {"limit": limit}

    @property
    def name(self) -> str:
        return "patch1_first_nonempty"

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        vector, _slot, _rng = self.validate_queue_select_inputs(q_len, slot, rng)
        selected = tuple(
            self.scheduler_domain.queue_catalog.queue_id_at(index)
            for index in np.flatnonzero(vector > 0)[: self._limit].tolist()
        )
        return self.validate_service_decision(ServiceDecision(selected), vector)


class _IncompleteQueueScheduler(SchedulerBase):
    @property
    def name(self) -> str:
        return "patch1_incomplete_queue"

    def configure_for_domain(self, domain) -> None:
        self.domain = domain


@pytest.fixture
def generic_test_scheduler() -> None:
    register_scheduler(
        "patch1_first_nonempty",
        _FirstNonemptyQueuesScheduler,
        capabilities=SchedulerCapabilities.queue_vector(("unconstrained",)),
        replace=True,
    )
    try:
        yield
    finally:
        unregister_scheduler("patch1_first_nonempty")


def test_registry_resolves_effective_defaults_algorithm_and_capabilities() -> None:
    spec = resolve_scheduler_spec("crossbar_random_grant_accept", {"rounds": 2})
    assert spec.name == "crossbar_random_grant_accept"
    assert spec.algorithm_id == "uniform_random_grant_accept"
    assert spec.params == {"rounds": 2}
    assert spec.service_family == "crossbar_matching"
    assert spec.capabilities.to_dict() == {
        "input_kind": "queue_vector",
        "output_kind": "service_decision",
        "service_families": ["crossbar_matching"],
    }
    assert scheduler_capabilities("crossbar_max_weight").input_kind == "queue_vector"
    assert scheduler_supports_service("crossbar_max_weight", "crossbar-matching")
    assert not scheduler_supports_service("crossbar_max_weight", "unconstrained")


def test_every_scheduler_registration_requires_explicit_native_capabilities() -> None:
    with pytest.raises(ValidationError, match="explicit native capabilities"):
        register_scheduler(
            "patch1_first_nonempty",
            _FirstNonemptyQueuesScheduler,
            replace=True,
        )

    def factory(params=None):
        return _FirstNonemptyQueuesScheduler(params)

    with pytest.raises(ValidationError, match="explicit native capabilities"):
        register_scheduler("patch1_callable_without_capabilities", factory, replace=True)


def test_removed_matrix_capability_cannot_bind() -> None:
    with pytest.raises(ValidationError, match="input_kind is invalid"):
        SchedulerCapabilities(  # type: ignore[arg-type]
            input_kind="crossbar_matrix",
            output_kind="matching",  # type: ignore[arg-type]
            service_families=("crossbar_matching",),
        )


@pytest.mark.parametrize(
    "retired_name",
    [
        "max_weight",
        "maxweight",
        "random_maximal",
        "islip_rga",
        "islip_canonical",
        "canonical_islip",
    ],
)
def test_retired_scheduler_names_cannot_be_reregistered(retired_name: str) -> None:
    capabilities = SchedulerCapabilities.queue_vector(("unconstrained",))
    with pytest.raises(ValidationError, match="retired scheduler"):
        register_scheduler(retired_name, _FirstNonemptyQueuesScheduler, capabilities=capabilities)
    with pytest.raises(ValidationError, match="retired scheduler"):
        register_scheduler(
            "patch1_retired_alias_probe",
            _FirstNonemptyQueuesScheduler,
            aliases=(retired_name,),
            capabilities=capabilities,
        )


@pytest.mark.parametrize("removed_name", ["round_robin", "roundrobin"])
def test_pruned_scheduler_names_cannot_be_reregistered(removed_name: str) -> None:
    capabilities = SchedulerCapabilities.queue_vector(("unconstrained",))
    with pytest.raises(ValidationError, match="removed scheduler"):
        register_scheduler(removed_name, _FirstNonemptyQueuesScheduler, capabilities=capabilities)
    with pytest.raises(ValidationError, match="removed scheduler"):
        register_scheduler(
            "patch1_removed_alias_probe",
            _FirstNonemptyQueuesScheduler,
            aliases=(removed_name,),
            capabilities=capabilities,
        )


def test_queue_vector_capability_requires_complete_plugin_protocol() -> None:
    register_scheduler(
        "patch1_incomplete_queue",
        _IncompleteQueueScheduler,
        capabilities=SchedulerCapabilities.queue_vector(("unconstrained",)),
        replace=True,
    )
    try:
        with pytest.raises(ValidationError, match="QueueScheduler protocol"):
            build_scheduler_for_domain(
                "patch1_incomplete_queue",
                {},
                QueueSchedulerDomain(QueueCatalog(("q",))),
            )
    finally:
        unregister_scheduler("patch1_incomplete_queue")


def test_native_queue_scheduler_keeps_parallel_labels_distinct(
    generic_test_scheduler: None,
) -> None:
    catalog = QueueCatalog(
        (
            QueueSpec("parallel-a", legacy_voq=(0, 1)),
            QueueSpec("parallel-b", legacy_voq=(0, 1)),
            QueueSpec("other"),
        )
    )
    scheduler = build_scheduler_for_domain(
        "patch1_first_nonempty",
        {},
        QueueSchedulerDomain(catalog, service_family="unconstrained"),
    )
    decision = scheduler.select_service(
        np.array([3, 4, 0], dtype=np.int64),
        slot=0,
        rng=build_scheduler_rng_for_slot(99, 0),
    )
    assert decision.selected_queue_ids == ("parallel-a", "parallel-b")


def test_generic_scheduler_constructor_defaults_are_canonical(
    generic_test_scheduler: None,
) -> None:
    spec = resolve_scheduler_spec("patch1_first_nonempty", {})
    assert spec.name == "patch1_first_nonempty"
    assert spec.algorithm_id == "test_first_nonempty"
    assert spec.params == {"limit": 2}
    assert spec.capabilities == SchedulerCapabilities.queue_vector(("unconstrained",))


def test_common_decision_validation_rejects_out_of_domain_and_empty_queues() -> None:
    catalog = QueueCatalog(("a", "b"))
    vector = np.array([1, 0], dtype=np.int64)
    with pytest.raises(ScheduleError, match="outside"):
        validate_scheduler_service_decision(ServiceDecision(("missing",)), vector, catalog)
    with pytest.raises(ScheduleError, match="empty"):
        validate_scheduler_service_decision(ServiceDecision(("b",)), vector, catalog)
    with pytest.raises(ScheduleError, match="duplicate"):
        ServiceDecision(("a", "a"))
    with pytest.raises(ValidationError, match="not a string"):
        ServiceDecision("ab")
