from __future__ import annotations

import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, resolve_config
from voqsim.kernel import build_simulation
from voqsim.stats import GenericRunStats, OnlineMoments
from voqsim.telemetry import SummaryWriter
from voqsim.traffic.compiler import compile_arrival_spec
from voqsim.utils import canonical_json_dumps


def _count_config(*, write_slot_trace: bool = False) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 1234, "slots": 3},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 1,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": {
            "family": "iid_count_table",
            "outcomes": [
                {
                    "id": "batch",
                    "probability": 1,
                    "counts": [
                        {"queue_id": "q0", "count": 2},
                        {"queue_id": "q1", "count": 1},
                    ],
                }
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": write_slot_trace,
            "observation": {"enabled": False, "block_slots": None, "targets": []},
        },
    }


def _markov_config() -> dict[str, object]:
    config = _count_config()
    config["run"] = {"seed": 1234, "slots": 4}
    config["switch"] = {
        "kind": "generalized",
        "queue_capacity": 2,
        "queues": [{"id": "q0"}, {"id": "q1"}],
    }
    config["arrival"] = {
        "family": "markov_count_kernel",
        "states": ["off", "on"],
        "outcomes": [
            {"id": "idle", "counts": []},
            {"id": "hit", "counts": [{"queue_id": "q0", "count": 1}]},
        ],
        "kernel": [
            {"state": "off", "outcome_id": "hit", "next_state": "on", "probability": 1},
            {"state": "on", "outcome_id": "idle", "next_state": "off", "probability": 1},
        ],
        "initial": {"state": "off"},
    }
    return config


def test_generic_run_stats_exact_integer_arrays_do_not_wrap_at_int64_limit() -> None:
    compiled = compile_arrival_spec(resolve_config(_count_config()))
    stats = GenericRunStats.from_catalog(
        compiled.queue_catalog,
        live_queue_ids=compiled.live_queue_ids(),
        family=compiled.family,
        queue_capacity=1,
    )

    stats._offered_counts[0] = 2**63 - 1
    stats._offered_counts[0] += 1
    stats._q_before_sum[0] = 2**63

    assert stats._offered_counts[0] == 2**63
    assert stats._q_before_sum[0] == 2**63


def test_online_moments_tracks_mean_and_variance() -> None:
    moments = OnlineMoments()
    for value in (1.0, 2.0, 3.0):
        moments.update(value)

    assert moments.count == 3
    assert moments.mean == pytest.approx(2.0)
    assert moments.variance == pytest.approx(2.0 / 3.0)
    assert moments.sample_variance == pytest.approx(1.0)
    assert moments.minimum == pytest.approx(1.0)
    assert moments.maximum == pytest.approx(3.0)


def test_generic_run_summary_counts_queue_metrics_and_scheduler_identity(tmp_path) -> None:
    result = build_simulation(_count_config(), output_dir=tmp_path / "summary").run()
    payload = result.summary.to_dict()
    metrics = payload["metrics"]

    assert metrics["slots_observed"] == 3
    assert metrics["offered_packets"] == 9
    assert metrics["admitted_packets"] == 4
    assert metrics["dropped_packets"] == 5
    assert metrics["completed_packets"] == 2
    assert metrics["mean_sojourn_slots"] == pytest.approx(1.0)
    assert metrics["mean_waiting_slots"] == pytest.approx(1.0)
    assert metrics["mean_total_occupancy_q_before"] == pytest.approx(4 / 3)
    assert metrics["mean_total_occupancy_q_after"] == pytest.approx(2.0)
    assert metrics["drop_reasons"] == {"buffer_full": 5}

    per_queue = {entry["queue_id"]: entry for entry in metrics["per_queue"]}
    assert per_queue["q0"]["offered_packets"] == 6
    assert per_queue["q0"]["admitted_packets"] == 3
    assert per_queue["q0"]["dropped_packets"] == 3
    assert per_queue["q0"]["completed_packets"] == 2
    assert per_queue["q0"]["drop_fraction_of_offered"] == pytest.approx(0.5)
    assert per_queue["q1"]["offered_packets"] == 3
    assert per_queue["q1"]["admitted_packets"] == 1
    assert per_queue["q1"]["dropped_packets"] == 2
    assert per_queue["q1"]["completed_packets"] == 0

    assert metrics["arrival"]["outcome_counts"] == [
        {"arrival_outcome_id": "batch", "count": 3, "rate": 1.0}
    ]
    assert metrics["schedule"]["scheduler_ids"] == {"conflict_graph_max_weight": 3}
    assert metrics["schedule"]["algorithm_ids"] == {"mwis_branch_memo_exact": 3}
    assert metrics["schedule"]["optimizer_ids"] == {"mwis_branch_memo_exact": 3}
    assert payload["metadata"]["scheduler_algorithm_id"] == "mwis_branch_memo_exact"
    assert payload["metadata"]["scheduler_optimizer_id"] == "mwis_branch_memo_exact"


def test_markov_state_occupancy_and_transition_counts_are_tracked(tmp_path) -> None:
    result = build_simulation(_markov_config(), output_dir=tmp_path / "markov").run()
    arrival = result.summary.to_dict()["metrics"]["arrival"]

    assert arrival["family"] == "markov_count_kernel"
    assert arrival["live_queue_ids"] == ["q0"]
    assert arrival["outcome_counts"] == [
        {"arrival_outcome_id": "hit", "count": 2, "rate": 0.5},
        {"arrival_outcome_id": "idle", "count": 2, "rate": 0.5},
    ]
    assert arrival["state_occupancy_counts"] == {"off": 2, "on": 2}
    assert arrival["state_transition_counts"] == {
        "off": {"on": 2},
        "on": {"off": 2},
    }


def test_run_summary_serializes_deterministically_and_summary_writer_accepts_it(tmp_path) -> None:
    result_a = build_simulation(_count_config(), output_dir=tmp_path / "a").run()
    result_b = build_simulation(_count_config(), output_dir=tmp_path / "b").run()

    serialized_a = canonical_json_dumps(result_a.summary.to_dict())
    serialized_b = canonical_json_dumps(result_b.summary.to_dict())
    assert serialized_a == serialized_b

    out_path = SummaryWriter(tmp_path / "summary-copy.json").write(result_a.summary)
    assert out_path.read_text(encoding="utf-8") == serialized_a + "\n"
