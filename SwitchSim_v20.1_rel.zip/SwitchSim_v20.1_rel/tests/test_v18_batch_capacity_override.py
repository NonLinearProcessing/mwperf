from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from voqsim.batch import preflight_batch_configs
from voqsim.cli import main
from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY


def _schema4_config(capacity: object = 4) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 1, "slots": 2, "warmup_slots": 0},
        "switch": {
            "kind": "generalized",
            "queue_capacity": capacity,
            "queues": [{"id": "q"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {"constraint": {"conflicts": []}, "priority": ["q"]},
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [{"slot": 0, "queue_id": "q", "count": 1}],
        },
    }


def _write_yaml(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


@pytest.mark.parametrize("override,expected", [(NO_DROP_CAPACITY, None), (7, 7)])
def test_batch_preflight_capacity_override_precedes_validation(
    tmp_path: Path,
    override: int | str,
    expected: int | None,
) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"
    _write_yaml(batch_dir / "first.yaml", _schema4_config(0))
    _write_yaml(batch_dir / "nested" / "second.yaml", _schema4_config(0))

    prepared = preflight_batch_configs(
        batch_dir,
        output_root,
        queue_capacity_override=override,
    )

    assert len(prepared) == 2
    assert all(item.resolved_config.switch.capacity == expected for item in prepared)


def test_batch_cli_capacity_override_is_emitted_in_resolved_config(tmp_path: Path) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"
    _write_yaml(batch_dir / "schema4.yaml", _schema4_config(0))

    assert main(
        [
            "--batch-dir",
            str(batch_dir),
            "--output-root",
            str(output_root),
            "--queue-capacity",
            NO_DROP_CAPACITY,
            "--quiet",
        ]
    ) == 0

    resolved = yaml.safe_load(
        (output_root / "runs" / "schema4" / "resolved_config.yaml").read_text(
            encoding="utf-8"
        )
    )
    assert resolved["switch"]["queue_capacity"] == NO_DROP_CAPACITY
