from __future__ import annotations

from copy import deepcopy
import itertools

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.exact_priority import exact_lex_weights
from voqsim.schedulers.interval_max_weight import IntervalMaxWeightScheduler
from voqsim.utils import canonical_sha256_hexdigest


def _scheduler(
    catalog: QueueCatalog,
    intervals: list[dict[str, object]],
    *,
    priority: list[object] | None = None,
) -> IntervalMaxWeightScheduler:
    params: dict[str, object] = {"constraint": {"intervals": intervals}}
    if priority is not None:
        params["priority"] = priority
    scheduler = IntervalMaxWeightScheduler(params)
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="nonoverlapping_intervals")
    )
    return scheduler


def _interval(queue_id: object, left: object, right: object) -> dict[str, object]:
    return {"queue_id": queue_id, "left": left, "right": right}


def _select(
    scheduler: IntervalMaxWeightScheduler,
    q_len: list[int] | np.ndarray,
    *,
    slot: int = 0,
) -> tuple[object, ...]:
    return scheduler.select_service(
        np.asarray(q_len, dtype=np.int64),
        slot,
        np.random.default_rng(12345),
    ).selected_queue_ids


def test_touching_half_open_intervals_are_compatible() -> None:
    catalog = QueueCatalog(("left", "right", "overlap"))
    scheduler = _scheduler(
        catalog,
        [
            _interval("left", 0, 1),
            _interval("right", 1, 2),
            _interval("overlap", 0.5, 1.5),
        ],
    )

    assert _select(scheduler, [4, 4, 7]) == ("left", "right")


def test_nested_intervals_choose_the_larger_exact_weight() -> None:
    catalog = QueueCatalog(("outer", "inner-a", "inner-b"))
    scheduler = _scheduler(
        catalog,
        [
            _interval("outer", 0, 10),
            _interval("inner-a", 1, 4),
            _interval("inner-b", 4, 9),
        ],
    )

    assert _select(scheduler, [11, 6, 6]) == ("inner-a", "inner-b")
    assert _select(scheduler, [13, 6, 6]) == ("outer",)


def test_weighted_case_defeats_greedy_largest_queue_selection() -> None:
    catalog = QueueCatalog(("whole", "first", "second"))
    scheduler = _scheduler(
        catalog,
        [
            _interval("whole", 0, 6),
            _interval("first", 0, 3),
            _interval("second", 3, 6),
        ],
    )

    # Greedily taking the individually heaviest queue gives weight 9.  The
    # exact dynamic program takes the compatible pair of total weight 10.
    assert _select(scheduler, [9, 5, 5]) == ("first", "second")


def test_nonuniform_lengths_optimize_maxweight_not_maximum_cardinality() -> None:
    catalog = QueueCatalog(("heavy", "small-a", "small-b"))
    scheduler = _scheduler(
        catalog,
        [
            _interval("heavy", 0, 10),
            _interval("small-a", 0, 5),
            _interval("small-b", 5, 10),
        ],
    )

    assert _select(scheduler, [3, 1, 1]) == ("heavy",)


def test_explicit_priority_controls_exact_primary_tie() -> None:
    catalog = QueueCatalog(("a", "b"))
    intervals = [_interval("a", -1, 2), _interval("b", -1, 2)]

    assert _select(_scheduler(catalog, intervals), [7, 7]) == ("a",)
    assert _select(_scheduler(catalog, intervals, priority=["b", "a"]), [7, 7]) == (
        "b",
    )


def test_default_priority_is_canonical_null_and_endpoints_are_canonicalized() -> None:
    scheduler = IntervalMaxWeightScheduler(
        {"constraint": {"intervals": [_interval("q", -0.0, 2.0)]}}
    )

    assert scheduler.params == {
        "constraint": {"intervals": [{"queue_id": "q", "left": 0, "right": 2}]},
        "priority": None,
    }


def test_reordered_constraint_entries_have_identical_effective_params_and_hash() -> None:
    entries = [
        _interval("z", 4, 5),
        _interval(7, 0, 1),
        _interval("a", 2, 3),
        _interval(2, 1, 2),
    ]
    forward = IntervalMaxWeightScheduler({"constraint": {"intervals": entries}})
    reverse = IntervalMaxWeightScheduler(
        {"constraint": {"intervals": list(reversed(entries))}}
    )

    assert forward.params == reverse.params
    assert [
        entry["queue_id"] for entry in forward.params["constraint"]["intervals"]
    ] == [2, 7, "a", "z"]
    assert canonical_sha256_hexdigest(forward.params) == canonical_sha256_hexdigest(
        reverse.params
    )


def test_selection_consumes_no_rng_draws() -> None:
    catalog = QueueCatalog(("a", "b"))
    scheduler = _scheduler(
        catalog,
        [_interval("a", 0, 1), _interval("b", 1, 2)],
    )
    rng = np.random.default_rng(88)
    before = deepcopy(rng.bit_generator.state)

    scheduler.select_service(np.array([1, 1]), 9, rng)

    assert rng.bit_generator.state == before


def _is_feasible(
    selected: frozenset[int],
    q_len: tuple[int, ...],
    intervals: tuple[tuple[float, float], ...],
) -> bool:
    if any(q_len[index] == 0 for index in selected):
        return False
    ordered = sorted((intervals[index][0], intervals[index][1], index) for index in selected)
    return all(previous[1] <= current[0] for previous, current in zip(ordered, ordered[1:]))


def _exhaustive_optimum(
    q_len: tuple[int, ...],
    intervals: tuple[tuple[float, float], ...],
    priority_indices: tuple[int, ...],
) -> frozenset[int]:
    best_set = frozenset()
    best_key: tuple[int, tuple[int, ...]] = (-1, ())
    for bits in itertools.product((0, 1), repeat=len(q_len)):
        selected = frozenset(index for index, bit in enumerate(bits) if bit)
        if not _is_feasible(selected, q_len, intervals):
            continue
        key = (
            sum(q_len[index] for index in selected),
            tuple(int(index in selected) for index in priority_indices),
        )
        if key > best_key:
            best_key = key
            best_set = selected
    return best_set


def test_public_results_equal_exhaustive_enumeration_on_small_instances() -> None:
    queue_ids = ("a", "b", "c", "d", "e", "f")
    catalog = QueueCatalog(queue_ids)
    numeric_intervals = (
        (0.0, 3.0),
        (1.0, 2.0),
        (2.0, 4.0),
        (4.0, 6.0),
        (5.0, 7.0),
        (7.0, 8.0),
    )
    priority = ("e", "b", "f", "a", "d", "c")
    priority_indices = tuple(catalog.index_of(queue_id) for queue_id in priority)
    scheduler = _scheduler(
        catalog,
        [
            _interval(queue_id, left, right)
            for queue_id, (left, right) in zip(queue_ids, numeric_intervals, strict=True)
        ],
        priority=list(priority),
    )

    rng = np.random.default_rng(8675309)
    cases = [tuple(int(value) for value in row) for row in rng.integers(0, 8, size=(100, 6))]
    cases.extend([(0, 0, 0, 0, 0, 0), (1, 1, 1, 1, 1, 1)])
    for q_len in cases:
        expected_indices = _exhaustive_optimum(q_len, numeric_intervals, priority_indices)
        expected = tuple(
            queue_id for index, queue_id in enumerate(queue_ids) if index in expected_indices
        )
        assert _select(scheduler, list(q_len)) == expected


def test_dynamic_program_preserves_arbitrary_precision_composite_weights() -> None:
    queue_ids = tuple(f"q{index}" for index in range(80))
    catalog = QueueCatalog(queue_ids)
    priority = list(reversed(queue_ids))
    scheduler = _scheduler(
        catalog,
        [_interval(queue_id, 0, 1) for queue_id in queue_ids],
        priority=priority,
    )
    q_len = np.ones(80, dtype=np.int64)

    assert max(exact_lex_weights(q_len, catalog, priority)) > np.iinfo(np.int64).max
    assert scheduler.select_service(q_len, 0, np.random.default_rng(1)).selected_queue_ids == (
        "q79",
    )


@pytest.mark.parametrize(
    "params, message",
    [
        ({}, "requires a constraint"),
        ({"constraint": {"intervals": []}}, "nonempty list"),
        ({"constraint": {"intervals": [_interval("q", 0, 1)], "extra": 1}}, "unknown"),
        ({"constraint": {"intervals": [{"queue_id": "q", "left": 0}]}}, "exactly"),
        ({"constraint": {"intervals": [_interval("q", True, 1)]}}, "finite real"),
        ({"constraint": {"intervals": [_interval("q", 0, float("nan"))]}}, "finite"),
        ({"constraint": {"intervals": [_interval("q", 1, 1)]}}, "left < right"),
        ({"constraint": {"intervals": [_interval("q", 2, 1)]}}, "left < right"),
        (
            {"constraint": {"intervals": [_interval("q", 0, 1), _interval("q", 1, 2)]}},
            "duplicate queue_id",
        ),
        ({"constraint": {"intervals": [_interval("q", 0, 1)]}, "extra": 1}, "unknown"),
    ],
)
def test_invalid_interval_constraints_fail_strictly(params: dict[str, object], message: str) -> None:
    with pytest.raises(ValidationError, match=message):
        IntervalMaxWeightScheduler(params)


@pytest.mark.parametrize(
    "intervals, message",
    [
        ([_interval("a", 0, 1)], "exactly one interval"),
        (
            [_interval("a", 0, 1), _interval("outside", 1, 2)],
            "exactly one interval",
        ),
    ],
)
def test_missing_or_out_of_domain_intervals_fail_at_domain_binding(
    intervals: list[dict[str, object]],
    message: str,
) -> None:
    scheduler = IntervalMaxWeightScheduler({"constraint": {"intervals": intervals}})
    domain = QueueSchedulerDomain(
        QueueCatalog(("a", "b")),
        service_family="nonoverlapping_intervals",
    )

    with pytest.raises(ValidationError, match=message):
        scheduler.configure_for_domain(domain)
    assert scheduler.scheduler_domain is None


@pytest.mark.parametrize("priority", [[], ["a"], ["a", "a"], ["a", "outside"]])
def test_priority_must_be_an_exact_catalog_permutation(priority: list[str]) -> None:
    with pytest.raises(ValidationError, match="priority"):
        scheduler = IntervalMaxWeightScheduler(
            {
                "constraint": {
                    "intervals": [_interval("a", 0, 1), _interval("b", 1, 2)]
                },
                "priority": priority,
            }
        )
        scheduler.configure_for_domain(
            QueueSchedulerDomain(
                QueueCatalog(("a", "b")),
                service_family="nonoverlapping_intervals",
            )
        )


def test_wrong_service_family_is_rejected() -> None:
    scheduler = IntervalMaxWeightScheduler(
        {"constraint": {"intervals": [_interval("q", 0, 1)]}}
    )
    with pytest.raises(ValidationError, match="nonoverlapping_intervals"):
        scheduler.configure_for_domain(QueueSchedulerDomain(QueueCatalog(("q",))))


def test_public_decision_validator_rejects_overlap() -> None:
    catalog = QueueCatalog(("a", "b", "c"))
    scheduler = _scheduler(
        catalog,
        [
            _interval("a", 0, 2),
            _interval("b", 1, 3),
            _interval("c", 3, 4),
        ],
    )

    with pytest.raises(ScheduleError, match="overlapping intervals"):
        scheduler.validate_service_decision(ServiceDecision(("a", "b")), np.ones(3, dtype=np.int64))


def test_feasibility_validation_handles_mixed_id_types_on_identical_intervals() -> None:
    catalog = QueueCatalog((1, "one"))
    scheduler = _scheduler(
        catalog,
        [_interval(1, 0, 2), _interval("one", 0, 2)],
    )

    with pytest.raises(ScheduleError, match="overlapping intervals"):
        scheduler.validate_service_decision(ServiceDecision((1, "one")), np.ones(2, dtype=np.int64))
