from __future__ import annotations

import ast
import builtins
import mmap
from pathlib import Path
import shelve
import sqlite3
import tempfile

import numpy as np

from voqsim.events import ArrivalAttempt
from voqsim.packet import Packet
from voqsim.queues import QueueBank, QueueCatalog
from voqsim.traffic.count_arrivals import DeterministicTraceArrival


def test_queue_and_arrival_modules_have_no_disk_backing_code() -> None:
    package_root = Path(__file__).parents[1] / "voqsim"
    sources = [
        package_root / "queues.py",
        package_root / "arrival_config.py",
        *sorted((package_root / "traffic").glob("*.py")),
    ]
    forbidden_modules = {"dbm", "mmap", "shelve", "sqlite3", "tempfile"}

    for source in sources:
        tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not ({alias.name.split(".")[0] for alias in node.names} & forbidden_modules)
            elif isinstance(node, ast.ImportFrom) and node.module is not None:
                assert node.module.split(".")[0] not in forbidden_modules
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                assert node.func.id != "open"


def test_nodrop_queue_and_arrival_runtime_do_not_open_disk(monkeypatch) -> None:
    catalog = QueueCatalog(("q",))
    bank = QueueBank(catalog, queue_capacity=None)
    arrival = DeterministicTraceArrival(
        catalog,
        {"events": [{"slot": 0, "queue_id": "q", "count": 2}]},
    )
    rng = np.random.default_rng(18)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("queue/arrival runtime attempted disk-backed storage")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(sqlite3, "connect", forbidden)
    monkeypatch.setattr(mmap, "mmap", forbidden)
    monkeypatch.setattr(shelve, "open", forbidden)
    monkeypatch.setattr(tempfile, "TemporaryFile", forbidden)
    monkeypatch.setattr(tempfile, "NamedTemporaryFile", forbidden)

    sample = arrival.sample(0, rng)
    assert sample.offered_counts is not None
    attempts = tuple(
        ArrivalAttempt.from_packet(
            Packet.for_queue(
                packet_id=packet_id,
                flow_id=0,
                queue_id="q",
                generation_slot=0,
            )
        )
        for packet_id in range(2)
    )
    decisions = bank.enqueue_or_drop(attempts, slot=0)

    assert tuple(sample.offered_counts.to_array()) == (2,)
    assert all(decision.accepted for decision in decisions)
    assert bank.total_occupancy() == 2
