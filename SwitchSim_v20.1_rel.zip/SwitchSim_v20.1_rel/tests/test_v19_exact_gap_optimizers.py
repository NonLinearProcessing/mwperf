from __future__ import annotations

from copy import deepcopy
from itertools import product
from typing import Callable

import numpy as np
import pytest

from voqsim.errors import ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.conflict_graph_max_weight import ConflictGraphMaxWeightScheduler
from voqsim.schedulers.crossbar_max_weight import CrossbarMaxWeightScheduler
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.exact_gap import ExactClassValueScheduler, ExactGapCertificate
from voqsim.schedulers.interval_max_weight import IntervalMaxWeightScheduler
from voqsim.schedulers.node_exclusive_max_weight import NodeExclusiveMaxWeightScheduler
from voqsim.schedulers.resource_packing_max_weight import ResourcePackingMaxWeightScheduler


Feasible = Callable[[frozenset[int]], bool]


def _bind(scheduler, queue_ids: tuple[str, ...], family: str):
    catalog = QueueCatalog(queue_ids)
    scheduler.configure_for_domain(QueueSchedulerDomain(catalog, family))
    return scheduler, catalog


def _crossbar():
    queue_ids = ("q0", "q1", "q2", "q3")
    edges = ((0, 0), (0, 1), (1, 0), (2, 2))
    scheduler, catalog = _bind(
        CrossbarMaxWeightScheduler(
            {
                "constraint": {
                    "inputs": [0, 1, 2],
                    "outputs": [0, 1, 2],
                    "edges": [
                        {"queue_id": queue_id, "input": edge[0], "output": edge[1]}
                        for queue_id, edge in zip(queue_ids, edges, strict=True)
                    ],
                },
                "priority": ["q2", "q1", "q0", "q3"],
            }
        ),
        queue_ids,
        "crossbar_matching",
    )

    def feasible(selected: frozenset[int]) -> bool:
        return (
            len({edges[index][0] for index in selected}) == len(selected)
            and len({edges[index][1] for index in selected}) == len(selected)
        )

    return scheduler, catalog, feasible


def _interval():
    queue_ids = ("q0", "q1", "q2", "q3")
    intervals = ((0, 3), (1, 2), (2, 4), (4, 6))
    scheduler, catalog = _bind(
        IntervalMaxWeightScheduler(
            {
                "constraint": {
                    "intervals": [
                        {"queue_id": queue_id, "left": interval[0], "right": interval[1]}
                        for queue_id, interval in zip(queue_ids, intervals, strict=True)
                    ]
                },
                "priority": ["q3", "q0", "q2", "q1"],
            }
        ),
        queue_ids,
        "nonoverlapping_intervals",
    )

    def feasible(selected: frozenset[int]) -> bool:
        chosen = sorted((intervals[index][0], intervals[index][1]) for index in selected)
        return all(left[1] <= right[0] for left, right in zip(chosen, chosen[1:]))

    return scheduler, catalog, feasible


def _node_exclusive():
    queue_ids = ("q0", "q1", "q2", "q3", "q4")
    links = ((0, 1), (0, 1), (1, 2), (2, 3), (0, 3))
    scheduler, catalog = _bind(
        NodeExclusiveMaxWeightScheduler(
            {
                "constraint": {
                    "vertices": [0, 1, 2, 3],
                    "links": [
                        {"queue_id": queue_id, "u": link[0], "v": link[1]}
                        for queue_id, link in zip(queue_ids, links, strict=True)
                    ],
                },
                "priority": ["q1", "q4", "q2", "q0", "q3"],
            }
        ),
        queue_ids,
        "node_exclusive_matching",
    )

    def feasible(selected: frozenset[int]) -> bool:
        endpoints = [endpoint for index in selected for endpoint in links[index]]
        return len(endpoints) == len(set(endpoints))

    return scheduler, catalog, feasible


def _conflict_graph():
    queue_ids = ("q0", "q1", "q2", "q3", "q4")
    conflicts = frozenset({(0, 1), (0, 2), (1, 2), (2, 3)})
    scheduler, catalog = _bind(
        ConflictGraphMaxWeightScheduler(
            {
                "constraint": {
                    "conflicts": [
                        [queue_ids[left], queue_ids[right]]
                        for left, right in sorted(conflicts)
                    ]
                },
                "priority": ["q4", "q3", "q2", "q1", "q0"],
            }
        ),
        queue_ids,
        "pairwise_conflicts",
    )

    def feasible(selected: frozenset[int]) -> bool:
        return all(not ({left, right} <= selected) for left, right in conflicts)

    return scheduler, catalog, feasible


def _resource_packing():
    queue_ids = ("q0", "q1", "q2", "q3", "q4")
    capacity = (2, 2)
    demands = ((2, 0), (1, 1), (0, 2), (0, 0), (1, 0))
    scheduler, catalog = _bind(
        ResourcePackingMaxWeightScheduler(
            {
                "constraint": {
                    "resources": ["r0", "r1"],
                    "capacity": list(capacity),
                    "demands": [
                        {"queue_id": queue_id, "demand": list(demand)}
                        for queue_id, demand in zip(queue_ids, demands, strict=True)
                    ],
                },
                "priority": ["q3", "q2", "q4", "q1", "q0"],
            }
        ),
        queue_ids,
        "resource_packing",
    )

    def feasible(selected: frozenset[int]) -> bool:
        return all(
            sum(demands[index][resource] for index in selected) <= capacity[resource]
            for resource in range(len(capacity))
        )

    return scheduler, catalog, feasible


BUILDERS = (_crossbar, _interval, _node_exclusive, _conflict_graph, _resource_packing)


def _forced_value(
    q_len: tuple[int, ...],
    feasible: Feasible,
    target: int,
    forced_class: int,
) -> int:
    best: int | None = None
    for bits in product((0, 1), repeat=len(q_len)):
        selected = frozenset(index for index, bit in enumerate(bits) if bit)
        if int(target in selected) != forced_class:
            continue
        if any(index != target and q_len[index] == 0 for index in selected):
            continue
        if forced_class == 0 and any(q_len[index] == 0 for index in selected):
            continue
        if not feasible(selected):
            continue
        value = sum(q_len[index] for index in selected)
        best = value if best is None else max(best, value)
    assert best is not None
    return best


@pytest.mark.parametrize("builder", BUILDERS, ids=lambda builder: builder.__name__.removeprefix("_"))
def test_exact_class_certificates_equal_full_feasible_set_oracle(builder) -> None:
    scheduler, catalog, feasible = builder()
    assert isinstance(scheduler, ExactClassValueScheduler)
    # Exhaust every zero/positive occupancy pattern and multiple primary ties.
    for q_len in product((0, 1, 3), repeat=catalog.n_queues):
        vector = np.asarray(q_len, dtype=np.int64)
        decision = scheduler.select_service(vector, 7, np.random.default_rng(41))
        state_before = deepcopy(scheduler.state_dict())
        vector_before = vector.copy()
        certificates = scheduler.exact_class_certificates(
            vector,
            decision,
            catalog.queue_ids,
            slot=7,
        )

        assert np.array_equal(vector, vector_before)
        assert scheduler.state_dict() == state_before
        assert tuple(certificate.queue_id for certificate in certificates) == catalog.queue_ids
        selected = set(decision.selected_queue_ids)
        production_value = sum(q_len[catalog.index_of(queue_id)] for queue_id in selected)
        for target_index, certificate in enumerate(certificates):
            expected_v0 = _forced_value(q_len, feasible, target_index, 0)
            expected_v1 = _forced_value(q_len, feasible, target_index, 1)
            assert certificate == ExactGapCertificate(
                queue_id=catalog.queue_id_at(target_index),
                backlog=q_len[target_index],
                selected_class=int(catalog.queue_id_at(target_index) in selected),
                production_value=production_value,
                v0=expected_v0,
                v1=expected_v1,
            )
            assert certificate.gap == expected_v1 - expected_v0
            assert certificate.theta == q_len[target_index] - certificate.gap
            assert certificate.theta >= 0


@pytest.mark.parametrize("builder", BUILDERS, ids=lambda builder: builder.__name__.removeprefix("_"))
def test_one_opposite_core_solve_per_target(builder, monkeypatch: pytest.MonkeyPatch) -> None:
    scheduler, catalog, _feasible = builder()
    q_len = np.arange(1, catalog.n_queues + 1, dtype=np.int64)
    decision = scheduler.select_service(q_len, 11, np.random.default_rng(9))
    scheduler_type = type(scheduler)
    original = scheduler_type._solve_exact_indices
    calls = 0

    def counted(self, *args, **kwargs):
        nonlocal calls
        calls += 1
        return original(self, *args, **kwargs)

    monkeypatch.setattr(scheduler_type, "_solve_exact_indices", counted)
    certificates = scheduler.exact_class_certificates(
        q_len,
        decision,
        catalog.queue_ids,
        slot=11,
    )

    assert len(certificates) == catalog.n_queues
    assert calls == catalog.n_queues


def test_empty_crossbar_target_is_value_only_reservation() -> None:
    queue_ids = ("target", "same-input", "same-output")
    scheduler, catalog = _bind(
        CrossbarMaxWeightScheduler(
            {
                "constraint": {
                    "inputs": [0, 1],
                    "outputs": [0, 1],
                    "edges": [
                        {"queue_id": "target", "input": 0, "output": 0},
                        {"queue_id": "same-input", "input": 0, "output": 1},
                        {"queue_id": "same-output", "input": 1, "output": 0},
                    ],
                }
            }
        ),
        queue_ids,
        "crossbar_matching",
    )
    q_len = np.asarray([0, 7, 6], dtype=np.int64)
    decision = scheduler.select_service(q_len, 0, np.random.default_rng(0))

    certificate = scheduler.exact_class_certificates(
        q_len, decision, ("target",), slot=0
    )[0]

    assert decision == ServiceDecision(("same-input", "same-output"))
    assert certificate == ExactGapCertificate("target", 0, 0, 13, 13, 0)
    assert "target" not in decision.selected_queue_ids


def test_node_forced_out_reduces_parallel_labels_again() -> None:
    queue_ids = ("preferred", "parallel", "remote")
    scheduler, _catalog = _bind(
        NodeExclusiveMaxWeightScheduler(
            {
                "constraint": {
                    "vertices": [0, 1, 2, 3],
                    "links": [
                        {"queue_id": "preferred", "u": 0, "v": 1},
                        {"queue_id": "parallel", "u": 0, "v": 1},
                        {"queue_id": "remote", "u": 2, "v": 3},
                    ],
                },
                "priority": ["preferred", "parallel", "remote"],
            }
        ),
        queue_ids,
        "node_exclusive_matching",
    )
    q_len = np.asarray([5, 5, 4], dtype=np.int64)
    decision = scheduler.select_service(q_len, 0, np.random.default_rng(0))
    certificate = scheduler.exact_class_certificates(
        q_len, decision, ("preferred",), slot=0
    )[0]

    assert decision == ServiceDecision(("preferred", "remote"))
    assert certificate.v0 == 9  # parallel + remote, not remote alone
    assert certificate.v1 == 9
    assert certificate.gap == 0


def test_certificate_values_exclude_secondary_priority_score() -> None:
    scheduler, _catalog = _bind(
        CrossbarMaxWeightScheduler(
            {
                "constraint": {
                    "inputs": [0],
                    "outputs": [0, 1],
                    "edges": [
                        {"queue_id": "a", "input": 0, "output": 0},
                        {"queue_id": "b", "input": 0, "output": 1},
                    ],
                },
                "priority": ["a", "b"],
            }
        ),
        ("a", "b"),
        "crossbar_matching",
    )
    q_len = np.asarray([5, 5], dtype=np.int64)
    decision = scheduler.select_service(q_len, 0, np.random.default_rng(0))
    certificates = scheduler.exact_class_certificates(
        q_len, decision, ("a", "b"), slot=0
    )

    assert decision == ServiceDecision(("a",))
    assert [(row.production_value, row.v0, row.v1) for row in certificates] == [
        (5, 5, 5),
        (5, 5, 5),
    ]


def test_infeasible_resource_target_is_rejected_before_restricted_solve() -> None:
    scheduler, _catalog = _bind(
        ResourcePackingMaxWeightScheduler(
            {
                "constraint": {
                    "resources": ["r"],
                    "capacity": [2],
                    "demands": [
                        {"queue_id": "ok", "demand": [1]},
                        {"queue_id": "impossible", "demand": [3]},
                    ],
                }
            }
        ),
        ("ok", "impossible"),
        "resource_packing",
    )
    q_len = np.asarray([1, 0], dtype=np.int64)
    decision = scheduler.select_service(q_len, 0, np.random.default_rng(0))

    with pytest.raises(ValidationError, match="not individually feasible"):
        scheduler.exact_class_certificates(
            q_len,
            decision,
            ("impossible",),
            slot=0,
        )


def test_empty_isolated_conflict_target_has_zero_gap_and_no_service() -> None:
    scheduler, _catalog = _bind(
        ConflictGraphMaxWeightScheduler(
            {"constraint": {"conflicts": []}}
        ),
        ("target", "busy"),
        "pairwise_conflicts",
    )
    q_len = np.asarray([0, 8], dtype=np.int64)
    decision = scheduler.select_service(q_len, 0, np.random.default_rng(0))
    certificate = scheduler.exact_class_certificates(
        q_len, decision, ("target",), slot=0
    )[0]

    assert decision == ServiceDecision(("busy",))
    assert certificate == ExactGapCertificate("target", 0, 0, 8, 8, 8)
    assert certificate.gap == 0
