from __future__ import annotations

"""Small end-to-end coverage of every exact scheduler/canonical arrival pairing.

The matrix deliberately uses a one-queue generalized switch.  That keeps the
test focused on composition at the public config/kernel/artifact boundaries,
without duplicating the optimizer-oracle suites.  Every service model can
serve the queue, and every arrival law offers at least one packet in slot zero;
because service precedes arrivals, a three-slot run must then complete a packet.
"""

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
from typing import Any

import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, load_config
from voqsim.kernel import build_simulation


QUEUE_ID = "q-main"
SLOTS = 3

SCHEDULERS = (
    "crossbar_max_weight",
    "interval_max_weight",
    "node_exclusive_max_weight",
    "conflict_graph_max_weight",
    "resource_packing_max_weight",
)

ARRIVAL_FAMILIES = (
    "iid_independent_bernoulli",
    "iid_count_table",
    "markov_count_kernel",
    "iid_independent_poisson",
    "iid_mixed_poisson",
    "deterministic_trace",
    "periodic_global_phase",
    "periodic_source_delays",
    "independent_marked_renewal",
    "independent_private_markov_renewal",
    "shared_joint_round_markov_renewal",
)

OPTIMIZER_IDS = {
    "crossbar_max_weight": "hungarian_exact",
    "interval_max_weight": "weighted_interval_dp_exact",
    "node_exclusive_max_weight": "edmonds_blossom_exact",
    "conflict_graph_max_weight": "mwis_branch_memo_exact",
    "resource_packing_max_weight": "binary_packing_memo_exact",
}

SERVICE_FAMILIES = {
    "crossbar_max_weight": "crossbar_matching",
    "interval_max_weight": "nonoverlapping_intervals",
    "node_exclusive_max_weight": "node_exclusive_matching",
    "conflict_graph_max_weight": "pairwise_conflicts",
    "resource_packing_max_weight": "resource_packing",
}

MATRIX_CASES = tuple(
    (scheduler_id, arrival_family)
    for scheduler_id in SCHEDULERS
    for arrival_family in ARRIVAL_FAMILIES
)

EXPECTED_STATIC_ARTIFACT_KEYS = {
    "resolved_config",
    "run_manifest",
    "flow_plan",
    "arrival_support",
    "service_model",
}

EXPECTED_RUN_FILENAMES = {
    "resolved_config.yaml",
    "run_manifest.json",
    "flow_plan.json",
    "arrival_support.json",
    "service_model.json",
    "telemetry.jsonl",
    "run_summary.json",
}


def _scheduler_params(scheduler_id: str) -> dict[str, Any]:
    if scheduler_id == "crossbar_max_weight":
        return {
            "constraint": {
                "inputs": ["input-0"],
                "outputs": ["output-0"],
                "edges": [
                    {
                        "queue_id": QUEUE_ID,
                        "input": "input-0",
                        "output": "output-0",
                    }
                ],
            },
            "priority": [QUEUE_ID],
        }
    if scheduler_id == "interval_max_weight":
        return {
            "constraint": {
                "intervals": [
                    {"queue_id": QUEUE_ID, "left": 0, "right": 1}
                ]
            },
            "priority": [QUEUE_ID],
        }
    if scheduler_id == "node_exclusive_max_weight":
        return {
            "constraint": {
                "vertices": ["u", "v"],
                "links": [{"queue_id": QUEUE_ID, "u": "u", "v": "v"}],
            },
            "priority": [QUEUE_ID],
        }
    if scheduler_id == "conflict_graph_max_weight":
        return {
            "constraint": {"conflicts": []},
            "priority": [QUEUE_ID],
            "max_search_states": 128,
        }
    if scheduler_id == "resource_packing_max_weight":
        return {
            "constraint": {
                "resources": ["resource-0"],
                "capacity": [1],
                "demands": [{"queue_id": QUEUE_ID, "demand": [1]}],
            },
            "priority": [QUEUE_ID],
            "max_search_states": 128,
        }
    raise AssertionError(f"unhandled scheduler: {scheduler_id}")


def _arrival_params(arrival_family: str) -> dict[str, Any]:
    if arrival_family == "iid_independent_bernoulli":
        return {
            "family": arrival_family,
            "rates": {
                "default": Decimal(0),
                "overrides": [{"queue_id": QUEUE_ID, "rate": Decimal(1)}],
            },
        }
    if arrival_family == "iid_count_table":
        return {
            "family": arrival_family,
            "outcomes": [
                {
                    "id": "batch",
                    "probability": Decimal(1),
                    "counts": [{"queue_id": QUEUE_ID, "count": 2}],
                }
            ],
        }
    if arrival_family == "markov_count_kernel":
        return {
            "family": arrival_family,
            "states": ["only"],
            "outcomes": [
                {
                    "id": "batch",
                    "counts": [{"queue_id": QUEUE_ID, "count": 2}],
                }
            ],
            "kernel": [
                {
                    "state": "only",
                    "outcome_id": "batch",
                    "next_state": "only",
                    "probability": Decimal(1),
                }
            ],
            "initial": {"state": "only"},
        }
    if arrival_family == "iid_independent_poisson":
        return {
            "family": arrival_family,
            "rates": {
                "default": Decimal(0),
                "overrides": [{"queue_id": QUEUE_ID, "rate": Decimal("2.5")}],
            },
        }
    if arrival_family == "iid_mixed_poisson":
        return {
            "family": arrival_family,
            "rates": {
                "default": Decimal(0),
                "overrides": [{"queue_id": QUEUE_ID, "rate": Decimal("2.5")}],
            },
            "modulation": {
                "scope": "shared",
                "states": [
                    {
                        "id": "one",
                        "probability": Decimal(1),
                        "multiplier": Decimal(1),
                    }
                ],
            },
        }
    if arrival_family == "deterministic_trace":
        return {
            "family": arrival_family,
            "events": [{"slot": 0, "queue_id": QUEUE_ID, "count": 2}],
        }
    if arrival_family == "periodic_global_phase":
        return {
            "family": arrival_family,
            "period": 8,
            "phase": 0,
            "sources": [
                {
                    "id": "source-0",
                    "entries": [
                        {"offset": 0, "queue_id": QUEUE_ID, "count": 2}
                    ],
                }
            ],
        }
    if arrival_family == "periodic_source_delays":
        return {
            "family": arrival_family,
            "period": 8,
            "sources": [
                {
                    "id": "source-0",
                    "delay": 0,
                    "entries": [
                        {"offset": 0, "queue_id": QUEUE_ID, "count": 2}
                    ],
                }
            ],
        }
    if arrival_family == "independent_marked_renewal":
        return {
            "family": arrival_family,
            "sources": [
                {
                    "id": "source-0",
                    "interarrival": {"kind": "deterministic", "d": 1},
                    "destination_pmf": [
                        {"queue_id": QUEUE_ID, "probability": 1.0}
                    ],
                }
            ],
        }
    if arrival_family == "independent_private_markov_renewal":
        return {
            "family": arrival_family,
            "sources": [
                {
                    "id": "source-0",
                    "states": ["only"],
                    "initial": {"state": "only"},
                    "gaps": [{"state": "only", "d": 1}],
                    "transitions": [
                        {
                            "state": "only",
                            "next_state": "only",
                            "probability": 1.0,
                        }
                    ],
                    "destination_pmf": [
                        {"queue_id": QUEUE_ID, "probability": 1.0}
                    ],
                }
            ],
        }
    if arrival_family == "shared_joint_round_markov_renewal":
        return {
            "family": arrival_family,
            "sources": [{"id": "source-0"}],
            "states": ["only"],
            "initial": {"state": "only"},
            "outcomes": [
                {
                    "state": "only",
                    "next_state": "only",
                    "probability": 1.0,
                    "emissions": [
                        {"source_id": "source-0", "d": 1, "queue_id": QUEUE_ID}
                    ],
                }
            ],
        }
    raise AssertionError(f"unhandled arrival family: {arrival_family}")


def _raw_config(
    scheduler_id: str,
    arrival_family: str,
    *,
    seed: int,
) -> dict[str, Any]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": seed, "slots": SLOTS, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": [QUEUE_ID],
        },
        "scheduler": {
            "name": scheduler_id,
            "params": _scheduler_params(scheduler_id),
        },
        "arrival": _arrival_params(arrival_family),
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "disabled",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": True,
        },
    }


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, dict)
    return payload


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def test_matrix_is_exactly_five_schedulers_by_all_canonical_arrival_laws() -> None:
    assert len(SCHEDULERS) == 5
    assert len(ARRIVAL_FAMILIES) == 11
    assert len(MATRIX_CASES) == 55
    assert len(set(MATRIX_CASES)) == 55


@pytest.mark.parametrize(
    "scheduler_id,arrival_family",
    MATRIX_CASES,
    ids=[f"{scheduler}__{arrival}" for scheduler, arrival in MATRIX_CASES],
)
def test_patch5_scheduler_arrival_matrix_runs_and_replays_deterministically(
    scheduler_id: str,
    arrival_family: str,
    tmp_path: Path,
) -> None:
    case_index = MATRIX_CASES.index((scheduler_id, arrival_family))
    seed = 175_500 + case_index
    raw = _raw_config(scheduler_id, arrival_family, seed=seed)

    first = build_simulation(deepcopy(raw), output_dir=tmp_path / "first").run()
    replay = build_simulation(
        first.output_dir / "resolved_config.yaml",
        output_dir=tmp_path / "replay",
    ).run()

    assert first.actual_seed == replay.actual_seed == seed
    assert first.requested_seed == replay.requested_seed == seed
    assert first.slots_run == replay.slots_run == SLOTS
    assert set(first.static_artifacts) == EXPECTED_STATIC_ARTIFACT_KEYS
    assert set(replay.static_artifacts) == EXPECTED_STATIC_ARTIFACT_KEYS
    assert {path.name for path in first.output_dir.iterdir()} == EXPECTED_RUN_FILENAMES
    assert {path.name for path in replay.output_dir.iterdir()} == EXPECTED_RUN_FILENAMES

    # Replay from the canonical resolved configuration must reproduce every
    # CLI-facing artifact byte-for-byte, including generic slot telemetry.
    for filename in sorted(EXPECTED_RUN_FILENAMES):
        assert (first.output_dir / filename).read_bytes() == (
            replay.output_dir / filename
        ).read_bytes()

    resolved = load_config(first.output_dir / "resolved_config.yaml")
    manifest = _read_json(first.output_dir / "run_manifest.json")
    service_model = _read_json(first.output_dir / "service_model.json")
    arrival_support = _read_json(first.output_dir / "arrival_support.json")
    records = _read_jsonl(first.output_dir / "telemetry.jsonl")

    assert resolved.scheduler.name == scheduler_id
    assert resolved.arrival.family == arrival_family
    assert manifest["scheduler_name"] == scheduler_id
    assert manifest["service_family"] == SERVICE_FAMILIES[scheduler_id]
    assert service_model["service"]["family"] == SERVICE_FAMILIES[scheduler_id]
    assert arrival_support["family"] == arrival_family

    assert [record["slot"] for record in records] == list(range(SLOTS))
    assert {
        (
            record["schedule"]["scheduler_id"],
            record["schedule"]["optimizer_id"],
        )
        for record in records
    } == {(scheduler_id, OPTIMIZER_IDS[scheduler_id])}
    assert any(
        record["schedule"]["selected_queue_ids"] == [QUEUE_ID]
        for record in records
    )

    metrics = first.summary.to_dict()["metrics"]
    assert metrics["offered_packets"] >= 1
    assert metrics["admitted_packets"] >= 1
    assert metrics["dropped_packets"] == 0
    assert metrics["completed_packets"] >= 1
    assert metrics["schedule"]["scheduler_ids"] == {scheduler_id: SLOTS}
    assert metrics["schedule"]["optimizer_ids"] == {
        OPTIMIZER_IDS[scheduler_id]: SLOTS
    }
