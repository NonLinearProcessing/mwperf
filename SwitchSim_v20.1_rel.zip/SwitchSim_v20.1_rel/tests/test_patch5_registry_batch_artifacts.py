from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
from typing import Any

import pytest
import yaml

from voqsim.batch import (
    BATCH_MANIFEST_FILENAME,
    BATCH_SUMMARY_FILENAME,
    preflight_batch_configs,
    run_batch_dir,
)
from voqsim.cli import main
from voqsim.config import (
    CONFIG_SCHEMA_VERSION,
    resolve_config,
    resolved_config_to_dict,
)
from voqsim.errors import ValidationError
from voqsim.manifest import (
    build_service_model,
    hash_resolved_config,
    hash_service_model,
)
from voqsim.schedulers import (
    ConflictGraphMaxWeightScheduler,
    ResourcePackingMaxWeightScheduler,
    build_scheduler,
    canonical_scheduler_config,
    resolve_scheduler_spec,
    scheduler_capabilities,
    scheduler_class_for_name,
    scheduler_supports_service,
)


QUEUE_IDS = ("a", "b", "c")
EXPECTED_STATIC_ARTIFACTS = {
    "arrival_support.json",
    "flow_plan.json",
    "resolved_config.yaml",
    "run_manifest.json",
    "service_model.json",
}


def _conflict_params(
    *,
    priority: list[str] | None = None,
    max_search_states: int | None = None,
) -> dict[str, Any]:
    return {
        "constraint": {"conflicts": [["b", "a"], ["c", "b"]]},
        "priority": list(QUEUE_IDS) if priority is None else priority,
        "max_search_states": max_search_states,
    }


def _packing_params(
    *,
    priority: list[str] | None = None,
    max_search_states: int | None = None,
) -> dict[str, Any]:
    return {
        "constraint": {
            "resources": ["r-b", 2],
            "capacity": [3, 2],
            "demands": [
                {"queue_id": "a", "demand": [1, 1]},
                {"queue_id": "b", "demand": [2, 0]},
                {"queue_id": "c", "demand": [0, 1]},
            ],
        },
        "priority": list(QUEUE_IDS) if priority is None else priority,
        "max_search_states": max_search_states,
    }


def _raw_config(
    scheduler: str,
    params: dict[str, Any],
    *,
    queues: tuple[str, ...] = QUEUE_IDS,
    events: list[dict[str, Any]] | None = None,
    slots: int = 3,
) -> dict[str, Any]:
    if events is None:
        events = [
            {"slot": 0, "queue_id": queue_id, "count": 1}
            for queue_id in queues
        ]
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 175_510, "slots": slots, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": list(queues),
        },
        "scheduler": {"name": scheduler, "params": params},
        "arrival": {"family": "deterministic_trace", "events": events},
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "disabled",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": True,
        },
    }


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")


def _config_hash(config: Any) -> str:
    return hash_resolved_config(
        resolved_config_to_dict(config, actual_seed=config.run.seed)
    )


def _service_hash(config: Any) -> str:
    return hash_service_model(build_service_model(config))


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, dict)
    return payload


def test_patch5_registry_classes_capabilities_and_effective_params() -> None:
    conflict_supplied = {
        "constraint": {
            "conflicts": [["z", "a"], ["z", 3], ["b", "a"]]
        },
        "priority": ["z", "b", "a", 3],
        "max_search_states": 99,
    }
    conflict_expected = {
        "constraint": {
            "conflicts": [[3, "z"], ["a", "b"], ["a", "z"]]
        },
        "priority": ["z", "b", "a", 3],
        "max_search_states": 99,
    }
    packing_supplied = {
        "constraint": {
            "resources": ["gpu", 7],
            "capacity": [5, 2],
            "demands": [
                {"queue_id": "b", "demand": [4, 1]},
                {"queue_id": "a", "demand": [2, 0]},
            ],
        }
    }
    packing_expected = {
        "constraint": {
            "resources": [7, "gpu"],
            "capacity": [2, 5],
            "demands": [
                {"queue_id": "a", "demand": [0, 2]},
                {"queue_id": "b", "demand": [1, 4]},
            ],
        },
        "priority": None,
        "max_search_states": None,
    }

    conflict = build_scheduler("conflict_graph_max_weight", conflict_supplied)
    packing = build_scheduler("resource_packing_max_weight", packing_supplied)
    conflict_spec = resolve_scheduler_spec(
        "conflict_graph_max_weight", conflict_supplied
    )
    packing_spec = resolve_scheduler_spec(
        "resource_packing_max_weight", packing_supplied
    )

    assert isinstance(conflict, ConflictGraphMaxWeightScheduler)
    assert isinstance(packing, ResourcePackingMaxWeightScheduler)
    assert scheduler_class_for_name(
        "conflict_graph_max_weight"
    ) is ConflictGraphMaxWeightScheduler
    assert scheduler_class_for_name(
        "resource_packing_max_weight"
    ) is ResourcePackingMaxWeightScheduler
    assert conflict.optimizer_id == "mwis_branch_memo_exact"
    assert packing.optimizer_id == "binary_packing_memo_exact"
    assert conflict.params == conflict.effective_params == conflict_expected
    assert packing.params == packing.effective_params == packing_expected
    assert conflict_spec.params == conflict_expected
    assert packing_spec.params == packing_expected
    assert conflict_spec.service_family == "pairwise_conflicts"
    assert packing_spec.service_family == "resource_packing"
    assert scheduler_capabilities("conflict_graph_max_weight").to_dict() == {
        "input_kind": "queue_vector",
        "output_kind": "service_decision",
        "service_families": ["pairwise_conflicts"],
    }
    assert scheduler_capabilities("resource_packing_max_weight").to_dict() == {
        "input_kind": "queue_vector",
        "output_kind": "service_decision",
        "service_families": ["resource_packing"],
    }
    assert scheduler_supports_service(
        "conflict_graph_max_weight", "pairwise-conflicts"
    )
    assert scheduler_supports_service(
        "resource_packing_max_weight", "resource-packing"
    )
    assert canonical_scheduler_config(
        "conflict_graph_max_weight", conflict_supplied
    ) == {"name": "conflict_graph_max_weight", "params": conflict_expected}
    assert canonical_scheduler_config(
        "resource_packing_max_weight", packing_supplied
    ) == {"name": "resource_packing_max_weight", "params": packing_expected}


def test_pair_and_resource_reordering_resolve_to_identical_configs_and_hashes() -> None:
    conflict_first = _raw_config(
        "conflict_graph_max_weight", _conflict_params(max_search_states=100)
    )
    conflict_second = deepcopy(conflict_first)
    conflict_second["scheduler"]["params"]["constraint"]["conflicts"] = [
        ["b", "c"],
        ["a", "b"],
    ]

    packing_first = _raw_config(
        "resource_packing_max_weight", _packing_params(max_search_states=100)
    )
    packing_second = deepcopy(packing_first)
    packing_second["scheduler"]["params"]["constraint"] = {
        "resources": [2, "r-b"],
        "capacity": [2, 3],
        "demands": [
            {"queue_id": "c", "demand": [1, 0]},
            {"queue_id": "b", "demand": [0, 2]},
            {"queue_id": "a", "demand": [1, 1]},
        ],
    }

    for raw_first, raw_second in (
        (conflict_first, conflict_second),
        (packing_first, packing_second),
    ):
        first = resolve_config(raw_first)
        second = resolve_config(raw_second)
        assert resolved_config_to_dict(first) == resolved_config_to_dict(second)
        assert _config_hash(first) == _config_hash(second)
        assert build_service_model(first) == build_service_model(second)
        assert _service_hash(first) == _service_hash(second)


@pytest.mark.parametrize(
    ("scheduler", "params", "mutate_physical"),
    [
        (
            "conflict_graph_max_weight",
            _conflict_params(max_search_states=100),
            lambda raw: raw["scheduler"]["params"]["constraint"][
                "conflicts"
            ].append(["a", "c"]),
        ),
        (
            "resource_packing_max_weight",
            _packing_params(max_search_states=100),
            lambda raw: raw["scheduler"]["params"]["constraint"][
                "capacity"
            ].__setitem__(0, 4),
        ),
    ],
)
def test_optimizer_policy_is_excluded_but_physical_constraint_is_in_service_hash(
    scheduler: str,
    params: dict[str, Any],
    mutate_physical: Any,
) -> None:
    baseline_raw = _raw_config(scheduler, deepcopy(params))
    policy_raw = deepcopy(baseline_raw)
    policy_raw["scheduler"]["params"]["priority"].reverse()
    policy_raw["scheduler"]["params"]["max_search_states"] = 101
    physical_raw = deepcopy(baseline_raw)
    mutate_physical(physical_raw)

    baseline = resolve_config(baseline_raw)
    policy = resolve_config(policy_raw)
    physical = resolve_config(physical_raw)

    assert _config_hash(policy) != _config_hash(baseline)
    assert _service_hash(policy) == _service_hash(baseline)
    assert build_service_model(policy) == build_service_model(baseline)
    assert _service_hash(physical) != _service_hash(baseline)
    assert set(build_service_model(baseline)["service"]) == {
        "family",
        "constraint",
    }


def test_batch_preflight_rejects_live_unserviceable_packing_queue_without_outputs(
    tmp_path: Path,
) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"
    valid = _raw_config("conflict_graph_max_weight", _conflict_params())
    invalid = _raw_config(
        "resource_packing_max_weight",
        {
            "constraint": {
                "resources": ["r"],
                "capacity": [0],
                "demands": [
                    {"queue_id": "live", "demand": [0]},
                    {"queue_id": "blocked", "demand": [1]},
                ],
            },
            "priority": ["live", "blocked"],
            "max_search_states": None,
        },
        queues=("live", "blocked"),
        events=[{"slot": 0, "queue_id": "blocked", "count": 1}],
    )
    _write_yaml(batch_dir / "valid.yaml", valid)
    _write_yaml(batch_dir / "invalid.yaml", invalid)

    with pytest.raises(ValidationError, match="batch preflight failed") as caught:
        preflight_batch_configs(batch_dir, output_root)

    error_text = " ".join(caught.value.context["errors"])
    assert "invalid.yaml" in error_text
    assert "scheduler can never serve" in error_text
    assert "blocked" in error_text
    assert not output_root.exists()


def test_successful_patch5_batch_records_canonical_identity_and_artifacts(
    tmp_path: Path,
) -> None:
    batch_dir = tmp_path / "batch"
    output_root = tmp_path / "out"
    inputs = {
        "conflict": _raw_config(
            "conflict_graph_max_weight",
            _conflict_params(max_search_states=1_000),
        ),
        "packing": _raw_config(
            "resource_packing_max_weight",
            _packing_params(max_search_states=1_000),
        ),
    }
    for name, raw in inputs.items():
        _write_yaml(batch_dir / f"{name}.yaml", raw)

    result = run_batch_dir(batch_dir, output_root)

    assert result.total_configs == result.attempted_runs == result.successful_runs == 2
    assert result.failed_runs == 0
    batch_manifest = _read_json(output_root / BATCH_MANIFEST_FILENAME)
    assert [item["scheduler"] for item in batch_manifest["prepared_runs"]] == [
        "conflict_graph_max_weight",
        "resource_packing_max_weight",
    ]

    expectations = {
        "conflict": (
            "conflict_graph_max_weight",
            "pairwise_conflicts",
            "mwis_branch_memo_exact",
        ),
        "packing": (
            "resource_packing_max_weight",
            "resource_packing",
            "binary_packing_memo_exact",
        ),
    }
    for name, (scheduler_id, family, optimizer_id) in expectations.items():
        run_dir = output_root / "runs" / name
        names = {path.name for path in run_dir.iterdir()}
        assert EXPECTED_STATIC_ARTIFACTS <= names
        assert {"telemetry.jsonl", "run_summary.json"} <= names

        manifest = _read_json(run_dir / "run_manifest.json")
        service_model = _read_json(run_dir / "service_model.json")
        summary = _read_json(run_dir / "run_summary.json")
        records = [
            json.loads(line)
            for line in (run_dir / "telemetry.jsonl")
            .read_text(encoding="utf-8")
            .splitlines()
        ]
        assert manifest["scheduler_name"] == scheduler_id
        assert manifest["service_family"] == family
        assert manifest["scheduler_params"] == resolve_config(
            inputs[name]
        ).scheduler.params
        assert service_model["service"]["family"] == family
        assert set(service_model["service"]) == {"family", "constraint"}
        assert manifest["service_model_hash"] == hash_service_model(service_model)
        assert {record["schedule"]["scheduler_id"] for record in records} == {
            scheduler_id
        }
        assert {record["schedule"]["optimizer_id"] for record in records} == {
            optimizer_id
        }
        assert summary["metrics"]["schedule"]["scheduler_ids"] == {
            scheduler_id: 3
        }
        assert summary["metrics"]["schedule"]["optimizer_ids"] == {
            optimizer_id: 3
        }


def test_safety_limits_surface_as_explicit_cli_and_batch_errors(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    queue_ids = ("q0", "q1", "q2", "q3")
    conflict = _raw_config(
        "conflict_graph_max_weight",
        {
            "constraint": {
                "conflicts": [list(pair) for pair in (
                    ("q0", "q1"),
                    ("q0", "q2"),
                    ("q0", "q3"),
                    ("q1", "q2"),
                    ("q1", "q3"),
                    ("q2", "q3"),
                )]
            },
            "priority": list(queue_ids),
            "max_search_states": 1,
        },
        queues=queue_ids,
        slots=2,
    )
    config_path = tmp_path / "conflict-limit.yaml"
    single_output = tmp_path / "single-out"
    _write_yaml(config_path, conflict)

    assert main([str(config_path), "--output-dir", str(single_output), "--quiet"]) == 2
    single_error = capsys.readouterr().err
    assert "conflict_graph_max_weight exact search exceeded max_search_states" in single_error
    assert (single_output / "telemetry.jsonl").read_text(encoding="utf-8").count("\n") == 1
    assert not (single_output / "run_summary.json").exists()

    packing = _raw_config(
        "resource_packing_max_weight",
        {
            "constraint": {
                "resources": ["r"],
                "capacity": [2],
                "demands": [
                    {"queue_id": queue_id, "demand": [1]}
                    for queue_id in queue_ids
                ],
            },
            "priority": list(queue_ids),
            "max_search_states": 1,
        },
        queues=queue_ids,
        slots=2,
    )
    batch_dir = tmp_path / "limit-batch"
    batch_output = tmp_path / "batch-out"
    _write_yaml(batch_dir / "packing.yaml", packing)

    assert main(
        [
            "--batch-dir",
            str(batch_dir),
            "--output-root",
            str(batch_output),
            "--quiet",
        ]
    ) == 1
    batch_summary = _read_json(batch_output / BATCH_SUMMARY_FILENAME)
    assert batch_summary["failed_runs"] == 1
    assert batch_summary["successful_runs"] == 0
    assert "ScheduleError" in batch_summary["results"][0]["error"]
    assert "exceeded max_search_states" in batch_summary["results"][0]["error"]
    packing_output = batch_output / "runs" / "packing"
    assert (packing_output / "telemetry.jsonl").read_text(
        encoding="utf-8"
    ).count("\n") == 1
    assert not (packing_output / "run_summary.json").exists()
