from __future__ import annotations

from copy import deepcopy
from fractions import Fraction

import pytest

from voqsim.analysis import (
    ArrivalMarginal,
    analyze_pooled_target_block,
    empirical_error_from_pooled,
    independent_replication_uncertainty,
    pool_target_block,
)
from voqsim.errors import ValidationError
from voqsim.kernel import build_simulation
from voqsim.telemetry import CompactObservationReader

from test_v18_observation_integration import _config


def _run(config, path):
    result = build_simulation(config, output_dir=path).run()
    assert result.observation_path is not None
    return result.observation_path


def test_reader_exposes_target_identity_and_exact_blocks(tmp_path) -> None:
    path = _run(_config(observations=True), tmp_path / "unit")

    with CompactObservationReader(path) as reader:
        targets = tuple(reader.iter_targets())
        blocks = tuple(reader.iter_blocks())
        block_one_levels = tuple(reader.iter_levels(target_id="target_0", block_id=1))
        block_one_boundaries = tuple(
            reader.iter_boundaries(target_id="target_0", block_id=1)
        )
        block_one_totals = tuple(
            reader.iter_target_blocks(target_id="target_0", block_id=1)
        )

    assert [(target.target_id, target.queue_id, target.mass_kind) for target in targets] == [
        ("target_0", "q", "integer")
    ]
    assert [(block.block_id, block.start_slot, block.stop_slot) for block in blocks] == [
        (0, 2, 4),
        (1, 4, 6),
    ]
    assert {row.block_id for row in block_one_levels} == {1}
    assert {row.block_id for row in block_one_boundaries} == {1}
    assert [row.block_id for row in block_one_totals] == [1]


def test_streaming_pool_and_formula_layer_use_only_requested_prefix(tmp_path) -> None:
    first = _config(observations=True)
    second = deepcopy(first)
    second["run"]["seed"] = 18022  # type: ignore[index]
    paths = [_run(first, tmp_path / "a"), _run(second, tmp_path / "b")]
    readers = [CompactObservationReader(path) for path in paths]
    try:
        arrival = ArrivalMarginal.from_pmf({0: 1})
        report = analyze_pooled_target_block(
            readers,
            target_id="target_0",
            block_id=0,
            cutoffs=[0],
            arrival=arrival,
        )
    finally:
        for reader in readers:
            reader.close()

    pooled = report.pooled
    assert pooled.unit_count == 2
    assert pooled.exposure == pooled.decision_mass == 4
    assert pooled.prefix_exposure == {}
    assert pooled.backlog_mean == 1
    assert pooled.departure_mean == 1
    cutoff = report.cutoffs[0]
    assert cutoff.cutoff == 0
    assert cutoff.tau == 1
    assert cutoff.tail_service == 1
    assert cutoff.slack == 1
    assert cutoff.association == 0
    finite = report.finite_windows[0]
    assert finite.eta_1 == Fraction(-1, 2)
    assert finite.eta_2 == Fraction(-1, 2)
    assert report.innovations[0].status == "expectation_only"


def test_authoritative_decoder_output_can_be_accounted_without_inventing_decoder(tmp_path) -> None:
    path = _run(_config(observations=True), tmp_path / "unit")
    with CompactObservationReader(path) as reader:
        pooled = pool_target_block(
            [reader],
            target_id="target_0",
            block_id=1,
            cutoffs=[1],
        )
    arrival = ArrivalMarginal.from_pmf({0: 1})
    cutoff = pooled.cutoff(1, arrival)
    accounting = empirical_error_from_pooled(
        pooled,
        cutoff,
        arrival=arrival,
        fitted_prefix={0: Fraction(1, 2), 1: 0},
        fitted_tail_mass=Fraction(1, 2),
        fitted_mean=1,
    )

    assert accounting.fitted_tail_mass == Fraction(1, 2)
    assert accounting.fitted_mean == 1
    assert accounting.tail_association_term is not None
    assert accounting.total_error == (
        accounting.tail_association_term
        + accounting.prefix_balance_term
        + accounting.stationarity_term
    )
    assert accounting.status == "empirical_accounting_mismatch"


def test_raw_endpoint_drifts_remain_available_without_arrival_law(tmp_path) -> None:
    path = _run(_config(observations=True), tmp_path / "unit")
    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target_0",
            block_id=0,
            cutoffs=[0],
            arrival=None,
        )

    assert report.cutoffs[0].status == "arrival_law_unavailable"
    endpoint = report.finite_windows[0]
    assert endpoint.eta_1 == Fraction(-1, 2)
    assert endpoint.eta_2 == Fraction(-1, 2)
    assert endpoint.eta_k == Fraction(-1, 2)
    assert endpoint.expected_eta_1 is None
    assert endpoint.expected_eta_2 is None
    assert endpoint.z_from_endpoints is None
    assert endpoint.status == "arrival_law_unavailable"


@pytest.mark.parametrize(
    ("fitted_prefix", "tail", "mean", "message"),
    [
        ({2: 1}, 0, 2, "outside the decoded prefix"),
        ({0: Fraction(3, 4), 1: Fraction(1, 2)}, None, None, "cannot exceed one"),
        ({0: Fraction(1, 2)}, Fraction(1, 4), 1, "sum exactly to one"),
        ({0: Fraction(1, 2), 1: 0}, Fraction(1, 2), Fraction(1, 2), "inconsistent"),
    ],
)
def test_decoder_outputs_are_validated_before_empirical_accounting(
    tmp_path,
    fitted_prefix,
    tail,
    mean,
    message,
) -> None:
    path = _run(_config(observations=True), tmp_path / "unit")
    with CompactObservationReader(path) as reader:
        pooled = pool_target_block(
            [reader],
            target_id="target_0",
            block_id=1,
            cutoffs=[1],
        )
    arrival = ArrivalMarginal.from_pmf({0: 1})
    cutoff = pooled.cutoff(1, arrival)
    with pytest.raises(ValidationError, match=message):
        empirical_error_from_pooled(
            pooled,
            cutoff,
            arrival=arrival,
            fitted_prefix=fitted_prefix,
            fitted_tail_mass=tail,
            fitted_mean=mean,
        )


def test_pooling_rejects_different_buffer_science(tmp_path) -> None:
    nodrop = _config(observations=True)
    finite = deepcopy(nodrop)
    finite["switch"]["queue_capacity"] = 10  # type: ignore[index]
    paths = [_run(nodrop, tmp_path / "nodrop"), _run(finite, tmp_path / "finite")]
    readers = [CompactObservationReader(path) for path in paths]
    try:
        with pytest.raises(ValidationError, match="incompatible scientific conditions"):
            pool_target_block(
                readers,
                target_id="target_0",
                block_id=0,
                cutoffs=[0],
            )
    finally:
        for reader in readers:
            reader.close()


def test_pooling_rejects_duplicate_actual_seed_as_same_scientific_unit(tmp_path) -> None:
    paths = [
        _run(_config(observations=True), tmp_path / "first"),
        _run(_config(observations=True), tmp_path / "replay"),
    ]
    readers = [CompactObservationReader(path) for path in paths]
    try:
        with pytest.raises(ValidationError, match="duplicate independent scientific unit"):
            pool_target_block(
                readers,
                target_id="target_0",
                block_id=0,
                cutoffs=[0],
            )
    finally:
        for reader in readers:
            reader.close()


def test_uncertainty_uses_independent_units_and_reports_small_samples() -> None:
    one = independent_replication_uncertainty([Fraction(3, 2)])
    many = independent_replication_uncertainty([1, 2, 3])

    assert one.status == "insufficient_replication"
    assert one.standard_error is None
    assert many.status == "ok"
    assert many.replication_units == 3
    assert many.mean == 2.0
    assert many.standard_error == pytest.approx(1 / (3**0.5))
