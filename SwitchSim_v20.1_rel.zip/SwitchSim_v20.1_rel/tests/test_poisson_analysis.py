from __future__ import annotations

from decimal import Decimal, localcontext
from fractions import Fraction
import math

import pytest

from voqsim.analysis import (
    ArrivalMarginal,
    beta_k_evaluation,
    certified_target_arrival_marginal,
    cutoff_analysis,
    finite_window_accounting,
    isolated_server_analysis,
    normalize_level_masses,
    weighted_innovation,
)
from voqsim.queues import QueueCatalog
from voqsim.traffic import (
    CompiledArrivalSpec,
    IIDCountTableArrival,
    IIDIndependentPoissonArrival,
    IIDMixedPoissonArrival,
)
from voqsim.telemetry import (
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    TargetSlotObservation,
)
from voqsim.analysis import analyze_pooled_target_block


def test_finite_law_stop_loss_remains_exact() -> None:
    law = ArrivalMarginal.from_pmf({0: Fraction(3, 4), 2: Fraction(1, 4)})

    result = law.stop_loss(0, 1)

    assert result.status == "exact"
    assert result.value == Fraction(1, 4)
    assert result.error_bound == 0
    assert law.mean == Fraction(1, 2)
    assert law.variance == Fraction(3, 4)
    assert law.second_moment == 1


def test_poisson_moments_are_exact_and_stop_loss_is_error_bounded() -> None:
    law = ArrivalMarginal.poisson(Decimal("0.5"))

    result = law.stop_loss(0, 1)
    with localcontext() as context:
        context.prec = 100
        expected = Decimal("0.5") - 1 + (-Decimal("0.5")).exp()

    assert law.pmf is None
    assert law.mean == Fraction(1, 2)
    assert law.variance == Fraction(1, 2)
    assert law.second_moment == Fraction(3, 4)
    assert result.status == "ok"
    assert result.value is not None and result.error_bound is not None
    assert result.error_bound > 0
    assert abs(result.value - float(expected)) <= result.error_bound


def test_poisson_decimal_path_does_not_underflow_p0_above_binary64_range() -> None:
    law = ArrivalMarginal.poisson(Decimal("1000"))

    result = law.stop_loss(0, 1)

    assert result.status == "ok"
    assert result.value == pytest.approx(999.0)
    assert result.error_bound is not None and result.error_bound > 0
    assert result.value != 1000.0  # the p0 contribution was not silently discarded


def test_poisson_resource_guard_returns_unavailable_not_partial_tail() -> None:
    law = ArrivalMarginal.poisson(1)

    result = law.stop_loss(0, 1_000_001)

    assert result.status == "poisson_iteration_limit"
    assert result.value is None
    assert result.error_bound is None


def test_mixed_poisson_moments_and_stop_loss_use_finite_mixture() -> None:
    law = ArrivalMarginal.mixed_poisson(
        Decimal("0.25"),
        ((Decimal("0.75"), 0), (Decimal("0.25"), 4)),
    )

    result = law.stop_loss(0, 1)
    component = ArrivalMarginal.poisson(1).stop_loss(0, 1)

    assert law.mean == Fraction(1, 4)
    assert law.variance == Fraction(7, 16)
    assert law.second_moment == Fraction(1, 2)
    assert result.status == "ok"
    assert result.value is not None and component.value is not None
    assert result.value == pytest.approx(float(component.value) / 4)
    assert result.error_bound is not None and result.error_bound > 0


def test_compiled_poisson_and_mixed_poisson_are_certified_without_pmf_tables() -> None:
    catalog = QueueCatalog(("q", "idle"))
    poisson_model = IIDIndependentPoissonArrival(
        catalog,
        {
            "rates": {
                "default": Decimal("0"),
                "overrides": [{"queue_id": "q", "rate": Decimal("0.25")}],
            }
        },
    )
    mixed_model = IIDMixedPoissonArrival(
        catalog,
        {
            "rates": {
                "default": Decimal("0"),
                "overrides": [{"queue_id": "q", "rate": Decimal("0.25")}],
            },
            "modulation": {
                "scope": "shared",
                "states": [
                    {"id": "off", "probability": Decimal("0.75"), "multiplier": 0},
                    {"id": "on", "probability": Decimal("0.25"), "multiplier": 4},
                ],
            },
        },
    )

    poisson = certified_target_arrival_marginal(
        CompiledArrivalSpec(model=poisson_model, queue_catalog=catalog),
        "q",
    )
    mixed = certified_target_arrival_marginal(
        CompiledArrivalSpec(model=mixed_model, queue_catalog=catalog),
        "q",
    )

    assert poisson.status == mixed.status == "ok"
    assert poisson.marginal is not None and poisson.marginal.pmf is None
    assert poisson.marginal.mean == Fraction(1, 4)
    assert poisson.marginal.variance == Fraction(1, 4)
    assert mixed.marginal is not None and mixed.marginal.pmf is None
    assert mixed.marginal.mean == Fraction(1, 4)
    assert mixed.marginal.variance == Fraction(7, 16)


def test_compiled_iid_count_table_keeps_an_exact_finite_marginal() -> None:
    catalog = QueueCatalog(("q", "other"))
    model = IIDCountTableArrival(
        catalog,
        {
            "outcomes": [
                {"id": "zero", "probability": Decimal("0.75"), "counts": []},
                {
                    "id": "batch",
                    "probability": Decimal("0.25"),
                    "counts": [{"queue_id": "q", "count": 3}],
                },
            ]
        },
    )

    result = certified_target_arrival_marginal(
        CompiledArrivalSpec(model=model, queue_catalog=catalog),
        "q",
    )

    assert result.status == "ok"
    assert result.marginal is not None
    assert result.marginal.pmf == {0: Fraction(3, 4), 3: Fraction(1, 4)}
    assert result.marginal.mean == Fraction(3, 4)
    assert result.marginal.second_moment == Fraction(9, 4)


def test_beta_and_finite_window_propagate_poisson_error_certificate() -> None:
    masses = normalize_level_masses({0: 3, 1: 1}, {0: 0, 1: 1})
    law = ArrivalMarginal.poisson(Decimal("0.25"))

    beta = beta_k_evaluation(masses, 1, law)
    cutoff = cutoff_analysis(masses, 1, law.mean)
    finite = finite_window_accounting(
        masses,
        {0: 1},
        {0: 1},
        4,
        law,
        cutoff=cutoff,
    )

    assert beta.status == "ok"
    assert beta.value is not None
    assert beta.error_bound is not None and beta.error_bound > 0
    assert finite.beta_k == beta.value
    assert finite.beta_k_error_bound == beta.error_bound
    assert finite.numerical_status == "ok"
    assert finite.tail_slack_right_error_bound is not None
    assert finite.tail_slack_right_error_bound > 0


def test_generic_innovation_is_explicitly_unavailable_for_infinite_law() -> None:
    masses = normalize_level_masses({0: 1}, {0: 0})

    result = weighted_innovation(
        masses,
        {0: 1},
        {0: 1},
        1,
        ArrivalMarginal.poisson(Fraction(1, 4)),
        lambda value: value**3,
    )

    assert result.status == "generic_expectation_unavailable"
    assert result.innovation is None
    assert result.expected_next_mean is None
    assert result.numerical_error_bound is None


def test_isolated_reference_is_independent_and_contention_label_is_strictly_gated() -> None:
    law = ArrivalMarginal.from_pmf({0: Fraction(1, 2), 1: Fraction(1, 2)})

    certified = isolated_server_analysis(
        exposure=4,
        backlog_exposure=4,
        backlog_service=3,
        arrival=law,
        no_drop=True,
        stationary_interpretation=True,
        early_service_late_arrival=True,
    )
    finite_buffer = isolated_server_analysis(
        exposure=4,
        backlog_exposure=4,
        backlog_service=3,
        arrival=law,
        drops=0,
        no_drop=False,
        stationary_interpretation=True,
        early_service_late_arrival=True,
    )

    assert certified.isolated_mean == Fraction(1, 2)
    assert certified.raw_difference == Fraction(1, 2)
    assert certified.contention_excess == Fraction(1, 2)
    assert certified.identity_right_hand_side == Fraction(1, 2)
    assert certified.identity_residual == 0
    assert certified.difference_label == "contention_excess"
    assert certified.status == "ok"

    assert finite_buffer.isolated_mean == Fraction(1, 2)
    assert finite_buffer.raw_difference == Fraction(1, 2)
    assert finite_buffer.contention_excess is None
    assert finite_buffer.identity_residual is None
    assert finite_buffer.difference_label == "raw_difference"
    assert finite_buffer.status == "no_drop_required"


def test_streaming_isolated_reference_does_not_require_exact_gap(tmp_path) -> None:
    path = tmp_path / "base_only.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=4,
        targets=[ObservationTarget("target", "q", gap_mode="none")],
        metadata={
            "actual_seed": 7,
            "slot_convention": "pre_service_N; service; arrivals; post_arrival_N_prime",
            "scientific_config": {
                "arrival": {"family": "fixture"},
                "scheduler": {"name": "fixture", "tie_policy": "fixture"},
                "switch": {"kind": "fixture", "queue_capacity": "NoDrop"},
            },
        },
    )
    for slot in range(4):
        served = 0 if slot == 3 else 1
        offered = 0 if slot == 3 else 1
        recorder.record_slot(
            slot,
            [
                TargetSlotObservation(
                    target_id="target",
                    backlog_before=1,
                    backlog_after=1,
                    served=served,
                    offered=offered,
                    admitted=offered,
                    dropped=0,
                )
            ],
        )
    recorder.complete()
    recorder.close()

    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=ArrivalMarginal.from_pmf(
                {0: Fraction(1, 2), 1: Fraction(1, 2)}
            ),
            stationary_interpretation=True,
        )

    assert report.pooled.gap_mode == "none"
    assert report.stationary_tie.status == "gap_not_requested"
    assert report.isolated_server.status == "ok"
    assert report.isolated_server.contention_excess == Fraction(1, 2)
    assert report.isolated_server.identity_residual == 0
    assert report.isolated_server.empirical_arrival_mean == Fraction(3, 4)
    assert report.isolated_server.empirical_arrival_second_moment == Fraction(3, 4)
    assert report.isolated_server.empirical_arrival_variance == Fraction(3, 16)


def test_poisson_stop_loss_matches_direct_small_series() -> None:
    theta = 3.25
    law = ArrivalMarginal.poisson(Decimal("3.25"))
    result = law.stop_loss(0, 5)
    direct = math.fsum(
        (count - 5) * math.exp(-theta) * theta**count / math.factorial(count)
        for count in range(6, 80)
    )

    assert result.status == "ok"
    assert result.value is not None and result.error_bound is not None
    assert abs(result.value - direct) <= result.error_bound + 2e-15
