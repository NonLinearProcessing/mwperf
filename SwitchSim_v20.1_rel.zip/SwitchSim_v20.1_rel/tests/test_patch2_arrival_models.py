from __future__ import annotations

import copy

import numpy as np
import pytest

from voqsim.errors import ValidationError
from voqsim.queues import QueueCatalog, QueueSpec
from voqsim.traffic.count_arrivals import (
    DeterministicTraceArrival,
    IndependentMarkedRenewalArrival,
    IndependentPrivateMarkovRenewalArrival,
    PeriodicGlobalPhaseArrival,
    PeriodicSourceDelaysArrival,
    SharedJointRoundMarkovRenewalArrival,
    build_count_arrival_model,
)


@pytest.fixture
def catalog() -> QueueCatalog:
    # Deliberately nonlexical order: all vectors must follow catalog order.
    return QueueCatalog((QueueSpec("zeta"), QueueSpec(7), QueueSpec("alpha")))


def _counts(sample) -> tuple[int, ...]:
    return tuple(sample.offered_counts)


def _stream(model, slots: int, *, seed: int = 12345) -> tuple[tuple[int, ...], ...]:
    rng = np.random.default_rng(seed)
    return tuple(_counts(model.sample(slot, rng)) for slot in range(slots))


def test_deterministic_trace_aggregates_duplicates_and_factory_builds(catalog: QueueCatalog) -> None:
    params = {
        "events": [
            {"slot": 0, "queue_id": "zeta", "count": 2},
            {"slot": 0, "queue_id": "zeta", "count": 3},
            {"slot": 0, "queue_id": "alpha", "count": 1},
            {"slot": 3, "queue_id": 7, "count": 4},
        ]
    }
    model = build_count_arrival_model("deterministic_trace", catalog, params)

    assert isinstance(model, DeterministicTraceArrival)
    first = model.sample(0, np.random.default_rng(1))
    assert _counts(first) == (5, 0, 1)
    assert first.offered_counts.total_count == 6
    assert _counts(model.sample(1, np.random.default_rng(2))) == (0, 0, 0)
    assert _counts(model.sample(3, np.random.default_rng(3))) == (0, 4, 0)
    assert model.live_queue_ids() == ("zeta", 7, "alpha")
    assert model.to_dict()["events"] == [
        {"slot": 0, "queue_id": "zeta", "count": 5},
        {"slot": 0, "queue_id": "alpha", "count": 1},
        {"slot": 3, "queue_id": 7, "count": 4},
    ]


def test_periodic_global_phase_aggregates_sources_and_wraps(catalog: QueueCatalog) -> None:
    model = PeriodicGlobalPhaseArrival(
        catalog,
        {
            "period": 3,
            "phase": 2,
            "sources": [
                {
                    "id": "left",
                    "entries": [
                        {"offset": 2, "queue_id": "zeta", "count": 2},
                        {"offset": 2, "queue_id": "zeta", "count": 1},
                    ],
                },
                {
                    "id": "right",
                    "entries": [
                        {"offset": 2, "queue_id": "zeta", "count": 2},
                        {"offset": 1, "queue_id": 7, "count": 4},
                    ],
                },
            ],
        },
    )

    rng = np.random.default_rng(8)
    assert [_counts(model.sample(slot, rng)) for slot in range(7)] == [
        (0, 4, 0),
        (5, 0, 0),
        (0, 0, 0),
        (0, 4, 0),
        (5, 0, 0),
        (0, 0, 0),
        (0, 4, 0),
    ]


def test_periodic_source_delays_obey_one_sided_delay_and_aggregate(catalog: QueueCatalog) -> None:
    model = PeriodicSourceDelaysArrival(
        catalog,
        {
            "period": 3,
            "sources": [
                {
                    "id": "a",
                    "delay": 2,
                    "entries": [{"offset": 0, "queue_id": "zeta", "count": 2}],
                },
                {
                    "id": "b",
                    "delay": 1,
                    "entries": [{"offset": 1, "queue_id": "zeta", "count": 3}],
                },
            ],
        },
    )

    rng = np.random.default_rng(9)
    assert [_counts(model.sample(slot, rng)) for slot in range(9)] == [
        (0, 0, 0),
        (0, 0, 0),
        (5, 0, 0),
        (0, 0, 0),
        (0, 0, 0),
        (5, 0, 0),
        (0, 0, 0),
        (0, 0, 0),
        (5, 0, 0),
    ]


def test_periodic_models_keep_large_periods_sparse(catalog: QueueCatalog) -> None:
    period = 1_000_000_007
    global_model = PeriodicGlobalPhaseArrival(
        catalog,
        {
            "period": period,
            "phase": period - 1,
            "sources": [
                {
                    "id": "s",
                    "entries": [
                        {"offset": 0, "queue_id": "zeta", "count": 1},
                        {"offset": 17, "queue_id": 7, "count": 2},
                    ],
                }
            ],
        },
    )
    assert len(global_model.sources[0].buckets) == 2
    assert len(global_model._buckets) == 2
    rng = np.random.default_rng(4)
    assert _counts(global_model.sample(period - 1, rng)) == (1, 0, 0)
    assert _counts(global_model.sample(16, rng)) == (0, 2, 0)

    delayed_model = PeriodicSourceDelaysArrival(
        catalog,
        {
            "period": period,
            "sources": [
                {
                    "id": "far-future",
                    "delay": 1_000_000_000,
                    "entries": [{"offset": 0, "queue_id": "alpha", "count": 1}],
                }
            ],
        },
    )
    # Prefix sampling must not memoize one vector per silent slot.
    for slot in range(10_000):
        assert delayed_model.sample(slot, rng).offered_counts.total_count == 0
    assert not hasattr(delayed_model, "_sample_cache")
    assert len(delayed_model.sources[0].buckets) == 1


def test_empty_trace_and_periodic_sources_are_valid_zero_laws(catalog: QueueCatalog) -> None:
    rng = np.random.default_rng(5)
    assert _counts(DeterministicTraceArrival(catalog, {"events": []}).sample(42, rng)) == (0, 0, 0)
    assert _counts(
        PeriodicGlobalPhaseArrival(
            catalog,
            {"period": 10**9, "phase": 0, "sources": []},
        ).sample(42, rng)
    ) == (0, 0, 0)
    assert _counts(
        PeriodicSourceDelaysArrival(
            catalog,
            {"period": 10**9, "sources": []},
        ).sample(42, rng)
    ) == (0, 0, 0)


def test_independent_renewal_d_one_and_source_collisions(catalog: QueueCatalog) -> None:
    model = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "s0",
                    "interarrival": {"kind": "deterministic", "d": 1},
                    "destination_pmf": [{"queue_id": "zeta", "probability": 1.0}],
                },
                {
                    "id": "s1",
                    "joint_pmf": [{"d": 1, "queue_id": "zeta", "probability": 1.0}],
                },
            ]
        },
    )

    assert _stream(model, 5) == ((2, 0, 0),) * 5
    assert model.live_queue_ids() == ("zeta",)


def test_independent_renewal_first_epoch_is_d_minus_one_and_horizon_is_clipped(
    catalog: QueueCatalog,
) -> None:
    model = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "grid",
                    "interarrival": {"kind": "geometric_grid", "d_min": 3, "delta": 4, "p": 1.0},
                    "destination_pmf": [{"queue_id": 7, "probability": 1.0}],
                }
            ]
        },
    )

    # A two-slot horizon observes no event; extending it by one reveals T0=D-1=2.
    assert _stream(model, 2) == ((0, 0, 0), (0, 0, 0))
    model.reset()
    assert _stream(model, 3) == ((0, 0, 0), (0, 0, 0), (0, 1, 0))


def test_independent_renewal_reset_and_fixed_seed_replay(catalog: QueueCatalog) -> None:
    params = {
        "sources": [
            {
                "id": "factorized",
                "interarrival": {
                    "kind": "finite_pmf",
                    "outcomes": [
                        {"d": 1, "probability": 0.4},
                        {"d": 3, "probability": 0.6},
                    ],
                },
                "destination_pmf": [
                    {"queue_id": "zeta", "probability": 0.25},
                    {"queue_id": "alpha", "probability": 0.75},
                ],
            },
            {
                "id": "joint",
                "joint_pmf": [
                    {"d": 1, "queue_id": 7, "probability": 0.7},
                    {"d": 2, "queue_id": "alpha", "probability": 0.3},
                ],
            },
        ]
    }
    model = IndependentMarkedRenewalArrival(catalog, params)
    first = _stream(model, 40, seed=90210)
    model.reset(np.random.default_rng(777))  # reset validates but deliberately consumes no draws
    second = _stream(model, 40, seed=90210)
    assert second == first


def test_private_markov_renewal_uses_new_state_gap_and_d_one_boundary(catalog: QueueCatalog) -> None:
    model = IndependentPrivateMarkovRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "private",
                    "states": ["fast", "slow"],
                    "initial": {"state": "fast"},
                    "gaps": [{"state": "fast", "d": 1}, {"state": "slow", "d": 2}],
                    "transitions": [
                        {"state": "fast", "next_state": "slow", "probability": 1.0},
                        {"state": "slow", "next_state": "fast", "probability": 1.0},
                    ],
                    "destination_pmf": [{"queue_id": "alpha", "probability": 1.0}],
                }
            ]
        },
    )

    assert _stream(model, 8) == (
        (0, 0, 1),  # T0=-1+d(fast)=0
        (0, 0, 0),
        (0, 0, 1),  # transition selected slow, so the next gap is two
        (0, 0, 1),  # transition selected fast, so the next gap is one
        (0, 0, 0),
        (0, 0, 1),
        (0, 0, 1),
        (0, 0, 0),
    )


def test_private_markov_sources_are_independent_and_replay(catalog: QueueCatalog) -> None:
    source = {
        "states": ["a", "b"],
        "initial": {"distribution": {"a": 0.5, "b": 0.5}},
        "gaps": [{"state": "a", "d": 1}, {"state": "b", "d": 2}],
        "transitions": [
            {"state": "a", "next_state": "a", "probability": 0.6},
            {"state": "a", "next_state": "b", "probability": 0.4},
            {"state": "b", "next_state": "a", "probability": 0.3},
            {"state": "b", "next_state": "b", "probability": 0.7},
        ],
        "destination_pmf": [
            {"queue_id": "zeta", "probability": 0.5},
            {"queue_id": 7, "probability": 0.5},
        ],
    }
    params = {"sources": [{"id": "first", **source}, {"id": "second", **copy.deepcopy(source)}]}
    model = IndependentPrivateMarkovRenewalArrival(catalog, params)

    first = _stream(model, 50, seed=404)
    assert any(sum(slot) == 2 for slot in first)
    model.reset()
    assert _stream(model, 50, seed=404) == first


def test_shared_joint_round_stream_matches_finite_horizon_clock_semantics(
    catalog: QueueCatalog,
) -> None:
    model = SharedJointRoundMarkovRenewalArrival(
        catalog,
        {
            "sources": [{"id": "fast"}, {"id": "slow"}],
            "states": ["only"],
            "initial": {"state": "only"},
            "outcomes": [
                {
                    "state": "only",
                    "next_state": "only",
                    "probability": 1.0,
                    "emissions": [
                        {"source_id": "fast", "d": 1, "queue_id": "zeta"},
                        {"source_id": "slow", "d": 2, "queue_id": "zeta"},
                    ],
                }
            ],
        },
    )

    # The fast clock emits every slot; the slow clock collides on odd slots.
    assert _stream(model, 8) == tuple((1 + (slot % 2), 0, 0) for slot in range(8))


def test_shared_joint_round_reset_and_seeded_replay(catalog: QueueCatalog) -> None:
    params = {
        "sources": [{"id": "x"}, {"id": "y"}],
        "states": ["a", "b"],
        "initial": {"distribution": {"a": 0.4, "b": 0.6}},
        "outcomes": [
            {
                "state": "a",
                "next_state": "a",
                "probability": 0.3,
                "emissions": [
                    {"source_id": "x", "d": 1, "queue_id": "zeta"},
                    {"source_id": "y", "d": 3, "queue_id": 7},
                ],
            },
            {
                "state": "a",
                "next_state": "b",
                "probability": 0.7,
                "emissions": [
                    {"source_id": "x", "d": 2, "queue_id": "alpha"},
                    {"source_id": "y", "d": 1, "queue_id": "alpha"},
                ],
            },
            {
                "state": "b",
                "next_state": "a",
                "probability": 0.55,
                "emissions": [
                    {"source_id": "x", "d": 1, "queue_id": 7},
                    {"source_id": "y", "d": 2, "queue_id": "zeta"},
                ],
            },
            {
                "state": "b",
                "next_state": "b",
                "probability": 0.45,
                "emissions": [
                    {"source_id": "x", "d": 3, "queue_id": "zeta"},
                    {"source_id": "y", "d": 1, "queue_id": 7},
                ],
            },
        ],
    }
    model = SharedJointRoundMarkovRenewalArrival(catalog, params)
    first = _stream(model, 60, seed=99)
    model.reset()
    assert _stream(model, 60, seed=99) == first


def test_shared_joint_round_clips_unobservable_future_events(catalog: QueueCatalog) -> None:
    horizon = 10_000
    model = build_count_arrival_model(
        "shared_joint_round_markov_renewal",
        catalog,
        {
            "sources": [{"id": "fast"}, {"id": "slow"}],
            "states": ["only"],
            "initial": {"state": "only"},
            "outcomes": [
                {
                    "state": "only",
                    "next_state": "only",
                    "probability": 1.0,
                    "emissions": [
                        {"source_id": "fast", "d": 1, "queue_id": "zeta"},
                        {"source_id": "slow", "d": 1_000_000_000, "queue_id": "alpha"},
                    ],
                }
            ],
        },
        horizon=horizon,
    )
    assert isinstance(model, SharedJointRoundMarkovRenewalArrival)
    rng = np.random.default_rng(6)
    maximum_pending_buckets = 0
    for slot in range(horizon):
        assert _counts(model.sample(slot, rng)) == (1, 0, 0)
        maximum_pending_buckets = max(maximum_pending_buckets, len(model._pending))
    assert maximum_pending_buckets <= 1
    assert not model._pending
    with pytest.raises(ValidationError, match="outside the configured arrival horizon"):
        model.sample(horizon, rng)


def test_stateful_models_reject_skipped_or_repeated_slots(catalog: QueueCatalog) -> None:
    model = IndependentMarkedRenewalArrival(
        catalog,
        {
            "sources": [
                {
                    "id": "s",
                    "interarrival": {"kind": "deterministic", "d": 1},
                    "destination_pmf": [{"queue_id": "zeta", "probability": 1.0}],
                }
            ]
        },
    )
    rng = np.random.default_rng(1)
    with pytest.raises(ValidationError, match="sequential"):
        model.sample(1, rng)
    model.sample(0, rng)
    with pytest.raises(ValidationError, match="sequential"):
        model.sample(0, rng)


@pytest.mark.parametrize(
    ("source", "message"),
    [
        (
            {
                "id": "finite",
                "interarrival": {
                    "kind": "finite_pmf",
                    "outcomes": [
                        {"d": 2, "probability": 0.25},
                        {"d": 2, "probability": 0.75},
                    ],
                },
                "destination_pmf": [{"queue_id": "zeta", "probability": 1.0}],
            },
            "duplicate gap",
        ),
        (
            {
                "id": "destination",
                "interarrival": {"kind": "deterministic", "d": 1},
                "destination_pmf": [
                    {"queue_id": "zeta", "probability": 0.4},
                    {"queue_id": "zeta", "probability": 0.6},
                ],
            },
            "duplicate queue coordinate",
        ),
        (
            {
                "id": "joint",
                "joint_pmf": [
                    {"d": 3, "queue_id": 7, "probability": 0.2},
                    {"d": 3, "queue_id": 7, "probability": 0.8},
                ],
            },
            r"duplicate \(d, queue_id\) coordinate",
        ),
    ],
)
def test_independent_direct_constructor_rejects_duplicate_pmf_coordinates(
    catalog: QueueCatalog,
    source: dict,
    message: str,
) -> None:
    with pytest.raises(ValidationError, match=message):
        IndependentMarkedRenewalArrival(catalog, {"sources": [source]})


def test_private_direct_constructor_rejects_duplicate_destination_coordinate(
    catalog: QueueCatalog,
) -> None:
    with pytest.raises(ValidationError, match="duplicate queue coordinate"):
        IndependentPrivateMarkovRenewalArrival(
            catalog,
            {
                "sources": [
                    {
                        "id": "private",
                        "states": ["only"],
                        "initial": {"state": "only"},
                        "gaps": [{"state": "only", "d": 1}],
                        "transitions": [
                            {"state": "only", "next_state": "only", "probability": 1.0}
                        ],
                        "destination_pmf": [
                            {"queue_id": "alpha", "probability": 0.5},
                            {"queue_id": "alpha", "probability": 0.5},
                        ],
                    }
                ]
            },
        )


def test_shared_direct_constructor_rejects_duplicate_canonical_outcome(
    catalog: QueueCatalog,
) -> None:
    first = {
        "state": "only",
        "next_state": "only",
        "probability": 0.4,
        "emissions": [
            {"source_id": "a", "d": 1, "queue_id": "zeta"},
            {"source_id": "b", "d": 2, "queue_id": 7},
        ],
    }
    duplicate_in_different_emission_order = {
        "state": "only",
        "next_state": "only",
        "probability": 0.6,
        "emissions": list(reversed(copy.deepcopy(first["emissions"]))),
    }
    with pytest.raises(ValidationError, match="duplicate canonical outcome coordinate"):
        SharedJointRoundMarkovRenewalArrival(
            catalog,
            {
                "sources": [{"id": "a"}, {"id": "b"}],
                "states": ["only"],
                "initial": {"state": "only"},
                "outcomes": [first, duplicate_in_different_emission_order],
            },
        )


@pytest.mark.parametrize(
    ("model_type", "params", "message"),
    [
        (IndependentMarkedRenewalArrival, {"sources": []}, "sources must not be empty"),
        (IndependentPrivateMarkovRenewalArrival, {"sources": []}, "sources must not be empty"),
        (
            SharedJointRoundMarkovRenewalArrival,
            {"sources": [], "states": ["s"], "initial": {"state": "s"}, "outcomes": []},
            "sources must not be empty",
        ),
        (
            SharedJointRoundMarkovRenewalArrival,
            {"sources": [{"id": "x"}], "states": [], "initial": {"state": "s"}, "outcomes": []},
            "states must not be empty",
        ),
        (
            SharedJointRoundMarkovRenewalArrival,
            {"sources": [{"id": "x"}], "states": ["s"], "initial": {"state": "s"}, "outcomes": []},
            "outcomes must not be empty",
        ),
    ],
)
def test_stateful_direct_constructors_reject_empty_structural_rows(
    catalog: QueueCatalog,
    model_type,
    params: dict,
    message: str,
) -> None:
    with pytest.raises(ValidationError, match=message):
        model_type(catalog, params)


@pytest.mark.parametrize(
    "family",
    [
        "deterministic_trace",
        "independent_marked_renewal",
        "independent_private_markov_renewal",
        "shared_joint_round_markov_renewal",
        "periodic_global_phase",
        "periodic_source_delays",
    ],
)
def test_factory_rejects_unknown_family_without_aliasing_canonical_ids(
    catalog: QueueCatalog,
    family: str,
) -> None:
    # The parameter ensures every published family is represented in the test
    # suite; the actual rejection checks that aliases cannot enter manifests.
    assert family
    with pytest.raises(ValidationError, match="Unsupported"):
        build_count_arrival_model(f"{family}_alias", catalog, {})
