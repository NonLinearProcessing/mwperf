from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path

import pytest
import yaml

from voqsim.config import (
    CONFIG_SCHEMA_VERSION,
    dump_resolved_config,
    load_config,
    load_raw_config,
    resolve_config,
    resolved_config_to_dict,
)
from voqsim.errors import ConfigError, ValidationError
from voqsim.rng import MAX_SEED_VALUE
from voqsim.validation import (
    validate_actual_seed,
    validate_flow_plan_unique_voqs,
    validate_seed,
)


def _canonical_config(*, seed: int = 1234) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": seed, "slots": 100, "warmup_slots": 10},
        "switch": {
            "kind": "generalized",
            "queue_capacity": "NoDrop",
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "crossbar_random_greedy_maximal",
            "params": {
                "constraint": {
                    "inputs": [0, 1],
                    "outputs": [0, 1],
                    "edges": [
                        {"queue_id": "q0", "input": 0, "output": 1},
                        {"queue_id": "q1", "input": 1, "output": 0},
                    ],
                }
            },
        },
        "arrival": {
            "family": "iid_independent_poisson",
            "rates": {
                "default": Decimal("0.125"),
                "overrides": [{"queue_id": "q1", "rate": Decimal("2.5")}],
            },
        },
    }


@pytest.mark.parametrize("seed", [-1, 0, 1234, MAX_SEED_VALUE])
def test_validate_seed_accepts_minus_one_and_supported_fixed_values(seed: int) -> None:
    assert validate_seed(seed) == seed


@pytest.mark.parametrize("bad_seed", [-2, MAX_SEED_VALUE + 1, True, 1.5, "7"])
def test_validate_seed_rejects_invalid_values(bad_seed: object) -> None:
    with pytest.raises(ValidationError):
        validate_seed(bad_seed)  # type: ignore[arg-type]


@pytest.mark.parametrize("bad_actual_seed", [-1, -2, True, 1.5, "7"])
def test_validate_actual_seed_rejects_invalid_values(bad_actual_seed: object) -> None:
    with pytest.raises(ValidationError):
        validate_actual_seed(bad_actual_seed)  # type: ignore[arg-type]


def test_load_raw_and_resolved_config_support_yaml_and_json(tmp_path: Path) -> None:
    canonical = _canonical_config()
    serializable = json.loads(json.dumps(canonical, default=float))
    yaml_path = tmp_path / "config.yaml"
    json_path = tmp_path / "config.json"
    yaml_path.write_text(yaml.safe_dump(serializable, sort_keys=False), encoding="utf-8")
    json_path.write_text(json.dumps(serializable), encoding="utf-8")

    assert load_raw_config(yaml_path)["run"]["seed"] == 1234
    yaml_loaded = load_config(yaml_path)
    json_loaded = load_config(json_path)
    assert yaml_loaded == json_loaded
    assert yaml_loaded.switch.capacity is None
    assert yaml_loaded.arrival.params["rates"]["default"] == Decimal("0.125")


def test_dump_resolved_config_preserves_exact_decimals_and_seed(tmp_path: Path) -> None:
    config = resolve_config(_canonical_config(seed=-1))

    for suffix in (".json", ".yaml"):
        path = dump_resolved_config(config, actual_seed=987654321, out_path=tmp_path / f"resolved{suffix}")
        loaded = load_config(path)
        assert loaded == config.with_actual_seed(987654321)
        assert loaded.arrival.params["rates"]["default"] == Decimal("0.125")


def test_resolved_config_to_dict_switches_seed_representation() -> None:
    config = resolve_config(_canonical_config())

    unresolved = resolved_config_to_dict(config)
    resolved = resolved_config_to_dict(config, actual_seed=77)

    assert unresolved["run"]["seed"] == 1234
    assert "actual_seed" not in unresolved["run"]
    assert resolved["run"]["requested_seed"] == 1234
    assert resolved["run"]["actual_seed"] == 77


def test_validate_flow_plan_unique_voqs() -> None:
    validate_flow_plan_unique_voqs(
        [
            {"flow_id": 0, "src_port": 0, "dst_port": 1},
            {"flow_id": 1, "src_port": 1, "dst_port": 0},
        ]
    )

    with pytest.raises(ValidationError):
        validate_flow_plan_unique_voqs(
            [
                {"flow_id": 0, "src_port": 0, "dst_port": 1},
                {"flow_id": 1, "src_port": 0, "dst_port": 1},
            ]
        )


def test_config_schema_version_must_be_current() -> None:
    raw = _canonical_config()
    raw["schema_version"] = "3.1.0"
    with pytest.raises(ConfigError, match="migration"):
        resolve_config(raw)


def test_schema4_rejects_legacy_defaulting_and_aliases() -> None:
    raw = _canonical_config()
    del raw["switch"]["kind"]  # type: ignore[index]
    with pytest.raises(ConfigError):
        resolve_config(raw)

    raw = _canonical_config()
    raw["scheduler"]["name"] = "random_maximal"  # type: ignore[index]
    with pytest.raises(ConfigError) as caught:
        resolve_config(raw)
    assert caught.value.context["replacement"] == "crossbar_random_greedy_maximal"
