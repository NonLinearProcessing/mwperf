"""Registry and common native-scheduler boundary tests."""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np
import pytest

from voqsim.errors import ConfigError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers import (
    QueueSchedulerBase,
    QueueSchedulerDomain,
    SchedulerCapabilities,
    available_schedulers,
    build_scheduler,
    build_scheduler_for_domain,
    is_scheduler_registered,
    register_scheduler,
    unregister_scheduler,
)
from voqsim.types import JSONValue


class _EchoScheduler(QueueSchedulerBase):
    algorithm_id = "test_echo"

    def __init__(self, params: Mapping[str, JSONValue] | None = None) -> None:
        super().__init__(params=params)
        self._params = dict(self.params)

    @property
    def name(self) -> str:
        return "echo_plugin"

    def select_service(self, q_len, slot: int, rng) -> ServiceDecision:
        self.validate_queue_select_inputs(q_len, slot, rng)
        return ServiceDecision.empty()


def test_scheduler_registry_exposes_final_v4_names() -> None:
    assert available_schedulers() == (
        "conflict_graph_max_weight",
        "crossbar_islip",
        "crossbar_max_weight",
        "crossbar_random_grant_accept",
        "crossbar_random_greedy_maximal",
        "interval_max_weight",
        "node_exclusive_max_weight",
        "resource_packing_max_weight",
    )
    assert is_scheduler_registered("Crossbar-Random-Greedy-Maximal")
    scheduler = build_scheduler("crossbar random greedy maximal", params={})
    assert scheduler.name == "crossbar_random_greedy_maximal"
    assert scheduler.algorithm_id == "random_permutation_greedy_maximal"


def test_register_scheduler_supports_native_self_contained_plugins() -> None:
    register_scheduler(
        "echo_plugin",
        _EchoScheduler,
        capabilities=SchedulerCapabilities.queue_vector(("unconstrained",)),
        replace=True,
    )
    try:
        scheduler = build_scheduler_for_domain(
            "echo_plugin",
            {"note": "future"},
            QueueSchedulerDomain(QueueCatalog(("q",)), service_family="unconstrained"),
        )
        assert isinstance(scheduler, _EchoScheduler)
        assert scheduler.algorithm_id == "test_echo"
        assert dict(scheduler.params) == {"note": "future"}
        decision = scheduler.select_service(
            np.array([1], dtype=np.int64),
            slot=0,
            rng=np.random.default_rng(1),
        )
        assert decision == ServiceDecision.empty()
    finally:
        unregister_scheduler("echo_plugin")


@pytest.mark.parametrize(
    "name",
    [
        "random_maximal",
        "round_robin",
        "roundrobin",
        "islip_rga",
        "islip_canonical",
        "canonical_islip",
        "islip",
        "does_not_exist",
    ],
)
def test_build_scheduler_rejects_noncanonical_or_unknown_names(name: str) -> None:
    with pytest.raises(ConfigError):
        build_scheduler(name)


def test_registration_without_explicit_capabilities_is_rejected() -> None:
    with pytest.raises(ValidationError, match="explicit native capabilities"):
        register_scheduler("echo_plugin", _EchoScheduler, replace=True)
