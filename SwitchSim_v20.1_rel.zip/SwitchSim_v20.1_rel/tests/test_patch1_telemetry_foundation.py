from __future__ import annotations

import json
from dataclasses import replace

import numpy as np
import pytest

from voqsim.errors import ValidationError
from voqsim.events import ArrivalAttempt
from voqsim.packet import Packet
from voqsim.queues import QueueBank, QueueCatalog, QueueSpec, ServiceDecision
from voqsim.sink import CompletionSink
from voqsim.stats import GenericRunStats, OnlineDiscreteTracker
from voqsim.telemetry import GenericSlotTraceBuilder, JsonlWriter
from voqsim.traffic.arrivals import ArrivalSample
from voqsim.traffic.counts import ArrivalCountVector


def _offered_packet(packet_id: int, queue_id: str, slot: int = 0) -> ArrivalAttempt:
    return ArrivalAttempt.from_packet(
        Packet.for_queue(
            packet_id=packet_id,
            flow_id=packet_id,
            queue_id=queue_id,
            generation_slot=slot,
        )
    )


def test_generic_record_uses_flat_catalog_coordinates_and_universal_schedule_metrics() -> None:
    # The legacy endpoints are deliberately identical.  Telemetry must retain
    # stable queue labels rather than accidentally merging parallel links.
    catalog = QueueCatalog(
        (
            QueueSpec("parallel-a", legacy_voq=(0, 1)),
            QueueSpec("parallel-b", legacy_voq=(0, 1)),
        )
    )
    bank = QueueBank(catalog, queue_capacity=4)
    attempts = (_offered_packet(0, "parallel-a"), _offered_packet(1, "parallel-b"))

    q_before_0 = bank.queue_lengths()
    admissions = bank.enqueue_or_drop(attempts, slot=0)
    q_after_0 = bank.queue_lengths()
    arrival_record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test_generalized",
        )
        .set_q_before(q_before_0)
        .set_service_decision(ServiceDecision.empty())
        .set_offered_attempts(attempts)
        .set_admissions(admissions)
        .set_q_after(q_after_0)
        .finalize()
    )

    q_before_1 = bank.queue_lengths()
    # Deliberately provide reverse catalog order; the runtime resolves it once
    # and telemetry seals the binary decision in canonical catalog order.
    decision = ServiceDecision(("parallel-b", "parallel-a"))
    departures = bank.service(decision, slot=1)
    completions = CompletionSink().accept_departures(departures, slot=1)
    assert tuple(event.queue_id for event in completions) == ("parallel-a", "parallel-b")
    q_after_1 = bank.queue_lengths()
    service_record = (
        GenericSlotTraceBuilder(
            slot=1,
            catalog=catalog,
            algorithm_id="test_exact",
            scheduler_id="test_generalized",
            optimizer_id="test_exact",
        )
        .set_q_before(q_before_1)
        .set_service_decision(decision)
        .add_departures(departures)
        .add_completions(completions)
        .set_q_after(q_after_1)
        .finalize()
    )

    payload = service_record.to_dict()
    assert payload["q_before"] == {
        "mode": "sparse_nonzero",
        "representation": "queue_vector",
        "queue_order": "service_model.queues[index]",
        "values": [["parallel-a", 1], ["parallel-b", 1]],
    }
    assert payload["schedule"]["selected_queue_ids"] == ["parallel-a", "parallel-b"]
    assert payload["schedule"]["algorithm_id"] == "test_exact"
    assert payload["schedule"]["optimizer_id"] == "test_exact"
    assert payload["schedule_metrics"] == {
        "algorithm_id": "test_exact",
        "feasible": True,
        "optimizer_id": "test_exact",
        "primary_maxweight_objective": 2,
        "scheduler_id": "test_generalized",
        "selected_count": 2,
        "served_count": 2,
    }
    assert service_record.q_after["values"] == []
    with pytest.raises(ValidationError, match="optimizer_id must equal algorithm_id"):
        GenericSlotTraceBuilder(
            slot=2,
            catalog=catalog,
            algorithm_id="test_exact",
            optimizer_id="different_exact_solver",
        )

    stats = GenericRunStats.from_catalog(catalog, queue_capacity=4)
    stats.update(arrival_record, q_before_vector=q_before_0, q_after_vector=q_after_0)
    stats.update(service_record, q_before_vector=q_before_1, q_after_vector=q_after_1)
    metrics = stats.finalize().to_dict()["metrics"]
    assert metrics["mean_selected_queue_count"] == 1.0
    assert metrics["mean_served_packet_count"] == 1.0
    assert metrics["mean_primary_maxweight_objective"] == 1.0
    assert metrics["schedule"]["algorithm_ids"] == {
        "test_algorithm": 1,
        "test_exact": 1,
    }
    assert metrics["schedule"]["optimizer_ids"] == {"test_exact": 1}
    assert [entry["queue_id"] for entry in metrics["per_queue"]] == ["parallel-a", "parallel-b"]
    assert all(entry["completed_packets"] == 1 for entry in metrics["per_queue"])


def test_generic_jsonl_writer_handles_record_and_packet_event_suppression(tmp_path) -> None:
    catalog = QueueCatalog(("q0", "q1"))
    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            queue_snapshot_mode="dense",
            scheduler_id="test",
        )
        .set_q_before(np.zeros(2, dtype=np.int64))
        .set_service_decision(ServiceDecision.empty())
        .set_q_after(np.zeros(2, dtype=np.int64))
        .finalize()
    )
    target = tmp_path / "generic.jsonl"
    with JsonlWriter(target, include_packet_events=False) as writer:
        writer.write_slot(record)

    payload = json.loads(target.read_text(encoding="utf-8"))
    assert payload["schema_version"] == "3.0.0"
    assert payload["q_before"]["values"] == [0, 0]
    assert payload["schedule"]["algorithm_id"] == "test_algorithm"
    assert "optimizer_id" not in payload["schedule"]
    assert payload["schedule_metrics"]["primary_maxweight_objective"] == 0
    assert "optimizer_id" not in payload["schedule_metrics"]
    for field_name in ("departures", "completions", "offered_attempts", "admissions"):
        assert field_name not in payload

    with pytest.raises(ValidationError, match="unsupported generic telemetry schema version"):
        replace(record, schema_version="2.0.0")


def test_generic_arrival_telemetry_preserves_same_queue_multiplicity() -> None:
    catalog = QueueCatalog(("burst",))
    bank = QueueBank(catalog, queue_capacity=2)
    attempts = tuple(_offered_packet(packet_id, "burst") for packet_id in range(3))
    q_before = bank.queue_lengths()
    admissions = bank.enqueue_or_drop(attempts, slot=0)
    q_after = bank.queue_lengths()

    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(q_before)
        .set_service_decision(ServiceDecision.empty())
        .set_offered_attempts(attempts)
        .set_admissions(admissions)
        .set_q_after(q_after)
        .finalize()
    )
    payload = record.to_dict()

    assert payload["arrivals"] == {
        "format": "queue_counts",
        "offered": [{"queue_id": "burst", "count": 3}],
        "admitted": [{"queue_id": "burst", "count": 2}],
        "dropped": [{"queue_id": "burst", "count": 1}],
    }
    assert payload["slot_metrics"]["offered_count"] == 3
    assert payload["slot_metrics"]["admitted_count"] == 2
    assert payload["slot_metrics"]["dropped_count"] == 1

    stats = GenericRunStats.from_catalog(catalog, queue_capacity=2)
    stats.update(record, q_before_vector=q_before, q_after_vector=q_after)
    metrics = stats.metrics_dict()
    assert metrics["offered_packets"] == 3
    assert metrics["admitted_packets"] == 2
    assert metrics["dropped_packets"] == 1
    assert metrics["per_queue"][0]["offered_packets"] == 3


def test_generic_arrival_outcome_identity_is_preserved_in_compact_statistics() -> None:
    catalog = QueueCatalog(("q",))
    record = (
        GenericSlotTraceBuilder(
            slot=0,
            catalog=catalog,
            algorithm_id="test_algorithm",
            scheduler_id="test",
        )
        .set_q_before(np.zeros(1, dtype=np.int64))
        .set_service_decision(ServiceDecision.empty())
        .set_arrival_sample(
            ArrivalSample(
                slot=0,
                offered_counts=ArrivalCountVector((0,)),
                arrival_outcome_id="idle",
            )
        )
        .set_q_after(np.zeros(1, dtype=np.int64))
        .finalize()
    )

    payload = record.to_dict(include_packet_events=False)
    assert payload["arrival_outcome_id"] == "idle"
    assert "offered_mask_id" not in payload

    stats = GenericRunStats.from_catalog(catalog, family="iid_count_table")
    stats.update(record)
    assert stats.metrics_dict()["arrival"]["outcome_counts"] == [
        {"arrival_outcome_id": "idle", "count": 1, "rate": 1.0}
    ]


def test_generic_primary_objective_tracker_has_fixed_memory() -> None:
    tracker = OnlineDiscreteTracker()
    for value in range(10_000):
        tracker.update(value)

    assert tracker.count == 10_000
    assert tracker.minimum == 0
    assert tracker.maximum == 9_999
    assert tracker.mean_or_none == 4_999.5
    assert not hasattr(tracker, "_counter")
