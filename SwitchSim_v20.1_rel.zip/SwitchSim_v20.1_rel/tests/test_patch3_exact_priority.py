from __future__ import annotations

import itertools
import random
from collections.abc import Iterable, Sequence

import numpy as np
import pytest

from voqsim.errors import ValidationError
from voqsim.queues import QueueCatalog
from voqsim.schedulers.exact_priority import canonical_priority, exact_lex_weights


Schedule = tuple[int, ...]


def _primary_objective(schedule: Schedule, q_len: Sequence[int]) -> int:
    return sum(bit * q_len[index] for index, bit in enumerate(schedule))


def _composite_objective(schedule: Schedule, weights: Sequence[int]) -> int:
    return sum(bit * weights[index] for index, bit in enumerate(schedule))


def _eligible(schedule: Schedule, q_len: Sequence[int]) -> bool:
    return all(not bit or q_len[index] > 0 for index, bit in enumerate(schedule))


def _enumeration_reference(
    feasible: Iterable[Schedule],
    q_len: Sequence[int],
    priority_indices: Sequence[int],
) -> Schedule:
    eligible = [schedule for schedule in feasible if _eligible(schedule, q_len)]
    return max(
        eligible,
        key=lambda schedule: (
            _primary_objective(schedule, q_len),
            tuple(schedule[index] for index in priority_indices),
        ),
    )


def _bit_fixing_reference(
    feasible: Iterable[Schedule],
    q_len: Sequence[int],
    priority_indices: Sequence[int],
) -> Schedule:
    candidates = [schedule for schedule in feasible if _eligible(schedule, q_len)]
    optimum = max(_primary_objective(schedule, q_len) for schedule in candidates)
    candidates = [schedule for schedule in candidates if _primary_objective(schedule, q_len) == optimum]
    for queue_index in priority_indices:
        with_one = [schedule for schedule in candidates if schedule[queue_index] == 1]
        if with_one:
            candidates = with_one
        else:
            candidates = [schedule for schedule in candidates if schedule[queue_index] == 0]
    assert len(candidates) == 1
    return candidates[0]


def _one_solve_selection(feasible: Iterable[Schedule], q_len: Sequence[int], weights: Sequence[int]) -> Schedule:
    eligible = [schedule for schedule in feasible if _eligible(schedule, q_len)]
    objective_by_schedule = {
        schedule: _composite_objective(schedule, weights)
        for schedule in eligible
    }
    best_value = max(objective_by_schedule.values())
    winners = [schedule for schedule, value in objective_by_schedule.items() if value == best_value]
    assert len(winners) == 1
    return winners[0]


def test_canonical_priority_defaults_to_catalog_order_and_preserves_labels() -> None:
    catalog = QueueCatalog(("z", 7, "a"))
    assert canonical_priority(catalog) == ("z", 7, "a")
    assert canonical_priority(catalog, ("a", np.int64(7), "z")) == ("a", 7, "z")


@pytest.mark.parametrize(
    ("priority", "message"),
    [
        (("a", "a", "c"), "duplicate"),
        (("a", "b"), "full permutation"),
        (("a", "b", "outside"), "outside the catalog"),
        ("abc", "must be an iterable"),
        ({"a": 0, "b": 1, "c": 2}, "must be an iterable"),
        (("a", "b", True), "outside the catalog"),
    ],
)
def test_canonical_priority_rejects_every_non_permutation(priority, message: str) -> None:
    with pytest.raises(ValidationError, match=message):
        canonical_priority(QueueCatalog(("a", "b", "c")), priority)


def test_exact_weights_follow_declared_priority_but_remain_in_catalog_order() -> None:
    catalog = QueueCatalog(("q0", "q1", "q2", "q3"))
    # B=16; priority bonuses are q2:8, q0:4, q3:2, q1:1.
    assert exact_lex_weights((3, 0, 4, 1), catalog, ("q2", "q0", "q3", "q1")) == (
        52,
        1,
        72,
        18,
    )


def test_empty_queues_still_receive_exact_secondary_weights() -> None:
    catalog = QueueCatalog((0, 1, 2))
    assert exact_lex_weights((0, 0, 0), catalog, (2, 0, 1)) == (2, 1, 4)


def test_exact_weights_are_arbitrary_precision_python_integers() -> None:
    catalog = QueueCatalog(("first", "second", "third"))
    huge = (1 << 200) + (1 << 79) + 3
    weights = exact_lex_weights((huge, huge + 1, 0), catalog, ("third", "first", "second"))
    assert all(type(weight) is int for weight in weights)
    assert weights == (
        8 * huge + 2,
        8 * (huge + 1) + 1,
        4,
    )
    # These occupancies and their composite weights cannot be represented
    # exactly by binary64; the helper never converts through floating point.
    assert float(huge) == float(huge + 1)
    assert weights[1] > weights[0]


@pytest.mark.parametrize(
    "q_len",
    [
        (1, 2),
        (1, 2, 3, 4),
        (1, -1, 0),
        (1, 2.0, 3),
        (1, True, 3),
        np.ones((1, 3), dtype=np.int64),
        {"a": 1, "b": 2, "c": 3},
    ],
)
def test_exact_weights_reject_invalid_queue_vectors(q_len) -> None:
    with pytest.raises(ValidationError):
        exact_lex_weights(q_len, QueueCatalog(("a", "b", "c")))


def test_one_solve_equals_enumeration_and_bit_fixing_exhaustively() -> None:
    """Check every zero-containing feasible family through three queues.

    A constraint family always admits the empty schedule.  For each catalog
    size this test visits every possible subset of the other schedules, every
    queue vector over ``{0,1,2}``, and every queue-priority permutation.
    """

    for n_queues in range(1, 4):
        catalog = QueueCatalog(tuple(f"q{index}" for index in range(n_queues)))
        zero = (0,) * n_queues
        nonzero_schedules = [
            schedule
            for schedule in itertools.product((0, 1), repeat=n_queues)
            if schedule != zero
        ]
        feasible_families = [
            (zero,) + tuple(
                schedule
                for index, schedule in enumerate(nonzero_schedules)
                if family_bits & (1 << index)
            )
            for family_bits in range(1 << len(nonzero_schedules))
        ]
        for q_len in itertools.product(range(3), repeat=n_queues):
            for priority_indices in itertools.permutations(range(n_queues)):
                priority = tuple(catalog.queue_id_at(index) for index in priority_indices)
                weights = exact_lex_weights(q_len, catalog, priority)
                for feasible in feasible_families:
                    expected = _enumeration_reference(feasible, q_len, priority_indices)
                    assert _one_solve_selection(feasible, q_len, weights) == expected
                    assert _bit_fixing_reference(feasible, q_len, priority_indices) == expected


def test_one_solve_equals_both_references_on_many_four_queue_instances() -> None:
    rng = random.Random(17203)
    n_queues = 4
    catalog = QueueCatalog(tuple(f"q{index}" for index in range(n_queues)))
    universe = tuple(itertools.product((0, 1), repeat=n_queues))
    for _case in range(600):
        feasible = tuple(
            schedule
            for schedule in universe
            if schedule == (0, 0, 0, 0) or rng.getrandbits(1)
        )
        q_len = tuple(rng.randrange(5) for _ in range(n_queues))
        priority_indices = list(range(n_queues))
        rng.shuffle(priority_indices)
        priority = tuple(catalog.queue_id_at(index) for index in priority_indices)
        weights = exact_lex_weights(q_len, catalog, priority)
        expected = _enumeration_reference(feasible, q_len, priority_indices)
        assert _one_solve_selection(feasible, q_len, weights) == expected
        assert _bit_fixing_reference(feasible, q_len, priority_indices) == expected


def test_nonuniform_lengths_select_maxweight_not_maximum_cardinality() -> None:
    catalog = QueueCatalog(("heavy", "light-a", "light-b"))
    feasible = ((0, 0, 0), (1, 0, 0), (0, 1, 1))
    q_len = (100, 2, 2)
    priority = ("light-a", "light-b", "heavy")
    weights = exact_lex_weights(q_len, catalog, priority)
    assert _one_solve_selection(feasible, q_len, weights) == (1, 0, 0)


def test_secondary_bits_cannot_overturn_one_unit_of_primary_weight() -> None:
    catalog = QueueCatalog(("q0", "q1", "q2", "q3", "q4"))
    q_len = (1, 0, 0, 0, 0)
    priority = ("q1", "q2", "q3", "q4", "q0")
    weights = exact_lex_weights(q_len, catalog, priority)
    primary_winner = (1, 0, 0, 0, 0)
    every_preferred_zero_queue = (0, 1, 1, 1, 1)
    assert _composite_objective(primary_winner, weights) > _composite_objective(
        every_preferred_zero_queue,
        weights,
    )
