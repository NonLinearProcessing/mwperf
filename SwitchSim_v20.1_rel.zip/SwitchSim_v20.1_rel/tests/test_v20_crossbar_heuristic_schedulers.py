from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pytest

from voqsim.errors import ConfigError, ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.rng import build_scheduler_rng_for_slot
from voqsim.schedulers import (
    CrossbarISlipScheduler,
    CrossbarRandomGrantAcceptScheduler,
    CrossbarRandomGreedyMaximalScheduler,
    QueueSchedulerDomain,
    available_schedulers,
    build_scheduler,
    build_scheduler_for_domain,
    resolve_scheduler_spec,
)


FINAL_SCHEDULERS = (
    "conflict_graph_max_weight",
    "crossbar_islip",
    "crossbar_max_weight",
    "crossbar_random_grant_accept",
    "crossbar_random_greedy_maximal",
    "interval_max_weight",
    "node_exclusive_max_weight",
    "resource_packing_max_weight",
)


def _rectangular_constraint() -> dict[str, object]:
    # Deliberately not in operational input/output order. The canonical
    # compiler must make queue-ID storage order irrelevant to arbitration.
    return {
        "inputs": ["i1", "i0"],
        "outputs": ["o2", "o0", "o1"],
        "edges": [
            {"queue_id": "z", "input": "i1", "output": "o2"},
            {"queue_id": "a", "input": "i0", "output": "o1"},
            {"queue_id": "m", "input": "i0", "output": "o0"},
            {"queue_id": "b", "input": "i1", "output": "o1"},
        ],
    }


def _rectangular_domain() -> QueueSchedulerDomain:
    return QueueSchedulerDomain(
        QueueCatalog(("z", "a", "m", "b")),
        service_family="crossbar_matching",
    )


def _full_square_constraint(catalog: QueueCatalog, n_ports: int) -> dict[str, object]:
    return {
        "inputs": list(range(n_ports)),
        "outputs": list(range(n_ports)),
        "edges": [
            {"queue_id": queue_id, "input": edge[0], "output": edge[1]}
            for queue_id in catalog.queue_ids
            if (edge := catalog.legacy_voq_for(queue_id)) is not None
        ],
    }


def _full_square_domain(catalog: QueueCatalog) -> QueueSchedulerDomain:
    return QueueSchedulerDomain(catalog, service_family="crossbar_matching")


def _params(name: str) -> dict[str, object]:
    params: dict[str, object] = {"constraint": _rectangular_constraint()}
    if name == "crossbar_random_grant_accept":
        params["rounds"] = 2
    if name == "crossbar_islip":
        params["iterations"] = 2
    return params


def _assert_crossbar_feasible(
    decision: ServiceDecision,
    constraint: dict[str, object],
) -> None:
    edges = {
        edge["queue_id"]: (edge["input"], edge["output"])
        for edge in constraint["edges"]  # type: ignore[index,union-attr]
    }
    selected = [edges[queue_id] for queue_id in decision.selected_queue_ids]
    assert len({input_label for input_label, _output in selected}) == len(selected)
    assert len({output_label for _input, output_label in selected}) == len(selected)


def _legacy_random_greedy(
    matrix: np.ndarray,
    rng: np.random.Generator,
) -> tuple[tuple[int, int], ...]:
    candidates = [
        (input_rank, output_rank)
        for input_rank in range(matrix.shape[0])
        for output_rank in range(matrix.shape[1])
        if int(matrix[input_rank, output_rank]) > 0
    ]
    used_inputs: set[int] = set()
    used_outputs: set[int] = set()
    selected: list[tuple[int, int]] = []
    for position in rng.permutation(len(candidates)).tolist():
        edge = candidates[int(position)]
        if edge[0] in used_inputs or edge[1] in used_outputs:
            continue
        selected.append(edge)
        used_inputs.add(edge[0])
        used_outputs.add(edge[1])
    return tuple(sorted(selected))


def _uniform_choice(rng: np.random.Generator, candidates: Sequence[int]) -> int:
    if len(candidates) == 1:
        return int(candidates[0])
    return int(candidates[int(rng.integers(0, len(candidates)))])


def _legacy_random_grant_accept(
    matrix: np.ndarray,
    rounds: int,
    rng: np.random.Generator,
) -> tuple[tuple[int, int], ...]:
    n_ports = matrix.shape[0]
    unmatched_inputs = list(range(n_ports))
    unmatched_outputs = list(range(n_ports))
    selected: list[tuple[int, int]] = []
    for _round_index in range(rounds):
        grants: dict[int, int] = {}
        for output_rank in unmatched_outputs:
            requesters = [
                input_rank
                for input_rank in unmatched_inputs
                if int(matrix[input_rank, output_rank]) > 0
            ]
            if requesters:
                grants[output_rank] = _uniform_choice(rng, requesters)
        accepts: dict[int, int] = {}
        for input_rank in unmatched_inputs:
            offered = [
                output_rank
                for output_rank in unmatched_outputs
                if grants.get(output_rank) == input_rank
            ]
            if offered:
                accepts[input_rank] = _uniform_choice(rng, offered)
        if not accepts:
            break
        selected.extend(sorted(accepts.items()))
        matched_inputs = set(accepts)
        matched_outputs = set(accepts.values())
        unmatched_inputs = [value for value in unmatched_inputs if value not in matched_inputs]
        unmatched_outputs = [value for value in unmatched_outputs if value not in matched_outputs]
    return tuple(sorted(selected))


def test_registry_exposes_only_final_scheduler_names_and_algorithm_ids() -> None:
    assert available_schedulers() == FINAL_SCHEDULERS
    expected = {
        "crossbar_random_greedy_maximal": "random_permutation_greedy_maximal",
        "crossbar_random_grant_accept": "uniform_random_grant_accept",
        "crossbar_islip": "persistent_pointer_islip",
        "crossbar_max_weight": "hungarian_exact",
        "interval_max_weight": "weighted_interval_dp_exact",
        "node_exclusive_max_weight": "edmonds_blossom_exact",
        "conflict_graph_max_weight": "mwis_branch_memo_exact",
        "resource_packing_max_weight": "binary_packing_memo_exact",
    }
    for name, algorithm_id in expected.items():
        if name in {
            "interval_max_weight",
            "node_exclusive_max_weight",
            "conflict_graph_max_weight",
            "resource_packing_max_weight",
        }:
            # Their constructor-specific topology is tested in their own suite.
            continue
        spec = resolve_scheduler_spec(name, _params(name))
        assert spec.algorithm_id == algorithm_id


@pytest.mark.parametrize(
    ("old_name", "replacement"),
    [
        ("random_maximal", "crossbar_random_greedy_maximal"),
        ("islip_rga", "crossbar_random_grant_accept"),
        ("islip_canonical", "crossbar_islip"),
        ("canonical_islip", "crossbar_islip"),
    ],
)
def test_old_scheduler_names_are_not_runtime_aliases(old_name: str, replacement: str) -> None:
    with pytest.raises(ConfigError) as captured:
        build_scheduler(old_name)
    assert captured.value.context["replacement"] == replacement


@pytest.mark.parametrize("old_name", ["round_robin", "roundrobin"])
def test_pruned_round_robin_has_no_runtime_replacement(old_name: str) -> None:
    with pytest.raises(ConfigError, match="without a behaviorally equivalent replacement"):
        build_scheduler(old_name)


def test_bare_islip_remains_an_explicit_ambiguity_error() -> None:
    with pytest.raises(ConfigError) as captured:
        build_scheduler("islip")
    assert captured.value.context["allowed_replacements"] == [
        "crossbar_islip",
        "crossbar_random_grant_accept",
    ]


@pytest.mark.parametrize(
    ("name", "scheduler_type"),
    [
        ("crossbar_random_greedy_maximal", CrossbarRandomGreedyMaximalScheduler),
        ("crossbar_random_grant_accept", CrossbarRandomGrantAcceptScheduler),
        ("crossbar_islip", CrossbarISlipScheduler),
    ],
)
def test_sparse_rectangular_heuristics_emit_feasible_native_decisions(name, scheduler_type) -> None:
    scheduler = build_scheduler_for_domain(name, _params(name), _rectangular_domain())
    assert isinstance(scheduler, scheduler_type)
    vector = np.array([4, 3, 2, 1], dtype=np.int64)
    decision = scheduler.select_service(
        vector,
        slot=5,
        rng=build_scheduler_rng_for_slot(1205, 5),
    )
    assert isinstance(decision, ServiceDecision)
    assert scheduler.validate_service_decision(decision, vector) == decision
    _assert_crossbar_feasible(decision, _rectangular_constraint())


def test_random_greedy_result_is_maximal_on_live_sparse_edges() -> None:
    scheduler = build_scheduler_for_domain(
        "crossbar_random_greedy_maximal",
        _params("crossbar_random_greedy_maximal"),
        _rectangular_domain(),
    )
    vector = np.array([1, 1, 1, 1], dtype=np.int64)
    decision = scheduler.select_service(vector, 0, build_scheduler_rng_for_slot(8, 0))
    selected = set(decision.selected_queue_ids)
    edges = {
        edge["queue_id"]: (edge["input"], edge["output"])
        for edge in _rectangular_constraint()["edges"]  # type: ignore[index,union-attr]
    }
    used_inputs = {edges[queue_id][0] for queue_id in selected}
    used_outputs = {edges[queue_id][1] for queue_id in selected}
    for queue_id, (input_label, output_label) in edges.items():
        if queue_id not in selected:
            assert input_label in used_inputs or output_label in used_outputs


@pytest.mark.parametrize("seed", range(20))
def test_full_square_random_greedy_preserves_legacy_seeded_decisions(seed: int) -> None:
    catalog = QueueCatalog.legacy_crossbar(3)
    domain = _full_square_domain(catalog)
    vector = np.array([0, 2, 1, 5, 0, 3, 0, 4, 0], dtype=np.int64)
    matrix = vector.reshape((3, 3))
    scheduler = build_scheduler_for_domain(
        "crossbar_random_greedy_maximal",
        {"constraint": _full_square_constraint(catalog, 3)},
        domain,
    )
    decision = scheduler.select_service(vector, 7, build_scheduler_rng_for_slot(seed, 7))
    expected = _legacy_random_greedy(matrix, build_scheduler_rng_for_slot(seed, 7))
    assert decision.selected_queue_ids == tuple(
        sorted(
            (catalog.queue_id_for_voq(edge) for edge in expected),
            key=catalog.index_of,
        )
    )


@pytest.mark.parametrize("seed", range(20))
def test_full_square_random_grant_accept_preserves_legacy_seeded_decisions(seed: int) -> None:
    catalog = QueueCatalog.legacy_crossbar(3)
    domain = _full_square_domain(catalog)
    vector = np.array([0, 2, 1, 5, 0, 3, 0, 4, 0], dtype=np.int64)
    matrix = vector.reshape((3, 3))
    scheduler = build_scheduler_for_domain(
        "crossbar_random_grant_accept",
        {"constraint": _full_square_constraint(catalog, 3), "rounds": 2},
        domain,
    )
    decision = scheduler.select_service(vector, 7, build_scheduler_rng_for_slot(seed, 7))
    expected = _legacy_random_grant_accept(
        matrix,
        2,
        build_scheduler_rng_for_slot(seed, 7),
    )
    assert decision.selected_queue_ids == tuple(
        sorted(
            (catalog.queue_id_for_voq(edge) for edge in expected),
            key=catalog.index_of,
        )
    )


def test_rectangular_islip_pointer_shapes_ranges_state_and_reset() -> None:
    params = _params("crossbar_islip")
    params.update(
        {
            "initial_grant_pointers": [1, 0, 1],
            "initial_accept_pointers": [2, 0],
        }
    )
    scheduler = build_scheduler_for_domain("crossbar_islip", params, _rectangular_domain())
    initial = scheduler.state_dict()
    assert initial["grant_pointers"] == [1, 0, 1]
    assert initial["accept_pointers"] == [2, 0]

    vector = np.ones(4, dtype=np.int64)
    first = scheduler.select_service(vector, 0, build_scheduler_rng_for_slot(3, 0))
    changed = scheduler.state_dict()
    assert changed != initial
    scheduler.reset()
    assert scheduler.state_dict() == initial
    replay = scheduler.select_service(vector, 1, build_scheduler_rng_for_slot(999, 1))
    assert replay == first


def test_full_square_islip_preserves_first_iteration_pointer_updates_and_reset() -> None:
    catalog = QueueCatalog.legacy_crossbar(2)
    domain = _full_square_domain(catalog)
    scheduler = build_scheduler_for_domain(
        "crossbar_islip",
        {"constraint": _full_square_constraint(catalog, 2), "iterations": 2},
        domain,
    )
    vector = np.ones(4, dtype=np.int64)
    first = scheduler.select_service(vector, 0, build_scheduler_rng_for_slot(1, 0))
    first_state = scheduler.state_dict()
    second = scheduler.select_service(vector, 1, build_scheduler_rng_for_slot(2, 1))
    second_state = scheduler.state_dict()

    assert first.selected_queue_ids == (
        catalog.queue_id_for_voq((0, 0)),
        catalog.queue_id_for_voq((1, 1)),
    )
    assert first_state["grant_pointers"] == [1, 0]
    assert first_state["accept_pointers"] == [1, 0]
    assert second.selected_queue_ids == (
        catalog.queue_id_for_voq((0, 1)),
        catalog.queue_id_for_voq((1, 0)),
    )
    assert second_state["grant_pointers"] == [0, 1]
    assert second_state["accept_pointers"] == [0, 1]

    scheduler.reset()
    replay = scheduler.select_service(vector, 2, build_scheduler_rng_for_slot(999, 2))
    assert replay == first


@pytest.mark.parametrize(
    "params",
    [
        {"iterations": 3},
        {"iterations": 1, "initial_grant_pointers": [0, 0]},
        {"iterations": 1, "initial_accept_pointers": [0, 0, 0]},
        {"iterations": 1, "initial_grant_pointers": [2, 0, 0]},
        {"iterations": 1, "initial_accept_pointers": [3, 0]},
    ],
)
def test_rectangular_islip_rejects_invalid_dimension_dependent_params(params) -> None:
    params = {"constraint": _rectangular_constraint(), **params}
    with pytest.raises(ValidationError):
        build_scheduler_for_domain("crossbar_islip", params, _rectangular_domain())


def test_random_grant_accept_round_bound_is_dimension_dependent() -> None:
    params = {"constraint": _rectangular_constraint(), "rounds": 3}
    with pytest.raises(ValidationError, match="smaller port side"):
        build_scheduler_for_domain(
            "crossbar_random_grant_accept",
            params,
            _rectangular_domain(),
        )


@pytest.mark.parametrize(
    ("name", "params"),
    [
        ("crossbar_random_greedy_maximal", {"k": 1}),
        ("crossbar_random_grant_accept", {"k": 1}),
        ("crossbar_random_grant_accept", {"num_rounds": 1}),
        ("crossbar_islip", {"k": 1}),
        ("crossbar_islip", {"rounds": 1}),
    ],
)
def test_legacy_parameter_spellings_are_not_v4_runtime_aliases(name: str, params) -> None:
    with pytest.raises(ValidationError, match="unsupported scheduler params"):
        build_scheduler(name, params)


@pytest.mark.parametrize(
    "name",
    [
        "crossbar_random_greedy_maximal",
        "crossbar_random_grant_accept",
        "crossbar_islip",
    ],
)
def test_crossbar_heuristics_reject_every_other_service_family(name: str) -> None:
    domain = QueueSchedulerDomain(QueueCatalog(("q",)), service_family="pairwise_conflicts")
    constraint = {
        "inputs": [0],
        "outputs": [0],
        "edges": [{"queue_id": "q", "input": 0, "output": 0}],
    }
    params: dict[str, object] = {"constraint": constraint}
    if name == "crossbar_random_grant_accept":
        params["rounds"] = 1
    if name == "crossbar_islip":
        params["iterations"] = 1
    with pytest.raises(ValidationError, match="crossbar_matching"):
        build_scheduler_for_domain(name, params, domain)


def test_crossbar_feasibility_validator_rejects_conflicting_decision() -> None:
    scheduler = build_scheduler_for_domain(
        "crossbar_random_greedy_maximal",
        _params("crossbar_random_greedy_maximal"),
        _rectangular_domain(),
    )
    vector = np.ones(4, dtype=np.int64)
    with pytest.raises(ScheduleError, match="one-queue-per-input"):
        scheduler.validate_service_decision(ServiceDecision(("a", "m")), vector)
