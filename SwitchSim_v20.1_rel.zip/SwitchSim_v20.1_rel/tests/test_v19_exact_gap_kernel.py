from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY, load_raw_config
from voqsim.errors import ScheduleError
from voqsim.kernel import build_simulation
from voqsim.telemetry import CompactObservationReader, STATUS_FAILED


CONFIG_DIR = Path(__file__).resolve().parents[1] / "configs"


def _observe(raw: dict[str, object], targets: list[str], *, gap: str) -> dict[str, object]:
    result = deepcopy(raw)
    telemetry = dict(result.get("telemetry", {}))
    telemetry.update(
        {
            "write_slot_trace": False,
            "observation": {
                "enabled": True,
                "block_slots": None,
                "targets": [
                    {"queue_id": queue_id, "gap": gap}
                    for queue_id in targets
                ],
            },
        }
    )
    result["telemetry"] = telemetry
    return result


def _commit_signature(commit) -> tuple[object, ...]:
    return (
        commit.slot,
        tuple(int(value) for value in commit.q_before),
        tuple(commit.selected_queue_ids),
        tuple(sorted(commit.offered_by_queue.items())),
        tuple(sorted(commit.admitted_by_queue.items())),
        tuple(sorted(commit.dropped_by_queue.items())),
        tuple(int(value) for value in commit.q_after),
    )


@pytest.mark.parametrize(
    "config_name,target",
    [
        ("4x4_iid_table_crossbar_max_weight_exact.yaml", "voq[0,1]"),
        ("schema3_interval_max_weight.yaml", "wide"),
        ("schema3_node_exclusive_max_weight.yaml", "ab-heavy"),
        ("schema3_conflict_graph_max_weight.yaml", "red"),
        ("schema3_resource_packing_max_weight.yaml", "bridge"),
    ],
)
def test_exact_gap_collection_preserves_dynamics_for_all_five_families(
    config_name: str,
    target: str,
    tmp_path: Path,
) -> None:
    source = load_raw_config(CONFIG_DIR / config_name)
    exact_simulator = build_simulation(
        _observe(source, [target], gap="exact"),
        output_dir=tmp_path / "exact",
    )
    plain_simulator = build_simulation(
        _observe(source, [target], gap="none"),
        output_dir=tmp_path / "plain",
    )
    exact_commits: list[object] = []
    plain_commits: list[object] = []

    exact_result = exact_simulator.run(observers=exact_commits.append)
    plain_result = plain_simulator.run(observers=plain_commits.append)

    assert [_commit_signature(commit) for commit in exact_commits] == [
        _commit_signature(commit) for commit in plain_commits
    ]
    assert exact_result.summary.metrics == plain_result.summary.metrics
    assert exact_result.measurement_start_queue_lengths == plain_result.measurement_start_queue_lengths
    assert exact_result.measurement_end_queue_lengths == plain_result.measurement_end_queue_lengths
    assert np.array_equal(
        exact_simulator.switch.queue_lengths(),
        plain_simulator.switch.queue_lengths(),
    )
    assert all(
        len(commit.exact_gap_certificates) == 1
        and isinstance(commit.gap_for(target), int)
        for commit in exact_commits
    )
    assert all(
        not commit.exact_gap_certificates and commit.gap_for(target) is None
        for commit in plain_commits
    )
    with pytest.raises(TypeError):
        exact_commits[0].gap_by_queue[target] = 0


@pytest.mark.parametrize("path", ["dense_crossbar", "sparse_crossbar"])
def test_exact_certificates_reach_commits_on_canonical_crossbar_topologies(path: str, tmp_path: Path) -> None:
    if path == "dense_crossbar":
        raw = load_raw_config(CONFIG_DIR / "4x4_iid_table_crossbar_max_weight_exact.yaml")
        raw["run"]["warmup_slots"] = 1
        target = "voq[0,1]"
    else:
        raw = load_raw_config(CONFIG_DIR / "schema3_sparse_rectangular_crossbar_max_weight.yaml")
        raw["run"]["warmup_slots"] = 1
        target = "north"

    commits: list[object] = []
    result = build_simulation(
        _observe(raw, [target], gap="exact"),
        output_dir=tmp_path / path,
    ).run(observers=commits.append)

    assert len(commits) == raw["run"]["slots"] - raw["run"]["warmup_slots"]
    assert all(tuple(commit.gap_by_queue) == (target,) for commit in commits)
    assert result.observation_path is not None
    with CompactObservationReader(result.observation_path) as reader:
        assert sum(row.exposure for row in reader.iter_levels()) == len(commits)
        assert all(row.gap_mode == "exact" for row in reader.iter_levels())
        reader.integrity_check()


def _phase_config(*, targets: list[str], termination: str = "fixed_slots_then_drain") -> dict[str, object]:
    raw: dict[str, object] = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 19032,
            "slots": 2,
            "warmup_slots": 1,
            "termination": termination,
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": ["q0", "q1"],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [
                {"slot": 0, "queue_id": "q0", "count": 1},
                {"slot": 0, "queue_id": "q1", "count": 1},
                {"slot": 1, "queue_id": "q0", "count": 2},
            ],
        },
        "telemetry": {"write_slot_trace": False},
    }
    return _observe(raw, targets, gap="exact")


def test_exact_solves_are_confined_to_measurement_not_warmup_or_drain(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    simulator = build_simulation(_phase_config(targets=["q0"]), output_dir=tmp_path / "phases")
    scheduler_type = type(simulator.scheduler)
    original = scheduler_type.exact_class_certificates
    solved_slots: list[int] = []

    def record_slots(self, q_len, production_decision, target_queue_ids, *, slot):
        solved_slots.append(slot)
        return original(
            self,
            q_len,
            production_decision,
            target_queue_ids,
            slot=slot,
        )

    monkeypatch.setattr(scheduler_type, "exact_class_certificates", record_slots)
    commits: list[object] = []
    result = simulator.run(observers=commits.append)

    assert solved_slots == [1]
    assert [commit.slot for commit in commits] == [1]
    assert result.slots_run > result.summary.to_dict()["metadata"]["configured_slots"]
    assert len(commits[0].exact_gap_certificates) == 1


def test_disabled_observations_do_not_request_exact_certificates(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    raw = _phase_config(targets=["q0"], termination="fixed_slots")
    raw["telemetry"]["observation"]["enabled"] = False
    simulator = build_simulation(raw, output_dir=tmp_path / "disabled")

    def unexpected(*_args, **_kwargs):
        raise AssertionError("disabled observations requested an exact certificate")

    monkeypatch.setattr(type(simulator.scheduler), "exact_class_certificates", unexpected)
    commits: list[object] = []
    result = simulator.run(observers=commits.append)

    assert result.observation_path is None
    assert all(not commit.exact_gap_certificates for commit in commits)


def test_invalid_second_certificate_fails_before_service_arrivals_or_observation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    simulator = build_simulation(
        _phase_config(targets=["q0", "q1"], termination="fixed_slots"),
        output_dir=tmp_path / "atomic",
    )
    scheduler_type = type(simulator.scheduler)
    original = scheduler_type.exact_class_certificates
    solved_slots: list[int] = []

    def corrupt_second(self, q_len, production_decision, target_queue_ids, *, slot):
        solved_slots.append(slot)
        certificates = original(
            self,
            q_len,
            production_decision,
            target_queue_ids,
            slot=slot,
        )
        return (certificates[0], certificates[0])

    monkeypatch.setattr(scheduler_type, "exact_class_certificates", corrupt_second)
    commits: list[object] = []

    with pytest.raises(ScheduleError, match="order or identity"):
        simulator.run(observers=commits.append)

    # Warmup admitted one packet to each queue.  The failing measured slot
    # neither served q0 nor sampled/admitted its two configured arrivals.
    assert simulator.switch.queue_lengths().tolist() == [1, 1]
    assert solved_slots == [1]
    assert commits == []
    assert simulator.observation_path is not None
    with CompactObservationReader(simulator.observation_path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED
        assert tuple(reader.iter_levels()) == ()
