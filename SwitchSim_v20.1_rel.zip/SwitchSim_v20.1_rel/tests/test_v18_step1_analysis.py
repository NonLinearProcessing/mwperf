from fractions import Fraction

import pytest

from voqsim.analysis import (
    ArrivalMarginal,
    beta_k,
    cutoff_analysis,
    cutoff_sweep,
    empirical_error_accounting,
    finite_window_accounting,
    normalize_level_masses,
    weighted_innovation,
)
from voqsim.errors import ValidationError


def test_normalize_pools_before_dividing() -> None:
    masses = normalize_level_masses({0: 2, 1: 4, 3: 2}, {0: 0, 1: 2, 3: 2})
    assert masses.total_mass == 8
    assert masses.p == {0: Fraction(1, 4), 1: Fraction(1, 2), 3: Fraction(1, 4)}
    assert masses.response == {0: 0, 1: Fraction(1, 2), 3: 1}
    assert masses.departure_mean == Fraction(1, 2)
    assert masses.backlog_mean == Fraction(5, 4)
    assert masses.service_backlog_moment == 1


def test_normalize_rejects_service_greater_than_exposure() -> None:
    with pytest.raises(ValidationError, match="cannot exceed"):
        normalize_level_masses({2: 1}, {2: 2})


def test_cutoff_reports_all_tail_quantities() -> None:
    masses = normalize_level_masses({0: 2, 1: 4, 3: 2}, {0: 0, 1: 2, 3: 2})
    result = cutoff_analysis(masses, 1, Fraction(1, 4))
    assert result.tau == Fraction(1, 4)
    assert result.service_tail_mass == Fraction(1, 4)
    assert result.backlog_tail_mass == Fraction(3, 4)
    assert result.service_backlog_tail_mass == Fraction(3, 4)
    assert result.tail_service == 1
    assert result.slack == Fraction(3, 4)
    assert result.association == 0
    assert result.tail_mean_share == Fraction(3, 5)
    assert result.compression_defect == 0
    assert result.status == "ok"


def test_cutoff_statuses_preserve_raw_values() -> None:
    masses = normalize_level_masses({0: 2, 1: 1}, {0: 0, 1: 0})
    no_tail = cutoff_analysis(masses, 1, Fraction(0))
    assert no_tail.status == "no_tail_exposure"
    dropped = cutoff_analysis(masses, 0, Fraction(0), drops=1)
    assert dropped.status == "drop_affected"
    assert dropped.tau == Fraction(1, 3)
    assert cutoff_analysis(masses, 0, Fraction(0), fresh_iid=False).status == "not_fresh_iid"
    unserved = normalize_level_masses({0: 1, 2: 1}, {})
    assert cutoff_analysis(unserved, 0, Fraction(1, 4)).status == "no_observed_service"


def test_cutoff_sweep_is_sorted_and_unique() -> None:
    masses = normalize_level_masses({0: 1, 1: 1, 2: 1}, {0: 0, 1: 1, 2: 1})
    results = cutoff_sweep(masses, [2, 0, 2, 1], Fraction(0))
    assert [result.cutoff for result in results] == [0, 1, 2]


def test_arrival_marginal_and_beta_use_no_extra_samples() -> None:
    arrival = ArrivalMarginal.from_pmf({0: Fraction(3, 4), 1: Fraction(1, 4)})
    assert arrival.mean == Fraction(1, 4)
    assert arrival.second_moment == Fraction(1, 4)
    masses = normalize_level_masses({0: 2, 1: 2}, {0: 0, 1: 1})
    assert beta_k(masses, 1, arrival) == Fraction(1, 16)


def test_empirical_terms_sum_exactly() -> None:
    masses = normalize_level_masses({0: 4, 1: 4, 2: 4}, {0: 0, 1: 2, 2: 4})
    cutoff = cutoff_analysis(masses, 1, Fraction(1, 4))
    result = empirical_error_accounting(
        masses,
        cutoff,
        arrival_mean=Fraction(1, 4),
        arrival_second_moment=Fraction(1, 4),
        input_response={0: 0, 1: Fraction(1, 2)},
        fitted_prefix={0: Fraction(1, 2), 1: Fraction(1, 4)},
        fitted_tail_mass=Fraction(1, 4),
        fitted_mean=Fraction(3, 2),
    )
    assert result.status == "ok"
    assert result.total_error == (
        result.tail_association_term + result.prefix_balance_term + result.stationarity_term
    )
    assert result.fitted_tail_mass == Fraction(1, 4)
    assert result.fitted_mean == Fraction(3, 2)


def test_finite_window_balance_and_tail_slack() -> None:
    arrival = ArrivalMarginal.from_pmf({0: 1})
    masses = normalize_level_masses({0: 4}, {0: 0})
    cutoff = cutoff_analysis(masses, 0, arrival.mean)
    result = finite_window_accounting(masses, {0: 1}, {0: 1}, 4, arrival, cutoff=cutoff)
    assert result.eta_1 == result.expected_eta_1 == 0
    assert result.eta_2 == result.expected_eta_2 == 0
    assert result.z_from_endpoints == 0
    assert result.eta_k == 0
    assert result.beta_k == 0


def test_weighted_innovation_reconstructed_from_boundaries() -> None:
    arrival = ArrivalMarginal.from_pmf({0: 1})
    masses = normalize_level_masses({2: 8}, {2: 0})
    result = weighted_innovation(masses, {2: 1}, {2: 1}, 8, arrival, lambda n: n * n)
    assert result.innovation == 0
    assert result.endpoint_drift == 0
    assert result.observed_mean == 4
    assert result.expected_next_mean == 4


def test_pmf_and_boundary_validation() -> None:
    with pytest.raises(ValidationError, match="sum exactly"):
        ArrivalMarginal.from_pmf({0: Fraction(1, 3), 1: Fraction(1, 3)})
    masses = normalize_level_masses({0: 1}, {0: 0})
    arrival = ArrivalMarginal.from_pmf({0: 1})
    with pytest.raises(ValidationError, match="positive total"):
        weighted_innovation(masses, {}, {0: 1}, 1, arrival, lambda n: n)
