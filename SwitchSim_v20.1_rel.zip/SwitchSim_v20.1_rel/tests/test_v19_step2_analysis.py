from __future__ import annotations

from fractions import Fraction

import pytest

from voqsim.analysis import (
    ArrivalMarginal,
    DecoderMeanEstimate,
    ReferenceMeanEstimate,
    authoritative_error_separation,
    cutoff_analysis,
    gap_competition_analysis,
    gap_level_analysis,
    gap_tail_analysis,
    normalize_level_masses,
    stationary_tie_analysis,
)
from voqsim.errors import ValidationError


def _oracle_cutoff():
    masses = normalize_level_masses(
        {0: 2, 1: 4, 2: 2},
        {0: 0, 1: 2, 2: 2},
    )
    return cutoff_analysis(masses, 0, Fraction(1, 2))


def test_exact_gap_oracle_reproduces_competition_tail_and_tie_formulas() -> None:
    competition = gap_competition_analysis(
        exposure=8,
        backlog_exposure=8,
        gap_positive_sum=5,
        gap_negative_sum=2,
    )
    assert competition.backlog_mean == 1
    assert competition.gap_mean == Fraction(3, 8)
    assert competition.competition_mean == Fraction(5, 8)
    assert competition.absolute_gap_mean == Fraction(7, 8)
    assert competition.competition_ratio == Fraction(7, 5)
    assert competition.identity_residual == 0
    assert competition.inequality_margin == Fraction(1, 2)
    assert competition.status == "ok"

    cutoff = _oracle_cutoff()
    assert cutoff.tau == Fraction(3, 4)
    assert cutoff.tail_service == Fraction(2, 3)
    assert cutoff.association == Fraction(1, 12)
    tail = gap_tail_analysis(
        cutoff,
        exposure=8,
        gap_positive_tail_sum=5,
        gap_negative_tail_sum=2,
        stationary_interpretation=True,
    )
    assert tail.positive_gap_tail_mass == Fraction(5, 8)
    assert tail.negative_gap_tail_mass == Fraction(1, 4)
    assert tail.gap_association == Fraction(3, 8)
    assert tail.competition_association == Fraction(-7, 24)
    assert tail.backlog_service_covariance == Fraction(1, 9)
    assert tail.competition_service_covariance == Fraction(-7, 18)
    assert tail.gap_covariance_term == Fraction(1, 2)
    assert tail.covariance_identity_residual == 0
    assert tail.compression_total == cutoff.compression_defect
    assert tail.status == "ok"

    arrival = ArrivalMarginal.from_pmf({0: Fraction(1, 2), 1: Fraction(1, 2)})
    tie = stationary_tie_analysis(
        exposure=8,
        backlog_exposure=8,
        gap_negative_backlog=1,
        gap_zero_unserved_backlog=1,
        arrival=arrival,
        stationary_interpretation=True,
    )
    assert tie.strict_loss == tie.lost_tie == Fraction(1, 8)
    assert tie.total_loss == Fraction(1, 4)
    assert tie.base_term == Fraction(1, 4)
    assert tie.isolated_component == Fraction(1, 2)
    assert tie.strict_loss_component == Fraction(1, 4)
    assert tie.lost_tie_component == Fraction(1, 4)
    assert tie.loss_component == Fraction(1, 2)
    assert tie.decomposed_mean == tie.backlog_mean == 1
    assert tie.decomposition_residual == 0
    assert tie.status == "ok"


@pytest.mark.parametrize(
    (
        "backlog",
        "exposure",
        "served",
        "negative",
        "zero",
        "positive",
        "tie_served",
        "g_plus",
        "g_minus",
        "strict",
        "tied",
    ),
    [
        (0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0),
        (1, 4, 2, 1, 2, 1, 1, 1, 2, Fraction(1, 4), Fraction(1, 4)),
        (2, 2, 2, 0, 0, 2, 0, 4, 0, 1, 0),
    ],
)
def test_per_level_response_is_strict_win_plus_served_tie(
    backlog,
    exposure,
    served,
    negative,
    zero,
    positive,
    tie_served,
    g_plus,
    g_minus,
    strict,
    tied,
) -> None:
    result = gap_level_analysis(
        backlog=backlog,
        exposure=exposure,
        served=served,
        gap_negative=negative,
        gap_zero=zero,
        gap_positive=positive,
        gap_zero_served=tie_served,
        gap_positive_sum=g_plus,
        gap_negative_sum=g_minus,
    )
    assert result.strict_win_probability == strict
    assert result.tied_service_probability == tied
    assert result.response == strict + tied
    assert result.response_identity_residual == 0
    assert result.status == "ok"


def test_gap_not_requested_preserves_base_response() -> None:
    row = gap_level_analysis(
        backlog=3,
        exposure=5,
        served=2,
        gap_negative=None,
        gap_zero=None,
        gap_positive=None,
        gap_zero_served=None,
        gap_positive_sum=None,
        gap_negative_sum=None,
    )
    assert row.response == Fraction(2, 5)
    assert row.strict_win_probability is None
    assert row.status == "gap_not_requested"

    competition = gap_competition_analysis(
        exposure=5,
        backlog_exposure=15,
        gap_positive_sum=None,
        gap_negative_sum=None,
    )
    assert competition.backlog_mean == 3
    assert competition.competition_mean is None
    assert competition.status == "gap_not_requested"


def test_gap_statuses_do_not_hide_descriptive_raw_quantities() -> None:
    cutoff = _oracle_cutoff()
    unasserted = gap_tail_analysis(
        cutoff,
        exposure=8,
        gap_positive_tail_sum=5,
        gap_negative_tail_sum=2,
    )
    assert unasserted.status == "stationarity_not_asserted"
    assert unasserted.gap_association == Fraction(3, 8)
    assert unasserted.compression_total is None

    zero_scale = gap_competition_analysis(
        exposure=4,
        backlog_exposure=4,
        gap_positive_sum=4,
        gap_negative_sum=0,
    )
    assert zero_scale.competition_mean == 0
    assert zero_scale.absolute_gap_mean == 1
    assert zero_scale.competition_ratio is None
    assert zero_scale.status == "zero_competition_scale"

    no_law = stationary_tie_analysis(
        exposure=8,
        backlog_exposure=8,
        gap_negative_backlog=1,
        gap_zero_unserved_backlog=1,
        arrival=None,
        stationary_interpretation=True,
    )
    assert no_law.strict_loss == no_law.lost_tie == Fraction(1, 8)
    assert no_law.isolated_component is None
    assert no_law.status == "arrival_law_unavailable"


@pytest.mark.parametrize(
    ("arrival", "drops", "stationary", "expected"),
    [
        (ArrivalMarginal.from_pmf({0: 1}, fresh_iid=False), 0, True, "not_fresh_iid"),
        (ArrivalMarginal.from_pmf({1: 1}), 0, True, "lambda_not_below_one"),
        (ArrivalMarginal.from_pmf({0: 1}), 1, True, "drop_affected"),
        (ArrivalMarginal.from_pmf({0: 1}), 0, False, "stationarity_not_asserted"),
    ],
)
def test_stationary_tie_applicability_statuses(arrival, drops, stationary, expected) -> None:
    result = stationary_tie_analysis(
        exposure=1,
        backlog_exposure=0,
        gap_negative_backlog=0,
        gap_zero_unserved_backlog=0,
        arrival=arrival,
        drops=drops,
        stationary_interpretation=stationary,
    )
    assert result.status == expected
    assert result.decomposed_mean is None


def test_gap_arithmetic_has_no_fixed_width_ceiling() -> None:
    scale = 1 << 200
    result = gap_competition_analysis(
        exposure=8 * scale,
        backlog_exposure=8 * scale,
        gap_positive_sum=5 * scale,
        gap_negative_sum=2 * scale,
    )
    assert result.competition_mean == Fraction(5, 8)
    assert result.competition_ratio == Fraction(7, 5)


@pytest.mark.parametrize(
    "overrides",
    [
        {"gap_positive": 2},
        {"gap_zero_served": 3},
        {"gap_positive_sum": 0},
        {"gap_positive_sum": 2},
        {"served": 1},
        {
            "backlog": 0,
            "exposure": 1,
            "served": 0,
            "gap_negative": 0,
            "gap_zero": 1,
            "gap_positive": 0,
            "gap_zero_served": 1,
            "gap_positive_sum": 0,
            "gap_negative_sum": 0,
        },
    ],
)
def test_invalid_exact_level_tuple_is_rejected(overrides) -> None:
    values = {
        "backlog": 1,
        "exposure": 4,
        "served": 2,
        "gap_negative": 1,
        "gap_zero": 2,
        "gap_positive": 1,
        "gap_zero_served": 1,
        "gap_positive_sum": 1,
        "gap_negative_sum": 2,
    }
    values.update(overrides)
    with pytest.raises(ValidationError):
        gap_level_analysis(**values)


def test_authoritative_decoder_error_separation_telescopes_exactly() -> None:
    result = authoritative_error_separation(
        sampler=DecoderMeanEstimate.create(
            target_id="q", cutoff=8, fitted_mean=8, status="ok"
        ),
        finite_window=DecoderMeanEstimate.create(
            target_id="q", cutoff=8, fitted_mean=7, status="ok"
        ),
        stationary=DecoderMeanEstimate.create(
            target_id="q", cutoff=8, fitted_mean=6, status="ok"
        ),
        stationary_mean=ReferenceMeanEstimate.create(
            target_id="q", mean=5, status="ok"
        ),
    )
    assert result.compression == 1
    assert result.finite_window_construction == 1
    assert result.sampling == 1
    assert result.total == 3
    assert result.accounting_residual == 0
    assert result.status == "ok"


def test_failed_decoder_fit_remains_a_status_not_a_numeric_error() -> None:
    result = authoritative_error_separation(
        sampler=DecoderMeanEstimate.create(
            target_id="q", cutoff=4, fitted_mean=8, status="ok"
        ),
        finite_window=DecoderMeanEstimate.create(
            target_id="q",
            cutoff=4,
            fitted_mean=7,
            status="nonpositive_tail_slack",
        ),
        stationary=DecoderMeanEstimate.create(
            target_id="q", cutoff=4, fitted_mean=6, status="ok"
        ),
        stationary_mean=ReferenceMeanEstimate.create(
            target_id="q", mean=5, status="ok"
        ),
    )
    assert result.compression == 1
    assert result.finite_window_construction is None
    assert result.sampling is None
    assert result.total == 3
    assert result.construction_status == "finite_window_decoder:nonpositive_tail_slack"
    assert result.status == "incomplete"


def test_error_separation_rejects_different_targets_or_cutoffs() -> None:
    stationary_mean = ReferenceMeanEstimate.create(target_id="q", mean=1, status="ok")
    common = DecoderMeanEstimate.create(target_id="q", cutoff=4, fitted_mean=1, status="ok")
    with pytest.raises(ValidationError, match="same cutoff"):
        authoritative_error_separation(
            sampler=DecoderMeanEstimate.create(
                target_id="q", cutoff=8, fitted_mean=1, status="ok"
            ),
            finite_window=common,
            stationary=common,
            stationary_mean=stationary_mean,
        )
    with pytest.raises(ValidationError, match="same target"):
        authoritative_error_separation(
            sampler=DecoderMeanEstimate.create(
                target_id="other", cutoff=4, fitted_mean=1, status="ok"
            ),
            finite_window=common,
            stationary=common,
            stationary_mean=stationary_mean,
        )
