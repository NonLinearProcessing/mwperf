from __future__ import annotations

from copy import deepcopy
from decimal import Decimal

import pytest

from voqsim.config import resolve_config, resolved_config_to_dict
from voqsim.errors import ConfigError, ValidationError
from voqsim.kernel import build_simulation


def _base(
    arrival: dict[str, object],
    *,
    queues: list[dict[str, object]] | None = None,
    conflicts: list[list[object]] | None = None,
) -> dict[str, object]:
    queue_specs = queues or [{"id": "q0"}, {"id": "q1"}]
    return {
        "schema_version": "4.0.0",
        "run": {"seed": 27, "slots": 16},
        "switch": {
            "kind": "generalized",
            "queue_capacity": "NoDrop",
            "queues": queue_specs,
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {
                    "conflicts": [["q0", "q1"]] if conflicts is None else conflicts,
                }
            },
        },
        "arrival": arrival,
    }


VALID_COUNT_ARRIVALS = (
    {
        "family": "iid_count_table",
        "outcomes": [
            {
                "id": "idle",
                "counts": [],
                "probability": Decimal("0.25"),
            },
            {
                "id": "batch",
                "counts": [{"queue_id": "q0", "count": 3}],
                "probability": Decimal("0.75"),
            },
        ],
    },
    {
        "family": "markov_count_kernel",
        "states": ["off", "on"],
        "outcomes": [
            {"id": "idle", "counts": []},
            {"id": "hit", "counts": [{"queue_id": "q1", "count": 2}]},
        ],
        "kernel": [
            {
                "state": "off",
                "outcome_id": "idle",
                "next_state": "on",
                "probability": Decimal(1),
            },
            {
                "state": "on",
                "outcome_id": "hit",
                "next_state": "off",
                "probability": Decimal(1),
            },
        ],
        "initial": {"state": "off"},
    },
    {
        "family": "deterministic_trace",
        "events": [
            {"slot": 0, "queue_id": "q0", "count": 5},
            {"slot": 9, "queue_id": "q1", "count": 1},
        ],
    },
    {
        "family": "periodic_global_phase",
        "period": 4,
        "phase": 3,
        "sources": [
            {
                "id": "source-a",
                "entries": [
                    {"offset": 0, "queue_id": "q0", "count": 2},
                    {"offset": 3, "queue_id": "q1", "count": 1},
                ],
            }
        ],
    },
    {
        "family": "periodic_source_delays",
        "period": 3,
        "sources": [
            {
                "id": "source-a",
                "delay": 0,
                "entries": [{"offset": 2, "queue_id": "q0", "count": 2}],
            },
            {
                "id": "source-b",
                "delay": 7,
                "entries": [{"offset": 0, "queue_id": "q1", "count": 1}],
            },
        ],
    },
    {
        "family": "independent_marked_renewal",
        "sources": [
            {
                "id": "fixed",
                "interarrival": {"kind": "deterministic", "d": 1},
                "destination_pmf": [
                    {"queue_id": "q0", "probability": Decimal("0.75")},
                    {"queue_id": "q1", "probability": Decimal("0.25")},
                ],
            },
            {
                "id": "joint",
                "joint_pmf": [
                    {"d": 1, "queue_id": "q1", "probability": Decimal("0.4")},
                    {"d": 3, "queue_id": "q0", "probability": Decimal("0.6")},
                ],
            },
        ],
    },
    {
        "family": "independent_private_markov_renewal",
        "sources": [
            {
                "id": "private-a",
                "states": ["short", "long"],
                "initial": {
                    "distribution": {
                        "short": Decimal("0.5"),
                        "long": Decimal("0.5"),
                    }
                },
                "gaps": [
                    {"state": "short", "d": 1},
                    {"state": "long", "d": 4},
                ],
                "transitions": [
                    {
                        "state": "short",
                        "next_state": "short",
                        "probability": Decimal("0.9"),
                    },
                    {
                        "state": "short",
                        "next_state": "long",
                        "probability": Decimal("0.1"),
                    },
                    {
                        "state": "long",
                        "next_state": "short",
                        "probability": Decimal("0.2"),
                    },
                    {
                        "state": "long",
                        "next_state": "long",
                        "probability": Decimal("0.8"),
                    },
                ],
                "destination_pmf": [
                    {"queue_id": "q0", "probability": Decimal(1)}
                ],
            }
        ],
    },
    {
        "family": "shared_joint_round_markov_renewal",
        "sources": [{"id": "left"}, {"id": "right"}],
        "states": ["only"],
        "initial": {"state": "only"},
        "outcomes": [
            {
                "state": "only",
                "next_state": "only",
                "probability": Decimal(1),
                "emissions": [
                    {"source_id": "left", "d": 1, "queue_id": "q0"},
                    {"source_id": "right", "d": 2, "queue_id": "q1"},
                ],
            }
        ],
    },
)


@pytest.mark.parametrize(
    "arrival",
    VALID_COUNT_ARRIVALS,
    ids=lambda item: item["family"],
)
def test_schema4_count_families_round_trip_canonically(
    arrival: dict[str, object],
) -> None:
    config = resolve_config(_base(deepcopy(arrival)))
    canonical = resolved_config_to_dict(config)

    assert canonical["arrival"]["family"] == arrival["family"]
    assert "allowed_edges" not in canonical["arrival"]
    assert "alphabet_constraint" not in canonical["arrival"]
    assert resolved_config_to_dict(resolve_config(canonical)) == canonical


def test_trace_duplicates_aggregate_and_sort_canonically() -> None:
    config = resolve_config(
        _base(
            {
                "family": "deterministic_trace",
                "events": [
                    {"slot": 2, "queue_id": "q1", "count": 1},
                    {"slot": 0, "queue_id": "q0", "count": 2},
                    {"slot": 0, "queue_id": "q0", "count": 3},
                ],
            }
        )
    )

    assert config.arrival.params["events"] == [
        {"slot": 0, "queue_id": "q0", "count": 5},
        {"slot": 2, "queue_id": "q1", "count": 1},
    ]


def test_periodic_duplicates_aggregate_without_reordering_sources() -> None:
    config = resolve_config(
        _base(
            {
                "family": "periodic_source_delays",
                "period": 5,
                "sources": [
                    {
                        "id": "second",
                        "delay": 4,
                        "entries": [
                            {"offset": 3, "queue_id": "q1", "count": 2},
                            {"offset": 3, "queue_id": "q1", "count": 4},
                        ],
                    },
                    {
                        "id": "first",
                        "delay": 0,
                        "entries": [{"offset": 0, "queue_id": "q0", "count": 1}],
                    },
                ],
            }
        )
    )
    sources = config.arrival.params["sources"]

    assert [source["id"] for source in sources] == ["second", "first"]
    assert sources[0]["entries"] == [{"offset": 3, "queue_id": "q1", "count": 6}]


def test_categorical_pmf_order_is_preserved() -> None:
    config = resolve_config(
        _base(
            {
                "family": "independent_marked_renewal",
                "sources": [
                    {
                        "id": "source",
                        "interarrival": {
                            "kind": "finite_pmf",
                            "outcomes": [
                                {"d": 9, "probability": Decimal("0.25")},
                                {"d": 1, "probability": Decimal("0.75")},
                            ],
                        },
                        "destination_pmf": [
                            {"queue_id": "q1", "probability": Decimal("0.4")},
                            {"queue_id": "q0", "probability": Decimal("0.6")},
                        ],
                    }
                ],
            }
        )
    )
    source = config.arrival.params["sources"][0]

    assert [row["d"] for row in source["interarrival"]["outcomes"]] == [9, 1]
    assert [row["queue_id"] for row in source["destination_pmf"]] == ["q1", "q0"]


def test_shared_emissions_follow_declared_source_order() -> None:
    raw = deepcopy(VALID_COUNT_ARRIVALS[-1])
    raw["sources"] = [{"id": "source-b"}, {"id": "source-a"}]
    raw["outcomes"][0]["emissions"] = [
        {"source_id": "source-a", "d": 2, "queue_id": "q1"},
        {"source_id": "source-b", "d": 1, "queue_id": "q0"},
    ]

    config = resolve_config(_base(raw))
    emissions = config.arrival.params["outcomes"][0]["emissions"]

    assert [emission["source_id"] for emission in emissions] == ["source_b", "source_a"]


def test_shared_joint_round_config_runs_end_to_end(tmp_path) -> None:
    result = build_simulation(
        resolve_config(_base(deepcopy(VALID_COUNT_ARRIVALS[-1]))),
        output_dir=tmp_path / "shared",
    ).run()

    assert result.summary.to_dict()["metrics"]["offered_packets"] == 24


def test_queue_native_law_rejects_unknown_queue() -> None:
    arrival = {
        "family": "deterministic_trace",
        "events": [{"slot": 0, "queue_id": "missing", "count": 1}],
    }

    with pytest.raises((ConfigError, ValidationError), match="queue|catalog"):
        resolve_config(_base(arrival))


@pytest.mark.parametrize(
    "interarrival",
    [
        {
            "kind": "finite_pmf",
            "outcomes": [
                {"d": 1, "probability": Decimal("0.5")},
                {"d": 1, "probability": Decimal("0.5")},
            ],
        },
        {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": Decimal(0)},
    ],
)
def test_renewal_rejects_duplicate_gap_atoms_and_improper_geometric_p(
    interarrival: dict[str, object],
) -> None:
    arrival = {
        "family": "independent_marked_renewal",
        "sources": [
            {
                "id": "source",
                "interarrival": interarrival,
                "destination_pmf": [{"queue_id": "q0", "probability": Decimal(1)}],
            }
        ],
    }

    with pytest.raises(ValidationError):
        resolve_config(_base(arrival))


def test_period_phase_and_cycle_offsets_must_be_inside_period() -> None:
    arrival = deepcopy(VALID_COUNT_ARRIVALS[3])
    arrival["phase"] = arrival["period"]
    with pytest.raises(ValidationError):
        resolve_config(_base(arrival))

    arrival = deepcopy(VALID_COUNT_ARRIVALS[3])
    arrival["sources"][0]["entries"][0]["offset"] = arrival["period"]
    with pytest.raises(ValidationError):
        resolve_config(_base(arrival))


def test_queue_ids_keep_integer_and_string_identity_distinct() -> None:
    config = resolve_config(
        _base(
            {
                "family": "deterministic_trace",
                "events": [
                    {"slot": 0, "queue_id": 1, "count": 1},
                    {"slot": 0, "queue_id": "1", "count": 2},
                ],
            },
            queues=[{"id": 1}, {"id": "1"}],
            conflicts=[[1, "1"]],
        )
    )

    assert config.switch.catalog.queue_ids == (1, "1")
    assert [event["queue_id"] for event in config.arrival.params["events"]] == [1, "1"]
