from __future__ import annotations

from fractions import Fraction

from voqsim.analysis import (
    ArrivalMarginal,
    analyze_pooled_target_block,
    iter_pooled_gap_levels,
)
from voqsim.telemetry import (
    MASS_BINARY64_LATTICE,
    CompactObservationReader,
    CompactObservationRecorder,
    ObservationTarget,
    TargetSlotObservation,
    WeightedBoundarySample,
    WeightedTargetSample,
    binary64_lattice_numerator,
)


def _metadata(seed: int) -> dict[str, object]:
    return {
        "actual_seed": seed,
        "scientific_config": {
            "arrival": {"family": "oracle"},
            "scheduler": {"name": "oracle", "tie_policy": "oracle"},
        },
    }


def _write_simulator_oracle(path, *, watermark: int = 65_536, seed: int = 1) -> None:
    # (N, N', D, A, G).  The eight decisions produce the hand oracle in
    # test_v19_step2_analysis while preserving slot-to-slot queue continuity.
    slots = (
        (0, 0, 0, 0, 0),
        (0, 1, 0, 1, 0),
        (1, 1, 0, 0, -2),
        (1, 1, 0, 0, 0),
        (1, 1, 1, 1, 0),
        (1, 2, 1, 2, 1),
        (2, 2, 1, 1, 2),
        (2, 1, 1, 0, 2),
    )
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=len(slots),
        targets=[ObservationTarget("target", "q", gap_mode="exact")],
        metadata=_metadata(seed),
        soft_watermark_rows=watermark,
    )
    for slot, (before, after, served, arrivals, gap) in enumerate(slots):
        recorder.record_slot(
            slot,
            [
                TargetSlotObservation(
                    target_id="target",
                    backlog_before=before,
                    backlog_after=after,
                    served=served,
                    offered=arrivals,
                    admitted=arrivals,
                    dropped=0,
                    gap=gap,
                )
            ],
        )
    recorder.complete()
    recorder.close()


def _weighted_metadata() -> dict[str, object]:
    return {
        "actual_seed": 22,
        "ensemble_id": "oracle",
        "slot_convention": "pre_service_N; service; arrivals; post_arrival_N_prime",
        "initial_condition": "weighted_population_supplied_by_test",
        "random_streams": {"arrival": "seeded external oracle stream"},
        "buffer_policy": {"mode": "NoDrop", "drop_behavior": "fail_on_allocation_error"},
        "weighting": {"mass": "normalized_binary64", "instant": "production_decision"},
        "resampling": {"algorithm": "external_oracle", "instant": "after_transition"},
        "scientific_config": {
            "arrival": {"family": "oracle"},
            "scheduler": {"name": "oracle", "tie_policy": "oracle"},
            "switch": {"kind": "oracle", "queue_capacity": "NoDrop"},
        },
    }


def _weighted_sample(backlog: int, served: int, gap: int) -> WeightedTargetSample:
    return WeightedTargetSample.from_binary64(
        target_id="target",
        backlog=backlog,
        weight=0.5,
        served=served,
        gap=gap,
    )


def _write_weighted_oracle(path) -> None:
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=4,
        targets=[
            ObservationTarget(
                "target",
                "q",
                MASS_BINARY64_LATTICE,
                gap_mode="exact",
            )
        ],
        unit_kind="weighted_ensemble",
        metadata=_weighted_metadata(),
    )
    recorder.record_weighted_boundary(
        0,
        [WeightedBoundarySample.from_binary64(target_id="target", backlog=0, weight=1.0)],
    )
    populations = (
        (_weighted_sample(0, 0, 0), _weighted_sample(0, 0, 0)),
        (_weighted_sample(1, 0, -2), _weighted_sample(1, 0, 0)),
        (_weighted_sample(1, 1, 0), _weighted_sample(1, 1, 1)),
        (_weighted_sample(2, 1, 2), _weighted_sample(2, 1, 2)),
    )
    for slot, samples in enumerate(populations):
        recorder.record_weighted_slot(slot, samples)
    recorder.record_weighted_boundary(
        4,
        [WeightedBoundarySample.from_binary64(target_id="target", backlog=1, weight=1.0)],
    )
    recorder.complete()
    recorder.close()


def _arrival() -> ArrivalMarginal:
    return ArrivalMarginal.from_pmf({0: Fraction(1, 2), 1: Fraction(1, 2)})


def test_streaming_exact_gap_analysis_matches_hand_oracle(tmp_path) -> None:
    path = tmp_path / "sim.sqlite3"
    _write_simulator_oracle(path)
    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=_arrival(),
            stationary_interpretation=True,
        )
        levels = tuple(
            iter_pooled_gap_levels([reader], target_id="target", block_id=0)
        )

    assert report.pooled.gap_mode == "exact"
    assert report.pooled.gap_positive_sum == 5
    assert report.pooled.gap_negative_sum == 2
    assert report.gap_competition.competition_mean == Fraction(5, 8)
    assert report.gap_competition.competition_ratio == Fraction(7, 5)
    assert report.gap_cutoffs[0].gap_association == Fraction(3, 8)
    assert report.gap_cutoffs[0].competition_association == Fraction(-7, 24)
    assert report.stationary_tie.decomposed_mean == 1
    assert [(row.backlog, row.response) for row in levels] == [
        (0, 0),
        (1, Fraction(1, 2)),
        (2, 1),
    ]
    assert levels[1].strict_win_probability == Fraction(1, 4)
    assert levels[1].tied_service_probability == Fraction(1, 4)


def test_weighted_gap_masses_use_the_exact_binary64_lattice(tmp_path) -> None:
    path = tmp_path / "weighted.sqlite3"
    _write_weighted_oracle(path)
    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=_arrival(),
            stationary_interpretation=True,
        )
        levels = tuple(
            iter_pooled_gap_levels([reader], target_id="target", block_id=0)
        )

    unit = binary64_lattice_numerator(1.0)
    half = binary64_lattice_numerator(0.5)
    assert report.pooled.exposure == 4 * unit
    assert report.pooled.gap_positive_sum == 5 * half
    assert report.pooled.gap_negative_sum == 2 * half
    assert report.gap_competition.competition_mean == Fraction(5, 8)
    assert report.gap_cutoffs[0].gap_association == Fraction(3, 8)
    assert report.stationary_tie.strict_loss == Fraction(1, 8)
    assert report.stationary_tie.lost_tie == Fraction(1, 8)
    assert all(row.response_identity_residual == 0 for row in levels)


def test_soft_watermark_does_not_change_gap_science(tmp_path) -> None:
    frequent = tmp_path / "frequent.sqlite3"
    deferred = tmp_path / "deferred.sqlite3"
    _write_simulator_oracle(frequent, watermark=1)
    _write_simulator_oracle(deferred, watermark=10_000)

    with CompactObservationReader(frequent) as first, CompactObservationReader(deferred) as second:
        first_rows = tuple(first.iter_levels())
        second_rows = tuple(second.iter_levels())
    assert first_rows == second_rows


def test_base_only_target_reports_explicit_gap_unavailability(tmp_path) -> None:
    path = tmp_path / "base.sqlite3"
    recorder = CompactObservationRecorder(
        path,
        window_start=0,
        window_stop=1,
        targets=[ObservationTarget("target", "q")],
        metadata=_metadata(7),
    )
    recorder.record_slot(
        0,
        [
            TargetSlotObservation(
                target_id="target",
                backlog_before=1,
                backlog_after=0,
                served=1,
                offered=0,
                admitted=0,
                dropped=0,
            )
        ],
    )
    recorder.complete()
    recorder.close()

    with CompactObservationReader(path) as reader:
        report = analyze_pooled_target_block(
            [reader],
            target_id="target",
            block_id=0,
            cutoffs=[0],
            arrival=ArrivalMarginal.from_pmf({0: 1}),
        )
        rows = tuple(iter_pooled_gap_levels([reader], target_id="target", block_id=0))

    assert report.gap_competition.status == "gap_not_requested"
    assert report.gap_cutoffs[0].status == "gap_not_requested"
    assert report.stationary_tie.status == "gap_not_requested"
    assert rows[0].response == 1
    assert rows[0].status == "gap_not_requested"
