from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path

import pytest

from voqsim.config import load_config, load_raw_config, resolve_config, resolved_config_to_dict
from voqsim.errors import ConfigError, ValidationError
from voqsim.kernel import build_simulation
from voqsim.manifest import build_service_model, hash_resolved_config, hash_service_model
from voqsim.schedulers import (
    CrossbarMaxWeightScheduler,
    IntervalMaxWeightScheduler,
    available_schedulers,
    build_scheduler,
    scheduler_capabilities,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"


def _config_hash(config) -> str:
    return hash_resolved_config(resolved_config_to_dict(config, actual_seed=config.run.seed))


def _service_hash(config) -> str:
    return hash_service_model(build_service_model(config))


def test_patch3_registry_exposes_only_the_new_exact_scheduler_identities() -> None:
    assert isinstance(build_scheduler("crossbar_max_weight"), CrossbarMaxWeightScheduler)
    assert isinstance(
        build_scheduler(
            "interval_max_weight",
            {
                "constraint": {
                    "intervals": [{"queue_id": "q", "left": 0, "right": 1}]
                }
            },
        ),
        IntervalMaxWeightScheduler,
    )
    assert scheduler_capabilities("crossbar_max_weight").to_dict() == {
        "input_kind": "queue_vector",
        "output_kind": "service_decision",
        "service_families": ["crossbar_matching"],
    }
    assert scheduler_capabilities("interval_max_weight").service_families == (
        "nonoverlapping_intervals",
    )
    assert "max_weight" not in available_schedulers(implemented_only=False)
    assert "maxweight" not in available_schedulers(implemented_only=False)


@pytest.mark.parametrize("retired_name", ["max_weight", "maxweight"])
def test_patch3_retired_names_fail_with_explicit_replacement(retired_name: str) -> None:
    with pytest.raises(ConfigError) as caught:
        build_scheduler(retired_name)
    assert caught.value.context == {
        "scheduler": retired_name,
        "replacement": "crossbar_max_weight",
    }


def test_crossbar_constraint_order_is_canonical_and_priority_is_policy_only() -> None:
    raw = deepcopy(
        load_raw_config(CONFIG_DIR / "schema3_sparse_rectangular_crossbar_max_weight.yaml")
    )
    reordered = deepcopy(raw)
    constraint = reordered["scheduler"]["params"]["constraint"]
    constraint["inputs"].reverse()
    constraint["outputs"].reverse()
    constraint["edges"].reverse()

    first = resolve_config(raw)
    second = resolve_config(reordered)
    assert resolved_config_to_dict(first) == resolved_config_to_dict(second)
    assert _config_hash(first) == _config_hash(second)
    assert _service_hash(first) == _service_hash(second)

    different_priority = deepcopy(raw)
    different_priority["scheduler"]["params"]["priority"].reverse()
    policy_variant = resolve_config(different_priority)
    assert _config_hash(first) != _config_hash(policy_variant)
    assert _service_hash(first) == _service_hash(policy_variant)

    different_constraint = deepcopy(raw)
    different_constraint["scheduler"]["params"]["constraint"]["inputs"].append("isolated")
    physical_variant = resolve_config(different_constraint)
    assert _service_hash(first) != _service_hash(physical_variant)


def test_interval_constraint_order_is_canonical_and_priority_does_not_change_service_hash() -> None:
    raw = deepcopy(load_raw_config(CONFIG_DIR / "schema3_interval_max_weight.yaml"))
    reordered = deepcopy(raw)
    reordered["scheduler"]["params"]["constraint"]["intervals"].reverse()
    different_priority = deepcopy(raw)
    different_priority["scheduler"]["params"]["priority"].reverse()

    first = resolve_config(raw)
    second = resolve_config(reordered)
    policy_variant = resolve_config(different_priority)
    assert resolved_config_to_dict(first) == resolved_config_to_dict(second)
    assert _service_hash(first) == _service_hash(second) == _service_hash(policy_variant)
    assert _config_hash(first) != _config_hash(policy_variant)


def test_canonical_crossbar_uses_and_requires_an_explicit_constraint(tmp_path: Path) -> None:
    raw = deepcopy(load_raw_config(CONFIG_DIR / "4x4_iid_table_crossbar_max_weight_exact.yaml"))
    config = resolve_config(raw)
    assert set(config.scheduler.params) == {"constraint", "priority"}
    service = build_service_model(config)["service"]
    assert service["family"] == "crossbar_matching"
    assert service["constraint"] == config.scheduler.params["constraint"]

    raw["scheduler"]["params"].pop("constraint")
    with pytest.raises(ValidationError, match="constraint"):
        build_simulation(raw, output_dir=tmp_path / "invalid")
    assert not (tmp_path / "invalid").exists()


@pytest.mark.parametrize(
    ("filename", "scheduler_id", "optimizer_id"),
    [
        ("schema3_sparse_rectangular_crossbar_max_weight.yaml", "crossbar_max_weight", "hungarian_exact"),
        ("schema3_interval_max_weight.yaml", "interval_max_weight", "weighted_interval_dp_exact"),
    ],
)
def test_generalized_patch3_examples_run_end_to_end_with_generic_telemetry(
    tmp_path: Path,
    filename: str,
    scheduler_id: str,
    optimizer_id: str,
) -> None:
    config = load_config(CONFIG_DIR / filename)
    result = build_simulation(config, output_dir=tmp_path / scheduler_id).run()
    records = [json.loads(line) for line in result.telemetry_path.read_text().splitlines()]
    assert result.slots_run == config.run.slots
    assert {record["schedule"]["scheduler_id"] for record in records} == {scheduler_id}
    assert {record["schedule"]["optimizer_id"] for record in records} == {optimizer_id}
