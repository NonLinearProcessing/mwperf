from __future__ import annotations

from copy import deepcopy
import itertools
import json
from pathlib import Path
import random

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.errors import ScheduleError, ValidationError
from voqsim.kernel import build_simulation
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.exact_priority import exact_lex_weights
from voqsim.schedulers.node_exclusive_max_weight import NodeExclusiveMaxWeightScheduler


Vertex = int | str
QueueId = int | str
Link = tuple[QueueId, Vertex, Vertex]


def _constraint(vertices: tuple[Vertex, ...] | list[Vertex], links: tuple[Link, ...] | list[Link]):
    return {
        "vertices": list(vertices),
        "links": [
            {"queue_id": queue_id, "u": u, "v": v}
            for queue_id, u, v in links
        ],
    }


def _build(
    vertices: tuple[Vertex, ...] | list[Vertex],
    links: tuple[Link, ...] | list[Link],
    *,
    catalog_ids: tuple[QueueId, ...] | list[QueueId] | None = None,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
) -> tuple[NodeExclusiveMaxWeightScheduler, QueueCatalog]:
    if catalog_ids is None:
        catalog_ids = [queue_id for queue_id, _u, _v in links]
    catalog = QueueCatalog(catalog_ids)
    params: dict[str, object] = {"constraint": _constraint(vertices, links)}
    if priority is not None:
        params["priority"] = list(priority)
    scheduler = NodeExclusiveMaxWeightScheduler(params)
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="node_exclusive_matching")
    )
    return scheduler, catalog


def _oracle_indices(
    links: tuple[Link, ...] | list[Link],
    q_len: tuple[int, ...] | list[int],
    catalog: QueueCatalog,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
) -> frozenset[int]:
    """Independent subset oracle: maximize Q.s, then priority membership bits."""

    if priority is None:
        priority = catalog.queue_ids
    priority_indices = tuple(catalog.index_of(queue_id) for queue_id in priority)
    link_by_index = {
        catalog.index_of(queue_id): (u, v)
        for queue_id, u, v in links
    }
    best = frozenset()
    best_key: tuple[int, tuple[int, ...]] = (-1, ())
    for bits in itertools.product((0, 1), repeat=catalog.n_queues):
        selected = frozenset(index for index, bit in enumerate(bits) if bit)
        if any(q_len[index] <= 0 for index in selected):
            continue
        endpoints = [endpoint for index in selected for endpoint in link_by_index[index]]
        if len(endpoints) != len(set(endpoints)):
            continue
        key = (
            sum(q_len[index] for index in selected),
            tuple(int(index in selected) for index in priority_indices),
        )
        if key > best_key:
            best_key = key
            best = selected
    return best


def _oracle_decision(
    links: tuple[Link, ...] | list[Link],
    q_len: tuple[int, ...] | list[int],
    catalog: QueueCatalog,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
) -> ServiceDecision:
    selected = _oracle_indices(links, q_len, catalog, priority)
    return ServiceDecision(
        tuple(
            queue_id
            for index, queue_id in enumerate(catalog.queue_ids)
            if index in selected
        )
    )


def _select(
    scheduler: NodeExclusiveMaxWeightScheduler,
    q_len: tuple[int, ...] | list[int] | np.ndarray,
    *,
    slot: int = 0,
    seed: int = 12345,
) -> ServiceDecision:
    return scheduler.select_service(
        np.asarray(q_len, dtype=np.int64),
        slot,
        np.random.default_rng(seed),
    )


def _unchecked_duplicate_decision(queue_id: QueueId) -> ServiceDecision:
    decision = object.__new__(ServiceDecision)
    object.__setattr__(decision, "selected_queue_ids", (queue_id, queue_id))
    return decision


def test_triangle_finds_the_exact_optional_matching() -> None:
    links: tuple[Link, ...] = (
        ("ab", "a", "b"),
        ("bc", "b", "c"),
        ("ca", "c", "a"),
    )
    scheduler, catalog = _build(("a", "b", "c"), links)

    actual = _select(scheduler, (7, 11, 9))

    assert actual == ServiceDecision(("bc",))
    assert actual == _oracle_decision(links, (7, 11, 9), catalog)
    assert scheduler.optimizer_id == "edmonds_blossom_exact"
    assert scheduler.service_family == "node_exclusive_matching"


@pytest.mark.parametrize(
    ("cycle_size", "q_len"),
    [
        (5, (8, 7, 11, 2, 10)),
        (7, (3, 13, 8, 9, 6, 12, 7)),
    ],
)
def test_odd_cycles_match_exhaustive_optima(
    cycle_size: int,
    q_len: tuple[int, ...],
) -> None:
    vertices = tuple(f"v{index}" for index in range(cycle_size))
    links: tuple[Link, ...] = tuple(
        (f"e{index}", vertices[index], vertices[(index + 1) % cycle_size])
        for index in range(cycle_size)
    )
    priority = tuple(reversed(tuple(queue_id for queue_id, _u, _v in links)))
    scheduler, catalog = _build(vertices, links, priority=priority)

    assert _select(scheduler, q_len) == _oracle_decision(
        links, q_len, catalog, priority
    )


def test_disconnected_components_and_isolated_vertex_are_handled() -> None:
    vertices: tuple[Vertex, ...] = ("a", "b", "c", "d", "e", "f", "isolated")
    links: tuple[Link, ...] = (
        ("ab", "a", "b"),
        ("bc", "b", "c"),
        ("de", "d", "e"),
        ("ef", "e", "f"),
    )
    scheduler, _catalog = _build(vertices, links)

    # Leaves c, f, and the explicitly declared isolated vertex unmatched.
    assert _select(scheduler, (8, 7, 6, 5)) == ServiceDecision(("ab", "de"))


def test_optional_matching_maximizes_weight_not_cardinality() -> None:
    links: tuple[Link, ...] = (
        ("heavy", 1, 2),
        ("left", 0, 1),
        ("right", 2, 3),
    )
    scheduler, _catalog = _build((0, 1, 2, 3), links)

    # The two-edge matching weighs 9, while the single middle edge weighs 10.
    assert _select(scheduler, (10, 6, 3)) == ServiceDecision(("heavy",))


def test_parallel_labels_and_reversed_endpoints_reduce_to_exact_best_label() -> None:
    links: tuple[Link, ...] = (
        ("parallel-low", "u", "v"),
        ("parallel-high", "v", "u"),
        (7, "u", "v"),
        ("disjoint", "x", "y"),
    )
    priority: tuple[QueueId, ...] = (7, "parallel-low", "parallel-high", "disjoint")
    scheduler, catalog = _build(
        ("u", "v", "x", "y"),
        links,
        priority=priority,
    )

    assert _select(scheduler, (8, 13, 12, 4)) == ServiceDecision(
        ("parallel-high", "disjoint")
    )
    assert _select(scheduler, (12, 12, 12, 4)) == ServiceDecision(
        (7, "disjoint")
    )
    assert _select(scheduler, (12, 12, 12, 4)) == _oracle_decision(
        links, (12, 12, 12, 4), catalog, priority
    )


def test_mixed_integer_and_string_vertex_and_queue_ids_are_distinct() -> None:
    vertices: tuple[Vertex, ...] = (0, 1, "0", "1", "spare")
    links: tuple[Link, ...] = (
        (0, 0, "0"),
        ("zero", 1, "1"),
        (2, "0", "1"),
    )
    scheduler, _catalog = _build(vertices, links, priority=("zero", 0, 2))

    assert _select(scheduler, (4, 4, 7)) == ServiceDecision((0, "zero"))


def test_parallel_representative_uses_arbitrary_precision_composite_weights() -> None:
    queue_count = 70
    queue_ids = tuple(f"q{index:02d}" for index in range(queue_count))
    links: tuple[Link, ...] = tuple(
        (queue_id, "left", "right") if index % 2 == 0
        else (queue_id, "right", "left")
        for index, queue_id in enumerate(queue_ids)
    )
    priority = tuple(reversed(queue_ids))
    scheduler, catalog = _build(("left", "right"), links, priority=priority)
    q_len = np.ones(queue_count, dtype=np.int64)

    assert max(exact_lex_weights(q_len, catalog, priority)) > np.iinfo(np.int64).max
    assert _select(scheduler, q_len) == ServiceDecision((priority[0],))


def test_all_empty_and_nonempty_selection_consume_no_rng_draws() -> None:
    links: tuple[Link, ...] = (("a", 0, 1), ("b", 1, 2), ("c", 2, 3))
    scheduler, _catalog = _build((0, 1, 2, 3), links)
    rng = np.random.default_rng(441)
    before_empty = deepcopy(rng.bit_generator.state)

    assert scheduler.select_service([0, 0, 0], 0, rng) == ServiceDecision.empty()
    assert rng.bit_generator.state == before_empty

    before_nonempty = deepcopy(rng.bit_generator.state)
    scheduler.select_service([3, 9, 4], 1, rng)
    assert rng.bit_generator.state == before_nonempty


@pytest.mark.parametrize("seed", range(100))
def test_public_scheduler_equals_independent_exhaustive_oracle(seed: int) -> None:
    source = random.Random(40_000 + seed)
    vertex_count = source.randint(2, 7)
    raw_vertices: tuple[Vertex, ...] = tuple(
        index if index % 2 == 0 else f"v{index}"
        for index in range(vertex_count)
    )
    queue_count = source.randint(1, min(9, vertex_count * (vertex_count - 1)))

    links_list: list[Link] = []
    for index in range(queue_count):
        u_index, v_index = source.sample(range(vertex_count), 2)
        u, v = raw_vertices[u_index], raw_vertices[v_index]
        if source.random() < 0.5:
            u, v = v, u
        queue_id: QueueId = index if index % 2 == 0 else f"q{index}"
        links_list.append((queue_id, u, v))
    links = tuple(links_list)
    catalog_ids = tuple(queue_id for queue_id, _u, _v in links)
    priority_list = list(catalog_ids)
    source.shuffle(priority_list)
    priority = tuple(priority_list)
    q_len = tuple(source.randrange(0, 31) for _ in links)
    scheduler, catalog = _build(raw_vertices, links, priority=priority)

    actual = scheduler.select_service(q_len, seed, np.random.default_rng(seed))
    expected = _oracle_decision(links, q_len, catalog, priority)

    assert actual == expected


def test_constraint_canonicalization_is_order_and_orientation_invariant() -> None:
    links: tuple[Link, ...] = (
        (9, "z", 0),
        ("a", 4, "x"),
        ("parallel", 0, "z"),
    )
    first = NodeExclusiveMaxWeightScheduler(
        {
            "constraint": _constraint(("z", 4, "x", 0), links),
            "priority": ["parallel", 9, "a"],
        }
    )
    second = NodeExclusiveMaxWeightScheduler(
        {
            "priority": ("parallel", 9, "a"),
            "constraint": _constraint(
                (0, "x", 4, "z"),
                tuple(
                    (queue_id, v, u)
                    for queue_id, u, v in reversed(links)
                ),
            ),
        }
    )

    assert first.effective_params == second.effective_params


@pytest.mark.parametrize(
    "params",
    [
        {},
        {"constraint": {}},
        {"constraint": {"vertices": [0, 1]}},
        {"constraint": {"links": [{"queue_id": "q", "u": 0, "v": 1}]}},
        {"constraint": {"vertices": [0, 1], "links": [], "extra": 1}},
        {"constraint": {"vertices": [], "links": [{"queue_id": "q", "u": 0, "v": 1}]}},
        {"constraint": {"vertices": [0, 1], "links": []}},
        {"constraint": {"vertices": "01", "links": [{"queue_id": "q", "u": 0, "v": 1}]}},
        {"constraint": {"vertices": [0, 1], "links": "q"}},
        {"constraint": {"vertices": [0, 1], "links": [7]}},
        {"constraint": _constraint((0, 0), (("q", 0, 0),))},
        {"constraint": _constraint((True, 1), (("q", True, 1),))},
        {"constraint": _constraint((-1, 1), (("q", -1, 1),))},
        {"constraint": _constraint(("", "v"), (("q", "", "v"),))},
        {"constraint": _constraint((" padded ", "v"), (("q", " padded ", "v"),))},
        {
            "constraint": {
                "vertices": [0, 1],
                "links": [{"queue_id": "q", "u": 0}],
            }
        },
        {
            "constraint": {
                "vertices": [0, 1],
                "links": [{"queue_id": "q", "u": 0, "v": 1, "extra": 2}],
            }
        },
        {"constraint": _constraint((0, 1), (("q", 0, 2),))},
        {"constraint": _constraint((0, 1), (("q", 0, 0),))},
        {"constraint": _constraint((0, 1, 2), (("q", 0, 1), ("q", 1, 2)))},
        {"constraint": _constraint((0, 1), ((True, 0, 1),))},
        {"constraint": _constraint((0, 1), (("q", 0, 1),)), "unknown": 1},
    ],
)
def test_malformed_node_exclusive_constraints_fail_strictly(params: dict[str, object]) -> None:
    with pytest.raises(ValidationError):
        NodeExclusiveMaxWeightScheduler(params)


@pytest.mark.parametrize(
    ("catalog_ids", "links"),
    [
        (("a", "b"), (("a", 0, 1),)),
        (("a",), (("a", 0, 1), ("outside", 1, 2))),
    ],
)
def test_constraint_must_cover_the_queue_catalog_exactly_and_bind_transactionally(
    catalog_ids: tuple[QueueId, ...],
    links: tuple[Link, ...],
) -> None:
    scheduler = NodeExclusiveMaxWeightScheduler(
        {"constraint": _constraint((0, 1, 2), links)}
    )

    with pytest.raises(ValidationError):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(
                QueueCatalog(catalog_ids),
                service_family="node_exclusive_matching",
            )
        )
    assert scheduler.scheduler_domain is None


def test_duplicate_queue_catalog_is_rejected_before_scheduler_binding() -> None:
    with pytest.raises(ValidationError):
        QueueCatalog(("same", "same"))


@pytest.mark.parametrize(
    "priority",
    [
        [],
        ["a"],
        ["a", "a"],
        ["a", "outside"],
    ],
)
def test_priority_must_be_an_exact_catalog_permutation(priority: list[QueueId]) -> None:
    with pytest.raises(ValidationError):
        scheduler = NodeExclusiveMaxWeightScheduler(
            {
                "constraint": _constraint((0, 1, 2), (("a", 0, 1), ("b", 1, 2))),
                "priority": priority,
            }
        )
        scheduler.configure_for_domain(
            QueueSchedulerDomain(
                QueueCatalog(("a", "b")),
                service_family="node_exclusive_matching",
            )
        )


def test_wrong_service_family_is_rejected_transactionally() -> None:
    scheduler = NodeExclusiveMaxWeightScheduler(
        {"constraint": _constraint((0, 1), (("q", 0, 1),))}
    )

    with pytest.raises(ValidationError):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(QueueCatalog(("q",)), "crossbar_matching")
        )
    assert scheduler.scheduler_domain is None


def test_selection_requires_binding_and_well_formed_inputs() -> None:
    scheduler = NodeExclusiveMaxWeightScheduler(
        {"constraint": _constraint((0, 1), (("q", 0, 1),))}
    )
    with pytest.raises(ValidationError):
        scheduler.select_service([1], 0, np.random.default_rng(1))

    scheduler.configure_for_domain(
        QueueSchedulerDomain(QueueCatalog(("q",)), "node_exclusive_matching")
    )
    for bad_q_len in ([[1]], [1, 2], [-1], [0.5]):
        with pytest.raises(ValidationError):
            scheduler.select_service(bad_q_len, 0, np.random.default_rng(1))


def test_public_decision_validator_accepts_disjoint_links_and_rejects_node_conflicts() -> None:
    links: tuple[Link, ...] = (
        ("ab", "a", "b"),
        ("bc", "b", "c"),
        ("de", "d", "e"),
    )
    scheduler, _catalog = _build(("a", "b", "c", "d", "e"), links)

    assert scheduler.validate_service_decision(
        ServiceDecision(("de", "ab")), [2, 3, 4]
    ) == ServiceDecision(("ab", "de"))
    with pytest.raises(ScheduleError):
        scheduler.validate_service_decision(ServiceDecision(("ab", "bc")), [2, 3, 4])


def test_public_decision_validator_rejects_parallel_labels_together() -> None:
    links: tuple[Link, ...] = (
        ("forward", 0, 1),
        ("reverse", 1, 0),
    )
    scheduler, _catalog = _build((0, 1), links)

    with pytest.raises(ScheduleError):
        scheduler.validate_service_decision(
            ServiceDecision(("forward", "reverse")), [1, 1]
        )


@pytest.mark.parametrize(
    "decision",
    [
        ("a",),
        ServiceDecision(("outside",)),
        ServiceDecision(("b",)),
        _unchecked_duplicate_decision("a"),
    ],
)
def test_public_decision_validator_rejects_malformed_identity_or_occupancy(
    decision: object,
) -> None:
    scheduler, _catalog = _build((0, 1, 2), (("a", 0, 1), ("b", 1, 2)))

    with pytest.raises(ScheduleError):
        scheduler.validate_service_decision(decision, [1, 0])


def test_node_exclusive_schedule_illegal_as_crossbar_matching_runs_end_to_end(
    tmp_path: Path,
) -> None:
    # The node-exclusive links are disjoint. The generalized kernel must apply
    # the active domain's validator and complete both packets together.
    config = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 174004, "slots": 2, "termination": "fixed_slots"},
        "switch": {
            "kind": "generalized",
            "queue_capacity": 4,
            "queues": [
                {"id": "left"},
                {"id": "right"},
            ],
        },
        "scheduler": {
            "name": "node_exclusive_max_weight",
            "params": {
                "constraint": {
                    "vertices": ["a", "b", "c", "d"],
                    "links": [
                        {"queue_id": "left", "u": "a", "v": "b"},
                        {"queue_id": "right", "u": "c", "v": "d"},
                    ],
                },
                "priority": ["left", "right"],
            },
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [
                {"slot": 0, "queue_id": "left", "count": 1},
                {"slot": 0, "queue_id": "right", "count": 1},
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "include_scheduler_state": False,
            "write_slot_trace": True,
        },
    }

    simulator = build_simulation(config, output_dir=tmp_path / "node-exclusive")
    result = simulator.run()
    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]

    assert result.summary.to_dict()["metrics"]["completed_packets"] == 2
    assert records[1]["schedule"] == {
        "format": "selected_queue_ids",
        "selected_queue_ids": ["left", "right"],
        "scheduler_id": "node_exclusive_max_weight",
        "algorithm_id": "edmonds_blossom_exact",
        "optimizer_id": "edmonds_blossom_exact",
    }
    assert [departure["queue_id"] for departure in records[1]["departures"]] == [
        "left",
        "right",
    ]
