from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest

import voqsim.kernel as kernel_module
from voqsim.batch import BatchPreparedRun, run_one_prepared
from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY
from voqsim.config import load_raw_config, resolve_config
from voqsim.errors import ValidationError
from voqsim.kernel import build_simulation
from voqsim.telemetry import CompactObservationReader, STATUS_COMPLETE, STATUS_FAILED


def _config(*, observations: bool, slots: int = 6, warmup: int = 2) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 18021,
            "slots": slots,
            "warmup_slots": warmup,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": ["q"],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {"constraint": {"conflicts": []}, "priority": ["q"]},
        },
        "arrival": {
            "family": "deterministic_trace",
            "events": [
                {"slot": 0, "queue_id": "q", "count": 2},
                {"slot": 2, "queue_id": "q", "count": 1},
                {"slot": 4, "queue_id": "q", "count": 2},
            ],
        },
        "telemetry": {
            "write_slot_trace": False,
            "observation": {
                "enabled": observations,
                "block_slots": 2,
                "targets": [{"queue_id": "q", "gap": "none"}],
            },
        },
    }


def _assert_observation_failed(simulator) -> None:
    assert simulator.observation_path is not None
    with pytest.raises(ValidationError, match="not complete"):
        CompactObservationReader(simulator.observation_path)
    with CompactObservationReader(simulator.observation_path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED


def test_enabled_observations_are_complete_reported_and_independent_of_raw_trace(tmp_path) -> None:
    simulator = build_simulation(_config(observations=True), output_dir=tmp_path / "run")
    result = simulator.run()

    assert result.telemetry_path is None
    assert result.observation_path is not None
    assert result.observation_path.read_bytes().startswith(b"SQLite format 3\x00")
    descriptor = result.to_dict()
    assert descriptor["compact_observations_written"] is True
    assert descriptor["observation_path"] == str(result.observation_path)

    summary = result.summary.to_dict()
    assert summary["metrics"]["slots_observed"] == 4
    assert summary["metrics"]["dropped_packets"] == 0
    assert summary["metadata"]["buffer_mode"] == NO_DROP_CAPACITY
    assert summary["metadata"]["buffer_capacity_packets"] is None
    assert summary["metadata"]["capacity_utilization_defined"] is False
    assert summary["metadata"]["post_run_final_occupancy_packets"] == 1

    with CompactObservationReader(result.observation_path) as reader:
        assert reader.state.status == STATUS_COMPLETE
        assert reader.state.window_start == 2
        assert reader.state.window_stop == 6
        assert reader.state.metadata["initial_condition"] == "empty_queues"
        assert reader.state.metadata["scientific_config"]["switch"]["queue_capacity"] == NO_DROP_CAPACITY
        assert [
            (row.block_id, row.backlog, row.exposure, row.served)
            for row in reader.iter_levels()
        ] == [
            (0, 1, 2, 2),
            (1, 0, 1, 0),
            (1, 2, 1, 1),
        ]
        assert [
            (row.block_id, row.side, row.backlog, row.mass)
            for row in reader.iter_boundaries()
        ] == [
            (0, "end", 0, 1),
            (0, "start", 1, 1),
            (1, "end", 1, 1),
            (1, "start", 0, 1),
        ]
        blocks = tuple(reader.iter_target_blocks())
        assert [(row.offered, row.offered_square, row.dropped) for row in blocks] == [
            (1, 1, 0),
            (2, 4, 0),
        ]
        reader.integrity_check()


def test_observation_toggle_does_not_change_simulator_dynamics(tmp_path) -> None:
    observed_simulator = build_simulation(
        _config(observations=True),
        output_dir=tmp_path / "observed",
    )
    plain_config = deepcopy(_config(observations=False))
    plain_config["telemetry"]["observation"]["targets"] = []  # type: ignore[index]
    plain_simulator = build_simulation(plain_config, output_dir=tmp_path / "plain")

    observed = observed_simulator.run()
    plain = plain_simulator.run()

    assert observed.actual_seed == plain.actual_seed
    assert observed.summary.metrics == plain.summary.metrics
    assert observed.measurement_start_queue_lengths == plain.measurement_start_queue_lengths
    assert observed.measurement_end_queue_lengths == plain.measurement_end_queue_lengths
    assert observed_simulator.switch.queue_lengths().tolist() == plain_simulator.switch.queue_lengths().tolist()


def test_observer_failure_marks_exact_prefix_non_poolable(tmp_path) -> None:
    simulator = build_simulation(_config(observations=True), output_dir=tmp_path / "failed")

    def fail_after_storage(_commit) -> None:
        raise RuntimeError("injected observer failure")

    with pytest.raises(RuntimeError, match="injected observer failure"):
        simulator.run(observers=fail_after_storage)

    assert simulator.observation_path is not None
    with pytest.raises(ValidationError, match="not complete"):
        CompactObservationReader(simulator.observation_path)
    with CompactObservationReader(simulator.observation_path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED
        assert tuple(reader.iter_levels())


def test_trace_close_failure_cannot_leave_observation_complete(tmp_path, monkeypatch) -> None:
    config = _config(observations=True)
    config["telemetry"]["write_slot_trace"] = True  # type: ignore[index]
    simulator = build_simulation(config, output_dir=tmp_path / "trace-close-failure")
    original_close = kernel_module.JsonlWriter.close

    def fail_after_close(writer) -> None:
        original_close(writer)
        raise OSError("injected trace close failure")

    monkeypatch.setattr(kernel_module.JsonlWriter, "close", fail_after_close)

    with pytest.raises(OSError, match="injected trace close failure"):
        simulator.run()

    _assert_observation_failed(simulator)


def test_terminal_invariant_failure_cannot_leave_observation_complete(tmp_path, monkeypatch) -> None:
    simulator = build_simulation(_config(observations=True), output_dir=tmp_path / "invariant-failure")
    original_record = kernel_module.Simulator._record_measurement_commit

    def inject_impossible_drop(self, commit, *, telemetry_writer, stats, observers) -> None:
        original_record(
            self,
            commit,
            telemetry_writer=telemetry_writer,
            stats=stats,
            observers=observers,
        )
        stats.dropped_packets += 1

    monkeypatch.setattr(kernel_module.Simulator, "_record_measurement_commit", inject_impossible_drop)

    with pytest.raises(ValidationError, match="successful NoDrop"):
        simulator.run()

    _assert_observation_failed(simulator)


def test_summary_publication_failure_cannot_leave_observation_complete(tmp_path, monkeypatch) -> None:
    simulator = build_simulation(_config(observations=True), output_dir=tmp_path / "summary-failure")

    def fail_summary_write(_writer, _summary) -> None:
        raise OSError("injected summary publication failure")

    monkeypatch.setattr(kernel_module.SummaryWriter, "write", fail_summary_write)

    with pytest.raises(OSError, match="injected summary publication failure"):
        simulator.run()

    _assert_observation_failed(simulator)


def test_every_distinct_visited_level_is_retained_without_a_size_gate(tmp_path) -> None:
    slots = 200
    config = _config(observations=True, slots=slots, warmup=0)
    config["telemetry"]["observation"]["block_slots"] = None  # type: ignore[index]
    config["arrival"] = {
        "family": "deterministic_trace",
        "events": [
            {"slot": slot, "queue_id": "q", "count": 2}
            for slot in range(slots)
        ],
    }
    result = build_simulation(config, output_dir=tmp_path / "levels").run()

    assert result.observation_path is not None
    with CompactObservationReader(result.observation_path) as reader:
        rows = tuple(reader.iter_levels())
        assert len(rows) == slots
        assert [row.backlog for row in rows] == [0, *range(2, slots + 1)]
        assert sum(row.exposure for row in rows) == slots


@pytest.mark.parametrize(
    "config_name,target",
    [
        ("4x4_iid_table_crossbar_max_weight_exact.yaml", "voq[0,1]"),
        ("schema3_interval_max_weight.yaml", "wide"),
        ("schema3_node_exclusive_max_weight.yaml", "ab-heavy"),
        ("schema3_conflict_graph_max_weight.yaml", "red"),
        ("schema3_resource_packing_max_weight.yaml", "bridge"),
    ],
)
def test_common_observation_path_covers_all_five_optimizer_families(
    config_name: str,
    target: str,
    tmp_path,
) -> None:
    config_path = Path(__file__).resolve().parents[1] / "configs" / config_name
    raw = deepcopy(load_raw_config(config_path))
    raw["telemetry"] = {
        **raw.get("telemetry", {}),
        "write_slot_trace": False,
        "observation": {
            "enabled": True,
            "block_slots": None,
            "targets": [{"queue_id": target, "gap": "none"}],
        },
    }
    result = build_simulation(raw, output_dir=tmp_path / config_path.stem).run()

    assert result.observation_path is not None
    with CompactObservationReader(result.observation_path) as reader:
        assert sum(row.exposure for row in reader.iter_levels()) == (
            raw["run"]["slots"] - raw["run"].get("warmup_slots", 0)
        )


def test_batch_result_reports_compact_observation_artifact(tmp_path) -> None:
    prepared = BatchPreparedRun(
        config_path=tmp_path / "config.yaml",
        relative_path=Path("config.yaml"),
        resolved_config=resolve_config(_config(observations=True)),
        output_dir=tmp_path / "run",
    )

    result = run_one_prepared(prepared)

    assert result.succeeded
    assert result.observation_path is not None
    assert result.to_dict()["observation_path"] == str(result.observation_path)
