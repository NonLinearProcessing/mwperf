from __future__ import annotations

import pytest

from voqsim.errors import ValidationError
from voqsim.events import (
    ADMISSION_REASON_BUFFER_FULL,
    ADMISSION_REASON_ENQUEUED,
    AdmissionDecision,
    ArrivalAttempt,
    CompletionEvent,
    DepartureEvent,
    event_to_dict,
)
from voqsim.flows import FlowPlan, FlowSpec, flow_spec_to_dict, flow_specs_to_list
from voqsim.packet import Packet, packet_to_dict
from voqsim.utils import canonicalize_admission_decisions, canonicalize_arrival_attempts


def test_packet_transitions_are_immutable_and_compute_timings() -> None:
    packet = Packet(packet_id=7, flow_id=3, src_port=1, dst_port=2, generation_slot=11)

    assert packet.voq_key == (1, 2)
    assert packet.is_enqueued is False
    assert packet.is_completed is False
    assert packet.sojourn_slots is None
    assert packet.residence_slots is None

    enqueued = packet.mark_enqueued(11)
    completed = enqueued.mark_completed(13)

    assert packet.enqueue_slot is None
    assert enqueued.enqueue_slot == 11
    assert completed.completion_slot == 13
    assert completed.sojourn_slots == 2
    assert completed.residence_slots == 2
    assert enqueued.mark_enqueued(11) is enqueued
    assert completed.mark_completed(13) is completed



def test_packet_alias_methods_and_serialization_work() -> None:
    packet = Packet(packet_id=9, flow_id=4, src_port=0, dst_port=3, generation_slot=8)
    completed = packet.with_enqueue_slot(8).with_completion_slot(10)

    payload = packet_to_dict(completed)
    assert payload["enqueue_slot"] == 8
    assert payload["completion_slot"] == 10
    assert payload["sojourn_slots"] == 2
    assert payload["residence_slots"] == 2


@pytest.mark.parametrize(
    "kwargs",
    [
        {
            "packet_id": 1,
            "flow_id": 0,
            "src_port": 0,
            "dst_port": 1,
            "generation_slot": 5,
            "enqueue_slot": 4,
        },
        {
            "packet_id": 1,
            "flow_id": 0,
            "src_port": 0,
            "dst_port": 1,
            "generation_slot": 5,
            "enqueue_slot": 5,
            "completion_slot": 5,
        },
        {
            "packet_id": 1,
            "flow_id": 0,
            "src_port": 0,
            "dst_port": 1,
            "generation_slot": 5,
            "completion_slot": 7,
        },
    ],
)
def test_packet_rejects_invalid_temporal_state(kwargs: dict[str, int]) -> None:
    with pytest.raises(ValidationError):
        Packet(**kwargs)



def test_packet_mark_completed_rejects_same_slot_as_enqueue() -> None:
    packet = Packet(packet_id=1, flow_id=0, src_port=0, dst_port=1, generation_slot=5).mark_enqueued(5)
    with pytest.raises(ValidationError):
        packet.mark_completed(5)



def test_flow_spec_is_static_identity_descriptor_and_normalizes_metadata() -> None:
    flow = FlowSpec(
        flow_id=9,
        src_port=2,
        dst_port=3,
        metadata={"label": "alpha", "tags": {"x", "y"}},
    )

    assert flow.voq_key == (2, 3)
    assert sorted(flow.metadata["tags"]) == ["x", "y"]
    assert flow.to_dict() == {
        "flow_id": 9,
        "src_port": 2,
        "dst_port": 3,
        "metadata": {"label": "alpha", "tags": ["x", "y"]},
    }



def test_flow_spec_rejects_invalid_identity_fields() -> None:
    with pytest.raises(ValidationError):
        FlowSpec(flow_id=-1, src_port=0, dst_port=1)

    with pytest.raises(ValidationError):
        FlowSpec(flow_id=1, src_port=0, dst_port=1, metadata={1: "bad"})



def test_flow_plan_rejects_duplicate_voq_assignments_and_exposes_plan_fields() -> None:
    flow_a = FlowSpec(flow_id=0, src_port=0, dst_port=1)
    flow_b = FlowSpec(flow_id=1, src_port=1, dst_port=0)
    plan = FlowPlan(flows=(flow_a, flow_b), metadata={"checkpoint": "v3.5"})

    assert len(plan) == 2
    assert tuple(plan) == (flow_a, flow_b)
    assert plan.flow_ids == (0, 1)
    assert plan.voq_keys == ((0, 1), (1, 0))
    assert plan.to_dict()["metadata"] == {"checkpoint": "v3.5"}

    with pytest.raises(ValidationError):
        FlowPlan(flows=(flow_a, FlowSpec(flow_id=2, src_port=0, dst_port=1)))



def test_flow_spec_to_dict_and_flow_specs_to_list_are_stable() -> None:
    flow_a = FlowSpec(flow_id=2, src_port=1, dst_port=0)
    flow_b = FlowSpec(flow_id=1, src_port=0, dst_port=2)

    assert flow_spec_to_dict(flow_a)["flow_id"] == 2
    assert flow_spec_to_dict({"k": 1, "v": [2, 3]}) == {"k": 1, "v": [2, 3]}
    ordered = flow_specs_to_list([flow_a, flow_b])
    assert [item["flow_id"] for item in ordered] == [1, 2]



def test_arrival_attempt_requires_fresh_packet_and_is_canonicalizable() -> None:
    packet_a = Packet(packet_id=5, flow_id=1, src_port=0, dst_port=2, generation_slot=7)
    packet_b = Packet(packet_id=4, flow_id=1, src_port=0, dst_port=1, generation_slot=7)
    attempt = ArrivalAttempt.from_packet(packet_a)

    assert attempt.slot == 7
    assert attempt.packet_id == 5
    assert attempt.to_dict()["event_type"] == "arrival_attempt"
    assert attempt.to_dict()["enqueue_slot"] is None

    ordered = canonicalize_arrival_attempts([ArrivalAttempt.from_packet(packet_a), ArrivalAttempt.from_packet(packet_b)])
    assert tuple(item.packet_id for item in ordered) == (4, 5)

    with pytest.raises(ValidationError):
        ArrivalAttempt.from_packet(packet_a.mark_enqueued(7))



def test_canonicalize_arrival_and_admission_order_handles_two_digit_ports_numerically() -> None:
    packet_a = Packet(packet_id=21, flow_id=1, src_port=10, dst_port=11, generation_slot=5)
    packet_b = Packet(packet_id=22, flow_id=1, src_port=4, dst_port=5, generation_slot=5)

    ordered_attempts = canonicalize_arrival_attempts([ArrivalAttempt.from_packet(packet_a), ArrivalAttempt.from_packet(packet_b)])
    assert tuple((item.src_port, item.dst_port) for item in ordered_attempts) == ((4, 5), (10, 11))

    ordered_decisions = canonicalize_admission_decisions(
        [
            AdmissionDecision.accept(packet_a, slot=5, queue_occupancy_before=0, voq_capacity=8),
            AdmissionDecision.accept(packet_b, slot=5, queue_occupancy_before=0, voq_capacity=8),
        ]
    )
    assert tuple((item.src_port, item.dst_port) for item in ordered_decisions) == ((4, 5), (10, 11))


def test_admission_decision_accept_and_drop_constructors_are_consistent() -> None:
    packet = Packet(packet_id=11, flow_id=2, src_port=1, dst_port=3, generation_slot=19)

    accepted = AdmissionDecision.accept(packet, slot=19, queue_occupancy_before=4, voq_capacity=8)
    dropped = AdmissionDecision.drop(packet, slot=19, queue_occupancy_before=8, voq_capacity=8)

    assert accepted.accepted is True
    assert accepted.reason == ADMISSION_REASON_ENQUEUED
    assert accepted.packet.enqueue_slot == 19
    assert accepted.queue_occupancy_before == 4
    assert accepted.queue_occupancy_after == 5
    assert accepted.outcome == "accepted"

    assert dropped.accepted is False
    assert dropped.reason == ADMISSION_REASON_BUFFER_FULL
    assert dropped.packet.enqueue_slot is None
    assert dropped.queue_occupancy_before == dropped.queue_occupancy_after == 8
    assert dropped.outcome == "dropped_buffer_full"



def test_admission_decision_rejects_invalid_occupancy_progression_and_canonicalizes() -> None:
    packet = Packet(packet_id=12, flow_id=2, src_port=1, dst_port=2, generation_slot=3).mark_enqueued(3)

    with pytest.raises(ValidationError):
        AdmissionDecision(
            slot=3,
            packet=packet,
            accepted=True,
            reason="enqueued",
            queue_occupancy_before=7,
            queue_occupancy_after=7,
            voq_capacity=8,
        )

    with pytest.raises(ValidationError):
        AdmissionDecision(
            slot=3,
            packet=Packet(packet_id=13, flow_id=2, src_port=1, dst_port=2, generation_slot=3),
            accepted=False,
            reason="buffer_full",
            queue_occupancy_before=7,
            queue_occupancy_after=7,
            voq_capacity=8,
        )

    ordered = canonicalize_admission_decisions(
        [
            AdmissionDecision.drop(Packet(packet_id=15, flow_id=2, src_port=1, dst_port=2, generation_slot=3), slot=3, queue_occupancy_before=8, voq_capacity=8),
            AdmissionDecision.accept(Packet(packet_id=14, flow_id=2, src_port=1, dst_port=1, generation_slot=3), slot=3, queue_occupancy_before=0, voq_capacity=8),
        ]
    )
    assert tuple(item.packet_id for item in ordered) == (14, 15)



def test_departure_event_requires_service_after_enqueue_slot() -> None:
    packet = Packet(packet_id=21, flow_id=7, src_port=0, dst_port=1, generation_slot=10).mark_enqueued(10)
    departure = DepartureEvent.from_packet(packet, slot=11, queue_occupancy_before=3)

    assert departure.queue_occupancy_after == 2
    assert departure.queue_residency_slots == 1
    assert departure.to_dict()["event_type"] == "departure"
    assert departure.queue_length_before == 3
    assert departure.queue_length_after == 2

    with pytest.raises(ValidationError):
        DepartureEvent.from_packet(packet, slot=10, queue_occupancy_before=3)



def test_completion_event_stamps_packet_and_reports_sojourn() -> None:
    packet = Packet(packet_id=31, flow_id=8, src_port=2, dst_port=0, generation_slot=14).mark_enqueued(14)
    completion = CompletionEvent.from_packet(packet, slot=16)
    via_departure = CompletionEvent.from_departure(DepartureEvent.from_packet(packet, slot=16, queue_occupancy_before=1))

    assert completion.packet.completion_slot == 16
    assert completion.sink_port == 0
    assert completion.sojourn_slots == 2
    assert completion.to_dict()["sojourn_slots"] == 2
    assert via_departure.packet.completion_slot == 16
    assert event_to_dict(completion)["event_type"] == "completion"



def test_completion_event_rejects_mismatched_sink_port() -> None:
    packet = Packet(packet_id=32, flow_id=8, src_port=2, dst_port=0, generation_slot=14).mark_enqueued(14).mark_completed(16)
    with pytest.raises(ValidationError):
        CompletionEvent(slot=16, packet=packet, sink_port=1)
