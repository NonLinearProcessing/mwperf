from __future__ import annotations

from copy import deepcopy
import itertools
import random

import numpy as np
import pytest

from voqsim.errors import ScheduleError, ValidationError
from voqsim.queues import QueueCatalog, ServiceDecision
from voqsim.schedulers.domain import QueueSchedulerDomain
from voqsim.schedulers.exact_priority import exact_lex_weights
from voqsim.schedulers.resource_packing_max_weight import (
    ResourcePackingMaxWeightScheduler,
)
from voqsim.utils import canonical_sha256_hexdigest


QueueId = int | str


def _params(
    queue_ids: tuple[QueueId, ...] | list[QueueId],
    capacity: tuple[int, ...] | list[int],
    demands: tuple[tuple[int, ...], ...] | list[tuple[int, ...]],
    *,
    resources: tuple[QueueId, ...] | list[QueueId] | None = None,
    priority: tuple[QueueId, ...] | list[QueueId] | None = None,
    max_search_states: int | None = None,
) -> dict[str, object]:
    if resources is None:
        resources = tuple(f"r{index}" for index in range(len(capacity)))
    return {
        "constraint": {
            "resources": list(resources),
            "capacity": list(capacity),
            "demands": [
                {"queue_id": queue_id, "demand": list(demand)}
                for queue_id, demand in zip(queue_ids, demands, strict=True)
            ],
        },
        "priority": None if priority is None else list(priority),
        "max_search_states": max_search_states,
    }


def _build(
    queue_ids: tuple[QueueId, ...] | list[QueueId],
    capacity: tuple[int, ...] | list[int],
    demands: tuple[tuple[int, ...], ...] | list[tuple[int, ...]],
    **kwargs: object,
) -> tuple[ResourcePackingMaxWeightScheduler, QueueCatalog]:
    catalog = QueueCatalog(queue_ids)
    scheduler = ResourcePackingMaxWeightScheduler(
        _params(queue_ids, capacity, demands, **kwargs)
    )
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="resource_packing")
    )
    return scheduler, catalog


def _select(
    scheduler: ResourcePackingMaxWeightScheduler,
    q_len: tuple[int, ...] | list[int] | np.ndarray,
    *,
    slot: int = 0,
    seed: int = 7001,
) -> ServiceDecision:
    return scheduler.select_service(q_len, slot, np.random.default_rng(seed))


def _oracle(
    catalog: QueueCatalog,
    capacity: tuple[int, ...],
    demands: tuple[tuple[int, ...], ...],
    q_len: tuple[int, ...],
    priority: tuple[QueueId, ...] | None = None,
) -> ServiceDecision:
    resolved_priority = catalog.queue_ids if priority is None else priority
    priority_indices = tuple(catalog.index_of(queue_id) for queue_id in resolved_priority)
    best_key: tuple[int, tuple[int, ...]] = (-1, ())
    best_indices: tuple[int, ...] = ()
    for bits in itertools.product((0, 1), repeat=catalog.n_queues):
        selected = tuple(index for index, bit in enumerate(bits) if bit)
        if any(q_len[index] <= 0 for index in selected):
            continue
        if any(
            sum(demands[index][resource] for index in selected) > available
            for resource, available in enumerate(capacity)
        ):
            continue
        key = (
            sum(q_len[index] for index in selected),
            tuple(int(index in selected) for index in priority_indices),
        )
        if key > best_key:
            best_key = key
            best_indices = selected
    return ServiceDecision.from_indices(best_indices, catalog)


def test_multiple_resources_selects_maxweight_not_maximum_cardinality() -> None:
    queue_ids = ("heavy", "small-a", "small-b", "other")
    capacity = (3, 3)
    demands = ((3, 3), (2, 0), (1, 2), (0, 1))
    scheduler, catalog = _build(queue_ids, capacity, demands)
    q_len = (11, 5, 5, 1)

    actual = _select(scheduler, q_len)

    assert actual == ServiceDecision(("heavy",))
    assert actual == _oracle(catalog, capacity, demands, q_len)
    assert scheduler.optimizer_id == "binary_packing_memo_exact"
    assert scheduler.service_family == "resource_packing"


def test_zero_capacities_reject_positive_demands_but_not_zero_columns() -> None:
    queue_ids = ("free", "blocked-r0", "blocked-r1")
    scheduler, _catalog = _build(
        queue_ids,
        (0, 0),
        ((0, 0), (1, 0), (0, 9)),
    )

    assert scheduler.individually_serviceable_queue_ids == ("free",)
    assert _select(scheduler, (1, 100, 100)) == ServiceDecision(("free",))


def test_zero_resources_and_empty_vectors_allow_every_nonempty_queue() -> None:
    queue_ids = (2, "a", "b")
    scheduler, _catalog = _build(
        queue_ids,
        (),
        ((), (), ()),
        resources=(),
        max_search_states=1,
    )

    assert scheduler.individually_serviceable_queue_ids == queue_ids
    assert _select(scheduler, (4, 0, 7)) == ServiceDecision((2, "b"))


def test_zero_demand_columns_are_selected_alongside_constrained_optimum() -> None:
    scheduler, catalog = _build(
        ("free-a", "x", "free-b", "y"),
        (1,),
        ((0,), (1,), (0,), (1,)),
        priority=("y", "x", "free-b", "free-a"),
    )
    q_len = (2, 5, 3, 5)

    actual = _select(scheduler, q_len)

    assert actual == ServiceDecision(("free-a", "free-b", "y"))
    assert actual == _oracle(
        catalog,
        (1,),
        ((0,), (1,), (0,), (1,)),
        q_len,
        ("y", "x", "free-b", "free-a"),
    )


def test_individually_impossible_queue_is_never_selected() -> None:
    scheduler, _catalog = _build(
        ("possible", "too-wide", "free"),
        (3, 4),
        ((3, 4), (4, 0), (0, 0)),
    )

    assert scheduler.individually_serviceable_queue_ids == ("possible", "free")
    assert _select(scheduler, (1, 10**9, 1)) == ServiceDecision(
        ("possible", "free")
    )


def test_resources_are_canonicalized_and_all_vectors_are_remapped() -> None:
    forward = ResourcePackingMaxWeightScheduler(
        _params(
            ("z", 4, "a"),
            (8, 5, 3),
            ((7, 4, 1), (2, 5, 3), (0, 1, 2)),
            resources=("z-resource", 8, "a-resource"),
        )
    )
    reverse = ResourcePackingMaxWeightScheduler(
        _params(
            ("a", 4, "z"),
            (3, 5, 8),
            ((2, 1, 0), (3, 5, 2), (1, 4, 7)),
            resources=("a-resource", 8, "z-resource"),
        )
    )

    assert forward.params == reverse.params
    assert forward.params["constraint"] == {
        "resources": [8, "a-resource", "z-resource"],
        "capacity": [5, 3, 8],
        "demands": [
            {"queue_id": 4, "demand": [5, 3, 2]},
            {"queue_id": "a", "demand": [1, 2, 0]},
            {"queue_id": "z", "demand": [4, 1, 7]},
        ],
    }
    assert canonical_sha256_hexdigest(forward.params) == canonical_sha256_hexdigest(
        reverse.params
    )


def test_default_effective_params_are_explicit_and_canonical() -> None:
    scheduler = ResourcePackingMaxWeightScheduler(
        {
            "constraint": {
                "resources": ["r"],
                "capacity": [1],
                "demands": [{"queue_id": "q", "demand": [1]}],
            }
        }
    )

    assert scheduler.params["priority"] is None
    assert scheduler.params["max_search_states"] is None


def test_explicit_priority_controls_primary_tie() -> None:
    scheduler, _catalog = _build(
        ("a", "b"),
        (1,),
        ((1,), (1,)),
        priority=("b", "a"),
    )

    assert _select(scheduler, (12, 12)) == ServiceDecision(("b",))


def test_large_composite_integer_weights_remain_exact() -> None:
    queue_ids = tuple(f"q{index:02d}" for index in range(75))
    priority = tuple(reversed(queue_ids))
    scheduler, catalog = _build(
        queue_ids,
        (1,),
        tuple((1,) for _queue_id in queue_ids),
        priority=priority,
        max_search_states=500,
    )
    q_len = np.ones(len(queue_ids), dtype=np.int64)

    assert max(exact_lex_weights(q_len, catalog, priority)) > np.iinfo(np.int64).max
    assert _select(scheduler, q_len) == ServiceDecision((priority[0],))


def test_selection_is_rng_neutral_for_empty_free_and_recursive_paths() -> None:
    scheduler, _catalog = _build(
        ("free", "a", "b", "c"),
        (2,),
        ((0,), (1,), (1,), (2,)),
    )
    rng = np.random.default_rng(9182)
    for slot, q_len in enumerate(((0, 0, 0, 0), (1, 0, 0, 0), (1, 3, 4, 5))):
        before = deepcopy(rng.bit_generator.state)
        scheduler.select_service(q_len, slot, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize("seed", range(120))
def test_random_small_instances_equal_independent_exhaustive_oracle(seed: int) -> None:
    rng = random.Random(700_000 + seed)
    n_queues = rng.randint(1, 8)
    n_resources = rng.randint(0, 4)
    queue_ids = tuple(f"q{index}" for index in range(n_queues))
    capacity = tuple(rng.randint(0, 5) for _ in range(n_resources))
    demands = tuple(
        tuple(rng.randint(0, 5) for _ in range(n_resources))
        for _ in range(n_queues)
    )
    q_len = tuple(rng.randint(0, 9) for _ in range(n_queues))
    priority_list = list(queue_ids)
    rng.shuffle(priority_list)
    priority = tuple(priority_list)
    scheduler, catalog = _build(
        queue_ids,
        capacity,
        demands,
        priority=priority,
        max_search_states=50_000,
    )

    assert _select(scheduler, q_len, seed=seed) == _oracle(
        catalog, capacity, demands, q_len, priority
    )


def test_disjoint_resource_supports_decompose_without_changing_exact_result() -> None:
    queue_ids = ("a0", "a1", "b0", "b1", "free")
    capacity = (1, 1)
    demands = ((1, 0), (1, 0), (0, 1), (0, 1), (0, 0))
    priority = ("a1", "b1", "a0", "b0", "free")
    scheduler, catalog = _build(
        queue_ids,
        capacity,
        demands,
        priority=priority,
    )
    q_len = (4, 4, 7, 7, 1)

    assert _select(scheduler, q_len) == _oracle(
        catalog, capacity, demands, q_len, priority
    )
    assert _select(scheduler, q_len) == ServiceDecision(("a1", "b1", "free"))


def test_search_state_limit_fails_explicitly_without_approximation() -> None:
    scheduler, _catalog = _build(
        tuple(f"q{i}" for i in range(8)),
        (3,),
        tuple((1,) for _ in range(8)),
        max_search_states=1,
    )

    with pytest.raises(ScheduleError, match="exceeded max_search_states") as exc_info:
        _select(scheduler, (1, 2, 3, 4, 5, 6, 7, 8))
    assert exc_info.value.context["max_search_states"] == 1
    assert exc_info.value.context["states_explored"] == 2
    assert exc_info.value.context["slot"] == 0


def test_capacity_validator_rejects_overpacked_external_decision() -> None:
    scheduler, _catalog = _build(("a", "b"), (1, 2), ((1, 1), (1, 1)))

    with pytest.raises(ScheduleError, match="exceeds a resource capacity"):
        scheduler.validate_service_decision(ServiceDecision(("a", "b")), (1, 1))


def test_bind_requires_exactly_one_demand_column_per_catalog_queue() -> None:
    scheduler = ResourcePackingMaxWeightScheduler(
        _params(("a",), (1,), ((1,),))
    )
    domain = QueueSchedulerDomain(
        QueueCatalog(("a", "missing")), service_family="resource_packing"
    )

    with pytest.raises(ValidationError, match="exactly one demand column"):
        scheduler.configure_for_domain(domain)
    assert scheduler.scheduler_domain is None


def test_failed_wrong_family_bind_is_transactional() -> None:
    scheduler = ResourcePackingMaxWeightScheduler(
        _params(("q",), (1,), ((1,),))
    )
    catalog = QueueCatalog(("q",))

    with pytest.raises(ValidationError, match="requires the resource_packing"):
        scheduler.configure_for_domain(
            QueueSchedulerDomain(catalog, service_family="crossbar_matching")
        )
    assert scheduler.scheduler_domain is None
    scheduler.configure_for_domain(
        QueueSchedulerDomain(catalog, service_family="resource_packing")
    )


@pytest.mark.parametrize(
    "params,match",
    [
        ({}, "requires scheduler.params.constraint"),
        (
            {"constraint": {"resources": ["r"], "capacity": [1], "demands": []}, "extra": 1},
            "unsupported scheduler params",
        ),
        (
            {"constraint": {"resources": ["r", "r"], "capacity": [1, 1], "demands": []}},
            "duplicate resource",
        ),
        (
            {"constraint": {"resources": ["r"], "capacity": [], "demands": []}},
            "capacity length",
        ),
        (
            {"constraint": {"resources": ["r"], "capacity": [-1], "demands": []}},
            "must be >= 0",
        ),
        (
            {
                "constraint": {
                    "resources": ["r"],
                    "capacity": [1],
                    "demands": [{"queue_id": "q", "demand": []}],
                }
            },
            "demand length",
        ),
        (
            {
                "constraint": {
                    "resources": ["r"],
                    "capacity": [1],
                    "demands": [{"queue_id": "q", "demand": [False]}],
                }
            },
            "nonnegative integer",
        ),
        (
            {
                "constraint": {
                    "resources": [],
                    "capacity": [],
                    "demands": [
                        {"queue_id": "q", "demand": []},
                        {"queue_id": "q", "demand": []},
                    ],
                }
            },
            "duplicate queue_id",
        ),
        (
            {
                "constraint": {"resources": [], "capacity": [], "demands": []},
                "max_search_states": 0,
            },
            "must be >= 1",
        ),
    ],
)
def test_invalid_constraint_and_policy_inputs_fail_early(
    params: dict[str, object], match: str
) -> None:
    with pytest.raises(ValidationError, match=match):
        ResourcePackingMaxWeightScheduler(params)


@pytest.mark.parametrize("value", [True, 1.5, "5", [], {}])
def test_invalid_search_state_limit_types_are_rejected(value: object) -> None:
    params = _params(("q",), (1,), ((1,),))
    params["max_search_states"] = value

    with pytest.raises(ValidationError, match="positive integer or null"):
        ResourcePackingMaxWeightScheduler(params)


def test_serviceability_query_requires_bound_domain() -> None:
    scheduler = ResourcePackingMaxWeightScheduler(
        _params(("q",), (1,), ((1,),))
    )

    with pytest.raises(ValidationError, match="configured"):
        _ = scheduler.individually_serviceable_queue_ids
