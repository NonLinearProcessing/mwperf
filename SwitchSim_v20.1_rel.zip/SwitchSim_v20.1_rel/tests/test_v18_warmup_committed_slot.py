from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION
from voqsim.errors import ValidationError
from voqsim.events import CommittedSlot
from voqsim.kernel import build_simulation
from voqsim.telemetry import CompactObservationReader, STATUS_FAILED


def _slot_config(path: str, *, warmup_slots: int = 2, slots: int = 5, drain: bool = False):
    run = {
        "seed": 18001,
        "slots": slots,
        "warmup_slots": warmup_slots,
        "termination": "fixed_slots_then_drain" if drain else "fixed_slots",
    }
    telemetry = {
        "format": "jsonl",
        "queue_snapshot": "dense",
        "include_packet_events": True,
        "write_slot_trace": True,
    }
    events = [{"slot": slot, "queue_id": "q", "count": 1} for slot in range(slots)]
    if path == "crossbar":
        switch = {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": [{"id": "q"}],
        }
        scheduler = {
            "name": "crossbar_max_weight",
            "params": {
                "constraint": {
                    "inputs": ["i"],
                    "outputs": ["o"],
                    "edges": [{"queue_id": "q", "input": "i", "output": "o"}],
                }
            },
        }
    else:
        switch = {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": ["q"],
        }
        scheduler = {
            "name": "conflict_graph_max_weight",
            "params": {"constraint": {"conflicts": []}, "priority": ["q"]},
        }
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": run,
        "switch": switch,
        "scheduler": scheduler,
        "arrival": {"family": "deterministic_trace", "events": events},
        "telemetry": telemetry,
    }


def _read_trace(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


class _ObjectObserver:
    def __init__(self) -> None:
        self.commits: list[CommittedSlot] = []

    def observe(self, commit: CommittedSlot) -> None:
        self.commits.append(commit)


@pytest.mark.parametrize("path", ["crossbar", "generic"])
def test_all_kernel_paths_publish_only_measurement_commits(path: str, tmp_path: Path) -> None:
    callback_commits: list[CommittedSlot] = []
    object_observer = _ObjectObserver()
    result = build_simulation(
        _slot_config(path),
        output_dir=tmp_path / path,
    ).run(observers=[callback_commits.append, object_observer])

    assert [commit.slot for commit in callback_commits] == [2, 3, 4]
    assert object_observer.commits == callback_commits
    assert [record["slot"] for record in _read_trace(result.telemetry_path)] == [2, 3, 4]

    metrics = result.summary.to_dict()["metrics"]
    assert metrics["slots_observed"] == 3
    assert metrics["first_slot"] == 2
    assert metrics["last_slot"] == 4
    assert metrics["offered_packets"] == 3
    assert metrics["admitted_packets"] == 3
    assert metrics["dropped_packets"] == 0

    assert result.measurement_queue_ids == callback_commits[0].queue_ids
    assert result.measurement_start_queue_lengths == tuple(callback_commits[0].q_before)
    assert result.measurement_end_queue_lengths == tuple(callback_commits[-1].q_after)

    for commit in callback_commits:
        assert isinstance(commit, CommittedSlot)
        assert commit.offered_count == commit.admitted_count == 1
        assert commit.dropped_count == 0
        assert commit.served_count == 1
        assert sum(commit.offered_by_queue.values()) == 1
        assert sum(commit.admitted_by_queue.values()) == 1
        assert sum(commit.served_by_queue.values()) == 1
        expected = commit.q_before.copy()
        for queue_id, count in commit.served_by_queue.items():
            expected[commit.queue_index(queue_id)] -= count
        for queue_id, count in commit.admitted_by_queue.items():
            expected[commit.queue_index(queue_id)] += count
        assert np.array_equal(expected, commit.q_after)

    with pytest.raises((ValueError, TypeError)):
        callback_commits[0].q_before[0] = 99
    with pytest.raises(ValueError):
        callback_commits[0].q_before.flags.writeable = True


def test_v18_positional_record_argument_remains_compatible(tmp_path: Path) -> None:
    commits: list[CommittedSlot] = []
    build_simulation(
        _slot_config("generic", warmup_slots=0, slots=1),
        output_dir=tmp_path / "source",
    ).run(observers=commits.append)
    source = commits[0]
    legacy_record = source.record

    reconstructed = CommittedSlot(
        source.slot,
        source.catalog,
        source.q_before,
        source.q_after,
        source.service_decision,
        source.departures,
        source.offered,
        source.admissions,
        legacy_record,
    )

    assert reconstructed.record is legacy_record
    assert reconstructed.exact_gap_certificates == ()


@pytest.mark.parametrize("path", ["crossbar", "generic"])
def test_drain_is_outside_measurement_for_all_kernel_paths(path: str, tmp_path: Path) -> None:
    commits: list[CommittedSlot] = []
    simulator = build_simulation(
        _slot_config(path, warmup_slots=0, slots=1, drain=True),
        output_dir=tmp_path / path,
    )
    result = simulator.run(observers=commits.append)

    assert result.slots_run == 2
    assert [commit.slot for commit in commits] == [0]
    assert [record["slot"] for record in _read_trace(result.telemetry_path)] == [0]
    assert result.summary.to_dict()["metrics"]["slots_observed"] == 1
    assert result.summary.to_dict()["metrics"]["completed_packets"] == 0
    assert sum(result.measurement_end_queue_lengths) == 1
    metadata = result.summary.to_dict()["metadata"]
    assert metadata["measurement_start_occupancy_packets"] == 0
    assert metadata["measurement_end_occupancy_packets"] == 1
    assert metadata["execution_peak_occupancy_packets"] == 1
    assert metadata["post_run_final_occupancy_packets"] == 0
    assert simulator.switch.is_empty()


def test_warmup_changes_measurement_only_not_dynamics_or_random_streams(tmp_path: Path) -> None:
    config = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 18002,
            "slots": 9,
            "warmup_slots": 0,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": 8,
            "queues": [{"id": queue_id} for queue_id in ("q01", "q02", "q12", "q21")],
        },
        "scheduler": {
            "name": "crossbar_random_greedy_maximal",
            "params": {
                "constraint": {
                    "inputs": [0, 1, 2],
                    "outputs": [0, 1, 2],
                    "edges": [
                        {"queue_id": "q01", "input": 0, "output": 1},
                        {"queue_id": "q02", "input": 0, "output": 2},
                        {"queue_id": "q12", "input": 1, "output": 2},
                        {"queue_id": "q21", "input": 2, "output": 1},
                    ],
                }
            },
        },
        "arrival": {
            "family": "iid_independent_bernoulli",
            "rates": {"default": 0.61, "overrides": []},
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "include_scheduler_state": True,
            "write_slot_trace": True,
        },
    }
    baseline_sim = build_simulation(config, output_dir=tmp_path / "w0")
    baseline = baseline_sim.run()

    warmed_config = dict(config)
    warmed_config["run"] = {**config["run"], "warmup_slots": 3}
    warmed_sim = build_simulation(warmed_config, output_dir=tmp_path / "w3")
    warmed = warmed_sim.run()

    baseline_tail = [record for record in _read_trace(baseline.telemetry_path) if record["slot"] >= 3]
    assert _read_trace(warmed.telemetry_path) == baseline_tail
    assert warmed.measurement_start_queue_lengths == tuple(
        baseline_tail[0]["q_before"]["values"]
    )
    assert warmed.measurement_end_queue_lengths == baseline.measurement_end_queue_lengths
    assert np.array_equal(warmed_sim.switch.queue_lengths(), baseline_sim.switch.queue_lengths())
    assert warmed.summary.to_dict()["metrics"]["slots_observed"] == 6


@pytest.mark.parametrize("path", ["crossbar", "generic"])
def test_stochastic_count_paths_advance_normally_during_warmup(
    path: str,
    tmp_path: Path,
) -> None:
    queue_ids = ("q0", "q1")
    switch = {
        "kind": "generalized",
        "queue_capacity": 16,
        "queues": [{"id": queue_id} for queue_id in queue_ids],
    }
    scheduler = (
        {
            "name": "crossbar_max_weight",
            "params": {
                "constraint": {
                    "inputs": [0, 1],
                    "outputs": [0],
                    "edges": [
                        {"queue_id": "q0", "input": 0, "output": 0},
                        {"queue_id": "q1", "input": 1, "output": 0},
                    ],
                }
            },
        }
        if path == "crossbar"
        else {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [[queue_ids[0], queue_ids[1]]]},
                "priority": list(queue_ids),
            },
        }
    )
    config = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 18003,
            "slots": 18,
            "warmup_slots": 0,
            "termination": "fixed_slots",
        },
        "switch": switch,
        "scheduler": scheduler,
        "arrival": {
            "family": "independent_marked_renewal",
            "sources": [
                {
                    "id": "random-renewal",
                    "interarrival": {
                        "kind": "geometric_grid",
                        "d_min": 1,
                        "delta": 1,
                        "p": 0.45,
                    },
                    "destination_pmf": [
                        {"queue_id": queue_ids[0], "probability": 0.4},
                        {"queue_id": queue_ids[1], "probability": 0.6},
                    ],
                }
            ],
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": True,
            "include_scheduler_state": True,
            "write_slot_trace": True,
        },
    }

    baseline_sim = build_simulation(config, output_dir=tmp_path / f"{path}-w0")
    baseline = baseline_sim.run()
    warmed_config = {**config, "run": {**config["run"], "warmup_slots": 7}}
    warmed_sim = build_simulation(warmed_config, output_dir=tmp_path / f"{path}-w7")
    warmed = warmed_sim.run()

    baseline_tail = [
        record for record in _read_trace(baseline.telemetry_path) if record["slot"] >= 7
    ]
    assert _read_trace(warmed.telemetry_path) == baseline_tail
    assert warmed.measurement_end_queue_lengths == baseline.measurement_end_queue_lengths
    assert np.array_equal(warmed_sim.switch.queue_lengths(), baseline_sim.switch.queue_lengths())


@pytest.mark.parametrize(
    ("path", "target"),
    [("crossbar", "q"), ("generic", "q")],
)
def test_failure_never_publishes_complete_observations_on_any_kernel_path(
    path: str,
    target: str,
    tmp_path: Path,
) -> None:
    config = _slot_config(path, warmup_slots=1, slots=4)
    config["telemetry"] = {
        **config["telemetry"],
        "observation": {
            "enabled": True,
            "block_slots": 2,
            "targets": [{"queue_id": target, "gap": "none"}],
        },
    }
    simulator = build_simulation(config, output_dir=tmp_path / path)

    def fail_after_commit(_commit: CommittedSlot) -> None:
        raise RuntimeError("injected observer failure")

    with pytest.raises(RuntimeError, match="injected observer failure"):
        simulator.run(observers=fail_after_commit)

    assert simulator.observation_path is not None
    with pytest.raises(ValidationError, match="not complete"):
        CompactObservationReader(simulator.observation_path)
    with CompactObservationReader(simulator.observation_path, require_complete=False) as reader:
        assert reader.state.status == STATUS_FAILED
