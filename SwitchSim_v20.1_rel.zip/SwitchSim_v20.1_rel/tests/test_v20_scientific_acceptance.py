from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path
from typing import Any

import numpy as np
import pytest

from voqsim.config import CONFIG_SCHEMA_VERSION, NO_DROP_CAPACITY
from voqsim.kernel import build_simulation
from voqsim.queues import QueueCatalog
from voqsim.rng import build_arrival_rng_for_slot, build_scheduler_rng_for_slot
from voqsim.telemetry import CompactObservationReader
from voqsim.traffic.count_arrivals import (
    IIDIndependentPoissonArrival,
    IIDMixedPoissonArrival,
)


_EMPIRICAL_SLOTS = 20_000
_EMPIRICAL_SEED = 20_261_001
_RATES = np.asarray([0.8, 1.6], dtype=float)
_MODULATION_MOMENTS = {1: 1.0, 2: 4.0, 3: 16.0, 4: 64.0}


def _rates(rate0: Decimal = Decimal("0.8"), rate1: Decimal = Decimal("1.6")):
    return {
        "default": Decimal(0),
        "overrides": [
            {"queue_id": "q0", "rate": rate0},
            {"queue_id": "q1", "rate": rate1},
        ],
    }


def _modulation(scope: str) -> dict[str, object]:
    # E[M] = 1, Var(M) = 3, and E[M**k] = 4**(k - 1).
    return {
        "scope": scope,
        "states": [
            {
                "id": "off",
                "probability": Decimal("0.75"),
                "multiplier": Decimal(0),
            },
            {
                "id": "burst",
                "probability": Decimal("0.25"),
                "multiplier": Decimal(4),
            },
        ],
    }


def _mixed_marginal_variance_and_fourth(rate: float) -> tuple[float, float]:
    factorial = {
        order: rate**order * _MODULATION_MOMENTS[order]
        for order in range(1, 5)
    }
    raw1 = factorial[1]
    raw2 = factorial[2] + factorial[1]
    raw3 = factorial[3] + 3 * factorial[2] + factorial[1]
    raw4 = (
        factorial[4]
        + 6 * factorial[3]
        + 7 * factorial[2]
        + factorial[1]
    )
    variance = raw2 - raw1**2
    central_fourth = (
        raw4 - 4 * raw1 * raw3 + 6 * raw1**2 * raw2 - 3 * raw1**4
    )
    return variance, central_fourth


def _shared_covariance_and_product_variance(
    first_rate: float,
    second_rate: float,
) -> tuple[float, float]:
    a = first_rate
    b = second_rate
    m2 = _MODULATION_MOMENTS[2]
    m3 = _MODULATION_MOMENTS[3]
    m4 = _MODULATION_MOMENTS[4]
    ex2 = a * a * m2 + a
    ey2 = b * b * m2 + b
    exy = a * b * m2
    ex2y = a * a * b * m3 + a * b * m2
    exy2 = a * b * b * m3 + a * b * m2
    ex2y2 = (
        a * a * b * b * m4
        + (a * a * b + a * b * b) * m3
        + a * b * m2
    )
    centered_product_second = (
        ex2y2
        - 2 * b * ex2y
        + b * b * ex2
        - 2 * a * exy2
        + 4 * a * b * exy
        - 2 * a * b * b * a
        + a * a * ey2
        - 2 * a * a * b * b
        + a * a * b * b
    )
    covariance = exy - a * b
    return covariance, centered_product_second - covariance**2


@pytest.mark.parametrize(
    ("family", "scope"),
    [
        pytest.param("iid_independent_poisson", None, id="independent-poisson"),
        pytest.param("iid_mixed_poisson", "shared", id="mixed-shared"),
        pytest.param(
            "iid_mixed_poisson",
            "independent_queue",
            id="mixed-independent-queue",
        ),
    ],
)
def test_fixed_seed_empirical_moments_and_cross_queue_covariance(
    family: str,
    scope: str | None,
) -> None:
    catalog = QueueCatalog(("q0", "q1"))
    if family == "iid_independent_poisson":
        model = IIDIndependentPoissonArrival(catalog, {"rates": _rates()})
        expected_variances = _RATES.copy()
        central_fourths = _RATES + 3 * _RATES**2
        expected_covariance = 0.0
        centered_product_variance = float(np.prod(expected_variances))
    else:
        assert scope is not None
        model = IIDMixedPoissonArrival(
            catalog,
            {"rates": _rates(), "modulation": _modulation(scope)},
        )
        marginal_moments = [
            _mixed_marginal_variance_and_fourth(rate) for rate in _RATES
        ]
        expected_variances = np.asarray(
            [moments[0] for moments in marginal_moments]
        )
        central_fourths = np.asarray(
            [moments[1] for moments in marginal_moments]
        )
        if scope == "shared":
            expected_covariance, centered_product_variance = (
                _shared_covariance_and_product_variance(*_RATES)
            )
        else:
            expected_covariance = 0.0
            centered_product_variance = float(np.prod(expected_variances))

    samples = np.empty((_EMPIRICAL_SLOTS, 2), dtype=np.int64)
    for slot in range(_EMPIRICAL_SLOTS):
        sample = model.sample(
            slot,
            build_arrival_rng_for_slot(_EMPIRICAL_SEED, slot),
        )
        assert sample.offered_counts is not None
        samples[slot, :] = tuple(sample.offered_counts)

    observed_means = samples.mean(axis=0)
    observed_variances = samples.var(axis=0)
    centered = samples - observed_means
    observed_covariance = float(np.mean(centered[:, 0] * centered[:, 1]))

    # Six asymptotic standard errors make these scientific smoke tests
    # meaningful while leaving a very large margin against sampling flukes.
    mean_tolerance = 6 * np.sqrt(expected_variances / _EMPIRICAL_SLOTS)
    variance_tolerance = 6 * np.sqrt(
        (central_fourths - expected_variances**2) / _EMPIRICAL_SLOTS
    )
    covariance_tolerance = 6 * np.sqrt(
        centered_product_variance / _EMPIRICAL_SLOTS
    )
    assert np.all(np.abs(observed_means - _RATES) <= mean_tolerance)
    assert np.all(
        np.abs(observed_variances - expected_variances) <= variance_tolerance
    )
    assert abs(observed_covariance - expected_covariance) <= covariance_tolerance


def _single_queue_poisson_config(capacity: object) -> dict[str, object]:
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {
            "seed": 1,
            "slots": 4,
            "warmup_slots": 0,
            "termination": "fixed_slots",
        },
        "switch": {
            "kind": "generalized",
            "queue_capacity": capacity,
            "queues": [{"id": "q"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": []},
                "priority": ["q"],
            },
        },
        "arrival": {
            "family": "iid_independent_poisson",
            "rates": {"default": Decimal(4), "overrides": []},
        },
        "telemetry": {
            "format": "jsonl",
            "queue_snapshot": "dense",
            "include_packet_events": False,
            "include_scheduler_state": False,
            "write_slot_trace": True,
            "observation": {
                "enabled": True,
                "block_slots": None,
                "targets": [{"queue_id": "q", "gap": "none"}],
            },
        },
    }


@pytest.mark.parametrize(
    ("capacity", "expected_admitted", "expected_dropped"),
    [
        pytest.param(
            NO_DROP_CAPACITY,
            [4, 2, 4, 6],
            [0, 0, 0, 0],
            id="nodrop",
        ),
        pytest.param(3, [3, 1, 1, 1], [1, 1, 3, 5], id="finite-capacity"),
    ],
)
def test_poisson_counts_above_one_survive_runtime_telemetry_and_compaction(
    capacity: object,
    expected_admitted: list[int],
    expected_dropped: list[int],
    tmp_path: Path,
) -> None:
    expected_offered = [4, 2, 4, 6]
    result = build_simulation(
        _single_queue_poisson_config(capacity),
        output_dir=tmp_path / str(capacity),
    ).run()

    assert result.telemetry_path is not None
    records = [
        json.loads(line)
        for line in result.telemetry_path.read_text(encoding="utf-8").splitlines()
    ]
    observed = [
        (
            record["slot_metrics"]["offered_count"],
            record["slot_metrics"]["admitted_count"],
            record["slot_metrics"]["dropped_count"],
        )
        for record in records
    ]
    assert observed == list(
        zip(expected_offered, expected_admitted, expected_dropped, strict=True)
    )
    assert max(expected_offered) > 1

    metrics = result.summary.to_dict()["metrics"]
    assert (
        metrics["offered_packets"],
        metrics["admitted_packets"],
        metrics["dropped_packets"],
    ) == (
        sum(expected_offered),
        sum(expected_admitted),
        sum(expected_dropped),
    )

    assert result.observation_path is not None
    with CompactObservationReader(result.observation_path) as reader:
        blocks = tuple(reader.iter_target_blocks())
        assert len(blocks) == 1
        block = blocks[0]
        assert block.slots_observed == 4
        assert (block.offered, block.offered_square) == (
            sum(expected_offered),
            sum(count * count for count in expected_offered),
        )
        assert (block.admitted, block.admitted_square, block.dropped) == (
            sum(expected_admitted),
            sum(count * count for count in expected_admitted),
            sum(expected_dropped),
        )
        reader.integrity_check()


def _crossbar_poisson_config(scheduler_name: str) -> dict[str, object]:
    queue_ids = ("q00", "q01", "q10", "q11")
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 9_901, "slots": 12},
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": queue_id} for queue_id in queue_ids],
        },
        "scheduler": {
            "name": scheduler_name,
            "params": {
                "constraint": {
                    "inputs": [0, 1],
                    "outputs": [0, 1],
                    "edges": [
                        {"queue_id": "q00", "input": 0, "output": 0},
                        {"queue_id": "q01", "input": 0, "output": 1},
                        {"queue_id": "q10", "input": 1, "output": 0},
                        {"queue_id": "q11", "input": 1, "output": 1},
                    ],
                }
            },
        },
        "arrival": {
            "family": "iid_independent_poisson",
            "rates": {"default": Decimal("1.5"), "overrides": []},
        },
    }


def test_scheduler_random_draws_cannot_perturb_the_arrival_stream(
    tmp_path: Path,
) -> None:
    arrival_signature = build_arrival_rng_for_slot(9_901, 3).integers(
        0, 2**63, size=16, dtype=np.int64
    )
    scheduler_signature = build_scheduler_rng_for_slot(9_901, 3).integers(
        0, 2**63, size=16, dtype=np.int64
    )
    assert not np.array_equal(arrival_signature, scheduler_signature)

    offered_streams: list[list[tuple[int, ...]]] = []
    for scheduler_name in (
        "crossbar_max_weight",
        "crossbar_random_greedy_maximal",
    ):
        commits = []
        result = build_simulation(
            _crossbar_poisson_config(scheduler_name),
            output_dir=tmp_path / scheduler_name,
        ).run(observers=commits.append)
        offered_streams.append(
            [
                tuple(commit.offered_by_queue.get(queue_id, 0) for queue_id in commit.queue_ids)
                for commit in commits
            ]
        )
        assert result.telemetry_path is None

    assert offered_streams[0] == offered_streams[1]
    assert max(count for vector in offered_streams[0] for count in vector) > 1


def _artifact_config(
    family: str,
    rate: Decimal,
) -> dict[str, object]:
    arrival: dict[str, object] = {
        "family": family,
        "rates": {"default": rate, "overrides": []},
    }
    if family == "iid_mixed_poisson":
        arrival["modulation"] = _modulation("shared")
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "run": {"seed": 44, "slots": 1},
        "switch": {
            "kind": "generalized",
            "queue_capacity": NO_DROP_CAPACITY,
            "queues": [{"id": "q0"}, {"id": "q1"}],
        },
        "scheduler": {
            "name": "conflict_graph_max_weight",
            "params": {
                "constraint": {"conflicts": [["q0", "q1"]]},
                "priority": ["q0", "q1"],
            },
        },
        "arrival": arrival,
    }


def _all_mapping_keys(value: Any):
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key)
            yield from _all_mapping_keys(child)
    elif isinstance(value, list):
        for child in value:
            yield from _all_mapping_keys(child)


@pytest.mark.parametrize(
    "family",
    ["iid_independent_poisson", "iid_mixed_poisson"],
)
def test_poisson_support_output_is_rate_compact_and_never_implies_a_trace(
    family: str,
    tmp_path: Path,
) -> None:
    support_sizes: list[int] = []
    simulators = []
    for label, rate in (
        ("small", Decimal("0.1")),
        ("huge", Decimal("1e12")),
    ):
        simulator = build_simulation(
            _artifact_config(family, rate),
            output_dir=tmp_path / label,
        )
        simulators.append(simulator)
        support_path = simulator.static_artifacts["arrival_support"]
        support = json.loads(support_path.read_text(encoding="utf-8"))
        support_sizes.append(support_path.stat().st_size)

        assert not any("pmf" in key.lower() for key in _all_mapping_keys(support))
        assert "outcomes" not in support["model"]
        assert support["support_size"] == 2
        assert support_path.stat().st_size < 2_048
        assert simulator.telemetry_path is None
        assert not (simulator.output_dir / "telemetry.jsonl").exists()

    # Only the decimal token grows; output never scales with the Poisson tail.
    assert abs(support_sizes[1] - support_sizes[0]) < 32

    result = simulators[0].run()
    assert result.telemetry_path is None
    assert result.to_dict()["slot_trace_written"] is False
    assert not (result.output_dir / "telemetry.jsonl").exists()


def test_disabled_outputs_remove_stale_runtime_artifacts_on_directory_reuse(
    tmp_path: Path,
) -> None:
    output_dir = tmp_path / "reused"
    first = build_simulation(
        _single_queue_poisson_config(NO_DROP_CAPACITY),
        output_dir=output_dir,
    ).run()
    assert first.telemetry_path is not None and first.telemetry_path.exists()
    assert first.observation_path is not None and first.observation_path.exists()

    no_optional_outputs = _single_queue_poisson_config(NO_DROP_CAPACITY)
    no_optional_outputs.pop("telemetry")
    second = build_simulation(
        no_optional_outputs,
        output_dir=output_dir,
    ).run()

    assert second.telemetry_path is None
    assert second.observation_path is None
    assert second.to_dict()["slot_trace_written"] is False
    assert second.to_dict()["compact_observations_written"] is False
    assert not (output_dir / "telemetry.jsonl").exists()
    assert not (output_dir / "observations.sqlite3").exists()
