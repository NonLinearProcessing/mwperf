# Commands

Run commands from the repository root on x86-64 Ubuntu.

## Dependencies

```bash
sudo apt-get update
sudo apt-get install -y \
  build-essential ca-certificates cmake coreutils curl findutils gawk \
  libboost-all-dev libeigen3-dev libyaml-cpp-dev musl-tools \
  nlohmann-json3-dev pkg-config python3 tar
```

The build requires CMake 3.24 or newer, a C++20 compiler, Boost 1.74 or
newer, Eigen 3.3 or newer, nlohmann-json 3.9 or newer, yaml-cpp, Catch2 3,
Rust/Cargo 1.82.0, and the `x86_64-unknown-linux-musl` Rust target.

Install Rust and the required target:

```bash
curl --proto '=https' --tlsv1.2 -fsS https://sh.rustup.rs | \
  sh -s -- -y --profile minimal --default-toolchain none
. "$HOME/.cargo/env"
rustup toolchain install 1.82.0 --profile minimal
rustup target add --toolchain 1.82.0 x86_64-unknown-linux-musl
```

Install Catch2 3.7.1 when Catch2 3 is not supplied by the operating system:

```bash
curl --proto '=https' --tlsv1.2 -fsSLo /tmp/catch2.tar.gz \
  https://github.com/catchorg/Catch2/archive/refs/tags/v3.7.1.tar.gz
tar -xzf /tmp/catch2.tar.gz -C /tmp
cmake -S /tmp/Catch2-3.7.1 -B /tmp/catch2-build \
  -DCMAKE_BUILD_TYPE=Release -DCATCH_BUILD_TESTING=OFF
cmake --build /tmp/catch2-build --parallel "$(nproc)"
sudo cmake --install /tmp/catch2-build
```

## Complete build and test

```bash
MWPERF_BUILD_JOBS="$(nproc)" bash sampler/run_integration_validation.sh
```

Environment controls:

- `MWPERF_BUILD_JOBS`: parallel build jobs; default `2`.
- `MWPERF_WORK_ROOT`: parent directory for temporary build directories; default
  `$HOME/mwperf-framework-runs`.
- `MWPERF_RESULTS_PARENT`: validation-output directory; default
  `$HOME/mwperf-validation-results`.
- `MWPERF_SAMPLER_EXECUTABLE`: absolute path to an existing static sampler;
  source tests still run, but rebuilding that executable is skipped.

## Build the sampler

```bash
cd sampler
export CARGO_TARGET_DIR="$PWD/target"
export CC_x86_64_unknown_linux_musl="$(command -v musl-gcc)"
export CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER="$CC_x86_64_unknown_linux_musl"
export RUSTFLAGS='-D warnings -C target-feature=+crt-static -C link-self-contained=yes -C debuginfo=0'
cargo fetch --locked \
  --manifest-path full-orbit-framework-sampler/Cargo.toml \
  --target x86_64-unknown-linux-musl
cargo build --frozen --release --jobs "$(nproc)" \
  --target x86_64-unknown-linux-musl \
  --manifest-path full-orbit-framework-sampler/Cargo.toml \
  --bin Full_Orbit_Framework_Sampler
cd ..
```

The executable is
`sampler/target/x86_64-unknown-linux-musl/release/Full_Orbit_Framework_Sampler`.

## Build and test the framework

```bash
SAMPLER="$(realpath sampler/target/x86_64-unknown-linux-musl/release/Full_Orbit_Framework_Sampler)"
SAMPLER_SHA256="$(sha256sum "$SAMPLER" | awk '{print $1}')"
cmake -S framework -B build/release -G 'Unix Makefiles' \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DMWPERF_ENABLE_FULL_ORBIT_SAMPLER=ON \
  -DMWPERF_FULL_ORBIT_SAMPLER_EXECUTABLE="$SAMPLER" \
  -DMWPERF_FULL_ORBIT_SAMPLER_SHA256="$SAMPLER_SHA256"
cmake --build build/release --parallel "$(nproc)"
ctest --test-dir build/release --output-on-failure --no-tests=error
```

CMake flags:

- `BUILD_TESTING=ON|OFF`: enable or omit test targets.
- `MWPERF_ENABLE_FULL_ORBIT_SAMPLER=ON|OFF`: enable or omit the sampler
  provider.
- `MWPERF_FULL_ORBIT_SAMPLER_EXECUTABLE=<absolute-path>`: select the sampler
  executable.
- `MWPERF_FULL_ORBIT_SAMPLER_SHA256=<64-hex-digest>`: authenticate the selected
  sampler executable.
- `MWPERF_WARNINGS_AS_ERRORS=ON|OFF`: promote project warnings to errors.
- `MWPERF_ENABLE_ASAN=ON|OFF`: enable AddressSanitizer.
- `MWPERF_ENABLE_UBSAN=ON|OFF`: enable UndefinedBehaviorSanitizer.
- `MWPERF_ENABLE_C30_PERFORMANCE_BENCHMARKS=ON|OFF`: enable optional
  performance benchmarks.

Install the program and sampler:

```bash
cmake --install build/release --prefix install
```

## Run

Run one target with the built-in analysis profile:

```bash
build/release/mwperf \
  --model path/to/model.json \
  --target queue-id \
  --output result.json \
  --workers 1 \
  --timeout-seconds 3600 \
  --result-version auto
```

Run an explicit analysis profile:

```bash
build/release/mwperf \
  --model path/to/model.json \
  --analysis path/to/analysis.json \
  --output result.json \
  --workers 1 \
  --timeout-seconds 3600 \
  --result-version auto
```

Run flags:

- `--model <path>`: schema-3 or schema-4 model input.
- `--target <queue-id>`: use the built-in analysis profile for one queue.
- `--analysis <path>`: use an analysis-v1 input; mutually exclusive with
  `--target`.
- `--output <path>`: result JSON destination.
- `--workers <positive-u32>`: provider worker count; default `1`.
- `--timeout-seconds <positive-integer>`: provider deadline in seconds;
  default `3600`.
- `--result-version <auto|1|2|3>`: select the result format; `auto` selects the
  format required by the route.
- `--output_resources`: include supported resource counters.
- `--report_unavailable_diagnostics`: include diagnostics for unavailable
  results.
- `--help`: print command syntax.
- `--version`: print compiled build information.

## Compare compression analyses

```bash
build/release/mwperf compare-compression \
  --stationary-reference stationary-observation.json \
  --finite-window-reference finite-window-observation.json \
  --weighted-ensemble weighted-observation-or-result.json \
  --decoder-result decoder-result-v2.json \
  --cutoff 4 --cutoff 8 --cutoff 16 \
  --output comparison.json
```

Comparison flags:

- `--stationary-reference <path>`: stationary-reference observation.
- `--finite-window-reference <path>`: finite-window-reference observation.
- `--weighted-ensemble <path>`: weighted-ensemble observation, result-v2, or
  result-v3.
- `--decoder-result <path>`: optional decoder result-v2.
- `--cutoff <K>`: nonnegative compression cutoff; repeat for multiple unique
  cutoffs. Defaults to `4`, `8`, and `12` when omitted.
- `--output <path>`: comparison JSON destination.

Exit statuses are `0` for success, `1` for failed analysis or an internal
failure, `2` for invalid command-line use, and `3` for an unavailable analysis
result.
