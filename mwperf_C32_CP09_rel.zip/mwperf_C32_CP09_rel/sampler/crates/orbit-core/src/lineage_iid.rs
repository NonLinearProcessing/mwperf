//! Compact lineage-addressed IID arrivals for weighted-ensemble sweeps.
//!
//! The qualified law stays factorized by source.  In each physical slot,
//! source `s` first emits with its exact Bernoulli probability `p_s`; only an
//! emitting source samples its exact conditional destination row.  The slot
//! arrival vector is the sum of those independent one-hot emissions.  No
//! Cartesian joint table and no mutable arrival replay cursor are constructed.

use std::collections::{hash_map::DefaultHasher, HashSet};
use std::hash::BuildHasherDefault;

use num_bigint::{BigInt, Sign};
use num_rational::BigRational;
use num_traits::{One, ToPrimitive, Zero};
use thiserror::Error;

use crate::exact::{ExactRational, ExactUnsigned, RuntimeCount};
use crate::resolved::SourceId;
use crate::rng::{LineageIidRng, PreparedCategorical};
use crate::unit_count::{Arrival, QueueCatalog, QueueIndex};
use crate::weighted_ensemble::LineageId;

// The C16 hosted-provider sandbox intentionally exposes no ambient entropy.
// Source IDs arrive through the authenticated, bounded request, so a
// deterministic builder preserves the set's sole uniqueness-checking role
// without asking RandomState for getrandom or /dev/urandom.
type Cp07DeterministicBuildHasher = BuildHasherDefault<DefaultHasher>;

/// Frozen family spelling independently verified by the framework when it
/// consumes an exact target projection.
pub const TARGET_ARRIVAL_FAMILY_ID_V1: &str = "independent_marked_renewal";

/// One ordered row of a qualified source's conditional destination PMF.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QualifiedIidDestination {
    pub queue: QueueIndex,
    pub probability: ExactRational,
}

/// One exact source in the phase-free IID subset accepted by CP07.
///
/// `source_id` retains the resolved descriptor identity for validation and
/// audit. Preparation assigns a dense `u32` identity in this input order. The
/// configured-law digest in [`PreparedLineageIid`] binds that dense identity
/// to the canonical descriptor, including its resolved source IDs and order.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QualifiedIidSource {
    pub source_id: SourceId,
    pub arrival_probability: ExactRational,
    pub destinations: Vec<QualifiedIidDestination>,
}

/// Frozen bounds shared with the framework observation-v1 parser.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TargetArrivalMarginalLimitsV1 {
    pub maximum_atoms: usize,
    pub maximum_integer_bits: u64,
    pub maximum_integer_decimal_digits: usize,
}

impl Default for TargetArrivalMarginalLimitsV1 {
    fn default() -> Self {
        Self {
            maximum_atoms: 65_536,
            maximum_integer_bits: 4_096,
            maximum_integer_decimal_digits: 1_234,
        }
    }
}

/// One positive-mass atom in the exact target one-slot batch law.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactTargetArrivalAtomV1 {
    batch_size: ExactUnsigned,
    probability: ExactRational,
}

impl ExactTargetArrivalAtomV1 {
    pub const fn batch_size(&self) -> &ExactUnsigned {
        &self.batch_size
    }

    pub const fn probability(&self) -> &ExactRational {
        &self.probability
    }
}

/// Exact compact target projection authenticated by the configured-law
/// digest. Atoms are strictly increasing by batch size and omit zero mass.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedTargetArrivalMarginalV1 {
    configured_law_digest: [u8; 32],
    atoms: Vec<ExactTargetArrivalAtomV1>,
    mean: ExactRational,
    second_moment: ExactRational,
}

impl PreparedTargetArrivalMarginalV1 {
    pub const fn arrival_family_id() -> &'static str {
        TARGET_ARRIVAL_FAMILY_ID_V1
    }

    pub const fn configured_law_digest(&self) -> [u8; 32] {
        self.configured_law_digest
    }

    pub fn atoms(&self) -> &[ExactTargetArrivalAtomV1] {
        &self.atoms
    }

    pub const fn mean(&self) -> &ExactRational {
        &self.mean
    }

    pub const fn second_moment(&self) -> &ExactRational {
        &self.second_moment
    }

    pub fn is_bound_to_configured_law(&self, digest: &[u8; 32]) -> bool {
        &self.configured_law_digest == digest
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum TargetArrivalMarginalError {
    #[error("the exact target-arrival projection target is outside the queue catalog")]
    TargetOutsideCatalog,
    #[error("the exact target-arrival projection atom count exceeds its frozen limit")]
    AtomLimitExceeded,
    #[error("the exact target-arrival projection integer magnitude exceeds its frozen limit")]
    IntegerMagnitudeLimitExceeded,
    #[error("the exact target-arrival projection allocation was refused")]
    CapacityExceeded,
    #[error("the exact target-arrival projection is not a normalized probability law")]
    ProjectionNotNormalized,
    #[error("the exact target-arrival projection count exceeds u64")]
    CountRepresentationBound,
    #[error("the exact target-arrival projection contradicted its qualified IID source table")]
    QualifiedSourceInvariant,
    #[error(transparent)]
    IidQualification(#[from] LineageIidError),
}

impl TargetArrivalMarginalError {
    pub const fn code(&self) -> &'static str {
        match self {
            Self::TargetOutsideCatalog => "target_outside_catalog",
            Self::AtomLimitExceeded => "atom_limit_exceeded",
            Self::IntegerMagnitudeLimitExceeded => "integer_magnitude_limit_exceeded",
            Self::CapacityExceeded => "capacity_exceeded",
            Self::ProjectionNotNormalized => "projection_not_normalized",
            Self::CountRepresentationBound => "count_representation_bound",
            Self::QualifiedSourceInvariant => "qualified_source_invariant",
            Self::IidQualification(_) => "iid_qualification",
        }
    }
}

/// Compile the target-only Poisson-binomial law before the qualified source
/// rows are consumed by [`PreparedLineageIid`].
///
/// Source `s` contributes a Bernoulli coordinate with exact probability
/// `arrival_probability * destination_probability(target)`. The recurrence is
/// O(K^2) arithmetic and O(K) storage for the K sources that can reach the
/// target; it never expands the joint queue-arrival law.
pub fn compile_exact_target_arrival_marginal_v1(
    catalog: &QueueCatalog,
    configured_law_digest: [u8; 32],
    sources: &[QualifiedIidSource],
    target: QueueIndex,
) -> Result<PreparedTargetArrivalMarginalV1, TargetArrivalMarginalError> {
    compile_exact_target_arrival_marginal_with_limits_v1(
        catalog,
        configured_law_digest,
        sources,
        target,
        TargetArrivalMarginalLimitsV1::default(),
    )
}

pub fn compile_exact_target_arrival_marginal_with_limits_v1(
    catalog: &QueueCatalog,
    configured_law_digest: [u8; 32],
    sources: &[QualifiedIidSource],
    target: QueueIndex,
    limits: TargetArrivalMarginalLimitsV1,
) -> Result<PreparedTargetArrivalMarginalV1, TargetArrivalMarginalError> {
    let target_position = target
        .as_usize()
        .filter(|position| *position < catalog.len())
        .ok_or(TargetArrivalMarginalError::TargetOutsideCatalog)?;
    if sources.is_empty() {
        return Err(LineageIidError::EmptySourceTable.into());
    }
    if u32::try_from(sources.len() - 1).is_err() {
        return Err(LineageIidError::SourceCountTooLarge.into());
    }
    validate_source_ids(sources)?;

    let mut target_probabilities = marginal_try_vec(sources.len().min(limits.maximum_atoms))?;
    let mut destination_seen_by_source = marginal_try_vec(catalog.len())?;
    destination_seen_by_source.resize(catalog.len(), usize::MAX);
    let mut certain_target_count = 0_usize;
    for (source_index, source) in sources.iter().enumerate() {
        let _ = probability_parts(&source.arrival_probability, source_index, None)?;
        if !source.arrival_probability.is_positive() {
            return Err(LineageIidError::InvalidArrivalProbability { source_index }.into());
        }
        if source.destinations.is_empty() {
            return Err(LineageIidError::EmptyDestinationRow { source_index }.into());
        }
        if u32::try_from(source.destinations.len() - 1).is_err() {
            return Err(LineageIidError::ProbabilityRepresentationBound { source_index }.into());
        }

        let mut destination_total = BigRational::zero();
        let mut target_route = BigRational::zero();
        for (destination, row) in source.destinations.iter().enumerate() {
            let position = row
                .queue
                .as_usize()
                .filter(|position| *position < catalog.len())
                .ok_or(LineageIidError::DestinationQueueOutOfRange {
                    source_index,
                    destination,
                })?;
            if destination_seen_by_source[position] == source_index {
                return Err(LineageIidError::DuplicateDestinationQueue {
                    source_index,
                    destination,
                }
                .into());
            }
            destination_seen_by_source[position] = source_index;
            let _ = probability_parts(&row.probability, source_index, Some(destination))?;
            destination_total += row.probability.as_ratio();
            if position == target_position {
                target_route += row.probability.as_ratio();
            }
            validate_rational_magnitude(&destination_total, limits)?;
            validate_rational_magnitude(&target_route, limits)?;
        }
        if destination_total != BigRational::one() {
            return Err(LineageIidError::DestinationRowNotNormalized { source_index }.into());
        }
        let theta = source.arrival_probability.as_ratio() * target_route;
        if theta < BigRational::zero() || theta > BigRational::one() {
            return Err(TargetArrivalMarginalError::QualifiedSourceInvariant);
        }
        if theta.is_zero() {
            continue;
        }
        if theta == BigRational::one() {
            certain_target_count = certain_target_count
                .checked_add(1)
                .ok_or(TargetArrivalMarginalError::CountRepresentationBound)?;
            continue;
        }
        if target_probabilities.len() >= limits.maximum_atoms.saturating_sub(1) {
            return Err(TargetArrivalMarginalError::AtomLimitExceeded);
        }
        validate_rational_magnitude(&theta, limits)?;
        target_probabilities.push(theta);
    }

    let coefficient_count = target_probabilities
        .len()
        .checked_add(1)
        .ok_or(TargetArrivalMarginalError::AtomLimitExceeded)?;
    if coefficient_count > limits.maximum_atoms {
        return Err(TargetArrivalMarginalError::AtomLimitExceeded);
    }
    let mut pmf = marginal_try_vec(coefficient_count)?;
    let mut next = marginal_try_vec(coefficient_count)?;
    pmf.push(BigRational::one());
    for theta in target_probabilities {
        next.clear();
        next.resize(pmf.len() + 1, BigRational::zero());
        let no_target = BigRational::one() - &theta;
        for count in 0..pmf.len() {
            next[count] += &pmf[count] * &no_target;
            next[count + 1] += &pmf[count] * &theta;
        }
        for coefficient in &next {
            validate_rational_magnitude(coefficient, limits)?;
        }
        std::mem::swap(&mut pmf, &mut next);
    }

    let total: BigRational = pmf.iter().cloned().sum();
    if total != BigRational::one() {
        return Err(TargetArrivalMarginalError::ProjectionNotNormalized);
    }
    let mut atoms = marginal_try_vec(pmf.len())?;
    let mut mean = BigRational::zero();
    let mut second_moment = BigRational::zero();
    for (random_count, probability) in pmf.into_iter().enumerate() {
        if probability.is_zero() {
            continue;
        }
        if probability < BigRational::zero() {
            return Err(TargetArrivalMarginalError::ProjectionNotNormalized);
        }
        let count = certain_target_count
            .checked_add(random_count)
            .ok_or(TargetArrivalMarginalError::CountRepresentationBound)?;
        let count_u64 = u64::try_from(count)
            .map_err(|_error| TargetArrivalMarginalError::CountRepresentationBound)?;
        validate_u64_magnitude(count_u64, limits)?;
        let exact_count = BigRational::from_integer(BigInt::from(count_u64));
        mean += &exact_count * &probability;
        second_moment += &exact_count * &exact_count * &probability;
        atoms.push(ExactTargetArrivalAtomV1 {
            batch_size: ExactUnsigned::from_u64(count_u64),
            probability: exact_rational_from_ratio(probability)?,
        });
    }
    if atoms.is_empty() {
        return Err(TargetArrivalMarginalError::ProjectionNotNormalized);
    }
    validate_rational_magnitude(&mean, limits)?;
    validate_rational_magnitude(&second_moment, limits)?;
    Ok(PreparedTargetArrivalMarginalV1 {
        configured_law_digest,
        atoms,
        mean: exact_rational_from_ratio(mean)?,
        second_moment: exact_rational_from_ratio(second_moment)?,
    })
}

fn exact_rational_from_ratio(
    value: BigRational,
) -> Result<ExactRational, TargetArrivalMarginalError> {
    ExactRational::new(
        value.numer().clone(),
        value.denom().clone(),
        "exact target-arrival projection",
    )
    .map_err(|_error| TargetArrivalMarginalError::QualifiedSourceInvariant)
}

fn validate_rational_magnitude(
    value: &BigRational,
    limits: TargetArrivalMarginalLimitsV1,
) -> Result<(), TargetArrivalMarginalError> {
    let numerator = value.numer().magnitude();
    let denominator = value.denom().magnitude();
    if numerator.bits() > limits.maximum_integer_bits
        || denominator.bits() > limits.maximum_integer_bits
    {
        return Err(TargetArrivalMarginalError::IntegerMagnitudeLimitExceeded);
    }
    // Convert to decimal only after the bit bound has capped the allocation.
    if numerator.to_str_radix(10).len() > limits.maximum_integer_decimal_digits
        || denominator.to_str_radix(10).len() > limits.maximum_integer_decimal_digits
    {
        return Err(TargetArrivalMarginalError::IntegerMagnitudeLimitExceeded);
    }
    Ok(())
}

fn validate_u64_magnitude(
    value: u64,
    limits: TargetArrivalMarginalLimitsV1,
) -> Result<(), TargetArrivalMarginalError> {
    let bits = if value == 0 {
        0
    } else {
        u64::from(u64::BITS - value.leading_zeros())
    };
    let decimal_digits = if value == 0 {
        1
    } else {
        usize::try_from(value.ilog10() + 1)
            .map_err(|_error| TargetArrivalMarginalError::CountRepresentationBound)?
    };
    if bits > limits.maximum_integer_bits
        || decimal_digits > limits.maximum_integer_decimal_digits
    {
        return Err(TargetArrivalMarginalError::IntegerMagnitudeLimitExceeded);
    }
    Ok(())
}

fn marginal_try_vec<T>(capacity: usize) -> Result<Vec<T>, TargetArrivalMarginalError> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(capacity)
        .map_err(|_error| TargetArrivalMarginalError::CapacityExceeded)?;
    Ok(values)
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedIidDestinationRow {
    distribution: PreparedCategorical<u32>,
    queues: Vec<QueueIndex>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedIidSource {
    source_id: SourceId,
    dense_id: u32,
    occurrence_numerator: u128,
    occurrence_denominator: u128,
    destinations: PreparedIidDestinationRow,
}

/// Immutable, compact source table used by one or more CP07 ensembles.
///
/// The complete ordered queue catalog is retained alongside dense destination
/// coordinates. A runner must match that catalog exactly, so an equal-width
/// permutation cannot silently reinterpret the physical arrival law.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedLineageIid {
    configured_law_digest: [u8; 32],
    catalog: QueueCatalog,
    sources: Vec<PreparedIidSource>,
}

impl PreparedLineageIid {
    /// Validate and compile exact factorized source laws without expanding
    /// their Cartesian joint distribution.
    ///
    /// `configured_law_digest` is the authenticated digest produced by the
    /// canonical request-lowering boundary. This JSON-free core does not
    /// reconstruct or re-hash the original configured-law bytes.
    pub fn try_new(
        catalog: QueueCatalog,
        configured_law_digest: [u8; 32],
        sources: Vec<QualifiedIidSource>,
    ) -> Result<Self, LineageIidError> {
        if catalog.is_empty() {
            return Err(LineageIidError::EmptyQueueCatalog);
        }
        let queue_count = catalog.len();
        if u32::try_from(queue_count).is_err() {
            return Err(LineageIidError::QueueCountTooLarge);
        }
        if sources.is_empty() {
            return Err(LineageIidError::EmptySourceTable);
        }
        if u32::try_from(sources.len() - 1).is_err() {
            return Err(LineageIidError::SourceCountTooLarge);
        }

        validate_source_ids(&sources)?;
        let mut prepared = try_vec(sources.len())?;
        for (source_index, source) in sources.into_iter().enumerate() {
            let dense_id = u32::try_from(source_index)
                .map_err(|_error| LineageIidError::SourceCountTooLarge)?;
            let (occurrence_numerator, occurrence_denominator) =
                probability_parts(&source.arrival_probability, source_index, None)?;
            if occurrence_numerator == 0 {
                return Err(LineageIidError::InvalidArrivalProbability {
                    source_index,
                });
            }
            let destinations = prepare_destination_row(
                source.destinations,
                queue_count,
                source_index,
            )?;
            prepared.push(PreparedIidSource {
                source_id: source.source_id,
                dense_id,
                occurrence_numerator,
                occurrence_denominator,
                destinations,
            });
        }

        Ok(Self {
            configured_law_digest,
            catalog,
            sources: prepared,
        })
    }

    pub const fn configured_law_digest(&self) -> [u8; 32] {
        self.configured_law_digest
    }

    pub const fn catalog(&self) -> &QueueCatalog {
        &self.catalog
    }

    pub fn queue_count(&self) -> usize {
        self.catalog.len()
    }

    pub fn source_count(&self) -> usize {
        self.sources.len()
    }

    pub fn source_ids(&self) -> impl ExactSizeIterator<Item = &SourceId> {
        self.sources.iter().map(|source| &source.source_id)
    }

    /// Allocate all reusable memory needed by [`Self::sample_slot`].
    pub fn try_scratch(&self) -> Result<LineageIidScratch, LineageIidError> {
        LineageIidScratch::try_new(self.catalog.len(), self.sources.len())
    }

    /// Sample and aggregate one child's late-arrival batch.
    ///
    /// The RNG is already bound to a seed, configured-law digest, and
    /// ensemble. Every stochastic address additionally contains `slot`, the
    /// freshly assigned child lineage, the dense source identity, a role, and
    /// a semantic subindex. Destination sampling occurs only after that source
    /// emits. The returned slice remains valid until the next mutable use of
    /// `scratch`.
    pub(crate) fn sample_slot<'a>(
        &self,
        rng: &LineageIidRng,
        physical_slot: u64,
        child: LineageId,
        scratch: &'a mut LineageIidScratch,
    ) -> Result<&'a [Arrival], LineageIidError> {
        if rng.configured_law_digest() != self.configured_law_digest {
            return Err(LineageIidError::RngLawBindingMismatch);
        }
        if rng.ensemble_id() != child.ensemble_id() {
            return Err(LineageIidError::LineageEnsembleMismatch {
                expected: rng.ensemble_id(),
                actual: child.ensemble_id(),
            });
        }
        scratch.begin(self.catalog.len())?;

        let sampled = self.sample_sources(rng, physical_slot, child, scratch);
        if let Err(error) = sampled {
            scratch.discard_partial();
            return Err(error);
        }
        scratch.finish()
    }

    fn sample_sources(
        &self,
        rng: &LineageIidRng,
        physical_slot: u64,
        child: LineageId,
        scratch: &mut LineageIidScratch,
    ) -> Result<(), LineageIidError> {
        for source in &self.sources {
            let occurs = rng
                .sample_occurrence(
                    physical_slot,
                    child,
                    source.dense_id,
                    0,
                    source.occurrence_numerator,
                    source.occurrence_denominator,
                )
                .map_err(|_error| LineageIidError::RandomDrawRefused)?;
            if !occurs {
                continue;
            }

            let destination_row = rng
                .sample_destination(
                    physical_slot,
                    child,
                    source.dense_id,
                    0,
                    &source.destinations.distribution,
                )
                .map_err(|_error| LineageIidError::RandomDrawRefused)?;
            let destination = usize::try_from(destination_row)
                .ok()
                .and_then(|index| source.destinations.queues.get(index))
                .copied()
                .ok_or(LineageIidError::PreparedInvariant {
                    invariant: "destination row index is in range",
                })?;
            scratch.add_one(destination)?;
        }
        Ok(())
    }
}

/// Reusable dense aggregation and canonical sparse-output storage.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LineageIidScratch {
    dense_counts: Vec<RuntimeCount>,
    touched: Vec<QueueIndex>,
    sparse_arrivals: Vec<Arrival>,
}

impl LineageIidScratch {
    pub(crate) fn try_new(
        queue_count: usize,
        maximum_source_count: usize,
    ) -> Result<Self, LineageIidError> {
        let mut dense_counts = try_vec(queue_count)?;
        dense_counts.resize(queue_count, RuntimeCount::ZERO);
        let maximum_touched = queue_count.min(maximum_source_count);
        Ok(Self {
            dense_counts,
            touched: try_vec(maximum_touched)?,
            sparse_arrivals: try_vec(maximum_touched)?,
        })
    }

    pub fn arrivals(&self) -> &[Arrival] {
        &self.sparse_arrivals
    }

    pub(crate) fn begin(&mut self, queue_count: usize) -> Result<(), LineageIidError> {
        if self.dense_counts.len() != queue_count {
            return Err(LineageIidError::ScratchQueueCountMismatch {
                expected: queue_count,
                actual: self.dense_counts.len(),
            });
        }
        self.discard_partial();
        Ok(())
    }

    fn add_one(&mut self, queue: QueueIndex) -> Result<(), LineageIidError> {
        self.add_count(queue, RuntimeCount::new(1))
    }

    pub(crate) fn add_count(
        &mut self,
        queue: QueueIndex,
        count: RuntimeCount,
    ) -> Result<(), LineageIidError> {
        if count == RuntimeCount::ZERO {
            return Err(LineageIidError::PreparedInvariant {
                invariant: "sampled arrival count is positive",
            });
        }
        let position = queue
            .as_usize()
            .filter(|position| *position < self.dense_counts.len())
            .ok_or(LineageIidError::PreparedInvariant {
                invariant: "sampled destination queue is in range",
            })?;
        let before = self.dense_counts[position];
        if before == RuntimeCount::ZERO {
            if self.touched.len() == self.touched.capacity() {
                return Err(LineageIidError::PreparedInvariant {
                    invariant: "touched-queue scratch has prepared capacity",
                });
            }
            self.touched.push(queue);
        }
        self.dense_counts[position] = before
            .checked_add(count, "lineage-IID same-slot aggregation")
            .map_err(|_error| LineageIidError::ArrivalAggregateOverflow { queue })?;
        Ok(())
    }

    pub(crate) fn finish(&mut self) -> Result<&[Arrival], LineageIidError> {
        self.touched.sort_unstable();
        self.sparse_arrivals.clear();
        for &queue in &self.touched {
            let position = queue
                .as_usize()
                .filter(|position| *position < self.dense_counts.len())
                .ok_or(LineageIidError::PreparedInvariant {
                    invariant: "touched queue is in range",
                })?;
            let count = self.dense_counts[position];
            if count == RuntimeCount::ZERO {
                return Err(LineageIidError::PreparedInvariant {
                    invariant: "touched queue has positive aggregate",
                });
            }
            if self.sparse_arrivals.len() == self.sparse_arrivals.capacity() {
                return Err(LineageIidError::PreparedInvariant {
                    invariant: "sparse-arrival scratch has prepared capacity",
                });
            }
            self.sparse_arrivals.push(Arrival::new(queue, count));
            self.dense_counts[position] = RuntimeCount::ZERO;
        }
        self.touched.clear();
        Ok(&self.sparse_arrivals)
    }

    pub(crate) fn discard_partial(&mut self) {
        for queue in self.touched.drain(..) {
            if let Some(count) = queue
                .as_usize()
                .and_then(|position| self.dense_counts.get_mut(position))
            {
                *count = RuntimeCount::ZERO;
            }
        }
        self.sparse_arrivals.clear();
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum LineageIidError {
    #[error("the lineage-IID queue catalog must be nonempty")]
    EmptyQueueCatalog,
    #[error("the lineage-IID queue count exceeds dense u32 identity")]
    QueueCountTooLarge,
    #[error("the lineage-IID source table must be nonempty")]
    EmptySourceTable,
    #[error("the lineage-IID source count exceeds dense u32 identity")]
    SourceCountTooLarge,
    #[error("source {source_index} has an empty or noncanonical resolved source ID")]
    InvalidSourceId { source_index: usize },
    #[error("source {source_index} duplicates an earlier resolved source ID")]
    DuplicateSourceId { source_index: usize },
    #[error("source {source_index} arrival probability must lie in (0,1]")]
    InvalidArrivalProbability { source_index: usize },
    #[error("source {source_index} has no conditional destinations")]
    EmptyDestinationRow { source_index: usize },
    #[error("source {source_index} destination {destination} names an out-of-range queue")]
    DestinationQueueOutOfRange {
        source_index: usize,
        destination: usize,
    },
    #[error("source {source_index} destination {destination} duplicates an earlier queue")]
    DuplicateDestinationQueue {
        source_index: usize,
        destination: usize,
    },
    #[error("source {source_index} destination {destination} probability must lie in [0,1]")]
    InvalidDestinationProbability {
        source_index: usize,
        destination: usize,
    },
    #[error(
        "source {source_index} conditional destination probabilities must sum exactly to one"
    )]
    DestinationRowNotNormalized { source_index: usize },
    #[error("source {source_index} probability data exceeds exact u128 preparation")]
    ProbabilityRepresentationBound { source_index: usize },
    #[error("source {source_index} exact probability preparation overflowed")]
    ProbabilityArithmeticOverflow { source_index: usize },
    #[error("lineage-IID preparation or scratch allocation was refused")]
    CapacityExceeded,
    #[error("the lineage-IID RNG is bound to a different configured law")]
    RngLawBindingMismatch,
    #[error("child lineage ensemble {actual} differs from RNG ensemble {expected}")]
    LineageEnsembleMismatch { expected: u64, actual: u64 },
    #[error("lineage-IID scratch has queue width {actual}, expected {expected}")]
    ScratchQueueCountMismatch { expected: usize, actual: usize },
    #[error("an exact lineage-addressed random draw was refused")]
    RandomDrawRefused,
    #[error("same-slot IID arrival aggregation overflowed at queue {queue:?}")]
    ArrivalAggregateOverflow { queue: QueueIndex },
    #[error("prepared lineage-IID invariant failed: {invariant}")]
    PreparedInvariant { invariant: &'static str },
}

fn validate_source_ids(sources: &[QualifiedIidSource]) -> Result<(), LineageIidError> {
    let mut seen = HashSet::with_hasher(Cp07DeterministicBuildHasher::default());
    seen.try_reserve(sources.len())
        .map_err(|_error| LineageIidError::CapacityExceeded)?;
    for (source_index, row) in sources.iter().enumerate() {
        if row.source_id.as_str().is_empty()
            || !is_normalized_active_token(row.source_id.as_str())?
        {
            return Err(LineageIidError::InvalidSourceId { source_index });
        }
        if !seen.insert(&row.source_id) {
            return Err(LineageIidError::DuplicateSourceId { source_index });
        }
    }
    Ok(())
}

fn is_normalized_active_token(value: &str) -> Result<bool, LineageIidError> {
    let mut normalized = String::new();
    normalized
        .try_reserve(value.len())
        .map_err(|_error| LineageIidError::CapacityExceeded)?;
    let mut separator_pending = false;
    for character in value.trim().chars().flat_map(char::to_lowercase) {
        if matches!(character, '-' | ' ' | '_') {
            if !normalized.is_empty() {
                separator_pending = true;
            }
        } else {
            if separator_pending {
                normalized
                    .try_reserve(1)
                    .map_err(|_error| LineageIidError::CapacityExceeded)?;
                normalized.push('_');
                separator_pending = false;
            }
            normalized
                .try_reserve(character.len_utf8())
                .map_err(|_error| LineageIidError::CapacityExceeded)?;
            normalized.push(character);
        }
    }
    Ok(normalized == value)
}

fn prepare_destination_row(
    destinations: Vec<QualifiedIidDestination>,
    queue_count: usize,
    source_index: usize,
) -> Result<PreparedIidDestinationRow, LineageIidError> {
    if destinations.is_empty() {
        return Err(LineageIidError::EmptyDestinationRow { source_index });
    }
    if u32::try_from(destinations.len() - 1).is_err() {
        return Err(LineageIidError::ProbabilityRepresentationBound { source_index });
    }

    let mut queues = try_vec(destinations.len())?;
    let mut probabilities = try_vec(destinations.len())?;
    for (destination, row) in destinations.iter().enumerate() {
        let position = row.queue.as_usize().filter(|index| *index < queue_count).ok_or(
            LineageIidError::DestinationQueueOutOfRange {
                source_index,
                destination,
            },
        )?;
        if destinations[..destination]
            .iter()
            .any(|earlier| earlier.queue == row.queue)
        {
            return Err(LineageIidError::DuplicateDestinationQueue {
                source_index,
                destination,
            });
        }
        debug_assert!(position < queue_count);
        queues.push(row.queue);
        probabilities.push(&row.probability);
    }
    let distribution = prepare_probability_row(&probabilities, source_index)?;
    Ok(PreparedIidDestinationRow {
        distribution,
        queues,
    })
}

fn prepare_probability_row(
    probabilities: &[&ExactRational],
    source_index: usize,
) -> Result<PreparedCategorical<u32>, LineageIidError> {
    let mut parts = try_vec(probabilities.len())?;
    let mut common_denominator = 1_u128;
    for (destination, probability) in probabilities.iter().enumerate() {
        let (numerator, denominator) =
            probability_parts(probability, source_index, Some(destination))?;
        common_denominator = checked_lcm(common_denominator, denominator)
            .ok_or(LineageIidError::ProbabilityArithmeticOverflow { source_index })?;
        parts.push((numerator, denominator));
    }

    let mut masses = try_vec(parts.len())?;
    for (numerator, denominator) in parts {
        let scale = common_denominator / denominator;
        masses.push(
            numerator
                .checked_mul(scale)
                .ok_or(LineageIidError::ProbabilityArithmeticOverflow { source_index })?,
        );
    }
    let sum = masses
        .iter()
        .try_fold(0_u128, |total, mass| total.checked_add(*mass))
        .ok_or(LineageIidError::ProbabilityArithmeticOverflow { source_index })?;
    if sum != common_denominator {
        return Err(LineageIidError::DestinationRowNotNormalized { source_index });
    }
    let divisor = masses.iter().copied().fold(0_u128, gcd);
    if divisor == 0 {
        return Err(LineageIidError::DestinationRowNotNormalized { source_index });
    }
    for mass in &mut masses {
        *mass /= divisor;
    }

    let mut outcomes = try_vec(probabilities.len())?;
    for index in 0..probabilities.len() {
        outcomes.push(
            u32::try_from(index)
                .map_err(|_error| LineageIidError::ProbabilityRepresentationBound {
                    source_index,
                })?,
        );
    }
    PreparedCategorical::try_from_ordered_integer_masses(outcomes, masses)
        .ok_or(LineageIidError::CapacityExceeded)
}

fn probability_parts(
    probability: &ExactRational,
    source_index: usize,
    destination: Option<usize>,
) -> Result<(u128, u128), LineageIidError> {
    let signed_numerator = probability.numerator();
    let denominator = probability.denominator();
    let numerator_big = signed_numerator.as_bigint().magnitude();
    let denominator_big = denominator.as_biguint();
    if signed_numerator.as_bigint().sign() == Sign::Minus
        || denominator_big.is_zero()
        || numerator_big > denominator_big
    {
        return Err(destination.map_or(
            LineageIidError::InvalidArrivalProbability { source_index },
            |destination| LineageIidError::InvalidDestinationProbability {
                source_index,
                destination,
            },
        ));
    }
    let numerator = numerator_big
        .to_u128()
        .ok_or(LineageIidError::ProbabilityRepresentationBound { source_index })?;
    let denominator = denominator_big
        .to_u128()
        .ok_or(LineageIidError::ProbabilityRepresentationBound { source_index })?;
    debug_assert!(denominator > 0 && numerator <= denominator);
    Ok((numerator, denominator))
}

fn checked_lcm(left: u128, right: u128) -> Option<u128> {
    let divisor = gcd(left, right);
    left.checked_div(divisor)?.checked_mul(right)
}

const fn gcd(mut left: u128, mut right: u128) -> u128 {
    while right != 0 {
        let remainder = left % right;
        left = right;
        right = remainder;
    }
    left
}

fn try_vec<T>(capacity: usize) -> Result<Vec<T>, LineageIidError> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(capacity)
        .map_err(|_error| LineageIidError::CapacityExceeded)?;
    Ok(values)
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeMap;

    use num_bigint::BigInt;

    use super::{
        compile_exact_target_arrival_marginal_v1,
        compile_exact_target_arrival_marginal_with_limits_v1, LineageIidError,
        PreparedIidSource, PreparedLineageIid, QualifiedIidDestination, QualifiedIidSource,
        TargetArrivalMarginalError, TargetArrivalMarginalLimitsV1,
        TARGET_ARRIVAL_FAMILY_ID_V1,
    };
    use crate::exact::{ExactRational, RuntimeCount};
    use crate::resolved::{SourceId, TypedId};
    use crate::rng::{select_categorical, LineageIidRng, WeIidDrawRole};
    use crate::unit_count::{QueueCatalog, QueueIndex};
    use crate::weighted_ensemble::LineageId;

    const LAW_DIGEST: [u8; 32] = [0x51; 32];
    const SEED: [u8; 32] = [0xa7; 32];

    fn ratio(numerator: i64, denominator: i64) -> ExactRational {
        ExactRational::new(
            BigInt::from(numerator),
            BigInt::from(denominator),
            "lineage IID test probability",
        )
        .expect("test ratio has nonzero denominator")
    }

    fn catalog(queue_count: usize) -> QueueCatalog {
        QueueCatalog::try_new(
            (0..queue_count)
                .map(|index| TypedId::from(format!("q{index}")))
                .collect(),
        )
        .expect("test queue catalog is canonical")
    }

    fn destination(queue: u32, numerator: i64, denominator: i64) -> QualifiedIidDestination {
        QualifiedIidDestination {
            queue: QueueIndex(queue),
            probability: ratio(numerator, denominator),
        }
    }

    fn source(
        id: &str,
        numerator: i64,
        denominator: i64,
        destinations: Vec<QualifiedIidDestination>,
    ) -> QualifiedIidSource {
        QualifiedIidSource {
            source_id: SourceId::new(id.to_owned()),
            arrival_probability: ratio(numerator, denominator),
            destinations,
        }
    }

    fn prepared_sources(prepared: &PreparedLineageIid) -> &[PreparedIidSource] {
        &prepared.sources
    }

    #[test]
    fn exact_factorized_source_laws_match_explicit_small_joint_enumeration() {
        let prepared = PreparedLineageIid::try_new(
            catalog(2),
            LAW_DIGEST,
            vec![
                source(
                    "alpha",
                    1,
                    2,
                    vec![destination(0, 1, 3), destination(1, 2, 3)],
                ),
                source(
                    "beta",
                    2,
                    3,
                    vec![destination(0, 3, 4), destination(1, 1, 4)],
                ),
            ],
        )
        .expect("small exact source table prepares");

        let mut compact = BTreeMap::<Vec<u64>, u128>::new();
        let first = &prepared_sources(&prepared)[0];
        let second = &prepared_sources(&prepared)[1];
        for first_occurrence in 0..first.occurrence_denominator {
            for first_destination in 0..first.destinations.distribution.total_mass() {
                for second_occurrence in 0..second.occurrence_denominator {
                    for second_destination in 0..second.destinations.distribution.total_mass() {
                        let mut counts = vec![0_u64; 2];
                        add_enumerated(
                            first,
                            first_occurrence,
                            first_destination,
                            &mut counts,
                        );
                        add_enumerated(
                            second,
                            second_occurrence,
                            second_destination,
                            &mut counts,
                        );
                        *compact.entry(counts).or_default() += 1;
                    }
                }
            }
        }

        // Explicitly compose the two source laws in the same common finite
        // sample space. alpha masses are [no=3,q0=1,q1=2] over 6 and beta
        // masses are [no=4,q0=6,q1=2] over 12.
        let mut explicit = BTreeMap::<Vec<u64>, u128>::new();
        for (first_queue, first_mass) in [(None, 3_u128), (Some(0), 1), (Some(1), 2)] {
            for (second_queue, second_mass) in
                [(None, 4_u128), (Some(0), 6), (Some(1), 2)]
            {
                let mut counts = vec![0_u64; 2];
                if let Some(queue) = first_queue {
                    counts[queue] += 1;
                }
                if let Some(queue) = second_queue {
                    counts[queue] += 1;
                }
                *explicit.entry(counts).or_default() += first_mass * second_mass;
            }
        }
        assert_eq!(compact, explicit);
    }

    fn add_enumerated(
        source: &PreparedIidSource,
        occurrence_draw: u128,
        destination_draw: u128,
        counts: &mut [u64],
    ) {
        if occurrence_draw >= source.occurrence_numerator {
            return;
        }
        let row = select_categorical(destination_draw, &source.destinations.distribution)
            .expect("enumerated residue selects an exact destination");
        let row = usize::try_from(row).expect("test destination row fits usize");
        let queue = source.destinations.queues[row];
        let queue = usize::try_from(queue.0).expect("test queue index fits usize");
        counts[queue] += 1;
    }

    #[test]
    fn simultaneous_sources_aggregate_same_queue_and_emit_canonical_sparse_order() {
        let prepared = PreparedLineageIid::try_new(
            catalog(3),
            LAW_DIGEST,
            vec![
                source("late_queue", 1, 1, vec![destination(2, 1, 1)]),
                source("same_queue", 1, 1, vec![destination(2, 1, 1)]),
                source("early_queue", 1, 1, vec![destination(0, 1, 1)]),
            ],
        )
        .expect("certain sources prepare");
        let rng = LineageIidRng::from_seed_material(SEED, LAW_DIGEST, 9);
        let mut scratch = prepared.try_scratch().expect("scratch allocates");
        let arrivals = prepared
            .sample_slot(&rng, 17, LineageId::new(9, 41), &mut scratch)
            .expect("certain arrivals sample")
            .to_vec();
        assert_eq!(arrivals.len(), 2);
        assert_eq!(arrivals[0].queue(), QueueIndex(0));
        assert_eq!(arrivals[0].count(), RuntimeCount::new(1));
        assert_eq!(arrivals[1].queue(), QueueIndex(2));
        assert_eq!(arrivals[1].count(), RuntimeCount::new(2));

        let replay = prepared
            .sample_slot(&rng, 17, LineageId::new(9, 41), &mut scratch)
            .expect("replay samples");
        assert_eq!(replay, arrivals.as_slice());
    }

    #[test]
    fn sibling_and_conditional_role_addresses_are_distinct_and_replay_exactly() {
        let rng = LineageIidRng::from_seed_material(SEED, LAW_DIGEST, 4);
        let first = rng
            .iid_address(
                3,
                LineageId::new(4, 10),
                0,
                WeIidDrawRole::ArrivalOccurrence,
                0,
            )
            .expect("valid first address")
            .encode();
        let replay = rng
            .iid_address(
                3,
                LineageId::new(4, 10),
                0,
                WeIidDrawRole::ArrivalOccurrence,
                0,
            )
            .expect("valid replay address")
            .encode();
        let sibling = rng
            .iid_address(
                3,
                LineageId::new(4, 11),
                0,
                WeIidDrawRole::ArrivalOccurrence,
                0,
            )
            .expect("valid sibling address")
            .encode();
        let conditional_destination = rng
            .iid_address(
                3,
                LineageId::new(4, 10),
                0,
                WeIidDrawRole::ConditionalDestination,
                0,
            )
            .expect("valid destination address")
            .encode();
        assert_eq!(first, replay);
        assert_ne!(first, sibling);
        assert_ne!(first, conditional_destination);
    }

    #[test]
    fn stochastic_slot_sampling_replays_with_independent_scratch() {
        let prepared = PreparedLineageIid::try_new(
            catalog(2),
            LAW_DIGEST,
            vec![
                source(
                    "first",
                    1,
                    2,
                    vec![destination(0, 1, 3), destination(1, 2, 3)],
                ),
                source(
                    "second",
                    2,
                    3,
                    vec![destination(0, 3, 4), destination(1, 1, 4)],
                ),
            ],
        )
        .expect("stochastic source table prepares");
        let rng = LineageIidRng::from_seed_material(SEED, LAW_DIGEST, 12);
        let mut left = prepared.try_scratch().expect("left scratch allocates");
        let mut right = prepared.try_scratch().expect("right scratch allocates");
        for slot in 0_u64..32 {
            let child = LineageId::new(12, 100 + slot);
            let expected = prepared
                .sample_slot(&rng, slot, child, &mut left)
                .expect("first replay samples")
                .to_vec();
            let replay = prepared
                .sample_slot(&rng, slot, child, &mut right)
                .expect("second replay samples");
            assert_eq!(replay, expected.as_slice());
        }
    }

    #[test]
    fn preparation_refuses_malformed_exact_sources() {
        assert_eq!(
            PreparedLineageIid::try_new(catalog(1), LAW_DIGEST, Vec::new()),
            Err(LineageIidError::EmptySourceTable)
        );
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("not normalized", 1, 2, vec![destination(0, 1, 1)])]
            ),
            Err(LineageIidError::InvalidSourceId { source_index: 0 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![
                    source("duplicate", 1, 2, vec![destination(0, 1, 1)]),
                    source("duplicate", 1, 2, vec![destination(0, 1, 1)])
                ]
            ),
            Err(LineageIidError::DuplicateSourceId { source_index: 1 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("zero_p", 0, 1, vec![destination(0, 1, 1)])]
            ),
            Err(LineageIidError::InvalidArrivalProbability { source_index: 0 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("large_p", 2, 1, vec![destination(0, 1, 1)])]
            ),
            Err(LineageIidError::InvalidArrivalProbability { source_index: 0 })
        ));
        let beyond_u128 = BigInt::from(1_u8) << 128_usize;
        let large_valid_probability = ExactRational::new(
            beyond_u128.clone() + BigInt::from(1_u8),
            beyond_u128 + BigInt::from(3_u8),
            "large valid lineage IID probability",
        )
        .expect("large probability has a positive denominator");
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![QualifiedIidSource {
                    source_id: SourceId::new("representation_bound".to_owned()),
                    arrival_probability: large_valid_probability,
                    destinations: vec![destination(0, 1, 1)],
                }],
            ),
            Err(LineageIidError::ProbabilityRepresentationBound { source_index: 0 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("empty", 1, 2, vec![])],
            ),
            Err(LineageIidError::EmptyDestinationRow { source_index: 0 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("range", 1, 2, vec![destination(1, 1, 1)])]
            ),
            Err(LineageIidError::DestinationQueueOutOfRange {
                source_index: 0,
                destination: 0
            })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source(
                    "duplicate_queue",
                    1,
                    2,
                    vec![destination(0, 1, 2), destination(0, 1, 2)]
                )]
            ),
            Err(LineageIidError::DuplicateDestinationQueue {
                source_index: 0,
                destination: 1
            })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(2),
                LAW_DIGEST,
                vec![source(
                    "not_normalized",
                    1,
                    2,
                    vec![destination(0, 1, 3), destination(1, 1, 3)]
                )]
            ),
            Err(LineageIidError::DestinationRowNotNormalized { source_index: 0 })
        ));
        assert!(matches!(
            PreparedLineageIid::try_new(
                catalog(1),
                LAW_DIGEST,
                vec![source("negative", 1, 2, vec![destination(0, -1, 1)])]
            ),
            Err(LineageIidError::InvalidDestinationProbability {
                source_index: 0,
                destination: 0
            })
        ));

        // Zero-mass conditional rows remain valid because the canonical C27
        // decoder permits them and exact categorical intervals simply skip
        // them.
        PreparedLineageIid::try_new(
            catalog(2),
            LAW_DIGEST,
            vec![source(
                "zero_destination",
                1,
                1,
                vec![destination(0, 0, 1), destination(1, 1, 1)],
            )],
        )
        .expect("zero conditional mass is retained exactly");
    }

    #[test]
    fn sampling_refuses_wrong_rng_law_lineage_and_scratch_width() {
        let prepared = PreparedLineageIid::try_new(
            catalog(1),
            LAW_DIGEST,
            vec![source("sole", 1, 1, vec![destination(0, 1, 1)])],
        )
        .expect("source prepares");
        let mut scratch = prepared.try_scratch().expect("scratch allocates");
        let wrong_law = LineageIidRng::from_seed_material(SEED, [0x52; 32], 1);
        assert_eq!(
            prepared.sample_slot(&wrong_law, 0, LineageId::new(1, 0), &mut scratch),
            Err(LineageIidError::RngLawBindingMismatch)
        );

        let rng = LineageIidRng::from_seed_material(SEED, LAW_DIGEST, 1);
        assert_eq!(
            prepared.sample_slot(&rng, 0, LineageId::new(2, 0), &mut scratch),
            Err(LineageIidError::LineageEnsembleMismatch {
                expected: 1,
                actual: 2
            })
        );
        let mut wrong_width = super::LineageIidScratch::try_new(2, 1)
            .expect("mismatched scratch itself allocates");
        assert_eq!(
            prepared.sample_slot(&rng, 0, LineageId::new(1, 0), &mut wrong_width),
            Err(LineageIidError::ScratchQueueCountMismatch {
                expected: 1,
                actual: 2
            })
        );
    }

    #[test]
    fn exact_target_projection_matches_the_compact_poisson_binomial_law() {
        let queues = catalog(2);
        let sources = vec![
            source(
                "s0",
                1,
                2,
                vec![destination(0, 1, 2), destination(1, 1, 2)],
            ),
            source("s1", 1, 4, vec![destination(0, 1, 1)]),
        ];
        let marginal = compile_exact_target_arrival_marginal_v1(
            &queues,
            LAW_DIGEST,
            &sources,
            QueueIndex(0),
        )
        .expect("exact target projection");
        assert_eq!(
            super::PreparedTargetArrivalMarginalV1::arrival_family_id(),
            TARGET_ARRIVAL_FAMILY_ID_V1
        );
        assert_eq!(marginal.configured_law_digest(), LAW_DIGEST);
        assert!(marginal.is_bound_to_configured_law(&LAW_DIGEST));
        assert!(!marginal.is_bound_to_configured_law(&[0_u8; 32]));
        let atoms = marginal.atoms();
        assert_eq!(atoms.len(), 3);
        assert_eq!(atoms[0].batch_size().to_string(), "0");
        assert_eq!(atoms[0].probability(), &ratio(9, 16));
        assert_eq!(atoms[1].batch_size().to_string(), "1");
        assert_eq!(atoms[1].probability(), &ratio(3, 8));
        assert_eq!(atoms[2].batch_size().to_string(), "2");
        assert_eq!(atoms[2].probability(), &ratio(1, 16));
        assert_eq!(marginal.mean(), &ratio(1, 2));
        assert_eq!(marginal.second_moment(), &ratio(5, 8));
    }

    #[test]
    fn exact_target_projection_omits_zero_mass_and_retains_absent_target_zero() {
        let queues = catalog(2);
        let certain = vec![source("certain", 1, 1, vec![destination(0, 1, 1)])];
        let marginal = compile_exact_target_arrival_marginal_v1(
            &queues,
            LAW_DIGEST,
            &certain,
            QueueIndex(0),
        )
        .expect("certain target projection");
        assert_eq!(marginal.atoms().len(), 1);
        assert_eq!(marginal.atoms()[0].batch_size().to_string(), "1");
        assert_eq!(marginal.atoms()[0].probability(), &ratio(1, 1));

        let absent = compile_exact_target_arrival_marginal_v1(
            &queues,
            LAW_DIGEST,
            &certain,
            QueueIndex(1),
        )
        .expect("absent target projection");
        assert_eq!(absent.atoms().len(), 1);
        assert_eq!(absent.atoms()[0].batch_size().to_string(), "0");
        assert_eq!(absent.atoms()[0].probability(), &ratio(1, 1));
        assert_eq!(absent.mean(), &ratio(0, 1));
        assert_eq!(absent.second_moment(), &ratio(0, 1));
    }

    #[test]
    fn exact_target_projection_enforces_the_framework_integer_bound() {
        let queues = catalog(1);
        let sources = vec![source("half", 1, 2, vec![destination(0, 1, 1)])];
        let error = compile_exact_target_arrival_marginal_with_limits_v1(
            &queues,
            LAW_DIGEST,
            &sources,
            QueueIndex(0),
            TargetArrivalMarginalLimitsV1 {
                maximum_atoms: 2,
                maximum_integer_bits: 1,
                maximum_integer_decimal_digits: 1,
            },
        )
        .expect_err("denominator two exceeds a one-bit limit");
        assert_eq!(
            error,
            TargetArrivalMarginalError::IntegerMagnitudeLimitExceeded
        );

        let certain = (0..4)
            .map(|index| {
                source(
                    &format!("certain_{index}"),
                    1,
                    1,
                    vec![destination(0, 1, 1)],
                )
            })
            .collect::<Vec<_>>();
        let count_error = compile_exact_target_arrival_marginal_with_limits_v1(
            &queues,
            LAW_DIGEST,
            &certain,
            QueueIndex(0),
            TargetArrivalMarginalLimitsV1 {
                maximum_atoms: 1,
                maximum_integer_bits: 2,
                maximum_integer_decimal_digits: 1,
            },
        )
        .expect_err("batch count four exceeds a two-bit limit");
        assert_eq!(
            count_error,
            TargetArrivalMarginalError::IntegerMagnitudeLimitExceeded
        );
    }

    #[test]
    fn exact_target_projection_enforces_the_positive_atom_cap() {
        let queues = catalog(1);
        let sources = vec![
            source("first", 1, 2, vec![destination(0, 1, 1)]),
            source("second", 1, 2, vec![destination(0, 1, 1)]),
        ];
        let error = compile_exact_target_arrival_marginal_with_limits_v1(
            &queues,
            LAW_DIGEST,
            &sources,
            QueueIndex(0),
            TargetArrivalMarginalLimitsV1 {
                maximum_atoms: 2,
                ..TargetArrivalMarginalLimitsV1::default()
            },
        )
        .expect_err("two fractional sources require three positive atoms");
        assert_eq!(error, TargetArrivalMarginalError::AtomLimitExceeded);
    }
}
