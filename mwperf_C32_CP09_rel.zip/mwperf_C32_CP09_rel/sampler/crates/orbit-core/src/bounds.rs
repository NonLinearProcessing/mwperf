//! Exact representability and deterministic-resource receipts for the five
//! retained occupancy-MaxWeight compilers.
//!
//! Each backend emits one closed service-optimizer contribution. Accepting it
//! validates every touched machine representation before the prepared
//! optimizer is released.

use std::collections::BTreeMap;
use std::fmt;

use num_bigint::BigUint;
use num_traits::ToPrimitive;
use thiserror::Error;

use crate::exact::ExactUnsigned;

/// The five retained exact service-family compilers.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum ServiceContributor {
    CrossbarHungarian,
    NodeExclusiveBlossom,
    IntervalDynamicProgram,
    ConflictGraphExactMwis,
    BinaryPackingBranchAndBound,
}

/// Closed identity for a bound-producing compiler.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum ContributorId {
    Service(ServiceContributor),
}

/// The retained simultaneously-live allocation class.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum AllocationClass {
    ConstraintWorkspace,
}

/// The retained deterministic work-stack class.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum WorkStackClass {
    ConstraintSolver,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
enum AggregationPolicy {
    Maximum,
    Sum,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum RepresentationPolicy {
    U32,
    Usize,
}

impl fmt::Display for RepresentationPolicy {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::U32 => formatter.write_str("u32"),
            Self::Usize => formatter.write_str("usize"),
        }
    }
}

/// Closed quantities emitted by every retained backend compiler.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum QuantityKey {
    DenseQueueCount,
    DenseResourceCount,
    AllocationElements(AllocationClass),
    AllocationBytes(AllocationClass),
    WorkStackDepth(WorkStackClass),
}

impl QuantityKey {
    const fn aggregation(self) -> AggregationPolicy {
        match self {
            Self::AllocationElements(_) | Self::AllocationBytes(_) => AggregationPolicy::Sum,
            Self::DenseQueueCount | Self::DenseResourceCount | Self::WorkStackDepth(_) => {
                AggregationPolicy::Maximum
            }
        }
    }

    const fn representation(self) -> RepresentationPolicy {
        match self {
            Self::DenseQueueCount | Self::DenseResourceCount => RepresentationPolicy::U32,
            Self::AllocationElements(_) | Self::AllocationBytes(_) | Self::WorkStackDepth(_) => {
                RepresentationPolicy::Usize
            }
        }
    }
}

/// Compilation owner used for bounded diagnostics and audit provenance.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) enum BoundStage {
    ConstraintCompilation,
}

/// Bounded diagnostic provenance. Paths are descriptive only and never select
/// aggregation behavior.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub(crate) struct BoundProvenance {
    stage: BoundStage,
    path: String,
    quantity: &'static str,
}

impl BoundProvenance {
    pub(crate) fn new(stage: BoundStage, path: impl Into<String>, quantity: &'static str) -> Self {
        Self {
            stage,
            path: path.into(),
            quantity,
        }
    }
}

impl fmt::Display for BoundProvenance {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "{:?} at {} ({})",
            self.stage, self.path, self.quantity
        )
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct BoundClaim {
    upper: BigUint,
    provenance: BoundProvenance,
}

/// All exact claims emitted atomically by one retained backend compiler.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct BoundContribution {
    contributor: ContributorId,
    claims: BTreeMap<QuantityKey, BoundClaim>,
}

impl BoundContribution {
    pub(crate) const fn new(contributor: ContributorId) -> Self {
        Self {
            contributor,
            claims: BTreeMap::new(),
        }
    }

    pub(crate) fn insert(
        &mut self,
        quantity: QuantityKey,
        upper: ExactUnsigned,
        provenance: BoundProvenance,
    ) -> Result<(), BoundError> {
        if self.claims.contains_key(&quantity) {
            return Err(BoundError::DuplicateClaim {
                contributor: self.contributor,
                quantity,
            });
        }
        self.claims.insert(
            quantity,
            BoundClaim {
                upper: upper.into_biguint(),
                provenance,
            },
        );
        Ok(())
    }
}

/// A compiled value whose bound contribution must be accepted before use.
#[derive(Debug, Eq, PartialEq)]
pub(crate) struct BoundCertified<T> {
    value: T,
    contribution: BoundContribution,
}

impl<T> BoundCertified<T> {
    pub(crate) fn new(value: T, contribution: BoundContribution) -> Result<Self, BoundError> {
        if contribution.claims.is_empty() {
            return Err(BoundError::EmptyContribution {
                contributor: contribution.contributor,
            });
        }
        Ok(Self {
            value,
            contribution,
        })
    }
}

/// Atomic receipt collector used while one optimizer is prepared.
#[derive(Debug, Default, Eq, PartialEq)]
pub(crate) struct BoundDraft {
    aggregates: BTreeMap<QuantityKey, BigUint>,
    receipts: BTreeMap<(ContributorId, QuantityKey), BoundClaim>,
}

impl BoundDraft {
    pub(crate) const fn new() -> Self {
        Self {
            aggregates: BTreeMap::new(),
            receipts: BTreeMap::new(),
        }
    }

    /// Validate the complete contribution prospectively, commit its receipts,
    /// and only then release the compiled value.
    pub(crate) fn accept<T>(&mut self, certified: BoundCertified<T>) -> Result<T, BoundError> {
        let BoundCertified {
            value,
            contribution,
        } = certified;
        self.accept_contribution(contribution)?;
        Ok(value)
    }

    fn accept_contribution(&mut self, contribution: BoundContribution) -> Result<(), BoundError> {
        if contribution.claims.is_empty() {
            return Err(BoundError::EmptyContribution {
                contributor: contribution.contributor,
            });
        }
        for quantity in contribution.claims.keys() {
            if self
                .receipts
                .contains_key(&(contribution.contributor, *quantity))
            {
                return Err(BoundError::DuplicateReceipt {
                    contributor: contribution.contributor,
                    quantity: *quantity,
                });
            }
        }

        let mut updates = BTreeMap::new();
        for (quantity, claim) in &contribution.claims {
            let aggregate = combine(self.aggregates.get(quantity), &claim.upper, *quantity);
            check_representation(*quantity, &aggregate, &claim.provenance)?;
            updates.insert(*quantity, aggregate);
        }

        for (quantity, aggregate) in updates {
            self.aggregates.insert(quantity, aggregate);
        }
        for (quantity, claim) in contribution.claims {
            self.receipts
                .insert((contribution.contributor, quantity), claim);
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub(crate) enum BoundError {
    #[error("bound contributor {contributor:?} supplied no claims")]
    EmptyContribution { contributor: ContributorId },
    #[error("bound contributor {contributor:?} repeated claim {quantity:?}")]
    DuplicateClaim {
        contributor: ContributorId,
        quantity: QuantityKey,
    },
    #[error("bound receipt {contributor:?}/{quantity:?} was installed more than once")]
    DuplicateReceipt {
        contributor: ContributorId,
        quantity: QuantityKey,
    },
    #[error("aggregate {quantity:?} exceeded its {representation} representation at {provenance}")]
    RepresentationExceeded {
        quantity: QuantityKey,
        representation: RepresentationPolicy,
        provenance: BoundProvenance,
    },
}

fn combine(existing: Option<&BigUint>, contribution: &BigUint, quantity: QuantityKey) -> BigUint {
    match quantity.aggregation() {
        AggregationPolicy::Maximum => existing.map_or_else(
            || contribution.clone(),
            |value| value.max(contribution).clone(),
        ),
        AggregationPolicy::Sum => existing.cloned().unwrap_or_default() + contribution,
    }
}

fn check_representation(
    quantity: QuantityKey,
    value: &BigUint,
    provenance: &BoundProvenance,
) -> Result<(), BoundError> {
    let representation = quantity.representation();
    let fits = match representation {
        RepresentationPolicy::U32 => value.to_u32().is_some(),
        RepresentationPolicy::Usize => value.to_usize().is_some(),
    };
    if fits {
        Ok(())
    } else {
        Err(BoundError::RepresentationExceeded {
            quantity,
            representation,
            provenance: provenance.clone(),
        })
    }
}
