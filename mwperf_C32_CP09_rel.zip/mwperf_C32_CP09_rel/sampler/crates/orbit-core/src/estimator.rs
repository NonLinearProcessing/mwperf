//! Canonical CP03 replication grants, path-free evidence, and estimator.
//!
//! Replication workers own independent addressed physical runs. Their only
//! return value is one bounded report. Aggregation first restores canonical
//! replication-coordinate order, reconciles every scientific grant and
//! physical endpoint, and only then forms ratios of aggregate integer counts.

use num_bigint::BigInt;
use thiserror::Error;

use crate::construction_observation::ConstructionObservationReplicationV1;
use crate::direct_count_arrivals::ArrivalReplay;
use crate::engine::{
    ConstructionWorkCounters, ConstructionWorkLimits, CountRunResult, MutableMemoryAccounting,
    OptimizerSearchStateGrant, ProviderEndpointIdentity, TargetWindowReconciliation,
};
use crate::error::{RunError, RuntimeStage};
use crate::exact::{ExactRational, RuntimeCount};
use crate::response_observer::ResponseLedger;

const RESPONSE_BIN_COUNT: usize = 4;
const FITTED_BIN_COUNT: usize = 3;

/// Canonical zero-based whole-path replication coordinate.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ReplicationCoordinate(u64);

impl ReplicationCoordinate {
    pub const fn new(index: u64) -> Self {
        Self(index)
    }

    pub const fn index(self) -> u64 {
        self.0
    }
}

/// A quotient/remainder partition of the request's one global scientific
/// grant. It is immutable and therefore independent of worker scheduling.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ScientificGrantPartition {
    replications: u64,
    global: ConstructionWorkLimits,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ScientificGrantReservation {
    coordinate: ReplicationCoordinate,
    maximum_configured_generator_draws: u64,
    maximum_exact_optimizer_calls: u64,
    optimizer_search_states: OptimizerSearchStateGrant,
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum EstimatorInvocationError {
    #[error("replication count is zero")]
    ZeroReplications,
    #[error("replication coordinate {coordinate} is outside 0..{replications}")]
    CoordinateOutOfRange { coordinate: u64, replications: u64 },
    #[error("replication report count differs from the declared population")]
    ReportCountMismatch,
    #[error("replication coordinates are duplicated or incomplete")]
    NonCanonicalCoordinateSet,
    #[error("a deterministic per-replication scientific grant is unusable: {detail}")]
    UnusableGrant { detail: String },
    #[error("aggregate work overflow contradicts the deterministic global grant partition")]
    InconsistentWorkAggregate,
    #[error("observation aggregation capacity could not be reserved")]
    ObservationAggregationCapacity,
    #[error("replication {coordinate} observation retention failed: {detail}")]
    ObservationFinalization { coordinate: u64, detail: String },
    #[error("replication {coordinate} did not retain its required observation record")]
    MissingObservation { coordinate: u64 },
    #[error("replication {coordinate} did not retain its pure arrival-stream digest")]
    MissingArrivalStreamDigest { coordinate: u64 },
}

impl ScientificGrantPartition {
    pub fn try_new(
        replications: u64,
        global: ConstructionWorkLimits,
    ) -> Result<Self, EstimatorInvocationError> {
        if replications == 0 {
            return Err(EstimatorInvocationError::ZeroReplications);
        }
        Ok(Self {
            replications,
            global,
        })
    }

    pub const fn replications(self) -> u64 {
        self.replications
    }

    pub const fn global(self) -> ConstructionWorkLimits {
        self.global
    }

    pub fn reservation(
        self,
        coordinate: ReplicationCoordinate,
    ) -> Result<ScientificGrantReservation, EstimatorInvocationError> {
        if coordinate.index() >= self.replications {
            return Err(EstimatorInvocationError::CoordinateOutOfRange {
                coordinate: coordinate.index(),
                replications: self.replications,
            });
        }
        let optimizer_search_states = match self.global.optimizer_search_states() {
            OptimizerSearchStateGrant::NotApplicable => OptimizerSearchStateGrant::NotApplicable,
            OptimizerSearchStateGrant::Bounded(total) => OptimizerSearchStateGrant::Bounded(
                partition_scalar(total, self.replications, coordinate.index()),
            ),
        };
        Ok(ScientificGrantReservation {
            coordinate,
            maximum_configured_generator_draws: partition_scalar(
                self.global.maximum_configured_generator_draws(),
                self.replications,
                coordinate.index(),
            ),
            maximum_exact_optimizer_calls: partition_scalar(
                self.global.maximum_exact_optimizer_calls(),
                self.replications,
                coordinate.index(),
            ),
            optimizer_search_states,
        })
    }
}

impl ScientificGrantReservation {
    pub const fn coordinate(self) -> ReplicationCoordinate {
        self.coordinate
    }

    pub const fn maximum_configured_generator_draws(self) -> u64 {
        self.maximum_configured_generator_draws
    }

    pub const fn maximum_exact_optimizer_calls(self) -> u64 {
        self.maximum_exact_optimizer_calls
    }

    pub const fn optimizer_search_states(self) -> OptimizerSearchStateGrant {
        self.optimizer_search_states
    }

    pub fn try_work_limits(self) -> Result<ConstructionWorkLimits, EstimatorInvocationError> {
        ConstructionWorkLimits::try_new(
            self.maximum_exact_optimizer_calls,
            self.optimizer_search_states,
            self.maximum_configured_generator_draws,
        )
        .map_err(|error| EstimatorInvocationError::UnusableGrant {
            detail: error.to_string(),
        })
    }
}

const fn partition_scalar(total: u64, count: u64, coordinate: u64) -> u64 {
    let quotient = total / count;
    let remainder = total % count;
    quotient + if coordinate < remainder { 1 } else { 0 }
}

/// Complete bounded success evidence returned by one worker. No queue vector,
/// slot coordinate, provider cursor, or physical path is retained.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicationEvidence {
    coordinate: ReplicationCoordinate,
    replay: ArrivalReplay,
    response: ResponseLedger,
    reconciliation: TargetWindowReconciliation,
    provider_endpoint: ProviderEndpointIdentity,
    work: ConstructionWorkCounters,
    limits: ConstructionWorkLimits,
    peak_memory: MutableMemoryAccounting,
    endpoint_memory: MutableMemoryAccounting,
}

impl ReplicationEvidence {
    pub(crate) fn from_count_run(
        coordinate: ReplicationCoordinate,
        result: CountRunResult,
    ) -> Self {
        Self {
            coordinate,
            replay: result.replay(),
            response: *result.response(),
            reconciliation: result.target_reconciliation(),
            provider_endpoint: result.provider_endpoint_identity(),
            work: result.work(),
            limits: result.limits(),
            peak_memory: result.peak_memory(),
            endpoint_memory: result.endpoint_memory(),
        }
    }

    #[cfg(test)]
    fn for_test(
        coordinate: u64,
        response: ResponseLedger,
        reconciliation: TargetWindowReconciliation,
        work: ConstructionWorkCounters,
        limits: ConstructionWorkLimits,
        horizon: RuntimeCount,
    ) -> Self {
        let tag = u8::try_from(coordinate).expect("test coordinate fits u8");
        Self {
            coordinate: ReplicationCoordinate::new(coordinate),
            replay: ArrivalReplay::from_seed_material([tag; 32], coordinate),
            response,
            reconciliation,
            provider_endpoint: ProviderEndpointIdentity::for_test(horizon, tag),
            work,
            limits,
            peak_memory: MutableMemoryAccounting::zero_for_test(),
            endpoint_memory: MutableMemoryAccounting::zero_for_test(),
        }
    }

    pub const fn coordinate(&self) -> ReplicationCoordinate {
        self.coordinate
    }
    pub const fn replay(&self) -> ArrivalReplay {
        self.replay
    }
    pub const fn response(&self) -> &ResponseLedger {
        &self.response
    }
    pub const fn reconciliation(&self) -> TargetWindowReconciliation {
        self.reconciliation
    }
    pub const fn provider_endpoint(&self) -> ProviderEndpointIdentity {
        self.provider_endpoint
    }
    pub const fn work(&self) -> ConstructionWorkCounters {
        self.work
    }
    pub const fn limits(&self) -> ConstructionWorkLimits {
        self.limits
    }
    pub const fn peak_memory(&self) -> MutableMemoryAccounting {
        self.peak_memory
    }
    pub const fn endpoint_memory(&self) -> MutableMemoryAccounting {
        self.endpoint_memory
    }
}

/// Path-free durable state present when a validly invoked physical replication
/// fails after initialization.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FailureEndpointEvidence {
    boundary: RuntimeCount,
    target_backlog: RuntimeCount,
    target_window_start: Option<(RuntimeCount, RuntimeCount, RuntimeCount)>,
    response: ResponseLedger,
    provider_endpoint: ProviderEndpointIdentity,
    endpoint_total_arrivals: RuntimeCount,
    endpoint_total_services: RuntimeCount,
    endpoint_total_occupancy: u128,
    peak_memory: MutableMemoryAccounting,
    endpoint_memory: MutableMemoryAccounting,
}

impl FailureEndpointEvidence {
    #[allow(clippy::too_many_arguments)]
    pub(crate) const fn new(
        boundary: RuntimeCount,
        target_backlog: RuntimeCount,
        target_window_start: Option<(RuntimeCount, RuntimeCount, RuntimeCount)>,
        response: ResponseLedger,
        provider_endpoint: ProviderEndpointIdentity,
        endpoint_total_arrivals: RuntimeCount,
        endpoint_total_services: RuntimeCount,
        endpoint_total_occupancy: u128,
        peak_memory: MutableMemoryAccounting,
        endpoint_memory: MutableMemoryAccounting,
    ) -> Self {
        Self {
            boundary,
            target_backlog,
            target_window_start,
            response,
            provider_endpoint,
            endpoint_total_arrivals,
            endpoint_total_services,
            endpoint_total_occupancy,
            peak_memory,
            endpoint_memory,
        }
    }

    pub const fn boundary(self) -> RuntimeCount {
        self.boundary
    }
    pub const fn target_backlog(self) -> RuntimeCount {
        self.target_backlog
    }
    pub const fn target_window_start(self) -> Option<(RuntimeCount, RuntimeCount, RuntimeCount)> {
        self.target_window_start
    }
    pub const fn response(self) -> ResponseLedger {
        self.response
    }
    pub const fn provider_endpoint(self) -> ProviderEndpointIdentity {
        self.provider_endpoint
    }
    pub const fn endpoint_total_arrivals(self) -> RuntimeCount {
        self.endpoint_total_arrivals
    }
    pub const fn endpoint_total_services(self) -> RuntimeCount {
        self.endpoint_total_services
    }
    pub const fn endpoint_total_occupancy(self) -> u128 {
        self.endpoint_total_occupancy
    }
    pub const fn peak_memory(self) -> MutableMemoryAccounting {
        self.peak_memory
    }
    pub const fn endpoint_memory(self) -> MutableMemoryAccounting {
        self.endpoint_memory
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProviderFailureReason {
    ScientificGrantExceeded,
    ExactSolverNoIncumbent,
    ArithmeticBound,
    ArrivalInvariant,
    OptimizerInvariant,
    CarrierInvariant,
    ObserverInvariant,
    ConstructionInvariant,
    ResourceExhausted,
}

impl ProviderFailureReason {
    pub(crate) fn from_run_error(error: &RunError) -> Self {
        match error {
            RunError::ScientificGrantExhausted { .. } => Self::ScientificGrantExceeded,
            RunError::ExactOptimizerNoIncumbent { .. } => Self::ExactSolverNoIncumbent,
            RunError::ArithmeticOverflow { .. } => Self::ArithmeticBound,
            RunError::ArrivalContractViolation { .. } => Self::ArrivalInvariant,
            RunError::OptimizerContractViolation { .. }
            | RunError::ExactOptimizerFailure { .. } => Self::OptimizerInvariant,
            RunError::CarrierInvariantViolation { .. } => Self::CarrierInvariant,
            RunError::ResultInvariantViolation { stage, .. }
                if *stage == RuntimeStage::SlotObserverPreflight =>
            {
                Self::ObserverInvariant
            }
            RunError::ResultInvariantViolation { .. } => Self::ConstructionInvariant,
            RunError::ResourceExhausted { .. } => Self::ResourceExhausted,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReplicationFailureEvidence {
    coordinate: ReplicationCoordinate,
    replay: ArrivalReplay,
    reason: ProviderFailureReason,
    error: RunError,
    limits: ConstructionWorkLimits,
    work: ConstructionWorkCounters,
    endpoint: Option<Box<FailureEndpointEvidence>>,
}

impl ReplicationFailureEvidence {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        coordinate: ReplicationCoordinate,
        replay: ArrivalReplay,
        reason: ProviderFailureReason,
        error: RunError,
        limits: ConstructionWorkLimits,
        work: ConstructionWorkCounters,
        endpoint: Option<Box<FailureEndpointEvidence>>,
    ) -> Self {
        Self {
            coordinate,
            replay,
            reason,
            error,
            limits,
            work,
            endpoint,
        }
    }

    pub const fn coordinate(&self) -> ReplicationCoordinate {
        self.coordinate
    }
    pub const fn replay(&self) -> ArrivalReplay {
        self.replay
    }
    pub const fn reason(&self) -> ProviderFailureReason {
        self.reason
    }
    pub const fn error(&self) -> &RunError {
        &self.error
    }
    pub const fn limits(&self) -> ConstructionWorkLimits {
        self.limits
    }
    pub const fn work(&self) -> ConstructionWorkCounters {
        self.work
    }
    pub fn endpoint(&self) -> Option<&FailureEndpointEvidence> {
        self.endpoint.as_deref()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReplicationReport {
    Completed(Box<ReplicationEvidence>),
    Failed(Box<ReplicationFailureEvidence>),
}

/// Observation-capable sibling of the frozen CP03 report.  The legacy report
/// remains byte-for-byte unchanged; a complete or recoverable partial
/// diagnostic record travels alongside it and is never used to manufacture a
/// surrogate success.
#[derive(Clone, Debug, PartialEq)]
pub struct ObservedReplicationReport {
    report: ReplicationReport,
    observation: Option<ConstructionObservationReplicationV1>,
    arrival_stream_digest: Option<[u8; 32]>,
    observation_error: Option<RunError>,
}

impl ObservedReplicationReport {
    pub(crate) const fn new(
        report: ReplicationReport,
        observation: Option<ConstructionObservationReplicationV1>,
        arrival_stream_digest: Option<[u8; 32]>,
        observation_error: Option<RunError>,
    ) -> Self {
        Self {
            report,
            observation,
            arrival_stream_digest,
            observation_error,
        }
    }

    pub const fn coordinate(&self) -> ReplicationCoordinate {
        self.report.coordinate()
    }

    pub const fn report(&self) -> &ReplicationReport {
        &self.report
    }

    pub const fn observation(&self) -> Option<&ConstructionObservationReplicationV1> {
        self.observation.as_ref()
    }

    pub const fn observation_error(&self) -> Option<&RunError> {
        self.observation_error.as_ref()
    }

    /// Digest of only the actually committed canonical sparse arrival
    /// batches. Unlike the observation wire's addressed `replay_identity`, it
    /// intentionally agrees for equal realized streams at different replay
    /// coordinates.
    pub const fn arrival_stream_digest(&self) -> Option<[u8; 32]> {
        self.arrival_stream_digest
    }

    fn into_parts(
        self,
    ) -> (
        ReplicationReport,
        Option<ConstructionObservationReplicationV1>,
        Option<[u8; 32]>,
        Option<RunError>,
    ) {
        (
            self.report,
            self.observation,
            self.arrival_stream_digest,
            self.observation_error,
        )
    }
}

impl ReplicationReport {
    pub const fn coordinate(&self) -> ReplicationCoordinate {
        match self {
            Self::Completed(evidence) => evidence.coordinate(),
            Self::Failed(evidence) => evidence.coordinate(),
        }
    }

    pub const fn limits(&self) -> ConstructionWorkLimits {
        match self {
            Self::Completed(evidence) => evidence.limits(),
            Self::Failed(evidence) => evidence.limits(),
        }
    }

    pub const fn work(&self) -> ConstructionWorkCounters {
        match self {
            Self::Completed(evidence) => evidence.work(),
            Self::Failed(evidence) => evidence.work(),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ConstructionWorkTotals {
    configured_generator_draws: u64,
    exact_optimizer_calls: u64,
    optimizer_search_states: u64,
    committed_slots: u64,
    touched_queues: u64,
    maximum_replication_peak_mutable_bytes: u64,
}

impl ConstructionWorkTotals {
    pub const fn configured_generator_draws(self) -> u64 {
        self.configured_generator_draws
    }
    pub const fn exact_optimizer_calls(self) -> u64 {
        self.exact_optimizer_calls
    }
    pub const fn optimizer_search_states(self) -> u64 {
        self.optimizer_search_states
    }
    pub const fn committed_slots(self) -> u64 {
        self.committed_slots
    }
    pub const fn touched_queues(self) -> u64 {
        self.touched_queues
    }
    pub const fn maximum_replication_peak_mutable_bytes(self) -> u64 {
        self.maximum_replication_peak_mutable_bytes
    }

    fn checked_add(self, work: ConstructionWorkCounters) -> Option<Self> {
        Some(Self {
            configured_generator_draws: self
                .configured_generator_draws
                .checked_add(work.configured_generator_draws())?,
            exact_optimizer_calls: self
                .exact_optimizer_calls
                .checked_add(work.exact_optimizer_calls())?,
            optimizer_search_states: self
                .optimizer_search_states
                .checked_add(work.optimizer_search_states())?,
            committed_slots: self.committed_slots.checked_add(work.committed_slots())?,
            touched_queues: self.touched_queues.checked_add(work.touched_queues())?,
            maximum_replication_peak_mutable_bytes: self
                .maximum_replication_peak_mutable_bytes
                .max(work.peak_mutable_bytes()),
        })
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct AggregatePrimitiveCounts {
    exposures: [RuntimeCount; RESPONSE_BIN_COUNT],
    selected: [RuntimeCount; RESPONSE_BIN_COUNT],
    scored_target_arrivals: RuntimeCount,
    target_backlog_at_w_total: RuntimeCount,
    target_backlog_at_t_total: RuntimeCount,
}

impl AggregatePrimitiveCounts {
    pub const fn exposures(self) -> [RuntimeCount; RESPONSE_BIN_COUNT] {
        self.exposures
    }
    pub const fn selected(self) -> [RuntimeCount; RESPONSE_BIN_COUNT] {
        self.selected
    }
    pub const fn scored_target_arrivals(self) -> RuntimeCount {
        self.scored_target_arrivals
    }
    pub const fn target_backlog_at_w_total(self) -> RuntimeCount {
        self.target_backlog_at_w_total
    }
    pub const fn target_backlog_at_t_total(self) -> RuntimeCount {
        self.target_backlog_at_t_total
    }
    pub fn scored_target_service_total(self) -> Result<RuntimeCount, RunError> {
        self.selected[1..]
            .iter()
            .try_fold(RuntimeCount::ZERO, |sum, value| {
                sum.checked_add(*value, "aggregate scored target service")
                    .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))
            })
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NominalThreeBinResponse {
    s1: ExactRational,
    s2: ExactRational,
    c: ExactRational,
}

impl NominalThreeBinResponse {
    pub const fn s1(&self) -> &ExactRational {
        &self.s1
    }
    pub const fn s2(&self) -> &ExactRational {
        &self.s2
    }
    pub const fn c(&self) -> &ExactRational {
        &self.c
    }
    pub fn ordered(&self) -> [&ExactRational; FITTED_BIN_COUNT] {
        [&self.s1, &self.s2, &self.c]
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BuiltEstimate {
    primitive: AggregatePrimitiveCounts,
    nominal: NominalThreeBinResponse,
    work: ConstructionWorkTotals,
    replications: Vec<ReplicationEvidence>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UnavailableEstimate {
    primitive: AggregatePrimitiveCounts,
    unobserved_bins: [bool; FITTED_BIN_COUNT],
    work: ConstructionWorkTotals,
    replications: Vec<ReplicationEvidence>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FailedEstimate {
    reason: ProviderFailureReason,
    failure_coordinate: Option<ReplicationCoordinate>,
    detail: String,
    work: Option<ConstructionWorkTotals>,
    reports: Vec<ReplicationReport>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConstructionEstimate {
    Built(BuiltEstimate),
    Unavailable(UnavailableEstimate),
    Failed(FailedEstimate),
}

#[derive(Clone, Debug, PartialEq)]
pub struct ObservedConstructionEstimate {
    estimate: ConstructionEstimate,
    observations: Vec<ConstructionObservationReplicationV1>,
    arrival_stream_digests: Vec<[u8; 32]>,
}

/// Fallibly reserved terminal storage for exact ordinary aggregation. Hosts
/// prepare this arena before launching physical replications so aggregation
/// cannot discard completed records because a result vector could not grow.
#[derive(Debug)]
pub struct PreparedObservedAggregationV1 {
    expected_len: usize,
    legacy: Vec<ReplicationReport>,
    observations: Vec<ConstructionObservationReplicationV1>,
    arrival_stream_digests: Vec<[u8; 32]>,
}

impl PreparedObservedAggregationV1 {
    pub fn try_new(
        partition: ScientificGrantPartition,
    ) -> Result<Self, EstimatorInvocationError> {
        let expected_len = usize::try_from(partition.replications)
            .map_err(|_error| EstimatorInvocationError::ReportCountMismatch)?;
        let mut legacy = Vec::new();
        legacy
            .try_reserve_exact(expected_len)
            .map_err(|_error| EstimatorInvocationError::ObservationAggregationCapacity)?;
        let mut observations = Vec::new();
        observations
            .try_reserve_exact(expected_len)
            .map_err(|_error| EstimatorInvocationError::ObservationAggregationCapacity)?;
        let mut arrival_stream_digests = Vec::new();
        arrival_stream_digests
            .try_reserve_exact(expected_len)
            .map_err(|_error| EstimatorInvocationError::ObservationAggregationCapacity)?;
        Ok(Self {
            expected_len,
            legacy,
            observations,
            arrival_stream_digests,
        })
    }
}

impl ObservedConstructionEstimate {
    pub const fn estimate(&self) -> &ConstructionEstimate {
        &self.estimate
    }

    pub fn observations(&self) -> &[ConstructionObservationReplicationV1] {
        &self.observations
    }

    pub fn arrival_stream_digests(&self) -> &[[u8; 32]] {
        &self.arrival_stream_digests
    }

    pub fn into_parts(
        self,
    ) -> (
        ConstructionEstimate,
        Vec<ConstructionObservationReplicationV1>,
        Vec<[u8; 32]>,
    ) {
        (
            self.estimate,
            self.observations,
            self.arrival_stream_digests,
        )
    }
}

macro_rules! common_estimate_accessors {
    ($type:ty) => {
        impl $type {
            pub const fn primitive(&self) -> AggregatePrimitiveCounts {
                self.primitive
            }
            pub const fn work(&self) -> ConstructionWorkTotals {
                self.work
            }
            pub fn replications(&self) -> &[ReplicationEvidence] {
                &self.replications
            }
        }
    };
}

common_estimate_accessors!(BuiltEstimate);
common_estimate_accessors!(UnavailableEstimate);

impl BuiltEstimate {
    pub const fn nominal(&self) -> &NominalThreeBinResponse {
        &self.nominal
    }
}

impl UnavailableEstimate {
    pub const fn unobserved_bins(&self) -> [bool; FITTED_BIN_COUNT] {
        self.unobserved_bins
    }
}

impl FailedEstimate {
    pub const fn reason(&self) -> ProviderFailureReason {
        self.reason
    }
    pub const fn failure_coordinate(&self) -> Option<ReplicationCoordinate> {
        self.failure_coordinate
    }
    pub fn detail(&self) -> &str {
        &self.detail
    }
    pub const fn work(&self) -> Option<ConstructionWorkTotals> {
        self.work
    }
    pub fn reports(&self) -> &[ReplicationReport] {
        &self.reports
    }
}

/// Restore canonical order, reconcile every worker report and reservation,
/// then fit the exact ratio of aggregate served/exposure counts.
pub fn aggregate_replications(
    partition: ScientificGrantPartition,
    horizon: RuntimeCount,
    window_length: RuntimeCount,
    mut reports: Vec<ReplicationReport>,
) -> Result<ConstructionEstimate, EstimatorInvocationError> {
    let expected_len = usize::try_from(partition.replications)
        .map_err(|_| EstimatorInvocationError::ReportCountMismatch)?;
    if reports.len() != expected_len {
        return Err(EstimatorInvocationError::ReportCountMismatch);
    }
    reports.sort_by_key(ReplicationReport::coordinate);
    for (index, report) in reports.iter().enumerate() {
        let index = u64::try_from(index)
            .map_err(|_| EstimatorInvocationError::NonCanonicalCoordinateSet)?;
        if report.coordinate().index() != index {
            return Err(EstimatorInvocationError::NonCanonicalCoordinateSet);
        }
    }

    let mut work = ConstructionWorkTotals::default();
    for report_index in 0..reports.len() {
        let report = &reports[report_index];
        let coordinate = report.coordinate();
        let report_work = report.work();
        let reservation = partition.reservation(report.coordinate())?;
        let expected_limits = reservation.try_work_limits()?;
        if report.limits() != expected_limits || !work_is_within(report_work, expected_limits) {
            return Ok(failed_estimate(
                reports,
                ProviderFailureReason::ScientificGrantExceeded,
                Some(coordinate),
                "replication work or limits disagree with its deterministic global reservation",
                Some(work),
            ));
        }
        let Some(next) = work.checked_add(report_work) else {
            // Calls and draws are bounded by disjoint reservations. Search
            // work may instead be uncapped telemetry, but every published
            // total still has the u64 carrier. In either case an aggregate
            // overflow leaves no complete representable provider-authored
            // work total to serialize as a Failed result.
            return Err(EstimatorInvocationError::InconsistentWorkAggregate);
        };
        work = next;
    }
    if work.configured_generator_draws > partition.global.maximum_configured_generator_draws()
        || work.exact_optimizer_calls > partition.global.maximum_exact_optimizer_calls()
        || match partition.global.optimizer_search_states() {
            OptimizerSearchStateGrant::NotApplicable => false,
            OptimizerSearchStateGrant::Bounded(maximum) => work.optimizer_search_states > maximum,
        }
    {
        return Ok(failed_estimate(
            reports,
            ProviderFailureReason::ScientificGrantExceeded,
            None,
            "aggregate construction work exceeds the global scientific grant",
            Some(work),
        ));
    }
    if let Some(failure) = reports.iter().find_map(|report| match report {
        ReplicationReport::Completed(_) => None,
        ReplicationReport::Failed(failure) => Some((
            failure.coordinate(),
            failure.reason(),
            failure.error().to_string(),
        )),
    }) {
        return Ok(failed_estimate(
            reports,
            failure.1,
            Some(failure.0),
            failure.2,
            Some(work),
        ));
    }

    let mut primitive = AggregatePrimitiveCounts {
        exposures: [RuntimeCount::ZERO; RESPONSE_BIN_COUNT],
        selected: [RuntimeCount::ZERO; RESPONSE_BIN_COUNT],
        scored_target_arrivals: RuntimeCount::ZERO,
        target_backlog_at_w_total: RuntimeCount::ZERO,
        target_backlog_at_t_total: RuntimeCount::ZERO,
    };
    let mut completed = Vec::new();
    if completed.try_reserve_exact(reports.len()).is_err() {
        return Ok(failed_estimate(
            reports,
            ProviderFailureReason::ResourceExhausted,
            None,
            "canonical replication-evidence reservation failed",
            Some(work),
        ));
    }
    for report in reports {
        let ReplicationReport::Completed(evidence) = report else {
            unreachable!("failure report was selected before aggregation")
        };
        if let Some(detail) = validate_completed(&evidence, horizon, window_length) {
            return Ok(FailedEstimate {
                reason: ProviderFailureReason::ConstructionInvariant,
                failure_coordinate: Some(evidence.coordinate()),
                detail: detail.to_owned(),
                work: Some(work),
                reports: vec![ReplicationReport::Completed(evidence)],
            }
            .into());
        }
        for bin in 0..RESPONSE_BIN_COUNT {
            let Some(exposure) = checked_count_sum(
                primitive.exposures[bin],
                evidence.response().exposures()[bin],
            ) else {
                return Ok(arithmetic_failure_for_completed(
                    completed,
                    evidence,
                    work,
                    "aggregate exposure count overflowed",
                ));
            };
            let Some(selected) =
                checked_count_sum(primitive.selected[bin], evidence.response().selected()[bin])
            else {
                return Ok(arithmetic_failure_for_completed(
                    completed,
                    evidence,
                    work,
                    "aggregate served-exposure count overflowed",
                ));
            };
            primitive.exposures[bin] = exposure;
            primitive.selected[bin] = selected;
        }
        let reconciliation = evidence.reconciliation();
        let Some(scored_target_arrivals) = checked_count_sum(
            primitive.scored_target_arrivals,
            reconciliation.scored_target_arrivals(),
        ) else {
            return Ok(arithmetic_failure_for_completed(
                completed,
                evidence,
                work,
                "aggregate target arrivals overflowed",
            ));
        };
        let Some(target_backlog_at_w_total) = checked_count_sum(
            primitive.target_backlog_at_w_total,
            reconciliation.target_backlog_at_w(),
        ) else {
            return Ok(arithmetic_failure_for_completed(
                completed,
                evidence,
                work,
                "aggregate target backlog at W overflowed",
            ));
        };
        let Some(next_target_t_total) = checked_count_sum(
            primitive.target_backlog_at_t_total,
            reconciliation.target_backlog_at_t(),
        ) else {
            return Ok(arithmetic_failure_for_completed(
                completed,
                evidence,
                work,
                "aggregate target backlog at T overflowed",
            ));
        };
        primitive.scored_target_arrivals = scored_target_arrivals;
        primitive.target_backlog_at_w_total = target_backlog_at_w_total;
        primitive.target_backlog_at_t_total = next_target_t_total;
        completed.push(*evidence);
    }

    let expected_exposures = partition
        .replications
        .checked_mul(window_length.get())
        .map(RuntimeCount::new);
    let actual_exposures = primitive
        .exposures
        .iter()
        .try_fold(RuntimeCount::ZERO, |sum, value| {
            checked_count_sum(sum, *value)
        });
    if expected_exposures.is_none() || actual_exposures != expected_exposures {
        return Ok(ConstructionEstimate::Failed(FailedEstimate {
            reason: if expected_exposures.is_none() {
                ProviderFailureReason::ArithmeticBound
            } else {
                ProviderFailureReason::ConstructionInvariant
            },
            failure_coordinate: None,
            detail: "aggregate exposure partition does not equal R*(T-W)".to_owned(),
            work: Some(work),
            reports: completed
                .into_iter()
                .map(|value| ReplicationReport::Completed(Box::new(value)))
                .collect(),
        }));
    }
    let unobserved_bins = [
        primitive.exposures[1] == RuntimeCount::ZERO,
        primitive.exposures[2] == RuntimeCount::ZERO,
        primitive.exposures[3] == RuntimeCount::ZERO,
    ];
    if unobserved_bins.into_iter().any(|unobserved| unobserved) {
        return Ok(ConstructionEstimate::Unavailable(UnavailableEstimate {
            primitive,
            unobserved_bins,
            work,
            replications: completed,
        }));
    }
    let nominal = NominalThreeBinResponse {
        s1: exact_ratio(primitive.selected[1], primitive.exposures[1]),
        s2: exact_ratio(primitive.selected[2], primitive.exposures[2]),
        c: exact_ratio(primitive.selected[3], primitive.exposures[3]),
    };
    Ok(ConstructionEstimate::Built(BuiltEstimate {
        primitive,
        nominal,
        work,
        replications: completed,
    }))
}

/// Canonically aggregate the frozen construction report while retaining all
/// complete and recoverable-partial ordinary observation records in the same
/// stable replication-coordinate order.
pub fn aggregate_observed_replications(
    partition: ScientificGrantPartition,
    horizon: RuntimeCount,
    window_length: RuntimeCount,
    reports: Vec<ObservedReplicationReport>,
) -> Result<ObservedConstructionEstimate, EstimatorInvocationError> {
    let prepared = PreparedObservedAggregationV1::try_new(partition)?;
    aggregate_observed_replications_prepared(
        partition,
        horizon,
        window_length,
        reports,
        prepared,
    )
}

/// Aggregate into terminal vectors reserved before physical execution.
pub fn aggregate_observed_replications_prepared(
    partition: ScientificGrantPartition,
    horizon: RuntimeCount,
    window_length: RuntimeCount,
    mut reports: Vec<ObservedReplicationReport>,
    prepared: PreparedObservedAggregationV1,
) -> Result<ObservedConstructionEstimate, EstimatorInvocationError> {
    let expected_len = usize::try_from(partition.replications)
        .map_err(|_error| EstimatorInvocationError::ReportCountMismatch)?;
    if reports.len() != expected_len || prepared.expected_len != expected_len {
        return Err(EstimatorInvocationError::ReportCountMismatch);
    }
    reports.sort_by_key(ObservedReplicationReport::coordinate);
    let PreparedObservedAggregationV1 {
        expected_len: _,
        mut legacy,
        mut observations,
        mut arrival_stream_digests,
    } = prepared;
    for (index, report) in reports.into_iter().enumerate() {
        let coordinate = u64::try_from(index)
            .map_err(|_error| EstimatorInvocationError::NonCanonicalCoordinateSet)?;
        if report.coordinate().index() != coordinate {
            return Err(EstimatorInvocationError::NonCanonicalCoordinateSet);
        }
        let report_coordinate = report.coordinate().index();
        let (report, observation, arrival_stream_digest, observation_error) =
            report.into_parts();
        if let Some(error) = observation_error {
            return Err(EstimatorInvocationError::ObservationFinalization {
                coordinate: report_coordinate,
                detail: error.to_string(),
            });
        }
        let observation = observation.ok_or(
            EstimatorInvocationError::MissingObservation {
                coordinate: report_coordinate,
            },
        )?;
        let arrival_stream_digest = arrival_stream_digest.ok_or(
            EstimatorInvocationError::MissingArrivalStreamDigest {
                coordinate: report_coordinate,
            },
        )?;
        legacy.push(report);
        observations.push(observation);
        arrival_stream_digests.push(arrival_stream_digest);
    }
    debug_assert_eq!(observations.len(), expected_len);
    let estimate = aggregate_replications(partition, horizon, window_length, legacy)?;
    Ok(ObservedConstructionEstimate {
        estimate,
        observations,
        arrival_stream_digests,
    })
}

impl From<FailedEstimate> for ConstructionEstimate {
    fn from(value: FailedEstimate) -> Self {
        Self::Failed(value)
    }
}

fn validate_completed(
    evidence: &ReplicationEvidence,
    horizon: RuntimeCount,
    window_length: RuntimeCount,
) -> Option<&'static str> {
    let response = evidence.response();
    let exposures = response.exposures();
    let selected = response.selected();
    if selected[0] != RuntimeCount::ZERO {
        return Some("Y_0 is nonzero");
    }
    if (0..RESPONSE_BIN_COUNT).any(|bin| selected[bin] > exposures[bin]) {
        return Some("a served count exceeds its matching exposure count");
    }
    let exposure_total = exposures.iter().try_fold(RuntimeCount::ZERO, |sum, value| {
        checked_count_sum(sum, *value)
    });
    if exposure_total != Some(window_length) {
        return Some("replication exposure partition differs from T-W");
    }
    let reconciliation = evidence.reconciliation();
    if reconciliation.window_length() != window_length
        || evidence.provider_endpoint().expected_slot() != horizon
        || evidence.work().committed_slots() != horizon.get()
        || evidence.work().exact_optimizer_calls() != horizon.get()
    {
        return Some("replication endpoint, work, or window length differs from the request");
    }
    let selected_total = selected[1..]
        .iter()
        .try_fold(RuntimeCount::ZERO, |sum, value| {
            checked_count_sum(sum, *value)
        });
    if selected_total != Some(reconciliation.scored_target_services()) {
        return Some("replication selected-service ledger does not reconcile");
    }
    let left = u128::from(reconciliation.target_backlog_at_w().get())
        .checked_add(u128::from(reconciliation.scored_target_arrivals().get()));
    let right = u128::from(reconciliation.target_backlog_at_t().get())
        .checked_add(u128::from(reconciliation.scored_target_services().get()));
    if left.is_none() || left != right {
        return Some("replication target conservation does not reconcile");
    }
    let endpoint_right = reconciliation
        .endpoint_total_occupancy()
        .checked_add(u128::from(reconciliation.endpoint_total_services().get()));
    if endpoint_right.is_none()
        || Some(u128::from(reconciliation.endpoint_total_arrivals().get())) != endpoint_right
    {
        return Some("replication aggregate endpoint conservation does not reconcile");
    }
    None
}

fn work_is_within(work: ConstructionWorkCounters, limits: ConstructionWorkLimits) -> bool {
    work.configured_generator_draws() <= limits.maximum_configured_generator_draws()
        && work.exact_optimizer_calls() <= limits.maximum_exact_optimizer_calls()
        && match limits.optimizer_search_states() {
            OptimizerSearchStateGrant::NotApplicable => true,
            OptimizerSearchStateGrant::Bounded(maximum) => {
                work.optimizer_search_states() <= maximum
            }
        }
}

fn checked_count_sum(left: RuntimeCount, right: RuntimeCount) -> Option<RuntimeCount> {
    left.get().checked_add(right.get()).map(RuntimeCount::new)
}

fn exact_ratio(numerator: RuntimeCount, denominator: RuntimeCount) -> ExactRational {
    debug_assert_ne!(denominator, RuntimeCount::ZERO);
    ExactRational::new(
        BigInt::from(numerator.get()),
        BigInt::from(denominator.get()),
        "positive aggregate response exposure",
    )
    .expect("the aggregate denominator was checked positive")
}

fn failed_estimate(
    reports: Vec<ReplicationReport>,
    reason: ProviderFailureReason,
    failure_coordinate: Option<ReplicationCoordinate>,
    detail: impl Into<String>,
    work: Option<ConstructionWorkTotals>,
) -> ConstructionEstimate {
    ConstructionEstimate::Failed(FailedEstimate {
        reason,
        failure_coordinate,
        detail: detail.into(),
        work,
        reports,
    })
}

fn arithmetic_failure_for_completed(
    mut completed: Vec<ReplicationEvidence>,
    evidence: Box<ReplicationEvidence>,
    work: ConstructionWorkTotals,
    detail: &'static str,
) -> ConstructionEstimate {
    let coordinate = evidence.coordinate();
    completed.push(*evidence);
    ConstructionEstimate::Failed(FailedEstimate {
        reason: ProviderFailureReason::ArithmeticBound,
        failure_coordinate: Some(coordinate),
        detail: detail.to_owned(),
        work: Some(work),
        reports: completed
            .into_iter()
            .map(|value| ReplicationReport::Completed(Box::new(value)))
            .collect(),
    })
}

#[cfg(test)]
mod tests;
