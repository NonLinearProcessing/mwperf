use num_bigint::BigInt;

use crate::error::{RunError, RuntimeStage};
use crate::exact::{ExactRational, ExactUnsigned};
use crate::lineage_iid::{QualifiedIidDestination, QualifiedIidSource};
use crate::occupancy_maxweight::PreparedOccupancyMaxWeight;
use crate::resolved::{
    ConflictGraphTopology, ConflictPair, CrossbarEdge, CrossbarTopology, IntervalTopology,
    NodeExclusiveLink, NodeExclusiveTopology, QueueInterval, ResolvedScheduler, ResourceDemand,
    ResourcePackingTopology, SchedulerTopology, SourceId, TypedId,
};
use crate::unit_count::{QueueCatalog, QueueIndex};
use crate::weighted_ensemble_coordinator::{
    PreparedWeightedEnsembleRun, WeightedFinitePrefixRunResultV1,
};
use crate::weighted_ensemble_estimator::{
    WeightedEstimatorError, WeightedFinitePrefixEstimateV1, WeightedRegionMass,
    WeightedResponseCutoffV1,
};
use crate::weighted_ensemble_runner::WeightedEnsembleRunError;

const LAW_DIGEST: [u8; 32] = [0xd7; 32];
const SEED: [u8; 32] = [0x5c; 32];
const TARGET: usize = 0;
const WARMUP: u64 = 1;
const HORIZON: u64 = 5;
const ENSEMBLES: u64 = 8;
const PARTICLES: usize = 4;

const ZERO_BITS: u64 = 0x0000_0000_0000_0000;
const QUARTER_BITS: u64 = 0x3fd0_0000_0000_0000;
const HALF_BITS: u64 = 0x3fe0_0000_0000_0000;
const ONE_BITS: u64 = 0x3ff0_0000_0000_0000;

fn qid(position: usize) -> TypedId {
    TypedId::from(format!("q{position}"))
}

fn label(prefix: &str, position: usize) -> TypedId {
    TypedId::from(format!("{prefix}{position}"))
}

fn exact_integer(value: i64) -> ExactRational {
    ExactRational::from_integer(BigInt::from(value))
}

fn probability(numerator: i64, denominator: i64, quantity: &'static str) -> ExactRational {
    ExactRational::new(BigInt::from(numerator), BigInt::from(denominator), quantity)
        .expect("test probability is a canonical exact rational")
}

fn alpha() -> ExactRational {
    probability(1, 20, "CP07-D conformance familywise alpha")
}

fn catalog() -> QueueCatalog {
    QueueCatalog::try_new((0..4).map(qid).collect())
        .expect("CP07-D conformance catalog is canonical")
}

/// These are the same compact authored geometries used by the CP07-B
/// five-family physical-parity gate.  With only q0 and q1 occupied, those two
/// queues are mutually exclusive in every topology and q1 wins an equal-
/// backlog tie under the authored `[q3,q2,q1,q0]` priority.
fn parity_schedulers() -> Vec<ResolvedScheduler> {
    let priority = || [3, 2, 1, 0].into_iter().map(qid).collect();
    vec![
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: vec![label("i", 0), label("i", 1)],
                outputs: vec![label("o", 0), label("o", 1)],
                edges: [(0, 0), (0, 1), (1, 0), (1, 1)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (input, output))| CrossbarEdge {
                        queue_id: qid(position),
                        input: label("i", input),
                        output: label("o", output),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: [(0, 3), (1, 2), (3, 4), (2, 5)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (left, right))| QueueInterval {
                        queue_id: qid(position),
                        left: exact_integer(left),
                        right: exact_integer(right),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                vertices: (0..4).map(|position| label("v", position)).collect(),
                links: [(0, 1), (1, 2), (2, 3), (0, 3)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (left, right))| NodeExclusiveLink {
                        queue_id: qid(position),
                        u: label("v", left),
                        v: label("v", right),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: [(0, 1), (1, 2), (2, 3)]
                    .into_iter()
                    .map(|(left, right)| ConflictPair {
                        first: qid(left),
                        second: qid(right),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(64)),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::ResourcePacking(ResourcePackingTopology {
                resources: vec![label("r", 0), label("r", 1)],
                capacity: vec![
                    ExactUnsigned::from_u64(2),
                    ExactUnsigned::from_u64(2),
                ],
                demands: [[1, 1], [2, 0], [0, 2], [3, 0]]
                    .into_iter()
                    .enumerate()
                    .map(|(position, row)| ResourceDemand {
                        queue_id: qid(position),
                        demand: row.into_iter().map(ExactUnsigned::from_u64).collect(),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(64)),
            }),
        },
    ]
}

fn certain_sources(arrival_queues: &[u32]) -> Vec<QualifiedIidSource> {
    arrival_queues
        .iter()
        .copied()
        .map(|queue| QualifiedIidSource {
            source_id: SourceId::new(format!("certain_q{queue}")),
            arrival_probability: probability(1, 1, "CP07-D certain occurrence"),
            destinations: vec![QualifiedIidDestination {
                queue: QueueIndex(queue),
                probability: probability(1, 1, "CP07-D certain destination"),
            }],
        })
        .collect()
}

fn half_occurrence_source(queue: u32) -> QualifiedIidSource {
    QualifiedIidSource {
        source_id: SourceId::new(format!("half_q{queue}")),
        arrival_probability: probability(1, 2, "CP07-D stochastic occurrence"),
        destinations: vec![QualifiedIidDestination {
            queue: QueueIndex(queue),
            probability: probability(1, 1, "CP07-D stochastic singleton destination"),
        }],
    }
}

#[allow(clippy::too_many_arguments)]
fn prepared_run(
    scheduler: ResolvedScheduler,
    arrival_queues: &[u32],
    warmup: u64,
    horizon: u64,
    ensembles: u64,
    particles: usize,
) -> PreparedWeightedEnsembleRun {
    let queue_catalog = catalog();
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &queue_catalog)
        .expect("CP07-D conformance optimizer prepares");
    let mut configured_law_digest = LAW_DIGEST;
    configured_law_digest[31] = u8::try_from(arrival_queues.len())
        .expect("the compact conformance source count fits u8");
    PreparedWeightedEnsembleRun::try_new_with_response_cutoff_v1(
        optimizer,
        configured_law_digest,
        certain_sources(arrival_queues),
        SEED,
        TARGET,
        warmup,
        horizon,
        ensembles,
        particles,
        WeightedResponseCutoffV1::K2,
        alpha(),
    )
    .expect("CP07-D sampler-native run prepares")
}

#[allow(clippy::too_many_arguments)]
fn prepared_run_with_response_cutoff_v1(
    scheduler: ResolvedScheduler,
    arrival_queues: &[u32],
    warmup: u64,
    horizon: u64,
    ensembles: u64,
    particles: usize,
    response_cutoff: WeightedResponseCutoffV1,
) -> PreparedWeightedEnsembleRun {
    let queue_catalog = catalog();
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &queue_catalog)
        .expect("CP07.1 conformance optimizer prepares");
    let mut configured_law_digest = LAW_DIGEST;
    configured_law_digest[31] = u8::try_from(arrival_queues.len())
        .expect("the compact conformance source count fits u8");
    PreparedWeightedEnsembleRun::try_new_with_response_cutoff_v1(
        optimizer,
        configured_law_digest,
        certain_sources(arrival_queues),
        SEED,
        TARGET,
        warmup,
        horizon,
        ensembles,
        particles,
        response_cutoff,
        alpha(),
    )
    .expect("CP07.1 cutoff-aware sampler-native run prepares")
}

fn assert_region_bits(
    actual: WeightedRegionMass,
    unserved_bits: u64,
    served_bits: u64,
    exposure_bits: u64,
) {
    assert_eq!(actual.unserved().to_bits(), unserved_bits);
    assert_eq!(actual.served().to_bits(), served_bits);
    assert_eq!(actual.exposure().to_bits(), exposure_bits);
}

fn assert_estimate_bits_eq(
    actual: &WeightedFinitePrefixEstimateV1,
    expected: &WeightedFinitePrefixEstimateV1,
) {
    let actual_common = actual.common();
    let expected_common = expected.common();
    assert_eq!(actual_common.ensemble_count(), expected_common.ensemble_count());
    assert_eq!(actual_common.window_length(), expected_common.window_length());
    assert_eq!(actual_common.response_cutoff(), expected_common.response_cutoff());
    for (actual_mass, expected_mass) in actual_common
        .masses()
        .levels()
        .iter()
        .zip(expected_common.masses().levels())
    {
        assert_eq!(actual_mass.level(), expected_mass.level());
        assert_eq!(
            actual_mass.mass().unserved().to_bits(),
            expected_mass.mass().unserved().to_bits()
        );
        assert_eq!(
            actual_mass.mass().served().to_bits(),
            expected_mass.mass().served().to_bits()
        );
        assert_eq!(
            actual_mass.mass().exposure().to_bits(),
            expected_mass.mass().exposure().to_bits()
        );
    }
    assert_eq!(
        actual_common.masses().tail().tail_from(),
        expected_common.masses().tail().tail_from()
    );
    assert_region_bits(
        actual_common.masses().tail().mass(),
        expected_common.masses().tail().mass().unserved().to_bits(),
        expected_common.masses().tail().mass().served().to_bits(),
        expected_common.masses().tail().mass().exposure().to_bits(),
    );
    assert_eq!(
        actual_common.concentration_radius().lower().to_bits(),
        expected_common.concentration_radius().lower().to_bits()
    );
    assert_eq!(
        actual_common.concentration_radius().upper().to_bits(),
        expected_common.concentration_radius().upper().to_bits()
    );
    assert_eq!(
        actual_common.floating_point_enclosure().to_bits(),
        expected_common.floating_point_enclosure().to_bits()
    );
    match (actual, expected) {
        (
            WeightedFinitePrefixEstimateV1::Built(actual),
            WeightedFinitePrefixEstimateV1::Built(expected),
        ) => {
            for (actual_coefficient, expected_coefficient) in actual
                .response()
                .levels()
                .iter()
                .zip(expected.response().levels())
            {
                assert_eq!(actual_coefficient.level(), expected_coefficient.level());
                assert_eq!(
                    actual_coefficient.coefficient().value().to_bits(),
                    expected_coefficient.coefficient().value().to_bits()
                );
                assert_eq!(
                    actual_coefficient.coefficient().interval().lower().to_bits(),
                    expected_coefficient.coefficient().interval().lower().to_bits()
                );
                assert_eq!(
                    actual_coefficient.coefficient().interval().upper().to_bits(),
                    expected_coefficient.coefficient().interval().upper().to_bits()
                );
            }
            assert_eq!(
                actual.response().tail().tail_from(),
                expected.response().tail().tail_from()
            );
            assert_eq!(
                actual.response().tail().coefficient().value().to_bits(),
                expected.response().tail().coefficient().value().to_bits()
            );
            assert_eq!(
                actual.response().tail().coefficient().interval().lower().to_bits(),
                expected.response().tail().coefficient().interval().lower().to_bits()
            );
            assert_eq!(
                actual.response().tail().coefficient().interval().upper().to_bits(),
                expected.response().tail().coefficient().interval().upper().to_bits()
            );
        }
        (
            WeightedFinitePrefixEstimateV1::Unavailable(actual),
            WeightedFinitePrefixEstimateV1::Unavailable(expected),
        ) => assert_eq!(
            actual.unobserved_nonzero_regions(),
            expected.unobserved_nonzero_regions()
        ),
        _ => panic!("worker count or replay changed CP07 estimate availability"),
    }
}

fn assert_run_bits_eq(
    actual: &WeightedFinitePrefixRunResultV1,
    expected: &WeightedFinitePrefixRunResultV1,
) {
    assert_eq!(actual.work(), expected.work());
    assert_estimate_bits_eq(
        actual.finite_prefix_estimate(),
        expected.finite_prefix_estimate(),
    );
}

fn assert_competition_known_answer(result: &WeightedFinitePrefixRunResultV1) {
    assert_eq!(result.work().particle_transitions(), 160);
    assert_eq!(result.work().exact_optimizer_calls(), 32);
    assert_eq!(result.work().schedule_cache_misses(), 32);
    assert!(result.work().exact_optimizer_calls() <= result.work().particle_transitions());

    let built = match result.finite_prefix_estimate() {
        WeightedFinitePrefixEstimateV1::Built(built) => built,
        WeightedFinitePrefixEstimateV1::Unavailable(_) => {
            panic!("the authored competition trace visits all three response regions")
        }
    };
    let common = built.common();
    assert_eq!(common.ensemble_count(), ENSEMBLES);
    assert_eq!(common.window_length(), HORIZON - WARMUP);
    assert_eq!(common.response_cutoff(), WeightedResponseCutoffV1::K2);
    let masses = common.masses();
    assert_region_bits(masses.levels()[0].mass(), ZERO_BITS, ZERO_BITS, ZERO_BITS);
    assert_region_bits(masses.levels()[1].mass(), QUARTER_BITS, ZERO_BITS, QUARTER_BITS);
    assert_region_bits(masses.levels()[2].mass(), QUARTER_BITS, QUARTER_BITS, HALF_BITS);
    assert_region_bits(
        masses.tail().mass(),
        ZERO_BITS,
        QUARTER_BITS,
        QUARTER_BITS,
    );
    let response = built.response();
    assert_eq!(response.levels()[0].coefficient().value().to_bits(), ZERO_BITS);
    assert_eq!(response.levels()[1].coefficient().value().to_bits(), ZERO_BITS);
    assert_eq!(response.levels()[2].coefficient().value().to_bits(), HALF_BITS);
    assert_eq!(response.tail().coefficient().value().to_bits(), ONE_BITS);
}

#[test]
fn cp07_d_all_five_families_are_end_to_end_known_answers_and_worker_invariant() {
    let mut family_reference = None;
    for scheduler in parity_schedulers() {
        let family = scheduler.topology.family();
        let run = prepared_run(
            scheduler,
            &[0, 1],
            WARMUP,
            HORIZON,
            ENSEMBLES,
            PARTICLES,
        );
        let baseline = run
            .execute_finite_prefix_v1(1)
            .expect("one-worker native CP07.1 fixture executes");
        assert_competition_known_answer(&baseline);
        if let Some(reference) = family_reference.as_ref() {
            assert_run_bits_eq(&baseline, reference);
        } else {
            family_reference = Some(baseline.clone());
        }

        for workers in [2, 3, 7, 64] {
            let actual = run
                .execute_finite_prefix_v1(workers)
                .unwrap_or_else(|error| {
                    panic!("{family:?} failed with {workers} workers: {error}")
                });
            assert_run_bits_eq(&actual, &baseline);
            assert_competition_known_answer(&actual);
        }

        let replay = run
            .execute_finite_prefix_v1(3)
            .expect("prepared native CP07.1 fixture replays");
        assert_run_bits_eq(&replay, &baseline);

        let reverse_order: Vec<u64> = (0..ENSEMBLES).rev().collect();
        let reverse = run
            .execute_in_ensemble_order_for_test(&reverse_order)
            .expect("real ensemble ledgers reduce canonically after reverse execution");
        assert_run_bits_eq(&reverse, &baseline);
    }
}

#[test]
fn cp07_1_prepared_cutoff_is_physical_noop_and_publishes_the_exact_shape() {
    const WIDE_HORIZON: u64 = 17;
    const WIDE_ENSEMBLES: u64 = 2;
    const WIDE_PARTICLES: usize = 1;

    let scheduler = parity_schedulers()
        .into_iter()
        .next()
        .expect("the authored family fixture is nonempty");
    let explicit_k2 = prepared_run_with_response_cutoff_v1(
        scheduler.clone(),
        &[0, 1],
        WARMUP,
        WIDE_HORIZON,
        WIDE_ENSEMBLES,
        WIDE_PARTICLES,
        WeightedResponseCutoffV1::K2,
    );
    let cutoff5 = WeightedResponseCutoffV1::try_new(5).expect("K=5 is a V1 cutoff");
    let wide = prepared_run_with_response_cutoff_v1(
        scheduler,
        &[0, 1],
        WARMUP,
        WIDE_HORIZON,
        WIDE_ENSEMBLES,
        WIDE_PARTICLES,
        cutoff5,
    );

    assert_eq!(explicit_k2.response_cutoff(), WeightedResponseCutoffV1::K2);
    assert_eq!(wide.response_cutoff(), cutoff5);

    let explicit_k2_result = explicit_k2
        .execute_finite_prefix_v1(1)
        .expect("explicit K=2 finite-prefix run executes");
    assert_eq!(
        explicit_k2_result
            .finite_prefix_estimate()
            .common()
            .response_cutoff(),
        WeightedResponseCutoffV1::K2
    );

    let wide_result = wide
        .execute_finite_prefix_v1(1)
        .expect("K=5 finite-prefix run executes");
    assert_eq!(wide_result.work(), explicit_k2_result.work());
    assert_eq!(wide_result.work().particle_transitions(), 34);

    let estimate = match wide_result.finite_prefix_estimate() {
        WeightedFinitePrefixEstimateV1::Built(estimate) => estimate,
        WeightedFinitePrefixEstimateV1::Unavailable(_) => {
            panic!("the 16-slot fixture visits levels 1 through 5 and the >=6 tail")
        }
    };
    let common = estimate.common();
    assert_eq!(common.response_cutoff(), cutoff5);
    assert_eq!(common.masses().levels().len(), 6);
    for (expected_level, level) in common.masses().levels().iter().enumerate() {
        assert_eq!(level.level(), u64::try_from(expected_level).unwrap());
    }
    assert_eq!(common.masses().tail().tail_from(), 6);
    assert_eq!(estimate.response().levels().len(), 6);
    for (expected_level, level) in estimate.response().levels().iter().enumerate() {
        assert_eq!(level.level(), u64::try_from(expected_level).unwrap());
    }
    assert_eq!(estimate.response().tail().tail_from(), 6);

    for workers in [2, 3, 7, 64] {
        let replay = wide
            .execute_finite_prefix_v1(workers)
            .expect("the wider result is worker invariant");
        assert_eq!(replay, wide_result, "workers={workers}");
    }
}

#[test]
fn cp07_d_real_run_reports_unavailable_without_fabricating_zero_denominators() {
    let scheduler = parity_schedulers()
        .into_iter()
        .next()
        .expect("the authored family fixture is nonempty");
    let run = prepared_run(scheduler, &[0], 1, 3, 2, 4);
    let baseline = run
        .execute_finite_prefix_v1(1)
        .expect("unavailable native fixture executes");

    assert_eq!(baseline.work().particle_transitions(), 24);
    assert_eq!(baseline.work().exact_optimizer_calls(), 4);
    assert_eq!(baseline.work().schedule_cache_misses(), 4);
    match baseline.finite_prefix_estimate() {
        WeightedFinitePrefixEstimateV1::Unavailable(unavailable) => {
            assert_eq!(
                unavailable.unobserved_nonzero_regions(),
                &[false, true, true]
            );
            let masses = unavailable.common().masses();
            assert_region_bits(masses.levels()[1].mass(), ZERO_BITS, ONE_BITS, ONE_BITS);
            assert_region_bits(masses.levels()[2].mass(), ZERO_BITS, ZERO_BITS, ZERO_BITS);
            assert_region_bits(
                masses.tail().mass(),
                ZERO_BITS,
                ZERO_BITS,
                ZERO_BITS,
            );
        }
        WeightedFinitePrefixEstimateV1::Built(_) => {
            panic!("unvisited level-two and tail regions cannot produce ratios")
        }
    }

    for workers in [2, 7, 64] {
        let actual = run
            .execute_finite_prefix_v1(workers)
            .expect("unavailable result is worker invariant");
        assert_run_bits_eq(&actual, &baseline);
    }
}

#[test]
fn cp07_d_stochastic_lineage_iid_is_bitwise_worker_order_and_replay_invariant() {
    const STOCHASTIC_HORIZON: u64 = 8;
    const STOCHASTIC_ENSEMBLES: u64 = 16;
    const STOCHASTIC_PARTICLES: usize = 8;

    let scheduler = parity_schedulers()
        .into_iter()
        .nth(3)
        .expect("the fourth authored fixture is conflict graph");
    let queue_catalog = catalog();
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &queue_catalog)
        .expect("stochastic CP07-D conflict optimizer prepares");
    let mut sources = certain_sources(&[0, 1]);
    sources.push(half_occurrence_source(3));
    let run = PreparedWeightedEnsembleRun::try_new_with_response_cutoff_v1(
        optimizer,
        [0xe3; 32],
        sources,
        SEED,
        TARGET,
        WARMUP,
        STOCHASTIC_HORIZON,
        STOCHASTIC_ENSEMBLES,
        STOCHASTIC_PARTICLES,
        WeightedResponseCutoffV1::K2,
        alpha(),
    )
    .expect("stochastic CP07-D sampler-native run prepares");

    let baseline = run
        .execute_finite_prefix_v1(1)
        .expect("stochastic one-worker CP07 fixture executes");
    let work = baseline.work();
    assert_eq!(work.particle_transitions(), 1_024);
    assert_eq!(work.schedule_cache_misses(), work.exact_optimizer_calls());
    assert!(work.exact_optimizer_calls() <= work.particle_transitions());
    // There are seven nonzero sweeps per ensemble and at most the two q3
    // states induced by its Bernoulli arrival. The strict lower inequality
    // proves that this fixed seed actually exercises full-state diversity.
    assert!(work.exact_optimizer_calls() > 7 * STOCHASTIC_ENSEMBLES);
    assert!(work.exact_optimizer_calls() <= 14 * STOCHASTIC_ENSEMBLES);

    let built = match baseline.finite_prefix_estimate() {
        WeightedFinitePrefixEstimateV1::Built(built) => built,
        WeightedFinitePrefixEstimateV1::Unavailable(_) => {
            panic!("the stochastic non-target source cannot remove target-region support")
        }
    };
    assert_eq!(
        built.response().levels()[1].coefficient().value().to_bits(),
        ZERO_BITS
    );
    assert_eq!(
        built.response().levels()[2].coefficient().value().to_bits(),
        HALF_BITS
    );
    assert_eq!(
        built.response().tail().coefficient().value().to_bits(),
        HALF_BITS
    );

    for workers in [2, 3, 7, 64] {
        let actual = run
            .execute_finite_prefix_v1(workers)
            .expect("stochastic CP07 result is worker invariant");
        assert_run_bits_eq(&actual, &baseline);
    }
    let replay = run
        .execute_finite_prefix_v1(3)
        .expect("stochastic CP07 run replays");
    assert_run_bits_eq(&replay, &baseline);

    let reverse_order: Vec<u64> = (0..STOCHASTIC_ENSEMBLES).rev().collect();
    let reverse = run
        .execute_in_ensemble_order_for_test(&reverse_order)
        .expect("stochastic ledgers reduce canonically after reverse execution");
    assert_run_bits_eq(&reverse, &baseline);
}

#[test]
fn cp07_d_real_run_selects_the_lowest_failed_ensemble_for_every_worker_count() {
    let mut scheduler = parity_schedulers()
        .into_iter()
        .nth(3)
        .expect("the fourth authored fixture is conflict graph");
    let SchedulerTopology::ConflictGraph(graph) = &mut scheduler.topology else {
        panic!("the selected authored fixture must remain conflict graph");
    };
    graph.max_search_states = Some(ExactUnsigned::from_u64(1));
    let run = prepared_run(scheduler, &[0, 1, 2, 3], 1, 2, 8, 2);

    for workers in [1, 2, 3, 7, 64] {
        let error = run
            .execute_finite_prefix_v1(workers)
            .expect_err("one search state cannot solve the occupied conflict fixture");
        match error {
            WeightedEstimatorError::EnsembleRun {
                ensemble_id,
                source:
                    WeightedEnsembleRunError::Optimizer(RunError::ResourceExhausted {
                        stage,
                        detail,
                    }),
            } => {
                assert_eq!(ensemble_id, 0, "workers={workers}");
                assert_eq!(stage, RuntimeStage::ColdMaxWeightSolve);
                assert!(detail.contains("configured max_search_states=1"));
                assert!(!detail.contains("construction optimizer_search_states"));
            }
            other => panic!("unexpected CP07 failed outcome with {workers} workers: {other:?}"),
        }
    }
}
