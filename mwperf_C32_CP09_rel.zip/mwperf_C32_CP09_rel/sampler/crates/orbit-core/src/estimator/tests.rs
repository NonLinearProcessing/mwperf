use num_bigint::BigInt;

use super::*;
use crate::direct_count_arrivals::{ArrivalReplay, PreparedArrival};
use crate::engine::{PreparedCountProblem, PreparedCountRun};
use crate::exact::{ExactRational, ExactUnsigned};
use crate::occupancy_maxweight::PreparedOccupancyMaxWeight;
use crate::resolved::{
    ConflictGraphTopology, ConflictPair, CountArrivalEvent, DeterministicTrace, IntervalTopology,
    QueueInterval, ResolvedArrival, ResolvedScheduler, SchedulerTopology, TypedId,
};
use crate::unit_count::{QueueCatalog, QueueIndex};

fn global_limits(replications: u64, horizon: u64) -> ConstructionWorkLimits {
    ConstructionWorkLimits::try_new(
        replications.checked_mul(horizon).unwrap(),
        OptimizerSearchStateGrant::NotApplicable,
        replications.checked_mul(4).unwrap(),
    )
    .unwrap()
}

fn synthetic_report(
    partition: ScientificGrantPartition,
    coordinate: u64,
    horizon: u64,
    exposures: [u64; 4],
    selected: [u64; 4],
    target_backlog_at_w: u64,
    scored_target_arrivals: u64,
) -> ReplicationReport {
    let window_length = exposures.into_iter().sum::<u64>();
    let scored_target_services = selected[1..].iter().sum::<u64>();
    let target_backlog_at_t = target_backlog_at_w
        .checked_add(scored_target_arrivals)
        .unwrap()
        .checked_sub(scored_target_services)
        .unwrap();
    let endpoint_total_services = scored_target_services;
    let endpoint_total_occupancy = u128::from(target_backlog_at_t);
    let endpoint_total_arrivals = endpoint_total_services
        .checked_add(target_backlog_at_t)
        .unwrap();
    let limits = partition
        .reservation(ReplicationCoordinate::new(coordinate))
        .unwrap()
        .try_work_limits()
        .unwrap();
    let response = ResponseLedger::from_counts_for_test(
        exposures.map(RuntimeCount::new),
        selected.map(RuntimeCount::new),
    );
    let reconciliation = TargetWindowReconciliation::for_test(
        RuntimeCount::new(window_length),
        RuntimeCount::new(target_backlog_at_w),
        RuntimeCount::new(target_backlog_at_t),
        RuntimeCount::new(scored_target_arrivals),
        RuntimeCount::new(scored_target_services),
        RuntimeCount::new(endpoint_total_arrivals),
        RuntimeCount::new(endpoint_total_services),
        endpoint_total_occupancy,
    );
    let work = ConstructionWorkCounters::for_test(4, horizon, 0, horizon, 1, 128);
    ReplicationReport::Completed(Box::new(ReplicationEvidence::for_test(
        coordinate,
        response,
        reconciliation,
        work,
        limits,
        RuntimeCount::new(horizon),
    )))
}

#[test]
fn fofs_cp03_scientific_grants_partition_without_race_or_reset() {
    let global =
        ConstructionWorkLimits::try_new(31, OptimizerSearchStateGrant::Bounded(17), 25).unwrap();
    let partition = ScientificGrantPartition::try_new(3, global).unwrap();
    let canonical: Vec<_> = (0..3)
        .map(|index| {
            partition
                .reservation(ReplicationCoordinate::new(index))
                .unwrap()
        })
        .collect();
    assert_eq!(
        canonical
            .iter()
            .map(|grant| grant.maximum_exact_optimizer_calls())
            .collect::<Vec<_>>(),
        vec![11, 10, 10]
    );
    assert_eq!(
        canonical
            .iter()
            .map(|grant| grant.maximum_configured_generator_draws())
            .collect::<Vec<_>>(),
        vec![9, 8, 8]
    );
    assert_eq!(
        canonical
            .iter()
            .map(|grant| grant.optimizer_search_states())
            .collect::<Vec<_>>(),
        vec![
            OptimizerSearchStateGrant::Bounded(6),
            OptimizerSearchStateGrant::Bounded(6),
            OptimizerSearchStateGrant::Bounded(5),
        ]
    );
    let reverse: Vec<_> = (0..3)
        .rev()
        .map(|index| {
            partition
                .reservation(ReplicationCoordinate::new(index))
                .unwrap()
        })
        .collect();
    assert_eq!(reverse.into_iter().rev().collect::<Vec<_>>(), canonical);
}

#[test]
fn fofs_cp03_aggregate_counts_not_mean_replication_ratios() {
    let partition = ScientificGrantPartition::try_new(2, global_limits(2, 10)).unwrap();
    let reports = vec![
        synthetic_report(partition, 0, 10, [7, 1, 1, 1], [0, 1, 0, 0], 0, 1),
        synthetic_report(partition, 1, 10, [0, 7, 1, 2], [0, 0, 1, 1], 0, 2),
    ];
    let estimate = aggregate_replications(
        partition,
        RuntimeCount::new(10),
        RuntimeCount::new(10),
        reports,
    )
    .unwrap();
    let ConstructionEstimate::Built(built) = estimate else {
        panic!("all three aggregate denominators are positive")
    };
    assert_eq!(
        built.nominal().s1().as_ratio(),
        &num_rational::BigRational::new(BigInt::from(1), BigInt::from(8))
    );
    assert_ne!(
        built.nominal().s1().as_ratio(),
        &num_rational::BigRational::new(BigInt::from(1), BigInt::from(2))
    );
    assert_eq!(
        built.nominal().s2().as_ratio(),
        &num_rational::BigRational::new(BigInt::from(1), BigInt::from(2))
    );
    assert_eq!(
        built.nominal().c().as_ratio(),
        &num_rational::BigRational::new(BigInt::from(1), BigInt::from(3))
    );
    assert_eq!(
        built.primitive().exposures().map(RuntimeCount::get),
        [7, 8, 2, 3]
    );
}

#[test]
fn fofs_cp03_every_zero_denominator_combination_is_explicit() {
    let partition = ScientificGrantPartition::try_new(1, global_limits(1, 4)).unwrap();
    for positive_mask in 0_u8..8 {
        let mut exposures = [4_u64, 0, 0, 0];
        for fitted in 0..3 {
            if positive_mask & (1 << fitted) != 0 {
                exposures[0] -= 1;
                exposures[fitted + 1] = 1;
            }
        }
        let estimate = aggregate_replications(
            partition,
            RuntimeCount::new(4),
            RuntimeCount::new(4),
            vec![synthetic_report(partition, 0, 4, exposures, [0; 4], 0, 0)],
        )
        .unwrap();
        let expected_unobserved = [
            positive_mask & 1 == 0,
            positive_mask & 2 == 0,
            positive_mask & 4 == 0,
        ];
        if positive_mask == 7 {
            assert!(matches!(estimate, ConstructionEstimate::Built(_)));
        } else {
            let ConstructionEstimate::Unavailable(unavailable) = estimate else {
                panic!("zero denominators must be Unavailable")
            };
            assert_eq!(unavailable.unobserved_bins(), expected_unobserved);
        }
    }
}

#[test]
fn fofs_cp03_canonical_aggregation_is_execution_order_independent() {
    let partition = ScientificGrantPartition::try_new(3, global_limits(3, 4)).unwrap();
    let canonical = vec![
        synthetic_report(partition, 0, 4, [1, 1, 1, 1], [0, 1, 0, 1], 0, 2),
        synthetic_report(partition, 1, 4, [1, 1, 1, 1], [0, 0, 1, 1], 0, 2),
        synthetic_report(partition, 2, 4, [1, 1, 1, 1], [0, 1, 1, 0], 0, 2),
    ];
    let mut reverse = canonical.clone();
    reverse.reverse();
    let first = aggregate_replications(
        partition,
        RuntimeCount::new(4),
        RuntimeCount::new(4),
        canonical,
    )
    .unwrap();
    let second = aggregate_replications(
        partition,
        RuntimeCount::new(4),
        RuntimeCount::new(4),
        reverse,
    )
    .unwrap();
    assert_eq!(first, second);
}

#[test]
fn fofs_cp06_unbounded_search_work_is_aggregated_as_telemetry() {
    let partition = ScientificGrantPartition::try_new(2, global_limits(2, 4)).unwrap();
    let mut reports = vec![
        synthetic_report(partition, 0, 4, [1, 1, 1, 1], [0, 1, 0, 1], 0, 2),
        synthetic_report(partition, 1, 4, [1, 1, 1, 1], [0, 0, 1, 1], 0, 2),
    ];
    for (report, observed) in reports.iter_mut().zip([7, 11]) {
        let ReplicationReport::Completed(evidence) = report else {
            unreachable!()
        };
        evidence.work = ConstructionWorkCounters::for_test(4, 4, observed, 4, 1, 128);
    }

    let estimate = aggregate_replications(
        partition,
        RuntimeCount::new(4),
        RuntimeCount::new(4),
        reports,
    )
    .expect("unbounded observed search work must aggregate");
    let ConstructionEstimate::Built(built) = estimate else {
        panic!("positive response-bin exposures must build")
    };
    assert_eq!(built.work().optimizer_search_states(), 18);
}

#[test]
fn fofs_cp05_failed_replication_is_selected_in_canonical_order() {
    let partition = ScientificGrantPartition::try_new(2, global_limits(2, 4)).unwrap();
    let success = synthetic_report(partition, 0, 4, [1, 1, 1, 1], [0; 4], 0, 0);
    let limits = partition
        .reservation(ReplicationCoordinate::new(1))
        .unwrap()
        .try_work_limits()
        .unwrap();
    let failure = ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
        ReplicationCoordinate::new(1),
        ArrivalReplay::from_seed_material([1; 32], 1),
        ProviderFailureReason::ExactSolverNoIncumbent,
        RunError::ExactOptimizerNoIncumbent {
            stage: RuntimeStage::ActionValidation,
            detail: "injected no-incumbent result".to_owned(),
        },
        limits,
        ConstructionWorkCounters::for_test(4, 1, 0, 0, 0, 0),
        None,
    )));
    let estimate = aggregate_replications(
        partition,
        RuntimeCount::new(4),
        RuntimeCount::new(4),
        vec![failure, success],
    )
    .unwrap();
    let ConstructionEstimate::Failed(failed) = estimate else {
        panic!("provider failure must not produce an artifact")
    };
    assert_eq!(
        failed.reason(),
        ProviderFailureReason::ExactSolverNoIncumbent
    );
    assert_eq!(
        failed.failure_coordinate(),
        Some(ReplicationCoordinate::new(1))
    );
}

#[test]
fn fofs_cp05_grant_overrun_and_arithmetic_overflow_are_failed() {
    let partition = ScientificGrantPartition::try_new(2, global_limits(2, 3)).unwrap();
    let mut overrun = synthetic_report(partition, 0, 3, [0, 1, 1, 1], [0; 4], 0, 0);
    let ReplicationReport::Completed(evidence) = &mut overrun else {
        unreachable!()
    };
    evidence.work = ConstructionWorkCounters::for_test(5, 3, 0, 3, 0, 0);
    let estimate = aggregate_replications(
        partition,
        RuntimeCount::new(3),
        RuntimeCount::new(3),
        vec![
            overrun,
            synthetic_report(partition, 1, 3, [0, 1, 1, 1], [0; 4], 0, 0),
        ],
    )
    .unwrap();
    assert!(matches!(
        estimate,
        ConstructionEstimate::Failed(ref failed)
            if failed.reason() == ProviderFailureReason::ScientificGrantExceeded
    ));

    let overflow_reports = vec![
        synthetic_report(partition, 0, 3, [0, 1, 1, 1], [0; 4], u64::MAX, 0),
        synthetic_report(partition, 1, 3, [0, 1, 1, 1], [0; 4], u64::MAX, 0),
    ];
    let estimate = aggregate_replications(
        partition,
        RuntimeCount::new(3),
        RuntimeCount::new(3),
        overflow_reports,
    )
    .unwrap();
    let ConstructionEstimate::Failed(failed) = estimate else {
        panic!("aggregate count overflow must be provider-authored Failed evidence")
    };
    assert_eq!(failed.reason(), ProviderFailureReason::ArithmeticBound);
    assert!(failed.work().is_some(), "complete work remains encodable");
    assert_eq!(
        failed.reports().len(),
        2,
        "primitive worker evidence is retained"
    );
}

fn qid(position: usize) -> TypedId {
    TypedId::from(format!("q{position}"))
}

#[test]
fn fofs_cp03_streaming_worker_evidence_reconciles_without_path() {
    let catalog = QueueCatalog::try_new(vec![qid(0)]).unwrap();
    let scheduler = ResolvedScheduler {
        priority: vec![qid(0)],
        topology: SchedulerTopology::Interval(IntervalTopology {
            intervals: vec![QueueInterval {
                queue_id: qid(0),
                left: ExactRational::from_integer(BigInt::from(0)),
                right: ExactRational::from_integer(BigInt::from(1)),
            }],
        }),
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let provider = PreparedArrival::try_compile(
        &ResolvedArrival::DeterministicTrace(DeterministicTrace {
            events: vec![
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(0),
                    count: 3,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(3),
                    queue_id: qid(0),
                    count: 1,
                },
            ],
        }),
        &catalog,
    )
    .unwrap();
    let limits = global_limits(1, 4);
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::ZERO,
        RuntimeCount::new(4),
        limits,
    )
    .unwrap();
    let run = PreparedCountRun::try_bind(problem, ArrivalReplay::from_seed_material([0x5a; 32], 7))
        .unwrap();
    let report = run.execute_evidenced(ReplicationCoordinate::new(7));
    let ReplicationReport::Completed(evidence) = report else {
        panic!("deterministic physical replication must complete")
    };
    assert_eq!(
        evidence.response().exposures().map(RuntimeCount::get),
        [1, 1, 1, 1]
    );
    assert_eq!(
        evidence.response().selected().map(RuntimeCount::get),
        [0, 1, 1, 1]
    );
    let reconciliation = evidence.reconciliation();
    assert_eq!(reconciliation.target_backlog_at_w().get(), 0);
    assert_eq!(reconciliation.target_backlog_at_t().get(), 1);
    assert_eq!(reconciliation.scored_target_arrivals().get(), 4);
    assert_eq!(reconciliation.scored_target_services().get(), 3);
    assert_eq!(evidence.work().exact_optimizer_calls(), 4);
    assert_eq!(evidence.work().committed_slots(), 4);
    assert_eq!(evidence.provider_endpoint().expected_slot().get(), 4);
    assert_ne!(
        evidence.provider_endpoint().arrival_cursor_digest(),
        [0; 32]
    );
    assert!(std::mem::size_of_val(&*evidence) < 1_024);
}

#[test]
fn fofs_cp03_failed_attempt_work_is_measured_and_retryable() {
    let catalog = QueueCatalog::try_new(vec![qid(0), qid(1)]).unwrap();
    let scheduler = ResolvedScheduler {
        priority: vec![qid(0), qid(1)],
        topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
            conflicts: vec![ConflictPair {
                first: qid(0),
                second: qid(1),
            }],
            max_search_states: None,
        }),
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let provider = PreparedArrival::try_compile(
        &ResolvedArrival::DeterministicTrace(DeterministicTrace {
            events: vec![
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(0),
                    count: 1,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(1),
                    count: 1,
                },
            ],
        }),
        &catalog,
    )
    .unwrap();
    // The two-vertex conflict frontier expands two active states even for the
    // empty slot-0 request. Give that committed solve its two states and leave
    // one state for the slot-1 attempt, which must then fail on its next
    // expansion. This exercises failed-attempt accounting rather than failing
    // during the first physical slot.
    let limits =
        ConstructionWorkLimits::try_new(2, OptimizerSearchStateGrant::Bounded(3), 4).unwrap();
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::ZERO,
        RuntimeCount::new(2),
        limits,
    )
    .unwrap();
    let run = PreparedCountRun::try_bind(problem, ArrivalReplay::from_seed_material([0xa5; 32], 0))
        .unwrap();
    let first = run.execute_evidenced(ReplicationCoordinate::new(0));
    let second = run.execute_evidenced(ReplicationCoordinate::new(0));
    assert_eq!(first, second);
    let ReplicationReport::Failed(failure) = first else {
        panic!("the remaining search state cannot complete the second conflict solve")
    };
    assert_eq!(
        failure.reason(),
        ProviderFailureReason::ScientificGrantExceeded
    );
    assert_eq!(failure.work().configured_generator_draws(), 4);
    assert_eq!(failure.work().exact_optimizer_calls(), 2);
    assert_eq!(failure.work().optimizer_search_states(), 3);
    assert_eq!(failure.work().committed_slots(), 1);
    assert_eq!(failure.endpoint().unwrap().boundary(), RuntimeCount::new(1));
}

#[test]
fn fofs_cp06_recursive_search_without_ceiling_completes_and_reports_work() {
    let catalog = QueueCatalog::try_new(vec![qid(0), qid(1)]).unwrap();
    let scheduler = ResolvedScheduler {
        priority: vec![qid(0), qid(1)],
        topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
            conflicts: vec![ConflictPair {
                first: qid(0),
                second: qid(1),
            }],
            max_search_states: None,
        }),
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let provider = PreparedArrival::try_compile(
        &ResolvedArrival::DeterministicTrace(DeterministicTrace { events: Vec::new() }),
        &catalog,
    )
    .unwrap();
    let limits = ConstructionWorkLimits::try_new(
        2,
        OptimizerSearchStateGrant::NotApplicable,
        4,
    )
    .unwrap();
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::ZERO,
        RuntimeCount::new(2),
        limits,
    )
    .expect("an omitted search ceiling is valid for a recursive exact optimizer");
    let report = PreparedCountRun::try_bind(
        problem,
        ArrivalReplay::from_seed_material([0xa5; 32], 0),
    )
    .unwrap()
    .execute_evidenced(ReplicationCoordinate::new(0));
    let ReplicationReport::Completed(evidence) = report else {
        panic!("unbounded exact search must not fail admission or execution")
    };
    assert!(evidence.work().optimizer_search_states() > 0);
}
