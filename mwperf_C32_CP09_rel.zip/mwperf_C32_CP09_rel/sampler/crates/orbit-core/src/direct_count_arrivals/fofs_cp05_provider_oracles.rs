use num_bigint::BigInt;

use super::*;
use crate::exact::RationalDomain;
use crate::resolved::{
    CountArrivalEvent, DeterministicTrace, GapProbability, IndependentMarkedRenewal,
    IndependentPrivateMarkovRenewal, JointRoundEmission, MarkedRenewalSource, PeriodicGlobalPhase,
    PeriodicSource, PeriodicSourceDelays, PrivateMarkovSource, StateGap, StateProbability,
};

type TestResult = Result<(), Box<dyn std::error::Error>>;

fn queue(value: &str) -> TypedId {
    TypedId::from(value)
}

fn source(value: &str) -> SourceId {
    SourceId::new(value.to_owned())
}

fn state(value: &str) -> StateId {
    StateId::new(value.to_owned())
}

fn unsigned(value: u64) -> ExactUnsigned {
    ExactUnsigned::from_u64(value)
}

fn probability(text: &str) -> ExactRational {
    ExactRational::parse_canonical(text, RationalDomain::Positive)
        .expect("test probability is canonical")
}

fn catalog() -> Result<QueueCatalog, crate::unit_count::CarrierError> {
    QueueCatalog::try_new(["q0", "q1", "q2", "q3"].map(queue).to_vec())
}

fn deterministic() -> ResolvedArrival {
    ResolvedArrival::DeterministicTrace(DeterministicTrace {
        events: vec![
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q2"),
                count: 3,
            },
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q0"),
                count: 2,
            },
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q0"),
                count: 5,
            },
            CountArrivalEvent {
                slot: unsigned(31),
                queue_id: queue("q1"),
                count: 4,
            },
        ],
    })
}

fn global_periodic() -> ResolvedArrival {
    ResolvedArrival::PeriodicGlobalPhase(PeriodicGlobalPhase {
        period: unsigned(5),
        phase: unsigned(2),
        sources: vec![
            PeriodicSource {
                id: source("a"),
                entries: vec![PeriodicEntry {
                    offset: unsigned(3),
                    queue_id: queue("q0"),
                    count: 2,
                }],
            },
            PeriodicSource {
                id: source("b"),
                entries: vec![
                    PeriodicEntry {
                        offset: unsigned(3),
                        queue_id: queue("q0"),
                        count: 4,
                    },
                    PeriodicEntry {
                        offset: unsigned(0),
                        queue_id: queue("q3"),
                        count: 1,
                    },
                ],
            },
        ],
    })
}

fn delayed_periodic() -> ResolvedArrival {
    ResolvedArrival::PeriodicSourceDelays(PeriodicSourceDelays {
        period: unsigned(4),
        sources: vec![
            DelayedPeriodicSource {
                id: source("early"),
                delay: unsigned(0),
                entries: vec![PeriodicEntry {
                    offset: unsigned(1),
                    queue_id: queue("q1"),
                    count: 3,
                }],
            },
            DelayedPeriodicSource {
                id: source("late"),
                delay: unsigned(9),
                entries: vec![
                    PeriodicEntry {
                        offset: unsigned(0),
                        queue_id: queue("q1"),
                        count: 5,
                    },
                    PeriodicEntry {
                        offset: unsigned(2),
                        queue_id: queue("q2"),
                        count: 2,
                    },
                ],
            },
        ],
    })
}

fn marked() -> ResolvedArrival {
    ResolvedArrival::IndependentMarkedRenewal(IndependentMarkedRenewal {
        sources: vec![
            MarkedRenewalSource {
                id: source("m0"),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::FinitePmf {
                        outcomes: vec![
                            GapProbability {
                                d: unsigned(2),
                                probability: probability("1/2"),
                            },
                            GapProbability {
                                d: unsigned(7),
                                probability: probability("1/2"),
                            },
                        ],
                    },
                    destination_pmf: vec![
                        QueueProbability {
                            queue_id: queue("q0"),
                            probability: probability("1/2"),
                        },
                        QueueProbability {
                            queue_id: queue("q3"),
                            probability: probability("1/2"),
                        },
                    ],
                },
            },
            MarkedRenewalSource {
                id: source("m1"),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::Deterministic { d: unsigned(11) },
                    destination_pmf: vec![QueueProbability {
                        queue_id: queue("q1"),
                        probability: probability("1"),
                    }],
                },
            },
        ],
    })
}

fn private_markov() -> ResolvedArrival {
    let a = state("a");
    let b = state("b");
    ResolvedArrival::IndependentPrivateMarkovRenewal(IndependentPrivateMarkovRenewal {
        sources: vec![PrivateMarkovSource {
            id: source("private"),
            states: vec![a.clone(), b.clone()],
            initial: InitialStateLaw::Distribution(vec![
                StateProbability {
                    state: a.clone(),
                    probability: probability("1/2"),
                },
                StateProbability {
                    state: b.clone(),
                    probability: probability("1/2"),
                },
            ]),
            gaps: vec![
                StateGap {
                    state: a.clone(),
                    d: unsigned(2),
                },
                StateGap {
                    state: b.clone(),
                    d: unsigned(5),
                },
            ],
            transitions: vec![
                MarkovTransition {
                    state: a.clone(),
                    next_state: a.clone(),
                    probability: probability("1/2"),
                },
                MarkovTransition {
                    state: a.clone(),
                    next_state: b.clone(),
                    probability: probability("1/2"),
                },
                MarkovTransition {
                    state: b.clone(),
                    next_state: a.clone(),
                    probability: probability("1/2"),
                },
                MarkovTransition {
                    state: b.clone(),
                    next_state: b,
                    probability: probability("1/2"),
                },
            ],
            destination_pmf: vec![
                QueueProbability {
                    queue_id: queue("q0"),
                    probability: probability("1/2"),
                },
                QueueProbability {
                    queue_id: queue("q2"),
                    probability: probability("1/2"),
                },
            ],
        }],
    })
}

fn shared_rounds() -> ResolvedArrival {
    let z = state("z");
    ResolvedArrival::SharedJointRoundMarkovRenewal(SharedJointRoundMarkovRenewal {
        sources: vec![source("fast"), source("slow")],
        states: vec![z.clone()],
        initial: InitialStateLaw::State(z.clone()),
        outcomes: vec![JointRoundOutcome {
            state: z.clone(),
            next_state: z,
            probability: ExactRational::from_integer(BigInt::from(1)),
            emissions: vec![
                JointRoundEmission {
                    source_id: source("fast"),
                    d: unsigned(1),
                    queue_id: queue("q0"),
                },
                JointRoundEmission {
                    source_id: source("slow"),
                    d: unsigned(7),
                    queue_id: queue("q0"),
                },
            ],
        }],
    })
}

fn definitions() -> Vec<ResolvedArrival> {
    vec![
        deterministic(),
        global_periodic(),
        delayed_periodic(),
        marked(),
        private_markov(),
        shared_rounds(),
    ]
}

const ORACLE_DRAW_GRANT: u64 = 1_000_000;

fn replay(actual_seed: u64, replication_index: u64) -> ArrivalReplay {
    ArrivalReplay::from_seed_material(
        *RngSeed::from_u64(actual_seed).as_bytes(),
        replication_index,
    )
}

fn start_finitely(
    prepared: &PreparedArrival,
    replay: ArrivalReplay,
) -> Result<(ArrivalState, ArrivalWorkCounters), ArrivalError> {
    prepared.try_start_counted(replay, ArrivalDrawBudget::try_new(ORACLE_DRAW_GRANT, 0)?)
}

fn prepare_finitely<'a>(
    prepared: &PreparedArrival,
    slot: RuntimeCount,
    state: &ArrivalState,
    workspace: &'a mut ArrivalWorkspace,
    work: ArrivalWorkCounters,
) -> Result<PreparedArrivalStep<'a>, ArrivalError> {
    prepared.prepare_step_counted(
        slot,
        state,
        workspace,
        ArrivalDrawBudget::try_new(ORACLE_DRAW_GRANT, work.configured_generator_draws)?,
    )
}

fn commit_finitely(
    prepared: &PreparedArrival,
    state: &mut ArrivalState,
    workspace: &mut ArrivalWorkspace,
    work: &mut ArrivalWorkCounters,
) {
    *work = work.saturating_add(prepared.commit_step_counted(state, workspace));
    assert!(work.configured_generator_draws <= ORACLE_DRAW_GRANT);
}

#[test]
fn fofs_cp05_all_providers_match_dense_reference_batches_and_endpoint_state() -> TestResult {
    let catalog = catalog()?;
    for definition in definitions() {
        let prepared = PreparedArrival::try_compile(&definition, &catalog)?;
        let (initial, initial_work) = start_finitely(&prepared, replay(0x1234_5678, 9))?;
        let mut optimized_state = initial.clone();
        let mut dense_state = initial;
        let mut workspace = prepared.try_workspace(&optimized_state)?;
        let mut work = initial_work;
        for slot in 0..48 {
            let optimized_entries = {
                let step = prepare_finitely(
                    &prepared,
                    RuntimeCount::new(slot),
                    &optimized_state,
                    &mut workspace,
                    work,
                )?;
                step.arrivals().to_vec()
            };
            commit_finitely(&prepared, &mut optimized_state, &mut workspace, &mut work);
            let (dense_batch, next_dense) =
                prepared.advance_dense_for_test(RuntimeCount::new(slot), &dense_state)?;
            assert_eq!(optimized_entries, dense_batch.entries(), "slot {slot}");
            dense_state = next_dense;
            assert_eq!(optimized_state, dense_state, "slot {slot}");
        }
        assert_eq!(work.full_dense_clears, 0);
        assert_eq!(work.batch_allocations, 0);
        assert_eq!(work.state_clones, 0);
        assert!(workspace.mutable_bytes() >= catalog.len() * std::mem::size_of::<RuntimeCount>());
    }
    Ok(())
}

#[test]
fn fofs_cp05_sparse_workspace_clears_only_previously_touched_queues() -> TestResult {
    let catalog = catalog()?;
    let prepared = PreparedArrival::try_compile(&deterministic(), &catalog)?;
    let (mut state, mut work) = start_finitely(&prepared, replay(1, 0))?;
    let mut workspace = prepared.try_workspace(&state)?;

    let first = prepare_finitely(&prepared, RuntimeCount::ZERO, &state, &mut workspace, work)?;
    assert_eq!(first.arrivals().len(), 2);
    assert_eq!(first.arrivals()[0].queue(), QueueIndex(0));
    assert_eq!(first.arrivals()[0].count(), RuntimeCount::new(7));
    assert_eq!(first.arrivals()[1].queue(), QueueIndex(2));
    commit_finitely(&prepared, &mut state, &mut workspace, &mut work);

    let idle = prepare_finitely(
        &prepared,
        RuntimeCount::new(1),
        &state,
        &mut workspace,
        work,
    )?;
    assert!(idle.arrivals().is_empty());
    commit_finitely(&prepared, &mut state, &mut workspace, &mut work);
    assert_eq!(work.touched_clears, 2);
    assert_eq!(work.full_dense_clears, 0);
    Ok(())
}

#[test]
fn fofs_cp05_prepared_provider_step_is_atomic_until_explicit_commit() -> TestResult {
    let catalog = catalog()?;
    for definition in definitions() {
        let prepared = PreparedArrival::try_compile(&definition, &catalog)?;
        let (mut state, mut work) = start_finitely(&prepared, replay(17, 0))?;
        let before = state.clone();
        let mut workspace = prepared.try_workspace(&state)?;
        let _step = prepare_finitely(&prepared, RuntimeCount::ZERO, &state, &mut workspace, work)?;
        assert_eq!(state, before);
        PreparedArrival::discard_step(&mut workspace);
        assert_eq!(state, before);
        let _step = prepare_finitely(&prepared, RuntimeCount::ZERO, &state, &mut workspace, work)?;
        commit_finitely(&prepared, &mut state, &mut workspace, &mut work);
        assert_eq!(state.expected_slot(), RuntimeCount::new(1));
    }
    Ok(())
}

#[test]
fn fofs_cp05_compiled_provider_reuses_tables_but_rejects_foreign_session_scratch() -> TestResult {
    let catalog = catalog()?;
    let prepared = PreparedArrival::try_compile(&marked(), &catalog)?;
    let (mut first, mut first_work) = start_finitely(&prepared, replay(23, 0))?;
    let (mut second, mut second_work) = start_finitely(&prepared, replay(23, 1))?;
    assert_ne!(first, second);

    let mut first_workspace = prepared.try_workspace(&first)?;
    let second_before = second.clone();
    assert!(matches!(
        prepare_finitely(
            &prepared,
            RuntimeCount::ZERO,
            &second,
            &mut first_workspace,
            second_work,
        ),
        Err(ArrivalError::CorruptState { .. })
    ));
    assert_eq!(second, second_before);

    let mut second_workspace = prepared.try_workspace(&second)?;
    let step = prepare_finitely(
        &prepared,
        RuntimeCount::ZERO,
        &second,
        &mut second_workspace,
        second_work,
    )?;
    let _ = step.arrivals();
    commit_finitely(
        &prepared,
        &mut second,
        &mut second_workspace,
        &mut second_work,
    );
    assert_eq!(second.expected_slot(), RuntimeCount::new(1));

    let step = prepare_finitely(
        &prepared,
        RuntimeCount::ZERO,
        &first,
        &mut first_workspace,
        first_work,
    )?;
    let _ = step.arrivals();
    commit_finitely(&prepared, &mut first, &mut first_workspace, &mut first_work);
    assert_eq!(first.expected_slot(), RuntimeCount::new(1));
    Ok(())
}

#[test]
fn fofs_cp05_renewal_heap_does_not_draw_ahead_across_long_idle_gaps() -> TestResult {
    let catalog = catalog()?;
    let definition = ResolvedArrival::IndependentMarkedRenewal(IndependentMarkedRenewal {
        sources: vec![MarkedRenewalSource {
            id: source("idle"),
            law: MarkedRenewalLaw::Factorized {
                interarrival: GapLaw::Deterministic { d: unsigned(97) },
                destination_pmf: vec![QueueProbability {
                    queue_id: queue("q0"),
                    probability: probability("1"),
                }],
            },
        }],
    });
    let prepared = PreparedArrival::try_compile(&definition, &catalog)?;
    let (mut state, mut work) = start_finitely(&prepared, replay(3, 0))?;
    let mut workspace = prepared.try_workspace(&state)?;
    for slot in 0..96 {
        let step = prepare_finitely(
            &prepared,
            RuntimeCount::new(slot),
            &state,
            &mut workspace,
            work,
        )?;
        assert!(step.arrivals().is_empty());
        commit_finitely(&prepared, &mut state, &mut workspace, &mut work);
    }
    assert_eq!(work.successor_events, 0);
    let due = prepare_finitely(
        &prepared,
        RuntimeCount::new(96),
        &state,
        &mut workspace,
        work,
    )?;
    assert_eq!(due.arrivals().len(), 1);
    commit_finitely(&prepared, &mut state, &mut workspace, &mut work);
    assert_eq!(work.successor_events, 1);
    Ok(())
}

type OracleBatch = Vec<(u32, u64)>;

fn collect_oracle_window(
    prepared: &PreparedArrival,
    state: &mut ArrivalState,
    workspace: &mut ArrivalWorkspace,
    work: &mut ArrivalWorkCounters,
    start: u64,
    end: u64,
) -> Result<Vec<OracleBatch>, ArrivalError> {
    let mut batches = Vec::new();
    for slot in start..end {
        let step = prepare_finitely(prepared, RuntimeCount::new(slot), state, workspace, *work)?;
        batches.push(
            step.arrivals()
                .iter()
                .map(|arrival| (arrival.queue().0, arrival.count().get()))
                .collect(),
        );
        commit_finitely(prepared, state, workspace, work);
    }
    Ok(batches)
}

fn assert_literal_prefix_endpoint_oracle(
    definition: &ResolvedArrival,
    expected: &[OracleBatch],
    split: usize,
    corrupt: fn(&mut PreparedArrival, &mut ArrivalState),
) -> TestResult {
    assert!(split < expected.len());
    let catalog = catalog()?;
    let mut prepared = PreparedArrival::try_compile(definition, &catalog)?;
    assert_eq!(prepared.family(), definition.family());
    let replay = replay(0x4350_3033, 7);
    let horizon = u64::try_from(expected.len())?;
    let split_slot = u64::try_from(split)?;

    let (mut continuous_state, mut continuous_work) = start_finitely(&prepared, replay)?;
    let mut continuous_workspace = prepared.try_workspace(&continuous_state)?;
    let continuous = collect_oracle_window(
        &prepared,
        &mut continuous_state,
        &mut continuous_workspace,
        &mut continuous_work,
        0,
        horizon,
    )?;
    assert_eq!(continuous, expected);
    assert_eq!(continuous_state.expected_slot(), RuntimeCount::new(horizon));

    let (mut partitioned_state, mut partitioned_work) = start_finitely(&prepared, replay)?;
    let mut prefix_workspace = prepared.try_workspace(&partitioned_state)?;
    let mut partitioned = collect_oracle_window(
        &prepared,
        &mut partitioned_state,
        &mut prefix_workspace,
        &mut partitioned_work,
        0,
        split_slot,
    )?;
    assert_eq!(partitioned.as_slice(), &expected[..split]);

    // A prefix endpoint is sufficient to resume: no semantic state is hidden
    // in the discarded scratch workspace.
    drop(prefix_workspace);
    let mut suffix_workspace = prepared.try_workspace(&partitioned_state)?;
    partitioned.extend(collect_oracle_window(
        &prepared,
        &mut partitioned_state,
        &mut suffix_workspace,
        &mut partitioned_work,
        split_slot,
        horizon,
    )?);
    assert_eq!(partitioned, expected);
    assert_eq!(partitioned_state, continuous_state);

    corrupt(&mut prepared, &mut partitioned_state);
    let corrupted_endpoint = partitioned_state.clone();
    assert!(matches!(
        prepare_finitely(
            &prepared,
            RuntimeCount::new(horizon),
            &partitioned_state,
            &mut suffix_workspace,
            partitioned_work,
        ),
        Err(ArrivalError::CorruptState { .. })
    ));
    assert_eq!(partitioned_state, corrupted_endpoint);
    Ok(())
}

#[test]
fn fofs_cp05_deterministic_trace_definition_prefix_endpoint_and_corrupt_state_oracle() -> TestResult
{
    let definition = ResolvedArrival::DeterministicTrace(DeterministicTrace {
        events: vec![
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q2"),
                count: 3,
            },
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q0"),
                count: 2,
            },
            CountArrivalEvent {
                slot: unsigned(0),
                queue_id: queue("q0"),
                count: 5,
            },
            CountArrivalEvent {
                slot: unsigned(3),
                queue_id: queue("q1"),
                count: 4,
            },
            CountArrivalEvent {
                slot: unsigned(7),
                queue_id: queue("q3"),
                count: 2,
            },
        ],
    });
    let expected = vec![
        vec![(0, 7), (2, 3)],
        vec![],
        vec![],
        vec![(1, 4)],
        vec![],
        vec![],
        vec![],
        vec![(3, 2)],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 3, |_prepared, state| {
        let ArrivalState::DeterministicTrace(state) = state else {
            panic!("deterministic definition produced its matching state")
        };
        state.bucket_cursor = usize::MAX;
    })
}

#[test]
fn fofs_cp05_periodic_global_phase_definition_prefix_endpoint_and_corrupt_state_oracle(
) -> TestResult {
    let definition = ResolvedArrival::PeriodicGlobalPhase(PeriodicGlobalPhase {
        period: unsigned(5),
        phase: unsigned(2),
        sources: vec![
            PeriodicSource {
                id: source("a"),
                entries: vec![PeriodicEntry {
                    offset: unsigned(3),
                    queue_id: queue("q0"),
                    count: 2,
                }],
            },
            PeriodicSource {
                id: source("b"),
                entries: vec![
                    PeriodicEntry {
                        offset: unsigned(3),
                        queue_id: queue("q0"),
                        count: 4,
                    },
                    PeriodicEntry {
                        offset: unsigned(0),
                        queue_id: queue("q3"),
                        count: 1,
                    },
                ],
            },
        ],
    });
    let expected = vec![
        vec![(0, 6)],
        vec![],
        vec![(3, 1)],
        vec![],
        vec![],
        vec![(0, 6)],
        vec![],
        vec![(3, 1)],
        vec![],
        vec![],
        vec![(0, 6)],
        vec![],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 7, |_prepared, state| {
        let ArrivalState::PeriodicGlobalPhase(state) = state else {
            panic!("global-periodic definition produced its matching state")
        };
        state.compiled_binding[0] ^= 0xff;
    })
}

#[test]
fn fofs_cp05_periodic_source_delays_definition_prefix_endpoint_and_corrupt_state_oracle(
) -> TestResult {
    let definition = ResolvedArrival::PeriodicSourceDelays(PeriodicSourceDelays {
        period: unsigned(4),
        sources: vec![
            DelayedPeriodicSource {
                id: source("early"),
                delay: unsigned(0),
                entries: vec![PeriodicEntry {
                    offset: unsigned(1),
                    queue_id: queue("q1"),
                    count: 3,
                }],
            },
            DelayedPeriodicSource {
                id: source("late"),
                delay: unsigned(3),
                entries: vec![
                    PeriodicEntry {
                        offset: unsigned(0),
                        queue_id: queue("q1"),
                        count: 5,
                    },
                    PeriodicEntry {
                        offset: unsigned(2),
                        queue_id: queue("q2"),
                        count: 2,
                    },
                ],
            },
        ],
    });
    let expected = vec![
        vec![],
        vec![(1, 3)],
        vec![],
        vec![(1, 5)],
        vec![],
        vec![(1, 3), (2, 2)],
        vec![],
        vec![(1, 5)],
        vec![],
        vec![(1, 3), (2, 2)],
        vec![],
        vec![(1, 5)],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 4, |_prepared, state| {
        let ArrivalState::PeriodicSourceDelays(state) = state else {
            panic!("delayed-periodic definition produced its matching state")
        };
        let _ = state.next_slots.pop();
    })
}

#[test]
fn fofs_cp05_independent_marked_renewal_definition_prefix_endpoint_and_corrupt_state_oracle(
) -> TestResult {
    let definition = ResolvedArrival::IndependentMarkedRenewal(IndependentMarkedRenewal {
        sources: vec![
            MarkedRenewalSource {
                id: source("two"),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::Deterministic { d: unsigned(2) },
                    destination_pmf: vec![QueueProbability {
                        queue_id: queue("q0"),
                        probability: probability("1"),
                    }],
                },
            },
            MarkedRenewalSource {
                id: source("three"),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::Deterministic { d: unsigned(3) },
                    destination_pmf: vec![QueueProbability {
                        queue_id: queue("q2"),
                        probability: probability("1"),
                    }],
                },
            },
        ],
    });
    let expected = vec![
        vec![],
        vec![(0, 1)],
        vec![(2, 1)],
        vec![(0, 1)],
        vec![],
        vec![(0, 1), (2, 1)],
        vec![],
        vec![(0, 1)],
        vec![(2, 1)],
        vec![(0, 1)],
        vec![],
        vec![(0, 1), (2, 1)],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 5, |_prepared, state| {
        let ArrivalState::IndependentMarkedRenewal(state) = state else {
            panic!("marked-renewal definition produced its matching state")
        };
        let _ = state.cursors.pop();
    })
}

#[test]
fn fofs_cp05_independent_private_markov_definition_prefix_endpoint_and_corrupt_state_oracle(
) -> TestResult {
    let a = state("a");
    let b = state("b");
    let definition =
        ResolvedArrival::IndependentPrivateMarkovRenewal(IndependentPrivateMarkovRenewal {
            sources: vec![PrivateMarkovSource {
                id: source("alternating"),
                states: vec![a.clone(), b.clone()],
                initial: InitialStateLaw::State(a.clone()),
                gaps: vec![
                    StateGap {
                        state: a.clone(),
                        d: unsigned(2),
                    },
                    StateGap {
                        state: b.clone(),
                        d: unsigned(3),
                    },
                ],
                transitions: vec![
                    MarkovTransition {
                        state: a.clone(),
                        next_state: b.clone(),
                        probability: probability("1"),
                    },
                    MarkovTransition {
                        state: b.clone(),
                        next_state: a,
                        probability: probability("1"),
                    },
                ],
                destination_pmf: vec![QueueProbability {
                    queue_id: queue("q1"),
                    probability: probability("1"),
                }],
            }],
        });
    let expected = vec![
        vec![],
        vec![(1, 1)],
        vec![],
        vec![],
        vec![(1, 1)],
        vec![],
        vec![(1, 1)],
        vec![],
        vec![],
        vec![(1, 1)],
        vec![],
        vec![(1, 1)],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 6, |_prepared, state| {
        let ArrivalState::IndependentPrivateMarkovRenewal(state) = state else {
            panic!("private-renewal definition produced its matching state")
        };
        let _ = state.cursors.pop();
    })
}

#[test]
fn fofs_cp05_shared_joint_round_markov_definition_prefix_endpoint_and_corrupt_state_oracle(
) -> TestResult {
    let z = state("z");
    let definition =
        ResolvedArrival::SharedJointRoundMarkovRenewal(SharedJointRoundMarkovRenewal {
            sources: vec![source("fast"), source("slow")],
            states: vec![z.clone()],
            initial: InitialStateLaw::State(z.clone()),
            outcomes: vec![JointRoundOutcome {
                state: z.clone(),
                next_state: z,
                probability: probability("1"),
                emissions: vec![
                    JointRoundEmission {
                        source_id: source("fast"),
                        d: unsigned(2),
                        queue_id: queue("q0"),
                    },
                    JointRoundEmission {
                        source_id: source("slow"),
                        d: unsigned(3),
                        queue_id: queue("q2"),
                    },
                ],
            }],
        });
    let expected = vec![
        vec![],
        vec![(0, 1)],
        vec![(2, 1)],
        vec![(0, 1)],
        vec![],
        vec![(0, 1), (2, 1)],
        vec![],
        vec![(0, 1)],
        vec![(2, 1)],
        vec![(0, 1)],
        vec![],
        vec![(0, 1), (2, 1)],
    ];
    assert_literal_prefix_endpoint_oracle(&definition, &expected, 5, |_prepared, state| {
        let ArrivalState::SharedJointRoundMarkovRenewal(state) = state else {
            panic!("shared-round definition produced its matching state")
        };
        let _ = state.clocks.pop();
    })
}
