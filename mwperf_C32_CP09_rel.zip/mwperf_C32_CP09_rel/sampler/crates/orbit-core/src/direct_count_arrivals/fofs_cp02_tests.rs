use super::{
    ArrivalDrawBudget, ArrivalError, ArrivalReplay, PreparedArrival, PreparedArrivalStep,
    PreparedInitial, PreparedRoundEmission, PreparedSharedOutcome, PreparedSharedRounds,
};
use crate::exact::RuntimeCount;
use crate::rng::{DirectArrivalDrawRole, DirectArrivalRngProvider, PreparedCategorical};
use crate::unit_count::{Arrival, QueueIndex};

type TestResult = Result<(), Box<dyn std::error::Error>>;

fn shared_rounds() -> PreparedArrival {
    let distribution =
        PreparedCategorical::try_from_ordered_integer_masses(vec![0_u32], vec![1_u128])
            .expect("one exact shared outcome");
    PreparedArrival::SharedJointRoundMarkovRenewal(PreparedSharedRounds {
        binding: [0x53; 32],
        queue_count: 2,
        source_count: 2,
        initial: PreparedInitial::Deterministic(0),
        rows: vec![super::PreparedSharedRow {
            distribution,
            outcomes: vec![PreparedSharedOutcome {
                next_state: 0,
                emissions: vec![
                    PreparedRoundEmission {
                        gap: 1,
                        queue: QueueIndex(0),
                    },
                    PreparedRoundEmission {
                        gap: 19,
                        queue: QueueIndex(1),
                    },
                ],
            }],
        }],
    })
}

fn shared_rounds_with_nonuniform_simultaneous_successors() -> PreparedArrival {
    let deterministic_row = |next_state, gaps: [u64; 4]| super::PreparedSharedRow {
        distribution: PreparedCategorical::try_from_ordered_integer_masses(
            vec![0_u32],
            vec![1_u128],
        )
        .expect("one exact shared outcome"),
        outcomes: vec![PreparedSharedOutcome {
            next_state,
            emissions: gaps
                .into_iter()
                .enumerate()
                .map(|(queue, gap)| PreparedRoundEmission {
                    gap,
                    queue: QueueIndex(u32::try_from(queue).expect("four queues fit u32")),
                })
                .collect(),
        }],
    };
    PreparedArrival::SharedJointRoundMarkovRenewal(PreparedSharedRounds {
        binding: [0x91; 32],
        queue_count: 4,
        source_count: 4,
        initial: PreparedInitial::Deterministic(0),
        rows: vec![
            deterministic_row(1, [1, 1, 1, 1]),
            // After the simultaneous origin-zero emissions, rank three is
            // next at origin one even though the old heap root's next clock
            // is two. This is the minimal four-rank batch-repair witness.
            deterministic_row(1, [2, 2, 2, 1]),
        ],
    })
}

fn prepared_arrivals(step: PreparedArrivalStep<'_>) -> Vec<Arrival> {
    step.arrivals().to_vec()
}

#[test]
fn fofs_cp05_full_seed_bridge_preserves_all_bytes_and_replication_coordinate() {
    let material = [
        0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee,
        0xff, 0x10, 0x21, 0x32, 0x43, 0x54, 0x65, 0x76, 0x87, 0x98, 0xa9, 0xba, 0xcb, 0xdc, 0xed,
        0xfe, 0x0f,
    ];
    let replay = ArrivalReplay::from_seed_material(material, 0x0102_0304_0506_0708);
    assert_eq!(*replay.seed.as_bytes(), material);
    assert_eq!(replay.replication_index, 0x0102_0304_0506_0708);

    let encoded = replay
        .address(
            DirectArrivalRngProvider::Marked,
            2,
            5,
            0,
            DirectArrivalDrawRole::Gap,
            0,
        )
        .encode();
    assert_eq!(&encoded[20..28], &0x0102_0304_0506_0708_u64.to_le_bytes());
}

#[test]
fn fofs_cp05_start_charges_provider_words_after_the_four_word_seed_bridge() -> TestResult {
    let prepared = shared_rounds();
    let replay = ArrivalReplay::from_seed_material([0xa5; 32], 7);

    let failure = prepared.try_start_counted(replay, ArrivalDrawBudget::try_new(5, 4)?);
    assert!(matches!(
        failure,
        Err(ArrivalError::ConfiguredGeneratorDrawGrantExceeded {
            maximum: 5,
            consumed: 4,
            requested: 2,
        })
    ));

    let (state, work) = prepared.try_start_counted(replay, ArrivalDrawBudget::try_new(6, 4)?)?;
    assert_eq!(work.configured_generator_draws(), 2);
    assert_eq!(state.expected_slot(), RuntimeCount::ZERO);
    let memory = state.memory_accounting();
    assert!(memory.fixed_cursor_bytes > 0);
    assert_eq!(memory.shared_pending_entries, 2);
    assert!(memory.shared_pending_bytes > 0);
    Ok(())
}

#[test]
fn fofs_cp05_shared_pending_growth_is_staged_and_retryable() -> TestResult {
    let prepared = shared_rounds();
    let replay = ArrivalReplay::from_seed_material([0x3c; 32], 11);
    let (mut state, start_work) =
        prepared.try_start_counted(replay, ArrivalDrawBudget::try_new(256, 4)?)?;
    let mut consumed = 4_u64
        .checked_add(start_work.configured_generator_draws())
        .expect("small fixture work fits");
    let mut workspace = prepared.try_workspace(&state)?;
    let mut saw_expansion = false;

    for origin in 0..32_u64 {
        let before_state = state.clone();
        let before_memory = state.memory_accounting();
        let before_counters = workspace.staged_work;
        let first_arrivals = prepared_arrivals(prepared.prepare_step_counted(
            RuntimeCount::new(origin),
            &state,
            &mut workspace,
            ArrivalDrawBudget::try_new(256, consumed)?,
        )?);

        if workspace.memory_accounting().staged_pending_bytes == 0 {
            let work = prepared.commit_step_counted(&mut state, &mut workspace);
            consumed = consumed
                .checked_add(work.configured_generator_draws())
                .expect("small fixture work fits");
            continue;
        }

        saw_expansion = true;
        assert_eq!(state, before_state);
        assert_eq!(state.memory_accounting(), before_memory);
        assert!(workspace.memory_accounting().staged_pending_entries > 0);
        PreparedArrival::discard_step(&mut workspace);
        assert_eq!(state, before_state);
        assert_eq!(state.memory_accounting(), before_memory);
        assert_eq!(workspace.memory_accounting().staged_pending_bytes, 0);
        assert_eq!(workspace.staged_work, before_counters);

        let grant_failure = prepared.prepare_step_counted(
            RuntimeCount::new(origin),
            &state,
            &mut workspace,
            ArrivalDrawBudget::try_new(consumed + 1, consumed)?,
        );
        assert!(matches!(
            grant_failure,
            Err(ArrivalError::ConfiguredGeneratorDrawGrantExceeded {
                consumed: actual,
                requested: 2,
                ..
            }) if actual == consumed
        ));
        assert_eq!(state, before_state);
        assert_eq!(state.memory_accounting(), before_memory);
        assert_eq!(workspace.memory_accounting().staged_pending_bytes, 0);
        assert_eq!(workspace.staged_work, before_counters);

        workspace.fail_next_shared_pending_reservation_for_test();
        let allocation_failure = prepared.prepare_step_counted(
            RuntimeCount::new(origin),
            &state,
            &mut workspace,
            ArrivalDrawBudget::try_new(256, consumed)?,
        );
        assert!(matches!(
            allocation_failure,
            Err(ArrivalError::ResourceExhausted {
                operation: "shared future overshoot"
            })
        ));
        assert_eq!(state, before_state);
        assert_eq!(state.memory_accounting(), before_memory);
        assert_eq!(workspace.memory_accounting().staged_pending_bytes, 0);
        assert_eq!(workspace.staged_work, before_counters);

        let retry_arrivals = prepared_arrivals(prepared.prepare_step_counted(
            RuntimeCount::new(origin),
            &state,
            &mut workspace,
            ArrivalDrawBudget::try_new(256, consumed)?,
        )?);
        assert_eq!(retry_arrivals, first_arrivals);
        assert_eq!(state, before_state);
        assert_eq!(state.memory_accounting(), before_memory);
        let work = prepared.commit_step_counted(&mut state, &mut workspace);
        assert_eq!(work.configured_generator_draws(), 2);
        assert!(work.shared_pending_expansions > 0);
        assert!(work.shared_pending_reserved_bytes > 0);
        assert_eq!(state.expected_slot(), RuntimeCount::new(origin + 1));
        assert_eq!(
            state.memory_accounting().fixed_cursor_bytes,
            before_memory.fixed_cursor_bytes
        );
        assert!(
            state.memory_accounting().shared_pending_bytes > before_memory.shared_pending_bytes
        );
        assert!(
            state.memory_accounting().shared_pending_entries > before_memory.shared_pending_entries
        );
        break;
    }

    assert!(
        saw_expansion,
        "fixture must exercise pending capacity growth"
    );
    Ok(())
}

#[test]
fn fofs_cp05_shared_due_fronts_repair_the_heap_one_key_at_a_time() -> TestResult {
    let prepared = shared_rounds_with_nonuniform_simultaneous_successors();
    let replay = ArrivalReplay::from_seed_material([0x27; 32], 19);
    let (mut state, start_work) =
        prepared.try_start_counted(replay, ArrivalDrawBudget::try_new(256, 4)?)?;
    let mut consumed = 4_u64
        .checked_add(start_work.configured_generator_draws())
        .expect("small fixture work fits");
    let mut workspace = prepared.try_workspace(&state)?;

    for origin in 0..4_u64 {
        let before = state.clone();
        let (dense_arrivals, dense_next) =
            prepared.advance_dense_for_test(RuntimeCount::new(origin), &before)?;
        let streamed = prepared_arrivals(prepared.prepare_step_counted(
            RuntimeCount::new(origin),
            &state,
            &mut workspace,
            ArrivalDrawBudget::try_new(256, consumed)?,
        )?);
        assert_eq!(streamed, dense_arrivals.entries());
        assert_eq!(state, before, "provider preparation remains prospective");

        if origin == 1 {
            assert_eq!(
                streamed,
                vec![Arrival::new(QueueIndex(3), RuntimeCount::new(1))],
                "the non-root rank with the earliest successor must not be skipped"
            );
            PreparedArrival::discard_step(&mut workspace);
            assert_eq!(state, before, "discard leaves the durable heap unchanged");
            let retry = prepared_arrivals(prepared.prepare_step_counted(
                RuntimeCount::new(origin),
                &state,
                &mut workspace,
                ArrivalDrawBudget::try_new(256, consumed)?,
            )?);
            assert_eq!(retry, streamed, "the same origin is safely retryable");
        }

        let work = prepared.commit_step_counted(&mut state, &mut workspace);
        consumed = consumed
            .checked_add(work.configured_generator_draws())
            .expect("small fixture work fits");
        assert_eq!(
            state, dense_next,
            "streaming and dense provider states differ"
        );
        assert_eq!(state.expected_slot(), RuntimeCount::new(origin + 1));
    }
    Ok(())
}
