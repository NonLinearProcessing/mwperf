use std::error::Error;
use std::fmt;

use num_bigint::{BigInt, BigUint};
use num_rational::BigRational;
use num_traits::{One, Signed, ToPrimitive, Zero};

use crate::error::ArithmeticError;

/// The three exact-rational lexical domains exposed by the canonical schema.
///
/// This is a lexical and sign constraint. Every successful parse is reduced
/// to the same [`BigRational`] normal form regardless of whether the input was
/// an integer, a terminating decimal, or a fraction.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum RationalDomain {
    General,
    Nonnegative,
    Positive,
}

impl fmt::Display for RationalDomain {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::General => formatter.write_str("general"),
            Self::Nonnegative => formatter.write_str("nonnegative"),
            Self::Positive => formatter.write_str("positive"),
        }
    }
}

/// A syntax or sign-domain failure while decoding an exact canonical string.
///
/// Input text is deliberately not retained in the error. The JSON boundary
/// supplies the instance path, and avoiding an owned copy keeps failure size
/// bounded even for an adversarially long numeric string.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ExactParseError {
    InvalidCanonicalInteger,
    InvalidCanonicalRational,
    DomainViolation { required: RationalDomain },
}

impl fmt::Display for ExactParseError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidCanonicalInteger => {
                formatter.write_str("invalid canonical decimal integer")
            }
            Self::InvalidCanonicalRational => {
                formatter.write_str("invalid canonical exact rational")
            }
            Self::DomainViolation { required } => {
                write!(formatter, "exact rational is outside the {required} domain")
            }
        }
    }
}

impl Error for ExactParseError {}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ExactUnsigned(BigUint);

impl ExactUnsigned {
    pub fn zero() -> Self {
        Self(BigUint::zero())
    }

    pub fn from_u64(value: u64) -> Self {
        Self(BigUint::from(value))
    }

    pub fn from_u128(value: u128) -> Self {
        Self(BigUint::from(value))
    }

    pub fn from_biguint(value: BigUint) -> Self {
        Self(value)
    }

    /// Parse one canonical nonnegative decimal integer. Leading zeroes,
    /// signs, whitespace, decimal points, and exponents are rejected.
    pub fn parse_canonical_decimal(text: &str) -> Result<Self, ExactParseError> {
        parse_canonical_unsigned(text)
            .map(Self)
            .ok_or(ExactParseError::InvalidCanonicalInteger)
    }

    pub fn as_biguint(&self) -> &BigUint {
        &self.0
    }

    pub fn into_biguint(self) -> BigUint {
        self.0
    }

    pub fn try_to_u32(&self, quantity: &'static str) -> Result<u32, ArithmeticError> {
        self.0
            .to_u32()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_u64(&self, quantity: &'static str) -> Result<u64, ArithmeticError> {
        self.0
            .to_u64()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_u128(&self, quantity: &'static str) -> Result<u128, ArithmeticError> {
        self.0
            .to_u128()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_usize(&self, quantity: &'static str) -> Result<usize, ArithmeticError> {
        self.0
            .to_usize()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn checked_ratio(
        numerator: Self,
        denominator: Self,
        quantity: &'static str,
    ) -> Result<ExactRational, ArithmeticError> {
        if denominator.0.is_zero() {
            return Err(ArithmeticError::ZeroDenominator { quantity });
        }
        Ok(ExactRational(BigRational::new(
            BigInt::from(numerator.0),
            BigInt::from(denominator.0),
        )))
    }
}

impl fmt::Display for ExactUnsigned {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(formatter)
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ExactSigned(BigInt);

impl ExactSigned {
    pub fn zero() -> Self {
        Self(BigInt::zero())
    }

    pub fn from_i128(value: i128) -> Self {
        Self(BigInt::from(value))
    }

    pub fn from_bigint(value: BigInt) -> Self {
        Self(value)
    }

    /// Parse one canonical signed decimal integer. Negative zero, leading
    /// zeroes, a plus sign, whitespace, decimal points, and exponents are
    /// rejected so there is one spelling per integer.
    pub fn parse_canonical_decimal(text: &str) -> Result<Self, ExactParseError> {
        parse_canonical_signed_integer(text, false)
            .map(Self)
            .ok_or(ExactParseError::InvalidCanonicalInteger)
    }

    pub fn as_bigint(&self) -> &BigInt {
        &self.0
    }

    pub fn into_bigint(self) -> BigInt {
        self.0
    }

    pub fn try_to_i128(&self, quantity: &'static str) -> Result<i128, ArithmeticError> {
        self.0
            .to_i128()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_u64(&self, quantity: &'static str) -> Result<u64, ArithmeticError> {
        self.0
            .to_u64()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_u128(&self, quantity: &'static str) -> Result<u128, ArithmeticError> {
        self.0
            .to_u128()
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }
}

impl fmt::Display for ExactSigned {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(formatter)
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ExactRational(BigRational);

impl ExactRational {
    pub fn new(
        numerator: BigInt,
        denominator: BigInt,
        quantity: &'static str,
    ) -> Result<Self, ArithmeticError> {
        if denominator.is_zero() {
            return Err(ArithmeticError::ZeroDenominator { quantity });
        }
        Ok(Self(BigRational::new(numerator, denominator)))
    }

    pub fn from_integer(value: BigInt) -> Self {
        Self(BigRational::from_integer(value))
    }

    /// Parse exactly the canonical rational-string grammar from the input
    /// schema without passing through binary floating point.
    pub fn parse_canonical(text: &str, domain: RationalDomain) -> Result<Self, ExactParseError> {
        parse_canonical_rational(text, domain).map(Self)
    }

    pub fn as_ratio(&self) -> &BigRational {
        &self.0
    }

    pub fn numerator(&self) -> ExactSigned {
        ExactSigned(self.0.numer().clone())
    }

    pub fn denominator(&self) -> ExactUnsigned {
        let magnitude = self.0.denom().magnitude().clone();
        ExactUnsigned(magnitude)
    }

    pub fn is_zero(&self) -> bool {
        self.0.is_zero()
    }

    pub fn is_positive(&self) -> bool {
        self.0.is_positive()
    }

    /// Exact mathematical floor, including for negative nonintegers.
    pub fn floor(&self) -> ExactSigned {
        let numerator = self.0.numer();
        let denominator = self.0.denom();
        let quotient = numerator / denominator;
        let remainder = numerator % denominator;
        if numerator.is_negative() && !remainder.is_zero() {
            ExactSigned(quotient - BigInt::one())
        } else {
            ExactSigned(quotient)
        }
    }

    /// Exact mathematical ceiling, including for negative nonintegers.
    pub fn ceil(&self) -> ExactSigned {
        let numerator = self.0.numer();
        let denominator = self.0.denom();
        let quotient = numerator / denominator;
        let remainder = numerator % denominator;
        if numerator.is_positive() && !remainder.is_zero() {
            ExactSigned(quotient + BigInt::one())
        } else {
            ExactSigned(quotient)
        }
    }

    pub fn to_integer_exact(&self, quantity: &'static str) -> Result<ExactSigned, ArithmeticError> {
        if self.0.denom() == &BigInt::one() {
            Ok(ExactSigned(self.0.numer().clone()))
        } else {
            Err(ArithmeticError::RepresentationBound { quantity })
        }
    }
}

impl fmt::Display for ExactRational {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}/{}", self.0.numer(), self.0.denom())
    }
}

fn parse_canonical_unsigned(text: &str) -> Option<BigUint> {
    let bytes = text.as_bytes();
    let syntax_is_valid = bytes == b"0"
        || (matches!(bytes.first(), Some(b'1'..=b'9')) && bytes.iter().all(u8::is_ascii_digit));
    if !syntax_is_valid {
        return None;
    }
    BigUint::parse_bytes(bytes, 10)
}

fn parse_canonical_signed_integer(text: &str, permit_negative_zero: bool) -> Option<BigInt> {
    let (negative, magnitude_text) = match text.strip_prefix('-') {
        Some(magnitude) => (true, magnitude),
        None => (false, text),
    };
    let magnitude = parse_canonical_unsigned(magnitude_text)?;
    if negative && magnitude.is_zero() && !permit_negative_zero {
        return None;
    }
    let value = BigInt::from(magnitude);
    Some(if negative { -value } else { value })
}

fn parse_canonical_rational(
    text: &str,
    domain: RationalDomain,
) -> Result<BigRational, ExactParseError> {
    let (negative, unsigned_text) = match text.strip_prefix('-') {
        Some(unsigned) => (true, unsigned),
        None => (false, text),
    };
    if negative && domain != RationalDomain::General {
        return Err(ExactParseError::DomainViolation { required: domain });
    }

    let (magnitude, denominator) = if let Some((numerator_text, denominator_text)) =
        unsigned_text.split_once('/')
    {
        let numerator = parse_canonical_unsigned(numerator_text)
            .ok_or(ExactParseError::InvalidCanonicalRational)?;
        let denominator = parse_canonical_unsigned(denominator_text)
            .filter(|value| !value.is_zero())
            .ok_or(ExactParseError::InvalidCanonicalRational)?;
        (numerator, denominator)
    } else if let Some((whole_text, fraction_text)) = unsigned_text.split_once('.') {
        let whole = parse_canonical_unsigned(whole_text)
            .ok_or(ExactParseError::InvalidCanonicalRational)?;
        if fraction_text.is_empty() || !fraction_text.as_bytes().iter().all(u8::is_ascii_digit) {
            return Err(ExactParseError::InvalidCanonicalRational);
        }
        let fractional = BigUint::parse_bytes(fraction_text.as_bytes(), 10)
            .ok_or(ExactParseError::InvalidCanonicalRational)?;
        let scale = u32::try_from(fraction_text.len())
            .map_err(|_| ExactParseError::InvalidCanonicalRational)?;
        let denominator = BigUint::from(10_u8).pow(scale);
        let magnitude = whole * &denominator + fractional;
        (magnitude, denominator)
    } else {
        let magnitude = parse_canonical_unsigned(unsigned_text)
            .ok_or(ExactParseError::InvalidCanonicalRational)?;
        (magnitude, BigUint::one())
    };

    if domain == RationalDomain::Positive && magnitude.is_zero() {
        return Err(ExactParseError::DomainViolation { required: domain });
    }
    let numerator = BigInt::from(magnitude);
    let signed_numerator = if negative { -numerator } else { numerator };
    Ok(BigRational::new(
        signed_numerator,
        BigInt::from(denominator),
    ))
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeCount(u64);

impl RuntimeCount {
    pub const ZERO: Self = Self(0);

    pub const fn new(value: u64) -> Self {
        Self(value)
    }

    pub const fn get(self) -> u64 {
        self.0
    }

    pub fn try_from_biguint(
        value: &BigUint,
        quantity: &'static str,
    ) -> Result<Self, ArithmeticError> {
        value
            .to_u64()
            .map(Self)
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_from_bigint(
        value: &BigInt,
        quantity: &'static str,
    ) -> Result<Self, ArithmeticError> {
        value
            .to_u64()
            .map(Self)
            .ok_or(ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_from_u128(value: u128, quantity: &'static str) -> Result<Self, ArithmeticError> {
        u64::try_from(value)
            .map(Self)
            .map_err(|_| ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_u32(self, quantity: &'static str) -> Result<u32, ArithmeticError> {
        u32::try_from(self.0).map_err(|_| ArithmeticError::RepresentationBound { quantity })
    }

    pub fn try_to_usize(self, quantity: &'static str) -> Result<usize, ArithmeticError> {
        usize::try_from(self.0).map_err(|_| ArithmeticError::RepresentationBound { quantity })
    }

    pub fn checked_add(self, rhs: Self, operation: &'static str) -> Result<Self, ArithmeticError> {
        self.0
            .checked_add(rhs.0)
            .map(Self)
            .ok_or(ArithmeticError::Overflow { operation })
    }

    pub fn checked_sub(self, rhs: Self, operation: &'static str) -> Result<Self, ArithmeticError> {
        self.0
            .checked_sub(rhs.0)
            .map(Self)
            .ok_or(ArithmeticError::Overflow { operation })
    }

    pub fn checked_mul(self, rhs: Self, operation: &'static str) -> Result<Self, ArithmeticError> {
        self.0
            .checked_mul(rhs.0)
            .map(Self)
            .ok_or(ArithmeticError::Overflow { operation })
    }

    pub fn checked_div(self, rhs: Self, quantity: &'static str) -> Result<Self, ArithmeticError> {
        if rhs == Self::ZERO {
            return Err(ArithmeticError::ZeroDenominator { quantity });
        }
        Ok(Self(self.0 / rhs.0))
    }
}

#[cfg(test)]
mod tests {
    use std::error::Error;

    use num_bigint::{BigInt, BigUint};
    use num_rational::BigRational;
    use num_traits::{One, Zero};

    use super::{ExactRational, ExactSigned, ExactUnsigned, RationalDomain, RuntimeCount};

    const PROPERTY_SEED: u64 = 0xd1b5_4a32_d192_ed03;
    const PROPERTY_CASES: usize = 4_096;

    struct FixedCases {
        state: u64,
    }

    impl FixedCases {
        const fn new(seed: u64) -> Self {
            Self { state: seed }
        }

        fn next_u64(&mut self) -> u64 {
            // A fixed modular recurrence used only to enumerate reproducible
            // property cases. The u128 calculation performs the modulus
            // explicitly; production arithmetic never inherits this rule.
            let expanded = (u128::from(self.state) * 6_364_136_223_846_793_005_u128
                + 1_442_695_040_888_963_407_u128)
                % (1_u128 << 64);
            let bytes = expanded.to_le_bytes();
            let next = u64::from_le_bytes([
                bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
            ]);
            self.state = next;
            next
        }
    }

    #[test]
    fn fofs_cp05_canonical_rational_grammar_and_normalization() -> Result<(), Box<dyn Error>> {
        let accepted = [
            ("0", RationalDomain::General, "0/1"),
            ("-0", RationalDomain::General, "0/1"),
            ("123", RationalDomain::General, "123/1"),
            ("-123", RationalDomain::General, "-123/1"),
            ("6/8", RationalDomain::General, "3/4"),
            ("-6/8", RationalDomain::General, "-3/4"),
            ("12.3400", RationalDomain::General, "617/50"),
            ("-0.125", RationalDomain::General, "-1/8"),
            ("0/999", RationalDomain::Nonnegative, "0/1"),
            ("0.000", RationalDomain::Nonnegative, "0/1"),
            ("0.0100", RationalDomain::Positive, "1/100"),
            ("1.0", RationalDomain::Positive, "1/1"),
        ];
        for (input, domain, expected) in accepted {
            let parsed = ExactRational::parse_canonical(input, domain)?;
            assert_eq!(parsed.to_string(), expected);
        }

        let invalid = [
            "", "+1", " 1", "1 ", "01", "-01", ".5", "-.5", "1.", "1e0", "1E0", "1/0", "1/-2",
            "1/+2", "1/02", "1//2", "1.2/3", "1/2.0", "NaN",
        ];
        for input in invalid {
            assert!(ExactRational::parse_canonical(input, RationalDomain::General).is_err());
        }
        assert!(ExactRational::parse_canonical("-1", RationalDomain::Nonnegative).is_err());
        assert!(ExactRational::parse_canonical("0", RationalDomain::Positive).is_err());
        assert!(ExactRational::parse_canonical("0.000", RationalDomain::Positive).is_err());

        let wide = "340282366920938463463374607431768211456/3";
        let parsed = ExactRational::parse_canonical(wide, RationalDomain::Positive)?;
        assert_eq!(parsed.denominator().to_string(), "3");
        Ok(())
    }

    #[test]
    fn fofs_cp05_canonical_decimal_integers_have_one_spelling() -> Result<(), Box<dyn Error>> {
        assert_eq!(
            ExactUnsigned::parse_canonical_decimal("0")?.to_string(),
            "0"
        );
        assert_eq!(
            ExactUnsigned::parse_canonical_decimal("18446744073709551616")?.to_string(),
            "18446744073709551616"
        );
        assert_eq!(
            ExactSigned::parse_canonical_decimal("-170141183460469231731687303715884105728")?
                .to_string(),
            "-170141183460469231731687303715884105728"
        );
        for invalid in ["", "00", "01", "-0", "+1", "1.0", "1e0", " 1"] {
            assert!(ExactSigned::parse_canonical_decimal(invalid).is_err());
        }
        for invalid in ["", "00", "01", "-1", "+1", "1.0", "1e0", " 1"] {
            assert!(ExactUnsigned::parse_canonical_decimal(invalid).is_err());
        }
        Ok(())
    }

    #[test]
    fn fofs_cp05_rational_reduces_sign_and_gcd_exactly() -> Result<(), Box<dyn Error>> {
        let cases = [
            (6_i32, 8_i32, "3/4"),
            (6, -8, "-3/4"),
            (-6, -8, "3/4"),
            (0, -8, "0/1"),
        ];
        for (numerator, denominator, expected) in cases {
            let value = ExactRational::new(
                BigInt::from(numerator),
                BigInt::from(denominator),
                "test ratio",
            )?;
            assert_eq!(value.to_string(), expected);
        }
        assert!(ExactRational::new(BigInt::from(1), BigInt::zero(), "test ratio").is_err());
        Ok(())
    }

    #[test]
    fn fofs_cp05_floor_and_ceil_are_exact_for_all_signs() -> Result<(), Box<dyn Error>> {
        let cases = [
            ("3/2", "1", "2"),
            ("-3/2", "-2", "-1"),
            ("4/2", "2", "2"),
            ("-4/2", "-2", "-2"),
            ("0", "0", "0"),
        ];
        for (input, expected_floor, expected_ceil) in cases {
            let value = ExactRational::parse_canonical(input, RationalDomain::General)?;
            assert_eq!(value.floor().to_string(), expected_floor);
            assert_eq!(value.ceil().to_string(), expected_ceil);
        }
        let noninteger = ExactRational::parse_canonical("1/3", RationalDomain::Positive)?;
        assert!(noninteger.to_integer_exact("integer-only value").is_err());
        let integer = ExactRational::parse_canonical("9/3", RationalDomain::Positive)?;
        assert_eq!(
            integer.to_integer_exact("integer-only value")?.to_string(),
            "3"
        );
        Ok(())
    }

    #[test]
    fn fofs_cp05_fixed_width_conversions_cover_zero_maximum_and_neighbors(
    ) -> Result<(), Box<dyn Error>> {
        let zero = BigUint::zero();
        let u64_maximum = BigUint::from(u64::MAX);
        let u64_too_large = &u64_maximum + BigUint::one();
        assert_eq!(RuntimeCount::try_from_biguint(&zero, "count")?.get(), 0);
        assert_eq!(
            RuntimeCount::try_from_biguint(&u64_maximum, "count")?.get(),
            u64::MAX
        );
        assert!(RuntimeCount::try_from_biguint(&u64_too_large, "count").is_err());
        assert!(RuntimeCount::try_from_bigint(&BigInt::from(-1), "count").is_err());

        assert_eq!(
            ExactSigned::from_i128(i128::MIN).try_to_i128("signed")?,
            i128::MIN
        );
        assert_eq!(
            ExactSigned::from_i128(i128::MAX).try_to_i128("signed")?,
            i128::MAX
        );
        assert!(ExactSigned::from_i128(-1).try_to_u128("unsigned").is_err());
        assert_eq!(
            ExactUnsigned::from_u128(u128::MAX).try_to_u128("unsigned")?,
            u128::MAX
        );
        assert!(RuntimeCount::new(u64::MAX).try_to_u32("index").is_err());
        Ok(())
    }

    #[test]
    fn fofs_cp05_every_direct_conversion_checks_both_fixed_width_boundaries(
    ) -> Result<(), Box<dyn Error>> {
        let i128_maximum = BigInt::from(i128::MAX);
        let i128_minimum = BigInt::from(i128::MIN);
        assert_eq!(
            ExactSigned::from_bigint(i128_maximum.clone()).try_to_i128("signed")?,
            i128::MAX
        );
        assert_eq!(
            ExactSigned::from_bigint(i128_minimum.clone()).try_to_i128("signed")?,
            i128::MIN
        );
        assert!(ExactSigned::from_bigint(i128_maximum + BigInt::one())
            .try_to_i128("signed")
            .is_err());
        assert!(ExactSigned::from_bigint(i128_minimum - BigInt::one())
            .try_to_i128("signed")
            .is_err());

        let u64_maximum = BigInt::from(u64::MAX);
        assert_eq!(ExactSigned::zero().try_to_u64("unsigned count")?, 0);
        assert_eq!(
            ExactSigned::from_bigint(u64_maximum.clone()).try_to_u64("unsigned count")?,
            u64::MAX
        );
        assert!(ExactSigned::from_bigint(u64_maximum + BigInt::one())
            .try_to_u64("unsigned count")
            .is_err());

        let u32_maximum = BigUint::from(u32::MAX);
        assert_eq!(
            ExactUnsigned::from_biguint(u32_maximum.clone()).try_to_u32("dense index")?,
            u32::MAX
        );
        assert!(ExactUnsigned::from_biguint(u32_maximum + BigUint::one())
            .try_to_u32("dense index")
            .is_err());

        let unsigned_u64_maximum = BigUint::from(u64::MAX);
        assert_eq!(
            ExactUnsigned::from_biguint(unsigned_u64_maximum.clone())
                .try_to_u64("runtime count")?,
            u64::MAX
        );
        assert!(
            ExactUnsigned::from_biguint(unsigned_u64_maximum + BigUint::one())
                .try_to_u64("runtime count")
                .is_err()
        );

        let usize_maximum = BigUint::from(usize::MAX);
        assert_eq!(
            ExactUnsigned::from_biguint(usize_maximum.clone()).try_to_usize("allocation length")?,
            usize::MAX
        );
        assert!(ExactUnsigned::from_biguint(usize_maximum + BigUint::one())
            .try_to_usize("allocation length")
            .is_err());

        assert_eq!(
            RuntimeCount::try_from_u128(u128::from(u64::MAX), "runtime count")?.get(),
            u64::MAX
        );
        assert!(RuntimeCount::try_from_u128(u128::from(u64::MAX) + 1, "runtime count").is_err());
        Ok(())
    }

    #[test]
    fn fofs_cp05_runtime_arithmetic_rejects_overflow_and_underflow() {
        assert_eq!(
            RuntimeCount::new(u64::MAX - 1)
                .checked_add(RuntimeCount::new(1), "count increment")
                .map(RuntimeCount::get),
            Ok(u64::MAX)
        );
        assert!(RuntimeCount::new(u64::MAX)
            .checked_add(RuntimeCount::new(1), "count increment")
            .is_err());
        assert!(RuntimeCount::ZERO
            .checked_sub(RuntimeCount::new(1), "count decrement")
            .is_err());
        assert!(RuntimeCount::new(u64::MAX)
            .checked_mul(RuntimeCount::new(2), "count product")
            .is_err());
        assert!(RuntimeCount::new(1)
            .checked_div(RuntimeCount::ZERO, "count divisor")
            .is_err());
    }

    #[test]
    fn fofs_cp05_fixed_seed_properties_match_arbitrary_precision_references(
    ) -> Result<(), Box<dyn Error>> {
        let mut cases = FixedCases::new(PROPERTY_SEED);
        let u64_maximum = BigUint::from(u64::MAX);

        for _case in 0..PROPERTY_CASES {
            let left = cases.next_u64();
            let right = cases.next_u64();

            let exact_sum = BigUint::from(left) + BigUint::from(right);
            let runtime_sum =
                RuntimeCount::new(left).checked_add(RuntimeCount::new(right), "property count sum");
            assert_eq!(runtime_sum.is_ok(), exact_sum <= u64_maximum);

            let exact_product = BigUint::from(left) * BigUint::from(right);
            let runtime_product = RuntimeCount::new(left)
                .checked_mul(RuntimeCount::new(right), "property count product");
            assert_eq!(runtime_product.is_ok(), exact_product <= u64_maximum);

            let signed_bytes = cases.next_u64().to_le_bytes();
            let numerator = i64::from_le_bytes(signed_bytes);
            let denominator = cases.next_u64() % 1_000_000 + 1;
            let ratio = ExactRational::new(
                BigInt::from(numerator),
                BigInt::from(denominator),
                "property ratio",
            )?;
            let floor = ratio.floor().into_bigint();
            let ceil = ratio.ceil().into_bigint();
            let floor_ratio = BigRational::from_integer(floor.clone());
            let floor_successor = BigRational::from_integer(floor + BigInt::one());
            let ceil_ratio = BigRational::from_integer(ceil.clone());
            let ceil_predecessor = BigRational::from_integer(ceil - BigInt::one());
            assert!(floor_ratio <= *ratio.as_ratio());
            assert!(*ratio.as_ratio() < floor_successor);
            assert!(*ratio.as_ratio() <= ceil_ratio);
            assert!(ceil_predecessor < *ratio.as_ratio());

            let fraction_denominator = BigUint::from(cases.next_u64()) + BigUint::one();
            let fraction_spelling = format!("{numerator}/{fraction_denominator}");
            let parsed_fraction =
                ExactRational::parse_canonical(&fraction_spelling, RationalDomain::General)?;
            let reference_fraction =
                BigRational::new(BigInt::from(numerator), BigInt::from(fraction_denominator));
            assert_eq!(parsed_fraction.as_ratio(), &reference_fraction);

            let decimal_whole = cases.next_u64() % 1_000_000;
            let decimal_fraction = cases.next_u64() % 1_000_000;
            let decimal_is_negative = cases.next_u64() % 2 == 1;
            let decimal_sign = if decimal_is_negative { "-" } else { "" };
            let decimal_spelling = format!("{decimal_sign}{decimal_whole}.{decimal_fraction:06}");
            let parsed_decimal =
                ExactRational::parse_canonical(&decimal_spelling, RationalDomain::General)?;
            let decimal_scale = BigInt::from(1_000_000_u64);
            let decimal_magnitude =
                BigInt::from(decimal_whole) * &decimal_scale + BigInt::from(decimal_fraction);
            let decimal_numerator = if decimal_is_negative {
                -decimal_magnitude
            } else {
                decimal_magnitude
            };
            let reference_decimal = BigRational::new(decimal_numerator, decimal_scale);
            assert_eq!(parsed_decimal.as_ratio(), &reference_decimal);
        }
        Ok(())
    }
}
