//! Platform-independent finite-window sampling intervals for FOFS CP03.
//!
//! The sampling unit is one independently addressed whole physical path.  No
//! slot is treated as IID.  All transcendental work is enclosed with exact
//! integers and rationals.  Binary64 values are produced by comparing exact
//! rationals with IEEE-754 bit patterns; the host's logarithm, square root,
//! floating-point mode, and parser are never consulted.

use std::array;

use num_bigint::{BigInt, BigUint, Sign};
use num_rational::BigRational;
use num_traits::{One, Zero};
use thiserror::Error;

/// First working precision required by the v1 evidence procedure.
pub const V1_INITIAL_FRACTION_BITS: u32 = 256;
/// Last working precision permitted by the v1 evidence procedure.
pub const V1_MAX_FRACTION_BITS: u32 = 16_384;
/// Cumulative exact-series term cap for one interval computation.
pub const V1_MAX_TOTAL_SERIES_TERMS: u64 = 1_000_000;

const BINARY64_ONE_BITS: u64 = 0x3ff0_0000_0000_0000;
const BINARY64_MAX_FINITE_BITS: u64 = 0x7fef_ffff_ffff_ffff;

/// The immutable v1 arithmetic limits.
///
/// The private field prevents a production caller from inventing a different
/// interval procedure while still allowing the fixed limits to be passed
/// explicitly through prepared construction state.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct IntervalComputationLimits {
    _v1: (),
}

impl IntervalComputationLimits {
    /// The only production limit set for
    /// `simultaneous_hoeffding_ratio_envelope_v1`.
    pub const V1: Self = Self { _v1: () };

    #[must_use]
    pub const fn initial_fraction_bits(self) -> u32 {
        V1_INITIAL_FRACTION_BITS
    }

    #[must_use]
    pub const fn maximum_fraction_bits(self) -> u32 {
        V1_MAX_FRACTION_BITS
    }

    #[must_use]
    pub const fn maximum_total_series_terms(self) -> u64 {
        V1_MAX_TOTAL_SERIES_TERMS
    }
}

/// One whole-path target ledger, in bins `0,1,2,3`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ReplicationLedger {
    pub exposures: [u64; 4],
    pub selected: [u64; 4],
}

/// An exact-rational enclosure of one real number.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RationalEnclosure {
    pub lower: BigRational,
    pub upper: BigRational,
}

impl RationalEnclosure {
    fn new(lower: BigRational, upper: BigRational) -> Self {
        debug_assert!(lower <= upper);
        Self { lower, upper }
    }

    fn exact(value: BigRational) -> Self {
        Self {
            lower: value.clone(),
            upper: value,
        }
    }
}

/// A nonnegative finite binary64 represented by its canonical IEEE-754 bits.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DirectedBinary64 {
    pub bits: u64,
}

impl DirectedBinary64 {
    /// Materialize the already-decided IEEE-754 bit pattern.
    #[must_use]
    pub fn to_f64(self) -> f64 {
        f64::from_bits(self.bits)
    }
}

/// Final outward-rounded simultaneous ratio interval.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DirectedBinary64Interval {
    /// Rounded toward minus infinity.
    pub lower: DirectedBinary64,
    /// Rounded toward plus infinity.
    pub upper: DirectedBinary64,
}

/// Legal C15 empirical status selected from the population-exposure bound.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EmpiricalIntervalStatus {
    PositiveWithConfidenceIntervalOnly,
    UnresolvedIntervalOnly,
}

/// Whether the v1 ratio formula had an informative positive denominator.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RatioIntervalBranch {
    PositiveExposure,
    UninformativeExposure,
}

/// Exact and directed evidence for one of the three fitted bins.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BinSamplingInterval {
    pub bin: u8,
    /// `mean_r E[r,bin]/L`, formed from aggregate counts.
    pub mean_exposure: BigRational,
    /// `mean_r Y[r,bin]/L`, formed from aggregate counts.
    pub mean_selected: BigRational,
    /// Enclosure of `max(0, mean_exposure - epsilon)`.
    pub exposure_lower_endpoint: RationalEnclosure,
    /// Enclosure of `min(1, mean_exposure + epsilon)`.
    pub exposure_upper_endpoint: RationalEnclosure,
    /// Enclosure of `max(0, mean_selected - epsilon)`.
    pub selected_lower_endpoint: RationalEnclosure,
    /// Enclosure of `min(1, mean_selected + epsilon)`.
    pub selected_upper_endpoint: RationalEnclosure,
    /// Enclosure of the mathematical lower ratio endpoint.
    pub ratio_lower_endpoint: RationalEnclosure,
    /// Enclosure of the mathematical upper ratio endpoint.
    pub ratio_upper_endpoint: RationalEnclosure,
    /// Outward-rounded `[XL,XU]` exposure-mean interval.
    pub directed_exposure_interval: DirectedBinary64Interval,
    /// Outward-rounded `[ZL,ZU]` selected-mean interval.
    pub directed_selected_interval: DirectedBinary64Interval,
    /// Outward-rounded v1 ratio interval.
    pub directed_interval: DirectedBinary64Interval,
    pub status: EmpiricalIntervalStatus,
    pub branch: RatioIntervalBranch,
}

/// Reproducibility counters for the exact transcendental enclosure.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct IntervalArithmeticEvidence {
    pub fractional_bits: u32,
    pub final_round_ln_m_terms: u64,
    pub final_round_ln_two_terms: u64,
    pub cumulative_series_terms: u64,
}

/// The mandatory v1 simultaneous three-bin sampling-evidence block.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ThreeBinSamplingIntervals {
    pub familywise_alpha: BigRational,
    pub replication_count: u64,
    pub window_length: u64,
    pub aggregate_exposures: [BigUint; 4],
    pub aggregate_selected: [BigUint; 4],
    /// Exact enclosure of `sqrt(ln(12/alpha)/(2R))`.
    pub epsilon: RationalEnclosure,
    /// Canonical bin order `1,2,3`.
    pub bins: [BinSamplingInterval; 3],
    pub arithmetic: IntervalArithmeticEvidence,
}

#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum IntervalError {
    #[error("familywise alpha must be an exact rational strictly between zero and one")]
    InvalidFamilywiseAlpha,
    #[error("at least one independent whole-path replication is required")]
    EmptyReplicationBank,
    #[error("the scored window length must be positive")]
    ZeroWindowLength,
    #[error("the replication count is not representable as u64")]
    ReplicationCountUnrepresentable,
    #[error("replication {replication} exposure bins do not sum to the scored window length")]
    ExposureCoverageMismatch { replication: usize },
    #[error("replication {replication}, bin {bin} has selected count above exposure")]
    SelectedAboveExposure { replication: usize, bin: usize },
    #[error("replication {replication} has selected service in bin zero")]
    SelectedInZeroBin { replication: usize },
    #[error("an exact arithmetic operand is too large for the host address space")]
    OperandUnrepresentable,
    #[error(
        "evidence_rounding_unresolved at p={fractional_bits} after {series_terms} series terms"
    )]
    EvidenceRoundingUnresolved {
        fractional_bits: u32,
        series_terms: u64,
    },
}

impl IntervalError {
    #[must_use]
    pub const fn code(&self) -> &'static str {
        match self {
            Self::InvalidFamilywiseAlpha => "invalid_familywise_alpha",
            Self::EmptyReplicationBank => "empty_replication_bank",
            Self::ZeroWindowLength => "zero_window_length",
            Self::ReplicationCountUnrepresentable => "replication_count_unrepresentable",
            Self::ExposureCoverageMismatch { .. } => "exposure_coverage_mismatch",
            Self::SelectedAboveExposure { .. } => "selected_above_exposure",
            Self::SelectedInZeroBin { .. } => "selected_in_zero_bin",
            Self::OperandUnrepresentable => "operand_unrepresentable",
            Self::EvidenceRoundingUnresolved { .. } => "evidence_rounding_unresolved",
        }
    }
}

#[derive(Clone, Copy)]
struct ArithmeticCaps {
    initial_bits: u32,
    maximum_bits: u32,
    maximum_terms: u64,
}

impl From<IntervalComputationLimits> for ArithmeticCaps {
    fn from(limits: IntervalComputationLimits) -> Self {
        Self {
            initial_bits: limits.initial_fraction_bits(),
            maximum_bits: limits.maximum_fraction_bits(),
            maximum_terms: limits.maximum_total_series_terms(),
        }
    }
}

#[derive(Clone)]
struct LogEnclosure {
    bounds: RationalEnclosure,
    ln_m_terms: u64,
    ln_two_terms: u64,
}

#[derive(Clone)]
struct PendingBin {
    bin: u8,
    mean_exposure: BigRational,
    mean_selected: BigRational,
    exposure_lower_endpoint: RationalEnclosure,
    exposure_upper_endpoint: RationalEnclosure,
    selected_lower_endpoint: RationalEnclosure,
    selected_upper_endpoint: RationalEnclosure,
    ratio_lower_endpoint: RationalEnclosure,
    ratio_upper_endpoint: RationalEnclosure,
    status: EmpiricalIntervalStatus,
    branch: RatioIntervalBranch,
}

#[derive(Clone, Copy)]
struct DirectedBinEndpoints {
    exposure: DirectedBinary64Interval,
    selected: DirectedBinary64Interval,
    ratio: DirectedBinary64Interval,
}

/// Compute the fixed v1 simultaneous finite-window evidence interval.
///
/// `replications.len()` is `R`, and every ledger is one independent whole
/// physical path observed over exactly `window_length = T-W` slots.  The
/// routine rejects a ledger that does not reconcile rather than silently
/// renormalizing it.
///
/// # Errors
///
/// Returns an input-reconciliation error for an invalid alpha, empty bank,
/// zero-length window, or inconsistent ledger. Returns
/// [`IntervalError::EvidenceRoundingUnresolved`] if exact outward rounding is
/// not decided under the frozen precision or series-term cap.
pub fn compute_three_bin_sampling_intervals(
    alpha: &BigRational,
    replications: &[ReplicationLedger],
    window_length: u64,
    limits: IntervalComputationLimits,
) -> Result<ThreeBinSamplingIntervals, IntervalError> {
    compute_with_caps(alpha, replications, window_length, limits.into())
}

/// Exact-arithmetic enclosure of the three-region Hoeffding radius.
///
/// This is a neutral arithmetic seam shared by the CP03 count estimator and
/// the CP07 weighted estimator.  It consumes no count ledger or replication
/// evidence: `independent_ensembles` is the complete statistical sample size.
pub(crate) fn compute_three_region_hoeffding_radius(
    alpha: &BigRational,
    independent_ensembles: u64,
    limits: IntervalComputationLimits,
) -> Result<DirectedBinary64Interval, IntervalError> {
    if alpha <= &BigRational::zero() || alpha >= &BigRational::one() {
        return Err(IntervalError::InvalidFamilywiseAlpha);
    }
    if independent_ensembles == 0 {
        return Err(IntervalError::EmptyReplicationBank);
    }

    let caps: ArithmeticCaps = limits.into();
    let mut cumulative_series_terms = 0_u64;
    let log = log_twelve_over_alpha(
        alpha,
        caps.initial_bits,
        &mut cumulative_series_terms,
        caps,
    )?;
    let divisor = BigRational::from_integer(BigInt::from(independent_ensembles) * 2);
    let radicand =
        RationalEnclosure::new(&log.bounds.lower / &divisor, &log.bounds.upper / &divisor);
    let radius = sqrt_enclosure(&radicand, caps.initial_bits)?;
    let lower = directed_nonnegative_binary64_bits(&radius.lower, false)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    let upper = directed_nonnegative_binary64_bits(&radius.upper, true)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    Ok(DirectedBinary64Interval {
        lower: DirectedBinary64 { bits: lower },
        upper: DirectedBinary64 { bits: upper },
    })
}

fn compute_with_caps(
    alpha: &BigRational,
    replications: &[ReplicationLedger],
    window_length: u64,
    caps: ArithmeticCaps,
) -> Result<ThreeBinSamplingIntervals, IntervalError> {
    if alpha <= &BigRational::zero() || alpha >= &BigRational::one() {
        return Err(IntervalError::InvalidFamilywiseAlpha);
    }
    if replications.is_empty() {
        return Err(IntervalError::EmptyReplicationBank);
    }
    if window_length == 0 {
        return Err(IntervalError::ZeroWindowLength);
    }
    let replication_count = u64::try_from(replications.len())
        .map_err(|_| IntervalError::ReplicationCountUnrepresentable)?;

    let mut aggregate_exposures: [BigUint; 4] = array::from_fn(|_| BigUint::zero());
    let mut aggregate_selected: [BigUint; 4] = array::from_fn(|_| BigUint::zero());
    for (replication, ledger) in replications.iter().enumerate() {
        let coverage = ledger
            .exposures
            .iter()
            .fold(BigUint::zero(), |sum, count| sum + *count);
        if coverage != BigUint::from(window_length) {
            return Err(IntervalError::ExposureCoverageMismatch { replication });
        }
        if ledger.selected[0] != 0 {
            return Err(IntervalError::SelectedInZeroBin { replication });
        }
        for bin in 0..4 {
            if ledger.selected[bin] > ledger.exposures[bin] {
                return Err(IntervalError::SelectedAboveExposure { replication, bin });
            }
            aggregate_exposures[bin] += ledger.exposures[bin];
            aggregate_selected[bin] += ledger.selected[bin];
        }
    }

    let sample_denominator = BigInt::from(replication_count) * BigInt::from(window_length);
    let mean_exposures: [BigRational; 4] = array::from_fn(|bin| {
        BigRational::new(
            BigInt::from(aggregate_exposures[bin].clone()),
            sample_denominator.clone(),
        )
    });
    let mean_selected: [BigRational; 4] = array::from_fn(|bin| {
        BigRational::new(
            BigInt::from(aggregate_selected[bin].clone()),
            sample_denominator.clone(),
        )
    });

    let mut fractional_bits = caps.initial_bits;
    let mut cumulative_series_terms = 0_u64;
    loop {
        let log =
            log_twelve_over_alpha(alpha, fractional_bits, &mut cumulative_series_terms, caps)?;
        let divisor = BigRational::from_integer(BigInt::from(replication_count) * 2);
        let radicand =
            RationalEnclosure::new(&log.bounds.lower / &divisor, &log.bounds.upper / &divisor);
        let epsilon = sqrt_enclosure(&radicand, fractional_bits)?;

        let mut pending = Vec::with_capacity(3);
        let mut directed = Vec::with_capacity(3);
        let mut all_decided = true;
        for bin in 1..=3 {
            match prepare_bin(bin, &mean_exposures[bin], &mean_selected[bin], &epsilon) {
                Some(candidate) => {
                    let exposure = common_directed_interval(
                        &candidate.exposure_lower_endpoint,
                        &candidate.exposure_upper_endpoint,
                    );
                    let selected = common_directed_interval(
                        &candidate.selected_lower_endpoint,
                        &candidate.selected_upper_endpoint,
                    );
                    let ratio = common_directed_interval(
                        &candidate.ratio_lower_endpoint,
                        &candidate.ratio_upper_endpoint,
                    );
                    if let (Some(exposure), Some(selected), Some(ratio)) =
                        (exposure, selected, ratio)
                    {
                        directed.push(DirectedBinEndpoints {
                            exposure,
                            selected,
                            ratio,
                        });
                    } else {
                        all_decided = false;
                    }
                    pending.push(candidate);
                }
                None => all_decided = false,
            }
        }

        if all_decided && pending.len() == 3 && directed.len() == 3 {
            let bins = array::from_fn(|index| {
                let candidate = pending[index].clone();
                BinSamplingInterval {
                    bin: candidate.bin,
                    mean_exposure: candidate.mean_exposure,
                    mean_selected: candidate.mean_selected,
                    exposure_lower_endpoint: candidate.exposure_lower_endpoint,
                    exposure_upper_endpoint: candidate.exposure_upper_endpoint,
                    selected_lower_endpoint: candidate.selected_lower_endpoint,
                    selected_upper_endpoint: candidate.selected_upper_endpoint,
                    ratio_lower_endpoint: candidate.ratio_lower_endpoint,
                    ratio_upper_endpoint: candidate.ratio_upper_endpoint,
                    directed_exposure_interval: directed[index].exposure,
                    directed_selected_interval: directed[index].selected,
                    directed_interval: directed[index].ratio,
                    status: candidate.status,
                    branch: candidate.branch,
                }
            });
            return Ok(ThreeBinSamplingIntervals {
                familywise_alpha: alpha.clone(),
                replication_count,
                window_length,
                aggregate_exposures,
                aggregate_selected,
                epsilon,
                bins,
                arithmetic: IntervalArithmeticEvidence {
                    fractional_bits,
                    final_round_ln_m_terms: log.ln_m_terms,
                    final_round_ln_two_terms: log.ln_two_terms,
                    cumulative_series_terms,
                },
            });
        }

        if fractional_bits >= caps.maximum_bits {
            return Err(IntervalError::EvidenceRoundingUnresolved {
                fractional_bits,
                series_terms: cumulative_series_terms,
            });
        }
        fractional_bits = fractional_bits
            .checked_mul(2)
            .map_or(caps.maximum_bits, |next| next.min(caps.maximum_bits));
    }
}

fn prepare_bin(
    bin: usize,
    mean_exposure: &BigRational,
    mean_selected: &BigRational,
    epsilon: &RationalEnclosure,
) -> Option<PendingBin> {
    let zero = BigRational::zero();
    let one = BigRational::one();

    let exposure_lower_endpoint = RationalEnclosure::new(
        nonnegative(mean_exposure - &epsilon.upper),
        nonnegative(mean_exposure - &epsilon.lower),
    );
    let exposure_upper_endpoint = RationalEnclosure::new(
        at_most_one(mean_exposure + &epsilon.lower),
        at_most_one(mean_exposure + &epsilon.upper),
    );
    let selected_lower_endpoint = RationalEnclosure::new(
        nonnegative(mean_selected - &epsilon.upper),
        nonnegative(mean_selected - &epsilon.lower),
    );
    let selected_upper_endpoint = RationalEnclosure::new(
        at_most_one(mean_selected + &epsilon.lower),
        at_most_one(mean_selected + &epsilon.upper),
    );

    let (ratio_lower_endpoint, ratio_upper_endpoint, status, branch) =
        if exposure_lower_endpoint.upper == zero {
            (
                RationalEnclosure::exact(zero),
                RationalEnclosure::exact(one),
                EmpiricalIntervalStatus::UnresolvedIntervalOnly,
                RatioIntervalBranch::UninformativeExposure,
            )
        } else if exposure_lower_endpoint.lower > zero {
            let ratio_lower = RationalEnclosure::new(
                &selected_lower_endpoint.lower / &exposure_upper_endpoint.upper,
                &selected_lower_endpoint.upper / &exposure_upper_endpoint.lower,
            );
            let ratio_upper = RationalEnclosure::new(
                at_most_one(&selected_upper_endpoint.lower / &exposure_lower_endpoint.upper),
                at_most_one(&selected_upper_endpoint.upper / &exposure_lower_endpoint.lower),
            );
            (
                ratio_lower,
                ratio_upper,
                EmpiricalIntervalStatus::PositiveWithConfidenceIntervalOnly,
                RatioIntervalBranch::PositiveExposure,
            )
        } else {
            return None;
        };

    Some(PendingBin {
        bin: u8::try_from(bin).ok()?,
        mean_exposure: mean_exposure.clone(),
        mean_selected: mean_selected.clone(),
        exposure_lower_endpoint,
        exposure_upper_endpoint,
        selected_lower_endpoint,
        selected_upper_endpoint,
        ratio_lower_endpoint,
        ratio_upper_endpoint,
        status,
        branch,
    })
}

fn nonnegative(value: BigRational) -> BigRational {
    value.max(BigRational::zero())
}

fn at_most_one(value: BigRational) -> BigRational {
    value.min(BigRational::one())
}

fn log_twelve_over_alpha(
    alpha: &BigRational,
    fractional_bits: u32,
    cumulative_terms: &mut u64,
    caps: ArithmeticCaps,
) -> Result<LogEnclosure, IntervalError> {
    let x = BigRational::new(alpha.denom().clone() * 12, alpha.numer().clone());
    let (numerator, denominator) = positive_parts(&x)?;
    let numerator_bits = numerator.bits();
    let denominator_bits = denominator.bits();
    let mut power = numerator_bits
        .checked_sub(denominator_bits)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    let shift = usize::try_from(power).map_err(|_| IntervalError::OperandUnrepresentable)?;
    if numerator < (&denominator << shift) {
        power = power
            .checked_sub(1)
            .ok_or(IntervalError::OperandUnrepresentable)?;
    }
    let shift = usize::try_from(power).map_err(|_| IntervalError::OperandUnrepresentable)?;
    let m = BigRational::new(BigInt::from(numerator), BigInt::from(denominator << shift));
    debug_assert!(m >= BigRational::one());
    debug_assert!(m < BigRational::from_integer(BigInt::from(2_u8)));

    let guard_bits = fractional_bits
        .checked_add(64)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    let tolerance = BigRational::new(
        BigInt::one(),
        BigInt::from(
            BigUint::one()
                << usize::try_from(guard_bits)
                    .map_err(|_| IntervalError::OperandUnrepresentable)?,
        ),
    );
    let power_plus_one = power
        .checked_add(1)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    let component_tolerance = &tolerance / BigRational::from_integer(BigInt::from(power_plus_one));

    let y_m = (&m - BigRational::one()) / (&m + BigRational::one());
    let before_m = *cumulative_terms;
    let ln_m = atanh_log_series(
        &y_m,
        &component_tolerance,
        cumulative_terms,
        caps.maximum_terms,
        fractional_bits,
    )?;
    let ln_m_terms = *cumulative_terms - before_m;

    let before_two = *cumulative_terms;
    let ln_two = atanh_log_series(
        &BigRational::new(BigInt::one(), BigInt::from(3_u8)),
        &component_tolerance,
        cumulative_terms,
        caps.maximum_terms,
        fractional_bits,
    )?;
    let ln_two_terms = *cumulative_terms - before_two;
    let multiplier = BigRational::from_integer(BigInt::from(power));
    let lower = &ln_m.lower + &multiplier * &ln_two.lower;
    let upper = &ln_m.upper + multiplier * &ln_two.upper;
    debug_assert!(&upper - &lower < tolerance);
    Ok(LogEnclosure {
        bounds: RationalEnclosure::new(lower, upper),
        ln_m_terms,
        ln_two_terms,
    })
}

fn atanh_log_series(
    y: &BigRational,
    tolerance: &BigRational,
    cumulative_terms: &mut u64,
    maximum_terms: u64,
    fractional_bits: u32,
) -> Result<RationalEnclosure, IntervalError> {
    debug_assert!(y >= &BigRational::zero());
    debug_assert!(y < &BigRational::one());
    if y.is_zero() {
        return Ok(RationalEnclosure::exact(BigRational::zero()));
    }
    let y_squared = y * y;
    let geometric_denominator = BigRational::one() - &y_squared;
    let mut power = y.clone();
    let mut partial = BigRational::zero();
    let mut index = 0_u64;
    loop {
        if *cumulative_terms >= maximum_terms {
            return Err(IntervalError::EvidenceRoundingUnresolved {
                fractional_bits,
                series_terms: *cumulative_terms,
            });
        }
        let odd = index
            .checked_mul(2)
            .and_then(|value| value.checked_add(1))
            .ok_or(IntervalError::OperandUnrepresentable)?;
        partial += (&power * BigInt::from(2_u8)) / BigRational::from_integer(BigInt::from(odd));
        *cumulative_terms += 1;

        let next_power = &power * &y_squared;
        let next_odd = odd
            .checked_add(2)
            .ok_or(IntervalError::OperandUnrepresentable)?;
        let remainder = (&next_power * BigInt::from(2_u8))
            / (BigRational::from_integer(BigInt::from(next_odd)) * &geometric_denominator);
        if remainder < *tolerance {
            return Ok(RationalEnclosure::new(partial.clone(), partial + remainder));
        }
        power = next_power;
        index = index
            .checked_add(1)
            .ok_or(IntervalError::OperandUnrepresentable)?;
    }
}

fn sqrt_enclosure(
    radicand: &RationalEnclosure,
    fractional_bits: u32,
) -> Result<RationalEnclosure, IntervalError> {
    let lower = sqrt_scaled(&radicand.lower, fractional_bits, false)?;
    let upper = sqrt_scaled(&radicand.upper, fractional_bits, true)?;
    Ok(RationalEnclosure::new(lower, upper))
}

fn sqrt_scaled(
    value: &BigRational,
    fractional_bits: u32,
    upward: bool,
) -> Result<BigRational, IntervalError> {
    let (numerator, denominator) = positive_parts(value)?;
    let shift = fractional_bits
        .checked_mul(2)
        .ok_or(IntervalError::OperandUnrepresentable)?;
    let scaled_numerator =
        numerator << usize::try_from(shift).map_err(|_| IntervalError::OperandUnrepresentable)?;
    let quotient = &scaled_numerator / &denominator;
    let floor_root = integer_sqrt_floor(&quotient);
    let exact = &floor_root * &floor_root * &denominator == scaled_numerator;
    let directed_root = if upward && !exact {
        floor_root + BigUint::one()
    } else {
        floor_root
    };
    Ok(BigRational::new(
        BigInt::from(directed_root),
        BigInt::from(
            BigUint::one()
                << usize::try_from(fractional_bits)
                    .map_err(|_| IntervalError::OperandUnrepresentable)?,
        ),
    ))
}

fn integer_sqrt_floor(value: &BigUint) -> BigUint {
    if value.is_zero() {
        return BigUint::zero();
    }
    let initial_shift = usize::try_from((value.bits() + 1) / 2).unwrap_or(usize::MAX);
    let mut estimate = BigUint::one() << initial_shift;
    loop {
        let next = (&estimate + value / &estimate) >> 1_usize;
        if next >= estimate {
            return estimate;
        }
        estimate = next;
    }
}

fn positive_parts(value: &BigRational) -> Result<(BigUint, BigUint), IntervalError> {
    if value < &BigRational::zero() || value.denom().sign() != Sign::Plus {
        return Err(IntervalError::OperandUnrepresentable);
    }
    Ok((
        value.numer().magnitude().clone(),
        value.denom().magnitude().clone(),
    ))
}

fn common_directed_bits(enclosure: &RationalEnclosure, upward: bool) -> Option<u64> {
    let lower = directed_binary64_bits(&enclosure.lower, upward)?;
    let upper = directed_binary64_bits(&enclosure.upper, upward)?;
    (lower == upper).then_some(lower)
}

fn common_directed_interval(
    lower_endpoint: &RationalEnclosure,
    upper_endpoint: &RationalEnclosure,
) -> Option<DirectedBinary64Interval> {
    Some(DirectedBinary64Interval {
        lower: DirectedBinary64 {
            bits: common_directed_bits(lower_endpoint, false)?,
        },
        upper: DirectedBinary64 {
            bits: common_directed_bits(upper_endpoint, true)?,
        },
    })
}

fn directed_binary64_bits(value: &BigRational, upward: bool) -> Option<u64> {
    if value < &BigRational::zero() || value > &BigRational::one() {
        return None;
    }
    let mut low = 0_u64;
    let mut high = BINARY64_ONE_BITS;
    while low < high {
        let midpoint = low + (high - low).div_ceil(2);
        if binary64_rational(midpoint) <= *value {
            low = midpoint;
        } else {
            high = midpoint - 1;
        }
    }
    if !upward || binary64_rational(low) == *value {
        Some(low)
    } else {
        low.checked_add(1)
    }
}

fn directed_nonnegative_binary64_bits(value: &BigRational, upward: bool) -> Option<u64> {
    if value < &BigRational::zero()
        || value > &binary64_nonnegative_rational(BINARY64_MAX_FINITE_BITS)
    {
        return None;
    }
    let mut low = 0_u64;
    let mut high = BINARY64_MAX_FINITE_BITS;
    while low < high {
        let midpoint = low + (high - low).div_ceil(2);
        if binary64_nonnegative_rational(midpoint) <= *value {
            low = midpoint;
        } else {
            high = midpoint - 1;
        }
    }
    if !upward || binary64_nonnegative_rational(low) == *value {
        Some(low)
    } else {
        low.checked_add(1)
    }
}

fn binary64_rational(bits: u64) -> BigRational {
    debug_assert!(bits <= BINARY64_ONE_BITS);
    if bits == 0 {
        return BigRational::zero();
    }
    let exponent = (bits >> 52) & 0x7ff;
    let fraction = bits & 0x000f_ffff_ffff_ffff;
    if exponent == 0 {
        BigRational::new(
            BigInt::from(fraction),
            BigInt::from(BigUint::one() << 1074_usize),
        )
    } else {
        let significand = (1_u64 << 52) | fraction;
        let denominator_shift = usize::try_from(1075_u64 - exponent).unwrap_or(usize::MAX);
        BigRational::new(
            BigInt::from(significand),
            BigInt::from(BigUint::one() << denominator_shift),
        )
    }
}

fn binary64_nonnegative_rational(bits: u64) -> BigRational {
    debug_assert!(bits <= BINARY64_MAX_FINITE_BITS);
    if bits <= BINARY64_ONE_BITS {
        return binary64_rational(bits);
    }
    let exponent = (bits >> 52) & 0x7ff;
    let fraction = bits & 0x000f_ffff_ffff_ffff;
    let significand = (1_u64 << 52) | fraction;
    if exponent >= 1075 {
        let numerator_shift = usize::try_from(exponent - 1075).unwrap_or(usize::MAX);
        BigRational::from_integer(BigInt::from(
            BigUint::from(significand) << numerator_shift,
        ))
    } else {
        let denominator_shift = usize::try_from(1075 - exponent).unwrap_or(usize::MAX);
        BigRational::new(
            BigInt::from(significand),
            BigInt::from(BigUint::one() << denominator_shift),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rational(numerator: u64, denominator: u64) -> BigRational {
        BigRational::new(BigInt::from(numerator), BigInt::from(denominator))
    }

    fn repeated_ledger(replications: usize, ledger: ReplicationLedger) -> Vec<ReplicationLedger> {
        vec![ledger; replications]
    }

    fn fixture_bigint(value: &serde_json::Value) -> BigInt {
        BigInt::parse_bytes(value.as_str().unwrap().as_bytes(), 10).unwrap()
    }

    fn fixture_counts(value: &serde_json::Value) -> [u64; 4] {
        let rows = value.as_array().unwrap();
        array::from_fn(|index| rows[index].as_u64().unwrap())
    }

    fn status_label(status: EmpiricalIntervalStatus) -> &'static str {
        match status {
            EmpiricalIntervalStatus::PositiveWithConfidenceIntervalOnly => {
                "positive_with_confidence/interval_only"
            }
            EmpiricalIntervalStatus::UnresolvedIntervalOnly => "unresolved/interval_only",
        }
    }

    fn branch_label(branch: RatioIntervalBranch) -> &'static str {
        match branch {
            RatioIntervalBranch::PositiveExposure => "positive_exposure",
            RatioIntervalBranch::UninformativeExposure => "uninformative_exposure",
        }
    }

    #[test]
    fn fofs_cp03_interval_rejects_invalid_population_inputs() {
        let valid = ReplicationLedger {
            exposures: [1, 1, 1, 1],
            selected: [0, 0, 1, 1],
        };
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &BigRational::zero(),
                std::slice::from_ref(&valid),
                4,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::InvalidFamilywiseAlpha)
        );
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &rational(1, 20),
                &[],
                4,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::EmptyReplicationBank)
        );
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &rational(1, 20),
                std::slice::from_ref(&valid),
                0,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::ZeroWindowLength)
        );
        let bad_coverage = ReplicationLedger {
            exposures: [1, 1, 1, 0],
            selected: [0, 0, 0, 0],
        };
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &rational(1, 20),
                &[bad_coverage],
                4,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::ExposureCoverageMismatch { replication: 0 })
        );
    }

    #[test]
    fn fofs_cp03_interval_rejects_impossible_selected_ledgers() {
        let selected_zero = ReplicationLedger {
            exposures: [1, 1, 1, 1],
            selected: [1, 0, 0, 0],
        };
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &rational(1, 20),
                &[selected_zero],
                4,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::SelectedInZeroBin { replication: 0 })
        );
        let selected_too_large = ReplicationLedger {
            exposures: [1, 1, 1, 1],
            selected: [0, 2, 0, 0],
        };
        assert_eq!(
            compute_three_bin_sampling_intervals(
                &rational(1, 20),
                &[selected_too_large],
                4,
                IntervalComputationLimits::V1,
            ),
            Err(IntervalError::SelectedAboveExposure {
                replication: 0,
                bin: 1,
            })
        );
    }

    #[test]
    fn fofs_cp03_interval_uses_whole_replication_aggregate_means() {
        let ledgers = [
            ReplicationLedger {
                exposures: [0, 1, 2, 1],
                selected: [0, 1, 1, 0],
            },
            ReplicationLedger {
                exposures: [2, 2, 0, 0],
                selected: [0, 0, 0, 0],
            },
        ];
        let result = compute_three_bin_sampling_intervals(
            &rational(1, 20),
            &ledgers,
            4,
            IntervalComputationLimits::V1,
        )
        .unwrap();
        assert_eq!(result.replication_count, 2);
        assert_eq!(
            result.aggregate_exposures,
            [2_u8.into(), 3_u8.into(), 2_u8.into(), 1_u8.into()]
        );
        assert_eq!(result.bins[0].mean_exposure, rational(3, 8));
        assert_eq!(result.bins[0].mean_selected, rational(1, 8));
        assert_eq!(result.bins[1].mean_exposure, rational(1, 4));
        assert_eq!(result.bins[1].mean_selected, rational(1, 8));
    }

    #[test]
    fn fofs_cp03_interval_r_one_is_uninformative_without_slot_iid_claim() {
        let result = compute_three_bin_sampling_intervals(
            &rational(1, 20),
            &[ReplicationLedger {
                exposures: [0, 1, 1, 1],
                selected: [0, 1, 1, 1],
            }],
            3,
            IntervalComputationLimits::V1,
        )
        .unwrap();
        for bin in &result.bins {
            assert_eq!(bin.branch, RatioIntervalBranch::UninformativeExposure);
            assert_eq!(bin.status, EmpiricalIntervalStatus::UnresolvedIntervalOnly);
            assert_eq!(bin.directed_interval.lower.bits, 0);
            assert_eq!(bin.directed_interval.upper.bits, BINARY64_ONE_BITS);
        }
    }

    #[test]
    fn fofs_cp03_interval_frozen_independent_oracle_panel() {
        let fixture: serde_json::Value = serde_json::from_str(include_str!(
            "../../../references/FOFS_CP03_INTERVAL_KNOWN_ANSWERS_V1.json"
        ))
        .unwrap();
        assert_eq!(fixture["fixture_version"], 1);
        assert_eq!(
            fixture["sampling_unit"],
            "independent_whole_physical_replication"
        );
        assert_eq!(
            fixture["oracle_provenance"]["implementation"],
            "Python_decimal_ln_sqrt_v1"
        );

        for case in fixture["cases"].as_array().unwrap() {
            let alpha = BigRational::new(
                fixture_bigint(&case["alpha"]["numerator"]),
                fixture_bigint(&case["alpha"]["denominator"]),
            );
            let replication_count =
                usize::try_from(case["replications"].as_u64().unwrap()).unwrap();
            let ledger = ReplicationLedger {
                exposures: fixture_counts(&case["repeated_ledger"]["exposures"]),
                selected: fixture_counts(&case["repeated_ledger"]["selected"]),
            };
            let result = compute_three_bin_sampling_intervals(
                &alpha,
                &repeated_ledger(replication_count, ledger),
                case["window_length"].as_u64().unwrap(),
                IntervalComputationLimits::V1,
            )
            .unwrap();
            assert_eq!(result.arithmetic.fractional_bits, 256, "{}", case["id"]);
            for (actual, expected) in result.bins.iter().zip(case["expected"].as_array().unwrap()) {
                assert_eq!(u64::from(actual.bin), expected["bin"].as_u64().unwrap());
                assert_eq!(
                    format!("{:016x}", actual.directed_exposure_interval.lower.bits),
                    expected["exposure_lower_bits"].as_str().unwrap(),
                    "{} bin {} exposure lower",
                    case["id"],
                    actual.bin
                );
                assert_eq!(
                    format!("{:016x}", actual.directed_exposure_interval.upper.bits),
                    expected["exposure_upper_bits"].as_str().unwrap(),
                    "{} bin {} exposure upper",
                    case["id"],
                    actual.bin
                );
                assert_eq!(
                    format!("{:016x}", actual.directed_selected_interval.lower.bits),
                    expected["selected_lower_bits"].as_str().unwrap(),
                    "{} bin {} selected lower",
                    case["id"],
                    actual.bin
                );
                assert_eq!(
                    format!("{:016x}", actual.directed_selected_interval.upper.bits),
                    expected["selected_upper_bits"].as_str().unwrap(),
                    "{} bin {} selected upper",
                    case["id"],
                    actual.bin
                );
                assert_eq!(
                    format!("{:016x}", actual.directed_interval.lower.bits),
                    expected["ratio_lower_bits"].as_str().unwrap(),
                    "{} bin {} ratio lower",
                    case["id"],
                    actual.bin
                );
                assert_eq!(
                    format!("{:016x}", actual.directed_interval.upper.bits),
                    expected["ratio_upper_bits"].as_str().unwrap(),
                    "{} bin {} ratio upper",
                    case["id"],
                    actual.bin
                );
                assert_eq!(status_label(actual.status), expected["status"]);
                assert_eq!(branch_label(actual.branch), expected["branch"]);
            }
        }

        for case in fixture["directed_rounding_cases"].as_array().unwrap() {
            let shift =
                usize::try_from(case["denominator_power_of_two"].as_u64().unwrap()).unwrap();
            let value = BigRational::new(
                fixture_bigint(&case["numerator"]),
                BigInt::from(BigUint::one() << shift),
            );
            assert_eq!(
                format!("{:016x}", directed_binary64_bits(&value, false).unwrap()),
                case["down_bits"].as_str().unwrap(),
                "{} down",
                case["id"]
            );
            assert_eq!(
                format!("{:016x}", directed_binary64_bits(&value, true).unwrap()),
                case["up_bits"].as_str().unwrap(),
                "{} up",
                case["id"]
            );
        }
    }

    #[test]
    fn fofs_cp03_interval_xl_zero_and_immediately_positive_choose_legal_statuses() {
        let zero = compute_three_bin_sampling_intervals(
            &rational(1, 20),
            &repeated_ledger(
                10_000,
                ReplicationLedger {
                    exposures: [98, 1, 1, 0],
                    selected: [0, 1, 0, 0],
                },
            ),
            100,
            IntervalComputationLimits::V1,
        )
        .unwrap();
        assert_eq!(
            zero.bins[0].branch,
            RatioIntervalBranch::UninformativeExposure
        );

        let positive = compute_three_bin_sampling_intervals(
            &rational(1, 20),
            &repeated_ledger(
                10_000,
                ReplicationLedger {
                    exposures: [96, 2, 1, 1],
                    selected: [0, 1, 0, 0],
                },
            ),
            100,
            IntervalComputationLimits::V1,
        )
        .unwrap();
        assert_eq!(
            positive.bins[0].branch,
            RatioIntervalBranch::PositiveExposure
        );
        assert_eq!(
            positive.bins[0].status,
            EmpiricalIntervalStatus::PositiveWithConfidenceIntervalOnly
        );
    }

    #[test]
    fn fofs_cp03_interval_directed_binary64_handles_exact_and_adjacent_boundaries() {
        let half = rational(1, 2);
        assert_eq!(
            directed_binary64_bits(&half, false),
            Some(0x3fe0_0000_0000_0000)
        );
        assert_eq!(
            directed_binary64_bits(&half, true),
            Some(0x3fe0_0000_0000_0000)
        );

        let exact = binary64_rational(0x3fe0_0000_0000_0000);
        let successor = binary64_rational(0x3fe0_0000_0000_0001);
        let between = (&exact + &successor) / BigInt::from(2_u8);
        assert_eq!(
            directed_binary64_bits(&between, false),
            Some(0x3fe0_0000_0000_0000)
        );
        assert_eq!(
            directed_binary64_bits(&between, true),
            Some(0x3fe0_0000_0000_0001)
        );

        let smallest = binary64_rational(1);
        assert_eq!(directed_binary64_bits(&smallest, false), Some(1));
        assert_eq!(directed_binary64_bits(&smallest, true), Some(1));
        let below_smallest = &smallest / BigInt::from(2_u8);
        assert_eq!(directed_binary64_bits(&below_smallest, false), Some(0));
        assert_eq!(directed_binary64_bits(&below_smallest, true), Some(1));
    }

    #[test]
    fn fofs_cp03_interval_integer_square_root_encloses_exactly() {
        assert_eq!(
            integer_sqrt_floor(&BigUint::from(0_u8)),
            BigUint::from(0_u8)
        );
        assert_eq!(
            integer_sqrt_floor(&BigUint::from(1_u8)),
            BigUint::from(1_u8)
        );
        assert_eq!(
            integer_sqrt_floor(&BigUint::from(15_u8)),
            BigUint::from(3_u8)
        );
        assert_eq!(
            integer_sqrt_floor(&BigUint::from(16_u8)),
            BigUint::from(4_u8)
        );
        assert_eq!(
            integer_sqrt_floor(&BigUint::from(17_u8)),
            BigUint::from(4_u8)
        );
        let value = (BigUint::one() << 4096_usize) - BigUint::one();
        let root = integer_sqrt_floor(&value);
        assert!(&root * &root <= value);
        assert!((&root + BigUint::one()).pow(2) > value);
    }

    #[test]
    fn fofs_cp03_interval_reports_rounding_cap_without_guessing() {
        let error = compute_with_caps(
            &rational(1, 20),
            &repeated_ledger(
                100,
                ReplicationLedger {
                    exposures: [1, 3, 3, 3],
                    selected: [0, 1, 2, 3],
                },
            ),
            10,
            ArithmeticCaps {
                initial_bits: 1,
                maximum_bits: 1,
                maximum_terms: 1,
            },
        )
        .unwrap_err();
        assert_eq!(error.code(), "evidence_rounding_unresolved");
        assert!(matches!(
            error,
            IntervalError::EvidenceRoundingUnresolved {
                fractional_bits: 1,
                series_terms: 1
            }
        ));
    }

    #[test]
    fn fofs_cp03_interval_requires_all_six_endpoint_directions() {
        // Every ratio is algebraically the uninformative [0,1], but XU and ZU
        // still depend on epsilon. A coarse one-round cap must therefore fail
        // instead of publishing those mean endpoints from just one side of
        // their rational enclosure.
        let error = compute_with_caps(
            &rational(1, 20),
            &repeated_ledger(
                100,
                ReplicationLedger {
                    exposures: [10, 0, 0, 0],
                    selected: [0, 0, 0, 0],
                },
            ),
            10,
            ArithmeticCaps {
                initial_bits: 8,
                maximum_bits: 8,
                maximum_terms: 10_000,
            },
        )
        .unwrap_err();
        assert!(matches!(
            error,
            IntervalError::EvidenceRoundingUnresolved {
                fractional_bits: 8,
                ..
            }
        ));
    }

    #[test]
    fn fofs_cp03_interval_source_has_no_host_transcendental_call() {
        let source = include_str!("finite_window_interval.rs");
        let forbidden = [
            ["f64", "::ln"].concat(),
            ["f64", "::sqrt"].concat(),
            [".ln", "()"].concat(),
            [".sqrt", "()"].concat(),
        ];
        for forbidden in forbidden {
            assert!(
                !source.contains(&forbidden),
                "forbidden host operation: {forbidden}"
            );
        }
        assert!(source.contains("atanh_log_series"));
        assert!(source.contains("integer_sqrt_floor"));
    }
}
