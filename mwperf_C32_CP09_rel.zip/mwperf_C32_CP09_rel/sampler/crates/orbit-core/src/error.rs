use std::fmt;

use thiserror::Error;

/// Ordered runtime stages cover one exact scheduling decision, one atomic
/// count transition, and horizon finalization.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeStage {
    EmptyInitialization,
    ColdMaxWeightSolve,
    ActionValidation,
    SlotSnapshot,
    SlotServicePreparation,
    SlotProviderAdvance,
    SlotTransitionPreparation,
    SlotObserverPreflight,
    SlotCommitPreparation,
    HorizonFinalization,
}

impl RuntimeStage {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::EmptyInitialization => "empty_initialization",
            Self::ColdMaxWeightSolve => "cold_maxweight_solve",
            Self::ActionValidation => "action_validation",
            Self::SlotSnapshot => "slot_snapshot",
            Self::SlotServicePreparation => "slot_service_preparation",
            Self::SlotProviderAdvance => "slot_provider_advance",
            Self::SlotTransitionPreparation => "slot_transition_preparation",
            Self::SlotObserverPreflight => "slot_observer_preflight",
            Self::SlotCommitPreparation => "slot_commit_preparation",
            Self::HorizonFinalization => "horizon_finalization",
        }
    }
}

impl fmt::Display for RuntimeStage {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum ArithmeticError {
    #[error("checked arithmetic overflow while computing {operation}")]
    Overflow { operation: &'static str },
    #[error("a denominator was zero while computing {quantity}")]
    ZeroDenominator { quantity: &'static str },
    #[error("an exact quantity was outside its prepared runtime representation: {quantity}")]
    RepresentationBound { quantity: &'static str },
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum PrepareError {
    #[error("invalid numeric specification at {path}: {detail}")]
    InvalidNumericSpec { path: String, detail: String },
    #[error("invalid carrier specification at {path}: {detail}")]
    InvalidCarrierSpec { path: String, detail: String },
    #[error("invalid arrival specification at {path}: {detail}")]
    InvalidArrivalSpec { path: String, detail: String },
    #[error("invalid constraint instance at {path}: {detail}")]
    InvalidConstraintInstance { path: String, detail: String },
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum RunError {
    #[error("arithmetic overflow during {stage:?}: {detail}")]
    ArithmeticOverflow { stage: RuntimeStage, detail: String },
    #[error("arrival contract violation during {stage:?}: {detail}")]
    ArrivalContractViolation { stage: RuntimeStage, detail: String },
    #[error("optimizer contract violation during {stage:?}: {detail}")]
    OptimizerContractViolation { stage: RuntimeStage, detail: String },
    #[error("carrier invariant violation during {stage:?}: {detail}")]
    CarrierInvariantViolation { stage: RuntimeStage, detail: String },
    #[error("result invariant violation during {stage:?}: {detail}")]
    ResultInvariantViolation { stage: RuntimeStage, detail: String },
    #[error("exact optimizer failure during {stage:?}: {detail}")]
    ExactOptimizerFailure { stage: RuntimeStage, detail: String },
    #[error("exact optimizer returned no incumbent during {stage:?}: {detail}")]
    ExactOptimizerNoIncumbent { stage: RuntimeStage, detail: String },
    #[error("scientific grant exhausted during {stage:?}: {detail}")]
    ScientificGrantExhausted { stage: RuntimeStage, detail: String },
    #[error("resource exhausted during {stage:?}: {detail}")]
    ResourceExhausted { stage: RuntimeStage, detail: String },
}

impl RunError {
    pub(crate) fn arithmetic(stage: RuntimeStage, source: ArithmeticError) -> Self {
        let detail = source.to_string();
        match source {
            ArithmeticError::Overflow { .. } => Self::ArithmeticOverflow { stage, detail },
            ArithmeticError::ZeroDenominator { .. }
            | ArithmeticError::RepresentationBound { .. } => Self::CarrierInvariantViolation {
                stage,
                detail: format!(
                    "a preparation-time numeric proof was violated at runtime: {detail}"
                ),
            },
        }
    }
}
