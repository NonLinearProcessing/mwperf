//! Six exact, exogenous direct-count arrival providers.
//!
//! This is the sole public arrival-provider carrier for schema 3. Compilation
//! closes a [`ResolvedArrival`] into immutable tables shared by replications.
//! Each replication owns its replay-bound state and reusable sparse workspace;
//! a prepared slot is committed with the queue transition or discarded.

use std::collections::VecDeque;
use std::hash::{Hash, Hasher};

use num_traits::ToPrimitive;
use thiserror::Error;

use crate::exact::{ExactRational, ExactUnsigned, RuntimeCount};
use crate::resolved::{
    ArrivalFamily, DelayedPeriodicSource, GapLaw, InitialStateLaw, JointRoundOutcome,
    MarkedRenewalLaw, MarkovTransition, PeriodicEntry, PrivateMarkovSource, QueueProbability,
    ResolvedArrival, SharedJointRoundMarkovRenewal, SourceId, StateId, TypedId,
};
use crate::rng::{
    sample_bernoulli_counted, sample_categorical_counted, CountedRandomError,
    DirectArrivalDrawCoordinate, DirectArrivalDrawRole, DirectArrivalRngProvider,
    PreparedCategorical, RngSeed, RngWordGrantExceeded, RngWordMeter,
};
#[cfg(any(test, feature = "qualification-test-support"))]
use crate::unit_count::ArrivalBatch;
use crate::unit_count::{Arrival, QueueCatalog, QueueIndex};

/// A deterministic replay identity for one prepared provider.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct ArrivalReplay {
    seed: RngSeed,
    replication_index: u64,
}

impl ArrivalReplay {
    const fn new(seed: RngSeed, replication_index: u64) -> Self {
        Self {
            seed,
            replication_index,
        }
    }

    /// Bind the complete C02 final-stage seed block and its physical
    /// replication coordinate without an additional derivation.
    pub const fn from_seed_material(seed_material: [u8; 32], replication_index: u64) -> Self {
        Self::new(RngSeed::from_bytes(seed_material), replication_index)
    }

    /// The complete retained C02 final-stage seed material. This is evidence
    /// provenance, not a request for the provider to derive another seed.
    pub const fn seed_material(self) -> [u8; 32] {
        *self.seed.as_bytes()
    }

    /// The addressed whole-path replication coordinate.
    pub const fn replication_index(self) -> u64 {
        self.replication_index
    }

    const fn address(
        self,
        provider: DirectArrivalRngProvider,
        source_index: u32,
        event_or_round_index: u64,
        state_or_row_index: u32,
        role: DirectArrivalDrawRole,
        draw_subindex: u64,
    ) -> crate::rng::RngAddress {
        DirectArrivalDrawCoordinate::new(
            provider,
            source_index,
            event_or_round_index,
            state_or_row_index,
            role,
            draw_subindex,
        )
        .address(self.replication_index)
    }
}

/// Immutable view of the finite configured-generator word grant at one
/// prospective provider boundary.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct ArrivalDrawBudget {
    maximum_words: u64,
    already_consumed_words: u64,
}

impl ArrivalDrawBudget {
    pub(crate) fn try_new(
        maximum_words: u64,
        already_consumed_words: u64,
    ) -> Result<Self, ArrivalError> {
        if already_consumed_words > maximum_words {
            return Err(ArrivalError::ConfiguredGeneratorDrawGrantExceeded {
                maximum: maximum_words,
                consumed: already_consumed_words,
                requested: 0,
            });
        }
        Ok(Self {
            maximum_words,
            already_consumed_words,
        })
    }

    fn meter(self) -> Result<RngWordMeter, ArrivalError> {
        RngWordMeter::try_new(self.maximum_words, self.already_consumed_words)
            .map_err(map_word_grant)
    }
}

/// Work actually performed by one successfully prepared provider transition.
/// A slot delta is published only by `commit_step_counted`.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(crate) struct ArrivalWorkCounters {
    pub(crate) configured_generator_draws: u64,
    pub(crate) touched_queue_updates: u64,
    pub(crate) touched_clears: u64,
    pub(crate) full_dense_clears: u64,
    pub(crate) heap_node_visits: u64,
    pub(crate) successor_events: u64,
    pub(crate) shared_pending_expansions: u64,
    pub(crate) shared_pending_reserved_bytes: u64,
    pub(crate) batch_allocations: u64,
    pub(crate) state_clones: u64,
}

impl ArrivalWorkCounters {
    pub(crate) const fn configured_generator_draws(self) -> u64 {
        self.configured_generator_draws
    }

    #[cfg(test)]
    fn saturating_add(self, other: Self) -> Self {
        Self {
            configured_generator_draws: self
                .configured_generator_draws
                .saturating_add(other.configured_generator_draws),
            touched_queue_updates: self
                .touched_queue_updates
                .saturating_add(other.touched_queue_updates),
            touched_clears: self.touched_clears.saturating_add(other.touched_clears),
            full_dense_clears: self
                .full_dense_clears
                .saturating_add(other.full_dense_clears),
            heap_node_visits: self.heap_node_visits.saturating_add(other.heap_node_visits),
            successor_events: self.successor_events.saturating_add(other.successor_events),
            shared_pending_expansions: self
                .shared_pending_expansions
                .saturating_add(other.shared_pending_expansions),
            shared_pending_reserved_bytes: self
                .shared_pending_reserved_bytes
                .saturating_add(other.shared_pending_reserved_bytes),
            batch_allocations: self
                .batch_allocations
                .saturating_add(other.batch_allocations),
            state_clones: self.state_clones.saturating_add(other.state_clones),
        }
    }
}

/// Heap-owned provider endpoint memory, separating topology-bounded cursor
/// storage from law-intrinsic shared-round pending events.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(crate) struct ArrivalStateMemory {
    pub(crate) fixed_cursor_bytes: usize,
    pub(crate) shared_pending_bytes: usize,
    pub(crate) shared_pending_entries: usize,
}

/// Replication-local provider scratch, with transient shared-pending
/// replacement buffers separated from topology-bounded reusable storage.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(crate) struct ArrivalWorkspaceMemory {
    pub(crate) fixed_scratch_bytes: usize,
    pub(crate) staged_pending_bytes: usize,
    pub(crate) staged_pending_entries: usize,
}

impl ArrivalWorkspaceMemory {
    #[cfg(test)]
    pub(crate) const fn total_bytes(self) -> usize {
        self.fixed_scratch_bytes
            .saturating_add(self.staged_pending_bytes)
    }
}

/// The one compiled production provider carrier handed to the engine.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PreparedArrival {
    DeterministicTrace(PreparedDeterministic),
    PeriodicGlobalPhase(PreparedGlobalPeriodic),
    PeriodicSourceDelays(PreparedDelayedPeriodic),
    IndependentMarkedRenewal(PreparedMarkedRenewal),
    IndependentPrivateMarkovRenewal(PreparedPrivateMarkov),
    SharedJointRoundMarkovRenewal(PreparedSharedRounds),
}

/// Sufficient state for the matching closed provider variant.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ArrivalState {
    DeterministicTrace(DeterministicState),
    PeriodicGlobalPhase(PeriodicState),
    PeriodicSourceDelays(DelayedPeriodicState),
    IndependentMarkedRenewal(MarkedState),
    IndependentPrivateMarkovRenewal(PrivateState),
    SharedJointRoundMarkovRenewal(SharedState),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedDeterministic {
    binding: PreparationBinding,
    queue_count: usize,
    buckets: Vec<PreparedBucket>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedGlobalPeriodic {
    binding: PreparationBinding,
    queue_count: usize,
    period: u64,
    buckets: Vec<PreparedBucket>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedDelayedPeriodic {
    binding: PreparationBinding,
    queue_count: usize,
    period: u64,
    coordinates: Vec<PreparedDelayedCoordinate>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedMarkedRenewal {
    binding: PreparationBinding,
    queue_count: usize,
    sources: Vec<PreparedMarkedSource>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedPrivateMarkov {
    binding: PreparationBinding,
    queue_count: usize,
    sources: Vec<PreparedPrivateSource>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedSharedRounds {
    binding: PreparationBinding,
    queue_count: usize,
    source_count: usize,
    initial: PreparedInitial,
    rows: Vec<PreparedSharedRow>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeterministicState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
    bucket_cursor: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PeriodicState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MarkedState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
    cursors: Vec<RenewalCursor>,
    heap: EventHeap,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PrivateState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
    cursors: Vec<PrivateCursor>,
    heap: EventHeap,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SharedState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
    next_round: u64,
    next_round_state: u32,
    clocks: Vec<RuntimeCount>,
    pending_by_source: Vec<VecDeque<PendingEmission>>,
    heap: EventHeap,
}

impl ArrivalState {
    pub const fn family(&self) -> ArrivalFamily {
        match self {
            Self::DeterministicTrace(_) => ArrivalFamily::DeterministicTrace,
            Self::PeriodicGlobalPhase(_) => ArrivalFamily::PeriodicGlobalPhase,
            Self::PeriodicSourceDelays(_) => ArrivalFamily::PeriodicSourceDelays,
            Self::IndependentMarkedRenewal(_) => ArrivalFamily::IndependentMarkedRenewal,
            Self::IndependentPrivateMarkovRenewal(_) => {
                ArrivalFamily::IndependentPrivateMarkovRenewal
            }
            Self::SharedJointRoundMarkovRenewal(_) => ArrivalFamily::SharedJointRoundMarkovRenewal,
        }
    }

    pub const fn expected_slot(&self) -> RuntimeCount {
        match self {
            Self::DeterministicTrace(state) => state.expected_slot,
            Self::PeriodicGlobalPhase(state) => state.expected_slot,
            Self::PeriodicSourceDelays(state) => state.expected_slot,
            Self::IndependentMarkedRenewal(state) => state.expected_slot,
            Self::IndependentPrivateMarkovRenewal(state) => state.expected_slot,
            Self::SharedJointRoundMarkovRenewal(state) => state.expected_slot,
        }
    }

    /// Stable semantic digest of the complete addressed arrival cursor.
    ///
    /// The encoding deliberately omits redundant heap layout and allocation
    /// capacity. It includes every cursor, pending event, binding, replay, and
    /// expected origin needed to distinguish provider-authored endpoint state.
    pub fn endpoint_identity_v1(&self) -> [u8; 32] {
        let mut encoder = EndpointIdentityEncoder::new();
        match self {
            Self::DeterministicTrace(state) => {
                encoder.u8(0);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
                encoder.u64(state.bucket_cursor as u64);
            }
            Self::PeriodicGlobalPhase(state) => {
                encoder.u8(1);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
            }
            Self::PeriodicSourceDelays(state) => {
                encoder.u8(2);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
                encoder.len(state.next_slots.len());
                for next in &state.next_slots {
                    encoder.optional_count(*next);
                }
            }
            Self::IndependentMarkedRenewal(state) => {
                encoder.u8(3);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
                encoder.len(state.cursors.len());
                for cursor in &state.cursors {
                    encoder.u64(cursor.event_index);
                    encoder.count(cursor.next_slot);
                    encoder.u32(cursor.next_queue.0);
                }
            }
            Self::IndependentPrivateMarkovRenewal(state) => {
                encoder.u8(4);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
                encoder.len(state.cursors.len());
                for cursor in &state.cursors {
                    encoder.u64(cursor.event_index);
                    encoder.u32(cursor.state_index);
                    encoder.count(cursor.next_slot);
                    encoder.u32(cursor.next_queue.0);
                }
            }
            Self::SharedJointRoundMarkovRenewal(state) => {
                encoder.u8(5);
                encoder.common(
                    state.binding,
                    state.compiled_binding,
                    state.replay,
                    state.expected_slot,
                );
                encoder.u64(state.next_round);
                encoder.u32(state.next_round_state);
                encoder.len(state.clocks.len());
                for clock in &state.clocks {
                    encoder.count(*clock);
                }
                encoder.len(state.pending_by_source.len());
                for pending in &state.pending_by_source {
                    encoder.len(pending.len());
                    for event in pending {
                        encoder.u64(event.round_index);
                        encoder.count(event.slot);
                        encoder.u32(event.queue.0);
                    }
                }
            }
        }
        encoder.finish()
    }

    const fn session_identity(&self) -> (PreparationBinding, PreparationBinding, ArrivalReplay) {
        match self {
            Self::DeterministicTrace(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
            Self::PeriodicGlobalPhase(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
            Self::PeriodicSourceDelays(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
            Self::IndependentMarkedRenewal(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
            Self::IndependentPrivateMarkovRenewal(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
            Self::SharedJointRoundMarkovRenewal(state) => {
                (state.compiled_binding, state.binding, state.replay)
            }
        }
    }

    /// Heap-owned mutable provider endpoint memory. Shared-round pending
    /// element buffers are law-intrinsic and deliberately reported apart from
    /// the topology-bounded cursor structures.
    pub(crate) fn memory_accounting(&self) -> ArrivalStateMemory {
        match self {
            Self::DeterministicTrace(_) | Self::PeriodicGlobalPhase(_) => {
                ArrivalStateMemory::default()
            }
            Self::PeriodicSourceDelays(state) => ArrivalStateMemory {
                fixed_cursor_bytes: state
                    .next_slots
                    .capacity()
                    .saturating_mul(std::mem::size_of::<Option<RuntimeCount>>())
                    .saturating_add(state.heap.mutable_bytes()),
                ..ArrivalStateMemory::default()
            },
            Self::IndependentMarkedRenewal(state) => ArrivalStateMemory {
                fixed_cursor_bytes: state
                    .cursors
                    .capacity()
                    .saturating_mul(std::mem::size_of::<RenewalCursor>())
                    .saturating_add(state.heap.mutable_bytes()),
                ..ArrivalStateMemory::default()
            },
            Self::IndependentPrivateMarkovRenewal(state) => ArrivalStateMemory {
                fixed_cursor_bytes: state
                    .cursors
                    .capacity()
                    .saturating_mul(std::mem::size_of::<PrivateCursor>())
                    .saturating_add(state.heap.mutable_bytes()),
                ..ArrivalStateMemory::default()
            },
            Self::SharedJointRoundMarkovRenewal(state) => {
                let shared_pending_bytes =
                    state
                        .pending_by_source
                        .iter()
                        .fold(0_usize, |sum, pending| {
                            sum.saturating_add(
                                pending
                                    .capacity()
                                    .saturating_mul(std::mem::size_of::<PendingEmission>()),
                            )
                        });
                let shared_pending_entries = state
                    .pending_by_source
                    .iter()
                    .fold(0_usize, |sum, pending| sum.saturating_add(pending.len()));
                ArrivalStateMemory {
                    fixed_cursor_bytes: state
                        .clocks
                        .capacity()
                        .saturating_mul(std::mem::size_of::<RuntimeCount>())
                        .saturating_add(
                            state
                                .pending_by_source
                                .capacity()
                                .saturating_mul(std::mem::size_of::<VecDeque<PendingEmission>>()),
                        )
                        .saturating_add(state.heap.mutable_bytes()),
                    shared_pending_bytes,
                    shared_pending_entries,
                }
            }
        }
    }
}

struct EndpointIdentityEncoder {
    hasher: blake3::Hasher,
}

impl EndpointIdentityEncoder {
    fn new() -> Self {
        let mut hasher = blake3::Hasher::new();
        hasher.update(b"FOFS-ARRIVAL-ENDPOINT-V1\0");
        Self { hasher }
    }

    fn common(
        &mut self,
        binding: PreparationBinding,
        compiled_binding: PreparationBinding,
        replay: ArrivalReplay,
        expected_slot: RuntimeCount,
    ) {
        self.hasher.update(&binding);
        self.hasher.update(&compiled_binding);
        self.hasher.update(&replay.seed_material());
        self.u64(replay.replication_index());
        self.count(expected_slot);
    }

    fn optional_count(&mut self, value: Option<RuntimeCount>) {
        match value {
            Some(value) => {
                self.u8(1);
                self.count(value);
            }
            None => self.u8(0),
        }
    }

    fn len(&mut self, value: usize) {
        self.u64(u64::try_from(value).unwrap_or(u64::MAX));
    }

    fn count(&mut self, value: RuntimeCount) {
        self.u64(value.get());
    }

    fn u8(&mut self, value: u8) {
        self.hasher.update(&[value]);
    }

    fn u32(&mut self, value: u32) {
        self.hasher.update(&value.to_be_bytes());
    }

    fn u64(&mut self, value: u64) {
        self.hasher.update(&value.to_be_bytes());
    }

    fn finish(self) -> [u8; 32] {
        *self.hasher.finalize().as_bytes()
    }
}

/// Bounded refusal classes for direct-count provider work.
#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum ArrivalError {
    #[error("invalid direct-arrival definition: {field}")]
    InvalidDefinition { field: &'static str },
    #[error("duplicate direct-arrival coordinate: {field}")]
    DuplicateCoordinate { field: &'static str },
    #[error("unknown queue reference")]
    UnknownQueue,
    #[error("unknown state or source reference: {field}")]
    UnknownReference { field: &'static str },
    #[error("direct-arrival value exceeds the runtime representation: {field}")]
    RepresentationBound { field: &'static str },
    #[error("checked direct-arrival arithmetic overflow: {operation}")]
    ArithmeticOverflow { operation: &'static str },
    #[error("resource exhaustion while preparing {operation}")]
    ResourceExhausted { operation: &'static str },
    #[error("prepared provider and arrival state families differ")]
    StateFamilyMismatch,
    #[error("provider expected slot {expected:?}, received {actual:?}")]
    SlotMismatch {
        expected: RuntimeCount,
        actual: RuntimeCount,
    },
    #[error("direct-arrival state invariant failed: {invariant}")]
    CorruptState { invariant: &'static str },
    #[error("exact addressed random draw refused")]
    RandomDrawRefused,
    #[error(
        "configured-generator draw grant exhausted: maximum {maximum}, consumed {consumed}, requested {requested}"
    )]
    ConfiguredGeneratorDrawGrantExceeded {
        maximum: u64,
        consumed: u64,
        requested: u64,
    },
    #[error("same-slot arrival aggregation overflowed at queue {queue:?}")]
    ArrivalAggregateOverflow { queue: QueueIndex },
    #[error("geometric-grid sampling exceeded its checked draw bound")]
    GeometricBoundRefused,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedBucket {
    key: RuntimeCount,
    arrivals: Vec<Arrival>,
}

type PreparationBinding = [u8; 32];
const MAX_ARRIVAL_COUNT: u64 = i64::MAX as u64;

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedDelayedSource {
    delay: u64,
    buckets: Vec<PreparedBucket>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PreparedDelayedCoordinate {
    queue: QueueIndex,
    count: RuntimeCount,
    first_slot: RuntimeCount,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DelayedPeriodicState {
    binding: PreparationBinding,
    compiled_binding: PreparationBinding,
    replay: ArrivalReplay,
    expected_slot: RuntimeCount,
    next_slots: Vec<Option<RuntimeCount>>,
    heap: EventHeap,
}

/// A replication-local indexed min-heap. Entries are stable dense source (or
/// periodic-coordinate) ranks; keys live in the matching cursor array. The
/// inverse table makes commit-time key increases allocation-free.
#[derive(Clone, Debug, Eq, PartialEq)]
struct EventHeap {
    ranks: Vec<u32>,
    positions: Vec<u32>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedMarkedSource {
    law: PreparedMarkedLaw,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedMarkedLaw {
    Joint {
        distribution: PreparedCategorical<u32>,
        outcomes: Vec<PreparedJointOutcome>,
    },
    Factorized {
        gap: PreparedGapLaw,
        destinations: PreparedDestinationRow,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PreparedJointOutcome {
    gap: u64,
    queue: QueueIndex,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedGapLaw {
    Deterministic(u64),
    Finite {
        distribution: PreparedCategorical<u32>,
        gaps: Vec<u64>,
    },
    GeometricGrid {
        d_min: u64,
        delta: u64,
        success_numerator: u128,
        success_denominator: u128,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedDestinationRow {
    distribution: PreparedCategorical<u32>,
    queues: Vec<QueueIndex>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RenewalCursor {
    event_index: u64,
    next_slot: RuntimeCount,
    next_queue: QueueIndex,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedPrivateSource {
    gaps: Vec<u64>,
    initial: PreparedInitial,
    transitions: Vec<PreparedTransitionRow>,
    destinations: PreparedDestinationRow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedInitial {
    Deterministic(u32),
    Distribution {
        distribution: PreparedCategorical<u32>,
        states: Vec<u32>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedTransitionRow {
    distribution: PreparedCategorical<u32>,
    next_states: Vec<u32>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PrivateCursor {
    event_index: u64,
    state_index: u32,
    next_slot: RuntimeCount,
    next_queue: QueueIndex,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedSharedRow {
    distribution: PreparedCategorical<u32>,
    outcomes: Vec<PreparedSharedOutcome>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PreparedSharedOutcome {
    next_state: u32,
    emissions: Vec<PreparedRoundEmission>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PreparedRoundEmission {
    gap: u64,
    queue: QueueIndex,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PendingEmission {
    round_index: u64,
    slot: RuntimeCount,
    queue: QueueIndex,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum PendingAdvance {
    Deterministic {
        next_expected: RuntimeCount,
        next_bucket_cursor: usize,
    },
    GlobalPeriodic {
        next_expected: RuntimeCount,
    },
    DelayedPeriodic {
        next_expected: RuntimeCount,
    },
    MarkedRenewal {
        next_expected: RuntimeCount,
    },
    PrivateRenewal {
        next_expected: RuntimeCount,
    },
    SharedRounds {
        next_expected: RuntimeCount,
        sampled_round: Option<PreparedSharedRoundCommit>,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct PreparedSharedRoundCommit {
    round_index: u64,
    following_round: u64,
    next_state: u32,
}

/// Reusable, replication-local provider storage. All capacities are acquired
/// before the first slot so ordinary direct-count production neither clones a
/// provider state nor allocates an arrival batch.
#[derive(Debug)]
pub(crate) struct ArrivalWorkspace {
    compiled_binding: PreparationBinding,
    session_binding: PreparationBinding,
    replay: ArrivalReplay,
    dense: Vec<RuntimeCount>,
    touched: Vec<QueueIndex>,
    sparse: Vec<Arrival>,
    due_ranks: Vec<u32>,
    delayed_updates: Vec<(u32, Option<RuntimeCount>)>,
    marked_updates: Vec<(u32, RenewalCursor)>,
    private_updates: Vec<(u32, PrivateCursor)>,
    shared_clocks: Vec<RuntimeCount>,
    shared_appends: Vec<PreparedRoundEmission>,
    shared_replacements: Vec<Option<VecDeque<PendingEmission>>>,
    pending: Option<PendingAdvance>,
    staged_work: ArrivalWorkCounters,
    #[cfg(test)]
    fail_next_shared_pending_reservation: bool,
    #[cfg(test)]
    fail_after_next_shared_pending_reservation: bool,
}

/// A borrowed, canonical dense-index-ordered sparse batch prepared in a
/// replication-local workspace.
#[derive(Clone, Copy, Debug)]
pub(crate) struct PreparedArrivalStep<'a> {
    arrivals: &'a [Arrival],
    workspace_memory: ArrivalWorkspaceMemory,
}

impl<'a> PreparedArrivalStep<'a> {
    pub(crate) const fn arrivals(self) -> &'a [Arrival] {
        self.arrivals
    }

    /// Memory held by the provider workspace at this prospective boundary.
    ///
    /// The snapshot travels with the borrowed batch so the transaction engine
    /// can account the provider peak without reborrowing the workspace that
    /// owns `arrivals`.
    pub(crate) const fn workspace_memory(self) -> ArrivalWorkspaceMemory {
        self.workspace_memory
    }
}

impl EventHeap {
    const ABSENT: u32 = u32::MAX;

    fn try_new<F>(rank_count: usize, key: F) -> Result<Self, ArrivalError>
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        if rank_count > u32::MAX as usize {
            return Err(ArrivalError::RepresentationBound {
                field: "event-heap rank count",
            });
        }
        let mut ranks = try_vec(rank_count, "event-heap ranks")?;
        let mut positions = try_vec(rank_count, "event-heap inverse positions")?;
        positions.resize(rank_count, Self::ABSENT);
        for rank in 0..rank_count {
            let rank = dense_u32(rank, "event-heap rank")?;
            if key(rank).is_some() {
                let position = dense_u32(ranks.len(), "event-heap position")?;
                positions[rank as usize] = position;
                ranks.push(rank);
            }
        }
        let mut heap = Self { ranks, positions };
        for position in (0..heap.ranks.len() / 2).rev() {
            heap.sift_down(position, &key);
        }
        Ok(heap)
    }

    fn collect_due<F>(
        &self,
        slot: RuntimeCount,
        key: F,
        output: &mut Vec<u32>,
    ) -> Result<u64, ArrivalError>
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        output.clear();
        let mut visits = 0_u64;
        self.collect_due_from(0, slot, &key, output, &mut visits)?;
        output.sort_unstable();
        Ok(visits)
    }

    fn collect_due_from<F>(
        &self,
        position: usize,
        slot: RuntimeCount,
        key: &F,
        output: &mut Vec<u32>,
        visits: &mut u64,
    ) -> Result<(), ArrivalError>
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        let Some(&rank) = self.ranks.get(position) else {
            return Ok(());
        };
        *visits = visits
            .checked_add(1)
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "event-heap visit count",
            })?;
        let event_slot = key(rank).ok_or(ArrivalError::CorruptState {
            invariant: "event heap contains only active ranks",
        })?;
        if event_slot < slot {
            return Err(ArrivalError::CorruptState {
                invariant: "event heap does not retain a stale root subtree",
            });
        }
        if event_slot != slot {
            return Ok(());
        }
        if output.len() == output.capacity() {
            return Err(ArrivalError::CorruptState {
                invariant: "due-rank workspace has prepared capacity",
            });
        }
        output.push(rank);
        let left = position
            .checked_mul(2)
            .and_then(|value| value.checked_add(1))
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "event-heap child index",
            })?;
        self.collect_due_from(left, slot, key, output, visits)?;
        self.collect_due_from(
            left.checked_add(1)
                .ok_or(ArrivalError::ArithmeticOverflow {
                    operation: "event-heap child index",
                })?,
            slot,
            key,
            output,
            visits,
        )
    }

    fn fix_increased<F>(&mut self, rank: u32, key: F)
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        let rank_position = rank as usize;
        let position = self.positions[rank_position];
        debug_assert_ne!(position, Self::ABSENT);
        let position = position as usize;
        if key(rank).is_none() {
            self.remove_at(position, &key);
        } else {
            self.sift_down(position, &key);
        }
    }

    fn remove_at<F>(&mut self, position: usize, key: &F)
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        let removed = self.ranks[position];
        self.positions[removed as usize] = Self::ABSENT;
        self.ranks.swap_remove(position);
        if position < self.ranks.len() {
            let replacement = self.ranks[position];
            self.positions[replacement as usize] = Self::inverse_position(position);
            if position > 0 {
                let parent = (position - 1) / 2;
                if Self::less(self.ranks[position], self.ranks[parent], key) {
                    self.sift_up(position, key);
                    return;
                }
            }
            self.sift_down(position, key);
        }
    }

    fn sift_up<F>(&mut self, mut position: usize, key: &F)
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        while position > 0 {
            let parent = (position - 1) / 2;
            if !Self::less(self.ranks[position], self.ranks[parent], key) {
                break;
            }
            self.swap_positions(position, parent);
            position = parent;
        }
    }

    fn sift_down<F>(&mut self, mut position: usize, key: &F)
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        loop {
            let Some(left) = position
                .checked_mul(2)
                .and_then(|value| value.checked_add(1))
            else {
                break;
            };
            if left >= self.ranks.len() {
                break;
            }
            let right = left + 1;
            let mut smallest = left;
            if right < self.ranks.len() && Self::less(self.ranks[right], self.ranks[left], key) {
                smallest = right;
            }
            if !Self::less(self.ranks[smallest], self.ranks[position], key) {
                break;
            }
            self.swap_positions(position, smallest);
            position = smallest;
        }
    }

    fn less<F>(left: u32, right: u32, key: &F) -> bool
    where
        F: Fn(u32) -> Option<RuntimeCount>,
    {
        (key(left), left) < (key(right), right)
    }

    fn swap_positions(&mut self, left: usize, right: usize) {
        self.ranks.swap(left, right);
        self.positions[self.ranks[left] as usize] = Self::inverse_position(left);
        self.positions[self.ranks[right] as usize] = Self::inverse_position(right);
    }

    fn inverse_position(position: usize) -> u32 {
        let Ok(position) = u32::try_from(position) else {
            unreachable!("event heap positions are bounded during construction")
        };
        position
    }

    fn mutable_bytes(&self) -> usize {
        self.ranks
            .capacity()
            .saturating_mul(std::mem::size_of::<u32>())
            .saturating_add(
                self.positions
                    .capacity()
                    .saturating_mul(std::mem::size_of::<u32>()),
            )
    }
}

impl ArrivalWorkspace {
    fn try_new(
        queue_count: usize,
        rank_capacity: usize,
        compiled_binding: PreparationBinding,
        session_binding: PreparationBinding,
        replay: ArrivalReplay,
    ) -> Result<Self, ArrivalError> {
        let mut dense = try_vec(queue_count, "arrival dense scratch")?;
        dense.resize(queue_count, RuntimeCount::ZERO);
        let mut shared_replacements = try_vec(rank_capacity, "shared pending replacement scratch")?;
        shared_replacements.resize_with(rank_capacity, || None);
        Ok(Self {
            compiled_binding,
            session_binding,
            replay,
            dense,
            touched: try_vec(queue_count, "arrival touched scratch")?,
            sparse: try_vec(queue_count, "arrival sparse scratch")?,
            due_ranks: try_vec(rank_capacity, "arrival due-rank scratch")?,
            delayed_updates: try_vec(rank_capacity, "delayed-periodic update scratch")?,
            marked_updates: try_vec(rank_capacity, "marked-renewal update scratch")?,
            private_updates: try_vec(rank_capacity, "private-renewal update scratch")?,
            shared_clocks: try_vec(rank_capacity, "shared-round clock scratch")?,
            shared_appends: try_vec(rank_capacity, "shared-round append scratch")?,
            shared_replacements,
            pending: None,
            staged_work: ArrivalWorkCounters::default(),
            #[cfg(test)]
            fail_next_shared_pending_reservation: false,
            #[cfg(test)]
            fail_after_next_shared_pending_reservation: false,
        })
    }

    fn begin(&mut self) -> Result<(), ArrivalError> {
        if self.pending.is_some() {
            return Err(ArrivalError::CorruptState {
                invariant: "prepared provider step is committed or discarded before reuse",
            });
        }
        self.staged_work = ArrivalWorkCounters::default();
        let cleared = u64::try_from(self.touched.len()).map_err(|_error| {
            ArrivalError::RepresentationBound {
                field: "arrival touched clear count",
            }
        })?;
        self.staged_work.touched_clears = cleared;
        for queue in self.touched.drain(..) {
            self.dense[queue.0 as usize] = RuntimeCount::ZERO;
        }
        self.sparse.clear();
        self.due_ranks.clear();
        self.delayed_updates.clear();
        self.marked_updates.clear();
        self.private_updates.clear();
        self.shared_clocks.clear();
        self.shared_appends.clear();
        for replacement in &mut self.shared_replacements {
            *replacement = None;
        }
        Ok(())
    }

    fn abort_preparation(&mut self) {
        for queue in self.touched.drain(..) {
            self.dense[queue.0 as usize] = RuntimeCount::ZERO;
        }
        self.sparse.clear();
        self.due_ranks.clear();
        self.delayed_updates.clear();
        self.marked_updates.clear();
        self.private_updates.clear();
        self.shared_clocks.clear();
        self.shared_appends.clear();
        for replacement in &mut self.shared_replacements {
            *replacement = None;
        }
        self.pending = None;
        self.staged_work = ArrivalWorkCounters::default();
    }

    fn stage_heap_node_visits(&mut self, visits: u64) -> Result<(), ArrivalError> {
        self.staged_work.heap_node_visits = self
            .staged_work
            .heap_node_visits
            .checked_add(visits)
            .ok_or(ArrivalError::ArithmeticOverflow {
            operation: "arrival heap-node work counter",
        })?;
        Ok(())
    }

    fn stage_successor_event(&mut self) -> Result<(), ArrivalError> {
        self.staged_work.successor_events =
            self.staged_work.successor_events.checked_add(1).ok_or(
                ArrivalError::ArithmeticOverflow {
                    operation: "arrival successor-event work counter",
                },
            )?;
        Ok(())
    }

    fn stage_pending_expansion(&mut self, reserved_bytes: usize) -> Result<(), ArrivalError> {
        let reserved_bytes =
            u64::try_from(reserved_bytes).map_err(|_error| ArrivalError::RepresentationBound {
                field: "shared pending reserved bytes",
            })?;
        self.staged_work.shared_pending_expansions = self
            .staged_work
            .shared_pending_expansions
            .checked_add(1)
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "shared pending expansion work counter",
            })?;
        self.staged_work.shared_pending_reserved_bytes = self
            .staged_work
            .shared_pending_reserved_bytes
            .checked_add(reserved_bytes)
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "shared pending byte work counter",
            })?;
        Ok(())
    }

    fn stage_shared_pending_replacement(
        &mut self,
        source_position: usize,
        current: &VecDeque<PendingEmission>,
        remove_front: bool,
        append: PendingEmission,
    ) -> Result<(), ArrivalError> {
        let retained = current.len().checked_sub(usize::from(remove_front)).ok_or(
            ArrivalError::CorruptState {
                invariant: "shared due replacement has a current front",
            },
        )?;
        let required = retained
            .checked_add(1)
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "shared pending replacement length",
            })?;
        if required <= current.capacity() {
            return Ok(());
        }

        #[cfg(test)]
        if std::mem::take(&mut self.fail_next_shared_pending_reservation) {
            return Err(ArrivalError::ResourceExhausted {
                operation: "shared future overshoot",
            });
        }
        let mut replacement = VecDeque::new();
        replacement.try_reserve_exact(required).map_err(|_error| {
            ArrivalError::ResourceExhausted {
                operation: "shared future overshoot",
            }
        })?;
        replacement.extend(current.iter().skip(usize::from(remove_front)).copied());
        replacement.push_back(append);
        let reserved_bytes = replacement
            .capacity()
            .saturating_mul(std::mem::size_of::<PendingEmission>());
        self.stage_pending_expansion(reserved_bytes)?;
        let target = self.shared_replacements.get_mut(source_position).ok_or(
            ArrivalError::CorruptState {
                invariant: "shared replacement scratch width equals source count",
            },
        )?;
        *target = Some(replacement);
        #[cfg(test)]
        if std::mem::take(&mut self.fail_after_next_shared_pending_reservation) {
            return Err(ArrivalError::ResourceExhausted {
                operation: "injected after shared future overshoot reservation",
            });
        }
        Ok(())
    }

    fn add(&mut self, arrival: Arrival) -> Result<(), ArrivalError> {
        let position = validate_queue(arrival.queue(), self.dense.len())?;
        if arrival.count() == RuntimeCount::ZERO || arrival.count().get() > MAX_ARRIVAL_COUNT {
            return Err(ArrivalError::CorruptState {
                invariant: "prepared arrival counts are positive",
            });
        }
        if self.dense[position] == RuntimeCount::ZERO {
            if self.touched.len() == self.touched.capacity() {
                return Err(ArrivalError::CorruptState {
                    invariant: "arrival touched workspace has queue-count capacity",
                });
            }
            self.touched.push(arrival.queue());
            self.staged_work.touched_queue_updates = self
                .staged_work
                .touched_queue_updates
                .checked_add(1)
                .ok_or(ArrivalError::ArithmeticOverflow {
                    operation: "arrival touched-queue work counter",
                })?;
        }
        self.dense[position] = RuntimeCount::new(checked_arrival_sum(
            self.dense[position].get(),
            arrival.count().get(),
            arrival.queue(),
        )?);
        Ok(())
    }

    fn finish(&mut self) -> Result<(), ArrivalError> {
        self.touched.sort_unstable();
        for &queue in &self.touched {
            let count = self.dense[queue.0 as usize];
            if count == RuntimeCount::ZERO || self.sparse.len() == self.sparse.capacity() {
                return Err(ArrivalError::CorruptState {
                    invariant: "canonical sparse workspace is complete and positive",
                });
            }
            self.sparse.push(Arrival::new(queue, count));
        }
        validate_batch_width(&self.sparse, self.dense.len())
    }

    pub(crate) fn memory_accounting(&self) -> ArrivalWorkspaceMemory {
        let fixed_scratch_bytes = [
            self.dense
                .capacity()
                .saturating_mul(std::mem::size_of::<RuntimeCount>()),
            self.touched
                .capacity()
                .saturating_mul(std::mem::size_of::<QueueIndex>()),
            self.sparse
                .capacity()
                .saturating_mul(std::mem::size_of::<Arrival>()),
            self.due_ranks
                .capacity()
                .saturating_mul(std::mem::size_of::<u32>()),
            self.delayed_updates
                .capacity()
                .saturating_mul(std::mem::size_of::<(u32, Option<RuntimeCount>)>()),
            self.marked_updates
                .capacity()
                .saturating_mul(std::mem::size_of::<(u32, RenewalCursor)>()),
            self.private_updates
                .capacity()
                .saturating_mul(std::mem::size_of::<(u32, PrivateCursor)>()),
            self.shared_clocks
                .capacity()
                .saturating_mul(std::mem::size_of::<RuntimeCount>()),
            self.shared_appends
                .capacity()
                .saturating_mul(std::mem::size_of::<PreparedRoundEmission>()),
            self.shared_replacements
                .capacity()
                .saturating_mul(std::mem::size_of::<Option<VecDeque<PendingEmission>>>()),
        ]
        .into_iter()
        .fold(0_usize, usize::saturating_add);
        let staged_pending_bytes =
            self.shared_replacements
                .iter()
                .fold(0_usize, |sum, replacement| {
                    sum.saturating_add(replacement.as_ref().map_or(0, |pending| {
                        pending
                            .capacity()
                            .saturating_mul(std::mem::size_of::<PendingEmission>())
                    }))
                });
        let staged_pending_entries = self
            .shared_replacements
            .iter()
            .fold(0_usize, |sum, replacement| {
                sum.saturating_add(replacement.as_ref().map_or(0, VecDeque::len))
            });
        ArrivalWorkspaceMemory {
            fixed_scratch_bytes,
            staged_pending_bytes,
            staged_pending_entries,
        }
    }

    /// Distinct arrival coordinates touched by the current prospective
    /// provider attempt. This is exposed only to the transaction engine so a
    /// failed attempt can publish honest work before its scratch is cleared.
    pub(crate) fn attempted_touched(&self) -> &[QueueIndex] {
        &self.touched
    }

    #[cfg(test)]
    pub(crate) fn mutable_bytes(&self) -> usize {
        self.memory_accounting().total_bytes()
    }

    #[cfg(test)]
    pub(crate) fn fail_next_shared_pending_reservation_for_test(&mut self) {
        self.fail_next_shared_pending_reservation = true;
    }

    #[cfg(test)]
    pub(crate) fn fail_after_next_shared_pending_reservation_for_test(&mut self) {
        self.fail_after_next_shared_pending_reservation = true;
    }
}

impl PreparedArrival {
    /// Validate and close one resolved definition into immutable tables shared
    /// by every replication. Replay coordinates and mutable cursors are not
    /// retained in this value.
    pub fn try_compile(
        definition: &ResolvedArrival,
        queues: &QueueCatalog,
    ) -> Result<Self, ArrivalError> {
        let binding = preparation_binding(definition, queues);
        match definition {
            ResolvedArrival::DeterministicTrace(spec) => {
                let prepared = PreparedDeterministic {
                    binding,
                    queue_count: queues.len(),
                    buckets: prepare_deterministic(&spec.events, queues)?,
                };
                Ok(Self::DeterministicTrace(prepared))
            }
            ResolvedArrival::PeriodicGlobalPhase(spec) => {
                let period = positive_u64(&spec.period, "period")?;
                let phase = bounded_u64(&spec.phase, "phase")?;
                if phase >= period {
                    return Err(ArrivalError::InvalidDefinition { field: "phase" });
                }
                validate_unique_sources(spec.sources.iter().map(|source| &source.id))?;
                let mut rows = Vec::new();
                for source in &spec.sources {
                    append_periodic_rows(&mut rows, &source.entries, period, phase, queues)?;
                }
                let buckets = bucketize(rows, "global periodic aggregation")?;
                let prepared = PreparedGlobalPeriodic {
                    binding,
                    queue_count: queues.len(),
                    period,
                    buckets,
                };
                Ok(Self::PeriodicGlobalPhase(prepared))
            }
            ResolvedArrival::PeriodicSourceDelays(spec) => {
                let period = positive_u64(&spec.period, "period")?;
                validate_unique_sources(spec.sources.iter().map(|source| &source.id))?;
                let mut sources = try_vec(spec.sources.len(), "delayed periodic sources")?;
                let mut eventual_rows = Vec::new();
                for source in &spec.sources {
                    let prepared_source = prepare_delayed_source(source, period, queues)?;
                    for bucket in &prepared_source.buckets {
                        let global_residue = u64::try_from(
                            (u128::from(prepared_source.delay % period)
                                + u128::from(bucket.key.get()))
                                % u128::from(period),
                        )
                        .map_err(|_error| {
                            ArrivalError::RepresentationBound {
                                field: "delayed periodic residue",
                            }
                        })?;
                        eventual_rows
                            .try_reserve(bucket.arrivals.len())
                            .map_err(|_error| ArrivalError::ResourceExhausted {
                                operation: "delayed periodic aggregate validation",
                            })?;
                        eventual_rows.extend(bucket.arrivals.iter().map(|arrival| {
                            (global_residue, arrival.queue(), arrival.count().get())
                        }));
                    }
                    sources.push(prepared_source);
                }
                let _validated = bucketize(eventual_rows, "delayed periodic aggregate validation")?;
                let coordinate_count = sources.iter().try_fold(0_usize, |sum, source| {
                    let width = source.buckets.iter().try_fold(0_usize, |inner, bucket| {
                        inner.checked_add(bucket.arrivals.len())
                    })?;
                    sum.checked_add(width)
                });
                let coordinate_count =
                    coordinate_count.ok_or(ArrivalError::RepresentationBound {
                        field: "delayed periodic coordinate count",
                    })?;
                let mut coordinates = try_vec(coordinate_count, "delayed periodic coordinates")?;
                for source in &sources {
                    for bucket in &source.buckets {
                        let Some(first_slot) = source.delay.checked_add(bucket.key.get()) else {
                            // This coordinate has no event in the representable
                            // runtime clock and is therefore safely absent.
                            continue;
                        };
                        for arrival in &bucket.arrivals {
                            coordinates.push(PreparedDelayedCoordinate {
                                queue: arrival.queue(),
                                count: arrival.count(),
                                first_slot: RuntimeCount::new(first_slot),
                            });
                        }
                    }
                }
                let prepared = PreparedDelayedPeriodic {
                    binding,
                    queue_count: queues.len(),
                    period,
                    coordinates,
                };
                Ok(Self::PeriodicSourceDelays(prepared))
            }
            ResolvedArrival::IndependentMarkedRenewal(spec) => {
                if spec.sources.is_empty() {
                    return Err(ArrivalError::InvalidDefinition { field: "sources" });
                }
                dense_u32(spec.sources.len() - 1, "marked source index")?;
                validate_unique_sources(spec.sources.iter().map(|source| &source.id))?;
                let mut sources = try_vec(spec.sources.len(), "marked-renewal sources")?;
                for source in &spec.sources {
                    sources.push(PreparedMarkedSource {
                        law: prepare_marked_law(&source.law, queues)?,
                    });
                }
                let prepared = PreparedMarkedRenewal {
                    binding,
                    queue_count: queues.len(),
                    sources,
                };
                Ok(Self::IndependentMarkedRenewal(prepared))
            }
            ResolvedArrival::IndependentPrivateMarkovRenewal(spec) => {
                if spec.sources.is_empty() {
                    return Err(ArrivalError::InvalidDefinition { field: "sources" });
                }
                dense_u32(spec.sources.len() - 1, "private source index")?;
                validate_unique_sources(spec.sources.iter().map(|source| &source.id))?;
                let mut sources = try_vec(spec.sources.len(), "private-renewal sources")?;
                for source in &spec.sources {
                    sources.push(prepare_private_source(source, queues)?);
                }
                let prepared = PreparedPrivateMarkov {
                    binding,
                    queue_count: queues.len(),
                    sources,
                };
                Ok(Self::IndependentPrivateMarkovRenewal(prepared))
            }
            ResolvedArrival::SharedJointRoundMarkovRenewal(spec) => Ok(
                Self::SharedJointRoundMarkovRenewal(prepare_shared(spec, queues, binding)?),
            ),
        }
    }

    /// Instantiate one replication endpoint while prospectively charging only
    /// the addressed draws actually performed during stochastic cursor setup.
    #[cfg(test)]
    pub(crate) fn try_start_counted(
        &self,
        replay: ArrivalReplay,
        budget: ArrivalDrawBudget,
    ) -> Result<(ArrivalState, ArrivalWorkCounters), ArrivalError> {
        let mut attempted_draws = 0;
        self.try_start_counted_observed(replay, budget, &mut attempted_draws)
    }

    /// Count successful primitive generator words even when initialization
    /// later refuses. The out-parameter is attempt evidence only; it is not a
    /// mutable provider cursor and is reset on every invocation.
    pub(crate) fn try_start_counted_observed(
        &self,
        replay: ArrivalReplay,
        budget: ArrivalDrawBudget,
        attempted_draws: &mut u64,
    ) -> Result<(ArrivalState, ArrivalWorkCounters), ArrivalError> {
        *attempted_draws = 0;
        let mut draw_meter = budget.meter()?;
        let compiled_binding = self.compiled_binding();
        let binding = session_binding(compiled_binding, replay);
        let state = match self {
            Self::DeterministicTrace(_) => {
                Ok(ArrivalState::DeterministicTrace(DeterministicState {
                    binding,
                    compiled_binding,
                    replay,
                    expected_slot: RuntimeCount::ZERO,
                    bucket_cursor: 0,
                }))
            }
            Self::PeriodicGlobalPhase(_) => Ok(ArrivalState::PeriodicGlobalPhase(PeriodicState {
                binding,
                compiled_binding,
                replay,
                expected_slot: RuntimeCount::ZERO,
            })),
            Self::PeriodicSourceDelays(prepared) => {
                let mut next_slots = try_vec(
                    prepared.coordinates.len(),
                    "delayed periodic initial clocks",
                )?;
                next_slots.extend(
                    prepared
                        .coordinates
                        .iter()
                        .map(|coordinate| Some(coordinate.first_slot)),
                );
                let heap = EventHeap::try_new(next_slots.len(), |rank| next_slots[rank as usize])?;
                Ok(ArrivalState::PeriodicSourceDelays(DelayedPeriodicState {
                    binding,
                    compiled_binding,
                    replay,
                    expected_slot: RuntimeCount::ZERO,
                    next_slots,
                    heap,
                }))
            }
            Self::IndependentMarkedRenewal(prepared) => Ok(ArrivalState::IndependentMarkedRenewal(
                prepared.initial_state(binding, compiled_binding, replay, &mut draw_meter)?,
            )),
            Self::IndependentPrivateMarkovRenewal(prepared) => {
                Ok(ArrivalState::IndependentPrivateMarkovRenewal(
                    prepared.initial_state(binding, compiled_binding, replay, &mut draw_meter)?,
                ))
            }
            Self::SharedJointRoundMarkovRenewal(prepared) => {
                Ok(ArrivalState::SharedJointRoundMarkovRenewal(
                    prepared.initial_state(binding, compiled_binding, replay, &mut draw_meter)?,
                ))
            }
        };
        *attempted_draws = draw_meter.staged_words();
        let state = state?;
        Ok((
            state,
            ArrivalWorkCounters {
                configured_generator_draws: draw_meter.staged_words(),
                ..ArrivalWorkCounters::default()
            },
        ))
    }

    pub const fn family(&self) -> ArrivalFamily {
        match self {
            Self::DeterministicTrace(_) => ArrivalFamily::DeterministicTrace,
            Self::PeriodicGlobalPhase(_) => ArrivalFamily::PeriodicGlobalPhase,
            Self::PeriodicSourceDelays(_) => ArrivalFamily::PeriodicSourceDelays,
            Self::IndependentMarkedRenewal(_) => ArrivalFamily::IndependentMarkedRenewal,
            Self::IndependentPrivateMarkovRenewal(_) => {
                ArrivalFamily::IndependentPrivateMarkovRenewal
            }
            Self::SharedJointRoundMarkovRenewal(_) => ArrivalFamily::SharedJointRoundMarkovRenewal,
        }
    }

    /// Allocate the bounded scratch owned by one replication. The workspace
    /// is deliberately separate from immutable provider tables and is never
    /// shared between workers.
    pub(crate) fn try_workspace(
        &self,
        state: &ArrivalState,
    ) -> Result<ArrivalWorkspace, ArrivalError> {
        self.validate_state_identity(state)?;
        let (compiled_binding, session_binding, replay) = state.session_identity();
        ArrivalWorkspace::try_new(
            self.queue_count(),
            self.rank_capacity(),
            compiled_binding,
            session_binding,
            replay,
        )
    }

    /// Prepare one provider transition into reusable storage. Logical state,
    /// durable pending capacities, and published work are unchanged until
    /// [`Self::commit_step_counted`].
    #[cfg(test)]
    pub(crate) fn prepare_step_counted<'a>(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
        workspace: &'a mut ArrivalWorkspace,
        budget: ArrivalDrawBudget,
    ) -> Result<PreparedArrivalStep<'a>, ArrivalError> {
        let mut attempted_draws = 0;
        self.prepare_step_counted_observed(slot, state, workspace, budget, &mut attempted_draws)
    }

    /// Prepare a step while publishing primitive words actually generated by
    /// this attempt, including a prefix produced before a later refusal.
    #[cfg(test)]
    pub(crate) fn prepare_step_counted_observed<'a>(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
        workspace: &'a mut ArrivalWorkspace,
        budget: ArrivalDrawBudget,
        attempted_draws: &mut u64,
    ) -> Result<PreparedArrivalStep<'a>, ArrivalError> {
        self.prepare_step_counted_observed_mode(
            slot,
            state,
            workspace,
            budget,
            attempted_draws,
            true,
        )
    }

    /// Engine-only form that leaves failed prospective storage intact until
    /// the caller measures it. The caller must unconditionally discard the
    /// provider step on `Err` before returning from its transaction boundary.
    pub(crate) fn prepare_step_counted_observed_staged<'a>(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
        workspace: &'a mut ArrivalWorkspace,
        budget: ArrivalDrawBudget,
        attempted_draws: &mut u64,
    ) -> Result<PreparedArrivalStep<'a>, ArrivalError> {
        self.prepare_step_counted_observed_mode(
            slot,
            state,
            workspace,
            budget,
            attempted_draws,
            false,
        )
    }

    fn prepare_step_counted_observed_mode<'a>(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
        workspace: &'a mut ArrivalWorkspace,
        budget: ArrivalDrawBudget,
        attempted_draws: &mut u64,
        abort_on_error: bool,
    ) -> Result<PreparedArrivalStep<'a>, ArrivalError> {
        *attempted_draws = 0;
        self.validate_workspace_identity(state, workspace)?;
        workspace.begin()?;
        let mut draw_meter = budget.meter()?;
        if let Err(error) = self.prepare_step_inner(slot, state, workspace, &mut draw_meter) {
            *attempted_draws = draw_meter.staged_words();
            if abort_on_error {
                workspace.abort_preparation();
            }
            return Err(error);
        }
        *attempted_draws = draw_meter.staged_words();
        workspace.staged_work.configured_generator_draws = draw_meter.staged_words();
        Ok(PreparedArrivalStep {
            arrivals: &workspace.sparse,
            workspace_memory: workspace.memory_accounting(),
        })
    }

    fn prepare_step_inner(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
        workspace: &mut ArrivalWorkspace,
        draw_meter: &mut RngWordMeter,
    ) -> Result<(), ArrivalError> {
        match (self, state) {
            (Self::DeterministicTrace(prepared), ArrivalState::DeterministicTrace(state)) => {
                check_slot(state.expected_slot, slot)?;
                validate_deterministic_state(&prepared.buckets, state)?;
                let mut next_bucket_cursor = state.bucket_cursor;
                if let Some(bucket) = prepared.buckets.get(state.bucket_cursor) {
                    if bucket.key == slot {
                        next_bucket_cursor = next_bucket_cursor.checked_add(1).ok_or(
                            ArrivalError::ArithmeticOverflow {
                                operation: "deterministic cursor increment",
                            },
                        )?;
                        for &arrival in &bucket.arrivals {
                            workspace.add(arrival)?;
                        }
                    }
                }
                workspace.pending = Some(PendingAdvance::Deterministic {
                    next_expected: next_expected(slot)?,
                    next_bucket_cursor,
                });
            }
            (Self::PeriodicGlobalPhase(prepared), ArrivalState::PeriodicGlobalPhase(state)) => {
                check_slot(state.expected_slot, slot)?;
                if prepared.period == 0 {
                    return Err(ArrivalError::CorruptState {
                        invariant: "prepared global period is positive",
                    });
                }
                if let Some(bucket) = find_bucket(&prepared.buckets, slot.get() % prepared.period) {
                    for &arrival in &bucket.arrivals {
                        workspace.add(arrival)?;
                    }
                }
                workspace.pending = Some(PendingAdvance::GlobalPeriodic {
                    next_expected: next_expected(slot)?,
                });
            }
            (Self::PeriodicSourceDelays(prepared), ArrivalState::PeriodicSourceDelays(state)) => {
                check_slot(state.expected_slot, slot)?;
                if state.next_slots.len() != prepared.coordinates.len() {
                    return Err(ArrivalError::CorruptState {
                        invariant: "delayed periodic cursor width equals coordinate count",
                    });
                }
                let visits = state.heap.collect_due(
                    slot,
                    |rank| state.next_slots[rank as usize],
                    &mut workspace.due_ranks,
                )?;
                workspace.stage_heap_node_visits(visits)?;
                for due_position in 0..workspace.due_ranks.len() {
                    let rank = workspace.due_ranks[due_position];
                    let coordinate = prepared.coordinates.get(rank as usize).ok_or(
                        ArrivalError::CorruptState {
                            invariant: "delayed periodic coordinate rank is in range",
                        },
                    )?;
                    workspace.add(Arrival::new(coordinate.queue, coordinate.count))?;
                    let next = state.next_slots[rank as usize].and_then(|current| {
                        current
                            .get()
                            .checked_add(prepared.period)
                            .map(RuntimeCount::new)
                    });
                    workspace.delayed_updates.push((rank, next));
                }
                workspace.pending = Some(PendingAdvance::DelayedPeriodic {
                    next_expected: next_expected(slot)?,
                });
            }
            (
                Self::IndependentMarkedRenewal(prepared),
                ArrivalState::IndependentMarkedRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                if state.cursors.len() != prepared.sources.len() {
                    return Err(ArrivalError::CorruptState {
                        invariant: "marked cursor width equals source count",
                    });
                }
                let visits = state.heap.collect_due(
                    slot,
                    |rank| Some(state.cursors[rank as usize].next_slot),
                    &mut workspace.due_ranks,
                )?;
                workspace.stage_heap_node_visits(visits)?;
                for due_position in 0..workspace.due_ranks.len() {
                    let rank = workspace.due_ranks[due_position];
                    let position = rank as usize;
                    let source =
                        prepared
                            .sources
                            .get(position)
                            .ok_or(ArrivalError::CorruptState {
                                invariant: "marked source rank is in range",
                            })?;
                    let cursor = state.cursors[position];
                    validate_queue(cursor.next_queue, prepared.queue_count)?;
                    workspace.add(Arrival::new(cursor.next_queue, RuntimeCount::new(1)))?;
                    let event_index = cursor.event_index.checked_add(1).ok_or(
                        ArrivalError::ArithmeticOverflow {
                            operation: "marked-renewal event index",
                        },
                    )?;
                    let (gap, next_queue) = PreparedMarkedRenewal::sample_event(
                        state.replay,
                        rank,
                        source,
                        event_index,
                        DirectArrivalDrawRole::Gap,
                        draw_meter,
                    )?;
                    workspace.stage_successor_event()?;
                    workspace.marked_updates.push((
                        rank,
                        RenewalCursor {
                            event_index,
                            next_slot: checked_clock_add(cursor.next_slot, gap)?,
                            next_queue,
                        },
                    ));
                }
                workspace.pending = Some(PendingAdvance::MarkedRenewal {
                    next_expected: next_expected(slot)?,
                });
            }
            (
                Self::IndependentPrivateMarkovRenewal(prepared),
                ArrivalState::IndependentPrivateMarkovRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                if state.cursors.len() != prepared.sources.len() {
                    return Err(ArrivalError::CorruptState {
                        invariant: "private cursor width equals source count",
                    });
                }
                let visits = state.heap.collect_due(
                    slot,
                    |rank| Some(state.cursors[rank as usize].next_slot),
                    &mut workspace.due_ranks,
                )?;
                workspace.stage_heap_node_visits(visits)?;
                for due_position in 0..workspace.due_ranks.len() {
                    let rank = workspace.due_ranks[due_position];
                    let position = rank as usize;
                    let source =
                        prepared
                            .sources
                            .get(position)
                            .ok_or(ArrivalError::CorruptState {
                                invariant: "private source rank is in range",
                            })?;
                    let cursor = state.cursors[position];
                    validate_queue(cursor.next_queue, prepared.queue_count)?;
                    workspace.add(Arrival::new(cursor.next_queue, RuntimeCount::new(1)))?;
                    let event_index = cursor.event_index.checked_add(1).ok_or(
                        ArrivalError::ArithmeticOverflow {
                            operation: "private-renewal event index",
                        },
                    )?;
                    let row_position = state_usize(cursor.state_index, source.transitions.len())?;
                    let transition = &source.transitions[row_position];
                    let selected = draw_index(
                        state.replay,
                        DirectArrivalRngProvider::PrivateMarkov,
                        rank,
                        event_index,
                        cursor.state_index,
                        DirectArrivalDrawRole::Transition,
                        0,
                        &transition.distribution,
                        draw_meter,
                    )?;
                    let next_state = *transition.next_states.get(selected).ok_or(
                        ArrivalError::CorruptState {
                            invariant: "private transition row index is in range",
                        },
                    )?;
                    let next_state_position = state_usize(next_state, source.gaps.len())?;
                    let next_queue = sample_destination(
                        &source.destinations,
                        state.replay,
                        DirectArrivalRngProvider::PrivateMarkov,
                        rank,
                        event_index,
                        next_state,
                        draw_meter,
                    )?;
                    workspace.stage_successor_event()?;
                    workspace.private_updates.push((
                        rank,
                        PrivateCursor {
                            event_index,
                            state_index: next_state,
                            next_slot: checked_clock_add(
                                cursor.next_slot,
                                source.gaps[next_state_position],
                            )?,
                            next_queue,
                        },
                    ));
                }
                workspace.pending = Some(PendingAdvance::PrivateRenewal {
                    next_expected: next_expected(slot)?,
                });
            }
            (
                Self::SharedJointRoundMarkovRenewal(prepared),
                ArrivalState::SharedJointRoundMarkovRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                if state.clocks.len() != prepared.source_count
                    || state.pending_by_source.len() != prepared.source_count
                {
                    return Err(ArrivalError::CorruptState {
                        invariant: "shared state width equals source count",
                    });
                }
                let visits = state.heap.collect_due(
                    slot,
                    |rank| {
                        state.pending_by_source[rank as usize]
                            .front()
                            .map(|pending| pending.slot)
                    },
                    &mut workspace.due_ranks,
                )?;
                workspace.stage_heap_node_visits(visits)?;
                let mut needs_round = false;
                for due_position in 0..workspace.due_ranks.len() {
                    let rank = workspace.due_ranks[due_position];
                    let pending = &state.pending_by_source[rank as usize];
                    let emission = pending.front().ok_or(ArrivalError::CorruptState {
                        invariant: "shared event heap names a pending front",
                    })?;
                    if emission.slot != slot {
                        return Err(ArrivalError::CorruptState {
                            invariant: "shared due emission has the requested slot",
                        });
                    }
                    workspace.add(Arrival::new(emission.queue, RuntimeCount::new(1)))?;
                    needs_round |= pending.len() == 1;
                }

                let sampled_round = if needs_round {
                    let round_index = state.next_round;
                    let following_round =
                        round_index
                            .checked_add(1)
                            .ok_or(ArrivalError::ArithmeticOverflow {
                                operation: "shared round index",
                            })?;
                    let outcome = prepared.sample_round(
                        state.replay,
                        round_index,
                        state.next_round_state,
                        draw_meter,
                    )?;
                    if outcome.emissions.len() != prepared.source_count {
                        return Err(ArrivalError::CorruptState {
                            invariant: "shared sampled outcome width equals source count",
                        });
                    }
                    workspace.stage_successor_event()?;
                    for (source_position, emission) in outcome.emissions.iter().enumerate() {
                        let next_clock =
                            checked_clock_add(state.clocks[source_position], emission.gap)?;
                        if next_clock <= slot {
                            return Err(ArrivalError::CorruptState {
                                invariant: "positive shared gap advances beyond current slot",
                            });
                        }
                        let remove_front = workspace
                            .due_ranks
                            .binary_search(&dense_u32(source_position, "shared source position")?)
                            .is_ok();
                        workspace.stage_shared_pending_replacement(
                            source_position,
                            &state.pending_by_source[source_position],
                            remove_front,
                            PendingEmission {
                                round_index,
                                slot: next_clock,
                                queue: emission.queue,
                            },
                        )?;
                        workspace.shared_clocks.push(next_clock);
                        workspace.shared_appends.push(*emission);
                    }
                    Some(PreparedSharedRoundCommit {
                        round_index,
                        following_round,
                        next_state: outcome.next_state,
                    })
                } else {
                    None
                };
                workspace.pending = Some(PendingAdvance::SharedRounds {
                    next_expected: next_expected(slot)?,
                    sampled_round,
                });
            }
            _ => return Err(ArrivalError::StateFamilyMismatch),
        }
        workspace.finish()
    }

    /// Commit a previously prepared provider transition. All allocations,
    /// random sampling, arithmetic, and invariant checks have already passed.
    pub(crate) fn commit_step_counted(
        &self,
        state: &mut ArrivalState,
        workspace: &mut ArrivalWorkspace,
    ) -> ArrivalWorkCounters {
        let pending = workspace
            .pending
            .take()
            .expect("provider commit requires a prepared step");
        match (self, state, pending) {
            (
                Self::DeterministicTrace(_),
                ArrivalState::DeterministicTrace(state),
                PendingAdvance::Deterministic {
                    next_expected,
                    next_bucket_cursor,
                },
            ) => {
                state.expected_slot = next_expected;
                state.bucket_cursor = next_bucket_cursor;
            }
            (
                Self::PeriodicGlobalPhase(_),
                ArrivalState::PeriodicGlobalPhase(state),
                PendingAdvance::GlobalPeriodic { next_expected },
            ) => state.expected_slot = next_expected,
            (
                Self::PeriodicSourceDelays(_),
                ArrivalState::PeriodicSourceDelays(state),
                PendingAdvance::DelayedPeriodic { next_expected },
            ) => {
                for &(rank, next_slot) in &workspace.delayed_updates {
                    state.next_slots[rank as usize] = next_slot;
                    let next_slots = &state.next_slots;
                    state
                        .heap
                        .fix_increased(rank, |other| next_slots[other as usize]);
                }
                state.expected_slot = next_expected;
            }
            (
                Self::IndependentMarkedRenewal(_),
                ArrivalState::IndependentMarkedRenewal(state),
                PendingAdvance::MarkedRenewal { next_expected },
            ) => {
                for &(rank, cursor) in &workspace.marked_updates {
                    state.cursors[rank as usize] = cursor;
                    let cursors = &state.cursors;
                    state
                        .heap
                        .fix_increased(rank, |other| Some(cursors[other as usize].next_slot));
                }
                state.expected_slot = next_expected;
            }
            (
                Self::IndependentPrivateMarkovRenewal(_),
                ArrivalState::IndependentPrivateMarkovRenewal(state),
                PendingAdvance::PrivateRenewal { next_expected },
            ) => {
                for &(rank, cursor) in &workspace.private_updates {
                    state.cursors[rank as usize] = cursor;
                    let cursors = &state.cursors;
                    state
                        .heap
                        .fix_increased(rank, |other| Some(cursors[other as usize].next_slot));
                }
                state.expected_slot = next_expected;
            }
            (
                Self::SharedJointRoundMarkovRenewal(_),
                ArrivalState::SharedJointRoundMarkovRenewal(state),
                PendingAdvance::SharedRounds {
                    next_expected,
                    sampled_round,
                },
            ) => {
                if let Some(round) = sampled_round {
                    debug_assert_eq!(workspace.shared_clocks.len(), state.clocks.len());
                    debug_assert_eq!(workspace.shared_appends.len(), state.clocks.len());
                    for source_position in 0..state.clocks.len() {
                        let rank = EventHeap::inverse_position(source_position);
                        let is_due = workspace.due_ranks.binary_search(&rank).is_ok();
                        state.clocks[source_position] = workspace.shared_clocks[source_position];
                        let emission = workspace.shared_appends[source_position];
                        if let Some(mut replacement) =
                            workspace.shared_replacements[source_position].take()
                        {
                            std::mem::swap(
                                &mut state.pending_by_source[source_position],
                                &mut replacement,
                            );
                        } else {
                            if is_due {
                                let popped = state.pending_by_source[source_position].pop_front();
                                debug_assert!(popped.is_some());
                            }
                            state.pending_by_source[source_position].push_back(PendingEmission {
                                round_index: round.round_index,
                                slot: workspace.shared_clocks[source_position],
                                queue: emission.queue,
                            });
                        }
                        if is_due {
                            let pending = &state.pending_by_source;
                            state.heap.fix_increased(rank, |other| {
                                pending[other as usize].front().map(|value| value.slot)
                            });
                        }
                    }
                    state.next_round = round.following_round;
                    state.next_round_state = round.next_state;
                } else {
                    for &rank in &workspace.due_ranks {
                        let popped = state.pending_by_source[rank as usize].pop_front();
                        debug_assert!(popped.is_some());
                        let pending = &state.pending_by_source;
                        state.heap.fix_increased(rank, |other| {
                            pending[other as usize].front().map(|value| value.slot)
                        });
                    }
                }
                state.expected_slot = next_expected;
            }
            _ => unreachable!("prepared provider step family cannot change before commit"),
        }
        std::mem::take(&mut workspace.staged_work)
    }

    pub(crate) fn discard_step(workspace: &mut ArrivalWorkspace) {
        workspace.abort_preparation();
    }

    fn validate_state_identity(&self, state: &ArrivalState) -> Result<(), ArrivalError> {
        if self.family() != state.family() {
            return Err(ArrivalError::StateFamilyMismatch);
        }
        let (compiled_binding, session_binding, replay) = state.session_identity();
        check_binding(
            self.compiled_binding(),
            compiled_binding,
            session_binding,
            replay,
        )
    }

    fn validate_workspace_identity(
        &self,
        state: &ArrivalState,
        workspace: &ArrivalWorkspace,
    ) -> Result<(), ArrivalError> {
        if self.family() != state.family() {
            return Err(ArrivalError::StateFamilyMismatch);
        }
        let (compiled_binding, session_binding, replay) = state.session_identity();
        if self.compiled_binding() != compiled_binding
            || workspace.compiled_binding != compiled_binding
            || workspace.session_binding != session_binding
            || workspace.replay != replay
        {
            return Err(ArrivalError::CorruptState {
                invariant: "state and workspace belong to this compiled provider session",
            });
        }
        Ok(())
    }

    pub(crate) const fn queue_count(&self) -> usize {
        match self {
            Self::DeterministicTrace(value) => value.queue_count,
            Self::PeriodicGlobalPhase(value) => value.queue_count,
            Self::PeriodicSourceDelays(value) => value.queue_count,
            Self::IndependentMarkedRenewal(value) => value.queue_count,
            Self::IndependentPrivateMarkovRenewal(value) => value.queue_count,
            Self::SharedJointRoundMarkovRenewal(value) => value.queue_count,
        }
    }

    const fn compiled_binding(&self) -> PreparationBinding {
        match self {
            Self::DeterministicTrace(value) => value.binding,
            Self::PeriodicGlobalPhase(value) => value.binding,
            Self::PeriodicSourceDelays(value) => value.binding,
            Self::IndependentMarkedRenewal(value) => value.binding,
            Self::IndependentPrivateMarkovRenewal(value) => value.binding,
            Self::SharedJointRoundMarkovRenewal(value) => value.binding,
        }
    }

    fn rank_capacity(&self) -> usize {
        match self {
            Self::DeterministicTrace(_) | Self::PeriodicGlobalPhase(_) => 0,
            Self::PeriodicSourceDelays(value) => value.coordinates.len(),
            Self::IndependentMarkedRenewal(value) => value.sources.len(),
            Self::IndependentPrivateMarkovRenewal(value) => value.sources.len(),
            Self::SharedJointRoundMarkovRenewal(value) => value.source_count,
        }
    }

    /// Deliberately dense current-tree oracle. It exists only in unit-test
    /// compilation and is never selectable by input, the CLI, or production
    /// code.
    #[cfg(any(test, feature = "qualification-test-support"))]
    pub(crate) fn advance_dense_for_test(
        &self,
        slot: RuntimeCount,
        state: &ArrivalState,
    ) -> Result<(ArrivalBatch, ArrivalState), ArrivalError> {
        self.validate_state_identity(state)?;
        let mut candidate = state.clone();
        let mut dense = try_vec(self.queue_count(), "dense arrival reference")?;
        dense.resize(self.queue_count(), RuntimeCount::ZERO);
        let next_expected = next_expected(slot)?;
        let mut draw_meter = RngWordMeter::unbounded_for_test();

        match (self, &mut candidate) {
            (Self::DeterministicTrace(prepared), ArrivalState::DeterministicTrace(state)) => {
                check_slot(state.expected_slot, slot)?;
                validate_deterministic_state(&prepared.buckets, state)?;
                if let Some(bucket) = prepared.buckets.get(state.bucket_cursor) {
                    if bucket.key == slot {
                        for &arrival in &bucket.arrivals {
                            dense_reference_add(&mut dense, arrival)?;
                        }
                        state.bucket_cursor = state.bucket_cursor.checked_add(1).ok_or(
                            ArrivalError::ArithmeticOverflow {
                                operation: "deterministic cursor increment",
                            },
                        )?;
                    }
                }
                state.expected_slot = next_expected;
            }
            (Self::PeriodicGlobalPhase(prepared), ArrivalState::PeriodicGlobalPhase(state)) => {
                check_slot(state.expected_slot, slot)?;
                if prepared.period == 0 {
                    return Err(ArrivalError::CorruptState {
                        invariant: "prepared global period is positive",
                    });
                }
                if let Some(bucket) = find_bucket(&prepared.buckets, slot.get() % prepared.period) {
                    for &arrival in &bucket.arrivals {
                        dense_reference_add(&mut dense, arrival)?;
                    }
                }
                state.expected_slot = next_expected;
            }
            (Self::PeriodicSourceDelays(prepared), ArrivalState::PeriodicSourceDelays(state)) => {
                check_slot(state.expected_slot, slot)?;
                if state.next_slots.len() != prepared.coordinates.len() {
                    return Err(ArrivalError::CorruptState {
                        invariant: "delayed periodic cursor width equals coordinate count",
                    });
                }
                for rank in 0..prepared.coordinates.len() {
                    if state.next_slots[rank] != Some(slot) {
                        continue;
                    }
                    let coordinate = prepared.coordinates[rank];
                    dense_reference_add(
                        &mut dense,
                        Arrival::new(coordinate.queue, coordinate.count),
                    )?;
                    let next_slot = slot
                        .get()
                        .checked_add(prepared.period)
                        .map(RuntimeCount::new);
                    state.next_slots[rank] = next_slot;
                    let next_slots = &state.next_slots;
                    state.heap.fix_increased(
                        dense_u32(rank, "delayed periodic coordinate rank")?,
                        |other| next_slots[other as usize],
                    );
                }
                state.expected_slot = next_expected;
            }
            (
                Self::IndependentMarkedRenewal(prepared),
                ArrivalState::IndependentMarkedRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                validate_renewal_cursors(
                    &state.cursors,
                    prepared.sources.len(),
                    prepared.queue_count,
                    slot,
                )?;
                for (source_position, source) in prepared.sources.iter().enumerate() {
                    let cursor = state.cursors[source_position];
                    if cursor.next_slot != slot {
                        continue;
                    }
                    dense_reference_add(
                        &mut dense,
                        Arrival::new(cursor.next_queue, RuntimeCount::new(1)),
                    )?;
                    let event_index = cursor.event_index.checked_add(1).ok_or(
                        ArrivalError::ArithmeticOverflow {
                            operation: "marked-renewal event index",
                        },
                    )?;
                    let source_index = dense_u32(source_position, "marked source index")?;
                    let (gap, next_queue) = PreparedMarkedRenewal::sample_event(
                        state.replay,
                        source_index,
                        source,
                        event_index,
                        DirectArrivalDrawRole::Gap,
                        &mut draw_meter,
                    )?;
                    state.cursors[source_position] = RenewalCursor {
                        event_index,
                        next_slot: checked_clock_add(cursor.next_slot, gap)?,
                        next_queue,
                    };
                    let cursors = &state.cursors;
                    state.heap.fix_increased(source_index, |other| {
                        Some(cursors[other as usize].next_slot)
                    });
                }
                state.expected_slot = next_expected;
            }
            (
                Self::IndependentPrivateMarkovRenewal(prepared),
                ArrivalState::IndependentPrivateMarkovRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                validate_private_cursors(state, prepared, slot)?;
                for (source_position, source) in prepared.sources.iter().enumerate() {
                    let cursor = state.cursors[source_position];
                    if cursor.next_slot != slot {
                        continue;
                    }
                    dense_reference_add(
                        &mut dense,
                        Arrival::new(cursor.next_queue, RuntimeCount::new(1)),
                    )?;
                    let event_index = cursor.event_index.checked_add(1).ok_or(
                        ArrivalError::ArithmeticOverflow {
                            operation: "private-renewal event index",
                        },
                    )?;
                    let source_index = dense_u32(source_position, "private source index")?;
                    let row_position = state_usize(cursor.state_index, source.transitions.len())?;
                    let transition = &source.transitions[row_position];
                    let selected = draw_index(
                        state.replay,
                        DirectArrivalRngProvider::PrivateMarkov,
                        source_index,
                        event_index,
                        cursor.state_index,
                        DirectArrivalDrawRole::Transition,
                        0,
                        &transition.distribution,
                        &mut draw_meter,
                    )?;
                    let next_state = transition.next_states[selected];
                    let next_state_position = state_usize(next_state, source.gaps.len())?;
                    let next_queue = sample_destination(
                        &source.destinations,
                        state.replay,
                        DirectArrivalRngProvider::PrivateMarkov,
                        source_index,
                        event_index,
                        next_state,
                        &mut draw_meter,
                    )?;
                    state.cursors[source_position] = PrivateCursor {
                        event_index,
                        state_index: next_state,
                        next_slot: checked_clock_add(
                            cursor.next_slot,
                            source.gaps[next_state_position],
                        )?,
                        next_queue,
                    };
                    let cursors = &state.cursors;
                    state.heap.fix_increased(source_index, |other| {
                        Some(cursors[other as usize].next_slot)
                    });
                }
                state.expected_slot = next_expected;
            }
            (
                Self::SharedJointRoundMarkovRenewal(prepared),
                ArrivalState::SharedJointRoundMarkovRenewal(state),
            ) => {
                check_slot(state.expected_slot, slot)?;
                validate_shared_state(prepared, state, slot)?;
                let mut due = try_vec(prepared.source_count, "dense shared due sources")?;
                let mut needs_round = false;
                for source_position in 0..state.pending_by_source.len() {
                    let front = state.pending_by_source[source_position].front().ok_or(
                        ArrivalError::CorruptState {
                            invariant: "shared source retains a pending overshoot",
                        },
                    )?;
                    if front.slot != slot {
                        continue;
                    }
                    dense_reference_add(
                        &mut dense,
                        Arrival::new(front.queue, RuntimeCount::new(1)),
                    )?;
                    due.push(dense_u32(source_position, "shared source index")?);
                    needs_round |= state.pending_by_source[source_position].len() == 1;
                }
                if needs_round {
                    let round_index = state.next_round;
                    let following_round =
                        round_index
                            .checked_add(1)
                            .ok_or(ArrivalError::ArithmeticOverflow {
                                operation: "shared round index",
                            })?;
                    let outcome = prepared.sample_round(
                        state.replay,
                        round_index,
                        state.next_round_state,
                        &mut draw_meter,
                    )?;
                    for (source_position, emission) in outcome.emissions.iter().enumerate() {
                        let rank = dense_u32(source_position, "shared source index")?;
                        let is_due = due.binary_search(&rank).is_ok();
                        if is_due {
                            state.pending_by_source[source_position].pop_front().ok_or(
                                ArrivalError::CorruptState {
                                    invariant: "shared pending front exists",
                                },
                            )?;
                        }
                        state.clocks[source_position] =
                            checked_clock_add(state.clocks[source_position], emission.gap)?;
                        state.pending_by_source[source_position]
                            .try_reserve(1)
                            .map_err(|_error| ArrivalError::ResourceExhausted {
                                operation: "dense shared future overshoot",
                            })?;
                        state.pending_by_source[source_position].push_back(PendingEmission {
                            round_index,
                            slot: state.clocks[source_position],
                            queue: emission.queue,
                        });
                        if is_due {
                            let pending = &state.pending_by_source;
                            state.heap.fix_increased(rank, |other| {
                                pending[other as usize].front().map(|value| value.slot)
                            });
                        }
                    }
                    state.next_round = following_round;
                    state.next_round_state = outcome.next_state;
                } else {
                    for rank in due {
                        state.pending_by_source[rank as usize].pop_front().ok_or(
                            ArrivalError::CorruptState {
                                invariant: "shared pending front exists",
                            },
                        )?;
                        let pending = &state.pending_by_source;
                        state.heap.fix_increased(rank, |other| {
                            pending[other as usize].front().map(|value| value.slot)
                        });
                    }
                }
                state.expected_slot = next_expected;
            }
            _ => return Err(ArrivalError::StateFamilyMismatch),
        }

        let mut sparse = try_vec(self.queue_count(), "dense reference sparse output")?;
        for (position, count) in dense.into_iter().enumerate() {
            if count != RuntimeCount::ZERO {
                sparse.push(Arrival::new(
                    QueueIndex(dense_u32(position, "dense reference queue index")?),
                    count,
                ));
            }
        }
        Ok((ArrivalBatch::new(sparse), candidate))
    }
}

#[cfg(any(test, feature = "qualification-test-support"))]
fn dense_reference_add(dense: &mut [RuntimeCount], arrival: Arrival) -> Result<(), ArrivalError> {
    let position = validate_queue(arrival.queue(), dense.len())?;
    dense[position] = RuntimeCount::new(checked_arrival_sum(
        dense[position].get(),
        arrival.count().get(),
        arrival.queue(),
    )?);
    Ok(())
}

fn prepare_deterministic(
    events: &[crate::resolved::CountArrivalEvent],
    queues: &QueueCatalog,
) -> Result<Vec<PreparedBucket>, ArrivalError> {
    let mut rows = try_vec(events.len(), "deterministic rows")?;
    for event in events {
        let slot = bounded_u64(&event.slot, "deterministic slot")?;
        if event.count == 0 || event.count > MAX_ARRIVAL_COUNT {
            return Err(ArrivalError::InvalidDefinition {
                field: "deterministic count",
            });
        }
        rows.push((slot, resolve_queue(queues, &event.queue_id)?, event.count));
    }
    bucketize(rows, "deterministic aggregation")
}

fn append_periodic_rows(
    rows: &mut Vec<(u64, QueueIndex, u64)>,
    entries: &[PeriodicEntry],
    period: u64,
    phase: u64,
    queues: &QueueCatalog,
) -> Result<(), ArrivalError> {
    rows.try_reserve(entries.len())
        .map_err(|_error| ArrivalError::ResourceExhausted {
            operation: "periodic rows",
        })?;
    for entry in entries {
        let offset = bounded_u64(&entry.offset, "periodic offset")?;
        if offset >= period || entry.count == 0 || entry.count > MAX_ARRIVAL_COUNT {
            return Err(ArrivalError::InvalidDefinition {
                field: "periodic entry",
            });
        }
        let residue_u128 = (u128::from(offset) + u128::from(phase)) % u128::from(period);
        let residue =
            u64::try_from(residue_u128).map_err(|_error| ArrivalError::RepresentationBound {
                field: "periodic residue",
            })?;
        rows.push((
            residue,
            resolve_queue(queues, &entry.queue_id)?,
            entry.count,
        ));
    }
    Ok(())
}

fn prepare_delayed_source(
    source: &DelayedPeriodicSource,
    period: u64,
    queues: &QueueCatalog,
) -> Result<PreparedDelayedSource, ArrivalError> {
    let delay = bounded_u64(&source.delay, "source delay")?;
    let mut rows = Vec::new();
    append_periodic_rows(&mut rows, &source.entries, period, 0, queues)?;
    Ok(PreparedDelayedSource {
        delay,
        buckets: bucketize(rows, "delayed periodic aggregation")?,
    })
}

fn bucketize(
    mut rows: Vec<(u64, QueueIndex, u64)>,
    operation: &'static str,
) -> Result<Vec<PreparedBucket>, ArrivalError> {
    rows.sort_unstable_by_key(|(slot, queue, _count)| (*slot, queue.0));
    let mut merged: Vec<(u64, QueueIndex, u64)> = try_vec(rows.len(), operation)?;
    for (slot, queue, count) in rows {
        if count == 0 || count > MAX_ARRIVAL_COUNT {
            return Err(ArrivalError::ArrivalAggregateOverflow { queue });
        }
        if let Some((last_slot, last_queue, last_count)) = merged.last_mut() {
            if *last_slot == slot && *last_queue == queue {
                *last_count = checked_arrival_sum(*last_count, count, queue)?;
                continue;
            }
        }
        merged.push((slot, queue, count));
    }

    let mut buckets = try_vec(merged.len(), operation)?;
    let mut index = 0;
    while index < merged.len() {
        let key = merged[index].0;
        let start = index;
        while index < merged.len() && merged[index].0 == key {
            index += 1;
        }
        let mut arrivals = try_vec(index - start, operation)?;
        for (_slot, queue, count) in &merged[start..index] {
            arrivals.push(Arrival::new(*queue, RuntimeCount::new(*count)));
        }
        buckets.push(PreparedBucket {
            key: RuntimeCount::new(key),
            arrivals,
        });
    }
    Ok(buckets)
}

fn validate_deterministic_state(
    buckets: &[PreparedBucket],
    state: &DeterministicState,
) -> Result<(), ArrivalError> {
    if state.bucket_cursor > buckets.len() {
        return Err(ArrivalError::CorruptState {
            invariant: "deterministic cursor is in range",
        });
    }
    if state.bucket_cursor > 0 && buckets[state.bucket_cursor - 1].key >= state.expected_slot {
        return Err(ArrivalError::CorruptState {
            invariant: "deterministic consumed buckets precede expected slot",
        });
    }
    if let Some(bucket) = buckets.get(state.bucket_cursor) {
        if bucket.key < state.expected_slot {
            return Err(ArrivalError::CorruptState {
                invariant: "deterministic cursor names first unconsumed bucket",
            });
        }
    }
    Ok(())
}

fn find_bucket(buckets: &[PreparedBucket], key: u64) -> Option<&PreparedBucket> {
    buckets
        .binary_search_by_key(&key, |bucket| bucket.key.get())
        .ok()
        .and_then(|index| buckets.get(index))
}

impl PreparedMarkedRenewal {
    fn initial_state(
        &self,
        binding: PreparationBinding,
        compiled_binding: PreparationBinding,
        replay: ArrivalReplay,
        draw_meter: &mut RngWordMeter,
    ) -> Result<MarkedState, ArrivalError> {
        let mut cursors = try_vec(self.sources.len(), "marked-renewal initial state")?;
        for (source_position, source) in self.sources.iter().enumerate() {
            let source_index = dense_u32(source_position, "marked source index")?;
            let (gap, next_queue) = Self::sample_event(
                replay,
                source_index,
                source,
                0,
                DirectArrivalDrawRole::Gap,
                draw_meter,
            )?;
            cursors.push(RenewalCursor {
                event_index: 0,
                next_slot: RuntimeCount::new(gap - 1),
                next_queue,
            });
        }
        let heap = EventHeap::try_new(self.sources.len(), |rank| {
            cursors.get(rank as usize).map(|cursor| cursor.next_slot)
        })?;
        Ok(MarkedState {
            binding,
            compiled_binding,
            replay,
            expected_slot: RuntimeCount::ZERO,
            cursors,
            heap,
        })
    }

    fn sample_event(
        replay: ArrivalReplay,
        source_index: u32,
        source: &PreparedMarkedSource,
        event_index: u64,
        gap_role: DirectArrivalDrawRole,
        draw_meter: &mut RngWordMeter,
    ) -> Result<(u64, QueueIndex), ArrivalError> {
        match &source.law {
            PreparedMarkedLaw::Joint {
                distribution,
                outcomes,
            } => {
                let row = draw_index(
                    replay,
                    DirectArrivalRngProvider::Marked,
                    source_index,
                    event_index,
                    0,
                    DirectArrivalDrawRole::JointGapDestination,
                    0,
                    distribution,
                    draw_meter,
                )?;
                let outcome = outcomes.get(row).ok_or(ArrivalError::CorruptState {
                    invariant: "joint marked row index is in range",
                })?;
                Ok((outcome.gap, outcome.queue))
            }
            PreparedMarkedLaw::Factorized { gap, destinations } => {
                let sampled_gap = sample_gap(
                    gap,
                    replay,
                    DirectArrivalRngProvider::Marked,
                    source_index,
                    event_index,
                    0,
                    gap_role,
                    draw_meter,
                )?;
                let queue = sample_destination(
                    destinations,
                    replay,
                    DirectArrivalRngProvider::Marked,
                    source_index,
                    event_index,
                    0,
                    draw_meter,
                )?;
                Ok((sampled_gap, queue))
            }
        }
    }
}

impl PreparedPrivateMarkov {
    fn initial_state(
        &self,
        binding: PreparationBinding,
        compiled_binding: PreparationBinding,
        replay: ArrivalReplay,
        draw_meter: &mut RngWordMeter,
    ) -> Result<PrivateState, ArrivalError> {
        let mut cursors = try_vec(self.sources.len(), "private-renewal initial state")?;
        for (source_position, source) in self.sources.iter().enumerate() {
            let source_index = dense_u32(source_position, "private source index")?;
            let state_index = sample_initial(
                &source.initial,
                replay,
                DirectArrivalRngProvider::PrivateMarkov,
                source_index,
                draw_meter,
            )?;
            let state_position = state_usize(state_index, source.gaps.len())?;
            let gap = source.gaps[state_position];
            let next_queue = sample_destination(
                &source.destinations,
                replay,
                DirectArrivalRngProvider::PrivateMarkov,
                source_index,
                0,
                state_index,
                draw_meter,
            )?;
            cursors.push(PrivateCursor {
                event_index: 0,
                state_index,
                next_slot: RuntimeCount::new(gap - 1),
                next_queue,
            });
        }
        let heap = EventHeap::try_new(self.sources.len(), |rank| {
            cursors.get(rank as usize).map(|cursor| cursor.next_slot)
        })?;
        Ok(PrivateState {
            binding,
            compiled_binding,
            replay,
            expected_slot: RuntimeCount::ZERO,
            cursors,
            heap,
        })
    }
}

impl PreparedSharedRounds {
    fn initial_state(
        &self,
        binding: PreparationBinding,
        compiled_binding: PreparationBinding,
        replay: ArrivalReplay,
        draw_meter: &mut RngWordMeter,
    ) -> Result<SharedState, ArrivalError> {
        let state_index = sample_initial(
            &self.initial,
            replay,
            DirectArrivalRngProvider::SharedRounds,
            u32::MAX,
            draw_meter,
        )?;
        let outcome = self.sample_round(replay, 0, state_index, draw_meter)?;
        if outcome.emissions.len() != self.source_count {
            return Err(ArrivalError::CorruptState {
                invariant: "shared outcome width equals source count",
            });
        }

        let mut clocks = try_vec(self.source_count, "shared initial clocks")?;
        let mut pending_by_source = try_vec(self.source_count, "shared pending sources")?;
        for emission in &outcome.emissions {
            let slot = RuntimeCount::new(emission.gap - 1);
            clocks.push(slot);
            let mut pending = VecDeque::new();
            pending
                .try_reserve(1)
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "shared initial overshoot",
                })?;
            pending.push_back(PendingEmission {
                round_index: 0,
                slot,
                queue: emission.queue,
            });
            pending_by_source.push(pending);
        }
        let heap = EventHeap::try_new(self.source_count, |rank| {
            pending_by_source
                .get(rank as usize)
                .and_then(|pending| pending.front())
                .map(|pending| pending.slot)
        })?;
        Ok(SharedState {
            binding,
            compiled_binding,
            replay,
            expected_slot: RuntimeCount::ZERO,
            next_round: 1,
            next_round_state: outcome.next_state,
            clocks,
            pending_by_source,
            heap,
        })
    }

    fn sample_round(
        &self,
        replay: ArrivalReplay,
        round_index: u64,
        state_index: u32,
        draw_meter: &mut RngWordMeter,
    ) -> Result<&PreparedSharedOutcome, ArrivalError> {
        let row_position = state_usize(state_index, self.rows.len())?;
        let row = &self.rows[row_position];
        let selected = draw_index(
            replay,
            DirectArrivalRngProvider::SharedRounds,
            u32::MAX,
            round_index,
            state_index,
            DirectArrivalDrawRole::JointRoundOutcome,
            0,
            &row.distribution,
            draw_meter,
        )?;
        row.outcomes
            .get(selected)
            .ok_or(ArrivalError::CorruptState {
                invariant: "shared outcome row index is in range",
            })
    }
}

fn prepare_marked_law(
    law: &MarkedRenewalLaw,
    queues: &QueueCatalog,
) -> Result<PreparedMarkedLaw, ArrivalError> {
    match law {
        MarkedRenewalLaw::JointPmf { outcomes } => {
            if outcomes.is_empty() {
                return Err(ArrivalError::InvalidDefinition {
                    field: "joint marked PMF",
                });
            }
            let mut prepared = try_vec(outcomes.len(), "joint marked outcomes")?;
            let mut probabilities = try_vec(outcomes.len(), "joint marked probabilities")?;
            for (position, outcome) in outcomes.iter().enumerate() {
                let gap = positive_u64(&outcome.d, "joint marked gap")?;
                let queue = resolve_queue(queues, &outcome.queue_id)?;
                if outcomes[..position]
                    .iter()
                    .any(|earlier| earlier.d == outcome.d && earlier.queue_id == outcome.queue_id)
                {
                    return Err(ArrivalError::DuplicateCoordinate {
                        field: "joint gap/queue outcome",
                    });
                }
                prepared.push(PreparedJointOutcome { gap, queue });
                probabilities.push(&outcome.probability);
            }
            Ok(PreparedMarkedLaw::Joint {
                distribution: prepare_distribution(&probabilities)?,
                outcomes: prepared,
            })
        }
        MarkedRenewalLaw::Factorized {
            interarrival,
            destination_pmf,
        } => Ok(PreparedMarkedLaw::Factorized {
            gap: prepare_gap_law(interarrival)?,
            destinations: prepare_destination_row(destination_pmf, queues)?,
        }),
    }
}

fn prepare_gap_law(law: &GapLaw) -> Result<PreparedGapLaw, ArrivalError> {
    match law {
        GapLaw::Deterministic { d } => Ok(PreparedGapLaw::Deterministic(positive_u64(
            d,
            "deterministic renewal gap",
        )?)),
        GapLaw::FinitePmf { outcomes } => {
            if outcomes.is_empty() {
                return Err(ArrivalError::InvalidDefinition {
                    field: "finite gap PMF",
                });
            }
            let mut gaps = try_vec(outcomes.len(), "finite gap outcomes")?;
            let mut probabilities = try_vec(outcomes.len(), "finite gap probabilities")?;
            for (position, outcome) in outcomes.iter().enumerate() {
                let gap = positive_u64(&outcome.d, "finite renewal gap")?;
                if outcomes[..position]
                    .iter()
                    .any(|earlier| earlier.d == outcome.d)
                {
                    return Err(ArrivalError::DuplicateCoordinate {
                        field: "finite gap outcome",
                    });
                }
                gaps.push(gap);
                probabilities.push(&outcome.probability);
            }
            Ok(PreparedGapLaw::Finite {
                distribution: prepare_distribution(&probabilities)?,
                gaps,
            })
        }
        GapLaw::GeometricGrid { d_min, delta, p } => {
            let (success_numerator, success_denominator) = positive_probability_parts(p)?;
            Ok(PreparedGapLaw::GeometricGrid {
                d_min: positive_u64(d_min, "geometric minimum gap")?,
                delta: positive_u64(delta, "geometric grid step")?,
                success_numerator,
                success_denominator,
            })
        }
    }
}

fn prepare_destination_row(
    pmf: &[QueueProbability],
    queues: &QueueCatalog,
) -> Result<PreparedDestinationRow, ArrivalError> {
    if pmf.is_empty() {
        return Err(ArrivalError::InvalidDefinition {
            field: "destination PMF",
        });
    }
    let mut resolved = try_vec(pmf.len(), "destination outcomes")?;
    let mut probabilities = try_vec(pmf.len(), "destination probabilities")?;
    for (position, row) in pmf.iter().enumerate() {
        if pmf[..position]
            .iter()
            .any(|earlier| earlier.queue_id == row.queue_id)
        {
            return Err(ArrivalError::DuplicateCoordinate {
                field: "destination queue",
            });
        }
        resolved.push(resolve_queue(queues, &row.queue_id)?);
        probabilities.push(&row.probability);
    }
    Ok(PreparedDestinationRow {
        distribution: prepare_distribution(&probabilities)?,
        queues: resolved,
    })
}

fn prepare_private_source(
    source: &PrivateMarkovSource,
    queues: &QueueCatalog,
) -> Result<PreparedPrivateSource, ArrivalError> {
    validate_states(&source.states)?;
    let state_count = source.states.len();
    let mut gaps: Vec<Option<u64>> = try_vec(state_count, "private state gaps")?;
    gaps.resize(state_count, None);
    for gap in &source.gaps {
        let state = find_state(&source.states, &gap.state)?;
        let position = state_usize(state, state_count)?;
        if gaps[position].is_some() {
            return Err(ArrivalError::DuplicateCoordinate {
                field: "private state gap",
            });
        }
        gaps[position] = Some(positive_u64(&gap.d, "private state gap")?);
    }
    let mut complete_gaps = try_vec(gaps.len(), "complete private state gaps")?;
    for gap in gaps {
        complete_gaps.push(gap.ok_or(ArrivalError::InvalidDefinition {
            field: "complete private state gaps",
        })?);
    }

    let initial = prepare_initial(&source.initial, &source.states)?;
    let transitions = prepare_transitions(&source.transitions, &source.states)?;
    let destinations = prepare_destination_row(&source.destination_pmf, queues)?;
    Ok(PreparedPrivateSource {
        gaps: complete_gaps,
        initial,
        transitions,
        destinations,
    })
}

fn prepare_transitions(
    authored: &[MarkovTransition],
    states: &[StateId],
) -> Result<Vec<PreparedTransitionRow>, ArrivalError> {
    let mut rows = try_vec(states.len(), "private transition rows")?;
    for state in states {
        let mut next_states = Vec::new();
        let mut probabilities = Vec::new();
        for (position, transition) in authored.iter().enumerate() {
            if &transition.state != state {
                continue;
            }
            if authored[..position].iter().any(|earlier| {
                earlier.state == transition.state && earlier.next_state == transition.next_state
            }) {
                return Err(ArrivalError::DuplicateCoordinate {
                    field: "private transition",
                });
            }
            next_states
                .try_reserve(1)
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "private transition outcomes",
                })?;
            probabilities
                .try_reserve(1)
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "private transition probabilities",
                })?;
            next_states.push(find_state(states, &transition.next_state)?);
            probabilities.push(&transition.probability);
        }
        if next_states.is_empty() {
            return Err(ArrivalError::InvalidDefinition {
                field: "complete private transition rows",
            });
        }
        rows.push(PreparedTransitionRow {
            distribution: prepare_distribution(&probabilities)?,
            next_states,
        });
    }
    for transition in authored {
        find_state(states, &transition.state)?;
    }
    Ok(rows)
}

fn prepare_shared(
    spec: &SharedJointRoundMarkovRenewal,
    queues: &QueueCatalog,
    binding: PreparationBinding,
) -> Result<PreparedSharedRounds, ArrivalError> {
    if spec.sources.is_empty() {
        return Err(ArrivalError::InvalidDefinition {
            field: "shared sources",
        });
    }
    validate_unique_sources(spec.sources.iter())?;
    validate_states(&spec.states)?;
    dense_u32(spec.sources.len() - 1, "shared source index")?;
    let initial = prepare_initial(&spec.initial, &spec.states)?;
    let mut rows = try_vec(spec.states.len(), "shared outcome rows")?;
    for state in &spec.states {
        let mut outcomes = Vec::new();
        let mut probabilities = Vec::new();
        for outcome in &spec.outcomes {
            if &outcome.state != state {
                continue;
            }
            let prepared = prepare_shared_outcome(outcome, &spec.sources, &spec.states, queues)?;
            if outcomes.contains(&prepared) {
                return Err(ArrivalError::DuplicateCoordinate {
                    field: "shared joint outcome",
                });
            }
            outcomes
                .try_reserve(1)
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "shared outcomes",
                })?;
            probabilities
                .try_reserve(1)
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "shared probabilities",
                })?;
            outcomes.push(prepared);
            probabilities.push(&outcome.probability);
        }
        if outcomes.is_empty() {
            return Err(ArrivalError::InvalidDefinition {
                field: "complete shared outcome rows",
            });
        }
        rows.push(PreparedSharedRow {
            distribution: prepare_distribution(&probabilities)?,
            outcomes,
        });
    }
    for outcome in &spec.outcomes {
        find_state(&spec.states, &outcome.state)?;
    }
    Ok(PreparedSharedRounds {
        binding,
        queue_count: queues.len(),
        source_count: spec.sources.len(),
        initial,
        rows,
    })
}

fn prepare_shared_outcome(
    outcome: &JointRoundOutcome,
    sources: &[SourceId],
    states: &[StateId],
    queues: &QueueCatalog,
) -> Result<PreparedSharedOutcome, ArrivalError> {
    let next_state = find_state(states, &outcome.next_state)?;
    if outcome.emissions.len() != sources.len() {
        return Err(ArrivalError::InvalidDefinition {
            field: "one shared emission per source",
        });
    }
    let mut emissions: Vec<Option<PreparedRoundEmission>> =
        try_vec(sources.len(), "shared emission row")?;
    emissions.resize(sources.len(), None);
    for emission in &outcome.emissions {
        let source = sources
            .iter()
            .position(|candidate| candidate == &emission.source_id)
            .ok_or(ArrivalError::UnknownReference {
                field: "shared emission source",
            })?;
        if emissions[source].is_some() {
            return Err(ArrivalError::DuplicateCoordinate {
                field: "shared emission source",
            });
        }
        emissions[source] = Some(PreparedRoundEmission {
            gap: positive_u64(&emission.d, "shared emission gap")?,
            queue: resolve_queue(queues, &emission.queue_id)?,
        });
    }
    let mut complete_emissions = try_vec(emissions.len(), "complete shared emission row")?;
    for emission in emissions {
        complete_emissions.push(emission.ok_or(ArrivalError::InvalidDefinition {
            field: "complete shared emission row",
        })?);
    }
    Ok(PreparedSharedOutcome {
        next_state,
        emissions: complete_emissions,
    })
}

fn prepare_initial(
    initial: &InitialStateLaw,
    states: &[StateId],
) -> Result<PreparedInitial, ArrivalError> {
    match initial {
        InitialStateLaw::State(state) => {
            Ok(PreparedInitial::Deterministic(find_state(states, state)?))
        }
        InitialStateLaw::Distribution(authored) => {
            if authored.len() != states.len() || authored.is_empty() {
                return Err(ArrivalError::InvalidDefinition {
                    field: "complete initial-state distribution",
                });
            }
            let mut state_indices = try_vec(authored.len(), "initial-state outcomes")?;
            let mut probabilities = try_vec(authored.len(), "initial-state probabilities")?;
            for (position, row) in authored.iter().enumerate() {
                if authored[..position]
                    .iter()
                    .any(|earlier| earlier.state == row.state)
                {
                    return Err(ArrivalError::DuplicateCoordinate {
                        field: "initial state",
                    });
                }
                state_indices.push(find_state(states, &row.state)?);
                probabilities.push(&row.probability);
            }
            for state in states {
                if !authored.iter().any(|row| &row.state == state) {
                    return Err(ArrivalError::InvalidDefinition {
                        field: "complete initial-state distribution",
                    });
                }
            }
            Ok(PreparedInitial::Distribution {
                distribution: prepare_distribution(&probabilities)?,
                states: state_indices,
            })
        }
    }
}

fn sample_initial(
    initial: &PreparedInitial,
    replay: ArrivalReplay,
    provider: DirectArrivalRngProvider,
    source_index: u32,
    draw_meter: &mut RngWordMeter,
) -> Result<u32, ArrivalError> {
    match initial {
        PreparedInitial::Deterministic(state) => Ok(*state),
        PreparedInitial::Distribution {
            distribution,
            states,
        } => {
            let selected = draw_index(
                replay,
                provider,
                source_index,
                0,
                0,
                DirectArrivalDrawRole::InitialState,
                0,
                distribution,
                draw_meter,
            )?;
            states
                .get(selected)
                .copied()
                .ok_or(ArrivalError::CorruptState {
                    invariant: "initial-state row index is in range",
                })
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn sample_gap(
    gap: &PreparedGapLaw,
    replay: ArrivalReplay,
    provider: DirectArrivalRngProvider,
    source_index: u32,
    event_index: u64,
    state_index: u32,
    role: DirectArrivalDrawRole,
    draw_meter: &mut RngWordMeter,
) -> Result<u64, ArrivalError> {
    match gap {
        PreparedGapLaw::Deterministic(value) => Ok(*value),
        PreparedGapLaw::Finite { distribution, gaps } => {
            let selected = draw_index(
                replay,
                provider,
                source_index,
                event_index,
                state_index,
                role,
                0,
                distribution,
                draw_meter,
            )?;
            gaps.get(selected)
                .copied()
                .ok_or(ArrivalError::CorruptState {
                    invariant: "finite-gap row index is in range",
                })
        }
        PreparedGapLaw::GeometricGrid {
            d_min,
            delta,
            success_numerator,
            success_denominator,
        } => {
            let maximum_failures = (u64::MAX - *d_min) / *delta;
            for failures in 0..=maximum_failures {
                let address = replay.address(
                    provider,
                    source_index,
                    event_index,
                    state_index,
                    DirectArrivalDrawRole::GeometricTrial,
                    failures,
                );
                let success = sample_bernoulli_counted(
                    &replay.seed,
                    address,
                    *success_numerator,
                    *success_denominator,
                    draw_meter,
                )
                .map_err(map_counted_random)?;
                if success {
                    let increment =
                        delta
                            .checked_mul(failures)
                            .ok_or(ArrivalError::ArithmeticOverflow {
                                operation: "geometric gap product",
                            })?;
                    return d_min
                        .checked_add(increment)
                        .ok_or(ArrivalError::ArithmeticOverflow {
                            operation: "geometric gap sum",
                        });
                }
            }
            Err(ArrivalError::GeometricBoundRefused)
        }
    }
}

fn sample_destination(
    row: &PreparedDestinationRow,
    replay: ArrivalReplay,
    provider: DirectArrivalRngProvider,
    source_index: u32,
    event_index: u64,
    state_index: u32,
    draw_meter: &mut RngWordMeter,
) -> Result<QueueIndex, ArrivalError> {
    let selected = draw_index(
        replay,
        provider,
        source_index,
        event_index,
        state_index,
        DirectArrivalDrawRole::Destination,
        0,
        &row.distribution,
        draw_meter,
    )?;
    row.queues
        .get(selected)
        .copied()
        .ok_or(ArrivalError::CorruptState {
            invariant: "destination row index is in range",
        })
}

#[allow(clippy::too_many_arguments)]
fn draw_index(
    replay: ArrivalReplay,
    provider: DirectArrivalRngProvider,
    source_index: u32,
    event_or_round_index: u64,
    state_or_row_index: u32,
    role: DirectArrivalDrawRole,
    draw_subindex: u64,
    distribution: &PreparedCategorical<u32>,
    draw_meter: &mut RngWordMeter,
) -> Result<usize, ArrivalError> {
    let address = replay.address(
        provider,
        source_index,
        event_or_round_index,
        state_or_row_index,
        role,
        draw_subindex,
    );
    let selected = sample_categorical_counted(&replay.seed, address, distribution, draw_meter)
        .map_err(map_counted_random)?;
    usize::try_from(selected).map_err(|_error| ArrivalError::RepresentationBound {
        field: "categorical row index",
    })
}

fn map_word_grant(error: RngWordGrantExceeded) -> ArrivalError {
    ArrivalError::ConfiguredGeneratorDrawGrantExceeded {
        maximum: error.maximum_words,
        consumed: error.consumed_words,
        requested: error.requested_words,
    }
}

fn map_counted_random(error: CountedRandomError) -> ArrivalError {
    match error {
        CountedRandomError::Random(_error) => ArrivalError::RandomDrawRefused,
        CountedRandomError::Grant(error) => map_word_grant(error),
    }
}

fn prepare_distribution(
    probabilities: &[&ExactRational],
) -> Result<PreparedCategorical<u32>, ArrivalError> {
    if probabilities.is_empty() {
        return Err(ArrivalError::InvalidDefinition {
            field: "probability row",
        });
    }
    let last = probabilities
        .len()
        .checked_sub(1)
        .ok_or(ArrivalError::InvalidDefinition {
            field: "probability row",
        })?;
    dense_u32(last, "probability row count")?;

    let mut parts = try_vec(probabilities.len(), "exact probability parts")?;
    let mut common_denominator = 1_u128;
    for probability in probabilities {
        let (numerator, denominator) = probability_parts(probability)?;
        common_denominator = checked_lcm(common_denominator, denominator)?;
        parts.push((numerator, denominator));
    }

    let mut masses = try_vec(parts.len(), "primitive probability masses")?;
    for (numerator, denominator) in parts {
        let scale = common_denominator / denominator;
        masses.push(
            numerator
                .checked_mul(scale)
                .ok_or(ArrivalError::ArithmeticOverflow {
                    operation: "probability common-denominator scaling",
                })?,
        );
    }
    let sum = masses.iter().try_fold(0_u128, |sum, mass| {
        sum.checked_add(*mass)
            .ok_or(ArrivalError::ArithmeticOverflow {
                operation: "probability mass sum",
            })
    })?;
    if sum != common_denominator {
        return Err(ArrivalError::InvalidDefinition {
            field: "probability row sums exactly to one",
        });
    }
    let divisor = masses.iter().copied().fold(0, gcd);
    if divisor == 0 {
        return Err(ArrivalError::InvalidDefinition {
            field: "positive probability mass",
        });
    }
    for mass in &mut masses {
        *mass /= divisor;
    }
    let mut outcomes = try_vec(probabilities.len(), "categorical row indices")?;
    for index in 0..probabilities.len() {
        outcomes.push(dense_u32(index, "probability row index")?);
    }
    PreparedCategorical::try_from_ordered_integer_masses(outcomes, masses).ok_or(
        ArrivalError::ResourceExhausted {
            operation: "sealed exact categorical",
        },
    )
}

fn probability_parts(probability: &ExactRational) -> Result<(u128, u128), ArrivalError> {
    let numerator =
        probability
            .numerator()
            .as_bigint()
            .to_u128()
            .ok_or(ArrivalError::InvalidDefinition {
                field: "nonnegative representable probability numerator",
            })?;
    let denominator = probability.denominator().as_biguint().to_u128().ok_or(
        ArrivalError::RepresentationBound {
            field: "probability denominator",
        },
    )?;
    if denominator == 0 || numerator > denominator {
        return Err(ArrivalError::InvalidDefinition {
            field: "probability in [0,1]",
        });
    }
    Ok((numerator, denominator))
}

fn positive_probability_parts(probability: &ExactRational) -> Result<(u128, u128), ArrivalError> {
    let (numerator, denominator) = probability_parts(probability)?;
    if numerator == 0 {
        return Err(ArrivalError::InvalidDefinition {
            field: "geometric p in (0,1]",
        });
    }
    Ok((numerator, denominator))
}

fn checked_lcm(left: u128, right: u128) -> Result<u128, ArrivalError> {
    let divisor = gcd(left, right);
    left.checked_div(divisor)
        .and_then(|reduced| reduced.checked_mul(right))
        .ok_or(ArrivalError::ArithmeticOverflow {
            operation: "probability denominator LCM",
        })
}

const fn gcd(mut left: u128, mut right: u128) -> u128 {
    while right != 0 {
        let remainder = left % right;
        left = right;
        right = remainder;
    }
    left
}

#[cfg(any(test, feature = "qualification-test-support"))]
fn validate_renewal_cursors(
    cursors: &[RenewalCursor],
    expected_sources: usize,
    queue_count: usize,
    slot: RuntimeCount,
) -> Result<(), ArrivalError> {
    if cursors.len() != expected_sources {
        return Err(ArrivalError::CorruptState {
            invariant: "marked cursor width equals source count",
        });
    }
    for cursor in cursors {
        if cursor.next_slot < slot {
            return Err(ArrivalError::CorruptState {
                invariant: "marked next clock is not stale",
            });
        }
        validate_queue(cursor.next_queue, queue_count)?;
    }
    Ok(())
}

#[cfg(any(test, feature = "qualification-test-support"))]
fn validate_private_cursors(
    state: &PrivateState,
    prepared: &PreparedPrivateMarkov,
    slot: RuntimeCount,
) -> Result<(), ArrivalError> {
    if state.cursors.len() != prepared.sources.len() {
        return Err(ArrivalError::CorruptState {
            invariant: "private cursor width equals source count",
        });
    }
    for (cursor, source) in state.cursors.iter().zip(&prepared.sources) {
        if cursor.next_slot < slot {
            return Err(ArrivalError::CorruptState {
                invariant: "private next clock is not stale",
            });
        }
        state_usize(cursor.state_index, source.gaps.len())?;
        validate_queue(cursor.next_queue, prepared.queue_count)?;
    }
    Ok(())
}

#[cfg(any(test, feature = "qualification-test-support"))]
fn validate_shared_state(
    prepared: &PreparedSharedRounds,
    state: &SharedState,
    slot: RuntimeCount,
) -> Result<(), ArrivalError> {
    if state.clocks.len() != prepared.source_count
        || state.pending_by_source.len() != prepared.source_count
    {
        return Err(ArrivalError::CorruptState {
            invariant: "shared state width equals source count",
        });
    }
    state_usize(state.next_round_state, prepared.rows.len())?;
    if state.next_round == 0 {
        return Err(ArrivalError::CorruptState {
            invariant: "shared state has sampled round zero",
        });
    }
    for (source_position, pending) in state.pending_by_source.iter().enumerate() {
        if pending.is_empty() {
            return Err(ArrivalError::CorruptState {
                invariant: "shared source retains a pending overshoot",
            });
        }
        let mut previous: Option<PendingEmission> = None;
        for emission in pending {
            validate_queue(emission.queue, prepared.queue_count)?;
            if emission.slot < slot {
                return Err(ArrivalError::CorruptState {
                    invariant: "shared pending clock is not stale",
                });
            }
            if let Some(earlier) = previous {
                if earlier.round_index.checked_add(1) != Some(emission.round_index)
                    || emission.slot <= earlier.slot
                {
                    return Err(ArrivalError::CorruptState {
                        invariant: "shared overshoots are ordered by round and clock",
                    });
                }
            }
            previous = Some(*emission);
        }
        let back = pending.back().ok_or(ArrivalError::CorruptState {
            invariant: "shared pending tail exists",
        })?;
        if back.round_index.checked_add(1) != Some(state.next_round)
            || state.clocks[source_position] != back.slot
        {
            return Err(ArrivalError::CorruptState {
                invariant: "shared tail agrees with round counter and clock",
            });
        }
    }
    Ok(())
}

fn try_vec<T>(capacity: usize, operation: &'static str) -> Result<Vec<T>, ArrivalError> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(capacity)
        .map_err(|_error| ArrivalError::ResourceExhausted { operation })?;
    Ok(values)
}

fn validate_batch_width(arrivals: &[Arrival], queue_count: usize) -> Result<(), ArrivalError> {
    let mut previous = None;
    for arrival in arrivals {
        validate_queue(arrival.queue(), queue_count)?;
        if arrival.count() == RuntimeCount::ZERO || arrival.count().get() > MAX_ARRIVAL_COUNT {
            return Err(ArrivalError::CorruptState {
                invariant: "prepared arrival counts are positive",
            });
        }
        if previous.is_some_and(|queue: QueueIndex| queue >= arrival.queue()) {
            return Err(ArrivalError::CorruptState {
                invariant: "prepared arrival rows are unique and dense ordered",
            });
        }
        previous = Some(arrival.queue());
    }
    Ok(())
}

fn validate_queue(queue: QueueIndex, queue_count: usize) -> Result<usize, ArrivalError> {
    let position = usize::try_from(queue.0).map_err(|_error| ArrivalError::CorruptState {
        invariant: "queue index is representable",
    })?;
    if position >= queue_count {
        return Err(ArrivalError::CorruptState {
            invariant: "queue index is in range",
        });
    }
    Ok(position)
}

fn resolve_queue(queues: &QueueCatalog, id: &TypedId) -> Result<QueueIndex, ArrivalError> {
    queues.index_of(id).ok_or(ArrivalError::UnknownQueue)
}

fn validate_unique_sources<'a>(
    sources: impl Iterator<Item = &'a SourceId>,
) -> Result<(), ArrivalError> {
    let mut collected = Vec::new();
    for source in sources {
        if source.as_str().is_empty() || !is_normalized_active_token(source.as_str())? {
            return Err(ArrivalError::InvalidDefinition {
                field: "normalized source ID",
            });
        }
        if collected.contains(&source) {
            return Err(ArrivalError::DuplicateCoordinate { field: "source ID" });
        }
        collected
            .try_reserve(1)
            .map_err(|_error| ArrivalError::ResourceExhausted {
                operation: "source uniqueness validation",
            })?;
        collected.push(source);
    }
    Ok(())
}

fn is_normalized_active_token(authored: &str) -> Result<bool, ArrivalError> {
    let mut normalized = String::new();
    normalized
        .try_reserve(authored.len())
        .map_err(|_error| ArrivalError::ResourceExhausted {
            operation: "active-token normalization",
        })?;
    let mut separator_pending = false;
    for character in authored.trim().chars().flat_map(char::to_lowercase) {
        if matches!(character, '-' | ' ' | '_') {
            if !normalized.is_empty() {
                separator_pending = true;
            }
        } else {
            if separator_pending {
                normalized
                    .try_reserve(1)
                    .map_err(|_error| ArrivalError::ResourceExhausted {
                        operation: "active-token normalization",
                    })?;
                normalized.push('_');
                separator_pending = false;
            }
            normalized
                .try_reserve(character.len_utf8())
                .map_err(|_error| ArrivalError::ResourceExhausted {
                    operation: "active-token normalization",
                })?;
            normalized.push(character);
        }
    }
    Ok(normalized == authored)
}

fn validate_states(states: &[StateId]) -> Result<(), ArrivalError> {
    if states.is_empty() {
        return Err(ArrivalError::InvalidDefinition { field: "states" });
    }
    dense_u32(states.len() - 1, "state index")?;
    for (position, state) in states.iter().enumerate() {
        if state.as_str().is_empty() || !is_normalized_active_token(state.as_str())? {
            return Err(ArrivalError::InvalidDefinition {
                field: "normalized state ID",
            });
        }
        if states[..position].contains(state) {
            return Err(ArrivalError::DuplicateCoordinate { field: "state ID" });
        }
    }
    Ok(())
}

fn find_state(states: &[StateId], state: &StateId) -> Result<u32, ArrivalError> {
    let position = states
        .iter()
        .position(|candidate| candidate == state)
        .ok_or(ArrivalError::UnknownReference { field: "state" })?;
    dense_u32(position, "state index")
}

fn state_usize(state: u32, state_count: usize) -> Result<usize, ArrivalError> {
    let position = usize::try_from(state).map_err(|_error| ArrivalError::CorruptState {
        invariant: "state index is representable",
    })?;
    if position >= state_count {
        return Err(ArrivalError::CorruptState {
            invariant: "state index is in range",
        });
    }
    Ok(position)
}

fn dense_u32(value: usize, field: &'static str) -> Result<u32, ArrivalError> {
    let converted =
        u32::try_from(value).map_err(|_error| ArrivalError::RepresentationBound { field })?;
    if converted == u32::MAX {
        return Err(ArrivalError::RepresentationBound { field });
    }
    Ok(converted)
}

fn positive_u64(value: &ExactUnsigned, field: &'static str) -> Result<u64, ArrivalError> {
    let converted = bounded_u64(value, field)?;
    if converted == 0 {
        return Err(ArrivalError::InvalidDefinition { field });
    }
    Ok(converted)
}

fn bounded_u64(value: &ExactUnsigned, field: &'static str) -> Result<u64, ArrivalError> {
    value
        .as_biguint()
        .to_u64()
        .ok_or(ArrivalError::RepresentationBound { field })
}

fn checked_clock_add(clock: RuntimeCount, gap: u64) -> Result<RuntimeCount, ArrivalError> {
    clock
        .get()
        .checked_add(gap)
        .map(RuntimeCount::new)
        .ok_or(ArrivalError::ArithmeticOverflow {
            operation: "renewal clock addition",
        })
}

fn check_slot(expected: RuntimeCount, actual: RuntimeCount) -> Result<(), ArrivalError> {
    if expected != actual {
        return Err(ArrivalError::SlotMismatch { expected, actual });
    }
    Ok(())
}

fn check_binding(
    prepared: PreparationBinding,
    compiled: PreparationBinding,
    session: PreparationBinding,
    replay: ArrivalReplay,
) -> Result<(), ArrivalError> {
    if prepared != compiled || session != session_binding(compiled, replay) {
        return Err(ArrivalError::CorruptState {
            invariant: "state belongs to this exact prepared definition and replay",
        });
    }
    Ok(())
}

fn checked_arrival_sum(left: u64, right: u64, queue: QueueIndex) -> Result<u64, ArrivalError> {
    let sum = left
        .checked_add(right)
        .ok_or(ArrivalError::ArrivalAggregateOverflow { queue })?;
    if sum > MAX_ARRIVAL_COUNT {
        return Err(ArrivalError::ArrivalAggregateOverflow { queue });
    }
    Ok(sum)
}

fn preparation_binding(definition: &ResolvedArrival, queues: &QueueCatalog) -> PreparationBinding {
    let mut hasher = BindingHasher::new();
    definition.hash(&mut hasher);
    queues.ids().hash(&mut hasher);
    hasher.finalize()
}

fn session_binding(compiled: PreparationBinding, replay: ArrivalReplay) -> PreparationBinding {
    let mut hasher = BindingHasher::new();
    compiled.hash(&mut hasher);
    replay.hash(&mut hasher);
    hasher.finalize()
}

struct BindingHasher {
    inner: blake3::Hasher,
}

impl BindingHasher {
    fn new() -> Self {
        let mut inner = blake3::Hasher::new();
        inner.update(b"FORBIT-ARRIVAL-BINDING-V1");
        Self { inner }
    }

    fn tagged_write(&mut self, tag: u8, bytes: &[u8]) {
        let length = match u64::try_from(bytes.len()) {
            Ok(value) => value,
            Err(_error) => u64::MAX,
        };
        self.inner.update(&[tag]);
        self.inner.update(&length.to_le_bytes());
        self.inner.update(bytes);
    }

    fn finalize(self) -> PreparationBinding {
        *self.inner.finalize().as_bytes()
    }
}

impl Hasher for BindingHasher {
    fn finish(&self) -> u64 {
        let digest = self.inner.finalize();
        let mut digest_head = [0_u8; 8];
        digest_head.copy_from_slice(&digest.as_bytes()[..8]);
        u64::from_le_bytes(digest_head)
    }

    fn write(&mut self, bytes: &[u8]) {
        self.tagged_write(0, bytes);
    }

    fn write_u8(&mut self, value: u8) {
        self.tagged_write(1, &[value]);
    }

    fn write_u16(&mut self, value: u16) {
        self.tagged_write(2, &value.to_le_bytes());
    }

    fn write_u32(&mut self, value: u32) {
        self.tagged_write(3, &value.to_le_bytes());
    }

    fn write_u64(&mut self, value: u64) {
        self.tagged_write(4, &value.to_le_bytes());
    }

    fn write_u128(&mut self, value: u128) {
        self.tagged_write(5, &value.to_le_bytes());
    }

    fn write_usize(&mut self, value: usize) {
        let converted = match u64::try_from(value) {
            Ok(value) => value,
            Err(_error) => u64::MAX,
        };
        self.write_u64(converted);
    }

    fn write_i8(&mut self, value: i8) {
        self.tagged_write(6, &value.to_le_bytes());
    }

    fn write_i16(&mut self, value: i16) {
        self.tagged_write(7, &value.to_le_bytes());
    }

    fn write_i32(&mut self, value: i32) {
        self.tagged_write(8, &value.to_le_bytes());
    }

    fn write_i64(&mut self, value: i64) {
        self.tagged_write(9, &value.to_le_bytes());
    }

    fn write_i128(&mut self, value: i128) {
        self.tagged_write(10, &value.to_le_bytes());
    }

    fn write_isize(&mut self, value: isize) {
        let converted = match i64::try_from(value) {
            Ok(value) => value,
            Err(_error) if value.is_negative() => i64::MIN,
            Err(_error) => i64::MAX,
        };
        self.write_i64(converted);
    }
}

fn next_expected(slot: RuntimeCount) -> Result<RuntimeCount, ArrivalError> {
    slot.get()
        .checked_add(1)
        .map(RuntimeCount::new)
        .ok_or(ArrivalError::ArithmeticOverflow {
            operation: "provider expected-slot increment",
        })
}

#[cfg(test)]
#[path = "direct_count_arrivals/fofs_cp05_provider_oracles.rs"]
mod fofs_cp05_provider_oracles;

#[cfg(test)]
#[path = "direct_count_arrivals/fofs_cp02_tests.rs"]
mod fofs_cp02_tests;
