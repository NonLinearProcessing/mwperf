//! JSON-free mathematical core for the Full Orbit Framework Sampler.
//!
//! The active graph is the canonical resolved DTO, six exogenous count
//! providers, the unit-count carrier, five exact occupancy-MaxWeight kernels,
//! one atomic streaming physical-orbit engine, one fixed target-response
//! ledger, and sampler-native weighted-ensemble execution and estimation.
//! Input syntax belongs to `orbit-json`.

#![cfg_attr(not(test), forbid(unsafe_code))]
// These style-level allowances preserve the audited mathematical ABI and its
// owned-value stage boundaries. Warnings and Clippy correctness lints remain
// denied by the workspace policy and verification command.
#![allow(
    clippy::doc_markdown,
    clippy::large_types_passed_by_value,
    clippy::missing_errors_doc,
    clippy::module_name_repetitions,
    clippy::must_use_candidate,
    clippy::needless_pass_by_value,
    clippy::no_effect_underscore_binding,
    clippy::struct_field_names,
    clippy::too_many_lines,
    clippy::unnecessary_wraps,
    clippy::used_underscore_binding
)]

mod bounds;
pub mod construction_observation;
pub mod direct_count_arrivals;
mod engine;
pub mod error;
pub mod estimator;
pub mod exact;
pub mod finite_window_interval;
pub mod gap_probe;
pub mod lineage_iid;
mod maxweight;
mod observation_sha256;
pub mod occupancy_maxweight;
pub mod paired_ordinary;
pub mod resolved;
mod response_observer;
mod rng;
pub mod unit_count;
pub mod weighted_ensemble;
pub mod weighted_ensemble_coordinator;
pub mod weighted_ensemble_estimator;
pub mod weighted_ensemble_runner;
pub mod weighted_iid_arrivals;

#[cfg(test)]
mod cp07_conformance_tests;
#[cfg(test)]
mod weighted_ensemble_qualification_tests;

#[cfg(feature = "qualification-test-support")]
pub use engine::qualification;
pub use engine::{
    ConstructionWorkCounters, ConstructionWorkLimits, CountRunResult, MutableMemoryAccounting,
    OptimizerSearchStateGrant, OrdinaryGapProbeV1, PreparedCountProblem, PreparedCountRun,
    PreparedOrdinaryObservationSink, ProviderEndpointIdentity, TargetWindowReconciliation,
};
pub use construction_observation::{
    BoundaryBacklogLawV1, BoundaryBacklogMassV1, ConstructionObservationBlockV1,
    ConstructionObservationBundleV1, ConstructionObservationError,
    ConstructionObservationReplicationV1, EnclosedBinary64V1, ExactLevelObservationV1,
    ExactTargetArrivalAtomV1, ExactTargetArrivalMarginalV1, GapObservationValueV1, GapSignV1,
    ObservationArrivalBindingV1, ObservationCapabilitiesV1, ObservationCapabilityStateV1,
    ObservationCompletenessV1, ObservationDigestV1, ObservationInitializationV1,
    ObservationGapCellV1, ObservationMassBalanceV1, ObservationNormalizationClaimV1,
    ObservationPlanV1, ObservationRngBindingV1, ObservationScalarRepresentationV1,
    ObservationScalarV1, ObservationScientificBindingsV1, ObservationSlotConventionV1,
    ObservationSlotStageV1, ObservationSourceRoleV1, ObservationTargetBindingV1,
    ObservationWorkCountersV1, TargetArrivalDescriptionV1, TargetArrivalOvershootDescriptorV1,
};
pub use observation_sha256::observation_domain_digest_v1;
pub use estimator::{
    aggregate_observed_replications, aggregate_observed_replications_prepared,
    aggregate_replications, AggregatePrimitiveCounts,
    BuiltEstimate, ConstructionEstimate, ConstructionWorkTotals, EstimatorInvocationError,
    FailedEstimate, FailureEndpointEvidence, NominalThreeBinResponse,
    ObservedConstructionEstimate, ObservedReplicationReport, PreparedObservedAggregationV1,
    ProviderFailureReason,
    ReplicationCoordinate, ReplicationEvidence, ReplicationFailureEvidence, ReplicationReport,
    ScientificGrantPartition, ScientificGrantReservation, UnavailableEstimate,
};
pub use gap_probe::{
    GapObservation, GapProbeError, GapProbePreparation, GapProbeUnavailableReasonV1, GapSign,
    PreparedGapProbe,
};
pub use paired_ordinary::{
    PairedFanInArmV1, PairedFanInBoundaryStateV1, PairedFanInFailureV1,
    PairedFanInGapTotalsV1, PairedFanInLevelRowV1, PairedFanInOutcomeV1,
    PairedFanInRecordV1, PairedFanInWorkV1, PreparedPairedFanInRunV1,
    PreparedPairedFanInExecutionV1, PreparedPairedProjectionArenaV1,
    PAIRED_FAN_IN_QUEUE_COUNT_V1,
};
pub use response_observer::ResponseLedger;
pub use unit_count::QueueIndex;
pub use weighted_ensemble_estimator::{
    WeightedBuiltEstimate, WeightedConcentrationRadius, WeightedEnsembleEstimate,
    WeightedEstimateCommon, WeightedEstimatorError, WeightedFinitePrefixBuiltV1,
    WeightedFinitePrefixCommonV1, WeightedFinitePrefixEstimateV1,
    WeightedFinitePrefixMassesV1, WeightedFinitePrefixResponseV1,
    WeightedFinitePrefixUnavailableV1, WeightedK2Masses, WeightedLevelMassV1,
    WeightedLevelResponseV1, WeightedRatioInterval, WeightedRegionMass,
    WeightedResponseCoefficient, WeightedResponseCutoffV1, WeightedResponseCutoffV2,
    WeightedTailMassV1,
    WeightedTailResponseV1, WeightedThreeBinResponse, WeightedUnavailableEstimate,
    MAX_WEIGHTED_RESPONSE_CUTOFF_V1, MIN_WEIGHTED_RESPONSE_CUTOFF_V1,
};
pub use weighted_ensemble_coordinator::{
    EnsembleAttemptFailureV1, EnsembleAttemptOutcomeV1, PreparedWeightedEnsembleRawRun,
    PreparedWeightedEnsembleRun,
    WeightedEnsembleRunResult, WeightedFinitePrefixLegacyStatusV2,
    WeightedFinitePrefixRunOutcomeV2, WeightedFinitePrefixRunResultV1,
    WeightedObservationIdentityV1, WeightedRawObservationRunOutcomeV1,
};
pub use weighted_iid_arrivals::{
    correctly_rounded_poisson_rate_bits_v1, PoissonModulationScopeV1, PreparedWeightedArrivalLawV1,
    PreparedWeightedArrivalV1, PreparedWeightedTargetArrivalV1,
    QualifiedIidCountOutcomeV1, QualifiedIidCountV1,
    QualifiedPoissonModulationStateV1, QualifiedWeightedArrivalV1,
    WeightedArrivalErrorV1, WeightedArrivalFamilyV1, WeightedArrivalScratchV1,
    WeightedArrivalSampleWorkV1, WeightedFiniteTargetArrivalV1, WeightedPoissonTargetArrivalV1,
    WeightedTargetArrivalAtomV1, IID_COUNT_TABLE_FAMILY_ID_V1,
    IID_COUNT_TABLE_PORTABLE_SCHEMA_V1, IID_INDEPENDENT_BERNOULLI_FAMILY_ID_V1,
    IID_INDEPENDENT_BERNOULLI_PORTABLE_SCHEMA_V1,
    IID_INDEPENDENT_POISSON_FAMILY_ID_V1,
    IID_INDEPENDENT_POISSON_OVERSHOOT_DESCRIPTOR_V1,
    IID_INDEPENDENT_POISSON_PORTABLE_SCHEMA_V1, IID_MIXED_POISSON_FAMILY_ID_V1,
    IID_MIXED_POISSON_OVERSHOOT_DESCRIPTOR_V1,
    IID_MIXED_POISSON_PORTABLE_SCHEMA_V1, ADDRESSED_POISSON_SAMPLER_ID_V1,
    ADDRESSED_POISSON_SAMPLER_VERSION_V1, MAX_POISSON_UNIFORM_WORDS_PER_VARIATE_V1,
};
