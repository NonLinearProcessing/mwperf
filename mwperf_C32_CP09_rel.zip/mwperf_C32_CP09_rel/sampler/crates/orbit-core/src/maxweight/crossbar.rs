//! Exact crossbar MaxWeight compiler and runtime backend.
//!
//! The accepted family envelope is deterministic: nonzero endpoint sets and
//! `Q <= I * O`. Host-representability, checked dimension arithmetic, and
//! successful workspace allocation are the only implementation bounds. The
//! backend is cold, exact, and uses no retained dual state. Prepared priority
//! rank, never edge storage order, defines the fixed-bit lexicographic
//! refinement.

mod hungarian;

use std::mem::size_of;

use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};

use super::{
    bigint_logical_payload_bytes, CandidateAction, MaxWeightRequest, PreparedCrossbarEdge,
    PreparedServiceOptimizer,
};
use crate::bounds::{
    AllocationClass, BoundCertified, BoundContribution, BoundError, BoundProvenance, BoundStage,
    ContributorId, QuantityKey, ServiceContributor, WorkStackClass,
};
use crate::error::{PrepareError, RunError, RuntimeStage};
use crate::exact::{ExactUnsigned, RuntimeCount};

const BITS_PER_WORD: usize = 64;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct CrossbarSize {
    input_count: usize,
    output_count: usize,
    queue_count: usize,
    order: usize,
    cells: usize,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct ReservationFailed;

/// Instance-local injection seam for every production-owned workspace vector.
pub(crate) trait AllocationGate {
    fn reserve_exact<T>(
        &mut self,
        buffer: &'static str,
        vector: &mut Vec<T>,
        additional: usize,
    ) -> Result<(), ReservationFailed>;
}

#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct ProductionAllocationGate;

impl AllocationGate for ProductionAllocationGate {
    fn reserve_exact<T>(
        &mut self,
        _buffer: &'static str,
        vector: &mut Vec<T>,
        additional: usize,
    ) -> Result<(), ReservationFailed> {
        vector
            .try_reserve_exact(additional)
            .map_err(|_error| ReservationFailed)
    }
}

fn invalid_constraint(detail: impl Into<String>) -> PrepareError {
    PrepareError::InvalidConstraintInstance {
        path: "/selected_config/scheduler".to_owned(),
        detail: detail.into(),
    }
}

/// Size-only validation deliberately runs before endpoint/edge linker
/// allocations. Acceptance is determined only by the mathematical shape and
/// checked host-representable dimensions.
pub(crate) fn validate_declared_size(
    input_count: usize,
    output_count: usize,
    queue_count: usize,
) -> Result<CrossbarSize, PrepareError> {
    if input_count == 0 || output_count == 0 {
        return Err(invalid_constraint(
            "crossbar endpoint sets must each be nonempty",
        ));
    }
    if queue_count == 0 {
        return Err(invalid_constraint(
            "crossbar must contain at least one dense queue edge",
        ));
    }
    let order = input_count.checked_add(output_count).ok_or_else(|| {
        invalid_constraint("crossbar augmented order overflows the host representation")
    })?;
    let cells = input_count.checked_mul(output_count).ok_or_else(|| {
        invalid_constraint("crossbar endpoint-cell count overflows the host representation")
    })?;
    if queue_count > cells {
        return Err(invalid_constraint(
            "crossbar has more queues than distinct input/output endpoint pairs",
        ));
    }
    Ok(CrossbarSize {
        input_count,
        output_count,
        queue_count,
        order,
        cells,
    })
}

fn exact_usize(value: usize) -> ExactUnsigned {
    ExactUnsigned::from_biguint(BigUint::from(value))
}

fn bit_word_count(bit_count: usize) -> Result<usize, PrepareError> {
    (bit_count / BITS_PER_WORD)
        .checked_add(usize::from(bit_count % BITS_PER_WORD != 0))
        .ok_or_else(|| invalid_constraint("crossbar validation bitset width overflowed"))
}

fn checked_workspace_bounds(size: CrossbarSize) -> Result<(usize, usize), PrepareError> {
    let one_based = size.order.checked_add(1).ok_or_else(|| {
        invalid_constraint("crossbar Hungarian one-based workspace length overflowed")
    })?;
    let hungarian_elements = one_based.checked_mul(6).ok_or_else(|| {
        invalid_constraint("crossbar Hungarian workspace element bound overflowed")
    })?;
    let queue_words = bit_word_count(size.queue_count)?;
    let cell_words = bit_word_count(size.cells)?;
    let input_words = bit_word_count(size.input_count)?;
    let output_words = bit_word_count(size.output_count)?;
    let validation_elements = queue_words
        .checked_add(cell_words)
        .and_then(|value| value.checked_add(input_words))
        .and_then(|value| value.checked_add(output_words))
        .ok_or_else(|| invalid_constraint("crossbar validation workspace bound overflowed"))?;
    let elements = size
        .queue_count
        .checked_mul(3)
        .and_then(|queues| queues.checked_add(size.cells))
        .and_then(|partial| partial.checked_add(hungarian_elements))
        .and_then(|partial| partial.checked_add(validation_elements))
        .ok_or_else(|| invalid_constraint("crossbar workspace element bound overflowed"))?;

    let prepared_bytes = size
        .queue_count
        .checked_mul(size_of::<PreparedCrossbarEdge>());
    let cell_bytes = size.cells.checked_mul(size_of::<Option<usize>>());
    let composite_bytes = size.queue_count.checked_mul(size_of::<BigInt>());
    let selected_bytes = size.queue_count.checked_mul(size_of::<bool>());
    let validation_bytes = validation_elements.checked_mul(size_of::<u64>());
    let two_host_indices = size_of::<usize>()
        .checked_mul(2)
        .ok_or_else(|| invalid_constraint("crossbar workspace host-index stride overflowed"))?;
    let per_hungarian_slot = size_of::<BigInt>()
        .checked_mul(2)
        .and_then(|value| value.checked_add(two_host_indices))
        .and_then(|value| value.checked_add(size_of::<Option<BigInt>>()))
        .and_then(|value| value.checked_add(size_of::<bool>()))
        .ok_or_else(|| invalid_constraint("crossbar workspace byte stride overflowed"))?;
    let bytes = prepared_bytes
        .and_then(|value| cell_bytes.and_then(|next| value.checked_add(next)))
        .and_then(|value| composite_bytes.and_then(|next| value.checked_add(next)))
        .and_then(|value| selected_bytes.and_then(|next| value.checked_add(next)))
        .and_then(|value| validation_bytes.and_then(|next| value.checked_add(next)))
        .and_then(|value| {
            one_based
                .checked_mul(per_hungarian_slot)
                .and_then(|next| value.checked_add(next))
        })
        .ok_or_else(|| invalid_constraint("crossbar workspace byte bound overflowed"))?;
    Ok((elements, bytes))
}

fn bound_error(error: BoundError) -> PrepareError {
    PrepareError::InvalidNumericSpec {
        path: "/selected_config/scheduler".to_owned(),
        detail: error.to_string(),
    }
}

/// Compile validated crossbar topology into immutable tables and a certified
/// replication-local solver workspace bound.
pub(crate) fn compile_optimizer(
    input_count: u32,
    output_count: u32,
    edges: Vec<PreparedCrossbarEdge>,
) -> Result<BoundCertified<PreparedServiceOptimizer>, PrepareError> {
    let host_inputs = usize::try_from(input_count)
        .map_err(|_| invalid_constraint("crossbar input count is not host-representable"))?;
    let host_outputs = usize::try_from(output_count)
        .map_err(|_| invalid_constraint("crossbar output count is not host-representable"))?;
    let size = validate_declared_size(host_inputs, host_outputs, edges.len())?;
    validate_compile_edges(size, &edges)?;
    let mut cell_to_queue = Vec::new();
    cell_to_queue
        .try_reserve_exact(size.cells)
        .map_err(|_error| invalid_constraint("crossbar cell-map allocation failed"))?;
    cell_to_queue.resize(size.cells, None);
    for edge in &edges {
        let input = usize::try_from(edge.input_index)
            .map_err(|_error| invalid_constraint("crossbar input exceeds usize"))?;
        let output = usize::try_from(edge.output_index)
            .map_err(|_error| invalid_constraint("crossbar output exceeds usize"))?;
        let queue = usize::try_from(edge.queue.0)
            .map_err(|_error| invalid_constraint("crossbar queue exceeds usize"))?;
        cell_to_queue[input * size.output_count + output] = Some(queue);
    }
    let optimizer = PreparedServiceOptimizer::CrossbarHungarian {
        input_count: RuntimeCount::new(u64::from(input_count)),
        output_count: RuntimeCount::new(u64::from(output_count)),
        edges,
        cell_to_queue,
    };
    let (workspace_elements, workspace_bytes) = checked_workspace_bounds(size)?;
    let contributor = ContributorId::Service(ServiceContributor::CrossbarHungarian);
    let mut contribution = BoundContribution::new(contributor);
    for (quantity, upper, label) in [
        (
            QuantityKey::DenseQueueCount,
            size.queue_count,
            "crossbar dense queue count",
        ),
        (
            QuantityKey::DenseResourceCount,
            size.order,
            "crossbar input plus output resource count",
        ),
        (
            QuantityKey::AllocationElements(AllocationClass::ConstraintWorkspace),
            workspace_elements,
            "crossbar simultaneously-live structural workspace elements",
        ),
        (
            QuantityKey::AllocationBytes(AllocationClass::ConstraintWorkspace),
            workspace_bytes,
            "crossbar simultaneously-live structural workspace inline bytes",
        ),
        (
            QuantityKey::WorkStackDepth(WorkStackClass::ConstraintSolver),
            size.order,
            "crossbar Hungarian alternating-path depth",
        ),
    ] {
        contribution
            .insert(
                quantity,
                exact_usize(upper),
                BoundProvenance::new(
                    BoundStage::ConstraintCompilation,
                    "/selected_config/scheduler",
                    label,
                ),
            )
            .map_err(bound_error)?;
    }
    BoundCertified::new(optimizer, contribution).map_err(bound_error)
}

fn validate_compile_edges(
    size: CrossbarSize,
    edges: &[PreparedCrossbarEdge],
) -> Result<(), PrepareError> {
    let mut seen_queues = allocate_prepare_bitset(
        "crossbar compile queue validation",
        bit_word_count(size.queue_count)?,
    )?;
    let mut seen_cells = allocate_prepare_bitset(
        "crossbar compile endpoint-cell validation",
        bit_word_count(size.cells)?,
    )?;
    for (position, edge) in edges.iter().enumerate() {
        let queue = usize::try_from(edge.queue.0).map_err(|_| {
            invalid_constraint("crossbar QueueIndex is not representable as a host index")
        })?;
        if queue >= size.queue_count {
            return Err(invalid_constraint(format!(
                "crossbar edge {position} has a non-dense QueueIndex"
            )));
        }
        let input = usize::try_from(edge.input_index)
            .map_err(|_| invalid_constraint("crossbar input index is not host-representable"))?;
        let output = usize::try_from(edge.output_index)
            .map_err(|_| invalid_constraint("crossbar output index is not host-representable"))?;
        if input >= size.input_count || output >= size.output_count {
            return Err(invalid_constraint(format!(
                "crossbar edge {position} has an endpoint outside its namespace"
            )));
        }
        let cell = input * size.output_count + output;
        if !mark_new_bit(&mut seen_queues, queue) || !mark_new_bit(&mut seen_cells, cell) {
            return Err(invalid_constraint(format!(
                "crossbar edge {position} duplicates a queue or endpoint pair"
            )));
        }
    }
    Ok(())
}

fn allocate_prepare_bitset(
    buffer: &'static str,
    word_count: usize,
) -> Result<Vec<u64>, PrepareError> {
    let mut words = Vec::new();
    words
        .try_reserve_exact(word_count)
        .map_err(|_error| invalid_constraint(format!("{buffer} allocation failed")))?;
    words.resize(word_count, 0_u64);
    Ok(words)
}

fn runtime_contract(detail: impl Into<String>) -> RunError {
    RunError::OptimizerContractViolation {
        stage: RuntimeStage::ColdMaxWeightSolve,
        detail: detail.into(),
    }
}

fn runtime_size(
    input_count: RuntimeCount,
    output_count: RuntimeCount,
    queue_count: usize,
) -> Result<CrossbarSize, RunError> {
    let input_count = input_count
        .try_to_usize("crossbar input count")
        .map_err(|error| runtime_contract(error.to_string()))?;
    let output_count = output_count
        .try_to_usize("crossbar output count")
        .map_err(|error| runtime_contract(error.to_string()))?;
    validate_declared_size(input_count, output_count, queue_count)
        .map_err(|error| runtime_contract(error.to_string()))
}

fn validate_and_check_schedule(
    size: CrossbarSize,
    edges: &[PreparedCrossbarEdge],
    mut is_selected: impl FnMut(usize) -> bool,
    validation: &mut ValidationScratch,
) -> Result<bool, RunError> {
    validation.prepare(size)?;
    let mut feasible = true;
    for (position, edge) in edges.iter().enumerate() {
        let (queue, input, output) = runtime_edge_coordinates(size, position, edge)?;
        let cell = input * size.output_count + output;
        if !mark_new_bit(&mut validation.seen_queues, queue)
            || !mark_new_bit(&mut validation.seen_cells, cell)
        {
            return Err(runtime_contract(format!(
                "prepared crossbar edge {position} duplicates a queue or endpoint pair"
            )));
        }
        if is_selected(queue) {
            let input_was_free = mark_new_bit(&mut validation.used_inputs, input);
            let output_was_free = mark_new_bit(&mut validation.used_outputs, output);
            feasible &= input_was_free && output_was_free;
        }
    }
    Ok(feasible)
}

fn runtime_edge_coordinates(
    size: CrossbarSize,
    position: usize,
    edge: &PreparedCrossbarEdge,
) -> Result<(usize, usize, usize), RunError> {
    let queue = usize::try_from(edge.queue.0)
        .map_err(|_| runtime_contract("crossbar QueueIndex is not host-representable"))?;
    let input = usize::try_from(edge.input_index)
        .map_err(|_| runtime_contract("crossbar input index is not host-representable"))?;
    let output = usize::try_from(edge.output_index)
        .map_err(|_| runtime_contract("crossbar output index is not host-representable"))?;
    if queue >= size.queue_count || input >= size.input_count || output >= size.output_count {
        return Err(runtime_contract(format!(
            "prepared crossbar edge {position} is outside its dense coordinate space"
        )));
    }
    Ok((queue, input, output))
}

fn mark_new_bit(words: &mut [u64], index: usize) -> bool {
    let word = index / BITS_PER_WORD;
    let bit = 1_u64 << (index % BITS_PER_WORD);
    let was_clear = words[word] & bit == 0;
    words[word] |= bit;
    was_clear
}

pub(super) fn is_feasible(
    input_count: RuntimeCount,
    output_count: RuntimeCount,
    edges: &[PreparedCrossbarEdge],
    schedule: &[bool],
) -> Result<bool, RunError> {
    let size = runtime_size(input_count, output_count, edges.len())?;
    if schedule.len() != size.queue_count {
        return Err(RunError::OptimizerContractViolation {
            stage: RuntimeStage::ActionValidation,
            detail: "crossbar schedule must have exactly one bit per dense QueueIndex".to_owned(),
        });
    }
    let mut allocation = ProductionAllocationGate;
    let mut validation = ValidationScratch::try_new(size, &mut allocation)?;
    validate_and_check_schedule(size, edges, |queue| schedule[queue], &mut validation)
}

fn allocate_filled<T: Clone, A: AllocationGate>(
    allocation: &mut A,
    buffer: &'static str,
    length: usize,
    value: T,
) -> Result<Vec<T>, RunError> {
    let mut vector = Vec::new();
    allocation
        .reserve_exact(buffer, &mut vector, length)
        .map_err(|ReservationFailed| RunError::ResourceExhausted {
            stage: RuntimeStage::ColdMaxWeightSolve,
            detail: format!("crossbar workspace allocation failed for {buffer}"),
        })?;
    vector.resize(length, value);
    Ok(vector)
}

struct CrossbarProblem<'a> {
    size: CrossbarSize,
    cell_to_queue: &'a [Option<usize>],
    composite_weights: &'a [BigInt],
    eligible: &'a [bool],
}

#[derive(Debug, Eq, PartialEq)]
struct ValidationScratch {
    seen_queues: Vec<u64>,
    seen_cells: Vec<u64>,
    used_inputs: Vec<u64>,
    used_outputs: Vec<u64>,
}

impl ValidationScratch {
    fn try_new<A: AllocationGate>(
        size: CrossbarSize,
        allocation: &mut A,
    ) -> Result<Self, RunError> {
        let queue_words = runtime_bit_word_count(size.queue_count)?;
        let cell_words = runtime_bit_word_count(size.cells)?;
        let input_words = runtime_bit_word_count(size.input_count)?;
        let output_words = runtime_bit_word_count(size.output_count)?;
        Ok(Self {
            seen_queues: allocate_filled(
                allocation,
                "crossbar_validation_seen_queues",
                queue_words,
                0_u64,
            )?,
            seen_cells: allocate_filled(
                allocation,
                "crossbar_validation_seen_cells",
                cell_words,
                0_u64,
            )?,
            used_inputs: allocate_filled(
                allocation,
                "crossbar_validation_used_inputs",
                input_words,
                0_u64,
            )?,
            used_outputs: allocate_filled(
                allocation,
                "crossbar_validation_used_outputs",
                output_words,
                0_u64,
            )?,
        })
    }

    fn prepare(&mut self, size: CrossbarSize) -> Result<(), RunError> {
        if self.seen_queues.len() != runtime_bit_word_count(size.queue_count)?
            || self.seen_cells.len() != runtime_bit_word_count(size.cells)?
            || self.used_inputs.len() != runtime_bit_word_count(size.input_count)?
            || self.used_outputs.len() != runtime_bit_word_count(size.output_count)?
        {
            return Err(runtime_contract(
                "crossbar validation scratch has the wrong prepared dimensions",
            ));
        }
        self.seen_queues.fill(0);
        self.seen_cells.fill(0);
        self.used_inputs.fill(0);
        self.used_outputs.fill(0);
        Ok(())
    }

    fn mutable_bytes(&self) -> usize {
        [
            self.seen_queues.capacity(),
            self.seen_cells.capacity(),
            self.used_inputs.capacity(),
            self.used_outputs.capacity(),
        ]
        .into_iter()
        .fold(0_usize, |bytes, words| {
            bytes.saturating_add(words.saturating_mul(size_of::<u64>()))
        })
    }
}

fn runtime_bit_word_count(bit_count: usize) -> Result<usize, RunError> {
    (bit_count / BITS_PER_WORD)
        .checked_add(usize::from(bit_count % BITS_PER_WORD != 0))
        .ok_or_else(|| runtime_contract("crossbar validation bitset width overflowed"))
}

/// Per-replication structural workspace for the exact Hungarian family. The
/// immutable endpoint-cell lowering remains in the prepared optimizer.
#[derive(Debug, Eq, PartialEq)]
pub(crate) struct SolverScratch {
    queue_count: usize,
    selected_capacity: usize,
    selected: Option<Vec<bool>>,
    composite_weights: Vec<BigInt>,
    hungarian: hungarian::SolverScratch,
    validation: ValidationScratch,
}

impl SolverScratch {
    pub(crate) fn try_new(
        input_count: RuntimeCount,
        output_count: RuntimeCount,
        edges: &[PreparedCrossbarEdge],
    ) -> Result<Self, RunError> {
        let size = runtime_size(input_count, output_count, edges.len())?;
        let mut allocation = ProductionAllocationGate;
        let mut composite_weights = allocate_filled(
            &mut allocation,
            "crossbar_composite_weights",
            size.queue_count,
            BigInt::zero(),
        )?;
        // Normalize logical length after using the same fallible allocation
        // boundary as the exact solve path.
        composite_weights.resize(size.queue_count, BigInt::zero());
        let hungarian =
            hungarian::SolverScratch::try_new(size.order, &mut allocation).map_err(|error| {
                match error {
                    hungarian::HungarianError::AllocationFailed { buffer } => {
                        RunError::ResourceExhausted {
                            stage: RuntimeStage::ColdMaxWeightSolve,
                            detail: format!("crossbar workspace allocation failed for {buffer}"),
                        }
                    }
                    _ => RunError::ExactOptimizerFailure {
                        stage: RuntimeStage::ColdMaxWeightSolve,
                        detail: "crossbar Hungarian scratch dimensions overflowed".to_owned(),
                    },
                }
            })?;
        let selected = allocate_filled(
            &mut allocation,
            "crossbar_selected",
            size.queue_count,
            false,
        )?;
        let selected_capacity = selected.capacity();
        let validation = ValidationScratch::try_new(size, &mut allocation)?;
        Ok(Self {
            queue_count: size.queue_count,
            selected_capacity,
            selected: Some(selected),
            composite_weights,
            hungarian,
            validation,
        })
    }

    pub(crate) fn recycle_selected(&mut self, mut selected: Vec<bool>) -> Result<(), RunError> {
        if self.selected.is_some() || selected.len() != self.queue_count {
            return Err(runtime_contract(
                "crossbar selected workspace was returned twice or with the wrong width",
            ));
        }
        selected.fill(false);
        self.selected = Some(selected);
        Ok(())
    }

    pub(crate) fn mutable_bytes(&self) -> usize {
        self.selected_capacity
            .saturating_mul(std::mem::size_of::<bool>())
            .saturating_add(
                self.composite_weights
                    .capacity()
                    .saturating_mul(std::mem::size_of::<BigInt>()),
            )
            .saturating_add(self.hungarian.mutable_bytes())
            .saturating_add(self.validation.mutable_bytes())
    }

    pub(crate) fn logical_exact_integer_payload_bytes(&self) -> usize {
        self.composite_weights
            .iter()
            .map(bigint_logical_payload_bytes)
            .fold(0_usize, usize::saturating_add)
            .saturating_add(self.hungarian.logical_exact_integer_payload_bytes())
    }
}

#[derive(Clone, Copy, Debug)]
enum AugmentedWeight<'a> {
    Forbidden,
    DummyZero,
    Real(&'a BigInt),
}

impl CrossbarProblem<'_> {
    fn real_queue(&self, input: usize, output: usize) -> Option<usize> {
        self.cell_to_queue[input * self.size.output_count + output]
    }

    fn real_arc_is_allowed(&self, queue: usize) -> bool {
        self.eligible[queue]
    }

    fn augmented_weight(&self, row: usize, column: usize) -> AugmentedWeight<'_> {
        if row < self.size.input_count && column < self.size.output_count {
            let Some(queue) = self.real_queue(row, column) else {
                return AugmentedWeight::Forbidden;
            };
            if self.real_arc_is_allowed(queue) {
                AugmentedWeight::Real(&self.composite_weights[queue])
            } else {
                AugmentedWeight::Forbidden
            }
        } else {
            AugmentedWeight::DummyZero
        }
    }
}

/// Canonical production solve using the prepared immutable cell map and one
/// replication's reusable Hungarian vectors.
pub(crate) fn solve_with_scratch(
    input_count: RuntimeCount,
    output_count: RuntimeCount,
    edges: &[PreparedCrossbarEdge],
    cell_to_queue: &[Option<usize>],
    request: &MaxWeightRequest,
    scratch: &mut SolverScratch,
) -> Result<Option<CandidateAction>, RunError> {
    let size = runtime_size(input_count, output_count, edges.len())?;
    let _empty_schedule_is_feasible =
        validate_and_check_schedule(size, edges, |_queue| false, &mut scratch.validation)?;
    if request.primary_weights.len() != size.queue_count
        || request.eligible.len() != size.queue_count
    {
        return Err(runtime_contract(
            "crossbar weights and eligibility must have exactly Q entries",
        ));
    }
    if cell_to_queue.len() != size.cells {
        return Err(runtime_contract(
            "prepared crossbar cell map has the wrong width",
        ));
    }
    for edge in edges {
        let queue = usize::try_from(edge.queue.0)
            .map_err(|_| runtime_contract("crossbar QueueIndex is not host-representable"))?;
        let input = usize::try_from(edge.input_index)
            .map_err(|_| runtime_contract("crossbar input index is not host-representable"))?;
        let output = usize::try_from(edge.output_index)
            .map_err(|_| runtime_contract("crossbar output index is not host-representable"))?;
        if cell_to_queue[input * size.output_count + output] != Some(queue) {
            return Err(runtime_contract(
                "prepared crossbar cell map differs from canonical edges",
            ));
        }
    }
    if scratch.queue_count != size.queue_count
        || scratch.composite_weights.len() != size.queue_count
    {
        return Err(runtime_contract(
            "crossbar replication scratch has the wrong prepared dimensions",
        ));
    }
    let radix = BigInt::one() << size.queue_count;
    for (rank, (destination, primary)) in scratch
        .composite_weights
        .iter_mut()
        .zip(&request.primary_weights)
        .enumerate()
    {
        let priority_bit = BigInt::one() << (size.queue_count - 1 - rank);
        *destination = primary * &radix + priority_bit;
    }
    let mut selected = scratch
        .selected
        .take()
        .ok_or_else(|| runtime_contract("crossbar selected workspace is already checked out"))?;
    if selected.len() != size.queue_count {
        scratch.selected = Some(selected);
        return Err(runtime_contract(
            "crossbar selected workspace has the wrong prepared width",
        ));
    }
    selected.fill(false);
    let problem = CrossbarProblem {
        size,
        cell_to_queue,
        composite_weights: &scratch.composite_weights,
        eligible: &request.eligible,
    };
    let kernel_result = hungarian::solve_with_scratch(
        &problem,
        &mut selected,
        &mut scratch.hungarian,
    )
    .map_err(|error| match error {
        hungarian::HungarianError::AllocationFailed { buffer } => RunError::ResourceExhausted {
            stage: RuntimeStage::ColdMaxWeightSolve,
            detail: format!("crossbar workspace allocation failed for {buffer}"),
        },
        hungarian::HungarianError::DimensionOverflow
        | hungarian::HungarianError::AugmentationInfeasible
        | hungarian::HungarianError::InvalidAssignment => RunError::ExactOptimizerFailure {
            stage: RuntimeStage::ColdMaxWeightSolve,
            detail: "crossbar optional-matching augmentation violated its exact invariant"
                .to_owned(),
        },
    });
    if let Err(error) = kernel_result {
        scratch.selected = Some(selected);
        return Err(error);
    }
    match validate_and_check_schedule(
        size,
        edges,
        |queue| selected[queue],
        &mut scratch.validation,
    ) {
        Ok(true) => {}
        Ok(false) => {
            scratch.selected = Some(selected);
            return Err(RunError::ExactOptimizerFailure {
                stage: RuntimeStage::ColdMaxWeightSolve,
                detail: "crossbar Hungarian returned an endpoint-conflicting schedule".to_owned(),
            });
        }
        Err(error) => {
            scratch.selected = Some(selected);
            return Err(error);
        }
    }
    let primary_objective = selected
        .iter()
        .zip(&request.primary_weights)
        .filter(|(chosen, _weight)| **chosen)
        .fold(BigInt::zero(), |sum, (_chosen, weight)| sum + weight);
    let tie_refinement =
        selected
            .iter()
            .enumerate()
            .fold(BigUint::zero(), |value, (rank, chosen)| {
                if *chosen {
                    value | (BigUint::one() << (size.queue_count - 1 - rank))
                } else {
                    value
                }
            });
    Ok(Some(CandidateAction {
        selected,
        primary_objective,
        tie_refinement,
    }))
}

pub(crate) fn is_feasible_with_scratch(
    input_count: RuntimeCount,
    output_count: RuntimeCount,
    edges: &[PreparedCrossbarEdge],
    schedule: &[bool],
    scratch: &mut SolverScratch,
) -> Result<bool, RunError> {
    let size = runtime_size(input_count, output_count, edges.len())?;
    if schedule.len() != size.queue_count || scratch.queue_count != size.queue_count {
        return Err(runtime_contract(
            "crossbar feasibility inputs differ from the prepared scratch dimensions",
        ));
    }
    validate_and_check_schedule(
        size,
        edges,
        |queue| schedule[queue],
        &mut scratch.validation,
    )
}
