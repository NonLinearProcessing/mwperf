//! Exact, cold Hungarian kernel for an implicitly augmented optional matching.
//!
//! A missing real arc is never assigned a finite stand-in value. All arcs
//! involving a dummy row or column are exact zero arcs, so every optional real
//! matching extends to a perfect augmented assignment of order `I + O`.

use std::cmp::Ordering;

use num_bigint::BigInt;
use num_traits::Zero;

use crate::maxweight::bigint_logical_payload_bytes;

use super::{AllocationGate, AugmentedWeight, CrossbarProblem, ReservationFailed};

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) enum HungarianError {
    DimensionOverflow,
    AllocationFailed { buffer: &'static str },
    AugmentationInfeasible,
    InvalidAssignment,
}

fn reserved_filled<T: Clone, A: AllocationGate>(
    allocation: &mut A,
    buffer: &'static str,
    length: usize,
    value: T,
) -> Result<Vec<T>, HungarianError> {
    let mut vector = Vec::new();
    allocation
        .reserve_exact(buffer, &mut vector, length)
        .map_err(|ReservationFailed| HungarianError::AllocationFailed { buffer })?;
    vector.resize(length, value);
    Ok(vector)
}

#[derive(Debug, Eq, PartialEq)]
pub(super) struct SolverScratch {
    row_potential: Vec<BigInt>,
    column_potential: Vec<BigInt>,
    column_owner: Vec<usize>,
    predecessor: Vec<usize>,
    minimum_slack: Vec<Option<BigInt>>,
    in_tree: Vec<bool>,
}

impl SolverScratch {
    pub(super) fn try_new<A: AllocationGate>(
        order: usize,
        allocation: &mut A,
    ) -> Result<Self, HungarianError> {
        let one_based = order
            .checked_add(1)
            .ok_or(HungarianError::DimensionOverflow)?;
        Ok(Self {
            row_potential: reserved_filled(
                allocation,
                "hungarian_row_potential",
                one_based,
                BigInt::zero(),
            )?,
            column_potential: reserved_filled(
                allocation,
                "hungarian_column_potential",
                one_based,
                BigInt::zero(),
            )?,
            column_owner: reserved_filled(
                allocation,
                "hungarian_column_owner",
                one_based,
                0_usize,
            )?,
            predecessor: reserved_filled(allocation, "hungarian_predecessor", one_based, 0_usize)?,
            minimum_slack: reserved_filled(
                allocation,
                "hungarian_minimum_slack",
                one_based,
                None::<BigInt>,
            )?,
            in_tree: reserved_filled(allocation, "hungarian_in_tree", one_based, false)?,
        })
    }

    pub(super) fn mutable_bytes(&self) -> usize {
        self.row_potential
            .capacity()
            .saturating_mul(std::mem::size_of::<BigInt>())
            .saturating_add(
                self.column_potential
                    .capacity()
                    .saturating_mul(std::mem::size_of::<BigInt>()),
            )
            .saturating_add(
                self.column_owner
                    .capacity()
                    .saturating_mul(std::mem::size_of::<usize>()),
            )
            .saturating_add(
                self.predecessor
                    .capacity()
                    .saturating_mul(std::mem::size_of::<usize>()),
            )
            .saturating_add(
                self.minimum_slack
                    .capacity()
                    .saturating_mul(std::mem::size_of::<Option<BigInt>>()),
            )
            .saturating_add(
                self.in_tree
                    .capacity()
                    .saturating_mul(std::mem::size_of::<bool>()),
            )
    }

    pub(super) fn logical_exact_integer_payload_bytes(&self) -> usize {
        self.row_potential
            .iter()
            .chain(&self.column_potential)
            .map(bigint_logical_payload_bytes)
            .chain(
                self.minimum_slack
                    .iter()
                    .filter_map(Option::as_ref)
                    .map(bigint_logical_payload_bytes),
            )
            .fold(0_usize, usize::saturating_add)
    }
}

/// Returns a selected-bit vector for one maximum-composite optional matching.
pub(super) fn solve_with_scratch(
    problem: &CrossbarProblem<'_>,
    selected: &mut [bool],
    scratch: &mut SolverScratch,
) -> Result<(), HungarianError> {
    let order = problem.size.order;
    let one_based = order
        .checked_add(1)
        .ok_or(HungarianError::DimensionOverflow)?;
    if scratch.row_potential.len() != one_based
        || scratch.column_potential.len() != one_based
        || scratch.column_owner.len() != one_based
        || scratch.predecessor.len() != one_based
        || scratch.minimum_slack.len() != one_based
        || scratch.in_tree.len() != one_based
    {
        return Err(HungarianError::InvalidAssignment);
    }
    let SolverScratch {
        row_potential,
        column_potential,
        column_owner,
        predecessor,
        minimum_slack,
        in_tree,
    } = scratch;
    row_potential.fill(BigInt::zero());
    column_potential.fill(BigInt::zero());
    column_owner.fill(0);
    predecessor.fill(0);
    minimum_slack.fill(None);
    in_tree.fill(false);

    for root_row in 1..=order {
        column_owner[0] = root_row;
        predecessor.fill(0);
        minimum_slack.fill(None);
        in_tree.fill(false);
        let mut current_column = 0_usize;

        loop {
            in_tree[current_column] = true;
            let current_row = column_owner[current_column];

            for next_column in 1..=order {
                if in_tree[next_column] {
                    continue;
                }
                let row = current_row - 1;
                let column = next_column - 1;
                let mut reduced_cost = match problem.augmented_weight(row, column) {
                    AugmentedWeight::Forbidden => continue,
                    AugmentedWeight::DummyZero => BigInt::zero(),
                    AugmentedWeight::Real(weight) => -weight,
                };
                reduced_cost -= &row_potential[current_row];
                reduced_cost -= &column_potential[next_column];

                let replace = match &minimum_slack[next_column] {
                    None => true,
                    Some(current) => match reduced_cost.cmp(current) {
                        Ordering::Less => true,
                        Ordering::Equal => current_column < predecessor[next_column],
                        Ordering::Greater => false,
                    },
                };
                if replace {
                    minimum_slack[next_column] = Some(reduced_cost);
                    predecessor[next_column] = current_column;
                }
            }

            let next_column = (1..=order)
                .filter(|column| !in_tree[*column])
                .filter(|column| minimum_slack[*column].is_some())
                .min_by(|left, right| {
                    match (
                        minimum_slack[*left].as_ref(),
                        minimum_slack[*right].as_ref(),
                    ) {
                        (Some(left_slack), Some(right_slack)) => {
                            left_slack.cmp(right_slack).then_with(|| left.cmp(right))
                        }
                        // Both indices have already passed the `Some` filter.
                        // Keep the branch total even if its filtered premise
                        // is violated by a future refactor.
                        _ => left.cmp(right),
                    }
                })
                .ok_or(HungarianError::AugmentationInfeasible)?;
            let delta = minimum_slack[next_column]
                .as_ref()
                .ok_or(HungarianError::AugmentationInfeasible)?
                .clone();

            for column in 0..=order {
                if in_tree[column] {
                    let row = column_owner[column];
                    row_potential[row] += &delta;
                    column_potential[column] -= &delta;
                } else if let Some(slack) = &mut minimum_slack[column] {
                    *slack -= &delta;
                }
            }

            current_column = next_column;
            if column_owner[current_column] == 0 {
                break;
            }
        }

        loop {
            let prior_column = predecessor[current_column];
            column_owner[current_column] = column_owner[prior_column];
            current_column = prior_column;
            if current_column == 0 {
                break;
            }
        }
    }

    for (one_based_column, &one_based_row) in column_owner.iter().enumerate().skip(1) {
        if one_based_row == 0 {
            return Err(HungarianError::InvalidAssignment);
        }
        let row = one_based_row - 1;
        let column = one_based_column - 1;
        if row < problem.size.input_count && column < problem.size.output_count {
            let queue = problem
                .real_queue(row, column)
                .ok_or(HungarianError::InvalidAssignment)?;
            if !problem.real_arc_is_allowed(queue) || selected[queue] {
                return Err(HungarianError::InvalidAssignment);
            }
            selected[queue] = true;
        }
    }
    Ok(())
}
