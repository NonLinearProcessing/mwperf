//! Exact half-open interval MaxWeight compiler and runtime backend.
//!
//! Exact rational endpoints exist only while this module compiles a canonical
//! right-endpoint order and compatible-predecessor table.  Runtime feasibility
//! and the cold weighted-interval dynamic program consume only that table.

use std::cmp::Ordering;
use std::mem::size_of;

use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};

use crate::bounds::{
    AllocationClass, BoundCertified, BoundContribution, BoundError, BoundProvenance, BoundStage,
    ContributorId, QuantityKey, ServiceContributor, WorkStackClass,
};
use crate::error::{PrepareError, RunError, RuntimeStage};
use crate::exact::{ExactRational, ExactUnsigned};
use crate::unit_count::QueueIndex;

use super::{
    bigint_logical_payload_bytes, biguint_logical_payload_bytes, CandidateAction, MaxWeightRequest,
    PreparedInterval, PreparedServiceOptimizer,
};

const BITS_PER_WORD: usize = 64;

/// Neutral exact row consumed by the interval compiler. This type belongs to
/// the backend rather than the retained occupancy adapter.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct CompileInterval {
    pub(crate) queue: QueueIndex,
    pub(crate) left: ExactRational,
    pub(crate) right: ExactRational,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct IntervalSize {
    queue_count: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Score {
    primary: BigInt,
    tie: BigUint,
}

impl Score {
    fn zero() -> Self {
        Self {
            primary: BigInt::zero(),
            tie: BigUint::zero(),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct ReservationFailed;

/// Instance-local injection seam for every production-owned runtime vector.
pub(crate) trait AllocationGate {
    fn reserve_exact<T>(
        &mut self,
        buffer: &'static str,
        vector: &mut Vec<T>,
        additional: usize,
    ) -> Result<(), ReservationFailed>;
}

#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct ProductionAllocationGate;

impl AllocationGate for ProductionAllocationGate {
    fn reserve_exact<T>(
        &mut self,
        _buffer: &'static str,
        vector: &mut Vec<T>,
        additional: usize,
    ) -> Result<(), ReservationFailed> {
        vector
            .try_reserve_exact(additional)
            .map_err(|_error| ReservationFailed)
    }
}

fn invalid_constraint(detail: impl Into<String>) -> PrepareError {
    PrepareError::InvalidConstraintInstance {
        path: "/selected_config/scheduler".to_owned(),
        detail: detail.into(),
    }
}

/// Size validation precedes linker/compiler allocation. The private empty
/// instance is intentional even though a complete public scenario currently
/// has at least one queue. Host-representability and successful checked
/// allocation are the only implementation bounds.
pub(crate) fn validate_declared_size(queue_count: usize) -> Result<IntervalSize, PrepareError> {
    Ok(IntervalSize { queue_count })
}

fn exact_usize(value: usize) -> ExactUnsigned {
    ExactUnsigned::from_biguint(BigUint::from(value))
}

fn checked_add(left: usize, right: usize, detail: &'static str) -> Result<usize, PrepareError> {
    left.checked_add(right)
        .ok_or_else(|| invalid_constraint(detail))
}

fn checked_mul(left: usize, right: usize, detail: &'static str) -> Result<usize, PrepareError> {
    left.checked_mul(right)
        .ok_or_else(|| invalid_constraint(detail))
}

fn bit_word_count(bit_count: usize) -> Result<usize, PrepareError> {
    (bit_count / BITS_PER_WORD)
        .checked_add(usize::from(bit_count % BITS_PER_WORD != 0))
        .ok_or_else(|| invalid_constraint("interval validation bitset width overflowed"))
}

/// Bounds both compilation (exact source plus predecessor output) and the
/// simultaneously-live runtime vectors.  Arbitrary-precision limb storage is
/// deliberately not misrepresented as a fixed byte count.
fn checked_workspace_bounds(size: IntervalSize) -> Result<(usize, usize), PrepareError> {
    let prefix_count = checked_add(size.queue_count, 1, "interval DP prefix count overflowed")?;
    let validation_words = bit_word_count(size.queue_count)?;
    let runtime_elements = checked_add(
        checked_mul(
            size.queue_count,
            3,
            "interval linear workspace element bound overflowed",
        )?,
        checked_add(
            prefix_count,
            validation_words,
            "interval validation workspace element bound overflowed",
        )?,
        "interval total workspace element bound overflowed",
    )?;

    let validation_bytes = checked_mul(
        validation_words,
        size_of::<u64>(),
        "interval validation byte bound overflowed",
    )?;
    let compile_bytes = checked_add(
        checked_mul(
            size.queue_count,
            checked_add(
                size_of::<CompileInterval>(),
                size_of::<PreparedInterval>(),
                "interval compile byte stride overflowed",
            )?,
            "interval compile byte bound overflowed",
        )?,
        validation_bytes,
        "interval compile validation byte bound overflowed",
    )?;
    let runtime_bytes = [
        checked_mul(
            size.queue_count,
            size_of::<PreparedInterval>(),
            "interval prepared byte bound overflowed",
        )?,
        checked_mul(
            size.queue_count,
            size_of::<bool>(),
            "interval selected byte bound overflowed",
        )?,
        checked_mul(
            size.queue_count,
            size_of::<bool>(),
            "interval reconstruction byte bound overflowed",
        )?,
        checked_mul(
            prefix_count,
            size_of::<Score>(),
            "interval score byte bound overflowed",
        )?,
        validation_bytes,
    ]
    .into_iter()
    .try_fold(0_usize, |sum, term| {
        checked_add(sum, term, "interval runtime byte bound overflowed")
    })?;
    Ok((runtime_elements, compile_bytes.max(runtime_bytes)))
}

fn bound_error(error: BoundError) -> PrepareError {
    PrepareError::InvalidNumericSpec {
        path: "/selected_config/scheduler".to_owned(),
        detail: error.to_string(),
    }
}

fn mark_new_bit(words: &mut [u64], index: usize) -> bool {
    let word = index / BITS_PER_WORD;
    let bit = 1_u64 << (index % BITS_PER_WORD);
    let was_clear = words[word] & bit == 0;
    words[word] |= bit;
    was_clear
}

fn validate_compile_intervals(
    size: IntervalSize,
    intervals: &[CompileInterval],
) -> Result<(), PrepareError> {
    let mut seen_queues = allocate_prepare_bitset(bit_word_count(size.queue_count)?)?;
    for (position, interval) in intervals.iter().enumerate() {
        let queue = usize::try_from(interval.queue.0)
            .map_err(|_| invalid_constraint("interval QueueIndex is not host-representable"))?;
        if queue >= size.queue_count {
            return Err(invalid_constraint(format!(
                "interval {position} has a non-dense QueueIndex"
            )));
        }
        if !mark_new_bit(&mut seen_queues, queue) {
            return Err(invalid_constraint(format!(
                "interval {position} duplicates a QueueIndex"
            )));
        }
        if interval.left >= interval.right {
            return Err(invalid_constraint(format!(
                "interval {position} must satisfy left < right"
            )));
        }
    }
    Ok(())
}

fn allocate_prepare_bitset(word_count: usize) -> Result<Vec<u64>, PrepareError> {
    let mut words = Vec::new();
    words
        .try_reserve_exact(word_count)
        .map_err(|_error| invalid_constraint("interval validation allocation failed"))?;
    words.resize(word_count, 0_u64);
    Ok(words)
}

fn exact_interval_order(left: &CompileInterval, right: &CompileInterval) -> Ordering {
    left.right
        .cmp(&right.right)
        .then_with(|| left.left.cmp(&right.left))
        .then_with(|| left.queue.cmp(&right.queue))
}

/// Return the last prior coordinate whose right endpoint is at most `left`.
/// The input prefix is already in nondecreasing exact right-endpoint order.
fn compatible_predecessor(
    sorted_prefix: &[CompileInterval],
    left: &crate::exact::ExactRational,
) -> Option<usize> {
    let mut low = 0_usize;
    let mut high = sorted_prefix.len();
    while low < high {
        let distance = high - low;
        let middle = low + distance / 2;
        if sorted_prefix[middle].right <= *left {
            low = middle + 1;
        } else {
            high = middle;
        }
    }
    low.checked_sub(1)
}

/// Exact endpoint values are consumed here and cannot survive in the runtime
/// optimizer or affect the unit-slot clock.
pub(crate) fn compile_optimizer(
    mut intervals: Vec<CompileInterval>,
) -> Result<BoundCertified<PreparedServiceOptimizer>, PrepareError> {
    let size = validate_declared_size(intervals.len())?;
    validate_compile_intervals(size, &intervals)?;
    intervals.sort_unstable_by(exact_interval_order);

    let mut prepared = Vec::new();
    prepared
        .try_reserve_exact(size.queue_count)
        .map_err(|_error| invalid_constraint("interval predecessor allocation failed"))?;
    for position in 0..size.queue_count {
        let predecessor = compatible_predecessor(&intervals[..position], &intervals[position].left)
            .map(|value| {
                u32::try_from(value).map_err(|_| {
                    invalid_constraint("interval predecessor exceeds the u32 runtime ABI")
                })
            })
            .transpose()?;
        prepared.push(PreparedInterval {
            queue: intervals[position].queue,
            compatible_predecessor: predecessor,
        });
    }

    let optimizer = PreparedServiceOptimizer::IntervalDynamicProgram {
        intervals: prepared,
    };
    let (workspace_elements, workspace_bytes) = checked_workspace_bounds(size)?;
    let contributor = ContributorId::Service(ServiceContributor::IntervalDynamicProgram);
    let mut contribution = BoundContribution::new(contributor);
    for (quantity, upper, label) in [
        (
            QuantityKey::DenseQueueCount,
            size.queue_count,
            "interval dense queue count",
        ),
        (
            QuantityKey::DenseResourceCount,
            size.queue_count,
            "interval static footprint count",
        ),
        (
            QuantityKey::AllocationElements(AllocationClass::ConstraintWorkspace),
            workspace_elements,
            "interval maximum simultaneously-live structural elements",
        ),
        (
            QuantityKey::AllocationBytes(AllocationClass::ConstraintWorkspace),
            workspace_bytes,
            "interval maximum simultaneously-live structural inline bytes",
        ),
        (
            QuantityKey::WorkStackDepth(WorkStackClass::ConstraintSolver),
            0,
            "interval iterative solver work-stack depth",
        ),
    ] {
        contribution
            .insert(
                quantity,
                exact_usize(upper),
                BoundProvenance::new(
                    BoundStage::ConstraintCompilation,
                    "/selected_config/scheduler",
                    label,
                ),
            )
            .map_err(bound_error)?;
    }
    BoundCertified::new(optimizer, contribution).map_err(bound_error)
}

fn runtime_contract(detail: impl Into<String>) -> RunError {
    RunError::OptimizerContractViolation {
        stage: RuntimeStage::ColdMaxWeightSolve,
        detail: detail.into(),
    }
}

fn validate_prepared_with_scratch(
    intervals: &[PreparedInterval],
    size: IntervalSize,
    seen_queues: &mut [u64],
) -> Result<(), RunError> {
    if seen_queues.len() != runtime_bit_word_count(size.queue_count)? {
        return Err(runtime_contract(
            "interval validation scratch has the wrong prepared dimensions",
        ));
    }
    seen_queues.fill(0);
    for (position, interval) in intervals.iter().enumerate() {
        let queue = usize::try_from(interval.queue.0)
            .map_err(|_| runtime_contract("interval QueueIndex is not host-representable"))?;
        if queue >= size.queue_count {
            return Err(runtime_contract(format!(
                "prepared interval {position} has a non-dense QueueIndex"
            )));
        }
        if !mark_new_bit(seen_queues, queue) {
            return Err(runtime_contract(format!(
                "prepared interval {position} duplicates a QueueIndex"
            )));
        }
        if interval.compatible_predecessor.is_some_and(|predecessor| {
            usize::try_from(predecessor).map_or(true, |value| value >= position)
        }) {
            return Err(runtime_contract(format!(
                "prepared interval {position} has a non-prior predecessor"
            )));
        }
    }
    Ok(())
}

fn validate_prepared(intervals: &[PreparedInterval]) -> Result<IntervalSize, RunError> {
    let size = validate_declared_size(intervals.len())
        .map_err(|error| runtime_contract(error.to_string()))?;
    let mut allocation = ProductionAllocationGate;
    let mut seen_queues = allocate_filled(
        &mut allocation,
        "interval_validation_seen_queues",
        runtime_bit_word_count(size.queue_count)?,
        0_u64,
    )?;
    validate_prepared_with_scratch(intervals, size, &mut seen_queues)?;
    Ok(size)
}

fn runtime_bit_word_count(bit_count: usize) -> Result<usize, RunError> {
    (bit_count / BITS_PER_WORD)
        .checked_add(usize::from(bit_count % BITS_PER_WORD != 0))
        .ok_or_else(|| runtime_contract("interval validation bitset width overflowed"))
}

fn predecessor_position(interval: &PreparedInterval) -> Result<Option<usize>, RunError> {
    interval
        .compatible_predecessor
        .map(|value| {
            usize::try_from(value)
                .map_err(|_| runtime_contract("interval predecessor is not host-representable"))
        })
        .transpose()
}

fn validate_and_check_schedule_after_prepared(
    intervals: &[PreparedInterval],
    mut is_selected: impl FnMut(usize) -> bool,
) -> Result<bool, RunError> {
    let mut last_selected = None::<usize>;
    let mut feasible = true;
    for (position, interval) in intervals.iter().enumerate() {
        let queue = usize::try_from(interval.queue.0)
            .map_err(|_| runtime_contract("interval QueueIndex is not host-representable"))?;
        if !is_selected(queue) {
            continue;
        }
        let predecessor = predecessor_position(interval)?;
        if last_selected.is_some_and(|last| predecessor.is_none_or(|prior| last > prior)) {
            feasible = false;
        }
        last_selected = Some(position);
    }
    Ok(feasible)
}

pub(super) fn is_feasible(
    intervals: &[PreparedInterval],
    schedule: &[bool],
) -> Result<bool, RunError> {
    let size = validate_prepared(intervals)?;
    if schedule.len() != size.queue_count {
        return Err(RunError::OptimizerContractViolation {
            stage: RuntimeStage::ActionValidation,
            detail: "interval schedule must have exactly one bit per dense QueueIndex".to_owned(),
        });
    }
    validate_and_check_schedule_after_prepared(intervals, |queue| schedule[queue])
}

fn allocate_filled<T: Clone, A: AllocationGate>(
    allocation: &mut A,
    buffer: &'static str,
    length: usize,
    value: T,
) -> Result<Vec<T>, RunError> {
    let mut vector = Vec::new();
    allocation
        .reserve_exact(buffer, &mut vector, length)
        .map_err(|ReservationFailed| RunError::ResourceExhausted {
            stage: RuntimeStage::ColdMaxWeightSolve,
            detail: format!("interval workspace allocation failed for {buffer}"),
        })?;
    vector.resize(length, value);
    Ok(vector)
}

/// Structural workspace owned by one replication. The selected-bit buffer is
/// checked out only while a candidate is live; DP scores never survive a
/// solve semantically and are completely overwritten on the next call.
#[derive(Debug, Eq, PartialEq)]
pub(crate) struct SolverScratch {
    selected_capacity: usize,
    selected: Option<Vec<bool>>,
    best: Vec<Score>,
    take: Vec<bool>,
    seen_queues: Vec<u64>,
}

impl SolverScratch {
    pub(crate) fn try_new(intervals: &[PreparedInterval]) -> Result<Self, RunError> {
        let size = validate_declared_size(intervals.len())
            .map_err(|error| runtime_contract(error.to_string()))?;
        let prefix_count = size
            .queue_count
            .checked_add(1)
            .ok_or_else(|| runtime_contract("interval DP prefix count overflowed"))?;
        let mut allocation = ProductionAllocationGate;
        let mut seen_queues = allocate_filled(
            &mut allocation,
            "interval_validation_seen_queues",
            runtime_bit_word_count(size.queue_count)?,
            0_u64,
        )?;
        validate_prepared_with_scratch(intervals, size, &mut seen_queues)?;
        let selected = allocate_filled(
            &mut allocation,
            "interval_selected",
            size.queue_count,
            false,
        )?;
        let selected_capacity = selected.capacity();
        Ok(Self {
            selected_capacity,
            selected: Some(selected),
            best: allocate_filled(
                &mut allocation,
                "interval_dp_scores",
                prefix_count,
                Score::zero(),
            )?,
            take: allocate_filled(
                &mut allocation,
                "interval_reconstruction",
                size.queue_count,
                false,
            )?,
            seen_queues,
        })
    }

    pub(crate) fn recycle_selected(&mut self, mut selected: Vec<bool>) -> Result<(), RunError> {
        if self.selected.is_some() || selected.len() != self.take.len() {
            return Err(runtime_contract(
                "interval selected workspace was returned twice or with the wrong width",
            ));
        }
        selected.fill(false);
        self.selected = Some(selected);
        Ok(())
    }

    pub(crate) fn mutable_bytes(&self) -> usize {
        self.selected_capacity
            .saturating_mul(std::mem::size_of::<bool>())
            .saturating_add(
                self.best
                    .capacity()
                    .saturating_mul(std::mem::size_of::<Score>()),
            )
            .saturating_add(
                self.take
                    .capacity()
                    .saturating_mul(std::mem::size_of::<bool>()),
            )
            .saturating_add(
                self.seen_queues
                    .capacity()
                    .saturating_mul(std::mem::size_of::<u64>()),
            )
    }

    pub(crate) fn logical_exact_integer_payload_bytes(&self) -> usize {
        self.best.iter().fold(0_usize, |bytes, score| {
            bytes
                .saturating_add(bigint_logical_payload_bytes(&score.primary))
                .saturating_add(biguint_logical_payload_bytes(&score.tie))
        })
    }
}

pub(crate) fn solve_with_scratch(
    intervals: &[PreparedInterval],
    request: &MaxWeightRequest,
    scratch: &mut SolverScratch,
) -> Result<Option<CandidateAction>, RunError> {
    let size = validate_declared_size(intervals.len())
        .map_err(|error| runtime_contract(error.to_string()))?;
    validate_prepared_with_scratch(intervals, size, &mut scratch.seen_queues)?;
    if request.primary_weights.len() != size.queue_count
        || request.eligible.len() != size.queue_count
    {
        return Err(runtime_contract(
            "interval weights and eligibility must have exactly Q entries",
        ));
    }
    let expected_prefix = size
        .queue_count
        .checked_add(1)
        .ok_or_else(|| runtime_contract("interval DP prefix count overflowed"))?;
    if scratch.best.len() != expected_prefix || scratch.take.len() != size.queue_count {
        return Err(runtime_contract(
            "interval replication scratch has the wrong prepared dimensions",
        ));
    }
    let mut selected = scratch
        .selected
        .take()
        .ok_or_else(|| runtime_contract("interval selected workspace is already checked out"))?;
    if selected.len() != size.queue_count {
        scratch.selected = Some(selected);
        return Err(runtime_contract(
            "interval selected workspace has the wrong prepared width",
        ));
    }
    selected.fill(false);
    scratch.best.fill(Score::zero());
    scratch.take.fill(false);
    let result = solve_parts_with_workspace(
        intervals,
        &request.primary_weights,
        &request.eligible,
        size,
        &mut selected,
        &mut scratch.best,
        &mut scratch.take,
    );
    if result.is_err() {
        scratch.selected = Some(selected);
    }
    result
}

pub(crate) fn is_feasible_with_scratch(
    intervals: &[PreparedInterval],
    schedule: &[bool],
    scratch: &mut SolverScratch,
) -> Result<bool, RunError> {
    let size = validate_declared_size(intervals.len())
        .map_err(|error| runtime_contract(error.to_string()))?;
    if schedule.len() != size.queue_count || scratch.take.len() != size.queue_count {
        return Err(runtime_contract(
            "interval feasibility inputs differ from the prepared scratch dimensions",
        ));
    }
    validate_prepared_with_scratch(intervals, size, &mut scratch.seen_queues)?;
    validate_and_check_schedule_after_prepared(intervals, |queue| schedule[queue])
}

#[allow(clippy::too_many_arguments)]
fn solve_parts_with_workspace(
    intervals: &[PreparedInterval],
    primary_weights: &[BigInt],
    eligible: &[bool],
    size: IntervalSize,
    selected: &mut Vec<bool>,
    best: &mut [Score],
    take: &mut [bool],
) -> Result<Option<CandidateAction>, RunError> {
    for (position, interval) in intervals.iter().enumerate() {
        let queue = usize::try_from(interval.queue.0)
            .map_err(|_| runtime_contract("interval QueueIndex is not host-representable"))?;
        let next = position
            .checked_add(1)
            .ok_or_else(|| runtime_contract("interval DP position overflowed"))?;
        let predecessor = predecessor_position(interval)?;
        if eligible[queue] {
            let prefix = predecessor
                .map(|prior| {
                    prior
                        .checked_add(1)
                        .ok_or_else(|| runtime_contract("interval predecessor prefix overflowed"))
                })
                .transpose()?
                .unwrap_or(0);
            let candidate_primary = &best[prefix].primary + &primary_weights[queue];
            let exponent = size
                .queue_count
                .checked_sub(1)
                .and_then(|value| value.checked_sub(queue))
                .ok_or_else(|| runtime_contract("interval tie exponent underflowed"))?;
            let candidate_tie = &best[prefix].tie | (BigUint::one() << exponent);
            if candidate_primary > best[position].primary
                || (candidate_primary == best[position].primary
                    && candidate_tie > best[position].tie)
            {
                best[next] = Score {
                    primary: candidate_primary,
                    tie: candidate_tie,
                };
                take[position] = true;
                continue;
            }
        }
        best[next] = best[position].clone();
    }

    let mut prefix = size.queue_count;
    while prefix > 0 {
        let position = prefix
            .checked_sub(1)
            .ok_or_else(|| runtime_contract("interval reconstruction underflowed"))?;
        if take[position] {
            let queue = usize::try_from(intervals[position].queue.0)
                .map_err(|_| runtime_contract("interval QueueIndex is not host-representable"))?;
            selected[queue] = true;
            prefix = predecessor_position(&intervals[position])?
                .map(|prior| {
                    prior.checked_add(1).ok_or_else(|| {
                        runtime_contract("interval reconstruction predecessor overflowed")
                    })
                })
                .transpose()?
                .unwrap_or(0);
        } else {
            prefix = position;
        }
    }

    if !validate_and_check_schedule_after_prepared(intervals, |queue| selected[queue])? {
        return Err(RunError::ExactOptimizerFailure {
            stage: RuntimeStage::ColdMaxWeightSolve,
            detail: "interval DP reconstructed an overlapping schedule".to_owned(),
        });
    }

    let primary_objective = selected
        .iter()
        .zip(primary_weights)
        .filter(|(chosen, _weight)| **chosen)
        .fold(BigInt::zero(), |sum, (_chosen, weight)| sum + weight);
    let tie_refinement =
        selected
            .iter()
            .enumerate()
            .try_fold(BigUint::zero(), |value, (rank, chosen)| {
                if !*chosen {
                    return Ok(value);
                }
                let exponent = size
                    .queue_count
                    .checked_sub(1)
                    .and_then(|upper| upper.checked_sub(rank))
                    .ok_or_else(|| runtime_contract("interval tie exponent underflowed"))?;
                Ok(value | (BigUint::one() << exponent))
            })?;
    Ok(Some(CandidateAction {
        selected: std::mem::take(selected),
        primary_objective,
        tie_refinement,
    }))
}
