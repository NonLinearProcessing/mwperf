//! CP05 compact exact scheduler and replication-scratch oracles.

use num_bigint::{BigInt, BigUint};

use super::*;
use crate::estimator::ProviderFailureReason;
use crate::exact::{ExactRational, ExactUnsigned, RuntimeCount};
use crate::maxweight::{require_free_incumbent, CandidateAction as FreeCandidateAction};
use crate::resolved::{
    ConflictGraphTopology, ConflictPair, CrossbarEdge, CrossbarTopology, IntervalTopology,
    NodeExclusiveLink, NodeExclusiveTopology, QueueInterval, ResolvedScheduler, ResourceDemand,
    ResourcePackingTopology, SchedulerTopology, TypedId,
};
use crate::unit_count::{
    Arrival, CarrierWorkspace, QueueCatalog, QueueIndex, ServiceVector, UnitCountCarrier,
};

fn qid(position: usize) -> TypedId {
    TypedId::from(format!("q{position}"))
}

fn label(prefix: &str, position: usize) -> TypedId {
    TypedId::from(format!("{prefix}{position}"))
}

fn queue(position: usize) -> QueueIndex {
    QueueIndex(u32::try_from(position).expect("small fixture queue"))
}

fn catalog() -> QueueCatalog {
    QueueCatalog::try_new((0..4).map(qid).collect()).expect("fixture catalog")
}

fn priority() -> Vec<TypedId> {
    [3, 2, 1, 0].into_iter().map(qid).collect()
}

fn exact(value: i64) -> ExactRational {
    ExactRational::from_integer(BigInt::from(value))
}

fn schedulers() -> Vec<ResolvedScheduler> {
    vec![
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: vec![label("i", 0), label("i", 1)],
                outputs: vec![label("o", 0), label("o", 1)],
                edges: [(0, 0), (0, 1), (1, 0), (1, 1)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (input, output))| CrossbarEdge {
                        queue_id: qid(position),
                        input: label("i", input),
                        output: label("o", output),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: [(0, 3), (1, 2), (3, 4), (2, 5)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (left, right))| QueueInterval {
                        queue_id: qid(position),
                        left: exact(left),
                        right: exact(right),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                vertices: (0..4).map(|position| label("v", position)).collect(),
                links: [(0, 1), (1, 2), (2, 3), (0, 3)]
                    .into_iter()
                    .enumerate()
                    .map(|(position, (left, right))| NodeExclusiveLink {
                        queue_id: qid(position),
                        u: label("v", left),
                        v: label("v", right),
                    })
                    .collect(),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: [(0, 1), (1, 2), (2, 3)]
                    .into_iter()
                    .map(|(left, right)| ConflictPair {
                        first: qid(left),
                        second: qid(right),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(64)),
            }),
        },
        ResolvedScheduler {
            priority: priority(),
            topology: SchedulerTopology::ResourcePacking(ResourcePackingTopology {
                resources: vec![label("r", 0), label("r", 1)],
                capacity: vec![ExactUnsigned::from_u64(2), ExactUnsigned::from_u64(2)],
                demands: [[1, 1], [2, 0], [0, 2], [3, 0]]
                    .into_iter()
                    .enumerate()
                    .map(|(position, row)| ResourceDemand {
                        queue_id: qid(position),
                        demand: row.into_iter().map(ExactUnsigned::from_u64).collect(),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(64)),
            }),
        },
    ]
}

fn occupied_carrier(
    catalog: &QueueCatalog,
    _feasibility: &PreparedOccupancyMaxWeight,
) -> UnitCountCarrier {
    let mut carrier = UnitCountCarrier::try_empty(catalog.clone()).expect("empty carrier");
    let service = ServiceVector::try_idle(catalog.len()).expect("idle service");
    let arrivals = [
        Arrival::new(queue(0), RuntimeCount::new(3)),
        Arrival::new(queue(2), RuntimeCount::new(2)),
    ];
    let mut workspace = CarrierWorkspace::try_new(&carrier).expect("carrier workspace");
    let prepared = carrier
        .prepare_slot(&service, &[], &arrivals, &mut workspace)
        .expect("seed fixture occupancy preparation");
    let _receipt = carrier.commit_prepared(prepared, &workspace);
    carrier
}

#[test]
fn fofs_cp05_reachable_support_matches_dense_across_all_five_schedulers() {
    let catalog = catalog();
    let support = [true, false, true, false];
    for scheduler in schedulers() {
        let dense = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
            .expect("dense optimizer prepares");
        let quotient =
            PreparedOccupancyMaxWeight::try_prepare_for_support(&scheduler, &catalog, &support)
                .expect("support quotient prepares");
        assert_eq!(dense.hot_queue_count(), 4);
        assert_eq!(quotient.hot_queue_count(), 2);

        let carrier = occupied_carrier(&catalog, &dense);
        let dense_selected = dense.select(&carrier).expect("dense Free solve");
        let mut scratch = quotient
            .try_replication_scratch()
            .expect("quotient scratch");
        let quotient_selected = quotient
            .select_free_with_scratch(&carrier, None, &mut scratch)
            .expect("quotient Free solve");
        assert_eq!(dense_selected.candidate(), quotient_selected.candidate());
        assert_eq!(quotient_selected.candidate().selected()[1], 0);
        assert_eq!(quotient_selected.candidate().selected()[3], 0);
        quotient
            .release_selected(quotient_selected, &mut scratch)
            .expect("return quotient selected request buffers");
    }
}

#[test]
fn fofs_cp05_empty_support_is_exact_zero_and_full_support_is_identity() {
    let catalog = catalog();
    for scheduler in schedulers() {
        let dense = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
            .expect("dense optimizer prepares");
        let identity =
            PreparedOccupancyMaxWeight::try_prepare_for_support(&scheduler, &catalog, &[true; 4])
                .expect("identity support prepares");
        let occupied = occupied_carrier(&catalog, &dense);
        assert_eq!(
            dense
                .select(&occupied)
                .expect("dense selection")
                .candidate(),
            identity
                .select(&occupied)
                .expect("identity support selection")
                .candidate()
        );

        let empty =
            PreparedOccupancyMaxWeight::try_prepare_for_support(&scheduler, &catalog, &[false; 4])
                .expect("empty support prepares");
        let carrier = UnitCountCarrier::try_empty(catalog.clone()).expect("empty carrier");
        let selected = empty.select(&carrier).expect("empty-H Free selection");
        assert_eq!(selected.candidate().selected(), &[0, 0, 0, 0]);
        assert_eq!(selected.candidate().primary_objective, BigInt::from(0_u8));
        assert_eq!(empty.hot_queue_count(), 0);
    }
}

#[test]
fn fofs_cp05_replication_scratch_reuses_buffers_without_retaining_an_incumbent() {
    let catalog = catalog();
    let scheduler = schedulers().remove(3);
    let quotient = PreparedOccupancyMaxWeight::try_prepare_for_support(
        &scheduler,
        &catalog,
        &[true, false, true, false],
    )
    .expect("support quotient prepares");
    let carrier = occupied_carrier(&catalog, &quotient);
    let mut scratch = quotient
        .try_replication_scratch()
        .expect("replication scratch");
    let primary_pointer = scratch.priority_primary.as_ptr();
    let eligible_pointer = scratch.priority_eligible.as_ptr();
    let service_pointer = scratch.priority_service.as_ptr();
    let mutable_bytes = scratch.mutable_bytes();

    let first = quotient
        .select_free_with_scratch(&carrier, None, &mut scratch)
        .expect("first solve");
    assert_eq!(scratch.mutable_bytes(), mutable_bytes);
    let first_candidate = first.candidate().clone();
    quotient
        .release_selected(first, &mut scratch)
        .expect("return selected request buffers");
    let second = quotient
        .select_free_with_scratch(&carrier, None, &mut scratch)
        .expect("second solve");

    assert_eq!(&first_candidate, second.candidate());
    assert_eq!(scratch.mutable_bytes(), mutable_bytes);
    assert_eq!(scratch.priority_primary.as_ptr(), primary_pointer);
    assert_eq!(scratch.priority_eligible.as_ptr(), eligible_pointer);
    assert_eq!(scratch.priority_service.as_ptr(), service_pointer);
}

const ORACLE_QUEUE_COUNT: usize = 4;
const ORACLE_OCCUPANCY_STATES: usize = 81;
const ORACLE_PRIORITY: [usize; ORACLE_QUEUE_COUNT] = [3, 2, 1, 0];

#[derive(Debug, Eq, PartialEq)]
struct ExhaustiveOracleAction {
    selected: [u8; ORACLE_QUEUE_COUNT],
    primary: BigInt,
    tie: BigUint,
}

fn carrier_with_occupancy(
    catalog: &QueueCatalog,
    occupancy: &[u64; ORACLE_QUEUE_COUNT],
) -> UnitCountCarrier {
    let mut carrier = UnitCountCarrier::try_empty(catalog.clone()).expect("empty carrier");
    let service = ServiceVector::try_idle(catalog.len()).expect("idle service");
    let arrivals = occupancy
        .iter()
        .copied()
        .enumerate()
        .filter(|(_position, count)| *count > 0)
        .map(|(position, count)| Arrival::new(queue(position), RuntimeCount::new(count)))
        .collect::<Vec<_>>();
    let mut workspace = CarrierWorkspace::try_new(&carrier).expect("carrier workspace");
    let prepared = carrier
        .prepare_slot(&service, &[], &arrivals, &mut workspace)
        .expect("occupancy fixture preparation");
    let _receipt = carrier.commit_prepared(prepared, &workspace);
    carrier
}

#[test]
fn fofs_cp05_free_solver_reports_actual_search_states_and_preflights_total_grant() {
    let catalog = catalog();
    let occupancy = [2, 2, 2, 2];
    let carrier = carrier_with_occupancy(&catalog, &occupancy);

    for scheduler_position in [3, 4] {
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(
            &schedulers().remove(scheduler_position),
            &catalog,
        )
        .expect("metered exact scheduler prepares");
        assert!(optimizer.search_states_are_applicable());
        let mut scratch = optimizer
            .try_replication_scratch()
            .expect("replication scratch");

        let baseline = optimizer
            .select_free_with_scratch(&carrier, None, &mut scratch)
            .expect("unlimited Free solve");
        let baseline_candidate = baseline.candidate().clone();
        let used = baseline.search_states_used();
        assert!(used > 0, "metered exact solve must expand a root state");
        assert_eq!(baseline.logical_exact_integer_payload_bytes(), 2);
        // A completed exact DP may consume and clear every transient score;
        // the live selected action above owns the required exact witness.
        optimizer
            .release_selected(baseline, &mut scratch)
            .expect("release baseline action");

        let exact_grant = optimizer
            .select_free_with_scratch(&carrier, Some(used), &mut scratch)
            .expect("an exact aggregate grant must admit the solve");
        assert_eq!(exact_grant.search_states_used(), used);
        assert_eq!(exact_grant.candidate(), &baseline_candidate);
        optimizer
            .release_selected(exact_grant, &mut scratch)
            .expect("release exact-grant action");

        let bytes_before_refusal = scratch.mutable_bytes();
        let zero_error = optimizer
            .select_free_with_scratch(&carrier, Some(0), &mut scratch)
            .expect_err("a zero aggregate grant must refuse before the root expansion");
        match zero_error {
            RunError::ScientificGrantExhausted { stage, detail } => {
                assert_eq!(stage, RuntimeStage::ColdMaxWeightSolve);
                assert!(detail.contains("construction optimizer_search_states"));
                assert!(detail.contains("remaining grant=0"));
            }
            other => panic!("unexpected zero-grant refusal: {other:?}"),
        }
        assert!(scratch.selected_dense().is_empty());
        assert_eq!(scratch.mutable_bytes(), bytes_before_refusal);

        let insufficient = used.checked_sub(1).expect("positive state count");
        let error = optimizer
            .select_free_with_scratch(&carrier, Some(insufficient), &mut scratch)
            .expect_err("an insufficient aggregate grant must refuse the solve");
        match error {
            RunError::ScientificGrantExhausted { stage, detail } => {
                assert_eq!(stage, RuntimeStage::ColdMaxWeightSolve);
                assert!(detail.contains("construction optimizer_search_states"));
                assert!(detail.contains(&format!("remaining grant={insufficient}")));
            }
            other => panic!("unexpected aggregate-grant refusal: {other:?}"),
        }
        assert!(scratch.selected_dense().is_empty());
        assert_eq!(scratch.mutable_bytes(), bytes_before_refusal);

        let retry = optimizer
            .select_free_with_scratch(&carrier, None, &mut scratch)
            .expect("same-origin retry after grant refusal");
        assert_eq!(retry.search_states_used(), used);
        assert_eq!(retry.candidate(), &baseline_candidate);
        optimizer
            .release_selected(retry, &mut scratch)
            .expect("release retry action");
    }
}

#[test]
fn fofs_cp05_authored_per_call_search_limit_retains_precedence_and_is_retryable() {
    let catalog = catalog();
    let carrier = carrier_with_occupancy(&catalog, &[2, 2, 2, 2]);

    for scheduler_position in [3, 4] {
        let mut scheduler = schedulers().remove(scheduler_position);
        match &mut scheduler.topology {
            SchedulerTopology::ConflictGraph(graph) => {
                graph.max_search_states = Some(ExactUnsigned::from_u64(1));
            }
            SchedulerTopology::ResourcePacking(packing) => {
                packing.max_search_states = Some(ExactUnsigned::from_u64(1));
            }
            _ => unreachable!("selected metered exact fixture"),
        }
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
            .expect("bounded metered exact scheduler prepares");
        let mut scratch = optimizer
            .try_replication_scratch()
            .expect("replication scratch");
        let bytes_before = scratch.mutable_bytes();

        let first = optimizer
            .select_free_with_scratch(&carrier, Some(1), &mut scratch)
            .expect_err("one state cannot complete this metered exact fixture");
        let retry = optimizer
            .select_free_with_scratch(&carrier, Some(1), &mut scratch)
            .expect_err("authored-limit refusal must be retryable");
        assert_eq!(first, retry);
        match first {
            RunError::ResourceExhausted { stage, detail } => {
                assert_eq!(stage, RuntimeStage::ColdMaxWeightSolve);
                assert!(detail.contains("configured max_search_states=1"));
                assert!(!detail.contains("construction optimizer_search_states"));
            }
            other => panic!("unexpected authored-limit refusal: {other:?}"),
        }
        assert!(scratch.selected_dense().is_empty());
        assert_eq!(scratch.mutable_bytes(), bytes_before);
    }
}

#[test]
fn fofs_cp05_nonrecursive_free_solvers_consume_zero_search_states() {
    let catalog = catalog();
    let carrier = carrier_with_occupancy(&catalog, &[2, 2, 2, 2]);
    for scheduler in schedulers().into_iter().take(3) {
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
            .expect("nonrecursive exact scheduler prepares");
        assert!(!optimizer.search_states_are_applicable());
        let mut scratch = optimizer
            .try_replication_scratch()
            .expect("replication scratch");
        let selected = optimizer
            .select_free_with_scratch(&carrier, Some(0), &mut scratch)
            .expect("a polynomial solve does not consume the search-state grant");
        assert_eq!(selected.search_states_used(), 0);
        optimizer
            .release_selected(selected, &mut scratch)
            .expect("release nonrecursive action");
    }
}

#[test]
fn fofs_cp05_free_solver_no_incumbent_maps_to_the_exact_provider_error() {
    let error = require_free_incumbent(None).expect_err("missing incumbent must fail closed");
    assert_eq!(
        ProviderFailureReason::from_run_error(&error),
        ProviderFailureReason::ExactSolverNoIncumbent
    );
    match &error {
        RunError::ExactOptimizerNoIncumbent { stage, detail } => {
            assert_eq!(*stage, RuntimeStage::ActionValidation);
            assert!(detail.contains("Free MaxWeight class returned no incumbent"));
            assert!(detail.contains("empty schedule"));
        }
        other => panic!("unexpected no-incumbent mapping: {other:?}"),
    }

    let incumbent = FreeCandidateAction {
        selected: vec![false; ORACLE_QUEUE_COUNT],
        primary_objective: BigInt::from(0_u8),
        tie_refinement: BigUint::from(0_u8),
    };
    assert_eq!(
        require_free_incumbent(Some(incumbent.clone())).expect("present incumbent"),
        incumbent
    );
}

fn occupancy_at(mut state: usize) -> [u64; ORACLE_QUEUE_COUNT] {
    let mut occupancy = [0_u64; ORACLE_QUEUE_COUNT];
    for count in &mut occupancy {
        *count = u64::try_from(state % 3).expect("ternary digit fits u64");
        state /= 3;
    }
    occupancy
}

fn oracle_selected(mask: u8, position: usize) -> bool {
    mask & (1_u8 << position) != 0
}

fn oracle_action(
    occupancy: &[u64; ORACLE_QUEUE_COUNT],
    independently_feasible: fn(u8) -> bool,
) -> Option<ExhaustiveOracleAction> {
    let mut best = None::<ExhaustiveOracleAction>;
    for mask in 0_u8..(1_u8 << ORACLE_QUEUE_COUNT) {
        if !independently_feasible(mask)
            || occupancy
                .iter()
                .enumerate()
                .any(|(position, count)| oracle_selected(mask, position) && *count == 0)
        {
            continue;
        }
        let mut selected = [0_u8; ORACLE_QUEUE_COUNT];
        let mut primary = BigInt::from(0_u8);
        for (position, count) in occupancy.iter().copied().enumerate() {
            if oracle_selected(mask, position) {
                selected[position] = 1;
                primary += BigInt::from(count);
            }
        }
        let tie = ORACLE_PRIORITY.iter().copied().enumerate().fold(
            BigUint::from(0_u8),
            |value, (rank, position)| {
                if oracle_selected(mask, position) {
                    value | (BigUint::from(1_u8) << (ORACLE_QUEUE_COUNT - 1 - rank))
                } else {
                    value
                }
            },
        );
        let candidate = ExhaustiveOracleAction {
            selected,
            primary,
            tie,
        };
        if best.as_ref().is_none_or(|incumbent| {
            (&candidate.primary, &candidate.tie) > (&incumbent.primary, &incumbent.tie)
        }) {
            best = Some(candidate);
        }
    }
    best
}

fn assert_free_class(
    optimizer: &PreparedOccupancyMaxWeight,
    carrier: &UnitCountCarrier,
    occupancy: &[u64; ORACLE_QUEUE_COUNT],
    independently_feasible: fn(u8) -> bool,
) {
    let expected = oracle_action(occupancy, independently_feasible)
        .expect("the Free class always contains the empty schedule");
    let actual = optimizer
        .select(carrier)
        .expect("production Free solver completed");
    let actual = actual.candidate();
    assert_eq!(
        actual.selected(),
        expected.selected,
        "selected schedule differs for occupancy {occupancy:?}"
    );
    assert_eq!(
        actual.primary_objective, expected.primary,
        "primary objective differs for occupancy {occupancy:?}"
    );
    assert_eq!(
        actual.tie_refinement, expected.tie,
        "authored-priority tie differs for occupancy {occupancy:?}"
    );
}

fn assert_compact_exhaustive_oracle(
    scheduler: ResolvedScheduler,
    independently_feasible: fn(u8) -> bool,
) {
    let catalog = catalog();
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
        .expect("oracle scheduler prepares");
    for state in 0..ORACLE_OCCUPANCY_STATES {
        let occupancy = occupancy_at(state);
        let carrier = carrier_with_occupancy(&catalog, &occupancy);
        assert_free_class(&optimizer, &carrier, &occupancy, independently_feasible);
    }
}

fn crossbar_oracle(mask: u8) -> bool {
    const ENDPOINTS: [(u8, u8); ORACLE_QUEUE_COUNT] = [(0, 0), (0, 1), (1, 0), (1, 1)];
    for (left, &left_endpoint) in ENDPOINTS.iter().enumerate() {
        if !oracle_selected(mask, left) {
            continue;
        }
        for (right, &right_endpoint) in ENDPOINTS.iter().enumerate().skip(left + 1) {
            if oracle_selected(mask, right)
                && (left_endpoint.0 == right_endpoint.0 || left_endpoint.1 == right_endpoint.1)
            {
                return false;
            }
        }
    }
    true
}

fn interval_oracle(mask: u8) -> bool {
    const HALF_OPEN: [(i8, i8); ORACLE_QUEUE_COUNT] = [(0, 3), (1, 2), (3, 4), (2, 5)];
    for (left, &left_interval) in HALF_OPEN.iter().enumerate() {
        if !oracle_selected(mask, left) {
            continue;
        }
        for (right, &right_interval) in HALF_OPEN.iter().enumerate().skip(left + 1) {
            if oracle_selected(mask, right)
                && left_interval.0 < right_interval.1
                && right_interval.0 < left_interval.1
            {
                return false;
            }
        }
    }
    true
}

fn node_exclusive_oracle(mask: u8) -> bool {
    const ENDPOINTS: [(u8, u8); ORACLE_QUEUE_COUNT] = [(0, 1), (1, 2), (2, 3), (0, 3)];
    for (left, &left_endpoint) in ENDPOINTS.iter().enumerate() {
        if !oracle_selected(mask, left) {
            continue;
        }
        for (right, &right_endpoint) in ENDPOINTS.iter().enumerate().skip(left + 1) {
            if oracle_selected(mask, right)
                && (left_endpoint.0 == right_endpoint.0
                    || left_endpoint.0 == right_endpoint.1
                    || left_endpoint.1 == right_endpoint.0
                    || left_endpoint.1 == right_endpoint.1)
            {
                return false;
            }
        }
    }
    true
}

fn conflict_graph_oracle(mask: u8) -> bool {
    const CONFLICTS: [(usize, usize); 3] = [(0, 1), (1, 2), (2, 3)];
    CONFLICTS
        .iter()
        .all(|&(left, right)| !oracle_selected(mask, left) || !oracle_selected(mask, right))
}

fn binary_packing_oracle(mask: u8) -> bool {
    const CAPACITY: [u8; 2] = [2, 2];
    const DEMAND: [[u8; 2]; ORACLE_QUEUE_COUNT] = [[1, 1], [2, 0], [0, 2], [3, 0]];
    (0..CAPACITY.len()).all(|resource| {
        DEMAND
            .iter()
            .enumerate()
            .filter(|(position, _row)| oracle_selected(mask, *position))
            .map(|(_position, row)| row[resource])
            .sum::<u8>()
            <= CAPACITY[resource]
    })
}

#[test]
fn fofs_cp05_crossbar_hungarian_matches_compact_exhaustive_oracle() {
    assert_compact_exhaustive_oracle(schedulers().remove(0), crossbar_oracle);
}

#[test]
fn fofs_cp05_interval_dynamic_program_matches_compact_exhaustive_oracle() {
    assert_compact_exhaustive_oracle(schedulers().remove(1), interval_oracle);
}

#[test]
fn fofs_cp05_node_exclusive_blossom_matches_compact_exhaustive_oracle() {
    assert_compact_exhaustive_oracle(schedulers().remove(2), node_exclusive_oracle);
}

#[test]
fn fofs_cp05_conflict_graph_exact_mwis_matches_compact_exhaustive_oracle() {
    assert_compact_exhaustive_oracle(schedulers().remove(3), conflict_graph_oracle);
}

#[test]
fn fofs_cp05_binary_packing_branch_and_bound_matches_compact_exhaustive_oracle() {
    assert_compact_exhaustive_oracle(schedulers().remove(4), binary_packing_oracle);
}
