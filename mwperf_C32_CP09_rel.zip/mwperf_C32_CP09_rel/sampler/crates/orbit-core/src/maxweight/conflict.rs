//! Exact pairwise-conflict MaxWeight compiler and MWIS backend.
//!
//! The primary path is a frontier dynamic program whose state count depends
//! on compiled frontier width, not queue count.  Graphs with a wide compiled
//! frontier remain admissible and use an exact sparse depth-first fallback.
//! Both paths compare the exact MaxWeight value and then the same canonical,
//! arbitrary-width priority key.

use std::cmp::Ordering;
use std::mem::size_of;

use num_bigint::{BigInt, BigUint};
use num_traits::{One, Zero};

use crate::bounds::{
    AllocationClass, BoundCertified, BoundContribution, BoundError, BoundProvenance, BoundStage,
    ContributorId, QuantityKey, ServiceContributor, WorkStackClass,
};
use crate::error::{PrepareError, RunError, RuntimeStage};
use crate::exact::ExactUnsigned;
use crate::unit_count::QueueIndex;

use super::{
    bigint_logical_payload_bytes, biguint_logical_payload_bytes, CandidateAction,
    MaxWeightRequest, PreparedServiceOptimizer, SearchStateLimits,
};

/// Algorithm-selection threshold only.  Wider graphs use the exact sparse
/// fallback; this value never rejects a scenario.
const MAX_DENSE_FRONTIER_BITS: usize = 20;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct ConflictSize {
    queue_count: usize,
    conflict_count: usize,
    stack_frames: usize,
}

/// Immutable performance program compiled from the canonical graph.  The
/// canonical BigUint rows remain the graph identity; this order may therefore
/// be recompiled when an induced-support quotient is formed.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct CompiledProgram {
    order: Vec<usize>,
    maximum_frontier: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Score {
    primary: BigInt,
    tie: BigUint,
}

impl Score {
    fn zero() -> Self {
        Self {
            primary: BigInt::zero(),
            tie: BigUint::zero(),
        }
    }

    fn plus(&self, other: &Self) -> Self {
        Self {
            primary: &self.primary + &other.primary,
            tie: &self.tie | &other.tie,
        }
    }

    fn compare(&self, other: &Self) -> Ordering {
        self.primary
            .cmp(&other.primary)
            .then_with(|| self.tie.cmp(&other.tie))
    }

    fn logical_payload_bytes(&self) -> usize {
        bigint_logical_payload_bytes(&self.primary)
            .saturating_add(biguint_logical_payload_bytes(&self.tie))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct FrontierStep {
    vertex: usize,
    before_width: usize,
    selected_neighbor_mask: usize,
    retained_bits: Vec<(usize, usize)>,
    vertex_after_bit: Option<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct SparseFrame {
    remaining: BigUint,
    selected: Score,
}

impl SparseFrame {
    fn logical_payload_bytes(&self) -> usize {
        biguint_logical_payload_bytes(&self.remaining)
            .saturating_add(self.selected.logical_payload_bytes())
    }
}

fn invalid_constraint(detail: impl Into<String>) -> PrepareError {
    PrepareError::InvalidConstraintInstance {
        path: "/selected_config/scheduler".to_owned(),
        detail: detail.into(),
    }
}

fn runtime_contract(detail: impl Into<String>) -> RunError {
    RunError::OptimizerContractViolation {
        stage: RuntimeStage::ColdMaxWeightSolve,
        detail: detail.into(),
    }
}

fn resource_exhausted(detail: impl Into<String>) -> RunError {
    RunError::ResourceExhausted {
        stage: RuntimeStage::ColdMaxWeightSolve,
        detail: detail.into(),
    }
}

fn exact_usize(value: usize) -> ExactUnsigned {
    ExactUnsigned::from_biguint(BigUint::from(value))
}

fn checked_add(left: usize, right: usize, detail: &'static str) -> Result<usize, PrepareError> {
    left.checked_add(right)
        .ok_or_else(|| invalid_constraint(detail))
}

fn checked_mul(left: usize, right: usize, detail: &'static str) -> Result<usize, PrepareError> {
    left.checked_mul(right)
        .ok_or_else(|| invalid_constraint(detail))
}

/// Host-representability validation only; there is no MWIS queue-count cap.
pub(crate) fn validate_declared_size(
    queue_count: usize,
    conflict_count: usize,
) -> Result<ConflictSize, PrepareError> {
    u64::try_from(queue_count)
        .map_err(|_error| invalid_constraint("conflict queue count exceeds the mask ABI"))?;
    let maximum_conflicts = if queue_count < 2 {
        0
    } else {
        queue_count
            .checked_mul(queue_count - 1)
            .and_then(|value| value.checked_div(2))
            .ok_or_else(|| invalid_constraint("conflict-pair envelope overflowed"))?
    };
    if conflict_count > maximum_conflicts {
        return Err(invalid_constraint(format!(
            "conflict-pair count {conflict_count} exceeds Q*(Q-1)/2={maximum_conflicts}"
        )));
    }
    let stack_frames = queue_count
        .checked_add(1)
        .ok_or_else(|| invalid_constraint("conflict sparse-stack depth overflowed"))?;
    Ok(ConflictSize {
        queue_count,
        conflict_count,
        stack_frames,
    })
}

fn checked_workspace_bounds(
    size: ConflictSize,
    program: &CompiledProgram,
) -> Result<(usize, usize), PrepareError> {
    let compile_elements = checked_add(
        checked_add(
            checked_add(
                size.queue_count,
                size.conflict_count,
                "conflict compile element bound overflowed",
            )?,
            checked_mul(
                size.queue_count,
                11,
                "conflict order-candidate bound overflowed",
            )?,
            "conflict compile element bound overflowed",
        )?,
        2,
        "conflict compile element bound overflowed",
    )?;
    let (runtime_elements, runtime_bytes) =
        if program.maximum_frontier <= MAX_DENSE_FRONTIER_BITS {
            let entries = 1_usize
                .checked_shl(u32::try_from(program.maximum_frontier).map_err(|_error| {
                    invalid_constraint("frontier width is not shift-representable")
                })?)
                .ok_or_else(|| invalid_constraint("frontier table length overflowed"))?;
            let mappings = checked_mul(
                size.queue_count,
                program.maximum_frontier,
                "frontier transition bound overflowed",
            )?;
            let elements = [
                checked_add(
                    checked_mul(
                        size.queue_count,
                        9,
                        "frontier linear workspace bound overflowed",
                    )?,
                    2,
                    "frontier linear workspace bound overflowed",
                )?,
                mappings,
                checked_mul(entries, 2, "frontier score-slot bound overflowed")?,
            ]
            .into_iter()
            .try_fold(0_usize, |sum, term| {
                checked_add(sum, term, "frontier runtime element bound overflowed")
            })?;
            let bytes = [
                checked_mul(
                    size.queue_count,
                    size_of::<FrontierStep>(),
                    "frontier-step byte bound overflowed",
                )?,
                checked_mul(
                    mappings,
                    size_of::<(usize, usize)>(),
                    "frontier-map byte bound overflowed",
                )?,
                checked_mul(
                    checked_mul(entries, 2, "frontier score-slot bound overflowed")?,
                    size_of::<Option<Score>>(),
                    "frontier score-table byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<bool>(),
                    "conflict selected byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<BigUint>(),
                    "conflict prepared-mask byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<usize>(),
                    "conflict compiled-order byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    checked_mul(
                        4,
                        size_of::<usize>(),
                        "frontier temporary byte width overflowed",
                    )?,
                    "frontier temporary byte bound overflowed",
                )?,
                checked_mul(
                    2,
                    size_of::<usize>(),
                    "frontier event sentinel byte bound overflowed",
                )?,
            ]
            .into_iter()
            .try_fold(0_usize, |sum, term| {
                checked_add(sum, term, "frontier runtime byte bound overflowed")
            })?;
            (elements, bytes)
        } else {
            let elements = checked_add(
                checked_mul(
                    size.queue_count,
                    6,
                    "sparse conflict linear workspace bound overflowed",
                )?,
                size.stack_frames,
                "sparse conflict element bound overflowed",
            )?;
            let bytes = [
                checked_mul(
                    size.stack_frames,
                    size_of::<SparseFrame>(),
                    "sparse conflict stack byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<bool>(),
                    "conflict selected byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<BigUint>(),
                    "conflict prepared-mask byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    size_of::<usize>(),
                    "conflict compiled-order byte bound overflowed",
                )?,
                checked_mul(
                    size.queue_count,
                    checked_mul(
                        4,
                        size_of::<usize>(),
                        "sparse validation byte width overflowed",
                    )?,
                    "sparse validation byte bound overflowed",
                )?,
            ]
            .into_iter()
            .try_fold(0_usize, |sum, term| {
                checked_add(sum, term, "sparse conflict byte bound overflowed")
            })?;
            (elements, bytes)
        };
    let compile_bytes = [
        checked_mul(
            size.conflict_count,
            size_of::<(QueueIndex, QueueIndex)>(),
            "conflict source-pair byte bound overflowed",
        )?,
        checked_mul(
            size.queue_count,
            size_of::<BigUint>(),
            "conflict prepared-mask byte bound overflowed",
        )?,
        checked_mul(
            size.queue_count,
            checked_mul(
                11,
                size_of::<usize>(),
                "conflict order-temporary byte width overflowed",
            )?,
            "conflict order-temporary byte bound overflowed",
        )?,
        checked_mul(
            2,
            size_of::<usize>(),
            "conflict event sentinel byte bound overflowed",
        )?,
    ]
    .into_iter()
    .try_fold(0_usize, |sum, term| {
        checked_add(sum, term, "conflict compile byte bound overflowed")
    })?;
    Ok((
        compile_elements.max(runtime_elements),
        compile_bytes.max(runtime_bytes),
    ))
}

fn bound_error(error: BoundError) -> PrepareError {
    PrepareError::InvalidNumericSpec {
        path: "/selected_config/scheduler".to_owned(),
        detail: error.to_string(),
    }
}

fn tie_bit(queue_count: usize, rank: usize) -> BigUint {
    BigUint::one() << (queue_count - 1 - rank)
}

fn validate_masks(conflict_masks: &[BigUint]) -> Result<ConflictSize, PrepareError> {
    let queue_count = conflict_masks.len();
    let queue_bits = u64::try_from(queue_count)
        .map_err(|_error| invalid_constraint("conflict queue count exceeds the mask ABI"))?;
    let mut directed_count = 0_usize;
    for (rank, neighbors) in conflict_masks.iter().enumerate() {
        if neighbors.bits() > queue_bits {
            return Err(invalid_constraint(format!(
                "prepared conflict row {rank} has a bit outside dense Q"
            )));
        }
        let rank_bit = u64::try_from(rank)
            .map_err(|_error| invalid_constraint("conflict rank exceeds the mask ABI"))?;
        if neighbors.bit(rank_bit) {
            return Err(invalid_constraint(format!(
                "prepared conflict row {rank} contains a self-loop"
            )));
        }
        directed_count = directed_count
            .checked_add(usize::try_from(neighbors.count_ones()).map_err(|_error| {
                invalid_constraint("conflict degree is not host-representable")
            })?)
            .ok_or_else(|| invalid_constraint("conflict degree sum overflowed"))?;
        for (other, reverse) in conflict_masks.iter().enumerate() {
            let other_bit = u64::try_from(other)
                .map_err(|_error| invalid_constraint("conflict rank exceeds the mask ABI"))?;
            if neighbors.bit(other_bit) != reverse.bit(rank_bit) {
                return Err(invalid_constraint(format!(
                    "prepared conflict rows {rank} and {other} are asymmetric"
                )));
            }
        }
    }
    if directed_count % 2 != 0 {
        return Err(invalid_constraint("prepared conflict degree sum is odd"));
    }
    validate_declared_size(queue_count, directed_count / 2)
}

fn degree_order(conflict_masks: &[BigUint], maximum: bool) -> Vec<usize> {
    let queue_count = conflict_masks.len();
    let mut remaining = vec![true; queue_count];
    let mut degrees = conflict_masks
        .iter()
        .map(|row| usize::try_from(row.count_ones()).unwrap_or(usize::MAX))
        .collect::<Vec<_>>();
    let mut order = Vec::with_capacity(queue_count);
    for _ in 0..queue_count {
        let chosen = (0..queue_count)
            .filter(|rank| remaining[*rank])
            .min_by(|left, right| {
                let compare = if maximum {
                    degrees[*right].cmp(&degrees[*left])
                } else {
                    degrees[*left].cmp(&degrees[*right])
                };
                compare.then_with(|| left.cmp(right))
            })
            .unwrap_or(0);
        remaining[chosen] = false;
        order.push(chosen);
        for rank in 0..queue_count {
            if remaining[rank]
                && conflict_masks[chosen].bit(u64::try_from(rank).unwrap_or(u64::MAX))
            {
                degrees[rank] = degrees[rank].saturating_sub(1);
            }
        }
    }
    order
}

fn maximum_cardinality_order(conflict_masks: &[BigUint]) -> Vec<usize> {
    let queue_count = conflict_masks.len();
    let mut remaining = vec![true; queue_count];
    let mut cardinality = vec![0_usize; queue_count];
    let mut order = Vec::with_capacity(queue_count);
    for _ in 0..queue_count {
        let chosen = (0..queue_count)
            .filter(|rank| remaining[*rank])
            .min_by(|left, right| {
                cardinality[*right]
                    .cmp(&cardinality[*left])
                    .then_with(|| left.cmp(right))
            })
            .unwrap_or(0);
        remaining[chosen] = false;
        order.push(chosen);
        for rank in 0..queue_count {
            if remaining[rank]
                && conflict_masks[chosen].bit(u64::try_from(rank).unwrap_or(u64::MAX))
            {
                cardinality[rank] = cardinality[rank].saturating_add(1);
            }
        }
    }
    order
}

fn positions_and_last(
    conflict_masks: &[BigUint],
    order: &[usize],
) -> Result<(Vec<usize>, Vec<usize>), PrepareError> {
    let queue_count = conflict_masks.len();
    if order.len() != queue_count {
        return Err(invalid_constraint(
            "compiled conflict order does not contain exactly Q vertices",
        ));
    }
    let mut positions = vec![usize::MAX; queue_count];
    for (position, rank) in order.iter().copied().enumerate() {
        if rank >= queue_count || positions[rank] != usize::MAX {
            return Err(invalid_constraint(
                "compiled conflict order is not a dense QueueIndex permutation",
            ));
        }
        positions[rank] = position;
    }
    let mut last = positions.clone();
    for rank in 0..queue_count {
        for other in 0..queue_count {
            if conflict_masks[rank].bit(u64::try_from(other).map_err(|_error| {
                invalid_constraint("conflict rank exceeds the mask ABI")
            })?) {
                last[rank] = last[rank].max(positions[other]);
            }
        }
    }
    Ok((positions, last))
}

fn frontier_width(conflict_masks: &[BigUint], order: &[usize]) -> Result<usize, PrepareError> {
    let (positions, last) = positions_and_last(conflict_masks, order)?;
    let queue_count = conflict_masks.len();
    let mut starts = vec![0_usize; queue_count.saturating_add(1)];
    let mut ends = vec![0_usize; queue_count.saturating_add(1)];
    for rank in 0..queue_count {
        if last[rank] > positions[rank] {
            starts[positions[rank]] = starts[positions[rank]].saturating_add(1);
            ends[last[rank]] = ends[last[rank]].saturating_add(1);
        }
    }
    let mut active = 0_usize;
    let mut maximum = 0_usize;
    for position in 0..queue_count {
        active = active
            .checked_sub(ends[position])
            .ok_or_else(|| invalid_constraint("frontier event program is inconsistent"))?;
        active = active
            .checked_add(starts[position])
            .ok_or_else(|| invalid_constraint("frontier width overflowed"))?;
        maximum = maximum.max(active);
    }
    Ok(maximum)
}

/// Compile a deterministic low-width performance order.  Optimality of the
/// order is unnecessary; optimality of the DP result is independent of it.
pub(crate) fn compile_program(
    conflict_masks: &[BigUint],
) -> Result<CompiledProgram, PrepareError> {
    validate_masks(conflict_masks)?;
    let queue_count = conflict_masks.len();
    let natural = (0..queue_count).collect::<Vec<_>>();
    let mut reverse_natural = natural.clone();
    reverse_natural.reverse();
    let maximum_degree = degree_order(conflict_masks, true);
    let minimum_degree = degree_order(conflict_masks, false);
    let mut reverse_minimum_degree = minimum_degree.clone();
    reverse_minimum_degree.reverse();
    let maximum_cardinality = maximum_cardinality_order(conflict_masks);
    let mut reverse_maximum_cardinality = maximum_cardinality.clone();
    reverse_maximum_cardinality.reverse();
    let candidates = [
        natural,
        reverse_natural,
        maximum_degree,
        minimum_degree,
        reverse_minimum_degree,
        maximum_cardinality,
        reverse_maximum_cardinality,
    ];
    let mut best = None::<(usize, Vec<usize>)>;
    for order in candidates {
        let width = frontier_width(conflict_masks, &order)?;
        let replace = match &best {
            None => true,
            Some((best_width, best_order)) => {
                width < *best_width || (width == *best_width && order < *best_order)
            }
        };
        if replace {
            best = Some((width, order));
        }
    }
    let (maximum_frontier, order) = best.unwrap_or((0, Vec::new()));
    Ok(CompiledProgram {
        order,
        maximum_frontier,
    })
}

pub(crate) fn compile_optimizer(
    queue_count: usize,
    conflicts: Vec<(QueueIndex, QueueIndex)>,
) -> Result<BoundCertified<PreparedServiceOptimizer>, PrepareError> {
    let size = validate_declared_size(queue_count, conflicts.len())?;
    let mut conflict_masks = Vec::new();
    conflict_masks
        .try_reserve_exact(queue_count)
        .map_err(|_error| invalid_constraint("conflict-mask allocation failed"))?;
    conflict_masks.resize(queue_count, BigUint::zero());
    for (position, &(first, second)) in conflicts.iter().enumerate() {
        let first = usize::try_from(first.0)
            .map_err(|_error| invalid_constraint("conflict endpoint exceeds usize"))?;
        let second = usize::try_from(second.0)
            .map_err(|_error| invalid_constraint("conflict endpoint exceeds usize"))?;
        if first >= queue_count || second >= queue_count {
            return Err(invalid_constraint(format!(
                "conflict pair {position} has an endpoint outside dense Q"
            )));
        }
        if first >= second {
            return Err(invalid_constraint(format!(
                "conflict pair {position} must be irreflexive and in canonical queue order"
            )));
        }
        let first_bit = u64::try_from(first)
            .map_err(|_error| invalid_constraint("conflict rank exceeds mask ABI"))?;
        let second_bit = u64::try_from(second)
            .map_err(|_error| invalid_constraint("conflict rank exceeds mask ABI"))?;
        if conflict_masks[first].bit(second_bit) {
            return Err(invalid_constraint(format!(
                "conflict pair {position} duplicates an undirected edge"
            )));
        }
        conflict_masks[first].set_bit(second_bit, true);
        conflict_masks[second].set_bit(first_bit, true);
    }
    let program = compile_program(&conflict_masks)?;
    let (workspace_elements, workspace_bytes) = checked_workspace_bounds(size, &program)?;
    let optimizer = PreparedServiceOptimizer::ConflictGraphExactMwis {
        conflict_masks,
        program,
    };
    let mut contribution = BoundContribution::new(ContributorId::Service(
        ServiceContributor::ConflictGraphExactMwis,
    ));
    for (quantity, upper, label) in [
        (
            QuantityKey::DenseQueueCount,
            size.queue_count,
            "conflict-graph dense queue count",
        ),
        (
            QuantityKey::DenseResourceCount,
            size.conflict_count,
            "conflict-pair resource count",
        ),
        (
            QuantityKey::AllocationElements(AllocationClass::ConstraintWorkspace),
            workspace_elements,
            "conflict structural workspace elements",
        ),
        (
            QuantityKey::AllocationBytes(AllocationClass::ConstraintWorkspace),
            workspace_bytes,
            "conflict structural workspace inline bytes",
        ),
        (
            QuantityKey::WorkStackDepth(WorkStackClass::ConstraintSolver),
            size.stack_frames,
            "conflict sparse exact fallback depth",
        ),
    ] {
        contribution
            .insert(
                quantity,
                exact_usize(upper),
                BoundProvenance::new(
                    BoundStage::ConstraintCompilation,
                    "/selected_config/scheduler",
                    label,
                ),
            )
            .map_err(bound_error)?;
    }
    BoundCertified::new(optimizer, contribution).map_err(bound_error)
}

fn runtime_size(conflict_masks: &[BigUint]) -> Result<ConflictSize, RunError> {
    validate_masks(conflict_masks).map_err(|error| runtime_contract(error.to_string()))
}

fn validate_and_check_schedule(
    conflict_masks: &[BigUint],
    schedule: &[bool],
) -> Result<bool, RunError> {
    // The immutable graph was fully validated when the prepared optimizer and
    // replication scratch were created.  Repeating the O(Q^2) symmetry audit
    // after every hot solve would erase the frontier reformulation's benefit.
    if schedule.len() != conflict_masks.len() {
        return Err(RunError::OptimizerContractViolation {
            stage: RuntimeStage::ActionValidation,
            detail: "conflict schedule must have exactly one bit per dense QueueIndex".to_owned(),
        });
    }
    let mut selected = BigUint::zero();
    for (rank, chosen) in schedule.iter().copied().enumerate() {
        if chosen {
            selected.set_bit(
                u64::try_from(rank)
                    .map_err(|_error| runtime_contract("selected rank exceeds mask ABI"))?,
                true,
            );
        }
    }
    for (rank, chosen) in schedule.iter().copied().enumerate() {
        if chosen && !(&conflict_masks[rank] & &selected).is_zero() {
            return Ok(false);
        }
    }
    Ok(true)
}

pub(super) fn is_feasible(conflict_masks: &[BigUint], schedule: &[bool]) -> Result<bool, RunError> {
    validate_and_check_schedule(conflict_masks, schedule)
}

fn build_frontier_steps(
    conflict_masks: &[BigUint],
    program: &CompiledProgram,
) -> Result<Vec<FrontierStep>, RunError> {
    let (positions, last) = positions_and_last(conflict_masks, &program.order)
        .map_err(|error| runtime_contract(error.to_string()))?;
    if frontier_width(conflict_masks, &program.order)
        .map_err(|error| runtime_contract(error.to_string()))?
        != program.maximum_frontier
    {
        return Err(runtime_contract(
            "compiled frontier width differs from the canonical graph",
        ));
    }
    let mut steps = Vec::new();
    steps
        .try_reserve_exact(conflict_masks.len())
        .map_err(|_error| resource_exhausted("conflict frontier-step allocation failed"))?;
    let mut before = Vec::<usize>::new();
    for (position, vertex) in program.order.iter().copied().enumerate() {
        if positions[vertex] != position {
            return Err(runtime_contract("compiled frontier order is inconsistent"));
        }
        let mut after = before
            .iter()
            .copied()
            .filter(|rank| last[*rank] > position)
            .collect::<Vec<_>>();
        if last[vertex] > position {
            after.push(vertex);
        }
        after.sort_unstable();
        if before.len() > MAX_DENSE_FRONTIER_BITS || after.len() > MAX_DENSE_FRONTIER_BITS {
            return Err(runtime_contract(
                "frontier step exceeds the selected dense-frontier mode",
            ));
        }
        let mut selected_neighbor_mask = 0_usize;
        let mut retained_bits = Vec::new();
        retained_bits
            .try_reserve_exact(before.len())
            .map_err(|_error| resource_exhausted("conflict frontier-map allocation failed"))?;
        for (old_position, rank) in before.iter().copied().enumerate() {
            if conflict_masks[vertex].bit(
                u64::try_from(rank)
                    .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?,
            ) {
                selected_neighbor_mask |= 1_usize << old_position;
            }
            if let Ok(new_position) = after.binary_search(&rank) {
                retained_bits.push((1_usize << old_position, 1_usize << new_position));
            }
        }
        let vertex_after_bit = after
            .binary_search(&vertex)
            .ok()
            .map(|new_position| 1_usize << new_position);
        steps.push(FrontierStep {
            vertex,
            before_width: before.len(),
            selected_neighbor_mask,
            retained_bits,
            vertex_after_bit,
        });
        before = after;
    }
    if !before.is_empty() {
        return Err(runtime_contract("compiled conflict frontier did not close"));
    }
    Ok(steps)
}

#[derive(Debug, Eq, PartialEq)]
enum SolverMode {
    Frontier {
        steps: Vec<FrontierStep>,
        current: Vec<Option<Score>>,
        next: Vec<Option<Score>>,
    },
    Sparse {
        stack: Vec<SparseFrame>,
    },
}

#[derive(Debug, Eq, PartialEq)]
pub(crate) struct SolverScratch {
    queue_count: usize,
    program: CompiledProgram,
    selected_capacity: usize,
    selected: Option<Vec<bool>>,
    mode: SolverMode,
}

impl SolverScratch {
    pub(crate) fn try_new(
        conflict_masks: &[BigUint],
        program: &CompiledProgram,
    ) -> Result<Self, RunError> {
        let size = runtime_size(conflict_masks)?;
        let compiled_width = frontier_width(conflict_masks, &program.order)
            .map_err(|error| runtime_contract(error.to_string()))?;
        if program.order.len() != size.queue_count
            || compiled_width != program.maximum_frontier
        {
            return Err(runtime_contract(
                "compiled conflict program differs from the canonical graph",
            ));
        }
        let mut selected = Vec::new();
        selected
            .try_reserve_exact(size.queue_count)
            .map_err(|_error| resource_exhausted("conflict selected allocation failed"))?;
        selected.resize(size.queue_count, false);
        let selected_capacity = selected.capacity();
        let mode = if program.maximum_frontier <= MAX_DENSE_FRONTIER_BITS {
            let entries = 1_usize
                .checked_shl(u32::try_from(program.maximum_frontier).map_err(|_error| {
                    runtime_contract("frontier width is not shift-representable")
                })?)
                .ok_or_else(|| runtime_contract("frontier table length overflowed"))?;
            let mut current = Vec::new();
            current
                .try_reserve_exact(entries)
                .map_err(|_error| resource_exhausted("frontier current allocation failed"))?;
            current.resize(entries, None);
            let mut next = Vec::new();
            next.try_reserve_exact(entries)
                .map_err(|_error| resource_exhausted("frontier next allocation failed"))?;
            next.resize(entries, None);
            SolverMode::Frontier {
                steps: build_frontier_steps(conflict_masks, program)?,
                current,
                next,
            }
        } else {
            let mut stack = Vec::new();
            stack
                .try_reserve_exact(size.stack_frames)
                .map_err(|_error| resource_exhausted("conflict sparse-stack allocation failed"))?;
            SolverMode::Sparse { stack }
        };
        let mut program_order = Vec::new();
        program_order
            .try_reserve_exact(program.order.len())
            .map_err(|_error| resource_exhausted("conflict program-copy allocation failed"))?;
        program_order.extend_from_slice(&program.order);
        Ok(Self {
            queue_count: size.queue_count,
            program: CompiledProgram {
                order: program_order,
                maximum_frontier: program.maximum_frontier,
            },
            selected_capacity,
            selected: Some(selected),
            mode,
        })
    }

    pub(crate) fn recycle_selected(&mut self, mut selected: Vec<bool>) -> Result<(), RunError> {
        if self.selected.is_some() || selected.len() != self.queue_count {
            return Err(runtime_contract(
                "conflict selected workspace was returned twice or with the wrong width",
            ));
        }
        selected.fill(false);
        self.selected = Some(selected);
        Ok(())
    }

    pub(crate) fn mutable_bytes(&self) -> usize {
        let mode_bytes = match &self.mode {
            SolverMode::Frontier {
                steps,
                current,
                next,
            } => steps
                .capacity()
                .saturating_mul(size_of::<FrontierStep>())
                .saturating_add(
                    steps
                        .iter()
                        .map(|step| {
                            step.retained_bits
                                .capacity()
                                .saturating_mul(size_of::<(usize, usize)>())
                        })
                        .fold(0_usize, usize::saturating_add),
                )
                .saturating_add(
                    current
                        .capacity()
                        .saturating_mul(size_of::<Option<Score>>()),
                )
                .saturating_add(
                    next.capacity()
                        .saturating_mul(size_of::<Option<Score>>()),
                ),
            SolverMode::Sparse { stack } => stack
                .capacity()
                .saturating_mul(size_of::<SparseFrame>()),
        };
        self.selected_capacity
            .saturating_mul(size_of::<bool>())
            .saturating_add(
                self.program
                    .order
                    .capacity()
                    .saturating_mul(size_of::<usize>()),
            )
            .saturating_add(mode_bytes)
    }

    pub(crate) fn logical_exact_integer_payload_bytes(&self) -> usize {
        match &self.mode {
            SolverMode::Frontier { current, next, .. } => current
                .iter()
                .chain(next)
                .filter_map(Option::as_ref)
                .map(Score::logical_payload_bytes)
                .fold(0_usize, usize::saturating_add),
            SolverMode::Sparse { stack } => stack
                .iter()
                .map(SparseFrame::logical_payload_bytes)
                .fold(0_usize, usize::saturating_add),
        }
    }
}

fn score_vertex(weights: &[BigInt], rank: usize) -> Score {
    Score {
        primary: weights[rank].clone(),
        tie: tie_bit(weights.len(), rank),
    }
}

fn retain_better(slot: &mut Option<Score>, candidate: Score) {
    if slot
        .as_ref()
        .is_none_or(|incumbent| candidate.compare(incumbent) == Ordering::Greater)
    {
        *slot = Some(candidate);
    }
}

fn transform_mask(mask: usize, retained_bits: &[(usize, usize)]) -> usize {
    retained_bits
        .iter()
        .filter(|(old, _new)| mask & *old != 0)
        .fold(0_usize, |value, (_old, new)| value | *new)
}

fn solve_frontier<'a>(
    steps: &[FrontierStep],
    mut current: &'a mut [Option<Score>],
    mut next: &'a mut [Option<Score>],
    request: &MaxWeightRequest,
    limits: SearchStateLimits,
    search_states: &mut usize,
) -> Result<Score, RunError> {
    current.fill(None);
    next.fill(None);
    current[0] = Some(Score::zero());
    for step in steps {
        next.fill(None);
        let active = 1_usize
            .checked_shl(u32::try_from(step.before_width).map_err(|_error| {
                runtime_contract("frontier step width is not shift-representable")
            })?)
            .ok_or_else(|| runtime_contract("frontier active-state count overflowed"))?;
        for local_mask in 0..active {
            let Some(score) = current[local_mask].take() else {
                continue;
            };
            limits.charge("conflict_frontier", search_states)?;
            let retained = transform_mask(local_mask, &step.retained_bits);
            retain_better(&mut next[retained], score.clone());
            if request.eligible[step.vertex]
                && local_mask & step.selected_neighbor_mask == 0
            {
                let include_mask = retained | step.vertex_after_bit.unwrap_or(0);
                retain_better(
                    &mut next[include_mask],
                    score.plus(&score_vertex(&request.primary_weights, step.vertex)),
                );
            }
        }
        std::mem::swap(&mut current, &mut next);
    }
    current[0]
        .take()
        .ok_or_else(|| runtime_contract("frontier DP ended without the feasible empty state"))
}

fn lowest_rank(mask: &BigUint) -> Result<usize, RunError> {
    mask.trailing_zeros()
        .ok_or_else(|| runtime_contract("empty conflict mask has no vertex"))
        .and_then(|rank| {
            usize::try_from(rank)
                .map_err(|_error| runtime_contract("conflict rank exceeds usize"))
        })
}

fn choose_branch(conflict_masks: &[BigUint], remaining: &BigUint) -> Result<usize, RunError> {
    let mut chosen = None::<(usize, u64)>;
    for (rank, neighbors) in conflict_masks.iter().enumerate() {
        let bit = u64::try_from(rank)
            .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?;
        if !remaining.bit(bit) {
            continue;
        }
        let degree = (neighbors & remaining).count_ones();
        if chosen.is_none_or(|(old_rank, old_degree)| {
            degree > old_degree || (degree == old_degree && rank < old_rank)
        }) {
            chosen = Some((rank, degree));
        }
    }
    chosen
        .map(|(rank, _degree)| rank)
        .ok_or_else(|| runtime_contract("nonempty conflict state has no branch vertex"))
}

fn reduce_isolated(
    conflict_masks: &[BigUint],
    weights: &[BigInt],
    remaining: &mut BigUint,
    selected: &mut Score,
) -> Result<(), RunError> {
    for rank in 0..conflict_masks.len() {
        let bit = u64::try_from(rank)
            .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?;
        if !remaining.bit(bit) || !(&conflict_masks[rank] & &*remaining).is_zero() {
            continue;
        }
        remaining.set_bit(bit, false);
        if weights[rank] >= BigInt::zero() {
            *selected = selected.plus(&score_vertex(weights, rank));
        }
    }
    Ok(())
}

fn clique_upper_bound(
    conflict_masks: &[BigUint],
    weights: &[BigInt],
    remaining: &BigUint,
) -> Result<Score, RunError> {
    let mut pending = remaining.clone();
    let mut primary = BigInt::zero();
    while !pending.is_zero() {
        let seed = lowest_rank(&pending)?;
        let seed_bit = u64::try_from(seed)
            .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?;
        let mut clique = BigUint::zero();
        clique.set_bit(seed_bit, true);
        pending.set_bit(seed_bit, false);
        for (rank, neighbors) in conflict_masks.iter().enumerate() {
            let bit = u64::try_from(rank)
                .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?;
            if pending.bit(bit) && (neighbors & &clique) == clique {
                clique.set_bit(bit, true);
                pending.set_bit(bit, false);
            }
        }
        let mut maximum = BigInt::zero();
        for (rank, weight) in weights.iter().enumerate() {
            if clique.bit(u64::try_from(rank).map_err(|_error| {
                runtime_contract("conflict rank exceeds mask ABI")
            })?) && weight > &maximum
            {
                maximum.clone_from(weight);
            }
        }
        primary += maximum;
    }
    let mut tie = BigUint::zero();
    for rank in 0..weights.len() {
        if remaining.bit(
            u64::try_from(rank)
                .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?,
        ) {
            tie |= tie_bit(weights.len(), rank);
        }
    }
    Ok(Score { primary, tie })
}

fn push_sparse(
    stack: &mut Vec<SparseFrame>,
    frame: SparseFrame,
    limit: usize,
) -> Result<(), RunError> {
    if stack.len() >= limit {
        return Err(resource_exhausted(
            "conflict sparse exact stack capacity was exhausted",
        ));
    }
    stack.push(frame);
    Ok(())
}

fn solve_sparse(
    conflict_masks: &[BigUint],
    request: &MaxWeightRequest,
    limits: SearchStateLimits,
    search_states: &mut usize,
    stack: &mut Vec<SparseFrame>,
) -> Result<Score, RunError> {
    stack.clear();
    let mut root = BigUint::zero();
    for (rank, eligible) in request.eligible.iter().copied().enumerate() {
        if eligible {
            root.set_bit(
                u64::try_from(rank)
                    .map_err(|_error| runtime_contract("eligible rank exceeds mask ABI"))?,
                true,
            );
        }
    }
    let limit = conflict_masks.len().saturating_add(1);
    push_sparse(
        stack,
        SparseFrame {
            remaining: root,
            selected: Score::zero(),
        },
        limit,
    )?;
    let mut incumbent = Score::zero();
    while let Some(mut frame) = stack.pop() {
        limits.charge("conflict_sparse", search_states)?;
        reduce_isolated(
            conflict_masks,
            &request.primary_weights,
            &mut frame.remaining,
            &mut frame.selected,
        )?;
        if frame.remaining.is_zero() {
            if frame.selected.compare(&incumbent) == Ordering::Greater {
                incumbent = frame.selected;
            }
            continue;
        }
        let upper = frame.selected.plus(&clique_upper_bound(
            conflict_masks,
            &request.primary_weights,
            &frame.remaining,
        )?);
        if upper.compare(&incumbent) != Ordering::Greater {
            continue;
        }
        let vertex = choose_branch(conflict_masks, &frame.remaining)?;
        let vertex_bit = u64::try_from(vertex)
            .map_err(|_error| runtime_contract("conflict rank exceeds mask ABI"))?;
        let mut exclude_remaining = frame.remaining.clone();
        exclude_remaining.set_bit(vertex_bit, false);
        push_sparse(
            stack,
            SparseFrame {
                remaining: exclude_remaining,
                selected: frame.selected.clone(),
            },
            limit,
        )?;
        let mut forbidden = conflict_masks[vertex].clone();
        forbidden.set_bit(vertex_bit, true);
        let removed = &frame.remaining & &forbidden;
        let include_remaining = &frame.remaining ^ &removed;
        push_sparse(
            stack,
            SparseFrame {
                remaining: include_remaining,
                selected: frame
                    .selected
                    .plus(&score_vertex(&request.primary_weights, vertex)),
            },
            limit,
        )?;
    }
    Ok(incumbent)
}

pub(crate) fn solve_with_scratch(
    conflict_masks: &[BigUint],
    program: &CompiledProgram,
    request: &MaxWeightRequest,
    limits: SearchStateLimits,
    search_states_used: &mut usize,
    scratch: &mut SolverScratch,
) -> Result<Option<CandidateAction>, RunError> {
    if request.primary_weights.len() != conflict_masks.len()
        || request.eligible.len() != conflict_masks.len()
    {
        return Err(runtime_contract(
            "conflict weights and eligibility must have exactly Q entries",
        ));
    }
    if scratch.queue_count != conflict_masks.len() || &scratch.program != program {
        return Err(runtime_contract(
            "conflict replication scratch has the wrong compiled topology",
        ));
    }
    let exact_result = match &mut scratch.mode {
        SolverMode::Frontier {
            steps,
            current,
            next,
        } => solve_frontier(
            steps,
            current,
            next,
            request,
            limits,
            search_states_used,
        ),
        SolverMode::Sparse { stack } => solve_sparse(
            conflict_masks,
            request,
            limits,
            search_states_used,
            stack,
        ),
    };
    if exact_result.is_err() {
        match &mut scratch.mode {
            SolverMode::Frontier { current, next, .. } => {
                current.fill(None);
                next.fill(None);
            }
            SolverMode::Sparse { stack } => stack.clear(),
        }
    }
    let exact = exact_result?;
    let mut selected = scratch
        .selected
        .take()
        .ok_or_else(|| runtime_contract("conflict selected workspace is already checked out"))?;
    selected.fill(false);
    let queue_count = selected.len();
    for (rank, bit) in selected.iter_mut().enumerate() {
        *bit = exact.tie.bit(
            u64::try_from(queue_count - 1 - rank)
                .map_err(|_error| runtime_contract("tie rank exceeds mask ABI"))?,
        );
    }
    match validate_and_check_schedule(conflict_masks, &selected) {
        Err(error) => {
            scratch.selected = Some(selected);
            return Err(error);
        }
        Ok(false) => {
            scratch.selected = Some(selected);
            return Err(RunError::ExactOptimizerFailure {
                stage: RuntimeStage::ColdMaxWeightSolve,
                detail: "conflict MWIS solver reconstructed a conflicting schedule".to_owned(),
            });
        }
        Ok(true) => {}
    }
    Ok(Some(CandidateAction {
        selected,
        primary_objective: exact.primary,
        tie_refinement: exact.tie,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn masks(queue_count: usize, edges: &[(usize, usize)]) -> Vec<BigUint> {
        let mut result = vec![BigUint::zero(); queue_count];
        for &(left, right) in edges {
            result[left].set_bit(u64::try_from(right).expect("test rank"), true);
            result[right].set_bit(u64::try_from(left).expect("test rank"), true);
        }
        result
    }

    fn unlimited() -> SearchStateLimits {
        SearchStateLimits {
            authored_per_call: None,
            remaining_total: None,
        }
    }

    fn solve(graph: &[BigUint], weights: Vec<BigInt>) -> CandidateAction {
        let program = compile_program(graph).expect("compile conflict program");
        let mut scratch = SolverScratch::try_new(graph, &program).expect("allocate scratch");
        let request = MaxWeightRequest {
            eligible: vec![true; graph.len()],
            primary_weights: weights,
        };
        let mut states = 0;
        solve_with_scratch(
            graph,
            &program,
            &request,
            unlimited(),
            &mut states,
            &mut scratch,
        )
        .expect("exact solve")
        .expect("Free class incumbent")
    }

    #[test]
    fn frontier_dp_matches_exhaustive_primary_and_tie() {
        let graph = masks(7, &[(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (0, 6), (1, 5)]);
        let weights = [-1_i8, 3, 0, 2, 3, -2, 1]
            .into_iter()
            .map(BigInt::from)
            .collect::<Vec<_>>();
        let candidate = solve(&graph, weights.clone());

        let mut expected = Score::zero();
        for subset in 0_usize..(1_usize << graph.len()) {
            let feasible = (0..graph.len()).all(|rank| {
                subset & (1_usize << rank) == 0
                    || (0..graph.len()).all(|other| {
                        subset & (1_usize << other) == 0
                            || !graph[rank].bit(u64::try_from(other).expect("test rank"))
                    })
            });
            if !feasible {
                continue;
            }
            let score = (0..graph.len())
                .filter(|rank| subset & (1_usize << rank) != 0)
                .fold(Score::zero(), |sum, rank| {
                    sum.plus(&score_vertex(&weights, rank))
                });
            if score.compare(&expected) == Ordering::Greater {
                expected = score;
            }
        }
        assert_eq!(candidate.primary_objective, expected.primary);
        assert_eq!(candidate.tie_refinement, expected.tie);
    }

    #[test]
    fn frontier_dp_excludes_ineligible_weight_and_includes_zero_tie_bits() {
        let graph = masks(3, &[]);
        let program = compile_program(&graph).expect("compile empty graph");
        let mut scratch = SolverScratch::try_new(&graph, &program).expect("allocate scratch");
        let request = MaxWeightRequest {
            primary_weights: vec![
                BigInt::from(100_u8),
                BigInt::zero(),
                BigInt::zero(),
            ],
            eligible: vec![false, true, true],
        };
        let mut states = 0;
        let candidate = solve_with_scratch(
            &graph,
            &program,
            &request,
            unlimited(),
            &mut states,
            &mut scratch,
        )
        .expect("solve")
        .expect("incumbent");
        assert_eq!(candidate.selected, vec![false, true, true]);
        assert_eq!(candidate.primary_objective, BigInt::zero());
    }

    #[test]
    fn thirty_two_queue_star_uses_width_one_frontier() {
        let edges = (1..32).map(|leaf| (0, leaf)).collect::<Vec<_>>();
        let graph = masks(32, &edges);
        let program = compile_program(&graph).expect("compile campaign star");
        assert_eq!(program.maximum_frontier, 1);
        let scratch = SolverScratch::try_new(&graph, &program).expect("allocate scratch");
        assert!(matches!(&scratch.mode, SolverMode::Frontier { .. }));
    }

    #[test]
    fn seventy_queue_star_has_no_machine_word_boundary() {
        let edges = (1..70).map(|leaf| (0, leaf)).collect::<Vec<_>>();
        let graph = masks(70, &edges);
        let program = compile_program(&graph).expect("compile star");
        assert_eq!(program.maximum_frontier, 1);
        let candidate = solve(&graph, vec![BigInt::from(1_u8); 70]);
        assert!(!candidate.selected[0]);
        assert!(candidate.selected[1..].iter().all(|selected| *selected));
        assert_eq!(candidate.primary_objective, BigInt::from(69_u8));
        assert!(candidate.tie_refinement.bits() > 64);
    }

    #[test]
    fn wide_frontier_uses_sparse_exact_fallback() {
        let queue_count = MAX_DENSE_FRONTIER_BITS + 2;
        let edges = (0..queue_count)
            .flat_map(|left| ((left + 1)..queue_count).map(move |right| (left, right)))
            .collect::<Vec<_>>();
        let graph = masks(queue_count, &edges);
        let program = compile_program(&graph).expect("compile clique");
        let scratch = SolverScratch::try_new(&graph, &program).expect("allocate sparse scratch");
        assert!(matches!(&scratch.mode, SolverMode::Sparse { .. }));
        let candidate = solve(&graph, vec![BigInt::from(5_u8); queue_count]);
        assert!(candidate.selected[0]);
        assert_eq!(candidate.selected.iter().filter(|bit| **bit).count(), 1);
    }
}
