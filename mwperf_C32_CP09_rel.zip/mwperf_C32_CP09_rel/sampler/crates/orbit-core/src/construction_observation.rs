//! JSON-free construction-observation records shared by weighted-ensemble and
//! ordinary executions.
//!
//! The types in this module are scientific primitives, not a response law and
//! not a deployed metric capability.  Wire spelling, member order, and digest
//! sealing remain the responsibility of the hosted-provider crate.

use num_bigint::BigInt;
use thiserror::Error;

use crate::exact::{ExactRational, ExactUnsigned};
use crate::resolved::TypedId;

/// A canonical SHA-256 digest carried by an observation binding.
pub type ObservationDigestV1 = [u8; 32];

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObservationSourceRoleV1 {
    WeightedEnsemble,
    ShortRestartReference,
    LongStationaryReference,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObservationScalarRepresentationV1 {
    ExactRational,
    EnclosedBinary64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObservationCompletenessV1 {
    Complete,
    Partial,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObservationNormalizationClaimV1 {
    Exact,
    Enclosed,
    NotClaimed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObservationSlotStageV1 {
    SolvePrimaryMaxWeight,
    ObservePreService,
    ApplyActualService,
    ClassifyAndResample,
    AllocateChildLineage,
    ApplyFreshLateArrival,
    CommitPostSlotState,
    EmitCommittedObservation,
}

/// One finite binary64 value and its deterministic absolute/L1 enclosure.
///
/// Bits are retained rather than an `f64` so equality is the canonical wire
/// equality and negative zero cannot be introduced by a later encoder.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct EnclosedBinary64V1 {
    pub value_bits: u64,
    pub absolute_error_bits: u64,
    pub l1_norm_bits: u64,
}

impl EnclosedBinary64V1 {
    pub fn try_new(
        value: f64,
        absolute_error: f64,
        l1_norm: f64,
    ) -> Result<Self, ConstructionObservationError> {
        require_finite_not_negative_zero(value, "observation scalar")?;
        require_nonnegative_finite(absolute_error, "observation absolute error")?;
        require_nonnegative_finite(l1_norm, "observation L1 norm")?;
        if l1_norm < value.abs() || l1_norm < absolute_error {
            return Err(ConstructionObservationError::InvalidValue {
                detail: "observation L1 norm does not enclose value and absolute error",
            });
        }
        Ok(Self {
            value_bits: value.to_bits(),
            absolute_error_bits: absolute_error.to_bits(),
            l1_norm_bits: l1_norm.to_bits(),
        })
    }

    pub fn value(self) -> f64 {
        f64::from_bits(self.value_bits)
    }

    pub fn absolute_error(self) -> f64 {
        f64::from_bits(self.absolute_error_bits)
    }

    pub fn l1_norm(self) -> f64 {
        f64::from_bits(self.l1_norm_bits)
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum ObservationScalarV1 {
    Exact(ExactRational),
    EnclosedBinary64(EnclosedBinary64V1),
}

impl ObservationScalarV1 {
    pub fn exact_u128(value: u128) -> Self {
        Self::Exact(ExactRational::from_integer(BigInt::from(value)))
    }

    pub fn exact_i128(value: i128) -> Self {
        Self::Exact(ExactRational::from_integer(BigInt::from(value)))
    }

    pub fn enclosed(
        value: f64,
        absolute_error: f64,
        l1_norm: f64,
    ) -> Result<Self, ConstructionObservationError> {
        Ok(Self::EnclosedBinary64(EnclosedBinary64V1::try_new(
            value,
            absolute_error,
            l1_norm,
        )?))
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct ObservationMassBalanceV1 {
    pub claim: ObservationNormalizationClaimV1,
    pub recorded_mass: ObservationScalarV1,
    pub signed_mass_defect: ObservationScalarV1,
}

impl ObservationMassBalanceV1 {
    pub fn exact(recorded_mass: u128, expected_mass: u128) -> Self {
        let signed_mass_defect = if recorded_mass >= expected_mass {
            let difference = recorded_mass - expected_mass;
            ObservationScalarV1::exact_u128(difference)
        } else {
            let difference = expected_mass - recorded_mass;
            let signed = -BigInt::from(difference);
            ObservationScalarV1::Exact(ExactRational::from_integer(signed))
        };
        Self {
            claim: ObservationNormalizationClaimV1::Exact,
            recorded_mass: ObservationScalarV1::exact_u128(recorded_mass),
            signed_mass_defect,
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct ObservationGapCellV1 {
    pub negative_mass: ObservationScalarV1,
    pub tie_mass: ObservationScalarV1,
    pub positive_mass: ObservationScalarV1,
    pub tied_and_served_mass: ObservationScalarV1,
    pub positive_magnitude_mass: ObservationScalarV1,
    pub negative_magnitude_mass: ObservationScalarV1,
}

#[derive(Clone, Debug, PartialEq)]
pub struct ExactLevelObservationV1 {
    pub backlog_level: ExactUnsigned,
    pub exposure_mass: ObservationScalarV1,
    pub served_mass: ObservationScalarV1,
    pub gap: Option<ObservationGapCellV1>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct BoundaryBacklogMassV1 {
    pub backlog_level: ExactUnsigned,
    pub mass: ObservationScalarV1,
}

#[derive(Clone, Debug, PartialEq)]
pub struct BoundaryBacklogLawV1 {
    pub boundary: u64,
    pub rows: Vec<BoundaryBacklogMassV1>,
    pub mass_balance: ObservationMassBalanceV1,
}

#[derive(Clone, Debug, PartialEq)]
pub struct ConstructionObservationBlockV1 {
    pub begin_boundary: u64,
    pub end_boundary: u64,
    pub completeness: ObservationCompletenessV1,
    pub committed_through_boundary: u64,
    pub levels: Vec<ExactLevelObservationV1>,
    pub exposure_mass_balance: ObservationMassBalanceV1,
    pub initial_boundary_law: BoundaryBacklogLawV1,
    pub committed_boundary_law: BoundaryBacklogLawV1,
}

#[derive(Clone, Debug, PartialEq)]
pub struct ConstructionObservationReplicationV1 {
    pub replication_id: TypedId,
    pub replay_identity: ObservationDigestV1,
    pub lineage_arrival_identity: Option<ObservationDigestV1>,
    pub completeness: ObservationCompletenessV1,
    pub committed_through_boundary: u64,
    pub blocks: Vec<ConstructionObservationBlockV1>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactTargetArrivalAtomV1 {
    pub batch_size: ExactUnsigned,
    pub probability: ExactRational,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExactTargetArrivalMarginalV1 {
    pub atoms: Vec<ExactTargetArrivalAtomV1>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetArrivalOvershootDescriptorV1 {
    pub descriptor_id: String,
    pub descriptor_version: u32,
    pub descriptor_digest: ObservationDigestV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TargetArrivalDescriptionV1 {
    ExactMarginal(ExactTargetArrivalMarginalV1),
    OvershootDescriptor(TargetArrivalOvershootDescriptorV1),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationArrivalBindingV1 {
    pub arrival_family_id: String,
    pub configured_law_digest: ObservationDigestV1,
    pub target_arrival: TargetArrivalDescriptionV1,
    pub mean: ExactRational,
    pub second_moment: ExactRational,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationTargetBindingV1 {
    pub target_id: TypedId,
    pub target_index: u64,
    pub maxweight_multiplier: ExactRational,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationScientificBindingsV1 {
    pub request_digest: ObservationDigestV1,
    pub problem_digest: ObservationDigestV1,
    pub experiment_digest: ObservationDigestV1,
    pub target: ObservationTargetBindingV1,
    pub arrival: ObservationArrivalBindingV1,
    pub topology_digest: ObservationDigestV1,
    pub scheduler_digest: ObservationDigestV1,
    pub optimizer_digest: ObservationDigestV1,
    pub primary_objective_digest: ObservationDigestV1,
    pub priority_digest: ObservationDigestV1,
    pub tie_policy_digest: ObservationDigestV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationSlotConventionV1 {
    pub step_order: Vec<ObservationSlotStageV1>,
    pub convention_digest: ObservationDigestV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationInitializationV1 {
    pub initial_law_id: String,
    pub initial_law_digest: ObservationDigestV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationRngBindingV1 {
    pub rng_abi_id: String,
    pub rng_abi_version: u32,
    pub construction_seed_policy_digest: ObservationDigestV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationCapabilityStateV1 {
    pub available: bool,
    pub unavailable_reason_code: Option<String>,
}

impl ObservationCapabilityStateV1 {
    pub const fn available() -> Self {
        Self {
            available: true,
            unavailable_reason_code: None,
        }
    }

    pub fn unavailable(reason_code: impl Into<String>) -> Self {
        Self {
            available: false,
            unavailable_reason_code: Some(reason_code.into()),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationCapabilitiesV1 {
    pub iid_fresh_arrivals: ObservationCapabilityStateV1,
    pub finite_arrival_second_moment: ObservationCapabilityStateV1,
    pub exact_target_arrival_marginal: ObservationCapabilityStateV1,
    pub no_target_drops: ObservationCapabilityStateV1,
    pub exact_primary_maxweight: ObservationCapabilityStateV1,
    pub unit_target_multiplier: ObservationCapabilityStateV1,
    pub certified_gap_probe: ObservationCapabilityStateV1,
}

#[derive(Clone, Debug, PartialEq)]
pub struct ConstructionObservationBundleV1 {
    pub schema_version: u32,
    pub source_role: ObservationSourceRoleV1,
    pub scalar_representation: ObservationScalarRepresentationV1,
    pub bindings: ObservationScientificBindingsV1,
    pub slot_convention: ObservationSlotConventionV1,
    pub initialization: ObservationInitializationV1,
    pub rng: ObservationRngBindingV1,
    pub warmup_boundary: u64,
    pub end_boundary: u64,
    pub reporting_block_boundaries: Vec<u64>,
    pub capabilities: ObservationCapabilitiesV1,
    pub replications: Vec<ConstructionObservationReplicationV1>,
}

/// Validated runtime geometry and storage caps for one observation record.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObservationPlanV1 {
    pub warmup_boundary: u64,
    pub end_boundary: u64,
    pub reporting_block_boundaries: Box<[u64]>,
    /// Combined serialized level plus initial/committed-boundary row cap.
    /// The two following limits are reservation/admission subcaps only and
    /// never authorize this shared request cap to be exceeded.
    pub maximum_total_rows_per_replication: usize,
    pub maximum_sparse_rows_per_replication: usize,
    pub maximum_boundary_rows_per_replication: usize,
    pub gap_telemetry: bool,
}

/// Additive diagnostic-plane work only. These counters are intentionally
/// separate from the frozen optimizer/RNG work report.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ObservationWorkCountersV1 {
    committed_rows: u128,
    new_sparse_keys: u128,
    gap_evaluations: u128,
    boundary_scans: u128,
    schedule_cache_hits: u128,
    schedule_cache_keys: u128,
    prepared_capacity_allocations: u128,
    prepared_capacity_units: u128,
}

#[allow(clippy::cast_lossless)]
impl ObservationWorkCountersV1 {
    /// Committed weighted parent-row visits (`P` per measured slot), not the
    /// number of serialized sparse level rows and not a row-cap quantity.
    pub const fn committed_rows(self) -> u128 {
        self.committed_rows
    }

    pub const fn new_sparse_keys(self) -> u128 {
        self.new_sparse_keys
    }

    /// Certified gap-probe invocations actually attempted, including a
    /// prospective slot that is later refused before commit.
    pub const fn gap_evaluations(self) -> u128 {
        self.gap_evaluations
    }

    /// Number of particle-state visits across all requested/partial boundary
    /// scans (one boundary event contributes exactly `P`).
    pub const fn boundary_scans(self) -> u128 {
        self.boundary_scans
    }

    /// Successful full-state schedule-cache lookups actually performed by
    /// diagnostics-enabled weighted-ensemble attempts.
    pub const fn schedule_cache_hits(self) -> u128 {
        self.schedule_cache_hits
    }

    /// Distinct full-state keys actually inserted after successful optimizer
    /// cache misses. Failed solver calls are not keys.
    pub const fn schedule_cache_keys(self) -> u128 {
        self.schedule_cache_keys
    }

    pub const fn prepared_capacity_allocations(self) -> u128 {
        self.prepared_capacity_allocations
    }

    pub const fn prepared_capacity_units(self) -> u128 {
        self.prepared_capacity_units
    }

    pub(crate) fn record_committed_rows(&mut self, count: usize) {
        self.committed_rows = self
            .committed_rows
            .checked_add(count as u128)
            .expect("request-bounded row work fits u128");
    }

    pub(crate) fn record_new_sparse_keys(&mut self, count: usize) {
        self.new_sparse_keys = self
            .new_sparse_keys
            .checked_add(count as u128)
            .expect("request-bounded sparse-key work fits u128");
    }

    pub(crate) fn record_gap_evaluations(&mut self, count: usize) {
        self.gap_evaluations = self
            .gap_evaluations
            .checked_add(count as u128)
            .expect("request-bounded gap work fits u128");
    }

    /// Count particle-state visits performed by boundary scans, not boundary
    /// callback events. Admission includes every requested edge plus one
    /// possible failed-prospective/partial-terminal scan per replication.
    pub(crate) fn record_boundary_scan(&mut self, particle_visits: usize) {
        self.boundary_scans = self
            .boundary_scans
            .checked_add(particle_visits as u128)
            .expect("request-bounded boundary work fits u128");
    }

    pub(crate) fn record_schedule_cache_hits(&mut self, count: usize) {
        self.schedule_cache_hits = self
            .schedule_cache_hits
            .checked_add(count as u128)
            .expect("request-bounded schedule-cache hit work fits u128");
    }

    pub(crate) fn record_schedule_cache_keys(&mut self, count: usize) {
        self.schedule_cache_keys = self
            .schedule_cache_keys
            .checked_add(count as u128)
            .expect("request-bounded schedule-cache key work fits u128");
    }

    pub(crate) fn record_prepared_capacity(&mut self, allocations: u128, units: usize) {
        self.prepared_capacity_allocations = self
            .prepared_capacity_allocations
            .checked_add(allocations)
            .expect("request-bounded preparation work fits u128");
        self.prepared_capacity_units = self
            .prepared_capacity_units
            .checked_add(units as u128)
            .expect("request-bounded prepared capacity fits u128");
    }

    pub(crate) fn merge(&mut self, other: Self) {
        self.committed_rows = self
            .committed_rows
            .checked_add(other.committed_rows)
            .expect("coordinator-admitted row work fits u128");
        self.new_sparse_keys = self
            .new_sparse_keys
            .checked_add(other.new_sparse_keys)
            .expect("coordinator-admitted sparse-key work fits u128");
        self.gap_evaluations = self
            .gap_evaluations
            .checked_add(other.gap_evaluations)
            .expect("coordinator-admitted gap work fits u128");
        self.boundary_scans = self
            .boundary_scans
            .checked_add(other.boundary_scans)
            .expect("coordinator-admitted boundary work fits u128");
        self.schedule_cache_hits = self
            .schedule_cache_hits
            .checked_add(other.schedule_cache_hits)
            .expect("coordinator-admitted schedule-cache hits fit u128");
        self.schedule_cache_keys = self
            .schedule_cache_keys
            .checked_add(other.schedule_cache_keys)
            .expect("coordinator-admitted schedule-cache keys fit u128");
        self.prepared_capacity_allocations = self
            .prepared_capacity_allocations
            .checked_add(other.prepared_capacity_allocations)
            .expect("coordinator-admitted allocation work fits u128");
        self.prepared_capacity_units = self
            .prepared_capacity_units
            .checked_add(other.prepared_capacity_units)
            .expect("coordinator-admitted capacity work fits u128");
    }
}

impl ObservationPlanV1 {
    #[allow(clippy::too_many_arguments)]
    pub fn try_new(
        warmup_boundary: u64,
        end_boundary: u64,
        reporting_block_boundaries: Vec<u64>,
        maximum_sparse_rows_per_replication: usize,
        maximum_boundary_rows_per_replication: usize,
        gap_telemetry: bool,
    ) -> Result<Self, ConstructionObservationError> {
        Self::try_new_with_total_cap(
            warmup_boundary,
            end_boundary,
            reporting_block_boundaries,
            maximum_sparse_rows_per_replication
                .max(maximum_boundary_rows_per_replication),
            maximum_sparse_rows_per_replication,
            maximum_boundary_rows_per_replication,
            gap_telemetry,
        )
    }

    /// Prepare independently bounded raw-observation arenas under one shared
    /// serialized-row cap.  CP09 uses the physical P*(T-W) and boundary-law
    /// attainability bounds here instead of eagerly reserving an authored cap
    /// that can be orders of magnitude larger than the run can populate.
    #[allow(clippy::too_many_arguments)]
    pub fn try_new_with_total_cap(
        warmup_boundary: u64,
        end_boundary: u64,
        reporting_block_boundaries: Vec<u64>,
        maximum_total_rows_per_replication: usize,
        maximum_sparse_rows_per_replication: usize,
        maximum_boundary_rows_per_replication: usize,
        gap_telemetry: bool,
    ) -> Result<Self, ConstructionObservationError> {
        if warmup_boundary >= end_boundary {
            return Err(ConstructionObservationError::InvalidPlan {
                detail: "the observation window must satisfy W < T",
            });
        }
        if reporting_block_boundaries.len() < 2
            || reporting_block_boundaries.first().copied() != Some(warmup_boundary)
            || reporting_block_boundaries.last().copied() != Some(end_boundary)
            || reporting_block_boundaries
                .windows(2)
                .any(|pair| pair[0] >= pair[1])
        {
            return Err(ConstructionObservationError::InvalidPlan {
                detail: "reporting boundaries must be strictly increasing absolute W..T edges",
            });
        }
        if maximum_total_rows_per_replication == 0
            || maximum_sparse_rows_per_replication == 0
            || maximum_boundary_rows_per_replication == 0
            || maximum_sparse_rows_per_replication > maximum_total_rows_per_replication
            || maximum_boundary_rows_per_replication > maximum_total_rows_per_replication
        {
            return Err(ConstructionObservationError::InvalidPlan {
                detail: "observation row caps must be positive subcaps of the shared total cap",
            });
        }
        Ok(Self {
            warmup_boundary,
            end_boundary,
            reporting_block_boundaries: reporting_block_boundaries.into_boxed_slice(),
            maximum_total_rows_per_replication,
            maximum_sparse_rows_per_replication,
            maximum_boundary_rows_per_replication,
            gap_telemetry,
        })
    }

    pub fn block_count(&self) -> usize {
        self.reporting_block_boundaries.len() - 1
    }

    pub fn block_index_for_slot(&self, physical_slot: u64) -> Option<usize> {
        if physical_slot < self.warmup_boundary || physical_slot >= self.end_boundary {
            return None;
        }
        Some(
            self.reporting_block_boundaries
                .partition_point(|boundary| *boundary <= physical_slot)
                - 1,
        )
    }

    pub fn is_reporting_boundary(&self, boundary: u64) -> bool {
        self.reporting_block_boundaries.binary_search(&boundary).is_ok()
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum GapSignV1 {
    Negative,
    Tie,
    Positive,
}

/// Allocation-free output shape expected from a prepared exact gap probe.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GapObservationValueV1 {
    competition_scale: u128,
    sign: GapSignV1,
    magnitude: u128,
}

impl GapObservationValueV1 {
    pub const fn new(competition_scale: u128, sign: GapSignV1, magnitude: u128) -> Self {
        Self {
            competition_scale,
            sign,
            magnitude,
        }
    }

    pub const fn competition_scale(self) -> u128 {
        self.competition_scale
    }

    pub const fn sign(self) -> GapSignV1 {
        self.sign
    }

    pub const fn magnitude(self) -> u128 {
        self.magnitude
    }
}

/// Deterministic nonnegative binary64 accumulator used only by the new
/// observation plane.  The legacy response ledger deliberately does not use
/// this type, preserving its frozen addition and division order.
#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct EnclosedBinary64AccumulatorV1 {
    sum: f64,
    correction: f64,
    direct_sum: f64,
    direct_roundoff: f64,
    input_error: f64,
    l1_norm: f64,
    l1_roundoff: f64,
}

impl EnclosedBinary64AccumulatorV1 {
    pub(crate) fn add_nonnegative(
        &mut self,
        value: f64,
    ) -> Result<(), ConstructionObservationError> {
        self.add_nonnegative_with_error(value, 0.0)
    }

    fn add_nonnegative_with_error(
        &mut self,
        value: f64,
        input_error: f64,
    ) -> Result<(), ConstructionObservationError> {
        require_nonnegative_finite(value, "observation accumulator addend")?;
        require_nonnegative_finite(input_error, "observation addend error")?;
        if value == 0.0 && input_error == 0.0 {
            return Ok(());
        }
        let adjusted = value - self.correction;
        let updated = self.sum + adjusted;
        if !adjusted.is_finite() || !updated.is_finite() {
            return Err(ConstructionObservationError::NumericalOverflow {
                quantity: "observation compensated sum",
            });
        }
        self.correction = (updated - self.sum) - adjusted;
        self.sum = updated;

        let (direct_sum, direct_residual) = two_sum(self.direct_sum, value)?;
        self.direct_sum = direct_sum;
        self.direct_roundoff = upper_add(self.direct_roundoff, direct_residual.abs())?;
        self.input_error = upper_add(self.input_error, input_error)?;
        let addend_l1 = upper_add(value, input_error)?;
        let (l1_norm, l1_residual) = two_sum(self.l1_norm, addend_l1)?;
        self.l1_norm = l1_norm;
        self.l1_roundoff = upper_add(self.l1_roundoff, l1_residual.abs())?;
        Ok(())
    }

    #[allow(clippy::cast_precision_loss)]
    pub(crate) fn add_weighted_u128(
        &mut self,
        weight: f64,
        magnitude: u128,
    ) -> Result<(), ConstructionObservationError> {
        require_nonnegative_finite(weight, "observation weight")?;
        let magnitude_binary64 = magnitude as f64;
        let value = weight * magnitude_binary64;
        require_nonnegative_finite(value, "weighted observation magnitude")?;
        let conversion_error = if magnitude <= (1_u128 << 53) {
            0.0
        } else {
            next_up(magnitude_binary64) - magnitude_binary64
        };
        let conversion_product = outward_multiply_nonnegative(weight, conversion_error)?;
        let product_roundoff = if value == 0.0 {
            0.0
        } else {
            next_up(value) - value
        };
        let input_error = upper_add(conversion_product, product_roundoff)?;
        self.add_nonnegative_with_error(value, input_error)
    }

    pub(crate) fn finish(self) -> Result<EnclosedBinary64V1, ConstructionObservationError> {
        let center_distance = upper_distance(self.sum, self.direct_sum)?;
        let summation_error = upper_add(center_distance, self.direct_roundoff)?;
        let absolute_error = upper_add(summation_error, self.input_error)?;
        let l1_norm = upper_add(self.l1_norm, self.l1_roundoff)?.max(absolute_error);
        EnclosedBinary64V1::try_new(self.sum, absolute_error, l1_norm)
    }

}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum ConstructionObservationError {
    #[error("invalid observation plan: {detail}")]
    InvalidPlan { detail: &'static str },
    #[error("invalid observation value: {detail}")]
    InvalidValue { detail: &'static str },
    #[error("observation allocation failed while preparing {operation}")]
    CapacityExceeded { operation: &'static str },
    #[error("observation row cap was exhausted")]
    RowCapExhausted,
    #[error("observation boundary-row cap was exhausted")]
    BoundaryRowCapExhausted,
    #[error("observation counter overflowed: {counter}")]
    CounterOverflow { counter: &'static str },
    #[error("observation numerical quantity overflowed: {quantity}")]
    NumericalOverflow { quantity: &'static str },
    #[error("certified gap probe failed: {code}")]
    GapProbeFailure { code: &'static str },
}

fn require_finite_not_negative_zero(
    value: f64,
    detail: &'static str,
) -> Result<(), ConstructionObservationError> {
    if !value.is_finite() || value.to_bits() == (-0.0_f64).to_bits() {
        return Err(ConstructionObservationError::InvalidValue { detail });
    }
    Ok(())
}

fn require_nonnegative_finite(
    value: f64,
    detail: &'static str,
) -> Result<(), ConstructionObservationError> {
    require_finite_not_negative_zero(value, detail)?;
    if value < 0.0 {
        return Err(ConstructionObservationError::InvalidValue { detail });
    }
    Ok(())
}

fn two_sum(lhs: f64, rhs: f64) -> Result<(f64, f64), ConstructionObservationError> {
    let sum = lhs + rhs;
    if !sum.is_finite() {
        return Err(ConstructionObservationError::NumericalOverflow {
            quantity: "observation binary64 sum",
        });
    }
    let rhs_virtual = sum - lhs;
    let lhs_virtual = sum - rhs_virtual;
    let rhs_roundoff = rhs - rhs_virtual;
    let lhs_roundoff = lhs - lhs_virtual;
    let residual = lhs_roundoff + rhs_roundoff;
    if !residual.is_finite() {
        return Err(ConstructionObservationError::NumericalOverflow {
            quantity: "observation binary64 residual",
        });
    }
    Ok((sum, residual))
}

pub(crate) fn upper_add(
    lhs: f64,
    rhs: f64,
) -> Result<f64, ConstructionObservationError> {
    require_nonnegative_finite(lhs, "observation upper-add lhs")?;
    require_nonnegative_finite(rhs, "observation upper-add rhs")?;
    let sum = lhs + rhs;
    if !sum.is_finite() {
        return Err(ConstructionObservationError::NumericalOverflow {
            quantity: "observation upper sum",
        });
    }
    Ok(if rhs == 0.0 { sum } else { next_up(sum) })
}

pub(crate) fn outward_multiply_nonnegative(
    lhs: f64,
    rhs: f64,
) -> Result<f64, ConstructionObservationError> {
    require_nonnegative_finite(lhs, "observation upper-product lhs")?;
    require_nonnegative_finite(rhs, "observation upper-product rhs")?;
    if lhs == 0.0 || rhs == 0.0 {
        return Ok(0.0);
    }
    let product = lhs * rhs;
    if !product.is_finite() {
        return Err(ConstructionObservationError::NumericalOverflow {
            quantity: "observation upper product",
        });
    }
    Ok(next_up(product))
}

fn upper_distance(lhs: f64, rhs: f64) -> Result<f64, ConstructionObservationError> {
    require_finite_not_negative_zero(lhs, "observation distance lhs")?;
    require_finite_not_negative_zero(rhs, "observation distance rhs")?;
    let distance = (lhs - rhs).abs();
    if !distance.is_finite() {
        return Err(ConstructionObservationError::NumericalOverflow {
            quantity: "observation binary64 distance",
        });
    }
    Ok(if distance == 0.0 {
        0.0
    } else {
        next_up(distance)
    })
}

fn next_up(value: f64) -> f64 {
    if value == 0.0 {
        return f64::from_bits(1);
    }
    f64::from_bits(value.to_bits() + 1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn observation_plan_requires_canonical_absolute_boundaries() {
        let plan = ObservationPlanV1::try_new(2, 9, vec![2, 4, 9], 32, 16, true)
            .expect("canonical plan prepares");
        assert_eq!(plan.block_count(), 2);
        assert_eq!(plan.maximum_total_rows_per_replication, 32);
        assert_eq!(plan.block_index_for_slot(2), Some(0));
        assert_eq!(plan.block_index_for_slot(4), Some(1));
        assert_eq!(plan.block_index_for_slot(9), None);
        assert!(plan.is_reporting_boundary(4));
        assert!(ObservationPlanV1::try_new(2, 9, vec![2, 4, 4, 9], 32, 16, false)
            .is_err());
    }

    #[test]
    fn enclosed_accumulator_is_deterministic_and_rejects_nonfinite_input() {
        let mut accumulator = EnclosedBinary64AccumulatorV1::default();
        for value in [0.25, 0.5, 0.25] {
            accumulator
                .add_nonnegative(value)
                .expect("finite mass accumulates");
        }
        let enclosed = accumulator.finish().expect("enclosure finalizes");
        assert_eq!(enclosed.value_bits, 1.0_f64.to_bits());
        assert!(enclosed.absolute_error().is_finite());
        assert!(enclosed.l1_norm() >= 1.0);

        let mut invalid = EnclosedBinary64AccumulatorV1::default();
        assert!(invalid.add_nonnegative(f64::INFINITY).is_err());

        let mut rounded_product = EnclosedBinary64AccumulatorV1::default();
        rounded_product
            .add_weighted_u128(0.1, (1_u128 << 100) + 1)
            .expect("large exact magnitude is conservatively enclosed");
        let rounded_product = rounded_product.finish().expect("product finalizes");
        assert!(rounded_product.absolute_error() > 0.0);
        assert!(rounded_product.l1_norm() >= rounded_product.absolute_error());
        assert!(EnclosedBinary64V1::try_new(1.0, 0.5, 0.25).is_err());
    }

    #[test]
    fn exact_balance_preserves_a_signed_defect() {
        let positive = ObservationMassBalanceV1::exact(5, 3);
        assert_eq!(positive.signed_mass_defect, ObservationScalarV1::exact_u128(2));
        let negative = ObservationMassBalanceV1::exact(3, 5);
        assert_eq!(
            negative.signed_mass_defect,
            ObservationScalarV1::exact_i128(-2)
        );
    }

    #[test]
    fn diagnostic_work_counters_checked_merge_preserves_counter_meanings() {
        let mut first = ObservationWorkCountersV1::default();
        first.record_committed_rows(4);
        first.record_new_sparse_keys(2);
        first.record_gap_evaluations(4);
        first.record_boundary_scan(2);
        first.record_schedule_cache_hits(3);
        first.record_schedule_cache_keys(1);
        first.record_prepared_capacity(2, 16);

        let mut second = ObservationWorkCountersV1::default();
        second.record_boundary_scan(4);
        second.record_schedule_cache_hits(1);
        second.record_schedule_cache_keys(2);
        first.merge(second);

        assert_eq!(first.committed_rows(), 4);
        assert_eq!(first.new_sparse_keys(), 2);
        assert_eq!(first.gap_evaluations(), 4);
        assert_eq!(first.boundary_scans(), 6);
        assert_eq!(first.schedule_cache_hits(), 4);
        assert_eq!(first.schedule_cache_keys(), 3);
        assert_eq!(first.prepared_capacity_allocations(), 2);
        assert_eq!(first.prepared_capacity_units(), 16);
    }
}
