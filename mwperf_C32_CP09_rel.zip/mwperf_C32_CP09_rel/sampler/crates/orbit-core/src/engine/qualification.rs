//! Feature-gated CP05 qualification observers.
//!
//! This module is not part of the provider request surface.  It drives the
//! sole physical transaction in [`PreparedCountRun`] and attaches bounded,
//! test-only observers.  The optional dense oracle uses the ordinary Free
//! solve and an independent dense `Q-S+a` transition, compares one origin at
//! a time, and discards that coordinate immediately.

use std::mem::size_of;
use std::sync::Arc;

use num_bigint::{BigInt, BigUint};

use super::{
    arithmetic_refusal, map_arrival_runtime, map_carrier_runtime, result_violation,
    scheduler_state_identity, CoordinateSink, CountRunResult, PreparedCountProblem,
    PreparedCountRun, ProductionFaultGate, ProviderEndpointIdentity, TargetWindowReconciliation,
    C02_SEED_BRIDGE_WORDS,
};
use crate::direct_count_arrivals::{ArrivalDrawBudget, ArrivalState};
use crate::error::{RunError, RuntimeStage};
use crate::estimator::{ReplicationCoordinate, ReplicationEvidence};
use crate::exact::RuntimeCount;
use crate::occupancy_maxweight::{CandidateAction, OccupancySolverScratch};
use crate::response_observer::{PreparedResponseCommit, ResponseLedger};
use crate::unit_count::{Arrival, ProspectiveSlot, UnitCountCarrier};

pub const BACKLOG_DIAGNOSTIC_BUCKETS: usize = 66;
const OVERFLOW_BACKLOG_BUCKET: usize = BACKLOG_DIAGNOSTIC_BUCKETS - 1;
const DIFFERENTIAL_DOMAIN: &[u8] = b"FOFS-CP04.1-PHYSICAL-DIFFERENTIAL-V1\0";

/// Optional bounded observers attached to the one CP05 physical execution.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct QualificationPlan {
    warmup_diagnostics: Option<([RuntimeCount; 3], RuntimeCount)>,
    dense_differential: bool,
}

impl QualificationPlan {
    /// Execute with no additional diagnostic state.  This exists so the CP05
    /// determinism harness can use the same typed return shape.
    pub const fn physical_only() -> Self {
        Self {
            warmup_diagnostics: None,
            dense_differential: false,
        }
    }

    /// Every origin is compared with the final test-only dense oracle.  No
    /// additional response or backlog diagnostic is accumulated.
    pub const fn construction_differential() -> Self {
        Self {
            warmup_diagnostics: None,
            dense_differential: true,
        }
    }

    /// Accumulate the three predeclared windows and the 66-bucket diagnostic
    /// without running a second provider or optimizer.
    pub const fn accuracy(warmups: [RuntimeCount; 3], histogram_warmup: RuntimeCount) -> Self {
        Self {
            warmup_diagnostics: Some((warmups, histogram_warmup)),
            dense_differential: false,
        }
    }

    /// Attach both bounded diagnostics and the dense per-origin oracle.  This
    /// is useful only for small conformance fixtures.
    pub const fn accuracy_with_differential(
        warmups: [RuntimeCount; 3],
        histogram_warmup: RuntimeCount,
    ) -> Self {
        Self {
            warmup_diagnostics: Some((warmups, histogram_warmup)),
            dense_differential: true,
        }
    }

    pub const fn dense_differential(self) -> bool {
        self.dense_differential
    }

    pub const fn warmup_diagnostics(self) -> Option<([RuntimeCount; 3], RuntimeCount)> {
        self.warmup_diagnostics
    }
}

/// The first coordinate that differed from the independent dense oracle.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DifferentialMismatch {
    origin: RuntimeCount,
    field: DifferentialMismatchField,
}

impl DifferentialMismatch {
    pub const fn origin(self) -> RuntimeCount {
        self.origin
    }

    pub const fn field(self) -> DifferentialMismatchField {
        self.field
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DifferentialMismatchField {
    Origin,
    PredecisionOccupancy,
    SelectedService,
    SparseArrivals,
    PostdecisionOccupancy,
    ExactObjective,
    ExactTieWitness,
    ProviderState,
    CarrierState,
    ProviderEndpointIdentity,
}

/// Path-free result of comparing every committed production origin online.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DenseDifferentialEvidence {
    compared_origin_count: RuntimeCount,
    first_mismatch: Option<DifferentialMismatch>,
    rolling_comparison_digest: [u8; 32],
    reference_free_solves: RuntimeCount,
}

impl DenseDifferentialEvidence {
    pub const fn compared_origin_count(self) -> RuntimeCount {
        self.compared_origin_count
    }

    pub const fn all_equal(self) -> bool {
        self.first_mismatch.is_none()
    }

    pub const fn first_mismatch(self) -> Option<DifferentialMismatch> {
        self.first_mismatch
    }

    pub const fn rolling_comparison_digest(self) -> [u8; 32] {
        self.rolling_comparison_digest
    }

    /// Test-oracle work, deliberately separate from production work.
    pub const fn reference_free_solves(self) -> RuntimeCount {
        self.reference_free_solves
    }
}

/// Exact target-window evidence for one of the three frozen warmups.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct WarmupWindowEvidence {
    warmup: RuntimeCount,
    ledger: ResponseLedger,
    reconciliation: TargetWindowReconciliation,
}

impl WarmupWindowEvidence {
    pub const fn warmup(self) -> RuntimeCount {
        self.warmup
    }

    pub const fn ledger(self) -> ResponseLedger {
        self.ledger
    }

    pub const fn reconciliation(self) -> TargetWindowReconciliation {
        self.reconciliation
    }
}

/// Fixed-cap physical backlog diagnostic.  Index 0..=64 is the exact target
/// backlog and index 65 is the `Q>=65` overflow bucket.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BacklogLevelEvidence {
    warmup: RuntimeCount,
    exposures: [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS],
    selected: [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS],
}

impl BacklogLevelEvidence {
    pub const fn warmup(self) -> RuntimeCount {
        self.warmup
    }

    pub const fn exposures(self) -> [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS] {
        self.exposures
    }

    pub const fn selected(self) -> [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS] {
        self.selected
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ThreeWarmupEvidence {
    windows: [WarmupWindowEvidence; 3],
    backlog_levels: BacklogLevelEvidence,
    bounded_observer_bytes: u64,
}

impl ThreeWarmupEvidence {
    pub const fn windows(self) -> [WarmupWindowEvidence; 3] {
        self.windows
    }

    pub const fn backlog_levels(self) -> BacklogLevelEvidence {
        self.backlog_levels
    }

    pub const fn bounded_observer_bytes(self) -> u64 {
        self.bounded_observer_bytes
    }
}

/// Explicit solve counters for the physical arm and its attached observers.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct QualificationSolveInstrumentation {
    primary_free_solves: RuntimeCount,
    observer_or_opposite_class_solves: RuntimeCount,
}

impl QualificationSolveInstrumentation {
    pub const fn primary_free_solves(self) -> RuntimeCount {
        self.primary_free_solves
    }

    pub const fn observer_or_opposite_class_solves(self) -> RuntimeCount {
        self.observer_or_opposite_class_solves
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct QualificationDiagnostics {
    differential: Option<DenseDifferentialEvidence>,
    three_warmups: Option<ThreeWarmupEvidence>,
    solves: QualificationSolveInstrumentation,
}

impl QualificationDiagnostics {
    pub const fn differential(self) -> Option<DenseDifferentialEvidence> {
        self.differential
    }

    pub const fn three_warmups(self) -> Option<ThreeWarmupEvidence> {
        self.three_warmups
    }

    pub const fn solves(self) -> QualificationSolveInstrumentation {
        self.solves
    }
}

/// One completed execution before its queue-width endpoint is erased.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QualificationExecution {
    coordinate: ReplicationCoordinate,
    result: CountRunResult,
    diagnostics: QualificationDiagnostics,
}

impl QualificationExecution {
    pub const fn coordinate(&self) -> ReplicationCoordinate {
        self.coordinate
    }

    pub const fn result(&self) -> &CountRunResult {
        &self.result
    }

    pub const fn diagnostics(&self) -> QualificationDiagnostics {
        self.diagnostics
    }

    /// Erase the queue-width endpoint exactly as the production replication
    /// coordinator does, while retaining only the bounded qualification data.
    pub fn into_parts(self) -> (ReplicationEvidence, QualificationDiagnostics) {
        (
            ReplicationEvidence::from_count_run(self.coordinate, self.result),
            self.diagnostics,
        )
    }
}

impl PreparedCountRun {
    /// Execute the sole physical orbit with CP05's bounded test observers.
    /// This method is absent unless the non-default qualification feature is
    /// selected at compile time.
    pub fn execute_qualification(
        &self,
        coordinate: ReplicationCoordinate,
        plan: QualificationPlan,
    ) -> Result<QualificationExecution, RunError> {
        if self.replay.replication_index() != coordinate.index() {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "replay and declared qualification coordinates differ",
            ));
        }
        validate_plan(self, plan)?;
        let mut sink = QualificationSink::try_new(self, plan)?;
        let result = self.execute_with_gate(&ProductionFaultGate, &mut sink)?;
        let diagnostics = sink.finish(self, &result)?;
        Ok(QualificationExecution {
            coordinate,
            result,
            diagnostics,
        })
    }
}

fn validate_plan(run: &PreparedCountRun, plan: QualificationPlan) -> Result<(), RunError> {
    if let Some((warmups, histogram_warmup)) = plan.warmup_diagnostics {
        if warmups[0] >= warmups[1]
            || warmups[1] >= warmups[2]
            || warmups[2] >= run.horizon()
            || histogram_warmup >= run.horizon()
            || !warmups.contains(&histogram_warmup)
        {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "qualification warmups must be distinct, increasing, below T, and contain the histogram warmup",
            ));
        }
    }
    Ok(())
}

struct QualificationSink {
    target: usize,
    warmups: Option<WarmupObserverState>,
    dense_reference: Option<DenseReferenceState>,
}

impl QualificationSink {
    fn try_new(run: &PreparedCountRun, plan: QualificationPlan) -> Result<Self, RunError> {
        let target = run.target().as_usize().ok_or_else(|| {
            result_violation(
                RuntimeStage::EmptyInitialization,
                "qualification target does not fit usize",
            )
        })?;
        let warmups = plan.warmup_diagnostics.map(|(warmups, histogram_warmup)| {
            WarmupObserverState::new(warmups, histogram_warmup, run.horizon())
        });
        let dense_reference = if plan.dense_differential {
            Some(DenseReferenceState::try_new(run)?)
        } else {
            None
        };
        Ok(Self {
            target,
            warmups,
            dense_reference,
        })
    }

    fn finish(
        self,
        run: &PreparedCountRun,
        result: &CountRunResult,
    ) -> Result<QualificationDiagnostics, RunError> {
        let differential = self
            .dense_reference
            .map(|reference| reference.finish(run, result))
            .transpose()?;
        let three_warmups = self
            .warmups
            .map(|observer| observer.finish(run, result))
            .transpose()?;
        Ok(QualificationDiagnostics {
            differential,
            three_warmups,
            solves: QualificationSolveInstrumentation {
                primary_free_solves: RuntimeCount::new(result.work().exact_optimizer_calls()),
                observer_or_opposite_class_solves: RuntimeCount::ZERO,
            },
        })
    }
}

struct PreparedQualificationCoordinate {
    warmups: Option<PreparedWarmupCoordinate>,
    dense_reference: Option<PreparedDenseReferenceCoordinate>,
}

impl CoordinateSink for QualificationSink {
    type Prepared = PreparedQualificationCoordinate;

    fn prepare(
        &mut self,
        view: ProspectiveSlot<'_>,
        candidate: &CandidateAction,
    ) -> Result<Self::Prepared, RunError> {
        let warmups = self
            .warmups
            .as_ref()
            .map(|observer| observer.prepare(view, self.target))
            .transpose()?;
        let dense_reference = self
            .dense_reference
            .as_mut()
            .map(|reference| reference.prepare(view, candidate))
            .transpose()?;
        Ok(PreparedQualificationCoordinate {
            warmups,
            dense_reference,
        })
    }

    fn commit(
        &mut self,
        prepared: Self::Prepared,
        provider_endpoint: &ArrivalState,
        carrier_endpoint: &UnitCountCarrier,
    ) {
        if let (Some(observer), Some(prepared)) = (&mut self.warmups, prepared.warmups) {
            observer.commit(prepared);
        }
        if let (Some(reference), Some(prepared)) =
            (&mut self.dense_reference, prepared.dense_reference)
        {
            reference.commit(prepared, provider_endpoint, carrier_endpoint);
        }
    }
}

#[derive(Clone, Copy)]
struct WindowStart {
    backlog: RuntimeCount,
    cumulative_arrivals: RuntimeCount,
    cumulative_services: RuntimeCount,
}

struct WarmupObserverState {
    warmups: [RuntimeCount; 3],
    histogram_warmup: RuntimeCount,
    horizon: RuntimeCount,
    ledgers: [ResponseLedger; 3],
    starts: [Option<WindowStart>; 3],
    target_arrivals: RuntimeCount,
    target_services: RuntimeCount,
    level_exposures: [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS],
    level_selected: [RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS],
}

impl WarmupObserverState {
    const fn new(
        warmups: [RuntimeCount; 3],
        histogram_warmup: RuntimeCount,
        horizon: RuntimeCount,
    ) -> Self {
        Self {
            warmups,
            histogram_warmup,
            horizon,
            ledgers: [ResponseLedger::empty(); 3],
            starts: [None; 3],
            target_arrivals: RuntimeCount::ZERO,
            target_services: RuntimeCount::ZERO,
            level_exposures: [RuntimeCount::ZERO; BACKLOG_DIAGNOSTIC_BUCKETS],
            level_selected: [RuntimeCount::ZERO; BACKLOG_DIAGNOSTIC_BUCKETS],
        }
    }

    fn prepare(
        &self,
        view: ProspectiveSlot<'_>,
        target: usize,
    ) -> Result<PreparedWarmupCoordinate, RunError> {
        let occupancy = *view.before().get(target).ok_or_else(|| {
            result_violation(
                RuntimeStage::SlotObserverPreflight,
                "qualification target is outside Q",
            )
        })?;
        let selected = *view.service().get(target).ok_or_else(|| {
            result_violation(
                RuntimeStage::SlotObserverPreflight,
                "qualification target is outside S",
            )
        })?;
        let response = [
            self.ledgers[0].prepare(
                view.origin(),
                occupancy,
                selected,
                self.warmups[0],
                self.horizon,
            )?,
            self.ledgers[1].prepare(
                view.origin(),
                occupancy,
                selected,
                self.warmups[1],
                self.horizon,
            )?,
            self.ledgers[2].prepare(
                view.origin(),
                occupancy,
                selected,
                self.warmups[2],
                self.horizon,
            )?,
        ];
        let starts = [0, 1, 2].map(|index| {
            (view.origin() == self.warmups[index]).then_some(WindowStart {
                backlog: occupancy,
                cumulative_arrivals: self.target_arrivals,
                cumulative_services: self.target_services,
            })
        });
        for (index, start) in starts.iter().enumerate() {
            if start.is_some() && self.starts[index].is_some() {
                return Err(result_violation(
                    RuntimeStage::SlotObserverPreflight,
                    "qualification warmup boundary was already captured",
                ));
            }
        }
        let target_arrival = view
            .sparse_arrivals()
            .iter()
            .find(|arrival| arrival.queue().as_usize() == Some(target))
            .map_or(RuntimeCount::ZERO, |arrival| arrival.count());
        let next_target_arrivals = self
            .target_arrivals
            .checked_add(target_arrival, "qualification target arrivals")
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotObserverPreflight, error))?;
        let next_target_services = self
            .target_services
            .checked_add(
                RuntimeCount::new(u64::from(selected)),
                "qualification target services",
            )
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotObserverPreflight, error))?;
        let level = (view.origin() >= self.histogram_warmup).then(|| {
            let bucket = if occupancy.get() <= 64 {
                usize::try_from(occupancy.get()).expect("0..=64 fits usize")
            } else {
                OVERFLOW_BACKLOG_BUCKET
            };
            (bucket, selected)
        });
        let level_update = if let Some((bucket, selected)) = level {
            Some((
                bucket,
                self.level_exposures[bucket]
                    .checked_add(RuntimeCount::new(1), "backlog diagnostic exposure")
                    .map_err(|error| {
                        RunError::arithmetic(RuntimeStage::SlotObserverPreflight, error)
                    })?,
                self.level_selected[bucket]
                    .checked_add(
                        RuntimeCount::new(u64::from(selected)),
                        "backlog diagnostic service",
                    )
                    .map_err(|error| {
                        RunError::arithmetic(RuntimeStage::SlotObserverPreflight, error)
                    })?,
            ))
        } else {
            None
        };
        Ok(PreparedWarmupCoordinate {
            response,
            starts,
            next_target_arrivals,
            next_target_services,
            level_update,
        })
    }

    fn commit(&mut self, prepared: PreparedWarmupCoordinate) {
        for (ledger, update) in self.ledgers.iter_mut().zip(prepared.response) {
            ledger.commit(update);
        }
        for (destination, update) in self.starts.iter_mut().zip(prepared.starts) {
            if let Some(update) = update {
                *destination = Some(update);
            }
        }
        self.target_arrivals = prepared.next_target_arrivals;
        self.target_services = prepared.next_target_services;
        if let Some((bucket, exposure, selected)) = prepared.level_update {
            self.level_exposures[bucket] = exposure;
            self.level_selected[bucket] = selected;
        }
    }

    fn finish(
        self,
        run: &PreparedCountRun,
        result: &CountRunResult,
    ) -> Result<ThreeWarmupEvidence, RunError> {
        let target = run.target().as_usize().ok_or_else(|| {
            result_violation(
                RuntimeStage::HorizonFinalization,
                "qualification target does not fit usize",
            )
        })?;
        let target_backlog_at_t = result.carrier().occupancy().as_slice()[target];
        let conservation = result.carrier().conservation();
        if self.target_arrivals != conservation.cumulative_arrivals()[target]
            || self.target_services != conservation.cumulative_services()[target]
        {
            return Err(result_violation(
                RuntimeStage::HorizonFinalization,
                "qualification target counters do not reconcile with the carrier",
            ));
        }
        let mut windows = [None; 3];
        for (index, destination) in windows.iter_mut().enumerate() {
            self.ledgers[index].validate_complete(self.warmups[index], run.horizon())?;
            let start = self.starts[index].ok_or_else(|| {
                result_violation(
                    RuntimeStage::HorizonFinalization,
                    "qualification warmup boundary is absent",
                )
            })?;
            let scored_target_arrivals = self
                .target_arrivals
                .checked_sub(start.cumulative_arrivals, "qualification scored arrivals")
                .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?;
            let scored_target_services = self
                .target_services
                .checked_sub(start.cumulative_services, "qualification scored services")
                .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?;
            let ledger_services = self.ledgers[index].selected()[1..].iter().try_fold(
                RuntimeCount::ZERO,
                |sum, count| {
                    sum.checked_add(*count, "qualification ledger services")
                        .map_err(|error| {
                            RunError::arithmetic(RuntimeStage::HorizonFinalization, error)
                        })
                },
            )?;
            if self.ledgers[index].y_0() != RuntimeCount::ZERO
                || ledger_services != scored_target_services
                || u128::from(start.backlog.get()) + u128::from(scored_target_arrivals.get())
                    != u128::from(target_backlog_at_t.get())
                        + u128::from(scored_target_services.get())
            {
                return Err(result_violation(
                    RuntimeStage::HorizonFinalization,
                    "qualification window does not reconcile",
                ));
            }
            *destination = Some(WarmupWindowEvidence {
                warmup: self.warmups[index],
                ledger: self.ledgers[index],
                reconciliation: TargetWindowReconciliation {
                    window_length: run
                        .horizon()
                        .checked_sub(self.warmups[index], "qualification window length")
                        .map_err(|error| {
                            RunError::arithmetic(RuntimeStage::HorizonFinalization, error)
                        })?,
                    target_backlog_at_w: start.backlog,
                    target_backlog_at_t,
                    scored_target_arrivals,
                    scored_target_services,
                    endpoint_total_arrivals: conservation.total_arrivals(),
                    endpoint_total_services: conservation.total_services(),
                    endpoint_total_occupancy: result.carrier().total_occupancy(),
                },
            });
        }
        let level_total =
            self.level_exposures
                .iter()
                .try_fold(RuntimeCount::ZERO, |sum, count| {
                    sum.checked_add(*count, "backlog diagnostic total")
                        .map_err(|error| {
                            RunError::arithmetic(RuntimeStage::HorizonFinalization, error)
                        })
                })?;
        let expected_level_total = run
            .horizon()
            .checked_sub(self.histogram_warmup, "backlog diagnostic window")
            .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?;
        if level_total != expected_level_total
            || self
                .level_selected
                .iter()
                .zip(self.level_exposures)
                .any(|(selected, exposure)| *selected > exposure)
            || self.level_selected[0] != RuntimeCount::ZERO
        {
            return Err(result_violation(
                RuntimeStage::HorizonFinalization,
                "backlog diagnostic does not partition its scored window",
            ));
        }
        let windows = windows.map(|window| window.expect("all three windows were filled"));
        let bounded_observer_bytes = u64::try_from(
            size_of::<[ResponseLedger; 3]>()
                + size_of::<[Option<WindowStart>; 3]>()
                + size_of::<[RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS]>() * 2
                + size_of::<RuntimeCount>() * 2,
        )
        .map_err(|_| {
            arithmetic_refusal(
                RuntimeStage::HorizonFinalization,
                "qualification observer byte count exceeds u64",
            )
        })?;
        Ok(ThreeWarmupEvidence {
            windows,
            backlog_levels: BacklogLevelEvidence {
                warmup: self.histogram_warmup,
                exposures: self.level_exposures,
                selected: self.level_selected,
            },
            bounded_observer_bytes,
        })
    }
}

struct PreparedWarmupCoordinate {
    response: [PreparedResponseCommit; 3],
    starts: [Option<WindowStart>; 3],
    next_target_arrivals: RuntimeCount,
    next_target_services: RuntimeCount,
    level_update: Option<(usize, RuntimeCount, RuntimeCount)>,
}

struct DenseReferenceState {
    problem: Arc<PreparedCountProblem>,
    provider_state: ArrivalState,
    solver_carrier: UnitCountCarrier,
    q: Vec<RuntimeCount>,
    cumulative_arrivals: Vec<RuntimeCount>,
    cumulative_services: Vec<RuntimeCount>,
    total_arrivals: RuntimeCount,
    total_services: RuntimeCount,
    solver_scratch: OccupancySolverScratch,
    compared: RuntimeCount,
    first_mismatch: Option<DifferentialMismatch>,
    hasher: blake3::Hasher,
}

impl DenseReferenceState {
    fn try_new(run: &PreparedCountRun) -> Result<Self, RunError> {
        let budget = ArrivalDrawBudget::try_new(
            run.limits.maximum_configured_generator_draws,
            C02_SEED_BRIDGE_WORDS,
        )
        .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
        let mut attempted_draws = 0;
        let (provider_state, _work) = run
            .problem
            .provider
            .try_start_counted_observed(run.replay, budget, &mut attempted_draws)
            .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
        let solver_carrier = UnitCountCarrier::try_empty(run.problem.catalog.clone())
            .map_err(|error| map_carrier_runtime(RuntimeStage::EmptyInitialization, error))?;
        let queue_count = run.problem.catalog.len();
        let q = solver_carrier.occupancy().as_slice().to_vec();
        let cumulative_arrivals = q.clone();
        let cumulative_services = q.clone();
        let solver_scratch = run.problem.optimizer.try_replication_scratch()?;
        let mut hasher = blake3::Hasher::new();
        hasher.update(DIFFERENTIAL_DOMAIN);
        hasher.update(&run.replay.seed_material());
        hasher.update(&run.replay.replication_index().to_be_bytes());
        hasher.update(
            &u64::try_from(queue_count)
                .map_err(|_| {
                    arithmetic_refusal(
                        RuntimeStage::EmptyInitialization,
                        "qualification queue count exceeds u64",
                    )
                })?
                .to_be_bytes(),
        );
        Ok(Self {
            problem: run.problem.clone(),
            provider_state,
            solver_carrier,
            q,
            cumulative_arrivals,
            cumulative_services,
            total_arrivals: RuntimeCount::ZERO,
            total_services: RuntimeCount::ZERO,
            solver_scratch,
            compared: RuntimeCount::ZERO,
            first_mismatch: None,
            hasher,
        })
    }

    fn prepare(
        &mut self,
        view: ProspectiveSlot<'_>,
        production_candidate: &CandidateAction,
    ) -> Result<PreparedDenseReferenceCoordinate, RunError> {
        let origin = self.compared;
        self.solver_carrier
            .replace_solver_occupancy_for_test(&self.q)
            .map_err(|error| map_carrier_runtime(RuntimeStage::ColdMaxWeightSolve, error))?;
        // Use the same ordinary Free solve, never a forced/counterfactual API.
        let selected = self.problem.optimizer.select_free_with_scratch(
            &self.solver_carrier,
            None,
            &mut self.solver_scratch,
        )?;
        let service = selected.candidate().service.as_slice().to_vec();
        let objective = selected.candidate().primary_objective.clone();
        let tie = selected.candidate().tie_refinement.clone();
        let provider_step = self
            .problem
            .provider
            .advance_dense_for_test(view.origin(), &self.provider_state)
            .map_err(|error| map_arrival_runtime(RuntimeStage::SlotProviderAdvance, error));
        let release = self
            .problem
            .optimizer
            .release_selected(selected, &mut self.solver_scratch);
        let (arrivals, next_provider) = provider_step?;
        release?;
        let q_next = independent_dense_transition(&self.q, &service, arrivals.entries())?;
        let mismatch = compare_coordinate(
            origin,
            view,
            &self.q,
            &service,
            arrivals.entries(),
            &q_next,
            &objective,
            &tie,
            production_candidate,
        );
        preflight_reference_conservation(
            &self.cumulative_arrivals,
            &self.cumulative_services,
            self.total_arrivals,
            self.total_services,
            &service,
            arrivals.entries(),
        )?;
        let next_compared = self
            .compared
            .checked_add(RuntimeCount::new(1), "dense compared-origin count")
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
        Ok(PreparedDenseReferenceCoordinate {
            origin,
            service,
            arrivals: arrivals.entries().to_vec(),
            q_next,
            objective,
            tie,
            next_provider,
            next_compared,
            mismatch,
        })
    }

    fn commit(
        &mut self,
        prepared: PreparedDenseReferenceCoordinate,
        production_provider: &ArrivalState,
        production_carrier: &UnitCountCarrier,
    ) {
        note_mismatch(&mut self.first_mismatch, prepared.mismatch);
        if production_provider != &prepared.next_provider {
            note_mismatch(
                &mut self.first_mismatch,
                Some(DifferentialMismatch {
                    origin: prepared.origin,
                    field: DifferentialMismatchField::ProviderState,
                }),
            );
        }
        apply_reference_conservation(
            &mut self.cumulative_arrivals,
            &mut self.cumulative_services,
            &mut self.total_arrivals,
            &mut self.total_services,
            &prepared.service,
            &prepared.arrivals,
        );
        if production_carrier.occupancy().as_slice() != prepared.q_next
            || production_carrier.conservation().cumulative_arrivals() != self.cumulative_arrivals
            || production_carrier.conservation().cumulative_services() != self.cumulative_services
            || production_carrier.conservation().total_arrivals() != self.total_arrivals
            || production_carrier.conservation().total_services() != self.total_services
            || production_carrier.boundary() != prepared.next_compared
        {
            note_mismatch(
                &mut self.first_mismatch,
                Some(DifferentialMismatch {
                    origin: prepared.origin,
                    field: DifferentialMismatchField::CarrierState,
                }),
            );
        }
        let actual_endpoint =
            provider_endpoint_identity_from_parts(production_provider, production_carrier);
        let expected_endpoint = reference_endpoint_identity(
            &prepared.next_provider,
            prepared.next_compared,
            &prepared.q_next,
            &self.cumulative_arrivals,
            &self.cumulative_services,
            self.total_arrivals,
            self.total_services,
        );
        if actual_endpoint != expected_endpoint {
            note_mismatch(
                &mut self.first_mismatch,
                Some(DifferentialMismatch {
                    origin: prepared.origin,
                    field: DifferentialMismatchField::ProviderEndpointIdentity,
                }),
            );
        }
        hash_coordinate(
            &mut self.hasher,
            prepared.origin,
            &self.q,
            &prepared.service,
            &prepared.arrivals,
            &prepared.q_next,
            &prepared.objective,
            &prepared.tie,
            prepared.next_provider.endpoint_identity_v1(),
            expected_endpoint,
        );
        self.q = prepared.q_next;
        self.provider_state = prepared.next_provider;
        self.compared = prepared.next_compared;
    }

    fn finish(
        self,
        run: &PreparedCountRun,
        result: &CountRunResult,
    ) -> Result<DenseDifferentialEvidence, RunError> {
        if self.compared != run.horizon()
            || self.provider_state.expected_slot() != run.horizon()
            || self.q != result.carrier().occupancy().as_slice()
        {
            return Err(result_violation(
                RuntimeStage::HorizonFinalization,
                "dense reference did not reach the production endpoint",
            ));
        }
        Ok(DenseDifferentialEvidence {
            compared_origin_count: self.compared,
            first_mismatch: self.first_mismatch,
            rolling_comparison_digest: *self.hasher.finalize().as_bytes(),
            reference_free_solves: self.compared,
        })
    }
}

struct PreparedDenseReferenceCoordinate {
    origin: RuntimeCount,
    service: Vec<u8>,
    arrivals: Vec<Arrival>,
    q_next: Vec<RuntimeCount>,
    objective: BigInt,
    tie: BigUint,
    next_provider: ArrivalState,
    next_compared: RuntimeCount,
    mismatch: Option<DifferentialMismatch>,
}

fn independent_dense_transition(
    q: &[RuntimeCount],
    service: &[u8],
    sparse_arrivals: &[Arrival],
) -> Result<Vec<RuntimeCount>, RunError> {
    if service.len() != q.len() {
        return Err(result_violation(
            RuntimeStage::SlotTransitionPreparation,
            "dense reference service width differs from Q",
        ));
    }
    let mut q_next = q.to_vec();
    for (position, (&before, &selected)) in q.iter().zip(service).enumerate() {
        if selected > 1 {
            return Err(result_violation(
                RuntimeStage::SlotTransitionPreparation,
                "dense reference service is not binary",
            ));
        }
        q_next[position] = before
            .checked_sub(
                RuntimeCount::new(u64::from(selected)),
                "dense reference predecision service",
            )
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
    }
    for &arrival in sparse_arrivals {
        let position = arrival.queue().as_usize().ok_or_else(|| {
            result_violation(
                RuntimeStage::SlotTransitionPreparation,
                "dense reference arrival queue does not fit usize",
            )
        })?;
        let next = q_next.get_mut(position).ok_or_else(|| {
            result_violation(
                RuntimeStage::SlotTransitionPreparation,
                "dense reference arrival queue is outside Q",
            )
        })?;
        *next = next
            .checked_add(arrival.count(), "dense reference late arrival")
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
    }
    Ok(q_next)
}

#[allow(clippy::too_many_arguments)]
fn compare_coordinate(
    expected_origin: RuntimeCount,
    view: ProspectiveSlot<'_>,
    q: &[RuntimeCount],
    service: &[u8],
    arrivals: &[Arrival],
    q_next: &[RuntimeCount],
    objective: &BigInt,
    tie: &BigUint,
    production_candidate: &CandidateAction,
) -> Option<DifferentialMismatch> {
    let field = if view.origin() != expected_origin {
        Some(DifferentialMismatchField::Origin)
    } else if view.before() != q {
        Some(DifferentialMismatchField::PredecisionOccupancy)
    } else if view.service() != service {
        Some(DifferentialMismatchField::SelectedService)
    } else if view.sparse_arrivals() != arrivals {
        Some(DifferentialMismatchField::SparseArrivals)
    } else if view.next() != q_next {
        Some(DifferentialMismatchField::PostdecisionOccupancy)
    } else if &production_candidate.primary_objective != objective {
        Some(DifferentialMismatchField::ExactObjective)
    } else if &production_candidate.tie_refinement != tie {
        Some(DifferentialMismatchField::ExactTieWitness)
    } else {
        None
    };
    field.map(|field| DifferentialMismatch {
        origin: expected_origin,
        field,
    })
}

fn note_mismatch(
    first: &mut Option<DifferentialMismatch>,
    candidate: Option<DifferentialMismatch>,
) {
    if first.is_none() {
        *first = candidate;
    }
}

fn preflight_reference_conservation(
    cumulative_arrivals: &[RuntimeCount],
    cumulative_services: &[RuntimeCount],
    total_arrivals: RuntimeCount,
    total_services: RuntimeCount,
    service: &[u8],
    arrivals: &[Arrival],
) -> Result<(), RunError> {
    let mut arrival_total = RuntimeCount::ZERO;
    for arrival in arrivals {
        let position = arrival.queue().as_usize().ok_or_else(|| {
            result_violation(
                RuntimeStage::SlotCommitPreparation,
                "dense reference arrival queue does not fit usize",
            )
        })?;
        cumulative_arrivals[position]
            .checked_add(arrival.count(), "dense reference cumulative arrivals")
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
        arrival_total = arrival_total
            .checked_add(arrival.count(), "dense reference slot arrivals")
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
    }
    let mut service_total = RuntimeCount::ZERO;
    for (position, selected) in service.iter().copied().enumerate() {
        cumulative_services[position]
            .checked_add(
                RuntimeCount::new(u64::from(selected)),
                "dense reference cumulative services",
            )
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
        service_total = service_total
            .checked_add(
                RuntimeCount::new(u64::from(selected)),
                "dense reference slot services",
            )
            .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
    }
    total_arrivals
        .checked_add(arrival_total, "dense reference total arrivals")
        .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
    total_services
        .checked_add(service_total, "dense reference total services")
        .map_err(|error| RunError::arithmetic(RuntimeStage::SlotCommitPreparation, error))?;
    Ok(())
}

fn apply_reference_conservation(
    cumulative_arrivals: &mut [RuntimeCount],
    cumulative_services: &mut [RuntimeCount],
    total_arrivals: &mut RuntimeCount,
    total_services: &mut RuntimeCount,
    service: &[u8],
    arrivals: &[Arrival],
) {
    for arrival in arrivals {
        let position = arrival
            .queue()
            .as_usize()
            .expect("preflight queue fits usize");
        cumulative_arrivals[position] = cumulative_arrivals[position]
            .checked_add(arrival.count(), "preflighted dense cumulative arrivals")
            .expect("reference arrival sum was preflighted");
        *total_arrivals = total_arrivals
            .checked_add(arrival.count(), "preflighted dense total arrivals")
            .expect("reference arrival total was preflighted");
    }
    for (position, selected) in service.iter().copied().enumerate() {
        let selected = RuntimeCount::new(u64::from(selected));
        cumulative_services[position] = cumulative_services[position]
            .checked_add(selected, "preflighted dense cumulative services")
            .expect("reference service sum was preflighted");
        *total_services = total_services
            .checked_add(selected, "preflighted dense total services")
            .expect("reference service total was preflighted");
    }
}

fn provider_endpoint_identity_from_parts(
    provider: &ArrivalState,
    carrier: &UnitCountCarrier,
) -> ProviderEndpointIdentity {
    let arrival_cursor_digest = provider.endpoint_identity_v1();
    let scheduler_state_digest = scheduler_state_identity(carrier);
    combine_endpoint_identity(
        arrival_cursor_digest,
        scheduler_state_digest,
        provider.expected_slot(),
    )
}

#[allow(clippy::too_many_arguments)]
fn reference_endpoint_identity(
    provider: &ArrivalState,
    boundary: RuntimeCount,
    q: &[RuntimeCount],
    cumulative_arrivals: &[RuntimeCount],
    cumulative_services: &[RuntimeCount],
    total_arrivals: RuntimeCount,
    total_services: RuntimeCount,
) -> ProviderEndpointIdentity {
    let mut scheduler = blake3::Hasher::new();
    scheduler.update(b"FOFS-SCHEDULER-ENDPOINT-V1\0");
    scheduler.update(&boundary.get().to_be_bytes());
    let total_occupancy = q.iter().map(|count| u128::from(count.get())).sum::<u128>();
    scheduler.update(&total_occupancy.to_be_bytes());
    scheduler.update(&(q.len() as u64).to_be_bytes());
    for value in q {
        scheduler.update(&value.get().to_be_bytes());
    }
    for value in cumulative_arrivals {
        scheduler.update(&value.get().to_be_bytes());
    }
    for value in cumulative_services {
        scheduler.update(&value.get().to_be_bytes());
    }
    scheduler.update(&total_arrivals.get().to_be_bytes());
    scheduler.update(&total_services.get().to_be_bytes());
    combine_endpoint_identity(
        provider.endpoint_identity_v1(),
        *scheduler.finalize().as_bytes(),
        provider.expected_slot(),
    )
}

fn combine_endpoint_identity(
    arrival_cursor_digest: [u8; 32],
    scheduler_state_digest: [u8; 32],
    expected_slot: RuntimeCount,
) -> ProviderEndpointIdentity {
    let mut hasher = blake3::Hasher::new();
    hasher.update(b"FOFS-PROVIDER-ENDPOINT-V1\0");
    hasher.update(&arrival_cursor_digest);
    hasher.update(&scheduler_state_digest);
    ProviderEndpointIdentity {
        endpoint_identity_digest: *hasher.finalize().as_bytes(),
        arrival_cursor_digest,
        scheduler_state_digest,
        expected_slot,
    }
}

#[allow(clippy::too_many_arguments)]
fn hash_coordinate(
    hasher: &mut blake3::Hasher,
    origin: RuntimeCount,
    q: &[RuntimeCount],
    service: &[u8],
    arrivals: &[Arrival],
    q_next: &[RuntimeCount],
    objective: &BigInt,
    tie: &BigUint,
    arrival_state_digest: [u8; 32],
    endpoint: ProviderEndpointIdentity,
) {
    hasher.update(&origin.get().to_be_bytes());
    hash_counts(hasher, q);
    hasher.update(&(service.len() as u64).to_be_bytes());
    hasher.update(service);
    hasher.update(&(arrivals.len() as u64).to_be_bytes());
    for arrival in arrivals {
        hasher.update(&arrival.queue().0.to_be_bytes());
        hasher.update(&arrival.count().get().to_be_bytes());
    }
    hash_counts(hasher, q_next);
    let objective = objective.to_signed_bytes_be();
    hasher.update(&(objective.len() as u64).to_be_bytes());
    hasher.update(&objective);
    let tie = tie.to_bytes_be();
    hasher.update(&(tie.len() as u64).to_be_bytes());
    hasher.update(&tie);
    hasher.update(&arrival_state_digest);
    hasher.update(&endpoint.endpoint_identity_digest());
    hasher.update(&endpoint.arrival_cursor_digest());
    hasher.update(&endpoint.scheduler_state_digest());
    hasher.update(&endpoint.expected_slot().get().to_be_bytes());
}

fn hash_counts(hasher: &mut blake3::Hasher, values: &[RuntimeCount]) {
    hasher.update(&(values.len() as u64).to_be_bytes());
    for value in values {
        hasher.update(&value.get().to_be_bytes());
    }
}

#[cfg(test)]
mod tests {
    use num_bigint::BigInt;

    use super::*;
    use crate::direct_count_arrivals::{ArrivalReplay, PreparedArrival};
    use crate::engine::{ConstructionWorkLimits, OptimizerSearchStateGrant};
    use crate::exact::{ExactRational, ExactUnsigned};
    use crate::occupancy_maxweight::PreparedOccupancyMaxWeight;
    use crate::resolved::{
        CountArrivalEvent, DeterministicTrace, IntervalTopology, QueueInterval, ResolvedArrival,
        ResolvedScheduler, SchedulerTopology, TypedId,
    };
    use crate::unit_count::{QueueCatalog, QueueIndex};

    fn qid(position: usize) -> TypedId {
        TypedId::from(format!("q{position}"))
    }

    fn run() -> PreparedCountRun {
        let catalog = QueueCatalog::try_new(vec![qid(0), qid(1)]).unwrap();
        let scheduler = ResolvedScheduler {
            priority: vec![qid(0), qid(1)],
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: vec![
                    QueueInterval {
                        queue_id: qid(0),
                        left: ExactRational::from_integer(BigInt::from(0)),
                        right: ExactRational::from_integer(BigInt::from(2)),
                    },
                    QueueInterval {
                        queue_id: qid(1),
                        left: ExactRational::from_integer(BigInt::from(1)),
                        right: ExactRational::from_integer(BigInt::from(3)),
                    },
                ],
            }),
        };
        let arrival = ResolvedArrival::DeterministicTrace(DeterministicTrace {
            events: vec![
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(0),
                    count: 4,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(1),
                    count: 2,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(5),
                    queue_id: qid(0),
                    count: 2,
                },
            ],
        });
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
        let provider = PreparedArrival::try_compile(&arrival, &catalog).unwrap();
        let limits =
            ConstructionWorkLimits::try_new(12, OptimizerSearchStateGrant::NotApplicable, 4)
                .unwrap();
        let problem = PreparedCountProblem::try_new(
            catalog,
            optimizer,
            provider,
            QueueIndex(0),
            RuntimeCount::new(4),
            RuntimeCount::new(12),
            limits,
        )
        .unwrap();
        PreparedCountRun::try_bind(problem, ArrivalReplay::from_seed_material([0x7b; 32], 3))
            .unwrap()
    }

    #[test]
    fn fofs_cp05_qualification_is_online_path_free_and_reconciled() {
        let run = run();
        let execution = run
            .execute_qualification(
                ReplicationCoordinate::new(3),
                QualificationPlan::accuracy_with_differential(
                    [
                        RuntimeCount::new(2),
                        RuntimeCount::new(4),
                        RuntimeCount::new(8),
                    ],
                    RuntimeCount::new(4),
                ),
            )
            .unwrap();
        assert_eq!(execution.result().work().exact_optimizer_calls(), 12);
        let diagnostics = execution.diagnostics();
        assert_eq!(diagnostics.solves().primary_free_solves().get(), 12);
        assert_eq!(
            diagnostics
                .solves()
                .observer_or_opposite_class_solves()
                .get(),
            0
        );
        let differential = diagnostics.differential().unwrap();
        assert!(differential.all_equal());
        assert_eq!(differential.compared_origin_count().get(), 12);
        assert_eq!(differential.reference_free_solves().get(), 12);
        let warmups = diagnostics.three_warmups().unwrap();
        for window in warmups.windows() {
            assert_eq!(
                window
                    .ledger()
                    .exposures()
                    .iter()
                    .map(|value| value.get())
                    .sum::<u64>(),
                12 - window.warmup().get()
            );
            assert_eq!(
                window.reconciliation().window_length().get(),
                12 - window.warmup().get()
            );
        }
        assert_eq!(
            warmups
                .backlog_levels()
                .exposures()
                .iter()
                .map(|value| value.get())
                .sum::<u64>(),
            8
        );
        let (evidence, retained) = execution.into_parts();
        assert_eq!(evidence.coordinate(), ReplicationCoordinate::new(3));
        assert_eq!(retained, diagnostics);
    }

    #[test]
    fn fofs_cp05_qualification_result_is_path_free_and_fixed_layout() {
        let execution = run()
            .execute_qualification(
                ReplicationCoordinate::new(3),
                QualificationPlan::accuracy(
                    [
                        RuntimeCount::new(2),
                        RuntimeCount::new(4),
                        RuntimeCount::new(8),
                    ],
                    RuntimeCount::new(4),
                ),
            )
            .unwrap();
        let diagnostics = execution.diagnostics();
        let observer = diagnostics.three_warmups().unwrap();
        assert_eq!(
            observer.bounded_observer_bytes(),
            u64::try_from(
                size_of::<[ResponseLedger; 3]>()
                    + size_of::<[Option<WindowStart>; 3]>()
                    + size_of::<[RuntimeCount; BACKLOG_DIAGNOSTIC_BUCKETS]>() * 2
                    + size_of::<RuntimeCount>() * 2
            )
            .unwrap()
        );
        assert_eq!(
            observer.backlog_levels().exposures().len(),
            BACKLOG_DIAGNOSTIC_BUCKETS
        );
        let (evidence, retained) = execution.into_parts();
        assert_eq!(retained, diagnostics);
        assert_eq!(
            evidence.response().mutable_bytes(),
            8 * size_of::<RuntimeCount>()
        );
        assert_eq!(
            evidence.peak_memory().carrier_observer_bytes(),
            evidence.endpoint_memory().carrier_observer_bytes()
        );
        // Both durable return types have no horizon-indexed field.  Their
        // fixed layout is a compile-time structural guard against journals.
        assert!(size_of::<QualificationDiagnostics>() < 4_096);
        assert!(size_of::<ReplicationEvidence>() < 4_096);
    }

    #[test]
    fn fofs_cp05_qualification_coordinate_failure_exposes_no_result_and_retry_is_exact() {
        let prepared = run();
        let error = prepared
            .execute_qualification(
                ReplicationCoordinate::new(2),
                QualificationPlan::physical_only(),
            )
            .unwrap_err();
        assert!(matches!(
            error,
            RunError::ResultInvariantViolation {
                stage: RuntimeStage::EmptyInitialization,
                ..
            }
        ));
        let retried = prepared
            .execute_qualification(
                ReplicationCoordinate::new(3),
                QualificationPlan::construction_differential(),
            )
            .unwrap();
        let clean = run()
            .execute_qualification(
                ReplicationCoordinate::new(3),
                QualificationPlan::construction_differential(),
            )
            .unwrap();
        assert_eq!(retried, clean);
        assert!(retried.diagnostics().differential().unwrap().all_equal());
    }
}
