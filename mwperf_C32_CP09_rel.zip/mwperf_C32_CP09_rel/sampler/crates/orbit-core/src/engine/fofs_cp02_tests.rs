//! Final typed-fixture physical reference and focused CP05 engine regressions.

use std::cell::Cell;
use std::collections::BTreeSet;

use num_bigint::BigInt;

use super::*;
use crate::exact::{ExactRational, ExactUnsigned};
use crate::resolved::{
    ArrivalFamily, ConflictGraphTopology, ConflictPair, CountArrivalEvent, CrossbarEdge,
    CrossbarTopology, DelayedPeriodicSource, DeterministicTrace, GapLaw, IndependentMarkedRenewal,
    IndependentPrivateMarkovRenewal, InitialStateLaw, IntervalTopology, JointRoundEmission,
    JointRoundOutcome, MarkedRenewalLaw, MarkedRenewalSource, MarkovTransition, NodeExclusiveLink,
    NodeExclusiveTopology, PeriodicEntry, PeriodicGlobalPhase, PeriodicSource,
    PeriodicSourceDelays, PrivateMarkovSource, QueueInterval, QueueProbability, ResolvedArrival,
    ResolvedScheduler, ResourceDemand, ResourcePackingTopology, SchedulerFamily, SchedulerTopology,
    SharedJointRoundMarkovRenewal, SourceId, StateGap, StateId, TypedId,
};
use crate::unit_count::Arrival;

fn qid(position: usize) -> TypedId {
    TypedId::from(format!("q{position}"))
}

fn label(kind: &str, position: usize) -> TypedId {
    TypedId::from(format!("{kind}{position}"))
}

fn source(value: &str) -> SourceId {
    SourceId::new(value.to_owned())
}

fn state(value: &str) -> StateId {
    StateId::new(value.to_owned())
}

fn probability(numerator: i64, denominator: i64) -> ExactRational {
    ExactRational::new(
        BigInt::from(numerator),
        BigInt::from(denominator),
        "CP02 test probability",
    )
    .unwrap()
}

fn interval_scheduler(queue_count: usize) -> ResolvedScheduler {
    ResolvedScheduler {
        priority: (0..queue_count).map(qid).collect(),
        topology: SchedulerTopology::Interval(IntervalTopology {
            intervals: (0..queue_count)
                .map(|position| QueueInterval {
                    queue_id: qid(position),
                    left: ExactRational::from_integer(BigInt::from(2 * position)),
                    right: ExactRational::from_integer(BigInt::from(2 * position + 1)),
                })
                .collect(),
        }),
    }
}

fn scheduler_covering_set() -> Vec<ResolvedScheduler> {
    let priority = vec![qid(2), qid(0), qid(1)];
    vec![
        ResolvedScheduler {
            priority: priority.clone(),
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: vec![label("i", 0), label("i", 1)],
                outputs: vec![label("o", 0), label("o", 1)],
                edges: vec![
                    CrossbarEdge {
                        queue_id: qid(0),
                        input: label("i", 0),
                        output: label("o", 0),
                    },
                    CrossbarEdge {
                        queue_id: qid(1),
                        input: label("i", 1),
                        output: label("o", 1),
                    },
                    CrossbarEdge {
                        queue_id: qid(2),
                        input: label("i", 0),
                        output: label("o", 1),
                    },
                ],
            }),
        },
        ResolvedScheduler {
            priority: priority.clone(),
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: vec![
                    QueueInterval {
                        queue_id: qid(0),
                        left: ExactRational::from_integer(BigInt::from(0)),
                        right: ExactRational::from_integer(BigInt::from(2)),
                    },
                    QueueInterval {
                        queue_id: qid(1),
                        left: ExactRational::from_integer(BigInt::from(2)),
                        right: ExactRational::from_integer(BigInt::from(4)),
                    },
                    QueueInterval {
                        queue_id: qid(2),
                        left: ExactRational::from_integer(BigInt::from(1)),
                        right: ExactRational::from_integer(BigInt::from(3)),
                    },
                ],
            }),
        },
        ResolvedScheduler {
            priority: priority.clone(),
            topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                vertices: (0..4).map(|position| label("v", position)).collect(),
                links: vec![
                    NodeExclusiveLink {
                        queue_id: qid(0),
                        u: label("v", 0),
                        v: label("v", 1),
                    },
                    NodeExclusiveLink {
                        queue_id: qid(1),
                        u: label("v", 2),
                        v: label("v", 3),
                    },
                    NodeExclusiveLink {
                        queue_id: qid(2),
                        u: label("v", 1),
                        v: label("v", 2),
                    },
                ],
            }),
        },
        ResolvedScheduler {
            priority: priority.clone(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: vec![
                    ConflictPair {
                        first: qid(0),
                        second: qid(2),
                    },
                    ConflictPair {
                        first: qid(1),
                        second: qid(2),
                    },
                ],
                max_search_states: None,
            }),
        },
        ResolvedScheduler {
            priority,
            topology: SchedulerTopology::ResourcePacking(ResourcePackingTopology {
                resources: vec![label("r", 0), label("r", 1)],
                capacity: vec![ExactUnsigned::from_u64(2), ExactUnsigned::from_u64(2)],
                demands: vec![
                    ResourceDemand {
                        queue_id: qid(0),
                        demand: vec![ExactUnsigned::from_u64(2), ExactUnsigned::from_u64(0)],
                    },
                    ResourceDemand {
                        queue_id: qid(1),
                        demand: vec![ExactUnsigned::from_u64(0), ExactUnsigned::from_u64(2)],
                    },
                    ResourceDemand {
                        queue_id: qid(2),
                        demand: vec![ExactUnsigned::from_u64(1), ExactUnsigned::from_u64(1)],
                    },
                ],
                max_search_states: None,
            }),
        },
    ]
}

fn periodic_entry(offset: u64, queue: usize, count: u64) -> PeriodicEntry {
    PeriodicEntry {
        offset: ExactUnsigned::from_u64(offset),
        queue_id: qid(queue),
        count,
    }
}

fn provider_covering_set() -> Vec<ResolvedArrival> {
    let ready = state("ready");
    vec![
        ResolvedArrival::DeterministicTrace(DeterministicTrace {
            events: vec![
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(0),
                    count: 3,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(0),
                    queue_id: qid(1),
                    count: 2,
                },
                CountArrivalEvent {
                    slot: ExactUnsigned::from_u64(5),
                    queue_id: qid(2),
                    count: 4,
                },
            ],
        }),
        ResolvedArrival::PeriodicGlobalPhase(PeriodicGlobalPhase {
            period: ExactUnsigned::from_u64(4),
            phase: ExactUnsigned::from_u64(1),
            sources: vec![
                PeriodicSource {
                    id: source("global_a"),
                    entries: vec![periodic_entry(0, 0, 2), periodic_entry(3, 2, 1)],
                },
                PeriodicSource {
                    id: source("global_b"),
                    entries: vec![periodic_entry(0, 1, 2)],
                },
            ],
        }),
        ResolvedArrival::PeriodicSourceDelays(PeriodicSourceDelays {
            period: ExactUnsigned::from_u64(5),
            sources: vec![
                DelayedPeriodicSource {
                    id: source("delayed_a"),
                    delay: ExactUnsigned::from_u64(1),
                    entries: vec![periodic_entry(0, 0, 2), periodic_entry(4, 1, 1)],
                },
                DelayedPeriodicSource {
                    id: source("delayed_b"),
                    delay: ExactUnsigned::from_u64(7),
                    entries: vec![periodic_entry(0, 2, 3)],
                },
            ],
        }),
        ResolvedArrival::IndependentMarkedRenewal(IndependentMarkedRenewal {
            sources: vec![MarkedRenewalSource {
                id: source("marked"),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::Deterministic {
                        d: ExactUnsigned::from_u64(2),
                    },
                    destination_pmf: vec![
                        QueueProbability {
                            queue_id: qid(0),
                            probability: probability(1, 2),
                        },
                        QueueProbability {
                            queue_id: qid(1),
                            probability: probability(1, 2),
                        },
                    ],
                },
            }],
        }),
        ResolvedArrival::IndependentPrivateMarkovRenewal(IndependentPrivateMarkovRenewal {
            sources: vec![PrivateMarkovSource {
                id: source("private"),
                states: vec![ready.clone()],
                initial: InitialStateLaw::State(ready.clone()),
                gaps: vec![StateGap {
                    state: ready.clone(),
                    d: ExactUnsigned::from_u64(2),
                }],
                transitions: vec![MarkovTransition {
                    state: ready.clone(),
                    next_state: ready.clone(),
                    probability: probability(1, 1),
                }],
                destination_pmf: vec![
                    QueueProbability {
                        queue_id: qid(0),
                        probability: probability(1, 3),
                    },
                    QueueProbability {
                        queue_id: qid(1),
                        probability: probability(1, 3),
                    },
                    QueueProbability {
                        queue_id: qid(2),
                        probability: probability(1, 3),
                    },
                ],
            }],
        }),
        ResolvedArrival::SharedJointRoundMarkovRenewal(SharedJointRoundMarkovRenewal {
            sources: vec![source("shared_a"), source("shared_b"), source("shared_c")],
            states: vec![ready.clone()],
            initial: InitialStateLaw::State(ready.clone()),
            outcomes: vec![JointRoundOutcome {
                state: ready.clone(),
                next_state: ready,
                probability: probability(1, 1),
                emissions: vec![
                    JointRoundEmission {
                        source_id: source("shared_a"),
                        d: ExactUnsigned::from_u64(1),
                        queue_id: qid(0),
                    },
                    JointRoundEmission {
                        source_id: source("shared_b"),
                        d: ExactUnsigned::from_u64(2),
                        queue_id: qid(1),
                    },
                    JointRoundEmission {
                        source_id: source("shared_c"),
                        d: ExactUnsigned::from_u64(3),
                        queue_id: qid(2),
                    },
                ],
            }],
        }),
    ]
}

fn shared_pending_provider() -> ResolvedArrival {
    let ready = state("pending_ready");
    ResolvedArrival::SharedJointRoundMarkovRenewal(SharedJointRoundMarkovRenewal {
        sources: vec![source("fast"), source("slow")],
        states: vec![ready.clone()],
        initial: InitialStateLaw::State(ready.clone()),
        outcomes: vec![JointRoundOutcome {
            state: ready.clone(),
            next_state: ready,
            probability: probability(1, 1),
            emissions: vec![
                JointRoundEmission {
                    source_id: source("fast"),
                    d: ExactUnsigned::from_u64(1),
                    queue_id: qid(0),
                },
                JointRoundEmission {
                    source_id: source("slow"),
                    d: ExactUnsigned::from_u64(19),
                    queue_id: qid(1),
                },
            ],
        }],
    })
}

fn stable_binomial_run(replication_index: u64, seed_material: [u8; 32]) -> PreparedCountRun {
    let catalog = QueueCatalog::try_new(vec![qid(0)]).unwrap();
    let scheduler = ResolvedScheduler {
        priority: vec![qid(0)],
        topology: SchedulerTopology::Crossbar(CrossbarTopology {
            inputs: vec![TypedId::from("in0")],
            outputs: vec![TypedId::from("out0")],
            edges: vec![CrossbarEdge {
                queue_id: qid(0),
                input: TypedId::from("in0"),
                output: TypedId::from("out0"),
            }],
        }),
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let arrival = ResolvedArrival::IndependentMarkedRenewal(IndependentMarkedRenewal {
        sources: (0..4)
            .map(|position| MarkedRenewalSource {
                id: source(&format!("s{position}")),
                law: MarkedRenewalLaw::Factorized {
                    interarrival: GapLaw::GeometricGrid {
                        d_min: ExactUnsigned::from_u64(1),
                        delta: ExactUnsigned::from_u64(1),
                        p: probability(1, 8),
                    },
                    destination_pmf: vec![QueueProbability {
                        queue_id: qid(0),
                        probability: probability(1, 1),
                    }],
                },
            })
            .collect(),
    });
    let provider = PreparedArrival::try_compile(&arrival, &catalog).unwrap();
    let global_limits =
        ConstructionWorkLimits::try_new(512, OptimizerSearchStateGrant::NotApplicable, 100_000)
            .unwrap();
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::new(8),
        RuntimeCount::new(64),
        global_limits,
    )
    .unwrap();
    PreparedCountRun::try_bind_with_limits(
        problem,
        ArrivalReplay::from_seed_material(seed_material, replication_index),
        ConstructionWorkLimits::try_new(64, OptimizerSearchStateGrant::NotApplicable, 12_500)
            .unwrap(),
    )
    .unwrap()
}

fn typed_run(horizon: u64, warmup: u64, events: Vec<(u64, usize, u64)>) -> PreparedCountRun {
    let queue_count = events
        .iter()
        .map(|(_, queue, _)| queue + 1)
        .max()
        .unwrap_or(1);
    let catalog = QueueCatalog::try_new((0..queue_count).map(qid).collect()).unwrap();
    let scheduler = interval_scheduler(queue_count);
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let arrival = ResolvedArrival::DeterministicTrace(DeterministicTrace {
        events: events
            .into_iter()
            .map(|(slot, queue, count)| CountArrivalEvent {
                slot: ExactUnsigned::from_u64(slot),
                queue_id: qid(queue),
                count,
            })
            .collect(),
    });
    let provider = PreparedArrival::try_compile(&arrival, &catalog).unwrap();
    let limits = ConstructionWorkLimits::try_new(
        horizon,
        OptimizerSearchStateGrant::NotApplicable,
        1_000_000,
    )
    .unwrap();
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::new(warmup),
        RuntimeCount::new(horizon),
        limits,
    )
    .unwrap();
    PreparedCountRun::try_bind(problem, ArrivalReplay::from_seed_material([0x5a; 32], 7)).unwrap()
}

fn prepared_run(
    scheduler: ResolvedScheduler,
    arrival: ResolvedArrival,
    horizon: u64,
    warmup: u64,
    replay_index: u64,
) -> PreparedCountRun {
    let catalog = QueueCatalog::try_new((0..3).map(qid).collect()).unwrap();
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog).unwrap();
    let search_grant = if optimizer.search_states_are_applicable() {
        OptimizerSearchStateGrant::Bounded(1_000_000)
    } else {
        OptimizerSearchStateGrant::NotApplicable
    };
    let provider = PreparedArrival::try_compile(&arrival, &catalog).unwrap();
    let problem = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::new(warmup),
        RuntimeCount::new(horizon),
        ConstructionWorkLimits::try_new(horizon, search_grant, 1_000_000).unwrap(),
    )
    .unwrap();
    PreparedCountRun::try_bind(
        problem,
        ArrivalReplay::from_seed_material([0xa5; 32], replay_index),
    )
    .unwrap()
}

fn independent_dense_transition(
    q: &[RuntimeCount],
    service: &[u8],
    sparse_arrivals: &[Arrival],
) -> Result<Vec<RuntimeCount>, RunError> {
    if service.len() != q.len() {
        return Err(result_violation(
            RuntimeStage::SlotTransitionPreparation,
            "reference service width differs from Q",
        ));
    }
    let mut q_next = q.to_vec();
    for (position, (&before, &selected)) in q.iter().zip(service).enumerate() {
        if selected > 1 {
            return Err(result_violation(
                RuntimeStage::SlotTransitionPreparation,
                "reference service is not binary",
            ));
        }
        q_next[position] = before
            .checked_sub(
                RuntimeCount::new(u64::from(selected)),
                "reference predecision unit service",
            )
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
    }
    for &arrival in sparse_arrivals {
        let position = arrival
            .queue()
            .as_usize()
            .filter(|position| *position < q_next.len())
            .ok_or_else(|| {
                result_violation(
                    RuntimeStage::SlotTransitionPreparation,
                    "reference arrival queue is outside Q",
                )
            })?;
        q_next[position] = q_next[position]
            .checked_add(arrival.count(), "reference late same-slot arrival")
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
    }
    Ok(q_next)
}

/// The final dense/reference path accepts only typed prepared fixtures, calls
/// the ordinary Free solver, computes `Q-S+a` independently, and returns only
/// comparison coordinates. It never invokes the production carrier transition.
fn run_physical_reference(run: &PreparedCountRun) -> Result<Vec<ComparisonCoordinate>, RunError> {
    let problem = &run.problem;
    let budget = ArrivalDrawBudget::try_new(
        problem.limits.maximum_configured_generator_draws,
        C02_SEED_BRIDGE_WORDS,
    )
    .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
    let (mut provider_state, _initial_work) = problem
        .provider
        .try_start_counted(run.replay, budget)
        .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
    let mut carrier = UnitCountCarrier::try_empty(problem.catalog.clone())
        .map_err(|error| map_carrier_runtime(RuntimeStage::EmptyInitialization, error))?;
    let mut dense_q = carrier.occupancy().as_slice().to_vec();
    let mut origin = RuntimeCount::ZERO;
    let mut solver_scratch = problem.optimizer.try_replication_scratch()?;
    let mut coordinates = Vec::new();
    coordinates
        .try_reserve_exact(
            problem
                .horizon
                .try_to_usize("reference horizon")
                .map_err(|error| RunError::arithmetic(RuntimeStage::EmptyInitialization, error))?,
        )
        .map_err(|_| {
            resource_refusal(
                RuntimeStage::EmptyInitialization,
                "reference coordinate reservation failed",
            )
        })?;

    while origin < problem.horizon {
        carrier
            .replace_solver_occupancy_for_test(&dense_q)
            .map_err(|error| map_carrier_runtime(RuntimeStage::ColdMaxWeightSolve, error))?;
        let selected =
            problem
                .optimizer
                .select_free_with_scratch(&carrier, None, &mut solver_scratch)?;
        let q = dense_q.clone();
        let service = selected.candidate().service.as_slice().to_vec();
        let primary_objective = selected.candidate().primary_objective.clone();
        let tie_refinement = selected.candidate().tie_refinement.clone();
        let (arrivals, next_provider) = problem
            .provider
            .advance_dense_for_test(origin, &provider_state)
            .map_err(|error| map_arrival_runtime(RuntimeStage::SlotProviderAdvance, error))?;
        let q_next = independent_dense_transition(&q, &service, arrivals.entries())?;
        problem
            .optimizer
            .release_selected(selected, &mut solver_scratch)?;
        provider_state = next_provider;
        dense_q.clone_from(&q_next);
        coordinates.push(ComparisonCoordinate {
            origin,
            q,
            service,
            sparse_arrivals: arrivals.entries().to_vec(),
            q_next,
            provider_endpoint: provider_state.clone(),
            primary_objective,
            tie_refinement,
        });
        origin = origin
            .checked_add(RuntimeCount::new(1), "reference origin")
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
    }
    Ok(coordinates)
}

fn run_streaming_with_coordinates(
    run: &PreparedCountRun,
) -> Result<(CountRunResult, Vec<ComparisonCoordinate>), RunError> {
    let mut sink = ComparisonCoordinateSink::try_new(run.horizon())?;
    let result = run.execute_with_gate(&ProductionFaultGate, &mut sink)?;
    Ok((result, sink.coordinates))
}

#[test]
fn fofs_cp05_stream_matches_final_dense_reference_at_every_coordinate() {
    let run = typed_run(6, 0, vec![(0, 0, 3), (4, 0, 1)]);
    let reference = run_physical_reference(&run).unwrap();
    let (result, coordinates) = run_streaming_with_coordinates(&run).unwrap();

    assert_eq!(coordinates, reference);
    let expected_q = [0, 3, 2, 1, 0, 1];
    let expected_q_next = [3, 2, 1, 0, 1, 0];
    for (coordinate, (q, q_next)) in coordinates
        .iter()
        .zip(expected_q.into_iter().zip(expected_q_next))
    {
        assert_eq!(coordinate.q.as_slice(), &[RuntimeCount::new(q)]);
        assert_eq!(coordinate.q_next.as_slice(), &[RuntimeCount::new(q_next)]);
    }
    for coordinate in &coordinates[1..=3] {
        assert!(
            coordinate.sparse_arrivals.is_empty(),
            "origin {} must preserve the long idle gap",
            coordinate.origin.get()
        );
    }
    let endpoint = reference.last().unwrap();
    assert_eq!(result.carrier().occupancy().as_slice(), endpoint.q_next);
    assert_eq!(result.provider_endpoint(), &endpoint.provider_endpoint);
    assert_eq!(result.carrier().boundary(), RuntimeCount::new(6));
    assert_eq!(
        result.provider_endpoint().expected_slot(),
        RuntimeCount::new(6)
    );
    assert_eq!(result.work().exact_optimizer_calls(), 6);
    assert_eq!(result.work().committed_slots(), 6);
    assert_eq!(result.work().optimizer_search_states(), 0);
    assert_eq!(result.work().configured_generator_draws(), 4);
    assert_eq!(
        result.response().exposures().map(RuntimeCount::get),
        [2, 2, 1, 1]
    );
    assert_eq!(
        result.response().selected().map(RuntimeCount::get),
        [0, 2, 1, 1]
    );
}

#[test]
fn fofs_cp05_covering_pairs_exercise_all_schedulers_and_providers() {
    let schedulers = scheduler_covering_set();
    let providers = provider_covering_set();
    assert_eq!(schedulers.len(), 5);
    assert_eq!(providers.len(), 6);
    assert_eq!(
        schedulers
            .iter()
            .map(|scheduler| scheduler.topology.family())
            .collect::<BTreeSet<_>>(),
        BTreeSet::from([
            SchedulerFamily::CrossbarMaxWeight,
            SchedulerFamily::IntervalMaxWeight,
            SchedulerFamily::NodeExclusiveMaxWeight,
            SchedulerFamily::ConflictGraphMaxWeight,
            SchedulerFamily::ResourcePackingMaxWeight,
        ])
    );
    assert_eq!(
        providers
            .iter()
            .map(ResolvedArrival::family)
            .collect::<BTreeSet<_>>(),
        BTreeSet::from([
            ArrivalFamily::DeterministicTrace,
            ArrivalFamily::PeriodicGlobalPhase,
            ArrivalFamily::PeriodicSourceDelays,
            ArrivalFamily::IndependentMarkedRenewal,
            ArrivalFamily::IndependentPrivateMarkovRenewal,
            ArrivalFamily::SharedJointRoundMarkovRenewal,
        ])
    );
    for (position, provider) in providers.into_iter().enumerate() {
        let position_u64 = u64::try_from(position).unwrap();
        let run = prepared_run(
            schedulers[position % schedulers.len()].clone(),
            provider,
            8,
            position_u64 % 3,
            position_u64,
        );
        let reference = run_physical_reference(&run).unwrap();
        let (result, streaming) = run_streaming_with_coordinates(&run).unwrap();
        assert_eq!(streaming, reference, "covering pair {position}");
        let endpoint = reference.last().unwrap();
        assert_eq!(result.carrier().boundary(), RuntimeCount::new(8));
        assert_eq!(result.carrier().occupancy().as_slice(), endpoint.q_next);
        assert_eq!(result.provider_endpoint(), &endpoint.provider_endpoint);
        assert_eq!(
            result.provider_endpoint().expected_slot(),
            RuntimeCount::new(8)
        );
        assert_eq!(result.work().exact_optimizer_calls(), 8);
        assert_eq!(result.work().committed_slots(), 8);
    }
}

#[test]
fn fofs_cp05_primary_solve_count_is_exactly_r_times_t() {
    let template = typed_run(7, 2, vec![(0, 0, 2)]);
    let replications = 4_u64;
    let total_calls = (0..replications)
        .map(|replication| {
            let result = PreparedCountRun::try_bind(
                Arc::clone(template.problem()),
                ArrivalReplay::from_seed_material(
                    [u8::try_from(replication).unwrap(); 32],
                    replication,
                ),
            )
            .unwrap()
            .execute()
            .unwrap();
            assert_eq!(
                result.work().exact_optimizer_calls(),
                template.horizon().get()
            );
            assert_eq!(result.work().committed_slots(), template.horizon().get());
            result.work().exact_optimizer_calls()
        })
        .sum::<u64>();
    assert_eq!(total_calls, replications * template.horizon().get());
}

fn memory_component_bytes(memory: MutableMemoryAccounting) -> u64 {
    memory
        .carrier_observer_bytes()
        .checked_add(memory.solver_scratch_bytes())
        .and_then(|sum| sum.checked_add(memory.solver_logical_exact_integer_bytes()))
        .and_then(|sum| sum.checked_add(memory.arrival_fixed_bytes()))
        .and_then(|sum| sum.checked_add(memory.arrival_intrinsic_pending_bytes()))
        .and_then(|sum| sum.checked_add(memory.bookkeeping_and_staging_bytes()))
        .unwrap()
}

fn assert_memory_categories_reconcile(result: &CountRunResult) {
    let endpoint = result.endpoint_memory();
    let peak = result.peak_memory();
    assert_eq!(
        endpoint.total_mutable_bytes(),
        memory_component_bytes(endpoint)
    );
    assert!(peak.total_mutable_bytes() <= memory_component_bytes(peak));
    assert!(peak.total_mutable_bytes() >= endpoint.total_mutable_bytes());
    assert_eq!(
        result.work().peak_mutable_bytes(),
        peak.total_mutable_bytes()
    );
    for (peak_category, endpoint_category) in [
        (
            peak.carrier_observer_bytes(),
            endpoint.carrier_observer_bytes(),
        ),
        (peak.solver_scratch_bytes(), endpoint.solver_scratch_bytes()),
        (
            peak.solver_logical_exact_integer_bytes(),
            endpoint.solver_logical_exact_integer_bytes(),
        ),
        (peak.arrival_fixed_bytes(), endpoint.arrival_fixed_bytes()),
        (
            peak.arrival_intrinsic_pending_bytes(),
            endpoint.arrival_intrinsic_pending_bytes(),
        ),
        (
            peak.bookkeeping_and_staging_bytes(),
            endpoint.bookkeeping_and_staging_bytes(),
        ),
    ] {
        assert!(peak_category >= endpoint_category);
        assert!(peak.total_mutable_bytes() >= peak_category);
    }
    assert!(
        peak.arrival_intrinsic_pending_entries() >= endpoint.arrival_intrinsic_pending_entries()
    );
}

#[test]
fn fofs_cp05_bookkeeping_and_staged_transaction_headers_are_counted_once() {
    let result = typed_run(1, 0, Vec::new()).execute().unwrap();

    let durable_fields = std::mem::size_of::<UnitCountCarrier>()
        .checked_add(std::mem::size_of::<ArrivalState>())
        .and_then(|sum| sum.checked_add(std::mem::size_of::<ResponseLedger>()))
        .and_then(|sum| sum.checked_add(std::mem::size_of::<ConstructionWorkCounters>()))
        .and_then(|sum| sum.checked_add(std::mem::size_of::<MutableMemoryAccounting>()))
        .unwrap();
    let durable_padding = std::mem::size_of::<ReplicationDurable>()
        .checked_sub(durable_fields)
        .unwrap();
    let scratch_fields = std::mem::size_of::<ArrivalWorkspace>()
        .checked_add(std::mem::size_of::<CarrierWorkspace>())
        .and_then(|sum| sum.checked_add(std::mem::size_of::<OccupancySolverScratch>()))
        .unwrap();
    let scratch_padding = std::mem::size_of::<ReplicationScratch>()
        .checked_sub(scratch_fields)
        .unwrap();
    let endpoint_bookkeeping = u64::try_from(
        std::mem::size_of::<ConstructionWorkCounters>()
            .checked_add(std::mem::size_of::<MutableMemoryAccounting>())
            .and_then(|sum| sum.checked_add(durable_padding))
            .and_then(|sum| sum.checked_add(scratch_padding))
            .unwrap(),
    )
    .unwrap();
    let staged_transaction = u64::try_from(
        std::mem::size_of::<ConstructionWorkCounters>()
            .checked_add(std::mem::size_of::<MutableMemoryAccounting>())
            .and_then(|sum| sum.checked_add(std::mem::size_of::<PreparedCountCommit>()))
            .and_then(|sum| sum.checked_add(std::mem::size_of::<PreparedResponseCommit>()))
            .and_then(|sum| sum.checked_add(std::mem::size_of::<PreparedArrivalStep<'static>>()))
            .unwrap(),
    )
    .unwrap();

    assert_eq!(
        result.endpoint_memory().bookkeeping_and_staging_bytes(),
        endpoint_bookkeeping
    );
    assert_eq!(
        result.peak_memory().bookkeeping_and_staging_bytes(),
        endpoint_bookkeeping
            .checked_add(staged_transaction)
            .unwrap()
    );
    assert_memory_categories_reconcile(&result);
}

#[test]
fn fofs_cp05_memory_is_horizon_invariant_at_fixed_occupancy() {
    let short = typed_run(4, 0, Vec::new()).execute().unwrap();
    let long = typed_run(40, 0, Vec::new()).execute().unwrap();
    assert_eq!(
        short.peak_memory().carrier_observer_bytes(),
        long.peak_memory().carrier_observer_bytes()
    );
    assert_eq!(
        short.endpoint_memory().carrier_observer_bytes(),
        long.endpoint_memory().carrier_observer_bytes()
    );
    assert_eq!(
        short.peak_memory().solver_scratch_bytes(),
        long.peak_memory().solver_scratch_bytes()
    );
    assert_eq!(
        short.peak_memory().arrival_fixed_bytes(),
        long.peak_memory().arrival_fixed_bytes()
    );
    assert_eq!(
        short.peak_memory().arrival_intrinsic_pending_bytes(),
        long.peak_memory().arrival_intrinsic_pending_bytes()
    );
    assert_memory_categories_reconcile(&short);
    assert_memory_categories_reconcile(&long);
}

#[test]
fn fofs_cp05_carrier_observer_memory_is_occupancy_invariant_at_fixed_horizon() {
    let low = typed_run(4, 0, vec![(0, 0, 1)]).execute().unwrap();
    let high = typed_run(4, 0, vec![(0, 0, 1_000_000)]).execute().unwrap();
    assert_eq!(
        low.peak_memory().carrier_observer_bytes(),
        high.peak_memory().carrier_observer_bytes()
    );
    assert_eq!(
        low.endpoint_memory().carrier_observer_bytes(),
        high.endpoint_memory().carrier_observer_bytes()
    );
    assert_eq!(
        low.peak_memory().solver_scratch_bytes(),
        high.peak_memory().solver_scratch_bytes()
    );
    assert_eq!(
        low.peak_memory().arrival_fixed_bytes(),
        high.peak_memory().arrival_fixed_bytes()
    );
    assert_eq!(
        low.response().mutable_bytes(),
        8 * std::mem::size_of::<RuntimeCount>()
    );
    assert_memory_categories_reconcile(&low);
    assert_memory_categories_reconcile(&high);
}

#[test]
fn fofs_cp05_w_equals_t_is_private_rejected_input() {
    let catalog = QueueCatalog::try_new(vec![qid(0)]).unwrap();
    let optimizer =
        PreparedOccupancyMaxWeight::try_prepare(&interval_scheduler(1), &catalog).unwrap();
    let provider = PreparedArrival::try_compile(
        &ResolvedArrival::DeterministicTrace(DeterministicTrace { events: vec![] }),
        &catalog,
    )
    .unwrap();
    let error = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        provider,
        QueueIndex(0),
        RuntimeCount::new(1),
        RuntimeCount::new(1),
        ConstructionWorkLimits::try_new(1, OptimizerSearchStateGrant::NotApplicable, 4).unwrap(),
    )
    .unwrap_err();
    assert!(matches!(
        error,
        RunError::ResultInvariantViolation {
            stage: RuntimeStage::EmptyInitialization,
            ..
        }
    ));
}

#[test]
fn fofs_cp05_one_slot_scored_window_observes_only_origin_t_minus_one() {
    let result = typed_run(4, 3, vec![(0, 0, 3)]).execute().unwrap();
    assert_eq!(
        result.response().exposures().map(RuntimeCount::get),
        [0, 1, 0, 0]
    );
    assert_eq!(
        result.response().selected().map(RuntimeCount::get),
        [0, 1, 0, 0]
    );
}

struct OneShotFault {
    origin: RuntimeCount,
    point: FaultPoint,
    fired: Cell<bool>,
}

impl SlotFaultGate for OneShotFault {
    fn check(&self, origin: RuntimeCount, point: FaultPoint) -> Result<(), RunError> {
        if origin == self.origin && point == self.point && !self.fired.replace(true) {
            return Err(RunError::ResourceExhausted {
                stage: fault_runtime_stage(point),
                detail: format!("injected {point:?}"),
            });
        }
        Ok(())
    }
}

const fn fault_runtime_stage(point: FaultPoint) -> RuntimeStage {
    match point {
        FaultPoint::Snapshot => RuntimeStage::SlotSnapshot,
        FaultPoint::Solve => RuntimeStage::ColdMaxWeightSolve,
        FaultPoint::ServicePreparation => RuntimeStage::SlotServicePreparation,
        FaultPoint::ProviderAdvance => RuntimeStage::SlotProviderAdvance,
        FaultPoint::CarrierPreparation => RuntimeStage::SlotTransitionPreparation,
        FaultPoint::ObserverPreflight => RuntimeStage::SlotObserverPreflight,
        FaultPoint::CommitPreparation => RuntimeStage::SlotCommitPreparation,
    }
}

const fn run_error_stage(error: &RunError) -> RuntimeStage {
    match error {
        RunError::ArithmeticOverflow { stage, .. }
        | RunError::ArrivalContractViolation { stage, .. }
        | RunError::OptimizerContractViolation { stage, .. }
        | RunError::CarrierInvariantViolation { stage, .. }
        | RunError::ResultInvariantViolation { stage, .. }
        | RunError::ExactOptimizerFailure { stage, .. }
        | RunError::ExactOptimizerNoIncumbent { stage, .. }
        | RunError::ScientificGrantExhausted { stage, .. }
        | RunError::ResourceExhausted { stage, .. } => *stage,
    }
}

struct NoopResponseObserver;

impl ResponseObserverDriver for NoopResponseObserver {
    type Prepared = ();

    fn prepare(
        &self,
        _ledger: &ResponseLedger,
        _origin: RuntimeCount,
        _occupancy: RuntimeCount,
        _selected: u8,
        _warmup: RuntimeCount,
        _horizon: RuntimeCount,
    ) -> Result<Self::Prepared, RunError> {
        Ok(())
    }

    fn commit(&self, _ledger: &mut ResponseLedger, _prepared: Self::Prepared) {}
}

struct OneShotObserverPrepareError {
    fired: Cell<bool>,
}

impl ResponseObserverDriver for OneShotObserverPrepareError {
    type Prepared = crate::response_observer::PreparedResponseCommit;

    fn prepare(
        &self,
        ledger: &ResponseLedger,
        origin: RuntimeCount,
        occupancy: RuntimeCount,
        selected: u8,
        warmup: RuntimeCount,
        horizon: RuntimeCount,
    ) -> Result<Self::Prepared, RunError> {
        if !self.fired.replace(true) {
            return Err(RunError::ResourceExhausted {
                stage: RuntimeStage::SlotObserverPreflight,
                detail: "injected one-shot observer prepare error".to_owned(),
            });
        }
        ProductionResponseObserver.prepare(ledger, origin, occupancy, selected, warmup, horizon)
    }

    fn commit(&self, ledger: &mut ResponseLedger, prepared: Self::Prepared) {
        ProductionResponseObserver.commit(ledger, prepared);
    }
}

fn run_durable_with_observer<O: ResponseObserverDriver>(
    run: &PreparedCountRun,
    observer: &O,
) -> Result<(ReplicationDurable, Vec<ComparisonCoordinate>), RunError> {
    let (mut durable, mut scratch) = prepare_execution(run)?;
    let mut sink = ComparisonCoordinateSink::try_new(run.horizon())?;
    while durable.carrier.boundary() < run.horizon() {
        execute_one_slot_with_observer(
            run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
            observer,
        )?;
    }
    Ok((durable, sink.coordinates))
}

#[test]
fn fofs_cp05_noop_observer_is_physically_noninterfering() {
    let run = typed_run(6, 1, vec![(0, 0, 3), (4, 0, 1)]);
    let (observed, observed_coordinates) =
        run_durable_with_observer(&run, &ProductionResponseObserver).unwrap();
    let (noop, noop_coordinates) = run_durable_with_observer(&run, &NoopResponseObserver).unwrap();

    assert_eq!(observed_coordinates, noop_coordinates);
    assert_eq!(observed.carrier, noop.carrier);
    assert_eq!(observed.provider_state, noop.provider_state);
    assert_eq!(observed.work, noop.work);
    assert_ne!(observed.response, noop.response);

    // An intentionally injected physical-resource failure after both
    // observers prepare is identical and leaves the complete durable state
    // unchanged in either run.
    let gate = OneShotFault {
        origin: RuntimeCount::ZERO,
        point: FaultPoint::CommitPreparation,
        fired: Cell::new(false),
    };
    let (mut observed_durable, mut observed_scratch) = prepare_execution(&run).unwrap();
    let observed_before = observed_durable.clone();
    let mut observed_sink = ComparisonCoordinateSink::try_new(run.horizon()).unwrap();
    let observed_error = execute_one_slot_with_observer(
        &run,
        &mut observed_durable,
        &mut observed_scratch,
        &gate,
        &mut observed_sink,
        &ProductionResponseObserver,
    )
    .unwrap_err();
    assert_eq!(observed_durable, observed_before);

    let gate = OneShotFault {
        origin: RuntimeCount::ZERO,
        point: FaultPoint::CommitPreparation,
        fired: Cell::new(false),
    };
    let (mut noop_durable, mut noop_scratch) = prepare_execution(&run).unwrap();
    let noop_before = noop_durable.clone();
    let mut noop_sink = ComparisonCoordinateSink::try_new(run.horizon()).unwrap();
    let noop_error = execute_one_slot_with_observer(
        &run,
        &mut noop_durable,
        &mut noop_scratch,
        &gate,
        &mut noop_sink,
        &NoopResponseObserver,
    )
    .unwrap_err();
    assert_eq!(noop_durable, noop_before);
    assert_eq!(observed_error, noop_error);
}

#[test]
fn fofs_cp05_observer_prepare_error_rolls_back_and_retry_matches_clean_run() {
    let run = typed_run(5, 1, vec![(0, 0, 3), (4, 0, 1)]);
    let (clean_result, clean_coordinates) = run_streaming_with_coordinates(&run).unwrap();
    let (mut durable, mut scratch) = prepare_execution(&run).unwrap();
    let before = durable.clone();
    let mut sink = ComparisonCoordinateSink::try_new(run.horizon()).unwrap();
    let observer = OneShotObserverPrepareError {
        fired: Cell::new(false),
    };

    let error = execute_one_slot_with_observer(
        &run,
        &mut durable,
        &mut scratch,
        &ProductionFaultGate,
        &mut sink,
        &observer,
    )
    .unwrap_err();
    assert_eq!(run_error_stage(&error), RuntimeStage::SlotObserverPreflight);
    assert_eq!(durable, before);
    assert!(sink.coordinates.is_empty());

    while durable.carrier.boundary() < run.horizon() {
        execute_one_slot_with_observer(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
            &observer,
        )
        .unwrap();
    }
    let retried_result = finish_execution(&run, durable, &scratch).unwrap();
    assert_eq!(sink.coordinates, clean_coordinates);
    assert_eq!(retried_result, clean_result);
}

#[test]
fn fofs_cp05_every_slot_stage_failure_is_atomic_and_retryable() {
    let run = typed_run(2, 0, vec![(0, 0, 2)]);
    let (clean_result, clean_coordinates) = run_streaming_with_coordinates(&run).unwrap();
    for point in [
        FaultPoint::Snapshot,
        FaultPoint::Solve,
        FaultPoint::ServicePreparation,
        FaultPoint::ProviderAdvance,
        FaultPoint::CarrierPreparation,
        FaultPoint::ObserverPreflight,
        FaultPoint::CommitPreparation,
    ] {
        let (mut durable, mut scratch) = prepare_execution(&run).unwrap();
        let before = durable.clone();
        let mut sink = ComparisonCoordinateSink::try_new(run.horizon()).unwrap();
        let gate = OneShotFault {
            origin: RuntimeCount::ZERO,
            point,
            fired: Cell::new(false),
        };
        let error =
            execute_one_slot(&run, &mut durable, &mut scratch, &gate, &mut sink).unwrap_err();
        assert_eq!(run_error_stage(&error), fault_runtime_stage(point));
        assert_eq!(durable, before, "durable mutation at {point:?}");
        assert!(sink.coordinates.is_empty());

        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .unwrap();
        while durable.carrier.boundary() < run.horizon() {
            execute_one_slot(
                &run,
                &mut durable,
                &mut scratch,
                &ProductionFaultGate,
                &mut sink,
            )
            .unwrap();
        }
        let retried_result = finish_execution(&run, durable, &scratch).unwrap();
        assert_eq!(
            sink.coordinates, clean_coordinates,
            "retry path at {point:?}"
        );
        assert_eq!(retried_result, clean_result, "retry result at {point:?}");
    }
}

#[test]
fn fofs_cp03_failed_stage_attempt_work_peak_and_cleanup_are_complete() {
    let run = typed_run(2, 0, vec![(0, 0, 2)]);
    for point in [
        FaultPoint::Snapshot,
        FaultPoint::Solve,
        FaultPoint::ServicePreparation,
        FaultPoint::ProviderAdvance,
        FaultPoint::CarrierPreparation,
        FaultPoint::ObserverPreflight,
        FaultPoint::CommitPreparation,
    ] {
        let (mut durable, mut scratch) = prepare_execution(&run).unwrap();
        let before = durable.clone();
        let mut sink = NoCoordinateSink;
        let gate = OneShotFault {
            origin: RuntimeCount::ZERO,
            point,
            fired: Cell::new(false),
        };
        let error =
            execute_one_slot(&run, &mut durable, &mut scratch, &gate, &mut sink).unwrap_err();
        assert_eq!(run_error_stage(&error), fault_runtime_stage(point));
        assert_eq!(durable, before, "durable mutation at {point:?}");

        let attempt = scratch.attempt;
        if point == FaultPoint::Snapshot {
            assert_eq!(attempt, ConstructionWorkCounters::zero());
        } else {
            assert_eq!(attempt.exact_optimizer_calls(), 1, "solve at {point:?}");
            assert!(
                attempt.peak_mutable_bytes() > before.work.peak_mutable_bytes(),
                "prospective peak at {point:?}"
            );
            let expected_touched = u64::from(matches!(
                point,
                FaultPoint::ProviderAdvance
                    | FaultPoint::CarrierPreparation
                    | FaultPoint::ObserverPreflight
                    | FaultPoint::CommitPreparation
            ));
            assert_eq!(
                attempt.touched_queues(),
                expected_touched,
                "attempted touched union at {point:?}"
            );
        }

        // A successful retry proves that every checked-out solver buffer and
        // prospective provider batch was returned by the failed transaction.
        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .unwrap();
        assert_eq!(durable.carrier.boundary(), RuntimeCount::new(1));
    }
}

#[test]
fn fofs_cp05_provider_postallocation_peak_is_measured_and_rolled_back() {
    let run = prepared_run(interval_scheduler(3), shared_pending_provider(), 32, 0, 11);
    let clean = run.execute().unwrap();
    let (mut durable, mut scratch) = prepare_execution(&run).unwrap();
    scratch
        .arrivals
        .fail_after_next_shared_pending_reservation_for_test();
    let mut sink = NoCoordinateSink;

    let (failure_origin, provider_peak) = loop {
        let before = durable.clone();
        let origin = durable.carrier.boundary();
        match execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        ) {
            Ok(()) => {}
            Err(error) => {
                assert!(matches!(
                    error,
                    RunError::ResourceExhausted {
                        stage: RuntimeStage::SlotProviderAdvance,
                        ..
                    }
                ));
                assert_eq!(durable, before);
                assert!(scratch.attempt.touched_queues() > 0);
                assert!(scratch.attempt.configured_generator_draws() > 0);
                assert_eq!(
                    scratch.arrivals.memory_accounting().staged_pending_bytes,
                    0,
                    "failed provider storage is discarded after its peak is measured"
                );
                break (origin, scratch.attempt.peak_mutable_bytes());
            }
        }
    };

    // Measure the same state before provider advance. The extra peak in the
    // failed run is exactly evidence that the post-allocation provider buffer
    // was observed before rollback.
    let (mut baseline_durable, mut baseline_scratch) = prepare_execution(&run).unwrap();
    let mut baseline_sink = NoCoordinateSink;
    while baseline_durable.carrier.boundary() < failure_origin {
        execute_one_slot(
            &run,
            &mut baseline_durable,
            &mut baseline_scratch,
            &ProductionFaultGate,
            &mut baseline_sink,
        )
        .unwrap();
    }
    let service_gate = OneShotFault {
        origin: failure_origin,
        point: FaultPoint::ServicePreparation,
        fired: Cell::new(false),
    };
    execute_one_slot(
        &run,
        &mut baseline_durable,
        &mut baseline_scratch,
        &service_gate,
        &mut baseline_sink,
    )
    .unwrap_err();
    assert!(provider_peak > baseline_scratch.attempt.peak_mutable_bytes());

    // Retry the identical origin and finish; the full endpoint is unchanged.
    while durable.carrier.boundary() < run.horizon() {
        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .unwrap();
    }
    assert_eq!(finish_execution(&run, durable, &scratch).unwrap(), clean);
}

#[test]
fn fofs_cp05_shared_pending_growth_is_atomic_and_fully_accounted() {
    let run = prepared_run(interval_scheduler(3), shared_pending_provider(), 32, 0, 11);
    let (clean_result, clean_coordinates) = run_streaming_with_coordinates(&run).unwrap();
    assert_eq!(clean_coordinates, run_physical_reference(&run).unwrap());
    let consumed = clean_result.work().configured_generator_draws();
    let remaining = clean_result.remaining_configured_generator_draws();
    assert_eq!(
        consumed.checked_add(remaining).unwrap(),
        clean_result.limits().maximum_configured_generator_draws()
    );
    assert!(consumed > C02_SEED_BRIDGE_WORDS);
    assert!(
        clean_result
            .endpoint_memory()
            .arrival_intrinsic_pending_bytes()
            > 0
    );
    assert!(
        clean_result
            .endpoint_memory()
            .arrival_intrinsic_pending_entries()
            > 0
    );
    assert!(
        clean_result.peak_memory().arrival_intrinsic_pending_bytes()
            >= clean_result
                .endpoint_memory()
                .arrival_intrinsic_pending_bytes()
    );
    assert!(
        clean_result
            .peak_memory()
            .arrival_intrinsic_pending_entries()
            >= clean_result
                .endpoint_memory()
                .arrival_intrinsic_pending_entries()
    );
    assert_memory_categories_reconcile(&clean_result);

    // Locate a slot whose committed successor demonstrably expands the
    // durable shared-pending capacity, then replay that exact origin through
    // the post-provider-preparation failure seam below.
    let (mut probe_durable, mut probe_scratch) = prepare_execution(&run).unwrap();
    let mut probe_memory = probe_durable.provider_state.memory_accounting();
    let growth_origin = loop {
        let origin = probe_durable.carrier.boundary();
        assert!(
            origin < run.horizon(),
            "fixture must grow shared pending memory"
        );
        execute_one_slot(
            &run,
            &mut probe_durable,
            &mut probe_scratch,
            &ProductionFaultGate,
            &mut NoCoordinateSink,
        )
        .unwrap();
        let next_memory = probe_durable.provider_state.memory_accounting();
        if next_memory.shared_pending_bytes > probe_memory.shared_pending_bytes {
            break origin;
        }
        probe_memory = next_memory;
    };

    let (mut durable, mut scratch) = prepare_execution(&run).unwrap();
    let initial_provider_memory = durable.provider_state.memory_accounting();
    let mut sink = ComparisonCoordinateSink::try_new(run.horizon()).unwrap();
    while durable.carrier.boundary() < growth_origin {
        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .unwrap();
    }
    let before_growth = durable.clone();
    let before_coordinates = sink.coordinates.clone();
    let before_provider_memory = durable.provider_state.memory_accounting();
    let gate = OneShotFault {
        origin: growth_origin,
        point: FaultPoint::ProviderAdvance,
        fired: Cell::new(false),
    };
    let error = execute_one_slot(&run, &mut durable, &mut scratch, &gate, &mut sink).unwrap_err();
    assert_eq!(run_error_stage(&error), RuntimeStage::SlotProviderAdvance);
    assert_eq!(durable, before_growth);
    assert_eq!(sink.coordinates, before_coordinates);
    assert_eq!(scratch.arrivals.memory_accounting().staged_pending_bytes, 0);
    assert_eq!(
        scratch.arrivals.memory_accounting().staged_pending_entries,
        0
    );

    execute_one_slot(
        &run,
        &mut durable,
        &mut scratch,
        &ProductionFaultGate,
        &mut sink,
    )
    .unwrap();
    let after_provider_memory = durable.provider_state.memory_accounting();
    assert!(
        after_provider_memory.shared_pending_bytes > before_provider_memory.shared_pending_bytes
    );
    assert!(
        after_provider_memory.shared_pending_entries
            > before_provider_memory.shared_pending_entries
    );
    assert!(
        after_provider_memory.shared_pending_entries
            > initial_provider_memory.shared_pending_entries
    );
    while durable.carrier.boundary() < run.horizon() {
        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .unwrap();
    }
    let retried_result = finish_execution(&run, durable, &scratch).unwrap();
    assert_eq!(sink.coordinates, clean_coordinates);
    assert_eq!(retried_result, clean_result);
}

#[test]
fn fofs_cp05_sparse_arrivals_remain_ordered_and_count_compressed() {
    let run = typed_run(1, 0, vec![(0, 1, 2), (0, 0, 3), (0, 1, 4)]);
    let (_, coordinates) = run_streaming_with_coordinates(&run).unwrap();
    assert_eq!(
        coordinates[0].sparse_arrivals,
        vec![
            Arrival::new(QueueIndex(0), RuntimeCount::new(3)),
            Arrival::new(QueueIndex(1), RuntimeCount::new(6)),
        ]
    );
}

fn decode_stable_seed_material(text: &str) -> [u8; 32] {
    assert_eq!(text.len(), 64);
    let mut decoded = [0_u8; 32];
    for (index, byte) in decoded.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&text[index * 2..index * 2 + 2], 16).unwrap();
    }
    decoded
}

fn stable_hex(bytes: [u8; 32]) -> String {
    let mut encoded = String::with_capacity(64);
    for byte in bytes {
        use std::fmt::Write as _;
        write!(&mut encoded, "{byte:02x}").unwrap();
    }
    encoded
}

fn stable_binomial_physical_projection() -> serde_json::Value {
    const MATERIALS: [&str; 8] = [
        "b5cb99d21b2bab142afa50678107a43a7fa637006aa084b75e6e67320e074896",
        "cb246d926f018e125a3644188950971f0ba8df2add5b58471989a4f1588bc377",
        "f30f719131fc1229b06e1f189c2bc2c7e25a7bdf3f7548f44de17f5c6b8111aa",
        "2d35d67246938d9f0eb920a731090145d0ef0cc7afd4d0be85a6516bc09a0861",
        "174017a1ee16b71b1db16440918f55112bdd01d5bb611936dbe704dbeaf1dee9",
        "76e8b5de7067c4ab3ed7f15160c9eda1aa3b15c995fdce7bc81da93ac3eb9e6b",
        "963a020980c80984fc4252bc289e6d275e445a36d077f236cdf6b168e081fd1e",
        "21be65346c47285ae13da653ddd68825360e8bb3679b02361ff91590749fd625",
    ];

    let mut aggregate_exposures = [0_u64; 4];
    let mut aggregate_selected = [0_u64; 4];
    let mut aggregate_draws = 0_u64;
    let mut aggregate_optimizer_calls = 0_u64;
    let mut aggregate_search_states = 0_u64;
    let mut aggregate_slots = 0_u64;
    let mut aggregate_touched = 0_u64;
    let mut peak_mutable_bytes = 0_u64;
    let mut replications = Vec::with_capacity(MATERIALS.len());

    for (replication_index, material) in MATERIALS.iter().enumerate() {
        let replication_index = u64::try_from(replication_index).unwrap();
        let run = stable_binomial_run(replication_index, decode_stable_seed_material(material));
        let independent = run_physical_reference(&run).expect("independent dense physical path");
        let (result, production) =
            run_streaming_with_coordinates(&run).expect("streaming stable path");
        assert_eq!(production, independent, "replication {replication_index}");

        let path: Vec<_> = independent
            .iter()
            .map(|coordinate| {
                let sparse_arrivals: Vec<_> = coordinate
                    .sparse_arrivals
                    .iter()
                    .map(|arrival| {
                        serde_json::json!({
                            "queue": arrival.queue().as_usize().unwrap(),
                            "count": arrival.count().get(),
                        })
                    })
                    .collect();
                serde_json::json!({
                    "origin": coordinate.origin.get(),
                    "q": coordinate.q.iter().map(|count| count.get()).collect::<Vec<_>>(),
                    "selected": coordinate.service,
                    "sparse_arrivals": sparse_arrivals,
                    "q_next": coordinate.q_next.iter().map(|count| count.get()).collect::<Vec<_>>(),
                    "provider_cursor_digest": stable_hex(coordinate.provider_endpoint.endpoint_identity_v1()),
                    "primary_objective": coordinate.primary_objective.to_string(),
                    "exact_tie_witness": coordinate.tie_refinement.to_string(),
                    "endpoint": coordinate.provider_endpoint.expected_slot().get(),
                })
            })
            .collect();
        let exposures = result.response().exposures().map(RuntimeCount::get);
        let selected = result.response().selected().map(RuntimeCount::get);
        for bin in 0..4 {
            aggregate_exposures[bin] = aggregate_exposures[bin]
                .checked_add(exposures[bin])
                .unwrap();
            aggregate_selected[bin] = aggregate_selected[bin].checked_add(selected[bin]).unwrap();
        }
        let work = result.work();
        aggregate_draws = aggregate_draws
            .checked_add(work.configured_generator_draws())
            .unwrap();
        aggregate_optimizer_calls = aggregate_optimizer_calls
            .checked_add(work.exact_optimizer_calls())
            .unwrap();
        aggregate_search_states = aggregate_search_states
            .checked_add(work.optimizer_search_states())
            .unwrap();
        aggregate_slots = aggregate_slots.checked_add(work.committed_slots()).unwrap();
        aggregate_touched = aggregate_touched
            .checked_add(work.touched_queues())
            .unwrap();
        peak_mutable_bytes = peak_mutable_bytes.max(work.peak_mutable_bytes());
        let endpoint = result.provider_endpoint_identity();
        let conservation = result.carrier().conservation();
        replications.push(serde_json::json!({
            "replication_index": replication_index,
            "path": path,
            "ledger": {"E": exposures, "Y": selected},
            "endpoint_reconciliation": {
                "boundary": result.carrier().boundary().get(),
                "q": result.carrier().occupancy().as_slice().iter().map(|count| count.get()).collect::<Vec<_>>(),
                "total_arrivals": conservation.total_arrivals().get(),
                "total_services": conservation.total_services().get(),
                "provider_endpoint_identity": stable_hex(endpoint.endpoint_identity_digest()),
                "arrival_cursor_digest": stable_hex(endpoint.arrival_cursor_digest()),
                "scheduler_state_digest": stable_hex(endpoint.scheduler_state_digest()),
                "provider_expected_slot": endpoint.expected_slot().get(),
            },
            "work": {
                "configured_generator_draws": work.configured_generator_draws(),
                "exact_optimizer_calls": work.exact_optimizer_calls(),
                "optimizer_search_states": work.optimizer_search_states(),
                "committed_slots": work.committed_slots(),
                "touched_queues": work.touched_queues(),
                "peak_mutable_bytes": work.peak_mutable_bytes(),
            },
        }));
    }

    assert_eq!(aggregate_exposures.iter().sum::<u64>(), 8 * (64 - 8));
    assert_eq!(aggregate_selected[0], 0);
    assert!(aggregate_exposures.iter().all(|exposure| *exposure > 0));
    assert_eq!(aggregate_selected[1], aggregate_exposures[1]);
    assert_eq!(aggregate_selected[2], aggregate_exposures[2]);
    assert_eq!(aggregate_selected[3], aggregate_exposures[3]);
    assert_eq!(aggregate_optimizer_calls, 512);
    assert_eq!(aggregate_slots, 512);
    assert_eq!(aggregate_search_states, 0);

    serde_json::json!({
        "replay_coordinates": MATERIALS.iter().enumerate().map(|(index, material)| serde_json::json!({
            "replication_index": index,
            "upr1_seed_material_hex": material,
        })).collect::<Vec<_>>(),
        "replications": replications,
        "aggregate_ledger": {"E": aggregate_exposures, "Y": aggregate_selected},
        "aggregate_work": {
            "configured_generator_draws": aggregate_draws,
            "exact_optimizer_calls": aggregate_optimizer_calls,
            "optimizer_search_states": aggregate_search_states,
            "committed_slots": aggregate_slots,
            "touched_queues": aggregate_touched,
            "peak_mutable_bytes": peak_mutable_bytes,
        },
        "exact_fitted_response": {
            "mu0": {"kind":"rational","numerator":"0","denominator":"1"},
            "s1": {"kind":"rational","numerator":"1","denominator":"1"},
            "s2": {"kind":"rational","numerator":"1","denominator":"1"},
            "c": {"kind":"rational","numerator":"1","denominator":"1"},
        },
    })
}

/// This expensive fixture check is selected explicitly by the CP03 release
/// gate. `emit` was used once after the fixed seed/request/procedure had been
/// committed; normal gate runs use the default verification branch.
#[test]
#[ignore = "selected by the stable-construction qualification"]
fn fofs_cp03_stable_binomial_independent_expected_path() {
    let actual = stable_binomial_physical_projection();
    if std::env::var("FOFS_CP03_STABLE_GOLDEN_ACTION").as_deref() == Ok("emit") {
        println!("FOFS_CP03_STABLE_PHYSICAL_BEGIN");
        println!("{}", serde_json::to_string(&actual).unwrap());
        println!("FOFS_CP03_STABLE_PHYSICAL_END");
        return;
    }
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(std::path::Path::parent)
        .unwrap();
    let golden: serde_json::Value = serde_json::from_slice(
        &std::fs::read(root.join("validation/fixtures/StableBinomialConstructionGoldenV1.json"))
            .expect("stable construction golden"),
    )
    .expect("stable construction golden JSON");
    for field in [
        "replay_coordinates",
        "replications",
        "aggregate_ledger",
        "aggregate_work",
        "exact_fitted_response",
    ] {
        assert_eq!(golden[field], actual[field], "stable golden field {field}");
    }
}
