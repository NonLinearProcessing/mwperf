//! The sole production physical-orbit constructor.
//!
//! A run binds one full replay identity to immutable, framework-prepared
//! physical parts. Execution retains only its endpoint, the eight response
//! counters, measured work, and bounded memory accounting. There is no slot
//! journal, scoring drain, or counterfactual scheduling path.

use std::collections::hash_map::DefaultHasher;
use std::collections::HashMap;
use std::hash::BuildHasherDefault;
use std::mem::size_of;
use std::sync::Arc;

use crate::construction_observation::{
    BoundaryBacklogLawV1, BoundaryBacklogMassV1, ConstructionObservationBlockV1,
    ConstructionObservationReplicationV1, ExactLevelObservationV1,
    GapObservationValueV1, GapSignV1,
    ObservationCompletenessV1, ObservationGapCellV1, ObservationMassBalanceV1,
    ObservationPlanV1, ObservationScalarV1,
};
use crate::direct_count_arrivals::{
    ArrivalDrawBudget, ArrivalError, ArrivalReplay, ArrivalState, ArrivalWorkspace,
    ArrivalWorkspaceMemory, PreparedArrival, PreparedArrivalStep,
};
use crate::error::{RunError, RuntimeStage};
use crate::estimator::{
    ProviderFailureReason, ReplicationCoordinate, ReplicationEvidence, ReplicationFailureEvidence,
    ReplicationReport, ObservedReplicationReport,
};
use crate::exact::{ExactUnsigned, RuntimeCount};
use crate::gap_probe::{GapProbeError, GapSign, PreparedGapProbe};
use crate::observation_sha256::{
    ordinary_observation_replay_identity_v1, ObservationSha256,
};
use crate::occupancy_maxweight::{
    CandidateAction, OccupancySolverScratch, PreparedOccupancyMaxWeight,
};
use crate::response_observer::{PreparedResponseCommit, ResponseLedger};
use crate::unit_count::{
    CarrierError, CarrierWorkspace, PreparedCountCommit, ProspectiveSlot, QueueCatalog, QueueIndex,
    ServiceFeasibility, UnitCountCarrier,
};
use crate::resolved::TypedId;

#[cfg(feature = "qualification-test-support")]
pub mod qualification;

const C02_SEED_BRIDGE_WORDS: u64 = 4;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OptimizerSearchStateGrant {
    /// No aggregate runtime ceiling. Recursive optimizers still measure and
    /// report every expanded search state; nonrecursive optimizers report zero.
    NotApplicable,
    /// Optional aggregate runtime ceiling. Exhaustion is an execution result,
    /// not a scientific scenario-admission rule.
    Bounded(u64),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ConstructionWorkLimits {
    maximum_exact_optimizer_calls: u64,
    optimizer_search_states: OptimizerSearchStateGrant,
    maximum_configured_generator_draws: u64,
}

impl ConstructionWorkLimits {
    pub fn try_new(
        maximum_exact_optimizer_calls: u64,
        optimizer_search_states: OptimizerSearchStateGrant,
        maximum_configured_generator_draws: u64,
    ) -> Result<Self, RunError> {
        if maximum_exact_optimizer_calls == 0 {
            return Err(resource_refusal(
                RuntimeStage::EmptyInitialization,
                "maximum_exact_optimizer_calls is zero",
            ));
        }
        if maximum_configured_generator_draws < C02_SEED_BRIDGE_WORDS {
            return Err(resource_refusal(
                RuntimeStage::EmptyInitialization,
                "draw grant does not cover the four-word C02 seed bridge",
            ));
        }
        Ok(Self {
            maximum_exact_optimizer_calls,
            optimizer_search_states,
            maximum_configured_generator_draws,
        })
    }

    pub const fn maximum_exact_optimizer_calls(self) -> u64 {
        self.maximum_exact_optimizer_calls
    }
    pub const fn optimizer_search_states(self) -> OptimizerSearchStateGrant {
        self.optimizer_search_states
    }
    pub const fn maximum_configured_generator_draws(self) -> u64 {
        self.maximum_configured_generator_draws
    }
}

/// Immutable physical tables and bounds shared by replay-bound runs.
#[derive(Debug, Eq, PartialEq)]
pub struct PreparedCountProblem {
    catalog: QueueCatalog,
    optimizer: PreparedOccupancyMaxWeight,
    provider: PreparedArrival,
    target: QueueIndex,
    warmup: RuntimeCount,
    horizon: RuntimeCount,
    limits: ConstructionWorkLimits,
}

impl PreparedCountProblem {
    pub fn try_new(
        catalog: QueueCatalog,
        optimizer: PreparedOccupancyMaxWeight,
        provider: PreparedArrival,
        target: QueueIndex,
        warmup: RuntimeCount,
        horizon: RuntimeCount,
        limits: ConstructionWorkLimits,
    ) -> Result<Arc<Self>, RunError> {
        if horizon == RuntimeCount::ZERO {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "the construction horizon T is zero",
            ));
        }
        if warmup >= horizon {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "the response window must satisfy W < T",
            ));
        }
        if target
            .as_usize()
            .filter(|position| *position < catalog.len())
            .is_none()
        {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "the target queue is outside the immutable catalog",
            ));
        }
        if optimizer.catalog() != &catalog {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "the prepared optimizer belongs to another catalog",
            ));
        }
        if provider.queue_count() != catalog.len() {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "the prepared provider has another queue width",
            ));
        }
        if limits.maximum_exact_optimizer_calls < horizon.get() {
            return Err(resource_refusal(
                RuntimeStage::EmptyInitialization,
                "exact-optimizer call grant is smaller than T",
            ));
        }
        match (
            optimizer.search_states_are_applicable(),
            limits.optimizer_search_states,
        ) {
            // NotApplicable means that search work is observed as telemetry
            // but is not bounded by an aggregate construction grant.
            // A bounded zero reservation is also valid: partitioning a small
            // positive global runtime ceiling can assign zero to a worker,
            // which is then reported as deterministic runtime exhaustion.
            (true, _) => {}
            (false, OptimizerSearchStateGrant::NotApplicable) => {}
            (false, _) => {
                return Err(result_violation(
                    RuntimeStage::EmptyInitialization,
                    "nonrecursive exact family requires a not-applicable search-state grant",
                ));
            }
        }
        Ok(Arc::new(Self {
            catalog,
            optimizer,
            provider,
            target,
            warmup,
            horizon,
            limits,
        }))
    }

    pub const fn catalog(&self) -> &QueueCatalog {
        &self.catalog
    }
    pub const fn optimizer(&self) -> &PreparedOccupancyMaxWeight {
        &self.optimizer
    }
    pub const fn provider(&self) -> &PreparedArrival {
        &self.provider
    }
    pub const fn target(&self) -> QueueIndex {
        self.target
    }
    pub const fn warmup(&self) -> RuntimeCount {
        self.warmup
    }
    pub const fn horizon(&self) -> RuntimeCount {
        self.horizon
    }
    pub const fn limits(&self) -> ConstructionWorkLimits {
        self.limits
    }
}

/// One replay-bound physical orbit. Binding performs no draw or solve.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedCountRun {
    problem: Arc<PreparedCountProblem>,
    replay: ArrivalReplay,
    limits: ConstructionWorkLimits,
}

impl PreparedCountRun {
    pub fn try_bind(
        problem: Arc<PreparedCountProblem>,
        replay: ArrivalReplay,
    ) -> Result<Self, RunError> {
        if problem.horizon == RuntimeCount::ZERO || problem.warmup >= problem.horizon {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "cannot bind replay to an invalid prepared problem",
            ));
        }
        let limits = problem.limits;
        Ok(Self {
            problem,
            replay,
            limits,
        })
    }

    /// Bind one replication's deterministic reservation from a global grant.
    /// The reservation may only tighten the framework-prepared ceilings.
    pub fn try_bind_with_limits(
        problem: Arc<PreparedCountProblem>,
        replay: ArrivalReplay,
        limits: ConstructionWorkLimits,
    ) -> Result<Self, RunError> {
        validate_run_limits(&problem, limits)?;
        Ok(Self {
            problem,
            replay,
            limits,
        })
    }

    pub const fn problem(&self) -> &Arc<PreparedCountProblem> {
        &self.problem
    }
    pub const fn replay(&self) -> ArrivalReplay {
        self.replay
    }
    pub fn catalog(&self) -> &QueueCatalog {
        self.problem.catalog()
    }
    pub fn target(&self) -> QueueIndex {
        self.problem.target()
    }
    pub fn warmup(&self) -> RuntimeCount {
        self.problem.warmup()
    }
    pub fn horizon(&self) -> RuntimeCount {
        self.problem.horizon()
    }
    pub const fn limits(&self) -> ConstructionWorkLimits {
        self.limits
    }

    pub fn execute(&self) -> Result<CountRunResult, RunError> {
        self.execute_with_gate(&ProductionFaultGate, &mut NoCoordinateSink)
    }

    /// Execute a whole addressed replication and immediately erase the
    /// queue-wide carrier/provider endpoint into bounded CP03 evidence.
    pub fn execute_evidenced(&self, coordinate: ReplicationCoordinate) -> ReplicationReport {
        if self.replay.replication_index() != coordinate.index() {
            return ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                coordinate,
                self.replay,
                ProviderFailureReason::ConstructionInvariant,
                RunError::ResultInvariantViolation {
                    stage: RuntimeStage::EmptyInitialization,
                    detail: "replay and declared replication coordinates differ".to_owned(),
                },
                self.limits,
                ConstructionWorkCounters::zero(),
                None,
            )));
        }

        let mut initialization_work = ConstructionWorkCounters::zero();
        let (mut durable, mut scratch) =
            match prepare_execution_observed(self, &mut initialization_work) {
                Ok(prepared) => prepared,
                Err(error) => {
                    let reason = ProviderFailureReason::from_run_error(&error);
                    return ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                        coordinate,
                        self.replay,
                        reason,
                        error,
                        self.limits,
                        initialization_work,
                        None,
                    )));
                }
            };
        while durable.carrier.boundary() < self.problem.horizon {
            if let Err(error) = execute_one_slot(
                self,
                &mut durable,
                &mut scratch,
                &ProductionFaultGate,
                &mut NoCoordinateSink,
            ) {
                let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                let (reason, error, failure_work) =
                    match durable.work.checked_with_attempt(scratch.attempt) {
                        Some(work) => (ProviderFailureReason::from_run_error(&error), error, work),
                        None => (
                            ProviderFailureReason::ArithmeticBound,
                            RunError::ArithmeticOverflow {
                                stage: RuntimeStage::SlotCommitPreparation,
                                detail: "failed-attempt work accounting overflowed".to_owned(),
                            },
                            ConstructionWorkCounters {
                                configured_generator_draws: u64::MAX,
                                exact_optimizer_calls: u64::MAX,
                                optimizer_search_states: u64::MAX,
                                committed_slots: durable.work.committed_slots,
                                touched_queues: u64::MAX,
                                peak_mutable_bytes: durable
                                    .work
                                    .peak_mutable_bytes
                                    .max(scratch.attempt.peak_mutable_bytes),
                            },
                        ),
                    };
                return ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                    coordinate,
                    self.replay,
                    reason,
                    error,
                    self.limits,
                    failure_work,
                    endpoint.map(Box::new),
                )));
            }
        }
        match finish_summary(self, &durable, &scratch) {
            Ok(summary) => {
                let result = completed_result(self, durable, summary);
                ReplicationReport::Completed(Box::new(ReplicationEvidence::from_count_run(
                    coordinate, result,
                )))
            }
            Err(error) => {
                let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                    coordinate,
                    self.replay,
                    ProviderFailureReason::from_run_error(&error),
                    error,
                    self.limits,
                    durable.work,
                    endpoint.map(Box::new),
                )))
            }
        }
    }

    /// Fallibly allocate the complete ordinary observation sink before any
    /// optimizer or arrival-provider work for this replication begins.
    pub fn try_prepare_observation_sink(
        &self,
        plan: ObservationPlanV1,
        gap_probe: Option<Arc<dyn OrdinaryGapProbeV1>>,
    ) -> Result<PreparedOrdinaryObservationSink, RunError> {
        PreparedOrdinaryObservationSink::try_new(self, plan, gap_probe)
    }

    /// Compatibility convenience that prepares one sink and then executes
    /// immediately. Multi-replication hosts should prepare every sink first
    /// and call `execute_prepared_observed_evidenced` in their workers.
    pub fn execute_observed_evidenced(
        &self,
        coordinate: ReplicationCoordinate,
        replication_id: TypedId,
        plan: ObservationPlanV1,
        gap_probe: Option<Arc<dyn OrdinaryGapProbeV1>>,
    ) -> ObservedReplicationReport {
        let sink = match self.try_prepare_observation_sink(plan, gap_probe) {
            Ok(sink) => sink,
            Err(error) => {
                let observation_error = error.clone();
                return ObservedReplicationReport::new(
                    ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                        coordinate,
                        self.replay,
                        ProviderFailureReason::from_run_error(&error),
                        error,
                        self.limits,
                        ConstructionWorkCounters::zero(),
                        None,
                    ))),
                    None,
                    None,
                    Some(observation_error),
                );
            }
        };
        self.execute_prepared_observed_evidenced(coordinate, replication_id, sink)
    }

    /// Execute with a sink whose fallible vector/hash-table reservations were
    /// completed before the host launched any physical worker.
    pub fn execute_prepared_observed_evidenced(
        &self,
        coordinate: ReplicationCoordinate,
        replication_id: TypedId,
        mut sink: PreparedOrdinaryObservationSink,
    ) -> ObservedReplicationReport {
        if self.replay.replication_index() != coordinate.index() {
            let error = result_violation(
                RuntimeStage::EmptyInitialization,
                "replay and declared replication coordinates differ",
            );
            let (observation, arrival_stream_digest, observation_error) =
                finalize_ordinary_observation(sink, coordinate, replication_id);
            return ObservedReplicationReport::new(
                ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                    coordinate,
                    self.replay,
                    ProviderFailureReason::ConstructionInvariant,
                    error,
                    self.limits,
                    ConstructionWorkCounters::zero(),
                    None,
                ))),
                observation,
                arrival_stream_digest,
                observation_error,
            );
        }
        if !sink.authenticates(self) {
            let error = result_violation(
                RuntimeStage::EmptyInitialization,
                "prepared ordinary observation sink belongs to another physical problem",
            );
            let (observation, arrival_stream_digest, observation_error) =
                finalize_ordinary_observation(sink, coordinate, replication_id);
            return ObservedReplicationReport::new(
                ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                    coordinate,
                    self.replay,
                    ProviderFailureReason::ConstructionInvariant,
                    error,
                    self.limits,
                    ConstructionWorkCounters::zero(),
                    None,
                ))),
                observation,
                arrival_stream_digest,
                observation_error,
            );
        }
        let mut initialization_work = ConstructionWorkCounters::zero();
        let (mut durable, mut scratch) =
            match prepare_execution_observed(self, &mut initialization_work) {
                Ok(prepared) => prepared,
                Err(error) => {
                    let (observation, arrival_stream_digest, observation_error) =
                        finalize_ordinary_observation(sink, coordinate, replication_id);
                    return ObservedReplicationReport::new(
                        ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                            coordinate,
                            self.replay,
                            ProviderFailureReason::from_run_error(&error),
                            error,
                            self.limits,
                            initialization_work,
                            None,
                        ))),
                        observation,
                        arrival_stream_digest,
                        observation_error,
                    );
                }
            };
        while durable.carrier.boundary() < self.problem.horizon {
            if let Err(error) = execute_one_slot(
                self,
                &mut durable,
                &mut scratch,
                &ProductionFaultGate,
                &mut sink,
            ) {
                let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                let (reason, error, failure_work) =
                    match durable.work.checked_with_attempt(scratch.attempt) {
                        Some(work) => (ProviderFailureReason::from_run_error(&error), error, work),
                        None => (
                            ProviderFailureReason::ArithmeticBound,
                            RunError::ArithmeticOverflow {
                                stage: RuntimeStage::SlotCommitPreparation,
                                detail: "failed-attempt work accounting overflowed".to_owned(),
                            },
                            ConstructionWorkCounters {
                                configured_generator_draws: u64::MAX,
                                exact_optimizer_calls: u64::MAX,
                                optimizer_search_states: u64::MAX,
                                committed_slots: durable.work.committed_slots,
                                touched_queues: u64::MAX,
                                peak_mutable_bytes: durable
                                    .work
                                    .peak_mutable_bytes
                                    .max(scratch.attempt.peak_mutable_bytes),
                            },
                        ),
                    };
                let (observation, arrival_stream_digest, observation_error) =
                    finalize_ordinary_observation(sink, coordinate, replication_id);
                return ObservedReplicationReport::new(
                    ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                        coordinate,
                        self.replay,
                        reason,
                        error,
                        self.limits,
                        failure_work,
                        endpoint.map(Box::new),
                    ))),
                    observation,
                    arrival_stream_digest,
                    observation_error,
                );
            }
        }
        match finish_summary(self, &durable, &scratch) {
            Ok(summary) => {
                let arrival_stream_digest = sink.arrival_stream_digest();
                let observation = match sink.finalize(coordinate, replication_id) {
                    Ok(Some(observation)) => observation,
                    Ok(None) => {
                        let error = result_violation(
                            RuntimeStage::HorizonFinalization,
                            "a completed ordinary run produced no observation record",
                        );
                        let observation_error = error.clone();
                        let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                        return ObservedReplicationReport::new(
                            ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                                coordinate,
                                self.replay,
                                ProviderFailureReason::from_run_error(&error),
                                error,
                                self.limits,
                                durable.work,
                                endpoint.map(Box::new),
                            ))),
                            None,
                            Some(arrival_stream_digest),
                            Some(observation_error),
                        );
                    }
                    Err(error) => {
                        let observation_error = error.clone();
                        let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                        return ObservedReplicationReport::new(
                            ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                                coordinate,
                                self.replay,
                                ProviderFailureReason::from_run_error(&error),
                                error,
                                self.limits,
                                durable.work,
                                endpoint.map(Box::new),
                            ))),
                            None,
                            Some(arrival_stream_digest),
                            Some(observation_error),
                        );
                    }
                };
                let result = completed_result(self, durable, summary);
                ObservedReplicationReport::new(
                    ReplicationReport::Completed(Box::new(ReplicationEvidence::from_count_run(
                        coordinate, result,
                    ))),
                    Some(observation),
                    Some(arrival_stream_digest),
                    None,
                )
            }
            Err(error) => {
                let endpoint = failure_endpoint(self, &durable, &scratch).ok();
                let (observation, arrival_stream_digest, observation_error) =
                    finalize_ordinary_observation(sink, coordinate, replication_id);
                ObservedReplicationReport::new(
                    ReplicationReport::Failed(Box::new(ReplicationFailureEvidence::new(
                        coordinate,
                        self.replay,
                        ProviderFailureReason::from_run_error(&error),
                        error,
                        self.limits,
                        durable.work,
                        endpoint.map(Box::new),
                    ))),
                    observation,
                    arrival_stream_digest,
                    observation_error,
                )
            }
        }
    }

    fn execute_with_gate<G: SlotFaultGate, S: CoordinateSink>(
        &self,
        fault: &G,
        sink: &mut S,
    ) -> Result<CountRunResult, RunError> {
        let (mut durable, mut scratch) = prepare_execution(self)?;
        while durable.carrier.boundary() < self.problem.horizon {
            execute_one_slot(self, &mut durable, &mut scratch, fault, sink)?;
        }
        finish_execution(self, durable, &scratch)
    }
}

fn validate_run_limits(
    problem: &PreparedCountProblem,
    limits: ConstructionWorkLimits,
) -> Result<(), RunError> {
    if limits.maximum_exact_optimizer_calls < problem.horizon.get() {
        return Err(resource_refusal(
            RuntimeStage::EmptyInitialization,
            "replication exact-optimizer reservation is smaller than T",
        ));
    }
    if limits.maximum_exact_optimizer_calls > problem.limits.maximum_exact_optimizer_calls
        || limits.maximum_configured_generator_draws
            > problem.limits.maximum_configured_generator_draws
    {
        return Err(result_violation(
            RuntimeStage::EmptyInitialization,
            "replication reservation exceeds its framework-prepared global ceiling",
        ));
    }
    match (
        problem.limits.optimizer_search_states,
        limits.optimizer_search_states,
    ) {
        (OptimizerSearchStateGrant::NotApplicable, OptimizerSearchStateGrant::NotApplicable) => {}
        (
            OptimizerSearchStateGrant::Bounded(global),
            OptimizerSearchStateGrant::Bounded(replication),
        ) if replication <= global => {}
        _ => {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "replication search-state reservation is incompatible with the global ceiling",
            ));
        }
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ConstructionWorkCounters {
    configured_generator_draws: u64,
    exact_optimizer_calls: u64,
    optimizer_search_states: u64,
    committed_slots: u64,
    touched_queues: u64,
    peak_mutable_bytes: u64,
}

impl ConstructionWorkCounters {
    pub(crate) const fn zero() -> Self {
        Self {
            configured_generator_draws: 0,
            exact_optimizer_calls: 0,
            optimizer_search_states: 0,
            committed_slots: 0,
            touched_queues: 0,
            peak_mutable_bytes: 0,
        }
    }

    pub const fn configured_generator_draws(self) -> u64 {
        self.configured_generator_draws
    }
    pub const fn exact_optimizer_calls(self) -> u64 {
        self.exact_optimizer_calls
    }
    pub const fn optimizer_search_states(self) -> u64 {
        self.optimizer_search_states
    }
    pub const fn committed_slots(self) -> u64 {
        self.committed_slots
    }
    pub const fn touched_queues(self) -> u64 {
        self.touched_queues
    }
    pub const fn peak_mutable_bytes(self) -> u64 {
        self.peak_mutable_bytes
    }

    fn checked_with_attempt(self, attempt: Self) -> Option<Self> {
        Some(Self {
            configured_generator_draws: self
                .configured_generator_draws
                .checked_add(attempt.configured_generator_draws)?,
            exact_optimizer_calls: self
                .exact_optimizer_calls
                .checked_add(attempt.exact_optimizer_calls)?,
            optimizer_search_states: self
                .optimizer_search_states
                .checked_add(attempt.optimizer_search_states)?,
            committed_slots: self.committed_slots,
            touched_queues: self.touched_queues.checked_add(attempt.touched_queues)?,
            peak_mutable_bytes: self.peak_mutable_bytes.max(attempt.peak_mutable_bytes),
        })
    }

    #[cfg(test)]
    pub(crate) const fn for_test(
        configured_generator_draws: u64,
        exact_optimizer_calls: u64,
        optimizer_search_states: u64,
        committed_slots: u64,
        touched_queues: u64,
        peak_mutable_bytes: u64,
    ) -> Self {
        Self {
            configured_generator_draws,
            exact_optimizer_calls,
            optimizer_search_states,
            committed_slots,
            touched_queues,
            peak_mutable_bytes,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MutableMemoryAccounting {
    carrier_observer_bytes: u64,
    solver_scratch_bytes: u64,
    solver_logical_exact_integer_bytes: u64,
    arrival_fixed_bytes: u64,
    arrival_intrinsic_pending_bytes: u64,
    arrival_intrinsic_pending_entries: u64,
    bookkeeping_and_staging_bytes: u64,
    total_mutable_bytes: u64,
}

impl MutableMemoryAccounting {
    #[cfg(test)]
    pub(crate) const fn zero_for_test() -> Self {
        Self {
            carrier_observer_bytes: 0,
            solver_scratch_bytes: 0,
            solver_logical_exact_integer_bytes: 0,
            arrival_fixed_bytes: 0,
            arrival_intrinsic_pending_bytes: 0,
            arrival_intrinsic_pending_entries: 0,
            bookkeeping_and_staging_bytes: 0,
            total_mutable_bytes: 0,
        }
    }
    pub const fn carrier_observer_bytes(self) -> u64 {
        self.carrier_observer_bytes
    }
    pub const fn solver_scratch_bytes(self) -> u64 {
        self.solver_scratch_bytes
    }
    /// Logical magnitude bytes, distinct from allocator-capacity accounting.
    pub const fn solver_logical_exact_integer_bytes(self) -> u64 {
        self.solver_logical_exact_integer_bytes
    }
    pub const fn arrival_fixed_bytes(self) -> u64 {
        self.arrival_fixed_bytes
    }
    pub const fn arrival_intrinsic_pending_bytes(self) -> u64 {
        self.arrival_intrinsic_pending_bytes
    }
    pub const fn arrival_intrinsic_pending_entries(self) -> u64 {
        self.arrival_intrinsic_pending_entries
    }
    /// Inline replication bookkeeping and wrapper padding. At a measured slot
    /// peak this also includes the simultaneous heapless prepared-transaction
    /// headers, but not backing buffers already charged to another category.
    pub const fn bookkeeping_and_staging_bytes(self) -> u64 {
        self.bookkeeping_and_staging_bytes
    }
    pub const fn total_mutable_bytes(self) -> u64 {
        self.total_mutable_bytes
    }

    fn componentwise_max(self, other: Self) -> Self {
        Self {
            carrier_observer_bytes: self
                .carrier_observer_bytes
                .max(other.carrier_observer_bytes),
            solver_scratch_bytes: self.solver_scratch_bytes.max(other.solver_scratch_bytes),
            solver_logical_exact_integer_bytes: self
                .solver_logical_exact_integer_bytes
                .max(other.solver_logical_exact_integer_bytes),
            arrival_fixed_bytes: self.arrival_fixed_bytes.max(other.arrival_fixed_bytes),
            arrival_intrinsic_pending_bytes: self
                .arrival_intrinsic_pending_bytes
                .max(other.arrival_intrinsic_pending_bytes),
            arrival_intrinsic_pending_entries: self
                .arrival_intrinsic_pending_entries
                .max(other.arrival_intrinsic_pending_entries),
            bookkeeping_and_staging_bytes: self
                .bookkeeping_and_staging_bytes
                .max(other.bookkeeping_and_staging_bytes),
            // Component maxima need not have occurred at the same instant;
            // retain the independently measured total peak as its own value.
            total_mutable_bytes: self.total_mutable_bytes.max(other.total_mutable_bytes),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CountRunResult {
    replay: ArrivalReplay,
    carrier: UnitCountCarrier,
    provider_endpoint: ArrivalState,
    response: ResponseLedger,
    work: ConstructionWorkCounters,
    limits: ConstructionWorkLimits,
    peak_memory: MutableMemoryAccounting,
    endpoint_memory: MutableMemoryAccounting,
    target_reconciliation: TargetWindowReconciliation,
    provider_endpoint_identity: ProviderEndpointIdentity,
}

impl CountRunResult {
    pub const fn replay(&self) -> ArrivalReplay {
        self.replay
    }
    pub const fn carrier(&self) -> &UnitCountCarrier {
        &self.carrier
    }
    pub const fn provider_endpoint(&self) -> &ArrivalState {
        &self.provider_endpoint
    }
    pub const fn response(&self) -> &ResponseLedger {
        &self.response
    }
    pub const fn work(&self) -> ConstructionWorkCounters {
        self.work
    }
    pub const fn limits(&self) -> ConstructionWorkLimits {
        self.limits
    }
    pub const fn peak_memory(&self) -> MutableMemoryAccounting {
        self.peak_memory
    }
    pub const fn endpoint_memory(&self) -> MutableMemoryAccounting {
        self.endpoint_memory
    }
    pub const fn target_reconciliation(&self) -> TargetWindowReconciliation {
        self.target_reconciliation
    }
    pub const fn provider_endpoint_identity(&self) -> ProviderEndpointIdentity {
        self.provider_endpoint_identity
    }
    pub const fn remaining_configured_generator_draws(&self) -> u64 {
        self.limits
            .maximum_configured_generator_draws
            .saturating_sub(self.work.configured_generator_draws)
    }
}

/// Scalar, path-free target conservation evidence over `W <= t < T`.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TargetWindowReconciliation {
    window_length: RuntimeCount,
    target_backlog_at_w: RuntimeCount,
    target_backlog_at_t: RuntimeCount,
    scored_target_arrivals: RuntimeCount,
    scored_target_services: RuntimeCount,
    endpoint_total_arrivals: RuntimeCount,
    endpoint_total_services: RuntimeCount,
    endpoint_total_occupancy: u128,
}

impl TargetWindowReconciliation {
    #[cfg(test)]
    #[allow(clippy::too_many_arguments)]
    pub(crate) const fn for_test(
        window_length: RuntimeCount,
        target_backlog_at_w: RuntimeCount,
        target_backlog_at_t: RuntimeCount,
        scored_target_arrivals: RuntimeCount,
        scored_target_services: RuntimeCount,
        endpoint_total_arrivals: RuntimeCount,
        endpoint_total_services: RuntimeCount,
        endpoint_total_occupancy: u128,
    ) -> Self {
        Self {
            window_length,
            target_backlog_at_w,
            target_backlog_at_t,
            scored_target_arrivals,
            scored_target_services,
            endpoint_total_arrivals,
            endpoint_total_services,
            endpoint_total_occupancy,
        }
    }
    pub const fn window_length(self) -> RuntimeCount {
        self.window_length
    }
    pub const fn target_backlog_at_w(self) -> RuntimeCount {
        self.target_backlog_at_w
    }
    pub const fn target_backlog_at_t(self) -> RuntimeCount {
        self.target_backlog_at_t
    }
    pub const fn scored_target_arrivals(self) -> RuntimeCount {
        self.scored_target_arrivals
    }
    pub const fn scored_target_services(self) -> RuntimeCount {
        self.scored_target_services
    }
    pub const fn endpoint_total_arrivals(self) -> RuntimeCount {
        self.endpoint_total_arrivals
    }
    pub const fn endpoint_total_services(self) -> RuntimeCount {
        self.endpoint_total_services
    }
    pub const fn endpoint_total_occupancy(self) -> u128 {
        self.endpoint_total_occupancy
    }
}

/// Three stable digests used by the path-free provider endpoint evidence.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ProviderEndpointIdentity {
    endpoint_identity_digest: [u8; 32],
    arrival_cursor_digest: [u8; 32],
    scheduler_state_digest: [u8; 32],
    expected_slot: RuntimeCount,
}

impl ProviderEndpointIdentity {
    #[cfg(test)]
    pub(crate) const fn for_test(expected_slot: RuntimeCount, tag: u8) -> Self {
        Self {
            endpoint_identity_digest: [tag; 32],
            arrival_cursor_digest: [tag.wrapping_add(1); 32],
            scheduler_state_digest: [tag.wrapping_add(2); 32],
            expected_slot,
        }
    }
    pub const fn endpoint_identity_digest(self) -> [u8; 32] {
        self.endpoint_identity_digest
    }
    pub const fn arrival_cursor_digest(self) -> [u8; 32] {
        self.arrival_cursor_digest
    }
    pub const fn scheduler_state_digest(self) -> [u8; 32] {
        self.scheduler_state_digest
    }
    pub const fn expected_slot(self) -> RuntimeCount {
        self.expected_slot
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct TargetBoundarySnapshot {
    backlog: RuntimeCount,
    cumulative_arrivals: RuntimeCount,
    cumulative_services: RuntimeCount,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ReplicationDurable {
    carrier: UnitCountCarrier,
    provider_state: ArrivalState,
    response: ResponseLedger,
    work: ConstructionWorkCounters,
    peak_memory: MutableMemoryAccounting,
    target_window_start: Option<TargetBoundarySnapshot>,
}

struct ReplicationScratch {
    arrivals: ArrivalWorkspace,
    carrier: CarrierWorkspace,
    optimizer: OccupancySolverScratch,
    attempt: ConstructionWorkCounters,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum FaultPoint {
    Snapshot,
    Solve,
    ServicePreparation,
    ProviderAdvance,
    CarrierPreparation,
    ObserverPreflight,
    CommitPreparation,
}

trait SlotFaultGate {
    fn check(&self, _origin: RuntimeCount, _point: FaultPoint) -> Result<(), RunError> {
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct ProductionFaultGate;

impl SlotFaultGate for ProductionFaultGate {}

trait ResponseObserverDriver {
    type Prepared;

    fn prepare(
        &self,
        ledger: &ResponseLedger,
        origin: RuntimeCount,
        occupancy: RuntimeCount,
        selected: u8,
        warmup: RuntimeCount,
        horizon: RuntimeCount,
    ) -> Result<Self::Prepared, RunError>;

    fn commit(&self, ledger: &mut ResponseLedger, prepared: Self::Prepared);
}

struct ProductionResponseObserver;

impl ResponseObserverDriver for ProductionResponseObserver {
    type Prepared = crate::response_observer::PreparedResponseCommit;

    fn prepare(
        &self,
        ledger: &ResponseLedger,
        origin: RuntimeCount,
        occupancy: RuntimeCount,
        selected: u8,
        warmup: RuntimeCount,
        horizon: RuntimeCount,
    ) -> Result<Self::Prepared, RunError> {
        ledger.prepare(origin, occupancy, selected, warmup, horizon)
    }

    fn commit(&self, ledger: &mut ResponseLedger, prepared: Self::Prepared) {
        ledger.commit(prepared);
    }
}

trait CoordinateSink {
    type Prepared;

    fn prepare(
        &mut self,
        _view: ProspectiveSlot<'_>,
        _candidate: &CandidateAction,
    ) -> Result<Self::Prepared, RunError>;

    fn commit(
        &mut self,
        prepared: Self::Prepared,
        provider_endpoint: &ArrivalState,
        carrier_endpoint: &UnitCountCarrier,
    );
}

struct NoCoordinateSink;

impl CoordinateSink for NoCoordinateSink {
    type Prepared = ();

    fn prepare(
        &mut self,
        _view: ProspectiveSlot<'_>,
        _candidate: &CandidateAction,
    ) -> Result<Self::Prepared, RunError> {
        Ok(())
    }

    fn commit(
        &mut self,
        _prepared: Self::Prepared,
        _provider_endpoint: &ArrivalState,
        _carrier_endpoint: &UnitCountCarrier,
    ) {
    }
}

/// Allocation-free exact-gap callback prepared against the complete scheduler
/// and target binding before an ordinary run starts.  Unsupported topology is
/// represented by absence of a probe; it is never rediscovered in the slot
/// loop.
mod ordinary_gap_probe_sealed {
    pub trait Sealed {}

    impl Sealed for crate::gap_probe::PreparedGapProbe {}
}

#[allow(private_bounds)]
pub trait OrdinaryGapProbeV1: ordinary_gap_probe_sealed::Sealed + Send + Sync {
    fn target(&self) -> QueueIndex;

    fn queue_count(&self) -> usize;

    fn authenticates_optimizer(
        &self,
        optimizer: &PreparedOccupancyMaxWeight,
    ) -> Result<bool, RunError>;

    fn observe(
        &self,
        occupancy: &[RuntimeCount],
        target_was_served: bool,
    ) -> Result<GapObservationValueV1, RunError>;
}

impl OrdinaryGapProbeV1 for PreparedGapProbe {
    fn target(&self) -> QueueIndex {
        PreparedGapProbe::target(self)
    }

    fn queue_count(&self) -> usize {
        PreparedGapProbe::queue_count(self)
    }

    fn authenticates_optimizer(
        &self,
        optimizer: &PreparedOccupancyMaxWeight,
    ) -> Result<bool, RunError> {
        optimizer
            .authenticates_gap_probe(self)
            .map_err(map_gap_probe_runtime)
    }

    fn observe(
        &self,
        occupancy: &[RuntimeCount],
        target_was_served: bool,
    ) -> Result<GapObservationValueV1, RunError> {
        let observation = PreparedGapProbe::observe(self, occupancy, target_was_served)
            .map_err(map_gap_probe_runtime)?;
        let sign = match observation.sign() {
            GapSign::Negative => GapSignV1::Negative,
            GapSign::Tie => GapSignV1::Tie,
            GapSign::Positive => GapSignV1::Positive,
        };
        Ok(GapObservationValueV1::new(
            observation.competition_scale(),
            sign,
            observation.magnitude(),
        ))
    }
}

fn map_gap_probe_runtime(error: GapProbeError) -> RunError {
    let detail = format!("gap probe {}: {error}", error.code());
    if error == GapProbeError::CompetitionScaleOverflow {
        arithmetic_refusal(RuntimeStage::SlotObserverPreflight, detail)
    } else {
        result_violation(RuntimeStage::SlotObserverPreflight, detail)
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct OrdinaryGapTotals {
    negative: u128,
    tied: u128,
    positive: u128,
    tied_and_served: u128,
    positive_magnitude: u128,
    negative_magnitude: u128,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct OrdinaryLevelTotals {
    exposure: u128,
    served: u128,
    gap: OrdinaryGapTotals,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
struct OrdinaryLevelKey {
    block: usize,
    backlog: u64,
}

#[derive(Clone)]
struct PreparedOrdinaryObservationDelta {
    arrival_hasher: ObservationSha256,
    level: Option<(OrdinaryLevelKey, OrdinaryLevelTotals)>,
    successor_boundary_index: Option<usize>,
}

type OrdinaryLevelTable = HashMap<
    OrdinaryLevelKey,
    OrdinaryLevelTotals,
    BuildHasherDefault<DefaultHasher>,
>;

/// Production direct-count observation sink.  Every fallible arithmetic and
/// capacity decision is completed by `prepare`; `commit` performs only writes
/// into storage reserved before the physical run began.
pub struct PreparedOrdinaryObservationSink {
    prepared_problem: Arc<PreparedCountProblem>,
    plan: ObservationPlanV1,
    maximum_level_rows: usize,
    target: usize,
    gap_probe: Option<Arc<dyn OrdinaryGapProbeV1>>,
    levels: OrdinaryLevelTable,
    ordered_levels: Vec<(OrdinaryLevelKey, OrdinaryLevelTotals)>,
    finalized_blocks: Vec<ConstructionObservationBlockV1>,
    boundaries: Vec<Option<u64>>,
    last_committed_boundary: u64,
    last_target_backlog: u64,
    arrival_hasher: ObservationSha256,
}

impl PreparedOrdinaryObservationSink {
    pub fn try_new(
        run: &PreparedCountRun,
        plan: ObservationPlanV1,
        gap_probe: Option<Arc<dyn OrdinaryGapProbeV1>>,
    ) -> Result<Self, RunError> {
        if plan.warmup_boundary != run.warmup().get()
            || plan.end_boundary != run.horizon().get()
        {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "ordinary observation plan does not match the physical W,T window",
            ));
        }
        if plan.gap_telemetry != gap_probe.is_some() {
            return Err(result_violation(
                RuntimeStage::EmptyInitialization,
                "ordinary observation gap capability and prepared probe disagree",
            ));
        }
        let target = run
            .target()
            .as_usize()
            .filter(|target| *target < run.catalog().len())
            .ok_or_else(|| {
                result_violation(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation target is outside the queue catalog",
                )
            })?;
        if let Some(probe) = &gap_probe {
            if probe.target() != run.target()
                || probe.queue_count() != run.catalog().len()
                || !probe.authenticates_optimizer(run.problem().optimizer())?
            {
                return Err(result_violation(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation gap probe does not match the complete prepared scheduler binding",
                ));
            }
        }
        let required_boundary_rows = plan.block_count().checked_mul(2).ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::EmptyInitialization,
                "ordinary observation boundary-row requirement overflowed",
            )
        })?;
        if required_boundary_rows > plan.maximum_boundary_rows_per_replication {
            return Err(resource_refusal(
                RuntimeStage::EmptyInitialization,
                "ordinary observation boundary-row cap is smaller than the block plan",
            ));
        }
        if required_boundary_rows > plan.maximum_total_rows_per_replication {
            return Err(resource_refusal(
                RuntimeStage::EmptyInitialization,
                "ordinary observation boundary rows exhaust the combined row cap",
            ));
        }
        let maximum_level_rows = plan
            .maximum_sparse_rows_per_replication
            .min(plan.maximum_total_rows_per_replication - required_boundary_rows);
        let mut levels = OrdinaryLevelTable::default();
        levels
            .try_reserve(maximum_level_rows)
            .map_err(|_error| {
                resource_refusal(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation sparse-table reservation failed",
                )
            })?;
        let mut ordered_levels = Vec::new();
        ordered_levels
            .try_reserve_exact(maximum_level_rows)
            .map_err(|_error| {
                resource_refusal(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation ordered-row reservation failed",
                )
            })?;
        // A finalized block owns its level vector in the frozen observation
        // DTO. Reserve each block's mathematical maximum before execution so
        // finalization only moves committed totals into prepared storage.
        let mut finalized_blocks = Vec::new();
        finalized_blocks
            .try_reserve_exact(plan.block_count())
            .map_err(|_error| {
                resource_refusal(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation final-block reservation failed",
                )
            })?;
        for boundaries in plan.reporting_block_boundaries.windows(2) {
            let begin = boundaries[0];
            let end = boundaries[1];
            let block_length = usize::try_from(end - begin).unwrap_or(usize::MAX);
            let mut finalized_levels = Vec::new();
            finalized_levels
                .try_reserve_exact(block_length.min(maximum_level_rows))
                .map_err(|_error| {
                    resource_refusal(
                        RuntimeStage::EmptyInitialization,
                        "ordinary observation final block-row reservation failed",
                    )
                })?;
            finalized_blocks.push(ConstructionObservationBlockV1 {
                begin_boundary: begin,
                end_boundary: end,
                completeness: ObservationCompletenessV1::Partial,
                committed_through_boundary: begin,
                levels: finalized_levels,
                exposure_mass_balance: ObservationMassBalanceV1::exact(0, 0),
                initial_boundary_law: prepare_exact_boundary_law(begin)?,
                committed_boundary_law: prepare_exact_boundary_law(begin)?,
            });
        }
        let mut boundaries = Vec::new();
        boundaries
            .try_reserve_exact(plan.reporting_block_boundaries.len())
            .map_err(|_error| {
                resource_refusal(
                    RuntimeStage::EmptyInitialization,
                    "ordinary observation boundary reservation failed",
                )
            })?;
        boundaries.resize(plan.reporting_block_boundaries.len(), None);
        if plan.warmup_boundary == 0 {
            boundaries[0] = Some(0);
        }
        // Only canonical committed batches enter this scientific identity.
        // Replay seed and replication coordinate are authenticated elsewhere;
        // including them here would make equal realized streams hash
        // differently. Paired arms use the same domain and broadcast updates.
        let mut arrival_hasher = ObservationSha256::new();
        arrival_hasher.update(b"MWPERF-ORDINARY-ARRIVAL-STREAM-V1\0");
        Ok(Self {
            prepared_problem: Arc::clone(run.problem()),
            plan,
            maximum_level_rows,
            target,
            gap_probe,
            levels,
            ordered_levels,
            finalized_blocks,
            boundaries,
            last_committed_boundary: 0,
            last_target_backlog: 0,
            arrival_hasher,
        })
    }

    pub fn arrival_stream_digest(&self) -> [u8; 32] {
        self.arrival_hasher.clone().finalize()
    }

    fn authenticates(&self, run: &PreparedCountRun) -> bool {
        self.prepared_problem.as_ref() == run.problem().as_ref()
    }

    pub const fn committed_through_boundary(&self) -> u64 {
        self.last_committed_boundary
    }

    fn prepare_delta(
        &self,
        view: ProspectiveSlot<'_>,
    ) -> Result<PreparedOrdinaryObservationDelta, RunError> {
        let mut arrival_hasher = self.arrival_hasher.clone();
        arrival_hasher.update(&view.origin().get().to_be_bytes());
        let arrival_count = u64::try_from(view.sparse_arrivals().len()).map_err(|_error| {
            arithmetic_refusal(
                RuntimeStage::SlotObserverPreflight,
                "ordinary arrival batch length exceeds u64",
            )
        })?;
        arrival_hasher.update(&arrival_count.to_be_bytes());
        for arrival in view.sparse_arrivals() {
            arrival_hasher.update(&arrival.queue().0.to_be_bytes());
            arrival_hasher.update(&arrival.count().get().to_be_bytes());
        }

        let origin = view.origin().get();
        let level = self
            .plan
            .block_index_for_slot(origin)
            .map(|block| {
                let backlog = view.before()[self.target].get();
                let served = view.service()[self.target];
                let key = OrdinaryLevelKey { block, backlog };
                if !self.levels.contains_key(&key)
                    && self.levels.len() == self.maximum_level_rows
                {
                    return Err(resource_refusal(
                        RuntimeStage::SlotObserverPreflight,
                        "ordinary observation sparse-row cap was exhausted",
                    ));
                }
                let mut totals = self.levels.get(&key).copied().unwrap_or_default();
                totals.exposure = totals.exposure.checked_add(1).ok_or_else(|| {
                    arithmetic_refusal(
                        RuntimeStage::SlotObserverPreflight,
                        "ordinary observation exposure counter overflowed",
                    )
                })?;
                totals.served = totals
                    .served
                    .checked_add(u128::from(served))
                    .ok_or_else(|| {
                        arithmetic_refusal(
                            RuntimeStage::SlotObserverPreflight,
                            "ordinary observation service counter overflowed",
                        )
                    })?;
                if let Some(probe) = &self.gap_probe {
                    let gap = probe.observe(view.before(), served != 0)?;
                    if backlog != 0
                        && ((gap.sign() == GapSignV1::Positive && served == 0)
                            || (gap.sign() == GapSignV1::Negative && served != 0))
                    {
                        return Err(result_violation(
                            RuntimeStage::SlotObserverPreflight,
                            "exact gap sign contradicts the actual positive-backlog service",
                        ));
                    }
                    match gap.sign() {
                        GapSignV1::Negative => {
                            totals.gap.negative = checked_observation_add(
                                totals.gap.negative,
                                1,
                                "ordinary negative-gap count",
                            )?;
                            totals.gap.negative_magnitude = checked_observation_add(
                                totals.gap.negative_magnitude,
                                gap.magnitude(),
                                "ordinary negative-gap magnitude",
                            )?;
                        }
                        GapSignV1::Tie => {
                            totals.gap.tied = checked_observation_add(
                                totals.gap.tied,
                                1,
                                "ordinary tie count",
                            )?;
                            totals.gap.tied_and_served = checked_observation_add(
                                totals.gap.tied_and_served,
                                u128::from(served),
                                "ordinary tied-and-served count",
                            )?;
                        }
                        GapSignV1::Positive => {
                            totals.gap.positive = checked_observation_add(
                                totals.gap.positive,
                                1,
                                "ordinary positive-gap count",
                            )?;
                            totals.gap.positive_magnitude = checked_observation_add(
                                totals.gap.positive_magnitude,
                                gap.magnitude(),
                                "ordinary positive-gap magnitude",
                            )?;
                        }
                    }
                }
                Ok((key, totals))
            })
            .transpose()?;
        let successor_boundary_index = self
            .plan
            .reporting_block_boundaries
            .binary_search(&view.next_boundary().get())
            .ok();
        Ok(PreparedOrdinaryObservationDelta {
            arrival_hasher,
            level,
            successor_boundary_index,
        })
    }

    fn commit_delta(
        &mut self,
        prepared: PreparedOrdinaryObservationDelta,
        carrier_endpoint: &UnitCountCarrier,
    ) {
        debug_assert_eq!(
            carrier_endpoint.boundary().get(),
            self.last_committed_boundary + 1
        );
        self.arrival_hasher = prepared.arrival_hasher;
        if let Some((key, totals)) = prepared.level {
            self.levels.insert(key, totals);
        }
        self.last_committed_boundary = carrier_endpoint.boundary().get();
        self.last_target_backlog = carrier_endpoint.occupancy().as_slice()[self.target].get();
        if let Some(index) = prepared.successor_boundary_index {
            self.boundaries[index] = Some(self.last_target_backlog);
        }
    }

    pub fn finalize(
        mut self,
        coordinate: ReplicationCoordinate,
        replication_id: TypedId,
    ) -> Result<Option<ConstructionObservationReplicationV1>, RunError> {
        if self.last_committed_boundary < self.plan.warmup_boundary {
            let arrival_stream_digest = self.arrival_hasher.finalize();
            let replay_identity = ordinary_observation_replay_identity_v1(
                &replication_id,
                coordinate.index(),
                arrival_stream_digest,
            );
            return Ok(Some(ConstructionObservationReplicationV1 {
                replication_id,
                replay_identity,
                lineage_arrival_identity: None,
                completeness: ObservationCompletenessV1::Partial,
                // No measured slot was committed. Observation-v1 represents
                // that empty measured prefix at W, independently of the
                // physical failure boundary that remains in legacy evidence.
                committed_through_boundary: self.plan.warmup_boundary,
                blocks: Vec::new(),
            }));
        }
        let committed_through = self.last_committed_boundary.min(self.plan.end_boundary);
        debug_assert!(self.ordered_levels.capacity() >= self.levels.len());
        self.ordered_levels
            .extend(self.levels.iter().map(|(key, totals)| (*key, *totals)));
        self.ordered_levels
            .sort_unstable_by_key(|(key, _totals)| *key);

        let mut emitted_blocks = 0_usize;
        for block in 0..self.plan.block_count() {
            let begin = self.plan.reporting_block_boundaries[block];
            let requested_end = self.plan.reporting_block_boundaries[block + 1];
            if begin >= committed_through {
                break;
            }
            let actual_end = requested_end.min(committed_through);
            let begin_backlog = self.boundary_value(begin).ok_or_else(|| {
                result_violation(
                    RuntimeStage::HorizonFinalization,
                    "ordinary observation is missing a committed initial boundary",
                )
            })?;
            let end_backlog = if actual_end == committed_through
                && self.last_committed_boundary == committed_through
            {
                self.last_target_backlog
            } else {
                self.boundary_value(actual_end).ok_or_else(|| {
                    result_violation(
                        RuntimeStage::HorizonFinalization,
                        "ordinary observation is missing a committed terminal boundary",
                    )
                })?
            };
            let first = self
                .ordered_levels
                .partition_point(|(key, _)| key.block < block);
            let last = self
                .ordered_levels
                .partition_point(|(key, _)| key.block <= block);
            let finalized = &mut self.finalized_blocks[block];
            if last - first > finalized.levels.capacity() {
                return Err(result_violation(
                    RuntimeStage::HorizonFinalization,
                    "ordinary observation exceeded its prepared final block-row arena",
                ));
            }
            let mut recorded_mass = 0_u128;
            for (key, totals) in &self.ordered_levels[first..last] {
                recorded_mass = recorded_mass.checked_add(totals.exposure).ok_or_else(|| {
                    arithmetic_refusal(
                        RuntimeStage::HorizonFinalization,
                        "ordinary observation finalized exposure overflowed",
                    )
                })?;
                finalized.levels.push(exact_level_from_totals(
                    key.backlog,
                    *totals,
                    self.plan.gap_telemetry,
                ));
            }
            let expected_mass = u128::from(actual_end - begin);
            if recorded_mass != expected_mass {
                return Err(result_violation(
                    RuntimeStage::HorizonFinalization,
                    "ordinary observation exposure does not equal its committed block length",
                ));
            }
            finalized.completeness = if actual_end == requested_end {
                ObservationCompletenessV1::Complete
            } else {
                ObservationCompletenessV1::Partial
            };
            finalized.committed_through_boundary = actual_end;
            finalized.exposure_mass_balance =
                ObservationMassBalanceV1::exact(recorded_mass, expected_mass);
            set_exact_boundary_law(&mut finalized.initial_boundary_law, begin, begin_backlog)?;
            set_exact_boundary_law(
                &mut finalized.committed_boundary_law,
                actual_end,
                end_backlog,
            )?;
            emitted_blocks += 1;
            if actual_end != requested_end {
                break;
            }
        }
        let completeness = if committed_through == self.plan.end_boundary {
            ObservationCompletenessV1::Complete
        } else {
            ObservationCompletenessV1::Partial
        };
        let serialized_row_count = self
            .ordered_levels
            .len()
            .checked_add(emitted_blocks.checked_mul(2).ok_or_else(|| {
                arithmetic_refusal(
                    RuntimeStage::HorizonFinalization,
                    "ordinary observation boundary-row total overflowed",
                )
            })?)
            .ok_or_else(|| {
                arithmetic_refusal(
                    RuntimeStage::HorizonFinalization,
                    "ordinary observation serialized-row total overflowed",
                )
            })?;
        if serialized_row_count > self.plan.maximum_total_rows_per_replication {
            return Err(resource_refusal(
                RuntimeStage::HorizonFinalization,
                "ordinary observation exceeded the combined serialized-row cap",
            ));
        }
        self.finalized_blocks.truncate(emitted_blocks);
        let arrival_stream_digest = self.arrival_hasher.finalize();
        let replay_identity = ordinary_observation_replay_identity_v1(
            &replication_id,
            coordinate.index(),
            arrival_stream_digest,
        );
        Ok(Some(ConstructionObservationReplicationV1 {
            replication_id,
            replay_identity,
            lineage_arrival_identity: None,
            completeness,
            committed_through_boundary: committed_through,
            blocks: self.finalized_blocks,
        }))
    }

    fn boundary_value(&self, boundary: u64) -> Option<u64> {
        self.plan
            .reporting_block_boundaries
            .binary_search(&boundary)
            .ok()
            .and_then(|index| self.boundaries[index])
    }
}

impl CoordinateSink for PreparedOrdinaryObservationSink {
    type Prepared = PreparedOrdinaryObservationDelta;

    fn prepare(
        &mut self,
        view: ProspectiveSlot<'_>,
        _candidate: &CandidateAction,
    ) -> Result<Self::Prepared, RunError> {
        self.prepare_delta(view)
    }

    fn commit(
        &mut self,
        prepared: Self::Prepared,
        _provider_endpoint: &ArrivalState,
        carrier_endpoint: &UnitCountCarrier,
    ) {
        self.commit_delta(prepared, carrier_endpoint);
    }
}

fn finalize_ordinary_observation(
    sink: PreparedOrdinaryObservationSink,
    coordinate: ReplicationCoordinate,
    replication_id: TypedId,
) -> (
    Option<ConstructionObservationReplicationV1>,
    Option<[u8; 32]>,
    Option<RunError>,
) {
    let arrival_stream_digest = sink.arrival_stream_digest();
    match sink.finalize(coordinate, replication_id) {
        Ok(observation) => (observation, Some(arrival_stream_digest), None),
        Err(error) => (None, Some(arrival_stream_digest), Some(error)),
    }
}

fn checked_observation_add(
    left: u128,
    right: u128,
    detail: &'static str,
) -> Result<u128, RunError> {
    left.checked_add(right)
        .ok_or_else(|| arithmetic_refusal(RuntimeStage::SlotObserverPreflight, detail))
}

fn prepare_exact_boundary_law(boundary: u64) -> Result<BoundaryBacklogLawV1, RunError> {
    let mut rows = Vec::new();
    rows.try_reserve_exact(1).map_err(|_error| {
        resource_refusal(
            RuntimeStage::EmptyInitialization,
            "ordinary observation final boundary-row reservation failed",
        )
    })?;
    rows.push(BoundaryBacklogMassV1 {
        backlog_level: ExactUnsigned::zero(),
        mass: ObservationScalarV1::exact_u128(1),
    });
    Ok(BoundaryBacklogLawV1 {
        boundary,
        rows,
        mass_balance: ObservationMassBalanceV1::exact(1, 1),
    })
}

fn set_exact_boundary_law(
    law: &mut BoundaryBacklogLawV1,
    boundary: u64,
    backlog: u64,
) -> Result<(), RunError> {
    let [row] = law.rows.as_mut_slice() else {
        return Err(result_violation(
            RuntimeStage::HorizonFinalization,
            "ordinary observation prepared boundary law lost its single row",
        ));
    };
    law.boundary = boundary;
    row.backlog_level = ExactUnsigned::from_u64(backlog);
    Ok(())
}

fn exact_level_from_totals(
    backlog: u64,
    totals: OrdinaryLevelTotals,
    include_gap: bool,
) -> ExactLevelObservationV1 {
    ExactLevelObservationV1 {
        backlog_level: ExactUnsigned::from_u64(backlog),
        exposure_mass: ObservationScalarV1::exact_u128(totals.exposure),
        served_mass: ObservationScalarV1::exact_u128(totals.served),
        gap: include_gap.then(|| ObservationGapCellV1 {
            negative_mass: ObservationScalarV1::exact_u128(totals.gap.negative),
            tie_mass: ObservationScalarV1::exact_u128(totals.gap.tied),
            positive_mass: ObservationScalarV1::exact_u128(totals.gap.positive),
            tied_and_served_mass: ObservationScalarV1::exact_u128(
                totals.gap.tied_and_served,
            ),
            positive_magnitude_mass: ObservationScalarV1::exact_u128(
                totals.gap.positive_magnitude,
            ),
            negative_magnitude_mass: ObservationScalarV1::exact_u128(
                totals.gap.negative_magnitude,
            ),
        }),
    }
}

#[cfg(test)]
#[derive(Clone, Debug, Eq, PartialEq)]
struct ComparisonCoordinate {
    origin: RuntimeCount,
    q: Vec<RuntimeCount>,
    service: Vec<u8>,
    sparse_arrivals: Vec<crate::unit_count::Arrival>,
    q_next: Vec<RuntimeCount>,
    provider_endpoint: ArrivalState,
    primary_objective: num_bigint::BigInt,
    tie_refinement: num_bigint::BigUint,
}

#[cfg(test)]
struct PreparedComparisonCoordinate {
    origin: RuntimeCount,
    q: Vec<RuntimeCount>,
    service: Vec<u8>,
    sparse_arrivals: Vec<crate::unit_count::Arrival>,
    q_next: Vec<RuntimeCount>,
    primary_objective: num_bigint::BigInt,
    tie_refinement: num_bigint::BigUint,
}

#[cfg(test)]
struct ComparisonCoordinateSink {
    coordinates: Vec<ComparisonCoordinate>,
}

#[cfg(test)]
impl ComparisonCoordinateSink {
    fn try_new(horizon: RuntimeCount) -> Result<Self, RunError> {
        let capacity = horizon
            .try_to_usize("test-only comparison-coordinate capacity")
            .map_err(|error| RunError::arithmetic(RuntimeStage::EmptyInitialization, error))?;
        let mut coordinates = Vec::new();
        coordinates.try_reserve_exact(capacity).map_err(|_| {
            resource_refusal(
                RuntimeStage::EmptyInitialization,
                "test-only comparison-coordinate reservation failed",
            )
        })?;
        Ok(Self { coordinates })
    }
}

#[cfg(test)]
impl CoordinateSink for ComparisonCoordinateSink {
    type Prepared = PreparedComparisonCoordinate;

    fn prepare(
        &mut self,
        view: ProspectiveSlot<'_>,
        candidate: &CandidateAction,
    ) -> Result<Self::Prepared, RunError> {
        Ok(PreparedComparisonCoordinate {
            origin: view.origin(),
            q: view.before().to_vec(),
            service: view.service().to_vec(),
            sparse_arrivals: view.sparse_arrivals().to_vec(),
            q_next: view.next().to_vec(),
            primary_objective: candidate.primary_objective.clone(),
            tie_refinement: candidate.tie_refinement.clone(),
        })
    }

    fn commit(
        &mut self,
        prepared: Self::Prepared,
        provider_endpoint: &ArrivalState,
        _carrier_endpoint: &UnitCountCarrier,
    ) {
        debug_assert!(self.coordinates.len() < self.coordinates.capacity());
        self.coordinates.push(ComparisonCoordinate {
            origin: prepared.origin,
            q: prepared.q,
            service: prepared.service,
            sparse_arrivals: prepared.sparse_arrivals,
            q_next: prepared.q_next,
            provider_endpoint: provider_endpoint.clone(),
            primary_objective: prepared.primary_objective,
            tie_refinement: prepared.tie_refinement,
        });
    }
}

fn prepare_execution(
    run: &PreparedCountRun,
) -> Result<(ReplicationDurable, ReplicationScratch), RunError> {
    let mut ignored_work = ConstructionWorkCounters::zero();
    prepare_execution_observed(run, &mut ignored_work)
}

fn prepare_execution_observed(
    run: &PreparedCountRun,
    attempted_work: &mut ConstructionWorkCounters,
) -> Result<(ReplicationDurable, ReplicationScratch), RunError> {
    *attempted_work = ConstructionWorkCounters {
        configured_generator_draws: C02_SEED_BRIDGE_WORDS,
        ..ConstructionWorkCounters::zero()
    };
    let limits = run.limits;
    let start_budget = ArrivalDrawBudget::try_new(
        limits.maximum_configured_generator_draws,
        C02_SEED_BRIDGE_WORDS,
    )
    .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
    let mut provider_attempted_draws = 0;
    let provider_start = run.problem.provider.try_start_counted_observed(
        run.replay,
        start_budget,
        &mut provider_attempted_draws,
    );
    attempted_work.configured_generator_draws = C02_SEED_BRIDGE_WORDS
        .checked_add(provider_attempted_draws)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::EmptyInitialization,
                "initial attempted configured-generator draw count overflowed",
            )
        })?;
    let (provider_state, start_work) = provider_start
        .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?;
    let configured_generator_draws = C02_SEED_BRIDGE_WORDS
        .checked_add(start_work.configured_generator_draws())
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::EmptyInitialization,
                "initial configured-generator draw count overflowed",
            )
        })?;
    if configured_generator_draws > limits.maximum_configured_generator_draws {
        return Err(resource_refusal(
            RuntimeStage::EmptyInitialization,
            "provider initialization crossed the draw grant",
        ));
    }
    if provider_state.expected_slot() != RuntimeCount::ZERO {
        return Err(result_violation(
            RuntimeStage::EmptyInitialization,
            "the provider did not start at origin zero",
        ));
    }
    let carrier = UnitCountCarrier::try_empty(run.problem.catalog.clone())
        .map_err(|error| map_carrier_runtime(RuntimeStage::EmptyInitialization, error))?;
    let scratch = ReplicationScratch {
        arrivals: run
            .problem
            .provider
            .try_workspace(&provider_state)
            .map_err(|error| map_arrival_runtime(RuntimeStage::EmptyInitialization, error))?,
        carrier: CarrierWorkspace::try_new(&carrier)
            .map_err(|error| map_carrier_runtime(RuntimeStage::EmptyInitialization, error))?,
        optimizer: run.problem.optimizer.try_replication_scratch()?,
        attempt: ConstructionWorkCounters::zero(),
    };
    let mut durable = ReplicationDurable {
        carrier,
        provider_state,
        response: ResponseLedger::empty(),
        work: ConstructionWorkCounters {
            configured_generator_draws,
            ..ConstructionWorkCounters::zero()
        },
        peak_memory: MutableMemoryAccounting {
            carrier_observer_bytes: 0,
            solver_scratch_bytes: 0,
            solver_logical_exact_integer_bytes: 0,
            arrival_fixed_bytes: 0,
            arrival_intrinsic_pending_bytes: 0,
            arrival_intrinsic_pending_entries: 0,
            bookkeeping_and_staging_bytes: 0,
            total_mutable_bytes: 0,
        },
        target_window_start: None,
    };
    durable.peak_memory = endpoint_memory(&durable, &scratch)?;
    durable.work.peak_mutable_bytes = durable.peak_memory.total_mutable_bytes;
    Ok((durable, scratch))
}

fn execute_one_slot<G: SlotFaultGate, S: CoordinateSink>(
    run: &PreparedCountRun,
    durable: &mut ReplicationDurable,
    scratch: &mut ReplicationScratch,
    fault: &G,
    sink: &mut S,
) -> Result<(), RunError> {
    execute_one_slot_with_observer(
        run,
        durable,
        scratch,
        fault,
        sink,
        &ProductionResponseObserver,
    )
}

fn execute_one_slot_with_observer<
    G: SlotFaultGate,
    S: CoordinateSink,
    O: ResponseObserverDriver,
>(
    run: &PreparedCountRun,
    durable: &mut ReplicationDurable,
    scratch: &mut ReplicationScratch,
    fault: &G,
    sink: &mut S,
    observer: &O,
) -> Result<(), RunError> {
    scratch.attempt = ConstructionWorkCounters::zero();
    let problem = &run.problem;
    let origin = durable.carrier.boundary();
    if origin >= problem.horizon
        || durable.provider_state.expected_slot() != origin
        || durable.work.committed_slots != origin.get()
    {
        return Err(result_violation(
            RuntimeStage::SlotSnapshot,
            "carrier, provider, work ledger, or horizon has a mismatched origin",
        ));
    }
    fault.check(origin, FaultPoint::Snapshot)?;

    if durable.work.exact_optimizer_calls >= run.limits.maximum_exact_optimizer_calls {
        return Err(scientific_grant_refusal(
            RuntimeStage::ColdMaxWeightSolve,
            "exact-optimizer call grant is exhausted",
        ));
    }
    let remaining_search_states = match run.limits.optimizer_search_states {
        OptimizerSearchStateGrant::NotApplicable => None,
        OptimizerSearchStateGrant::Bounded(maximum) => Some(
            maximum
                .checked_sub(durable.work.optimizer_search_states)
                .ok_or_else(|| {
                    result_violation(
                        RuntimeStage::SlotSnapshot,
                        "optimizer search-state work exceeds its grant",
                    )
                })?,
        ),
    };
    scratch.attempt.exact_optimizer_calls = 1;
    let selected = problem.optimizer.select_free_with_scratch_counted(
        &durable.carrier,
        remaining_search_states,
        &mut scratch.optimizer,
        &mut scratch.attempt.optimizer_search_states,
    )?;

    // Once a Free action checks out its request/service buffers, every
    // fallible exit below returns them and discards any provider stage.
    let staged = (|| {
        record_attempt_peak(
            durable,
            &scratch.carrier,
            &scratch.optimizer,
            scratch.arrivals.memory_accounting(),
            &mut scratch.attempt,
            &selected,
        )?;
        fault.check(origin, FaultPoint::Solve)?;

        let service = &selected.candidate().service;
        {
            let feasibility = problem
                .optimizer
                .service_feasibility_with_scratch(&mut scratch.optimizer);
            feasibility.validate(service).map_err(|error| {
                map_carrier_runtime(RuntimeStage::SlotServicePreparation, error)
            })?;
        }
        fault.check(origin, FaultPoint::ServicePreparation)?;

        let draw_budget = ArrivalDrawBudget::try_new(
            run.limits.maximum_configured_generator_draws,
            durable.work.configured_generator_draws,
        )
        .map_err(|error| map_arrival_runtime(RuntimeStage::SlotProviderAdvance, error))?;
        let prepared_arrivals = match problem.provider.prepare_step_counted_observed_staged(
            origin,
            &durable.provider_state,
            &mut scratch.arrivals,
            draw_budget,
            &mut scratch.attempt.configured_generator_draws,
        ) {
            Ok(prepared) => prepared,
            Err(error) => {
                scratch.attempt.touched_queues = attempted_touched_union_count(
                    scratch.optimizer.selected_dense(),
                    scratch.arrivals.attempted_touched(),
                    RuntimeStage::SlotProviderAdvance,
                )?;
                record_attempt_peak(
                    durable,
                    &scratch.carrier,
                    &scratch.optimizer,
                    scratch.arrivals.memory_accounting(),
                    &mut scratch.attempt,
                    &selected,
                )?;
                return Err(map_arrival_runtime(
                    RuntimeStage::SlotProviderAdvance,
                    error,
                ));
            }
        };
        let arrival_workspace_memory = prepared_arrivals.workspace_memory();
        let arrivals = prepared_arrivals.arrivals();
        scratch.attempt.touched_queues = touched_union_count(
            scratch.optimizer.selected_dense(),
            arrivals,
            RuntimeStage::SlotProviderAdvance,
        )?;
        record_attempt_peak(
            durable,
            &scratch.carrier,
            &scratch.optimizer,
            arrival_workspace_memory,
            &mut scratch.attempt,
            &selected,
        )?;
        fault.check(origin, FaultPoint::ProviderAdvance)?;

        let prepared_carrier = durable
            .carrier
            .prepare_slot(
                service,
                scratch.optimizer.selected_dense(),
                arrivals,
                &mut scratch.carrier,
            )
            .map_err(|error| map_carrier_runtime(RuntimeStage::SlotTransitionPreparation, error))?;
        let view =
            durable
                .carrier
                .prospective_view(service, arrivals, prepared_carrier, &scratch.carrier);
        let expected_next = origin
            .checked_add(RuntimeCount::new(1), "physical slot boundary")
            .map_err(|error| {
                RunError::arithmetic(RuntimeStage::SlotTransitionPreparation, error)
            })?;
        if view.origin() != origin || view.next_boundary() != expected_next {
            return Err(result_violation(
                RuntimeStage::SlotTransitionPreparation,
                "prospective carrier has a noncanonical boundary",
            ));
        }
        record_attempt_peak(
            durable,
            &scratch.carrier,
            &scratch.optimizer,
            arrival_workspace_memory,
            &mut scratch.attempt,
            &selected,
        )?;
        fault.check(origin, FaultPoint::CarrierPreparation)?;

        let target = problem
            .target
            .as_usize()
            .filter(|position| *position < view.before().len())
            .ok_or_else(|| {
                result_violation(
                    RuntimeStage::SlotObserverPreflight,
                    "prepared target is outside the prospective carrier",
                )
            })?;
        let prepared_window_start = if origin == problem.warmup {
            if durable.target_window_start.is_some() {
                return Err(result_violation(
                    RuntimeStage::SlotObserverPreflight,
                    "target window-start boundary was already captured",
                ));
            }
            Some(TargetBoundarySnapshot {
                backlog: view.before()[target],
                cumulative_arrivals: durable.carrier.conservation().cumulative_arrivals()[target],
                cumulative_services: durable.carrier.conservation().cumulative_services()[target],
            })
        } else {
            let snapshot_is_required = origin > problem.warmup;
            if durable.target_window_start.is_some() != snapshot_is_required {
                return Err(result_violation(
                    RuntimeStage::SlotObserverPreflight,
                    "target window-start boundary presence disagrees with the current origin",
                ));
            }
            None
        };
        let prepared_response = observer.prepare(
            &durable.response,
            origin,
            view.before()[target],
            view.service()[target],
            problem.warmup,
            problem.horizon,
        )?;
        fault.check(origin, FaultPoint::ObserverPreflight)?;

        let touched = u64::try_from(view.touched().count()).map_err(|_| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "touched-queue count exceeds u64",
            )
        })?;
        if scratch.attempt.touched_queues != touched {
            return Err(result_violation(
                RuntimeStage::SlotCommitPreparation,
                "arrival/service union differs from prospective carrier touched coordinates",
            ));
        }
        let mut next_work = durable.work;
        next_work.exact_optimizer_calls = next_work
            .exact_optimizer_calls
            .checked_add(1)
            .ok_or_else(|| {
                arithmetic_refusal(
                    RuntimeStage::SlotCommitPreparation,
                    "exact-optimizer call counter overflowed",
                )
            })?;
        next_work.optimizer_search_states = next_work
            .optimizer_search_states
            .checked_add(selected.search_states_used())
            .ok_or_else(|| {
                arithmetic_refusal(
                    RuntimeStage::SlotCommitPreparation,
                    "optimizer search-state counter overflowed",
                )
            })?;
        next_work.committed_slots = next_work.committed_slots.checked_add(1).ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "committed-slot counter overflowed",
            )
        })?;
        next_work.touched_queues =
            next_work
                .touched_queues
                .checked_add(touched)
                .ok_or_else(|| {
                    arithmetic_refusal(
                        RuntimeStage::SlotCommitPreparation,
                        "touched-queue counter overflowed",
                    )
                })?;
        let prepared_coordinate = sink.prepare(view, selected.candidate())?;
        let next_peak_memory = durable.peak_memory.componentwise_max(prospective_memory(
            durable,
            &scratch.carrier,
            &scratch.optimizer,
            arrival_workspace_memory,
            &selected,
        )?);
        scratch.attempt.peak_mutable_bytes = scratch
            .attempt
            .peak_mutable_bytes
            .max(next_peak_memory.total_mutable_bytes);
        next_work.peak_mutable_bytes = next_peak_memory.total_mutable_bytes;
        fault.check(origin, FaultPoint::CommitPreparation)?;
        Ok((
            prepared_carrier,
            prepared_response,
            next_work,
            next_peak_memory,
            prepared_coordinate,
            prepared_window_start,
        ))
    })();

    let (
        prepared_carrier,
        prepared_response,
        mut next_work,
        next_peak_memory,
        prepared_coordinate,
        prepared_window_start,
    ) = match staged {
        Ok(prepared) => prepared,
        Err(error) => {
            PreparedArrival::discard_step(&mut scratch.arrivals);
            problem
                .optimizer
                .release_selected(selected, &mut scratch.optimizer)?;
            return Err(error);
        }
    };

    // Release is the last fallible preparation. Everything after it is a
    // checked move/scalar write across the shared commit boundary.
    if let Err(error) = problem
        .optimizer
        .release_selected(selected, &mut scratch.optimizer)
    {
        PreparedArrival::discard_step(&mut scratch.arrivals);
        return Err(error);
    }
    let _receipt = durable
        .carrier
        .commit_prepared(prepared_carrier, &scratch.carrier);
    let provider_work = problem
        .provider
        .commit_step_counted(&mut durable.provider_state, &mut scratch.arrivals);
    next_work.configured_generator_draws = next_work
        .configured_generator_draws
        .checked_add(provider_work.configured_generator_draws())
        .expect("counted provider grant proves committed draw sum");
    debug_assert!(
        next_work.configured_generator_draws <= run.limits.maximum_configured_generator_draws
    );
    observer.commit(&mut durable.response, prepared_response);
    if let Some(snapshot) = prepared_window_start {
        durable.target_window_start = Some(snapshot);
    }
    durable.work = next_work;
    durable.peak_memory = next_peak_memory;
    scratch.attempt = ConstructionWorkCounters::zero();
    sink.commit(
        prepared_coordinate,
        &durable.provider_state,
        &durable.carrier,
    );
    Ok(())
}

fn finish_execution(
    run: &PreparedCountRun,
    durable: ReplicationDurable,
    scratch: &ReplicationScratch,
) -> Result<CountRunResult, RunError> {
    let summary = finish_summary(run, &durable, scratch)?;
    Ok(completed_result(run, durable, summary))
}

#[derive(Clone, Copy)]
struct FinishedSummary {
    endpoint_memory: MutableMemoryAccounting,
    target_reconciliation: TargetWindowReconciliation,
    provider_endpoint_identity: ProviderEndpointIdentity,
}

fn finish_summary(
    run: &PreparedCountRun,
    durable: &ReplicationDurable,
    scratch: &ReplicationScratch,
) -> Result<FinishedSummary, RunError> {
    if durable.carrier.boundary() != run.problem.horizon
        || durable.provider_state.expected_slot() != run.problem.horizon
        || durable.work.committed_slots != run.problem.horizon.get()
        || durable.work.exact_optimizer_calls != run.problem.horizon.get()
    {
        return Err(result_violation(
            RuntimeStage::HorizonFinalization,
            "physical endpoint or measured primary-solve count differs from T",
        ));
    }
    durable
        .carrier
        .validate_complete()
        .map_err(|error| map_carrier_runtime(RuntimeStage::HorizonFinalization, error))?;
    durable
        .response
        .validate_complete(run.problem.warmup, run.problem.horizon)?;
    let endpoint_memory = endpoint_memory(durable, scratch)?;
    let target_reconciliation = target_reconciliation(run, durable)?;
    let provider_endpoint_identity = provider_endpoint_identity(durable);
    Ok(FinishedSummary {
        endpoint_memory,
        target_reconciliation,
        provider_endpoint_identity,
    })
}

fn completed_result(
    run: &PreparedCountRun,
    durable: ReplicationDurable,
    summary: FinishedSummary,
) -> CountRunResult {
    CountRunResult {
        replay: run.replay,
        carrier: durable.carrier,
        provider_endpoint: durable.provider_state,
        response: durable.response,
        work: durable.work,
        limits: run.limits,
        peak_memory: durable.peak_memory,
        endpoint_memory: summary.endpoint_memory,
        target_reconciliation: summary.target_reconciliation,
        provider_endpoint_identity: summary.provider_endpoint_identity,
    }
}

fn target_reconciliation(
    run: &PreparedCountRun,
    durable: &ReplicationDurable,
) -> Result<TargetWindowReconciliation, RunError> {
    let target = run.target().as_usize().ok_or_else(|| {
        result_violation(
            RuntimeStage::HorizonFinalization,
            "target index does not fit the endpoint representation",
        )
    })?;
    let start = durable.target_window_start.ok_or_else(|| {
        result_violation(
            RuntimeStage::HorizonFinalization,
            "target window-start boundary was not captured",
        )
    })?;
    let conservation = durable.carrier.conservation();
    let target_backlog_at_t = *durable
        .carrier
        .occupancy()
        .as_slice()
        .get(target)
        .ok_or_else(|| {
            result_violation(
                RuntimeStage::HorizonFinalization,
                "target is outside endpoint occupancy",
            )
        })?;
    let endpoint_target_arrivals = conservation.cumulative_arrivals()[target];
    let endpoint_target_services = conservation.cumulative_services()[target];
    let scored_target_arrivals = endpoint_target_arrivals
        .checked_sub(
            start.cumulative_arrivals,
            "scored target arrival reconciliation",
        )
        .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?;
    let scored_target_services = endpoint_target_services
        .checked_sub(
            start.cumulative_services,
            "scored target service reconciliation",
        )
        .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?;
    let ledger_services =
        durable.response.selected()[1..]
            .iter()
            .try_fold(RuntimeCount::ZERO, |sum, value| {
                sum.checked_add(*value, "nonempty target service ledger")
                    .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))
            })?;
    if durable.response.y_0() != RuntimeCount::ZERO || ledger_services != scored_target_services {
        return Err(result_violation(
            RuntimeStage::HorizonFinalization,
            "response service ledger does not reconcile with target conservation",
        ));
    }
    let conservation_left = u128::from(start.backlog.get())
        .checked_add(u128::from(scored_target_arrivals.get()))
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::HorizonFinalization,
                "target conservation left side overflowed",
            )
        })?;
    let conservation_right = u128::from(target_backlog_at_t.get())
        .checked_add(u128::from(scored_target_services.get()))
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::HorizonFinalization,
                "target conservation right side overflowed",
            )
        })?;
    if conservation_left != conservation_right {
        return Err(result_violation(
            RuntimeStage::HorizonFinalization,
            "target window does not satisfy Q_T = Q_W - service + arrivals",
        ));
    }
    let endpoint_total_arrivals = conservation.total_arrivals();
    let endpoint_total_services = conservation.total_services();
    if u128::from(endpoint_total_arrivals.get())
        != durable
            .carrier
            .total_occupancy()
            .checked_add(u128::from(endpoint_total_services.get()))
            .ok_or_else(|| {
                arithmetic_refusal(
                    RuntimeStage::HorizonFinalization,
                    "aggregate endpoint conservation overflowed",
                )
            })?
    {
        return Err(result_violation(
            RuntimeStage::HorizonFinalization,
            "aggregate endpoint conservation is inconsistent",
        ));
    }
    Ok(TargetWindowReconciliation {
        window_length: run
            .horizon()
            .checked_sub(run.warmup(), "scored window length")
            .map_err(|error| RunError::arithmetic(RuntimeStage::HorizonFinalization, error))?,
        target_backlog_at_w: start.backlog,
        target_backlog_at_t,
        scored_target_arrivals,
        scored_target_services,
        endpoint_total_arrivals,
        endpoint_total_services,
        endpoint_total_occupancy: durable.carrier.total_occupancy(),
    })
}

fn provider_endpoint_identity(durable: &ReplicationDurable) -> ProviderEndpointIdentity {
    let arrival_cursor_digest = durable.provider_state.endpoint_identity_v1();
    let scheduler_state_digest = scheduler_state_identity(&durable.carrier);
    let mut hasher = blake3::Hasher::new();
    hasher.update(b"FOFS-PROVIDER-ENDPOINT-V1\0");
    hasher.update(&arrival_cursor_digest);
    hasher.update(&scheduler_state_digest);
    let endpoint_identity_digest = *hasher.finalize().as_bytes();
    ProviderEndpointIdentity {
        endpoint_identity_digest,
        arrival_cursor_digest,
        scheduler_state_digest,
        expected_slot: durable.provider_state.expected_slot(),
    }
}

fn scheduler_state_identity(carrier: &UnitCountCarrier) -> [u8; 32] {
    let mut hasher = blake3::Hasher::new();
    hasher.update(b"FOFS-SCHEDULER-ENDPOINT-V1\0");
    hasher.update(&carrier.boundary().get().to_be_bytes());
    hasher.update(&carrier.total_occupancy().to_be_bytes());
    hasher.update(&(carrier.catalog().len() as u64).to_be_bytes());
    for value in carrier.occupancy().as_slice() {
        hasher.update(&value.get().to_be_bytes());
    }
    for value in carrier.conservation().cumulative_arrivals() {
        hasher.update(&value.get().to_be_bytes());
    }
    for value in carrier.conservation().cumulative_services() {
        hasher.update(&value.get().to_be_bytes());
    }
    hasher.update(&carrier.conservation().total_arrivals().get().to_be_bytes());
    hasher.update(&carrier.conservation().total_services().get().to_be_bytes());
    *hasher.finalize().as_bytes()
}

fn failure_endpoint(
    run: &PreparedCountRun,
    durable: &ReplicationDurable,
    scratch: &ReplicationScratch,
) -> Result<crate::estimator::FailureEndpointEvidence, RunError> {
    let target = run.target().as_usize().ok_or_else(|| {
        result_violation(
            RuntimeStage::HorizonFinalization,
            "failure endpoint target index does not fit usize",
        )
    })?;
    let target_backlog = *durable
        .carrier
        .occupancy()
        .as_slice()
        .get(target)
        .ok_or_else(|| {
            result_violation(
                RuntimeStage::HorizonFinalization,
                "failure endpoint target is outside the carrier",
            )
        })?;
    let conservation = durable.carrier.conservation();
    let window_start = durable.target_window_start.or_else(|| {
        (durable.carrier.boundary() == run.warmup()).then(|| TargetBoundarySnapshot {
            backlog: target_backlog,
            cumulative_arrivals: conservation.cumulative_arrivals()[target],
            cumulative_services: conservation.cumulative_services()[target],
        })
    });
    Ok(crate::estimator::FailureEndpointEvidence::new(
        durable.carrier.boundary(),
        target_backlog,
        window_start.map(|snapshot| {
            (
                snapshot.backlog,
                snapshot.cumulative_arrivals,
                snapshot.cumulative_services,
            )
        }),
        durable.response,
        provider_endpoint_identity(durable),
        conservation.total_arrivals(),
        conservation.total_services(),
        durable.carrier.total_occupancy(),
        durable.peak_memory,
        endpoint_memory(durable, scratch)?,
    ))
}

fn endpoint_memory(
    durable: &ReplicationDurable,
    scratch: &ReplicationScratch,
) -> Result<MutableMemoryAccounting, RunError> {
    endpoint_memory_from_parts(
        durable,
        &scratch.carrier,
        &scratch.optimizer,
        scratch.arrivals.memory_accounting(),
    )
}

fn endpoint_memory_from_parts(
    durable: &ReplicationDurable,
    carrier: &CarrierWorkspace,
    optimizer: &OccupancySolverScratch,
    workspace: ArrivalWorkspaceMemory,
) -> Result<MutableMemoryAccounting, RunError> {
    let carrier_observer_bytes = checked_usize_sum(
        [
            size_of::<UnitCountCarrier>(),
            durable.carrier.mutable_bytes(),
            size_of::<CarrierWorkspace>(),
            carrier.mutable_bytes(),
            durable.response.mutable_bytes(),
        ],
        "carrier/observer memory",
    )?;
    let solver_scratch_bytes = checked_usize_sum(
        [
            size_of::<OccupancySolverScratch>(),
            optimizer.mutable_bytes(),
        ],
        "solver scratch memory",
    )?;
    let solver_logical_exact_integer_bytes = usize_to_u64(
        optimizer.logical_exact_integer_payload_bytes(),
        "solver logical exact-integer payload",
    )?;
    let state = durable.provider_state.memory_accounting();
    let arrival_fixed_bytes = checked_usize_sum(
        [
            size_of::<ArrivalState>(),
            state.fixed_cursor_bytes,
            size_of::<ArrivalWorkspace>(),
            workspace.fixed_scratch_bytes,
        ],
        "fixed arrival cursor/scratch memory",
    )?;
    let arrival_intrinsic_pending_bytes = usize_to_u64(
        state.shared_pending_bytes,
        "arrival intrinsic pending bytes",
    )?;
    let arrival_intrinsic_pending_entries = usize_to_u64(
        state.shared_pending_entries,
        "arrival intrinsic pending entries",
    )?;
    let bookkeeping_and_staging_bytes = endpoint_bookkeeping_and_padding_bytes()?;
    let total_mutable_bytes = carrier_observer_bytes
        .checked_add(solver_scratch_bytes)
        .and_then(|sum| sum.checked_add(solver_logical_exact_integer_bytes))
        .and_then(|sum| sum.checked_add(arrival_fixed_bytes))
        .and_then(|sum| sum.checked_add(arrival_intrinsic_pending_bytes))
        .and_then(|sum| sum.checked_add(bookkeeping_and_staging_bytes))
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "total mutable-memory accounting overflowed",
            )
        })?;
    Ok(MutableMemoryAccounting {
        carrier_observer_bytes,
        solver_scratch_bytes,
        solver_logical_exact_integer_bytes,
        arrival_fixed_bytes,
        arrival_intrinsic_pending_bytes,
        arrival_intrinsic_pending_entries,
        bookkeeping_and_staging_bytes,
        total_mutable_bytes,
    })
}

/// Measure the complete prospective commit boundary: shared-round preparation
/// may hold durable and staged pending deques simultaneously, while the work,
/// peak, carrier, observer, and provider commit headers coexist on the stack.
fn prospective_memory(
    durable: &ReplicationDurable,
    carrier: &CarrierWorkspace,
    optimizer: &OccupancySolverScratch,
    workspace: ArrivalWorkspaceMemory,
    selected: &crate::occupancy_maxweight::SelectedAction,
) -> Result<MutableMemoryAccounting, RunError> {
    let mut prospective = endpoint_memory_from_parts(durable, carrier, optimizer, workspace)?;
    let live_action_header = usize_to_u64(
        size_of::<crate::occupancy_maxweight::SelectedAction>(),
        "live selected-action header",
    )?;
    prospective.solver_scratch_bytes = prospective
        .solver_scratch_bytes
        .checked_add(live_action_header)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective solver structural-memory peak overflowed",
            )
        })?;
    prospective.total_mutable_bytes = prospective
        .total_mutable_bytes
        .checked_add(live_action_header)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective selected-action total-memory peak overflowed",
            )
        })?;
    let live_exact = usize_to_u64(
        selected.logical_exact_integer_payload_bytes(),
        "live action logical exact-integer payload",
    )?;
    prospective.solver_logical_exact_integer_bytes = prospective
        .solver_logical_exact_integer_bytes
        .checked_add(live_exact)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective exact-integer payload peak overflowed",
            )
        })?;
    prospective.total_mutable_bytes = prospective
        .total_mutable_bytes
        .checked_add(live_exact)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective exact-integer total-memory peak overflowed",
            )
        })?;
    let staged_pending = usize_to_u64(workspace.staged_pending_bytes, "staged pending bytes")?;
    let staged_entries = usize_to_u64(workspace.staged_pending_entries, "staged pending entries")?;
    prospective.arrival_intrinsic_pending_bytes = prospective
        .arrival_intrinsic_pending_bytes
        .checked_add(staged_pending)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective pending-byte peak overflowed",
            )
        })?;
    prospective.arrival_intrinsic_pending_entries = prospective
        .arrival_intrinsic_pending_entries
        .checked_add(staged_entries)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective pending-entry peak overflowed",
            )
        })?;
    prospective.total_mutable_bytes = prospective
        .total_mutable_bytes
        .checked_add(staged_pending)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective mutable-memory peak overflowed",
            )
        })?;
    let staged_bookkeeping = staged_transaction_bookkeeping_bytes()?;
    prospective.bookkeeping_and_staging_bytes = prospective
        .bookkeeping_and_staging_bytes
        .checked_add(staged_bookkeeping)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective bookkeeping/staging memory overflowed",
            )
        })?;
    prospective.total_mutable_bytes = prospective
        .total_mutable_bytes
        .checked_add(staged_bookkeeping)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "prospective bookkeeping/staging total-memory peak overflowed",
            )
        })?;
    Ok(prospective)
}

fn record_attempt_peak(
    durable: &ReplicationDurable,
    carrier: &CarrierWorkspace,
    optimizer: &OccupancySolverScratch,
    workspace: ArrivalWorkspaceMemory,
    attempt: &mut ConstructionWorkCounters,
    selected: &crate::occupancy_maxweight::SelectedAction,
) -> Result<(), RunError> {
    let measured =
        prospective_memory(durable, carrier, optimizer, workspace, selected)?.total_mutable_bytes;
    attempt.peak_mutable_bytes = attempt.peak_mutable_bytes.max(measured);
    Ok(())
}

fn touched_union_count(
    selected: &[QueueIndex],
    arrivals: &[crate::unit_count::Arrival],
    stage: RuntimeStage,
) -> Result<u64, RunError> {
    let mut selected_position = 0;
    let mut arrival_position = 0;
    let mut count = 0_u64;
    while selected_position < selected.len() || arrival_position < arrivals.len() {
        let selected_queue = selected.get(selected_position).map(|queue| queue.0);
        let arrival_queue = arrivals
            .get(arrival_position)
            .map(|arrival| arrival.queue().0);
        match (selected_queue, arrival_queue) {
            (Some(left), Some(right)) if left == right => {
                selected_position += 1;
                arrival_position += 1;
            }
            (Some(left), Some(right)) if left < right => selected_position += 1,
            (Some(_) | None, Some(_)) => arrival_position += 1,
            (Some(_), None) => selected_position += 1,
            (None, None) => break,
        }
        count = count.checked_add(1).ok_or_else(|| {
            arithmetic_refusal(stage, "attempted touched-queue union exceeds u64")
        })?;
    }
    Ok(count)
}

fn attempted_touched_union_count(
    selected: &[QueueIndex],
    arrival_touched: &[QueueIndex],
    stage: RuntimeStage,
) -> Result<u64, RunError> {
    let selected_count = u64::try_from(selected.len())
        .map_err(|_| arithmetic_refusal(stage, "attempted selected width exceeds u64"))?;
    arrival_touched
        .iter()
        .filter(|queue| !selected.contains(queue))
        .try_fold(selected_count, |count, _queue| {
            count.checked_add(1).ok_or_else(|| {
                arithmetic_refusal(stage, "attempted touched-queue union exceeds u64")
            })
        })
}

fn endpoint_bookkeeping_and_padding_bytes() -> Result<u64, RunError> {
    let durable_padding = checked_struct_padding(
        size_of::<ReplicationDurable>(),
        [
            size_of::<UnitCountCarrier>(),
            size_of::<ArrivalState>(),
            size_of::<ResponseLedger>(),
            size_of::<ConstructionWorkCounters>(),
            size_of::<MutableMemoryAccounting>(),
        ],
        "durable replication wrapper padding",
    )?;
    let scratch_padding = checked_struct_padding(
        size_of::<ReplicationScratch>(),
        [
            size_of::<ArrivalWorkspace>(),
            size_of::<CarrierWorkspace>(),
            size_of::<OccupancySolverScratch>(),
            size_of::<ConstructionWorkCounters>(),
        ],
        "replication scratch wrapper padding",
    )?;
    checked_usize_sum(
        [
            size_of::<ConstructionWorkCounters>(),
            size_of::<MutableMemoryAccounting>(),
            size_of::<ConstructionWorkCounters>(),
            durable_padding,
            scratch_padding,
        ],
        "endpoint bookkeeping and wrapper-padding memory",
    )
}

fn staged_transaction_bookkeeping_bytes() -> Result<u64, RunError> {
    checked_usize_sum(
        [
            // `next_work` and the prospective `next_peak_memory`.
            size_of::<ConstructionWorkCounters>(),
            size_of::<MutableMemoryAccounting>(),
            // Heapless carrier/observer commits and the live provider batch
            // view. Their backing buffers remain charged to existing categories.
            size_of::<PreparedCountCommit>(),
            size_of::<PreparedResponseCommit>(),
            size_of::<PreparedArrivalStep<'static>>(),
        ],
        "staged transaction bookkeeping memory",
    )
}

fn checked_struct_padding<const N: usize>(
    structure: usize,
    fields: [usize; N],
    quantity: &'static str,
) -> Result<usize, RunError> {
    let field_bytes = fields
        .into_iter()
        .try_fold(0_usize, usize::checked_add)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "mutable-memory field-size sum overflowed usize",
            )
        })?;
    structure.checked_sub(field_bytes).ok_or_else(|| {
        result_violation(
            RuntimeStage::SlotCommitPreparation,
            format!("{quantity} is smaller than its field-size sum"),
        )
    })
}

fn checked_usize_sum<const N: usize>(
    values: [usize; N],
    quantity: &'static str,
) -> Result<u64, RunError> {
    let sum = values
        .into_iter()
        .try_fold(0_usize, usize::checked_add)
        .ok_or_else(|| {
            arithmetic_refusal(
                RuntimeStage::SlotCommitPreparation,
                "mutable-memory byte sum overflowed usize",
            )
        })?;
    usize_to_u64(sum, quantity)
}

fn usize_to_u64(value: usize, quantity: &'static str) -> Result<u64, RunError> {
    u64::try_from(value).map_err(|_| {
        arithmetic_refusal(
            RuntimeStage::SlotCommitPreparation,
            format!("{quantity} exceeds u64"),
        )
    })
}

pub(crate) fn map_arrival_runtime(stage: RuntimeStage, error: ArrivalError) -> RunError {
    let detail = error.to_string();
    match error {
        ArrivalError::ArithmeticOverflow { .. } | ArrivalError::ArrivalAggregateOverflow { .. } => {
            RunError::ArithmeticOverflow { stage, detail }
        }
        ArrivalError::ConfiguredGeneratorDrawGrantExceeded { .. } => {
            RunError::ScientificGrantExhausted { stage, detail }
        }
        ArrivalError::ResourceExhausted { .. }
        | ArrivalError::RandomDrawRefused
        | ArrivalError::GeometricBoundRefused => RunError::ResourceExhausted { stage, detail },
        ArrivalError::InvalidDefinition { .. }
        | ArrivalError::DuplicateCoordinate { .. }
        | ArrivalError::UnknownQueue
        | ArrivalError::UnknownReference { .. }
        | ArrivalError::RepresentationBound { .. }
        | ArrivalError::StateFamilyMismatch
        | ArrivalError::SlotMismatch { .. }
        | ArrivalError::CorruptState { .. } => RunError::ArrivalContractViolation { stage, detail },
    }
}

pub(crate) fn map_carrier_runtime(stage: RuntimeStage, error: CarrierError) -> RunError {
    let detail = error.to_string();
    match error {
        CarrierError::OccupancyOverflow { .. } | CarrierError::CounterOverflow { .. } => {
            RunError::ArithmeticOverflow { stage, detail }
        }
        CarrierError::ResourceExhausted { .. } => RunError::ResourceExhausted { stage, detail },
        CarrierError::NonBinaryService { .. }
        | CarrierError::ServiceShape { .. }
        | CarrierError::InfeasibleService
        | CarrierError::ServiceFromEmptyQueue { .. } => {
            RunError::OptimizerContractViolation { stage, detail }
        }
        CarrierError::EmptyQueueCatalog
        | CarrierError::QueueCatalogTooLarge
        | CarrierError::InvalidQueueId { .. }
        | CarrierError::DuplicateQueueId { .. }
        | CarrierError::ArrivalQueueOutOfRange { .. }
        | CarrierError::NonCanonicalArrivalBatch
        | CarrierError::PerQueueConservation { .. }
        | CarrierError::AggregateConservation
        | CarrierError::StateInvariant { .. } => {
            RunError::CarrierInvariantViolation { stage, detail }
        }
    }
}

pub(crate) fn arithmetic_refusal(stage: RuntimeStage, detail: impl Into<String>) -> RunError {
    RunError::ArithmeticOverflow {
        stage,
        detail: detail.into(),
    }
}

pub(crate) fn resource_refusal(stage: RuntimeStage, detail: impl Into<String>) -> RunError {
    RunError::ResourceExhausted {
        stage,
        detail: detail.into(),
    }
}

pub(crate) fn scientific_grant_refusal(
    stage: RuntimeStage,
    detail: impl Into<String>,
) -> RunError {
    RunError::ScientificGrantExhausted {
        stage,
        detail: detail.into(),
    }
}

pub(crate) fn result_violation(stage: RuntimeStage, detail: impl Into<String>) -> RunError {
    RunError::ResultInvariantViolation {
        stage,
        detail: detail.into(),
    }
}

#[cfg(test)]
mod c31_ordinary_observation_tests {
    use super::*;
    use crate::construction_observation::{
        ObservationCompletenessV1, ObservationMassBalanceV1, ObservationScalarV1,
    };
    use crate::direct_count_arrivals::ArrivalReplay;
    use crate::exact::ExactUnsigned;
    use crate::resolved::{
        CountArrivalEvent, CrossbarEdge, CrossbarTopology, DeterministicTrace,
        ResolvedArrival, ResolvedScheduler, SchedulerTopology,
    };

    fn qid() -> TypedId {
        TypedId::from("q0")
    }

    fn observed_run() -> PreparedCountRun {
        let catalog = QueueCatalog::try_new(vec![qid()]).expect("one-queue catalog");
        let scheduler = ResolvedScheduler {
            priority: vec![qid()],
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: vec![TypedId::from("input")],
                outputs: vec![TypedId::from("output")],
                edges: vec![CrossbarEdge {
                    queue_id: qid(),
                    input: TypedId::from("input"),
                    output: TypedId::from("output"),
                }],
            }),
        };
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)
            .expect("one-queue optimizer");
        let provider = PreparedArrival::try_compile(
            &ResolvedArrival::DeterministicTrace(DeterministicTrace {
                events: vec![
                    CountArrivalEvent {
                        slot: ExactUnsigned::from_u64(0),
                        queue_id: qid(),
                        count: 2,
                    },
                    CountArrivalEvent {
                        slot: ExactUnsigned::from_u64(2),
                        queue_id: qid(),
                        count: 1,
                    },
                ],
            }),
            &catalog,
        )
        .expect("deterministic provider");
        let limits = ConstructionWorkLimits::try_new(
            4,
            OptimizerSearchStateGrant::NotApplicable,
            64,
        )
        .expect("test limits");
        let problem = PreparedCountProblem::try_new(
            catalog,
            optimizer,
            provider,
            QueueIndex(0),
            RuntimeCount::new(1),
            RuntimeCount::new(4),
            limits,
        )
        .expect("test problem");
        PreparedCountRun::try_bind(
            problem,
            ArrivalReplay::from_seed_material([0x5a; 32], 0),
        )
        .expect("test replay")
    }

    fn observation_plan() -> ObservationPlanV1 {
        ObservationPlanV1::try_new(1, 4, vec![1, 2, 4], 16, 16, false)
            .expect("observation plan")
    }

    fn expected_arrival_digest() -> [u8; 32] {
        let mut hasher = ObservationSha256::new();
        hasher.update(b"MWPERF-ORDINARY-ARRIVAL-STREAM-V1\0");
        for origin in 0_u64..4 {
            hasher.update(&origin.to_be_bytes());
            let count = if origin == 0 || origin == 2 {
                1_u64
            } else {
                0_u64
            };
            hasher.update(&count.to_be_bytes());
            if count != 0 {
                hasher.update(&0_u32.to_be_bytes());
                hasher.update(&(if origin == 0 { 2_u64 } else { 1_u64 }).to_be_bytes());
            }
        }
        hasher.finalize()
    }

    #[derive(Clone, Copy)]
    struct FailCommitPreparationAt(u64);

    impl SlotFaultGate for FailCommitPreparationAt {
        fn check(&self, origin: RuntimeCount, point: FaultPoint) -> Result<(), RunError> {
            if origin.get() == self.0 && point == FaultPoint::CommitPreparation {
                return Err(RunError::ResourceExhausted {
                    stage: RuntimeStage::SlotCommitPreparation,
                    detail: "injected C31 observation rollback".to_owned(),
                });
            }
            Ok(())
        }
    }

    #[test]
    fn ordinary_observer_prepare_failure_leaves_every_durable_plane_unchanged() {
        let run = observed_run();
        let mut initialization_work = ConstructionWorkCounters::zero();
        let (mut durable, mut scratch) =
            prepare_execution_observed(&run, &mut initialization_work)
                .expect("execution preparation");
        let mut sink = PreparedOrdinaryObservationSink::try_new(
            &run,
            observation_plan(),
            None,
        )
        .expect("observation preparation");

        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .expect("first slot commits");
        let durable_before = durable.clone();
        let digest_before = sink.arrival_stream_digest();
        let levels_before = sink.levels.clone();
        let boundaries_before = sink.boundaries.clone();

        let error = execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &FailCommitPreparationAt(1),
            &mut sink,
        )
        .expect_err("the injected precommit failure fires");
        assert!(matches!(
            error,
            RunError::ResourceExhausted {
                stage: RuntimeStage::SlotCommitPreparation,
                ..
            }
        ));
        assert_eq!(durable, durable_before);
        assert_eq!(sink.committed_through_boundary(), 1);
        assert_eq!(sink.arrival_stream_digest(), digest_before);
        assert_eq!(sink.levels, levels_before);
        assert_eq!(sink.boundaries, boundaries_before);

        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &ProductionFaultGate,
            &mut sink,
        )
        .expect("the exact same slot can be retried");
        assert_eq!(durable.carrier.boundary(), RuntimeCount::new(2));
        assert_eq!(sink.committed_through_boundary(), 2);
    }

    #[test]
    fn ordinary_observation_reports_exact_rows_boundaries_digest_and_partial_prefix() {
        let run = observed_run();
        let report = run.execute_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("replication-000"),
            observation_plan(),
            None,
        );
        assert!(matches!(report.report(), ReplicationReport::Completed(_)));
        assert_eq!(
            report.arrival_stream_digest(),
            Some(expected_arrival_digest())
        );
        let observation = report.observation().expect("complete observation");
        assert_eq!(observation.completeness, ObservationCompletenessV1::Complete);
        assert_eq!(observation.committed_through_boundary, 4);
        assert_eq!(
            observation.replay_identity,
            ordinary_observation_replay_identity_v1(
                &TypedId::from("replication-000"),
                0,
                expected_arrival_digest(),
            )
        );
        assert_eq!(observation.blocks.len(), 2);
        assert_eq!(observation.blocks[0].begin_boundary, 1);
        assert_eq!(observation.blocks[0].committed_through_boundary, 2);
        assert_eq!(observation.blocks[0].levels.len(), 1);
        assert_eq!(observation.blocks[0].levels[0].backlog_level, ExactUnsigned::from_u64(2));
        assert_eq!(
            observation.blocks[0].levels[0].exposure_mass,
            ObservationScalarV1::exact_u128(1)
        );
        assert_eq!(
            observation.blocks[0].levels[0].served_mass,
            ObservationScalarV1::exact_u128(1)
        );
        assert_eq!(
            observation.blocks[0].exposure_mass_balance,
            ObservationMassBalanceV1::exact(1, 1)
        );
        assert_eq!(
            observation.blocks[0].initial_boundary_law.rows[0].backlog_level,
            ExactUnsigned::from_u64(2)
        );
        assert_eq!(
            observation.blocks[0].committed_boundary_law.rows[0].backlog_level,
            ExactUnsigned::from_u64(1)
        );
        assert_eq!(observation.blocks[1].begin_boundary, 2);
        assert_eq!(observation.blocks[1].committed_through_boundary, 4);
        assert_eq!(observation.blocks[1].levels.len(), 1);
        assert_eq!(observation.blocks[1].levels[0].backlog_level, ExactUnsigned::from_u64(1));
        assert_eq!(
            observation.blocks[1].levels[0].exposure_mass,
            ObservationScalarV1::exact_u128(2)
        );
        assert_eq!(
            observation.blocks[1].levels[0].served_mass,
            ObservationScalarV1::exact_u128(2)
        );
        assert_eq!(
            observation.blocks[1].committed_boundary_law.rows[0].backlog_level,
            ExactUnsigned::from_u64(0)
        );

        let mut initialization_work = ConstructionWorkCounters::zero();
        let (mut durable, mut scratch) =
            prepare_execution_observed(&run, &mut initialization_work)
                .expect("partial execution preparation");
        let mut sink = PreparedOrdinaryObservationSink::try_new(
            &run,
            observation_plan(),
            None,
        )
        .expect("partial observation preparation");
        assert!(sink.ordered_levels.capacity() >= sink.maximum_level_rows);
        assert_eq!(sink.finalized_blocks.len(), 2);
        let prepared_first_block_rows = sink.finalized_blocks[0].levels.as_ptr();
        for _ in 0..2 {
            execute_one_slot(
                &run,
                &mut durable,
                &mut scratch,
                &ProductionFaultGate,
                &mut sink,
            )
            .expect("prefix slot commits");
        }
        execute_one_slot(
            &run,
            &mut durable,
            &mut scratch,
            &FailCommitPreparationAt(2),
            &mut sink,
        )
        .expect_err("prefix stops before a third commit");
        let partial = sink
            .finalize(
                ReplicationCoordinate::new(0),
                TypedId::from("replication-partial"),
            )
            .expect("partial finalization")
            .expect("W was reached");
        assert_eq!(partial.completeness, ObservationCompletenessV1::Partial);
        assert_eq!(partial.committed_through_boundary, 2);
        assert_eq!(partial.blocks.len(), 1);
        assert_eq!(partial.blocks[0].levels.as_ptr(), prepared_first_block_rows);
        assert_eq!(partial.blocks[0].completeness, ObservationCompletenessV1::Complete);
        assert_eq!(partial.blocks[0].committed_through_boundary, 2);

        let mut initialization_work = ConstructionWorkCounters::zero();
        let (_durable, _scratch) =
            prepare_execution_observed(&run, &mut initialization_work)
                .expect("pre-W execution preparation");
        let sink = PreparedOrdinaryObservationSink::try_new(
            &run,
            observation_plan(),
            None,
        )
        .expect("pre-W observation preparation");
        let empty = sink
            .finalize(
                ReplicationCoordinate::new(0),
                TypedId::from("replication-empty-prefix"),
            )
            .expect("empty-prefix finalization")
            .expect("empty measured prefix is explicit");
        assert_eq!(empty.completeness, ObservationCompletenessV1::Partial);
        assert_eq!(empty.committed_through_boundary, 1);
        assert!(empty.blocks.is_empty());
    }

    #[test]
    fn ordinary_prepared_sink_executes_without_worker_time_sink_reservation() {
        let run = observed_run();
        let sink = run
            .try_prepare_observation_sink(observation_plan(), None)
            .expect("sink storage is prepared before worker launch");
        let report = run.execute_prepared_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("prepared-replication-000"),
            sink,
        );
        assert!(matches!(report.report(), ReplicationReport::Completed(_)));
        assert_eq!(
            report.arrival_stream_digest(),
            Some(expected_arrival_digest())
        );
        assert_eq!(
            report
                .observation()
                .expect("prepared execution retains its observation")
                .completeness,
            ObservationCompletenessV1::Complete
        );
    }

    #[test]
    fn ordinary_prepared_sink_retains_an_empty_record_on_coordinate_refusal() {
        let run = observed_run();
        let sink = run
            .try_prepare_observation_sink(observation_plan(), None)
            .expect("coordinate-refusal sink is prepared");
        let report = run.execute_prepared_observed_evidenced(
            ReplicationCoordinate::new(1),
            TypedId::from("wrong-coordinate"),
            sink,
        );
        assert!(matches!(report.report(), ReplicationReport::Failed(_)));
        assert!(report.observation_error().is_none());
        let observation = report
            .observation()
            .expect("a prepared empty prefix survives coordinate refusal");
        assert_eq!(observation.completeness, ObservationCompletenessV1::Partial);
        assert_eq!(observation.committed_through_boundary, 1);
        assert!(observation.blocks.is_empty());
        assert!(report.arrival_stream_digest().is_some());
    }

    #[test]
    fn ordinary_foreign_prepared_sink_refusal_retains_an_empty_record() {
        let source = observed_run();
        let sink = source
            .try_prepare_observation_sink(observation_plan(), None)
            .expect("foreign-refusal sink is prepared");
        let foreign_limits = ConstructionWorkLimits::try_new(
            5,
            OptimizerSearchStateGrant::NotApplicable,
            64,
        )
        .expect("foreign problem limits");
        let foreign_problem = PreparedCountProblem::try_new(
            source.catalog().clone(),
            source.problem().optimizer().clone(),
            source.problem().provider().clone(),
            source.target(),
            source.warmup(),
            source.horizon(),
            foreign_limits,
        )
        .expect("foreign problem");
        let foreign = PreparedCountRun::try_bind(foreign_problem, source.replay())
            .expect("foreign run");
        let report = foreign.execute_prepared_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("foreign-sink-refusal"),
            sink,
        );
        let ReplicationReport::Failed(failure) = report.report() else {
            panic!("a foreign sink must fail closed")
        };
        assert_eq!(failure.work(), ConstructionWorkCounters::zero());
        assert!(report.observation_error().is_none());
        let observation = report
            .observation()
            .expect("foreign-sink refusal retains the prepared empty prefix");
        assert_eq!(observation.completeness, ObservationCompletenessV1::Partial);
        assert_eq!(observation.committed_through_boundary, 1);
        assert!(observation.blocks.is_empty());
        assert!(report.arrival_stream_digest().is_some());
    }

    #[test]
    fn ordinary_arrival_stream_digest_depends_only_on_committed_sparse_batches() {
        let first = observed_run();
        let second = PreparedCountRun::try_bind(
            Arc::clone(first.problem()),
            ArrivalReplay::from_seed_material([0xc3; 32], 7),
        )
        .expect("alternate deterministic replay address");
        let first = first.execute_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("stream-a"),
            observation_plan(),
            None,
        );
        let second = second.execute_observed_evidenced(
            ReplicationCoordinate::new(7),
            TypedId::from("stream-b"),
            observation_plan(),
            None,
        );
        assert_eq!(
            first.arrival_stream_digest(),
            Some(expected_arrival_digest())
        );
        assert_eq!(
            second.arrival_stream_digest(),
            Some(expected_arrival_digest())
        );
        let first = first.observation().expect("first stream observation");
        let second = second.observation().expect("second stream observation");
        assert_ne!(first.replay_identity, second.replay_identity);
    }

    #[test]
    fn ordinary_sparse_cap_failure_retains_the_exact_prepared_partial_record() {
        let run = observed_run();
        let tight_plan = ObservationPlanV1::try_new(1, 4, vec![1, 2, 4], 1, 16, false)
            .expect("tight ordinary plan");
        let report = run.execute_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("replication-cap-partial"),
            tight_plan,
            None,
        );
        assert!(matches!(report.report(), ReplicationReport::Failed(_)));
        assert!(report.observation_error().is_none());
        assert!(report.arrival_stream_digest().is_some());
        let retained = report
            .observation()
            .expect("the cap refusal retains its committed prefix");
        assert_eq!(retained.completeness, ObservationCompletenessV1::Partial);
        assert_eq!(retained.committed_through_boundary, 2);
        assert_eq!(retained.blocks.len(), 1);
        assert_eq!(retained.blocks[0].begin_boundary, 1);
        assert_eq!(retained.blocks[0].committed_through_boundary, 2);
        assert_eq!(retained.blocks[0].levels.len(), 1);
        assert_eq!(
            retained.blocks[0].exposure_mass_balance,
            ObservationMassBalanceV1::exact(1, 1)
        );
    }

    #[test]
    fn ordinary_aggregation_refuses_a_missing_retained_record() {
        let base = observed_run();
        let run = PreparedCountRun::try_bind(
            Arc::clone(base.problem()),
            ArrivalReplay::from_seed_material([0x5a; 32], 1),
        )
        .expect("mismatched-coordinate replay");
        let report = run.execute_observed_evidenced(
            ReplicationCoordinate::new(0),
            TypedId::from("replication-000"),
            observation_plan(),
            None,
        );
        assert!(report.observation().is_some());
        // Model transport loss explicitly: prepared execution now correctly
        // retains an empty partial record even for this coordinate refusal.
        let report = ObservedReplicationReport::new(
            report.report().clone(),
            None,
            report.arrival_stream_digest(),
            None,
        );
        let partition = crate::estimator::ScientificGrantPartition::try_new(1, run.limits())
            .expect("one-replication grant");
        let error = crate::estimator::aggregate_observed_replications(
            partition,
            run.horizon(),
            RuntimeCount::new(3),
            vec![report],
        )
        .expect_err("aggregation cannot silently shorten an authenticated bundle");
        assert!(matches!(
            error,
            crate::estimator::EstimatorInvocationError::MissingObservation { coordinate: 0 }
        ));
    }

    #[test]
    fn ordinary_gap_probe_is_bound_to_the_complete_prepared_scheduler() {
        let run = observed_run();
        let foreign_scheduler = ResolvedScheduler {
            priority: vec![qid()],
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: vec![TypedId::from("foreign-input")],
                outputs: vec![TypedId::from("foreign-output")],
                edges: vec![CrossbarEdge {
                    queue_id: qid(),
                    input: TypedId::from("foreign-input"),
                    output: TypedId::from("foreign-output"),
                }],
            }),
        };
        let foreign_probe = PreparedGapProbe::try_prepare(
            &foreign_scheduler,
            run.catalog(),
            run.target(),
        )
        .expect("foreign probe preparation")
        .into_prepared()
        .expect("one-queue foreign crossbar supports a probe");
        let plan = ObservationPlanV1::try_new(1, 4, vec![1, 2, 4], 16, 16, true)
            .expect("gap-enabled plan");
        let error = match PreparedOrdinaryObservationSink::try_new(
            &run,
            plan,
            Some(Arc::new(foreign_probe)),
        ) {
            Ok(_sink) => panic!("a same-width probe from another scheduler must be refused"),
            Err(error) => error,
        };
        assert!(matches!(
            error,
            RunError::ResultInvariantViolation {
                stage: RuntimeStage::EmptyInitialization,
                ..
            }
        ));
    }
}

#[cfg(test)]
#[path = "engine/fofs_cp02_tests.rs"]
mod fofs_cp02_tests;
