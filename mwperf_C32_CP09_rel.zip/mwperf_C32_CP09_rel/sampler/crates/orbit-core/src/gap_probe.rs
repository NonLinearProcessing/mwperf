//! Certified exact opportunity-gap probes.
//!
//! Reviewed topology classes retain their zero-additional-solve closed forms.
//! CP09 may additionally prepare a generic exact probe: the physical action
//! supplies one forced target face and one cache-keyed call to the same exact
//! scheduler evaluates the opposite face. Neither path consumes randomness or
//! changes the physical action.

use blake3::Hasher;
use num_traits::One;
use thiserror::Error;

use crate::exact::{ExactRational, RuntimeCount};
use crate::resolved::{
    ConflictGraphTopology, IntervalTopology, NodeExclusiveLink, NodeExclusiveTopology,
    QueueInterval, ResolvedScheduler, SchedulerTopology, TypedId,
};
use crate::unit_count::{QueueCatalog, QueueIndex};

const FINGERPRINT_DOMAIN: &[u8] = b"FORBIT-C31-GAP-PROBE-V1\0";

/// Closed observation-capability reasons shared with the framework contract.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum GapProbeUnavailableReasonV1 {
    DisabledByRequest,
    UnsupportedGapTopology,
    NonunitTargetMultiplier,
}

impl GapProbeUnavailableReasonV1 {
    pub const fn code(self) -> &'static str {
        match self {
            Self::DisabledByRequest => "disabled_by_request",
            Self::UnsupportedGapTopology => "unsupported_gap_topology",
            Self::NonunitTargetMultiplier => "nonunit_target_multiplier",
        }
    }
}

/// Preparation either proves one closed form or returns a scientific
/// capability refusal.  Malformed scheduler/catalog bindings are errors, not
/// unsupported scientific cases.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GapProbePreparation {
    Available(PreparedGapProbe),
    Unavailable(GapProbeUnavailableReasonV1),
}

impl GapProbePreparation {
    pub const fn disabled_by_request() -> Self {
        Self::Unavailable(GapProbeUnavailableReasonV1::DisabledByRequest)
    }

    pub const fn prepared(&self) -> Option<&PreparedGapProbe> {
        match self {
            Self::Available(probe) => Some(probe),
            Self::Unavailable(_) => None,
        }
    }

    pub const fn unavailable_reason(&self) -> Option<GapProbeUnavailableReasonV1> {
        match self {
            Self::Available(_) => None,
            Self::Unavailable(reason) => Some(*reason),
        }
    }

    pub fn into_prepared(self) -> Option<PreparedGapProbe> {
        match self {
            Self::Available(probe) => Some(probe),
            Self::Unavailable(_) => None,
        }
    }
}

/// Sign of `G = N - Theta`.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum GapSign {
    Negative,
    Tie,
    Positive,
}

/// One allocation-free exact gap evaluation.
///
/// Signed magnitude is used instead of `i128`: the admitted queue count and
/// runtime count bounds make `u128` summation cheap, and no signed endpoint
/// conversion is needed by weighted or exact-count accumulators.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GapObservation {
    competition_scale: u128,
    sign: GapSign,
    magnitude: u128,
}

impl GapObservation {
    pub const fn competition_scale(self) -> u128 {
        self.competition_scale
    }

    pub const fn sign(self) -> GapSign {
        self.sign
    }

    pub const fn magnitude(self) -> u128 {
        self.magnitude
    }

    pub const fn positive_magnitude(self) -> u128 {
        match self.sign {
            GapSign::Positive => self.magnitude,
            GapSign::Negative | GapSign::Tie => 0,
        }
    }

    pub const fn negative_magnitude(self) -> u128 {
        match self.sign {
            GapSign::Negative => self.magnitude,
            GapSign::Tie | GapSign::Positive => 0,
        }
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum GapProbeError {
    #[error("the gap-probe target is outside the dense queue catalog")]
    TargetOutsideCatalog,
    #[error("the gap-probe priority is not a complete queue-catalog permutation")]
    InvalidPriority,
    #[error("the gap-probe topology does not cover the queue catalog exactly")]
    InvalidTopologyCoverage,
    #[error("the gap-probe target is absent from the scheduler topology")]
    TargetAbsentFromTopology,
    #[error("the gap-probe preparation allocation was refused")]
    CapacityExceeded,
    #[error("the gap-probe occupancy width differs from its prepared queue catalog")]
    OccupancyWidthMismatch,
    #[error("the exact competition-scale sum overflowed u128")]
    CompetitionScaleOverflow,
    #[error("the generic exact gap probe requires an opposite-face optimizer solve")]
    OppositeFaceSolveRequired,
    #[error("the exact scheduler served an empty target queue")]
    EmptyTargetServed,
    #[error("the exact scheduler left a strictly positive target gap unserved")]
    PositiveGapUnserved,
    #[error("the exact scheduler served a strictly negative target gap")]
    NegativeGapServed,
}

impl GapProbeError {
    /// Stable provider-facing classification. Human diagnostics remain the
    /// `Display` text supplied by `thiserror`.
    pub const fn code(&self) -> &'static str {
        match self {
            Self::TargetOutsideCatalog => "target_outside_catalog",
            Self::InvalidPriority => "invalid_priority",
            Self::InvalidTopologyCoverage => "invalid_topology_coverage",
            Self::TargetAbsentFromTopology => "target_absent_from_topology",
            Self::CapacityExceeded => "capacity_exceeded",
            Self::OccupancyWidthMismatch => "occupancy_width_mismatch",
            Self::CompetitionScaleOverflow => "competition_scale_overflow",
            Self::OppositeFaceSolveRequired => "opposite_face_solve_required",
            Self::EmptyTargetServed => "empty_target_served",
            Self::PositiveGapUnserved => "positive_gap_unserved",
            Self::NegativeGapServed => "negative_gap_served",
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum PreparedGapFormula {
    Clique { competitors: Box<[usize]> },
    StarHub { leaves: Box<[usize]> },
    StarLeaf { hub: usize, other_leaves: Box<[usize]> },
    /// Exact fallback for a topology without one of the reviewed closed
    /// forms.  The physical solve supplies one forced face; the weighted
    /// runner evaluates only the opposite face with the same exact backend.
    ExactOppositeFace,
}

/// Immutable closed-form probe bound to one dense geometry, target and
/// authored priority.  The fingerprint is an internal binding witness, not a
/// replacement for the framework's SHA-256 scientific identities.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PreparedGapProbe {
    queue_count: usize,
    target_queue: QueueIndex,
    target: usize,
    formula: PreparedGapFormula,
    scheduler_fingerprint: [u8; 32],
}

impl PreparedGapProbe {
    /// Prepare the current unit-occupancy MaxWeight lane.
    pub fn try_prepare(
        scheduler: &ResolvedScheduler,
        catalog: &QueueCatalog,
        target: QueueIndex,
    ) -> Result<GapProbePreparation, GapProbeError> {
        Self::try_prepare_with_target_multiplier(
            scheduler,
            catalog,
            target,
            &ExactRational::from_integer(num_bigint::BigInt::from(1_u8)),
        )
    }

    /// Prepare while explicitly proving the selected target's multiplier.
    pub fn try_prepare_with_target_multiplier(
        scheduler: &ResolvedScheduler,
        catalog: &QueueCatalog,
        target: QueueIndex,
        target_multiplier: &ExactRational,
    ) -> Result<GapProbePreparation, GapProbeError> {
        Self::try_prepare_impl(
            scheduler,
            catalog,
            target,
            target_multiplier,
            false,
        )
    }

    /// Prepare exact CP09 gap telemetry, retaining the zero-additional-solve
    /// formulas where proved and selecting one exact opposite-face solve for
    /// every other supported exact scheduler geometry.
    pub fn try_prepare_with_exact_fallback(
        scheduler: &ResolvedScheduler,
        catalog: &QueueCatalog,
        target: QueueIndex,
        target_multiplier: &ExactRational,
    ) -> Result<GapProbePreparation, GapProbeError> {
        Self::try_prepare_impl(
            scheduler,
            catalog,
            target,
            target_multiplier,
            true,
        )
    }

    fn try_prepare_impl(
        scheduler: &ResolvedScheduler,
        catalog: &QueueCatalog,
        target: QueueIndex,
        target_multiplier: &ExactRational,
        allow_exact_fallback: bool,
    ) -> Result<GapProbePreparation, GapProbeError> {
        if target_multiplier.as_ratio() != &num_rational::BigRational::one() {
            return Ok(GapProbePreparation::Unavailable(
                GapProbeUnavailableReasonV1::NonunitTargetMultiplier,
            ));
        }
        let target_queue = target;
        let target = dense_position(target_queue, catalog.len())
            .ok_or(GapProbeError::TargetOutsideCatalog)?;
        let priority = dense_priority(scheduler, catalog)?;
        let formula = match &scheduler.topology {
            SchedulerTopology::Crossbar(topology) => {
                prepare_crossbar(topology, catalog, target)?
            }
            SchedulerTopology::NodeExclusive(topology) => {
                prepare_node_exclusive(topology, catalog, target)?
            }
            SchedulerTopology::Interval(topology) => {
                prepare_interval(topology, catalog, target)?
            }
            SchedulerTopology::ConflictGraph(topology) => {
                prepare_conflict(topology, catalog, target)?
            }
            SchedulerTopology::ResourcePacking(_) => None,
        };
        let formula = match formula {
            Some(formula) => formula,
            None if allow_exact_fallback => PreparedGapFormula::ExactOppositeFace,
            None => {
                return Ok(GapProbePreparation::Unavailable(
                    GapProbeUnavailableReasonV1::UnsupportedGapTopology,
                ));
            }
        };
        let scheduler_fingerprint = fingerprint(
            scheduler,
            catalog,
            &priority,
            target,
            &formula,
        )?;
        Ok(GapProbePreparation::Available(Self {
            queue_count: catalog.len(),
            target_queue,
            target,
            formula,
            scheduler_fingerprint,
        }))
    }

    pub const fn target(&self) -> QueueIndex {
        self.target_queue
    }

    pub const fn queue_count(&self) -> usize {
        self.queue_count
    }

    pub const fn scheduler_fingerprint(&self) -> [u8; 32] {
        self.scheduler_fingerprint
    }

    /// True exactly when a weighted schedule-cache miss must evaluate the
    /// opposite forced target face. Closed-form probes remain zero-solve.
    pub const fn requires_opposite_face_solve(&self) -> bool {
        matches!(&self.formula, PreparedGapFormula::ExactOppositeFace)
    }

    /// Whether preparation proved that every non-target queue competes with
    /// the target for one shared unit-capacity server.  The paired fan-in
    /// experiment uses the corresponding `max(other backlog)` formula for
    /// every target, so admitting a merely observed work-conserving action is
    /// not sufficient evidence for that formula.
    pub(crate) fn is_single_server_clique(&self) -> bool {
        matches!(&self.formula, PreparedGapFormula::Clique { .. })
    }

    /// Evaluate the proved formula and check it against the actual physical
    /// target decision. This method performs no allocation or optimizer work.
    pub fn observe(
        &self,
        occupancy: &[RuntimeCount],
        target_was_served: bool,
    ) -> Result<GapObservation, GapProbeError> {
        if occupancy.len() != self.queue_count {
            return Err(GapProbeError::OccupancyWidthMismatch);
        }
        let target_backlog = u128::from(occupancy[self.target].get());
        if target_backlog == 0 && target_was_served {
            return Err(GapProbeError::EmptyTargetServed);
        }
        let competition_scale = match &self.formula {
            PreparedGapFormula::Clique { competitors } => competitors
                .iter()
                .map(|&queue| u128::from(occupancy[queue].get()))
                .max()
                .unwrap_or(0),
            PreparedGapFormula::StarHub { leaves } => {
                checked_sum(occupancy, leaves)?
            }
            PreparedGapFormula::StarLeaf { hub, other_leaves } => {
                let alternatives = checked_sum(occupancy, other_leaves)?;
                u128::from(occupancy[*hub].get()).saturating_sub(alternatives)
            }
            PreparedGapFormula::ExactOppositeFace => {
                return Err(GapProbeError::OppositeFaceSolveRequired);
            }
        };
        let (sign, magnitude) = match target_backlog.cmp(&competition_scale) {
            std::cmp::Ordering::Less => (
                GapSign::Negative,
                competition_scale - target_backlog,
            ),
            std::cmp::Ordering::Equal => (GapSign::Tie, 0),
            std::cmp::Ordering::Greater => (
                GapSign::Positive,
                target_backlog - competition_scale,
            ),
        };
        if target_backlog > 0 {
            match (sign, target_was_served) {
                (GapSign::Positive, false) => {
                    return Err(GapProbeError::PositiveGapUnserved)
                }
                (GapSign::Negative, true) => {
                    return Err(GapProbeError::NegativeGapServed)
                }
                _ => {}
            }
        }
        Ok(GapObservation {
            competition_scale,
            sign,
            magnitude,
        })
    }
}

fn checked_sum(
    occupancy: &[RuntimeCount],
    queues: &[usize],
) -> Result<u128, GapProbeError> {
    queues.iter().try_fold(0_u128, |total, &queue| {
        checked_add_scale(total, u128::from(occupancy[queue].get()))
    })
}

fn checked_add_scale(total: u128, addend: u128) -> Result<u128, GapProbeError> {
    total
        .checked_add(addend)
        .ok_or(GapProbeError::CompetitionScaleOverflow)
}

fn dense_position(queue: QueueIndex, queue_count: usize) -> Option<usize> {
    usize::try_from(queue.0)
        .ok()
        .filter(|position| *position < queue_count)
}

fn dense_priority(
    scheduler: &ResolvedScheduler,
    catalog: &QueueCatalog,
) -> Result<Vec<usize>, GapProbeError> {
    if scheduler.priority.len() != catalog.len() {
        return Err(GapProbeError::InvalidPriority);
    }
    let mut result = try_vec(catalog.len())?;
    let mut seen = try_bool_vec(catalog.len())?;
    for id in &scheduler.priority {
        let dense = catalog
            .index_of(id)
            .and_then(|queue| dense_position(queue, catalog.len()))
            .ok_or(GapProbeError::InvalidPriority)?;
        if seen[dense] {
            return Err(GapProbeError::InvalidPriority);
        }
        seen[dense] = true;
        result.push(dense);
    }
    Ok(result)
}

fn dense_queue(
    catalog: &QueueCatalog,
    id: &TypedId,
) -> Result<usize, GapProbeError> {
    catalog
        .index_of(id)
        .and_then(|queue| dense_position(queue, catalog.len()))
        .ok_or(GapProbeError::InvalidTopologyCoverage)
}

fn validate_row_coverage(
    rows: impl IntoIterator<Item = usize>,
    queue_count: usize,
) -> Result<(), GapProbeError> {
    let mut seen = try_bool_vec(queue_count)?;
    let mut count = 0_usize;
    for queue in rows {
        if queue >= queue_count || seen[queue] {
            return Err(GapProbeError::InvalidTopologyCoverage);
        }
        seen[queue] = true;
        count = count
            .checked_add(1)
            .ok_or(GapProbeError::InvalidTopologyCoverage)?;
    }
    if count != queue_count || seen.iter().any(|present| !*present) {
        return Err(GapProbeError::InvalidTopologyCoverage);
    }
    Ok(())
}

fn all_competitors(queue_count: usize, target: usize) -> Result<Box<[usize]>, GapProbeError> {
    let mut competitors = try_vec(queue_count.saturating_sub(1))?;
    competitors.extend((0..queue_count).filter(|queue| *queue != target));
    Ok(competitors.into_boxed_slice())
}

fn prepare_crossbar(
    topology: &crate::resolved::CrossbarTopology,
    catalog: &QueueCatalog,
    target: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    let mut dense = try_vec(topology.edges.len())?;
    for edge in &topology.edges {
        dense.push(dense_queue(catalog, &edge.queue_id)?);
    }
    validate_row_coverage(dense.iter().copied(), catalog.len())?;
    if !dense.contains(&target) {
        return Err(GapProbeError::TargetAbsentFromTopology);
    }
    let supported = topology.edges.len() <= 1
        || topology
            .edges
            .iter()
            .all(|edge| edge.input == topology.edges[0].input)
        || topology
            .edges
            .iter()
            .all(|edge| edge.output == topology.edges[0].output);
    if !supported {
        return Ok(None);
    }
    Ok(Some(PreparedGapFormula::Clique {
        competitors: all_competitors(catalog.len(), target)?,
    }))
}

fn share_vertex(left: &NodeExclusiveLink, right: &NodeExclusiveLink) -> bool {
    left.u == right.u || left.u == right.v || left.v == right.u || left.v == right.v
}

fn prepare_node_exclusive(
    topology: &NodeExclusiveTopology,
    catalog: &QueueCatalog,
    target: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    let mut dense = try_vec(topology.links.len())?;
    for link in &topology.links {
        dense.push(dense_queue(catalog, &link.queue_id)?);
    }
    validate_row_coverage(dense.iter().copied(), catalog.len())?;
    if !dense.contains(&target) {
        return Err(GapProbeError::TargetAbsentFromTopology);
    }
    let supported = topology.links.len() <= 1
        || topology.links.first().is_some_and(|first| {
            topology
                .links
                .iter()
                .all(|link| link.u == first.u || link.v == first.u)
                || topology
                    .links
                    .iter()
                    .all(|link| link.u == first.v || link.v == first.v)
        })
        || (topology.links.len() == 3
            && share_vertex(&topology.links[0], &topology.links[1])
            && share_vertex(&topology.links[0], &topology.links[2])
            && share_vertex(&topology.links[1], &topology.links[2]));
    if !supported {
        return Ok(None);
    }
    Ok(Some(PreparedGapFormula::Clique {
        competitors: all_competitors(catalog.len(), target)?,
    }))
}

fn intervals_compatible(left: &QueueInterval, right: &QueueInterval) -> bool {
    left.right <= right.left || right.right <= left.left
}

fn interval_star(
    rows: &[(usize, &QueueInterval)],
    target: usize,
    hub_row: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    let target_interval = rows
        .iter()
        .find(|row| row.0 == target)
        .ok_or(GapProbeError::TargetAbsentFromTopology)?
        .1;
    if rows[hub_row].0 != target
        && intervals_compatible(rows[hub_row].1, target_interval)
    {
        return Ok(None);
    }
    let mut leaf_rows = try_vec(rows.len().saturating_sub(1))?;
    for row in 0..rows.len() {
        if row != hub_row && !intervals_compatible(rows[row].1, rows[hub_row].1) {
            leaf_rows.push(row);
        }
    }
    if rows[hub_row].0 != target && !leaf_rows.iter().any(|&row| rows[row].0 == target) {
        return Ok(None);
    }
    for left in 0..leaf_rows.len() {
        for right in (left + 1)..leaf_rows.len() {
            if !intervals_compatible(rows[leaf_rows[left]].1, rows[leaf_rows[right]].1) {
                return Ok(None);
            }
        }
    }
    let mut is_leaf = try_bool_vec(rows.len())?;
    for &row in &leaf_rows {
        is_leaf[row] = true;
    }
    for &leaf in &leaf_rows {
        for other in 0..rows.len() {
            if other == hub_row || is_leaf[other] {
                continue;
            }
            if !intervals_compatible(rows[leaf].1, rows[other].1) {
                return Ok(None);
            }
        }
    }
    if rows[hub_row].0 == target {
        let mut leaves = try_vec(leaf_rows.len())?;
        for row in leaf_rows {
            leaves.push(rows[row].0);
        }
        return Ok(Some(PreparedGapFormula::StarHub {
            leaves: leaves.into_boxed_slice(),
        }));
    }
    let mut other_leaves = try_vec(leaf_rows.len().saturating_sub(1))?;
    for row in leaf_rows {
        if rows[row].0 != target {
            other_leaves.push(rows[row].0);
        }
    }
    Ok(Some(PreparedGapFormula::StarLeaf {
        hub: rows[hub_row].0,
        other_leaves: other_leaves.into_boxed_slice(),
    }))
}

fn prepare_interval(
    topology: &IntervalTopology,
    catalog: &QueueCatalog,
    target: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    let mut rows = try_vec(topology.intervals.len())?;
    for interval in &topology.intervals {
        rows.push((dense_queue(catalog, &interval.queue_id)?, interval));
    }
    validate_row_coverage(rows.iter().map(|row| row.0), catalog.len())?;
    let target_row = rows
        .iter()
        .position(|row| row.0 == target)
        .ok_or(GapProbeError::TargetAbsentFromTopology)?;
    if let Some(formula) = interval_star(&rows, target, target_row)? {
        return Ok(Some(formula));
    }
    let mut neighbors = try_vec(rows.len().saturating_sub(1))?;
    for (row, value) in rows.iter().enumerate() {
        if row != target_row && !intervals_compatible(rows[target_row].1, value.1) {
            neighbors.push(row);
        }
    }
    if neighbors.len() != 1 {
        return Ok(None);
    }
    interval_star(&rows, target, neighbors[0])
}

fn conflict_star(
    topology: &ConflictGraphTopology,
    catalog: &QueueCatalog,
    target: usize,
    hub: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    let mut leaves = try_vec(catalog.len().saturating_sub(1))?;
    for conflict in &topology.conflicts {
        let first = dense_queue(catalog, &conflict.first)?;
        let second = dense_queue(catalog, &conflict.second)?;
        let neighbor = if first == hub {
            Some(second)
        } else if second == hub {
            Some(first)
        } else {
            None
        };
        if let Some(neighbor) = neighbor {
            if !leaves.contains(&neighbor) {
                leaves.push(neighbor);
            }
        }
    }
    leaves.sort_unstable();
    if target != hub && !leaves.contains(&target) {
        return Ok(None);
    }
    for conflict in &topology.conflicts {
        let first = dense_queue(catalog, &conflict.first)?;
        let second = dense_queue(catalog, &conflict.second)?;
        if (leaves.contains(&first) && second != hub)
            || (leaves.contains(&second) && first != hub)
        {
            return Ok(None);
        }
    }
    if target == hub {
        return Ok(Some(PreparedGapFormula::StarHub {
            leaves: leaves.into_boxed_slice(),
        }));
    }
    let mut other_leaves = try_vec(leaves.len().saturating_sub(1))?;
    other_leaves.extend(leaves.into_iter().filter(|queue| *queue != target));
    Ok(Some(PreparedGapFormula::StarLeaf {
        hub,
        other_leaves: other_leaves.into_boxed_slice(),
    }))
}

fn prepare_conflict(
    topology: &ConflictGraphTopology,
    catalog: &QueueCatalog,
    target: usize,
) -> Result<Option<PreparedGapFormula>, GapProbeError> {
    // Keep this recognition set identical to the framework's frozen C30
    // admission predicate: conflict graphs contribute star components only.
    // Single-server cliques are represented by the supported common-port
    // crossbar and common-vertex/triangle node-exclusive families.
    // Resolve every endpoint even when the target is isolated, so an invalid
    // topology cannot masquerade as a supported zero-leaf star.
    for conflict in &topology.conflicts {
        let _ = dense_queue(catalog, &conflict.first)?;
        let _ = dense_queue(catalog, &conflict.second)?;
    }
    if let Some(formula) = conflict_star(topology, catalog, target, target)? {
        return Ok(Some(formula));
    }
    let mut sole_neighbor = None;
    for conflict in &topology.conflicts {
        let first = dense_queue(catalog, &conflict.first)?;
        let second = dense_queue(catalog, &conflict.second)?;
        let neighbor = if first == target {
            Some(second)
        } else if second == target {
            Some(first)
        } else {
            None
        };
        if let Some(neighbor) = neighbor {
            if sole_neighbor.is_some_and(|prior| prior != neighbor) {
                return Ok(None);
            }
            sole_neighbor = Some(neighbor);
        }
    }
    let Some(hub) = sole_neighbor else {
        // The target-isolated case was accepted by the first branch.
        return Ok(None);
    };
    conflict_star(topology, catalog, target, hub)
}

fn fingerprint(
    scheduler: &ResolvedScheduler,
    catalog: &QueueCatalog,
    priority: &[usize],
    target: usize,
    formula: &PreparedGapFormula,
) -> Result<[u8; 32], GapProbeError> {
    let mut hasher = Hasher::new();
    hasher.update(FINGERPRINT_DOMAIN);
    put_usize(&mut hasher, catalog.len())?;
    for id in catalog.ids() {
        put_typed_id(&mut hasher, id)?;
    }
    put_scheduler_geometry(&mut hasher, &scheduler.topology)?;
    put_usize(&mut hasher, priority.len())?;
    for &queue in priority {
        put_usize(&mut hasher, queue)?;
    }
    put_usize(&mut hasher, target)?;
    match formula {
        PreparedGapFormula::Clique { competitors } => {
            hasher.update(&[0]);
            put_indices(&mut hasher, competitors)?;
        }
        PreparedGapFormula::StarHub { leaves } => {
            hasher.update(&[1]);
            put_indices(&mut hasher, leaves)?;
        }
        PreparedGapFormula::StarLeaf { hub, other_leaves } => {
            hasher.update(&[2]);
            put_usize(&mut hasher, *hub)?;
            put_indices(&mut hasher, other_leaves)?;
        }
        PreparedGapFormula::ExactOppositeFace => {
            hasher.update(&[3]);
        }
    }
    Ok(*hasher.finalize().as_bytes())
}

fn put_scheduler_geometry(
    hasher: &mut Hasher,
    topology: &SchedulerTopology,
) -> Result<(), GapProbeError> {
    match topology {
        SchedulerTopology::Crossbar(crossbar) => {
            hasher.update(&[0]);
            put_typed_ids(hasher, &crossbar.inputs)?;
            put_typed_ids(hasher, &crossbar.outputs)?;
            put_usize(hasher, crossbar.edges.len())?;
            for edge in &crossbar.edges {
                put_typed_id(hasher, &edge.queue_id)?;
                put_typed_id(hasher, &edge.input)?;
                put_typed_id(hasher, &edge.output)?;
            }
        }
        SchedulerTopology::Interval(intervals) => {
            hasher.update(&[1]);
            put_usize(hasher, intervals.intervals.len())?;
            for interval in &intervals.intervals {
                put_typed_id(hasher, &interval.queue_id)?;
                put_exact_rational(hasher, &interval.left);
                put_exact_rational(hasher, &interval.right);
            }
        }
        SchedulerTopology::NodeExclusive(node) => {
            hasher.update(&[2]);
            put_typed_ids(hasher, &node.vertices)?;
            put_usize(hasher, node.links.len())?;
            for link in &node.links {
                put_typed_id(hasher, &link.queue_id)?;
                put_typed_id(hasher, &link.u)?;
                put_typed_id(hasher, &link.v)?;
            }
        }
        SchedulerTopology::ConflictGraph(graph) => {
            hasher.update(&[3]);
            put_usize(hasher, graph.conflicts.len())?;
            for conflict in &graph.conflicts {
                put_typed_id(hasher, &conflict.first)?;
                put_typed_id(hasher, &conflict.second)?;
            }
            put_optional_unsigned(hasher, graph.max_search_states.as_ref());
        }
        SchedulerTopology::ResourcePacking(packing) => {
            hasher.update(&[4]);
            put_typed_ids(hasher, &packing.resources)?;
            put_usize(hasher, packing.capacity.len())?;
            for capacity in &packing.capacity {
                put_exact_unsigned(hasher, capacity);
            }
            put_usize(hasher, packing.demands.len())?;
            for demand in &packing.demands {
                put_typed_id(hasher, &demand.queue_id)?;
                put_usize(hasher, demand.demand.len())?;
                for amount in &demand.demand {
                    put_exact_unsigned(hasher, amount);
                }
            }
            put_optional_unsigned(hasher, packing.max_search_states.as_ref());
        }
    }
    Ok(())
}

fn put_typed_ids(hasher: &mut Hasher, ids: &[TypedId]) -> Result<(), GapProbeError> {
    put_usize(hasher, ids.len())?;
    for id in ids {
        put_typed_id(hasher, id)?;
    }
    Ok(())
}

fn put_optional_unsigned(
    hasher: &mut Hasher,
    value: Option<&crate::exact::ExactUnsigned>,
) {
    match value {
        None => {
            hasher.update(&[0]);
        }
        Some(value) => {
            hasher.update(&[1]);
            put_exact_unsigned(hasher, value);
        }
    }
}

fn put_exact_rational(
    hasher: &mut Hasher,
    value: &ExactRational,
) {
    let numerator = value.as_ratio().numer();
    match numerator.sign() {
        num_bigint::Sign::Minus => {
            hasher.update(&[0]);
        }
        num_bigint::Sign::NoSign => {
            hasher.update(&[1]);
        }
        num_bigint::Sign::Plus => {
            hasher.update(&[2]);
        }
    }
    put_biguint(hasher, numerator.magnitude());
    put_biguint(hasher, value.as_ratio().denom().magnitude());
}

fn put_exact_unsigned(
    hasher: &mut Hasher,
    value: &crate::exact::ExactUnsigned,
) {
    put_biguint(hasher, value.as_biguint());
}

fn put_biguint(
    hasher: &mut Hasher,
    value: &num_bigint::BigUint,
) {
    hasher.update(&value.bits().to_le_bytes());
    for digit in value.iter_u64_digits() {
        hasher.update(&digit.to_le_bytes());
    }
}

fn put_indices(hasher: &mut Hasher, values: &[usize]) -> Result<(), GapProbeError> {
    put_usize(hasher, values.len())?;
    for &value in values {
        put_usize(hasher, value)?;
    }
    Ok(())
}

fn put_usize(hasher: &mut Hasher, value: usize) -> Result<(), GapProbeError> {
    let value = u64::try_from(value).map_err(|_error| GapProbeError::InvalidTopologyCoverage)?;
    hasher.update(&value.to_le_bytes());
    Ok(())
}

fn put_typed_id(hasher: &mut Hasher, id: &TypedId) -> Result<(), GapProbeError> {
    match id {
        TypedId::Integer(value) => {
            hasher.update(&[0]);
            put_exact_unsigned(hasher, value);
        }
        TypedId::String(value) => {
            hasher.update(&[1]);
            put_usize(hasher, value.len())?;
            hasher.update(value.as_bytes());
        }
    }
    Ok(())
}

fn try_vec<T>(capacity: usize) -> Result<Vec<T>, GapProbeError> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(capacity)
        .map_err(|_error| GapProbeError::CapacityExceeded)?;
    Ok(values)
}

fn try_bool_vec(length: usize) -> Result<Vec<bool>, GapProbeError> {
    let mut values = try_vec(length)?;
    values.resize(length, false);
    Ok(values)
}

#[cfg(test)]
mod tests {
    use num_bigint::BigInt;

    use super::*;
    use crate::occupancy_maxweight::PreparedOccupancyMaxWeight;
    use crate::resolved::{
        ConflictPair, CrossbarEdge, CrossbarTopology, NodeExclusiveLink, QueueInterval,
        ResourceDemand, ResourcePackingTopology,
    };
    use crate::exact::ExactUnsigned;
    use crate::unit_count::ServiceVector;

    fn q(index: usize) -> TypedId {
        TypedId::from(format!("q{index}"))
    }

    fn id(prefix: &str, index: usize) -> TypedId {
        TypedId::from(format!("{prefix}{index}"))
    }

    fn catalog(count: usize) -> QueueCatalog {
        QueueCatalog::try_new((0..count).map(q).collect()).expect("test catalog")
    }

    fn exact(value: i64) -> ExactRational {
        ExactRational::from_integer(BigInt::from(value))
    }

    fn probe(
        scheduler: &ResolvedScheduler,
        catalog: &QueueCatalog,
        target: usize,
    ) -> PreparedGapProbe {
        PreparedGapProbe::try_prepare(
            scheduler,
            catalog,
            QueueIndex(u32::try_from(target).expect("small target")),
        )
        .expect("probe preparation")
        .into_prepared()
        .expect("supported topology")
    }

    fn forced_face_theta(
        optimizer: &PreparedOccupancyMaxWeight,
        queue_count: usize,
        target: usize,
        occupancy: &[RuntimeCount],
    ) -> u128 {
        assert!(queue_count < usize::BITS as usize);
        let mut faces = [None::<u128>, None::<u128>];
        for mask in 0..(1_usize << queue_count) {
            let dense = (0..queue_count)
                .map(|queue| u8::from(mask & (1_usize << queue) != 0))
                .collect::<Vec<_>>();
            let service = ServiceVector::try_from_dense(dense).expect("binary mask");
            if !optimizer.is_feasible(&service).expect("oracle feasibility") {
                continue;
            }
            let face = usize::from(service.as_slice()[target]);
            let value = occupancy
                .iter()
                .enumerate()
                .filter(|(queue, _count)| *queue != target && service.as_slice()[*queue] == 1)
                .map(|(_queue, count)| u128::from(count.get()))
                .sum::<u128>();
            faces[face] = Some(faces[face].map_or(value, |prior| prior.max(value)));
        }
        faces[0].expect("forced zero") - faces[1].expect("forced one")
    }

    fn assert_formula(
        scheduler: &ResolvedScheduler,
        target: usize,
        states: &[[u64; 4]],
    ) {
        let queues = catalog(4);
        let prepared = probe(scheduler, &queues, target);
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(scheduler, &queues)
            .expect("oracle optimizer");
        for state in states {
            let occupancy = (*state).map(RuntimeCount::new);
            let theta = forced_face_theta(&optimizer, queues.len(), target, &occupancy);
            let n = u128::from(state[target]);
            let served = n > theta;
            let observed = prepared
                .observe(&occupancy, served)
                .expect("formula obeys strict sign decision");
            assert_eq!(observed.competition_scale(), theta, "state={state:?}");
        }
    }

    fn assert_exact_fallback(scheduler: &ResolvedScheduler, target: usize) {
        let queues = catalog(4);
        let prepared = PreparedGapProbe::try_prepare_with_exact_fallback(
            scheduler,
            &queues,
            QueueIndex(u32::try_from(target).expect("small target")),
            &exact(1),
        )
        .expect("fallback preparation")
        .into_prepared()
        .expect("exact scheduler admits fallback");
        assert!(prepared.requires_opposite_face_solve());
        let optimizer = PreparedOccupancyMaxWeight::try_prepare(scheduler, &queues)
            .expect("oracle optimizer");
        let mut scratch = optimizer.try_replication_scratch().expect("gap scratch");
        for state in exhaustive_small_states() {
            let occupancy = state.map(RuntimeCount::new);
            let decision = optimizer
                .solve_occupancy(&occupancy)
                .expect("physical exact solve");
            let served = decision.dense_service().as_slice()[target] != 0;
            let expected = forced_face_theta(&optimizer, queues.len(), target, &occupancy);
            let mut attempted_search_states = 0;
            let actual = optimizer
                .solve_exact_opposite_face_gap_with_scratch_counted(
                    &occupancy,
                    QueueIndex(u32::try_from(target).expect("small target")),
                    served,
                    decision.primary_objective(),
                    None,
                    &mut scratch,
                    &mut attempted_search_states,
                )
                .expect("opposite face solve");
            assert_eq!(actual, expected, "state={state:?}");
        }
    }

    fn exhaustive_small_states() -> Vec<[u64; 4]> {
        let mut states = Vec::new();
        for q0 in 0..=2 {
            for q1 in 0..=2 {
                for q2 in 0..=2 {
                    for q3 in 0..=2 {
                        states.push([q0, q1, q2, q3]);
                    }
                }
            }
        }
        states
    }

    #[test]
    fn conflict_star_hub_and_leaf_match_forced_faces() {
        let scheduler = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: (1..4)
                    .map(|leaf| ConflictPair {
                        first: q(0),
                        second: q(leaf),
                    })
                    .collect(),
                max_search_states: None,
            }),
        };
        let states = exhaustive_small_states();
        assert_formula(&scheduler, 0, &states);
        assert_formula(&scheduler, 1, &states);
    }

    #[test]
    fn long_interval_hub_and_leaf_match_forced_faces() {
        let scheduler = ResolvedScheduler {
            priority: (0..4).rev().map(q).collect(),
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: [(0, 10), (0, 2), (3, 5), (6, 8)]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, (left, right))| QueueInterval {
                        queue_id: q(queue),
                        left: exact(left),
                        right: exact(right),
                    })
                    .collect(),
            }),
        };
        let states = exhaustive_small_states();
        assert_formula(&scheduler, 0, &states);
        assert_formula(&scheduler, 2, &states);
    }

    #[test]
    fn crossbar_fan_in_and_node_cliques_match_forced_faces() {
        let states = exhaustive_small_states();
        for reverse_priority in [false, true] {
            let priority: Vec<TypedId> = if reverse_priority {
                (0..4).rev().map(q).collect()
            } else {
                (0..4).map(q).collect()
            };
            let crossbar_fan_in = ResolvedScheduler {
                priority: priority.clone(),
                topology: SchedulerTopology::Crossbar(CrossbarTopology {
                    inputs: (0..4).map(|index| id("i", index)).collect(),
                    outputs: vec![id("o", 0)],
                    edges: (0..4)
                        .map(|queue| CrossbarEdge {
                            queue_id: q(queue),
                            input: id("i", queue),
                            output: id("o", 0),
                        })
                        .collect(),
                }),
            };
            let crossbar_fan_out = ResolvedScheduler {
                priority: priority.clone(),
                topology: SchedulerTopology::Crossbar(CrossbarTopology {
                    inputs: vec![id("i", 0)],
                    outputs: (0..4).map(|index| id("o", index)).collect(),
                    edges: (0..4)
                        .map(|queue| CrossbarEdge {
                            queue_id: q(queue),
                            input: id("i", 0),
                            output: id("o", queue),
                        })
                        .collect(),
                }),
            };
            let node_common_vertex = ResolvedScheduler {
                priority,
                topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                    vertices: (0..5).map(|index| id("v", index)).collect(),
                    links: (0..4)
                        .map(|queue| NodeExclusiveLink {
                            queue_id: q(queue),
                            u: id("v", 0),
                            v: id("v", queue + 1),
                        })
                        .collect(),
                }),
            };
            for target in 0..4 {
                assert_formula(&crossbar_fan_in, target, &states);
                assert_formula(&crossbar_fan_out, target, &states);
                assert_formula(&node_common_vertex, target, &states);
            }
        }

        let triangle_catalog = catalog(3);
        let triangle = ResolvedScheduler {
            priority: (0..3).rev().map(q).collect(),
            topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                vertices: (0..3).map(|index| id("v", index)).collect(),
                links: [(0, 1), (1, 2), (2, 0)]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, (u, v))| NodeExclusiveLink {
                        queue_id: q(queue),
                        u: id("v", u),
                        v: id("v", v),
                    })
                    .collect(),
            }),
        };
        let triangle_probe = probe(&triangle, &triangle_catalog, 1);
        let occupancy = [RuntimeCount::new(9), RuntimeCount::new(7), RuntimeCount::new(2)];
        assert_eq!(triangle_probe.observe(&occupancy, false).expect("negative gap").competition_scale(), 9);
    }

    #[test]
    fn complete_conflict_graph_is_outside_the_frozen_c30_capability() {
        let queues = catalog(4);
        let complete_conflicts = (0..4)
            .flat_map(|first| {
                ((first + 1)..4).map(move |second| ConflictPair {
                    first: q(first),
                    second: q(second),
                })
            })
            .collect::<Vec<_>>();
        for reverse_priority in [false, true] {
            let priority: Vec<TypedId> = if reverse_priority {
                (0..4).rev().map(q).collect()
            } else {
                (0..4).map(q).collect()
            };
            let scheduler = ResolvedScheduler {
                priority,
                topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                    conflicts: complete_conflicts.clone(),
                    max_search_states: None,
                }),
            };
            for target in 0..4 {
                assert_eq!(
                    PreparedGapProbe::try_prepare(
                        &scheduler,
                        &queues,
                        QueueIndex(u32::try_from(target).expect("small target")),
                    )
                    .expect("complete conflict graph is a scientific refusal")
                    .unavailable_reason(),
                    Some(GapProbeUnavailableReasonV1::UnsupportedGapTopology)
                );
            }
        }
    }

    #[test]
    fn generic_topology_is_unavailable_and_scheduler_data_bind_fingerprint() {
        let queues = catalog(4);
        let topology = ConflictGraphTopology {
            conflicts: [(0, 1), (1, 2), (2, 3), (3, 0)]
                .into_iter()
                .map(|(first, second)| ConflictPair {
                    first: q(first),
                    second: q(second),
                })
                .collect(),
            max_search_states: None,
        };
        let forward = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(topology.clone()),
        };
        assert_eq!(
            PreparedGapProbe::try_prepare(&forward, &queues, QueueIndex(0))
                .expect("normal refusal")
                .unavailable_reason(),
            Some(GapProbeUnavailableReasonV1::UnsupportedGapTopology)
        );

        let star = ConflictGraphTopology {
            conflicts: (1..4)
                .map(|leaf| ConflictPair {
                    first: q(0),
                    second: q(leaf),
                })
                .collect(),
            max_search_states: None,
        };
        let first = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(star.clone()),
        };
        let second = ResolvedScheduler {
            priority: (0..4).rev().map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(star),
        };
        assert_ne!(
            probe(&first, &queues, 0).scheduler_fingerprint(),
            probe(&second, &queues, 0).scheduler_fingerprint()
        );

        let mut reordered_topology = match &first.topology {
            SchedulerTopology::ConflictGraph(topology) => topology.clone(),
            _ => unreachable!("test fixture is a conflict graph"),
        };
        reordered_topology.conflicts.reverse();
        let reordered = ResolvedScheduler {
            priority: first.priority.clone(),
            topology: SchedulerTopology::ConflictGraph(reordered_topology),
        };
        assert_ne!(
            probe(&first, &queues, 0).scheduler_fingerprint(),
            probe(&reordered, &queues, 0).scheduler_fingerprint()
        );
    }

    #[test]
    fn exact_fallback_matches_forced_faces_for_all_generic_scheduler_families() {
        let crossbar = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: (0..2).map(|index| id("i", index)).collect(),
                outputs: (0..2).map(|index| id("o", index)).collect(),
                edges: [(0, 0), (0, 1), (1, 0), (1, 1)]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, (input, output))| CrossbarEdge {
                        queue_id: q(queue),
                        input: id("i", input),
                        output: id("o", output),
                    })
                    .collect(),
            }),
        };
        let node_cycle = ResolvedScheduler {
            priority: (0..4).rev().map(q).collect(),
            topology: SchedulerTopology::NodeExclusive(NodeExclusiveTopology {
                vertices: (0..4).map(|index| id("v", index)).collect(),
                links: [(0, 1), (1, 2), (2, 3), (3, 0)]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, (u, v))| NodeExclusiveLink {
                        queue_id: q(queue),
                        u: id("v", u),
                        v: id("v", v),
                    })
                    .collect(),
            }),
        };
        let conflict_cycle = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: [(0, 1), (1, 2), (2, 3), (3, 0)]
                    .into_iter()
                    .map(|(first, second)| ConflictPair {
                        first: q(first),
                        second: q(second),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(256)),
            }),
        };
        let interval_path = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::Interval(IntervalTopology {
                intervals: [(0, 2), (1, 4), (3, 6), (5, 7)]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, (left, right))| QueueInterval {
                        queue_id: q(queue),
                        left: exact(left),
                        right: exact(right),
                    })
                    .collect(),
            }),
        };
        let packing = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::ResourcePacking(ResourcePackingTopology {
                resources: vec![id("r", 0), id("r", 1)],
                capacity: vec![ExactUnsigned::from_u64(4), ExactUnsigned::from_u64(4)],
                demands: [[3, 1], [1, 3], [2, 2], [2, 2]]
                    .into_iter()
                    .enumerate()
                    .map(|(queue, row)| ResourceDemand {
                        queue_id: q(queue),
                        demand: row.into_iter().map(ExactUnsigned::from_u64).collect(),
                    })
                    .collect(),
                max_search_states: Some(ExactUnsigned::from_u64(1024)),
            }),
        };
        for scheduler in [&crossbar, &node_cycle, &conflict_cycle, &packing] {
            assert_exact_fallback(scheduler, 0);
        }
        assert_exact_fallback(&interval_path, 1);
    }

    #[test]
    fn tie_is_exact_and_permits_both_authored_priority_outcomes() {
        let queues = catalog(4);
        let topology = CrossbarTopology {
            inputs: (0..4).map(|index| id("i", index)).collect(),
            outputs: vec![id("o", 0)],
            edges: (0..4)
                .map(|queue| CrossbarEdge {
                    queue_id: q(queue),
                    input: id("i", queue),
                    output: id("o", 0),
                })
                .collect(),
        };
        let target_first = ResolvedScheduler {
            priority: (0..4).map(q).collect(),
            topology: SchedulerTopology::Crossbar(topology.clone()),
        };
        let target_last = ResolvedScheduler {
            priority: (0..4).rev().map(q).collect(),
            topology: SchedulerTopology::Crossbar(topology),
        };
        let occupancy = [
            RuntimeCount::new(5),
            RuntimeCount::new(5),
            RuntimeCount::new(1),
            RuntimeCount::ZERO,
        ];
        let served_tie = probe(&target_first, &queues, 0)
            .observe(&occupancy, true)
            .expect("a target-served tie is exact");
        let lost_tie = probe(&target_last, &queues, 0)
            .observe(&occupancy, false)
            .expect("a target-unserved tie is exact");
        assert_ne!(
            probe(&target_first, &queues, 0).scheduler_fingerprint(),
            probe(&target_last, &queues, 0).scheduler_fingerprint()
        );
        assert_eq!(served_tie.sign(), GapSign::Tie);
        assert_eq!(lost_tie.sign(), GapSign::Tie);
        assert_eq!(served_tie.competition_scale(), 5);
        assert_eq!(served_tie.magnitude(), 0);

        let zero = [RuntimeCount::ZERO; 4];
        assert_eq!(
            probe(&target_first, &queues, 0)
                .observe(&zero, false)
                .expect("N=0 participates in the competition moments")
                .sign(),
            GapSign::Tie
        );
        assert_eq!(
            probe(&target_first, &queues, 0).observe(&zero, true),
            Err(GapProbeError::EmptyTargetServed)
        );
    }

    #[test]
    fn nonunit_multiplier_and_checked_scale_overflow_are_closed_refusals() {
        let queues = catalog(1);
        let scheduler = ResolvedScheduler {
            priority: vec![q(0)],
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: vec![],
                max_search_states: None,
            }),
        };
        assert_eq!(
            PreparedGapProbe::try_prepare_with_target_multiplier(
                &scheduler,
                &queues,
                QueueIndex(0),
                &exact(2),
            )
            .expect("nonunit multipliers are a scientific refusal")
            .unavailable_reason(),
            Some(GapProbeUnavailableReasonV1::NonunitTargetMultiplier)
        );
        assert_eq!(
            checked_add_scale(u128::MAX, 1),
            Err(GapProbeError::CompetitionScaleOverflow)
        );
        assert_eq!(
            GapProbePreparation::disabled_by_request().unavailable_reason(),
            Some(GapProbeUnavailableReasonV1::DisabledByRequest)
        );
        assert_eq!(
            GapProbeError::PositiveGapUnserved.code(),
            "positive_gap_unserved"
        );
    }

    #[test]
    fn zero_and_near_maximum_states_use_checked_signed_magnitude() {
        let queues = catalog(3);
        let scheduler = ResolvedScheduler {
            priority: (0..3).map(q).collect(),
            topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                conflicts: [1, 2]
                    .into_iter()
                    .map(|leaf| ConflictPair {
                        first: q(0),
                        second: q(leaf),
                    })
                    .collect(),
                max_search_states: None,
            }),
        };
        let prepared = probe(&scheduler, &queues, 0);
        let observed = prepared
            .observe(
                &[
                    RuntimeCount::ZERO,
                    RuntimeCount::new(u64::MAX),
                    RuntimeCount::new(u64::MAX),
                ],
                false,
            )
            .expect("u128 covers the admitted sum");
        assert_eq!(observed.sign(), GapSign::Negative);
        assert_eq!(observed.magnitude(), 2_u128 * u128::from(u64::MAX));
        assert_eq!(observed.positive_magnitude(), 0);
        assert_eq!(observed.negative_magnitude(), observed.magnitude());

        let clique = ResolvedScheduler {
            priority: (0..3).rev().map(q).collect(),
            topology: SchedulerTopology::Crossbar(CrossbarTopology {
                inputs: (0..3).map(|index| id("i", index)).collect(),
                outputs: vec![id("o", 0)],
                edges: (0..3)
                    .map(|queue| CrossbarEdge {
                        queue_id: q(queue),
                        input: id("i", queue),
                        output: id("o", 0),
                    })
                    .collect(),
            }),
        };
        let clique_observed = probe(&clique, &queues, 0)
            .observe(
                &[
                    RuntimeCount::ZERO,
                    RuntimeCount::new(u64::MAX),
                    RuntimeCount::new(u64::MAX - 1),
                ],
                false,
            )
            .expect("clique competition uses a maximum, not a sum");
        assert_eq!(clique_observed.competition_scale(), u128::from(u64::MAX));
        assert_eq!(clique_observed.magnitude(), u128::from(u64::MAX));

        assert_eq!(
            prepared.observe(
                &[RuntimeCount::new(1), RuntimeCount::ZERO, RuntimeCount::ZERO],
                false,
            ),
            Err(GapProbeError::PositiveGapUnserved)
        );
    }
}
