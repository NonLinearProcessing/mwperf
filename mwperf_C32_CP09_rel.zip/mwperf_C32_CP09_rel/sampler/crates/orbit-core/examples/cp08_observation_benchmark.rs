//! CP08 production-path performance qualification.
//!
//! The executable deliberately drives the public `orbit-core` weighted-
//! ensemble runner, observation bank, coordinator, and certified gap probe.
//! It is not a synthetic accumulator microbenchmark.  Each timed phase runs
//! in a fresh child process so Linux RSS high-water marks are comparable.
//!
//! Run it explicitly; normal tests only compile this target:
//!
//! ```text
//! cargo run -p orbit-core --release --example cp08_observation_benchmark -- \
//!     --profile full --samples 20
//! ```

// A counting global allocator is qualification-only instrumentation.  It is
// isolated to this example binary and cannot alter the orbit-core library or
// provider binaries, whose production crates continue to forbid unsafe code.
#![allow(unsafe_code)]
#![allow(
    clippy::cast_lossless,
    clippy::cast_possible_truncation,
    clippy::cast_sign_loss,
    clippy::missing_panics_doc,
    clippy::struct_excessive_bools,
    clippy::too_many_lines
)]

use std::alloc::{GlobalAlloc, Layout, System};
use std::error::Error;
use std::fmt::Write as _;
use std::fs;
use std::io;
use std::process::Command;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Instant;

use num_bigint::BigInt;
use orbit_core::construction_observation::{
    ObservationPlanV1, ObservationWorkCountersV1,
};
use orbit_core::direct_count_arrivals::{ArrivalReplay, PreparedArrival};
use orbit_core::exact::{ExactRational, ExactUnsigned, RuntimeCount};
use orbit_core::gap_probe::{GapProbePreparation, PreparedGapProbe};
use orbit_core::lineage_iid::{
    PreparedLineageIid, QualifiedIidDestination, QualifiedIidSource,
};
use orbit_core::occupancy_maxweight::PreparedOccupancyMaxWeight;
use orbit_core::resolved::{
    ConflictGraphTopology, ConflictPair, CountArrivalEvent, CrossbarEdge,
    CrossbarTopology, DeterministicTrace, ResolvedArrival, ResolvedScheduler,
    SchedulerTopology, SourceId, TypedId,
};
use orbit_core::unit_count::{QueueCatalog, QueueIndex};
use orbit_core::{
    ConstructionWorkLimits, OptimizerSearchStateGrant, PreparedCountProblem,
    PreparedCountRun, ReplicationCoordinate,
};
use orbit_core::weighted_ensemble_coordinator::{
    PreparedWeightedEnsembleRun, WeightedFinitePrefixLegacyStatusV2,
    WeightedObservationIdentityV1,
};
use orbit_core::weighted_ensemble_estimator::{
    WeightedObservationBankSinkV1, WeightedResponseCutoffV1,
};
use orbit_core::weighted_ensemble_runner::{
    OneEnsembleRunner, WeightedObservation,
};

type AnyError = Box<dyn Error + Send + Sync + 'static>;

struct CountingAllocator;

static ALLOC_CALLS: AtomicU64 = AtomicU64::new(0);
static REALLOC_CALLS: AtomicU64 = AtomicU64::new(0);
static ALLOCATED_BYTES: AtomicU64 = AtomicU64::new(0);
static DEALLOCATED_BYTES: AtomicU64 = AtomicU64::new(0);
static LIVE_BYTES: AtomicUsize = AtomicUsize::new(0);
static PEAK_LIVE_BYTES: AtomicUsize = AtomicUsize::new(0);

#[global_allocator]
static GLOBAL_ALLOCATOR: CountingAllocator = CountingAllocator;

unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: this delegates the unmodified allocation request to the
        // process system allocator and only observes a successful result.
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            record_allocation(layout.size());
        }
        pointer
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        // SAFETY: this delegates the unmodified allocation request to the
        // process system allocator and only observes a successful result.
        let pointer = unsafe { System.alloc_zeroed(layout) };
        if !pointer.is_null() {
            record_allocation(layout.size());
        }
        pointer
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        record_deallocation(layout.size());
        // SAFETY: `pointer` and `layout` are passed through exactly as supplied
        // by the caller of this `GlobalAlloc` implementation.
        unsafe { System.dealloc(pointer, layout) };
    }

    unsafe fn realloc(
        &self,
        pointer: *mut u8,
        layout: Layout,
        new_size: usize,
    ) -> *mut u8 {
        // SAFETY: this delegates the unmodified reallocation request to the
        // process system allocator and records it only after success.
        let replacement = unsafe { System.realloc(pointer, layout, new_size) };
        if !replacement.is_null() {
            REALLOC_CALLS.fetch_add(1, Ordering::Relaxed);
            if new_size >= layout.size() {
                let growth = new_size - layout.size();
                ALLOCATED_BYTES.fetch_add(saturating_u64(growth), Ordering::Relaxed);
                let live = LIVE_BYTES.fetch_add(growth, Ordering::Relaxed) + growth;
                record_peak(live);
            } else {
                let shrinkage = layout.size() - new_size;
                DEALLOCATED_BYTES.fetch_add(saturating_u64(shrinkage), Ordering::Relaxed);
                LIVE_BYTES.fetch_sub(shrinkage, Ordering::Relaxed);
            }
        }
        replacement
    }
}

fn saturating_u64(value: usize) -> u64 {
    u64::try_from(value).unwrap_or(u64::MAX)
}

fn record_allocation(bytes: usize) {
    ALLOC_CALLS.fetch_add(1, Ordering::Relaxed);
    ALLOCATED_BYTES.fetch_add(saturating_u64(bytes), Ordering::Relaxed);
    let live = LIVE_BYTES.fetch_add(bytes, Ordering::Relaxed) + bytes;
    record_peak(live);
}

fn record_deallocation(bytes: usize) {
    DEALLOCATED_BYTES.fetch_add(saturating_u64(bytes), Ordering::Relaxed);
    LIVE_BYTES.fetch_sub(bytes, Ordering::Relaxed);
}

fn record_peak(candidate: usize) {
    let mut prior = PEAK_LIVE_BYTES.load(Ordering::Relaxed);
    while candidate > prior {
        match PEAK_LIVE_BYTES.compare_exchange_weak(
            prior,
            candidate,
            Ordering::Relaxed,
            Ordering::Relaxed,
        ) {
            Ok(_) => break,
            Err(actual) => prior = actual,
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct AllocatorWindow {
    calls: u64,
    reallocations: u64,
    allocated_bytes: u64,
    deallocated_bytes: u64,
    peak_live_delta_bytes: usize,
}

fn begin_allocator_window() -> usize {
    ALLOC_CALLS.store(0, Ordering::Relaxed);
    REALLOC_CALLS.store(0, Ordering::Relaxed);
    ALLOCATED_BYTES.store(0, Ordering::Relaxed);
    DEALLOCATED_BYTES.store(0, Ordering::Relaxed);
    let live = LIVE_BYTES.load(Ordering::Relaxed);
    PEAK_LIVE_BYTES.store(live, Ordering::Relaxed);
    live
}

fn end_allocator_window(start_live: usize) -> AllocatorWindow {
    AllocatorWindow {
        calls: ALLOC_CALLS.load(Ordering::Relaxed),
        reallocations: REALLOC_CALLS.load(Ordering::Relaxed),
        allocated_bytes: ALLOCATED_BYTES.load(Ordering::Relaxed),
        deallocated_bytes: DEALLOCATED_BYTES.load(Ordering::Relaxed),
        peak_live_delta_bytes: PEAK_LIVE_BYTES
            .load(Ordering::Relaxed)
            .saturating_sub(start_live),
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Profile {
    Quick,
    Full,
}

impl Profile {
    const fn name(self) -> &'static str {
        match self {
            Self::Quick => "quick",
            Self::Full => "full",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum StateShape {
    LowDistinct,
    HighDistinct,
    UnsupportedGapAuto,
    OrdinaryShort,
    OrdinaryLong,
}

impl StateShape {
    const fn name(self) -> &'static str {
        match self {
            Self::LowDistinct => "low",
            Self::HighDistinct => "high",
            Self::UnsupportedGapAuto => "unsupported_gap_auto",
            Self::OrdinaryShort => "ordinary_short",
            Self::OrdinaryLong => "ordinary_long",
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Case {
    name: &'static str,
    particles: usize,
    ensembles: u64,
    warmup: u64,
    horizon: u64,
    blocks: usize,
    gap: bool,
    shape: StateShape,
    cap_refusal: bool,
}

impl Case {
    fn row_cap(self) -> Result<usize, AnyError> {
        if self.cap_refusal {
            return self
                .particles
                .checked_add(2)
                .ok_or_else(|| qualification_error("cap-refusal row reserve overflowed"));
        }
        let window = usize::try_from(self.horizon - self.warmup)?;
        window
            .checked_add(self.blocks)
            .and_then(|value| value.checked_add(17))
            .ok_or_else(|| qualification_error("qualification row cap overflowed"))
    }
}

fn qualification_cases(profile: Profile) -> Vec<Case> {
    let (small_population, scale_population, large_population, horizon, ensembles) =
        match profile {
            Profile::Quick => (1, 64, 256, 96, 2),
            Profile::Full => (1, 256, 4_096, 512, 64),
        };
    let large_horizon = if profile == Profile::Full { 192 } else { 64 };
    vec![
        Case {
            name: "p1_low_b1_gap_off",
            particles: small_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 1,
            gap: false,
            shape: StateShape::LowDistinct,
            cap_refusal: false,
        },
        Case {
            name: "p_scale_low_b1_gap_off",
            particles: scale_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 1,
            gap: false,
            shape: StateShape::LowDistinct,
            cap_refusal: false,
        },
        Case {
            name: "p_large_low_b1_gap_off",
            particles: large_population,
            ensembles: 1,
            warmup: 8,
            horizon: large_horizon,
            blocks: 1,
            gap: false,
            shape: StateShape::LowDistinct,
            cap_refusal: false,
        },
        Case {
            name: "p_scale_high_b1_gap_off",
            particles: scale_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 1,
            gap: false,
            shape: StateShape::HighDistinct,
            cap_refusal: false,
        },
        Case {
            name: "p_scale_high_b16_gap_off",
            particles: scale_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 16,
            gap: false,
            shape: StateShape::HighDistinct,
            cap_refusal: false,
        },
        Case {
            name: "p_scale_high_b16_gap_on",
            particles: scale_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 16,
            gap: true,
            shape: StateShape::HighDistinct,
            cap_refusal: false,
        },
        Case {
            name: "cap_plus_one_refusal",
            particles: scale_population,
            ensembles: 1,
            warmup: 8,
            horizon,
            blocks: 1,
            gap: true,
            shape: StateShape::HighDistinct,
            cap_refusal: true,
        },
        Case {
            name: "unsupported_gap_auto",
            particles: scale_population,
            ensembles,
            warmup: 8,
            horizon,
            blocks: 1,
            gap: false,
            shape: StateShape::UnsupportedGapAuto,
            cap_refusal: false,
        },
        Case {
            name: "ordinary_short_restart",
            particles: 1,
            ensembles: if profile == Profile::Full { 64 } else { 4 },
            warmup: 0,
            horizon: if profile == Profile::Full { 256 } else { 64 },
            blocks: 1,
            gap: false,
            shape: StateShape::OrdinaryShort,
            cap_refusal: false,
        },
        Case {
            name: "ordinary_long_stationary",
            particles: 1,
            ensembles: if profile == Profile::Full { 16 } else { 2 },
            warmup: if profile == Profile::Full { 512 } else { 32 },
            horizon: if profile == Profile::Full { 4_096 } else { 256 },
            blocks: 16,
            gap: false,
            shape: StateShape::OrdinaryLong,
            cap_refusal: false,
        },
    ]
}

#[derive(Debug)]
struct PreparedFixture {
    optimizer: PreparedOccupancyMaxWeight,
    iid: PreparedLineageIid,
    gap_probe: Option<PreparedGapProbe>,
    target: QueueIndex,
}

fn one() -> ExactRational {
    ExactRational::from_integer(BigInt::from(1_u8))
}

fn prepare_fixture(shape: StateShape) -> Result<PreparedFixture, AnyError> {
    let target_id = TypedId::from("q_target");
    let competitor_id = TypedId::from("q_competitor");
    let (catalog, scheduler, target, sources, expect_gap_probe) = match shape {
        StateShape::LowDistinct => {
            let catalog = QueueCatalog::try_new(vec![target_id.clone()])?;
            let scheduler = ResolvedScheduler {
                priority: vec![target_id],
                topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                    conflicts: Vec::new(),
                    max_search_states: None,
                }),
            };
            let sources = vec![certain_source("source_target", QueueIndex(0))];
            (catalog, scheduler, QueueIndex(0), sources, true)
        }
        StateShape::HighDistinct => {
            let catalog = QueueCatalog::try_new(vec![
                competitor_id.clone(),
                target_id.clone(),
            ])?;
            let scheduler = ResolvedScheduler {
                // The competitor wins positive ties. With one certain arrival
                // to each queue, target backlog then visits O(T-W) levels.
                priority: vec![competitor_id.clone(), target_id.clone()],
                topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                    conflicts: vec![ConflictPair {
                        first: competitor_id,
                        second: target_id,
                    }],
                    max_search_states: None,
                }),
            };
            let sources = vec![
                certain_source("source_competitor", QueueIndex(0)),
                certain_source("source_target", QueueIndex(1)),
            ];
            (catalog, scheduler, QueueIndex(1), sources, true)
        }
        StateShape::UnsupportedGapAuto => {
            let queue_ids: Vec<TypedId> = (0..4)
                .map(|index| TypedId::from(format!("q{index}")))
                .collect();
            let catalog = QueueCatalog::try_new(queue_ids.clone())?;
            // A four-cycle is outside the certified conflict-star family.
            // The observation lane must therefore continue with gap disabled,
            // without an optimizer rerun or an invented approximation.
            let scheduler = ResolvedScheduler {
                priority: queue_ids.clone(),
                topology: SchedulerTopology::ConflictGraph(ConflictGraphTopology {
                    conflicts: [(0, 1), (1, 2), (2, 3), (3, 0)]
                        .into_iter()
                        .map(|(first, second)| ConflictPair {
                            first: queue_ids[first].clone(),
                            second: queue_ids[second].clone(),
                        })
                        .collect(),
                    max_search_states: None,
                }),
            };
            let sources = vec![certain_source("source_target", QueueIndex(0))];
            (catalog, scheduler, QueueIndex(0), sources, false)
        }
        StateShape::OrdinaryShort | StateShape::OrdinaryLong => {
            return Err(qualification_error(
                "ordinary cases do not use the weighted-ensemble fixture",
            ));
        }
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)?;
    let iid = PreparedLineageIid::try_new(catalog.clone(), [0x81; 32], sources)?;
    let gap_probe = match PreparedGapProbe::try_prepare(&scheduler, &catalog, target)? {
        GapProbePreparation::Available(probe) if expect_gap_probe => Some(probe),
        GapProbePreparation::Unavailable(reason) if !expect_gap_probe => {
            if reason.code() != "unsupported_gap_topology" {
                return Err(qualification_error(
                    "unsupported-gap fixture returned the wrong refusal reason",
                ));
            }
            None
        }
        GapProbePreparation::Available(_) => {
            return Err(qualification_error(
                "unsupported-gap fixture unexpectedly prepared a probe",
            ));
        }
        GapProbePreparation::Unavailable(reason) => {
            return Err(qualification_error(format!(
                "qualification gap fixture was unavailable: {}",
                reason.code()
            )));
        }
    };
    Ok(PreparedFixture {
        optimizer,
        iid,
        gap_probe,
        target,
    })
}

fn certain_source(name: &str, queue: QueueIndex) -> QualifiedIidSource {
    QualifiedIidSource {
        source_id: SourceId::new(name.to_owned()),
        arrival_probability: one(),
        destinations: vec![QualifiedIidDestination {
            queue,
            probability: one(),
        }],
    }
}

fn selected_gap_probe(
    case: Case,
    fixture: &PreparedFixture,
) -> Result<
    Option<&dyn orbit_core::weighted_ensemble_runner::WeightedGapProbeV1>,
    AnyError,
> {
    if !case.gap {
        return Ok(None);
    }
    let probe = fixture
        .gap_probe
        .as_ref()
        .ok_or_else(|| qualification_error("gap-enabled case has no certified probe"))?;
    Ok(Some(
        probe as &dyn orbit_core::weighted_ensemble_runner::WeightedGapProbeV1,
    ))
}

fn reporting_boundaries(case: Case) -> Result<Vec<u64>, AnyError> {
    let window = case.horizon - case.warmup;
    let block_count = u64::try_from(case.blocks)?;
    if block_count == 0 || block_count > window {
        return Err(qualification_error(
            "qualification block count is outside 1..=T-W",
        ));
    }
    let mut boundaries = Vec::with_capacity(case.blocks + 1);
    for block in 0..=block_count {
        boundaries.push(case.warmup + window * block / block_count);
    }
    if boundaries.windows(2).any(|pair| pair[0] >= pair[1]) {
        return Err(qualification_error(
            "qualification reporting boundaries were not strict",
        ));
    }
    Ok(boundaries)
}

fn observation_plan(case: Case) -> Result<ObservationPlanV1, AnyError> {
    let cap = case.row_cap()?;
    Ok(ObservationPlanV1::try_new(
        case.warmup,
        case.horizon,
        reporting_boundaries(case)?,
        cap,
        cap,
        case.gap,
    )?)
}

fn prepared_run(
    case: Case,
    fixture: &PreparedFixture,
) -> Result<PreparedWeightedEnsembleRun, AnyError> {
    let alpha = ExactRational::new(
        BigInt::from(1_u8),
        BigInt::from(20_u8),
        "CP08 performance qualification familywise alpha",
    )?;
    Ok(
        PreparedWeightedEnsembleRun::try_from_prepared_with_response_cutoff_v1(
            fixture.optimizer.clone(),
            fixture.iid.clone(),
            [0x82; 32],
            usize::try_from(fixture.target.0)?,
            case.warmup,
            case.horizon,
            case.ensembles,
            case.particles,
            WeightedResponseCutoffV1::try_new(4)?,
            alpha,
        )?,
    )
}

fn observation_identities(case: Case) -> Result<Vec<WeightedObservationIdentityV1>, AnyError> {
    let capacity = usize::try_from(case.ensembles)?;
    let mut identities = Vec::with_capacity(capacity);
    for ensemble_id in 0..case.ensembles {
        identities.push(WeightedObservationIdentityV1::new(
            addressed_digest(0x91, ensemble_id),
            addressed_digest(0x92, ensemble_id),
        ));
    }
    Ok(identities)
}

fn addressed_digest(domain: u8, coordinate: u64) -> [u8; 32] {
    let mut digest = [domain; 32];
    let bytes = coordinate.to_le_bytes();
    for (index, byte) in bytes.into_iter().enumerate() {
        digest[index] ^= byte;
    }
    digest
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct CounterSnapshot {
    committed_rows: u128,
    new_sparse_keys: u128,
    gap_evaluations: u128,
    boundary_scans: u128,
    cache_hits: u128,
    cache_keys: u128,
    prepared_reservation_sites: u128,
    prepared_capacity_units: u128,
}

impl CounterSnapshot {
    fn from_counter(counter: ObservationWorkCountersV1) -> Self {
        Self {
            committed_rows: counter.committed_rows(),
            new_sparse_keys: counter.new_sparse_keys(),
            gap_evaluations: counter.gap_evaluations(),
            boundary_scans: counter.boundary_scans(),
            cache_hits: counter.schedule_cache_hits(),
            cache_keys: counter.schedule_cache_keys(),
            prepared_reservation_sites: counter.prepared_capacity_allocations(),
            prepared_capacity_units: counter.prepared_capacity_units(),
        }
    }

    fn checked_add(self, other: Self) -> Result<Self, AnyError> {
        Ok(Self {
            committed_rows: checked_counter(self.committed_rows, other.committed_rows)?,
            new_sparse_keys: checked_counter(self.new_sparse_keys, other.new_sparse_keys)?,
            gap_evaluations: checked_counter(self.gap_evaluations, other.gap_evaluations)?,
            boundary_scans: checked_counter(self.boundary_scans, other.boundary_scans)?,
            cache_hits: checked_counter(self.cache_hits, other.cache_hits)?,
            cache_keys: checked_counter(self.cache_keys, other.cache_keys)?,
            prepared_reservation_sites: checked_counter(
                self.prepared_reservation_sites,
                other.prepared_reservation_sites,
            )?,
            prepared_capacity_units: checked_counter(
                self.prepared_capacity_units,
                other.prepared_capacity_units,
            )?,
        })
    }
}

fn checked_counter(first: u128, second: u128) -> Result<u128, AnyError> {
    first
        .checked_add(second)
        .ok_or_else(|| qualification_error("qualification counter overflowed"))
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct RetainedRows {
    replications: usize,
    blocks: usize,
    levels: usize,
    boundary_rows: usize,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct RssSnapshot {
    rss_kib: Option<u64>,
    high_water_kib: Option<u64>,
}

fn linux_rss() -> RssSnapshot {
    let Ok(status) = fs::read_to_string("/proc/self/status") else {
        return RssSnapshot::default();
    };
    RssSnapshot {
        rss_kib: parse_status_kib(&status, "VmRSS:"),
        high_water_kib: parse_status_kib(&status, "VmHWM:"),
    }
}

fn parse_status_kib(status: &str, field: &str) -> Option<u64> {
    status.lines().find_map(|line| {
        let remainder = line.strip_prefix(field)?;
        remainder.split_whitespace().next()?.parse().ok()
    })
}

#[derive(Debug)]
struct Record {
    phase: &'static str,
    elapsed_ns: u128,
    allocator: AllocatorWindow,
    baseline_allocator: Option<AllocatorWindow>,
    rss_before: RssSnapshot,
    rss_after: RssSnapshot,
    status: &'static str,
    response_equal: Option<bool>,
    work_equal: Option<bool>,
    observation_counters_available: bool,
    executed_ensembles: u64,
    particle_transitions: u64,
    optimizer_calls: u64,
    cache_misses_available: bool,
    cache_misses: u64,
    rng_draws_available: bool,
    rng_draws: u64,
    encoded_bytes_available: bool,
    encoded_bytes: u64,
    retained_bytes_available: bool,
    retained_bytes: u64,
    counters: CounterSnapshot,
    retained: RetainedRows,
    failure_code: Option<&'static str>,
}

impl Record {
    fn empty(phase: &'static str) -> Self {
        Self {
            phase,
            elapsed_ns: 0,
            allocator: AllocatorWindow::default(),
            baseline_allocator: None,
            rss_before: RssSnapshot::default(),
            rss_after: RssSnapshot::default(),
            status: "complete",
            response_equal: None,
            work_equal: None,
            observation_counters_available: false,
            executed_ensembles: 0,
            particle_transitions: 0,
            optimizer_calls: 0,
            cache_misses_available: false,
            cache_misses: 0,
            rng_draws_available: false,
            rng_draws: 0,
            encoded_bytes_available: false,
            encoded_bytes: 0,
            retained_bytes_available: false,
            retained_bytes: 0,
            counters: CounterSnapshot::default(),
            retained: RetainedRows::default(),
            failure_code: None,
        }
    }
}

fn measured<T>(operation: impl FnOnce() -> T) -> (T, u128, AllocatorWindow, RssSnapshot, RssSnapshot) {
    let rss_before = linux_rss();
    let start_live = begin_allocator_window();
    let started = Instant::now();
    let result = operation();
    let elapsed_ns = started.elapsed().as_nanos();
    let allocator = end_allocator_window(start_live);
    let rss_after = linux_rss();
    (result, elapsed_ns, allocator, rss_before, rss_after)
}

fn slot_loop(case: Case, diagnostics: bool) -> Result<Record, AnyError> {
    let fixture = prepare_fixture(case.shape)?;
    let mut runner = OneEnsembleRunner::try_new(
        &fixture.optimizer,
        &fixture.iid,
        [0x82; 32],
        0,
        fixture.target,
        case.warmup,
        case.horizon,
        case.particles,
    )?;
    let mut ensemble = runner.try_initial_ensemble()?;

    if !diagnostics {
        let mut discard = |_slot: u64, _rows: &[WeightedObservation]| {};
        let (summary, elapsed_ns, allocator, rss_before, rss_after) =
            measured(|| runner.run(&mut ensemble, &mut discard));
        let summary = summary?;
        let mut record = Record::empty("slot_loop_off");
        record.elapsed_ns = elapsed_ns;
        record.allocator = allocator;
        record.rss_before = rss_before;
        record.rss_after = rss_after;
        record.executed_ensembles = 1;
        record.particle_transitions = summary.work().particle_transitions();
        record.optimizer_calls = summary.work().exact_optimizer_calls();
        record.cache_misses_available = true;
        record.cache_misses = record.optimizer_calls;
        return Ok(record);
    }

    let plan = observation_plan(case)?;
    let mut sink = WeightedObservationBankSinkV1::try_new(0, case.particles, plan.clone())?;
    let gap_probe = selected_gap_probe(case, &fixture)?;
    runner.try_enable_observation_v1(plan, gap_probe)?;
    let (outcome, elapsed_ns, allocator, rss_before, rss_after) =
        measured(|| runner.run_with_observation_v1(&mut ensemble, &mut sink));
    let outcome = outcome?;
    let status = if outcome.failure().is_some() {
        "failed"
    } else {
        "complete"
    };
    let counters = CounterSnapshot::from_counter(outcome.observation_work()).checked_add(
        CounterSnapshot::from_counter(sink.observation_work()),
    )?;
    let mut record = Record::empty("slot_loop_on");
    record.elapsed_ns = elapsed_ns;
    record.allocator = allocator;
    record.rss_before = rss_before;
    record.rss_after = rss_after;
    record.status = status;
    record.observation_counters_available = true;
    record.executed_ensembles = 1;
    record.particle_transitions = outcome.work().particle_transitions();
    record.optimizer_calls = outcome.work().exact_optimizer_calls();
    record.cache_misses_available = true;
    record.cache_misses = record.optimizer_calls;
    record.counters = counters;
    if outcome.failure().is_some() {
        record.failure_code = Some("weighted_ensemble_run");
    }
    Ok(record)
}

fn slot_allocation_parity(case: Case) -> Result<Record, AnyError> {
    let off = slot_loop(case, false)?;
    let on = slot_loop(case, true)?;
    let mut record = on;
    record.phase = "slot_allocation_parity";
    record.baseline_allocator = Some(off.allocator);
    record.work_equal = Some(
        record.particle_transitions == off.particle_transitions
            && record.optimizer_calls == off.optimizer_calls,
    );
    if record.work_equal != Some(true) {
        return Err(qualification_error(
            "diagnostics changed one-ensemble physical work",
        ));
    }
    Ok(record)
}

fn ordinary_observation(case: Case) -> Result<Record, AnyError> {
    if !matches!(case.shape, StateShape::OrdinaryShort | StateShape::OrdinaryLong) {
        return Err(qualification_error("ordinary phase received a WE case"));
    }
    let target_id = TypedId::from("q_target");
    let input_id = TypedId::from("input");
    let output_id = TypedId::from("output");
    let catalog = QueueCatalog::try_new(vec![target_id.clone()])?;
    let scheduler = ResolvedScheduler {
        priority: vec![target_id.clone()],
        topology: SchedulerTopology::Crossbar(CrossbarTopology {
            inputs: vec![input_id.clone()],
            outputs: vec![output_id.clone()],
            edges: vec![CrossbarEdge {
                queue_id: target_id.clone(),
                input: input_id,
                output: output_id,
            }],
        }),
    };
    let optimizer = PreparedOccupancyMaxWeight::try_prepare(&scheduler, &catalog)?;
    let mut arrival_events = Vec::with_capacity(usize::try_from(case.horizon)?);
    for slot in 0..case.horizon {
        // Keep the long-reference queue nonempty throughout W..T instead of
        // timing an idle tail after one slot-zero batch.
        arrival_events.push(CountArrivalEvent {
            slot: ExactUnsigned::from_u64(slot),
            queue_id: target_id.clone(),
            count: 2,
        });
    }
    let arrivals = PreparedArrival::try_compile(
        &ResolvedArrival::DeterministicTrace(DeterministicTrace {
            events: arrival_events,
        }),
        &catalog,
    )?;
    let limits = ConstructionWorkLimits::try_new(
        case.horizon,
        OptimizerSearchStateGrant::NotApplicable,
        64,
    )?;
    let problem: Arc<PreparedCountProblem> = PreparedCountProblem::try_new(
        catalog,
        optimizer,
        arrivals,
        QueueIndex(0),
        RuntimeCount::new(case.warmup),
        RuntimeCount::new(case.horizon),
        limits,
    )?;
    let plan = observation_plan(case)?;
    let mut jobs = Vec::with_capacity(usize::try_from(case.ensembles)?);
    for coordinate in 0..case.ensembles {
        jobs.push((
            PreparedCountRun::try_bind(
                Arc::clone(&problem),
                ArrivalReplay::from_seed_material([0xa1; 32], coordinate),
            )?,
            TypedId::from(format!("ordinary-{coordinate:06}")),
        ));
    }
    let (reports, elapsed_ns, allocator, rss_before, rss_after) = measured(|| {
        jobs
            .into_iter()
            .enumerate()
            .map(|(index, (run, replication_id))| {
                run.execute_observed_evidenced(
                    ReplicationCoordinate::new(
                        u64::try_from(index).expect("admitted ordinary index fits u64"),
                    ),
                    replication_id,
                    plan.clone(),
                    None,
                )
            })
            .collect::<Vec<_>>()
    });

    let mut record = Record::empty(match case.shape {
        StateShape::OrdinaryShort => "ordinary_short_observation",
        StateShape::OrdinaryLong => "ordinary_long_observation",
        _ => unreachable!("ordinary shape was checked above"),
    });
    record.elapsed_ns = elapsed_ns;
    record.allocator = allocator;
    record.rss_before = rss_before;
    record.rss_after = rss_after;
    record.rng_draws_available = true;
    record.executed_ensembles = case.ensembles;
    record.retained.replications = reports.len();
    for report in &reports {
        if let Some(error) = report.observation_error() {
            return Err(qualification_error(format!(
                "ordinary observation finalization failed: {error}"
            )));
        }
        let observation = report
            .observation()
            .ok_or_else(|| qualification_error("ordinary execution omitted its observation"))?;
        let work = report.report().work();
        record.particle_transitions = record
            .particle_transitions
            .checked_add(work.committed_slots())
            .ok_or_else(|| qualification_error("ordinary committed-slot work overflowed"))?;
        record.optimizer_calls = record
            .optimizer_calls
            .checked_add(work.exact_optimizer_calls())
            .ok_or_else(|| qualification_error("ordinary optimizer work overflowed"))?;
        record.rng_draws = record
            .rng_draws
            .checked_add(work.configured_generator_draws())
            .ok_or_else(|| qualification_error("ordinary RNG work overflowed"))?;
        record.retained.blocks = record
            .retained
            .blocks
            .checked_add(observation.blocks.len())
            .ok_or_else(|| qualification_error("ordinary retained block count overflowed"))?;
        record.counters.boundary_scans = record
            .counters
            .boundary_scans
            .checked_add(u128::try_from(observation.blocks.len() + 1)?)
            .ok_or_else(|| qualification_error("ordinary boundary work overflowed"))?;
        for block in &observation.blocks {
            record.retained.levels = record
                .retained
                .levels
                .checked_add(block.levels.len())
                .ok_or_else(|| qualification_error("ordinary retained levels overflowed"))?;
            record.retained.boundary_rows = record
                .retained
                .boundary_rows
                .checked_add(block.initial_boundary_law.rows.len())
                .and_then(|value| {
                    value.checked_add(block.committed_boundary_law.rows.len())
                })
                .ok_or_else(|| qualification_error("ordinary boundary rows overflowed"))?;
            record.counters.new_sparse_keys = record
                .counters
                .new_sparse_keys
                .checked_add(u128::try_from(block.levels.len())?)
                .ok_or_else(|| qualification_error("ordinary sparse keys overflowed"))?;
            record.counters.committed_rows = record
                .counters
                .committed_rows
                .checked_add(u128::from(block.end_boundary - block.begin_boundary))
                .ok_or_else(|| qualification_error("ordinary committed rows overflowed"))?;
        }
    }
    let expected_committed = u128::from(case.ensembles)
        .checked_mul(u128::from(case.horizon - case.warmup))
        .ok_or_else(|| qualification_error("ordinary expected rows overflowed"))?;
    if record.counters.committed_rows != expected_committed {
        return Err(qualification_error(
            "ordinary observation did not retain every measured slot",
        ));
    }
    Ok(record)
}

fn full_legacy(case: Case) -> Result<Record, AnyError> {
    if case.cap_refusal {
        return Err(qualification_error(
            "cap-refusal case has no matched complete legacy lane",
        ));
    }
    let fixture = prepare_fixture(case.shape)?;
    let run = prepared_run(case, &fixture)?;
    let (result, elapsed_ns, allocator, rss_before, rss_after) =
        measured(|| run.execute_finite_prefix_v1(1));
    let result = result?;
    let mut record = Record::empty("full_observation_off");
    record.elapsed_ns = elapsed_ns;
    record.allocator = allocator;
    record.rss_before = rss_before;
    record.rss_after = rss_after;
    record.executed_ensembles = case.ensembles;
    record.particle_transitions = result.work().particle_transitions();
    record.optimizer_calls = result.work().exact_optimizer_calls();
    record.cache_misses_available = true;
    record.cache_misses = record.optimizer_calls;
    Ok(record)
}

fn full_observation(case: Case) -> Result<Record, AnyError> {
    let fixture = prepare_fixture(case.shape)?;
    let run = prepared_run(case, &fixture)?;
    let plan = observation_plan(case)?;
    let identities = observation_identities(case)?;
    let gap_probe = selected_gap_probe(case, &fixture)?;
    let (outcome, elapsed_ns, allocator, rss_before, rss_after) = measured(|| {
        run.execute_finite_prefix_with_observation_v2(1, &plan, &identities, gap_probe)
    });
    let outcome = outcome?;
    let complete = matches!(
        outcome.legacy_status(),
        WeightedFinitePrefixLegacyStatusV2::Complete(_)
    );
    if !case.cap_refusal && !complete {
        return Err(qualification_error(
            "an admitted observation qualification case did not complete",
        ));
    }
    if case.cap_refusal && complete {
        return Err(qualification_error(
            "the cap-plus-one qualification case unexpectedly completed",
        ));
    }
    let counters = CounterSnapshot::from_counter(outcome.observation_work());
    if complete {
        check_complete_counters(case, counters)?;
    }
    let retained = retained_rows(&outcome);
    let failure_code = outcome.primary_failure().map(|failure| failure.code());
    let mut record = Record::empty(if case.cap_refusal {
        "cap_refusal"
    } else {
        "full_observation_on"
    });
    record.elapsed_ns = elapsed_ns;
    record.allocator = allocator;
    record.rss_before = rss_before;
    record.rss_after = rss_after;
    record.status = if complete { "complete" } else { "failed" };
    record.observation_counters_available = true;
    record.executed_ensembles = case.ensembles;
    record.particle_transitions = outcome.work().particle_transitions();
    record.optimizer_calls = outcome.work().exact_optimizer_calls();
    record.cache_misses_available = true;
    record.cache_misses = record.optimizer_calls;
    record.counters = counters;
    record.retained = retained;
    record.failure_code = failure_code;
    Ok(record)
}

fn scientific_equivalence(case: Case) -> Result<Record, AnyError> {
    if case.cap_refusal {
        return Err(qualification_error(
            "cap-refusal case cannot be used for complete equivalence",
        ));
    }
    let fixture = prepare_fixture(case.shape)?;
    let run = prepared_run(case, &fixture)?;
    let plan = observation_plan(case)?;
    let identities = observation_identities(case)?;
    let gap_probe = selected_gap_probe(case, &fixture)?;
    let (pair, elapsed_ns, allocator, rss_before, rss_after) = measured(|| {
        let baseline = run.execute_finite_prefix_v1(1);
        let observed = run.execute_finite_prefix_with_observation_v2(
            1,
            &plan,
            &identities,
            gap_probe,
        );
        (baseline, observed)
    });
    let baseline = pair.0?;
    let observed = pair.1?;
    let (response_equal, work_equal) = match observed.legacy_status() {
        WeightedFinitePrefixLegacyStatusV2::Complete(observed_result) => (
            observed_result.finite_prefix_estimate() == baseline.finite_prefix_estimate(),
            observed_result.work() == baseline.work() && observed.work() == baseline.work(),
        ),
        WeightedFinitePrefixLegacyStatusV2::Failed { .. }
        | WeightedFinitePrefixLegacyStatusV2::ResponseFailed { .. } => (false, false),
    };
    if !response_equal || !work_equal {
        return Err(qualification_error(
            "diagnostics-on changed legacy response or physical work",
        ));
    }
    let counters = CounterSnapshot::from_counter(observed.observation_work());
    check_complete_counters(case, counters)?;
    let mut record = Record::empty("scientific_equivalence");
    record.elapsed_ns = elapsed_ns;
    record.allocator = allocator;
    record.rss_before = rss_before;
    record.rss_after = rss_after;
    record.response_equal = Some(response_equal);
    record.work_equal = Some(work_equal);
    record.observation_counters_available = true;
    record.executed_ensembles = case
        .ensembles
        .checked_mul(2)
        .ok_or_else(|| qualification_error("equivalence ensemble count overflowed"))?;
    record.particle_transitions = observed
        .work()
        .particle_transitions()
        .checked_add(baseline.work().particle_transitions())
        .ok_or_else(|| qualification_error("equivalence transition work overflowed"))?;
    record.optimizer_calls = observed
        .work()
        .exact_optimizer_calls()
        .checked_add(baseline.work().exact_optimizer_calls())
        .ok_or_else(|| qualification_error("equivalence optimizer work overflowed"))?;
    record.cache_misses_available = true;
    record.cache_misses = record.optimizer_calls;
    record.counters = counters;
    record.retained = retained_rows(&observed);
    Ok(record)
}

fn check_complete_counters(case: Case, counters: CounterSnapshot) -> Result<(), AnyError> {
    let measured_slots = u128::from(case.horizon - case.warmup);
    let particles = u128::try_from(case.particles)?;
    let boundary_visits = u128::try_from(case.blocks + 1)?;
    let expected_rows = u128::from(case.ensembles)
        .checked_mul(particles)
        .and_then(|value| value.checked_mul(measured_slots))
        .ok_or_else(|| qualification_error("expected committed-row work overflowed"))?;
    let expected_gap = if case.gap { expected_rows } else { 0 };
    let expected_boundaries = u128::from(case.ensembles)
        .checked_mul(particles)
        .and_then(|value| value.checked_mul(boundary_visits))
        .ok_or_else(|| qualification_error("expected boundary work overflowed"))?;
    if counters.committed_rows != expected_rows
        || counters.gap_evaluations != expected_gap
        || counters.boundary_scans != expected_boundaries
    {
        return Err(qualification_error(
            "complete observation counters did not match admitted production work",
        ));
    }
    Ok(())
}

fn retained_rows(
    outcome: &orbit_core::weighted_ensemble_coordinator::WeightedFinitePrefixRunOutcomeV2,
) -> RetainedRows {
    let mut retained = RetainedRows::default();
    for attempt in outcome.attempts() {
        let Some(replication) = attempt.observation() else {
            continue;
        };
        retained.replications += 1;
        retained.blocks += replication.blocks.len();
        for block in &replication.blocks {
            retained.levels += block.levels.len();
            retained.boundary_rows += block.initial_boundary_law.rows.len();
            retained.boundary_rows += block.committed_boundary_law.rows.len();
        }
    }
    retained
}

fn qualification_error(message: impl Into<String>) -> AnyError {
    Box::new(io::Error::other(message.into()))
}

#[derive(Debug)]
struct Arguments {
    profile: Profile,
    samples: usize,
    child_case: Option<String>,
    child_phase: Option<String>,
    sample: usize,
}

fn parse_arguments() -> Result<Arguments, AnyError> {
    let mut profile = Profile::Quick;
    let mut samples = 3_usize;
    let mut child_case = None;
    let mut child_phase = None;
    let mut sample = 0_usize;
    let mut arguments = std::env::args().skip(1);
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--profile" => {
                let value = arguments
                    .next()
                    .ok_or_else(|| qualification_error("--profile requires quick or full"))?;
                profile = match value.as_str() {
                    "quick" => Profile::Quick,
                    "full" => Profile::Full,
                    _ => return Err(qualification_error("--profile requires quick or full")),
                };
            }
            "--samples" => {
                samples = arguments
                    .next()
                    .ok_or_else(|| qualification_error("--samples requires an integer"))?
                    .parse()?;
                if samples == 0 {
                    return Err(qualification_error("--samples must be positive"));
                }
            }
            "--child-case" => {
                child_case = Some(
                    arguments
                        .next()
                        .ok_or_else(|| qualification_error("--child-case requires a name"))?,
                );
            }
            "--child-phase" => {
                child_phase = Some(
                    arguments
                        .next()
                        .ok_or_else(|| qualification_error("--child-phase requires a name"))?,
                );
            }
            "--sample" => {
                sample = arguments
                    .next()
                    .ok_or_else(|| qualification_error("--sample requires an integer"))?
                    .parse()?;
            }
            "--help" | "-h" => {
                println!(
                    "cp08_observation_benchmark [--profile quick|full] [--samples N]"
                );
                std::process::exit(0);
            }
            _ => {
                return Err(qualification_error(format!(
                    "unknown qualification argument: {argument}"
                )));
            }
        }
    }
    if child_case.is_some() != child_phase.is_some() {
        return Err(qualification_error(
            "--child-case and --child-phase must be supplied together",
        ));
    }
    Ok(Arguments {
        profile,
        samples,
        child_case,
        child_phase,
        sample,
    })
}

const HEADER: &str = "case,profile,sample,phase,state_shape,diagnostics,gap,particles,ensembles,warmup,horizon,blocks,row_cap,elapsed_ns,allocator_calls,allocator_reallocations,allocator_allocated_bytes,allocator_deallocated_bytes,allocator_peak_live_delta_bytes,baseline_allocator_calls,baseline_allocator_reallocations,rss_available,rss_before_kib,rss_after_kib,rss_hwm_kib,status,response_equal,work_equal,observation_counters_available,particle_transitions,optimizer_calls,cache_misses_available,cache_misses,rng_draws_available,rng_draws,encoded_bytes_available,encoded_bytes,retained_bytes_available,retained_bytes,committed_rows,new_sparse_keys,gap_evaluations,boundary_scans,cache_hits,cache_keys,prepared_reservation_sites,prepared_capacity_units,retained_replications,retained_blocks,retained_level_rows,retained_boundary_rows,failure_code";

fn emit_record(
    case: Case,
    profile: Profile,
    sample: usize,
    record: &Record,
) -> Result<(), AnyError> {
    let mut line = String::with_capacity(768);
    macro_rules! field {
        ($value:expr) => {{
            if !line.is_empty() {
                line.push(',');
            }
            write!(line, "{}", $value)?;
        }};
    }
    let rss_available = record.rss_before.rss_kib.is_some()
        && record.rss_after.rss_kib.is_some()
        && record.rss_after.high_water_kib.is_some();
    let baseline = record.baseline_allocator.unwrap_or_default();
    let diagnostics = !matches!(record.phase, "slot_loop_off" | "full_observation_off");
    field!(case.name);
    field!(profile.name());
    field!(sample);
    field!(record.phase);
    field!(case.shape.name());
    field!(diagnostics);
    field!(case.gap);
    field!(case.particles);
    field!(record.executed_ensembles);
    field!(case.warmup);
    field!(case.horizon);
    field!(case.blocks);
    field!(case.row_cap()?);
    field!(record.elapsed_ns);
    field!(record.allocator.calls);
    field!(record.allocator.reallocations);
    field!(record.allocator.allocated_bytes);
    field!(record.allocator.deallocated_bytes);
    field!(record.allocator.peak_live_delta_bytes);
    field!(baseline.calls);
    field!(baseline.reallocations);
    field!(rss_available);
    field!(record.rss_before.rss_kib.unwrap_or(0));
    field!(record.rss_after.rss_kib.unwrap_or(0));
    field!(record.rss_after.high_water_kib.unwrap_or(0));
    field!(record.status);
    field!(option_bool(record.response_equal));
    field!(option_bool(record.work_equal));
    field!(record.observation_counters_available);
    field!(record.particle_transitions);
    field!(record.optimizer_calls);
    field!(record.cache_misses_available);
    field!(record.cache_misses);
    field!(record.rng_draws_available);
    field!(record.rng_draws);
    field!(record.encoded_bytes_available);
    field!(record.encoded_bytes);
    field!(record.retained_bytes_available);
    field!(record.retained_bytes);
    field!(record.counters.committed_rows);
    field!(record.counters.new_sparse_keys);
    field!(record.counters.gap_evaluations);
    field!(record.counters.boundary_scans);
    field!(record.counters.cache_hits);
    field!(record.counters.cache_keys);
    field!(record.counters.prepared_reservation_sites);
    field!(record.counters.prepared_capacity_units);
    field!(record.retained.replications);
    field!(record.retained.blocks);
    field!(record.retained.levels);
    field!(record.retained.boundary_rows);
    field!(record.failure_code.unwrap_or(""));
    println!("{line}");
    Ok(())
}

fn option_bool(value: Option<bool>) -> &'static str {
    match value {
        Some(true) => "true",
        Some(false) => "false",
        None => "",
    }
}

fn execute_child(arguments: &Arguments) -> Result<(), AnyError> {
    let case_name = arguments
        .child_case
        .as_deref()
        .ok_or_else(|| qualification_error("child case is absent"))?;
    let phase = arguments
        .child_phase
        .as_deref()
        .ok_or_else(|| qualification_error("child phase is absent"))?;
    let case = qualification_cases(arguments.profile)
        .into_iter()
        .find(|case| case.name == case_name)
        .ok_or_else(|| qualification_error("unknown child case"))?;
    let record = match phase {
        "equivalence" => scientific_equivalence(case)?,
        "slot_off" => slot_loop(case, false)?,
        "slot_on" => slot_loop(case, true)?,
        "slot_parity" => slot_allocation_parity(case)?,
        "full_off" => full_legacy(case)?,
        "full_on" | "cap_refusal" => full_observation(case)?,
        "ordinary" => ordinary_observation(case)?,
        _ => return Err(qualification_error("unknown child phase")),
    };
    emit_record(case, arguments.profile, arguments.sample, &record)
}

fn execute_driver(arguments: &Arguments) -> Result<(), AnyError> {
    println!("{HEADER}");
    let executable = std::env::current_exe()?;
    for case in qualification_cases(arguments.profile) {
        if matches!(case.shape, StateShape::OrdinaryShort | StateShape::OrdinaryLong) {
            warm_child(&executable, arguments.profile, case, "ordinary")?;
            for sample in 0..arguments.samples {
                run_child(
                    &executable,
                    arguments.profile,
                    case,
                    "ordinary",
                    sample,
                )?;
            }
            continue;
        }
        if case.cap_refusal {
            warm_child(&executable, arguments.profile, case, "cap_refusal")?;
            run_child(
                &executable,
                arguments.profile,
                case,
                "cap_refusal",
                0,
            )?;
            continue;
        }
        warm_child(&executable, arguments.profile, case, "equivalence")?;
        run_child(
            &executable,
            arguments.profile,
            case,
            "equivalence",
            0,
        )?;
        warm_child(&executable, arguments.profile, case, "slot_parity")?;
        run_child(
            &executable,
            arguments.profile,
            case,
            "slot_parity",
            0,
        )?;
        for phase in ["slot_off", "slot_on", "full_off", "full_on"] {
            warm_child(&executable, arguments.profile, case, phase)?;
        }
        for sample in 0..arguments.samples {
            for phase in ["slot_off", "slot_on", "full_off", "full_on"] {
                run_child(
                    &executable,
                    arguments.profile,
                    case,
                    phase,
                    sample,
                )?;
            }
        }
    }
    Ok(())
}

fn run_child(
    executable: &std::path::Path,
    profile: Profile,
    case: Case,
    phase: &str,
    sample: usize,
) -> Result<(), AnyError> {
    invoke_child(executable, profile, case, phase, sample, true)
}

fn warm_child(
    executable: &std::path::Path,
    profile: Profile,
    case: Case,
    phase: &str,
) -> Result<(), AnyError> {
    invoke_child(executable, profile, case, phase, usize::MAX, false)
}

fn invoke_child(
    executable: &std::path::Path,
    profile: Profile,
    case: Case,
    phase: &str,
    sample: usize,
    emit_stdout: bool,
) -> Result<(), AnyError> {
    let output = Command::new(executable)
        .args([
            "--profile",
            profile.name(),
            "--child-case",
            case.name,
            "--child-phase",
            phase,
            "--sample",
            &sample.to_string(),
        ])
        .output()?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(qualification_error(format!(
            "qualification child {}/{} failed: {stderr}",
            case.name, phase
        )));
    }
    if emit_stdout {
        let stdout = String::from_utf8(output.stdout)?;
        print!("{stdout}");
    }
    Ok(())
}

fn main() -> Result<(), AnyError> {
    let arguments = parse_arguments()?;
    if arguments.child_case.is_some() {
        execute_child(&arguments)
    } else {
        execute_driver(&arguments)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[ignore = "manual production qualification"]
    fn quick_production_equivalence_and_counter_gate() {
        for case in qualification_cases(Profile::Quick)
            .into_iter()
            .filter(|case| {
                !case.cap_refusal
                    && !matches!(
                        case.shape,
                        StateShape::OrdinaryShort | StateShape::OrdinaryLong
                    )
            })
        {
            let record = scientific_equivalence(case)
                .expect("production equivalence qualification must execute");
            assert_eq!(record.response_equal, Some(true));
            assert_eq!(record.work_equal, Some(true));
        }
    }

    #[test]
    #[ignore = "manual allocator qualification; use one test thread"]
    fn quick_production_slot_loop_has_no_diagnostic_allocation_delta() {
        for case in qualification_cases(Profile::Quick)
            .into_iter()
            .filter(|case| {
                !case.cap_refusal
                    && !matches!(
                        case.shape,
                        StateShape::OrdinaryShort | StateShape::OrdinaryLong
                    )
            })
        {
            let record = slot_allocation_parity(case)
                .expect("production allocation qualification must execute");
            let baseline = record
                .baseline_allocator
                .expect("allocation parity carries a baseline");
            assert_eq!(record.allocator.calls, baseline.calls);
            assert_eq!(record.allocator.reallocations, baseline.reallocations);
            assert_eq!(record.allocator.allocated_bytes, baseline.allocated_bytes);
        }
    }

    #[test]
    #[ignore = "manual cap-refusal qualification"]
    fn quick_production_cap_plus_one_refuses_without_truncation() {
        let case = qualification_cases(Profile::Quick)
            .into_iter()
            .find(|case| case.cap_refusal)
            .expect("quick matrix contains cap refusal");
        let record = full_observation(case).expect("production cap refusal must execute");
        assert_eq!(record.status, "failed");
        assert_eq!(record.failure_code, Some("construction_observation"));
        assert_eq!(record.retained.replications, 1);
        assert_eq!(record.retained.blocks, 1);
        assert_eq!(record.retained.levels, 1);
        assert_eq!(record.retained.boundary_rows, 2);
        assert!(record.counters.committed_rows > 0);
        assert_eq!(record.counters.committed_rows % case.particles as u128, 0);
        assert_eq!(record.counters.new_sparse_keys, 1);
        assert!(
            record.retained.levels + record.retained.boundary_rows
                <= case.row_cap().expect("cap case has a representable row cap")
        );

        let fixture = prepare_fixture(case.shape).expect("cap fixture prepares");
        let run = prepared_run(case, &fixture).expect("cap run prepares");
        let plan = observation_plan(case).expect("cap plan prepares");
        let identities = observation_identities(case).expect("cap identities prepare");
        let gap_probe = selected_gap_probe(case, &fixture).expect("cap probe prepares");
        let outcome = run
            .execute_finite_prefix_with_observation_v2(1, &plan, &identities, gap_probe)
            .expect("cap refusal remains in-band");
        let attempt = &outcome.attempts()[0];
        assert!(matches!(
            attempt.failure(),
            Some(orbit_core::weighted_ensemble_coordinator::EnsembleAttemptFailureV1::Observation(
                orbit_core::ConstructionObservationError::RowCapExhausted
            ))
        ));
        let observation = attempt
            .observation()
            .expect("cap refusal retains a partial sidecar");
        assert_eq!(
            observation.completeness,
            orbit_core::construction_observation::ObservationCompletenessV1::Partial
        );
        assert!(observation.committed_through_boundary > case.warmup);
        assert!(observation.committed_through_boundary < case.horizon);
        assert_eq!(observation.blocks.len(), 1);
        let block = &observation.blocks[0];
        assert_eq!(block.begin_boundary, case.warmup);
        assert_eq!(
            block.committed_through_boundary,
            observation.committed_through_boundary
        );
        assert_eq!(block.levels.len(), 1);
        assert_eq!(block.initial_boundary_law.rows.len(), 1);
        assert_eq!(block.committed_boundary_law.rows.len(), 1);
        assert_eq!(
            block.committed_boundary_law.boundary,
            observation.committed_through_boundary
        );
        assert_eq!(
            outcome.observation_work().committed_rows(),
            u128::from(observation.committed_through_boundary - case.warmup)
                * case.particles as u128
        );
        assert_eq!(outcome.observation_work().new_sparse_keys(), 1);
    }

    #[test]
    #[ignore = "manual ordinary performance qualification"]
    fn quick_production_short_and_long_ordinary_observers() {
        for case in qualification_cases(Profile::Quick).into_iter().filter(|case| {
            matches!(case.shape, StateShape::OrdinaryShort | StateShape::OrdinaryLong)
        }) {
            let record = ordinary_observation(case)
                .expect("production ordinary observation qualification must execute");
            assert_eq!(record.status, "complete");
            assert!(record.rng_draws_available);
            assert_eq!(
                record.retained.replications,
                usize::try_from(case.ensembles)
                    .expect("qualification ensemble count fits the host")
            );
        }
    }
}
