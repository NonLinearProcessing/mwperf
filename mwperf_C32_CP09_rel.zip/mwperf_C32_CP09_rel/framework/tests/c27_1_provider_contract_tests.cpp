#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/app/execution_plan.hpp"
#include "mwperf/app/resolved_request.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/cli.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"
#include "mwperf/surrogate/surrogate_id.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "surrogate/providers/full_orbit_sampler_provider.hpp"

#if defined(MWPERF_C27_1_FULL_ORBIT_PROVIDER_ENABLED)
namespace {

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c27-1-provider-contract";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] mwperf::SourceNode source_node(const std::string_view text) {
  auto document = mwperf::load_document(write_input("parameters", text));
  INFO((document ? std::string{}
                 : document.error().code + ": " + document.error().message));
  REQUIRE(document);
  return std::move(document).value().root;
}

[[nodiscard]] std::string read_fixture(const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  REQUIRE(input.is_open());
  const std::string text{std::istreambuf_iterator<char>{input},
                         std::istreambuf_iterator<char>{}};
  REQUIRE((input.good() || input.eof()));
  return text;
}

[[nodiscard]] mwperf::SurrogateProvider full_orbit_provider() {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  CHECK(provider.value().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.2.0"});
  return std::move(provider).value();
}

[[nodiscard]] mwperf::SurrogateProvider full_orbit_k_wide_provider() {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto version = mwperf::SurrogateVersion::parse("1.2.0");
  REQUIRE(version);
  auto provider = mwperf::lookup_surrogate_provider(
      id.value(), std::optional<mwperf::SurrogateVersion>{version.value()});
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  return std::move(provider).value();
}

[[nodiscard]] mwperf::SurrogateProvider full_orbit_observation_provider() {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto version = mwperf::SurrogateVersion::parse("1.3.0");
  REQUIRE(version);
  auto provider = mwperf::lookup_surrogate_provider(
      id.value(), std::optional<mwperf::SurrogateVersion>{version.value()});
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  return std::move(provider).value();
}

[[nodiscard]] mwperf::SurrogateProvider full_orbit_cp09_provider() {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto version = mwperf::SurrogateVersion::parse("1.4.0");
  REQUIRE(version);
  auto provider = mwperf::lookup_surrogate_provider(
      id.value(), std::optional<mwperf::SurrogateVersion>{version.value()});
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  return std::move(provider).value();
}

[[nodiscard]] mwperf::SourceNode valid_parameters() {
  return source_node(R"json({
    "schema_version":2,
    "warmup_slots":2,
    "horizon_slots":6,
    "replications":2,
    "population_size":4,
    "familywise_alpha":{
      "kind":"rational","numerator":"1","denominator":"20"
    },
    "response_cutoff":4
  })json");
}

[[nodiscard]] mwperf::SourceNode k_wide_parameters(
    const std::uint64_t response_cutoff = 4U,
    const std::uint64_t population_size = 4U,
    const std::uint64_t horizon_slots = 6U,
    const std::uint64_t replications = 2U,
    const std::uint64_t warmup_slots = 2U) {
  return source_node(
      "{\"schema_version\":2,\"warmup_slots\":" +
      std::to_string(warmup_slots) + ",\"horizon_slots\":" +
      std::to_string(horizon_slots) + ",\"replications\":" +
      std::to_string(replications) + ",\"population_size\":" +
      std::to_string(population_size) +
      ",\"familywise_alpha\":{\"kind\":\"rational\",\"numerator\":\"1\","
      "\"denominator\":\"20\"},\"response_cutoff\":" +
      std::to_string(response_cutoff) + "}");
}

[[nodiscard]] mwperf::SourceNode observation_parameters(
    const std::string_view gap_telemetry = "disabled",
    const bool emit_observation_record = true) {
  return source_node(
      "{\"schema_version\":3,\"warmup_slots\":2,\"horizon_slots\":6,"
      "\"replications\":2,\"population_size\":4,\"familywise_alpha\":{"
      "\"kind\":\"rational\",\"numerator\":\"1\",\"denominator\":\"20\"},"
      "\"response_cutoff\":4,\"emit_observation_record\":" +
      std::string(emit_observation_record ? "true" : "false") +
      ",\"reporting_block_boundaries\":[2,4,6],\"gap_telemetry\":\"" +
      std::string(gap_telemetry) +
      "\",\"maximum_observation_rows_per_replication\":128,"
      "\"maximum_observation_bytes\":1048576}");
}

[[nodiscard]] mwperf::SourceNode cp09_parameters(
    const std::string_view cutoffs = "[4,8,16]",
    const bool emit = true,
    const std::string_view deployment_cutoff = "null") {
  // maximum_* are retained wire-compatibility members for schema 4. They do
  // not limit, truncate, allocate, or enter CP09 experiment identity.
  return source_node(
      "{\"schema_version\":4,\"construction\":{"
      "\"warmup_slots\":0,\"horizon_slots\":400,\"replications\":16,"
      "\"population_size\":64},\"observation\":{"
      "\"emit\":" + std::string(emit ? "true" : "false") +
      ",\"reporting_block_boundaries\":[0,400],"
      "\"gap_telemetry\":\"auto\","
      "\"maximum_rows_per_replication\":25728,"
      "\"maximum_bytes\":" +
      std::to_string(mwperf::kNonScientificByteCeiling) +
      "},\"projection\":{"
      "\"mode\":\"raw_observed\",\"cutoffs\":" +
      std::string(cutoffs) + ",\"deployment_cutoff\":" +
      std::string(deployment_cutoff) +
      ",\"familywise_alpha\":{"
      "\"numerator\":\"1\",\"denominator\":\"20\"}}}");
}

[[nodiscard]] std::filesystem::path k_wide_execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c27-1-k-wide-c15-runs";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

[[nodiscard]] mwperf::ArtifactParseLimits artifact_parse_limits() {
  return {16U << 20U, 64U, 1U << 15U, 1U << 15U, 1U << 17U,
          1U << 17U, 64U << 20U};
}

[[nodiscard]] mwperf::TailResolution constant_response_tail(
    const std::uint64_t cutoff) {
  return mwperf::ConstantResponseTailResolution{
      mwperf::BigNat{cutoff},
      source_node("{\"kind\":\"constant_response\",\"parameters\":{\"cutoff\":" +
                  std::to_string(cutoff) + "}}")};
}

[[nodiscard]] std::string bytes_string(
    const std::span<const std::byte> bytes) {
  return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
}

[[nodiscard]] mwperf::TypedLabel label(const std::string& value) {
  auto result = mwperf::TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue(const std::string& value) {
  return mwperf::QueueId(label(value));
}

struct PreviewFixture final {
  mwperf::FrameworkProblemView view;
  mwperf::MetricRequirements requirements;
  mwperf::ConstructionBudget budget;
  mwperf::ResolvedInstance instance;
  mwperf::CompiledArrivalLaw compiled_arrival;
};

struct KWidePreviewFixtureConfig final {
  std::uint64_t response_cutoff;
  std::uint64_t population_size;
  std::uint64_t horizon_slots;
  std::uint64_t replications;
  std::uint64_t warmup_slots;
  std::uint64_t optimizer_max_calls;
};

void replace_fixture_token(std::string& text, const std::string_view token,
                           const std::string& replacement) {
  const auto position = text.find(token);
  REQUIRE(position != std::string::npos);
  REQUIRE(text.find(token, position + token.size()) == std::string::npos);
  text.replace(position, token.size(), replacement);
}

[[nodiscard]] PreviewFixture preview_fixture(
    const std::string_view target = "q0",
    const std::size_t source_count = 4U,
    const std::optional<KWidePreviewFixtureConfig>& k_wide = std::nullopt) {
  REQUIRE(source_count >= 4U);
  std::string model_text = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":7,"slots":6,"warmup_slots":2,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0"],
      "max_search_states":null}},
    "arrival":{"family":"independent_marked_renewal","sources":[
      {"id":"s0","interarrival":{"kind":"geometric_grid","d_min":1,
        "delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0",
        "probability":1}]},
      {"id":"s1","interarrival":{"kind":"geometric_grid","d_min":1,
        "delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0",
        "probability":1}]},
      {"id":"s2","interarrival":{"kind":"geometric_grid","d_min":1,
        "delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0",
        "probability":1}]},
      {"id":"s3","interarrival":{"kind":"geometric_grid","d_min":1,
        "delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0",
        "probability":1}]}
    ],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
      "include_packet_events":false,"include_scheduler_state":false,
      "write_slot_trace":false},
    "metadata":{}
  })json";
  const auto source_end = model_text.find("\n    ],\"metadata\":{}}");
  REQUIRE(source_end != std::string::npos);
  std::string additional_sources;
  for (std::size_t source = 4U; source < source_count; ++source) {
    additional_sources +=
        R"json(,
      {"id":"s)json" +
        std::to_string(source) +
        R"json(","interarrival":{"kind":"geometric_grid","d_min":1,
        "delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0",
        "probability":1}]})json";
  }
  model_text.insert(source_end, additional_sources);
  std::string analysis_text = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[
      {"id":"fofs.iid.pi0.v1","kind":"stationary_empty_probability","parameters":{}},
      {"id":"fofs.iid.pmf.v1","kind":"stationary_backlog_pmf","parameters":{"max_level":2}},
      {"id":"fofs.iid.tail3.v1","kind":"stationary_backlog_tail","parameters":{"threshold":3}},
      {"id":"fofs.iid.mean.v1","kind":"stationary_backlog_moment","parameters":{"order":1}},
      {"id":"fofs.iid.sojourn.v1","kind":"mean_sojourn","parameters":{}},
      {"id":"fofs.iid.bcs.v1","kind":"backlog_conditioned_service","parameters":{"levels":[0,1,2]}}
    ],
    "surrogate":__SURROGATE__,
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"constant_response","parameters":{
        "cutoff":__RESPONSE_CUTOFF__}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":__OPTIMIZER_MAX_CALLS__,
        "max_search_states_per_call":1000},
      "sampling":{"max_generator_draws":100000},
      "tolerance":{"linear_residual_abs":0.0001,
        "integration_abs":null,"tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
      "max_iterations":null}}
  })json";

  const KWidePreviewFixtureConfig config =
      k_wide.value_or(KWidePreviewFixtureConfig{2U, 4U, 6U, 2U, 2U,
                                                1000U});
  const std::uint64_t response_cutoff = config.response_cutoff;
  const std::uint64_t optimizer_max_calls = config.optimizer_max_calls;
  const std::string surrogate =
      "{\"id\":\"full_orbit_framework_sampler\",\"version\":\"1.2.0\","
      "\"parameters\":{\"schema_version\":2,\"warmup_slots\":" +
      std::to_string(config.warmup_slots) +
      ",\"horizon_slots\":" + std::to_string(config.horizon_slots) +
      ",\"replications\":" + std::to_string(config.replications) +
      ",\"population_size\":" + std::to_string(config.population_size) +
      ",\"familywise_alpha\":{\"kind\":\"rational\",\"numerator\":\"1\","
      "\"denominator\":\"20\"},\"response_cutoff\":" +
      std::to_string(config.response_cutoff) + "}}";
  replace_fixture_token(analysis_text, "__SURROGATE__", surrogate);
  replace_fixture_token(analysis_text, "__RESPONSE_CUTOFF__",
                        std::to_string(response_cutoff));
  replace_fixture_token(analysis_text, "__OPTIMIZER_MAX_CALLS__",
                        std::to_string(optimizer_max_calls));

  if (target != "q0") {
    const auto replace_all = [target](std::string& text) {
      std::size_t offset = 0U;
      while ((offset = text.find("q0", offset)) != std::string::npos) {
        text.replace(offset, 2U, target);
        offset += target.size();
      }
    };
    replace_all(model_text);
    replace_all(analysis_text);
  }

  auto model_document = mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((instance ? std::string{}
                 : instance.error().code + ": " + instance.error().message));
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);

  std::vector<mwperf::MetricRequest> requests;
  for (const auto& authored : instance.value().analysis_spec().metrics) {
    auto request =
        mwperf::parse_metric_request(authored, instance.value().queues());
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    requests.push_back(std::move(request).value());
  }
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  const mwperf::TargetSelection targets{
      1U, {queue(std::string(target))},
      mwperf::ConstructionGroupIdV1(label("c27.1.full-orbit.group"))};
  auto view = mwperf::build_framework_problem_view(
      instance.value(), *arrival.value(), targets);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);
  auto compact = mwperf::project_factorized_iid_framework_problem_view(
      view.value());
  INFO((compact ? std::string{}
                : compact.error().code + ": " + compact.error().message));
  REQUIRE(compact);
  view = std::move(compact);

  auto linear = mwperf::ExactRational::make(mwperf::BigInt{1},
                                             mwperf::BigInt{10000});
  REQUIRE(linear);
  mwperf::ConstructionBudget budget{
      1U,
      {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{1000000U}},
      {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
      {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
      {mwperf::BudgetApplicabilityV1::applicable, linear.value()},
      {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
      {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
      {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
  return {std::move(view).value(), std::move(requirements),
          std::move(budget), instance.value(), *arrival.value()};
}

[[nodiscard]] std::string large_geometry_model(const bool packing) {
  const std::size_t queue_count = packing ? 17U : 21U;
  const std::size_t resource_count = packing ? 17U : 0U;

  std::string queues;
  std::string priority;
  for (std::size_t queue_index = 0U; queue_index < queue_count;
       ++queue_index) {
    if (queue_index != 0U) {
      queues += ',';
      priority += ',';
    }
    const std::string id = "q" + std::to_string(queue_index);
    queues += "{\"id\":\"" + id + "\"}";
    priority += "\"" + id + "\"";
  }

  std::string scheduler;
  if (!packing) {
    scheduler =
        "{\"name\":\"conflict_graph_max_weight\",\"params\":{"
        "\"constraint\":{\"conflicts\":[]},"
        "\"max_search_states\":null,\"priority\":[" +
        priority + "]}}";
  } else {
    std::string resources;
    std::string capacities;
    for (std::size_t resource = 0U; resource < resource_count; ++resource) {
      if (resource != 0U) {
        resources += ',';
        capacities += ',';
      }
      resources += "\"r" + std::to_string(resource) + "\"";
      capacities += '1';
    }

    std::string demands;
    for (std::size_t queue_index = 0U; queue_index < queue_count;
         ++queue_index) {
      if (queue_index != 0U) demands += ',';
      demands += "{\"demand\":[";
      for (std::size_t resource = 0U; resource < resource_count; ++resource) {
        if (resource != 0U) demands += ',';
        demands += resource == queue_index ? '1' : '0';
      }
      demands += "],\"queue_id\":\"q" + std::to_string(queue_index) +
                 "\"}";
    }
    scheduler =
        "{\"name\":\"resource_packing_max_weight\",\"params\":{"
        "\"constraint\":{\"capacity\":[" +
        capacities + "],\"demands\":[" + demands +
        "],\"resources\":[" + resources +
        "]},\"max_search_states\":null,\"priority\":[" + priority +
        "]}}";
  }

  return
      "{\"schema_version\":\"3.0.0\","
      "\"run\":{\"seed\":17,\"slots\":8,\"warmup_slots\":0,"
      "\"termination\":\"fixed_slots\"},"
      "\"switch\":{\"kind\":\"generalized\",\"queue_capacity\":null,"
      "\"queues\":[" +
      queues + "]},\"scheduler\":" + scheduler +
      ",\"arrival\":{\"family\":\"independent_marked_renewal\","
      "\"metadata\":{},\"sources\":["
      "{\"id\":\"s0\",\"interarrival\":{\"kind\":\"geometric_grid\","
      "\"d_min\":1,\"delta\":1,\"p\":0.125},\"destination_pmf\":["
      "{\"queue_id\":\"q0\",\"probability\":1}]},"
      "{\"id\":\"s1\",\"interarrival\":{\"kind\":\"geometric_grid\","
      "\"d_min\":1,\"delta\":1,\"p\":0.125},\"destination_pmf\":["
      "{\"queue_id\":\"q0\",\"probability\":1}]},"
      "{\"id\":\"s2\",\"interarrival\":{\"kind\":\"geometric_grid\","
      "\"d_min\":1,\"delta\":1,\"p\":0.125},\"destination_pmf\":["
      "{\"queue_id\":\"q0\",\"probability\":1}]},"
      "{\"id\":\"s3\",\"interarrival\":{\"kind\":\"geometric_grid\","
      "\"d_min\":1,\"delta\":1,\"p\":0.125},\"destination_pmf\":["
      "{\"queue_id\":\"q0\",\"probability\":1}]}]},"
      "\"telemetry\":{\"format\":\"jsonl\","
      "\"queue_snapshot\":\"disabled\",\"include_packet_events\":false,"
      "\"include_scheduler_state\":false,\"write_slot_trace\":false},"
      "\"metadata\":{}}";
}

void require_large_geometry_plan(const bool packing) {
  const auto model_path =
      write_input(packing ? "packing-large-geometry" :
                            "conflict-large-geometry",
                  large_geometry_model(packing));
  const auto output_path = model_path.parent_path() /
                           (packing ? "packing-large-result.json" :
                                      "conflict-large-result.json");
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {},
      .output_path = {output_path.string(), output_path},
      .target_queue = std::string("q0"),
  }};
  auto resolved = mwperf::load_and_resolve_request(request);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " +
                       resolved.error().message));
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  auto valid = mwperf::validate_execution_plan(plan.value());
  INFO((valid ? std::string{}
              : valid.error().code + ": " + valid.error().message));
  REQUIRE(valid);
}

[[nodiscard]] std::set<mwperf::MetricKindV1> metric_kinds(
    const mwperf::MetricSupportManifest& manifest) {
  std::set<mwperf::MetricKindV1> result;
  for (const auto& clause : manifest.clauses()) {
    result.insert(clause.metric_kind);
  }
  return result;
}

}  // namespace

TEST_CASE("C27.1 Full Orbit manifest freezes the production contract",
          "[c27_1][contract]") {
  const auto provider = full_orbit_provider();
  const auto& validated = provider.manifest();
  const auto& manifest = validated.value();

  CHECK(manifest.manifest_schema_version == 1U);
  CHECK(manifest.provider == mwperf::ProviderIdentityV1{
                                 "full_orbit_framework_sampler", "1.2.0"});
  CHECK(manifest.default_selection);
  CHECK(manifest.construction_method ==
        mwperf::ConstructionMethodV1::sampled_offline);
  CHECK(manifest.producer_mode ==
        mwperf::ProducerModeV1::local_executable_builder);
  CHECK(manifest.deployed_semantic_tag ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(manifest.runtime_access_tag ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  CHECK(manifest.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                finite_prefix_constant_tail_response_v1,
            1U});
  CHECK(manifest.parameter_schema_version == 2U);
  CHECK(manifest.parameter_schema_digest.hex() ==
        "6f013e3ce85414bddb975ba208b250a79803e780fbab913c7d6091e6640c0fc3");
  CHECK(manifest.supported_build_request_versions ==
        std::vector<std::uint32_t>{1U});
  CHECK(manifest.supported_artifact_versions ==
        std::vector<std::uint32_t>{1U});
  CHECK(manifest.required_build_report_schema_versions ==
        std::vector<std::uint32_t>{1U});

  const std::vector<mwperf::SchedulerConstraintPairV1> expected_pairs{
      {mwperf::ServiceFamily::crossbar_matching,
       mwperf::OptimizerId::hungarian_exact},
      {mwperf::ServiceFamily::nonoverlapping_intervals,
       mwperf::OptimizerId::weighted_interval_dp_exact},
      {mwperf::ServiceFamily::node_exclusive_matching,
       mwperf::OptimizerId::edmonds_blossom_exact},
      {mwperf::ServiceFamily::pairwise_conflicts,
       mwperf::OptimizerId::mwis_branch_memo_exact},
      {mwperf::ServiceFamily::resource_packing,
       mwperf::OptimizerId::binary_packing_memo_exact}};
  CHECK(manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs ==
        expected_pairs);
  CHECK(std::find(
            manifest.optimizer_constraint_applicability
                .scheduler_optimizer_pairs.begin(),
            manifest.optimizer_constraint_applicability
                .scheduler_optimizer_pairs.end(),
            mwperf::SchedulerConstraintPairV1{
                mwperf::ServiceFamily::pairwise_conflicts,
                mwperf::OptimizerId::hungarian_exact}) ==
        manifest.optimizer_constraint_applicability
            .scheduler_optimizer_pairs.end());
  CHECK(manifest.optimizer_constraint_applicability.timing_conventions ==
        std::vector<mwperf::TimingConvention>{
            mwperf::TimingConvention::early_service_late_admission});
  CHECK(manifest.target_and_arrival_scientific_prerequisites
            .minimum_deployed_targets == 1U);
  CHECK(manifest.target_and_arrival_scientific_prerequisites
            .maximum_deployed_targets == 1U);
  CHECK(manifest.target_and_arrival_scientific_prerequisites
            .permitted_target_couplings ==
        std::vector<mwperf::TargetCouplingV1>{
            mwperf::TargetCouplingV1::scalar_target});

  const auto expected_metrics = std::set<mwperf::MetricKindV1>{
      mwperf::MetricKindV1::stationary_empty_probability,
      mwperf::MetricKindV1::stationary_backlog_pmf,
      mwperf::MetricKindV1::stationary_backlog_tail,
      mwperf::MetricKindV1::stationary_backlog_moment,
      mwperf::MetricKindV1::mean_sojourn,
      mwperf::MetricKindV1::backlog_conditioned_service};
  CHECK(manifest.metric_clause_upper_envelope.clauses().size() == 6U);
  CHECK(manifest.metric_clause_upper_envelope.canonical_digest().hex() ==
        "6ce5d3524e5ff83fa4e36512b9fb74d5ca0aa4a607f13ac16b7849928de7d08f");
  CHECK(metric_kinds(manifest.metric_clause_upper_envelope) ==
        expected_metrics);

  const auto expected_domain_size = [](const mwperf::MetricKindV1 kind) {
    switch (kind) {
      case mwperf::MetricKindV1::stationary_backlog_pmf:
        return std::size_t{3U};
      case mwperf::MetricKindV1::backlog_conditioned_service:
        return std::size_t{7U};
      case mwperf::MetricKindV1::stationary_empty_probability:
      case mwperf::MetricKindV1::stationary_backlog_tail:
      case mwperf::MetricKindV1::stationary_backlog_moment:
      case mwperf::MetricKindV1::mean_sojourn:
        return std::size_t{1U};
      default:
        return std::size_t{0U};
    }
  };

  const std::set<mwperf::MetricSupportRoleV1> expected_roles{
      mwperf::MetricSupportRoleV1::deployed_payload,
      mwperf::MetricSupportRoleV1::deployed_response,
      mwperf::MetricSupportRoleV1::raw_response,
      mwperf::MetricSupportRoleV1::raw_response_bound_evidence,
      mwperf::MetricSupportRoleV1::statistical_evidence};
  CHECK(std::set<mwperf::MetricSupportRoleV1>(
            manifest.allowed_metric_support_roles.begin(),
            manifest.allowed_metric_support_roles.end()) == expected_roles);
  for (const auto& clause : manifest.metric_clause_upper_envelope.clauses()) {
    const auto* exact =
        std::get_if<mwperf::ExactMetricParameterSetV1>(
            &clause.parameter_domain);
    REQUIRE(exact != nullptr);
    CHECK(exact->values.size() == expected_domain_size(clause.metric_kind));
    std::set<mwperf::MetricSupportRoleV1> roles;
    for (const auto& requirement : clause.required_roles) {
      roles.insert(requirement.role);
    }
    CHECK(roles == expected_roles);
  }

  auto digest = mwperf::digest_provider_manifest_v1(manifest);
  REQUIRE(digest);
  CHECK(digest.value() == manifest.manifest_digest);
  CHECK(manifest.manifest_digest.hex() ==
        "1c19fa77ce2744e92ccf220999cd0406e8a7ffac42e7769bfe5becd42a370658");
  auto scientific = mwperf::digest_provider_scientific_contract_v1(
      validated.scientific_projection());
  REQUIRE(scientific);
  CHECK(scientific.value() == validated.scientific_contract_digest());
  CHECK(validated.scientific_contract_digest().value().hex() ==
        "a0cc1201e8009827b0ce5b0b14a3ba20ee62629569ac5fe97622d3bfb47bc157");

  auto registration =
      mwperf::detail::full_orbit_sampler_k_wide_provider_registration();
  REQUIRE(registration);
  CHECK(registration.value().manifest == manifest);
  CHECK(static_cast<bool>(registration.value().parameter_validator));
  CHECK(static_cast<bool>(registration.value().previewer));
  CHECK(static_cast<bool>(registration.value().materializer));
  CHECK(std::holds_alternative<mwperf::LocalExecutableBuilderV1>(
      registration.value().producer));
  CHECK_FALSE(registration.value().framework_activation.has_value());
}

TEST_CASE("C29 K-wide hosted route is the registered production route",
          "[c27_1][contract]") {
  auto route = mwperf::detail::full_orbit_sampler_k_wide_hosted_route();
  REQUIRE(route);
  CHECK(route.value().provider ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.2.0"});
  CHECK(route.value().parameter_schema_version == 2U);
  CHECK(route.value().parameter_schema_digest.hex() ==
        "6f013e3ce85414bddb975ba208b250a79803e780fbab913c7d6091e6640c0fc3");
  CHECK(route.value().hosted_route_binding_digest.hex() ==
        "c01842f5aeb40a5513783d157e11c111e4d5e72a68651191f7fe79a54383df66");
  CHECK(route.value().proposed_payload_tag ==
        "finite_prefix_constant_tail_response_v1");
  CHECK(route.value().proposed_payload_version == 1U);
  CHECK(route.value().native_result_tag ==
        "full_orbit_cp07_1_finite_prefix_transport_v1");
  CHECK(route.value().executable_id == "fofs.cp06.c27.local");
  CHECK(route.value().request_protocol_version == 1U);
  CHECK(route.value().result_protocol_version == 1U);
  CHECK_FALSE(route.value().production_registration_deferred);

  auto version = mwperf::SurrogateVersion::parse("1.2.0");
  REQUIRE(version);
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto registered = mwperf::lookup_surrogate_provider(
      id.value(),
      std::optional<mwperf::SurrogateVersion>{version.value()});
  INFO((registered ? std::string{}
                   : registered.error().code + ": " +
                         registered.error().message));
  REQUIRE(registered);
  CHECK(registered.value().identity() == route.value().provider);
  const auto& manifest = registered.value().manifest().value();
  CHECK(manifest.default_selection);
  CHECK(manifest.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                finite_prefix_constant_tail_response_v1,
            1U});
  CHECK(manifest.manifest_digest.hex() ==
        "1c19fa77ce2744e92ccf220999cd0406e8a7ffac42e7769bfe5becd42a370658");
  CHECK(manifest.metric_clause_upper_envelope.canonical_digest().hex() ==
        "6ce5d3524e5ff83fa4e36512b9fb74d5ca0aa4a607f13ac16b7849928de7d08f");
  CHECK(registered.value()
            .manifest()
            .scientific_contract_digest()
            .value()
            .hex() ==
        "a0cc1201e8009827b0ce5b0b14a3ba20ee62629569ac5fe97622d3bfb47bc157");
}

TEST_CASE("C30 observation route is additive and result-v2 bound",
          "[c27_1][c30][contract]") {
  const auto legacy = full_orbit_provider();
  CHECK(legacy.identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.2.0"});
  CHECK(legacy.is_default());
  CHECK(legacy.result_protocol_version() == 1U);

  auto route = mwperf::detail::full_orbit_sampler_observation_hosted_route();
  REQUIRE(route);
  CHECK(route.value().provider ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.3.0"});
  CHECK(route.value().parameter_schema_version == 3U);
  CHECK(route.value().parameter_schema_digest.hex() ==
        "2aa621821b52b40389e3095d5d9009db1cfcf68869e7ed1857b05e1eaf381863");
  CHECK(route.value().hosted_route_binding_digest.hex() ==
        "e5312cc6c783eeaf1f473ddab4ca94c22c8ce9b935034aae88749349ec1ee515");
  CHECK(route.value().native_result_tag ==
        "full_orbit_cp07_1_finite_prefix_transport_v2");
  CHECK(route.value().request_protocol_version == 1U);
  CHECK(route.value().result_protocol_version == 2U);
  CHECK(route.value().maximum_observation_bytes == 24U * 1024U * 1024U);
  CHECK_FALSE(route.value().production_registration_deferred);

  const auto provider = full_orbit_observation_provider();
  CHECK(provider.identity() == route.value().provider);
  CHECK_FALSE(provider.is_default());
  CHECK(provider.result_protocol_version() == 2U);
  CHECK(provider.manifest().value().parameter_schema_version == 3U);
  CHECK(provider.manifest().value().parameter_schema_digest ==
        route.value().parameter_schema_digest);
  CHECK(provider.manifest().value().manifest_digest.hex() ==
        "4f8fe7a1d430f9892b3fba5c6b8c569be47b14cfd6feb760da466046b3214f22");
  CHECK(provider.manifest().scientific_contract_digest().value().hex() ==
        "7a3014e9944f09118e48f549335f3bcdc23f2958f8259af37736c08306999c14");

  auto registration =
      mwperf::detail::full_orbit_sampler_observation_provider_registration();
  REQUIRE(registration);
  CHECK(registration.value().result_protocol_version == 2U);
  REQUIRE(registration.value().observation_envelope_validator);
  CHECK(static_cast<bool>(
      *registration.value().observation_envelope_validator));
}

TEST_CASE("C32 CP09 route is observation-only, schema-4 and arbitrary-K",
          "[c32][cp09][contract][integration]") {
  auto route = mwperf::detail::full_orbit_sampler_cp09_hosted_route();
  REQUIRE(route);
  CHECK(route.value().provider ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.4.0"});
  CHECK(route.value().parameter_schema_version == 4U);
  CHECK(route.value().parameter_schema_digest.hex() ==
        "2774ae06fb01177a3ad0d04974f0c6fcdc8e88ab632a3a3ee44bd31d3aa1f087");
  CHECK(route.value().hosted_route_binding_digest.hex() ==
        "c7533309415daa5d05fc2c26752198856e7d240fa608368c21d6587ec7e43be0");
  CHECK(route.value().empirical_profile_tag ==
        "empirical_finite_window_response_v1");
  CHECK(route.value().native_result_tag ==
        "full_orbit_cp09_observation_transport_v3");
  CHECK(route.value().request_protocol_version == 1U);
  CHECK(route.value().result_protocol_version == 3U);
  CHECK(route.value().maximum_observation_bytes ==
        mwperf::kNonScientificByteCeiling);
  CHECK_FALSE(route.value().production_registration_deferred);

  const auto provider = full_orbit_cp09_provider();
  CHECK_FALSE(provider.is_default());
  CHECK(provider.result_protocol_version() == 3U);
  const auto& validated_manifest = provider.manifest();
  const auto& manifest = validated_manifest.value();
  CHECK(manifest.parameter_schema_version == 4U);
  CHECK(manifest.parameter_schema_digest ==
        route.value().parameter_schema_digest);
  CHECK(manifest.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                empirical_finite_window_response_v1,
            1U});
  auto resealed_manifest = mwperf::digest_provider_manifest_v1(manifest);
  REQUIRE(resealed_manifest);
  CHECK(manifest.manifest_digest == resealed_manifest.value());
  CHECK(manifest.transport_limits.maximum_request_bytes ==
        mwperf::kNonScientificByteCeiling);
  CHECK(manifest.transport_limits.maximum_result_bytes ==
        mwperf::kNonScientificByteCeiling);
  CHECK(validated_manifest.scientific_contract_digest().value().hex() ==
        "fdb96d64420c33f7348c60e9d2ab86602d926e38bb0d6bd8c66e2a642def0e32");
  CHECK(manifest.metric_clause_upper_envelope.canonical_digest().hex() ==
        "cf2471b2ce580ab6a7b4e8b418612689c1c0417354d266d9f02a01bd85db8305");
  CHECK(std::all_of(
      manifest.metric_clause_upper_envelope.clauses().begin(),
      manifest.metric_clause_upper_envelope.clauses().end(),
      [](const mwperf::MetricSupportClauseV1& clause) {
        return clause.payload_class == mwperf::PayloadClassV1{
                   mwperf::PayloadClassTagV1::
                       empirical_finite_window_response_v1,
                   1U};
      }));
  CHECK(manifest.allowed_metric_support_roles ==
        std::vector<mwperf::MetricSupportRoleV1>{
            mwperf::MetricSupportRoleV1::raw_response_bound_evidence,
            mwperf::MetricSupportRoleV1::statistical_evidence,
            mwperf::MetricSupportRoleV1::compression_evidence});
  CHECK(manifest.scientific_construction_policy_schema.point_deployment ==
        std::vector<mwperf::PointDeploymentPolicyV1>{
            mwperf::PointDeploymentPolicyV1::not_applicable});

  auto registration =
      mwperf::detail::full_orbit_sampler_cp09_provider_registration();
  REQUIRE(registration);
  CHECK(registration.value().result_protocol_version == 3U);
  REQUIRE(registration.value().observation_envelope_validator);
  CHECK(static_cast<bool>(
      *registration.value().observation_envelope_validator));

  constexpr std::string_view kUnboundedScientificCutoff =
      "340282366920938463463374607431768211456";
  auto parameters = mwperf::validate_surrogate_parameters(
      provider, cp09_parameters(
                    "[0,16,340282366920938463463374607431768211456]"));
  INFO((parameters ? std::string{}
                   : parameters.error().code + ": " +
                         parameters.error().message));
  REQUIRE(parameters);
  CHECK(bytes_string(parameters.value().canonical_value_bytes()).find(
            kUnboundedScientificCutoff) != std::string::npos);
  auto analysis = mwperf::detail::full_orbit_cp09_analysis_parameters(
      parameters.value());
  REQUIRE(analysis);
  CHECK(analysis.value().warmup_slots == mwperf::BigNat{0U});
  CHECK(analysis.value().horizon_slots == mwperf::BigNat{400U});
  CHECK(analysis.value().replications == mwperf::BigNat{16U});
  CHECK(analysis.value().population_size == mwperf::BigNat{64U});
  CHECK(analysis.value().gap_telemetry_requested);
  REQUIRE(analysis.value().projection_cutoffs.size() == 3U);
  CHECK(analysis.value().projection_cutoffs.back().to_decimal_string() ==
        kUnboundedScientificCutoff);

  // Exercise the complete C15 request path.  The CP09 cutoff is a sparse
  // mathematical coordinate and must remain an exact JSON integer even when
  // it exceeds every native integer type used by the JSON DOM.
  auto fixture = preview_fixture();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  const auto decision = mwperf::negotiate_capabilities(
      fixture.requirements, preview.value(),
      fixture.view.configured_arrival().capabilities());
  const auto* contract = mwperf::accepted_capability_contract(decision);
  REQUIRE(contract != nullptr);
  auto request = mwperf::make_surrogate_build_request(
      provider.manifest(), fixture.view, *contract, parameters.value(),
      fixture.budget, mwperf::MasterSeed{203'882'758U});
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  auto request_bytes =
      mwperf::canonical_surrogate_build_request_bytes_v1(request.value());
  INFO((request_bytes
            ? std::string{}
            : request_bytes.error().code + ": " +
                  request_bytes.error().message));
  REQUIRE(request_bytes);
  const std::string canonical_request = bytes_string(request_bytes.value());
  CHECK(canonical_request.find(kUnboundedScientificCutoff) !=
        std::string::npos);
  CHECK(canonical_request.find(
            "\"proposed_payload_tag\":"
            "\"empirical_finite_window_response_v1\"") !=
        std::string::npos);
  CHECK(canonical_request.find("3.4028236692093846e+38") ==
        std::string::npos);

  const auto cutoff_array = [](const std::size_t count) {
    std::string result{"["};
    for (std::size_t index = 0U; index < count; ++index) {
      if (index != 0U) result.push_back(',');
      result += std::to_string(index);
    }
    result.push_back(']');
    return result;
  };
  auto practical_projection = mwperf::validate_surrogate_parameters(
      provider, cp09_parameters(cutoff_array(16U)));
  REQUIRE(practical_projection);
  auto practical_preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      practical_projection.value());
  INFO((practical_preview
            ? std::string{}
            : practical_preview.error().code + ": " +
                  practical_preview.error().message));
  REQUIRE(practical_preview);

  auto projection_heavy = mwperf::validate_surrogate_parameters(
      provider, cp09_parameters(cutoff_array(82U)));
  REQUIRE(projection_heavy);
  auto projection_preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      projection_heavy.value());
  INFO((projection_preview
            ? std::string{}
            : projection_preview.error().code + ": " +
                  projection_preview.error().message));
  REQUIRE(projection_preview);

  CHECK_FALSE(mwperf::detail::validate_full_orbit_cp09_parameters(
      cp09_parameters("[4,4]")));
  CHECK_FALSE(mwperf::detail::validate_full_orbit_cp09_parameters(
      cp09_parameters("[4,8,16]", false)));
  CHECK_FALSE(mwperf::detail::validate_full_orbit_cp09_parameters(
      cp09_parameters("[4,8,16]", true, "16")));

  CHECK_FALSE(
      mwperf::detail::validate_full_orbit_observation_terminal_replication_policy(
          mwperf::ProviderResultKindV2::observed, mwperf::BigNat{16U},
          15U, true));
  CHECK(
      mwperf::detail::validate_full_orbit_observation_terminal_replication_policy(
          mwperf::ProviderResultKindV2::observed, mwperf::BigNat{16U},
          16U, true));
}

TEST_CASE("C32 CP09 analytic Poisson request plans framework prediction input",
          "[c27_1][c32][cp09][integration]") {
  const auto fixture_root =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
      "fixtures" / "c32";
  const auto model_path =
      fixture_root / "full_orbit_model_poisson_tiny.json";
  const auto analysis_path =
      fixture_root / "full_orbit_analysis_raw_v3_tiny.json";
  const auto output_path =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c32-cp09-poisson-observed-result.json";
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {analysis_path.string(), analysis_path},
      .output_path = {output_path.string(), output_path},
      .worker_count = 2U,
      .result_version = mwperf::ResultVersionSelectionV1::v3,
  }};

  auto resolved = mwperf::load_and_resolve_request(request);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " +
                       resolved.error().message));
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  auto valid_plan = mwperf::validate_execution_plan(plan.value());
  INFO((valid_plan ? std::string{}
                   : valid_plan.error().code + ": " +
                         valid_plan.error().message));
  REQUIRE(valid_plan);

  CHECK(plan.value().provider().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.4.0"});
  CHECK(plan.value().provider().result_protocol_version() == 3U);
  CHECK(plan.value().preview().core.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                empirical_finite_window_response_v1,
            1U});
  CHECK(plan.value().solver_regime() ==
        mwperf::MetricSolverRegimeV1::analytic);
  CHECK(plan.value().metric_plans().size() == 6U);

  SECTION("zero-solve gap telemetry retains an authored physical call cap") {
    std::string analysis_text = read_fixture(analysis_path);
    replace_fixture_token(analysis_text, "\"max_calls\": 1000000",
                          "\"max_calls\": 256");
    const auto capped_analysis_path =
        write_input("c32-cp09-physical-only-cap", analysis_text);
    const auto capped_output_path =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
        "c32-cp09-budget-floor-result.json";
    const mwperf::CliRequest capped_request{mwperf::Analyze{
        .model_path = {model_path.string(), model_path},
        .analysis_path =
            {capped_analysis_path.string(), capped_analysis_path},
        .output_path = {capped_output_path.string(), capped_output_path},
        .worker_count = 2U,
        .result_version = mwperf::ResultVersionSelectionV1::v3,
    }};
    auto capped_resolved = mwperf::load_and_resolve_request(capped_request);
    INFO((capped_resolved
              ? std::string{}
              : capped_resolved.error().code + ": " +
                    capped_resolved.error().message));
    REQUIRE(capped_resolved);
    auto capped_plan = mwperf::build_execution_plan(capped_resolved.value());
    INFO((capped_plan ? std::string{}
                      : capped_plan.error().code + ": " +
                            capped_plan.error().message));
    REQUIRE(capped_plan);
    REQUIRE(mwperf::validate_execution_plan(capped_plan.value()));
    const mwperf::BigNat physical_calls{256U};
    REQUIRE(capped_plan.value()
                .resolved_instance()
                .optimizer_budget()
                .max_calls);
    CHECK(*capped_plan.value()
               .resolved_instance()
               .optimizer_budget()
               .max_calls == physical_calls);
    REQUIRE(capped_plan.value()
                .construction_budget()
                .exact_optimizer_calls.amount);
    CHECK(*capped_plan.value()
               .construction_budget()
               .exact_optimizer_calls.amount == physical_calls);
    REQUIRE(capped_plan.value().work_bounds().optimizer_calls);
    CHECK(*capped_plan.value().work_bounds().optimizer_calls ==
          physical_calls);

    const mwperf::AnalysisBundle capped_bundle =
        mwperf::execute_analysis(capped_plan.value());
    INFO((capped_bundle.failure().has_value()
              ? capped_bundle.failure()->code
              : std::string{}));
    CHECK(capped_bundle.status() == mwperf::ResultStatusV1::success);
    CHECK_FALSE(capped_bundle.failure().has_value());
    CHECK(capped_bundle.optimizer_calls_observed() <= physical_calls);
  }

  SECTION("generic opposite-face gaps cannot enlarge an authored hard cap") {
    std::string model_text = read_fixture(model_path);
    replace_fixture_token(model_text,
                          "\"name\": \"conflict_graph_max_weight\"",
                          "\"name\": \"resource_packing_max_weight\"");
    replace_fixture_token(
        model_text, "\"constraint\": {\"conflicts\": []}",
        "\"constraint\": {\"capacity\": [1], \"demands\": "
        "[{\"demand\": [1], \"queue_id\": \"q0\"}], "
        "\"resources\": [\"r0\"]}");
    const auto generic_model_path =
        write_input("c32-cp09-generic-gap-model", model_text);
    std::string analysis_text = read_fixture(analysis_path);
    replace_fixture_token(analysis_text, "\"max_calls\": 1000000",
                          "\"max_calls\": 256");
    const auto capped_analysis_path =
        write_input("c32-cp09-generic-gap-cap", analysis_text);
    const auto capped_output_path =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
        "c32-cp09-generic-gap-cap-result.json";
    const mwperf::CliRequest capped_request{mwperf::Analyze{
        .model_path = {generic_model_path.string(), generic_model_path},
        .analysis_path =
            {capped_analysis_path.string(), capped_analysis_path},
        .output_path = {capped_output_path.string(), capped_output_path},
        .worker_count = 2U,
        .result_version = mwperf::ResultVersionSelectionV1::v3,
    }};
    auto capped_resolved = mwperf::load_and_resolve_request(capped_request);
    INFO((capped_resolved
              ? std::string{}
              : capped_resolved.error().code + ": " +
                    capped_resolved.error().message));
    REQUIRE(capped_resolved);
    auto capped_plan = mwperf::build_execution_plan(capped_resolved.value());
    REQUIRE_FALSE(capped_plan);
    CHECK(capped_plan.error().category ==
          mwperf::DiagnosticCategory::input_validation);
    CHECK(capped_plan.error().code ==
          "c32.full_orbit_cp09_insufficient_grant");
  }

  SECTION("uncapped CP09 derives and executes a conservative finite grant") {
    std::string analysis_text = read_fixture(analysis_path);
    replace_fixture_token(analysis_text, "\"max_calls\": 1000000",
                          "\"max_calls\": null");
    const auto uncapped_analysis_path =
        write_input("c32-cp09-derived-call-grant", analysis_text);
    const auto uncapped_output_path =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
        "c32-cp09-derived-call-grant-result.json";
    const mwperf::CliRequest uncapped_request{mwperf::Analyze{
        .model_path = {model_path.string(), model_path},
        .analysis_path =
            {uncapped_analysis_path.string(), uncapped_analysis_path},
        .output_path = {uncapped_output_path.string(), uncapped_output_path},
        .worker_count = 2U,
        .result_version = mwperf::ResultVersionSelectionV1::v3,
    }};
    auto uncapped_resolved = mwperf::load_and_resolve_request(uncapped_request);
    INFO((uncapped_resolved
              ? std::string{}
              : uncapped_resolved.error().code + ": " +
                    uncapped_resolved.error().message));
    REQUIRE(uncapped_resolved);
    auto uncapped_plan =
        mwperf::build_execution_plan(uncapped_resolved.value());
    INFO((uncapped_plan ? std::string{}
                        : uncapped_plan.error().code + ": " +
                              uncapped_plan.error().message));
    REQUIRE(uncapped_plan);
    REQUIRE(mwperf::validate_execution_plan(uncapped_plan.value()));

    // R=2, P=8, T=16, W=0. Physical sampling costs RPT=256 and the
    // conservative exact generic-gap allowance is RP(T-W)=256 more.
    const mwperf::BigNat expected_calls{512U};
    CHECK(uncapped_plan.value()
              .construction_budget()
              .exact_optimizer_calls.applicability ==
          mwperf::BudgetApplicabilityV1::applicable);
    REQUIRE(uncapped_plan.value()
                .construction_budget()
                .exact_optimizer_calls.amount);
    CHECK(*uncapped_plan.value()
               .construction_budget()
               .exact_optimizer_calls.amount == expected_calls);
    REQUIRE(uncapped_plan.value().work_bounds().optimizer_calls);
    CHECK(*uncapped_plan.value().work_bounds().optimizer_calls ==
          expected_calls);

    const mwperf::AnalysisBundle uncapped_bundle =
        mwperf::execute_analysis(uncapped_plan.value());
    INFO((uncapped_bundle.failure().has_value()
              ? uncapped_bundle.failure()->code
              : std::string{}));
    CHECK(uncapped_bundle.status() == mwperf::ResultStatusV1::success);
    CHECK_FALSE(uncapped_bundle.failure().has_value());
    CHECK(uncapped_bundle.optimizer_calls_observed() <= expected_calls);
  }
}

TEST_CASE(
    "C30 observation arrival context keeps law and compact-view identities distinct",
    "[c27_1][c30][contract][arrival]") {
  auto fixture = preview_fixture(
      "q0", 4U, KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 48U});
  const auto& authenticated_arrival =
      fixture.view.configured_arrival();
  const auto& compiled_binding =
      mwperf::arrival_law_binding(fixture.compiled_arrival);

  CHECK(authenticated_arrival.digest().value() ==
        fixture.view.fingerprints().compiled_arrival);
  CHECK(compiled_binding == authenticated_arrival.binding());
  CHECK(compiled_binding.law_digest.value() !=
        fixture.view.fingerprints().compiled_arrival);

  auto accepted =
      mwperf::detail::validate_full_orbit_observation_arrival_context(
          fixture.view, fixture.instance, fixture.compiled_arrival);
  INFO((accepted ? std::string{}
                 : accepted.error().code + ": " +
                       accepted.error().message));
  REQUIRE(accepted);

  SECTION("a foreign law on the same queue catalog is rejected") {
    auto foreign = preview_fixture(
        "q0", 5U,
        KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 48U});
    auto rejected =
        mwperf::detail::validate_full_orbit_observation_arrival_context(
            fixture.view, foreign.instance, foreign.compiled_arrival);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.full_orbit_observation_arrival_context");
  }

  SECTION("a foreign queue catalog is rejected") {
    auto foreign = preview_fixture(
        "hub", 4U,
        KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 48U});
    auto rejected =
        mwperf::detail::validate_full_orbit_observation_arrival_context(
            fixture.view, foreign.instance, foreign.compiled_arrival);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.full_orbit_observation_arrival_context");
  }
}

TEST_CASE("C29 K-wide manifest advertises exactly the retained metric domains",
          "[c27_1][contract]") {
  const auto provider = full_orbit_provider();
  const auto& k_wide = provider.manifest()
                           .value()
                           .metric_clause_upper_envelope;

  const std::set<mwperf::MetricKindV1> expected_kinds{
      mwperf::MetricKindV1::stationary_empty_probability,
      mwperf::MetricKindV1::stationary_backlog_pmf,
      mwperf::MetricKindV1::stationary_backlog_tail,
      mwperf::MetricKindV1::stationary_backlog_moment,
      mwperf::MetricKindV1::mean_sojourn,
      mwperf::MetricKindV1::backlog_conditioned_service};
  REQUIRE(k_wide.clauses().size() == expected_kinds.size());
  CHECK(metric_kinds(k_wide) == expected_kinds);

  const std::vector<std::pair<
      mwperf::MetricKindV1, std::vector<mwperf::MetricRequestParametersV1>>>
      expected_domains{
          {mwperf::MetricKindV1::stationary_empty_probability,
           {mwperf::StationaryEmptyProbabilityParametersV1{}}},
          {mwperf::MetricKindV1::stationary_backlog_pmf,
           {mwperf::StationaryBacklogPmfParametersV1{
                mwperf::PmfThroughLevelV1{mwperf::BigNat{0U}}},
            mwperf::StationaryBacklogPmfParametersV1{
                mwperf::PmfThroughLevelV1{mwperf::BigNat{1U}}},
            mwperf::StationaryBacklogPmfParametersV1{
                mwperf::PmfThroughLevelV1{mwperf::BigNat{2U}}}}},
          {mwperf::MetricKindV1::stationary_backlog_tail,
           {mwperf::StationaryBacklogTailParametersV1{mwperf::BigNat{3U}}}},
          {mwperf::MetricKindV1::stationary_backlog_moment,
           {mwperf::StationaryBacklogMomentParametersV1{mwperf::BigNat{1U}}}},
          {mwperf::MetricKindV1::mean_sojourn,
           {mwperf::MeanSojournParametersV1{}}},
          {mwperf::MetricKindV1::backlog_conditioned_service,
           {mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{0U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{1U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{2U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{0U}, mwperf::BigNat{1U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{0U}, mwperf::BigNat{2U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{1U}, mwperf::BigNat{2U}}},
            mwperf::BacklogConditionedServiceParametersV1{
                {mwperf::BigNat{0U}, mwperf::BigNat{1U},
                 mwperf::BigNat{2U}}}}}};
  for (const auto& [kind, expected] : expected_domains) {
    const auto clause = std::find_if(
        k_wide.clauses().begin(), k_wide.clauses().end(),
        [kind](const mwperf::MetricSupportClauseV1& candidate) {
          return candidate.metric_kind == kind;
        });
    REQUIRE(clause != k_wide.clauses().end());
    const auto* domain =
        std::get_if<mwperf::ExactMetricParameterSetV1>(
            &clause->parameter_domain);
    REQUIRE(domain != nullptr);
    CHECK(domain->values == expected);
  }
}

TEST_CASE("C27.11 K-wide parameters are closed canonical and bounded",
          "[c27_1][contract]") {
  auto canonical = mwperf::detail::validate_full_orbit_k_wide_parameters(
      k_wide_parameters());
  REQUIRE(canonical);
  CHECK(bytes_string(canonical.value().canonical_bytes) ==
        "{\"schema_version\":2,\"warmup_slots\":2,\"horizon_slots\":6,"
        "\"replications\":2,\"population_size\":4,\"familywise_alpha\":{"
        "\"kind\":\"rational\",\"numerator\":\"1\",\"denominator\":\"20\"},"
        "\"response_cutoff\":4}");

  auto reordered = mwperf::detail::validate_full_orbit_k_wide_parameters(
      source_node(R"json({
        "response_cutoff":4,
        "familywise_alpha":{"denominator":"20","numerator":"1",
          "kind":"rational"},
        "population_size":4,"replications":2,"horizon_slots":6,
        "warmup_slots":2,"schema_version":2
      })json"));
  REQUIRE(reordered);
  CHECK(reordered.value().canonical_bytes == canonical.value().canonical_bytes);

  for (const auto text : {
           R"json({"schema_version":2,"warmup_slots":2,"horizon_slots":6,"replications":2,"population_size":0,"familywise_alpha":{"kind":"rational","numerator":"1","denominator":"20"},"response_cutoff":4})json",
           R"json({"schema_version":2,"warmup_slots":2,"horizon_slots":6,"replications":2,"population_size":4,"familywise_alpha":{"kind":"rational","numerator":"1","denominator":"20"},"response_cutoff":1})json",
           R"json({"schema_version":2,"warmup_slots":2,"horizon_slots":6,"replications":2,"population_size":4,"familywise_alpha":{"kind":"rational","numerator":"1","denominator":"20"},"response_cutoff":6})json",
           R"json({"schema_version":2,"warmup_slots":2,"horizon_slots":6,"replications":2,"population_size":4,"familywise_alpha":{"kind":"rational","numerator":"1","denominator":"20"},"response_cutoff":4,"extension":0})json"}) {
    CAPTURE(text);
    CHECK_FALSE(mwperf::detail::validate_full_orbit_k_wide_parameters(
        source_node(text)));
  }
}

TEST_CASE("C30 observation parameters freeze all three gap modes",
          "[c27_1][c30][contract][negative]") {
  for (const std::string_view mode : {"disabled", "auto", "required"}) {
    CAPTURE(mode);
    auto validated =
        mwperf::detail::validate_full_orbit_observation_parameters(
            observation_parameters(mode));
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
    CHECK(bytes_string(validated.value().canonical_bytes).find(
              "\"gap_telemetry\":\"" + std::string(mode) + "\"") !=
          std::string::npos);
  }

  SECTION("unknown legacy spelling is rejected as a closed mode") {
    auto rejected = mwperf::detail::validate_full_orbit_observation_parameters(
        observation_parameters("certified_zero_solve"));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.full_orbit_observation_gap_mode");
  }

  SECTION("diagnostics-off permits only disabled gap telemetry") {
    auto disabled = mwperf::detail::validate_full_orbit_observation_parameters(
        observation_parameters("disabled", false));
    REQUIRE(disabled);
    for (const std::string_view mode : {"auto", "required"}) {
      CAPTURE(mode);
      auto rejected =
          mwperf::detail::validate_full_orbit_observation_parameters(
              observation_parameters(mode, false));
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code ==
            "c30.full_orbit_observation_disabled_gap_mode");
    }
  }
}

TEST_CASE("C30 terminal replication policy is branch sensitive",
          "[c27_1][c30][contract][negative]") {
  using mwperf::ProviderResultKindV2;
  const mwperf::BigNat requested{2U};

  auto built_short_prefix =
      mwperf::detail::
          validate_full_orbit_observation_terminal_replication_policy(
              ProviderResultKindV2::built, requested, 1U, true);
  REQUIRE_FALSE(built_short_prefix);
  CHECK(built_short_prefix.error().code ==
        "c30.full_orbit_observation_terminal_replication_policy");

  auto built_partial =
      mwperf::detail::
          validate_full_orbit_observation_terminal_replication_policy(
              ProviderResultKindV2::built, requested, 2U, false);
  REQUIRE_FALSE(built_partial);
  CHECK(built_partial.error().code ==
        "c30.full_orbit_observation_terminal_replication_policy");
  CHECK(mwperf::detail::
            validate_full_orbit_observation_terminal_replication_policy(
                ProviderResultKindV2::built, requested, 2U, true));

  for (const auto kind : {ProviderResultKindV2::unavailable,
                          ProviderResultKindV2::failed}) {
    CAPTURE(static_cast<unsigned>(kind));
    CHECK(mwperf::detail::
              validate_full_orbit_observation_terminal_replication_policy(
                  kind, requested, 1U, false));
    CHECK(mwperf::detail::
              validate_full_orbit_observation_terminal_replication_policy(
                  kind, requested, 2U, false));
    CHECK(mwperf::detail::
              validate_full_orbit_observation_terminal_replication_policy(
                  kind, requested, 2U, true));
  }

  auto over_cap =
      mwperf::detail::
          validate_full_orbit_observation_terminal_replication_policy(
              ProviderResultKindV2::failed, requested, 3U, false);
  REQUIRE_FALSE(over_cap);
  CHECK(over_cap.error().code ==
        "c30.full_orbit_observation_terminal_replication_policy");
}

TEST_CASE("C27.11 K-wide hosted preview binds cutoff and checked RPT",
          "[c27_1][contract][negative]") {
  auto fixture = preview_fixture();
  fixture.budget.exact_optimizer_calls = {
      mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{48U}};
  fixture.budget.optimizer_search_states = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
  fixture.budget.configured_generator_draws = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};

  for (const std::uint64_t cutoff : {2U, 3U, 4U, 5U}) {
    CAPTURE(cutoff);
    auto parameters = mwperf::detail::validate_full_orbit_k_wide_parameters(
        k_wide_parameters(cutoff));
    REQUIRE(parameters);
    auto tail = constant_response_tail(cutoff);
    auto preview = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
        fixture.view, fixture.budget, tail, parameters.value());
    INFO((preview ? std::string{}
                  : preview.error().code + ": " + preview.error().message));
    REQUIRE(preview);
    CHECK(preview.value().response_cutoff == mwperf::BigNat{cutoff});
    CHECK(preview.value().maximum_exact_optimizer_calls ==
          mwperf::BigNat{48U});
    CHECK_FALSE(preview.value()
                    .construction_prerequisites.required_optimizer_calls
                    .has_value());
    CHECK_FALSE(preview.value()
                    .construction_prerequisites.required_generator_draws
                    .has_value());
    CHECK_FALSE(preview.value()
                    .construction_prerequisites
                    .required_search_states_per_call
                    .has_value());
  }

  SECTION("the resolved cutoff is authoritative") {
    auto parameters = mwperf::detail::validate_full_orbit_k_wide_parameters(
        k_wide_parameters(4U));
    REQUIRE(parameters);
    auto mismatch = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
        fixture.view, fixture.budget, constant_response_tail(5U),
        parameters.value());
    REQUIRE_FALSE(mismatch);
    CHECK(mismatch.error().code ==
          "c27_1.full_orbit_k_wide_cutoff_mismatch");
  }

  SECTION("the exact-call grant covers RPT") {
    fixture.budget.exact_optimizer_calls.amount = mwperf::BigNat{47U};
    auto parameters = mwperf::detail::validate_full_orbit_k_wide_parameters(
        k_wide_parameters());
    REQUIRE(parameters);
    auto rejected = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
        fixture.view, fixture.budget, constant_response_tail(4U),
        parameters.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c27_1.full_orbit_k_wide_insufficient_grant");
  }

  SECTION("search states and configured draws are NotApplicable") {
    auto parameters = mwperf::detail::validate_full_orbit_k_wide_parameters(
        k_wide_parameters());
    REQUIRE(parameters);
    fixture.budget.optimizer_search_states = {
        mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}};
    auto search = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
        fixture.view, fixture.budget, constant_response_tail(4U),
        parameters.value());
    REQUIRE_FALSE(search);
    CHECK(search.error().code ==
          "c27_1.full_orbit_k_wide_nonapplicable_grant");

    fixture.budget.optimizer_search_states = {
        mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
    fixture.budget.configured_generator_draws = {
        mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}};
    auto draws = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
        fixture.view, fixture.budget, constant_response_tail(4U),
        parameters.value());
    REQUIRE_FALSE(draws);
    CHECK(draws.error().code ==
          "c27_1.full_orbit_k_wide_nonapplicable_grant");
  }
}

TEST_CASE(
    "C27.11 production K-wide artifacts pass the complete C15 object graph",
    "[c27_1][contract][c15][integration]") {
  constexpr std::uint64_t kPopulationSize = 64U;
  constexpr std::uint64_t kHorizonSlots = 100U;
  constexpr std::uint64_t kReplications = 8U;
  constexpr std::uint64_t kWarmupSlots = 20U;
  constexpr std::uint64_t kMaximumOptimizerCalls =
      kPopulationSize * kHorizonSlots * kReplications;

  const auto provider = full_orbit_k_wide_provider();

  for (const std::uint64_t cutoff : {2U, 3U, 4U, 5U}) {
    CAPTURE(cutoff);
    // Keep the direct contract seam faithful to a request the production
    // planner can mint: the authored constant-tail cutoff agrees with K and
    // its global optimizer cap covers the checked R*P*T admission bound.
    auto fixture = preview_fixture(
        "q0", 4U,
        KWidePreviewFixtureConfig{cutoff, kPopulationSize, kHorizonSlots,
                                  kReplications, kWarmupSlots,
                                  kMaximumOptimizerCalls});
    fixture.budget.exact_optimizer_calls = {
        mwperf::BudgetApplicabilityV1::applicable,
        mwperf::BigNat{kMaximumOptimizerCalls}};
    fixture.budget.optimizer_search_states = {
        mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
    fixture.budget.configured_generator_draws = {
        mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};

    auto parameters = mwperf::validate_surrogate_parameters(
        provider,
        k_wide_parameters(cutoff, kPopulationSize, kHorizonSlots,
                          kReplications, kWarmupSlots));
    INFO((parameters ? std::string{}
                     : parameters.error().code + ": " +
                           parameters.error().message));
    REQUIRE(parameters);

    auto preview = mwperf::preview_surrogate_descriptor(
        provider, fixture.view, fixture.requirements, fixture.budget,
        parameters.value());
    INFO((preview ? std::string{}
                  : preview.error().code + ": " + preview.error().message));
    REQUIRE(preview);
    REQUIRE(preview.value().metric_support_manifest != nullptr);
    CHECK_FALSE(preview.value()
                    .construction_prerequisites.required_optimizer_calls
                    .has_value());
    CHECK_FALSE(preview.value()
                    .construction_prerequisites.required_generator_draws
                    .has_value());
    CHECK_FALSE(preview.value()
                    .construction_prerequisites
                    .required_search_states_per_call
                    .has_value());
    CHECK(preview.value().core.payload_class ==
          mwperf::PayloadClassV1{
              mwperf::PayloadClassTagV1::
                  finite_prefix_constant_tail_response_v1,
              1U});
    CHECK(preview.value().core.tail.kind ==
          mwperf::TailRepresentationKindV1::constant_response);
    CHECK(preview.value().core.tail.boundary ==
          std::optional<mwperf::BigNat>{mwperf::BigNat{cutoff + 1U}});

    const auto decision = mwperf::negotiate_capabilities(
        fixture.requirements, preview.value(),
        fixture.view.configured_arrival().capabilities());
    const auto* contract = mwperf::accepted_capability_contract(decision);
    std::string capability_diagnostic;
    if (contract == nullptr) {
      const auto diagnostic = mwperf::explain_capability_failure(decision);
      capability_diagnostic = diagnostic.code + ": " + diagnostic.message;
      if (const auto* rejected =
              mwperf::rejected_capability_decision(decision);
          rejected != nullptr && !rejected->ordered_failures.empty()) {
        const auto& failure = rejected->ordered_failures.front();
        capability_diagnostic += "; provided: " + failure.provided +
                                 "; required: " + failure.required;
      }
    }
    INFO(capability_diagnostic);
    REQUIRE(contract != nullptr);

    auto request = mwperf::make_surrogate_build_request(
        provider.manifest(), fixture.view, *contract, parameters.value(),
        fixture.budget, mwperf::MasterSeed{203'882'758U});
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    auto context = mwperf::BuildExecutionContext::create(
        request.value(), provider.manifest(), k_wide_execution_root());
    INFO((context ? std::string{}
                  : context.error().code + ": " + context.error().message));
    REQUIRE(context);

    const auto outcome = mwperf::execute_surrogate_provider(
        provider, request.value(), context.value(),
        mwperf::ProviderExecutionControlsV1{1U, std::nullopt});
    const auto* completed =
        std::get_if<mwperf::CompletedProviderExecution>(&outcome);
    std::string execution_diagnostic;
    if (const auto* failed =
            std::get_if<mwperf::FailedProviderExecution>(&outcome)) {
      execution_diagnostic =
          failed->diagnostic.code + ": " + failed->diagnostic.message;
      for (const auto& note : failed->diagnostic.notes) {
        execution_diagnostic += "\n";
        execution_diagnostic += note;
      }
    }
    INFO(execution_diagnostic);
    REQUIRE(completed != nullptr);

    auto parsed = mwperf::parse_surrogate_build_result(
        completed->bytes, artifact_parse_limits());
    INFO((parsed ? std::string{}
                 : parsed.error().code + ": " + parsed.error().message));
    REQUIRE(parsed);
    auto report = mwperf::validate_surrogate_build_report(
        parsed.value(), request.value(), fixture.budget);
    INFO((report ? std::string{}
                 : report.error().code + ": " + report.error().message));
    REQUIRE(report);

    // F-C15-06 reaches the object-graph, realized-owner, scoped-evidence,
    // and auxiliary-ledger validators only after the production descriptor,
    // manifest echo, payload, report, and family evidence agree exactly.
    auto validated = mwperf::validate_surrogate_build_result(
        parsed.value(), request.value(), provider.manifest(), *contract,
        report.value());
    INFO((validated
              ? std::string{}
              : validated.error().code + ": " + validated.error().message +
                    " at " +
                    validated.error().json_pointer.value_or("<none>")));
    REQUIRE(validated);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated.value(), fixture.requirements);
    const auto* built =
        std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
    REQUIRE(built != nullptr);

    const auto& artifact = built->artifact.value();
    const auto* response =
        std::get_if<mwperf::FinitePrefixConstantTailResponseV1>(
            &artifact.payload);
    REQUIRE(response != nullptr);
    CHECK(response->response_cutoff == mwperf::BigNat{cutoff});
    CHECK(response->raw_response.response_cutoff ==
          mwperf::BigNat{cutoff});
    CHECK(response->raw_response.identifications.size() == cutoff + 2U);
    REQUIRE(response->raw_envelopes.size() == 1U);
    CHECK(response->raw_envelopes.front().response_cutoff ==
          mwperf::BigNat{cutoff});
    CHECK(response->raw_envelopes.front().covered_coordinates.size() ==
          cutoff + 2U);
    CHECK(artifact.deployed_descriptor == contract->descriptor_core());
    CHECK(artifact.structural_manifest_echo.manifest_digest ==
          contract->structural_manifest().canonical_digest());
    CHECK(artifact.deployed_descriptor.metric_support_manifest_digest ==
          contract->structural_manifest().canonical_digest());

    std::size_t expected_bindings = 0U;
    for (const auto& clause : contract->structural_manifest().clauses()) {
      expected_bindings += clause.required_roles.size();
    }
    CHECK(artifact.realized_metric_bindings.bindings.size() ==
          expected_bindings);
    CHECK(built->satisfied_clauses.size() ==
          contract->structural_manifest().clauses().size());

    REQUIRE(artifact.family_evidence.size() == 1U);
    const auto& family = artifact.family_evidence.front();
    REQUIRE(provider.manifest()
                .value()
                .family_evidence_conformance_report_anchors.size() == 1U);
    const auto& anchor = provider.manifest()
                             .value()
                             .family_evidence_conformance_report_anchors
                             .front();
    CHECK(family.family_evidence_schema_id ==
          anchor.family_evidence_schema_id);
    CHECK(family.family_evidence_schema_version ==
          anchor.family_evidence_schema_version);
    CHECK(family.provider_conformance_report_ref.report_id ==
          anchor.report_id);
    CHECK(family.provider_conformance_report_ref.report_digest ==
          anchor.report_digest);
    CHECK(family.provider == provider.identity());
    CHECK(family.provider_scientific_contract_digest ==
          provider.manifest().scientific_contract_digest().value());
    CHECK(family.request_digest == request.value().request_digest().value());
    CHECK(family.payload_digest == artifact.payload_digest);
    CHECK(family.evidence_scope_tag ==
          mwperf::MetricEvidenceScopeV1::raw_static_proposal);
    std::vector<mwperf::ArtifactObjectReferenceV1> expected_subjects;
    expected_subjects.reserve(cutoff + 4U);
    for (const auto& identification :
         response->raw_response.identifications) {
      expected_subjects.push_back(identification.coefficient_id);
      CHECK(std::find(identification.family_evidence_envelope_ids.begin(),
                      identification.family_evidence_envelope_ids.end(),
                      family.evidence_id) !=
            identification.family_evidence_envelope_ids.end());
    }
    expected_subjects.push_back(
        response->raw_envelopes.front().envelope_id);
    expected_subjects.push_back(
        response->raw_response.product_id.identity());
    std::sort(expected_subjects.begin(), expected_subjects.end());
    CHECK(family.subject_references == expected_subjects);
    CHECK(family.parent_references ==
          std::vector<mwperf::ArtifactObjectReferenceV1>{
              response->raw_response.product_id.identity()});
    CHECK(std::find(response->raw_envelopes.front()
                        .family_evidence_envelope_ids.begin(),
                    response->raw_envelopes.front()
                        .family_evidence_envelope_ids.end(),
                    family.evidence_id) !=
          response->raw_envelopes.front()
              .family_evidence_envelope_ids.end());

    auto portable = mwperf::adapt_portable_payload(built->artifact);
    INFO((portable
              ? std::string{}
              : portable.error().code + ": " + portable.error().message));
    REQUIRE(portable);
    const auto* portable_response =
        std::get_if<mwperf::PortableFinitePrefixConstantTailResponseV1>(
            &portable.value().value());
    REQUIRE(portable_response != nullptr);
    CHECK(portable_response->response_cutoff == mwperf::BigNat{cutoff});
    CHECK(portable_response->constant_tail_from ==
          mwperf::BigNat{cutoff + 1U});
    CHECK(portable_response->service_by_level.size() == cutoff + 1U);

    auto plug = mwperf::materialize_and_validate_surrogate_plug(
        portable.value(), built->artifact, *contract);
    INFO((plug ? std::string{}
               : plug.error().code + ": " + plug.error().message));
    REQUIRE(plug);
    CHECK(plug.value().descriptor().core == artifact.deployed_descriptor);

    const auto& bindings = built->artifact.validation_bindings();
    CHECK(bindings.provider == provider.identity());
    CHECK(bindings.preview_digest == contract->preview_digest());
    CHECK(bindings.accepted_contract_digest == contract->contract_digest());
    CHECK(bindings.structural_manifest_digest ==
          contract->structural_manifest().canonical_digest());
  }
}

TEST_CASE("C29 normal application route retains one native K-wide C19 law",
          "[c27_1][contract][integration][c19]") {
  const auto fixture_root =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
      "fixtures" / "c27_1";
  const auto model_path = fixture_root / "full_orbit_model_conflict.json";
  const auto analysis_path =
      fixture_root / "full_orbit_analysis_built_k_wide.json";
  const auto output_path =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c29-native-route-result.json";
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {analysis_path.string(), analysis_path},
      .output_path = {output_path.string(), output_path},
  }};
  auto resolved = mwperf::load_and_resolve_request(request);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " +
                       resolved.error().message));
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  auto valid_plan = mwperf::validate_execution_plan(plan.value());
  INFO((valid_plan ? std::string{}
                   : valid_plan.error().code + ": " +
                         valid_plan.error().message));
  REQUIRE(valid_plan);

  constexpr std::uint64_t kCutoff = 4U;
  CHECK(plan.value().provider().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.2.0"});
  CHECK(plan.value().preview().core.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                finite_prefix_constant_tail_response_v1,
            1U});
  CHECK(plan.value().preview().core.phase.payload_phase ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(plan.value().preview().core.tail.boundary ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{kCutoff + 1U}});
  REQUIRE(plan.value().dependency_schedule().size() == 6U);
  for (const auto& dependency : plan.value().dependency_schedule()) {
    CHECK(dependency.kind ==
          mwperf::SharedDependencyKindV1::c19_scalar_iid_stationary_summary);
  }
  CHECK(plan.value().problem_view().configured_arrival().capabilities()
            .exact_factorized_iid_generator.has_value());
  CHECK_FALSE(plan.value().problem_view().configured_arrival()
                  .iid_joint_table().has_value());

  // Execute the same frozen request once at the C15 boundary so this test can
  // inspect the private artifact.  The normal application run below must bind
  // to exactly this deterministic payload digest; no public result field is
  // added merely to expose the native coefficient vector.
  auto build_request = mwperf::make_surrogate_build_request(
      plan.value().provider_manifest(), plan.value().problem_view(),
      plan.value().capability_contract(),
      plan.value().validated_parameters(),
      plan.value().construction_budget(), plan.value().master_seed());
  REQUIRE(build_request);
  auto context = mwperf::BuildExecutionContext::create(
      build_request.value(), plan.value().provider_manifest(),
      k_wide_execution_root());
  REQUIRE(context);
  const auto provider_outcome = mwperf::execute_surrogate_provider(
      plan.value().provider(), build_request.value(), context.value(),
      mwperf::ProviderExecutionControlsV1{1U, std::nullopt});
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&provider_outcome);
  REQUIRE(completed != nullptr);
  auto parsed = mwperf::parse_surrogate_build_result(
      completed->bytes, artifact_parse_limits());
  REQUIRE(parsed);
  auto report = mwperf::validate_surrogate_build_report(
      parsed.value(), build_request.value(),
      plan.value().construction_budget());
  REQUIRE(report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), build_request.value(), plan.value().provider_manifest(),
      plan.value().capability_contract(), report.value());
  REQUIRE(validated);
  auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), plan.value().requirements());
  const auto* built =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(built != nullptr);
  const auto& artifact = built->artifact.value();
  const auto* native =
      std::get_if<mwperf::FinitePrefixConstantTailResponseV1>(
          &artifact.payload);
  REQUIRE(native != nullptr);
  CHECK(native->response_cutoff == mwperf::BigNat{kCutoff});
  REQUIRE(native->raw_response.identifications.size() == kCutoff + 2U);
  CHECK(native->raw_response.identifications.front().coordinate ==
        mwperf::FinitePrefixResponseCoordinateV1{
            mwperf::FinitePrefixResponseCoordinateKindV1::
                structural_level_zero,
            mwperf::BigNat{0U}});
  for (std::size_t level = 1U; level <= kCutoff; ++level) {
    CHECK(native->raw_response.identifications[level].coordinate ==
          mwperf::FinitePrefixResponseCoordinateV1{
              mwperf::FinitePrefixResponseCoordinateKindV1::exact_level,
              mwperf::BigNat{static_cast<std::uint64_t>(level)}});
  }
  CHECK(native->raw_response.identifications.back().coordinate ==
        mwperf::FinitePrefixResponseCoordinateV1{
            mwperf::FinitePrefixResponseCoordinateKindV1::constant_tail,
            mwperf::BigNat{kCutoff + 1U}});
  auto portable = mwperf::adapt_portable_payload(built->artifact);
  REQUIRE(portable);
  const auto* response =
      std::get_if<mwperf::PortableFinitePrefixConstantTailResponseV1>(
          &portable.value().value());
  REQUIRE(response != nullptr);
  CHECK(response->response_cutoff == mwperf::BigNat{kCutoff});
  REQUIRE(response->service_by_level.size() == kCutoff + 1U);
  CHECK(response->constant_tail_from == mwperf::BigNat{kCutoff + 1U});
  CHECK(response->selected_product.identity() ==
        native->deployed_response_product_id.identity());

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  CHECK(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  CHECK_FALSE(bundle.response_curve().has_value());
  CHECK(bundle.execution_identity().provider ==
        plan.value().provider().identity());
  REQUIRE(bundle.execution_identity().payload_digest.has_value());
  CHECK(*bundle.execution_identity().payload_digest == artifact.payload_digest);
  CHECK(bundle.execution_identity().plug_kind ==
        std::optional<std::string>{
            "finite_prefix_constant_tail_response_v1"});
  REQUIRE(bundle.execution_identity().execution_seal_digest.has_value());
  REQUIRE(bundle.metrics().size() == 6U);
  for (const auto& metric : bundle.metrics()) {
    const auto* established =
        std::get_if<mwperf::EstablishedResultMetricV1>(&metric);
    REQUIRE(established != nullptr);
    CHECK(established->header.law_identity ==
          *bundle.execution_identity().execution_seal_digest);
    CHECK(std::find(established->header.assumptions.begin(),
                    established->header.assumptions.end(),
                    "phase_free_finite_prefix_constant_tail_response") !=
          established->header.assumptions.end());
  }

  const auto has_diagnostic = [&](const std::string_view id) {
    return std::any_of(
        bundle.diagnostics().begin(), bundle.diagnostics().end(),
        [id](const mwperf::ResultDiagnosticV1& diagnostic) {
          return diagnostic.diagnostic_id == id;
        });
  };
  CHECK(has_diagnostic("c27.c19.normalization_residual"));
  CHECK(has_diagnostic("c27.c19.invariance_residual"));
  CHECK(has_diagnostic("c27.c19.stationary_status"));
  for (const auto& diagnostic : bundle.diagnostics()) {
    CHECK_FALSE(diagnostic.diagnostic_id.starts_with("c27.c18."));
    CHECK_FALSE(diagnostic.diagnostic_id.starts_with("c27.c20."));
    CHECK_FALSE(diagnostic.diagnostic_id.starts_with("c27.c21."));
  }
}

TEST_CASE("C27.11 K-wide hosted preview admits the work ceiling only",
          "[c27_1][negative]") {
  auto fixture = preview_fixture();
  fixture.budget.exact_optimizer_calls = {
      mwperf::BudgetApplicabilityV1::applicable,
      mwperf::BigNat{1'000'000'000U}};
  fixture.budget.optimizer_search_states = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
  fixture.budget.configured_generator_draws = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};

  auto boundary = mwperf::detail::validate_full_orbit_k_wide_parameters(
      k_wide_parameters(4U, 10U, 10'000'000U, 10U));
  REQUIRE(boundary);
  auto admitted = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
      fixture.view, fixture.budget, constant_response_tail(4U),
      boundary.value());
  REQUIRE(admitted);
  CHECK(admitted.value().maximum_exact_optimizer_calls ==
        mwperf::BigNat{1'000'000'000U});

  auto over = mwperf::detail::validate_full_orbit_k_wide_parameters(
      k_wide_parameters(4U, 11U, 10'000'000U, 10U));
  REQUIRE(over);
  auto rejected = mwperf::detail::preview_full_orbit_k_wide_hosted_route(
      fixture.view, fixture.budget, constant_response_tail(4U), over.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c27_1.full_orbit_k_wide_work_limit");
}

TEST_CASE("C27.11 BuildSeed to CP07.1 seed mapping matches Rust",
          "[c27_1][contract][rng]") {
  auto identity = mwperf::Digest256::from_hex(
      "1111111111111111111111111111111111111111111111111111111111111111");
  REQUIRE(identity);
  const mwperf::BuildIdentityDigest build_identity(identity.value());
  const mwperf::BuildSeed seed(
      mwperf::MasterSeed{0x0102'0304'0506'0708ULL}, build_identity);
  auto derived = mwperf::sha256_domain_separated(
      "mwperf.cp07.1.seed", seed.canonical_bytes());
  REQUIRE(derived);
  CHECK(derived.value().hex() ==
        "90f33164758ae9a39a92411f0de6e77934150901ad45853c2d594f8a8192233b");

  const mwperf::BuildSeed changed(
      mwperf::MasterSeed{0x0102'0304'0506'0709ULL}, build_identity);
  auto changed_derived = mwperf::sha256_domain_separated(
      "mwperf.cp07.1.seed", changed.canonical_bytes());
  REQUIRE(changed_derived);
  CHECK(changed_derived.value().hex() ==
        "98bb4f33878f76291f04508746c7432062e4067d09b80e35e09937fef74c6aab");
  CHECK(changed_derived.value() != derived.value());
}

TEST_CASE("C29 Full Orbit preview is deterministic and K-wide",
          "[c27_1][contract]") {
  const auto provider = full_orbit_provider();
  auto parameters = mwperf::validate_surrogate_parameters(provider,
                                                           valid_parameters());
  REQUIRE(parameters);
  auto fixture = preview_fixture(
      "q0", 4U, KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 1000U});
  auto first = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((first ? std::string{}
              : first.error().code + ": " + first.error().message));
  REQUIRE(first);
  auto second = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  REQUIRE(second);
  CHECK(first.value() == second.value());

  const auto& preview = first.value();
  CHECK(preview.core.provider == provider.identity());
  CHECK(preview.core.semantic ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(preview.core.runtime_access ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  CHECK(preview.core.payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                finite_prefix_constant_tail_response_v1,
            1U});
  CHECK(preview.core.tail.kind ==
        mwperf::TailRepresentationKindV1::constant_response);
  CHECK(preview.core.tail.boundary ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{5U}});
  auto core_digest =
      mwperf::canonical_plug_descriptor_core_digest_v1(preview.core);
  REQUIRE(core_digest);
  CHECK(preview.core.core_digest == core_digest.value());
  REQUIRE(preview.metric_support_manifest != nullptr);
  CHECK(preview.metric_support_manifest->clauses().size() == 6U);
  CHECK(preview.problem_view_digest == fixture.view.canonical_digest().value());
  CHECK(preview.parameter_digest == parameters.value().canonical_value_digest());
  auto budget_digest = mwperf::digest_construction_budget_v1(fixture.budget);
  REQUIRE(budget_digest);
  CHECK(preview.budget_digest == budget_digest.value());
  CHECK(preview.construction_target_scope ==
        std::vector<mwperf::QueueId>{queue("q0")});
  CHECK_FALSE(
      preview.construction_prerequisites.required_optimizer_calls.has_value());
  CHECK_FALSE(
      preview.construction_prerequisites.required_generator_draws.has_value());
  CHECK_FALSE(preview.construction_prerequisites
                  .required_search_states_per_call.has_value());
  CHECK(preview.policies.point_deployment ==
        mwperf::PointDeploymentPolicyV1::deploy_raw_point);
  CHECK(preview.policies.coefficient_completion ==
        mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points);
  CHECK(preview.policies.projection ==
        mwperf::ProjectionPolicyV1::not_applicable);
  CHECK(preview.policies.recoding ==
        mwperf::RecodingPolicyV1::not_applicable);
  CHECK(preview.policies.evidence_roles ==
        mwperf::EvidenceRolePolicyV1::exact_manifest_roles);
}

TEST_CASE("C27.10 Full Orbit admits exact optimizer geometries beyond legacy "
          "dense-memo dimensions",
          "[c27_1][c27_10][contract]") {
  SECTION("MWIS with twenty-one queues") {
    require_large_geometry_plan(false);
  }
  SECTION("packing with seventeen queues and resources") {
    require_large_geometry_plan(true);
  }
}

TEST_CASE("C27.9 Full Orbit negotiates exact factorized IID without a joint "
          "table",
          "[c27_1][c27_9][contract][arrival]") {
  const auto provider = full_orbit_provider();
  auto parameters = mwperf::validate_surrogate_parameters(provider,
                                                           valid_parameters());
  REQUIRE(parameters);

  // Sixty-five independent sources are deliberately beyond the dense
  // joint-table materialization cap.  The canonical configured law is
  // nevertheless an exact, portable description of their temporal-IID joint
  // batch law.
  auto fixture = preview_fixture(
      "q0", 65U,
      KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 1000U});
  const auto& arrival = fixture.view.configured_arrival();
  REQUIRE(arrival.capabilities().exact_factorized_iid_generator.has_value());
  CHECK(arrival.capabilities().exact_factorized_iid_generator->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK_FALSE(arrival.capabilities().exact_iid_joint_vector.has_value());
  CHECK_FALSE(arrival.iid_joint_table().has_value());
  CHECK_FALSE(arrival.configured_law().canonical_data.empty());
  CHECK(arrival.configured_law().payload_digest.hex().size() == 64U);
  CHECK(arrival.binding().law_digest.value().hex().size() == 64U);

  auto preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  const auto& assumptions =
      preview.value().construction_prerequisites.arrival;
  const auto iid = std::find_if(
      assumptions.begin(), assumptions.end(), [](const auto& assumption) {
        return assumption.kind == mwperf::ArrivalNeedKindV1::exact_iid_late;
      });
  REQUIRE(iid != assumptions.end());
  CHECK(iid->use == mwperf::ArrivalCapabilityUseV1::construction);
  CHECK(iid->provision == mwperf::CapabilityProvisionNeedV1::portable);
  CHECK(iid->joint);
}

TEST_CASE("C29 Full Orbit preview specializes its frozen target prototype",
          "[c27_1][contract][target]") {
  const auto provider = full_orbit_provider();
  auto parameters = mwperf::validate_surrogate_parameters(provider,
                                                           valid_parameters());
  REQUIRE(parameters);
  auto fixture = preview_fixture(
      "hub", 4U, KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 1000U});
  auto preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  CHECK(preview.value().core.deployed_targets ==
        std::vector<mwperf::QueueId>{queue("hub")});
  REQUIRE(preview.value().core.marks.size() == 1U);
  CHECK(preview.value().core.marks.front().kind ==
        mwperf::MetricMarkKindV1::target_backlog);
  REQUIRE(preview.value().metric_support_manifest != nullptr);
  for (const auto& clause :
       preview.value().metric_support_manifest->clauses()) {
    CHECK(clause.ordered_targets ==
          std::vector<mwperf::QueueId>{queue("hub")});
    CHECK(std::none_of(
        clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
          return mark.kind == mwperf::MetricMarkKindV1::opportunity;
        }));
  }
  CHECK(preview.value().core.metric_support_manifest_digest ==
        preview.value().metric_support_manifest->canonical_digest());
  CHECK(preview.value().metric_support_manifest->canonical_digest() !=
        provider.manifest().value().metric_clause_upper_envelope
            .canonical_digest());
  CHECK(std::any_of(
      provider.manifest().value().metric_clause_upper_envelope.clauses().begin(),
      provider.manifest().value().metric_clause_upper_envelope.clauses().end(),
      [](const auto& clause) {
        return std::any_of(
            clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
              return mark.kind == mwperf::MetricMarkKindV1::opportunity;
            });
      }));
}

TEST_CASE(
    "C27.11 K-wide preview specializes its frozen target prototype",
    "[c27_1][contract][target]") {
  const auto provider = full_orbit_k_wide_provider();
  auto parameters = mwperf::validate_surrogate_parameters(
      provider, k_wide_parameters(5U));
  REQUIRE(parameters);
  auto fixture = preview_fixture(
      "hub", 4U, KWidePreviewFixtureConfig{5U, 4U, 6U, 2U, 2U, 48U});
  fixture.budget.exact_optimizer_calls = {
      mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{48U}};
  fixture.budget.optimizer_search_states = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
  fixture.budget.configured_generator_draws = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};

  auto preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  CHECK(preview.value().core.deployed_targets ==
        std::vector<mwperf::QueueId>{queue("hub")});
  REQUIRE(preview.value().metric_support_manifest != nullptr);
  for (const auto& clause :
       preview.value().metric_support_manifest->clauses()) {
    CHECK(clause.ordered_targets ==
          std::vector<mwperf::QueueId>{queue("hub")});
    CHECK(std::none_of(
        clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
          return mark.kind == mwperf::MetricMarkKindV1::opportunity;
        }));
  }
  CHECK(preview.value().core.metric_support_manifest_digest ==
        preview.value().metric_support_manifest->canonical_digest());
  CHECK(preview.value().metric_support_manifest->canonical_digest() !=
        provider.manifest().value().metric_clause_upper_envelope
            .canonical_digest());
  CHECK(std::any_of(
      provider.manifest().value().metric_clause_upper_envelope.clauses().begin(),
      provider.manifest().value().metric_clause_upper_envelope.clauses().end(),
      [](const auto& clause) {
        return std::any_of(
            clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
              return mark.kind == mwperf::MetricMarkKindV1::opportunity;
            });
      }));
}

TEST_CASE(
    "C30 observation preview specializes its frozen target prototype",
    "[c27_1][c30][contract][target]") {
  const auto provider = full_orbit_observation_provider();
  auto parameters = mwperf::validate_surrogate_parameters(
      provider, observation_parameters());
  REQUIRE(parameters);
  auto fixture = preview_fixture(
      "hub", 4U, KWidePreviewFixtureConfig{4U, 4U, 6U, 2U, 2U, 48U});
  fixture.budget.exact_optimizer_calls = {
      mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{48U}};
  fixture.budget.optimizer_search_states = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};
  fixture.budget.configured_generator_draws = {
      mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt};

  auto preview = mwperf::preview_surrogate_descriptor(
      provider, fixture.view, fixture.requirements, fixture.budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  CHECK(preview.value().core.deployed_targets ==
        std::vector<mwperf::QueueId>{queue("hub")});
  REQUIRE(preview.value().metric_support_manifest != nullptr);
  for (const auto& clause :
       preview.value().metric_support_manifest->clauses()) {
    CHECK(clause.ordered_targets ==
          std::vector<mwperf::QueueId>{queue("hub")});
    CHECK(std::none_of(
        clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
          return mark.kind == mwperf::MetricMarkKindV1::opportunity;
        }));
  }
  CHECK(preview.value().core.metric_support_manifest_digest ==
        preview.value().metric_support_manifest->canonical_digest());
  CHECK(preview.value().metric_support_manifest->canonical_digest() !=
        provider.manifest().value().metric_clause_upper_envelope
            .canonical_digest());
  CHECK(std::any_of(
      provider.manifest().value().metric_clause_upper_envelope.clauses().begin(),
      provider.manifest().value().metric_clause_upper_envelope.clauses().end(),
      [](const auto& clause) {
        return std::any_of(
            clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
              return mark.kind == mwperf::MetricMarkKindV1::opportunity;
            });
      }));
}

TEST_CASE("C27.1 target CLI mints a bound non-prototype build request",
          "[c27_1][contract][target][request]") {
  const auto fixture_path =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
      "fixtures" / "c27_1" / "full_orbit_model_conflict.json";
  std::string model_text = read_fixture(fixture_path);
  for (std::size_t offset = 0U;
       (offset = model_text.find("q0", offset)) != std::string::npos;) {
    model_text.replace(offset, 2U, "hub");
    offset += 3U;
  }

  const auto model_path = write_input("target-cli-model", model_text);
  const auto output_path =
      model_path.parent_path() / "target-cli-result.json";
  const std::string model_argument = model_path.string();
  const std::string output_argument = output_path.string();
  const std::array<std::string_view, 8U> arguments{
      "--model", model_argument, "--target", "hub", "--output",
      output_argument, "--output_resources",
      "--report_unavailable_diagnostics"};

  auto cli = mwperf::parse_cli(arguments);
  INFO((cli ? std::string{} : cli.error().code + ": " + cli.error().message));
  REQUIRE(cli);
  auto resolved = mwperf::load_and_resolve_request(cli.value());
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  REQUIRE(resolved.value().analyze().target_queue.has_value());
  CHECK(*resolved.value().analyze().target_queue == "hub");
  CHECK(resolved.value().analyze().output_resources);
  CHECK(resolved.value().analyze().report_unavailable_diagnostics);

  auto plan = mwperf::build_execution_plan(resolved.value());
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  auto valid_plan = mwperf::validate_execution_plan(plan.value());
  INFO((valid_plan ? std::string{}
                   : valid_plan.error().code + ": " +
                         valid_plan.error().message));
  REQUIRE(valid_plan);
  CHECK(plan.value().provider().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.2.0"});
  CHECK(plan.value().provider().is_default());
  CHECK(plan.value().provider_manifest().value().payload_class ==
        mwperf::PayloadClassV1{
            mwperf::PayloadClassTagV1::
                finite_prefix_constant_tail_response_v1,
            1U});
  CHECK(plan.value().validated_parameters().parameter_schema_version() == 2U);
  CHECK(plan.value().preview().core.payload_class ==
        plan.value().provider_manifest().value().payload_class);
  CHECK(plan.value().preview().core.tail.kind ==
        mwperf::TailRepresentationKindV1::constant_response);
  CHECK(plan.value().preview().core.tail.boundary ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{3U}});
  CHECK(plan.value()
            .construction_budget()
            .optimizer_search_states.applicability ==
        mwperf::BudgetApplicabilityV1::not_applicable);
  CHECK_FALSE(plan.value()
                  .construction_budget()
                  .optimizer_search_states.amount.has_value());
  CHECK(plan.value()
            .construction_budget()
            .configured_generator_draws.applicability ==
        mwperf::BudgetApplicabilityV1::not_applicable);
  CHECK_FALSE(plan.value()
                  .construction_budget()
                  .configured_generator_draws.amount.has_value());
  CHECK(plan.value().problem_view().target_selection().ordered_targets ==
        std::vector<mwperf::QueueId>{queue("hub")});
  for (const auto& clause :
       plan.value().capability_contract().structural_manifest().clauses()) {
    CHECK(clause.ordered_targets ==
          std::vector<mwperf::QueueId>{queue("hub")});
    CHECK(std::none_of(
        clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
          return mark.kind == mwperf::MetricMarkKindV1::opportunity;
        }));
  }

  auto request = mwperf::make_surrogate_build_request(
      plan.value().provider_manifest(), plan.value().problem_view(),
      plan.value().capability_contract(), plan.value().validated_parameters(),
      plan.value().construction_budget(), plan.value().master_seed());
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  auto canonical =
      mwperf::canonical_surrogate_build_request_bytes_v1(request.value());
  INFO((canonical ? std::string{}
                  : canonical.error().code + ": " +
                        canonical.error().message));
  REQUIRE(canonical);
  CHECK_FALSE(canonical.value().empty());

  const std::array<std::string_view, 7U> compact_arguments{
      "--model", model_argument, "--target", "hub", "--output",
      output_argument, "--output_resources"};
  auto compact_cli = mwperf::parse_cli(compact_arguments);
  REQUIRE(compact_cli);
  auto compact_resolved =
      mwperf::load_and_resolve_request(compact_cli.value());
  REQUIRE(compact_resolved);
  CHECK_FALSE(
      compact_resolved.value().analyze().report_unavailable_diagnostics);
  CHECK(compact_resolved.value().fingerprints() ==
        resolved.value().fingerprints());
  CHECK(compact_resolved.value().master_seed() ==
        resolved.value().master_seed());
  auto compact_plan = mwperf::build_execution_plan(compact_resolved.value());
  REQUIRE(compact_plan);
  CHECK(compact_plan.value().provider().identity() ==
        plan.value().provider().identity());
  CHECK(compact_plan.value().preview() == plan.value().preview());
  CHECK(compact_plan.value()
            .validated_parameters()
            .canonical_value_digest() ==
        plan.value().validated_parameters().canonical_value_digest());
  CHECK(std::ranges::equal(
      compact_plan.value().validated_parameters().canonical_value_bytes(),
      plan.value().validated_parameters().canonical_value_bytes()));
  auto compact_request = mwperf::make_surrogate_build_request(
      compact_plan.value().provider_manifest(),
      compact_plan.value().problem_view(),
      compact_plan.value().capability_contract(),
      compact_plan.value().validated_parameters(),
      compact_plan.value().construction_budget(),
      compact_plan.value().master_seed());
  REQUIRE(compact_request);
  auto compact_canonical =
      mwperf::canonical_surrogate_build_request_bytes_v1(
          compact_request.value());
  REQUIRE(compact_canonical);
  CHECK(compact_canonical.value() == canonical.value());

  const std::string wire(
      reinterpret_cast<const char*>(canonical.value().data()),
      canonical.value().size());
  const auto& configured_arrival =
      request.value().framework_problem_view().configured_arrival();
  const std::string law_digest =
      configured_arrival.binding().law_digest.value().hex();

  // C27.9 changes only the Full Orbit transport projection: the exact
  // canonical factorized law is sent, while the legacy Cartesian table slot
  // remains present as null for the frozen C15 wire shape.
  CHECK(wire.find("\"iid_joint_table\":null") != std::string::npos);
  CHECK(wire.find("\"iid_joint_table\":[") == std::string::npos);
  CHECK(wire.find("\"exact_factorized_iid_generator\":{") !=
        std::string::npos);
  CHECK(wire.find("\"configured_law\":{") != std::string::npos);
  CHECK(wire.find("\"canonical_data\":\"") != std::string::npos);
  CHECK(wire.find(
            "\"schema\":\"independent_marked_renewal_v1\"") !=
        std::string::npos);
  CHECK(wire.find("\"law_digest\":\"" + law_digest + "\"") !=
        std::string::npos);
  CHECK(wire.find("\"ordered_queue_catalog\":[") != std::string::npos);
  CHECK(wire.find("\"constraint_geometry\":{") != std::string::npos);
  CHECK(wire.find("\"target_selection\":{") != std::string::npos);
  CHECK(wire.find("\"validated_parameters\":{") != std::string::npos);
  CHECK(request.value()
            .framework_problem_view()
            .target_selection()
            .ordered_targets ==
        std::vector<mwperf::QueueId>{queue("hub")});
  CHECK(request.value()
            .accepted_capability_contract()
            .construction_target_scope ==
        std::vector<mwperf::QueueId>{queue("hub")});
  for (const auto& clause :
       request.value()
           .accepted_capability_contract()
           .structural_metric_support_manifest.clauses()) {
    CHECK(clause.ordered_targets ==
          std::vector<mwperf::QueueId>{queue("hub")});
    CHECK(std::none_of(
        clause.marks.begin(), clause.marks.end(), [](const auto& mark) {
          return mark.kind == mwperf::MetricMarkKindV1::opportunity;
        }));
  }

  auto bindings = mwperf::artifact::detail::verify_request_bindings_v1(
      request.value(), plan.value().provider_manifest());
  INFO((bindings ? std::string{}
                 : bindings.error().code + ": " + bindings.error().message));
  REQUIRE(bindings);
}

#else

TEST_CASE("C27.1 provider contract is absent in compatibility builds",
          "[c27_1][contract]") {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE_FALSE(provider);
  CHECK(provider.error().code == "c16.unknown_surrogate_id");
}

#endif
