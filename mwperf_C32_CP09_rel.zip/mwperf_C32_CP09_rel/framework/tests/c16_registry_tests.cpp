#include <algorithm>
#include <atomic>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_test_providers.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::TypedLabel label(const std::string& text) {
  auto result = mwperf::TypedLabel::text(text);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue_id(const std::string& text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::SourceNode object_node() {
  const mwperf::SourceLocation location{
      "c16-registry-fixture.json", 1U, 1U, 0U};
  return mwperf::SourceNode::make_object(
      {{"resolution_level", location,
        mwperf::SourceNode::make_number(
            "1", location, "/resolution_level")}},
      location, "");
}

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c16-registry";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct InputFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
};

[[nodiscard]] InputFixture make_input_fixture() {
  static constexpr std::string_view model_text = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
      "params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],
                "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis_text = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.mwis.engineered","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);
  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  const std::array requests{request.value()};
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements)};
}

[[nodiscard]] mwperf::ConstructionBudget construction_budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct BoundScenario final {
  mwperf::SurrogateProvider provider;
  mwperf::MetricRequirements requirements;
  mwperf::FrameworkProblemView view;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::ConstructionBudget budget;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] BoundScenario make_bound_scenario() {
  auto input = make_input_fixture();
  auto id = mwperf::SurrogateId::parse("c16.fixture.mwis.engineered");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.registry.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), object_node());
  REQUIRE(parameters);
  auto budget = construction_budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, budget,
      parameters.value());
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const auto& manifest = provider.value().manifest().value();
  auto contract = Factory::accepted_contract(
      manifest, preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, mwperf::MasterSeed(0xC16U));
  REQUIRE(request);
  return {std::move(provider).value(), std::move(input.requirements),
          std::move(view).value(), std::move(parameters).value(),
          std::move(budget), std::move(request).value()};
}

[[nodiscard]] mwperf::SurrogateProviderRegistrationV1 registration(
    const std::string& id, const std::string& version,
    const bool is_default) {
  auto manifest = mwperf::testing::c16_test_manifest(
      id, mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, is_default);
  manifest.provider.provider_version = version;
  auto digest = mwperf::digest_provider_manifest_v1(manifest);
  REQUIRE(digest);
  manifest.manifest_digest = std::move(digest).value();
  return mwperf::testing::c16_test_registration(std::move(manifest));
}

[[nodiscard]] mwperf::SurrogateId surrogate_id(const std::string& value) {
  auto id = mwperf::SurrogateId::parse(value);
  REQUIRE(id);
  return std::move(id).value();
}

[[nodiscard]] mwperf::SurrogateVersion surrogate_version(
    const std::string& value) {
  auto version = mwperf::SurrogateVersion::parse(value);
  REQUIRE(version);
  return std::move(version).value();
}

[[nodiscard]] mwperf::Diagnostic forbidden_callback_diagnostic() {
  return {mwperf::DiagnosticCategory::internal,
          "c16.test.forbidden_callback",
          "an unregistered provider callback was invoked", std::nullopt,
          std::nullopt, {}};
}

}  // namespace

TEST_CASE("C16 injected registry enforces exact explicit defaults",
          "[c16][negative]") {
  const auto id = surrogate_id("c16.fixture.registry.versions");

  SECTION("no default") {
    auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
        {registration(id.value(), "1.0.0", false),
         registration(id.value(), "9.0.0", false)});
    REQUIRE(registry);
    auto omitted = mwperf::detail::lookup_in_surrogate_registry(
        registry.value(), id, std::nullopt);
    REQUIRE_FALSE(omitted);
    CHECK(omitted.error().code == "c16.no_default_surrogate_version");
  }

  SECTION("one explicit default and no latest-version guessing") {
    auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
        {registration(id.value(), "9.0.0", false),
         registration(id.value(), "1.0.0", true)});
    REQUIRE(registry);
    auto omitted = mwperf::detail::lookup_in_surrogate_registry(
        registry.value(), id, std::nullopt);
    REQUIRE(omitted);
    CHECK(omitted.value().identity().provider_version == "1.0.0");

    const auto high = surrogate_version("9.0.0");
    auto explicit_high = mwperf::detail::lookup_in_surrogate_registry(
        registry.value(), id,
        std::optional<mwperf::SurrogateVersion>{high});
    REQUIRE(explicit_high);
    CHECK(explicit_high.value().identity().provider_version == "9.0.0");
  }

  SECTION("multiple defaults") {
    auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
        {registration(id.value(), "1.0.0", true),
         registration(id.value(), "9.0.0", true)});
    REQUIRE_FALSE(registry);
    CHECK(registry.error().code ==
          "c16.multiple_default_provider_versions");
  }
}

TEST_CASE("C16 injected registry lookup and diagnostics ignore assembly order",
          "[c16][property]") {
  const auto id = surrogate_id("c16.fixture.registry.order");
  auto forward = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {registration(id.value(), "1.0.0", true),
       registration(id.value(), "9.0.0", false)});
  auto reverse = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {registration(id.value(), "9.0.0", false),
       registration(id.value(), "1.0.0", true)});
  REQUIRE(forward);
  REQUIRE(reverse);
  REQUIRE(forward.value().providers().size() == 2U);
  REQUIRE(reverse.value().providers().size() == 2U);
  for (std::size_t index = 0U; index < 2U; ++index) {
    CHECK(forward.value().providers()[index].identity() ==
          reverse.value().providers()[index].identity());
    CHECK(forward.value().providers()[index].is_default() ==
          reverse.value().providers()[index].is_default());
  }
  auto forward_default = mwperf::detail::lookup_in_surrogate_registry(
      forward.value(), id, std::nullopt);
  auto reverse_default = mwperf::detail::lookup_in_surrogate_registry(
      reverse.value(), id, std::nullopt);
  REQUIRE(forward_default);
  REQUIRE(reverse_default);
  CHECK(forward_default.value().identity() == reverse_default.value().identity());

  auto no_default_forward =
      mwperf::detail::SurrogateRegistryAssembler::assemble(
          {registration(id.value(), "1.0.0", false),
           registration(id.value(), "9.0.0", false)});
  auto no_default_reverse =
      mwperf::detail::SurrogateRegistryAssembler::assemble(
          {registration(id.value(), "9.0.0", false),
           registration(id.value(), "1.0.0", false)});
  REQUIRE(no_default_forward);
  REQUIRE(no_default_reverse);
  auto first_error = mwperf::detail::lookup_in_surrogate_registry(
      no_default_forward.value(), id, std::nullopt);
  auto second_error = mwperf::detail::lookup_in_surrogate_registry(
      no_default_reverse.value(), id, std::nullopt);
  REQUIRE_FALSE(first_error);
  REQUIRE_FALSE(second_error);
  CHECK(first_error.error() == second_error.error());
}

TEST_CASE("C16 injected providers cannot reach registered callback boundaries",
          "[c16][negative]") {
  auto scenario = make_bound_scenario();
  auto parameter_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto preview_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto producer_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto materializer_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto activation_calls = std::make_shared<std::atomic<unsigned>>(0U);

  auto injected = mwperf::testing::c16_test_registration(
      scenario.provider.manifest().value());
  injected.parameter_validator =
      [parameter_calls](const mwperf::SourceNode&)
      -> mwperf::Result<mwperf::ValidatedParameterPayloadV1> {
    parameter_calls->fetch_add(1U, std::memory_order_relaxed);
    return mwperf::Result<mwperf::ValidatedParameterPayloadV1>::failure(
        forbidden_callback_diagnostic());
  };
  injected.previewer =
      [preview_calls](const mwperf::FrameworkProblemView&,
                      const mwperf::MetricRequirements&,
                      const mwperf::ConstructionBudget&,
                      const mwperf::ValidatedSurrogateParameters&)
      -> mwperf::Result<mwperf::PlugDescriptorPreview> {
    preview_calls->fetch_add(1U, std::memory_order_relaxed);
    return mwperf::Result<mwperf::PlugDescriptorPreview>::failure(
        forbidden_callback_diagnostic());
  };
  injected.producer = mwperf::InProcessBuilderV1{
      [producer_calls](const mwperf::SurrogateBuildRequest&,
                       mwperf::BuildExecutionContext&) {
        producer_calls->fetch_add(1U, std::memory_order_relaxed);
        return mwperf::ProviderExecutionOutcome(
            mwperf::FailedProviderExecution{
                forbidden_callback_diagnostic()});
      }};
  injected.materializer =
      [materializer_calls](const mwperf::PortablePlugPayload&,
                           const mwperf::ValidatedSurrogateArtifact&,
                           const mwperf::AcceptedCapabilityContract&)
      -> mwperf::Result<mwperf::RuntimePlugCandidateV1> {
    materializer_calls->fetch_add(1U, std::memory_order_relaxed);
    return mwperf::Result<mwperf::RuntimePlugCandidateV1>::failure(
        forbidden_callback_diagnostic());
  };
  injected.framework_activation = mwperf::FrameworkActivationRegistrationV1{
      mwperf::FrameworkActivationCapabilitiesV1{
          true, true, true, true, true,
          mwperf::StageTag::generic_sampling, false,
          std::optional<mwperf::BigNat>{mwperf::BigNat{1U}}, std::nullopt,
          std::optional<mwperf::BigNat>{mwperf::BigNat{1U}},
          std::optional<mwperf::BigNat>{mwperf::BigNat{1U}},
          std::optional<mwperf::BigNat>{mwperf::BigNat{0U}},
          mwperf::ConditionalSampleDependenceV1::iid_cold_replications,
          mwperf::ConditionalEstimatorProcedureV1::conditional_reward_mean,
          mwperf::ConditionalRewardPremisesV1{
              true, mwperf::ExactRational::zero(),
              mwperf::ExactRational::one()}},
      [activation_calls](
          const mwperf::RuntimeFrameworkActivationContextV1&)
          -> mwperf::Result<mwperf::RuntimeFrameworkActivationV1> {
        activation_calls->fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<mwperf::RuntimeFrameworkActivationV1>::failure(
            forbidden_callback_diagnostic());
      }};

  auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {std::move(injected)});
  REQUIRE(registry);
  const auto id = surrogate_id(scenario.provider.identity().provider_id);
  const auto version =
      surrogate_version(scenario.provider.identity().provider_version);
  auto unregistered = mwperf::detail::lookup_in_surrogate_registry(
      registry.value(), id,
      std::optional<mwperf::SurrogateVersion>{version});
  REQUIRE(unregistered);
  REQUIRE(unregistered.value().has_framework_activation_factory());
  REQUIRE(unregistered.value().framework_activation_capabilities());
  CHECK(unregistered.value().framework_activation_capabilities()
            ->proves_exact_closed_boundary);

  auto parameters = mwperf::validate_surrogate_parameters(
      unregistered.value(), object_node());
  REQUIRE_FALSE(parameters);
  CHECK(parameters.error().code == "c16.unregistered_provider_handle");

  auto preview = mwperf::preview_surrogate_descriptor(
      unregistered.value(), scenario.view, scenario.requirements,
      scenario.budget, scenario.parameters);
  REQUIRE_FALSE(preview);
  CHECK(preview.error().code == "c16.unregistered_provider_handle");

  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c16-registry-runs";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  auto context = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), root);
  REQUIRE(context);
  auto execution = mwperf::execute_surrogate_provider(
      unregistered.value(), scenario.request, context.value());
  const auto* rejected =
      std::get_if<mwperf::FailedProviderExecution>(&execution);
  REQUIRE(rejected != nullptr);
  CHECK(rejected->diagnostic.code == "c16.unregistered_provider_handle");

  CHECK(parameter_calls->load(std::memory_order_relaxed) == 0U);
  CHECK(preview_calls->load(std::memory_order_relaxed) == 0U);
  CHECK(producer_calls->load(std::memory_order_relaxed) == 0U);
  CHECK(materializer_calls->load(std::memory_order_relaxed) == 0U);
  CHECK(activation_calls->load(std::memory_order_relaxed) == 0U);

  // Rejection is atomic: it does not consume the request-bound execution
  // gate, so the genuinely registered provider can still use this context.
  auto registered_execution = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context.value());
  CHECK(std::holds_alternative<mwperf::CompletedProviderExecution>(
      registered_execution));
}

TEST_CASE("C16 activation metadata cannot claim closure without a domain",
          "[c16][negative]") {
  auto invalid = registration("c16.fixture.activation.invalid", "1.0.0",
                              true);
  invalid.framework_activation = mwperf::FrameworkActivationRegistrationV1{
      mwperf::FrameworkActivationCapabilitiesV1{
          false, true, false, false, false},
      [](const mwperf::RuntimeFrameworkActivationContextV1&)
          -> mwperf::Result<mwperf::RuntimeFrameworkActivationV1> {
        return mwperf::Result<mwperf::RuntimeFrameworkActivationV1>::failure(
            forbidden_callback_diagnostic());
      }};
  auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {std::move(invalid)});
  REQUIRE_FALSE(registry);
  CHECK(registry.error().code ==
        "c16.invalid_framework_activation_registration");
}
