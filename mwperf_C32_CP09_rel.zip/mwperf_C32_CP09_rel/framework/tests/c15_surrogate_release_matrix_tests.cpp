#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/c15_golden_sources.hpp"
#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace {

using ReleaseFactory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::TypedLabel release_label(const std::string& text) {
  auto parsed = mwperf::TypedLabel::text(text);
  REQUIRE(parsed);
  return std::move(parsed).value();
}

[[nodiscard]] mwperf::QueueId release_queue(const std::string& text) {
  return mwperf::QueueId(release_label(text));
}

[[nodiscard]] mwperf::ExactRational release_rational(
    const std::int64_t numerator, const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::PortableScientificScalar release_scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return mwperf::PortableScientificScalar::rational(
      release_rational(numerator, denominator));
}

[[nodiscard]] mwperf::Digest256 release_digest(const std::string_view text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  auto digest = mwperf::sha256(bytes);
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_object(
    const std::string& name) {
  return {release_label(name), release_digest(name)};
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1 release_role(
    const mwperf::MetricSupportRoleV1 role,
    const mwperf::MetricTargetScopeV1 target_scope,
    const mwperf::MetricResultScopeV1 result_scope,
    const mwperf::MetricEvidenceScopeV1 evidence_scope) {
  const auto* schema = mwperf::metric_support_role_schema_v1(role);
  REQUIRE(schema != nullptr);
  REQUIRE((schema->allowed_target_scopes &
           mwperf::metric_target_scope_bit_v1(target_scope)) != 0U);
  REQUIRE((schema->allowed_result_scopes &
           mwperf::metric_result_scope_bit_v1(result_scope)) != 0U);
  REQUIRE((schema->allowed_evidence_scopes &
           mwperf::metric_evidence_scope_bit_v1(evidence_scope)) != 0U);

  std::vector<mwperf::MetricRoleRelationRequirementV1> role_relations;
  const auto append_roles =
      [&role_relations](const std::uint32_t mask,
                        const mwperf::MetricRoleRelationKindV1 relation) {
        for (const auto candidate : mwperf::all_metric_support_roles_v1()) {
          if ((mask & mwperf::metric_support_role_bit_v1(candidate)) != 0U) {
            role_relations.push_back({relation, candidate});
          }
        }
      };
  append_roles(schema->required_lineage_parent_roles,
               mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_roles(schema->required_binding_roles,
               mwperf::MetricRoleRelationKindV1::binding);
  append_roles(schema->required_evidence_roles,
               mwperf::MetricRoleRelationKindV1::evidence);
  append_roles(schema->required_subject_roles,
               mwperf::MetricRoleRelationKindV1::subject);

  std::vector<mwperf::InternalRelationRequirementV1> internal_relations;
  const auto append_internal =
      [&internal_relations](const std::uint64_t mask,
                            const mwperf::MetricRoleRelationKindV1 relation) {
        const auto last = static_cast<std::uint8_t>(
            mwperf::InternalReferencePurposeV1::error_object);
        for (std::uint8_t index = 0U; index <= last; ++index) {
          const auto purpose =
              static_cast<mwperf::InternalReferencePurposeV1>(index);
          if ((mask & mwperf::internal_reference_purpose_bit_v1(purpose)) !=
              0U) {
            internal_relations.push_back({relation, purpose});
          }
        }
      };
  append_internal(schema->required_internal_lineage_parents,
                  mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_internal(schema->required_internal_bindings,
                  mwperf::MetricRoleRelationKindV1::binding);
  append_internal(schema->required_internal_evidence,
                  mwperf::MetricRoleRelationKindV1::evidence);
  append_internal(schema->required_internal_subjects,
                  mwperf::MetricRoleRelationKindV1::subject);

  return {role, target_scope, result_scope, evidence_scope,
          std::move(role_relations), std::move(internal_relations)};
}

[[nodiscard]] mwperf::MetricSupportManifest release_stationary_manifest() {
  const auto q0 = release_queue("q0");
  auto result = mwperf::MetricSupportManifest::from_clauses({{
      {"throughput", 0U},
      mwperf::MetricKindV1::stationary_throughput,
      mwperf::ExactMetricParameterSetV1{
          {mwperf::StationaryThroughputParametersV1{}}},
      {q0},
      mwperf::TargetCouplingV1::scalar_target,
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
       std::nullopt, mwperf::FiniteHorizonCoverageKindV1::none, std::nullopt},
      {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U},
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      {},
      {},
      mwperf::SolverRegimeV1::enumerated,
      mwperf::EnumeratedAccuracyV1{{}},
      {mwperf::StructuralErrorFormV1::exact,
       mwperf::MetricEvidenceScopeV1::none, mwperf::ExactRational::zero()},
      mwperf::MetricResultScopeV1::surrogate_law,
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.release.matrix.v0", 1U},
      {release_role(mwperf::MetricSupportRoleV1::deployed_payload,
                    mwperf::MetricTargetScopeV1::payload_targets,
                    mwperf::MetricResultScopeV1::surrogate_law,
                    mwperf::MetricEvidenceScopeV1::none),
       release_role(mwperf::MetricSupportRoleV1::stationary_marked_edge_law,
                    mwperf::MetricTargetScopeV1::ordered_metric_targets,
                    mwperf::MetricResultScopeV1::surrogate_law,
                    mwperf::MetricEvidenceScopeV1::deployed_surrogate_law),
       release_role(
           mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
           mwperf::MetricTargetScopeV1::ordered_metric_targets,
           mwperf::MetricResultScopeV1::not_a_metric_result,
           mwperf::MetricEvidenceScopeV1::validity_or_lift)}}});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::PlugDescriptorCore release_stationary_descriptor(
    const mwperf::MetricSupportManifest& manifest) {
  mwperf::PlugDescriptorCore result{
      1U,
      {"c15.release.finite", "1.0.0"},
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U},
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      {release_queue("q0")},
      mwperf::TargetCouplingV1::scalar_target,
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
       std::nullopt, mwperf::FiniteHorizonCoverageKindV1::none, std::nullopt},
      {mwperf::TailRepresentationKindV1::exact_unbounded, std::nullopt,
       std::nullopt},
      {},
      {},
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.release.matrix.v0", 1U},
      {},
      {mwperf::EnumeratedAccuracyV1{{}}},
      {mwperf::ConstructionResultScopeV1::surrogate_law,
       mwperf::ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest.canonical_digest(),
      release_digest("descriptor-placeholder")};
  auto digest = mwperf::canonical_plug_descriptor_core_digest_v1(result);
  REQUIRE(digest);
  result.core_digest = std::move(digest).value();
  return result;
}

[[nodiscard]] std::vector<mwperf::FiniteLawTableAlternativeV1>
release_finite_tables() {
  const auto law = release_object("finite-law");
  const auto s0 = release_label("s0");
  const auto m0 = release_label("m0");
  const mwperf::FiniteLawRowV1 stationary_row{
      release_label("row"), s0,
      mwperf::FiniteRowConditioningStageV1::stationary_edge,
      {{s0, {m0}, release_scalar(1, 1), std::nullopt}}};
  const mwperf::FiniteLawRowV1 prearrival_row{
      release_label("pre-row"), s0,
      mwperf::FiniteRowConditioningStageV1::prearrival,
      {{s0, {m0}, release_scalar(1, 1), std::nullopt}}};
  const mwperf::FiniteLawRowV1 postarrival_row{
      release_label("post-row"), s0,
      mwperf::FiniteRowConditioningStageV1::postarrival,
      {{s0, {m0}, release_scalar(1, 1), std::nullopt}}};
  const mwperf::FiniteLawRowV1 continuation_row{
      release_label("continuation-row"), s0,
      mwperf::FiniteRowConditioningStageV1::one_slot_current,
      {{s0, {m0}, release_scalar(1, 1), std::nullopt}}};
  const mwperf::ExplicitOrderedWordV1 word{
      s0, mwperf::BigNat{1U}, {m0}, release_label("terminal"), s0,
      release_scalar(1, 1)};
  const mwperf::FinitePredictiveStoppingTablesV1 predictive{
      {continuation_row}, {continuation_row}, {continuation_row}};

  std::vector<mwperf::FiniteLawTableAlternativeV1> result;
  result.emplace_back(mwperf::StationaryMarkedEdgeTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {stationary_row},
      {"queue.big_nat", 1U}, {"arrival.phase", 1U},
      {"service.bit", 1U}, {"edge.mark", 1U},
      release_digest("conditioning")});
  result.emplace_back(mwperf::StagedOpportunityFluxTableV1{
      1U, law, mwperf::FiniteTableStorageV1::sparse, {s0}, {s0},
      {prearrival_row}, {postarrival_row}, release_digest("arrival"),
      {"arrival.innovation", 1U}, release_object("update"),
      release_object("retained"),
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge}});
  result.emplace_back(mwperf::TemporalContinuationTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {continuation_row},
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge},
      {"arrival.phase", 1U}, std::nullopt});
  result.emplace_back(mwperf::StoppedPathTableV1{
      1U, law, "hit.q0", {s0}, {s0}, {m0}, true, predictive,
      release_scalar(0, 1), {release_object("absorption")}});
  result.emplace_back(mwperf::RomrResidenceWordTableV1{
      1U, law, "event.q0", {s0}, {s0}, {m0},
      std::vector<mwperf::ExplicitOrderedWordV1>{word},
      release_scalar(0, 1), {release_object("termination")}});
  result.emplace_back(mwperf::CoupledCommonScheduleTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {stationary_row},
      release_digest("constraint"), release_digest("tie-phase-arrival")});
  return result;
}

[[nodiscard]] std::filesystem::path write_release_matrix_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next_id{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c15-release-matrix";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(next_id.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct ReleaseProblemInput final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
};

[[nodiscard]] ReleaseProblemInput make_release_problem_input(
    const std::string_view scheduler, const std::string_view arrival) {
  const std::string model_text =
      std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":)json") +
      std::string(scheduler) + R"json(,
    "arrival":)json" +
      std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis_text = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c15.fixture.provider","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                    "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(
      write_release_matrix_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document = mwperf::load_document(
      write_release_matrix_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);

  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  auto compiled =
      mwperf::detail::CompiledArrivalAccess::get(resolved.value().arrival());
  INFO((compiled ? std::string{}
                 : compiled.error().code + ": " + compiled.error().message));
  REQUIRE(compiled);
  return {std::move(resolved).value(), std::move(compiled).value()};
}

[[nodiscard]] mwperf::FrameworkProblemView make_release_view(
    const std::string_view scheduler, const std::string_view arrival) {
  auto input = make_release_problem_input(scheduler, arrival);
  const mwperf::TargetSelection targets{
      1U, {release_queue("q0")},
      mwperf::ConstructionGroupIdV1(release_label("c15.release.matrix"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);
  return std::move(view).value();
}

constexpr std::string_view kConflictScheduler = R"json(
  {"name":"conflict_graph_max_weight","params":{
    "constraint":{"conflicts":[]},"priority":["q0","q1"],
    "max_search_states":null}})json";

constexpr std::string_view kTraceArrival = R"json(
  {"family":"deterministic_trace",
   "events":[{"slot":0,"queue_id":"q0","count":1}],"metadata":{}})json";

}  // namespace

TEST_CASE("C15 release matrix projects all six configured arrival variants",
          "[c15][property][release-matrix]") {
  struct ArrivalCase final {
    std::string_view json;
    mwperf::PortableArrivalLawSchema schema;
  };
  static constexpr std::array<ArrivalCase, 6U> cases{{
      {kTraceArrival,
       mwperf::PortableArrivalLawSchema::deterministic_trace_v1},
      {R"json({"family":"periodic_global_phase","period":2,"phase":1,
               "sources":[{"id":"s","entries":[{"offset":0,
                 "queue_id":"q0","count":1}]}],"metadata":{}})json",
       mwperf::PortableArrivalLawSchema::periodic_global_phase_v1},
      {R"json({"family":"periodic_source_delays","period":2,
               "sources":[{"id":"s","delay":1,"entries":[{"offset":0,
                 "queue_id":"q0","count":1}]}],"metadata":{}})json",
       mwperf::PortableArrivalLawSchema::periodic_source_delays_v1},
      {R"json({"family":"independent_marked_renewal","sources":[{"id":"s",
               "interarrival":{"kind":"deterministic","d":1},
               "destination_pmf":[{"queue_id":"q0","probability":1}]}],
               "metadata":{}})json",
       mwperf::PortableArrivalLawSchema::independent_marked_renewal_v1},
      {R"json({"family":"independent_private_markov_renewal",
               "sources":[{"id":"s","states":["on"],
               "initial":{"state":"on"},"gaps":[{"state":"on","d":1}],
               "transitions":[{"state":"on","next_state":"on",
                 "probability":1}],"destination_pmf":[{"queue_id":"q0",
                 "probability":1}]}],"metadata":{}})json",
       mwperf::PortableArrivalLawSchema::independent_private_markov_renewal_v1},
      {R"json({"family":"shared_joint_round_markov_renewal",
               "sources":[{"id":"a"},{"id":"b"}],"states":["on"],
               "initial":{"state":"on"},"outcomes":[{"state":"on",
               "next_state":"on","probability":1,"emissions":[
                 {"source_id":"a","d":1,"queue_id":"q0"},
                 {"source_id":"b","d":2,"queue_id":"q1"}]}],
               "metadata":{}})json",
       mwperf::PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1},
  }};

  std::vector<mwperf::FrameworkProblemViewDigest> digests;
  for (std::size_t index = 0U; index < cases.size(); ++index) {
    CAPTURE(index);
    const auto first = make_release_view(kConflictScheduler, cases[index].json);
    const auto repeat = make_release_view(kConflictScheduler, cases[index].json);
    const auto first_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(first);
    const auto repeat_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(repeat);
    REQUIRE(first_bytes);
    REQUIRE(repeat_bytes);
    CHECK(first_bytes.value() == repeat_bytes.value());
    CHECK(first.canonical_digest() == repeat.canonical_digest());
    CHECK(first.configured_arrival().configured_law().schema ==
          cases[index].schema);
    CHECK_FALSE(first.configured_arrival()
                    .configured_law()
                    .canonical_data.empty());
    digests.push_back(first.canonical_digest());
  }
  for (std::size_t left = 0U; left < digests.size(); ++left) {
    for (std::size_t right = left + 1U; right < digests.size(); ++right) {
      CHECK_FALSE(digests[left] == digests[right]);
    }
  }

  const auto joint_view =
      make_release_view(kConflictScheduler, cases.back().json);
  const auto& joint = joint_view.configured_arrival().configured_law();
  CHECK(joint_view.configured_arrival().binding().family ==
        mwperf::ArrivalFamily::shared_joint_round_markov_renewal);
  std::size_t cursor = 0U;
  const auto read_u32 = [&]() {
    REQUIRE(cursor + 4U <= joint.canonical_data.size());
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
      value = static_cast<std::uint32_t>(
          (value << 8U) |
          std::to_integer<std::uint8_t>(joint.canonical_data[cursor++]));
    }
    return value;
  };
  const auto read_u64 = [&]() {
    REQUIRE(cursor + 8U <= joint.canonical_data.size());
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
      value = (value << 8U) |
              std::to_integer<std::uint8_t>(
                  joint.canonical_data[cursor++]);
    }
    return value;
  };
  const auto skip_string = [&]() {
    const auto size = read_u64();
    REQUIRE(size <= joint.canonical_data.size() - cursor);
    cursor += static_cast<std::size_t>(size);
  };

  skip_string();  // Closed shared-round law domain.
  const auto child_size = read_u64();
  REQUIRE(child_size <= joint.canonical_data.size() - cursor);
  skip_string();  // Shared-round child law domain.
  CHECK(read_u32() == 1U);
  CHECK(read_u64() == 2U);  // Queue cardinality.
  REQUIRE(read_u64() == 2U);  // Both sources remain in one law.
  skip_string();
  skip_string();
  REQUIRE(cursor < joint.canonical_data.size());
  CHECK(std::to_integer<std::uint8_t>(joint.canonical_data[cursor]) == 0U);
  ++cursor;  // Named rather than distributed initial-state discriminant.
  REQUIRE(read_u64() == 1U);
  (void)read_u64();  // Initial state index.
  REQUIRE(read_u64() == 1U);
  skip_string();
  REQUIRE(read_u64() == 1U);  // One joint outcome.
  (void)read_u64();  // Next-state index.
  CHECK(read_u64() == 2U);  // Two emissions in that same outcome.
}

TEST_CASE("C15 release matrix binds geometry coefficients and joint atoms",
          "[c15][property][release-matrix]") {
  struct GeometryMutation final {
    std::string_view baseline;
    std::string_view changed;
    std::size_t variant_index;
  };
  static constexpr std::array<GeometryMutation, 5U> mutations{{
      {R"json({"name":"crossbar_max_weight","params":{"constraint":{
                 "inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[
                   {"queue_id":"q0","input":"i0","output":"o0"},
                   {"queue_id":"q1","input":"i1","output":"o1"}]},
                 "priority":["q0","q1"]}})json",
       R"json({"name":"crossbar_max_weight","params":{"constraint":{
                 "inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[
                   {"queue_id":"q0","input":"i0","output":"o0"},
                   {"queue_id":"q1","input":"i0","output":"o1"}]},
                 "priority":["q0","q1"]}})json",
       0U},
      {R"json({"name":"interval_max_weight","params":{"constraint":{
                 "intervals":[{"queue_id":"q0","left":0,"right":1},
                   {"queue_id":"q1","left":1,"right":2}]},
                 "priority":["q0","q1"]}})json",
       R"json({"name":"interval_max_weight","params":{"constraint":{
                 "intervals":[{"queue_id":"q0","left":0,"right":1},
                   {"queue_id":"q1","left":1,"right":3}]},
                 "priority":["q0","q1"]}})json",
       1U},
      {R"json({"name":"node_exclusive_max_weight","params":{"constraint":{
                 "vertices":["u","v","w","x"],"links":[
                   {"queue_id":"q0","u":"u","v":"v"},
                   {"queue_id":"q1","u":"w","v":"x"}]},
                 "priority":["q0","q1"]}})json",
       R"json({"name":"node_exclusive_max_weight","params":{"constraint":{
                 "vertices":["u","v","w","x"],"links":[
                   {"queue_id":"q0","u":"u","v":"v"},
                   {"queue_id":"q1","u":"v","v":"x"}]},
                 "priority":["q0","q1"]}})json",
       2U},
      {kConflictScheduler,
       R"json({"name":"conflict_graph_max_weight","params":{
                 "constraint":{"conflicts":[["q0","q1"]]},
                 "priority":["q0","q1"],"max_search_states":null}})json",
       3U},
      {R"json({"name":"resource_packing_max_weight","params":{"constraint":{
                 "resources":["r"],"capacity":[2],"demands":[
                   {"queue_id":"q0","demand":[1]},
                   {"queue_id":"q1","demand":[2]}]},
                 "priority":["q0","q1"],"max_search_states":null}})json",
       R"json({"name":"resource_packing_max_weight","params":{"constraint":{
                 "resources":["r"],"capacity":[3],"demands":[
                   {"queue_id":"q0","demand":[1]},
                   {"queue_id":"q1","demand":[2]}]},
                 "priority":["q0","q1"],"max_search_states":null}})json",
       4U},
  }};

  for (std::size_t index = 0U; index < mutations.size(); ++index) {
    CAPTURE(index);
    const auto before = make_release_view(mutations[index].baseline,
                                          kTraceArrival);
    const auto after = make_release_view(mutations[index].changed,
                                         kTraceArrival);
    CHECK(before.constraint_geometry().index() ==
          mutations[index].variant_index);
    CHECK(after.constraint_geometry().index() == mutations[index].variant_index);
    CHECK_FALSE(before.canonical_digest() == after.canonical_digest());
    const auto before_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(before);
    const auto after_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(after);
    REQUIRE(before_bytes);
    REQUIRE(after_bytes);
    CHECK_FALSE(before_bytes.value() == after_bytes.value());
  }

  static constexpr std::string_view first_joint = R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"a"},{"id":"b"}],"states":["on"],
    "initial":{"state":"on"},"outcomes":[{"state":"on",
    "next_state":"on","probability":1,"emissions":[
      {"source_id":"a","d":1,"queue_id":"q0"},
      {"source_id":"b","d":2,"queue_id":"q1"}]}],"metadata":{}})json";
  static constexpr std::string_view changed_joint = R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"a"},{"id":"b"}],"states":["on"],
    "initial":{"state":"on"},"outcomes":[{"state":"on",
    "next_state":"on","probability":1,"emissions":[
      {"source_id":"a","d":1,"queue_id":"q0"},
      {"source_id":"b","d":3,"queue_id":"q1"}]}],"metadata":{}})json";
  const auto before_joint = make_release_view(kConflictScheduler, first_joint);
  const auto after_joint = make_release_view(kConflictScheduler, changed_joint);
  CHECK_FALSE(before_joint.canonical_digest() == after_joint.canonical_digest());
  CHECK_FALSE(before_joint.configured_arrival().configured_law().payload_digest ==
              after_joint.configured_arrival().configured_law().payload_digest);
}

TEST_CASE("C15 release matrix rejects finite table subtag relabeling",
          "[c15][negative][release-matrix]") {
  const auto manifest = release_stationary_manifest();
  const auto descriptor = release_stationary_descriptor(manifest);
  const auto tables = release_finite_tables();
  REQUIRE(tables.size() == 6U);

  const auto make_payload = [&](const std::size_t index) {
    return mwperf::ArtifactPayloadV1{mwperf::FiniteLawTablesV1{
        1U,
        {release_queue("q0")},
        mwperf::SemanticTagV1::stationary_marked_edge,
        mwperf::RuntimeAccessTagV1::finite_enumerated_row,
        release_digest("arrival"),
        release_digest("selection"),
        {{release_label("s0"), {release_scalar(0, 1)}}},
        {{release_label("m0"), {release_scalar(0, 1)}}},
        tables[index]}};
  };

  const auto valid = mwperf::validate_metric_support_manifest(
      manifest, make_payload(0U), descriptor);
  INFO((valid ? std::string{}
              : valid.error().code + ": " + valid.error().message));
  REQUIRE(valid);

  // The closed table subtag determines its semantic.  Keeping the stationary
  // semantic/access/descriptor tuple while swapping any other table schema
  // must fail before capability publication.
  for (std::size_t index = 1U; index < tables.size(); ++index) {
    CAPTURE(index);
    auto rejected = mwperf::validate_metric_support_manifest(
        manifest, make_payload(index), descriptor);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.finite_table_semantic_mismatch");
  }

  auto wrong_access =
      std::get<mwperf::FiniteLawTablesV1>(make_payload(0U));
  wrong_access.runtime_access = mwperf::RuntimeAccessTagV1::sparse_row;
  auto rejected_access = mwperf::validate_metric_support_manifest(
      manifest, mwperf::ArtifactPayloadV1{std::move(wrong_access)},
      descriptor);
  REQUIRE_FALSE(rejected_access);
  CHECK(rejected_access.error().code == "c15.finite_table_semantic_mismatch");
}

TEST_CASE("C15 release matrix content-binds every direct value selector",
          "[c15][property][release-matrix]") {
  const auto q0 = release_queue("q0");
  const auto q1 = release_queue("q1");
  mwperf::DirectMetricValueV1 baseline{
      release_object("direct-value"),
      {"throughput", 0U},
      {q0, q1},
      release_scalar(1, 2),
      release_digest("request"),
      release_digest("normalized-request"),
      release_digest("targets"),
      release_digest("arrival"),
      release_digest("contract"),
      {mwperf::SelectionKindV1::stationary_unique},
      {},
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::DirectMetricValidityBasisV1::exact_closed_form,
      {release_object("validity")}};
  auto baseline_digest =
      mwperf::artifact::detail::direct_metric_value_digest_v1(baseline);
  REQUIRE(baseline_digest);

  using Mutation = void (*)(mwperf::DirectMetricValueV1&);
  const std::array<Mutation, 13U> mutations{{
      [](auto& value) { value.metric_clause_id.authored_index = 1U; },
      [](auto& value) {
        std::swap(value.ordered_targets[0U], value.ordered_targets[1U]);
      },
      [](auto& value) { value.value = release_scalar(3, 4); },
      [](auto& value) { value.request_digest = release_digest("request-2"); },
      [](auto& value) {
        value.normalized_metric_request_digest =
            release_digest("normalized-request-2");
      },
      [](auto& value) {
        value.target_selection_digest = release_digest("targets-2");
      },
      [](auto& value) {
        value.configured_arrival_digest = release_digest("arrival-2");
      },
      [](auto& value) {
        value.accepted_contract_digest = release_digest("contract-2");
      },
      [](auto& value) {
        value.selection_assumptions = {
            mwperf::SelectionKindV1::stationary_class};
      },
      [](auto& value) {
        value.arrival_assumptions.push_back(
            {mwperf::ArrivalNeedKindV1::target_intensity,
             mwperf::ArrivalCapabilityUseV1::runtime,
             mwperf::CapabilityProvisionNeedV1::portable, std::nullopt,
             false, false, std::nullopt, std::nullopt, std::nullopt});
      },
      [](auto& value) {
        value.result_scope = mwperf::MetricResultScopeV1::response_envelope;
      },
      [](auto& value) {
        value.validity_basis =
            mwperf::DirectMetricValidityBasisV1::exact_finite_enumeration;
      },
      [](auto& value) { value.evidence_ids.push_back(release_object("more")); },
  }};

  for (std::size_t index = 0U; index < mutations.size(); ++index) {
    CAPTURE(index);
    auto changed = baseline;
    mutations[index](changed);
    auto changed_digest =
        mwperf::artifact::detail::direct_metric_value_digest_v1(changed);
    REQUIRE(changed_digest);
    CHECK_FALSE(changed_digest.value() == baseline_digest.value());
  }
}

namespace {

[[nodiscard]] std::vector<std::byte> release_bytes(
    const std::string_view text) {
  const auto view = std::as_bytes(std::span(text.data(), text.size()));
  return {view.begin(), view.end()};
}

[[nodiscard]] mwperf::ProviderIdentityV1 release_provider(
    std::string id) {
  return {std::move(id), "1.0.0"};
}

[[nodiscard]] mwperf::MetricSupportManifestEchoV1 release_manifest_echo(
    const mwperf::MetricSupportManifest& manifest) {
  auto bytes = mwperf::canonical_metric_support_manifest_bytes_v1(manifest);
  REQUIRE(bytes);
  return {1U, std::move(bytes).value(), manifest.canonical_digest()};
}

struct ReleaseFullPathInput final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
};

enum class ReleasePayloadCase : std::uint8_t {
  analytic,
  finite_stationary,
  finite_staged,
  finite_temporal,
  finite_stopped,
  finite_residence,
  finite_coupled,
  runtime_recipe,
  response_envelope,
  direct,
};

enum class ReleaseEnvelopeContractKind : std::uint8_t {
  response,
  optimizer_interval_raw,
  physical_bound,
};

struct ReleaseFullPathSpec final {
  ReleasePayloadCase payload_case;
  std::string_view name;
  std::string_view metric_json;
  mwperf::PayloadClassTagV1 payload_tag;
  mwperf::SemanticTagV1 semantic;
  mwperf::RuntimeAccessTagV1 access;
  mwperf::SolverRegimeV1 solver;
  mwperf::ConstructionMethodV1 method;
  mwperf::ProducerModeV1 mode;
  mwperf::MetricSupportRoleV1 primary_role;
  bool coupled;
  bool transient;
};

[[nodiscard]] std::string release_solver_json(
    const mwperf::SolverRegimeV1 solver) {
  switch (solver) {
    case mwperf::SolverRegimeV1::enumerated:
      return R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})json";
    case mwperf::SolverRegimeV1::analytic:
      return R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json";
    case mwperf::SolverRegimeV1::monte_carlo:
      return R"json({"kind":"monte_carlo","parameters":{"replications":64,"confidence_level":0.95,"interval_method":"hoeffding"}})json";
    case mwperf::SolverRegimeV1::direct:
      return R"json({"kind":"direct","parameters":{}})json";
  }
  FAIL("unreachable release solver");
  return {};
}

[[nodiscard]] std::string release_selection_json(const bool transient) {
  if (!transient) {
    return R"json({"kind":"stationary_unique","parameters":{}})json";
  }
  return R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{}}]}}})json";
}

[[nodiscard]] ReleaseFullPathInput make_release_full_path_input(
    const ReleaseFullPathSpec& spec) {
  const std::string model_text = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string targets = spec.coupled ? "[\"q0\",\"q1\"]"
                                           : "[\"q0\"]";
  const std::string analysis_text =
      std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":)json") + targets + R"json(,
    "metrics":[)json" + std::string(spec.metric_json) + R"json(],
    "surrogate":{"id":"c15.release.provider","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" + release_selection_json(spec.transient) +
      R"json(,
    "solver":)json" + release_solver_json(spec.solver) + "}";

  auto model_document = mwperf::load_document(
      write_release_matrix_input("full-model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document = mwperf::load_document(
      write_release_matrix_input("full-analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  auto compiled =
      mwperf::detail::CompiledArrivalAccess::get(resolved.value().arrival());
  REQUIRE(compiled);
  std::vector<mwperf::MetricRequest> requests;
  for (const auto& metric : resolved.value().analysis_spec().metrics) {
    auto request = mwperf::parse_metric_request(metric,
                                                resolved.value().queues());
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    requests.push_back(std::move(request).value());
  }
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  return {std::move(resolved).value(), std::move(compiled).value(),
          std::move(requirements)};
}

[[nodiscard]] mwperf::AccuracyContractV1 release_accuracy(
    const mwperf::SolverRegimeV1 solver) {
  switch (solver) {
    case mwperf::SolverRegimeV1::enumerated:
      return mwperf::EnumeratedAccuracyV1{{}};
    case mwperf::SolverRegimeV1::analytic:
      return mwperf::AnalyticAccuracyV1{mwperf::BigNat{128U}, {}};
    case mwperf::SolverRegimeV1::monte_carlo:
      return mwperf::MonteCarloAccuracyV1{
          mwperf::BigNat{64U}, release_rational(19, 20),
          mwperf::StatisticalIntervalKindV1::hoeffding,
          mwperf::StatisticalEstimandKindV1::bounded_iid,
          release_rational(0, 1), release_rational(1, 1)};
    case mwperf::SolverRegimeV1::direct:
      return mwperf::DirectExactAccuracyV1{};
  }
  FAIL("unreachable release accuracy");
  return mwperf::DirectExactAccuracyV1{};
}

[[nodiscard]] std::vector<mwperf::StateFieldDescriptorV1>
release_state_fields(const ReleasePayloadCase payload_case) {
  (void)payload_case;
  return {{mwperf::StateFieldKindV1::target_backlog,
           mwperf::FieldOwnershipV1::framework_exact,
           {"queue.big_nat", 1U}}};
}

[[nodiscard]] std::vector<mwperf::MarkDescriptorV1> release_marks(
    const ReleasePayloadCase payload_case) {
  if (payload_case == ReleasePayloadCase::finite_stationary) {
    return {{mwperf::MetricMarkKindV1::actual_departure,
             mwperf::MetricRevealStageV1::completed_edge,
             {"service.bit", 1U}, ""},
            {mwperf::MetricMarkKindV1::successor_backlog,
             mwperf::MetricRevealStageV1::completed_edge,
             {"queue.big_nat", 1U}, ""}};
  }
  if (payload_case == ReleasePayloadCase::finite_staged) {
    return {{mwperf::MetricMarkKindV1::arrival_batch,
             mwperf::MetricRevealStageV1::arrival,
             {"arrival.innovation", 1U}, ""}};
  }
  return {{mwperf::MetricMarkKindV1::actual_departure,
           mwperf::MetricRevealStageV1::completed_edge,
           {"service.bit", 1U}, ""}};
}

[[nodiscard]] mwperf::MetricSupportManifest release_full_path_manifest(
    const ReleaseFullPathSpec& spec,
    const mwperf::MetricRequirements& requirements,
    const std::optional<mwperf::TargetCouplingV1> coupling_override =
        std::nullopt,
    const ReleaseEnvelopeContractKind envelope_contract =
        ReleaseEnvelopeContractKind::response) {
  REQUIRE_FALSE(requirements.clauses().empty());
  std::vector<mwperf::MetricSupportClauseV1> clauses;
  clauses.reserve(requirements.clauses().size());
  for (const auto& requested : requirements.clauses()) {
    std::vector<mwperf::QueueId> targets;
    for (const auto& target : requested.origin.ordered_targets) {
      targets.push_back(target.queue_id);
    }
    const bool response_envelope =
        spec.payload_case == ReleasePayloadCase::response_envelope;
    const bool physical =
        response_envelope &&
        envelope_contract == ReleaseEnvelopeContractKind::physical_bound;
    const auto result_scope =
        response_envelope
            ? (physical ? mwperf::MetricResultScopeV1::physical_bound
                        : mwperf::MetricResultScopeV1::response_envelope)
            : mwperf::MetricResultScopeV1::surrogate_law;
    const auto raw_bound_scope =
        envelope_contract ==
                ReleaseEnvelopeContractKind::optimizer_interval_raw
            ? mwperf::MetricEvidenceScopeV1::optimizer_interval_raw
            : mwperf::MetricEvidenceScopeV1::raw_static_proposal;
    std::vector<mwperf::MetricSupportRoleRequirementV1> roles;
    roles.push_back(release_role(
        mwperf::MetricSupportRoleV1::deployed_payload,
        mwperf::MetricTargetScopeV1::payload_targets, result_scope,
        mwperf::MetricEvidenceScopeV1::none));
    if (response_envelope) {
      roles.push_back(release_role(
          mwperf::MetricSupportRoleV1::raw_response,
          mwperf::MetricTargetScopeV1::deployed_singleton_target,
          mwperf::MetricResultScopeV1::proposal_raw,
          mwperf::MetricEvidenceScopeV1::raw_static_proposal));
      auto envelope_role = release_role(
          mwperf::MetricSupportRoleV1::response_envelope,
          mwperf::MetricTargetScopeV1::deployed_singleton_target,
          result_scope,
          physical ? mwperf::MetricEvidenceScopeV1::physical_system
                   : mwperf::MetricEvidenceScopeV1::validity_or_lift);
      if (physical) {
        envelope_role.role_relations.push_back(
            {mwperf::MetricRoleRelationKindV1::evidence,
             mwperf::MetricSupportRoleV1::physical_transfer_evidence});
      }
      roles.push_back(std::move(envelope_role));
      roles.push_back(release_role(
          mwperf::MetricSupportRoleV1::raw_response_bound_evidence,
          mwperf::MetricTargetScopeV1::deployed_singleton_target,
          mwperf::MetricResultScopeV1::not_a_metric_result,
          raw_bound_scope));
      roles.push_back(release_role(
          mwperf::MetricSupportRoleV1::response_order_evidence,
          mwperf::MetricTargetScopeV1::deployed_singleton_target,
          mwperf::MetricResultScopeV1::not_a_metric_result,
          mwperf::MetricEvidenceScopeV1::deployed_surrogate_law));
      if (physical) {
        roles.push_back(release_role(
            mwperf::MetricSupportRoleV1::physical_transfer_evidence,
            mwperf::MetricTargetScopeV1::ordered_metric_targets,
            mwperf::MetricResultScopeV1::physical_bound,
            mwperf::MetricEvidenceScopeV1::physical_system));
      }
    } else {
      const auto target_scope =
          spec.payload_case == ReleasePayloadCase::direct
              ? mwperf::MetricTargetScopeV1::exact_request_targets
              : mwperf::MetricTargetScopeV1::ordered_metric_targets;
      auto primary = release_role(
          spec.primary_role, target_scope, result_scope,
          mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
      if (spec.primary_role ==
          mwperf::MetricSupportRoleV1::temporal_continuation_law) {
        primary.internal_relations.push_back(
            {mwperf::MetricRoleRelationKindV1::binding,
             mwperf::InternalReferencePurposeV1::selection_binding});
      }
      if (spec.payload_case == ReleasePayloadCase::finite_coupled &&
          coupling_override ==
              mwperf::TargetCouplingV1::full_schedule_identity) {
        primary.internal_relations.push_back(
            {mwperf::MetricRoleRelationKindV1::binding,
             mwperf::InternalReferencePurposeV1::full_schedule});
      }
      roles.push_back(std::move(primary));
      roles.push_back(release_role(
          mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
          target_scope, mwperf::MetricResultScopeV1::not_a_metric_result,
          mwperf::MetricEvidenceScopeV1::validity_or_lift));
    }

    mwperf::MetricParameterDomainV1 parameter_domain =
        spec.payload_case == ReleasePayloadCase::direct
            ? mwperf::MetricParameterDomainV1{
                  mwperf::ExactMetricDecoderDomainV1{
                      mwperf::ExactMetricDecoderKeyV1(
                          release_label("c15.release.exact.decoder")),
                      requested.origin.parameters}}
            : mwperf::MetricParameterDomainV1{
                  mwperf::ExactMetricParameterSetV1{
                      {requested.origin.parameters}}};
    const auto selection = spec.transient
                               ? mwperf::SelectionKindV1::transient_initial
                               : mwperf::SelectionKindV1::stationary_unique;
    const auto error_promise =
        response_envelope
            ? (physical
                   ? mwperf::StructuralErrorPromiseV1{
                         mwperf::StructuralErrorFormV1::physical_transfer_bound,
                         mwperf::MetricEvidenceScopeV1::physical_system,
                         std::nullopt}
                   : mwperf::StructuralErrorPromiseV1{
                         mwperf::StructuralErrorFormV1::validity_witness,
                         mwperf::MetricEvidenceScopeV1::validity_or_lift,
                         std::nullopt})
            : mwperf::StructuralErrorPromiseV1{
                  mwperf::StructuralErrorFormV1::exact,
                  mwperf::MetricEvidenceScopeV1::none,
                  mwperf::ExactRational::zero()};
    const auto target_coupling = coupling_override.value_or(
        spec.coupled ? mwperf::TargetCouplingV1::common_schedule_projection
                     : mwperf::TargetCouplingV1::scalar_target);
    clauses.push_back(mwperf::MetricSupportClauseV1{
        requested.origin.clause_id,
        requested.origin.kind,
        std::move(parameter_domain),
        std::move(targets),
        target_coupling,
        release_state_fields(spec.payload_case),
        release_marks(spec.payload_case),
        {{selection}, {}, {}},
        {mwperf::PayloadPhaseKindV1::phase_free,
         mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
         std::nullopt,
         mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
         std::nullopt},
        {spec.payload_tag, 1U},
        spec.semantic,
        spec.access,
        {},
        {},
        spec.solver,
        release_accuracy(spec.solver),
        error_promise,
        result_scope,
        {mwperf::V0DeclarationKindV1::structural_witness_required,
         "c15.release.v0", 1U},
        std::move(roles)});
  }
  auto manifest =
      mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
  INFO((manifest ? std::string{}
                 : manifest.error().code + ": " + manifest.error().message));
  REQUIRE(manifest);
  return std::move(manifest).value();
}

[[nodiscard]] mwperf::PlugDescriptorCore release_full_path_descriptor(
    const ReleaseFullPathSpec& spec,
    const mwperf::ProviderIdentityV1& provider,
    const mwperf::MetricSupportManifest& manifest) {
  const auto& clause = manifest.clauses().front();
  const bool physical =
      clause.result_scope == mwperf::MetricResultScopeV1::physical_bound;
  const auto result_scope =
      spec.payload_case == ReleasePayloadCase::response_envelope
          ? (physical ? mwperf::ConstructionResultScopeV1::physical_bound
                      : mwperf::ConstructionResultScopeV1::response_envelope)
          : mwperf::ConstructionResultScopeV1::surrogate_law;
  const auto error_scope =
      spec.payload_case == ReleasePayloadCase::response_envelope
          ? (physical ? mwperf::ConstructionErrorScopeV1::physical_system
                      : mwperf::ConstructionErrorScopeV1::validity_or_lift)
          : mwperf::ConstructionErrorScopeV1::deployed_surrogate_law;
  std::vector<mwperf::OptionalReportedEvidenceV1> optional_evidence;
  if (physical) {
    optional_evidence.push_back(
        {mwperf::OptionalReportedEvidenceKindV1::physical_fidelity,
         "c15.release.physical-transfer", 1U});
  }
  mwperf::PlugDescriptorCore descriptor{
      1U,
      provider,
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      {spec.payload_tag, 1U},
      spec.semantic,
      spec.access,
      clause.ordered_targets,
      clause.target_coupling,
      clause.state_fields,
      clause.marks,
      clause.selection_domain,
      clause.phase_domain,
      {mwperf::TailRepresentationKindV1::exact_unbounded, std::nullopt,
       std::nullopt},
      clause.arrival_assumptions,
      clause.hypotheses,
      clause.mandatory_v0,
      std::move(optional_evidence),
      {clause.requested_accuracy},
      {result_scope, error_scope},
      manifest.canonical_digest(),
      release_digest("c15.release.descriptor.placeholder")};
  auto digest = mwperf::canonical_plug_descriptor_core_digest_v1(descriptor);
  REQUIRE(digest);
  descriptor.core_digest = std::move(digest).value();
  return descriptor;
}

[[nodiscard]] mwperf::SurrogateProviderManifestV1
release_full_path_provider_manifest(
    const ReleaseFullPathSpec& spec,
    const mwperf::ProviderIdentityV1& provider,
    const mwperf::MetricSupportManifest& manifest) {
  std::vector<mwperf::MetricSupportRoleV1> allowed_roles;
  for (const auto& role : manifest.clauses().front().required_roles) {
    allowed_roles.push_back(role.role);
  }
  std::sort(allowed_roles.begin(), allowed_roles.end(),
            [](const auto left, const auto right) {
              return mwperf::metric_support_role_rank_v1(left) <
                     mwperf::metric_support_role_rank_v1(right);
            });
  std::vector<mwperf::RegisteredAnalyticFamilyContractV1> analytic;
  if (spec.payload_case == ReleasePayloadCase::analytic) {
    analytic.push_back({"c15.release.analytic", 1U,
                        "c15.release.analytic.parameters", 1U,
                        "c15.release.analytic.domain", 1U});
  }
  std::vector<mwperf::RegisteredRuntimeRecipeContractV1> recipes;
  if (spec.payload_case == ReleasePayloadCase::runtime_recipe) {
    recipes.push_back({"c15.release.runtime", 1U,
                       "c15.release.runtime.parameters", 1U,
                       "c15.release.runtime.state", 1U,
                       "c15.release.runtime.mark", 1U});
  }
  std::optional<mwperf::LocalExecutableDeclarationV1> executable;
  if (spec.mode == mwperf::ProducerModeV1::local_executable_builder) {
    executable = mwperf::LocalExecutableDeclarationV1{
        "c15.release.builder", 1U,
        {"--request", "{request_path}", "--result", "{result_path}"},
        true};
  }
  mwperf::SurrogateProviderManifestV1 result{
      1U,
      provider,
      false,
      release_digest(std::string(spec.name) + ".source"),
      spec.method,
      spec.mode,
      spec.semantic,
      spec.access,
      {spec.payload_tag, 1U},
      1U,
      release_digest(std::string(spec.name) + ".parameter-schema"),
      {1U},
      {1U},
      {1U},
      {},
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      {manifest.clauses().front().ordered_targets.size(),
       manifest.clauses().front().ordered_targets.size(),
       {manifest.clauses().front().target_coupling}, {}},
      manifest,
      std::move(allowed_roles),
      {{"c15.release.evidence", 1U, 4096U}},
      {{"c15.release.evidence", 1U, 1U,
        release_label(std::string(spec.name) + ".conformance"),
        release_digest(std::string(spec.name) + ".conformance")}},
      {1U,
       {mwperf::PointDeploymentPolicyV1::not_applicable},
       {mwperf::CoefficientCompletionPolicyV1::not_applicable},
       {mwperf::ProjectionPolicyV1::not_applicable},
       {mwperf::RecodingPolicyV1::not_applicable},
       {mwperf::EvidenceRolePolicyV1::exact_manifest_roles},
       std::move(analytic),
       std::move(recipes)},
      std::move(executable),
      {1U << 20U, 1U << 20U},
      release_digest("c15.release.manifest.placeholder")};
  auto digest = mwperf::digest_provider_manifest_v1(result);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  result.manifest_digest = std::move(digest).value();
  return result;
}

[[nodiscard]] mwperf::ConstructionBudget release_construction_budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct ReleaseBoundRequest final {
  ReleaseFullPathSpec spec;
  ReleaseFullPathInput input;
  mwperf::SurrogateProviderManifestV1 raw_manifest;
  mwperf::ValidatedProviderManifest manifest;
  mwperf::FrameworkProblemView view;
  mwperf::MetricSupportManifest structural_manifest;
  mwperf::AcceptedCapabilityContract contract;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::ConstructionBudget budget;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] ReleaseBoundRequest release_bound_request(
    const ReleaseFullPathSpec& spec, const std::uint64_t seed,
    const std::optional<mwperf::TargetCouplingV1> coupling_override =
        std::nullopt,
    const ReleaseEnvelopeContractKind envelope_contract =
        ReleaseEnvelopeContractKind::response) {
  auto input = make_release_full_path_input(spec);
  auto structural_manifest =
      release_full_path_manifest(spec, input.requirements,
                                 coupling_override, envelope_contract);
  const auto provider =
      release_provider("c15.release.path." + std::string(spec.name));
  auto raw_manifest = release_full_path_provider_manifest(
      spec, provider, structural_manifest);
  auto validated_manifest = mwperf::validate_provider_manifest(raw_manifest);
  INFO((validated_manifest
            ? std::string{}
            : validated_manifest.error().code + ": " +
                  validated_manifest.error().message));
  REQUIRE(validated_manifest);

  const auto targets = structural_manifest.clauses().front().ordered_targets;
  const mwperf::TargetSelection target_selection{
      1U, targets,
      mwperf::ConstructionGroupIdV1(
          release_label(std::string(spec.name) + ".group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, target_selection);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);

  const auto parameter_bytes = release_bytes("{}");
  auto parameter_digest =
      mwperf::digest_surrogate_parameter_values_v1(parameter_bytes);
  REQUIRE(parameter_digest);
  auto parameters = ReleaseFactory::validated_parameters(
      provider, raw_manifest.parameter_schema_version,
      raw_manifest.parameter_schema_digest, parameter_bytes);
  auto budget = release_construction_budget();
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const mwperf::PreviewPoliciesV1 policies{
      mwperf::PointDeploymentPolicyV1::not_applicable,
      mwperf::CoefficientCompletionPolicyV1::not_applicable,
      mwperf::ProjectionPolicyV1::not_applicable,
      mwperf::RecodingPolicyV1::not_applicable,
      mwperf::EvidenceRolePolicyV1::exact_manifest_roles};
  auto contract = ReleaseFactory::accepted_contract(
      raw_manifest,
      release_full_path_descriptor(spec, provider, structural_manifest),
      structural_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {}, targets, policies,
      {{}, std::nullopt, std::nullopt, std::nullopt},
      view.value().canonical_digest().value(), parameter_digest.value(),
      budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      validated_manifest.value(), view.value(), contract, parameters, budget,
      mwperf::MasterSeed(seed));
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  return {spec,
          std::move(input),
          std::move(raw_manifest),
          std::move(validated_manifest).value(),
          std::move(view).value(),
          std::move(structural_manifest),
          std::move(contract),
          std::move(parameters),
          std::move(budget),
          std::move(request).value()};
}

[[nodiscard]] const std::array<ReleaseFullPathSpec, 10U>&
release_full_path_specs() {
  static const std::array<ReleaseFullPathSpec, 10U> specs{{
      {ReleasePayloadCase::analytic,
       "analytic",
       R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json",
       mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
       mwperf::SemanticTagV1::stationary_marked_edge,
       mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
       mwperf::SolverRegimeV1::analytic,
       mwperf::ConstructionMethodV1::closed_form,
       mwperf::ProducerModeV1::inline_immediate,
       mwperf::MetricSupportRoleV1::stationary_marked_edge_law, false,
       false},
      {ReleasePayloadCase::finite_stationary,
       "finite-stationary",
       R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::stationary_marked_edge,
       mwperf::RuntimeAccessTagV1::finite_enumerated_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_deterministic,
       mwperf::ProducerModeV1::in_process_builder,
       mwperf::MetricSupportRoleV1::stationary_marked_edge_law, false,
       false},
      {ReleasePayloadCase::finite_staged,
       "finite-staged",
       R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::staged_opportunity_flux_law,
       mwperf::RuntimeAccessTagV1::sparse_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_hybrid,
       mwperf::ProducerModeV1::local_executable_builder,
       mwperf::MetricSupportRoleV1::staged_opportunity_flux_law, false,
       false},
      {ReleasePayloadCase::finite_temporal,
       "finite-temporal",
       R"json({"id":"persistence","kind":"service_persistence","parameters":{}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::temporal_one_slot_continuation,
       mwperf::RuntimeAccessTagV1::finite_enumerated_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_deterministic,
       mwperf::ProducerModeV1::in_process_builder,
       mwperf::MetricSupportRoleV1::temporal_continuation_law, false,
       false},
      {ReleasePayloadCase::finite_stopped,
       "finite-stopped",
       R"json({"id":"hit","kind":"first_hit","parameters":{"set":{"kind":"equal","level":1},"horizon":2,"include_mean":false}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::stopped_path_law,
       mwperf::RuntimeAccessTagV1::finite_enumerated_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_hybrid,
       mwperf::ProducerModeV1::local_executable_builder,
       mwperf::MetricSupportRoleV1::stopped_path_law, false, true},
      {ReleasePayloadCase::finite_residence,
       "finite-residence",
       R"json({"id":"gap","kind":"event_gap_distribution","parameters":{"event":"departure","horizon":2}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::romr_residence_word_law,
       mwperf::RuntimeAccessTagV1::finite_enumerated_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_deterministic,
       mwperf::ProducerModeV1::in_process_builder,
       mwperf::MetricSupportRoleV1::residence_word_law, false, false},
      {ReleasePayloadCase::finite_coupled,
       "finite-coupled",
       R"json({"id":"joint","kind":"joint_backlog_event","parameters":{"relation":"any_at_or_above","thresholds":[1,1]}})json",
       mwperf::PayloadClassTagV1::finite_law_tables_v1,
       mwperf::SemanticTagV1::coupled_target_schedule_law,
       mwperf::RuntimeAccessTagV1::finite_enumerated_row,
       mwperf::SolverRegimeV1::enumerated,
       mwperf::ConstructionMethodV1::engineered_hybrid,
       mwperf::ProducerModeV1::local_executable_builder,
       mwperf::MetricSupportRoleV1::coupled_schedule_law, true, false},
      {ReleasePayloadCase::runtime_recipe,
       "runtime",
       R"json({"id":"gap","kind":"event_gap_distribution","parameters":{"event":"departure","horizon":2}})json",
       mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
       mwperf::SemanticTagV1::romr_residence_word_law,
       mwperf::RuntimeAccessTagV1::procedural_residence_generator,
       mwperf::SolverRegimeV1::analytic,
       mwperf::ConstructionMethodV1::sampled_offline,
       mwperf::ProducerModeV1::in_process_builder,
       mwperf::MetricSupportRoleV1::residence_word_law, false, false},
      {ReleasePayloadCase::response_envelope,
       "envelope",
       R"json({"id":"conditioned","kind":"backlog_conditioned_service","parameters":{"levels":[0]}})json",
       mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
       mwperf::SemanticTagV1::response_envelope_law,
       mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
       mwperf::SolverRegimeV1::analytic,
       mwperf::ConstructionMethodV1::engineered_hybrid,
       mwperf::ProducerModeV1::local_executable_builder,
       mwperf::MetricSupportRoleV1::response_envelope, false, false},
      {ReleasePayloadCase::direct,
       "direct",
       R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json",
       mwperf::PayloadClassTagV1::direct_metric_payload_v1,
       mwperf::SemanticTagV1::direct_metric_decoder,
       mwperf::RuntimeAccessTagV1::direct_metric_decoder,
       mwperf::SolverRegimeV1::direct,
       mwperf::ConstructionMethodV1::precomputed,
       mwperf::ProducerModeV1::inline_immediate,
       mwperf::MetricSupportRoleV1::direct_metric_value, false, false},
  }};
  return specs;
}

[[nodiscard]] bool release_route_has_arrival_need(
    const mwperf::MetricRouteAlternativeV1& route,
    const mwperf::ArrivalNeedKindV1 kind) {
  return std::any_of(
      route.arrival.all_of.begin(), route.arrival.all_of.end(),
      [kind](const mwperf::ArrivalAssumptionV1& assumption) {
        return assumption.kind == kind;
      });
}

[[nodiscard]] const mwperf::MetricRouteAlternativeV1&
release_three_bin_composition_route(
    const mwperf::MetricRequirements& requirements,
    const mwperf::ConfiguredArrivalCompositionV1 composition) {
  REQUIRE(requirements.clauses().size() == 1U);
  const auto& routes = requirements.clauses().front().route_alternatives;
  const auto found = std::find_if(
      routes.begin(), routes.end(), [&](const auto& route) {
        if (route.access.runtime_access !=
                mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family ||
            route.access.backend_route !=
                mwperf::BackendRouteKindV1::stationary_invariant) {
          return false;
        }
        const bool iid = release_route_has_arrival_need(
            route, mwperf::ArrivalNeedKindV1::exact_iid_late);
        const bool predictive = release_route_has_arrival_need(
            route, mwperf::ArrivalNeedKindV1::predictive_phase);
        return composition ==
                       mwperf::ConfiguredArrivalCompositionV1::
                           iid_late_arrival
                   ? iid && !predictive
                   : predictive && !iid;
      });
  REQUIRE(found != routes.end());
  return *found;
}

[[nodiscard]] std::vector<mwperf::StateFieldDescriptorV1>
release_three_bin_composition_state_fields(
    const mwperf::ConfiguredArrivalCompositionV1 composition) {
  std::vector<mwperf::StateFieldDescriptorV1> fields{
      {mwperf::StateFieldKindV1::target_backlog,
       mwperf::FieldOwnershipV1::framework_exact,
       {"queue.big_nat", 1U}}};
  if (composition ==
      mwperf::ConfiguredArrivalCompositionV1::
          finite_enumerated_predictive_phase) {
    fields.push_back(
        {mwperf::StateFieldKindV1::configured_arrival_predictive_phase,
         mwperf::FieldOwnershipV1::framework_exact,
         {"arrival.phase", 1U}});
  }
  return fields;
}

[[nodiscard]] std::vector<mwperf::MarkDescriptorV1>
release_three_bin_composition_marks(
    const mwperf::MetricRouteAlternativeV1& route) {
  std::vector<mwperf::MarkDescriptorV1> marks;
  marks.reserve(route.marks.size());
  for (const auto& required : route.marks) {
    std::string codec;
    switch (required.kind) {
      case mwperf::MetricMarkKindV1::target_backlog:
        codec = "queue.big_nat";
        break;
      case mwperf::MetricMarkKindV1::opportunity:
        codec = "service.bit";
        break;
      case mwperf::MetricMarkKindV1::predictive_phase:
        codec = "arrival.phase";
        break;
      default:
        FAIL("unexpected mark in stationary scalar composition route");
    }
    marks.push_back(
        {required.kind, required.latest_reveal_stage,
         {std::move(codec), 1U},
         required.relation == mwperf::MarkRelationRequirementV1::individual
             ? std::string{}
             : std::string{"c15.release.composed-edge"}});
  }
  return marks;
}

[[nodiscard]] std::vector<mwperf::MetricSupportRoleRequirementV1>
release_three_bin_composition_roles() {
  mwperf::MetricSupportRoleRequirementV1 deployed_payload{
      mwperf::MetricSupportRoleV1::deployed_payload,
      mwperf::MetricTargetScopeV1::payload_targets,
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::MetricEvidenceScopeV1::none,
      {},
      {}};
  mwperf::MetricSupportRoleRequirementV1 deployed_response{
      mwperf::MetricSupportRoleV1::deployed_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::MetricEvidenceScopeV1::deployed_surrogate_law,
      {{mwperf::MetricRoleRelationKindV1::binding,
        mwperf::MetricSupportRoleV1::deployed_payload},
       {mwperf::MetricRoleRelationKindV1::subject,
        mwperf::MetricSupportRoleV1::raw_response}},
      {}};
  mwperf::MetricSupportRoleRequirementV1 raw_response{
      mwperf::MetricSupportRoleV1::raw_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::proposal_raw,
      mwperf::MetricEvidenceScopeV1::raw_static_proposal,
      {{mwperf::MetricRoleRelationKindV1::binding,
        mwperf::MetricSupportRoleV1::deployed_payload}},
      {{mwperf::MetricRoleRelationKindV1::lineage_parent,
        mwperf::InternalReferencePurposeV1::coefficient_origin}}};
  auto validity = release_role(
          mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
          mwperf::MetricTargetScopeV1::deployed_singleton_target,
          mwperf::MetricResultScopeV1::not_a_metric_result,
          mwperf::MetricEvidenceScopeV1::validity_or_lift);
  return {std::move(deployed_payload), std::move(deployed_response),
          std::move(raw_response), std::move(validity)};
}

[[nodiscard]] mwperf::MetricSupportManifest
release_three_bin_composition_manifest(
    const mwperf::MetricRequirements& requirements,
    const mwperf::ConfiguredArrivalCompositionV1 composition) {
  REQUIRE(requirements.clauses().size() == 1U);
  const auto& requested = requirements.clauses().front();
  const auto& route =
      release_three_bin_composition_route(requirements, composition);
  std::vector<mwperf::QueueId> targets;
  for (const auto& target : requested.origin.ordered_targets) {
    targets.push_back(target.queue_id);
  }
  std::vector<mwperf::HypothesisClaimV1> hypotheses;
  hypotheses.reserve(route.hypotheses.size());
  for (const auto& requirement : route.hypotheses) {
    hypotheses.push_back(requirement.claim);
  }
  const bool predictive =
      composition == mwperf::ConfiguredArrivalCompositionV1::
                             finite_enumerated_predictive_phase;
  const mwperf::PhaseSupportV1 phase{
      mwperf::PayloadPhaseKindV1::phase_free,
      composition,
      predictive,
      predictive ? std::optional<mwperf::CodecIdentityV1>{
                       mwperf::CodecIdentityV1{"arrival.phase", 1U}}
                 : std::nullopt,
      mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
      std::nullopt};
  auto manifest = mwperf::MetricSupportManifest::from_clauses({{
      requested.origin.clause_id,
      requested.origin.kind,
      mwperf::ExactMetricParameterSetV1{{requested.origin.parameters}},
      std::move(targets),
      mwperf::TargetCouplingV1::scalar_target,
      release_three_bin_composition_state_fields(composition),
      release_three_bin_composition_marks(route),
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      phase,
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      route.arrival.all_of,
      std::move(hypotheses),
      mwperf::SolverRegimeV1::analytic,
      requested.accuracy.contract,
      {mwperf::StructuralErrorFormV1::exact,
       mwperf::MetricEvidenceScopeV1::none, mwperf::ExactRational::zero()},
      mwperf::MetricResultScopeV1::surrogate_law,
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.release.composition.v0", 1U},
      release_three_bin_composition_roles()}});
  INFO((manifest ? std::string{}
                 : manifest.error().code + ": " + manifest.error().message));
  REQUIRE(manifest);
  return std::move(manifest).value();
}

[[nodiscard]] mwperf::PlugDescriptorCore
release_three_bin_composition_descriptor(
    const mwperf::MetricSupportManifest& manifest,
    const std::string& provider_id) {
  const auto& clause = manifest.clauses().front();
  mwperf::PlugDescriptorCore descriptor{
      1U,
      release_provider(provider_id),
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      clause.payload_class,
      clause.semantic,
      clause.runtime_access,
      clause.ordered_targets,
      clause.target_coupling,
      clause.state_fields,
      clause.marks,
      clause.selection_domain,
      clause.phase_domain,
      {mwperf::TailRepresentationKindV1::constant_response,
       mwperf::BigNat{3U}, std::nullopt},
      clause.arrival_assumptions,
      clause.hypotheses,
      clause.mandatory_v0,
      {},
      {clause.requested_accuracy},
      {mwperf::ConstructionResultScopeV1::surrogate_law,
       mwperf::ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest.canonical_digest(),
      release_digest("c15.release.composition.descriptor.placeholder")};
  auto digest = mwperf::canonical_plug_descriptor_core_digest_v1(descriptor);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  descriptor.core_digest = std::move(digest).value();
  return descriptor;
}

[[nodiscard]] mwperf::PlugDescriptorPreview
release_three_bin_composition_preview(
    const mwperf::MetricSupportManifest& manifest,
    const std::string& provider_id) {
  auto shared_manifest =
      std::make_shared<const mwperf::MetricSupportManifest>(manifest);
  mwperf::PlugDescriptorPreview preview{
      1U,
      release_three_bin_composition_descriptor(manifest, provider_id),
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      manifest.clauses().front().ordered_targets,
      {mwperf::PointDeploymentPolicyV1::deploy_raw_point,
       mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
       mwperf::ProjectionPolicyV1::not_applicable,
       mwperf::RecodingPolicyV1::not_applicable,
       mwperf::EvidenceRolePolicyV1::exact_manifest_roles},
      {{}, std::nullopt, std::nullopt, std::nullopt},
      std::move(shared_manifest),
      release_digest("c15.release.composition.problem"),
      release_digest("c15.release.composition.parameters"),
      release_digest("c15.release.composition.budget"),
      release_digest("c15.release.composition.preview.placeholder")};
  auto digest = mwperf::canonical_plug_descriptor_preview_digest_v1(preview);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  preview.preview_digest = std::move(digest).value();
  return preview;
}

[[nodiscard]] mwperf::ProviderConformanceReportRef
release_three_bin_composition_conformance(
    const mwperf::ProviderIdentityV1& provider) {
  return {1U,
          release_label("c15.release.composition.conformance"),
          release_digest("c15.release.composition.conformance"),
          provider,
          release_digest("c15.release.composition.scientific-contract"),
          "c15.release.composition.evidence",
          1U};
}

[[nodiscard]] mwperf::CoefficientIdentificationV1
release_three_bin_composition_identification(
    const mwperf::ProviderIdentityV1& provider, const std::string& prefix,
    const mwperf::ThreeBinCoefficientV1 bin,
    const mwperf::PortableScientificScalar& point) {
  mwperf::CoefficientIdentificationV1 identification{
      release_object(prefix + ".coefficient." +
                     std::to_string(static_cast<unsigned int>(bin))),
      {mwperf::ProposalConditioningSourceV1::exact_population,
       release_scalar(1, 1), std::nullopt},
      {mwperf::PopulationConditioningStatusV1::proved_positive,
       mwperf::RawValueStatusV1::exact_point},
      point,
      {},
      release_three_bin_composition_conformance(provider),
      std::nullopt,
      bin};
  auto digest =
      mwperf::artifact::detail::coefficient_identification_digest_v1(
          identification);
  REQUIRE(digest);
  identification.coefficient_id.object_digest = std::move(digest).value();
  return identification;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1
release_three_bin_composition_payload(
    const mwperf::Digest256& configured_arrival_binding,
    const std::string& prefix, const mwperf::ProviderIdentityV1& provider) {
  const auto target = release_queue("q0");
  std::array<mwperf::CoefficientIdentificationV1, 3U> identifications{
      release_three_bin_composition_identification(
          provider, prefix, mwperf::ThreeBinCoefficientV1::one,
          release_scalar(1, 4)),
      release_three_bin_composition_identification(
          provider, prefix, mwperf::ThreeBinCoefficientV1::two,
          release_scalar(3, 4)),
      release_three_bin_composition_identification(
          provider, prefix, mwperf::ThreeBinCoefficientV1::tail_from_three,
          release_scalar(1, 2))};
  mwperf::RawResponseProductV1 raw{
      ReleaseFactory::raw_response_product_id(
          release_object(prefix + ".raw")),
      provider,
      release_digest(prefix + ".request"),
      target,
      configured_arrival_binding,
      release_digest(prefix + ".proposal-law"),
      std::move(identifications)};
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(raw);
  REQUIRE(raw_digest);
  raw.product_id = ReleaseFactory::raw_response_product_id(
      {release_label(prefix + ".raw"), std::move(raw_digest).value()});
  const auto deployed = raw.product_id;
  mwperf::ThreeBinScalarResponseV1 response{
      1U,
      release_object(prefix + ".row"),
      target,
      configured_arrival_binding,
      std::move(raw),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      deployed,
      {}};
  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
  return response;
}

[[nodiscard]] bool release_c19_composition_is_eligible(
    const mwperf::AcceptedCapabilityContract& contract) {
  if (contract.semantic() != mwperf::SemanticTagV1::scalar_backlog_response ||
      contract.runtime_access() !=
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family ||
      contract.structural_manifest().clauses().size() != 1U) {
    return false;
  }
  const auto& clause = contract.structural_manifest().clauses().front();
  const auto has_assumption = [&](const mwperf::ArrivalNeedKindV1 kind) {
    return std::any_of(
        clause.arrival_assumptions.begin(), clause.arrival_assumptions.end(),
        [kind](const mwperf::ArrivalAssumptionV1& assumption) {
          return assumption.kind == kind;
        });
  };
  const bool has_iid_hypothesis = std::any_of(
      clause.hypotheses.begin(), clause.hypotheses.end(),
      [](const mwperf::HypothesisClaimV1& claim) {
        return claim.kind == mwperf::HypothesisKindV1::iid_late_arrival;
      });
  return clause.phase_domain.payload_phase ==
             mwperf::PayloadPhaseKindV1::phase_free &&
         clause.phase_domain.arrival_composition ==
             mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival &&
         !clause.phase_domain.retains_configured_predictive_phase &&
         has_assumption(mwperf::ArrivalNeedKindV1::exact_iid_late) &&
         has_iid_hypothesis &&
         contract.arrival_capabilities().exact_iid_joint_vector.has_value();
}


[[nodiscard]] mwperf::FiniteParameterAnalyticDataV1
release_analytic_payload(const ReleaseBoundRequest& fixture) {
  return {1U,
          "c15.release.analytic",
          1U,
          "c15.release.analytic.parameters",
          1U,
          "c15.release.analytic.domain",
          1U,
          fixture.manifest.value().provider,
          fixture.structural_manifest.clauses().front().ordered_targets,
          {{"alpha", release_scalar(1, 2)}},
          {{"kernel", std::vector<mwperf::PortableScientificScalar>{
                          release_scalar(1, 4), release_scalar(3, 4)}}},
          {{"backlog", release_scalar(0, 1), release_scalar(4, 1), true,
            true}},
          fixture.contract.descriptor_core().state_fields,
          {release_object(std::string(fixture.spec.name) + ".law")}};
}

[[nodiscard]] mwperf::RegisteredRuntimeRecipeV1 release_runtime_payload(
    const ReleaseBoundRequest& fixture) {
  return {1U,
          "c15.release.runtime",
          1U,
          "c15.release.runtime.parameters",
          1U,
          "c15.release.runtime.state",
          1U,
          "c15.release.runtime.mark",
          1U,
          fixture.manifest.value().provider,
          fixture.structural_manifest.clauses().front().ordered_targets,
          {{"rate", release_scalar(1, 2)}},
          fixture.contract.descriptor_core().state_fields,
          fixture.contract.descriptor_core().marks};
}

[[nodiscard]] mwperf::FiniteLawRowV1 release_finite_row(
    const std::string& name, const mwperf::TypedLabel& conditioning,
    const mwperf::FiniteRowConditioningStageV1 stage,
    const mwperf::TypedLabel& successor,
    std::vector<mwperf::TypedLabel> marks,
    std::optional<mwperf::CommonScheduleRealizationV1> schedule =
        std::nullopt) {
  return {release_label(name), conditioning, stage,
          {{successor, std::move(marks), release_scalar(1, 1),
            std::move(schedule)}}};
}

[[nodiscard]] mwperf::FiniteLawTablesV1 release_finite_payload(
    const ReleaseBoundRequest& fixture,
    const mwperf::ArtifactObjectReferenceV1& completion_evidence) {
  const auto& spec = fixture.spec;
  const auto s0 = release_label("s0");
  const auto active = release_label("active");
  const auto terminal = release_label("terminal");
  const auto pre = release_label("a-pre");
  const auto post = release_label("z-post");
  const auto m0 = release_label("m0");

  std::vector<mwperf::PortableFiniteDictionaryEntryV1> states{
      {s0, {release_scalar(0, 1)}}};
  std::vector<mwperf::PortableFiniteDictionaryEntryV1> marks{
      {m0, {release_scalar(0, 1)}}};
  std::optional<mwperf::FiniteLawTableAlternativeV1> table;

  switch (spec.payload_case) {
    case ReleasePayloadCase::finite_stationary: {
      marks.front().coordinates.push_back(release_scalar(0, 1));
      table = mwperf::StationaryMarkedEdgeTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          mwperf::FiniteTableStorageV1::dense,
          {release_finite_row(std::string(spec.name) + ".row", s0,
                              mwperf::FiniteRowConditioningStageV1::
                                  stationary_edge,
                              s0, {m0})},
          {"queue.big_nat", 1U},
          {"arrival.phase", 1U},
          {"service.bit", 1U},
          {"queue.big_nat", 1U},
          fixture.view.fingerprints().target_selection};
      break;
    }
    case ReleasePayloadCase::finite_staged: {
      states = {{pre, {release_scalar(0, 1)}},
                {post, {release_scalar(0, 1), release_scalar(0, 1)}}};
      table = mwperf::StagedOpportunityFluxTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          mwperf::FiniteTableStorageV1::sparse,
          {pre},
          {post},
          {release_finite_row(std::string(spec.name) + ".pre-row", pre,
                              mwperf::FiniteRowConditioningStageV1::prearrival,
                              post, {m0})},
          {release_finite_row(std::string(spec.name) + ".post-row", post,
                              mwperf::FiniteRowConditioningStageV1::postarrival,
                              pre, {m0})},
          fixture.view.fingerprints().compiled_arrival,
          {"arrival.innovation", 1U},
          release_object(std::string(spec.name) + ".update"),
          release_object(std::string(spec.name) + ".retained"),
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival,
           mwperf::MetricRevealStageV1::completed_edge}};
      break;
    }
    case ReleasePayloadCase::finite_temporal: {
      table = mwperf::TemporalContinuationTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          mwperf::FiniteTableStorageV1::dense,
          {release_finite_row(
              std::string(spec.name) + ".row", s0,
              mwperf::FiniteRowConditioningStageV1::one_slot_current, s0,
              {m0})},
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival,
           mwperf::MetricRevealStageV1::completed_edge},
          {"arrival.phase", 1U},
          std::nullopt};
      break;
    }
    case ReleasePayloadCase::finite_stopped: {
      states = {{active, {release_scalar(0, 1)}},
                {terminal, {release_scalar(1, 1)}}};
      const mwperf::FinitePredictiveStoppingTablesV1 predictive{
          {},
          {release_finite_row(
              std::string(spec.name) + ".stop-row", active,
              mwperf::FiniteRowConditioningStageV1::stopped_continuation,
              terminal, {m0})},
          {release_finite_row(
              std::string(spec.name) + ".terminal-row", terminal,
              mwperf::FiniteRowConditioningStageV1::stopped_continuation,
              active, {})}};
      table = mwperf::StoppedPathTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          "hit.q0",
          {active},
          {active, terminal},
          {m0},
          false,
          predictive,
          release_scalar(0, 1),
          {}};
      break;
    }
    case ReleasePayloadCase::finite_residence: {
      table = mwperf::RomrResidenceWordTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          "departure.q0",
          {s0},
          {s0},
          {m0},
          std::vector<mwperf::ExplicitOrderedWordV1>{
              {s0, mwperf::BigNat{1U}, {m0}, s0, s0,
               release_scalar(1, 1)}},
          release_scalar(0, 1),
          {completion_evidence}};
      break;
    }
    case ReleasePayloadCase::finite_coupled: {
      const auto s00 = release_label("s00");
      const auto s11 = release_label("s11");
      const auto d00 = release_label("d00");
      const auto d11 = release_label("d11");
      states = {
          {s00, {release_scalar(0, 1), release_scalar(0, 1)}},
          {s11, {release_scalar(1, 1), release_scalar(1, 1)}}};
      marks = {
          {d00, {release_scalar(0, 1), release_scalar(0, 1)}},
          {d11, {release_scalar(1, 1), release_scalar(1, 1)}}};
      const mwperf::CommonScheduleRealizationV1 full_common{
          {release_queue("q0"), release_queue("q1")},
          {mwperf::BigNat{1U}, mwperf::BigNat{1U}},
          {mwperf::BigNat{1U}, mwperf::BigNat{1U}},
          {mwperf::BigNat{0U}, mwperf::BigNat{0U}},
          {1U, 1U},
          false,
          std::nullopt};
      const mwperf::CommonScheduleRealizationV1 empty_common{
          {},
          {},
          {mwperf::BigNat{0U}, mwperf::BigNat{0U}},
          {mwperf::BigNat{0U}, mwperf::BigNat{0U}},
          {0U, 0U},
          false,
          std::nullopt};
      auto binding =
          mwperf::artifact::detail::coupled_tie_phase_arrival_binding_v1(
              fixture.view);
      REQUIRE(binding);
      table = mwperf::CoupledCommonScheduleTableV1{
          1U,
          release_object(std::string(spec.name) + ".law"),
          mwperf::FiniteTableStorageV1::dense,
          {release_finite_row(
               std::string(spec.name) + ".a-full-row", s11,
               mwperf::FiniteRowConditioningStageV1::common_schedule, s00,
               {d11}, full_common),
           release_finite_row(
               std::string(spec.name) + ".z-empty-row", s00,
               mwperf::FiniteRowConditioningStageV1::common_schedule, s00,
               {d00}, empty_common)},
          fixture.view.fingerprints().constraint,
          std::move(binding).value()};
      break;
    }
    default:
      FAIL("release_finite_payload requires a finite payload case");
  }

  REQUIRE(table.has_value());
  auto digest =
      mwperf::artifact::detail::finite_law_table_digest_v1(*table);
  REQUIRE(digest);
  std::visit(
      [&](auto& selected) { selected.law_id.object_digest = digest.value(); },
      *table);
  return {1U,
          fixture.structural_manifest.clauses().front().ordered_targets,
          spec.semantic,
          spec.access,
          fixture.view.fingerprints().compiled_arrival,
          fixture.view.fingerprints().target_selection,
          std::move(states),
          std::move(marks),
          std::move(*table)};
}

[[nodiscard]] mwperf::DirectMetricPayloadV1 release_direct_payload(
    const ReleaseBoundRequest& fixture,
    const mwperf::ArtifactObjectReferenceV1& evidence) {
  const auto& clause = fixture.structural_manifest.clauses().front();
  auto requirements_digest =
      mwperf::canonical_metric_requirements_digest(fixture.input.requirements);
  REQUIRE(requirements_digest);
  mwperf::DirectMetricValueV1 value{
      release_object(std::string(fixture.spec.name) + ".value"),
      clause.clause_id,
      clause.ordered_targets,
      release_scalar(1, 2),
      fixture.request.request_digest().value(),
      std::move(requirements_digest).value(),
      fixture.view.fingerprints().target_selection,
      fixture.view.fingerprints().compiled_arrival,
      fixture.contract.contract_digest(),
      clause.selection_domain.kinds,
      clause.arrival_assumptions,
      clause.result_scope,
      mwperf::DirectMetricValidityBasisV1::exact_closed_form,
      {evidence}};
  auto digest = mwperf::artifact::detail::direct_metric_value_digest_v1(value);
  REQUIRE(digest);
  value.value_id.object_digest = std::move(digest).value();
  return {1U, {std::move(value)}};
}

[[nodiscard]] mwperf::CommonBuildReportV1 release_build_report(
    const ReleaseBoundRequest& fixture) {
  mwperf::CommonBuildReportV1 report{
      1U,
      release_label(std::string(fixture.spec.name) + ".report"),
      release_digest(std::string(fixture.spec.name) + ".report.placeholder"),
      fixture.request.request_digest().value(),
      fixture.contract.budget_digest(),
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {},
      {}};
  auto digest = mwperf::canonical_common_build_report_digest_v1(report);
  REQUIRE(digest);
  report.report_digest = std::move(digest).value();
  return report;
}

[[nodiscard]] mwperf::ProviderConformanceReportRef release_conformance(
    const ReleaseBoundRequest& fixture) {
  REQUIRE(fixture.manifest.value()
              .family_evidence_conformance_report_anchors.size() == 1U);
  const auto& anchor = fixture.manifest.value()
                           .family_evidence_conformance_report_anchors.front();
  return {anchor.report_schema_version,
          anchor.report_id,
          anchor.report_digest,
          fixture.manifest.value().provider,
          fixture.manifest.scientific_contract_digest().value(),
          anchor.family_evidence_schema_id,
          anchor.family_evidence_schema_version};
}

[[nodiscard]] const mwperf::MetricSupportRoleRequirementV1&
release_role_requirement(const ReleaseBoundRequest& fixture,
                         const mwperf::MetricSupportRoleV1 role) {
  const auto& roles = fixture.structural_manifest.clauses().front().required_roles;
  const auto found = std::find_if(
      roles.begin(), roles.end(), [role](const auto& requirement) {
        return requirement.role == role;
      });
  REQUIRE(found != roles.end());
  return *found;
}

struct ReleaseObjectSet final {
  mwperf::ArtifactObjectReferenceV1 payload;
  mwperf::ArtifactObjectReferenceV1 primary;
  mwperf::ArtifactObjectReferenceV1 family;
  mwperf::ArtifactObjectReferenceV1 validity;
};

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_role_subject(
    const mwperf::MetricSupportRoleV1 role,
    const ReleaseFullPathSpec& spec, const ReleaseObjectSet& objects) {
  if (role == mwperf::MetricSupportRoleV1::deployed_payload) {
    return objects.payload;
  }
  if (role == spec.primary_role) return objects.primary;
  if (role ==
      mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    return objects.validity;
  }
  FAIL("unsupported ordinary release-matrix role");
  return objects.payload;
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_internal_object(
    const ReleaseBoundRequest& fixture, const ReleaseObjectSet& objects,
    const mwperf::MetricSupportRoleV1 owner,
    const mwperf::InternalReferencePurposeV1 purpose) {
  const auto prefix = std::string(fixture.spec.name);
  switch (purpose) {
    case mwperf::InternalReferencePurposeV1::artifact_payload:
      return objects.payload;
    case mwperf::InternalReferencePurposeV1::law_or_result:
      return objects.primary;
    case mwperf::InternalReferencePurposeV1::validity_witness:
      return objects.family;
    case mwperf::InternalReferencePurposeV1::configured_arrival_binding:
      return {release_label(prefix + ".arrival-binding"),
              fixture.view.fingerprints().compiled_arrival};
    case mwperf::InternalReferencePurposeV1::selection_binding:
      return {release_label(prefix + ".selection-binding"),
              fixture.view.fingerprints().target_selection};
    case mwperf::InternalReferencePurposeV1::timing_binding:
      return {release_label(prefix + ".timing-binding"),
              fixture.view.fingerprints().tie_and_timing};
    case mwperf::InternalReferencePurposeV1::state_codec:
      return release_object(prefix + ".state-codec");
    case mwperf::InternalReferencePurposeV1::coordinate_codec:
      return release_object(prefix + ".coordinate-codec");
    case mwperf::InternalReferencePurposeV1::mark_codec:
      return release_object(prefix + ".mark-codec");
    case mwperf::InternalReferencePurposeV1::stage_law: {
      REQUIRE(owner ==
              mwperf::MetricSupportRoleV1::staged_opportunity_flux_law);
      break;
    }
    case mwperf::InternalReferencePurposeV1::normalized_request: {
      auto digest =
          mwperf::canonical_metric_requirements_digest(fixture.input.requirements);
      REQUIRE(digest);
      return {release_label(prefix + ".normalized-request"),
              std::move(digest).value()};
    }
    default:
      break;
  }
  return release_object(prefix + ".purpose." +
                        std::to_string(static_cast<unsigned int>(purpose)));
}

[[nodiscard]] std::vector<mwperf::RealizedRoleRelationV1>
release_role_relations(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseObjectSet& objects) {
  const auto clause = fixture.structural_manifest.clauses().front().clause_id;
  std::vector<mwperf::RealizedRoleRelationV1> result;
  result.reserve(requirement.role_relations.size());
  for (const auto& relation : requirement.role_relations) {
    result.push_back(
        {relation.relation,
         {clause, relation.other_role},
         release_role_subject(relation.other_role, fixture.spec, objects)});
  }
  return result;
}

[[nodiscard]] std::vector<mwperf::RealizedInternalReferenceV1>
release_internal_relations(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseObjectSet& objects,
    const std::optional<mwperf::ArtifactObjectReferenceV1>& stage_law =
        std::nullopt) {
  std::vector<mwperf::RealizedInternalReferenceV1> result;
  result.reserve(requirement.internal_relations.size());
  for (const auto& relation : requirement.internal_relations) {
    auto referenced =
        release_internal_object(fixture, objects, requirement.role,
                                relation.purpose);
    if (relation.purpose == mwperf::InternalReferencePurposeV1::stage_law) {
      REQUIRE(stage_law.has_value());
      referenced = *stage_law;
    }
    result.push_back({relation.relation, relation.purpose,
                      std::move(referenced)});
  }
  return result;
}

[[nodiscard]] std::vector<mwperf::ArtifactObjectReferenceV1>
release_relation_projection(
    const std::vector<mwperf::RealizedRoleRelationV1>& roles,
    const std::vector<mwperf::RealizedInternalReferenceV1>& internal,
    const mwperf::MetricRoleRelationKindV1 relation) {
  std::vector<mwperf::ArtifactObjectReferenceV1> result;
  for (const auto& item : roles) {
    if (item.relation == relation) result.push_back(item.referenced_object);
  }
  for (const auto& item : internal) {
    if (item.relation == relation) result.push_back(item.referenced_object);
  }
  std::sort(result.begin(), result.end());
  result.erase(std::unique(result.begin(), result.end()), result.end());
  return result;
}

[[nodiscard]] mwperf::RealizedReferenceCoreV1 release_realized_core(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseObjectSet& objects,
    const std::optional<mwperf::ArtifactObjectReferenceV1>& stage_law =
        std::nullopt) {
  return {fixture.structural_manifest.clauses().front().ordered_targets,
          requirement.target_scope,
          requirement.result_scope,
          requirement.evidence_scope,
          release_role_relations(fixture, requirement, objects),
          release_internal_relations(fixture, requirement, objects,
                                     stage_law)};
}

[[nodiscard]] mwperf::RealizedReferenceV1 release_realized_reference(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseObjectSet& objects,
    const std::optional<mwperf::ArtifactObjectReferenceV1>& stage_law =
        std::nullopt) {
  auto core = release_realized_core(fixture, requirement, objects, stage_law);
  const auto subject =
      release_role_subject(requirement.role, fixture.spec, objects);
  switch (requirement.role) {
    case mwperf::MetricSupportRoleV1::deployed_payload:
      return mwperf::DeployedPayloadReferenceV1{
          std::move(core), mwperf::ArtifactPayloadRef{subject}};
    case mwperf::MetricSupportRoleV1::stationary_marked_edge_law:
      return mwperf::StationaryMarkedEdgeLawReferenceV1{
          std::move(core), mwperf::StationaryMarkedEdgeLawRef{subject}};
    case mwperf::MetricSupportRoleV1::staged_opportunity_flux_law:
      return mwperf::StagedOpportunityFluxLawReferenceV1{
          std::move(core), mwperf::StagedOpportunityFluxLawRef{subject}};
    case mwperf::MetricSupportRoleV1::temporal_continuation_law:
      return mwperf::TemporalContinuationLawReferenceV1{
          std::move(core), mwperf::TemporalContinuationLawRef{subject}};
    case mwperf::MetricSupportRoleV1::residence_word_law:
      return mwperf::ResidenceWordLawReferenceV1{
          std::move(core), mwperf::ResidenceWordLawRef{subject}};
    case mwperf::MetricSupportRoleV1::stopped_path_law:
      return mwperf::StoppedPathLawReferenceV1{
          std::move(core), mwperf::StoppedPathLawRef{subject}};
    case mwperf::MetricSupportRoleV1::coupled_schedule_law:
      return mwperf::CoupledScheduleLawReferenceV1{
          std::move(core), mwperf::CoupledScheduleLawRef{subject}};
    case mwperf::MetricSupportRoleV1::direct_metric_value:
      return mwperf::DirectMetricValueReferenceV1{
          std::move(core), mwperf::DirectMetricValueRef{subject}};
    case mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return mwperf::ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core),
          mwperf::ReportedValidityOrLiftEvidenceRef{subject}};
    default:
      FAIL("unsupported ordinary release-matrix realized role");
  }
  return mwperf::DeployedPayloadReferenceV1{
      std::move(core), mwperf::ArtifactPayloadRef{subject}};
}

[[nodiscard]] mwperf::FamilyEvidenceEnvelopeV1 release_family_evidence(
    const ReleaseBoundRequest& fixture, const ReleaseObjectSet& objects,
    const mwperf::Digest256& payload_digest) {
  const auto body = release_bytes(R"json({"claim":"valid"})json");
  auto body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(body);
  REQUIRE(body_digest);
  std::vector<mwperf::ArtifactObjectReferenceV1> subjects{objects.payload,
                                                          objects.primary};
  std::sort(subjects.begin(), subjects.end());
  subjects.erase(std::unique(subjects.begin(), subjects.end()), subjects.end());
  mwperf::FamilyEvidenceEnvelopeV1 evidence{
      1U,
      objects.family,
      "c15.release.evidence",
      1U,
      release_conformance(fixture),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.request.request_digest().value(),
      payload_digest,
      std::move(subjects),
      {},
      std::vector<mwperf::QueueId>(
          fixture.contract.construction_target_scope().begin(),
          fixture.contract.construction_target_scope().end()),
      mwperf::MetricEvidenceScopeV1::validity_or_lift,
      body,
      std::move(body_digest).value()};
  auto digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(evidence);
  REQUIRE(digest);
  evidence.evidence_id.object_digest = std::move(digest).value();
  return evidence;
}

[[nodiscard]] mwperf::ScopedArtifactEvidenceV1 release_validity_evidence(
    const ReleaseBoundRequest& fixture, const ReleaseObjectSet& objects,
    const mwperf::ArtifactObjectReferenceV1& family,
    const std::optional<mwperf::ArtifactObjectReferenceV1>& stage_law =
        std::nullopt) {
  auto final_objects = objects;
  final_objects.family = family;
  const auto& requirement = release_role_requirement(
      fixture,
      mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
  const auto roles = release_role_relations(fixture, requirement, final_objects);
  auto internal = release_internal_relations(fixture, requirement,
                                             final_objects, stage_law);
  mwperf::ScopedArtifactEvidenceV1 evidence{
      final_objects.validity,
      mwperf::ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
      fixture.structural_manifest.clauses().front().ordered_targets,
      requirement.result_scope,
      requirement.evidence_scope,
      release_relation_projection(
          roles, internal, mwperf::MetricRoleRelationKindV1::subject),
      release_relation_projection(
          roles, internal, mwperf::MetricRoleRelationKindV1::lineage_parent),
      {family},
      std::move(internal)};
  auto digest =
      mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(evidence);
  REQUIRE(digest);
  evidence.evidence_id.object_digest = std::move(digest).value();
  return evidence;
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_primary_identity(
    const mwperf::ArtifactPayloadV1& payload,
    const mwperf::ArtifactObjectReferenceV1& payload_identity) {
  return std::visit(
      [&](const auto& selected) -> mwperf::ArtifactObjectReferenceV1 {
        using Selected = std::decay_t<decltype(selected)>;
        if constexpr (std::same_as<Selected,
                                   mwperf::FiniteParameterAnalyticDataV1>) {
          return selected.transform_or_response_identities.front();
        } else if constexpr (std::same_as<Selected,
                                          mwperf::FiniteLawTablesV1>) {
          return std::visit([](const auto& table) { return table.law_id; },
                            selected.table);
        } else if constexpr (std::same_as<
                                 Selected,
                                 mwperf::RegisteredRuntimeRecipeV1>) {
          return payload_identity;
        } else if constexpr (std::same_as<Selected,
                                          mwperf::DirectMetricPayloadV1>) {
          return selected.values.front().value_id;
        } else {
          FAIL("unsupported ordinary release payload");
        }
        return payload_identity;
      },
      payload);
}

void release_rebind_late_evidence(
    mwperf::ArtifactPayloadV1& payload,
    const mwperf::ArtifactObjectReferenceV1& evidence) {
  if (auto* finite = std::get_if<mwperf::FiniteLawTablesV1>(&payload)) {
    if (auto* residence =
            std::get_if<mwperf::RomrResidenceWordTableV1>(&finite->table)) {
      REQUIRE(residence->complete_mass_termination_evidence.size() == 1U);
      residence->complete_mass_termination_evidence.front() = evidence;
    }
    if (auto* coupled =
            std::get_if<mwperf::CoupledCommonScheduleTableV1>(
                &finite->table)) {
      for (auto& row : coupled->common_joint_rows) {
        for (auto& atom : row.atoms) {
          if (atom.common_schedule.has_value() &&
              atom.common_schedule->projection_witness.has_value()) {
            atom.common_schedule->projection_witness = evidence;
          }
        }
      }
    }
  }
  if (auto* direct = std::get_if<mwperf::DirectMetricPayloadV1>(&payload)) {
    REQUIRE(direct->values.size() == 1U);
    REQUIRE(direct->values.front().evidence_ids.size() == 1U);
    direct->values.front().evidence_ids.front() = evidence;
  }
}

struct ReleaseBuiltFixture final {
  mwperf::CommonBuildReportV1 report;
  mwperf::ValidatedSurrogateBuildReport validated_report;
  mwperf::BuiltSurrogateResultV1 result;
};

using ReleasePayloadMutation = void (*)(mwperf::ArtifactPayloadV1&);

void release_reseal_payload_owned_identities(
    mwperf::ArtifactPayloadV1& payload) {
  if (auto* finite = std::get_if<mwperf::FiniteLawTablesV1>(&payload)) {
    auto digest =
        mwperf::artifact::detail::finite_law_table_digest_v1(finite->table);
    REQUIRE(digest);
    std::visit(
        [&](auto& table) { table.law_id.object_digest = digest.value(); },
        finite->table);
  }
  if (auto* direct = std::get_if<mwperf::DirectMetricPayloadV1>(&payload)) {
    for (auto& value : direct->values) {
      auto digest =
          mwperf::artifact::detail::direct_metric_value_digest_v1(value);
      REQUIRE(digest);
      value.value_id.object_digest = std::move(digest).value();
    }
  }
}

[[nodiscard]] ReleaseBuiltFixture release_ordinary_built_fixture(
    const ReleaseBoundRequest& fixture,
    const ReleasePayloadMutation mutation = nullptr) {
  REQUIRE(fixture.spec.payload_case != ReleasePayloadCase::response_envelope);
  const auto validity_placeholder =
      release_object(std::string(fixture.spec.name) + ".validity");
  mwperf::ArtifactPayloadV1 payload = [&]() -> mwperf::ArtifactPayloadV1 {
    switch (fixture.spec.payload_case) {
      case ReleasePayloadCase::analytic:
        return release_analytic_payload(fixture);
      case ReleasePayloadCase::runtime_recipe:
        return release_runtime_payload(fixture);
      case ReleasePayloadCase::direct:
        return release_direct_payload(fixture, validity_placeholder);
      case ReleasePayloadCase::finite_stationary:
      case ReleasePayloadCase::finite_staged:
      case ReleasePayloadCase::finite_temporal:
      case ReleasePayloadCase::finite_stopped:
      case ReleasePayloadCase::finite_residence:
      case ReleasePayloadCase::finite_coupled:
        return release_finite_payload(fixture, validity_placeholder);
      case ReleasePayloadCase::response_envelope:
        break;
    }
    FAIL("unsupported ordinary release payload");
    return release_runtime_payload(fixture);
  }();
  if (mutation != nullptr) mutation(payload);
  release_reseal_payload_owned_identities(payload);

  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(payload_digest);
  ReleaseObjectSet objects{
      {release_label(std::string(fixture.spec.name) + ".payload"),
       payload_digest.value()},
      release_object(std::string(fixture.spec.name) + ".primary.placeholder"),
      release_object(std::string(fixture.spec.name) + ".family"),
      validity_placeholder};
  objects.primary = release_primary_identity(payload, objects.payload);
  auto family = release_family_evidence(fixture, objects,
                                        payload_digest.value());
  objects.family = family.evidence_id;

  std::optional<mwperf::ArtifactObjectReferenceV1> stage_law;
  if (const auto* finite =
          std::get_if<mwperf::FiniteLawTablesV1>(&payload)) {
    if (const auto* staged =
            std::get_if<mwperf::StagedOpportunityFluxTableV1>(
                &finite->table)) {
      stage_law = staged->deterministic_update_descriptor;
    }
  }
  auto scoped =
      release_validity_evidence(fixture, objects, family.evidence_id,
                                stage_law);
  objects.validity = scoped.evidence_id;
  release_rebind_late_evidence(payload, scoped.evidence_id);
  auto rebound_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(rebound_digest);
  REQUIRE(rebound_digest.value() == payload_digest.value());

  std::vector<mwperf::RealizedMetricBindingV1> bindings;
  for (const auto& requirement :
       fixture.structural_manifest.clauses().front().required_roles) {
    bindings.push_back(
        {{fixture.structural_manifest.clauses().front().clause_id,
          requirement.role},
         release_realized_reference(fixture, requirement, objects,
                                    stage_law)});
  }

  const auto report = release_build_report(fixture);
  mwperf::SurrogateArtifactV1 artifact{
      1U,
      fixture.request.request_digest().value(),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.contract.construction_method(),
      fixture.contract.producer_mode(),
      fixture.contract.semantic(),
      fixture.contract.runtime_access(),
      fixture.contract.payload_class(),
      objects.payload,
      std::move(payload),
      payload_digest.value(),
      release_manifest_echo(fixture.structural_manifest),
      {fixture.request.request_digest().value(), payload_digest.value(),
       std::move(bindings)},
      fixture.contract.descriptor_core(),
      report,
      {std::move(family)},
      {std::move(scoped)},
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};
  return {report, ReleaseFactory::validated_build_report(report),
          {std::move(envelope), std::move(artifact)}};
}

[[nodiscard]] const ReleaseFullPathSpec& release_spec(
    const ReleasePayloadCase payload_case) {
  const auto& specs = release_full_path_specs();
  const auto found = std::find_if(
      specs.begin(), specs.end(), [payload_case](const auto& spec) {
        return spec.payload_case == payload_case;
      });
  REQUIRE(found != specs.end());
  return *found;
}

[[nodiscard]] mwperf::ArtifactParseLimits release_parse_limits() {
  return {1U << 20U, 64U, 1U << 14U, 1U << 14U, 1U << 16U,
          1U << 16U, 8U << 20U};
}

}  // namespace

TEST_CASE(
    "C15 phase-free three-bin response composes with IID and predictive arrivals",
    "[c15][integration][release-matrix][arrival-composition]") {
  const ReleaseFullPathSpec spec{
      ReleasePayloadCase::analytic,
      "three-bin-composition",
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json",
      mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      mwperf::SolverRegimeV1::analytic,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      mwperf::MetricSupportRoleV1::deployed_response,
      false,
      false};
  auto input = make_release_full_path_input(spec);
  auto temporal_law = mwperf::testing::make_c09_correlated_fixture_law(
      input.instance.queues());
  auto iid_law = mwperf::testing::make_c09_correlated_fixture_law(
      input.instance.queues(), mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
  REQUIRE(temporal_law);
  REQUIRE(iid_law);
  const auto temporal_arrival =
      mwperf::builder_arrival_view(temporal_law.value());
  const auto iid_arrival = mwperf::builder_arrival_view(iid_law.value());

  CHECK_FALSE(temporal_arrival.digest() == iid_arrival.digest());
  CHECK_FALSE(temporal_arrival.iid_joint_table().has_value());
  CHECK(iid_arrival.iid_joint_table().has_value());
  CHECK(temporal_arrival.finite_phase().has_value());
  CHECK(temporal_arrival.transition_rows().has_value());
  CHECK(temporal_arrival.capabilities()
            .finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::available);
  CHECK(temporal_arrival.capabilities()
            .finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::available);

  const auto iid_manifest = release_three_bin_composition_manifest(
      input.requirements,
      mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival);
  const auto temporal_manifest = release_three_bin_composition_manifest(
      input.requirements,
      mwperf::ConfiguredArrivalCompositionV1::
          finite_enumerated_predictive_phase);
  const auto iid_preview = release_three_bin_composition_preview(
      iid_manifest, "c15.release.composition.iid");
  const auto temporal_preview = release_three_bin_composition_preview(
      temporal_manifest, "c15.release.composition.temporal");
  const auto iid_decision = mwperf::negotiate_capabilities(
      input.requirements, iid_preview, iid_arrival.capabilities());
  const auto temporal_decision = mwperf::negotiate_capabilities(
      input.requirements, temporal_preview, temporal_arrival.capabilities());
  if (!mwperf::capability_decision_is_accepted(iid_decision)) {
    const auto diagnostic = mwperf::explain_capability_failure(iid_decision);
    INFO(diagnostic.code + ": " + diagnostic.message);
  }
  if (!mwperf::capability_decision_is_accepted(temporal_decision)) {
    const auto diagnostic =
        mwperf::explain_capability_failure(temporal_decision);
    INFO(diagnostic.code + ": " + diagnostic.message);
  }
  REQUIRE(mwperf::capability_decision_is_accepted(iid_decision));
  REQUIRE(mwperf::capability_decision_is_accepted(temporal_decision));
  const auto* iid_contract =
      mwperf::accepted_capability_contract(iid_decision);
  const auto* temporal_contract =
      mwperf::accepted_capability_contract(temporal_decision);
  REQUIRE(iid_contract != nullptr);
  REQUIRE(temporal_contract != nullptr);
  REQUIRE(iid_contract->metric_contracts().size() == 1U);
  REQUIRE(temporal_contract->metric_contracts().size() == 1U);
  CHECK(iid_contract->metric_contracts().front().backend_route ==
        mwperf::BackendRouteKindV1::stationary_invariant);
  CHECK(temporal_contract->metric_contracts().front().backend_route ==
        mwperf::BackendRouteKindV1::stationary_invariant);

  const auto& temporal_descriptor = temporal_contract->descriptor_core();
  CHECK(iid_contract->semantic() ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(temporal_contract->semantic() ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(iid_contract->descriptor_core().phase.payload_phase ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(temporal_descriptor.phase.payload_phase ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(temporal_descriptor.phase.arrival_composition ==
        mwperf::ConfiguredArrivalCompositionV1::
            finite_enumerated_predictive_phase);
  CHECK(temporal_descriptor.phase.retains_configured_predictive_phase);
  CHECK(temporal_descriptor.phase.predictive_phase_codec ==
        std::optional<mwperf::CodecIdentityV1>{
            mwperf::CodecIdentityV1{"arrival.phase", 1U}});
  CHECK(std::any_of(
      temporal_descriptor.state_fields.begin(),
      temporal_descriptor.state_fields.end(), [](const auto& field) {
        return field.kind ==
                   mwperf::StateFieldKindV1::
                       configured_arrival_predictive_phase &&
               field.ownership == mwperf::FieldOwnershipV1::framework_exact &&
               field.codec == mwperf::CodecIdentityV1{"arrival.phase", 1U};
      }));

  const auto iid_payload = release_three_bin_composition_payload(
      iid_arrival.digest().value(), "c15.release.composition.iid",
      iid_preview.core.provider);
  const auto temporal_payload = release_three_bin_composition_payload(
      temporal_arrival.digest().value(), "c15.release.composition.temporal",
      temporal_preview.core.provider);
  CHECK_FALSE(iid_payload.configured_arrival_binding ==
              temporal_payload.configured_arrival_binding);
  for (std::size_t index = 0U;
       index < iid_payload.raw_response.identifications.size(); ++index) {
    CAPTURE(index);
    const auto& iid_identification =
        iid_payload.raw_response.identifications[index];
    const auto& temporal_identification =
        temporal_payload.raw_response.identifications[index];
    REQUIRE(iid_identification.raw_point.has_value());
    REQUIRE(temporal_identification.raw_point.has_value());
    CHECK(iid_identification.target_bin_binding ==
          static_cast<mwperf::ThreeBinCoefficientV1>(index));
    CHECK(temporal_identification.target_bin_binding ==
          iid_identification.target_bin_binding);
    CHECK(*temporal_identification.raw_point ==
          *iid_identification.raw_point);
  }
  CHECK(*iid_payload.raw_response.identifications[0U].raw_point ==
        release_scalar(1, 4));
  CHECK(*iid_payload.raw_response.identifications[1U].raw_point ==
        release_scalar(3, 4));
  CHECK(*iid_payload.raw_response.identifications[2U].raw_point ==
        release_scalar(1, 2));

  const auto iid_f05 = mwperf::validate_metric_support_manifest(
      iid_manifest, mwperf::ArtifactPayloadV1{iid_payload},
      iid_contract->descriptor_core());
  const auto temporal_f05 = mwperf::validate_metric_support_manifest(
      temporal_manifest, mwperf::ArtifactPayloadV1{temporal_payload},
      temporal_contract->descriptor_core());
  INFO((iid_f05 ? std::string{}
                : iid_f05.error().code + ": " + iid_f05.error().message));
  INFO((temporal_f05
            ? std::string{}
            : temporal_f05.error().code + ": " +
                  temporal_f05.error().message));
  REQUIRE(iid_f05);
  REQUIRE(temporal_f05);

  // This is only the C15 eligibility premise for the later F-C19-09
  // execution path.  C15 neither invokes nor implements that decoder.
  CHECK(release_c19_composition_is_eligible(*iid_contract));
  CHECK_FALSE(release_c19_composition_is_eligible(*temporal_contract));

  auto phase_conditioned = temporal_contract->descriptor_core();
  phase_conditioned.phase.payload_phase =
      mwperf::PayloadPhaseKindV1::predictive_phase_indexed;
  auto phase_digest =
      mwperf::canonical_plug_descriptor_core_digest_v1(phase_conditioned);
  REQUIRE(phase_digest);
  phase_conditioned.core_digest = std::move(phase_digest).value();
  const auto phase_rejected = mwperf::validate_metric_support_manifest(
      temporal_manifest, mwperf::ArtifactPayloadV1{temporal_payload},
      phase_conditioned);
  REQUIRE_FALSE(phase_rejected);
  CHECK(phase_rejected.error().code == "c15.three_bin_descriptor_mismatch");

  auto temporal_metric_clause = temporal_manifest.clauses().front();
  temporal_metric_clause.metric_kind = mwperf::MetricKindV1::service_persistence;
  temporal_metric_clause.parameter_domain =
      mwperf::ExactMetricParameterSetV1{
          {mwperf::ServicePersistenceParametersV1{}}};
  auto temporal_metric_manifest =
      mwperf::MetricSupportManifest::from_clauses(
          {std::move(temporal_metric_clause)});
  REQUIRE(temporal_metric_manifest);
  const auto temporal_metric_descriptor =
      release_three_bin_composition_descriptor(
          temporal_metric_manifest.value(),
          "c15.release.composition.false-temporal-metric");
  const auto metric_rejected = mwperf::validate_metric_support_manifest(
      temporal_metric_manifest.value(),
      mwperf::ArtifactPayloadV1{temporal_payload},
      temporal_metric_descriptor);
  REQUIRE_FALSE(metric_rejected);
  CHECK(metric_rejected.error().code ==
        "c15.metric_semantic_route_mismatch");
}


TEST_CASE("C15 release matrix completes every ordinary payload through F08",
          "[c15][integration][release-matrix]") {
  std::set<mwperf::ProducerModeV1> modes;
  std::set<mwperf::PayloadClassTagV1> payload_tags;
  std::uint64_t seed = 0xC150U;
  for (const auto& spec : release_full_path_specs()) {
    if (spec.payload_case == ReleasePayloadCase::response_envelope) continue;
    CAPTURE(spec.name);
    {
      auto fixture = release_bound_request(spec, seed++);
      const auto built = release_ordinary_built_fixture(fixture);
      auto bytes =
          mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
              mwperf::SurrogateBuildResultV1{built.result});
      REQUIRE(bytes);
      auto parsed = mwperf::parse_surrogate_build_result(
          bytes.value(), release_parse_limits());
      INFO((parsed ? std::string{}
                   : parsed.error().code + ": " + parsed.error().message));
      REQUIRE(parsed);
      auto validated = mwperf::validate_surrogate_build_result(
          parsed.value(), fixture.request, fixture.manifest,
          fixture.contract, built.validated_report);
      INFO((validated
                ? std::string{}
                : validated.error().code + ": " +
                      validated.error().message));
      REQUIRE(validated);
      const auto realized = mwperf::resolve_realized_metric_capabilities(
          validated.value(), fixture.input.requirements);
      const auto* capabilities =
          std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
      REQUIRE(capabilities != nullptr);
      REQUIRE(capabilities->satisfied_clauses.size() == 1U);
      CHECK(capabilities->satisfied_clauses.front() ==
            fixture.structural_manifest.clauses().front().clause_id);
      auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
      INFO((portable ? std::string{}
                     : portable.error().code + ": " +
                           portable.error().message));
      REQUIRE(portable);
      modes.insert(spec.mode);
      payload_tags.insert(spec.payload_tag);
    }
  }
  CHECK(modes ==
        std::set<mwperf::ProducerModeV1>{
            mwperf::ProducerModeV1::inline_immediate,
            mwperf::ProducerModeV1::in_process_builder,
            mwperf::ProducerModeV1::local_executable_builder});
  CHECK(payload_tags ==
        std::set<mwperf::PayloadClassTagV1>{
            mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
            mwperf::PayloadClassTagV1::finite_law_tables_v1,
            mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
            mwperf::PayloadClassTagV1::direct_metric_payload_v1});
}

TEST_CASE("C15 sparse stationary table completes F01 through F08",
          "[c15][integration][release-matrix]") {
  auto spec = release_spec(ReleasePayloadCase::finite_stationary);
  spec.name = "finite-stationary-sparse";
  spec.access = mwperf::RuntimeAccessTagV1::sparse_row;
  auto fixture = release_bound_request(spec, 0xC15E11U);
  const auto built = release_ordinary_built_fixture(
      fixture, [](mwperf::ArtifactPayloadV1& payload) {
        auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
        std::get<mwperf::StationaryMarkedEdgeTableV1>(finite.table).storage =
            mwperf::FiniteTableStorageV1::sparse;
      });
  auto bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{built.result});
  REQUIRE(bytes);
  auto parsed = mwperf::parse_surrogate_build_result(
      bytes.value(), release_parse_limits());
  REQUIRE(parsed);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), fixture.request, fixture.manifest, fixture.contract,
      built.validated_report);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);

  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), fixture.input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
  INFO((portable ? std::string{}
                 : portable.error().code + ": " +
                       portable.error().message));
  REQUIRE(portable);
  const auto* finite = std::get_if<mwperf::PortableFiniteLawTablesV1>(
      &portable.value().value());
  REQUIRE(finite != nullptr);
  CHECK(finite->context.runtime_access == mwperf::RuntimeAccessTagV1::sparse_row);
  const auto* stationary =
      std::get_if<mwperf::StationaryMarkedEdgeTableV1>(
          &finite->normalized_record.table);
  REQUIRE(stationary != nullptr);
  CHECK(stationary->storage == mwperf::FiniteTableStorageV1::sparse);
}

TEST_CASE("C15 multi-metric build outcomes remain transactional through F07",
          "[c15][integration][negative][release-matrix]") {
  auto spec = release_spec(ReleasePayloadCase::analytic);
  spec.name = "analytic-multi-metric";
  spec.metric_json =
      R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}},{"id":"empty","kind":"stationary_empty_probability","parameters":{}})json";
  auto fixture = release_bound_request(spec, 0xC15E30U);
  REQUIRE(fixture.input.requirements.clauses().size() == 2U);
  REQUIRE(fixture.structural_manifest.clauses().size() == 2U);

  const auto report = release_build_report(fixture);
  const auto trusted = ReleaseFactory::validated_build_report(report);
  const mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};
  const auto& requested = fixture.input.requirements.clauses();
  const mwperf::UnavailableReasonV1 invalidated{
      mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
      "c15.release.metric-evidence-unavailable",
      "one accepted metric lost its required post-build evidence",
      requested.front().origin.clause_id, std::nullopt};

  SECTION("one metric reason cannot publish a partial transaction") {
    const mwperf::UnavailableSurrogateResultV1 incomplete{
        envelope, {invalidated}, std::nullopt};
    auto rejected = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{incomplete}, fixture.request,
        fixture.manifest, fixture.contract, trusted);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.unavailable_incomplete_reasons");
  }

  SECTION("complete reasons preserve one Unavailable terminal outcome") {
    const mwperf::UnavailableReasonV1 transaction_companion{
        mwperf::UnavailableReasonKindV1::
            realized_capability_narrower_than_accepted,
        "c15.release.transaction-requires-all-metrics",
        "the otherwise realizable metric cannot be published separately",
        requested[1U].origin.clause_id, std::nullopt};
    const mwperf::UnavailableSurrogateResultV1 unavailable{
        envelope, {invalidated, transaction_companion}, std::nullopt};
    auto bytes =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{unavailable});
    REQUIRE(bytes);
    auto parsed = mwperf::parse_surrogate_build_result(
        bytes.value(), release_parse_limits());
    REQUIRE(parsed);
    auto validated = mwperf::validate_surrogate_build_result(
        parsed.value(), fixture.request, fixture.manifest, fixture.contract,
        trusted);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated.value(), fixture.input.requirements);
    const auto* terminal =
        std::get_if<mwperf::RealizedUnavailableCapabilitiesV1>(&realized);
    REQUIRE(terminal != nullptr);
    CHECK(terminal->reasons == unavailable.reasons);
    CHECK(std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized) ==
          nullptr);
  }

  SECTION("Built with only one clause's realized roles is rejected") {
    const auto narrowed = release_ordinary_built_fixture(fixture);
    REQUIRE(narrowed.result.artifact.realized_metric_bindings.bindings.size() ==
            fixture.structural_manifest.clauses().front().required_roles.size());
    auto rejected = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{narrowed.result}, fixture.request,
        fixture.manifest, fixture.contract, narrowed.validated_report);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "metric_binding_key_missing");
  }
}

TEST_CASE("C32 provider-result-v3 terminals reuse the released semantic validator",
          "[c15][c32][result-v3][unit]") {
  auto spec = release_spec(ReleasePayloadCase::analytic);
  spec.name = "analytic-v3-terminal-validation";
  spec.metric_json =
      R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}},{"id":"empty","kind":"stationary_empty_probability","parameters":{}})json";
  auto fixture = release_bound_request(spec, 0xC320U);
  REQUIRE(fixture.input.requirements.clauses().size() == 2U);
  const auto& clauses = fixture.input.requirements.clauses();
  const mwperf::UnavailableReasonV1 first_clause{
      mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
      "c32.fixture.evidence", "required evidence is unavailable",
      clauses.front().origin.clause_id, std::nullopt};
  const mwperf::UnavailableReasonV1 global_reason{
      mwperf::UnavailableReasonKindV1::unmet_construction_assumption,
      "c32.fixture.assumption", "a construction assumption was not met",
      std::nullopt, std::nullopt};

  SECTION("Unavailable cannot omit all reasons") {
    const mwperf::SurrogateBuildResultBranchV3 branch =
        mwperf::UnavailableSurrogateResultBodyV2{{}, std::nullopt};
    auto rejected = mwperf::validate_surrogate_build_terminal_v3(
        branch, fixture.contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.unavailable_empty_reasons");
  }

  SECTION("Unavailable cannot repeat an identical reason") {
    const mwperf::SurrogateBuildResultBranchV3 branch =
        mwperf::UnavailableSurrogateResultBodyV2{
            {global_reason, global_reason}, std::nullopt};
    auto rejected = mwperf::validate_surrogate_build_terminal_v3(
        branch, fixture.contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.unavailable_duplicate_reason");
  }

  SECTION("clause-scoped Unavailable covers the complete transaction") {
    const mwperf::SurrogateBuildResultBranchV3 branch =
        mwperf::UnavailableSurrogateResultBodyV2{{first_clause}, std::nullopt};
    auto rejected = mwperf::validate_surrogate_build_terminal_v3(
        branch, fixture.contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.unavailable_incomplete_reasons");
  }

  SECTION("Unavailable alternatives retain their closed nonempty shape") {
    const mwperf::SurrogateBuildResultBranchV3 branch =
        mwperf::UnavailableSurrogateResultBodyV2{
            {global_reason},
            mwperf::StrongestTruthfulAlternativeV1{
                "", std::nullopt, std::nullopt}};
    auto rejected = mwperf::validate_surrogate_build_terminal_v3(
        branch, fixture.contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.unavailable_alternative_shape");
  }

  SECTION("provider-authored Failed requires nonempty diagnostics") {
    const mwperf::SurrogateBuildResultBranchV3 branch =
        mwperf::FailedSurrogateResultBodyV2{
            mwperf::ProviderFailureV1{
                mwperf::ProviderFailureKindV1::construction_failure, "", ""}};
    auto rejected = mwperf::validate_surrogate_build_terminal_v3(
        branch, fixture.contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.provider_failure_shape");
  }
}

TEST_CASE("C15 release matrix rejects deep-invalid finite subtag bodies",
          "[c15][negative][release-matrix]") {
  struct Negative final {
    ReleasePayloadCase payload_case;
    const char* name;
    ReleasePayloadMutation mutation;
    const char* code;
  };
  const std::array<Negative, 9U> cases{{
      {ReleasePayloadCase::finite_staged,
       "omitted staged postarrival domain",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         std::get<mwperf::StagedOpportunityFluxTableV1>(finite.table)
             .postarrival_state_domain.clear();
       },
       "c15.staged_table_domains"},
      {ReleasePayloadCase::finite_stopped,
       "stopped terminal reentry outside entrance",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& table = std::get<mwperf::StoppedPathTableV1>(finite.table);
         auto& predictive =
             std::get<mwperf::FinitePredictiveStoppingTablesV1>(
                 table.representation);
         predictive.terminal_or_exit_rows.front()
             .atoms.front()
             .successor_state_id = release_label("terminal");
       },
       "c15.stopped_predictive_domain"},
      {ReleasePayloadCase::finite_residence,
       "residence word reentry outside entrance",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& table =
             std::get<mwperf::RomrResidenceWordTableV1>(finite.table);
         std::get<std::vector<mwperf::ExplicitOrderedWordV1>>(
             table.representation)
             .front()
             .successor_entry_id = release_label("foreign");
       },
       "c15.explicit_word_shape"},
      {ReleasePayloadCase::finite_coupled,
       "coupled common-schedule backlog mismatch",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& table =
             std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table);
         table.common_joint_rows.front()
             .atoms.front()
             .common_schedule->retained_target_backlogs.front() =
             mwperf::BigNat{1U};
       },
       "c15.common_schedule_retained_backlog_mismatch"},
      {ReleasePayloadCase::finite_residence,
       "ROMR positive nontermination mass",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& table =
             std::get<mwperf::RomrResidenceWordTableV1>(finite.table);
         table.nontermination_probability = release_scalar(1, 4);
       },
       "c15.residence_table_shape"},
      {ReleasePayloadCase::finite_stationary,
       "split duplicate finite atom",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& atoms =
             std::get<mwperf::StationaryMarkedEdgeTableV1>(finite.table)
                 .joint_edge_rows.front()
                 .atoms;
         atoms.front().probability = release_scalar(1, 2);
         atoms.push_back(atoms.front());
       },
       "c15.finite_atom_order"},
      {ReleasePayloadCase::finite_residence,
       "split duplicate explicit residence word",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& words = std::get<std::vector<mwperf::ExplicitOrderedWordV1>>(
             std::get<mwperf::RomrResidenceWordTableV1>(finite.table)
                 .representation);
         words.front().probability = release_scalar(1, 2);
         words.push_back(words.front());
       },
       "c15.explicit_word_shape"},
      {ReleasePayloadCase::finite_coupled,
       "omitted coupled common schedule",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table)
             .common_joint_rows.front()
             .atoms.front()
             .common_schedule.reset();
       },
       "c15.finite_atom_shape"},
      {ReleasePayloadCase::finite_coupled,
       "independent scalar atom replaces coupled realization",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& atom =
             std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table)
                 .common_joint_rows.front()
                 .atoms.front();
         atom = mwperf::FiniteLawAtomV1{
             atom.successor_state_id, atom.ordered_mark_ids,
             atom.probability, std::nullopt};
       },
       "c15.finite_atom_shape"},
  }};

  std::uint64_t seed = 0xC15F0U;
  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      auto fixture = release_bound_request(release_spec(test.payload_case),
                                           seed++);
      const auto built =
          release_ordinary_built_fixture(fixture, test.mutation);
      auto rejected = mwperf::validate_surrogate_build_result(
          mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
          fixture.manifest, fixture.contract, built.validated_report);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == test.code);
    }
  }
}

TEST_CASE("C15 direct payload rejects every resealed external binding mutation",
          "[c15][negative][release-matrix]") {
  struct Negative final {
    const char* name;
    ReleasePayloadMutation mutation;
    const char* code;
  };
  const std::array<Negative, 10U> cases{{
      {"metric clause identity",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .metric_clause_id.authored_index = 1U;
       },
       "c15.direct_value_clause_binding"},
      {"ordered target identity",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .ordered_targets.front() = release_queue("q1");
       },
       "c15.built_target_binding"},
      {"selection assumptions",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .selection_assumptions = {
             mwperf::SelectionKindV1::stationary_class};
       },
       "c15.direct_value_clause_binding"},
      {"arrival assumptions",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .arrival_assumptions.push_back(
                 {mwperf::ArrivalNeedKindV1::target_intensity,
                  mwperf::ArrivalCapabilityUseV1::runtime,
                  mwperf::CapabilityProvisionNeedV1::portable, std::nullopt,
                  false, false, std::nullopt, std::nullopt, std::nullopt});
       },
       "c15.direct_value_clause_binding"},
      {"result scope",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .result_scope = mwperf::MetricResultScopeV1::response_envelope;
       },
       "c15.direct_value_clause_binding"},
      {"request digest",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .request_digest = release_digest("foreign-request");
       },
       "c15.direct_value_context_binding"},
      {"normalized metric request digest",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .normalized_metric_request_digest =
             release_digest("foreign-normalized-request");
       },
       "c15.direct_value_context_binding"},
      {"target-selection digest",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .target_selection_digest = release_digest("foreign-targets");
       },
       "c15.direct_value_context_binding"},
      {"configured-arrival digest",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .configured_arrival_digest = release_digest("foreign-arrival");
       },
       "c15.direct_value_context_binding"},
      {"accepted-contract digest",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::DirectMetricPayloadV1>(payload)
             .values.front()
             .accepted_contract_digest = release_digest("foreign-contract");
       },
       "c15.direct_value_context_binding"},
  }};

  auto fixture =
      release_bound_request(release_spec(ReleasePayloadCase::direct),
                            0xC15F10U);
  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      const auto built =
          release_ordinary_built_fixture(fixture, test.mutation);
      auto rejected = mwperf::validate_surrogate_build_result(
          mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
          fixture.manifest, fixture.contract, built.validated_report);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == test.code);
    }
  }
}

TEST_CASE("C15 registered payloads reject every allowlist-key mutation",
          "[c15][negative][release-matrix]") {
  struct Negative final {
    ReleasePayloadCase payload_case;
    const char* name;
    ReleasePayloadMutation mutation;
    const char* code;
  };
  const std::array<Negative, 14U> cases{{
      {ReleasePayloadCase::analytic,
       "analytic family id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .registered_family_id = "c15.release.analytic.foreign";
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::analytic,
       "analytic family version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .registered_family_version = 2U;
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::analytic,
       "analytic parameter schema id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .parameter_schema_id = "c15.release.analytic.parameters.foreign";
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::analytic,
       "analytic parameter schema version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .parameter_schema_version = 2U;
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::analytic,
       "analytic domain schema id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .domain_schema_id = "c15.release.analytic.domain.foreign";
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::analytic,
       "analytic domain schema version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteParameterAnalyticDataV1>(payload)
             .domain_schema_version = 2U;
       },
       "c15.analytic_family_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime recipe id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .registered_recipe_id = "c15.release.runtime.foreign";
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime recipe version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .registered_recipe_version = 2U;
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime parameter schema id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .parameter_schema_id = "c15.release.runtime.parameters.foreign";
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime parameter schema version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .parameter_schema_version = 2U;
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime state codec schema id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .state_codec_schema_id = "c15.release.runtime.state.foreign";
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime state codec schema version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .state_codec_schema_version = 2U;
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime mark codec schema id",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .mark_codec_schema_id = "c15.release.runtime.mark.foreign";
       },
       "c15.runtime_recipe_not_registered"},
      {ReleasePayloadCase::runtime_recipe,
       "runtime mark codec schema version",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::RegisteredRuntimeRecipeV1>(payload)
             .mark_codec_schema_version = 2U;
       },
       "c15.runtime_recipe_not_registered"},
  }};

  std::uint64_t seed = 0xC15F20U;
  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      auto fixture = release_bound_request(release_spec(test.payload_case),
                                           seed++);
      const auto built =
          release_ordinary_built_fixture(fixture, test.mutation);
      auto rejected = mwperf::validate_surrogate_build_result(
          mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
          fixture.manifest, fixture.contract, built.validated_report);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == test.code);
    }
  }
}

TEST_CASE("C15 coupled rows bind vector dictionaries to every realization",
          "[c15][negative][release-matrix][coupled-dictionary]") {
  struct Negative final {
    const char* name;
    ReleasePayloadMutation mutation;
    const char* code;
  };
  const std::array<Negative, 10U> cases{{
      {"state dictionary uses scalar rather than target-vector arity",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.state_dictionary.front().coordinates.pop_back();
       },
       "c15.finite_dictionary_descriptor_shape"},
      {"mark dictionary uses scalar rather than target-vector arity",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.mark_dictionary.front().coordinates.pop_back();
       },
       "c15.finite_dictionary_descriptor_shape"},
      {"conditioning coordinate contradicts current backlog",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.state_dictionary.back().coordinates.front() =
             release_scalar(0, 1);
       },
       "c15.coupled_current_backlog_dictionary_mismatch"},
      {"successor coordinate contradicts retained backlog",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.state_dictionary.front().coordinates.front() =
             release_scalar(1, 1);
       },
       "c15.coupled_retained_backlog_dictionary_mismatch"},
      {"mark coordinate contradicts joint departure",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.mark_dictionary.back().coordinates.front() =
             release_scalar(0, 1);
       },
       "c15.coupled_departure_dictionary_mismatch"},
      {"one state label cannot mean unequal current and retained vectors",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& rows = std::get<mwperf::CoupledCommonScheduleTableV1>(
                          finite.table)
                          .common_joint_rows;
         rows.front().atoms.front().successor_state_id =
             rows.front().conditioning_state_id;
       },
       "c15.coupled_retained_backlog_dictionary_mismatch"},
      {"target backlog coordinate must be an exact integer",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.state_dictionary.back().coordinates.front() =
             release_scalar(1, 2);
       },
       "c15.coupled_current_backlog_dictionary_mismatch"},
      {"target backlog coordinate cannot be negative",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.state_dictionary.front().coordinates.front() =
             release_scalar(-1, 1);
       },
       "c15.coupled_retained_backlog_dictionary_mismatch"},
      {"actual-departure coordinate must be binary",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         finite.mark_dictionary.back().coordinates.front() =
             release_scalar(2, 1);
       },
       "c15.coupled_departure_dictionary_mismatch"},
      {"target-vector coordinates follow authored target order",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
         auto& rows = std::get<mwperf::CoupledCommonScheduleTableV1>(
                          finite.table)
                          .common_joint_rows;
         auto& full = *rows.front().atoms.front().common_schedule;
         auto& retained = *rows.back().atoms.front().common_schedule;
         full.selected_schedule_backlogs = {mwperf::BigNat{2U},
                                             mwperf::BigNat{1U}};
         full.current_target_backlogs = {mwperf::BigNat{2U},
                                         mwperf::BigNat{1U}};
         full.retained_target_backlogs = {mwperf::BigNat{1U},
                                          mwperf::BigNat{0U}};
         retained.current_target_backlogs = {mwperf::BigNat{1U},
                                             mwperf::BigNat{0U}};
         retained.retained_target_backlogs = {mwperf::BigNat{1U},
                                              mwperf::BigNat{0U}};
         finite.state_dictionary.front().coordinates = {
             release_scalar(1, 1), release_scalar(0, 1)};
         // Deliberately reverse only the full row's authored q0,q1 values.
         finite.state_dictionary.back().coordinates = {
             release_scalar(1, 1), release_scalar(2, 1)};
       },
       "c15.coupled_current_backlog_dictionary_mismatch"},
  }};

  std::uint64_t seed = 0xC15F30U;
  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      auto fixture = release_bound_request(
          release_spec(ReleasePayloadCase::finite_coupled), seed++);
      const auto built =
          release_ordinary_built_fixture(fixture, test.mutation);
      auto rejected = mwperf::validate_surrogate_build_result(
          mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
          fixture.manifest, fixture.contract, built.validated_report);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == test.code);
    }
  }

  SECTION("atoms in one conditional row share its exact current vector") {
    auto fixture = release_bound_request(
        release_spec(ReleasePayloadCase::finite_coupled), 0xC15F3AU);
    const auto built = release_ordinary_built_fixture(
        fixture, [](mwperf::ArtifactPayloadV1& payload) {
          auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
          auto& row = std::get<mwperf::CoupledCommonScheduleTableV1>(
                          finite.table)
                          .common_joint_rows.front();
          row.atoms.front().probability = release_scalar(1, 2);
          auto differing = row.atoms.front();
          differing.probability = release_scalar(1, 2);
          differing.common_schedule->selected_schedule_backlogs.front() =
              mwperf::BigNat{2U};
          differing.common_schedule->current_target_backlogs.front() =
              mwperf::BigNat{2U};
          differing.common_schedule->retained_target_backlogs.front() =
              mwperf::BigNat{1U};
          row.atoms.push_back(std::move(differing));
        });
    auto rejected = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
        fixture.manifest, fixture.contract, built.validated_report);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.coupled_current_backlog_dictionary_mismatch");
  }
}

TEST_CASE("C15 coupled payload rejects every ordered target mismatch",
          "[c15][integration][negative][release-matrix]") {
  struct Negative final {
    const char* name;
    ReleasePayloadMutation mutation;
  };
  const std::array<Negative, 4U> cases{{
      {"missing deployed target",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteLawTablesV1>(payload)
             .ordered_deployed_targets.pop_back();
       }},
      {"extra deployed target",
       [](mwperf::ArtifactPayloadV1& payload) {
         std::get<mwperf::FiniteLawTablesV1>(payload)
             .ordered_deployed_targets.push_back(release_queue("q2"));
       }},
      {"duplicate deployed target",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& targets = std::get<mwperf::FiniteLawTablesV1>(payload)
                             .ordered_deployed_targets;
         targets[1U] = targets[0U];
       }},
      {"reordered deployed targets",
       [](mwperf::ArtifactPayloadV1& payload) {
         auto& targets = std::get<mwperf::FiniteLawTablesV1>(payload)
                             .ordered_deployed_targets;
         std::swap(targets[0U], targets[1U]);
       }},
  }};

  std::uint64_t seed = 0xC15F20U;
  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      auto fixture = release_bound_request(
          release_spec(ReleasePayloadCase::finite_coupled), seed++);
      const auto built =
          release_ordinary_built_fixture(fixture, test.mutation);
      auto rejected = mwperf::validate_surrogate_build_result(
          mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
          fixture.manifest, fixture.contract, built.validated_report);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == "c15.built_target_binding");
    }
  }
}

TEST_CASE("C15 full-schedule coupling rejects projected schedule atoms",
          "[c15][integration][negative][release-matrix]") {
  const auto& spec = release_spec(ReleasePayloadCase::finite_coupled);

  SECTION("full-schedule identity accepts complete unwitnessed atoms") {
    auto fixture = release_bound_request(
        spec, 0xC15F10U,
        mwperf::TargetCouplingV1::full_schedule_identity);
    const auto built = release_ordinary_built_fixture(fixture);
    auto validated = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
        fixture.manifest, fixture.contract, built.validated_report);
    INFO((validated
              ? std::string{}
              : validated.error().code + ": " +
                    validated.error().message));
    REQUIRE(validated);
  }

  SECTION("full-schedule identity rejects a valid witnessed projection") {
    auto fixture = release_bound_request(
        spec, 0xC15F11U,
        mwperf::TargetCouplingV1::full_schedule_identity);
    const auto built = release_ordinary_built_fixture(
        fixture, [](mwperf::ArtifactPayloadV1& payload) {
          auto& finite = std::get<mwperf::FiniteLawTablesV1>(payload);
          auto& coupled =
              std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table);
          REQUIRE(coupled.common_joint_rows.size() == 2U);
          REQUIRE(coupled.common_joint_rows.front().atoms.size() == 1U);
          auto& schedule = coupled.common_joint_rows.front()
                               .atoms.front()
                               .common_schedule;
          REQUIRE(schedule.has_value());
          schedule->structurally_witnessed_projection = true;
          schedule->projection_witness =
              release_object("finite-coupled.validity");
        });

    const auto& finite =
        std::get<mwperf::FiniteLawTablesV1>(built.result.artifact.payload);
    const auto& coupled =
        std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table);
    const auto& schedule = coupled.common_joint_rows.front()
                               .atoms.front()
                               .common_schedule;
    REQUIRE(schedule.has_value());
    auto shape =
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            *schedule,
            fixture.structural_manifest.clauses().front().ordered_targets,
            fixture.view);
    INFO((shape ? std::string{}
                : shape.error().code + ": " + shape.error().message));
    REQUIRE(shape);

    auto rejected = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
        fixture.manifest, fixture.contract, built.validated_report);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.coupled_full_schedule_projection");
  }

  SECTION("projection coupling may retain a complete full-schedule atom") {
    auto fixture = release_bound_request(
        spec, 0xC15F12U,
        mwperf::TargetCouplingV1::common_schedule_projection);
    const auto built = release_ordinary_built_fixture(fixture);
    const auto& finite =
        std::get<mwperf::FiniteLawTablesV1>(built.result.artifact.payload);
    const auto& coupled =
        std::get<mwperf::CoupledCommonScheduleTableV1>(finite.table);
    const auto& schedule = coupled.common_joint_rows.front()
                               .atoms.front()
                               .common_schedule;
    REQUIRE(schedule.has_value());
    CHECK_FALSE(schedule->structurally_witnessed_projection);
    CHECK_FALSE(schedule->projection_witness.has_value());

    auto validated = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
        fixture.manifest, fixture.contract, built.validated_report);
    INFO((validated
              ? std::string{}
              : validated.error().code + ": " +
                    validated.error().message));
    REQUIRE(validated);
  }
}

namespace {

enum class ReleaseEnvelopeVariant : std::uint8_t {
  valid_distinct,
  valid_exact_alias,
  nested_raw_in_typed_components,
  family_in_typed_components,
  missing_raw_bound_binding,
  physical_without_transfer,
};

[[nodiscard]] mwperf::CoefficientIdentificationV1
release_envelope_identification(
    const ReleaseBoundRequest& fixture, const std::string& prefix,
    const mwperf::ThreeBinCoefficientV1 bin,
    const mwperf::PortableScientificScalar& point,
    const std::optional<mwperf::ArtifactObjectReferenceV1>& family) {
  mwperf::CoefficientIdentificationV1 result{
      release_object(prefix + ".coefficient." +
                     std::to_string(static_cast<unsigned int>(bin))),
      {mwperf::ProposalConditioningSourceV1::exact_population,
       release_scalar(1, 1), std::nullopt},
      {mwperf::PopulationConditioningStatusV1::proved_positive,
       mwperf::RawValueStatusV1::exact_point},
      point,
      family.has_value()
          ? std::vector<mwperf::ArtifactObjectReferenceV1>{*family}
          : std::vector<mwperf::ArtifactObjectReferenceV1>{},
      release_conformance(fixture),
      std::nullopt,
      bin};
  auto digest =
      mwperf::artifact::detail::coefficient_identification_digest_v1(result);
  REQUIRE(digest);
  result.coefficient_id.object_digest = std::move(digest).value();
  return result;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 release_envelope_response(
    const ReleaseBoundRequest& fixture, const std::string& prefix,
    const std::array<mwperf::PortableScientificScalar, 3U>& points,
    const mwperf::ArtifactObjectReferenceV1& raw_family,
    const bool carries_direct_raw_bound,
    const mwperf::RawEnvelopeScopeV1 raw_envelope_scope) {
  std::array<mwperf::CoefficientIdentificationV1, 3U> identifications{
      release_envelope_identification(
          fixture, prefix, mwperf::ThreeBinCoefficientV1::one, points[0U],
          carries_direct_raw_bound
              ? std::optional<mwperf::ArtifactObjectReferenceV1>{raw_family}
              : std::nullopt),
      release_envelope_identification(
          fixture, prefix, mwperf::ThreeBinCoefficientV1::two, points[1U],
          std::nullopt),
      release_envelope_identification(
          fixture, prefix, mwperf::ThreeBinCoefficientV1::tail_from_three,
          points[2U], std::nullopt)};
  const auto target = fixture.view.target_selection().ordered_targets.front();
  const auto proposal_digest = release_digest(prefix + ".proposal-law");
  mwperf::RawResponseProductV1 raw{
      ReleaseFactory::raw_response_product_id(
          release_object(prefix + ".raw")),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      target,
      fixture.view.fingerprints().compiled_arrival,
      proposal_digest,
      std::move(identifications)};
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(raw);
  REQUIRE(raw_digest);
  raw.product_id = ReleaseFactory::raw_response_product_id(
      {release_label(prefix + ".raw"), std::move(raw_digest).value()});

  std::vector<mwperf::RawResponseEnvelopeV1> envelopes;
  if (carries_direct_raw_bound) {
    mwperf::RawResponseEnvelopeV1 envelope{
        release_object(prefix + ".raw-bound"),
        raw.product_id,
        proposal_digest,
        {mwperf::ThreeBinCoefficientV1::one},
        {points[0U]},
        {points[0U]},
        "exact_population_identity",
        mwperf::RawEnvelopeCoverageV1::deterministic,
        mwperf::PopulationConditioningPremiseV1::unconditional,
        std::nullopt,
        std::nullopt,
        raw_envelope_scope,
        {raw_family}};
    auto envelope_digest =
        mwperf::artifact::detail::raw_response_envelope_digest_v1(envelope);
    REQUIRE(envelope_digest);
    envelope.envelope_id.object_digest =
        std::move(envelope_digest).value();
    envelopes.push_back(std::move(envelope));
  }

  mwperf::ThreeBinScalarResponseV1 response{
      1U,
      release_object(prefix + ".row"),
      target,
      fixture.view.fingerprints().compiled_arrival,
      std::move(raw),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      ReleaseFactory::raw_response_product_id(
          release_object(prefix + ".unreachable")),
      std::move(envelopes)};
  response.deployed_response_product_id = response.raw_response.product_id;
  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
  return response;
}

[[nodiscard]] mwperf::FamilyEvidenceEnvelopeV1 release_envelope_family(
    const ReleaseBoundRequest& fixture, const std::string& name,
    const mwperf::Digest256& payload_digest,
    const mwperf::MetricEvidenceScopeV1 scope,
    std::vector<mwperf::ArtifactObjectReferenceV1> subjects,
    std::vector<mwperf::ArtifactObjectReferenceV1> parents = {}) {
  std::sort(subjects.begin(), subjects.end());
  subjects.erase(std::unique(subjects.begin(), subjects.end()), subjects.end());
  std::sort(parents.begin(), parents.end());
  parents.erase(std::unique(parents.begin(), parents.end()), parents.end());
  const auto body =
      release_bytes(std::string("{\"claim\":\"") + name + "\"}");
  auto body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(body);
  REQUIRE(body_digest);
  mwperf::FamilyEvidenceEnvelopeV1 family{
      1U,
      release_object(name),
      "c15.release.evidence",
      1U,
      release_conformance(fixture),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.request.request_digest().value(),
      payload_digest,
      std::move(subjects),
      std::move(parents),
      std::vector<mwperf::QueueId>(
          fixture.contract.construction_target_scope().begin(),
          fixture.contract.construction_target_scope().end()),
      scope,
      body,
      std::move(body_digest).value()};
  auto digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(family);
  REQUIRE(digest);
  family.evidence_id.object_digest = std::move(digest).value();
  return family;
}

struct ReleaseEnvelopeObjects final {
  mwperf::ArtifactObjectReferenceV1 payload;
  mwperf::ArtifactObjectReferenceV1 raw;
  mwperf::ArtifactObjectReferenceV1 envelope;
  mwperf::ArtifactObjectReferenceV1 raw_bound;
  mwperf::ArtifactObjectReferenceV1 order;
  mwperf::ArtifactObjectReferenceV1 raw_family;
  mwperf::ArtifactObjectReferenceV1 order_family;
  mwperf::ArtifactObjectReferenceV1 coefficient;
  mwperf::ArtifactObjectReferenceV1 lower;
  mwperf::ArtifactObjectReferenceV1 upper;
  mwperf::ArtifactObjectReferenceV1 comparison;
  mwperf::ArtifactObjectReferenceV1 evaluation;
  mwperf::ArtifactObjectReferenceV1 proposal;
  mwperf::ArtifactObjectReferenceV1 physical;
  mwperf::ArtifactObjectReferenceV1 physical_family;
};

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_envelope_role_subject(
    const mwperf::MetricSupportRoleV1 role,
    const ReleaseEnvelopeObjects& objects) {
  switch (role) {
    case mwperf::MetricSupportRoleV1::deployed_payload:
      return objects.payload;
    case mwperf::MetricSupportRoleV1::raw_response:
      return objects.raw;
    case mwperf::MetricSupportRoleV1::response_envelope:
      return objects.envelope;
    case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
      return objects.raw_bound;
    case mwperf::MetricSupportRoleV1::response_order_evidence:
      return objects.order;
    case mwperf::MetricSupportRoleV1::physical_transfer_evidence:
      return objects.physical;
    default:
      FAIL("unsupported response-envelope role");
  }
  return objects.payload;
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 release_envelope_internal(
    const ReleaseBoundRequest& fixture,
    const mwperf::InternalReferencePurposeV1 purpose,
    const ReleaseEnvelopeObjects& objects) {
  switch (purpose) {
    case mwperf::InternalReferencePurposeV1::coefficient_origin:
      return objects.coefficient;
    case mwperf::InternalReferencePurposeV1::lower_response_product:
      return objects.lower;
    case mwperf::InternalReferencePurposeV1::upper_response_product:
      return objects.upper;
    case mwperf::InternalReferencePurposeV1::comparison_domain:
      return objects.comparison;
    case mwperf::InternalReferencePurposeV1::evaluation_identity:
      return objects.evaluation;
    case mwperf::InternalReferencePurposeV1::proposal_identity:
      return objects.proposal;
    case mwperf::InternalReferencePurposeV1::surrogate_source:
      return objects.payload;
    case mwperf::InternalReferencePurposeV1::error_object:
      return objects.physical_family;
    default:
      return release_object(std::string(fixture.spec.name) + ".purpose." +
                            std::to_string(
                                static_cast<unsigned int>(purpose)));
  }
}

[[nodiscard]] mwperf::RealizedReferenceCoreV1 release_envelope_core(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseEnvelopeObjects& objects) {
  std::vector<mwperf::RealizedRoleRelationV1> roles;
  for (const auto& relation : requirement.role_relations) {
    roles.push_back(
        {relation.relation,
         {fixture.structural_manifest.clauses().front().clause_id,
          relation.other_role},
         release_envelope_role_subject(relation.other_role, objects)});
  }
  std::vector<mwperf::RealizedInternalReferenceV1> internal;
  for (const auto& relation : requirement.internal_relations) {
    internal.push_back(
        {relation.relation, relation.purpose,
         release_envelope_internal(fixture, relation.purpose, objects)});
  }
  return {fixture.structural_manifest.clauses().front().ordered_targets,
          requirement.target_scope, requirement.result_scope,
          requirement.evidence_scope, std::move(roles),
          std::move(internal)};
}

[[nodiscard]] mwperf::RealizedReferenceV1 release_envelope_reference(
    const ReleaseBoundRequest& fixture,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const ReleaseEnvelopeObjects& objects) {
  auto core = release_envelope_core(fixture, requirement, objects);
  switch (requirement.role) {
    case mwperf::MetricSupportRoleV1::deployed_payload:
      return mwperf::DeployedPayloadReferenceV1{
          std::move(core), mwperf::ArtifactPayloadRef{objects.payload}};
    case mwperf::MetricSupportRoleV1::raw_response:
      return mwperf::RawResponseProductReferenceV1{
          std::move(core),
          mwperf::RawResponseProductRef{
              objects.raw,
              mwperf::ResponseProductValueFormV1::exact_point}};
    case mwperf::MetricSupportRoleV1::response_envelope:
      return mwperf::ResponseEnvelopeReferenceV1{
          std::move(core), mwperf::ResponseEnvelopeRef{objects.envelope}};
    case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
      return mwperf::RawResponseBoundEvidenceReferenceV1{
          std::move(core),
          mwperf::RawResponseBoundEvidenceRef{objects.raw_bound}};
    case mwperf::MetricSupportRoleV1::response_order_evidence:
      return mwperf::ResponseOrderEvidenceReferenceV1{
          std::move(core),
          mwperf::ResponseOrderEvidenceRef{objects.order}};
    case mwperf::MetricSupportRoleV1::physical_transfer_evidence:
      return mwperf::PhysicalTransferEvidenceReferenceV1{
          std::move(core),
          mwperf::PhysicalTransferEvidenceRef{objects.physical}};
    default:
      FAIL("unsupported response-envelope realized reference");
  }
  return mwperf::DeployedPayloadReferenceV1{
      std::move(core), mwperf::ArtifactPayloadRef{objects.payload}};
}

void release_replace_reference(
    mwperf::ArtifactObjectReferenceV1& reference,
    const mwperf::ArtifactObjectReferenceV1& prior,
    const mwperf::ArtifactObjectReferenceV1& replacement) {
  if (reference == prior) reference = replacement;
}

void release_rebind_envelope_family(
    mwperf::ResponseEnvelopeEvidenceV1& payload,
    const mwperf::ArtifactObjectReferenceV1& prior,
    const mwperf::ArtifactObjectReferenceV1& replacement) {
  const auto replace_in = [&](mwperf::ThreeBinScalarResponseV1& response) {
    for (auto& coefficient : response.raw_response.identifications) {
      for (auto& reference : coefficient.family_evidence_envelope_ids) {
        release_replace_reference(reference, prior, replacement);
      }
    }
    for (auto& envelope : response.raw_envelopes) {
      for (auto& reference : envelope.family_evidence_envelope_ids) {
        release_replace_reference(reference, prior, replacement);
      }
    }
  };
  replace_in(payload.lower_response);
  replace_in(payload.upper_response);
}

[[nodiscard]] ReleaseBuiltFixture release_envelope_built_fixture(
    const ReleaseBoundRequest& fixture,
    const ReleaseEnvelopeVariant variant) {
  REQUIRE(fixture.spec.payload_case == ReleasePayloadCase::response_envelope);
  const auto& clause = fixture.structural_manifest.clauses().front();
  const auto& raw_bound_requirement = release_role_requirement(
      fixture, mwperf::MetricSupportRoleV1::raw_response_bound_evidence);
  const bool optimizer_raw =
      raw_bound_requirement.evidence_scope ==
      mwperf::MetricEvidenceScopeV1::optimizer_interval_raw;
  const auto raw_envelope_scope =
      optimizer_raw ? mwperf::RawEnvelopeScopeV1::optimizer_interval_raw
                    : mwperf::RawEnvelopeScopeV1::proposal_raw;
  const bool physical_contract =
      clause.result_scope == mwperf::MetricResultScopeV1::physical_bound;
  const bool include_physical_transfer =
      physical_contract &&
      variant != ReleaseEnvelopeVariant::physical_without_transfer;
  const bool alias = variant == ReleaseEnvelopeVariant::valid_exact_alias;
  const auto raw_family_placeholder =
      release_object(std::string(fixture.spec.name) + ".raw-family");
  auto lower = release_envelope_response(
      fixture, std::string(fixture.spec.name) + ".lower",
      {release_scalar(1, 4), release_scalar(1, 2), release_scalar(1, 4)},
      raw_family_placeholder, true, raw_envelope_scope);
  auto upper = alias
                   ? lower
                   : release_envelope_response(
                         fixture, std::string(fixture.spec.name) + ".upper",
                         {release_scalar(1, 2), release_scalar(3, 4),
                          release_scalar(1, 2)},
                         raw_family_placeholder, false,
                         raw_envelope_scope);
  const auto order_placeholder =
      release_object(std::string(fixture.spec.name) + ".order");
  const auto physical_placeholder =
      release_object(std::string(fixture.spec.name) + ".physical-transfer");
  const auto raw_bound = lower.raw_envelopes.front().envelope_id;
  const auto raw = lower.raw_response.product_id.identity();
  const auto coefficient =
      lower.raw_response.identifications.front().coefficient_id;
  const auto lower_product =
      mwperf::deployed_response_product_identity_v1(
          lower.deployed_response_product_id);
  const auto upper_product =
      mwperf::deployed_response_product_identity_v1(
          upper.deployed_response_product_id);
  const auto comparison =
      release_object(std::string(fixture.spec.name) + ".comparison");

  std::vector<mwperf::ArtifactObjectReferenceV1> typed{order_placeholder};
  if (include_physical_transfer) {
    typed.push_back(physical_placeholder);
  }
  if (variant == ReleaseEnvelopeVariant::nested_raw_in_typed_components) {
    typed.push_back(raw_bound);
  } else if (variant ==
             ReleaseEnvelopeVariant::family_in_typed_components) {
    typed.push_back(raw_family_placeholder);
  }
  std::sort(typed.begin(), typed.end());
  mwperf::ResponseEnvelopeEvidenceV1 envelope_payload{
      1U,
      fixture.structural_manifest.clauses().front().ordered_targets,
      physical_contract ||
              variant == ReleaseEnvelopeVariant::physical_without_transfer
          ? mwperf::MetricResultScopeV1::physical_bound
          : mwperf::MetricResultScopeV1::response_envelope,
      physical_contract ||
              variant == ReleaseEnvelopeVariant::physical_without_transfer
          ? mwperf::MetricEvidenceScopeV1::physical_system
          : mwperf::MetricEvidenceScopeV1::validity_or_lift,
      std::move(lower),
      std::move(upper),
      ReleaseFactory::raw_response_product_id(lower_product),
      ReleaseFactory::raw_response_product_id(upper_product),
      comparison,
      std::move(typed),
      false,
      std::nullopt};
  // The selected nested products above are raw in this fixture.  Rebind from
  // their erased generic identities through the typed test seam.
  envelope_payload.lower_response_product =
      envelope_payload.lower_response.deployed_response_product_id;
  envelope_payload.upper_response_product =
      envelope_payload.upper_response.deployed_response_product_id;

  mwperf::ArtifactPayloadV1 payload = envelope_payload;
  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(payload_digest);
  const mwperf::ArtifactObjectReferenceV1 payload_identity{
      release_label(std::string(fixture.spec.name) + ".payload"),
      payload_digest.value()};

  auto raw_family = release_envelope_family(
      fixture, std::string(fixture.spec.name) + ".raw-family",
      payload_digest.value(), raw_bound_requirement.evidence_scope,
      {raw_bound, coefficient}, {raw});
  auto order_family = release_envelope_family(
      fixture, std::string(fixture.spec.name) + ".order-family",
      payload_digest.value(),
      mwperf::MetricEvidenceScopeV1::deployed_surrogate_law,
      {lower_product, upper_product});
  std::optional<mwperf::FamilyEvidenceEnvelopeV1> physical_family;
  if (include_physical_transfer) {
    physical_family = release_envelope_family(
        fixture, std::string(fixture.spec.name) + ".physical-family",
        payload_digest.value(), mwperf::MetricEvidenceScopeV1::physical_system,
        {payload_identity});
  }

  ReleaseEnvelopeObjects objects{
      payload_identity,
      raw,
      payload_identity,
      raw_bound,
      order_placeholder,
      raw_family.evidence_id,
      order_family.evidence_id,
      coefficient,
      lower_product,
      upper_product,
      comparison,
      release_object(std::string(fixture.spec.name) + ".evaluation"),
      {release_label(std::string(fixture.spec.name) + ".proposal"),
       envelope_payload.lower_response.raw_response.proposal_law_digest},
      physical_placeholder,
      physical_family.has_value()
          ? physical_family->evidence_id
          : release_object(std::string(fixture.spec.name) +
                           ".physical-family")};
  const auto& order_requirement = release_role_requirement(
      fixture, mwperf::MetricSupportRoleV1::response_order_evidence);
  auto order_core =
      release_envelope_core(fixture, order_requirement, objects);
  mwperf::ScopedArtifactEvidenceV1 order_evidence{
      order_placeholder,
      mwperf::ArtifactReferenceKindV1::response_order_evidence,
      fixture.structural_manifest.clauses().front().ordered_targets,
      order_requirement.result_scope,
      order_requirement.evidence_scope,
      release_relation_projection(
          order_core.role_relations, order_core.internal_relations,
          mwperf::MetricRoleRelationKindV1::subject),
      release_relation_projection(
          order_core.role_relations, order_core.internal_relations,
          mwperf::MetricRoleRelationKindV1::lineage_parent),
      {order_family.evidence_id},
      order_core.internal_relations};
  auto order_digest =
      mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(
          order_evidence);
  REQUIRE(order_digest);
  order_evidence.evidence_id.object_digest = std::move(order_digest).value();
  objects.order = order_evidence.evidence_id;

  std::optional<mwperf::ScopedArtifactEvidenceV1> physical_evidence;
  if (include_physical_transfer) {
    REQUIRE(physical_family.has_value());
    const auto& physical_requirement = release_role_requirement(
        fixture, mwperf::MetricSupportRoleV1::physical_transfer_evidence);
    auto physical_core =
        release_envelope_core(fixture, physical_requirement, objects);
    physical_evidence = mwperf::ScopedArtifactEvidenceV1{
        physical_placeholder,
        mwperf::ArtifactReferenceKindV1::physical_transfer_evidence,
        clause.ordered_targets,
        physical_requirement.result_scope,
        physical_requirement.evidence_scope,
        release_relation_projection(
            physical_core.role_relations, physical_core.internal_relations,
            mwperf::MetricRoleRelationKindV1::subject),
        release_relation_projection(
            physical_core.role_relations, physical_core.internal_relations,
            mwperf::MetricRoleRelationKindV1::lineage_parent),
        {physical_family->evidence_id},
        physical_core.internal_relations};
    auto physical_digest =
        mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(
            *physical_evidence);
    REQUIRE(physical_digest);
    physical_evidence->evidence_id.object_digest =
        std::move(physical_digest).value();
    objects.physical = physical_evidence->evidence_id;
  }

  release_rebind_envelope_family(envelope_payload, raw_family_placeholder,
                                 raw_family.evidence_id);
  for (auto& reference : envelope_payload.typed_evidence_components) {
    release_replace_reference(reference, order_placeholder,
                              order_evidence.evidence_id);
    release_replace_reference(reference, raw_family_placeholder,
                              raw_family.evidence_id);
    if (physical_evidence.has_value()) {
      release_replace_reference(reference, physical_placeholder,
                                physical_evidence->evidence_id);
    }
  }
  std::sort(envelope_payload.typed_evidence_components.begin(),
            envelope_payload.typed_evidence_components.end());
  payload = envelope_payload;
  auto final_payload_digest =
      mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(final_payload_digest);
  REQUIRE(final_payload_digest.value() == payload_digest.value());

  std::vector<mwperf::RealizedMetricBindingV1> bindings;
  for (const auto& requirement :
       fixture.structural_manifest.clauses().front().required_roles) {
    if (variant == ReleaseEnvelopeVariant::missing_raw_bound_binding &&
        requirement.role ==
            mwperf::MetricSupportRoleV1::raw_response_bound_evidence) {
      continue;
    }
    if (variant == ReleaseEnvelopeVariant::physical_without_transfer &&
        requirement.role ==
            mwperf::MetricSupportRoleV1::physical_transfer_evidence) {
      continue;
    }
    bindings.push_back(
        {{fixture.structural_manifest.clauses().front().clause_id,
          requirement.role},
         release_envelope_reference(fixture, requirement, objects)});
  }
  std::vector<mwperf::FamilyEvidenceEnvelopeV1> families{
      std::move(raw_family), std::move(order_family)};
  if (physical_family.has_value()) {
    families.push_back(std::move(*physical_family));
  }
  std::sort(families.begin(), families.end(),
            [](const auto& left, const auto& right) {
              return left.evidence_id < right.evidence_id;
            });
  std::vector<mwperf::ScopedArtifactEvidenceV1> scoped_evidence{
      std::move(order_evidence)};
  if (physical_evidence.has_value()) {
    scoped_evidence.push_back(std::move(*physical_evidence));
  }
  std::sort(scoped_evidence.begin(), scoped_evidence.end(),
            [](const auto& left, const auto& right) {
              return left.evidence_id < right.evidence_id;
            });
  const auto report = release_build_report(fixture);
  std::vector<mwperf::ArtifactDiagnosticComponentV1> diagnostics;
  if (variant == ReleaseEnvelopeVariant::physical_without_transfer) {
    diagnostics.push_back(
        {1U,
         release_label(std::string(fixture.spec.name) + ".diagnostic"),
         mwperf::ArtifactDiagnosticScopeV1::physical_fidelity,
         "construction.completed",
         "construction and V0 diagnostics completed",
         {payload_identity},
         {}});
  }
  mwperf::SurrogateArtifactV1 artifact{
      1U,
      fixture.request.request_digest().value(),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.contract.construction_method(),
      fixture.contract.producer_mode(),
      fixture.contract.semantic(),
      fixture.contract.runtime_access(),
      fixture.contract.payload_class(),
      payload_identity,
      std::move(payload),
      payload_digest.value(),
      release_manifest_echo(fixture.structural_manifest),
      {fixture.request.request_digest().value(), payload_digest.value(),
       std::move(bindings)},
      fixture.contract.descriptor_core(),
      report,
      std::move(families),
      std::move(scoped_evidence),
      std::move(diagnostics),
      {std::nullopt,
       std::nullopt,
       std::nullopt,
       std::nullopt,
       std::nullopt,
       {},
       {},
       {},
       std::nullopt,
       objects.proposal.object_id,
       objects.evaluation.object_id}};
  mwperf::ResultEnvelopeV1 result_envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};
  return {report, ReleaseFactory::validated_build_report(report),
          {std::move(result_envelope), std::move(artifact)}};
}

[[nodiscard]] mwperf::Result<mwperf::ValidatedSurrogateBuildResult>
release_validate_envelope(const ReleaseBoundRequest& fixture,
                          const ReleaseBuiltFixture& built,
                          const bool through_wire) {
  if (!through_wire) {
    return mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, fixture.request,
        fixture.manifest, fixture.contract, built.validated_report);
  }
  auto bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{built.result});
  REQUIRE(bytes);
  auto parsed = mwperf::parse_surrogate_build_result(
      bytes.value(), release_parse_limits());
  REQUIRE(parsed);
  return mwperf::validate_surrogate_build_result(
      parsed.value(), fixture.request, fixture.manifest, fixture.contract,
      built.validated_report);
}

}  // namespace

TEST_CASE("C15 release matrix carries response envelopes through F08",
          "[c15][integration][release-matrix]") {
  auto fixture = release_bound_request(
      release_spec(ReleasePayloadCase::response_envelope), 0xC15E0U);
  for (const auto variant : {ReleaseEnvelopeVariant::valid_distinct,
                             ReleaseEnvelopeVariant::valid_exact_alias}) {
    const std::string_view variant_name =
        variant == ReleaseEnvelopeVariant::valid_distinct
            ? std::string_view("distinct lower and upper ledgers")
            : std::string_view("exact lower and upper ledger alias");
    DYNAMIC_SECTION(variant_name) {
      const auto built = release_envelope_built_fixture(fixture, variant);
      auto validated = release_validate_envelope(fixture, built, true);
      INFO((validated
                ? std::string{}
                : validated.error().code + ": " +
                      validated.error().message));
      REQUIRE(validated);
      const auto realized = mwperf::resolve_realized_metric_capabilities(
          validated.value(), fixture.input.requirements);
      const auto* capabilities =
          std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
      REQUIRE(capabilities != nullptr);
      auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
      REQUIRE(portable);
      CHECK(std::holds_alternative<
            mwperf::PortableResponseEnvelopeEvidenceV1>(
          portable.value().value()));
    }
  }
}

TEST_CASE("C15 analytic-transform response envelope completes F01 through F08",
          "[c15][integration][release-matrix]") {
  auto spec = release_spec(ReleasePayloadCase::response_envelope);
  spec.name = "envelope-analytic-transform";
  spec.access = mwperf::RuntimeAccessTagV1::analytic_transform;
  auto fixture = release_bound_request(spec, 0xC15E10U);
  const auto built = release_envelope_built_fixture(
      fixture, ReleaseEnvelopeVariant::valid_distinct);
  auto validated = release_validate_envelope(fixture, built, true);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);

  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), fixture.input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
  INFO((portable ? std::string{}
                 : portable.error().code + ": " +
                       portable.error().message));
  REQUIRE(portable);
  const auto* response =
      std::get_if<mwperf::PortableResponseEnvelopeEvidenceV1>(
          &portable.value().value());
  REQUIRE(response != nullptr);
  CHECK(response->context.runtime_access ==
        mwperf::RuntimeAccessTagV1::analytic_transform);
}

TEST_CASE("C15 optimizer raw envelope remains typed through F08",
          "[c15][integration][release-matrix]") {
  auto fixture = release_bound_request(
      release_spec(ReleasePayloadCase::response_envelope), 0xC15E20U,
      std::nullopt,
      ReleaseEnvelopeContractKind::optimizer_interval_raw);
  const auto built = release_envelope_built_fixture(
      fixture, ReleaseEnvelopeVariant::valid_distinct);
  auto validated = release_validate_envelope(fixture, built, true);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message + " at " +
                        validated.error().json_pointer.value_or("<none>")));
  REQUIRE(validated);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), fixture.input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
  REQUIRE(portable);
  const auto* response =
      std::get_if<mwperf::PortableResponseEnvelopeEvidenceV1>(
          &portable.value().value());
  REQUIRE(response != nullptr);
  REQUIRE(response->normalized_record.lower_response.raw_envelopes.size() ==
          1U);
  CHECK(response->normalized_record.lower_response.raw_envelopes.front()
            .scope == mwperf::RawEnvelopeScopeV1::optimizer_interval_raw);
  CHECK(std::any_of(
      response->context.family_evidence.begin(),
      response->context.family_evidence.end(), [](const auto& evidence) {
        return evidence.evidence_scope_tag ==
               mwperf::MetricEvidenceScopeV1::optimizer_interval_raw;
      }));
}

TEST_CASE("C15 physical response bound preserves its transfer certificate",
          "[c15][integration][release-matrix]") {
  auto fixture = release_bound_request(
      release_spec(ReleasePayloadCase::response_envelope), 0xC15E21U,
      std::nullopt, ReleaseEnvelopeContractKind::physical_bound);
  const auto built = release_envelope_built_fixture(
      fixture, ReleaseEnvelopeVariant::valid_distinct);
  auto validated = release_validate_envelope(fixture, built, true);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), fixture.input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
  REQUIRE(portable);
  const auto* response =
      std::get_if<mwperf::PortableResponseEnvelopeEvidenceV1>(
          &portable.value().value());
  REQUIRE(response != nullptr);
  CHECK(response->normalized_record.result_scope ==
        mwperf::MetricResultScopeV1::physical_bound);
  CHECK(response->normalized_record.evidence_scope ==
        mwperf::MetricEvidenceScopeV1::physical_system);
  const auto physical = std::find_if(
      response->context.scoped_evidence.begin(),
      response->context.scoped_evidence.end(), [](const auto& evidence) {
        return evidence.reference_kind ==
               mwperf::ArtifactReferenceKindV1::physical_transfer_evidence;
      });
  REQUIRE(physical != response->context.scoped_evidence.end());
  CHECK(std::find(response->normalized_record.typed_evidence_components.begin(),
                  response->normalized_record.typed_evidence_components.end(),
                  physical->evidence_id) !=
        response->normalized_record.typed_evidence_components.end());
  CHECK(std::any_of(
      response->context.realized_metric_bindings.bindings.begin(),
      response->context.realized_metric_bindings.bindings.end(),
      [](const auto& binding) {
        return binding.key.role ==
               mwperf::MetricSupportRoleV1::physical_transfer_evidence;
      }));
}

TEST_CASE("C15 response envelope evidence alternatives are noninterchangeable",
          "[c15][negative][release-matrix]") {
  struct Rejection final {
    ReleaseEnvelopeVariant variant;
    const char* name;
  };
  const std::array<Rejection, 4U> rejections{{
      {ReleaseEnvelopeVariant::nested_raw_in_typed_components,
       "nested raw envelope is not scoped-vector evidence"},
      {ReleaseEnvelopeVariant::family_in_typed_components,
       "family envelope is not scoped-vector evidence"},
      {ReleaseEnvelopeVariant::missing_raw_bound_binding,
       "required direct raw bound cannot be omitted"},
      {ReleaseEnvelopeVariant::physical_without_transfer,
       "diagnostics and V0 do not promote to a physical bound"},
  }};
  std::uint64_t seed = 0xC15E10U;
  for (const auto& rejection : rejections) {
    DYNAMIC_SECTION(rejection.name) {
      auto fixture = release_bound_request(
          release_spec(ReleasePayloadCase::response_envelope), seed++,
          std::nullopt,
          rejection.variant == ReleaseEnvelopeVariant::physical_without_transfer
              ? ReleaseEnvelopeContractKind::physical_bound
              : ReleaseEnvelopeContractKind::response);
      const auto built =
          release_envelope_built_fixture(fixture, rejection.variant);
      auto rejected = release_validate_envelope(fixture, built, true);
      REQUIRE_FALSE(rejected);
    }
  }
}

namespace mwperf::testing {

namespace {

[[nodiscard]] C15GoldenSourceV1 authenticate_release_golden_source_v1(
    const ReleaseBoundRequest& fixture, const ReleaseBuiltFixture& candidate,
    std::string name) {
  INFO("golden source: " << name);
  auto bytes = artifact::detail::canonical_surrogate_build_result_bytes_v1(
      SurrogateBuildResultV1{candidate.result});
  REQUIRE(bytes);
  auto parsed =
      parse_surrogate_build_result(bytes.value(), release_parse_limits());
  INFO((parsed ? std::string{}
               : parsed.error().code + ": " + parsed.error().message +
                     " at " +
                     parsed.error().json_pointer.value_or("<none>")));
  REQUIRE(parsed);
  auto validated = validate_surrogate_build_result(
      parsed.value(), fixture.request, fixture.manifest, fixture.contract,
      candidate.validated_report);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message + " at " +
                        validated.error().json_pointer.value_or("<none>")));
  REQUIRE(validated);
  const auto realized = resolve_realized_metric_capabilities(
      validated.value(), fixture.input.requirements);
  const auto* capabilities =
      std::get_if<RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = adapt_portable_payload(capabilities->artifact);
  INFO((portable ? std::string{}
                 : portable.error().code + ": " +
                       portable.error().message));
  REQUIRE(portable);
  const auto* source_built =
      std::get_if<BuiltSurrogateResultV1>(&parsed.value());
  REQUIRE(source_built != nullptr);
  return {std::move(name), *source_built, portable.value().value()};
}

[[nodiscard]] C15GoldenSourceV1 make_release_golden_source_v1(
    const ReleasePayloadCase payload_case, std::string name,
    const std::uint64_t seed,
    const ReleasePayloadMutation mutation = nullptr) {
  auto fixture = release_bound_request(release_spec(payload_case), seed);
  const auto candidate =
      payload_case == ReleasePayloadCase::response_envelope
          ? release_envelope_built_fixture(
                fixture, ReleaseEnvelopeVariant::valid_distinct)
          : release_ordinary_built_fixture(fixture, mutation);
  return authenticate_release_golden_source_v1(fixture, candidate,
                                                std::move(name));
}

[[nodiscard]] C15GoldenSourceV1 make_release_envelope_golden_source_v1(
    const ReleaseEnvelopeContractKind contract_kind, std::string name,
    const std::uint64_t seed) {
  auto fixture = release_bound_request(
      release_spec(ReleasePayloadCase::response_envelope), seed,
      std::nullopt, contract_kind);
  const auto candidate = release_envelope_built_fixture(
      fixture, ReleaseEnvelopeVariant::valid_distinct);
  return authenticate_release_golden_source_v1(fixture, candidate,
                                                std::move(name));
}

void release_use_stopped_explicit_words(
    ArtifactPayloadV1& payload) {
  auto& finite = std::get<FiniteLawTablesV1>(payload);
  auto& table = std::get<StoppedPathTableV1>(finite.table);
  const auto active = release_label("active");
  const auto terminal = release_label("terminal");
  const auto mark = release_label("m0");
  table.representation = std::vector<ExplicitOrderedWordV1>{
      {active, BigNat{1U}, {mark}, terminal, active,
       release_scalar(1, 1)}};
}

void release_use_romr_predictive_tables(
    ArtifactPayloadV1& payload) {
  auto& finite = std::get<FiniteLawTablesV1>(payload);
  auto& table = std::get<RomrResidenceWordTableV1>(finite.table);
  const auto active = release_label("active");
  const auto terminal = release_label("terminal");
  const auto mark = release_label("m0");
  finite.state_dictionary = {
      {active, {release_scalar(0, 1)}},
      {terminal, {release_scalar(1, 1)}}};
  table.entrance_state_domain = {active};
  table.residence_state_domain = {active, terminal};
  auto continuation = release_finite_row(
      "finite-residence.continuation-row", active,
      FiniteRowConditioningStageV1::residence_continuation, active, {mark});
  continuation.atoms.front().probability = release_scalar(1, 2);
  auto event = release_finite_row(
      "finite-residence.event-row", active,
      FiniteRowConditioningStageV1::residence_continuation, terminal, {mark});
  event.atoms.front().probability = release_scalar(1, 2);
  table.representation = FinitePredictiveStoppingTablesV1{
      {std::move(continuation)}, {std::move(event)},
      {release_finite_row(
          "finite-residence.exit-row", terminal,
          FiniteRowConditioningStageV1::residence_continuation, active,
          {})}};
}

}  // namespace

std::vector<C15GoldenSourceV1> make_non_three_c15_golden_sources_v1() {
  std::vector<C15GoldenSourceV1> result;
  result.reserve(5U);
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::analytic, "finite_parameter_analytic", 0xC15A10U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_stationary, "finite_law_tables", 0xC15A11U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::runtime_recipe, "registered_runtime_recipe",
      0xC15A12U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::response_envelope, "response_envelope", 0xC15A13U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::direct, "direct_metric", 0xC15A14U));
  return result;
}

std::vector<C15GoldenSourceV1> make_finite_table_c15_golden_sources_v1() {
  std::vector<C15GoldenSourceV1> result;
  result.reserve(6U);
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_stationary, "stationary_marked_edge",
      0xC15B10U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_staged, "staged_opportunity_flux",
      0xC15B11U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_temporal, "temporal_continuation",
      0xC15B12U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_stopped, "stopped_path", 0xC15B13U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_residence, "romr_residence_word",
      0xC15B14U));
  result.push_back(make_release_golden_source_v1(
      ReleasePayloadCase::finite_coupled, "coupled_common_schedule",
      0xC15B15U));
  return result;
}

C15GoldenSourceV1
make_response_envelope_optimizer_interval_raw_c15_golden_source_v1() {
  return make_release_envelope_golden_source_v1(
      ReleaseEnvelopeContractKind::optimizer_interval_raw,
      "response_envelope_optimizer_interval_raw", 0xC15C10U);
}

C15GoldenSourceV1
make_response_envelope_physical_bound_c15_golden_source_v1() {
  return make_release_envelope_golden_source_v1(
      ReleaseEnvelopeContractKind::physical_bound,
      "response_envelope_physical_bound", 0xC15C11U);
}

C15GoldenSourceV1
make_stopped_path_explicit_words_c15_golden_source_v1() {
  return make_release_golden_source_v1(
      ReleasePayloadCase::finite_stopped, "stopped_path_explicit_words",
      0xC15C12U, release_use_stopped_explicit_words);
}

C15GoldenSourceV1
make_romr_residence_predictive_tables_c15_golden_source_v1() {
  return make_release_golden_source_v1(
      ReleasePayloadCase::finite_residence,
      "romr_residence_predictive_tables", 0xC15C13U,
      release_use_romr_predictive_tables);
}

}  // namespace mwperf::testing

TEST_CASE("C15 predictive ROMR geometric residence completes F01 through F08",
          "[c15][integration][release-matrix][romr-predictive]") {
  const auto source =
      mwperf::testing::
          make_romr_residence_predictive_tables_c15_golden_source_v1();
  CHECK(source.name == "romr_residence_predictive_tables");

  const auto* finite =
      std::get_if<mwperf::PortableFiniteLawTablesV1>(&source.portable_payload);
  REQUIRE(finite != nullptr);
  CHECK(finite->context.semantic ==
        mwperf::SemanticTagV1::romr_residence_word_law);
  CHECK(finite->context.runtime_access ==
        mwperf::RuntimeAccessTagV1::finite_enumerated_row);

  const auto* residence = std::get_if<mwperf::RomrResidenceWordTableV1>(
      &finite->normalized_record.table);
  REQUIRE(residence != nullptr);
  const auto* predictive =
      std::get_if<mwperf::FinitePredictiveStoppingTablesV1>(
          &residence->representation);
  REQUIRE(predictive != nullptr);
  REQUIRE(predictive->continuation_rows.size() == 1U);
  REQUIRE(predictive->stop_or_event_rows.size() == 1U);
  REQUIRE(predictive->terminal_or_exit_rows.size() == 1U);

  const auto& continuation = predictive->continuation_rows.front();
  const auto& event = predictive->stop_or_event_rows.front();
  const auto& exit = predictive->terminal_or_exit_rows.front();
  REQUIRE(continuation.atoms.size() == 1U);
  REQUIRE(event.atoms.size() == 1U);
  REQUIRE(exit.atoms.size() == 1U);
  CHECK(continuation.conditioning_state_id == release_label("active"));
  CHECK(continuation.atoms.front().successor_state_id ==
        release_label("active"));
  CHECK(continuation.atoms.front().probability == release_scalar(1, 2));
  CHECK(event.conditioning_state_id == release_label("active"));
  CHECK(event.atoms.front().successor_state_id == release_label("terminal"));
  CHECK(event.atoms.front().probability == release_scalar(1, 2));
  CHECK(exit.conditioning_state_id == release_label("terminal"));
  CHECK(exit.atoms.front().successor_state_id == release_label("active"));
  CHECK(exit.atoms.front().probability == release_scalar(1, 1));
  CHECK(residence->nontermination_probability == release_scalar(0, 1));
}
