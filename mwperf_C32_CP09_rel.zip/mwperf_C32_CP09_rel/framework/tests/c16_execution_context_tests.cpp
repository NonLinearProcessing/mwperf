#include <algorithm>
#include <filesystem>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/reduction/exact_reductions.hpp"
#include "mwperf/reduction/resource_coordinates.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
using Input = mwperf::testing::c16_designated_detail::InputV1;

[[nodiscard]] std::filesystem::path execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c16-execution-context";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

[[nodiscard]] mwperf::ConstructionBudget budget(
    const std::uint64_t optimizer_calls = 0U) {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{optimizer_calls}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct Scenario final {
  mwperf::SurrogateProvider provider;
  Input input;
  mwperf::FrameworkProblemView view;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::PlugDescriptorPreview preview;
  mwperf::AcceptedCapabilityContract contract;
  mwperf::ConstructionBudget grant;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] Scenario exact_scenario() {
  constexpr std::string_view id_text = "c16.fixture.context.exact";
  auto input = mwperf::testing::c16_designated_detail::input(id_text);
  auto id = mwperf::SurrogateId::parse(std::string(id_text));
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U,
      {mwperf::testing::c16_designated_detail::queue("q0")},
      mwperf::ConstructionGroupIdV1(
          mwperf::testing::c16_designated_detail::label(
              "c16.context.exact.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(),
      mwperf::testing::c16_designated_detail::parameters());
  REQUIRE(parameters);
  auto grant = budget(1U);
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, grant,
      parameters.value());
  REQUIRE(preview);
  REQUIRE(preview.value()
              .construction_prerequisites.required_optimizer_calls ==
          mwperf::BigNat{1U});
  auto grant_digest = mwperf::digest_construction_budget_v1(grant);
  REQUIRE(grant_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), grant_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), grant, mwperf::MasterSeed(0xC16ECU));
  REQUIRE(request);
  return {std::move(provider).value(), std::move(input),
          std::move(view).value(), std::move(parameters).value(),
          std::move(preview).value(), std::move(contract), std::move(grant),
          std::move(request).value()};
}

[[nodiscard]] mwperf::ConstructionExactQueryServices exact_services(
    const Scenario& scenario, mwperf::OptimizerExecutionContext& optimizer,
    const mwperf::BigNat& subgrant) {
  auto services =
      mwperf::detail::ConstructionExactQueryBindingAccess::bind(
          scenario.input.instance, scenario.request.build_identity_digest(),
          optimizer, subgrant);
  REQUIRE(services);
  return std::move(services).value();
}

[[nodiscard]] std::string failure_code(
    const mwperf::ProviderExecutionOutcome& outcome) {
  const auto* failure =
      std::get_if<mwperf::FailedProviderExecution>(&outcome);
  return failure == nullptr ? std::string{} : failure->diagnostic.code;
}

[[nodiscard]] mwperf::ArrivalAssumptionV1 arrival_assumption(
    const mwperf::ArrivalNeedKindV1 kind,
    const mwperf::CapabilityProvisionNeedV1 provision) {
  return {kind,
          mwperf::ArrivalCapabilityUseV1::construction,
          provision,
          std::nullopt,
          false,
          false,
          std::nullopt,
          std::nullopt,
          std::nullopt};
}

struct ArrivalScenario final {
  Input input;
  mwperf::CompiledArrivalLaw law;
  mwperf::ValidatedProviderManifest manifest;
  mwperf::FrameworkProblemView view;
  mwperf::ConstructionBudget grant;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] ArrivalScenario arrival_scenario(
    const mwperf::ArrivalNeedKindV1 kind,
    const mwperf::CapabilityProvisionNeedV1 provision,
    const mwperf::ProducerModeV1 mode =
        mwperf::ProducerModeV1::in_process_builder) {
  auto input = mwperf::testing::c16_designated_detail::input(
      "c16.fixture.context.exact");
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      input.instance.queues());
  REQUIRE(law);
  const mwperf::TargetSelection targets{
      1U,
      {mwperf::testing::c16_designated_detail::queue("q0")},
      mwperf::ConstructionGroupIdV1(
          mwperf::testing::c16_designated_detail::label(
              "c16.context.arrival.group"))};
  auto base_view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(base_view);
  auto view = Factory::with_configured_arrival(
      base_view.value(), mwperf::builder_arrival_view(law.value()));
  const mwperf::ArrivalAssumptionV1 assumption =
      arrival_assumption(kind, provision);
  std::optional<mwperf::LocalExecutableDeclarationV1> local;
  if (mode == mwperf::ProducerModeV1::local_executable_builder) {
    local = mwperf::LocalExecutableDeclarationV1{
        "c16.context.synthetic", 1U,
        {"--request", "{request_path}", "--result", "{result_path}"},
        false};
  }
  auto raw_manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.context.synthetic",
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_hybrid, mode, true,
      std::move(local));
  raw_manifest.target_and_arrival_scientific_prerequisites
      .arrival_assumptions = {assumption};
  auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
      raw_manifest.metric_clause_upper_envelope.clauses().begin(),
      raw_manifest.metric_clause_upper_envelope.clauses().end());
  REQUIRE(clauses.size() == 1U);
  clauses.front().arrival_assumptions = {assumption};
  auto support =
      mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
  REQUIRE(support);
  raw_manifest.metric_clause_upper_envelope = std::move(support).value();
  raw_manifest.manifest_digest =
      std::move(mwperf::digest_provider_manifest_v1(raw_manifest)).value();
  auto manifest = mwperf::validate_provider_manifest(raw_manifest);
  REQUIRE(manifest);
  const auto parameter_bytes =
      mwperf::testing::c16_designated_detail::bytes(
          R"json({"resolution_level":1})json");
  auto parameters = Factory::validated_parameters(
      raw_manifest.provider, raw_manifest.parameter_schema_version,
      raw_manifest.parameter_schema_digest, parameter_bytes);
  auto grant = budget();
  auto grant_digest = mwperf::digest_construction_budget_v1(grant);
  REQUIRE(grant_digest);
  const auto core = mwperf::testing::c16_fixture_detail::scalar_core(
      raw_manifest, targets.ordered_targets);
  const mwperf::PreviewPoliciesV1 policies{
      raw_manifest.scientific_construction_policy_schema
          .point_deployment.front(),
      raw_manifest.scientific_construction_policy_schema
          .coefficient_completion.front(),
      raw_manifest.scientific_construction_policy_schema.projection.front(),
      raw_manifest.scientific_construction_policy_schema.recoding.front(),
      raw_manifest.scientific_construction_policy_schema
          .evidence_roles.front()};
  const mwperf::ConstructionPrerequisitesV1 prerequisites{
      {assumption}, std::nullopt, std::nullopt, std::nullopt};
  auto contract = Factory::accepted_contract(
      raw_manifest, core, raw_manifest.metric_clause_upper_envelope,
      input.requirements, view.configured_arrival().capabilities(), {},
      targets.ordered_targets, policies, prerequisites,
      view.canonical_digest().value(), parameters.canonical_value_digest(),
      grant_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      manifest.value(), view, contract, parameters, grant,
      mwperf::MasterSeed(0xC16A11U));
  REQUIRE(request);
  return {std::move(input), std::move(law).value(),
          std::move(manifest).value(), std::move(view), std::move(grant),
          std::move(request).value()};
}

}  // namespace

TEST_CASE("C16 exact context service is required and exactly grant bound",
          "[c16][context][negative]") {
  auto scenario = exact_scenario();
  auto missing = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root());
  REQUIRE_FALSE(missing);
  CHECK(missing.error().code == "c16.execution_context_exact_service_shape");

  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      scenario.input.instance, mwperf::BigNat{1U});
  REQUIRE(optimizer);
  auto service = exact_services(scenario, optimizer.value(),
                                mwperf::BigNat{0U});
  auto wrong_grant = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root(),
      std::nullopt, std::move(service));
  REQUIRE_FALSE(wrong_grant);
  CHECK(wrong_grant.error().code ==
        "c16.execution_context_exact_service_grant_mismatch");
}

TEST_CASE("C16 exact context audits liveness instance and cold ledger",
          "[c16][context][negative]") {
  auto scenario = exact_scenario();

  SECTION("moved-from service") {
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(
            scenario.input.instance, mwperf::BigNat{1U});
    REQUIRE(optimizer);
    auto service = exact_services(scenario, optimizer.value(),
                                  mwperf::BigNat{1U});
    auto moved = std::move(service);
    static_cast<void>(moved);
    auto rejected = mwperf::BuildExecutionContext::create(
        scenario.request, scenario.provider.manifest(), execution_root(),
        std::nullopt, std::move(service));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c16.execution_context_exact_service_inactive");
  }

  SECTION("foreign resolved instance") {
    auto authored = scenario.input.instance.authored_model();
    auto& scheduler =
        std::get<mwperf::ConflictGraphMaxWeightScheduler>(
            authored.scheduler.value);
    REQUIRE(scheduler.priority.value.has_value());
    std::reverse(scheduler.priority.value->begin(),
                 scheduler.priority.value->end());
    auto analysis = scenario.input.instance.analysis_spec();
    const auto canonical =
        mwperf::canonicalize_authored_inputs(authored, analysis);
    const auto fingerprints = mwperf::fingerprint_inputs(canonical);
    auto foreign = mwperf::resolve_physical_instance(
        authored, analysis, fingerprints);
    REQUIRE(foreign);
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(
            foreign.value(), mwperf::BigNat{1U});
    REQUIRE(optimizer);
    auto service =
        mwperf::detail::ConstructionExactQueryBindingAccess::bind(
            foreign.value(), scenario.request.build_identity_digest(),
            optimizer.value(), mwperf::BigNat{1U});
    REQUIRE(service);
    auto rejected = mwperf::BuildExecutionContext::create(
        scenario.request, scenario.provider.manifest(), execution_root(),
        std::nullopt, std::move(service).value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c16.execution_context_exact_service_binding_mismatch");
  }

  SECTION("preconsumed ledger") {
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(
            scenario.input.instance, mwperf::BigNat{1U});
    REQUIRE(optimizer);
    auto service = exact_services(scenario, optimizer.value(),
                                  mwperf::BigNat{1U});
    REQUIRE(mwperf::begin_search_budget(optimizer.value()));
    auto rejected = mwperf::BuildExecutionContext::create(
        scenario.request, scenario.provider.manifest(), execution_root(),
        std::nullopt, std::move(service));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c16.execution_context_exact_service_not_cold");
  }
}

TEST_CASE("C16 F03 rejects exact-service preconsumption before callback",
          "[c16][context][negative][atomicity]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = exact_scenario();
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      scenario.input.instance, mwperf::BigNat{1U});
  REQUIRE(optimizer);
  auto service = exact_services(scenario, optimizer.value(),
                                mwperf::BigNat{1U});
  auto context = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root(),
      std::nullopt, std::move(service));
  REQUIRE(context);
  REQUIRE(context.value().exact_query_services() != nullptr);
  REQUIRE(mwperf::begin_search_budget(optimizer.value()));
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context.value());
  CHECK(failure_code(outcome) ==
        "c16.execution_context_exact_service_not_cold");
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        0U);
}

TEST_CASE("C16 context exposes only request-authorized adjacent replay",
          "[c16][integration][context][arrival]") {
  for (const auto kind : {mwperf::ArrivalNeedKindV1::sequential_law,
                          mwperf::ArrivalNeedKindV1::entrance_labels}) {
    CAPTURE(kind);
    auto scenario = arrival_scenario(
        kind, mwperf::CapabilityProvisionNeedV1::process_local);
    auto services = mwperf::make_builder_arrival_services(
        scenario.law, scenario.view.configured_arrival());
    REQUIRE(services);
    REQUIRE(services.value().has_unit_cube());
    auto context = mwperf::BuildExecutionContext::create(
        scenario.request, scenario.manifest, execution_root(),
        std::move(services).value());
    REQUIRE(context);
    CHECK(context.value().arrival_replay_service() != nullptr);
    CHECK(context.value().exact_query_services() == nullptr);
  }
}

TEST_CASE("C16 context rejects missing extra and unusable arrival services",
          "[c16][context][arrival][negative]") {
  auto required = arrival_scenario(
      mwperf::ArrivalNeedKindV1::sequential_law,
      mwperf::CapabilityProvisionNeedV1::process_local);
  auto missing = mwperf::BuildExecutionContext::create(
      required.request, required.manifest, execution_root());
  REQUIRE_FALSE(missing);
  CHECK(missing.error().code ==
        "c16.execution_context_arrival_service_shape");

  auto services = mwperf::make_builder_arrival_services(
      required.law, required.view.configured_arrival());
  REQUIRE(services);
  auto live = std::move(services).value();
  auto moved = std::move(live);
  static_cast<void>(moved);
  auto inactive = mwperf::BuildExecutionContext::create(
      required.request, required.manifest, execution_root(),
      std::move(live));
  REQUIRE_FALSE(inactive);
  CHECK(inactive.error().code ==
        "c16.execution_context_arrival_service_inactive");

  auto portable = arrival_scenario(
      mwperf::ArrivalNeedKindV1::sequential_law,
      mwperf::CapabilityProvisionNeedV1::any);
  auto extra_services = mwperf::make_builder_arrival_services(
      portable.law, portable.view.configured_arrival());
  REQUIRE(extra_services);
  auto extra = mwperf::BuildExecutionContext::create(
      portable.request, portable.manifest, execution_root(),
      std::move(extra_services).value());
  REQUIRE_FALSE(extra);
  CHECK(extra.error().code ==
        "c16.execution_context_arrival_service_shape");

  auto unsupported = arrival_scenario(
      mwperf::ArrivalNeedKindV1::full_common_batch,
      mwperf::CapabilityProvisionNeedV1::process_local);
  auto rejected = mwperf::BuildExecutionContext::create(
      unsupported.request, unsupported.manifest, execution_root());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c16.execution_context_arrival_service_unsupported");
}
