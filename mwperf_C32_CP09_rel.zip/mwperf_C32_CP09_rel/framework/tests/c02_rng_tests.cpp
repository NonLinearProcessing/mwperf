#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <boost/multiprecision/cpp_int.hpp>
#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace {

using mwperf::BigInt;
using mwperf::BigNat;
using mwperf::BuildIdentityDigest;
using mwperf::BuildSeed;
using mwperf::Digest256;
using mwperf::MasterSeed;
using mwperf::NormalizedPmf;
using mwperf::StageTag;
using mwperf::TypedLabel;

[[nodiscard]] Digest256 digest(std::string_view hex) {
  auto result = Digest256::from_hex(hex);
  if (!result) {
    throw std::logic_error("invalid digest fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] BigNat natural(BigInt value) {
  auto result = BigNat::from_big_int(std::move(value));
  if (!result) {
    throw std::logic_error("invalid natural-number fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational rational(BigInt numerator,
                                              BigInt denominator) {
  auto result =
      mwperf::ExactRational::make(std::move(numerator), std::move(denominator));
  if (!result) {
    throw std::logic_error("invalid rational fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] NormalizedPmf pmf_from_masses(
    const std::vector<BigInt>& masses) {
  BigInt denominator = 0;
  for (const BigInt& mass : masses) {
    denominator += mass;
  }
  std::vector<mwperf::AuthoredProbability> authored;
  authored.reserve(masses.size());
  for (const BigInt& mass : masses) {
    auto probability = mwperf::AuthoredProbability::from_exact(
        rational(mass, denominator));
    if (!probability) {
      throw std::logic_error("invalid probability fixture");
    }
    authored.push_back(std::move(probability).value());
  }
  auto normalized = mwperf::validate_and_normalize_pmf(
      authored, mwperf::physical_pmf_tolerance());
  if (!normalized) {
    throw std::logic_error("invalid PMF fixture");
  }
  return std::move(normalized).value();
}

[[nodiscard]] std::string hex_bytes(std::span<const std::byte> bytes) {
  constexpr char digits[] = "0123456789abcdef";
  std::string result;
  result.reserve(bytes.size() * 2U);
  for (const std::byte byte : bytes) {
    const auto value = std::to_integer<std::uint8_t>(byte);
    result.push_back(digits[value >> 4U]);
    result.push_back(digits[value & 0x0fU]);
  }
  return result;
}

[[nodiscard]] std::vector<std::byte> bytes_from_hex(std::string_view hex) {
  const auto nibble = [](const char character) -> std::uint8_t {
    if (character >= '0' && character <= '9') {
      return static_cast<std::uint8_t>(character - '0');
    }
    if (character >= 'a' && character <= 'f') {
      return static_cast<std::uint8_t>(character - 'a' + 10);
    }
    throw std::logic_error("invalid hexadecimal fixture");
  };
  if (hex.size() % 2U != 0U) {
    throw std::logic_error("odd hexadecimal fixture");
  }
  std::vector<std::byte> bytes;
  bytes.reserve(hex.size() / 2U);
  for (std::size_t position = 0; position < hex.size(); position += 2U) {
    const auto value = static_cast<std::uint8_t>(
        (nibble(hex[position]) << 4U) | nibble(hex[position + 1U]));
    bytes.push_back(static_cast<std::byte>(value));
  }
  return bytes;
}

void check_instance_preimage(std::span<const std::byte> actual,
                             std::string_view preimage_hex,
                             const Digest256& expected) {
  const auto preimage = bytes_from_hex(preimage_hex);
  CHECK(hex_bytes(actual) == preimage_hex);
  auto hashed = mwperf::sha256(preimage);
  REQUIRE(hashed);
  CHECK(hashed.value() == expected);
}

[[nodiscard]] const Digest256& digest_a() {
  static const Digest256 value = digest(
      "000102030405060708090a0b0c0d0e0f"
      "101112131415161718191a1b1c1d1e1f");
  return value;
}

[[nodiscard]] const Digest256& digest_b() {
  static const Digest256 value = digest(
      "202122232425262728292a2b2c2d2e2f"
      "303132333435363738393a3b3c3d3e3f");
  return value;
}

struct StageVector {
  StageTag stage;
  std::string_view state;
  std::array<std::uint64_t, 3> outputs;
};

constexpr std::array<StageVector, 14> kStageVectors{{
    {StageTag::initial_joint_atom,
     "e247a6dd592c4d67179983aeaec4de6ec32fa402c0d345aaacc22314deadafe0",
     {0xfe12da5c4d8cad0aULL, 0x39e0735ac25d53d1ULL,
      0x8f01a537c068df78ULL}},
    {StageTag::prearrival_closure,
     "a4596bb2392c9a033e166039481ed9481ae18671dfd6c88b7d0206888ae90278",
     {0xf77508d6b618d4f3ULL, 0x577a885f16486249ULL,
      0x30bd1d9e05e6d1aeULL}},
    {StageTag::tie_resolution,
     "6473e3420e8d9a7646b39f4988c41f3dab0be857cb491a2616ccc1004900f7ad",
     {0xc97ff6853cbede30ULL, 0x648a1cc48e031798ULL,
      0xe28d4bb83f27c1aeULL}},
    {StageTag::configured_arrival,
     "6765ea68ff641b0a7e3e713669072b41b573220e8d28c08084ce7ec526b38534",
     {0x7cf3483b214d3893ULL, 0x94498a662ca9d91eULL,
      0x03b5601906687324ULL}},
    {StageTag::postarrival_closure,
     "176655b9a62fd9dbbf9f86693367e20b715b21108ce5f8a2d102e677c171569b",
     {0x85503f04a15dfad7ULL, 0xd255e241c5ad8620ULL,
      0x11b8a4d9e097244aULL}},
    {StageTag::controller_post,
     "d79da3b2781757503fc551e80f2925c5a5991c3f319d1d17952239d265e3258c",
     {0xd7b2e5551dd1d197ULL, 0x8b73e6b55d4cef52ULL,
      0x4d1e6c9a1d1857cbULL}},
    {StageTag::generic_sampling,
     "13dd2944e001f969e1f3b3992264c82a2ab8d3c073ba3f1b06789e4a2ae607a2",
     {0xeb48f585db97b2d4ULL, 0x356d1c221ac2bd05ULL,
      0x5aed0578d1e4d88eULL}},
    {StageTag::importance_proposal,
     "272dc359544cdbb3fd39109ea6a0d949e699bf267a8de0009da018a311607f30",
     {0x83f5f1a52318eec1ULL, 0x6e11d27c9a72f9cfULL,
      0x053f8546417583adULL}},
    {StageTag::training,
     "86c7ccbecec456d1102834ac67d2dd9874503be4d599ba9d0419906d6dfa041c",
     {0x88a127200879dd68ULL, 0xdab929f295e123e6ULL,
      0x53f5e11d4247072cULL}},
    {StageTag::solver_sampling,
     "c16c636baba7d5bc06c32439bab6f99247ffd403cd93c329ce104ac06d437625",
     {0x26af12e914ef5590ULL, 0x14f2b1e182021fc0ULL,
      0xd9a76bb96e60f439ULL}},
    {StageTag::surrogate_build_input,
     "f08dd06e1a45155ad4d445d112818005794fc2936b7a5b9dfcfebd9554f71426",
     {0xa822e02061c07134ULL, 0x76a966c4452c10a8ULL,
      0xe4e9d2eb2c2168ebULL}},
    {StageTag::surrogate_build_context,
     "c2ed4a43d594a3fe51e9f1aa7b993fae52106affbe15a28a431bb9019fb4bcde",
     {0x0fbd7bdcf818cdacULL, 0x5460706a21862c72ULL,
      0x3d63dcb368bc5426ULL}},
    {StageTag::surrogate_build_probe,
     "3cf7c39ab8be3cc787ba9f885264d1c8bb11375d6ec5d749034d45a309c56cbf",
     {0xe7057b3ddc7016ebULL, 0x1f6e7d1cbe9f2700ULL,
      0xf41219a9ae928c09ULL}},
    {StageTag::surrogate_build_final,
     "c25c1632df6f497262f0e87721c5ad0d3f6612525518ffb16b1f77adcad8c408",
     {0x2c6e7877dfb5a8afULL, 0x55c0149727719b87ULL,
      0xb77ec900c0ef3ab0ULL}},
}};

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::InstanceKey>);
static_assert(!std::is_default_constructible_v<mwperf::BuildIdentityDigest>);
static_assert(!std::is_default_constructible_v<mwperf::BuildSeed>);
static_assert(!std::is_default_constructible_v<mwperf::RngCheckpoint>);
static_assert(!std::is_default_constructible_v<mwperf::DeterministicRng>);
static_assert(!std::is_copy_constructible_v<mwperf::DeterministicRng>);
static_assert(!std::is_copy_assignable_v<mwperf::DeterministicRng>);
static_assert(std::is_move_constructible_v<mwperf::DeterministicRng>);
static_assert(std::is_move_assignable_v<mwperf::DeterministicRng>);

TEST_CASE("RNG stage tags are the frozen append-only version-1 table",
          "[c02][unit][rng]") {
  const std::array<std::uint16_t, 14> expected{
      0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007,
      0x0008, 0x0009, 0x000a, 0x000b, 0x000c, 0x000d, 0x000e};
  for (std::size_t index = 0; index < kStageVectors.size(); ++index) {
    CHECK(mwperf::stage_tag_value(kStageVectors[index].stage) ==
          expected[index]);
  }
  CHECK(mwperf::kRngVersion == 1U);

  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  REQUIRE(key);
  CHECK_THROWS_AS(mwperf::testing::rng_derivation_preimage(
                      MasterSeed(0), static_cast<StageTag>(0), key.value()),
                  std::invalid_argument);
}

TEST_CASE("fixed route tuples produce byte-stable instance keys",
          "[c02][unit][rng]") {
  const BigNat id = natural(258);
  const auto physical =
      mwperf::make_physical_reference_instance_key(digest_a(), id);
  REQUIRE(physical);
  CHECK(physical.value().digest().hex() ==
        "071fcb81910967bcddf952315db61fc572824d579e68ff11f08f84f2eaf5d549");
  const auto physical_preimage =
      mwperf::testing::physical_reference_instance_key_preimage(digest_a(), id);
  check_instance_preimage(
      physical_preimage,
      "6d77706572662e726e672e696e7374616e63650000000001"
      "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
      "1718191a1b1c1d1e1f020000000000000012706879736963616c5f7265666572"
      "656e63650300000000000000020102",
      physical.value().digest());

  const auto temporal =
      mwperf::make_temporal_path_instance_key(digest_a(), digest_b(), id);
  REQUIRE(temporal);
  CHECK(temporal.value().digest().hex() ==
        "b80ab316a31f8ede1777953b2ae03c7e08dafa47dfa7894fe0981e70f9b947a4");
  const auto temporal_preimage =
      mwperf::testing::temporal_path_instance_key_preimage(
          digest_a(), digest_b(), id);
  check_instance_preimage(
      temporal_preimage,
      "6d77706572662e726e672e696e7374616e63650000000001"
      "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
      "1718191a1b1c1d1e1f010000000000000020202122232425262728292a2b2c2d"
      "2e2f303132333435363738393a3b3c3d3e3f02000000000000000d74656d70"
      "6f72616c5f706174680300000000000000020102",
      temporal.value().digest());

  const auto estimator = mwperf::make_estimator_instance_key(
      digest_a(), digest_b(), "estimator.alpha", id);
  REQUIRE(estimator);
  CHECK(estimator.value().digest().hex() ==
        "6518444aa746cb616260c02c2316a57b627249ee17a304337e4257c6dc3b13ba");
  const auto estimator_preimage =
      mwperf::testing::estimator_instance_key_preimage(
          digest_a(), digest_b(), "estimator.alpha", id);
  REQUIRE(estimator_preimage);
  check_instance_preimage(
      estimator_preimage.value(),
      "6d77706572662e726e672e696e7374616e63650000000001"
      "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
      "1718191a1b1c1d1e1f050000000000000020202122232425262728292a2b2c2d"
      "2e2f303132333435363738393a3b3c3d3e3f02000000000000000f65737469"
      "6d61746f722e616c7068610300000000000000020102",
      estimator.value().digest());

  const auto internal = mwperf::make_internal_draw_instance_key(
      digest_a(), digest_b(), "branch/\xce\xb2");
  REQUIRE(internal);
  CHECK(internal.value().digest().hex() ==
        "b9c38838287898ccff1a913ab520f41275e1b47fadd24ab300edf3b9b8757e82");
  const auto internal_preimage =
      mwperf::testing::internal_draw_instance_key_preimage(
          digest_a(), digest_b(), "branch/\xce\xb2");
  REQUIRE(internal_preimage);
  check_instance_preimage(
      internal_preimage.value(),
      "6d77706572662e726e672e696e7374616e63650000000001"
      "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
      "1718191a1b1c1d1e1f050000000000000020202122232425262728292a2b2c2d"
      "2e2f303132333435363738393a3b3c3d3e3f0200000000000000096272616e"
      "63682fceb2",
      internal.value().digest());

  const auto target = TypedLabel::numeric(natural(256));
  const auto build = mwperf::make_surrogate_build_instance_key(
      BuildIdentityDigest(digest_a()), "provider", "1.2.3", target, id);
  REQUIRE(build);
  CHECK(build.value().digest().hex() ==
        "99110c0d3cbb9d87b0c092a8399ef15447f060957073e987a7d1ec89f19561c5");
  const auto build_preimage =
      mwperf::testing::surrogate_build_instance_key_preimage(
          BuildIdentityDigest(digest_a()), "provider", "1.2.3", target, id);
  REQUIRE(build_preimage);
  check_instance_preimage(
      build_preimage.value(),
      "6d77706572662e726e672e696e7374616e63650000000001"
      "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
      "1718191a1b1c1d1e1f02000000000000000870726f7669646572020000000000"
      "000005312e322e330400000000000000030001000300000000000000020102",
      build.value().digest());
}

TEST_CASE("component tags and lengths preserve label and text identity",
          "[c02][unit][rng]") {
  const BuildIdentityDigest build_digest(digest_a());
  const BigNat zero(std::uint64_t{0});
  const auto numeric_zero = mwperf::make_surrogate_build_instance_key(
      build_digest, "", "", TypedLabel::numeric(BigNat(std::uint64_t{0})), zero);
  REQUIRE(numeric_zero);
  CHECK(numeric_zero.value().digest().hex() ==
        "b63ffce18fdbb0c3758adbf8e7f064e2658766239570312adf18c602fe7c996a");
  const auto numeric_zero_preimage =
      mwperf::testing::surrogate_build_instance_key_preimage(
          build_digest, "", "", TypedLabel::numeric(BigNat(std::uint64_t{0})),
          zero);
  REQUIRE(numeric_zero_preimage);
  CHECK(hex_bytes(numeric_zero_preimage.value()) ==
        "6d77706572662e726e672e696e7374616e63650000000001"
        "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
        "1718191a1b1c1d1e1f0200000000000000000200000000000000000400000000"
        "00000002000003000000000000000100");

  auto string_zero_label = TypedLabel::text("0");
  REQUIRE(string_zero_label);
  const auto string_zero = mwperf::make_surrogate_build_instance_key(
      build_digest, "", "", string_zero_label.value(), zero);
  REQUIRE(string_zero);
  CHECK(string_zero.value().digest().hex() ==
        "1185cc50c0a3dc58b4fe7ec9f3491b97db44c97e489213cfcd030b4b6a3096fa");
  CHECK(numeric_zero.value() != string_zero.value());
  const auto string_zero_preimage =
      mwperf::testing::surrogate_build_instance_key_preimage(
          build_digest, "", "", string_zero_label.value(), zero);
  REQUIRE(string_zero_preimage);
  CHECK(hex_bytes(string_zero_preimage.value()) ==
        "6d77706572662e726e672e696e7374616e63650000000001"
        "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
        "1718191a1b1c1d1e1f0200000000000000000200000000000000000400000000"
        "00000002013003000000000000000100");

  auto unicode_label = TypedLabel::text("\xce\xbb");
  REQUIRE(unicode_label);
  const auto adjacent_left = mwperf::make_surrogate_build_instance_key(
      build_digest, "a", "bc", unicode_label.value(), zero);
  const auto adjacent_right = mwperf::make_surrogate_build_instance_key(
      build_digest, "ab", "c", unicode_label.value(), zero);
  REQUIRE(adjacent_left);
  REQUIRE(adjacent_right);
  CHECK(adjacent_left.value().digest().hex() ==
        "a237abb90212768214c750c3516f02c4d68ba0e504d225c98d9a1f6ab472aa6f");
  CHECK(adjacent_right.value().digest().hex() ==
        "2fe482f5a8a6f1fadd2171e88f7e3438457ccc7b22ee5350619f3d3d46bad0db");
  CHECK(adjacent_left.value() != adjacent_right.value());
  const auto unicode_preimage =
      mwperf::testing::surrogate_build_instance_key_preimage(
          build_digest, "a", "bc", unicode_label.value(), zero);
  const auto adjacent_preimage =
      mwperf::testing::surrogate_build_instance_key_preimage(
          build_digest, "ab", "c", unicode_label.value(), zero);
  REQUIRE(unicode_preimage);
  REQUIRE(adjacent_preimage);
  CHECK(hex_bytes(unicode_preimage.value()) ==
        "6d77706572662e726e672e696e7374616e63650000000001"
        "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
        "1718191a1b1c1d1e1f0200000000000000016102000000000000000262630400"
        "0000000000000301cebb03000000000000000100");
  CHECK(hex_bytes(adjacent_preimage.value()) ==
        "6d77706572662e726e672e696e7374616e63650000000001"
        "010000000000000020000102030405060708090a0b0c0d0e0f10111213141516"
        "1718191a1b1c1d1e1f0200000000000000026162020000000000000001630400"
        "0000000000000301cebb03000000000000000100");

  const auto empty_estimator = mwperf::make_estimator_instance_key(
      digest_a(), digest_b(), "", zero);
  REQUIRE(empty_estimator);
  CHECK(empty_estimator.value().digest().hex() ==
        "e52b40b6581bdf5cedd27fad2070e13269efb2b18bbd42eac221e120f18da276");
}

TEST_CASE("instance key text components reject malformed UTF-8",
          "[c02][negative][rng]") {
  const std::string malformed("\xc0\x80", 2);
  const auto estimator = mwperf::make_estimator_instance_key(
      digest_a(), digest_b(), malformed, BigNat(std::uint64_t{0}));
  REQUIRE_FALSE(estimator);
  CHECK(estimator.error().code == "invalid_rng_utf8_component");

  auto label = TypedLabel::text("target");
  REQUIRE(label);
  const auto build = mwperf::make_surrogate_build_instance_key(
      BuildIdentityDigest(digest_a()), malformed, "1", label.value(),
      BigNat(std::uint64_t{0}));
  REQUIRE_FALSE(build);
  CHECK(build.error().code == "invalid_rng_utf8_component");
}

TEST_CASE("build seed binds only master seed and opaque precursor digest",
          "[c02][unit][rng]") {
  constexpr MasterSeed master(0x0123456789abcdefULL);
  const BuildIdentityDigest identity_a(digest_a());
  const BuildIdentityDigest identity_b(digest_b());
  const BuildSeed seed(master, identity_a);
  CHECK(hex_bytes(seed.canonical_bytes()) ==
        "000000010123456789abcdef"
        "000102030405060708090a0b0c0d0e0f"
        "101112131415161718191a1b1c1d1e1f");
  CHECK(seed.rng_version() == 1U);
  CHECK(seed.master_seed() == master);
  CHECK(seed.is_bound_to(identity_a));
  CHECK_FALSE(seed.is_bound_to(identity_b));
  CHECK(seed != BuildSeed(MasterSeed(master.value() + 1U), identity_a));
  CHECK(seed != BuildSeed(master, identity_b));
  CHECK(identity_a.digest() == digest_a());
}

TEST_CASE("stream derivation preimage state and xoshiro words match vectors",
          "[c02][unit][rng]") {
  constexpr MasterSeed master(0x0123456789abcdefULL);
  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), natural(258));
  REQUIRE(key);

  const auto preimage = mwperf::testing::rng_derivation_preimage(
      master, StageTag::initial_joint_atom, key.value());
  CHECK(hex_bytes(preimage) ==
        "6d77706572662e726e672e786f736869726f323536737300"
        "000000010123456789abcdef0001"
        "071fcb81910967bcddf952315db61fc5"
        "72824d579e68ff11f08f84f2eaf5d549");

  for (const StageVector& expected : kStageVectors) {
    auto rng = mwperf::derive_rng_stream(master, expected.stage, key.value());
    CHECK(rng.stream_identity().hex() == expected.state);
    const auto checkpoint = rng.checkpoint();
    CHECK(checkpoint.rng_version() == 1U);
    CHECK(checkpoint.stream_identity().hex() == expected.state);
    for (const std::uint64_t output : expected.outputs) {
      CHECK(rng.next_u64() == output);
    }
    CHECK(rng.consumed_words().to_decimal_string() == "3");
  }
}

TEST_CASE("every fixed route identity has a stream golden vector",
          "[c02][unit][rng]") {
  constexpr MasterSeed master(0x0123456789abcdefULL);
  const BigNat id = natural(258);
  const auto physical =
      mwperf::make_physical_reference_instance_key(digest_a(), id);
  const auto temporal =
      mwperf::make_temporal_path_instance_key(digest_a(), digest_b(), id);
  const auto estimator = mwperf::make_estimator_instance_key(
      digest_a(), digest_b(), "estimator.alpha", id);
  const auto internal = mwperf::make_internal_draw_instance_key(
      digest_a(), digest_b(), "branch/\xce\xb2");
  const auto build = mwperf::make_surrogate_build_instance_key(
      BuildIdentityDigest(digest_a()), "provider", "1.2.3",
      TypedLabel::numeric(natural(256)), id);
  REQUIRE(physical);
  REQUIRE(temporal);
  REQUIRE(estimator);
  REQUIRE(internal);
  REQUIRE(build);

  const auto check = [&master](const mwperf::InstanceKey& key,
                               std::string_view state,
                               const std::uint64_t first_word) {
    auto rng = mwperf::derive_rng_stream(master, StageTag::generic_sampling,
                                         key);
    CHECK(rng.stream_identity().hex() == state);
    CHECK(rng.next_u64() == first_word);
  };
  check(physical.value(),
        "13dd2944e001f969e1f3b3992264c82a2ab8d3c073ba3f1b06789e4a2ae607a2",
        0xeb48f585db97b2d4ULL);
  check(temporal.value(),
        "94bac3c56b064ad7532233fbad60f780790217db45f628969e287e03d66c5ecf",
        0x81919ebd05c0c2c7ULL);
  check(estimator.value(),
        "01030e971e8df9282b913505f67a4760680e933593a3e8d9b1958fbc2599b9e2",
        0x43290629bf45f3ccULL);
  check(internal.value(),
        "28bb71a01addc2536bf3dc5a195664a7ee973c75a90a1233cbda999812624a6b",
        0xeeddeb3a17d8adf5ULL);
  check(build.value(),
        "d0f82dfc1825e197b9728f95ef62b2616958469989b86a301e08aac8d73f1231",
        0x919ead8a2cad8947ULL);
}

TEST_CASE("digest-to-state uses big endian and repairs only all-zero state",
          "[c02][unit][rng]") {
  const auto all_zero = digest(std::string(64, '0'));
  CHECK(mwperf::testing::decode_rng_state(all_zero) ==
        std::array<std::uint64_t, 4>{0x9e3779b97f4a7c15ULL, 0U, 0U, 0U});

  const auto individual_zero = digest(
      "00000000000000000000000000000001"
      "0102030405060708f0e0d0c0b0a09080");
  CHECK(mwperf::testing::decode_rng_state(individual_zero) ==
        std::array<std::uint64_t, 4>{0U, 1U, 0x0102030405060708ULL,
                                     0xf0e0d0c0b0a09080ULL});
}

TEST_CASE("derivation is independent of call order and separates key inputs",
          "[c02][property][rng]") {
  const auto key_zero = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  const auto key_one = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{1}));
  REQUIRE(key_zero);
  REQUIRE(key_one);

  auto first_a = mwperf::derive_rng_stream(
      MasterSeed(4), StageTag::generic_sampling, key_zero.value());
  auto other = mwperf::derive_rng_stream(
      MasterSeed(4), StageTag::training, key_one.value());
  auto second_a = mwperf::derive_rng_stream(
      MasterSeed(4), StageTag::generic_sampling, key_zero.value());
  CHECK(first_a.derivation_stage() == StageTag::generic_sampling);
  CHECK(other.derivation_stage() == StageTag::training);
  CHECK(first_a.next_u64() == second_a.next_u64());
  CHECK(first_a.stream_identity() == second_a.stream_identity());
  CHECK(other.stream_identity() != first_a.stream_identity());

  auto changed_seed = mwperf::derive_rng_stream(
      MasterSeed(5), StageTag::generic_sampling, key_zero.value());
  auto changed_stage = mwperf::derive_rng_stream(
      MasterSeed(4), StageTag::solver_sampling, key_zero.value());
  auto changed_key = mwperf::derive_rng_stream(
      MasterSeed(4), StageTag::generic_sampling, key_one.value());
  CHECK(changed_seed.stream_identity() != first_a.stream_identity());
  CHECK(changed_stage.stream_identity() != first_a.stream_identity());
  CHECK(changed_key.stream_identity() != first_a.stream_identity());
}

TEST_CASE("construction stages are mutually isolated named streams",
          "[c02][property][rng]") {
  auto label = TypedLabel::text("group");
  REQUIRE(label);
  const auto key = mwperf::make_surrogate_build_instance_key(
      BuildIdentityDigest(digest_a()), "provider", "1", label.value(),
      BigNat(std::uint64_t{7}));
  const auto changed_precursor_key =
      mwperf::make_surrogate_build_instance_key(
          BuildIdentityDigest(digest_b()), "provider", "1", label.value(),
          BigNat(std::uint64_t{7}));
  REQUIRE(key);
  REQUIRE(changed_precursor_key);

  auto input = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_input, key.value());
  auto context = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_context, key.value());
  auto probe = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_probe, key.value());
  auto final = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_final, key.value());
  const auto context_expected = context.next_u64();
  const auto probe_expected = probe.next_u64();
  const auto final_expected = final.next_u64();
  for (int count = 0; count < 100; ++count) {
    static_cast<void>(input.next_u64());
  }
  auto context_replay = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_context, key.value());
  auto probe_replay = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_probe, key.value());
  auto final_replay = mwperf::derive_rng_stream(
      MasterSeed(11), StageTag::surrogate_build_final, key.value());
  CHECK(context_replay.next_u64() == context_expected);
  CHECK(probe_replay.next_u64() == probe_expected);
  CHECK(final_replay.next_u64() == final_expected);

  for (const StageTag stage :
       {StageTag::surrogate_build_input, StageTag::surrogate_build_context,
        StageTag::surrogate_build_probe, StageTag::surrogate_build_final}) {
    auto original = mwperf::derive_rng_stream(MasterSeed(11), stage, key.value());
    auto changed = mwperf::derive_rng_stream(
        MasterSeed(11), stage, changed_precursor_key.value());
    CHECK(original.stream_identity() != changed.stream_identity());
  }
}

TEST_CASE("temporal route excludes horizon and preserves run prefixes",
          "[c02][property][rng]") {
  const auto key = mwperf::make_temporal_path_instance_key(
      digest_a(), digest_b(), BigNat(std::uint64_t{9}));
  const auto another_path = mwperf::make_temporal_path_instance_key(
      digest_a(), digest_b(), BigNat(std::uint64_t{10}));
  REQUIRE(key);
  REQUIRE(another_path);
  auto short_run = mwperf::derive_rng_stream(
      MasterSeed(17), StageTag::configured_arrival, key.value());
  auto extended_run = mwperf::derive_rng_stream(
      MasterSeed(17), StageTag::configured_arrival, key.value());
  for (int position = 0; position < 32; ++position) {
    CHECK(short_run.next_u64() == extended_run.next_u64());
  }
  for (int extension = 0; extension < 13; ++extension) {
    static_cast<void>(extended_run.next_u64());
  }
  auto other = mwperf::derive_rng_stream(
      MasterSeed(17), StageTag::configured_arrival, another_path.value());
  CHECK(other.stream_identity() != short_run.stream_identity());
}

TEST_CASE("exact categorical lookup gives zero masses no integer",
          "[c02][unit][rng]") {
  const auto one_cell = pmf_from_masses({BigInt(1)});
  auto result = mwperf::testing::sample_categorical_with_script(one_cell, {});
  REQUIRE(result);
  CHECK(result.value() == mwperf::testing::ScriptedCategoricalResult{0U, 0U});

  const auto leading = pmf_from_masses({BigInt(0), BigInt(1), BigInt(1)});
  const std::array<std::uint64_t, 1> zero_word{0U};
  const std::array<std::uint64_t, 1> one_word{1U};
  REQUIRE(mwperf::testing::sample_categorical_with_script(leading, zero_word));
  CHECK(mwperf::testing::sample_categorical_with_script(leading, zero_word)
            .value()
            .index == 1U);
  CHECK(mwperf::testing::sample_categorical_with_script(leading, one_word)
            .value()
            .index == 2U);

  const auto interior = pmf_from_masses({BigInt(1), BigInt(0), BigInt(1)});
  CHECK(mwperf::testing::sample_categorical_with_script(interior, one_word)
            .value()
            .index == 2U);

  const auto trailing = pmf_from_masses({BigInt(1), BigInt(1), BigInt(0)});
  CHECK(mwperf::testing::sample_categorical_with_script(trailing, one_word)
            .value()
            .index == 1U);
}

TEST_CASE("categorical rejection uses exact arbitrary-precision blocks",
          "[c02][unit][rng]") {
  const auto power_of_two = pmf_from_masses({BigInt(1), BigInt(3)});
  const std::array<std::uint64_t, 1> all_bits{
      std::numeric_limits<std::uint64_t>::max()};
  auto power_result = mwperf::testing::sample_categorical_with_script(
      power_of_two, all_bits);
  REQUIRE(power_result);
  CHECK(power_result.value() ==
        mwperf::testing::ScriptedCategoricalResult{1U, 1U});

  const auto just_above = pmf_from_masses({BigInt(1), BigInt(4)});
  const std::array<std::uint64_t, 4> rejected_twice{7U, 6U, 4U,
                                                   0xdeadbeefU};
  auto rejected = mwperf::testing::sample_categorical_with_script(
      just_above, rejected_twice);
  REQUIRE(rejected);
  CHECK(rejected.value() ==
        mwperf::testing::ScriptedCategoricalResult{1U, 3U});
  CHECK(rejected_twice[rejected.value().consumed_words] == 0xdeadbeefU);

  const BigInt two_to_64 = BigInt(1) << 64U;
  const auto wide = pmf_from_masses({two_to_64, BigInt(1)});
  const std::array<std::uint64_t, 4> wide_words{
      std::numeric_limits<std::uint64_t>::max(), 1U, 0U, 1U};
  auto wide_result =
      mwperf::testing::sample_categorical_with_script(wide, wide_words);
  REQUIRE(wide_result);
  CHECK(wide_result.value() ==
        mwperf::testing::ScriptedCategoricalResult{1U, 4U});

  const BigInt two_to_130 = BigInt(1) << 130U;
  const auto multi_limb = pmf_from_masses({two_to_130, BigInt(1)});
  const std::array<std::uint64_t, 6> multi_words{
      std::numeric_limits<std::uint64_t>::max(),
      std::numeric_limits<std::uint64_t>::max(), 7U, 0U, 0U, 4U};
  auto multi_result = mwperf::testing::sample_categorical_with_script(
      multi_limb, multi_words);
  REQUIRE(multi_result);
  CHECK(multi_result.value() ==
        mwperf::testing::ScriptedCategoricalResult{1U, 6U});
}

TEST_CASE("script exhaustion never falls back to biased sampling",
          "[c02][negative][rng]") {
  const auto law = pmf_from_masses({BigInt(1), BigInt(4)});
  const std::array<std::uint64_t, 1> rejected{7U};
  const auto result =
      mwperf::testing::sample_categorical_with_script(law, rejected);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "rng_script_exhausted");
}

TEST_CASE("small exact categorical laws own exactly their integral masses",
          "[c02][property][rng]") {
  const std::array<std::uint64_t, 5> masses{0U, 2U, 1U, 0U, 4U};
  std::vector<BigInt> exact_masses;
  for (const auto mass : masses) {
    exact_masses.emplace_back(mass);
  }
  const auto law = pmf_from_masses(exact_masses);
  std::array<std::size_t, 5> observed{};
  for (std::uint64_t integer = 0; integer < 7U; ++integer) {
    const std::array<std::uint64_t, 1> word{integer};
    const auto sample =
        mwperf::testing::sample_categorical_with_script(law, word);
    REQUIRE(sample);
    ++observed[sample.value().index];
  }
  for (std::size_t index = 0; index < masses.size(); ++index) {
    CHECK(observed[index] == masses[index]);
  }
}

TEST_CASE("an exact positive mass survives a zero long-double image",
          "[c02][unit][rng]") {
  BigInt denominator = 1;
  const int decimal_exponent =
      std::numeric_limits<long double>::max_exponent10 + 100;
  for (int digit = 0; digit < decimal_exponent; ++digit) {
    denominator *= 10;
  }
  const auto law =
      pmf_from_masses({BigInt(1), BigInt(denominator - BigInt(1))});
  REQUIRE(law.authored_probabilities().front().exact_value().is_positive());
  CHECK(law.authored_probabilities().front().numerical_image() == 0.0L);
  const std::size_t words =
      (law.integral_denominator().bit_length() + 63U) / 64U;
  const std::vector<std::uint64_t> zeros(words, 0U);
  const auto sample =
      mwperf::testing::sample_categorical_with_script(law, zeros);
  REQUIRE(sample);
  CHECK(sample.value().index == 0U);
}

TEST_CASE("RNG checkpoints and transactions restore exact advancement",
          "[c02][integration][rng]") {
  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), natural(258));
  REQUIRE(key);
  auto rng = mwperf::derive_rng_stream(
      MasterSeed(0x0123456789abcdefULL), StageTag::initial_joint_atom,
      key.value());

  const auto accepted_law = pmf_from_masses({BigInt(1), BigInt(1)});
  std::size_t accepted_index = 0;
  std::uint64_t accepted_following = 0;
  {
    mwperf::RngTransaction transaction(rng);
    accepted_index = mwperf::sample_categorical(accepted_law, rng);
    accepted_following = rng.next_u64();
  }
  CHECK(rng.consumed_words().to_decimal_string() == "0");
  CHECK(mwperf::sample_categorical(accepted_law, rng) == accepted_index);
  CHECK(rng.next_u64() == accepted_following);

  auto rejection_rng = mwperf::derive_rng_stream(
      MasterSeed(0x0123456789abcdefULL), StageTag::initial_joint_atom,
      key.value());
  const auto rejection_law = pmf_from_masses({BigInt(1), BigInt(8)});
  std::size_t rejected_index = 0;
  std::uint64_t rejected_following = 0;
  {
    mwperf::RngTransaction transaction(rejection_rng);
    rejected_index = mwperf::sample_categorical(rejection_law, rejection_rng);
    CHECK(rejection_rng.consumed_words().to_decimal_string() == "2");
    rejected_following = rejection_rng.next_u64();
  }
  CHECK(rejection_rng.consumed_words().to_decimal_string() == "0");
  CHECK(mwperf::sample_categorical(rejection_law, rejection_rng) ==
        rejected_index);
  CHECK(rejection_rng.next_u64() == rejected_following);

  {
    mwperf::RngTransaction transaction(rejection_rng);
    static_cast<void>(rejection_rng.next_u64());
    transaction.commit();
  }
  CHECK(rejection_rng.consumed_words().to_decimal_string() == "4");
}

TEST_CASE("checkpoint restore rejects another stream without mutation",
          "[c02][negative][rng]") {
  const auto key_zero = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  const auto key_one = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{1}));
  REQUIRE(key_zero);
  REQUIRE(key_one);
  auto first = mwperf::derive_rng_stream(
      MasterSeed(3), StageTag::generic_sampling, key_zero.value());
  auto second = mwperf::derive_rng_stream(
      MasterSeed(3), StageTag::generic_sampling, key_one.value());
  const auto foreign = first.checkpoint();
  const auto before = second.checkpoint();
  const auto restore = second.restore(foreign);
  REQUIRE_FALSE(restore);
  CHECK(restore.error().code == "rng_checkpoint_stream_mismatch");
  const auto after = second.checkpoint();
  CHECK(after.stream_identity() == before.stream_identity());
  CHECK(after.state_words() == before.state_words());
  CHECK(after.consumed_words() == before.consumed_words());
}

TEST_CASE("checkpoint restore rejects another RNG version without mutation",
          "[c02][negative][rng]") {
  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  REQUIRE(key);
  auto rng = mwperf::derive_rng_stream(
      MasterSeed(3), StageTag::generic_sampling, key.value());
  static_cast<void>(rng.next_u64());
  const auto before = rng.checkpoint();
  const auto incompatible =
      mwperf::testing::checkpoint_with_version(before, 2U);
  const auto restore = rng.restore(incompatible);
  REQUIRE_FALSE(restore);
  CHECK(restore.error().code == "rng_checkpoint_version_mismatch");
  const auto after = rng.checkpoint();
  CHECK(after.stream_identity() == before.stream_identity());
  CHECK(after.state_words() == before.state_words());
  CHECK(after.consumed_words() == before.consumed_words());
}

TEST_CASE("moving a checkpoint preserves a consistent usable source",
          "[c02][integration][rng]") {
  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  REQUIRE(key);
  auto rng = mwperf::derive_rng_stream(
      MasterSeed(21), StageTag::generic_sampling, key.value());
  static_cast<void>(rng.next_u64());
  static_cast<void>(rng.next_u64());
  auto source = rng.checkpoint();
  const auto expected_state = source.state_words();
  const auto expected_count = source.consumed_words();
  auto destination = std::move(source);

  CHECK(source.state_words() == expected_state);
  CHECK(source.consumed_words() == expected_count);
  CHECK(destination.state_words() == expected_state);
  CHECK(destination.consumed_words() == expected_count);

  static_cast<void>(rng.next_u64());
  REQUIRE(rng.restore(source));
  CHECK(rng.checkpoint().state_words() == expected_state);
  CHECK(rng.consumed_words() == expected_count);
  static_cast<void>(rng.next_u64());
  REQUIRE(rng.restore(destination));
  CHECK(rng.checkpoint().state_words() == expected_state);
  CHECK(rng.consumed_words() == expected_count);
}

TEST_CASE("an open transaction pins its sole live RNG cursor",
          "[c02][negative][rng]") {
  const auto key_zero = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  const auto key_one = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{1}));
  REQUIRE(key_zero);
  REQUIRE(key_one);
  auto pinned = mwperf::derive_rng_stream(
      MasterSeed(31), StageTag::generic_sampling, key_zero.value());
  auto replacement = mwperf::derive_rng_stream(
      MasterSeed(31), StageTag::generic_sampling, key_one.value());
  auto destination = mwperf::derive_rng_stream(
      MasterSeed(32), StageTag::generic_sampling, key_one.value());
  const auto pinned_before = pinned.checkpoint();
  const auto replacement_before = replacement.checkpoint();
  const auto destination_before = destination.checkpoint();

  {
    mwperf::RngTransaction transaction(pinned);
    static_cast<void>(pinned.next_u64());
    CHECK_THROWS_AS(
        [&pinned] {
          auto forbidden = std::move(pinned);
          static_cast<void>(forbidden);
        }(),
        std::logic_error);
    CHECK_THROWS_AS(pinned = std::move(replacement), std::logic_error);
    CHECK_THROWS_AS(destination = std::move(pinned), std::logic_error);
    CHECK_THROWS_AS(mwperf::RngTransaction(pinned), std::logic_error);
  }

  CHECK(pinned.checkpoint().state_words() == pinned_before.state_words());
  CHECK(pinned.consumed_words() == pinned_before.consumed_words());
  CHECK(replacement.checkpoint().state_words() ==
        replacement_before.state_words());
  CHECK(replacement.consumed_words() == replacement_before.consumed_words());
  CHECK(destination.checkpoint().state_words() ==
        destination_before.state_words());
  CHECK(destination.consumed_words() == destination_before.consumed_words());

  CHECK_NOTHROW(destination = std::move(pinned));
  CHECK_THROWS_AS(pinned.next_u64(), std::logic_error);
}

TEST_CASE("moved RNG transfers the sole live cursor",
          "[c02][negative][rng]") {
  const auto key = mwperf::make_physical_reference_instance_key(
      digest_a(), BigNat(std::uint64_t{0}));
  REQUIRE(key);
  auto source = mwperf::derive_rng_stream(
      MasterSeed(8), StageTag::generic_sampling, key.value());
  auto destination = std::move(source);
  CHECK_NOTHROW(destination.next_u64());
  CHECK_THROWS_AS(source.next_u64(), std::logic_error);
}
