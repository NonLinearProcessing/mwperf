#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <iterator>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "fixtures/c15/c15_golden_sources.hpp"
#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/finite_prefix_constant_tail_response.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"
#include "surrogate/finite_prefix_constant_tail_validation.hpp"
#include "surrogate/payload_wire.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
namespace wire = mwperf::artifact::detail::wire;

[[nodiscard]] mwperf::TypedLabel label(const std::string& text) {
  auto parsed = mwperf::TypedLabel::text(text);
  REQUIRE(parsed);
  return std::move(parsed).value();
}

[[nodiscard]] mwperf::QueueId queue_id(const std::string& text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::PortId port_id(const std::string& text) {
  return mwperf::PortId(label(text));
}

[[nodiscard]] mwperf::VertexId vertex_id(const std::string& text) {
  return mwperf::VertexId(label(text));
}

[[nodiscard]] mwperf::ResourceId resource_id(const std::string& text) {
  return mwperf::ResourceId(label(text));
}

[[nodiscard]] mwperf::MetricClauseIdV1 clause_id(const std::string& text) {
  return {text, 0U};
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::PortableScientificScalar scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return mwperf::PortableScientificScalar::rational(
      rational(numerator, denominator));
}

[[nodiscard]] mwperf::PortableScientificScalar binary_scalar(
    const double value) {
  auto result = mwperf::PortableScientificScalar::from_binary64(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 digest_of(const std::string& text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  auto result = mwperf::sha256(bytes);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 digest_from_hex(
    const std::string_view text) {
  auto result = mwperf::Digest256::from_hex(std::string(text));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 zero_digest() {
  auto result = mwperf::Digest256::from_hex(std::string(64U, '0'));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<std::byte> bytes_of(const std::string& text);

struct ProtocolInputFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
};

[[nodiscard]] std::filesystem::path write_protocol_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next_id{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c15-protocol";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(next_id.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string protocol_analysis_text(
    const std::string_view selection, const std::string_view metrics) {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":)json") + std::string(metrics) + R"json(,
    "surrogate":{"id":"c15.fixture.provider","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" + std::string(selection) + R"json(,
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                  "max_iterations":null}}
  })json";
}

[[nodiscard]] mwperf::Result<mwperf::AnalysisSpec> parse_protocol_analysis(
    const std::string_view selection,
    const std::string_view metrics =
        R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json") {
  auto document = mwperf::load_document(write_protocol_input(
      "analysis-selection", protocol_analysis_text(selection, metrics)));
  if (!document) {
    return mwperf::Result<mwperf::AnalysisSpec>::failure(document.error());
  }
  return mwperf::parse_analysis_spec_v1(document.value());
}

[[nodiscard]] ProtocolInputFixture make_protocol_input_fixture(
    const std::string_view selection =
        R"json({"kind":"stationary_unique","parameters":{}})json",
    const std::string_view metrics =
        R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
    const std::string_view scheduler = {},
    const std::string_view arrival = {},
    const std::string_view queues = {}) {
  static constexpr std::string_view default_scheduler = R"json(
      {"name":"conflict_graph_max_weight","params":{
        "constraint":{"conflicts":[]},"priority":["q0","q1"],
        "max_search_states":null}})json";
  static constexpr std::string_view default_arrival = R"json(
      {"family":"deterministic_trace","events":[],"metadata":{}})json";
  static constexpr std::string_view default_queues =
      R"json([{"id":"q0"},{"id":"q1"}])json";
  const std::string model_text = std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,"queues":)json") +
      std::string(queues.empty() ? default_queues : queues) + R"json(},
    "scheduler":)json" +
      std::string(scheduler.empty() ? default_scheduler : scheduler) +
      R"json(,"arrival":)json" +
      std::string(arrival.empty() ? default_arrival : arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis_text = protocol_analysis_text(selection, metrics);

  auto model_document =
      mwperf::load_document(write_protocol_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document =
      mwperf::load_document(write_protocol_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " +
                       analysis.error().message));
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  auto compiled =
      mwperf::detail::CompiledArrivalAccess::get(resolved.value().arrival());
  REQUIRE(compiled);
  std::vector<mwperf::MetricRequest> requests;
  requests.reserve(resolved.value().analysis_spec().metrics.size());
  for (const auto& metric : resolved.value().analysis_spec().metrics) {
    auto request =
        mwperf::parse_metric_request(metric, resolved.value().queues());
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    requests.push_back(std::move(request).value());
  }
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  return {std::move(resolved).value(), std::move(compiled).value(),
          std::move(requirements)};
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object_ref(
    const std::string& name) {
  return {label(name), digest_of(name)};
}

[[nodiscard]] mwperf::ProviderIdentityV1 provider(
    std::string id = "c15.fixture.provider",
    std::string version = "1.0.0") {
  return {std::move(id), std::move(version)};
}

[[nodiscard]] mwperf::ProviderConformanceReportRef conformance(
    const mwperf::ProviderIdentityV1& identity = provider()) {
  return {1U,
          label("c15.conformance"),
          digest_of("conformance-report"),
          identity,
          digest_of("scientific-contract"),
          "c15.fixture.evidence",
          1U};
}

[[nodiscard]] mwperf::ProviderConformanceReportRef
finite_prefix_conformance(
    const mwperf::ProviderIdentityV1& identity = provider()) {
  return {1U,
          label("fofs_cp07_1_provider_conformance_report_v1"),
          digest_from_hex(
              "89cc4d4fbdcd516ae61cd97d7769fb2c49c5990d3576c44785c5b4a6d1fb0019"),
          identity,
          digest_from_hex(
              "a0cc1201e8009827b0ce5b0b14a3ba20ee62629569ac5fe97622d3bfb47bc157"),
          "full_orbit_finite_prefix_evidence_v1",
          1U};
}

[[nodiscard]] mwperf::RawResponseProductId raw_id(
    const std::string& name = "raw") {
  return Factory::raw_response_product_id(object_ref(name));
}

[[nodiscard]] mwperf::NominalResponseProductId nominal_id(
    const std::string& name = "nominal") {
  return Factory::nominal_response_product_id(object_ref(name));
}

[[nodiscard]] mwperf::ProjectionCenterProductId center_id(
    const std::string& name = "center") {
  return Factory::projection_center_product_id(object_ref(name));
}

[[nodiscard]] mwperf::ProjectedMeanProductId mean_id(
    const std::string& name = "mean") {
  return Factory::projected_mean_product_id(object_ref(name));
}

[[nodiscard]] mwperf::RecodedResponseProductId recoded_id(
    const std::string& name = "recoded") {
  return Factory::recoded_response_product_id(object_ref(name));
}

[[nodiscard]] mwperf::CoefficientIdentificationV1 identification(
    const mwperf::ThreeBinCoefficientV1 bin,
    mwperf::PortableScientificScalar value) {
  return {object_ref("coefficient-" +
                     std::to_string(static_cast<unsigned int>(bin))),
          {mwperf::ProposalConditioningSourceV1::exact_population,
           scalar(1, 1), std::nullopt},
          {mwperf::PopulationConditioningStatusV1::proved_positive,
           mwperf::RawValueStatusV1::exact_point},
          std::move(value),
          {},
          conformance(),
          std::nullopt,
          bin};
}

[[nodiscard]] mwperf::ResponseCoefficientTripleV1 coefficient_triple(
    const bool use_binary64 = false) {
  const auto one = use_binary64 ? binary_scalar(0.25) : scalar(1, 4);
  const auto two = use_binary64 ? binary_scalar(0.75) : scalar(3, 4);
  const auto tail = use_binary64 ? binary_scalar(0.5) : scalar(1, 2);
  return {{{mwperf::ThreeBinCoefficientV1::one, one,
            object_ref("coefficient-0")},
           {mwperf::ThreeBinCoefficientV1::two, two,
            object_ref("coefficient-1")},
           {mwperf::ThreeBinCoefficientV1::tail_from_three, tail,
            object_ref("coefficient-2")}}};
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 three_bin_payload(
    const bool use_binary64 = false, const bool use_nominal = true) {
  const mwperf::QueueId target = queue_id("q0");
  auto raw = raw_id();
  std::array<mwperf::CoefficientIdentificationV1, 3U> identifications{
      identification(mwperf::ThreeBinCoefficientV1::one,
                     use_binary64 ? binary_scalar(0.25) : scalar(1, 4)),
      identification(mwperf::ThreeBinCoefficientV1::two,
                     use_binary64 ? binary_scalar(0.75) : scalar(3, 4)),
      identification(mwperf::ThreeBinCoefficientV1::tail_from_three,
                     use_binary64 ? binary_scalar(0.5) : scalar(1, 2))};
  mwperf::RawResponseProductV1 raw_product{
      raw, provider(), digest_of("request"), target,
      digest_of("configured-arrival"), digest_of("proposal-law"),
      std::move(identifications)};
  auto raw_digest =
      mwperf::canonical_raw_response_product_digest_v1(raw_product);
  REQUIRE(raw_digest);
  raw_product.product_id = Factory::raw_response_product_id(
      {label("raw"), std::move(raw_digest).value()});
  raw = raw_product.product_id;

  std::optional<mwperf::NominalResponseProductV1> nominal;
  if (use_nominal) {
    nominal = mwperf::NominalResponseProductV1{
        nominal_id(), provider(), digest_of("request"), target,
        coefficient_triple(use_binary64), raw, std::nullopt, std::nullopt};
    auto nominal_digest =
        mwperf::canonical_nominal_response_product_digest_v1(*nominal);
    REQUIRE(nominal_digest);
    nominal->product_id = Factory::nominal_response_product_id(
        {label("nominal"), std::move(nominal_digest).value()});
  }
  mwperf::DeployedResponseProductIdV1 deployed =
      use_nominal ? mwperf::DeployedResponseProductIdV1(nominal->product_id)
                  : mwperf::DeployedResponseProductIdV1(raw);
  mwperf::ThreeBinScalarResponseV1 response{
      1U,
      object_ref("response-row"),
      target,
      digest_of("configured-arrival"),
      std::move(raw_product),
      std::move(nominal),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::move(deployed),
      {}};
  auto row_digest = mwperf::canonical_three_bin_response_row_digest_v1(
      response);
  REQUIRE(row_digest);
  response.response_row_id =
      {label("response-row"), std::move(row_digest).value()};
  return response;
}

[[nodiscard]] mwperf::FinitePrefixResponseCoordinateV1
finite_prefix_coordinate(const std::uint64_t cutoff,
                         const std::uint64_t ordinal) {
  if (ordinal == 0U) {
    return {mwperf::FinitePrefixResponseCoordinateKindV1::
                structural_level_zero,
            mwperf::BigNat{0U}};
  }
  if (ordinal <= cutoff) {
    return {mwperf::FinitePrefixResponseCoordinateKindV1::exact_level,
            mwperf::BigNat{ordinal}};
  }
  REQUIRE(ordinal == cutoff + 1U);
  return {mwperf::FinitePrefixResponseCoordinateKindV1::constant_tail,
          mwperf::BigNat{cutoff + 1U}};
}

[[nodiscard]] double finite_prefix_point(const std::uint64_t cutoff,
                                         const std::uint64_t ordinal) {
  if (ordinal == 0U || ordinal == 2U) return 0.0;
  if (ordinal == cutoff + 1U) return 0.625;
  constexpr std::array<double, 6U> kExact{0.0, 0.1, 0.0,
                                          0.75, 0.5, 1.0};
  REQUIRE(ordinal < kExact.size());
  return kExact[ordinal];
}

void reseal_finite_prefix_response(
    mwperf::FinitePrefixConstantTailResponseV1& response) {
  for (auto& identification : response.raw_response.identifications) {
    auto digest =
        mwperf::canonical_finite_prefix_coefficient_identification_digest_v1(
            identification);
    REQUIRE(digest);
    identification.coefficient_id.object_digest =
        std::move(digest).value();
  }

  auto raw_digest =
      mwperf::canonical_finite_prefix_raw_response_product_digest_v1(
          response.raw_response);
  REQUIRE(raw_digest);
  response.raw_response.product_id = Factory::raw_response_product_id(
      {response.raw_response.product_id.identity().object_id,
       std::move(raw_digest).value()});
  response.deployed_response_product_id = response.raw_response.product_id;

  for (auto& envelope : response.raw_envelopes) {
    envelope.source_product = response.raw_response.product_id;
    envelope.construction_law_digest =
        response.raw_response.proposal_law_digest;
    auto envelope_digest =
        mwperf::canonical_finite_prefix_raw_response_envelope_digest_v1(
            envelope);
    REQUIRE(envelope_digest);
    envelope.envelope_id.object_digest = std::move(envelope_digest).value();
  }

  auto row_digest =
      mwperf::canonical_finite_prefix_constant_tail_response_row_digest_v1(
          response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
}

[[nodiscard]] std::vector<std::byte> finite_prefix_family_body(
    const mwperf::FinitePrefixConstantTailResponseV1& response) {
  using Json = nlohmann::ordered_json;

  const auto& raw = response.raw_response;
  REQUIRE_FALSE(raw.identifications.empty());
  REQUIRE(response.raw_envelopes.size() == 1U);
  const auto& envelope = response.raw_envelopes.front();
  const std::size_t tail_index = raw.identifications.size() - 1U;

  Json mass_levels = Json::array();
  Json response_levels = Json::array();
  for (std::size_t index = 0U; index < tail_index; ++index) {
    const auto& coefficient = raw.identifications[index];
    mass_levels.push_back(Json{
        {"level", wire::encode_big_nat(
                      coefficient.coordinate.level_or_tail_from)},
        {"served", wire::encode_scalar(coefficient.pooled_served_mass)},
        {"unserved", wire::encode_scalar(coefficient.pooled_unserved_mass)},
    });
    response_levels.push_back(Json{
        {"interval",
         Json{{"lower", wire::encode_scalar(envelope.lower[index])},
              {"upper", wire::encode_scalar(envelope.upper[index])}}},
        {"level", wire::encode_big_nat(
                      coefficient.coordinate.level_or_tail_from)},
        {"point", wire::encode_scalar(coefficient.raw_point)},
    });
  }

  const auto& tail = raw.identifications[tail_index];
  const Json body{
      {"concentration_radius",
       Json{{"lower",
             wire::encode_scalar(envelope.concentration_radius_lower)},
            {"upper",
             wire::encode_scalar(envelope.concentration_radius_upper)}}},
      {"ensemble_count", wire::encode_big_nat(raw.ensemble_count)},
      {"floating_point_enclosure",
       wire::encode_scalar(envelope.floating_point_enclosure)},
      {"masses",
       Json{{"levels", std::move(mass_levels)},
            {"response_cutoff", wire::encode_big_nat(response.response_cutoff)},
            {"tail",
             Json{{"served", wire::encode_scalar(tail.pooled_served_mass)},
                  {"tail_from", wire::encode_big_nat(
                                    tail.coordinate.level_or_tail_from)},
                  {"unserved",
                   wire::encode_scalar(tail.pooled_unserved_mass)}}}}},
      {"response",
       Json{{"levels", std::move(response_levels)},
            {"response_cutoff", wire::encode_big_nat(response.response_cutoff)},
            {"tail",
             Json{{"interval",
                   Json{{"lower",
                         wire::encode_scalar(envelope.lower[tail_index])},
                        {"upper",
                         wire::encode_scalar(envelope.upper[tail_index])}}},
                  {"point", wire::encode_scalar(tail.raw_point)},
                  {"tail_from", wire::encode_big_nat(
                                    tail.coordinate.level_or_tail_from)}}}}},
      {"response_cutoff", wire::encode_big_nat(response.response_cutoff)},
      {"schema_id", "full_orbit_finite_prefix_evidence_v1"},
      {"schema_version", 1U},
      {"window_length", wire::encode_big_nat(raw.window_length)},
  };
  return bytes_of(body.dump());
}

[[nodiscard]] mwperf::FinitePrefixConstantTailResponseV1
finite_prefix_payload(const std::uint64_t cutoff) {
  REQUIRE(cutoff >= 2U);
  REQUIRE(cutoff <= 5U);
  const auto target = queue_id("q0");
  const auto identity = provider();
  const auto report = finite_prefix_conformance(identity);
  const auto family_evidence_id =
      object_ref("finite-prefix-family-evidence");
  std::vector<mwperf::FinitePrefixCoefficientIdentificationV1>
      identifications;
  std::vector<mwperf::FinitePrefixResponseCoordinateV1> coordinates;
  std::vector<mwperf::PortableScientificScalar> lower;
  std::vector<mwperf::PortableScientificScalar> upper;
  identifications.reserve(cutoff + 2U);
  coordinates.reserve(cutoff + 2U);
  lower.reserve(cutoff + 2U);
  upper.reserve(cutoff + 2U);
  for (std::uint64_t ordinal = 0U; ordinal <= cutoff + 1U; ++ordinal) {
    const auto coordinate = finite_prefix_coordinate(cutoff, ordinal);
    const double point = finite_prefix_point(cutoff, ordinal);
    const double served = point * 0.5;
    const double unserved = (1.0 - point) * 0.5;
    identifications.push_back({
        object_ref("finite-prefix-coefficient-" +
                   std::to_string(ordinal)),
        coordinate,
        binary_scalar(unserved),
        binary_scalar(served),
        binary_scalar(point),
        {family_evidence_id},
        report,
    });
    coordinates.push_back(coordinate);
    lower.push_back(binary_scalar(point));
    upper.push_back(binary_scalar(point));
  }

  mwperf::FinitePrefixRawResponseProductV1 raw{
      raw_id("finite-prefix-raw"),
      identity,
      digest_of("request"),
      target,
      digest_of("configured-arrival"),
      digest_of("finite-prefix-proposal-law"),
      mwperf::BigNat{cutoff},
      mwperf::BigNat{8U},
      mwperf::BigNat{16U},
      std::move(identifications),
  };
  mwperf::FinitePrefixRawResponseEnvelopeV1 envelope{
      object_ref("finite-prefix-envelope"),
      raw.product_id,
      raw.proposal_law_digest,
      mwperf::BigNat{cutoff},
      std::move(coordinates),
      std::move(lower),
      std::move(upper),
      binary_scalar(0.125),
      binary_scalar(0.25),
      binary_scalar(0.0),
      "fofs.cp07_1.simultaneous_response_interval",
      mwperf::RawEnvelopeCoverageV1::simultaneous,
      mwperf::PopulationConditioningPremiseV1::
          conditional_on_population_positivity,
      label("finite-prefix-evaluation"),
      mwperf::BigNat{8U},
      mwperf::RawEnvelopeScopeV1::proposal_raw,
      {family_evidence_id},
  };
  mwperf::FinitePrefixConstantTailResponseV1 response{
      1U,
      object_ref("finite-prefix-response-row"),
      target,
      digest_of("configured-arrival"),
      mwperf::BigNat{cutoff},
      std::move(raw),
      raw_id("finite-prefix-raw"),
      {std::move(envelope)},
  };
  auto proposal_law_digest = mwperf::sha256_domain_separated(
      "mwperf.fofs.cp07_1.proposal_law.v1",
      finite_prefix_family_body(response));
  REQUIRE(proposal_law_digest);
  response.raw_response.proposal_law_digest = proposal_law_digest.value();
  response.raw_envelopes.front().construction_law_digest =
      proposal_law_digest.value();
  reseal_finite_prefix_response(response);
  return response;
}

void seal_finite_prefix_family_graph(
    mwperf::FinitePrefixConstantTailResponseV1& response,
    mwperf::FamilyEvidenceEnvelopeV1& family) {
  REQUIRE(response.raw_envelopes.size() == 1U);
  auto body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(
          family.canonical_family_body);
  REQUIRE(body_digest);
  family.canonical_family_body_digest = body_digest.value();

  auto proposal_law_digest = mwperf::sha256_domain_separated(
      "mwperf.fofs.cp07_1.proposal_law.v1",
      family.canonical_family_body);
  REQUIRE(proposal_law_digest);
  response.raw_response.proposal_law_digest = proposal_law_digest.value();
  response.raw_envelopes.front().construction_law_digest =
      proposal_law_digest.value();
  reseal_finite_prefix_response(response);

  const mwperf::ArtifactPayloadV1 payload = response;
  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(payload_digest);
  family.payload_digest = payload_digest.value();

  family.subject_references.clear();
  family.subject_references.reserve(
      response.raw_response.identifications.size() + 2U);
  for (const auto& identification :
       response.raw_response.identifications) {
    family.subject_references.push_back(identification.coefficient_id);
  }
  family.subject_references.push_back(
      response.raw_envelopes.front().envelope_id);
  family.subject_references.push_back(
      response.raw_response.product_id.identity());
  std::sort(family.subject_references.begin(),
            family.subject_references.end());
  family.subject_references.erase(
      std::unique(family.subject_references.begin(),
                  family.subject_references.end()),
      family.subject_references.end());
  family.parent_references = {
      response.raw_response.product_id.identity()};

  auto family_digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(family);
  REQUIRE(family_digest);
  family.evidence_id.object_digest = std::move(family_digest).value();

  const auto replace_backlink = [&](mwperf::ArtifactObjectReferenceV1& ref) {
    if (ref.object_id == family.evidence_id.object_id) {
      ref = family.evidence_id;
    }
  };
  for (auto& identification : response.raw_response.identifications) {
    for (auto& reference : identification.family_evidence_envelope_ids) {
      replace_backlink(reference);
    }
  }
  for (auto& raw_envelope : response.raw_envelopes) {
    for (auto& reference : raw_envelope.family_evidence_envelope_ids) {
      replace_backlink(reference);
    }
  }
  reseal_finite_prefix_response(response);
  const mwperf::ArtifactPayloadV1 finalized_payload = response;
  auto finalized_payload_digest =
      mwperf::canonical_artifact_payload_digest_v1(finalized_payload);
  REQUIRE(finalized_payload_digest);
  CHECK(finalized_payload_digest.value() == family.payload_digest);
}

[[nodiscard]] mwperf::FamilyEvidenceEnvelopeV1
finite_prefix_family_evidence(
    mwperf::FinitePrefixConstantTailResponseV1& response) {
  const auto& raw = response.raw_response;
  REQUIRE(response.raw_envelopes.size() == 1U);
  auto canonical_body = finite_prefix_family_body(response);
  auto body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(
          canonical_body);
  REQUIRE(body_digest);
  const auto evidence_id =
      raw.identifications.front().family_evidence_envelope_ids.front();
  const auto& report =
      raw.identifications.front().provider_conformance_report_ref;

  mwperf::FamilyEvidenceEnvelopeV1 family{
      1U,
      evidence_id,
      "full_orbit_finite_prefix_evidence_v1",
      1U,
      report,
      raw.provider,
      report.provider_scientific_contract_digest,
      raw.request_digest,
      digest_of("finite-prefix-payload-pending-seal"),
      {},
      {},
      {response.deployed_target},
      mwperf::MetricEvidenceScopeV1::raw_static_proposal,
      std::move(canonical_body),
      std::move(body_digest).value(),
  };
  seal_finite_prefix_family_graph(response, family);
  return family;
}

[[nodiscard]] mwperf::PortableScientificScalar fixture_scalar(
    const bool binary, const double binary_value, const std::int64_t numerator,
    const std::int64_t denominator) {
  return binary ? binary_scalar(binary_value) : scalar(numerator, denominator);
}

[[nodiscard]] std::vector<mwperf::FiniteLawTableAlternativeV1>
finite_table_fixtures(const bool binary = false) {
  const auto law = object_ref("law");
  const auto s0 = label("s0");
  const auto m0 = label("m0");
  const auto probability = fixture_scalar(binary, 1.0, 1, 1);
  const mwperf::FiniteLawRowV1 row{
      label("row"), s0,
      mwperf::FiniteRowConditioningStageV1::stationary_edge,
      {{s0, {m0}, probability, std::nullopt}}};
  const mwperf::ExplicitOrderedWordV1 word{
      s0, mwperf::BigNat{1U}, {m0}, label("terminal"), s0, probability};
  const mwperf::FinitePredictiveStoppingTablesV1 predictive{{row}, {row},
                                                            {row}};
  std::vector<mwperf::FiniteLawTableAlternativeV1> tables;
  tables.emplace_back(mwperf::StationaryMarkedEdgeTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      {"q", 1U}, {"phase", 1U}, {"departure", 1U}, {"mark", 1U},
      digest_of("conditioning")});
  tables.emplace_back(mwperf::StagedOpportunityFluxTableV1{
      1U, law, mwperf::FiniteTableStorageV1::sparse, {s0}, {s0}, {row}, {row},
      digest_of("arrival"), {"arrival.innovation", 1U},
      object_ref("update"), object_ref("retained"),
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge}});
  tables.emplace_back(mwperf::TemporalContinuationTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge},
      {"arrival.phase", 1U}, std::nullopt});
  tables.emplace_back(mwperf::StoppedPathTableV1{
      1U, law, "hit.q0", {s0}, {s0}, {m0}, true, predictive,
      fixture_scalar(binary, 0.25, 1, 4),
      {object_ref("defective-law-evidence")}});
  tables.emplace_back(mwperf::RomrResidenceWordTableV1{
      1U, law, "event.q0", {s0}, {s0}, {m0},
      std::vector<mwperf::ExplicitOrderedWordV1>{word},
      fixture_scalar(binary, 0.0, 0, 1),
      {object_ref("termination-evidence")}});
  tables.emplace_back(mwperf::CoupledCommonScheduleTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      digest_of("constraint"), digest_of("tie-phase-arrival")});
  return tables;
}

[[nodiscard]] std::vector<mwperf::ArtifactPayloadV1> payload_fixtures(
    const bool binary = false) {
  const auto q0 = queue_id("q0");
  const auto q1 = queue_id("q1");
  std::vector<mwperf::ArtifactPayloadV1> payloads;
  payloads.emplace_back(three_bin_payload(binary));
  payloads.emplace_back(mwperf::FiniteParameterAnalyticDataV1{
      1U, "fixture.family", 1U, "fixture.parameters", 1U,
      "fixture.domain", 1U, provider(), {q0},
      {{"theta", fixture_scalar(binary, 0.5, 1, 2)}},
      {{"row", std::vector<mwperf::PortableScientificScalar>{
                    fixture_scalar(binary, 0.25, 1, 4),
                    fixture_scalar(binary, 0.75, 3, 4)}}},
      {{"backlog", fixture_scalar(binary, 0.0, 0, 1),
        fixture_scalar(binary, 4.0, 4, 1), true, true}},
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {object_ref("analytic-response")}});

  auto tables = finite_table_fixtures(binary);
  payloads.emplace_back(mwperf::FiniteLawTablesV1{
      1U,
      {q0},
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      digest_of("arrival"),
      digest_of("selection"),
      {{label("s0"), {fixture_scalar(binary, 0.25, 1, 4)}}},
      {{label("m0"), {fixture_scalar(binary, 0.5, 1, 2)}}},
      std::move(tables.front())});
  payloads.emplace_back(mwperf::RegisteredRuntimeRecipeV1{
      1U, "fixture.recipe", 1U, "fixture.parameters", 1U,
      "fixture.state-codec", 1U, "fixture.mark-codec", 1U, provider(), {q0},
      {{"p", fixture_scalar(binary, 0.5, 1, 2)},
       {"vector", std::vector<mwperf::PortableScientificScalar>{
                      fixture_scalar(binary, 0.25, 1, 4),
                      fixture_scalar(binary, 0.75, 3, 4)}}},
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}}});
  auto lower = three_bin_payload(binary);
  auto upper = three_bin_payload(binary);
  auto lower_product = lower.deployed_response_product_id;
  auto upper_product = upper.deployed_response_product_id;
  payloads.emplace_back(mwperf::ResponseEnvelopeEvidenceV1{
      1U, {q0}, mwperf::MetricResultScopeV1::response_envelope,
      mwperf::MetricEvidenceScopeV1::validity_or_lift,
      std::move(lower), std::move(upper), std::move(lower_product),
      std::move(upper_product), object_ref("comparison-domain"),
      {object_ref("order-proof")}, false, std::nullopt});
  payloads.emplace_back(mwperf::DirectMetricPayloadV1{
      1U,
      {{object_ref("direct-value"), clause_id("throughput"), {q0, q1},
        std::vector<mwperf::PortableScientificScalar>{
            fixture_scalar(binary, 0.25, 1, 4),
            fixture_scalar(binary, 0.75, 3, 4)},
        digest_of("request"), digest_of("normalized-request"),
        digest_of("targets"), digest_of("arrival"), digest_of("contract"),
        {mwperf::SelectionKindV1::stationary_unique}, {},
        mwperf::MetricResultScopeV1::surrogate_law,
        mwperf::DirectMetricValidityBasisV1::exact_closed_form,
        {object_ref("validity-proof")}}}});
  payloads.emplace_back(finite_prefix_payload(2U));
  return payloads;
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1 role(
    const mwperf::MetricSupportRoleV1 value,
    const mwperf::MetricTargetScopeV1 target_scope,
    const mwperf::MetricResultScopeV1 result_scope,
    const mwperf::MetricEvidenceScopeV1 evidence_scope) {
  return {value, target_scope, result_scope, evidence_scope, {}, {}};
}

[[nodiscard]] mwperf::MetricSupportManifest scalar_manifest() {
  auto deployed_payload = role(
      mwperf::MetricSupportRoleV1::deployed_payload,
      mwperf::MetricTargetScopeV1::payload_targets,
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::MetricEvidenceScopeV1::none);
  auto deployed_response = role(
      mwperf::MetricSupportRoleV1::deployed_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
  deployed_response.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::MetricSupportRoleV1::deployed_payload});
  deployed_response.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::MetricSupportRoleV1::raw_response});

  auto raw_response = role(
      mwperf::MetricSupportRoleV1::raw_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::proposal_raw,
      mwperf::MetricEvidenceScopeV1::raw_static_proposal);
  raw_response.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::MetricSupportRoleV1::deployed_payload});
  raw_response.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::InternalReferencePurposeV1::coefficient_origin});

  auto validity = role(
      mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::validity_or_lift);
  const std::array validity_bindings{
      mwperf::InternalReferencePurposeV1::coordinate_codec,
      mwperf::InternalReferencePurposeV1::mark_codec,
      mwperf::InternalReferencePurposeV1::configured_arrival_binding,
      mwperf::InternalReferencePurposeV1::selection_binding,
      mwperf::InternalReferencePurposeV1::timing_binding,
      mwperf::InternalReferencePurposeV1::validity_basis};
  for (const auto purpose : validity_bindings) {
    validity.internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::binding, purpose});
  }
  validity.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::evidence,
       mwperf::InternalReferencePurposeV1::validity_witness});
  validity.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::artifact_payload});
  validity.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::law_or_result});

  mwperf::MetricSupportClauseV1 clause{
      clause_id("throughput"),
      mwperf::MetricKindV1::stationary_throughput,
      mwperf::ExactMetricParameterSetV1{
          {mwperf::StationaryThroughputParametersV1{}}},
      {queue_id("q0")},
      mwperf::TargetCouplingV1::scalar_target,
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
       std::nullopt,
       mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      {},
      {},
      mwperf::SolverRegimeV1::analytic,
      mwperf::AnalyticAccuracyV1{mwperf::BigNat{128U}, {}},
      {mwperf::StructuralErrorFormV1::exact,
       mwperf::MetricEvidenceScopeV1::none, mwperf::ExactRational::zero()},
      mwperf::MetricResultScopeV1::surrogate_law,
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.fixture.v0", 1U},
      {std::move(deployed_payload),
       std::move(deployed_response),
       std::move(raw_response), std::move(validity)}};
  auto result = mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::MetricSupportManifest interval_scalar_manifest() {
  auto clause = scalar_manifest().clauses().front();
  const auto deployed_iterator = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               mwperf::MetricSupportRoleV1::deployed_response;
      });
  REQUIRE(deployed_iterator != clause.required_roles.end());
  auto& deployed = *deployed_iterator;
  REQUIRE(deployed.role_relations.size() == 2U);
  auto deployed_subject = std::find_if(
      deployed.role_relations.begin(), deployed.role_relations.end(),
      [](const auto& relation) {
        return relation.relation ==
               mwperf::MetricRoleRelationKindV1::subject;
      });
  REQUIRE(deployed_subject != deployed.role_relations.end());
  deployed_subject->other_role =
      mwperf::MetricSupportRoleV1::nominal_response;

  const auto raw_iterator = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const auto& requirement) {
        return requirement.role == mwperf::MetricSupportRoleV1::raw_response;
      });
  REQUIRE(raw_iterator != clause.required_roles.end());
  auto& raw = *raw_iterator;
  raw.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::evidence,
       mwperf::MetricSupportRoleV1::raw_response_bound_evidence});

  auto nominal = role(
      mwperf::MetricSupportRoleV1::nominal_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::nominal_static_proposal);
  nominal.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::MetricSupportRoleV1::raw_response});
  nominal.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::completion_policy});

  auto bounds = role(
      mwperf::MetricSupportRoleV1::raw_response_bound_evidence,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::raw_static_proposal);
  bounds.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::MetricSupportRoleV1::raw_response});
  bounds.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::evaluation_identity},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::proposal_identity},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::coefficient_origin}};

  clause.required_roles.push_back(std::move(nominal));
  clause.required_roles.push_back(std::move(bounds));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::MetricSupportManifest all_stage_scalar_manifest() {
  auto clause = scalar_manifest().clauses().front();
  const auto deployed_iterator = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               mwperf::MetricSupportRoleV1::deployed_response;
      });
  REQUIRE(deployed_iterator != clause.required_roles.end());
  auto deployed_subject = std::find_if(
      deployed_iterator->role_relations.begin(),
      deployed_iterator->role_relations.end(), [](const auto& relation) {
        return relation.relation ==
               mwperf::MetricRoleRelationKindV1::subject;
      });
  REQUIRE(deployed_subject != deployed_iterator->role_relations.end());
  deployed_subject->other_role =
      mwperf::MetricSupportRoleV1::recoded_response;

  auto nominal = role(
      mwperf::MetricSupportRoleV1::nominal_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::nominal_static_proposal);
  nominal.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::MetricSupportRoleV1::raw_response});
  nominal.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::completion_policy});

  auto center = role(
      mwperf::MetricSupportRoleV1::projection_center,
      mwperf::MetricTargetScopeV1::ordered_construction_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::projection_center);
  center.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::InternalReferencePurposeV1::projection_source});

  auto mean = role(
      mwperf::MetricSupportRoleV1::projected_mean,
      mwperf::MetricTargetScopeV1::ordered_construction_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::projected_surrogate_mean);
  mean.role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::MetricSupportRoleV1::projection_center});
  mean.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::projection_policy});

  auto recoded = role(
      mwperf::MetricSupportRoleV1::recoded_response,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::recoded_static_proposal);
  recoded.role_relations = {
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::MetricSupportRoleV1::nominal_response},
      {mwperf::MetricRoleRelationKindV1::lineage_parent,
       mwperf::MetricSupportRoleV1::projected_mean}};
  recoded.internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::recoding_policy});

  clause.required_roles.push_back(std::move(nominal));
  clause.required_roles.push_back(std::move(center));
  clause.required_roles.push_back(std::move(mean));
  clause.required_roles.push_back(std::move(recoded));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

enum class CompressionLineageFixtureV1 : std::uint8_t {
  raw_parent,
  nominal_parent,
  completion_source,
};

[[nodiscard]] mwperf::MetricSupportManifest compression_scalar_manifest(
  const CompressionLineageFixtureV1 lineage) {
  auto clause = all_stage_scalar_manifest().clauses().front();
  if (lineage == CompressionLineageFixtureV1::completion_source) {
    clause.required_roles.erase(
        std::remove_if(
            clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& requirement) {
              return requirement.role ==
                         mwperf::MetricSupportRoleV1::projection_center ||
                     requirement.role ==
                         mwperf::MetricSupportRoleV1::projected_mean;
            }),
        clause.required_roles.end());
    const auto nominal = std::find_if(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const auto& requirement) {
          return requirement.role ==
                 mwperf::MetricSupportRoleV1::nominal_response;
        });
    REQUIRE(nominal != clause.required_roles.end());
    nominal->role_relations.erase(
        std::remove_if(
            nominal->role_relations.begin(), nominal->role_relations.end(),
            [](const auto& relation) {
              return relation.relation ==
                     mwperf::MetricRoleRelationKindV1::lineage_parent;
            }),
        nominal->role_relations.end());
    nominal->internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::lineage_parent,
         mwperf::InternalReferencePurposeV1::completion_source});
  }
  const auto deployed = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               mwperf::MetricSupportRoleV1::deployed_response;
      });
  REQUIRE(deployed != clause.required_roles.end());
  const auto deployed_subject = std::find_if(
      deployed->role_relations.begin(), deployed->role_relations.end(),
      [](const auto& relation) {
        return relation.relation ==
               mwperf::MetricRoleRelationKindV1::subject;
      });
  REQUIRE(deployed_subject != deployed->role_relations.end());
  deployed_subject->other_role =
      mwperf::MetricSupportRoleV1::recoded_response;

  auto recoded = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               mwperf::MetricSupportRoleV1::recoded_response;
      });
  if (recoded == clause.required_roles.end()) {
    auto added = role(
        mwperf::MetricSupportRoleV1::recoded_response,
        mwperf::MetricTargetScopeV1::deployed_singleton_target,
        mwperf::MetricResultScopeV1::not_a_metric_result,
        mwperf::MetricEvidenceScopeV1::recoded_static_proposal);
    added.internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::recoding_policy});
    clause.required_roles.push_back(std::move(added));
    recoded = std::prev(clause.required_roles.end());
  }
  if (lineage == CompressionLineageFixtureV1::raw_parent) {
    recoded->role_relations.erase(
        std::remove_if(recoded->role_relations.begin(),
                       recoded->role_relations.end(), [](const auto& relation) {
                         return relation.relation ==
                                mwperf::MetricRoleRelationKindV1::
                                    lineage_parent;
                       }),
        recoded->role_relations.end());
    recoded->role_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::lineage_parent,
         mwperf::MetricSupportRoleV1::raw_response});
  } else if (lineage == CompressionLineageFixtureV1::completion_source) {
    recoded->role_relations.clear();
    recoded->internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::lineage_parent,
         mwperf::InternalReferencePurposeV1::completion_source});
  }
  recoded->role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::evidence,
       mwperf::MetricSupportRoleV1::compression_evidence});

  auto compression = role(
      mwperf::MetricSupportRoleV1::compression_evidence,
      mwperf::MetricTargetScopeV1::deployed_singleton_target,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::recoded_static_proposal);
  compression.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::compression_rule},
      {mwperf::MetricRoleRelationKindV1::evidence,
       mwperf::InternalReferencePurposeV1::error_object},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::compression_source},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::compression_destination}};
  clause.required_roles.push_back(std::move(compression));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::MetricSupportManifest
authoritative_evidence_scalar_manifest() {
  auto clause = scalar_manifest().clauses().front();

  auto optimizer = role(
      mwperf::MetricSupportRoleV1::optimizer_evidence,
      mwperf::MetricTargetScopeV1::ordered_construction_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::optimizer_interval_raw);
  optimizer.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::solver_identity},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::constraint_identity},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::call_report_identity},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::evaluation_identity},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::certified_product_or_envelope}};

  auto statistical = role(
      mwperf::MetricSupportRoleV1::statistical_evidence,
      mwperf::MetricTargetScopeV1::ordered_construction_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::raw_static_proposal);
  statistical.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::sampling_bank},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::sampling_probe},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::evaluation_identity},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::coverage_family},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::estimand}};

  auto calibration = role(
      mwperf::MetricSupportRoleV1::calibration_evidence,
      mwperf::MetricTargetScopeV1::ordered_construction_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::raw_static_proposal);
  calibration.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::sampling_bank},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::calibration_rule},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::calibration_source}};

  clause.required_roles.push_back(std::move(optimizer));
  clause.required_roles.push_back(std::move(statistical));
  clause.required_roles.push_back(std::move(calibration));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::MetricSupportManifest
numerical_stability_scalar_manifest() {
  auto clause = scalar_manifest().clauses().front();
  clause.hypotheses.push_back(
      {mwperf::HypothesisKindV1::stable, std::nullopt, std::nullopt,
       std::nullopt});

  auto numerical = role(
      mwperf::MetricSupportRoleV1::numerical_evidence,
      mwperf::MetricTargetScopeV1::ordered_metric_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::numerical_result);
  numerical.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::algorithm_tolerance_policy},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::residual_or_enclosure},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::representation_domain},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::law_or_result}};

  auto stability = role(
      mwperf::MetricSupportRoleV1::stability_certificate,
      mwperf::MetricTargetScopeV1::ordered_metric_targets,
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
  stability.internal_relations = {
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::configured_arrival_binding},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::state_domain},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::class_domain},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::selection_binding},
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::stability_statement},
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::InternalReferencePurposeV1::deployed_law}};

  clause.required_roles.push_back(std::move(numerical));
  clause.required_roles.push_back(std::move(stability));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::PlugDescriptorCore scalar_descriptor(
    const mwperf::MetricSupportManifest& manifest,
    mwperf::RuntimeAccessTagV1 access =
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
    mwperf::ProviderIdentityV1 identity = provider()) {
  mwperf::PlugDescriptorCore descriptor{
      1U,
      std::move(identity),
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      mwperf::SemanticTagV1::scalar_backlog_response,
      access,
      {queue_id("q0")},
      mwperf::TargetCouplingV1::scalar_target,
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
       std::nullopt,
       mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {mwperf::TailRepresentationKindV1::constant_response, mwperf::BigNat{3U},
       std::nullopt},
      {},
      {},
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.fixture.v0", 1U},
      {},
      {mwperf::AnalyticAccuracyV1{mwperf::BigNat{128U}, {}}},
      {mwperf::ConstructionResultScopeV1::surrogate_law,
       mwperf::ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest.canonical_digest(),
      digest_of("descriptor")};
  auto core_digest = mwperf::canonical_plug_descriptor_core_digest_v1(
      descriptor);
  REQUIRE(core_digest);
  descriptor.core_digest = std::move(core_digest).value();
  return descriptor;
}

void reseal_descriptor(mwperf::PlugDescriptorCore& descriptor) {
  auto digest = mwperf::canonical_plug_descriptor_core_digest_v1(descriptor);
  REQUIRE(digest);
  descriptor.core_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::MetricSupportManifestEchoV1 manifest_echo(
    const mwperf::MetricSupportManifest& manifest) {
  auto bytes = mwperf::canonical_metric_support_manifest_bytes_v1(manifest);
  REQUIRE(bytes);
  return {1U, std::move(bytes).value(), manifest.canonical_digest()};
}

[[nodiscard]] mwperf::SurrogateProviderManifestV1 provider_manifest(
    const mwperf::ConstructionMethodV1 method =
        mwperf::ConstructionMethodV1::engineered_deterministic,
    const mwperf::ProducerModeV1 mode =
        mwperf::ProducerModeV1::in_process_builder,
    std::string provider_id = "c15.fixture.provider",
    std::optional<mwperf::MetricSupportManifest> selected_manifest =
        std::nullopt,
    const mwperf::PointDeploymentPolicyV1 point_deployment =
        mwperf::PointDeploymentPolicyV1::deploy_raw_point,
    const mwperf::CoefficientCompletionPolicyV1 coefficient_completion =
        mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
    const mwperf::ProjectionPolicyV1 projection =
        mwperf::ProjectionPolicyV1::not_applicable,
    const mwperf::RecodingPolicyV1 recoding =
        mwperf::RecodingPolicyV1::not_applicable) {
  const auto manifest = selected_manifest.has_value()
                            ? std::move(*selected_manifest)
                            : scalar_manifest();
  std::vector<mwperf::MetricSupportRoleV1> allowed_roles;
  for (const auto& clause : manifest.clauses()) {
    for (const auto& requirement : clause.required_roles) {
      if (std::find(allowed_roles.begin(), allowed_roles.end(),
                    requirement.role) == allowed_roles.end()) {
        allowed_roles.push_back(requirement.role);
      }
    }
  }
  std::sort(allowed_roles.begin(), allowed_roles.end(),
            [](const auto left, const auto right) {
              return mwperf::metric_support_role_rank_v1(left) <
                     mwperf::metric_support_role_rank_v1(right);
            });
  std::optional<mwperf::LocalExecutableDeclarationV1> executable;
  if (mode == mwperf::ProducerModeV1::local_executable_builder) {
    executable = mwperf::LocalExecutableDeclarationV1{
        "c15.fixture.builder", 1U,
        {"--request", "{request_path}", "--result", "{result_path}"}, true};
  }
  mwperf::SurrogateProviderManifestV1 result{
      1U,
      provider(std::move(provider_id)),
      false,
      digest_of("source-build"),
      method,
      mode,
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      1U,
      digest_of("parameter-schema"),
      {1U},
      {1U},
      {1U},
      {},
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      {1U, 1U, {mwperf::TargetCouplingV1::scalar_target}, {}},
      manifest,
      std::move(allowed_roles),
      {{"c15.fixture.evidence", 1U, 4096U}},
      {{"c15.fixture.evidence", 1U, 1U, label("c15.conformance"),
        digest_of("conformance-report")}},
      {1U,
       {point_deployment},
       {coefficient_completion},
       {projection},
       {recoding},
       {mwperf::EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      std::move(executable),
      {1U << 20U, 1U << 20U},
      digest_of("manifest-placeholder")};
  auto digest = mwperf::digest_provider_manifest_v1(result);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  result.manifest_digest = std::move(digest).value();
  return result;
}

void reseal_manifest(mwperf::SurrogateProviderManifestV1& manifest) {
  auto digest = mwperf::digest_provider_manifest_v1(manifest);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  manifest.manifest_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::CommonBuildReportV1 build_report() {
  return {1U,
          label("c15.report"),
          digest_of("report"),
          digest_of("request"),
          digest_of("budget"),
          {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {},
          {}};
}

[[nodiscard]] mwperf::SurrogateArtifactV1 artifact_for_payload(
    mwperf::ArtifactPayloadV1 payload) {
  const mwperf::MetricSupportManifest manifest = scalar_manifest();
  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(payload_digest);
  const mwperf::Digest256 bound_payload_digest = payload_digest.value();
  return {1U,
          digest_of("request"),
          provider(),
          digest_of("scientific-contract"),
          mwperf::ConstructionMethodV1::engineered_deterministic,
          mwperf::ProducerModeV1::in_process_builder,
          mwperf::SemanticTagV1::scalar_backlog_response,
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
          mwperf::artifact_payload_class_v1(payload),
          object_ref("payload"),
          std::move(payload),
          bound_payload_digest,
          manifest_echo(manifest),
          {digest_of("request"), bound_payload_digest, {}},
          scalar_descriptor(manifest),
          build_report(),
          {},
          {},
          {},
          {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
           std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
           std::nullopt}};
}

[[nodiscard]] mwperf::ConstructionBudget construction_budget(
    const std::uint64_t generator_draw_grant = 0U) {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{generator_draw_grant}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct BoundRequestFixture final {
  mwperf::ValidatedProviderManifest manifest;
  mwperf::FrameworkProblemView view;
  mwperf::AcceptedCapabilityContract contract;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::ConstructionBudget budget;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] BoundRequestFixture make_bound_request_fixture(
    const ProtocolInputFixture& input,
    const mwperf::ConstructionMethodV1 method,
    const mwperf::ProducerModeV1 mode, const std::string& provider_id,
    const mwperf::MasterSeed master_seed = mwperf::MasterSeed(0xC15U),
    const std::uint64_t generator_draw_grant = 0U,
    std::optional<mwperf::MetricSupportManifest> selected_manifest =
        std::nullopt,
    const mwperf::PointDeploymentPolicyV1 point_deployment =
        mwperf::PointDeploymentPolicyV1::deploy_raw_point,
    const mwperf::CoefficientCompletionPolicyV1 coefficient_completion =
        mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
    const mwperf::ProjectionPolicyV1 projection =
        mwperf::ProjectionPolicyV1::not_applicable,
    const mwperf::RecodingPolicyV1 recoding =
        mwperf::RecodingPolicyV1::not_applicable) {
  auto raw_manifest = provider_manifest(
      method, mode, provider_id, std::move(selected_manifest),
      point_deployment, coefficient_completion, projection, recoding);
  auto validated_manifest = mwperf::validate_provider_manifest(raw_manifest);
  INFO((validated_manifest
            ? std::string{}
            : validated_manifest.error().code + ": " +
                  validated_manifest.error().message));
  REQUIRE(validated_manifest);

  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c15.fixture.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);

  const auto parameter_bytes = bytes_of("{}");
  auto parameter_digest =
      mwperf::digest_surrogate_parameter_values_v1(parameter_bytes);
  REQUIRE(parameter_digest);
  auto parameters = Factory::validated_parameters(
      raw_manifest.provider, raw_manifest.parameter_schema_version,
      raw_manifest.parameter_schema_digest, parameter_bytes);
  auto budget = construction_budget(generator_draw_grant);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const mwperf::PreviewPoliciesV1 policies{
      point_deployment,
      coefficient_completion,
      projection,
      recoding,
      mwperf::EvidenceRolePolicyV1::exact_manifest_roles};
  auto accepted_descriptor = scalar_descriptor(
      raw_manifest.metric_clause_upper_envelope,
      raw_manifest.runtime_access_tag, raw_manifest.provider);
  accepted_descriptor.hypothesis_claims =
      raw_manifest.metric_clause_upper_envelope.clauses().front().hypotheses;
  reseal_descriptor(accepted_descriptor);
  auto contract = Factory::accepted_contract(
      raw_manifest,
      std::move(accepted_descriptor),
      raw_manifest.metric_clause_upper_envelope, input.requirements,
      view.value().configured_arrival().capabilities(), {}, {queue_id("q0")},
      policies, {{}, std::nullopt, std::nullopt, std::nullopt},
      view.value().canonical_digest().value(), parameter_digest.value(),
      budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      validated_manifest.value(), view.value(), contract, parameters, budget,
      master_seed);
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  return {std::move(validated_manifest).value(), std::move(view).value(),
          std::move(contract), std::move(parameters), std::move(budget),
          std::move(request).value()};
}

[[nodiscard]] mwperf::CommonBuildReportV1 sealed_report_for(
    const BoundRequestFixture& fixture,
    const std::uint64_t generator_draws_used = 0U) {
  mwperf::CommonBuildReportV1 report{
      1U,
      label("c15.fixture.report"),
      digest_of("report-placeholder"),
      fixture.request.request_digest().value(),
      fixture.contract.budget_digest(),
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable,
       mwperf::BigNat{generator_draws_used}},
      {},
      {}};
  auto digest = mwperf::canonical_common_build_report_digest_v1(report);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  report.report_digest = std::move(digest).value();
  return report;
}

[[nodiscard]] mwperf::ProviderConformanceReportRef bound_conformance(
    const BoundRequestFixture& fixture) {
  const auto& anchor = fixture.manifest.value()
                           .family_evidence_conformance_report_anchors.front();
  return {anchor.report_schema_version,
          anchor.report_id,
          anchor.report_digest,
          fixture.manifest.value().provider,
          fixture.manifest.scientific_contract_digest().value(),
          anchor.family_evidence_schema_id,
          anchor.family_evidence_schema_version};
}

[[nodiscard]] mwperf::CoefficientIdentificationV1 bound_identification(
    const BoundRequestFixture& fixture,
    const mwperf::ThreeBinCoefficientV1 bin,
    mwperf::PortableScientificScalar point) {
  mwperf::CoefficientIdentificationV1 result{
      object_ref("bound-coefficient-" +
                 std::to_string(static_cast<unsigned int>(bin))),
      {mwperf::ProposalConditioningSourceV1::exact_population, scalar(1, 1),
       std::nullopt},
      {mwperf::PopulationConditioningStatusV1::proved_positive,
       mwperf::RawValueStatusV1::exact_point},
      std::move(point),
      {},
      bound_conformance(fixture),
      std::nullopt,
      bin};
  auto digest =
      mwperf::artifact::detail::coefficient_identification_digest_v1(result);
  REQUIRE(digest);
  result.coefficient_id.object_digest = std::move(digest).value();
  return result;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 bound_three_bin_payload(
    const BoundRequestFixture& fixture) {
  const auto target = fixture.view.target_selection().ordered_targets.front();
  std::array<mwperf::CoefficientIdentificationV1, 3U> identifications{
      bound_identification(fixture, mwperf::ThreeBinCoefficientV1::one,
                           scalar(1, 4)),
      bound_identification(fixture, mwperf::ThreeBinCoefficientV1::two,
                           scalar(3, 4)),
      bound_identification(
          fixture, mwperf::ThreeBinCoefficientV1::tail_from_three,
          scalar(1, 2))};
  mwperf::RawResponseProductV1 raw{
      raw_id("bound-raw"),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      target,
      fixture.view.fingerprints().compiled_arrival,
      digest_of("bound-proposal-law"),
      std::move(identifications)};
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(raw);
  REQUIRE(raw_digest);
  raw.product_id = Factory::raw_response_product_id(
      {label("bound-raw"), std::move(raw_digest).value()});

  mwperf::ThreeBinScalarResponseV1 result{
      1U,
      object_ref("bound-response-row"),
      target,
      fixture.view.fingerprints().compiled_arrival,
      std::move(raw),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      raw_id("unreachable-placeholder"),
      {}};
  result.deployed_response_product_id = result.raw_response.product_id;
  auto row_digest = mwperf::canonical_three_bin_response_row_digest_v1(result);
  REQUIRE(row_digest);
  result.response_row_id.object_digest = std::move(row_digest).value();
  return result;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1
bound_all_stage_three_bin_payload(const BoundRequestFixture& fixture) {
  auto response = bound_three_bin_payload(fixture);
  const auto target = response.deployed_target;
  const auto construction_targets = std::vector<mwperf::QueueId>(
      fixture.contract.construction_target_scope().begin(),
      fixture.contract.construction_target_scope().end());
  REQUIRE(construction_targets == std::vector<mwperf::QueueId>{target});

  response.nominal_response = mwperf::NominalResponseProductV1{
      nominal_id("bound-nominal"),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      target,
      {{{mwperf::ThreeBinCoefficientV1::one, scalar(1, 4),
         response.raw_response.identifications[0U].coefficient_id},
        {mwperf::ThreeBinCoefficientV1::two, scalar(3, 4),
         response.raw_response.identifications[1U].coefficient_id},
        {mwperf::ThreeBinCoefficientV1::tail_from_three, scalar(1, 2),
         response.raw_response.identifications[2U].coefficient_id}}},
      response.raw_response.product_id,
      object_ref("bound-completion-policy"),
      std::nullopt};
  auto nominal_digest = mwperf::canonical_nominal_response_product_digest_v1(
      *response.nominal_response);
  REQUIRE(nominal_digest);
  response.nominal_response->product_id = Factory::nominal_response_product_id(
      {label("bound-nominal"), std::move(nominal_digest).value()});

  response.projection_center = mwperf::ProjectionCenterProductV1{
      center_id("bound-center"),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      construction_targets,
      target,
      mwperf::ProjectionCenterSourceKindV1::decoded_raw_response,
      {scalar(1, 2)},
      response.raw_response.product_id,
      std::nullopt};
  auto center_digest = mwperf::canonical_projection_center_product_digest_v1(
      *response.projection_center);
  REQUIRE(center_digest);
  response.projection_center->product_id =
      Factory::projection_center_product_id(
          {label("bound-center"), std::move(center_digest).value()});

  response.projected_mean = mwperf::ProjectedMeanProductV1{
      mean_id("bound-mean"),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      construction_targets,
      target,
      {scalar(1, 2)},
      response.projection_center->product_id,
      object_ref("bound-projection-policy"),
      std::nullopt};
  auto mean_digest = mwperf::canonical_projected_mean_product_digest_v1(
      *response.projected_mean);
  REQUIRE(mean_digest);
  response.projected_mean->product_id = Factory::projected_mean_product_id(
      {label("bound-mean"), std::move(mean_digest).value()});

  response.recoded_response = mwperf::RecodedResponseProductV1{
      recoded_id("bound-recoded"),
      fixture.manifest.value().provider,
      fixture.request.request_digest().value(),
      target,
      response.nominal_response->coefficients,
      mwperf::ProductDerivationKindV1::mean_inversion_recoding,
      response.projected_mean->product_id,
      response.nominal_response->product_id,
      std::nullopt,
      object_ref("bound-recoding-policy"),
      std::nullopt};
  auto recoded_digest = mwperf::canonical_recoded_response_product_digest_v1(
      *response.recoded_response);
  REQUIRE(recoded_digest);
  response.recoded_response->product_id = Factory::recoded_response_product_id(
      {label("bound-recoded"), std::move(recoded_digest).value()});
  response.deployed_response_product_id =
      response.recoded_response->product_id;

  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
  return response;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1
bound_compression_three_bin_payload(
    const BoundRequestFixture& fixture,
    const CompressionLineageFixtureV1 lineage) {
  auto response = bound_all_stage_three_bin_payload(fixture);
  if (lineage == CompressionLineageFixtureV1::completion_source) {
    response.projection_center = std::nullopt;
    response.projected_mean = std::nullopt;
    auto& raw = response.raw_response;
    for (const auto& identification : raw.identifications) {
      REQUIRE(identification.raw_point.has_value());
    }
    mwperf::ResponseCoefficientTripleV1 coefficients{
        {{mwperf::ThreeBinCoefficientV1::one,
          *raw.identifications[0U].raw_point,
          raw.identifications[0U].coefficient_id},
         {mwperf::ThreeBinCoefficientV1::two,
          *raw.identifications[1U].raw_point,
          raw.identifications[1U].coefficient_id},
         {mwperf::ThreeBinCoefficientV1::tail_from_three,
          *raw.identifications[2U].raw_point,
          raw.identifications[2U].coefficient_id}}};
    response.recoded_response = mwperf::RecodedResponseProductV1{
        recoded_id("bound-recoded"), fixture.manifest.value().provider,
        fixture.request.request_digest().value(), response.deployed_target,
        std::move(coefficients),
        mwperf::ProductDerivationKindV1::endpoint_completion, std::nullopt,
        std::monostate{}, object_ref("bound-endpoint-completion-policy"),
        object_ref("bound-recoding-policy"), std::nullopt};
  } else if (lineage == CompressionLineageFixtureV1::raw_parent) {
    auto& recoded = *response.recoded_response;
    recoded.derivation_kind =
        mwperf::ProductDerivationKindV1::identity_recoding;
    recoded.projected_mean_parent = std::nullopt;
    recoded.reference_response_parent = response.raw_response.product_id;
    recoded.completion_policy_id = std::nullopt;
    for (std::size_t index = 0U; index < recoded.coefficients.size();
         ++index) {
      REQUIRE(response.raw_response.identifications[index]
                  .raw_point.has_value());
      recoded.coefficients[index].value =
          *response.raw_response.identifications[index].raw_point;
      recoded.coefficients[index].origin_coefficient_id =
          response.raw_response.identifications[index].coefficient_id;
    }
  }

  auto& recoded = *response.recoded_response;
  auto recoded_digest =
      mwperf::canonical_recoded_response_product_digest_v1(recoded);
  REQUIRE(recoded_digest);
  recoded.product_id = Factory::recoded_response_product_id(
      {label("bound-recoded"), std::move(recoded_digest).value()});
  response.deployed_response_product_id = recoded.product_id;
  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
  return response;
}

[[nodiscard]] const mwperf::MetricSupportRoleRequirementV1&
scalar_role_requirement(const mwperf::MetricSupportManifest& manifest,
                        const mwperf::MetricSupportRoleV1 role_value) {
  REQUIRE(manifest.clauses().size() == 1U);
  const auto& roles = manifest.clauses().front().required_roles;
  const auto found = std::find_if(
      roles.begin(), roles.end(), [role_value](const auto& requirement) {
        return requirement.role == role_value;
      });
  REQUIRE(found != roles.end());
  return *found;
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 bound_internal_object(
    const BoundRequestFixture& fixture,
    const mwperf::CommonBuildReportV1& report,
    const mwperf::InternalReferencePurposeV1 purpose,
    const mwperf::ThreeBinScalarResponseV1& response,
    const mwperf::ArtifactObjectReferenceV1& payload_identity,
    const mwperf::ArtifactObjectReferenceV1& validity_witness) {
  switch (purpose) {
    case mwperf::InternalReferencePurposeV1::coefficient_origin: {
      const auto nonpoint = std::find_if(
          response.raw_response.identifications.begin(),
          response.raw_response.identifications.end(), [](const auto& item) {
            return item.coefficient_status.raw_value_status !=
                   mwperf::RawValueStatusV1::exact_point;
          });
      if (nonpoint != response.raw_response.identifications.end()) {
        return nonpoint->coefficient_id;
      }
      if (!response.raw_envelopes.empty()) {
        REQUIRE_FALSE(response.raw_envelopes.front().covered_bins.empty());
        return response.raw_response
            .identifications[static_cast<std::size_t>(
                response.raw_envelopes.front().covered_bins.front())]
            .coefficient_id;
      }
      return response.raw_response.identifications.front().coefficient_id;
    }
    case mwperf::InternalReferencePurposeV1::configured_arrival_binding:
      return {label("configured-arrival-binding"),
              response.configured_arrival_binding};
    case mwperf::InternalReferencePurposeV1::artifact_payload:
      return payload_identity;
    case mwperf::InternalReferencePurposeV1::law_or_result:
      return response.response_row_id;
    case mwperf::InternalReferencePurposeV1::validity_witness:
      return validity_witness;
    case mwperf::InternalReferencePurposeV1::coordinate_codec:
      return object_ref("coordinate-codec");
    case mwperf::InternalReferencePurposeV1::mark_codec:
      return object_ref("mark-codec");
    case mwperf::InternalReferencePurposeV1::selection_binding:
      return object_ref("selection-binding");
    case mwperf::InternalReferencePurposeV1::timing_binding:
      return {label("timing-binding"),
              fixture.view.fingerprints().tie_and_timing};
    case mwperf::InternalReferencePurposeV1::validity_basis:
      return object_ref("validity-basis");
    case mwperf::InternalReferencePurposeV1::completion_source:
      return response.raw_response.identifications.front().coefficient_id;
    case mwperf::InternalReferencePurposeV1::completion_policy:
      if (response.nominal_response.has_value()) {
        REQUIRE(response.nominal_response->completion_policy_id.has_value());
        return *response.nominal_response->completion_policy_id;
      }
      REQUIRE(response.recoded_response.has_value());
      REQUIRE(response.recoded_response->completion_policy_id.has_value());
      return *response.recoded_response->completion_policy_id;
    case mwperf::InternalReferencePurposeV1::projection_source:
      REQUIRE(response.projection_center.has_value());
      return std::visit(
          [](const auto& source) { return source.identity(); },
          response.projection_center->response_source);
    case mwperf::InternalReferencePurposeV1::projection_policy:
      REQUIRE(response.projected_mean.has_value());
      return response.projected_mean->projection_policy_id;
    case mwperf::InternalReferencePurposeV1::recoding_policy:
      REQUIRE(response.recoded_response.has_value());
      return response.recoded_response->recoding_policy_id;
    case mwperf::InternalReferencePurposeV1::evaluation_identity:
      return response.raw_envelopes.empty()
                 ? object_ref("bound-final-evaluation")
                 : object_ref("interval-evaluation");
    case mwperf::InternalReferencePurposeV1::proposal_identity:
      return {label("interval-proposal"),
              response.raw_response.proposal_law_digest};
    case mwperf::InternalReferencePurposeV1::solver_identity:
      return object_ref("bound-solver");
    case mwperf::InternalReferencePurposeV1::constraint_identity:
      return {label("bound-constraint"),
              fixture.view.fingerprints().constraint};
    case mwperf::InternalReferencePurposeV1::call_report_identity:
      return {report.report_id, report.report_digest};
    case mwperf::InternalReferencePurposeV1::certified_product_or_envelope:
      return response.raw_response.product_id.identity();
    case mwperf::InternalReferencePurposeV1::sampling_bank:
      return object_ref("bound-input-bank");
    case mwperf::InternalReferencePurposeV1::sampling_probe:
      return object_ref("bound-sampling-probe");
    case mwperf::InternalReferencePurposeV1::coverage_family:
      return validity_witness;
    case mwperf::InternalReferencePurposeV1::estimand:
      return response.raw_response.product_id.identity();
    case mwperf::InternalReferencePurposeV1::algorithm_tolerance_policy:
      return object_ref("bound-algorithm-tolerance-policy");
    case mwperf::InternalReferencePurposeV1::residual_or_enclosure:
      return object_ref("bound-residual-or-enclosure");
    case mwperf::InternalReferencePurposeV1::representation_domain:
      return object_ref("bound-representation-domain");
    case mwperf::InternalReferencePurposeV1::calibration_rule:
      return object_ref("bound-calibration-rule");
    case mwperf::InternalReferencePurposeV1::calibration_source:
      return response.raw_response.product_id.identity();
    case mwperf::InternalReferencePurposeV1::compression_rule:
      return object_ref("bound-compression-rule");
    case mwperf::InternalReferencePurposeV1::compression_source: {
      const auto& roles = fixture.contract.structural_manifest()
                              .clauses()
                              .front()
                              .required_roles;
      const auto recoded = std::find_if(
          roles.begin(), roles.end(), [](const auto& requirement) {
            return requirement.role ==
                   mwperf::MetricSupportRoleV1::recoded_response;
          });
      REQUIRE(recoded != roles.end());
      const auto& recoded_requirement = *recoded;
      const bool uses_completion_source = std::any_of(
          recoded_requirement.internal_relations.begin(),
          recoded_requirement.internal_relations.end(),
          [](const auto& relation) {
            return relation.relation ==
                       mwperf::MetricRoleRelationKindV1::lineage_parent &&
                   relation.purpose ==
                       mwperf::InternalReferencePurposeV1::completion_source;
          });
      if (uses_completion_source) {
        return response.raw_response.identifications.front().coefficient_id;
      }
      const auto names_parent = [&](const mwperf::MetricSupportRoleV1 role) {
        return std::any_of(
            recoded_requirement.role_relations.begin(),
            recoded_requirement.role_relations.end(),
            [role](const auto& relation) {
              return relation.relation ==
                         mwperf::MetricRoleRelationKindV1::lineage_parent &&
                     relation.other_role == role;
            });
      };
      if (names_parent(mwperf::MetricSupportRoleV1::nominal_response)) {
        REQUIRE(response.nominal_response.has_value());
        return response.nominal_response->product_id.identity();
      }
      if (names_parent(mwperf::MetricSupportRoleV1::raw_response)) {
        return response.raw_response.product_id.identity();
      }
      REQUIRE(response.projected_mean.has_value());
      return response.projected_mean->product_id.identity();
    }
    case mwperf::InternalReferencePurposeV1::compression_destination:
      REQUIRE(response.recoded_response.has_value());
      return response.recoded_response->product_id.identity();
    case mwperf::InternalReferencePurposeV1::error_object:
      return validity_witness;
    case mwperf::InternalReferencePurposeV1::deployed_law:
      return response.response_row_id;
    case mwperf::InternalReferencePurposeV1::state_domain:
      return object_ref("bound-state-domain");
    case mwperf::InternalReferencePurposeV1::class_domain:
      return object_ref("bound-class-domain");
    case mwperf::InternalReferencePurposeV1::stability_statement:
      return object_ref("bound-stability-statement");
    default:
      FAIL("unexpected purpose in the scalar C15 fixture");
  }
  return payload_identity;
}

[[nodiscard]] mwperf::FamilyEvidenceEnvelopeV1 bound_family_evidence(
    const BoundRequestFixture& fixture,
    const mwperf::ArtifactObjectReferenceV1& payload_identity,
    const mwperf::ThreeBinScalarResponseV1& response) {
  const auto body = bytes_of(R"({"opaque_claim":"fixture-validity"})");
  auto body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(body);
  REQUIRE(body_digest);
  mwperf::FamilyEvidenceEnvelopeV1 result{
      1U,
      object_ref("bound-family-evidence"),
      "c15.fixture.evidence",
      1U,
      bound_conformance(fixture),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.request.request_digest().value(),
      payload_identity.object_digest,
      {payload_identity, response.response_row_id},
      {},
      std::vector<mwperf::QueueId>(
          fixture.contract.construction_target_scope().begin(),
          fixture.contract.construction_target_scope().end()),
      mwperf::MetricEvidenceScopeV1::validity_or_lift,
      body,
      std::move(body_digest).value()};
  auto envelope_digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(result);
  REQUIRE(envelope_digest);
  result.evidence_id.object_digest = std::move(envelope_digest).value();
  return result;
}

[[nodiscard]] std::vector<mwperf::RealizedRoleRelationV1>
bound_role_relations(
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const mwperf::MetricClauseIdV1& clause,
    const mwperf::ArtifactObjectReferenceV1& payload_identity,
    const mwperf::ThreeBinScalarResponseV1& response,
    const mwperf::ArtifactObjectReferenceV1& validity_evidence_identity,
    const std::optional<mwperf::ArtifactObjectReferenceV1>&
        compression_evidence_identity = std::nullopt,
    const std::optional<mwperf::ArtifactObjectReferenceV1>&
        raw_bound_evidence_identity = std::nullopt) {
  std::vector<mwperf::RealizedRoleRelationV1> result;
  for (const auto& relation : requirement.role_relations) {
    mwperf::ArtifactObjectReferenceV1 referenced = payload_identity;
    switch (relation.other_role) {
      case mwperf::MetricSupportRoleV1::deployed_payload:
        referenced = payload_identity;
        break;
      case mwperf::MetricSupportRoleV1::deployed_response:
      case mwperf::MetricSupportRoleV1::raw_response:
        referenced = response.raw_response.product_id.identity();
        break;
      case mwperf::MetricSupportRoleV1::nominal_response:
        REQUIRE(response.nominal_response.has_value());
        referenced = response.nominal_response->product_id.identity();
        break;
      case mwperf::MetricSupportRoleV1::projection_center:
        REQUIRE(response.projection_center.has_value());
        referenced = response.projection_center->product_id.identity();
        break;
      case mwperf::MetricSupportRoleV1::projected_mean:
        REQUIRE(response.projected_mean.has_value());
        referenced = response.projected_mean->product_id.identity();
        break;
      case mwperf::MetricSupportRoleV1::recoded_response:
        REQUIRE(response.recoded_response.has_value());
        referenced = response.recoded_response->product_id.identity();
        break;
      case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
        if (response.raw_envelopes.empty()) {
          REQUIRE(raw_bound_evidence_identity.has_value());
          referenced = *raw_bound_evidence_identity;
        } else {
          referenced = response.raw_envelopes.front().envelope_id;
        }
        break;
      case mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence:
        referenced = validity_evidence_identity;
        break;
      case mwperf::MetricSupportRoleV1::compression_evidence:
        REQUIRE(compression_evidence_identity.has_value());
        referenced = *compression_evidence_identity;
        break;
      default:
        FAIL("unexpected role relation in the scalar C15 fixture");
    }
    result.push_back(
        {relation.relation, {clause, relation.other_role}, referenced});
  }
  return result;
}

[[nodiscard]] std::vector<mwperf::RealizedInternalReferenceV1>
bound_internal_relations(
    const BoundRequestFixture& fixture,
    const mwperf::CommonBuildReportV1& report,
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const mwperf::ThreeBinScalarResponseV1& response,
    const mwperf::ArtifactObjectReferenceV1& payload_identity,
    const mwperf::ArtifactObjectReferenceV1& validity_witness) {
  std::vector<mwperf::RealizedInternalReferenceV1> result;
  for (const auto& relation : requirement.internal_relations) {
    result.push_back(
        {relation.relation, relation.purpose,
         bound_internal_object(fixture, report, relation.purpose, response,
                               payload_identity, validity_witness)});
  }
  return result;
}

void reseal_raw_only_bound_response(
    mwperf::ThreeBinScalarResponseV1& response) {
  REQUIRE_FALSE(response.nominal_response.has_value());
  REQUIRE_FALSE(response.projection_center.has_value());
  REQUIRE_FALSE(response.projected_mean.has_value());
  REQUIRE_FALSE(response.recoded_response.has_value());
  for (auto& identification : response.raw_response.identifications) {
    auto identification_digest =
        mwperf::artifact::detail::coefficient_identification_digest_v1(
            identification);
    REQUIRE(identification_digest);
    identification.coefficient_id.object_digest =
        std::move(identification_digest).value();
  }
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(
      response.raw_response);
  REQUIRE(raw_digest);
  response.raw_response.product_id = Factory::raw_response_product_id(
      {response.raw_response.product_id.identity().object_id,
       std::move(raw_digest).value()});
  response.deployed_response_product_id = response.raw_response.product_id;
  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
}

struct BoundBuiltFixture final {
  mwperf::CommonBuildReportV1 report;
  mwperf::ValidatedSurrogateBuildReport validated_report;
  mwperf::BuiltSurrogateResultV1 result;
};

[[nodiscard]] BoundBuiltFixture make_bound_built_fixture(
    const BoundRequestFixture& fixture,
    mwperf::ThreeBinScalarResponseV1 response,
    std::vector<mwperf::FamilyEvidenceEnvelopeV1> additional_family_evidence =
        {}) {
  mwperf::ArtifactPayloadV1 payload = response;
  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  REQUIRE(payload_digest);
  const mwperf::ArtifactObjectReferenceV1 payload_identity{
      label("bound-payload"), payload_digest.value()};
  const auto report = sealed_report_for(fixture);

  auto family = bound_family_evidence(fixture, payload_identity, response);
  additional_family_evidence.push_back(family);
  std::sort(additional_family_evidence.begin(),
            additional_family_evidence.end(),
            [](const auto& left, const auto& right) {
              return left.evidence_id < right.evidence_id;
            });
  const auto& manifest = fixture.contract.structural_manifest();
  const auto& clause = manifest.clauses().front().clause_id;
  const auto raw_bound_requirement = std::find_if(
      manifest.clauses().front().required_roles.begin(),
      manifest.clauses().front().required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               mwperf::MetricSupportRoleV1::raw_response_bound_evidence;
      });
  const bool has_raw_bound_role =
      raw_bound_requirement != manifest.clauses().front().required_roles.end();
  const auto& validity_requirement = scalar_role_requirement(
      manifest,
      mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
  auto validity_internal = bound_internal_relations(
      fixture, report, validity_requirement, response, payload_identity,
      family.evidence_id);
  std::vector<mwperf::ArtifactObjectReferenceV1> validity_subjects;
  std::vector<mwperf::ArtifactObjectReferenceV1> validity_parents;
  for (const auto& relation : validity_internal) {
    if (relation.relation == mwperf::MetricRoleRelationKindV1::subject) {
      validity_subjects.push_back(relation.referenced_object);
    } else if (relation.relation ==
               mwperf::MetricRoleRelationKindV1::lineage_parent) {
      validity_parents.push_back(relation.referenced_object);
    }
  }
  mwperf::ScopedArtifactEvidenceV1 scoped{
      object_ref("bound-validity-evidence"),
      mwperf::ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
      {response.deployed_target},
      mwperf::MetricResultScopeV1::not_a_metric_result,
      mwperf::MetricEvidenceScopeV1::validity_or_lift,
      std::move(validity_subjects),
      std::move(validity_parents),
      {family.evidence_id},
      validity_internal};
  auto scoped_digest =
      mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(scoped);
  REQUIRE(scoped_digest);
  scoped.evidence_id.object_digest = std::move(scoped_digest).value();

  std::vector<mwperf::ScopedArtifactEvidenceV1> scoped_records{scoped};
  const auto append_scoped_role = [&](const mwperf::MetricSupportRoleV1 role,
                                      const mwperf::ArtifactReferenceKindV1 kind,
                                      const std::string& identity,
                                      std::vector<
                                          mwperf::ArtifactObjectReferenceV1>
                                          family_ids = {}) {
    const auto& requirement = scalar_role_requirement(manifest, role);
    auto internal = bound_internal_relations(
        fixture, report, requirement, response, payload_identity,
        family.evidence_id);
    std::vector<mwperf::ArtifactObjectReferenceV1> subjects;
    std::vector<mwperf::ArtifactObjectReferenceV1> parents;
    const auto role_relations = bound_role_relations(
        requirement, clause, payload_identity, response,
        scoped.evidence_id);
    for (const auto& relation : role_relations) {
      if (relation.relation == mwperf::MetricRoleRelationKindV1::subject) {
        subjects.push_back(relation.referenced_object);
      } else if (relation.relation ==
                 mwperf::MetricRoleRelationKindV1::lineage_parent) {
        parents.push_back(relation.referenced_object);
      }
    }
    for (const auto& relation : internal) {
      if (relation.relation == mwperf::MetricRoleRelationKindV1::subject) {
        subjects.push_back(relation.referenced_object);
      } else if (relation.relation ==
                 mwperf::MetricRoleRelationKindV1::lineage_parent) {
        parents.push_back(relation.referenced_object);
      }
    }
    const auto canonicalize = [](auto& references) {
      std::sort(references.begin(), references.end());
      references.erase(std::unique(references.begin(), references.end()),
                       references.end());
    };
    canonicalize(subjects);
    canonicalize(parents);
    mwperf::ScopedArtifactEvidenceV1 evidence{
        object_ref(identity), kind, {response.deployed_target},
        requirement.result_scope, requirement.evidence_scope,
        std::move(subjects), std::move(parents), std::move(family_ids),
        std::move(internal)};
    auto digest =
        mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(evidence);
    REQUIRE(digest);
    evidence.evidence_id.object_digest = std::move(digest).value();
    scoped_records.push_back(std::move(evidence));
  };
  const auto manifest_has_role = [&](const mwperf::MetricSupportRoleV1 role) {
    return std::any_of(
        manifest.clauses().front().required_roles.begin(),
        manifest.clauses().front().required_roles.end(),
        [role](const auto& requirement) { return requirement.role == role; });
  };
  if (manifest_has_role(mwperf::MetricSupportRoleV1::optimizer_evidence)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::optimizer_evidence,
                       mwperf::ArtifactReferenceKindV1::optimizer_evidence,
                       "bound-optimizer-evidence");
  }
  if (manifest_has_role(mwperf::MetricSupportRoleV1::statistical_evidence)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::statistical_evidence,
                       mwperf::ArtifactReferenceKindV1::statistical_evidence,
                       "bound-statistical-evidence");
  }
  if (manifest_has_role(mwperf::MetricSupportRoleV1::numerical_evidence)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::numerical_evidence,
                       mwperf::ArtifactReferenceKindV1::numerical_evidence,
                       "bound-numerical-evidence");
  }
  if (manifest_has_role(mwperf::MetricSupportRoleV1::calibration_evidence)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::calibration_evidence,
                       mwperf::ArtifactReferenceKindV1::calibration_evidence,
                       "bound-calibration-evidence");
  }
  if (manifest_has_role(mwperf::MetricSupportRoleV1::compression_evidence)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::compression_evidence,
                       mwperf::ArtifactReferenceKindV1::compression_evidence,
                       "bound-compression-evidence");
  }
  if (manifest_has_role(mwperf::MetricSupportRoleV1::stability_certificate)) {
    append_scoped_role(mwperf::MetricSupportRoleV1::stability_certificate,
                       mwperf::ArtifactReferenceKindV1::stability_certificate,
                       "bound-stability-certificate");
  }
  if (has_raw_bound_role && response.raw_envelopes.empty()) {
    const auto nonpoint = std::find_if(
        response.raw_response.identifications.begin(),
        response.raw_response.identifications.end(), [](const auto& item) {
          return item.coefficient_status.raw_value_status !=
                 mwperf::RawValueStatusV1::exact_point;
        });
    REQUIRE(nonpoint != response.raw_response.identifications.end());
    append_scoped_role(
        mwperf::MetricSupportRoleV1::raw_response_bound_evidence,
        mwperf::ArtifactReferenceKindV1::raw_response_bound_evidence,
        "bound-raw-absence-evidence",
        nonpoint->family_evidence_envelope_ids);
  }
  std::sort(scoped_records.begin(), scoped_records.end(),
            [](const auto& left, const auto& right) {
              return left.evidence_id < right.evidence_id;
            });
  const auto scoped_identity_for =
      [&](const mwperf::ArtifactReferenceKindV1 kind)
      -> const mwperf::ArtifactObjectReferenceV1& {
    const auto found = std::find_if(
        scoped_records.begin(), scoped_records.end(),
        [kind](const auto& evidence) {
          return evidence.reference_kind == kind;
        });
    REQUIRE(found != scoped_records.end());
    return found->evidence_id;
  };
  const std::optional<mwperf::ArtifactObjectReferenceV1>
      compression_evidence_identity =
          manifest_has_role(mwperf::MetricSupportRoleV1::compression_evidence)
              ? std::optional<mwperf::ArtifactObjectReferenceV1>{
                    scoped_identity_for(mwperf::ArtifactReferenceKindV1::
                                            compression_evidence)}
              : std::nullopt;
  const std::optional<mwperf::ArtifactObjectReferenceV1>
      raw_bound_evidence_identity =
          has_raw_bound_role && response.raw_envelopes.empty()
              ? std::optional<mwperf::ArtifactObjectReferenceV1>{
                    scoped_identity_for(mwperf::ArtifactReferenceKindV1::
                                            raw_response_bound_evidence)}
              : std::nullopt;

  const auto make_core = [&](const mwperf::MetricSupportRoleV1 role_value) {
    const auto& requirement = scalar_role_requirement(manifest, role_value);
    return mwperf::RealizedReferenceCoreV1{
        {response.deployed_target},
        requirement.target_scope,
        requirement.result_scope,
        requirement.evidence_scope,
        bound_role_relations(requirement, clause, payload_identity, response,
                             scoped.evidence_id,
                             compression_evidence_identity,
                             raw_bound_evidence_identity),
        bound_internal_relations(fixture, report, requirement, response,
                                 payload_identity, family.evidence_id)};
  };

  const bool raw_is_exact_point = std::all_of(
      response.raw_response.identifications.begin(),
      response.raw_response.identifications.end(), [](const auto& item) {
        return item.coefficient_status.raw_value_status ==
                   mwperf::RawValueStatusV1::exact_point &&
               item.raw_point.has_value();
      });
  std::vector<mwperf::RealizedMetricBindingV1> realized;
  for (const auto& requirement : manifest.clauses().front().required_roles) {
    auto core = make_core(requirement.role);
    mwperf::RealizedReferenceV1 reference =
        [&]() -> mwperf::RealizedReferenceV1 {
      switch (requirement.role) {
        case mwperf::MetricSupportRoleV1::deployed_payload:
          return mwperf::DeployedPayloadReferenceV1{
              std::move(core), {payload_identity}};
        case mwperf::MetricSupportRoleV1::deployed_response:
          return std::visit(
              [&](const auto& selected) -> mwperf::RealizedReferenceV1 {
                using Selected = std::decay_t<decltype(selected)>;
                if constexpr (std::same_as<Selected,
                                           mwperf::RawResponseProductId>) {
                  return mwperf::DeployedResponseReferenceV1{
                      std::move(core),
                      mwperf::RawResponseProductRef{
                          selected.identity(),
                          mwperf::ResponseProductValueFormV1::exact_point}};
                } else if constexpr (std::same_as<
                                         Selected,
                                         mwperf::NominalResponseProductId>) {
                  return mwperf::DeployedResponseReferenceV1{
                      std::move(core),
                      mwperf::NominalResponseProductRef{
                          selected.identity()}};
                } else {
                  return mwperf::DeployedResponseReferenceV1{
                      std::move(core),
                      mwperf::RecodedResponseProductRef{
                          selected.identity()}};
                }
              },
              response.deployed_response_product_id);
        case mwperf::MetricSupportRoleV1::raw_response:
          return mwperf::RawResponseProductReferenceV1{
              std::move(core),
              {response.raw_response.product_id.identity(),
               raw_is_exact_point
                   ? mwperf::ResponseProductValueFormV1::exact_point
                   : mwperf::ResponseProductValueFormV1::interval_only}};
        case mwperf::MetricSupportRoleV1::nominal_response:
          REQUIRE(response.nominal_response.has_value());
          return mwperf::NominalResponseProductReferenceV1{
              std::move(core),
              {response.nominal_response->product_id.identity()}};
        case mwperf::MetricSupportRoleV1::projection_center:
          REQUIRE(response.projection_center.has_value());
          return mwperf::ProjectionCenterProductReferenceV1{
              std::move(core),
              {response.projection_center->product_id.identity()}};
        case mwperf::MetricSupportRoleV1::projected_mean:
          REQUIRE(response.projected_mean.has_value());
          return mwperf::ProjectedMeanProductReferenceV1{
              std::move(core),
              {response.projected_mean->product_id.identity()}};
        case mwperf::MetricSupportRoleV1::recoded_response:
          REQUIRE(response.recoded_response.has_value());
          return mwperf::RecodedResponseProductReferenceV1{
              std::move(core),
              {response.recoded_response->product_id.identity()}};
        case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
          if (response.raw_envelopes.empty()) {
            return mwperf::RawResponseBoundEvidenceReferenceV1{
                std::move(core),
                {scoped_identity_for(
                    mwperf::ArtifactReferenceKindV1::
                        raw_response_bound_evidence)}};
          }
          return mwperf::RawResponseBoundEvidenceReferenceV1{
              std::move(core),
              {response.raw_envelopes.front().envelope_id}};
        case mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence:
          return mwperf::ReportedValidityOrLiftEvidenceReferenceV1{
              std::move(core), {scoped.evidence_id}};
        case mwperf::MetricSupportRoleV1::optimizer_evidence:
          return mwperf::OptimizerEvidenceReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::optimizer_evidence)}};
        case mwperf::MetricSupportRoleV1::statistical_evidence:
          return mwperf::StatisticalEvidenceReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::statistical_evidence)}};
        case mwperf::MetricSupportRoleV1::numerical_evidence:
          return mwperf::NumericalEvidenceReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::numerical_evidence)}};
        case mwperf::MetricSupportRoleV1::calibration_evidence:
          return mwperf::CalibrationEvidenceReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::calibration_evidence)}};
        case mwperf::MetricSupportRoleV1::compression_evidence:
          return mwperf::CompressionEvidenceReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::compression_evidence)}};
        case mwperf::MetricSupportRoleV1::stability_certificate:
          return mwperf::StabilityCertificateReferenceV1{
              std::move(core),
              {scoped_identity_for(
                  mwperf::ArtifactReferenceKindV1::stability_certificate)}};
        default:
          FAIL("unsupported role in the scalar C15 fixture");
      }
      return mwperf::DeployedPayloadReferenceV1{
          std::move(core), {payload_identity}};
        }();
    realized.push_back({{clause, requirement.role}, std::move(reference)});
  }

  const std::optional<mwperf::TypedLabel> proposal_id =
      has_raw_bound_role
          ? std::optional<mwperf::TypedLabel>{label("interval-proposal")}
          : std::nullopt;
  const std::optional<mwperf::TypedLabel> evaluation_id =
      has_raw_bound_role
          ? std::optional<mwperf::TypedLabel>{
                response.raw_envelopes.empty()
                    ? label("bound-final-evaluation")
                    : label("interval-evaluation")}
          : (manifest_has_role(mwperf::MetricSupportRoleV1::optimizer_evidence) ||
                     manifest_has_role(
                         mwperf::MetricSupportRoleV1::statistical_evidence)
                 ? std::optional<mwperf::TypedLabel>{
                       label("bound-final-evaluation")}
                 : std::nullopt);
  const std::optional<mwperf::TypedLabel> input_bank_id =
      manifest_has_role(mwperf::MetricSupportRoleV1::statistical_evidence) ||
              manifest_has_role(
                  mwperf::MetricSupportRoleV1::calibration_evidence)
          ? std::optional<mwperf::TypedLabel>{label("bound-input-bank")}
          : std::nullopt;

  mwperf::SurrogateArtifactV1 artifact{
      1U,
      fixture.request.request_digest().value(),
      fixture.manifest.value().provider,
      fixture.manifest.scientific_contract_digest().value(),
      fixture.contract.construction_method(),
      fixture.contract.producer_mode(),
      fixture.contract.semantic(),
      fixture.contract.runtime_access(),
      fixture.contract.payload_class(),
      payload_identity,
      std::move(payload),
      payload_digest.value(),
      manifest_echo(manifest),
      {fixture.request.request_digest().value(), payload_digest.value(),
       std::move(realized)},
      fixture.contract.descriptor_core(),
      report,
      std::move(additional_family_evidence),
      std::move(scoped_records),
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::move(input_bank_id),
       std::move(proposal_id),
       std::move(evaluation_id)}};
  mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};
  return {report, Factory::validated_build_report(report),
          {std::move(envelope), std::move(artifact)}};
}

[[nodiscard]] BoundBuiltFixture make_bound_built_fixture(
    const BoundRequestFixture& fixture) {
  return make_bound_built_fixture(fixture, bound_three_bin_payload(fixture));
}

struct BoundIntervalResponseFixture final {
  mwperf::ThreeBinScalarResponseV1 response;
  mwperf::FamilyEvidenceEnvelopeV1 interval_evidence;
};

void reseal_interval_family_backlinks(
    BoundIntervalResponseFixture& interval_fixture) {
  auto& response = interval_fixture.response;
  auto& evidence = interval_fixture.interval_evidence;
  REQUIRE(response.nominal_response.has_value());

  for (auto& envelope : response.raw_envelopes) {
    auto digest =
        mwperf::artifact::detail::raw_response_envelope_digest_v1(envelope);
    REQUIRE(digest);
    envelope.envelope_id.object_digest = std::move(digest).value();
  }
  std::sort(response.raw_envelopes.begin(), response.raw_envelopes.end(),
            [](const auto& left, const auto& right) {
              return left.envelope_id < right.envelope_id;
            });
  auto row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();

  const mwperf::ArtifactPayloadV1 projected_payload = response;
  auto payload_digest =
      mwperf::canonical_artifact_payload_digest_v1(projected_payload);
  REQUIRE(payload_digest);
  evidence.payload_digest = payload_digest.value();
  evidence.subject_references.clear();
  if (response.raw_envelopes.empty()) {
    for (const auto& identification :
         response.raw_response.identifications) {
      const bool names_evidence = std::any_of(
          identification.family_evidence_envelope_ids.begin(),
          identification.family_evidence_envelope_ids.end(),
          [&](const auto& reference) {
            return reference.object_id == evidence.evidence_id.object_id;
          });
      if (names_evidence) {
        evidence.subject_references.push_back(
            identification.coefficient_id);
      }
    }
  } else {
    for (const auto& envelope : response.raw_envelopes) {
      evidence.subject_references.push_back(envelope.envelope_id);
      for (const auto bin : envelope.covered_bins) {
        evidence.subject_references.push_back(
            response.raw_response
                .identifications[static_cast<std::size_t>(bin)]
                .coefficient_id);
      }
    }
  }
  std::sort(evidence.subject_references.begin(),
            evidence.subject_references.end());
  evidence.subject_references.erase(
      std::unique(evidence.subject_references.begin(),
                  evidence.subject_references.end()),
      evidence.subject_references.end());
  evidence.parent_references = {
      response.raw_response.product_id.identity()};
  auto body_digest = mwperf::artifact::detail::family_evidence_body_digest_v1(
      evidence.canonical_family_body);
  REQUIRE(body_digest);
  evidence.canonical_family_body_digest = std::move(body_digest).value();
  auto evidence_digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(evidence);
  REQUIRE(evidence_digest);
  evidence.evidence_id.object_digest = std::move(evidence_digest).value();

  const auto replace_backlink = [&](mwperf::ArtifactObjectReferenceV1& ref) {
    if (ref.object_id == evidence.evidence_id.object_id) {
      ref = evidence.evidence_id;
    }
  };
  for (auto& identification : response.raw_response.identifications) {
    for (auto& reference : identification.family_evidence_envelope_ids) {
      replace_backlink(reference);
    }
  }
  for (auto& envelope : response.raw_envelopes) {
    for (auto& reference : envelope.family_evidence_envelope_ids) {
      replace_backlink(reference);
    }
  }

  for (const auto& identification : response.raw_response.identifications) {
    auto digest =
        mwperf::artifact::detail::coefficient_identification_digest_v1(
            identification);
    REQUIRE(digest);
    CHECK(digest.value() == identification.coefficient_id.object_digest);
  }
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(
      response.raw_response);
  REQUIRE(raw_digest);
  CHECK(raw_digest.value() ==
        response.raw_response.product_id.identity().object_digest);
  for (const auto& envelope : response.raw_envelopes) {
    auto digest =
        mwperf::artifact::detail::raw_response_envelope_digest_v1(envelope);
    REQUIRE(digest);
    CHECK(digest.value() == envelope.envelope_id.object_digest);
  }
  auto final_row_digest =
      mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(final_row_digest);
  CHECK(final_row_digest.value() == response.response_row_id.object_digest);
  const mwperf::ArtifactPayloadV1 final_payload = response;
  auto final_payload_digest =
      mwperf::canonical_artifact_payload_digest_v1(final_payload);
  REQUIRE(final_payload_digest);
  CHECK(final_payload_digest.value() == payload_digest.value());
}

[[nodiscard]] BoundIntervalResponseFixture make_bound_interval_response(
    const BoundRequestFixture& fixture) {
  auto response = bound_three_bin_payload(fixture);
  const mwperf::ArtifactObjectReferenceV1 evidence_placeholder{
      label("bound-interval-family-evidence"),
      digest_of("late-bound-evidence-placeholder")};
  auto& interval = response.raw_response.identifications.at(1U);
  interval.coefficient_status.raw_value_status =
      mwperf::RawValueStatusV1::interval_only;
  interval.raw_point = std::nullopt;
  interval.family_evidence_envelope_ids = {evidence_placeholder};
  reseal_raw_only_bound_response(response);

  const auto& raw = response.raw_response;
  const auto completion_policy = object_ref("interval-completion-policy");
  mwperf::ResponseCoefficientTripleV1 coefficients{
      {{mwperf::ThreeBinCoefficientV1::one, scalar(1, 4),
        raw.identifications[0U].coefficient_id},
       {mwperf::ThreeBinCoefficientV1::two, scalar(1, 2),
        raw.identifications[1U].coefficient_id},
       {mwperf::ThreeBinCoefficientV1::tail_from_three, scalar(1, 2),
        raw.identifications[2U].coefficient_id}}};
  response.nominal_response = mwperf::NominalResponseProductV1{
      nominal_id("bound-interval-nominal"), fixture.manifest.value().provider,
      fixture.request.request_digest().value(), response.deployed_target,
      std::move(coefficients), raw.product_id, completion_policy,
      std::nullopt};
  auto nominal_digest = mwperf::canonical_nominal_response_product_digest_v1(
      *response.nominal_response);
  REQUIRE(nominal_digest);
  response.nominal_response->product_id = Factory::nominal_response_product_id(
      {label("bound-interval-nominal"),
       std::move(nominal_digest).value()});
  response.deployed_response_product_id =
      response.nominal_response->product_id;

  mwperf::RawResponseEnvelopeV1 envelope{
      object_ref("bound-bin-two-envelope"),
      raw.product_id,
      raw.proposal_law_digest,
      {mwperf::ThreeBinCoefficientV1::two},
      {scalar(1, 4)},
      {scalar(3, 4)},
      "fixture.exact-bin-two-interval",
      mwperf::RawEnvelopeCoverageV1::deterministic,
      mwperf::PopulationConditioningPremiseV1::unconditional,
      std::nullopt,
      std::nullopt,
      mwperf::RawEnvelopeScopeV1::proposal_raw,
      {evidence_placeholder}};
  auto envelope_digest =
      mwperf::artifact::detail::raw_response_envelope_digest_v1(envelope);
  REQUIRE(envelope_digest);
  envelope.envelope_id.object_digest = std::move(envelope_digest).value();
  response.raw_envelopes = {std::move(envelope)};

  const auto body = bytes_of(R"({"claim":"bin-two-interval"})");
  auto body_digest = mwperf::artifact::detail::family_evidence_body_digest_v1(
      body);
  REQUIRE(body_digest);
  BoundIntervalResponseFixture result{
      std::move(response),
      {1U,
       evidence_placeholder,
       "c15.fixture.evidence",
       1U,
       bound_conformance(fixture),
       fixture.manifest.value().provider,
       fixture.manifest.scientific_contract_digest().value(),
       fixture.request.request_digest().value(),
       digest_of("late-bound-payload-placeholder"),
       {},
       {},
       std::vector<mwperf::QueueId>(
           fixture.contract.construction_target_scope().begin(),
           fixture.contract.construction_target_scope().end()),
       mwperf::MetricEvidenceScopeV1::raw_static_proposal,
       body,
       std::move(body_digest).value()}};
  reseal_interval_family_backlinks(result);
  return result;
}

void reseal_status_mutated_interval_response(
    BoundIntervalResponseFixture& result) {
  auto& response = result.response;
  for (auto& identification : response.raw_response.identifications) {
    auto digest =
        mwperf::artifact::detail::coefficient_identification_digest_v1(
            identification);
    REQUIRE(digest);
    identification.coefficient_id.object_digest =
        std::move(digest).value();
  }
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(
      response.raw_response);
  REQUIRE(raw_digest);
  response.raw_response.product_id = Factory::raw_response_product_id(
      {response.raw_response.product_id.identity().object_id,
       std::move(raw_digest).value()});

  REQUIRE(response.nominal_response.has_value());
  auto& nominal = *response.nominal_response;
  nominal.raw_parent = response.raw_response.product_id;
  for (std::size_t index = 0U; index < nominal.coefficients.size(); ++index) {
    nominal.coefficients[index].origin_coefficient_id =
        response.raw_response.identifications[index].coefficient_id;
  }
  auto nominal_digest =
      mwperf::canonical_nominal_response_product_digest_v1(nominal);
  REQUIRE(nominal_digest);
  nominal.product_id = Factory::nominal_response_product_id(
      {nominal.product_id.identity().object_id,
       std::move(nominal_digest).value()});
  response.deployed_response_product_id = nominal.product_id;

  for (auto& envelope : response.raw_envelopes) {
    envelope.source_product = response.raw_response.product_id;
    envelope.construction_law_digest =
        response.raw_response.proposal_law_digest;
  }
  reseal_interval_family_backlinks(result);
}

[[nodiscard]] BoundIntervalResponseFixture make_bound_absence_response(
    const BoundRequestFixture& fixture,
    const mwperf::PopulationConditioningStatusV1 population =
        mwperf::PopulationConditioningStatusV1::proved_zero,
    const bool retain_family_proof = true) {
  auto result = make_bound_interval_response(fixture);
  auto& identification =
      result.response.raw_response.identifications[1U];
  identification.proposal_conditioning = {
      mwperf::ProposalConditioningSourceV1::exact_population,
      scalar(0, 1), std::nullopt};
  identification.coefficient_status = {
      population, mwperf::RawValueStatusV1::absent};
  identification.raw_point = std::nullopt;
  if (!retain_family_proof) {
    identification.family_evidence_envelope_ids.clear();
  }
  result.response.raw_envelopes.clear();
  reseal_status_mutated_interval_response(result);
  return result;
}

[[nodiscard]] BoundIntervalResponseFixture make_bound_closed_status_response(
    const BoundRequestFixture& fixture,
    const mwperf::ProposalConditioningSourceV1 source,
    const mwperf::PopulationConditioningStatusV1 population,
    const mwperf::RawValueStatusV1 raw_status) {
  auto result = make_bound_interval_response(fixture);
  const std::size_t index =
      raw_status == mwperf::RawValueStatusV1::absent ? 2U : 1U;
  auto& identification =
      result.response.raw_response.identifications[index];
  identification.proposal_conditioning.source = source;
  identification.proposal_conditioning.observed_nonnegative_value =
      scalar(1, 2);
  identification.proposal_conditioning.frozen_evaluation_id =
      source == mwperf::ProposalConditioningSourceV1::empirical_average
          ? std::optional<mwperf::TypedLabel>{label("interval-evaluation")}
          : std::nullopt;
  identification.coefficient_status = {population, raw_status};
  identification.raw_point =
      raw_status == mwperf::RawValueStatusV1::exact_point
          ? std::optional<mwperf::PortableScientificScalar>{scalar(1, 2)}
          : std::nullopt;
  if (raw_status == mwperf::RawValueStatusV1::absent) {
    identification.family_evidence_envelope_ids.clear();
  } else {
    REQUIRE(index == 1U);
    auto& envelope = result.response.raw_envelopes.front();
    envelope.coverage =
        source == mwperf::ProposalConditioningSourceV1::empirical_average
            ? mwperf::RawEnvelopeCoverageV1::marginal
            : mwperf::RawEnvelopeCoverageV1::deterministic;
    envelope.population_conditioning_premise =
        population == mwperf::PopulationConditioningStatusV1::unresolved
            ? mwperf::PopulationConditioningPremiseV1::
                  conditional_on_population_positivity
            : mwperf::PopulationConditioningPremiseV1::unconditional;
    envelope.frozen_evaluation_id =
        identification.proposal_conditioning.frozen_evaluation_id;
    envelope.sample_size =
        source == mwperf::ProposalConditioningSourceV1::empirical_average
            ? std::optional<mwperf::BigNat>{mwperf::BigNat{1U}}
            : std::nullopt;
  }
  reseal_status_mutated_interval_response(result);
  return result;
}

[[nodiscard]] mwperf::Result<mwperf::ValidatedSurrogateBuildResult>
validate_bound_built(const BoundRequestFixture& request_fixture,
                     const BoundBuiltFixture& built_fixture) {
  return mwperf::validate_surrogate_build_result(
      mwperf::SurrogateBuildResultV1{built_fixture.result},
      request_fixture.request, request_fixture.manifest,
      request_fixture.contract, built_fixture.validated_report);
}

[[nodiscard]] mwperf::RealizedMetricBindingV1& realized_binding(
    mwperf::SurrogateArtifactV1& artifact,
    const mwperf::MetricSupportRoleV1 role_value) {
  const auto found = std::find_if(
      artifact.realized_metric_bindings.bindings.begin(),
      artifact.realized_metric_bindings.bindings.end(),
      [role_value](const auto& binding) {
        return binding.key.role == role_value;
      });
  REQUIRE(found != artifact.realized_metric_bindings.bindings.end());
  return *found;
}

void reseal_scoped_evidence_and_binding(mwperf::SurrogateArtifactV1& artifact,
                                        const std::size_t index = 0U) {
  REQUIRE(index < artifact.scoped_evidence.size());
  auto& scoped = artifact.scoped_evidence[index];
  auto digest =
      mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(scoped);
  REQUIRE(digest);
  scoped.evidence_id.object_digest = std::move(digest).value();
  auto& binding = realized_binding(
      artifact,
      mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
  auto& reference =
      std::get<mwperf::ReportedValidityOrLiftEvidenceReferenceV1>(
          binding.reference);
  reference.evidence.identity = scoped.evidence_id;
}

void reseal_scoped_evidence_for_role(
    mwperf::SurrogateArtifactV1& artifact,
    const mwperf::MetricSupportRoleV1 role) {
  auto& binding = realized_binding(artifact, role);
  const auto prior = mwperf::realized_reference_subject_v1(binding.reference);
  const auto found = std::find_if(
      artifact.scoped_evidence.begin(), artifact.scoped_evidence.end(),
      [&prior](const auto& evidence) {
        return evidence.evidence_id == prior;
      });
  REQUIRE(found != artifact.scoped_evidence.end());
  auto digest =
      mwperf::artifact::detail::scoped_artifact_evidence_digest_v1(*found);
  REQUIRE(digest);
  found->evidence_id.object_digest = std::move(digest).value();
  const auto updated = found->evidence_id;
  std::visit(
      [&updated](auto& reference) {
        if constexpr (requires { reference.evidence.identity; }) {
          reference.evidence.identity = updated;
        } else {
          FAIL("fixture reseal requested for a non-scoped role");
        }
      },
      binding.reference);
  for (auto& candidate : artifact.realized_metric_bindings.bindings) {
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        candidate.reference);
    for (auto& relation : core.role_relations) {
      if (relation.referenced_object == prior) {
        relation.referenced_object = updated;
      }
    }
  }
}

void reseal_family_evidence_and_references(
    mwperf::SurrogateArtifactV1& artifact, const std::size_t index = 0U) {
  REQUIRE(index < artifact.family_evidence.size());
  auto& family = artifact.family_evidence[index];
  const auto prior_identity = family.evidence_id;
  auto body_digest = mwperf::artifact::detail::family_evidence_body_digest_v1(
      family.canonical_family_body);
  REQUIRE(body_digest);
  family.canonical_family_body_digest = std::move(body_digest).value();
  auto envelope_digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(family);
  REQUIRE(envelope_digest);
  family.evidence_id.object_digest = std::move(envelope_digest).value();

  const auto replace = [&](mwperf::ArtifactObjectReferenceV1& reference) {
    if (reference == prior_identity) reference = family.evidence_id;
  };
  const auto replace_response = [&](mwperf::ThreeBinScalarResponseV1& response) {
    for (auto& identification : response.raw_response.identifications) {
      for (auto& reference : identification.family_evidence_envelope_ids) {
        replace(reference);
      }
    }
    for (auto& envelope : response.raw_envelopes) {
      for (auto& reference : envelope.family_evidence_envelope_ids) {
        replace(reference);
      }
    }
  };
  if (auto* response =
          std::get_if<mwperf::ThreeBinScalarResponseV1>(&artifact.payload)) {
    replace_response(*response);
  } else if (auto* envelope =
                 std::get_if<mwperf::ResponseEnvelopeEvidenceV1>(
                     &artifact.payload)) {
    replace_response(envelope->lower_response);
    replace_response(envelope->upper_response);
  }
  for (auto& scoped : artifact.scoped_evidence) {
    for (auto& reference : scoped.family_envelope_ids) replace(reference);
    for (auto& relation : scoped.internal_references) {
      replace(relation.referenced_object);
    }
  }
  for (auto& binding : artifact.realized_metric_bindings.bindings) {
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        binding.reference);
    for (auto& relation : core.internal_relations) {
      replace(relation.referenced_object);
    }
  }
  for (std::size_t scoped_index = 0U;
       scoped_index < artifact.scoped_evidence.size(); ++scoped_index) {
    const auto identity = artifact.scoped_evidence[scoped_index].evidence_id;
    const auto binding = std::find_if(
        artifact.realized_metric_bindings.bindings.begin(),
        artifact.realized_metric_bindings.bindings.end(),
        [&identity](const auto& item) {
          return mwperf::realized_reference_subject_v1(item.reference) ==
                 identity;
        });
    REQUIRE(binding != artifact.realized_metric_bindings.bindings.end());
    reseal_scoped_evidence_for_role(artifact, binding->key.role);
  }
}

[[nodiscard]] mwperf::ArtifactParseLimits generous_parse_limits() {
  return {1U << 20U, 64U, 1U << 14U, 1U << 14U, 1U << 16U, 1U << 16U,
          8U << 20U};
}

[[nodiscard]] std::vector<std::byte> bytes_of(const std::string& text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  return {bytes.begin(), bytes.end()};
}

[[nodiscard]] std::filesystem::path c15_fixture_path(
    const std::string_view name) {
  return std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
         "fixtures" / "c15" / std::string(name);
}

[[nodiscard]] std::string read_fixture_text(const std::string_view name) {
  std::ifstream input(c15_fixture_path(name), std::ios::binary);
  INFO(c15_fixture_path(name).string());
  REQUIRE(input.is_open());
  std::ostringstream buffer;
  buffer << input.rdbuf();
  REQUIRE((input.good() || input.eof()));
  return buffer.str();
}

[[nodiscard]] std::string read_project_text(const std::string_view path) {
  const auto source_path =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / std::string(path);
  std::ifstream input(source_path, std::ios::binary);
  INFO(source_path.string());
  REQUIRE(input.is_open());
  std::ostringstream buffer;
  buffer << input.rdbuf();
  REQUIRE((input.good() || input.eof()));
  return buffer.str();
}

[[nodiscard]] std::string text_of(const std::span<const std::byte> bytes) {
  std::string result;
  result.reserve(bytes.size());
  for (const std::byte value : bytes) {
    result.push_back(static_cast<char>(std::to_integer<unsigned char>(value)));
  }
  return result;
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::PortableScientificScalar& value) {
  return value.kind() == mwperf::PortableScientificScalarKind::rational;
}

[[nodiscard]] bool contains_only_rationals(
    const std::vector<mwperf::PortableScientificScalar>& values) {
  return std::all_of(values.begin(), values.end(), [](const auto& value) {
    return contains_only_rationals(value);
  });
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::PortableValueV1& value) {
  return std::visit(
      [](const auto& active) { return contains_only_rationals(active); },
      value);
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::ResponseCoefficientTripleV1& values) {
  return std::all_of(values.begin(), values.end(), [](const auto& value) {
    return contains_only_rationals(value.value);
  });
}

[[nodiscard]] bool contains_only_rationals(
    const std::vector<mwperf::FiniteLawRowV1>& rows) {
  return std::all_of(rows.begin(), rows.end(), [](const auto& row) {
    return std::all_of(row.atoms.begin(), row.atoms.end(), [](const auto& atom) {
      return contains_only_rationals(atom.probability);
    });
  });
}

[[nodiscard]] bool contains_only_rationals(
    const std::vector<mwperf::ExplicitOrderedWordV1>& words) {
  return std::all_of(words.begin(), words.end(), [](const auto& word) {
    return contains_only_rationals(word.probability);
  });
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::FinitePredictiveStoppingTablesV1& tables) {
  return contains_only_rationals(tables.continuation_rows) &&
         contains_only_rationals(tables.stop_or_event_rows) &&
         contains_only_rationals(tables.terminal_or_exit_rows);
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::FiniteLawTableAlternativeV1& table) {
  return std::visit(
      [](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active,
                                   mwperf::StationaryMarkedEdgeTableV1>) {
          return contains_only_rationals(active.joint_edge_rows);
        } else if constexpr (
            std::same_as<Active, mwperf::StagedOpportunityFluxTableV1>) {
          return contains_only_rationals(active.opportunity_rows) &&
                 contains_only_rationals(active.successor_mark_rows);
        } else if constexpr (
            std::same_as<Active, mwperf::TemporalContinuationTableV1>) {
          return contains_only_rationals(active.continuation_rows);
        } else if constexpr (std::same_as<Active,
                                          mwperf::StoppedPathTableV1>) {
          return std::visit(
                     [](const auto& representation) {
                       return contains_only_rationals(representation);
                     },
                     active.representation) &&
                 contains_only_rationals(
                     active.nonhit_or_nontermination_probability);
        } else if constexpr (
            std::same_as<Active, mwperf::RomrResidenceWordTableV1>) {
          return std::visit(
                     [](const auto& representation) {
                       return contains_only_rationals(representation);
                     },
                     active.representation) &&
                 contains_only_rationals(active.nontermination_probability);
        } else {
          static_assert(std::same_as<
                        Active, mwperf::CoupledCommonScheduleTableV1>);
          return contains_only_rationals(active.common_joint_rows);
        }
      },
      table);
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::ThreeBinScalarResponseV1& response) {
  for (const auto& item : response.raw_response.identifications) {
    if (!contains_only_rationals(
            item.proposal_conditioning.observed_nonnegative_value) ||
        (item.raw_point.has_value() &&
         !contains_only_rationals(*item.raw_point))) {
      return false;
    }
  }
  if (response.nominal_response.has_value() &&
      !contains_only_rationals(response.nominal_response->coefficients)) {
    return false;
  }
  if (response.projection_center.has_value() &&
      !contains_only_rationals(response.projection_center->mean_vector)) {
    return false;
  }
  if (response.projected_mean.has_value() &&
      !contains_only_rationals(response.projected_mean->mean_vector)) {
    return false;
  }
  if (response.recoded_response.has_value() &&
      !contains_only_rationals(response.recoded_response->coefficients)) {
    return false;
  }
  return std::all_of(response.raw_envelopes.begin(),
                     response.raw_envelopes.end(), [](const auto& envelope) {
                       return contains_only_rationals(envelope.lower) &&
                              contains_only_rationals(envelope.upper);
                     });
}

[[nodiscard]] bool contains_only_rationals(
    const mwperf::FinitePrefixConstantTailResponseV1& response) {
  const bool identifications_are_rational = std::all_of(
      response.raw_response.identifications.begin(),
      response.raw_response.identifications.end(),
      [](const auto& identification) {
        return contains_only_rationals(
                   identification.pooled_unserved_mass) &&
               contains_only_rationals(identification.pooled_served_mass) &&
               contains_only_rationals(identification.raw_point);
      });
  return identifications_are_rational &&
         std::all_of(
             response.raw_envelopes.begin(), response.raw_envelopes.end(),
             [](const auto& envelope) {
               return contains_only_rationals(envelope.lower) &&
                      contains_only_rationals(envelope.upper) &&
                      contains_only_rationals(
                          envelope.concentration_radius_lower) &&
                      contains_only_rationals(
                          envelope.concentration_radius_upper) &&
                      contains_only_rationals(
                          envelope.floating_point_enclosure);
             });
}

[[nodiscard]] bool manifest_identity_tuples_unique(
    const std::span<const mwperf::SurrogateProviderManifestV1> manifests) {
  for (std::size_t left = 0U; left < manifests.size(); ++left) {
    for (std::size_t right = left + 1U; right < manifests.size(); ++right) {
      if (manifests[left].provider == manifests[right].provider &&
          (manifests[left].construction_method !=
               manifests[right].construction_method ||
           manifests[left].producer_mode != manifests[right].producer_mode ||
           manifests[left].deployed_semantic_tag !=
               manifests[right].deployed_semantic_tag ||
           manifests[left].runtime_access_tag !=
               manifests[right].runtime_access_tag ||
           manifests[left].payload_class != manifests[right].payload_class ||
           manifests[left].default_selection !=
               manifests[right].default_selection)) {
        return false;
      }
    }
  }
  return true;
}

template <typename Argument>
concept AdaptableArgument = requires(const Argument& value) {
  { mwperf::adapt_portable_payload(value) } ->
      std::same_as<mwperf::Result<mwperf::PortablePlugPayload>>;
};

template <typename T>
concept HasProviderIdentityMember = requires(T value) { value.provider; };
template <typename T>
concept HasProducerModeMember = requires(T value) { value.producer_mode; };
template <typename T>
concept HasRuntimeAccessMember = requires(T value) { value.runtime_access; };
template <typename T>
concept HasRequestDigestMember = requires(T value) { value.request_digest; };
template <typename T>
concept HasExecutableMember = requires(T value) { value.executable; };
template <typename T>
concept HasCallbackMember = requires(T value) { value.callback; };
template <typename T>
concept HasPublicArtifactMember = requires(T value) { value.artifact; };
template <typename T>
concept ExposesAdaptableArtifact = requires(const T& value) {
  { mwperf::adapt_portable_payload(value.artifact) } ->
      std::same_as<mwperf::Result<mwperf::PortablePlugPayload>>;
};

}  // namespace

mwperf::testing::C15GoldenSourceV1
mwperf::testing::make_three_bin_c15_golden_source_v1() {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.golden-authentic-three-bin", mwperf::MasterSeed(0xC15003U));
  const auto candidate = make_bound_built_fixture(fixture);
  auto bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{candidate.result});
  REQUIRE(bytes);
  auto parsed = mwperf::parse_surrogate_build_result(bytes.value(),
                                                     generous_parse_limits());
  REQUIRE(parsed);
  const auto* parsed_built =
      std::get_if<mwperf::BuiltSurrogateResultV1>(&parsed.value());
  REQUIRE(parsed_built != nullptr);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), fixture.request, fixture.manifest, fixture.contract,
      candidate.validated_report);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message + " at " +
                        validated.error().json_pointer.value_or("<none>")));
  REQUIRE(validated);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
  REQUIRE(portable);
  return {"three_bin", *parsed_built, portable.value().value()};
}

static_assert(std::variant_size_v<mwperf::ArtifactPayloadV1> == 7U);
static_assert(std::variant_size_v<mwperf::FiniteLawTableAlternativeV1> == 6U);
static_assert(std::variant_size_v<mwperf::SurrogateBuildResultV1> == 3U);
static_assert(std::variant_size_v<mwperf::PortablePlugPayloadValueV1> == 7U);
static_assert(mwperf::all_semantic_tags_v1().size() == 9U);
static_assert(mwperf::all_runtime_access_tags_v1().size() == 7U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::ConstructionMethodV1::precomputed) +
                  1U ==
              5U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::ProducerModeV1::local_executable_builder) +
                  1U ==
              3U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::PayloadClassTagV1::
                      empirical_finite_window_response_v1) +
                  1U ==
              8U);
static_assert(std::variant_size_v<mwperf::RealizedReferenceV1> == 25U);
static_assert(mwperf::all_metric_support_roles_v1().size() == 25U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::InternalReferencePurposeV1::error_object) +
                  1U ==
              63U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::ArtifactReferenceKindV1::physical_transfer_evidence) +
                  1U ==
              24U);
static_assert(static_cast<std::uint8_t>(
                  mwperf::ArtifactDiagnosticScopeV1::physical_fidelity) +
                  1U ==
              9U);
static_assert(!std::same_as<mwperf::ConstructionMethodV1,
                            mwperf::ProducerModeV1>);
static_assert(!std::same_as<mwperf::ConstructionMethodV1,
                            mwperf::SemanticTagV1>);
static_assert(!std::same_as<mwperf::ProducerModeV1,
                            mwperf::RuntimeAccessTagV1>);
static_assert(!std::default_initializable<mwperf::RawResponseProductId>);
static_assert(!std::default_initializable<mwperf::NominalResponseProductId>);
static_assert(!std::default_initializable<mwperf::ProjectionCenterProductId>);
static_assert(!std::default_initializable<mwperf::ProjectedMeanProductId>);
static_assert(!std::default_initializable<mwperf::RecodedResponseProductId>);
static_assert(!std::constructible_from<mwperf::RawResponseProductId,
                                       mwperf::NominalResponseProductId>);
static_assert(!std::constructible_from<mwperf::RecodedResponseProductId,
                                       mwperf::ProjectedMeanProductId>);
static_assert(!std::default_initializable<mwperf::ValidatedSurrogateArtifact>);
static_assert(!std::default_initializable<mwperf::ValidatedSurrogateBuildResult>);
static_assert(!std::default_initializable<mwperf::PortablePlugPayload>);
static_assert(AdaptableArgument<mwperf::ValidatedSurrogateArtifact>);
static_assert(!AdaptableArgument<mwperf::SurrogateArtifactV1>);
static_assert(!AdaptableArgument<mwperf::SurrogateBuildResultV1>);
static_assert(!AdaptableArgument<mwperf::RawResponseProductV1>);
static_assert(!AdaptableArgument<mwperf::ProjectedMeanProductV1>);
static_assert(!std::convertible_to<mwperf::ValidatedSurrogateBuildResult,
                                   mwperf::ValidatedSurrogateArtifact>);
static_assert(!HasPublicArtifactMember<mwperf::ValidatedBuiltResultV1>);
static_assert(!HasPublicArtifactMember<
              mwperf::ValidatedSurrogateBuildResultValueV1>);
static_assert(!ExposesAdaptableArtifact<mwperf::ValidatedBuiltResultV1>);
static_assert(!ExposesAdaptableArtifact<mwperf::ValidatedSurrogateBuildResult>);
static_assert(ExposesAdaptableArtifact<mwperf::RealizedBuiltCapabilitiesV1>);
static_assert(!HasProviderIdentityMember<
              mwperf::testing::ModeErasedLawProjectionV1>);
static_assert(!HasProducerModeMember<
              mwperf::testing::ModeErasedLawProjectionV1>);
static_assert(!HasRuntimeAccessMember<
              mwperf::testing::ModeErasedLawProjectionV1>);
static_assert(!HasRequestDigestMember<
              mwperf::testing::ModeErasedLawProjectionV1>);
static_assert(!HasExecutableMember<
              mwperf::testing::ModeErasedLawProjectionV1>);
static_assert(!HasCallbackMember<mwperf::PortablePlugPayloadValueV1>);
using C15RequestFactorySignature = mwperf::Result<mwperf::SurrogateBuildRequest> (*)(
    const mwperf::ValidatedProviderManifest&,
    const mwperf::FrameworkProblemView&,
    const mwperf::AcceptedCapabilityContract&,
    const mwperf::ValidatedSurrogateParameters&,
    const mwperf::ConstructionBudget&, const mwperf::MasterSeed&);
static_assert(std::same_as<decltype(&mwperf::make_surrogate_build_request),
                           C15RequestFactorySignature>);

TEST_CASE("C15 provider classification tuple is closed and independently bound",
          "[c15][unit]") {
  struct Case final {
    mwperf::ConstructionMethodV1 method;
    mwperf::ProducerModeV1 mode;
  };
  const std::array cases{
      Case{mwperf::ConstructionMethodV1::closed_form,
           mwperf::ProducerModeV1::inline_immediate},
      Case{mwperf::ConstructionMethodV1::engineered_deterministic,
           mwperf::ProducerModeV1::in_process_builder},
      Case{mwperf::ConstructionMethodV1::engineered_deterministic,
           mwperf::ProducerModeV1::local_executable_builder},
      Case{mwperf::ConstructionMethodV1::engineered_hybrid,
           mwperf::ProducerModeV1::local_executable_builder},
      Case{mwperf::ConstructionMethodV1::sampled_offline,
           mwperf::ProducerModeV1::in_process_builder},
      Case{mwperf::ConstructionMethodV1::precomputed,
           mwperf::ProducerModeV1::inline_immediate}};
  for (std::size_t index = 0U; index < cases.size(); ++index) {
    auto manifest = provider_manifest(
        cases[index].method, cases[index].mode,
        "c15.fixture.provider." + std::to_string(index));
    auto validated = mwperf::validate_provider_manifest(manifest);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
    CHECK(validated.value().value().construction_method == cases[index].method);
    CHECK(validated.value().value().producer_mode == cases[index].mode);
    CHECK(validated.value().value().deployed_semantic_tag ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(validated.value().value().runtime_access_tag ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  }
}

TEST_CASE("C15 manifest applicability is exactly the five released optimizer pairs",
          "[c15][negative]") {
  const std::vector<mwperf::SchedulerConstraintPairV1> all_pairs{
      {mwperf::ServiceFamily::crossbar_matching,
       mwperf::OptimizerId::hungarian_exact},
      {mwperf::ServiceFamily::nonoverlapping_intervals,
       mwperf::OptimizerId::weighted_interval_dp_exact},
      {mwperf::ServiceFamily::node_exclusive_matching,
       mwperf::OptimizerId::edmonds_blossom_exact},
      {mwperf::ServiceFamily::pairwise_conflicts,
       mwperf::OptimizerId::mwis_branch_memo_exact},
      {mwperf::ServiceFamily::resource_packing,
       mwperf::OptimizerId::binary_packing_memo_exact}};

  auto complete = provider_manifest();
  complete.optimizer_constraint_applicability.scheduler_optimizer_pairs =
      all_pairs;
  reseal_manifest(complete);
  REQUIRE(mwperf::validate_provider_manifest(complete));

  SECTION("mismatched pair") {
    auto value = complete;
    value.optimizer_constraint_applicability.scheduler_optimizer_pairs[0U]
        .optimizer = mwperf::OptimizerId::weighted_interval_dp_exact;
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.invalid_applicability");
  }
  SECTION("unsorted pairs") {
    auto value = complete;
    std::reverse(
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .begin(),
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .end());
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.noncanonical_applicability");
  }
  SECTION("duplicate pair") {
    auto value = complete;
    value.optimizer_constraint_applicability.scheduler_optimizer_pairs.insert(
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .begin() + 1,
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .front());
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.noncanonical_applicability");
  }
  SECTION("unknown family") {
    auto value = complete;
    value.optimizer_constraint_applicability.scheduler_optimizer_pairs[0U]
        .service_family = static_cast<mwperf::ServiceFamily>(255U);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.unknown_manifest_enum");
  }
  SECTION("wrong timing") {
    auto value = complete;
    value.optimizer_constraint_applicability.timing_conventions.clear();
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.invalid_applicability");
  }
}

TEST_CASE("C15 nested manifest enums are closed before canonical encoding",
          "[c15][negative]") {
  enum class NestedEnumField {
    service_family,
    optimizer,
    timing,
    point_deployment,
    coefficient_completion,
    projection,
    recoding,
    evidence_roles,
  };
  struct Case final {
    NestedEnumField field;
    const char* name;
  };
  const std::array cases{
      Case{NestedEnumField::service_family, "optimizer service family"},
      Case{NestedEnumField::optimizer, "optimizer identifier"},
      Case{NestedEnumField::timing, "timing convention"},
      Case{NestedEnumField::point_deployment, "point deployment policy"},
      Case{NestedEnumField::coefficient_completion,
           "coefficient completion policy"},
      Case{NestedEnumField::projection, "projection policy"},
      Case{NestedEnumField::recoding, "recoding policy"},
      Case{NestedEnumField::evidence_roles, "evidence-role policy"},
  };
  const auto invalidate = [](auto& value, const NestedEnumField field) {
    switch (field) {
      case NestedEnumField::service_family:
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .front()
            .service_family = static_cast<mwperf::ServiceFamily>(255U);
        return;
      case NestedEnumField::optimizer:
        value.optimizer_constraint_applicability.scheduler_optimizer_pairs
            .front()
            .optimizer = static_cast<mwperf::OptimizerId>(255U);
        return;
      case NestedEnumField::timing:
        value.optimizer_constraint_applicability.timing_conventions.front() =
            static_cast<mwperf::TimingConvention>(255U);
        return;
      case NestedEnumField::point_deployment:
        value.scientific_construction_policy_schema.point_deployment.front() =
            static_cast<mwperf::PointDeploymentPolicyV1>(255U);
        return;
      case NestedEnumField::coefficient_completion:
        value.scientific_construction_policy_schema.coefficient_completion
            .front() =
            static_cast<mwperf::CoefficientCompletionPolicyV1>(255U);
        return;
      case NestedEnumField::projection:
        value.scientific_construction_policy_schema.projection.front() =
            static_cast<mwperf::ProjectionPolicyV1>(255U);
        return;
      case NestedEnumField::recoding:
        value.scientific_construction_policy_schema.recoding.front() =
            static_cast<mwperf::RecodingPolicyV1>(255U);
        return;
      case NestedEnumField::evidence_roles:
        value.scientific_construction_policy_schema.evidence_roles.front() =
            static_cast<mwperf::EvidenceRolePolicyV1>(255U);
        return;
    }
  };

  const auto baseline = provider_manifest();
  const auto baseline_validation =
      mwperf::validate_provider_manifest(baseline);
  REQUIRE(baseline_validation);

  for (const auto& test : cases) {
    DYNAMIC_SECTION(test.name) {
      auto manifest = baseline;
      invalidate(manifest, test.field);
      CHECK_FALSE(mwperf::canonical_provider_manifest_bytes_v1(manifest));
      CHECK_FALSE(mwperf::digest_provider_manifest_v1(manifest));
      CHECK_FALSE(mwperf::validate_provider_manifest(manifest));

      auto projection =
          baseline_validation.value().scientific_projection();
      invalidate(projection, test.field);
      CHECK_FALSE(
          mwperf::canonical_provider_scientific_contract_bytes_v1(projection));
      CHECK_FALSE(
          mwperf::digest_provider_scientific_contract_v1(projection));
    }
  }
}

TEST_CASE("C15 manifest rejects malformed closed classifications and transport",
          "[c15][negative]") {
  SECTION("required method counter policy is canonical and scientific") {
    auto value = provider_manifest();
    const auto baseline = mwperf::validate_provider_manifest(value);
    REQUIRE(baseline);
    value.required_method_counters = {
        {"integration_evaluations", mwperf::BigNat{3U}}};
    reseal_manifest(value);
    const auto changed = mwperf::validate_provider_manifest(value);
    REQUIRE(changed);
    CHECK(changed.value().scientific_contract_digest() !=
          baseline.value().scientific_contract_digest());
  }
  SECTION("required method counter names are sorted and unique") {
    auto value = provider_manifest();
    value.required_method_counters = {
        {"refinement_rounds", mwperf::BigNat{1U}},
        {"integration_evaluations", mwperf::BigNat{1U}}};
    reseal_manifest(value);
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("required method counter names use the portable identifier grammar") {
    auto value = provider_manifest();
    value.required_method_counters = {
        {"integration evaluations", mwperf::BigNat{1U}}};
    reseal_manifest(value);
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("common and transport measurements are reserved") {
    for (const std::string name : {"optimizer_calls", "result_bytes",
                                   "stderr_bytes", "elapsed_wall_time"}) {
      auto value = provider_manifest();
      value.required_method_counters = {
          {name, mwperf::BigNat{1U}}};
      reseal_manifest(value);
      auto checked = mwperf::validate_provider_manifest(value);
      REQUIRE_FALSE(checked);
      CHECK(checked.error().code ==
            "c15.noncanonical_required_method_counters");
    }
  }
  SECTION("unknown construction enum") {
    auto value = provider_manifest();
    value.construction_method =
        static_cast<mwperf::ConstructionMethodV1>(255U);
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("precomputed is immediate only") {
    auto value = provider_manifest(mwperf::ConstructionMethodV1::precomputed,
                                   mwperf::ProducerModeV1::in_process_builder);
    auto digest = mwperf::digest_provider_manifest_v1(value);
    REQUIRE(digest);
    value.manifest_digest = std::move(digest).value();
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("protocol version set is exact and duplicate free") {
    auto value = provider_manifest();
    value.supported_artifact_versions = {1U, 1U};
    auto digest = mwperf::digest_provider_manifest_v1(value);
    REQUIRE(digest);
    value.manifest_digest = std::move(digest).value();
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("payload and access cannot be inferred from construction") {
    auto value = provider_manifest(mwperf::ConstructionMethodV1::sampled_offline,
                                   mwperf::ProducerModeV1::in_process_builder);
    value.runtime_access_tag =
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler;
    auto digest = mwperf::digest_provider_manifest_v1(value);
    REQUIRE(digest);
    value.manifest_digest = std::move(digest).value();
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("manifest self digest is mandatory") {
    auto value = provider_manifest();
    value.manifest_digest = digest_of("wrong-manifest");
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }
  SECTION("local declaration rejects open argument grammar") {
    auto value = provider_manifest(
        mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::local_executable_builder);
    REQUIRE(value.local_executable.has_value());
    value.local_executable->fixed_argument_template = {
        "--request", "{request_path}", "--result", "{result_path}",
        "{arbitrary_path}"};
    auto digest = mwperf::digest_provider_manifest_v1(value);
    REQUIRE(digest);
    value.manifest_digest = std::move(digest).value();
    CHECK_FALSE(mwperf::validate_provider_manifest(value));
  }

  SECTION("local declaration accepts only the closed direct argv tuple") {
    const std::array<std::vector<std::string>, 8U> forbidden{{
        {"--request", "{request_path}"},
        {"--result", "{result_path}", "--request", "{request_path}"},
        {"--request", "{request_path}", "--result", "{result_path}",
         "--shell=/bin/sh"},
        {"--request", "{request_path}", "--result", "{result_path}",
         "--network"},
        {"--request", "{request_path}", "--result", "{result_path}",
         "--daemon"},
        {"--request", "{request_path}", "--result", "{result_path}",
         "--credential=secret"},
        {"--request", "${REQUEST}", "--result", "{result_path}"},
        {"sh", "-c", "builder {request_path} > {result_path}"},
    }};
    for (const auto& arguments : forbidden) {
      auto value = provider_manifest(
          mwperf::ConstructionMethodV1::engineered_deterministic,
          mwperf::ProducerModeV1::local_executable_builder);
      REQUIRE(value.local_executable.has_value());
      value.local_executable->fixed_argument_template = arguments;
      reseal_manifest(value);
      CHECK_FALSE(mwperf::validate_provider_manifest(value));
    }
  }
}

TEST_CASE("C15 manifest preserves the authoritative C14 arrival assumption shape",
          "[c15][negative]") {
  const auto rejects = [](const mwperf::ArrivalAssumptionV1& assumption) {
    auto value = provider_manifest();
    value.target_and_arrival_scientific_prerequisites.arrival_assumptions = {
        assumption};
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    CHECK_FALSE(checked);
    if (checked) return false;
    CHECK(checked.error().code == "c15.invalid_arrival_prerequisite");
    return true;
  };
  const auto accepts = [](const mwperf::ArrivalAssumptionV1& assumption) {
    auto value = provider_manifest();
    value.target_and_arrival_scientific_prerequisites.arrival_assumptions = {
        assumption};
    reseal_manifest(value);
    return static_cast<bool>(mwperf::validate_provider_manifest(value));
  };

  CHECK(rejects({mwperf::ArrivalNeedKindV1::arrival_moment,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 mwperf::BigNat{0U}, true, true, std::nullopt,
                 std::nullopt, std::nullopt}));
  CHECK(rejects({mwperf::ArrivalNeedKindV1::target_intensity,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, true, false, std::nullopt,
                 std::nullopt, std::nullopt}));
  CHECK(rejects({mwperf::ArrivalNeedKindV1::target_intensity,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, false, true, std::nullopt,
                 std::nullopt, std::nullopt}));

  for (const auto kind : {
           mwperf::ArrivalNeedKindV1::full_common_batch,
           mwperf::ArrivalNeedKindV1::predictive_phase,
           mwperf::ArrivalNeedKindV1::sequential_law,
           mwperf::ArrivalNeedKindV1::entrance_labels,
           mwperf::ArrivalNeedKindV1::finite_support,
           mwperf::ArrivalNeedKindV1::exact_iid_late}) {
    CAPTURE(kind);
    CHECK(rejects({kind, mwperf::ArrivalCapabilityUseV1::runtime,
                   mwperf::CapabilityProvisionNeedV1::portable,
                   std::nullopt, false, true, std::nullopt,
                   std::nullopt, std::nullopt}));
  }

  CHECK(rejects({mwperf::ArrivalNeedKindV1::transform,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, true, true,
                 mwperf::TransformKind::exact_pgf,
                 mwperf::DistributionScope::joint_vector,
                 mwperf::ExactArgumentDomain{rational(1, 2),
                                             rational(1, 2), true,
                                             false}}));
  CHECK(rejects({mwperf::ArrivalNeedKindV1::transform,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, true, true,
                 mwperf::TransformKind::exact_pgf,
                 mwperf::DistributionScope::joint_vector,
                 mwperf::ExactArgumentDomain{rational(1, 2),
                                             rational(1, 2), false,
                                             true}}));
  CHECK(accepts({mwperf::ArrivalNeedKindV1::arrival_moment,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 mwperf::BigNat{1U}, true, true, std::nullopt,
                 std::nullopt, std::nullopt}));
  CHECK(accepts({mwperf::ArrivalNeedKindV1::transform,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, true, true,
                 mwperf::TransformKind::exact_pgf,
                 mwperf::DistributionScope::joint_vector,
                 mwperf::ExactArgumentDomain{rational(1, 2),
                                             rational(1, 2), true,
                                             true}}));
  CHECK(accepts({mwperf::ArrivalNeedKindV1::full_common_batch,
                 mwperf::ArrivalCapabilityUseV1::runtime,
                 mwperf::CapabilityProvisionNeedV1::portable,
                 std::nullopt, true, false, std::nullopt,
                 std::nullopt, std::nullopt}));
}

TEST_CASE("C15 manifest rejects every undeclared payload semantic access tuple",
          "[c15][negative]") {
  struct InvalidTuple final {
    mwperf::PayloadClassTagV1 payload;
    mwperf::SemanticTagV1 semantic;
    mwperf::RuntimeAccessTagV1 access;
  };
  const std::array cases{
      InvalidTuple{
          mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
          mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family},
      InvalidTuple{
          mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
          mwperf::SemanticTagV1::response_envelope_law,
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family},
      InvalidTuple{
          mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
          mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::direct_metric_decoder},
      InvalidTuple{
          mwperf::PayloadClassTagV1::finite_law_tables_v1,
          mwperf::SemanticTagV1::scalar_backlog_response,
          mwperf::RuntimeAccessTagV1::finite_enumerated_row},
      InvalidTuple{
          mwperf::PayloadClassTagV1::finite_law_tables_v1,
          mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::analytic_transform},
      InvalidTuple{
          mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
          mwperf::SemanticTagV1::response_envelope_law,
          mwperf::RuntimeAccessTagV1::normalized_conditional_sampler},
      InvalidTuple{
          mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
          mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::finite_enumerated_row},
      InvalidTuple{
          mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
          mwperf::SemanticTagV1::scalar_backlog_response,
          mwperf::RuntimeAccessTagV1::analytic_transform},
      InvalidTuple{
          mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
          mwperf::SemanticTagV1::response_envelope_law,
          mwperf::RuntimeAccessTagV1::direct_metric_decoder},
      InvalidTuple{
          mwperf::PayloadClassTagV1::direct_metric_payload_v1,
          mwperf::SemanticTagV1::scalar_backlog_response,
          mwperf::RuntimeAccessTagV1::direct_metric_decoder},
      InvalidTuple{
          mwperf::PayloadClassTagV1::direct_metric_payload_v1,
          mwperf::SemanticTagV1::direct_metric_decoder,
          mwperf::RuntimeAccessTagV1::analytic_transform}};

  for (std::size_t index = 0U; index < cases.size(); ++index) {
    auto value = provider_manifest(
        mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder,
        "c15.fixture.invalid-tuple." + std::to_string(index));
    value.payload_class = {cases[index].payload, 1U};
    value.deployed_semantic_tag = cases[index].semantic;
    value.runtime_access_tag = cases[index].access;
    reseal_manifest(value);
    auto checked = mwperf::validate_provider_manifest(value);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c15.incompatible_payload_access");
  }
}

TEST_CASE("C15 fixture registry rejects conflicting identity tuples and defaults",
          "[c15][negative]") {
  // F-C15-01 intentionally validates one manifest in isolation.  Static
  // registry-set uniqueness is owned by C16; this fixture-only set check locks
  // the C15 handoff rule without introducing ambient production state.
  auto first = provider_manifest(
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, "c15.fixture.same");
  auto same = first;
  CHECK(manifest_identity_tuples_unique(
      std::array<mwperf::SurrogateProviderManifestV1, 2U>{first, same}));

  auto tuple_collision = first;
  tuple_collision.producer_mode = mwperf::ProducerModeV1::inline_immediate;
  reseal_manifest(tuple_collision);
  CHECK_FALSE(manifest_identity_tuples_unique(
      std::array<mwperf::SurrogateProviderManifestV1, 2U>{first,
                                                          tuple_collision}));

  auto default_collision = first;
  default_collision.default_selection = true;
  reseal_manifest(default_collision);
  CHECK_FALSE(manifest_identity_tuples_unique(
      std::array<mwperf::SurrogateProviderManifestV1, 2U>{first,
                                                          default_collision}));
}

TEST_CASE("C15 manifest binds exact analytic and runtime registry metadata",
          "[c15][negative]") {
  const auto registered_manifest = [](
      const mwperf::PayloadClassTagV1 payload,
      const mwperf::RuntimeAccessTagV1 access) {
    auto clause = scalar_manifest().clauses().front();
    clause.payload_class = {payload, 1U};
    clause.semantic = mwperf::SemanticTagV1::stationary_marked_edge;
    clause.runtime_access = access;
    clause.required_roles.erase(
        std::remove_if(
            clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& requirement) {
              return requirement.role !=
                         mwperf::MetricSupportRoleV1::deployed_payload &&
                     requirement.role != mwperf::MetricSupportRoleV1::
                                             reported_validity_or_lift_evidence;
            }),
        clause.required_roles.end());
    auto stationary_law = role(
        mwperf::MetricSupportRoleV1::stationary_marked_edge_law,
        mwperf::MetricTargetScopeV1::ordered_metric_targets,
        mwperf::MetricResultScopeV1::surrogate_law,
        mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
    stationary_law.role_relations = {
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::MetricSupportRoleV1::deployed_payload},
        {mwperf::MetricRoleRelationKindV1::evidence,
         mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence}};
    stationary_law.internal_relations = {
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::state_codec},
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::mark_codec},
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::configured_arrival_binding},
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::selection_binding}};
    clause.required_roles.push_back(std::move(stationary_law));
    const auto validity = std::find_if(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const auto& requirement) {
          return requirement.role == mwperf::MetricSupportRoleV1::
                                         reported_validity_or_lift_evidence;
        });
    REQUIRE(validity != clause.required_roles.end());
    validity->target_scope =
        mwperf::MetricTargetScopeV1::ordered_metric_targets;
    if (access ==
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler) {
      clause.solver_route = mwperf::SolverRegimeV1::monte_carlo;
      clause.requested_accuracy = mwperf::MonteCarloAccuracyV1{
          mwperf::BigNat{64U}, rational(19, 20),
          mwperf::StatisticalIntervalKindV1::hoeffding,
          mwperf::StatisticalEstimandKindV1::bounded_iid,
          rational(0, 1), rational(1, 1)};
    }
    auto result =
        mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
    REQUIRE(result);
    return std::move(result).value();
  };
  auto analytic = provider_manifest(
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.registered-analytic",
      registered_manifest(
          mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
          mwperf::RuntimeAccessTagV1::analytic_transform));
  analytic.payload_class = {
      mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1, 1U};
  analytic.deployed_semantic_tag =
      mwperf::SemanticTagV1::stationary_marked_edge;
  analytic.runtime_access_tag = mwperf::RuntimeAccessTagV1::analytic_transform;
  analytic.scientific_construction_policy_schema.registered_analytic_families =
      {{"fixture.family", 1U, "fixture.parameters", 1U, "fixture.domain",
        1U}};
  reseal_manifest(analytic);
  REQUIRE(mwperf::validate_provider_manifest(analytic));

  const auto valid_registration =
      analytic.scientific_construction_policy_schema
          .registered_analytic_families.front();
  for (const std::size_t mutation : {0U, 1U, 2U, 3U, 4U, 5U}) {
    auto bad = analytic;
    auto& registration = bad.scientific_construction_policy_schema
                             .registered_analytic_families.front();
    switch (mutation) {
      case 0U: registration.family_id.clear(); break;
      case 1U: registration.family_version = 0U; break;
      case 2U: registration.parameter_schema_id.clear(); break;
      case 3U: registration.parameter_schema_version = 0U; break;
      case 4U: registration.domain_schema_id.clear(); break;
      case 5U: registration.domain_schema_version = 0U; break;
      default: FAIL("unreachable registration mutation");
    }
    reseal_manifest(bad);
    CHECK_FALSE(mwperf::validate_provider_manifest(bad));
  }
  CHECK(valid_registration.family_id == "fixture.family");

  auto recipe = provider_manifest(
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.registered-recipe",
      registered_manifest(
          mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
          mwperf::RuntimeAccessTagV1::normalized_conditional_sampler));
  recipe.payload_class = {
      mwperf::PayloadClassTagV1::registered_runtime_recipe_v1, 1U};
  recipe.deployed_semantic_tag =
      mwperf::SemanticTagV1::stationary_marked_edge;
  recipe.runtime_access_tag =
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler;
  recipe.scientific_construction_policy_schema.registered_runtime_recipes = {
      {"fixture.recipe", 1U, "fixture.parameters", 1U,
       "fixture.state-codec", 1U, "fixture.mark-codec", 1U}};
  reseal_manifest(recipe);
  REQUIRE(mwperf::validate_provider_manifest(recipe));
  auto bad_recipe = recipe;
  bad_recipe.scientific_construction_policy_schema.registered_runtime_recipes
      .front()
      .state_codec_schema_version = 0U;
  reseal_manifest(bad_recipe);
  CHECK_FALSE(mwperf::validate_provider_manifest(bad_recipe));
}

TEST_CASE("C15 manifest binds one conformance-report anchor per evidence schema",
          "[c15][negative]") {
  const auto valid = provider_manifest();
  REQUIRE(mwperf::validate_provider_manifest(valid));
  REQUIRE(valid.allowed_family_evidence_schemas.size() == 1U);
  REQUIRE(valid.family_evidence_conformance_report_anchors.size() == 1U);
  const auto& schema = valid.allowed_family_evidence_schemas.front();
  const auto& anchor =
      valid.family_evidence_conformance_report_anchors.front();
  CHECK(anchor.family_evidence_schema_id == schema.schema_id);
  CHECK(anchor.family_evidence_schema_version == schema.schema_version);
  CHECK(anchor.report_schema_version == 1U);
  CHECK(anchor.report_id == label("c15.conformance"));
  CHECK(anchor.report_digest == digest_of("conformance-report"));

  for (const std::size_t mutation : {0U, 1U, 2U, 3U, 4U, 5U}) {
    auto bad = valid;
    switch (mutation) {
      case 0U:
        bad.family_evidence_conformance_report_anchors.clear();
        break;
      case 1U:
        bad.family_evidence_conformance_report_anchors.push_back(anchor);
        break;
      case 2U:
        bad.family_evidence_conformance_report_anchors.front()
            .family_evidence_schema_id = "other.schema";
        break;
      case 3U:
        bad.family_evidence_conformance_report_anchors.front()
            .family_evidence_schema_version = 2U;
        break;
      case 4U:
        bad.family_evidence_conformance_report_anchors.front()
            .report_schema_version = 0U;
        break;
      case 5U:
        bad.family_evidence_conformance_report_anchors.front().report_digest =
            zero_digest();
        break;
      default: FAIL("unreachable conformance-anchor mutation");
    }
    reseal_manifest(bad);
    CHECK_FALSE(mwperf::validate_provider_manifest(bad));
  }
}

TEST_CASE("C15 F02 problem view is immutable complete and order bound",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c15.fixture.group"))};
  auto first = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  auto second = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(first);
  REQUIRE(second);
  CHECK(first.value() == second.value());
  auto first_bytes =
      mwperf::canonical_framework_problem_view_bytes_v1(first.value());
  auto second_bytes =
      mwperf::canonical_framework_problem_view_bytes_v1(second.value());
  REQUIRE(first_bytes);
  REQUIRE(second_bytes);
  CHECK(first_bytes.value() == second_bytes.value());
  REQUIRE(first.value().queues().size() == 2U);
  CHECK(first.value().queues().front().queue_id == queue_id("q0"));
  CHECK(first.value().queues()[1U].queue_id == queue_id("q1"));
  CHECK(first.value().target_selection() == targets);
  CHECK(first.value().timing() ==
        mwperf::TimingConvention::early_service_late_admission);
  CHECK(first.value().configured_arrival().version() == 1U);

  auto wrong_targets = targets;
  wrong_targets.ordered_targets = {queue_id("q1")};
  CHECK_FALSE(mwperf::build_framework_problem_view(
      input.instance, *input.arrival, wrong_targets));
  auto duplicate_targets = targets;
  duplicate_targets.ordered_targets.push_back(queue_id("q0"));
  CHECK_FALSE(mwperf::build_framework_problem_view(
      input.instance, *input.arrival, duplicate_targets));
}

TEST_CASE("C32 physical trajectory identity excludes analysis authority",
          "[c32][cp09][identity][property]") {
  const auto unique = make_protocol_input_fixture(
      R"json({"kind":"stationary_unique","parameters":{}})json");
  const auto selected_class = make_protocol_input_fixture(
      R"json({"kind":"stationary_class","parameters":{"class_id":"class-a"}})json");
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c32.physical-trajectory"))};
  auto unique_view = mwperf::build_framework_problem_view(
      unique.instance, *unique.arrival, targets);
  auto class_view = mwperf::build_framework_problem_view(
      selected_class.instance, *selected_class.arrival, targets);
  REQUIRE(unique_view);
  REQUIRE(class_view);
  CHECK(unique_view.value().canonical_digest() !=
        class_view.value().canonical_digest());
  auto unique_physical = mwperf::canonical_physical_trajectory_digest_v1(
      unique_view.value());
  auto class_physical = mwperf::canonical_physical_trajectory_digest_v1(
      class_view.value());
  REQUIRE(unique_physical);
  REQUIRE(class_physical);
  CHECK(unique_physical.value() == class_physical.value());

  const auto reversed_priority = make_protocol_input_fixture(
      R"json({"kind":"stationary_unique","parameters":{}})json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q1","q0"],"max_search_states":null}})json");
  auto reversed_view = mwperf::build_framework_problem_view(
      reversed_priority.instance, *reversed_priority.arrival, targets);
  REQUIRE(reversed_view);
  auto reversed_physical = mwperf::canonical_physical_trajectory_digest_v1(
      reversed_view.value());
  REQUIRE(reversed_physical);
  CHECK(reversed_physical.value() != unique_physical.value());
}

TEST_CASE("C15 F02 canonicalizes all five scheduler constraint geometries",
          "[c15][property]") {
  static constexpr std::array<std::string_view, 5U> schedulers{
      R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"}]},"priority":["q0","q1"]}})json",
      R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2}]},"priority":["q0","q1"]}})json",
      R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"w","v":"x"}]},"priority":["q0","q1"]}})json",
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],"max_search_states":null}})json",
      R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[2]}]},"priority":["q0","q1"],"max_search_states":null}})json"};
  std::vector<mwperf::FrameworkProblemViewDigest> digests;
  for (std::size_t index = 0U; index < schedulers.size(); ++index) {
    const auto input = make_protocol_input_fixture(
        R"json({"kind":"stationary_unique","parameters":{}})json",
        R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
        schedulers[index]);
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(label("c15.geometry"))};
    auto first = mwperf::build_framework_problem_view(
        input.instance, *input.arrival, targets);
    auto second = mwperf::build_framework_problem_view(
        input.instance, *input.arrival, targets);
    REQUIRE(first);
    REQUIRE(second);
    auto first_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(first.value());
    auto second_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(second.value());
    REQUIRE(first_bytes);
    REQUIRE(second_bytes);
    CHECK(first_bytes.value() == second_bytes.value());
    CHECK(first.value().canonical_digest() ==
          second.value().canonical_digest());
    CHECK(first.value().constraint_geometry().index() == index);
    digests.push_back(first.value().canonical_digest());
  }
  for (std::size_t left = 0U; left < digests.size(); ++left) {
    for (std::size_t right = left + 1U; right < digests.size(); ++right) {
      CHECK_FALSE(digests[left] == digests[right]);
    }
  }
}

TEST_CASE("C15 F02 binds every normalized analysis selection alternative",
          "[c15][property]") {
  struct SelectionCase final {
    std::string_view selection;
    std::string_view metrics;
    std::size_t expected_index;
  };
  static constexpr std::string_view stationary_metric =
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json";
  static constexpr std::string_view transient_metric =
      R"json([{"id":"law","kind":"transient_backlog_law","parameters":{"horizons":[0,1]}}])json";
  const std::array cases{
      SelectionCase{
          R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":0.25,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{}},{"probability":0.75,"backlog":[{"queue_id":"q1","value":0},{"queue_id":"q0","value":0}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{}}]}}})json",
          transient_metric, 0U},
      SelectionCase{
          R"json({"kind":"stationary_unique","parameters":{}})json",
          stationary_metric, 1U},
      SelectionCase{
          R"json({"kind":"stationary_class","parameters":{"class_id":"class-a"}})json",
          stationary_metric, 2U},
      SelectionCase{
          R"json({"kind":"stationary_mixture","parameters":{"components":[{"class_id":"class-a","probability":0.3333333333333333},{"class_id":"class-b","probability":0.6666666666666666}]}})json",
          stationary_metric, 3U},
      SelectionCase{
          R"json({"kind":"fixed_point","parameters":{"mode":"unique"}})json",
          stationary_metric, 4U},
      SelectionCase{
          R"json({"kind":"fixed_point","parameters":{"mode":"id","solution_id":"root-a"}})json",
          stationary_metric, 5U}};

  std::vector<mwperf::Digest256> digests;
  for (const auto& item : cases) {
    const auto input = make_protocol_input_fixture(item.selection,
                                                   item.metrics);
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(label("c15.fixture.selection"))};
    auto first = mwperf::build_framework_problem_view(
        input.instance, *input.arrival, targets);
    auto repeat = mwperf::build_framework_problem_view(
        input.instance, *input.arrival, targets);
    REQUIRE(first);
    REQUIRE(repeat);
    CHECK(first.value().analysis_selection().index() == item.expected_index);
    CHECK(first.value().canonical_digest() == repeat.value().canonical_digest());
    auto first_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(first.value());
    auto repeat_bytes =
        mwperf::canonical_framework_problem_view_bytes_v1(repeat.value());
    REQUIRE(first_bytes);
    REQUIRE(repeat_bytes);
    CHECK(first_bytes.value() == repeat_bytes.value());
    digests.push_back(first.value().canonical_digest().value());

    if (item.expected_index == 0U) {
      REQUIRE(first.value().initial_predictive_law().has_value());
      // C09 normalizes queue order and coalesces the two authored equal atoms;
      // C15 projects that resolved exact law, never the raw authored weights.
      REQUIRE(first.value().initial_predictive_law()->atoms.size() == 1U);
      CHECK(first.value().initial_predictive_law()->atoms.front().probability ==
            mwperf::ExactRational::one());
    }
    if (item.expected_index == 3U) {
      const auto* mixture =
          std::get_if<mwperf::PortableStationaryMixtureSelectionV1>(
              &first.value().analysis_selection());
      REQUIRE(mixture != nullptr);
      REQUIRE(mixture->components.size() == 2U);
      CHECK(mixture->components[0U].probability +
                mixture->components[1U].probability ==
            mwperf::ExactRational::one());
    }
  }
  for (std::size_t left = 0U; left < digests.size(); ++left) {
    for (std::size_t right = left + 1U; right < digests.size(); ++right) {
      CHECK(digests[left] != digests[right]);
    }
  }
}

TEST_CASE("C15 F02 rejects malformed stationary mixture selections",
          "[c15][negative]") {
  for (const std::string_view selection : {
           R"json({"kind":"stationary_mixture","parameters":{"components":[]}})json",
           R"json({"kind":"stationary_mixture","parameters":{"components":[{"class_id":"same","probability":0.5},{"class_id":"same","probability":0.5}]}})json",
           R"json({"kind":"stationary_mixture","parameters":{"components":[{"class_id":"a","probability":0.2},{"class_id":"b","probability":0.2}]}})json"}) {
    auto analysis = parse_protocol_analysis(selection);
    if (!analysis) {
      // Empty mixtures may be closed already by C03.  Duplicate and mass
      // normalization are rechecked at the immutable C15 projection boundary.
      continue;
    }
    const auto base = make_protocol_input_fixture();
    auto canonical = mwperf::canonicalize_authored_inputs(
        base.instance.authored_model(), analysis.value());
    const auto fingerprints = mwperf::fingerprint_inputs(canonical);
    auto resolved = mwperf::resolve_physical_instance(
        base.instance.authored_model(), analysis.value(), fingerprints);
    REQUIRE(resolved);
    auto compiled =
        mwperf::detail::CompiledArrivalAccess::get(resolved.value().arrival());
    REQUIRE(compiled);
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(label("c15.fixture.bad-mixture"))};
    CHECK_FALSE(mwperf::build_framework_problem_view(
        resolved.value(), *compiled.value(), targets));
  }
}

TEST_CASE("C15 F03 derives seed-free identity then seed and final digest",
          "[c15][property]") {
  const auto input = make_protocol_input_fixture();
  const auto first = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.request", mwperf::MasterSeed(0xC15001U));
  const auto repeat = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.request", mwperf::MasterSeed(0xC15001U));
  REQUIRE(mwperf::artifact::detail::verify_request_bindings_v1(
      first.request, first.manifest));
  CHECK(first.request.build_identity_digest() ==
        repeat.request.build_identity_digest());
  CHECK(first.request.build_seed() == repeat.request.build_seed());
  CHECK(first.request.request_digest() == repeat.request.request_digest());
  auto first_bytes =
      mwperf::canonical_surrogate_build_request_bytes_v1(first.request);
  auto repeated_bytes =
      mwperf::canonical_surrogate_build_request_bytes_v1(repeat.request);
  REQUIRE(first_bytes);
  REQUIRE(repeated_bytes);
  CHECK(first_bytes.value() == repeated_bytes.value());
  CHECK(first.request.build_seed().master_seed() ==
        mwperf::MasterSeed(0xC15001U));
  CHECK(first.request.build_seed().is_bound_to(
      first.request.build_identity_digest()));

  // Changing only MasterSeed cannot enter the seed-free BuildIdentity.
  const auto another_seed = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.request", mwperf::MasterSeed(0xC15002U));
  CHECK(another_seed.request.build_identity_digest() ==
        first.request.build_identity_digest());
  CHECK(another_seed.request.build_seed() != first.request.build_seed());
  CHECK(another_seed.request.request_digest() !=
        first.request.request_digest());
  REQUIRE(mwperf::artifact::detail::verify_request_bindings_v1(
      another_seed.request, another_seed.manifest));

  // An applicable zero is a real identity-bearing grant, not "unlimited".
  const auto one_draw_grant = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.request", mwperf::MasterSeed(0xC15001U), 1U);
  CHECK(one_draw_grant.request.build_identity_digest() !=
        first.request.build_identity_digest());
  CHECK(one_draw_grant.request.build_seed() != first.request.build_seed());
  CHECK(one_draw_grant.request.request_digest() !=
        first.request.request_digest());
}

TEST_CASE("C15 F03 propagates every accepted input through identity and rejects intact replay",
          "[c15][property][negative]") {
  static constexpr std::string_view selection =
      R"json({"kind":"stationary_unique","parameters":{}})json";
  static constexpr std::string_view metrics =
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json";
  const auto input = make_protocol_input_fixture(selection, metrics);
  const auto constraint_input = make_protocol_input_fixture(
      selection, metrics,
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":["q0","q1"],"max_search_states":null}})json");
  const auto arrival_input = make_protocol_input_fixture(
      selection, metrics, {},
      R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":1}],"metadata":{}})json");

  auto raw_manifest = provider_manifest(
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.identity-transitivity");
  raw_manifest.scientific_construction_policy_schema.coefficient_completion = {
      mwperf::CoefficientCompletionPolicyV1::not_applicable,
      mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points};
  reseal_manifest(raw_manifest);
  auto checked_manifest = mwperf::validate_provider_manifest(raw_manifest);
  REQUIRE(checked_manifest);
  const auto manifest = std::move(checked_manifest).value();

  const auto parameter_bytes = bytes_of("{}");
  const auto parameters = Factory::validated_parameters(
      raw_manifest.provider, raw_manifest.parameter_schema_version,
      raw_manifest.parameter_schema_digest, parameter_bytes);
  const mwperf::PreviewPoliciesV1 baseline_policies{
      mwperf::PointDeploymentPolicyV1::deploy_raw_point,
      mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
      mwperf::ProjectionPolicyV1::not_applicable,
      mwperf::RecodingPolicyV1::not_applicable,
      mwperf::EvidenceRolePolicyV1::exact_manifest_roles};
  const auto issue_request =
      [&](const ProtocolInputFixture& request_input,
          const mwperf::ConstructionBudget& budget,
          const mwperf::PreviewPoliciesV1& policies,
          const mwperf::MasterSeed master_seed,
          const std::string_view construction_group)
      -> BoundRequestFixture {
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(
            label(std::string(construction_group)))};
    auto view = mwperf::build_framework_problem_view(
        request_input.instance, *request_input.arrival, targets);
    INFO((view ? std::string{}
               : view.error().code + ": " + view.error().message));
    REQUIRE(view);
    auto budget_digest = mwperf::digest_construction_budget_v1(budget);
    REQUIRE(budget_digest);
    auto contract = Factory::accepted_contract(
        raw_manifest,
        scalar_descriptor(raw_manifest.metric_clause_upper_envelope,
                          raw_manifest.runtime_access_tag,
                          raw_manifest.provider),
        raw_manifest.metric_clause_upper_envelope, request_input.requirements,
        view.value().configured_arrival().capabilities(), {},
        {queue_id("q0")}, policies,
        {{}, std::nullopt, std::nullopt, std::nullopt},
        view.value().canonical_digest().value(),
        parameters.canonical_value_digest(), budget_digest.value());
    auto request = mwperf::make_surrogate_build_request(
        manifest, view.value(), contract, parameters, budget, master_seed);
    INFO((request ? std::string{}
                  : request.error().code + ": " +
                        request.error().message));
    REQUIRE(request);
    REQUIRE(mwperf::artifact::detail::verify_request_bindings_v1(
        request.value(), manifest));
    return {manifest, std::move(view).value(), std::move(contract),
            parameters, budget, std::move(request).value()};
  };

  constexpr std::uint64_t baseline_seed = 0xC15A01U;
  const auto baseline_budget = construction_budget();
  const auto baseline = issue_request(
      input, baseline_budget, baseline_policies,
      mwperf::MasterSeed(baseline_seed), "c15.fixture.identity-group");
  const auto built = make_bound_built_fixture(baseline);
  auto accepted = validate_bound_built(baseline, built);
  INFO((accepted ? std::string{}
                 : accepted.error().code + ": " +
                       accepted.error().message));
  REQUIRE(accepted);

  std::vector<std::pair<std::string, BoundRequestFixture>> variants;
  variants.emplace_back(
      "target selection construction-group binding",
      issue_request(input, baseline_budget, baseline_policies,
                    mwperf::MasterSeed(baseline_seed),
                    "c15.fixture.identity-other-group"));
  variants.emplace_back(
      "constraint/scheduler geometry",
      issue_request(constraint_input, baseline_budget, baseline_policies,
                    mwperf::MasterSeed(baseline_seed),
                    "c15.fixture.identity-group"));
  variants.emplace_back(
      "configured arrival",
      issue_request(arrival_input, baseline_budget, baseline_policies,
                    mwperf::MasterSeed(baseline_seed),
                    "c15.fixture.identity-group"));

  auto changed_policies = baseline_policies;
  changed_policies.coefficient_completion =
      mwperf::CoefficientCompletionPolicyV1::not_applicable;
  variants.emplace_back(
      "accepted policies",
      issue_request(input, baseline_budget, changed_policies,
                    mwperf::MasterSeed(baseline_seed),
                    "c15.fixture.identity-group"));

  const auto add_budget_variant = [&](const std::string& name,
                                      const mwperf::ConstructionBudget& budget) {
    variants.emplace_back(
        name, issue_request(input, budget, baseline_policies,
                            mwperf::MasterSeed(baseline_seed),
                            "c15.fixture.identity-group"));
  };
  auto exact_calls = baseline_budget;
  exact_calls.exact_optimizer_calls.amount = mwperf::BigNat{1U};
  add_budget_variant("exact optimizer-call grant", exact_calls);
  auto search_states = baseline_budget;
  search_states.optimizer_search_states.amount = mwperf::BigNat{1U};
  add_budget_variant("optimizer search-state grant", search_states);
  auto generator_draws = baseline_budget;
  generator_draws.configured_generator_draws.amount = mwperf::BigNat{1U};
  add_budget_variant("configured-generator-draw grant", generator_draws);
  auto linear_tolerance = baseline_budget;
  linear_tolerance.linear_residual_abs = {
      mwperf::BudgetApplicabilityV1::applicable, rational(1, 1024)};
  add_budget_variant("linear-residual tolerance grant", linear_tolerance);
  auto integration_tolerance = baseline_budget;
  integration_tolerance.integration_abs = {
      mwperf::BudgetApplicabilityV1::applicable, rational(1, 1024)};
  add_budget_variant("integration tolerance grant", integration_tolerance);
  auto tail_tolerance = baseline_budget;
  tail_tolerance.tail_abs = {mwperf::BudgetApplicabilityV1::applicable,
                             rational(1, 1024)};
  add_budget_variant("tail tolerance grant", tail_tolerance);
  auto fixed_point_tolerance = baseline_budget;
  fixed_point_tolerance.fixed_point_abs = {
      mwperf::BudgetApplicabilityV1::applicable, rational(1, 1024)};
  add_budget_variant("fixed-point tolerance grant", fixed_point_tolerance);

  for (const auto& [name, variant] : variants) {
    INFO("coherent request variant: " << name);
    CHECK(variant.request.build_identity_digest() !=
          baseline.request.build_identity_digest());
    CHECK(variant.request.build_seed() != baseline.request.build_seed());
    CHECK(variant.request.request_digest() !=
          baseline.request.request_digest());
    auto replay = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{built.result}, variant.request,
        variant.manifest, variant.contract, built.validated_report);
    REQUIRE_FALSE(replay);
    CHECK(replay.error().code == "c15.result_envelope_binding");
  }

  const auto master_seed_only = issue_request(
      input, baseline_budget, baseline_policies,
      mwperf::MasterSeed(baseline_seed + 1U),
      "c15.fixture.identity-group");
  CHECK(master_seed_only.request.build_identity_digest() ==
        baseline.request.build_identity_digest());
  CHECK(master_seed_only.request.build_seed() != baseline.request.build_seed());
  CHECK(master_seed_only.request.request_digest() !=
        baseline.request.request_digest());
  auto master_seed_replay = mwperf::validate_surrogate_build_result(
      mwperf::SurrogateBuildResultV1{built.result}, master_seed_only.request,
      master_seed_only.manifest, master_seed_only.contract,
      built.validated_report);
  REQUIRE_FALSE(master_seed_replay);
  CHECK(master_seed_replay.error().code == "c15.result_envelope_binding");
}

TEST_CASE("C15 F03 binds a seed root without initializing or drawing RNG",
          "[c15][catalog][unit]") {
  // This source-level instrumentation gate is intentionally scoped to the
  // production F-C15-03 body.  C02's later stream derivation remains free to
  // use RNG machinery, but request construction may only bind an immutable
  // BuildSeed root.
  const std::string source =
      read_project_text("src/surrogate/request_adapter.cpp");
  const auto begin = source.find(
      "Result<SurrogateBuildRequest> make_surrogate_build_request(");
  const auto end = source.find(
      "Result<void> artifact::detail::verify_request_bindings_v1(", begin);
  REQUIRE(begin != std::string::npos);
  REQUIRE(end != std::string::npos);
  REQUIRE(begin < end);
  const std::string_view body(source.data() + begin, end - begin);

  const auto precursor = body.find("digest_build_identity_v1(identity)");
  const auto seed_root = body.find("BuildSeed seed(master_seed");
  const auto final_digest = body.find("digest_request(request)");
  REQUIRE(precursor != std::string_view::npos);
  REQUIRE(seed_root != std::string_view::npos);
  REQUIRE(final_digest != std::string_view::npos);
  CHECK(precursor < seed_root);
  CHECK(seed_root < final_digest);

  for (const std::string_view forbidden : {
           "derive_rng_stream", "DeterministicRng", "RngTransaction",
           "next_u64", "sample_categorical", "sample_exact"}) {
    INFO(forbidden);
    CHECK(body.find(forbidden) == std::string_view::npos);
  }
}

TEST_CASE("C15 request binding verifier rejects stale precursor seed and body",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.tamper", mwperf::MasterSeed(19U));
  const mwperf::BuildIdentityDigest wrong_identity(digest_of("wrong-identity"));
  const mwperf::SurrogateBuildRequestDigest wrong_request(
      digest_of("wrong-request"));

  CHECK_FALSE(mwperf::artifact::detail::verify_request_bindings_v1(
      Factory::with_build_identity_digest(fixture.request, wrong_identity),
      fixture.manifest));
  CHECK_FALSE(mwperf::artifact::detail::verify_request_bindings_v1(
      Factory::with_request_digest(fixture.request, wrong_request),
      fixture.manifest));
  CHECK_FALSE(mwperf::artifact::detail::verify_request_bindings_v1(
      Factory::with_build_seed(
          fixture.request,
          mwperf::BuildSeed(mwperf::MasterSeed(19U), wrong_identity)),
      fixture.manifest));
  const auto corrupt_view = Factory::with_problem_view_digest(
      fixture.view,
      mwperf::FrameworkProblemViewDigest(digest_of("wrong-view")));
  CHECK_FALSE(mwperf::artifact::detail::verify_request_bindings_v1(
      Factory::with_problem_view(fixture.request, corrupt_view),
      fixture.manifest));
}

TEST_CASE("C15 F03 rejects foreign views scopes and accepted-policy tamper",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.contract-binding", mwperf::MasterSeed(73U));

  SECTION("contract preview belongs to one exact problem view") {
    const auto other_input = make_protocol_input_fixture(
        R"json({"kind":"stationary_class","parameters":{"class_id":"other-class"}})json");
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(label("c15.fixture.group"))};
    auto other_view = mwperf::build_framework_problem_view(
        other_input.instance, *other_input.arrival, targets);
    REQUIRE(other_view);
    CHECK_FALSE(mwperf::make_surrogate_build_request(
        fixture.manifest, other_view.value(), fixture.contract,
        fixture.parameters, fixture.budget, mwperf::MasterSeed(73U)));
  }

  SECTION("construction scope cannot omit a deployed target") {
    const auto changed = Factory::with_construction_scope(fixture.contract, {});
    CHECK_FALSE(mwperf::make_surrogate_build_request(
        fixture.manifest, fixture.view, changed, fixture.parameters,
        fixture.budget, mwperf::MasterSeed(73U)));
  }

  SECTION("construction scope cannot name a queue outside the view") {
    const auto changed = Factory::with_construction_scope(
        fixture.contract, {queue_id("q0"), queue_id("q2")});
    CHECK_FALSE(mwperf::make_surrogate_build_request(
        fixture.manifest, fixture.view, changed, fixture.parameters,
        fixture.budget, mwperf::MasterSeed(73U)));
  }

  SECTION("accepted deployment policy is contract-bound") {
    auto policies = fixture.contract.policies();
    policies.point_deployment =
        mwperf::PointDeploymentPolicyV1::deploy_nominal_point;
    const auto changed = Factory::with_policies(fixture.contract, policies);
    CHECK_FALSE(mwperf::make_surrogate_build_request(
        fixture.manifest, fixture.view, changed, fixture.parameters,
        fixture.budget, mwperf::MasterSeed(73U)));
  }

  SECTION("all remaining provider policies are contract-bound") {
    std::array<mwperf::PreviewPoliciesV1, 4U> changed_policies{
        fixture.contract.policies(), fixture.contract.policies(),
        fixture.contract.policies(), fixture.contract.policies()};
    changed_policies[0U].coefficient_completion =
        mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion;
    changed_policies[1U].projection =
        mwperf::ProjectionPolicyV1::identity;
    changed_policies[2U].recoding = mwperf::RecodingPolicyV1::identity;
    changed_policies[3U].evidence_roles =
        mwperf::EvidenceRolePolicyV1::not_applicable;
    for (const auto& policies : changed_policies) {
      const auto changed = Factory::with_policies(fixture.contract, policies);
      CHECK_FALSE(mwperf::make_surrogate_build_request(
          fixture.manifest, fixture.view, changed, fixture.parameters,
          fixture.budget, mwperf::MasterSeed(73U)));
    }
  }
}

TEST_CASE("C15 F03 rejects validated parameter carriers from another binding",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.parameter-binding", mwperf::MasterSeed(91U));
  const auto canonical_bytes = bytes_of("{}");

  const std::array foreign{
      Factory::validated_parameters(provider("another.provider", "1.0.0"),
                                    1U,
                                    fixture.manifest.value()
                                        .parameter_schema_digest,
                                    canonical_bytes),
      Factory::validated_parameters(
          provider("c15.fixture.parameter-binding", "2.0.0"), 1U,
          fixture.manifest.value().parameter_schema_digest,
          canonical_bytes),
      Factory::validated_parameters(
          provider("c15.fixture.parameter-binding", "1.0.0"), 2U,
          fixture.manifest.value().parameter_schema_digest,
          canonical_bytes)};
  for (const auto& parameters : foreign) {
    CHECK_FALSE(mwperf::make_surrogate_build_request(
        fixture.manifest, fixture.view, fixture.contract, parameters,
        fixture.budget, mwperf::MasterSeed(91U)));
  }
}

TEST_CASE("C15 exact ModeErased projection equates all producer routes",
          "[c15][property]") {
  const auto input = make_protocol_input_fixture();
  const std::array fixtures{
      make_bound_request_fixture(
          input, mwperf::ConstructionMethodV1::closed_form,
          mwperf::ProducerModeV1::inline_immediate,
          "c15.fixture.inline"),
      make_bound_request_fixture(
          input, mwperf::ConstructionMethodV1::engineered_deterministic,
          mwperf::ProducerModeV1::in_process_builder,
          "c15.fixture.in-process"),
      make_bound_request_fixture(
          input, mwperf::ConstructionMethodV1::engineered_hybrid,
          mwperf::ProducerModeV1::local_executable_builder,
          "c15.fixture.local"),
      make_bound_request_fixture(
          input, mwperf::ConstructionMethodV1::precomputed,
          mwperf::ProducerModeV1::inline_immediate,
          "c15.fixture.precomputed")};

  using ModeErasedMetricRoute =
      std::tuple<mwperf::MetricKindV1, mwperf::SemanticTagV1,
                 mwperf::RuntimeAccessTagV1, mwperf::TargetCouplingV1,
                 mwperf::SolverRegimeV1, mwperf::BackendRouteKindV1>;
  std::vector<mwperf::testing::ModeErasedLawProjectionV1> projections;
  std::vector<std::vector<ModeErasedMetricRoute>> metric_routes;
  std::vector<mwperf::Digest256> artifact_payload_digests;
  std::vector<mwperf::Digest256> descriptor_digests;
  for (const auto& fixture : fixtures) {
    const auto candidate = make_bound_built_fixture(fixture);
    auto bytes =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{candidate.result});
    REQUIRE(bytes);
    auto parsed = mwperf::parse_surrogate_build_result(
        bytes.value(), generous_parse_limits());
    REQUIRE(parsed);
    auto validated = mwperf::validate_surrogate_build_result(
        parsed.value(), fixture.request, fixture.manifest, fixture.contract,
        candidate.validated_report);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated.value(), input.requirements);
    const auto* capabilities =
        std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
    REQUIRE(capabilities != nullptr);
    auto portable = mwperf::adapt_portable_payload(capabilities->artifact);
    REQUIRE(portable);
    CHECK(std::holds_alternative<mwperf::PortableThreeBinScalarResponseV1>(
        portable.value().value()));

    auto projected = mwperf::testing::make_mode_erased_law_projection_v1(
        capabilities->artifact, fixture.request, fixture.contract);
    INFO((projected ? std::string{}
                    : projected.error().code + ": " +
                          projected.error().message));
    REQUIRE(projected);
    projections.push_back(std::move(projected).value());

    const auto& clause =
        fixture.contract.structural_manifest().clauses().front();
    metric_routes.push_back({ModeErasedMetricRoute{
        clause.metric_kind, clause.semantic, clause.runtime_access,
        clause.target_coupling, clause.solver_route,
        mwperf::BackendRouteKindV1::analytic_metric_family}});

    const auto* built = std::get_if<mwperf::BuiltSurrogateResultV1>(
        &parsed.value());
    REQUIRE(built != nullptr);
    artifact_payload_digests.push_back(built->artifact.payload_digest);
    descriptor_digests.push_back(built->artifact.deployed_descriptor.core_digest);
  }
  REQUIRE(projections.size() == fixtures.size());
  REQUIRE(metric_routes.size() == fixtures.size());
  for (std::size_t index = 1U; index < projections.size(); ++index) {
    CHECK(projections[index] == projections.front());
    CHECK(metric_routes[index] == metric_routes.front());
    CHECK(fixtures[index].contract.structural_manifest() ==
          fixtures.front().contract.structural_manifest());
    CHECK(fixtures[index].request.build_identity_digest() !=
          fixtures.front().request.build_identity_digest());
    CHECK(fixtures[index].request.request_digest() !=
          fixtures.front().request.request_digest());
    CHECK(artifact_payload_digests[index] != artifact_payload_digests.front());
    CHECK(descriptor_digests[index] != descriptor_digests.front());
  }
  REQUIRE(metric_routes.front().size() == 1U);
  CHECK(std::get<5>(metric_routes.front().front()) ==
        mwperf::BackendRouteKindV1::analytic_metric_family);
  CHECK(projections.front().projection_version == 1U);
  CHECK(projections.front().deployed_law.canonical_law_parameters ==
        std::array{rational(0, 1), rational(1, 4), rational(3, 4),
                   rational(1, 2)});
  REQUIRE(projections.front()
              .metric_convention.normalized_metric_kinds_and_parameters
              .size() == 1U);
  CHECK(projections.front()
            .metric_convention.normalized_metric_kinds_and_parameters.front()
            .metric_kind == mwperf::MetricKindV1::stationary_throughput);

  // Runtime route/identity are explicitly erased: changing only those
  // identity-bearing fields cannot leak into the mathematical projection.
  auto route_only = artifact_for_payload(three_bin_payload());
  route_only.runtime_access =
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler;
  route_only.deployed_descriptor.runtime_access =
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler;
  route_only.provider = provider("c15.fixture.erased-route", "9.0.0");
  auto route_projection =
      mwperf::testing::make_mode_erased_law_projection_v1(
          Factory::validated_artifact(std::move(route_only)),
          fixtures.front().request, fixtures.front().contract);
  REQUIRE(route_projection);
  CHECK(route_projection.value() == projections.front());
}

TEST_CASE("C15 canonical payload bytes and digests are deterministic",
          "[c15][property]") {
  for (const bool binary : {false, true}) {
    const mwperf::ArtifactPayloadV1 payload = three_bin_payload(binary);
    auto bytes_a = mwperf::canonical_artifact_payload_bytes_v1(payload);
    auto bytes_b = mwperf::canonical_artifact_payload_bytes_v1(payload);
    auto digest_a = mwperf::canonical_artifact_payload_digest_v1(payload);
    auto digest_b = mwperf::canonical_artifact_payload_digest_v1(payload);
    REQUIRE(bytes_a);
    REQUIRE(bytes_b);
    REQUIRE(digest_a);
    REQUIRE(digest_b);
    CHECK(bytes_a.value() == bytes_b.value());
    CHECK(digest_a.value() == digest_b.value());
  }

  mwperf::ArtifactPayloadV1 first = three_bin_payload(false);
  mwperf::ArtifactPayloadV1 second = first;
  auto& response = std::get<mwperf::ThreeBinScalarResponseV1>(second);
  REQUIRE(response.nominal_response.has_value());
  response.nominal_response->coefficients[2U].value = scalar(7, 8);
  auto first_digest = mwperf::canonical_artifact_payload_digest_v1(first);
  auto second_digest = mwperf::canonical_artifact_payload_digest_v1(second);
  REQUIRE(first_digest);
  REQUIRE(second_digest);
  CHECK(first_digest.value() != second_digest.value());
}

TEST_CASE(
    "C15 finite-prefix constant-tail payload is canonical and round-trips for every supported cutoff",
    "[c15][property]") {
  std::vector<mwperf::Digest256> digests;
  for (const std::uint64_t cutoff : {2U, 3U, 4U, 5U}) {
    INFO("K=" << cutoff);
      auto response = finite_prefix_payload(cutoff);
      auto shape = mwperf::artifact::detail::
          validate_finite_prefix_constant_tail_shape_v1(
              response, mwperf::BigNat{cutoff},
              mwperf::BigNat{cutoff + 1U});
      INFO((shape ? std::string{}
                  : shape.error().code + ": " + shape.error().message));
      REQUIRE(shape);
      const auto family = finite_prefix_family_evidence(response);
      auto family_shape = mwperf::artifact::detail::
          validate_finite_prefix_constant_tail_family_evidence_v1(
              response,
              std::span<const mwperf::FamilyEvidenceEnvelopeV1>{&family,
                                                                 1U});
      INFO((family_shape
                ? std::string{}
                : family_shape.error().code + ": " +
                      family_shape.error().message));
      REQUIRE(family_shape);
      CHECK(family.provider_conformance_report_ref.report_id ==
            label("fofs_cp07_1_provider_conformance_report_v1"));
      CHECK(family.provider_conformance_report_ref.report_digest ==
            digest_from_hex(
                "89cc4d4fbdcd516ae61cd97d7769fb2c49c5990d3576c44785c5b4a6d1fb0019"));
      CHECK(family.provider_conformance_report_ref
                .family_evidence_schema_id ==
            "full_orbit_finite_prefix_evidence_v1");

      const mwperf::ArtifactPayloadV1 payload = response;
      auto bytes_a = mwperf::canonical_artifact_payload_bytes_v1(payload);
      auto bytes_b = mwperf::canonical_artifact_payload_bytes_v1(payload);
      auto digest_a = mwperf::canonical_artifact_payload_digest_v1(payload);
      auto digest_b = mwperf::canonical_artifact_payload_digest_v1(payload);
      REQUIRE(bytes_a);
      REQUIRE(bytes_b);
      REQUIRE(digest_a);
      REQUIRE(digest_b);
      CHECK(bytes_a.value() == bytes_b.value());
      CHECK(digest_a.value() == digest_b.value());
      digests.push_back(digest_a.value());

      const mwperf::ResultEnvelopeV1 envelope{
          1U, digest_of("request"), provider(), build_report()};
      const mwperf::SurrogateBuildResultV1 built{
          mwperf::BuiltSurrogateResultV1{
              envelope, artifact_for_payload(payload)}};
      auto encoded =
          mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
              built);
      REQUIRE(encoded);
      auto parsed = mwperf::parse_surrogate_build_result(
          encoded.value(), generous_parse_limits());
      INFO((parsed ? std::string{}
                   : parsed.error().code + ": " + parsed.error().message));
      REQUIRE(parsed);
      CHECK(parsed.value() == built);

      const auto json = nlohmann::ordered_json::parse(
          text_of(encoded.value()));
      const auto& body = json.at("artifact").at("payload").at("body");
      CHECK(body.at("response_cutoff") == std::to_string(cutoff));
      const auto& identifications =
          body.at("raw_response").at("identifications");
      REQUIRE(identifications.size() == cutoff + 2U);
      CHECK(identifications.front().at("coordinate").at("kind") ==
            "structural_level_zero");
      CHECK(identifications.front().at("coordinate").at("level") == "0");
      for (std::uint64_t level = 1U; level <= cutoff; ++level) {
        CHECK(identifications.at(level).at("coordinate").at("kind") ==
              "exact_level");
        CHECK(identifications.at(level).at("coordinate").at("level") ==
              std::to_string(level));
      }
      CHECK(identifications.back().at("coordinate").at("kind") ==
            "constant_tail");
      CHECK(identifications.back().at("coordinate").at("tail_from") ==
            std::to_string(cutoff + 1U));
      for (const auto& identification : identifications) {
        for (const auto* scalar_value : {
                 &identification.at("pooled_mass").at("unserved"),
                 &identification.at("pooled_mass").at("served"),
                 &identification.at("raw_point")}) {
          CHECK(scalar_value->at("kind") == "binary64");
          CHECK(scalar_value->at("bits")
                    .get<std::string>()
                    .starts_with("0x"));
        }
      }
  }
  std::sort(digests.begin(), digests.end());
  CHECK(std::adjacent_find(digests.begin(), digests.end()) == digests.end());
}

TEST_CASE(
    "C15 finite-prefix wire rejects malformed and nonfinite binary64 coefficients",
    "[c15][negative]") {
  const mwperf::ResultEnvelopeV1 envelope{
      1U, digest_of("request"), provider(), build_report()};
  const mwperf::SurrogateBuildResultV1 built{
      mwperf::BuiltSurrogateResultV1{
          envelope,
          artifact_for_payload(finite_prefix_payload(5U))}};
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          built);
  REQUIRE(encoded);
  const auto baseline =
      nlohmann::ordered_json::parse(text_of(encoded.value()));

  for (const std::string_view bits : {
           "0X3fb999999999999a", "0x3FB999999999999A",
           "0x3fb999999999999", "0x7ff0000000000000",
           "0x7ff8000000000000", "0x8000000000000000"}) {
    DYNAMIC_SECTION(bits) {
      auto tampered = baseline;
      tampered["artifact"]["payload"]["body"]["raw_response"]
              ["identifications"][1U]["raw_point"]["bits"] = bits;
      auto parsed = mwperf::parse_surrogate_build_result(
          bytes_of(tampered.dump()), generous_parse_limits());
      REQUIRE_FALSE(parsed);
    }
  }
}

TEST_CASE(
    "C16 finite-prefix adaptation preserves exact dyadics zeros and native K-wide shape",
    "[c15][c16][integration]") {
  for (const std::uint64_t cutoff : {2U, 3U, 4U, 5U}) {
    INFO("K=" << cutoff);
      auto artifact = artifact_for_payload(finite_prefix_payload(cutoff));
      auto adapted = mwperf::adapt_portable_payload(
          Factory::validated_artifact(std::move(artifact)));
      REQUIRE(adapted);
      const auto* response =
          std::get_if<mwperf::PortableFinitePrefixConstantTailResponseV1>(
              &adapted.value().value());
      REQUIRE(response != nullptr);
      CHECK(response->response_cutoff == mwperf::BigNat{cutoff});
      CHECK(response->service_by_level.size() == cutoff + 1U);
      CHECK(response->service_by_level.front() ==
            mwperf::ExactRational::zero());
      CHECK(response->service_by_level.at(2U) ==
            mwperf::ExactRational::zero());
      CHECK(response->constant_tail_from == mwperf::BigNat{cutoff + 1U});
      CHECK(response->constant_tail_service == rational(5, 8));

      auto rounding_sensitive = mwperf::ExactRational::make(
          mwperf::BigInt{3'602'879'701'896'397LL},
          mwperf::BigInt{36'028'797'018'963'968LL});
      REQUIRE(rounding_sensitive);
      CHECK(response->service_by_level.at(1U) ==
            rounding_sensitive.value());
      for (const auto& identification :
           response->normalized_record.raw_response.identifications) {
        CHECK(identification.pooled_unserved_mass.kind() ==
              mwperf::PortableScientificScalarKind::rational);
        CHECK(identification.pooled_served_mass.kind() ==
              mwperf::PortableScientificScalarKind::rational);
        CHECK(identification.raw_point.kind() ==
              mwperf::PortableScientificScalarKind::rational);
      }
      REQUIRE(response->normalized_record.raw_envelopes.size() == 1U);
      const auto& normalized_envelope =
          response->normalized_record.raw_envelopes.front();
      for (const auto& bound : normalized_envelope.lower) {
        CHECK(bound.kind() ==
              mwperf::PortableScientificScalarKind::rational);
      }
      for (const auto& bound : normalized_envelope.upper) {
        CHECK(bound.kind() ==
              mwperf::PortableScientificScalarKind::rational);
      }
      CHECK(normalized_envelope.concentration_radius_lower.kind() ==
            mwperf::PortableScientificScalarKind::rational);
      CHECK(normalized_envelope.concentration_radius_upper.kind() ==
            mwperf::PortableScientificScalarKind::rational);
      CHECK(normalized_envelope.floating_point_enclosure.kind() ==
            mwperf::PortableScientificScalarKind::rational);

      // The K-wide alternative and all native positive levels survive
      // adaptation.  In particular K>2 cannot be reinterpreted as the
      // sampler's separate three-bin compatibility fold.
      CHECK_FALSE(std::holds_alternative<
                  mwperf::PortableThreeBinScalarResponseV1>(
          adapted.value().value()));
      if (cutoff > 2U) {
        CHECK(response->service_by_level.size() > 3U);
        CHECK(response->service_by_level.at(3U) == rational(3, 4));
      }
  }
}

TEST_CASE(
    "C16 K2 dynamic and legacy three-bin payloads normalize to one scalar response",
    "[c15][c16][unit]") {
  auto dynamic = finite_prefix_payload(2U);
  const std::array<double, 3U> values{0.25, 0.75, 0.5};
  for (std::size_t index = 0U; index < values.size(); ++index) {
    const std::size_t dynamic_index = index + 1U;
    dynamic.raw_response.identifications.at(dynamic_index).raw_point =
        binary_scalar(values[index]);
    dynamic.raw_envelopes.front().lower.at(dynamic_index) =
        binary_scalar(values[index]);
    dynamic.raw_envelopes.front().upper.at(dynamic_index) =
        binary_scalar(values[index]);
  }
  reseal_finite_prefix_response(dynamic);

  auto dynamic_adapted = mwperf::adapt_portable_payload(
      Factory::validated_artifact(artifact_for_payload(dynamic)));
  auto legacy_adapted = mwperf::adapt_portable_payload(
      Factory::validated_artifact(artifact_for_payload(
          three_bin_payload(true))));
  REQUIRE(dynamic_adapted);
  REQUIRE(legacy_adapted);
  const auto* dynamic_response =
      std::get_if<mwperf::PortableFinitePrefixConstantTailResponseV1>(
          &dynamic_adapted.value().value());
  const auto* legacy_response =
      std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
          &legacy_adapted.value().value());
  REQUIRE(dynamic_response != nullptr);
  REQUIRE(legacy_response != nullptr);
  REQUIRE(dynamic_response->service_by_level.size() == 3U);
  CHECK(dynamic_response->service_by_level.front() ==
        mwperf::ExactRational::zero());
  CHECK(dynamic_response->service_by_level.at(1U) ==
        legacy_response->coefficients.at(0U));
  CHECK(dynamic_response->service_by_level.at(2U) ==
        legacy_response->coefficients.at(1U));
  CHECK(dynamic_response->constant_tail_from == mwperf::BigNat{3U});
  CHECK(dynamic_response->constant_tail_service ==
        legacy_response->coefficients.at(2U));
}

TEST_CASE(
    "C16 finite-prefix adaptation rejects every inconsistent response shape",
    "[c15][c16][negative]") {
  const auto rejects = [](
                           mwperf::FinitePrefixConstantTailResponseV1 value,
                           const mwperf::BigNat& expected_cutoff =
                               mwperf::BigNat{5U},
                           const mwperf::BigNat& descriptor_tail_from =
                               mwperf::BigNat{6U},
                           const bool adapter_must_reject = true) {
    auto shape = mwperf::artifact::detail::
        validate_finite_prefix_constant_tail_shape_v1(
            value, expected_cutoff, descriptor_tail_from);
    CHECK_FALSE(shape);
    reseal_finite_prefix_response(value);
    auto adapted = mwperf::adapt_portable_payload(
        Factory::validated_artifact(artifact_for_payload(std::move(value))));
    if (adapter_must_reject) {
      CHECK_FALSE(adapted);
    } else {
      CHECK(adapted);
    }
  };

  SECTION("missing exact level") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.erase(
        value.raw_response.identifications.begin() + 3);
    rejects(std::move(value));
  }
  SECTION("duplicate exact level") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.at(2U).coordinate =
        value.raw_response.identifications.at(1U).coordinate;
    rejects(std::move(value));
  }
  SECTION("permuted exact levels") {
    auto value = finite_prefix_payload(5U);
    std::swap(value.raw_response.identifications.at(1U),
              value.raw_response.identifications.at(2U));
    rejects(std::move(value));
  }
  SECTION("nonconsecutive exact level") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.at(3U).coordinate
        .level_or_tail_from = mwperf::BigNat{4U};
    rejects(std::move(value));
  }
  SECTION("nonzero structural level zero") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.front().raw_point =
        binary_scalar(0.25);
    rejects(std::move(value));
  }
  SECTION("tail does not begin at K plus one") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.back().coordinate
        .level_or_tail_from = mwperf::BigNat{7U};
    rejects(std::move(value));
  }
  SECTION("payload and raw cutoff disagree") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.response_cutoff = mwperf::BigNat{4U};
    rejects(std::move(value));
  }
  SECTION("provider and payload cutoff disagree") {
    auto value = finite_prefix_payload(5U);
    rejects(std::move(value), mwperf::BigNat{4U}, mwperf::BigNat{5U},
            false);
  }
  SECTION("descriptor boundary disagrees") {
    auto value = finite_prefix_payload(5U);
    rejects(std::move(value), mwperf::BigNat{5U}, mwperf::BigNat{7U},
            false);
  }
  SECTION("payload and envelope cutoff disagree") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().response_cutoff = mwperf::BigNat{4U};
    rejects(std::move(value));
  }
  SECTION("interval vector length disagrees") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().upper.pop_back();
    rejects(std::move(value));
  }
  SECTION("envelope tail label disagrees") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().covered_coordinates.back()
        .level_or_tail_from = mwperf::BigNat{7U};
    rejects(std::move(value));
  }
  SECTION("coefficient is outside the probability domain") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.at(1U).raw_point =
        binary_scalar(1.5);
    rejects(std::move(value));
  }
  SECTION("coefficient uses rational instead of sampler binary64") {
    auto value = finite_prefix_payload(5U);
    value.raw_response.identifications.at(1U).raw_point = scalar(1, 4);
    rejects(std::move(value));
  }
  SECTION("interval is outside the probability domain") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().upper.at(1U) = binary_scalar(1.25);
    rejects(std::move(value));
  }
  SECTION("interval endpoints are reversed") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().lower.at(1U) = binary_scalar(0.75);
    value.raw_envelopes.front().upper.at(1U) = binary_scalar(0.5);
    rejects(std::move(value));
  }
  SECTION("interval excludes its nominal coefficient") {
    auto value = finite_prefix_payload(5U);
    value.raw_envelopes.front().lower.at(1U) = binary_scalar(0.5);
    value.raw_envelopes.front().upper.at(1U) = binary_scalar(0.75);
    rejects(std::move(value));
  }
}

TEST_CASE(
    "C15 finite-prefix semantics retain unbounded nonnegative pooled masses",
    "[c15][unit]") {
  auto response = finite_prefix_payload(5U);
  response.raw_response.identifications.at(1U).pooled_unserved_mass =
      binary_scalar(std::bit_cast<double>(std::uint64_t{0x3ff0000000000001}));
  auto shape = mwperf::artifact::detail::
      validate_finite_prefix_constant_tail_shape_v1(
          response, mwperf::BigNat{5U}, mwperf::BigNat{6U});
  INFO((shape ? std::string{}
              : shape.error().code + ": " + shape.error().message));
  REQUIRE(shape);
}

TEST_CASE(
    "C15 finite-prefix family evidence binds native K vectors and tail",
    "[c15][negative]") {
  auto response = finite_prefix_payload(5U);
  const auto baseline = finite_prefix_family_evidence(response);
  auto valid = mwperf::artifact::detail::
      validate_finite_prefix_constant_tail_family_evidence_v1(
          response,
          std::span<const mwperf::FamilyEvidenceEnvelopeV1>{&baseline, 1U});
  REQUIRE(valid);

  const auto rejects = [&](const auto& mutate) {
    auto bound_response = response;
    auto family = baseline;
    auto body = nlohmann::ordered_json::parse(
        text_of(family.canonical_family_body));
    mutate(body);
    family.canonical_family_body = bytes_of(body.dump());
    seal_finite_prefix_family_graph(bound_response, family);
    auto result = mwperf::artifact::detail::
        validate_finite_prefix_constant_tail_family_evidence_v1(
            bound_response,
            std::span<const mwperf::FamilyEvidenceEnvelopeV1>{&family, 1U});
    CHECK_FALSE(result);
  };

  SECTION("top-level evidence K") {
    rejects([](auto& body) { body["response_cutoff"] = "4"; });
  }
  SECTION("mass-vector evidence K") {
    rejects([](auto& body) {
      body["masses"]["response_cutoff"] = "4";
    });
  }
  SECTION("response vector length") {
    rejects([](auto& body) { body["response"]["levels"].erase(3U); });
  }
  SECTION("tail label") {
    rejects([](auto& body) {
      body["response"]["tail"]["tail_from"] = "7";
    });
  }
  SECTION("binary64 point bits") {
    rejects([](auto& body) {
      body["response"]["levels"][1U]["point"]["bits"] =
          "0x3fd0000000000000";
    });
  }
}

TEST_CASE("C15 scientific scalar grammar preserves exact representation",
          "[c15][unit]") {
  auto negative = mwperf::PortableScientificScalar::parse_rational("-3", "7");
  auto zero = mwperf::PortableScientificScalar::parse_rational("0", "1");
  auto subnormal = mwperf::PortableScientificScalar::parse_binary64(
      "0x0000000000000001");
  auto endpoint = mwperf::PortableScientificScalar::parse_binary64(
      "0x3ff0000000000000");
  REQUIRE(negative);
  REQUIRE(zero);
  REQUIRE(subnormal);
  REQUIRE(endpoint);
  CHECK(negative.value().canonical_tagged_encoding() ==
        "rational:-3/7");
  CHECK(mwperf::binary64_as_exact_rational(endpoint.value()) ==
        mwperf::ExactRational::one());
  mwperf::BigInt subnormal_denominator{1};
  subnormal_denominator <<= 1074U;
  auto exact_subnormal = mwperf::ExactRational::make(
      mwperf::BigInt{1}, std::move(subnormal_denominator));
  REQUIRE(exact_subnormal);
  CHECK(mwperf::binary64_as_exact_rational(subnormal.value()) ==
        exact_subnormal.value());
}

TEST_CASE("C15 scientific scalar grammar rejects noncanonical encodings",
          "[c15][negative]") {
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_rational("2", "4"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_rational("+1", "2"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_rational("01", "2"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_rational("0", "2"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(
      "0X3ff0000000000000"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(
      "0x3FF0000000000000"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(
      "0x8000000000000000"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(
      "0x7ff0000000000000"));
  CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(
      "0x7ff8000000000000"));
}

TEST_CASE("C15 three-bin response keeps exact nonmonotone coefficients",
          "[c15][unit]") {
  const auto payload = three_bin_payload(false);
  REQUIRE(payload.nominal_response.has_value());
  const auto& values = payload.nominal_response->coefficients;
  CHECK(values[0U].bin == mwperf::ThreeBinCoefficientV1::one);
  CHECK(values[1U].bin == mwperf::ThreeBinCoefficientV1::two);
  CHECK(values[2U].bin == mwperf::ThreeBinCoefficientV1::tail_from_three);
  CHECK(values[0U].value.rational_value() == rational(1, 4));
  CHECK(values[1U].value.rational_value() == rational(3, 4));
  CHECK(values[2U].value.rational_value() == rational(1, 2));
  // mu(0) is the protocol's fixed leading zero, not a fourth authored
  // coefficient.  The complete projected law is checked in the ModeErased
  // F01--F08 path above.
  CHECK(values.size() == 3U);
}

TEST_CASE("C15 coefficient source and status vocabularies are orthogonal",
          "[c15][unit]") {
  const std::array population{
      mwperf::PopulationConditioningStatusV1::proved_positive,
      mwperf::PopulationConditioningStatusV1::proved_zero,
      mwperf::PopulationConditioningStatusV1::positive_with_confidence,
      mwperf::PopulationConditioningStatusV1::unresolved};
  const std::array raw{mwperf::RawValueStatusV1::exact_point,
                       mwperf::RawValueStatusV1::interval_only,
                       mwperf::RawValueStatusV1::absent};
  CHECK(population.size() == 4U);
  CHECK(raw.size() == 3U);
  CHECK_FALSE((std::is_same_v<mwperf::CoefficientStatusV1,
                              mwperf::ProposalConditioningMeasureV1>));
}

TEST_CASE("C15 F05 enforces payload manifest descriptor compatibility",
          "[c15][negative]") {
  const auto manifest = scalar_manifest();
  // The fixture contract selects the raw point under
  // require_complete_raw_points; nominal deployment is covered separately
  // with the declared-completion policy.
  const mwperf::ArtifactPayloadV1 payload = three_bin_payload(false, false);
  const auto descriptor = scalar_descriptor(manifest);
  auto valid = mwperf::validate_metric_support_manifest(manifest, payload,
                                                        descriptor);
  INFO((valid ? std::string{}
              : valid.error().code + ": " + valid.error().message));
  REQUIRE(valid);

  SECTION("runtime route substitution") {
    auto mismatch = descriptor;
    mismatch.runtime_access = mwperf::RuntimeAccessTagV1::sparse_row;
    CHECK_FALSE(mwperf::validate_metric_support_manifest(manifest, payload,
                                                         mismatch));
  }
  SECTION("false coupled target claim") {
    auto mismatch = descriptor;
    mismatch.target_coupling =
        mwperf::TargetCouplingV1::common_schedule_projection;
    mismatch.deployed_targets.push_back(queue_id("q1"));
    CHECK_FALSE(mwperf::validate_metric_support_manifest(manifest, payload,
                                                         mismatch));
  }
  SECTION("phase-conditioned claim on phase-free response") {
    auto mismatch = descriptor;
    mismatch.phase.payload_phase =
        mwperf::PayloadPhaseKindV1::predictive_phase_indexed;
    CHECK_FALSE(mwperf::validate_metric_support_manifest(manifest, payload,
                                                         mismatch));
  }
  SECTION("semantic relabeling") {
    auto mismatch = descriptor;
    mismatch.semantic = mwperf::SemanticTagV1::coupled_target_schedule_law;
    CHECK_FALSE(mwperf::validate_metric_support_manifest(manifest, payload,
                                                         mismatch));
  }
  SECTION("target relabeling") {
    auto changed = std::get<mwperf::ThreeBinScalarResponseV1>(payload);
    changed.deployed_target = queue_id("q1");
    CHECK_FALSE(mwperf::validate_metric_support_manifest(
        manifest, mwperf::ArtifactPayloadV1{std::move(changed)}, descriptor));
  }
}

TEST_CASE("C15 F05 rejects resealed malformed descriptor cores",
          "[c15][negative]") {
  const auto manifest = scalar_manifest();
  const mwperf::ArtifactPayloadV1 payload = three_bin_payload(false, false);
  const auto valid = scalar_descriptor(manifest);
  REQUIRE(mwperf::validate_metric_support_manifest(manifest, payload, valid));

  const auto rejects = [&](const auto& mutation) {
    auto malformed = valid;
    mutation(malformed);
    reseal_descriptor(malformed);
    CHECK_FALSE(mwperf::validate_metric_support_manifest(manifest, payload,
                                                         malformed));
  };
  SECTION("empty provider identity") {
    rejects([](auto& descriptor) { descriptor.provider.provider_id.clear(); });
  }
  SECTION("empty applicability relation") {
    rejects([](auto& descriptor) {
      descriptor.applicability.scheduler_optimizer_pairs.clear();
    });
  }
  SECTION("duplicate descriptor-only state field") {
    rejects([](auto& descriptor) {
      descriptor.state_fields.push_back(descriptor.state_fields.front());
    });
  }
  SECTION("unsorted selection domain") {
    rejects([](auto& descriptor) {
      descriptor.selection.kinds.push_back(
          mwperf::SelectionKindV1::transient_initial);
    });
  }
  SECTION("constant response carries incompatible certified tail mass") {
    rejects([](auto& descriptor) {
      descriptor.tail.certified_tail_mass = rational(1, 4);
    });
  }
  SECTION("nonretained phase nevertheless declares a predictive codec") {
    rejects([](auto& descriptor) {
      descriptor.phase.retains_configured_predictive_phase = false;
      descriptor.phase.predictive_phase_codec =
          mwperf::CodecIdentityV1{"arrival.phase", 1U};
    });
  }
  SECTION("malformed optional evidence") {
    rejects([](auto& descriptor) {
      descriptor.optional_reported_evidence.push_back(
          {mwperf::OptionalReportedEvidenceKindV1::v1_fibre_realizability,
           "", 0U});
    });
  }
}

TEST_CASE("C15 F05 rejects every representative descriptor ceiling widening",
          "[c15][negative]") {
  const auto baseline_manifest = scalar_manifest();
  const mwperf::ArtifactPayloadV1 payload = three_bin_payload(false, false);

  const auto descriptor_rejects = [&](const auto& mutation) {
    auto descriptor = scalar_descriptor(baseline_manifest);
    mutation(descriptor);
    reseal_descriptor(descriptor);
    CHECK_FALSE(mwperf::validate_metric_support_manifest(
        baseline_manifest, payload, descriptor));
  };
  SECTION("state codec substitution") {
    descriptor_rejects([](auto& descriptor) {
      descriptor.state_fields.front().codec = {"queue.foreign", 1U};
    });
  }
  SECTION("mark reveal-stage broadening") {
    descriptor_rejects([](auto& descriptor) {
      descriptor.marks.front().reveal_stage =
          mwperf::MetricRevealStageV1::arrival;
    });
  }
  SECTION("phase horizon narrowing") {
    descriptor_rejects([](auto& descriptor) {
      descriptor.phase.finite_horizon_coverage =
          mwperf::FiniteHorizonCoverageKindV1::bounded;
      descriptor.phase.maximum_finite_horizon = mwperf::BigNat{0U};
    });
  }
  SECTION("weaker accuracy route") {
    descriptor_rejects([](auto& descriptor) {
      descriptor.accuracy_support = {
          mwperf::AnalyticAccuracyV1{mwperf::BigNat{64U}, {}}};
    });
  }

  const auto manifest_rejects = [&](const auto& mutation) {
    std::vector<mwperf::MetricSupportClauseV1> clauses(
        baseline_manifest.clauses().begin(),
        baseline_manifest.clauses().end());
    mutation(clauses.front());
    auto changed =
        mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
    REQUIRE(changed);
    auto descriptor = scalar_descriptor(changed.value());
    CHECK_FALSE(mwperf::validate_metric_support_manifest(
        changed.value(), payload, descriptor));
  };
  SECTION("named selection is not offered") {
    manifest_rejects([](auto& clause) {
      clause.selection_domain.kinds = {
          mwperf::SelectionKindV1::stationary_class};
      clause.selection_domain.named_classes = {label("unoffered-class")};
    });
  }
  SECTION("arrival provision is not offered") {
    manifest_rejects([](auto& clause) {
      clause.arrival_assumptions.push_back(
          {mwperf::ArrivalNeedKindV1::exact_iid_late,
           mwperf::ArrivalCapabilityUseV1::runtime,
           mwperf::CapabilityProvisionNeedV1::portable,
           std::nullopt, false, false, std::nullopt, std::nullopt,
           std::nullopt});
    });
  }
  SECTION("hypothesis is not offered") {
    manifest_rejects([](auto& clause) {
      clause.hypotheses.push_back(
          {mwperf::HypothesisKindV1::lossless, std::nullopt, std::nullopt,
           std::nullopt});
    });
  }
}

TEST_CASE("C15 payload class dispatch covers all seven closed alternatives",
          "[c15][unit]") {
  const auto q0 = queue_id("q0");
  const auto q1 = queue_id("q1");
  std::vector<mwperf::ArtifactPayloadV1> payloads;
  payloads.emplace_back(three_bin_payload());
  payloads.emplace_back(mwperf::FiniteParameterAnalyticDataV1{
      1U, "fixture.family", 1U, "fixture.parameters", 1U,
      "fixture.domain", 1U, provider(), {q0},
      {{"theta", scalar(1, 2)}}, {},
      {{"backlog", scalar(0, 1), scalar(4, 1), true, true}},
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {object_ref("analytic-response")}});
  payloads.emplace_back(mwperf::FiniteLawTablesV1{
      1U,
      {q0},
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      digest_of("arrival"),
      digest_of("selection"),
      {{label("s0"), {scalar(0, 1)}}},
      {{label("m0"), {scalar(0, 1)}}},
      mwperf::StationaryMarkedEdgeTableV1{
          1U, object_ref("stationary-law"),
          mwperf::FiniteTableStorageV1::dense,
          {{label("row"), label("s0"),
            mwperf::FiniteRowConditioningStageV1::stationary_edge,
            {{label("s0"), {label("m0")}, scalar(1, 1), std::nullopt}}}},
          {"queue.big_nat", 1U}, {"arrival.phase", 1U},
          {"service.bit", 1U}, {"edge.mark", 1U},
          digest_of("conditioning")}});
  payloads.emplace_back(mwperf::RegisteredRuntimeRecipeV1{
      1U, "fixture.recipe", 1U, "fixture.parameters", 1U,
      "fixture.state-codec", 1U, "fixture.mark-codec", 1U, provider(), {q0},
      {{"p", scalar(1, 2)}},
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{mwperf::MetricMarkKindV1::actual_departure,
        mwperf::MetricRevealStageV1::completed_edge,
        {"service.bit", 1U}, ""}}});
  auto lower = three_bin_payload();
  auto upper = three_bin_payload();
  auto lower_product = lower.deployed_response_product_id;
  auto upper_product = upper.deployed_response_product_id;
  payloads.emplace_back(mwperf::ResponseEnvelopeEvidenceV1{
      1U, {q0}, mwperf::MetricResultScopeV1::response_envelope,
      mwperf::MetricEvidenceScopeV1::validity_or_lift,
      std::move(lower), std::move(upper),
      std::move(lower_product), std::move(upper_product),
      object_ref("comparison-domain"), {object_ref("order-proof")}, false,
      std::nullopt});
  payloads.emplace_back(mwperf::DirectMetricPayloadV1{
      1U,
      {{object_ref("direct-value"), clause_id("throughput"), {q0, q1},
        scalar(1, 2), digest_of("request"),
        digest_of("normalized-request"), digest_of("targets"),
        digest_of("arrival"), digest_of("contract"),
        {mwperf::SelectionKindV1::stationary_unique}, {},
        mwperf::MetricResultScopeV1::surrogate_law,
        mwperf::DirectMetricValidityBasisV1::exact_closed_form,
        {object_ref("validity-proof")}}}});
  payloads.emplace_back(finite_prefix_payload(2U));

  const std::array expected{
      mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
      mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1,
      mwperf::PayloadClassTagV1::finite_law_tables_v1,
      mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
      mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
      mwperf::PayloadClassTagV1::direct_metric_payload_v1,
      mwperf::PayloadClassTagV1::
          finite_prefix_constant_tail_response_v1};
  REQUIRE(payloads.size() == expected.size());
  for (std::size_t index = 0U; index < payloads.size(); ++index) {
    const auto payload_class = mwperf::artifact_payload_class_v1(payloads[index]);
    CHECK(payload_class.tag == expected[index]);
    CHECK(payload_class.version == 1U);
    auto encoded = mwperf::canonical_artifact_payload_bytes_v1(payloads[index]);
    REQUIRE(encoded);
    CHECK_FALSE(encoded.value().empty());
  }
}

TEST_CASE("C15 finite-law union names all six noninterchangeable table schemas",
          "[c15][unit]") {
  const auto law = object_ref("law");
  const auto s0 = label("s0");
  const auto m0 = label("m0");
  const mwperf::FiniteLawRowV1 row{
      label("row"), s0,
      mwperf::FiniteRowConditioningStageV1::stationary_edge,
      {{s0, {m0}, scalar(1, 1), std::nullopt}}};
  const mwperf::ExplicitOrderedWordV1 word{
      s0, mwperf::BigNat{1U}, {m0}, label("terminal"), s0, scalar(1, 1)};
  const mwperf::FinitePredictiveStoppingTablesV1 predictive{{row}, {row},
                                                            {row}};
  std::vector<mwperf::FiniteLawTableAlternativeV1> tables;
  tables.emplace_back(mwperf::StationaryMarkedEdgeTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      {"q", 1U}, {"phase", 1U}, {"departure", 1U}, {"mark", 1U},
      digest_of("conditioning")});
  tables.emplace_back(mwperf::StagedOpportunityFluxTableV1{
      1U, law, mwperf::FiniteTableStorageV1::sparse, {s0}, {s0}, {row}, {row},
      digest_of("arrival"), {"arrival.innovation", 1U},
      object_ref("update"), object_ref("retained"),
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge}});
  tables.emplace_back(mwperf::TemporalContinuationTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      {mwperf::MetricRevealStageV1::predecision,
       mwperf::MetricRevealStageV1::arrival,
       mwperf::MetricRevealStageV1::completed_edge},
      {"arrival.phase", 1U}, std::nullopt});
  tables.emplace_back(mwperf::StoppedPathTableV1{
      1U, law, "hit.q0", {s0}, {s0}, {m0}, true, predictive, scalar(1, 4),
      {object_ref("defective-law-evidence")}});
  tables.emplace_back(mwperf::RomrResidenceWordTableV1{
      1U, law, "event.q0", {s0}, {s0}, {m0},
      std::vector<mwperf::ExplicitOrderedWordV1>{word},
      scalar(0, 1), {object_ref("termination-evidence")}});
  tables.emplace_back(mwperf::CoupledCommonScheduleTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {row},
      digest_of("constraint"), digest_of("tie-phase-arrival")});
  REQUIRE(tables.size() == 6U);
  for (std::size_t index = 0U; index < tables.size(); ++index) {
    CHECK(tables[index].index() == index);
  }
}

TEST_CASE("C15 common schedules enforce all five portable geometries",
          "[c15][unit]") {
  const auto input = make_protocol_input_fixture();
  const mwperf::TargetSelection selection{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c15.fixture.geometry"))};
  auto base = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, selection);
  REQUIRE(base);
  const auto q0 = queue_id("q0");
  const auto q1 = queue_id("q1");
  const std::array ordered_targets{q0, q1};
  const mwperf::CommonScheduleRealizationV1 valid{
      {q0, q1}, {mwperf::BigNat{1U}, mwperf::BigNat{1U}},
      {mwperf::BigNat{1U}, mwperf::BigNat{1U}},
      {mwperf::BigNat{0U}, mwperf::BigNat{0U}}, {1U, 1U}, false,
      std::nullopt};

  const auto check = [&](const mwperf::SchedulerConstraintPairV1 key,
                         mwperf::PortableConstraintGeometryV1 geometry,
                         const bool expected) {
    const auto view = Factory::with_constraint_geometry(
        base.value(), key, std::move(geometry));
    const auto result =
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            valid, ordered_targets, view);
    INFO((result ? std::string{}
                 : result.error().code + ": " + result.error().message));
    CHECK(static_cast<bool>(result) == expected);
  };

  SECTION("crossbar endpoints") {
    const mwperf::SchedulerConstraintPairV1 key{
        mwperf::ServiceFamily::crossbar_matching,
        mwperf::OptimizerId::hungarian_exact};
    check(key,
          mwperf::PortableCrossbarConstraintV1{
              {port_id("i0"), port_id("i1")},
              {port_id("o0"), port_id("o1")},
              {{q0, port_id("i0"), port_id("o0")},
               {q1, port_id("i1"), port_id("o1")}}},
          true);
    check(key,
          mwperf::PortableCrossbarConstraintV1{
              {port_id("i0"), port_id("i1")},
              {port_id("o0"), port_id("o1")},
              {{q0, port_id("i0"), port_id("o0")},
               {q1, port_id("i0"), port_id("o1")}}},
          false);
  }

  SECTION("half-open touching intervals") {
    const mwperf::SchedulerConstraintPairV1 key{
        mwperf::ServiceFamily::nonoverlapping_intervals,
        mwperf::OptimizerId::weighted_interval_dp_exact};
    check(key,
          mwperf::PortableIntervalConstraintV1{
              {{q0, rational(0, 1), rational(1, 1)},
               {q1, rational(1, 1), rational(2, 1)}}},
          true);
    check(key,
          mwperf::PortableIntervalConstraintV1{
              {{q0, rational(0, 1), rational(2, 1)},
               {q1, rational(1, 1), rational(3, 1)}}},
          false);
  }

  SECTION("node-exclusive links") {
    const mwperf::SchedulerConstraintPairV1 key{
        mwperf::ServiceFamily::node_exclusive_matching,
        mwperf::OptimizerId::edmonds_blossom_exact};
    check(key,
          mwperf::PortableNodeExclusiveConstraintV1{
              {vertex_id("v0"), vertex_id("v1"), vertex_id("v2"),
               vertex_id("v3")},
              {{q0, vertex_id("v0"), vertex_id("v1")},
               {q1, vertex_id("v2"), vertex_id("v3")}}},
          true);
    check(key,
          mwperf::PortableNodeExclusiveConstraintV1{
              {vertex_id("v0"), vertex_id("v1"), vertex_id("v2")},
              {{q0, vertex_id("v0"), vertex_id("v1")},
               {q1, vertex_id("v1"), vertex_id("v2")}}},
          false);
  }

  SECTION("pairwise conflicts") {
    const mwperf::SchedulerConstraintPairV1 key{
        mwperf::ServiceFamily::pairwise_conflicts,
        mwperf::OptimizerId::mwis_branch_memo_exact};
    check(key, mwperf::PortableConflictConstraintV1{{q0, q1}, {}}, true);
    check(key,
          mwperf::PortableConflictConstraintV1{{q0, q1}, {{q0, q1}}},
          false);
  }

  SECTION("resource packing") {
    const mwperf::SchedulerConstraintPairV1 key{
        mwperf::ServiceFamily::resource_packing,
        mwperf::OptimizerId::binary_packing_memo_exact};
    check(key,
          mwperf::PortablePackingConstraintV1{
              {resource_id("r0")}, {mwperf::BigNat{2U}},
              {{q0, {mwperf::BigNat{1U}}},
               {q1, {mwperf::BigNat{1U}}}}},
          true);
    check(key,
          mwperf::PortablePackingConstraintV1{
              {resource_id("r0")}, {mwperf::BigNat{1U}},
              {{q0, {mwperf::BigNat{1U}}},
               {q1, {mwperf::BigNat{1U}}}}},
          false);
  }
}

TEST_CASE("C15 common schedule records bind eligibility and q minus d",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const mwperf::TargetSelection selection{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c15.fixture.schedule-record"))};
  auto base = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, selection);
  REQUIRE(base);
  const auto q0 = queue_id("q0");
  const auto q1 = queue_id("q1");
  const std::array ordered_targets{q0, q1};
  const auto view = Factory::with_constraint_geometry(
      base.value(),
      {mwperf::ServiceFamily::pairwise_conflicts,
       mwperf::OptimizerId::mwis_branch_memo_exact},
      mwperf::PortableConflictConstraintV1{{q0, q1}, {}});
  const mwperf::CommonScheduleRealizationV1 valid{
      {q0, q1}, {mwperf::BigNat{2U}, mwperf::BigNat{1U}},
      {mwperf::BigNat{2U}, mwperf::BigNat{1U}},
      {mwperf::BigNat{1U}, mwperf::BigNat{0U}}, {1U, 1U}, false,
      std::nullopt};
  REQUIRE(mwperf::artifact::detail::validate_common_schedule_realization_v1(
      valid, ordered_targets, view));

  SECTION("departure cannot exceed current backlog") {
    auto bad = valid;
    bad.current_target_backlogs[0U] = mwperf::BigNat{0U};
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("retained backlog is exactly q minus d") {
    auto bad = valid;
    bad.retained_target_backlogs[0U] = mwperf::BigNat{0U};
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("unknown schedule queue") {
    auto bad = valid;
    bad.selected_full_schedule[1U] = queue_id("q2");
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("duplicate schedule queue") {
    auto bad = valid;
    bad.selected_full_schedule[1U] = q0;
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("selected queue must have positive recorded backlog") {
    auto bad = valid;
    bad.selected_schedule_backlogs[1U] = mwperf::BigNat{0U};
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("unwitnessed full schedule follows canonical queue catalog order") {
    auto bad = valid;
    std::swap(bad.selected_full_schedule[0U],
              bad.selected_full_schedule[1U]);
    std::swap(bad.selected_schedule_backlogs[0U],
              bad.selected_schedule_backlogs[1U]);
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            bad, ordered_targets, view));
  }
  SECTION("witnessed target projection follows authored target order") {
    const std::array reversed_targets{q1, q0};
    auto projected = valid;
    projected.selected_full_schedule = {q1, q0};
    projected.structurally_witnessed_projection = true;
    projected.projection_witness = object_ref("schedule-projection");
    REQUIRE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            projected, reversed_targets, view));
    std::swap(projected.selected_full_schedule[0U],
              projected.selected_full_schedule[1U]);
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            projected, reversed_targets, view));
  }
  SECTION("projection witness presence is exact") {
    auto full_with_witness = valid;
    full_with_witness.projection_witness = object_ref("unexpected-witness");
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            full_with_witness, ordered_targets, view));
    auto projected_without_witness = valid;
    projected_without_witness.structurally_witnessed_projection = true;
    CHECK_FALSE(
        mwperf::artifact::detail::validate_common_schedule_realization_v1(
            projected_without_witness, ordered_targets, view));
  }
}

TEST_CASE("C15 F07 exposes a built artifact only for the exact sealed request",
          "[c15][integration]") {
  const auto accepted_input = make_protocol_input_fixture(
      R"json({"kind":"stationary_unique","parameters":{}})json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}},{"id":"empty","kind":"stationary_empty_probability","parameters":{}}])json");
  const auto expected_artifact = artifact_for_payload(three_bin_payload());
  const auto sealed = Factory::validated_result(
      Factory::validated_built_result(
          Factory::validated_artifact(expected_artifact)),
      accepted_input.requirements);

  auto exact = mwperf::resolve_realized_metric_capabilities(
      sealed, accepted_input.requirements);
  const auto* built =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&exact);
  REQUIRE(built != nullptr);
  CHECK(built->artifact.value() == expected_artifact);
  REQUIRE(built->satisfied_clauses.size() ==
          accepted_input.requirements.clauses().size());
  for (std::size_t index = 0U; index < built->satisfied_clauses.size();
       ++index) {
    CHECK(built->satisfied_clauses[index] ==
          accepted_input.requirements.clauses()[index].origin.clause_id);
  }
  REQUIRE(mwperf::adapt_portable_payload(built->artifact));

  const auto subset_input = make_protocol_input_fixture();
  const auto different_input = make_protocol_input_fixture(
      R"json({"kind":"stationary_unique","parameters":{}})json",
      R"json([{"id":"different","kind":"stationary_backlog_moment","parameters":{"order":2}}])json");
  const std::array<mwperf::MetricRequest, 0U> no_requests{};
  const auto empty = mwperf::aggregate_metric_requirements(no_requests);
  const std::array mismatches{subset_input.requirements, empty,
                              different_input.requirements};
  for (const auto& mismatch : mismatches) {
    auto report =
        mwperf::resolve_realized_metric_capabilities(sealed, mismatch);
    const auto* failed =
        std::get_if<mwperf::RealizedFailedCapabilitiesV1>(&report);
    REQUIRE(failed != nullptr);
    CHECK(failed->failure.kind ==
          mwperf::ProviderFailureKindV1::invariant_violation);
    CHECK(failed->failure.code == "requirements_not_exactly_accepted");
  }
}

TEST_CASE("C15 F07 preserves unavailable and failed terminal values verbatim",
          "[c15][unit]") {
  const auto input = make_protocol_input_fixture();
  const mwperf::ResultEnvelopeV1 envelope{
      1U, digest_of("request"), provider(), build_report()};
  const mwperf::UnavailableSurrogateResultV1 unavailable_value{
      envelope,
      {{mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
        "fixture.evidence-unavailable", "fixture evidence is unavailable",
        clause_id("throughput"), object_ref("missing-evidence")}},
      std::nullopt};
  const auto unavailable = Factory::validated_result(
      mwperf::ValidatedUnavailableResultV1{unavailable_value},
      input.requirements);
  const std::array<mwperf::MetricRequest, 0U> no_requests{};
  const auto empty = mwperf::aggregate_metric_requirements(no_requests);
  const auto unavailable_report =
      mwperf::resolve_realized_metric_capabilities(unavailable, empty);
  const auto* preserved_unavailable =
      std::get_if<mwperf::RealizedUnavailableCapabilitiesV1>(
          &unavailable_report);
  REQUIRE(preserved_unavailable != nullptr);
  CHECK(preserved_unavailable->reasons == unavailable_value.reasons);

  const mwperf::FailedSurrogateResultV1 failed_value{
      envelope,
      {mwperf::ProviderFailureKindV1::provider_internal_error,
       "fixture.provider-error", "fixture provider error"}};
  const auto failed = Factory::validated_result(
      mwperf::ValidatedFailedResultV1{failed_value}, input.requirements);
  const auto failed_report =
      mwperf::resolve_realized_metric_capabilities(failed, empty);
  const auto* preserved_failed =
      std::get_if<mwperf::RealizedFailedCapabilitiesV1>(&failed_report);
  REQUIRE(preserved_failed != nullptr);
  CHECK(preserved_failed->failure == failed_value.failure);
}

TEST_CASE("C15 F06 validates every unavailable and failed terminal reason",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.terminals", mwperf::MasterSeed(101U));
  const auto report = sealed_report_for(fixture);
  const auto trusted = Factory::validated_build_report(report);
  const mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};

  const std::array unavailable_kinds{
      mwperf::UnavailableReasonKindV1::inapplicable_target_structure,
      mwperf::UnavailableReasonKindV1::coefficient_proved_zero,
      mwperf::UnavailableReasonKindV1::coefficient_unresolved,
      mwperf::UnavailableReasonKindV1::interval_only_without_authorized_point,
      mwperf::UnavailableReasonKindV1::unmet_construction_assumption,
      mwperf::UnavailableReasonKindV1::construction_domain_unavailable,
      mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
      mwperf::UnavailableReasonKindV1::
          realized_capability_narrower_than_accepted};
  for (std::size_t index = 0U; index < unavailable_kinds.size(); ++index) {
    const auto kind = unavailable_kinds[index];
    const bool requires_clause =
        kind == mwperf::UnavailableReasonKindV1::coefficient_proved_zero ||
        kind == mwperf::UnavailableReasonKindV1::coefficient_unresolved ||
        kind == mwperf::UnavailableReasonKindV1::
                    interval_only_without_authorized_point ||
        kind == mwperf::UnavailableReasonKindV1::
                    required_evidence_unavailable ||
        kind == mwperf::UnavailableReasonKindV1::
                    realized_capability_narrower_than_accepted;
    const bool requires_subject =
        kind == mwperf::UnavailableReasonKindV1::coefficient_proved_zero ||
        kind == mwperf::UnavailableReasonKindV1::coefficient_unresolved ||
        kind == mwperf::UnavailableReasonKindV1::
                    interval_only_without_authorized_point;
    const mwperf::UnavailableReasonV1 reason{
        kind, "fixture.unavailable." + std::to_string(index),
        "fixture scientific construction is unavailable",
        requires_clause
            ? std::optional<mwperf::MetricClauseIdV1>{
                  input.requirements.clauses().front().origin.clause_id}
            : std::nullopt,
        requires_subject
            ? std::optional<mwperf::ArtifactObjectReferenceV1>{
                  object_ref("unavailable-subject")}
            : std::nullopt};
    const mwperf::UnavailableSurrogateResultV1 value{
        envelope, {reason}, std::nullopt};
    auto validated = mwperf::validate_surrogate_build_result(
        value, fixture.request, fixture.manifest, fixture.contract, trusted);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
    auto realized = mwperf::resolve_realized_metric_capabilities(
        validated.value(), input.requirements);
    const auto* preserved =
        std::get_if<mwperf::RealizedUnavailableCapabilitiesV1>(&realized);
    REQUIRE(preserved != nullptr);
    CHECK(preserved->reasons == value.reasons);
  }

  const auto clause = input.requirements.clauses().front().origin.clause_id;
  const mwperf::UnavailableSurrogateResultV1 multiple_conditions{
      envelope,
      {{mwperf::UnavailableReasonKindV1::coefficient_unresolved,
        "fixture.unresolved.one", "first unresolved construction condition",
        clause, object_ref("coefficient-1")},
       {mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
        "fixture.evidence.two", "a distinct required proof is unavailable",
        clause, object_ref("validity-proof")}},
      std::nullopt};
  auto multiple_validated = mwperf::validate_surrogate_build_result(
      multiple_conditions, fixture.request, fixture.manifest,
      fixture.contract, trusted);
  INFO((multiple_validated
            ? std::string{}
            : multiple_validated.error().code + ": " +
                  multiple_validated.error().message));
  REQUIRE(multiple_validated);

  const std::array failure_kinds{
      mwperf::ProviderFailureKindV1::construction_failure,
      mwperf::ProviderFailureKindV1::resource_exhausted,
      mwperf::ProviderFailureKindV1::invariant_violation,
      mwperf::ProviderFailureKindV1::provider_internal_error};
  for (std::size_t index = 0U; index < failure_kinds.size(); ++index) {
    const mwperf::FailedSurrogateResultV1 value{
        envelope,
        {failure_kinds[index], "fixture.failure." + std::to_string(index),
         "fixture provider failure"}};
    auto validated = mwperf::validate_surrogate_build_result(
        value, fixture.request, fixture.manifest, fixture.contract, trusted);
    REQUIRE(validated);
    auto realized = mwperf::resolve_realized_metric_capabilities(
        validated.value(), input.requirements);
    const auto* preserved =
        std::get_if<mwperf::RealizedFailedCapabilitiesV1>(&realized);
    REQUIRE(preserved != nullptr);
    CHECK(preserved->failure == value.failure);
  }
}

TEST_CASE("C15 F06 rejects incomplete duplicate or malformed terminal reasons",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.bad-terminals", mwperf::MasterSeed(103U));
  const auto report = sealed_report_for(fixture);
  const auto trusted = Factory::validated_build_report(report);
  const mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, report};
  const mwperf::UnavailableReasonV1 reason{
      mwperf::UnavailableReasonKindV1::coefficient_unresolved,
      "fixture.unresolved", "fixture unresolved coefficient",
      input.requirements.clauses().front().origin.clause_id,
      object_ref("coefficient")};

  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      mwperf::UnavailableSurrogateResultV1{envelope, {}, std::nullopt},
      fixture.request, fixture.manifest, fixture.contract, trusted));
  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      mwperf::UnavailableSurrogateResultV1{envelope, {reason, reason},
                                           std::nullopt},
      fixture.request, fixture.manifest, fixture.contract, trusted));
  auto missing_subject = reason;
  missing_subject.subject.reset();
  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      mwperf::UnavailableSurrogateResultV1{envelope, {missing_subject},
                                           std::nullopt},
      fixture.request, fixture.manifest, fixture.contract, trusted));
  auto unknown_clause = reason;
  unknown_clause.metric_clause_id = clause_id("unknown");
  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      mwperf::UnavailableSurrogateResultV1{envelope, {unknown_clause},
                                           std::nullopt},
      fixture.request, fixture.manifest, fixture.contract, trusted));
  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      mwperf::FailedSurrogateResultV1{
          envelope,
          {mwperf::ProviderFailureKindV1::provider_internal_error, "", ""}},
      fixture.request, fixture.manifest, fixture.contract, trusted));
  const mwperf::UnavailableSurrogateResultV1 invalid_alternative{
      envelope,
      {reason},
      mwperf::StrongestTruthfulAlternativeV1{
          "invalid closed payload tag",
          mwperf::PayloadClassV1{
              static_cast<mwperf::PayloadClassTagV1>(255U), 1U},
          mwperf::MetricResultScopeV1::surrogate_law}};
  CHECK_FALSE(mwperf::validate_surrogate_build_result(
      invalid_alternative, fixture.request, fixture.manifest,
      fixture.contract, trusted));
}

TEST_CASE("C15 F06 seals one exact request-bound Built artifact",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.built", mwperf::MasterSeed(107U));
  const auto built = make_bound_built_fixture(fixture);
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{built.result});
  REQUIRE(encoded);
  auto parsed = mwperf::parse_surrogate_build_result(
      encoded.value(), generous_parse_limits());
  INFO((parsed ? std::string{}
               : parsed.error().code + ": " + parsed.error().message));
  REQUIRE(parsed);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), fixture.request, fixture.manifest, fixture.contract,
      built.validated_report);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  REQUIRE(capabilities->satisfied_clauses.size() == 1U);
  CHECK(capabilities->satisfied_clauses.front() == clause_id("throughput"));
  auto adapted = mwperf::adapt_portable_payload(capabilities->artifact);
  REQUIRE(adapted);
  CHECK(std::holds_alternative<mwperf::PortableThreeBinScalarResponseV1>(
      adapted.value().value()));
}

TEST_CASE("C15 F06 rejects trusted Built reports beyond the exact grant or request",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.report-limits", mwperf::MasterSeed(179U));

  const auto validate_with_report =
      [&](mwperf::CommonBuildReportV1 report) {
        auto digest = mwperf::canonical_common_build_report_digest_v1(report);
        REQUIRE(digest);
        report.report_digest = std::move(digest).value();
        auto built = make_bound_built_fixture(fixture);
        built.result.envelope.build_report = report;
        built.result.artifact.build_report_echo = report;
        return mwperf::validate_surrogate_build_result(
            built.result, fixture.request, fixture.manifest, fixture.contract,
            Factory::validated_build_report(std::move(report)));
      };

  SECTION("an applicable zero generator grant is not unlimited") {
    auto report = sealed_report_for(fixture);
    report.configured_generator_draws.used = mwperf::BigNat{1U};
    const auto validated = validate_with_report(std::move(report));
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c15.report_budget_exceeded");
  }

  SECTION("a separately sealed report cannot name another request") {
    auto report = sealed_report_for(fixture);
    report.request_digest = digest_of("foreign-report-request");
    const auto validated = validate_with_report(std::move(report));
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c15.report_request_digest");
  }
}

TEST_CASE("C15 F06 validates all five response-product stages",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.all-product-stages", mwperf::MasterSeed(110U), 0U,
      all_stage_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_recoded_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion,
      mwperf::ProjectionPolicyV1::convex_feasible_mean,
      mwperf::RecodingPolicyV1::mean_inversion);
  const auto built = make_bound_built_fixture(
      fixture, bound_all_stage_three_bin_payload(fixture));
  auto validated = validate_bound_built(fixture, built);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);

  const auto& response = std::get<mwperf::ThreeBinScalarResponseV1>(
      built.result.artifact.payload);
  REQUIRE(response.nominal_response.has_value());
  REQUIRE(response.projection_center.has_value());
  REQUIRE(response.projected_mean.has_value());
  REQUIRE(response.recoded_response.has_value());
  CHECK(std::holds_alternative<mwperf::RecodedResponseProductId>(
      response.deployed_response_product_id));

  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), input.requirements);
  const auto* capabilities =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(capabilities != nullptr);
  auto adapted = mwperf::adapt_portable_payload(capabilities->artifact);
  REQUIRE(adapted);
  const auto* portable =
      std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
          &adapted.value().value());
  REQUIRE(portable != nullptr);
  CHECK(portable->normalized_record.deployed_response_product_id ==
        response.deployed_response_product_id);
}

TEST_CASE("C15 F06 compression evidence uses exact recoded lineage",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  struct LineageCase final {
    const char* name;
    CompressionLineageFixtureV1 lineage;
    mwperf::CoefficientCompletionPolicyV1 completion;
    mwperf::ProjectionPolicyV1 projection;
    mwperf::RecodingPolicyV1 recoding;
  };
  const std::array lineages{
      LineageCase{"raw response parent",
                  CompressionLineageFixtureV1::raw_parent,
                  mwperf::CoefficientCompletionPolicyV1::
                      declared_nominal_completion,
                  mwperf::ProjectionPolicyV1::convex_feasible_mean,
                  mwperf::RecodingPolicyV1::identity},
      LineageCase{"nominal response parent",
                  CompressionLineageFixtureV1::nominal_parent,
                  mwperf::CoefficientCompletionPolicyV1::
                      declared_nominal_completion,
                  mwperf::ProjectionPolicyV1::convex_feasible_mean,
                  mwperf::RecodingPolicyV1::mean_inversion},
      LineageCase{"coefficient completion source",
                  CompressionLineageFixtureV1::completion_source,
                  mwperf::CoefficientCompletionPolicyV1::
                      authorized_endpoint_completion,
                  mwperf::ProjectionPolicyV1::not_applicable,
                  mwperf::RecodingPolicyV1::mean_inversion}};

  const auto make_case = [&](const LineageCase& item,
                             const std::uint64_t seed) {
    auto fixture = make_bound_request_fixture(
        input, mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder,
        "c15.fixture.compression-" + std::to_string(seed),
        mwperf::MasterSeed(seed), 0U,
        compression_scalar_manifest(item.lineage),
        mwperf::PointDeploymentPolicyV1::deploy_recoded_point,
        item.completion, item.projection, item.recoding);
    auto built = make_bound_built_fixture(
        fixture, bound_compression_three_bin_payload(fixture, item.lineage));
    return std::pair{std::move(fixture), std::move(built)};
  };

  std::uint64_t seed = 181U;
  for (const auto& item : lineages) {
    DYNAMIC_SECTION(item.name << " is accepted") {
      auto [fixture, built] = make_case(item, seed++);
      auto validated = validate_bound_built(fixture, built);
      INFO((validated ? std::string{}
                      : validated.error().code + ": " +
                            validated.error().message));
      REQUIRE(validated);
    }
  }

  const LineageCase raw_case = lineages.front();
  SECTION("an unrelated retained nominal product is not a compression source") {
    auto [fixture, built] = make_case(raw_case, 187U);
    auto& payload = std::get<mwperf::ThreeBinScalarResponseV1>(
        built.result.artifact.payload);
    REQUIRE(payload.nominal_response.has_value());
    const auto unrelated = payload.nominal_response->product_id.identity();
    auto& binding = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto evidence_identity =
        mwperf::realized_reference_subject_v1(binding.reference);
    const auto scoped = std::find_if(
        built.result.artifact.scoped_evidence.begin(),
        built.result.artifact.scoped_evidence.end(),
        [&evidence_identity](const auto& evidence) {
          return evidence.evidence_id == evidence_identity;
        });
    REQUIRE(scoped != built.result.artifact.scoped_evidence.end());
    const auto replace_source = [&](auto& relations) {
      const auto source = std::find_if(
          relations.begin(), relations.end(), [](const auto& relation) {
            return relation.purpose ==
                   mwperf::InternalReferencePurposeV1::compression_source;
          });
      REQUIRE(source != relations.end());
      const auto prior = source->referenced_object;
      source->referenced_object = unrelated;
      return prior;
    };
    const auto prior = replace_source(scoped->internal_references);
    const auto subject = std::find(scoped->subject_references.begin(),
                                   scoped->subject_references.end(), prior);
    REQUIRE(subject != scoped->subject_references.end());
    *subject = unrelated;
    std::sort(scoped->subject_references.begin(),
              scoped->subject_references.end());
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        binding.reference);
    CHECK(replace_source(core.internal_relations) == prior);
    reseal_scoped_evidence_for_role(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c15.object_graph_compression_source");
  }

  SECTION("a compression rule cannot alias the payload object") {
    auto [fixture, built] = make_case(raw_case, 191U);
    auto& binding = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto evidence_identity =
        mwperf::realized_reference_subject_v1(binding.reference);
    const auto scoped = std::find_if(
        built.result.artifact.scoped_evidence.begin(),
        built.result.artifact.scoped_evidence.end(),
        [&evidence_identity](const auto& evidence) {
          return evidence.evidence_id == evidence_identity;
        });
    REQUIRE(scoped != built.result.artifact.scoped_evidence.end());
    const auto alias_rule = [&](auto& relations) {
      const auto rule = std::find_if(
          relations.begin(), relations.end(), [](const auto& relation) {
            return relation.purpose ==
                   mwperf::InternalReferencePurposeV1::compression_rule;
          });
      REQUIRE(rule != relations.end());
      rule->referenced_object = built.result.artifact.payload_identity;
    };
    alias_rule(scoped->internal_references);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        binding.reference);
    alias_rule(core.internal_relations);
    reseal_scoped_evidence_for_role(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_internal_reference_kind");
  }

  SECTION("a compression source cannot alias an evidence object") {
    auto [fixture, built] = make_case(raw_case, 193U);
    auto& binding = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto compression_identity =
        mwperf::realized_reference_subject_v1(binding.reference);
    const auto validity = std::find_if(
        built.result.artifact.scoped_evidence.begin(),
        built.result.artifact.scoped_evidence.end(),
        [](const auto& evidence) {
          return evidence.reference_kind ==
                 mwperf::ArtifactReferenceKindV1::
                     reported_validity_or_lift_evidence;
        });
    REQUIRE(validity != built.result.artifact.scoped_evidence.end());
    const auto scoped = std::find_if(
        built.result.artifact.scoped_evidence.begin(),
        built.result.artifact.scoped_evidence.end(),
        [&compression_identity](const auto& evidence) {
          return evidence.evidence_id == compression_identity;
        });
    REQUIRE(scoped != built.result.artifact.scoped_evidence.end());
    const auto alias_source = [&](auto& relations) {
      const auto source = std::find_if(
          relations.begin(), relations.end(), [](const auto& relation) {
            return relation.purpose ==
                   mwperf::InternalReferencePurposeV1::compression_source;
          });
      REQUIRE(source != relations.end());
      const auto prior = source->referenced_object;
      source->referenced_object = validity->evidence_id;
      return prior;
    };
    const auto prior = alias_source(scoped->internal_references);
    const auto subject = std::find(scoped->subject_references.begin(),
                                   scoped->subject_references.end(), prior);
    REQUIRE(subject != scoped->subject_references.end());
    *subject = validity->evidence_id;
    std::sort(scoped->subject_references.begin(),
              scoped->subject_references.end());
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        binding.reference);
    CHECK(alias_source(core.internal_relations) == prior);
    reseal_scoped_evidence_for_role(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::compression_evidence);
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_internal_reference_kind");
  }
}

TEST_CASE("C15 F06 rejects noncanonical or unknown three-bin bindings",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.bin-order", mwperf::MasterSeed(108U));
  auto response = bound_three_bin_payload(fixture);

  SECTION("identification order does not match one two tail") {
    std::swap(response.raw_response.identifications[0U],
              response.raw_response.identifications[1U]);
    reseal_raw_only_bound_response(response);
    const auto built = make_bound_built_fixture(fixture, std::move(response));
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("closed target-bin enum rejects an unknown value") {
    response.raw_response.identifications[1U].target_bin_binding =
        static_cast<mwperf::ThreeBinCoefficientV1>(255U);
    reseal_raw_only_bound_response(response);
    const auto built = make_bound_built_fixture(fixture, std::move(response));
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
}

TEST_CASE("C15 F06 accepts non-prefix interval evidence with late-bound seals",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto interval_manifest = interval_scalar_manifest();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.interval", mwperf::MasterSeed(111U), 0U,
      interval_manifest,
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
  auto interval = make_bound_interval_response(fixture);
  REQUIRE(interval.response.raw_envelopes.size() == 1U);
  CHECK(interval.response.raw_envelopes.front().covered_bins ==
        std::vector<mwperf::ThreeBinCoefficientV1>{
            mwperf::ThreeBinCoefficientV1::two});

  const mwperf::ArtifactPayloadV1 payload = interval.response;
  auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(payload);
  auto payload_bytes = mwperf::canonical_artifact_payload_bytes_v1(payload);
  REQUIRE(payload_digest);
  REQUIRE(payload_bytes);

  auto digest_only_mutation = interval.response;
  const auto foreign_evidence_digest = digest_of("foreign-interval-evidence");
  digest_only_mutation.raw_response.identifications[1U]
      .family_evidence_envelope_ids.front()
      .object_digest = foreign_evidence_digest;
  digest_only_mutation.raw_envelopes.front()
      .family_evidence_envelope_ids.front()
      .object_digest = foreign_evidence_digest;
  const mwperf::ArtifactPayloadV1 digest_only_payload = digest_only_mutation;
  auto digest_only_digest =
      mwperf::canonical_artifact_payload_digest_v1(digest_only_payload);
  auto digest_only_bytes =
      mwperf::canonical_artifact_payload_bytes_v1(digest_only_payload);
  REQUIRE(digest_only_digest);
  REQUIRE(digest_only_bytes);
  CHECK(digest_only_digest.value() == payload_digest.value());
  CHECK(digest_only_bytes.value() != payload_bytes.value());

  auto object_id_mutation = interval.response;
  object_id_mutation.raw_response.identifications[1U]
      .family_evidence_envelope_ids.front()
      .object_id = label("foreign-interval-evidence-id");
  object_id_mutation.raw_envelopes.front()
      .family_evidence_envelope_ids.front()
      .object_id = label("foreign-interval-evidence-id");
  const mwperf::ArtifactPayloadV1 object_id_payload = object_id_mutation;
  auto object_id_digest =
      mwperf::canonical_artifact_payload_digest_v1(object_id_payload);
  REQUIRE(object_id_digest);
  CHECK(object_id_digest.value() != payload_digest.value());

  const auto built = make_bound_built_fixture(
      fixture, interval.response, {interval.interval_evidence});
  auto validated = validate_bound_built(fixture, built);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
}

TEST_CASE("C15 F06 preserves realizable coefficient statuses and rejects unproved absence",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();

  SECTION("proved-positive exact-population point") {
    const auto fixture = make_bound_request_fixture(
        input, mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder,
        "c15.fixture.status-exact-point", mwperf::MasterSeed(151U));
    const auto built = make_bound_built_fixture(fixture);
    auto validated = validate_bound_built(fixture, built);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
  }

  struct StatusCase final {
    const char* name;
    mwperf::ProposalConditioningSourceV1 source;
    mwperf::PopulationConditioningStatusV1 population;
    mwperf::RawValueStatusV1 raw;
  };
  const std::array cases{
      StatusCase{"proved-positive exact-population interval",
                 mwperf::ProposalConditioningSourceV1::exact_population,
                 mwperf::PopulationConditioningStatusV1::proved_positive,
                 mwperf::RawValueStatusV1::interval_only},
      StatusCase{"positive-with-confidence empirical interval",
                 mwperf::ProposalConditioningSourceV1::empirical_average,
                 mwperf::PopulationConditioningStatusV1::
                     positive_with_confidence,
                 mwperf::RawValueStatusV1::interval_only},
      StatusCase{"unresolved exact-population interval",
                 mwperf::ProposalConditioningSourceV1::exact_population,
                 mwperf::PopulationConditioningStatusV1::unresolved,
                 mwperf::RawValueStatusV1::interval_only}};
  for (std::size_t index = 0U; index < cases.size(); ++index) {
    const auto& status_case = cases[index];
    DYNAMIC_SECTION(status_case.name) {
      const auto fixture = make_bound_request_fixture(
          input, mwperf::ConstructionMethodV1::engineered_deterministic,
          mwperf::ProducerModeV1::in_process_builder,
          "c15.fixture.status-valid-" + std::to_string(index),
          mwperf::MasterSeed(152U + index), 0U,
          interval_scalar_manifest(),
          mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
          mwperf::CoefficientCompletionPolicyV1::
              declared_nominal_completion);
      auto response = make_bound_closed_status_response(
          fixture, status_case.source, status_case.population,
          status_case.raw);
      const auto built = make_bound_built_fixture(
          fixture, std::move(response.response),
          {std::move(response.interval_evidence)});
      auto validated = validate_bound_built(fixture, built);
      INFO((validated ? std::string{}
                      : validated.error().code + ": " +
                            validated.error().message));
      REQUIRE(validated);
    }
  }

  SECTION("proved-zero exact-population absence with family proof") {
    const auto fixture = make_bound_request_fixture(
        input, mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder,
        "c15.fixture.status-proved-zero", mwperf::MasterSeed(156U), 0U,
        interval_scalar_manifest(),
        mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
        mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
    auto response = make_bound_absence_response(fixture);
    const auto built = make_bound_built_fixture(
        fixture, std::move(response.response),
        {std::move(response.interval_evidence)});
    auto validated = validate_bound_built(fixture, built);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
  }

  SECTION("unresolved absence is wire-valid but cannot fulfill raw bound") {
    const auto fixture = make_bound_request_fixture(
        input, mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder,
        "c15.fixture.status-unresolved-absence", mwperf::MasterSeed(157U), 0U,
        interval_scalar_manifest(),
        mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
        mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
    auto response = make_bound_absence_response(
        fixture, mwperf::PopulationConditioningStatusV1::unresolved);
    const auto built = make_bound_built_fixture(
        fixture, std::move(response.response),
        {std::move(response.interval_evidence)});
    auto encoded =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{built.result});
    REQUIRE(encoded);
    auto parsed = mwperf::parse_surrogate_build_result(
        encoded.value(), generous_parse_limits());
    REQUIRE(parsed);
    auto rejected = mwperf::validate_surrogate_build_result(
        parsed.value(), fixture.request, fixture.manifest, fixture.contract,
        built.validated_report);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.object_graph_raw_bound_absence_proof");
  }
}

TEST_CASE("C15 F06 rejects every other coefficient-status cross-product",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.status-cross-product", mwperf::MasterSeed(158U));
  const std::array sources{
      mwperf::ProposalConditioningSourceV1::exact_population,
      mwperf::ProposalConditioningSourceV1::empirical_average};
  const std::array populations{
      mwperf::PopulationConditioningStatusV1::proved_positive,
      mwperf::PopulationConditioningStatusV1::proved_zero,
      mwperf::PopulationConditioningStatusV1::positive_with_confidence,
      mwperf::PopulationConditioningStatusV1::unresolved};
  const std::array raw_statuses{
      mwperf::RawValueStatusV1::exact_point,
      mwperf::RawValueStatusV1::interval_only,
      mwperf::RawValueStatusV1::absent};

  for (const auto source : sources) {
    for (const auto population : populations) {
      for (const auto raw : raw_statuses) {
        const bool accepted_shape =
            (source ==
                 mwperf::ProposalConditioningSourceV1::exact_population &&
             population == mwperf::PopulationConditioningStatusV1::
                               proved_positive &&
             (raw == mwperf::RawValueStatusV1::exact_point ||
              raw == mwperf::RawValueStatusV1::interval_only)) ||
            (source ==
                 mwperf::ProposalConditioningSourceV1::empirical_average &&
             population == mwperf::PopulationConditioningStatusV1::
                               positive_with_confidence &&
             raw == mwperf::RawValueStatusV1::interval_only) ||
            (population ==
                 mwperf::PopulationConditioningStatusV1::unresolved &&
             (raw == mwperf::RawValueStatusV1::interval_only ||
              raw == mwperf::RawValueStatusV1::absent)) ||
            (source ==
                 mwperf::ProposalConditioningSourceV1::exact_population &&
             population ==
                 mwperf::PopulationConditioningStatusV1::proved_zero &&
             raw == mwperf::RawValueStatusV1::absent);
        if (accepted_shape) continue;

        CAPTURE(static_cast<unsigned int>(source),
                static_cast<unsigned int>(population),
                static_cast<unsigned int>(raw));
        auto response = bound_three_bin_payload(fixture);
        auto& identification = response.raw_response.identifications[1U];
        identification.proposal_conditioning.source = source;
        identification.proposal_conditioning.frozen_evaluation_id =
            source ==
                    mwperf::ProposalConditioningSourceV1::empirical_average
                ? std::optional<mwperf::TypedLabel>{
                      label("interval-evaluation")}
                : std::nullopt;
        identification.coefficient_status = {population, raw};
        identification.raw_point =
            raw == mwperf::RawValueStatusV1::exact_point
                ? std::optional<mwperf::PortableScientificScalar>{
                      scalar(1, 2)}
                : std::nullopt;
        reseal_raw_only_bound_response(response);
        const auto built =
            make_bound_built_fixture(fixture, std::move(response));
        auto validated = validate_bound_built(fixture, built);
        REQUIRE_FALSE(validated);
        CHECK(validated.error().code == "c15.coefficient_status_combination");
      }
    }
  }
}

TEST_CASE("C15 F06 rejects coefficient status field-presence mismatches",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.status-fields", mwperf::MasterSeed(159U));

  const auto validate_mutation = [&](auto mutate) {
    auto response = bound_three_bin_payload(fixture);
    mutate(response.raw_response.identifications[1U]);
    reseal_raw_only_bound_response(response);
    const auto built =
        make_bound_built_fixture(fixture, std::move(response));
    return validate_bound_built(fixture, built);
  };
  SECTION("exact point requires its point") {
    auto result = validate_mutation([](auto& identification) {
      identification.raw_point = std::nullopt;
    });
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c15.coefficient_status_combination");
  }
  SECTION("interval forbids a point") {
    auto result = validate_mutation([](auto& identification) {
      identification.coefficient_status.raw_value_status =
          mwperf::RawValueStatusV1::interval_only;
    });
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c15.coefficient_status_combination");
  }
  SECTION("empirical source requires frozen evaluation") {
    auto result = validate_mutation([](auto& identification) {
      identification.proposal_conditioning.source =
          mwperf::ProposalConditioningSourceV1::empirical_average;
      identification.coefficient_status = {
          mwperf::PopulationConditioningStatusV1::positive_with_confidence,
          mwperf::RawValueStatusV1::interval_only};
      identification.raw_point = std::nullopt;
    });
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c15.coefficient_frozen_evaluation_binding");
  }
  SECTION("exact-population source forbids frozen evaluation") {
    auto result = validate_mutation([](auto& identification) {
      identification.proposal_conditioning.frozen_evaluation_id =
          label("spurious-evaluation");
    });
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c15.coefficient_frozen_evaluation_binding");
  }
}

TEST_CASE("C15 F06 resolves complete interval evidence refs and envelope sets",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.interval-graph", mwperf::MasterSeed(112U), 0U,
      interval_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
  const auto validate_raw_envelope_mutation =
      [&](BoundIntervalResponseFixture interval) {
        reseal_interval_family_backlinks(interval);
        const auto built = make_bound_built_fixture(
            fixture, interval.response, {interval.interval_evidence});
        return validate_bound_built(fixture, built);
      };

  SECTION("raw envelope rejects lower greater than upper") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front().lower.front() = scalar(7, 8);
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_domain");
  }

  SECTION("raw envelope rejects a lower bound outside the unit interval") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front().lower.front() = scalar(-1, 4);
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_domain");
  }

  SECTION("raw envelope rejects an upper bound outside the unit interval") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front().upper.front() = scalar(5, 4);
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_domain");
  }

  SECTION("raw envelope must contain its retained exact point") {
    auto interval = make_bound_interval_response(fixture);
    auto& identification =
        interval.response.raw_response.identifications[1U];
    identification.coefficient_status.raw_value_status =
        mwperf::RawValueStatusV1::exact_point;
    identification.raw_point = scalar(3, 4);
    REQUIRE(interval.response.nominal_response.has_value());
    interval.response.nominal_response->coefficients[1U].value =
        scalar(3, 4);
    reseal_status_mutated_interval_response(interval);
    CHECK(identification.coefficient_status.raw_value_status ==
          mwperf::RawValueStatusV1::exact_point);
    REQUIRE(identification.raw_point.has_value());
    CHECK(identification.raw_point->rational_value() == rational(3, 4));
    interval.response.raw_envelopes.front().upper.front() = scalar(1, 2);
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.raw_envelope_excludes_exact_point");
  }

  SECTION("raw envelope must not begin above its retained exact point") {
    auto interval = make_bound_interval_response(fixture);
    auto& identification =
        interval.response.raw_response.identifications[1U];
    identification.coefficient_status.raw_value_status =
        mwperf::RawValueStatusV1::exact_point;
    identification.raw_point = scalar(1, 4);
    REQUIRE(interval.response.nominal_response.has_value());
    interval.response.nominal_response->coefficients[1U].value =
        scalar(1, 4);
    interval.response.raw_envelopes.front().lower.front() = scalar(1, 2);
    reseal_status_mutated_interval_response(interval);
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.raw_envelope_excludes_exact_point");
  }

  SECTION("raw envelope containment includes both endpoints") {
    const std::array endpoints{scalar(1, 4), scalar(3, 4)};
    for (const auto& endpoint : endpoints) {
      auto interval = make_bound_interval_response(fixture);
      auto& identification =
          interval.response.raw_response.identifications[1U];
      identification.coefficient_status.raw_value_status =
          mwperf::RawValueStatusV1::exact_point;
      identification.raw_point = endpoint;
      REQUIRE(interval.response.nominal_response.has_value());
      interval.response.nominal_response->coefficients[1U].value = endpoint;
      reseal_status_mutated_interval_response(interval);
      const auto accepted =
          validate_raw_envelope_mutation(std::move(interval));
      INFO((accepted ? std::string{}
                     : accepted.error().code + ": " +
                           accepted.error().message));
      REQUIRE(accepted);
    }
  }

  SECTION("raw envelope rejects a foreign source product") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front().source_product =
        raw_id("foreign-envelope-source");
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_shape");
  }

  SECTION("raw envelope rejects a foreign construction law") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front().construction_law_digest =
        digest_of("foreign-envelope-construction-law");
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_shape");
  }

  SECTION("every unresolved interval envelope requires a conditional premise") {
    auto interval = make_bound_closed_status_response(
        fixture, mwperf::ProposalConditioningSourceV1::exact_population,
        mwperf::PopulationConditioningStatusV1::unresolved,
        mwperf::RawValueStatusV1::interval_only);
    auto unconditional = interval.response.raw_envelopes.front();
    unconditional.envelope_id =
        object_ref("unresolved-unconditional-envelope");
    unconditional.certification_method =
        "fixture.unresolved-unconditional-interval";
    unconditional.population_conditioning_premise =
        mwperf::PopulationConditioningPremiseV1::unconditional;
    interval.response.raw_envelopes.push_back(std::move(unconditional));
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.unresolved_raw_envelope_premise");
  }

  SECTION("empirical interval rejects deterministic coverage") {
    auto interval = make_bound_closed_status_response(
        fixture, mwperf::ProposalConditioningSourceV1::empirical_average,
        mwperf::PopulationConditioningStatusV1::positive_with_confidence,
        mwperf::RawValueStatusV1::interval_only);
    interval.response.raw_envelopes.front().coverage =
        mwperf::RawEnvelopeCoverageV1::deterministic;
    const auto rejected =
        validate_raw_envelope_mutation(std::move(interval));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.interval_without_bound_evidence");
  }

  SECTION("stale complete evidence digest rejects after projected digests pass") {
    auto interval = make_bound_interval_response(fixture);
    auto built = make_bound_built_fixture(
        fixture, interval.response, {interval.interval_evidence});
    auto& response = std::get<mwperf::ThreeBinScalarResponseV1>(
        built.result.artifact.payload);
    response.raw_response.identifications[1U]
        .family_evidence_envelope_ids.front()
        .object_digest = digest_of("stale-full-evidence-ref");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }

  SECTION("duplicate envelope identity rejects") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.push_back(
        interval.response.raw_envelopes.front());
    reseal_interval_family_backlinks(interval);
    const auto built = make_bound_built_fixture(
        fixture, interval.response, {interval.interval_evidence});
    CHECK_FALSE(validate_bound_built(fixture, built));
  }

  SECTION("every retained raw envelope requires family evidence") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.front()
        .family_evidence_envelope_ids.clear();
    reseal_interval_family_backlinks(interval);
    const auto built = make_bound_built_fixture(
        fixture, interval.response, {interval.interval_evidence});
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c15.interval_without_bound_evidence");
  }

  SECTION("an exact-point raw envelope still requires family evidence") {
    auto exact = make_bound_interval_response(fixture);
    auto& identification =
        exact.response.raw_response.identifications[1U];
    identification.coefficient_status.raw_value_status =
        mwperf::RawValueStatusV1::exact_point;
    identification.raw_point = scalar(1, 2);
    reseal_status_mutated_interval_response(exact);
    const auto complete = make_bound_built_fixture(
        fixture, exact.response, {exact.interval_evidence});
    auto complete_validation = validate_bound_built(fixture, complete);
    INFO((complete_validation
              ? std::string{}
              : complete_validation.error().code + ": " +
                    complete_validation.error().message));
    REQUIRE(complete_validation);

    exact.response.raw_envelopes.front()
        .family_evidence_envelope_ids.clear();
    reseal_interval_family_backlinks(exact);
    const auto incomplete = make_bound_built_fixture(
        fixture, exact.response, {exact.interval_evidence});
    const auto rejected = validate_bound_built(fixture, incomplete);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.raw_envelope_shape");
  }

  SECTION("distinct compatible scopes may cover the same required bin") {
    auto interval = make_bound_interval_response(fixture);
    auto second = interval.response.raw_envelopes.front();
    second.envelope_id = object_ref("bound-bin-two-quadrature-envelope");
    second.certification_method = "fixture.quadrature-bin-two-interval";
    second.scope = mwperf::RawEnvelopeScopeV1::deterministic_quadrature_raw;
    interval.response.raw_envelopes.push_back(std::move(second));
    reseal_interval_family_backlinks(interval);
    const auto built = make_bound_built_fixture(
        fixture, interval.response, {interval.interval_evidence});
    auto validated = validate_bound_built(fixture, built);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
  }

  SECTION("one realized origin may select a member of a multi-bin envelope") {
    auto interval = make_bound_interval_response(fixture);
    auto& envelope = interval.response.raw_envelopes.front();
    envelope.covered_bins = {mwperf::ThreeBinCoefficientV1::one,
                             mwperf::ThreeBinCoefficientV1::two};
    envelope.lower = {scalar(1, 4), scalar(1, 4)};
    envelope.upper = {scalar(1, 4), scalar(3, 4)};
    interval.response.raw_response.identifications[0U]
        .family_evidence_envelope_ids =
        envelope.family_evidence_envelope_ids;
    reseal_status_mutated_interval_response(interval);
    auto built = make_bound_built_fixture(
        fixture, interval.response, {interval.interval_evidence});
    const auto family = std::find_if(
        built.result.artifact.family_evidence.begin(),
        built.result.artifact.family_evidence.end(), [](const auto& evidence) {
          return evidence.evidence_scope_tag ==
                 mwperf::MetricEvidenceScopeV1::raw_static_proposal;
        });
    REQUIRE(family != built.result.artifact.family_evidence.end());
    const auto& subjects = family->subject_references;
    CHECK(std::find(subjects.begin(), subjects.end(), envelope.envelope_id) !=
          subjects.end());
    CHECK(std::find(
              subjects.begin(), subjects.end(),
              interval.response.raw_response.identifications[0U]
                  .coefficient_id) != subjects.end());
    CHECK(std::find(
              subjects.begin(), subjects.end(),
              interval.response.raw_response.identifications[1U]
                  .coefficient_id) != subjects.end());
    auto validated = validate_bound_built(fixture, built);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);

    auto& raw_bound = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::raw_response_bound_evidence);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        raw_bound.reference);
    const auto origin = std::find_if(
        core.internal_relations.begin(), core.internal_relations.end(),
        [](const auto& relation) {
          return relation.purpose ==
                 mwperf::InternalReferencePurposeV1::coefficient_origin;
        });
    REQUIRE(origin != core.internal_relations.end());
    const auto invalid_origin =
        interval.response.raw_response.identifications[2U].coefficient_id;
    origin->referenced_object = invalid_origin;
    auto& raw_response = realized_binding(
        built.result.artifact, mwperf::MetricSupportRoleV1::raw_response);
    auto& raw_core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        raw_response.reference);
    const auto raw_origin = std::find_if(
        raw_core.internal_relations.begin(), raw_core.internal_relations.end(),
        [](const auto& relation) {
          return relation.purpose ==
                 mwperf::InternalReferencePurposeV1::coefficient_origin;
        });
    REQUIRE(raw_origin != raw_core.internal_relations.end());
    raw_origin->referenced_object = invalid_origin;
    auto rejected = validate_bound_built(fixture, built);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.object_graph_raw_envelope_internal_binding");
  }
}

TEST_CASE("C15 F06 resolves family-backed proved-zero absence evidence",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.absence-proof", mwperf::MasterSeed(167U), 0U,
      interval_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);

  const auto make_complete = [&]() {
    auto absence = make_bound_absence_response(fixture);
    return make_bound_built_fixture(
        fixture, std::move(absence.response),
        {std::move(absence.interval_evidence)});
  };
  const auto complete = make_complete();
  const auto& response = std::get<mwperf::ThreeBinScalarResponseV1>(
      complete.result.artifact.payload);
  CHECK(response.raw_envelopes.empty());
  const auto& absent = response.raw_response.identifications[1U];
  CHECK(absent.coefficient_status.population_conditioning_status ==
        mwperf::PopulationConditioningStatusV1::proved_zero);
  CHECK(absent.coefficient_status.raw_value_status ==
        mwperf::RawValueStatusV1::absent);
  REQUIRE_FALSE(absent.family_evidence_envelope_ids.empty());
  const auto raw_bound = std::find_if(
      complete.result.artifact.realized_metric_bindings.bindings.begin(),
      complete.result.artifact.realized_metric_bindings.bindings.end(),
      [](const auto& binding) {
        return binding.key.role ==
               mwperf::MetricSupportRoleV1::raw_response_bound_evidence;
      });
  REQUIRE(raw_bound !=
          complete.result.artifact.realized_metric_bindings.bindings.end());
  CHECK(std::holds_alternative<
        mwperf::RawResponseBoundEvidenceReferenceV1>(raw_bound->reference));
  const auto bound_subject =
      mwperf::realized_reference_subject_v1(raw_bound->reference);
  CHECK(std::any_of(
      complete.result.artifact.scoped_evidence.begin(),
      complete.result.artifact.scoped_evidence.end(),
      [&bound_subject](const auto& evidence) {
        return evidence.evidence_id == bound_subject &&
               evidence.reference_kind ==
                   mwperf::ArtifactReferenceKindV1::
                       raw_response_bound_evidence;
      }));
  auto complete_validation = validate_bound_built(fixture, complete);
  INFO((complete_validation
            ? std::string{}
            : complete_validation.error().code + ": " +
                  complete_validation.error().message));
  REQUIRE(complete_validation);

  SECTION("unresolved absence without a proof cannot fulfill a raw-bound role") {
    auto unresolved = make_bound_absence_response(
        fixture, mwperf::PopulationConditioningStatusV1::unresolved, false);
    const auto built =
        make_bound_built_fixture(fixture, std::move(unresolved.response));
    CHECK_FALSE(validate_bound_built(fixture, built));
  }

  SECTION("interval-only data still needs a numerical envelope") {
    auto interval = make_bound_interval_response(fixture);
    interval.response.raw_envelopes.clear();
    reseal_status_mutated_interval_response(interval);
    const auto built = make_bound_built_fixture(
        fixture, std::move(interval.response),
        {std::move(interval.interval_evidence)});
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c15.interval_without_bound_evidence");
  }

  SECTION("scoped proof must repeat the coefficient family reference") {
    auto built = make_complete();
    auto& binding = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::raw_response_bound_evidence);
    const auto subject =
        mwperf::realized_reference_subject_v1(binding.reference);
    const auto scoped = std::find_if(
        built.result.artifact.scoped_evidence.begin(),
        built.result.artifact.scoped_evidence.end(),
        [&subject](const auto& evidence) {
          return evidence.evidence_id == subject;
        });
    REQUIRE(scoped != built.result.artifact.scoped_evidence.end());
    scoped->family_envelope_ids.clear();
    reseal_scoped_evidence_for_role(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::raw_response_bound_evidence);
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_raw_bound_absence_proof");
  }

  SECTION("family proof retains its authoritative conformance report") {
    auto built = make_complete();
    auto& payload = std::get<mwperf::ThreeBinScalarResponseV1>(
        built.result.artifact.payload);
    const auto family_identity = payload.raw_response.identifications[1U]
                                     .family_evidence_envelope_ids.front();
    const auto family = std::find_if(
        built.result.artifact.family_evidence.begin(),
        built.result.artifact.family_evidence.end(),
        [&family_identity](const auto& evidence) {
          return evidence.evidence_id == family_identity;
        });
    REQUIRE(family != built.result.artifact.family_evidence.end());
    const auto index = static_cast<std::size_t>(std::distance(
        built.result.artifact.family_evidence.begin(), family));
    family->provider_conformance_report_ref.report_digest =
        digest_of("foreign-conformance-report");
    reseal_family_evidence_and_references(built.result.artifact, index);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }

  SECTION("family proof retains the exact raw parent") {
    auto built = make_complete();
    auto& payload = std::get<mwperf::ThreeBinScalarResponseV1>(
        built.result.artifact.payload);
    const auto family_identity = payload.raw_response.identifications[1U]
                                     .family_evidence_envelope_ids.front();
    const auto family = std::find_if(
        built.result.artifact.family_evidence.begin(),
        built.result.artifact.family_evidence.end(),
        [&family_identity](const auto& evidence) {
          return evidence.evidence_id == family_identity;
        });
    REQUIRE(family != built.result.artifact.family_evidence.end());
    const auto index = static_cast<std::size_t>(std::distance(
        built.result.artifact.family_evidence.begin(), family));
    family->parent_references = {object_ref("foreign-raw-parent")};
    reseal_family_evidence_and_references(built.result.artifact, index);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }

  SECTION("scoped proof retains final-evaluation provenance") {
    auto built = make_complete();
    built.result.artifact.provenance.final_evaluation_id =
        label("foreign-final-evaluation");
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_raw_bound_provenance");
  }

  SECTION("scoped proof retains proposal provenance") {
    auto built = make_complete();
    built.result.artifact.provenance.proposal_id =
        label("foreign-proposal");
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_raw_bound_provenance");
  }
}

TEST_CASE("C15 F06 rejects Built identity manifest and binding tamper",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.built-tamper", mwperf::MasterSeed(109U));
  auto built = make_bound_built_fixture(fixture);

  SECTION("artifact request binding") {
    built.result.artifact.request_digest = digest_of("foreign-request");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("payload content digest") {
    built.result.artifact.payload_digest = digest_of("stale-payload");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("structural manifest exact bytes") {
    built.result.artifact.structural_manifest_echo.canonical_manifest_bytes
        .push_back(std::byte{0U});
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("descriptor exact echo") {
    built.result.artifact.deployed_descriptor.core_digest =
        digest_of("stale-descriptor");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("binding-set request digest") {
    built.result.artifact.realized_metric_bindings.request_digest =
        digest_of("foreign-request");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("binding-set payload digest") {
    built.result.artifact.realized_metric_bindings.payload_digest =
        digest_of("foreign-payload");
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("missing role key") {
    built.result.artifact.realized_metric_bindings.bindings.pop_back();
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("duplicate role key") {
    built.result.artifact.realized_metric_bindings.bindings.push_back(
        built.result.artifact.realized_metric_bindings.bindings.front());
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("extra role key") {
    auto extra =
        built.result.artifact.realized_metric_bindings.bindings.front();
    extra.key.role = mwperf::MetricSupportRoleV1::nominal_response;
    built.result.artifact.realized_metric_bindings.bindings.push_back(
        std::move(extra));
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("wrong typed product stage") {
    auto& binding = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::deployed_response);
    auto& deployed = std::get<mwperf::DeployedResponseReferenceV1>(
        binding.reference);
    deployed.selected_product = mwperf::NominalResponseProductRef{
        deployed_response_product_identity_v1(
            std::get<mwperf::ThreeBinScalarResponseV1>(
                built.result.artifact.payload)
                .deployed_response_product_id)};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("wrong realized target scope") {
    auto& binding = realized_binding(
        built.result.artifact, mwperf::MetricSupportRoleV1::raw_response);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        binding.reference);
    core.ordered_targets = {queue_id("q1")};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
}

TEST_CASE("C15 F06 reports inner Built versions before stale bindings",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.validation-order", mwperf::MasterSeed(173U));
  auto built = make_bound_built_fixture(fixture);
  built.result.artifact.artifact_protocol_version = 2U;
  std::visit([](auto& payload) { payload.payload_version = 2U; },
             built.result.artifact.payload);
  built.result.artifact.payload_class.version = 2U;
  built.result.artifact.request_digest = digest_of("stale-artifact-request");
  built.result.envelope.request_digest = digest_of("stale-envelope-request");
  built.result.envelope.build_report.request_digest =
      digest_of("stale-report-request");

  const auto validated = validate_bound_built(fixture, built);
  REQUIRE_FALSE(validated);
  CHECK(validated.error().code == "c15.built_version");
}

TEST_CASE("C15 F06 resolves scoped evidence by exact purpose ledger",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.purpose-ledger", mwperf::MasterSeed(113U));
  auto built = make_bound_built_fixture(fixture);
  REQUIRE_FALSE(built.result.artifact.scoped_evidence.empty());
  REQUIRE_FALSE(
      built.result.artifact.scoped_evidence.front().internal_references.empty());

  SECTION("missing purpose") {
    built.result.artifact.scoped_evidence.front().internal_references.pop_back();
    reseal_scoped_evidence_and_binding(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("wrong purpose") {
    built.result.artifact.scoped_evidence.front()
        .internal_references.front()
        .purpose = mwperf::InternalReferencePurposeV1::physical_model;
    reseal_scoped_evidence_and_binding(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("wrong relation") {
    built.result.artifact.scoped_evidence.front()
        .internal_references.front()
        .relation = mwperf::MetricRoleRelationKindV1::subject;
    reseal_scoped_evidence_and_binding(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("a configured-arrival leaf cannot alias the payload object") {
    const auto payload_identity = built.result.artifact.payload_identity;
    auto& scoped_internal =
        built.result.artifact.scoped_evidence.front().internal_references;
    const auto scoped_arrival = std::find_if(
        scoped_internal.begin(), scoped_internal.end(), [](const auto& item) {
          return item.purpose ==
                 mwperf::InternalReferencePurposeV1::
                     configured_arrival_binding;
        });
    REQUIRE(scoped_arrival != scoped_internal.end());
    scoped_arrival->referenced_object = payload_identity;

    auto& validity = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        validity.reference);
    const auto realized_arrival = std::find_if(
        core.internal_relations.begin(), core.internal_relations.end(),
        [](const auto& item) {
          return item.purpose ==
                 mwperf::InternalReferencePurposeV1::
                     configured_arrival_binding;
        });
    REQUIRE(realized_arrival != core.internal_relations.end());
    realized_arrival->referenced_object = payload_identity;
    reseal_scoped_evidence_and_binding(built.result.artifact);

    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_internal_reference_kind");
  }
  SECTION("one bodyless identity cannot serve two semantic purposes") {
    const auto shared_leaf = object_ref("shared-purpose-leaf");
    const auto alias_purposes = [&](auto& relations) {
      const auto coordinate = std::find_if(
          relations.begin(), relations.end(), [](const auto& item) {
            return item.purpose ==
                   mwperf::InternalReferencePurposeV1::coordinate_codec;
          });
      const auto arrival = std::find_if(
          relations.begin(), relations.end(), [](const auto& item) {
            return item.purpose ==
                   mwperf::InternalReferencePurposeV1::
                       configured_arrival_binding;
          });
      REQUIRE(coordinate != relations.end());
      REQUIRE(arrival != relations.end());
      coordinate->referenced_object = shared_leaf;
      arrival->referenced_object = shared_leaf;
    };
    alias_purposes(
        built.result.artifact.scoped_evidence.front().internal_references);
    auto& validity = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        validity.reference);
    alias_purposes(core.internal_relations);
    reseal_scoped_evidence_and_binding(built.result.artifact);

    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.object_graph_leaf_purpose_collision");
  }
  SECTION("reported validity timing is not the authoritative view binding") {
    const mwperf::ArtifactObjectReferenceV1 foreign_timing{
        label("timing-binding"), digest_of("foreign-tie-and-timing")};
    auto& scoped_internal =
        built.result.artifact.scoped_evidence.front().internal_references;
    const auto scoped_timing = std::find_if(
        scoped_internal.begin(), scoped_internal.end(), [](const auto& item) {
          return item.purpose ==
                 mwperf::InternalReferencePurposeV1::timing_binding;
        });
    REQUIRE(scoped_timing != scoped_internal.end());
    scoped_timing->referenced_object = foreign_timing;
    auto& validity = realized_binding(
        built.result.artifact,
        mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence);
    auto& core = std::visit(
        [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
          return reference.core;
        },
        validity.reference);
    const auto realized_timing = std::find_if(
        core.internal_relations.begin(), core.internal_relations.end(),
        [](const auto& item) {
          return item.purpose ==
                 mwperf::InternalReferencePurposeV1::timing_binding;
        });
    REQUIRE(realized_timing != core.internal_relations.end());
    realized_timing->referenced_object = foreign_timing;
    reseal_scoped_evidence_and_binding(built.result.artifact);
    const auto validated = validate_bound_built(fixture, built);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "c15.realized_owner_reference_mismatch");
  }
  SECTION("dangling family evidence") {
    built.result.artifact.scoped_evidence.front().family_envelope_ids.front() =
        object_ref("missing-family-evidence");
    reseal_scoped_evidence_and_binding(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("wrong evidence reference kind") {
    built.result.artifact.scoped_evidence.front().reference_kind =
        mwperf::ArtifactReferenceKindV1::physical_transfer_evidence;
    reseal_scoped_evidence_and_binding(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
}

TEST_CASE("C15 F06 binds evidence owners to authoritative request anchors",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.owner-anchors", mwperf::MasterSeed(163U), 0U,
      authoritative_evidence_scalar_manifest());

  const auto complete = make_bound_built_fixture(fixture);
  auto complete_validation = validate_bound_built(fixture, complete);
  INFO((complete_validation
            ? std::string{}
            : complete_validation.error().code + ": " +
                  complete_validation.error().message));
  REQUIRE(complete_validation);

  struct AnchorMutation final {
    const char* name;
    mwperf::MetricSupportRoleV1 role;
    mwperf::InternalReferencePurposeV1 purpose;
    mwperf::ArtifactObjectReferenceV1 replacement;
  };
  const std::array mutations{
      AnchorMutation{
          "optimizer constraint fingerprint",
          mwperf::MetricSupportRoleV1::optimizer_evidence,
          mwperf::InternalReferencePurposeV1::constraint_identity,
          {label("bound-constraint"), digest_of("foreign-constraint")}},
      AnchorMutation{
          "optimizer build report",
          mwperf::MetricSupportRoleV1::optimizer_evidence,
          mwperf::InternalReferencePurposeV1::call_report_identity,
          object_ref("foreign-call-report")},
      AnchorMutation{
          "optimizer final evaluation",
          mwperf::MetricSupportRoleV1::optimizer_evidence,
          mwperf::InternalReferencePurposeV1::evaluation_identity,
          object_ref("foreign-optimizer-evaluation")},
      AnchorMutation{
          "statistical frozen input bank",
          mwperf::MetricSupportRoleV1::statistical_evidence,
          mwperf::InternalReferencePurposeV1::sampling_bank,
          object_ref("foreign-statistical-bank")},
      AnchorMutation{
          "statistical final evaluation",
          mwperf::MetricSupportRoleV1::statistical_evidence,
          mwperf::InternalReferencePurposeV1::evaluation_identity,
          object_ref("foreign-statistical-evaluation")},
      AnchorMutation{
          "calibration frozen input bank",
          mwperf::MetricSupportRoleV1::calibration_evidence,
          mwperf::InternalReferencePurposeV1::sampling_bank,
          object_ref("foreign-calibration-bank")}};

  for (const auto& mutation : mutations) {
    DYNAMIC_SECTION(mutation.name) {
      auto built = make_bound_built_fixture(fixture);
      auto& binding = realized_binding(built.result.artifact, mutation.role);
      const auto prior_evidence =
          mwperf::realized_reference_subject_v1(binding.reference);
      const auto scoped = std::find_if(
          built.result.artifact.scoped_evidence.begin(),
          built.result.artifact.scoped_evidence.end(),
          [&prior_evidence](const auto& evidence) {
            return evidence.evidence_id == prior_evidence;
          });
      REQUIRE(scoped != built.result.artifact.scoped_evidence.end());

      const auto scoped_anchor = std::find_if(
          scoped->internal_references.begin(),
          scoped->internal_references.end(), [&](const auto& relation) {
            return relation.purpose == mutation.purpose;
          });
      REQUIRE(scoped_anchor != scoped->internal_references.end());
      scoped_anchor->referenced_object = mutation.replacement;

      auto& core = std::visit(
          [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
            return reference.core;
          },
          binding.reference);
      const auto realized_anchor = std::find_if(
          core.internal_relations.begin(), core.internal_relations.end(),
          [&](const auto& relation) {
            return relation.purpose == mutation.purpose;
          });
      REQUIRE(realized_anchor != core.internal_relations.end());
      realized_anchor->referenced_object = mutation.replacement;
      reseal_scoped_evidence_for_role(built.result.artifact, mutation.role);

      const auto validated = validate_bound_built(fixture, built);
      REQUIRE_FALSE(validated);
      CHECK(validated.error().code ==
            "c15.realized_owner_reference_mismatch");
    }
  }
}

TEST_CASE("C15 F06 realizes numerical and stability scoped evidence",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.numerical-stability", mwperf::MasterSeed(167U), 0U,
      numerical_stability_scalar_manifest());

  auto complete = make_bound_built_fixture(fixture);
  auto complete_validation = validate_bound_built(fixture, complete);
  INFO((complete_validation
            ? std::string{}
            : complete_validation.error().code + ": " +
                  complete_validation.error().message));
  REQUIRE(complete_validation);
  CHECK(std::holds_alternative<mwperf::NumericalEvidenceReferenceV1>(
      realized_binding(complete.result.artifact,
                       mwperf::MetricSupportRoleV1::numerical_evidence)
          .reference));
  CHECK(std::holds_alternative<mwperf::StabilityCertificateReferenceV1>(
      realized_binding(complete.result.artifact,
                       mwperf::MetricSupportRoleV1::stability_certificate)
          .reference));

  struct EvidenceRoleCase final {
    const char* name;
    mwperf::MetricSupportRoleV1 role;
    mwperf::MetricSupportRoleV1 other_role;
  };
  const std::array roles{
      EvidenceRoleCase{"numerical evidence",
                       mwperf::MetricSupportRoleV1::numerical_evidence,
                       mwperf::MetricSupportRoleV1::stability_certificate},
      EvidenceRoleCase{"stability certificate",
                       mwperf::MetricSupportRoleV1::stability_certificate,
                       mwperf::MetricSupportRoleV1::numerical_evidence}};

  for (const auto& role_case : roles) {
    DYNAMIC_SECTION(role_case.name << " rejects a foreign reference type") {
      auto built = make_bound_built_fixture(fixture);
      auto& binding = realized_binding(built.result.artifact, role_case.role);
      const auto core =
          mwperf::realized_reference_core_v1(binding.reference);
      const auto subject =
          mwperf::realized_reference_subject_v1(binding.reference);
      if (role_case.role ==
          mwperf::MetricSupportRoleV1::numerical_evidence) {
        binding.reference = mwperf::StabilityCertificateReferenceV1{
            core, mwperf::StabilityCertificateRef{subject}};
      } else {
        binding.reference = mwperf::NumericalEvidenceReferenceV1{
            core, mwperf::NumericalEvidenceRef{subject}};
      }
      const auto validated = validate_bound_built(fixture, built);
      REQUIRE_FALSE(validated);
      CHECK(validated.error().code ==
            "metric_binding_reference_type_mismatch");
    }

    DYNAMIC_SECTION(role_case.name << " rejects a widened evidence scope") {
      auto built = make_bound_built_fixture(fixture);
      auto& binding = realized_binding(built.result.artifact, role_case.role);
      auto& core = std::visit(
          [](auto& reference) -> mwperf::RealizedReferenceCoreV1& {
            return reference.core;
          },
          binding.reference);
      core.evidence_scope = mwperf::MetricEvidenceScopeV1::physical_system;
      const auto validated = validate_bound_built(fixture, built);
      REQUIRE_FALSE(validated);
      CHECK(validated.error().code == "metric_binding_scope_mismatch");
    }

    DYNAMIC_SECTION(role_case.name << " rejects a cross-kind subject binding") {
      auto built = make_bound_built_fixture(fixture);
      const auto replacement = mwperf::realized_reference_subject_v1(
          realized_binding(built.result.artifact, role_case.other_role)
              .reference);
      auto& binding = realized_binding(built.result.artifact, role_case.role);
      if (role_case.role ==
          mwperf::MetricSupportRoleV1::numerical_evidence) {
        std::get<mwperf::NumericalEvidenceReferenceV1>(binding.reference)
            .evidence.identity = replacement;
      } else {
        std::get<mwperf::StabilityCertificateReferenceV1>(binding.reference)
            .certificate.identity = replacement;
      }
      const auto validated = validate_bound_built(fixture, built);
      REQUIRE_FALSE(validated);
      CHECK(validated.error().code ==
            "c15.object_graph_realized_reference_kind");
    }
  }
}

TEST_CASE("C15 F06 rejects malformed scoped diagnostics and provenance",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.auxiliary", mwperf::MasterSeed(149U));
  auto built = make_bound_built_fixture(fixture);
  auto& artifact = built.result.artifact;
  const auto payload_id = artifact.payload_identity;
  const auto evidence_id = artifact.scoped_evidence.front().evidence_id;

  SECTION("stale scoped evidence content digest") {
    artifact.scoped_evidence.front().ordered_targets = {queue_id("q1")};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("duplicate scoped subject") {
    artifact.scoped_evidence.front().subject_references.push_back(
        artifact.scoped_evidence.front().subject_references.front());
    reseal_scoped_evidence_and_binding(artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("noncanonical scoped subject order") {
    REQUIRE(artifact.scoped_evidence.front().subject_references.size() == 2U);
    std::swap(artifact.scoped_evidence.front().subject_references[0U],
              artifact.scoped_evidence.front().subject_references[1U]);
    reseal_scoped_evidence_and_binding(artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("duplicate scoped internal reference") {
    artifact.scoped_evidence.front().internal_references.push_back(
        artifact.scoped_evidence.front().internal_references.front());
    reseal_scoped_evidence_and_binding(artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("promoted scoped result and evidence") {
    artifact.scoped_evidence.front().result_scope =
        mwperf::MetricResultScopeV1::physical_bound;
    artifact.scoped_evidence.front().evidence_scope =
        mwperf::MetricEvidenceScopeV1::physical_system;
    reseal_scoped_evidence_and_binding(artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("extra scoped target") {
    artifact.scoped_evidence.front().ordered_targets.push_back(queue_id("q1"));
    reseal_scoped_evidence_and_binding(artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("diagnostic has unknown scope") {
    artifact.diagnostic_components.push_back(
        {1U, label("diagnostic"),
         static_cast<mwperf::ArtifactDiagnosticScopeV1>(255U), "diagnostic",
         "fixture diagnostic", {payload_id}, {evidence_id}});
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("diagnostic has empty code") {
    artifact.diagnostic_components.push_back(
        {1U, label("diagnostic"), mwperf::ArtifactDiagnosticScopeV1::solver,
         "", "fixture diagnostic", {payload_id}, {evidence_id}});
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("diagnostic evidence is dangling") {
    artifact.diagnostic_components.push_back(
        {1U, label("diagnostic"), mwperf::ArtifactDiagnosticScopeV1::solver,
         "diagnostic", "fixture diagnostic", {payload_id},
         {object_ref("missing-diagnostic-evidence")}});
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance component names are duplicated") {
    artifact.provenance.component_digests = {
        {"component", digest_of("one")}, {"component", digest_of("two")}};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance component names are unsorted") {
    artifact.provenance.component_digests = {
        {"z-component", digest_of("z")}, {"a-component", digest_of("a")}};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance decisions are duplicated") {
    artifact.provenance.method_decisions = {"decision", "decision"};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance uses a non-build stream") {
    artifact.provenance.seed_stream_counts = {
        {mwperf::StageTag::configured_arrival, label("stream"),
         mwperf::BigNat{0U}}};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance present string is empty") {
    artifact.provenance.source_document_id = std::string{};
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
  SECTION("provenance present digest is zero") {
    artifact.provenance.provider_source_digest = zero_digest();
    CHECK_FALSE(validate_bound_built(fixture, built));
  }
}

TEST_CASE("C15 F06 treats registered family bodies as bounded opaque JSON",
          "[c15][property]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.family-evidence", mwperf::MasterSeed(127U));

  SECTION("arbitrary canonical provider fields do not select a formula branch") {
    auto built = make_bound_built_fixture(fixture);
    built.result.artifact.family_evidence.front().canonical_family_body =
        bytes_of(R"({"formula_looking_name":"ignored","threshold_branch":"provider-owned"})");
    reseal_family_evidence_and_references(built.result.artifact);
    auto validated = validate_bound_built(fixture, built);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);
  }

  const auto rejects = [&](const std::string_view body) {
    auto built = make_bound_built_fixture(fixture);
    built.result.artifact.family_evidence.front().canonical_family_body =
        bytes_of(std::string(body));
    reseal_family_evidence_and_references(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  };
  SECTION("duplicate decoded key") {
    rejects(R"({"a":1,"\u0061":2})");
  }
  SECTION("noncanonical key order") {
    rejects(R"({"z":1,"a":2})");
  }
  SECTION("whitespace") { rejects(R"({ "a":1})"); }
  SECTION("raw floating point") { rejects(R"({"a":1.25})"); }
  SECTION("raw exponent") { rejects(R"({"a":1e2})"); }
  SECTION("malformed rational") {
    rejects(R"({"kind":"rational","numerator":"2","denominator":"4"})");
  }
  SECTION("malformed binary64") {
    rejects(R"({"kind":"binary64","bits":"0X3ff0000000000000"})");
  }

  const auto bound_rejects = [&](const auto& mutation) {
    auto built = make_bound_built_fixture(fixture);
    mutation(built.result.artifact.family_evidence.front());
    reseal_family_evidence_and_references(built.result.artifact);
    CHECK_FALSE(validate_bound_built(fixture, built));
  };
  SECTION("unregistered family schema") {
    bound_rejects([](auto& evidence) {
      evidence.family_evidence_schema_id = "c15.unregistered";
    });
  }
  SECTION("wrong family schema version") {
    bound_rejects([](auto& evidence) {
      evidence.family_evidence_schema_version = 2U;
    });
  }
  SECTION("wrong conformance report") {
    bound_rejects([](auto& evidence) {
      evidence.provider_conformance_report_ref.report_digest =
          digest_of("untrusted-report");
    });
  }
  SECTION("wrong provider") {
    bound_rejects([](auto& evidence) {
      evidence.provider = provider("c15.foreign", "1.0.0");
    });
  }
  SECTION("wrong scientific contract") {
    bound_rejects([](auto& evidence) {
      evidence.provider_scientific_contract_digest =
          digest_of("foreign-scientific-contract");
    });
  }
  SECTION("wrong request") {
    bound_rejects([](auto& evidence) {
      evidence.request_digest = digest_of("foreign-request");
    });
  }
  SECTION("wrong payload") {
    bound_rejects([](auto& evidence) {
      evidence.payload_digest = digest_of("foreign-payload");
    });
  }
  SECTION("missing subject") {
    bound_rejects([](auto& evidence) { evidence.subject_references.clear(); });
  }
  SECTION("wrong construction scope") {
    bound_rejects([](auto& evidence) {
      evidence.construction_target_scope = {queue_id("q1")};
    });
  }
  SECTION("wrong evidence scope") {
    bound_rejects([](auto& evidence) {
      evidence.evidence_scope_tag =
          mwperf::MetricEvidenceScopeV1::physical_system;
    });
  }
}

TEST_CASE("C15 parser requires the scoped internal-reference ledger",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.internal-wire", mwperf::MasterSeed(131U));
  const auto built = make_bound_built_fixture(fixture);
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{built.result});
  REQUIRE(encoded);
  auto parsed = mwperf::parse_surrogate_build_result(encoded.value(),
                                                      generous_parse_limits());
  REQUIRE(parsed);
  CHECK(parsed.value() == mwperf::SurrogateBuildResultV1{built.result});

  auto json = nlohmann::ordered_json::parse(text_of(encoded.value()));
  REQUIRE(json.at("artifact").at("scoped_evidence").size() == 1U);
  json.at("artifact").at("scoped_evidence").at(0U).erase(
      "internal_references");
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of(json.dump()), generous_parse_limits()));
}

TEST_CASE("C15 parser requires raw-envelope coverage semantics",
          "[c15][negative]") {
  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.raw-envelope-wire", mwperf::MasterSeed(132U), 0U,
      interval_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
  const auto interval = make_bound_interval_response(fixture);
  const auto built = make_bound_built_fixture(
      fixture, interval.response, {interval.interval_evidence});
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{built.result});
  REQUIRE(encoded);
  const auto baseline =
      nlohmann::ordered_json::parse(text_of(encoded.value()));
  const auto& envelopes = baseline.at("artifact")
                              .at("payload")
                              .at("body")
                              .at("raw_envelopes");
  REQUIRE(envelopes.is_array());
  REQUIRE(envelopes.size() == 1U);

  const auto rejects_missing = [&](const std::string_view field) {
    auto tampered = baseline;
    auto& envelope = tampered["artifact"]["payload"]["body"]
                             ["raw_envelopes"][0U];
    REQUIRE(envelope.erase(std::string(field)) == 1U);
    auto parsed = mwperf::parse_surrogate_build_result(
        bytes_of(tampered.dump()), generous_parse_limits());
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "artifact_wire_missing_field");
    CHECK(parsed.error().json_pointer ==
          std::optional<std::string>{
              "/artifact/payload/body/raw_envelopes/0/" +
              std::string(field)});
  };

  SECTION("coverage") { rejects_missing("coverage"); }
  SECTION("population conditioning premise") {
    rejects_missing("population_conditioning_premise");
  }
}

TEST_CASE("C15 adaptation converts every nested binary64 to exact dyadics",
          "[c15][integration]") {
  auto artifact = artifact_for_payload(three_bin_payload(true));
  auto validated = Factory::validated_artifact(std::move(artifact));
  auto adapted = mwperf::adapt_portable_payload(validated);
  REQUIRE(adapted);
  const auto* response = std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
      &adapted.value().value());
  REQUIRE(response != nullptr);
  CHECK(response->coefficients[0U] == rational(1, 4));
  CHECK(response->coefficients[1U] == rational(3, 4));
  CHECK(response->coefficients[2U] == rational(1, 2));
  REQUIRE(response->normalized_record.nominal_response.has_value());
  for (const auto& coefficient :
       response->normalized_record.nominal_response->coefficients) {
    CHECK(coefficient.value.kind() ==
          mwperf::PortableScientificScalarKind::rational);
  }
  for (const auto& item :
       response->normalized_record.raw_response.identifications) {
    REQUIRE(item.raw_point.has_value());
    CHECK(item.raw_point->kind() ==
          mwperf::PortableScientificScalarKind::rational);
  }
}

TEST_CASE("C15 F08 preserves separately scoped evidence ledgers byte-exactly",
          "[c15][integration]") {
  const auto input = make_protocol_input_fixture();
  const auto request_fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.adapter-evidence", mwperf::MasterSeed(137U));
  const auto built = make_bound_built_fixture(request_fixture);
  const auto original_family = built.result.artifact.family_evidence;
  const auto original_scoped = built.result.artifact.scoped_evidence;
  REQUIRE(original_family.size() == 1U);
  REQUIRE(original_scoped.size() == 1U);
  REQUIRE_FALSE(original_family.front().canonical_family_body.empty());
  REQUIRE_FALSE(original_scoped.front().internal_references.empty());

  auto adapted = mwperf::adapt_portable_payload(
      Factory::validated_artifact(built.result.artifact));
  REQUIRE(adapted);
  const auto* response = std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
      &adapted.value().value());
  REQUIRE(response != nullptr);
  CHECK(response->context.family_evidence == original_family);
  CHECK(response->context.scoped_evidence == original_scoped);
  CHECK(response->context.family_evidence.front().canonical_family_body ==
        original_family.front().canonical_family_body);
  CHECK(response->context.family_evidence.front()
            .canonical_family_body_digest ==
        original_family.front().canonical_family_body_digest);
  CHECK(response->context.scoped_evidence.front().family_envelope_ids.front() ==
        response->context.family_evidence.front().evidence_id);
}

TEST_CASE("C15 F08 recursively rationalizes all payload and table alternatives",
          "[c15][property]") {
  auto payloads = payload_fixtures(true);
  auto augmented_response = three_bin_payload(true);
  REQUIRE(augmented_response.nominal_response.has_value());
  const auto raw = augmented_response.raw_response.product_id;
  const auto nominal = augmented_response.nominal_response->product_id;
  augmented_response.projection_center = mwperf::ProjectionCenterProductV1{
      center_id(), provider(), digest_of("request"),
      {queue_id("q0"), queue_id("q1")}, queue_id("q0"),
      mwperf::ProjectionCenterSourceKindV1::decoded_raw_response,
      {binary_scalar(0.25), binary_scalar(0.75)}, nominal, std::nullopt};
  augmented_response.projected_mean = mwperf::ProjectedMeanProductV1{
      mean_id(), provider(), digest_of("request"),
      {queue_id("q0"), queue_id("q1")}, queue_id("q0"),
      {binary_scalar(0.5), binary_scalar(0.25)}, center_id(),
      object_ref("projection-policy"), std::nullopt};
  augmented_response.recoded_response = mwperf::RecodedResponseProductV1{
      recoded_id(), provider(), digest_of("request"), queue_id("q0"),
      coefficient_triple(true),
      mwperf::ProductDerivationKindV1::mean_inversion_recoding, mean_id(),
      nominal, std::nullopt, object_ref("recoding-policy"), std::nullopt};
  augmented_response.raw_envelopes.push_back(mwperf::RawResponseEnvelopeV1{
      object_ref("raw-envelope"), raw, digest_of("construction-law"),
      {mwperf::ThreeBinCoefficientV1::one,
       mwperf::ThreeBinCoefficientV1::two,
       mwperf::ThreeBinCoefficientV1::tail_from_three},
      {binary_scalar(0.0), binary_scalar(0.25), binary_scalar(0.5)},
      {binary_scalar(0.25), binary_scalar(0.75), binary_scalar(1.0)},
      "fixture", mwperf::RawEnvelopeCoverageV1::simultaneous,
      mwperf::PopulationConditioningPremiseV1::
          conditional_on_population_positivity,
      std::nullopt, std::nullopt,
      mwperf::RawEnvelopeScopeV1::proposal_raw, {}});
  payloads.front() = std::move(augmented_response);

  for (const auto& payload : payloads) {
    auto adapted = mwperf::adapt_portable_payload(
        Factory::validated_artifact(artifact_for_payload(payload)));
    REQUIRE(adapted);
    std::visit(
        [](const auto& active) {
          using Active = std::decay_t<decltype(active)>;
          if constexpr (std::same_as<
                            Active,
                            mwperf::PortableThreeBinScalarResponseV1>) {
            CHECK(contains_only_rationals(active.normalized_record));
          } else if constexpr (
              std::same_as<
                  Active,
                  mwperf::PortableFinitePrefixConstantTailResponseV1>) {
            CHECK(contains_only_rationals(active.normalized_record));
          } else if constexpr (
              std::same_as<Active,
                           mwperf::PortableFiniteParameterAnalyticDataV1>) {
            for (const auto& value : active.normalized_record.parameters) {
              CHECK(contains_only_rationals(value.value));
            }
            for (const auto& value : active.normalized_record.tables) {
              CHECK(contains_only_rationals(value.value));
            }
            for (const auto& coordinate :
                 active.normalized_record.mathematical_domain) {
              CHECK(contains_only_rationals(coordinate.lower));
              CHECK(contains_only_rationals(coordinate.upper));
            }
          } else if constexpr (
              std::same_as<Active, mwperf::PortableFiniteLawTablesV1>) {
            for (const auto& value : active.normalized_record.state_dictionary) {
              CHECK(contains_only_rationals(value.coordinates));
            }
            for (const auto& value : active.normalized_record.mark_dictionary) {
              CHECK(contains_only_rationals(value.coordinates));
            }
            CHECK(contains_only_rationals(active.normalized_record.table));
          } else if constexpr (
              std::same_as<Active,
                           mwperf::PortableRegisteredRuntimeRecipeV1>) {
            for (const auto& value : active.normalized_record.parameters) {
              CHECK(contains_only_rationals(value.value));
            }
          } else if constexpr (
              std::same_as<Active,
                           mwperf::PortableResponseEnvelopeEvidenceV1>) {
            CHECK(contains_only_rationals(
                active.normalized_record.lower_response));
            CHECK(contains_only_rationals(
                active.normalized_record.upper_response));
          } else {
            static_assert(std::same_as<
                          Active, mwperf::PortableDirectMetricPayloadV1>);
            for (const auto& value : active.normalized_record.values) {
              CHECK(contains_only_rationals(value.value));
            }
          }
        },
        adapted.value().value());
  }

  const std::array table_semantics{
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::SemanticTagV1::staged_opportunity_flux_law,
      mwperf::SemanticTagV1::temporal_one_slot_continuation,
      mwperf::SemanticTagV1::stopped_path_law,
      mwperf::SemanticTagV1::romr_residence_word_law,
      mwperf::SemanticTagV1::coupled_target_schedule_law};
  auto tables = finite_table_fixtures(true);
  for (std::size_t index = 0U; index < tables.size(); ++index) {
    const mwperf::ArtifactPayloadV1 payload = mwperf::FiniteLawTablesV1{
        1U, {queue_id("q0")}, table_semantics[index],
        mwperf::RuntimeAccessTagV1::finite_enumerated_row,
        digest_of("arrival"), digest_of("selection"),
        {{label("s0"), {binary_scalar(0.25)}}},
        {{label("m0"), {binary_scalar(0.5)}}}, tables[index]};
    auto adapted = mwperf::adapt_portable_payload(
        Factory::validated_artifact(artifact_for_payload(payload)));
    REQUIRE(adapted);
    const auto* finite = std::get_if<mwperf::PortableFiniteLawTablesV1>(
        &adapted.value().value());
    REQUIRE(finite != nullptr);
    CHECK(contains_only_rationals(finite->normalized_record.table));
    CHECK(contains_only_rationals(
        finite->normalized_record.state_dictionary.front().coordinates));
    CHECK(contains_only_rationals(
        finite->normalized_record.mark_dictionary.front().coordinates));
  }
}

TEST_CASE("C15 parser round-trips all three mutually exclusive inner results",
          "[c15][integration]") {
  const mwperf::ResultEnvelopeV1 envelope{1U, digest_of("request"), provider(),
                                          build_report()};
  std::vector<mwperf::SurrogateBuildResultV1> values;
  values.emplace_back(mwperf::BuiltSurrogateResultV1{
      envelope, artifact_for_payload(three_bin_payload())});
  values.emplace_back(mwperf::UnavailableSurrogateResultV1{
          envelope,
          {{mwperf::UnavailableReasonKindV1::coefficient_unresolved,
            "coefficient.unresolved", "a response bin was unresolved",
            clause_id("throughput"), object_ref("coefficient-1")}},
          std::nullopt});
  values.emplace_back(mwperf::FailedSurrogateResultV1{
          envelope,
          {mwperf::ProviderFailureKindV1::construction_failure,
           "construction.failed", "fixture construction failed"}});
  REQUIRE(values.size() == 3U);
  for (const auto& value : values) {
    auto encoded =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            value);
    REQUIRE(encoded);
    auto parsed = mwperf::parse_surrogate_build_result(
        encoded.value(), generous_parse_limits());
    INFO((parsed ? std::string{}
                 : parsed.error().code + ": " + parsed.error().message));
    REQUIRE(parsed);
    CHECK(parsed.value() == value);
  }

  auto unavailable_bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          values[1U]);
  REQUIRE(unavailable_bytes);
  const std::string unavailable_text = text_of(unavailable_bytes.value());
  CHECK(unavailable_text.find("strongest_truthful_alternative") ==
        std::string::npos);
  auto explicit_null = nlohmann::ordered_json::parse(unavailable_text);
  explicit_null["strongest_truthful_alternative"] = nullptr;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of(explicit_null.dump()), generous_parse_limits()));
}

TEST_CASE("C15 parser rejects non-three raw identifications and unknown bins",
          "[c15][negative]") {
  const mwperf::ResultEnvelopeV1 envelope{
      1U, digest_of("request"), provider(), build_report()};
  const mwperf::SurrogateBuildResultV1 built{
      mwperf::BuiltSurrogateResultV1{
          envelope, artifact_for_payload(three_bin_payload())}};
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          built);
  REQUIRE(encoded);
  const auto baseline =
      nlohmann::ordered_json::parse(text_of(encoded.value()));
  const auto identifications =
      baseline.at("artifact")
          .at("payload")
          .at("body")
          .at("raw_response")
          .at("identifications");
  REQUIRE(identifications.is_array());
  REQUIRE(identifications.size() == 3U);

  for (const std::size_t cardinality : {0U, 2U, 4U}) {
    auto tampered = baseline;
    auto& values = tampered["artifact"]["payload"]["body"]
                           ["raw_response"]["identifications"];
    while (values.size() > cardinality) values.erase(values.end() - 1);
    while (values.size() < cardinality) values.push_back(values.back());
    INFO("raw identification cardinality " << cardinality);
    CHECK_FALSE(mwperf::parse_surrogate_build_result(
        bytes_of(tampered.dump()), generous_parse_limits()));
  }

  auto unknown_bin = baseline;
  unknown_bin["artifact"]["payload"]["body"]["raw_response"]
             ["identifications"][1U]["target_bin_binding"] =
      "unknown_bin";
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of(unknown_bin.dump()), generous_parse_limits()));

  auto explicit_mu_zero = baseline;
  explicit_mu_zero["artifact"]["payload"]["body"]["mu0"] = {
      {"kind", "rational"}, {"numerator", "1"}, {"denominator", "1"}};
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of(explicit_mu_zero.dump()), generous_parse_limits()));

  auto fourth_coefficient = baseline;
  auto& coefficients = fourth_coefficient["artifact"]["payload"]["body"]
                                         ["nominal_response"]["coefficients"];
  REQUIRE(coefficients.is_array());
  REQUIRE(coefficients.size() == 3U);
  coefficients.push_back(coefficients.back());
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of(fourth_coefficient.dump()), generous_parse_limits()));
}

TEST_CASE("C15 parser enforces bytes syntax and allocation bounds",
          "[c15][negative]") {
  const auto valid = mwperf::artifact::detail::
      canonical_surrogate_build_result_bytes_v1(
          mwperf::FailedSurrogateResultV1{
              {1U, digest_of("request"), provider(), build_report()},
              {mwperf::ProviderFailureKindV1::provider_internal_error,
               "provider.error", "failure"}});
  REQUIRE(valid);

  auto tiny = generous_parse_limits();
  tiny.maximum_bytes = valid.value().size() - 1U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(), tiny));

  auto truncated = valid.value();
  truncated.pop_back();
  CHECK_FALSE(mwperf::parse_surrogate_build_result(truncated,
                                                   generous_parse_limits()));
  auto trailing = valid.value();
  trailing.push_back(std::byte{'x'});
  CHECK_FALSE(mwperf::parse_surrogate_build_result(trailing,
                                                   generous_parse_limits()));
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of("{\"status\":\"failed\",\"status\":\"built\"}"),
      generous_parse_limits()));
  CHECK_FALSE(mwperf::parse_surrogate_build_result(
      bytes_of("{\"status\":\"failed\",\"unknown\":true}"),
      generous_parse_limits()));
  const std::array invalid_utf8{std::byte{'{'}, std::byte{'\"'},
                                std::byte{0xc0}, std::byte{0xaf},
                                std::byte{'\"'}, std::byte{'}'}};
  CHECK_FALSE(mwperf::parse_surrogate_build_result(invalid_utf8,
                                                   generous_parse_limits()));

  auto shallow = generous_parse_limits();
  shallow.maximum_nesting_depth = 2U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(), shallow));
  auto no_strings = generous_parse_limits();
  no_strings.maximum_string_bytes = 3U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(), no_strings));
  auto no_objects = generous_parse_limits();
  no_objects.maximum_object_entries = 1U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(), no_objects));
  auto no_arrays = generous_parse_limits();
  no_arrays.maximum_array_entries = 0U;
  const auto array_wire = mwperf::artifact::detail::
      canonical_surrogate_build_result_bytes_v1(
          mwperf::UnavailableSurrogateResultV1{
              {1U, digest_of("request"), provider(), build_report()},
              {{mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
                "provider.unavailable", "required evidence unavailable",
                clause_id("throughput"), object_ref("missing-evidence")}},
              std::nullopt});
  REQUIRE(array_wire);
  CHECK_FALSE(
      mwperf::parse_surrogate_build_result(array_wire.value(), no_arrays));
  auto no_scalars = generous_parse_limits();
  no_scalars.maximum_scalar_count = 1U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(), no_scalars));
  auto no_allocations = generous_parse_limits();
  no_allocations.maximum_total_decoded_allocation_bytes = 8U;
  CHECK_FALSE(mwperf::parse_surrogate_build_result(valid.value(),
                                                   no_allocations));
}

TEST_CASE("C15 checked-in malformed wire matrix is rejected byte for byte",
          "[c15][negative]") {
  const auto fixture = nlohmann::json::parse(
      read_fixture_text("malformed_result_matrix.json"));
  REQUIRE(fixture.is_array());
  REQUIRE(fixture.size() >= 10U);
  for (const auto& item : fixture) {
    INFO(item.at("name").get<std::string>());
    const auto wire = bytes_of(item.at("wire").get<std::string>());
    CHECK_FALSE(mwperf::parse_surrogate_build_result(
        wire, generous_parse_limits()));
  }
}

TEST_CASE("C15 stopped defective mass differs from ROMR nontermination",
          "[c15][negative]") {
  const mwperf::StoppedPathTableV1 stopped{
      1U, object_ref("stopped"), "hit", {label("s0")}, {label("s0")},
      {label("m0")}, true, std::vector<mwperf::ExplicitOrderedWordV1>{},
      scalar(1, 4), {object_ref("defective-evidence")}};
  const mwperf::RomrResidenceWordTableV1 residence{
      1U, object_ref("residence"), "exit", {label("s0")}, {label("s0")},
      {label("m0")}, std::vector<mwperf::ExplicitOrderedWordV1>{},
      scalar(1, 4), {object_ref("termination-evidence")}};
  CHECK(stopped.accepted_defective_hitting_law);
  CHECK(stopped.nonhit_or_nontermination_probability.rational_value() ==
        rational(1, 4));
  CHECK(residence.nontermination_probability.rational_value() ==
        rational(1, 4));
  // Semantic rejection of the residence record is exercised through F-C15-06
  // once placed in an otherwise valid request-bound artifact; unlike stopped
  // hitting, ROMR never authorizes positive nontermination mass.
}

TEST_CASE("C15 terminal reason and provider-failure vocabularies stay distinct",
          "[c15][unit]") {
  const std::array unavailable{
      mwperf::UnavailableReasonKindV1::inapplicable_target_structure,
      mwperf::UnavailableReasonKindV1::coefficient_proved_zero,
      mwperf::UnavailableReasonKindV1::coefficient_unresolved,
      mwperf::UnavailableReasonKindV1::interval_only_without_authorized_point,
      mwperf::UnavailableReasonKindV1::unmet_construction_assumption,
      mwperf::UnavailableReasonKindV1::construction_domain_unavailable,
      mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
      mwperf::UnavailableReasonKindV1::
          realized_capability_narrower_than_accepted};
  const std::array failed{
      mwperf::ProviderFailureKindV1::construction_failure,
      mwperf::ProviderFailureKindV1::resource_exhausted,
      mwperf::ProviderFailureKindV1::invariant_violation,
      mwperf::ProviderFailureKindV1::provider_internal_error};
  CHECK(unavailable.size() == 8U);
  CHECK(failed.size() == 4U);
  CHECK_FALSE((std::is_same_v<mwperf::UnavailableReasonKindV1,
                              mwperf::ProviderFailureKindV1>));
}

TEST_CASE("C15 canonical golden corpus is byte stable", "[c15][unit]") {
  const auto output_directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c15-golden-stage";
  std::error_code error;
  std::filesystem::remove_all(output_directory, error);
  REQUIRE_FALSE(error);
  error.clear();
  std::filesystem::create_directories(output_directory, error);
  REQUIRE_FALSE(error);
  const auto write_bytes = [&](const std::string& name,
                               const std::span<const std::byte> bytes) {
    std::ofstream output(output_directory / name,
                         std::ios::binary | std::ios::trunc);
    REQUIRE(output.is_open());
    output.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    REQUIRE(output.good());
  };
  const auto write_text = [&](const std::string& name,
                              const std::string_view value) {
    write_bytes(name, std::as_bytes(std::span(value.data(), value.size())));
  };
  const auto write_wire_sha = [&](const std::string& name,
                                  const std::span<const std::byte> bytes) {
    auto digest = mwperf::sha256(bytes);
    REQUIRE(digest);
    write_text(name + ".wire.sha256", digest.value().hex());
  };
  const auto write_json = [&](const std::string& name,
                              const nlohmann::ordered_json& value) {
    const auto text = value.dump();
    write_text(name, text);
    write_wire_sha(
        name,
        std::as_bytes(std::span(text.data(), text.size())));
  };
  const auto bytes_hex = [](const std::span<const std::byte> bytes) {
    static constexpr char digits[] = "0123456789abcdef";
    std::string result;
    result.reserve(bytes.size() * 2U);
    for (const auto value : bytes) {
      const auto byte = std::to_integer<unsigned int>(value);
      result.push_back(digits[(byte >> 4U) & 0x0fU]);
      result.push_back(digits[byte & 0x0fU]);
    }
    return result;
  };

  const auto input = make_protocol_input_fixture();
  const auto fixture = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.golden", mwperf::MasterSeed(0xC15001U));
  // Exercise the fixture-only trusted report issuer while F06 fixtures are
  // assembled below; this also locks its canonical self-digest construction.
  const auto sealed_report = sealed_report_for(fixture);
  CHECK(sealed_report.request_digest == fixture.request.request_digest().value());
  auto provider_manifest_bytes =
      mwperf::canonical_provider_manifest_bytes_v1(fixture.manifest.value());
  auto problem_view_bytes =
      mwperf::canonical_framework_problem_view_bytes_v1(fixture.view);
  auto report_bytes =
      mwperf::canonical_common_build_report_bytes_v1(sealed_report);
  REQUIRE(provider_manifest_bytes);
  REQUIRE(problem_view_bytes);
  REQUIRE(report_bytes);
  write_bytes("provider_manifest.json", provider_manifest_bytes.value());
  write_bytes("framework_problem_view.json", problem_view_bytes.value());
  write_bytes("common_build_report.json", report_bytes.value());
  write_wire_sha("provider_manifest.json", provider_manifest_bytes.value());
  write_wire_sha("framework_problem_view.json", problem_view_bytes.value());
  write_wire_sha("common_build_report.json", report_bytes.value());
  write_text("provider_manifest.sha256",
             fixture.manifest.value().manifest_digest.hex());
  write_text("framework_problem_view.sha256",
             fixture.view.canonical_digest().value().hex());
  write_text("common_build_report.sha256",
             sealed_report.report_digest.hex());
  auto projection = mwperf::canonical_provider_scientific_contract_bytes_v1(
      fixture.manifest.scientific_projection());
  REQUIRE(projection);
  write_bytes("provider_scientific_projection.json", projection.value());
  write_wire_sha("provider_scientific_projection.json", projection.value());
  write_text("provider_scientific_projection.sha256",
             fixture.manifest.scientific_contract_digest().value().hex());

  const auto& request = fixture.request;
  const mwperf::BuildIdentityV1 identity{
      1U,
      request.provider_binding(),
      {request.classifications().construction_method,
       request.classifications().producer_mode,
       request.classifications().proposed_semantic_tag,
       request.classifications().proposed_access_tag,
       request.classifications().proposed_payload_tag,
       fixture.manifest.value().payload_class.version},
      request.framework_problem_view(),
      request.accepted_capability_contract(),
      std::vector<std::byte>(request.validated_parameters().begin(),
                             request.validated_parameters().end()),
      request.construction_budget(),
      {1U,
       request.framework_problem_view().target_selection().ordered_targets,
       request.framework_problem_view()
           .target_selection()
           .construction_group_binding},
      request.protocol_version(), 1U,
      request.required_build_report_schema()};
  auto identity_bytes = mwperf::canonical_build_identity_bytes_v1(identity);
  auto request_bytes =
      mwperf::canonical_surrogate_build_request_bytes_v1(request);
  REQUIRE(identity_bytes);
  REQUIRE(request_bytes);
  write_bytes("build_identity.json", identity_bytes.value());
  write_bytes("surrogate_build_request.json", request_bytes.value());
  write_wire_sha("build_identity.json", identity_bytes.value());
  write_wire_sha("surrogate_build_request.json", request_bytes.value());
  write_text("build_identity.sha256",
             request.build_identity_digest().digest().hex());
  write_text("surrogate_build_request.sha256",
             request.request_digest().value().hex());
  const auto build_seed_bytes = request.build_seed().canonical_bytes();
  write_bytes("build_seed_root.bin", build_seed_bytes);
  write_wire_sha("build_seed_root.bin", build_seed_bytes);
  write_json(
      "build_seed_root.json",
      {{"rng_version", request.build_seed().rng_version()},
       {"master_seed",
        std::to_string(request.build_seed().master_seed().value())},
       {"build_identity_digest",
        request.build_seed().build_identity_digest().digest().hex()},
       {"canonical_bytes", bytes_hex(build_seed_bytes)}});

  const auto string_array = [](const std::initializer_list<std::string_view>
                                   values) {
    auto result = nlohmann::ordered_json::array();
    for (const auto value : values) result.push_back(value);
    return result;
  };
  const nlohmann::ordered_json closed_vocabulary{
      {"construction_method",
       string_array({"closed_form", "engineered_deterministic",
                     "engineered_hybrid", "sampled_offline",
                     "precomputed"})},
      {"producer_mode",
       string_array({"inline_immediate", "in_process_builder",
                     "local_executable_builder"})},
      {"semantic_tag",
       string_array({"scalar_backlog_response", "stationary_marked_edge",
                     "staged_opportunity_flux_law",
                     "temporal_one_slot_continuation",
                     "romr_residence_word_law", "stopped_path_law",
                     "coupled_target_schedule_law", "direct_metric_decoder",
                     "response_envelope_law"})},
      {"runtime_access_tag",
       string_array({"finite_enumerated_row", "sparse_row",
                     "normalized_conditional_sampler", "analytic_transform",
                     "finite_parameter_analytic_family",
                     "procedural_residence_generator",
                     "direct_metric_decoder"})},
      {"payload_class_tag",
       string_array({"three_bin_scalar_response_v1",
                     "finite_parameter_analytic_data_v1",
                     "finite_law_tables_v1",
                     "registered_runtime_recipe_v1",
                     "response_envelope_evidence_v1",
                     "direct_metric_payload_v1",
                     "finite_prefix_constant_tail_response_v1"})},
      {"finite_table_tag",
       string_array({"stationary_marked_edge", "staged_opportunity_flux",
                     "temporal_one_slot_continuation", "stopped_path",
                     "romr_residence_word", "coupled_common_schedule"})},
      {"finite_table_storage", string_array({"dense", "sparse"})},
      {"finite_row_conditioning_stage",
       string_array({"stationary_edge", "prearrival", "postarrival",
                     "one_slot_current", "stopped_continuation",
                     "residence_continuation", "common_schedule"})},
      {"three_bin_coefficient",
       string_array({"one", "two", "tail_from_three"})},
      {"proposal_conditioning_source",
       string_array({"exact_population", "empirical_average"})},
      {"population_conditioning_status",
       string_array({"proved_positive", "proved_zero",
                     "positive_with_confidence", "unresolved"})},
      {"raw_value_status",
       string_array({"exact_point", "interval_only", "absent"})},
      {"response_product_stage",
       string_array({"raw_response", "nominal_response",
                     "projection_center", "projected_mean",
                     "recoded_response"})},
      {"projection_center_source",
       string_array({"decoded_raw_response", "synthetic_snapshot_mean",
                     "explicit_fallback"})},
      {"product_derivation",
       string_array({"nominal_completion", "admissibility_projection",
                     "identity_recoding", "mean_inversion_recoding",
                     "endpoint_completion"})},
      {"raw_envelope_scope",
       string_array({"proposal_raw", "optimizer_interval_raw",
                     "deterministic_quadrature_raw",
                     "physical_response_bound"})},
      {"raw_envelope_coverage",
       string_array({"deterministic", "marginal", "simultaneous"})},
      {"population_conditioning_premise",
       string_array({"unconditional",
                     "conditional_on_population_positivity"})},
      {"target_coupling",
       string_array({"scalar_target", "common_schedule_projection",
                     "full_schedule_identity"})},
      {"point_product_deployment",
       string_array({"not_applicable", "deploy_raw_point",
                     "deploy_nominal_point", "deploy_recoded_point"})},
      {"coefficient_completion",
       string_array({"not_applicable", "require_complete_raw_points",
                     "declared_nominal_completion",
                     "authorized_endpoint_completion"})},
      {"projection_policy",
       string_array({"not_applicable", "identity",
                     "convex_feasible_mean"})},
      {"recoding_policy",
       string_array({"not_applicable", "identity", "mean_inversion"})},
      {"evidence_role_policy",
       string_array({"not_applicable", "exact_manifest_roles"})},
      {"metric_support_role",
       string_array({"deployed_payload", "deployed_response", "raw_response",
                     "nominal_response", "projection_center",
                     "projected_mean", "recoded_response",
                     "stationary_marked_edge_law",
                     "staged_opportunity_flux_law",
                     "temporal_continuation_law", "residence_word_law",
                     "stopped_path_law", "coupled_schedule_law",
                     "direct_metric_value", "response_envelope",
                     "raw_response_bound_evidence",
                     "response_order_evidence", "optimizer_evidence",
                     "statistical_evidence", "numerical_evidence",
                     "calibration_evidence", "compression_evidence",
                     "stability_certificate",
                     "reported_validity_or_lift_evidence",
                     "physical_transfer_evidence"})},
      {"metric_target_scope",
       string_array({"payload_targets", "deployed_singleton_target",
                     "ordered_metric_targets",
                     "ordered_construction_targets",
                     "exact_request_targets"})},
      {"metric_result_scope",
       string_array({"not_a_metric_result", "surrogate_law",
                     "proposal_raw", "response_envelope",
                     "physical_bound"})},
      {"metric_evidence_scope",
       string_array({"none", "raw_static_proposal",
                     "nominal_static_proposal", "projection_center",
                     "projected_surrogate_mean", "recoded_static_proposal",
                     "optimizer_interval_raw", "deployed_surrogate_law",
                     "numerical_result", "validity_or_lift",
                     "physical_system"})},
      {"artifact_reference_kind",
       string_array({"artifact_payload", "raw_response_product",
                     "nominal_response_product", "projection_center_product",
                     "projected_mean_product", "recoded_response_product",
                     "stationary_marked_edge_law",
                     "staged_opportunity_flux_law",
                     "temporal_continuation_law", "residence_word_law",
                     "stopped_path_law", "coupled_schedule_law",
                     "direct_metric_value", "response_envelope",
                     "raw_response_bound_evidence",
                     "response_order_evidence", "optimizer_evidence",
                     "statistical_evidence", "numerical_evidence",
                     "calibration_evidence", "compression_evidence",
                     "stability_certificate",
                     "reported_validity_or_lift_evidence",
                     "physical_transfer_evidence"})},
      {"internal_reference_purpose",
       string_array({
           "artifact_payload", "coefficient_origin", "completion_source",
           "completion_policy", "projection_source", "projection_policy",
           "recoding_policy", "state_codec", "mark_codec",
           "configured_arrival_binding", "selection_binding",
           "initial_binding", "stage_law", "reveal_order", "entrance",
           "one_slot_continuation", "adapted_positive_stop", "word",
           "terminal", "reentry", "killed_projection",
           "projected_schedule", "feasibility_domain_codec",
           "full_schedule", "normalized_request", "validity_basis",
           "lower_response_product", "upper_response_product",
           "comparison_domain", "evaluation_identity", "proposal_identity",
           "exact_population", "solver_identity", "constraint_identity",
           "call_report_identity", "certified_product_or_envelope",
           "estimand", "sampling_bank", "sampling_probe",
           "coverage_family", "algorithm_tolerance_policy",
           "residual_or_enclosure", "representation_domain",
           "calibration_source", "calibration_rule", "compression_source",
           "compression_destination", "compression_rule", "deployed_law",
           "law_or_result", "state_domain", "class_domain",
           "stability_statement", "coordinate_codec", "timing_binding",
           "validity_witness", "physical_model", "physical_metric",
           "transfer_theorem", "transfer_assumption", "transfer_direction",
           "surrogate_source", "error_object"})},
      {"response_product_value_form",
       string_array({"exact_point", "interval_only"})},
      {"work_counter_applicability",
       string_array({"not_applicable", "applicable"})},
      {"budget_applicability",
       string_array({"not_applicable", "applicable"})},
      {"artifact_diagnostic_scope",
       string_array({"construction_integration", "input_bank_initialization",
                     "optimizer_certification", "coefficient_sampling",
                     "compression", "projection", "recoding", "solver",
                     "physical_fidelity"})},
      {"unavailable_reason_kind",
       string_array({"inapplicable_target_structure",
                     "coefficient_proved_zero", "coefficient_unresolved",
                     "interval_only_without_authorized_point",
                     "unmet_construction_assumption",
                     "construction_domain_unavailable",
                     "required_evidence_unavailable",
                     "realized_capability_narrower_than_accepted"})},
      {"provider_failure_kind",
       string_array({"construction_failure", "resource_exhausted",
                     "invariant_violation", "provider_internal_error"})},
      {"provenance_stage_tag",
       string_array({"initial_joint_atom", "prearrival_closure",
                     "tie_resolution", "configured_arrival",
                     "postarrival_closure", "controller_post",
                     "generic_sampling", "importance_proposal", "training",
                     "solver_sampling", "surrogate_build_input",
                     "surrogate_build_context", "surrogate_build_probe",
                     "surrogate_build_final"})}};
  write_json("closed_vocabulary_v1.json", closed_vocabulary);

  struct ProviderRouteGolden final {
    const char* name;
    mwperf::ConstructionMethodV1 method;
    mwperf::ProducerModeV1 mode;
  };
  const std::array provider_routes{
      ProviderRouteGolden{"closed_form_inline",
                          mwperf::ConstructionMethodV1::closed_form,
                          mwperf::ProducerModeV1::inline_immediate},
      ProviderRouteGolden{"engineered_deterministic_in_process",
                          mwperf::ConstructionMethodV1::engineered_deterministic,
                          mwperf::ProducerModeV1::in_process_builder},
      ProviderRouteGolden{"engineered_hybrid_local",
                          mwperf::ConstructionMethodV1::engineered_hybrid,
                          mwperf::ProducerModeV1::local_executable_builder},
      ProviderRouteGolden{"sampled_offline_in_process",
                          mwperf::ConstructionMethodV1::sampled_offline,
                          mwperf::ProducerModeV1::in_process_builder},
      ProviderRouteGolden{"precomputed_inline",
                          mwperf::ConstructionMethodV1::precomputed,
                          mwperf::ProducerModeV1::inline_immediate}};
  for (const auto& route : provider_routes) {
    auto manifest_value = provider_manifest(
        route.method, route.mode,
        "c15.fixture.golden-provider-" + std::string(route.name));
    auto validated = mwperf::validate_provider_manifest(manifest_value);
    REQUIRE(validated);
    auto bytes = mwperf::canonical_provider_manifest_bytes_v1(manifest_value);
    REQUIRE(bytes);
    const auto name =
        "provider_manifest_" + std::string(route.name) + ".json";
    write_bytes(name, bytes.value());
    write_wire_sha(name, bytes.value());
    write_text("provider_manifest_" + std::string(route.name) + ".sha256",
               manifest_value.manifest_digest.hex());
  }

  static constexpr std::array<std::string_view, 6U> payload_names{
      "three_bin", "finite_parameter_analytic", "finite_law_tables",
      "registered_runtime_recipe", "response_envelope", "direct_metric"};
  std::vector<mwperf::testing::C15GoldenSourceV1> golden_sources;
  golden_sources.push_back(
      mwperf::testing::make_three_bin_c15_golden_source_v1());
  auto non_three_sources =
      mwperf::testing::make_non_three_c15_golden_sources_v1();
  golden_sources.insert(golden_sources.end(),
                        std::make_move_iterator(non_three_sources.begin()),
                        std::make_move_iterator(non_three_sources.end()));
  REQUIRE(golden_sources.size() == payload_names.size());

  const auto rational_json = [](const mwperf::ExactRational& value) {
    return nlohmann::ordered_json{{"numerator", value.numerator_decimal()},
                                  {"denominator",
                                   value.denominator_decimal()}};
  };
  for (std::size_t index = 0U; index < golden_sources.size(); ++index) {
    const auto& source = golden_sources[index];
    CHECK(source.name == payload_names[index]);
    auto source_result_bytes =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{source.source_built});
    REQUIRE(source_result_bytes);
    const auto source_result_json = nlohmann::ordered_json::parse(
        text_of(source_result_bytes.value()));
    const auto& source_artifact_json = source_result_json.at("artifact");

    auto payload_bytes = mwperf::canonical_artifact_payload_bytes_v1(
        source.source_built.artifact.payload);
    REQUIRE(payload_bytes);
    const auto payload_name =
        "payload_" + std::string(payload_names[index]) + ".json";
    write_bytes(payload_name, payload_bytes.value());
    write_wire_sha(payload_name, payload_bytes.value());
    auto payload_digest = mwperf::canonical_artifact_payload_digest_v1(
        source.source_built.artifact.payload);
    REQUIRE(payload_digest);
    CHECK(payload_digest.value() == source.source_built.artifact.payload_digest);
    write_text("payload_" + std::string(payload_names[index]) + ".sha256",
               payload_digest.value().hex());

    const auto* context = std::visit(
        [](const auto& active) -> const mwperf::PortablePayloadContextV1* {
          return &active.context;
        },
        source.portable_payload);
    CHECK(context->payload_class == source.source_built.artifact.payload_class);
    CHECK(context->semantic == source.source_built.artifact.deployed_semantic);
    CHECK(context->runtime_access ==
          source.source_built.artifact.runtime_access);
    CHECK(context->payload_identity ==
          source.source_built.artifact.payload_identity);
    CHECK(context->payload_digest == source.source_built.artifact.payload_digest);
    CHECK(context->structural_manifest_echo ==
          source.source_built.artifact.structural_manifest_echo);
    CHECK(context->realized_metric_bindings ==
          source.source_built.artifact.realized_metric_bindings);
    CHECK(context->family_evidence ==
          source.source_built.artifact.family_evidence);
    CHECK(context->scoped_evidence ==
          source.source_built.artifact.scoped_evidence);

    const auto normalized_payload = std::visit(
        [](const auto& active) -> mwperf::ArtifactPayloadV1 {
          return active.normalized_record;
        },
        source.portable_payload);
    auto normalized_bytes =
        mwperf::canonical_artifact_payload_bytes_v1(normalized_payload);
    REQUIRE(normalized_bytes);
    nlohmann::ordered_json ordered_targets = nlohmann::ordered_json::array();
    for (const auto& target : context->ordered_deployed_targets) {
      ordered_targets.push_back(*target.label().text_value());
    }
    const auto normalized_json =
        nlohmann::ordered_json::parse(text_of(normalized_bytes.value()));
    nlohmann::ordered_json portable_json = nlohmann::ordered_json::object();
    portable_json["snapshot_schema"] =
        "mwperf.c15.test.portable_plug_payload.v1";
    portable_json["portable_alternative"] = source.name;
    portable_json["context"] = nlohmann::ordered_json::object();
    auto& context_json = portable_json["context"];
    context_json["payload_class"] = source_artifact_json.at("payload_class");
    context_json["semantic"] = source_artifact_json.at("deployed_semantic");
    context_json["runtime_access"] = source_artifact_json.at("runtime_access");
    context_json["ordered_deployed_targets"] = std::move(ordered_targets);
    context_json["payload_identity"] =
        source_artifact_json.at("payload_identity");
    context_json["payload_digest"] = source_artifact_json.at("payload_digest");
    context_json["structural_manifest_echo"] =
        source_artifact_json.at("structural_manifest_echo");
    context_json["realized_metric_bindings"] =
        source_artifact_json.at("realized_metric_bindings");
    context_json["family_evidence"] =
        source_artifact_json.at("family_evidence");
    context_json["scoped_evidence"] =
        source_artifact_json.at("scoped_evidence");
    portable_json["normalized_record"] = normalized_json;
    if (const auto* response =
            std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
                &source.portable_payload)) {
      const auto& normalized_body = normalized_json.at("body");
      portable_json["deployed_target"] = normalized_body.at("deployed_target");
      portable_json["coefficients"] = nlohmann::ordered_json::array();
      for (const auto& coefficient : response->coefficients) {
        portable_json["coefficients"].push_back(
            rational_json(coefficient));
      }
      portable_json["selected_product"] =
          normalized_body.at("deployed_response_product_id");
    }
    write_json("portable_" + source.name + ".json", portable_json);
  }

  const auto all_stage_request = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.golden-all-stages", mwperf::MasterSeed(0xC15004U), 0U,
      all_stage_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_recoded_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion,
      mwperf::ProjectionPolicyV1::convex_feasible_mean,
      mwperf::RecodingPolicyV1::mean_inversion);
  const auto all_stage_built = make_bound_built_fixture(
      all_stage_request, bound_all_stage_three_bin_payload(all_stage_request));
  REQUIRE(validate_bound_built(all_stage_request, all_stage_built));
  auto all_stage_result_bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{all_stage_built.result});
  REQUIRE(all_stage_result_bytes);
  const auto all_stage_json = nlohmann::ordered_json::parse(
      text_of(all_stage_result_bytes.value()));
  const auto& all_stage_body =
      all_stage_json.at("artifact").at("payload").at("body");
  const auto& all_stages = std::get<mwperf::ThreeBinScalarResponseV1>(
      all_stage_built.result.artifact.payload);
  REQUIRE(all_stages.nominal_response.has_value());
  REQUIRE(all_stages.projection_center.has_value());
  REQUIRE(all_stages.projected_mean.has_value());
  REQUIRE(all_stages.recoded_response.has_value());
  const std::array<std::pair<std::string_view, std::string_view>, 5U>
      product_members{{{"raw", "raw_response"},
                       {"nominal", "nominal_response"},
                       {"projection_center", "projection_center"},
                       {"projected_mean", "projected_mean"},
                       {"recoded", "recoded_response"}}};
  for (const auto& [name, member] : product_members) {
    write_json("product_" + std::string(name) + ".json",
               all_stage_body.at(member));
  }
  write_text("product_raw.sha256",
             all_stages.raw_response.product_id.identity()
                 .object_digest.hex());
  write_text("product_nominal.sha256",
             all_stages.nominal_response->product_id.identity()
                 .object_digest.hex());
  write_text("product_projection_center.sha256",
             all_stages.projection_center->product_id.identity()
                 .object_digest.hex());
  write_text("product_projected_mean.sha256",
             all_stages.projected_mean->product_id.identity()
                 .object_digest.hex());
  write_text("product_recoded.sha256",
             all_stages.recoded_response->product_id.identity()
                 .object_digest.hex());
  write_text("three_bin_response_row.sha256",
             all_stages.response_row_id.object_digest.hex());

  const auto interval_request = make_bound_request_fixture(
      input, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      "c15.fixture.golden-interval", mwperf::MasterSeed(0xC15002U), 0U,
      interval_scalar_manifest(),
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
      mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion);
  const auto interval = make_bound_interval_response(interval_request);
  const mwperf::ArtifactPayloadV1 interval_payload = interval.response;
  auto interval_bytes =
      mwperf::canonical_artifact_payload_bytes_v1(interval_payload);
  auto interval_digest =
      mwperf::canonical_artifact_payload_digest_v1(interval_payload);
  REQUIRE(interval_bytes);
  REQUIRE(interval_digest);
  write_bytes("payload_three_bin_interval.json", interval_bytes.value());
  write_wire_sha("payload_three_bin_interval.json", interval_bytes.value());
  write_text("payload_three_bin_interval.sha256",
             interval_digest.value().hex());

  auto digest_mutated_interval = interval.response;
  digest_mutated_interval.raw_response.identifications[1U]
      .family_evidence_envelope_ids.front()
      .object_digest = digest_of("golden-full-evidence-digest-mutation");
  digest_mutated_interval.raw_envelopes.front()
      .family_evidence_envelope_ids.front()
      .object_digest = digest_of("golden-full-evidence-digest-mutation");
  const mwperf::ArtifactPayloadV1 digest_mutated_payload =
      digest_mutated_interval;
  auto digest_mutated_bytes =
      mwperf::canonical_artifact_payload_bytes_v1(digest_mutated_payload);
  auto digest_mutated_digest =
      mwperf::canonical_artifact_payload_digest_v1(digest_mutated_payload);
  REQUIRE(digest_mutated_bytes);
  REQUIRE(digest_mutated_digest);
  CHECK(digest_mutated_digest.value() == interval_digest.value());
  write_bytes("payload_three_bin_interval_digest_mutated.json",
              digest_mutated_bytes.value());
  write_wire_sha("payload_three_bin_interval_digest_mutated.json",
                 digest_mutated_bytes.value());
  write_text("family_interval_evidence.sha256",
             interval.interval_evidence.evidence_id.object_digest.hex());

  const auto interval_built = make_bound_built_fixture(
      interval_request, interval.response, {interval.interval_evidence});
  auto interval_result_bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{interval_built.result});
  REQUIRE(interval_result_bytes);
  write_bytes("result_built_interval.json", interval_result_bytes.value());
  write_wire_sha("result_built_interval.json",
                 interval_result_bytes.value());

  struct CoefficientStatusGolden final {
    const char* name;
    mwperf::ProposalConditioningSourceV1 source;
    mwperf::PopulationConditioningStatusV1 population;
    mwperf::RawValueStatusV1 raw;
  };
  const std::array coefficient_statuses{
      CoefficientStatusGolden{
          "exact_population_proved_positive_exact_point",
          mwperf::ProposalConditioningSourceV1::exact_population,
          mwperf::PopulationConditioningStatusV1::proved_positive,
          mwperf::RawValueStatusV1::exact_point},
      CoefficientStatusGolden{
          "exact_population_proved_positive_interval_only",
          mwperf::ProposalConditioningSourceV1::exact_population,
          mwperf::PopulationConditioningStatusV1::proved_positive,
          mwperf::RawValueStatusV1::interval_only},
      CoefficientStatusGolden{
          "empirical_average_positive_with_confidence_interval_only",
          mwperf::ProposalConditioningSourceV1::empirical_average,
          mwperf::PopulationConditioningStatusV1::positive_with_confidence,
          mwperf::RawValueStatusV1::interval_only},
      CoefficientStatusGolden{
          "exact_population_unresolved_interval_only",
          mwperf::ProposalConditioningSourceV1::exact_population,
          mwperf::PopulationConditioningStatusV1::unresolved,
          mwperf::RawValueStatusV1::interval_only},
      CoefficientStatusGolden{
          "exact_population_proved_zero_absent",
          mwperf::ProposalConditioningSourceV1::exact_population,
          mwperf::PopulationConditioningStatusV1::proved_zero,
          mwperf::RawValueStatusV1::absent},
      CoefficientStatusGolden{
          "exact_population_unresolved_absent",
          mwperf::ProposalConditioningSourceV1::exact_population,
          mwperf::PopulationConditioningStatusV1::unresolved,
          mwperf::RawValueStatusV1::absent}};
  for (std::size_t index = 0U; index < coefficient_statuses.size(); ++index) {
    const auto& status = coefficient_statuses[index];
    const auto response = [&]() -> mwperf::ThreeBinScalarResponseV1 {
      if (index == 0U) {
        return std::get<mwperf::ThreeBinScalarResponseV1>(
            golden_sources.front().source_built.artifact.payload);
      }
      if (status.population ==
          mwperf::PopulationConditioningStatusV1::proved_zero) {
        return make_bound_absence_response(interval_request).response;
      }
      return make_bound_closed_status_response(
                 interval_request, status.source, status.population,
                 status.raw)
          .response;
    }();
    const mwperf::ArtifactPayloadV1 status_payload = response;
    auto bytes = mwperf::canonical_artifact_payload_bytes_v1(status_payload);
    REQUIRE(bytes);
    const auto name =
        "payload_three_bin_status_" + std::string(status.name) + ".json";
    write_bytes(name, bytes.value());
    write_wire_sha(name, bytes.value());
    const auto json = nlohmann::ordered_json::parse(text_of(bytes.value()));
    const auto identification_index =
        status.raw == mwperf::RawValueStatusV1::absent
            ? 2U
            : (index == 0U ? 0U : 1U);
    write_json("coefficient_status_" + std::string(status.name) + ".json",
               json.at("body")
                   .at("raw_response")
                   .at("identifications")
                   .at(identification_index));
  }

  static constexpr std::array<std::string_view, 6U> table_names{
      "stationary_marked_edge", "staged_opportunity_flux",
      "temporal_continuation", "stopped_path", "romr_residence_word",
      "coupled_common_schedule"};
  auto finite_sources =
      mwperf::testing::make_finite_table_c15_golden_sources_v1();
  REQUIRE(finite_sources.size() == table_names.size());
  for (std::size_t index = 0U; index < finite_sources.size(); ++index) {
    const auto& source = finite_sources[index];
    CHECK(source.name == table_names[index]);
    auto bytes = mwperf::canonical_artifact_payload_bytes_v1(
        source.source_built.artifact.payload);
    REQUIRE(bytes);
    const auto full_name =
        "payload_finite_table_" + source.name + ".json";
    write_bytes(full_name, bytes.value());
    write_wire_sha(full_name, bytes.value());
    const auto payload_json =
        nlohmann::ordered_json::parse(text_of(bytes.value()));
    write_json("table_" + source.name + ".json",
               payload_json.at("body").at("table"));
    auto digest = mwperf::canonical_artifact_payload_digest_v1(
        source.source_built.artifact.payload);
    REQUIRE(digest);
    CHECK(digest.value() == source.source_built.artifact.payload_digest);
    write_text("table_" + source.name + ".sha256",
               digest.value().hex());
  }

  const auto bound_built = make_bound_built_fixture(fixture);
  const auto& bound_artifact = bound_built.result.artifact;
  const mwperf::RealizedBindingValidationContextV1 binding_context{
      {{queue_id("q0")}, queue_id("q0"),
       std::vector<mwperf::QueueId>(
           fixture.contract.construction_target_scope().begin(),
           fixture.contract.construction_target_scope().end())},
      fixture.contract.policies()};
  auto validated_bindings = mwperf::validate_realized_metric_bindings_v1(
      fixture.contract.structural_manifest(), binding_context,
      bound_artifact.realized_metric_bindings.bindings);
  REQUIRE(validated_bindings);
  auto binding_bytes = mwperf::canonical_realized_metric_bindings_bytes_v1(
      validated_bindings.value());
  REQUIRE(binding_bytes);
  write_bytes("realized_metric_bindings.bin", binding_bytes.value());
  write_wire_sha("realized_metric_bindings.bin", binding_bytes.value());
  auto binding_digest =
      mwperf::digest_realized_metric_bindings_v1(validated_bindings.value());
  REQUIRE(binding_digest);
  write_text("realized_metric_bindings.sha256",
             binding_digest.value().hex());
  write_bytes("structural_manifest.json",
              bound_artifact.structural_manifest_echo
                  .canonical_manifest_bytes);
  write_wire_sha("structural_manifest.json",
                 bound_artifact.structural_manifest_echo
                     .canonical_manifest_bytes);
  write_text("structural_manifest.sha256",
             bound_artifact.structural_manifest_echo.manifest_digest.hex());

  auto bound_result_bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{bound_built.result});
  REQUIRE(bound_result_bytes);
  const auto bound_json = nlohmann::ordered_json::parse(
      text_of(bound_result_bytes.value()));
  const auto& artifact_json = bound_json.at("artifact");
  write_json("structural_manifest_echo.json",
             artifact_json.at("structural_manifest_echo"));
  write_json("bound_realized_metric_bindings.json",
             artifact_json.at("realized_metric_bindings"));
  write_json("trusted_common_build_report_echo.json",
             artifact_json.at("build_report_echo"));
  REQUIRE(artifact_json.at("family_evidence").size() == 1U);
  REQUIRE(artifact_json.at("scoped_evidence").size() == 1U);
  write_json("family_evidence_envelope.json",
             artifact_json.at("family_evidence").at(0U));
  write_json("scoped_artifact_evidence.json",
             artifact_json.at("scoped_evidence").at(0U));
  write_json(
      "provider_conformance_report_ref.json",
      artifact_json.at("payload")
          .at("body")
          .at("raw_response")
          .at("identifications")
          .at(0U)
          .at("provider_conformance_report_ref"));

  auto not_applicable_report = sealed_report;
  not_applicable_report.optimizer_calls = {
      mwperf::WorkCounterApplicabilityV1::not_applicable,
      mwperf::BigNat{0U}};
  not_applicable_report.optimizer_search_states = {
      mwperf::WorkCounterApplicabilityV1::not_applicable,
      mwperf::BigNat{0U}};
  not_applicable_report.configured_generator_draws = {
      mwperf::WorkCounterApplicabilityV1::not_applicable,
      mwperf::BigNat{0U}};
  auto not_applicable_report_digest =
      mwperf::canonical_common_build_report_digest_v1(
          not_applicable_report);
  REQUIRE(not_applicable_report_digest);
  not_applicable_report.report_digest =
      std::move(not_applicable_report_digest).value();
  auto not_applicable_report_bytes =
      mwperf::canonical_common_build_report_bytes_v1(not_applicable_report);
  REQUIRE(not_applicable_report_bytes);
  write_bytes("common_build_report_not_applicable.json",
              not_applicable_report_bytes.value());
  write_wire_sha("common_build_report_not_applicable.json",
                 not_applicable_report_bytes.value());
  write_text("common_build_report_not_applicable.sha256",
             not_applicable_report.report_digest.hex());

  auto mode_erased = mwperf::testing::make_mode_erased_law_projection_v1(
      Factory::validated_artifact(bound_artifact), fixture.request,
      fixture.contract);
  REQUIRE(mode_erased);
  nlohmann::ordered_json mode_json;
  mode_json["projection_version"] = mode_erased.value().projection_version;
  mode_json["deployed_law"] = {
      {"payload_family_tag",
       static_cast<std::uint8_t>(
           mode_erased.value().deployed_law.payload_family_tag)},
      {"payload_family_version",
       mode_erased.value().deployed_law.payload_family_version},
      {"semantic_tag",
       static_cast<std::uint8_t>(mode_erased.value().deployed_law.semantic_tag)},
      {"mathematical_state_domain",
       static_cast<std::uint8_t>(
           mode_erased.value().deployed_law.mathematical_state_domain)},
      {"target_relative_state_and_mark_convention",
       static_cast<std::uint8_t>(mode_erased.value()
                                     .deployed_law
                                     .target_relative_state_and_mark_convention)},
      {"service_randomization_convention",
       static_cast<std::uint8_t>(mode_erased.value()
                                     .deployed_law
                                     .service_randomization_convention)}};
  for (const auto& parameter :
       mode_erased.value().deployed_law.canonical_law_parameters) {
    mode_json["deployed_law"]["canonical_law_parameters"].push_back(
        {{"numerator", parameter.numerator_decimal()},
         {"denominator", parameter.denominator_decimal()}});
  }
  mode_json["configured_arrival_math"] = {
      {"arrival_family_tag",
       static_cast<std::uint8_t>(
           mode_erased.value().configured_arrival_math.arrival_family_tag)},
      {"canonical_joint_law_or_recipe",
       text_of(mode_erased.value()
                   .configured_arrival_math
                   .canonical_joint_law_or_recipe)},
      {"predictive_phase_semantics",
       static_cast<std::uint8_t>(mode_erased.value()
                                     .configured_arrival_math
                                     .predictive_phase_semantics)},
      {"has_initial_predictive_state_law",
       mode_erased.value()
           .configured_arrival_math
           .initial_predictive_state_law.has_value()}};
  mode_json["timing_convention"] = {
      {"decision_service_arrival_order",
       static_cast<std::uint8_t>(mode_erased.value()
                                     .timing_convention
                                     .decision_service_arrival_order)}};
  for (const auto reveal : mode_erased.value()
                               .timing_convention
                               .observation_and_reveal_stages) {
    mode_json["timing_convention"]["observation_and_reveal_stages"]
        .push_back(static_cast<std::uint8_t>(reveal));
  }
  mode_json["metric_convention"]["selection_alternative"] =
      mode_erased.value()
          .metric_convention
          .initial_or_stationary_selection.index();
  for (const auto& metric : mode_erased.value()
                                .metric_convention
                                .normalized_metric_kinds_and_parameters) {
    mode_json["metric_convention"]["metric_kinds_and_parameter_alternatives"]
        .push_back(
            {{"metric_kind", static_cast<std::uint8_t>(metric.metric_kind)},
             {"parameter_alternatives",
              nlohmann::ordered_json::array()}});
    auto& alternatives =
        mode_json["metric_convention"]
                 ["metric_kinds_and_parameter_alternatives"]
                     .back()["parameter_alternatives"];
    for (const auto& parameter : metric.normalized_parameters) {
      alternatives.push_back(parameter.index());
    }
  }
  for (const auto& conditioning :
       mode_erased.value().metric_convention.conditioning_convention) {
    nlohmann::ordered_json value{
        {"target_coupling",
         static_cast<std::uint8_t>(conditioning.target_coupling)},
        {"payload_phase",
         static_cast<std::uint8_t>(conditioning.payload_phase)},
        {"arrival_composition",
         static_cast<std::uint8_t>(conditioning.arrival_composition)},
        {"retains_configured_predictive_phase",
         conditioning.retains_configured_predictive_phase},
        {"arrival_assumption_count",
         conditioning.arrival_assumptions.size()},
        {"hypothesis_count", conditioning.hypotheses.size()}};
    for (const auto field : conditioning.mathematical_state_fields) {
      value["mathematical_state_fields"].push_back(
          static_cast<std::uint8_t>(field));
    }
    for (const auto& hypothesis : conditioning.hypotheses) {
      value["hypothesis_kinds"].push_back(
          static_cast<std::uint8_t>(hypothesis.kind));
    }
    mode_json["metric_convention"]["conditioning_convention"].push_back(
        std::move(value));
  }
  for (const auto scope :
       mode_erased.value().metric_convention.result_scope) {
    mode_json["metric_convention"]["result_scope"].push_back(
        static_cast<std::uint8_t>(scope));
  }
  write_json("mode_erased_law_projection.json", mode_json);

  const mwperf::ResultEnvelopeV1 envelope{
      1U, fixture.request.request_digest().value(),
      fixture.manifest.value().provider, sealed_report};
  write_bytes("result_built.json", bound_result_bytes.value());
  write_wire_sha("result_built.json", bound_result_bytes.value());

  struct UnavailableGolden final {
    mwperf::UnavailableReasonKindV1 kind;
    const char* name;
  };
  const std::array unavailable_kinds{
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::inapplicable_target_structure,
          "inapplicable_target_structure"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::coefficient_proved_zero,
          "coefficient_proved_zero"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::coefficient_unresolved,
          "coefficient_unresolved"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::
              interval_only_without_authorized_point,
          "interval_only_without_authorized_point"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::unmet_construction_assumption,
          "unmet_construction_assumption"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::construction_domain_unavailable,
          "construction_domain_unavailable"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::required_evidence_unavailable,
          "required_evidence_unavailable"},
      UnavailableGolden{
          mwperf::UnavailableReasonKindV1::
              realized_capability_narrower_than_accepted,
          "realized_capability_narrower_than_accepted"}};
  for (std::size_t index = 0U; index < unavailable_kinds.size(); ++index) {
    const auto& item = unavailable_kinds[index];
    const mwperf::UnavailableSurrogateResultV1 unavailable{
        envelope,
        {{item.kind, "c15.golden." + std::string(item.name),
          "canonical unavailable reason " + std::string(item.name),
          clause_id("throughput"), object_ref("coefficient-1")}},
        index == 0U
            ? std::optional<mwperf::StrongestTruthfulAlternativeV1>{
                  {"canonical strongest truthful alternative",
                   mwperf::PayloadClassV1{
                       mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
                       1U},
                   mwperf::MetricResultScopeV1::surrogate_law}}
            : std::nullopt};
    auto validated = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{unavailable}, fixture.request,
        fixture.manifest, fixture.contract, bound_built.validated_report);
    REQUIRE(validated);
    auto bytes =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{unavailable});
    REQUIRE(bytes);
    const auto name =
        "result_unavailable_" + std::string(item.name) + ".json";
    write_bytes(name, bytes.value());
    write_wire_sha(name, bytes.value());
  }

  struct FailureGolden final {
    mwperf::ProviderFailureKindV1 kind;
    const char* name;
  };
  const std::array failure_kinds{
      FailureGolden{mwperf::ProviderFailureKindV1::construction_failure,
                    "construction_failure"},
      FailureGolden{mwperf::ProviderFailureKindV1::resource_exhausted,
                    "resource_exhausted"},
      FailureGolden{mwperf::ProviderFailureKindV1::invariant_violation,
                    "invariant_violation"},
      FailureGolden{mwperf::ProviderFailureKindV1::provider_internal_error,
                    "provider_internal_error"}};
  for (const auto& item : failure_kinds) {
    const mwperf::FailedSurrogateResultV1 failed{
        envelope,
        {item.kind, "c15.golden." + std::string(item.name),
         "canonical provider failure " + std::string(item.name)}};
    auto validated = mwperf::validate_surrogate_build_result(
        mwperf::SurrogateBuildResultV1{failed}, fixture.request,
        fixture.manifest, fixture.contract, bound_built.validated_report);
    REQUIRE(validated);
    auto bytes =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            mwperf::SurrogateBuildResultV1{failed});
    REQUIRE(bytes);
    const auto name = "result_failed_" + std::string(item.name) + ".json";
    write_bytes(name, bytes.value());
    write_wire_sha(name, bytes.value());
  }

  auto diagnostic_built = bound_built;
  const std::array diagnostic_scopes{
      mwperf::ArtifactDiagnosticScopeV1::construction_integration,
      mwperf::ArtifactDiagnosticScopeV1::input_bank_initialization,
      mwperf::ArtifactDiagnosticScopeV1::optimizer_certification,
      mwperf::ArtifactDiagnosticScopeV1::coefficient_sampling,
      mwperf::ArtifactDiagnosticScopeV1::compression,
      mwperf::ArtifactDiagnosticScopeV1::projection,
      mwperf::ArtifactDiagnosticScopeV1::recoding,
      mwperf::ArtifactDiagnosticScopeV1::solver,
      mwperf::ArtifactDiagnosticScopeV1::physical_fidelity};
  for (std::size_t index = 0U; index < diagnostic_scopes.size(); ++index) {
    diagnostic_built.result.artifact.diagnostic_components.push_back(
        {1U, label("diagnostic." + std::to_string(index)),
         diagnostic_scopes[index],
         "c15.golden.diagnostic." + std::to_string(index),
         "canonical diagnostic scope " + std::to_string(index), {}, {}});
  }
  REQUIRE(validate_bound_built(fixture, diagnostic_built));
  auto diagnostic_bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{diagnostic_built.result});
  REQUIRE(diagnostic_bytes);
  write_bytes("result_built_all_diagnostic_scopes.json",
              diagnostic_bytes.value());
  write_wire_sha("result_built_all_diagnostic_scopes.json",
                 diagnostic_bytes.value());
  const auto diagnostic_json = nlohmann::ordered_json::parse(
      text_of(diagnostic_bytes.value()));
  write_json("artifact_diagnostic_components_all_scopes.json",
             diagnostic_json.at("artifact").at("diagnostic_components"));
  auto smallest_subnormal =
      mwperf::PortableScientificScalar::parse_binary64(
          "0x0000000000000001");
  REQUIRE(smallest_subnormal);
  auto large_natural = mwperf::BigNat::from_big_int(
      mwperf::BigInt("1234567890123456789012345678901234567890"));
  REQUIRE(large_natural);
  const std::array rational_values{
      std::pair{"negative_reduced", scalar(-3, 7)},
      std::pair{"zero", scalar(0, 1)},
      std::pair{"positive_reduced", scalar(5, 7)}};
  const std::array binary_values{
      std::pair{"positive_zero", binary_scalar(0.0)},
      std::pair{"smallest_subnormal", smallest_subnormal.value()},
      std::pair{"representative_fraction", binary_scalar(0.25)},
      std::pair{"representative_normal", binary_scalar(1.5)},
      std::pair{"endpoint_one", binary_scalar(1.0)}};
  auto number_corpus = nlohmann::ordered_json::object();
  number_corpus["portable_scientific_scalar_rational"] =
      nlohmann::ordered_json::array();
  for (const auto& [name, value] : rational_values) {
    number_corpus["portable_scientific_scalar_rational"].push_back(
        {{"name", name},
         {"wire", mwperf::artifact::detail::wire::encode_scalar(value)},
         {"tagged_encoding", value.canonical_tagged_encoding()}});
  }
  number_corpus["portable_scientific_scalar_binary64"] =
      nlohmann::ordered_json::array();
  for (const auto& [name, value] : binary_values) {
    number_corpus["portable_scientific_scalar_binary64"].push_back(
        {{"name", name},
         {"wire", mwperf::artifact::detail::wire::encode_scalar(value)},
         {"tagged_encoding", value.canonical_tagged_encoding()},
         {"exact_dyadic_after_adaptation",
          rational_json(mwperf::binary64_as_exact_rational(value))}});
  }
  number_corpus["canonical_nonnegative_integer"] =
      nlohmann::ordered_json::array(
          {{{"name", "zero"},
            {"wire", mwperf::artifact::detail::wire::encode_big_nat(
                         mwperf::BigNat{0U})}},
           {{"name", "large_decimal"},
            {"wire", mwperf::artifact::detail::wire::encode_big_nat(
                         large_natural.value())}}});
  write_json("exact_number_corpus_v1.json", number_corpus);

  for (const auto& [name, value] : rational_values) {
    write_text("scalar_rational_" + std::string(name) + ".tagged.txt",
               value.canonical_tagged_encoding());
  }
  for (const auto& [name, value] : binary_values) {
    write_text("scalar_binary64_" + std::string(name) + ".tagged.txt",
               value.canonical_tagged_encoding());
  }

  const auto golden_directory =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
      "fixtures" / "c15" / "golden";
  REQUIRE(std::filesystem::is_directory(golden_directory));
  const auto relative_files = [](const std::filesystem::path& root) {
    std::vector<std::string> result;
    for (const auto& entry :
         std::filesystem::recursive_directory_iterator(root)) {
      if (entry.is_regular_file()) {
        result.push_back(
            std::filesystem::relative(entry.path(), root).generic_string());
      }
    }
    std::sort(result.begin(), result.end());
    return result;
  };
  const auto read_file = [](const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    REQUIRE(input.is_open());
    return std::vector<char>(std::istreambuf_iterator<char>(input),
                             std::istreambuf_iterator<char>());
  };
  const auto expected_files = relative_files(golden_directory);
  const auto actual_files = relative_files(output_directory);
  REQUIRE(actual_files == expected_files);
  for (const auto& relative : expected_files) {
    INFO(relative);
    CHECK(read_file(output_directory / relative) ==
          read_file(golden_directory / relative));
  }
}
