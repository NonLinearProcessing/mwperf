#include <algorithm>
#include <array>
#include <atomic>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_registered_pair_matrix_fixture.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
namespace matrix = mwperf::testing::c16_registered_pair_matrix;
namespace designated = mwperf::testing::c16_designated_detail;
namespace coupled = mwperf::testing::c16_coupled_fixture;

[[nodiscard]] mwperf::SourceNode parameter_object(
    const std::optional<std::string_view> lexeme,
    const bool string_value = false,
    const bool add_unknown = false) {
  const mwperf::SourceLocation location{
      "c16-registered-pair-parameters.json", 1U, 1U, 0U};
  std::vector<mwperf::SourceObjectMember> members;
  if (lexeme.has_value()) {
    members.push_back(
        {"resolution_level", location,
         string_value
             ? mwperf::SourceNode::make_string(
                   std::string(*lexeme), location, "/resolution_level")
             : mwperf::SourceNode::make_number(
                   std::string(*lexeme), location, "/resolution_level")});
  }
  if (add_unknown) {
    members.push_back(
        {"unknown", location,
         mwperf::SourceNode::make_number("1", location, "/unknown")});
  }
  return mwperf::SourceNode::make_object(std::move(members), location, "");
}

[[nodiscard]] std::filesystem::path execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c16-registered-pair-matrix";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

[[nodiscard]] mwperf::testing::C16DesignatedScenarioV1 scenario(
    const matrix::ProfileV1& profile) {
  auto input = [&] {
    if (profile.semantic !=
        mwperf::SemanticTagV1::coupled_target_schedule_law) {
      // A normalized conditional sampler is a C24 row/reward Monte Carlo
      // access route, not an analytic stationary-throughput route.  Select
      // the registered stationary-edge reward clause for that singular
      // semantic/access profile so the C16 matrix exercises the authored
      // pair without relabelling an incompatible metric route.
      return designated::input(
          profile.provider_id,
          profile.access ==
              mwperf::RuntimeAccessTagV1::normalized_conditional_sampler);
    }
    auto source = coupled::input();
    auto request = mwperf::parse_metric_request(
        source.instance.analysis_spec().metrics.front(),
        source.instance.queues());
    REQUIRE(request);
    return designated::InputV1{
        std::move(source.instance), std::move(source.arrival),
        std::move(source.requirements), std::move(request).value()};
  }();
  auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  std::vector<mwperf::QueueId> targets{designated::queue("q0")};
  if (profile.semantic ==
      mwperf::SemanticTagV1::coupled_target_schedule_law) {
    targets.push_back(designated::queue("q1"));
  }
  const mwperf::TargetSelection selection{
      1U, std::move(targets),
      mwperf::ConstructionGroupIdV1(
          designated::label("c16.registered-pair.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, selection);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), parameter_object("1"));
  REQUIRE(parameters);
  auto budget = designated::budget();
  if (profile.access ==
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler) {
    REQUIRE(input.instance.analysis_spec().context);
    const auto& draw_cap = input.instance.analysis_spec()
                               .context->resolution.sampling
                               .max_generator_draws;
    REQUIRE(draw_cap.has_value());
    budget.configured_generator_draws = {
        mwperf::BudgetApplicabilityV1::applicable, *draw_cap};
  }
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, budget,
      parameters.value());
  INFO((preview ? std::string{} : preview.error().code));
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, mwperf::MasterSeed(0xC1609U));
  INFO((request ? std::string{} : request.error().code));
  REQUIRE(request);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(), manifest, std::move(input.instance),
          std::move(input.arrival), std::move(input.requirements),
          std::move(input.request), std::move(view).value(),
          std::move(parameters).value(), std::move(preview).value(),
          std::move(contract), budget, std::move(request).value()};
}

[[nodiscard]] mwperf::FiniteLawTableAlternativeV1 finite_table(
    const matrix::ProfileV1& profile) {
  const auto law = designated::object("c16.registered-pair.law");
  switch (profile.semantic) {
    case mwperf::SemanticTagV1::stationary_marked_edge:
      return mwperf::StationaryMarkedEdgeTableV1{
          1U, law, mwperf::FiniteTableStorageV1::dense, {},
          {"queue.big_nat", 1U}, {"arrival.phase", 1U},
          {"service.bit", 1U}, {"edge.mark", 1U},
          designated::digest("c16.registered-pair.conditioning")};
    case mwperf::SemanticTagV1::staged_opportunity_flux_law:
      return mwperf::StagedOpportunityFluxTableV1{
          1U, law, mwperf::FiniteTableStorageV1::sparse, {}, {}, {}, {},
          designated::digest("c16.registered-pair.arrival"),
          {"arrival.innovation", 1U},
          designated::object("c16.registered-pair.update"),
          designated::object("c16.registered-pair.retained"),
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival,
           mwperf::MetricRevealStageV1::completed_edge}};
    case mwperf::SemanticTagV1::coupled_target_schedule_law:
      return mwperf::CoupledCommonScheduleTableV1{
          1U, law, mwperf::FiniteTableStorageV1::dense, {},
          designated::digest("c16.registered-pair.geometry"),
          designated::digest("c16.registered-pair.tie-phase")};
    default:
      break;
  }
  FAIL("a non-table registered pair requested a table payload");
  return mwperf::StationaryMarkedEdgeTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {},
      {"queue.big_nat", 1U}, {"arrival.phase", 1U},
      {"service.bit", 1U}, {"edge.mark", 1U},
      designated::digest("c16.registered-pair.unreachable")};
}

[[nodiscard]] mwperf::ArtifactPayloadV1 payload(
    const matrix::ProfileV1& profile,
    const mwperf::testing::C16DesignatedScenarioV1& value) {
  auto response = mwperf::testing::make_c16_designated_response_v1(
      value, mwperf::testing::c16_designated_payload_options_v1(
                 mwperf::testing::C16DesignatedResponseStageV1::raw));
  const auto targets = value.preview.core.deployed_targets;
  switch (profile.payload) {
    case mwperf::PayloadClassTagV1::three_bin_scalar_response_v1:
      return response;
    case mwperf::PayloadClassTagV1::finite_law_tables_v1:
      return mwperf::FiniteLawTablesV1{
          1U, targets, profile.semantic, profile.access,
          value.view.fingerprints().compiled_arrival,
          designated::digest("c16.registered-pair.selection"), {}, {},
          finite_table(profile)};
    case mwperf::PayloadClassTagV1::registered_runtime_recipe_v1:
      return mwperf::RegisteredRuntimeRecipeV1{
          1U, "c16.registered-pair.recipe", 1U,
          "c16.registered-pair.recipe-parameters", 1U,
          "c16.registered-pair.recipe-state", 1U,
          "c16.registered-pair.recipe-mark", 1U,
          value.provider.identity(), targets, {}, value.preview.core.state_fields,
          value.preview.core.marks};
    case mwperf::PayloadClassTagV1::response_envelope_evidence_v1:
      return mwperf::ResponseEnvelopeEvidenceV1{
          1U, targets, mwperf::MetricResultScopeV1::response_envelope,
          mwperf::MetricEvidenceScopeV1::validity_or_lift,
          response, response, response.deployed_response_product_id,
          response.deployed_response_product_id,
          designated::object("c16.registered-pair.envelope-comparison"),
          {mwperf::deployed_response_product_identity_v1(
              response.deployed_response_product_id)},
          true, response.deployed_response_product_id};
    case mwperf::PayloadClassTagV1::direct_metric_payload_v1:
      return mwperf::DirectMetricPayloadV1{1U, {}};
    case mwperf::PayloadClassTagV1::
        finite_prefix_constant_tail_response_v1:
    case mwperf::PayloadClassTagV1::
        empirical_finite_window_response_v1:
    case mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1:
      break;
  }
  FAIL("the registered pair matrix selected an unconfigured payload");
  return mwperf::DirectMetricPayloadV1{1U, {}};
}

struct MaterializationV1 final {
  mwperf::ValidatedSurrogateArtifact artifact;
  mwperf::PortablePlugPayload payload;
};

[[nodiscard]] MaterializationV1 materialization(
    const matrix::ProfileV1& profile,
    const mwperf::testing::C16DesignatedScenarioV1& value) {
  const auto payload_identity =
      designated::object("c16.registered-pair.payload");
  const auto payload_digest =
      designated::digest("c16.registered-pair.payload-bytes");
  const auto echo = designated::manifest_echo(
      value.contract.structural_manifest());
  const mwperf::BoundRealizedMetricBindingsV1 realized{
      value.request.request_digest().value(), payload_digest, {}};
  mwperf::SurrogateArtifactV1 source{
      1U,
      value.request.request_digest().value(),
      value.provider.identity(),
      value.provider.manifest().scientific_contract_digest().value(),
      value.contract.construction_method(),
      value.contract.producer_mode(),
      profile.semantic,
      profile.access,
      {profile.payload, 1U},
      payload_identity,
      payload(profile, value),
      payload_digest,
      echo,
      realized,
      value.preview.core,
      designated::report(value),
      {},
      {},
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          value.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  const mwperf::ArtifactValidationBindingsV1 bindings{
      value.request.build_identity_digest().digest(),
      value.request.request_digest().value(),
      value.provider.identity(),
      value.provider.manifest().value().parameter_schema_version,
      value.provider.manifest().scientific_contract_digest().value(),
      value.contract.construction_method(),
      value.contract.producer_mode(),
      profile.semantic,
      profile.access,
      {profile.payload, 1U},
      value.view.canonical_digest().value(),
      std::move(selection_digest).value(),
      value.contract.contract_digest(),
      value.contract.requirements_digest(),
      value.contract.arrival_capabilities_digest(),
      value.contract.preview_digest(),
      value.contract.parameter_digest(),
      value.contract.budget_digest(),
      value.contract.structural_manifest().canonical_digest()};
  auto artifact = Factory::validated_artifact(std::move(source), bindings);
  auto portable = mwperf::adapt_portable_payload(artifact);
  INFO((portable ? std::string{} : portable.error().code));
  REQUIRE(portable);
  return {std::move(artifact), std::move(portable).value()};
}

}  // namespace

TEST_CASE("C16 every singular registered semantic-access pair traverses its static provider",
          "[c16][integration][provider-pair-matrix]") {
  matrix::reset_counters();
  std::array<bool, 9U> semantics{};
  std::array<bool, 7U> accesses{};

  for (std::size_t index = 0U; index < matrix::kProfiles.size(); ++index) {
    const auto& profile = matrix::kProfiles[index];
    CAPTURE(profile.provider_id);
    auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
    REQUIRE(id);
    auto provider = mwperf::lookup_surrogate_provider(id.value());
    REQUIRE(provider);
    CHECK(provider.value().manifest().value().deployed_semantic_tag ==
          profile.semantic);
    CHECK(provider.value().manifest().value().runtime_access_tag ==
          profile.access);
    CHECK(provider.value().manifest().value().payload_class ==
          mwperf::PayloadClassV1{profile.payload, 1U});
    const std::size_t expected_clause_count =
        profile.access ==
                mwperf::RuntimeAccessTagV1::normalized_conditional_sampler
            ? 5U
            : 1U;
    REQUIRE(provider.value().manifest().value()
                .metric_clause_upper_envelope.clauses().size() ==
            expected_clause_count);

    const std::array invalid{
        std::pair{parameter_object(std::nullopt),
                  std::string_view{"c16.fixture.parameter_missing"}},
        std::pair{parameter_object(std::nullopt, false, true),
                  std::string_view{"c16.fixture.parameter_unknown"}},
        std::pair{parameter_object("1", true),
                  std::string_view{"c16.fixture.parameter_wrong_type"}},
        std::pair{parameter_object("0"),
                  std::string_view{"c16.fixture.parameter_out_of_domain"}}};
    for (const auto& [parameters, code] : invalid) {
      auto rejected = mwperf::validate_surrogate_parameters(
          provider.value(), parameters);
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == code);
    }

    auto value = scenario(profile);
    auto context = mwperf::BuildExecutionContext::create(
        value.request, value.provider.manifest(), execution_root());
    REQUIRE(context);
    const auto outcome = mwperf::execute_surrogate_provider(
        value.provider, value.request, context.value());
    const auto* completed =
        std::get_if<mwperf::CompletedProviderExecution>(&outcome);
    REQUIRE(completed != nullptr);
    auto parsed = mwperf::parse_surrogate_build_result(
        completed->bytes,
        mwperf::ArtifactParseLimits{1U << 24U, 128U, 1U << 18U,
                                    1U << 20U, 1U << 20U, 1U << 22U,
                                    1U << 25U});
    INFO((parsed ? std::string{} : parsed.error().code));
    REQUIRE(parsed);
    auto report = mwperf::validate_surrogate_build_report(
        parsed.value(), value.request, value.budget);
    INFO((report ? std::string{} : report.error().code));
    REQUIRE(report);
    auto validated = mwperf::validate_surrogate_build_result(
        parsed.value(), value.request, value.manifest, value.contract,
        report.value());
    INFO((validated ? std::string{} : validated.error().code));
    REQUIRE(validated);

    auto ready = materialization(profile, value);
    auto reached = mwperf::materialize_and_validate_surrogate_plug(
        ready.payload, ready.artifact, value.contract);
    REQUIRE_FALSE(reached);
    CHECK(reached.error().code ==
          "c16.fixture.registered_pair_materializer_reached");

    const auto& calls = matrix::counters()[index];
    CHECK(calls.parameter.load(std::memory_order_relaxed) == 5U);
    CHECK(calls.preview.load(std::memory_order_relaxed) == 1U);
    CHECK(calls.execute.load(std::memory_order_relaxed) == 1U);
    CHECK(calls.materialize.load(std::memory_order_relaxed) == 1U);
    semantics[static_cast<std::size_t>(profile.semantic)] = true;
    accesses[static_cast<std::size_t>(profile.access)] = true;
  }

  CHECK(std::all_of(semantics.begin(), semantics.end(), [](const bool value) {
    return value;
  }));
  CHECK(std::all_of(accesses.begin(), accesses.end(), [](const bool value) {
    return value;
  }));
}
