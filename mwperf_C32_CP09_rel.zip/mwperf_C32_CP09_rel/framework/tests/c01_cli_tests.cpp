#include <algorithm>
#include <array>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <locale>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "cli_runtime.hpp"
#include "mwperf/build_information.hpp"
#include "mwperf/cli.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/result.hpp"

namespace {

[[nodiscard]] std::vector<std::string_view> views_of(
    const std::vector<std::string>& values) {
  std::vector<std::string_view> views;
  views.reserve(values.size());
  for (const std::string& value : values) {
    views.emplace_back(value);
  }
  return views;
}

[[nodiscard]] mwperf::Result<mwperf::CliRequest> parse(
    const std::vector<std::string>& values) {
  const std::vector<std::string_view> views = views_of(values);
  return mwperf::parse_cli(views);
}

[[nodiscard]] std::string failure_code(const std::vector<std::string>& values) {
  const auto result = parse(values);
  REQUIRE_FALSE(result.has_value());
  return result.error().code;
}

class Argv {
 public:
  explicit Argv(std::vector<std::string> arguments) {
    storage_.reserve(arguments.size() + 1U);
    storage_.emplace_back("mwperf");
    for (std::string& argument : arguments) {
      storage_.push_back(std::move(argument));
    }
    pointers_.reserve(storage_.size());
    for (std::string& value : storage_) {
      pointers_.push_back(value.data());
    }
  }

  [[nodiscard]] int argc() const {
    return static_cast<int>(pointers_.size());
  }

  [[nodiscard]] char* const* argv() const { return pointers_.data(); }

 private:
  std::vector<std::string> storage_;
  std::vector<char*> pointers_;
};

class OddNumpunct final : public std::numpunct<char> {
 protected:
  [[nodiscard]] char do_decimal_point() const override { return ','; }
  [[nodiscard]] char do_thousands_sep() const override { return '_'; }
  [[nodiscard]] std::string do_grouping() const override { return "\1"; }
};

class GlobalLocaleGuard {
 public:
  GlobalLocaleGuard() : previous_(std::locale()) {}
  GlobalLocaleGuard(const GlobalLocaleGuard&) = delete;
  GlobalLocaleGuard& operator=(const GlobalLocaleGuard&) = delete;
  ~GlobalLocaleGuard() { std::locale::global(previous_); }

 private:
  std::locale previous_;
};

[[nodiscard]] mwperf::Result<void> throwing_analysis(
    const mwperf::Analyze&) {
  throw std::runtime_error("private exception text must not escape");
}

[[nodiscard]] std::size_t occurrence_count(const std::string& text,
                                           const std::string_view needle) {
  std::size_t count = 0;
  std::size_t position = 0;
  while ((position = text.find(needle, position)) != std::string::npos) {
    ++count;
    position += needle.size();
  }
  return count;
}

}  // namespace

TEST_CASE("analysis options are order independent", "[c01][unit][property]") {
  const std::array<std::pair<std::string, std::string>, 3> pairs{{
      {"--model", "authored/../model.yaml"},
      {"--analysis", "analysis.json"},
      {"--output", "result.json"},
  }};
  std::array<std::size_t, 3> order{{0U, 1U, 2U}};

  do {
    std::vector<std::string> arguments;
    for (const std::size_t index : order) {
      arguments.push_back(pairs[index].first);
      arguments.push_back(pairs[index].second);
    }

    const auto result = parse(arguments);
    REQUIRE(result.has_value());
    REQUIRE(std::holds_alternative<mwperf::Analyze>(result.value().mode));
    const auto& analyze = std::get<mwperf::Analyze>(result.value().mode);
    CHECK(analyze.model_path.authored == "authored/../model.yaml");
    CHECK(analyze.model_path.path ==
          std::filesystem::path("authored/../model.yaml"));
    CHECK(analyze.analysis_path.authored == "analysis.json");
    CHECK(analyze.output_path.authored == "result.json");
    CHECK(analyze.worker_count == 1U);
    CHECK(analyze.timeout_seconds == 3600U);
    CHECK_FALSE(analyze.output_resources);
    CHECK_FALSE(analyze.report_unavailable_diagnostics);
  } while (std::next_permutation(order.begin(), order.end()));
}

TEST_CASE("built-in Full Orbit target options are order independent",
          "[c01][unit][property]") {
  const std::array<std::pair<std::string, std::string>, 3> pairs{{
      {"--model", "canonicalschema.json"},
      {"--target", "hub"},
      {"--output", "result.json"},
  }};
  std::array<std::size_t, 3> order{{0U, 1U, 2U}};

  do {
    std::vector<std::string> arguments;
    for (const std::size_t index : order) {
      arguments.push_back(pairs[index].first);
      arguments.push_back(pairs[index].second);
    }
    const auto result = parse(arguments);
    REQUIRE(result.has_value());
    const auto& analyze = std::get<mwperf::Analyze>(result.value().mode);
    REQUIRE(analyze.target_queue.has_value());
    CHECK(*analyze.target_queue == "hub");
    CHECK(analyze.analysis_path.authored.empty());
    CHECK(analyze.model_path.authored == "canonicalschema.json");
    CHECK(analyze.output_path.authored == "result.json");
    CHECK(analyze.worker_count == 1U);
    CHECK(analyze.timeout_seconds == 3600U);
    CHECK_FALSE(analyze.output_resources);
    CHECK_FALSE(analyze.report_unavailable_diagnostics);
  } while (std::next_permutation(order.begin(), order.end()));
}

TEST_CASE("CP09 compression cutoffs are canonical arbitrary naturals",
          "[c01][c32][unit]") {
  constexpr std::string_view enormous =
      "115792089237316195423570985008687907853269984665640564039457584007913129639936";
  const auto parsed = parse(
      {"compare-compression", "--stationary-reference", "stationary.json",
       "--finite-window-reference", "finite.json", "--weighted-ensemble",
       "weighted.json", "--cutoff", std::string(enormous), "--cutoff", "0",
       "--output", "comparison.json"});
  REQUIRE(parsed.has_value());
  const auto& comparison =
      std::get<mwperf::CompareCompression>(parsed.value().mode);
  REQUIRE(comparison.cutoffs.size() == 2U);
  CHECK(comparison.cutoffs.front() == mwperf::BigNat{0U});
  CHECK(comparison.cutoffs.back().to_decimal_string() == enormous);

  CHECK(failure_code(
            {"compare-compression", "--stationary-reference", "stationary.json",
             "--finite-window-reference", "finite.json", "--weighted-ensemble",
             "weighted.json", "--cutoff", "01", "--output",
             "comparison.json"}) == "cli_invalid_compression_cutoff");
}

TEST_CASE("provider execution controls are explicit host-only CLI values",
          "[c01][unit]") {
  const auto result = parse({"--workers", "32", "--model", "model.json",
                             "--timeout-seconds", "86400", "--target", "q0",
                             "--output", "result.json", "--output_resources",
                             "--report_unavailable_diagnostics"});
  REQUIRE(result.has_value());
  const auto& analyze = std::get<mwperf::Analyze>(result.value().mode);
  CHECK(analyze.worker_count == 32U);
  CHECK(analyze.timeout_seconds == 86400U);
  CHECK(analyze.output_resources);
  CHECK(analyze.report_unavailable_diagnostics);
}

TEST_CASE("help and version parse as closed exclusive modes", "[c01][unit]") {
  const auto help = parse({"--help"});
  REQUIRE(help.has_value());
  CHECK(std::holds_alternative<mwperf::Help>(help.value().mode));

  const auto version = parse({"--version"});
  REQUIRE(version.has_value());
  CHECK(std::holds_alternative<mwperf::Version>(version.value().mode));
}

TEST_CASE("build information is complete and stable", "[c01][unit]") {
  const mwperf::BuildInformation first = mwperf::build_information();
  const mwperf::BuildInformation second = mwperf::build_information();
  CHECK(first == second);
  CHECK_FALSE(first.program_version.empty());
  CHECK_FALSE(first.source_tree_version.empty());
  CHECK_FALSE(first.compiler_id.empty());
  CHECK_FALSE(first.compiler_version.empty());
  CHECK_FALSE(first.enabled_features.empty());
  CHECK(first.physical_schema_version == "3.0.0,4.0.0");
  CHECK(first.analysis_schema_version == "1.0.0");
  CHECK(first.rng_algorithm_version == "xoshiro256ss-v1");
  CHECK_FALSE(first.function_interface_manifest_version.empty());
}

TEST_CASE("diagnostic rendering is deterministic and byte escaped",
          "[c01][unit][property]") {
  std::string path = "model\\name\n\"";
  path.push_back(static_cast<char>(0xFF));
  const mwperf::Diagnostic diagnostic{
      .category = mwperf::DiagnosticCategory::cli_usage,
      .code = "test[code]",
      .message = "bad\nmessage",
      .authored_path = path,
      .json_pointer = "/arrival/0",
      .notes = {"first", "second\tentry"},
  };

  const std::string first = mwperf::render_cli_diagnostic(diagnostic);
  {
    GlobalLocaleGuard guard;
    std::locale::global(
        std::locale(std::locale::classic(), new OddNumpunct));
    const std::string second = mwperf::render_cli_diagnostic(diagnostic);
    CHECK(first == second);
  }

  CHECK(first ==
        "mwperf: cli_usage[test\\x5Bcode\\x5D]: \"bad\\x0Amessage\"\n"
        "  path: \"model\\\\name\\x0A\\\"\\xFF\"\n"
        "  pointer: \"/arrival/0\"\n"
        "  note: \"first\"\n"
        "  note: \"second\\x09entry\"\n");
}

TEST_CASE("duplicate known options fail at every insertion point",
          "[c01][negative][property]") {
  const std::vector<std::string> base{
      "--model", "m", "--analysis", "a", "--output", "o"};
  for (const std::string& option :
       {std::string("--model"), std::string("--analysis"),
        std::string("--output"), std::string("--workers"),
        std::string("--timeout-seconds")}) {
    for (std::size_t position = 0; position <= base.size(); ++position) {
      std::vector<std::string> candidate = base;
      candidate.insert(candidate.begin() + static_cast<std::ptrdiff_t>(position),
                       {option, "duplicate"});
      CHECK_FALSE(parse(candidate).has_value());
    }
  }
  CHECK(failure_code({"--model", "m", "--target", "hub", "--target",
                      "leaf", "--output", "o"}) ==
        "cli_duplicate_option");
  CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                      "--workers", "2", "--workers", "3"}) ==
        "cli_duplicate_option");
  CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                      "--timeout-seconds", "10", "--timeout-seconds", "20"}) ==
        "cli_duplicate_option");
  CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                      "--output_resources", "--output_resources"}) ==
        "cli_duplicate_option");
  CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                      "--report_unavailable_diagnostics",
                      "--report_unavailable_diagnostics"}) ==
        "cli_duplicate_option");
}

TEST_CASE("unknown options and positional arguments always fail",
          "[c01][negative][property]") {
  const std::vector<std::string> base{
      "--model", "m", "--analysis", "a", "--output", "o"};
  for (std::size_t position = 0; position <= base.size(); ++position) {
    std::vector<std::string> unknown = base;
    unknown.insert(unknown.begin() + static_cast<std::ptrdiff_t>(position),
                   "--bogus");
    CHECK_FALSE(parse(unknown).has_value());

    std::vector<std::string> positional = base;
    positional.insert(
        positional.begin() + static_cast<std::ptrdiff_t>(position), "stray");
    CHECK_FALSE(parse(positional).has_value());
  }
}

TEST_CASE("malformed and mixed invocations have stable usage failures",
          "[c01][negative]") {
  CHECK(failure_code({}) == "cli_no_arguments");
  CHECK(failure_code({"--model"}) == "cli_missing_value");
  CHECK(failure_code({"--analysis"}) == "cli_missing_value");
  CHECK(failure_code({"--target"}) == "cli_missing_value");
  CHECK(failure_code({"--output"}) == "cli_missing_value");
  CHECK(failure_code({"--workers"}) == "cli_missing_value");
  CHECK(failure_code({"--timeout-seconds"}) == "cli_missing_value");
  CHECK(failure_code({"--analysis", ""}) == "cli_empty_value");
  CHECK(failure_code({"--target", ""}) == "cli_empty_value");
  CHECK(failure_code({"--bogus"}) == "cli_unknown_option");
  CHECK(failure_code({"positional"}) == "cli_unexpected_argument");
  CHECK(failure_code({"--model", "m"}) ==
        "cli_missing_required_option");
  CHECK(failure_code(
            {"--model", "m", "--analysis", "a"}) ==
        "cli_missing_required_option");
  CHECK(failure_code(
            {"--model", "m", "--output", "o"}) ==
        "cli_missing_required_option");
  CHECK(failure_code(
            {"--analysis", "a", "--output", "o"}) ==
        "cli_missing_required_option");
  CHECK(failure_code({"--model", "m", "--target", "hub", "--analysis",
                      "a", "--output", "o"}) ==
        "cli_conflicting_analysis_source");
  CHECK(failure_code({"--model", ""}) == "cli_empty_value");
  CHECK(failure_code({"--output", ""}) == "cli_empty_value");
  CHECK(failure_code({"--help", "--version"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--model", "m"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--analysis", "a"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--output", "o"}) == "cli_mixed_mode");
  CHECK(failure_code({"--version", "--model", "m"}) == "cli_mixed_mode");
  CHECK(failure_code({"--version", "--analysis", "a"}) ==
        "cli_mixed_mode");
  CHECK(failure_code({"--version", "--output", "o"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--workers", "2"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--output_resources"}) == "cli_mixed_mode");
  CHECK(failure_code({"--help", "--report_unavailable_diagnostics"}) ==
        "cli_mixed_mode");
  CHECK(failure_code({"--version", "--report_unavailable_diagnostics"}) ==
        "cli_mixed_mode");
  CHECK(failure_code({"--version", "--version"}) ==
        "cli_duplicate_option");
  CHECK(failure_code({"--model", "--bogus"}) == "cli_missing_value");
  for (const auto& invalid : {std::string("0"), std::string("01"),
                              std::string("-1"),
                              std::string("workers")}) {
    CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                        "--workers", invalid}) ==
          "cli_invalid_execution_control");
  }
  const auto formerly_capped_workers =
      parse({"--model", "m", "--analysis", "a", "--output", "o",
             "--workers", "65"});
  REQUIRE(formerly_capped_workers);
  CHECK(std::get<mwperf::Analyze>(formerly_capped_workers.value().mode)
            .worker_count == 65U);
  for (const auto& invalid : {std::string("0"), std::string("01"),
                              std::string("1.5"), std::string("seconds")}) {
    CHECK(failure_code({"--model", "m", "--analysis", "a", "--output", "o",
                        "--timeout-seconds", invalid}) ==
          "cli_invalid_execution_control");
  }

  const auto formerly_capped_timeout =
      parse({"--model", "m", "--analysis", "a", "--output", "o",
             "--timeout-seconds", "31536001"});
  REQUIRE(formerly_capped_timeout);
  CHECK(std::get<mwperf::Analyze>(formerly_capped_timeout.value().mode)
            .timeout_seconds == 31536001U);

  const auto dash_output = parse(
      {"--model", "m", "--analysis", "a", "--output", "-"});
  REQUIRE(dash_output.has_value());
  CHECK(std::get<mwperf::Analyze>(dash_output.value().mode)
            .output_path.authored == "-");
}

TEST_CASE("the process boundary maps an escaping exception",
          "[c01][negative]") {
  Argv arguments(
      {"--model", "m", "--analysis", "a", "--output", "o"});
  std::ostringstream standard_output;
  std::ostringstream standard_error;

  const int exit_code = mwperf::detail::run_cli_boundary(
      arguments.argc(), arguments.argv(), standard_output, standard_error,
      &throwing_analysis);

  CHECK(exit_code == 1);
  CHECK(standard_output.str().empty());
  CHECK(standard_error.str() ==
        "mwperf: internal[internal_exception]: \"an unexpected exception "
        "crossed the process boundary\"\n");
  CHECK(standard_error.str().find("private exception") == std::string::npos);
}

TEST_CASE("help version and analysis use their assigned streams and exits",
          "[c01][integration]") {
  {
    Argv arguments({"--help"});
    std::ostringstream standard_output;
    std::ostringstream standard_error;
    CHECK(mwperf::detail::run_cli_boundary(
              arguments.argc(), arguments.argv(), standard_output,
              standard_error,
              &mwperf::detail::c01_pipeline_not_implemented) == 0);
    CHECK(standard_output.str().starts_with("Usage:\n"));
    CHECK(standard_error.str().empty());
  }
  {
    Argv arguments({"--version"});
    std::ostringstream first_output;
    std::ostringstream first_error;
    std::ostringstream second_output;
    std::ostringstream second_error;
    CHECK(mwperf::detail::run_cli_boundary(
              arguments.argc(), arguments.argv(), first_output, first_error,
              &mwperf::detail::c01_pipeline_not_implemented) == 0);
    CHECK(mwperf::detail::run_cli_boundary(
              arguments.argc(), arguments.argv(), second_output, second_error,
              &mwperf::detail::c01_pipeline_not_implemented) == 0);
    CHECK(first_output.str() == second_output.str());
    CHECK_FALSE(first_output.str().empty());
    CHECK(first_error.str().empty());
    CHECK(second_error.str().empty());
  }
}

TEST_CASE("the C01 analysis seam never touches its output path",
          "[c01][integration]") {
  const std::filesystem::path test_root(MWPERF_TEST_TEMP_DIRECTORY);
  std::filesystem::create_directories(test_root);
  const std::filesystem::path absent = test_root / "absent-result.json";
  const std::filesystem::path existing = test_root / "existing-result.json";
  std::filesystem::remove(absent);

  const auto invoke = [](const std::filesystem::path& output) {
    Argv arguments({"--model", "definitely-missing-model.yaml", "--analysis",
                    "definitely-missing-analysis.yaml", "--output",
                    output.string()});
    std::ostringstream standard_output;
    std::ostringstream standard_error;
    const int exit_code = mwperf::detail::run_cli_boundary(
        arguments.argc(), arguments.argv(), standard_output, standard_error,
        &mwperf::detail::c01_pipeline_not_implemented);
    return std::array<std::string, 3>{std::to_string(exit_code),
                                      standard_output.str(),
                                      standard_error.str()};
  };

  const auto absent_result = invoke(absent);
  CHECK(absent_result[0] == "1");
  CHECK(absent_result[1].empty());
  CHECK(absent_result[2].find("pipeline_not_implemented") !=
        std::string::npos);
  CHECK_FALSE(std::filesystem::exists(absent));

  constexpr std::string_view sentinel = "C01 sentinel bytes\n";
  {
    std::ofstream stream(existing, std::ios::binary | std::ios::trunc);
    REQUIRE(stream.good());
    stream << sentinel;
  }
  const auto existing_result = invoke(existing);
  CHECK(existing_result[0] == "1");
  std::ifstream stream(existing, std::ios::binary);
  const std::string preserved((std::istreambuf_iterator<char>(stream)),
                              std::istreambuf_iterator<char>());
  CHECK(preserved == sentinel);

  std::filesystem::remove(existing);
}

TEST_CASE("usage failure renders exactly one final diagnostic",
          "[c01][integration]") {
  Argv arguments({"--model"});
  std::ostringstream standard_output;
  std::ostringstream standard_error;
  const int exit_code = mwperf::detail::run_cli_boundary(
      arguments.argc(), arguments.argv(), standard_output, standard_error,
      &mwperf::detail::c01_pipeline_not_implemented);
  CHECK(exit_code == 2);
  CHECK(standard_output.str().empty());
  CHECK(occurrence_count(standard_error.str(), "mwperf: ") == 1U);
}
