# Provider-1.4 production seam for schema-4 IID arrival laws.
# This deliberately invokes the built public CLI and therefore covers the
# registered provider, C16 broker, canonical request, static sampler, result-v3
# parser, and compression-analysis publication in one small test.

foreach(required IN ITEMS MWPERF_EXECUTABLE MWPERF_MODEL MWPERF_ANALYSIS
                          MWPERF_OUTPUT)
  if(NOT DEFINED ${required} OR "${${required}}" STREQUAL "")
    message(FATAL_ERROR "${required} is required")
  endif()
endforeach()

if(NOT DEFINED MWPERF_EXPECTED_ARRIVAL_FAMILY OR
   "${MWPERF_EXPECTED_ARRIVAL_FAMILY}" STREQUAL "")
  set(MWPERF_EXPECTED_ARRIVAL_FAMILY "iid_independent_poisson")
endif()
foreach(required_file IN ITEMS "${MWPERF_EXECUTABLE}" "${MWPERF_MODEL}"
                               "${MWPERF_ANALYSIS}")
  if(NOT EXISTS "${required_file}")
    message(FATAL_ERROR "C32 production input is missing: ${required_file}")
  endif()
endforeach()

function(json_get out document)
  string(JSON value ERROR_VARIABLE json_error GET "${document}" ${ARGN})
  if(NOT json_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "invalid provider-1.4 result path [${ARGN}]: ${json_error}")
  endif()
  set(${out} "${value}" PARENT_SCOPE)
endfunction()

function(assert_json_type document expected)
  string(JSON actual ERROR_VARIABLE json_error TYPE "${document}" ${ARGN})
  if(NOT json_error STREQUAL "NOTFOUND" OR
     NOT actual STREQUAL "${expected}")
    message(FATAL_ERROR
      "provider-1.4 result path [${ARGN}] must be ${expected}; "
      "observed [${actual}], error [${json_error}]")
  endif()
endfunction()

function(assert_json_equal document expected)
  json_get(actual "${document}" ${ARGN})
  if(NOT "${actual}" STREQUAL "${expected}")
    message(FATAL_ERROR
      "provider-1.4 result path [${ARGN}] expected [${expected}], "
      "observed [${actual}]")
  endif()
endfunction()

function(assert_rational document numerator denominator)
  assert_json_equal("${document}" "rational" ${ARGN} kind)
  assert_json_equal("${document}" "${numerator}" ${ARGN} numerator)
  assert_json_equal("${document}" "${denominator}" ${ARGN} denominator)
endfunction()

function(assert_prediction_quantity document expected_status)
  assert_json_type("${document}" "OBJECT" ${ARGN})
  assert_json_equal("${document}" "${expected_status}" ${ARGN} status)
  if(expected_status STREQUAL "available")
    assert_json_type("${document}" "OBJECT" ${ARGN} value)
    assert_json_type("${document}" "NULL" ${ARGN} reason_code)
  elseif(expected_status STREQUAL "unavailable")
    assert_json_type("${document}" "NULL" ${ARGN} value)
    assert_json_type("${document}" "STRING" ${ARGN} reason_code)
    json_get(reason "${document}" ${ARGN} reason_code)
    if(reason STREQUAL "")
      message(FATAL_ERROR
        "provider-1.4 unavailable prediction path [${ARGN}] has no reason")
    endif()
  else()
    message(FATAL_ERROR
      "unsupported prediction status assertion [${expected_status}]")
  endif()
endfunction()

function(assert_compression_quantity_reported document)
  assert_json_type("${document}" "OBJECT" ${ARGN})
  assert_json_type("${document}" "OBJECT" ${ARGN} status)
  assert_json_type("${document}" "ARRAY"
                   ${ARGN} status unavailable_reasons)
  string(JSON estimate_type ERROR_VARIABLE estimate_error TYPE
         "${document}" ${ARGN} estimate)
  string(JSON reason_count ERROR_VARIABLE reason_error LENGTH
         "${document}" ${ARGN} status unavailable_reasons)
  if(NOT estimate_error STREQUAL "NOTFOUND" OR
     NOT reason_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "invalid compression quantity path [${ARGN}]: "
      "estimate [${estimate_error}], reasons [${reason_error}]")
  endif()
  if(estimate_type STREQUAL "OBJECT")
    if(NOT reason_count EQUAL 0)
      message(FATAL_ERROR
        "available compression quantity [${ARGN}] carries unavailable reasons")
    endif()
  elseif(estimate_type STREQUAL "NULL")
    if(reason_count LESS 1)
      message(FATAL_ERROR
        "unavailable compression quantity [${ARGN}] has no explicit reason")
    endif()
  else()
    message(FATAL_ERROR
      "compression quantity [${ARGN}] has invalid estimate type "
      "[${estimate_type}]")
  endif()
endfunction()

get_filename_component(output_directory "${MWPERF_OUTPUT}" DIRECTORY)
file(MAKE_DIRECTORY "${output_directory}")
file(REMOVE "${MWPERF_OUTPUT}")
execute_process(
  COMMAND "${MWPERF_EXECUTABLE}"
          --model "${MWPERF_MODEL}"
          --analysis "${MWPERF_ANALYSIS}"
          --output "${MWPERF_OUTPUT}"
          --workers 2
          --result-version 3
  RESULT_VARIABLE result
  OUTPUT_VARIABLE stdout
  ERROR_VARIABLE stderr
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR
    "provider-1.4 production execution failed (exit ${result})\n"
    "stdout:\n${stdout}\n"
    "stderr:\n${stderr}")
endif()
if(NOT EXISTS "${MWPERF_OUTPUT}")
  message(FATAL_ERROR
    "provider-1.4 execution published no result-v3")
endif()

file(READ "${MWPERF_OUTPUT}" document)
assert_json_equal("${document}" "3" result_version)
assert_json_equal("${document}" "success" status)
assert_json_type("${document}" "NULL" failure)
assert_json_equal("${document}" "observed" result_kind)
assert_json_type("${document}" "OBJECT" main_result)
assert_json_equal("${document}"
                  "framework_empirical_constant_last_observed_v1"
                  main_result method_id)
if(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL "iid_independent_poisson")
  assert_json_equal("${document}" "2" main_result method_version)
else()
  assert_json_equal("${document}" "1" main_result method_version)
endif()

assert_json_equal("${document}" "full_orbit_framework_sampler"
                  provenance provider provider_id)
assert_json_equal("${document}" "1.4.0"
                  provenance provider provider_version)
assert_json_equal("${document}" "success"
                  diagnostic_supplement terminal main_status)
assert_json_type("${document}" "OBJECT"
                 diagnostic_supplement observation_bundle)
json_get(observation_digest "${document}"
         diagnostic_supplement observation_bundle_digest)
string(LENGTH "${observation_digest}" observation_digest_length)
if(NOT observation_digest_length EQUAL 64 OR
   NOT observation_digest MATCHES "^[0-9a-f]+$")
  message(FATAL_ERROR
    "provider-1.4 observation digest is not lowercase SHA-256: "
    "${observation_digest}")
endif()
assert_json_equal("${document}" "${observation_digest}"
                  main_result observation_digest)
json_get(analysis_digest "${document}"
         diagnostic_supplement analysis analysis_digest)
assert_json_equal("${document}" "${analysis_digest}"
                  main_result analysis_digest)
assert_json_equal("${document}" "q0" main_result target_id)

assert_json_equal("${document}" "${MWPERF_EXPECTED_ARRIVAL_FAMILY}"
                  diagnostic_supplement observation_bundle bindings arrival
                  arrival_family_id)
if(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL "iid_independent_poisson")
  assert_json_equal("${document}" "overshoot_descriptor"
                    diagnostic_supplement observation_bundle bindings arrival
                    target_arrival kind)
  assert_json_equal("${document}" "iid_independent_poisson_overshoot_v1"
                    diagnostic_supplement observation_bundle bindings arrival
                    target_arrival descriptor_id)
elseif(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL
       "independent_marked_renewal")
  assert_json_equal("${document}" "exact_marginal"
                    diagnostic_supplement observation_bundle bindings arrival
                    target_arrival kind)
  string(JSON arrival_atom_count ERROR_VARIABLE arrival_atom_error LENGTH
         "${document}" diagnostic_supplement observation_bundle bindings
         arrival target_arrival atoms)
  if(NOT arrival_atom_error STREQUAL "NOTFOUND" OR
     NOT arrival_atom_count EQUAL 3)
    message(FATAL_ERROR
      "factorized target arrival must have exactly three marginal atoms")
  endif()
  foreach(index RANGE 0 2)
    assert_json_equal("${document}" "${index}"
                      diagnostic_supplement observation_bundle bindings
                      arrival target_arrival atoms ${index} batch_size)
  endforeach()
  assert_rational("${document}" "1369" "1600"
                  diagnostic_supplement observation_bundle bindings arrival
                  target_arrival atoms 0 probability)
  assert_rational("${document}" "111" "800"
                  diagnostic_supplement observation_bundle bindings arrival
                  target_arrival atoms 1 probability)
  assert_rational("${document}" "9" "1600"
                  diagnostic_supplement observation_bundle bindings arrival
                  target_arrival atoms 2 probability)
  assert_rational("${document}" "3" "20"
                  diagnostic_supplement observation_bundle bindings arrival
                  mean)
  assert_rational("${document}" "129" "800"
                  diagnostic_supplement observation_bundle bindings arrival
                  second_moment)
else()
  message(FATAL_ERROR
    "unsupported provider-1.4 arrival test family: "
    "${MWPERF_EXPECTED_ARRIVAL_FAMILY}")
endif()
assert_json_equal("${document}" "ON"
                  diagnostic_supplement observation_bundle capabilities
                  certified_gap_probe available)

assert_json_equal("${document}" "empirical_finite_window_response_v1"
                  diagnostic_supplement analysis projection_mode)
assert_json_type("${document}" "ARRAY"
                 diagnostic_supplement analysis
                 empirical_finite_window_response_v1 observed_levels)
string(JSON observed_level_count ERROR_VARIABLE observed_level_error LENGTH
       "${document}" diagnostic_supplement analysis
       empirical_finite_window_response_v1 observed_levels)
if(NOT observed_level_error STREQUAL "NOTFOUND" OR
   observed_level_count LESS 1)
  message(FATAL_ERROR
    "provider-1.4 raw response retained no observed levels")
endif()
assert_json_equal("${document}" "2"
                  diagnostic_supplement analysis
                  empirical_finite_window_response_v1
                  included_complete_replications)

# The framework result must consume the whole contiguous raw response.  K is
# a reporting view and may not silently truncate the response or the emitted
# stationary PMF back to the legacy 0--2 fixture range.
json_get(complete_through "${document}"
         diagnostic_supplement analysis
         empirical_finite_window_response_v1 complete_through)
if(complete_through STREQUAL "" OR complete_through LESS 1)
  message(FATAL_ERROR
    "provider-1.4 production response has no positive contiguous anchor")
endif()
assert_json_equal("${document}" "${complete_through}"
                  main_result response_treatment observed_complete_through)
assert_json_equal("${document}" "${complete_through}"
                  main_result response_treatment prefix_cutoff)
math(EXPR constant_tail_from "${complete_through} + 1")
assert_json_equal("${document}" "${constant_tail_from}"
                  main_result response_treatment constant_tail_from)
assert_json_equal("${document}" "constant_last_observed"
                  main_result response_treatment completion_policy)
assert_json_equal("${document}"
                  "constant_equal_to_last_observed_response"
                  main_result response_treatment unobserved_levels)
assert_json_equal("${document}" "retained_as_observed_coefficient"
                  main_result response_treatment empirical_zero_or_one)
assert_json_equal("${document}" "mu_0_equals_zero"
                  main_result response_treatment structural_zero)
assert_json_equal("${document}"
                  "exact_dyadic_point_estimate_with_absolute_error_retained"
                  main_result response_treatment coefficient_value_treatment)
math(EXPR complete_point_count "${complete_through} + 1")
string(JSON response_point_count ERROR_VARIABLE response_point_error LENGTH
       "${document}" main_result response_treatment points)
if(NOT response_point_error STREQUAL "NOTFOUND" OR
   NOT response_point_count EQUAL complete_point_count)
  message(FATAL_ERROR
    "framework response retained ${response_point_count} points, expected "
    "the complete 0..${complete_through} range (${complete_point_count})")
endif()
foreach(index RANGE 0 ${complete_through})
  assert_json_equal("${document}" "${index}"
                    main_result response_treatment points ${index} level)
  if(index EQUAL complete_through)
    assert_json_equal("${document}"
                      "finite_prefix_and_constant_tail_anchor"
                      main_result response_treatment points ${index} role)
  else()
    assert_json_equal("${document}" "finite_prefix"
                      main_result response_treatment points ${index} role)
  endif()
endforeach()

if(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL "iid_independent_poisson")
  assert_json_equal("${document}"
                    "empirical_plugin_prediction_conditional_on_exact_dyadic_response_and_certified_poisson_representative"
                    main_result stationary interpretation)
else()
  assert_json_equal("${document}"
                    "empirical_plugin_prediction_conditional_on_exact_dyadic_response_centers"
                    main_result stationary interpretation)
endif()
assert_json_equal("${document}"
                  "not_established_source_absolute_error_bounds_retained"
                  main_result stationary physical_metric_claim)
json_get(calculation_status "${document}" main_result calculation_status)
if(calculation_status STREQUAL "available")
  assert_json_type("${document}" "NULL"
                   main_result calculation_reason_code)
  string(JSON pmf_count ERROR_VARIABLE pmf_error LENGTH
         "${document}" main_result stationary pmf)
  if(NOT pmf_error STREQUAL "NOTFOUND" OR
     NOT pmf_count EQUAL complete_point_count)
    message(FATAL_ERROR
      "available framework PMF retained ${pmf_count} points, expected "
      "the complete 0..${complete_through} range (${complete_point_count})")
  endif()
  foreach(index RANGE 0 ${complete_through})
    assert_json_equal("${document}" "${index}"
                      main_result stationary pmf ${index} level)
    assert_prediction_quantity("${document}" "available"
                               main_result stationary pmf ${index}
                               probability)
  endforeach()
  foreach(quantity IN ITEMS remaining_tail_probability empty_probability
                            first_backlog_moment second_backlog_moment
                            mean_sojourn arrival_mean)
    assert_prediction_quantity("${document}" "available"
                               main_result stationary ${quantity})
  endforeach()
elseif(calculation_status STREQUAL "unavailable")
  assert_json_type("${document}" "STRING"
                   main_result calculation_reason_code)
  json_get(calculation_reason "${document}"
           main_result calculation_reason_code)
  if(calculation_reason STREQUAL "")
    message(FATAL_ERROR
      "unavailable framework prediction did not publish a reason")
  endif()
  foreach(quantity IN ITEMS remaining_tail_probability empty_probability
                            first_backlog_moment second_backlog_moment
                            mean_sojourn)
    assert_prediction_quantity("${document}" "unavailable"
                               main_result stationary ${quantity})
  endforeach()
  assert_prediction_quantity("${document}" "available"
                             main_result stationary arrival_mean)
else()
  message(FATAL_ERROR
    "framework prediction has invalid calculation status: "
    "${calculation_status}")
endif()

if(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL "iid_independent_poisson")
  assert_json_equal("${document}" "available"
                    main_result calculation_status)
  assert_json_type("${document}" "NULL"
                   main_result calculation_reason_code)
  assert_json_type("${document}" "OBJECT"
                   main_result poisson_arrival_reconstruction_v1)
  assert_json_equal("${document}" "infinite_not_truncated"
                    main_result poisson_arrival_reconstruction_v1 law_support)
  assert_json_equal("${document}" "exact_declarative_rational"
                    main_result poisson_arrival_reconstruction_v1
                    configured_rate_treatment)
  assert_json_equal("${document}" "3/4"
                    main_result poisson_arrival_reconstruction_v1
                    exact_first_raw_moment exact)
  assert_json_equal("${document}" "21/16"
                    main_result poisson_arrival_reconstruction_v1
                    exact_second_raw_moment exact)
  assert_json_equal("${document}" "183/64"
                    main_result poisson_arrival_reconstruction_v1
                    exact_third_raw_moment exact)
  assert_json_equal("${document}" "1/4"
                    main_result stationary empty_probability value exact)
  assert_json_equal("${document}" "15/8"
                    main_result stationary first_backlog_moment value exact)
  assert_json_equal("${document}" "231/32"
                    main_result stationary second_backlog_moment value exact)
  assert_json_equal("${document}" "5/2"
                    main_result stationary mean_sojourn value exact)
  foreach(quantity IN ITEMS omitted_probability omitted_first_raw_moment
                            omitted_second_raw_moment
                            omitted_third_raw_moment)
    assert_json_type("${document}" "OBJECT"
                     main_result poisson_arrival_reconstruction_v1
                     ${quantity})
  endforeach()
endif()

foreach(panel IN ITEMS finite_window competition ties)
  assert_json_type("${document}" "OBJECT"
                   diagnostic_supplement analysis ${panel})
endforeach()
foreach(quantity IN ITEMS mean_gap mean_absolute_gap mean_competition_scale
                          normalized_gap_scale)
  assert_compression_quantity_reported(
      "${document}" diagnostic_supplement analysis competition ${quantity})
endforeach()
string(JSON competition_cutoff_count
       ERROR_VARIABLE competition_cutoff_error LENGTH
       "${document}" diagnostic_supplement analysis competition cutoffs)
if(NOT competition_cutoff_error STREQUAL "NOTFOUND" OR
   NOT competition_cutoff_count EQUAL 3)
  message(FATAL_ERROR
    "gap-enabled target did not publish all three competition cutoffs")
endif()
foreach(index RANGE 0 2)
  foreach(quantity IN ITEMS positive_gap_tail_reward
                            negative_gap_tail_reward
                            gap_association_reward
                            competition_association_reward
                            competition_backlog_tail_reward
                            competition_service_tail_reward
                            direct_competition_association_reward
                            association_split_closure)
    assert_compression_quantity_reported(
        "${document}" diagnostic_supplement analysis competition cutoffs
        ${index} ${quantity})
  endforeach()
endforeach()
foreach(quantity IN ITEMS strict_loss_backlog_reward lost_tie_backlog_reward
                          empirical_identity_lhs empirical_identity_rhs
                          empirical_identity_closure isolated_server_baseline
                          strict_loss_mean_contribution
                          lost_tie_mean_contribution
                          stationary_mean_reconstruction)
  assert_compression_quantity_reported(
      "${document}" diagnostic_supplement analysis ties ${quantity})
endforeach()
string(JSON tie_response_count ERROR_VARIABLE tie_response_error LENGTH
       "${document}" diagnostic_supplement analysis ties response_by_level)
if(NOT tie_response_error STREQUAL "NOTFOUND" OR tie_response_count LESS 1)
  message(FATAL_ERROR
    "gap-enabled target did not publish tie response telemetry")
endif()
math(EXPR last_tie_response "${tie_response_count} - 1")
foreach(index RANGE 0 ${last_tie_response})
  foreach(quantity IN ITEMS strict_win_response_component
                            tied_service_response_component
                            reconstructed_response observed_response
                            response_reconstruction_closure)
    assert_compression_quantity_reported(
        "${document}" diagnostic_supplement analysis ties response_by_level
        ${index} ${quantity})
  endforeach()
endforeach()
if(MWPERF_EXPECTED_ARRIVAL_FAMILY STREQUAL "iid_independent_poisson")
  assert_json_type("${document}" "OBJECT"
                   diagnostic_supplement analysis
                   poisson_overshoot_evaluation_v1)
endif()
string(JSON cutoff_count ERROR_VARIABLE cutoff_error LENGTH
       "${document}" diagnostic_supplement analysis cutoffs)
if(NOT cutoff_error STREQUAL "NOTFOUND" OR NOT cutoff_count EQUAL 3)
  message(FATAL_ERROR
    "provider-1.4 result did not retain the three requested projections")
endif()
foreach(index RANGE 0 2)
  assert_json_type("${document}" "OBJECT"
                   diagnostic_supplement analysis cutoffs ${index}
                   four_tail_rewards)
  assert_json_type("${document}" "OBJECT"
                   diagnostic_supplement analysis cutoffs ${index}
                   empirical_decomposition)
endforeach()
