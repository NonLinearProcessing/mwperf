if(NOT DEFINED MWPERF_EXECUTABLE OR NOT EXISTS "${MWPERF_EXECUTABLE}")
  message(FATAL_ERROR "MWPERF_EXECUTABLE is missing")
endif()
if(NOT DEFINED MWPERF_TEST_ROOT)
  message(FATAL_ERROR "MWPERF_TEST_ROOT is missing")
endif()

file(MAKE_DIRECTORY "${MWPERF_TEST_ROOT}")
set(file_sentinel "${MWPERF_TEST_ROOT}/test-owned-sentinel.txt")
file(WRITE "${file_sentinel}" "test-owned sentinel\n")
file(SHA256 "${file_sentinel}" sentinel_hash_before)
file(GLOB_RECURSE files_before LIST_DIRECTORIES false
     "${MWPERF_TEST_ROOT}/*")
list(SORT files_before)

function(run_checked expected_exit)
  execute_process(
    COMMAND "${MWPERF_EXECUTABLE}" ${ARGN}
    WORKING_DIRECTORY "${MWPERF_TEST_ROOT}"
    RESULT_VARIABLE actual_exit
    OUTPUT_VARIABLE actual_stdout
    ERROR_VARIABLE actual_stderr
  )
  if(NOT "${actual_exit}" STREQUAL "${expected_exit}")
    message(FATAL_ERROR
      "unexpected exit ${actual_exit}; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  set(RUN_STDOUT "${actual_stdout}" PARENT_SCOPE)
  set(RUN_STDERR "${actual_stderr}" PARENT_SCOPE)
endfunction()

run_checked(0 --help)
set(first_help "${RUN_STDOUT}")
if(RUN_STDOUT STREQUAL "" OR NOT RUN_STDERR STREQUAL "")
  message(FATAL_ERROR "--help did not write only standard output")
endif()
run_checked(0 --help)
if(NOT RUN_STDOUT STREQUAL first_help OR NOT RUN_STDERR STREQUAL "")
  message(FATAL_ERROR "--help was not byte-stable")
endif()

run_checked(0 --version)
set(first_version "${RUN_STDOUT}")
if(first_version STREQUAL "" OR NOT RUN_STDERR STREQUAL "")
  message(FATAL_ERROR "--version did not write only standard output")
endif()
run_checked(0 --version)
if(NOT RUN_STDOUT STREQUAL first_version OR NOT RUN_STDERR STREQUAL "")
  message(FATAL_ERROR "--version was not byte-stable")
endif()

file(GLOB_RECURSE files_after_modes LIST_DIRECTORIES false
     "${MWPERF_TEST_ROOT}/*")
list(SORT files_after_modes)
file(SHA256 "${file_sentinel}" sentinel_hash_after)
if(NOT files_after_modes STREQUAL files_before OR
   NOT sentinel_hash_after STREQUAL sentinel_hash_before)
  message(FATAL_ERROR "help or version created or modified a file")
endif()

set(absent_output "${MWPERF_TEST_ROOT}/absent-result.json")
file(REMOVE "${absent_output}")
run_checked(1 --model missing-model.yaml --analysis missing-analysis.yaml
              --output "${absent_output}")
if(NOT RUN_STDOUT STREQUAL "")
  message(FATAL_ERROR "analysis seam wrote to standard output")
endif()
if(NOT RUN_STDERR MATCHES "document_open_failed")
  message(FATAL_ERROR "C27 analysis path omitted document_open_failed")
endif()
if(EXISTS "${absent_output}")
  message(FATAL_ERROR "analysis seam created the requested output")
endif()

set(existing_output "${MWPERF_TEST_ROOT}/existing-result.json")
set(sentinel "C01-sentinel-content\n")
file(WRITE "${existing_output}" "${sentinel}")
run_checked(1 --model missing-model.yaml --analysis missing-analysis.yaml
              --output "${existing_output}")
file(READ "${existing_output}" preserved)
if(NOT preserved STREQUAL sentinel)
  message(FATAL_ERROR "analysis seam modified the requested output")
endif()

run_checked(2 --model)
set(first_malformed_stderr "${RUN_STDERR}")
if(NOT RUN_STDOUT STREQUAL "")
  message(FATAL_ERROR "malformed invocation wrote to standard output")
endif()
string(REGEX MATCHALL "mwperf: " diagnostic_prefixes "${RUN_STDERR}")
list(LENGTH diagnostic_prefixes diagnostic_count)
if(NOT diagnostic_count EQUAL 1)
  message(FATAL_ERROR "malformed invocation did not render one diagnostic")
endif()
set(expected_malformed_stderr
    "mwperf: cli_usage[cli_missing_value]: \"an option requires a nonempty value\"\n  note: \"--model\"\n")
if(NOT first_malformed_stderr STREQUAL expected_malformed_stderr)
  message(FATAL_ERROR "malformed diagnostic bytes changed")
endif()
run_checked(2 --model)
if(NOT RUN_STDOUT STREQUAL "" OR
   NOT RUN_STDERR STREQUAL first_malformed_stderr)
  message(FATAL_ERROR "malformed diagnostic was not byte-stable")
endif()
