if(NOT DEFINED MWPERF_EXECUTABLE OR
   NOT DEFINED MWPERF_MODEL OR
   NOT DEFINED MWPERF_ANALYSIS OR
   NOT DEFINED MWPERF_OUTPUT)
  message(FATAL_ERROR "C30 result-v1 refusal audit is missing an input")
endif()

file(REMOVE "${MWPERF_OUTPUT}")
execute_process(
  COMMAND "${MWPERF_EXECUTABLE}"
          --model "${MWPERF_MODEL}"
          --analysis "${MWPERF_ANALYSIS}"
          --output "${MWPERF_OUTPUT}"
          --result-version 1
  RESULT_VARIABLE result
  OUTPUT_VARIABLE stdout
  ERROR_VARIABLE stderr
)
if(result EQUAL 0)
  message(FATAL_ERROR
    "provider-result-v2 route unexpectedly accepted --result-version 1")
endif()

set(combined "${stdout}\n${stderr}")
if(NOT combined MATCHES "c30\\.result_v1_forbidden_for_diagnostics_provider")
  message(FATAL_ERROR
    "result-v1 refusal did not report the frozen diagnostic: ${combined}")
endif()
if(EXISTS "${MWPERF_OUTPUT}")
  message(FATAL_ERROR
    "result-v1 refusal created an output artifact before rejecting execution")
endif()
