if(NOT DEFINED MWPERF_COMPARISON_OUTPUT)
  message(FATAL_ERROR "MWPERF_COMPARISON_OUTPUT is missing")
endif()
if(NOT EXISTS "${MWPERF_COMPARISON_OUTPUT}")
  message(FATAL_ERROR "standalone comparison output was not published")
endif()

file(READ "${MWPERF_COMPARISON_OUTPUT}" comparison_json)
string(JSON comparison_version ERROR_VARIABLE version_error
  GET "${comparison_json}" comparison_version)
if(version_error OR NOT comparison_version EQUAL 1)
  message(FATAL_ERROR "comparison_version is not the required value 1")
endif()
string(JSON comparison_kind ERROR_VARIABLE kind_error
  GET "${comparison_json}" kind)
if(kind_error OR NOT comparison_kind STREQUAL "compression_error_separation")
  message(FATAL_ERROR "comparison output has the wrong closed kind")
endif()
string(JSON cutoff_count ERROR_VARIABLE cutoffs_error
  LENGTH "${comparison_json}" cutoffs)
if(cutoffs_error OR NOT cutoff_count EQUAL 1)
  message(FATAL_ERROR "comparison output must contain the requested cutoff")
endif()
string(JSON cutoff ERROR_VARIABLE cutoff_error
  GET "${comparison_json}" cutoffs 0 cutoff)
if(cutoff_error OR NOT cutoff STREQUAL "1")
  message(FATAL_ERROR "comparison output did not retain cutoff 1")
endif()
