# Real C27.1 production-path acceptance.  This script is registered only for
# builds that bind a sealed Full Orbit executable into the production
# registry.  It intentionally drives the public CLI instead of a C16 test-seam
# registry.

foreach(required IN ITEMS MWPERF_EXECUTABLE MWPERF_SOURCE_ROOT
                          MWPERF_FULL_ORBIT_SAMPLER_EXECUTABLE
                          MWPERF_TEST_ROOT MWPERF_C27_1_SCENARIO)
  if(NOT DEFINED ${required} OR "${${required}}" STREQUAL "")
    message(FATAL_ERROR "${required} is required")
  endif()
endforeach()
if(NOT EXISTS "${MWPERF_EXECUTABLE}")
  message(FATAL_ERROR "the production mwperf executable is missing")
endif()
if(NOT EXISTS "${MWPERF_FULL_ORBIT_SAMPLER_EXECUTABLE}")
  message(FATAL_ERROR "the configured Full Orbit executable is missing")
endif()

set(fixture_root "${MWPERF_SOURCE_ROOT}/tests/fixtures/c27_1")
set(built_k_wide_analysis
    "${fixture_root}/full_orbit_analysis_built_k_wide.json")
foreach(required_fixture IN ITEMS "${built_k_wide_analysis}")
  if(NOT EXISTS "${required_fixture}")
    message(FATAL_ERROR "C27.1 fixture is missing: ${required_fixture}")
  endif()
endforeach()

file(MAKE_DIRECTORY "${MWPERF_TEST_ROOT}")
set(generated_fixture_root "${MWPERF_TEST_ROOT}/generated-fixtures")
file(MAKE_DIRECTORY "${generated_fixture_root}")

# Every production case below starts from the one sealed CP07.1 analysis and
# changes only the checked transport copy of K, its authoritative resolved
# cutoff, or the finite run dimensions.  This prevents the qualification
# matrix from accidentally selecting the retired ThreeBin route.
function(write_k_wide_analysis output_path provider_cutoff resolved_cutoff
         warmup_slots horizon_slots replications population_size)
  file(READ "${built_k_wide_analysis}" document)
  string(JSON document SET "${document}"
         surrogate parameters response_cutoff "${provider_cutoff}")
  string(JSON document SET "${document}"
         resolution tail parameters cutoff "${resolved_cutoff}")
  string(JSON document SET "${document}"
         surrogate parameters warmup_slots "${warmup_slots}")
  string(JSON document SET "${document}"
         surrogate parameters horizon_slots "${horizon_slots}")
  string(JSON document SET "${document}"
         surrogate parameters replications "${replications}")
  string(JSON document SET "${document}"
         surrogate parameters population_size "${population_size}")

  # string(JSON) parses every JSON number through binary64 while rewriting
  # the document.  Restore the authored decimal lexeme so C14 receives the
  # exact 1/10^12 requirement rather than a platform-formatted value that can
  # be slightly smaller (and therefore spuriously stricter).
  string(REGEX REPLACE
         "\"linear_residual_abs\"[ \t\r\n]*:[ \t\r\n]*[-+0-9.eE]+"
         "\"linear_residual_abs\" : 1e-12"
         document "${document}")
  string(REGEX MATCHALL
         "\"linear_residual_abs\"[ \t\r\n]*:[ \t\r\n]*1e-12[ \t\r\n]*[,}]"
         exact_tolerance_lexemes "${document}")
  list(LENGTH exact_tolerance_lexemes exact_tolerance_lexeme_count)
  if(NOT exact_tolerance_lexeme_count EQUAL 1)
    message(FATAL_ERROR
      "generated K-wide analysis did not preserve linear_residual_abs as exact 1e-12")
  endif()
  file(WRITE "${output_path}" "${document}\n")
endfunction()

function(write_k_wide_unavailable_models exact_level_path tail_path)
  # Exact-level cause: at the only measured boundary q0=3.  Thus the K=2
  # tail has positive exposure while both nontrivial exact levels do not.
  file(WRITE "${exact_level_path}" [=[
{
  "schema_version": "3.0.0",
  "run": {"seed": 17, "slots": 2, "warmup_slots": 0, "termination": "fixed_slots"},
  "switch": {"kind": "generalized", "queue_capacity": null, "queues": [{"id": "q0"}]},
  "scheduler": {
    "name": "conflict_graph_max_weight",
    "params": {"constraint": {"conflicts": []}, "max_search_states": null, "priority": ["q0"]}
  },
  "arrival": {
    "family": "independent_marked_renewal",
    "metadata": {},
    "sources": [
      {"id": "s0", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q0", "probability": 1}]},
      {"id": "s1", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q0", "probability": 1}]},
      {"id": "s2", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q0", "probability": 1}]}
    ]
  },
  "telemetry": {"format": "jsonl", "queue_snapshot": "disabled", "include_packet_events": false, "include_scheduler_state": false, "write_slot_trace": false},
  "metadata": {"fixture": "c29-k-wide-exact-level-unavailable"}
}
]=])

  # Tail-only cause: q1 is always one packet ahead of q0 and conflicts with
  # it, so q0 is not served.  The two measured q0 backlogs are exactly 1 and
  # 2; every exact K=2 level is observed and N>=3 is not.
  file(WRITE "${tail_path}" [=[
{
  "schema_version": "3.0.0",
  "run": {"seed": 17, "slots": 3, "warmup_slots": 0, "termination": "fixed_slots"},
  "switch": {"kind": "generalized", "queue_capacity": null, "queues": [{"id": "q0"}, {"id": "q1"}]},
  "scheduler": {
    "name": "conflict_graph_max_weight",
    "params": {"constraint": {"conflicts": [["q0", "q1"]]}, "max_search_states": null, "priority": ["q1", "q0"]}
  },
  "arrival": {
    "family": "independent_marked_renewal",
    "metadata": {},
    "sources": [
      {"id": "s0", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q0", "probability": 1}]},
      {"id": "s1", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q1", "probability": 1}]},
      {"id": "s2", "interarrival": {"kind": "geometric_grid", "d_min": 1, "delta": 1, "p": 1}, "destination_pmf": [{"queue_id": "q1", "probability": 1}]}
    ]
  },
  "telemetry": {"format": "jsonl", "queue_snapshot": "disabled", "include_packet_events": false, "include_scheduler_state": false, "write_slot_trace": false},
  "metadata": {"fixture": "c29-k-wide-tail-unavailable"}
}
]=])
endfunction()

function(json_get out document)
  string(JSON value ERROR_VARIABLE json_error GET "${document}" ${ARGN})
  if(NOT json_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "invalid result JSON path [${ARGN}]: ${json_error}")
  endif()
  set(${out} "${value}" PARENT_SCOPE)
endfunction()

function(assert_equal actual expected context)
  if(NOT "${actual}" STREQUAL "${expected}")
    message(FATAL_ERROR
      "${context}: expected [${expected}], observed [${actual}]")
  endif()
endfunction()

function(published_result_summary output out)
  if(NOT EXISTS "${output}")
    set(${out} "result=[not published: ${output}]" PARENT_SCOPE)
    return()
  endif()
  file(READ "${output}" document)
  set(summary "result=[${output}]")
  string(JSON error_code ERROR_VARIABLE code_error
         GET "${document}" error code)
  if(code_error STREQUAL "NOTFOUND")
    string(APPEND summary " error_code=[${error_code}]")
  endif()
  set(${out} "${summary}" PARENT_SCOPE)
endfunction()

function(assert_rational document expected_numerator expected_denominator)
  json_get(exact "${document}" ${ARGN} exact)
  json_get(decimal "${document}" ${ARGN} decimal)
  assert_equal("${exact}" "${expected_numerator}/${expected_denominator}"
               "exact rational")
  string(JSON decimal_type ERROR_VARIABLE decimal_error TYPE
         "${document}" ${ARGN} decimal)
  if(NOT decimal_error STREQUAL "NOTFOUND" OR
     NOT decimal_type STREQUAL "NUMBER")
    message(FATAL_ERROR
      "compact rational decimal is not a JSON number at [${ARGN}]")
  endif()
endfunction()

function(assert_rational_shape document)
  string(JSON value_type ERROR_VARIABLE value_error TYPE
         "${document}" ${ARGN})
  if(NOT value_error STREQUAL "NOTFOUND" OR
     NOT value_type STREQUAL "OBJECT")
    message(FATAL_ERROR
      "compact rational is not a JSON object at [${ARGN}]")
  endif()
  string(JSON field_count ERROR_VARIABLE field_error LENGTH
         "${document}" ${ARGN})
  if(NOT field_error STREQUAL "NOTFOUND" OR NOT field_count EQUAL 2)
    message(FATAL_ERROR
      "compact rational does not contain exactly exact and decimal at [${ARGN}]")
  endif()
  string(JSON exact_type ERROR_VARIABLE exact_error TYPE
         "${document}" ${ARGN} exact)
  if(NOT exact_error STREQUAL "NOTFOUND" OR
     NOT exact_type STREQUAL "STRING")
    message(FATAL_ERROR
      "compact rational exact value is not a string at [${ARGN}]")
  endif()
  json_get(exact "${document}" ${ARGN} exact)
  if(NOT "${exact}" MATCHES "^-?[0-9]+/[1-9][0-9]*$")
    message(FATAL_ERROR
      "compact rational exact value is not canonical at [${ARGN}]: ${exact}")
  endif()
  string(JSON decimal_type ERROR_VARIABLE decimal_error TYPE
         "${document}" ${ARGN} decimal)
  if(NOT decimal_error STREQUAL "NOTFOUND" OR
     NOT decimal_type STREQUAL "NUMBER")
    message(FATAL_ERROR
      "compact rational decimal is not a JSON number at [${ARGN}]")
  endif()
endfunction()

function(assert_wall_clock document)
  foreach(component IN ITEMS end_to_end sampler framework)
    string(JSON component_type ERROR_VARIABLE type_error TYPE
           "${document}" wall_clock_seconds ${component})
    if(NOT type_error STREQUAL "NOTFOUND" OR
       NOT component_type STREQUAL "NUMBER")
      message(FATAL_ERROR
        "wall_clock_seconds.${component} must be a JSON number")
    endif()
    json_get(component_value "${document}" wall_clock_seconds ${component})
    if(component_value LESS 0)
      message(FATAL_ERROR
        "wall_clock_seconds.${component} must be nonnegative")
    endif()
  endforeach()
endfunction()

function(assert_forbidden_reporting_absent document)
  foreach(forbidden IN ITEMS
      diagnostics certificates assumptions scientific_scope evidence_refs
      error_refs law_identity surrogate execution budget_usage status
      unavailable failure build model analysis input_fingerprint
      result_schema_version provenance convention)
    string(FIND "${document}" "\"${forbidden}\":" forbidden_position)
    if(NOT forbidden_position EQUAL -1)
      message(FATAL_ERROR
        "non-scientific output field escaped into compact result: ${forbidden}")
    endif()
  endforeach()
endfunction()

function(assert_key_order document)
  set(previous_position -1)
  foreach(key IN LISTS ARGN)
    string(FIND "${document}" "\"${key}\":" key_position)
    if(key_position EQUAL -1)
      message(FATAL_ERROR "compact result is missing key: ${key}")
    endif()
    if(key_position LESS_EQUAL previous_position)
      message(FATAL_ERROR "compact result key order is invalid at: ${key}")
    endif()
    set(previous_position "${key_position}")
  endforeach()
endfunction()

function(assert_success_shape document expected_config expect_resources)
  string(JSON top_level_count ERROR_VARIABLE length_error LENGTH "${document}")
  if(NOT length_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR "cannot inspect compact result: ${length_error}")
  endif()
  if(expect_resources)
    assert_equal("${top_level_count}" "5" "resource result field count")
    assert_key_order("${document}" config response_curve metrics
                     wall_clock_seconds resources)
    string(JSON resources_type ERROR_VARIABLE resources_error TYPE
           "${document}" resources)
    if(NOT resources_error STREQUAL "NOTFOUND" OR
       NOT resources_type STREQUAL "OBJECT")
      message(FATAL_ERROR "--output_resources did not publish resources")
    endif()
  else()
    assert_equal("${top_level_count}" "4" "default result field count")
    assert_key_order("${document}" config response_curve metrics
                     wall_clock_seconds)
    string(JSON ignored ERROR_VARIABLE resources_error GET
           "${document}" resources)
    if(resources_error STREQUAL "NOTFOUND")
      message(FATAL_ERROR "resources appeared without --output_resources")
    endif()
  endif()
  json_get(config "${document}" config)
  assert_equal("${config}" "${expected_config}" "config name")
  assert_wall_clock("${document}")
  foreach(component IN ITEMS end_to_end sampler framework)
    json_get(component_value "${document}" wall_clock_seconds ${component})
    if(component_value LESS_EQUAL 0)
      message(FATAL_ERROR
        "successful production run reported no ${component} wall-clock time")
    endif()
  endforeach()
  assert_forbidden_reporting_absent("${document}")
endfunction()

function(assert_error_shape document expected_config)
  string(JSON top_level_count ERROR_VARIABLE length_error LENGTH "${document}")
  if(NOT length_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR "cannot inspect compact error result: ${length_error}")
  endif()
  assert_equal("${top_level_count}" "3" "error result field count")
  assert_key_order("${document}" config error wall_clock_seconds)
  json_get(config "${document}" config)
  assert_equal("${config}" "${expected_config}" "error config name")
  json_get(error_code "${document}" error code)
  json_get(error_message "${document}" error message)
  if(error_code STREQUAL "" OR error_message STREQUAL "")
    message(FATAL_ERROR "compact error code and message must be nonempty")
  endif()
  assert_wall_clock("${document}")
  assert_forbidden_reporting_absent("${document}")
endfunction()

function(assert_k_wide_unavailable_publication document expected_cutoff
         expect_diagnostics)
  string(JSON cutoff_type ERROR_VARIABLE cutoff_type_error TYPE
         "${document}" error response_cutoff)
  if(NOT cutoff_type_error STREQUAL "NOTFOUND" OR
     NOT cutoff_type STREQUAL "STRING")
    message(FATAL_ERROR
      "K-wide unavailable response_cutoff must be an exact decimal string")
  endif()
  json_get(response_cutoff "${document}" error response_cutoff)
  assert_equal("${response_cutoff}" "${expected_cutoff}"
               "K-wide unavailable response cutoff")
  string(JSON diagnostic_type ERROR_VARIABLE diagnostic_error TYPE
         "${document}" error unavailable_diagnostics)
  if(expect_diagnostics)
    if(NOT diagnostic_error STREQUAL "NOTFOUND" OR
       NOT diagnostic_type STREQUAL "OBJECT")
      message(FATAL_ERROR
        "--report_unavailable_diagnostics did not publish its bounded object")
    endif()
  elseif(diagnostic_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "unavailable diagnostics appeared without the publication flag")
  endif()
endfunction()

function(assert_k_wide_metrics document)
  string(JSON response_type ERROR_VARIABLE response_error TYPE
         "${document}" response_curve)
  if(NOT response_error STREQUAL "NOTFOUND" OR
     NOT response_type STREQUAL "NULL")
    message(FATAL_ERROR
      "the K-wide public response_curve must be JSON null")
  endif()

  string(JSON metric_count ERROR_VARIABLE metric_error LENGTH
         "${document}" metrics)
  if(NOT metric_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "cannot inspect K-wide result metrics: ${metric_error}")
  endif()
  assert_equal("${metric_count}" "6" "K-wide metric count")

  set(expected_ids
      fofs.iid.pi0.v1
      fofs.iid.pmf.v1
      fofs.iid.tail3.v1
      fofs.iid.mean.v1
      fofs.iid.sojourn.v1
      fofs.iid.bcs.v1)
  set(expected_kinds
      stationary_empty_probability
      stationary_backlog_pmf
      stationary_backlog_tail
      stationary_backlog_moment
      mean_sojourn
      backlog_conditioned_service)
  foreach(index RANGE 0 5)
    string(JSON metric_field_count ERROR_VARIABLE field_error LENGTH
           "${document}" metrics ${index})
    if(NOT field_error STREQUAL "NOTFOUND")
      message(FATAL_ERROR
        "cannot inspect K-wide compact metric: ${field_error}")
    endif()
    assert_equal("${metric_field_count}" "5"
                 "K-wide compact metric field count")
    list(GET expected_ids ${index} expected_id)
    list(GET expected_kinds ${index} expected_kind)
    json_get(metric_id "${document}" metrics ${index} id)
    json_get(metric_kind "${document}" metrics ${index} kind)
    json_get(metric_target "${document}" metrics ${index} target)
    assert_equal("${metric_id}" "${expected_id}" "K-wide metric order")
    assert_equal("${metric_kind}" "${expected_kind}" "K-wide metric kind")
    assert_equal("${metric_target}" "q0" "K-wide metric target")
  endforeach()

  assert_rational_shape("${document}" metrics 0 value)
  assert_rational_shape("${document}" metrics 2 value)
  assert_rational_shape("${document}" metrics 3 value)
  assert_rational_shape("${document}" metrics 4 value)

  json_get(pmf_coordinate "${document}" metrics 1 value coordinates 0)
  assert_equal("${pmf_coordinate}" "predecision_backlog_partition"
               "K-wide stationary PMF coordinate")
  string(JSON probability_count ERROR_VARIABLE probability_error LENGTH
         "${document}" metrics 1 value probabilities)
  if(NOT probability_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "cannot inspect K-wide stationary probabilities: ${probability_error}")
  endif()
  assert_equal("${probability_count}" "4"
               "K-wide stationary probability count")
  set(expected_outcomes 0 1 2 "N>=3")
  foreach(index RANGE 0 3)
    list(GET expected_outcomes ${index} expected_outcome)
    string(JSON outcome_type ERROR_VARIABLE outcome_error TYPE
           "${document}" metrics 1 value probabilities ${index} outcome)
    if(NOT outcome_error STREQUAL "NOTFOUND")
      message(FATAL_ERROR
        "cannot inspect K-wide stationary outcome: ${outcome_error}")
    endif()
    if(index LESS 3)
      assert_equal("${outcome_type}" "OBJECT"
                   "K-wide numeric stationary outcome type")
      json_get(outcome "${document}" metrics 1 value probabilities ${index}
               outcome integer)
    else()
      assert_equal("${outcome_type}" "STRING"
                   "K-wide aggregate stationary outcome type")
      json_get(outcome "${document}" metrics 1 value probabilities ${index}
               outcome)
    endif()
    assert_equal("${outcome}" "${expected_outcome}"
                 "K-wide stationary outcome")
    assert_rational_shape("${document}" metrics 1 value probabilities
                          ${index} probability)
  endforeach()

  string(JSON service_count ERROR_VARIABLE service_error LENGTH
         "${document}" metrics 5 value)
  if(NOT service_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "cannot inspect K-wide conditioned-service vector: ${service_error}")
  endif()
  assert_equal("${service_count}" "3"
               "K-wide conditioned-service coordinate count")
  foreach(index RANGE 0 2)
    assert_rational_shape("${document}" metrics 5 value ${index})
  endforeach()
endfunction()

function(run_case case_name model analysis expected_exit expected_status)
  set(worker_count 1)
  set(timeout_seconds 3600)
  set(output_resources FALSE)
  set(report_unavailable_diagnostics FALSE)
  if(ARGC GREATER 5)
    set(worker_count "${ARGV5}")
  endif()
  if(ARGC GREATER 6)
    set(timeout_seconds "${ARGV6}")
  endif()
  if(ARGC GREATER 7)
    set(output_resources "${ARGV7}")
  endif()
  if(ARGC GREATER 8)
    set(report_unavailable_diagnostics "${ARGV8}")
  endif()
  set(run_root "${MWPERF_TEST_ROOT}/${case_name}")
  set(output "${run_root}/result.json")
  file(MAKE_DIRECTORY "${run_root}")
  file(REMOVE "${output}")
  set(command
      "${MWPERF_EXECUTABLE}"
      --model "${model}"
      --analysis "${analysis}"
      --output "${output}"
      --workers "${worker_count}"
      --timeout-seconds "${timeout_seconds}")
  if(output_resources)
    list(APPEND command --output_resources)
  endif()
  if(report_unavailable_diagnostics)
    list(APPEND command --report_unavailable_diagnostics)
  endif()
  execute_process(
    COMMAND ${command}
    WORKING_DIRECTORY "${run_root}"
    RESULT_VARIABLE actual_exit
    OUTPUT_VARIABLE actual_stdout
    ERROR_VARIABLE actual_stderr
  )
  if(NOT "${actual_exit}" STREQUAL "${expected_exit}")
    published_result_summary("${output}" result_summary)
    message(FATAL_ERROR
      "${case_name}: unexpected exit ${actual_exit}; ${result_summary}; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  if(NOT "${actual_stdout}" STREQUAL "" OR
     NOT "${actual_stderr}" STREQUAL "")
    message(FATAL_ERROR
      "${case_name}: a published terminal result must leave stdout/stderr empty; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  if(NOT EXISTS "${output}")
    message(FATAL_ERROR "${case_name}: the CLI did not publish result-v1")
  endif()
  file(READ "${output}" document)
  cmake_path(GET model FILENAME config_name)
  if(expected_status STREQUAL "success")
    assert_success_shape("${document}" "${config_name}" "${output_resources}")
  else()
    assert_error_shape("${document}" "${config_name}")
    string(JSON cutoff ERROR_VARIABLE cutoff_error GET
           "${document}" error response_cutoff)
    if(cutoff_error STREQUAL "NOTFOUND")
      assert_k_wide_unavailable_publication(
        "${document}" "${cutoff}" "${report_unavailable_diagnostics}")
    endif()
  endif()
  set(C27_1_RESULT_PATH "${output}" PARENT_SCOPE)
  set(C27_1_RESULT_DOCUMENT "${document}" PARENT_SCOPE)
endfunction()

# Planning/input rejections occur before valid-plan execution begins, so the
# CLI owns the diagnostic and must not publish a result-v1 artifact.  Keep
# this distinct from run_case(), whose nonsuccess branches are terminal
# results published after execution has begun.
function(run_input_rejection_case case_name model analysis expected_code
         expected_message)
  set(run_root "${MWPERF_TEST_ROOT}/${case_name}")
  set(output "${run_root}/result.json")
  file(MAKE_DIRECTORY "${run_root}")
  file(REMOVE "${output}")
  execute_process(
    COMMAND "${MWPERF_EXECUTABLE}"
            --model "${model}"
            --analysis "${analysis}"
            --output "${output}"
            --workers 2
            --timeout-seconds 3600
    WORKING_DIRECTORY "${run_root}"
    RESULT_VARIABLE actual_exit
    OUTPUT_VARIABLE actual_stdout
    ERROR_VARIABLE actual_stderr
  )
  if(NOT "${actual_exit}" STREQUAL "1")
    published_result_summary("${output}" result_summary)
    message(FATAL_ERROR
      "${case_name}: unexpected pre-plan exit ${actual_exit}; ${result_summary}; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  if(NOT "${actual_stdout}" STREQUAL "")
    message(FATAL_ERROR
      "${case_name}: a pre-plan rejection wrote stdout=[${actual_stdout}]")
  endif()
  set(expected_stderr
      "mwperf: input_validation[${expected_code}]: \"${expected_message}\"\n")
  if(NOT "${actual_stderr}" STREQUAL "${expected_stderr}")
    message(FATAL_ERROR
      "${case_name}: unexpected pre-plan diagnostic; expected=[${expected_stderr}] observed=[${actual_stderr}]")
  endif()
  if(EXISTS "${output}")
    message(FATAL_ERROR
      "${case_name}: a pre-plan rejection published result-v1 at ${output}")
  endif()
endfunction()

function(run_target_case case_name model target expected_exit expected_status)
  set(worker_count 1)
  set(timeout_seconds 3600)
  if(ARGC GREATER 5)
    set(worker_count "${ARGV5}")
  endif()
  if(ARGC GREATER 6)
    set(timeout_seconds "${ARGV6}")
  endif()
  set(run_root "${MWPERF_TEST_ROOT}/${case_name}")
  set(output "${run_root}/result.json")
  file(MAKE_DIRECTORY "${run_root}")
  file(REMOVE "${output}")
  execute_process(
    COMMAND "${MWPERF_EXECUTABLE}"
            --model "${model}"
            --target "${target}"
            --output "${output}"
            --workers "${worker_count}"
            --timeout-seconds "${timeout_seconds}"
    WORKING_DIRECTORY "${run_root}"
    RESULT_VARIABLE actual_exit
    OUTPUT_VARIABLE actual_stdout
    ERROR_VARIABLE actual_stderr
  )
  if(NOT "${actual_exit}" STREQUAL "${expected_exit}")
    published_result_summary("${output}" result_summary)
    message(FATAL_ERROR
      "${case_name}: unexpected exit ${actual_exit}; ${result_summary}; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  if(NOT "${actual_stdout}" STREQUAL "" OR
     NOT "${actual_stderr}" STREQUAL "")
    message(FATAL_ERROR
      "${case_name}: a published terminal result must leave stdout/stderr empty; stdout=[${actual_stdout}] stderr=[${actual_stderr}]")
  endif()
  if(NOT EXISTS "${output}")
    message(FATAL_ERROR "${case_name}: the CLI did not publish result-v1")
  endif()
  file(READ "${output}" document)
  cmake_path(GET model FILENAME config_name)
  if(expected_status STREQUAL "success")
    assert_success_shape("${document}" "${config_name}" FALSE)
  else()
    assert_error_shape("${document}" "${config_name}")
  endif()
  set(C27_1_RESULT_PATH "${output}" PARENT_SCOPE)
  set(C27_1_RESULT_DOCUMENT "${document}" PARENT_SCOPE)
endfunction()

if(MWPERF_C27_1_SCENARIO STREQUAL "target_cli")
  run_target_case(
    default-target-conflict
    "${fixture_root}/full_orbit_model_conflict.json"
    q0 0 success 2)
  assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
elseif(MWPERF_C27_1_SCENARIO STREQUAL "built")
  set(k2_analysis "${generated_fixture_root}/built-k2-analysis.json")
  write_k_wide_analysis("${k2_analysis}" 2 2 20 100 8 64)
  run_case(
    built-conflict
    "${fixture_root}/full_orbit_model_conflict.json"
    "${k2_analysis}" 0 success 3 7200 TRUE TRUE)
  assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
  json_get(resource_workers "${C27_1_RESULT_DOCUMENT}" resources workers)
  assert_equal("${resource_workers}" "3" "reported worker count")
  foreach(counter IN ITEMS optimizer_calls configured_generator_draws
                           optimizer_search_states)
    string(JSON counter_type ERROR_VARIABLE counter_error TYPE
           "${C27_1_RESULT_DOCUMENT}" resources ${counter})
    if(NOT counter_error STREQUAL "NOTFOUND" OR
       NOT counter_type STREQUAL "STRING")
      message(FATAL_ERROR
        "resources.${counter} must be an exact decimal string")
    endif()
  endforeach()
elseif(MWPERF_C27_1_SCENARIO STREQUAL "built_k_wide")
  foreach(response_cutoff RANGE 2 5)
    set(analysis
        "${generated_fixture_root}/built-k${response_cutoff}-analysis.json")
    write_k_wide_analysis(
      "${analysis}" ${response_cutoff} ${response_cutoff} 20 100 8 64)
    run_case(
      "built-k${response_cutoff}-conflict"
      "${fixture_root}/full_orbit_model_conflict.json"
      "${analysis}" 0 success 1 3600)
    assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
  endforeach()
elseif(MWPERF_C27_1_SCENARIO STREQUAL "geometry")
  set(geometry_analysis
      "${generated_fixture_root}/geometry-k4-analysis.json")
  write_k_wide_analysis("${geometry_analysis}" 4 4 20 100 8 64)
  foreach(geometry IN ITEMS conflict crossbar interval node_exclusive packing)
    set(model "${fixture_root}/full_orbit_model_${geometry}.json")
    if(NOT EXISTS "${model}")
      message(FATAL_ERROR "geometry fixture is missing: ${model}")
    endif()
    run_case("built-${geometry}" "${model}" "${geometry_analysis}" 0 success 4)
    assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
  endforeach()
elseif(MWPERF_C27_1_SCENARIO STREQUAL "branches")
  set(exact_level_model
      "${generated_fixture_root}/unavailable-exact-level-model.json")
  set(tail_model "${generated_fixture_root}/unavailable-tail-model.json")
  write_k_wide_unavailable_models("${exact_level_model}" "${tail_model}")

  set(exact_level_analysis
      "${generated_fixture_root}/unavailable-exact-level-analysis.json")
  write_k_wide_analysis("${exact_level_analysis}" 2 2 1 2 1 1)
  run_case(unavailable-exact-level "${exact_level_model}"
           "${exact_level_analysis}" 3 unavailable 2)
  json_get(error_code "${C27_1_RESULT_DOCUMENT}" error code)
  assert_equal("${error_code}" "fofs.zero_exposure"
               "unobserved nontrivial exact level status")
  json_get(exact_level_cutoff "${C27_1_RESULT_DOCUMENT}"
           error response_cutoff)
  assert_equal("${exact_level_cutoff}" "2"
               "unobserved exact-level cutoff")

  set(tail_analysis
      "${generated_fixture_root}/unavailable-tail-analysis.json")
  write_k_wide_analysis("${tail_analysis}" 2 2 1 3 1 1)
  run_case(unavailable-tail "${tail_model}" "${tail_analysis}"
           3 unavailable 2)
  json_get(error_code "${C27_1_RESULT_DOCUMENT}" error code)
  assert_equal("${error_code}" "fofs.zero_exposure"
               "unobserved tail status")

  run_case(unavailable-tail-diagnostics "${tail_model}" "${tail_analysis}"
           3 unavailable 2 3600 FALSE TRUE)
  json_get(provider_reason_code "${C27_1_RESULT_DOCUMENT}"
           error unavailable_diagnostics reasons 0 code)
  assert_equal("${provider_reason_code}" "fofs.zero_exposure"
               "retained provider unavailable reason")
  json_get(provider_reason_message "${C27_1_RESULT_DOCUMENT}"
           error unavailable_diagnostics reasons 0 message)
  string(FIND "${provider_reason_message}" "tail" tail_reason_position)
  if(tail_reason_position EQUAL -1)
    message(FATAL_ERROR
      "provider unavailable diagnostics did not retain the missing-tail message")
  endif()
  string(JSON absent_c19 ERROR_VARIABLE absent_c19_error GET
         "${C27_1_RESULT_DOCUMENT}" error unavailable_diagnostics c19)
  if(absent_c19_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "provider Unavailable fabricated a C19 diagnostic without a Built payload")
  endif()

  set(c19_analysis
      "${generated_fixture_root}/unavailable-c19-k5-analysis.json")
  write_k_wide_analysis("${c19_analysis}" 5 5 1 7 1 1)
  run_case(unavailable-c19-compact "${tail_model}" "${c19_analysis}"
           3 unavailable 2 3600 FALSE FALSE)
  json_get(c19_error_code "${C27_1_RESULT_DOCUMENT}" error code)
  assert_equal("${c19_error_code}" "c27.k_bin_metric_not_established"
               "native K-wide C19 unavailable code")
  json_get(c19_cutoff "${C27_1_RESULT_DOCUMENT}" error response_cutoff)
  assert_equal("${c19_cutoff}" "5" "native K-wide C19 cutoff")

  run_case(unavailable-c19-diagnostics "${tail_model}" "${c19_analysis}"
           3 unavailable 2 3600 FALSE TRUE)
  json_get(c19_status "${C27_1_RESULT_DOCUMENT}"
           error unavailable_diagnostics c19 analytic_status)
  assert_equal("${c19_status}" "outside_strict_tail_profile"
               "C19 unavailable analytic status")
  assert_rational("${C27_1_RESULT_DOCUMENT}" 1 1
                  error unavailable_diagnostics c19 arrival_mean)
  assert_rational("${C27_1_RESULT_DOCUMENT}" 0 1
                  error unavailable_diagnostics c19 constant_tail
                  service_probability)
  assert_rational("${C27_1_RESULT_DOCUMENT}" -1 1
                  error unavailable_diagnostics c19 tail_slack)
  string(JSON coefficient_count ERROR_VARIABLE coefficient_error LENGTH
         "${C27_1_RESULT_DOCUMENT}" error unavailable_diagnostics
         coefficient_diagnostics)
  if(NOT coefficient_error STREQUAL "NOTFOUND")
    message(FATAL_ERROR
      "cannot inspect retained K-wide coefficient diagnostics")
  endif()
  assert_equal("${coefficient_count}" "7"
               "K=5 coefficient diagnostic count")

  # The provider owns equality between its response_cutoff and the resolved
  # constant-tail cutoff.  Deliberately disagreeing copies must fail before
  # a sampler payload or analytic solve can be accepted.
  set(conflict_analysis
      "${generated_fixture_root}/mismatched-cutoff-analysis.json")
  write_k_wide_analysis("${conflict_analysis}" 3 2 20 100 8 64)
  run_input_rejection_case(
    mismatched-cutoff
    "${fixture_root}/full_orbit_model_conflict.json"
    "${conflict_analysis}"
    "c27_1.full_orbit_k_wide_cutoff_mismatch"
    "the execution plan's provider response_cutoff differs from the resolved constant-response tail cutoff")
elseif(MWPERF_C27_1_SCENARIO STREQUAL "reproducibility")
  set(model "${fixture_root}/full_orbit_model_conflict.json")
  foreach(response_cutoff IN ITEMS 2 5)
    set(analysis
        "${generated_fixture_root}/repro-k${response_cutoff}-analysis.json")
    write_k_wide_analysis(
      "${analysis}" ${response_cutoff} ${response_cutoff} 20 100 8 64)
    run_case("repro-k${response_cutoff}-a" "${model}" "${analysis}"
             0 success 1)
    assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
    set(first_document "${C27_1_RESULT_DOCUMENT}")
    string(JSON first_document REMOVE "${first_document}"
           wall_clock_seconds)
    run_case("repro-k${response_cutoff}-b" "${model}" "${analysis}"
             0 success 3)
    assert_k_wide_metrics("${C27_1_RESULT_DOCUMENT}")
    set(second_document "${C27_1_RESULT_DOCUMENT}")
    string(JSON second_document REMOVE "${second_document}"
           wall_clock_seconds)
    if(NOT first_document STREQUAL second_document)
      message(FATAL_ERROR
        "K=${response_cutoff} fixed scientific inputs and seed did not produce identical scientific output across worker counts")
    endif()
  endforeach()
else()
  message(FATAL_ERROR
    "unknown MWPERF_C27_1_SCENARIO: ${MWPERF_C27_1_SCENARIO}")
endif()
