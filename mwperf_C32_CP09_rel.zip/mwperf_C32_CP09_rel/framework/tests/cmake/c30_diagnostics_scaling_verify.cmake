if(NOT DEFINED MWPERF_C30_BENCHMARK)
  message(FATAL_ERROR "C30 scaling audit requires its benchmark executable")
endif()

function(run_case output_name mode rows cutoffs)
  execute_process(
    COMMAND "${MWPERF_C30_BENCHMARK}"
            --mode "${mode}"
            --rows "${rows}"
            --cutoffs "${cutoffs}"
            --repetitions 2
    RESULT_VARIABLE result
    OUTPUT_VARIABLE output
    ERROR_VARIABLE error
    OUTPUT_STRIP_TRAILING_WHITESPACE
  )
  if(NOT result EQUAL 0)
    message(FATAL_ERROR
      "C30 benchmark ${mode}/${rows}/${cutoffs} failed: ${error}")
  endif()
  set("${output_name}" "${output}" PARENT_SCOPE)
endfunction()

run_case(disabled disabled 1024 4)
string(JSON disabled_allocations GET "${disabled}" allocation_calls)
if(NOT disabled_allocations EQUAL 0)
  message(FATAL_ERROR
    "diagnostics-disabled path allocated ${disabled_allocations} times")
endif()

run_case(parser_enabled parser 1024 4)
string(JSON parser_bytes GET "${parser_enabled}" encoded_bytes)
string(JSON parser_allocations GET "${parser_enabled}" allocation_calls)
if(parser_bytes LESS_EQUAL 0 OR parser_allocations LESS_EQUAL 0)
  message(FATAL_ERROR
    "enabled parser did not report positive bytes/allocations: ${parser_bytes}/${parser_allocations}")
endif()

run_case(parser_cap parser-cap 1024 4)
string(JSON capped_bytes GET "${parser_cap}" encoded_bytes)
string(JSON parser_limit GET "${parser_cap}" cap)
math(EXPR expected_capped_bytes "${parser_limit} + 1")
if(NOT capped_bytes EQUAL expected_capped_bytes)
  message(FATAL_ERROR
    "parser cap audit did not exercise cap-plus-one: ${capped_bytes}/${parser_limit}")
endif()

run_case(rows_small analysis 1024 8)
run_case(rows_large analysis 8192 8)
foreach(field input_level_rows merged_level_rows merge_key_comparisons
              merge_heap_operations)
  string(JSON small_value GET "${rows_small}" work "${field}")
  string(JSON large_value GET "${rows_large}" work "${field}")
  if("${field}" STREQUAL "input_level_rows" OR
     "${field}" STREQUAL "merged_level_rows")
    if(NOT small_value EQUAL 1024 OR NOT large_value EQUAL 8192)
      message(FATAL_ERROR
        "${field} does not track input rows exactly: ${small_value}/${large_value}")
    endif()
  elseif(large_value LESS small_value)
    message(FATAL_ERROR
      "${field} decreased when input rows increased: ${small_value}/${large_value}")
  else()
    math(EXPR linear_ceiling "${small_value} * 8 + 64")
    if(large_value GREATER linear_ceiling)
      message(FATAL_ERROR
        "${field} exceeded the linear counter ceiling: ${large_value} > ${linear_ceiling}")
    endif()
  endif()
endforeach()

run_case(cutoffs_small fit 512 4)
run_case(cutoffs_large fit 512 16)
string(JSON small_fits GET "${cutoffs_small}" work point_fit_invocations)
string(JSON large_fits GET "${cutoffs_large}" work point_fit_invocations)
if(NOT small_fits EQUAL 4 OR NOT large_fits EQUAL 16)
  message(FATAL_ERROR
    "point-fit counters do not track cutoff count: ${small_fits}/${large_fits}")
endif()
