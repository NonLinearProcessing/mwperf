#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "support/c19_math_test_util.hpp"

namespace {

using namespace mwperf;
using namespace mwperf::testing::c19_math;

[[nodiscard]] AuditedPhaseResponse phase_response(PhaseCarrierSpec spec) {
  auto response = mint_phase_response(std::move(spec));
  INFO((response ? std::string{} : response.error().code));
  REQUIRE(response);
  return std::move(response).value();
}

[[nodiscard]] PhaseArrivalKernel phase_kernel(
    const AuditedPhaseResponse& response) {
  auto kernel = PhaseArrivalKernel::from_audited(response);
  INFO((kernel ? std::string{} : kernel.error().code));
  REQUIRE(kernel);
  return std::move(kernel).value();
}

[[nodiscard]] BlockFluxOperator phase_flux(
    const PhaseArrivalKernel& kernel, const AuditedPhaseResponse& response) {
  auto flux = assemble_markov_additive_blocks(kernel, response);
  INFO((flux ? std::string{} : flux.error().code));
  REQUIRE(flux);
  return std::move(flux).value();
}

[[nodiscard]] PhaseCarrierSpec alternating_phase_spec(
    CarrierLineageSpec carrier_lineage) {
  carrier_lineage.arrival_family = ArrivalFamily::periodic_global_phase;
  const SelectionSpec selection = stationary_unique_selection();
  const SolverPolicy solver = policy(carrier_lineage);
  return {std::move(carrier_lineage),
          {phase(0U), phase(1U)},
          {phase_block(0U, {rational(0), rational(0), rational(1), rational(0)}),
           phase_block(1U,
                       {rational(0), rational(1), rational(0), rational(0)})},
          {rational(1, 2), rational(1, 2)},
          {rational(0), rational(0), rational(1), rational(1)},
          exact_closed_completion(1U),
          selection,
          solver};
}

[[nodiscard]] PhaseCarrierSpec noncommuting_phase_spec(
    CarrierLineageSpec carrier_lineage) {
  carrier_lineage.arrival_family = ArrivalFamily::periodic_global_phase;
  const SelectionSpec selection = stationary_unique_selection();
  const SolverPolicy solver = policy(carrier_lineage);
  return {
      std::move(carrier_lineage),
      {phase(0U), phase(1U)},
      {phase_block(0U,
                   {rational(1, 2), rational(0), rational(0), rational(1, 4)}),
       phase_block(1U,
                   {rational(0), rational(1, 2), rational(3, 4), rational(0)})},
      {rational(3, 5), rational(2, 5)},
      {rational(0), rational(0), rational(1, 4), rational(3, 4),
       rational(1), rational(1)},
      exact_closed_completion(2U),
      selection,
      solver};
}

[[nodiscard]] PhaseCarrierSpec reducible_phase_spec(
    CarrierLineageSpec carrier_lineage, SelectionSpec selection) {
  carrier_lineage.arrival_family = ArrivalFamily::periodic_global_phase;
  const SolverPolicy solver = policy(carrier_lineage);
  return {std::move(carrier_lineage),
          {phase(0U), phase(1U)},
          {phase_block(0U,
                       {rational(1), rational(0), rational(0), rational(1)})},
          {rational(1, 2), rational(1, 2)},
          {rational(0), rational(0)},
          exact_closed_completion(0U),
          std::move(selection),
          solver};
}

[[nodiscard]] AuditedFixedPointFamily fixed_family(
    FixedPointCarrierSpec spec) {
  auto family = mint_fixed_point_family(std::move(spec));
  INFO((family ? std::string{} : family.error().code));
  REQUIRE(family);
  return std::move(family).value();
}

[[nodiscard]] FixedPointCarrierSpec fixed_spec(
    CarrierLineageSpec carrier_lineage, std::vector<ExactRational> cold,
    const bool uniqueness_declared,
    std::vector<NamedFixedPointSolution> named_solutions,
    ExactFixedPointMap map, SelectionSpec selection,
    const std::uint64_t iterations = 64U,
    const std::uint64_t evaluations = 64U,
    const ExactRational& tolerance = rational(1, 1024)) {
  const SolverPolicy solver = policy(carrier_lineage, iterations, tolerance);
  return {std::move(carrier_lineage),
          {rational(0)},
          {rational(1)},
          {rational(0)},
          {rational(1)},
          std::move(cold),
          BigNat{iterations},
          BigNat{evaluations},
          uniqueness_declared,
          std::move(named_solutions),
          std::move(map),
          std::move(selection),
          solver};
}

}  // namespace

TEST_CASE("C19 public F06 left-multiplies K by the current-phase D",
          "[c19][math][sf26][noncommuting]") {
  const auto response =
      phase_response(noncommuting_phase_spec(lineage("phase-noncommuting")));
  const PhaseArrivalKernel kernel =
      phase_kernel(response);  // PhaseArrivalKernel::from_audited
  const BlockFluxOperator flux = phase_flux(kernel, response);  // F-C19-06

  const std::array<ExactRational, 4U> expected{
      rational(3, 8), rational(1, 8), rational(9, 16), rational(1, 16)};
  for (std::size_t source_phase = 0U; source_phase < 2U; ++source_phase) {
    for (std::size_t destination_phase = 0U; destination_phase < 2U;
         ++destination_phase) {
      auto entry = flux.transition_probability(BigNat{1U}, source_phase,
                                               BigNat{1U}, destination_phase);
      REQUIRE(entry);
      CHECK(entry.value() ==
            expected[source_phase * 2U + destination_phase]);
    }
  }
}

TEST_CASE("C19 public F07 solves the alternating SF.27 and SF.27a law",
          "[c19][math][sf27]") {
  auto spec = alternating_phase_spec(lineage("phase-alternating"));
  const SolverPolicy solver = spec.solver_policy;
  const SelectionSpec selection = spec.selection;
  const auto response = phase_response(std::move(spec));
  const PhaseArrivalKernel kernel = phase_kernel(response);
  const BlockFluxOperator flux = phase_flux(kernel, response);
  auto law = solve_markov_additive_stationary(
      flux, selection, solver);  // F-C19-07
  REQUIRE(law);
  CHECK(law.value().status() == AnalyticStationaryStatusV1::finite);

  auto mass_00 = law.value().mass(BigNat{0U}, 0U);
  auto mass_11 = law.value().mass(BigNat{1U}, 1U);
  auto mass_01 = law.value().mass(BigNat{0U}, 1U);
  auto mass_10 = law.value().mass(BigNat{1U}, 0U);
  REQUIRE(mass_00);
  REQUIRE(mass_11);
  REQUIRE(mass_01);
  REQUIRE(mass_10);
  CHECK(mass_00.value() == 0.5L);
  CHECK(mass_11.value() == 0.5L);
  CHECK(mass_01.value() == 0.0L);
  CHECK(mass_10.value() == 0.0L);
  REQUIRE(law.value().phase_marginal().size() == 2U);
  for (const PhaseMarginalAtomV1& marginal : law.value().phase_marginal()) {
    CHECK(marginal.invariant_mass == 0.5L);
    CHECK(marginal.configured_mass == 0.5L);
    CHECK(marginal.residual == 0.0L);
  }
  CHECK(law.value().identity() == flux.identity());
  REQUIRE(law.value().identity().accepted_metric_clause());
  REQUIRE(law.value().identity().realized_metric_binding());
  REQUIRE(law.value().identity().carrier_snapshot_digest());
  CHECK(law.value().identity().configured_arrival() ==
        flux.identity().configured_arrival());
}

TEST_CASE("C19 phase completion and reducibility form one exact table",
          "[c19][math][phase-table]") {
  enum class Scenario : std::uint8_t {
    leaked_exact_cutoff,
    additive_completion,
    nonzero_mu_at_zero,
    nonstochastic_kernel,
    ambiguous_classes,
    selected_mixture,
  };
  constexpr std::array scenarios{
      Scenario::leaked_exact_cutoff, Scenario::additive_completion,
      Scenario::nonzero_mu_at_zero, Scenario::nonstochastic_kernel,
      Scenario::ambiguous_classes, Scenario::selected_mixture};

  for (const Scenario scenario : scenarios) {
    CAPTURE(static_cast<unsigned>(scenario));
    if (scenario == Scenario::ambiguous_classes ||
        scenario == Scenario::selected_mixture) {
      const bool selected = scenario == Scenario::selected_mixture;
      const CarrierLineageSpec carrier_lineage =
          lineage(selected ? "phase-reducible-selected"
                           : "phase-reducible-ambiguous");
      const SelectionSpec selection =
          selected ? equal_stationary_mixture()
                   : stationary_unique_selection();
      auto spec = reducible_phase_spec(carrier_lineage, selection);
      const SolverPolicy solver = spec.solver_policy;
      const auto response = phase_response(std::move(spec));
      const PhaseArrivalKernel kernel = phase_kernel(response);
      const BlockFluxOperator flux = phase_flux(kernel, response);
      auto law = solve_markov_additive_stationary(flux, selection, solver);
      if (!selected) {
        REQUIRE_FALSE(law);
      } else {
        REQUIRE(law);
        REQUIRE(law.value().selected_classes().size() == 2U);
        auto first = law.value().mass(BigNat{0U}, 0U);
        auto second = law.value().mass(BigNat{0U}, 1U);
        REQUIRE(first);
        REQUIRE(second);
        CHECK(first.value() == 0.5L);
        CHECK(second.value() == 0.5L);
      }
      continue;
    }

    CarrierLineageSpec carrier_lineage =
        lineage("phase-table-" + std::to_string(static_cast<unsigned>(scenario)));
    carrier_lineage.arrival_family = ArrivalFamily::periodic_global_phase;
    const SelectionSpec selection = stationary_unique_selection();
    const SolverPolicy solver = policy(carrier_lineage);
    PhaseLevelCompletionV1 completion = exact_closed_completion(0U);
    ExactRational service = ExactRational::zero();
    std::vector<ExactPhaseArrivalBlockV1> blocks{
        phase_block(1U, {ExactRational::one()})};
    if (scenario == Scenario::additive_completion) {
      auto completion_id = analysis_fingerprint(lineage("phase-completion"));
      REQUIRE(completion_id);
      completion = {PhaseLevelCompletionKindV1::additive_completion,
                    BigNat{0U}, std::move(completion_id).value(),
                    {PhaseCompletionAtomV1{0U, 0U, ExactRational::one()}}};
    } else if (scenario == Scenario::nonzero_mu_at_zero) {
      service = rational(1, 2);
      blocks = {phase_block(0U, {ExactRational::one()})};
    } else if (scenario == Scenario::nonstochastic_kernel) {
      blocks = {phase_block(0U, {rational(1, 2)})};
    }
    PhaseCarrierSpec spec{
        std::move(carrier_lineage), {phase(0U)}, std::move(blocks),
        {ExactRational::one()}, {service}, std::move(completion), selection,
        solver};
    auto minted = mint_phase_response(std::move(spec));
    if (!minted) {
      CHECK(scenario != Scenario::additive_completion);
      continue;
    }
    auto kernel = PhaseArrivalKernel::from_audited(minted.value());
    if (!kernel) {
      CHECK(scenario == Scenario::nonstochastic_kernel);
      continue;
    }
    auto flux = assemble_markov_additive_blocks(kernel.value(), minted.value());
    if (scenario == Scenario::additive_completion) {
      REQUIRE(flux);
      auto self = flux.value().transition_probability(BigNat{0U}, 0U,
                                                      BigNat{0U}, 0U);
      REQUIRE(self);
      CHECK(self.value() == ExactRational::one());
    } else {
      REQUIRE_FALSE(flux);
    }
  }
}

TEST_CASE("C19 rejects foreign phase identity and analysis before solving",
          "[c19][math][phase-identity]") {
  auto first_spec = alternating_phase_spec(lineage("phase-origin"));
  const SolverPolicy correct_policy = first_spec.solver_policy;
  const SelectionSpec selection = first_spec.selection;
  const auto first = phase_response(std::move(first_spec));
  const auto foreign =
      phase_response(alternating_phase_spec(lineage("phase-foreign")));
  const PhaseArrivalKernel kernel = phase_kernel(first);

  auto foreign_response = assemble_markov_additive_blocks(kernel, foreign);
  REQUIRE_FALSE(foreign_response);

  const BlockFluxOperator flux = phase_flux(kernel, first);
  SolverPolicy foreign_policy = correct_policy;
  auto foreign_fingerprint = analysis_fingerprint(lineage("phase-analysis"));
  REQUIRE(foreign_fingerprint);
  foreign_policy.analysis_fingerprint = std::move(foreign_fingerprint).value();
  auto rejected =
      solve_markov_additive_stationary(flux, selection, foreign_policy);
  REQUIRE_FALSE(rejected);
}

TEST_CASE("C19 public F08 converges cold and reports both SF.37 residuals",
          "[c19][math][sf37][convergent]") {
  const CarrierLineageSpec carrier_lineage = lineage("fixed-affine");
  const SelectionSpec selection = fixed_unique_selection();
  const SolverPolicy solver = policy(carrier_lineage, 64U, rational(1, 1024));
  const ExactRational quarter = rational(1, 4);
  const ExactRational half = rational(1, 2);
  auto spec = fixed_spec(
      carrier_lineage, {ExactRational::zero()}, true, {},
      [quarter, half](const std::span<const ExactRational> value) {
        return Result<std::vector<ExactRational>>::success(
            {quarter + half * value.front()});
      },
      selection, 64U, 64U, rational(1, 1024));
  const auto family = fixed_family(std::move(spec));
  auto law = solve_declared_fixed_point(family, selection, solver);  // F-C19-08
  REQUIRE(law);
  CHECK(law.value().termination() == FixedPointTerminationV1::converged);
  REQUIRE(law.value().parameters().size() == 1U);
  const ExactRational eta = law.value().parameters().front();
  CHECK(eta < half);
  CHECK(law.value().fixed_point_residual() == quarter - half * eta);
  CHECK(law.value().iterate_difference() ==
        rational(2) * law.value().fixed_point_residual());
  CHECK(law.value().fixed_point_residual() <= rational(1, 1024));
  REQUIRE(law.value().identity().accepted_metric_clause());
  REQUIRE(law.value().identity().realized_metric_binding());
  REQUIRE(law.value().identity().carrier_snapshot_digest());
}

TEST_CASE("C19 fixed-point selector budget and identity form one table",
          "[c19][math][sf37][fixed-table]") {
  SECTION("the identity map requires its declared root selector") {
    const CarrierLineageSpec carrier_lineage = lineage("fixed-selected");
    const SelectionSpec selection = fixed_id_selection("one-third");
    const SolverPolicy solver = policy(carrier_lineage, 8U, rational(0));
    auto spec = fixed_spec(
        carrier_lineage, {rational(1, 3)}, false,
        {{label("one-third"), {rational(1, 3)}}},
        [](const std::span<const ExactRational> value) {
          return Result<std::vector<ExactRational>>::success(
              {value.front()});
        },
        selection, 8U, 8U, rational(0));
    const auto family = fixed_family(std::move(spec));
    auto selected = solve_declared_fixed_point(family, selection, solver);
    REQUIRE(selected);
    CHECK(selected.value().termination() == FixedPointTerminationV1::converged);
    REQUIRE(selected.value().parameters().size() == 1U);
    CHECK(selected.value().parameters().front() == rational(1, 3));
    CHECK(selected.value().iterate_difference().is_zero());
    CHECK(selected.value().fixed_point_residual().is_zero());
  }

  SECTION("a nonunique identity map rejects an unqualified selector") {
    const CarrierLineageSpec carrier_lineage = lineage("fixed-ambiguous");
    const SelectionSpec selection = fixed_unique_selection();
    const SolverPolicy solver = policy(carrier_lineage, 8U, rational(0));
    auto spec = fixed_spec(
        carrier_lineage, {rational(1, 3)}, false,
        {{label("one-third"), {rational(1, 3)}},
         {label("two-thirds"), {rational(2, 3)}}},
        [](const std::span<const ExactRational> value) {
          return Result<std::vector<ExactRational>>::success(
              {value.front()});
        },
        selection, 8U, 8U, rational(0));
    const auto family = fixed_family(std::move(spec));
    auto ambiguous = solve_declared_fixed_point(family, selection, solver);
    REQUIRE_FALSE(ambiguous);
    CHECK(ambiguous.error().code == "c19.fixed_point_ambiguous");
  }

  SECTION("the oscillating map exhausts exactly its declared budget") {
    const CarrierLineageSpec carrier_lineage = lineage("fixed-oscillating");
    const SelectionSpec selection = fixed_unique_selection();
    const SolverPolicy solver = policy(carrier_lineage, 4U, rational(0));
    auto spec = fixed_spec(
        carrier_lineage, {ExactRational::zero()}, true, {},
        [](const std::span<const ExactRational> value) {
          return Result<std::vector<ExactRational>>::success(
              {ExactRational::one() - value.front()});
        },
        selection, 4U, 4U, rational(0));
    const auto family = fixed_family(std::move(spec));
    auto exhausted = solve_declared_fixed_point(family, selection, solver);
    REQUIRE(exhausted);
    CHECK(exhausted.value().termination() ==
          FixedPointTerminationV1::evaluation_budget_exhausted);
    CHECK(exhausted.value().evaluation_count() == BigNat{4U});
    CHECK(exhausted.value().iterate_difference() == ExactRational::one());
    CHECK(exhausted.value().fixed_point_residual() == ExactRational::one());
  }

  SECTION("iteration and evaluation exhaustion remain distinct") {
    const CarrierLineageSpec carrier_lineage =
        lineage("fixed-iteration-budget");
    const SelectionSpec selection = fixed_unique_selection();
    const SolverPolicy solver = policy(carrier_lineage, 2U, rational(0));
    auto spec = fixed_spec(
        carrier_lineage, {ExactRational::zero()}, true, {},
        [](const std::span<const ExactRational> value) {
          return Result<std::vector<ExactRational>>::success(
              {ExactRational::one() - value.front()});
        },
        selection, 2U, 8U, rational(0));
    const auto family = fixed_family(std::move(spec));
    auto exhausted = solve_declared_fixed_point(family, selection, solver);
    REQUIRE(exhausted);
    CHECK(exhausted.value().termination() ==
          FixedPointTerminationV1::iteration_budget_exhausted);
    CHECK(exhausted.value().iteration_count() == BigNat{2U});
    CHECK(exhausted.value().evaluation_count() == BigNat{3U});
    CHECK(exhausted.value().iterate_difference() == ExactRational::one());
    CHECK(exhausted.value().fixed_point_residual() == ExactRational::one());
  }

  SECTION("a foreign policy is rejected before the first map evaluation") {
    const CarrierLineageSpec carrier_lineage = lineage("fixed-policy-origin");
    const SelectionSpec selection = fixed_unique_selection();
    const SolverPolicy solver = policy(carrier_lineage, 4U, rational(0));
    const auto calls = std::make_shared<unsigned>(0U);
    auto spec = fixed_spec(
        carrier_lineage, {rational(1, 2)}, true, {},
        [calls](const std::span<const ExactRational> value) {
          ++*calls;
          return Result<std::vector<ExactRational>>::success(
              {value.front()});
        },
        selection, 4U, 4U, rational(0));
    const auto family = fixed_family(std::move(spec));
    SolverPolicy foreign = solver;
    auto fingerprint = analysis_fingerprint(lineage("fixed-policy-foreign"));
    REQUIRE(fingerprint);
    foreign.analysis_fingerprint = std::move(fingerprint).value();
    auto rejected = solve_declared_fixed_point(family, selection, foreign);
    REQUIRE_FALSE(rejected);
    CHECK(*calls == 0U);
  }
}
