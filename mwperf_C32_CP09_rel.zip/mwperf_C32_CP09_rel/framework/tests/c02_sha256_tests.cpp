#include <algorithm>
#include <array>
#include <cstddef>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"

namespace {

[[nodiscard]] std::span<const std::byte> bytes_of(
    const std::string_view text) noexcept {
  return std::as_bytes(std::span<const char>(text.data(), text.size()));
}

[[nodiscard]] mwperf::Digest256 checked_hash(const std::string_view text) {
  auto result = mwperf::sha256(bytes_of(text));
  REQUIRE(result.has_value());
  return std::move(result).value();
}

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::Digest256>);

TEST_CASE("Digest256 admits exactly 32 bytes and canonical lower-case hex",
          "[c02][unit][negative]") {
  const std::array<std::byte, mwperf::Digest256::kSize> zero_bytes{};
  auto digest = mwperf::Digest256::from_bytes(zero_bytes);
  REQUIRE(digest.has_value());
  CHECK(digest.value().hex() == std::string(64U, '0'));
  CHECK(std::equal(digest.value().bytes().begin(),
                   digest.value().bytes().end(), zero_bytes.begin()));

  const auto reparsed = mwperf::Digest256::from_hex(digest.value().hex());
  REQUIRE(reparsed.has_value());
  CHECK(reparsed.value() == digest.value());

  const std::array<std::byte, 31U> short_bytes{};
  const std::array<std::byte, 33U> long_bytes{};
  const auto short_result = mwperf::Digest256::from_bytes(short_bytes);
  const auto long_result = mwperf::Digest256::from_bytes(long_bytes);
  REQUIRE_FALSE(short_result.has_value());
  REQUIRE_FALSE(long_result.has_value());
  CHECK(short_result.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(short_result.error().code == "invalid_digest_width");
  CHECK(long_result.error().code == "invalid_digest_width");

  const auto short_hex = mwperf::Digest256::from_hex(std::string(63U, '0'));
  const auto uppercase = mwperf::Digest256::from_hex(
      "ABCDEF0000000000000000000000000000000000000000000000000000000000");
  const auto punctuation = mwperf::Digest256::from_hex(
      "!000000000000000000000000000000000000000000000000000000000000000");
  REQUIRE_FALSE(short_hex.has_value());
  REQUIRE_FALSE(uppercase.has_value());
  REQUIRE_FALSE(punctuation.has_value());
  CHECK(short_hex.error().code == "invalid_digest_width");
  CHECK(uppercase.error().code == "noncanonical_digest_hex");
  CHECK(punctuation.error().code == "noncanonical_digest_hex");
}

TEST_CASE("Digest256 comparison is lexicographic over unsigned digest bytes",
          "[c02][unit]") {
  const auto zero = mwperf::Digest256::from_hex(std::string(64U, '0'));
  const auto low = mwperf::Digest256::from_hex(
      "0000000000000000000000000000000000000000000000000000000000000001");
  const auto high = mwperf::Digest256::from_hex(std::string(64U, 'f'));
  REQUIRE(zero.has_value());
  REQUIRE(low.has_value());
  REQUIRE(high.has_value());
  CHECK(zero.value() < low.value());
  CHECK(low.value() < high.value());
  CHECK(high.value() == high.value());
}

TEST_CASE("SHA-256 matches standard known-answer vectors", "[c02][unit]") {
  struct Vector final {
    std::string_view message;
    std::string_view digest;
  };
  constexpr std::array<Vector, 4U> vectors{{
      {"", "e3b0c44298fc1c149afbf4c8996fb924"
           "27ae41e4649b934ca495991b7852b855"},
      {"abc", "ba7816bf8f01cfea414140de5dae2223"
              "b00361a396177a9cb410ff61f20015ad"},
      {"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
       "248d6a61d20638b8e5c026930c3e6039"
       "a33ce45964ff2167f6ecedd419db06c1"},
      {"abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmn"
       "hijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu",
       "cf5b16a778af8380036ce59e7b049237"
       "0b249b11e8f07a51afac45037afee9d1"},
  }};

  for (const Vector& vector : vectors) {
    INFO("message length: " << vector.message.size());
    CHECK(checked_hash(vector.message).hex() == vector.digest);

    mwperf::Sha256 one_byte_chunks;
    for (std::size_t index = 0U; index < vector.message.size(); ++index) {
      REQUIRE(one_byte_chunks
                  .update(bytes_of(vector.message.substr(index, 1U)))
                  .has_value());
    }
    CHECK(one_byte_chunks.finalize().hex() == vector.digest);
  }
}

TEST_CASE("incremental SHA-256 is chunk invariant and finalize is a snapshot",
          "[c02][unit][property]") {
  constexpr std::string_view message =
      "incremental hashing must not depend on how input bytes are divided "
      "across calls, including divisions at the compression boundary";
  const mwperf::Digest256 expected = checked_hash(message);

  for (std::size_t chunk_size = 1U; chunk_size <= 71U; ++chunk_size) {
    mwperf::Sha256 incremental;
    REQUIRE(incremental.update({}).has_value());
    for (std::size_t offset = 0U; offset < message.size();
         offset += chunk_size) {
      const std::size_t count =
          std::min(chunk_size, message.size() - offset);
      REQUIRE(incremental
                  .update(bytes_of(message.substr(offset, count)))
                  .has_value());
    }
    CHECK(incremental.finalize() == expected);
    CHECK(incremental.finalize() == expected);
  }

  mwperf::Sha256 extensible;
  REQUIRE(extensible.update(bytes_of("abc")).has_value());
  const mwperf::Digest256 abc = extensible.finalize();
  REQUIRE(extensible.update(bytes_of("def")).has_value());
  CHECK(abc.hex() ==
        "ba7816bf8f01cfea414140de5dae2223"
        "b00361a396177a9cb410ff61f20015ad");
  CHECK(extensible.finalize() == checked_hash("abcdef"));
}

TEST_CASE("incremental SHA-256 handles a million-byte standard vector",
          "[c02][unit]") {
  std::array<std::byte, 1000U> chunk{};
  std::fill(chunk.begin(), chunk.end(), std::byte{'a'});
  mwperf::Sha256 hasher;
  for (std::size_t repetition = 0U; repetition < 1000U; ++repetition) {
    REQUIRE(hasher.update(chunk).has_value());
  }
  CHECK(hasher.finalize().hex() ==
        "cdc76e5c9914fb9281a1c7e284d73e67"
        "f1809a48a497200e046d39ccc7112cd0");
}

TEST_CASE("domain-separated SHA-256 uses the documented byte preimage",
          "[c02][unit][negative]") {
  const auto digest =
      mwperf::sha256_domain_separated("mwperf.test", bytes_of("canonical"));
  REQUIRE(digest.has_value());
  CHECK(digest.value().hex() ==
        "a53b2ecf1c00e34e2985f291fc95aa13"
        "83f0f759e792ff6c30fb8cb404da7313");

  std::string explicit_preimage = "mwperf.test";
  explicit_preimage.push_back('\0');
  explicit_preimage += "canonical";
  CHECK(digest.value() == checked_hash(explicit_preimage));

  const auto other_domain =
      mwperf::sha256_domain_separated("mwperf.other", bytes_of("canonical"));
  const auto other_payload =
      mwperf::sha256_domain_separated("mwperf.test", bytes_of("canonical!"));
  REQUIRE(other_domain.has_value());
  REQUIRE(other_payload.has_value());
  CHECK(other_domain.value() != digest.value());
  CHECK(other_payload.value() != digest.value());

  const auto empty_domain = mwperf::sha256_domain_separated("", {});
  const auto spaced_domain = mwperf::sha256_domain_separated("mwperf test", {});
  const auto nul_domain = mwperf::sha256_domain_separated(
      std::string_view("mwperf\0test", 11U), {});
  const std::array<char, 1U> non_ascii_character{
      static_cast<char>(0x80U)};
  const auto non_ascii_domain = mwperf::sha256_domain_separated(
      std::string_view(non_ascii_character.data(), non_ascii_character.size()),
      {});
  REQUIRE_FALSE(empty_domain.has_value());
  REQUIRE_FALSE(spaced_domain.has_value());
  REQUIRE_FALSE(nul_domain.has_value());
  REQUIRE_FALSE(non_ascii_domain.has_value());
  CHECK(empty_domain.error().code == "invalid_digest_domain");
  CHECK(spaced_domain.error().category ==
        mwperf::DiagnosticCategory::input_validation);
}
