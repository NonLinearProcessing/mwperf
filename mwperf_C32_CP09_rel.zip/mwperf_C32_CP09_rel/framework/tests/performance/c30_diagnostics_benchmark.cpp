#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/diagnostics/compression_analysis.hpp"

namespace {

std::atomic<bool> g_count_allocations{false};
std::atomic<std::uint64_t> g_allocation_calls{0U};

void count_allocation() noexcept {
  if (g_count_allocations.load(std::memory_order_relaxed)) {
    g_allocation_calls.fetch_add(1U, std::memory_order_relaxed);
  }
}

template <typename T>
T take(mwperf::Result<T> value) {
  if (!value) {
    throw std::runtime_error(value.error().code + ": " +
                             value.error().message);
  }
  return std::move(value).value();
}

mwperf::ExactRational rational(const std::uint64_t numerator,
                              const std::uint64_t denominator = 1U) {
  return take(mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                          mwperf::BigInt{denominator}));
}

mwperf::Digest256 digest(const char digit) {
  return take(mwperf::Digest256::from_hex(std::string(64U, digit)));
}

mwperf::ObservationScalarV1 scalar(const std::uint64_t value) {
  return {mwperf::PortableScientificScalar::rational(rational(value)),
          std::nullopt};
}

mwperf::ConstructionObservationEnvelopeV1 benchmark_observation(
    const std::size_t row_count) {
  if (row_count < 2U || row_count > 100'000U) {
    throw std::invalid_argument("rows must be in 2..100000");
  }
  std::vector<mwperf::ExactLevelObservationV1> levels;
  levels.reserve(row_count);
  for (std::size_t index = 0U; index < row_count; ++index) {
    levels.push_back(
        {mwperf::BigNat{static_cast<std::uint64_t>(index)}, scalar(1U),
         scalar(index == 0U ? 0U : 1U), std::nullopt});
  }
  const auto exact_balance = [](const std::uint64_t mass) {
    return mwperf::ObservationMassBalanceV1{
        mwperf::ObservationNormalizationClaimV1::exact, scalar(mass),
        scalar(0U)};
  };
  const std::uint64_t horizon = static_cast<std::uint64_t>(row_count);
  mwperf::ConstructionObservationBundleV1 bundle{
      1U,
      mwperf::ObservationSourceRoleV1::short_restart_reference,
      mwperf::ObservationScalarRepresentationV1::exact_rational,
      {digest('1'),
       digest('2'),
       digest('3'),
       {mwperf::QueueId(
            mwperf::TypedLabel::numeric(mwperf::BigNat{0U})),
        0U, rational(1U)},
       {"iid_batch_v1",
        digest('4'),
        mwperf::ExactTargetArrivalMarginalV1{
            {{mwperf::BigNat{0U}, rational(3U, 4U)},
             {mwperf::BigNat{1U}, rational(1U, 4U)}}},
        rational(1U, 4U), rational(1U, 4U)},
       digest('5'), digest('6'), digest('7'), digest('8'), digest('9'),
       digest('a')},
      {{mwperf::ObservationSlotStageV1::solve_primary_maxweight,
        mwperf::ObservationSlotStageV1::observe_pre_service,
        mwperf::ObservationSlotStageV1::apply_actual_service,
        mwperf::ObservationSlotStageV1::apply_fresh_late_arrival,
        mwperf::ObservationSlotStageV1::commit_post_slot_state,
        mwperf::ObservationSlotStageV1::emit_committed_observation},
       digest('b')},
      {"point_mass_zero", digest('c')},
      {"counter_rng", 1U, digest('d')},
      0U,
      horizon,
      {0U, horizon},
      {{true, std::nullopt}, {true, std::nullopt}, {true, std::nullopt},
       {true, std::nullopt}, {true, std::nullopt}, {true, std::nullopt},
       {false, std::string("not_requested")}},
      {{mwperf::TypedLabel::numeric(mwperf::BigNat{0U}), digest('e'),
        std::nullopt, mwperf::ObservationCompletenessV1::complete, horizon,
        {{0U,
          horizon,
          mwperf::ObservationCompletenessV1::complete,
          horizon,
          std::move(levels),
          exact_balance(horizon),
          {0U, {{mwperf::BigNat{0U}, scalar(1U)}}, exact_balance(1U)},
          {horizon,
           {{mwperf::BigNat{0U}, scalar(1U)}},
           exact_balance(1U)}}}}}};
  auto body_digest =
      take(mwperf::construction_observation_bundle_digest_v1(bundle));
  return {std::move(bundle), std::move(body_digest)};
}

struct Arguments final {
  std::string mode{"analysis"};
  std::size_t rows{4096U};
  std::size_t cutoff_count{12U};
  std::size_t repetitions{5U};
};

Arguments arguments(const int argc, char** argv) {
  Arguments parsed;
  for (int index = 1; index < argc; ++index) {
    const std::string_view token(argv[index]);
    if (index + 1 >= argc) {
      throw std::invalid_argument("every benchmark option needs a value");
    }
    const std::string value(argv[++index]);
    if (token == "--mode") {
      parsed.mode = value;
    } else if (token == "--rows") {
      parsed.rows = static_cast<std::size_t>(std::stoull(value));
    } else if (token == "--cutoffs") {
      parsed.cutoff_count = static_cast<std::size_t>(std::stoull(value));
    } else if (token == "--repetitions") {
      parsed.repetitions = static_cast<std::size_t>(std::stoull(value));
    } else {
      throw std::invalid_argument("unknown benchmark option");
    }
  }
  if (parsed.repetitions == 0U || parsed.cutoff_count == 0U) {
    throw std::invalid_argument("cutoffs and repetitions must be positive");
  }
  return parsed;
}

bool diagnostics_absent_gate(
    const mwperf::ValidatedConstructionObservationBundleV1* observation) {
  if (observation == nullptr) {
    return false;
  }
  mwperf::CompressionAnalysisOptionsV1 options;
  return static_cast<bool>(
      mwperf::analyze_compression_observations_v1(*observation, options));
}

}  // namespace

void* operator new(const std::size_t size) {
  count_allocation();
  if (void* memory = std::malloc(size == 0U ? 1U : size)) {
    return memory;
  }
  throw std::bad_alloc();
}

void* operator new[](const std::size_t size) {
  return ::operator new(size);
}

void operator delete(void* memory) noexcept { std::free(memory); }
void operator delete[](void* memory) noexcept { std::free(memory); }
void operator delete(void* memory, std::size_t) noexcept { std::free(memory); }
void operator delete[](void* memory, std::size_t) noexcept {
  std::free(memory);
}

int main(const int argc, char** argv) {
  try {
    const Arguments config = arguments(argc, argv);
    std::vector<std::uint64_t> samples;
    samples.reserve(config.repetitions);
    std::uint64_t total_allocations = 0U;
    std::optional<mwperf::CompressionAnalysisWorkCountersV1> observed_work;

    if (config.mode == "disabled") {
      for (std::size_t repetition = 0U; repetition <= config.repetitions;
           ++repetition) {
        g_allocation_calls.store(0U, std::memory_order_relaxed);
        g_count_allocations.store(true, std::memory_order_relaxed);
        const auto started = std::chrono::steady_clock::now();
        const bool analyzed = diagnostics_absent_gate(nullptr);
        const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now() - started);
        g_count_allocations.store(false, std::memory_order_relaxed);
        if (analyzed) throw std::runtime_error("absent diagnostics were run");
        if (repetition != 0U) {
          samples.push_back(static_cast<std::uint64_t>(elapsed.count()));
          total_allocations +=
              g_allocation_calls.load(std::memory_order_relaxed);
        }
      }
      if (total_allocations != 0U) {
        throw std::runtime_error(
            "diagnostics-disabled path performed a measured allocation");
      }
    } else {
      auto envelope = benchmark_observation(config.rows);
      auto validated = take(mwperf::validate_construction_observation_envelope_v1(
          std::move(envelope),
          mwperf::default_observation_parse_limits_v1()));
      if (config.mode == "parser" || config.mode == "parser-cap") {
        auto artifact = take(
            mwperf::canonical_construction_observation_envelope_bytes_v1(
                {validated.value(), validated.digest()}));
        if (config.mode == "parser") {
          g_allocation_calls.store(0U, std::memory_order_relaxed);
          g_count_allocations.store(true, std::memory_order_relaxed);
          const auto started = std::chrono::steady_clock::now();
          auto parsed = mwperf::parse_construction_observation_envelope_v1(
              artifact, mwperf::default_observation_parse_limits_v1());
          const auto elapsed =
              std::chrono::duration_cast<std::chrono::nanoseconds>(
                  std::chrono::steady_clock::now() - started);
          g_count_allocations.store(false, std::memory_order_relaxed);
          if (!parsed) {
            throw std::runtime_error(parsed.error().code + ": " +
                                     parsed.error().message);
          }
          std::cout << "{\"mode\":\"parser\",\"encoded_bytes\":"
                    << artifact.size() << ",\"allocation_calls\":"
                    << g_allocation_calls.load(std::memory_order_relaxed)
                    << ",\"elapsed_ns\":[" << elapsed.count() << "]}\n";
          return 0;
        }
        auto limits = mwperf::default_observation_parse_limits_v1();
        limits.maximum_bytes = artifact.size() - 1U;
        const auto rejected =
            mwperf::parse_construction_observation_envelope_v1(artifact, limits);
        if (rejected ||
            rejected.error().code != "observation_parse_input_bytes_limit") {
          throw std::runtime_error("parser cap-plus-one was not rejected");
        }
        std::cout << "{\"mode\":\"parser-cap\",\"encoded_bytes\":"
                  << artifact.size() << ",\"cap\":" << limits.maximum_bytes
                  << "}\n";
        return 0;
      }
      if (config.mode != "analysis" && config.mode != "fit") {
        throw std::invalid_argument(
            "mode must be disabled, analysis, fit, parser, or parser-cap");
      }
      mwperf::CompressionAnalysisOptionsV1 options;
      options.cutoffs.clear();
      for (std::size_t index = 1U; index <= config.cutoff_count; ++index) {
        options.cutoffs.emplace_back(static_cast<std::uint64_t>(index));
      }
      options.run_diagnostic_fits = config.mode == "fit";
      options.compute_delete_one_replication_jackknife = false;
      for (std::size_t repetition = 0U; repetition <= config.repetitions;
           ++repetition) {
        g_allocation_calls.store(0U, std::memory_order_relaxed);
        g_count_allocations.store(true, std::memory_order_relaxed);
        const auto started = std::chrono::steady_clock::now();
        auto result = mwperf::analyze_compression_observations_v1(
            validated, options);
        const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now() - started);
        g_count_allocations.store(false, std::memory_order_relaxed);
        if (!result) {
          throw std::runtime_error(result.error().code + ": " +
                                   result.error().message);
        }
        if (observed_work.has_value() &&
            *observed_work != result.value().work) {
          throw std::runtime_error(
              "deterministic work counters changed between repetitions");
        }
        observed_work = result.value().work;
        if (repetition != 0U) {
          samples.push_back(static_cast<std::uint64_t>(elapsed.count()));
          total_allocations +=
              g_allocation_calls.load(std::memory_order_relaxed);
        }
      }
    }

    std::cout << "{\"mode\":\"" << config.mode << "\",\"rows\":"
              << config.rows << ",\"cutoffs\":" << config.cutoff_count
              << ",\"repetitions\":" << config.repetitions
              << ",\"allocation_calls\":" << total_allocations;
    if (observed_work.has_value()) {
      const auto& work = *observed_work;
      std::cout
          << ",\"work\":{\"input_level_rows\":" << work.input_level_rows
          << ",\"input_boundary_rows\":" << work.input_boundary_rows
          << ",\"merged_level_rows\":" << work.merged_level_rows
          << ",\"merged_boundary_rows\":" << work.merged_boundary_rows
          << ",\"merge_key_comparisons\":" << work.merge_key_comparisons
          << ",\"merge_heap_operations\":" << work.merge_heap_operations
          << ",\"point_fit_invocations\":" << work.point_fit_invocations
          << ",\"jackknife_fit_invocations\":"
          << work.jackknife_fit_invocations
          << ",\"top_level_reservation_events\":"
          << work.top_level_reservation_events
          << ",\"analysis_allocation_events\":"
          << work.analysis_allocation_events
          << ",\"input_row_bytes\":" << work.input_row_bytes
          << ",\"peak_retained_top_level_objects\":"
          << work.peak_retained_top_level_objects
          << ",\"estimated_peak_retained_bytes\":"
          << work.estimated_peak_retained_bytes << '}';
    }
    std::cout << ",\"elapsed_ns\":[";
    for (std::size_t index = 0U; index < samples.size(); ++index) {
      if (index != 0U) std::cout << ',';
      std::cout << samples[index];
    }
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception& error) {
    g_count_allocations.store(false, std::memory_order_relaxed);
    std::cerr << "c30 benchmark error: " << error.what() << '\n';
    return 1;
  }
}
