#include <array>
#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_end_to_end_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
using Json = nlohmann::ordered_json;

template <typename T>
concept HasCallbackField = requires(T value) { value.callback; };

template <typename T>
concept HasObjectCodeField = requires(T value) { value.object_code; };

template <typename T>
concept HasSharedLibraryField = requires(T value) { value.shared_library; };

template <typename T>
concept HasExecutableExpressionField =
    requires(T value) { value.executable_expression; };

template <typename T>
concept DataOnlyPayloadRecord =
    !HasCallbackField<T> && !HasObjectCodeField<T> &&
    !HasSharedLibraryField<T> && !HasExecutableExpressionField<T>;

static_assert(DataOnlyPayloadRecord<mwperf::ThreeBinScalarResponseV1>);
static_assert(DataOnlyPayloadRecord<mwperf::FiniteParameterAnalyticDataV1>);
static_assert(DataOnlyPayloadRecord<mwperf::FiniteLawTablesV1>);
static_assert(DataOnlyPayloadRecord<mwperf::RegisteredRuntimeRecipeV1>);
static_assert(DataOnlyPayloadRecord<mwperf::ResponseEnvelopeEvidenceV1>);
static_assert(DataOnlyPayloadRecord<mwperf::DirectMetricPayloadV1>);

[[nodiscard]] mwperf::ConstructionBudget count_budget(
    const std::uint64_t optimizer_calls,
    const std::uint64_t optimizer_search_states,
    const std::uint64_t configured_generator_draws) {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{optimizer_calls}},
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{optimizer_search_states}},
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{configured_generator_draws}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

[[nodiscard]] mwperf::testing::C16DesignatedScenarioV1 make_scenario(
    const std::string_view provider_id,
    mwperf::ConstructionBudget budget) {
  using namespace mwperf::testing::c16_designated_detail;
  auto source = input(provider_id);
  auto id = mwperf::SurrogateId::parse(std::string(provider_id));
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue("q0")},
      mwperf::ConstructionGroupIdV1(
          label("c16.producer-matrix.construction-group"))};
  auto view = mwperf::build_framework_problem_view(
      source.instance, *source.arrival, targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(),
      mwperf::testing::c16_designated_detail::parameters());
  REQUIRE(parameters);
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements, budget,
      parameters.value());
  INFO((preview ? std::string{} : preview.error().code + ": " +
                                      preview.error().message));
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, source.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, mwperf::MasterSeed(0xC160507U));
  INFO((request ? std::string{} : request.error().code + ": " +
                                      request.error().message));
  REQUIRE(request);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(),
          manifest,
          std::move(source.instance),
          std::move(source.arrival),
          std::move(source.requirements),
          std::move(source.request),
          std::move(view).value(),
          std::move(parameters).value(),
          std::move(preview).value(),
          std::move(contract),
          std::move(budget),
          std::move(request).value()};
}

[[nodiscard]] mwperf::ArtifactParseLimits parse_limits() {
  return {1U << 20U, 64U, 1U << 14U, 1U << 14U, 1U << 16U,
          1U << 16U, 8U << 20U};
}

[[nodiscard]] std::string text_of(
    const std::span<const std::byte> bytes) {
  return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
}

[[nodiscard]] std::vector<std::byte> bytes_of(
    const std::string_view text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  return {bytes.begin(), bytes.end()};
}

void reseal(mwperf::CommonBuildReportV1& report) {
  auto digest = mwperf::canonical_common_build_report_digest_v1(report);
  REQUIRE(digest);
  report.report_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::SurrogateBuildResult built_with_report(
    const mwperf::testing::C16DesignatedScenarioV1& scenario,
    const mwperf::CommonBuildReportV1& report) {
  auto result = mwperf::testing::c16_flow_fixture::built_result(
      scenario.request, scenario.manifest.value());
  REQUIRE(result);
  auto* built = std::get_if<mwperf::BuiltSurrogateResultV1>(&result.value());
  REQUIRE(built != nullptr);
  built->envelope.build_report = report;
  return std::move(result).value();
}

[[nodiscard]] mwperf::CommonBuildReportV1 built_report(
    const mwperf::testing::C16DesignatedScenarioV1& scenario) {
  auto result = mwperf::testing::c16_flow_fixture::built_result(
      scenario.request, scenario.manifest.value());
  REQUIRE(result);
  const auto* built =
      std::get_if<mwperf::BuiltSurrogateResultV1>(&result.value());
  REQUIRE(built != nullptr);
  return built->envelope.build_report;
}

[[nodiscard]] mwperf::PortableScientificScalar natural(
    const std::uint64_t value) {
  auto rational = mwperf::ExactRational::make(
      mwperf::BigInt(value), mwperf::BigInt{1});
  REQUIRE(rational);
  return mwperf::PortableScientificScalar::rational(
      std::move(rational).value());
}

}  // namespace

TEST_CASE(
    "C16 accepted construction prerequisite may terminate only as typed Unavailable",
    "[c16][integration][negative][producer-matrix][atomicity]") {
  auto scenario = make_scenario(
      "c16.fixture.search-product", count_budget(3U, 12U, 0U));
  REQUIRE(scenario.preview.construction_prerequisites
              .required_optimizer_calls == mwperf::BigNat{3U});
  REQUIRE(scenario.preview.construction_prerequisites
              .required_search_states_per_call == mwperf::BigNat{4U});
  REQUIRE(scenario.contract.construction_prerequisites() ==
          scenario.preview.construction_prerequisites);

  auto scientific =
      mwperf::testing::c16_flow_fixture::unavailable_result(scenario.request);
  REQUIRE(scientific);
  auto* unavailable =
      std::get_if<mwperf::UnavailableSurrogateResultV1>(&scientific.value());
  REQUIRE(unavailable != nullptr);
  unavailable->reasons = {
      {mwperf::UnavailableReasonKindV1::unmet_construction_assumption,
       "c16.fixture.optimizer-domain-unavailable",
       "the accepted exact optimizer prerequisite is unavailable for this concrete instance",
       std::nullopt, std::nullopt}};

  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  const mwperf::ProviderExecutionOutcome outcome =
      mwperf::testing::c16_flow_fixture::serialized(
          std::move(scientific));
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  REQUIRE(completed != nullptr);
  auto parsed = mwperf::parse_surrogate_build_result(
      completed->bytes, parse_limits());
  REQUIRE(parsed);
  REQUIRE(std::holds_alternative<mwperf::UnavailableSurrogateResultV1>(
      parsed.value()));

  // Built-only work minima do not forge an outer transport failure or a
  // partial result when the provider truthfully terminates as Unavailable.
  auto report = mwperf::validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.budget);
  INFO((report ? std::string{} : report.error().code));
  REQUIRE(report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.manifest,
      scenario.contract, report.value());
  REQUIRE(validated);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  REQUIRE(std::holds_alternative<
          mwperf::RealizedUnavailableCapabilitiesV1>(realized));
  CHECK_FALSE(std::holds_alternative<mwperf::RealizedBuiltCapabilitiesV1>(
      realized));
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE(
    "C16 F10 enforces all common counter omissions exact limits and overruns",
    "[c16][integration][negative][producer-matrix][budget]") {
  auto scenario = make_scenario(
      "c16.fixture.search-product", count_budget(3U, 12U, 5U));
  auto exact = built_report(scenario);

  using ReportMember =
      mwperf::CommonWorkCounterV1 mwperf::CommonBuildReportV1::*;
  using GrantMember =
      mwperf::CountConstructionGrantV1 mwperf::ConstructionBudget::*;
  constexpr std::array<ReportMember, 3U> report_members{
      &mwperf::CommonBuildReportV1::optimizer_calls,
      &mwperf::CommonBuildReportV1::optimizer_search_states,
      &mwperf::CommonBuildReportV1::configured_generator_draws};
  constexpr std::array<GrantMember, 3U> grant_members{
      &mwperf::ConstructionBudget::exact_optimizer_calls,
      &mwperf::ConstructionBudget::optimizer_search_states,
      &mwperf::ConstructionBudget::configured_generator_draws};
  constexpr std::array<std::string_view, 3U> wire_names{
      "optimizer_calls", "optimizer_search_states",
      "configured_generator_draws"};

  for (std::size_t index = 0U; index < report_members.size(); ++index) {
    const auto& grant = scenario.budget.*grant_members[index];
    REQUIRE(grant.amount.has_value());
    (exact.*report_members[index]).used = *grant.amount;
  }
  reseal(exact);
  const auto exact_result = built_with_report(scenario, exact);
  REQUIRE(mwperf::validate_surrogate_build_report(
      exact_result, scenario.request, scenario.budget));

  for (std::size_t index = 0U; index < report_members.size(); ++index) {
    CAPTURE(wire_names[index]);
    auto omitted = exact;
    (omitted.*report_members[index]).applicability =
        mwperf::WorkCounterApplicabilityV1::not_applicable;
    (omitted.*report_members[index]).used = mwperf::BigNat{0U};
    reseal(omitted);
    auto omitted_validation = mwperf::validate_surrogate_build_report(
        built_with_report(scenario, omitted), scenario.request,
        scenario.budget);
    REQUIRE_FALSE(omitted_validation);
    CHECK(omitted_validation.error().code ==
          "c15.report_counter_applicability");

    auto overrun = exact;
    const auto& grant = scenario.budget.*grant_members[index];
    REQUIRE(grant.amount.has_value());
    (overrun.*report_members[index]).used =
        *grant.amount + mwperf::BigNat{1U};
    reseal(overrun);
    auto overrun_validation = mwperf::validate_surrogate_build_report(
        built_with_report(scenario, overrun), scenario.request,
        scenario.budget);
    REQUIRE_FALSE(overrun_validation);
    CHECK(overrun_validation.error().code == "c15.report_budget_exceeded");

    auto encoded =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
            exact_result);
    REQUIRE(encoded);
    Json document = Json::parse(text_of(encoded.value()));
    document.at("envelope").at("build_report")
        .erase(std::string(wire_names[index]));
    const auto omitted_bytes = bytes_of(document.dump());
    auto parse_rejection = mwperf::parse_surrogate_build_result(
        omitted_bytes, parse_limits());
    REQUIRE_FALSE(parse_rejection);
    CHECK(parse_rejection.error().code == "artifact_wire_missing_field");
  }
}

TEST_CASE(
    "C16 F10 keeps provider diagnostics optional unless the manifest requires them",
    "[c16][integration][negative][producer-matrix][budget]") {
  auto optional = make_scenario(
      "c16.fixture.mwis.sampling", count_budget(0U, 0U, 0U));
  auto optional_report = built_report(optional);
  REQUIRE(optional_report.optional_method_counters.empty());
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_with_report(optional, optional_report), optional.request,
      optional.budget));

  optional_report.optional_method_counters = {
      {"context_replays", natural(2U)},
      {"integration_evaluations", natural(3U)},
      {"refinement_rounds", natural(1U)}};
  reseal(optional_report);
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_with_report(optional, optional_report), optional.request,
      optional.budget));

  auto required = make_scenario(
      "c16.fixture.mwis.engineered", count_budget(0U, 0U, 0U));
  auto required_report = built_report(required);
  REQUIRE(required_report.optional_method_counters.size() == 1U);
  REQUIRE(required_report.optional_method_counters.front().name ==
          "integration_evaluations");
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_with_report(required, required_report), required.request,
      required.budget));

  required_report.optional_method_counters.clear();
  reseal(required_report);
  auto rejected = mwperf::validate_surrogate_build_report(
      built_with_report(required, required_report), required.request,
      required.budget);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c16.required_method_counter_missing");
}

TEST_CASE(
    "C16 completed artifact wire rejects every code-bearing field as inert unknown data",
    "[c16][negative][producer-matrix][data-only][wire]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = make_scenario(
      "c16.fixture.flow.closed-form", count_budget(0U, 0U, 0U));
  auto result = mwperf::testing::c16_flow_fixture::built_result(
      scenario.request, scenario.manifest.value());
  REQUIRE(result);
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          result.value());
  REQUIRE(encoded);
  const Json baseline = Json::parse(text_of(encoded.value()));

  const std::array hostile_fields{
      std::pair{"callback_name", "invoke_surrogate_callback"},
      std::pair{"object_code", "7f454c46"},
      std::pair{"shared_library_reference", "/tmp/provider.so"},
      std::pair{"executable_expression", "system('provider')"},
      std::pair{"source_text", "return construct_surrogate();"},
      std::pair{"bytecode", "00ff00ff"},
      std::pair{"symbol_name", "provider_entrypoint"},
      std::pair{"function_pointer", "0x1"}};
  for (const auto& [field, hostile_value] : hostile_fields) {
    CAPTURE(field);
    Json document = baseline;
    document.at("artifact").at("payload").at("body")[field] =
        hostile_value;
    const auto hostile_bytes = bytes_of(document.dump());
    auto rejected = mwperf::parse_surrogate_build_result(
        hostile_bytes, parse_limits());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "artifact_wire_closed_object");
    CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
              std::memory_order_relaxed) == 0U);
  }
}
