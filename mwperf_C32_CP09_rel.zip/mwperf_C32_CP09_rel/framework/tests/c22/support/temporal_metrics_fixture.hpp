#pragma once

#if !defined(MWPERF_C22_TEST_SEAMS)
#error "temporal_metrics_fixture.hpp is available only to C22 tests"
#endif

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/temporal.hpp"

namespace mwperf::testing::c22 {

inline const CodecIdentityV1 kStateCodec{"c22.fixture.state", 1U};

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline Digest256 digest(const std::string_view text) {
  auto result = sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline ReducedStateV1 state(const std::uint8_t value) {
  return {kStateCodec, {static_cast<std::byte>(value)}};
}

[[nodiscard]] inline RuntimeMarkIdV1 runtime_mark_id(
    const std::string_view value) {
  auto label = TypedLabel::text(std::string(value));
  REQUIRE(label);
  return RuntimeMarkIdV1(std::move(label).value());
}

[[nodiscard]] inline CausalMarkV1 runtime_mark(
    const RuntimeMarkIdV1& id, CodecIdentityV1 codec,
    std::vector<std::byte> canonical_value) {
  return {{id, {std::move(codec), std::move(canonical_value)}},
          CausalStageV1::psi};
}

[[nodiscard]] inline ArrivalPhaseIdentityV1 phase(
    const std::uint8_t value = 0U) {
  return {ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] inline MarkedFluxEdgeV1 edge(
    const ReducedStateV1& before, const ReducedStateV1& after,
    const std::uint64_t backlog, const std::uint8_t departure,
    const std::uint64_t arrival = 0U) {
  return {before,
          after,
          {BigNat{backlog}},
          {departure},
          {BigNat{arrival}},
          phase(),
          phase(),
          {}};
}

[[nodiscard]] inline C22SyntheticTransitionV1 transition(
    const std::size_t successor, const ReducedStateV1& before,
    const ReducedStateV1& after, const std::uint64_t backlog,
    const std::uint8_t departure, const ExactRational& mass,
    const std::uint64_t arrival = 0U) {
  return {successor, edge(before, after, backlog, departure, arrival), mass};
}

[[nodiscard]] inline C22SyntheticSourceIdentityV1 identity(
    const std::string_view name, const bool projection_bound = false) {
  const auto tagged = [name](const std::string_view role) {
    return digest(std::string(name) + "." + std::string(role));
  };
  return {tagged("source"),
          projection_bound
              ? std::optional<Digest256>{tagged("projection")}
              : std::nullopt,
          tagged("contract"),
          tagged("requirements"),
          tagged("analysis"),
          tagged("instance"),
          tagged("targets"),
          tagged("arrival"),
          tagged("selection"),
          tagged("exact-state"),
          tagged("reduced-state"),
          tagged("marks"),
          tagged("continuation"),
          tagged("target-service"),
          tagged("timing"),
          kStateCodec};
}

template <typename T>
[[nodiscard]] inline T require_value(Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline C22SyntheticViewsV1 mint_stationary(
    const std::string_view name, std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    const std::size_t maximum_state_offset = 32U,
    const std::size_t maximum_edge_offset = 32U,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations = {}) {
  return require_value(C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::stationary, identity(name, true), std::move(nodes),
      std::move(entrance), maximum_state_offset, maximum_edge_offset,
      std::move(f05_authorizations)));
}

[[nodiscard]] inline C22SyntheticViewsV1 mint_framework_v0(
    const std::string_view name, std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    const std::size_t maximum_state_offset = 32U,
    const std::size_t maximum_edge_offset = 32U,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations = {}) {
  return require_value(C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::framework_v0,
      std::nullopt, identity(name, false), std::move(nodes),
      std::move(entrance), maximum_state_offset, maximum_edge_offset,
      std::move(f05_authorizations)));
}

[[nodiscard]] inline C22SyntheticViewsV1 mint_event_entrance(
    const std::string_view name, std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance) {
  return require_value(C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::event_palm, identity(name, true), std::move(nodes),
      std::move(entrance), 32U, 32U));
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
service_persistence_authorization(const std::size_t target = 0U) {
  return {MetricKindV1::service_persistence, target,
          ServicePersistenceParametersV1{}};
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
service_autocovariance_authorization(std::vector<BigNat> lags,
                                     const std::size_t target = 0U) {
  return {MetricKindV1::service_autocovariance, target,
          ServiceAutocovarianceParametersV1{std::move(lags)}};
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
service_window_authorization(const BigNat& width,
                             const std::size_t target = 0U) {
  return {MetricKindV1::service_window_count, target,
          ServiceWindowCountParametersV1{width}};
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
service_spectrum_authorization(
    std::vector<ExactRational> frequencies, const BigNat& truncation_lag,
    const std::size_t target = 0U) {
  return {MetricKindV1::service_spectrum, target,
          ServiceSpectrumParametersV1{
              std::move(frequencies), truncation_lag,
              SpectrumWindowV1::rectangular_truncation}};
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
mean_event_gap_authorization(const GapEventKind event,
                             const std::size_t target = 0U) {
  return {MetricKindV1::mean_event_gap, target,
          MeanEventGapParametersV1{event}};
}

[[nodiscard]] inline C22SyntheticF05AuthorizationV1
mean_binary_run_authorization(BinaryPredicateV1 predicate,
                              const std::size_t target = 0U) {
  return {MetricKindV1::mean_binary_run, target,
          MeanBinaryRunParametersV1{std::move(predicate)}};
}

[[nodiscard]] inline C22SyntheticViewsV1 alternator(
    const std::string_view name = "c22.alternator") {
  const auto zero = state(0U);
  const auto one = state(1U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {zero, {transition(1U, zero, one, 0U, 0U, ExactRational::one())},
       0U});
  nodes.push_back(
      {one, {transition(0U, one, zero, 1U, 1U, ExactRational::one())},
       0U});
  return mint_stationary(name, std::move(nodes),
                         {{0U, rational(1, 2)}, {1U, rational(1, 2)}},
                         32U, 32U,
                         {service_persistence_authorization(),
                          service_autocovariance_authorization({BigNat{2U}}),
                          mean_event_gap_authorization(
                              GapEventKind::departure),
                          service_spectrum_authorization(
                              {ExactRational::zero()}, BigNat{2U})});
}

[[nodiscard]] inline C22SyntheticViewsV1 framework_alternator(
    const std::string_view name = "c22.framework-alternator") {
  const auto zero = state(0U);
  const auto one = state(1U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {zero, {transition(1U, zero, one, 0U, 0U, ExactRational::one())},
       0U});
  nodes.push_back(
      {one, {transition(0U, one, zero, 1U, 1U, ExactRational::one())},
       0U});
  return mint_framework_v0(name, std::move(nodes),
                           {{0U, rational(1, 2)},
                            {1U, rational(1, 2)}},
                           32U, 32U,
                           {service_autocovariance_authorization(
                               {BigNat{2U}})});
}

[[nodiscard]] inline C22SyntheticViewsV1 alternator_event_palm(
    const std::string_view name = "c22.alternator-event-palm") {
  const auto zero = state(0U);
  const auto one = state(1U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {zero, {transition(1U, zero, one, 0U, 0U, ExactRational::one())},
       0U});
  nodes.push_back(
      {one, {transition(0U, one, zero, 1U, 1U, ExactRational::one())},
       0U});
  // A departure occurs on one -> zero, so the event-Palm post-event entrance
  // is state zero.  C22 receives this already tilted entrance; this fixture
  // performs no C23 Palm construction.
  return mint_event_entrance(name, std::move(nodes),
                             {{0U, ExactRational::one()}});
}

[[nodiscard]] inline C22SyntheticViewsV1 iid_bernoulli_third(
    const std::string_view name = "c22.iid-third") {
  const auto only = state(0U);
  std::vector<C22SyntheticTransitionV1> row;
  row.push_back(transition(0U, only, only, 1U, 0U, rational(2, 3)));
  row.push_back(transition(0U, only, only, 1U, 1U, rational(1, 3)));
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back({only, std::move(row), 0U});
  return mint_stationary(name, std::move(nodes),
                         {{0U, ExactRational::one()}}, 32U, 32U,
                         {service_window_authorization(BigNat{3U}),
                          service_autocovariance_authorization(
                              {BigNat{1U}, BigNat{2U}, BigNat{5U}}),
                          service_spectrum_authorization(
                              {rational(1, 1), ExactRational::zero(),
                               rational(1, 2)},
                              BigNat{2U})});
}

[[nodiscard]] inline C22SyntheticViewsV1 analytic_three_quarter_self_loop(
    const std::string_view name, const ExactRational& error_lower,
    const ExactRational& error_upper) {
  const auto only = state(0U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {only,
       {transition(0U, only, only, 1U, 0U, rational(3, 4))},
       std::nullopt});
  return require_value(C22FixtureAccess::mint_analytic_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::event_palm, identity(name, true), std::move(nodes),
      {{0U, ExactRational::one()}}, {{error_lower, error_upper}}, 8U, 8U));
}

[[nodiscard]] inline C22SyntheticViewsV1 active_component_mixture(
    const std::string_view name = "c22.active-mixture") {
  const auto active_zero = state(0U);
  const auto active_one = state(1U);
  const auto inactive = state(2U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back({active_zero,
                   {transition(1U, active_zero, active_one, 0U, 0U,
                               ExactRational::one())},
                   0U});
  nodes.push_back({active_one,
                   {transition(0U, active_one, active_zero, 1U, 1U,
                               ExactRational::one())},
                   0U});
  nodes.push_back({inactive,
                   {transition(2U, inactive, inactive, 0U, 0U,
                               ExactRational::one())},
                   1U});
  return mint_stationary(
      name, std::move(nodes),
      {{0U, rational(1, 8)}, {1U, rational(1, 8)},
       {2U, rational(3, 4)}},
      32U, 32U,
      {mean_event_gap_authorization(GapEventKind::departure)});
}

[[nodiscard]] inline C22SyntheticViewsV1
merged_label_active_component_mixture(
    const std::string_view name = "c22.active-mixture-merged-label") {
  const auto active_zero = state(0U);
  const auto active_one = state(1U);
  const auto inactive = state(2U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back({active_zero,
                   {transition(1U, active_zero, active_one, 0U, 0U,
                               ExactRational::one())},
                   0U});
  nodes.push_back({active_one,
                   {transition(0U, active_one, active_zero, 1U, 1U,
                               ExactRational::one())},
                   0U});
  // This advisory label deliberately merges a distinct inactive closed SCC
  // with the active alternator.  C22 must derive exact support SCCs rather
  // than use the label to inflate the active-component numerator.
  nodes.push_back({inactive,
                   {transition(2U, inactive, inactive, 0U, 0U,
                               ExactRational::one())},
                   0U});
  return mint_stationary(
      name, std::move(nodes),
      {{0U, rational(1, 8)}, {1U, rational(1, 8)},
       {2U, rational(3, 4)}},
      32U, 32U,
      {mean_event_gap_authorization(GapEventKind::departure)});
}

[[nodiscard]] inline C22SyntheticViewsV1 finite_start_run_mixture(
    const std::string_view name = "c22.run-mixture") {
  const auto all_one = state(0U);
  const auto alternating_zero = state(1U);
  const auto alternating_one = state(2U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back({all_one,
                   {transition(0U, all_one, all_one, 1U, 1U,
                               ExactRational::one())},
                   0U});
  nodes.push_back({alternating_zero,
                   {transition(2U, alternating_zero, alternating_one, 0U, 0U,
                               ExactRational::one())},
                   1U});
  nodes.push_back({alternating_one,
                   {transition(1U, alternating_one, alternating_zero, 1U, 1U,
                               ExactRational::one())},
                   1U});
  return mint_stationary(
      name, std::move(nodes),
      {{0U, rational(1, 2)}, {1U, rational(1, 4)},
       {2U, rational(1, 4)}},
      32U, 32U,
      {mean_binary_run_authorization(BasicBinaryPredicateV1::busy)});
}

[[nodiscard]] inline C22SyntheticViewsV1 exact_killed_chain(
    const std::string_view name = "c22.killed") {
  const auto zero = state(0U);
  const auto one = state(1U);
  const auto hit = state(2U);
  const auto kill = state(3U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {zero,
       {transition(0U, zero, zero, 0U, 0U, rational(1, 2)),
        transition(1U, zero, one, 0U, 0U, rational(1, 4)),
        transition(2U, zero, hit, 0U, 0U, rational(1, 8)),
        transition(3U, zero, kill, 0U, 0U, rational(1, 8))},
       std::nullopt});
  nodes.push_back(
      {one,
       {transition(1U, one, one, 0U, 0U, rational(1, 2)),
        transition(2U, one, hit, 0U, 0U, rational(3, 8)),
        transition(3U, one, kill, 0U, 0U, rational(1, 8))},
       std::nullopt});
  nodes.push_back(
      {hit,
       {transition(2U, hit, hit, 1U, 0U, ExactRational::one())},
       std::nullopt});
  nodes.push_back(
      {kill,
       {transition(3U, kill, kill, 2U, 0U, ExactRational::one())},
       std::nullopt});
  return mint_event_entrance(name, std::move(nodes),
                             {{0U, ExactRational::one()}});
}

[[nodiscard]] inline C22SyntheticViewsV1 defective_killed_chain(
    const std::string_view name = "c22.defective") {
  const auto initial = state(0U);
  const auto trap = state(1U);
  const auto hit = state(2U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {initial,
       {transition(1U, initial, trap, 0U, 0U, rational(1, 2)),
        transition(2U, initial, hit, 0U, 0U, rational(1, 2))},
       std::nullopt});
  nodes.push_back(
      {trap,
       {transition(1U, trap, trap, 0U, 0U, ExactRational::one())},
       std::nullopt});
  nodes.push_back(
      {hit,
       {transition(2U, hit, hit, 1U, 0U, ExactRational::one())},
       std::nullopt});
  return mint_event_entrance(name, std::move(nodes),
                             {{0U, ExactRational::one()}});
}

// The entrance deliberately lives on the already-absorbed node.  The source
// itself and its rows are valid, so the stopped evaluator (not the mint) must
// reject this law before performing a recursion.
[[nodiscard]] inline C22SyntheticViewsV1 unsafe_hit_entrance_chain(
    const std::string_view name = "c22.unsafe-entrance") {
  const auto safe = state(0U);
  const auto hit = state(1U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {safe,
       {transition(0U, safe, safe, 0U, 0U, rational(1, 2)),
        transition(1U, safe, hit, 0U, 0U, rational(1, 2))},
       std::nullopt});
  nodes.push_back(
      {hit,
       {transition(1U, hit, hit, 1U, 0U, ExactRational::one())},
       std::nullopt});
  return mint_event_entrance(name, std::move(nodes),
                             {{1U, ExactRational::one()}});
}

[[nodiscard]] inline BinaryMark departure_mark() {
  return {BinaryMarkKindV1::target_departure, 0U, std::nullopt};
}

[[nodiscard]] inline BinaryMark busy_state_mark() {
  return {BinaryMarkKindV1::state_predicate, 0U,
          BinaryStatePredicateV1{0U, BasicBinaryPredicateV1::busy}};
}

[[nodiscard]] inline SafeSet zero_backlog_safe_set() {
  return {{TargetBacklogPredicateV1{0U, BacklogRelationV1::equal,
                                    BigNat{0U}}}};
}

[[nodiscard]] inline TypedAbsorptionMarkV1 backlog_exit(
    std::string type_id, const std::uint64_t level) {
  return {std::move(type_id),
          TargetBacklogPredicateV1{0U, BacklogRelationV1::equal,
                                   BigNat{level}},
          AnyEdgePredicateV1{}};
}

[[nodiscard]] inline SolverPolicy solver_policy(
    const std::string_view source_name = "c22.killed") {
  return {LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000000LL), ExactRational::zero(),
          digest(std::string(source_name) + ".analysis")};
}

}  // namespace mwperf::testing::c22
