#pragma once

#if !defined(MWPERF_C22_TEST_SEAMS)
#error "integration_temporal_contract_fixture.hpp is available only to C22 tests"
#endif

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/metrics/temporal.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing::c22_integration {

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

template <typename T>
[[nodiscard]] inline T require_value(Result<T> value) {
  INFO((value ? std::string{}
              : value.error().code + ": " + value.error().message));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline C22SyntheticSourceIdentityV1 identity(
    const std::string_view name) {
  const auto tagged = [name](const std::string_view role) {
    return c17::digest(std::string(name) + "." + std::string(role));
  };
  return {tagged("source"),
          tagged("projection"),
          tagged("contract"),
          tagged("requirements"),
          tagged("analysis"),
          tagged("instance"),
          tagged("targets"),
          tagged("arrival"),
          tagged("selection"),
          tagged("exact-state-schema"),
          tagged("reduced-state-schema"),
          tagged("mark-schema"),
          tagged("continuation-schema"),
          tagged("service-schema"),
          tagged("timing"),
          {"mwperf.c22.integration.state", 1U}};
}

[[nodiscard]] inline ReducedStateV1 state(const std::uint8_t value) {
  return {{"mwperf.c22.integration.state", 1U},
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] inline ArrivalPhaseIdentityV1 phase(
    const std::uint8_t value) {
  return {ArrivalFamily::deterministic_trace,
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] inline MarkedFluxEdgeV1 edge(
    const ReducedStateV1& pre_state, const ReducedStateV1& successor_state,
    const std::uint8_t departure = 0U) {
  return {pre_state,
          successor_state,
          {BigNat{1U}},
          {departure},
          {BigNat{0U}},
          phase(std::to_integer<std::uint8_t>(
              pre_state.canonical_value.front())),
          phase(std::to_integer<std::uint8_t>(
              successor_state.canonical_value.front())),
          {}};
}

// A normalized two-state law entered in state 0.  State 0 exits to state 1
// on the first edge and state 1 is a closed continuation state.  The source
// remains a complete stochastic law; killing is applied only by F-C22-02.
[[nodiscard]] inline C22SyntheticViewsV1 one_step_exit_source(
    const AuditedTemporalSourceKindV1 source_kind,
    const InitialLawKindV1 entrance_kind, const std::string_view name,
    const std::size_t entrance_index = 0U) {
  const ReducedStateV1 safe = state(0U);
  const ReducedStateV1 absorbed = state(1U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back({safe,
                   {{1U, edge(safe, absorbed, 1U),
                     ExactRational::one()}},
                   std::nullopt});
  nodes.push_back({absorbed,
                   {{1U, edge(absorbed, absorbed, 0U),
                     ExactRational::one()}},
                   std::nullopt});
  return require_value(C22FixtureAccess::mint_exact_source(
      source_kind, entrance_kind, identity(name), std::move(nodes),
      {{entrance_index, ExactRational::one()}}, 8U, 8U));
}

[[nodiscard]] inline C22SyntheticViewsV1 iid_departure_source(
    const std::string_view name, const std::size_t maximum_edge_offset) {
  const ReducedStateV1 only = state(0U);
  std::vector<C22SyntheticNodeV1> nodes;
  nodes.push_back(
      {only,
       {{0U, edge(only, only, 0U), rational(1, 2)},
        {0U, edge(only, only, 1U), rational(1, 2)}},
       0U});
  return require_value(C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::stationary, identity(name), std::move(nodes),
      {{0U, ExactRational::one()}}, maximum_edge_offset,
      maximum_edge_offset,
      {{MetricKindV1::service_spectrum, 0U,
        ServiceSpectrumParametersV1{
            {ExactRational::zero(), rational(1, 2)}, BigNat{3U},
            SpectrumWindowV1::rectangular_truncation}},
       {MetricKindV1::service_spectrum, 0U,
        ServiceSpectrumParametersV1{
            {ExactRational::zero(), rational(1, 2)}, BigNat{4U},
            SpectrumWindowV1::rectangular_truncation}}}));
}

[[nodiscard]] inline SafeSet safe_state_zero() {
  return {ExactStatePredicateV1{state(0U)}};
}

[[nodiscard]] inline AbsorptionMarks hit_state_one() {
  return {{{"hit", ExactStatePredicateV1{state(1U)},
            AnyEdgePredicateV1{}}}};
}

[[nodiscard]] inline SolverPolicy solver_policy(
    const std::string_view source_name) {
  return {LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000LL), ExactRational::zero(),
          c17::digest(std::string(source_name) + ".analysis")};
}

}  // namespace mwperf::testing::c22_integration
