#pragma once

#if !defined(MWPERF_C22_TEST_SEAMS)
#error "transient_dispatch_fixture.hpp is available only to C22 tests"
#endif

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "fixtures/c20/enumerable_four_word_fixture.hpp"
#include "mwperf/metrics/temporal.hpp"

namespace mwperf::testing::c22_transient {

namespace temporal_fixture = c17_temporal;
namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

enum class PredictivePhaseV1 : std::uint8_t {
  target_arrival_then_quiet = 0U,
  other_queue_only = 1U,
};

enum class TransientRequestV1 : std::uint8_t {
  backlog_law,
  first_hit,
  threshold_excursion,
};

enum class TargetQueueV1 : std::uint8_t {
  first,
  second,
};

inline constexpr std::size_t kBacklogOffset = 0U;
inline constexpr std::size_t kPhaseOffset = 1U;
inline constexpr std::size_t kBoundaryOffset = 2U;
inline constexpr std::size_t kAgeOffset = 3U;
inline constexpr std::size_t kStateSize = 4U;

inline const CodecIdentityV1 kAgeCodec{
    // This transient state realizes the surrogate-owned field and edge mark
    // declared by the inherited C20 reset-ROMR contract.  The codec identity
    // must therefore remain exactly that contract's identity.
    "c20.fixture.residence-age", 1U};

[[nodiscard]] inline RuntimeFieldIdV1 age_field() {
  return RuntimeFieldIdV1(designated::label("field.2"));
}

[[nodiscard]] inline RuntimeMarkIdV1 age_mark() {
  // active_component sorts before the entrance phase label.
  return RuntimeMarkIdV1(designated::label("mark.0"));
}

[[nodiscard]] inline RuntimeDecoderIdV1 age_decoder() {
  return RuntimeDecoderIdV1(designated::label("decoder.0"));
}

[[nodiscard]] inline ReducedStateV1 state(
    const std::uint8_t backlog, const PredictivePhaseV1 phase,
    const std::uint8_t boundary = 0U,
    const std::uint8_t age = 0U) {
  return {c17::kReducedStateCodec,
          {static_cast<std::byte>(backlog),
           static_cast<std::byte>(phase), static_cast<std::byte>(boundary),
           static_cast<std::byte>(age)}};
}

[[nodiscard]] inline std::string analysis_text(
    const PredictivePhaseV1 phase, const TransientRequestV1 request,
    const bool omit_predictive_phase = false,
    const std::string_view provider_id =
        matrix::kC20ResetRomrProfile.provider_id,
    const bool sampler_solver = false,
    const TargetQueueV1 target_queue = TargetQueueV1::first,
    const std::uint8_t initial_target_backlog = 0U,
    const std::size_t maximum_states = 64U) {
  std::string metric;
  switch (request) {
    case TransientRequestV1::backlog_law:
      metric = R"json({"id":"c22-transient-law","kind":"transient_backlog_law","parameters":{"horizons":[3,0,1]}})json";
      break;
    case TransientRequestV1::first_hit:
      metric = R"json({"id":"c22-first-hit","kind":"first_hit","parameters":{"set":{"kind":"at_or_above","level":1},"horizon":2,"include_mean":false}})json";
      break;
    case TransientRequestV1::threshold_excursion:
      metric = R"json({"id":"c22-threshold-return","kind":"threshold_excursion","parameters":{"set":{"kind":"at_or_above","level":1},"horizon":2,"include_mean":false}})json";
      break;
  }
  // The registered reset-ROMR provider is scoped to q0. The target_queue
  // selector changes q0's physical placement in the model below; it never
  // changes the identity of the deployed target.
  static_cast<void>(target_queue);
  const std::string target = "q0";
  const std::string q0_backlog = std::to_string(initial_target_backlog);
  const std::string q1_backlog = "0";
  const std::string arrival_state = omit_predictive_phase
      ? std::string{}
      : std::string{R"json(,"arrival_state":{"kind":"shared_round_state","state":")json"} +
            (phase == PredictivePhaseV1::target_arrival_then_quiet
                 ? "h0"
                 : "h1") +
            R"json("})json";
  const std::string solver =
      sampler_solver
          ? R"json({"kind":"monte_carlo","parameters":{"replications":64,"confidence_level":0.95,"interval_method":"hoeffding"}})json"
          : R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})json";
  return std::string{R"json({
    "analysis_schema_version":"1.0.0",
    "targets":[")json" + target + R"json("],
    "metrics":[)json"} + metric + R"json(],
    "surrogate":{"id":")json" +
         std::string(provider_id) +
         R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":)json" + std::to_string(maximum_states) + R"json(,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":4096},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{
      "atoms":[{"probability":1,
                 "backlog":[{"queue_id":"q0","value":)json" + q0_backlog + R"json(},
                            {"queue_id":"q1","value":)json" + q1_backlog + R"json(},
                            {"queue_id":"q2","value":0}],
                 "controller_state":{})json" +
         arrival_state + R"json(,
                 "static_context":{},"surrogate_initial":{}}]}}},
    "solver":)json" + solver + R"json(
  })json";
}

[[nodiscard]] inline designated::InputV1 input(
    const PredictivePhaseV1 phase, const TransientRequestV1 request,
    const matrix::ProfileV1& profile = matrix::kC20ResetRomrProfile,
    const bool sampler_solver = false,
    const TargetQueueV1 target_queue = TargetQueueV1::first,
    const std::uint8_t initial_target_backlog = 0U,
    const std::size_t maximum_states = 64U) {
  static constexpr std::string_view model_first = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":22,"slots":2,"warmup_slots":1,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{
      "family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s"}],
      "states":["h0","h1"],
      "initial":{"distribution":[{"state":"h0","probability":0.5},
                                    {"state":"h1","probability":0.5}]},
      "outcomes":[
        {"state":"h0","next_state":"h1","probability":1,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
        {"state":"h1","next_state":"h1","probability":1,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]}
      ],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view model_nonfirst = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":22,"slots":2,"warmup_slots":1,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q1"},{"id":"q0"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{
      "family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s"}],
      "states":["h0","h1"],
      "initial":{"distribution":[{"state":"h0","probability":0.5},
                                    {"state":"h1","probability":0.5}]},
      "outcomes":[
        {"state":"h0","next_state":"h1","probability":1,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]},
        {"state":"h1","next_state":"h1","probability":1,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]}
      ],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string_view model =
      target_queue == TargetQueueV1::first ? model_first : model_nonfirst;

  auto model_document =
      load_document(designated::write_input("c22-transient-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(designated::write_input(
      "c22-transient-analysis",
      analysis_text(phase, request, false, profile.provider_id,
                    sampler_solver, target_queue, initial_target_backlog,
                    maximum_states)));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  INFO((authored_analysis
            ? std::string{}
            : authored_analysis.error().code + ": " +
                  authored_analysis.error().message));
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  INFO((instance ? std::string{}
                 : instance.error().code + ": " + instance.error().message));
  REQUIRE(instance);
  auto fixture_law = make_c09_phase_selective_transient_fixture_law(
      instance.value().queues());
  INFO((fixture_law ? std::string{}
                    : fixture_law.error().code + ": " +
                          fixture_law.error().message));
  REQUIRE(fixture_law);
  auto arrival = std::make_shared<const CompiledArrivalLaw>(
      std::move(fixture_law).value());
  auto rebound = C20ArrivalFixtureAccess::bind(instance.value(), arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  auto metric = parse_metric_request(
      rebound.value().analysis_spec().metrics.front(),
      rebound.value().queues());
  REQUIRE(metric);
  std::vector<MetricRequest> requests{metric.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(rebound).value(), std::move(arrival),
          std::move(requirements), std::move(metric).value()};
}

[[nodiscard]] inline ExactReducedStateSchemaV1 state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const CompiledArrivalLaw& configured_arrival) {
  REQUIRE(ordered_targets.size() == 1U);
  std::vector<QueueId> targets(ordered_targets.begin(),
                               ordered_targets.end());
  auto prototype = TargetBacklogV1::from_values(
      instance, targets, std::vector<BigNat>{BigNat{0U}});
  REQUIRE(prototype);
  auto phase_zero = make_c09_fixture_phase_for_testing(
      configured_arrival, 0U, BigNat{0U});
  auto phase_one = make_c09_fixture_phase_for_testing(
      configured_arrival, 1U, BigNat{0U});
  REQUIRE(phase_zero);
  REQUIRE(phase_one);
  auto phases = std::make_shared<const std::vector<ArrivalPhase>>(
      std::vector<ArrivalPhase>{std::move(phase_zero).value(),
                                std::move(phase_one).value()});
  const RuntimeFieldIdV1 local_age = age_field();
  const RuntimeMarkIdV1 local_mark = age_mark();

  return {
      c17::kReducedStateCodec,
      c17::digest("c22.fixture.transient.exact-state-schema.v2-clockful"),
      c17::digest("c22.fixture.transient.reduced-state-schema.v2-clockful"),
      c17::digest("c22.fixture.transient.ownership-schema.v2-clockful"),
      c17::digest("c22.fixture.transient.exact-update-schema.v2-clockful"),
      [prototype = std::move(prototype).value(), phases, local_age](
          const ReducedStateV1& input)
          -> Result<ExactReducedCoordinatesV1> {
        if (input.codec != c17::kReducedStateCodec ||
            input.canonical_value.size() != kStateSize) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c22.fixture.transient_state_shape",
              "the transient fixture state has a foreign shape");
        }
        const auto phase = std::to_integer<std::uint8_t>(
            input.canonical_value[kPhaseOffset]);
        const auto boundary = std::to_integer<std::uint8_t>(
            input.canonical_value[kBoundaryOffset]);
        if (phase > 1U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c22.fixture.transient_phase",
              "the transient fixture phase is outside its finite domain");
        }
        auto backlog = prototype.with_values({BigNat{
            std::to_integer<std::uint8_t>(
                input.canonical_value[kBacklogOffset])}});
        if (!backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(backlog.error());
        }
        auto anchored = reanchor_c09_fixture_phase_for_testing(
            (*phases)[phase], BigNat{boundary});
        if (!anchored) {
          return Result<ExactReducedCoordinatesV1>::failure(
              anchored.error());
        }
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(backlog).value(), std::move(anchored).value(),
             BigNat{boundary},
             std::nullopt, {}, std::nullopt,
             {{local_age,
               {kAgeCodec, {input.canonical_value[kAgeOffset]}}}}});
      },
      [phases, local_age](
          const ExactReducedCoordinatesV1& coordinates,
          const UnresolvedPatch& patch) -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != 1U ||
            coordinates.resources.has_value() ||
            coordinates.controller.has_value() ||
            !coordinates.margins.empty() ||
            coordinates.unresolved_fields.size() != 1U ||
            coordinates.unresolved_fields.front().field != local_age ||
            coordinates.unresolved_fields.front().value.codec != kAgeCodec ||
            coordinates.unresolved_fields.front().value.canonical_value.size() !=
                1U ||
            coordinates.backlog.value_at_target_ordinal(0U).bit_length() >
                8U || coordinates.boundary_index.bit_length() > 8U) {
          return c17::failure<ReducedStateV1>(
              "c22.fixture.transient_rebuild_shape",
              "the transient fixture rebuild received a foreign coordinate");
        }
        const auto canonical =
            arrival_phase_canonical_state(coordinates.arrival_phase);
        if (arrival_phase_family(coordinates.arrival_phase) !=
                ArrivalFamily::shared_joint_round_markov_renewal ||
            canonical.size() != 1U ||
            (canonical.front() != std::byte{0U} &&
             canonical.front() != std::byte{1U})) {
          return c17::failure<ReducedStateV1>(
              "c22.fixture.transient_rebuild_phase",
              "the transient fixture rebuild received a foreign predictive phase");
        }
        const std::uint8_t phase =
            std::to_integer<std::uint8_t>(canonical.front());
        auto expected = reanchor_c09_fixture_phase_for_testing(
            (*phases)[phase], coordinates.boundary_index);
        if (!expected ||
            !c17::same_phase(expected.value(), coordinates.arrival_phase)) {
          return c17::failure<ReducedStateV1>(
              "c22.fixture.transient_phase_binding",
              "the predictive phase does not belong to the configured arrival law");
        }
        CanonicalRuntimeValueV1 age =
            coordinates.unresolved_fields.front().value;
        for (const RuntimeFieldPatchV1& update : patch.fields()) {
          if (update.field != local_age || update.value.codec != kAgeCodec ||
              update.value.canonical_value.size() != 1U) {
            return c17::failure<ReducedStateV1>(
                "c22.fixture.transient_patch_shape",
                "the transient fixture received a foreign unresolved patch");
          }
          age = update.value;
        }
        return Result<ReducedStateV1>::success(
            {c17::kReducedStateCodec,
             {static_cast<std::byte>(
                  coordinates.backlog.value_at_target_ordinal(0U)
                      .value().convert_to<std::uint8_t>()),
              static_cast<std::byte>(phase),
              static_cast<std::byte>(
                  coordinates.boundary_index.value().convert_to<std::uint8_t>()),
              age.canonical_value.front()}});
      },
      [](const ReducedStateV1& input) {
        if (input.codec != c17::kReducedStateCodec ||
            input.canonical_value.size() != kStateSize ||
            std::to_integer<std::uint8_t>(
                input.canonical_value[kPhaseOffset]) > 1U) {
          return c17::failure<void>(
              "c22.fixture.transient_state_domain",
              "the state is outside the finite transient fixture domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {{{age_decoder(), local_mark,
         MarkDecoderSourceV1::completed_edge,
         {"c17.fixture.temporal.completed-edge-projection", 1U},
         kAgeCodec}},
       [local_age, local_mark](
           const ExactReducedCoordinatesV1&,
           const ExactReducedCoordinatesV1& after,
           const OpportunityMark&, const ResolvedAction&,
           const ArrivalTransition&, const PostClosure&)
           -> Result<std::vector<RuntimeDecodedMarkV1>> {
         const auto age = std::ranges::find_if(
             after.unresolved_fields,
             [&](const RuntimeFieldPatchV1& value) {
               return value.field == local_age;
             });
         if (age == after.unresolved_fields.end()) {
           return c17::failure<std::vector<RuntimeDecodedMarkV1>>(
               "c22.fixture.transient_age_missing",
               "the completed edge omitted its retained residence age");
         }
         return Result<std::vector<RuntimeDecodedMarkV1>>::success(
             {{local_mark, age->value}});
       }}};
}

[[nodiscard]] inline matrix::C17TemporalFixtureOverrideV1 operation_override(
    std::shared_ptr<std::atomic<unsigned>> sampler_calls = nullptr) {
  matrix::C17TemporalFixtureOverrideV1 result;
  result.maximum_residence_slots = 1U;
  result.residence_local_reset_fields = {age_field()};

  const QueueId target = designated::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto c_minus = [target, opportunity_codec](const CMinusInputV1&)
      -> Result<CMinusOutputV1> {
    return Result<CMinusOutputV1>::success(
        {{opportunity_codec, {std::byte{0x00}}}, {},
         V0EmittedOpportunityFaceV1{
             {{{}, {}, ExactRational::one()},
              {{target}, {}, ExactRational::zero()}}},
         std::nullopt});
  };
  result.c_minus = [c_minus](const CMinusInputV1& input,
                             DeterministicRng&) { return c_minus(input); };
  result.enumerate_c_minus = [c_minus](const CMinusInputV1& input) {
    auto value = c_minus(input);
    if (!value) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          value.error());
    }
    auto mass = ProbabilityMass::exact_rational(
        ExactRational::one(), true);
    REQUIRE(mass);
    return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
        {{std::move(value).value(), std::move(mass).value()}});
  };
  result.entry_initializer = [](const CanonicalRuntimeValueV1& input) {
    if (input.codec != c17::kReducedStateCodec ||
        input.canonical_value.size() != kStateSize) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c22.fixture.transient_entry_shape",
          "the transient entry initializer received a foreign state");
    }
    CanonicalRuntimeValueV1 output = input;
    output.canonical_value[kAgeOffset] = std::byte{0U};
    return Result<CanonicalRuntimeValueV1>::success(std::move(output));
  };
  result.stopping_indicator = [](const CanonicalRuntimeValueV1&) {
    return Result<CanonicalRuntimeValueV1>::success(
        {{"c17.fixture.temporal.indicator", 1U}, {std::byte{1U}}});
  };
  result.terminal_reentry = [](
      const EventTerminalReentryInputV1& input) {
    return Result<CanonicalRuntimeValueV1>::success(input.successor_state);
  };
  result.conditional_sampler_calls = std::move(sampler_calls);
  return result;
}

inline void bind_transient_seed(
    AuditedFrameworkSeedV1& seed, const PredictivePhaseV1 phase,
    const std::uint8_t initial_target_backlog = 0U,
    const TargetQueueV1 target_queue = TargetQueueV1::first) {
  const ReducedStateV1 initial = state(initial_target_backlog, phase);
  const auto state_codec = seed.reduced_state_codec;
  const auto exact_schema = seed.bindings.exact_state_schema_digest;
  const auto reduced_schema = seed.bindings.reduced_state_schema_digest;
  const auto selection = seed.bindings.selection_digest;
  const auto support = seed.selection_support;
  auto one = ProbabilityMass::exact_rational(ExactRational::one(), true);
  REQUIRE(one);

  seed.initial_selection_authority =
      {SelectionKindV1::transient_initial, std::nullopt};
  seed.initial_mapper =
      [state_codec, exact_schema, reduced_schema, selection, support, initial,
       one = std::move(one).value()](
          const SelectionSpec& selected,
          const std::optional<InitialPhysicalLaw>& physical) {
        if (!std::holds_alternative<TransientSelection>(selected) ||
            !physical.has_value() || physical->atoms().size() != 1U) {
          return c17::failure<ReducedInitialLawCandidateV1>(
              "c22.fixture.transient_initializer_required",
              "the fixture requires one complete transient physical atom");
        }
        return Result<ReducedInitialLawCandidateV1>::success(
            {state_codec, exact_schema, reduced_schema, selection, support,
             {{initial, one, 0U}}});
      };
  const auto domain = seed.reduced_state_domain_validator;
  seed.physical_atom_projection_validator =
      [domain, phase, initial_target_backlog,
       target_queue](const std::size_t ordinal,
                      const InitialPhysicalAtom& atom,
                      const ReducedStateV1& reduced) {
        auto valid = domain(reduced);
        if (!valid) {
          return valid;
        }
        const auto* shared =
            std::get_if<SharedRoundState>(&atom.arrival_state);
        const std::string_view expected =
            phase == PredictivePhaseV1::target_arrival_then_quiet
                ? "h0"
                : "h1";
        const std::size_t physical_target =
            target_queue == TargetQueueV1::first ? 0U : 1U;
        if (ordinal != 0U || shared == nullptr ||
            shared->state != expected ||
            physical_target >= atom.backlog.size() ||
            atom.backlog[physical_target] != BigNat{initial_target_backlog} ||
            reduced != state(initial_target_backlog, phase)) {
          return c17::failure<void>(
              "c22.fixture.predictive_phase_projection_mismatch",
              "the reduced entrance did not retain the complete physical "
              "backlog and predictive arrival phase");
        }
        return Result<void>::success();
      };
}

struct TransientDispatchCaseV1 final {
  temporal_fixture::GenericTemporalFrameworkV1 temporal;
  MetricRequest request;
  ReducedInitialLaw initial_law;
};

[[nodiscard]] inline TransientDispatchCaseV1 make_case(
    const PredictivePhaseV1 phase, const TransientRequestV1 request_kind,
    const matrix::ProfileV1& profile = matrix::kC20ResetRomrProfile,
    const bool sampler_solver = false,
    std::shared_ptr<std::atomic<unsigned>> sampler_calls = nullptr,
    const TargetQueueV1 target_queue = TargetQueueV1::first,
    const std::uint8_t initial_target_backlog = 0U,
    const std::size_t maximum_states = 64U) {
  matrix::C17TemporalFixtureOverrideV1 operations =
      operation_override(std::move(sampler_calls));
  matrix::ScopedC17TemporalFixtureOverride scope(operations);
  auto scenario = temporal_fixture::temporal_scenario(
      input(phase, request_kind, profile, sampler_solver, target_queue,
            initial_target_backlog, maximum_states),
      profile);
  const MetricRequest request = scenario.metric_request;
  auto prepared = temporal_fixture::
      prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          std::move(scenario),
          ArrivalInitialState{SharedRoundState{
              phase == PredictivePhaseV1::target_arrival_then_quiet
                  ? "h0"
                  : "h1"}},
          std::nullopt, [](PlugDescriptor&) {},
          [](const ResolvedInstance& instance,
             const std::span<const QueueId> targets,
             const CompiledArrivalLaw& arrival, const ArrivalPhase&,
             const ArrivalPhase&) {
            return state_schema(instance, targets, arrival);
          },
          [phase, initial_target_backlog](const std::span<const QueueId>,
                                          const ExactReducedStateSchemaV1&) {
            return state(initial_target_backlog, phase);
          },
          [](ExactCausalProgramV1& program) {
            std::vector<ReducedStateV1> domain;
            for (const auto phase :
                 {PredictivePhaseV1::target_arrival_then_quiet,
                  PredictivePhaseV1::other_queue_only}) {
              domain.push_back(state(0U, phase));
              domain.push_back(state(1U, phase));
            }
            program.reachable_audit_states = domain;
            program.finite_event_domain_states = std::move(domain);
            program.maximum_residence_slots = 1U;
            // These boundary-zero values are representatives of the audited
            // finite phase quotient.  Raw temporal successors retain their
            // absolute physical boundary, so this is not the full clockful
            // reduced-state domain.
            program.event_entry_domain_is_exact_state_domain = false;
            program.event_clock_semantics = EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient;
          },
          [phase, initial_target_backlog,
           target_queue](AuditedFrameworkSeedV1& seed) {
            bind_transient_seed(seed, phase, initial_target_backlog,
                                target_queue);
          });
  auto audited = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((audited ? std::string{}
                : audited.error().code + ": " + audited.error().message));
  REQUIRE(audited);
  temporal_fixture::GenericTemporalFrameworkV1 temporal{
      std::move(audited).value(), std::move(prepared.instance),
      std::move(prepared.ordered_targets), std::move(prepared.state_schema),
      std::move(prepared.descriptor), std::move(prepared.initial_state),
      std::move(prepared.entrance_mark),
      std::move(prepared.entrance_decoder_calls),
      std::move(prepared.residence_generator_calls)};
  REQUIRE(temporal.instance.initial_law().has_value());
  auto physical = detail::CompiledInitialLawAccess::get(
      *temporal.instance.initial_law());
  REQUIRE(physical);
  auto configured_arrival =
      detail::CompiledArrivalAccess::get(temporal.instance.arrival());
  REQUIRE(configured_arrival);
  CHECK(physical.value()->arrival_binding() ==
        arrival_law_binding(*configured_arrival.value()));
  auto reduced = construct_reduced_initial_law(
      temporal.instance, temporal.framework,
      temporal.instance.analysis_spec().context->selection,
      InitialPhysicalLaw{*physical.value()});
  INFO((reduced ? std::string{}
                : reduced.error().code + ": " + reduced.error().message));
  REQUIRE(reduced);
  return {std::move(temporal), request, std::move(reduced).value()};
}

[[nodiscard]] inline TransientDispatchCaseV1 backlog_case(
    const PredictivePhaseV1 phase) {
  return make_case(phase, TransientRequestV1::backlog_law);
}

[[nodiscard]] inline TransientDispatchCaseV1 first_hit_case() {
  return make_case(PredictivePhaseV1::target_arrival_then_quiet,
                   TransientRequestV1::first_hit);
}

[[nodiscard]] inline TransientDispatchCaseV1 threshold_return_case() {
  return make_case(PredictivePhaseV1::other_queue_only,
                   TransientRequestV1::threshold_excursion,
                   matrix::kC20ResetRomrProfile, false, nullptr,
                   TargetQueueV1::first, 1U);
}

[[nodiscard]] inline TransientDispatchCaseV1 nonfirst_target_case() {
  return make_case(PredictivePhaseV1::target_arrival_then_quiet,
                   TransientRequestV1::first_hit,
                   matrix::kC20ResetRomrProfile, false, nullptr,
                   TargetQueueV1::second, 0U);
}

[[nodiscard]] inline TransientDispatchCaseV1 cutoff_budget_case() {
  return make_case(PredictivePhaseV1::target_arrival_then_quiet,
                   TransientRequestV1::first_hit,
                   matrix::kC20ResetRomrProfile, false, nullptr,
                   TargetQueueV1::second, 0U, 1U);
}

class C22SamplingAdapterPoisonSpy final {
 public:
  C22SamplingAdapterPoisonSpy()
      : calls_(std::make_shared<std::atomic<unsigned>>(0U)) {}

  [[nodiscard]] std::shared_ptr<std::atomic<unsigned>> counter() const {
    return calls_;
  }

  void reset() const noexcept {
    calls_->store(0U, std::memory_order_relaxed);
  }

  [[nodiscard]] unsigned calls() const noexcept {
    return calls_->load(std::memory_order_relaxed);
  }

 private:
  std::shared_ptr<std::atomic<unsigned>> calls_;
};

[[nodiscard]] inline std::string sampler_only_error_code(
    const C22SamplingAdapterPoisonSpy& poison) {
  matrix::C17TemporalFixtureOverrideV1 operations =
      operation_override(poison.counter());
  matrix::ScopedC17TemporalFixtureOverride scope(operations);
  const matrix::ProfileV1& profile = temporal_fixture::temporal_profile(
      SemanticTagV1::temporal_one_slot_continuation);
  auto source = input(PredictivePhaseV1::target_arrival_then_quiet,
                      TransientRequestV1::backlog_law, profile, true);
  auto id = SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{}
                 : provider.error().code + ": " +
                       provider.error().message));
  REQUIRE(provider);
  const auto& header = metric_request_header(source.request);
  std::vector<QueueId> targets;
  targets.reserve(header.ordered_targets.size());
  for (const ResolvedMetricTargetV1& target : header.ordered_targets) {
    targets.push_back(target.queue_id);
  }
  const TargetSelection selection{
      1U, std::move(targets),
      ConstructionGroupIdV1(
          designated::label("c22.sampler-negative.construction-group"))};
  auto view = build_framework_problem_view(
      source.instance, *source.arrival, selection);
  REQUIRE(view);
  auto parameters = validate_surrogate_parameters(
      provider.value(), designated::parameters());
  REQUIRE(parameters);
  const auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements,
      designated::budget(), parameters.value());
  REQUIRE_FALSE(preview);
  return preview.error().code;
}

[[nodiscard]] inline std::string omitted_phase_error_code() {
  auto document = load_document(designated::write_input(
      "c22-transient-missing-phase",
      analysis_text(PredictivePhaseV1::target_arrival_then_quiet,
                    TransientRequestV1::backlog_law, true)));
  REQUIRE(document);
  auto parsed = parse_analysis_spec_v1(document.value());
  REQUIRE_FALSE(parsed);
  return parsed.error().code;
}

[[nodiscard]] inline std::string negative_horizon_error_code() {
  std::string authored = analysis_text(
      PredictivePhaseV1::target_arrival_then_quiet,
      TransientRequestV1::first_hit);
  const std::string positive = R"json("horizon":2)json";
  const std::size_t offset = authored.find(positive);
  REQUIRE(offset != std::string::npos);
  authored.replace(offset, positive.size(), R"json("horizon":-1)json");
  auto document = load_document(designated::write_input(
      "c22-transient-negative-horizon", authored));
  REQUIRE(document);
  auto parsed = parse_analysis_spec_v1(document.value());
  REQUIRE_FALSE(parsed);
  return parsed.error().code;
}

}  // namespace mwperf::testing::c22_transient
