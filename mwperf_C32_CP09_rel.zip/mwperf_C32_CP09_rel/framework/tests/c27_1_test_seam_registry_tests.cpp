#include <catch2/catch_test_macros.hpp>

#include "mwperf/surrogate/surrogate_id.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"

TEST_CASE("C27.1 leaves the C16 synthetic test registry unchanged",
          "[c27_1][test-seam]") {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE_FALSE(provider);
  CHECK(provider.error().code == "c16.unknown_surrogate_id");
}
