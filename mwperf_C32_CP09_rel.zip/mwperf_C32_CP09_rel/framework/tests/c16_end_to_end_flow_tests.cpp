#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_audited_handle_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::TypedLabel label(const std::string_view value) {
  auto result = mwperf::TypedLabel::text(std::string(value));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue(const std::string_view value) {
  return mwperf::QueueId(label(value));
}

[[nodiscard]] mwperf::Digest256 digest(const std::string_view value) {
  auto result = mwperf::sha256(
      std::as_bytes(std::span(value.data(), value.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::SourceNode parameters() {
  const mwperf::SourceLocation location{"c16-flow-parameters.json", 1U, 1U,
                                        0U};
  return mwperf::SourceNode::make_object(
      {{"resolution_level", location,
        mwperf::SourceNode::make_number("1", location,
                                        "/resolution_level")}},
      location, "");
}

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-end-to-end-input";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct Input final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
};

[[nodiscard]] std::string_view scheduler_for_family(
    const mwperf::ServiceFamily family) {
  switch (family) {
    case mwperf::ServiceFamily::crossbar_matching:
      return R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::nonoverlapping_intervals:
      return R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::node_exclusive_matching:
      return R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"w","v":"x"}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::pairwise_conflicts:
      return R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],"max_search_states":null}})json";
    case mwperf::ServiceFamily::resource_packing:
      return R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[2]}]},"priority":["q0","q1"],"max_search_states":null}})json";
  }
  FAIL("unreachable C16 fixture service family");
  return {};
}

[[nodiscard]] Input make_input(
    const std::string_view provider_id,
    const mwperf::ServiceFamily family =
        mwperf::ServiceFamily::pairwise_conflicts) {
  static constexpr std::string_view model_template = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":__C16_SCHEDULER__,
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  std::string model(model_template);
  static constexpr std::string_view scheduler_placeholder =
      "__C16_SCHEDULER__";
  const auto scheduler_position = model.find(scheduler_placeholder);
  REQUIRE(scheduler_position != std::string::npos);
  model.replace(scheduler_position, scheduler_placeholder.size(),
                scheduler_for_family(family));
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":")json") + std::string(provider_id) + R"json(",
                 "version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(write_input("model", model));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = mwperf::detail::CompiledArrivalAccess::get(
      instance.value().arrival());
  REQUIRE(arrival);
  auto metric = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(metric);
  auto requirements = mwperf::aggregate_metric_requirements(
      std::vector<mwperf::MetricRequest>{metric.value()});
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements)};
}

[[nodiscard]] mwperf::ConstructionBudget budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct Scenario final {
  mwperf::SurrogateProvider provider;
  mwperf::ResolvedInstance instance;
  mwperf::MetricRequirements requirements;
  mwperf::FrameworkProblemView view;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::PlugDescriptorPreview preview;
  mwperf::AcceptedCapabilityContract contract;
  mwperf::ConstructionBudget construction_budget;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] Scenario make_scenario(
    const std::string& provider_id,
    const mwperf::MasterSeed master_seed = mwperf::MasterSeed(0xC1604U),
    const mwperf::ServiceFamily family =
        mwperf::ServiceFamily::pairwise_conflicts,
    const mwperf::BuilderArrivalView* configured_arrival = nullptr) {
  auto input = make_input(provider_id, family);
  auto id = mwperf::SurrogateId::parse(provider_id);
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{} : provider.error().code));
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.flow.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto selected_view = std::move(view).value();
  if (configured_arrival != nullptr) {
    selected_view = Factory::with_configured_arrival(
        selected_view, *configured_arrival);
  }
  auto validated_parameters = mwperf::validate_surrogate_parameters(
      provider.value(), parameters());
  REQUIRE(validated_parameters);
  auto selected_budget = budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), selected_view, input.requirements, selected_budget,
      validated_parameters.value());
  INFO((preview ? std::string{} : preview.error().code));
  REQUIRE(preview);
  auto budget_digest =
      mwperf::digest_construction_budget_v1(selected_budget);
  REQUIRE(budget_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      selected_view.configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      selected_view.canonical_digest().value(),
      validated_parameters.value().canonical_value_digest(),
      budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), selected_view, contract,
      validated_parameters.value(), selected_budget, master_seed);
  INFO((request ? std::string{} : request.error().code));
  REQUIRE(request);
  return {std::move(provider).value(), std::move(input.instance),
          std::move(input.requirements), std::move(selected_view),
          std::move(validated_parameters).value(), std::move(preview).value(),
          std::move(contract), std::move(selected_budget),
          std::move(request).value()};
}

void check_arrival_view_unchanged(
    const mwperf::BuilderArrivalView& actual,
    const mwperf::BuilderArrivalView& expected) {
  CHECK(actual.version() == expected.version());
  CHECK(actual.binding() == expected.binding());
  CHECK(actual.digest() == expected.digest());
  CHECK(actual.capabilities() == expected.capabilities());
  CHECK(actual.positive_support().bytes() ==
        expected.positive_support().bytes());
  CHECK(actual.configured_law() == expected.configured_law());
  CHECK(actual.iid_joint_table() == expected.iid_joint_table());
  CHECK(actual.moments() == expected.moments());
  CHECK(actual.covariances() == expected.covariances());
  CHECK(actual.analytic_transform() == expected.analytic_transform());
  CHECK(actual.joint_distribution() == expected.joint_distribution());
  CHECK(actual.coordinate_distributions() ==
        expected.coordinate_distributions());
  CHECK(actual.replay_codec() == expected.replay_codec());
  CHECK(actual.unit_cube() == expected.unit_cube());
  CHECK(actual.finite_phase() == expected.finite_phase());
  CHECK(actual.transition_rows() == expected.transition_rows());
  CHECK(actual.stationary_phase_law() == expected.stationary_phase_law());
}

[[nodiscard]] std::filesystem::path execution_root() {
  auto result = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                "c16-end-to-end-runs";
  std::error_code error;
  std::filesystem::create_directories(result, error);
  REQUIRE_FALSE(error);
  result = std::filesystem::canonical(result, error);
  REQUIRE_FALSE(error);
  return result;
}

[[nodiscard]] mwperf::BuildExecutionContext context(
    const Scenario& scenario) {
  auto result = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root());
  INFO((result ? std::string{} : result.error().code));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArtifactParseLimits parse_limits() {
  return {1U << 20U, 64U, 1U << 14U, 1U << 14U, 1U << 16U,
          1U << 16U, 8U << 20U};
}

[[nodiscard]] std::string failure_code(
    const mwperf::ProviderExecutionOutcome& outcome) {
  const auto* failed = std::get_if<mwperf::FailedProviderExecution>(&outcome);
  return failed == nullptr ? std::string{} : failed->diagnostic.code;
}

[[nodiscard]] std::vector<std::byte> execute_bytes(
    const Scenario& scenario) {
  auto execution_context = context(scenario);
  auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, execution_context);
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  INFO((completed != nullptr ? std::string{} : failure_code(outcome)));
  REQUIRE(completed != nullptr);
  return completed->bytes;
}

struct BuiltFlow final {
  std::vector<std::byte> bytes;
  mwperf::ValidatedSurrogateBuildResult validated_result;
  mwperf::ValidatedSurrogateArtifact artifact;
  mwperf::PortablePlugPayload payload;
  mwperf::ValidatedSurrogatePlug plug;
  mwperf::KernelAccess access;
};

[[nodiscard]] BuiltFlow run_built_flow(const Scenario& scenario) {
  auto bytes = execute_bytes(scenario);
  auto parsed = mwperf::parse_surrogate_build_result(bytes, parse_limits());
  INFO((parsed ? std::string{}
               : parsed.error().code + ": " + parsed.error().message));
  REQUIRE(parsed);
  auto report = mwperf::validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.construction_budget);
  INFO((report ? std::string{} : report.error().code));
  REQUIRE(report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.provider.manifest(),
      scenario.contract, report.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  const auto* built =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(built != nullptr);
  REQUIRE(built->satisfied_clauses.size() == 1U);
  auto payload = mwperf::adapt_portable_payload(built->artifact);
  INFO((payload ? std::string{} : payload.error().code));
  REQUIRE(payload);
  auto plug = mwperf::materialize_and_validate_surrogate_plug(
      payload.value(), built->artifact, scenario.contract);
  INFO((plug ? std::string{} : plug.error().code));
  REQUIRE(plug);
  auto access = mwperf::validate_kernel_access(plug.value());
  INFO((access ? std::string{} : access.error().code));
  REQUIRE(access);
  return {std::move(bytes), validated.value(), built->artifact,
          std::move(payload).value(), std::move(plug).value(),
          std::move(access).value()};
}

[[nodiscard]] mwperf::ValidatedSurrogateBuildResult validate_completed(
    const Scenario& scenario, const std::vector<std::byte>& bytes) {
  auto parsed = mwperf::parse_surrogate_build_result(bytes, parse_limits());
  REQUIRE(parsed);
  auto report = mwperf::validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.construction_budget);
  REQUIRE(report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.provider.manifest(),
      scenario.contract, report.value());
  INFO((validated ? std::string{} : validated.error().code));
  REQUIRE(validated);
  return std::move(validated).value();
}

}  // namespace

TEST_CASE("C16 completed provider bytes traverse the complete C15 to F05 path",
          "[c16][integration][end-to-end][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  std::optional<mwperf::testing::ModeErasedLawProjectionV1> reference;
  std::vector<mwperf::ProviderIdentityV1> identities;
  std::vector<mwperf::Digest256> request_digests;
  std::vector<mwperf::Digest256> build_identity_digests;
  std::vector<mwperf::Digest256> artifact_payload_digests;
  std::vector<mwperf::Digest256> deployed_product_digests;
  std::vector<mwperf::Digest256> plug_descriptor_digests;
  std::vector<std::string_view> provider_ids{
      "c16.fixture.flow.closed-form", "c16.fixture.flow.precomputed",
      "c16.fixture.flow.in-process"};
#if defined(MWPERF_C16_FLOW_BUILDER_PATH)
  provider_ids.push_back("c16.fixture.flow.local");
#endif

  for (const auto provider_id : provider_ids) {
    CAPTURE(provider_id);
    auto scenario = make_scenario(std::string(provider_id));
    auto flow = run_built_flow(scenario);
    auto projection = mwperf::testing::make_mode_erased_law_projection_v1(
        flow.artifact, scenario.request, scenario.contract);
    REQUIRE(projection);
    if (!reference.has_value()) {
      reference = projection.value();
    } else {
      CHECK(projection.value() == *reference);
    }
    identities.push_back(scenario.provider.identity());
    request_digests.push_back(scenario.request.request_digest().value());
    build_identity_digests.push_back(
        scenario.request.build_identity_digest().digest());
    artifact_payload_digests.push_back(flow.artifact.value().payload_digest);
    const auto* response = std::get_if<mwperf::ThreeBinScalarResponseV1>(
        &flow.artifact.value().payload);
    REQUIRE(response != nullptr);
    deployed_product_digests.push_back(
        std::visit(
            [](const auto& product) {
              return product.identity().object_digest;
            },
            response->deployed_response_product_id));
    plug_descriptor_digests.push_back(
        flow.plug.descriptor().descriptor_digest);
  }

  for (std::size_t left = 0U; left < identities.size(); ++left) {
    for (std::size_t right = left + 1U; right < identities.size(); ++right) {
      CHECK(identities[left] != identities[right]);
      CHECK(request_digests[left] != request_digests[right]);
      CHECK(build_identity_digests[left] != build_identity_digests[right]);
      CHECK(artifact_payload_digests[left] != artifact_payload_digests[right]);
      CHECK(deployed_product_digests[left] !=
            deployed_product_digests[right]);
      CHECK(plug_descriptor_digests[left] !=
            plug_descriptor_digests[right]);
    }
  }
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        3U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        provider_ids.size());
}

TEST_CASE("C16 inner outcomes are atomic and never fall back to a stale plug",
          "[c16][integration][negative][atomicity][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto baseline = make_scenario("c16.fixture.flow.closed-form");
  const auto built = run_built_flow(baseline);
  const auto baseline_descriptor = built.plug.descriptor();

  for (const auto* provider_id : {"c16.fixture.flow.unavailable",
                                  "c16.fixture.flow.failed"}) {
    CAPTURE(provider_id);
    auto scenario = make_scenario(provider_id);
    auto validated = validate_completed(scenario, execute_bytes(scenario));
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated, scenario.requirements);
    CHECK_FALSE(
        std::holds_alternative<mwperf::RealizedBuiltCapabilitiesV1>(realized));
    CHECK(baseline_descriptor == built.plug.descriptor());
  }

  auto malformed = make_scenario("c16.fixture.flow.malformed");
  const auto malformed_bytes = execute_bytes(malformed);
  auto rejected =
      mwperf::parse_surrogate_build_result(malformed_bytes, parse_limits());
  REQUIRE_FALSE(rejected);
  CHECK(baseline_descriptor == built.plug.descriptor());
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        4U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        1U);
}

TEST_CASE("C16 fixed seed replay is cold deterministic and single dispatch",
          "[c16][integration][determinism][atomicity][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto first = make_scenario("c16.fixture.flow.in-process",
                             mwperf::MasterSeed(0xC16DULL));
  auto second = make_scenario("c16.fixture.flow.in-process",
                              mwperf::MasterSeed(0xC16DULL));
  REQUIRE(first.request.build_seed() == second.request.build_seed());
  REQUIRE(first.request.request_digest() == second.request.request_digest());

  auto first_context = context(first);
  auto first_outcome = mwperf::execute_surrogate_provider(
      first.provider, first.request, first_context);
  const auto* first_completed =
      std::get_if<mwperf::CompletedProviderExecution>(&first_outcome);
  REQUIRE(first_completed != nullptr);
  const auto repeated = mwperf::execute_surrogate_provider(
      first.provider, first.request, first_context);
  CHECK(failure_code(repeated) == "c16.repeated_provider_execution");

  auto second_context = context(second);
  const auto second_outcome = mwperf::execute_surrogate_provider(
      second.provider, second.request, second_context);
  const auto* second_completed =
      std::get_if<mwperf::CompletedProviderExecution>(&second_outcome);
  REQUIRE(second_completed != nullptr);
  CHECK(first_completed->bytes == second_completed->bytes);
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        2U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        0U);
}

TEST_CASE("C16 seed parent and request mutations are rejected preinvoke",
          "[c16][negative][binding][atomicity][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = make_scenario("c16.fixture.flow.closed-form");

  const mwperf::BuildSeed wrong_parent{
      scenario.request.build_seed().master_seed(),
      mwperf::BuildIdentityDigest(digest("c16.foreign.build-identity"))};
  const auto wrong_seed =
      Factory::with_build_seed(scenario.request, wrong_parent);
  auto rejected_seed_context = mwperf::BuildExecutionContext::create(
      wrong_seed, scenario.provider.manifest(), execution_root());
  REQUIRE_FALSE(rejected_seed_context);

  // Exercise F-C16-03 itself with a legitimate cold execution context.  Its
  // first operation is C15's read-only request verifier, so the foreign seed
  // parent must be rejected before either context consumption or provider
  // invocation.  Retaining the exact forged values also proves that C16 did
  // not repair the request or derive a replacement seed.
  auto seed_context = context(scenario);
  const auto seed_outcome = mwperf::execute_surrogate_provider(
      scenario.provider, wrong_seed, seed_context);
  CHECK(failure_code(seed_outcome) == "c15.build_seed_parent_mismatch");
  CHECK(wrong_seed.build_seed() == wrong_parent);
  CHECK(wrong_seed.build_identity_digest() ==
        scenario.request.build_identity_digest());
  CHECK_FALSE(wrong_seed.build_seed() == scenario.request.build_seed());

  const auto wrong_digest = Factory::with_request_digest(
      scenario.request,
      mwperf::SurrogateBuildRequestDigest(digest("c16.foreign.request")));
  auto rejected_request_context = mwperf::BuildExecutionContext::create(
      wrong_digest, scenario.provider.manifest(), execution_root());
  REQUIRE_FALSE(rejected_request_context);
  auto request_context = context(scenario);
  const auto request_outcome = mwperf::execute_surrogate_provider(
      scenario.provider, wrong_digest, request_context);
  CHECK(failure_code(request_outcome) == "c15.request_digest_mismatch");
  CHECK(wrong_digest.request_digest() != scenario.request.request_digest());
  CHECK(wrong_digest.build_seed() == scenario.request.build_seed());
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        0U);
}

TEST_CASE("C16 materialization rejects mutated contract bindings atomically",
          "[c16][negative][binding][atomicity][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = make_scenario("c16.fixture.flow.closed-form");
  auto built = run_built_flow(scenario);
  const auto materializations =
      mwperf::testing::c16_fixture_detail::materializer_calls().load();

  const auto check_mutation = [&](const std::string_view name,
                                  auto mutate,
                                  const std::string_view expected_code = {}) {
    CAPTURE(name);
    auto bindings = built.artifact.validation_bindings();
    mutate(bindings);
    const auto forged = Factory::validated_artifact(
        built.artifact.value(), std::move(bindings));
    const auto rejected = mwperf::materialize_and_validate_surrogate_plug(
        built.payload, forged, scenario.contract);
    if (expected_code.empty()) {
      CHECK_FALSE(rejected);
    } else {
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == expected_code);
    }
    CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
          materializations);
  };

  check_mutation("provider", [](auto& value) {
    value.provider.provider_id = "c16.fixture.foreign";
  });
  check_mutation(
      "build-identity",
      [](auto& value) {
        value.build_identity_digest = digest("foreign.build-identity");
      },
      "c16.materialization_binding_mismatch");
  check_mutation(
      "request",
      [](auto& value) {
        value.request_digest = digest("foreign.request");
      },
      "c16.materialization_binding_mismatch");
  check_mutation("parameter-schema", [](auto& value) {
    ++value.parameter_schema_version;
  });
  check_mutation("scientific-contract", [](auto& value) {
    value.provider_scientific_contract_digest = digest("foreign.science");
  });
  check_mutation("construction-method", [](auto& value) {
    value.construction_method = mwperf::ConstructionMethodV1::sampled_offline;
  });
  check_mutation("producer-mode", [](auto& value) {
    value.producer_mode = mwperf::ProducerModeV1::local_executable_builder;
  });
  check_mutation(
      "semantic",
      [](auto& value) {
        value.semantic = mwperf::SemanticTagV1::stationary_marked_edge;
      },
      "c16.materialization_binding_mismatch");
  check_mutation(
      "runtime-access",
      [](auto& value) {
        value.runtime_access =
            mwperf::RuntimeAccessTagV1::finite_enumerated_row;
      },
      "c16.materialization_binding_mismatch");
  check_mutation(
      "payload-class",
      [](auto& value) {
        value.payload_class =
            {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U};
      },
      "c16.materialization_binding_mismatch");
  check_mutation(
      "problem-view",
      [](auto& value) {
        value.framework_problem_view_digest = digest("foreign.problem-view");
      },
      "c16.materialization_binding_mismatch");
  check_mutation("accepted-contract", [](auto& value) {
    value.accepted_contract_digest = digest("foreign.contract");
  });
  check_mutation("requirements", [](auto& value) {
    value.requirements_digest = digest("foreign.requirements");
  });
  check_mutation("arrival", [](auto& value) {
    value.arrival_capabilities_digest = digest("foreign.arrival");
  });
  check_mutation("preview", [](auto& value) {
    value.preview_digest = digest("foreign.preview");
  });
  check_mutation("parameters", [](auto& value) {
    value.parameter_digest = digest("foreign.parameters");
  });
  check_mutation("budget", [](auto& value) {
    value.budget_digest = digest("foreign.budget");
  });
  check_mutation("manifest", [](auto& value) {
    value.structural_manifest_digest = digest("foreign.manifest");
  });
  check_mutation("analysis-selection", [](auto& value) {
    value.analysis_selection_digest = digest("foreign.selection");
  });
}

TEST_CASE("C16 post-plan stage failures publish no partial runtime state",
          "[c16][integration][negative][atomicity][flow]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = make_scenario("c16.fixture.flow.closed-form");
  const auto completed_bytes = execute_bytes(scenario);
  auto parsed =
      mwperf::parse_surrogate_build_result(completed_bytes, parse_limits());
  REQUIRE(parsed);
  REQUIRE(std::holds_alternative<mwperf::BuiltSurrogateResultV1>(
      parsed.value()));

  const auto planned_request_digest = scenario.request.request_digest();
  const auto planned_build_identity =
      scenario.request.build_identity_digest();
  const auto planned_seed = scenario.request.build_seed();
  const auto planned_view_digest = scenario.view.canonical_digest();
  const auto planned_selection = scenario.view.analysis_selection();
  const auto planned_provider = scenario.provider.identity();
  const auto planned_manifest_digest =
      scenario.provider.manifest().value().manifest_digest;
  const auto planned_preview_calls =
      mwperf::testing::c16_fixture_detail::preview_calls().load();
  const auto planned_construction_calls =
      mwperf::testing::c16_fixture_detail::construction_calls().load();
  const auto planned_materializer_calls =
      mwperf::testing::c16_fixture_detail::materializer_calls().load();
  REQUIRE(planned_construction_calls == 1U);
  REQUIRE(planned_materializer_calls == 0U);
  std::optional<mwperf::ValidatedSurrogatePlug> published_plug;
  std::optional<mwperf::KernelAccess> published_access;

  const auto check_no_runtime_publication =
      [&](const unsigned expected_materializer_calls) {
        CHECK_FALSE(published_plug.has_value());
        CHECK_FALSE(published_access.has_value());
        CHECK(scenario.request.request_digest() == planned_request_digest);
        CHECK(scenario.request.build_identity_digest() ==
              planned_build_identity);
        CHECK(scenario.request.build_seed() == planned_seed);
        CHECK(scenario.view.canonical_digest() == planned_view_digest);
        CHECK(scenario.view.analysis_selection() == planned_selection);

        auto id = mwperf::SurrogateId::parse(planned_provider.provider_id);
        auto version =
            mwperf::SurrogateVersion::parse(planned_provider.provider_version);
        REQUIRE(id);
        REQUIRE(version);
        auto current = mwperf::lookup_surrogate_provider(
            id.value(),
            std::optional<mwperf::SurrogateVersion>{version.value()});
        REQUIRE(current);
        CHECK(current.value().identity() == planned_provider);
        CHECK(current.value().manifest().value().manifest_digest ==
              planned_manifest_digest);

        // Snapshotting immediately after the one planned construction makes
        // this independent of whether a particular fixture instruments its
        // pure preview callback.  Every failure must leave preview and
        // construction counts unchanged: no retry, fallback, or replan.  One
        // additional materializer call is permitted only for failures
        // deliberately injected after that call.
        CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load() ==
              planned_preview_calls);
        CHECK(
            mwperf::testing::c16_fixture_detail::construction_calls().load() ==
            planned_construction_calls);
        CHECK(
            mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
            planned_materializer_calls + expected_materializer_calls);
      };

  SECTION("F-C16-10 build-report failure") {
    auto corrupted = parsed.value();
    auto& built = std::get<mwperf::BuiltSurrogateResultV1>(corrupted);
    built.envelope.build_report.optimizer_calls.used = mwperf::BigNat{1U};
    auto report_digest = mwperf::canonical_common_build_report_digest_v1(
        built.envelope.build_report);
    REQUIRE(report_digest);
    built.envelope.build_report.report_digest =
        std::move(report_digest).value();

    auto rejected = mwperf::validate_surrogate_build_report(
        corrupted, scenario.request, scenario.construction_budget);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.report_budget_exceeded");
    check_no_runtime_publication(0U);
  }

  SECTION("C15 artifact validation failure") {
    auto report = mwperf::validate_surrogate_build_report(
        parsed.value(), scenario.request, scenario.construction_budget);
    REQUIRE(report);
    auto corrupted = parsed.value();
    std::get<mwperf::BuiltSurrogateResultV1>(corrupted)
        .artifact.payload_digest = digest("c16.foreign.payload");
    auto rejected = mwperf::validate_surrogate_build_result(
        corrupted, scenario.request, scenario.provider.manifest(),
        scenario.contract, report.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c15.payload_digest");
    check_no_runtime_publication(0U);
  }

  SECTION("C15 portable adaptation failure") {
    auto validated = validate_completed(scenario, completed_bytes);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated, scenario.requirements);
    const auto* built =
        std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
    REQUIRE(built != nullptr);
    auto corrupted = built->artifact.value();
    auto* response = std::get_if<mwperf::ThreeBinScalarResponseV1>(
        &corrupted.payload);
    REQUIRE(response != nullptr);
    response->deployed_response_product_id = Factory::raw_response_product_id(
        {label("c16.foreign.raw-product"),
         digest("c16.foreign.raw-product")});
    const auto forged = Factory::validated_artifact(
        std::move(corrupted), built->artifact.validation_bindings());

    auto rejected = mwperf::adapt_portable_payload(forged);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c15.portable_adapter_validated_artifact_invariant");
    check_no_runtime_publication(0U);
  }

  SECTION("F-C16-04 rejects an invalid descriptor after materialization") {
    auto validated = validate_completed(scenario, completed_bytes);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated, scenario.requirements);
    const auto* built =
        std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
    REQUIRE(built != nullptr);

    auto invalid_core = scenario.contract.descriptor_core();
    invalid_core.schema_version = 2U;
    auto core_digest =
        mwperf::canonical_plug_descriptor_core_digest_v1(invalid_core);
    REQUIRE(core_digest);
    invalid_core.core_digest = std::move(core_digest).value();
    auto forged_contract = Factory::accepted_contract(
        scenario.provider.manifest().value(), invalid_core,
        scenario.contract.structural_manifest(),
        scenario.contract.requirements(),
        scenario.contract.arrival_capabilities(),
        std::vector<mwperf::ResolvedMetricContractV1>(
            scenario.contract.metric_contracts().begin(),
            scenario.contract.metric_contracts().end()),
        std::vector<mwperf::QueueId>(
            scenario.contract.construction_target_scope().begin(),
            scenario.contract.construction_target_scope().end()),
        scenario.contract.policies(),
        scenario.contract.construction_prerequisites(),
        scenario.view.canonical_digest().value(),
        scenario.contract.parameter_digest(),
        scenario.contract.budget_digest());

    auto source = built->artifact.value();
    source.deployed_descriptor = invalid_core;
    auto bindings = built->artifact.validation_bindings();
    bindings.provider = forged_contract.provider();
    bindings.construction_method = forged_contract.construction_method();
    bindings.producer_mode = forged_contract.producer_mode();
    bindings.semantic = forged_contract.semantic();
    bindings.runtime_access = forged_contract.runtime_access();
    bindings.payload_class = forged_contract.payload_class();
    bindings.framework_problem_view_digest =
        scenario.view.canonical_digest().value();
    bindings.accepted_contract_digest = forged_contract.contract_digest();
    bindings.requirements_digest = forged_contract.requirements_digest();
    bindings.arrival_capabilities_digest =
        forged_contract.arrival_capabilities_digest();
    bindings.preview_digest = forged_contract.preview_digest();
    bindings.parameter_digest = forged_contract.parameter_digest();
    bindings.budget_digest = forged_contract.budget_digest();
    bindings.structural_manifest_digest =
        forged_contract.structural_manifest().canonical_digest();
    const auto forged_artifact = Factory::validated_artifact(
        std::move(source), std::move(bindings));
    auto forged_payload = mwperf::adapt_portable_payload(forged_artifact);
    REQUIRE(forged_payload);

    auto rejected = mwperf::materialize_and_validate_surrogate_plug(
        forged_payload.value(), forged_artifact, forged_contract);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.invalid_c14_descriptor_core");
    check_no_runtime_publication(1U);
  }

  SECTION("F-C16-05 rejects access shape without invoking it") {
    auto validated = validate_completed(scenario, completed_bytes);
    const auto realized = mwperf::resolve_realized_metric_capabilities(
        validated, scenario.requirements);
    const auto* built =
        std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
    REQUIRE(built != nullptr);
    auto payload = mwperf::adapt_portable_payload(built->artifact);
    REQUIRE(payload);

    // First prove that this exact C15 artifact traverses the real F-C16-04
    // materializer.  The successful carrier remains scoped and is destroyed
    // before injecting the access-only mutation at the F-C16-05 seam.
    std::optional<mwperf::PlugDescriptor> descriptor;
    {
      auto materialized = mwperf::materialize_and_validate_surrogate_plug(
          payload.value(), built->artifact, scenario.contract);
      REQUIRE(materialized);
      descriptor = materialized.value().descriptor();
    }
    REQUIRE(descriptor.has_value());

    std::atomic<unsigned> access_calls{0U};
    const auto& core = built->artifact.value().deployed_descriptor;
    mwperf::KernelAccess invalid_access =
        mwperf::FiniteParameterAnalyticFamilyAccess(
            {{"c16.foreign.backlog", 1U},
             {std::string(mwperf::kThreeBinServiceResponseCodecIdV1), 1U}},
            {std::string(mwperf::kThreeBinResponseFamilyIdV1), 1U,
             {std::string(mwperf::kThreeBinResponseParameterSchemaIdV1), 1U},
             core.state_fields.front().codec},
            [&access_calls](const mwperf::CanonicalRuntimeValueV1&) {
              access_calls.fetch_add(1U);
              return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                  {{std::string(mwperf::kThreeBinServiceResponseCodecIdV1),
                    1U},
                   {std::byte{0x01}}});
            });
    mwperf::SurrogatePlug invalid_plug =
        mwperf::ScalarBacklogResponsePlugV1{
            payload.value(), std::move(invalid_access)};
    {
      auto candidate =
          mwperf::testing::C16FixtureAuditedMint::validated_plug(
              std::move(*descriptor), std::move(invalid_plug),
              built->artifact.validation_bindings(),
              scenario.contract.contract_digest(),
              scenario.contract.structural_manifest());
      REQUIRE(candidate);
      auto rejected = mwperf::validate_kernel_access(candidate.value());
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code == "c16.analytic_family_domain_mismatch");
    }
    CHECK(access_calls.load() == 0U);
    check_no_runtime_publication(1U);
  }
}

TEST_CASE(
    "C16 all ten profiles preserve each external C09 law through F05",
    "[c16][integration][end-to-end][identity][flow][arrival-composition]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  std::optional<mwperf::testing::ModeErasedLawProjectionV1> iid_reference;
  std::optional<mwperf::testing::ModeErasedLawProjectionV1>
      temporal_reference;
  std::vector<mwperf::ProviderIdentityV1> providers;
  std::vector<mwperf::Digest256> manifests;
  std::vector<mwperf::Digest256> construction_identities;
  std::vector<mwperf::Digest256> requests;
  std::vector<mwperf::Digest256> artifacts;
  std::vector<mwperf::Digest256> products;
  std::vector<mwperf::Digest256> descriptors;
  providers.reserve(mwperf::testing::kC16TestProfiles.size());
  manifests.reserve(mwperf::testing::kC16TestProfiles.size());
  for (const auto& profile : mwperf::testing::kC16TestProfiles) {
    CAPTURE(profile.provider_id);

    // C16 owns only the phase-free service-response plug.  Use the inherited
    // trusted view seam to put each immutable C09 construction view through
    // the complete C16-owned profile path without inventing a C17 route.
    auto arrival_input = make_input(profile.provider_id, profile.family);
    auto iid_law = mwperf::testing::make_c09_correlated_fixture_law(
        arrival_input.instance.queues(),
        mwperf::testing::FixtureFailureMode::none,
        mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
    auto temporal_law = mwperf::testing::make_c09_correlated_fixture_law(
        arrival_input.instance.queues());
    REQUIRE(iid_law);
    REQUIRE(temporal_law);
    const auto iid_before = mwperf::builder_arrival_view(iid_law.value());
    const auto temporal_before =
        mwperf::builder_arrival_view(temporal_law.value());
    REQUIRE(iid_before.iid_joint_table());
    REQUIRE(iid_before.finite_phase());
    REQUIRE(iid_before.transition_rows());
    CHECK_FALSE(temporal_before.iid_joint_table());
    REQUIRE(temporal_before.finite_phase());
    REQUIRE(temporal_before.transition_rows());
    REQUIRE(temporal_before.stationary_phase_law());
    CHECK(temporal_before.capabilities()
              .finite_enumerated_predictive_phase ==
          mwperf::CapabilityAvailability::available);
    CHECK(temporal_before.capabilities()
              .finite_enumerated_transition_row ==
          mwperf::CapabilityAvailability::available);
    CHECK_FALSE(iid_before.binding() == temporal_before.binding());
    CHECK_FALSE(iid_before.digest() == temporal_before.digest());

    auto iid_scenario = make_scenario(
        std::string(profile.provider_id), mwperf::MasterSeed(0xC1610U),
        profile.family, &iid_before);
    auto iid_flow = run_built_flow(iid_scenario);
    auto iid_projection =
        mwperf::testing::make_mode_erased_law_projection_v1(
            iid_flow.artifact, iid_scenario.request, iid_scenario.contract);
    REQUIRE(iid_projection);

    auto temporal_scenario = make_scenario(
        std::string(profile.provider_id), mwperf::MasterSeed(0xC1610U),
        profile.family, &temporal_before);
    auto temporal_flow = run_built_flow(temporal_scenario);
    auto temporal_projection =
        mwperf::testing::make_mode_erased_law_projection_v1(
            temporal_flow.artifact, temporal_scenario.request,
            temporal_scenario.contract);
    REQUIRE(temporal_projection);

    const auto check_external_arrival_flow =
        [](const Scenario& scenario, const BuiltFlow& flow,
           const mwperf::BuilderArrivalView& expected_arrival) {
      check_arrival_view_unchanged(scenario.view.configured_arrival(),
                                   expected_arrival);
      check_arrival_view_unchanged(
          scenario.request.framework_problem_view().configured_arrival(),
          expected_arrival);
      CHECK(scenario.view.fingerprints().compiled_arrival ==
            expected_arrival.digest().value());
      CHECK(scenario.request.framework_problem_view()
                .fingerprints()
                .compiled_arrival == expected_arrival.digest().value());

      CHECK(scenario.preview.core.semantic ==
            mwperf::SemanticTagV1::scalar_backlog_response);
      CHECK(scenario.preview.core.runtime_access ==
            mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
      CHECK(scenario.preview.core.phase.payload_phase ==
            mwperf::PayloadPhaseKindV1::phase_free);
      CHECK(scenario.preview.core.phase.arrival_composition ==
            mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition);
      CHECK_FALSE(
          scenario.preview.core.phase.retains_configured_predictive_phase);
      CHECK_FALSE(scenario.preview.core.phase.predictive_phase_codec);
      CHECK(scenario.preview.construction_prerequisites.arrival.empty());
      CHECK(scenario.contract.construction_prerequisites().arrival.empty());
      CHECK(scenario.contract.metric_contracts().empty());
      CHECK(scenario.contract.arrival_capabilities() ==
            expected_arrival.capabilities());
      for (const auto& clause :
           scenario.contract.structural_manifest().clauses()) {
        CHECK(clause.phase_domain.payload_phase ==
              mwperf::PayloadPhaseKindV1::phase_free);
        CHECK(clause.phase_domain.arrival_composition ==
              mwperf::ConfiguredArrivalCompositionV1::
                  no_arrival_composition);
        CHECK_FALSE(
            clause.phase_domain.retains_configured_predictive_phase);
        CHECK_FALSE(clause.phase_domain.predictive_phase_codec);
      }

      const auto* response = std::get_if<mwperf::ThreeBinScalarResponseV1>(
          &flow.artifact.value().payload);
      REQUIRE(response != nullptr);
      CHECK(response->configured_arrival_binding ==
            expected_arrival.digest().value());
      CHECK(response->raw_response.configured_arrival_binding ==
            expected_arrival.digest().value());
      CHECK(flow.plug.artifact_bindings().framework_problem_view_digest ==
            scenario.view.canonical_digest().value());
      CHECK(flow.plug.artifact_bindings().arrival_capabilities_digest ==
            scenario.contract.arrival_capabilities_digest());

      const auto& report = flow.artifact.value().build_report_echo;
      CHECK(report.configured_generator_draws.applicability ==
            mwperf::WorkCounterApplicabilityV1::applicable);
      CHECK(report.configured_generator_draws.used == mwperf::BigNat{0U});
      CHECK(scenario.construction_budget.configured_generator_draws.amount ==
            std::optional<mwperf::BigNat>{mwperf::BigNat{0U}});

      const auto& descriptor = flow.plug.descriptor();
      CHECK(descriptor.configured_arrival_ownership ==
            mwperf::ConfiguredArrivalOwnershipV1::
                framework_external_exactly_once);
      CHECK_FALSE(descriptor.c_minus);
      CHECK_FALSE(descriptor.c_plus);
      CHECK_FALSE(descriptor.event_contract);
      const auto* family =
          std::get_if<mwperf::FiniteParameterAnalyticFamilyAccess>(
              &flow.access);
      REQUIRE(family != nullptr);
      CHECK(family->has_operation());
      CHECK(family->shape().response_codec ==
            mwperf::CodecIdentityV1{
                std::string(mwperf::kThreeBinServiceResponseCodecIdV1), 1U});
    };
    check_external_arrival_flow(iid_scenario, iid_flow, iid_before);
    check_external_arrival_flow(temporal_scenario, temporal_flow,
                                temporal_before);

    CHECK(iid_projection.value().deployed_law ==
          temporal_projection.value().deployed_law);
    CHECK(iid_projection.value().timing_convention ==
          temporal_projection.value().timing_convention);
    CHECK(iid_projection.value().metric_convention ==
          temporal_projection.value().metric_convention);
    CHECK_FALSE(iid_projection.value().configured_arrival_math ==
                temporal_projection.value().configured_arrival_math);
    CHECK(iid_flow.plug.descriptor() == temporal_flow.plug.descriptor());

    const auto* iid_response =
        std::get_if<mwperf::ThreeBinScalarResponseV1>(
            &iid_flow.artifact.value().payload);
    const auto* temporal_response =
        std::get_if<mwperf::ThreeBinScalarResponseV1>(
            &temporal_flow.artifact.value().payload);
    REQUIRE(iid_response != nullptr);
    REQUIRE(temporal_response != nullptr);
    CHECK(iid_scenario.provider.identity() ==
          temporal_scenario.provider.identity());
    CHECK(iid_scenario.provider.manifest().value().manifest_digest ==
          temporal_scenario.provider.manifest().value().manifest_digest);
    CHECK_FALSE(iid_scenario.request.build_identity_digest() ==
                temporal_scenario.request.build_identity_digest());
    CHECK_FALSE(iid_scenario.request.request_digest() ==
                temporal_scenario.request.request_digest());
    CHECK_FALSE(iid_flow.artifact.value().payload_digest ==
                temporal_flow.artifact.value().payload_digest);
    CHECK_FALSE(iid_response->response_row_id ==
                temporal_response->response_row_id);
    CHECK_FALSE(iid_response->deployed_response_product_id ==
                temporal_response->deployed_response_product_id);

    if (!iid_reference.has_value()) {
      iid_reference = iid_projection.value();
    } else {
      CHECK(iid_projection.value() == *iid_reference);
    }
    if (!temporal_reference.has_value()) {
      temporal_reference = temporal_projection.value();
    } else {
      CHECK(temporal_projection.value() == *temporal_reference);
    }

    CHECK(iid_flow.artifact.value().build_report_echo.optional_method_counters
              .size() ==
          iid_scenario.provider.manifest()
              .value()
              .required_method_counters.size());
    CHECK(temporal_flow.artifact.value()
              .build_report_echo.optional_method_counters.size() ==
          temporal_scenario.provider.manifest()
              .value()
              .required_method_counters.size());

    check_arrival_view_unchanged(
        mwperf::builder_arrival_view(iid_law.value()), iid_before);
    check_arrival_view_unchanged(
        mwperf::builder_arrival_view(temporal_law.value()), temporal_before);

    providers.push_back(iid_scenario.provider.identity());
    manifests.push_back(
        iid_scenario.provider.manifest().value().manifest_digest);
    construction_identities.push_back(
        iid_scenario.request.build_identity_digest().digest());
    requests.push_back(iid_scenario.request.request_digest().value());
    artifacts.push_back(
        iid_flow.artifact.value().payload_identity.object_digest);
    products.push_back(std::visit(
        [](const auto& product) { return product.identity().object_digest; },
        iid_response->deployed_response_product_id));
    descriptors.push_back(iid_flow.plug.descriptor().descriptor_digest);
  }
  for (std::size_t left = 0U; left < providers.size(); ++left) {
    for (std::size_t right = left + 1U; right < providers.size(); ++right) {
      CHECK(providers[left] != providers[right]);
      CHECK(manifests[left] != manifests[right]);
      CHECK(construction_identities[left] != construction_identities[right]);
      CHECK(requests[left] != requests[right]);
      CHECK(artifacts[left] != artifacts[right]);
      CHECK(products[left] != products[right]);
      CHECK(descriptors[left] != descriptors[right]);
    }
  }
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        2U * mwperf::testing::kC16TestProfiles.size());
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        2U * mwperf::testing::kC16TestProfiles.size());
}
