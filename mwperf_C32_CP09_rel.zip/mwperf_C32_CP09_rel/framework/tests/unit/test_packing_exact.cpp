#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <optional>
#include <ranges>
#include <sstream>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/packing.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct PackingFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::PackingProblem problem;
};

struct Query final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct SolveAttempt final {
  mwperf::Result<mwperf::OptimizerSolution> result;
  mwperf::SearchAccounting accounting;
};

struct InstrumentedAttempt final {
  mwperf::Result<mwperf::detail::PackingExactWitness> result;
  mwperf::detail::PackingSolveInstrumentation instrumentation;
  mwperf::SearchAccounting accounting;
};

struct ForcedAttempt final {
  mwperf::Result<mwperf::PrimaryOptimum> result;
  mwperf::BigNat calls_reserved;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c08-packing-unit";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string queue_list(const std::size_t count) {
  std::ostringstream output;
  output << '[';
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"q" << queue << "\"";
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string natural_priority(const std::size_t count) {
  return queue_list(count);
}

[[nodiscard]] std::string model_text(const std::size_t queue_count,
                                     const std::string& constraint,
                                     const std::string& priority) {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queue_list(queue_count) +
         R"(},"scheduler":{"name":"resource_packing_max_weight","params":{"constraint":)" +
         constraint + R"(,"priority":)" + priority +
         R"(,"max_search_states":null}},"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] PackingFixture make_fixture(
    const std::size_t queue_count, const std::string& constraint,
    std::string priority = {}) {
  if (priority.empty()) {
    priority = natural_priority(queue_count);
  }
  auto document = mwperf::load_document(
      write_model(model_text(queue_count, constraint, priority)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  INFO((model ? std::string{} : model.error().code));
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto resolved_priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(resolved_priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  const auto& resolved = std::get<mwperf::ResolvedPackingConstraint>(
      descriptor.value().value());
  auto problem = mwperf::compile_packing_problem(resolved);
  INFO((problem ? std::string{} : problem.error().code));
  REQUIRE(problem);
  return PackingFixture{std::move(catalog).value(),
                        std::move(resolved_priority).value(),
                        std::move(descriptor).value(),
                        std::move(problem).value()};
}

[[nodiscard]] mwperf::Result<mwperf::AuthoredModelConfig> parse_attempt(
    const std::size_t queue_count, const std::string& constraint) {
  auto document = mwperf::load_document(write_model(model_text(
      queue_count, constraint, natural_priority(queue_count))));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  return mwperf::parse_model_config_v3(node.value());
}

[[nodiscard]] mwperf::Result<mwperf::ConstraintDescriptor> compile_attempt(
    const std::size_t queue_count, const std::string& constraint) {
  auto document = mwperf::load_document(write_model(model_text(
      queue_count, constraint, natural_priority(queue_count))));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  return mwperf::compile_constraint_descriptor(model.value().scheduler,
                                                catalog.value());
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy policy(
    std::optional<mwperf::BigNat> limit) {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = limit,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::move(limit),
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '9'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const PackingFixture& fixture,
    const mwperf::OptimizerBudgetPolicy& budget_policy) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, budget_policy);
}

[[nodiscard]] Query make_query(
    const PackingFixture& fixture, std::vector<mwperf::BigNat> values,
    std::vector<std::uint8_t> eligibility_values,
    const mwperf::OptimizerBudgetPolicy& budget_policy) {
  const auto token = dimension(fixture, budget_policy);
  auto primary =
      mwperf::PrimaryWeights::from_values(token, std::move(values));
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, std::move(eligibility_values));
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return Query{std::move(primary).value(), std::move(eligibility).value(),
               std::move(weights).value()};
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] SolveAttempt solve_attempt(
    const PackingFixture& fixture, const Query& query,
    const mwperf::OptimizerBudgetPolicy& budget_policy) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      budget_policy, std::nullopt, query.weights.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto result = mwperf::solve_exact(fixture.descriptor, query.eligibility,
                                    query.weights, budget.value());
  const auto accounting = budget.value().accounting();
  if (result) {
    auto validation = mwperf::validate_optimizer_solution(
        result.value(), fixture.descriptor, query.eligibility,
        query.weights);
    INFO((validation ? std::string{} : validation.error().code));
    REQUIRE(validation);
    CHECK(result.value().accounting() == accounting);
  }
  return SolveAttempt{std::move(result), accounting};
}

[[nodiscard]] InstrumentedAttempt instrumented_attempt(
    const PackingFixture& fixture, const Query& query,
    const mwperf::OptimizerBudgetPolicy& budget_policy,
    const mwperf::detail::PackingSolveFault fault =
        mwperf::detail::PackingSolveFault::none) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      budget_policy, std::nullopt, query.weights.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::resource_packing));
  mwperf::detail::PackingSolveInstrumentation instrumentation;
  auto result = mwperf::detail::solve_packing_exact_with_instrumentation(
      fixture.problem, query.eligibility, query.weights, budget.value(),
      instrumentation, fault);
  return InstrumentedAttempt{std::move(result), std::move(instrumentation),
                             budget.value().accounting()};
}

[[nodiscard]] ForcedAttempt forced_attempt(
    const PackingFixture& fixture, const Query& query,
    const mwperf::OptimizerBudgetPolicy& budget_policy,
    const mwperf::ForcedTargetBit side) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      budget_policy, std::nullopt, query.primary.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto target = mwperf::TargetIndex::from_dimension(
      query.primary.dimension(), 0U);
  REQUIRE(target);
  auto result = mwperf::solve_forced_target(
      context, fixture.descriptor, query.eligibility, query.primary,
      target.value(), side, fixture.priority);
  return ForcedAttempt{std::move(result),
                       context.ledger_snapshot().calls_reserved()};
}

[[nodiscard]] std::vector<std::uint8_t> bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] mwperf::BigNat power_of_two(const unsigned int shift) {
  mwperf::BigInt value = 1;
  value <<= shift;
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C08 packing compilation retains exact resources demands and empty dimensions",
          "[c08][unit][packing][compile]") {
  const auto huge = power_of_two(160U).to_decimal_string();
  const auto fixture = make_fixture(
      3U,
      R"({"resources":["ram","cpu"],"capacity":[)" + huge +
          R"(,3],"demands":[{"queue_id":"q2","demand":[0,0]},{"queue_id":"q0","demand":[1,2]},{"queue_id":"q1","demand":[)" +
          huge + R"(,3]}]})");
  REQUIRE(fixture.problem.resource_count() == 2U);
  REQUIRE(fixture.problem.queue_count() == 3U);
  CHECK(fixture.problem.capacity()[0U] == power_of_two(160U));
  CHECK(fixture.problem.capacity()[1U] == mwperf::BigNat(3U));
  REQUIRE(fixture.problem.demands().size() == 3U);
  CHECK(fixture.problem.demands()[0U].queue.ordinal() == 0U);
  CHECK(fixture.problem.demands()[1U].queue.ordinal() == 1U);
  CHECK(fixture.problem.demands()[2U].queue.ordinal() == 2U);
  CHECK(fixture.problem.demands()[1U].demand[0U] == power_of_two(160U));

  const auto empty = make_fixture(
      2U,
      R"({"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]},{"queue_id":"q1","demand":[]}]})");
  CHECK(empty.problem.resource_count() == 0U);
  CHECK(empty.problem.capacity().empty());
  CHECK(empty.problem.demands()[0U].demand.empty());
  CHECK(empty.problem.demands()[1U].demand.empty());
}

TEST_CASE("C08 packing normalization removes only current infeasibility",
          "[c08][unit][packing][normalization]") {
  const auto fixture = make_fixture(
      5U,
      R"({"resources":["r0","r1"],"capacity":[3,4],"demands":[{"queue_id":"q0","demand":[4,0]},{"queue_id":"q1","demand":[3,4]},{"queue_id":"q2","demand":[0,5]},{"queue_id":"q3","demand":[0,0]},{"queue_id":"q4","demand":[1,1]}]})");
  auto subset = mwperf::QueueSubset::from_bytes(
      std::vector<std::uint8_t>{1U, 1U, 1U, 1U, 1U});
  REQUIRE(subset);
  auto normalized = mwperf::normalize_packing_subproblem(
      fixture.problem, std::move(subset).value(), fixture.problem.capacity());
  REQUIRE(normalized);
  CHECK_FALSE(normalized.value().queues().test(0U));
  CHECK(normalized.value().queues().test(1U));
  CHECK_FALSE(normalized.value().queues().test(2U));
  CHECK(normalized.value().queues().test(3U));
  CHECK(normalized.value().queues().test(4U));
  CHECK(normalized.value().remaining_capacity() == fixture.problem.capacity());

  const auto no_cap = make_fixture(
      2U,
      R"({"resources":["r"],"capacity":[100],"demands":[{"queue_id":"q0","demand":[2]},{"queue_id":"q1","demand":[1]}]})");
  auto both = mwperf::QueueSubset::from_bytes(
      std::vector<std::uint8_t>{1U, 1U});
  REQUIRE(both);
  auto unchanged = mwperf::normalize_packing_subproblem(
      no_cap.problem, std::move(both).value(), no_cap.problem.capacity());
  REQUIRE(unchanged);
  CHECK(unchanged.value().queues().test(0U));
  CHECK(unchanged.value().queues().test(1U));
  CHECK(unchanged.value().remaining_capacity()[0U] == mwperf::BigNat(100U));
}

TEST_CASE("C08 packing solves zero-dimensional zero-capacity and non-greedy cases",
          "[c08][unit][packing]") {
  const auto unlimited = policy(std::nullopt);

  SECTION("no resources selects every eligible queue") {
    const auto fixture = make_fixture(
        4U,
        R"({"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]},{"queue_id":"q1","demand":[]},{"queue_id":"q2","demand":[]},{"queue_id":"q3","demand":[]}]})");
    const auto query = make_query(fixture, naturals({1U, 2U, 3U, 4U}),
                                  {1U, 0U, 1U, 1U}, unlimited);
    auto attempt = solve_attempt(fixture, query, unlimited);
    REQUIRE(attempt.result);
    CHECK(bits(attempt.result.value().schedule()) ==
          std::vector<std::uint8_t>{1U, 0U, 1U, 1U});
    CHECK(attempt.accounting.completed_expansions() == mwperf::BigNat(3U));
  }

  SECTION("zero capacity retains exactly zero-demand queues") {
    const auto fixture = make_fixture(
        3U,
        R"({"resources":["r"],"capacity":[0],"demands":[{"queue_id":"q0","demand":[0]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[0]}]})");
    const auto query = make_query(fixture, naturals({3U, 100U, 2U}),
                                  {1U, 1U, 1U}, unlimited);
    auto attempt = solve_attempt(fixture, query, unlimited);
    REQUIRE(attempt.result);
    CHECK(bits(attempt.result.value().schedule()) ==
          std::vector<std::uint8_t>{1U, 0U, 1U});
    CHECK(attempt.accounting.completed_expansions() == mwperf::BigNat(2U));
  }

  SECTION("two-dimensional optimum is a non-greedy combination") {
    const auto fixture = make_fixture(
        4U,
        R"({"resources":["cpu","ram"],"capacity":[4,4],"demands":[{"queue_id":"q0","demand":[4,1]},{"queue_id":"q1","demand":[1,4]},{"queue_id":"q2","demand":[2,2]},{"queue_id":"q3","demand":[2,2]}]})");
    const auto query = make_query(fixture, naturals({7U, 7U, 6U, 6U}),
                                  {1U, 1U, 1U, 1U}, unlimited);
    auto attempt = solve_attempt(fixture, query, unlimited);
    REQUIRE(attempt.result);
    CHECK(bits(attempt.result.value().schedule()) ==
          std::vector<std::uint8_t>{0U, 0U, 1U, 1U});
  }
}

TEST_CASE("C08 packing memo hits and base calls have exact golden accounting",
          "[c08][unit][packing][accounting]") {
  const auto fixture = make_fixture(
      3U,
      R"({"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]})");
  const auto unlimited = policy(std::nullopt);
  const auto query = make_query(fixture, naturals({1U, 1U, 1U}),
                                {1U, 1U, 1U}, unlimited);
  auto attempt = instrumented_attempt(fixture, query, unlimited);
  REQUIRE(attempt.result);
  CHECK(bits(attempt.result.value().schedule) ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  CHECK(attempt.accounting.completed_expansions() == mwperf::BigNat(5U));
  CHECK(attempt.instrumentation.expanded_keys.size() == 5U);
  CHECK(attempt.instrumentation.base_calls == 5U);
  CHECK(attempt.instrumentation.memo_hits == 1U);

  for (std::size_t first = 0U;
       first < attempt.instrumentation.expanded_keys.size(); ++first) {
    for (std::size_t second = first + 1U;
         second < attempt.instrumentation.expanded_keys.size(); ++second) {
      CHECK(attempt.instrumentation.expanded_keys[first] !=
            attempt.instrumentation.expanded_keys[second]);
    }
  }
  const std::vector<std::string> expected_capacity{"2", "2", "2", "1",
                                                   "1"};
  for (std::size_t index = 0U; index < expected_capacity.size(); ++index) {
    CHECK(attempt.instrumentation.expanded_keys[index]
              .remaining_capacity()[0U]
              .to_decimal_string() == expected_capacity[index]);
  }
  CHECK(attempt.instrumentation.expanded_keys[0U].queues().test(0U));
  CHECK_FALSE(attempt.instrumentation.expanded_keys[1U].queues().test(0U));
  CHECK(attempt.instrumentation.expanded_keys[4U].queues().test(1U));
  CHECK(attempt.instrumentation.expanded_keys[4U].queues().test(2U));
}

TEST_CASE("C08 packing finite limits fail atomically after an incumbent exists",
          "[c08][unit][negative][packing][accounting]") {
  const auto fixture = make_fixture(
      3U,
      R"({"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]})");

  const auto exact_limit = policy(mwperf::BigNat(5U));
  const auto exact_query = make_query(fixture, naturals({1U, 1U, 1U}),
                                      {1U, 1U, 1U}, exact_limit);
  auto exact = solve_attempt(fixture, exact_query, exact_limit);
  REQUIRE(exact.result);
  CHECK(exact.accounting.completed_expansions() == mwperf::BigNat(5U));

  const auto short_limit = policy(mwperf::BigNat(4U));
  const auto short_query = make_query(fixture, naturals({1U, 1U, 1U}),
                                      {1U, 1U, 1U}, short_limit);
  auto exhausted = solve_attempt(fixture, short_query, short_limit);
  REQUIRE_FALSE(exhausted.result);
  CHECK(exhausted.result.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(exhausted.result.error().code == "search_state_limit_exhausted");
  CHECK(exhausted.accounting.completed_expansions() == mwperf::BigNat(4U));
  CHECK(exhausted.accounting.exhausted());

  SECTION("zero permits no nonbase state and one permits a singleton") {
    const auto singleton = make_fixture(
        1U,
        R"({"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]}]})");
    const auto zero = policy(mwperf::BigNat(0U));
    const auto zero_query = make_query(singleton, naturals({1U}), {1U}, zero);
    auto zero_result = solve_attempt(singleton, zero_query, zero);
    REQUIRE_FALSE(zero_result.result);
    CHECK(zero_result.accounting.completed_expansions().is_zero());

    const auto one = policy(mwperf::BigNat(1U));
    const auto one_query = make_query(singleton, naturals({1U}), {1U}, one);
    auto one_result = solve_attempt(singleton, one_query, one);
    REQUIRE(one_result.result);
    CHECK(one_result.accounting.completed_expansions() == mwperf::BigNat(1U));
  }
}

TEST_CASE("C08 packing forced sides are exact and target weight independent",
          "[c08][unit][packing][forced-target]") {
  const auto fixture = make_fixture(
      5U,
      R"({"resources":["r0","r1"],"capacity":[3,3],"demands":[{"queue_id":"q0","demand":[2,3]},{"queue_id":"q1","demand":[1,0]},{"queue_id":"q2","demand":[0,1]},{"queue_id":"q3","demand":[2,2]},{"queue_id":"q4","demand":[0,0]}]})");
  const auto unlimited = policy(std::nullopt);
  const auto query = make_query(fixture, naturals({1000U, 5U, 4U, 8U, 2U}),
                                {0U, 1U, 1U, 1U, 1U}, unlimited);
  auto zero = forced_attempt(fixture, query, unlimited,
                             mwperf::ForcedTargetBit::zero);
  auto one = forced_attempt(fixture, query, unlimited,
                            mwperf::ForcedTargetBit::one);
  REQUIRE(zero.result);
  REQUIRE(one.result);
  CHECK(zero.calls_reserved == mwperf::BigNat(1U));
  CHECK(one.calls_reserved == mwperf::BigNat(1U));
  CHECK(zero.result.value().value == mwperf::BigNat(19U));
  CHECK(one.result.value().value == mwperf::BigNat(7U));
  CHECK(bits(zero.result.value().witness) ==
        std::vector<std::uint8_t>{0U, 1U, 1U, 1U, 1U});
  CHECK(bits(one.result.value().witness) ==
        std::vector<std::uint8_t>{1U, 1U, 0U, 0U, 1U});

  auto changed_values = naturals({0U, 5U, 4U, 8U, 2U});
  changed_values[0U] = power_of_two(190U);
  const auto changed = make_query(fixture, std::move(changed_values),
                                  {0U, 1U, 1U, 1U, 1U}, unlimited);
  auto changed_zero = forced_attempt(fixture, changed, unlimited,
                                     mwperf::ForcedTargetBit::zero);
  auto changed_one = forced_attempt(fixture, changed, unlimited,
                                    mwperf::ForcedTargetBit::one);
  REQUIRE(changed_zero.result);
  REQUIRE(changed_one.result);
  CHECK(changed_zero.result.value().value == zero.result.value().value);
  CHECK(changed_one.result.value().value == one.result.value().value);
  CHECK(bits(changed_zero.result.value().witness) ==
        bits(zero.result.value().witness));
  CHECK(bits(changed_one.result.value().witness) ==
        bits(one.result.value().witness));
}

TEST_CASE("C08 packing forced infeasibility exhaustion and equality stay distinct",
          "[c08][negative][packing][forced-target]") {
  SECTION("forced one can be structurally infeasible") {
    const auto fixture = make_fixture(
        2U,
        R"({"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[2]},{"queue_id":"q1","demand":[0]}]})");
    const auto unlimited = policy(std::nullopt);
    const auto query = make_query(fixture, naturals({3U, 1U}), {0U, 1U},
                                  unlimited);
    auto result = forced_attempt(fixture, query, unlimited,
                                 mwperf::ForcedTargetBit::one);
    REQUIRE_FALSE(result.result);
    CHECK(result.result.error().category ==
          mwperf::DiagnosticCategory::unavailable);
    CHECK(result.result.error().code == "infeasible_side");
    CHECK(result.calls_reserved == mwperf::BigNat(1U));
  }

  SECTION("one-less forced budget reports exhaustion, not infeasibility") {
    const auto fixture = make_fixture(
        3U,
        R"({"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[0]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]})");
    const auto unlimited = policy(std::nullopt);
    const auto unlimited_query = make_query(
        fixture, naturals({9U, 2U, 1U}), {0U, 1U, 1U}, unlimited);
    auto exact = forced_attempt(fixture, unlimited_query, unlimited,
                                mwperf::ForcedTargetBit::one);
    REQUIRE(exact.result);
    const mwperf::BigNat required =
        exact.result.value().accounting.completed_expansions();
    REQUIRE(required > mwperf::BigNat(0U));
    auto one_less = mwperf::checked_subtract(required, mwperf::BigNat(1U));
    REQUIRE(one_less);
    const auto finite = policy(one_less.value());
    const auto finite_query = make_query(
        fixture, naturals({9U, 2U, 1U}), {0U, 1U, 1U}, finite);
    auto exhausted = forced_attempt(fixture, finite_query, finite,
                                    mwperf::ForcedTargetBit::one);
    REQUIRE_FALSE(exhausted.result);
    CHECK(exhausted.result.error().code == "search_state_limit_exhausted");
    CHECK(exhausted.calls_reserved == mwperf::BigNat(1U));
    CHECK(std::ranges::find(exhausted.result.error().notes,
                            "query kind: forced_one") !=
          exhausted.result.error().notes.end());
  }

  SECTION("faulted equal scores never choose an implicit branch") {
    const auto fixture = make_fixture(
        1U,
        R"({"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]}]})");
    const auto unlimited = policy(std::nullopt);
    const auto query = make_query(fixture, naturals({1U}), {1U}, unlimited);
    auto faulted = instrumented_attempt(
        fixture, query, unlimited,
        mwperf::detail::PackingSolveFault::force_distinct_branch_score_equality);
    REQUIRE_FALSE(faulted.result);
    CHECK(faulted.result.error().code ==
          "packing_composite_equality_invariant");
  }
}

TEST_CASE("C08 packing rejects malformed authored compiled and memo records",
          "[c08][negative][packing][compile]") {
  SECTION("negative capacity") {
    auto result = parse_attempt(
        1U,
        R"({"resources":["r"],"capacity":[-1],"demands":[{"queue_id":"q0","demand":[0]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "integer_negative");
  }
  SECTION("negative demand") {
    auto result = parse_attempt(
        1U,
        R"({"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[-1]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "integer_negative");
  }
  SECTION("capacity dimension") {
    auto result = compile_attempt(
        1U,
        R"({"resources":["r0","r1"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[0,0]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_capacity_dimension");
  }
  SECTION("demand dimension") {
    auto result = compile_attempt(
        1U,
        R"({"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_demand_dimension");
  }
  SECTION("unknown queue") {
    auto result = compile_attempt(
        1U,
        R"({"resources":[],"capacity":[],"demands":[{"queue_id":"missing","demand":[]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "unknown_queue_reference");
  }
  SECTION("missing queue row") {
    auto result = compile_attempt(
        2U,
        R"({"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }
  SECTION("duplicate resource") {
    auto result = compile_attempt(
        1U,
        R"({"resources":["r","r"],"capacity":[1,1],"demands":[{"queue_id":"q0","demand":[0,0]}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_packing_resource");
  }

  const auto fixture = make_fixture(
      2U,
      R"({"resources":["r0","r1"],"capacity":[2,3],"demands":[{"queue_id":"q0","demand":[1,0]},{"queue_id":"q1","demand":[0,1]}]})");
  const auto& resolved = std::get<mwperf::ResolvedPackingConstraint>(
      fixture.descriptor.value());

  SECTION("C08 rechecks resource order") {
    auto corrupt = resolved;
    corrupt.resources[1U].index = corrupt.resources[0U].index;
    auto result = mwperf::compile_packing_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_compiled_resource_order_invalid");
  }
  SECTION("C08 rechecks demand dimension") {
    auto corrupt = resolved;
    corrupt.demands[0U].demand.pop_back();
    auto result = mwperf::compile_packing_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "packing_compiled_demand_dimension_mismatch");
  }
  SECTION("C08 rechecks queue coverage") {
    auto corrupt = resolved;
    corrupt.demands[1U].queue = corrupt.demands[0U].queue;
    auto result = mwperf::compile_packing_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_compiled_queue_coverage_invalid");
  }
  SECTION("normalization rejects malformed subset") {
    auto malformed = mwperf::QueueSubset::for_test_unchecked(
        2U, {std::uint64_t{1U} << 63U});
    auto result = mwperf::normalize_packing_subproblem(
        fixture.problem, std::move(malformed), fixture.problem.capacity());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_memo_queue_subset_invalid");
  }
  SECTION("normalization rejects capacity dimension") {
    auto subset = mwperf::QueueSubset::from_bytes(
        std::vector<std::uint8_t>{1U, 1U});
    REQUIRE(subset);
    auto result = mwperf::normalize_packing_subproblem(
        fixture.problem, std::move(subset).value(),
        mwperf::CapacityVector::from_values({mwperf::BigNat(2U)}));
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "packing_memo_capacity_dimension_mismatch");
  }
}
