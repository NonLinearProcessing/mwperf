#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/stationary/analytic.hpp"

namespace {

using mwperf::AnalyticStationaryStatusV1;
using mwperf::ArrivalFamily;
using mwperf::ArrivalPhaseIdentityV1;
using mwperf::BigInt;
using mwperf::BigNat;
using mwperf::ExactPhaseArrivalBlockV1;
using mwperf::ExactRational;
using mwperf::FixedPointIdSelection;
using mwperf::FixedPointLaw;
using mwperf::FixedPointSelection;
using mwperf::FixedPointTerminationV1;
using mwperf::FixedPointUniqueSelection;
using mwperf::LinearMethod;
using mwperf::PhaseCompletionAtomV1;
using mwperf::PhaseLevelCompletionKindV1;
using mwperf::PhaseLevelCompletionV1;
using mwperf::SelectionSpec;
using mwperf::SolverPolicy;
using mwperf::SourceLocation;
using mwperf::SourceNode;
using mwperf::StationaryClassSelection;
using mwperf::StationaryMixtureComponent;
using mwperf::StationaryMixtureSelection;
using mwperf::StationaryUniqueSelection;
using mwperf::testing::C19FixtureAccess;
using mwperf::testing::ExactFixedPointFixtureV1;
using mwperf::testing::ExactPhaseResponseFixtureV1;

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator = 1) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto value = mwperf::sha256(
      std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] SourceNode source(const std::string& pointer) {
  return SourceNode::make_null(
      SourceLocation{"c19-markov-additive-test", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] ArrivalPhaseIdentityV1 phase(const std::uint8_t ordinal) {
  return {ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::TypedLabel class_id(const std::uint64_t ordinal) {
  return mwperf::TypedLabel::numeric(BigNat{ordinal});
}

[[nodiscard]] mwperf::TypedLabel fixed_point_id(const std::string& name) {
  auto id = mwperf::TypedLabel::text(name);
  REQUIRE(id);
  return std::move(id).value();
}

[[nodiscard]] mwperf::AuthoredProbability probability(
    const ExactRational& value) {
  auto result = mwperf::AuthoredProbability::from_exact(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SelectionSpec stationary_unique_selection() {
  return StationaryUniqueSelection{source("/selection/stationary-unique")};
}

[[nodiscard]] SelectionSpec stationary_class_selection(
    const std::uint64_t ordinal) {
  return StationaryClassSelection{
      class_id(ordinal), source("/selection/stationary-class")};
}

[[nodiscard]] SelectionSpec equal_stationary_mixture() {
  return StationaryMixtureSelection{
      {{class_id(0U), probability(rational(1, 2)),
        source("/selection/mixture/0")},
       {class_id(1U), probability(rational(1, 2)),
        source("/selection/mixture/1")}},
      source("/selection/mixture")};
}

[[nodiscard]] SelectionSpec fixed_unique_selection() {
  return FixedPointSelection{
      FixedPointUniqueSelection{source("/selection/fixed-unique")}};
}

[[nodiscard]] SelectionSpec fixed_id_selection(const std::string& name) {
  return FixedPointSelection{FixedPointIdSelection{
      fixed_point_id(name), source("/selection/fixed-id")}};
}

[[nodiscard]] SolverPolicy policy(
    const std::uint64_t maximum_evaluations = 64U,
    const ExactRational& tolerance = rational(1, 1024)) {
  return {LinearMethod::dense_pivoted, BigNat{maximum_evaluations}, tolerance,
          ExactRational::zero(), digest("c19.markov-fixed.policy")};
}

[[nodiscard]] ExactPhaseArrivalBlockV1 block(
    const std::uint64_t arrivals,
    std::vector<ExactRational> entries) {
  return {BigNat{arrivals}, std::move(entries)};
}

[[nodiscard]] PhaseLevelCompletionV1 exact_closed(
    const std::uint64_t maximum_level) {
  return {PhaseLevelCompletionKindV1::exact_closed, BigNat{maximum_level},
          std::nullopt, {}};
}

[[nodiscard]] ExactPhaseResponseFixtureV1 alternating_phase_fixture() {
  return {
      {phase(0U), phase(1U)},
      {block(0U, {rational(0), rational(0), rational(1), rational(0)}),
       block(1U,
             {rational(0), rational(1), rational(0), rational(0)})},
      {rational(1, 2), rational(1, 2)},
      {rational(0), rational(0), rational(1), rational(1)},
      exact_closed(1U)};
}

[[nodiscard]] ExactPhaseResponseFixtureV1 reducible_phase_fixture() {
  return {{phase(0U), phase(1U)},
          {block(0U,
                 {rational(1), rational(0), rational(0), rational(1)})},
          {rational(1, 2), rational(1, 2)},
          {rational(0), rational(0)},
          exact_closed(0U)};
}

[[nodiscard]] ExactPhaseResponseFixtureV1 non_dyadic_phase_fixture() {
  return {{phase(0U)},
          {block(0U, {rational(1, 2)}), block(1U, {rational(1, 2)})},
          {rational(1)},
          {rational(0), rational(2, 3)},
          {PhaseLevelCompletionKindV1::additive_completion, BigNat{1U},
           digest("c19.phase.non-dyadic-completion"),
           {PhaseCompletionAtomV1{1U, 1U, rational(1, 6)}}}};
}

void require_exact_mass(const FixedPointLaw& law,
                        const ExactRational& expected) {
  REQUIRE(law.parameters().size() == 1U);
  CHECK(law.parameters().front() == expected);
}

}  // namespace

TEST_CASE("C19 alternating Markov-additive law satisfies SF.26 and SF.27a",
          "[c19][unit][markov-additive][sf26][sf27a]") {
  auto flux = C19FixtureAccess::phase_flux(alternating_phase_fixture());
  REQUIRE(flux);
  CHECK(flux.value().identity().payload_phase() ==
        mwperf::PayloadPhaseKindV1::predictive_phase_indexed);
  CHECK(flux.value().phase_count() == 2U);
  CHECK(flux.value().maximum_level() == BigNat{1U});

  auto zero_to_one = flux.value().transition_probability(
      BigNat{0U}, 0U, BigNat{1U}, 1U);
  auto one_to_zero = flux.value().transition_probability(
      BigNat{1U}, 1U, BigNat{0U}, 0U);
  REQUIRE(zero_to_one);
  REQUIRE(one_to_zero);
  CHECK(zero_to_one.value() == ExactRational::one());
  CHECK(one_to_zero.value() == ExactRational::one());

  auto law = mwperf::solve_markov_additive_stationary(
      flux.value(), stationary_unique_selection(), policy());
  REQUIRE(law);
  CHECK(law.value().status() == AnalyticStationaryStatusV1::finite);

  auto mass_00 = law.value().mass(BigNat{0U}, 0U);
  auto mass_11 = law.value().mass(BigNat{1U}, 1U);
  auto mass_01 = law.value().mass(BigNat{0U}, 1U);
  auto mass_10 = law.value().mass(BigNat{1U}, 0U);
  REQUIRE(mass_00);
  REQUIRE(mass_11);
  REQUIRE(mass_01);
  REQUIRE(mass_10);
  CHECK(mass_00.value() == 0.5L);
  CHECK(mass_11.value() == 0.5L);
  CHECK(mass_01.value() == 0.0L);
  CHECK(mass_10.value() == 0.0L);

  REQUIRE(law.value().phase_marginal().size() == 2U);
  for (const auto& marginal : law.value().phase_marginal()) {
    CHECK(marginal.invariant_mass == 0.5L);
    CHECK(marginal.configured_mass == 0.5L);
    CHECK(marginal.residual == 0.0L);
  }
}

TEST_CASE("C19 SF.26 left-multiplies each arrival block by D_n",
          "[c19][unit][markov-additive][noncommuting]") {
  ExactPhaseResponseFixtureV1 fixture{
      {phase(0U), phase(1U)},
      {block(0U,
             {rational(1, 2), rational(0), rational(0), rational(1, 4)}),
       block(1U,
             {rational(0), rational(1, 2), rational(3, 4), rational(0)})},
      {rational(3, 5), rational(2, 5)},
      {rational(0), rational(0), rational(1, 4), rational(3, 4),
       rational(1), rational(1)},
      exact_closed(2U)};

  auto flux = C19FixtureAccess::phase_flux(std::move(fixture));
  REQUIRE(flux);
  const std::vector<ExactRational> expected{
      rational(3, 8), rational(1, 8), rational(9, 16), rational(1, 16)};
  const std::vector<ExactRational> right_multiplied{
      rational(3, 8), rational(3, 8), rational(3, 16), rational(1, 16)};
  for (std::size_t source_phase = 0U; source_phase < 2U; ++source_phase) {
    for (std::size_t destination_phase = 0U; destination_phase < 2U;
         ++destination_phase) {
      const std::size_t index = source_phase * 2U + destination_phase;
      auto entry = flux.value().transition_probability(
          BigNat{1U}, source_phase, BigNat{1U}, destination_phase);
      REQUIRE(entry);
      CHECK(entry.value() == expected[index]);
      if (expected[index] != right_multiplied[index]) {
        CHECK(entry.value() != right_multiplied[index]);
      }
    }
  }
}

TEST_CASE("C19 finite phase cutoff requires an exact declared completion",
          "[c19][unit][markov-additive][completion]") {
  const auto leaking = [] {
    return ExactPhaseResponseFixtureV1{
        {phase(0U)}, {block(1U, {rational(1)})}, {rational(1)},
        {rational(0)}, exact_closed(0U)};
  };

  auto rejected = C19FixtureAccess::phase_flux(leaking());
  CHECK_FALSE(rejected);

  auto completed = leaking();
  completed.completion =
      PhaseLevelCompletionV1{PhaseLevelCompletionKindV1::additive_completion,
                             BigNat{0U}, digest("c19.phase.completion"),
                             {PhaseCompletionAtomV1{0U, 0U, rational(1)}}};
  auto flux = C19FixtureAccess::phase_flux(std::move(completed));
  REQUIRE(flux);
  auto self = flux.value().transition_probability(
      BigNat{0U}, 0U, BigNat{0U}, 0U);
  REQUIRE(self);
  CHECK(self.value() == ExactRational::one());

  auto incomplete = leaking();
  incomplete.completion =
      PhaseLevelCompletionV1{PhaseLevelCompletionKindV1::additive_completion,
                             BigNat{0U}, digest("c19.phase.completion"),
                             {PhaseCompletionAtomV1{0U, 0U,
                                                    rational(1, 2)}}};
  CHECK_FALSE(C19FixtureAccess::phase_flux(std::move(incomplete)));
}

TEST_CASE("C19 phase blocks and response obey the SF.26 dimensions",
          "[c19][unit][markov-additive][sf26][negative]") {
  auto wrong_block_dimension = alternating_phase_fixture();
  wrong_block_dimension.arrival_blocks.front().row_major.pop_back();
  CHECK_FALSE(C19FixtureAccess::phase_flux(
      std::move(wrong_block_dimension)));

  auto nonzero_empty_service = alternating_phase_fixture();
  nonzero_empty_service.service_row_major.front() = rational(1, 2);
  CHECK_FALSE(C19FixtureAccess::phase_flux(
      std::move(nonzero_empty_service)));
}

TEST_CASE("C19 additive completion preserves leaked next-phase mass",
          "[c19][unit][markov-additive][completion][negative]") {
  ExactPhaseResponseFixtureV1 wrong_destination_phase{
      {phase(0U), phase(1U)},
      {block(1U,
             {rational(1), rational(0), rational(0), rational(1)})},
      {rational(1, 2), rational(1, 2)},
      {rational(0), rational(0)},
      PhaseLevelCompletionV1{
          PhaseLevelCompletionKindV1::additive_completion, BigNat{0U},
          digest("c19.phase.destination-completion"),
          {PhaseCompletionAtomV1{0U, 1U, rational(1)},
           PhaseCompletionAtomV1{1U, 0U, rational(1)}}}};

  CHECK_FALSE(C19FixtureAccess::phase_flux(
      std::move(wrong_destination_phase)));
}

TEST_CASE("C19 reducible phase laws require selection and SF.27a agreement",
          "[c19][unit][markov-additive][selection][sf27a]") {
  auto flux = C19FixtureAccess::phase_flux(reducible_phase_fixture());
  REQUIRE(flux);

  CHECK_FALSE(mwperf::solve_markov_additive_stationary(
      flux.value(), stationary_unique_selection(), policy()));
  CHECK_FALSE(mwperf::solve_markov_additive_stationary(
      flux.value(), stationary_class_selection(0U), policy()));
  CHECK_FALSE(mwperf::solve_markov_additive_stationary(
      flux.value(), stationary_class_selection(99U), policy()));

  auto mixture = mwperf::solve_markov_additive_stationary(
      flux.value(), equal_stationary_mixture(), policy());
  REQUIRE(mixture);
  CHECK(mixture.value().status() == AnalyticStationaryStatusV1::finite);
  auto first = mixture.value().mass(BigNat{0U}, 0U);
  auto second = mixture.value().mass(BigNat{0U}, 1U);
  REQUIRE(first);
  REQUIRE(second);
  CHECK(first.value() == 0.5L);
  CHECK(second.value() == 0.5L);
  REQUIRE(mixture.value().selected_classes().size() == 2U);
  CHECK(mixture.value().selected_classes()[0].class_id == class_id(0U));
  CHECK(mixture.value().selected_classes()[0].exact_weight == rational(1, 2));
  CHECK(mixture.value().selected_classes()[1].class_id == class_id(1U));
  CHECK(mixture.value().selected_classes()[1].exact_weight == rational(1, 2));
  REQUIRE(mixture.value().phase_marginal().size() == 2U);
  for (const auto& marginal : mixture.value().phase_marginal()) {
    CHECK(marginal.invariant_mass == 0.5L);
    CHECK(marginal.configured_mass == 0.5L);
    CHECK(marginal.residual == 0.0L);
  }
}

TEST_CASE("C19 phase diagnostics measure the numerical SF.27 image",
          "[c19][unit][markov-additive][sf27][residual]") {
  auto flux = C19FixtureAccess::phase_flux(non_dyadic_phase_fixture());
  REQUIRE(flux);
  auto law = mwperf::solve_markov_additive_stationary(
      flux.value(), stationary_unique_selection(), policy());
  REQUIRE(law);

  auto mass_zero = law.value().mass(BigNat{0U}, 0U);
  auto mass_one = law.value().mass(BigNat{1U}, 0U);
  REQUIRE(mass_zero);
  REQUIRE(mass_one);
  CHECK(mass_zero.value() == rational(2, 5).to_long_double());
  CHECK(mass_one.value() == rational(3, 5).to_long_double());

  const auto& diagnostics = law.value().diagnostics();
  CHECK(std::fabs(diagnostics.normalization_residual) <=
        diagnostics.normalization_bound);
  CHECK(diagnostics.l1_invariance_residual <=
        diagnostics.l1_invariance_bound);
  CHECK(diagnostics.maximum_invariance_residual <=
        diagnostics.maximum_invariance_bound);
  CHECK(diagnostics.maximum_invariance_residual > 0.0L);

  const long double residual_zero =
      mass_zero.value() * rational(1, 2).to_long_double() +
      mass_one.value() * rational(1, 3).to_long_double() - mass_zero.value();
  const long double residual_one =
      mass_zero.value() * rational(1, 2).to_long_double() +
      mass_one.value() * rational(2, 3).to_long_double() - mass_one.value();
  const long double expected_maximum =
      std::max(std::fabs(residual_zero), std::fabs(residual_one));
  CHECK(std::fabs(diagnostics.maximum_invariance_residual - expected_maximum) <=
        4.0L * std::numeric_limits<long double>::epsilon());

  REQUIRE(diagnostics.class_solves.size() == 1U);
  CHECK(std::fabs(diagnostics.class_solves.front().normalization_residual) <=
        diagnostics.class_solves.front().normalization_bound);
  CHECK(diagnostics.class_solves.front().l1_invariance_residual <=
        diagnostics.class_solves.front().l1_invariance_bound);
  CHECK(diagnostics.class_solves.front().maximum_invariance_residual > 0.0L);
  REQUIRE(law.value().phase_marginal().size() == 1U);
  CHECK(law.value().phase_marginal().front().residual ==
        diagnostics.normalization_residual);
  CHECK(std::fabs(law.value().phase_marginal().front().residual) <=
        law.value().phase_marginal().front().residual_bound);
}

TEST_CASE("C19 declared fixed points are cold deterministic and selected",
          "[c19][unit][fixed-point][sf37]") {
  const auto affine = [] {
    return ExactFixedPointFixtureV1{
        {rational(0)}, {rational(1)}, {rational(0)},
        true,          {},
        [](const std::span<const ExactRational> value) {
          return mwperf::Result<std::vector<ExactRational>>::success(
              {rational(1, 4) + rational(1, 2) * value.front()});
        }};
  };
  const SolverPolicy affine_policy = policy(64U, rational(1, 1024));

  auto first = C19FixtureAccess::fixed_point_law(
      affine(), fixed_unique_selection(), affine_policy);
  REQUIRE(first);
  CHECK(first.value().identity().payload_phase() ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(first.value().termination() == FixedPointTerminationV1::converged);
  REQUIRE(first.value().parameters().size() == 1U);
  const ExactRational eta = first.value().parameters().front();
  CHECK(eta < rational(1, 2));
  CHECK(first.value().fixed_point_residual() ==
        rational(1, 4) - rational(1, 2) * eta);
  CHECK(first.value().iterate_difference() ==
        rational(2) * first.value().fixed_point_residual());
  CHECK(first.value().fixed_point_residual() <= rational(1, 1024));

  auto identity_unique = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(1, 3)},
       false, {{fixed_point_id("one-third"), {rational(1, 3)}}},
       [](const std::span<const ExactRational> value) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {value.front()});
       }},
      fixed_unique_selection(), policy(8U, rational(0)));
  CHECK_FALSE(identity_unique);

  auto identity_selected = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(1, 3)},
       false, {{fixed_point_id("one-third"), {rational(1, 3)}}},
       [](const std::span<const ExactRational> value) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {value.front()});
       }},
      fixed_id_selection("one-third"), policy(8U, rational(0)));
  REQUIRE(identity_selected);
  CHECK(identity_selected.value().termination() ==
        FixedPointTerminationV1::converged);
  require_exact_mass(identity_selected.value(), rational(1, 3));
  CHECK(identity_selected.value().iterate_difference().is_zero());
  CHECK(identity_selected.value().fixed_point_residual().is_zero());

  auto unknown_identity = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(1, 3)},
       false, {{fixed_point_id("one-third"), {rational(1, 3)}}},
       [](const std::span<const ExactRational> value) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {value.front()});
       }},
      fixed_id_selection("unknown"), policy(8U, rational(0)));
  CHECK_FALSE(unknown_identity);

  auto different_selected_root = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(1, 3)},
       false, {{fixed_point_id("one"), {rational(1)}}},
       [](const std::span<const ExactRational> value) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {value.front()});
       }},
      fixed_id_selection("one"), policy(8U, rational(0)));
  REQUIRE(different_selected_root);
  CHECK(different_selected_root.value().termination() ==
        FixedPointTerminationV1::selected_root_unavailable);
  require_exact_mass(different_selected_root.value(), rational(1, 3));
  CHECK(different_selected_root.value().fixed_point_residual().is_zero());

  auto image_outside_domain = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(0)},
       true, {},
       [](const std::span<const ExactRational>) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {rational(2)});
       }},
      fixed_unique_selection(), policy(8U, rational(0)));
  CHECK_FALSE(image_outside_domain);

  auto oscillating = C19FixtureAccess::fixed_point_law(
      {{rational(0)}, {rational(1)}, {rational(0)},
       true, {},
       [](const std::span<const ExactRational> value) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {ExactRational::one() - value.front()});
       }},
      fixed_unique_selection(), policy(6U, rational(0)));
  REQUIRE(oscillating);
  CHECK(oscillating.value().termination() ==
        FixedPointTerminationV1::iteration_budget_exhausted);
  CHECK(oscillating.value().evaluation_count() == BigNat{6U});
  CHECK(oscillating.value().iterate_difference() == ExactRational::one());
  CHECK(oscillating.value().fixed_point_residual() == ExactRational::one());
  REQUIRE(oscillating.value().parameters().size() == 1U);
  CHECK((oscillating.value().parameters().front().is_zero() ||
         oscillating.value().parameters().front() == ExactRational::one()));
  CHECK(oscillating.value().parameters().front() != rational(1, 2));

  auto second = C19FixtureAccess::fixed_point_law(
      affine(), fixed_unique_selection(), affine_policy);
  REQUIRE(second);
  CHECK(second.value().termination() == first.value().termination());
  CHECK(second.value().parameters().front() ==
        first.value().parameters().front());
  CHECK(second.value().iterate_difference() ==
        first.value().iterate_difference());
  CHECK(second.value().fixed_point_residual() ==
        first.value().fixed_point_residual());
  CHECK(second.value().iteration_count() == first.value().iteration_count());
  CHECK(second.value().evaluation_count() == first.value().evaluation_count());
}
