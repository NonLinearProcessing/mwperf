#include <algorithm>
#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/private_markov_renewal.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

using PrivateStepSignature = mwperf::Result<mwperf::ArrivalStep> (*)(
    mwperf::PrivateMarkovCursor&, const mwperf::BigNat&);

static_assert(std::same_as<decltype(&mwperf::next_private_markov_batch),
                           PrivateStepSignature>);
static_assert(
    std::same_as<mwperf::PrivateMarkovCursor, mwperf::ArrivalProcess>);
static_assert(!std::is_default_constructible_v<mwperf::PrivateMarkovLaw>);
static_assert(std::is_copy_constructible_v<mwperf::PrivateMarkovLaw>);

struct ParsedPrivate final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> serial{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c11-private";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("private-" + std::to_string(serial.fetch_add(1U)) +
                   ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output << text;
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedPrivate parse_private(const std::string_view arrival) {
  const std::string text =
      R"json({"switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"},{"id":"q3"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2","q3"],"max_search_states":null}},"arrival":)json" +
      std::string(arrival) + "}";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto executable = mwperf::extract_executable_model(document.value());
  REQUIRE(executable);
  auto model = mwperf::parse_model_config_v3(executable.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedPrivate{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::IndependentPrivateMarkovRenewalArrival& authored(
    ParsedPrivate& parsed) {
  return std::get<mwperf::IndependentPrivateMarkovRenewalArrival>(
      parsed.model.arrival.value);
}

[[nodiscard]] mwperf::CompiledArrivalLaw publish(
    const ParsedPrivate& parsed) {
  auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  REQUIRE(law.value().family() ==
          mwperf::ArrivalFamily::independent_private_markov_renewal);
  return std::move(law).value();
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(
      "a0a1a2a3a4a5a6a7a8a9aaabacadaeaf"
      "b0b1b2b3b4b5b6b7b8b9babbbcbdbebf");
  if (!digest) {
    throw std::logic_error("invalid private-Markov fixture digest");
  }
  return std::move(digest).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t instance) {
  auto key = mwperf::make_physical_reference_instance_key(
      fixture_digest(), mwperf::BigNat(instance));
  if (!key) {
    throw std::logic_error("invalid private-Markov fixture instance key");
  }
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::SourceNode initial_source_node() {
  return mwperf::SourceNode::make_object(
      std::vector<mwperf::SourceObjectMember>{},
      mwperf::SourceLocation{"c11-private-unit", 1U, 1U, 0U},
      "/arrival_state");
}

[[nodiscard]] mwperf::ArrivalInitialState private_states(
    const std::initializer_list<std::pair<std::string_view,
                                          std::string_view>> states) {
  std::vector<mwperf::PrivateMarkovState> values;
  values.reserve(states.size());
  for (const auto& [source, state] : states) {
    values.push_back(mwperf::PrivateMarkovState{
        std::string(source), std::string(state), initial_source_node()});
  }
  return mwperf::ArrivalInitialState(
      mwperf::PrivateMarkovStates{std::move(values)});
}

[[nodiscard]] mwperf::ArrivalProcess make_process(
    const mwperf::CompiledArrivalLaw& law,
    mwperf::ArrivalInitialState initial, const std::uint64_t seed = 11011U,
    const std::uint64_t instance = 0U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, instance));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, initial, std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto result = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::uint64_t count_at(const mwperf::ArrivalBatch& batch,
                                     const std::size_t queue) {
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    if (entry.queue.ordinal() == queue) {
      return entry.count.value().convert_to<std::uint64_t>();
    }
  }
  return 0U;
}

[[nodiscard]] bool has_any_arrival(const mwperf::ArrivalBatch& batch) {
  return !batch.empty_batch();
}

void check_same_step(const mwperf::ArrivalStep& left,
                     const mwperf::ArrivalStep& right) {
  CHECK(left.authored_slot == right.authored_slot);
  CHECK(left.batch == right.batch);
  CHECK(left.law_digest == right.law_digest);
  // The C09 realization identity deliberately includes the supplied vector
  // encoding. This test permutes that encoding to verify C11 maps states and
  // consumes draws in authored law order, so only the resulting path should
  // coincide.
  CHECK(mwperf::arrival_phase_digest(left.phase_before) ==
        mwperf::arrival_phase_digest(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_after) ==
        mwperf::arrival_phase_digest(right.phase_after));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(left.phase_before),
      mwperf::arrival_phase_canonical_state(right.phase_before)));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(left.phase_after),
      mwperf::arrival_phase_canonical_state(right.phase_after)));
}

[[nodiscard]] mwperf::AuthoredProbability probability(
    const std::int64_t numerator, const std::int64_t denominator) {
  auto exact = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                           mwperf::BigInt(denominator));
  REQUIRE(exact);
  auto value =
      mwperf::AuthoredProbability::from_exact(std::move(exact).value());
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& text) {
  auto label = mwperf::TypedLabel::text(text);
  REQUIRE(label);
  return std::move(label).value();
}

void expect_compile_error(
    const mwperf::IndependentPrivateMarkovRenewalArrival& value,
    const mwperf::QueueCatalog& queues, const std::string_view code) {
  auto result = mwperf::compile_private_markov_renewal(value, queues);
  INFO((result ? std::string("unexpected successful compilation")
               : result.error().code + ": " + result.error().message));
  REQUIRE_FALSE(result);
  CHECK(result.error().code == code);
}

constexpr std::string_view kDefensiveFixture = R"json({
  "family":"independent_private_markov_renewal",
  "sources":[{
    "id":"source-a",
    "states":["a","b"],
    "initial":{"distribution":[
      {"state":"a","probability":0.5},
      {"state":"b","probability":0.5}]},
    "gaps":[{"state":"a","d":1},{"state":"b","d":3}],
    "transitions":[
      {"state":"a","next_state":"a","probability":1},
      {"state":"b","next_state":"b","probability":1}],
    "destination_pmf":[
      {"queue_id":"q0","probability":0.5},
      {"queue_id":"q1","probability":0.5}]
  }],
  "metadata":{}
})json";

}  // namespace

TEST_CASE("C11 private laws preserve authored tables support and conservative "
          "capabilities",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[
      {"id":"zeta","states":["only"],"initial":{"state":"only"},
       "gaps":[{"state":"only","d":2}],
       "transitions":[{"state":"only","next_state":"only","probability":1}],
       "destination_pmf":[
         {"queue_id":"q0","probability":1},
         {"queue_id":"q1","probability":0}]},
      {"id":"alpha","states":["wait","run"],"initial":{"state":"wait"},
       "gaps":[{"state":"wait","d":5},{"state":"run","d":1}],
       "transitions":[
         {"state":"wait","next_state":"run","probability":1},
         {"state":"run","next_state":"wait","probability":1}],
       "destination_pmf":[
         {"queue_id":"q1","probability":0},
         {"queue_id":"q2","probability":1}]}
    ],"metadata":{}
  })json");

  auto concrete =
      mwperf::compile_private_markov_renewal(authored(parsed), parsed.queues);
  REQUIRE(concrete);
  REQUIRE(concrete.value().sources().size() == 2U);
  CHECK(concrete.value().sources()[0U].source_id == "zeta");
  CHECK(concrete.value().sources()[1U].source_id == "alpha");
  REQUIRE(concrete.value().sources()[1U].states.size() == 2U);
  CHECK(concrete.value().sources()[1U].states[0U].state_id == "wait");
  CHECK(concrete.value().sources()[1U].states[0U].gap ==
        mwperf::BigNat(5U));
  CHECK(concrete.value().sources()[1U].states[1U].state_id == "run");
  CHECK(concrete.value().sources()[1U].states[1U].gap ==
        mwperf::BigNat(1U));

  const auto law = publish(parsed);
  const auto support = mwperf::positive_arrival_support(law);
  CHECK(support.bytes() ==
        std::vector<std::uint8_t>({1U, 0U, 1U, 0U}));

  const auto capabilities = mwperf::arrival_capabilities(law);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());
}

TEST_CASE("C11 supplied private states are not redrawn and select the first "
          "gap",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[{
      "id":"source","states":["fast","slow","forbidden"],
      "initial":{"distribution":[
        {"state":"fast","probability":0.5},
        {"state":"slow","probability":0.5},
        {"state":"forbidden","probability":0}]},
      "gaps":[
        {"state":"fast","d":1},{"state":"slow","d":4},
        {"state":"forbidden","d":2}],
      "transitions":[
        {"state":"fast","next_state":"fast","probability":1},
        {"state":"slow","next_state":"slow","probability":1},
        {"state":"forbidden","next_state":"forbidden","probability":1}],
      "destination_pmf":[{"queue_id":"q1","probability":1}]
    }],"metadata":{}
  })json");
  const auto law = publish(parsed);

  auto fast = make_process(law, private_states({{"source", "fast"}}),
                           7001U, 2U);
  auto slow = make_process(law, private_states({{"source", "slow"}}),
                           7001U, 2U);
  const auto fast_origin = snapshot(fast);
  const auto slow_origin = snapshot(slow);
  CHECK(fast_origin.rng.consumed_words().is_zero());
  CHECK(slow_origin.rng.consumed_words().is_zero());
  CHECK_FALSE(fast_origin.phase_digest == slow_origin.phase_digest);

  auto fast_zero =
      mwperf::next_private_markov_batch(fast, mwperf::BigNat(0U));
  REQUIRE(fast_zero);
  CHECK(count_at(fast_zero.value().batch, 1U) == 1U);

  for (std::uint64_t slot = 0U; slot < 3U; ++slot) {
    auto step =
        mwperf::next_private_markov_batch(slow, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(step.value().batch.empty_batch());
    CHECK(snapshot(slow).rng.consumed_words().is_zero());
  }
  auto slow_three =
      mwperf::next_private_markov_batch(slow, mwperf::BigNat(3U));
  REQUIRE(slow_three);
  CHECK(count_at(slow_three.value().batch, 1U) == 1U);
  CHECK(snapshot(slow).rng.consumed_words().is_zero());

  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(7001U, 2U));
  REQUIRE(stream);
  auto forbidden = mwperf::instantiate_arrival_process(
      law, private_states({{"source", "forbidden"}}),
      std::move(stream).value());
  REQUIRE_FALSE(forbidden);
  CHECK(forbidden.error().code ==
        "private_markov_initial_state_zero_probability");
}

TEST_CASE("C11 private D one starts at slot zero and permits consecutive "
          "events",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[{
      "id":"clock","states":["tick"],"initial":{"state":"tick"},
      "gaps":[{"state":"tick","d":1}],
      "transitions":[
        {"state":"tick","next_state":"tick","probability":1}],
      "destination_pmf":[{"queue_id":"q0","probability":1}]
    }],"metadata":{}
  })json");
  const auto law = publish(parsed);
  auto process = make_process(law, private_states({{"clock", "tick"}}));
  for (std::uint64_t slot = 0U; slot < 6U; ++slot) {
    auto step =
        mwperf::next_private_markov_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(count_at(step.value().batch, 0U) == 1U);
    CHECK(step.value().physical_arrival_epoch() == mwperf::BigNat(slot + 1U));
  }
}

TEST_CASE("C11 private events transition before applying the new state gap",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[{
      "id":"alternating","states":["a","b"],"initial":{"state":"a"},
      "gaps":[{"state":"a","d":1},{"state":"b","d":3}],
      "transitions":[
        {"state":"a","next_state":"b","probability":1},
        {"state":"b","next_state":"a","probability":1}],
      "destination_pmf":[{"queue_id":"q0","probability":1}]
    }],"metadata":{}
  })json");
  const auto law = publish(parsed);
  auto process = make_process(
      law, private_states({{"alternating", "a"}}));
  const std::vector<std::uint64_t> expected_slots{0U, 3U, 4U, 7U, 8U};
  for (std::uint64_t slot = 0U; slot <= 8U; ++slot) {
    auto step =
        mwperf::next_private_markov_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(has_any_arrival(step.value().batch) ==
          (std::ranges::find(expected_slots, slot) != expected_slots.end()));
  }
}

TEST_CASE("C11 persistent private chains retain event-index gap correlation",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[{
      "id":"persistent","states":["burst","idle"],
      "initial":{"distribution":[
        {"state":"burst","probability":0.5},
        {"state":"idle","probability":0.5}]},
      "gaps":[{"state":"burst","d":1},{"state":"idle","d":4}],
      "transitions":[
        {"state":"burst","next_state":"burst","probability":1},
        {"state":"idle","next_state":"idle","probability":1}],
      "destination_pmf":[{"queue_id":"q2","probability":1}]
    }],"metadata":{}
  })json");
  const auto law = publish(parsed);
  auto burst = make_process(
      law, private_states({{"persistent", "burst"}}), 991U, 1U);
  auto idle = make_process(
      law, private_states({{"persistent", "idle"}}), 991U, 1U);

  for (std::uint64_t slot = 0U; slot <= 8U; ++slot) {
    auto burst_step =
        mwperf::next_private_markov_batch(burst, mwperf::BigNat(slot));
    auto idle_step =
        mwperf::next_private_markov_batch(idle, mwperf::BigNat(slot));
    REQUIRE(burst_step);
    REQUIRE(idle_step);
    CHECK(count_at(burst_step.value().batch, 2U) == 1U);
    CHECK(has_any_arrival(idle_step.value().batch) ==
          (slot == 3U || slot == 7U));
  }
}

TEST_CASE("C11 private destinations are sampled when scheduled and retained",
          "[c11][unit][private-markov]") {
  const auto fixture = [](const std::uint64_t gap) {
    return std::string(R"json({
      "family":"independent_private_markov_renewal",
      "sources":[{
        "id":"source","states":["state"],"initial":{"state":"state"},
        "gaps":[{"state":"state","d":)json") +
           std::to_string(gap) + R"json(}],
        "transitions":[
          {"state":"state","next_state":"state","probability":1}],
        "destination_pmf":[
          {"queue_id":"q0","probability":0.5},
          {"queue_id":"q1","probability":0.5}]
      }],"metadata":{}
    })json";
  };
  auto fast_parsed = parse_private(fixture(1U));
  auto slow_parsed = parse_private(fixture(3U));
  const auto fast_law = publish(fast_parsed);
  const auto slow_law = publish(slow_parsed);
  auto fast = make_process(fast_law, private_states({{"source", "state"}}),
                           8811U, 9U);
  auto slow = make_process(slow_law, private_states({{"source", "state"}}),
                           8811U, 9U);

  CHECK(snapshot(fast).rng.consumed_words() == mwperf::BigNat(1U));
  CHECK(snapshot(slow).rng.consumed_words() == mwperf::BigNat(1U));
  auto fast_zero =
      mwperf::next_private_markov_batch(fast, mwperf::BigNat(0U));
  REQUIRE(fast_zero);
  CHECK(snapshot(fast).rng.consumed_words() == mwperf::BigNat(2U));

  for (std::uint64_t slot = 0U; slot < 2U; ++slot) {
    auto empty =
        mwperf::next_private_markov_batch(slow, mwperf::BigNat(slot));
    REQUIRE(empty);
    CHECK(empty.value().batch.empty_batch());
    CHECK(snapshot(slow).rng.consumed_words() == mwperf::BigNat(1U));
  }
  auto slow_two =
      mwperf::next_private_markov_batch(slow, mwperf::BigNat(2U));
  REQUIRE(slow_two);
  CHECK(count_at(slow_two.value().batch, 0U) ==
        count_at(fast_zero.value().batch, 0U));
  CHECK(count_at(slow_two.value().batch, 1U) ==
        count_at(fast_zero.value().batch, 1U));
  CHECK(snapshot(slow).rng.consumed_words() == mwperf::BigNat(2U));
}

TEST_CASE("C11 private source-order draws replay independently across cursors",
          "[c11][unit][private-markov]") {
  auto parsed = parse_private(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[
      {"id":"zeta","states":["z"],"initial":{"state":"z"},
       "gaps":[{"state":"z","d":1}],
       "transitions":[{"state":"z","next_state":"z","probability":1}],
       "destination_pmf":[
         {"queue_id":"q0","probability":0.5},
         {"queue_id":"q1","probability":0.5}]},
      {"id":"alpha","states":["a"],"initial":{"state":"a"},
       "gaps":[{"state":"a","d":1}],
       "transitions":[{"state":"a","next_state":"a","probability":1}],
       "destination_pmf":[
         {"queue_id":"q2","probability":0.5},
         {"queue_id":"q3","probability":0.5}]}
    ],"metadata":{}
  })json");
  auto concrete =
      mwperf::compile_private_markov_renewal(authored(parsed), parsed.queues);
  REQUIRE(concrete);
  REQUIRE(concrete.value().sources().size() == 2U);

  constexpr std::uint64_t seed = 42U;
  constexpr std::uint64_t instance = 17U;
  auto expected_rng = configured_rng(seed, instance);
  const auto& first_source = concrete.value().sources()[0U];
  const auto& second_source = concrete.value().sources()[1U];
  const std::size_t first_mark = mwperf::sample_categorical(
      first_source.destination_probabilities, expected_rng);
  const std::size_t second_mark = mwperf::sample_categorical(
      second_source.destination_probabilities, expected_rng);
  REQUIRE(first_mark < first_source.destinations.size());
  REQUIRE(second_mark < second_source.destinations.size());

  const auto law = publish(parsed);
  auto left = make_process(
      law, private_states({{"alpha", "a"}, {"zeta", "z"}}), seed,
      instance);
  auto right = make_process(
      law, private_states({{"zeta", "z"}, {"alpha", "a"}}), seed,
      instance);
  auto noise = make_process(
      law, private_states({{"zeta", "z"}, {"alpha", "a"}}), seed + 1U,
      instance + 1U);
  CHECK(snapshot(left).rng.consumed_words() == mwperf::BigNat(2U));
  CHECK(snapshot(right).rng.consumed_words() == mwperf::BigNat(2U));

  auto left_zero =
      mwperf::next_private_markov_batch(left, mwperf::BigNat(0U));
  auto noise_zero =
      mwperf::next_private_markov_batch(noise, mwperf::BigNat(0U));
  auto right_zero =
      mwperf::next_private_markov_batch(right, mwperf::BigNat(0U));
  REQUIRE(left_zero);
  REQUIRE(noise_zero);
  REQUIRE(right_zero);
  check_same_step(left_zero.value(), right_zero.value());
  CHECK(count_at(left_zero.value().batch,
                 first_source.destinations[first_mark].ordinal()) == 1U);
  CHECK(count_at(left_zero.value().batch,
                 second_source.destinations[second_mark].ordinal()) == 1U);
  CHECK(snapshot(left).rng.consumed_words() == mwperf::BigNat(4U));

  auto right_one =
      mwperf::next_private_markov_batch(right, mwperf::BigNat(1U));
  auto noise_one =
      mwperf::next_private_markov_batch(noise, mwperf::BigNat(1U));
  auto left_one =
      mwperf::next_private_markov_batch(left, mwperf::BigNat(1U));
  REQUIRE(right_one);
  REQUIRE(noise_one);
  REQUIRE(left_one);
  check_same_step(left_one.value(), right_one.value());
}

TEST_CASE("C11 private compiler rejects malformed source state and gap tables",
          "[c11][unit][private-markov][negative]") {
  auto parsed = parse_private(kDefensiveFixture);

  SECTION("empty source set") {
    authored(parsed).sources.value.clear();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_empty_sources");
  }
  SECTION("empty source identifier") {
    authored(parsed).sources.value[0U].id.value.clear();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_source_id_empty");
  }
  SECTION("duplicate source identifier") {
    authored(parsed).sources.value.push_back(
        authored(parsed).sources.value[0U]);
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_source_id");
  }
  SECTION("empty state set") {
    authored(parsed).sources.value[0U].states.value.clear();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_empty_states");
  }
  SECTION("empty state identifier") {
    authored(parsed).sources.value[0U].states.value[0U].value.clear();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_state_id_empty");
  }
  SECTION("duplicate state identifier") {
    authored(parsed).sources.value[0U].states.value[1U].value = "a";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_state_id");
  }
  SECTION("gap references an unknown state") {
    authored(parsed).sources.value[0U].gaps.value[0U].state.value = "other";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_gap_state_unknown");
  }
  SECTION("duplicate gap") {
    authored(parsed).sources.value[0U].gaps.value[1U].state.value = "a";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_state_gap");
  }
  SECTION("zero gap") {
    authored(parsed).sources.value[0U].gaps.value[0U].d.value =
        mwperf::BigNat(0U);
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_nonpositive_gap");
  }
  SECTION("missing gap") {
    authored(parsed).sources.value[0U].gaps.value.pop_back();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_missing_state_gap");
  }
}

TEST_CASE("C11 private compiler rejects malformed initial and transition rows",
          "[c11][unit][private-markov][negative]") {
  auto parsed = parse_private(kDefensiveFixture);
  auto& source = authored(parsed).sources.value[0U];

  SECTION("unknown fixed initial state") {
    source.initial.value = mwperf::InitialExactState{
        mwperf::NormalizedToken{"other", "other", source.id.provenance},
        source.initial.provenance};
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_initial_state_unknown");
  }
  SECTION("empty initial distribution") {
    std::get<mwperf::InitialStateDistribution>(source.initial.value)
        .distribution.value.clear();
    expect_compile_error(authored(parsed), parsed.queues, "pmf_empty");
  }
  SECTION("unknown initial distribution state") {
    auto& distribution =
        std::get<mwperf::InitialStateDistribution>(source.initial.value)
            .distribution.value;
    distribution[1U].state.value = "other";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_initial_state_unknown");
  }
  SECTION("duplicate initial coordinate") {
    auto& distribution =
        std::get<mwperf::InitialStateDistribution>(source.initial.value)
            .distribution.value;
    distribution[1U].state.value = "a";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_initial_coordinate");
  }
  SECTION("incomplete initial coordinate set") {
    auto& distribution =
        std::get<mwperf::InitialStateDistribution>(source.initial.value)
            .distribution.value;
    distribution.erase(distribution.begin() + 1, distribution.end());
    distribution[0U].probability.value = probability(1, 1);
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_initial_distribution_incomplete");
  }
  SECTION("unknown transition current state") {
    source.transitions.value[0U].state.value = "other";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_transition_state_unknown");
  }
  SECTION("unknown transition next state") {
    source.transitions.value[0U].next_state.value = "other";
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_transition_next_state_unknown");
  }
  SECTION("duplicate transition coordinate") {
    auto duplicate = source.transitions.value[0U];
    source.transitions.value[0U].probability.value = probability(1, 2);
    duplicate.probability.value = probability(1, 2);
    source.transitions.value.insert(source.transitions.value.begin() + 1,
                                    std::move(duplicate));
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_transition_coordinate");
  }
  SECTION("missing transition row") {
    source.transitions.value.pop_back();
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_missing_transition_row");
  }
  SECTION("nonunit transition row") {
    source.transitions.value[0U].probability.value = probability(1, 2);
    expect_compile_error(authored(parsed), parsed.queues,
                         "pmf_mass_outside_tolerance");
  }
}

TEST_CASE("C11 private compiler and cursor reject malformed destinations and "
          "initial source maps",
          "[c11][unit][private-markov][negative]") {
  auto parsed = parse_private(kDefensiveFixture);
  auto& source = authored(parsed).sources.value[0U];

  SECTION("empty destination row") {
    source.destination_pmf.value.clear();
    expect_compile_error(authored(parsed), parsed.queues, "pmf_empty");
  }
  SECTION("duplicate destination coordinate") {
    source.destination_pmf.value[1U].queue_id.value =
        source.destination_pmf.value[0U].queue_id.value;
    expect_compile_error(authored(parsed), parsed.queues,
                         "private_markov_duplicate_destination_coordinate");
  }
  SECTION("unknown destination queue") {
    source.destination_pmf.value[0U].queue_id.value =
        mwperf::QueueId(text_label("missing"));
    expect_compile_error(authored(parsed), parsed.queues,
                         "unknown_queue_reference");
  }
  SECTION("zero destination mass") {
    source.destination_pmf.value[0U].probability.value = probability(0, 1);
    source.destination_pmf.value[1U].probability.value = probability(0, 1);
    expect_compile_error(authored(parsed), parsed.queues,
                         "pmf_zero_total_mass");
  }
  SECTION("wrong initial family") {
    const auto law = publish(parsed);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(80U, 0U));
    REQUIRE(stream);
    auto result = mwperf::instantiate_arrival_process(
        law, mwperf::RenewalOrigin{}, std::move(stream).value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "arrival_initial_family_mismatch");
  }
  SECTION("missing configured source") {
    const auto law = publish(parsed);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(81U, 0U));
    REQUIRE(stream);
    auto result = mwperf::instantiate_arrival_process(
        law, private_states({}), std::move(stream).value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "private_markov_initial_source_coverage");
  }
  SECTION("duplicate configured source") {
    const auto law = publish(parsed);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(82U, 0U));
    REQUIRE(stream);
    auto result = mwperf::instantiate_arrival_process(
        law, private_states({{"source_a", "a"}, {"source_a", "b"}}),
        std::move(stream).value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "private_markov_initial_duplicate_source");
  }
  SECTION("unknown configured source") {
    const auto law = publish(parsed);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(83U, 0U));
    REQUIRE(stream);
    auto result = mwperf::instantiate_arrival_process(
        law, private_states({{"other", "a"}}), std::move(stream).value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "private_markov_initial_source_unknown");
  }
  SECTION("unknown configured state") {
    const auto law = publish(parsed);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(84U, 0U));
    REQUIRE(stream);
    auto result = mwperf::instantiate_arrival_process(
        law, private_states({{"source_a", "other"}}),
        std::move(stream).value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "private_markov_initial_state_unknown");
  }
}
