#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <optional>
#include <random>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/certificates/transfer_bounds.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/stationary/analytic.hpp"

namespace mwperf::testing {

// C19 owns the narrow test authority needed to rebind a resolved physical
// input to an exact C09 fixture law.  As with the released C24 runner, C25
// supplies the runner-local definition so the production API remains opaque.
Result<ResolvedInstance> C19FixtureAccess::bind_resolved_arrival_for_testing(
    const ResolvedInstance& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
  const auto reject = [](std::string code, std::string message) {
    return Result<ResolvedInstance>::failure(
        {DiagnosticCategory::input_validation, std::move(code),
         std::move(message), std::nullopt, std::nullopt, {}});
  };
  if (!configured_arrival) {
    return reject("c25.fixture_arrival_missing",
                  "the C25 theorem fixture requires an exact arrival law");
  }
  if (source.initial_law().has_value()) {
    return reject("c25.fixture_initial_law_bound_to_previous_arrival",
                  "the C25 theorem fixture requires stationary selection");
  }

  const PhysicalBindingIdentity physical = source.arrival().identity();
  const ArrivalBinding& binding = arrival_law_binding(*configured_arrival);
  if (physical.combined_input != source.fingerprints().combined ||
      binding.family != physical.arrival_family ||
      binding.timing != source.timing() ||
      binding.timing != physical.timing ||
      binding.queue_cardinality != source.queues().size() ||
      binding.queue_cardinality != physical.queue_cardinality) {
    return reject("c25.fixture_arrival_physical_binding_mismatch",
                  "the fixture law does not match the resolved physical "
                  "arrival binding");
  }
  auto catalog_digest = detail::digest_queue_catalog(source.queues());
  if (!catalog_digest || binding.catalog_digest != catalog_digest.value()) {
    return catalog_digest
               ? reject("c25.fixture_arrival_catalog_mismatch",
                        "the fixture law does not match the queue catalog")
               : Result<ResolvedInstance>::failure(catalog_digest.error());
  }
  QueueMask support = positive_arrival_support(*configured_arrival);
  if (support.size() != source.queues().size() ||
      support.bytes() != source.positive_arrival_support().bytes()) {
    return reject("c25.fixture_arrival_support_mismatch",
                  "the fixture law and authored law have different support");
  }

  const ArrivalProductBindingIdentity product_identity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
  const auto references = source.arrival().queue_references();
  ConfiguredArrivalBinding rebound_arrival(
      physical,
      std::vector<BoundQueueReference>(references.begin(), references.end()),
      std::shared_ptr<const void>(configured_arrival),
      ArrivalCompiledProductKind::compiled_arrival_law_v1,
      product_identity);
  return Result<ResolvedInstance>::success(ResolvedInstance(
      source.authored_model(), source.analysis_spec(), source.fingerprints(),
      source.queues(), source.priority(), source.constraint(),
      source.service_identity(), source.serviceable(),
      source.optimizer_budget(), source.targets(), std::move(rebound_arrival),
      std::move(support), source.initial_law(), source.timing()));
}

}  // namespace mwperf::testing

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix = mwperf::testing::c16_registered_pair_matrix;
namespace designated = mwperf::testing::c16_designated_detail;

constexpr long double kTolerance = 2.0e-12L;

[[nodiscard]] bool close(const long double left, const long double right,
                         const long double tolerance = kTolerance) {
  return std::fabs(left - right) <= tolerance;
}

[[nodiscard]] const mwperf::ErrorBoundConstantV1* find_constant(
    const mwperf::ErrorBound& bound,
    const mwperf::ErrorBoundConstantKindV1 kind) {
  const auto found = std::find_if(
      bound.raw_constants.begin(), bound.raw_constants.end(),
      [kind](const mwperf::ErrorBoundConstantV1& constant) {
        return constant.kind == kind;
      });
  return found == bound.raw_constants.end() ? nullptr : &*found;
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(numerator, denominator);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object(
    const std::string_view name) {
  return {matrix::label(name), matrix::digest(name)};
}

// The IID-only drift and response-envelope theorems must be tested against a
// carrier whose sealed C09 input actually publishes the exact joint-vector
// table.  Merely writing `iid_across_slots` into C25 evidence is intentionally
// insufficient.
[[nodiscard]] temporal::GenericTemporalFrameworkV1 make_iid_framework(
    const bool arbitrary_batch = false) {
  auto instance = mwperf::testing::c17::make_shared_arrival_instance();
  const auto profile = arbitrary_batch
                           ? mwperf::testing::FixtureConstructionProfile::
                                 portable_iid_batch_joint_table
                           : mwperf::testing::FixtureConstructionProfile::
                                 portable_iid_bernoulli_joint_table;
  const mwperf::ExactRational first_mass =
      arbitrary_batch ? rational(17, 20) : rational(7, 10);
  auto iid = mwperf::testing::make_c09_weighted_correlated_fixture_law(
      instance.queues(), first_mass, profile);
  REQUIRE(iid);
  auto arrival = std::make_shared<const mwperf::CompiledArrivalLaw>(
      std::move(iid).value());
  auto rebound = mwperf::testing::C19FixtureAccess::
      bind_resolved_arrival_for_testing(instance, arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  instance = std::move(rebound).value();
  auto request = mwperf::parse_metric_request(
      instance.analysis_spec().metrics.front(), instance.queues());
  REQUIRE(request);
  std::vector<mwperf::MetricRequest> requests{request.value()};
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  designated::InputV1 source{std::move(instance), std::move(arrival),
                             std::move(requirements),
                             std::move(request).value()};

  auto scenario = temporal::temporal_scenario(
      std::move(source), temporal::temporal_profile());
  auto prepared =
      temporal::prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          std::move(scenario),
          mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h0"}},
          mwperf::BigNat{0U}, [](mwperf::PlugDescriptor&) {},
          [](const mwperf::ResolvedInstance& instance,
             const std::span<const mwperf::QueueId> targets,
             const mwperf::CompiledArrivalLaw&, const mwperf::ArrivalPhase& before,
             const mwperf::ArrivalPhase& after) {
            return mwperf::testing::c17::exact_state_schema(
                instance, targets, before, after);
          },
          [](const std::span<const mwperf::QueueId> targets,
             const mwperf::ExactReducedStateSchemaV1&) {
            return mwperf::testing::c17::reduced_state(targets, {1U});
          },
          [](mwperf::ExactCausalProgramV1&) {});
  auto framework = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(),
          std::move(prepared.instance),
          std::move(prepared.ordered_targets),
          std::move(prepared.state_schema),
          std::move(prepared.descriptor),
          std::move(prepared.initial_state),
          std::move(prepared.entrance_mark),
          std::move(prepared.entrance_decoder_calls),
          std::move(prepared.residence_generator_calls)};
}

[[nodiscard]] mwperf::MetricGeometry tv_geometry(
    const std::string_view name,
    const std::optional<long double> reward_lower = std::nullopt,
    const std::optional<long double> reward_upper = std::nullopt) {
  return {.value = mwperf::TotalVariationGeometryV1{
              .geometry_identity = matrix::digest(std::string(name) + ".tv"),
              .state_space_identity =
                  matrix::digest(std::string(name) + ".state"),
              .observable_identity =
                  matrix::digest(std::string(name) + ".observable"),
              .convention =
                  mwperf::TvConventionV1::supremum_event_difference,
              .reward_lower = reward_lower,
              .reward_upper = reward_upper,
          }};
}

[[nodiscard]] mwperf::MetricGeometry wasserstein_geometry(
    const std::string_view name, const long double lipschitz = 1.0L) {
  return {.value = mwperf::WassersteinGeometryV1{
              .geometry_identity =
                  matrix::digest(std::string(name) + ".wasserstein"),
              .state_space_identity =
                  matrix::digest(std::string(name) + ".state"),
              .metric_identity =
                  matrix::digest(std::string(name) + ".metric"),
              .lower_semicontinuous = true,
              .triangle_inequality = true,
              .generates_borel_sigma_field = true,
              .reference_first_moment_finite = true,
              .approximate_first_moment_finite = true,
              .reward_lipschitz_modulus = lipschitz,
              .reward_expectations_exist = true,
          }};
}

[[nodiscard]] mwperf::MetricGeometry weighted_geometry(
    const std::string_view name, const long double dual_modulus = 1.0L) {
  return {.value = mwperf::WeightedGeometryV1{
              .geometry_identity =
                  matrix::digest(std::string(name) + ".weighted"),
              .state_space_identity =
                  matrix::digest(std::string(name) + ".state"),
              .norm_identity = matrix::digest(std::string(name) + ".norm"),
              .complete_normed_space = true,
              .shared_foster_lyapunov_tail = true,
              .reward_dual_modulus = dual_modulus,
          }};
}

[[nodiscard]] mwperf::OperatorNormGeometryV1 operator_geometry(
    const std::string_view name, const std::size_t dimension) {
  return {
      .geometry_identity = matrix::digest(std::string(name) + ".operator"),
      .state_space_identity = matrix::digest(std::string(name) + ".state"),
      .norm_identity = matrix::digest(std::string(name) + ".norm"),
      .kind = mwperf::OperatorNormKindV1::weighted_supremum,
      .weights = std::vector<mwperf::ExactRational>(
          dimension, mwperf::ExactRational::one()),
      .complete_normed_space = true,
      .contains_constant_one = true,
  };
}

[[nodiscard]] mwperf::RowErrorEvidenceV1 row_error(
    const std::string_view name, const mwperf::RowErrorKindV1 kind,
    mwperf::MetricGeometry geometry, const long double defect,
    const std::optional<long double> initial_defect = std::nullopt,
    const bool equal_initial = true) {
  return {
      .evidence_id = object(std::string(name) + ".row"),
      .reference_law = object(std::string(name) + ".reference"),
      .approximate_law = object(std::string(name) + ".approximate"),
      .kind = kind,
      .horizon_domain =
          kind == mwperf::RowErrorKindV1::approximate_relational_slot_row
              ? mwperf::HorizonDomainV1::relational_slots
              : mwperf::HorizonDomainV1::complete_residence_words,
      .consequence_domain = matrix::digest(std::string(name) + ".domain"),
      .geometry = std::move(geometry),
      .row_defect = defect,
      .initial_defect = initial_defect,
      .equal_initial_law = equal_initial,
      .common_refinement_established = true,
      .orientation = mwperf::TransferOrientationV1::reference_to_approximate,
      .reward = {.kind = mwperf::RewardGeometryKindV1::event_indicator,
                 .lower = 0.0L,
                 .upper = 1.0L,
                 .lipschitz_modulus = std::nullopt,
                 .required_moments_established = true},
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::ValidatedCertificates validate_nodes(
    const mwperf::AuditedCompiledFramework& framework,
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes,
    const std::function<void(mwperf::CertificateBundle&)>& select) {
  // Every positive theorem view must be backed by an independent, directly
  // linked premise for the exact claim.  Keep the authoring helpers terse,
  // but make that graph edge explicit in every test fixture.
  std::vector<mwperf::CertificateEvidenceNodeV1> premises;
  const std::size_t authored_nodes = nodes.size();
  premises.reserve(authored_nodes);
  for (std::size_t index = 0U; index < authored_nodes; ++index) {
    std::visit(
        [&](auto& node) {
          using Node = std::decay_t<decltype(node)>;
          std::optional<mwperf::CertificateClaimKindV1> claim;
          if constexpr (std::is_same_v<Node, mwperf::RowErrorEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::finite_horizon_transfer;
          } else if constexpr (std::is_same_v<
                                   Node, mwperf::ContractionEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::contraction_transfer;
          } else if constexpr (
              std::is_same_v<Node, mwperf::KilledKernelPairEvidenceV1> ||
              std::is_same_v<Node, mwperf::ResolventEvidenceV1>) {
            claim =
                mwperf::CertificateClaimKindV1::stopped_resolvent_transfer;
          } else if constexpr (std::is_same_v<
                                   Node, mwperf::DriftWitnessEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::stability;
          } else if constexpr (std::is_same_v<
                                   Node,
                                   mwperf::ResponseEnvelopeCertificateEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::response_envelope;
          } else {
            return;
          }

          const std::string name =
              "c25.test.typed-premise." + std::to_string(index) + "." +
              std::to_string(static_cast<unsigned int>(*claim));
          mwperf::Digest256 subject_product =
              matrix::digest(name + ".subject-product");
          mwperf::Digest256 subject_law =
              matrix::digest(name + ".subject-law");
          if constexpr (requires {
                          node.subject_product_identity;
                          node.subject_law_identity;
                        }) {
            subject_product = node.subject_product_identity;
            subject_law = node.subject_law_identity;
          }
          mwperf::CertificatePremiseEvidenceV1 premise{
              .evidence_id = object(name),
              .supported_claim = *claim,
              .subject_product_identity = subject_product,
              .subject_law_identity = subject_law,
              .premise_identity = matrix::digest(name + ".premise"),
              .provenance_identity = object(name + ".provenance"),
              .coverage =
                  mwperf::CertificateCoverageV1::global_declared_domain,
              .origin = mwperf::CertificateEvidenceOriginV1::independent_a_priori,
              .dependencies = {}};
          node.dependencies.push_back(premise.evidence_id);
          premises.emplace_back(std::move(premise));
        },
        nodes[index]);
  }
  nodes.insert(nodes.end(), std::make_move_iterator(premises.begin()),
               std::make_move_iterator(premises.end()));

  auto evidence = mwperf::Evidence::bind(framework, std::move(nodes));
  INFO((evidence ? std::string{}
                 : evidence.error().code + ": " + evidence.error().message));
  REQUIRE(evidence);
  mwperf::CertificateBundle bundle =
      mwperf::CertificateBundle::v0_only(evidence.value());
  select(bundle);
  auto validated = mwperf::validate_certificate_bundle(
      bundle, framework, evidence.value());
  INFO((validated
            ? std::string{}
            : validated.error().code + ": " + validated.error().message));
  REQUIRE(validated);
  return std::move(validated).value();
}

[[nodiscard]] mwperf::ValidatedCertificates validate_transfer_nodes(
    const mwperf::AuditedCompiledFramework& framework,
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes,
    std::vector<mwperf::CertificateEvidenceIdV1> selected) {
  return validate_nodes(
      framework, std::move(nodes),
      [selected = std::move(selected)](
          mwperf::CertificateBundle& bundle) mutable {
        bundle.transfer_claims = std::move(selected);
      });
}

[[nodiscard]] mwperf::MetricRequest metric_request(
    const mwperf::QueueCatalog& queues, const std::string_view metric) {
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + std::string(metric) + R"json(],
    "surrogate":{"id":"c25.test","version":"1.0.0","parameters":{}},
    "resolution":{
      "level":{"max_states":128,"max_row_atoms":256},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":32},
      "optimizer":{"max_calls":64,"max_search_states_per_call":256},
      "sampling":{"max_generator_draws":1024},
      "tolerance":{"linear_residual_abs":1e-12,
                   "integration_abs":1e-12,"tail_abs":1e-12,
                   "fixed_point_abs":1e-12}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}}
  })json";
  auto document =
      mwperf::load_document(designated::write_input("c25-metric", analysis));
  REQUIRE(document);
  auto spec = mwperf::parse_analysis_spec_v1(document.value());
  REQUIRE(spec);
  auto request = mwperf::parse_metric_request(spec.value().metrics.front(),
                                               queues);
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  return std::move(request).value();
}

[[nodiscard]] mwperf::ScopedCertificateRecordEvidenceV1 premise_record(
    const std::string_view name) {
  return {
      .evidence_id = object(std::string(name) + ".premise"),
      .kind = mwperf::CertificateClaimKindV1::validation,
      .subject_product_identity =
          matrix::digest(std::string(name) + ".product"),
      .subject_law_identity = matrix::digest(std::string(name) + ".law"),
      .statement_identity = matrix::digest(std::string(name) + ".statement"),
      .coverage = mwperf::CertificateCoverageV1::global_declared_domain,
      .origin = mwperf::CertificateEvidenceOriginV1::independent_a_priori,
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::DriftWitnessEvidenceV1 drift_evidence(
    const mwperf::AuditedCompiledFramework& framework,
    const std::string_view name) {
  auto bound = mwperf::Evidence::bind(framework, {});
  REQUIRE(bound);
  return {
      .evidence_id = object(std::string(name) + ".drift"),
      .framework_fingerprint =
          bound.value().framework_bindings().problem_fingerprints
              .resolved_instance,
      .configured_arrival_fingerprint =
          bound.value().framework_bindings().problem_fingerprints
              .compiled_arrival,
      .subject_product_identity =
          matrix::digest(std::string(name) + ".product"),
      .subject_law_identity = matrix::digest(std::string(name) + ".law"),
      .declared_domain_identity =
          matrix::digest(std::string(name) + ".domain"),
      .common_joint_schedule_law_identity =
          matrix::digest(std::string(name) + ".joint-schedule"),
      .domain_coverage =
          mwperf::CertificateCoverageV1::forward_invariant_domain,
      .retains_full_physical_backlog = true,
      .iid_across_slots_exact_joint = true,
      .capacity_interior_verified = true,
      .declared_domain_forward_invariant = true,
      .all_declared_domain_rows_verified = true,
      .common_joint_schedule_law_established = true,
      .initial_support_contained = true,
      .initial_quadratic_backlog_moment_finite = true,
      .epsilon = 0.2L,
      .b = 1.0L,
      .delta = 0.1L,
      .deterministic_row_tolerance = 0.0L,
      .arrival_second_norm_moment = 2.0L,
      .max_schedule_squared_norm = 3.0L,
      .rows = {{0.0L, 0.0L, 0.0L, true},
               {10.0L, 8.0L, 10.0L, true}},
      .irreducible = false,
      .petite_set = false,
      .norm_like_all_unbounded_phases = false,
      .dependencies = {object(std::string(name) + ".premise")},
  };
}

[[nodiscard]] mwperf::ValidatedCertificates validate_drift(
    const mwperf::AuditedCompiledFramework& framework,
    mwperf::DriftWitnessEvidenceV1 drift,
    mwperf::ScopedCertificateRecordEvidenceV1 premise) {
  const auto drift_id = drift.evidence_id;
  return validate_nodes(
      framework, {std::move(premise), std::move(drift)},
      [drift_id](mwperf::CertificateBundle& bundle) {
        bundle.stability = drift_id;
      });
}

[[nodiscard]] mwperf::ResponseEnvelopeCertificateEvidenceV1 envelope_evidence(
    const mwperf::AuditedCompiledFramework& framework,
    const mwperf::QueueId& target, const std::string_view name) {
  auto bound = mwperf::Evidence::bind(framework, {});
  REQUIRE(bound);
  const mwperf::Digest256 slow =
      matrix::digest(std::string(name) + ".slow-product");
  const mwperf::Digest256 fast =
      matrix::digest(std::string(name) + ".fast-product");
  const mwperf::Digest256 subject =
      matrix::digest(std::string(name) + ".point-product");
  const mwperf::Digest256 subject_law =
      matrix::digest(std::string(name) + ".point-law");
  return {
      .evidence_id = object(std::string(name) + ".envelope"),
      .framework_fingerprint =
          bound.value().framework_bindings().problem_fingerprints
              .resolved_instance,
      .configured_arrival_identity =
          bound.value().framework_bindings().problem_fingerprints
              .compiled_arrival,
      .target = target,
      .subject_product_identity = subject,
      .subject_law_identity = subject_law,
      .slow_product_identity = slow,
      .fast_product_identity = fast,
      .subject_product =
          {.identity = subject,
           .stage = mwperf::ResponseProductStageV1::recoded_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = subject_law,
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .slow_product =
          {.identity = slow,
           .stage = mwperf::ResponseProductStageV1::raw_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = matrix::digest(std::string(name) + ".slow-law"),
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .fast_product =
          {.identity = fast,
           .stage = mwperf::ResponseProductStageV1::raw_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = matrix::digest(std::string(name) + ".fast-law"),
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .mu_minus = {0.55L, 0.55L, 0.6L},
      .mu_point = {0.7L, 0.7L, 0.7L},
      .mu_plus = {0.85L, 0.85L, 0.85L},
      .pointwise_order_independently_certified = true,
      .arrival_semantics =
          mwperf::EnvelopeArrivalSemanticsV1::iid_across_slots,
      .requested_route =
          mwperf::EnvelopeClosureRouteV1::reachable_tail_strict_slack,
      .iid_target_marginal = {{0U, 0.7L}, {1U, 0.3L}},
      .lambda = 0.3L,
      .arrival_second_moment = 0.3L,
      .arrival_second_moment_finite = true,
      .closure = {.established = false,
                  .boundary = 1U,
                  .initial_support = {0U},
                  .selected_accessible_class = {0U, 1U},
                  .bound_slow_product_identity = slow,
                  .exact_reachability = false,
                  .unique_reachable_closed_class = false},
      .tail = {.boundary_order_certified = true,
               .tail_order_certified = true,
               .finite_second_moment = true},
      .temporal_backend = std::nullopt,
      .stationary_existence_convergence = true,
      .little_lossless = true,
      .little_unit_packets = true,
      .little_eventual_departure = true,
      .little_positive_finite_intensity = true,
      .little_finite_backlog_first_moment = true,
      .little_law = true,
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::ValidatedCertificates validate_envelope(
    const mwperf::AuditedCompiledFramework& framework,
    mwperf::ResponseEnvelopeCertificateEvidenceV1 envelope) {
  const auto envelope_id = envelope.evidence_id;
  return validate_nodes(
      framework, {std::move(envelope)},
      [envelope_id](mwperf::CertificateBundle& bundle) {
        bundle.response_envelopes = {envelope_id};
      });
}

static_assert(!std::is_default_constructible_v<mwperf::RowErrorBound>);
static_assert(!std::is_constructible_v<mwperf::RowErrorBound,
                                       mwperf::RowErrorEvidenceV1>);
static_assert(!std::is_default_constructible_v<mwperf::ContractionWitness>);
static_assert(!std::is_default_constructible_v<mwperf::KilledKernelPair>);
static_assert(!std::is_default_constructible_v<mwperf::ResolventWitness>);
static_assert(!std::is_default_constructible_v<mwperf::DriftWitness>);
static_assert(!std::is_default_constructible_v<mwperf::ResponseEnvelope>);
static_assert(
    !std::is_default_constructible_v<mwperf::CertificateArrivalLaw>);

}  // namespace

TEST_CASE("C25 finite-horizon TV transfer has exact boundary semantics",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();

  SECTION("equal-initial event words") {
    const auto zero = row_error(
        "c25.tv.zero", mwperf::RowErrorKindV1::marked_residence_event_row,
        tv_geometry("c25.tv.zero"), 0.0L);
    auto certificates = validate_transfer_nodes(
        fixture.framework, {zero}, {zero.evidence_id});
    auto view = certificates.row_error_bound(zero.evidence_id);
    REQUIRE(view);

    for (const std::uint64_t horizon : {0U, 1U, 97U}) {
      auto bound = mwperf::compute_finite_horizon_tv_transfer(
          view.value(), mwperf::Horizon{horizon});
      REQUIRE(bound);
      REQUIRE(bound.value().raw_value);
      CHECK(*bound.value().raw_value == 0.0L);
      REQUIRE(bound.value().union_bound);
      CHECK(*bound.value().union_bound == 0.0L);
      CHECK(bound.value().scope ==
            mwperf::TransferScopeV1::finite_residence_words);
    }
  }

  SECTION("unit row defect and zero words") {
    const auto unit = row_error(
        "c25.tv.unit", mwperf::RowErrorKindV1::marked_residence_event_row,
        tv_geometry("c25.tv.unit"), 1.0L);
    auto certificates = validate_transfer_nodes(
        fixture.framework, {unit}, {unit.evidence_id});
    auto view = certificates.row_error_bound(unit.evidence_id);
    REQUIRE(view);
    auto zero_words = mwperf::compute_finite_horizon_tv_transfer(
        view.value(), mwperf::Horizon{0U});
    auto one_word = mwperf::compute_finite_horizon_tv_transfer(
        view.value(), mwperf::Horizon{1U});
    REQUIRE(zero_words);
    REQUIRE(one_word);
    CHECK(*zero_words.value().raw_value == 0.0L);
    CHECK(*one_word.value().raw_value == 1.0L);
  }

  SECTION("relational slot transfer retains its initial defect at T zero") {
    const auto relational = row_error(
        "c25.tv.relational",
        mwperf::RowErrorKindV1::approximate_relational_slot_row,
        tv_geometry("c25.tv.relational"), 0.25L, 0.125L, false);
    auto certificates = validate_transfer_nodes(
        fixture.framework, {relational}, {relational.evidence_id});
    auto view = certificates.row_error_bound(relational.evidence_id);
    REQUIRE(view);
    auto at_zero = mwperf::compute_finite_horizon_tv_transfer(
        view.value(), mwperf::Horizon{0U});
    auto at_two = mwperf::compute_finite_horizon_tv_transfer(
        view.value(), mwperf::Horizon{2U});
    REQUIRE(at_zero);
    REQUIRE(at_two);
    CHECK(close(*at_zero.value().raw_value, 0.125L));
    CHECK(close(*at_two.value().raw_value,
                1.0L - 0.875L * 0.75L * 0.75L));
    CHECK(close(*at_two.value().union_bound, 0.625L));
    CHECK(at_two.value().scope ==
          mwperf::TransferScopeV1::finite_relational_slots);
  }
}

TEST_CASE("C25 finite-horizon TV arithmetic is stable and horizon typed",
          "[c25][unit][negative]") {
  auto fixture = temporal::make_generic_temporal_framework();
  const auto tiny = row_error(
      "c25.tv.tiny", mwperf::RowErrorKindV1::marked_residence_event_row,
      tv_geometry("c25.tv.tiny"), 1.0e-18L);
  auto certificates = validate_transfer_nodes(
      fixture.framework, {tiny}, {tiny.evidence_id});
  auto view = certificates.row_error_bound(tiny.evidence_id);
  REQUIRE(view);

  const std::uint64_t steps = 1'000'000U;
  auto stable = mwperf::compute_finite_horizon_tv_transfer(
      view.value(), mwperf::Horizon{steps});
  REQUIRE(stable);
  const long double expected =
      -std::expm1(static_cast<long double>(steps) * std::log1p(-1.0e-18L));
  CHECK(close(*stable.value().raw_value, expected, 1.0e-24L));
  CHECK(*stable.value().raw_value <= *stable.value().union_bound);

  const mwperf::BigInt too_large =
      mwperf::BigInt(std::numeric_limits<std::size_t>::max()) + 1;
  auto enormous = mwperf::BigNat::from_big_int(too_large);
  REQUIRE(enormous);
  auto rejected = mwperf::compute_finite_horizon_tv_transfer(
      view.value(), enormous.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c25.transfer_horizon_out_of_range");
}

TEST_CASE("C25 finite TV rejects invalid defects, domains, and rewards",
          "[c25][negative]") {
  auto fixture = temporal::make_generic_temporal_framework();

  SECTION("probability outside the closed unit interval") {
    const auto invalid = row_error(
        "c25.tv.invalid-probability",
        mwperf::RowErrorKindV1::marked_residence_event_row,
        tv_geometry("c25.tv.invalid-probability"), 1.01L);
    auto evidence = mwperf::Evidence::bind(fixture.framework, {invalid});
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.transfer_claims = {invalid.evidence_id};
    auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.framework, evidence.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.invalid_row_defect");
  }

  SECTION("event evidence cannot be relabelled as a slot horizon") {
    auto invalid = row_error(
        "c25.tv.invalid-domain",
        mwperf::RowErrorKindV1::marked_residence_event_row,
        tv_geometry("c25.tv.invalid-domain"), 0.1L);
    invalid.horizon_domain = mwperf::HorizonDomainV1::relational_slots;
    auto evidence = mwperf::Evidence::bind(fixture.framework, {invalid});
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.transfer_claims = {invalid.evidence_id};
    auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.framework, evidence.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.row_horizon_domain_mismatch");
  }

  SECTION("plain TV cannot certify an unbounded backlog reward") {
    auto unbounded = row_error(
        "c25.tv.unbounded", mwperf::RowErrorKindV1::marked_residence_event_row,
        tv_geometry("c25.tv.unbounded"), 0.1L);
    unbounded.reward.kind = mwperf::RewardGeometryKindV1::unbounded;
    auto certificates = validate_transfer_nodes(
        fixture.framework, {unbounded}, {unbounded.evidence_id});
    auto view = certificates.row_error_bound(unbounded.evidence_id);
    REQUIRE(view);
    auto rejected = mwperf::compute_finite_horizon_tv_transfer(
        view.value(), mwperf::Horizon{3U});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.tv_unbounded_reward_unsupported");
  }
}

TEST_CASE("C25 finite TV scales only an explicitly bounded reward range",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();
  auto row = row_error(
      "c25.tv.bounded-reward",
      mwperf::RowErrorKindV1::marked_residence_event_row,
      tv_geometry("c25.tv.bounded-reward", -2.0L, 3.0L), 0.2L);
  row.reward = {.kind = mwperf::RewardGeometryKindV1::bounded_range,
                .lower = -2.0L,
                .upper = 3.0L,
                .lipschitz_modulus = std::nullopt,
                .required_moments_established = true};
  auto certificates = validate_transfer_nodes(
      fixture.framework, {row}, {row.evidence_id});
  auto view = certificates.row_error_bound(row.evidence_id);
  REQUIRE(view);
  auto bound = mwperf::compute_finite_horizon_tv_transfer(
      view.value(), mwperf::Horizon{2U});
  REQUIRE(bound);
  // The raw law distance remains 1-(1-.2)^2=.36.  Only the presentation for
  // this explicitly declared reward is scaled by its range width five.
  CHECK(close(*bound.value().raw_value, 0.36L));
  CHECK(close(*bound.value().presented_value, 1.8L));
  CHECK(close(*bound.value().union_bound, 0.4L));
  const auto* row_defect = find_constant(
      bound.value(), mwperf::ErrorBoundConstantKindV1::row_defect);
  const auto* reward_scale = find_constant(
      bound.value(), mwperf::ErrorBoundConstantKindV1::reward_scale);
  REQUIRE(row_defect != nullptr);
  REQUIRE(row_defect->numerical_value);
  CHECK(close(*row_defect->numerical_value, 0.2L));
  REQUIRE(reward_scale != nullptr);
  REQUIRE(reward_scale->numerical_value);
  CHECK(close(*reward_scale->numerical_value, 5.0L));
}

TEST_CASE("C25 stationary TV contraction retains its raw quotient",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();
  auto row = row_error(
      "c25.contraction.tv",
      mwperf::RowErrorKindV1::stationary_uniform_total_variation,
      tv_geometry("c25.contraction.tv"), 0.5L);
  const mwperf::ContractionEvidenceV1 contraction{
      .evidence_id = object("c25.contraction.tv.witness"),
      .row_error_id = row.evidence_id,
      .reference_kernel = row.reference_law,
      .approximate_kernel = row.approximate_law,
      .reference_invariant_law = object("c25.contraction.tv.pi"),
      .approximate_invariant_law = object("c25.contraction.tv.pihat"),
      .geometry = row.geometry,
      .coefficient = 0.75L,
      .invariant_laws_established = true,
      .reference_first_moment_finite = true,
      .approximate_first_moment_finite = true,
      .shared_foster_lyapunov_tail = true,
      .dependencies = {row.evidence_id},
  };
  auto certificates = validate_transfer_nodes(
      fixture.framework, {row, contraction},
      {row.evidence_id, contraction.evidence_id});
  auto row_view = certificates.row_error_bound(row.evidence_id);
  auto contraction_view =
      certificates.contraction_witness(contraction.evidence_id);
  REQUIRE(row_view);
  REQUIRE(contraction_view);

  auto bound = mwperf::compute_contraction_transfer(
      row_view.value(), contraction_view.value(), row.geometry);
  REQUIRE(bound);
  REQUIRE(bound.value().raw_value);
  REQUIRE(bound.value().presented_value);
  REQUIRE(bound.value().conditioning_factor);
  CHECK(close(*bound.value().raw_value, 2.0L));
  CHECK(close(*bound.value().presented_value, 1.0L));
  CHECK(close(*bound.value().conditioning_factor, 4.0L));
  CHECK(bound.value().presentation_capped);
  CHECK(bound.value().components.size() == 1U);
  const auto* coefficient = find_constant(
      bound.value(),
      mwperf::ErrorBoundConstantKindV1::contraction_coefficient);
  const auto* gap = find_constant(
      bound.value(), mwperf::ErrorBoundConstantKindV1::contraction_gap);
  const auto* conditioning = find_constant(
      bound.value(), mwperf::ErrorBoundConstantKindV1::conditioning_factor);
  REQUIRE(coefficient != nullptr);
  REQUIRE(coefficient->numerical_value);
  CHECK(close(*coefficient->numerical_value, 0.75L));
  REQUIRE(gap != nullptr);
  REQUIRE(gap->numerical_value);
  CHECK(close(*gap->numerical_value, 0.25L));
  REQUIRE(conditioning != nullptr);
  REQUIRE(conditioning->numerical_value);
  CHECK(close(*conditioning->numerical_value, 4.0L));

  auto mismatch = mwperf::compute_contraction_transfer(
      row_view.value(), contraction_view.value(),
      tv_geometry("c25.contraction.tv.foreign"));
  REQUIRE_FALSE(mismatch);
  CHECK(mismatch.error().code == "c25.contraction_geometry_mismatch");
}

TEST_CASE("C25 contraction branches preserve geometry and reward scale",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();

  SECTION("Wasserstein occupation defect") {
    auto row = row_error(
        "c25.contraction.wasserstein",
        mwperf::RowErrorKindV1::stationary_wasserstein_occupation,
        wasserstein_geometry("c25.contraction.wasserstein", 3.0L), 2.0L);
    row.orientation =
        mwperf::TransferOrientationV1::approximate_to_reference;
    row.reward = {.kind = mwperf::RewardGeometryKindV1::metric_lipschitz,
                  .lower = std::nullopt,
                  .upper = std::nullopt,
                  .lipschitz_modulus = 3.0L,
                  .required_moments_established = true};
    const mwperf::ContractionEvidenceV1 contraction{
        .evidence_id = object("c25.contraction.wasserstein.witness"),
        .row_error_id = row.evidence_id,
        .reference_kernel = row.reference_law,
        .approximate_kernel = row.approximate_law,
        .reference_invariant_law = object("c25.contraction.wasserstein.pi"),
        .approximate_invariant_law =
            object("c25.contraction.wasserstein.pihat"),
        .geometry = row.geometry,
        .coefficient = 0.5L,
        .invariant_laws_established = true,
        .reference_first_moment_finite = true,
        .approximate_first_moment_finite = true,
        .shared_foster_lyapunov_tail = false,
        .dependencies = {row.evidence_id},
    };
    auto certificates = validate_transfer_nodes(
        fixture.framework, {row, contraction},
        {row.evidence_id, contraction.evidence_id});
    auto row_view = certificates.row_error_bound(row.evidence_id);
    auto witness = certificates.contraction_witness(contraction.evidence_id);
    REQUIRE(row_view);
    REQUIRE(witness);
    auto bound = mwperf::compute_contraction_transfer(
        row_view.value(), witness.value(), row.geometry);
    REQUIRE(bound);
    CHECK(bound.value().geometry.kind() ==
          mwperf::TransferGeometryKindV1::wasserstein_metric);
    CHECK(close(*bound.value().raw_value, 4.0L));
    CHECK(close(*bound.value().presented_value, 12.0L));
    CHECK_FALSE(bound.value().presentation_capped);
  }

  SECTION("explicit weighted geometry") {
    auto row = row_error(
        "c25.contraction.weighted",
        mwperf::RowErrorKindV1::stationary_weighted_norm,
        weighted_geometry("c25.contraction.weighted", 2.0L), 0.1L);
    row.orientation =
        mwperf::TransferOrientationV1::approximate_to_reference;
    row.reward = {.kind = mwperf::RewardGeometryKindV1::unbounded,
                  .lower = std::nullopt,
                  .upper = std::nullopt,
                  .lipschitz_modulus = std::nullopt,
                  .required_moments_established = true};
    const mwperf::ContractionEvidenceV1 contraction{
        .evidence_id = object("c25.contraction.weighted.witness"),
        .row_error_id = row.evidence_id,
        .reference_kernel = row.reference_law,
        .approximate_kernel = row.approximate_law,
        .reference_invariant_law = object("c25.contraction.weighted.pi"),
        .approximate_invariant_law =
            object("c25.contraction.weighted.pihat"),
        .geometry = row.geometry,
        .coefficient = 0.8L,
        .invariant_laws_established = true,
        .reference_first_moment_finite = true,
        .approximate_first_moment_finite = true,
        .shared_foster_lyapunov_tail = true,
        .dependencies = {row.evidence_id},
    };
    auto certificates = validate_transfer_nodes(
        fixture.framework, {row, contraction},
        {row.evidence_id, contraction.evidence_id});
    auto row_view = certificates.row_error_bound(row.evidence_id);
    auto witness = certificates.contraction_witness(contraction.evidence_id);
    REQUIRE(row_view);
    REQUIRE(witness);
    auto bound = mwperf::compute_contraction_transfer(
        row_view.value(), witness.value(), row.geometry);
    REQUIRE(bound);
    CHECK(bound.value().geometry.kind() ==
          mwperf::TransferGeometryKindV1::weighted_total_variation);
    CHECK(close(*bound.value().raw_value, 0.5L));
    CHECK(close(*bound.value().presented_value, 1.0L));
  }
}

TEST_CASE("C25 contraction rejects non-strict and cross-owner evidence",
          "[c25][negative]") {
  auto first_fixture = temporal::make_generic_temporal_framework();
  auto second_fixture = temporal::make_generic_temporal_framework();
  auto row = row_error(
      "c25.contraction.reject",
      mwperf::RowErrorKindV1::stationary_uniform_total_variation,
      tv_geometry("c25.contraction.reject"), 0.1L);
  auto contraction = mwperf::ContractionEvidenceV1{
      .evidence_id = object("c25.contraction.reject.witness"),
      .row_error_id = row.evidence_id,
      .reference_kernel = row.reference_law,
      .approximate_kernel = row.approximate_law,
      .reference_invariant_law = object("c25.contraction.reject.pi"),
      .approximate_invariant_law = object("c25.contraction.reject.pihat"),
      .geometry = row.geometry,
      .coefficient = 1.0L,
      .invariant_laws_established = true,
      .reference_first_moment_finite = true,
      .approximate_first_moment_finite = true,
      .shared_foster_lyapunov_tail = true,
      .dependencies = {row.evidence_id},
  };
  auto first = validate_transfer_nodes(
      first_fixture.framework, {row, contraction},
      {row.evidence_id, contraction.evidence_id});
  auto first_row = first.row_error_bound(row.evidence_id);
  auto first_contraction = first.contraction_witness(contraction.evidence_id);
  REQUIRE(first_row);
  REQUIRE(first_contraction);
  auto non_strict = mwperf::compute_contraction_transfer(
      first_row.value(), first_contraction.value(), row.geometry);
  REQUIRE_FALSE(non_strict);
  CHECK(non_strict.error().code ==
        "c25.contraction_coefficient_not_strict");

  contraction.coefficient = 0.5L;
  auto second = validate_transfer_nodes(
      second_fixture.framework, {row, contraction},
      {row.evidence_id, contraction.evidence_id});
  auto second_contraction =
      second.contraction_witness(contraction.evidence_id);
  REQUIRE(second_contraction);
  auto cross_owner = mwperf::compute_contraction_transfer(
      first_row.value(), second_contraction.value(), row.geometry);
  REQUIRE_FALSE(cross_owner);
  CHECK(cross_owner.error().code == "c25.validated_view_owner_mismatch");
}

TEST_CASE("C25 killed resolvent preserves exact kernel and entrance terms",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();
  const auto norm = operator_geometry("c25.resolvent", 2U);
  const mwperf::KilledKernelPairEvidenceV1 pair{
      .evidence_id = object("c25.resolvent.pair"),
      .reference_law = object("c25.resolvent.reference"),
      .approximate_law = object("c25.resolvent.approximate"),
      .state_order_identity = norm.state_space_identity,
      .stopping_event_identity = matrix::digest("c25.resolvent.stop"),
      .common_lift_identity = matrix::digest("c25.resolvent.lift"),
      .reference_killed_kernel =
          {2U, 2U,
           {rational(1, 2), rational(0, 1), rational(0, 1),
            rational(1, 4)}},
      .approximate_killed_kernel =
          {2U, 2U,
           {rational(1, 4), rational(0, 1), rational(0, 1),
            rational(1, 4)}},
      .reference_entrance_law =
          std::vector<mwperf::ExactRational>{rational(1, 1),
                                              rational(0, 1)},
      .approximate_entrance_law =
          std::vector<mwperf::ExactRational>{rational(0, 1),
                                              rational(1, 1)},
      .reference_c23_entrance = std::nullopt,
      .approximate_c23_entrance = std::nullopt,
      .common_state_and_lift_established = true,
      .dependencies = {},
  };
  const mwperf::ResolventEvidenceV1 resolvent{
      .evidence_id = object("c25.resolvent.witness"),
      .killed_pair_id = pair.evidence_id,
      .norm = norm,
      .reference_resolvent =
          {2U, 2U,
           {rational(2, 1), rational(0, 1), rational(0, 1),
            rational(4, 3)}},
      .approximate_resolvent =
          {2U, 2U,
           {rational(4, 3), rational(0, 1), rational(0, 1),
            rational(4, 3)}},
      .bounded_neumann_resolvents = true,
      .space_contains_one = true,
      .minimal_potentials_finite = true,
      .certified_inverse_residual_conversion = std::nullopt,
      .dependencies = {pair.evidence_id},
  };
  auto certificates = validate_transfer_nodes(
      fixture.framework, {pair, resolvent},
      {pair.evidence_id, resolvent.evidence_id});
  auto pair_view = certificates.killed_kernel_pair(pair.evidence_id);
  auto resolvent_view = certificates.resolvent_witness(resolvent.evidence_id);
  REQUIRE(pair_view);
  REQUIRE(resolvent_view);
  auto bound = mwperf::compute_stopped_resolvent_transfer(
      pair_view.value(), resolvent_view.value());
  REQUIRE(bound);
  CHECK(bound.value().scope ==
        mwperf::TransferScopeV1::entrance_averaged_stopped_potential);
  CHECK(bound.value().components.size() == 3U);
  CHECK(bound.value().components[0].kind ==
        mwperf::ErrorBoundComponentKindV1::killed_kernel);
  CHECK(bound.value().components[1].kind ==
        mwperf::ErrorBoundComponentKindV1::entrance_law);
  CHECK(bound.value().components[2].kind ==
        mwperf::ErrorBoundComponentKindV1::potential_numerical_residual);
  CHECK(close(*bound.value().components[0].numerical_value, 2.0L / 3.0L));
  CHECK(close(*bound.value().components[1].numerical_value, 8.0L / 3.0L));
  CHECK(close(*bound.value().components[2].numerical_value, 0.0L));
  CHECK(close(*bound.value().raw_value, 10.0L / 3.0L));
  REQUIRE(bound.value().exact_raw_value);
  CHECK(*bound.value().exact_raw_value == rational(10, 3));

  const auto* reference_norm = find_constant(
      bound.value(),
      mwperf::ErrorBoundConstantKindV1::reference_resolvent_norm);
  const auto* kernel_defect = find_constant(
      bound.value(),
      mwperf::ErrorBoundConstantKindV1::killed_kernel_defect_norm);
  const auto* potential_norm = find_constant(
      bound.value(),
      mwperf::ErrorBoundConstantKindV1::approximate_potential_norm);
  const auto* entrance_defect = find_constant(
      bound.value(),
      mwperf::ErrorBoundConstantKindV1::entrance_defect_dual_norm);
  REQUIRE(reference_norm != nullptr);
  REQUIRE(reference_norm->exact_value);
  CHECK(*reference_norm->exact_value == rational(2, 1));
  REQUIRE(kernel_defect != nullptr);
  REQUIRE(kernel_defect->exact_value);
  CHECK(*kernel_defect->exact_value == rational(1, 4));
  REQUIRE(potential_norm != nullptr);
  REQUIRE(potential_norm->exact_value);
  CHECK(*potential_norm->exact_value == rational(4, 3));
  REQUIRE(entrance_defect != nullptr);
  REQUIRE(entrance_defect->exact_value);
  CHECK(*entrance_defect->exact_value == rational(2, 1));

  auto unsupported_approximate = resolvent;
  unsupported_approximate.evidence_id =
      object("c25.resolvent.approximate-inverse");
  unsupported_approximate.certified_inverse_residual_conversion = 0.125L;
  auto approximate_certificates = validate_transfer_nodes(
      fixture.framework, {pair, unsupported_approximate},
      {pair.evidence_id, unsupported_approximate.evidence_id});
  auto approximate_pair =
      approximate_certificates.killed_kernel_pair(pair.evidence_id);
  auto approximate_witness = approximate_certificates.resolvent_witness(
      unsupported_approximate.evidence_id);
  REQUIRE(approximate_pair);
  REQUIRE(approximate_witness);
  auto unavailable = mwperf::compute_stopped_resolvent_transfer(
      approximate_pair.value(), approximate_witness.value());
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code ==
        "c25.approximate_resolvent_conversion_unavailable");
}

TEST_CASE("C25 killed resolvent rejects singular or false inverse evidence",
          "[c25][negative]") {
  auto fixture = temporal::make_generic_temporal_framework();

  SECTION("singular minimal potential") {
    const auto norm = operator_geometry("c25.resolvent.singular", 1U);
    const mwperf::KilledKernelPairEvidenceV1 pair{
        .evidence_id = object("c25.resolvent.singular.pair"),
        .reference_law = object("c25.resolvent.singular.reference"),
        .approximate_law = object("c25.resolvent.singular.approximate"),
        .state_order_identity = norm.state_space_identity,
        .stopping_event_identity = matrix::digest("c25.resolvent.singular.stop"),
        .common_lift_identity = matrix::digest("c25.resolvent.singular.lift"),
        .reference_killed_kernel = {1U, 1U, {rational(1, 1)}},
        .approximate_killed_kernel = {1U, 1U, {rational(0, 1)}},
        .reference_entrance_law = std::nullopt,
        .approximate_entrance_law = std::nullopt,
        .reference_c23_entrance = std::nullopt,
        .approximate_c23_entrance = std::nullopt,
        .common_state_and_lift_established = true,
        .dependencies = {},
    };
    const mwperf::ResolventEvidenceV1 resolvent{
        .evidence_id = object("c25.resolvent.singular.witness"),
        .killed_pair_id = pair.evidence_id,
        .norm = norm,
        .reference_resolvent = {1U, 1U, {rational(1, 1)}},
        .approximate_resolvent = {1U, 1U, {rational(1, 1)}},
        .bounded_neumann_resolvents = true,
        .space_contains_one = true,
        .minimal_potentials_finite = true,
        .certified_inverse_residual_conversion = std::nullopt,
        .dependencies = {pair.evidence_id},
    };
    auto certificates = validate_transfer_nodes(
        fixture.framework, {pair, resolvent},
        {pair.evidence_id, resolvent.evidence_id});
    auto pair_view = certificates.killed_kernel_pair(pair.evidence_id);
    auto witness = certificates.resolvent_witness(resolvent.evidence_id);
    REQUIRE(pair_view);
    REQUIRE(witness);
    auto rejected = mwperf::compute_stopped_resolvent_transfer(
        pair_view.value(), witness.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.killed_resolvent_singular");
  }

  SECTION("authored inverse mismatch") {
    const auto norm = operator_geometry("c25.resolvent.inverse", 1U);
    const mwperf::KilledKernelPairEvidenceV1 pair{
        .evidence_id = object("c25.resolvent.inverse.pair"),
        .reference_law = object("c25.resolvent.inverse.reference"),
        .approximate_law = object("c25.resolvent.inverse.approximate"),
        .state_order_identity = norm.state_space_identity,
        .stopping_event_identity = matrix::digest("c25.resolvent.inverse.stop"),
        .common_lift_identity = matrix::digest("c25.resolvent.inverse.lift"),
        .reference_killed_kernel = {1U, 1U, {rational(1, 2)}},
        .approximate_killed_kernel = {1U, 1U, {rational(1, 4)}},
        .reference_entrance_law = std::nullopt,
        .approximate_entrance_law = std::nullopt,
        .reference_c23_entrance = std::nullopt,
        .approximate_c23_entrance = std::nullopt,
        .common_state_and_lift_established = true,
        .dependencies = {},
    };
    const mwperf::ResolventEvidenceV1 resolvent{
        .evidence_id = object("c25.resolvent.inverse.witness"),
        .killed_pair_id = pair.evidence_id,
        .norm = norm,
        .reference_resolvent = {1U, 1U, {rational(3, 1)}},
        .approximate_resolvent = {1U, 1U, {rational(4, 3)}},
        .bounded_neumann_resolvents = true,
        .space_contains_one = true,
        .minimal_potentials_finite = true,
        .certified_inverse_residual_conversion = std::nullopt,
        .dependencies = {pair.evidence_id},
    };
    auto certificates = validate_transfer_nodes(
        fixture.framework, {pair, resolvent},
        {pair.evidence_id, resolvent.evidence_id});
    auto pair_view = certificates.killed_kernel_pair(pair.evidence_id);
    auto witness = certificates.resolvent_witness(resolvent.evidence_id);
    REQUIRE(pair_view);
    REQUIRE(witness);
    auto rejected = mwperf::compute_stopped_resolvent_transfer(
        pair_view.value(), witness.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.resolvent_inverse_identity_failed");
  }
}

TEST_CASE("C25 drift keeps time-average and recurrence conclusions separate",
          "[c25][unit]") {
  auto fixture = make_iid_framework();

  SECTION("time-average drift only") {
    constexpr std::string_view name{"c25.drift.average"};
    auto drift = drift_evidence(fixture.framework, name);
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto result = mwperf::validate_drift_stability_witness(
        witness.value(), fixture.framework);
    REQUIRE(result);
    CHECK(result.value().strongest_conclusion ==
          mwperf::StabilityConclusionV1::time_average_drift);
    CHECK(result.value().time_average_claim ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(result.value().positive_recurrence_claim ==
          mwperf::CertificateClaimStateV1::not_established);
    CHECK(close(*result.value().drift_constant_c0, 5.0L));
    CHECK(close(*result.value().negative_drift_coefficient, 0.2L));
    CHECK(close(*result.value().time_average_backlog_bound, 35.0L));
  }

  SECTION("positive recurrence requires every extra premise") {
    constexpr std::string_view name{"c25.drift.recurrent"};
    auto drift = drift_evidence(fixture.framework, name);
    drift.irreducible = true;
    drift.petite_set = true;
    drift.norm_like_all_unbounded_phases = true;
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto result = mwperf::validate_drift_stability_witness(
        witness.value(), fixture.framework);
    REQUIRE(result);
    CHECK(result.value().strongest_conclusion ==
          mwperf::StabilityConclusionV1::positive_recurrence);
    CHECK(result.value().recurrence_claim ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(result.value().positive_recurrence_claim ==
          mwperf::CertificateClaimStateV1::established);
  }
}

TEST_CASE("C25 drift rejects missing slack, domain, schedule, and binding",
          "[c25][negative]") {
  auto fixture = make_iid_framework();

  SECTION("delta equality has no negative drift") {
    constexpr std::string_view name{"c25.drift.equal-slack"};
    auto drift = drift_evidence(fixture.framework, name);
    drift.delta = drift.epsilon;
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto rejected = mwperf::validate_drift_stability_witness(
        witness.value(), fixture.framework);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.drift_slack_invalid");
  }

  SECTION("finite rows do not replace forward invariance") {
    constexpr std::string_view name{"c25.drift.non-invariant"};
    auto drift = drift_evidence(fixture.framework, name);
    drift.declared_domain_forward_invariant = false;
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto rejected = mwperf::validate_drift_stability_witness(
        witness.value(), fixture.framework);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c25.drift_domain_not_forward_invariant");
  }

  SECTION("independent target services are not one common schedule") {
    constexpr std::string_view name{"c25.drift.no-common-schedule"};
    auto drift = drift_evidence(fixture.framework, name);
    drift.rows.back().common_feasible_schedule = false;
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto rejected = mwperf::validate_drift_stability_witness(
        witness.value(), fixture.framework);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.drift_common_schedule_missing");
  }

  SECTION("a validated view remains bound to its issuing framework") {
    constexpr std::string_view name{"c25.drift.foreign-framework"};
    auto second_fixture = temporal::make_generic_temporal_framework();
    auto drift = drift_evidence(fixture.framework, name);
    const auto drift_id = drift.evidence_id;
    auto certificates = validate_drift(
        fixture.framework, std::move(drift), premise_record(name));
    auto witness = certificates.drift_witness(drift_id);
    REQUIRE(witness);
    auto rejected = mwperf::validate_drift_stability_witness(
        witness.value(), second_fixture.framework);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.drift_framework_mismatch");
  }
}

TEST_CASE("C25 IID response envelopes distinguish Bernoulli and batch order",
          "[c25][unit]") {
  auto fixture = make_iid_framework();
  const auto mean_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-mean","kind":"stationary_backlog_moment","parameters":{"order":1}})json");

  SECTION("Bernoulli reachable tail has MLR and stochastic order") {
    auto envelope = envelope_evidence(
        fixture.framework, fixture.ordered_targets.front(),
        "c25.envelope.bernoulli");
    const auto id = envelope.evidence_id;
    auto certificates = validate_envelope(fixture.framework,
                                          std::move(envelope));
    auto view = certificates.response_envelope(id);
    auto arrival = certificates.certificate_arrival_law(id);
    REQUIRE(view);
    REQUIRE(arrival);
    auto interval = mwperf::evaluate_response_envelope(
        view.value(), arrival.value(), mean_request);
    REQUIRE(interval);
    CHECK(interval.value().claim_state ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(interval.value().route ==
          mwperf::EnvelopeEvaluationRouteV1::reachable_tail_strict_slack);
    CHECK(interval.value().order_strength ==
          mwperf::ResponseOrderStrengthV1::stationary_mlr_and_stochastic);
    REQUIRE(interval.value().lower.numerical_value);
    REQUIRE(interval.value().upper.numerical_value);
    CHECK(*interval.value().lower.numerical_value <=
          *interval.value().upper.numerical_value);
    CHECK(interval.value().physical_transfer_claim ==
          mwperf::CertificateClaimStateV1::not_established);
  }

  SECTION("a boundary middle response is not advertised as MLR") {
    auto envelope = envelope_evidence(
        fixture.framework, fixture.ordered_targets.front(),
        "c25.envelope.bernoulli-boundary-middle");
    // The slow and fast comparison laws remain valid interior Bernoulli
    // birth-death laws, but the evaluated middle response has a boundary
    // coefficient.  MLR requires all three laws to satisfy the interior
    // premise.
    envelope.mu_point.one = 1.0L;
    envelope.mu_plus.one = 1.0L;
    const auto id = envelope.evidence_id;
    auto certificates = validate_envelope(fixture.framework,
                                          std::move(envelope));
    auto view = certificates.response_envelope(id);
    auto arrival = certificates.certificate_arrival_law(id);
    REQUIRE(view);
    REQUIRE(arrival);
    auto interval = mwperf::evaluate_response_envelope(
        view.value(), arrival.value(), mean_request);
    REQUIRE(interval);
    CHECK(interval.value().claim_state ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(interval.value().order_strength ==
          mwperf::ResponseOrderStrengthV1::stationary_stochastic);
  }

  SECTION("arbitrary batches retain stochastic but not MLR order") {
    auto batch_fixture = make_iid_framework(true);
    const auto batch_mean_request = metric_request(
        batch_fixture.instance.queues(),
        R"json({"id":"c25-batch-mean","kind":"stationary_backlog_moment","parameters":{"order":1}})json");
    auto envelope = envelope_evidence(
        batch_fixture.framework, batch_fixture.ordered_targets.front(),
        "c25.envelope.batch");
    envelope.iid_target_marginal = {{0U, 0.85L}, {2U, 0.15L}};
    envelope.lambda = 0.3L;
    envelope.arrival_second_moment = 0.6L;
    const auto id = envelope.evidence_id;
    auto certificates = validate_envelope(batch_fixture.framework,
                                          std::move(envelope));
    auto view = certificates.response_envelope(id);
    auto arrival = certificates.certificate_arrival_law(id);
    REQUIRE(view);
    REQUIRE(arrival);
    auto interval = mwperf::evaluate_response_envelope(
        view.value(), arrival.value(), batch_mean_request);
    REQUIRE(interval);
    CHECK(interval.value().claim_state ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(interval.value().order_strength ==
          mwperf::ResponseOrderStrengthV1::stationary_stochastic);
  }
}

TEST_CASE("C25 exact finite closure precedes off-class tail slack",
          "[c25][unit]") {
  auto fixture = make_iid_framework();
  auto envelope = envelope_evidence(
      fixture.framework, fixture.ordered_targets.front(),
      "c25.envelope.closed");
  envelope.requested_route =
      mwperf::EnvelopeClosureRouteV1::exact_finite_closure;
  envelope.mu_minus = {1.0L, 0.0L, 0.0L};
  envelope.mu_point = {1.0L, 0.5L, 0.5L};
  envelope.mu_plus = {1.0L, 1.0L, 1.0L};
  envelope.closure.established = true;
  envelope.closure.exact_reachability = true;
  envelope.closure.unique_reachable_closed_class = true;
  envelope.closure.exact_inputs = mwperf::ExactFiniteEnvelopeInputsV1{
      .mu_minus = {rational(1, 1), rational(0, 1), rational(0, 1)},
      .mu_point = {rational(1, 1), rational(1, 2), rational(1, 2)},
      .mu_plus = {rational(1, 1), rational(1, 1), rational(1, 1)},
      .iid_target_marginal = {{0U, rational(7, 10)},
                              {1U, rational(3, 10)}},
  };
  envelope.arrival_second_moment_finite = false;
  envelope.tail.finite_second_moment = false;
  const auto id = envelope.evidence_id;
  auto certificates = validate_envelope(fixture.framework,
                                        std::move(envelope));
  auto view = certificates.response_envelope(id);
  auto arrival = certificates.certificate_arrival_law(id);
  REQUIRE(view);
  REQUIRE(arrival);

  const auto mean_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-closed-mean","kind":"stationary_backlog_moment","parameters":{"order":1}})json");
  auto mean = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), mean_request);
  REQUIRE(mean);
  CHECK(mean.value().route ==
        mwperf::EnvelopeEvaluationRouteV1::exact_finite_closure);
  CHECK(mean.value().tail_slack_status ==
        mwperf::EnvelopeTailSlackStatusV1::not_applicable_off_class);
  CHECK_FALSE(mean.value().slow_tail_slack.has_value());
  REQUIRE(mean.value().lower.exact_value);
  REQUIRE(mean.value().upper.exact_value);
  CHECK(*mean.value().lower.exact_value == rational(3, 10));
  CHECK(*mean.value().upper.exact_value == rational(3, 10));
  CHECK(close(*mean.value().lower.numerical_value, 0.3L));
  CHECK(close(*mean.value().upper.numerical_value, 0.3L));

  const auto sojourn_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-closed-sojourn","kind":"mean_sojourn","parameters":{}})json");
  auto sojourn = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), sojourn_request);
  REQUIRE(sojourn);
  CHECK(close(*sojourn.value().lower.numerical_value, 1.0L));
  CHECK(close(*sojourn.value().upper.numerical_value, 1.0L));
}

TEST_CASE("C25 exact closure requires exact typed theorem inputs",
          "[c25][unit][negative]") {
  auto fixture = make_iid_framework();
  auto envelope = envelope_evidence(
      fixture.framework, fixture.ordered_targets.front(),
      "c25.envelope.closed-missing-exact-inputs");
  envelope.requested_route =
      mwperf::EnvelopeClosureRouteV1::exact_finite_closure;
  envelope.mu_minus = {1.0L, 0.0L, 0.0L};
  envelope.mu_point = {1.0L, 0.5L, 0.5L};
  envelope.mu_plus = {1.0L, 1.0L, 1.0L};
  envelope.closure.established = true;
  envelope.closure.exact_reachability = true;
  envelope.closure.unique_reachable_closed_class = true;
  const auto id = envelope.evidence_id;
  auto certificates = validate_envelope(fixture.framework,
                                        std::move(envelope));
  auto view = certificates.response_envelope(id);
  auto arrival = certificates.certificate_arrival_law(id);
  REQUIRE(view);
  REQUIRE(arrival);
  const auto request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-closed-no-exact","kind":"stationary_backlog_moment","parameters":{"order":1}})json");
  auto rejected = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), request);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c25.envelope_exact_closure_inputs_missing");
}

TEST_CASE("C25 reachable tails expose missing strict upper slack",
          "[c25][unit][negative]") {
  auto fixture = make_iid_framework();
  auto envelope = envelope_evidence(
      fixture.framework, fixture.ordered_targets.front(),
      "c25.envelope.no-slow-slack");
  envelope.mu_minus.tail = envelope.lambda;
  const auto id = envelope.evidence_id;
  auto certificates = validate_envelope(fixture.framework,
                                        std::move(envelope));
  auto view = certificates.response_envelope(id);
  auto arrival = certificates.certificate_arrival_law(id);
  REQUIRE(view);
  REQUIRE(arrival);
  const auto request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-no-slack","kind":"stationary_backlog_moment","parameters":{"order":1}})json");
  auto interval = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), request);
  REQUIRE(interval);
  CHECK(interval.value().claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(interval.value().upper.value_status ==
        mwperf::BoundValueStatusV1::unresolved);
  CHECK(interval.value().upper.claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(interval.value().lower.value_status ==
        mwperf::BoundValueStatusV1::finite);
}

TEST_CASE("C25 temporal envelopes require an accepted exact metric route",
          "[c25][unit]") {
  auto fixture = temporal::make_generic_temporal_framework();
  auto envelope = envelope_evidence(
      fixture.framework, fixture.ordered_targets.front(),
      "c25.envelope.temporal");
  envelope.arrival_semantics =
      mwperf::EnvelopeArrivalSemanticsV1::temporal_augmented;
  envelope.iid_target_marginal.clear();
  envelope.requested_route =
      mwperf::EnvelopeClosureRouteV1::temporal_backend;
  const auto mean_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-temporal-mean","kind":"stationary_backlog_moment","parameters":{"order":1}})json");
  const auto authorized_tail_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-temporal-tail","kind":"stationary_backlog_tail","parameters":{"threshold":3}})json");
  auto mean_digest = mwperf::canonical_metric_requirements_digest(
      mwperf::requirements_for_metric(mean_request));
  auto tail_digest = mwperf::canonical_metric_requirements_digest(
      mwperf::requirements_for_metric(authorized_tail_request));
  REQUIRE(mean_digest);
  REQUIRE(tail_digest);
  auto bound = mwperf::Evidence::bind(fixture.framework, {});
  REQUIRE(bound);
  const mwperf::CertificatePremiseEvidenceV1 backend_premise{
      .evidence_id = object("c25.envelope.temporal.backend.premise"),
      .supported_claim = mwperf::CertificateClaimKindV1::response_envelope,
      .subject_product_identity = envelope.subject_product_identity,
      .subject_law_identity = envelope.subject_law_identity,
      .premise_identity =
          matrix::digest("c25.envelope.temporal.backend.theorem-premise"),
      .provenance_identity =
          object("c25.envelope.temporal.backend.provenance"),
      .coverage = mwperf::CertificateCoverageV1::global_declared_domain,
      .origin =
          mwperf::CertificateEvidenceOriginV1::independent_a_priori,
      .dependencies = {}};
  envelope.dependencies = {backend_premise.evidence_id};
  envelope.temporal_backend = mwperf::TemporalEnvelopeBackendEvidenceV1{
      .accepted = true,
      .evidence_dependency = backend_premise.evidence_id,
      .accepted_contract_digest =
          bound.value().framework_bindings().accepted_contract_digest,
      .backend_identity = matrix::digest("c25.temporal.backend"),
      .theorem_identity = matrix::digest("c25.temporal.theorem"),
      .configured_arrival_identity = envelope.configured_arrival_identity,
      .slow_product_identity = envelope.slow_product_identity,
      .fast_product_identity = envelope.fast_product_identity,
      .metric_intervals =
          {{mwperf::MetricKindV1::stationary_backlog_moment,
            "c25-temporal-mean", mean_digest.value(),
            mwperf::BoundValueStatusV1::finite, 2.0L,
            mwperf::BoundValueStatusV1::finite, 5.0L},
           {mwperf::MetricKindV1::stationary_backlog_tail,
            "c25-temporal-tail", tail_digest.value(),
            mwperf::BoundValueStatusV1::finite, 0.1L,
            mwperf::BoundValueStatusV1::finite, 0.4L}},
      .common_arrival_phase_coupling = true,
      .service_independent_phase = true,
      .invariant_exists = true,
      .convergence_established = true,
  };
  const auto id = envelope.evidence_id;
  auto certificates = validate_nodes(
      fixture.framework, {backend_premise, envelope},
      [id](mwperf::CertificateBundle& bundle) {
        bundle.response_envelopes = {id};
      });
  auto view = certificates.response_envelope(id);
  auto arrival = certificates.certificate_arrival_law(id);
  REQUIRE(view);
  REQUIRE(arrival);
  auto interval = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), mean_request);
  REQUIRE(interval);
  CHECK(interval.value().route ==
        mwperf::EnvelopeEvaluationRouteV1::augmented_temporal_backend);
  CHECK(close(*interval.value().lower.numerical_value, 2.0L));
  CHECK(close(*interval.value().upper.numerical_value, 5.0L));

  auto authorized_tail = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), authorized_tail_request);
  REQUIRE(authorized_tail);
  CHECK(authorized_tail.value().claim_state ==
        mwperf::CertificateClaimStateV1::established);
  CHECK(close(*authorized_tail.value().lower.numerical_value, 0.1L));
  CHECK(close(*authorized_tail.value().upper.numerical_value, 0.4L));

  // Same human-readable ID and kind are insufficient: changing only the
  // threshold changes the canonical one-clause request digest.
  const auto unavailable_request = metric_request(
      fixture.instance.queues(),
      R"json({"id":"c25-temporal-tail","kind":"stationary_backlog_tail","parameters":{"threshold":4}})json");
  auto unavailable = mwperf::evaluate_response_envelope(
      view.value(), arrival.value(), unavailable_request);
  REQUIRE(unavailable);
  CHECK(unavailable.value().claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(unavailable.value().route ==
        mwperf::EnvelopeEvaluationRouteV1::augmented_temporal_backend);
  CHECK(unavailable.value().lower.value_status ==
        mwperf::BoundValueStatusV1::unresolved);
}

TEST_CASE("C25 envelope identities cannot be substituted by numeric equality",
          "[c25][negative]") {
  auto fixture = make_iid_framework();
  auto envelope = envelope_evidence(
      fixture.framework, fixture.ordered_targets.front(),
      "c25.envelope.identity");
  envelope.requested_route =
      mwperf::EnvelopeClosureRouteV1::exact_finite_closure;
  envelope.mu_minus = {1.0L, 0.0L, 0.0L};
  envelope.mu_point = envelope.mu_minus;
  envelope.mu_plus = envelope.mu_minus;
  envelope.closure.established = true;
  envelope.closure.exact_reachability = true;
  envelope.closure.unique_reachable_closed_class = true;
  // Equal coefficients do not turn a deployed-point identity into the named
  // slow-envelope product identity.
  envelope.closure.bound_slow_product_identity =
      envelope.subject_product_identity;
  auto evidence = mwperf::Evidence::bind(fixture.framework, {envelope});
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.response_envelopes = {envelope.evidence_id};
  auto rejected = mwperf::validate_certificate_bundle(
      bundle, fixture.framework, evidence.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c25.envelope_closure_product_mismatch");
}

TEST_CASE("C25 finite TV bounds are monotone bounded and below their union bound",
          "[c25][property]") {
  auto fixture = temporal::make_generic_temporal_framework();
  constexpr std::array defects{0.0L, 0.000001L, 0.02L, 0.2L, 0.75L,
                               1.0L};
  const auto geometry = tv_geometry("c25.property.tv.common");
  std::vector<mwperf::RowErrorEvidenceV1> rows;
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes;
  std::vector<mwperf::CertificateEvidenceIdV1> selected;
  rows.reserve(defects.size());
  nodes.reserve(defects.size());
  selected.reserve(defects.size());
  for (std::size_t index = 0U; index < defects.size(); ++index) {
    auto row = row_error(
        "c25.property.tv." + std::to_string(index),
        mwperf::RowErrorKindV1::marked_residence_event_row, geometry,
        defects[index]);
    selected.push_back(row.evidence_id);
    rows.push_back(row);
    nodes.emplace_back(std::move(row));
  }
  auto certificates = validate_transfer_nodes(
      fixture.framework, std::move(nodes), std::move(selected));

  std::array<std::array<long double, 13U>, defects.size()> values{};
  for (std::size_t defect_index = 0U; defect_index < defects.size();
       ++defect_index) {
    auto view = certificates.row_error_bound(
        rows[defect_index].evidence_id);
    REQUIRE(view);
    long double previous = 0.0L;
    for (std::uint64_t horizon = 0U; horizon <= 12U; ++horizon) {
      auto bound = mwperf::compute_finite_horizon_tv_transfer(
          view.value(), mwperf::Horizon{horizon});
      REQUIRE(bound);
      REQUIRE(bound.value().presented_value);
      REQUIRE(bound.value().union_bound);
      const long double value = *bound.value().presented_value;
      values[defect_index][static_cast<std::size_t>(horizon)] = value;
      CHECK(value >= 0.0L);
      CHECK(value <= 1.0L);
      CHECK(value <= *bound.value().union_bound + kTolerance);
      CHECK(value + kTolerance >= previous);
      previous = value;
    }
  }
  for (std::size_t defect_index = 1U; defect_index < defects.size();
       ++defect_index) {
    for (std::size_t horizon = 0U; horizon <= 12U; ++horizon) {
      CHECK(values[defect_index][horizon] + kTolerance >=
            values[defect_index - 1U][horizon]);
    }
  }
}

TEST_CASE("C25 contraction bounds are monotone in defect and conditioning",
          "[c25][property]") {
  auto fixture = temporal::make_generic_temporal_framework();
  constexpr std::array defects{0.01L, 0.05L, 0.2L, 0.6L};
  constexpr std::array coefficients{0.0L, 0.25L, 0.5L, 0.9L};
  const auto geometry = tv_geometry("c25.property.contraction.common");
  std::array<std::array<long double, coefficients.size()>, defects.size()>
      raw_values{};

  for (std::size_t defect_index = 0U; defect_index < defects.size();
       ++defect_index) {
    for (std::size_t coefficient_index = 0U;
         coefficient_index < coefficients.size(); ++coefficient_index) {
      const std::string name =
          "c25.property.contraction." + std::to_string(defect_index) + "." +
          std::to_string(coefficient_index);
      auto row = row_error(
          name, mwperf::RowErrorKindV1::stationary_uniform_total_variation,
          geometry, defects[defect_index]);
      const mwperf::ContractionEvidenceV1 contraction{
          .evidence_id = object(name + ".witness"),
          .row_error_id = row.evidence_id,
          .reference_kernel = row.reference_law,
          .approximate_kernel = row.approximate_law,
          .reference_invariant_law = object(name + ".pi"),
          .approximate_invariant_law = object(name + ".pihat"),
          .geometry = geometry,
          .coefficient = coefficients[coefficient_index],
          .invariant_laws_established = true,
          .reference_first_moment_finite = true,
          .approximate_first_moment_finite = true,
          .shared_foster_lyapunov_tail = true,
          .dependencies = {row.evidence_id}};
      auto certificates = validate_transfer_nodes(
          fixture.framework, {row, contraction},
          {row.evidence_id, contraction.evidence_id});
      auto row_view = certificates.row_error_bound(row.evidence_id);
      auto witness =
          certificates.contraction_witness(contraction.evidence_id);
      REQUIRE(row_view);
      REQUIRE(witness);
      auto bound = mwperf::compute_contraction_transfer(
          row_view.value(), witness.value(), geometry);
      REQUIRE(bound);
      REQUIRE(bound.value().raw_value);
      CHECK(bound.value().geometry.kind() ==
            mwperf::TransferGeometryKindV1::total_variation);
      raw_values[defect_index][coefficient_index] =
          *bound.value().raw_value;
      CHECK(close(*bound.value().raw_value,
                  defects[defect_index] /
                      (1.0L - coefficients[coefficient_index])));
    }
  }
  for (std::size_t defect = 0U; defect < defects.size(); ++defect) {
    for (std::size_t coefficient = 1U;
         coefficient < coefficients.size(); ++coefficient) {
      CHECK(raw_values[defect][coefficient] + kTolerance >=
            raw_values[defect][coefficient - 1U]);
    }
  }
  for (std::size_t defect = 1U; defect < defects.size(); ++defect) {
    for (std::size_t coefficient = 0U;
         coefficient < coefficients.size(); ++coefficient) {
      CHECK(raw_values[defect][coefficient] + kTolerance >=
            raw_values[defect - 1U][coefficient]);
    }
  }
}

TEST_CASE("C25 random small absorbed kernels obey the resolvent inequality",
          "[c25][property]") {
  auto fixture = temporal::make_generic_temporal_framework();
  std::mt19937_64 rng(0xC2504ULL);
  std::uniform_int_distribution<int> substochastic(0, 7);
  for (std::size_t trial = 0U; trial < 8U; ++trial) {
    const int a0 = substochastic(rng);
    const int a1 = substochastic(rng);
    const int b0 = substochastic(rng);
    const int b1 = substochastic(rng);
    const std::string name =
        "c25.property.resolvent." + std::to_string(trial);
    const auto norm = operator_geometry(name, 2U);
    const mwperf::KilledKernelPairEvidenceV1 pair{
        .evidence_id = object(name + ".pair"),
        .reference_law = object(name + ".reference"),
        .approximate_law = object(name + ".approximate"),
        .state_order_identity = norm.state_space_identity,
        .stopping_event_identity = matrix::digest(name + ".stop"),
        .common_lift_identity = matrix::digest(name + ".lift"),
        .reference_killed_kernel =
            {2U, 2U,
             {rational(a0, 10), rational(0, 1), rational(0, 1),
              rational(a1, 10)}},
        .approximate_killed_kernel =
            {2U, 2U,
             {rational(b0, 10), rational(0, 1), rational(0, 1),
              rational(b1, 10)}},
        .reference_entrance_law = std::nullopt,
        .approximate_entrance_law = std::nullopt,
        .reference_c23_entrance = std::nullopt,
        .approximate_c23_entrance = std::nullopt,
        .common_state_and_lift_established = true,
        .dependencies = {}};
    const mwperf::ResolventEvidenceV1 resolvent{
        .evidence_id = object(name + ".witness"),
        .killed_pair_id = pair.evidence_id,
        .norm = norm,
        .reference_resolvent =
            {2U, 2U,
             {rational(10, 10 - a0), rational(0, 1), rational(0, 1),
              rational(10, 10 - a1)}},
        .approximate_resolvent =
            {2U, 2U,
             {rational(10, 10 - b0), rational(0, 1), rational(0, 1),
              rational(10, 10 - b1)}},
        .bounded_neumann_resolvents = true,
        .space_contains_one = true,
        .minimal_potentials_finite = true,
        .certified_inverse_residual_conversion = std::nullopt,
        .dependencies = {pair.evidence_id}};
    auto certificates = validate_transfer_nodes(
        fixture.framework, {pair, resolvent},
        {pair.evidence_id, resolvent.evidence_id});
    auto pair_view = certificates.killed_kernel_pair(pair.evidence_id);
    auto witness = certificates.resolvent_witness(resolvent.evidence_id);
    REQUIRE(pair_view);
    REQUIRE(witness);
    auto bound = mwperf::compute_stopped_resolvent_transfer(
        pair_view.value(), witness.value());
    REQUIRE(bound);
    REQUIRE(bound.value().raw_value);
    const long double actual = std::max(
        std::fabs(10.0L / static_cast<long double>(10 - a0) -
                  10.0L / static_cast<long double>(10 - b0)),
        std::fabs(10.0L / static_cast<long double>(10 - a1) -
                  10.0L / static_cast<long double>(10 - b1)));
    CHECK(actual <= *bound.value().raw_value + kTolerance);
  }
}

TEST_CASE("C25 arbitrary-batch common coupling preserves envelope queue order",
          "[c25][property]") {
  const mwperf::ScalarResponseCoefficientsV1 slow{0.15L, 0.80L, 0.25L};
  const mwperf::ScalarResponseCoefficientsV1 middle{0.45L, 0.90L, 0.55L};
  const mwperf::ScalarResponseCoefficientsV1 fast{0.75L, 0.95L, 0.85L};
  CHECK(slow.one < slow.two);
  CHECK(slow.tail < slow.two);
  CHECK(middle.tail < middle.two);
  const auto probability = [](const mwperf::ScalarResponseCoefficientsV1& mu,
                              const std::uint64_t backlog) {
    if (backlog == 0U) return 0.0L;
    if (backlog == 1U) return mu.one;
    if (backlog == 2U) return mu.two;
    return mu.tail;
  };
  const auto step = [&](const std::uint64_t backlog,
                        const std::uint64_t batch, const long double uniform,
                        const mwperf::ScalarResponseCoefficientsV1& mu) {
    const bool served = backlog > 0U && uniform < probability(mu, backlog);
    return backlog - static_cast<std::uint64_t>(served) + batch;
  };

  std::mt19937_64 rng(0xC2506ULL);
  std::uniform_int_distribution<std::uint64_t> batch(0U, 5U);
  std::uniform_real_distribution<long double> uniform(0.0L, 1.0L);
  std::uint64_t plus = 0U;
  std::uint64_t point = 0U;
  std::uint64_t minus = 0U;
  for (std::size_t slot = 0U; slot < 500U; ++slot) {
    const std::uint64_t arrivals = batch(rng);
    const long double service_uniform = uniform(rng);
    plus = step(plus, arrivals, service_uniform, fast);
    point = step(point, arrivals, service_uniform, middle);
    minus = step(minus, arrivals, service_uniform, slow);
    CHECK(plus <= point);
    CHECK(point <= minus);
  }
}

TEST_CASE("C25 distinguishes joint IID drift data from target marginals and temporal replay",
          "[c25][property][negative]") {
  struct JointAtom final {
    std::uint64_t first;
    std::uint64_t second;
    long double probability;
  };
  const std::array correlated{JointAtom{0U, 0U, 0.5L},
                              JointAtom{1U, 1U, 0.5L}};
  const std::array anticorrelated{JointAtom{0U, 1U, 0.5L},
                                  JointAtom{1U, 0U, 0.5L}};
  const auto target_mean = [](const auto& law) {
    long double result = 0.0L;
    for (const auto& atom : law) {
      result = std::fma(static_cast<long double>(atom.first),
                        atom.probability, result);
    }
    return result;
  };
  const auto joint_squared_norm = [](const auto& law) {
    long double result = 0.0L;
    for (const auto& atom : law) {
      const long double first = static_cast<long double>(atom.first);
      const long double second = static_cast<long double>(atom.second);
      result = std::fma(first * first + second * second, atom.probability,
                        result);
    }
    return result;
  };
  CHECK(close(target_mean(correlated), target_mean(anticorrelated)));
  // The scalar target envelope sees the same Bernoulli marginal, while a
  // joint drift witness still owns the complete vector law.  A cross term in
  // another valid Lyapunov geometry distinguishes these two couplings.
  const auto squared_total = [](const auto& law) {
    long double result = 0.0L;
    for (const auto& atom : law) {
      const long double total =
          static_cast<long double>(atom.first + atom.second);
      result = std::fma(total * total, atom.probability, result);
    }
    return result;
  };
  CHECK(close(joint_squared_norm(correlated),
              joint_squared_norm(anticorrelated)));
  CHECK_FALSE(close(squared_total(correlated),
                    squared_total(anticorrelated)));

  auto temporal_fixture = temporal::make_generic_temporal_framework();
  auto iid_only = envelope_evidence(
      temporal_fixture.framework, temporal_fixture.ordered_targets.front(),
      "c25.property.temporal-not-iid");
  auto evidence = mwperf::Evidence::bind(temporal_fixture.framework,
                                         {iid_only});
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.response_envelopes = {iid_only.evidence_id};
  auto rejected = mwperf::validate_certificate_bundle(
      bundle, temporal_fixture.framework, evidence.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c25.envelope_configured_arrival_not_exact_iid");
  CHECK(iid_only.subject_product.stage ==
        mwperf::ResponseProductStageV1::recoded_response);
}
