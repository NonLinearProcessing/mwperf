#include <atomic>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct LexFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c05-lex";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] LexFixture make_fixture(const std::size_t dimension,
                                      const bool reverse_priority = false) {
  std::string queues{"["};
  std::string priority{"["};
  for (std::size_t index = 0; index < dimension; ++index) {
    if (index != 0U) {
      queues += ',';
      priority += ',';
    }
    queues += "\"q" + std::to_string(index) + "\"";
    const std::size_t rank_queue =
        reverse_priority ? dimension - index - 1U : index;
    priority += "\"q" + std::to_string(rank_queue) + "\"";
  }
  queues += ']';
  priority += ']';

  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      queues +
      R"(},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":)" +
      priority +
      R"(,"max_search_states":null}},"arrival":{"family":"deterministic_trace","events":[]}})";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto resolved_priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(resolved_priority);

  mwperf::detail::ConstraintCompilerServices compilers;
  compilers.conflicts = [](const mwperf::ResolvedConflictConstraint&) {
    std::shared_ptr<const void> owner = std::make_shared<const int>(17);
    return mwperf::CompiledConstraintProduct::for_fixture(
        mwperf::ServiceFamily::pairwise_conflicts, std::move(owner));
  };
  auto descriptor =
      mwperf::detail::compile_constraint_descriptor_with_child_services(
          model.value().scheduler, catalog.value(), compilers);
  REQUIRE(descriptor);
  return LexFixture{std::move(catalog).value(),
                    std::move(resolved_priority).value(),
                    std::move(descriptor).value()};
}

[[nodiscard]] mwperf::Digest256 zero_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '0'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension_token(
    const LexFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      zero_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority,
      mwperf::OptimizerBudgetPolicy{
          .physical_per_call = std::nullopt,
          .analysis_per_call = std::nullopt,
          .effective_per_call = std::nullopt,
          .max_calls = std::nullopt,
      });
}

[[nodiscard]] mwperf::PrimaryWeights weights(
    const LexFixture& fixture, std::vector<mwperf::BigNat> values) {
  auto result = mwperf::PrimaryWeights::from_values(dimension_token(fixture),
                                                    std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::EligibilityMask eligibility(
    const LexFixture& fixture, std::vector<std::uint8_t> values) {
  auto result = mwperf::EligibilityMask::from_bytes(dimension_token(fixture),
                                                    std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C05 composes the exact one-solve lexicographic weights",
          "[c05][unit][lex]") {
  SECTION("m equals one") {
    const auto fixture = make_fixture(1U);
    const auto primary = weights(fixture, {mwperf::BigNat(3U)});
    const auto mask = eligibility(fixture, {1U});
    auto composed = mwperf::compose_lexicographic_weights(
        primary, fixture.priority, mask);
    REQUIRE(composed);
    CHECK(composed.value().primary_scale().to_decimal_string() == "2");
    CHECK(composed.value().values()[0].to_decimal_string() == "7");
    CHECK(composed.value().secondary_weights()[0].to_decimal_string() == "1");
  }

  SECTION("m equals two") {
    const auto fixture = make_fixture(2U);
    const auto primary = weights(
        fixture, {mwperf::BigNat(3U), mwperf::BigNat(5U)});
    const auto mask = eligibility(fixture, {1U, 1U});
    auto composed = mwperf::compose_lexicographic_weights(
        primary, fixture.priority, mask);
    REQUIRE(composed);
    CHECK(composed.value().primary_scale().to_decimal_string() == "4");
    CHECK(composed.value().values()[0].to_decimal_string() == "14");
    CHECK(composed.value().values()[1].to_decimal_string() == "21");
    CHECK(composed.value().secondary_weights()[0].to_decimal_string() == "2");
    CHECK(composed.value().secondary_weights()[1].to_decimal_string() == "1");
  }
}

TEST_CASE("C05 priority bits remain multiprecision beyond a machine word",
          "[c05][unit][lex]") {
  const auto fixture = make_fixture(65U);
  std::vector<mwperf::BigNat> zeroes;
  zeroes.reserve(65U);
  for (std::size_t index = 0; index < 65U; ++index) {
    zeroes.emplace_back(0U);
  }
  const auto primary = weights(fixture, std::move(zeroes));
  const auto mask = mwperf::EligibilityMask::all(dimension_token(fixture));
  auto composed = mwperf::compose_lexicographic_weights(
      primary, fixture.priority, mask);
  REQUIRE(composed);
  CHECK(composed.value().primary_scale().to_decimal_string() ==
        "36893488147419103232");
  CHECK(composed.value().secondary_weights().front().to_decimal_string() ==
        "18446744073709551616");
  CHECK(composed.value().secondary_weights().back().to_decimal_string() ==
        "1");
}

TEST_CASE("C05 a unit primary advantage dominates every priority bit",
          "[c05][unit][property][lex]") {
  for (std::size_t dimension = 1U; dimension <= 18U; ++dimension) {
    const auto fixture = make_fixture(dimension);
    std::vector<mwperf::BigNat> primary_values;
    primary_values.reserve(dimension);
    for (std::size_t index = 0; index < dimension; ++index) {
      primary_values.emplace_back(index == dimension - 1U ? 1U : 0U);
    }
    const auto primary = weights(fixture, std::move(primary_values));
    const auto mask = mwperf::EligibilityMask::all(dimension_token(fixture));
    auto composed = mwperf::compose_lexicographic_weights(
        primary, fixture.priority, mask);
    REQUIRE(composed);

    mwperf::BigNat all_losing_secondary(0U);
    for (std::size_t index = 0; index + 1U < dimension; ++index) {
      all_losing_secondary += composed.value().secondary_weights()[index];
    }
    CHECK(composed.value().at(fixture.catalog.index_at(dimension - 1U).value()) >
          all_losing_secondary);
  }
}

TEST_CASE("C05 priority reversal changes only secondary coordinate identity",
          "[c05][unit][lex]") {
  const auto forward = make_fixture(2U, false);
  const auto reverse = make_fixture(2U, true);
  const auto forward_primary = weights(
      forward, {mwperf::BigNat(0U), mwperf::BigNat(0U)});
  const auto reverse_primary = weights(
      reverse, {mwperf::BigNat(0U), mwperf::BigNat(0U)});
  auto forward_lex = mwperf::compose_lexicographic_weights(
      forward_primary, forward.priority,
      mwperf::EligibilityMask::all(dimension_token(forward)));
  auto reverse_lex = mwperf::compose_lexicographic_weights(
      reverse_primary, reverse.priority,
      mwperf::EligibilityMask::all(dimension_token(reverse)));
  REQUIRE(forward_lex);
  REQUIRE(reverse_lex);
  CHECK(forward_lex.value().secondary_weights()[0].to_decimal_string() == "2");
  CHECK(forward_lex.value().secondary_weights()[1].to_decimal_string() == "1");
  CHECK(reverse_lex.value().secondary_weights()[0].to_decimal_string() == "1");
  CHECK(reverse_lex.value().secondary_weights()[1].to_decimal_string() == "2");
}

TEST_CASE("C05 eligibility stays separate from exact weights",
          "[c05][unit][lex]") {
  const auto fixture = make_fixture(2U);
  auto huge = mwperf::BigNat::from_big_int(
      (mwperf::BigInt(1) << 300U) + mwperf::BigInt(9));
  REQUIRE(huge);
  const auto primary = weights(
      fixture, {std::move(huge).value(), mwperf::BigNat(1U)});
  const auto mask = eligibility(fixture, {0U, 1U});
  auto composed = mwperf::compose_lexicographic_weights(
      primary, fixture.priority, mask);
  REQUIRE(composed);
  CHECK_FALSE(composed.value().eligibility().at(
      fixture.catalog.index_at(0U).value()));
  CHECK(composed.value().primary_weight(
            fixture.catalog.index_at(0U).value()) >
        composed.value().primary_weight(
            fixture.catalog.index_at(1U).value()));
}

TEST_CASE("C05 rejects dimension identity and vector shape mismatches",
          "[c05][negative][lex]") {
  const auto left = make_fixture(2U);
  const auto foreign = make_fixture(2U);
  const auto primary = weights(
      left, {mwperf::BigNat(1U), mwperf::BigNat(2U)});
  const auto foreign_mask =
      mwperf::EligibilityMask::all(dimension_token(foreign));
  auto mismatch = mwperf::compose_lexicographic_weights(
      primary, left.priority, foreign_mask);
  REQUIRE_FALSE(mismatch);
  CHECK(mismatch.error().code == "lexicographic_dimension_identity_mismatch");

  auto wrong_length = mwperf::PrimaryWeights::from_values(
      dimension_token(left), {mwperf::BigNat(1U)});
  REQUIRE_FALSE(wrong_length);
  CHECK(wrong_length.error().code == "primary_weights_dimension_mismatch");

  auto nonbinary = mwperf::EligibilityMask::from_bytes(
      dimension_token(left), {1U, 2U});
  REQUIRE_FALSE(nonbinary);
  CHECK(nonbinary.error().code == "eligibility_not_binary");
}

TEST_CASE("C05 rejects a deliberately malformed priority carrier",
          "[c05][negative][lex]") {
  const auto fixture = make_fixture(2U);
  const auto first = fixture.catalog.index_at(0U).value();
  const auto malformed =
      mwperf::detail::LexicographicTestAccess::make_priority_for_fixture(
          {first, first}, {0U, 1U});
  const mwperf::OptimizerBudgetPolicy base{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
  const auto dimension = mwperf::QueueDimensionToken::for_fixture(
      zero_digest(), fixture.catalog.size(), fixture.descriptor, malformed,
      base);
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension, {mwperf::BigNat(1U), mwperf::BigNat(1U)});
  REQUIRE(primary);
  const auto mask = mwperf::EligibilityMask::all(dimension);
  auto composed = mwperf::compose_lexicographic_weights(
      primary.value(), malformed, mask);
  REQUIRE_FALSE(composed);
  CHECK(composed.error().code == "lexicographic_priority_not_permutation");
}
