#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ValidationFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

enum class CandidateFault : std::uint8_t {
  none,
  wrong_objective,
  wrong_family,
  wrong_backend,
  wrong_accounting,
  polynomial_expansion,
};

struct CandidatePlan final {
  std::vector<std::uint8_t> selected;
  CandidateFault fault = CandidateFault::none;
  std::optional<mwperf::QueueDimensionToken> schedule_dimension =
      std::nullopt;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c05-validation";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] mwperf::Result<mwperf::CompiledConstraintProduct> product(
    const mwperf::ServiceFamily family) {
  std::shared_ptr<const void> owner =
      std::make_shared<const std::string>(mwperf::to_string(family));
  return mwperf::CompiledConstraintProduct::for_fixture(family,
                                                        std::move(owner));
}

[[nodiscard]] mwperf::detail::ConstraintCompilerServices compilers() {
  return mwperf::detail::ConstraintCompilerServices{
      .crossbar = [](const mwperf::ResolvedCrossbarConstraint&) {
        return product(mwperf::ServiceFamily::crossbar_matching);
      },
      .intervals = [](const mwperf::ResolvedIntervalConstraint&) {
        return product(mwperf::ServiceFamily::nonoverlapping_intervals);
      },
      .node_exclusive = [](const mwperf::ResolvedNodeExclusiveConstraint&) {
        return product(mwperf::ServiceFamily::node_exclusive_matching);
      },
      .conflicts = [](const mwperf::ResolvedConflictConstraint&) {
        return product(mwperf::ServiceFamily::pairwise_conflicts);
      },
      .packing = [](const mwperf::ResolvedPackingConstraint&) {
        return product(mwperf::ServiceFamily::resource_packing);
      },
  };
}

[[nodiscard]] ValidationFixture compile_fixture(
    const std::string& queues, const std::string& scheduler) {
  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      queues + R"(},"scheduler":)" + scheduler +
      R"(,"arrival":{"family":"deterministic_trace","events":[]}})";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  const auto children = compilers();
  auto descriptor =
      mwperf::detail::compile_constraint_descriptor_with_child_services(
          model.value().scheduler, catalog.value(), children);
  REQUIRE(descriptor);
  return ValidationFixture{std::move(catalog).value(),
                           std::move(priority).value(),
                           std::move(descriptor).value()};
}

[[nodiscard]] mwperf::Digest256 digest(const char fill = '0') {
  auto result = mwperf::Digest256::from_hex(std::string(64U, fill));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy base_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::QueueDimensionToken token(
    const ValidationFixture& fixture, const char digest_fill = '0') {
  return mwperf::QueueDimensionToken::for_fixture(
      digest(digest_fill), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, base_policy());
}

struct Query final {
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

[[nodiscard]] Query query(const ValidationFixture& fixture,
                          std::vector<std::uint8_t> eligible = {1U, 1U}) {
  const auto dimension = token(fixture);
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension, {mwperf::BigNat(5U), mwperf::BigNat(3U)});
  REQUIRE(primary);
  auto mask = mwperf::EligibilityMask::from_bytes(dimension,
                                                  std::move(eligible));
  REQUIRE(mask);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, mask.value());
  REQUIRE(weights);
  return Query{std::move(mask).value(), std::move(weights).value()};
}

[[nodiscard]] mwperf::ServiceFamily other_family(
    const mwperf::ServiceFamily family) {
  return family == mwperf::ServiceFamily::resource_packing
             ? mwperf::ServiceFamily::crossbar_matching
             : mwperf::ServiceFamily::resource_packing;
}

[[nodiscard]] mwperf::OptimizerId other_backend(
    const mwperf::OptimizerId backend) {
  return backend == mwperf::OptimizerId::binary_packing_memo_exact
             ? mwperf::OptimizerId::hungarian_exact
             : mwperf::OptimizerId::binary_packing_memo_exact;
}

[[nodiscard]] mwperf::detail::ExactOptimizerBackendServices candidate_services(
    const ValidationFixture& fixture, CandidatePlan plan) {
  const auto expected = fixture.descriptor.identity();
  auto callback =
      [expected, plan = std::move(plan)](
          const auto&, const mwperf::CompiledConstraintProduct&,
          const mwperf::EligibilityMask&, const mwperf::LexWeights& weights,
          mwperf::SearchBudget& budget,
          const std::optional<mwperf::detail::ForcedTargetCondition>&,
          const mwperf::detail::ExactBackendAuthority& authority)
      -> mwperf::Result<mwperf::detail::ExactBackendCandidate> {
    const auto dimension = plan.schedule_dimension.has_value()
                               ? *plan.schedule_dimension
                               : weights.dimension();
    auto schedule = mwperf::Schedule::from_bytes(dimension, plan.selected);
    if (!schedule) {
      return mwperf::Result<mwperf::detail::ExactBackendCandidate>::failure(
          schedule.error());
    }

    mwperf::BigNat objective(0U);
    for (std::size_t index = 0U; index < plan.selected.size(); ++index) {
      if (plan.selected[index] != 0U) {
        objective += weights.values()[index];
      }
    }

    mwperf::ServiceFamily family = expected.family;
    mwperf::OptimizerId backend = expected.optimizer;
    mwperf::SearchAccounting accounting = budget.accounting();
    switch (plan.fault) {
      case CandidateFault::none:
        break;
      case CandidateFault::wrong_objective:
        objective += mwperf::BigNat(1U);
        break;
      case CandidateFault::wrong_family:
        family = other_family(family);
        break;
      case CandidateFault::wrong_backend:
        backend = other_backend(backend);
        break;
      case CandidateFault::wrong_accounting:
        accounting = mwperf::SearchAccounting::for_fixture(
            mwperf::BigNat(99U), accounting.effective_per_call_limit(),
            accounting.completed_expansions(), accounting.query_kind(),
            accounting.family(), accounting.exhausted(), accounting.target());
        break;
      case CandidateFault::polynomial_expansion:
        REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(budget));
        accounting = budget.accounting();
        break;
    }

    return mwperf::Result<mwperf::detail::ExactBackendCandidate>::success(
        authority.make_candidate(
            std::move(schedule).value(), std::move(objective), family,
            backend, std::move(accounting), {"exact test witness"}));
  };

  return mwperf::detail::ExactOptimizerBackendServices{
      .crossbar = callback,
      .intervals = callback,
      .node_exclusive = callback,
      .conflicts = callback,
      .packing = std::move(callback),
  };
}

[[nodiscard]] mwperf::Result<mwperf::OptimizerSolution> dispatch_candidate(
    const ValidationFixture& fixture, const Query& input,
    CandidatePlan plan) {
  auto context = mwperf::OptimizerExecutionContext::for_fixture(
      base_policy(), std::nullopt, token(fixture));
  REQUIRE(context);
  auto budget = mwperf::begin_search_budget(context.value());
  REQUIRE(budget);
  auto classified =
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary);
  REQUIRE(classified);
  const auto services = candidate_services(fixture, std::move(plan));
  return mwperf::detail::solve_exact_with_backend_services(
      fixture.descriptor, input.eligibility, input.weights, budget.value(),
      std::nullopt, services);
}

[[nodiscard]] std::vector<ValidationFixture> family_fixtures() {
  std::vector<ValidationFixture> result;
  result.push_back(compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i","output":"o0"},{"queue_id":"q1","input":"i","output":"o1"}]},"priority":null}})"));
  result.push_back(compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3}]},"priority":null}})"));
  result.push_back(compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"v","v":"w"}]},"priority":null}})"));
  result.push_back(compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":null}})"));
  result.push_back(compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]}]},"priority":null,"max_search_states":null}})"));
  return result;
}

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::ProvenOptimal>);
static_assert(!std::is_default_constructible_v<mwperf::OptimizerSolution>);
static_assert(
    !std::is_default_constructible_v<mwperf::detail::ExactBackendCandidate>);
static_assert(
    !std::is_default_constructible_v<mwperf::detail::ExactBackendAuthority>);
static_assert(
    !std::is_copy_constructible_v<mwperf::detail::ExactBackendAuthority>);
static_assert(
    !std::is_move_constructible_v<mwperf::detail::ExactBackendAuthority>);
static_assert(!std::is_convertible_v<mwperf::Schedule,
                                     mwperf::OptimizerSolution>);
static_assert(
    !std::is_convertible_v<mwperf::detail::ExactBackendCandidate,
                           mwperf::OptimizerSolution>);
static_assert(
    !std::is_convertible_v<mwperf::detail::PartialOptimizerCandidate,
                           mwperf::detail::ExactBackendCandidate>);
static_assert(
    !std::is_convertible_v<mwperf::detail::PartialOptimizerCandidate,
                           mwperf::OptimizerSolution>);

TEST_CASE("C05 promotes and publicly validates exact candidates for every family",
          "[c05][unit][validation]") {
  for (const auto& fixture : family_fixtures()) {
    const auto input = query(fixture);
    auto solved = dispatch_candidate(
        fixture, input, CandidatePlan{.selected = {1U, 0U}});
    INFO(mwperf::to_string(fixture.descriptor.family()));
    REQUIRE(solved);
    CHECK(mwperf::validate_optimizer_solution(
        solved.value(), fixture.descriptor, input.eligibility, input.weights));
    CHECK(solved.value().proof_notes().size() == 1U);
  }
}

TEST_CASE("C05 rejects infeasible candidate witnesses for every family",
          "[c05][unit][negative][validation]") {
  for (const auto& fixture : family_fixtures()) {
    const auto input = query(fixture);
    auto solved = dispatch_candidate(
        fixture, input, CandidatePlan{.selected = {1U, 1U}});
    INFO(mwperf::to_string(fixture.descriptor.family()));
    REQUIRE_FALSE(solved);
    CHECK(solved.error().code == "optimizer_schedule_infeasible");
  }
}

TEST_CASE("C05 rejects corrupt candidate objective family backend and accounting",
          "[c05][unit][negative][validation]") {
  const auto fixture = family_fixtures().at(3U);
  const auto input = query(fixture);

  const std::vector<std::pair<CandidateFault, std::string>> cases{
      {CandidateFault::wrong_objective,
       "optimizer_solution_objective_mismatch"},
      {CandidateFault::wrong_family, "optimizer_backend_family_mismatch"},
      {CandidateFault::wrong_backend, "optimizer_backend_identity_mismatch"},
      {CandidateFault::wrong_accounting,
       "optimizer_backend_accounting_mismatch"},
  };
  for (const auto& [fault, expected_code] : cases) {
    auto solved = dispatch_candidate(
        fixture, input,
        CandidatePlan{.selected = {1U, 0U}, .fault = fault});
    INFO(expected_code);
    REQUIRE_FALSE(solved);
    CHECK(solved.error().code == expected_code);
  }
}

TEST_CASE("C05 rejects ineligible candidate support before publication",
          "[c05][unit][negative][validation]") {
  const auto fixture = family_fixtures().at(3U);
  const auto input = query(fixture, {1U, 0U});
  auto solved = dispatch_candidate(
      fixture, input, CandidatePlan{.selected = {0U, 1U}});
  REQUIRE_FALSE(solved);
  CHECK(solved.error().code == "optimizer_schedule_ineligible");
}

TEST_CASE("C05 rejects recursive expansion charges from polynomial families",
          "[c05][unit][negative][validation]") {
  const auto fixture = family_fixtures().front();
  const auto input = query(fixture);
  auto solved = dispatch_candidate(
      fixture, input,
      CandidatePlan{.selected = {1U, 0U},
                    .fault = CandidateFault::polynomial_expansion});
  REQUIRE_FALSE(solved);
  CHECK(solved.error().code ==
        "optimizer_accounting_polynomial_expansions");
}

TEST_CASE("C05 dispatch rejects foreign schedule and query identities",
          "[c05][unit][negative][validation]") {
  const auto fixtures = family_fixtures();
  const auto& fixture = fixtures.at(3U);
  const auto input = query(fixture);

  const auto foreign_fixture = compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":null}})");
  auto foreign_schedule = dispatch_candidate(
      fixture, input,
      CandidatePlan{.selected = {1U, 0U},
                    .schedule_dimension = token(foreign_fixture)});
  REQUIRE_FALSE(foreign_schedule);
  CHECK(foreign_schedule.error().code ==
        "optimizer_backend_schedule_dimension_mismatch");

  const auto foreign_input = query(foreign_fixture);
  auto context = mwperf::OptimizerExecutionContext::for_fixture(
      base_policy(), std::nullopt, token(foreign_fixture));
  REQUIRE(context);
  auto budget = mwperf::begin_search_budget(context.value());
  REQUIRE(budget);
  const auto services = candidate_services(
      fixture, CandidatePlan{.selected = {1U, 0U}});
  auto wrong_descriptor = mwperf::detail::solve_exact_with_backend_services(
      fixture.descriptor, foreign_input.eligibility, foreign_input.weights,
      budget.value(), std::nullopt, services);
  REQUIRE_FALSE(wrong_descriptor);
  CHECK(wrong_descriptor.error().code ==
        "optimizer_dispatch_descriptor_dimension_mismatch");
}

TEST_CASE("C05 public validator detects identity and eligibility mismatch on a valid solution",
          "[c05][unit][negative][validation]") {
  const auto fixture = family_fixtures().at(3U);
  const auto input = query(fixture);
  auto solved = dispatch_candidate(
      fixture, input, CandidatePlan{.selected = {1U, 0U}});
  REQUIRE(solved);

  const auto foreign_fixture = compile_fixture(
      R"(["q0","q1"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":null}})");
  const auto foreign_input = query(foreign_fixture);
  auto dimension_result = mwperf::validate_optimizer_solution(
      solved.value(), fixture.descriptor, foreign_input.eligibility,
      input.weights);
  REQUIRE_FALSE(dimension_result);
  CHECK(dimension_result.error().code ==
        "optimizer_solution_dimension_identity_mismatch");

  auto constraint_result = mwperf::validate_optimizer_solution(
      solved.value(), foreign_fixture.descriptor, input.eligibility,
      input.weights);
  REQUIRE_FALSE(constraint_result);
  CHECK(constraint_result.error().code ==
        "optimizer_solution_constraint_identity_mismatch");

  auto alternate_eligibility =
      mwperf::EligibilityMask::from_bytes(token(fixture), {1U, 0U});
  REQUIRE(alternate_eligibility);
  auto eligibility_result = mwperf::validate_optimizer_solution(
      solved.value(), fixture.descriptor, alternate_eligibility.value(),
      input.weights);
  REQUIRE_FALSE(eligibility_result);
  CHECK(eligibility_result.error().code ==
        "optimizer_weight_eligibility_mismatch");
}

TEST_CASE("C05 binary and dimension carriers reject malformed schedules",
          "[c05][unit][negative][validation]") {
  const auto fixture = family_fixtures().at(3U);

  auto corrupt = mwperf::Schedule::from_bytes(token(fixture), {1U, 7U});
  REQUIRE_FALSE(corrupt);
  CHECK(corrupt.error().code == "schedule_not_binary");

  auto short_schedule = mwperf::Schedule::from_bytes(token(fixture), {1U});
  REQUIRE_FALSE(short_schedule);
  CHECK(short_schedule.error().code == "schedule_dimension_mismatch");
}
