#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/search_budget.hpp"

namespace {

[[nodiscard]] mwperf::OptimizerBudgetPolicy policy(
    std::optional<std::uint64_t> per_call,
    std::optional<std::uint64_t> max_calls) {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = per_call.has_value()
                               ? std::optional<mwperf::BigNat>(
                                     mwperf::BigNat(*per_call))
                               : std::nullopt,
      .effective_per_call = per_call.has_value()
                                ? std::optional<mwperf::BigNat>(
                                      mwperf::BigNat(*per_call))
                                : std::nullopt,
      .max_calls = max_calls.has_value()
                       ? std::optional<mwperf::BigNat>(
                             mwperf::BigNat(*max_calls))
                       : std::nullopt,
  };
}

[[nodiscard]] mwperf::OptimizerExecutionContext context(
    mwperf::OptimizerBudgetPolicy base,
    std::optional<std::uint64_t> assigned = std::nullopt) {
  auto result = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(base),
      assigned.has_value()
          ? std::optional<mwperf::BigNat>(mwperf::BigNat(*assigned))
          : std::nullopt);
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

static_assert(!std::is_copy_constructible_v<mwperf::OptimizerExecutionContext>);
static_assert(std::is_move_constructible_v<mwperf::OptimizerExecutionContext>);
static_assert(!std::is_move_assignable_v<mwperf::OptimizerExecutionContext>);
static_assert(!std::is_constructible_v<mwperf::OptimizerExecutionContext,
                                       mwperf::OptimizerBudgetPolicy>);
static_assert(!std::is_constructible_v<
              mwperf::OptimizerExecutionContext,
              mwperf::OptimizerCallLedgerSnapshot>);
static_assert(
    !std::is_default_constructible_v<mwperf::OptimizerCallLedgerObserver>);
static_assert(
    std::is_copy_constructible_v<mwperf::OptimizerCallLedgerObserver>);
static_assert(!std::is_constructible_v<
              mwperf::OptimizerExecutionContext,
              mwperf::OptimizerCallLedgerObserver>);
static_assert(!std::is_copy_constructible_v<mwperf::SearchBudget>);
static_assert(std::is_move_constructible_v<mwperf::SearchBudget>);
static_assert(!std::is_copy_assignable_v<mwperf::OptimizerCallLedgerSnapshot>);

TEST_CASE("C05 reserves exactly one optimizer call before work",
          "[c05][unit][budget]") {
  auto context = ::context(policy(std::nullopt, 2U));

  auto first = mwperf::begin_search_budget(context);
  REQUIRE(first);
  CHECK(first.value().call_ordinal().to_decimal_string() == "1");
  CHECK(first.value().completed_expansions().is_zero());
  CHECK_FALSE(first.value().effective_limit().has_value());

  auto second = mwperf::begin_search_budget(context);
  REQUIRE(second);
  CHECK(second.value().call_ordinal().to_decimal_string() == "2");

  const auto at_limit = context.ledger_snapshot();
  CHECK(at_limit.calls_reserved().to_decimal_string() == "2");
  REQUIRE(at_limit.assigned_max_calls().has_value());
  CHECK(at_limit.assigned_max_calls()->to_decimal_string() == "2");
  CHECK(at_limit.context_active());
  CHECK_FALSE(at_limit.has_remaining_capacity());

  auto rejected = mwperf::begin_search_budget(context);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "optimizer_call_limit_exhausted");
  CHECK(rejected.error().category == mwperf::DiagnosticCategory::resource_limit);
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() == "2");
}

TEST_CASE("C05 finite search limits have the exact L plus one boundary",
          "[c05][unit][budget]") {
  SECTION("zero permits no recursive expansion") {
    auto context = ::context(policy(0U, 1U));
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
        budget.value(), mwperf::ServiceFamily::pairwise_conflicts));

    auto first = mwperf::detail::SearchBudgetAccess::charge_expansion(
        budget.value());
    REQUIRE_FALSE(first);
    CHECK(first.error().code == "search_state_limit_exhausted");
    CHECK(budget.value().completed_expansions().is_zero());
    CHECK(budget.value().exhausted());
    const auto snapshot = context.ledger_snapshot();
    REQUIRE(snapshot.assigned_max_search_states().has_value());
    CHECK(snapshot.assigned_max_search_states()->is_zero());
    CHECK(snapshot.search_states_expanded().is_zero());
  }

  SECTION("one completes once and rejects the second expansion") {
    auto context = ::context(policy(1U, 1U));
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
        budget.value(), mwperf::ServiceFamily::resource_packing));
    REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
        budget.value()));
    CHECK(budget.value().completed_expansions().to_decimal_string() == "1");

    auto second = mwperf::detail::SearchBudgetAccess::charge_expansion(
        budget.value());
    REQUIRE_FALSE(second);
    CHECK(second.error().code == "search_state_limit_exhausted");
    CHECK(second.error().notes.at(1) == "completed recursive expansions: 1");
    CHECK(budget.value().completed_expansions().to_decimal_string() == "1");
    const auto snapshot = context.ledger_snapshot();
    REQUIRE(snapshot.assigned_max_search_states().has_value());
    CHECK(snapshot.assigned_max_search_states()->to_decimal_string() == "1");
    CHECK(snapshot.search_states_expanded().to_decimal_string() == "1");
  }
}

TEST_CASE("C05 observers aggregate recursive expansions without reset",
          "[c05][unit][budget][observer]") {
  auto execution = ::context(policy(2U, 2U));
  const auto observer = execution.ledger_observer();

  {
    auto first = mwperf::begin_search_budget(execution);
    REQUIRE(first);
    REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
        first.value(), mwperf::ServiceFamily::pairwise_conflicts));
    REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
        first.value()));
  }
  CHECK(observer.snapshot().search_states_expanded().to_decimal_string() ==
        "1");

  auto second = mwperf::begin_search_budget(execution);
  REQUIRE(second);
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      second.value(), mwperf::ServiceFamily::resource_packing));
  REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
      second.value()));
  REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
      second.value()));
  auto rejected = mwperf::detail::SearchBudgetAccess::charge_expansion(
      second.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "search_state_limit_exhausted");

  const auto snapshot = observer.snapshot();
  REQUIRE(snapshot.assigned_max_search_states().has_value());
  CHECK(snapshot.assigned_max_search_states()->to_decimal_string() == "4");
  CHECK(snapshot.search_states_expanded().to_decimal_string() == "3");
}

TEST_CASE("C05 base cases and memo hits require no accounting operation",
          "[c05][unit][budget]") {
  auto context = ::context(policy(3U, 1U));
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::pairwise_conflicts));

  // A backend represents both cases by returning without invoking the sole
  // charge primitive. Only a new nonbase, nonmemoized key invokes it.
  CHECK(budget.value().completed_expansions().is_zero());
  REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
      budget.value()));
  CHECK(budget.value().completed_expansions().to_decimal_string() == "1");
}

TEST_CASE("C05 search budgets authorize one dispatch and classify one query",
          "[c05][unit][negative][budget]") {
  auto context = ::context(policy(4U, 1U));
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);

  auto charge_before_dispatch =
      mwperf::detail::SearchBudgetAccess::charge_expansion(budget.value());
  REQUIRE_FALSE(charge_before_dispatch);
  CHECK(charge_before_dispatch.error().code ==
        "search_budget_dispatch_not_claimed");

  REQUIRE(budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto repeat_kind =
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::generic_exact);
  REQUIRE_FALSE(repeat_kind);
  CHECK(repeat_kind.error().code == "search_budget_query_already_set");

  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::crossbar_matching));
  auto repeat_dispatch = mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::crossbar_matching);
  REQUIRE_FALSE(repeat_dispatch);
  CHECK(repeat_dispatch.error().code ==
        "search_budget_dispatch_already_claimed");
}

TEST_CASE("C05 process-local contexts retain disjoint immutable ledgers",
          "[c05][unit][budget]") {
  auto left = ::context(policy(2U, 3U), 3U);
  auto right = ::context(policy(5U, 5U), 1U);
  REQUIRE(mwperf::begin_search_budget(left));
  REQUIRE(mwperf::begin_search_budget(left));
  REQUIRE(mwperf::begin_search_budget(right));

  const auto left_snapshot = left.ledger_snapshot();
  const auto right_snapshot = right.ledger_snapshot();
  CHECK(left_snapshot.calls_reserved().to_decimal_string() == "2");
  CHECK(right_snapshot.calls_reserved().to_decimal_string() == "1");
  CHECK(left_snapshot.assigned_max_calls()->to_decimal_string() == "3");
  CHECK(right_snapshot.assigned_max_calls()->to_decimal_string() == "1");

  // A snapshot has no constructor/import route into a context. Reserving more
  // work changes only the live ledger that created it.
  REQUIRE(mwperf::begin_search_budget(left));
  CHECK(left_snapshot.calls_reserved().to_decimal_string() == "2");
  CHECK(left.ledger_snapshot().calls_reserved().to_decimal_string() == "3");
}

TEST_CASE("C05 local call subgrants do not rewrite the C04 base policy",
          "[c05][unit][budget]") {
  auto execution = ::context(policy(4U, 5U), 2U);

  REQUIRE(execution.base_policy().max_calls.has_value());
  CHECK(execution.base_policy().max_calls->to_decimal_string() == "5");
  REQUIRE(execution.assigned_max_calls().has_value());
  CHECK(execution.assigned_max_calls()->to_decimal_string() == "2");

  REQUIRE(mwperf::begin_search_budget(execution));
  REQUIRE(mwperf::begin_search_budget(execution));
  auto over_local_subgrant = mwperf::begin_search_budget(execution);
  REQUIRE_FALSE(over_local_subgrant);
  CHECK(over_local_subgrant.error().code ==
        "optimizer_call_limit_exhausted");
  CHECK(execution.base_policy().max_calls->to_decimal_string() == "5");
}

TEST_CASE("C05 moving a context transfers authority without a reset snapshot",
          "[c05][unit][negative][budget]") {
  auto source = ::context(policy(2U, 3U));
  REQUIRE(mwperf::begin_search_budget(source));

  mwperf::OptimizerExecutionContext destination(std::move(source));
  const auto inactive = source.ledger_snapshot();
  CHECK_FALSE(inactive.context_active());
  CHECK_FALSE(inactive.has_remaining_capacity());
  auto rejected = mwperf::begin_search_budget(source);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "optimizer_execution_context_moved_from");

  const auto transferred = destination.ledger_snapshot();
  CHECK(transferred.context_active());
  CHECK(transferred.calls_reserved().to_decimal_string() == "1");
  REQUIRE(mwperf::begin_search_budget(destination));
  CHECK(destination.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "2");
}

TEST_CASE("C05 read-only ledger observers follow moves and survive teardown",
          "[c05][unit][budget][observer]") {
  std::optional<mwperf::OptimizerCallLedgerObserver> observer;
  {
    auto source = ::context(policy(2U, 3U), 3U);
    observer.emplace(source.ledger_observer());

    const auto cold = observer->snapshot();
    CHECK(cold.context_active());
    REQUIRE(cold.assigned_max_calls().has_value());
    CHECK(cold.assigned_max_calls()->to_decimal_string() == "3");
    CHECK(cold.calls_reserved().is_zero());
    REQUIRE(cold.assigned_max_search_states().has_value());
    CHECK(cold.assigned_max_search_states()->to_decimal_string() == "6");
    CHECK(cold.search_states_expanded().is_zero());

    REQUIRE(mwperf::begin_search_budget(source));
    CHECK(observer->snapshot().calls_reserved().to_decimal_string() == "1");

    mwperf::OptimizerExecutionContext destination(std::move(source));
    CHECK_FALSE(source.active());
    CHECK(observer->snapshot().context_active());
    CHECK(observer->snapshot().calls_reserved().to_decimal_string() == "1");

    REQUIRE(mwperf::begin_search_budget(destination));
    const auto transferred = observer->snapshot();
    CHECK(transferred.context_active());
    CHECK(transferred.calls_reserved().to_decimal_string() == "2");
  }

  REQUIRE(observer.has_value());
  const auto retained = observer->snapshot();
  CHECK_FALSE(retained.context_active());
  CHECK_FALSE(retained.has_remaining_capacity());
  REQUIRE(retained.assigned_max_calls().has_value());
  CHECK(retained.assigned_max_calls()->to_decimal_string() == "3");
  CHECK(retained.calls_reserved().to_decimal_string() == "2");
  REQUIRE(retained.assigned_max_search_states().has_value());
  CHECK(retained.assigned_max_search_states()->to_decimal_string() == "6");
  CHECK(retained.search_states_expanded().is_zero());
}

TEST_CASE("C05 moved search budgets cannot be reused",
          "[c05][negative][budget]") {
  auto context = ::context(policy(std::nullopt, 1U));
  auto budget_result = mwperf::begin_search_budget(context);
  REQUIRE(budget_result);
  mwperf::SearchBudget moved(std::move(budget_result).value());

  auto use_after_move = budget_result.value().set_query_kind(
      mwperf::OptimizerQueryKind::ordinary);
  REQUIRE_FALSE(use_after_move);
  CHECK(use_after_move.error().code == "search_budget_moved_from");
  REQUIRE(moved.set_query_kind(mwperf::OptimizerQueryKind::ordinary));
}

TEST_CASE("C05 search budgets cannot outlive context authority",
          "[c05][negative][budget][observer]") {
  std::optional<mwperf::SearchBudget> retained;
  std::optional<mwperf::OptimizerCallLedgerObserver> observer;
  {
    auto execution = ::context(policy(2U, 1U));
    observer.emplace(execution.ledger_observer());
    auto budget = mwperf::begin_search_budget(execution);
    REQUIRE(budget);
    REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
        budget.value(), mwperf::ServiceFamily::pairwise_conflicts));
    retained.emplace(std::move(budget).value());
  }

  REQUIRE(retained.has_value());
  REQUIRE(observer.has_value());
  CHECK_FALSE(observer->snapshot().context_active());
  auto rejected = mwperf::detail::SearchBudgetAccess::charge_expansion(
      *retained);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "optimizer_execution_context_inactive");
  CHECK(observer->snapshot().search_states_expanded().is_zero());
}


TEST_CASE("C05 rejects malformed base policies and oversized subgrants",
          "[c05][negative][budget]") {
  mwperf::OptimizerBudgetPolicy exact_minimum{
      .physical_per_call = mwperf::BigNat(2U),
      .analysis_per_call = mwperf::BigNat(5U),
      .effective_per_call = mwperf::BigNat(2U),
      .max_calls = mwperf::BigNat(4U),
  };
  auto valid_minimum = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(exact_minimum), mwperf::BigNat(3U));
  REQUIRE(valid_minimum);
  CHECK(valid_minimum.value()
            .base_policy()
            .effective_per_call->to_decimal_string() == "2");
  CHECK(valid_minimum.value().assigned_max_calls()->to_decimal_string() ==
        "3");

  auto inconsistent = policy(3U, 4U);
  inconsistent.effective_per_call = mwperf::BigNat(2U);
  auto bad_policy = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(inconsistent), std::nullopt);
  REQUIRE_FALSE(bad_policy);
  CHECK(bad_policy.error().code ==
        "optimizer_budget_effective_limit_inconsistent");

  auto too_large = mwperf::OptimizerExecutionContext::for_fixture(
      policy(std::nullopt, 2U), mwperf::BigNat(3U));
  REQUIRE_FALSE(too_large);
  CHECK(too_large.error().code ==
        "optimizer_assigned_call_subgrant_exceeds_base");
}

TEST_CASE("C05 finite limits above one retain the exact off-by-one rule",
          "[c05][unit][budget]") {
  auto execution = ::context(policy(3U, 1U));
  auto budget = mwperf::begin_search_budget(execution);
  REQUIRE(budget);
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::resource_packing));
  for (std::size_t completed = 1U; completed <= 3U; ++completed) {
    REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
        budget.value()));
    CHECK(budget.value().completed_expansions().to_decimal_string() ==
          std::to_string(completed));
  }
  auto fourth = mwperf::detail::SearchBudgetAccess::charge_expansion(
      budget.value());
  REQUIRE_FALSE(fourth);
  CHECK(fourth.error().code == "search_state_limit_exhausted");
  CHECK(budget.value().completed_expansions().to_decimal_string() == "3");
}

TEST_CASE("C05 a null per-call limit permits exact unbounded accounting",
          "[c05][unit][budget]") {
  auto execution = ::context(policy(std::nullopt, 1U));
  auto budget = mwperf::begin_search_budget(execution);
  REQUIRE(budget);
  REQUIRE_FALSE(budget.value().effective_limit().has_value());
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      budget.value(), mwperf::ServiceFamily::pairwise_conflicts));
  for (std::size_t count = 0U; count < 128U; ++count) {
    REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
        budget.value()));
  }
  CHECK(budget.value().completed_expansions().to_decimal_string() == "128");
  CHECK_FALSE(budget.value().exhausted());
}
