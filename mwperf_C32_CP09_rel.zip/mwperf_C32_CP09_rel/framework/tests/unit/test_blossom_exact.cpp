#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <optional>
#include <ranges>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct SupportFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::NodeExclusiveProblem problem;
};

struct RawEdge final {
  std::size_t first;
  std::size_t second;
  mwperf::BigNat weight;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c07-blossom";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '7'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] std::string queue_list(const std::size_t count) {
  std::ostringstream output;
  output << '[';
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"q" << queue << "\"";
  }
  output << ']';
  return output.str();
}

[[nodiscard]] SupportFixture support_fixture(const std::size_t queue_count) {
  REQUIRE(queue_count != 0U);
  std::ostringstream links;
  links << '[';
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    if (queue != 0U) {
      links << ',';
    }
    links << "{\"queue_id\":\"q" << queue
          << "\",\"u\":\"a\",\"v\":\"b\"}";
  }
  links << ']';
  const std::string model_text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      queue_list(queue_count) +
      R"(},"scheduler":{"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["a","b"],"links":)" +
      links.str() +
      R"(},"priority":null}},"arrival":{"family":"deterministic_trace","events":[]}})";

  auto document = mwperf::load_document(write_model(model_text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  const auto& constraint =
      std::get<mwperf::ResolvedNodeExclusiveConstraint>(
          descriptor.value().value());
  auto problem = mwperf::compile_node_exclusive_problem(constraint);
  REQUIRE(problem);
  return SupportFixture{std::move(catalog).value(),
                        std::move(priority).value(),
                        std::move(descriptor).value(),
                        std::move(problem).value()};
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const SupportFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] mwperf::DenseQueueIndex queue_index(
    const SupportFixture& fixture, const std::size_t queue) {
  REQUIRE(queue < fixture.problem.queue_to_link().size());
  const std::size_t position = fixture.problem.queue_to_link()[queue];
  REQUIRE(position < fixture.problem.links().size());
  return fixture.problem.links()[position].queue;
}

[[nodiscard]] mwperf::RepresentativeGraph make_graph(
    const SupportFixture& fixture, const std::size_t vertex_count,
    const std::vector<RawEdge>& edges) {
  REQUIRE(edges.size() <= fixture.catalog.size());
  std::vector<mwperf::RepresentativeEdge> representatives;
  representatives.reserve(edges.size());
  for (std::size_t edge = 0U; edge < edges.size(); ++edge) {
    representatives.push_back(mwperf::RepresentativeEdge{
        .first = edges[edge].first,
        .second = edges[edge].second,
        .queue = queue_index(fixture, edge),
        .weight = edges[edge].weight,
    });
  }
  std::ranges::sort(representatives, [](const auto& lhs, const auto& rhs) {
    return std::pair{lhs.first, lhs.second} <
           std::pair{rhs.first, rhs.second};
  });
  return mwperf::RepresentativeGraph::for_test(
      vertex_count, dimension(fixture), std::move(representatives));
}

[[nodiscard]] std::set<std::pair<std::size_t, std::size_t>>
selected_pairs(const mwperf::RepresentativeGraph& graph,
               const mwperf::RepresentativeMatching& matching) {
  std::set<std::pair<std::size_t, std::size_t>> result;
  for (const std::size_t edge : matching.selected_edges()) {
    REQUIRE(edge < graph.edges().size());
    result.emplace(graph.edges()[edge].first, graph.edges()[edge].second);
  }
  return result;
}

[[nodiscard]] mwperf::BigNat huge_weight(const unsigned int shift,
                                         const std::uint64_t add) {
  mwperf::BigInt value = 1;
  value <<= shift;
  value += add;
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<std::uint8_t> bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

}  // namespace

TEST_CASE("C07 Blossom solves optional elementary general-graph matchings",
          "[c07][unit][blossom]") {
  SECTION("empty representative graph with isolated vertices") {
    const auto fixture = support_fixture(1U);
    const auto graph = make_graph(fixture, 4U, {});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(matching.value().selected_edges().empty());
    CHECK(matching.value().objective().is_zero());
    REQUIRE(matching.value().vertex_mates().size() == 4U);
    CHECK(std::ranges::all_of(matching.value().vertex_mates(),
                              [](const auto& mate) {
                                return !mate.has_value();
                              }));
  }

  SECTION("one link") {
    const auto fixture = support_fixture(1U);
    const auto graph = make_graph(
        fixture, 2U, {{0U, 1U, mwperf::BigNat(7U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          std::set<std::pair<std::size_t, std::size_t>>{{0U, 1U}});
    CHECK(matching.value().objective().to_decimal_string() == "7");
  }

  SECTION("weight objective does not acquire a cardinality preference") {
    const auto fixture = support_fixture(3U);
    const auto graph = make_graph(
        fixture, 4U,
        {{0U, 1U, mwperf::BigNat(5U)},
         {1U, 2U, mwperf::BigNat(11U)},
         {2U, 3U, mwperf::BigNat(5U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          std::set<std::pair<std::size_t, std::size_t>>{{1U, 2U}});
    CHECK(matching.value().objective().to_decimal_string() == "11");
  }

  SECTION("even cycle") {
    const auto fixture = support_fixture(4U);
    const auto graph = make_graph(
        fixture, 4U,
        {{0U, 3U, mwperf::BigNat(2U)},
         {1U, 2U, mwperf::BigNat(2U)},
         {0U, 1U, mwperf::BigNat(1U)},
         {2U, 3U, mwperf::BigNat(4U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 1U}, {2U, 3U}}));
    CHECK(matching.value().objective().to_decimal_string() == "5");
  }

  SECTION("triangle") {
    const auto fixture = support_fixture(3U);
    const auto graph = make_graph(
        fixture, 3U,
        {{0U, 1U, mwperf::BigNat(8U)},
         {0U, 2U, mwperf::BigNat(9U)},
         {1U, 2U, mwperf::BigNat(10U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          std::set<std::pair<std::size_t, std::size_t>>{{1U, 2U}});
    CHECK(matching.value().objective().to_decimal_string() == "10");

    // The final positive triangle dual restores full edge slack to zero even
    // though the vertex-dual-only raw slack is negative. This directly checks
    // why the Blossom workspace must use a signed arbitrary-precision type.
    auto signed_slack =
        mwperf::detail::blossom_observed_negative_internal_raw_slack_for_test(
            graph);
    REQUIRE(signed_slack);
    CHECK(signed_slack.value());
  }
}

TEST_CASE("C07 Blossom contracts an odd cycle to expose an augmentation",
          "[c07][unit][blossom][odd-cycle]") {
  const auto fixture = support_fixture(4U);
  const auto graph = make_graph(
      fixture, 4U,
      {{0U, 1U, mwperf::BigNat(8U)},
       {0U, 2U, mwperf::BigNat(9U)},
       {1U, 2U, mwperf::BigNat(10U)},
       {2U, 3U, mwperf::BigNat(7U)}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  REQUIRE(matching);
  CHECK(selected_pairs(graph, matching.value()) ==
        (std::set<std::pair<std::size_t, std::size_t>>{
            {0U, 1U}, {2U, 3U}}));
  CHECK(matching.value().objective().to_decimal_string() == "15");
}

TEST_CASE("C07 Blossom solves a weighted five-cycle through its stem",
          "[c07][unit][blossom][odd-cycle]") {
  const auto fixture = support_fixture(6U);
  const auto graph = make_graph(
      fixture, 6U,
      {{0U, 1U, mwperf::BigNat(8U)},
       {1U, 2U, mwperf::BigNat(9U)},
       {2U, 3U, mwperf::BigNat(10U)},
       {3U, 4U, mwperf::BigNat(11U)},
       {0U, 4U, mwperf::BigNat(12U)},
       {2U, 5U, mwperf::BigNat(7U)}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  REQUIRE(matching);
  CHECK(selected_pairs(graph, matching.value()) ==
        (std::set<std::pair<std::size_t, std::size_t>>{
            {0U, 1U}, {2U, 5U}, {3U, 4U}}));
  CHECK(matching.value().objective().to_decimal_string() == "26");
}

TEST_CASE("C07 Blossom relabels an S blossom as T before augmentation",
          "[c07][unit][blossom][relabel]") {
  // Pinned NetworkX 3.6.1 regression: TestMaxWeightMatching::
  // test_s_t_blossom. Vertex labels are shifted from 1-based to 0-based.
  const auto fixture = support_fixture(6U);
  const auto graph = make_graph(
      fixture, 6U,
      {{0U, 1U, mwperf::BigNat(9U)},
       {0U, 2U, mwperf::BigNat(8U)},
       {1U, 2U, mwperf::BigNat(10U)},
       {0U, 3U, mwperf::BigNat(5U)},
       {3U, 4U, mwperf::BigNat(4U)},
       {0U, 5U, mwperf::BigNat(3U)}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  REQUIRE(matching);
  CHECK(selected_pairs(graph, matching.value()) ==
        (std::set<std::pair<std::size_t, std::size_t>>{
            {0U, 5U}, {1U, 2U}, {3U, 4U}}));
  CHECK(matching.value().objective().to_decimal_string() == "17");
}

TEST_CASE("C07 Blossom expands a relabeled T blossom in-stage",
          "[c07][unit][blossom][relabel][delta4]") {
  // Pinned NetworkX 3.6.1 regression: TestMaxWeightMatching::
  // test_s_blossom_relabel_expand. This specifically covers the delta-4
  // expansion path. Vertex labels are shifted from 1-based to 0-based.
  const auto fixture = support_fixture(8U);
  const auto graph = make_graph(
      fixture, 8U,
      {{0U, 1U, mwperf::BigNat(23U)},
       {0U, 4U, mwperf::BigNat(22U)},
       {0U, 5U, mwperf::BigNat(15U)},
       {1U, 2U, mwperf::BigNat(25U)},
       {2U, 3U, mwperf::BigNat(22U)},
       {3U, 4U, mwperf::BigNat(25U)},
       {3U, 7U, mwperf::BigNat(14U)},
       {4U, 6U, mwperf::BigNat(13U)}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  INFO((matching ? std::string{} : matching.error().code));
  REQUIRE(matching);
  CHECK(selected_pairs(graph, matching.value()) ==
        (std::set<std::pair<std::size_t, std::size_t>>{
            {0U, 5U}, {1U, 2U}, {3U, 7U}, {4U, 6U}}));
  CHECK(matching.value().objective().to_decimal_string() == "67");
}

TEST_CASE("C07 Blossom handles nested contraction and exact expansion",
          "[c07][unit][blossom][nested]") {
  SECTION("nested S blossom") {
    const auto fixture = support_fixture(7U);
    const auto graph = make_graph(
        fixture, 6U,
        {{0U, 1U, mwperf::BigNat(9U)},
         {0U, 2U, mwperf::BigNat(9U)},
         {1U, 2U, mwperf::BigNat(10U)},
         {1U, 3U, mwperf::BigNat(8U)},
         {2U, 4U, mwperf::BigNat(8U)},
         {3U, 4U, mwperf::BigNat(10U)},
         {4U, 5U, mwperf::BigNat(6U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 2U}, {1U, 3U}, {4U, 5U}}));
    CHECK(matching.value().objective().to_decimal_string() == "23");
  }

  SECTION("nested blossom expands recursively after augmentation") {
    const auto fixture = support_fixture(10U);
    const auto graph = make_graph(
        fixture, 8U,
        {{0U, 1U, mwperf::BigNat(8U)},
         {0U, 2U, mwperf::BigNat(8U)},
         {1U, 2U, mwperf::BigNat(10U)},
         {1U, 3U, mwperf::BigNat(12U)},
         {2U, 4U, mwperf::BigNat(12U)},
         {3U, 4U, mwperf::BigNat(14U)},
         {3U, 5U, mwperf::BigNat(12U)},
         {4U, 6U, mwperf::BigNat(12U)},
         {5U, 6U, mwperf::BigNat(14U)},
         {6U, 7U, mwperf::BigNat(12U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 1U}, {2U, 4U}, {3U, 5U}, {6U, 7U}}));
    CHECK(matching.value().objective().to_decimal_string() == "44");
  }

  SECTION("recursive expansion regression") {
    const auto fixture = support_fixture(11U);
    const auto graph = make_graph(
        fixture, 10U,
        {{0U, 1U, mwperf::BigNat(40U)},
         {0U, 2U, mwperf::BigNat(40U)},
         {1U, 2U, mwperf::BigNat(60U)},
         {1U, 3U, mwperf::BigNat(55U)},
         {2U, 4U, mwperf::BigNat(55U)},
         {3U, 4U, mwperf::BigNat(50U)},
         {0U, 7U, mwperf::BigNat(15U)},
         {4U, 6U, mwperf::BigNat(30U)},
         {5U, 6U, mwperf::BigNat(10U)},
         {7U, 9U, mwperf::BigNat(10U)},
         {3U, 8U, mwperf::BigNat(30U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 1U}, {2U, 4U}, {3U, 8U}, {5U, 6U}, {7U, 9U}}));
    CHECK(matching.value().objective().to_decimal_string() == "145");
  }
}

TEST_CASE("C07 Blossom passes upstream nested and least-slack regressions",
          "[c07][unit][blossom][nested][relabel][delta2][delta3]") {
  // These four integer-only fixtures are pinned from NetworkX 3.6.1
  // TestMaxWeightMatching. They exercise distinct control-flow paths in the
  // Galil/Edmonds implementation; vertex labels are shifted from 1-based to
  // 0-based and every expected optimum is unique.
  SECTION("nested S blossom is relabeled and included in a larger blossom") {
    // test_nested_s_blossom_relabel
    const auto fixture = support_fixture(9U);
    const auto graph = make_graph(
        fixture, 8U,
        {{0U, 1U, mwperf::BigNat(10U)},
         {0U, 6U, mwperf::BigNat(10U)},
         {1U, 2U, mwperf::BigNat(12U)},
         {2U, 3U, mwperf::BigNat(20U)},
         {2U, 4U, mwperf::BigNat(20U)},
         {3U, 4U, mwperf::BigNat(25U)},
         {4U, 5U, mwperf::BigNat(10U)},
         {5U, 6U, mwperf::BigNat(10U)},
         {6U, 7U, mwperf::BigNat(8U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    INFO((matching ? std::string{} : matching.error().code));
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 1U}, {2U, 3U}, {4U, 5U}, {6U, 7U}}));
    CHECK(matching.value().objective().to_decimal_string() == "48");
  }

  SECTION("nested S blossom is relabeled as T and expanded") {
    // test_nested_s_blossom_relabel_expand
    const auto fixture = support_fixture(9U);
    const auto graph = make_graph(
        fixture, 8U,
        {{0U, 1U, mwperf::BigNat(19U)},
         {0U, 2U, mwperf::BigNat(20U)},
         {0U, 7U, mwperf::BigNat(8U)},
         {1U, 2U, mwperf::BigNat(25U)},
         {1U, 3U, mwperf::BigNat(18U)},
         {2U, 4U, mwperf::BigNat(18U)},
         {3U, 4U, mwperf::BigNat(13U)},
         {3U, 6U, mwperf::BigNat(7U)},
         {4U, 5U, mwperf::BigNat(7U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    INFO((matching ? std::string{} : matching.error().code));
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 7U}, {1U, 2U}, {3U, 6U}, {4U, 5U}}));
    CHECK(matching.value().objective().to_decimal_string() == "47");
  }

  SECTION("T expansion regenerates the least-slack S-to-free edge") {
    // test_nasty_blossom_least_slack: the expansion must update the delta-2
    // candidate instead of retaining the contracted blossom's stale edge.
    const auto fixture = support_fixture(10U);
    const auto graph = make_graph(
        fixture, 10U,
        {{0U, 1U, mwperf::BigNat(45U)},
         {0U, 4U, mwperf::BigNat(45U)},
         {1U, 2U, mwperf::BigNat(50U)},
         {2U, 3U, mwperf::BigNat(45U)},
         {3U, 4U, mwperf::BigNat(50U)},
         {0U, 5U, mwperf::BigNat(30U)},
         {2U, 8U, mwperf::BigNat(35U)},
         {3U, 7U, mwperf::BigNat(28U)},
         {4U, 6U, mwperf::BigNat(26U)},
         {8U, 9U, mwperf::BigNat(5U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    INFO((matching ? std::string{} : matching.error().code));
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 5U}, {1U, 2U}, {3U, 7U}, {4U, 6U}, {8U, 9U}}));
    CHECK(matching.value().objective().to_decimal_string() == "139");
  }

  SECTION("inner blossom lands on the augmenting path after outer expansion") {
    // test_nasty_blossom_augmenting: nested contractions, competing
    // S-to-S least-slack edges (delta 3), and expansion all precede the final
    // augmentation through the former inner blossom.
    const auto fixture = support_fixture(13U);
    const auto graph = make_graph(
        fixture, 12U,
        {{0U, 1U, mwperf::BigNat(45U)},
         {0U, 6U, mwperf::BigNat(45U)},
         {1U, 2U, mwperf::BigNat(50U)},
         {2U, 3U, mwperf::BigNat(45U)},
         {3U, 4U, mwperf::BigNat(95U)},
         {3U, 5U, mwperf::BigNat(94U)},
         {4U, 5U, mwperf::BigNat(94U)},
         {5U, 6U, mwperf::BigNat(50U)},
         {0U, 7U, mwperf::BigNat(30U)},
         {2U, 10U, mwperf::BigNat(35U)},
         {4U, 8U, mwperf::BigNat(36U)},
         {6U, 9U, mwperf::BigNat(26U)},
         {10U, 11U, mwperf::BigNat(5U)}});
    auto matching = mwperf::detail::solve_blossom_exact(graph);
    INFO((matching ? std::string{} : matching.error().code));
    REQUIRE(matching);
    CHECK(selected_pairs(graph, matching.value()) ==
          (std::set<std::pair<std::size_t, std::size_t>>{
              {0U, 7U}, {1U, 2U}, {3U, 5U},
              {4U, 8U}, {6U, 9U}, {10U, 11U}}));
    CHECK(matching.value().objective().to_decimal_string() == "241");
  }
}

TEST_CASE("C07 Blossom arithmetic remains exact beyond fixed width",
          "[c07][unit][blossom][multiprecision]") {
  const auto fixture = support_fixture(4U);
  const mwperf::BigNat h5 = huge_weight(200U, 5U);
  const mwperf::BigNat h4 = huge_weight(200U, 4U);
  const mwperf::BigNat h3 = huge_weight(200U, 3U);
  const mwperf::BigNat h2 = huge_weight(200U, 2U);
  const auto graph = make_graph(
      fixture, 4U,
      {{0U, 1U, h5}, {1U, 2U, h4}, {0U, 2U, h3}, {2U, 3U, h2}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  REQUIRE(matching);
  CHECK(selected_pairs(graph, matching.value()) ==
        (std::set<std::pair<std::size_t, std::size_t>>{
            {0U, 1U}, {2U, 3U}}));
  mwperf::BigNat expected = h5 + h2;
  CHECK(matching.value().objective() == expected);
  CHECK(matching.value().objective().bit_length() == 202U);
}

TEST_CASE("C07 expansion maps representatives losslessly and rejects nonmatchings",
          "[c07][unit][blossom][expansion]") {
  const auto fixture = support_fixture(8U);
  const auto graph = make_graph(
      fixture, 4U,
      {{0U, 1U, mwperf::BigNat(5U)},
       {2U, 3U, mwperf::BigNat(9U)}});
  auto matching = mwperf::detail::solve_blossom_exact(graph);
  REQUIRE(matching);
  auto expanded = mwperf::detail::expand_representative_matching(
      matching.value(), graph);
  REQUIRE(expanded);
  CHECK((bits(expanded.value().schedule) ==
         std::vector<std::uint8_t>{1U, 1U, 0U, 0U, 0U, 0U, 0U, 0U}));
  CHECK(expanded.value().composite_objective.to_decimal_string() == "14");

  const auto conflicting_graph = make_graph(
      fixture, 3U,
      {{0U, 1U, mwperf::BigNat(5U)},
       {1U, 2U, mwperf::BigNat(9U)}});
  auto corrupt = mwperf::RepresentativeMatching::for_test(
      {0U, 1U}, {1U, 0U, std::nullopt}, mwperf::BigNat(14U));
  auto rejected = mwperf::detail::expand_representative_matching(
      corrupt, conflicting_graph);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().category == mwperf::DiagnosticCategory::internal);
}

TEST_CASE("C07 Blossom hard-fails an injected exact-certificate mismatch",
          "[c07][negative][blossom][certificate]") {
  const auto fixture = support_fixture(4U);
  const auto graph = make_graph(
      fixture, 4U,
      {{0U, 1U, mwperf::BigNat(8U)},
       {0U, 2U, mwperf::BigNat(9U)},
       {1U, 2U, mwperf::BigNat(10U)},
       {2U, 3U, mwperf::BigNat(7U)}});
  auto result = mwperf::detail::solve_blossom_exact_with_fault(
      graph, mwperf::detail::BlossomTestFault::force_certificate_mismatch);
  REQUIRE_FALSE(result);
  CHECK(result.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(result.error().code == "blossom_primal_dual_objective_mismatch");
}

TEST_CASE("C07 all-ineligible labelled links reduce to an empty exact matching",
          "[c07][unit][blossom][eligibility]") {
  const auto fixture = support_fixture(3U);
  const auto token = dimension(fixture);
  auto primary = mwperf::PrimaryWeights::from_values(
      token, {mwperf::BigNat(9U), mwperf::BigNat(8U),
              mwperf::BigNat(7U)});
  auto eligibility =
      mwperf::EligibilityMask::from_bytes(token, {0U, 0U, 0U});
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  auto graph = mwperf::select_parallel_link_representatives(
      fixture.problem, eligibility.value(), weights.value());
  REQUIRE(graph);
  CHECK(graph.value().edges().empty());
  auto matching = mwperf::detail::solve_blossom_exact(graph.value());
  REQUIRE(matching);
  auto expanded = mwperf::detail::expand_representative_matching(
      matching.value(), graph.value());
  REQUIRE(expanded);
  CHECK(std::ranges::all_of(expanded.value().schedule.bytes(),
                            [](const std::uint8_t value) {
                              return value == 0U;
                            }));
  CHECK(expanded.value().composite_objective.is_zero());
}
