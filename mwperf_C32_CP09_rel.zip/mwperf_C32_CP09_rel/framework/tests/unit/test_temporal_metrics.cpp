#include <algorithm>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <limits>
#include <numbers>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "c22/support/temporal_metrics_fixture.hpp"
#include "mwperf/metrics/temporal.hpp"

namespace {

namespace c22 = mwperf::testing::c22;

template <typename T>
void require_error(const mwperf::Result<T>& result,
                   const std::string& expected_code) {
  INFO((result ? std::string{"unexpected success"}
               : result.error().code + ": " + result.error().message));
  REQUIRE_FALSE(result);
  CHECK(result.error().code == expected_code);
}

template <typename T>
[[nodiscard]] const T& require_optional(const std::optional<T>& value) {
  REQUIRE(value.has_value());
  return *value;
}

[[nodiscard]] mwperf::testing::C22MetricEnvelopeInspectionV1 decode(
    const mwperf::Result<mwperf::MetricValue>& value) {
  const auto metric = c22::require_value(value);
  return c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));
}

[[nodiscard]] mwperf::AbsorptionMarks two_exit_marks() {
  return {{{c22::backlog_exit("hit", 1U),
            c22::backlog_exit("kill", 2U)}}};
}

template <typename Source>
concept C22CylinderSource = requires(
    const Source& source, const mwperf::CylinderEvent& event) {
  { mwperf::evaluate_finite_cylinder(source, event, mwperf::BigNat{1U}) } ->
      std::same_as<mwperf::Result<mwperf::MetricValue>>;
};

static_assert(C22CylinderSource<mwperf::AuditedCylinderLaw>);
static_assert(!C22CylinderSource<mwperf::AuditedTemporalKernel>);
static_assert(!C22CylinderSource<mwperf::AuditedTemporalLaw>);
static_assert(!C22CylinderSource<mwperf::AuditedSamplerDescriptor>);
static_assert(!C22CylinderSource<mwperf::KernelAccess>);

}  // namespace

TEST_CASE("C22 typed cylinder offsets generate exactly the required slots",
          "[c22][unit][cylinder]") {
  const auto source = c22::alternator();
  const auto& law = require_optional(source.cylinder);

  const mwperf::CylinderEvent empty;
  const auto empty_result = decode(mwperf::evaluate_finite_cylinder(
      law, empty, mwperf::BigNat{0U}));
  REQUIRE(empty_result.exact_values.size() == 1U);
  CHECK(empty_result.exact_values.front() ==
        mwperf::ExactRational::one());
  CHECK(empty_result.completed_steps == 0U);

  mwperf::CylinderEvent two_edges;
  two_edges.observations.push_back(mwperf::EdgeMarkAtV1{
      mwperf::BigNat{0U}, mwperf::TargetDeparturePredicateV1{0U, false}});
  two_edges.observations.push_back(mwperf::EdgeMarkAtV1{
      mwperf::BigNat{1U}, mwperf::TargetDeparturePredicateV1{0U, true}});
  const auto edge_result = decode(mwperf::evaluate_finite_cylinder(
      law, two_edges, mwperf::BigNat{2U}));
  CHECK(edge_result.kind == "finite_cylinder_probability");
  REQUIRE(edge_result.exact_values.size() == 1U);
  CHECK(edge_result.exact_values.front() == c22::rational(1, 2));
  CHECK(edge_result.completed_steps == 2U);
  CHECK(edge_result.temporal_budget.actual_state_count == 2U);
  CHECK(edge_result.temporal_budget.actual_row_atom_count == 2U);
  CHECK(edge_result.temporal_budget.requested_horizon == 2U);
  REQUIRE(edge_result.temporal_budget.permitted_horizon.has_value());
  CHECK(*edge_result.temporal_budget.permitted_horizon == 2U);
  CHECK(edge_result.temporal_budget.authorized_maximum_state_offset == 32U);
  REQUIRE(edge_result.temporal_budget.authorized_maximum_edge_offset
              .has_value());
  CHECK(*edge_result.temporal_budget.authorized_maximum_edge_offset == 32U);
  CHECK_FALSE(edge_result.temporal_budget.maximum_states.has_value());
  CHECK_FALSE(edge_result.temporal_budget.maximum_row_atoms.has_value());
  CHECK(edge_result.temporal_budget.solver_iterations == 0U);
  CHECK_FALSE(edge_result.temporal_budget
                  .authored_maximum_solver_iterations.has_value());
  CHECK_FALSE(edge_result.temporal_budget.maximum_solver_iterations
                  .has_value());
  CHECK_FALSE(edge_result.temporal_budget.absolute_residual_tolerance
                  .has_value());
  CHECK_FALSE(edge_result.temporal_budget.relative_residual_tolerance
                  .has_value());
  CHECK_FALSE(edge_result.temporal_budget.budget_stop);
  REQUIRE(edge_result.indices.size() == 2U);
  CHECK(edge_result.indices[0U] == mwperf::BigNat{0U});
  CHECK(edge_result.indices[1U] == mwperf::BigNat{1U});

  mwperf::CylinderEvent one_state;
  one_state.observations.push_back(mwperf::StateAtV1{
      mwperf::BigNat{1U}, mwperf::ExactStatePredicateV1{c22::state(1U)}});
  const auto state_result = decode(mwperf::evaluate_finite_cylinder(
      law, one_state, mwperf::BigNat{1U}));
  CHECK(state_result.exact_values.front() == c22::rational(1, 2));
  CHECK(state_result.completed_steps == 1U);

  // The result retains authored order although traversal uses the largest
  // distinct typed offset.  EdgeMarkAt(3) requires four completed slots.
  mwperf::CylinderEvent nonconsecutive;
  nonconsecutive.observations.push_back(mwperf::EdgeMarkAtV1{
      mwperf::BigNat{3U}, mwperf::TargetDeparturePredicateV1{0U, true}});
  nonconsecutive.observations.push_back(mwperf::StateAtV1{
      mwperf::BigNat{0U}, mwperf::ExactStatePredicateV1{c22::state(0U)}});
  const auto nonconsecutive_result = decode(
      mwperf::evaluate_finite_cylinder(
          law, nonconsecutive, mwperf::BigNat{4U}));
  CHECK(nonconsecutive_result.exact_values.front() ==
        c22::rational(1, 2));
  CHECK(nonconsecutive_result.completed_steps == 4U);
  REQUIRE(nonconsecutive_result.indices.size() == 2U);
  CHECK(nonconsecutive_result.indices[0U] == mwperf::BigNat{3U});
  CHECK(nonconsecutive_result.indices[1U] == mwperf::BigNat{0U});

  require_error(mwperf::evaluate_finite_cylinder(
                    law, two_edges, mwperf::BigNat{1U}),
                "c22.cylinder_horizon_too_short");
}

TEST_CASE("C22 alternator has exact persistence covariance and event gap",
          "[c22][unit][temporal]") {
  const auto source = c22::alternator("c22.alternator.statistics");
  const auto& law = require_optional(source.law);
  const auto mark = c22::departure_mark();

  const auto persistence = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          law, mark,
          {mwperf::TemporalStatisticKindV1::service_persistence,
           {}, std::nullopt, std::nullopt, {}}));
  CHECK(persistence.kind == "service_persistence");
  REQUIRE(persistence.exact_values.size() == 3U);
  CHECK(persistence.exact_values[0U] == c22::rational(1, 2));
  CHECK(persistence.exact_values[1U].is_zero());
  CHECK(persistence.exact_values[2U].is_zero());
  CHECK(persistence.completed_steps == 2U);
  CHECK(persistence.temporal_budget.actual_state_count == 2U);
  CHECK(persistence.temporal_budget.actual_row_atom_count == 2U);
  CHECK(persistence.temporal_budget.requested_horizon == 2U);
  CHECK_FALSE(persistence.temporal_budget.permitted_horizon.has_value());
  CHECK(persistence.temporal_budget.solver_iterations == 0U);
  CHECK_FALSE(persistence.temporal_budget.budget_stop);

  const auto covariance = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          law, mark,
          {mwperf::TemporalStatisticKindV1::autocovariance,
           {mwperf::BigNat{2U}}, std::nullopt, std::nullopt, {}}));
  CHECK(covariance.kind == "service_autocovariance");
  REQUIRE(covariance.exact_values.size() == 1U);
  CHECK(covariance.exact_values.front() == c22::rational(1, 4));
  CHECK(covariance.completed_steps == 3U);

  const auto gap = decode(mwperf::evaluate_runs_gaps_autocorrelation(
      law, mark,
      {mwperf::TemporalStatisticKindV1::mean_event_gap,
       {}, std::nullopt, std::nullopt, {}}));
  CHECK(gap.kind == "mean_event_palm_gap");
  REQUIRE(gap.exact_values.size() == 1U);
  CHECK(gap.exact_values.front() == c22::rational(2, 1));
}

TEST_CASE("C22 rejects a direct cylinder family without its projective "
          "consistency witness",
          "[c22][unit][cylinder][projectivity][negative]") {
  const auto only = c22::state(0U);
  const auto source = c22::require_value(
      mwperf::testing::C22FixtureAccess::mint_exact_source(
          mwperf::AuditedTemporalSourceKindV1::stationary_projection,
          mwperf::InitialLawKindV1::stationary,
          c22::identity("c22.inconsistent-cylinder-family", true),
          {{only,
            {c22::transition(0U, only, only, 0U, 0U,
                             mwperf::ExactRational::one())},
            0U}},
          {{0U, mwperf::ExactRational::one()}}, 1U, 0U, {}, false));
  const mwperf::CylinderEvent event{{mwperf::StateAtV1{
      mwperf::BigNat{0U}, mwperf::AnyStatePredicateV1{}}}};
  require_error(mwperf::evaluate_finite_cylinder(
                    require_optional(source.cylinder), event,
                    mwperf::BigNat{0U}),
                "c22.cylinder_source_binding_mismatch");
}

TEST_CASE("C22 IID Bernoulli service has binomial windows and a finite "
          "rectangular spectrum",
          "[c22][unit][temporal][spectrum]") {
  const auto source = c22::iid_bernoulli_third();
  const auto& law = require_optional(source.law);
  const auto mark = c22::departure_mark();

  const auto window = decode(mwperf::evaluate_runs_gaps_autocorrelation(
      law, mark,
      {mwperf::TemporalStatisticKindV1::service_window_count,
       {}, mwperf::BigNat{3U}, std::nullopt, {}}));
  CHECK(window.kind == "service_window_count");
  const std::vector<mwperf::ExactRational> expected_window{
      c22::rational(8, 27), c22::rational(12, 27),
      c22::rational(6, 27), c22::rational(1, 27)};
  CHECK(window.exact_values == expected_window);
  CHECK(window.completed_steps == 3U);

  const auto covariance = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          law, mark,
          {mwperf::TemporalStatisticKindV1::autocovariance,
           {mwperf::BigNat{1U}, mwperf::BigNat{2U}, mwperf::BigNat{5U}},
           std::nullopt, std::nullopt, {}}));
  REQUIRE(covariance.exact_values.size() == 3U);
  CHECK(std::ranges::all_of(covariance.exact_values,
                            [](const auto& value) {
                              return value.is_zero();
                            }));

  const std::vector<mwperf::ExactRational> authored_frequencies{
      c22::rational(1, 1), mwperf::ExactRational::zero(),
      c22::rational(1, 2)};
  const auto spectrum = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          law, mark,
          {mwperf::TemporalStatisticKindV1::service_spectrum,
           {}, std::nullopt, mwperf::BigNat{2U},
           authored_frequencies}));
  CHECK(spectrum.kind ==
        "rectangularly_truncated_covariance_fourier_sum");
  CHECK(spectrum.rectangular_truncation);
  CHECK(spectrum.angular_radians);
  CHECK(spectrum.transcendental_error_certified);
  CHECK(spectrum.transcendental_error_bound > 0.0L);
  CHECK_FALSE(spectrum.authored_absolute_tolerance.has_value());
  CHECK(spectrum.exact_probability_kernel_error.is_zero());
  CHECK(spectrum.conservative_transcendental_enclosure_radius ==
        spectrum.transcendental_error_bound);
  CHECK(spectrum.transcendental_enclosure_is_whole_range);
  CHECK(spectrum.authored_angular_frequencies_radians ==
        authored_frequencies);
  REQUIRE(spectrum.exact_values.size() == 3U);
  CHECK(spectrum.exact_values[0U] == c22::rational(2, 9));
  CHECK(spectrum.exact_values[1U].is_zero());
  CHECK(spectrum.exact_values[2U].is_zero());
  REQUIRE(spectrum.numerical_values.size() == authored_frequencies.size());
  const long double expected =
      1.0L / (9.0L * std::numbers::pi_v<long double>);
  for (const long double actual : spectrum.numerical_values) {
    CHECK(std::fabs(actual - expected) <=
          spectrum.transcendental_error_bound);
  }
  CHECK(spectrum.completed_steps == 3U);
}

TEST_CASE("C22 correlated finite-word spectrum matches its truncated sum",
          "[c22][unit][temporal][spectrum]") {
  const auto source = c22::alternator("c22.correlated-spectrum");
  const auto spectrum = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          require_optional(source.law), c22::departure_mark(),
          {mwperf::TemporalStatisticKindV1::service_spectrum,
           {}, std::nullopt, mwperf::BigNat{2U},
           {mwperf::ExactRational::zero()}}));

  REQUIRE(spectrum.exact_values.size() == 3U);
  CHECK(spectrum.exact_values[0U] == c22::rational(1, 4));
  CHECK(spectrum.exact_values[1U] == c22::rational(-1, 4));
  CHECK(spectrum.exact_values[2U] == c22::rational(1, 4));
  REQUIRE(spectrum.numerical_values.size() == 1U);
  const long double expected =
      1.0L / (8.0L * std::numbers::pi_v<long double>);
  CHECK(std::fabs(spectrum.numerical_values.front() - expected) <=
        spectrum.transcendental_error_bound);
  CHECK(spectrum.rectangular_truncation);
  CHECK(spectrum.angular_radians);
  CHECK(spectrum.transcendental_error_certified);
  CHECK(spectrum.transcendental_error_bound > 0.0L);
  CHECK_FALSE(spectrum.authored_absolute_tolerance.has_value());
  CHECK(spectrum.exact_probability_kernel_error.is_zero());
  CHECK(spectrum.conservative_transcendental_enclosure_radius ==
        spectrum.transcendental_error_bound);
  CHECK(spectrum.transcendental_enclosure_is_whole_range);
  CHECK(spectrum.completed_steps == 3U);
}

TEST_CASE("C22 event-Palm alternator gap is a point mass at two",
          "[c22][unit][stopped][event-palm]") {
  const std::string name = "c22.alternator-event-gap";
  const auto source = c22::alternator_event_palm(name);
  const mwperf::AbsorptionMarks next_departure{{{
      "departure", mwperf::AnyStatePredicateV1{},
      mwperf::TargetDeparturePredicateV1{0U, true},
  }}};
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel),
      mwperf::SafeSet{mwperf::AnyStatePredicateV1{}}, next_departure));
  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{2U}, false, true},
          c22::solver_policy(name)));

  REQUIRE(stopped.survival_tails.size() == 3U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[1U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[2U].exact_probability.is_zero());
  REQUIRE(stopped.absorption_masses.size() == 2U);
  CHECK(stopped.absorption_masses[0U].exact_probability.is_zero());
  CHECK(stopped.absorption_masses[1U].hitting_time == mwperf::BigNat{2U});
  CHECK(stopped.absorption_masses[1U].exact_probability ==
        mwperf::ExactRational::one());
  REQUIRE(stopped.eventual_typed_exit_probabilities.size() == 1U);
  CHECK(stopped.eventual_typed_exit_probabilities.front().exact_probability ==
        mwperf::ExactRational::one());
}

TEST_CASE("C22 framework-v0 visitors remain closed and exhaustive",
          "[c22][unit][closed-carriers]") {
  const std::string name = "c22.framework-v0-visitors";
  const auto source = c22::framework_alternator(name);
  REQUIRE(source.cylinder.has_value());
  REQUIRE(source.kernel.has_value());
  REQUIRE(source.law.has_value());
  CHECK_FALSE(source.entrance.has_value());

  const mwperf::CylinderEvent event{{mwperf::EdgeMarkAtV1{
      mwperf::BigNat{0U},
      mwperf::TargetDeparturePredicateV1{0U, true}}}};
  const auto cylinder = decode(mwperf::evaluate_finite_cylinder(
      *source.cylinder, event, mwperf::BigNat{1U}));
  CHECK(cylinder.exact_values.front() == c22::rational(1, 2));

  const auto covariance = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          *source.law, c22::departure_mark(),
          {mwperf::TemporalStatisticKindV1::autocovariance,
           {mwperf::BigNat{2U}}, std::nullopt, std::nullopt, {}}));
  CHECK(covariance.exact_values.front() == c22::rational(1, 4));

  const auto killed = c22::require_value(mwperf::construct_killed_kernel(
      *source.kernel, mwperf::SafeSet{mwperf::AnyStatePredicateV1{}}, {}));
  CHECK(killed.source_kind() ==
        mwperf::AuditedTemporalSourceKindV1::framework_v0);
  CHECK(killed.state_count() == 2U);
}

TEST_CASE("C22 exact killed chain preserves survivor and typed-exit mass",
          "[c22][unit][stopped]") {
  const auto source = c22::exact_killed_chain();
  const auto& temporal_kernel = require_optional(source.kernel);
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      temporal_kernel, c22::zero_backlog_safe_set(), two_exit_marks()));

  const auto potential = c22::require_value(
      mwperf::compute_minimal_killed_potential(
          kernel, c22::solver_policy()));
  REQUIRE(potential.coordinates().size() == 2U);
  CHECK(potential.coordinates()[0U].value.status ==
        mwperf::ExtendedNonnegativeStatusV1::finite);
  CHECK(potential.coordinates()[1U].value.status ==
        mwperf::ExtendedNonnegativeStatusV1::finite);
  REQUIRE(potential.coordinates()[0U].value.exact_value.has_value());
  REQUIRE(potential.coordinates()[1U].value.exact_value.has_value());
  CHECK(*potential.coordinates()[0U].value.exact_value ==
        c22::rational(3, 1));
  CHECK(*potential.coordinates()[1U].value.exact_value ==
        c22::rational(2, 1));
  REQUIRE(potential.coordinates()[0U].exact_equation_residual.has_value());
  REQUIRE(potential.coordinates()[1U].exact_equation_residual.has_value());
  CHECK(potential.coordinates()[0U].exact_equation_residual->is_zero());
  CHECK(potential.coordinates()[1U].exact_equation_residual->is_zero());
  CHECK(potential.diagnostics().finite_dimension == 2U);
  CHECK(potential.diagnostics().exact_rank == 2U);
  CHECK(potential.diagnostics().closed_survivor_classes.empty());
  CHECK(potential.diagnostics().reciprocal_condition_estimate > 0.0L);
  CHECK_FALSE(potential.diagnostics().method.empty());
  CHECK(potential.diagnostics().zero_start_iterations > 0U);
  CHECK_FALSE(
      potential.diagnostics().authored_maximum_iterations.has_value());
  CHECK_FALSE(potential.diagnostics().maximum_iterations.has_value());
  CHECK(potential.diagnostics().absolute_residual_tolerance ==
        c22::rational(1, 1000000000000000LL));
  CHECK(potential.diagnostics().relative_residual_tolerance.is_zero());
  CHECK_FALSE(potential.diagnostics().budget_stop);

  CHECK(kernel.state_count() == 2U);
  REQUIRE(kernel.row_diagnostics().size() == 2U);
  for (const auto& row : kernel.row_diagnostics()) {
    CHECK(row.exact_source_mass == mwperf::ExactRational::one());
    CHECK(row.exact_balance_residual.is_zero());
    CHECK(row.source_error_lower.is_zero());
    CHECK(row.source_error_upper.is_zero());
  }
  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{2U}, true, true}, c22::solver_policy()));

  REQUIRE(stopped.survival_tails.size() == 3U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[1U].exact_probability ==
        c22::rational(3, 4));
  CHECK(stopped.survival_tails[2U].exact_probability ==
        c22::rational(1, 2));
  REQUIRE(stopped.absorption_masses.size() == 4U);
  CHECK(stopped.absorption_masses[0U].type_id == "hit");
  CHECK(stopped.absorption_masses[0U].hitting_time == mwperf::BigNat{1U});
  CHECK(stopped.absorption_masses[0U].exact_probability ==
        c22::rational(1, 8));
  CHECK(stopped.absorption_masses[1U].type_id == "kill");
  CHECK(stopped.absorption_masses[1U].hitting_time == mwperf::BigNat{1U});
  CHECK(stopped.absorption_masses[1U].exact_probability ==
        c22::rational(1, 8));
  CHECK(stopped.absorption_masses[2U].type_id == "hit");
  CHECK(stopped.absorption_masses[2U].hitting_time == mwperf::BigNat{2U});
  CHECK(stopped.absorption_masses[2U].exact_probability ==
        c22::rational(5, 32));
  CHECK(stopped.absorption_masses[3U].type_id == "kill");
  CHECK(stopped.absorption_masses[3U].hitting_time == mwperf::BigNat{2U});
  CHECK(stopped.absorption_masses[3U].exact_probability ==
        c22::rational(3, 32));
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::nondefective);
  CHECK(stopped.exact_defect_probability.is_zero());
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::finite);
  REQUIRE(stopped.mean_stopping_time.exact_value.has_value());
  CHECK(*stopped.mean_stopping_time.exact_value == c22::rational(3, 1));
  REQUIRE(stopped.eventual_typed_exit_probabilities.size() == 2U);
  CHECK(stopped.eventual_typed_exit_probabilities[0U].type_id == "hit");
  CHECK(stopped.eventual_typed_exit_probabilities[0U].exact_probability ==
        c22::rational(5, 8));
  CHECK(stopped.eventual_typed_exit_probabilities[1U].type_id == "kill");
  CHECK(stopped.eventual_typed_exit_probabilities[1U].exact_probability ==
        c22::rational(3, 8));
  CHECK(stopped.budget.requested_horizon == 2U);
  CHECK(stopped.budget.state_count == 2U);
  CHECK(stopped.budget.row_atom_count == 7U);
  CHECK(stopped.budget.iterations > 0U);
  CHECK_FALSE(stopped.budget.maximum_states.has_value());
  CHECK_FALSE(stopped.budget.maximum_row_atoms.has_value());
  CHECK_FALSE(stopped.budget.maximum_iterations.has_value());
  CHECK(stopped.budget.absolute_residual_tolerance ==
        c22::rational(1, 1000000000000000LL));
  CHECK(stopped.budget.relative_residual_tolerance.is_zero());
  CHECK_FALSE(stopped.budget.budget_stop);
  CHECK_FALSE(stopped.finite_results_preserved_when_mean_unavailable);
}

TEST_CASE("C22 defective killed chain keeps finite tails when its mean is "
          "infinite",
          "[c22][unit][stopped][defective]") {
  const auto source = c22::defective_killed_chain();
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), c22::zero_backlog_safe_set(),
      {{{c22::backlog_exit("hit", 1U)}}}));
  const auto finite_only = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{3U}, false, false},
          c22::solver_policy("c22.defective")));
  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{3U}, true, true},
          c22::solver_policy("c22.defective")));

  REQUIRE(finite_only.survival_tails.size() ==
          stopped.survival_tails.size());
  for (std::size_t index = 0U; index < stopped.survival_tails.size();
       ++index) {
    CHECK(finite_only.survival_tails[index].index ==
          stopped.survival_tails[index].index);
    CHECK(finite_only.survival_tails[index].exact_probability ==
          stopped.survival_tails[index].exact_probability);
  }
  REQUIRE(finite_only.absorption_masses.size() ==
          stopped.absorption_masses.size());
  for (std::size_t index = 0U; index < stopped.absorption_masses.size();
       ++index) {
    CHECK(finite_only.absorption_masses[index].hitting_time ==
          stopped.absorption_masses[index].hitting_time);
    CHECK(finite_only.absorption_masses[index].type_id ==
          stopped.absorption_masses[index].type_id);
    CHECK(finite_only.absorption_masses[index].exact_probability ==
          stopped.absorption_masses[index].exact_probability);
  }
  CHECK(finite_only.absorption_status ==
        mwperf::AbsorptionStatusV1::defective);
  CHECK(finite_only.exact_defect_probability == c22::rational(1, 2));
  CHECK(finite_only.eventual_typed_exit_probabilities.empty());
  CHECK(finite_only.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::not_established);
  CHECK_FALSE(finite_only.finite_results_preserved_when_mean_unavailable);
  CHECK(kernel.row_diagnostics().size() == 2U);
  REQUIRE(finite_only.typed_exit_defect_solve_diagnostics.has_value());
  CHECK(finite_only.typed_exit_defect_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::established);
  CHECK(finite_only.typed_exit_defect_solve_diagnostics->iterations > 0U);
  REQUIRE(finite_only.typed_exit_defect_solve_diagnostics->system_dimension
              .has_value());
  CHECK(*finite_only.typed_exit_defect_solve_diagnostics->system_dimension ==
        1U);
  REQUIRE(finite_only.typed_exit_defect_solve_diagnostics->exact_rank
              .has_value());
  CHECK(*finite_only.typed_exit_defect_solve_diagnostics->exact_rank == 1U);
  CHECK_FALSE(
      finite_only.typed_exit_defect_solve_diagnostics->method.empty());
  CHECK_FALSE(finite_only.potential_solve_diagnostics.has_value());
  REQUIRE(stopped.survival_tails.size() == 4U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  for (std::size_t index = 1U; index < stopped.survival_tails.size();
       ++index) {
    CHECK(stopped.survival_tails[index].exact_probability ==
          c22::rational(1, 2));
  }
  REQUIRE(stopped.absorption_masses.size() == 3U);
  CHECK(stopped.absorption_masses[0U].exact_probability ==
        c22::rational(1, 2));
  CHECK(stopped.absorption_masses[1U].exact_probability.is_zero());
  CHECK(stopped.absorption_masses[2U].exact_probability.is_zero());
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::defective);
  CHECK(stopped.exact_defect_probability == c22::rational(1, 2));
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
  CHECK_FALSE(stopped.mean_stopping_time.exact_value.has_value());
  CHECK(stopped.finite_results_preserved_when_mean_unavailable);
  REQUIRE(stopped.typed_exit_defect_solve_diagnostics.has_value());
  CHECK(stopped.typed_exit_defect_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::established);
  REQUIRE(stopped.potential_solve_diagnostics.has_value());
  CHECK(stopped.potential_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::established);
}

TEST_CASE("C22 zero iteration budget preserves finite stopped output",
          "[c22][unit][stopped][budget]") {
  const std::string name = "c22.zero-iteration-budget";
  const auto source = c22::exact_killed_chain(name);
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), c22::zero_backlog_safe_set(),
      two_exit_marks()));
  mwperf::SolverPolicy policy = c22::solver_policy(name);
  policy.max_iterations = mwperf::BigNat{0U};
  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{2U}, true, true}, policy));

  REQUIRE(stopped.survival_tails.size() == 3U);
  CHECK(stopped.survival_tails[1U].exact_probability ==
        c22::rational(3, 4));
  CHECK(stopped.survival_tails[2U].exact_probability ==
        c22::rational(1, 2));
  REQUIRE(stopped.absorption_masses.size() == 4U);
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::not_established);
  CHECK(stopped.absorption_status ==
        mwperf::AbsorptionStatusV1::not_established);
  CHECK(stopped.eventual_typed_exit_probabilities.empty());
  CHECK(stopped.finite_results_preserved_when_mean_unavailable);
  CHECK(stopped.budget.budget_stop);
  CHECK(stopped.budget.iterations == 0U);
  REQUIRE(stopped.budget.maximum_iterations.has_value());
  CHECK(*stopped.budget.maximum_iterations == 0U);
  REQUIRE(stopped.budget.authored_maximum_iterations.has_value());
  CHECK(stopped.budget.authored_maximum_iterations->is_zero());
  REQUIRE(stopped.typed_exit_defect_solve_diagnostics.has_value());
  CHECK(stopped.typed_exit_defect_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::budget_stopped);
  CHECK(stopped.typed_exit_defect_solve_diagnostics->iterations == 0U);
  REQUIRE(stopped.potential_solve_diagnostics.has_value());
  CHECK(stopped.potential_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::budget_stopped);
  CHECK(stopped.potential_solve_diagnostics->iterations == 0U);
}

TEST_CASE("C22 oversized positive iteration budget permits exact certificate",
          "[c22][unit][stopped][budget]") {
  const std::string name = "c22.oversized-positive-iteration-budget";
  const auto source = c22::exact_killed_chain(name);
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), c22::zero_backlog_safe_set(),
      two_exit_marks()));
  const mwperf::BigNat authored =
      mwperf::BigNat{std::numeric_limits<std::size_t>::max()} +
      mwperf::BigNat{1U};
  mwperf::SolverPolicy policy = c22::solver_policy(name);
  policy.max_iterations = authored;

  const auto potential = c22::require_value(
      mwperf::compute_minimal_killed_potential(kernel, policy));
  CHECK(potential.diagnostics().zero_start_iterations > 0U);
  REQUIRE(potential.diagnostics().authored_maximum_iterations.has_value());
  CHECK(*potential.diagnostics().authored_maximum_iterations == authored);
  CHECK_FALSE(potential.diagnostics().maximum_iterations.has_value());
  CHECK_FALSE(potential.diagnostics().budget_stop);

  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          kernel, require_optional(source.entrance),
          {mwperf::BigNat{2U}, true, true}, policy));
  CHECK(stopped.absorption_status ==
        mwperf::AbsorptionStatusV1::nondefective);
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::finite);
  CHECK(stopped.budget.iterations > 0U);
  CHECK_FALSE(stopped.budget.maximum_iterations.has_value());
  REQUIRE(stopped.budget.authored_maximum_iterations.has_value());
  CHECK(*stopped.budget.authored_maximum_iterations == authored);
  CHECK_FALSE(stopped.budget.budget_stop);
}

TEST_CASE("C22 source-derived gap and run ratios exclude inactive and "
          "startless components",
          "[c22][unit][temporal][components]") {
  const auto gap_source = c22::active_component_mixture();
  const auto gap = decode(mwperf::evaluate_runs_gaps_autocorrelation(
      require_optional(gap_source.law), c22::departure_mark(),
      {mwperf::TemporalStatisticKindV1::mean_event_gap,
       {}, std::nullopt, std::nullopt, {}}));
  REQUIRE(gap.exact_values.size() == 1U);
  CHECK(gap.exact_values.front() == c22::rational(2, 1));
  CHECK(gap.exact_values.front() != c22::rational(8, 1));

  const auto merged = c22::merged_label_active_component_mixture();
  const auto merged_gap = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          require_optional(merged.law), c22::departure_mark(),
          {mwperf::TemporalStatisticKindV1::mean_event_gap,
           {}, std::nullopt, std::nullopt, {}}));
  REQUIRE(merged_gap.exact_values.size() == 1U);
  CHECK(merged_gap.exact_values.front() == c22::rational(2, 1));

  const auto run_source = c22::finite_start_run_mixture();
  const auto run = decode(mwperf::evaluate_runs_gaps_autocorrelation(
      require_optional(run_source.law), c22::busy_state_mark(),
      {mwperf::TemporalStatisticKindV1::mean_binary_run,
       {}, std::nullopt, std::nullopt, {}}));
  REQUIRE(run.exact_values.size() == 1U);
  CHECK(run.exact_values.front() == mwperf::ExactRational::one());
  CHECK(run.exact_values.front() != c22::rational(3, 1));
}

TEST_CASE("C22 temporal statistics require their mathematical witnesses",
          "[c22][unit][temporal][negative]") {
  const auto zero = c22::state(0U);
  const auto one = c22::state(1U);
  std::vector<mwperf::testing::C22SyntheticNodeV1> unlabeled_nodes;
  unlabeled_nodes.push_back(
      {zero,
       {c22::transition(1U, zero, one, 0U, 0U,
                        mwperf::ExactRational::one())},
       std::nullopt});
  unlabeled_nodes.push_back(
      {one,
       {c22::transition(0U, one, zero, 1U, 1U,
                        mwperf::ExactRational::one())},
       std::nullopt});
  const auto unlabeled = c22::mint_stationary(
      "c22.unlabeled-components", std::move(unlabeled_nodes),
      {{0U, c22::rational(1, 2)}, {1U, c22::rational(1, 2)}},
      32U, 32U,
      {c22::mean_event_gap_authorization(
           mwperf::GapEventKind::departure),
       c22::mean_binary_run_authorization(
           mwperf::BasicBinaryPredicateV1::busy)});
  const auto derived_gap = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          require_optional(unlabeled.law), c22::departure_mark(),
          {mwperf::TemporalStatisticKindV1::mean_event_gap,
           {}, std::nullopt, std::nullopt, {}}));
  CHECK(derived_gap.exact_values.front() == c22::rational(2, 1));
  const auto derived_run = decode(
      mwperf::evaluate_runs_gaps_autocorrelation(
          require_optional(unlabeled.law), c22::busy_state_mark(),
          {mwperf::TemporalStatisticKindV1::mean_binary_run,
           {}, std::nullopt, std::nullopt, {}}));
  CHECK(derived_run.exact_values.front() == mwperf::ExactRational::one());

  const auto source = c22::iid_bernoulli_third("c22.service-mark-guard");
  const auto arrival_mark = mwperf::BinaryMark{
      mwperf::BinaryMarkKindV1::positive_target_arrival, 0U, std::nullopt};
  const std::vector<mwperf::LagSpec> service_requests{
      {mwperf::TemporalStatisticKindV1::service_persistence,
       {}, std::nullopt, std::nullopt, {}},
      {mwperf::TemporalStatisticKindV1::autocovariance,
       {mwperf::BigNat{1U}}, std::nullopt, std::nullopt, {}},
      {mwperf::TemporalStatisticKindV1::service_window_count,
       {}, mwperf::BigNat{2U}, std::nullopt, {}},
      {mwperf::TemporalStatisticKindV1::service_spectrum,
       {}, std::nullopt, mwperf::BigNat{1U},
       {mwperf::ExactRational::zero()}},
  };
  for (const auto& request : service_requests) {
    require_error(mwperf::evaluate_runs_gaps_autocorrelation(
                      require_optional(source.law), arrival_mark, request),
                  "c22.temporal_statistic_not_authorized_by_accepted_contract");
  }

  require_error(mwperf::evaluate_runs_gaps_autocorrelation(
                    require_optional(source.law), c22::departure_mark(),
                    {mwperf::TemporalStatisticKindV1::service_window_count,
                     {}, mwperf::BigNat{0U}, std::nullopt, {}}),
                "c22.temporal_statistic_not_authorized_by_accepted_contract");
}

TEST_CASE("C22 persistence rejects zero departure intensity after exact "
          "authorization",
          "[c22][unit][temporal][persistence][negative]") {
  const auto only = c22::state(0U);
  const auto source = c22::mint_stationary(
      "c22.zero-departure-persistence",
      {{only,
        {c22::transition(0U, only, only, 1U, 0U,
                         mwperf::ExactRational::one())},
        0U}},
      {{0U, mwperf::ExactRational::one()}}, 2U, 2U,
      {c22::service_persistence_authorization()});

  require_error(mwperf::evaluate_runs_gaps_autocorrelation(
                    require_optional(source.law), c22::departure_mark(),
                    {mwperf::TemporalStatisticKindV1::service_persistence,
                     {}, std::nullopt, std::nullopt, {}}),
                "c22.zero_departure_intensity_for_persistence");
}

TEST_CASE("C22 rejects nonunit exact rows and ambiguous or unclassified "
          "physical exits",
          "[c22][unit][negative]") {
  const auto only = c22::state(0U);
  std::vector<mwperf::testing::C22SyntheticNodeV1> malformed_nodes;
  malformed_nodes.push_back(
      {only,
       {c22::transition(0U, only, only, 0U, 0U,
                        c22::rational(999999999999LL, 1000000000000LL))},
       0U});
  const auto malformed = mwperf::testing::C22FixtureAccess::mint_exact_source(
      mwperf::AuditedTemporalSourceKindV1::stationary_projection,
      mwperf::InitialLawKindV1::stationary,
      c22::identity("c22.nonunit-row", true), std::move(malformed_nodes),
      {{0U, mwperf::ExactRational::one()}}, 1U, 1U);
  require_error(malformed, "c22.exact_temporal_source_row_not_unit");

  const auto source = c22::exact_killed_chain("c22.overlap");
  const mwperf::AbsorptionMarks overlapping{{
      c22::backlog_exit("first", 1U),
      c22::backlog_exit("second", 1U),
  }};
  require_error(mwperf::construct_killed_kernel(
                    require_optional(source.kernel),
                    c22::zero_backlog_safe_set(), overlapping),
                "c22.overlapping_absorption_sets");

  const mwperf::AbsorptionMarks missing_kill{{
      c22::backlog_exit("hit", 1U),
  }};
  require_error(mwperf::construct_killed_kernel(
                    require_optional(source.kernel),
                    c22::zero_backlog_safe_set(), missing_kill),
                "c22.unclassified_killed_exit");

  const auto alternator = c22::alternator("c22.absent-target");
  mwperf::CylinderEvent absent_departure;
  absent_departure.observations.push_back(mwperf::EdgeMarkAtV1{
      mwperf::BigNat{0U}, mwperf::TargetDeparturePredicateV1{1U, true}});
  const auto missing_mark = mwperf::evaluate_finite_cylinder(
      require_optional(alternator.cylinder), absent_departure,
      mwperf::BigNat{1U});
  require_error(missing_mark, "c22.edge_predicate_departure_mark_missing");
}

TEST_CASE("C22 synthetic Palm and FIFO mints reject malformed tag bindings",
          "[c22][unit][closed-carriers][negative]") {
  const auto only = c22::state(0U);
  const auto nodes = [&]() {
    return std::vector<mwperf::testing::C22SyntheticNodeV1>{{
        only,
        {c22::transition(0U, only, only, 0U, 0U,
                         mwperf::ExactRational::one())},
        0U}};
  };

  require_error(
      mwperf::testing::C22FixtureAccess::mint_exact_source(
          mwperf::AuditedTemporalSourceKindV1::passive_fifo_tag,
          mwperf::InitialLawKindV1::event_palm,
          c22::identity("c22.malformed-event-palm", true), nodes(),
          {{0U, mwperf::ExactRational::one()}}, 1U, 1U),
      "c22.invalid_synthetic_source_identity");
  require_error(
      mwperf::testing::C22FixtureAccess::mint_exact_source(
          mwperf::AuditedTemporalSourceKindV1::stationary_projection,
          mwperf::InitialLawKindV1::fifo_tag,
          c22::identity("c22.malformed-fifo-tag", true), nodes(),
          {{0U, mwperf::ExactRational::one()}}, 1U, 1U),
      "c22.invalid_synthetic_source_identity");
  require_error(
      mwperf::testing::C22FixtureAccess::mint_exact_source(
          mwperf::AuditedTemporalSourceKindV1::stationary_projection,
          mwperf::InitialLawKindV1::event_palm,
          c22::identity("c22.event-palm-out-of-domain", true), nodes(),
          {{1U, mwperf::ExactRational::one()}}, 1U, 1U),
      "c22.synthetic_entrance_out_of_domain");
}

TEST_CASE("C22 analytic row error remains separate from physical exits",
          "[c22][unit][stopped][analytic][negative]") {
  const auto exact_enclosure = c22::analytic_three_quarter_self_loop(
      "c22.analytic-row-exact-enclosure", c22::rational(1, 4),
      c22::rational(1, 4));
  const auto wide_enclosure = c22::analytic_three_quarter_self_loop(
      "c22.analytic-row-wide-enclosure", c22::rational(1, 8),
      c22::rational(3, 8));
  const auto exact_kernel = c22::require_value(
      mwperf::construct_killed_kernel(
          require_optional(exact_enclosure.kernel),
          mwperf::SafeSet{mwperf::AnyStatePredicateV1{}}, {}));
  const auto wide_kernel = c22::require_value(
      mwperf::construct_killed_kernel(
          require_optional(wide_enclosure.kernel),
          mwperf::SafeSet{mwperf::AnyStatePredicateV1{}}, {}));

  REQUIRE(exact_kernel.row_diagnostics().size() == 1U);
  REQUIRE(wide_kernel.row_diagnostics().size() == 1U);
  const auto& exact_row = exact_kernel.row_diagnostics().front();
  const auto& wide_row = wide_kernel.row_diagnostics().front();
  CHECK(exact_row.exact_source_mass == c22::rational(3, 4));
  CHECK(exact_row.exact_survivor_mass == c22::rational(3, 4));
  CHECK(exact_row.exact_typed_exit_masses.empty());
  CHECK(exact_row.exact_balance_residual.is_zero());
  CHECK(exact_row.source_error_lower == c22::rational(1, 4));
  CHECK(exact_row.source_error_upper == c22::rational(1, 4));
  CHECK(wide_row.exact_source_mass == exact_row.exact_source_mass);
  CHECK(wide_row.exact_survivor_mass == exact_row.exact_survivor_mass);
  CHECK(wide_row.exact_typed_exit_masses ==
        exact_row.exact_typed_exit_masses);
  CHECK(wide_row.source_error_lower == c22::rational(1, 8));
  CHECK(wide_row.source_error_upper == c22::rational(3, 8));

  require_error(mwperf::compute_minimal_killed_potential(
                    exact_kernel,
                    c22::solver_policy("c22.analytic-row-exact-enclosure")),
                "c22.analytic_killed_potential_numerically_unresolved");
  require_error(mwperf::evaluate_hit_survival_absorption(
                    exact_kernel, require_optional(exact_enclosure.entrance),
                    {mwperf::BigNat{2U}, false, false},
                    c22::solver_policy(
                        "c22.analytic-row-exact-enclosure")),
                "c22.analytic_stopped_recursion_numerically_unresolved");

  const auto invalid = mwperf::testing::C22FixtureAccess::mint_analytic_source(
      mwperf::AuditedTemporalSourceKindV1::stationary_projection,
      mwperf::InitialLawKindV1::event_palm,
      c22::identity("c22.analytic-row-uncovered", true),
      {{c22::state(0U),
        {c22::transition(0U, c22::state(0U), c22::state(0U), 1U, 0U,
                         c22::rational(3, 4))},
        std::nullopt}},
      {{0U, mwperf::ExactRational::one()}},
      {{c22::rational(1, 8), c22::rational(1, 8)}}, 8U, 8U);
  require_error(invalid,
                "c22.analytic_temporal_source_enclosure_not_covering_unity");
}

TEST_CASE("C22 a state frontier does not fabricate its outgoing edge",
          "[c22][unit][cylinder][frontier][negative]") {
  const auto zero = c22::state(0U);
  const auto one = c22::state(1U);
  const auto source = c22::mint_stationary(
      "c22.state-frontier-no-edge",
      {{zero,
        {c22::transition(1U, zero, one, 0U, 0U,
                         mwperf::ExactRational::one())},
        0U},
       {one,
        {c22::transition(0U, one, zero, 1U, 1U,
                         mwperf::ExactRational::one())},
        0U}},
      {{0U, c22::rational(1, 2)}, {1U, c22::rational(1, 2)}}, 1U, 0U);

  const mwperf::CylinderEvent state_at_frontier{{mwperf::StateAtV1{
      mwperf::BigNat{1U}, mwperf::AnyStatePredicateV1{}}}};
  const auto state_result = decode(mwperf::evaluate_finite_cylinder(
      require_optional(source.cylinder), state_at_frontier,
      mwperf::BigNat{1U}));
  CHECK(state_result.exact_values.front() ==
        mwperf::ExactRational::one());
  CHECK(state_result.completed_steps == 1U);

  const mwperf::CylinderEvent edge_from_frontier{{mwperf::EdgeMarkAtV1{
      mwperf::BigNat{1U}, mwperf::AnyEdgePredicateV1{}}}};
  require_error(mwperf::evaluate_finite_cylinder(
                    require_optional(source.cylinder), edge_from_frontier,
                    mwperf::BigNat{2U}),
                "c22.edge_offset_beyond_temporal_budget");
}

TEST_CASE("C22 runtime-mark predicates diagnose missing codec and duplicates",
          "[c22][unit][cylinder][runtime-mark][negative]") {
  const auto mark_id = c22::runtime_mark_id("c22.fixture.runtime-mark");
  const mwperf::CodecIdentityV1 retained_codec{
      "c22.fixture.runtime-mark-value", 1U};
  const mwperf::CodecIdentityV1 foreign_codec{
      "c22.fixture.runtime-mark-value.foreign", 1U};
  const auto value = std::vector<std::byte>{std::byte{0x2aU}};
  const auto predicate = [&](const mwperf::CodecIdentityV1& codec) {
    return mwperf::CylinderEvent{{mwperf::EdgeMarkAtV1{
        mwperf::BigNat{0U},
        mwperf::ExactRuntimeMarkPredicateV1{mark_id, codec, value}}}};
  };
  const auto source_with_marks = [&](const std::string_view name,
                                     std::vector<mwperf::CausalMarkV1> marks) {
    const auto only = c22::state(0U);
    auto marked = c22::edge(only, only, 1U, 0U);
    marked.marks = std::move(marks);
    return c22::mint_stationary(
        name, {{only, {{0U, std::move(marked),
                        mwperf::ExactRational::one()}}, 0U}},
        {{0U, mwperf::ExactRational::one()}}, 1U, 0U);
  };

  const auto missing = source_with_marks("c22.runtime-mark-missing", {});
  require_error(mwperf::evaluate_finite_cylinder(
                    require_optional(missing.cylinder),
                    predicate(retained_codec), mwperf::BigNat{1U}),
                "c22.runtime_mark_not_retained");

  const auto one_mark = c22::runtime_mark(
      mark_id, retained_codec, std::vector<std::byte>{std::byte{0x2aU}});
  const auto codec = source_with_marks("c22.runtime-mark-codec", {one_mark});
  require_error(mwperf::evaluate_finite_cylinder(
                    require_optional(codec.cylinder), predicate(foreign_codec),
                    mwperf::BigNat{1U}),
                "c22.runtime_mark_codec_mismatch");

  const mwperf::CylinderEvent wrong_value{{mwperf::EdgeMarkAtV1{
      mwperf::BigNat{0U},
      mwperf::ExactRuntimeMarkPredicateV1{
          mark_id, retained_codec,
          std::vector<std::byte>{std::byte{0x2bU}}}}}};
  const auto false_probability = decode(mwperf::evaluate_finite_cylinder(
      require_optional(codec.cylinder), wrong_value,
      mwperf::BigNat{1U}));
  REQUIRE(false_probability.exact_values.size() == 1U);
  CHECK(false_probability.exact_values.front().is_zero());

  const auto duplicate = source_with_marks(
      "c22.runtime-mark-duplicate", {one_mark, one_mark});
  require_error(mwperf::evaluate_finite_cylinder(
                    require_optional(duplicate.cylinder),
                    predicate(retained_codec), mwperf::BigNat{1U}),
                "c22.duplicate_runtime_mark");
}

TEST_CASE("C22 a whole safe set has exact zero physical exit mass",
          "[c22][unit][stopped][row-mass]") {
  const auto source = c22::iid_bernoulli_third("c22.whole-safe-set");
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), {{mwperf::AnyStatePredicateV1{}}},
      {}));
  REQUIRE(kernel.row_diagnostics().size() == 1U);
  const auto& row = kernel.row_diagnostics().front();
  CHECK(row.exact_source_mass == mwperf::ExactRational::one());
  CHECK(row.exact_survivor_mass == mwperf::ExactRational::one());
  CHECK(row.exact_typed_exit_masses.empty());
  CHECK(row.exact_balance_residual.is_zero());
  CHECK(row.source_error_lower.is_zero());
  CHECK(row.source_error_upper.is_zero());
}

TEST_CASE("C22 edge-mark killing is physical even when its successor is "
          "state-safe",
          "[c22][unit][stopped][edge-exit]") {
  const auto source = c22::iid_bernoulli_third("c22.safe-successor-exit");
  const mwperf::AbsorptionMarks departures{{
      {"departure", mwperf::AnyStatePredicateV1{},
       mwperf::TargetDeparturePredicateV1{0U, true}},
  }};
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), {mwperf::AnyStatePredicateV1{}},
      departures));
  CHECK(kernel.state_count() == 1U);
  REQUIRE(kernel.row_diagnostics().size() == 1U);
  const auto& row = kernel.row_diagnostics().front();
  CHECK(row.exact_survivor_mass == c22::rational(2, 3));
  REQUIRE(row.exact_typed_exit_masses.size() == 1U);
  CHECK(row.exact_typed_exit_masses.front() == c22::rational(1, 3));
  CHECK(row.exact_balance_residual.is_zero());
}

TEST_CASE("C22 stopped evaluation rejects entrance mass outside the safe "
          "domain",
          "[c22][unit][stopped][negative]") {
  const auto source = c22::unsafe_hit_entrance_chain();
  const mwperf::AbsorptionMarks hit{{c22::backlog_exit("hit", 1U)}};
  const auto kernel = c22::require_value(mwperf::construct_killed_kernel(
      require_optional(source.kernel), c22::zero_backlog_safe_set(), hit));
  CHECK(kernel.state_count() == 1U);
  require_error(mwperf::evaluate_hit_survival_absorption(
                    kernel, require_optional(source.entrance),
                    {mwperf::BigNat{1U}, false, false},
                    c22::solver_policy("c22.unsafe-entrance")),
                "c22.initial_law_not_supported_on_safe_set");
}
