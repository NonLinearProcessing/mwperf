#include <array>
#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c20/audited_reset_temporal_fixture.hpp"
#include "fixtures/c20/enumerable_four_word_fixture.hpp"
#include "fixtures/c20/multi_slot_temporal_fixture.hpp"
#include "fixtures/c20/reset_identity_fixture.hpp"
#include "mwperf/temporal/romr.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

static_assert(!std::default_initializable<mwperf::SealedRomrOpsHandle>);
static_assert(!std::default_initializable<mwperf::ResidenceCursor>);
static_assert(!std::default_initializable<mwperf::ResidenceStep>);
static_assert(!std::default_initializable<mwperf::StopDecision>);
static_assert(!std::default_initializable<mwperf::ResidenceWord>);
static_assert(!std::default_initializable<mwperf::ResidenceWordRow>);
static_assert(!std::default_initializable<mwperf::FiniteEventStateDomain>);
static_assert(!std::default_initializable<mwperf::EmbeddedKernel>);
static_assert(!std::default_initializable<mwperf::TemporalPath>);

TEST_CASE("C20 reset identity permits only a declared residence-local age",
          "[c20][unit][reset][exact-coordinate]") {
  namespace reset = mwperf::testing::c20_reset;
  auto fixture = reset::reset_coordinates();
  const std::array declared_local_age{fixture.local_age};
  const auto preserves = [&](const mwperf::ExactReducedCoordinatesV1& after) {
    return mwperf::testing::C20FixtureAccess::
        reset_preserves_persistent_coordinates_for_testing(
            fixture.baseline, after, declared_local_age);
  };

  auto legal = fixture.baseline;
  legal.unresolved_fields.front().value =
      mwperf::testing::c17::value("c20.fixture.age", {0x00U});
  CHECK(preserves(legal));

  CHECK_FALSE(mwperf::testing::C20FixtureAccess::
                  reset_preserves_persistent_coordinates_for_testing(
                      fixture.baseline, legal,
                      std::span<const mwperf::RuntimeFieldIdV1>{}));

  auto persistent_mode = legal;
  persistent_mode.unresolved_fields.back().value =
      mwperf::testing::c17::value("c20.fixture.mode", {0x03U});
  CHECK_FALSE(preserves(persistent_mode));

  auto queue = legal;
  queue.backlog = fixture.alternate_backlog;
  CHECK_FALSE(preserves(queue));

  auto phase = legal;
  phase.arrival_phase = fixture.alternate_phase;
  CHECK_FALSE(preserves(phase));

  auto boundary = legal;
  boundary.boundary_index = boundary.boundary_index + mwperf::BigNat{1U};
  CHECK_FALSE(preserves(boundary));

  auto resources = legal;
  resources.resources = fixture.alternate_resources;
  CHECK_FALSE(preserves(resources));

  auto margins = legal;
  margins.margins = {fixture.alternate_margin};
  REQUIRE(margins.margins.size() == fixture.baseline.margins.size());
  CHECK_FALSE(preserves(margins));

  auto controller = legal;
  controller.controller =
      mwperf::testing::c17::value("c20.fixture.controller", {0x42U});
  CHECK_FALSE(preserves(controller));
}

TEST_CASE("C20 audited residence resets only local age and retains raw age",
          "[c20][unit][reset][audited][word]") {
  namespace reset = mwperf::testing::c20_reset_audited;
  auto fixture = reset::framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);

  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  CHECK(reset::state_byte(cursor.value().event_entry(), reset::kAgeOffset) ==
        7U);
  CHECK(reset::state_byte(cursor.value().raw_continuation(),
                          reset::kAgeOffset) == 0U);
  auto entry_exact = fixture.state_schema.decode(fixture.initial_state);
  auto initialized_exact =
      fixture.state_schema.decode(cursor.value().raw_continuation());
  REQUIRE(entry_exact);
  REQUIRE(initialized_exact);
  CHECK(mwperf::testing::c17::same_phase(
      entry_exact.value().arrival_phase,
      initialized_exact.value().arrival_phase));
  CHECK(entry_exact.value().margins == initialized_exact.value().margins);

  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC20A6E0U});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(step);
  CHECK(reset::state_byte(step.value().edge().successor_state(),
                          reset::kAgeOffset) == 7U);
  auto successor_exact =
      fixture.state_schema.decode(step.value().edge().successor_state());
  REQUIRE(successor_exact);
  REQUIRE(successor_exact.value().margins.size() == 1U);
  CHECK(successor_exact.value().backlog.value_at_target_ordinal(0U) ==
        mwperf::BigNat{1U});
  const std::size_t target_ordinal = successor_exact.value()
                                         .backlog
                                         .target_at_target_ordinal(0U)
                                         .ordinal();
  CHECK(successor_exact.value()
            .margins.front()
            .evaluation_backlog()
            .values()[target_ordinal] == mwperf::BigNat{1U});
  const auto raw_age = std::ranges::find_if(
      step.value().edge().marks(), [](const mwperf::CausalMarkV1& mark) {
        return mark.mark.mark == reset::raw_age_mark();
      });
  REQUIRE(raw_age != step.value().edge().marks().end());
  CHECK(raw_age->reveal_stage == mwperf::CausalStageV1::psi);
  CHECK(raw_age->mark.value.codec == reset::kAgeCodec);
  REQUIRE(raw_age->mark.value.canonical_value.size() == 1U);
  CHECK(std::to_integer<std::uint8_t>(
            raw_age->mark.value.canonical_value.front()) == 7U);

  auto stop =
      mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(stop);
  REQUIRE(stop.value().stops());
  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  CHECK(word.value().length() == mwperf::BigNat{1U});
  REQUIRE(word.value().edges().size() == 1U);
  const auto retained_raw_age = std::ranges::find_if(
      word.value().edges().front().marks(),
      [](const mwperf::CausalMarkV1& mark) {
        return mark.mark.mark == reset::raw_age_mark();
      });
  REQUIRE(retained_raw_age != word.value().edges().front().marks().end());
  CHECK(retained_raw_age->reveal_stage == mwperf::CausalStageV1::psi);
  CHECK(retained_raw_age->mark.value.codec == reset::kAgeCodec);
  REQUIRE(retained_raw_age->mark.value.canonical_value.size() == 1U);
  CHECK(std::to_integer<std::uint8_t>(
            retained_raw_age->mark.value.canonical_value.front()) == 7U);
  CHECK(reset::state_byte(word.value().raw_terminal_state(),
                          reset::kAgeOffset) == 7U);
  CHECK(reset::state_byte(word.value().event_endpoint(),
                          reset::kAgeOffset) == 7U);
  REQUIRE(word.value().continuation_path().size() == 2U);
  CHECK(reset::state_byte(word.value().continuation_path().back(),
                          reset::kAgeOffset) == 0U);
  auto raw_exact =
      fixture.state_schema.decode(word.value().raw_terminal_state());
  auto reset_exact =
      fixture.state_schema.decode(word.value().continuation_path().back());
  REQUIRE(raw_exact);
  REQUIRE(reset_exact);
  CHECK(mwperf::testing::c17::same_phase(
      raw_exact.value().arrival_phase, reset_exact.value().arrival_phase));
  CHECK(raw_exact.value().margins == reset_exact.value().margins);
}

TEST_CASE("C20 audited entry reset rejects predictive phase mutation",
          "[c20][unit][reset][audited][negative]") {
  namespace reset = mwperf::testing::c20_reset_audited;
  auto fixture = reset::framework(reset::ResetFaultV1::entry_phase);
  auto view = mwperf::audited_romr_view(fixture.framework);
  REQUIRE(view);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE_FALSE(cursor);
  CHECK(cursor.error().code == "c20.initializer_reset_exact_coordinate");
}

TEST_CASE("C20 audited terminal reset rejects exact margin mutation",
          "[c20][unit][reset][audited][negative]") {
  namespace reset = mwperf::testing::c20_reset_audited;
  auto fixture = reset::framework(reset::ResetFaultV1::terminal_margin);
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC20A6E1U});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(step);
  auto stop =
      mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(stop);
  REQUIRE(stop.value().stops());
  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE_FALSE(word);
  CHECK(word.error().code == "c20.terminal_reset_exact_coordinate");
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::failed);
}

TEST_CASE("C20 canonical residence is one complete causal slot",
          "[c20][unit][romr]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);

  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto cursor = mwperf::begin_residence(view.value(), entrance);
  REQUIRE(cursor);
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::open);
  CHECK(cursor.value().offset() == mwperf::BigNat{0U});
  CHECK(cursor.value().version() == mwperf::BigNat{0U});
  CHECK(cursor.value().event_entry() == entrance);
  CHECK(cursor.value().current_state() == entrance);
  CHECK(cursor.value().edges().empty());
  CHECK(cursor.value().ops_handle().identity().hex().size() == 64U);

  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC2001U});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(step);
  CHECK(cursor.value().lifecycle() ==
        mwperf::ResidenceLifecycleV1::step_pending_validation);
  CHECK(cursor.value().offset() == mwperf::BigNat{1U});
  CHECK(cursor.value().version() == mwperf::BigNat{1U});
  CHECK(cursor.value().current_state() == step.value().edge().successor_state());
  REQUIRE(cursor.value().edges().size() == 1U);
  CHECK(cursor.value().edges().front() == step.value().edge());
  CHECK(step.value().edge().stage_trace() == mwperf::kCausalStageOrderV1);
  CHECK(step.value().input_version() == mwperf::BigNat{0U});
  CHECK(step.value().output_version() == mwperf::BigNat{1U});

  auto decision =
      mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(decision);
  CHECK(decision.value().stops());
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::stopped);

  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::finalized);
  CHECK(word.value().length() == mwperf::BigNat{1U});
  CHECK(word.value().entry_state() == entrance);
  CHECK(word.value().event_endpoint() == step.value().edge().successor_state());
  REQUIRE(word.value().continuation_path().size() == 2U);
  CHECK(word.value().continuation_path().front().canonical_value ==
        entrance.canonical_value);
  REQUIRE(word.value().edges().size() == 1U);
  CHECK(word.value().edges().front() == step.value().edge());
  REQUIRE(word.value().predecision_projections().size() == 1U);
  REQUIRE(word.value().completed_edge_projections().size() == 1U);
  CHECK(word.value().continuation_path().back().canonical_value ==
        word.value().event_endpoint().canonical_value);
  CHECK(word.value().predecision_projections().front() ==
        step.value().predecision_projection());
  CHECK(word.value().completed_edge_projections().front() ==
        step.value().completed_edge_projection());
  CHECK(word.value().word_digest().hex().size() == 64U);
}

TEST_CASE("C20 deterministic residence continues twice and stops after slot three",
          "[c20][unit][romr][multi-slot]") {
  auto fixture =
      mwperf::testing::c20::make_deterministic_three_slot_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC203520U});
  REQUIRE(bank);
  auto q0 = fixture.instance.queues().index_at(0U);
  REQUIRE(q0);

  constexpr std::array<std::uint8_t, 4U> expected_backlog{2U, 1U, 3U,
                                                         2U};
  constexpr std::array<std::uint8_t, 3U> expected_departure{1U, 0U, 1U};
  constexpr std::array<std::uint8_t, 3U> expected_arrival{0U, 2U, 0U};
  std::vector<mwperf::ResidenceStep> steps;
  steps.reserve(3U);
  for (std::size_t slot = 0U; slot < 3U; ++slot) {
    CHECK(mwperf::testing::c20::backlog_value(cursor.value().current_state()) ==
          expected_backlog[slot]);
    CHECK(mwperf::testing::c20::phase_index(cursor.value().current_state()) ==
          slot);
    auto step = mwperf::advance_residence(
        cursor.value(), executor.value(), bank.value());
    REQUIRE(step);
    CHECK(step.value().offset() == mwperf::BigNat{slot + 1U});
    CHECK(step.value().input_version() == mwperf::BigNat{slot});
    CHECK(step.value().output_version() == mwperf::BigNat{slot + 1U});
    CHECK(mwperf::testing::c20::backlog_value(
              step.value().edge().pre_state()) == expected_backlog[slot]);
    CHECK(mwperf::testing::c20::backlog_value(
              step.value().edge().successor_state()) ==
          expected_backlog[slot + 1U]);
    CHECK(mwperf::testing::c20::phase_index(
              step.value().edge().pre_state()) == slot);
    CHECK(mwperf::testing::c20::phase_index(
              step.value().edge().successor_state()) == slot + 1U);
    CHECK(step.value().edge().action().actual_departure.at(q0.value()) ==
          (expected_departure[slot] != 0U));
    REQUIRE(step.value().edge().arrival().batch.binding().has_value());
    auto arrival = mwperf::project_arrival_count(
        step.value().edge().arrival().batch, q0.value(),
        *step.value().edge().arrival().batch.binding());
    REQUIRE(arrival);
    CHECK(arrival.value() == mwperf::BigNat{expected_arrival[slot]});
    CHECK(step.value().edge().stage_trace() ==
          mwperf::kCausalStageOrderV1);
    CHECK(mwperf::testing::c20::one_byte_projection(
              step.value().predecision_projection()) == slot);
    CHECK(mwperf::testing::c20::one_byte_projection(
              step.value().completed_edge_projection()) == slot + 1U);

    auto decision =
        mwperf::validate_residence_stop(cursor.value(), step.value());
    REQUIRE(decision);
    CHECK(decision.value().stops() == (slot == 2U));
    CHECK(decision.value().offset() == mwperf::BigNat{slot + 1U});
    CHECK(cursor.value().lifecycle() ==
          (slot == 2U ? mwperf::ResidenceLifecycleV1::stopped
                      : mwperf::ResidenceLifecycleV1::open));
    steps.push_back(step.value());
  }

  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  CHECK(word.value().length() == mwperf::BigNat{3U});
  CHECK(word.value().entry_state() == fixture.initial_state);
  CHECK(mwperf::testing::c20::backlog_value(
            word.value().event_endpoint()) == 2U);
  CHECK(mwperf::testing::c20::phase_index(
            word.value().event_endpoint()) == 3U);
  CHECK(word.value().raw_terminal_state().canonical_value ==
        word.value().event_endpoint().canonical_value);
  REQUIRE(word.value().continuation_path().size() == 4U);
  REQUIRE(word.value().edges().size() == 3U);
  REQUIRE(word.value().predecision_projections().size() == 3U);
  REQUIRE(word.value().completed_edge_projections().size() == 3U);
  for (std::size_t slot = 0U; slot < 3U; ++slot) {
    const auto& continuation = word.value().continuation_path()[slot];
    CHECK(std::to_integer<std::uint8_t>(
              continuation.canonical_value[0U]) == expected_backlog[slot]);
    CHECK(std::to_integer<std::uint8_t>(
              continuation.canonical_value[1U]) == slot);
    CHECK(word.value().edges()[slot] == steps[slot].edge());
    CHECK(mwperf::testing::c20::one_byte_projection(
              word.value().predecision_projections()[slot]) == slot);
    CHECK(mwperf::testing::c20::one_byte_projection(
              word.value().completed_edge_projections()[slot]) ==
          slot + 1U);
  }
  const auto& terminal = word.value().continuation_path().back();
  CHECK(std::to_integer<std::uint8_t>(terminal.canonical_value[0U]) == 2U);
  CHECK(std::to_integer<std::uint8_t>(terminal.canonical_value[1U]) == 3U);
  CHECK(fixture.residence_generator_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C20 validates a stop only after a completed edge",
          "[c20][unit][lifecycle][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  auto cursor = mwperf::begin_residence(view.value(), entrance);
  REQUIRE(cursor);
  auto premature = mwperf::finalize_residence_word(cursor.value());
  REQUIRE_FALSE(premature);
  CHECK(premature.error().code == "c20.cursor_not_stopped");

  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC2002U});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(step);
  auto second_advance = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE_FALSE(second_advance);
  CHECK(second_advance.error().code == "c20.cursor_not_open");

  auto decision =
      mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(decision);
  REQUIRE(decision.value().stops());
  auto repeated_stop =
      mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE_FALSE(repeated_stop);
  CHECK(repeated_stop.error().code ==
        "c20.cursor_not_pending_stop_validation");
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::stopped);

  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  auto repeated_finalize = mwperf::finalize_residence_word(cursor.value());
  REQUIRE_FALSE(repeated_finalize);
  CHECK(repeated_finalize.error().code == "c20.cursor_already_finalized");
}

TEST_CASE("C20 step tokens cannot cross residence cursors",
          "[c20][unit][binding][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto first = mwperf::begin_residence(view.value(), entrance);
  auto second = mwperf::begin_residence(view.value(), entrance);
  REQUIRE(first);
  REQUIRE(second);

  auto first_bank =
      mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
          view.value(), fixture.instance, mwperf::MasterSeed{0xC2003U});
  auto second_bank =
      mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
          view.value(), fixture.instance, mwperf::MasterSeed{0xC2003U});
  REQUIRE(first_bank);
  REQUIRE(second_bank);
  auto first_step = mwperf::advance_residence(
      first.value(), executor.value(), first_bank.value());
  auto second_step = mwperf::advance_residence(
      second.value(), executor.value(), second_bank.value());
  REQUIRE(first_step);
  REQUIRE(second_step);
  CHECK(first_step.value().edge() == second_step.value().edge());

  auto crossed =
      mwperf::validate_residence_stop(second.value(), first_step.value());
  REQUIRE_FALSE(crossed);
  CHECK(crossed.error().code == "c20.step_binding_mismatch");

  // A rejected foreign token is atomic: the cursor can still consume its own
  // pending step and reach the unique positive stop.
  auto own =
      mwperf::validate_residence_stop(second.value(), second_step.value());
  REQUIRE(own);
  CHECK(own.value().stops());
}

TEST_CASE("C20 rejects a stale step from the same residence cursor",
          "[c20][unit][binding][stale][negative]") {
  auto fixture =
      mwperf::testing::c20::make_deterministic_three_slot_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC203561U});
  REQUIRE(bank);

  auto first = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(first);
  auto first_decision =
      mwperf::validate_residence_stop(cursor.value(), first.value());
  REQUIRE(first_decision);
  REQUIRE_FALSE(first_decision.value().stops());

  auto second = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(second);
  REQUIRE(second.value().offset() == mwperf::BigNat{2U});
  REQUIRE(second.value().output_version() == mwperf::BigNat{2U});
  REQUIRE(first.value().offset() == mwperf::BigNat{1U});
  REQUIRE(first.value().output_version() == mwperf::BigNat{1U});
  REQUIRE(first.value().completed_edge_digest() !=
          second.value().completed_edge_digest());
  const auto state_before = cursor.value().current_state();
  const auto edge_count_before = cursor.value().edges().size();

  auto stale =
      mwperf::validate_residence_stop(cursor.value(), first.value());
  REQUIRE_FALSE(stale);
  CHECK(stale.error().code == "c20.step_binding_mismatch");
  CHECK(cursor.value().lifecycle() ==
        mwperf::ResidenceLifecycleV1::step_pending_validation);
  CHECK(cursor.value().offset() == mwperf::BigNat{2U});
  CHECK(cursor.value().version() == mwperf::BigNat{2U});
  CHECK(cursor.value().current_state() == state_before);
  CHECK(cursor.value().edges().size() == edge_count_before);

  // Rejection is atomic: the exact current token remains usable.
  auto current =
      mwperf::validate_residence_stop(cursor.value(), second.value());
  REQUIRE(current);
  CHECK_FALSE(current.value().stops());
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::open);
}

TEST_CASE("C20 rejects continuation at the sealed maximum residence length",
          "[c20][unit][stop][maximum][negative]") {
  auto fixture =
      mwperf::testing::c20::make_continuing_at_sealed_maximum_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC203562U});
  REQUIRE(bank);

  auto first = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(first);
  auto continued =
      mwperf::validate_residence_stop(cursor.value(), first.value());
  REQUIRE(continued);
  REQUIRE_FALSE(continued.value().stops());

  auto second = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(second);
  REQUIRE(cursor.value().offset() == mwperf::BigNat{2U});
  const auto rng_before_rejection = bank.value().snapshot();
  auto rejected =
      mwperf::validate_residence_stop(cursor.value(), second.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c20.declared_max_residence_exceeded");
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::failed);
  CHECK(cursor.value().offset() == mwperf::BigNat{2U});
  CHECK(cursor.value().edges().size() == 2U);
  CHECK(bank.value().snapshot() == rng_before_rejection);

  auto not_a_word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE_FALSE(not_a_word);
  CHECK(not_a_word.error().code == "c20.cursor_not_stopped");
}

TEST_CASE("C20 rejects a slot executor from another audited framework",
          "[c20][unit][binding][negative]") {
  auto left = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto right = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto left_view = mwperf::audited_romr_view(left.framework);
  auto right_executor = mwperf::audited_slot_executor(right.framework);
  REQUIRE(left_view);
  REQUIRE(right_executor);
  const auto entrance =
      mwperf::testing::c17::reduced_state(left.ordered_targets, {2U});
  auto cursor = mwperf::begin_residence(left_view.value(), entrance);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      left_view.value(), left.instance, mwperf::MasterSeed{0xC2004U});
  REQUIRE(bank);
  const auto bank_before = bank.value().snapshot();

  auto rejected = mwperf::advance_residence(
      cursor.value(), right_executor.value(), bank.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c20.executor_binding_mismatch");
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::open);
  CHECK(cursor.value().offset() == mwperf::BigNat{0U});
  CHECK(bank.value().snapshot() == bank_before);
}

TEST_CASE("C20 rejects a completed step from another audited seal",
          "[c20][unit][step][binding][negative]") {
  auto left = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto right = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto left_view = mwperf::audited_romr_view(left.framework);
  auto right_view = mwperf::audited_romr_view(right.framework);
  auto left_executor = mwperf::audited_slot_executor(left.framework);
  auto right_executor = mwperf::audited_slot_executor(right.framework);
  REQUIRE(left_view);
  REQUIRE(right_view);
  REQUIRE(left_executor);
  REQUIRE(right_executor);
  const auto left_entry =
      mwperf::testing::c17::reduced_state(left.ordered_targets, {2U});
  const auto right_entry =
      mwperf::testing::c17::reduced_state(right.ordered_targets, {2U});
  auto left_cursor = mwperf::begin_residence(left_view.value(), left_entry);
  auto right_cursor = mwperf::begin_residence(right_view.value(), right_entry);
  REQUIRE(left_cursor);
  REQUIRE(right_cursor);
  auto left_bank =
      mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
          left_view.value(), left.instance, mwperf::MasterSeed{0xC2006U});
  auto right_bank =
      mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
          right_view.value(), right.instance, mwperf::MasterSeed{0xC2006U});
  REQUIRE(left_bank);
  REQUIRE(right_bank);
  auto left_step = mwperf::advance_residence(
      left_cursor.value(), left_executor.value(), left_bank.value());
  auto right_step = mwperf::advance_residence(
      right_cursor.value(), right_executor.value(), right_bank.value());
  REQUIRE(left_step);
  REQUIRE(right_step);

  auto foreign = mwperf::validate_residence_stop(
      left_cursor.value(), right_step.value());
  REQUIRE_FALSE(foreign);
  CHECK(foreign.error().code == "c20.step_binding_mismatch");
  CHECK(left_cursor.value().lifecycle() ==
        mwperf::ResidenceLifecycleV1::step_pending_validation);
  CHECK(left_cursor.value().offset() == mwperf::BigNat{1U});

  auto own = mwperf::validate_residence_stop(
      left_cursor.value(), left_step.value());
  REQUIRE(own);
  CHECK(own.value().stops());
}

TEST_CASE("C20 rejects physical-route banks without mutating a cursor",
          "[c20][unit][rng][binding][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto cursor = mwperf::begin_residence(view.value(), entrance);
  REQUIRE(cursor);

  auto physical = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{0xC2005U});
  REQUIRE(physical);
  auto rejected = mwperf::advance_residence(
      cursor.value(), executor.value(), physical.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "temporal_rng_bank_route_mismatch");
  CHECK(cursor.value().lifecycle() == mwperf::ResidenceLifecycleV1::open);
  CHECK(cursor.value().offset() == mwperf::BigNat{0U});
  CHECK(cursor.value().version() == mwperf::BigNat{0U});
  CHECK(cursor.value().current_state() == entrance);
  CHECK(cursor.value().edges().empty());

  auto temporal =
      mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
          view.value(), fixture.instance, mwperf::MasterSeed{0xC2005U});
  REQUIRE(temporal);
  auto accepted = mwperf::advance_residence(
      cursor.value(), executor.value(), temporal.value());
  REQUIRE(accepted);
  CHECK(cursor.value().lifecycle() ==
        mwperf::ResidenceLifecycleV1::step_pending_validation);
  CHECK(cursor.value().offset() == mwperf::BigNat{1U});
}

TEST_CASE("C20 finite quotient rejects entries outside its sealed domain",
          "[c20][unit][entry-domain][negative]") {
  auto fixture =
      mwperf::testing::c20::make_four_word_enumerable_framework();
  auto view = mwperf::audited_romr_view(fixture.temporal.framework);
  REQUIRE(view);

  const auto outside =
      mwperf::testing::c17::reduced_state(
          fixture.temporal.ordered_targets, {4U}, false, 0U);
  auto rejected = mwperf::begin_residence(view.value(), outside);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c20.event_entry_outside_domain");

  // Entry validation occurs before any bank is supplied or stream can be
  // consumed.  A valid entry remains cold and starts at version/offset zero.
  const auto inside = fixture.temporal.initial_state;
  auto accepted = mwperf::begin_residence(view.value(), inside);
  REQUIRE(accepted);
  CHECK(accepted.value().lifecycle() == mwperf::ResidenceLifecycleV1::open);
  CHECK(accepted.value().offset() == mwperf::BigNat{0U});
  CHECK(accepted.value().version() == mwperf::BigNat{0U});
  CHECK(accepted.value().edges().empty());

  auto wrong_codec = inside;
  wrong_codec.codec = {"c20.fixture.foreign-state", 1U};
  auto codec_rejected = mwperf::begin_residence(view.value(), wrong_codec);
  REQUIRE_FALSE(codec_rejected);
  CHECK(codec_rejected.error().code == "c20.event_entry_codec_mismatch");
}

}  // namespace
