#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <limits>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/certificates/transfer_bounds.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

[[nodiscard]] mwperf::Digest256 digest(const std::string_view text) {
  auto value = mwperf::sha256(std::as_bytes(
      std::span<const char>(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object(
    const std::string_view text) {
  auto label = mwperf::TypedLabel::text(std::string(text));
  REQUIRE(label);
  return {std::move(label).value(), digest(text)};
}

template <typename Source>
concept FiniteTransferSource = requires(const Source& source,
                                        const mwperf::Horizon& horizon) {
  { mwperf::compute_finite_horizon_tv_transfer(source, horizon) } ->
      std::same_as<mwperf::Result<mwperf::ErrorBound>>;
};

template <typename Source>
concept ContractionSource = requires(
    const mwperf::RowErrorBound& row, const Source& source,
    const mwperf::MetricGeometry& geometry) {
  { mwperf::compute_contraction_transfer(row, source, geometry) } ->
      std::same_as<mwperf::Result<mwperf::ErrorBound>>;
};

template <typename Source>
concept ResolventSource = requires(const mwperf::KilledKernelPair& kernels,
                                   const Source& source) {
  { mwperf::compute_stopped_resolvent_transfer(kernels, source) } ->
      std::same_as<mwperf::Result<mwperf::ErrorBound>>;
};

template <typename Source>
concept DriftSource = requires(
    const Source& source,
    const mwperf::AuditedCompiledFramework& framework) {
  { mwperf::validate_drift_stability_witness(source, framework) } ->
      std::same_as<mwperf::Result<mwperf::StabilityCertificate>>;
};

template <typename Source>
concept EnvelopeSource = requires(
    const Source& source, const mwperf::CertificateArrivalLaw& arrival,
    const mwperf::MetricRequest& request) {
  { mwperf::evaluate_response_envelope(source, arrival, request) } ->
      std::same_as<mwperf::Result<mwperf::MetricInterval>>;
};

static_assert(!std::default_initializable<mwperf::ValidatedCertificates>);
static_assert(!std::default_initializable<mwperf::RowErrorBound>);
static_assert(!std::default_initializable<mwperf::ContractionWitness>);
static_assert(!std::default_initializable<mwperf::KilledKernelPair>);
static_assert(!std::default_initializable<mwperf::ResolventWitness>);
static_assert(!std::default_initializable<mwperf::DriftWitness>);
static_assert(!std::default_initializable<mwperf::ResponseEnvelope>);
static_assert(!std::default_initializable<mwperf::CertificateArrivalLaw>);

static_assert(FiniteTransferSource<mwperf::RowErrorBound>);
static_assert(!FiniteTransferSource<mwperf::RowErrorEvidenceV1>);
static_assert(!FiniteTransferSource<mwperf::KernelAccess>);
static_assert(ContractionSource<mwperf::ContractionWitness>);
static_assert(!ContractionSource<mwperf::ContractionEvidenceV1>);
static_assert(ResolventSource<mwperf::ResolventWitness>);
static_assert(!ResolventSource<mwperf::ResolventEvidenceV1>);
static_assert(DriftSource<mwperf::DriftWitness>);
static_assert(!DriftSource<mwperf::DriftWitnessEvidenceV1>);
static_assert(EnvelopeSource<mwperf::ResponseEnvelope>);
static_assert(!EnvelopeSource<mwperf::ResponseEnvelopeCertificateEvidenceV1>);

struct BoundFixture final {
  mwperf::testing::c17::ThreeBinFrameworkV1 carrier;
  mwperf::Evidence evidence;
};

[[nodiscard]] BoundFixture v0_fixture() {
  auto carrier =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto evidence = mwperf::Evidence::bind(carrier.framework, {});
  REQUIRE(evidence);
  return {std::move(carrier), std::move(evidence).value()};
}

[[nodiscard]] mwperf::V1GeometryEvidenceV1 v1_node(
    const mwperf::Evidence& bound,
    const mwperf::CertificateEvidenceIdV1& id,
    const mwperf::CertificateEvidenceIdV1& premise) {
  return {
      id,
      mwperf::CodecIdentityV1{"mwperf.c25.v1-geometry-witness", 1U},
      bound.framework_bindings().problem_fingerprints.resolved_instance,
      digest("c25.fixture.subject-product"),
      digest("c25.fixture.subject-law"),
      digest("c25.fixture.compatibility-relation"),
      digest("c25.fixture.lifting-kernel"),
      digest("c25.fixture.physical-state-schema"),
      bound.framework_bindings().reduced_state_schema_digest,
      digest("c25.fixture.complete-decision-mark"),
      mwperf::CertificateCoverageV1::global_declared_domain,
      true,
      true,
      true,
      true,
      {premise}};
}

[[nodiscard]] mwperf::V2DynamicLiftEvidenceV1 v2_node(
    const mwperf::Evidence& bound,
    const mwperf::CertificateEvidenceIdV1& id,
    const mwperf::CertificateEvidenceIdV1& v1,
    const mwperf::CertificateEvidenceIdV1& premise,
    const bool include_initial_law = true) {
  return {
      id,
      mwperf::CodecIdentityV1{"mwperf.c25.v2-dynamic-lift-witness", 1U},
      bound.framework_bindings().problem_fingerprints.resolved_instance,
      digest("c25.fixture.subject-product"),
      digest("c25.fixture.subject-law"),
      digest("c25.fixture.compatibility-relation"),
      digest("c25.fixture.lifting-kernel"),
      digest("c25.fixture.complete-decision-mark"),
      bound.framework_bindings().problem_fingerprints.compiled_arrival,
      mwperf::CertificateCoverageV1::global_declared_domain,
      true,
      true,
      include_initial_law
          ? std::optional<mwperf::Digest256>{
                digest("c25.fixture.lifted-initial-law")}
          : std::nullopt,
      include_initial_law,
      {v1, premise}};
}

[[nodiscard]] mwperf::CertificatePremiseEvidenceV1 premise_node(
    const std::string_view id,
    const mwperf::CertificateClaimKindV1 supported_claim,
    const mwperf::Digest256& product = digest("c25.fixture.subject-product"),
    const mwperf::Digest256& law = digest("c25.fixture.subject-law")) {
  return {
      .evidence_id = object(id),
      .supported_claim = supported_claim,
      .subject_product_identity = product,
      .subject_law_identity = law,
      .premise_identity = digest(std::string(id) + ".premise"),
      .provenance_identity = object(std::string(id) + ".provenance"),
      .coverage = mwperf::CertificateCoverageV1::global_declared_domain,
      .origin = mwperf::CertificateEvidenceOriginV1::independent_a_priori,
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::ComplexityCostEvidenceV1 complexity_node(
    const std::string_view id,
    const mwperf::ComplexityCostCategoryV1 category,
    const mwperf::ComplexityCostUnitV1 unit, const long double amount) {
  return {
      .evidence_id = object(id),
      .category = category,
      .amount = amount,
      .unit = unit,
      .convention = "inclusive count for the exact bound artifact",
      .subject_product_identity = digest("c25.fixture.subject-product"),
      .subject_law_identity = digest("c25.fixture.subject-law"),
      .provenance_identity = object(std::string(id) + ".provenance"),
      .coverage = mwperf::CertificateCoverageV1::global_declared_domain,
      .origin = mwperf::CertificateEvidenceOriginV1::provider_report,
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::ScopedCertificateRecordEvidenceV1 scoped_node(
    const std::string_view id, const mwperf::CertificateClaimKindV1 kind,
    std::vector<mwperf::CertificateEvidenceIdV1> dependencies = {}) {
  return {object(id),
          kind,
          digest("c25.fixture.subject-product"),
          digest("c25.fixture.subject-law"),
          digest(std::string(id) + ".statement"),
          mwperf::CertificateCoverageV1::global_declared_domain,
          mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          std::move(dependencies)};
}

[[nodiscard]] mwperf::ValidatedCertificates validate(
    const mwperf::AuditedCompiledFramework& framework,
    const mwperf::Evidence& evidence, mwperf::CertificateBundle bundle) {
  auto result = mwperf::validate_certificate_bundle(
      bundle, framework, evidence);
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C25 a V0-only bundle remains executable without stronger claims",
          "[c25][unit][certificate][v0-only]") {
  auto fixture = v0_fixture();
  auto bundle = mwperf::CertificateBundle::v0_only(fixture.evidence);
  auto validated = validate(fixture.carrier.framework, fixture.evidence,
                            std::move(bundle));

  REQUIRE(validated.v0_report().passed());
  CHECK(validated.graph_digest() == fixture.evidence.graph_digest());
  CHECK(validated.v1_geometry().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.stationary_integrated_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.physical_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.stability().state ==
        mwperf::CertificateClaimStateV1::not_established);
}

TEST_CASE("C25 evidence graph digest is canonical under node permutation",
          "[c25][unit][certificate][canonical-evidence]") {
  auto fixture = v0_fixture();
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      scoped_node("c25.fixture.numeric", mwperf::CertificateClaimKindV1::numerics),
      complexity_node("c25.fixture.complexity",
                      mwperf::ComplexityCostCategoryV1::construction,
                      mwperf::ComplexityCostUnitV1::wall_clock_seconds,
                      1.0L),
      scoped_node("c25.fixture.validation",
                  mwperf::CertificateClaimKindV1::validation),
      scoped_node("c25.fixture.provenance",
                  mwperf::CertificateClaimKindV1::provenance)};
  auto first = mwperf::Evidence::canonical_graph_digest(nodes);
  REQUIRE(first);
  std::reverse(nodes.begin(), nodes.end());
  auto reversed = mwperf::Evidence::canonical_graph_digest(nodes);
  REQUIRE(reversed);
  CHECK(first.value() == reversed.value());
}

TEST_CASE("C25 V1 geometry remains independent of stronger claims",
          "[c25][unit][certificate][independent-claims]") {
  auto fixture = v0_fixture();
  const auto v1_id = object("c25.fixture.v1");
  const auto premise_id = object("c25.fixture.v1.premise");
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      premise_node("c25.fixture.v1.premise",
                   mwperf::CertificateClaimKindV1::v1_fibre_geometry),
      v1_node(fixture.evidence, v1_id, premise_id)};
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.v1_geometry = v1_id;

  auto validated = validate(fixture.carrier.framework, evidence.value(),
                            std::move(bundle));
  CHECK(validated.v1_geometry().state ==
        mwperf::CertificateClaimStateV1::established);
  CHECK(validated.v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.stationary_integrated_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.physical_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
}

TEST_CASE("C25 complete V2 evidence establishes only its dynamic-lift claim",
          "[c25][unit][certificate][v2]") {
  auto fixture = v0_fixture();
  const auto v1_id = object("c25.fixture.v1");
  const auto v2_id = object("c25.fixture.v2");
  const auto v1_premise_id = object("c25.fixture.v1.premise");
  const auto v2_premise_id = object("c25.fixture.v2.premise");
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      premise_node("c25.fixture.v1.premise",
                   mwperf::CertificateClaimKindV1::v1_fibre_geometry),
      premise_node("c25.fixture.v2.premise",
                   mwperf::CertificateClaimKindV1::v2_dynamic_lift),
      v1_node(fixture.evidence, v1_id, v1_premise_id),
      v2_node(fixture.evidence, v2_id, v1_id, v2_premise_id)};
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.v1_geometry = v1_id;
  bundle.v2_dynamic_lift = v2_id;
  auto validated = validate(fixture.carrier.framework, evidence.value(),
                            std::move(bundle));
  CHECK(validated.v1_geometry().state ==
        mwperf::CertificateClaimStateV1::established);
  CHECK(validated.v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::established);
  CHECK(validated.stationary_integrated_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
}

TEST_CASE("C25 stronger claims require exact typed premise dependencies",
          "[c25][unit][certificate][typed-premises]") {
  auto fixture = v0_fixture();
  const auto v1_id = object("c25.fixture.premised-v1");
  const auto v2_id = object("c25.fixture.premised-v2");
  const auto v1_premise_id = object("c25.fixture.premised-v1.premise");
  const auto v2_premise_id = object("c25.fixture.premised-v2.premise");

  auto v2_without_premise =
      v2_node(fixture.evidence, v2_id, v1_id, v2_premise_id);
  v2_without_premise.dependencies = {v1_id};
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      premise_node("c25.fixture.premised-v1.premise",
                   mwperf::CertificateClaimKindV1::v1_fibre_geometry),
      premise_node("c25.fixture.premised-v2.premise",
                   mwperf::CertificateClaimKindV1::v2_dynamic_lift),
      v1_node(fixture.evidence, v1_id, v1_premise_id),
      std::move(v2_without_premise)};
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.v1_geometry = v1_id;
  bundle.v2_dynamic_lift = v2_id;
  auto validated = validate(fixture.carrier.framework, evidence.value(),
                            std::move(bundle));

  CHECK(validated.v1_geometry().state ==
        mwperf::CertificateClaimStateV1::established);
  CHECK(validated.v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK_FALSE(validated.v2_dynamic_lift().diagnostics.empty());
  CHECK(std::ranges::find(validated.v2_dynamic_lift().dependency_closure,
                          v2_premise_id) ==
        validated.v2_dynamic_lift().dependency_closure.end());
}

TEST_CASE("C25 complexity costs retain every closed category separately",
          "[c25][unit][certificate][complexity]") {
  auto fixture = v0_fixture();
  constexpr std::array categories{
      mwperf::ComplexityCostCategoryV1::construction,
      mwperf::ComplexityCostCategoryV1::calibration,
      mwperf::ComplexityCostCategoryV1::representation,
      mwperf::ComplexityCostCategoryV1::surrogate_solve,
      mwperf::ComplexityCostCategoryV1::optimizer_calls,
      mwperf::ComplexityCostCategoryV1::storage,
      mwperf::ComplexityCostCategoryV1::trace_warmup_and_dependence,
      mwperf::ComplexityCostCategoryV1::proposal_generation,
      mwperf::ComplexityCostCategoryV1::tail_proof,
      mwperf::ComplexityCostCategoryV1::certificate_evaluation};
  constexpr std::array units{
      mwperf::ComplexityCostUnitV1::wall_clock_seconds,
      mwperf::ComplexityCostUnitV1::cpu_seconds,
      mwperf::ComplexityCostUnitV1::scalar_coefficients,
      mwperf::ComplexityCostUnitV1::wall_clock_seconds,
      mwperf::ComplexityCostUnitV1::calls,
      mwperf::ComplexityCostUnitV1::bytes,
      mwperf::ComplexityCostUnitV1::samples,
      mwperf::ComplexityCostUnitV1::dimensionless_work_units,
      mwperf::ComplexityCostUnitV1::cpu_seconds,
      mwperf::ComplexityCostUnitV1::wall_clock_seconds};

  std::vector<mwperf::CertificateEvidenceNodeV1> nodes;
  std::vector<mwperf::CertificateEvidenceIdV1> ids;
  for (std::size_t index = 0; index < categories.size(); ++index) {
    const std::string name = "c25.fixture.cost." + std::to_string(index);
    ids.push_back(object(name));
    const long double amount =
        (categories[index] ==
             mwperf::ComplexityCostCategoryV1::surrogate_solve ||
         categories[index] ==
             mwperf::ComplexityCostCategoryV1::certificate_evaluation)
            ? 7.0L
            : static_cast<long double>(index);
    nodes.emplace_back(complexity_node(name, categories[index], units[index],
                                       amount));
  }
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.complexity = ids;
  auto validated = validate(fixture.carrier.framework, evidence.value(),
                            std::move(bundle));
  const auto round_trip = validated.complexity_costs();
  REQUIRE(round_trip.size() == categories.size());
  for (std::size_t index = 0; index < round_trip.size(); ++index) {
    CHECK(round_trip[index].category == categories[index]);
    CHECK(round_trip[index].unit == units[index]);
    CHECK_FALSE(round_trip[index].convention.empty());
    CHECK(round_trip[index].evidence_id == ids[index]);
  }
  CHECK(round_trip[3].amount == round_trip[9].amount);
  CHECK(round_trip[3].category != round_trip[9].category);
}

TEST_CASE("C25 rejects malformed quantitative complexity evidence",
          "[c25][negative][certificate][complexity]") {
  auto fixture = v0_fixture();
  auto cost = complexity_node(
      "c25.fixture.bad-cost", mwperf::ComplexityCostCategoryV1::storage,
      mwperf::ComplexityCostUnitV1::bytes, 1.0L);
  const auto id = cost.evidence_id;

  SECTION("non-finite amount") {
    cost.amount = std::numeric_limits<long double>::infinity();
    auto evidence = mwperf::Evidence::bind(
        fixture.carrier.framework,
        std::vector<mwperf::CertificateEvidenceNodeV1>{cost});
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.complexity = {id};
    const auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.carrier.framework, evidence.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.invalid_complexity_cost_amount");
  }

  SECTION("missing convention") {
    cost.convention.clear();
    auto evidence = mwperf::Evidence::bind(
        fixture.carrier.framework,
        std::vector<mwperf::CertificateEvidenceNodeV1>{cost});
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.complexity = {id};
    const auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.carrier.framework, evidence.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c25.complexity_cost_convention_missing");
  }
}

TEST_CASE("C25 rejects dangling and cyclic certificate evidence",
          "[c25][negative][certificate][evidence-graph]") {
  SECTION("dangling claim reference") {
    auto fixture = v0_fixture();
    auto bundle = mwperf::CertificateBundle::v0_only(fixture.evidence);
    bundle.v1_geometry = object("c25.fixture.missing-v1");
    const auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.carrier.framework, fixture.evidence);
    REQUIRE_FALSE(rejected);
  }

  SECTION("dependency cycle") {
    auto fixture = v0_fixture();
    const auto first_id = object("c25.fixture.cycle.first");
    const auto second_id = object("c25.fixture.cycle.second");
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
        scoped_node("c25.fixture.cycle.first",
                    mwperf::CertificateClaimKindV1::validation,
                    {second_id}),
        scoped_node("c25.fixture.cycle.second",
                    mwperf::CertificateClaimKindV1::provenance,
                    {first_id})};
    auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                           std::move(nodes));
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.validation = {first_id};
    bundle.provenance = {second_id};
    const auto rejected = mwperf::validate_certificate_bundle(
        bundle, fixture.carrier.framework, evidence.value());
    REQUIRE_FALSE(rejected);
  }
}

TEST_CASE("C25 rejects a V2 path claim without its lifted initial law",
          "[c25][negative][certificate][v2-initial-law]") {
  auto fixture = v0_fixture();
  const auto v1_id = object("c25.fixture.v1");
  const auto v2_id = object("c25.fixture.v2.missing-initial");
  const auto v1_premise_id = object("c25.fixture.v1.premise");
  const auto v2_premise_id = object("c25.fixture.v2.premise");
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      premise_node("c25.fixture.v1.premise",
                   mwperf::CertificateClaimKindV1::v1_fibre_geometry),
      premise_node("c25.fixture.v2.premise",
                   mwperf::CertificateClaimKindV1::v2_dynamic_lift),
      v1_node(fixture.evidence, v1_id, v1_premise_id),
      v2_node(fixture.evidence, v2_id, v1_id, v2_premise_id, false)};
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.v1_geometry = v1_id;
  bundle.v2_dynamic_lift = v2_id;
  const auto rejected = mwperf::validate_certificate_bundle(
      bundle, fixture.carrier.framework, evidence.value());
  REQUIRE_FALSE(rejected);
}

TEST_CASE("C25 evidence is bound to one exact V0 carrier",
          "[c25][negative][certificate][cross-framework]") {
  auto first = v0_fixture();
  auto second_carrier =
      mwperf::testing::c17::make_positive_underflow_three_bin_framework();
  auto bundle = mwperf::CertificateBundle::v0_only(first.evidence);
  const auto rejected = mwperf::validate_certificate_bundle(
      bundle, second_carrier.framework, first.evidence);
  REQUIRE_FALSE(rejected);
}

TEST_CASE("C25 validation evidence never upgrades physical fidelity",
          "[c25][negative][certificate][physical-firewall]") {
  auto fixture = v0_fixture();
  const auto validation_id = object("c25.fixture.validation-only");
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      scoped_node("c25.fixture.validation-only",
                  mwperf::CertificateClaimKindV1::validation)};
  auto evidence = mwperf::Evidence::bind(fixture.carrier.framework,
                                         std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.validation = {validation_id};

  auto validated = validate(fixture.carrier.framework, evidence.value(),
                            std::move(bundle));
  const auto found = std::ranges::find_if(
      validated.claims(), [](const mwperf::ValidatedClaimV1& claim) {
        return claim.kind == mwperf::CertificateClaimKindV1::validation;
      });
  REQUIRE(found != validated.claims().end());
  CHECK(found->state == mwperf::CertificateClaimStateV1::established);
  CHECK(validated.physical_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
}

namespace {

[[nodiscard]] mwperf::MetricRequest temporal_metric_request(
    const mwperf::QueueCatalog& queues, const std::uint64_t order) {
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"c25-same-id","kind":"stationary_backlog_moment",
                "parameters":{"order":)json") +
      std::to_string(order) + R"json(}}],
    "surrogate":{"id":"c25.test","version":"1.0.0","parameters":{}},
    "resolution":{"level":{"max_states":128,"max_row_atoms":256},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":32},
      "optimizer":{"max_calls":64,"max_search_states_per_call":256},
      "sampling":{"max_generator_draws":1024},
      "tolerance":{"linear_residual_abs":1e-12,
                   "integration_abs":1e-12,"tail_abs":1e-12,
                   "fixed_point_abs":1e-12}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}}
  })json";
  auto document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c25-temporal-request", analysis));
  REQUIRE(document);
  auto spec = mwperf::parse_analysis_spec_v1(document.value());
  REQUIRE(spec);
  auto request =
      mwperf::parse_metric_request(spec.value().metrics.front(), queues);
  REQUIRE(request);
  return std::move(request).value();
}

[[nodiscard]] mwperf::Digest256 request_digest(
    const mwperf::MetricRequest& request) {
  auto value = mwperf::canonical_metric_requirements_digest(
      mwperf::requirements_for_metric(request));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ScopedCertificateRecordEvidenceV1 exact_record(
    const mwperf::CertificateEvidenceIdV1& id,
    const mwperf::Digest256& product, const mwperf::Digest256& law) {
  return {.evidence_id = id,
          .kind = mwperf::CertificateClaimKindV1::validation,
          .subject_product_identity = product,
          .subject_law_identity = law,
          .statement_identity = digest("c25.fixture.exact-record.statement"),
          .coverage =
              mwperf::CertificateCoverageV1::global_declared_domain,
          .origin =
              mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          .dependencies = {}};
}

[[nodiscard]] mwperf::ResponseEnvelopeCertificateEvidenceV1
temporal_envelope_node(
    const mwperf::Evidence& bound, const mwperf::QueueId& target,
    const mwperf::MetricRequest& request,
    const mwperf::CertificateEvidenceIdV1& backend_dependency) {
  const auto subject = digest("c25.fixture.temporal.subject-product");
  const auto subject_law = digest("c25.fixture.temporal.subject-law");
  const auto slow = digest("c25.fixture.temporal.slow-product");
  const auto slow_law = digest("c25.fixture.temporal.slow-law");
  const auto fast = digest("c25.fixture.temporal.fast-product");
  const auto fast_law = digest("c25.fixture.temporal.fast-law");
  return {
      .evidence_id = object("c25.fixture.temporal.envelope"),
      .framework_fingerprint =
          bound.framework_bindings().problem_fingerprints.resolved_instance,
      .configured_arrival_identity =
          bound.framework_bindings().problem_fingerprints.compiled_arrival,
      .target = target,
      .subject_product_identity = subject,
      .subject_law_identity = subject_law,
      .slow_product_identity = slow,
      .fast_product_identity = fast,
      .subject_product =
          {.identity = subject,
           .stage = mwperf::ResponseProductStageV1::recoded_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = subject_law,
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .slow_product =
          {.identity = slow,
           .stage = mwperf::ResponseProductStageV1::raw_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = slow_law,
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .fast_product =
          {.identity = fast,
           .stage = mwperf::ResponseProductStageV1::raw_response,
           .raw_value_status = mwperf::RawValueStatusV1::exact_point,
           .law_identity = fast_law,
           .designated_deployed_point = true,
           .validated_cross_product_transfer = false,
           .transfer_evidence = std::nullopt},
      .mu_minus = {0.55L, 0.55L, 0.60L},
      .mu_point = {0.70L, 0.70L, 0.70L},
      .mu_plus = {0.85L, 0.85L, 0.85L},
      .pointwise_order_independently_certified = true,
      .arrival_semantics =
          mwperf::EnvelopeArrivalSemanticsV1::temporal_augmented,
      .requested_route = mwperf::EnvelopeClosureRouteV1::temporal_backend,
      .iid_target_marginal = {},
      .lambda = 0.0L,
      .arrival_second_moment = 0.0L,
      .arrival_second_moment_finite = false,
      .closure = {.established = false,
                  .boundary = 1U,
                  .initial_support = {0U},
                  .selected_accessible_class = {},
                  .bound_slow_product_identity = slow,
                  .exact_reachability = false,
                  .unique_reachable_closed_class = false},
      .tail = {.boundary_order_certified = false,
               .tail_order_certified = false,
               .finite_second_moment = false},
      .temporal_backend =
          mwperf::TemporalEnvelopeBackendEvidenceV1{
              .accepted = true,
              .evidence_dependency = backend_dependency,
              .accepted_contract_digest =
                  bound.framework_bindings().accepted_contract_digest,
              .backend_identity = digest("c25.fixture.temporal.backend"),
              .theorem_identity = digest("c25.fixture.temporal.theorem"),
              .configured_arrival_identity =
                  bound.framework_bindings()
                      .problem_fingerprints.compiled_arrival,
              .slow_product_identity = slow,
              .fast_product_identity = fast,
              .metric_intervals =
                  {{.metric_kind = mwperf::metric_request_kind(request),
                    .metric_id =
                        mwperf::metric_request_header(request).metric_id,
                    .normalized_request_digest = request_digest(request),
                    .lower_status = mwperf::BoundValueStatusV1::finite,
                    .lower = 2.0L,
                    .upper_status = mwperf::BoundValueStatusV1::finite,
                    .upper = 5.0L}},
              .common_arrival_phase_coupling = true,
              .service_independent_phase = true,
              .invariant_exists = true,
              .convergence_established = true},
      .stationary_existence_convergence = true,
      .little_lossless = false,
      .little_unit_packets = false,
      .little_eventual_departure = false,
      .little_positive_finite_intensity = false,
      .little_finite_backlog_first_moment = false,
      .little_law = false,
      .dependencies = {backend_dependency},
  };
}

[[nodiscard]] mwperf::EnvelopeResponseProductTransferEvidenceV1
response_bridge(
    const mwperf::CertificateEvidenceIdV1& source_evidence,
    const mwperf::ArtifactObjectReferenceV1& source_reference,
    const mwperf::Digest256& source_law,
    const mwperf::CertificateEvidenceIdV1& transfer_premise,
    const mwperf::CertificateEvidenceIdV1& bridge_id,
    const mwperf::Digest256& destination_product,
    const mwperf::Digest256& destination_law) {
  return {
      .evidence_id = bridge_id,
      .source_evidence = source_evidence,
      .source_reference = source_reference,
      .source_product_identity = source_reference.object_digest,
      .source_stage = mwperf::ResponseProductStageV1::raw_response,
      .source_value_status = mwperf::RawValueStatusV1::interval_only,
      .source_law_identity = source_law,
      .destination_product_identity = destination_product,
      .destination_stage = mwperf::ResponseProductStageV1::recoded_response,
      .destination_value_status = mwperf::RawValueStatusV1::exact_point,
      .destination_law_identity = destination_law,
      .theorem_or_map_identity = digest("c25.fixture.bridge.map"),
      .direction =
          mwperf::ResponseProductTransferDirectionV1::source_to_destination,
      .coefficient_intervals =
          {{{mwperf::ThreeBinCoefficientV1::one, 0.60L, 0.80L, 0.65L,
             0.75L},
            {mwperf::ThreeBinCoefficientV1::two, 0.60L, 0.80L, 0.65L,
             0.75L},
            {mwperf::ThreeBinCoefficientV1::tail_from_three, 0.60L, 0.80L,
             0.65L, 0.75L}}},
      .assumptions = {"validated deterministic coefficient-map image"},
      .direction_and_assumptions_validated = true,
      .destination_is_designated_deployed_point = true,
      .dependencies = {source_evidence, transfer_premise},
  };
}

[[nodiscard]] mwperf::Result<mwperf::ValidatedCertificates>
validate_envelope_nodes(
    const mwperf::AuditedCompiledFramework& framework,
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes,
    const mwperf::CertificateEvidenceIdV1& envelope_id) {
  auto evidence = mwperf::Evidence::bind(framework, std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.response_envelopes = {envelope_id};
  return mwperf::validate_certificate_bundle(bundle, framework,
                                              evidence.value());
}

}  // namespace

TEST_CASE("C25 temporal backend binds contract evidence and full request",
          "[c25][unit][negative][certificate][temporal-binding]") {
  SECTION("accepted contract mismatch") {
    auto fixture = v0_fixture();
    const auto request =
        temporal_metric_request(fixture.carrier.instance.queues(), 1U);
    const auto dependency = object("c25.fixture.temporal.backend-proof");
    auto envelope = temporal_envelope_node(
        fixture.evidence, fixture.carrier.ordered_targets.front(), request,
        dependency);
    const auto envelope_id = envelope.evidence_id;
    envelope.temporal_backend->accepted_contract_digest =
        digest("c25.fixture.foreign-contract");
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
        premise_node("c25.fixture.temporal.backend-proof",
                     mwperf::CertificateClaimKindV1::response_envelope,
                     envelope.subject_product_identity,
                     envelope.subject_law_identity),
        std::move(envelope)};
    const auto rejected = validate_envelope_nodes(
        fixture.carrier.framework, std::move(nodes), envelope_id);
    REQUIRE_FALSE(rejected);
  }

  SECTION("missing backend dependency") {
    auto fixture = v0_fixture();
    const auto request =
        temporal_metric_request(fixture.carrier.instance.queues(), 1U);
    const auto dependency = object("c25.fixture.temporal.missing-proof");
    auto envelope = temporal_envelope_node(
        fixture.evidence, fixture.carrier.ordered_targets.front(), request,
        dependency);
    const auto envelope_id = envelope.evidence_id;
    envelope.dependencies.clear();
    const auto rejected = validate_envelope_nodes(
        fixture.carrier.framework, {std::move(envelope)}, envelope_id);
    REQUIRE_FALSE(rejected);
  }

  SECTION("same id and kind with different parameters is unavailable") {
    auto fixture = v0_fixture();
    const auto order_one =
        temporal_metric_request(fixture.carrier.instance.queues(), 1U);
    const auto order_two =
        temporal_metric_request(fixture.carrier.instance.queues(), 2U);
    REQUIRE(mwperf::metric_request_kind(order_one) ==
            mwperf::metric_request_kind(order_two));
    REQUIRE(mwperf::metric_request_header(order_one).metric_id ==
            mwperf::metric_request_header(order_two).metric_id);
    REQUIRE_FALSE(request_digest(order_one) == request_digest(order_two));

    const auto dependency = object("c25.fixture.temporal.backend-proof");
    auto envelope = temporal_envelope_node(
        fixture.evidence, fixture.carrier.ordered_targets.front(), order_one,
        dependency);
    const auto envelope_id = envelope.evidence_id;
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
        premise_node("c25.fixture.temporal.backend-proof",
                     mwperf::CertificateClaimKindV1::response_envelope,
                     envelope.subject_product_identity,
                     envelope.subject_law_identity),
        std::move(envelope)};
    auto evidence =
        mwperf::Evidence::bind(fixture.carrier.framework, std::move(nodes));
    REQUIRE(evidence);
    auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
    bundle.response_envelopes = {envelope_id};
    auto certificates = validate(fixture.carrier.framework, evidence.value(),
                                 std::move(bundle));
    auto view = certificates.response_envelope(envelope_id);
    auto arrival = certificates.certificate_arrival_law(envelope_id);
    REQUIRE(view);
    REQUIRE(arrival);
    const auto accepted = mwperf::evaluate_response_envelope(
        view.value(), arrival.value(), order_one);
    REQUIRE(accepted);
    CHECK(accepted.value().claim_state ==
          mwperf::CertificateClaimStateV1::established);
    const auto unavailable = mwperf::evaluate_response_envelope(
        view.value(), arrival.value(), order_two);
    REQUIRE(unavailable);
    CHECK(unavailable.value().claim_state ==
          mwperf::CertificateClaimStateV1::not_established);
  }
}

TEST_CASE("C25 response-product bridges require complete certified images",
          "[c25][unit][negative][certificate][product-bridge]") {
  const auto setup = [] {
    auto fixture = v0_fixture();
    const auto request =
        temporal_metric_request(fixture.carrier.instance.queues(), 1U);
    const auto unused_backend = object("c25.fixture.bridge.unused-backend");
    auto envelope = temporal_envelope_node(
        fixture.evidence, fixture.carrier.ordered_targets.front(), request,
        unused_backend);
    envelope.temporal_backend.reset();

    const auto source_reference = object("c25.fixture.bridge.raw-product");
    const auto source_law = digest("c25.fixture.bridge.raw-law");
    const auto source_evidence = object("c25.fixture.bridge.raw-evidence");
    const auto transfer_premise = object("c25.fixture.bridge.premise");
    const auto envelope_premise =
        object("c25.fixture.bridge.envelope-premise");
    const auto bridge_id = object("c25.fixture.bridge.transfer");
    auto bridge = response_bridge(
        source_evidence, source_reference, source_law, transfer_premise,
        bridge_id,
        envelope.subject_product.identity, envelope.subject_product.law_identity);
    envelope.subject_product.validated_cross_product_transfer = true;
    envelope.subject_product.transfer_evidence = bridge_id;
    envelope.dependencies = {bridge_id, envelope_premise};
    return std::tuple{
        std::move(fixture),
        exact_record(source_evidence, source_reference.object_digest,
                     source_law),
        premise_node("c25.fixture.bridge.premise",
                     mwperf::CertificateClaimKindV1::
                         response_product_transfer,
                     envelope.subject_product.identity,
                     envelope.subject_product.law_identity),
        premise_node("c25.fixture.bridge.envelope-premise",
                     mwperf::CertificateClaimKindV1::response_envelope,
                     envelope.subject_product.identity,
                     envelope.subject_product.law_identity),
        std::move(bridge), std::move(envelope)};
  };

  SECTION("valid typed bridge") {
    auto [fixture, source, premise, envelope_premise, bridge, envelope] =
        setup();
    const auto envelope_id = envelope.evidence_id;
    const auto bound = validate_envelope_nodes(
        fixture.carrier.framework,
        {std::move(source), std::move(premise),
         std::move(envelope_premise), std::move(bridge), std::move(envelope)},
        envelope_id);
    REQUIRE(bound);
  }

  SECTION("missing per-bin result") {
    auto [fixture, source, premise, envelope_premise, bridge, envelope] =
        setup();
    const auto envelope_id = envelope.evidence_id;
    bridge.coefficient_intervals[2].coefficient =
        mwperf::ThreeBinCoefficientV1::two;
    const auto rejected = validate_envelope_nodes(
        fixture.carrier.framework,
        {std::move(source), std::move(premise),
         std::move(envelope_premise), std::move(bridge), std::move(envelope)},
        envelope_id);
    REQUIRE_FALSE(rejected);
  }

  SECTION("result interval excludes deployed coefficient") {
    auto [fixture, source, premise, envelope_premise, bridge, envelope] =
        setup();
    const auto envelope_id = envelope.evidence_id;
    bridge.coefficient_intervals[0].result_lower = 0.10L;
    bridge.coefficient_intervals[0].result_upper = 0.20L;
    const auto rejected = validate_envelope_nodes(
        fixture.carrier.framework,
        {std::move(source), std::move(premise),
         std::move(envelope_premise), std::move(bridge), std::move(envelope)},
        envelope_id);
    REQUIRE_FALSE(rejected);
  }

  SECTION("source evidence does not match source product") {
    auto [fixture, source, premise, envelope_premise, bridge, envelope] =
        setup();
    const auto envelope_id = envelope.evidence_id;
    source.subject_product_identity = digest("c25.fixture.foreign-product");
    const auto rejected = validate_envelope_nodes(
        fixture.carrier.framework,
        {std::move(source), std::move(premise),
         std::move(envelope_premise), std::move(bridge), std::move(envelope)},
        envelope_id);
    REQUIRE_FALSE(rejected);
  }
}
