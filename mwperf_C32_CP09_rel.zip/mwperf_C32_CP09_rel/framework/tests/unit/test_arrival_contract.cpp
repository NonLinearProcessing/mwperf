#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/build_services.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace {

using ArrivalTransitionSignature = mwperf::Result<mwperf::ArrivalStep> (*)(
    mwperf::ArrivalProcess&, const mwperf::BigNat&);

template <typename... Arguments>
concept CanRequestArrivalStep = requires(Arguments&&... arguments) {
  mwperf::next_arrival_step(std::forward<Arguments>(arguments)...);
};

template <typename Service>
concept HasReplayOperation = requires(
    const Service& service, mwperf::AdjacentReplayRequest request) {
  service.replay(std::move(request));
};

template <typename Service>
concept HasUnitCubeOperation = requires(
    const Service& service, const mwperf::UnitCubeRequest& request) {
  service.evaluate(request);
};

static_assert(std::same_as<decltype(&mwperf::next_arrival_step),
                           ArrivalTransitionSignature>);
static_assert(CanRequestArrivalStep<mwperf::ArrivalProcess&,
                                   const mwperf::BigNat&>);
static_assert(!CanRequestArrivalStep<mwperf::ArrivalProcess&,
                                    const mwperf::BigNat&,
                                    const std::vector<mwperf::BigNat>&>);
static_assert(!HasReplayOperation<mwperf::BuilderArrivalServices>);
static_assert(HasReplayOperation<mwperf::AdjacentReplayService>);
static_assert(!HasUnitCubeOperation<mwperf::BuilderArrivalServices>);
static_assert(HasUnitCubeOperation<mwperf::UnitCubeArrivalService>);

static_assert(std::variant_size_v<mwperf::CompiledArrivalVariant> == 10U);
static_assert(std::same_as<
              std::variant_alternative_t<0U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledTraceArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<1U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledGlobalPeriodicArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<2U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledSourceDelayArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<3U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledMarkedRenewalArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<4U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledPrivateMarkovArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<5U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledSharedRoundArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<6U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledIidBernoulliArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<7U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledIidCountTableArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<8U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledIidPoissonArrivalLaw>);
static_assert(std::same_as<
              std::variant_alternative_t<9U, mwperf::CompiledArrivalVariant>,
              mwperf::CompiledIidMixedPoissonArrivalLaw>);

static_assert(std::variant_size_v<mwperf::ArrivalProcessVariant> == 10U);
static_assert(std::same_as<
              std::variant_alternative_t<0U, mwperf::ArrivalProcessVariant>,
              mwperf::TraceArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<1U, mwperf::ArrivalProcessVariant>,
              mwperf::GlobalPeriodicArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<2U, mwperf::ArrivalProcessVariant>,
              mwperf::SourceDelayArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<3U, mwperf::ArrivalProcessVariant>,
              mwperf::MarkedRenewalArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<4U, mwperf::ArrivalProcessVariant>,
              mwperf::PrivateMarkovArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<5U, mwperf::ArrivalProcessVariant>,
              mwperf::SharedRoundArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<6U, mwperf::ArrivalProcessVariant>,
              mwperf::IidBernoulliArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<7U, mwperf::ArrivalProcessVariant>,
              mwperf::IidCountTableArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<8U, mwperf::ArrivalProcessVariant>,
              mwperf::IidPoissonArrivalProcess>);
static_assert(std::same_as<
              std::variant_alternative_t<9U, mwperf::ArrivalProcessVariant>,
              mwperf::IidMixedPoissonArrivalProcess>);

static_assert(std::variant_size_v<mwperf::ArrivalPhase> == 10U);
static_assert(std::variant_size_v<mwperf::ArrivalInitialState> == 6U);
static_assert(
    std::same_as<std::variant_alternative_t<0U, mwperf::ArrivalPhase>,
                 mwperf::TraceArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<1U, mwperf::ArrivalPhase>,
                 mwperf::GlobalPeriodicArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<2U, mwperf::ArrivalPhase>,
                 mwperf::SourceDelayArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<3U, mwperf::ArrivalPhase>,
                 mwperf::MarkedRenewalArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<4U, mwperf::ArrivalPhase>,
                 mwperf::PrivateMarkovArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<5U, mwperf::ArrivalPhase>,
                 mwperf::SharedRoundArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<6U, mwperf::ArrivalPhase>,
                 mwperf::IidBernoulliArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<7U, mwperf::ArrivalPhase>,
                 mwperf::IidCountTableArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<8U, mwperf::ArrivalPhase>,
                 mwperf::IidPoissonArrivalPhase>);
static_assert(
    std::same_as<std::variant_alternative_t<9U, mwperf::ArrivalPhase>,
                 mwperf::IidMixedPoissonArrivalPhase>);

static_assert(std::is_copy_constructible_v<mwperf::CompiledArrivalLaw>);
static_assert(std::is_nothrow_move_constructible_v<mwperf::CompiledArrivalLaw>);
static_assert(!std::is_copy_constructible_v<mwperf::ArrivalProcess>);
static_assert(std::is_nothrow_move_constructible_v<mwperf::ArrivalProcess>);
static_assert(!std::is_copy_constructible_v<mwperf::ArrivalStreamKey>);
static_assert(!std::is_copy_constructible_v<mwperf::BuilderArrivalStreamKey>);
static_assert(std::is_copy_constructible_v<mwperf::BuilderArrivalView>);

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto result = mwperf::TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::AuthoredQueue authored_queue(
    const std::string& id, const std::size_t ordinal) {
  const std::string base = "/switch/queues/" + std::to_string(ordinal);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{mwperf::QueueId(text_label(id)),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<std::optional<mwperf::LegacyVoqCoordinate>>{
          std::nullopt, provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::QueueCatalog make_catalog() {
  std::vector<mwperf::AuthoredQueue> queues;
  queues.push_back(authored_queue("q0", 0U));
  queues.push_back(authored_queue("q1", 1U));
  queues.push_back(authored_queue("q2", 2U));
  mwperf::AuthoredSwitchConfig authored = mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          std::move(queues), provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
  auto catalog = mwperf::build_queue_catalog(authored);
  REQUIRE(catalog);
  return std::move(catalog).value();
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto result = mwperf::Digest256::from_hex(
      "000102030405060708090a0b0c0d0e0f"
      "101112131415161718191a1b1c1d1e1f");
  if (!result) {
    throw std::logic_error("invalid C09 fixture digest");
  }
  return std::move(result).value();
}

[[nodiscard]] mwperf::DeterministicRng fixture_rng(
    const mwperf::MasterSeed seed, const mwperf::StageTag stage,
    const std::uint64_t instance) {
  auto key = mwperf::make_physical_reference_instance_key(
      fixture_digest(), mwperf::BigNat(instance));
  if (!key) {
    throw std::logic_error("invalid C09 fixture instance key");
  }
  return mwperf::derive_rng_stream(seed, stage, key.value());
}

[[nodiscard]] mwperf::ArrivalInitialState shared_round_state(
    std::string state = "h0") {
  return mwperf::ArrivalInitialState(
      mwperf::SharedRoundState{std::move(state)});
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                              const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  if (!result) {
    throw std::logic_error("invalid C09 rational fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArrivalProcess make_process(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t seed,
    const std::uint64_t instance = 0U,
    mwperf::ArrivalInitialState state = shared_round_state()) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, fixture_rng(mwperf::MasterSeed(seed),
                       mwperf::StageTag::configured_arrival, instance));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, state, std::move(stream).value());
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::BuilderArrivalStreamKey make_builder_stream(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t seed,
    const std::uint64_t instance, const mwperf::StageTag stage) {
  auto stream = mwperf::make_builder_arrival_stream_key(
      law, stage, fixture_rng(mwperf::MasterSeed(seed), stage, instance));
  REQUIRE(stream);
  return std::move(stream).value();
}

[[nodiscard]] mwperf::NormalizedPmf two_atom_pmf() {
  const auto half = rational(1, 2);
  auto first = mwperf::AuthoredProbability::from_exact(half);
  auto second = mwperf::AuthoredProbability::from_exact(half);
  REQUIRE(first);
  REQUIRE(second);
  const std::array<mwperf::AuthoredProbability, 2U> authored{
      first.value(), second.value()};
  auto normalized = mwperf::validate_and_normalize_pmf(
      authored, mwperf::physical_pmf_tolerance());
  REQUIRE(normalized);
  return std::move(normalized).value();
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto result = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(result);
  return std::move(result).value();
}

void check_same_snapshot(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  CHECK(left.expected_slot == right.expected_slot);
  CHECK(left.phase_digest == right.phase_digest);
  CHECK(left.rng.rng_version() == right.rng.rng_version());
  CHECK(left.rng.stream_identity() == right.rng.stream_identity());
  CHECK(left.rng.state_words() == right.rng.state_words());
  CHECK(left.rng.consumed_words() == right.rng.consumed_words());
}

void check_same_step(const mwperf::ArrivalStep& left,
                     const mwperf::ArrivalStep& right) {
  CHECK(left.authored_slot == right.authored_slot);
  CHECK(left.physical_arrival_epoch() == right.physical_arrival_epoch());
  CHECK(left.batch == right.batch);
  CHECK(left.law_digest == right.law_digest);
  CHECK(left.realization_identity == right.realization_identity);
  CHECK(mwperf::arrival_phase_family(left.phase_before) ==
        mwperf::arrival_phase_family(right.phase_before));
  CHECK(mwperf::arrival_phase_family(left.phase_after) ==
        mwperf::arrival_phase_family(right.phase_after));
  CHECK(mwperf::arrival_phase_digest(left.phase_before) ==
        mwperf::arrival_phase_digest(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_after) ==
        mwperf::arrival_phase_digest(right.phase_after));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(left.phase_before),
      mwperf::arrival_phase_canonical_state(right.phase_before)));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(left.phase_after),
      mwperf::arrival_phase_canonical_state(right.phase_after)));
}

void check_same_replay(const mwperf::AdjacentReplayResult& left,
                       const mwperf::AdjacentReplayResult& right) {
  CHECK(left.view_digest == right.view_digest);
  CHECK(left.replay_identity == right.replay_identity);
  CHECK(left.status == right.status);
  CHECK(left.accounting.transitions == right.accounting.transitions);
  CHECK(left.accounting.rng_words == right.accounting.rng_words);
  REQUIRE(left.steps.size() == right.steps.size());
  for (std::size_t index = 0U; index < left.steps.size(); ++index) {
    check_same_step(left.steps[index], right.steps[index]);
  }
}

[[nodiscard]] std::pair<mwperf::BigNat, mwperf::BigNat> projected_pair(
    const mwperf::ArrivalBatch& batch, const mwperf::QueueCatalog& catalog,
    const mwperf::ArrivalBinding& binding) {
  auto first_index = catalog.index_at(0U);
  auto second_index = catalog.index_at(1U);
  REQUIRE(first_index);
  REQUIRE(second_index);
  auto first = mwperf::project_arrival_count(batch, first_index.value(),
                                             binding);
  auto second = mwperf::project_arrival_count(batch, second_index.value(),
                                              binding);
  REQUIRE(first);
  REQUIRE(second);
  return {std::move(first).value(), std::move(second).value()};
}

void check_correlated_pair(
    const std::pair<mwperf::BigNat, mwperf::BigNat>& values) {
  CHECK(((values.first == mwperf::BigNat(1U) &&
          values.second == mwperf::BigNat(4U)) ||
         (values.first == mwperf::BigNat(3U) &&
          values.second == mwperf::BigNat(2U))));
}

}  // namespace

TEST_CASE("C09 fixture cursors bind supplied streams and preserve one joint "
          "arrival draw",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  CHECK(law.value().family() ==
        mwperf::ArrivalFamily::shared_joint_round_markov_renewal);
  CHECK(law.value().variant().index() == 5U);

  auto same_a = make_process(law.value(), 1701U, 4U);
  auto same_b = make_process(law.value(), 1701U, 4U);
  auto different = make_process(law.value(), 1702U, 4U);

  const auto same_a_initial = snapshot(same_a);
  const auto same_b_initial = snapshot(same_b);
  const auto different_initial = snapshot(different);
  check_same_snapshot(same_a_initial, same_b_initial);
  CHECK(same_a_initial.rng.consumed_words() == mwperf::BigNat(0U));
  CHECK(different_initial.rng.consumed_words() == mwperf::BigNat(0U));
  CHECK_FALSE(same_a_initial.rng.stream_identity() ==
              different_initial.rng.stream_identity());

  auto step_a = mwperf::next_arrival_step(same_a, mwperf::BigNat(0U));
  auto step_b = mwperf::next_arrival_step(same_b, mwperf::BigNat(0U));
  REQUIRE(step_a);
  REQUIRE(step_b);
  check_same_step(step_a.value(), step_b.value());
  check_correlated_pair(projected_pair(
      step_a.value().batch, catalog, mwperf::arrival_law_binding(law.value())));
  CHECK(step_a.value().physical_arrival_epoch() == mwperf::BigNat(1U));
  CHECK(mwperf::arrival_phases_share_cursor(step_a.value().phase_before,
                                            step_a.value().phase_after));
  CHECK_FALSE(mwperf::arrival_phases_share_cursor(step_a.value().phase_before,
                                                  step_b.value().phase_before));

  const auto after_draw = snapshot(same_a);
  CHECK(after_draw.expected_slot == mwperf::BigNat(1U));
  CHECK(after_draw.rng.consumed_words() == mwperf::BigNat(1U));
  const auto before_projection = snapshot(same_a);
  check_correlated_pair(projected_pair(
      step_a.value().batch, catalog, mwperf::arrival_law_binding(law.value())));
  check_same_snapshot(before_projection, snapshot(same_a));
}

TEST_CASE("C09 fixture cursor accepts only authored slots zero one two",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  auto process = make_process(law.value(), 41U);

  const auto origin = snapshot(process);
  auto skipped_first =
      mwperf::next_arrival_step(process, mwperf::BigNat(1U));
  REQUIRE_FALSE(skipped_first);
  CHECK(skipped_first.error().code == "nonsequential_arrival_access");
  check_same_snapshot(origin, snapshot(process));

  auto zero = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  const auto after_zero = snapshot(process);

  auto repeated = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(repeated);
  CHECK(repeated.error().code == "nonsequential_arrival_access");
  check_same_snapshot(after_zero, snapshot(process));

  auto skipped = mwperf::next_arrival_step(process, mwperf::BigNat(2U));
  REQUIRE_FALSE(skipped);
  CHECK(skipped.error().code == "nonsequential_arrival_access");
  check_same_snapshot(after_zero, snapshot(process));

  auto one = mwperf::next_arrival_step(process, mwperf::BigNat(1U));
  REQUIRE(one);
  const auto after_one = snapshot(process);
  CHECK(after_one.expected_slot == mwperf::BigNat(2U));

  auto decreasing =
      mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(decreasing);
  CHECK(decreasing.error().code == "nonsequential_arrival_access");
  check_same_snapshot(after_one, snapshot(process));
}

TEST_CASE("C09 aggregation failure rolls back slot phase and supplied RNG",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::overflow_after_draw);
  REQUIRE(law);
  auto process = make_process(law.value(), 987U);
  const auto origin = snapshot(process);

  auto failed = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(failed);
  CHECK(failed.error().code == "arrival_count_overflow");
  check_same_snapshot(origin, snapshot(process));

  auto retry = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(retry);
  CHECK(retry.error().code == "arrival_count_overflow");
  check_same_snapshot(origin, snapshot(process));
}

TEST_CASE("C09 runtime adapter exceptions remain typed Result failures",
          "[c09][unit][negative][arrival][transaction]") {
  const mwperf::QueueCatalog catalog = make_catalog();

  auto throwing_initial = mwperf::testing::make_c09_correlated_fixture_law(
      catalog,
      mwperf::testing::FixtureFailureMode::throwing_initial_validator);
  REQUIRE(throwing_initial);
  auto configured_stream = mwperf::make_configured_arrival_stream_key(
      throwing_initial.value(),
      fixture_rng(mwperf::MasterSeed(4301U),
                  mwperf::StageTag::configured_arrival, 1U));
  REQUIRE(configured_stream);
  auto process = mwperf::instantiate_arrival_process(
      throwing_initial.value(), shared_round_state(),
      std::move(configured_stream).value());
  REQUIRE_FALSE(process);
  CHECK(process.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(process.error().code == "arrival_process_initialization_failure");

  auto throwing_cube = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::throwing_unit_cube);
  REQUIRE(throwing_cube);
  const auto view = mwperf::builder_arrival_view(throwing_cube.value());
  auto services =
      mwperf::make_builder_arrival_services(throwing_cube.value(), view);
  REQUIRE(services);
  REQUIRE(services.value().unit_cube_service().has_value());
  auto transition = services.value().unit_cube_service()->evaluate(
      mwperf::UnitCubeRequest{view.digest(), mwperf::BigNat(0U), std::nullopt,
                              {rational(1, 4)}});
  REQUIRE_FALSE(transition);
  CHECK(transition.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(transition.error().code == "arrival_unit_cube_invariant_failure");
}

TEST_CASE("C09 construction and projection reject cross-law bindings",
          "[c09][unit][negative][arrival][binding]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto baseline = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  auto phase_required = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::phase_required_unit_cube);
  REQUIRE(baseline);
  REQUIRE(phase_required);
  const auto baseline_view = mwperf::builder_arrival_view(baseline.value());
  const auto foreign_view =
      mwperf::builder_arrival_view(phase_required.value());
  CHECK_FALSE(baseline_view.digest() == foreign_view.digest());

  auto mismatched_services = mwperf::make_builder_arrival_services(
      baseline.value(), foreign_view);
  REQUIRE_FALSE(mismatched_services);
  CHECK(mismatched_services.error().code == "arrival_view_binding_mismatch");

  auto services =
      mwperf::make_builder_arrival_services(baseline.value(), baseline_view);
  REQUIRE(services);
  REQUIRE(services.value().replay_service().has_value());
  REQUIRE(services.value().unit_cube_service().has_value());
  auto foreign_stream = make_builder_stream(
      phase_required.value(), 4401U, 1U,
      mwperf::StageTag::surrogate_build_probe);
  auto replay_with_foreign_stream = services.value().replay_service()->replay(
      mwperf::AdjacentReplayRequest{
          baseline_view.digest(),
          mwperf::ExplicitReplayInitialState{shared_round_state()},
          mwperf::BigNat(0U), mwperf::BigNat(1U),
          std::move(foreign_stream), "foreign-stream"});
  REQUIRE_FALSE(replay_with_foreign_stream);
  CHECK(replay_with_foreign_stream.error().code ==
        "arrival_view_binding_mismatch");

  auto baseline_process = make_process(baseline.value(), 4402U, 2U);
  auto foreign_process = make_process(phase_required.value(), 4403U, 3U);
  auto baseline_step =
      mwperf::next_arrival_step(baseline_process, mwperf::BigNat(0U));
  auto foreign_step =
      mwperf::next_arrival_step(foreign_process, mwperf::BigNat(0U));
  REQUIRE(baseline_step);
  REQUIRE(foreign_step);

  auto replay_with_foreign_phase = services.value().replay_service()->replay(
      mwperf::AdjacentReplayRequest{
          baseline_view.digest(),
          mwperf::ExplicitReplayPhase{foreign_step.value().phase_after},
          mwperf::BigNat(1U), mwperf::BigNat(1U),
          make_builder_stream(baseline.value(), 4404U, 4U,
                              mwperf::StageTag::surrogate_build_probe),
          "foreign-phase"});
  REQUIRE_FALSE(replay_with_foreign_phase);
  CHECK(replay_with_foreign_phase.error().code ==
        "arrival_replay_phase_binding_mismatch");

  auto cube_with_foreign_view =
      services.value().unit_cube_service()->evaluate(mwperf::UnitCubeRequest{
          foreign_view.digest(), mwperf::BigNat(0U), std::nullopt,
          {rational(1, 4)}});
  REQUIRE_FALSE(cube_with_foreign_view);
  CHECK(cube_with_foreign_view.error().code ==
        "arrival_view_binding_mismatch");

  auto phase_services = mwperf::make_builder_arrival_services(
      phase_required.value(), foreign_view);
  REQUIRE(phase_services);
  REQUIRE(phase_services.value().unit_cube_service().has_value());
  auto cube_with_foreign_phase =
      phase_services.value().unit_cube_service()->evaluate(
          mwperf::UnitCubeRequest{foreign_view.digest(), mwperf::BigNat(0U),
                                  baseline_step.value().phase_before,
                                  {rational(1, 4)}});
  REQUIRE_FALSE(cube_with_foreign_phase);
  CHECK(cube_with_foreign_phase.error().code ==
        "arrival_unit_cube_phase_binding_mismatch");

  const auto first_queue = catalog.index_at(0U);
  REQUIRE(first_queue);
  auto projection = mwperf::project_arrival_count(
      baseline_step.value().batch, first_queue.value(),
      mwperf::arrival_law_binding(phase_required.value()));
  REQUIRE_FALSE(projection);
  CHECK(projection.error().code == "arrival_projection_binding_mismatch");
}

TEST_CASE("C09 fixture capability record and portable view make no implied "
          "claims",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);

  const auto capabilities = mwperf::arrival_capabilities(law.value());
  CHECK(capabilities.version == 1U);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::available);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::supplied);
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());
  REQUIRE(capabilities.adjacent_batch_replay.has_value());
  CHECK(capabilities.adjacent_batch_replay->explicit_initial_state);
  CHECK(capabilities.adjacent_batch_replay->explicit_phase);
  CHECK(capabilities.adjacent_batch_replay->normalized_initial_law);
  CHECK(capabilities.adjacent_batch_replay->named_stationary_initialization);
  CHECK(capabilities.adjacent_batch_replay->provision ==
        mwperf::AccessProvision::process_local_only);
  REQUIRE(capabilities.unit_cube_transform.has_value());
  CHECK(capabilities.unit_cube_transform->dimension == mwperf::BigNat(1U));
  CHECK(capabilities.unit_cube_transform->boundary ==
        mwperf::UnitCubeBoundary::left_closed_right_open);
  CHECK(capabilities.unit_cube_transform->phase_requirement ==
        mwperf::PhaseArgumentRequirement::phase_free);
  CHECK_FALSE(
      capabilities.exact_factorized_iid_generator.has_value());

  const auto support = mwperf::positive_arrival_support(law.value());
  REQUIRE(support.size() == catalog.size());
  auto q0 = catalog.index_at(0U);
  auto q1 = catalog.index_at(1U);
  auto q2 = catalog.index_at(2U);
  REQUIRE(q0);
  REQUIRE(q1);
  REQUIRE(q2);
  CHECK(support.at(q0.value()));
  CHECK(support.at(q1.value()));
  CHECK_FALSE(support.at(q2.value()));

  const auto view = mwperf::builder_arrival_view(law.value());
  const auto replayed_view = mwperf::builder_arrival_view(law.value());
  CHECK(view.version() == 1U);
  CHECK(view.binding() == mwperf::arrival_law_binding(law.value()));
  CHECK(view.capabilities() == capabilities);
  CHECK(view.digest() == replayed_view.digest());
  CHECK(view.configured_law().schema ==
        mwperf::PortableArrivalLawSchema::
            shared_joint_round_markov_renewal_v1);
  CHECK(view.configured_law().version == 1U);
  CHECK_FALSE(view.iid_joint_table().has_value());
  CHECK_FALSE(view.moments().has_value());
  CHECK_FALSE(view.covariances().has_value());
  CHECK_FALSE(view.analytic_transform().has_value());
  CHECK_FALSE(view.joint_distribution().has_value());
  CHECK_FALSE(view.coordinate_distributions().has_value());
  REQUIRE(view.replay_codec().has_value());
  CHECK(view.replay_codec()->requires_complete_initial_state);
  CHECK(view.replay_codec()->preserves_adjacent_temporal_order);
  REQUIRE(view.stationary_phase_law().has_value());
  CHECK(view.stationary_phase_law()->canonical_states.size() == 2U);
  CHECK(view.stationary_phase_law()->probabilities.size() == 2U);
  REQUIRE(view.unit_cube().has_value());
  CHECK(view.unit_cube()->capability ==
        *capabilities.unit_cube_transform);

  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);
  CHECK(services.value().view_digest() == view.digest());
  CHECK(services.value().has_replay());
  CHECK(services.value().has_unit_cube());
}

TEST_CASE("C09 construction view preserves independent portable transform "
          "descriptors",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::
          independent_portable_transforms);
  REQUIRE(law);

  const auto capabilities = mwperf::arrival_capabilities(law.value());
  REQUIRE(capabilities.analytic_transform.has_value());
  REQUIRE(capabilities.exact_joint_distribution.has_value());
  REQUIRE(capabilities.exact_coordinate_distributions.has_value());
  CHECK(capabilities.analytic_transform->kind ==
        mwperf::TransformKind::closed_transform);
  CHECK(capabilities.exact_joint_distribution->kind ==
        mwperf::TransformKind::exact_pgf);
  CHECK(capabilities.exact_coordinate_distributions->kind ==
        mwperf::TransformKind::exact_pmf);
  CHECK(capabilities.exact_joint_distribution->scope ==
        mwperf::DistributionScope::joint_vector);
  CHECK(capabilities.exact_coordinate_distributions->scope ==
        mwperf::DistributionScope::per_coordinate);
  CHECK(capabilities.analytic_transform->domain.lower == rational(0, 1));
  CHECK(capabilities.analytic_transform->domain.upper == rational(1, 1));
  CHECK(capabilities.analytic_transform->domain.lower_inclusive);
  CHECK(capabilities.analytic_transform->domain.upper_inclusive);

  const auto view = mwperf::builder_arrival_view(law.value());
  REQUIRE(view.analytic_transform().has_value());
  REQUIRE(view.joint_distribution().has_value());
  REQUIRE(view.coordinate_distributions().has_value());
  CHECK(view.analytic_transform()->codec_version == 11U);
  CHECK(view.joint_distribution()->codec_version == 12U);
  CHECK(view.coordinate_distributions()->codec_version == 13U);
  CHECK(view.analytic_transform()->canonical_parameters ==
        std::vector<std::byte>{std::byte{0xa1}});
  CHECK(view.joint_distribution()->canonical_parameters ==
        std::vector<std::byte>{std::byte{0xb2}});
  CHECK(view.coordinate_distributions()->canonical_parameters ==
        std::vector<std::byte>{std::byte{0xc3}});
}

TEST_CASE("C09 exact IID joint-vector access is independent of transforms and "
          "moments",
          "[c09][unit][arrival][capability]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
  REQUIRE(law);

  const auto capabilities = mwperf::arrival_capabilities(law.value());
  REQUIRE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(
      capabilities.exact_factorized_iid_generator.has_value());
  CHECK(capabilities.exact_iid_joint_vector->finite_support);
  CHECK(capabilities.exact_iid_joint_vector->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());

  const auto view = mwperf::builder_arrival_view(law.value());
  REQUIRE(view.iid_joint_table().has_value());
  REQUIRE(view.iid_joint_table()->size() == 2U);
  CHECK_FALSE(view.moments().has_value());
  CHECK_FALSE(view.covariances().has_value());
  CHECK_FALSE(view.analytic_transform().has_value());
  CHECK_FALSE(view.joint_distribution().has_value());
  CHECK_FALSE(view.coordinate_distributions().has_value());

  const auto& first = view.iid_joint_table()->at(0U);
  const auto& second = view.iid_joint_table()->at(1U);
  REQUIRE(first.dense_counts.size() == catalog.size());
  REQUIRE(second.dense_counts.size() == catalog.size());
  CHECK(first.dense_counts ==
        std::vector<mwperf::BigNat>{mwperf::BigNat(1U), mwperf::BigNat(4U),
                                    mwperf::BigNat(0U)});
  CHECK(second.dense_counts ==
        std::vector<mwperf::BigNat>{mwperf::BigNat(3U), mwperf::BigNat(2U),
                                    mwperf::BigNat(0U)});
  CHECK(first.probability == rational(1, 2));
  CHECK(second.probability == rational(1, 2));
}

TEST_CASE("C09 exact moments and covariances are independent of a PMF or "
          "transform",
          "[c09][unit][arrival][capability]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::
          portable_moments_and_covariance);
  REQUIRE(law);

  auto first = catalog.index_at(0U);
  auto second = catalog.index_at(1U);
  auto third = catalog.index_at(2U);
  REQUIRE(first);
  REQUIRE(second);
  REQUIRE(third);
  const auto capabilities = mwperf::arrival_capabilities(law.value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  REQUIRE(capabilities.exact_joint_moments.has_value());
  REQUIRE(capabilities.exact_coordinate_moments.has_value());
  REQUIRE(capabilities.exact_joint_moments->maximum_order.has_value());
  REQUIRE(capabilities.exact_coordinate_moments->maximum_order.has_value());
  CHECK(*capabilities.exact_joint_moments->maximum_order ==
        mwperf::BigNat(2U));
  CHECK(*capabilities.exact_coordinate_moments->maximum_order ==
        mwperf::BigNat(2U));
  CHECK(capabilities.exact_joint_moments->joint);
  CHECK_FALSE(capabilities.exact_coordinate_moments->joint);
  CHECK(capabilities.exact_joint_moments->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK(capabilities.exact_coordinate_moments->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::available);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());

  const auto view = mwperf::builder_arrival_view(law.value());
  CHECK_FALSE(view.iid_joint_table().has_value());
  CHECK_FALSE(view.analytic_transform().has_value());
  CHECK_FALSE(view.joint_distribution().has_value());
  CHECK_FALSE(view.coordinate_distributions().has_value());
  REQUIRE(view.moments().has_value());
  REQUIRE(view.covariances().has_value());
  const std::vector<mwperf::ExactMomentDatum> expected_moments{
      {{first.value()}, mwperf::BigNat(1U), rational(2, 1)},
      {{first.value()}, mwperf::BigNat(2U), rational(5, 1)},
      {{first.value(), second.value()}, mwperf::BigNat(2U), rational(5, 1)},
      {{first.value(), third.value()}, mwperf::BigNat(2U), rational(0, 1)},
      {{second.value()}, mwperf::BigNat(1U), rational(3, 1)},
      {{second.value()}, mwperf::BigNat(2U), rational(10, 1)},
      {{second.value(), third.value()}, mwperf::BigNat(2U), rational(0, 1)},
      {{third.value()}, mwperf::BigNat(1U), rational(0, 1)},
      {{third.value()}, mwperf::BigNat(2U), rational(0, 1)}};
  const std::vector<mwperf::ExactMomentDatum> expected_covariances{
      {{first.value(), first.value()}, mwperf::BigNat(2U), rational(1, 1)},
      {{first.value(), second.value()}, mwperf::BigNat(2U), rational(-1, 1)},
      {{first.value(), third.value()}, mwperf::BigNat(2U), rational(0, 1)},
      {{second.value(), second.value()}, mwperf::BigNat(2U), rational(1, 1)},
      {{second.value(), third.value()}, mwperf::BigNat(2U), rational(0, 1)},
      {{third.value(), third.value()}, mwperf::BigNat(2U), rational(0, 1)}};
  CHECK(*view.moments() == expected_moments);
  CHECK(*view.covariances() == expected_covariances);
}

TEST_CASE("C09 adjacent replay can be advertised without stationary "
          "initialization",
          "[c09][unit][arrival][capability]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::replay_without_stationary);
  REQUIRE(law);

  const auto capabilities = mwperf::arrival_capabilities(law.value());
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  REQUIRE(capabilities.adjacent_batch_replay.has_value());
  CHECK(capabilities.adjacent_batch_replay->explicit_initial_state);
  CHECK(capabilities.adjacent_batch_replay->explicit_phase);
  CHECK(capabilities.adjacent_batch_replay->normalized_initial_law);
  CHECK_FALSE(
      capabilities.adjacent_batch_replay->named_stationary_initialization);

  const auto view = mwperf::builder_arrival_view(law.value());
  REQUIRE(view.replay_codec().has_value());
  CHECK_FALSE(view.stationary_phase_law().has_value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);
  CHECK(services.value().has_replay());

  auto replay = services.value().replay_service()->replay(
      mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayInitialState{shared_round_state("h0")},
          mwperf::BigNat(0U), mwperf::BigNat(2U),
          make_builder_stream(law.value(), 5401U, 2U,
                              mwperf::StageTag::surrogate_build_probe),
          "nonstationary-explicit-replay"});
  REQUIRE(replay);
  CHECK(replay.value().accounting.transitions == mwperf::BigNat(2U));
  CHECK(replay.value().accounting.rng_words == mwperf::BigNat(2U));

  auto stationary = services.value().replay_service()->replay(
      mwperf::AdjacentReplayRequest{
          view.digest(), mwperf::NamedStationaryPhaseLaw{"missing-by-design"},
          mwperf::BigNat(0U), mwperf::BigNat(1U),
          make_builder_stream(law.value(), 5402U, 3U,
                              mwperf::StageTag::surrogate_build_probe),
          "stationary-replay-is-absent"});
  REQUIRE_FALSE(stationary);
  CHECK(stationary.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK(stationary.error().code == "arrival_stationary_replay_unsupported");
}

TEST_CASE("C09 publication rejects process-local portable data without an "
          "evaluator",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::array profiles{
      mwperf::testing::FixtureConstructionProfile::
          unsupported_process_local_iid,
      mwperf::testing::FixtureConstructionProfile::
          unsupported_process_local_moment,
      mwperf::testing::FixtureConstructionProfile::
          unsupported_process_local_transform,
  };
  for (const auto profile : profiles) {
    CAPTURE(static_cast<unsigned int>(profile));
    auto law = mwperf::testing::make_c09_correlated_fixture_law(
        catalog, mwperf::testing::FixtureFailureMode::none, profile);
    REQUIRE_FALSE(law);
    CHECK(law.error().category == mwperf::DiagnosticCategory::internal);
    CHECK(law.error().code == "arrival_capability_contract_mismatch");
  }
}

TEST_CASE("C09 publication rejects malformed capability discriminants and "
          "descriptors transactionally",
          "[c09][unit][negative][arrival][publication]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  using Profile = mwperf::testing::FixtureConstructionProfile;
  struct Case final {
    Profile profile;
    const char* expected_code;
  };
  const std::array cases{
      Case{Profile::invalid_availability_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_stationary_status_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_access_provision_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_transform_kind_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_distribution_scope_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_phase_requirement_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_cube_boundary_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_inverse_cdf_discriminant,
           "arrival_capability_contract_mismatch"},
      Case{Profile::partial_sampler_runtime,
           "arrival_runtime_adapter_incomplete"},
      Case{Profile::nonfinite_iid_claim,
           "arrival_capability_contract_mismatch"},
      Case{Profile::iid_support_mismatch,
           "arrival_capability_contract_mismatch"},
      Case{Profile::noncanonical_moment_table,
           "arrival_capability_contract_mismatch"},
      Case{Profile::noncanonical_covariance_table,
           "arrival_capability_contract_mismatch"},
      Case{Profile::invalid_unit_cube_coordinates,
           "arrival_capability_contract_mismatch"},
      Case{Profile::incomplete_replay_codec,
           "arrival_capability_contract_mismatch"},
      Case{Profile::empty_transform_domain,
           "arrival_capability_contract_mismatch"},
      Case{Profile::zero_transform_codec,
           "arrival_capability_contract_mismatch"},
      Case{Profile::throwing_phase_decoder, "arrival_compiler_exception"},
      Case{Profile::support_dimension_mismatch,
           "arrival_support_dimension_mismatch"},
      Case{Profile::unbounded_moment_claim,
           "arrival_capability_contract_mismatch"},
      Case{Profile::phase_conditioned_moment_claim,
           "arrival_capability_contract_mismatch"},
      Case{Profile::incomplete_coordinate_moment_table,
           "arrival_capability_contract_mismatch"},
      Case{Profile::incomplete_covariance_table,
           "arrival_capability_contract_mismatch"},
      Case{Profile::incomplete_cross_moment_table,
           "arrival_capability_contract_mismatch"},
      Case{Profile::unit_cube_missing_phase_encoder,
           "arrival_capability_contract_mismatch"},
      Case{Profile::replay_missing_sequential_sampler,
           "arrival_capability_contract_mismatch"},
  };

  for (const Case& item : cases) {
    CAPTURE(static_cast<unsigned int>(item.profile));
    auto law = mwperf::testing::make_c09_correlated_fixture_law(
        catalog, mwperf::testing::FixtureFailureMode::none, item.profile);
    REQUIRE_FALSE(law);
    CHECK(law.error().category == mwperf::DiagnosticCategory::internal);
    CHECK(law.error().code == item.expected_code);
  }
}

TEST_CASE("C09 builder replay uses a fresh cursor and leaves deployment "
          "untouched",
          "[c09][unit][integration][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);

  auto deployed = make_process(law.value(), 2201U, 7U);
  const auto deployed_origin = snapshot(deployed);

  auto builder_stream = mwperf::make_builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_probe,
      fixture_rng(mwperf::MasterSeed(3100U),
                  mwperf::StageTag::surrogate_build_probe, 12U));
  REQUIRE(builder_stream);
  mwperf::AdjacentReplayRequest request{
      view.digest(),
      mwperf::ExplicitReplayInitialState{shared_round_state("h0")},
      mwperf::BigNat(0U),
      mwperf::BigNat(3U),
      std::move(builder_stream).value(),
      "unit-replay"};
  auto replay = services.value().replay_service()->replay(std::move(request));
  REQUIRE(replay);
  CHECK(replay.value().view_digest == view.digest());
  CHECK(replay.value().replay_identity == "unit-replay");
  CHECK(replay.value().status ==
        mwperf::ReplayContextStatus::ordered_dependent_contexts);
  REQUIRE(replay.value().steps.size() == 3U);
  CHECK(replay.value().accounting.transitions == mwperf::BigNat(3U));
  CHECK(replay.value().accounting.rng_words == mwperf::BigNat(3U));
  for (std::size_t index = 0U; index < replay.value().steps.size(); ++index) {
    CHECK(replay.value().steps[index].authored_slot ==
          mwperf::BigNat(static_cast<std::uint64_t>(index)));
    check_correlated_pair(
        projected_pair(replay.value().steps[index].batch, catalog,
                       mwperf::arrival_law_binding(law.value())));
  }
  check_same_snapshot(deployed_origin, snapshot(deployed));

  auto deployed_step =
      mwperf::next_arrival_step(deployed, mwperf::BigNat(0U));
  REQUIRE(deployed_step);
  auto fresh_deployed = make_process(law.value(), 2201U, 7U);
  auto fresh_step =
      mwperf::next_arrival_step(fresh_deployed, mwperf::BigNat(0U));
  REQUIRE(fresh_step);
  check_same_step(deployed_step.value(), fresh_step.value());

  auto wrong_stage = mwperf::make_builder_arrival_stream_key(
      law.value(), mwperf::StageTag::configured_arrival,
      fixture_rng(mwperf::MasterSeed(3100U),
                  mwperf::StageTag::configured_arrival, 12U));
  REQUIRE_FALSE(wrong_stage);
  CHECK(wrong_stage.error().code == "arrival_builder_stream_stage_mismatch");

  auto mislabeled_builder_stage = mwperf::make_builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_probe,
      fixture_rng(mwperf::MasterSeed(3100U),
                  mwperf::StageTag::surrogate_build_context, 12U));
  REQUIRE_FALSE(mislabeled_builder_stage);
  CHECK(mislabeled_builder_stage.error().code ==
        "arrival_builder_stream_stage_mismatch");

  auto scheduler_stream = mwperf::make_configured_arrival_stream_key(
      law.value(), fixture_rng(mwperf::MasterSeed(3100U),
                               mwperf::StageTag::tie_resolution, 12U));
  REQUIRE_FALSE(scheduler_stream);
  CHECK(scheduler_stream.error().code == "arrival_stream_stage_mismatch");
}

TEST_CASE("C09 portable-only construction access does not create local "
          "services",
          "[c09][unit][arrival][capability]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::
          portable_only_construction_access);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  REQUIRE(view.capabilities().adjacent_batch_replay.has_value());
  REQUIRE(view.capabilities().unit_cube_transform.has_value());
  CHECK(view.capabilities().adjacent_batch_replay->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK(view.capabilities().unit_cube_transform->provision ==
        mwperf::AccessProvision::portable_only);
  REQUIRE(view.replay_codec().has_value());
  REQUIRE(view.unit_cube().has_value());

  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);
  CHECK_FALSE(services.value().has_replay());
  CHECK_FALSE(services.value().has_unit_cube());
  CHECK_FALSE(services.value().replay_service().has_value());
  CHECK_FALSE(services.value().unit_cube_service().has_value());
}

TEST_CASE("C09 builder replay restores an explicit predictive phase at its "
          "authored slot",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);

  auto phase_source = make_process(law.value(), 6501U, 8U);
  auto origin_step =
      mwperf::next_arrival_step(phase_source, mwperf::BigNat(0U));
  REQUIRE(origin_step);
  const mwperf::ArrivalPhase replay_phase = origin_step.value().phase_after;

  auto first = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::ExplicitReplayPhase{replay_phase},
      mwperf::BigNat(1U),
      mwperf::BigNat(3U),
      make_builder_stream(law.value(), 6502U, 9U,
                          mwperf::StageTag::surrogate_build_probe),
      "phase-replay"});
  auto repeated =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayPhase{replay_phase},
          mwperf::BigNat(1U),
          mwperf::BigNat(3U),
          make_builder_stream(law.value(), 6502U, 9U,
                              mwperf::StageTag::surrogate_build_probe),
          "phase-replay"});
  REQUIRE(first);
  REQUIRE(repeated);
  check_same_replay(first.value(), repeated.value());
  REQUIRE(first.value().steps.size() == 3U);
  CHECK(first.value().steps.front().authored_slot == mwperf::BigNat(1U));
  CHECK(mwperf::arrival_phase_digest(first.value().steps.front().phase_before) ==
        mwperf::arrival_phase_digest(replay_phase));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(
          first.value().steps.front().phase_before),
      mwperf::arrival_phase_canonical_state(replay_phase)));
  CHECK_FALSE(mwperf::arrival_phases_share_cursor(
      first.value().steps.front().phase_before, replay_phase));
  CHECK(first.value().accounting.transitions == mwperf::BigNat(3U));
  CHECK(first.value().accounting.rng_words == mwperf::BigNat(3U));

  auto wrong_slot =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayPhase{replay_phase},
          mwperf::BigNat(0U),
          mwperf::BigNat(1U),
          make_builder_stream(law.value(), 6503U, 10U,
                              mwperf::StageTag::surrogate_build_probe),
          "phase-wrong-slot"});
  REQUIRE_FALSE(wrong_slot);
  CHECK(wrong_slot.error().code == "arrival_replay_phase_slot_mismatch");
}

TEST_CASE("C09 normalized and named replay initialization are deterministic "
          "and account for their phase draw",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);

  const auto initial_states = std::vector<mwperf::ArrivalInitialState>{
      shared_round_state("h0"), shared_round_state("h1")};
  const auto initial_pmf = two_atom_pmf();
  auto normalized =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::NormalizedReplayInitialLaw{initial_states, initial_pmf},
          mwperf::BigNat(0U),
          mwperf::BigNat(2U),
          make_builder_stream(law.value(), 7101U, 3U,
                              mwperf::StageTag::surrogate_build_context),
          "normalized-replay"});
  auto normalized_repeated =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::NormalizedReplayInitialLaw{initial_states, initial_pmf},
          mwperf::BigNat(0U),
          mwperf::BigNat(2U),
          make_builder_stream(law.value(), 7101U, 3U,
                              mwperf::StageTag::surrogate_build_context),
          "normalized-replay"});
  REQUIRE(normalized);
  REQUIRE(normalized_repeated);
  check_same_replay(normalized.value(), normalized_repeated.value());
  CHECK(normalized.value().accounting.transitions == mwperf::BigNat(2U));
  CHECK(normalized.value().accounting.rng_words == mwperf::BigNat(3U));

  auto named = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::NamedStationaryPhaseLaw{"c09_fixture_stationary_h01"},
      mwperf::BigNat(5U),
      mwperf::BigNat(2U),
      make_builder_stream(law.value(), 7201U, 5U,
                          mwperf::StageTag::surrogate_build_input),
      "named-stationary-replay"});
  auto named_repeated =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::NamedStationaryPhaseLaw{"c09_fixture_stationary_h01"},
          mwperf::BigNat(5U),
          mwperf::BigNat(2U),
          make_builder_stream(law.value(), 7201U, 5U,
                              mwperf::StageTag::surrogate_build_input),
          "named-stationary-replay"});
  REQUIRE(named);
  REQUIRE(named_repeated);
  check_same_replay(named.value(), named_repeated.value());
  REQUIRE_FALSE(named.value().steps.empty());
  CHECK(named.value().steps.front().authored_slot == mwperf::BigNat(5U));
  CHECK(named.value().accounting.transitions == mwperf::BigNat(2U));
  CHECK(named.value().accounting.rng_words == mwperf::BigNat(3U));

  auto bad_dimension =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::NormalizedReplayInitialLaw{
              std::vector<mwperf::ArrivalInitialState>{
                  shared_round_state("h0")},
              initial_pmf},
          mwperf::BigNat(0U),
          mwperf::BigNat(1U),
          make_builder_stream(law.value(), 7301U, 6U,
                              mwperf::StageTag::surrogate_build_probe),
          "bad-normalized-dimension"});
  REQUIRE_FALSE(bad_dimension);
  CHECK(bad_dimension.error().code ==
        "arrival_replay_initial_law_dimension_mismatch");

  auto unknown_stationary =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::NamedStationaryPhaseLaw{"not_the_configured_law"},
          mwperf::BigNat(0U),
          mwperf::BigNat(1U),
          make_builder_stream(law.value(), 7302U, 7U,
                              mwperf::StageTag::surrogate_build_probe),
          "unknown-stationary-law"});
  REQUIRE_FALSE(unknown_stationary);
  CHECK(unknown_stationary.error().code ==
        "arrival_stationary_replay_law_mismatch");
}

TEST_CASE("C09 builder replay path changes with initialization or construction "
          "stage",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);

  auto h0 = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::ExplicitReplayInitialState{shared_round_state("h0")},
      mwperf::BigNat(0U),
      mwperf::BigNat(1U),
      make_builder_stream(law.value(), 8101U, 4U,
                          mwperf::StageTag::surrogate_build_probe),
      "changed-path"});
  auto h1 = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::ExplicitReplayInitialState{shared_round_state("h1")},
      mwperf::BigNat(0U),
      mwperf::BigNat(1U),
      make_builder_stream(law.value(), 8101U, 4U,
                          mwperf::StageTag::surrogate_build_probe),
      "changed-path"});
  auto other_stage =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayInitialState{shared_round_state("h0")},
          mwperf::BigNat(0U),
          mwperf::BigNat(1U),
          make_builder_stream(law.value(), 8101U, 4U,
                              mwperf::StageTag::surrogate_build_final),
          "changed-path"});
  REQUIRE(h0);
  REQUIRE(h1);
  REQUIRE(other_stage);
  REQUIRE(h0.value().steps.size() == 1U);
  REQUIRE(h1.value().steps.size() == 1U);
  REQUIRE(other_stage.value().steps.size() == 1U);
  CHECK_FALSE(mwperf::arrival_phase_digest(h0.value().steps[0].phase_before) ==
              mwperf::arrival_phase_digest(h1.value().steps[0].phase_before));
  CHECK_FALSE(h0.value().steps[0].realization_identity ==
              h1.value().steps[0].realization_identity);
  CHECK_FALSE(h0.value().steps[0].realization_identity ==
              other_stage.value().steps[0].realization_identity);
}

TEST_CASE("C09 unit cube evaluates one correlated joint transition without "
          "touching deployment RNG",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);
  auto deployed = make_process(law.value(), 19U);
  const auto deployed_origin = snapshot(deployed);

  mwperf::UnitCubeRequest low{view.digest(), mwperf::BigNat(5U), std::nullopt,
                              {rational(1, 4)}};
  auto low_transition = services.value().unit_cube_service()->evaluate(low);
  REQUIRE(low_transition);
  CHECK(low_transition.value().authored_slot == mwperf::BigNat(5U));
  CHECK(mwperf::arrival_phase_digest(low_transition.value().phase_before) ==
        deployed_origin.phase_digest);
  CHECK((projected_pair(low_transition.value().batch, catalog,
                        mwperf::arrival_law_binding(law.value())) ==
         std::pair<mwperf::BigNat, mwperf::BigNat>{mwperf::BigNat(1U),
                                                   mwperf::BigNat(4U)}));
  CHECK(mwperf::arrival_phases_share_cursor(
      low_transition.value().phase_before,
      low_transition.value().phase_after));

  mwperf::UnitCubeRequest boundary{
      view.digest(), mwperf::BigNat(5U), std::nullopt, {rational(1, 2)}};
  auto high_transition =
      services.value().unit_cube_service()->evaluate(boundary);
  REQUIRE(high_transition);
  CHECK((projected_pair(high_transition.value().batch, catalog,
                        mwperf::arrival_law_binding(law.value())) ==
         std::pair<mwperf::BigNat, mwperf::BigNat>{mwperf::BigNat(3U),
                                                   mwperf::BigNat(2U)}));
  check_same_snapshot(deployed_origin, snapshot(deployed));

  mwperf::UnitCubeRequest wrong_dimension{
      view.digest(), mwperf::BigNat(0U), std::nullopt, {}};
  auto dimension_error =
      services.value().unit_cube_service()->evaluate(wrong_dimension);
  REQUIRE_FALSE(dimension_error);
  CHECK(dimension_error.error().code ==
        "arrival_unit_cube_dimension_mismatch");

  mwperf::UnitCubeRequest endpoint{
      view.digest(), mwperf::BigNat(0U), std::nullopt,
      {mwperf::ExactRational::one()}};
  auto domain_error =
      services.value().unit_cube_service()->evaluate(endpoint);
  REQUIRE_FALSE(domain_error);
  CHECK(domain_error.error().code ==
        "arrival_unit_cube_point_out_of_domain");

  auto phase_source = make_process(law.value(), 20U);
  auto phase_source_step =
      mwperf::next_arrival_step(phase_source, mwperf::BigNat(0U));
  REQUIRE(phase_source_step);
  mwperf::UnitCubeRequest unexpected_phase{
      view.digest(), mwperf::BigNat(1U),
      phase_source_step.value().phase_after, {rational(1, 4)}};
  auto phase_error =
      services.value().unit_cube_service()->evaluate(unexpected_phase);
  REQUIRE_FALSE(phase_error);
  CHECK(phase_error.error().code == "arrival_unit_cube_phase_unexpected");
}

TEST_CASE("C09 phase-dependent unit cube requires a bound phase at the exact "
          "requested slot",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto law = mwperf::testing::make_c09_correlated_fixture_law(
      catalog, mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::phase_required_unit_cube);
  REQUIRE(law);
  const auto view = mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);
  REQUIRE(view.capabilities().unit_cube_transform.has_value());
  CHECK(view.capabilities().unit_cube_transform->phase_requirement ==
        mwperf::PhaseArgumentRequirement::explicit_phase_required);

  auto phase_source = make_process(law.value(), 9201U, 3U);
  auto phase_step =
      mwperf::next_arrival_step(phase_source, mwperf::BigNat(0U));
  REQUIRE(phase_step);
  const mwperf::ArrivalPhase slot_one_phase = phase_step.value().phase_after;

  mwperf::UnitCubeRequest absent_phase{
      view.digest(), mwperf::BigNat(1U), std::nullopt, {rational(1, 4)}};
  auto required_error =
      services.value().unit_cube_service()->evaluate(absent_phase);
  REQUIRE_FALSE(required_error);
  CHECK(required_error.error().code == "arrival_unit_cube_phase_required");

  mwperf::UnitCubeRequest wrong_slot{
      view.digest(), mwperf::BigNat(0U), slot_one_phase, {rational(1, 4)}};
  auto slot_error = services.value().unit_cube_service()->evaluate(wrong_slot);
  REQUIRE_FALSE(slot_error);
  CHECK(slot_error.error().code == "arrival_unit_cube_phase_slot_mismatch");

  mwperf::UnitCubeRequest aligned{
      view.digest(), mwperf::BigNat(1U), slot_one_phase, {rational(1, 4)}};
  auto transition = services.value().unit_cube_service()->evaluate(aligned);
  REQUIRE(transition);
  CHECK(transition.value().authored_slot == mwperf::BigNat(1U));
  CHECK(mwperf::arrival_phase_digest(transition.value().phase_before) ==
        mwperf::arrival_phase_digest(slot_one_phase));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(transition.value().phase_before),
      mwperf::arrival_phase_canonical_state(slot_one_phase)));
  CHECK_FALSE(mwperf::arrival_phases_share_cursor(
      transition.value().phase_before, slot_one_phase));
  CHECK((projected_pair(transition.value().batch, catalog,
                        mwperf::arrival_law_binding(law.value())) ==
         std::pair<mwperf::BigNat, mwperf::BigNat>{mwperf::BigNat(1U),
                                                   mwperf::BigNat(4U)}));
}
