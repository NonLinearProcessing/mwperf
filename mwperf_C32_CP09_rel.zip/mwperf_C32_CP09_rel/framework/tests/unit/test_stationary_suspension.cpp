#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/stationary/suspension.hpp"
#include "stationary/c21_bounded_projection_internal.hpp"

namespace {

namespace c21 = mwperf::testing::c21;

using mwperf::BigNat;
using mwperf::EventInvariantLaw;
using mwperf::ExactRational;
using mwperf::PositiveFiniteMean;
using mwperf::StationaryMarkedEdge;
using mwperf::StationaryTemporalLaw;
using mwperf::StationaryTemporalProjection;
using mwperf::testing::C21MeanEvidenceFixtureV1;
using mwperf::testing::C21MeanEvidenceKindV1;
using mwperf::testing::C21MarkedEdgeFixtureAtomV1;

static_assert(!std::is_default_constructible_v<EventInvariantLaw>);
static_assert(!std::is_default_constructible_v<PositiveFiniteMean>);
static_assert(!std::is_default_constructible_v<StationaryTemporalLaw>);
static_assert(!std::is_default_constructible_v<StationaryMarkedEdge>);
static_assert(!std::is_default_constructible_v<StationaryTemporalProjection>);
static_assert(!std::is_convertible_v<EventInvariantLaw,
                                     StationaryTemporalLaw>);
static_assert(!std::is_convertible_v<StationaryMarkedEdge,
                                     StationaryTemporalLaw>);
static_assert(!std::is_convertible_v<StationaryTemporalLaw,
                                     StationaryMarkedEdge>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::compute_mean_residence),
              const EventInvariantLaw&, const mwperf::KernelAccess&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::compute_mean_residence),
              const EventInvariantLaw&,
              const mwperf::AuditedSamplerDescriptor&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::suspend_event_law_to_slots),
              const EventInvariantLaw&, const mwperf::KernelAccess&,
              const PositiveFiniteMean&, const mwperf::RewardDecoder&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::suspend_event_law_to_slots),
              const EventInvariantLaw&,
              const mwperf::AuditedSamplerDescriptor&,
              const PositiveFiniteMean&, const mwperf::RewardDecoder&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::build_stationary_temporal_projection),
              const EventInvariantLaw&, const mwperf::KernelAccess&,
              const PositiveFiniteMean&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::build_stationary_temporal_projection),
              const EventInvariantLaw&,
              const mwperf::AuditedSamplerDescriptor&,
              const PositiveFiniteMean&>);

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

template <typename T>
void require_error(const mwperf::Result<T>& result,
                   const std::string& expected_code) {
  REQUIRE_FALSE(result);
  CHECK(result.error().code == expected_code);
}

[[nodiscard]] mwperf::EventInvariantLaw select_event_law(
    const c21::StationarySuspensionFixtureV1& fixture) {
  return require_value(mwperf::select_event_invariant_law(
      fixture.kernel, c21::configured_selection(fixture),
      c21::solver_policy(fixture)));
}

[[nodiscard]] const mwperf::EventInvariantMassV1* event_mass_for_phase(
    const EventInvariantLaw& law, const std::uint8_t phase) {
  for (const auto& mass : law.masses()) {
    REQUIRE(mass.state_index < law.domain().states().size());
    if (c21::phase(law.domain().states()[mass.state_index]) == phase) {
      return &mass;
    }
  }
  return nullptr;
}

[[nodiscard]] mwperf::RewardDecoder length_bias_reward_decoder() {
  return {
      mwperf::StationaryRewardDomainV1::state,
      mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
      false,
      {},
      [](const mwperf::StationaryRewardArgumentV1& argument)
          -> mwperf::Result<long double> {
        const std::uint8_t phase = c21::phase(argument.state);
        if (phase == 0U) {
          return mwperf::Result<long double>::success(10.0L);
        }
        return mwperf::Result<long double>::success(
            static_cast<long double>(c21::age(argument.state) + 1U));
      },
      {"c21.test.length-biased-reward", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder constant_reward_decoder(
    const mwperf::StationaryRewardIntegrabilityV1 integrability,
    const long double value,
    const mwperf::StationaryRewardDomainV1 domain =
        mwperf::StationaryRewardDomainV1::state,
    std::vector<mwperf::RequiredStationaryMarkV1> marks = {}) {
  return {domain,
          integrability,
          false,
          std::move(marks),
          [value](const mwperf::StationaryRewardArgumentV1&)
              -> mwperf::Result<long double> {
            return mwperf::Result<long double>::success(value);
          },
          {"c21.test.constant-reward", 1U}};
}

[[nodiscard]] mwperf::RuntimeMarkIdV1 mark_id(const std::string& value) {
  auto label = mwperf::TypedLabel::text(value);
  REQUIRE(label);
  return mwperf::RuntimeMarkIdV1(std::move(label).value());
}

[[nodiscard]] mwperf::ReducedStateV1 edge_state(const std::uint8_t value) {
  return {{"c21.test.marked-edge-state", 1U},
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] mwperf::MarkedFluxEdgeV1 edge_atom(
    const std::uint8_t departure, const std::uint64_t arrival) {
  const mwperf::ArrivalPhaseIdentityV1 phase{
      mwperf::ArrivalFamily::shared_joint_round_markov_renewal,
      {std::byte{0x00}}};
  return {edge_state(1U), edge_state(1U), {BigNat{1U}}, {departure},
          {BigNat{arrival}}, phase, phase, {}};
}

[[nodiscard]] C21MeanEvidenceFixtureV1 mean_evidence(
    const C21MeanEvidenceKindV1 kind, const ExactRational& evaluated,
    const ExactRational& lower,
    std::optional<ExactRational> upper,
    const ExactRational& tail_lower = ExactRational::zero(),
    std::optional<ExactRational> tail_upper = ExactRational::zero(),
    const bool support_complete = true,
    const bool tail_certified = true) {
  return {kind, evaluated, lower, std::move(upper), tail_lower,
          std::move(tail_upper), support_complete, tail_certified};
}

struct ConfiguredMetricResult final {
  mwperf::MetricValue value;
  mwperf::Digest256 projection_fingerprint;
};

[[nodiscard]] ConfiguredMetricResult evaluate_configured_metric(
    const c21::ProjectionPlanFixtureV1 plan) {
  auto fixture = c21::make_plan_fixture(plan);
  EventInvariantLaw law = select_event_law(fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, fixture.provider, mean));
  const auto request = require_value(mwperf::parse_metric_request(
      fixture.temporal.instance.analysis_spec().metrics.front(),
      fixture.temporal.instance.queues()));
  return {require_value(mwperf::evaluate_stationary_temporal_metric(
              projection.temporal_law(), request)),
          projection.fingerprint()};
}

}  // namespace

TEST_CASE("C21 length-biases two selected event classes and evaluates the "
          "renewal reward exactly",
          "[c21][unit]") {
  auto fixture = c21::make_fixture();
  const auto request = require_value(mwperf::parse_metric_request(
      fixture.temporal.instance.analysis_spec().metrics.front(),
      fixture.temporal.instance.queues()));
  const auto requirements = mwperf::requirements_for_metric(request);
  const auto has_route = [&](const mwperf::BackendRouteKindV1 route) {
    for (const auto& clause : requirements.clauses()) {
      if (std::ranges::any_of(
              clause.route_alternatives,
              [&](const mwperf::MetricRouteAlternativeV1& alternative) {
                return alternative.access.backend_route == route &&
                       alternative.access.runtime_access ==
                           mwperf::RuntimeAccessTagV1::
                               procedural_residence_generator;
              })) {
        return true;
      }
    }
    return false;
  };
  CHECK(has_route(mwperf::BackendRouteKindV1::stationary_invariant));
  CHECK(has_route(mwperf::BackendRouteKindV1::stationary_edge_reward));
  EventInvariantLaw law = select_event_law(fixture);

  REQUIRE(law.masses().size() == 2U);
  REQUIRE(law.selected_classes().size() == 2U);
  REQUIRE(law.diagnostics().classes.size() == 2U);
  REQUIRE(law.diagnostics().closed_class_indices.size() == 2U);
  CHECK(law.diagnostics().transient_state_indices.empty());
  CHECK(law.diagnostics().exact_nonnegative);
  CHECK(law.diagnostics().exact_normalized);
  CHECK(law.diagnostics().exact_invariant);
  CHECK(law.diagnostics().exact_normalization_residual.is_zero());
  REQUIRE(law.diagnostics().exact_invariance_residuals.size() == 2U);
  CHECK(std::ranges::all_of(
      law.diagnostics().exact_invariance_residuals,
      [](const ExactRational& residual) { return residual.is_zero(); }));

  const auto* event_a = event_mass_for_phase(law, 0U);
  const auto* event_b = event_mass_for_phase(law, 1U);
  REQUIRE(event_a != nullptr);
  REQUIRE(event_b != nullptr);
  CHECK(event_a->exact_mass == c21::rational(1, 2));
  CHECK(event_b->exact_mass == c21::rational(1, 2));
  for (const auto& selected : law.selected_classes()) {
    CHECK(selected.exact_weight == c21::rational(1, 2));
  }

  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  REQUIRE(mean.exact_value().has_value());
  CHECK(*mean.exact_value() == c21::rational(2, 1));
  CHECK(mean.exact_lower_bound() == c21::rational(2, 1));
  CHECK(mean.exact_upper_bound() == c21::rational(2, 1));
  CHECK(mean.diagnostics().method ==
        mwperf::ResidenceExpectationMethodV1::finite_exact_enumeration);
  CHECK(mean.diagnostics().event_states_visited == 2U);
  CHECK(mean.diagnostics().words_visited == 2U);
  CHECK(mean.diagnostics().offsets_certified == 4U);
  CHECK(mean.diagnostics().support_complete);
  CHECK(mean.diagnostics().tail_certified);

  const auto state_limited =
      mwperf::stationary::detail::build_stationary_temporal_projection_bounded(
          law, fixture.provider, mean, 3U, 1U);
  REQUIRE_FALSE(state_limited);
  CHECK(state_limited.error().code ==
        "c21.stationary_temporal_state_budget_exceeded");
  const auto row_limited =
      mwperf::stationary::detail::build_stationary_temporal_projection_bounded(
          law, fixture.provider, mean, 4U, 0U);
  REQUIRE_FALSE(row_limited);
  CHECK(row_limited.error().code ==
        "c21.stationary_temporal_row_atom_budget_exceeded");
  const auto bounded =
      require_value(mwperf::stationary::detail::
                        build_stationary_temporal_projection_bounded(
                            law, fixture.provider, mean, 4U, 1U));
  CHECK(bounded.actual_state_count == 4U);
  CHECK(bounded.actual_maximum_row_atoms == 1U);

  const auto value = require_value(mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean, length_bias_reward_decoder()));
  const auto envelope = require_value(
      mwperf::testing::C21FixtureAccess::decode_metric_envelope(value));
  REQUIRE(envelope.exact_numerator.has_value());
  REQUIRE(envelope.exact_ratio.has_value());
  CHECK(*envelope.exact_numerator == c21::rational(8, 1));
  CHECK(envelope.exact_denominator == c21::rational(2, 1));
  CHECK(*envelope.exact_ratio == c21::rational(4, 1));
  CHECK_FALSE(envelope.positive_infinity);

  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, fixture.provider, mean));
  const auto atoms = mwperf::testing::C21FixtureAccess::temporal_atoms(
      projection.temporal_law());
  REQUIRE(atoms.size() == 4U);
  ExactRational class_a_slot_mass = ExactRational::zero();
  ExactRational class_b_slot_mass = ExactRational::zero();
  for (const auto& atom : atoms) {
    CHECK(atom.exact_mass == c21::rational(1, 4));
    const std::uint8_t phase = c21::phase(atom.stationary_left_state);
    if (phase == 0U) {
      class_a_slot_mass = class_a_slot_mass + atom.exact_mass;
    } else {
      REQUIRE(phase == 1U);
      class_b_slot_mass = class_b_slot_mass + atom.exact_mass;
    }
  }
  CHECK(class_a_slot_mass == c21::rational(1, 4));
  CHECK(class_b_slot_mass == c21::rational(3, 4));
}

TEST_CASE("C21 unit residences reduce the slot law to the event law",
          "[c21][unit]") {
  auto fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::equal_mixture, c21::rational(1, 2),
      c21::rational(1, 2), false, 1U);
  EventInvariantLaw law = select_event_law(fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  REQUIRE(mean.exact_value().has_value());
  CHECK(*mean.exact_value() == ExactRational::one());

  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, fixture.provider, mean));
  const auto atoms = mwperf::testing::C21FixtureAccess::temporal_atoms(
      projection.temporal_law());
  REQUIRE(atoms.size() == 2U);
  for (const auto& atom : atoms) {
    CHECK(atom.residence_offset == BigNat{0U});
    CHECK(atom.exact_mass == c21::rational(1, 2));
    const auto* event = event_mass_for_phase(
        law, c21::phase(atom.stationary_left_state));
    REQUIRE(event != nullptr);
    CHECK(atom.exact_mass == event->exact_mass);
  }
  CHECK(projection.marked_edge().diagnostics().exact_total_mass ==
        ExactRational::one());
  CHECK(projection.marked_edge().diagnostics().exact_left_right_marginals_equal);
  CHECK(projection.marked_edge().diagnostics().exact_queue_updates_hold);
  CHECK(projection.marked_edge().diagnostics().exact_endpoint_invariance_holds);
}

TEST_CASE("C21 unit-residence edge equals the direct C17 to C18 marked edge",
          "[c21][unit]") {
  auto fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::equal_mixture, c21::rational(1, 2),
      c21::rational(1, 2), false, 1U);
  EventInvariantLaw law = select_event_law(fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  REQUIRE(mean.exact_value().has_value());
  REQUIRE(*mean.exact_value() == ExactRational::one());
  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, fixture.provider, mean));

  // This is an independent inherited path: compile the same V0-sealed C17
  // one-slot row, then apply F-C18-01 to its completed marked outcomes.  C21
  // is compared through its public representation: quotient endpoints plus
  // the retained raw C17 edge.  Equality of the complete mathematical raw
  // outcome covers D, A, phase and every auxiliary causal mark while ignoring
  // only internal branch/stream provenance and never reaching into C21's
  // latent suspension.
  auto row_provider = mwperf::audited_row_provider(fixture.temporal.framework);
  REQUIRE(row_provider);
  const auto& c21_edge = projection.marked_edge();
  ExactRational expected_total = ExactRational::zero();
  std::size_t expected_atoms = 0U;
  for (const auto& event_mass : law.masses()) {
    if (!event_mass.exact_mass.is_positive()) {
      continue;
    }
    REQUIRE(event_mass.state_index < law.domain().states().size());
    const mwperf::ReducedStateV1& event_state =
        law.domain().states()[event_mass.state_index];
    auto c17_row = mwperf::compile_reduced_kernel_row(
        row_provider.value(), event_state);
    REQUIRE(c17_row);
    auto c18_row = mwperf::project_marked_row_to_endpoint(c17_row.value());
    REQUIRE(c18_row);
    REQUIRE(c17_row.value().atoms().size() ==
            c18_row.value().marked_atoms().size());
    REQUIRE(law.embedded_kernel()
                .rows()[event_mass.state_index]
                .endpoint_atoms.size() == 1U);
    CHECK(c18_row.value().exact_total_mass() == ExactRational::one());

    for (std::size_t index = 0U; index < c17_row.value().atoms().size();
         ++index) {
      const auto& c17_atom = c17_row.value().atoms()[index];
      const auto& c18_atom = c18_row.value().marked_atoms()[index];
      CHECK(c18_atom.edge.pre_state == c17_atom.edge.pre_state());
      CHECK(c18_atom.edge.successor_state ==
            c17_atom.edge.successor_state());
      CHECK(c18_atom.edge.marks ==
            std::vector<mwperf::CausalMarkV1>(
                c17_atom.edge.marks().begin(),
                c17_atom.edge.marks().end()));
      CHECK(c18_atom.exact_mass == c17_atom.exact_mass);
      if (!c18_atom.exact_mass.is_positive()) {
        continue;
      }

      const auto endpoint_index = law.embedded_kernel()
                                      .rows()[event_mass.state_index]
                                      .endpoint_atoms.front()
                                      .endpoint_index;
      REQUIRE(endpoint_index < law.domain().states().size());
      const mwperf::ReducedStateV1& stationary_right =
          law.domain().states()[endpoint_index];
      const ExactRational expected_mass =
          event_mass.exact_mass * c18_atom.exact_mass;
      const auto matching = std::find_if(
          c21_edge.atoms().begin(), c21_edge.atoms().end(),
          [&](const mwperf::StationaryMarkedEdgeAtomV1& candidate) {
            return candidate.stationary_left_state == event_state &&
                   candidate.stationary_right_state == stationary_right &&
                   mwperf::same_completed_reduced_outcome(
                       candidate.raw_edge, c17_atom.edge);
          });
      REQUIRE(matching != c21_edge.atoms().end());
      CHECK(matching->exact_mass == expected_mass);
      expected_total = expected_total + expected_mass;
      ++expected_atoms;
    }
  }
  CHECK(expected_total == ExactRational::one());
  CHECK(expected_atoms == c21_edge.atoms().size());
  CHECK(c21_edge.diagnostics().exact_total_mass == expected_total);
}

TEST_CASE("C21 checks configured slot-time phase occupation rather than the "
          "event marginal",
          "[c21][unit]") {
  auto fixture = c21::make_fixture();
  EventInvariantLaw law = select_event_law(fixture);
  const auto* event_a = event_mass_for_phase(law, 0U);
  const auto* event_b = event_mass_for_phase(law, 1U);
  REQUIRE(event_a != nullptr);
  REQUIRE(event_b != nullptr);
  CHECK(event_a->exact_mass == c21::rational(1, 2));
  CHECK(event_b->exact_mass == c21::rational(1, 2));
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, fixture.provider, mean));

  const auto& diagnostics = projection.temporal_law().diagnostics();
  CHECK(diagnostics.configured_phase_identity_available);
  CHECK(diagnostics.configured_phase_identity_matches);
  REQUIRE(diagnostics.phase_occupation.size() == 2U);
  for (const auto& atom : diagnostics.phase_occupation) {
    REQUIRE(atom.phase.canonical_state.size() == 1U);
    REQUIRE(atom.configured_exact_mass.has_value());
    const auto phase =
        std::to_integer<std::uint8_t>(atom.phase.canonical_state.front());
    const ExactRational expected =
        phase == 0U ? c21::rational(1, 4) : c21::rational(3, 4);
    CHECK(atom.exact_slot_mass == expected);
    CHECK(*atom.configured_exact_mass == expected);
    CHECK(atom.numerical_residual == 0.0L);
  }

  auto wrong_fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::equal_mixture, c21::rational(1, 2),
      c21::rational(1, 2));
  EventInvariantLaw wrong_law = select_event_law(wrong_fixture);
  PositiveFiniteMean wrong_mean = require_value(
      mwperf::compute_mean_residence(wrong_law, wrong_fixture.provider));
  const auto rejected = mwperf::build_stationary_temporal_projection(
      wrong_law, wrong_fixture.provider, wrong_mean);
  require_error(rejected, "c21.configured_slot_phase_identity_mismatch");
}

TEST_CASE("C21 retains distinct departure-arrival marks that share an "
          "endpoint",
          "[c21][unit]") {
  std::vector<C21MarkedEdgeFixtureAtomV1> atoms;
  atoms.push_back({edge_atom(0U, 0U), c21::rational(1, 2)});
  atoms.push_back({edge_atom(1U, 1U), c21::rational(1, 2)});
  const auto inspection = require_value(
      mwperf::testing::C21FixtureAccess::inspect_marked_edge_coalescing(
          std::move(atoms)));
  CHECK(inspection.retained_marked_atom_count == 2U);
  CHECK(inspection.endpoint_pushforward_atom_count == 1U);
  CHECK(inspection.exact_total_mass == ExactRational::one());
  CHECK(inspection.exact_departure_mass == c21::rational(1, 2));
  CHECK(inspection.exact_arrival_mass == c21::rational(1, 2));
  CHECK(inspection.exact_queue_updates_hold);
  CHECK(inspection.exact_left_right_marginals_equal);
  CHECK(inspection.exact_endpoint_invariance_holds);
}

TEST_CASE("C21 requires an explicit valid selection for reducible event "
          "classes",
          "[c21][unit]") {
  auto unique_fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::unique, c21::rational(1, 4),
      c21::rational(3, 4));
  const auto missing = mwperf::select_event_invariant_law(
      unique_fixture.kernel, c21::configured_selection(unique_fixture),
      c21::solver_policy(unique_fixture));
  require_error(missing, "c21.event_class_selection_required");

  auto unknown_fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::unknown_class, c21::rational(1, 4),
      c21::rational(3, 4));
  const auto unknown = mwperf::select_event_invariant_law(
      unknown_fixture.kernel, c21::configured_selection(unknown_fixture),
      c21::solver_policy(unknown_fixture));
  require_error(unknown, "c21.unknown_event_class");

  auto mixture_fixture = c21::make_fixture();
  const auto foreign_selector = mwperf::select_event_invariant_law(
      mixture_fixture.kernel, c21::unique_selection(),
      c21::solver_policy(mixture_fixture));
  require_error(foreign_selector, "c21.event_selection_binding_mismatch");

  const mwperf::SelectionSpec empty_mixture =
      mwperf::StationaryMixtureSelection{{}, c21::source("/empty-mixture")};
  const auto empty = mwperf::select_event_invariant_law(
      mixture_fixture.kernel, empty_mixture,
      c21::solver_policy(mixture_fixture));
  require_error(empty, "c21.empty_event_class_mixture");

  std::vector<mwperf::StationaryMixtureComponent> duplicates;
  duplicates.push_back(
      {mwperf::TypedLabel::numeric(BigNat{0U}),
       c21::probability(c21::rational(1, 2)),
       c21::source("/duplicate-mixture/components/0")});
  duplicates.push_back(
      {mwperf::TypedLabel::numeric(BigNat{0U}),
       c21::probability(c21::rational(1, 2)),
       c21::source("/duplicate-mixture/components/1")});
  const mwperf::SelectionSpec duplicate_mixture =
      mwperf::StationaryMixtureSelection{
          std::move(duplicates), c21::source("/duplicate-mixture")};
  const auto duplicate = mwperf::select_event_invariant_law(
      mixture_fixture.kernel, duplicate_mixture,
      c21::solver_policy(mixture_fixture));
  require_error(duplicate, "c21.duplicate_event_mixture_class");

  std::vector<mwperf::StationaryMixtureComponent> zero_components;
  zero_components.push_back(
      {mwperf::TypedLabel::numeric(BigNat{0U}),
       c21::probability(ExactRational::zero()),
       c21::source("/zero-mixture/components/0")});
  zero_components.push_back(
      {mwperf::TypedLabel::numeric(BigNat{1U}),
       c21::probability(ExactRational::zero()),
       c21::source("/zero-mixture/components/1")});
  const mwperf::SelectionSpec zero_mixture =
      mwperf::StationaryMixtureSelection{
          std::move(zero_components), c21::source("/zero-mixture")};
  const auto zero = mwperf::select_event_invariant_law(
      mixture_fixture.kernel, zero_mixture,
      c21::solver_policy(mixture_fixture));
  require_error(zero, "c21.nonpositive_event_mixture_total");
}

TEST_CASE("C21 implicitly selects the sole closed event class",
          "[c21][unit]") {
  auto fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::unique, ExactRational::one(),
      ExactRational::zero(), false, 3U, true);
  EventInvariantLaw law = select_event_law(fixture);
  REQUIRE(law.diagnostics().classes.size() == 1U);
  REQUIRE(law.diagnostics().closed_class_indices.size() == 1U);
  REQUIRE(law.selected_classes().size() == 1U);
  REQUIRE(law.masses().size() == 1U);
  CHECK(law.selected_classes().front().exact_weight == ExactRational::one());
  CHECK(law.masses().front().exact_mass == ExactRational::one());
  CHECK(c21::phase(law.domain().states().front()) == 0U);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  REQUIRE(mean.exact_value().has_value());
  CHECK(*mean.exact_value() == ExactRational::one());
}

TEST_CASE("C21 normalizes positive nonunit event mixture weights",
          "[c21][unit]") {
  auto fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::nonunit_equal_mixture);
  std::vector<mwperf::StationaryMixtureComponent> components;
  components.push_back(
      {mwperf::TypedLabel::numeric(BigNat{0U}),
       c21::probability(c21::rational(1, 1)),
       c21::source("/direct-selection/components/0")});
  components.push_back(
      {mwperf::TypedLabel::numeric(BigNat{1U}),
       c21::probability(c21::rational(1, 1)),
       c21::source("/direct-selection/components/1")});
  const mwperf::SelectionSpec nonunit = mwperf::StationaryMixtureSelection{
      std::move(components), c21::source("/direct-selection")};

  EventInvariantLaw law = require_value(mwperf::select_event_invariant_law(
      fixture.kernel, nonunit, c21::solver_policy(fixture)));
  REQUIRE(law.selected_classes().size() == 2U);
  CHECK(law.selected_classes()[0].exact_weight == c21::rational(1, 2));
  CHECK(law.selected_classes()[1].exact_weight == c21::rational(1, 2));
}

TEST_CASE("C21 excludes a transient event SCC from the implicit invariant "
          "law",
          "[c21][unit]") {
  auto fixture = c21::make_transient_fixture();
  const auto transient_index = fixture.domain.index_of(fixture.class_a);
  const auto closed_index = fixture.domain.index_of(fixture.class_b);
  REQUIRE(transient_index.has_value());
  REQUIRE(closed_index.has_value());
  REQUIRE(*transient_index != *closed_index);

  EventInvariantLaw law = select_event_law(fixture);
  REQUIRE(law.diagnostics().classes.size() == 3U);
  REQUIRE(law.diagnostics().closed_class_indices.size() == 1U);
  REQUIRE(law.diagnostics().transient_state_indices.size() == 2U);
  CHECK(std::ranges::find(law.diagnostics().transient_state_indices,
                          *transient_index) !=
        law.diagnostics().transient_state_indices.end());

  const std::size_t closed_class_index =
      law.diagnostics().closed_class_indices.front();
  REQUIRE(closed_class_index < law.diagnostics().classes.size());
  const auto& closed_class =
      law.diagnostics().classes[closed_class_index];
  CHECK(closed_class.closed);
  REQUIRE(closed_class.member_indices.size() == 2U);
  CHECK(std::ranges::find(closed_class.member_indices, *closed_index) !=
        closed_class.member_indices.end());

  REQUIRE(law.selected_classes().size() == 1U);
  CHECK(law.selected_classes().front().class_index == closed_class_index);
  CHECK(law.selected_classes().front().exact_weight ==
        ExactRational::one());

  const auto mass_at = [&](const std::size_t state_index)
      -> const mwperf::EventInvariantMassV1* {
    const auto found = std::ranges::find_if(
        law.masses(), [&](const mwperf::EventInvariantMassV1& mass) {
          return mass.state_index == state_index;
        });
    return found == law.masses().end() ? nullptr : &*found;
  };
  const auto* transient_mass = mass_at(*transient_index);
  const auto* closed_mass = mass_at(*closed_index);
  REQUIRE(transient_mass != nullptr);
  REQUIRE(closed_mass != nullptr);
  CHECK(transient_mass->exact_mass == ExactRational::zero());
  for (const std::size_t state_index :
       law.diagnostics().transient_state_indices) {
    const auto* mass = mass_at(state_index);
    REQUIRE(mass != nullptr);
    CHECK(mass->exact_mass == ExactRational::zero());
  }
  CHECK(closed_mass->exact_mass == c21::rational(1, 2));
  ExactRational closed_total = ExactRational::zero();
  for (const std::size_t state_index : closed_class.member_indices) {
    const auto* mass = mass_at(state_index);
    REQUIRE(mass != nullptr);
    CHECK(mass->exact_mass == c21::rational(1, 2));
    closed_total = closed_total + mass->exact_mass;
  }
  CHECK(closed_total == ExactRational::one());

  // Canonical state ordering assigns the zero-backlog closed class id zero
  // and the backlog-two, phase-zero transient class id one.  A source sealed
  // to that transient selector must be rejected rather than silently
  // redirected to the sole closed class.
  auto transient_selection_fixture = c21::make_transient_fixture(
      c21::EventSelectionFixtureV1::transient_class);
  const auto rejected = mwperf::select_event_invariant_law(
      transient_selection_fixture.kernel,
      c21::configured_selection(transient_selection_fixture),
      c21::solver_policy(transient_selection_fixture));
  require_error(rejected, "c21.transient_event_class_selected");
}

TEST_CASE("C21 rejects foreign provider and denominator provenance before "
          "stationary traversal",
          "[c21][unit]") {
  auto fixture_a = c21::make_fixture();
  auto fixture_b = c21::make_fixture(
      c21::EventSelectionFixtureV1::equal_mixture, c21::rational(1, 3),
      c21::rational(2, 3), false, 2U);
  EventInvariantLaw law_a = select_event_law(fixture_a);
  EventInvariantLaw law_b = select_event_law(fixture_b);
  PositiveFiniteMean mean_a = require_value(
      mwperf::compute_mean_residence(law_a, fixture_a.provider));
  PositiveFiniteMean mean_b = require_value(
      mwperf::compute_mean_residence(law_b, fixture_b.provider));

  const auto foreign_provider =
      mwperf::compute_mean_residence(law_a, fixture_b.provider);
  require_error(foreign_provider,
                "c20.stationary_foreign_residence_provider");

  const auto foreign_mean = mwperf::suspend_event_law_to_slots(
      law_a, fixture_a.provider, mean_b, length_bias_reward_decoder());
  require_error(foreign_mean,
                "c21.event_law_denominator_binding_mismatch");

  const auto foreign_three_way = mwperf::suspend_event_law_to_slots(
      law_a, fixture_b.provider, mean_a, length_bias_reward_decoder());
  require_error(foreign_three_way,
                "c20.stationary_foreign_residence_provider");

  const auto projection_foreign_mean =
      mwperf::build_stationary_temporal_projection(
          law_a, fixture_a.provider, mean_b);
  require_error(projection_foreign_mean,
                "c21.event_law_denominator_binding_mismatch");

  const auto projection_foreign_provider =
      mwperf::build_stationary_temporal_projection(
          law_a, fixture_b.provider, mean_a);
  require_error(projection_foreign_provider,
                "c20.stationary_foreign_residence_provider");
}

TEST_CASE("C21 mean evidence rejects zero, infinite, uncertified, and "
          "overflowing residence expectations",
          "[c21][unit]") {
  const auto zero =
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::finite_exact,
                        ExactRational::zero(), ExactRational::zero(),
                        ExactRational::zero()));
  require_error(zero, "c21.nonpositive_or_invalid_mean_residence");

  const auto infinite =
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::positive_infinity,
                        ExactRational::one(), ExactRational::one(),
                        std::nullopt, ExactRational::zero(), std::nullopt,
                        false, true));
  require_error(infinite, "c21.infinite_mean_residence");

  const auto uncertified =
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::uncertified_tail,
                        ExactRational::one(), ExactRational::one(),
                        std::nullopt, ExactRational::zero(), std::nullopt,
                        false, false));
  require_error(uncertified, "c21.mean_residence_tail_uncertified");

  const auto overflow =
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::arithmetic_overflow,
                        ExactRational::one(), ExactRational::one(),
                        std::nullopt));
  require_error(overflow, "c21.mean_residence_arithmetic_overflow");
}

TEST_CASE("C21 refuses the normalized harmonic-tail residence law whose "
          "mean diverges",
          "[c21][unit]") {
  // p_k = 1/[k(k+1)] telescopes.  At every finite cutoff N, the enumerated
  // mass is N/(N+1) and the exact residual tail is 1/(N+1), so the complete
  // countable law has unit mass without truncation or renormalization.
  ExactRational probability_prefix = ExactRational::zero();
  ExactRational mean_prefix = ExactRational::zero();
  // Five blocks keep this checkpoint's deliberately bounded audit harness in
  // range; the same block inequality below is independent of the cutoff and
  // therefore supplies the unbounded sequence of lower bounds.
  constexpr std::int64_t kDyadicBlocks = 5;
  constexpr std::int64_t kCutoff =
      (std::int64_t{1} << kDyadicBlocks) - 1;
  for (std::int64_t k = 1; k <= kCutoff; ++k) {
    const ExactRational probability = c21::rational(1, k * (k + 1));
    probability_prefix = probability_prefix + probability;
    mean_prefix = mean_prefix + c21::rational(1, k + 1);
  }
  const ExactRational residual_tail =
      c21::rational(1, kCutoff + 1);
  CHECK(probability_prefix ==
        c21::rational(kCutoff, kCutoff + 1));
  CHECK(probability_prefix + residual_tail == ExactRational::one());

  // Each dyadic block k=2^b,...,2^(b+1)-1 contributes at least 1/2
  // to sum 1/(k+1).  Hence these exact partial means exceed an arbitrarily
  // increasing sequence of lower bounds; finite residence almost surely
  // therefore does not establish a finite residence mean.
  CHECK(mean_prefix >= c21::rational(kDyadicBlocks, 2));
  const auto infinite =
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::positive_infinity,
                        mean_prefix, mean_prefix, std::nullopt,
                        residual_tail, std::nullopt, false, true));
  require_error(infinite, "c21.infinite_mean_residence");
}

TEST_CASE("C21 mean evidence keeps exact and certified-tail diagnostics "
          "distinct",
          "[c21][unit]") {
  const auto exact = require_value(
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::finite_exact,
                        c21::rational(2, 1), c21::rational(2, 1),
                        c21::rational(2, 1))));
  REQUIRE(exact.exact_value.has_value());
  CHECK(*exact.exact_value == c21::rational(2, 1));
  CHECK(exact.exact_tail_lower_bound.is_zero());
  CHECK(exact.exact_tail_upper_bound.is_zero());
  CHECK(exact.support_complete);
  CHECK(exact.tail_certified);

  // A large exact rational with a finite promoted image exercises the range
  // guard without converting a finite prefix or sample maximum into a proof.
  const ExactRational heavy = c21::rational(9000000000000000LL, 1);
  const auto certified = require_value(
      mwperf::testing::C21FixtureAccess::inspect_positive_finite_mean_evidence(
          mean_evidence(C21MeanEvidenceKindV1::certified_finite_enclosure,
                        heavy, heavy, heavy, ExactRational::zero(),
                        ExactRational::zero(), false, true)));
  CHECK_FALSE(certified.exact_value.has_value());
  CHECK(certified.exact_lower_bound == heavy);
  CHECK(certified.exact_upper_bound == heavy);
  CHECK(certified.tail_certified);
  CHECK(std::isfinite(certified.numerical_value));
  CHECK(certified.numerical_value > 0.0L);
  CHECK(certified.range_status != mwperf::ResidenceRangeStatusV1::overflow);
  CHECK(certified.range_status !=
        mwperf::ResidenceRangeStatusV1::numerically_unresolved);
}

TEST_CASE("C21 enforces signed and nonnegative reward integrability at the "
          "stationary boundary",
          "[c21][unit]") {
  auto fixture = c21::make_fixture();
  EventInvariantLaw law = select_event_law(fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));

  const auto signed_infinity = mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean,
      constant_reward_decoder(
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          std::numeric_limits<long double>::infinity()));
  require_error(signed_infinity,
                "c21.reward_integrability_not_established");

  const auto signed_nan = mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean,
      constant_reward_decoder(
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          std::numeric_limits<long double>::quiet_NaN()));
  require_error(signed_nan, "c21.reward_integrability_not_established");

  const auto negative_nonnegative = mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean,
      constant_reward_decoder(
          mwperf::StationaryRewardIntegrabilityV1::nonnegative_extended_real,
          -1.0L));
  require_error(negative_nonnegative,
                "c21.reward_integrability_not_established");

  const auto nonnegative_infinity = require_value(
      mwperf::suspend_event_law_to_slots(
          law, fixture.provider, mean,
          constant_reward_decoder(
              mwperf::StationaryRewardIntegrabilityV1::
                  nonnegative_extended_real,
              std::numeric_limits<long double>::infinity())));
  const auto envelope = require_value(
      mwperf::testing::C21FixtureAccess::decode_metric_envelope(
          nonnegative_infinity));
  CHECK(envelope.positive_infinity);
  CHECK_FALSE(envelope.exact_numerator.has_value());
  CHECK_FALSE(envelope.exact_ratio.has_value());
  CHECK(envelope.exact_denominator == c21::rational(2, 1));
}

TEST_CASE("C21 rejects a one-edge reward whose declared mark is absent",
          "[c21][unit]") {
  auto fixture = c21::make_fixture();
  EventInvariantLaw law = select_event_law(fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, fixture.provider));
  std::vector<mwperf::RequiredStationaryMarkV1> required{{
      mark_id("c21.test.absent-mark"), {"c21.test.absent-codec", 1U},
      mwperf::CausalStageV1::psi}};
  const auto rejected = mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean,
      constant_reward_decoder(
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute, 1.0L,
          mwperf::StationaryRewardDomainV1::one_edge,
          std::move(required)));
  require_error(rejected, "c14_capability_missing_mark");

  std::vector<mwperf::RequiredStationaryMarkV1> too_early{{
      mwperf::testing::c20_reset_audited::raw_age_mark(),
      mwperf::testing::c20_reset_audited::kAgeCodec,
      mwperf::CausalStageV1::c_plus}};
  const auto reveal_incompatible = mwperf::suspend_event_law_to_slots(
      law, fixture.provider, mean,
      constant_reward_decoder(
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute, 1.0L,
          mwperf::StationaryRewardDomainV1::one_edge,
          std::move(too_early)));
  require_error(reveal_incompatible, "c14_capability_missing_mark");
}

TEST_CASE("C21 stationary PMF preserves the complete law and finite output "
          "window",
          "[c21][unit]") {
  const auto complete_result = evaluate_configured_metric(
      c21::ProjectionPlanFixtureV1::stationary_pmf);
  const auto complete = require_value(
      mwperf::testing::C21FixtureAccess::decode_stationary_backlog_pmf(
          complete_result.value));
  CHECK(complete.source_fingerprint ==
        complete_result.projection_fingerprint);
  CHECK(complete.complete_domain);
  CHECK_FALSE(complete.max_level.has_value());
  REQUIRE(complete.atoms.size() == 1U);
  CHECK(complete.atoms.front().level == BigNat{1U});
  CHECK(complete.atoms.front().exact_mass == ExactRational::one());
  CHECK(complete.exact_returned_mass == ExactRational::one());
  CHECK(complete.exact_omitted_tail_mass.is_zero());

  const auto window_result = evaluate_configured_metric(
      c21::ProjectionPlanFixtureV1::stationary_pmf_window);
  const auto window = require_value(
      mwperf::testing::C21FixtureAccess::decode_stationary_backlog_pmf(
          window_result.value));
  CHECK(window.source_fingerprint == window_result.projection_fingerprint);
  CHECK_FALSE(window.complete_domain);
  REQUIRE(window.max_level.has_value());
  CHECK(*window.max_level == BigNat{0U});
  CHECK(window.atoms.empty());
  CHECK(window.exact_returned_mass.is_zero());
  CHECK(window.exact_omitted_tail_mass == ExactRational::one());
}

TEST_CASE("C21 stationary PGF evaluates every configured point exactly",
          "[c21][unit]") {
  const auto result = evaluate_configured_metric(
      c21::ProjectionPlanFixtureV1::stationary_pgf);
  const auto pgf = require_value(
      mwperf::testing::C21FixtureAccess::decode_stationary_backlog_pgf(
          result.value));
  CHECK(pgf.source_fingerprint == result.projection_fingerprint);
  const std::vector<ExactRational> expected{
      ExactRational::zero(), c21::rational(1, 2), ExactRational::one(),
      c21::rational(2, 1)};
  REQUIRE(pgf.atoms.size() == expected.size());
  for (std::size_t index = 0U; index < expected.size(); ++index) {
    CHECK(pgf.atoms[index].point == expected[index]);
    // The fixture's ordinary-slot backlog is identically one, so G(z)=z.
    CHECK(pgf.atoms[index].exact_value == expected[index]);
  }
}

TEST_CASE("C21 stationary quantile uses the exact lower inverse CDF",
          "[c21][unit]") {
  const auto result = evaluate_configured_metric(
      c21::ProjectionPlanFixtureV1::stationary_quantile);
  const auto quantile = require_value(
      mwperf::testing::C21FixtureAccess::decode_stationary_backlog_quantile(
          result.value));
  CHECK(quantile.source_fingerprint == result.projection_fingerprint);
  CHECK(quantile.probability == c21::rational(1, 2));
  CHECK(quantile.convention ==
        mwperf::DiscreteQuantileConventionV1::lower_inverse_cdf);
  CHECK(quantile.quantile == BigNat{1U});
  CHECK(quantile.exact_cdf_below.is_zero());
  CHECK(quantile.exact_cdf_at_quantile == ExactRational::one());
}

TEST_CASE("C21 distribution dispatch requires the exact matching C14 "
          "stationary contract",
          "[c21][unit]") {
  auto pmf_fixture = c21::make_plan_fixture(
      c21::ProjectionPlanFixtureV1::stationary_pmf);
  EventInvariantLaw law = select_event_law(pmf_fixture);
  PositiveFiniteMean mean = require_value(
      mwperf::compute_mean_residence(law, pmf_fixture.provider));
  StationaryTemporalProjection projection = require_value(
      mwperf::build_stationary_temporal_projection(
          law, pmf_fixture.provider, mean));

  auto pgf_fixture = c21::make_plan_fixture(
      c21::ProjectionPlanFixtureV1::stationary_pgf);
  const auto foreign_request = require_value(mwperf::parse_metric_request(
      pgf_fixture.temporal.instance.analysis_spec().metrics.front(),
      pgf_fixture.temporal.instance.queues()));
  const auto rejected = mwperf::evaluate_stationary_temporal_metric(
      projection.temporal_law(), foreign_request);
  require_error(rejected, "c14_capability_stationary_route_not_accepted");
}

TEST_CASE("C21 refuses stationary suspension without a configured slot "
          "phase law",
          "[c21][unit]") {
  const auto rejected = mwperf::testing::C21FixtureAccess::
      inspect_missing_configured_phase_law_requirement();
  require_error(rejected, "c21.configured_slot_phase_law_unavailable");
}
