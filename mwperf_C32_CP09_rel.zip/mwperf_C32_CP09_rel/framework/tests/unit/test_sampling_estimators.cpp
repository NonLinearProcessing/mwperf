#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/sampling/estimators.hpp"

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix =
    mwperf::testing::c16_registered_pair_matrix;

constexpr long double kTolerance = 1.0e-12L;

[[nodiscard]] mwperf::Digest256 zero_digest() {
  const std::array<std::byte, mwperf::Digest256::kSize> bytes{};
  return mwperf::Digest256::from_bytes(bytes).value();
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] bool close(const long double left, const long double right,
                         const long double tolerance = kTolerance) {
  return std::fabs(left - right) <= tolerance;
}

[[nodiscard]] mwperf::KernelTransitionV1 atom(
    const mwperf::ConditioningState& state, const std::uint8_t value) {
  const mwperf::CodecIdentityV1 mark_codec{
      "mwperf.c23.typed_label", 1U};
  const std::byte byte = static_cast<std::byte>(value);
  return {state,
          {{mark_codec, {byte}},
           {mark_codec, {byte}},
           {mark_codec, {byte}}}};
}

[[nodiscard]] std::uint8_t atom_value(const mwperf::Sample& sample) {
  REQUIRE_FALSE(sample.ordered_marks.empty());
  REQUIRE_FALSE(sample.ordered_marks.front().canonical_value.empty());
  return std::to_integer<std::uint8_t>(
      sample.ordered_marks.front().canonical_value.front());
}

[[nodiscard]] std::size_t canonical_runtime_bytes(
    const mwperf::CanonicalRuntimeValueV1& value) {
  return value.codec.id.size() + value.canonical_value.size();
}

[[nodiscard]] std::size_t canonical_sample_bytes(
    const mwperf::Sample& sample) {
  std::size_t total = canonical_runtime_bytes(sample.successor_state);
  for (const auto& mark : sample.ordered_marks) {
    total += canonical_runtime_bytes(mark);
  }
  return total;
}

[[nodiscard]] mwperf::KernelTransitionV1 cu_atom(
    const mwperf::ConditioningState& state, const std::uint8_t c,
    const std::uint8_t u) {
  const mwperf::CodecIdentityV1 mark_codec{
      "mwperf.c23.typed_label", 1U};
  return {state,
          {{mark_codec, {static_cast<std::byte>(c)}},
           {mark_codec, {static_cast<std::byte>(u)}},
           {mark_codec, {static_cast<std::byte>(u)}}}};
}

[[nodiscard]] std::uint8_t mark_value(const mwperf::Sample& sample,
                                      const std::size_t index) {
  REQUIRE(index < sample.ordered_marks.size());
  REQUIRE_FALSE(sample.ordered_marks[index].canonical_value.empty());
  return std::to_integer<std::uint8_t>(
      sample.ordered_marks[index].canonical_value.front());
}

[[nodiscard]] mwperf::ConditionalSamplerContractV1 sampler_contract(
    const std::string_view prefix, const std::size_t support_size,
    const mwperf::ConditionalSampleDependenceV1 dependence) {
  const auto keyed = [prefix](const std::string_view suffix) {
    return matrix::digest(std::string(prefix) + "." + std::string(suffix));
  };
  return {1U,
          mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
          dependence,
          mwperf::ConditionalSupportKindV1::finite_declared,
          support_size,
          matrix::digest("c17.fixture.reduced-state-schema"),
          keyed("support"),
          keyed("proposal"),
          keyed("residual"),
          keyed("output"),
          keyed("arrival"),
          keyed("common"),
          true,
          true,
          true,
          true,
          true,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerV1EvidenceScopeV1::none,
          std::nullopt,
          mwperf::SamplerV2EvidenceScopeV1::none,
          std::nullopt,
          std::nullopt};
}

[[nodiscard]] matrix::C17TemporalFixtureOverrideV1 sampler_override(
    const std::string_view prefix, const std::size_t support_size,
    const mwperf::ConditionalSampleDependenceV1 dependence,
    const std::optional<std::uint8_t> constant = std::nullopt) {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_sampler_contract =
      sampler_contract(prefix, support_size, dependence);
  override.conditional_sampler_operation =
      [support_size, constant](const mwperf::CanonicalRuntimeValueV1& state,
                               mwperf::DeterministicRng& rng) {
        const std::uint8_t selected = constant.has_value()
            ? *constant
            : static_cast<std::uint8_t>(
                  rng.next_u64() %
                  static_cast<std::uint64_t>(support_size));
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            atom(state, selected));
      };
  override.conditional_support_enumerator =
      [support_size](const mwperf::CanonicalRuntimeValueV1& state) {
        std::vector<mwperf::KernelTransitionV1> support;
        support.reserve(support_size);
        for (std::size_t index = 0U; index < support_size; ++index) {
          support.push_back(atom(state, static_cast<std::uint8_t>(index)));
        }
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            std::move(support));
      };
  override.conditional_support_query =
      [support_size](const mwperf::CanonicalRuntimeValueV1& state,
                     const mwperf::KernelTransitionV1& sample) {
        const bool shaped = sample.successor_state == state &&
                            sample.ordered_marks.size() == 3U &&
                            !sample.ordered_marks.front()
                                 .canonical_value.empty();
        const bool in_range =
            shaped && atom_value(sample) < support_size;
        return mwperf::Result<bool>::success(in_range);
      };
  return override;
}

struct SealedSamplerFixture final {
  mwperf::AuditedCompiledFramework framework;
  mwperf::NormalizedSamplerAccess sampler;
  mwperf::ConditioningState row;
};

[[nodiscard]] SealedSamplerFixture seal_sampler(
    const matrix::C17TemporalFixtureOverrideV1& override,
    const std::uint64_t replications,
    const mwperf::StatisticalIntervalKindV1 interval =
        mwperf::StatisticalIntervalKindV1::none,
    const mwperf::BackendRouteKindV1 accepted_backend_route =
        mwperf::BackendRouteKindV1::conditional_reward_monte_carlo) {
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, replications, interval, accepted_backend_route,
      [](mwperf::ExactCausalProgramV1&) {});
  const mwperf::ConditioningState row = prepared.initial_state;
  auto framework_result = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework_result ? std::string{}
                         : framework_result.error().code + ": " +
                               framework_result.error().message));
  REQUIRE(framework_result);
  auto framework = std::move(framework_result).value();
  auto descriptor = mwperf::audited_sampler_descriptor(framework);
  REQUIRE(descriptor);
  auto sampler =
      mwperf::validate_conditional_generator(descriptor.value());
  INFO((sampler ? std::string{}
                : sampler.error().code + ": " + sampler.error().message));
  REQUIRE(sampler);
  return {std::move(framework), std::move(sampler).value(), row};
}

[[nodiscard]] SealedSamplerFixture seal_row_sampler(
    const matrix::C17TemporalFixtureOverrideV1& override,
    const std::uint64_t replications) {
  return seal_sampler(
      override, replications, mwperf::StatisticalIntervalKindV1::none,
      mwperf::BackendRouteKindV1::conditional_row_monte_carlo);
}

[[nodiscard]] mwperf::SamplingPlanSpecV1 plan_spec(
    const std::uint64_t replications, const std::uint64_t seed,
    std::string estimator_id, const mwperf::Digest256& target,
    const mwperf::StatisticalIntervalKindV1 interval =
        mwperf::StatisticalIntervalKindV1::none,
    const mwperf::StatisticalEstimandKindV1 estimand =
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
    std::optional<mwperf::ExactRational> lower = std::nullopt,
    std::optional<mwperf::ExactRational> upper = std::nullopt,
    const mwperf::StageTag stage = mwperf::StageTag::generic_sampling,
    const bool rao_blackwell = false,
    std::optional<mwperf::TotalVariationRequestV1> tv = std::nullopt) {
  // The C24 fixture requests the binary departure reward from C14.  Even
  // when no interval is requested, that accepted clause retains its authored
  // [0,1] almost-sure range and C24 must reproduce it exactly.
  if (interval == mwperf::StatisticalIntervalKindV1::none &&
      estimand == mwperf::StatisticalEstimandKindV1::
                      point_with_variance_diagnostics &&
      !lower.has_value() && !upper.has_value()) {
    lower = mwperf::ExactRational::zero();
    upper = mwperf::ExactRational::one();
  }
  return {{mwperf::BigNat{replications}, rational(95, 100), interval,
           estimand, std::move(lower), std::move(upper)},
          mwperf::MasterSeed{seed},
          std::move(estimator_id),
          target,
          mwperf::BigNat{replications},
          stage,
          true,
          rao_blackwell,
          std::move(tv)};
}

[[nodiscard]] mwperf::SamplingPlan make_plan(
    const mwperf::NormalizedSamplerAccess& sampler,
    mwperf::SamplingPlanSpecV1 spec) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  spec.metric_target_digest =
      sampler.accepted_sampling_clauses().front().metric_target_digest;
  auto plan = mwperf::SamplingPlan::from_accepted_clause(
      sampler, std::move(spec));
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  return std::move(plan).value();
}

[[nodiscard]] const mwperf::Digest256& accepted_target(
    const mwperf::NormalizedSamplerAccess& sampler) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  return sampler.accepted_sampling_clauses().front().metric_target_digest;
}

using RewardFunction = std::function<mwperf::Result<long double>(
    const mwperf::ConditioningState&, const mwperf::Sample&)>;

[[nodiscard]] mwperf::RewardDecoder reward_decoder(
    const std::string_view id, const mwperf::Digest256& decoder_digest,
    const mwperf::Digest256& target,
    const mwperf::Digest256& output_schema, RewardFunction decode,
    const bool binary = false,
    std::optional<mwperf::ExactRational> lower = std::nullopt,
    std::optional<mwperf::ExactRational> upper = std::nullopt) {
  auto conditional =
      std::make_shared<const mwperf::ConditionalSamplingRewardV1>(
          mwperf::ConditionalSamplingRewardV1{
              std::string(id), decoder_digest, target, output_schema,
              mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
              binary, std::move(lower), std::move(upper),
              std::move(decode), true});
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          {},
          {"c24.reward.scalar", 1U},
          std::move(conditional)};
}

[[nodiscard]] RewardFunction byte_reward(
    const std::function<long double(std::uint8_t)>& transform) {
  return [transform](const mwperf::ConditioningState&,
                     const mwperf::Sample& sample) {
    return mwperf::Result<long double>::success(
        transform(atom_value(sample)));
  };
}

void attach_ratio(
    matrix::C17TemporalFixtureOverrideV1& override,
    const mwperf::Digest256& target,
    const mwperf::Digest256& decoder_digest,
    mwperf::ConditionalTargetRatioCallbackV1 ratio,
    const bool domination = true,
    const bool finite_mean = true,
    const bool integrable = true,
    const bool iid = true) {
  (void)target;
  REQUIRE(override.conditional_sampler_contract.has_value());
  const auto& sampler = *override.conditional_sampler_contract;
  override.target_ratio_contract = mwperf::ConditionalTargetRatioContractV1{
      1U,
      mwperf::ImportanceTargetKindV1::transition_row,
      matrix::digest("c24.importance.target-law"),
      zero_digest(),
      decoder_digest,
      sampler.residual_schema,
      sampler.output_schema,
      domination,
      finite_mean,
      integrable,
      iid,
      true,
      true};
  override.target_ratio_operation = std::move(ratio);
}

void attach_innovation(
    matrix::C17TemporalFixtureOverrideV1& override,
    const mwperf::Digest256& decoder_digest,
    mwperf::ConditionalExactInnovationCallbackV1 innovation,
    mwperf::ExactRational maximum_absolute_error =
        mwperf::ExactRational::zero()) {
  REQUIRE(override.conditional_sampler_contract.has_value());
  const auto& sampler = *override.conditional_sampler_contract;
  override.exact_innovation_contract =
      mwperf::ConditionalExactInnovationContractV1{
          1U,
          matrix::digest("c24.innovation.representation"),
          zero_digest(),
          sampler.configured_arrival_law,
          decoder_digest,
          sampler.residual_schema,
          sampler.output_schema,
          true,
          std::move(maximum_absolute_error)};
  override.exact_innovation_operation = std::move(innovation);
}

}  // namespace

TEST_CASE("C24 fixed-support TV budgets match the exact checkpoint goldens",
          "[c24][unit][plan][tv]") {
  const auto two = mwperf::SamplingPlan::sufficient_iid_tv_budget(
      2U, 0.1L, 0.05L);
  REQUIRE(two);
  CHECK(two.value() == mwperf::BigNat{220U});

  const auto three = mwperf::SamplingPlan::sufficient_iid_tv_budget(
      3U, 0.25L, 0.1L);
  REQUIRE(three);
  CHECK(three.value() == mwperf::BigNat{36U});

  const auto simultaneous =
      mwperf::SamplingPlan::sufficient_iid_tv_budget(
          2U, 0.1L, 0.05L, 10U);
  REQUIRE(simultaneous);
  CHECK(simultaneous.value() == mwperf::BigNat{335U});

  const auto unaddressable =
      mwperf::SamplingPlan::sufficient_iid_tv_budget(
          2U, std::numeric_limits<long double>::denorm_min(), 0.05L);
  REQUIRE_FALSE(unaddressable);
  CHECK(unaddressable.error().code == "c24.tv_budget_not_addressable");

  CHECK_FALSE(mwperf::SamplingPlan::sufficient_iid_tv_budget(
      0U, 0.1L, 0.05L));
  CHECK_FALSE(mwperf::SamplingPlan::sufficient_iid_tv_budget(
      2U, 0.0L, 0.05L));
  CHECK_FALSE(mwperf::SamplingPlan::sufficient_iid_tv_budget(
      2U, 0.1L, 1.0L));
}

TEST_CASE("C24 rejects nonfixed or empty sampling plans before any draw",
          "[c24][negative][plan][transactional]") {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto fixture = seal_sampler(override, 4U);
  const auto target = accepted_target(fixture.sampler);

  auto zero = plan_spec(0U, 1U, "c24.plan.zero", target);
  const auto zero_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(zero));
  REQUIRE_FALSE(zero_result);
  CHECK(zero_result.error().code == "c24.invalid_fixed_sampling_plan");

  auto capped = plan_spec(4U, 1U, "c24.plan.cap", target);
  capped.draw_cap = mwperf::BigNat{3U};
  const auto cap_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(capped));
  REQUIRE_FALSE(cap_result);
  CHECK(cap_result.error().code == "c24.invalid_fixed_sampling_plan");

  auto adaptive = plan_spec(4U, 1U, "c24.plan.adaptive", target);
  adaptive.fixed_budget = false;
  const auto adaptive_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(adaptive));
  REQUIRE_FALSE(adaptive_result);
  CHECK(adaptive_result.error().code == "c24.invalid_fixed_sampling_plan");

  auto unknown = plan_spec(4U, 1U, "c24.plan.unknown", target);
  unknown.accuracy.interval =
      static_cast<mwperf::StatisticalIntervalKindV1>(255U);
  const auto unknown_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(unknown));
  REQUIRE_FALSE(unknown_result);
  CHECK(unknown_result.error().code == "c24.unsupported_interval_method");

  auto binomial_without_range = plan_spec(
      4U, 1U, "c24.plan.binomial-missing-range", target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion);
  const auto missing_range_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(binomial_without_range));
  REQUIRE_FALSE(missing_range_result);
  CHECK(missing_range_result.error().code ==
        "c24.exact_binomial_estimand_mismatch");

  auto binomial_wrong_range = plan_spec(
      4U, 1U, "c24.plan.binomial-wrong-range", target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), rational(2, 1));
  const auto wrong_range_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(binomial_wrong_range));
  REQUIRE_FALSE(wrong_range_result);
  CHECK(wrong_range_result.error().code ==
        "c24.exact_binomial_estimand_mismatch");

  auto none_binary = plan_spec(
      4U, 1U, "c24.plan.none-binary", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto none_binary_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(none_binary));
  REQUIRE_FALSE(none_binary_result);
  CHECK(none_binary_result.error().code == "c24.none_estimand_mismatch");

  auto wrong_stage = plan_spec(
      4U, 1U, "c24.plan.wrong-stage", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::prearrival_closure);
  const auto wrong_stage_result =
      mwperf::SamplingPlan::from_accepted_clause(
          fixture.sampler, std::move(wrong_stage));
  REQUIRE_FALSE(wrong_stage_result);
  CHECK(wrong_stage_result.error().code ==
        "c24.sampling_plan_reveal_stage_mismatch");

  // Once C14 has accepted a concrete statistical procedure, C24 may not
  // locally refine or replace any component of that accuracy contract.
  auto authority_fixture = seal_sampler(
      override, 4U, mwperf::StatisticalIntervalKindV1::hoeffding);
  const auto authority_target = accepted_target(authority_fixture.sampler);
  const auto accepted_spec = plan_spec(
      4U, 2U, "c24.plan.accepted-authority", authority_target,
      mwperf::StatisticalIntervalKindV1::hoeffding,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto accepted_plan = mwperf::SamplingPlan::from_accepted_clause(
      authority_fixture.sampler, accepted_spec);
  REQUIRE(accepted_plan);

  const auto check_accuracy_mutation = [&](mwperf::SamplingPlanSpecV1 spec) {
    const auto result = mwperf::SamplingPlan::from_accepted_clause(
        authority_fixture.sampler, std::move(spec));
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.sampling_plan_accuracy_not_accepted");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  };

  auto replication_mutation = accepted_spec;
  replication_mutation.accuracy.replications = mwperf::BigNat{3U};
  check_accuracy_mutation(std::move(replication_mutation));

  auto confidence_mutation = accepted_spec;
  confidence_mutation.accuracy.confidence_level = rational(9, 10);
  check_accuracy_mutation(std::move(confidence_mutation));

  auto interval_mutation = accepted_spec;
  interval_mutation.accuracy.interval =
      mwperf::StatisticalIntervalKindV1::exact_binomial;
  check_accuracy_mutation(std::move(interval_mutation));

  auto estimand_mutation = accepted_spec;
  estimand_mutation.accuracy.estimand =
      mwperf::StatisticalEstimandKindV1::bounded_iid;
  check_accuracy_mutation(std::move(estimand_mutation));

  auto lower_mutation = accepted_spec;
  lower_mutation.accuracy.almost_sure_lower = rational(-1, 1);
  check_accuracy_mutation(std::move(lower_mutation));

  auto upper_mutation = accepted_spec;
  upper_mutation.accuracy.almost_sure_upper = rational(2, 1);
  check_accuracy_mutation(std::move(upper_mutation));

  auto draw_cap_mutation = accepted_spec;
  draw_cap_mutation.draw_cap = mwperf::BigNat{5U};
  const auto excessive_draw_cap =
      mwperf::SamplingPlan::from_accepted_clause(
          authority_fixture.sampler, std::move(draw_cap_mutation));
  REQUIRE_FALSE(excessive_draw_cap);
  CHECK(excessive_draw_cap.error().code ==
        "c24.sampling_plan_draw_cap_exceeds_accepted_grant");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 empirical rows retain exact counts including unseen support atoms",
          "[c24][unit][empirical-row][counts]") {
  const auto target = matrix::digest("c24.row.target");
  auto override = sampler_override(
      "c24.row.three", 3U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::arrival_only_replay;
  override.conditional_sampler_contract->normalization_evidence =
      mwperf::SamplerEvidenceScopeV1::construction_enforced;
  override.conditional_sampler_contract->termination_evidence =
      mwperf::SamplerEvidenceScopeV1::independently_audited;
  override.conditional_sampler_contract->v1_evidence_scope =
      mwperf::SamplerV1EvidenceScopeV1::row_conditional;
  override.conditional_sampler_contract->v1_evidence_reference =
      matrix::digest("c24.row.evidence.v1");
  override.conditional_sampler_contract->v2_evidence_scope =
      mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift;
  override.conditional_sampler_contract->v2_evidence_reference =
      matrix::digest("c24.row.evidence.v2");
  override.conditional_sampler_contract->foreign_construction_evidence =
      matrix::digest("c24.row.evidence.foreign");
  auto fixture = seal_row_sampler(override, 7U);
  const auto plan = make_plan(fixture.sampler,
      plan_spec(7U, 0xC240301U, "c24.row.counts", target));
  CHECK(plan.accepted_backend_route() ==
        mwperf::BackendRouteKindV1::conditional_row_monte_carlo);

  const auto row = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  INFO((row ? std::string{}
            : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  CHECK(row.value().total() == mwperf::BigNat{7U});
  REQUIRE(row.value().atoms().size() == 3U);
  CHECK(row.value().atoms()[0U].count == mwperf::BigNat{7U});
  CHECK(row.value().atoms()[1U].count == mwperf::BigNat{0U});
  CHECK(row.value().atoms()[2U].count == mwperf::BigNat{0U});
  CHECK(row.value().atoms()[0U].probability ==
        mwperf::ExactRational::one());
  CHECK(row.value().atoms()[1U].probability ==
        mwperf::ExactRational::zero());
  CHECK(row.value().atoms()[2U].probability ==
        mwperf::ExactRational::zero());
  CHECK(row.value().iid_replications());
  CHECK(row.value().failed_draws() == 0U);
  CHECK(row.value().costs().draws == mwperf::BigNat{7U});
  CHECK(row.value().costs().failed_draws == mwperf::BigNat{0U});
  CHECK(row.value().costs().exact_innovation_atoms == mwperf::BigNat{0U});
  CHECK(row.value().costs().optimizer_probes == mwperf::BigNat{0U});
  const std::size_t expected_canonical_bytes =
      canonical_runtime_bytes(fixture.row) +
      7U * canonical_sample_bytes(row.value().atoms()[0U].sample);
  CHECK(row.value().costs().canonical_bytes ==
        mwperf::BigNat{static_cast<std::uint64_t>(
            expected_canonical_bytes)});
  CHECK(row.value().seal_digest() == fixture.sampler.seal_digest());
  CHECK(row.value().plan_digest() == plan.plan_digest());
  CHECK(row.value().metric_target_digest() ==
        plan.metric_target_digest());
  const mwperf::SamplingEvidenceSnapshotV1 expected_evidence{
      mwperf::RuntimeSamplingProvenanceV1::arrival_only_replay,
      mwperf::SamplerEvidenceScopeV1::construction_enforced,
      mwperf::SamplerEvidenceScopeV1::independently_audited,
      mwperf::SamplerV1EvidenceScopeV1::row_conditional,
      matrix::digest("c24.row.evidence.v1"),
      mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
      matrix::digest("c24.row.evidence.v2"),
      matrix::digest("c24.row.evidence.foreign")};
  CHECK(row.value().sampling_evidence() == expected_evidence);
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 7U);
}

TEST_CASE("C24 replay provenance retains actual per-replication word counts",
          "[c24][unit][replay][provenance]") {
  auto zero_override = sampler_override(
      "c24.replay.zero-word", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  auto zero_fixture = seal_row_sampler(zero_override, 3U);
  const auto zero_plan = make_plan(
      zero_fixture.sampler,
      plan_spec(3U, 0xC2403A1U, "c24.replay.zero-word",
                accepted_target(zero_fixture.sampler)));
  const auto zero_row = mwperf::estimate_discrete_kernel_row(
      zero_fixture.sampler, zero_fixture.row, zero_plan);
  REQUIRE(zero_row);
  REQUIRE(zero_row.value().replay_streams().size() == 3U);
  CHECK(std::ranges::all_of(
      zero_row.value().replay_streams(),
      [](const mwperf::SamplingReplicationReplayV1& record) {
        return record.consumed_words.is_zero();
      }));

  auto multi_override = sampler_override(
      "c24.replay.multiword", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  multi_override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        (void)rng.next_u64();
        (void)rng.next_u64();
        (void)rng.next_u64();
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            atom(state, 0U));
      };
  auto multi_fixture = seal_row_sampler(multi_override, 3U);
  const auto multi_plan = make_plan(
      multi_fixture.sampler,
      plan_spec(3U, 0xC2403A2U, "c24.replay.multiword",
                accepted_target(multi_fixture.sampler)));
  const auto multi_row = mwperf::estimate_discrete_kernel_row(
      multi_fixture.sampler, multi_fixture.row, multi_plan);
  const auto multi_replay = mwperf::estimate_discrete_kernel_row(
      multi_fixture.sampler, multi_fixture.row, multi_plan);
  REQUIRE(multi_row);
  REQUIRE(multi_replay);
  REQUIRE(multi_row.value().replay_streams().size() == 3U);
  CHECK(std::ranges::all_of(
      multi_row.value().replay_streams(),
      [](const mwperf::SamplingReplicationReplayV1& record) {
        return record.consumed_words == mwperf::BigNat{3U};
      }));
  CHECK(std::ranges::equal(multi_row.value().replay_streams(),
                           multi_replay.value().replay_streams()));
  for (std::size_t left = 0U;
       left < multi_row.value().replay_streams().size(); ++left) {
    for (std::size_t right = left + 1U;
         right < multi_row.value().replay_streams().size(); ++right) {
      CHECK(multi_row.value().replay_streams()[left].stream_identity !=
            multi_row.value().replay_streams()[right].stream_identity);
    }
  }
}

TEST_CASE("C24 aborts a failed fixed bank at the first failed draw without retry",
          "[c24][negative][empirical-row][transactional]") {
  const auto target = matrix::digest("c24.row.failure.target");
  auto override = sampler_override(
      "c24.row.failure", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1&,
         mwperf::DeterministicRng&)
          -> mwperf::Result<mwperf::KernelTransitionV1> {
        return mwperf::Result<mwperf::KernelTransitionV1>::failure(
            matrix::reached_materializer());
      };
  auto fixture = seal_row_sampler(override, 8U);
  const auto plan = make_plan(fixture.sampler,
      plan_spec(8U, 0xC240304U, "c24.row.failure", target));
  auto observer = mwperf::SamplingExecutionObserverV1::for_plan(plan);
  REQUIRE(observer);
  const auto result = mwperf::estimate_discrete_kernel_row_observed(
      fixture.sampler, fixture.row, plan, observer.value());
  // A failed fixed bank publishes no EmpiricalRow and therefore no successful
  // draw/cost-counter record with a reduced denominator.
  REQUIRE_FALSE(result);
  CHECK_FALSE(result.has_value());
  CHECK(result.error().code ==
        "c16.fixture.registered_pair_materializer_reached");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 1U);
  CHECK(observer.value().generator_draws() == mwperf::BigNat{1U});
  CHECK(observer.value().failed_draws() == mwperf::BigNat{1U});
  REQUIRE(observer.value().replay_streams().size() == 1U);
  CHECK(observer.value().replay_streams().front().consumed_words.is_zero());
}

TEST_CASE("C24 uses one immutable finite support snapshot for the complete fixed bank",
          "[c24][unit][empirical-row][support-snapshot]") {
  const auto target = matrix::digest("c24.row.changing-support.target");
  auto override = sampler_override(
      "c24.row.changing-support", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng&) {
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            atom(state, 1U));
      };
  const auto enumeration_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_support_enumerator =
      [enumeration_calls](const mwperf::CanonicalRuntimeValueV1& state) {
        const unsigned call = enumeration_calls->fetch_add(
            1U, std::memory_order_relaxed);
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            call == 0U
                ? std::vector<mwperf::KernelTransitionV1>{
                      atom(state, 0U), atom(state, 1U)}
                : std::vector<mwperf::KernelTransitionV1>{
                      atom(state, 1U), atom(state, 2U)});
      };
  auto fixture = seal_row_sampler(override, 3U);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      3U, 0xC240305U, "c24.row.changing-support", target));

  const auto result = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  REQUIRE(result);
  REQUIRE(result.value().atoms().size() == 2U);
  CHECK(result.value().atoms()[0U].count == mwperf::BigNat{0U});
  CHECK(result.value().atoms()[1U].count == mwperf::BigNat{3U});
  // A second enumeration would return {1,2}.  The exact count of one proves
  // that neither per-replication validation nor publication re-queries the
  // authored support after the pre-draw snapshot.
  CHECK(enumeration_calls->load(std::memory_order_relaxed) == 1U);
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 3U);
}

TEST_CASE("C24 validates every support atom before starting an empirical bank",
          "[c24][negative][empirical-row][sample-validator]") {
  const auto target = matrix::digest("c24.row.invalid-snapshot.target");
  auto override = sampler_override(
      "c24.row.invalid-snapshot", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        auto invalid = atom(state, 1U);
        invalid.ordered_marks.back().canonical_value = {std::byte{0x02}};
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            {atom(state, 0U), std::move(invalid)});
      };
  auto fixture = seal_row_sampler(override, 3U);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      3U, 0xC240306U, "c24.row.invalid-snapshot", target));

  const auto result = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  REQUIRE_FALSE(result);
  CHECK(result.error().code ==
        "c24.fixture.common_projection_violation");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 attaches a finite-support TV claim only at a sufficient fixed budget",
          "[c24][unit][empirical-row][tv]") {
  const auto target = matrix::digest("c24.row.tv.target");
  auto override = sampler_override(
      "c24.row.tv", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  auto sufficient_fixture = seal_row_sampler(override, 220U);

  const auto sufficient = make_plan(sufficient_fixture.sampler, plan_spec(
      220U, 0xC240302U, "c24.row.tv.sufficient", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      false, mwperf::TotalVariationRequestV1{0.1L, 0.05L, 1U}));
  const auto row = mwperf::estimate_discrete_kernel_row(
      sufficient_fixture.sampler, sufficient_fixture.row, sufficient);
  REQUIRE(row);
  REQUIRE(row.value().total_variation_bound().has_value());
  const auto& bound = *row.value().total_variation_bound();
  CHECK(bound.support_cardinality == 2U);
  CHECK(close(bound.epsilon, 0.1L));
  CHECK(close(bound.alpha, 0.05L));
  CHECK(bound.iid_premise);
  CHECK(bound.fixed_sample_size);
  CHECK(bound.controls ==
        mwperf::SamplingClaimScopeV1::row_conditional_surrogate);
  CHECK(bound.advertised_failure_bound <= 0.05L + kTolerance);
  CHECK(row.value().atoms()[1U].count == mwperf::BigNat{0U});

  auto insufficient_override = override;
  insufficient_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto insufficient_fixture = seal_row_sampler(insufficient_override, 219U);
  const auto insufficient = make_plan(insufficient_fixture.sampler, plan_spec(
      219U, 0xC240303U, "c24.row.tv.insufficient", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      false, mwperf::TotalVariationRequestV1{0.1L, 0.05L, 1U}));
  const unsigned before =
      insufficient_override.conditional_sampler_calls->load(
      std::memory_order_relaxed);
  const auto rejected = mwperf::estimate_discrete_kernel_row(
      insufficient_fixture.sampler, insufficient_fixture.row, insufficient);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c24.insufficient_tv_replication_budget");
  CHECK(insufficient_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == before);

  auto underflow_override = override;
  underflow_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto underflow_fixture = seal_row_sampler(underflow_override, 1U);
  const auto underflow_safe = make_plan(underflow_fixture.sampler, plan_spec(
      1U, 0xC240306U, "c24.row.tv.underflow-safe", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      false, mwperf::TotalVariationRequestV1{1.0e6L, 0.05L, 1U}));
  const auto tiny_bound = mwperf::estimate_discrete_kernel_row(
      underflow_fixture.sampler, underflow_fixture.row, underflow_safe);
  REQUIRE(tiny_bound);
  REQUIRE(tiny_bound.value().total_variation_bound().has_value());
  CHECK(tiny_bound.value()
            .total_variation_bound()
            ->advertised_failure_bound > 0.0L);
  CHECK(tiny_bound.value()
            .total_variation_bound()
            ->advertised_failure_bound <= 0.05L);
}

TEST_CASE("C24 refuses a finite-support TV claim for query-only support before drawing",
          "[c24][negative][empirical-row][tv-premise]") {
  const auto target = matrix::digest("c24.row.query.target");
  auto override = sampler_override(
      "c24.row.query", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  override.conditional_sampler_contract->support_kind =
      mwperf::ConditionalSupportKindV1::membership_query;
  override.conditional_sampler_contract->finite_support_cardinality.reset();
  auto fixture = seal_row_sampler(override, 220U);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      220U, 0xC240305U, "c24.row.query", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      false, mwperf::TotalVariationRequestV1{0.1L, 0.05L, 1U}));
  const auto result = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c24.tv_bound_premise_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

}

TEST_CASE("C24 reward moments use the fixed raw reward bank stably",
          "[c24][unit][reward][moments]") {
  auto target = matrix::digest("c24.reward.moments.target");
  const auto decoder_digest = matrix::digest("c24.reward.moments.decoder");
  auto override = sampler_override(
      "c24.reward.moments", 4U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::modified_compatible_state;
  const auto output = override.conditional_sampler_contract->output_schema;
  auto fixture = seal_sampler(override, 4U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.reward.moments", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return 1.0e12L + static_cast<long double>(value + 1U);
      }));

  std::optional<mwperf::Estimate> selected;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = make_plan(fixture.sampler, plan_spec(
        4U, seed, "c24.reward.moments", target));
    auto estimate = mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan);
    REQUIRE(estimate);
    std::vector<long double> sorted(estimate.value().raw_rewards().begin(),
                                    estimate.value().raw_rewards().end());
    std::sort(sorted.begin(), sorted.end());
    const std::vector<long double> desired{
        1.0e12L + 1.0L, 1.0e12L + 2.0L,
        1.0e12L + 3.0L, 1.0e12L + 4.0L};
    if (sorted == desired) {
      selected = estimate.value();
      break;
    }
  }
  REQUIRE(selected.has_value());
  CHECK(close(selected->value(), 1.0e12L + 2.5L, 1.0e-9L));
  REQUIRE(selected->sample_variance().has_value());
  CHECK(close(*selected->sample_variance(), 5.0L / 3.0L));
  CHECK(selected->claim_scope() ==
        mwperf::SamplingClaimScopeV1::row_conditional_surrogate);
  CHECK(selected->sampling_evidence().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::modified_compatible_state);
  CHECK(selected->has_empirical_residual());
  CHECK(selected->costs().draws == mwperf::BigNat{4U});
  REQUIRE(selected->replay_streams().size() == 4U);
  CHECK(std::ranges::all_of(
      selected->replay_streams(),
      [](const mwperf::SamplingReplicationReplayV1& record) {
        return record.consumed_words == mwperf::BigNat{1U};
      }));
  CHECK(selected->seal_digest() == fixture.sampler.seal_digest());
  CHECK(selected->metric_target_digest() == target);
  CHECK(selected->conditioning_row_digest() ==
        selected->empirical_residual().conditioning_row_digest());
  CHECK(selected->plan_digest() ==
        selected->empirical_residual().plan_digest());
  CHECK(selected->metric_target_digest() ==
        selected->empirical_residual().metric_target_digest());
  CHECK_FALSE(selected->proposal_law_identity().has_value());
  CHECK_FALSE(selected->target_law_identity().has_value());
}

TEST_CASE("C24 compensated reward mean survives adversarial cancellation",
          "[c24][unit][reward][moments][cancellation]") {
  auto target = matrix::digest("c24.reward.cancellation.target");
  const auto decoder_digest =
      matrix::digest("c24.reward.cancellation.decoder");
  auto override = sampler_override(
      "c24.reward.cancellation", 3U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  const auto output = override.conditional_sampler_contract->output_schema;
  auto fixture = seal_sampler(override, 3U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.reward.cancellation", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        if (value == 0U) return 1.0e20L;
        if (value == 1U) return 1.0L;
        return -1.0e20L;
      }));

  const std::vector<long double> desired{1.0e20L, 1.0L, -1.0e20L};
  std::optional<mwperf::Estimate> selected;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = make_plan(fixture.sampler, plan_spec(
        3U, seed, "c24.reward.cancellation", target));
    auto estimate = mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan);
    REQUIRE(estimate);
    if (std::ranges::equal(estimate.value().raw_rewards(), desired)) {
      selected = std::move(estimate).value();
      break;
    }
  }
  REQUIRE(selected.has_value());
  CHECK(close(selected->value(), 1.0L / 3.0L, 1.0e-18L));
  REQUIRE(selected->sample_variance().has_value());
  CHECK(*selected->sample_variance() >= 0.0L);
}

TEST_CASE("C24 exact-binomial and Hoeffding intervals match fixed-sample goldens",
          "[c24][unit][reward][interval]") {
  auto target = matrix::digest("c24.reward.interval.target");
  const auto decoder_digest = matrix::digest("c24.reward.interval.decoder");
  const auto zero = mwperf::ExactRational::zero();
  const auto one = mwperf::ExactRational::one();

  auto zero_override = sampler_override(
      "c24.reward.cp.zero", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto zero_output =
      zero_override.conditional_sampler_contract->output_schema;
  auto zero_fixture = seal_sampler(
      zero_override, 10U,
      mwperf::StatisticalIntervalKindV1::exact_binomial);
  target = accepted_target(zero_fixture.sampler);
  const auto binary_zero = reward_decoder(
      "c24.reward.binary", decoder_digest, target, zero_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, zero, one);
  const auto cp_plan = make_plan(zero_fixture.sampler, plan_spec(
      10U, 0xC240401U, "c24.reward.cp.zero", target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion, zero, one));
  const auto cp_zero = mwperf::estimate_reward_expectation(
      zero_fixture.sampler, zero_fixture.row, binary_zero, cp_plan);
  REQUIRE(cp_zero);
  REQUIRE(cp_zero.value().interval().has_value());
  CHECK(close(cp_zero.value().interval()->lower, 0.0L));
  CHECK(close(cp_zero.value().interval()->upper,
              0.3084971078187607L, 2.0e-12L));
  CHECK(cp_zero.value().interval()->sample_size == mwperf::BigNat{10U});
  CHECK(cp_zero.value().interval()->dependence ==
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  CHECK_FALSE(cp_zero.value().interval()->coverage_statement.empty());

  auto bernoulli_override = sampler_override(
      "c24.reward.cp.half", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  const auto bernoulli_output =
      bernoulli_override.conditional_sampler_contract->output_schema;
  auto bernoulli_fixture = seal_sampler(
      bernoulli_override, 10U,
      mwperf::StatisticalIntervalKindV1::exact_binomial);
  target = accepted_target(bernoulli_fixture.sampler);
  const auto binary = reward_decoder(
      "c24.reward.binary", decoder_digest, target, bernoulli_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, zero, one);

  std::optional<mwperf::Estimate> five;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = make_plan(bernoulli_fixture.sampler, plan_spec(
        10U, seed, "c24.reward.cp.half", target,
        mwperf::StatisticalIntervalKindV1::exact_binomial,
        mwperf::StatisticalEstimandKindV1::binary_proportion, zero, one));
    auto estimate = mwperf::estimate_reward_expectation(
        bernoulli_fixture.sampler, bernoulli_fixture.row, binary, plan);
    REQUIRE(estimate);
    const auto successes = static_cast<std::size_t>(std::count(
        estimate.value().raw_rewards().begin(),
        estimate.value().raw_rewards().end(), 1.0L));
    if (successes == 5U) {
      five = estimate.value();
      break;
    }
  }
  REQUIRE(five.has_value());
  REQUIRE(five->interval().has_value());
  CHECK(close(five->value(), 0.5L));
  CHECK(close(five->interval()->lower,
              0.18708602844739855L, 2.0e-12L));
  CHECK(close(five->interval()->upper,
              0.8129139715526015L, 2.0e-12L));

  auto hoeffding_override = bernoulli_override;
  hoeffding_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto hoeffding_fixture = seal_sampler(
      hoeffding_override, 10U,
      mwperf::StatisticalIntervalKindV1::hoeffding);
  const auto hoeffding_target = accepted_target(hoeffding_fixture.sampler);
  const auto hoeffding_reward = reward_decoder(
      "c24.reward.binary", decoder_digest, hoeffding_target,
      bernoulli_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, zero, one);
  const auto hoeffding_plan = make_plan(hoeffding_fixture.sampler, plan_spec(
      10U, 0xC240402U, "c24.reward.hoeffding", hoeffding_target,
      mwperf::StatisticalIntervalKindV1::hoeffding,
      mwperf::StatisticalEstimandKindV1::binary_proportion, zero, one));
  const auto hoeffding = mwperf::estimate_reward_expectation(
      hoeffding_fixture.sampler, hoeffding_fixture.row, hoeffding_reward,
      hoeffding_plan);
  REQUIRE(hoeffding);
  REQUIRE(hoeffding.value().interval().has_value());
  const long double radius = std::sqrt(std::log(40.0L) / 20.0L);
  CHECK(close(hoeffding.value().interval()->lower,
              std::max(0.0L, hoeffding.value().value() - radius)));
  CHECK(close(hoeffding.value().interval()->upper,
              std::min(1.0L, hoeffding.value().value() + radius)));
  CHECK(hoeffding.value().interval()->iid_premise);
  CHECK(hoeffding.value().interval()->fixed_sample_size);
  CHECK(hoeffding.value().interval()->sample_size == mwperf::BigNat{10U});
  CHECK(hoeffding.value().interval()->dependence ==
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  CHECK(hoeffding.value().interval()->controls ==
        mwperf::SamplingClaimScopeV1::row_conditional_surrogate);
  CHECK_FALSE(hoeffding.value().interval()->coverage_statement.empty());
  REQUIRE(hoeffding.value().interval()->almost_sure_lower.has_value());
  REQUIRE(hoeffding.value().interval()->almost_sure_upper.has_value());
}

TEST_CASE("C24 rejects IID coverage premises transactionally",
          "[c24][negative][reward][interval]") {
  auto target = matrix::digest("c24.reward.correlated.target");
  const auto decoder_digest = matrix::digest("c24.reward.correlated.decoder");
  auto override = sampler_override(
      "c24.reward.correlated", 2U,
      mwperf::ConditionalSampleDependenceV1::correlated_trace);
  const auto output = override.conditional_sampler_contract->output_schema;
  auto fixture = seal_sampler(
      override, 10U,
      mwperf::StatisticalIntervalKindV1::exact_binomial);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.reward.correlated", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto plan = make_plan(fixture.sampler, plan_spec(
      10U, 0xC240403U, "c24.reward.correlated", target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one()));
  const auto result = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, plan);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c24.exact_binomial_premise_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto iid_override = sampler_override(
      "c24.reward.hoeffding-range-mismatch", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto iid_output =
      iid_override.conditional_sampler_contract->output_schema;
  auto iid_fixture = seal_sampler(
      iid_override, 10U,
      mwperf::StatisticalIntervalKindV1::hoeffding);
  const auto iid_target = accepted_target(iid_fixture.sampler);
  const auto mismatched_range = reward_decoder(
      "c24.reward.hoeffding-range-mismatch", decoder_digest, iid_target,
      iid_output, byte_reward([](const std::uint8_t) { return 0.5L; }),
      false, mwperf::ExactRational::zero(), rational(2, 1));
  const auto hoeffding_plan = make_plan(iid_fixture.sampler, plan_spec(
      10U, 0xC240404U, "c24.reward.hoeffding-range-mismatch", iid_target,
      mwperf::StatisticalIntervalKindV1::hoeffding,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one()));
  const auto range_mismatch = mwperf::estimate_reward_expectation(
      iid_fixture.sampler, iid_fixture.row, mismatched_range,
      hoeffding_plan);
  REQUIRE_FALSE(range_mismatch);
  CHECK(range_mismatch.error().code ==
        "c24.hoeffding_premise_mismatch");
  CHECK(iid_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects every extended-real reward without replacement draws",
          "[c24][negative][reward][extended-real]") {
  auto target = matrix::digest("c24.reward.extended.target");
  const auto decoder_digest = matrix::digest("c24.reward.extended.decoder");
  const std::array<long double, 3U> values{
      std::numeric_limits<long double>::infinity(),
      -std::numeric_limits<long double>::infinity(),
      std::numeric_limits<long double>::quiet_NaN()};
  for (std::size_t index = 0U; index < values.size(); ++index) {
    auto override = sampler_override(
        "c24.reward.extended." + std::to_string(index), 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    const auto output = override.conditional_sampler_contract->output_schema;
    auto fixture = seal_sampler(override, 3U);
    target = accepted_target(fixture.sampler);
    const auto extended = values[index];
    const auto reward = reward_decoder(
        "c24.reward.extended", decoder_digest, target, output,
        byte_reward([extended](const std::uint8_t) { return extended; }));
    const auto plan = make_plan(fixture.sampler, plan_spec(
        3U, 0xC240405U + static_cast<std::uint64_t>(index),
        "c24.reward.extended", target));
    auto observer = mwperf::SamplingExecutionObserverV1::for_plan(plan);
    REQUIRE(observer);
    const auto result = mwperf::estimate_reward_expectation_observed(
        fixture.sampler, fixture.row, reward, plan, observer.value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c24.nonfinite_reward");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 3U);
    CHECK(observer.value().generator_draws() == mwperf::BigNat{3U});
    CHECK(observer.value().failed_draws() == mwperf::BigNat{0U});
    CHECK(observer.value().replay_streams().size() == 3U);
  }
}

TEST_CASE("C24 importance weights are scale invariant and retain exact diagnostics",
          "[c24][unit][importance][diagnostics]") {
  auto target = matrix::digest("c24.importance.target");
  const auto decoder_digest = matrix::digest("c24.importance.decoder");
  auto first_override = sampler_override(
      "c24.importance.three", 3U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  first_override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::proposal;
  const auto output = first_override.conditional_sampler_contract->output_schema;
  attach_ratio(
      first_override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             static_cast<long double>(atom_value(sample) + 1U)});
      });
  auto second_override = first_override;
  second_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  second_override.target_ratio_operation =
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             7.0L * static_cast<long double>(atom_value(sample) + 1U)});
      };
  auto log_override = first_override;
  log_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  log_override.target_ratio_operation =
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        const long double weight =
            static_cast<long double>(atom_value(sample) + 1U);
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::log_nonnegative,
             10000.0L + std::log(weight)});
      };
  auto first = seal_sampler(first_override, 3U);
  auto second = seal_sampler(second_override, 3U);
  auto logged = seal_sampler(log_override, 3U);
  target = accepted_target(first.sampler);
  CHECK(first.sampler.seal_digest() == second.sampler.seal_digest());
  CHECK(first.sampler.seal_digest() == logged.sampler.seal_digest());
  const auto reward = reward_decoder(
      "c24.importance.reward", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        const long double base = static_cast<long double>(value + 1U);
        return base * base;
      }));

  std::optional<mwperf::Estimate> first_selected;
  std::optional<mwperf::Estimate> second_selected;
  std::optional<mwperf::Estimate> log_selected;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = make_plan(first.sampler, plan_spec(
        3U, seed, "c24.importance.three", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
    auto first_ratio =
        first.sampler.bind_target_density_ratio(first.row, plan);
    auto second_ratio =
        second.sampler.bind_target_density_ratio(second.row, plan);
    auto log_ratio =
        logged.sampler.bind_target_density_ratio(logged.row, plan);
    REQUIRE(first_ratio);
    REQUIRE(second_ratio);
    REQUIRE(log_ratio);
    auto first_estimate = mwperf::estimate_importance_weighted(
        first.sampler, first.row, first_ratio.value(), reward, plan);
    auto second_estimate = mwperf::estimate_importance_weighted(
        second.sampler, second.row, second_ratio.value(), reward, plan);
    auto log_estimate = mwperf::estimate_importance_weighted(
        logged.sampler, logged.row, log_ratio.value(), reward, plan);
    REQUIRE(first_estimate);
    REQUIRE(second_estimate);
    REQUIRE(log_estimate);
    std::vector<long double> sorted(first_estimate.value().raw_rewards().begin(),
                                    first_estimate.value().raw_rewards().end());
    std::sort(sorted.begin(), sorted.end());
    if (sorted == std::vector<long double>{1.0L, 4.0L, 9.0L}) {
      first_selected = first_estimate.value();
      second_selected = second_estimate.value();
      log_selected = log_estimate.value();
      break;
    }
  }
  REQUIRE(first_selected.has_value());
  REQUIRE(second_selected.has_value());
  REQUIRE(log_selected.has_value());
  REQUIRE(first_selected->replay_streams().size() == 3U);
  CHECK(std::ranges::all_of(
      first_selected->replay_streams(),
      [](const mwperf::SamplingReplicationReplayV1& record) {
        return record.consumed_words == mwperf::BigNat{1U};
      }));
  CHECK(first_selected->sampling_evidence().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::proposal);
  CHECK(second_selected->sampling_evidence() ==
        first_selected->sampling_evidence());
  CHECK(log_selected->sampling_evidence() ==
        first_selected->sampling_evidence());
  CHECK(first_selected->seal_digest() == first.sampler.seal_digest());
  CHECK(first_selected->metric_target_digest() == target);
  CHECK(first_selected->conditioning_row_digest() ==
        second_selected->conditioning_row_digest());
  CHECK(first_selected->plan_digest() ==
        second_selected->plan_digest());
  CHECK(first_selected->conditioning_row_digest() ==
        log_selected->conditioning_row_digest());
  CHECK(first_selected->plan_digest() == log_selected->plan_digest());
  CHECK_FALSE(first_selected->has_empirical_residual());
  REQUIRE(first_selected->proposal_law_identity().has_value());
  REQUIRE(first_selected->target_law_identity().has_value());
  CHECK(*first_selected->proposal_law_identity() ==
        first.sampler.contract().proposal_law_identity);
  CHECK(*first_selected->target_law_identity() ==
        matrix::digest("c24.importance.target-law"));
  CHECK(close(first_selected->value(), 6.0L));
  CHECK(close(second_selected->value(), 6.0L));
  CHECK(close(log_selected->value(), 6.0L));
  REQUIRE(first_selected->importance_diagnostics().has_value());
  REQUIRE(second_selected->importance_diagnostics().has_value());
  const auto& diagnostics = *first_selected->importance_diagnostics();
  CHECK(close(diagnostics.effective_sample_size, 18.0L / 7.0L));
  CHECK(close(diagnostics.maximum_normalized_weight, 0.5L));
  CHECK(diagnostics.zero_weight_count == 0U);
  CHECK(close(diagnostics.positive_log_weight_dynamic_range,
              std::log(3.0L)));
  CHECK_FALSE(diagnostics.zero_weights_present);
  CHECK_FALSE(diagnostics.full_log_weight_dynamic_range_infinite);
  CHECK(diagnostics.finite_sample_biased);
  CHECK(diagnostics.consistency_claim);
  CHECK(diagnostics.weighted_second_moment_claim);
  REQUIRE(first_selected->raw_weights().size() == 3U);
  REQUIRE(second_selected->raw_weights().size() == 3U);
  REQUIRE(log_selected->raw_weights().size() == 3U);
  for (std::size_t index = 0U; index < 3U; ++index) {
    CHECK(close(first_selected->raw_weights()[index].common_scaled_weight,
                second_selected->raw_weights()[index].common_scaled_weight));
    CHECK(close(second_selected->raw_weights()[index].authored_value,
                7.0L * first_selected->raw_weights()[index].authored_value));
    CHECK(log_selected->raw_weights()[index].representation ==
          mwperf::ImportanceWeightRepresentationV1::log_nonnegative);
    CHECK(close(first_selected->raw_weights()[index].common_scaled_weight,
                log_selected->raw_weights()[index].common_scaled_weight,
                1.0e-11L));
  }
  REQUIRE(log_selected->importance_diagnostics().has_value());
  CHECK(close(log_selected->importance_diagnostics()->effective_sample_size,
              18.0L / 7.0L, 1.0e-11L));
}

TEST_CASE("C24 permits individual zero importance weights but rejects a zero denominator",
          "[c24][unit][importance][zero-weight]") {
  auto target = matrix::digest("c24.importance.zero.target");
  const auto decoder_digest = matrix::digest("c24.importance.zero.decoder");
  auto override = sampler_override(
      "c24.importance.zero", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::log_nonnegative,
             atom_value(sample) == 0U
                 ? -std::numeric_limits<long double>::infinity()
                 : 0.0L});
      });
  auto fixture = seal_sampler(override, 8U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.importance.zero", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return 1.0L + static_cast<long double>(value);
      }));

  std::optional<mwperf::Estimate> mixed;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = make_plan(fixture.sampler, plan_spec(
        8U, seed, "c24.importance.zero.mixed", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
    auto ratio = fixture.sampler.bind_target_density_ratio(fixture.row, plan);
    REQUIRE(ratio);
    auto estimate = mwperf::estimate_importance_weighted(
        fixture.sampler, fixture.row, ratio.value(), reward, plan);
    if (!estimate &&
        estimate.error().code == "c24.zero_importance_denominator") {
      continue;
    }
    REQUIRE(estimate);
    const std::size_t zeros = static_cast<std::size_t>(std::count(
        estimate.value().raw_rewards().begin(),
        estimate.value().raw_rewards().end(), 1.0L));
    if (zeros != 0U && zeros != 8U) {
      REQUIRE(estimate.value().importance_diagnostics().has_value());
      CHECK(estimate.value().importance_diagnostics()->zero_weight_count ==
            zeros);
      CHECK(estimate.value().importance_diagnostics()->zero_weights_present);
      CHECK(estimate.value().importance_diagnostics()
                ->full_log_weight_dynamic_range_infinite);
      mixed = estimate.value();
      break;
    }
  }
  REQUIRE(mixed.has_value());
  CHECK(close(mixed->value(), 2.0L));

  auto all_zero_override = sampler_override(
      "c24.importance.all-zero", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal, 0U);
  const auto all_zero_output =
      all_zero_override.conditional_sampler_contract->output_schema;
  attach_ratio(
      all_zero_override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             0.0L});
      });
  auto all_zero = seal_sampler(all_zero_override, 4U);
  const auto zero_reward = reward_decoder(
      "c24.importance.zero", decoder_digest, target, all_zero_output,
      byte_reward([](const std::uint8_t) { return 1.0L; }));
  const auto plan = make_plan(all_zero.sampler, plan_spec(
      4U, 0xC240501U, "c24.importance.all-zero", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  auto ratio = all_zero.sampler.bind_target_density_ratio(all_zero.row, plan);
  REQUIRE(ratio);
  auto observer = mwperf::SamplingExecutionObserverV1::for_plan(plan);
  REQUIRE(observer);
  const auto rejected = mwperf::estimate_importance_weighted_observed(
      all_zero.sampler, all_zero.row, ratio.value(), zero_reward, plan,
      observer.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c24.zero_importance_denominator");
  CHECK(all_zero_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 4U);
  CHECK(observer.value().generator_draws() == mwperf::BigNat{4U});
  CHECK(observer.value().failed_draws() == mwperf::BigNat{0U});
  CHECK(observer.value().replay_streams().size() == 4U);
}

TEST_CASE("C24 rejects mismatched importance bindings and premises before drawing",
          "[c24][negative][importance][binding]") {
  auto target = matrix::digest("c24.importance.binding.target");
  const auto decoder_digest = matrix::digest("c24.importance.binding.decoder");
  auto override = sampler_override(
      "c24.importance.binding", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      });
  auto fixture = seal_sampler(override, 4U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.importance.binding", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  const auto first_plan = make_plan(fixture.sampler, plan_spec(
      4U, 0xC240502U, "c24.importance.binding.first", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  const auto second_plan = make_plan(fixture.sampler, plan_spec(
      4U, 0xC240502U, "c24.importance.binding.second", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  auto ratio =
      fixture.sampler.bind_target_density_ratio(fixture.row, first_plan);
  REQUIRE(ratio);

  const auto plan_mismatch = mwperf::estimate_importance_weighted(
      fixture.sampler, fixture.row, ratio.value(), reward, second_plan);
  REQUIRE_FALSE(plan_mismatch);
  CHECK(plan_mismatch.error().code == "c24.importance_binding_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto other_row = fixture.row;
  other_row.canonical_value.push_back(std::byte{0x7f});
  const auto row_mismatch = mwperf::estimate_importance_weighted(
      fixture.sampler, other_row, ratio.value(), reward, first_plan);
  REQUIRE_FALSE(row_mismatch);
  CHECK(row_mismatch.error().code == "c24.importance_binding_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  const auto other_target =
      matrix::digest("c24.importance.binding.other-target");
  const auto other_target_plan = mwperf::SamplingPlan::from_accepted_clause(
      fixture.sampler, plan_spec(
      4U, 0xC240502U, "c24.importance.binding.first", other_target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  REQUIRE_FALSE(other_target_plan);
  CHECK(other_target_plan.error().code ==
        "c24.sampling_plan_target_not_accepted");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  const auto wrong_reward = reward_decoder(
      "c24.importance.binding.wrong-reward",
      matrix::digest("c24.importance.binding.other-decoder"), target,
      output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  const auto reward_mismatch = mwperf::estimate_importance_weighted(
      fixture.sampler, fixture.row, ratio.value(), wrong_reward,
      first_plan);
  REQUIRE_FALSE(reward_mismatch);
  CHECK(reward_mismatch.error().code ==
        "c24.importance_reward_digest_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto twin_override = override;
  twin_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto twin = seal_sampler(twin_override, 4U);
  CHECK(twin.sampler.seal_digest() == fixture.sampler.seal_digest());
  const auto seal_mismatch = mwperf::estimate_importance_weighted(
      twin.sampler, twin.row, ratio.value(), reward, first_plan);
  REQUIRE_FALSE(seal_mismatch);
  CHECK(seal_mismatch.error().code == "c24.importance_binding_mismatch");
  CHECK(twin_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto proposal_override = override;
  proposal_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  proposal_override.conditional_sampler_contract->proposal_law_identity =
      matrix::digest("c24.importance.binding.other-proposal");
  auto other_proposal = seal_sampler(proposal_override, 4U);
  CHECK(other_proposal.sampler.seal_digest() !=
        fixture.sampler.seal_digest());
  const auto proposal_mismatch = mwperf::estimate_importance_weighted(
      other_proposal.sampler, other_proposal.row, ratio.value(), reward,
      first_plan);
  REQUIRE_FALSE(proposal_mismatch);
  CHECK(proposal_mismatch.error().code ==
        "c24.sampling_plan_access_binding_mismatch");
  CHECK(proposal_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto missing_override = sampler_override(
      "c24.importance.missing-premise", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  const auto missing_output =
      missing_override.conditional_sampler_contract->output_schema;
  attach_ratio(
      missing_override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      },
      false);
  auto missing = seal_sampler(missing_override, 4U);
  const auto missing_target = accepted_target(missing.sampler);
  const auto missing_reward = reward_decoder(
      "c24.importance.binding", decoder_digest, missing_target,
      missing_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  const auto missing_plan = make_plan(missing.sampler, plan_spec(
      4U, 0xC240502U, "c24.importance.binding.missing", missing_target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  auto missing_ratio =
      missing.sampler.bind_target_density_ratio(missing.row, missing_plan);
  REQUIRE(missing_ratio);
  const auto premise = mwperf::estimate_importance_weighted(
      missing.sampler, missing.row, missing_ratio.value(), missing_reward,
      missing_plan);
  REQUIRE_FALSE(premise);
  CHECK(premise.error().code ==
        "c24.importance_population_premise_missing");
  CHECK(missing_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects signed and nonfinite importance weights without retry",
          "[c24][negative][importance][weight-domain]") {
  struct InvalidWeight final {
    mwperf::ImportanceWeightV1 weight;
    std::string_view code;
  };
  const std::vector<InvalidWeight> cases{
      {{mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
        -1.0L},
       "c24.invalid_direct_importance_weight"},
      {{mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
        -0.0L},
       "c24.invalid_direct_importance_weight"},
      {{mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
        std::numeric_limits<long double>::infinity()},
       "c24.invalid_direct_importance_weight"},
      {{mwperf::ImportanceWeightRepresentationV1::log_nonnegative,
        std::numeric_limits<long double>::quiet_NaN()},
       "c24.invalid_log_importance_weight"},
      {{mwperf::ImportanceWeightRepresentationV1::log_nonnegative,
        std::numeric_limits<long double>::infinity()},
       "c24.invalid_log_importance_weight"},
      {{static_cast<mwperf::ImportanceWeightRepresentationV1>(0xffU),
        1.0L},
       "c24.unknown_importance_weight_representation"}};

  for (std::size_t index = 0U; index < cases.size(); ++index) {
    auto target = matrix::digest(
        "c24.importance.invalid.target." + std::to_string(index));
    const auto decoder_digest = matrix::digest(
        "c24.importance.invalid.decoder." + std::to_string(index));
    auto override = sampler_override(
        "c24.importance.invalid." + std::to_string(index), 1U,
        mwperf::ConditionalSampleDependenceV1::iid_proposal, 0U);
    const auto output = override.conditional_sampler_contract->output_schema;
    const auto authored = cases[index].weight;
    attach_ratio(
        override, target, decoder_digest,
        [authored](const mwperf::CanonicalRuntimeValueV1&,
                   const mwperf::KernelTransitionV1&) {
          return mwperf::Result<mwperf::ImportanceWeightV1>::success(
              authored);
        });
    auto fixture = seal_sampler(override, 3U);
    target = accepted_target(fixture.sampler);
    const auto reward = reward_decoder(
        "c24.importance.invalid", decoder_digest, target, output,
        byte_reward([](const std::uint8_t) { return 1.0L; }));
    const auto plan = make_plan(fixture.sampler, plan_spec(
        3U, 0xC240503U + static_cast<std::uint64_t>(index),
        "c24.importance.invalid", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
    auto ratio =
        fixture.sampler.bind_target_density_ratio(fixture.row, plan);
    REQUIRE(ratio);
    const auto result = mwperf::estimate_importance_weighted(
        fixture.sampler, fixture.row, ratio.value(), reward, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == cases[index].code);
    // The fixed residual bank is drawn once; a bad weight never triggers a
    // replacement proposal draw.
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 3U);
  }
}

TEST_CASE("C24 enforces declared importance-reward domains on every draw",
          "[c24][negative][importance][reward-domain]") {
  struct InvalidReward final {
    long double value;
    bool binary;
    std::string_view code;
  };
  const std::array<InvalidReward, 2U> cases{{
      {0.5L, true, "c24.nonbinary_indicator_reward"},
      {2.0L, false, "c24.reward_outside_audited_range"},
  }};

  for (std::size_t index = 0U; index < cases.size(); ++index) {
    auto target = matrix::digest(
        "c24.importance.reward-domain.target." + std::to_string(index));
    const auto decoder_digest = matrix::digest(
        "c24.importance.reward-domain.decoder." + std::to_string(index));
    auto override = sampler_override(
        "c24.importance.reward-domain." + std::to_string(index), 1U,
        mwperf::ConditionalSampleDependenceV1::iid_proposal, 0U);
    const auto output = override.conditional_sampler_contract->output_schema;
    attach_ratio(
        override, target, decoder_digest,
        [](const mwperf::CanonicalRuntimeValueV1&,
           const mwperf::KernelTransitionV1&) {
          return mwperf::Result<mwperf::ImportanceWeightV1>::success(
              {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
               1.0L});
        });
    auto fixture = seal_sampler(override, 3U);
    target = accepted_target(fixture.sampler);
    const InvalidReward authored = cases[index];
    const auto reward = reward_decoder(
        "c24.importance.reward-domain", decoder_digest, target, output,
        byte_reward([value = authored.value](const std::uint8_t) {
          return value;
        }),
        authored.binary, mwperf::ExactRational::zero(),
        mwperf::ExactRational::one());
    const auto plan = make_plan(fixture.sampler, plan_spec(
        3U, 0xC240506U + static_cast<std::uint64_t>(index),
        "c24.importance.reward-domain", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
    auto ratio =
        fixture.sampler.bind_target_density_ratio(fixture.row, plan);
    REQUIRE(ratio);
    const auto result = mwperf::estimate_importance_weighted(
        fixture.sampler, fixture.row, ratio.value(), reward, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == authored.code);
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 3U);
  }
}

TEST_CASE("C24 checks each importance population premise before proposal draws",
          "[c24][negative][importance][premise-matrix]") {
  struct PremiseCase final {
    bool finite_mean;
    bool weighted_integrable;
    bool ratio_iid;
    mwperf::ConditionalSampleDependenceV1 sampler_dependence;
  };
  const std::array<PremiseCase, 4U> cases{{
      {false, true, true,
       mwperf::ConditionalSampleDependenceV1::iid_proposal},
      {true, false, true,
       mwperf::ConditionalSampleDependenceV1::iid_proposal},
      {true, true, false,
       mwperf::ConditionalSampleDependenceV1::iid_proposal},
      {true, true, true,
       mwperf::ConditionalSampleDependenceV1::correlated_trace},
  }};

  for (std::size_t index = 0U; index < cases.size(); ++index) {
    auto target = matrix::digest(
        "c24.importance.premise.target." + std::to_string(index));
    const auto decoder_digest = matrix::digest(
        "c24.importance.premise.decoder." + std::to_string(index));
    auto override = sampler_override(
        "c24.importance.premise." + std::to_string(index), 1U,
        cases[index].sampler_dependence, 0U);
    const auto output = override.conditional_sampler_contract->output_schema;
    attach_ratio(
        override, target, decoder_digest,
        [](const mwperf::CanonicalRuntimeValueV1&,
           const mwperf::KernelTransitionV1&) {
          return mwperf::Result<mwperf::ImportanceWeightV1>::success(
              {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
               1.0L});
        },
        true, cases[index].finite_mean,
        cases[index].weighted_integrable, cases[index].ratio_iid);
    auto fixture = seal_sampler(override, 2U);
    target = accepted_target(fixture.sampler);
    const auto reward = reward_decoder(
        "c24.importance.premise", decoder_digest, target, output,
        byte_reward([](const std::uint8_t) { return 1.0L; }));
    const auto plan = make_plan(fixture.sampler, plan_spec(
        2U, 0xC240504U + static_cast<std::uint64_t>(index),
        "c24.importance.premise", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt,
        cases[index].sampler_dependence ==
                mwperf::ConditionalSampleDependenceV1::iid_proposal
            ? mwperf::StageTag::importance_proposal
            : mwperf::StageTag::generic_sampling));
    auto ratio =
        fixture.sampler.bind_target_density_ratio(fixture.row, plan);
    REQUIRE(ratio);
    const auto result = mwperf::estimate_importance_weighted(
        fixture.sampler, fixture.row, ratio.value(), reward, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          (cases[index].sampler_dependence ==
                   mwperf::ConditionalSampleDependenceV1::iid_proposal
               ? "c24.importance_population_premise_missing"
               : "c24.importance_stage_mismatch"));
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  }
}

TEST_CASE("C24 rejects finite log weights that underflow common scaling",
          "[c24][negative][importance][precision]") {
  auto target = matrix::digest("c24.importance.underflow.target");
  const auto decoder_digest =
      matrix::digest("c24.importance.underflow.decoder");
  auto override = sampler_override(
      "c24.importance.underflow", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        const long double log_weight =
            atom_value(sample) == 0U ? -1.0e6L : 0.0L;
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::log_nonnegative,
             log_weight});
      });
  auto fixture = seal_sampler(override, 8U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.importance.underflow", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));

  bool observed = false;
  for (std::uint64_t seed = 0U; seed < 1024U; ++seed) {
    const auto plan = make_plan(fixture.sampler, plan_spec(
        8U, seed, "c24.importance.underflow", target,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
    auto ratio =
        fixture.sampler.bind_target_density_ratio(fixture.row, plan);
    REQUIRE(ratio);
    const unsigned before = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    const auto result = mwperf::estimate_importance_weighted(
        fixture.sampler, fixture.row, ratio.value(), reward, plan);
    const unsigned after = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    CHECK(after - before == 8U);
    if (!result && result.error().code ==
                       "c24.importance_weight_precision_underflow") {
      observed = true;
      break;
    }
    REQUIRE(result);
  }
  REQUIRE(observed);
}

TEST_CASE("C24 quarantines a stationary-occupation ratio without disabling ordinary estimation",
          "[c24][negative][importance][target-kind]") {
  const auto target = matrix::digest("c24.importance.kind.target");
  const auto decoder_digest = matrix::digest("c24.importance.kind.decoder");
  auto override = sampler_override(
      "c24.importance.kind", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      });
  override.target_ratio_contract->target_kind =
      mwperf::ImportanceTargetKindV1::stationary_occupation;

  auto fixture = seal_sampler(override, 1U);
  CHECK_FALSE(fixture.sampler.target_density_ratio_available());
  const auto accepted = accepted_target(fixture.sampler);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      1U, 0xC240510U, "c24.importance.kind.ordinary", accepted));
  const auto reward = reward_decoder(
      "c24.importance.kind.ordinary", decoder_digest, accepted, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  REQUIRE(mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, plan));
  const unsigned before_binding = override.conditional_sampler_calls->load(
      std::memory_order_relaxed);
  const auto unavailable = fixture.sampler.bind_target_density_ratio(
      fixture.row, plan);
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code == "c24.invalid_target_ratio_binding");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == before_binding);
}

TEST_CASE("C24 quarantines a density ratio bound to a foreign metric target",
          "[c24][negative][importance][target-binding]") {
  const auto target = matrix::digest("c24.importance.foreign.target");
  const auto decoder_digest =
      matrix::digest("c24.importance.foreign.decoder");
  auto override = sampler_override(
      "c24.importance.foreign", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      });
  override.target_ratio_contract->metric_target_digest =
      matrix::digest("c24.importance.foreign.unaccepted-target");

  auto fixture = seal_sampler(override, 1U);
  CHECK_FALSE(fixture.sampler.target_density_ratio_available());
  const auto accepted = accepted_target(fixture.sampler);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      1U, 0xC240511U, "c24.importance.foreign.ordinary", accepted));
  const auto reward = reward_decoder(
      "c24.importance.foreign.ordinary", decoder_digest, accepted, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  REQUIRE(mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, plan));
  const unsigned before_binding = override.conditional_sampler_calls->load(
      std::memory_order_relaxed);
  const auto unavailable = fixture.sampler.bind_target_density_ratio(
      fixture.row, plan);
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code ==
        "c24.target_ratio_target_not_accepted");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == before_binding);
}

TEST_CASE("C24 incomplete optional authority pairs leave the ordinary estimator available",
          "[c24][negative][optional-authority][incomplete]") {
  const auto exercise_ordinary = [](
      SealedSamplerFixture& fixture,
      const mwperf::Digest256& decoder_digest,
      const std::string& estimator_id) {
    const auto target = accepted_target(fixture.sampler);
    auto plan = make_plan(fixture.sampler, plan_spec(
        1U, 0xC240513U, estimator_id, target));
    const auto reward = reward_decoder(
        estimator_id, decoder_digest, target,
        fixture.sampler.contract().output_schema,
        byte_reward([](const std::uint8_t value) {
          return static_cast<long double>(value);
        }));
    REQUIRE(mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan));
    return plan;
  };

  SECTION("ratio contract without operation") {
    const auto decoder = matrix::digest("c24.ratio.contract-only.decoder");
    auto override = sampler_override(
        "c24.ratio.contract-only", 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    attach_ratio(
        override, matrix::digest("c24.ratio.contract-only.target"), decoder,
        [](const mwperf::CanonicalRuntimeValueV1&,
           const mwperf::KernelTransitionV1&) {
          return mwperf::Result<mwperf::ImportanceWeightV1>::success(
              {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
               1.0L});
        });
    override.target_ratio_operation.reset();
    auto fixture = seal_sampler(override, 1U);
    CHECK_FALSE(fixture.sampler.target_density_ratio_available());
    const auto plan = exercise_ordinary(
        fixture, decoder, "c24.ratio.contract-only.ordinary");
    const unsigned before = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    const auto result = fixture.sampler.bind_target_density_ratio(
        fixture.row, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.incomplete_target_density_ratio_authority");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == before);
  }

  SECTION("ratio operation without contract") {
    const auto decoder = matrix::digest("c24.ratio.operation-only.decoder");
    auto override = sampler_override(
        "c24.ratio.operation-only", 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    override.target_ratio_operation =
        [](const mwperf::CanonicalRuntimeValueV1&,
           const mwperf::KernelTransitionV1&) {
          return mwperf::Result<mwperf::ImportanceWeightV1>::success(
              {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
               1.0L});
        };
    auto fixture = seal_sampler(override, 1U);
    CHECK_FALSE(fixture.sampler.target_density_ratio_available());
    const auto plan = exercise_ordinary(
        fixture, decoder, "c24.ratio.operation-only.ordinary");
    const unsigned before = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    const auto result = fixture.sampler.bind_target_density_ratio(
        fixture.row, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.incomplete_target_density_ratio_authority");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == before);
  }

  SECTION("innovation contract without operation") {
    const auto decoder =
        matrix::digest("c24.innovation.contract-only.decoder");
    auto override = sampler_override(
        "c24.innovation.contract-only", 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    attach_innovation(
        override, decoder,
        [](const mwperf::CanonicalRuntimeValueV1& state,
           const mwperf::KernelTransitionV1& residual) {
          return mwperf::Result<
              std::vector<mwperf::ExactInnovationAtomV1>>::success(
              {{{state, residual.ordered_marks},
                mwperf::ExactRational::one()}});
        });
    override.exact_innovation_operation.reset();
    auto fixture = seal_sampler(override, 1U);
    CHECK_FALSE(fixture.sampler.exact_innovation_available());
    const auto plan = exercise_ordinary(
        fixture, decoder, "c24.innovation.contract-only.ordinary");
    const unsigned before = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    const auto result = fixture.sampler.bind_exact_innovation_kernel(
        fixture.row, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.incomplete_exact_innovation_authority");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == before);
  }

  SECTION("innovation operation without contract") {
    const auto decoder =
        matrix::digest("c24.innovation.operation-only.decoder");
    auto override = sampler_override(
        "c24.innovation.operation-only", 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    override.exact_innovation_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           const mwperf::KernelTransitionV1& residual) {
          return mwperf::Result<
              std::vector<mwperf::ExactInnovationAtomV1>>::success(
              {{{state, residual.ordered_marks},
                mwperf::ExactRational::one()}});
        };
    auto fixture = seal_sampler(override, 1U);
    CHECK_FALSE(fixture.sampler.exact_innovation_available());
    const auto plan = exercise_ordinary(
        fixture, decoder, "c24.innovation.operation-only.ordinary");
    const unsigned before = override.conditional_sampler_calls->load(
        std::memory_order_relaxed);
    const auto result = fixture.sampler.bind_exact_innovation_kernel(
        fixture.row, plan);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.incomplete_exact_innovation_authority");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == before);
  }
}

TEST_CASE("C24 quarantines cross-bound exact innovations without disabling ordinary estimation",
          "[c24][negative][rao-blackwell][binding]") {
  const auto decoder_digest =
      matrix::digest("c24.rb.invalid-binding.decoder");
  const auto audit = [&](const std::string_view suffix,
                         const std::string_view expected_code,
                         const auto& mutate) {
    auto override = sampler_override(
        "c24.rb.invalid-binding." + std::string(suffix), 1U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
    auto innovation_calls = std::make_shared<std::atomic<unsigned>>(0U);
    attach_innovation(
        override, decoder_digest,
        [innovation_calls](const mwperf::CanonicalRuntimeValueV1& state,
                           const mwperf::KernelTransitionV1& residual) {
          innovation_calls->fetch_add(1U, std::memory_order_relaxed);
          return mwperf::Result<
              std::vector<mwperf::ExactInnovationAtomV1>>::success(
              {{mwperf::KernelTransitionV1{state, residual.ordered_marks},
                mwperf::ExactRational::one()}});
        });
    mutate(*override.exact_innovation_contract);
    const auto output = override.conditional_sampler_contract->output_schema;
    auto fixture = seal_sampler(override, 1U);
    CHECK_FALSE(fixture.sampler.exact_innovation_available());
    const auto target = accepted_target(fixture.sampler);
    const auto plan = make_plan(fixture.sampler, plan_spec(
        1U, 0xC240512U,
        "c24.rb.invalid-binding." + std::string(suffix), target));
    const auto reward = reward_decoder(
        "c24.rb.invalid-binding.ordinary", decoder_digest, target, output,
        byte_reward([](const std::uint8_t value) {
          return static_cast<long double>(value);
        }));
    REQUIRE(mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan));
    const unsigned before_binding =
        override.conditional_sampler_calls->load(
            std::memory_order_relaxed);
    const auto unavailable = fixture.sampler.bind_exact_innovation_kernel(
        fixture.row, plan);
    REQUIRE_FALSE(unavailable);
    CHECK(unavailable.error().code == expected_code);
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == before_binding);
    CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);
  };

  SECTION("configured arrival") {
    audit("arrival", "c24.invalid_exact_innovation_binding",
          [](mwperf::ConditionalExactInnovationContractV1& value) {
            value.configured_arrival_law =
                matrix::digest("c24.rb.invalid-binding.other-arrival");
          });
  }
  SECTION("residual schema") {
    audit("residual", "c24.invalid_exact_innovation_binding",
          [](mwperf::ConditionalExactInnovationContractV1& value) {
            value.residual_schema =
                matrix::digest("c24.rb.invalid-binding.other-residual");
          });
  }
  SECTION("output schema") {
    audit("output", "c24.invalid_exact_innovation_binding",
          [](mwperf::ConditionalExactInnovationContractV1& value) {
            value.output_schema =
                matrix::digest("c24.rb.invalid-binding.other-output");
          });
  }
  SECTION("independent-coordinate authority is not the configured joint innovation") {
    audit("independent-coordinate", "c24.invalid_exact_innovation_binding",
          [](mwperf::ConditionalExactInnovationContractV1& value) {
            value.configured_joint_innovation = false;
          });
  }
  SECTION("metric target") {
    audit("target", "c24.exact_innovation_target_not_accepted",
          [](mwperf::ConditionalExactInnovationContractV1& value) {
            value.metric_target_digest =
                matrix::digest("c24.rb.invalid-binding.other-target");
          });
  }
}

TEST_CASE("C24 Rao-Blackwellizes a sealed C plus U innovation without a second draw",
          "[c24][unit][rao-blackwell]") {
  auto target = matrix::digest("c24.rb.target");
  const auto decoder_digest = matrix::digest("c24.rb.decoder");
  auto override = sampler_override(
      "c24.rb", 4U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::physical_trace;
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        const std::uint8_t joint =
            static_cast<std::uint8_t>(rng.next_u64() % 4U);
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            cu_atom(state, static_cast<std::uint8_t>(joint >> 1U),
                    static_cast<std::uint8_t>(joint & 1U)));
      };
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            {cu_atom(state, 0U, 0U), cu_atom(state, 0U, 1U),
             cu_atom(state, 1U, 0U), cu_atom(state, 1U, 1U)});
      };
  const auto output = override.conditional_sampler_contract->output_schema;
  auto innovation_calls = std::make_shared<std::atomic<unsigned>>(0U);
  const auto half = rational(1, 2);
  attach_innovation(
      override, decoder_digest,
      [innovation_calls, half](
          const mwperf::CanonicalRuntimeValueV1& state,
          const mwperf::KernelTransitionV1& residual) {
        innovation_calls->fetch_add(1U, std::memory_order_relaxed);
        const std::uint8_t c = mark_value(residual, 0U);
        return mwperf::Result<
            std::vector<mwperf::ExactInnovationAtomV1>>::success(
            {{cu_atom(state, c, 0U), half},
             {cu_atom(state, c, 1U), half}});
      });
  auto fixture = seal_sampler(override, 4U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.rb.reward", decoder_digest, target, output,
      [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        return mwperf::Result<long double>::success(
            static_cast<long double>(mark_value(sample, 0U) +
                                     mark_value(sample, 1U)));
      });

  // Select a fixed addressed bank containing each exact (C,U) atom once.
  // This is a deterministic search over the versioned C02 seed map, not an
  // empirical assertion about the Bernoulli law.
  std::optional<std::uint64_t> selected_seed;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto candidate_plan = make_plan(fixture.sampler,
        plan_spec(4U, seed, "c24.rb.common", target));
    auto candidate = mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, candidate_plan);
    REQUIRE(candidate);
    std::array<bool, 4U> seen{};
    const auto candidate_residual =
        candidate.value().empirical_residual();
    for (const auto& sample : candidate_residual.samples()) {
      const std::size_t index =
          2U * mark_value(sample, 0U) + mark_value(sample, 1U);
      REQUIRE(index < seen.size());
      seen[index] = true;
    }
    if (std::ranges::all_of(seen, [](const bool value) { return value; })) {
      selected_seed = seed;
      break;
    }
  }
  REQUIRE(selected_seed.has_value());
  const auto raw_plan = make_plan(fixture.sampler, plan_spec(
      4U, *selected_seed, "c24.rb.common", target));
  const auto rb_plan = make_plan(fixture.sampler, plan_spec(
      4U, *selected_seed, "c24.rb.common", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      true));
  const auto raw = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, raw_plan);
  REQUIRE(raw);
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);
  const auto rb = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, rb_plan);
  REQUIRE(rb);
  CHECK(raw.value().sampling_evidence().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::physical_trace);
  CHECK(rb.value().sampling_evidence() == raw.value().sampling_evidence());
  REQUIRE(raw.value().replay_streams().size() == 4U);
  REQUIRE(rb.value().replay_streams().size() == 4U);
  CHECK(std::ranges::equal(raw.value().replay_streams(),
                           rb.value().replay_streams()));
  CHECK(std::ranges::all_of(
      rb.value().replay_streams(),
      [](const mwperf::SamplingReplicationReplayV1& record) {
        return record.consumed_words == mwperf::BigNat{1U};
      }));
  CHECK(rb.value().claim_scope() ==
        mwperf::SamplingClaimScopeV1::rao_blackwell_row);
  REQUIRE(rb.value().raw_rewards().size() == raw.value().raw_rewards().size());
  const auto raw_residual = raw.value().empirical_residual();
  const auto residual_samples = raw_residual.samples();
  REQUIRE(residual_samples.size() == raw.value().raw_rewards().size());
  for (std::size_t index = 0U; index < raw.value().raw_rewards().size();
       ++index) {
    const long double c = mark_value(residual_samples[index], 0U);
    const long double u = mark_value(residual_samples[index], 1U);
    CHECK(close(raw.value().raw_rewards()[index], c + u));
    CHECK(close(rb.value().raw_rewards()[index],
                c + 0.5L));
  }
  CHECK(close(raw.value().value(), 1.0L));
  CHECK(close(rb.value().value(), 1.0L));
  REQUIRE(raw.value().sample_variance().has_value());
  REQUIRE(rb.value().sample_variance().has_value());
  REQUIRE(rb.value().exact_integration_absolute_error().has_value());
  CHECK(close(*rb.value().exact_integration_absolute_error(), 0.0L));
  CHECK(rb.value().costs().exact_innovation_atoms == mwperf::BigNat{8U});
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 4U);
  CHECK(raw.value().seal_digest() == fixture.sampler.seal_digest());
  CHECK(raw.value().plan_digest() == raw_plan.plan_digest());
  CHECK(raw.value().metric_target_digest() == target);
  CHECK_FALSE(raw.value().proposal_law_identity().has_value());
  CHECK_FALSE(raw.value().target_law_identity().has_value());
  CHECK(rb.value().seal_digest() == fixture.sampler.seal_digest());
  CHECK(rb.value().conditioning_row_digest() ==
        raw.value().conditioning_row_digest());
  CHECK(rb.value().plan_digest() == rb_plan.plan_digest());
  CHECK(rb.value().metric_target_digest() == target);
  CHECK_FALSE(rb.value().proposal_law_identity().has_value());
  CHECK_FALSE(rb.value().target_law_identity().has_value());

  // Exact four-atom population identities for independent
  // C,U ~ Bernoulli(1/2), Y=C+U and h(C)=C+1/2.  These are population
  // statements; no assertion compares per-batch raw and RB variances.
  constexpr long double y00 = 0.0L;
  constexpr long double y01 = 1.0L;
  constexpr long double y10 = 1.0L;
  constexpr long double y11 = 2.0L;
  constexpr long double mean_y = (y00 + y01 + y10 + y11) / 4.0L;
  constexpr long double variance_y =
      ((y00 - mean_y) * (y00 - mean_y) +
       (y01 - mean_y) * (y01 - mean_y) +
       (y10 - mean_y) * (y10 - mean_y) +
       (y11 - mean_y) * (y11 - mean_y)) /
      4.0L;
  constexpr long double h0 = (y00 + y01) / 2.0L;
  constexpr long double h1 = (y10 + y11) / 2.0L;
  constexpr long double variance_h =
      ((h0 - mean_y) * (h0 - mean_y) +
       (h1 - mean_y) * (h1 - mean_y)) /
      2.0L;
  constexpr long double conditional_variance_c0 =
      ((y00 - h0) * (y00 - h0) + (y01 - h0) * (y01 - h0)) /
      2.0L;
  constexpr long double conditional_variance_c1 =
      ((y10 - h1) * (y10 - h1) + (y11 - h1) * (y11 - h1)) /
      2.0L;
  constexpr long double mean_conditional_variance =
      (conditional_variance_c0 + conditional_variance_c1) / 2.0L;
  CHECK(close(mean_y, 1.0L));
  CHECK(close(variance_y, 0.5L));
  CHECK(close(variance_h, 0.25L));
  CHECK(close(mean_conditional_variance, 0.25L));
  CHECK(close(variance_y - variance_h, mean_conditional_variance));
  CHECK(close((variance_y - variance_h) / 4.0L,
              1.0L / 16.0L));

  const unsigned before_unauthorized =
      innovation_calls->load(std::memory_order_relaxed);
  const auto raw_innovation =
      fixture.sampler.bind_exact_innovation_kernel(fixture.row, raw_plan);
  REQUIRE_FALSE(raw_innovation);
  CHECK(raw_innovation.error().code == "c24.rao_blackwell_not_requested");
  CHECK(innovation_calls->load(std::memory_order_relaxed) ==
        before_unauthorized);

  auto rb_innovation =
      fixture.sampler.bind_exact_innovation_kernel(fixture.row, rb_plan);
  REQUIRE(rb_innovation);
  const auto bypass = mwperf::rao_blackwellize_known_innovation(
      raw.value().empirical_residual(), rb_innovation.value(), reward);
  REQUIRE_FALSE(bypass);
  CHECK(bypass.error().code == "c24.rao_blackwell_not_requested");
  CHECK(innovation_calls->load(std::memory_order_relaxed) ==
        before_unauthorized);

  const auto direct = mwperf::rao_blackwellize_known_innovation(
      rb.value().empirical_residual(), rb_innovation.value(), reward);
  REQUIRE(direct);
  CHECK(direct.value().sampling_evidence() ==
        raw.value().sampling_evidence());
  CHECK(close(direct.value().value(), rb.value().value()));

  const auto wrong_reward = reward_decoder(
      "c24.rb.wrong-reward", matrix::digest("c24.rb.other-decoder"),
      target, output,
      [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        return mwperf::Result<long double>::success(
            static_cast<long double>(mark_value(sample, 0U) +
                                     mark_value(sample, 1U)));
      });
  const unsigned before_reward_mismatch =
      innovation_calls->load(std::memory_order_relaxed);
  const auto reward_mismatch = mwperf::rao_blackwellize_known_innovation(
      rb.value().empirical_residual(), rb_innovation.value(),
      wrong_reward);
  REQUIRE_FALSE(reward_mismatch);
  CHECK(reward_mismatch.error().code ==
        "c24.rao_blackwell_reward_binding_mismatch");
  CHECK(innovation_calls->load(std::memory_order_relaxed) ==
        before_reward_mismatch);

  auto temporal_reward = reward;
  temporal_reward.requires_temporal_continuation = true;
  const auto temporal_mismatch =
      mwperf::rao_blackwellize_known_innovation(
          rb.value().empirical_residual(), rb_innovation.value(),
          temporal_reward);
  REQUIRE_FALSE(temporal_mismatch);
  CHECK(temporal_mismatch.error().code ==
        "c24.rao_blackwell_reward_binding_mismatch");
  CHECK(innovation_calls->load(std::memory_order_relaxed) ==
        before_reward_mismatch);

  const auto bounded_reward = reward_decoder(
      "c24.rb.bounded-reward", decoder_digest, target, output,
      [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        return mwperf::Result<long double>::success(
            static_cast<long double>(mark_value(sample, 0U) +
                                     mark_value(sample, 1U)));
      },
      false, mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto range_violation =
      mwperf::rao_blackwellize_known_innovation(
          rb.value().empirical_residual(), rb_innovation.value(),
          bounded_reward);
  REQUIRE_FALSE(range_violation);
  CHECK(range_violation.error().code ==
        "c24.integrated_reward_outside_audited_range");

  const auto other_rb_plan = make_plan(fixture.sampler, plan_spec(
      4U, *selected_seed, "c24.rb.other-plan", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      true));
  auto wrong_innovation = fixture.sampler.bind_exact_innovation_kernel(
      fixture.row, other_rb_plan);
  REQUIRE(wrong_innovation);
  const unsigned before = innovation_calls->load(std::memory_order_relaxed);
  const auto mismatch = mwperf::rao_blackwellize_known_innovation(
      rb.value().empirical_residual(), wrong_innovation.value(), reward);
  REQUIRE_FALSE(mismatch);
  CHECK(mismatch.error().code == "c24.rao_blackwell_binding_mismatch");
  CHECK(innovation_calls->load(std::memory_order_relaxed) == before);

  auto other_row = fixture.row;
  REQUIRE_FALSE(other_row.canonical_value.empty());
  const auto persistent_bit = std::to_integer<std::uint8_t>(
                                  other_row.canonical_value.back()) &
                              1U;
  other_row.canonical_value.back() =
      static_cast<std::byte>(persistent_bit == 0U ? 1U : 0U);
  auto row_bound_innovation =
      fixture.sampler.bind_exact_innovation_kernel(other_row, rb_plan);
  REQUIRE(row_bound_innovation);
  const auto row_mismatch = mwperf::rao_blackwellize_known_innovation(
      rb.value().empirical_residual(), row_bound_innovation.value(),
      reward);
  REQUIRE_FALSE(row_mismatch);
  CHECK(row_mismatch.error().code ==
        "c24.rao_blackwell_binding_mismatch");
  CHECK(innovation_calls->load(std::memory_order_relaxed) == before);

  auto other_override = override;
  other_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto other_fixture = seal_sampler(other_override, 4U);
  auto cross_seal_innovation =
      other_fixture.sampler.bind_exact_innovation_kernel(
          other_fixture.row, rb_plan);
  REQUIRE(cross_seal_innovation);
  const auto seal_mismatch = mwperf::rao_blackwellize_known_innovation(
      rb.value().empirical_residual(), cross_seal_innovation.value(),
      reward);
  REQUIRE_FALSE(seal_mismatch);
  CHECK(seal_mismatch.error().code ==
        "c24.rao_blackwell_binding_mismatch");
  CHECK(other_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
  CHECK(innovation_calls->load(std::memory_order_relaxed) == before);
}

TEST_CASE("C24 separates deterministic innovation error from sampling uncertainty",
          "[c24][unit][rao-blackwell][error-separation]") {
  auto target = matrix::digest("c24.rb.error.target");
  const auto decoder_digest = matrix::digest("c24.rb.error.decoder");
  auto override = sampler_override(
      "c24.rb.error", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_innovation(
      override, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1& state,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<
            std::vector<mwperf::ExactInnovationAtomV1>>::success(
            {{atom(state, 0U), mwperf::ExactRational::one()}});
      },
      rational(1, 100));
  auto fixture = seal_sampler(
      override, 100U, mwperf::StatisticalIntervalKindV1::hoeffding);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.rb.error", decoder_digest, target, output,
      [](const mwperf::ConditioningState&, const mwperf::Sample&) {
        return mwperf::Result<long double>::success(0.5L);
      },
      false, mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto plan = make_plan(fixture.sampler, plan_spec(
      100U, 0xC240604U, "c24.rb.error", target,
      mwperf::StatisticalIntervalKindV1::hoeffding,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one(),
      mwperf::StageTag::generic_sampling, true));
  const auto result = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, plan);
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  CHECK(close(result.value().value(), 0.5L));
  REQUIRE(result.value().sample_variance().has_value());
  CHECK(close(*result.value().sample_variance(), 0.0L));
  REQUIRE(result.value().exact_integration_absolute_error().has_value());
  const long double deterministic_error =
      *result.value().exact_integration_absolute_error();
  CHECK(deterministic_error >= 0.01L);
  CHECK(deterministic_error < 0.011L);
  REQUIRE(result.value().interval().has_value());
  const long double sampling_radius =
      std::sqrt(std::log(40.0L) / 200.0L);
  CHECK(close(result.value().interval()->lower,
              0.5L - sampling_radius - deterministic_error));
  CHECK(close(result.value().interval()->upper,
              0.5L + sampling_radius + deterministic_error));
  CHECK(result.value().interval()->controls ==
        mwperf::SamplingClaimScopeV1::rao_blackwell_row);
  CHECK(result.value().costs().draws == mwperf::BigNat{100U});
  CHECK(result.value().costs().exact_innovation_atoms ==
        mwperf::BigNat{100U});
}

TEST_CASE("C24 Rao-Blackwellization accepts a residual-only sample decoder domain",
          "[c24][unit][rao-blackwell][residual-only]") {
  auto target = matrix::digest("c24.rb.residual-only.target");
  const auto decoder_digest =
      matrix::digest("c24.rb.residual-only.decoder");
  auto override = sampler_override(
      "c24.rb.residual-only", 2U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        const auto c = static_cast<std::uint8_t>(rng.next_u64() & 1U);
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            cu_atom(state, c, UINT8_C(0xff)));
      };
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            {cu_atom(state, 0U, UINT8_C(0xff)),
             cu_atom(state, 1U, UINT8_C(0xff))});
      };
  const auto output = override.conditional_sampler_contract->output_schema;
  auto innovation_calls = std::make_shared<std::atomic<unsigned>>(0U);
  const auto half = rational(1, 2);
  attach_innovation(
      override, decoder_digest,
      [innovation_calls, half](
          const mwperf::CanonicalRuntimeValueV1& state,
          const mwperf::KernelTransitionV1& residual) {
        innovation_calls->fetch_add(1U, std::memory_order_relaxed);
        const std::uint8_t c = mark_value(residual, 0U);
        return mwperf::Result<
            std::vector<mwperf::ExactInnovationAtomV1>>::success(
            {{cu_atom(state, c, 0U), half},
             {cu_atom(state, c, 1U), half}});
      });
  auto fixture = seal_sampler(override, 6U);
  target = accepted_target(fixture.sampler);
  auto residual_decode_attempts =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto completed_decode_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  const auto reward = reward_decoder(
      "c24.rb.residual-only", decoder_digest, target, output,
      [residual_decode_attempts, completed_decode_calls](
          const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        const std::uint8_t u = mark_value(sample, 1U);
        if (u == UINT8_C(0xff)) {
          residual_decode_attempts->fetch_add(
              1U, std::memory_order_relaxed);
          return mwperf::Result<long double>::failure(
              matrix::reached_materializer());
        }
        completed_decode_calls->fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<long double>::success(
            static_cast<long double>(mark_value(sample, 0U) + u));
      });

  const auto ordinary_plan = make_plan(fixture.sampler, plan_spec(
      6U, 0xC240602U, "c24.rb.residual-only", target));
  const auto ordinary = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, ordinary_plan);
  REQUIRE_FALSE(ordinary);
  CHECK(ordinary.error().code ==
        "c16.fixture.registered_pair_materializer_reached");
  CHECK(residual_decode_attempts->load(std::memory_order_relaxed) == 1U);
  CHECK(completed_decode_calls->load(std::memory_order_relaxed) == 0U);
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);

  residual_decode_attempts->store(0U, std::memory_order_relaxed);
  const auto rb_plan = make_plan(fixture.sampler, plan_spec(
      6U, 0xC240602U, "c24.rb.residual-only", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      true));
  const auto rb = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, rb_plan);
  INFO((rb ? std::string{}
           : rb.error().code + ": " + rb.error().message));
  REQUIRE(rb);
  CHECK(residual_decode_attempts->load(std::memory_order_relaxed) == 0U);
  CHECK(completed_decode_calls->load(std::memory_order_relaxed) == 12U);
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 6U);
  CHECK(rb.value().claim_scope() ==
        mwperf::SamplingClaimScopeV1::rao_blackwell_row);
  CHECK(rb.value().costs().draws == mwperf::BigNat{6U});
  CHECK(rb.value().costs().exact_innovation_atoms == mwperf::BigNat{12U});
  for (const long double conditional_mean : rb.value().raw_rewards()) {
    CHECK((conditional_mean == 0.5L || conditional_mean == 1.5L));
  }
}

TEST_CASE("C24 rejects an unavailable Rao-Blackwell branch before drawing",
          "[c24][negative][rao-blackwell][unavailable]") {
  auto target = matrix::digest("c24.rb.unavailable.target");
  const auto decoder_digest = matrix::digest("c24.rb.unavailable.decoder");
  auto override = sampler_override(
      "c24.rb.unavailable", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  auto fixture = seal_sampler(override, 3U);
  target = accepted_target(fixture.sampler);
  CHECK_FALSE(fixture.sampler.exact_innovation_available());
  const auto reward = reward_decoder(
      "c24.rb.unavailable", decoder_digest, target, output,
      byte_reward([](const std::uint8_t) { return 1.0L; }));

  const auto ordinary_plan = make_plan(fixture.sampler, plan_spec(
      3U, 0xC240603U, "c24.rb.unavailable", target));
  const auto ordinary = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, ordinary_plan);
  REQUIRE(ordinary);
  const unsigned before = override.conditional_sampler_calls->load(
      std::memory_order_relaxed);
  CHECK(before == 3U);

  const auto rb_plan = make_plan(fixture.sampler, plan_spec(
      3U, 0xC240603U, "c24.rb.unavailable", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      true));
  const auto unavailable = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, rb_plan);
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code == "c24.exact_innovation_unavailable");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == before);
}

TEST_CASE("C24 rejects Rao-Blackwell use not requested by the bound plan",
          "[c24][negative][rao-blackwell][authorization]") {
  auto target = matrix::digest("c24.rb.authorization.target");
  const auto decoder_digest =
      matrix::digest("c24.rb.authorization.decoder");
  auto override = sampler_override(
      "c24.rb.authorization", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  auto innovation_calls = std::make_shared<std::atomic<unsigned>>(0U);
  attach_innovation(
      override, decoder_digest,
      [innovation_calls](const mwperf::CanonicalRuntimeValueV1& state,
                         const mwperf::KernelTransitionV1& residual) {
        innovation_calls->fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<
            std::vector<mwperf::ExactInnovationAtomV1>>::success(
            {{atom(state, atom_value(residual)),
              mwperf::ExactRational::one()}});
      });
  auto fixture = seal_sampler(override, 2U);
  target = accepted_target(fixture.sampler);
  const auto reward = reward_decoder(
      "c24.rb.authorization", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));

  const auto ordinary_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240604U, "c24.rb.authorization", target));
  const auto ordinary = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, ordinary_plan);
  REQUIRE(ordinary);
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);

  const auto rejected_binding =
      fixture.sampler.bind_exact_innovation_kernel(fixture.row,
                                                   ordinary_plan);
  REQUIRE_FALSE(rejected_binding);
  CHECK(rejected_binding.error().code ==
        "c24.rao_blackwell_not_requested");
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);

  const auto authorized_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240604U, "c24.rb.authorization", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
      true));
  const auto innovation = fixture.sampler.bind_exact_innovation_kernel(
      fixture.row, authorized_plan);
  REQUIRE(innovation);
  const auto bypass = mwperf::rao_blackwellize_known_innovation(
      ordinary.value().empirical_residual(), innovation.value(), reward);
  REQUIRE_FALSE(bypass);
  CHECK(bypass.error().code == "c24.rao_blackwell_not_requested");
  CHECK(innovation_calls->load(std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects a reward-route plan at the empirical-row boundary",
          "[c24][negative][empirical-row][backend-route]") {
  const auto target = matrix::digest("c24.row.reward-route.target");
  auto override = sampler_override(
      "c24.row.reward-route", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  auto fixture = seal_sampler(override, 2U);
  const auto plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC2406FFU, "c24.row.reward-route", target));
  REQUIRE(plan.accepted_backend_route() ==
          mwperf::BackendRouteKindV1::conditional_reward_monte_carlo);

  const auto result = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c24.empirical_row_requires_row_route");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects row-route plans at reward estimator boundaries",
          "[c24][negative][reward][importance][backend-route]") {
  auto cold_override = sampler_override(
      "c24.reward.row-route", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, 0U);
  const auto cold_output =
      cold_override.conditional_sampler_contract->output_schema;
  auto cold_fixture = seal_row_sampler(cold_override, 2U);
  const auto cold_target = accepted_target(cold_fixture.sampler);
  const auto cold_reward = reward_decoder(
      "c24.reward.row-route",
      matrix::digest("c24.reward.row-route.decoder"), cold_target,
      cold_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  const auto cold_plan = make_plan(cold_fixture.sampler, plan_spec(
      2U, 0xC2406F0U, "c24.reward.row-route", cold_target));
  REQUIRE(cold_plan.accepted_backend_route() ==
          mwperf::BackendRouteKindV1::conditional_row_monte_carlo);

  const auto reward_result = mwperf::estimate_reward_expectation(
      cold_fixture.sampler, cold_fixture.row, cold_reward, cold_plan);
  REQUIRE_FALSE(reward_result);
  CHECK(reward_result.error().code == "c24.reward_requires_reward_route");
  CHECK(cold_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  auto proposal_override = sampler_override(
      "c24.importance.row-route", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal, 0U);
  proposal_override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::proposal;
  const auto proposal_output =
      proposal_override.conditional_sampler_contract->output_schema;
  const auto proposal_decoder_digest =
      matrix::digest("c24.importance.row-route.decoder");
  attach_ratio(
      proposal_override, matrix::digest("c24.importance.row-route.target"),
      proposal_decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      });
  auto proposal_fixture = seal_row_sampler(proposal_override, 2U);
  const auto proposal_target = accepted_target(proposal_fixture.sampler);
  const auto proposal_reward = reward_decoder(
      "c24.importance.row-route", proposal_decoder_digest, proposal_target,
      proposal_output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }));
  const auto proposal_plan = make_plan(proposal_fixture.sampler, plan_spec(
      2U, 0xC2406F1U, "c24.importance.row-route", proposal_target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  auto ratio = proposal_fixture.sampler.bind_target_density_ratio(
      proposal_fixture.row, proposal_plan);
  REQUIRE(ratio);

  const auto importance_result = mwperf::estimate_importance_weighted(
      proposal_fixture.sampler, proposal_fixture.row, ratio.value(),
      proposal_reward, proposal_plan);
  REQUIRE_FALSE(importance_result);
  CHECK(importance_result.error().code ==
        "c24.importance_requires_reward_route");
  CHECK(proposal_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects estimator-inapplicable plan clauses before drawing",
          "[c24][negative][plan][estimator-gating]") {
  auto target = matrix::digest("c24.plan-gating.target");
  const auto decoder_digest = matrix::digest("c24.plan-gating.decoder");
  auto override = sampler_override(
      "c24.plan-gating", 1U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal, 0U);
  const auto output = override.conditional_sampler_contract->output_schema;
  attach_ratio(
      override, target, decoder_digest,
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1&) {
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             1.0L});
      });
  auto fixture = seal_sampler(override, 2U);
  auto interval_override = override;
  interval_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto interval_fixture = seal_sampler(
      interval_override, 2U,
      mwperf::StatisticalIntervalKindV1::exact_binomial);
  target = accepted_target(fixture.sampler);
  const auto interval_target = accepted_target(interval_fixture.sampler);
  const auto reward = reward_decoder(
      "c24.plan-gating", decoder_digest, target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, mwperf::ExactRational::zero(), mwperf::ExactRational::one());
  const auto interval_reward = reward_decoder(
      "c24.plan-gating", decoder_digest, interval_target, output,
      byte_reward([](const std::uint8_t value) {
        return static_cast<long double>(value);
      }),
      true, mwperf::ExactRational::zero(), mwperf::ExactRational::one());

  const auto check_no_draw = [&] {
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
    CHECK(interval_override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  };

  const auto proposal_row_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240700U, "c24.plan-gating.proposal-row", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal));
  const auto proposal_row = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, proposal_row_plan);
  REQUIRE_FALSE(proposal_row);
  CHECK(proposal_row.error().code ==
        "c24.proposal_requires_importance_estimator");
  check_no_draw();

  const auto proposal_reward = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, proposal_row_plan);
  REQUIRE_FALSE(proposal_reward);
  CHECK(proposal_reward.error().code ==
        "c24.proposal_requires_importance_estimator");
  check_no_draw();

  const auto proposal_rb_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240700U, "c24.plan-gating.proposal-rb", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      true));
  const auto proposal_rb = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, proposal_rb_plan);
  REQUIRE_FALSE(proposal_rb);
  CHECK(proposal_rb.error().code ==
        "c24.proposal_requires_importance_estimator");
  check_no_draw();

  const auto row_interval_plan = make_plan(interval_fixture.sampler, plan_spec(
      2U, 0xC240701U, "c24.plan-gating.row-interval", interval_target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one(),
      mwperf::StageTag::importance_proposal));
  const auto row_interval = mwperf::estimate_discrete_kernel_row(
      interval_fixture.sampler, interval_fixture.row, row_interval_plan);
  REQUIRE_FALSE(row_interval);
  CHECK(row_interval.error().code ==
        "c24.empirical_row_reward_interval_not_supported");
  check_no_draw();

  const auto row_rb_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240702U, "c24.plan-gating.row-rb", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      true));
  const auto row_rb = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, row_rb_plan);
  REQUIRE_FALSE(row_rb);
  CHECK(row_rb.error().code ==
        "c24.empirical_row_rao_blackwell_not_supported");
  check_no_draw();

  const auto reward_tv_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240703U, "c24.plan-gating.reward-tv", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      false, mwperf::TotalVariationRequestV1{0.5L, 0.1L, 1U}));
  const auto reward_tv = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, reward_tv_plan);
  REQUIRE_FALSE(reward_tv);
  CHECK(reward_tv.error().code ==
        "c24.reward_total_variation_not_supported");
  check_no_draw();

  const auto reward_rb_tv_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240704U, "c24.plan-gating.reward-rb-tv", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      true, mwperf::TotalVariationRequestV1{0.5L, 0.1L, 1U}));
  const auto reward_rb_tv = mwperf::estimate_reward_expectation(
      fixture.sampler, fixture.row, reward, reward_rb_tv_plan);
  REQUIRE_FALSE(reward_rb_tv);
  CHECK(reward_rb_tv.error().code ==
        "c24.reward_total_variation_not_supported");
  check_no_draw();

  const auto check_importance_rejection =
      [&](const mwperf::NormalizedSamplerAccess& sampler,
          const mwperf::ConditioningState& row,
          const mwperf::RewardDecoder& bound_reward,
          const mwperf::SamplingPlan& plan, const std::string_view code) {
        auto ratio =
            sampler.bind_target_density_ratio(row, plan);
        REQUIRE(ratio);
        const auto estimate = mwperf::estimate_importance_weighted(
            sampler, row, ratio.value(), bound_reward, plan);
        REQUIRE_FALSE(estimate);
        CHECK(estimate.error().code == code);
        check_no_draw();
      };

  const auto importance_tv_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240705U, "c24.plan-gating.importance-tv", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      false, mwperf::TotalVariationRequestV1{0.5L, 0.1L, 1U}));
  check_importance_rejection(
      fixture.sampler, fixture.row, reward, importance_tv_plan,
      "c24.importance_total_variation_not_supported");

  const auto importance_rb_plan = make_plan(fixture.sampler, plan_spec(
      2U, 0xC240706U, "c24.plan-gating.importance-rb", target,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::StatisticalEstimandKindV1::point_with_variance_diagnostics,
      std::nullopt, std::nullopt, mwperf::StageTag::importance_proposal,
      true));
  check_importance_rejection(
      fixture.sampler, fixture.row, reward, importance_rb_plan,
      "c24.importance_rao_blackwell_not_supported");

  const auto importance_interval_plan = make_plan(
      interval_fixture.sampler, plan_spec(
      2U, 0xC240707U, "c24.plan-gating.importance-interval", interval_target,
      mwperf::StatisticalIntervalKindV1::exact_binomial,
      mwperf::StatisticalEstimandKindV1::binary_proportion,
      mwperf::ExactRational::zero(), mwperf::ExactRational::one(),
      mwperf::StageTag::importance_proposal));
  check_importance_rejection(
      interval_fixture.sampler, interval_fixture.row, interval_reward,
      importance_interval_plan, "c24.importance_interval_not_supported");
}
