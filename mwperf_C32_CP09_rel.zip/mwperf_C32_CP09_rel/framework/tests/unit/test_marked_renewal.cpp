#include <algorithm>
#include <array>
#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

using RenewalStepSignature = mwperf::Result<mwperf::ArrivalStep> (*)(
    mwperf::RenewalCursor&, const mwperf::BigNat&);

static_assert(std::same_as<decltype(&mwperf::next_marked_renewal_batch),
                           RenewalStepSignature>);
static_assert(std::same_as<mwperf::RenewalCursor, mwperf::ArrivalProcess>);
static_assert(!std::is_default_constructible_v<mwperf::RenewalLaw>);
static_assert(std::is_copy_constructible_v<mwperf::RenewalLaw>);

struct ParsedRenewal final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

struct ObservedRenewalEvent final {
  std::uint64_t slot;
  std::size_t queue;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> serial{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c11-marked-renewal";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("renewal-" + std::to_string(serial.fetch_add(1U)) +
                   ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output << text;
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedRenewal parse_arrival(const std::string_view arrival) {
  const std::string model_text =
      R"json({"schema_version":"3.0.0","switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2"],"max_search_states":null}},"arrival":)json" +
      std::string(arrival) +
      R"json(,"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})json";
  auto document = mwperf::load_document(write_model(model_text));
  REQUIRE(document);
  auto executable = mwperf::extract_executable_model(document.value());
  REQUIRE(executable);
  auto model = mwperf::parse_model_config_v3(executable.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedRenewal{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] const mwperf::IndependentMarkedRenewalArrival& authored(
    const ParsedRenewal& parsed) {
  return std::get<mwperf::IndependentMarkedRenewalArrival>(
      parsed.model.arrival.value);
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(
      "606162636465666768696a6b6c6d6e6f"
      "707172737475767778797a7b7c7d7e7f");
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t realization = 0U) {
  auto key = mwperf::make_physical_reference_instance_key(
      fixture_digest(), mwperf::BigNat(realization));
  REQUIRE(key);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::CompiledArrivalLaw compile_full(
    const ParsedRenewal& parsed) {
  auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t seed = 1101U,
    const std::uint64_t realization = 0U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, realization));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, mwperf::ArrivalInitialState{mwperf::RenewalOrigin{}},
      std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto value = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(value);
  return std::move(value).value();
}

void check_same_snapshot(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  CHECK(left.expected_slot == right.expected_slot);
  CHECK(left.phase_digest == right.phase_digest);
  CHECK(left.rng.rng_version() == right.rng.rng_version());
  CHECK(left.rng.stream_identity() == right.rng.stream_identity());
  CHECK(left.rng.state_words() == right.rng.state_words());
  CHECK(left.rng.consumed_words() == right.rng.consumed_words());
}

[[nodiscard]] std::uint64_t count_at(const mwperf::ArrivalBatch& batch,
                                     const std::size_t queue) {
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    if (entry.queue.ordinal() == queue) {
      return entry.count.value().convert_to<std::uint64_t>();
    }
  }
  return 0U;
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                              const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  if (!result) {
    throw std::logic_error("invalid C11 rational fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] std::vector<ObservedRenewalEvent> replay_and_collect(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t last_slot,
    const std::uint64_t seed) {
  auto first = instantiate(law, seed, 9U);
  auto replay = instantiate(law, seed, 9U);
  std::vector<ObservedRenewalEvent> events;
  for (std::uint64_t slot = 0U; slot <= last_slot; ++slot) {
    auto left = mwperf::next_arrival_step(first, mwperf::BigNat(slot));
    auto right = mwperf::next_arrival_step(replay, mwperf::BigNat(slot));
    REQUIRE(left);
    REQUIRE(right);
    CHECK(left.value().batch == right.value().batch);
    CHECK(left.value().law_digest == right.value().law_digest);
    CHECK(left.value().realization_identity ==
          right.value().realization_identity);
    CHECK(mwperf::arrival_phase_digest(left.value().phase_before) ==
          mwperf::arrival_phase_digest(right.value().phase_before));
    CHECK(mwperf::arrival_phase_digest(left.value().phase_after) ==
          mwperf::arrival_phase_digest(right.value().phase_after));
    if (!left.value().batch.empty_batch()) {
      REQUIRE(left.value().batch.entries().size() == 1U);
      CHECK(left.value().batch.entries()[0U].count == mwperf::BigNat(1U));
      events.push_back(ObservedRenewalEvent{
          slot, left.value().batch.entries()[0U].queue.ordinal()});
    }
  }
  check_same_snapshot(snapshot(first), snapshot(replay));
  return events;
}

}  // namespace

TEST_CASE("C11 renewal uses the exact minus-one event origin",
          "[c11][unit][renewal]") {
  auto parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[
      {"id":"every","interarrival":{"kind":"deterministic","d":1},
       "destination_pmf":[{"queue_id":"q0","probability":1}]},
      {"id":"thirds","interarrival":{"kind":"deterministic","d":3},
       "destination_pmf":[{"queue_id":"q1","probability":1}]}
    ],"metadata":{}
  })json");

  auto geometry = mwperf::compile_marked_renewal(authored(parsed),
                                                  parsed.queues);
  REQUIRE(geometry);
  REQUIRE(geometry.value().sources().size() == 2U);
  const auto& every = std::get<mwperf::FactorizedRenewalLawSource>(
      geometry.value().sources()[0U]);
  const auto& thirds = std::get<mwperf::FactorizedRenewalLawSource>(
      geometry.value().sources()[1U]);
  CHECK(every.source_id == "every");
  CHECK(thirds.source_id == "thirds");
  CHECK(std::get<mwperf::DeterministicRenewalGap>(every.interarrival).gap ==
        mwperf::BigNat(1U));
  CHECK(std::get<mwperf::DeterministicRenewalGap>(thirds.interarrival).gap ==
        mwperf::BigNat(3U));

  auto law = compile_full(parsed);
  CHECK(law.family() ==
        mwperf::ArrivalFamily::independent_marked_renewal);
  auto process = instantiate(law);
  CHECK(snapshot(process).rng.consumed_words().is_zero());

  for (std::uint64_t slot = 0U; slot <= 8U; ++slot) {
    auto step =
        mwperf::next_marked_renewal_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(step.value().authored_slot == mwperf::BigNat(slot));
    CHECK(step.value().physical_arrival_epoch() == mwperf::BigNat(slot + 1U));
    CHECK(count_at(step.value().batch, 0U) == 1U);
    CHECK(count_at(step.value().batch, 1U) ==
          ((slot == 2U || slot == 5U || slot == 8U) ? 1U : 0U));
  }
  CHECK(snapshot(process).rng.consumed_words().is_zero());
}

TEST_CASE("C11 finite and p-one geometric gaps preserve exact sampling rows",
          "[c11][unit][renewal]") {
  SECTION("finite row retains authored categorical coordinates") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"finite",
        "interarrival":{"kind":"finite_pmf","outcomes":[
          {"d":7,"probability":0},
          {"d":2,"probability":1},
          {"d":5,"probability":0}]},
        "destination_pmf":[{"queue_id":"q1","probability":1}]
      }],"metadata":{}
    })json");
    auto geometry =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE(geometry);
    const auto& source = std::get<mwperf::FactorizedRenewalLawSource>(
        geometry.value().sources()[0U]);
    const auto& finite =
        std::get<mwperf::FiniteRenewalGap>(source.interarrival);
    CHECK(finite.gaps == std::vector<mwperf::BigNat>{
                             mwperf::BigNat(7U), mwperf::BigNat(2U),
                             mwperf::BigNat(5U)});
    CHECK(finite.probabilities.integral_masses() ==
          std::vector<mwperf::BigNat>{mwperf::BigNat(0U),
                                      mwperf::BigNat(1U),
                                      mwperf::BigNat(0U)});

    auto process = instantiate(compile_full(parsed), 1102U);
    for (std::uint64_t slot = 0U; slot <= 5U; ++slot) {
      auto step = mwperf::next_arrival_step(process, mwperf::BigNat(slot));
      REQUIRE(step);
      CHECK(count_at(step.value().batch, 1U) ==
            ((slot == 1U || slot == 3U || slot == 5U) ? 1U : 0U));
    }
    CHECK(snapshot(process).rng.consumed_words().is_zero());
  }

  SECTION("geometric p one uses d-min and consumes no engine word") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"geometric",
        "interarrival":{"kind":"geometric_grid","d_min":4,"delta":9,
                        "p":1},
        "destination_pmf":[{"queue_id":"q2","probability":1}]
      }],"metadata":{}
    })json");
    auto geometry =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE(geometry);
    const auto& source = std::get<mwperf::FactorizedRenewalLawSource>(
        geometry.value().sources()[0U]);
    const auto& geometric =
        std::get<mwperf::GeometricGridRenewalGap>(source.interarrival);
    CHECK(geometric.d_min == mwperf::BigNat(4U));
    CHECK(geometric.delta == mwperf::BigNat(9U));
    CHECK(geometric.trial_probabilities.integral_masses() ==
          std::vector<mwperf::BigNat>{mwperf::BigNat(1U),
                                      mwperf::BigNat(0U)});

    auto process = instantiate(compile_full(parsed), 1103U);
    const auto before = snapshot(process);
    CHECK(before.rng.consumed_words().is_zero());
    for (std::uint64_t slot = 0U; slot <= 8U; ++slot) {
      auto step = mwperf::next_arrival_step(process, mwperf::BigNat(slot));
      REQUIRE(step);
      CHECK(count_at(step.value().batch, 2U) ==
            ((slot == 3U || slot == 7U) ? 1U : 0U));
    }
    CHECK(snapshot(process).rng.consumed_words().is_zero());
  }

  SECTION("geometric trials use fixed failure failure success indexing") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"geometric",
        "interarrival":{"kind":"geometric_grid","d_min":4,"delta":9,
                        "p":0.5},
        "destination_pmf":[{"queue_id":"q2","probability":1}]
      }],"metadata":{}
    })json");
    auto geometry =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE(geometry);
    const auto& source = std::get<mwperf::FactorizedRenewalLawSource>(
        geometry.value().sources()[0U]);
    const auto& geometric =
        std::get<mwperf::GeometricGridRenewalGap>(source.interarrival);

    const std::array<std::uint64_t, 1U> failure{1U};
    const std::array<std::uint64_t, 1U> success{0U};
    const auto first = mwperf::testing::sample_categorical_with_script(
        geometric.trial_probabilities, failure);
    const auto second = mwperf::testing::sample_categorical_with_script(
        geometric.trial_probabilities, failure);
    const auto third = mwperf::testing::sample_categorical_with_script(
        geometric.trial_probabilities, success);
    REQUIRE(first);
    REQUIRE(second);
    REQUIRE(third);
    CHECK(first.value().index == 1U);
    CHECK(second.value().index == 1U);
    CHECK(third.value().index == 0U);
    const mwperf::BigNat failures(2U);
    CHECK(geometric.d_min + geometric.delta * failures ==
          mwperf::BigNat(22U));
  }
}

TEST_CASE("C11 joint renewal keeps gap-mark dependence while factorized draws do not",
          "[c11][unit][renewal]") {
  auto factorized = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[{
      "id":"source",
      "interarrival":{"kind":"finite_pmf","outcomes":[
        {"d":1,"probability":0.5},{"d":3,"probability":0.5}]},
      "destination_pmf":[
        {"queue_id":"q0","probability":0.5},
        {"queue_id":"q1","probability":0.5}]
    }],"metadata":{}
  })json");
  auto joint = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[{
      "id":"source","joint_pmf":[
        {"d":1,"queue_id":"q0","probability":0.5},
        {"d":3,"queue_id":"q1","probability":0.5}]
    }],"metadata":{}
  })json");

  auto joint_geometry =
      mwperf::compile_marked_renewal(authored(joint), joint.queues);
  REQUIRE(joint_geometry);
  const auto& joint_source = std::get<mwperf::JointRenewalLawSource>(
      joint_geometry.value().sources()[0U]);
  REQUIRE(joint_source.outcomes.size() == 2U);
  CHECK(joint_source.outcomes[0U].gap == mwperf::BigNat(1U));
  CHECK(joint_source.outcomes[0U].destination.ordinal() == 0U);
  CHECK(joint_source.outcomes[1U].gap == mwperf::BigNat(3U));
  CHECK(joint_source.outcomes[1U].destination.ordinal() == 1U);

  const auto factorized_events =
      replay_and_collect(compile_full(factorized), 399U, 1104U);
  const auto joint_events =
      replay_and_collect(compile_full(joint), 399U, 1104U);
  REQUIRE(factorized_events.size() > 50U);
  REQUIRE(joint_events.size() > 50U);

  const auto gap_at = [](const std::vector<ObservedRenewalEvent>& events,
                         const std::size_t index) {
    return index == 0U ? events[0U].slot + 1U
                       : events[index].slot - events[index - 1U].slot;
  };
  bool factorized_recombined = false;
  for (std::size_t index = 0U; index < joint_events.size(); ++index) {
    const std::uint64_t gap = gap_at(joint_events, index);
    CHECK(((gap == 1U && joint_events[index].queue == 0U) ||
           (gap == 3U && joint_events[index].queue == 1U)));
  }
  for (std::size_t index = 0U; index < factorized_events.size(); ++index) {
    const std::uint64_t gap = gap_at(factorized_events, index);
    REQUIRE((gap == 1U || gap == 3U));
    REQUIRE(factorized_events[index].queue <= 1U);
    factorized_recombined =
        factorized_recombined ||
        (gap == 1U && factorized_events[index].queue == 1U) ||
        (gap == 3U && factorized_events[index].queue == 0U);
  }
  CHECK(factorized_recombined);
}

TEST_CASE("C11 renewal support and capabilities make only proved claims",
          "[c11][unit][renewal]") {
  auto parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[
      {"id":"factorized",
       "interarrival":{"kind":"deterministic","d":2},
       "destination_pmf":[
         {"queue_id":"q0","probability":1},
         {"queue_id":"q2","probability":0}]},
      {"id":"joint","joint_pmf":[
         {"d":1,"queue_id":"q1","probability":1},
         {"d":4,"queue_id":"q2","probability":0}]}
    ],"metadata":{}
  })json");
  auto law = compile_full(parsed);
  CHECK(mwperf::positive_arrival_support(law).bytes() ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  const auto capabilities = mwperf::arrival_capabilities(law);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());

  const auto rows = mwperf::testing::normalized_arrival_rows_for_testing(law);
  REQUIRE(rows.size() == 2U);
  CHECK(rows[0U].kind ==
        mwperf::ArrivalCategoricalRowKind::destination);
  CHECK(rows[1U].kind ==
        mwperf::ArrivalCategoricalRowKind::joint_gap_destination);
}

TEST_CASE("C27.1 unit-grid geometric renewals publish their exact IID batch",
          "[c11][c27_1][unit][renewal][capability]") {
  auto parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[
      {"id":"s0","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0","probability":1}]},
      {"id":"s1","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0","probability":1}]},
      {"id":"s2","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0","probability":1}]},
      {"id":"s3","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.125},"destination_pmf":[{"queue_id":"q0","probability":1}]}
    ],"metadata":{}
  })json");
  auto law = compile_full(parsed);

  const auto capabilities = mwperf::arrival_capabilities(law);
  REQUIRE(capabilities.exact_factorized_iid_generator.has_value());
  CHECK(capabilities.exact_factorized_iid_generator->provision ==
        mwperf::AccessProvision::portable_only);
  REQUIRE(capabilities.exact_iid_joint_vector.has_value());
  CHECK(capabilities.exact_iid_joint_vector->finite_support);
  CHECK(capabilities.exact_iid_joint_vector->provision ==
        mwperf::AccessProvision::portable_only);
  REQUIRE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_coordinate_moments->maximum_order ==
        std::optional<mwperf::BigNat>{mwperf::BigNat(1U)});
  CHECK_FALSE(capabilities.exact_coordinate_moments->joint);
  CHECK_FALSE(capabilities.exact_coordinate_moments->conditioned_on_phase);
  CHECK(capabilities.exact_coordinate_moments->provision ==
        mwperf::AccessProvision::portable_only);

  const auto view = mwperf::builder_arrival_view(law);
  REQUIRE(view.iid_joint_table().has_value());
  const auto& table = *view.iid_joint_table();
  REQUIRE(table.size() == 5U);
  const std::array expected_mass{
      rational(2401, 4096), rational(343, 1024), rational(147, 2048),
      rational(7, 1024), rational(1, 4096)};
  for (std::size_t count = 0U; count < table.size(); ++count) {
    CHECK(table[count].dense_counts ==
          std::vector<mwperf::BigNat>{mwperf::BigNat(count),
                                      mwperf::BigNat(0U),
                                      mwperf::BigNat(0U)});
    CHECK(table[count].probability == expected_mass[count]);
  }

  REQUIRE(view.moments().has_value());
  const auto& moments = *view.moments();
  REQUIRE(moments.size() == parsed.queues.size());
  for (std::size_t ordinal = 0U; ordinal < moments.size(); ++ordinal) {
    REQUIRE(moments[ordinal].coordinates.size() == 1U);
    CHECK(moments[ordinal].coordinates.front().ordinal() == ordinal);
    CHECK(moments[ordinal].order == mwperf::BigNat(1U));
    CHECK(moments[ordinal].value ==
          (ordinal == 0U ? rational(1, 2) : rational(0, 1)));
  }

  SECTION("non-unit geometric grids retain only sequential access") {
    auto non_iid = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"geometric_grid","d_min":1,"delta":2,"p":0.5},
        "destination_pmf":[{"queue_id":"q0","probability":1}]
      }],"metadata":{}
    })json");
    auto non_iid_law = compile_full(non_iid);
    const auto non_iid_capabilities =
        mwperf::arrival_capabilities(non_iid_law);
    CHECK_FALSE(
        non_iid_capabilities.exact_factorized_iid_generator.has_value());
    CHECK_FALSE(non_iid_capabilities.exact_iid_joint_vector.has_value());
    CHECK_FALSE(non_iid_capabilities.exact_coordinate_moments.has_value());
    const auto non_iid_view = mwperf::builder_arrival_view(non_iid_law);
    CHECK_FALSE(non_iid_view.iid_joint_table().has_value());
    CHECK_FALSE(non_iid_view.moments().has_value());
  }
}

TEST_CASE("C27.9 compact factorized IID projection produces only the target PMF",
          "[c11][c19][c27_9][unit][renewal][projection]") {
  auto parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[
      {"id":"s0","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.5},
       "destination_pmf":[{"queue_id":"q0","probability":0.5},{"queue_id":"q1","probability":0.5}]},
      {"id":"s1","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.25},
       "destination_pmf":[{"queue_id":"q0","probability":1}]}
    ],"metadata":{}
  })json");
  auto law = compile_full(parsed);
  auto q0 = parsed.queues.index_at(0U);
  REQUIRE(q0);
  auto projected =
      mwperf::project_exact_factorized_iid_target_pmf(law, q0.value());
  REQUIRE(projected);
  REQUIRE(projected.value().size() == 3U);

  const std::array expected{
      rational(9, 16), rational(3, 8), rational(1, 16)};
  for (std::size_t count = 0U; count < expected.size(); ++count) {
    CHECK(projected.value()[count].count == mwperf::BigNat(count));
    CHECK(projected.value()[count].probability == expected[count]);
  }

  // For a small source set, the compact recurrence must equal projection of
  // the retained legacy Cartesian table atom for atom.
  const auto view = mwperf::builder_arrival_view(law);
  REQUIRE(view.iid_joint_table().has_value());
  std::array legacy_projection{mwperf::ExactRational::zero(),
                               mwperf::ExactRational::zero(),
                               mwperf::ExactRational::zero()};
  for (const auto& joint : *view.iid_joint_table()) {
    REQUIRE(joint.dense_counts.size() == parsed.queues.size());
    const std::size_t count =
        joint.dense_counts[q0.value().ordinal()]
            .value()
            .convert_to<std::size_t>();
    REQUIRE(count < legacy_projection.size());
    legacy_projection[count] =
        legacy_projection[count] + joint.probability;
  }
  for (std::size_t count = 0U; count < expected.size(); ++count) {
    CHECK(projected.value()[count].probability == legacy_projection[count]);
  }

  auto q2 = parsed.queues.index_at(2U);
  REQUIRE(q2);
  auto zero_target =
      mwperf::project_exact_factorized_iid_target_pmf(law, q2.value());
  REQUIRE(zero_target);
  REQUIRE(zero_target.value().size() == 1U);
  CHECK(zero_target.value().front().count == mwperf::BigNat(0U));
  CHECK(zero_target.value().front().probability ==
        mwperf::ExactRational::one());

  auto certain = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[
      {"id":"certain","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":1},
       "destination_pmf":[{"queue_id":"q0","probability":1}]}
    ],"metadata":{}
  })json");
  auto certain_law = compile_full(certain);
  auto certain_q0 = certain.queues.index_at(0U);
  REQUIRE(certain_q0);
  auto certain_target = mwperf::project_exact_factorized_iid_target_pmf(
      certain_law, certain_q0.value());
  REQUIRE(certain_target);
  REQUIRE(certain_target.value().size() == 1U);
  CHECK(certain_target.value().front().count == mwperf::BigNat(1U));
  CHECK(certain_target.value().front().probability ==
        mwperf::ExactRational::one());
}

TEST_CASE("C27.8 exact factorized IID capability survives the legacy table cap",
          "[c11][c27_8][unit][renewal][capability]") {
  std::string sources;
  for (std::size_t source = 0U; source < 65U; ++source) {
    if (!sources.empty()) {
      sources += ',';
    }
    sources +=
        R"json({"id":"s)json" + std::to_string(source) +
        R"json(","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0.5},"destination_pmf":[{"queue_id":"q0","probability":1}]})json";
  }
  auto parsed = parse_arrival(
      R"json({"family":"independent_marked_renewal","sources":[)json" +
      sources + R"json(],"metadata":{}})json");
  auto law = compile_full(parsed);

  const auto capabilities = mwperf::arrival_capabilities(law);
  REQUIRE(capabilities.exact_factorized_iid_generator.has_value());
  CHECK(capabilities.exact_factorized_iid_generator->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  REQUIRE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_coordinate_moments->maximum_order ==
        std::optional<mwperf::BigNat>{mwperf::BigNat(1U)});

  const auto view = mwperf::builder_arrival_view(law);
  CHECK_FALSE(view.iid_joint_table().has_value());
  REQUIRE(view.moments().has_value());
  REQUIRE(view.moments()->size() == parsed.queues.size());
  CHECK(view.moments()->at(0U).value == rational(65, 2));
  CHECK(view.moments()->at(1U).value == rational(0, 1));
  CHECK(view.moments()->at(2U).value == rational(0, 1));

  auto q0 = parsed.queues.index_at(0U);
  REQUIRE(q0);
  auto target_pmf =
      mwperf::project_exact_factorized_iid_target_pmf(law, q0.value());
  REQUIRE(target_pmf);
  REQUIRE(target_pmf.value().size() == 66U);
  CHECK(target_pmf.value().front().count == mwperf::BigNat(0U));
  CHECK(target_pmf.value().back().count == mwperf::BigNat(65U));
  CHECK(target_pmf.value().front().probability ==
        target_pmf.value().back().probability);
  mwperf::ExactRational total = mwperf::ExactRational::zero();
  mwperf::ExactRational mean = mwperf::ExactRational::zero();
  for (const auto& atom : target_pmf.value()) {
    total = total + atom.probability;
    auto count = mwperf::ExactRational::make(atom.count.value(),
                                             mwperf::BigInt{1});
    REQUIRE(count);
    mean = mean + atom.probability * count.value();
  }
  CHECK(total == mwperf::ExactRational::one());
  CHECK(mean == rational(65, 2));
}

TEST_CASE("C11 renewal compilers reject malformed coordinates and clocks",
          "[c11][unit][renewal][negative]") {
  SECTION("duplicate finite gap") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"finite_pmf","outcomes":[
          {"d":2,"probability":0.5},{"d":2,"probability":0.5}]},
        "destination_pmf":[{"queue_id":"q0","probability":1}]
      }],"metadata":{}
    })json");
    auto result =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "renewal_duplicate_gap_coordinate");
    auto through_registry =
        mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE_FALSE(through_registry);
    CHECK(through_registry.error().code ==
          "renewal_duplicate_gap_coordinate");
  }

  SECTION("duplicate factorized destination") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"deterministic","d":1},
        "destination_pmf":[
          {"queue_id":"q0","probability":0.5},
          {"queue_id":"q0","probability":0.5}]
      }],"metadata":{}
    })json");
    auto result =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "renewal_duplicate_destination_coordinate");
  }

  SECTION("duplicate complete joint coordinate") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","joint_pmf":[
          {"d":1,"queue_id":"q0","probability":0.5},
          {"d":1,"queue_id":"q0","probability":0.5}]
      }],"metadata":{}
    })json");
    auto result =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "renewal_duplicate_joint_coordinate");
  }

  SECTION("nonpositive deterministic gap in typed input") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"deterministic","d":1},
        "destination_pmf":[{"queue_id":"q0","probability":1}]
      }],"metadata":{}
    })json");
    auto& renewal = std::get<mwperf::IndependentMarkedRenewalArrival>(
        parsed.model.arrival.value);
    auto& source = std::get<mwperf::FactorizedRenewalSource>(
        renewal.sources.value[0U]);
    std::get<mwperf::DeterministicInterarrival>(source.interarrival.value)
        .d.value = mwperf::BigNat(0U);
    auto result = mwperf::compile_marked_renewal(renewal, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "renewal_gap_nonpositive");
  }

  SECTION("invalid geometric parameters in typed input") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s",
        "interarrival":{"kind":"geometric_grid","d_min":1,"delta":2,
                        "p":1},
        "destination_pmf":[{"queue_id":"q0","probability":1}]
      }],"metadata":{}
    })json");
    auto renewal = authored(parsed);
    auto& source = std::get<mwperf::FactorizedRenewalSource>(
        renewal.sources.value[0U]);
    auto& geometric = std::get<mwperf::GeometricGridInterarrival>(
        source.interarrival.value);
    geometric.delta.value = mwperf::BigNat(0U);
    auto result = mwperf::compile_marked_renewal(renewal, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "renewal_geometric_grid_invalid");
  }

  SECTION("unknown queue") {
    auto parsed = parse_arrival(R"json({
      "family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"deterministic","d":1},
        "destination_pmf":[{"queue_id":"missing","probability":1}]
      }],"metadata":{}
    })json");
    auto result =
        mwperf::compile_marked_renewal(authored(parsed), parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "unknown_queue_reference");
    CHECK(result.error().json_pointer ==
          std::optional<std::string>{
              "/arrival/sources/0/destination_pmf/0/queue_id"});
  }
}

TEST_CASE("C11 renewal cursor rejects skipped and repeated slots transactionally",
          "[c11][unit][renewal][negative]") {
  auto parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[{
      "id":"s","interarrival":{"kind":"deterministic","d":2},
      "destination_pmf":[{"queue_id":"q0","probability":1}]
    }],"metadata":{}
  })json");
  auto process = instantiate(compile_full(parsed), 1105U);
  const auto origin = snapshot(process);

  auto skipped =
      mwperf::next_marked_renewal_batch(process, mwperf::BigNat(1U));
  REQUIRE_FALSE(skipped);
  CHECK(skipped.error().code == "nonsequential_arrival_access");
  check_same_snapshot(snapshot(process), origin);

  auto zero = mwperf::next_marked_renewal_batch(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  CHECK(zero.value().batch.empty_batch());
  const auto after_zero = snapshot(process);

  auto repeated =
      mwperf::next_marked_renewal_batch(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(repeated);
  CHECK(repeated.error().code == "nonsequential_arrival_access");
  check_same_snapshot(snapshot(process), after_zero);

  auto two = mwperf::next_arrival_step(process, mwperf::BigNat(2U));
  REQUIRE_FALSE(two);
  CHECK(two.error().code == "nonsequential_arrival_access");
  check_same_snapshot(snapshot(process), after_zero);

  auto one = mwperf::next_arrival_step(process, mwperf::BigNat(1U));
  REQUIRE(one);
  REQUIRE(one.value().batch.entries().size() == 1U);
  CHECK(one.value().batch.entries()[0U].queue.ordinal() == 0U);
}
