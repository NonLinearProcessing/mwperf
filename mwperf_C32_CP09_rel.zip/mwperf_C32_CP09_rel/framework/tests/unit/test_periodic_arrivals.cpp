#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/periodic.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct ParsedPeriodic final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> serial{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c10-periodic";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("periodic-" + std::to_string(serial.fetch_add(1U)) +
                   ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output << text;
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] mwperf::Result<mwperf::AuthoredModelConfig>
parse_authored_arrival(const std::string_view arrival) {
  const std::string model_text =
      R"json({"switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2"],"max_search_states":null}},"arrival":)json" +
      std::string(arrival) + "}";
  auto document = mwperf::load_document(write_model(model_text));
  if (!document) {
    return mwperf::Result<mwperf::AuthoredModelConfig>::failure(
        document.error());
  }
  auto executable = mwperf::extract_executable_model(document.value());
  if (!executable) {
    return mwperf::Result<mwperf::AuthoredModelConfig>::failure(
        executable.error());
  }
  return mwperf::parse_model_config_v3(executable.value());
}

[[nodiscard]] ParsedPeriodic parse_arrival(const std::string_view arrival) {
  auto model = parse_authored_arrival(arrival);
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedPeriodic{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::Digest256 fixed_digest() {
  auto digest = mwperf::Digest256::from_hex(
      "303132333435363738393a3b3c3d3e3f"
      "404142434445464748494a4b4c4d4e4f");
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law,
    mwperf::ArrivalInitialState initial,
    const std::uint64_t instance = 0U) {
  auto key = mwperf::make_physical_reference_instance_key(
      fixed_digest(), mwperf::BigNat(instance));
  REQUIRE(key);
  auto rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed(1010U), mwperf::StageTag::configured_arrival,
      key.value());
  auto stream =
      mwperf::make_configured_arrival_stream_key(law, std::move(rng));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, initial, std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] std::uint64_t count_at(const mwperf::ArrivalBatch& batch,
                                     const std::size_t ordinal) {
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    if (entry.queue.ordinal() == ordinal) {
      return entry.count.value().convert_to<std::uint64_t>();
    }
  }
  return 0U;
}

[[nodiscard]] mwperf::CompiledArrivalLaw compile(
    const ParsedPeriodic& parsed) {
  auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  return std::move(law).value();
}

}  // namespace

TEST_CASE("C10 global phase rotates sparse residues and preserves sources",
          "[c10][unit]") {
  auto parsed = parse_arrival(R"json({
    "family":"periodic_global_phase","period":4,"phase":1,
    "sources":[
      {"id":"first","entries":[
        {"offset":0,"queue_id":"q0","count":2},
        {"offset":3,"queue_id":"q1","count":4},
        {"offset":0,"queue_id":"q0","count":3}]},
      {"id":"second","entries":[
        {"offset":0,"queue_id":"q0","count":5}]}
    ],"metadata":{}
  })json");
  const auto& authored = std::get<mwperf::PeriodicGlobalPhaseArrival>(
      parsed.model.arrival.value);
  auto geometry =
      mwperf::compile_global_phase_periodic(authored, parsed.queues);
  REQUIRE(geometry);
  CHECK(geometry.value().period().to_decimal_string() == "4");
  CHECK(geometry.value().configured_phase().to_decimal_string() == "1");
  REQUIRE(geometry.value().sources().size() == 2U);
  CHECK(geometry.value().sources()[0U].source_id == "first");
  CHECK(geometry.value().sources()[1U].source_id == "second");
  CHECK(geometry.value().aggregate_entry_count() == 3U);
  REQUIRE(geometry.value().sources()[0U].shifted_residues.size() == 2U);
  CHECK(geometry.value().sources()[0U].shifted_residues[0U]
            .residue.to_decimal_string() == "0");
  CHECK(geometry.value().sources()[0U].shifted_residues[1U]
            .residue.to_decimal_string() == "1");
  CHECK(geometry.value().sources()[0U].shifted_residues[1U]
            .counts[0U]
            .count.to_decimal_string() == "5");

  auto law = compile(parsed);
  auto process = instantiate(law, mwperf::GlobalPeriodicOrigin{});
  auto slot0 = mwperf::next_periodic_batch(process, mwperf::BigNat(0U));
  REQUIRE(slot0);
  const auto initial_phase_span =
      mwperf::arrival_phase_canonical_state(slot0.value().phase_before);
  const std::vector<std::byte> initial_phase(initial_phase_span.begin(),
                                              initial_phase_span.end());
  CHECK(slot0.value().physical_arrival_epoch().to_decimal_string() == "1");
  CHECK(count_at(slot0.value().batch, 0U) == 0U);
  CHECK(count_at(slot0.value().batch, 1U) == 4U);
  auto slot1 = mwperf::next_periodic_batch(process, mwperf::BigNat(1U));
  REQUIRE(slot1);
  CHECK(count_at(slot1.value().batch, 0U) == 10U);
  CHECK(count_at(slot1.value().batch, 1U) == 0U);
  auto slot2 = mwperf::next_periodic_batch(process, mwperf::BigNat(2U));
  REQUIRE(slot2);
  auto slot3 = mwperf::next_periodic_batch(process, mwperf::BigNat(3U));
  REQUIRE(slot3);
  const auto repeated_phase_span =
      mwperf::arrival_phase_canonical_state(slot3.value().phase_after);
  CHECK(std::vector<std::byte>(repeated_phase_span.begin(),
                               repeated_phase_span.end()) == initial_phase);
}

TEST_CASE("C10 source delays are one-sided before exact modulo evaluation",
          "[c10][unit]") {
  auto parsed = parse_arrival(R"json({
    "family":"periodic_source_delays","period":4,
    "sources":[
      {"id":"late","delay":5,"entries":[
        {"offset":0,"queue_id":"q0","count":2}]},
      {"id":"origin","delay":0,"entries":[
        {"offset":0,"queue_id":"q1","count":3}]}
    ],"metadata":{}
  })json");
  const auto& authored = std::get<mwperf::PeriodicSourceDelaysArrival>(
      parsed.model.arrival.value);
  auto geometry =
      mwperf::compile_source_delay_periodic(authored, parsed.queues);
  REQUIRE(geometry);
  REQUIRE(geometry.value().sources().size() == 2U);
  CHECK(geometry.value().sources()[0U].delay.to_decimal_string() == "5");
  CHECK(geometry.value().aggregate_entry_count() == 2U);

  auto law = compile(parsed);
  auto process = instantiate(law, mwperf::SourceDelayOrigin{});
  for (std::uint64_t slot = 0U; slot <= 5U; ++slot) {
    auto step = mwperf::next_periodic_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    if (slot == 0U || slot == 4U) {
      CHECK(count_at(step.value().batch, 1U) == 3U);
    } else {
      CHECK(count_at(step.value().batch, 1U) == 0U);
    }
    // Slot 1 is the dangerous pre-delay modulo match: 1 == 5 (mod 4).
    CHECK(count_at(step.value().batch, 0U) == (slot == 5U ? 2U : 0U));
  }
}

TEST_CASE("C10 periodic runtime aggregates cross-source collisions atomically",
          "[c10][unit][negative]") {
  const auto maximum = std::numeric_limits<std::int64_t>::max();
  auto parsed = parse_arrival(
      std::string(R"json({"family":"periodic_global_phase","period":1,"phase":0,"sources":[{"id":"a","entries":[{"offset":0,"queue_id":"q0","count":)json") +
      std::to_string(maximum) +
      R"json(}]},{"id":"b","entries":[{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json");
  auto law = compile(parsed);
  auto process = instantiate(law, mwperf::GlobalPeriodicOrigin{});
  auto before = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(before);
  auto failed = mwperf::next_periodic_batch(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(failed);
  CHECK(failed.error().code == "arrival_count_overflow");
  auto after = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(after);
  CHECK(after.value().expected_slot == before.value().expected_slot);
  CHECK(after.value().phase_digest == before.value().phase_digest);
  CHECK(after.value().rng.consumed_words() ==
        before.value().rng.consumed_words());
  auto repeated = mwperf::next_periodic_batch(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(repeated);
  CHECK(repeated.error().code == "arrival_count_overflow");
}

TEST_CASE("C10 within-source duplicate overflow fails during compilation",
          "[c10][unit][negative]") {
  const auto maximum = std::numeric_limits<std::int64_t>::max();
  auto parsed = parse_arrival(
      std::string(R"json({"family":"periodic_source_delays","period":1,"sources":[{"id":"a","delay":0,"entries":[{"offset":0,"queue_id":"q0","count":)json") +
      std::to_string(maximum) +
      R"json(},{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json");
  const auto& authored = std::get<mwperf::PeriodicSourceDelaysArrival>(
      parsed.model.arrival.value);
  auto result = mwperf::compile_source_delay_periodic(authored, parsed.queues);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "arrival_count_overflow");
}

TEST_CASE("C10 periodic capabilities are conservative and empty laws stay empty",
          "[c10][unit]") {
  const std::string_view arrivals[] = {
      R"json({"family":"periodic_global_phase","period":7,"phase":6,"sources":[],"metadata":{}})json",
      R"json({"family":"periodic_source_delays","period":7,"sources":[{"id":"empty","delay":999,"entries":[]}],"metadata":{}})json"};
  for (const std::string_view arrival : arrivals) {
    auto parsed = parse_arrival(arrival);
    auto law = compile(parsed);
    const auto capabilities = mwperf::arrival_capabilities(law);
    CHECK(capabilities.exact_positive_support ==
          mwperf::CapabilityAvailability::available);
    CHECK(capabilities.sequential_normalized_sampler ==
          mwperf::CapabilityAvailability::available);
    CHECK(capabilities.finite_enumerated_predictive_phase ==
          mwperf::CapabilityAvailability::unavailable);
    CHECK(capabilities.finite_enumerated_transition_row ==
          mwperf::CapabilityAvailability::unavailable);
    CHECK(capabilities.stationary_phase_law ==
          mwperf::StationaryPhaseLawStatus::unavailable);
    CHECK_FALSE(capabilities.analytic_transform.has_value());
    CHECK_FALSE(capabilities.analytic_moments.has_value());
    CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
    const auto support = mwperf::positive_arrival_support(law);
    CHECK(support.bytes() == std::vector<std::uint8_t>({0U, 0U, 0U}));

    mwperf::ArrivalInitialState initial =
        law.family() == mwperf::ArrivalFamily::periodic_global_phase
            ? mwperf::ArrivalInitialState(mwperf::GlobalPeriodicOrigin{})
            : mwperf::ArrivalInitialState(mwperf::SourceDelayOrigin{});
    auto process = instantiate(law, std::move(initial));
    for (std::uint64_t slot = 0U; slot < 3U; ++slot) {
      auto step = mwperf::next_periodic_batch(process, mwperf::BigNat(slot));
      REQUIRE(step);
      CHECK(step.value().batch.empty_batch());
    }
  }
}

TEST_CASE("C10 exact sparse storage is independent of enormous time values",
          "[c10][unit]") {
  const std::string huge = "1" + std::string(500U, '0');
  auto global = parse_arrival(
      std::string(R"json({"family":"periodic_global_phase","period":)json") +
      huge +
      R"json(,"phase":0,"sources":[{"id":"one","entries":[{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json");
  auto global_geometry = mwperf::compile_global_phase_periodic(
      std::get<mwperf::PeriodicGlobalPhaseArrival>(global.model.arrival.value),
      global.queues);
  REQUIRE(global_geometry);
  CHECK(global_geometry.value().aggregate_entry_count() == 1U);
  CHECK(global_geometry.value().sources().size() == 1U);
  CHECK(global_geometry.value().period().bit_length() > 1600U);

  auto delayed = parse_arrival(
      std::string(R"json({"family":"periodic_source_delays","period":)json") +
      huge +
      R"json(,"sources":[{"id":"one","delay":)json" + huge +
      R"json(,"entries":[{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json");
  auto delayed_geometry = mwperf::compile_source_delay_periodic(
      std::get<mwperf::PeriodicSourceDelaysArrival>(
          delayed.model.arrival.value),
      delayed.queues);
  REQUIRE(delayed_geometry);
  CHECK(delayed_geometry.value().aggregate_entry_count() == 1U);
  CHECK(delayed_geometry.value().sources().size() == 1U);
  CHECK(delayed_geometry.value().sources()[0U].delay.bit_length() > 1600U);
}

TEST_CASE("C10 periodic compilers defensively reject malformed typed input",
          "[c10][unit][negative]") {
  auto parsed = parse_arrival(R"json({
    "family":"periodic_global_phase","period":4,"phase":1,
    "sources":[{"id":"a","entries":[
      {"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}
  })json");
  auto authored = std::get<mwperf::PeriodicGlobalPhaseArrival>(
      parsed.model.arrival.value);

  SECTION("zero period") {
    authored.period.value = mwperf::BigNat(0U);
    auto result =
        mwperf::compile_global_phase_periodic(authored, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "periodic_period_zero");
  }
  SECTION("phase outside period") {
    authored.phase.value = authored.period.value;
    auto result =
        mwperf::compile_global_phase_periodic(authored, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "periodic_phase_out_of_range");
  }
  SECTION("offset outside period") {
    authored.sources.value[0U].entries.value[0U].offset.value =
        authored.period.value;
    auto result =
        mwperf::compile_global_phase_periodic(authored, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "periodic_offset_out_of_range");
  }
  SECTION("zero count") {
    authored.sources.value[0U].entries.value[0U].count.value =
        mwperf::BigNat(0U);
    auto result =
        mwperf::compile_global_phase_periodic(authored, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "periodic_entry_count_zero");
  }
  SECTION("duplicate normalized source") {
    authored.sources.value.push_back(authored.sources.value[0U]);
    auto result =
        mwperf::compile_global_phase_periodic(authored, parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "periodic_duplicate_source_id");
  }
}

TEST_CASE("C10 parser rejects negative trace slots and source delays",
          "[c10][unit][negative]") {
  struct Fixture final {
    std::string_view arrival;
    std::string_view pointer;
  };
  constexpr Fixture fixtures[] = {
      {R"json({"family":"deterministic_trace","events":[{"slot":-1,"queue_id":"q0","count":1}],"metadata":{}})json",
       "/arrival/events/0/slot"},
      {R"json({"family":"periodic_source_delays","period":4,"sources":[{"id":"a","delay":-1,"entries":[]}],"metadata":{}})json",
       "/arrival/sources/0/delay"},
  };
  for (const Fixture& fixture : fixtures) {
    auto result = parse_authored_arrival(fixture.arrival);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "integer_negative");
    CHECK(result.error().json_pointer == fixture.pointer);
  }
}

TEST_CASE("C10 periodic compilation rejects an unknown typed queue",
          "[c10][unit][negative]") {
  auto parsed = parse_arrival(R"json({
    "family":"periodic_global_phase","period":2,"phase":0,
    "sources":[{"id":"a","entries":[
      {"offset":0,"queue_id":"missing","count":1}]}],"metadata":{}
  })json");
  const auto& authored = std::get<mwperf::PeriodicGlobalPhaseArrival>(
      parsed.model.arrival.value);
  auto result =
      mwperf::compile_global_phase_periodic(authored, parsed.queues);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "unknown_queue_reference");
  CHECK(result.error().json_pointer ==
        std::optional<std::string>{
            "/arrival/sources/0/entries/0/queue_id"});
}

TEST_CASE("C10 periodic cursor guard and initial state are family typed",
          "[c10][unit][negative]") {
  auto parsed = parse_arrival(
      R"json({"family":"periodic_global_phase","period":2,"phase":0,"sources":[],"metadata":{}})json");
  auto law = compile(parsed);

  auto key = mwperf::make_physical_reference_instance_key(
      fixed_digest(), mwperf::BigNat(9U));
  REQUIRE(key);
  auto rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed(1010U), mwperf::StageTag::configured_arrival,
      key.value());
  auto stream =
      mwperf::make_configured_arrival_stream_key(law, std::move(rng));
  REQUIRE(stream);
  auto wrong = mwperf::instantiate_arrival_process(
      law, mwperf::SourceDelayOrigin{}, std::move(stream).value());
  REQUIRE_FALSE(wrong);
  CHECK(wrong.error().code == "arrival_initial_family_mismatch");

  auto process = instantiate(law, mwperf::GlobalPeriodicOrigin{}, 10U);
  auto skipped = mwperf::next_periodic_batch(process, mwperf::BigNat(1U));
  REQUIRE_FALSE(skipped);
  CHECK(skipped.error().code == "nonsequential_arrival_access");
  auto first = mwperf::next_periodic_batch(process, mwperf::BigNat(0U));
  REQUIRE(first);
  auto repeated = mwperf::next_periodic_batch(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(repeated);
  CHECK(repeated.error().code == "nonsequential_arrival_access");
}
