#include <algorithm>
#include <array>
#include <cstdint>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/types.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace {

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto result = mwperf::TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::AuthoredQueue authored_queue(
    mwperf::QueueId id, const std::size_t ordinal) {
  const std::string base = "/switch/queues/" + std::to_string(ordinal);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{std::move(id),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<
          std::optional<mwperf::LegacyVoqCoordinate>>{
          std::nullopt, provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::QueueCatalog make_catalog() {
  std::vector<mwperf::AuthoredQueue> queues;
  queues.push_back(authored_queue(
      mwperf::QueueId(
          mwperf::TypedLabel::numeric(mwperf::BigNat(std::uint64_t{1U}))),
      0U));
  queues.push_back(
      authored_queue(mwperf::QueueId(text_label("1")), 1U));
  queues.push_back(
      authored_queue(mwperf::QueueId(text_label("third")), 2U));

  mwperf::AuthoredSwitchConfig authored = mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          std::move(queues), provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
  auto result = mwperf::build_queue_catalog(authored);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& hex) {
  auto result = mwperf::Digest256::from_hex(hex);
  if (!result) {
    throw std::logic_error("invalid C09 digest fixture");
  }
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArrivalBinding binding_a(
    const std::size_t queue_cardinality) {
  return mwperf::ArrivalBinding{
      .family = mwperf::ArrivalFamily::deterministic_trace,
      .timing = mwperf::TimingConvention::early_service_late_admission,
      .queue_cardinality = queue_cardinality,
      .law_digest = mwperf::ArrivalLawDigest(digest(
          "000102030405060708090a0b0c0d0e0f"
          "101112131415161718191a1b1c1d1e1f")),
      .catalog_digest = mwperf::QueueCatalogDigest(digest(
          "202122232425262728292a2b2c2d2e2f"
          "303132333435363738393a3b3c3d3e3f")),
  };
}

[[nodiscard]] mwperf::ArrivalBinding binding_b(
    const std::size_t queue_cardinality) {
  mwperf::ArrivalBinding result = binding_a(queue_cardinality);
  result.law_digest = mwperf::ArrivalLawDigest(digest(
      "404142434445464748494a4b4c4d4e4f"
      "505152535455565758595a5b5c5d5e5f"));
  return result;
}

[[nodiscard]] mwperf::ArrivalBinding count_table_binding(
    const std::size_t queue_cardinality) {
  mwperf::ArrivalBinding result = binding_a(queue_cardinality);
  result.family = mwperf::ArrivalFamily::iid_count_table;
  return result;
}

[[nodiscard]] mwperf::ArrivalBinding binding_foreign_catalog(
    const std::size_t queue_cardinality) {
  mwperf::ArrivalBinding result = binding_a(queue_cardinality);
  result.catalog_digest = mwperf::QueueCatalogDigest(digest(
      "606162636465666768696a6b6c6d6e6f"
      "707172737475767778797a7b7c7d7e7f"));
  return result;
}

[[nodiscard]] mwperf::ArrivalAtom atom(
    const mwperf::QueueCatalog& catalog, const std::size_t ordinal,
    mwperf::BigNat count, mwperf::ArrivalBinding binding) {
  auto queue = catalog.index_at(ordinal);
  REQUIRE(queue);
  auto result = mwperf::ArrivalAtom::make(
      queue.value(), std::move(count), std::move(binding));
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C09 aggregates an empty input to the canonical empty batch",
          "[c09][unit][arrival]") {
  const std::vector<mwperf::ArrivalAtom> atoms;
  auto result = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE(result);
  CHECK(result.value().empty_batch());
  CHECK(result.value().entries().empty());
  CHECK_FALSE(result.value().binding().has_value());
  CHECK(result.value() == mwperf::ArrivalBatch::empty());
}

TEST_CASE("C09 preserves one checked atom as one canonical batch entry",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const mwperf::ArrivalBinding binding = binding_a(catalog.size());
  const std::array atoms{
      atom(catalog, 1U, mwperf::BigNat(17U), binding)};
  auto result = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE(result);
  REQUIRE(result.value().binding().has_value());
  CHECK(*result.value().binding() == binding);
  REQUIRE(result.value().entries().size() == 1U);
  CHECK(result.value().entries()[0U].queue.ordinal() == 1U);
  CHECK(result.value().entries()[0U].count == mwperf::BigNat(17U));
}

TEST_CASE("C09 aggregation is canonical under duplicates and permutations",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const mwperf::ArrivalBinding binding = binding_a(catalog.size());
  const std::vector<mwperf::ArrivalAtom> base{
      atom(catalog, 2U, mwperf::BigNat(4U), binding),
      atom(catalog, 0U, mwperf::BigNat(3U), binding),
      atom(catalog, 2U, mwperf::BigNat(5U), binding),
      atom(catalog, 1U, mwperf::BigNat(7U), binding),
  };

  auto reference = mwperf::aggregate_arrival_batch(base);
  REQUIRE(reference);
  REQUIRE(reference.value().binding().has_value());
  CHECK(*reference.value().binding() == binding);
  REQUIRE(reference.value().entries().size() == 3U);
  CHECK(reference.value().entries()[0].queue.ordinal() == 0U);
  CHECK(reference.value().entries()[0].count == mwperf::BigNat(3U));
  CHECK(reference.value().entries()[1].queue.ordinal() == 1U);
  CHECK(reference.value().entries()[1].count == mwperf::BigNat(7U));
  CHECK(reference.value().entries()[2].queue.ordinal() == 2U);
  CHECK(reference.value().entries()[2].count == mwperf::BigNat(9U));

  std::array<std::size_t, 4U> order{0U, 1U, 2U, 3U};
  do {
    std::vector<mwperf::ArrivalAtom> permuted;
    permuted.reserve(order.size());
    for (const std::size_t index : order) {
      permuted.push_back(base[index]);
    }
    auto result = mwperf::aggregate_arrival_batch(permuted);
    REQUIRE(result);
    CHECK(result.value() == reference.value());
  } while (std::next_permutation(order.begin(), order.end()));
}

TEST_CASE("C09 aggregation keeps numeric and textual queue IDs distinct",
          "[c09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto numeric = catalog.index_at(0U);
  auto textual = catalog.index_at(1U);
  REQUIRE(numeric);
  REQUIRE(textual);
  CHECK_FALSE(catalog.queue_id(numeric.value()) ==
              catalog.queue_id(textual.value()));

  const mwperf::ArrivalBinding binding = binding_a(catalog.size());
  const std::vector<mwperf::ArrivalAtom> atoms{
      atom(catalog, 1U, mwperf::BigNat(11U), binding),
      atom(catalog, 0U, mwperf::BigNat(13U), binding),
  };
  auto result = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE(result);
  REQUIRE(result.value().entries().size() == 2U);
  CHECK(result.value().entries()[0].queue == numeric.value());
  CHECK(result.value().entries()[0].count == mwperf::BigNat(13U));
  CHECK(result.value().entries()[1].queue == textual.value());
  CHECK(result.value().entries()[1].count == mwperf::BigNat(11U));
}

TEST_CASE("CP09 count-table aggregation accepts the u64 maximum exactly",
          "[c09][c32][cp09][unit][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const mwperf::ArrivalBinding binding = count_table_binding(catalog.size());
  const auto maximum = std::numeric_limits<std::uint64_t>::max();
  const std::vector<mwperf::ArrivalAtom> atoms{
      atom(catalog, 0U, mwperf::BigNat(maximum - 1U), binding),
      atom(catalog, 0U, mwperf::BigNat(1U), binding),
  };

  auto result = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE(result);
  REQUIRE(result.value().entries().size() == 1U);
  CHECK(result.value().entries()[0].count == mwperf::BigNat(maximum));
}

TEST_CASE("CP09 count-table aggregation rejects u64 overflow without a partial batch",
          "[c09][c32][cp09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const mwperf::ArrivalBinding binding = count_table_binding(catalog.size());
  const auto maximum = std::numeric_limits<std::uint64_t>::max();
  const std::vector<mwperf::ArrivalAtom> atoms{
      atom(catalog, 0U, mwperf::BigNat(maximum), binding),
      atom(catalog, 0U, mwperf::BigNat(1U), binding),
  };

  auto result = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE_FALSE(result);
  CHECK(result.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(result.error().code == "arrival_count_overflow");
}

TEST_CASE("C09 rejects zero counts and dense indices outside their binding",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const mwperf::ArrivalBinding binding = binding_a(catalog.size());
  auto first = catalog.index_at(0U);
  auto third = catalog.index_at(2U);
  REQUIRE(first);
  REQUIRE(third);

  auto zero = mwperf::ArrivalAtom::make(first.value(), mwperf::BigNat(0U),
                                        binding);
  REQUIRE_FALSE(zero);
  CHECK(zero.error().code == "arrival_atom_zero_count");

  auto outside = mwperf::ArrivalAtom::make(
      third.value(), mwperf::BigNat(1U), binding_a(2U));
  REQUIRE_FALSE(outside);
  CHECK(outside.error().code == "arrival_atom_queue_out_of_range");
}

TEST_CASE("C09 rejects mixed law and catalog bindings transactionally",
          "[c09][unit][negative][arrival]") {
  const mwperf::QueueCatalog catalog = make_catalog();

  const auto check_mismatch = [&catalog](mwperf::ArrivalBinding second) {
    const std::vector<mwperf::ArrivalAtom> atoms{
        atom(catalog, 0U, mwperf::BigNat(2U), binding_a(catalog.size())),
        atom(catalog, 1U, mwperf::BigNat(3U), std::move(second)),
    };
    auto result = mwperf::aggregate_arrival_batch(atoms);
    REQUIRE_FALSE(result);
    CHECK(result.error().category ==
          mwperf::DiagnosticCategory::input_validation);
    CHECK(result.error().code == "arrival_atom_binding_mismatch");
  };

  SECTION("law identity") { check_mismatch(binding_b(catalog.size())); }
  SECTION("catalog identity") {
    check_mismatch(binding_foreign_catalog(catalog.size()));
  }
}
