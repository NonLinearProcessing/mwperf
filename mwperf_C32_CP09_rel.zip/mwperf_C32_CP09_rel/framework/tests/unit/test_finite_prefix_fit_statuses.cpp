#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/stationary/finite_prefix_fit.hpp"
#include "support/c19_math_test_util.hpp"

namespace {

using namespace mwperf;
using namespace mwperf::testing::c19_math;

[[nodiscard]] Digest256 digest(const char digit) {
  auto value = Digest256::from_hex(std::string(64U, digit));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] std::vector<FinitePrefixFitArrivalAtomV1> fit_arrivals(
    const std::vector<ExactRational>& dense) {
  std::vector<FinitePrefixFitArrivalAtomV1> result;
  for (std::size_t count = 0U; count < dense.size(); ++count) {
    if (dense[count].is_positive()) {
      result.push_back({BigNat{static_cast<std::uint64_t>(count)},
                        dense[count]});
    }
  }
  return result;
}

[[nodiscard]] std::vector<ScalarArrivalMassV1> production_arrivals(
    const std::vector<ExactRational>& dense) {
  std::vector<ScalarArrivalMassV1> result;
  for (std::size_t count = 0U; count < dense.size(); ++count) {
    if (dense[count].is_positive()) {
      result.push_back({BigNat{static_cast<std::uint64_t>(count)},
                        dense[count]});
    }
  }
  return result;
}

[[nodiscard]] FinitePrefixFitInputV1 fit_input(
    const std::vector<ExactRational>& dense_arrival,
    std::vector<ExactRational> service_by_level,
    ExactRational tail_service_value,
    const bool second_moment_available = true,
    std::vector<FinitePrefixFitSelectionSeedAtomV1> selection_seed = {}) {
  return FinitePrefixFitInputV1{
      fit_arrivals(dense_arrival),
      second_moment_available,
      second_moment_available,
      std::move(selection_seed),
      std::move(service_by_level),
      std::move(tail_service_value),
      {digest('a'), digest('b')},
      {},
      std::nullopt,
      false};
}

[[nodiscard]] ScalarStationaryLaw production_law(
    const std::string& name,
    const std::vector<ExactRational>& dense_arrival,
    const std::vector<ExactRational>& service_by_level,
    const ExactRational& tail_service_value) {
  const std::size_t cutoff = service_by_level.size() - 1U;
  auto response = mint_scalar_response(scalar_carrier(
      lineage(name), production_arrivals(dense_arrival), service_by_level,
      BigNat{static_cast<std::uint64_t>(cutoff + 1U)},
      tail_service_value));
  INFO((response ? std::string{} : response.error().code));
  REQUIRE(response);
  auto arrival = ArrivalLaw::from_audited(response.value());
  INFO((arrival ? std::string{} : arrival.error().code));
  REQUIRE(arrival);
  auto law = solve_constant_tail_response(
      response.value(), arrival.value(),
      Cutoff{BigNat{static_cast<std::uint64_t>(cutoff)}},
      tail_service(tail_service_value));
  INFO((law ? std::string{} : law.error().code));
  REQUIRE(law);
  return std::move(law).value();
}

void check_parity(const FinitePrefixFitResultV1& fit,
                  const ScalarStationaryLaw& law,
                  const AnalyticStationaryStatusV1 expected_status) {
  REQUIRE(fit.fitted_prefix_probabilities);
  REQUIRE(fit.fitted_tail_mass);
  REQUIRE(fit.fitted_mean_backlog);
  CHECK(law.status() == expected_status);
  CHECK(law.normalized_law_established());
  REQUIRE(law.exact_tail_mass());
  REQUIRE(law.exact_mean_backlog());
  CHECK(*law.exact_tail_mass() == *fit.fitted_tail_mass);
  CHECK(*law.exact_mean_backlog() == *fit.fitted_mean_backlog);
  REQUIRE(law.diagnostics().terms_evaluated);
  CHECK(*law.diagnostics().terms_evaluated == fit.terms_evaluated);
  CHECK(law.diagnostics().tail_slack == fit.tail_slack);
  REQUIRE(fit.residuals.normalization);
  REQUIRE(fit.residuals.invariance);
  CHECK(law.diagnostics().normalization_residual ==
        *fit.residuals.normalization);
  CHECK(law.diagnostics().invariance_residual ==
        *fit.residuals.invariance);
  REQUIRE(fit.fitted_prefix_probabilities->size() ==
          fit.consumed_service_by_level.size());
  for (std::size_t level = 0U;
       level < fit.fitted_prefix_probabilities->size(); ++level) {
    auto mass = law.mass(BigNat{static_cast<std::uint64_t>(level)});
    REQUIRE(mass);
    CHECK(mass.value() == (*fit.fitted_prefix_probabilities)[level]);
  }
}

struct ParityFixture final {
  std::string name;
  std::vector<ExactRational> dense_arrival;
  std::vector<ExactRational> service_by_level;
  ExactRational tail_service;
};

[[nodiscard]] std::vector<ParityFixture> parity_fixtures() {
  return {
      {"c30-fit-parity-k2",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4)},
       rational(2, 3)},
      {"c30-fit-parity-k3",
       {rational(3, 4), rational(0), rational(1, 4)},
       {rational(0), rational(1, 2), rational(3, 4), rational(1)},
       rational(3, 4)},
      {"c30-fit-parity-k4",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4), rational(4, 5),
        rational(1, 2)},
       rational(2, 3)},
      {"c30-fit-parity-k5",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4), rational(4, 5),
        rational(1, 2), rational(5, 6)},
       rational(2, 3)},
  };
}

}  // namespace

TEST_CASE("C30 pure finite-prefix fit exposes every typed status",
          "[c30][math][unit][status]") {
  const std::vector<ExactRational> bernoulli{
      rational(3, 4), rational(1, 4)};

  SECTION("strict tail stable") {
    auto result = fit_finite_prefix_constant_tail(
        fit_input(bernoulli, {rational(0), rational(1, 2)},
                  rational(1, 2)));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::strict_tail_stable);
    CHECK(result.value().normalized_law_established());
    REQUIRE(result.value().fitted_mean_backlog);
    REQUIRE(result.value().fitted_second_backlog_moment);
  }

  SECTION("finite closed tail unreachable") {
    auto result = fit_finite_prefix_constant_tail(fit_input(
        {rational(1)}, {rational(0), rational(0)}, rational(0), true,
        {{BigNat{0U}, rational(1)}}));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
    CHECK(result.value().normalized_law_established());
    REQUIRE(result.value().fitted_second_backlog_moment);
    CHECK(result.value().fitted_second_backlog_moment->is_zero());
    CHECK(result.value().tail_slack_applicability ==
          FinitePrefixFitSlackApplicabilityV1::not_applicable_off_class);
  }

  SECTION("outside strict tail profile") {
    auto result = fit_finite_prefix_constant_tail(
        fit_input(bernoulli, {rational(0), rational(1, 2)},
                  rational(1, 4)));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::outside_strict_tail_profile);
    CHECK_FALSE(result.value().normalized_law_established());
    REQUIRE(result.value().tail_slack);
    CHECK(result.value().tail_slack->is_zero());
  }

  SECTION("degenerate selected closed class") {
    auto result = fit_finite_prefix_constant_tail(
        fit_input({rational(1)}, {rational(0), rational(0)},
                  rational(1, 2)));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::degenerate_or_selected_closed_class);
    CHECK_FALSE(result.value().normalized_law_established());
  }

  SECTION("required moment unavailable") {
    auto result = fit_finite_prefix_constant_tail(
        fit_input(bernoulli, {rational(0), rational(1, 2)},
                  rational(1, 2), false));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::required_moment_unavailable);
    CHECK(result.value().normalized_law_established());
    CHECK_FALSE(result.value().arrival_second_moment.has_value());
    CHECK_FALSE(result.value().arrival_third_moment.has_value());
    CHECK_FALSE(result.value().fitted_mean_backlog.has_value());
    CHECK_FALSE(result.value().fitted_second_backlog_moment.has_value());
  }

  SECTION("unsupported assumptions") {
    auto result = fit_finite_prefix_constant_tail(
        fit_input(bernoulli, {rational(0), rational(0)}, rational(1, 2)));
    REQUIRE(result);
    CHECK(result.value().status ==
          FinitePrefixFitStatusV1::unsupported_assumptions);
    CHECK_FALSE(result.value().normalized_law_established());
  }
}

TEST_CASE("C30 pure fit matches the production C19 wrapper for K two through five",
          "[c30][math][unit][parity]") {
  for (const ParityFixture& fixture : parity_fixtures()) {
    CAPTURE(fixture.name);
    auto fit = fit_finite_prefix_constant_tail(fit_input(
        fixture.dense_arrival, fixture.service_by_level,
        fixture.tail_service, true, {{BigNat{0U}, rational(1)}}));
    REQUIRE(fit);
    CHECK(fit.value().status == FinitePrefixFitStatusV1::strict_tail_stable);
    const ScalarStationaryLaw law = production_law(
        fixture.name, fixture.dense_arrival, fixture.service_by_level,
        fixture.tail_service);
    check_parity(fit.value(), law,
                 AnalyticStationaryStatusV1::strict_tail_stable);
  }
}

TEST_CASE("C30 pure fit matches C19 finite closure before slack rejection",
          "[c30][math][unit][parity][finite-closure]") {
  const std::vector<ExactRational> arrival{rational(1)};
  const std::vector<ExactRational> service{
      rational(0), rational(0), rational(0)};
  auto fit = fit_finite_prefix_constant_tail(fit_input(
      arrival, service, rational(0), true,
      {{BigNat{0U}, rational(1)}}));
  REQUIRE(fit);
  CHECK(fit.value().status ==
        FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
  const ScalarStationaryLaw law =
      production_law("c30-fit-parity-finite-closure", arrival, service,
                     rational(0));
  check_parity(fit.value(), law,
               AnalyticStationaryStatusV1::finite_closed_tail_unreachable);
  REQUIRE(law.finite_closure_proof());
  REQUIRE(law.finite_closure_proof()->reachable_support().size() ==
          fit.value().finite_reachable_support.size());
  for (std::size_t index = 0U;
       index < fit.value().finite_reachable_support.size(); ++index) {
    CHECK(law.finite_closure_proof()->reachable_support()[index] ==
          fit.value().finite_reachable_support[index]);
  }
}
