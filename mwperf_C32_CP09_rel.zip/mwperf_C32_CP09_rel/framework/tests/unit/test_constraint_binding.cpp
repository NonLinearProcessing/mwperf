#include <atomic>
#include <filesystem>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <variant>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace mwperf {
namespace {

class ConstraintFixtureFile final {
 public:
  explicit ConstraintFixtureFile(const std::string_view contents) {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c04-constraint";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (error) {
      throw std::runtime_error("failed to create C04 constraint fixture path");
    }
    path_ = directory /
            ("constraint-" + std::to_string(next_id.fetch_add(1U)) + ".json");
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to open C04 constraint fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output.good()) {
      throw std::runtime_error("failed to write C04 constraint fixture");
    }
  }

  ConstraintFixtureFile(const ConstraintFixtureFile&) = delete;
  ConstraintFixtureFile& operator=(const ConstraintFixtureFile&) = delete;

  ~ConstraintFixtureFile() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

struct CompiledConstraint final {
  AuthoredModelConfig model;
  QueueCatalog catalog;
  ConstraintDescriptor descriptor;
};

[[nodiscard]] Result<CompiledConstraintProduct> fixture_product(
    const ServiceFamily family) {
  std::shared_ptr<const void> owner =
      std::make_shared<const std::string>(std::string(to_string(family)));
  return CompiledConstraintProduct::for_fixture(family, std::move(owner));
}

[[nodiscard]] detail::ConstraintCompilerServices fixture_compilers() {
  return detail::ConstraintCompilerServices{
      .crossbar = [](const ResolvedCrossbarConstraint&) {
        return fixture_product(ServiceFamily::crossbar_matching);
      },
      .intervals = [](const ResolvedIntervalConstraint&) {
        return fixture_product(ServiceFamily::nonoverlapping_intervals);
      },
      .node_exclusive = [](const ResolvedNodeExclusiveConstraint&) {
        return fixture_product(ServiceFamily::node_exclusive_matching);
      },
      .conflicts = [](const ResolvedConflictConstraint&) {
        return fixture_product(ServiceFamily::pairwise_conflicts);
      },
      .packing = [](const ResolvedPackingConstraint&) {
        return fixture_product(ServiceFamily::resource_packing);
      },
  };
}

[[nodiscard]] std::string physical_model(const std::string_view queues,
                                         const std::string_view scheduler) {
  return std::string{"{"} +
         R"("switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         std::string{queues} + R"(},"scheduler":)" + std::string{scheduler} +
         R"(,"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] Result<CompiledConstraint> compile_text(
    const std::string& text) {
  ConstraintFixtureFile file(text);
  auto document = load_document(file.path());
  if (!document) {
    return Result<CompiledConstraint>::failure(std::move(document.error()));
  }
  auto model_node = extract_executable_model(document.value());
  if (!model_node) {
    return Result<CompiledConstraint>::failure(std::move(model_node.error()));
  }
  auto model = parse_model_config_v3(model_node.value());
  if (!model) {
    return Result<CompiledConstraint>::failure(std::move(model.error()));
  }
  auto catalog = build_queue_catalog(model.value().switch_config);
  if (!catalog) {
    return Result<CompiledConstraint>::failure(std::move(catalog.error()));
  }
  const detail::ConstraintCompilerServices children = fixture_compilers();
  auto descriptor = detail::compile_constraint_descriptor_with_child_services(
      model.value().scheduler, catalog.value(), children);
  if (!descriptor) {
    return Result<CompiledConstraint>::failure(std::move(descriptor.error()));
  }
  return Result<CompiledConstraint>::success(
      CompiledConstraint{std::move(model).value(), std::move(catalog).value(),
                         std::move(descriptor).value()});
}

[[nodiscard]] Result<ConstraintDescriptor> compile_failure_fixture(
    const std::string& text) {
  ConstraintFixtureFile file(text);
  auto document = load_document(file.path());
  if (!document) {
    return Result<ConstraintDescriptor>::failure(std::move(document.error()));
  }
  auto model_node = extract_executable_model(document.value());
  if (!model_node) {
    return Result<ConstraintDescriptor>::failure(std::move(model_node.error()));
  }
  auto model = parse_model_config_v3(model_node.value());
  if (!model) {
    return Result<ConstraintDescriptor>::failure(std::move(model.error()));
  }
  auto catalog = build_queue_catalog(model.value().switch_config);
  if (!catalog) {
    return Result<ConstraintDescriptor>::failure(std::move(catalog.error()));
  }
  const detail::ConstraintCompilerServices children = fixture_compilers();
  return detail::compile_constraint_descriptor_with_child_services(
      model.value().scheduler, catalog.value(), children);
}

}  // namespace

TEST_CASE("C04 binds a crossbar with separate port namespaces and unmatched ports",
          "[c04][unit][constraint]") {
  auto compiled = compile_text(physical_model(
      R"([{"id":"q0"},{"id":"q1"}])",
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["shared","i1","unused-in"],"outputs":["shared","o1","unused-out"],"edges":[{"queue_id":"q1","input":"i1","output":"o1"},{"queue_id":"q0","input":"shared","output":"shared"}]},"priority":null}})"));
  INFO((compiled ? std::string{} : compiled.error().code));
  REQUIRE(compiled);
  const auto& crossbar = std::get<ResolvedCrossbarConstraint>(
      compiled.value().descriptor.value());
  REQUIRE(crossbar.inputs.size() == 3U);
  REQUIRE(crossbar.outputs.size() == 3U);
  REQUIRE(crossbar.edges.size() == 2U);
  CHECK(crossbar.edges[0].queue.ordinal() == 1U);
  CHECK(crossbar.edges[1].queue.ordinal() == 0U);
  CHECK(crossbar.edges[1].input.ordinal() == 0U);
  CHECK(crossbar.edges[1].output.ordinal() == 0U);
  CHECK(compiled.value().descriptor.downward_closed());
  CHECK(compiled.value().descriptor.compiled_product().has_owner());
  CHECK(compiled.value().descriptor.compiled_product().family() ==
        ServiceFamily::crossbar_matching);
  CHECK(compiled.value().descriptor.summary() ==
        "crossbar_matching queues=2 inputs=3 outputs=3");

  const DerivedServiceIdentity identity =
      compiled.value().descriptor.identity();
  CHECK(to_string(identity.scheduler) == "crossbar_max_weight");
  CHECK(to_string(identity.family) == "crossbar_matching");
  CHECK(to_string(identity.optimizer) == "hungarian_exact");
  CHECK(compute_individual_serviceability(compiled.value().descriptor).all());
  auto public_compile = compile_constraint_descriptor(
      compiled.value().model.scheduler, compiled.value().catalog);
  REQUIRE(public_compile);
  CHECK(public_compile.value().compiled_product().has_owner());
  CHECK(public_compile.value().compiled_product().family() ==
        ServiceFamily::crossbar_matching);
}

TEST_CASE("C04 retains exact half-open intervals in authored order",
          "[c04][unit][constraint]") {
  auto compiled = compile_text(physical_model(
      R"(["left","right"])",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"right","left":1,"right":2},{"queue_id":"left","left":0.1,"right":1}]},"priority":null}})"));
  REQUIRE(compiled);
  const auto& intervals = std::get<ResolvedIntervalConstraint>(
      compiled.value().descriptor.value());
  REQUIRE(intervals.intervals.size() == 2U);
  CHECK(intervals.intervals[0].queue.ordinal() == 1U);
  CHECK(intervals.intervals[1].queue.ordinal() == 0U);
  CHECK(intervals.intervals[1].right <= intervals.intervals[0].left);
  CHECK(to_string(compiled.value().descriptor.identity().optimizer) ==
        "weighted_interval_dp_exact");
  CHECK(compute_individual_serviceability(compiled.value().descriptor).all());
}

TEST_CASE("C04 retains node parallel links and isolated declared vertices",
          "[c04][unit][constraint]") {
  auto compiled = compile_text(physical_model(
      R"(["a","b"])",
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","isolated"],"links":[{"queue_id":"a","u":"u","v":"v"},{"queue_id":"b","u":"v","v":"u"}]},"priority":null}})"));
  REQUIRE(compiled);
  const auto& node = std::get<ResolvedNodeExclusiveConstraint>(
      compiled.value().descriptor.value());
  REQUIRE(node.vertices.size() == 3U);
  REQUIRE(node.links.size() == 2U);
  CHECK(node.links[0].u.ordinal() == node.links[1].v.ordinal());
  CHECK(node.links[0].v.ordinal() == node.links[1].u.ordinal());
  CHECK(to_string(compiled.value().descriptor.identity().optimizer) ==
        "edmonds_blossom_exact");
  auto public_compile = compile_constraint_descriptor(
      compiled.value().model.scheduler, compiled.value().catalog);
  REQUIRE(public_compile);
  CHECK(public_compile.value().compiled_product().has_owner());
  CHECK(public_compile.value().compiled_product().family() ==
        ServiceFamily::node_exclusive_matching);
}

TEST_CASE("C04 conflict descriptors retain every isolated queue",
          "[c04][unit][constraint]") {
  auto compiled = compile_text(physical_model(
      R"([1,"1","isolated"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["1",1]]},"priority":null,"max_search_states":null}})"));
  REQUIRE(compiled);
  const auto& conflict = std::get<ResolvedConflictConstraint>(
      compiled.value().descriptor.value());
  REQUIRE(conflict.conflicts.size() == 1U);
  REQUIRE(conflict.adjacency.size() == 3U);
  CHECK(conflict.conflicts[0].first.ordinal() == 0U);
  CHECK(conflict.conflicts[0].second.ordinal() == 1U);
  CHECK(conflict.adjacency[2].empty());
  CHECK(to_string(compiled.value().descriptor.identity().optimizer) ==
        "mwis_branch_memo_exact");
  auto public_compile = compile_constraint_descriptor(
      compiled.value().model.scheduler, compiled.value().catalog);
  REQUIRE(public_compile);
  CHECK(public_compile.value().compiled_product().has_owner());
  CHECK(public_compile.value().compiled_product().family() ==
        ServiceFamily::pairwise_conflicts);

  auto empty = compile_text(physical_model(
      R"(["q0"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":null,"max_search_states":null}})"));
  REQUIRE(empty);
  const auto& empty_conflict = std::get<ResolvedConflictConstraint>(
      empty.value().descriptor.value());
  CHECK(empty_conflict.conflicts.empty());
  REQUIRE(empty_conflict.adjacency.size() == 1U);
  CHECK(empty_conflict.adjacency[0].empty());
}

TEST_CASE("C04 packing serviceability is exact componentwise comparison",
          "[c04][unit][constraint]") {
  auto compiled = compile_text(physical_model(
      R"(["fits","exceeds"])",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["cpu","ram"],"capacity":[5,100000000000000000000],"demands":[{"queue_id":"exceeds","demand":[6,0]},{"queue_id":"fits","demand":[5,100000000000000000000]}]},"priority":null,"max_search_states":null}})"));
  REQUIRE(compiled);
  const auto& packing = std::get<ResolvedPackingConstraint>(
      compiled.value().descriptor.value());
  REQUIRE(packing.demands.size() == 2U);
  CHECK(packing.demands[0].queue.ordinal() == 1U);
  CHECK(packing.capacity[1].to_decimal_string() == "100000000000000000000");
  const ServiceableMask serviceable =
      compute_individual_serviceability(compiled.value().descriptor);
  REQUIRE(serviceable.size() == 2U);
  CHECK(serviceable.at(compiled.value().catalog.index_at(0U).value()));
  CHECK_FALSE(serviceable.at(compiled.value().catalog.index_at(1U).value()));
  CHECK_FALSE(serviceable.all());
  CHECK(to_string(compiled.value().descriptor.identity().optimizer) ==
        "binary_packing_memo_exact");
  auto public_compile = compile_constraint_descriptor(
      compiled.value().model.scheduler, compiled.value().catalog);
  REQUIRE(public_compile);
  CHECK(public_compile.value().compiled_product().has_owner());
  CHECK(public_compile.value().compiled_product().family() ==
        ServiceFamily::resource_packing);

  auto zero_dimensional = compile_text(physical_model(
      R"(["q0","q1"])",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]},{"queue_id":"q1","demand":[]}]},"priority":null,"max_search_states":null}})"));
  REQUIRE(zero_dimensional);
  CHECK(compute_individual_serviceability(
            zero_dimensional.value().descriptor)
            .all());

  auto wide = compile_text(physical_model(
      R"(["below","equal","above"])",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["wide"],"capacity":[340282366920938463463374607431768211456],"demands":[{"queue_id":"below","demand":[340282366920938463463374607431768211455]},{"queue_id":"equal","demand":[340282366920938463463374607431768211456]},{"queue_id":"above","demand":[340282366920938463463374607431768211457]}]},"priority":null,"max_search_states":null}})"));
  REQUIRE(wide);
  const ServiceableMask wide_mask =
      compute_individual_serviceability(wide.value().descriptor);
  CHECK(wide_mask.at(wide.value().catalog.index_at(0U).value()));
  CHECK(wide_mask.at(wide.value().catalog.index_at(1U).value()));
  CHECK_FALSE(wide_mask.at(wide.value().catalog.index_at(2U).value()));
}

TEST_CASE("C04 rejects invalid constraint coverage and references",
          "[c04][unit][negative][constraint]") {
  SECTION("C04 rechecks an invalid exact interval in a typed authored record") {
    auto valid = compile_text(physical_model(
        R"(["q0"])",
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1}]},"priority":null}})"));
    REQUIRE(valid);
    auto& scheduler = std::get<IntervalMaxWeightScheduler>(
        valid.value().model.scheduler.value);
    scheduler.constraint.value.intervals.value[0].right.value =
        scheduler.constraint.value.intervals.value[0].left.value;
    const detail::ConstraintCompilerServices children = fixture_compilers();
    auto result = detail::compile_constraint_descriptor_with_child_services(
        valid.value().model.scheduler, valid.value().catalog, children);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "invalid_interval");
  }
  SECTION("missing queue coverage") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0","q1"])",
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }
  SECTION("duplicate queue coverage") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0","q1"])",
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q0","left":1,"right":2}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_constraint_queue");
  }
  SECTION("undeclared crossbar endpoint") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"missing","output":"o"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "undeclared_crossbar_input");
  }
  SECTION("duplicate input declarations") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i","i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_crossbar_input");
  }
  SECTION("duplicate output declarations") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o","o"],"edges":[{"queue_id":"q0","input":"i","output":"o"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_crossbar_output");
  }
  SECTION("undeclared crossbar output") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"missing"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "undeclared_crossbar_output");
  }
  SECTION("duplicate crossbar endpoint pair") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0","q1"])",
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"},{"queue_id":"q1","input":"i","output":"o"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_crossbar_endpoint_pair");
  }
  SECTION("node self-loop") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u"],"links":[{"queue_id":"q0","u":"u","v":"u"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "node_link_self_loop");
  }
  SECTION("undeclared node endpoint") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v"],"links":[{"queue_id":"q0","u":"u","v":"missing"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "undeclared_link_vertex");
  }
  SECTION("duplicate node vertex") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","u"],"links":[{"queue_id":"q0","u":"u","v":"u"}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_node_vertex");
  }
  SECTION("self conflict") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q0"]]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "conflict_self_pair");
  }
  SECTION("reversed conflict duplicate") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0","q1"])",
        R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q0"]]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_conflict_pair");
  }
  SECTION("packing dimension") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[]}]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_demand_dimension");
  }
  SECTION("packing capacity dimension") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r0","r1"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[0,0]}]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "packing_capacity_dimension");
  }
  SECTION("duplicate packing resource") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r","r"],"capacity":[1,1],"demands":[{"queue_id":"q0","demand":[0,0]}]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_packing_resource");
  }
  SECTION("missing packing queue row") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0","q1"])",
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]}]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }
  SECTION("unknown packing queue row") {
    auto result = compile_failure_fixture(physical_model(
        R"(["q0"])",
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":[],"capacity":[],"demands":[{"queue_id":"unknown","demand":[]}]},"priority":null,"max_search_states":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "unknown_queue_reference");
  }
  SECTION("typed queue identity does not coerce") {
    auto result = compile_failure_fixture(physical_model(
        R"([1])",
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"1","left":0,"right":1}]},"priority":null}})"));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "unknown_queue_reference");
  }
}

TEST_CASE("C04 compiler uses C06 registrations and checks injected families",
          "[c04][unit][negative][constraint]") {
  auto valid = compile_text(physical_model(
      R"(["q0"])",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1}]},"priority":null}})"));
  REQUIRE(valid);

  auto unavailable = compile_constraint_descriptor(valid.value().model.scheduler,
                                                   valid.value().catalog);
  REQUIRE(unavailable);
  CHECK(unavailable.value().family() ==
        ServiceFamily::nonoverlapping_intervals);

  detail::ConstraintCompilerServices missing;
  auto no_fixture = detail::compile_constraint_descriptor_with_child_services(
      valid.value().model.scheduler, valid.value().catalog, missing);
  REQUIRE_FALSE(no_fixture);
  CHECK(no_fixture.error().code == "constraint_compiler_unavailable_c06");

  detail::ConstraintCompilerServices mismatched = fixture_compilers();
  mismatched.intervals = [](const ResolvedIntervalConstraint&) {
    return fixture_product(ServiceFamily::crossbar_matching);
  };
  auto wrong_family =
      detail::compile_constraint_descriptor_with_child_services(
          valid.value().model.scheduler, valid.value().catalog, mismatched);
  REQUIRE_FALSE(wrong_family);
  CHECK(wrong_family.error().category == DiagnosticCategory::internal);
  CHECK(wrong_family.error().code ==
        "compiled_constraint_product_mismatch");

  auto null_product = CompiledConstraintProduct::for_fixture(
      ServiceFamily::nonoverlapping_intervals, {});
  REQUIRE_FALSE(null_product);
  CHECK(null_product.error().code == "null_compiled_constraint_product");
}

}  // namespace mwperf
