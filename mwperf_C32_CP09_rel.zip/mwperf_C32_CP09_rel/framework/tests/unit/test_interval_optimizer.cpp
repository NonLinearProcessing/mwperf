#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct IntervalFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::IntervalProblem problem;
};

struct Query final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c06-interval-unit";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string interval_model(
    const std::string& queues, const std::string& constraint,
    const std::string& priority = "null") {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues +
         R"(},"scheduler":{"name":"interval_max_weight","params":{"constraint":)" +
         constraint + R"(,"priority":)" + priority +
         R"(}},"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] IntervalFixture make_fixture(
    const std::string& queues, const std::string& constraint,
    const std::string& priority_text = "null") {
  auto document = mwperf::load_document(
      write_model(interval_model(queues, constraint, priority_text)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  REQUIRE(descriptor.value().family() ==
          mwperf::ServiceFamily::nonoverlapping_intervals);
  const auto& resolved = std::get<mwperf::ResolvedIntervalConstraint>(
      descriptor.value().value());
  auto problem = mwperf::compile_interval_problem(resolved);
  INFO((problem ? std::string{} : problem.error().code));
  REQUIRE(problem);
  return IntervalFixture{std::move(catalog).value(),
                         std::move(priority).value(),
                         std::move(descriptor).value(),
                         std::move(problem).value()};
}

[[nodiscard]] mwperf::Result<mwperf::ConstraintDescriptor>
compile_attempt(const std::string& queues, const std::string& constraint) {
  auto document = mwperf::load_document(
      write_model(interval_model(queues, constraint)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  return mwperf::compile_constraint_descriptor(model.value().scheduler,
                                                catalog.value());
}

[[nodiscard]] mwperf::Result<mwperf::AuthoredModelConfig> parse_attempt(
    const std::string& queues, const std::string& constraint) {
  auto document = mwperf::load_document(
      write_model(interval_model(queues, constraint)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  return mwperf::parse_model_config_v3(node.value());
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 zero_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '0'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const IntervalFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      zero_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] Query make_query(
    const IntervalFixture& fixture, std::vector<mwperf::BigNat> primary_values,
    std::vector<std::uint8_t> eligibility_values) {
  const auto token = dimension(fixture);
  auto primary = mwperf::PrimaryWeights::from_values(
      token, std::move(primary_values));
  REQUIRE(primary);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, std::move(eligibility_values));
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  INFO((weights ? std::string{} : weights.error().code));
  REQUIRE(weights);
  return Query{std::move(primary).value(), std::move(eligibility).value(),
               std::move(weights).value()};
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::vector<std::size_t> ordered_queues(
    const mwperf::IntervalProblem& problem) {
  std::vector<std::size_t> queues;
  queues.reserve(problem.intervals().size());
  for (const auto& interval : problem.intervals()) {
    queues.push_back(interval.queue.ordinal());
  }
  return queues;
}

[[nodiscard]] mwperf::OptimizerExecutionContext context_for(
    const mwperf::QueueDimensionToken& token) {
  auto context = mwperf::OptimizerExecutionContext::for_fixture(
      unlimited_policy(), std::nullopt, token);
  REQUIRE(context);
  return std::move(context).value();
}

[[nodiscard]] std::string touching_constraint() {
  return R"({"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2}]})";
}

[[nodiscard]] std::string dp_choice_constraint() {
  return R"({"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":1,"right":2}]})";
}

}  // namespace

TEST_CASE("C06 interval predecessor compilation uses exact half-open geometry",
          "[c06][unit][interval]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2","q3","q4"])",
      R"({"intervals":[{"queue_id":"q3","left":1e-1,"right":2e-1},{"queue_id":"q1","left":-1,"right":0},{"queue_id":"q4","left":-5e-1,"right":2E-1},{"queue_id":"q0","left":-2,"right":-1},{"queue_id":"q2","left":-2,"right":1e-1}]})");

  // Exact right, then left, then dense-queue structural ordering. This set
  // simultaneously includes negative coordinates, nesting, equal right
  // endpoints, and exponent-authored decimals.
  CHECK((ordered_queues(fixture.problem) ==
         std::vector<std::size_t>{0U, 1U, 2U, 4U, 3U}));
  const auto predecessors = fixture.problem.predecessors();
  REQUIRE(predecessors.size() == 5U);
  CHECK_FALSE(predecessors[0U].has_value());
  REQUIRE(predecessors[1U].has_value());
  CHECK(*predecessors[1U] == 0U);
  CHECK_FALSE(predecessors[2U].has_value());
  REQUIRE(predecessors[3U].has_value());
  CHECK(*predecessors[3U] == 0U);
  REQUIRE(predecessors[4U].has_value());
  CHECK(*predecessors[4U] == 2U);

  CHECK(fixture.problem.intervals()[2U].right.to_canonical_string() ==
        "1/10");
  CHECK(fixture.problem.intervals()[3U].left.to_canonical_string() ==
        "-1/2");
  const auto independently_found = mwperf::find_interval_predecessors(
      fixture.problem.intervals());
  CHECK(std::vector<std::optional<std::size_t>>(predecessors.begin(),
                                                predecessors.end()) ==
        independently_found);
}

TEST_CASE("C06 interval solver selects intervals that touch at one endpoint",
          "[c06][unit][interval]") {
  const auto fixture =
      make_fixture(R"(["q0","q1"])", touching_constraint());
  const auto query =
      make_query(fixture, naturals({3U, 4U}), {1U, 1U});

  auto solved = mwperf::detail::solve_interval_exact(
      fixture.problem, query.eligibility, query.weights, nullptr);
  INFO((solved ? std::string{} : solved.error().code));
  REQUIRE(solved);
  CHECK((schedule_bits(solved.value().schedule) ==
         std::vector<std::uint8_t>{1U, 1U}));
  CHECK(solved.value().composite_objective.to_decimal_string() == "31");
}

TEST_CASE("C06 interval ineligibility disables a take branch not geometry",
          "[c06][unit][interval]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])",
      R"({"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3},{"queue_id":"q2","left":3,"right":4}]})");
  REQUIRE(fixture.problem.predecessors()[2U].has_value());
  CHECK(*fixture.problem.predecessors()[2U] == 1U);
  const auto before = std::vector<std::optional<std::size_t>>(
      fixture.problem.predecessors().begin(),
      fixture.problem.predecessors().end());
  const auto query = make_query(fixture, naturals({2U, 100U, 3U}),
                                {1U, 0U, 1U});

  auto solved = mwperf::detail::solve_interval_exact(
      fixture.problem, query.eligibility, query.weights, nullptr);
  REQUIRE(solved);
  CHECK((schedule_bits(solved.value().schedule) ==
         std::vector<std::uint8_t>{1U, 0U, 1U}));
  CHECK(solved.value().composite_objective.to_decimal_string() == "45");
  CHECK(std::vector<std::optional<std::size_t>>(
            fixture.problem.predecessors().begin(),
            fixture.problem.predecessors().end()) == before);
}

TEST_CASE("C06 interval DP reconstructs the unique supplied composite optimum",
          "[c06][unit][interval]") {
  const auto forward = make_fixture(R"(["q0","q1","q2"])",
                                    dp_choice_constraint(),
                                    R"(["q0","q1","q2"])");
  const auto reverse = make_fixture(R"(["q0","q1","q2"])",
                                    dp_choice_constraint(),
                                    R"(["q2","q1","q0"])");
  const auto forward_query =
      make_query(forward, naturals({2U, 1U, 1U}), {1U, 1U, 1U});
  const auto reverse_query =
      make_query(reverse, naturals({2U, 1U, 1U}), {1U, 1U, 1U});

  auto forward_solved = mwperf::detail::solve_interval_exact(
      forward.problem, forward_query.eligibility, forward_query.weights,
      nullptr);
  auto reverse_solved = mwperf::detail::solve_interval_exact(
      reverse.problem, reverse_query.eligibility, reverse_query.weights,
      nullptr);
  REQUIRE(forward_solved);
  REQUIRE(reverse_solved);
  CHECK((schedule_bits(forward_solved.value().schedule) ==
         std::vector<std::uint8_t>{1U, 0U, 0U}));
  CHECK(forward_solved.value().composite_objective.to_decimal_string() ==
        "20");
  CHECK((schedule_bits(reverse_solved.value().schedule) ==
         std::vector<std::uint8_t>{0U, 1U, 1U}));
  CHECK(reverse_solved.value().composite_objective.to_decimal_string() ==
        "22");
}

TEST_CASE("C06 interval reports malformed composite equality",
          "[c06][unit][negative][interval]") {
  const auto fixture =
      make_fixture(R"(["q0","q1"])", touching_constraint());
  const auto query =
      make_query(fixture, naturals({1U, 1U}), {1U, 1U});
  auto faulted = mwperf::detail::solve_interval_exact_with_fault(
      fixture.problem, query.eligibility, query.weights, nullptr,
      mwperf::detail::IntervalTestFault::force_equal_transition);
  REQUIRE_FALSE(faulted);
  CHECK(faulted.error().code == "interval_composite_equality_invariant");
  CHECK(faulted.error().category == mwperf::DiagnosticCategory::internal);

  auto invalid_fault = mwperf::detail::solve_interval_exact_with_fault(
      fixture.problem, query.eligibility, query.weights, nullptr,
      static_cast<mwperf::detail::IntervalTestFault>(255U));
  REQUIRE_FALSE(invalid_fault);
  CHECK(invalid_fault.error().code == "interval_test_fault_invalid");
}

TEST_CASE("C06 interval rejects invalid authored and rebound geometry",
          "[c06][negative][interval]") {
  SECTION("authored left equals right") {
    auto result = parse_attempt(
        R"(["q0"])",
        R"({"intervals":[{"queue_id":"q0","left":1,"right":1}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "model_invalid_interval");
  }

  SECTION("authored left exceeds right") {
    auto result = parse_attempt(
        R"(["q0"])",
        R"({"intervals":[{"queue_id":"q0","left":2,"right":1}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "model_invalid_interval");
  }

  SECTION("authored missing queue coverage") {
    auto result = compile_attempt(
        R"(["q0","q1"])",
        R"({"intervals":[{"queue_id":"q0","left":0,"right":1}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }

  SECTION("nonnumeric endpoint is rejected before C06") {
    auto result = parse_attempt(
        R"(["q0"])",
        R"({"intervals":[{"queue_id":"q0","left":"NaN","right":1}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().category ==
          mwperf::DiagnosticCategory::input_validation);
  }

  const auto fixture = make_fixture(
      R"(["q0","q1"])", touching_constraint());
  const auto& resolved = std::get<mwperf::ResolvedIntervalConstraint>(
      fixture.descriptor.value());

  SECTION("C06 rechecks exact bounds") {
    auto corrupt = resolved;
    corrupt.intervals[0U].right = corrupt.intervals[0U].left;
    auto result = mwperf::compile_interval_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "interval_compiled_bounds_invalid");
  }

  SECTION("C06 rechecks dense queue coverage") {
    auto corrupt = resolved;
    corrupt.intervals[1U].queue = corrupt.intervals[0U].queue;
    auto result = mwperf::compile_interval_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "interval_compiled_queue_coverage_invalid");
  }
}

TEST_CASE("C06 interval solve detects corrupt order predecessor and maps",
          "[c06][negative][interval]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])",
      R"({"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2},{"queue_id":"q2","left":2,"right":3}]})");
  const auto query = make_query(fixture, naturals({1U, 1U, 1U}),
                                {1U, 1U, 1U});

  SECTION("sorted order") {
    std::vector<mwperf::ExactInterval> intervals(
        fixture.problem.intervals().begin(),
        fixture.problem.intervals().end());
    std::swap(intervals[0U], intervals[1U]);
    std::vector<std::size_t> inverse(intervals.size());
    for (std::size_t ordered = 0U; ordered < intervals.size(); ++ordered) {
      inverse[intervals[ordered].queue.ordinal()] = ordered;
    }
    auto predecessors = mwperf::find_interval_predecessors(intervals);
    auto corrupt = mwperf::IntervalProblem::for_test(
        std::move(intervals), std::move(predecessors), std::move(inverse));
    auto result = mwperf::detail::solve_interval_exact(
        corrupt, query.eligibility, query.weights, nullptr);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "interval_problem_order_corrupt");
  }

  SECTION("predecessor must be earlier") {
    std::vector<mwperf::ExactInterval> intervals(
        fixture.problem.intervals().begin(),
        fixture.problem.intervals().end());
    std::vector<std::optional<std::size_t>> predecessors(
        fixture.problem.predecessors().begin(),
        fixture.problem.predecessors().end());
    std::vector<std::size_t> inverse(
        fixture.problem.queue_to_ordered().begin(),
        fixture.problem.queue_to_ordered().end());
    predecessors[1U] = 1U;
    auto corrupt = mwperf::IntervalProblem::for_test(
        std::move(intervals), std::move(predecessors), std::move(inverse));
    auto result = mwperf::detail::solve_interval_exact(
        corrupt, query.eligibility, query.weights, nullptr);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "interval_problem_predecessor_not_earlier");
  }

  SECTION("queue reconstruction map") {
    std::vector<mwperf::ExactInterval> intervals(
        fixture.problem.intervals().begin(),
        fixture.problem.intervals().end());
    std::vector<std::optional<std::size_t>> predecessors(
        fixture.problem.predecessors().begin(),
        fixture.problem.predecessors().end());
    std::vector<std::size_t> inverse(
        fixture.problem.queue_to_ordered().begin(),
        fixture.problem.queue_to_ordered().end());
    inverse[0U] = 1U;
    auto corrupt = mwperf::IntervalProblem::for_test(
        std::move(intervals), std::move(predecessors), std::move(inverse));
    auto result = mwperf::detail::solve_interval_exact(
        corrupt, query.eligibility, query.weights, nullptr);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "interval_problem_queue_map_corrupt");
  }
}

TEST_CASE("C06 interval rejects eligibility and weight shape mismatches",
          "[c06][negative][interval]") {
  const auto fixture =
      make_fixture(R"(["q0","q1"])", touching_constraint());
  auto malformed_mask = mwperf::EligibilityMask::from_bytes(
      dimension(fixture), {1U});
  REQUIRE_FALSE(malformed_mask);
  CHECK(malformed_mask.error().code == "eligibility_dimension_mismatch");

  const auto one_queue = make_fixture(
      R"(["q0"])",
      R"({"intervals":[{"queue_id":"q0","left":0,"right":1}]})");
  const auto foreign_query =
      make_query(one_queue, naturals({1U}), {1U});
  auto result = mwperf::detail::solve_interval_exact(
      fixture.problem, foreign_query.eligibility, foreign_query.weights,
      nullptr);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "interval_query_dimension_mismatch");
}

TEST_CASE("C06 interval forced target solves only non-target primary coordinates",
          "[c06][unit][interval][forced]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2","q3"])",
      R"({"intervals":[{"queue_id":"q0","left":1,"right":3},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":3,"right":4},{"queue_id":"q3","left":2,"right":5}]})");
  const auto query = make_query(fixture, naturals({100U, 2U, 3U, 10U}),
                                {0U, 1U, 1U, 1U});
  auto target = mwperf::TargetIndex::from_dimension(
      query.primary.dimension(), 0U);
  REQUIRE(target);
  auto context = context_for(query.primary.dimension());

  auto forced_zero = mwperf::solve_forced_target(
      context, fixture.descriptor, query.eligibility, query.primary,
      target.value(), mwperf::ForcedTargetBit::zero, fixture.priority);
  INFO((forced_zero ? std::string{} : forced_zero.error().code));
  REQUIRE(forced_zero);
  CHECK(forced_zero.value().value.to_decimal_string() == "12");
  CHECK((schedule_bits(forced_zero.value().witness) ==
         std::vector<std::uint8_t>{0U, 1U, 0U, 1U}));
  CHECK(forced_zero.value().accounting.completed_expansions().is_zero());

  auto forced_one = mwperf::solve_forced_target(
      context, fixture.descriptor, query.eligibility, query.primary,
      target.value(), mwperf::ForcedTargetBit::one, fixture.priority);
  INFO((forced_one ? std::string{} : forced_one.error().code));
  REQUIRE(forced_one);
  CHECK(forced_one.value().value.to_decimal_string() == "5");
  CHECK((schedule_bits(forced_one.value().witness) ==
         std::vector<std::uint8_t>{1U, 1U, 1U, 0U}));
  CHECK(forced_one.value().accounting.completed_expansions().is_zero());

  // q0 is ordinarily ineligible, yet the one-side commits it. Its own
  // primary magnitude cannot alter either reported residual value.
  const auto changed_target = make_query(
      fixture, naturals({999999U, 2U, 3U, 10U}), {0U, 1U, 1U, 1U});
  auto changed_zero = mwperf::solve_forced_target(
      context, fixture.descriptor, changed_target.eligibility,
      changed_target.primary, target.value(), mwperf::ForcedTargetBit::zero,
      fixture.priority);
  auto changed_one = mwperf::solve_forced_target(
      context, fixture.descriptor, changed_target.eligibility,
      changed_target.primary, target.value(), mwperf::ForcedTargetBit::one,
      fixture.priority);
  REQUIRE(changed_zero);
  REQUIRE(changed_one);
  CHECK(changed_zero.value().value == forced_zero.value().value);
  CHECK(changed_one.value().value == forced_one.value().value);
}
