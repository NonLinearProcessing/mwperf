#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/stationary/finite_prefix_fit.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const char digit) {
  auto value = mwperf::Digest256::from_hex(std::string(64U, digit));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::FinitePrefixFitInputV1 stable_bernoulli_input(
    const std::size_t cutoff) {
  std::vector<mwperf::ExactRational> service(
      cutoff + 1U, rational(1, 2));
  service.front() = rational(0);
  return mwperf::FinitePrefixFitInputV1{
      {{mwperf::BigNat{0U}, rational(3, 4)},
       {mwperf::BigNat{1U}, rational(1, 4)}},
      true,
      true,
      {},
      std::move(service),
      rational(1, 2),
      {digest('1'), digest('2')},
      {},
      std::nullopt,
      false};
}

template <typename T>
concept HasObservedMeanMember = requires(T value) { value.observed_mean; };

static_assert(!HasObservedMeanMember<mwperf::FinitePrefixFitInputV1>,
              "the diagnostic fit input must not accept the observed mean");

}  // namespace

TEST_CASE("C30 pure finite-prefix fit supports diagnostic K without a plug",
          "[c30][math][unit]") {
  for (const std::size_t cutoff : std::array<std::size_t, 3U>{4U, 8U, 12U}) {
    INFO("cutoff=" << cutoff);
    auto fitted = mwperf::fit_finite_prefix_constant_tail(
        stable_bernoulli_input(cutoff));
    REQUIRE(fitted);
    CHECK(fitted.value().status ==
          mwperf::FinitePrefixFitStatusV1::strict_tail_stable);
    REQUIRE(fitted.value().fitted_prefix_probabilities);
    REQUIRE(fitted.value().fitted_tail_mass);
    REQUIRE(fitted.value().fitted_mean_backlog);
    REQUIRE(fitted.value().fitted_second_backlog_moment);
    REQUIRE(fitted.value().arrival_third_moment);
    REQUIRE(fitted.value().tail_slack);
    CHECK(fitted.value().fitted_prefix_probabilities->size() == cutoff + 1U);
    CHECK(*fitted.value().fitted_mean_backlog == rational(3, 4));
    CHECK(*fitted.value().fitted_second_backlog_moment == rational(3, 2));
    CHECK(*fitted.value().arrival_third_moment == rational(1, 4));
    CHECK(*fitted.value().tail_slack == rational(1, 4));
    REQUIRE(fitted.value().residuals.normalization);
    REQUIRE(fitted.value().residuals.invariance);
    REQUIRE(fitted.value().residuals.mean_identity);
    CHECK(fitted.value().residuals.normalization->is_zero());
    CHECK(fitted.value().residuals.invariance->is_zero());
    CHECK(fitted.value().residuals.mean_identity->is_zero());
  }
}

TEST_CASE("C30 finite closure precedes the nonpositive-slack classification",
          "[c30][math][unit]") {
  auto input = mwperf::FinitePrefixFitInputV1{
      {{mwperf::BigNat{0U}, rational(1)}},
      true,
      true,
      {{mwperf::BigNat{0U}, rational(1)}},
      {rational(0), rational(0), rational(0), rational(0), rational(0)},
      rational(0),
      {digest('3'), digest('4')},
      {},
      std::nullopt,
      false};

  auto fitted = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE(fitted);
  CHECK(fitted.value().status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
  REQUIRE(fitted.value().fitted_tail_mass);
  REQUIRE(fitted.value().fitted_mean_backlog);
  REQUIRE(fitted.value().fitted_second_backlog_moment);
  CHECK(fitted.value().fitted_tail_mass->is_zero());
  CHECK(fitted.value().fitted_mean_backlog->is_zero());
  CHECK(fitted.value().fitted_second_backlog_moment->is_zero());
  CHECK_FALSE(fitted.value().tail_slack.has_value());
  CHECK(fitted.value().tail_slack_applicability ==
        mwperf::FinitePrefixFitSlackApplicabilityV1::
            not_applicable_off_class);
}

TEST_CASE("C32 second backlog moment requires the exact third arrival moment",
          "[c32][math][unit]") {
  auto input = stable_bernoulli_input(4U);
  input.third_arrival_moment_available = false;
  auto fitted = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE(fitted);
  CHECK(fitted.value().status ==
        mwperf::FinitePrefixFitStatusV1::strict_tail_stable);
  REQUIRE(fitted.value().fitted_mean_backlog);
  CHECK(*fitted.value().fitted_mean_backlog == rational(3, 4));
  CHECK_FALSE(fitted.value().arrival_third_moment.has_value());
  CHECK_FALSE(fitted.value().fitted_second_backlog_moment.has_value());
}

TEST_CASE("C32 second backlog moment includes finite-prefix drift corrections",
          "[c32][math][unit]") {
  auto input = stable_bernoulli_input(2U);
  input.service_by_level = {rational(0), rational(3, 4), rational(1, 2)};

  auto fitted =
      mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE(fitted);
  CHECK(fitted.value().status ==
        mwperf::FinitePrefixFitStatusV1::strict_tail_stable);
  REQUIRE(fitted.value().fitted_mean_backlog);
  REQUIRE(fitted.value().fitted_second_backlog_moment);

  // For Bernoulli(1/4) arrivals, mu(1)=3/4 and mu(q)=1/2 for
  // q>=2, detailed balance gives pi_0=9/14, pi_1=2/7 and a
  // geometric tail with ratio 1/3.  Its first two raw moments are
  // therefore 13/28 and 11/14.  This exercises both C1 and C2 in the
  // third-power drift identity rather than only its constant-service case.
  CHECK(*fitted.value().fitted_mean_backlog == rational(13, 28));
  CHECK(*fitted.value().fitted_second_backlog_moment == rational(11, 14));
}

TEST_CASE("C32 finite closure computes its second backlog moment directly",
          "[c32][math][unit][finite-closure]") {
  auto input = mwperf::FinitePrefixFitInputV1{
      {{mwperf::BigNat{0U}, rational(1)}},
      false,
      false,
      {{mwperf::BigNat{2U}, rational(1)}},
      {rational(0), rational(0), rational(0)},
      rational(0),
      {digest('5'), digest('6')},
      {},
      std::nullopt,
      false};

  auto fitted = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE(fitted);
  CHECK(fitted.value().status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
  REQUIRE(fitted.value().fitted_mean_backlog);
  REQUIRE(fitted.value().fitted_second_backlog_moment);
  CHECK(*fitted.value().fitted_mean_backlog == rational(2));
  CHECK(*fitted.value().fitted_second_backlog_moment == rational(4));
}

TEST_CASE("C32 second backlog moment uses raw batch-arrival moments",
          "[c32][math][unit]") {
  auto input = mwperf::FinitePrefixFitInputV1{
      {{mwperf::BigNat{0U}, rational(3, 4)},
       {mwperf::BigNat{2U}, rational(1, 4)}},
      true,
      true,
      {},
      {rational(0)},
      rational(1),
      {digest('7'), digest('8')},
      {},
      std::nullopt,
      false};

  auto fitted = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE(fitted);
  CHECK(fitted.value().status ==
        mwperf::FinitePrefixFitStatusV1::strict_tail_stable);
  REQUIRE(fitted.value().arrival_second_moment);
  REQUIRE(fitted.value().arrival_third_moment);
  REQUIRE(fitted.value().fitted_mean_backlog);
  REQUIRE(fitted.value().fitted_second_backlog_moment);

  // A is zero with probability 3/4 and two with probability 1/4, so
  // E[A]=1/2, E[A^2]=1 and E[A^3]=2.  With deterministic service at every
  // positive level, the exact stationary first two raw backlog moments are
  // 1 and 5/2.
  CHECK(*fitted.value().arrival_second_moment == rational(1));
  CHECK(*fitted.value().arrival_third_moment == rational(2));
  CHECK(*fitted.value().fitted_mean_backlog == rational(1));
  CHECK(*fitted.value().fitted_second_backlog_moment == rational(5, 2));
}

TEST_CASE("C30 fit admission checks reject cutoff limits",
          "[c30][math][negative]") {
  auto input = stable_bernoulli_input(4U);
  input.limits.maximum_cutoff = 3U;
  auto fitted = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  REQUIRE_FALSE(fitted);
  CHECK(fitted.error().code == "c19.fit_cutoff_limit");
  CHECK(fitted.error().category == mwperf::DiagnosticCategory::resource_limit);
}
