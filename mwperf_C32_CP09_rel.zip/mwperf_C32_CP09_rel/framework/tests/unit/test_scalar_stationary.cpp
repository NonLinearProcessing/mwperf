#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/stationary/analytic.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"

namespace {

using mwperf::AnalyticStationaryStatusV1;
using mwperf::ArrivalLaw;
using mwperf::ArrivalTransform;
using mwperf::BigNat;
using mwperf::Cutoff;
using mwperf::EvaluationPoint;
using mwperf::ExactRational;
using mwperf::MeanSojournCountingConventionV1;
using mwperf::ScalarArrivalMassV1;
using mwperf::ScalarStationaryLaw;
using mwperf::TailPolicy;
using mwperf::TailService;
using mwperf::testing::C19FixtureAccess;
using mwperf::testing::C19ThreeBinFixtureAccess;
using mwperf::testing::ExactLittleLawPremisesFixtureV1;
using mwperf::testing::ExactScalarResponseFixtureV1;

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator = 1) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] ExactRational divide(const ExactRational& numerator,
                                   const ExactRational& denominator) {
  auto value = mwperf::checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] TailService tail_service(const ExactRational& value) {
  auto service = TailService::make(value);
  REQUIRE(service);
  return std::move(service).value();
}

[[nodiscard]] EvaluationPoint evaluation_point(const ExactRational& value) {
  auto point = EvaluationPoint::make(value);
  REQUIRE(point);
  return std::move(point).value();
}

[[nodiscard]] ArrivalLaw arrival_law(
    std::vector<ScalarArrivalMassV1> atoms) {
  auto law = C19FixtureAccess::arrival_law(std::move(atoms));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] ArrivalLaw bernoulli_arrival(const ExactRational& rate) {
  return arrival_law({{BigNat{0U}, ExactRational::one() - rate},
                      {BigNat{1U}, rate}});
}

[[nodiscard]] ExactScalarResponseFixtureV1 constant_response(
    const ExactRational& service) {
  return {{ExactRational::zero()}, BigNat{1U}, service};
}

[[nodiscard]] ExactScalarResponseFixtureV1 three_bin_response(
    const ExactRational& s1, const ExactRational& s2,
    const ExactRational& c) {
  return {{ExactRational::zero(), s1, s2}, BigNat{3U}, c};
}

[[nodiscard]] ExactRational mass(const ScalarStationaryLaw& law,
                                 const std::uint64_t level) {
  auto value = law.mass(BigNat{level});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] ExactRational survival(
    const std::vector<ExactRational>& arrival,
    const std::size_t threshold) {
  ExactRational result = ExactRational::zero();
  for (std::size_t index = threshold; index < arrival.size(); ++index) {
    result = result + arrival[index];
  }
  return result;
}

// SF.19 evaluated directly from its source equation. This deliberately does
// not call the production recurrence or its survival-probability helper.
[[nodiscard]] ExactRational sf19_rhs(
    const std::vector<ExactRational>& arrival,
    const std::vector<ExactRational>& response,
    const std::vector<ExactRational>& stationary_mass,
    const std::size_t cut) {
  ExactRational result = ExactRational::zero();
  for (std::size_t index = 0U; index < cut; ++index) {
    const std::size_t distance = cut - index;
    result = result +
             stationary_mass[index] *
                 ((ExactRational::one() - response[index]) *
                      survival(arrival, distance) +
                  response[index] * survival(arrival, distance + 1U));
  }
  return result;
}

}  // namespace

TEST_CASE("C19 SF.14 preserves early-service late-admission probabilities",
          "[c19][unit][scalar][sf14]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const ArrivalLaw arrival = bernoulli_arrival(lambda);
  auto flux = C19FixtureAccess::scalar_flux(
      arrival, constant_response(service));
  REQUIRE(flux);
  CHECK(flux.value().identity().payload_phase() ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK_FALSE(flux.value().identity().accepted_metric_clause().has_value());
  CHECK_FALSE(flux.value().identity().realized_metric_binding().has_value());

  const auto probability = [&](const std::uint64_t source,
                               const std::uint64_t destination) {
    auto value = flux.value().transition_probability(
        BigNat{source}, BigNat{destination});
    REQUIRE(value);
    return std::move(value).value();
  };

  CHECK(probability(0U, 0U) == rational(3, 4));
  CHECK(probability(0U, 1U) == rational(1, 4));
  CHECK(probability(0U, 2U) == ExactRational::zero());

  CHECK(probability(2U, 0U) == ExactRational::zero());
  CHECK(probability(2U, 1U) == rational(3, 8));
  CHECK(probability(2U, 2U) == rational(1, 2));
  CHECK(probability(2U, 3U) == rational(1, 8));
  CHECK(probability(2U, 1U) + probability(2U, 2U) +
            probability(2U, 3U) ==
        ExactRational::one());
}

TEST_CASE("C19 SF.19 and SF.21 give the constant-service Bernoulli law",
          "[c19][unit][scalar][sf19][sf21]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const ArrivalLaw arrival = bernoulli_arrival(lambda);
  auto flux = C19FixtureAccess::scalar_flux(
      arrival, constant_response(service));
  REQUIRE(flux);
  const TailService tail = tail_service(service);
  auto cut_law = mwperf::solve_scalar_cut_recursion(
      flux.value(), TailPolicy::constant_response(Cutoff{BigNat{0U}}, tail));
  REQUIRE(cut_law);
  auto birth_death = C19FixtureAccess::solve_bernoulli(
      arrival, constant_response(service));
  REQUIRE(birth_death);

  const std::vector<ExactRational> expected{
      rational(1, 2), rational(1, 3), rational(1, 9), rational(1, 27)};
  for (std::size_t level = 0U; level < expected.size(); ++level) {
    CAPTURE(level);
    CHECK(mass(cut_law.value(), level) == expected[level]);
    CHECK(mass(birth_death.value(), level) == expected[level]);
  }

  const std::vector<ExactRational> arrival_pmf{rational(3, 4), lambda};
  const std::vector<ExactRational> response{
      ExactRational::zero(), service, service, service};
  for (std::size_t cut = 1U; cut < expected.size(); ++cut) {
    CAPTURE(cut);
    CHECK(expected[cut] * response[cut] * arrival_pmf.front() ==
          sf19_rhs(arrival_pmf, response, expected, cut));
  }

  for (std::size_t level = 0U; level + 1U < expected.size(); ++level) {
    CAPTURE(level);
    const ExactRational sf21 = divide(
        lambda * (ExactRational::one() - response[level]),
        (ExactRational::one() - lambda) * response[level + 1U]);
    CHECK(divide(expected[level + 1U], expected[level]) == sf21);
  }

  REQUIRE(cut_law.value().exact_mean_backlog());
  REQUIRE(birth_death.value().exact_mean_backlog());
  CHECK(*cut_law.value().exact_mean_backlog() == rational(3, 4));
  CHECK(*birth_death.value().exact_mean_backlog() == rational(3, 4));

  const ArrivalTransform transform = ArrivalTransform::from(arrival);
  const auto check_pgf = [&](const ExactRational& z,
                             const ExactRational& expected_pgf,
                             const ExactRational& expected_response_pgf) {
    auto readout = mwperf::evaluate_scalar_pgf_and_moments(
        cut_law.value(), transform, evaluation_point(z));
    REQUIRE(readout);
    REQUIRE(readout.value().exact_pgf());
    REQUIRE(readout.value().exact_response_weighted_pgf());
    CHECK(*readout.value().exact_pgf() == expected_pgf);
    CHECK(*readout.value().exact_response_weighted_pgf() ==
          expected_response_pgf);
  };
  check_pgf(ExactRational::zero(), rational(1, 2),
            ExactRational::zero());
  check_pgf(rational(1, 2), rational(7, 10), rational(1, 10));
  check_pgf(ExactRational::one(), ExactRational::one(), lambda);

  // At z=1/2 the two sides of SF.16 and the quotient in SF.17 are exact.
  const ExactRational z = rational(1, 2);
  const ExactRational pgf = rational(7, 10);
  const ExactRational arrival_pgf = rational(7, 8);
  const ExactRational response_transform = rational(1, 10);
  CHECK(arrival_pgf *
            (pgf + (divide(ExactRational::one(), z) -
                    ExactRational::one()) *
                       response_transform) ==
        pgf);
  CHECK(divide(z * (ExactRational::one() - arrival_pgf) * pgf,
               arrival_pgf * (ExactRational::one() - z)) ==
        response_transform);
  CHECK(service * (ExactRational::one() - expected.front()) == lambda);
}

TEST_CASE("C19 SF.19 solves the batch-arrival work-conserving fixture",
          "[c19][unit][scalar][sf19][batch]") {
  const std::vector<ExactRational> arrival_pmf{
      rational(3, 4), ExactRational::zero(), rational(1, 4)};
  const ArrivalLaw arrival = arrival_law(
      {{BigNat{0U}, arrival_pmf[0U]}, {BigNat{2U}, arrival_pmf[2U]}});
  auto flux = C19FixtureAccess::scalar_flux(
      arrival, constant_response(ExactRational::one()));
  REQUIRE(flux);
  auto law = mwperf::solve_scalar_cut_recursion(
      flux.value(), TailPolicy::constant_response(
                        Cutoff{BigNat{0U}},
                        tail_service(ExactRational::one())));
  REQUIRE(law);

  const std::vector<ExactRational> expected{
      rational(1, 2), rational(1, 6), rational(2, 9),
      rational(2, 27), rational(2, 81)};
  const std::vector<ExactRational> response(
      expected.size(), ExactRational::one());
  std::vector<ExactRational> response_with_empty = response;
  response_with_empty.front() = ExactRational::zero();
  for (std::size_t level = 0U; level < expected.size(); ++level) {
    CAPTURE(level);
    CHECK(mass(law.value(), level) == expected[level]);
  }
  for (std::size_t cut = 1U; cut < expected.size(); ++cut) {
    CAPTURE(cut);
    CHECK(expected[cut] * response_with_empty[cut] * arrival_pmf.front() ==
          sf19_rhs(arrival_pmf, response_with_empty, expected, cut));
  }
  REQUIRE(law.value().exact_mean_backlog());
  CHECK(*law.value().exact_mean_backlog() == ExactRational::one());
}

TEST_CASE("C19 work-conserving Bernoulli service closes on levels zero and one",
          "[c19][unit][scalar][sf21][finite-closure]") {
  const ExactRational lambda = rational(2, 5);
  const ArrivalLaw arrival = bernoulli_arrival(lambda);
  auto flux = C19FixtureAccess::scalar_flux(
      arrival, constant_response(ExactRational::one()));
  REQUIRE(flux);
  auto cut_law = mwperf::solve_scalar_cut_recursion(
      flux.value(), TailPolicy::exact_finite_closure(Cutoff{BigNat{1U}}));
  REQUIRE(cut_law);
  auto birth_death = C19FixtureAccess::solve_bernoulli(
      arrival, constant_response(ExactRational::one()));
  REQUIRE(birth_death);

  CHECK(mass(cut_law.value(), 0U) == rational(3, 5));
  CHECK(mass(cut_law.value(), 1U) == rational(2, 5));
  CHECK(mass(birth_death.value(), 0U) == rational(3, 5));
  CHECK(mass(birth_death.value(), 1U) == rational(2, 5));
  REQUIRE(cut_law.value().exact_tail_mass());
  REQUIRE(birth_death.value().exact_tail_mass());
  CHECK(*cut_law.value().exact_tail_mass() == ExactRational::zero());
  CHECK(*birth_death.value().exact_tail_mass() == ExactRational::zero());
  REQUIRE(cut_law.value().exact_mean_backlog());
  REQUIRE(birth_death.value().exact_mean_backlog());
  CHECK(*cut_law.value().exact_mean_backlog() == lambda);
  CHECK(*birth_death.value().exact_mean_backlog() == lambda);
  CHECK_FALSE(cut_law.value().diagnostics().tail_slack.has_value());
  CHECK(cut_law.value().diagnostics().numerical_condition_estimate == 1.0L);

  // The SF.21 tail ratio is exactly zero when c=1, so the birth--death law
  // has exact finite support rather than a numerically truncated tail.
  const ExactRational tail_ratio = divide(
      lambda * (ExactRational::one() - ExactRational::one()),
      (ExactRational::one() - lambda) * ExactRational::one());
  CHECK(tail_ratio == ExactRational::zero());
  REQUIRE(birth_death.value().diagnostics().tail_slack);
  const ExactRational strict_tail_slack = ExactRational::one() - lambda;
  CHECK(*birth_death.value().diagnostics().tail_slack == strict_tail_slack);
  CHECK(birth_death.value().diagnostics().numerical_condition_estimate ==
        1.0L / strict_tail_slack.to_long_double());
  REQUIRE(birth_death.value().finite_closure_proof());
  CHECK(birth_death.value().finite_closure_proof()->law_identity() ==
        birth_death.value().identity());
  const auto birth_death_support =
      birth_death.value().finite_closure_proof()->reachable_support();
  REQUIRE(birth_death_support.size() == 2U);
  CHECK(birth_death_support[0U] == BigNat{0U});
  CHECK(birth_death_support[1U] == BigNat{1U});
  CHECK(mass(birth_death.value(), 2U) == ExactRational::zero());

  REQUIRE(cut_law.value().finite_closure_proof());
  CHECK(cut_law.value().finite_closure_proof()->law_identity() ==
        cut_law.value().identity());
  const auto cut_support =
      cut_law.value().finite_closure_proof()->reachable_support();
  REQUIRE(cut_support.size() == 2U);
  CHECK(cut_support[0U] == BigNat{0U});
  CHECK(cut_support[1U] == BigNat{1U});
}

TEST_CASE("C19 F02 accepts only its operator-declared constant tail",
          "[c19][unit][scalar][sf19][tail-policy]") {
  const ArrivalLaw arrival = bernoulli_arrival(rational(1, 4));
  const ExactRational service = rational(1, 2);

  auto undeclared_flux = C19FixtureAccess::scalar_flux(
      arrival, {{ExactRational::zero(), service}, std::nullopt, std::nullopt});
  REQUIRE(undeclared_flux);
  auto undeclared = mwperf::solve_scalar_cut_recursion(
      undeclared_flux.value(),
      TailPolicy::constant_response(Cutoff{BigNat{1U}},
                                    tail_service(service)));
  REQUIRE_FALSE(undeclared);
  CHECK(undeclared.error().code == "c19.constant_tail_policy_mismatch");

  auto declared_flux = C19FixtureAccess::scalar_flux(
      arrival,
      {{ExactRational::zero(), service}, BigNat{2U}, service});
  REQUIRE(declared_flux);
  auto wrong_cutoff = mwperf::solve_scalar_cut_recursion(
      declared_flux.value(),
      TailPolicy::constant_response(Cutoff{BigNat{0U}},
                                    tail_service(service)));
  REQUIRE_FALSE(wrong_cutoff);
  CHECK(wrong_cutoff.error().code == "c19.constant_tail_policy_mismatch");

  auto wrong_service = mwperf::solve_scalar_cut_recursion(
      declared_flux.value(),
      TailPolicy::constant_response(Cutoff{BigNat{1U}},
                                    tail_service(rational(3, 4))));
  REQUIRE_FALSE(wrong_service);
  CHECK(wrong_service.error().code == "c19.constant_tail_policy_mismatch");
}

TEST_CASE("C19 SF.19 distinguishes inconsistent zero from zero over zero",
          "[c19][unit][scalar][sf19][zero-denominator]") {
  const ExactScalarResponseFixtureV1 zero_at_one{
      {ExactRational::zero(), ExactRational::zero()}, std::nullopt,
      std::nullopt};

  const ArrivalLaw crossing_arrival = bernoulli_arrival(rational(1, 2));
  auto inconsistent_flux =
      C19FixtureAccess::scalar_flux(crossing_arrival, zero_at_one);
  REQUIRE(inconsistent_flux);
  auto inconsistent = mwperf::solve_scalar_cut_recursion(
      inconsistent_flux.value(), TailPolicy::no_completion(BigNat{2U}));
  REQUIRE(inconsistent);
  CHECK(inconsistent.value().status() ==
        AnalyticStationaryStatusV1::unsupported_assumptions);
  CHECK_FALSE(inconsistent.value().normalized_law_established());
  REQUIRE(inconsistent.value().diagnostics().terms_evaluated);
  CHECK(*inconsistent.value().diagnostics().terms_evaluated == BigNat{1U});

  const ArrivalLaw no_crossing_arrival =
      arrival_law({{BigNat{0U}, ExactRational::one()}});
  auto underdetermined_flux =
      C19FixtureAccess::scalar_flux(no_crossing_arrival, zero_at_one);
  REQUIRE(underdetermined_flux);
  auto underdetermined = mwperf::solve_scalar_cut_recursion(
      underdetermined_flux.value(), TailPolicy::no_completion(BigNat{2U}));
  REQUIRE(underdetermined);
  CHECK(underdetermined.value().status() ==
        AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
  CHECK_FALSE(underdetermined.value().normalized_law_established());
  REQUIRE(underdetermined.value().diagnostics().terms_evaluated);
  CHECK(*underdetermined.value().diagnostics().terms_evaluated == BigNat{1U});
}

TEST_CASE("C19 finite PGF ignores response values on zero-mass levels",
          "[c19][unit][scalar][sf16][finite-closure]") {
  const ArrivalLaw arrival =
      arrival_law({{BigNat{0U}, ExactRational::one()}});
  auto flux = C19FixtureAccess::scalar_flux(
      arrival, {{ExactRational::zero()}, std::nullopt, std::nullopt});
  REQUIRE(flux);
  auto law = mwperf::solve_scalar_cut_recursion(
      flux.value(), TailPolicy::exact_finite_closure(Cutoff{BigNat{3U}}));
  REQUIRE(law);
  CHECK(law.value().normalized_law_established());
  REQUIRE(law.value().finite_closure_proof());
  const auto support = law.value().finite_closure_proof()->reachable_support();
  REQUIRE(support.size() == 1U);
  CHECK(support.front() == BigNat{0U});

  auto readout = mwperf::evaluate_scalar_pgf_and_moments(
      law.value(), ArrivalTransform::from(arrival),
      evaluation_point(rational(1, 2)));
  REQUIRE(readout);
  REQUIRE(readout.value().exact_pgf());
  REQUIRE(readout.value().exact_response_weighted_pgf());
  CHECK(*readout.value().exact_pgf() == ExactRational::one());
  CHECK(*readout.value().exact_response_weighted_pgf() ==
        ExactRational::zero());
}

TEST_CASE("C19 SF.22 gives the nonmonotone three-bin constant-tail oracle",
          "[c19][unit][scalar][sf22][three-bin]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational s1 = rational(3, 4);
  const ExactRational s2 = rational(1, 4);
  const ExactRational c = rational(2, 3);
  const ArrivalLaw arrival = bernoulli_arrival(lambda);
  auto law = C19FixtureAccess::solve_constant_tail(
      arrival, three_bin_response(s1, s2, c), Cutoff{BigNat{2U}},
      tail_service(c));
  REQUIRE(law);
  CHECK(law.value().status() ==
        AnalyticStationaryStatusV1::strict_tail_stable);
  CHECK(law.value().normalized_law_established());

  const ExactRational w1 = rational(4, 9);
  const ExactRational w2 = rational(4, 27);
  const ExactRational b_one =
      c + w1 * (c - s1) + w2 * (c - s2);
  CHECK(b_one == rational(56, 81));
  const ExactRational pi0 = divide(c - lambda, b_one);
  const ExactRational pi1 = pi0 * w1;
  const ExactRational pi2 = pi0 * w2;
  const ExactRational tail =
      ExactRational::one() - pi0 - pi1 - pi2;
  CHECK(pi0 == rational(135, 224));
  CHECK(pi1 == rational(15, 56));
  CHECK(pi2 == rational(5, 56));
  CHECK(tail == rational(9, 224));
  CHECK(mass(law.value(), 0U) == pi0);
  CHECK(mass(law.value(), 1U) == pi1);
  CHECK(mass(law.value(), 2U) == pi2);
  REQUIRE(law.value().exact_tail_mass());
  CHECK(*law.value().exact_tail_mass() == tail);

  const ExactRational correction_at_one =
      pi0 * c + pi1 * (c - s1) + pi2 * (c - s2);
  CHECK(correction_at_one == c - lambda);
  const ExactRational correction_derivative =
      pi1 * (c - s1) + rational(2) * pi2 * (c - s2);
  CHECK(correction_derivative == rational(5, 96));
  const ExactRational mean = divide(
      lambda + lambda - rational(2) * lambda * lambda +
          rational(2) * correction_derivative,
      rational(2) * (c - lambda));
  CHECK(mean == rational(23, 40));
  REQUIRE(law.value().exact_mean_backlog());
  CHECK(*law.value().exact_mean_backlog() == mean);
  REQUIRE(law.value().diagnostics().tail_slack);
  CHECK(*law.value().diagnostics().tail_slack == rational(5, 12));

  // C(1)=c-lambda also gives stationary flow conservation exactly.
  CHECK(s1 * pi1 + s2 * pi2 + c * tail == lambda);

  auto readout = mwperf::evaluate_scalar_pgf_and_moments(
      law.value(), ArrivalTransform::from(arrival),
      evaluation_point(rational(1, 2)));
  REQUIRE(readout);
  REQUIRE(readout.value().exact_pgf());
  CHECK(*readout.value().exact_pgf() == rational(7525, 9856));
}

TEST_CASE("C19 stationary backlog gives the departure-slot Little-law value",
          "[c19][unit][scalar][little-law]") {
  const ExactRational lambda = rational(1, 4);
  const ArrivalLaw arrival = bernoulli_arrival(lambda);
  const ExactRational service = rational(1, 2);
  const ExactScalarResponseFixtureV1 response =
      three_bin_response(service, service, service);
  auto summary = C19ThreeBinFixtureAccess::summarize(
      arrival, response, {true, true, true, true, true, true});
  REQUIRE(summary);
  REQUIRE(summary.value().exact_mean_backlog());
  REQUIRE(summary.value().exact_mean_sojourn());
  CHECK(*summary.value().exact_mean_backlog() == rational(3, 4));
  CHECK(*summary.value().exact_mean_sojourn() == rational(3));
  CHECK(*summary.value().exact_mean_sojourn() ==
        divide(*summary.value().exact_mean_backlog(), arrival.mean()));
  CHECK(summary.value().sojourn_counting_convention() ==
        MeanSojournCountingConventionV1::includes_departure_slot);

  const std::array<ExactLittleLawPremisesFixtureV1, 6> missing_premise{
      ExactLittleLawPremisesFixtureV1{false, true, true, true, true, true},
      ExactLittleLawPremisesFixtureV1{true, false, true, true, true, true},
      ExactLittleLawPremisesFixtureV1{true, true, false, true, true, true},
      ExactLittleLawPremisesFixtureV1{true, true, true, false, true, true},
      ExactLittleLawPremisesFixtureV1{true, true, true, true, false, true},
      ExactLittleLawPremisesFixtureV1{true, true, true, true, true, false}};
  for (const auto& premises : missing_premise) {
    auto withheld =
        C19ThreeBinFixtureAccess::summarize(arrival, response, premises);
    REQUIRE(withheld);
    REQUIRE(withheld.value().exact_mean_backlog());
    CHECK(*withheld.value().exact_mean_backlog() == rational(3, 4));
    CHECK_FALSE(withheld.value().exact_mean_sojourn().has_value());
    CHECK_FALSE(withheld.value().numerical_mean_sojourn().has_value());
  }
}

TEST_CASE("C19 reachable tail reports an unavailable required second moment",
          "[c19][unit][scalar][sf22][moment]") {
  auto arrival_result = C19FixtureAccess::arrival_law_without_second_moment(
      {{BigNat{0U}, rational(3, 4)}, {BigNat{1U}, rational(1, 4)}});
  REQUIRE(arrival_result);
  const ArrivalLaw arrival = std::move(arrival_result).value();
  const auto response =
      three_bin_response(rational(3, 4), rational(1, 4), rational(2, 3));

  auto law = C19FixtureAccess::solve_constant_tail(
      arrival, response, Cutoff{BigNat{2U}}, tail_service(rational(2, 3)));
  REQUIRE(law);
  CHECK(law.value().status() ==
        AnalyticStationaryStatusV1::required_moment_unavailable);
  CHECK(law.value().normalized_law_established());
  CHECK_FALSE(law.value().exact_mean_backlog().has_value());
  CHECK_FALSE(law.value().numerical_mean_backlog().has_value());
  REQUIRE(law.value().exact_tail_mass());
  CHECK(*law.value().exact_tail_mass() == rational(9, 224));

  auto summary = C19ThreeBinFixtureAccess::summarize(
      arrival, response, {true, true, true, true, true, true});
  REQUIRE(summary);
  CHECK(summary.value().status() ==
        AnalyticStationaryStatusV1::required_moment_unavailable);
  REQUIRE(summary.value().pi_zero());
  REQUIRE(summary.value().pi_one());
  REQUIRE(summary.value().pi_two());
  REQUIRE(summary.value().tail_mass_from_three());
  CHECK(*summary.value().pi_zero() == rational(135, 224));
  CHECK(*summary.value().pi_one() == rational(15, 56));
  CHECK(*summary.value().pi_two() == rational(5, 56));
  CHECK(*summary.value().tail_mass_from_three() == rational(9, 224));
  CHECK_FALSE(summary.value().exact_mean_backlog().has_value());
  CHECK_FALSE(summary.value().exact_mean_sojourn().has_value());
}

TEST_CASE("C19 unit arrivals separate the F04 endpoint from F05 strict tail",
          "[c19][unit][scalar][sf21][sf22][endpoint]") {
  const ArrivalLaw arrival =
      arrival_law({{BigNat{0U}, ExactRational::zero()},
                   {BigNat{1U}, ExactRational::one()}});
  REQUIRE(arrival.atoms().size() == 1U);
  CHECK(arrival.atoms().front() ==
        (ScalarArrivalMassV1{BigNat{1U}, ExactRational::one()}));
  const auto response = three_bin_response(
      ExactRational::zero(), ExactRational::zero(), ExactRational::one());

  auto birth_death = C19FixtureAccess::solve_bernoulli(arrival, response);
  REQUIRE(birth_death);
  auto constant_tail = C19FixtureAccess::solve_constant_tail(
      arrival, response, Cutoff{BigNat{2U}},
      tail_service(ExactRational::one()));
  REQUIRE(constant_tail);

  CHECK(birth_death.value().status() ==
        AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
  CHECK(constant_tail.value().status() ==
        AnalyticStationaryStatusV1::outside_strict_tail_profile);
  CHECK(birth_death.value().identity() == constant_tail.value().identity());
  for (std::uint64_t level = 0U; level <= 4U; ++level) {
    CAPTURE(level);
    const ExactRational expected =
        level == 3U ? ExactRational::one() : ExactRational::zero();
    CHECK(mass(birth_death.value(), level) == expected);
  }
  REQUIRE(birth_death.value().exact_mean_backlog());
  CHECK(*birth_death.value().exact_mean_backlog() == rational(3));
  CHECK_FALSE(constant_tail.value().normalized_law_established());
  CHECK_FALSE(constant_tail.value().exact_mean_backlog().has_value());
  CHECK_FALSE(constant_tail.value().exact_tail_mass().has_value());

  REQUIRE(birth_death.value().finite_closure_proof());
  CHECK(birth_death.value().finite_closure_proof()->law_identity() ==
        birth_death.value().identity());
  CHECK_FALSE(constant_tail.value().finite_closure_proof().has_value());
  const auto support =
      birth_death.value().finite_closure_proof()->reachable_support();
  REQUIRE(support.size() == 4U);
  for (std::size_t level = 0U; level < support.size(); ++level) {
    CAPTURE(level);
    CHECK(support[level] == BigNat{static_cast<std::uint64_t>(level)});
  }

  auto summary = C19ThreeBinFixtureAccess::summarize(
      arrival, response, {true, true, true, true, true, true});
  REQUIRE(summary);
  CHECK(summary.value().status() ==
        AnalyticStationaryStatusV1::outside_strict_tail_profile);
  CHECK_FALSE(summary.value().pi_zero().has_value());
  CHECK_FALSE(summary.value().pi_one().has_value());
  CHECK_FALSE(summary.value().pi_two().has_value());
  CHECK_FALSE(summary.value().tail_mass_from_three().has_value());
  CHECK_FALSE(summary.value().exact_mean_backlog().has_value());
  CHECK_FALSE(summary.value().exact_mean_sojourn().has_value());
  CHECK(summary.value().tail_slack_applicability() ==
        mwperf::TailSlackApplicabilityV1::applicable);
  REQUIRE(summary.value().tail_slack());
  CHECK(*summary.value().tail_slack() == ExactRational::zero());
  const auto bins = summary.value().bins();
  CHECK(bins[3U].conditioning_mass.kind() ==
        mwperf::StationaryConditioningMassKindV1::
            stationary_law_not_established);
  CHECK_FALSE(bins[3U].conditioning_mass.mass().has_value());
  CHECK_FALSE(bins[3U].conditioning_mass.region().has_value());
}
