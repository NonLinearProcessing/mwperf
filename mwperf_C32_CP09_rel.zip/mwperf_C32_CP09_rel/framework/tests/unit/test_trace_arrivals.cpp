#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/trace.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

using TraceStepSignature = mwperf::Result<mwperf::ArrivalStep> (*)(
    mwperf::TraceCursor&, const mwperf::BigNat&);

static_assert(std::same_as<decltype(&mwperf::next_trace_batch),
                           TraceStepSignature>);
static_assert(std::same_as<mwperf::TraceCursor, mwperf::ArrivalProcess>);
static_assert(!std::is_default_constructible_v<mwperf::TraceLaw>);
static_assert(std::is_copy_constructible_v<mwperf::TraceLaw>);

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto label = mwperf::TypedLabel::text(value);
  REQUIRE(label);
  return std::move(label).value();
}

[[nodiscard]] mwperf::QueueId text_queue(const std::string& value) {
  return mwperf::QueueId(text_label(value));
}

[[nodiscard]] mwperf::QueueId numeric_queue(const std::uint64_t value) {
  return mwperf::QueueId(
      mwperf::TypedLabel::numeric(mwperf::BigNat(value)));
}

[[nodiscard]] mwperf::AuthoredQueue authored_queue(
    mwperf::QueueId id, const std::size_t ordinal) {
  const std::string base = "/switch/queues/" + std::to_string(ordinal);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{std::move(id),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<std::optional<mwperf::LegacyVoqCoordinate>>{
          std::nullopt, provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::QueueCatalog make_catalog(
    std::vector<mwperf::QueueId> ids =
        {text_queue("q0"), text_queue("q1"), text_queue("q2")}) {
  std::vector<mwperf::AuthoredQueue> queues;
  queues.reserve(ids.size());
  for (std::size_t index = 0U; index < ids.size(); ++index) {
    queues.push_back(authored_queue(std::move(ids[index]), index));
  }
  mwperf::AuthoredSwitchConfig authored = mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          std::move(queues), provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
  auto catalog = mwperf::build_queue_catalog(authored);
  REQUIRE(catalog);
  return std::move(catalog).value();
}

[[nodiscard]] mwperf::TraceEvent trace_event(
    mwperf::BigNat slot, mwperf::QueueId queue, mwperf::BigNat count,
    const std::size_t ordinal) {
  const std::string base = "/arrival/events/" + std::to_string(ordinal);
  return mwperf::TraceEvent{
      mwperf::AuthoredField<mwperf::BigNat>{std::move(slot),
                                            provenance(base + "/slot")},
      mwperf::AuthoredField<mwperf::QueueId>{std::move(queue),
                                             provenance(base + "/queue_id")},
      mwperf::AuthoredField<mwperf::BigNat>{std::move(count),
                                            provenance(base + "/count")},
      provenance(base)};
}

[[nodiscard]] mwperf::DeterministicTraceArrival authored_trace(
    std::vector<mwperf::TraceEvent> events) {
  return mwperf::DeterministicTraceArrival{
      mwperf::AuthoredField<std::vector<mwperf::TraceEvent>>{
          std::move(events), provenance("/arrival/events")},
      mwperf::AuthoredMetadata{std::nullopt,
                               provenance("/arrival/metadata")},
      provenance("/arrival")};
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(
      "000102030405060708090a0b0c0d0e0f"
      "101112131415161718191a1b1c1d1e1f");
  if (!digest) {
    throw std::logic_error("invalid deterministic-trace fixture digest");
  }
  return std::move(digest).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t instance = 0U) {
  auto key = mwperf::make_physical_reference_instance_key(
      fixture_digest(), mwperf::BigNat(instance));
  if (!key) {
    throw std::logic_error("invalid deterministic-trace instance key");
  }
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::CompiledArrivalLaw publish_trace(
    const mwperf::DeterministicTraceArrival& trace,
    const mwperf::QueueCatalog& catalog) {
  mwperf::AuthoredArrivalConfig authored{trace, provenance("/arrival")};
  auto law = mwperf::compile_arrival_law(authored, catalog);
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::ArrivalProcess make_process(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t seed = 17U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, mwperf::ArrivalInitialState{mwperf::TraceOrigin{}},
      std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto result = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(result);
  return std::move(result).value();
}

void check_snapshot_equal(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  CHECK(left.expected_slot == right.expected_slot);
  CHECK(left.phase_digest == right.phase_digest);
  CHECK(left.rng.rng_version() == right.rng.rng_version());
  CHECK(left.rng.stream_identity() == right.rng.stream_identity());
  CHECK(left.rng.state_words() == right.rng.state_words());
  CHECK(left.rng.consumed_words() == right.rng.consumed_words());
}

[[nodiscard]] mwperf::BigNat huge_slot() {
  auto value = mwperf::BigNat::from_big_int(mwperf::BigInt(1) << 4096U);
  REQUIRE(value);
  return std::move(value).value();
}

}  // namespace

TEST_CASE("C10 trace compilation aggregates and orders exact sparse events",
          "[c10][unit]") {
  const auto catalog = make_catalog();
  auto trace = authored_trace({
      trace_event(mwperf::BigNat(2U), text_queue("q0"), mwperf::BigNat(4U),
                  0U),
      trace_event(mwperf::BigNat(0U), text_queue("q1"), mwperf::BigNat(1U),
                  1U),
      trace_event(mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(2U),
                  2U),
      trace_event(mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(3U),
                  3U),
  });

  auto compiled = mwperf::compile_deterministic_trace(trace, catalog);
  REQUIRE(compiled);
  const auto events = compiled.value().events();
  REQUIRE(events.size() == 3U);
  CHECK(events[0U].slot == mwperf::BigNat(0U));
  CHECK(events[0U].queue.ordinal() == 0U);
  CHECK(events[0U].count == mwperf::BigNat(5U));
  CHECK(events[1U].slot == mwperf::BigNat(0U));
  CHECK(events[1U].queue.ordinal() == 1U);
  CHECK(events[1U].count == mwperf::BigNat(1U));
  CHECK(events[2U].slot == mwperf::BigNat(2U));
  CHECK(events[2U].queue.ordinal() == 0U);
  CHECK(events[2U].count == mwperf::BigNat(4U));
  const std::array<std::uint8_t, 3U> expected_support{1U, 1U, 0U};
  CHECK(std::ranges::equal(compiled.value().positive_support_bytes(),
                           expected_support));
}

TEST_CASE("C10 trace slot zero is the physical late-admission batch A(1)",
          "[c10][unit]") {
  const auto catalog = make_catalog();
  const auto trace = authored_trace({
      trace_event(mwperf::BigNat(2U), text_queue("q0"), mwperf::BigNat(4U),
                  0U),
      trace_event(mwperf::BigNat(0U), text_queue("q1"), mwperf::BigNat(1U),
                  1U),
      trace_event(mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(2U),
                  2U),
      trace_event(mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(3U),
                  3U),
  });
  const auto law = publish_trace(trace, catalog);
  auto process = make_process(law);
  const auto before = snapshot(process);
  REQUIRE(before.rng.consumed_words().is_zero());

  auto zero = mwperf::next_trace_batch(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  CHECK(zero.value().authored_slot == mwperf::BigNat(0U));
  CHECK(zero.value().physical_arrival_epoch() == mwperf::BigNat(1U));
  REQUIRE(zero.value().batch.entries().size() == 2U);
  CHECK(zero.value().batch.entries()[0U].queue.ordinal() == 0U);
  CHECK(zero.value().batch.entries()[0U].count == mwperf::BigNat(5U));
  CHECK(zero.value().batch.entries()[1U].queue.ordinal() == 1U);
  CHECK(zero.value().batch.entries()[1U].count == mwperf::BigNat(1U));
  CHECK(mwperf::arrival_phase_family(zero.value().phase_before) ==
        mwperf::ArrivalFamily::deterministic_trace);
  CHECK(mwperf::arrival_phases_share_cursor(zero.value().phase_before,
                                             zero.value().phase_after));
  CHECK_FALSE(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(zero.value().phase_before),
      mwperf::arrival_phase_canonical_state(zero.value().phase_after)));

  auto one = mwperf::next_trace_batch(process, mwperf::BigNat(1U));
  REQUIRE(one);
  CHECK(one.value().batch.empty_batch());
  auto two = mwperf::next_trace_batch(process, mwperf::BigNat(2U));
  REQUIRE(two);
  REQUIRE(two.value().batch.entries().size() == 1U);
  CHECK(two.value().batch.entries()[0U].count == mwperf::BigNat(4U));
  auto three = mwperf::next_trace_batch(process, mwperf::BigNat(3U));
  REQUIRE(three);
  CHECK(three.value().batch.empty_batch());
  auto four = mwperf::next_trace_batch(process, mwperf::BigNat(4U));
  REQUIRE(four);
  CHECK(four.value().batch.empty_batch());

  const auto after = snapshot(process);
  CHECK(after.expected_slot == mwperf::BigNat(5U));
  CHECK(after.rng.consumed_words().is_zero());
  CHECK(after.rng.state_words() == before.rng.state_words());
}

TEST_CASE("C10 empty and exhausted traces remain sequential zero processes",
          "[c10][unit]") {
  const auto catalog = make_catalog();
  const auto law = publish_trace(authored_trace({}), catalog);
  const auto capabilities = mwperf::arrival_capabilities(law);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());

  const auto support = mwperf::positive_arrival_support(law);
  CHECK(support.bytes() == std::vector<std::uint8_t>{0U, 0U, 0U});
  auto process = make_process(law, 22U);
  for (std::uint64_t slot = 0U; slot < 8U; ++slot) {
    auto step = mwperf::next_trace_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(step.value().batch.empty_batch());
  }
  CHECK(snapshot(process).rng.consumed_words().is_zero());
}

TEST_CASE("C10 trace sequential failures do not advance cursor or RNG",
          "[c10][unit][negative]") {
  const auto catalog = make_catalog();
  const auto law = publish_trace(
      authored_trace({trace_event(mwperf::BigNat(1U), text_queue("q0"),
                                  mwperf::BigNat(1U), 0U)}),
      catalog);
  auto process = make_process(law, 23U);

  const auto origin = snapshot(process);
  auto skipped_first =
      mwperf::next_trace_batch(process, mwperf::BigNat(1U));
  REQUIRE_FALSE(skipped_first);
  CHECK(skipped_first.error().code == "nonsequential_arrival_access");
  check_snapshot_equal(snapshot(process), origin);

  auto zero = mwperf::next_trace_batch(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  const auto after_zero = snapshot(process);
  auto repeated = mwperf::next_trace_batch(process, mwperf::BigNat(0U));
  REQUIRE_FALSE(repeated);
  CHECK(repeated.error().code == "nonsequential_arrival_access");
  check_snapshot_equal(snapshot(process), after_zero);
  auto skipped = mwperf::next_trace_batch(process, mwperf::BigNat(2U));
  REQUIRE_FALSE(skipped);
  CHECK(skipped.error().code == "nonsequential_arrival_access");
  check_snapshot_equal(snapshot(process), after_zero);

  auto one = mwperf::next_trace_batch(process, mwperf::BigNat(1U));
  REQUIRE(one);
  REQUIRE(one.value().batch.entries().size() == 1U);
  CHECK(snapshot(process).rng.consumed_words().is_zero());
}

TEST_CASE("C10 trace validates initial family queue IDs and positive counts",
          "[c10][unit][negative]") {
  const auto catalog = make_catalog();
  const auto valid_trace = authored_trace({trace_event(
      mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(1U), 0U)});
  const auto law = publish_trace(valid_trace, catalog);
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(24U));
  REQUIRE(stream);
  auto wrong_initial = mwperf::instantiate_arrival_process(
      law, mwperf::ArrivalInitialState{mwperf::GlobalPeriodicOrigin{}},
      std::move(stream).value());
  REQUIRE_FALSE(wrong_initial);
  CHECK(wrong_initial.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(wrong_initial.error().code ==
        "arrival_initial_family_mismatch");

  auto unknown = mwperf::compile_deterministic_trace(
      authored_trace({trace_event(mwperf::BigNat(0U), text_queue("missing"),
                                  mwperf::BigNat(1U), 0U)}),
      catalog);
  REQUIRE_FALSE(unknown);
  CHECK(unknown.error().code == "unknown_queue_reference");
  CHECK(unknown.error().json_pointer ==
        std::optional<std::string>{"/arrival/events/0/queue_id"});

  auto zero = mwperf::compile_deterministic_trace(
      authored_trace({trace_event(mwperf::BigNat(0U), text_queue("q0"),
                                  mwperf::BigNat(0U), 0U)}),
      catalog);
  REQUIRE_FALSE(zero);
  CHECK(zero.error().code == "arrival_atom_zero_count");
}

TEST_CASE("C10 trace duplicate overflow is rejected at common aggregation",
          "[c10][unit][negative]") {
  const auto catalog = make_catalog();
  const auto maximum = static_cast<std::uint64_t>(
      std::numeric_limits<std::int64_t>::max());
  auto exact_maximum = mwperf::compile_deterministic_trace(
      authored_trace({trace_event(mwperf::BigNat(0U), text_queue("q0"),
                                  mwperf::BigNat(maximum), 0U)}),
      catalog);
  REQUIRE(exact_maximum);
  REQUIRE(exact_maximum.value().events().size() == 1U);
  CHECK(exact_maximum.value().events()[0U].count == mwperf::BigNat(maximum));

  auto overflow = mwperf::compile_deterministic_trace(
      authored_trace({
          trace_event(mwperf::BigNat(0U), text_queue("q0"),
                      mwperf::BigNat(maximum), 0U),
          trace_event(mwperf::BigNat(0U), text_queue("q0"),
                      mwperf::BigNat(1U), 1U),
      }),
      catalog);
  REQUIRE_FALSE(overflow);
  CHECK(overflow.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(overflow.error().code == "arrival_count_overflow");
}

#if defined(MWPERF_C10_TEST_SEAMS)
TEST_CASE("C10 trace rejects a stale unconsumed cursor event",
          "[c10][unit][negative]") {
  const auto catalog = make_catalog();
  auto compiled = mwperf::compile_deterministic_trace(
      authored_trace({trace_event(mwperf::BigNat(0U), text_queue("q0"),
                                  mwperf::BigNat(1U), 0U)}),
      catalog);
  REQUIRE(compiled);

  auto origin = mwperf::testing::validate_trace_cursor_state_for_testing(
      compiled.value(), mwperf::BigNat(0U), 0U, false);
  REQUIRE(origin);
  auto stale = mwperf::testing::validate_trace_cursor_state_for_testing(
      compiled.value(), mwperf::BigNat(1U), 0U, false);
  REQUIRE_FALSE(stale);
  CHECK(stale.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(stale.error().code == "trace_cursor_state_invariant_failure");
  CHECK(stale.error().message.find("stale unconsumed event") !=
        std::string::npos);
}
#endif

TEST_CASE("C10 trace keeps numeric and textual queue identities distinct",
          "[c10][unit]") {
  const auto catalog =
      make_catalog({numeric_queue(1U), text_queue("1")});
  auto compiled = mwperf::compile_deterministic_trace(
      authored_trace({
          trace_event(mwperf::BigNat(0U), text_queue("1"),
                      mwperf::BigNat(2U), 0U),
          trace_event(mwperf::BigNat(0U), numeric_queue(1U),
                      mwperf::BigNat(3U), 1U),
      }),
      catalog);
  REQUIRE(compiled);
  REQUIRE(compiled.value().events().size() == 2U);
  CHECK(compiled.value().events()[0U].queue.ordinal() == 0U);
  CHECK(compiled.value().events()[0U].count == mwperf::BigNat(3U));
  CHECK(compiled.value().events()[1U].queue.ordinal() == 1U);
  CHECK(compiled.value().events()[1U].count == mwperf::BigNat(2U));
}

TEST_CASE("C10 trace storage depends on sparse entries and exact bit lengths",
          "[c10][unit]") {
  const auto catalog = make_catalog();
  const mwperf::BigNat far_future = huge_slot();
  auto compiled = mwperf::compile_deterministic_trace(
      authored_trace({trace_event(far_future, text_queue("q2"),
                                  mwperf::BigNat(7U), 0U)}),
      catalog);
  REQUIRE(compiled);
  REQUIRE(compiled.value().events().size() == 1U);
  CHECK(compiled.value().events()[0U].slot == far_future);
  // 2^4096 needs 513 magnitude bytes.  A period/max-slot-sized allocation
  // would be impossible; this bound confirms only the canonical encoding was
  // retained.
  CHECK(compiled.value().canonical_law_data().size() < 1024U);
}

TEST_CASE("C10 trace canonicalization is invariant under authored row order",
          "[c10][property]") {
  const auto catalog = make_catalog();
  const std::array<mwperf::TraceEvent, 4U> base{
      trace_event(mwperf::BigNat(3U), text_queue("q2"), mwperf::BigNat(2U),
                  0U),
      trace_event(mwperf::BigNat(0U), text_queue("q0"), mwperf::BigNat(1U),
                  1U),
      trace_event(mwperf::BigNat(3U), text_queue("q2"), mwperf::BigNat(5U),
                  2U),
      trace_event(mwperf::BigNat(1U), text_queue("q1"), mwperf::BigNat(4U),
                  3U),
  };
  auto reference = mwperf::compile_deterministic_trace(
      authored_trace(std::vector<mwperf::TraceEvent>(base.begin(),
                                                     base.end())),
      catalog);
  REQUIRE(reference);
  const std::vector<std::byte> reference_bytes(
      reference.value().canonical_law_data().begin(),
      reference.value().canonical_law_data().end());
  const std::vector<mwperf::ExactTraceEvent> reference_events(
      reference.value().events().begin(), reference.value().events().end());

  std::array<std::size_t, 4U> order{0U, 1U, 2U, 3U};
  std::size_t permutations = 0U;
  do {
    std::vector<mwperf::TraceEvent> permuted;
    for (const std::size_t index : order) {
      permuted.push_back(base[index]);
    }
    auto compiled = mwperf::compile_deterministic_trace(
        authored_trace(std::move(permuted)), catalog);
    REQUIRE(compiled);
    CHECK(std::ranges::equal(compiled.value().canonical_law_data(),
                             reference_bytes));
    CHECK(std::ranges::equal(compiled.value().events(), reference_events));
    ++permutations;
  } while (std::ranges::next_permutation(order).found);
  CHECK(permutations == 24U);
}

TEST_CASE("C10 trace equal stream keys replay exactly without draws",
          "[c10][property]") {
  const auto catalog = make_catalog();
  const auto law = publish_trace(
      authored_trace({
          trace_event(mwperf::BigNat(0U), text_queue("q0"),
                      mwperf::BigNat(2U), 0U),
          trace_event(mwperf::BigNat(3U), text_queue("q2"),
                      mwperf::BigNat(5U), 1U),
      }),
      catalog);
  auto first = make_process(law, 101U);
  auto second = make_process(law, 101U);
  for (std::uint64_t slot = 0U; slot < 7U; ++slot) {
    auto left = mwperf::next_trace_batch(first, mwperf::BigNat(slot));
    auto right = mwperf::next_trace_batch(second, mwperf::BigNat(slot));
    REQUIRE(left);
    REQUIRE(right);
    CHECK(left.value().authored_slot == right.value().authored_slot);
    CHECK(left.value().batch == right.value().batch);
    CHECK(std::ranges::equal(
        mwperf::arrival_phase_canonical_state(left.value().phase_before),
        mwperf::arrival_phase_canonical_state(right.value().phase_before)));
    CHECK(std::ranges::equal(
        mwperf::arrival_phase_canonical_state(left.value().phase_after),
        mwperf::arrival_phase_canonical_state(right.value().phase_after)));
    CHECK(left.value().realization_identity ==
          right.value().realization_identity);
  }
  CHECK(snapshot(first).rng.consumed_words().is_zero());
  CHECK(snapshot(second).rng.consumed_words().is_zero());
}
