#include <atomic>
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/sampling/conditional_generator.hpp"
#include "sampling/c24_internal.hpp"

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix =
    mwperf::testing::c16_registered_pair_matrix;

struct SealedSamplerFixture final {
  mwperf::AuditedCompiledFramework framework;
  mwperf::NormalizedSamplerAccess sampler;
  mwperf::ConditioningState row;
};

[[nodiscard]] SealedSamplerFixture seal_sampler(
    const matrix::C17TemporalFixtureOverrideV1& override) {
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  const mwperf::ConditioningState row = prepared.initial_state;
  auto framework_result = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework_result ? std::string{}
                         : framework_result.error().code + ": " +
                               framework_result.error().message));
  REQUIRE(framework_result);
  auto framework = std::move(framework_result).value();
  auto descriptor = mwperf::audited_sampler_descriptor(framework);
  INFO((descriptor ? std::string{}
                   : descriptor.error().code + ": " +
                         descriptor.error().message));
  REQUIRE(descriptor);
  auto sampler =
      mwperf::validate_conditional_generator(descriptor.value());
  INFO((sampler ? std::string{}
                : sampler.error().code + ": " + sampler.error().message));
  REQUIRE(sampler);
  return {std::move(framework), std::move(sampler).value(), row};
}

[[nodiscard]] mwperf::RngBank make_bank(
    const SealedSamplerFixture& fixture,
    const std::string_view estimator_id = "c24.unit.draw",
    const std::uint64_t replication = 0U,
    const mwperf::StageTag stage = mwperf::StageTag::generic_sampling) {
  auto row_digest =
      mwperf::sampling::detail::conditioning_state_digest(fixture.row);
  REQUIRE(row_digest);
  auto bank = mwperf::sampling::detail::C24RngAccess::make(
      fixture.sampler.seal_digest(), row_digest.value(), estimator_id,
      mwperf::BigNat{replication}, mwperf::MasterSeed{0xC2401U},
      stage);
  INFO((bank ? std::string{}
             : bank.error().code + ": " + bank.error().message));
  REQUIRE(bank);
  return std::move(bank).value();
}

[[nodiscard]] mwperf::KernelTransitionV1 shaped_sample(
    const mwperf::ConditioningState& state, const std::byte value) {
  const mwperf::CodecIdentityV1 mark_codec{
      "mwperf.c23.typed_label", 1U};
  return {state,
          {{mark_codec, {value}},
           {mark_codec, {value}},
           {mark_codec, {value}}}};
}

[[nodiscard]] mwperf::ConditionalSamplerContractV1 sampler_contract(
    const std::string_view prefix, const std::size_t support_size) {
  const auto keyed = [prefix](const std::string_view suffix) {
    return matrix::digest(std::string(prefix) + "." + std::string(suffix));
  };
  return {1U,
          mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
          mwperf::ConditionalSampleDependenceV1::iid_cold_replications,
          mwperf::ConditionalSupportKindV1::finite_declared,
          support_size,
          matrix::digest("c17.fixture.reduced-state-schema"),
          keyed("support"),
          keyed("proposal"),
          keyed("residual"),
          keyed("output"),
          keyed("arrival"),
          keyed("common"),
          true,
          true,
          true,
          true,
          true,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerV1EvidenceScopeV1::none,
          std::nullopt,
          mwperf::SamplerV2EvidenceScopeV1::none,
          std::nullopt,
          std::nullopt};
}

[[nodiscard]] matrix::C17TemporalFixtureOverrideV1 two_atom_override(
    const mwperf::ConditionalSamplerRevealStageV1 reveal_stage) {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_sampler_contract =
      sampler_contract("c24.generator.two-atom", 2U);
  override.conditional_sampler_contract->reveal_stage = reveal_stage;
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            shaped_sample(state, static_cast<std::byte>(rng.next_u64() & 1U)));
      };
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            {shaped_sample(state, std::byte{0x00}),
             shaped_sample(state, std::byte{0x01})});
      };
  override.conditional_support_query =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<bool>::success(
            sample == shaped_sample(state, std::byte{0x00}) ||
            sample == shaped_sample(state, std::byte{0x01}));
      };
  return override;
}

}  // namespace

static_assert(!std::is_default_constructible_v<
              mwperf::AuditedSamplerDescriptor>);
static_assert(!std::is_default_constructible_v<
              mwperf::NormalizedSamplerAccess>);
static_assert(!std::is_constructible_v<mwperf::NormalizedSamplerAccess,
                                       mwperf::KernelAccess>);

TEST_CASE("C24 validates a real C17-sealed conditional sampler without probing it",
          "[c24][unit][generator][seal]") {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto fixture = seal_sampler(override);

  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
  CHECK(fixture.sampler.contract().normalized_probability_law);
  CHECK(fixture.sampler.contract().almost_sure_return);
  CHECK(fixture.sampler.contract().persistent_memory_is_explicit);
  CHECK(fixture.sampler.contract().no_hidden_warm_state);
  CHECK(fixture.sampler.contract().dependence ==
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
  CHECK(fixture.sampler.contract().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::deployed_generator);
  CHECK_FALSE(fixture.sampler.target_density_ratio_available());
  CHECK_FALSE(fixture.sampler.exact_innovation_available());

  auto bank = make_bank(fixture);
  auto sample = mwperf::draw_conditional_sample(
      fixture.sampler, fixture.row, bank);
  INFO((sample ? std::string{}
               : sample.error().code + ": " + sample.error().message));
  REQUIRE(sample);
  CHECK(sample.value().successor_state == fixture.row);
  CHECK(sample.value().ordered_marks.size() == 3U);
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 1U);

  const auto replay = mwperf::draw_conditional_sample(
      fixture.sampler, fixture.row, bank);
  REQUIRE_FALSE(replay);
  CHECK(replay.error().code == "c24.estimator_rng_bank_reused");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 1U);
}

TEST_CASE("C17 rejects a sampler bound to a foreign configured arrival without drawing",
          "[c24][negative][generator][arrival-binding]") {
  auto override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  override.conditional_sampler_contract->configured_arrival_law =
      matrix::digest("c24.generator.foreign-configured-arrival");
  override.preserve_authored_conditional_sampler_arrival_binding = true;

  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  const auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  REQUIRE_FALSE(sealed);
  CHECK(sealed.error().code ==
        "c17.sampler_configured_arrival_binding_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 rejects bad row and seal bindings before sampler dispatch",
          "[c24][negative][generator][transactional]") {
  matrix::C17TemporalFixtureOverrideV1 first_override;
  first_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto first = seal_sampler(first_override);

  mwperf::ConditioningState wrong_row = first.row;
  wrong_row.codec = {"c24.wrong-row", 1U};
  auto bank = make_bank(first, "c24.unit.binding");
  const auto wrong = mwperf::draw_conditional_sample(
      first.sampler, wrong_row, bank);
  REQUIRE_FALSE(wrong);
  CHECK(wrong.error().code == "c24.conditioning_state_codec_mismatch");
  CHECK(first_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  // A rejected row does not consume the one-shot bank.
  REQUIRE(mwperf::draw_conditional_sample(first.sampler, first.row, bank));
  CHECK(first_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 1U);

  matrix::C17TemporalFixtureOverrideV1 second_override;
  second_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  second_override.conditional_sampler_contract =
      sampler_contract("c24.foreign-seal", 1U);
  auto second = seal_sampler(second_override);
  auto foreign_bank = make_bank(first, "c24.unit.foreign-seal", 1U);
  const auto foreign = mwperf::draw_conditional_sample(
      second.sampler, second.row, foreign_bank);
  REQUIRE_FALSE(foreign);
  CHECK(foreign.error().code == "c24.invalid_estimator_rng_bank");
  CHECK(second_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 turns each malformed, unsupported, or throwing draw into one failure",
          "[c24][negative][generator][failure]") {
  SECTION("malformed output shape") {
    matrix::C17TemporalFixtureOverrideV1 override;
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              {state, {}});
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture, "c24.unit.malformed");
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c24.malformed_sample_shape");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }

  SECTION("atom outside declared support") {
    matrix::C17TemporalFixtureOverrideV1 override;
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              shaped_sample(state, std::byte{0x02}));
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture, "c24.unit.unsupported");
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c24.sample_outside_declared_support");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }

  SECTION("callback exception") {
    matrix::C17TemporalFixtureOverrideV1 override;
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1&,
           mwperf::DeterministicRng&)
            -> mwperf::Result<mwperf::KernelTransitionV1> {
          throw std::runtime_error("c24 test draw failure");
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture, "c24.unit.throw");
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c24.sample_operation_exception");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }

  SECTION("typed timeout failure") {
    matrix::C17TemporalFixtureOverrideV1 override;
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1&,
           mwperf::DeterministicRng&)
            -> mwperf::Result<mwperf::KernelTransitionV1> {
          return mwperf::Result<mwperf::KernelTransitionV1>::failure(
              {mwperf::DiagnosticCategory::resource_limit,
               "c24.fixture.timeout",
               "the fixture generator reached its authored runtime limit",
               std::nullopt, std::nullopt, {}});
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture, "c24.unit.timeout");
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c24.fixture.timeout");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);

    const auto retry = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(retry);
    CHECK(retry.error().code == "c24.estimator_rng_bank_reused");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }
}

TEST_CASE("C24 audits the exact declared support on every finite-support draw",
          "[c24][negative][generator][support]") {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_sampler_contract =
      sampler_contract("c24.support", 2U);
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng&) {
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            shaped_sample(state, std::byte{0x01}));
      };
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        const auto duplicate = shaped_sample(state, std::byte{0x01});
        return mwperf::Result<std::vector<mwperf::KernelTransitionV1>>::success(
            {duplicate, duplicate});
      };
  auto fixture = seal_sampler(override);
  auto bank = make_bank(fixture, "c24.unit.duplicate-support");
  const auto result = mwperf::draw_conditional_sample(
      fixture.sampler, fixture.row, bank);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c24.invalid_declared_finite_support");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 1U);
}

TEST_CASE("C24 replay is cold within a stage and domain-separated across stages",
          "[c24][unit][generator][replay]") {
  auto pre_override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::prearrival_residual);
  auto post_override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::postarrival_residual);
  auto pre = seal_sampler(pre_override);
  auto post = seal_sampler(post_override);

  const auto sequence = [](const SealedSamplerFixture& fixture,
                           const mwperf::StageTag stage) {
    std::vector<std::byte> values;
    values.reserve(32U);
    for (std::uint64_t replication = 0U; replication < 32U;
         ++replication) {
      auto bank = make_bank(fixture, "c24.generator.stage-replay",
                            replication, stage);
      auto sample = mwperf::draw_conditional_sample(
          fixture.sampler, fixture.row, bank);
      REQUIRE(sample);
      values.push_back(
          sample.value().ordered_marks.front().canonical_value.front());
    }
    return values;
  };

  const auto pre_first =
      sequence(pre, mwperf::StageTag::prearrival_closure);
  const auto pre_replay =
      sequence(pre, mwperf::StageTag::prearrival_closure);
  const auto post_values =
      sequence(post, mwperf::StageTag::postarrival_closure);
  CHECK(pre_first == pre_replay);
  CHECK(pre_first != post_values);
}

TEST_CASE("C24 copies a value-captured mutable sampler for every cold draw",
          "[c24][unit][generator][cold-replication]") {
  auto override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  override.conditional_sampler_operation =
      [cursor = std::uint8_t{0U}](
          const mwperf::CanonicalRuntimeValueV1& state,
          mwperf::DeterministicRng&) mutable {
        cursor = static_cast<std::uint8_t>((cursor + 1U) & 1U);
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            shaped_sample(state, static_cast<std::byte>(cursor)));
      };
  auto fixture = seal_sampler(override);
  for (std::uint64_t replication = 0U; replication < 8U;
       ++replication) {
    auto bank = make_bank(fixture, "c24.generator.mutable-cold",
                          replication);
    auto sample = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE(sample);
    CHECK(sample.value().ordered_marks.front().canonical_value ==
          std::vector<std::byte>{std::byte{0x01}});
  }
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 8U);
}

TEST_CASE("C17 rejects every unknown sampler contract enum without a draw",
          "[c24][negative][generator][enum]") {
  const auto audit = [](mwperf::ConditionalSamplerContractV1 contract) {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_contract = std::move(contract);
    const matrix::ScopedC17TemporalFixtureOverride guard(override);
    const auto& profile = temporal::temporal_profile(
        mwperf::SemanticTagV1::temporal_one_slot_continuation);
    auto prepared = temporal::prepare_conditional_sampling_framework(
        profile, [](mwperf::ExactCausalProgramV1&) {});
    auto result = mwperf::audit_v0_causality(
        std::move(prepared.candidate), prepared.descriptor,
        std::move(prepared.access));
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c17.incomplete_conditional_sampler_contract");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  };

  SECTION("reveal stage") {
    auto contract = sampler_contract("c24.invalid.reveal", 2U);
    contract.reveal_stage =
        static_cast<mwperf::ConditionalSamplerRevealStageV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("dependence") {
    auto contract = sampler_contract("c24.invalid.dependence", 2U);
    contract.dependence =
        static_cast<mwperf::ConditionalSampleDependenceV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("support kind") {
    auto contract = sampler_contract("c24.invalid.support", 2U);
    contract.support_kind =
        static_cast<mwperf::ConditionalSupportKindV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("normalization evidence") {
    auto contract = sampler_contract("c24.invalid.normalization", 2U);
    contract.normalization_evidence =
        static_cast<mwperf::SamplerEvidenceScopeV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("termination evidence") {
    auto contract = sampler_contract("c24.invalid.termination", 2U);
    contract.termination_evidence =
        static_cast<mwperf::SamplerEvidenceScopeV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("V1 evidence scope") {
    auto contract = sampler_contract("c24.invalid.v1-scope", 2U);
    contract.v1_evidence_scope =
        static_cast<mwperf::SamplerV1EvidenceScopeV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("V2 evidence scope") {
    auto contract = sampler_contract("c24.invalid.v2-scope", 2U);
    contract.v2_evidence_scope =
        static_cast<mwperf::SamplerV2EvidenceScopeV1>(0xffU);
    audit(std::move(contract));
  }
  SECTION("runtime sampling provenance") {
    auto contract = sampler_contract("c24.invalid.provenance", 2U);
    contract.runtime_provenance =
        static_cast<mwperf::RuntimeSamplingProvenanceV1>(0xffU);
    audit(std::move(contract));
  }
}

TEST_CASE("C17 rejects non-probability or nonterminating sampler contracts cold",
          "[c24][negative][generator][contract-evidence]") {
  const auto audit = [](mwperf::ConditionalSamplerContractV1 contract,
                        const std::string_view expected_code) {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_contract = std::move(contract);
    const matrix::ScopedC17TemporalFixtureOverride guard(override);
    const auto& profile = temporal::temporal_profile(
        mwperf::SemanticTagV1::temporal_one_slot_continuation);
    auto prepared = temporal::prepare_conditional_sampling_framework(
        profile, [](mwperf::ExactCausalProgramV1&) {});
    const auto sealed = mwperf::audit_v0_causality(
        std::move(prepared.candidate), prepared.descriptor,
        std::move(prepared.access));

    // A failed V0 result cannot be projected to AuditedSamplerDescriptor;
    // therefore C24 has no handle on which it could execute the callback.
    REQUIRE_FALSE(sealed);
    CHECK(sealed.error().code == expected_code);
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  };

  SECTION("unnormalized output is not a probability law") {
    auto contract = sampler_contract("c24.invalid.unnormalized", 2U);
    contract.normalized_probability_law = false;
    audit(std::move(contract), "c17.incomplete_conditional_sampler_contract");
  }

  SECTION("signed-measure output has no admitted normalized-law witness") {
    // The v1 sampler contract deliberately has no signed-measure runtime
    // representation.  Such a provider is expressible only by withholding the
    // normalized-probability-law affirmation, which V0 must reject.
    auto contract = sampler_contract("c24.invalid.signed-measure", 2U);
    contract.normalized_probability_law = false;
    audit(std::move(contract), "c17.incomplete_conditional_sampler_contract");
  }

  SECTION("almost-sure return is not declared") {
    auto contract = sampler_contract("c24.invalid.no-as-return", 2U);
    contract.almost_sure_return = false;
    audit(std::move(contract), "c17.incomplete_conditional_sampler_contract");
  }

  SECTION("termination evidence is outside the closed evidence vocabulary") {
    // Evidence is a required closed enum rather than an optional field in v1;
    // an unknown value is the schema-level form of missing evidence.
    auto contract = sampler_contract("c24.invalid.no-termination-evidence", 2U);
    contract.termination_evidence =
        static_cast<mwperf::SamplerEvidenceScopeV1>(0xffU);
    audit(std::move(contract), "c17.incomplete_conditional_sampler_contract");
  }
}

TEST_CASE("C17 rejects a multi-target sampler without one common projection",
          "[c24][negative][generator][target-projection]") {
  auto override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  // V1 stores one common-projection identity, so incompatible independently
  // authored target projections are represented by the absence of that one
  // common authority.
  override.conditional_sampler_contract->common_projection_identity.reset();
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  prepared.descriptor.core.deployed_targets.push_back(
      mwperf::QueueId(matrix::label("q1")));
  prepared.descriptor.core.target_coupling =
      mwperf::TargetCouplingV1::common_schedule_projection;
  auto descriptor_digest = mwperf::canonical_plug_descriptor_core_digest_v1(
      prepared.descriptor.core);
  REQUIRE(descriptor_digest);
  prepared.descriptor.core.core_digest =
      std::move(descriptor_digest).value();
  auto runtime_descriptor_digest =
      mwperf::canonical_plug_descriptor_digest_v1(prepared.descriptor);
  REQUIRE(runtime_descriptor_digest);
  prepared.descriptor.descriptor_digest =
      std::move(runtime_descriptor_digest).value();

  const auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  REQUIRE_FALSE(sealed);
  CHECK(sealed.error().code ==
        "c17.missing_common_sampler_projection_identity");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C17 requires a sealed completed-sample validator",
          "[c24][negative][generator][sample-validator]") {
  auto override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  override.suppress_conditional_sample_validator = true;
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  const auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  REQUIRE_FALSE(sealed);
  CHECK(sealed.error().code ==
        "c17.incomplete_conditional_sampler_contract");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C17 binds typed V1 and V2 scopes one-to-one with evidence",
          "[c24][negative][generator][fidelity-evidence]") {
  const auto audit = [](mwperf::ConditionalSamplerContractV1 contract) {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_contract = std::move(contract);
    const matrix::ScopedC17TemporalFixtureOverride guard(override);
    const auto& profile = temporal::temporal_profile(
        mwperf::SemanticTagV1::temporal_one_slot_continuation);
    auto prepared = temporal::prepare_conditional_sampling_framework(
        profile, [](mwperf::ExactCausalProgramV1&) {});
    const auto sealed = mwperf::audit_v0_causality(
        std::move(prepared.candidate), prepared.descriptor,
        std::move(prepared.access));
    REQUIRE_FALSE(sealed);
    CHECK(sealed.error().code ==
          "c17.invalid_sampler_fidelity_evidence_binding");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  };

  SECTION("V1 reference without scope") {
    auto contract = sampler_contract("c24.invalid.v1-reference", 2U);
    contract.v1_evidence_reference = matrix::digest("c24.invalid.v1");
    audit(std::move(contract));
  }
  SECTION("V1 scope without reference") {
    auto contract = sampler_contract("c24.invalid.v1-scope-only", 2U);
    contract.v1_evidence_scope =
        mwperf::SamplerV1EvidenceScopeV1::row_conditional;
    audit(std::move(contract));
  }
  SECTION("V2 reference without scope") {
    auto contract = sampler_contract("c24.invalid.v2-reference", 2U);
    contract.v2_evidence_reference = matrix::digest("c24.invalid.v2");
    audit(std::move(contract));
  }
  SECTION("V2 scope without reference") {
    auto contract = sampler_contract("c24.invalid.v2-scope-only", 2U);
    contract.v2_evidence_scope =
        mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift;
    audit(std::move(contract));
  }
  SECTION("zero V1 reference") {
    auto contract = sampler_contract("c24.invalid.v1-zero", 2U);
    contract.v1_evidence_scope =
        mwperf::SamplerV1EvidenceScopeV1::row_conditional;
    const std::array<std::byte, mwperf::Digest256::kSize> zero_bytes{};
    auto zero_digest = mwperf::Digest256::from_bytes(zero_bytes);
    REQUIRE(zero_digest);
    contract.v1_evidence_reference = std::move(zero_digest).value();
    audit(std::move(contract));
  }
}

TEST_CASE("C17 binds sampler persistence to the exact reduced-state schema",
          "[c24][negative][generator][persistent-schema]") {
  auto override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  override.conditional_sampler_contract->persistent_state_schema =
      matrix::digest("c24.generator.foreign-persistent-schema");
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  const auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  REQUIRE_FALSE(sealed);
  CHECK(sealed.error().code ==
        "c17.sampler_persistent_state_schema_mismatch");
  CHECK(override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C24 validates conditioning and successor states in the sealed domain",
          "[c24][negative][generator][state-domain]") {
  SECTION("conditioning state is rejected before RNG or callback use") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    auto fixture = seal_sampler(override);
    auto invalid = fixture.row;
    invalid.canonical_value.push_back(std::byte{0x7f});
    auto bank = make_bank(fixture);
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, invalid, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.conditioning_state_outside_sealed_domain");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 0U);
  }

  SECTION("sampled successor is rejected before support dispatch") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          auto invalid = state;
          invalid.canonical_value.push_back(std::byte{0x7f});
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              shaped_sample(invalid, std::byte{0x00}));
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture);
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.successor_state_outside_sealed_domain");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }

  SECTION("an unseen invalid finite-support successor is audited") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              shaped_sample(state, std::byte{0x00}));
        };
    override.conditional_support_enumerator =
        [](const mwperf::CanonicalRuntimeValueV1& state) {
          auto invalid = state;
          invalid.canonical_value.push_back(std::byte{0x7f});
          return mwperf::Result<
              std::vector<mwperf::KernelTransitionV1>>::success(
              {shaped_sample(state, std::byte{0x00}),
               shaped_sample(invalid, std::byte{0x01})});
        };
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture);
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c24.successor_state_outside_sealed_domain");
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  }
}

TEST_CASE("C24 rejects semantic sample violations before publication",
          "[c24][negative][generator][sample-validator]") {
  const auto draw_invalid = [](
                                matrix::C17TemporalFixtureOverrideV1 override,
                                const std::string_view expected_code) {
    auto fixture = seal_sampler(override);
    auto bank = make_bank(fixture);
    const auto result = mwperf::draw_conditional_sample(
        fixture.sampler, fixture.row, bank);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == expected_code);
    CHECK(override.conditional_sampler_calls->load(
              std::memory_order_relaxed) == 1U);
  };

  SECTION("mark value domain") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          auto sample = shaped_sample(state, std::byte{0x00});
          sample.ordered_marks.front().canonical_value.clear();
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              std::move(sample));
        };
    draw_invalid(std::move(override),
                 "c24.fixture.sample_mark_outside_value_domain");
  }

  SECTION("exact-coordinate ownership and update") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          auto successor = state;
          successor.canonical_value.front() ^= std::byte{0x01};
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              shaped_sample(successor, std::byte{0x00}));
        };
    draw_invalid(std::move(override),
                 "c24.fixture.exact_coordinate_update_violation");
  }

  SECTION("common projection") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          auto sample = shaped_sample(state, std::byte{0x00});
          sample.ordered_marks.back().canonical_value = {std::byte{0x01}};
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              std::move(sample));
        };
    draw_invalid(std::move(override),
                 "c24.fixture.common_projection_violation");
  }

  SECTION("every finite support atom is validated") {
    auto override = two_atom_override(
        mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng&) {
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              shaped_sample(state, std::byte{0x00}));
        };
    override.conditional_support_enumerator =
        [](const mwperf::CanonicalRuntimeValueV1& state) {
          auto invalid = shaped_sample(state, std::byte{0x01});
          invalid.ordered_marks.front().canonical_value.clear();
          return mwperf::Result<
              std::vector<mwperf::KernelTransitionV1>>::success(
              {shaped_sample(state, std::byte{0x00}),
               std::move(invalid)});
        };
    draw_invalid(std::move(override),
                 "c24.fixture.sample_mark_outside_value_domain");
  }
}

TEST_CASE("C17 seal identity encodes typed runtime sampling provenance",
          "[c24][unit][generator][provenance][identity]") {
  auto physical_override = two_atom_override(
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual);
  physical_override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::physical_trace;
  auto modified_override = physical_override;
  modified_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  modified_override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::modified_compatible_state;

  const auto physical = seal_sampler(physical_override);
  const auto modified = seal_sampler(modified_override);
  CHECK(physical.sampler.contract().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::physical_trace);
  CHECK(modified.sampler.contract().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::modified_compatible_state);
  CHECK(physical.sampler.seal_digest() != modified.sampler.seal_digest());
  CHECK(physical_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
  CHECK(modified_override.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
}
