#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/stationary/flux.hpp"
#include "support/c16_designated_payload_fixture.hpp"

namespace {

using mwperf::BoundaryCompletionKindV1;
using mwperf::C18ExactMatrixFixtureV1;
using mwperf::ClassDecomposition;
using mwperf::CompletionBoundMarkedAtomV1;
using mwperf::CompletionBoundMarkedRowV1;
using mwperf::ExactRational;
using mwperf::InvariantLaw;
using mwperf::LinearMethod;
using mwperf::MarkedFluxEdgeV1;
using mwperf::ReducedStateV1;
using mwperf::SelectionSpec;
using mwperf::SolverPolicy;
using mwperf::SourceLocation;
using mwperf::SourceNode;
using mwperf::StationaryClassSelection;
using mwperf::StationaryMixtureComponent;
using mwperf::StationaryMixtureSelection;
using mwperf::StationaryUniqueSelection;
using mwperf::TransitionMatrix;

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto value = mwperf::sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] SourceNode source(const std::string& pointer = "/c18-test") {
  return SourceNode::make_null(
      SourceLocation{"c18-stationary-test", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] ReducedStateV1 state(const std::uint8_t ordinal) {
  return {{"c18.test.reduced-state", 1U},
          {std::byte{1U}, static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 absorbing_phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::shared_joint_round_markov_renewal,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::TypedLabel class_id(const std::uint64_t ordinal) {
  return mwperf::TypedLabel::numeric(mwperf::BigNat{ordinal});
}

[[nodiscard]] mwperf::RuntimeMarkIdV1 mark_id(const std::string& name) {
  auto label = mwperf::TypedLabel::text(name);
  REQUIRE(label);
  return mwperf::RuntimeMarkIdV1(std::move(label).value());
}

[[nodiscard]] mwperf::CausalMarkV1 causal_mark(
    const mwperf::RuntimeMarkIdV1& id,
    const mwperf::CodecIdentityV1& codec,
    const mwperf::CausalStageV1 stage, const std::uint8_t value) {
  return {{id, {codec, {static_cast<std::byte>(value)}}}, stage};
}

[[nodiscard]] SelectionSpec unique_selection() {
  return StationaryUniqueSelection{source("/selection/unique")};
}

[[nodiscard]] SelectionSpec class_selection(const std::uint64_t ordinal) {
  return StationaryClassSelection{class_id(ordinal),
                                  source("/selection/class")};
}

[[nodiscard]] mwperf::AuthoredProbability probability(
    const ExactRational& value) {
  auto result = mwperf::AuthoredProbability::from_exact(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SelectionSpec mixture_selection(
    const ExactRational& first, const ExactRational& second,
    const std::optional<std::uint64_t> second_class = 1U) {
  std::vector<StationaryMixtureComponent> components;
  components.push_back({class_id(0U), probability(first),
                        source("/selection/mixture/0")});
  components.push_back({class_id(*second_class), probability(second),
                        source("/selection/mixture/1")});
  return StationaryMixtureSelection{
      std::move(components), source("/selection/mixture")};
}

[[nodiscard]] SolverPolicy policy(const std::string& identity = "default",
                                  const ExactRational& tolerance =
                                      rational(1, 1000000000000000LL)) {
  return {LinearMethod::dense_pivoted, std::nullopt, tolerance,
          ExactRational::zero(), digest("c18.policy." + identity)};
}

struct BoundInstanceFixtureV1 final {
  mwperf::ResolvedInstance instance;
  mwperf::CompiledArrivalLaw configured_arrival;
  mwperf::TargetSelection target_selection;
  std::vector<mwperf::ArrivalPhaseIdentityV1> configured_phases;
  std::vector<ExactRational> configured_phase_masses;
};

[[nodiscard]] mwperf::TargetSelection target_selection(
    const mwperf::ResolvedInstance& instance) {
  std::vector<mwperf::QueueId> targets;
  targets.reserve(instance.targets().size());
  for (const auto& target : instance.targets().values()) {
    targets.push_back(instance.queues().queue_id(target.queue));
  }
  auto group = mwperf::TypedLabel::text("c18.unit.target-selection");
  REQUIRE(group);
  return {1U, std::move(targets),
          mwperf::ConstructionGroupIdV1(std::move(group).value())};
}

[[nodiscard]] std::pair<
    std::vector<mwperf::ArrivalPhaseIdentityV1>,
    std::vector<ExactRational>>
configured_phase_law(const mwperf::CompiledArrivalLaw& arrival) {
  const auto view = mwperf::builder_arrival_view(arrival);
  std::vector<mwperf::ArrivalPhaseIdentityV1> phases;
  std::vector<ExactRational> masses;
  if (view.stationary_phase_law().has_value()) {
    const auto& law = *view.stationary_phase_law();
    REQUIRE(law.canonical_states.size() ==
            law.probabilities.normalized_weights().size());
    for (std::size_t index = 0U; index < law.canonical_states.size();
         ++index) {
      phases.push_back({arrival.family(), law.canonical_states[index]});
      masses.push_back(law.probabilities.normalized_weights()[index]);
    }
  }
  return {std::move(phases), std::move(masses)};
}

[[nodiscard]] BoundInstanceFixtureV1 bound_instance(
    const std::string_view arrival, const std::string_view selection) {
  const std::string model = std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":18,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":)json") +
                            std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c18.fixture.bound","version":null,
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":1e-15,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json") +
                               std::string(selection) + R"json(,
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c18-unit-model", model));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c18-unit-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto resolved = mwperf::resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      mwperf::fingerprint_inputs(canonical));
  REQUIRE(resolved);
  mwperf::ResolvedInstance instance = std::move(resolved).value();
  auto compiled =
      mwperf::detail::CompiledArrivalAccess::get(instance.arrival());
  REQUIRE(compiled);
  mwperf::CompiledArrivalLaw configured_arrival = *compiled.value();
  auto phases = configured_phase_law(configured_arrival);
  auto targets = target_selection(instance);
  return {std::move(instance), std::move(configured_arrival),
          std::move(targets), std::move(phases.first),
          std::move(phases.second)};
}

[[nodiscard]] BoundInstanceFixtureV1 deterministic_bound_instance() {
  return bound_instance(
      R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
      R"json({"kind":"stationary_unique","parameters":{}})json");
}

[[nodiscard]] BoundInstanceFixtureV1 two_phase_bound_instance() {
  return bound_instance(
      R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
      R"json({"kind":"stationary_mixture","parameters":{"components":[{"class_id":0,"probability":0.5},{"class_id":1,"probability":0.5}]}})json");
}

[[nodiscard]] SolverPolicy bound_policy(
    const mwperf::ResolvedInstance& instance) {
  REQUIRE(instance.analysis_spec().context);
  const auto& context = *instance.analysis_spec().context;
  const auto* enumerated = std::get_if<mwperf::EnumeratedSolver>(
      &context.solver);
  REQUIRE(enumerated != nullptr);
  REQUIRE(context.resolution.tolerance.linear_residual_abs.has_value());
  return {enumerated->linear_method, enumerated->max_iterations,
          *context.resolution.tolerance.linear_residual_abs,
          ExactRational::zero(), instance.fingerprints().analysis};
}

[[nodiscard]] MarkedFluxEdgeV1 edge(const ReducedStateV1& from,
                                    const ReducedStateV1& to,
                                    const std::uint8_t phase_from,
                                    const std::uint8_t phase_to,
                                    const std::uint8_t departure = 0U,
                                    const std::uint64_t arrival = 0U,
                                    const std::uint64_t backlog = 1U) {
  return {from,
          to,
          {mwperf::BigNat{backlog}},
          {departure},
          {mwperf::BigNat{arrival}},
          phase(phase_from),
          phase(phase_to),
          {}};
}

[[nodiscard]] C18ExactMatrixFixtureV1 fixture(
    std::vector<ReducedStateV1> states,
    std::vector<ExactRational> entries, SelectionSpec selection,
    SolverPolicy solver,
    std::optional<std::vector<long double>> numerical_entries = std::nullopt,
    std::optional<std::vector<CompletionBoundMarkedRowV1>> rows =
        std::nullopt,
    const BoundaryCompletionKindV1 completion =
        BoundaryCompletionKindV1::exact_closed,
    std::optional<mwperf::Digest256> completion_identity = std::nullopt,
    const bool physical_mark_preserving = true,
    std::optional<mwperf::ResolvedInstance> bound_instance = std::nullopt,
    std::optional<mwperf::CompiledArrivalLaw> bound_configured_arrival =
        std::nullopt,
    std::optional<mwperf::TargetSelection> bound_target_selection =
        std::nullopt,
    std::vector<mwperf::ArrivalPhaseIdentityV1> configured_phases = {},
    std::vector<ExactRational> configured_phase_masses = {},
    std::optional<std::vector<ExactRational>> configured_phase_kernel =
        std::nullopt,
    std::vector<mwperf::ArrivalPhaseIdentityV1> state_phases = {}) {
  auto row_values = rows ? std::move(*rows)
                         : std::vector<CompletionBoundMarkedRowV1>{};
  return {std::move(states),
          std::move(entries),
          std::move(selection),
          std::move(solver),
          std::move(numerical_entries),
          std::move(row_values),
          completion,
          std::move(completion_identity),
          physical_mark_preserving,
          std::move(bound_instance),
          std::move(bound_configured_arrival),
          std::move(bound_target_selection),
          digest("c18.test.exact-state-schema"),
          digest("c18.test.reduced-state-schema"),
          std::move(configured_phases),
          std::move(configured_phase_masses),
          std::move(configured_phase_kernel),
          std::move(state_phases)};
}

[[nodiscard]] TransitionMatrix make_matrix(C18ExactMatrixFixtureV1 value) {
  auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
      std::move(value));
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] InvariantLaw solve(TransitionMatrix matrix,
                                 const SelectionSpec& selection,
                                 const SolverPolicy& solver) {
  ClassDecomposition decomposition =
      mwperf::analyze_communicating_classes(matrix);
  auto selected =
      mwperf::select_invariant_class(decomposition, selection);
  INFO((selected ? std::string{}
                 : selected.error().code + ": " + selected.error().message));
  REQUIRE(selected);
  auto law = mwperf::solve_invariant_distribution(
      matrix, std::move(selected).value(), solver);
  INFO((law ? std::string{}
            : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] long double metric_scalar(const mwperf::MetricValue& value) {
  auto decoded = mwperf::testing::C18FixtureAccess::decode_metric_scalar(value);
  REQUIRE(decoded);
  return decoded.value();
}

[[nodiscard]] mwperf::RewardDecoder state_reward(
    const long double value = 1.0L) {
  return {mwperf::StationaryRewardDomainV1::state,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [value](const mwperf::StationaryRewardArgumentV1& argument) {
            if (argument.edge != nullptr) {
              return mwperf::Result<long double>::failure(
                  {mwperf::DiagnosticCategory::internal,
                   "c18.test.state_reward_edge",
                   "state reward unexpectedly received an edge",
                   std::nullopt, std::nullopt, {}});
            }
            return mwperf::Result<long double>::success(value);
          },
          {"c18.test.scalar", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder departure_reward(
    std::vector<mwperf::RequiredStationaryMarkV1> required_marks = {}) {
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          std::move(required_marks),
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            if (argument.edge == nullptr ||
                argument.edge->target_departures.size() != 1U) {
              return mwperf::Result<long double>::failure(
                  {mwperf::DiagnosticCategory::internal,
                   "c18.test.missing_edge",
                   "departure reward requires one marked edge",
                   std::nullopt, std::nullopt, {}});
            }
            return mwperf::Result<long double>::success(
                static_cast<long double>(
                    argument.edge->target_departures.front()));
          },
          {"c18.test.scalar", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder arrival_reward() {
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            if (argument.edge == nullptr ||
                argument.edge->target_arrivals.size() != 1U) {
              return mwperf::Result<long double>::failure(
                  {mwperf::DiagnosticCategory::internal,
                   "c18.test.missing_edge",
                   "arrival reward requires one marked edge",
                   std::nullopt, std::nullopt, {}});
            }
            return mwperf::Result<long double>::success(
                argument.edge->target_arrivals.front()
                    .value()
                    .convert_to<long double>());
          },
          {"c18.test.scalar", 1U}};
}

void check_close(const long double actual, const long double expected,
                 const long double tolerance = 1.0e-14L) {
  CHECK(std::isfinite(actual));
  CHECK(std::abs(actual - expected) <= tolerance);
}

[[nodiscard]] bool has_note(const mwperf::Diagnostic& diagnostic,
                            const std::string_view fragment) {
  return std::ranges::any_of(
      diagnostic.notes, [fragment](const std::string& note) {
        return note.find(fragment) != std::string::npos;
      });
}

}  // namespace

TEST_CASE("C18 solves the irreducible rational invariant equation",
          "[c18][unit]") {
  auto selection = unique_selection();
  const auto solver = policy("irreducible");
  auto matrix = make_matrix(fixture(
      {state(0U), state(1U)},
      {rational(3, 4), rational(1, 4), rational(1, 2), rational(1, 2)},
      selection, solver));

  const auto decomposition = mwperf::analyze_communicating_classes(matrix);
  REQUIRE(decomposition.classes().size() == 1U);
  REQUIRE(decomposition.closed_class_indices().size() == 1U);
  CHECK(decomposition.transient_state_indices().empty());

  const auto law = solve(matrix, selection, solver);
  REQUIRE(law.masses().size() == 2U);
  check_close(law.masses()[0], 2.0L / 3.0L);
  check_close(law.masses()[1], 1.0L / 3.0L);
  const auto& diagnostics = law.solve_diagnostics();
  REQUIRE(diagnostics.class_solves.size() == 1U);
  CHECK(diagnostics.class_solves.front().dimension == 2U);
  CHECK(diagnostics.class_solves.front().rank == 2U);
  CHECK(diagnostics.class_solves.front().finite_nonnegative);
  CHECK(diagnostics.class_solves.front().status ==
        mwperf::StationaryLinearSolveStatusV1::solved);
  CHECK(diagnostics.normalization_residual <=
        diagnostics.normalization_bound);
  CHECK(diagnostics.l1_invariance_residual <=
        diagnostics.l1_invariance_bound);
  CHECK(diagnostics.maximum_invariance_residual <=
        diagnostics.maximum_invariance_bound);
  CHECK(diagnostics.relative_residual_tolerance == ExactRational::zero());
}

TEST_CASE("C18 decomposes and explicitly selects a reducible rational law",
          "[c18][unit]") {
  const std::vector<ExactRational> entries{
      ExactRational::one(), ExactRational::zero(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one(), ExactRational::zero(),
      rational(1, 4),       rational(3, 4),       ExactRational::zero()};
  const auto solver = policy("reducible");

  SECTION("a missing selector is rejected") {
    auto selection = unique_selection();
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    const auto decomposition = mwperf::analyze_communicating_classes(matrix);
    REQUIRE(decomposition.classes().size() == 3U);
    REQUIRE(decomposition.closed_class_indices().size() == 2U);
    REQUIRE(decomposition.transient_state_indices().size() == 1U);
    CHECK(decomposition.transient_state_indices().front() == 2U);
    auto selected =
        mwperf::select_invariant_class(decomposition, selection);
    CHECK_FALSE(selected);
  }

  SECTION("one named closed class retains exact zero mass elsewhere") {
    auto selection = class_selection(0U);
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    const auto law = solve(matrix, selection, solver);
    REQUIRE(law.masses().size() == 3U);
    CHECK(law.masses()[0] == 1.0L);
    CHECK(law.masses()[1] == 0.0L);
    CHECK(law.masses()[2] == 0.0L);
    REQUIRE(law.selected_classes().size() == 1U);
    CHECK(law.selected_classes().front().class_id == class_id(0U));
    CHECK(law.selected_classes().front().exact_weight ==
          ExactRational::one());
  }

  SECTION("an authored mixture is normalized and keeps its provenance") {
    auto selection = mixture_selection(rational(2, 5), rational(3, 5));
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    const auto law = solve(matrix, selection, solver);
    REQUIRE(law.masses().size() == 3U);
    check_close(law.masses()[0], 2.0L / 5.0L);
    check_close(law.masses()[1], 3.0L / 5.0L);
    CHECK(law.masses()[2] == 0.0L);
    REQUIRE(law.selected_classes().size() == 2U);
    CHECK(law.selected_classes()[0].exact_weight == rational(2, 5));
    CHECK(law.selected_classes()[1].exact_weight == rational(3, 5));
  }

  SECTION("a zero-weight closed class remains explicit provenance") {
    auto selection =
        mixture_selection(ExactRational::one(), ExactRational::zero());
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    const auto law = solve(matrix, selection, solver);
    REQUIRE(law.masses().size() == 3U);
    CHECK(law.masses()[0] == 1.0L);
    CHECK(law.masses()[1] == 0.0L);
    CHECK(law.masses()[2] == 0.0L);
    REQUIRE(law.selected_classes().size() == 2U);
    CHECK(law.selected_classes()[0].class_id == class_id(0U));
    CHECK(law.selected_classes()[0].exact_weight == ExactRational::one());
    CHECK(law.selected_classes()[1].class_id == class_id(1U));
    CHECK(law.selected_classes()[1].exact_weight == ExactRational::zero());
    CHECK(law.solve_diagnostics().selected_classes.size() == 2U);
    CHECK(law.solve_diagnostics().class_solves.size() == 1U);
  }
}

TEST_CASE("C18 retains marks that share one endpoint",
          "[c18][unit]") {
  auto selection = unique_selection();
  const auto solver = policy("shared-endpoint");
  const auto only = state(0U);
  const auto required_id = mark_id("c18.test.shared-endpoint-mark");
  const mwperf::CodecIdentityV1 required_codec{
      "c18.test.shared-endpoint-value", 1U};
  auto first = edge(only, only, 0U, 0U, 0U, 0U);
  auto second = edge(only, only, 0U, 0U, 1U, 1U);
  first.marks.push_back(causal_mark(required_id, required_codec,
                                    mwperf::CausalStageV1::resolver, 0U));
  second.marks.push_back(causal_mark(required_id, required_codec,
                                     mwperf::CausalStageV1::resolver, 1U));
  std::vector<CompletionBoundMarkedRowV1> rows(1U);
  rows.front().atoms = {
      {0U, rational(2, 5), 0.4L, false, std::move(first)},
      {0U, rational(3, 5), 0.6L, false, std::move(second)}};
  auto matrix = make_matrix(fixture(
      {only}, {ExactRational::one()}, selection, solver, std::nullopt,
      std::move(rows)));
  CHECK(matrix.exact_entry(0U, 0U) == ExactRational::one());
  REQUIRE(matrix.marked_flux().rows().front().atoms.size() == 2U);

  const auto law = solve(matrix, selection, solver);
  const mwperf::RequiredStationaryMarkV1 required{
      required_id, required_codec, mwperf::CausalStageV1::arrival};
  auto reward = mwperf::evaluate_stationary_edge_reward(
      law, departure_reward({required}));
  REQUIRE(reward);
  const ExactRational exact_departure =
      rational(2, 5) * ExactRational::zero() +
      rational(3, 5) * ExactRational::one();
  check_close(metric_scalar(reward.value()),
              exact_departure.to_long_double());
  auto arrivals =
      mwperf::evaluate_stationary_edge_reward(law, arrival_reward());
  REQUIRE(arrivals);
  check_close(metric_scalar(arrivals.value()), 0.6L);

  auto too_early = required;
  too_early.latest_reveal_stage = mwperf::CausalStageV1::c_minus;
  auto unavailable = mwperf::evaluate_stationary_edge_reward(
      law, departure_reward({std::move(too_early)}));
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code == "c18.required_edge_mark_unavailable");

  auto state_with_edge_mark = state_reward();
  state_with_edge_mark.required_marks = {required};
  auto invalid_state_reward = mwperf::evaluate_stationary_edge_reward(
      law, state_with_edge_mark);
  REQUIRE_FALSE(invalid_state_reward);
  CHECK(invalid_state_reward.error().code ==
        "c18.state_reward_requires_edge_mark");
}

TEST_CASE("C18 completion kind controls marked reward availability",
          "[c18][unit]") {
  const auto only = state(0U);

  SECTION("state-only completion permits state rewards, not affected edges") {
    auto bound = deterministic_bound_instance();
    REQUIRE(bound.instance.analysis_spec().context);
    const auto selection =
        bound.instance.analysis_spec().context->selection;
    const auto solver = bound_policy(bound.instance);
    std::vector<CompletionBoundMarkedRowV1> rows(1U);
    rows.front().atoms = {
        {0U, ExactRational::one(), 1.0L, true, std::nullopt}};
    auto matrix = make_matrix(fixture(
        {only}, {ExactRational::one()}, selection, solver, std::nullopt,
        std::move(rows), BoundaryCompletionKindV1::state_only_completion,
        digest("c18.completion.state-only"), false, bound.instance,
        bound.configured_arrival, bound.target_selection,
        bound.configured_phases, bound.configured_phase_masses));
    const auto law = solve(matrix, selection, solver);
    auto state_value =
        mwperf::evaluate_stationary_edge_reward(law, state_reward(7.0L));
    REQUIRE(state_value);
    check_close(metric_scalar(state_value.value()), 7.0L);
    auto edge_value =
        mwperf::evaluate_stationary_edge_reward(law, departure_reward());
    CHECK_FALSE(edge_value);
    CHECK(matrix.marked_flux().completion_kind() ==
          BoundaryCompletionKindV1::state_only_completion);
    CHECK_FALSE(matrix.marked_flux().physical_mark_preserving());
    const auto diagnostics = mwperf::compute_stationary_flux_diagnostics(
        law, bound.instance);
    CHECK(diagnostics.instance_binding_matches);
    CHECK_FALSE(diagnostics.completion_mark_scope_available);
    CHECK_FALSE(diagnostics.expected_departures.has_value());
    CHECK_FALSE(diagnostics.expected_arrivals.has_value());
    CHECK_FALSE(diagnostics.flow_difference.has_value());
  }

  SECTION("marked completion evaluates only its transformed edge") {
    auto selection = unique_selection();
    const auto solver = policy("completion-marked");
    std::vector<CompletionBoundMarkedRowV1> rows(1U);
    rows.front().atoms = {{0U, ExactRational::one(), 1.0L, true,
                           edge(only, only, 0U, 0U, 1U, 1U)}};
    const auto completion_id = digest("c18.completion.marked");
    auto matrix = make_matrix(fixture(
        {only}, {ExactRational::one()}, selection, solver, std::nullopt,
        std::move(rows), BoundaryCompletionKindV1::marked_completion,
        completion_id, true));
    const auto law = solve(matrix, selection, solver);
    auto edge_value =
        mwperf::evaluate_stationary_edge_reward(law, departure_reward());
    REQUIRE(edge_value);
    check_close(metric_scalar(edge_value.value()), 1.0L);
    REQUIRE(matrix.marked_flux().completion_identity().has_value());
    CHECK(*matrix.marked_flux().completion_identity() == completion_id);
    CHECK(matrix.marked_flux().physical_mark_preserving());
    for (std::size_t destination = 0U; destination < matrix.size();
         ++destination) {
      long double stationary_right_marginal = 0.0L;
      for (std::size_t source = 0U; source < matrix.size(); ++source) {
        for (const auto& atom : matrix.marked_flux().rows()[source].atoms) {
          if (atom.successor_index == destination) {
            stationary_right_marginal +=
                law.masses()[source] * atom.exact_mass.to_long_double();
          }
        }
      }
      check_close(stationary_right_marginal, law.masses()[destination]);
    }
  }
}

TEST_CASE("C18 support is independent of solver scale",
          "[c18][unit]") {
  const auto a = rational(1, 1000000000000LL);
  const auto b = rational(2, 1000000000000LL);
  auto selection = unique_selection();
  const auto solver = policy("near-reducible");
  auto matrix = make_matrix(fixture(
      {state(0U), state(1U)},
      {ExactRational::one() - a, a, b, ExactRational::one() - b},
      selection, solver));
  CHECK(matrix.exact_positive_support(0U, 1U));
  CHECK(matrix.exact_positive_support(1U, 0U));
  const auto decomposition = mwperf::analyze_communicating_classes(matrix);
  REQUIRE(decomposition.classes().size() == 1U);

  const auto law = solve(matrix, selection, solver);
  check_close(law.masses()[0], 2.0L / 3.0L, 1.0e-12L);
  check_close(law.masses()[1], 1.0L / 3.0L, 1.0e-12L);
  REQUIRE(law.solve_diagnostics().class_solves.size() == 1U);
  CHECK(law.solve_diagnostics().class_solves.front().condition_warning);
}

TEST_CASE("C18 exact-first flux obeys the finite queue balance identity",
          "[c18][unit]") {
  const auto zero = state(0U);
  const auto one = state(1U);
  const auto two = state(2U);
  const auto three = state(3U);
  auto bound = deterministic_bound_instance();
  REQUIRE(bound.instance.analysis_spec().context);
  const auto selection =
      bound.instance.analysis_spec().context->selection;
  const auto solver = bound_policy(bound.instance);
  const std::vector<ExactRational> entries{
      rational(8, 9),       ExactRational::zero(),
      ExactRational::zero(), rational(1, 9),
      ExactRational::one(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one(),
      ExactRational::zero(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::zero(),
      ExactRational::one(), ExactRational::zero()};
  std::vector<CompletionBoundMarkedRowV1> rows(4U);
  rows[0U].atoms = {
      {0U, rational(8, 9), rational(8, 9).to_long_double(), false,
       edge(zero, zero, 0U, 0U, 0U, 0U, 0U)},
      {3U, rational(1, 9), rational(1, 9).to_long_double(), false,
       edge(zero, three, 0U, 0U, 0U, 3U, 0U)}};
  rows[1U].atoms = {
      {0U, ExactRational::one(), 1.0L, false,
       edge(one, zero, 0U, 0U, 1U, 0U, 1U)}};
  rows[2U].atoms = {
      {1U, ExactRational::one(), 1.0L, false,
       edge(two, one, 0U, 0U, 1U, 0U, 2U)}};
  rows[3U].atoms = {
      {2U, ExactRational::one(), 1.0L, false,
       edge(three, two, 0U, 0U, 1U, 0U, 3U)}};

  auto matrix = make_matrix(fixture(
      {zero, one, two, three}, entries, selection, solver, std::nullopt,
      std::move(rows), BoundaryCompletionKindV1::exact_closed, std::nullopt,
      true, bound.instance, bound.configured_arrival, bound.target_selection,
      bound.configured_phases,
      bound.configured_phase_masses, std::nullopt,
      {phase(0U), phase(0U), phase(0U), phase(0U)}));
  const auto law = solve(matrix, selection, solver);
  REQUIRE(law.masses().size() == 4U);
  check_close(law.masses()[0], 3.0L / 4.0L);
  check_close(law.masses()[1], 1.0L / 12.0L);
  check_close(law.masses()[2], 1.0L / 12.0L);
  check_close(law.masses()[3], 1.0L / 12.0L);

  const auto diagnostics =
      mwperf::compute_stationary_flux_diagnostics(law, bound.instance);
  REQUIRE(diagnostics.expected_arrivals.has_value());
  REQUIRE(diagnostics.expected_departures.has_value());
  REQUIRE(diagnostics.flow_difference.has_value());
  check_close(*diagnostics.expected_arrivals, 1.0L / 4.0L);
  check_close(*diagnostics.expected_departures, 1.0L / 4.0L);
  check_close(*diagnostics.flow_difference, 0.0L);
}

TEST_CASE("C18 arrival phase marginal is a publication gate",
          "[c18][unit]") {
  const std::vector<ExactRational> entries{
      ExactRational::one(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one()};
  const std::vector<mwperf::ArrivalPhaseIdentityV1> phases{
      absorbing_phase(0U), absorbing_phase(1U)};
  const std::vector<ExactRational> identity_phase_kernel{
      ExactRational::one(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one()};

  SECTION("matching configured phase law passes") {
    auto bound = two_phase_bound_instance();
    REQUIRE(bound.instance.analysis_spec().context);
    const auto selection =
        bound.instance.analysis_spec().context->selection;
    const auto solver = bound_policy(bound.instance);
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U)}, entries, selection, solver, std::nullopt,
        std::nullopt, BoundaryCompletionKindV1::exact_closed, std::nullopt,
        true, bound.instance, std::nullopt, bound.target_selection, phases,
        {rational(1, 2), rational(1, 2)}, identity_phase_kernel, phases));
    const auto law = solve(matrix, selection, solver);
    const auto diagnostics =
        mwperf::compute_stationary_flux_diagnostics(law, bound.instance);
    CHECK(diagnostics.instance_binding_matches);
    CHECK(diagnostics.arrival_phase_marginal_available);
    CHECK(diagnostics.arrival_phase_marginal_matches);
    CHECK_FALSE(diagnostics.fatal);
    CHECK(diagnostics.publication_allowed);
  }

  SECTION("wrong configured phase law is fatal despite invariance") {
    auto bound = two_phase_bound_instance();
    REQUIRE(bound.instance.analysis_spec().context);
    const auto selection =
        bound.instance.analysis_spec().context->selection;
    const auto solver = bound_policy(bound.instance);
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U)}, entries, selection, solver, std::nullopt,
        std::nullopt, BoundaryCompletionKindV1::exact_closed, std::nullopt,
        true, bound.instance, std::nullopt, bound.target_selection, phases,
        {rational(3, 4), rational(1, 4)}, identity_phase_kernel, phases));
    const auto law = solve(matrix, selection, solver);
    CHECK(law.solve_diagnostics().l1_invariance_residual <=
          law.solve_diagnostics().l1_invariance_bound);
    const auto diagnostics =
        mwperf::compute_stationary_flux_diagnostics(law, bound.instance);
    CHECK(diagnostics.instance_binding_matches);
    CHECK(diagnostics.arrival_phase_marginal_available);
    CHECK_FALSE(diagnostics.arrival_phase_marginal_matches);
    CHECK(diagnostics.fatal);
    CHECK_FALSE(diagnostics.publication_allowed);
  }
}

TEST_CASE("C18 rejects malformed exact matrix and marked data",
          "[c18][negative]") {
  const auto solver = policy("malformed");

  SECTION("exact row mass is not one") {
    auto selection = unique_selection();
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U)}, {rational(1, 2)}, selection, solver));
    CHECK_FALSE(result);
  }

  SECTION("an exact transition is negative") {
    auto selection = unique_selection();
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U), state(1U)},
                {rational(3, 2), rational(-1, 2),
                 ExactRational::zero(), ExactRational::one()},
                selection, solver));
    CHECK_FALSE(result);
  }

  SECTION("a required numerical image is not finite") {
    auto selection = unique_selection();
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U)}, {ExactRational::one()}, selection, solver,
                std::vector<long double>{
                    std::numeric_limits<long double>::infinity()}));
    CHECK_FALSE(result);
  }

  SECTION("the state domain contains a duplicate exact identity") {
    auto selection = unique_selection();
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U), state(0U)},
                {ExactRational::one(), ExactRational::zero(),
                 ExactRational::zero(), ExactRational::one()},
                selection, solver));
    CHECK_FALSE(result);
  }

  SECTION("a marked endpoint index is not in the domain") {
    auto selection = unique_selection();
    std::vector<CompletionBoundMarkedRowV1> rows(1U);
    rows.front().atoms = {{1U, ExactRational::one(), 1.0L, false,
                           edge(state(0U), state(1U), 0U, 1U)}};
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U)}, {ExactRational::one()}, selection, solver,
                std::nullopt, std::move(rows)));
    CHECK_FALSE(result);
  }

  SECTION("departure larger than current backlog is invalid") {
    auto selection = unique_selection();
    std::vector<CompletionBoundMarkedRowV1> rows(1U);
    auto malformed = edge(state(0U), state(0U), 0U, 0U, 2U, 0U);
    malformed.prearrival_target_backlog.front() = mwperf::BigNat{1U};
    rows.front().atoms = {
        {0U, ExactRational::one(), 1.0L, false, std::move(malformed)}};
    auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U)}, {ExactRational::one()}, selection, solver,
                std::nullopt, std::move(rows)));
    CHECK_FALSE(result);
  }
}

TEST_CASE("C18 rejects ambiguous or inadmissible invariant selectors",
          "[c18][negative]") {
  const std::vector<ExactRational> entries{
      ExactRational::one(), ExactRational::zero(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one(), ExactRational::zero(),
      rational(1, 4),       rational(3, 4),       ExactRational::zero()};
  const auto solver = policy("selector-negative");

  SECTION("unknown class identifier") {
    auto selection = class_selection(9U);
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    auto selected = mwperf::select_invariant_class(
        mwperf::analyze_communicating_classes(matrix), selection);
    CHECK_FALSE(selected);
  }

  SECTION("mixture assigns mass to a transient class") {
    auto selection = mixture_selection(rational(1, 2), rational(1, 2), 2U);
    auto matrix = make_matrix(fixture(
        {state(0U), state(1U), state(2U)}, entries, selection, solver));
    auto selected = mwperf::select_invariant_class(
        mwperf::analyze_communicating_classes(matrix), selection);
    CHECK_FALSE(selected);
  }

  SECTION("mixture has zero total mass") {
    auto selection =
        mixture_selection(ExactRational::zero(), ExactRational::zero());
    auto matrix = mwperf::testing::C18FixtureAccess::transition_matrix(
        fixture({state(0U), state(1U), state(2U)}, entries, selection,
                solver));
    CHECK_FALSE(matrix);
  }
}

TEST_CASE("C18 rejects foreign selection and solver identities before solve",
          "[c18][negative]") {
  auto selection = unique_selection();
  const auto first_policy = policy("bound-policy");
  auto first = make_matrix(fixture(
      {state(0U), state(1U)},
      {rational(3, 4), rational(1, 4), rational(1, 2), rational(1, 2)},
      selection, first_policy));
  auto first_selected = mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(first), selection);
  REQUIRE(first_selected);

  SECTION("separately supplied solver policy differs") {
    auto result = mwperf::solve_invariant_distribution(
        first, first_selected.value(), policy("foreign-policy"));
    CHECK_FALSE(result);
  }

  SECTION("same-shaped selection belongs to another matrix") {
    auto second = make_matrix(fixture(
        {state(0U), state(1U)},
        {rational(2, 3), rational(1, 3), rational(1, 4), rational(3, 4)},
        selection, first_policy));
    auto second_selected = mwperf::select_invariant_class(
        mwperf::analyze_communicating_classes(second), selection);
    REQUIRE(second_selected);
    auto result = mwperf::solve_invariant_distribution(
        first, second_selected.value(), first_policy);
    CHECK_FALSE(result);
  }

  SECTION("equal-valued carriers still have distinct bound identities") {
    auto second = make_matrix(fixture(
        {state(0U), state(1U)},
        {rational(3, 4), rational(1, 4), rational(1, 2), rational(1, 2)},
        selection, first_policy));
    CHECK(second.exact_entry(0U, 0U) == first.exact_entry(0U, 0U));
    CHECK(second.numerical_entry(1U, 1U) ==
          first.numerical_entry(1U, 1U));
    auto second_selected = mwperf::select_invariant_class(
        mwperf::analyze_communicating_classes(second), selection);
    REQUIRE(second_selected);
    auto result = mwperf::solve_invariant_distribution(
        first, second_selected.value(), first_policy);
    CHECK_FALSE(result);
  }
}

TEST_CASE("C18 rejects a same-shaped foreign resolved instance",
          "[c18][negative]") {
  auto bound = deterministic_bound_instance();
  auto foreign = deterministic_bound_instance();
  CHECK(bound.instance.fingerprints() == foreign.instance.fingerprints());
  CHECK_FALSE(bound.instance.arrival().shares_compiled_product_with(
      foreign.instance.arrival()));

  REQUIRE(bound.instance.analysis_spec().context);
  const auto selection =
      bound.instance.analysis_spec().context->selection;
  const auto solver = bound_policy(bound.instance);
  auto matrix = make_matrix(fixture(
      {state(0U)}, {ExactRational::one()}, selection, solver, std::nullopt,
      std::nullopt, BoundaryCompletionKindV1::exact_closed, std::nullopt,
      true, bound.instance, bound.configured_arrival, bound.target_selection,
      bound.configured_phases,
      bound.configured_phase_masses));
  const auto law = solve(matrix, selection, solver);
  const auto diagnostics =
      mwperf::compute_stationary_flux_diagnostics(law, foreign.instance);
  CHECK_FALSE(diagnostics.instance_binding_matches);
  CHECK(diagnostics.fatal);
  CHECK_FALSE(diagnostics.publication_allowed);
  CHECK_FALSE(diagnostics.expected_departures.has_value());
  CHECK_FALSE(diagnostics.arrival_phase_marginal_available);
}

TEST_CASE("C18 retains a bounded floating row residual without repair",
          "[c18][negative]") {
  auto selection = unique_selection();
  const auto solver = policy("floating-residual");
  const long double perturbed = 0.75L + 5.0e-16L;
  auto matrix = make_matrix(fixture(
      {state(0U), state(1U)},
      {rational(1, 4), rational(3, 4), rational(1, 2), rational(1, 2)},
      selection, solver,
      std::vector<long double>{0.25L, perturbed, 0.5L, 0.5L}));
  CHECK(matrix.numerical_entry(0U, 1U) == perturbed);
  REQUIRE(matrix.row_diagnostics().size() == 2U);
  CHECK(matrix.row_diagnostics()[0].numerical_residual_from_one > 0.0L);
  CHECK(std::abs(matrix.row_diagnostics()[0].numerical_residual_from_one) <=
        matrix.row_diagnostics()[0].residual_bound);
  CHECK(matrix.exact_entry(0U, 0U) + matrix.exact_entry(0U, 1U) ==
        ExactRational::one());
}

TEST_CASE("C18 reports a numerically unresolved exact positive class",
          "[c18][negative]") {
  mwperf::BigInt denominator{1};
  for (std::size_t index = 0U; index < 6000U; ++index) {
    denominator *= 10;
  }
  auto a_result = ExactRational::make(mwperf::BigInt{1}, denominator);
  auto b_result = ExactRational::make(mwperf::BigInt{2}, denominator);
  REQUIRE(a_result);
  REQUIRE(b_result);
  const auto a = std::move(a_result).value();
  const auto b = std::move(b_result).value();
  auto selection = unique_selection();
  const auto solver = policy("underflow-rank");
  auto matrix = make_matrix(fixture(
      {state(0U), state(1U)},
      {ExactRational::one() - a, a, b, ExactRational::one() - b},
      selection, solver));
  CHECK(matrix.exact_positive_support(0U, 1U));
  CHECK(matrix.exact_positive_support(1U, 0U));
  CHECK(matrix.numerical_entry(0U, 1U) == 0.0L);
  CHECK(mwperf::analyze_communicating_classes(matrix).classes().size() == 1U);
  auto selected = mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(matrix), selection);
  REQUIRE(selected);
  auto law = mwperf::solve_invariant_distribution(
      matrix, std::move(selected).value(), solver);
  REQUIRE_FALSE(law);
  CHECK(law.error().code == "c18.numerically_unresolved");
  CHECK(has_note(law.error(), "reason rank_deficient"));
  CHECK(has_note(law.error(), "method dense_pivoted"));
  CHECK(has_note(law.error(), "rank 1"));
  CHECK(has_note(law.error(), "dimension 2"));
  CHECK(has_note(law.error(), "normalization residual"));
  CHECK(has_note(law.error(), "l1 residual"));
  CHECK(has_note(law.error(), "maximum residual"));
  CHECK(has_note(law.error(), "condition warning"));
}

TEST_CASE("C18 solver tolerance cannot alter topology or closure",
          "[c18][negative]") {
  const auto a = rational(1, 1000000000000LL);
  const auto b = rational(2, 1000000000000LL);
  auto selection = unique_selection();
  const auto strict = policy("strict", rational(1, 1000000000000000LL));
  const auto loose = policy("loose", rational(1, 1000000));
  const std::vector<ExactRational> entries{
      ExactRational::one() - a, a, b, ExactRational::one() - b};
  auto strict_matrix = make_matrix(
      fixture({state(0U), state(1U)}, entries, selection, strict));
  auto loose_matrix = make_matrix(
      fixture({state(0U), state(1U)}, entries, selection, loose));
  const auto strict_classes =
      mwperf::analyze_communicating_classes(strict_matrix);
  const auto loose_classes =
      mwperf::analyze_communicating_classes(loose_matrix);
  REQUIRE(strict_classes.classes().size() == loose_classes.classes().size());
  CHECK(strict_classes.classes().front().member_indices ==
        loose_classes.classes().front().member_indices);
  CHECK(strict_matrix.exact_positive_support(0U, 1U));
  CHECK(loose_matrix.exact_positive_support(0U, 1U));
}
