#include <concepts>
#include <cstddef>
#include <cstdint>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/metrics/palm_fifo.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

template <typename Source>
concept EventPalmSource = requires(const Source& source,
                                   const mwperf::EventIndicator& event) {
  { mwperf::construct_event_palm_law(source, event) } ->
      std::same_as<mwperf::Result<mwperf::PalmLaw>>;
};

template <typename Source>
concept AdmissionPalmSource = requires(const Source& source,
                                       const mwperf::ArrivalCountMark& mark) {
  { mwperf::construct_admission_palm_law(source, mark) } ->
      std::same_as<mwperf::Result<mwperf::AdmissionPalmLaw>>;
};

template <typename Kernel>
concept FifoEvaluationKernel = requires(
    const mwperf::TagInitialLaw& entrance, const Kernel& kernel,
    const mwperf::HorizonSpec& horizon, const mwperf::SolverPolicy& policy) {
  { mwperf::evaluate_fifo_delay_distribution(entrance, kernel, horizon,
                                              policy) } ->
      std::same_as<mwperf::Result<mwperf::DelayLaw>>;
};

static_assert(EventPalmSource<mwperf::StationaryTemporalLaw>);
static_assert(!EventPalmSource<mwperf::StationaryMarkedEdge>);
static_assert(!EventPalmSource<mwperf::AuditedTemporalLaw>);
static_assert(!EventPalmSource<mwperf::AuditedSamplerDescriptor>);

static_assert(AdmissionPalmSource<mwperf::StationaryMarkedEdge>);
static_assert(!AdmissionPalmSource<mwperf::StationaryTemporalLaw>);
static_assert(!AdmissionPalmSource<mwperf::AuditedTemporalKernel>);
static_assert(!AdmissionPalmSource<mwperf::AuditedSamplerDescriptor>);

static_assert(FifoEvaluationKernel<mwperf::TemporalServiceKernel>);
static_assert(!FifoEvaluationKernel<mwperf::AuditedTemporalKernel>);
static_assert(!FifoEvaluationKernel<mwperf::KilledKernel>);
static_assert(!FifoEvaluationKernel<mwperf::StationaryMarkedEdge>);

static_assert(!std::default_initializable<mwperf::PalmLaw>);
static_assert(!std::default_initializable<mwperf::AdmissionPalmLaw>);
static_assert(!std::default_initializable<mwperf::AdmissionRate>);
static_assert(!std::default_initializable<mwperf::StationaryQueueLaw>);
static_assert(!std::default_initializable<mwperf::TagInitialLaw>);
static_assert(!std::default_initializable<mwperf::DelayLaw>);
static_assert(!std::convertible_to<mwperf::PalmLaw,
                                   mwperf::AdmissionPalmLaw>);

}  // namespace

TEST_CASE("C23 admission Palm size-biases batches and counts every rank once",
          "[c23][unit][palm]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;

  const auto palm = require_value(
      mwperf::testing::C23FixtureAccess::inspect_admission_palm(
          {Edge{rational(1, 2), mwperf::BigNat{5U}, 0U,
                mwperf::BigNat{1U}},
           Edge{rational(1, 2), mwperf::BigNat{5U}, 0U,
                mwperf::BigNat{3U}}}));

  CHECK(palm.exact_intensity == rational(2, 1));
  CHECK(palm.exact_total_mass == mwperf::ExactRational::one());
  REQUIRE(palm.atoms.size() == 4U);

  CHECK(palm.atoms[0U].edge_index == 0U);
  CHECK(palm.atoms[0U].batch_size == mwperf::BigNat{1U});
  CHECK(palm.atoms[0U].rank == mwperf::BigNat{1U});
  CHECK(palm.atoms[0U].exact_mass == rational(1, 4));

  mwperf::ExactRational size_three_mass = mwperf::ExactRational::zero();
  for (std::size_t index = 1U; index < palm.atoms.size(); ++index) {
    const auto& atom = palm.atoms[index];
    CHECK(atom.edge_index == 1U);
    CHECK(atom.batch_size == mwperf::BigNat{3U});
    CHECK(atom.rank == mwperf::BigNat{index});
    CHECK(atom.exact_mass == rational(1, 4));
    size_three_mass = size_three_mass + atom.exact_mass;
  }
  CHECK(size_three_mass == rational(3, 4));
}

TEST_CASE("C23 zero-admission edges create no Palm labels",
          "[c23][unit][palm]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;

  const auto palm = require_value(
      mwperf::testing::C23FixtureAccess::inspect_admission_palm(
          {Edge{rational(1, 2), mwperf::BigNat{2U}, 0U,
                mwperf::BigNat{0U}},
           Edge{rational(1, 2), mwperf::BigNat{2U}, 0U,
                mwperf::BigNat{2U}}}));

  CHECK(palm.exact_intensity == mwperf::ExactRational::one());
  CHECK(palm.exact_total_mass == mwperf::ExactRational::one());
  REQUIRE(palm.atoms.size() == 2U);
  for (std::size_t rank = 0U; rank < palm.atoms.size(); ++rank) {
    CHECK(palm.atoms[rank].edge_index == 1U);
    CHECK(palm.atoms[rank].batch_size == mwperf::BigNat{2U});
    CHECK(palm.atoms[rank].rank == mwperf::BigNat{rank + 1U});
    CHECK(palm.atoms[rank].exact_mass == rational(1, 2));
  }
}

TEST_CASE("C23 admission Palm uses the first eligible boundary and exact rank",
          "[c23][unit][palm][timing]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  const auto palm = require_value(
      mwperf::testing::C23FixtureAccess::inspect_admission_palm(
          {Edge{mwperf::ExactRational::one(), mwperf::BigNat{5U}, 1U,
                mwperf::BigNat{3U}}}));

  REQUIRE(palm.atoms.size() == 3U);
  CHECK(palm.atoms[1U].rank == mwperf::BigNat{2U});
  CHECK(palm.atoms[1U].first_eligible_backlog == mwperf::BigNat{7U});
  CHECK(palm.atoms[1U].predecessors == mwperf::BigNat{5U});
  CHECK(palm.atoms[1U].predecessors <
        palm.atoms[1U].first_eligible_backlog);
}

TEST_CASE("C23 rejects zero admission intensity before normalization",
          "[c23][unit][palm][negative]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  const auto rejected =
      mwperf::testing::C23FixtureAccess::inspect_admission_palm(
          {Edge{rational(1, 3), mwperf::BigNat{0U}, 0U,
                mwperf::BigNat{0U}},
           Edge{rational(2, 3), mwperf::BigNat{4U}, 1U,
                mwperf::BigNat{0U}}});

  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK_FALSE(rejected.error().code.empty());
}
