#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ConflictFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::ConflictProblem problem;
};

struct Query final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct ForcedAttempt final {
  mwperf::Result<mwperf::PrimaryOptimum> result;
  mwperf::BigNat calls_reserved;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c08-mwis";
  std::filesystem::create_directories(directory);
  const auto path =
      directory /
      ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string model_text(const std::string& queues,
                                     const std::string& conflicts) {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues +
         R"(},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":)" +
         conflicts +
         R"(},"priority":null,"max_search_states":null}},"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] ConflictFixture make_fixture(const std::string& queues,
                                           const std::string& conflicts) {
  auto document =
      mwperf::load_document(write_model(model_text(queues, conflicts)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  const auto& geometry = std::get<mwperf::ResolvedConflictConstraint>(
      descriptor.value().value());
  auto problem = mwperf::compile_conflict_problem(geometry);
  INFO((problem ? std::string{} : problem.error().code));
  REQUIRE(problem);
  return ConflictFixture{std::move(catalog).value(),
                         std::move(priority).value(),
                         std::move(descriptor).value(),
                         std::move(problem).value()};
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy policy(
    const std::optional<std::uint64_t> limit) {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call =
          limit.has_value()
              ? std::optional<mwperf::BigNat>(mwperf::BigNat(*limit))
              : std::nullopt,
      .effective_per_call =
          limit.has_value()
              ? std::optional<mwperf::BigNat>(mwperf::BigNat(*limit))
              : std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '8'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const ConflictFixture& fixture,
    const mwperf::OptimizerBudgetPolicy& budget_policy) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, budget_policy);
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] Query query(const ConflictFixture& fixture,
                          const std::vector<mwperf::BigNat>& primary_values,
                          std::vector<std::uint8_t> eligibility_values,
                          const mwperf::OptimizerBudgetPolicy& budget_policy) {
  const auto token = dimension(fixture, budget_policy);
  auto primary = mwperf::PrimaryWeights::from_values(token, primary_values);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, std::move(eligibility_values));
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return Query{std::move(primary).value(), std::move(eligibility).value(),
               std::move(weights).value()};
}

struct SearchBudgetScope final {
  mwperf::OptimizerExecutionContext context;
  mwperf::SearchBudget budget;
};

[[nodiscard]] SearchBudgetScope budget(
    const mwperf::QueueDimensionToken& token,
    mwperf::OptimizerBudgetPolicy budget_policy) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(budget_policy), std::nullopt, token);
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto result = mwperf::begin_search_budget(context);
  REQUIRE(result);
  REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
      result.value(), mwperf::ServiceFamily::pairwise_conflicts));
  return {std::move(context), std::move(result).value()};
}

[[nodiscard]] ForcedAttempt forced_attempt(
    const ConflictFixture& fixture, const Query& exact_query,
    const mwperf::OptimizerBudgetPolicy& budget_policy,
    const mwperf::ForcedTargetBit side) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      budget_policy, std::nullopt, exact_query.primary.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto target = mwperf::TargetIndex::from_dimension(
      exact_query.primary.dimension(), 0U);
  REQUIRE(target);
  auto result = mwperf::solve_forced_target(
      context, fixture.descriptor, exact_query.eligibility,
      exact_query.primary, target.value(), side, fixture.priority);
  return ForcedAttempt{std::move(result),
                       context.ledger_snapshot().calls_reserved()};
}

[[nodiscard]] std::vector<std::uint8_t> bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

}  // namespace

TEST_CASE("C08 conflict compilation stores canonical symmetric bitsets and isolates",
          "[c08][unit][mwis][compile]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2","q3"])",
      R"([["q2","q0"],["q1","q2"]])");
  const auto& problem = fixture.problem;
  REQUIRE(problem.queue_count() == 4U);
  REQUIRE(problem.edges().size() == 2U);
  CHECK(problem.edges()[0U].first.ordinal() == 0U);
  CHECK(problem.edges()[0U].second.ordinal() == 2U);
  CHECK(problem.edges()[1U].first.ordinal() == 1U);
  CHECK(problem.edges()[1U].second.ordinal() == 2U);
  CHECK(problem.adjacency()[0U].test(2U));
  CHECK(problem.adjacency()[2U].test(0U));
  CHECK_FALSE(problem.adjacency()[0U].test(0U));
  CHECK(problem.closed_neighborhoods()[0U].test(0U));
  CHECK((std::vector<std::size_t>(problem.isolated_queues().begin(),
                                  problem.isolated_queues().end()) ==
         std::vector<std::size_t>{3U}));
  CHECK(mwperf::detail::validate_conflict_problem(problem));
}

TEST_CASE("C08 canonical queue subsets retain logical length and mask tail bits",
          "[c08][unit][mwis][subset]") {
  auto sixty_four = mwperf::QueueSubset::none(64U);
  auto sixty_five = mwperf::QueueSubset::none(65U);
  REQUIRE(sixty_four.set(63U));
  REQUIRE(sixty_five.set(63U));
  CHECK(sixty_four != sixty_five);
  CHECK(sixty_four.canonical());
  CHECK(sixty_five.canonical());
  CHECK_FALSE(sixty_five.set(65U));

  auto malformed = mwperf::QueueSubset::for_test_unchecked(
      65U, {std::uint64_t{0U}, std::uint64_t{2U}});
  CHECK_FALSE(malformed.canonical());
}

TEST_CASE("C08 exact MWIS solves elementary and disconnected graphs",
          "[c08][unit][mwis]") {
  SECTION("empty eligibility is a zero-expansion base state") {
    const auto fixture = make_fixture(R"(["q0","q1"])",
                                      R"([["q0","q1"]])");
    const auto budget_policy = policy(0U);
    const auto exact_query =
        query(fixture, naturals({9U, 8U}), {0U, 0U}, budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    auto result = mwperf::detail::solve_mwis_exact(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget);
    REQUIRE(result);
    CHECK(bits(result.value().schedule) == std::vector<std::uint8_t>{0U, 0U});
    CHECK(result.value().composite_objective.is_zero());
    CHECK(work.budget.completed_expansions().is_zero());
  }

  SECTION("a path chooses the non-greedy endpoint pair") {
    const auto fixture = make_fixture(
        R"(["q0","q1","q2"])",
        R"([["q0","q1"],["q1","q2"]])");
    const auto budget_policy = policy(std::nullopt);
    const auto exact_query =
        query(fixture, naturals({3U, 5U, 3U}), {1U, 1U, 1U},
              budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    auto result = mwperf::detail::solve_mwis_exact(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget);
    REQUIRE(result);
    CHECK(bits(result.value().schedule) ==
          std::vector<std::uint8_t>{1U, 0U, 1U});
  }

  SECTION("an empty conflict graph selects every eligible isolate") {
    const auto fixture = make_fixture(
        R"(["q0","q1","q2","q3"])", R"([])");
    const auto budget_policy = policy(std::nullopt);
    const auto exact_query =
        query(fixture, naturals({1U, 2U, 3U, 4U}),
              {1U, 0U, 1U, 1U}, budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    auto result = mwperf::detail::solve_mwis_exact(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget);
    REQUIRE(result);
    CHECK(bits(result.value().schedule) ==
          std::vector<std::uint8_t>{1U, 0U, 1U, 1U});
  }

  SECTION("a clique selects its unique composite-priority vertex") {
    const auto fixture = make_fixture(
        R"(["q0","q1","q2","q3"])",
        R"([["q0","q1"],["q0","q2"],["q0","q3"],["q1","q2"],["q1","q3"],["q2","q3"]])");
    const auto budget_policy = policy(std::nullopt);
    const auto exact_query =
        query(fixture, naturals({5U, 5U, 5U, 5U}),
              {1U, 1U, 1U, 1U}, budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    auto result = mwperf::detail::solve_mwis_exact(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget);
    REQUIRE(result);
    CHECK(bits(result.value().schedule) ==
          std::vector<std::uint8_t>{1U, 0U, 0U, 0U});
  }

  SECTION("an even cycle selects the known opposite pair") {
    const auto fixture = make_fixture(
        R"(["q0","q1","q2","q3"])",
        R"([["q0","q1"],["q1","q2"],["q2","q3"],["q3","q0"]])");
    const auto budget_policy = policy(std::nullopt);
    const auto exact_query =
        query(fixture, naturals({5U, 4U, 5U, 4U}),
              {1U, 1U, 1U, 1U}, budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    auto result = mwperf::detail::solve_mwis_exact(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget);
    REQUIRE(result);
    CHECK(bits(result.value().schedule) ==
          std::vector<std::uint8_t>{1U, 0U, 1U, 0U});
  }

  SECTION("disconnected component order follows component minima") {
    const auto fixture = make_fixture(
        R"(["q0","q1","q2","q3"])",
        R"([["q0","q1"],["q2","q3"]])");
    const auto budget_policy = policy(std::nullopt);
    const auto exact_query =
        query(fixture, naturals({1U, 1U, 1U, 1U}), {1U, 1U, 1U, 1U},
              budget_policy);
    auto work = budget(exact_query.weights.dimension(), budget_policy);
    mwperf::detail::MwisTestTrace trace;
    auto result = mwperf::detail::solve_mwis_exact_with_test_control(
        fixture.problem, exact_query.eligibility, exact_query.weights,
        work.budget, nullptr, mwperf::detail::MwisTestFault::none, trace);
    REQUIRE(result);
    REQUIRE_FALSE(trace.component_minima.empty());
    CHECK(trace.component_minima.front() ==
          std::vector<std::size_t>{0U, 2U});
    CHECK(bits(result.value().schedule) ==
          std::vector<std::uint8_t>{1U, 0U, 1U, 0U});
  }
}

TEST_CASE("C08 MWIS zero and singleton finite budgets meet the exact boundary",
          "[c08][unit][mwis][accounting]") {
  const auto fixture = make_fixture(R"(["q0"])", R"([])");

  const auto zero_policy = policy(0U);
  const auto zero_query =
      query(fixture, naturals({1U}), {1U}, zero_policy);
  auto zero_work = budget(zero_query.weights.dimension(), zero_policy);
  auto exhausted = mwperf::detail::solve_mwis_exact(
      fixture.problem, zero_query.eligibility, zero_query.weights,
      zero_work.budget);
  REQUIRE_FALSE(exhausted);
  CHECK(exhausted.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(exhausted.error().code == "search_state_limit_exhausted");
  CHECK(zero_work.budget.completed_expansions().is_zero());
  CHECK(zero_work.budget.exhausted());

  const auto one_policy = policy(1U);
  const auto one_query = query(fixture, naturals({1U}), {1U}, one_policy);
  auto one_work = budget(one_query.weights.dimension(), one_policy);
  auto solved = mwperf::detail::solve_mwis_exact(
      fixture.problem, one_query.eligibility, one_query.weights,
      one_work.budget);
  REQUIRE(solved);
  CHECK(bits(solved.value().schedule) == std::vector<std::uint8_t>{1U});
  CHECK(one_work.budget.completed_expansions() == mwperf::BigNat(1U));
  CHECK_FALSE(one_work.budget.exhausted());
}

TEST_CASE("C08 MWIS forced sides override target eligibility and ignore target weight",
          "[c08][unit][mwis][forced-target]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2","q3","q4"])",
      R"([["q0","q1"],["q1","q2"],["q2","q3"]])");
  const auto budget_policy = policy(std::nullopt);
  const auto exact_query =
      query(fixture, naturals({1000U, 5U, 4U, 3U, 2U}),
            {0U, 1U, 1U, 1U, 1U}, budget_policy);

  auto forced_zero = forced_attempt(
      fixture, exact_query, budget_policy, mwperf::ForcedTargetBit::zero);
  auto forced_one = forced_attempt(
      fixture, exact_query, budget_policy, mwperf::ForcedTargetBit::one);
  REQUIRE(forced_zero.result);
  REQUIRE(forced_one.result);
  CHECK(forced_zero.calls_reserved == mwperf::BigNat(1U));
  CHECK(forced_one.calls_reserved == mwperf::BigNat(1U));
  CHECK(forced_zero.result.value().value == mwperf::BigNat(10U));
  CHECK(forced_one.result.value().value == mwperf::BigNat(6U));
  CHECK(bits(forced_zero.result.value().witness) ==
        std::vector<std::uint8_t>{0U, 1U, 0U, 1U, 1U});
  CHECK(bits(forced_one.result.value().witness) ==
        std::vector<std::uint8_t>{1U, 0U, 1U, 0U, 1U});

  const auto changed =
      query(fixture, naturals({0U, 5U, 4U, 3U, 2U}),
            {0U, 1U, 1U, 1U, 1U}, budget_policy);
  auto changed_zero = forced_attempt(
      fixture, changed, budget_policy, mwperf::ForcedTargetBit::zero);
  auto changed_one = forced_attempt(
      fixture, changed, budget_policy, mwperf::ForcedTargetBit::one);
  REQUIRE(changed_zero.result);
  REQUIRE(changed_one.result);
  CHECK(changed_zero.result.value().value == forced_zero.result.value().value);
  CHECK(changed_one.result.value().value == forced_one.result.value().value);
  CHECK(bits(changed_zero.result.value().witness) ==
        bits(forced_zero.result.value().witness));
  CHECK(bits(changed_one.result.value().witness) ==
        bits(forced_one.result.value().witness));
}

TEST_CASE("C08 MWIS charges each new nonbase key once and no base or memo hit",
          "[c08][unit][mwis][accounting]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])",
      R"([["q0","q1"],["q1","q2"]])");
  const auto budget_policy = policy(3U);
  const auto exact_query =
      query(fixture, naturals({1U, 1U, 1U}), {1U, 1U, 1U},
            budget_policy);
  auto work = budget(exact_query.weights.dimension(), budget_policy);
  mwperf::detail::MwisTestTrace trace;
  auto result = mwperf::detail::solve_mwis_exact_with_test_control(
      fixture.problem, exact_query.eligibility, exact_query.weights,
      work.budget, nullptr, mwperf::detail::MwisTestFault::none, trace);
  REQUIRE(result);
  CHECK(work.budget.completed_expansions().to_decimal_string() == "3");
  CHECK(trace.expanded_keys.size() == 3U);
  CHECK(trace.base_calls == 3U);
  CHECK(trace.memo_hits == 1U);
}

TEST_CASE("C08 MWIS exhaustion is atomic after a completed sibling branch",
          "[c08][unit][mwis][accounting][negative]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])",
      R"([["q0","q2"],["q1","q2"]])");
  const auto budget_policy = policy(3U);
  const auto exact_query =
      query(fixture, naturals({1U, 1U, 1U}), {1U, 1U, 1U},
            budget_policy);
  auto work = budget(exact_query.weights.dimension(), budget_policy);
  mwperf::detail::MwisTestTrace trace;
  auto result = mwperf::detail::solve_mwis_exact_with_test_control(
      fixture.problem, exact_query.eligibility, exact_query.weights,
      work.budget, nullptr, mwperf::detail::MwisTestFault::none, trace);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "search_state_limit_exhausted");
  CHECK(result.error().category == mwperf::DiagnosticCategory::resource_limit);
  CHECK(work.budget.completed_expansions().to_decimal_string() == "3");
  CHECK(work.budget.exhausted());
  CHECK(trace.expanded_keys.size() == 3U);
}

TEST_CASE("C08 MWIS rejects distinct schedules with an injected equal composite score",
          "[c08][unit][mwis][negative]") {
  const auto fixture = make_fixture(R"(["q0"])", R"([])");
  const auto budget_policy = policy(std::nullopt);
  const auto exact_query =
      query(fixture, naturals({1U}), {1U}, budget_policy);
  auto work = budget(exact_query.weights.dimension(), budget_policy);
  mwperf::detail::MwisTestTrace trace;
  auto result = mwperf::detail::solve_mwis_exact_with_test_control(
      fixture.problem, exact_query.eligibility, exact_query.weights,
      work.budget, nullptr,
      mwperf::detail::MwisTestFault::force_distinct_branch_equality, trace);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "mwis_composite_equality_invariant");
}

TEST_CASE("C08 MWIS rejects corrupt asymmetric compiled adjacency",
          "[c08][unit][mwis][negative]") {
  const auto fixture = make_fixture(R"(["q0","q1"])",
                                    R"([["q0","q1"]])");
  std::vector<mwperf::QueueSubset> adjacency(fixture.problem.adjacency().begin(),
                                             fixture.problem.adjacency().end());
  REQUIRE(adjacency[0U].reset(1U));
  auto corrupt = mwperf::ConflictProblem::for_test(
      std::move(adjacency),
      std::vector<mwperf::QueueSubset>(
          fixture.problem.closed_neighborhoods().begin(),
          fixture.problem.closed_neighborhoods().end()),
      std::vector<mwperf::ConflictEdge>(fixture.problem.edges().begin(),
                                       fixture.problem.edges().end()),
      {});
  auto result = mwperf::detail::validate_conflict_problem(corrupt);
  REQUIRE_FALSE(result);
  CHECK((result.error().code == "conflict_problem_adjacency_asymmetric" ||
         result.error().code ==
             "conflict_problem_closed_neighborhood_invalid"));
}
