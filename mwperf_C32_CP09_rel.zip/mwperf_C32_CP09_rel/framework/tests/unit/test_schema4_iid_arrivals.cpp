#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

class TemporarySchema4 final {
 public:
  explicit TemporarySchema4(const std::string_view contents) {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory{MWPERF_TEST_TEMP_DIRECTORY};
    std::filesystem::create_directories(directory);
    path_ = directory /
            ("schema4_iid_" + std::to_string(next_id.fetch_add(1U)) +
             ".json");
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to create schema-4 IID fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output) {
      throw std::runtime_error("failed to write schema-4 IID fixture");
    }
  }

  TemporarySchema4(const TemporarySchema4&) = delete;
  TemporarySchema4& operator=(const TemporarySchema4&) = delete;

  ~TemporarySchema4() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

[[nodiscard]] std::string schema4_model(const std::string_view arrival,
                                        const bool observations) {
  return std::string{
             R"({"schema_version":"4.0.0","switch":{"kind":"generalized","queue_capacity":"NoDrop","queues":[{"id":"q0"},{"id":"q1"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":null}},"arrival":)"} +
         std::string{arrival} +
         (observations
              ? R"(,"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false,"observation":{"enabled":true,"block_slots":null,"targets":[{"queue_id":"q0","gap":"exact"},{"queue_id":"q1","gap":"none"}]}}})"
              : R"(,"telemetry":{"observation":{"enabled":false,"block_slots":null,"targets":[]}}})");
}

[[nodiscard]] mwperf::AuthoredModelConfig parse_schema4(
    const std::string& text) {
  TemporarySchema4 file(text);
  auto document = mwperf::load_document(file.path());
  REQUIRE(document);
  auto model = mwperf::extract_executable_model(document.value());
  REQUIRE(model);
  auto parsed = mwperf::parse_model_config(model.value());
  INFO((!parsed ? parsed.error().code + ": " + parsed.error().message
                : std::string{}));
  REQUIRE(parsed);
  return std::move(parsed).value();
}

struct CompiledFixture final {
  mwperf::QueueCatalog queues;
  mwperf::CompiledArrivalLaw law;
};

[[nodiscard]] CompiledFixture compile_schema4(const std::string_view arrival,
                                              const bool observations = false) {
  auto model = parse_schema4(schema4_model(arrival, observations));
  auto queues = mwperf::build_queue_catalog(model.switch_config);
  REQUIRE(queues);
  auto law = mwperf::compile_arrival_law(model.arrival, queues.value());
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  return {std::move(queues).value(), std::move(law).value()};
}

[[nodiscard]] std::string byte_hex(const std::span<const std::byte> bytes) {
  constexpr std::array<char, 16U> digits{
      '0', '1', '2', '3', '4', '5', '6', '7',
      '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
  std::string result;
  result.reserve(bytes.size() * 2U);
  for (const std::byte value : bytes) {
    const auto octet = std::to_integer<unsigned int>(value);
    result.push_back(digits[(octet >> 4U) & 0x0fU]);
    result.push_back(digits[octet & 0x0fU]);
  }
  return result;
}

[[nodiscard]] std::uint64_t read_u64_be(
    const std::span<const std::byte> bytes, const std::size_t offset) {
  REQUIRE(offset <= bytes.size());
  REQUIRE(bytes.size() - offset >= 8U);
  std::uint64_t value = 0U;
  for (std::size_t index = 0U; index < 8U; ++index) {
    value = (value << 8U) |
            std::to_integer<std::uint64_t>(bytes[offset + index]);
  }
  return value;
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                              const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed) {
  auto digest = mwperf::Digest256::from_hex(
      "00112233445566778899aabbccddeeff"
      "102132435465768798a9bacbdcedfe0f");
  REQUIRE(digest);
  auto key = mwperf::make_physical_reference_instance_key(
      digest.value(), mwperf::BigNat(0U));
  REQUIRE(key);
  return mwperf::derive_rng_stream(mwperf::MasterSeed(seed),
                                   mwperf::StageTag::configured_arrival,
                                   key.value());
}

[[nodiscard]] mwperf::ArrivalProcess make_process(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t seed) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, mwperf::ArrivalInitialState{mwperf::RenewalOrigin{}},
      std::move(stream).value());
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::BigNat count_at(
    const mwperf::ArrivalBatch& batch, const CompiledFixture& fixture,
    const std::size_t ordinal) {
  auto queue = fixture.queues.index_at(ordinal);
  REQUIRE(queue);
  auto count = mwperf::project_arrival_count(
      batch, queue.value(), mwperf::arrival_law_binding(fixture.law));
  REQUIRE(count);
  return std::move(count).value();
}

}  // namespace

TEST_CASE("CP09 schema-4 dispatch retains NoDrop telemetry and Bernoulli law",
          "[c32][cp09][unit][config][arrival]") {
  const std::string arrival =
      R"({"family":"iid_independent_bernoulli","rates":{"default":0.25,"overrides":[{"queue_id":"q1","rate":1}]},"metadata":{}})";
  auto model = parse_schema4(schema4_model(arrival, true));
  CHECK(model.schema_version.value == "4.0.0");
  const auto& switch_config =
      std::get<mwperf::GeneralizedSwitchConfig>(model.switch_config);
  CHECK_FALSE(switch_config.queue_capacity.value.has_value());
  CHECK_FALSE(switch_config.queue_capacity.provenance.defaulted);
  REQUIRE(model.telemetry.observation.has_value());
  CHECK(model.telemetry.observation->enabled.value);
  REQUIRE(model.telemetry.observation->targets.value.size() == 2U);
  CHECK(model.telemetry.observation->targets.value.front().gap.value ==
        mwperf::ObservationGapMode::exact);

  auto queues = mwperf::build_queue_catalog(model.switch_config);
  REQUIRE(queues);
  auto law = mwperf::compile_arrival_law(model.arrival, queues.value());
  REQUIRE(law);
  const mwperf::ArrivalCapabilities capabilities =
      mwperf::arrival_capabilities(law.value());
  REQUIRE(capabilities.exact_portable_iid_recipe.has_value());
  CHECK(capabilities.exact_portable_iid_recipe->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK_FALSE(capabilities.exact_factorized_iid_generator.has_value());
  auto target = queues.value().index_at(0U);
  REQUIRE(target);
  auto marginal =
      mwperf::project_exact_iid_target_pmf(law.value(), target.value());
  REQUIRE(marginal);
  REQUIRE(marginal.value().size() == 2U);
  CHECK(marginal.value()[0U].count == mwperf::BigNat(0U));
  CHECK(marginal.value()[0U].probability == rational(3, 4));
  CHECK(marginal.value()[1U].count == mwperf::BigNat(1U));
  CHECK(marginal.value()[1U].probability == rational(1, 4));
}

TEST_CASE("CP09 schema-4 count table preserves authored wire order and joint draws",
          "[c32][cp09][unit][arrival]") {
  auto fixture = compile_schema4(
      R"({"family":"iid_count_table","outcomes":[{"id":"pulse","probability":0.75,"counts":[{"queue_id":"q1","count":1},{"queue_id":"q0","count":2}]},{"id":"idle","probability":0.25,"counts":[]}],"metadata":{}})",
      true);
  CHECK(fixture.law.family() == mwperf::ArrivalFamily::iid_count_table);
  CHECK(fixture.law.variant().index() == 7U);

  const mwperf::BuilderArrivalView view =
      mwperf::builder_arrival_view(fixture.law);
  REQUIRE(view.capabilities().exact_portable_iid_recipe.has_value());
  CHECK(view.capabilities().exact_portable_iid_recipe->provision ==
        mwperf::AccessProvision::portable_only);
  CHECK(view.configured_law().schema ==
        mwperf::PortableArrivalLawSchema::iid_count_table_v1);
  CHECK(byte_hex(view.configured_law().canonical_data) ==
        "00000000000000336d77706572662e6330392e636f6d70696c65645f6172726976"
        "616c5f776974685f6e6f726d616c697a65645f726f77732e763100000000000000"
        "a6000000000000001d6d77706572662e6333322e6969645f636f756e745f746162"
        "6c652e763100000001000000000000000200000000000000020000000000000005"
        "70756c736500000000000000013300000000000000013400000000000000020000"
        "000000000000000000000000000200000000000000010000000000000001000000"
        "000000000469646c65000000000000000131000000000000000134000000000000"
        "00000000000000000000");

  REQUIRE(view.iid_joint_table().has_value());
  REQUIRE(view.iid_joint_table()->size() == 2U);
  CHECK((view.iid_joint_table()->at(0U).dense_counts ==
         std::vector<mwperf::BigNat>{mwperf::BigNat(0U),
                                     mwperf::BigNat(0U)}));
  CHECK(view.iid_joint_table()->at(0U).probability == rational(1, 4));
  CHECK((view.iid_joint_table()->at(1U).dense_counts ==
         std::vector<mwperf::BigNat>{mwperf::BigNat(2U),
                                     mwperf::BigNat(1U)}));
  CHECK(view.iid_joint_table()->at(1U).probability == rational(3, 4));

  auto process = make_process(fixture.law, 3209U);
  for (std::uint64_t slot = 0U; slot < 64U; ++slot) {
    auto step = mwperf::next_arrival_step(process, mwperf::BigNat(slot));
    REQUIRE(step);
    const mwperf::BigNat q0 = count_at(step.value().batch, fixture, 0U);
    const mwperf::BigNat q1 = count_at(step.value().batch, fixture, 1U);
    CHECK(((q0 == mwperf::BigNat(0U) && q1 == mwperf::BigNat(0U)) ||
           (q0 == mwperf::BigNat(2U) && q1 == mwperf::BigNat(1U))));
  }
}

TEST_CASE("CP09 schema-4 count table uses the complete u64 count carrier",
          "[c32][cp09][unit][arrival]") {
  constexpr std::uint64_t maximum =
      std::numeric_limits<std::uint64_t>::max();
  auto fixture = compile_schema4(
      R"({"family":"iid_count_table","outcomes":[{"id":"maximum","probability":1,"counts":[{"queue_id":"q0","count":18446744073709551615}]}],"metadata":{}})");

  const mwperf::BuilderArrivalView view =
      mwperf::builder_arrival_view(fixture.law);
  REQUIRE(view.iid_joint_table().has_value());
  REQUIRE(view.iid_joint_table()->size() == 1U);
  CHECK(view.iid_joint_table()->front().dense_counts.front() ==
        mwperf::BigNat(maximum));

  auto process = make_process(fixture.law, 3212U);
  auto step = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE(step);
  CHECK(count_at(step.value().batch, fixture, 0U) == mwperf::BigNat(maximum));
  CHECK(count_at(step.value().batch, fixture, 1U) == mwperf::BigNat(0U));
}

TEST_CASE("CP09 Poisson wire binds once-rounded rates and replay is structural",
          "[c32][cp09][unit][arrival][poisson]") {
  auto fixture = compile_schema4(
      R"({"family":"iid_independent_poisson","rates":{"default":0,"overrides":[{"queue_id":"q0","rate":0.1}]},"metadata":{}})");
  CHECK(fixture.law.family() ==
        mwperf::ArrivalFamily::iid_independent_poisson);
  CHECK(fixture.law.variant().index() == 8U);

  const mwperf::BuilderArrivalView view =
      mwperf::builder_arrival_view(fixture.law);
  REQUIRE(view.capabilities().exact_portable_iid_recipe.has_value());
  CHECK_FALSE(
      view.capabilities().exact_factorized_iid_generator.has_value());
  CHECK(view.configured_law().schema ==
        mwperf::PortableArrivalLawSchema::iid_independent_poisson_v1);
  CHECK(byte_hex(view.configured_law().canonical_data) ==
        "00000000000000336d77706572662e6330392e636f6d70696c65645f6172726976"
        "616c5f776974685f6e6f726d616c697a65645f726f77732e763100000000000000"
        "6e00000000000000256d77706572662e6333322e6969645f696e646570656e6465"
        "6e745f706f6973736f6e2e76310000000100000000000000020000000000000001"
        "31000000000000000231303fb999999999999a0000000000000001300000000000"
        "0000013100000000000000000000000000000000");
  CHECK((view.positive_support().bytes() ==
         std::vector<std::uint8_t>{1U, 0U}));
  REQUIRE(view.moments().has_value());
  REQUIRE(view.moments()->size() == 4U);
  CHECK(view.moments()->at(0U).value == rational(1, 10));
  CHECK(view.moments()->at(1U).value == rational(11, 100));
  CHECK(view.moments()->at(2U).value == rational(0, 1));
  CHECK(view.moments()->at(3U).value == rational(0, 1));

  auto first = make_process(fixture.law, 3210U);
  auto second = make_process(fixture.law, 3210U);
  for (std::uint64_t slot = 0U; slot < 64U; ++slot) {
    auto first_step =
        mwperf::next_arrival_step(first, mwperf::BigNat(slot));
    auto second_step =
        mwperf::next_arrival_step(second, mwperf::BigNat(slot));
    REQUIRE(first_step);
    REQUIRE(second_step);
    CHECK(first_step.value().batch == second_step.value().batch);
    CHECK(count_at(first_step.value().batch, fixture, 1U) ==
          mwperf::BigNat(0U));
  }
}

TEST_CASE("CP09 Poisson operational rates round exact decimal ties to even",
          "[c32][cp09][unit][arrival][poisson]") {
  // (2^53+1)/2^53 is exactly halfway above 1 and rounds to the even lower
  // significand.  (2^53+3)/2^53 is the next midpoint and rounds to the even
  // upper significand.  These are the same cross-language KATs used by the
  // Rust CP09 arrival decoder/sampler.
  for (const auto& [decimal, expected_bits] :
       std::array<std::pair<std::string_view, std::uint64_t>, 2U>{
           {{"1.00000000000000011102230246251565404236316680908203125",
             UINT64_C(0x3ff0000000000000)},
            {"1.00000000000000033306690738754696212708950042724609375",
             UINT64_C(0x3ff0000000000002)}}}) {
    const std::string arrival =
        R"({"family":"iid_independent_poisson","rates":{"default":0,"overrides":[{"queue_id":"q0","rate":)" +
        std::string(decimal) + R"(}]},"metadata":{}})";
    auto fixture = compile_schema4(arrival);
    const mwperf::BuilderArrivalView view =
        mwperf::builder_arrival_view(fixture.law);
    const auto& bytes =
        view.configured_law().canonical_data;
    // After q0's operational word the two-queue recipe contains q1's framed
    // exact 0/1 value and word, followed by the outer zero-row count.
    REQUIRE(bytes.size() >= 42U);
    CHECK(read_u64_be(bytes, bytes.size() - 42U) == expected_bits);
  }

  auto too_large = parse_schema4(schema4_model(
      R"({"family":"iid_independent_poisson","rates":{"default":0,"overrides":[{"queue_id":"q0","rate":4503599627370497}]},"metadata":{}})",
      false));
  auto queues = mwperf::build_queue_catalog(too_large.switch_config);
  REQUIRE(queues);
  auto refused = mwperf::compile_arrival_law(too_large.arrival, queues.value());
  REQUIRE_FALSE(refused);
  CHECK(refused.error().code ==
        "schema4_poisson_operational_rate_out_of_range");
}

TEST_CASE("CP09 shared mixed Poisson compiles exact products and covariance",
          "[c32][cp09][unit][arrival][poisson]") {
  auto fixture = compile_schema4(
      R"({"family":"iid_mixed_poisson","rates":{"default":0.1,"overrides":[]},"modulation":{"scope":"shared","states":[{"id":"on","probability":0.5,"multiplier":2},{"id":"off","probability":0.5,"multiplier":0}]},"metadata":{}})");
  CHECK(fixture.law.family() == mwperf::ArrivalFamily::iid_mixed_poisson);
  CHECK(fixture.law.variant().index() == 9U);
  const mwperf::BuilderArrivalView view =
      mwperf::builder_arrival_view(fixture.law);
  REQUIRE(view.capabilities().exact_portable_iid_recipe.has_value());
  // A shared modulation state creates within-slot dependence.  Its exact
  // portable IID recipe must never be mislabeled as factorized.
  CHECK_FALSE(
      view.capabilities().exact_factorized_iid_generator.has_value());
  CHECK(view.configured_law().schema ==
        mwperf::PortableArrivalLawSchema::iid_mixed_poisson_v1);
  // Queue-major/state-minor exact products preserve authored (not sorted)
  // state order: 0.1*2, 0.1*0 for each queue, followed only by the outer C09
  // zero normalized-row count.
  CHECK(byte_hex(view.configured_law().canonical_data)
            .ends_with("3fc999999999999a0000000000000000"
                       "3fc999999999999a0000000000000000"
                       "0000000000000000"));
  REQUIRE(view.moments().has_value());
  CHECK(view.moments()->at(0U).value == rational(1, 10));
  CHECK(view.moments()->at(1U).value == rational(3, 25));
  REQUIRE(view.covariances().has_value());
  REQUIRE(view.covariances()->size() == 3U);
  CHECK(view.covariances()->at(0U).value == rational(11, 100));
  CHECK(view.covariances()->at(1U).value == rational(1, 100));
  CHECK(view.covariances()->at(2U).value == rational(11, 100));
}
