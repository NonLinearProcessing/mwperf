#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct CrossbarFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::CrossbarProblem problem;
};

struct Query final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c06-crossbar-unit";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string crossbar_model(
    const std::string& queues, const std::string& constraint,
    const std::string& priority = "null") {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues +
         R"(},"scheduler":{"name":"crossbar_max_weight","params":{"constraint":)" +
         constraint + R"(,"priority":)" + priority +
         R"(}},"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] CrossbarFixture make_fixture(
    const std::string& queues, const std::string& constraint,
    const std::string& priority_text = "null") {
  auto document = mwperf::load_document(
      write_model(crossbar_model(queues, constraint, priority_text)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  REQUIRE(descriptor.value().family() ==
          mwperf::ServiceFamily::crossbar_matching);
  const auto& resolved = std::get<mwperf::ResolvedCrossbarConstraint>(
      descriptor.value().value());
  auto problem = mwperf::compile_crossbar_problem(resolved);
  INFO((problem ? std::string{} : problem.error().code));
  REQUIRE(problem);
  return CrossbarFixture{std::move(catalog).value(),
                         std::move(priority).value(),
                         std::move(descriptor).value(),
                         std::move(problem).value()};
}

[[nodiscard]] mwperf::Result<mwperf::ConstraintDescriptor>
compile_attempt(const std::string& queues, const std::string& constraint) {
  auto document = mwperf::load_document(
      write_model(crossbar_model(queues, constraint)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  return mwperf::compile_constraint_descriptor(model.value().scheduler,
                                                catalog.value());
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 zero_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '0'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const CrossbarFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      zero_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] Query make_query(
    const CrossbarFixture& fixture, std::vector<mwperf::BigNat> primary_values,
    std::vector<std::uint8_t> eligibility_values) {
  const auto token = dimension(fixture);
  auto primary = mwperf::PrimaryWeights::from_values(
      token, std::move(primary_values));
  REQUIRE(primary);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, std::move(eligibility_values));
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  INFO((weights ? std::string{} : weights.error().code));
  REQUIRE(weights);
  return Query{std::move(primary).value(), std::move(eligibility).value(),
               std::move(weights).value()};
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] mwperf::OptimizerExecutionContext context_for(
    const mwperf::QueueDimensionToken& token) {
  auto context = mwperf::OptimizerExecutionContext::for_fixture(
      unlimited_policy(), std::nullopt, token);
  REQUIRE(context);
  return std::move(context).value();
}

[[nodiscard]] std::string sparse_optional_constraint() {
  return R"({"inputs":["i0","i1"],"outputs":["o0","o1","o2"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"}]})";
}

[[nodiscard]] std::string two_choice_constraint() {
  return R"({"inputs":["i0"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"}]})";
}

}  // namespace

TEST_CASE("C06 crossbar solves an optional sparse matching without a cardinality objective",
          "[c06][unit][crossbar]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])", sparse_optional_constraint());
  const auto query = make_query(fixture, naturals({10U, 4U, 4U}),
                                {1U, 1U, 1U});

  auto solved = mwperf::detail::solve_crossbar_exact(
      fixture.problem, query.eligibility, query.weights, nullptr);
  INFO((solved ? std::string{} : solved.error().code));
  REQUIRE(solved);

  // q1+q2 is a feasible cardinality-two matching with composite score 67.
  // The exact objective instead selects q0 alone with score 84.
  CHECK((schedule_bits(solved.value().schedule) ==
         std::vector<std::uint8_t>{1U, 0U, 0U}));
  CHECK(solved.value().composite_objective.to_decimal_string() == "84");
  CHECK(fixture.problem.input_count() == 2U);
  CHECK(fixture.problem.output_count() == 3U);
  CHECK(fixture.problem.padded_dimension() == 5U);
  CHECK(fixture.problem.own_dummy_column(1U) == 4U);
  CHECK(fixture.problem.own_dummy_row(2U) == 4U);
}

TEST_CASE("C06 crossbar keeps forbidden real arcs structural during augmentation",
          "[c06][unit][negative][crossbar]") {
  const auto fixture = make_fixture(
      R"(["q0","q1"])",
      R"({"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"}]})");
  const auto query =
      make_query(fixture, naturals({3U, 2U}), {1U, 1U});

  auto ordinary = mwperf::detail::solve_crossbar_exact(
      fixture.problem, query.eligibility, query.weights, nullptr);
  REQUIRE(ordinary);
  CHECK((schedule_bits(ordinary.value().schedule) ==
         std::vector<std::uint8_t>{1U, 1U}));

  auto faulted = mwperf::detail::solve_crossbar_exact_with_fault(
      fixture.problem, query.eligibility, query.weights, nullptr,
      mwperf::detail::CrossbarTestFault::force_forbidden_assignment);
  REQUIRE_FALSE(faulted);
  CHECK(faulted.error().code == "crossbar_hungarian_forbidden_arc");
  CHECK(faulted.error().category == mwperf::DiagnosticCategory::internal);

  auto invalid_fault = mwperf::detail::solve_crossbar_exact_with_fault(
      fixture.problem, query.eligibility, query.weights, nullptr,
      static_cast<mwperf::detail::CrossbarTestFault>(255U));
  REQUIRE_FALSE(invalid_fault);
  CHECK(invalid_fault.error().code == "crossbar_test_fault_invalid");
}

TEST_CASE("C06 crossbar empty eligibility projects the all-unmatched assignment",
          "[c06][unit][crossbar]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])", sparse_optional_constraint());
  const auto query = make_query(fixture, naturals({9U, 8U, 7U}),
                                {0U, 0U, 0U});

  auto solved = mwperf::detail::solve_crossbar_exact(
      fixture.problem, query.eligibility, query.weights, nullptr);
  REQUIRE(solved);
  CHECK((schedule_bits(solved.value().schedule) ==
         std::vector<std::uint8_t>{0U, 0U, 0U}));
  CHECK(solved.value().composite_objective.is_zero());
}

TEST_CASE("C06 crossbar follows supplied priority only on an equal-primary face",
          "[c06][unit][crossbar]") {
  const auto forward = make_fixture(R"(["q0","q1"])",
                                    two_choice_constraint(),
                                    R"(["q0","q1"])");
  const auto reverse = make_fixture(R"(["q0","q1"])",
                                    two_choice_constraint(),
                                    R"(["q1","q0"])");
  const auto forward_query =
      make_query(forward, naturals({5U, 5U}), {1U, 1U});
  const auto reverse_query =
      make_query(reverse, naturals({5U, 5U}), {1U, 1U});

  auto forward_solved = mwperf::detail::solve_crossbar_exact(
      forward.problem, forward_query.eligibility, forward_query.weights,
      nullptr);
  auto reverse_solved = mwperf::detail::solve_crossbar_exact(
      reverse.problem, reverse_query.eligibility, reverse_query.weights,
      nullptr);
  REQUIRE(forward_solved);
  REQUIRE(reverse_solved);
  CHECK((schedule_bits(forward_solved.value().schedule) ==
         std::vector<std::uint8_t>{1U, 0U}));
  CHECK((schedule_bits(reverse_solved.value().schedule) ==
         std::vector<std::uint8_t>{0U, 1U}));

  // With q1 preferred, q0's one-unit primary advantage is still decisive:
  // 1*4+1 is greater than q1's largest possible secondary bit 2.
  const auto dominance =
      make_query(reverse, naturals({1U, 0U}), {1U, 1U});
  auto dominant = mwperf::detail::solve_crossbar_exact(
      reverse.problem, dominance.eligibility, dominance.weights, nullptr);
  REQUIRE(dominant);
  CHECK((schedule_bits(dominant.value().schedule) ==
         std::vector<std::uint8_t>{1U, 0U}));
  CHECK(dominant.value().composite_objective.to_decimal_string() == "5");
}

TEST_CASE("C06 crossbar rejects malformed bound and compiled geometry",
          "[c06][negative][crossbar]") {
  SECTION("authored duplicate input labels") {
    auto result = compile_attempt(
        R"(["q0"])",
        R"({"inputs":["i","i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_crossbar_input");
  }

  SECTION("authored undeclared endpoint") {
    auto result = compile_attempt(
        R"(["q0"])",
        R"({"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"missing"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "undeclared_crossbar_output");
  }

  SECTION("authored duplicate endpoint pair") {
    auto result = compile_attempt(
        R"(["q0","q1"])",
        R"({"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"},{"queue_id":"q1","input":"i","output":"o"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_crossbar_endpoint_pair");
  }

  SECTION("authored missing queue coverage") {
    auto result = compile_attempt(
        R"(["q0","q1"])",
        R"({"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }

  const auto fixture = make_fixture(
      R"(["q0","q1"])",
      R"({"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"}]})");
  const auto& resolved = std::get<mwperf::ResolvedCrossbarConstraint>(
      fixture.descriptor.value());

  SECTION("C06 rechecks dense input indices") {
    auto corrupt = resolved;
    corrupt.inputs[1U].index = corrupt.inputs[0U].index;
    auto result = mwperf::compile_crossbar_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "crossbar_compiled_input_index_invalid");
  }

  SECTION("C06 rechecks duplicate endpoint pairs") {
    auto corrupt = resolved;
    corrupt.edges[1U].input = corrupt.edges[0U].input;
    corrupt.edges[1U].output = corrupt.edges[0U].output;
    auto result = mwperf::compile_crossbar_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "crossbar_compiled_endpoint_duplicate");
  }

  SECTION("C06 rechecks dense queue coverage") {
    auto corrupt = resolved;
    corrupt.edges[1U].queue = corrupt.edges[0U].queue;
    auto result = mwperf::compile_crossbar_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "crossbar_compiled_queue_coverage_invalid");
  }

  SECTION("solve rejects corrupt sparse adjacency") {
    const auto query =
        make_query(fixture, naturals({1U, 1U}), {1U, 1U});
    std::vector<mwperf::CrossbarQueueEdge> edges(
        fixture.problem.queue_edges().begin(),
        fixture.problem.queue_edges().end());
    std::vector<std::vector<std::size_t>> rows{
        fixture.problem.row_edge_queues().front()};
    auto corrupt = mwperf::CrossbarProblem::for_test(
        fixture.problem.input_count(), fixture.problem.output_count(),
        std::move(edges), std::move(rows));
    auto result = mwperf::detail::solve_crossbar_exact(
        corrupt, query.eligibility, query.weights, nullptr);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "crossbar_problem_adjacency_dimension_mismatch");
  }
}

TEST_CASE("C06 crossbar rejects eligibility and weight shape mismatches",
          "[c06][negative][crossbar]") {
  const auto fixture = make_fixture(R"(["q0","q1"])",
                                    two_choice_constraint());
  auto malformed_mask = mwperf::EligibilityMask::from_bytes(
      dimension(fixture), {1U});
  REQUIRE_FALSE(malformed_mask);
  CHECK(malformed_mask.error().code == "eligibility_dimension_mismatch");

  const auto one_queue = make_fixture(
      R"(["q0"])",
      R"({"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q0","input":"i","output":"o"}]})");
  const auto foreign_query =
      make_query(one_queue, naturals({1U}), {1U});
  auto result = mwperf::detail::solve_crossbar_exact(
      fixture.problem, foreign_query.eligibility, foreign_query.weights,
      nullptr);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "crossbar_query_dimension_mismatch");
}

TEST_CASE("C06 crossbar forced target uses residual primary weights",
          "[c06][unit][crossbar][forced]") {
  const auto fixture = make_fixture(
      R"(["q0","q1","q2"])", sparse_optional_constraint());
  const auto query = make_query(fixture, naturals({100U, 4U, 5U}),
                                {0U, 1U, 1U});
  auto target = mwperf::TargetIndex::from_dimension(
      query.primary.dimension(), 0U);
  REQUIRE(target);
  auto context = context_for(query.primary.dimension());

  auto forced_zero = mwperf::solve_forced_target(
      context, fixture.descriptor, query.eligibility, query.primary,
      target.value(), mwperf::ForcedTargetBit::zero, fixture.priority);
  INFO((forced_zero ? std::string{} : forced_zero.error().code));
  REQUIRE(forced_zero);
  CHECK(forced_zero.value().value.to_decimal_string() == "9");
  CHECK((schedule_bits(forced_zero.value().witness) ==
         std::vector<std::uint8_t>{0U, 1U, 1U}));
  CHECK(forced_zero.value().accounting.completed_expansions().is_zero());

  auto forced_one = mwperf::solve_forced_target(
      context, fixture.descriptor, query.eligibility, query.primary,
      target.value(), mwperf::ForcedTargetBit::one, fixture.priority);
  INFO((forced_one ? std::string{} : forced_one.error().code));
  REQUIRE(forced_one);
  CHECK(forced_one.value().value.is_zero());
  CHECK((schedule_bits(forced_one.value().witness) ==
         std::vector<std::uint8_t>{1U, 0U, 0U}));
  CHECK(forced_one.value().accounting.completed_expansions().is_zero());

  // The target is ordinarily ineligible and its primary coordinate is not
  // part of either residual objective.
  const auto changed_target = make_query(
      fixture, naturals({999999U, 4U, 5U}), {0U, 1U, 1U});
  auto changed_zero = mwperf::solve_forced_target(
      context, fixture.descriptor, changed_target.eligibility,
      changed_target.primary, target.value(), mwperf::ForcedTargetBit::zero,
      fixture.priority);
  auto changed_one = mwperf::solve_forced_target(
      context, fixture.descriptor, changed_target.eligibility,
      changed_target.primary, target.value(), mwperf::ForcedTargetBit::one,
      fixture.priority);
  REQUIRE(changed_zero);
  REQUIRE(changed_one);
  CHECK(changed_zero.value().value == forced_zero.value().value);
  CHECK(changed_one.value().value == forced_one.value().value);
}
