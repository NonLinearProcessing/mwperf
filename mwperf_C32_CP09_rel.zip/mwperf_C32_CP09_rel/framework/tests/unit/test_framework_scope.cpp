#include <atomic>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

[[nodiscard]] std::filesystem::path write_scope_fixture(
    const std::string_view stem, const std::string_view suffix,
    const std::string_view contents) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c04-scope";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (std::string(stem) + std::to_string(next.fetch_add(1U)) +
                     std::string(suffix));
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedPair parse_scope_pair(const std::string& model_text,
                                          const std::string& analysis_text) {
  const auto model_path = write_scope_fixture("model", ".json", model_text);
  const auto analysis_path =
      write_scope_fixture("analysis", ".json", analysis_text);
  auto model_document = mwperf::load_document(model_path);
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto analysis_document = mwperf::load_document(analysis_path);
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((!analysis ? analysis.error().code + ": " + analysis.error().message
                  : std::string{}));
  REQUIRE(analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      model.value(), analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(model).value(), std::move(analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] std::string scope_analysis() {
  return R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"m","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":null,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })json";
}

[[nodiscard]] std::string conflict_model(
    const std::string_view capacity = "null") {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "switch":{"kind":"generalized","queue_capacity":)json") +
         std::string(capacity) + R"json(,"queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":1}]},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
}

}  // namespace

TEST_CASE("C04 public resolution reaches C09 after exact constraint compilation",
          "[c04][unit]") {
  const ParsedPair pair = parse_scope_pair(conflict_model(), scope_analysis());
  const auto resolved = mwperf::resolve_physical_instance(
      pair.model, pair.analysis, pair.fingerprints);
  INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                  : std::string{}));
  REQUIRE(resolved);
  CHECK(resolved.value().arrival().family() ==
        mwperf::ArrivalFamily::deterministic_trace);
  CHECK(resolved.value().arrival().has_compiled_product());
  CHECK(resolved.value().arrival().compiled_product_kind() ==
        mwperf::ArrivalCompiledProductKind::compiled_arrival_law_v1);
  const auto q0 = resolved.value().queues().index_at(0U);
  const auto q1 = resolved.value().queues().index_at(1U);
  REQUIRE(q0);
  REQUIRE(q1);
  CHECK(resolved.value().positive_arrival_support().at(q0.value()));
  CHECK_FALSE(resolved.value().positive_arrival_support().at(q1.value()));
}

TEST_CASE("C04 retains a finite buffer declaration without changing resolution",
          "[c04][unit]") {
  const ParsedPair pair =
      parse_scope_pair(conflict_model("9223372036854775807"), scope_analysis());
  const auto resolved = mwperf::resolve_physical_instance(
      pair.model, pair.analysis, pair.fingerprints);
  INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                  : std::string{}));
  REQUIRE(resolved);
  const auto* generalized = std::get_if<mwperf::GeneralizedSwitchConfig>(
      &resolved.value().authored_model().switch_config);
  REQUIRE(generalized != nullptr);
  REQUIRE(generalized->queue_capacity.value.has_value());
  CHECK(generalized->queue_capacity.value->to_decimal_string() ==
        "9223372036854775807");
}

TEST_CASE("C27.1 finite capacity binds into the problem view",
          "[c04][c27_1][integration]") {
  const ParsedPair pair =
      parse_scope_pair(conflict_model("64"), scope_analysis());
  auto resolved = mwperf::resolve_physical_instance(
      pair.model, pair.analysis, pair.fingerprints);
  INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                  : std::string{}));
  REQUIRE(resolved);
  REQUIRE(resolved.value().arrival().family() ==
          mwperf::ArrivalFamily::deterministic_trace);

  auto arrival = mwperf::detail::CompiledArrivalAccess::get(
      resolved.value().arrival());
  REQUIRE(arrival);
  auto group = mwperf::TypedLabel::text("c27.1.canonical.input");
  REQUIRE(group);
  REQUIRE(resolved.value().targets().values().size() == 1U);
  const mwperf::ResolvedTarget& target =
      resolved.value().targets().values().front();
  const mwperf::TargetSelection selection{
      1U,
      {resolved.value().queues().queue_id(target.queue)},
      mwperf::ConstructionGroupIdV1(std::move(group).value())};
  auto view = mwperf::build_framework_problem_view(
      resolved.value(), *arrival.value(), selection);
  INFO((!view ? view.error().code + ": " + view.error().message
              : std::string{}));
  REQUIRE(view);
  REQUIRE(view.value().units_and_encodings().queue_capacity.has_value());
  CHECK(*view.value().units_and_encodings().queue_capacity ==
        mwperf::BigNat{64U});
}

TEST_CASE("C04 rejects a foreign fingerprint bundle before child selection",
          "[c04][unit][negative]") {
  const ParsedPair first =
      parse_scope_pair(conflict_model(), scope_analysis());
  std::string changed = scope_analysis();
  const std::string needle = R"("targets":["q0"])";
  const auto position = changed.find(needle);
  REQUIRE(position != std::string::npos);
  changed.replace(position, needle.size(), R"("targets":["q1"])" );
  const ParsedPair second = parse_scope_pair(conflict_model(), changed);

  const auto resolved = mwperf::resolve_physical_instance(
      first.model, first.analysis, second.fingerprints);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(resolved.error().code == "input_fingerprint_mismatch");
}

TEST_CASE("C04 positive-support masks are exact binary dense values",
          "[c04][unit][negative]") {
  auto valid = mwperf::QueueMask::from_bytes({1U, 0U, 1U}, 3U);
  REQUIRE(valid);
  CHECK(valid.value().bytes() == std::vector<std::uint8_t>{1U, 0U, 1U});

  auto wrong_size = mwperf::QueueMask::from_bytes({1U}, 2U);
  REQUIRE_FALSE(wrong_size);
  CHECK(wrong_size.error().code == "arrival_support_dimension_mismatch");

  auto non_binary = mwperf::QueueMask::from_bytes({2U}, 1U);
  REQUIRE_FALSE(non_binary);
  CHECK(non_binary.error().code == "arrival_support_mask_not_binary");
}

TEST_CASE("C04 reports legacy and compatibility scope exclusions",
          "[c04][unit][negative]") {
  SECTION("legacy switch") {
    const ParsedPair pair = parse_scope_pair(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":{"family":"deterministic_trace","events":[]}})",
        scope_analysis());
    const auto resolved = mwperf::resolve_physical_instance(
        pair.model, pair.analysis, pair.fingerprints);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(resolved.error().code == "unsupported_switch_kind");
  }

  SECTION("compatibility scheduler") {
    const ParsedPair pair = parse_scope_pair(
        R"({"switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":"q1"}]},"scheduler":{"name":"random_maximal","params":{}},"arrival":{"family":"deterministic_trace","events":[]}})",
        scope_analysis());
    const auto resolved = mwperf::resolve_physical_instance(
        pair.model, pair.analysis, pair.fingerprints);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(resolved.error().code == "unsupported_scheduler_family");
  }
}
