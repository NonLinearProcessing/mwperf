#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/shared_round_renewal.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

using SharedStepSignature = mwperf::Result<mwperf::ArrivalStep> (*)(
    mwperf::SharedRoundCursor&, const mwperf::BigNat&);

static_assert(std::same_as<decltype(&mwperf::next_shared_round_batch),
                           SharedStepSignature>);
static_assert(std::same_as<mwperf::SharedRoundCursor,
                           mwperf::ArrivalProcess>);
static_assert(!std::is_default_constructible_v<mwperf::SharedRoundLaw>);
static_assert(std::is_copy_constructible_v<mwperf::SharedRoundLaw>);

struct ParsedArrival final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c11-shared-round-renewal";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string model_document(const std::string_view arrival) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
                 "params":{"constraint":{"conflicts":[]},
                           "priority":["q0","q1","q2"],
                           "max_search_states":null}},
    "arrival":)json") +
         std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] ParsedArrival parse_arrival(const std::string_view arrival) {
  auto document = mwperf::load_document(write_fixture(model_document(arrival)));
  INFO((!document ? document.error().code + ": " + document.error().message
                  : std::string{}));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedArrival{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] const mwperf::SharedJointRoundMarkovRenewalArrival& authored(
    const ParsedArrival& parsed) {
  return std::get<mwperf::SharedJointRoundMarkovRenewalArrival>(
      parsed.model.arrival.value);
}

[[nodiscard]] mwperf::SharedRoundLaw compile_geometry(
    const ParsedArrival& parsed) {
  auto result =
      mwperf::compile_shared_round_renewal(authored(parsed), parsed.queues);
  INFO((!result ? result.error().code + ": " + result.error().message
                : std::string{}));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::CompiledArrivalLaw publish(
    const ParsedArrival& parsed) {
  auto result =
      mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  INFO((!result ? result.error().code + ": " + result.error().message
                : std::string{}));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t instance = 0U) {
  auto digest = mwperf::sha256(std::span<const std::byte>{});
  REQUIRE(digest);
  auto key = mwperf::make_physical_reference_instance_key(
      digest.value(), mwperf::BigNat(instance));
  REQUIRE(key);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law, const std::string_view state,
    const std::uint64_t seed = 1101U,
    const std::uint64_t instance = 0U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, instance));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, mwperf::ArrivalInitialState{mwperf::SharedRoundState{
               std::string(state)}},
      std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::BigNat count_at(const mwperf::ArrivalBatch& batch,
                                      const std::size_t queue) {
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    if (entry.queue.ordinal() == queue) {
      return entry.count;
    }
  }
  return mwperf::BigNat(0U);
}

[[nodiscard]] std::vector<std::byte> phase_bytes(
    const mwperf::ArrivalPhase& phase) {
  const auto bytes = mwperf::arrival_phase_canonical_state(phase);
  return std::vector<std::byte>(bytes.begin(), bytes.end());
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto result = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(result);
  return std::move(result).value();
}

void check_same_snapshot(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  CHECK(left.expected_slot == right.expected_slot);
  CHECK(left.phase_digest == right.phase_digest);
  CHECK(left.rng.rng_version() == right.rng.rng_version());
  CHECK(left.rng.stream_identity() == right.rng.stream_identity());
  CHECK(left.rng.state_words() == right.rng.state_words());
  CHECK(left.rng.consumed_words() == right.rng.consumed_words());
}

void check_replay_step(const mwperf::ArrivalStep& left,
                       const mwperf::ArrivalStep& right) {
  CHECK(left.authored_slot == right.authored_slot);
  CHECK(left.batch == right.batch);
  CHECK(left.law_digest == right.law_digest);
  CHECK(left.realization_identity == right.realization_identity);
  CHECK(phase_bytes(left.phase_before) == phase_bytes(right.phase_before));
  CHECK(phase_bytes(left.phase_after) == phase_bytes(right.phase_after));
}

void check_conservative_capabilities(const mwperf::CompiledArrivalLaw& law) {
  const mwperf::ArrivalCapabilities capabilities =
      mwperf::arrival_capabilities(law);
  CHECK(capabilities.version == 1U);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());
}

}  // namespace

TEST_CASE("C11 shared D=1 starts in slot zero and remains consecutive",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"source"}],
    "states":["on"],"initial":{"state":"on"},
    "outcomes":[{"state":"on","next_state":"on","probability":1,
      "emissions":[{"source_id":"source","d":1,"queue_id":"q0"}]}],
    "metadata":{}
  })json");

  const mwperf::SharedRoundLaw geometry = compile_geometry(parsed);
  REQUIRE(geometry.source_ids().size() == 1U);
  REQUIRE(geometry.states().size() == 1U);
  REQUIRE(geometry.states()[0U].outcomes.size() == 1U);
  CHECK(geometry.states()[0U].outcomes[0U].emissions[0U].gap ==
        mwperf::BigNat(1U));

  const mwperf::CompiledArrivalLaw law = publish(parsed);
  auto process = instantiate(law, "on");
  const auto before = snapshot(process);
  CHECK(before.rng.consumed_words().is_zero());
  for (std::uint64_t slot = 0U; slot < 7U; ++slot) {
    auto step = mwperf::next_shared_round_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(step.value().authored_slot == mwperf::BigNat(slot));
    CHECK(step.value().physical_arrival_epoch() == mwperf::BigNat(slot + 1U));
    REQUIRE(step.value().batch.entries().size() == 1U);
    CHECK(count_at(step.value().batch, 0U) == mwperf::BigNat(1U));
  }
  CHECK(snapshot(process).rng.consumed_words().is_zero());
}

TEST_CASE("C11 shared rounds retain asynchronous D=1 and D=3 clocks",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"fast"},{"id":"slow"}],
    "states":["on"],"initial":{"state":"on"},
    "outcomes":[{"state":"on","next_state":"on","probability":1,
      "emissions":[
        {"source_id":"fast","d":1,"queue_id":"q0"},
        {"source_id":"slow","d":3,"queue_id":"q1"}]}],
    "metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = publish(parsed);
  auto process = instantiate(law, "on");

  for (std::uint64_t slot = 0U; slot < 10U; ++slot) {
    auto step = mwperf::next_shared_round_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(count_at(step.value().batch, 0U) == mwperf::BigNat(1U));
    const bool slow_event = slot == 2U || slot == 5U || slot == 8U;
    CHECK(count_at(step.value().batch, 1U) ==
          mwperf::BigNat(slow_event ? 1U : 0U));
    CHECK(step.value().batch.entries().size() ==
          static_cast<std::size_t>(slow_event ? 2U : 1U));
  }
}

TEST_CASE("C11 one sampled shared outcome preserves paired marks and replay",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"left"},{"id":"right"}],
    "states":["on"],"initial":{"state":"on"},
    "outcomes":[
      {"state":"on","next_state":"on","probability":0.5,
       "emissions":[{"source_id":"left","d":1,"queue_id":"q0"},
                    {"source_id":"right","d":1,"queue_id":"q0"}]},
      {"state":"on","next_state":"on","probability":0.5,
       "emissions":[{"source_id":"left","d":1,"queue_id":"q1"},
                    {"source_id":"right","d":1,"queue_id":"q1"}]}
    ],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = publish(parsed);
  auto first = instantiate(law, "on", 7741U, 12U);
  auto replay = instantiate(law, "on", 7741U, 12U);
  bool saw_q0 = false;
  bool saw_q1 = false;

  for (std::uint64_t slot = 0U; slot < 128U; ++slot) {
    auto left = mwperf::next_shared_round_batch(first, mwperf::BigNat(slot));
    auto right = mwperf::next_shared_round_batch(replay, mwperf::BigNat(slot));
    REQUIRE(left);
    REQUIRE(right);
    check_replay_step(left.value(), right.value());

    // A single outcome is projected to both sources.  Thus a batch is either
    // 2*q0 or 2*q1 and can never contain an independently recombined pair.
    REQUIRE(left.value().batch.entries().size() == 1U);
    const auto& entry = left.value().batch.entries().front();
    CHECK(entry.count == mwperf::BigNat(2U));
    REQUIRE((entry.queue.ordinal() == 0U || entry.queue.ordinal() == 1U));
    saw_q0 = saw_q0 || entry.queue.ordinal() == 0U;
    saw_q1 = saw_q1 || entry.queue.ordinal() == 1U;
  }
  CHECK(saw_q0);
  CHECK(saw_q1);

  const auto first_snapshot = snapshot(first);
  const auto replay_snapshot = snapshot(replay);
  CHECK(first_snapshot.expected_slot == replay_snapshot.expected_slot);
  CHECK(first_snapshot.phase_digest == replay_snapshot.phase_digest);
  CHECK(first_snapshot.rng.stream_identity() ==
        replay_snapshot.rng.stream_identity());
  CHECK(first_snapshot.rng.state_words() == replay_snapshot.rng.state_words());
  CHECK(first_snapshot.rng.consumed_words() ==
        replay_snapshot.rng.consumed_words());
}

TEST_CASE("C11 slow-source future marks remain pending across fast rounds",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"fast"},{"id":"slow"}],
    "states":["even","odd"],"initial":{"state":"even"},
    "outcomes":[
      {"state":"even","next_state":"odd","probability":1,
       "emissions":[{"source_id":"fast","d":1,"queue_id":"q2"},
                    {"source_id":"slow","d":5,"queue_id":"q0"}]},
      {"state":"odd","next_state":"even","probability":1,
       "emissions":[{"source_id":"fast","d":1,"queue_id":"q2"},
                    {"source_id":"slow","d":5,"queue_id":"q1"}]}
    ],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = publish(parsed);
  auto process = instantiate(law, "even");
  std::size_t one_round_phase_size = 0U;
  std::size_t four_round_phase_size = 0U;

  for (std::uint64_t slot = 0U; slot <= 14U; ++slot) {
    auto step = mwperf::next_shared_round_batch(process, mwperf::BigNat(slot));
    REQUIRE(step);
    CHECK(count_at(step.value().batch, 2U) == mwperf::BigNat(1U));
    CHECK(count_at(step.value().batch, 0U) ==
          mwperf::BigNat(slot == 4U || slot == 14U ? 1U : 0U));
    CHECK(count_at(step.value().batch, 1U) ==
          mwperf::BigNat(slot == 9U ? 1U : 0U));
    if (slot == 0U) {
      one_round_phase_size = phase_bytes(step.value().phase_after).size();
    }
    if (slot == 3U) {
      four_round_phase_size = phase_bytes(step.value().phase_after).size();
    }
  }
  // Repeated fast-source extensions materialize and retain several slow
  // events.  Their canonical phase representation therefore grows.
  CHECK(four_round_phase_size > one_round_phase_size);
}

TEST_CASE("C11 supplied shared initial state is installed without redraw",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"source"}],
    "states":["short","long"],
    "initial":{"distribution":[
      {"state":"short","probability":0.5},
      {"state":"long","probability":0.5}]},
    "outcomes":[
      {"state":"short","next_state":"short","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q0"}]},
      {"state":"long","next_state":"long","probability":1,
       "emissions":[{"source_id":"source","d":3,"queue_id":"q1"}]}
    ],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = publish(parsed);
  auto process = instantiate(law, "long", 9191U);

  CHECK(snapshot(process).rng.consumed_words().is_zero());
  auto zero = mwperf::next_shared_round_batch(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  CHECK(zero.value().batch.empty_batch());
  CHECK(snapshot(process).rng.consumed_words().is_zero());
  auto one = mwperf::next_shared_round_batch(process, mwperf::BigNat(1U));
  REQUIRE(one);
  CHECK(one.value().batch.empty_batch());
  auto two = mwperf::next_shared_round_batch(process, mwperf::BigNat(2U));
  REQUIRE(two);
  REQUIRE(two.value().batch.entries().size() == 1U);
  CHECK(count_at(two.value().batch, 1U) == mwperf::BigNat(1U));
  CHECK(count_at(two.value().batch, 0U).is_zero());
}

TEST_CASE("C11 shared support follows positive initial and outcome reachability",
          "[c11][unit]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"source"}],
    "states":["root","reachable","dead"],
    "initial":{"distribution":[
      {"state":"root","probability":1},
      {"state":"reachable","probability":0},
      {"state":"dead","probability":0}]},
    "outcomes":[
      {"state":"root","next_state":"reachable","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q0"}]},
      {"state":"root","next_state":"dead","probability":0,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q2"}]},
      {"state":"reachable","next_state":"reachable","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q1"}]},
      {"state":"dead","next_state":"dead","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q2"}]}
    ],"metadata":{}
  })json");

  const mwperf::SharedRoundLaw geometry = compile_geometry(parsed);
  CHECK(std::vector<std::uint8_t>(geometry.positive_support_bytes().begin(),
                                  geometry.positive_support_bytes().end()) ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  const mwperf::CompiledArrivalLaw law = publish(parsed);
  CHECK(mwperf::positive_arrival_support(law).bytes() ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  check_conservative_capabilities(law);
}

TEST_CASE("C11 shared compiler rejects malformed emissions and kernels",
          "[c11][unit][negative]") {
  struct Fixture final {
    std::string_view arrival;
    std::string_view expected_code;
  };
  const std::vector<Fixture> fixtures{
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"},{"id":"b"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[{"state":"s",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_source_emission_incomplete"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"},{"id":"b"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[{"state":"s",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"},
        {"source_id":"a","d":1,"queue_id":"q1"}]}],"metadata":{}})json",
       "shared_round_duplicate_source_emission"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[{"state":"s",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"ghost","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_emission_source_unknown"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[{"state":"s",
        "next_state":"missing","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_next_state_unknown"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[
        {"state":"s","next_state":"s","probability":0.5,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]},
        {"state":"s","next_state":"s","probability":0.5,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_duplicate_outcome"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s","orphan"],
        "initial":{"state":"s"},"outcomes":[{"state":"s",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_outgoing_row_missing"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s"],
        "initial":{"state":"missing"},"outcomes":[{"state":"s",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_initial_state_unknown"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"a"}],"states":["s"],
        "initial":{"state":"s"},"outcomes":[{"state":"ghost",
        "next_state":"s","probability":1,"emissions":[
        {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json",
       "shared_round_outcome_state_unknown"},
  };

  for (const Fixture& fixture : fixtures) {
    CAPTURE(fixture.expected_code);
    const ParsedArrival parsed = parse_arrival(fixture.arrival);
    auto result =
        mwperf::compile_shared_round_renewal(authored(parsed), parsed.queues);
    REQUIRE_FALSE(result);
    CHECK(result.error().category ==
          mwperf::DiagnosticCategory::input_validation);
    CHECK(result.error().code == fixture.expected_code);
  }

  // The parser independently rejects zero as a non-positive integer.  Inject
  // it through the typed seam to verify the C11 compiler repeats this critical
  // invariant for callers that construct authored records directly.
  ParsedArrival zero_gap = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"a"}],"states":["s"],
    "initial":{"state":"s"},"outcomes":[{"state":"s",
    "next_state":"s","probability":1,"emissions":[
    {"source_id":"a","d":1,"queue_id":"q0"}]}],"metadata":{}})json");
  auto& zero_gap_authored =
      std::get<mwperf::SharedJointRoundMarkovRenewalArrival>(
          zero_gap.model.arrival.value);
  zero_gap_authored.outcomes.value[0U].emissions.value[0U].d.value =
      mwperf::BigNat(0U);
  auto zero_gap_result = mwperf::compile_shared_round_renewal(
      zero_gap_authored, zero_gap.queues);
  REQUIRE_FALSE(zero_gap_result);
  CHECK(zero_gap_result.error().code == "shared_round_gap_nonpositive");
}

TEST_CASE("C11 shared cursor rejects zero-mass and unknown supplied initials",
          "[c11][unit][negative]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"source"}],"states":["live","zero"],
    "initial":{"distribution":[{"state":"live","probability":1},
                                  {"state":"zero","probability":0}]},
    "outcomes":[
      {"state":"live","next_state":"live","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q0"}]},
      {"state":"zero","next_state":"zero","probability":1,
       "emissions":[{"source_id":"source","d":1,"queue_id":"q1"}]}
    ],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = publish(parsed);

  for (const auto& [state, code] :
       std::vector<std::pair<std::string_view, std::string_view>>{
           {"zero", "shared_round_supplied_initial_state_zero_mass"},
           {"missing", "shared_round_supplied_initial_state_unknown"}}) {
    CAPTURE(state);
    auto stream = mwperf::make_configured_arrival_stream_key(
        law, configured_rng(551U));
    REQUIRE(stream);
    auto process = mwperf::instantiate_arrival_process(
        law,
        mwperf::ArrivalInitialState{
            mwperf::SharedRoundState{std::string(state)}},
        std::move(stream).value());
    REQUIRE_FALSE(process);
    CHECK(process.error().code == code);
  }
}

#if defined(MWPERF_C11_TEST_SEAMS)
TEST_CASE("C11 shared overflow rolls back staged rounds pending marks and RNG",
          "[c11][unit][negative][transaction]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"fast"},{"id":"slow"}],
    "states":["s"],"initial":{"state":"s"},
    "outcomes":[
      {"state":"s","next_state":"s","probability":0.5,"emissions":[
        {"source_id":"fast","d":1,"queue_id":"q0"},
        {"source_id":"slow","d":3,"queue_id":"q1"}]},
      {"state":"s","next_state":"s","probability":0.5,"emissions":[
        {"source_id":"fast","d":1,"queue_id":"q1"},
        {"source_id":"slow","d":3,"queue_id":"q0"}]}
    ],"metadata":{}
  })json");
  auto law = mwperf::testing::make_shared_round_overflow_fixture_law(
      authored(parsed), parsed.queues, mwperf::BigNat(2U));
  REQUIRE(law);
  auto process = instantiate(law.value(), "s", 5511U);
  REQUIRE(mwperf::next_arrival_step(process, mwperf::BigNat(0U)));
  REQUIRE(mwperf::next_arrival_step(process, mwperf::BigNat(1U)));
  const auto before = snapshot(process);
  CHECK(before.rng.consumed_words() == mwperf::BigNat(2U));

  auto failed = mwperf::next_arrival_step(process, mwperf::BigNat(2U));
  REQUIRE_FALSE(failed);
  CHECK(failed.error().code == "arrival_count_overflow");
  check_same_snapshot(before, snapshot(process));

  auto retry = mwperf::next_arrival_step(process, mwperf::BigNat(2U));
  REQUIRE_FALSE(retry);
  CHECK(retry.error().code == "arrival_count_overflow");
  check_same_snapshot(before, snapshot(process));
}
#endif
