#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/metrics/palm_fifo.hpp"

namespace {

inline const mwperf::CodecIdentityV1 kTagTestCodec{
    "mwperf.c23.test.tag-state", 1U};

[[nodiscard]] mwperf::ReducedStateV1 state(const std::uint8_t value) {
  return {kTagTestCodec, {static_cast<std::byte>(value)}};
}

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TemporalServiceStep step(
    const std::uint8_t successor_state,
    const std::uint64_t successor_backlog,
    const std::uint8_t departure) {
  return {state(successor_state), mwperf::BigNat{successor_backlog},
          departure};
}

void check_survivor(const mwperf::TagTransition& transition,
                    const mwperf::ReducedStateV1& expected_state,
                    const mwperf::BigNat& expected_predecessors) {
  CHECK_FALSE(transition.tag_departed);
  REQUIRE(transition.survivor.has_value());
  CHECK(transition.survivor->untagged_state == expected_state);
  CHECK(transition.survivor->predecessors == expected_predecessors);
}

}  // namespace

TEST_CASE("C23 passive FIFO tag implements the exact four transition cases",
          "[c23][unit][fifo-tag]") {
  const mwperf::TagState ranked{state(0U), mwperf::BigNat{2U}};

  const auto denial = require_value(mwperf::advance_passive_fifo_tag(
      ranked, step(1U, 12U, 0U)));
  check_survivor(denial, state(1U), mwperf::BigNat{2U});

  const auto predecessor_departure = require_value(
      mwperf::advance_passive_fifo_tag(ranked, step(2U, 6U, 1U)));
  check_survivor(predecessor_departure, state(2U), mwperf::BigNat{1U});

  const mwperf::TagState head{state(0U), mwperf::BigNat{0U}};
  const auto head_denial = require_value(mwperf::advance_passive_fifo_tag(
      head, step(3U, 8U, 0U)));
  check_survivor(head_denial, state(3U), mwperf::BigNat{0U});

  const auto tag_departure = require_value(
      mwperf::advance_passive_fifo_tag(head, step(4U, 2U, 1U)));
  CHECK(tag_departure.tag_departed);
  CHECK_FALSE(tag_departure.survivor.has_value());
}

TEST_CASE("C23 later arrivals change total backlog but never predecessor rank",
          "[c23][unit][fifo-tag]") {
  const mwperf::TagState initial{state(0U), mwperf::BigNat{2U}};

  const auto arrivals_without_service = require_value(
      mwperf::advance_passive_fifo_tag(initial, step(1U, 17U, 0U)));
  check_survivor(arrivals_without_service, state(1U),
                 mwperf::BigNat{2U});

  const auto arrivals_with_predecessor_service = require_value(
      mwperf::advance_passive_fifo_tag(initial, step(2U, 16U, 1U)));
  check_survivor(arrivals_with_predecessor_service, state(2U),
                 mwperf::BigNat{1U});
}

TEST_CASE("C23 passive rank cannot alter the untagged successor",
          "[c23][unit][fifo-tag][passivity]") {
  const auto low_rank = require_value(mwperf::advance_passive_fifo_tag(
      mwperf::TagState{state(4U), mwperf::BigNat{1U}},
      step(7U, 9U, 0U)));
  const auto high_rank = require_value(mwperf::advance_passive_fifo_tag(
      mwperf::TagState{state(4U), mwperf::BigNat{5U}},
      step(7U, 9U, 0U)));

  REQUIRE(low_rank.survivor.has_value());
  REQUIRE(high_rank.survivor.has_value());
  CHECK(low_rank.survivor->untagged_state ==
        high_rank.survivor->untagged_state);
  CHECK(low_rank.survivor->untagged_state == state(7U));
  CHECK(low_rank.survivor->predecessors == mwperf::BigNat{1U});
  CHECK(high_rank.survivor->predecessors == mwperf::BigNat{5U});
}

TEST_CASE("C23 deterministic service gives sojourn rank plus one",
          "[c23][unit][fifo-tag]") {
  for (std::size_t initial_rank = 0U; initial_rank <= 6U; ++initial_rank) {
    CAPTURE(initial_rank);
    mwperf::TagState current{state(0U), mwperf::BigNat{initial_rank}};
    std::uint64_t current_backlog = initial_rank + 1U;
    std::size_t eligible_slots = 0U;
    for (;;) {
      ++eligible_slots;
      const std::uint64_t successor_backlog = current_backlog - 1U;
      const auto transition = require_value(
          mwperf::advance_passive_fifo_tag(
              current,
              step(static_cast<std::uint8_t>(eligible_slots),
                   successor_backlog, 1U)));
      if (transition.tag_departed) {
        CHECK_FALSE(transition.survivor.has_value());
        break;
      }
      REQUIRE(transition.survivor.has_value());
      current = *transition.survivor;
      current_backlog = successor_backlog;
    }
    CHECK(eligible_slots == initial_rank + 1U);
  }
}

TEST_CASE("C23 passive tag rejects nonbinary departure and invalid successor rank",
          "[c23][unit][fifo-tag][negative]") {
  const mwperf::TagState valid{state(0U), mwperf::BigNat{1U}};
  const auto nonbinary =
      mwperf::advance_passive_fifo_tag(valid, step(1U, 2U, 2U));
  REQUIRE_FALSE(nonbinary);
  CHECK(nonbinary.error().category ==
        mwperf::DiagnosticCategory::input_validation);

  const mwperf::TagState invalid_rank{state(0U), mwperf::BigNat{2U}};
  const auto rejected = mwperf::advance_passive_fifo_tag(
      invalid_rank, step(1U, 2U, 0U));
  REQUIRE_FALSE(rejected);
  CHECK_FALSE(rejected.error().code.empty());
}
