#include <atomic>
#include <filesystem>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>

#include <catch2/catch_test_macros.hpp>
#include <catch2/generators/catch_generators.hpp>

#include "mwperf/config/document.hpp"

namespace {

class TemporaryDocument final {
 public:
  TemporaryDocument(const std::string_view suffix,
                    const std::string_view contents) {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory{MWPERF_TEST_TEMP_DIRECTORY};
    std::filesystem::create_directories(directory);
    path_ = directory /
            ("document_layer_" + std::to_string(next_id.fetch_add(1U)) +
             std::string(suffix));
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to create C03 document fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output) {
      throw std::runtime_error("failed to write C03 document fixture");
    }
  }

  TemporaryDocument(const TemporaryDocument&) = delete;
  TemporaryDocument& operator=(const TemporaryDocument&) = delete;

  ~TemporaryDocument() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

}  // namespace

TEST_CASE("C03 JSON document nodes retain exact lexemes and source",
          "[c03][unit]") {
  TemporaryDocument file(
      ".json",
      "{\n  \"integer\": 1000000000000000000000001,\n"
      "  \"decimal\": 10e-1,\n  \"text\": \"q\\u0030\",\n"
      "  \"array\": [true, null]\n}\n");

  auto loaded = mwperf::load_document(file.path());
  INFO((!loaded
            ? loaded.error().code + ":" +
                  loaded.error().json_pointer.value_or(std::string{"<none>"})
            : std::string{}));
  REQUIRE(loaded);
  CHECK(loaded.value().syntax == mwperf::DocumentSyntax::json);
  const mwperf::SourceNode& root = loaded.value().root;
  REQUIRE(root.kind() == mwperf::SourceNodeKind::object);
  REQUIRE(root.find("integer") != nullptr);
  REQUIRE(root.find("decimal") != nullptr);
  REQUIRE(root.find("text") != nullptr);
  CHECK(*root.find("integer")->number_lexeme() ==
        "1000000000000000000000001");
  CHECK(*root.find("decimal")->number_lexeme() == "10e-1");
  CHECK(*root.find("text")->string_value() == "q0");
  CHECK(root.find("integer")->json_pointer() == "/integer");
  CHECK(root.find("integer")->location().line == 2U);
  CHECK(root.find("integer")->location().column == 14U);
  REQUIRE(root.find("array") != nullptr);
  REQUIRE(root.find("array")->array_items().size() == 2U);
  CHECK(root.find("array")->array_items()[0].json_pointer() == "/array/0");
}

TEST_CASE("C03 JSON duplicate detection uses decoded key identity",
          "[c03][negative]") {
  TemporaryDocument file(".json", "{\"a\": 1, \"\\u0061\": 2}");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE_FALSE(loaded);
  CHECK(loaded.error().code == "duplicate_object_key");
  CHECK(loaded.error().json_pointer == "/a");
  REQUIRE(loaded.error().notes.size() == 3U);
  CHECK(loaded.error().notes[1].starts_with("first definition:"));
  CHECK(loaded.error().notes[2].starts_with("duplicate definition:"));

  auto replay = mwperf::load_document(file.path());
  REQUIRE_FALSE(replay);
  CHECK(replay.error() == loaded.error());
}

TEST_CASE("C03 strict JSON rejects malformed tokens before producing a tree",
          "[c03][negative]") {
  const std::string content = GENERATE(
      std::string{"{\"n\":01}"}, std::string{"{\"n\":1.}"},
      std::string{"{\"n\":.5}"}, std::string{"{\"n\":1e}"},
      std::string{"{\"s\":\"\\x20\"}"},
      std::string{"{\"s\":\"\\uD800\"}"},
      std::string{"{\"s\":\"\\uDC00\"}"},
      std::string{"{} trailing"},
      std::string{"{\"outer\":{\"a\":1,\"a\":2}}"});
  TemporaryDocument file(".json", content);
  auto loaded = mwperf::load_document(file.path());
  REQUIRE_FALSE(loaded);
  INFO(loaded.error().code);
  CHECK((loaded.error().code.starts_with("json_") ||
         loaded.error().code == "duplicate_object_key"));
}

TEST_CASE("C03 restricted YAML retains exact scalars and quoted types",
          "[c03][unit]") {
  TemporaryDocument file(
      ".yaml",
      "integer: 184467440737095516160\n"
      "decimal: 1e-9\n"
      "quoted_decimal: \"1e-9\"\n"
      "enabled: true\n"
      "nothing: null\n");
  auto loaded = mwperf::load_document(file.path());
  INFO((!loaded
            ? loaded.error().code + ":" +
                  loaded.error().json_pointer.value_or(std::string{"<none>"})
            : std::string{}));
  REQUIRE(loaded);
  const mwperf::SourceNode& root = loaded.value().root;
  REQUIRE(root.find("integer") != nullptr);
  CHECK(root.find("integer")->kind() == mwperf::SourceNodeKind::number);
  CHECK(*root.find("integer")->number_lexeme() ==
        "184467440737095516160");
  CHECK(root.find("decimal")->kind() == mwperf::SourceNodeKind::number);
  CHECK(*root.find("decimal")->number_lexeme() == "1e-9");
  CHECK(root.find("quoted_decimal")->kind() == mwperf::SourceNodeKind::string);
  CHECK(root.find("enabled")->kind() == mwperf::SourceNodeKind::boolean);
  CHECK(root.find("nothing")->kind() == mwperf::SourceNodeKind::null_value);
  CHECK(root.find("decimal")->location().line == 2U);
  CHECK(root.find("decimal")->json_pointer() == "/decimal");
}

TEST_CASE("C03 YAML accepts JSON flow syntax under its selected grammar",
          "[c03][unit]") {
  TemporaryDocument file(".yml", "{\"switch\": {\"kind\": \"generalized\"}}");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE(loaded);
  CHECK(loaded.value().syntax == mwperf::DocumentSyntax::yaml);
  REQUIRE(loaded.value().root.find("switch") != nullptr);
}

TEST_CASE("C03 restricted YAML rejects duplicate and non-string keys",
          "[c03][negative]") {
  SECTION("duplicate") {
    TemporaryDocument file(".yaml", "a: 1\na: 2\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "duplicate_object_key");
    CHECK(loaded.error().json_pointer == "/a");
  }
  SECTION("decoded duplicate") {
    TemporaryDocument file(".yaml", "a: 1\n\"\\u0061\": 2\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "duplicate_object_key");
    CHECK(loaded.error().json_pointer == "/a");
    REQUIRE(loaded.error().notes.size() == 3U);
    CHECK(loaded.error().notes[1].starts_with("first definition:"));
    CHECK(loaded.error().notes[2].starts_with("duplicate definition:"));
  }
  SECTION("numeric key") {
    TemporaryDocument file(".yaml", "1: value\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_mapping_key_not_string");
  }
  SECTION("quoted numeric key is a string") {
    TemporaryDocument file(".yaml", "\"1\": value\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    CHECK(loaded.value().root.find("1") != nullptr);
  }
}

TEST_CASE("C03 restricted YAML excludes non-JSON features",
          "[c03][negative]") {
  SECTION("multiple documents") {
    TemporaryDocument file(".yaml", "a: 1\n---\na: 2\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_multiple_documents");
  }
  SECTION("alias") {
    TemporaryDocument file(".yaml", "a: &value [1]\nb: *value\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_alias_not_allowed");
    CHECK(loaded.error().json_pointer == "/b");
  }
  SECTION("alias used as a mapping key") {
    TemporaryDocument file(".yaml", "source: &key abc\n*key : value\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_alias_not_allowed");
    REQUIRE_FALSE(loaded.error().notes.empty());
    CHECK(loaded.error().notes.front().starts_with("line 2, column 1"));
  }
  SECTION("mapping-key anchor reused as a value") {
    TemporaryDocument file(".yaml", "&key name: *key\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_alias_not_allowed");
    REQUIRE_FALSE(loaded.error().notes.empty());
    CHECK(loaded.error().notes.front().starts_with("line 1, column 12"));
  }
  SECTION("merge") {
    TemporaryDocument file(
        ".yaml", "base: &base {a: 1}\nmerged:\n  <<: *base\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK((loaded.error().code == "yaml_merge_key_not_allowed" ||
           loaded.error().code == "yaml_custom_tag_not_allowed" ||
           loaded.error().code == "yaml_alias_not_allowed"));
  }
  SECTION("custom tag") {
    TemporaryDocument file(".yaml", "a: !custom value\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "yaml_custom_tag_not_allowed");
  }
  SECTION("nonfinite") {
    TemporaryDocument file(".yaml", "a: .nan\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "document_nonfinite_number");
  }
}

TEST_CASE("C03 loader diagnoses a missing authored file", "[c03][negative]") {
  const std::filesystem::path missing =
      std::filesystem::path{MWPERF_TEST_TEMP_DIRECTORY} /
      "document_layer_file_that_must_not_exist.json";
  std::error_code ignored;
  std::filesystem::remove(missing, ignored);
  auto loaded = mwperf::load_document(missing);
  REQUIRE_FALSE(loaded);
  CHECK(loaded.error().code == "document_open_failed");
  CHECK(loaded.error().authored_path == missing.string());
}

TEST_CASE("C03 YAML-only implicit scalar spellings are rejected",
          "[c03][negative]") {
  const std::string scalar = GENERATE(std::string{".5"}, std::string{"+1"},
                                      std::string{"-.5"}, std::string{"1."},
                                      std::string{"1.e+2"},
                                      std::string{"-1.e-2"},
                                      std::string{"-01"},
                                      std::string{"-0x10"},
                                      std::string{"1_000"},
                                      std::string{"12:30"},
                                      std::string{"1:20.5"},
                                      std::string{"2001-12-15"},
                                      std::string{"2001-1-1"},
                                      std::string{"yes"}, std::string{"Y"},
                                      std::string{"n"}, std::string{"~"},
                                      std::string{"0x10"});
  TemporaryDocument file(".yaml", "value: " + scalar + "\n");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE_FALSE(loaded);
  CHECK(loaded.error().code == "yaml_non_json_implicit_scalar");
}

TEST_CASE("C03 suffix selection never retries another grammar",
          "[c03][negative]") {
  TemporaryDocument file(".json", "switch:\n  kind: generalized\n");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE_FALSE(loaded);
  CHECK(loaded.error().code == "document_suffix_content_mismatch");
}

TEST_CASE("C03 exact-key validation is source precise", "[c03][unit]") {
  TemporaryDocument file(".json", "{\n  \"known\": 1,\n  \"typo\": 2\n}\n");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE(loaded);
  static constexpr std::string_view allowed[]{"known"};
  auto checked = mwperf::validate_exact_keys(loaded.value().root, allowed, "");
  REQUIRE_FALSE(checked);
  CHECK(checked.error().code == "unknown_object_key");
  CHECK(checked.error().json_pointer == "/typo");
  CHECK(checked.error().authored_path == file.path().string());
  REQUIRE_FALSE(checked.error().notes.empty());
  CHECK(checked.error().notes.front().starts_with("line 3, column 3"));
}

TEST_CASE("C03 JSON pointers apply RFC 6901 token escaping", "[c03][unit]") {
  TemporaryDocument file(".json", "{\"a/b~c\":{\"d/e~f\":1}}");
  auto loaded = mwperf::load_document(file.path());
  REQUIRE(loaded);
  const mwperf::SourceNode* outer = loaded.value().root.find("a/b~c");
  REQUIRE(outer != nullptr);
  CHECK(outer->json_pointer() == "/a~1b~0c");
  const mwperf::SourceNode* inner = outer->find("d/e~f");
  REQUIRE(inner != nullptr);
  CHECK(inner->json_pointer() == "/a~1b~0c/d~1e~0f");
}

TEST_CASE("C03 executable model extraction is closed", "[c03][unit]") {
  SECTION("raw executable object") {
    TemporaryDocument file(
        ".json",
        "{\"switch\":{},\"arrival\":{},\"metadata\":{\"x\":1}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE(extracted);
    CHECK(extracted.value().node.find("switch") != nullptr);
  }
  SECTION("approved manifest") {
    TemporaryDocument file(
        ".json",
        "{\"manifest_kind\":\"switchsim_config_template\","
        "\"execution_contract\":{"
        "\"executable_config_pointer\":\"/selected_config\"},"
        "\"selected_config\":{\"switch\":{},\"arrival\":{}},"
        "\"option_catalog\":{}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE(extracted);
    CHECK(extracted.value().node.json_pointer() == "/selected_config");
  }
  SECTION("arbitrary selected_config wrapper") {
    TemporaryDocument file(
        ".json", "{\"selected_config\":{\"switch\":{},\"arrival\":{}}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().code == "physical_root_unrecognized");
  }
  SECTION("option catalog is not executable input") {
    TemporaryDocument file(".json", "{\"option_catalog\":{}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().code == "physical_root_unrecognized");
  }
  SECTION("entries collection is not executable input") {
    TemporaryDocument file(".json", "{\"entries\":[]}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().code == "physical_root_unrecognized");
  }
  SECTION("manifest entry is not executable input") {
    TemporaryDocument file(
        ".json",
        "{\"id\":\"example\",\"selected_config\":"
        "{\"switch\":{},\"arrival\":{}}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().code == "physical_root_unrecognized");
  }
  SECTION("manifest and executable keys are ambiguous") {
    TemporaryDocument file(
        ".json",
        "{\"manifest_kind\":\"switchsim_config_template\","
        "\"switch\":{},\"selected_config\":{}}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().code == "physical_root_ambiguous");
  }
  SECTION("malformed pointer is diagnosed at its value") {
    TemporaryDocument file(
        ".json",
        "{\n  \"manifest_kind\":\"switchsim_config_template\",\n"
        "  \"execution_contract\":{\n"
        "    \"executable_config_pointer\":7\n  },\n"
        "  \"selected_config\":{}\n}\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    const mwperf::SourceNode* contract =
        loaded.value().root.find("execution_contract");
    REQUIRE(contract != nullptr);
    const mwperf::SourceNode* pointer =
        contract->find("executable_config_pointer");
    REQUIRE(pointer != nullptr);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().json_pointer ==
          "/execution_contract/executable_config_pointer");
    REQUIRE_FALSE(extracted.error().notes.empty());
    CHECK(extracted.error().notes.front() ==
          "line " + std::to_string(pointer->location().line) + ", column " +
              std::to_string(pointer->location().column) + ", byte " +
              std::to_string(pointer->location().byte_offset));
  }
  SECTION("malformed selected config is diagnosed at its value") {
    TemporaryDocument file(
        ".json",
        "{\n  \"manifest_kind\":\"switchsim_config_template\",\n"
        "  \"execution_contract\":{\"executable_config_pointer\":"
        "\"/selected_config\"},\n  \"selected_config\":false\n}\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    const mwperf::SourceNode* selected =
        loaded.value().root.find("selected_config");
    REQUIRE(selected != nullptr);
    auto extracted = mwperf::extract_executable_model(loaded.value());
    REQUIRE_FALSE(extracted);
    CHECK(extracted.error().json_pointer == "/selected_config");
    REQUIRE_FALSE(extracted.error().notes.empty());
    CHECK(extracted.error().notes.front() ==
          "line " + std::to_string(selected->location().line) +
              ", column " + std::to_string(selected->location().column) +
              ", byte " + std::to_string(selected->location().byte_offset));
  }
}

TEST_CASE("C03 loader rejects invalid UTF-8 and unsupported suffixes",
          "[c03][negative]") {
  SECTION("invalid UTF-8") {
    const std::string content = "{\n\"x\":\"ok\",\n\"y\":\"\xc3\x28\"}";
    TemporaryDocument file(".json", content);
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "document_invalid_utf8");
    REQUIRE_FALSE(loaded.error().notes.empty());
    CHECK(loaded.error().notes.front().starts_with("line 3, column 6"));
  }
  SECTION("unsupported suffix") {
    TemporaryDocument file(".txt", "{}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE_FALSE(loaded);
    CHECK(loaded.error().code == "document_suffix_unsupported");
  }
}

TEST_CASE("C03 source columns are UTF-8 byte columns", "[c03][unit]") {
  SECTION("JSON") {
    TemporaryDocument file(".json", "{\"\xc3\xa9\":\"x\",\"n\":1}");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    REQUIRE(loaded.value().root.find("n") != nullptr);
    CHECK(loaded.value().root.find("n")->location().line == 1U);
    CHECK(loaded.value().root.find("n")->location().column == 15U);
  }
  SECTION("YAML") {
    TemporaryDocument file(".yaml", "\xc3\xa9: text\nvalue: 1\n");
    auto loaded = mwperf::load_document(file.path());
    REQUIRE(loaded);
    REQUIRE(loaded.value().root.find("\xc3\xa9") != nullptr);
    CHECK(loaded.value().root.find("\xc3\xa9")->location().line == 1U);
    CHECK(loaded.value().root.find("\xc3\xa9")->location().column == 5U);
    CHECK(loaded.value().root.find("value")->location().line == 2U);
    CHECK(loaded.value().root.find("value")->location().column == 8U);
  }
}
