#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <ranges>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct NodeFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
  mwperf::NodeExclusiveProblem problem;
};

struct Query final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c07-node-compile";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string node_model(
    const std::string& queues, const std::string& constraint,
    const std::string& priority = "null") {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues +
         R"(},"scheduler":{"name":"node_exclusive_max_weight","params":{"constraint":)" +
         constraint + R"(,"priority":)" + priority +
         R"(}},"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] NodeFixture make_fixture(
    const std::string& queues, const std::string& constraint,
    const std::string& priority = "null") {
  auto document =
      mwperf::load_document(write_model(node_model(queues, constraint,
                                                   priority)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto resolved_priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(resolved_priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  REQUIRE(descriptor.value().family() ==
          mwperf::ServiceFamily::node_exclusive_matching);
  const auto& geometry =
      std::get<mwperf::ResolvedNodeExclusiveConstraint>(
          descriptor.value().value());
  auto problem = mwperf::compile_node_exclusive_problem(geometry);
  INFO((problem ? std::string{} : problem.error().code));
  REQUIRE(problem);
  return NodeFixture{std::move(catalog).value(),
                     std::move(resolved_priority).value(),
                     std::move(descriptor).value(),
                     std::move(problem).value()};
}

[[nodiscard]] mwperf::Result<mwperf::ConstraintDescriptor> compile_attempt(
    const std::string& queues, const std::string& constraint) {
  auto document =
      mwperf::load_document(write_model(node_model(queues, constraint)));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  return mwperf::compile_constraint_descriptor(model.value().scheduler,
                                                catalog.value());
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 zero_digest() {
  auto digest = mwperf::Digest256::from_hex(std::string(64U, '0'));
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const NodeFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      zero_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] Query make_query(
    const NodeFixture& fixture, std::vector<mwperf::BigNat> primary_values,
    std::vector<std::uint8_t> eligibility_values) {
  const auto token = dimension(fixture);
  auto primary = mwperf::PrimaryWeights::from_values(
      token, std::move(primary_values));
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, std::move(eligibility_values));
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return Query{std::move(primary).value(), std::move(eligibility).value(),
               std::move(weights).value()};
}

[[nodiscard]] std::string parallel_constraint() {
  return R"({"vertices":["z","b","a","isolated"],"links":[{"queue_id":"q2","u":"a","v":"b"},{"queue_id":"q1","u":"b","v":"z"},{"queue_id":"q0","u":"z","v":"b"}]})";
}

[[nodiscard]] mwperf::NodeExclusiveProblem corrupt_problem(
    const mwperf::NodeExclusiveProblem& source,
    std::vector<mwperf::NodeExclusiveParallelGroup> groups,
    std::vector<std::size_t> queue_to_link,
    std::vector<mwperf::NodeExclusiveIncidence> incidence,
    std::vector<std::size_t> isolated) {
  return mwperf::NodeExclusiveProblem::for_test(
      std::vector<mwperf::NodeExclusiveVertex>(source.vertices().begin(),
                                               source.vertices().end()),
      std::vector<mwperf::NodeExclusiveLabelledLink>(source.links().begin(),
                                                     source.links().end()),
      std::vector<std::size_t>(source.incidence_offsets().begin(),
                               source.incidence_offsets().end()),
      std::move(incidence), std::move(groups), std::move(queue_to_link),
      std::move(isolated));
}

}  // namespace

TEST_CASE("C07 compilation retains isolated vertices and every parallel queue label",
          "[c07][unit][node-compile]") {
  const auto fixture = make_fixture(R"(["q0","q1","q2"])",
                                    parallel_constraint(),
                                    R"(["q1","q0","q2"])");
  const auto& problem = fixture.problem;

  REQUIRE(problem.vertex_count() == 4U);
  REQUIRE(problem.queue_count() == 3U);
  REQUIRE(problem.vertices().size() == 4U);
  CHECK_FALSE(problem.vertices()[0U].isolated);
  CHECK_FALSE(problem.vertices()[1U].isolated);
  CHECK_FALSE(problem.vertices()[2U].isolated);
  CHECK(problem.vertices()[3U].isolated);
  CHECK((std::vector<std::size_t>(problem.isolated_vertices().begin(),
                                  problem.isolated_vertices().end()) ==
         std::vector<std::size_t>{3U}));

  REQUIRE(problem.links().size() == 3U);
  CHECK(problem.links()[0U].queue.ordinal() == 0U);
  CHECK(problem.links()[1U].queue.ordinal() == 1U);
  CHECK(problem.links()[2U].queue.ordinal() == 2U);
  CHECK(problem.links()[0U].first == 0U);
  CHECK(problem.links()[0U].second == 1U);
  CHECK(problem.links()[1U].first == 0U);
  CHECK(problem.links()[1U].second == 1U);
  CHECK(problem.links()[2U].first == 1U);
  CHECK(problem.links()[2U].second == 2U);
  CHECK((std::vector<std::size_t>(problem.queue_to_link().begin(),
                                  problem.queue_to_link().end()) ==
         std::vector<std::size_t>{0U, 1U, 2U}));

  REQUIRE(problem.parallel_groups().size() == 2U);
  CHECK(problem.parallel_groups()[0U] ==
        mwperf::NodeExclusiveParallelGroup{0U, 1U, 0U, 2U});
  CHECK(problem.parallel_groups()[1U] ==
        mwperf::NodeExclusiveParallelGroup{1U, 2U, 2U, 3U});
  CHECK((std::vector<std::size_t>(problem.incidence_offsets().begin(),
                                  problem.incidence_offsets().end()) ==
         std::vector<std::size_t>{0U, 2U, 5U, 6U, 6U}));
  REQUIRE(problem.incidence().size() == 6U);
}

TEST_CASE("C07 parallel representatives are selected after eligibility by exact composite weight",
          "[c07][unit][node-compile][representatives]") {
  const auto fixture = make_fixture(R"(["q0","q1","q2"])",
                                    parallel_constraint(),
                                    R"(["q1","q0","q2"])");

  const auto preferred =
      make_query(fixture, naturals({5U, 5U, 4U}), {1U, 1U, 1U});
  auto first = mwperf::select_parallel_link_representatives(
      fixture.problem, preferred.eligibility, preferred.weights);
  REQUIRE(first);
  REQUIRE(first.value().edges().size() == 2U);
  CHECK(first.value().edges()[0U].queue.ordinal() == 1U);
  CHECK(first.value().edges()[0U].weight.to_decimal_string() == "44");
  CHECK(first.value().edges()[1U].queue.ordinal() == 2U);

  const auto fallback =
      make_query(fixture, naturals({5U, 5U, 4U}), {1U, 0U, 1U});
  auto second = mwperf::select_parallel_link_representatives(
      fixture.problem, fallback.eligibility, fallback.weights);
  REQUIRE(second);
  REQUIRE(second.value().edges().size() == 2U);
  CHECK(second.value().edges()[0U].queue.ordinal() == 0U);
  CHECK(second.value().edges()[0U].weight.to_decimal_string() == "42");

  const auto omitted =
      make_query(fixture, naturals({5U, 5U, 4U}), {0U, 0U, 1U});
  auto third = mwperf::select_parallel_link_representatives(
      fixture.problem, omitted.eligibility, omitted.weights);
  REQUIRE(third);
  REQUIRE(third.value().edges().size() == 1U);
  CHECK(third.value().edges()[0U].queue.ordinal() == 2U);

  auto replay = mwperf::select_parallel_link_representatives(
      fixture.problem, preferred.eligibility, preferred.weights);
  REQUIRE(replay);
  CHECK(std::ranges::equal(replay.value().edges(), first.value().edges()));
}

TEST_CASE("C07 compilation rejects malformed authored and rebound node geometry",
          "[c07][negative][node-compile]") {
  SECTION("duplicate vertex label") {
    auto result = compile_attempt(
        R"(["q0"])",
        R"({"vertices":["u","u"],"links":[{"queue_id":"q0","u":"u","v":"u"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_node_vertex");
  }
  SECTION("undeclared endpoint") {
    auto result = compile_attempt(
        R"(["q0"])",
        R"({"vertices":["u","v"],"links":[{"queue_id":"q0","u":"u","v":"missing"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "undeclared_link_vertex");
  }
  SECTION("self loop") {
    auto result = compile_attempt(
        R"(["q0"])",
        R"({"vertices":["u"],"links":[{"queue_id":"q0","u":"u","v":"u"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "node_link_self_loop");
  }
  SECTION("missing queue coverage") {
    auto result = compile_attempt(
        R"(["q0","q1"])",
        R"({"vertices":["u","v"],"links":[{"queue_id":"q0","u":"u","v":"v"}]})");
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "missing_constraint_queue");
  }

  const auto fixture = make_fixture(R"(["q0","q1","q2"])",
                                    parallel_constraint());
  const auto& resolved =
      std::get<mwperf::ResolvedNodeExclusiveConstraint>(
          fixture.descriptor.value());

  SECTION("C07 rechecks dense vertex coverage") {
    auto corrupt = resolved;
    corrupt.vertices[1U].index = corrupt.vertices[0U].index;
    auto result = mwperf::compile_node_exclusive_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "node_exclusive_compiled_vertex_coverage_invalid");
  }
  SECTION("C07 rechecks dense queue coverage") {
    auto corrupt = resolved;
    corrupt.links[1U].queue = corrupt.links[0U].queue;
    auto result = mwperf::compile_node_exclusive_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "node_exclusive_compiled_queue_coverage_invalid");
  }
  SECTION("C07 rechecks self loops after binding") {
    auto corrupt = resolved;
    corrupt.links[0U].v = corrupt.links[0U].u;
    auto result = mwperf::compile_node_exclusive_problem(corrupt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "node_exclusive_compiled_self_loop");
  }
}

TEST_CASE("C07 representative selection rejects corrupt immutable maps",
          "[c07][negative][node-compile][representatives]") {
  const auto fixture = make_fixture(R"(["q0","q1","q2"])",
                                    parallel_constraint());
  const auto query =
      make_query(fixture, naturals({3U, 2U, 1U}), {1U, 1U, 1U});

  const std::vector<mwperf::NodeExclusiveParallelGroup> groups(
      fixture.problem.parallel_groups().begin(),
      fixture.problem.parallel_groups().end());
  const std::vector<std::size_t> queue_map(
      fixture.problem.queue_to_link().begin(),
      fixture.problem.queue_to_link().end());
  const std::vector<mwperf::NodeExclusiveIncidence> incidence(
      fixture.problem.incidence().begin(), fixture.problem.incidence().end());
  const std::vector<std::size_t> isolated(
      fixture.problem.isolated_vertices().begin(),
      fixture.problem.isolated_vertices().end());

  SECTION("parallel group partition") {
    auto bad_groups = groups;
    bad_groups[0U].begin = 1U;
    auto corrupt = corrupt_problem(fixture.problem, std::move(bad_groups),
                                   queue_map, incidence, isolated);
    auto result = mwperf::select_parallel_link_representatives(
        corrupt, query.eligibility, query.weights);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "node_exclusive_problem_parallel_group_invalid");
  }
  SECTION("queue reconstruction") {
    auto bad_map = queue_map;
    bad_map[0U] = bad_map[1U];
    auto corrupt = corrupt_problem(fixture.problem, groups,
                                   std::move(bad_map), incidence, isolated);
    auto result = mwperf::select_parallel_link_representatives(
        corrupt, query.eligibility, query.weights);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "node_exclusive_problem_queue_map_invalid");
  }
  SECTION("incidence endpoint") {
    auto bad_incidence = incidence;
    bad_incidence[0U].opposite = 3U;
    auto corrupt = corrupt_problem(fixture.problem, groups, queue_map,
                                   std::move(bad_incidence), isolated);
    auto result = mwperf::select_parallel_link_representatives(
        corrupt, query.eligibility, query.weights);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "node_exclusive_problem_incidence_endpoint_mismatch");
  }
  SECTION("isolated vertex list") {
    auto corrupt = corrupt_problem(fixture.problem, groups, queue_map,
                                   incidence, {});
    auto result = mwperf::select_parallel_link_representatives(
        corrupt, query.eligibility, query.weights);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "node_exclusive_problem_isolated_vertices_invalid");
  }
}

TEST_CASE("C07 representative selection rejects query dimension mismatches",
          "[c07][negative][node-compile][dimension]") {
  const auto fixture = make_fixture(R"(["q0","q1","q2"])",
                                    parallel_constraint());
  auto malformed =
      mwperf::EligibilityMask::from_bytes(dimension(fixture), {1U, 1U});
  REQUIRE_FALSE(malformed);
  CHECK(malformed.error().code == "eligibility_dimension_mismatch");

  const auto one_queue = make_fixture(
      R"(["q0"])",
      R"({"vertices":["u","v"],"links":[{"queue_id":"q0","u":"u","v":"v"}]})");
  const auto foreign = make_query(one_queue, naturals({1U}), {1U});
  auto result = mwperf::select_parallel_link_representatives(
      fixture.problem, foreign.eligibility, foreign.weights);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "node_exclusive_query_dimension_mismatch");
}
