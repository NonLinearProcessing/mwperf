#include <atomic>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <variant>

#include <catch2/catch_test_macros.hpp>
#include <catch2/generators/catch_generators.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"

namespace {

class TemporaryPhysical final {
 public:
  explicit TemporaryPhysical(const std::string_view contents,
                             const std::string_view suffix = ".json") {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory{MWPERF_TEST_TEMP_DIRECTORY};
    std::filesystem::create_directories(directory);
    path_ = directory /
            ("model_v3_" + std::to_string(next_id.fetch_add(1U)) +
             std::string(suffix));
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to create physical-model fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output) {
      throw std::runtime_error("failed to write physical-model fixture");
    }
  }

  TemporaryPhysical(const TemporaryPhysical&) = delete;
  TemporaryPhysical& operator=(const TemporaryPhysical&) = delete;

  ~TemporaryPhysical() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

[[nodiscard]] mwperf::Result<mwperf::AuthoredModelConfig> parse_text(
    const std::string& text, const std::string_view suffix = ".json") {
  TemporaryPhysical file(text, suffix);
  auto document = mwperf::load_document(file.path());
  if (!document) {
    return mwperf::Result<mwperf::AuthoredModelConfig>::failure(
        document.error());
  }
  auto model = mwperf::extract_executable_model(document.value());
  if (!model) {
    return mwperf::Result<mwperf::AuthoredModelConfig>::failure(model.error());
  }
  return mwperf::parse_model_config_v3(model.value());
}

[[nodiscard]] std::string generalized_model(std::string scheduler,
                                             std::string arrival,
                                             std::string prefix = {}) {
  return "{" + std::move(prefix) +
         R"("switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":1}]},"scheduler":)" +
         std::move(scheduler) + R"(,"arrival":)" + std::move(arrival) + "}";
}

[[nodiscard]] std::string trace_arrival() {
  return R"({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":2}],"metadata":{}})";
}

[[nodiscard]] std::string conflict_scheduler() {
  return R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0",1]]},"priority":null,"max_search_states":null}})";
}

}  // namespace

TEST_CASE("C03 physical defaults are explicit and provenance-marked",
          "[c03][unit]") {
  auto parsed = parse_text(
      generalized_model(conflict_scheduler(), trace_arrival()));
  REQUIRE(parsed);
  CHECK(parsed.value().schema_version.provenance.defaulted);
  CHECK(parsed.value().run.seed.value.mode == mwperf::SeedMode::automatic);
  CHECK(parsed.value().run.slots.value.to_decimal_string() == "1000");
  CHECK(parsed.value().run.warmup_slots.value.is_zero());
  CHECK(parsed.value().run.output_dir.value == std::nullopt);
  CHECK(parsed.value().run.provenance.defaulted);
  CHECK(parsed.value().telemetry.format.value == "jsonl");
  CHECK(parsed.value().telemetry.queue_snapshot.value ==
        mwperf::QueueSnapshotMode::sparse_nonzero);
  CHECK(parsed.value().telemetry.include_packet_events.value);
  CHECK_FALSE(parsed.value().telemetry.include_scheduler_state.value);
  CHECK(parsed.value().telemetry.write_slot_trace.value);
  CHECK(parsed.value().metadata.value == std::nullopt);

  const auto& switch_config =
      std::get<mwperf::GeneralizedSwitchConfig>(parsed.value().switch_config);
  CHECK(switch_config.queue_capacity.value == std::nullopt);
  CHECK(switch_config.legacy_n_ports.value == std::nullopt);
  REQUIRE(switch_config.queues.value.size() == 2U);
  CHECK(switch_config.queues.value[0].id.value.label().is_text());
  CHECK(switch_config.queues.value[1].id.value.label().is_numeric());
}

TEST_CASE("C03 parses all five preferred scheduler wrappers",
          "[c03][unit]") {
  SECTION("crossbar") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0"],"outputs":["o0"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"}]},"priority":["q0",1]}})",
        trace_arrival()));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::CrossbarMaxWeightScheduler>(
        parsed.value().scheduler.value));
  }
  SECTION("interval with exact endpoints") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0.1,"right":10e-1},{"queue_id":1,"left":1,"right":2}]},"priority":null}})",
        trace_arrival()));
    REQUIRE(parsed);
    const auto& scheduler = std::get<mwperf::IntervalMaxWeightScheduler>(
        parsed.value().scheduler.value);
    CHECK(scheduler.constraint.value.intervals.value[0].left.value <
          scheduler.constraint.value.intervals.value[0].right.value);
  }
  SECTION("node exclusive") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v"],"links":[{"queue_id":"q0","u":"u","v":"v"}]},"priority":null}})",
        trace_arrival()));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::NodeExclusiveMaxWeightScheduler>(
        parsed.value().scheduler.value));
  }
  SECTION("conflict graph") {
    auto parsed = parse_text(
        generalized_model(conflict_scheduler(), trace_arrival()));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::ConflictGraphMaxWeightScheduler>(
        parsed.value().scheduler.value));
  }
  SECTION("resource packing with empty resource dimension") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":[],"capacity":[],"demands":[{"queue_id":"q0","demand":[]},{"queue_id":1,"demand":[]}]},"priority":null,"max_search_states":100000000000000000000}})",
        trace_arrival()));
    REQUIRE(parsed);
    const auto& scheduler =
        std::get<mwperf::ResourcePackingMaxWeightScheduler>(
            parsed.value().scheduler.value);
    REQUIRE(scheduler.max_search_states.value.has_value());
    CHECK(scheduler.max_search_states.value->to_decimal_string() ==
          "100000000000000000000");
  }
}

TEST_CASE("C03 parses all six preferred arrival families without PMF repair",
          "[c03][unit]") {
  SECTION("deterministic trace preserves authored rows") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":1},{"slot":0,"queue_id":"q0","count":2}]})"));
    REQUIRE(parsed);
    const auto& arrival = std::get<mwperf::DeterministicTraceArrival>(
        parsed.value().arrival.value);
    REQUIRE(arrival.events.value.size() == 2U);
    CHECK(arrival.events.value[0].count.value.to_decimal_string() == "1");
    CHECK(arrival.events.value[1].count.value.to_decimal_string() == "2");
  }
  SECTION("periodic global phase permits empty source list") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"periodic_global_phase","period":4,"phase":3,"sources":[],"metadata":{}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::PeriodicGlobalPhaseArrival>(
        parsed.value().arrival.value));
  }
  SECTION("periodic source delays normalizes IDs and retains order") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"periodic_source_delays","period":4,"sources":[{"id":" Source-A ","delay":2,"entries":[{"offset":3,"queue_id":1,"count":4}]}],"metadata":{}})"));
    REQUIRE(parsed);
    const auto& arrival = std::get<mwperf::PeriodicSourceDelaysArrival>(
        parsed.value().arrival.value);
    CHECK(arrival.sources.value[0].id.value == "source_a");
  }
  SECTION("independent marked renewal factorized accepts unnormalized row") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"independent_marked_renewal","sources":[{"id":"S 0","interarrival":{"kind":"finite_pmf","outcomes":[{"d":1,"probability":0.1}]},"destination_pmf":[{"queue_id":"q0","probability":0.2}]}],"metadata":{}})"));
    REQUIRE(parsed);
    const auto& arrival = std::get<mwperf::IndependentMarkedRenewalArrival>(
        parsed.value().arrival.value);
    const auto& source = std::get<mwperf::FactorizedRenewalSource>(
        arrival.sources.value.front());
    CHECK(source.id.value == "s_0");
    CHECK(source.destination_pmf.value.front().probability.value.exact_value() ==
          mwperf::parse_decimal_rational(mwperf::NumericLexeme("0.2")).value());
  }
  SECTION("independent marked renewal joint") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"independent_marked_renewal","sources":[{"id":"s","joint_pmf":[{"d":2,"queue_id":1,"probability":1}]}],"metadata":{}})"));
    REQUIRE(parsed);
    const auto& arrival = std::get<mwperf::IndependentMarkedRenewalArrival>(
        parsed.value().arrival.value);
    CHECK(std::holds_alternative<mwperf::JointRenewalSource>(
        arrival.sources.value.front()));
  }
  SECTION("private Markov renewal distribution initial state") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"independent_private_markov_renewal","sources":[{"id":"s","states":["On","Off"],"initial":{"distribution":[{"state":"on","probability":0.4},{"state":"off","probability":0.4}]},"gaps":[{"state":"on","d":1},{"state":"off","d":2}],"transitions":[{"state":"on","next_state":"off","probability":0.2}],"destination_pmf":[{"queue_id":"q0","probability":0.3}]}],"metadata":{}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::IndependentPrivateMarkovRenewalArrival>(
        parsed.value().arrival.value));
  }
  SECTION("shared joint renewal exact-state initial") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"shared_joint_round_markov_renewal","sources":[{"id":"s0"}],"states":["Steady"],"initial":{"state":"steady"},"outcomes":[{"state":"steady","next_state":"steady","probability":0.7,"emissions":[{"source_id":"s0","d":1,"queue_id":"q0"}]}],"metadata":{}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::SharedJointRoundMarkovRenewalArrival>(
        parsed.value().arrival.value));
  }
}

TEST_CASE("C03 recognizes closed legacy compatibility carriers",
          "[c03][unit]") {
  SECTION("omitted legacy scheduler materializes random_maximal") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE(parsed);
    const auto& scheduler =
        std::get<mwperf::UnsupportedCompatibilityScheduler>(
            parsed.value().scheduler.value);
    CHECK(scheduler.kind == mwperf::CompatibilitySchedulerKind::random_maximal);
    CHECK(parsed.value().scheduler.provenance.defaulted);
  }
  SECTION("omitted legacy scheduler name materializes random_maximal") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{"params":{}},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE(parsed);
    const auto& scheduler =
        std::get<mwperf::UnsupportedCompatibilityScheduler>(
            parsed.value().scheduler.value);
    CHECK(scheduler.kind == mwperf::CompatibilitySchedulerKind::random_maximal);
    CHECK(scheduler.name_provenance.defaulted);
    CHECK(scheduler.name_provenance.json_pointer == "/scheduler/name");
    CHECK_FALSE(scheduler.provenance.defaulted);
    CHECK(std::holds_alternative<mwperf::RandomMaximalCompatibilityParams>(
        scheduler.params));
  }
  SECTION("legacy crossbar MaxWeight has no synthesized constraint") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{"name":"crossbar_max_weight","params":{"priority":null}},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE(parsed);
    const auto& scheduler = std::get<mwperf::CrossbarMaxWeightScheduler>(
        parsed.value().scheduler.value);
    CHECK(scheduler.legacy_form);
    CHECK_FALSE(scheduler.constraint.value.has_value());
  }
  SECTION("all four compatibility scheduler names") {
    const std::string params = GENERATE(
        std::string{R"("random_maximal","params":{})"},
        std::string{R"("round_robin","params":{"input_offset":0,"output_offset":1})"},
        std::string{R"("islip_rga","params":{"k":1})"},
        std::string{R"("islip_canonical","params":{"k":1,"initial_grant_pointers":[0,1],"initial_accept_pointers":[1,0]})"});
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{"name":)" +
        params + R"(},"arrival":{"family":"deterministic_trace","events":[]}})" );
    REQUIRE(parsed);
    const auto& scheduler =
        std::get<mwperf::UnsupportedCompatibilityScheduler>(
            parsed.value().scheduler.value);
    CHECK_FALSE(scheduler.name_provenance.defaulted);
    CHECK(scheduler.name_provenance.json_pointer == "/scheduler/name");
  }
  SECTION("three compatibility arrival families") {
    const std::string arrival = GENERATE(
        std::string{R"({"family":"iid_table","alphabet":[{"id":"a","edges":[],"probability":1}]})"},
        std::string{R"({"family":"markov_kernel","states":["s"],"alphabet":[{"id":"a","edges":[]}],"kernel":[{"state":"s","mask_id":"a","next_state":"s","probability":1}],"initial":{"state":"s"}})"},
        std::string{R"({"family":"factorized_bernoulli","alphabet_constraint":"unrestricted","lambda":{"default":0.5,"overrides":{"[0,1]":0.25}}})"});
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":)" +
        arrival + "}");
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::UnsupportedCompatibilityArrival>(
        parsed.value().arrival.value));
  }
}

TEST_CASE("C03 compatibility carriers retain resolved defaults and tokens",
          "[c03][unit]") {
  SECTION("iid defaults and normalized optional atom id") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":{"family":"iid_table","alphabet":[{"id":" Arrival-A ","edges":[],"probability":1}]}})"
    );
    REQUIRE(parsed);
    const auto& unsupported =
        std::get<mwperf::UnsupportedCompatibilityArrival>(
            parsed.value().arrival.value);
    const auto& iid = std::get<mwperf::IidTableCompatibilityArrival>(
        unsupported.value);
    CHECK(iid.common.allowed_edges.mode.value == mwperf::AllowedEdgesMode::full);
    CHECK(iid.common.allowed_edges.mode.provenance.defaulted);
    CHECK(iid.common.alphabet_constraint.value ==
          mwperf::AlphabetConstraintMode::unrestricted);
    CHECK(iid.metadata.provenance.defaulted);
    REQUIRE(iid.alphabet.value.front().id.value.has_value());
    CHECK(iid.alphabet.value.front().id.value->value == "arrival_a");
  }
  SECTION("Markov declarations and references share normalization") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":{"family":"markov_kernel","states":[" State-A "],"alphabet":[{"id":" Mask-A ","edges":[]}],"kernel":[{"state":"state a","mask_id":"mask-a","next_state":"STATE_A","probability":1}],"initial":{"state":"state-a"}}})"
    );
    REQUIRE(parsed);
    const auto& unsupported =
        std::get<mwperf::UnsupportedCompatibilityArrival>(
            parsed.value().arrival.value);
    const auto& markov = std::get<mwperf::MarkovKernelCompatibilityArrival>(
        unsupported.value);
    CHECK(markov.states.value.front().value == "state_a");
    CHECK(markov.alphabet.value.front().id.value == "mask_a");
    CHECK(markov.kernel.value.front().state.value == "state_a");
    CHECK(markov.kernel.value.front().mask_id.value == "mask_a");
    CHECK(markov.kernel.value.front().next_state.value == "state_a");
    CHECK(std::get<mwperf::InitialExactState>(markov.initial.value).state.value ==
          "state_a");
  }
  SECTION("factorized overrides default to an explicit empty typed set") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"arrival":{"family":"factorized_bernoulli","lambda":{"default":0.5}}})"
    );
    REQUIRE(parsed);
    const auto& unsupported =
        std::get<mwperf::UnsupportedCompatibilityArrival>(
            parsed.value().arrival.value);
    const auto& factorized =
        std::get<mwperf::FactorizedBernoulliCompatibilityArrival>(
            unsupported.value);
    CHECK(factorized.overrides.value.empty());
    CHECK(factorized.overrides.provenance.defaulted);
  }
  SECTION("scheduler defaults are typed") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{"name":"round_robin","params":{}},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE(parsed);
    const auto& unsupported =
        std::get<mwperf::UnsupportedCompatibilityScheduler>(
            parsed.value().scheduler.value);
    const auto& round_robin =
        std::get<mwperf::RoundRobinCompatibilityParams>(unsupported.params);
    CHECK(round_robin.input_offset.value.is_zero());
    CHECK(round_robin.output_offset.value.is_zero());
    CHECK(round_robin.input_offset.provenance.defaulted);
    CHECK(round_robin.output_offset.provenance.defaulted);
  }
}

TEST_CASE("C03 rejects local physical violations with source context",
          "[c03][negative]") {
  SECTION("closed tagged unions report misspelled discriminators first") {
    struct Fixture final {
      std::string document;
      std::string pointer;
    };
    const Fixture fixtures[] = {
        {R"({"switch":{"kin":"generalized","queues":["q0"]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]}}},"arrival":{"family":"deterministic_trace","events":[]}})",
         "/switch/kin"},
        {generalized_model(
             conflict_scheduler(),
             R"({"famly":"deterministic_trace","events":[]})"),
         "/arrival/famly"},
        {generalized_model(
             conflict_scheduler(),
             R"({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kin":"deterministic","d":1},"destination_pmf":[{"queue_id":"q0","probability":1}]}]})"),
         "/arrival/sources/0/interarrival/kin"},
        {generalized_model(
             conflict_scheduler(),
             R"({"family":"independent_marked_renewal","sources":[{"id":"s","interarriva":{"kind":"deterministic","d":1}}]})"),
         "/arrival/sources/0/interarriva"},
        {generalized_model(
             conflict_scheduler(),
             R"({"family":"independent_private_markov_renewal","sources":[{"id":"s","states":["a"],"initial":{"stat":"a"},"gaps":[],"transitions":[{"state":"a","next_state":"a","probability":1}],"destination_pmf":[{"queue_id":"q0","probability":1}]}]})"),
         "/arrival/sources/0/initial/stat"},
    };
    for (const Fixture& fixture : fixtures) {
      auto parsed = parse_text(fixture.document);
      INFO(fixture.pointer);
      REQUIRE_FALSE(parsed);
      CHECK(parsed.error().code == "unknown_object_key");
      CHECK(parsed.error().json_pointer == fixture.pointer);
    }
  }
  SECTION("generalized scheduler name remains required") {
    auto parsed = parse_text(generalized_model(
        R"({"params":{}})", trace_arrival()));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_missing_key");
    CHECK(parsed.error().json_pointer.value_or("") == "/scheduler");
  }
  SECTION("defaulted legacy scheduler still has random_maximal params") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{"params":{"input_offset":1}},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "unknown_object_key");
    CHECK(parsed.error().json_pointer.value_or("") ==
          "/scheduler/params/input_offset");
  }
  SECTION("defaulted legacy scheduler still requires its params wrapper") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":64},"scheduler":{},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_missing_key");
    CHECK(parsed.error().json_pointer.value_or("") == "/scheduler");
  }
  SECTION("generalized scheduler omission") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"generalized","queues":["q0"]},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_generalized_scheduler_required");
  }
  SECTION("interval order is exact") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":1.0000000000000000001,"right":1.0000000000000000000}]},"priority":null}})",
        trace_arrival()));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_invalid_interval");
  }
  SECTION("phase below period") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"periodic_global_phase","period":4,"phase":4,"sources":[]})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_phase_out_of_range");
  }
  SECTION("count upper bound") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":9223372036854775808}]})"));
    REQUIRE_FALSE(parsed);
  }
  SECTION("probability exact range") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kind":"geometric_grid","d_min":1,"delta":1,"p":0},"destination_pmf":[{"queue_id":"q0","probability":1}]}]})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_probability_not_positive");
  }
  SECTION("normalized source collision") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(),
        R"({"family":"periodic_source_delays","period":1,"sources":[{"id":"A-B","delay":0,"entries":[]},{"id":" a b ","delay":0,"entries":[]}]})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_normalized_token_collision");
  }
  SECTION("warmup exceeds slots") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), trace_arrival(),
        R"("run":{"slots":2,"warmup_slots":3},)"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_warmup_exceeds_slots");
  }
  SECTION("seed replay mismatch") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), trace_arrival(),
        R"("run":{"requested_seed":7,"actual_seed":8},)"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_seed_replay_mismatch");
  }
  SECTION("diagnostic contains file pointer and line-column note") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), trace_arrival(), R"("run":{"typo":1},)"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().authored_path.has_value());
    INFO(parsed.error().json_pointer.value_or("<missing>"));
    CHECK(parsed.error().json_pointer.value_or("") == "/run/typo");
    REQUIRE_FALSE(parsed.error().notes.empty());
    CHECK(parsed.error().notes.front().starts_with("line "));
  }
}

TEST_CASE("C03 canonical-only physical parser names rejected aliases",
          "[c03][negative]") {
  SECTION("schema 2") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), trace_arrival(),
        R"("schema_version":"2.1.0",)"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_schema_version_unsupported");
  }
  SECTION("switch alias") {
    auto parsed = parse_text(
        R"({"switch":{"kind":"generic","queues":["q0"]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]}}},"arrival":{"family":"deterministic_trace","events":[]}})"
    );
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_noncanonical_alias");
    CHECK(parsed.error().notes.back().find("generalized") != std::string::npos);
  }
  SECTION("scheduler parameters alias") {
    auto parsed = parse_text(generalized_model(
        R"({"name":"conflict_graph_max_weight","parameters":{"constraint":{"conflicts":[]}}})",
        trace_arrival()));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_noncanonical_alias");
    CHECK(parsed.error().notes.back().find("params") != std::string::npos);
  }
  SECTION("arrival alias") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), R"({"family":"bernoulli"})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_noncanonical_alias");
    CHECK(parsed.error().notes.back().find("factorized_bernoulli") !=
          std::string::npos);
  }
  SECTION("telemetry spelling alias") {
    auto parsed = parse_text(generalized_model(
        conflict_scheduler(), trace_arrival(),
        R"("telemetry":{"queue_snapshot":"sparse_non_zero"},)"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "model_noncanonical_alias");
  }
}

TEST_CASE("C03 intentionally leaves C04 and C09 checks unresolved",
          "[c03][unit]") {
  auto parsed = parse_text(generalized_model(
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["missing","missing"]]},"priority":["missing"],"max_search_states":null}})",
      R"({"family":"independent_marked_renewal","sources":[{"id":"s","joint_pmf":[{"d":1,"queue_id":"missing","probability":0.2}]}]})"));
  INFO((!parsed ? parsed.error().code + ": " + parsed.error().message
                : std::string{}));
  REQUIRE(parsed);
}
