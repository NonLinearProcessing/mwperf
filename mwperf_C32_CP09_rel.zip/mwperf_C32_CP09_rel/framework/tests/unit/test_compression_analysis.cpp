#include <algorithm>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/compression_analysis.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::CompressionQuantityV1 exact_quantity(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  return {{mwperf::CompressionNumericalValueV1{
               rational(numerator, denominator),
               mwperf::ExactRational::zero()}},
          {}};
}

[[nodiscard]] mwperf::ExactRational cp09_tolerance() {
  mwperf::BigInt denominator = 1;
  for (std::size_t digit = 0U; digit < 45U; ++digit) denominator *= 10;
  auto value = mwperf::ExactRational::make(mwperf::BigInt{1}, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] const mwperf::ExactRational& estimate(
    const mwperf::CompressionQuantityV1& quantity) {
  REQUIRE(quantity.available());
  return quantity.estimate->value;
}

[[nodiscard]] bool has_reason(
    const mwperf::CompressionMetricStatusV1& status,
    const mwperf::CompressionUnavailableReasonV1 reason) {
  return std::find(status.unavailable_reasons.begin(),
                   status.unavailable_reasons.end(),
                   reason) != status.unavailable_reasons.end();
}

[[nodiscard]] bool has_warning(
    const mwperf::CompressionMetricStatusV1& status,
    const mwperf::CompressionWarningCodeV1 warning) {
  return std::find(status.warnings.begin(), status.warnings.end(), warning) !=
         status.warnings.end();
}

[[nodiscard]] mwperf::ValidatedConstructionObservationBundleV1 validate(
    mwperf::ConstructionObservationBundleV1 bundle) {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  return std::move(validated).value();
}

[[nodiscard]] mwperf::CompressionAnalysisResultV1 analyze(
    mwperf::ConstructionObservationBundleV1 bundle,
    const mwperf::BigNat& cutoff, const bool run_fit = false,
    std::vector<mwperf::FinitePrefixFitSelectionSeedAtomV1> seed = {}) {
  const auto observation = validate(std::move(bundle));
  mwperf::CompressionAnalysisOptionsV1 options{
      {cutoff}, {}, std::move(seed), {}, std::nullopt, run_fit, false, true,
      true,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto result =
      mwperf::analyze_compression_observations_v1(observation, options);
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C30 jackknife resamples independent replications exactly",
          "[c30][math][unit]") {
  std::vector<mwperf::JackknifeReplicationEstimateV1> leave_one_out{
      {mwperf::TypedLabel::numeric(mwperf::BigNat{0U}), exact_quantity(8)},
      {mwperf::TypedLabel::numeric(mwperf::BigNat{1U}), exact_quantity(10)},
      {mwperf::TypedLabel::numeric(mwperf::BigNat{2U}), exact_quantity(12)},
  };

  auto summary = mwperf::summarize_delete_one_replication_jackknife_v1(
      exact_quantity(10), leave_one_out);
  REQUIRE(summary);
  CHECK(summary.value().leave_one_out_estimates == leave_one_out);
  CHECK(estimate(summary.value().leave_one_out_mean) == rational(10));
  CHECK(estimate(summary.value().estimated_bias).is_zero());
  CHECK(estimate(summary.value().bias_corrected_estimate) == rational(10));
  CHECK(estimate(summary.value().squared_standard_error) == rational(16, 3));
  CHECK(estimate(summary.value().invalid_resample_rate).is_zero());
}

TEST_CASE("C30 analysis keeps zero and negative tail slack typed",
          "[c30][math][unit][status]") {
  SECTION("zero slack preserves undivided tail rewards") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    bundle.bindings.arrival.target_arrival =
        mwperf::ExactTargetArrivalMarginalV1{
            {{mwperf::BigNat{0U}, rational(1, 2)},
             {mwperf::BigNat{1U}, rational(1, 2)}}};
    bundle.bindings.arrival.mean = rational(1, 2);
    bundle.bindings.arrival.second_moment = rational(1, 2);
    const auto result = analyze(std::move(bundle), mwperf::BigNat{1U});
    const auto& tail = result.cutoffs.front().tail;
    CHECK(estimate(tail.tail_probability) == rational(1, 2));
    CHECK(estimate(tail.backlog_tail_reward) == rational(1));
    CHECK(estimate(tail.tail_slack).is_zero());
    CHECK_FALSE(tail.tail_association_ratio.available());
    CHECK(has_reason(tail.tail_association_ratio.status,
                     mwperf::CompressionUnavailableReasonV1::
                         zero_tail_slack));
  }

  SECTION("negative slack blocks only the stationary interpretation") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    bundle.bindings.arrival.target_arrival =
        mwperf::ExactTargetArrivalMarginalV1{
            {{mwperf::BigNat{0U}, rational(1, 2)},
             {mwperf::BigNat{2U}, rational(1, 2)}}};
    bundle.bindings.arrival.mean = rational(1);
    bundle.bindings.arrival.second_moment = rational(2);
    const auto result = analyze(std::move(bundle), mwperf::BigNat{1U});
    const auto& tail = result.cutoffs.front().tail;
    CHECK(estimate(tail.tail_slack) == rational(-1, 2));
    CHECK(tail.tail_association_ratio.available());
    CHECK_FALSE(tail.stationary_compression_defect.available());
    CHECK(has_reason(tail.stationary_compression_defect.status,
                     mwperf::CompressionUnavailableReasonV1::
                         nonpositive_tail_slack));
  }
}

TEST_CASE("C30 analysis distinguishes no exposure no tail and zero service",
          "[c30][math][unit][status]") {
  SECTION("no completed exposure") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    auto& replication = bundle.replications.front();
    replication.completeness =
        mwperf::ObservationCompletenessV1::partial;
    replication.committed_through_boundary = bundle.warmup_boundary;
    replication.blocks.clear();
    const auto result = analyze(std::move(bundle), mwperf::BigNat{1U});
    CHECK(has_reason(result.pooled.status,
                     mwperf::CompressionUnavailableReasonV1::
                         no_complete_replication));
    CHECK(has_reason(result.pooled.status,
                     mwperf::CompressionUnavailableReasonV1::no_exposure));
    CHECK(has_reason(result.finite_window.status,
                     mwperf::CompressionUnavailableReasonV1::
                         incomplete_or_missing_boundary));
  }

  SECTION("no tail exposure") {
    const auto result = analyze(mwperf::testing::c30::exact_bundle(),
                                mwperf::BigNat{2U});
    const auto& tail = result.cutoffs.front().tail;
    CHECK(estimate(tail.tail_probability).is_zero());
    CHECK_FALSE(tail.constant_tail_response.available());
    CHECK(has_reason(tail.constant_tail_response.status,
                     mwperf::CompressionUnavailableReasonV1::
                         no_tail_exposure));
  }

  SECTION("exposure with zero service remains descriptive") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    for (auto& row : bundle.replications.front().blocks.front().levels) {
      row.served_mass = mwperf::testing::c30::scalar(0);
    }
    const auto result = analyze(std::move(bundle), mwperf::BigNat{1U});
    const auto& cutoff = result.cutoffs.front();
    CHECK(estimate(cutoff.tail.tail_service_mass).is_zero());
    CHECK(estimate(cutoff.tail.constant_tail_response).is_zero());
    REQUIRE(cutoff.empirical_profile.prefix.size() == 2U);
    CHECK(cutoff.empirical_profile.prefix.front().decoder_structural_zero);
    CHECK(estimate(cutoff.empirical_profile.prefix.front().response)
              .is_zero());
    CHECK(has_warning(cutoff.empirical_profile.prefix[1U].response.status,
                      mwperf::CompressionWarningCodeV1::
                          exposure_without_observed_service));
  }
}

TEST_CASE("C30 missing moments and fit rejection stay local to their panels",
          "[c30][math][unit][status]") {
  SECTION("descriptor-only arrival keeps descriptive rewards") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    bundle.bindings.arrival.target_arrival =
        mwperf::TargetArrivalOvershootDescriptorV1{
            "fixture_descriptor", 1U,
            mwperf::testing::c30::digest('c')};
    bundle.capabilities.exact_target_arrival_marginal =
        mwperf::testing::c30::unavailable("descriptor_only");
    bundle.capabilities.finite_arrival_second_moment =
        mwperf::testing::c30::unavailable("moment_unavailable");
    const auto result = analyze(std::move(bundle), mwperf::BigNat{1U});
    CHECK(result.cutoffs.front().tail.tail_probability.available());
    CHECK_FALSE(result.finite_window.second_moment_expected_increment
                    .available());
    CHECK(has_reason(
        result.finite_window.second_moment_expected_increment.status,
        mwperf::CompressionUnavailableReasonV1::missing_second_moment));
  }

  SECTION("invalid selection seed is a decoder rejection, not analysis loss") {
    const auto result = analyze(
        mwperf::testing::c30::exact_bundle(), mwperf::BigNat{1U}, true,
        {{mwperf::BigNat{0U}, rational(1, 2)}});
    const auto& cutoff = result.cutoffs.front();
    CHECK_FALSE(cutoff.diagnostic_fit.has_value());
    REQUIRE(cutoff.diagnostic_fit_failure);
    CHECK(cutoff.diagnostic_fit_failure->code ==
          "c19.scalar_selection_seed_not_normalized");
    CHECK(has_reason(cutoff.diagnostic_fit_status,
                     mwperf::CompressionUnavailableReasonV1::
                         decoder_rejected));
    CHECK(cutoff.tail.tail_probability.available());
  }
}

TEST_CASE("C30 observation validation rejects unsupported timing order",
          "[c30][math][unit][status][negative]") {
  auto bundle = mwperf::testing::c30::exact_bundle();
  std::swap(bundle.slot_convention.step_order[1U],
            bundle.slot_convention.step_order[2U]);
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE_FALSE(validated);
  CHECK(validated.error().code == "observation_slot_order_mismatch");
}

TEST_CASE("C32 raw finite-window projections admit arbitrary BigNat cutoffs",
          "[c32][cp09][math][unit]") {
  const auto observation =
      validate(mwperf::testing::c30::exact_gap_bundle());
  mwperf::BigInt enormous_value = 1;
  enormous_value <<= 256U;
  auto enormous = mwperf::BigNat::from_big_int(std::move(enormous_value));
  REQUIRE(enormous);

  mwperf::CompressionAnalysisOptionsV1 raw_options;
  raw_options.cutoffs = {mwperf::BigNat{0U}, mwperf::BigNat{1U},
                         mwperf::BigNat{2U}, enormous.value()};
  raw_options.run_diagnostic_fits = false;
  raw_options.stationary_coefficients_established = true;
  raw_options.prefix_preservation_established = true;
  raw_options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  raw_options.ensemble_population_size = mwperf::BigNat{64U};
  auto raw = mwperf::analyze_compression_observations_v1(
      observation, raw_options);
  REQUIRE(raw);
  REQUIRE(raw.value().empirical_finite_window_response);
  const auto& profile = *raw.value().empirical_finite_window_response;
  CHECK(profile.observed_levels.size() == 3U);
  CHECK(profile.observed_point_count == mwperf::BigNat{3U});
  CHECK(profile.highest_observed_level == mwperf::BigNat{2U});
  CHECK(profile.coordinate_extent == mwperf::BigNat{3U});
  CHECK(profile.complete_through == mwperf::BigNat{2U});
  CHECK(profile.ensemble_population_size == mwperf::BigNat{64U});
  REQUIRE(raw.value().cutoffs.size() == 4U);
  const auto& zero_cutoff = raw.value().cutoffs.front();
  CHECK(zero_cutoff.cutoff == mwperf::BigNat{0U});
  CHECK_FALSE(zero_cutoff.diagnostic_fit.has_value());
  CHECK_FALSE(zero_cutoff.diagnostic_fitted_mean.available());
  CHECK(has_reason(zero_cutoff.diagnostic_fitted_mean.status,
                   mwperf::CompressionUnavailableReasonV1::
                       fitted_law_unavailable));
  CHECK(zero_cutoff.tail.tail_probability.available());
  CHECK(zero_cutoff.tail.tail_service_mass.available());
  CHECK(zero_cutoff.tail.backlog_tail_reward.available());
  CHECK(zero_cutoff.tail.backlog_service_tail_reward.available());

  // For K1=1 < K2=2 each exact tail reward telescopes into the mass in the
  // intervening band {2} plus the later tail.  These are the four distinct
  // quantities needed by the compression identity, not a fitted surrogate.
  const auto& first_tail = raw.value().cutoffs[1U].tail;
  const auto& second_tail = raw.value().cutoffs[2U].tail;
  CHECK(estimate(first_tail.tail_probability) ==
        rational(1, 2) + estimate(second_tail.tail_probability));
  CHECK(estimate(first_tail.tail_service_mass) ==
        rational(1, 4) + estimate(second_tail.tail_service_mass));
  CHECK(estimate(first_tail.backlog_tail_reward) ==
        rational(1) + estimate(second_tail.backlog_tail_reward));
  CHECK(estimate(first_tail.backlog_service_tail_reward) ==
        rational(1, 2) +
            estimate(second_tail.backlog_service_tail_reward));

  CHECK(raw.value().cutoffs.back().cutoff == enormous.value());
  CHECK(raw.value().cutoffs.back().empirical_profile.prefix.empty());
  CHECK(raw.value().cutoffs.back().empirical_profile.representation ==
        mwperf::EmpiricalResponseProfileRepresentationV1::
            sparse_profile_reference);
  CHECK(estimate(raw.value().cutoffs.back().tail.tail_probability).is_zero());
  CHECK(estimate(raw.value().cutoffs.back().tail.tail_service_mass).is_zero());
  CHECK(estimate(raw.value().cutoffs.back().tail.backlog_tail_reward)
            .is_zero());
  CHECK(estimate(raw.value().cutoffs.back().tail.backlog_service_tail_reward)
            .is_zero());

  // Numerical cutoff magnitude changes only post-collection views.  It does
  // not change, extend, or densely reallocate the physical response profile.
  mwperf::CompressionAnalysisOptionsV1 smaller = raw_options;
  smaller.cutoffs.back() = mwperf::BigNat{257U};
  auto projected = mwperf::analyze_compression_observations_v1(
      observation, smaller);
  REQUIRE(projected);
  REQUIRE(projected.value().empirical_finite_window_response);
  CHECK(*projected.value().empirical_finite_window_response == profile);
  CHECK(projected.value().work.estimated_peak_retained_bytes ==
        raw.value().work.estimated_peak_retained_bytes);

  // A sparse coordinate hole remains absent.  The publication does not fill
  // it with a synthetic zero response, and it keeps physical extent separate
  // from the last consecutively observed coordinate.
  auto hole_bundle = mwperf::testing::c30::exact_gap_bundle();
  auto& levels = hole_bundle.replications.front().blocks.front().levels;
  auto moved = std::move(levels[1U]);
  moved.backlog_level = mwperf::BigNat{3U};
  levels.erase(levels.begin() + 1);
  levels.push_back(std::move(moved));
  auto hole = mwperf::analyze_compression_observations_v1(
      validate(std::move(hole_bundle)), raw_options);
  REQUIRE(hole);
  REQUIRE(hole.value().empirical_finite_window_response);
  const auto& sparse_hole =
      *hole.value().empirical_finite_window_response;
  CHECK(sparse_hole.highest_observed_level == mwperf::BigNat{3U});
  CHECK(sparse_hole.coordinate_extent == mwperf::BigNat{4U});
  CHECK(sparse_hole.complete_through == mwperf::BigNat{0U});
  CHECK(std::ranges::none_of(
      sparse_hole.observed_levels, [](const auto& point) {
        return point.backlog_level == mwperf::BigNat{1U};
      }));
}

TEST_CASE(
    "C32 raw response preserves empirical zero one and missing-level semantics",
    "[c32][cp09][math][unit][response]") {
  auto bundle = mwperf::testing::c30::exact_bundle(
      mwperf::ObservationSourceRoleV1::weighted_ensemble);
  auto& levels = bundle.replications.front().blocks.front().levels;

  // Backlog zero is the structural no-service coefficient.  At a positive
  // backlog an observed zero is instead empirical evidence, and an observed
  // one is likewise retained as data rather than treated as a boundary case.
  levels[1U].served_mass = mwperf::testing::c30::scalar(0);
  levels[2U].served_mass = levels[2U].exposure_mass;
  levels[2U].backlog_level = mwperf::BigNat{3U};

  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{4U}, mwperf::BigNat{8U},
                     mwperf::BigNat{16U}};
  options.run_diagnostic_fits = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  auto analyzed = mwperf::analyze_compression_observations_v1(
      validate(std::move(bundle)), options);
  REQUIRE(analyzed);
  REQUIRE(analyzed.value().empirical_finite_window_response);

  const auto& raw = *analyzed.value().empirical_finite_window_response;
  REQUIRE(raw.observed_levels.size() == 3U);
  CHECK(raw.observed_point_count == mwperf::BigNat{3U});
  CHECK(raw.highest_observed_level == mwperf::BigNat{3U});
  CHECK(raw.coordinate_extent == mwperf::BigNat{4U});
  CHECK(raw.complete_through == mwperf::BigNat{1U});

  CHECK(raw.observed_levels[0U].backlog_level == mwperf::BigNat{0U});
  CHECK(raw.observed_levels[0U].response_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::structural_zero);
  CHECK(estimate(raw.observed_levels[0U].response).is_zero());
  CHECK(has_warning(raw.observed_levels[0U].response.status,
                    mwperf::CompressionWarningCodeV1::
                        structural_zero_response));

  CHECK(raw.observed_levels[1U].backlog_level == mwperf::BigNat{1U});
  CHECK(raw.observed_levels[1U].response_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(estimate(raw.observed_levels[1U].response).is_zero());
  CHECK(has_warning(raw.observed_levels[1U].response.status,
                    mwperf::CompressionWarningCodeV1::
                        exposure_without_observed_service));

  CHECK(raw.observed_levels[2U].backlog_level == mwperf::BigNat{3U});
  CHECK(raw.observed_levels[2U].response_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(estimate(raw.observed_levels[2U].response) == rational(1));

  // The absent level two remains absent.  Each requested K is merely a
  // post-collection view and may not truncate or densify the raw response.
  CHECK(std::ranges::none_of(raw.observed_levels, [](const auto& point) {
    return point.backlog_level == mwperf::BigNat{2U};
  }));
  REQUIRE(analyzed.value().cutoffs.size() == 3U);
  for (const auto& cutoff : analyzed.value().cutoffs) {
    CHECK(cutoff.empirical_profile.representation ==
          mwperf::EmpiricalResponseProfileRepresentationV1::
              sparse_profile_reference);
    CHECK(cutoff.empirical_profile.prefix.empty());
    CHECK_FALSE(cutoff.diagnostic_fit.has_value());
    CHECK(has_reason(cutoff.diagnostic_fit_status,
                     mwperf::CompressionUnavailableReasonV1::
                         fitted_law_unavailable));
  }
}

TEST_CASE("C32 framework prediction publishes the complete exact readout",
          "[c32][cp09][math][unit][prediction]") {
  auto bundle = mwperf::testing::c30::exact_bundle(
      mwperf::ObservationSourceRoleV1::weighted_ensemble);
  // Preserve the fixture's total exposure and its selected {0,1} closed
  // class, but retain an observed response through level four.  This keeps
  // the exact stationary answer simple while proving that the framework
  // readout is not truncated to the legacy metric requests at levels 0--2.
  bundle.replications.front().blocks.front().levels = {
      {mwperf::BigNat{0U}, mwperf::testing::c30::scalar(1),
       mwperf::testing::c30::scalar(0), std::nullopt},
      {mwperf::BigNat{1U}, mwperf::testing::c30::scalar(1),
       mwperf::testing::c30::scalar(1), std::nullopt},
      {mwperf::BigNat{2U}, mwperf::testing::c30::scalar(1),
       mwperf::testing::c30::scalar(1, 2), std::nullopt},
      {mwperf::BigNat{3U}, mwperf::testing::c30::scalar(1, 2),
       mwperf::testing::c30::scalar(1, 4), std::nullopt},
      {mwperf::BigNat{4U}, mwperf::testing::c30::scalar(1, 2),
       mwperf::testing::c30::scalar(1, 4), std::nullopt}};
  const auto observation = validate(std::move(bundle));
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{4U}};
  options.run_diagnostic_fits = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  auto analyzed = mwperf::analyze_compression_observations_v1(
      observation, options);
  REQUIRE(analyzed);

  const auto prediction = mwperf::derive_framework_empirical_prediction_v1(
      observation, analyzed.value(), options);
  CHECK(prediction.observation_digest == observation.digest());
  CHECK(prediction.analysis_digest == analyzed.value().analysis_digest);
  CHECK(prediction.target_id == observation.value().bindings.target.target_id);
  CHECK(prediction.calculation_status ==
        mwperf::FrameworkPredictionAvailabilityV1::available);
  CHECK_FALSE(prediction.calculation_reason_code.has_value());
  CHECK(prediction.observed_complete_through == mwperf::BigNat{4U});
  CHECK(prediction.prefix_cutoff == mwperf::BigNat{4U});
  CHECK(prediction.constant_tail_from == mwperf::BigNat{5U});
  CHECK_FALSE(prediction.response_has_numerical_enclosures);

  REQUIRE(prediction.response_points.size() == 5U);
  for (std::size_t level = 0U; level < prediction.response_points.size();
       ++level) {
    CHECK(prediction.response_points[level].backlog_level ==
          mwperf::BigNat{level});
    CHECK(prediction.response_points[level].constant_tail_anchor ==
          (level == 4U));
  }
  CHECK(prediction.response_points[0U].observation_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::structural_zero);
  CHECK(prediction.response_points[1U].observation_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(prediction.response_points[2U].observation_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(prediction.response_points[3U].observation_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(prediction.response_points[4U].observation_status ==
        mwperf::EmpiricalFiniteWindowPointStatusV1::available);
  CHECK(prediction.response_points[0U].observed_response.value.is_zero());
  CHECK(prediction.response_points[1U].observed_response.value == rational(1));
  CHECK(prediction.response_points[2U].observed_response.value ==
        rational(1, 2));
  CHECK(prediction.response_points[3U].observed_response.value ==
        rational(1, 2));
  CHECK(prediction.response_points[4U].observed_response.value ==
        rational(1, 2));

  REQUIRE(prediction.stationary_pmf.size() == 5U);
  CHECK(prediction.stationary_pmf[0U].backlog_level == mwperf::BigNat{0U});
  CHECK(prediction.stationary_pmf[1U].backlog_level == mwperf::BigNat{1U});
  CHECK(prediction.stationary_pmf[2U].backlog_level == mwperf::BigNat{2U});
  CHECK(prediction.stationary_pmf[3U].backlog_level == mwperf::BigNat{3U});
  CHECK(prediction.stationary_pmf[4U].backlog_level == mwperf::BigNat{4U});
  REQUIRE(prediction.stationary_pmf[0U].probability.available());
  REQUIRE(prediction.stationary_pmf[1U].probability.available());
  REQUIRE(prediction.stationary_pmf[2U].probability.available());
  REQUIRE(prediction.stationary_pmf[3U].probability.available());
  REQUIRE(prediction.stationary_pmf[4U].probability.available());
  CHECK(*prediction.stationary_pmf[0U].probability.value == rational(3, 4));
  CHECK(*prediction.stationary_pmf[1U].probability.value == rational(1, 4));
  CHECK(prediction.stationary_pmf[2U].probability.value->is_zero());
  CHECK(prediction.stationary_pmf[3U].probability.value->is_zero());
  CHECK(prediction.stationary_pmf[4U].probability.value->is_zero());

  REQUIRE(prediction.remaining_tail_probability.available());
  REQUIRE(prediction.empty_probability.available());
  REQUIRE(prediction.first_backlog_moment.available());
  REQUIRE(prediction.second_backlog_moment.available());
  REQUIRE(prediction.mean_sojourn.available());
  REQUIRE(prediction.arrival_mean.available());
  CHECK(prediction.remaining_tail_probability.value->is_zero());
  CHECK(*prediction.empty_probability.value == rational(3, 4));
  CHECK(*prediction.first_backlog_moment.value == rational(1, 4));
  CHECK(*prediction.second_backlog_moment.value == rational(1, 4));
  CHECK(*prediction.mean_sojourn.value == rational(1));
  CHECK(*prediction.arrival_mean.value == rational(1, 4));
}

TEST_CASE(
    "C32 framework prediction distinguishes empirical zero from missing response",
    "[c32][cp09][math][unit][prediction][status]") {
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{4U}};
  options.run_diagnostic_fits = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};

  SECTION("an observed positive-backlog zero is consumed then rejected scientifically") {
    auto bundle = mwperf::testing::c30::exact_bundle(
        mwperf::ObservationSourceRoleV1::weighted_ensemble);
    bundle.replications.front().blocks.front().levels[1U].served_mass =
        mwperf::testing::c30::scalar(0);
    const auto observation = validate(std::move(bundle));
    auto analyzed = mwperf::analyze_compression_observations_v1(
        observation, options);
    REQUIRE(analyzed);
    const auto prediction =
        mwperf::derive_framework_empirical_prediction_v1(
            observation, analyzed.value(), options);
    REQUIRE(prediction.response_points.size() == 3U);
    CHECK(prediction.response_points[1U].observation_status ==
          mwperf::EmpiricalFiniteWindowPointStatusV1::available);
    CHECK(prediction.response_points[1U].observed_response.value.is_zero());
    CHECK(prediction.calculation_status ==
          mwperf::FrameworkPredictionAvailabilityV1::unavailable);
    REQUIRE(prediction.calculation_reason_code);
    CHECK_FALSE(prediction.calculation_reason_code->empty());
    CHECK_FALSE(prediction.first_backlog_moment.available());
    CHECK(prediction.first_backlog_moment.reason_code ==
          prediction.calculation_reason_code);
  }

  SECTION("a missing positive-backlog anchor is never filled with zero") {
    auto bundle = mwperf::testing::c30::exact_bundle(
        mwperf::ObservationSourceRoleV1::weighted_ensemble);
    auto& levels = bundle.replications.front().blocks.front().levels;
    levels[1U].backlog_level = mwperf::BigNat{3U};
    std::swap(levels[1U], levels[2U]);
    const auto observation = validate(std::move(bundle));
    auto analyzed = mwperf::analyze_compression_observations_v1(
        observation, options);
    REQUIRE(analyzed);
    REQUIRE(analyzed.value().empirical_finite_window_response);
    CHECK(analyzed.value().empirical_finite_window_response->complete_through ==
          mwperf::BigNat{0U});
    const auto prediction =
        mwperf::derive_framework_empirical_prediction_v1(
            observation, analyzed.value(), options);
    CHECK(prediction.calculation_status ==
          mwperf::FrameworkPredictionAvailabilityV1::unavailable);
    CHECK(prediction.calculation_reason_code ==
          std::optional<std::string>{
              "contiguous_response_requires_positive_anchor"});
    CHECK(prediction.response_points.empty());
    CHECK_FALSE(prediction.empty_probability.available());
    CHECK(prediction.empty_probability.reason_code ==
          prediction.calculation_reason_code);
  }

  SECTION("an analytic Poisson arrival is decoded without truncating its moments") {
    auto bundle = mwperf::testing::c30::exact_bundle(
        mwperf::ObservationSourceRoleV1::weighted_ensemble);
    bundle.bindings.arrival.arrival_family_id =
        "iid_independent_poisson_v1";
    bundle.bindings.arrival.target_arrival =
        mwperf::TargetArrivalOvershootDescriptorV1{
            "iid_independent_poisson_overshoot_v1", 1U,
            mwperf::testing::c30::digest('c')};
    bundle.bindings.arrival.mean = rational(1, 4);
    bundle.bindings.arrival.second_moment = rational(5, 16);
    bundle.capabilities.exact_target_arrival_marginal =
        mwperf::testing::c30::unavailable("infinite_support");
    const auto observation = validate(std::move(bundle));
    options.poisson_overshoot =
        mwperf::CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1{
            "iid_independent_poisson_overshoot_v1",
            1U,
            {{rational(1), rational(1, 4), UINT64_C(0x3fd0000000000000)}},
            mwperf::testing::c30::digest('b'),
            mwperf::testing::c30::digest('c'),
            cp09_tolerance(),
            std::numeric_limits<std::uint64_t>::max()};
    auto analyzed = mwperf::analyze_compression_observations_v1(
        observation, options);
    REQUIRE(analyzed);
    const auto prediction =
        mwperf::derive_framework_empirical_prediction_v1(
            observation, analyzed.value(), options);
    CHECK(prediction.calculation_status ==
          mwperf::FrameworkPredictionAvailabilityV1::available);
    CHECK_FALSE(prediction.calculation_reason_code.has_value());
    REQUIRE(prediction.response_points.size() == 3U);
    REQUIRE(prediction.stationary_pmf.size() == 3U);
    CHECK(prediction.empty_probability.available());
    CHECK(prediction.first_backlog_moment.available());
    CHECK(prediction.second_backlog_moment.available());
    CHECK(prediction.mean_sojourn.available());
    CHECK(prediction.arrival_mean.available());
    REQUIRE(prediction.poisson_arrival_reconstruction);
    const auto& reconstruction =
        *prediction.poisson_arrival_reconstruction;
    CHECK(reconstruction.descriptor_digest ==
          mwperf::testing::c30::digest('c'));
    CHECK(reconstruction.represented_through == mwperf::BigNat{2U});
    REQUIRE(reconstruction.probability_prefix.size() == 3U);
    CHECK(reconstruction.exact_first_raw_moment == rational(1, 4));
    CHECK(reconstruction.exact_second_raw_moment == rational(5, 16));
    CHECK(reconstruction.exact_third_raw_moment == rational(29, 64));
    CHECK(reconstruction.omitted_probability.value.is_nonnegative());
    CHECK(reconstruction.omitted_probability.absolute_error_bound
              .is_nonnegative());
    CHECK(reconstruction.omitted_first_raw_moment.value.is_nonnegative());
    CHECK(reconstruction.omitted_second_raw_moment.value.is_nonnegative());
    CHECK(reconstruction.omitted_third_raw_moment.value.is_nonnegative());

    const auto repeated =
        mwperf::derive_framework_empirical_prediction_v1(
            observation, analyzed.value(), options);
    CHECK(repeated == prediction);
  }
}

TEST_CASE("C32 raw mode preserves shared tail drift gap and tie mathematics",
          "[c32][cp09][math][unit]") {
  const auto observation =
      validate(mwperf::testing::c30::exact_gap_bundle());
  mwperf::CompressionAnalysisOptionsV1 legacy;
  // Both cutoffs retain positive observed tails, so every legacy finite-window
  // quantity is defined and can be compared directly.  The separate raw test
  // above covers the no-tail/K=0 typed-unavailability edges.
  legacy.cutoffs = {mwperf::BigNat{0U}, mwperf::BigNat{1U}};
  legacy.run_diagnostic_fits = false;
  legacy.stationary_coefficients_established = true;
  legacy.prefix_preservation_established = true;
  auto dense = mwperf::analyze_compression_observations_v1(
      observation, legacy);
  REQUIRE(dense);

  mwperf::CompressionAnalysisOptionsV1 raw = legacy;
  raw.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  raw.ensemble_population_size = mwperf::BigNat{64U};
  auto sparse = mwperf::analyze_compression_observations_v1(
      observation, raw);
  REQUIRE(sparse);
  REQUIRE(sparse.value().cutoffs.size() == dense.value().cutoffs.size());
  for (std::size_t index = 0U; index < dense.value().cutoffs.size(); ++index) {
    CHECK(sparse.value().cutoffs[index].tail ==
          dense.value().cutoffs[index].tail);
    CHECK(sparse.value().cutoffs[index].decomposition ==
          dense.value().cutoffs[index].decomposition);
  }
  CHECK(sparse.value().finite_window == dense.value().finite_window);
  CHECK(sparse.value().competition == dense.value().competition);
  CHECK(sparse.value().ties == dense.value().ties);
}

TEST_CASE("C32 finite-arrival cutoff sweep preserves exact overshoot rewards",
          "[c32][cp09][math][unit]") {
  const auto observation =
      validate(mwperf::testing::c30::exact_gap_bundle());
  mwperf::CompressionAnalysisOptionsV1 batch_options;
  // The fixture has two arrival atoms.  Three cutoffs select the atom-wise
  // moving-window sweep, while each one-cutoff evaluation below selects the
  // established cutoff-wise evaluator.
  batch_options.cutoffs =
      {mwperf::BigNat{0U}, mwperf::BigNat{1U}, mwperf::BigNat{2U}};
  batch_options.run_diagnostic_fits = false;
  batch_options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  batch_options.ensemble_population_size = mwperf::BigNat{64U};
  auto batch = mwperf::analyze_compression_observations_v1(
      observation, batch_options);
  REQUIRE(batch);
  REQUIRE(batch.value().finite_window.cutoffs.size() ==
          batch_options.cutoffs.size());

  for (std::size_t index = 0U; index < batch_options.cutoffs.size(); ++index) {
    auto scalar_options = batch_options;
    scalar_options.cutoffs = {batch_options.cutoffs[index]};
    auto scalar = mwperf::analyze_compression_observations_v1(
        observation, scalar_options);
    REQUIRE(scalar);
    REQUIRE(scalar.value().finite_window.cutoffs.size() == 1U);
    CHECK(batch.value().finite_window.cutoffs[index] ==
          scalar.value().finite_window.cutoffs.front());
  }
}

TEST_CASE("C32 Poisson innovation is certified without truncating the law",
          "[c32][cp09][math][unit]") {
  auto bundle = mwperf::testing::c30::exact_gap_bundle();
  const auto descriptor_digest = mwperf::testing::c30::digest('c');
  const auto operational_digest = mwperf::testing::c30::digest('d');
  bundle.bindings.arrival.target_arrival =
      mwperf::TargetArrivalOvershootDescriptorV1{
          "iid_independent_poisson_overshoot_v1", 1U,
          descriptor_digest};
  bundle.bindings.arrival.mean = rational(1, 2);
  bundle.bindings.arrival.second_moment = rational(3, 4);
  bundle.capabilities.exact_target_arrival_marginal =
      mwperf::testing::c30::unavailable("infinite_support");
  const auto observation = validate(std::move(bundle));

  mwperf::BigInt enormous_value = 2'000'000;
  auto enormous = mwperf::BigNat::from_big_int(std::move(enormous_value));
  REQUIRE(enormous);
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}, enormous.value()};
  options.run_diagnostic_fits = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  options.poisson_overshoot =
      mwperf::CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1{
          "iid_independent_poisson_overshoot_v1",
          1U,
          {{rational(1), rational(1, 2), UINT64_C(0x3fe0000000000000)}},
          operational_digest,
          descriptor_digest,
          cp09_tolerance(),
          1'000'000U};

  auto result = mwperf::analyze_compression_observations_v1(observation,
                                                             options);
  REQUIRE(result);
  REQUIRE(result.value().poisson_overshoot_evaluation);
  CHECK(result.value().poisson_overshoot_evaluation->descriptor_digest ==
        descriptor_digest);
  CHECK(result.value().poisson_overshoot_evaluation->recurrence_steps <=
        1'000'000U);
  REQUIRE(result.value().finite_window.cutoffs.size() == 2U);
  CHECK(result.value().finite_window.cutoffs.front()
            .overshoot_reward_normalized.available());
  CHECK(result.value().finite_window.cutoffs.back()
            .overshoot_reward_normalized.available());

  // The sparse physical profile and the four empirical tail rewards at the
  // same arbitrary cutoff remain available and unchanged by the compact
  // analytic Poisson evaluator.
  const auto& tail = result.value().cutoffs.back().tail;
  CHECK(tail.tail_probability.available());
  CHECK(tail.tail_service_mass.available());
  CHECK(tail.backlog_tail_reward.available());
  CHECK(tail.backlog_service_tail_reward.available());
}

TEST_CASE("C32 mixed Poisson overshoot is combined with exact state weights",
          "[c32][cp09][math][unit]") {
  auto bundle = mwperf::testing::c30::exact_gap_bundle();
  const auto descriptor_digest = mwperf::testing::c30::digest('e');
  bundle.bindings.arrival.target_arrival =
      mwperf::TargetArrivalOvershootDescriptorV1{
          "iid_mixed_poisson_overshoot_v1", 1U, descriptor_digest};
  bundle.bindings.arrival.mean = rational(1, 2);
  bundle.bindings.arrival.second_moment = rational(13, 16);
  bundle.capabilities.exact_target_arrival_marginal =
      mwperf::testing::c30::unavailable("infinite_support");
  const auto observation = validate(std::move(bundle));

  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}, mwperf::BigNat{2U}};
  options.run_diagnostic_fits = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  options.poisson_overshoot =
      mwperf::CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1{
          "iid_mixed_poisson_overshoot_v1",
          1U,
          {{rational(1, 2), rational(1, 4),
            UINT64_C(0x3fd0000000000000)},
           {rational(1, 2), rational(3, 4),
            UINT64_C(0x3fe8000000000000)}},
          mwperf::testing::c30::digest('d'),
          descriptor_digest,
          cp09_tolerance(),
          1'000'000U};

  auto result =
      mwperf::analyze_compression_observations_v1(observation, options);
  REQUIRE(result);
  REQUIRE(result.value().poisson_overshoot_evaluation);
  CHECK(result.value().poisson_overshoot_evaluation->status.available());
  REQUIRE(result.value().finite_window.cutoffs.size() == 2U);
  CHECK(result.value().finite_window.cutoffs.front()
            .overshoot_reward_normalized.available());
  CHECK(result.value().finite_window.cutoffs.back()
            .overshoot_reward_normalized.available());
}
