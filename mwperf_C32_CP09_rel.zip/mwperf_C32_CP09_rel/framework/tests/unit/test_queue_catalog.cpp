#include <algorithm>
#include <cstddef>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace {

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto parsed = mwperf::TypedLabel::text(value);
  REQUIRE(parsed);
  return std::move(parsed.value());
}

[[nodiscard]] mwperf::QueueId text_queue(const std::string& value) {
  return mwperf::QueueId(text_label(value));
}

[[nodiscard]] mwperf::QueueId numeric_queue(const std::uint64_t value) {
  return mwperf::QueueId(mwperf::TypedLabel::numeric(mwperf::BigNat(value)));
}

[[nodiscard]] mwperf::QueueId numeric_queue(mwperf::BigNat value) {
  return mwperf::QueueId(
      mwperf::TypedLabel::numeric(std::move(value)));
}

[[nodiscard]] mwperf::BigNat exact_nat(const std::string& lexeme) {
  auto parsed = mwperf::parse_exact_nonnegative_integer(
      mwperf::JsonNumber(lexeme), mwperf::BoundPolicy::unbounded());
  REQUIRE(parsed);
  return std::move(parsed.value());
}

[[nodiscard]] mwperf::AuthoredQueue queue(
    mwperf::QueueId id, const std::size_t position,
    std::optional<mwperf::LegacyVoqCoordinate> legacy = std::nullopt) {
  const std::string base = "/switch/queues/" + std::to_string(position);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{std::move(id),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<std::optional<mwperf::LegacyVoqCoordinate>>{
          std::move(legacy), provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::LegacyVoqCoordinate coordinate(
    mwperf::BigNat source, mwperf::BigNat destination,
    const std::size_t position) {
  const std::string base =
      "/switch/queues/" + std::to_string(position) + "/legacy_voq";
  return mwperf::LegacyVoqCoordinate{
      mwperf::AuthoredField<mwperf::BigNat>{std::move(source),
                                            provenance(base + "/0")},
      mwperf::AuthoredField<mwperf::BigNat>{std::move(destination),
                                            provenance(base + "/1")},
      provenance(base)};
}

[[nodiscard]] mwperf::AuthoredSwitchConfig generalized_switch(
    std::vector<mwperf::AuthoredQueue> queues,
    std::optional<mwperf::BigNat> legacy_n_ports = std::nullopt) {
  return mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          std::move(queues), provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::move(legacy_n_ports), provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
}

[[nodiscard]] mwperf::AuthoredSchedulerConfig conflict_scheduler(
    std::optional<std::vector<mwperf::AuthoredField<mwperf::QueueId>>>
        priority) {
  const mwperf::ConflictConstraint constraint{
      mwperf::AuthoredField<std::vector<mwperf::ConflictPair>>{
          {}, provenance("/scheduler/params/constraint/conflicts")},
      provenance("/scheduler/params/constraint")};
  return mwperf::AuthoredSchedulerConfig{
      mwperf::ConflictGraphMaxWeightScheduler{
          mwperf::AuthoredField<mwperf::ConflictConstraint>{
              constraint, provenance("/scheduler/params/constraint")},
          mwperf::AuthoredPriority{std::move(priority),
                                   provenance("/scheduler/params/priority")},
          mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
              std::nullopt,
              provenance("/scheduler/params/max_search_states")},
          provenance("/scheduler")},
      provenance("/scheduler")};
}

[[nodiscard]] std::vector<mwperf::AuthoredField<mwperf::QueueId>>
authored_priority(const std::vector<mwperf::QueueId>& ids) {
  std::vector<mwperf::AuthoredField<mwperf::QueueId>> result;
  result.reserve(ids.size());
  for (std::size_t index = 0; index < ids.size(); ++index) {
    result.push_back(mwperf::AuthoredField<mwperf::QueueId>{
        ids[index], provenance("/scheduler/params/priority/" +
                               std::to_string(index))});
  }
  return result;
}

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::DenseQueueIndex>);
static_assert(
    !std::is_convertible_v<mwperf::DenseQueueIndex, std::size_t>);
static_assert(!std::is_default_constructible_v<mwperf::QueueCatalog>);
static_assert(!std::is_default_constructible_v<mwperf::PriorityOrder>);

TEST_CASE("C04 queue catalog preserves authored order and typed identity",
          "[c04][unit]") {
  constexpr const char* spelling = "1844674407370955161600000";
  const mwperf::QueueId numeric = numeric_queue(exact_nat(spelling));
  const mwperf::QueueId textual = text_queue(spelling);
  auto built = mwperf::build_queue_catalog(generalized_switch(
      {queue(numeric, 0U), queue(textual, 1U)}));
  REQUIRE(built);
  REQUIRE(built.value().size() == 2U);

  auto zero = built.value().index_at(0U);
  auto one = built.value().index_at(1U);
  REQUIRE(zero);
  REQUIRE(one);
  CHECK(built.value().queue_id(zero.value()) == numeric);
  CHECK(built.value().queue_id(one.value()) == textual);
  CHECK_FALSE(numeric == textual);

  auto numeric_dense =
      built.value().resolve(numeric, provenance("/reference/numeric"));
  auto text_dense =
      built.value().resolve(textual, provenance("/reference/text"));
  REQUIRE(numeric_dense);
  REQUIRE(text_dense);
  CHECK(numeric_dense.value().ordinal() == 0U);
  CHECK(text_dense.value().ordinal() == 1U);

  auto past_end = built.value().index_at(2U);
  REQUIRE_FALSE(past_end);
  CHECK(past_end.error().code == "index_out_of_range");
}

TEST_CASE("C04 queue catalog retains duplicate legacy coordinates and derives "
          "an exact extent",
          "[c04][unit]") {
  const mwperf::BigNat huge = exact_nat("184467440737095516160000");
  auto built = mwperf::build_queue_catalog(generalized_switch(
      {queue(text_queue("a"), 0U, coordinate(huge, mwperf::BigNat(7U), 0U)),
       queue(text_queue("b"), 1U, coordinate(huge, mwperf::BigNat(7U), 1U))}));
  REQUIRE(built);
  REQUIRE(built.value().legacy_n_ports().has_value());
  CHECK(built.value().legacy_n_ports()->derived);
  CHECK(built.value().legacy_n_ports()->value.to_decimal_string() ==
        "184467440737095516160001");
  REQUIRE(built.value().entries().size() == 2U);
  REQUIRE(built.value().entries()[0].legacy_voq.has_value());
  REQUIRE(built.value().entries()[1].legacy_voq.has_value());
  CHECK(built.value().entries()[0].legacy_voq->source.value ==
        built.value().entries()[1].legacy_voq->source.value);
}

TEST_CASE("C04 legacy extent preserves explicit and absent forms",
          "[c04][unit]") {
  SECTION("explicit exact extent") {
    const mwperf::BigNat extent = exact_nat("184467440737095516160001");
    auto built = mwperf::build_queue_catalog(generalized_switch(
        {queue(text_queue("q"), 0U,
               coordinate(exact_nat("184467440737095516160000"),
                          mwperf::BigNat(0U), 0U))},
        extent));
    REQUIRE(built);
    REQUIRE(built.value().legacy_n_ports().has_value());
    CHECK_FALSE(built.value().legacy_n_ports()->derived);
    CHECK(built.value().legacy_n_ports()->value == extent);
  }

  SECTION("no coordinates leaves absent extent absent") {
    auto built = mwperf::build_queue_catalog(
        generalized_switch({queue(text_queue("q"), 0U)}));
    REQUIRE(built);
    CHECK_FALSE(built.value().legacy_n_ports().has_value());
  }
}

TEST_CASE("C04 queue catalog rejects invalid switch/catalog boundaries",
          "[c04][negative]") {
  SECTION("empty catalog") {
    auto built = mwperf::build_queue_catalog(generalized_switch({}));
    REQUIRE_FALSE(built);
    CHECK(built.error().code == "empty_queue_catalog");
  }

  SECTION("duplicate typed ID") {
    const mwperf::QueueId q = text_queue("q");
    auto built = mwperf::build_queue_catalog(
        generalized_switch({queue(q, 0U), queue(q, 1U)}));
    REQUIRE_FALSE(built);
    CHECK(built.error().code == "duplicate_queue_id");
    REQUIRE(built.error().notes.size() == 1U);
    CHECK(built.error().notes[0] == "first definition: /switch/queues/0");
  }

  SECTION("coordinate at declared extent") {
    auto built = mwperf::build_queue_catalog(generalized_switch(
        {queue(text_queue("q"), 0U,
               coordinate(mwperf::BigNat(3U), mwperf::BigNat(0U), 0U))},
        mwperf::BigNat(3U)));
    REQUIRE_FALSE(built);
    CHECK(built.error().code == "legacy_voq_out_of_extent");
    CHECK(built.error().json_pointer ==
          "/switch/queues/0/legacy_voq/0");
  }

  SECTION("legacy switch remains unexpanded") {
    const auto pointer = provenance("/switch");
    mwperf::AuthoredSwitchConfig legacy = mwperf::LegacyCrossbarSwitchConfig{
        mwperf::AuthoredField<mwperf::BigNat>{mwperf::BigNat(2U), pointer},
        mwperf::AuthoredField<mwperf::BigNat>{mwperf::BigNat(4U), pointer},
        mwperf::AuthoredField<bool>{true, pointer}, pointer};
    auto built = mwperf::build_queue_catalog(legacy);
    REQUIRE_FALSE(built);
    CHECK(built.error().code == "unsupported_switch_kind");
  }
}

TEST_CASE("C04 null and explicit priorities produce inverse permutations",
          "[c04][unit]") {
  const std::vector<mwperf::QueueId> ids = {
      text_queue("q0"), numeric_queue(1U), text_queue("q2")};
  auto catalog = mwperf::build_queue_catalog(generalized_switch(
      {queue(ids[0], 0U), queue(ids[1], 1U), queue(ids[2], 2U)}));
  REQUIRE(catalog);

  auto identity = mwperf::resolve_priority(
      conflict_scheduler(std::nullopt), catalog.value());
  REQUIRE(identity);
  CHECK(identity.value().is_catalog_order());

  const std::vector<mwperf::QueueId> reverse = {ids[2], ids[1], ids[0]};
  auto explicit_order = mwperf::resolve_priority(
      conflict_scheduler(authored_priority(reverse)), catalog.value());
  REQUIRE(explicit_order);
  CHECK_FALSE(explicit_order.value().is_catalog_order());
  CHECK(explicit_order.value().queue_at_rank(0U).ordinal() == 2U);
  CHECK(explicit_order.value().rank_of(
            explicit_order.value().queue_at_rank(2U)) == 2U);
  CHECK(explicit_order.value().queue_to_rank()[0] == 2U);
  CHECK(explicit_order.value().queue_to_rank()[1] == 1U);
  CHECK(explicit_order.value().queue_to_rank()[2] == 0U);
}

TEST_CASE("C04 explicit priority rejects the first deterministic fault",
          "[c04][negative]") {
  const mwperf::QueueId q0 = text_queue("q0");
  const mwperf::QueueId q1 = numeric_queue(1U);
  auto catalog = mwperf::build_queue_catalog(
      generalized_switch({queue(q0, 0U), queue(q1, 1U)}));
  REQUIRE(catalog);

  SECTION("wrong length precedes reference checks") {
    auto result = mwperf::resolve_priority(
        conflict_scheduler(authored_priority({text_queue("missing")})),
        catalog.value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "priority_length_mismatch");
  }

  SECTION("duplicate") {
    auto result = mwperf::resolve_priority(
        conflict_scheduler(authored_priority({q0, q0})), catalog.value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "duplicate_priority_queue");
  }

  SECTION("typed identity mismatch") {
    auto result = mwperf::resolve_priority(
        conflict_scheduler(authored_priority({q0, text_queue("1")})),
        catalog.value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "unknown_queue_reference");
    CHECK(result.error().json_pointer == "/scheduler/params/priority/1");
  }
}

TEST_CASE("C04 every authored queue permutation round-trips through rank maps",
          "[c04][property]") {
  const std::vector<mwperf::QueueId> ids = {
      text_queue("a"), text_queue("b"), text_queue("c"), text_queue("d")};
  auto catalog = mwperf::build_queue_catalog(generalized_switch(
      {queue(ids[0], 0U), queue(ids[1], 1U), queue(ids[2], 2U),
       queue(ids[3], 3U)}));
  REQUIRE(catalog);

  std::vector<std::size_t> permutation = {0U, 1U, 2U, 3U};
  do {
    std::vector<mwperf::QueueId> ordered;
    ordered.reserve(permutation.size());
    for (const std::size_t ordinal : permutation) {
      ordered.push_back(ids[ordinal]);
    }
    auto resolved = mwperf::resolve_priority(
        conflict_scheduler(authored_priority(ordered)), catalog.value());
    REQUIRE(resolved);
    for (std::size_t rank = 0; rank < permutation.size(); ++rank) {
      const mwperf::DenseQueueIndex dense =
          resolved.value().queue_at_rank(rank);
      CHECK(dense.ordinal() == permutation[rank]);
      CHECK(resolved.value().rank_of(dense) == rank);
    }
  } while (std::next_permutation(permutation.begin(), permutation.end()));
}
