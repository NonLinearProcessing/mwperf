#include <atomic>
#include <array>
#include <filesystem>
#include <fstream>
#include <functional>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/document.hpp"

namespace {

class TemporaryAnalysis final {
 public:
  explicit TemporaryAnalysis(const std::string_view contents) {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory{MWPERF_TEST_TEMP_DIRECTORY};
    std::filesystem::create_directories(directory);
    path_ = directory /
            ("analysis_v1_" + std::to_string(next_id.fetch_add(1U)) +
             ".json");
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to create analysis fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output) {
      throw std::runtime_error("failed to write analysis fixture");
    }
  }

  TemporaryAnalysis(const TemporaryAnalysis&) = delete;
  TemporaryAnalysis& operator=(const TemporaryAnalysis&) = delete;

  ~TemporaryAnalysis() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

[[nodiscard]] std::string make_analysis(
    std::string metrics,
    std::string selection = R"({"kind":"stationary_unique","parameters":{}})",
    std::string solver =
        R"({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})",
    std::string tail = R"({"kind":"none","parameters":{}})",
    std::string draw_grant = "null",
    std::string surrogate_parameters = "{}",
    std::string surrogate_version = "null") {
  return R"({"analysis_schema_version":"1.0.0","targets":["q0","q1"],"metrics":)" +
         std::move(metrics) +
         R"(,"surrogate":{"id":"provider","version":)" +
         std::move(surrogate_version) +
         R"(,"parameters":)" + std::move(surrogate_parameters) +
         R"(},"resolution":{"level":{"max_states":1000,"max_row_atoms":null},"tail":)" +
         std::move(tail) +
         R"(,"phase":{"max_phase_states":20},"optimizer":{"max_calls":100,"max_search_states_per_call":null},"sampling":{"max_generator_draws":)" +
         std::move(draw_grant) +
         R"(},"tolerance":{"linear_residual_abs":1e-12,"integration_abs":null,"tail_abs":0,"fixed_point_abs":null}},"selection":)" +
         std::move(selection) + R"(,"solver":)" + std::move(solver) + "}";
}

[[nodiscard]] mwperf::Result<mwperf::AnalysisSpec> parse_text(
    const std::string& text) {
  TemporaryAnalysis file(text);
  auto document = mwperf::load_document(file.path());
  if (!document) {
    return mwperf::Result<mwperf::AnalysisSpec>::failure(document.error());
  }
  return mwperf::parse_analysis_spec_v1(document.value());
}

[[nodiscard]] std::string all_metric_items() {
  return R"([
{"id":"m01","kind":"stationary_throughput","parameters":{}},
{"id":"m02","kind":"stationary_empty_probability","parameters":{}},
{"id":"m03","kind":"mean_sojourn","parameters":{}},
{"id":"m04","kind":"service_persistence","parameters":{}},
{"id":"m05","kind":"joint_backlog_covariance","parameters":{}},
{"id":"m06","kind":"stationary_backlog_pmf","parameters":{"max_level":10}},
{"id":"m07","kind":"stationary_backlog_pgf","parameters":{"points":[0,0.5,1]}},
{"id":"m08","kind":"stationary_backlog_moment","parameters":{"order":2}},
{"id":"m09","kind":"stationary_backlog_quantile","parameters":{"probability":0.95}},
{"id":"m10","kind":"stationary_backlog_tail","parameters":{"threshold":4}},
{"id":"m11","kind":"backlog_conditioned_service","parameters":{"levels":[0,1,2]}},
{"id":"m12","kind":"stationary_edge_reward","parameters":{"reward":"departure","moment_order":1}},
{"id":"m13","kind":"service_autocovariance","parameters":{"lags":[1,3]}},
{"id":"m14","kind":"lagged_cross_queue_covariance","parameters":{"lags":[2,4]}},
{"id":"m15","kind":"service_spectrum","parameters":{"frequencies":[0,1.25],"truncation_lag":8}},
{"id":"m16","kind":"service_window_count","parameters":{"width":5}},
{"id":"m17","kind":"mean_event_gap","parameters":{"event":"admission"}},
{"id":"m18","kind":"event_gap_distribution","parameters":{"event":"busy_denial","horizon":20}},
{"id":"m19","kind":"mean_binary_run","parameters":{"predicate":"threshold_above","threshold":3}},
{"id":"m20","kind":"binary_run_distribution","parameters":{"predicate":"busy","horizon":12}},
{"id":"m21","kind":"first_hit","parameters":{"set":{"kind":"at_or_above","level":7},"horizon":50,"include_mean":true}},
{"id":"m22","kind":"threshold_excursion","parameters":{"set":{"kind":"equal","level":0},"horizon":5,"include_mean":false}},
{"id":"m23","kind":"transient_backlog_law","parameters":{"horizons":[0,1,10]}},
{"id":"m24","kind":"fifo_delay","parameters":{"output":"pmf","horizon":20}},
{"id":"m25","kind":"fifo_delay_conditioned","parameters":{"output":"quantile","probability":0.9,"condition":{"kind":"class","value":"gold"}}},
{"id":"m26","kind":"counterfactual_opportunity_gap","parameters":{"convention_id":1,"horizon":3}},
{"id":"m27","kind":"joint_backlog_event","parameters":{"relation":"all_at_or_above","thresholds":[2,2]}},
{"id":"m28","kind":"joint_delay","parameters":{"sampling":"lagged","lag":0,"horizon":10}},
{"id":"m29","kind":"ordered_schedule_sequence","parameters":{"horizon":4,"retain_full_schedule":true}}
])";
}

[[nodiscard]] std::string transient_selection(std::string arrival_state) {
  return R"({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":2}],"controller_state":{},"arrival_state":)" +
         std::move(arrival_state) +
         R"(,"static_context":{},"surrogate_initial":{"phase_hint":0}}]}}})";
}

[[nodiscard]] std::string single_metric(const std::string_view kind,
                                        const std::string_view parameters) {
  return "[{\"id\":\"m\",\"kind\":\"" + std::string(kind) +
         "\",\"parameters\":" + std::string(parameters) + "}]";
}

}  // namespace

TEST_CASE("C03 analysis parser accepts every frozen metric wire tag",
          "[c03][unit]") {
  auto parsed = parse_text(make_analysis(all_metric_items()));
  INFO((!parsed ? parsed.error().code + ": " + parsed.error().message
                : std::string{}));
  REQUIRE(parsed);
  CHECK(parsed.value().analysis_schema_version == "1.0.0");
  REQUIRE(parsed.value().metrics.size() == 29U);
  REQUIRE(parsed.value().context != nullptr);
  for (const mwperf::MetricNode& metric : parsed.value().metrics) {
    CHECK(metric.context == parsed.value().context);
  }
  CHECK(std::holds_alternative<mwperf::StationaryThroughputMetric>(
      parsed.value().metrics.front().metric));
  CHECK(std::holds_alternative<mwperf::OrderedScheduleSequenceMetric>(
      parsed.value().metrics.back().metric));
  CHECK(parsed.value().context->targets.queue_ids.size() == 2U);
  CHECK(parsed.value().context->resolution.optimizer.max_calls->to_decimal_string() ==
        "100");
}

TEST_CASE("C03 analysis parser covers selection wire alternatives",
          "[c03][unit]") {
  const std::string metric =
      R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])";

  SECTION("stationary class") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_class","parameters":{"class_id":1}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::StationaryClassSelection>(
        parsed.value().context->selection));
  }
  SECTION("stationary mixture") {
    auto parsed = parse_text(make_analysis(
        metric,
        R"({"kind":"stationary_mixture","parameters":{"components":[{"class_id":"a","probability":0.25},{"class_id":"b","probability":0.75}]}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::StationaryMixtureSelection>(
        parsed.value().context->selection));
  }
  SECTION("fixed point unique") {
    auto parsed = parse_text(make_analysis(
        metric,
        R"({"kind":"fixed_point","parameters":{"mode":"unique"}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::FixedPointSelection>(
        parsed.value().context->selection));
  }
  SECTION("fixed point id") {
    auto parsed = parse_text(make_analysis(
        metric,
        R"({"kind":"fixed_point","parameters":{"mode":"id","solution_id":"root-a"}})"));
    REQUIRE(parsed);
  }
  SECTION("all transient arrival-state forms") {
    const std::string states[] = {
        R"({"kind":"trace_origin"})",
        R"({"kind":"global_periodic_origin"})",
        R"({"kind":"source_delay_origin"})",
        R"({"kind":"renewal_origin"})",
        R"({"kind":"private_markov_states","states":[{"source_id":"s0","state":"a"}]})",
        R"({"kind":"shared_round_state","state":"a"})"};
    for (const std::string& state : states) {
      auto parsed = parse_text(make_analysis(metric, transient_selection(state)));
      INFO((!parsed ? parsed.error().code + ": " + parsed.error().message
                    : std::string{}));
      REQUIRE(parsed);
      CHECK(std::holds_alternative<mwperf::TransientSelection>(
          parsed.value().context->selection));
    }
  }
}

TEST_CASE("C03 transient arrival references use physical token normalization",
          "[c03][unit][negative]") {
  const std::string metric =
      R"([{"id":"m","kind":"transient_backlog_law","parameters":{"horizons":[0]}}])";

  SECTION("private source and state references canonicalize") {
    auto parsed = parse_text(make_analysis(
        metric,
        transient_selection(
            R"({"kind":"private_markov_states","states":[{"source_id":" Source--A ","state":" ON  State "}]})")));
    REQUIRE(parsed);
    const auto& transient = std::get<mwperf::TransientSelection>(
        parsed.value().context->selection);
    const auto& state = std::get<mwperf::PrivateMarkovStates>(
        transient.atoms.front().arrival_state);
    REQUIRE(state.states.size() == 1U);
    CHECK(state.states.front().source_id == "source_a");
    CHECK(state.states.front().state == "on_state");
  }
  SECTION("shared state reference canonicalizes") {
    auto parsed = parse_text(make_analysis(
        metric, transient_selection(
                    R"({"kind":"shared_round_state","state":" READY--Now "})")));
    REQUIRE(parsed);
    const auto& transient = std::get<mwperf::TransientSelection>(
        parsed.value().context->selection);
    const auto& state = std::get<mwperf::SharedRoundState>(
        transient.atoms.front().arrival_state);
    CHECK(state.state == "ready_now");
  }
  SECTION("duplicates are detected after normalization") {
    auto parsed = parse_text(make_analysis(
        metric,
        transient_selection(
            R"({"kind":"private_markov_states","states":[{"source_id":"Source-A","state":"on"},{"source_id":"source_a","state":"off"}]})")));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.duplicate_arrival_source_state");
  }
}

TEST_CASE("C03 analysis parser covers solver and tail alternatives",
          "[c03][unit]") {
  const std::string metric =
      R"([{"id":"m","kind":"stationary_backlog_pmf","parameters":{}}])";
  SECTION("analytic and finite closed") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"analytic","parameters":{"precision_bits":256,"max_iterations":40}})",
        R"({"kind":"finite_closed","parameters":{"max_level":20}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::AnalyticSolver>(
        parsed.value().context->solver));
    CHECK(std::holds_alternative<mwperf::FiniteClosedTailResolution>(
        parsed.value().context->resolution.tail));
  }
  SECTION("monte carlo and certified truncation") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"monte_carlo","parameters":{"replications":100,"confidence_level":0.95,"interval_method":"hoeffding"}})",
        R"({"kind":"certified_truncation","parameters":{"max_level":30,"max_tail_mass":1e-6}})",
        "100000"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::MonteCarloSolver>(
        parsed.value().context->solver));
  }
  SECTION("every Monte Carlo interval method is retained") {
    const std::array methods{
        std::pair{"exact_binomial",
                  mwperf::MonteCarloIntervalMethod::exact_binomial},
        std::pair{"none", mwperf::MonteCarloIntervalMethod::none}};
    for (const auto& [wire, expected] : methods) {
      const std::string solver =
          R"({"kind":"monte_carlo","parameters":{"replications":7,"confidence_level":0.9,"interval_method":")" +
          std::string(wire) + R"("}})";
      auto parsed = parse_text(make_analysis(metric,
                                             R"({"kind":"stationary_unique","parameters":{}})",
                                             solver, R"({"kind":"none","parameters":{}})",
                                             "100"));
      INFO(wire);
      REQUIRE(parsed);
      const auto& monte_carlo = std::get<mwperf::MonteCarloSolver>(
          parsed.value().context->solver);
      CHECK(monte_carlo.interval_method == expected);
    }
  }
  SECTION("direct and constant response") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"direct","parameters":{}})",
        R"({"kind":"constant_response","parameters":{"cutoff":2}})"));
    REQUIRE(parsed);
    CHECK(std::holds_alternative<mwperf::DirectSolver>(
        parsed.value().context->solver));
  }
}

TEST_CASE("C03 analysis parser preserves complementary resolution grants",
          "[c03][unit]") {
  std::string analysis = make_analysis(
      single_metric("stationary_throughput", "{}"),
      R"({"kind":"stationary_unique","parameters":{}})",
      R"({"kind":"enumerated","parameters":{"linear_method":"sparse_iterative","max_iterations":null}})",
      R"({"kind":"none","parameters":{}})", "789");

  const auto replace_once = [&analysis](const std::string_view from,
                                        const std::string_view to) {
    const std::size_t position = analysis.find(from);
    REQUIRE(position != std::string::npos);
    analysis.replace(position, from.size(), to);
  };
  replace_once(R"("max_states":1000,"max_row_atoms":null)",
               R"("max_states":null,"max_row_atoms":17)");
  replace_once(R"("max_phase_states":20)",
               R"("max_phase_states":null)");
  replace_once(R"("max_calls":100,"max_search_states_per_call":null)",
               R"("max_calls":null,"max_search_states_per_call":23)");
  replace_once(
      R"("linear_residual_abs":1e-12,"integration_abs":null,"tail_abs":0,"fixed_point_abs":null)",
      R"("linear_residual_abs":0.125,"integration_abs":0.25,"tail_abs":0,"fixed_point_abs":3.5)");

  auto parsed = parse_text(analysis);
  INFO((!parsed ? parsed.error().code + ": " + parsed.error().message
                : std::string{}));
  REQUIRE(parsed);
  const mwperf::ResolutionEnvelope& resolution =
      parsed.value().context->resolution;
  CHECK_FALSE(resolution.level.max_states);
  REQUIRE(resolution.level.max_row_atoms);
  CHECK(resolution.level.max_row_atoms->to_decimal_string() == "17");
  CHECK_FALSE(resolution.phase.max_phase_states);
  CHECK_FALSE(resolution.optimizer.max_calls);
  REQUIRE(resolution.optimizer.max_search_states_per_call);
  CHECK(resolution.optimizer.max_search_states_per_call->to_decimal_string() ==
        "23");
  REQUIRE(resolution.sampling.max_generator_draws);
  CHECK(resolution.sampling.max_generator_draws->to_decimal_string() == "789");

  REQUIRE(resolution.tolerance.linear_residual_abs);
  REQUIRE(resolution.tolerance.integration_abs);
  REQUIRE(resolution.tolerance.tail_abs);
  REQUIRE(resolution.tolerance.fixed_point_abs);
  CHECK(resolution.tolerance.linear_residual_abs->to_canonical_string() ==
        "1/8");
  CHECK(resolution.tolerance.integration_abs->to_canonical_string() ==
        "1/4");
  CHECK(resolution.tolerance.tail_abs->to_canonical_string() == "0/1");
  CHECK(resolution.tolerance.fixed_point_abs->to_canonical_string() ==
        "7/2");
}

TEST_CASE("C03 metric union alternatives are closed and retained",
          "[c03][unit]") {
  SECTION("edge rewards") {
    const std::array rewards{
        std::pair{"increment", mwperf::EdgeRewardKind::increment},
        std::pair{"departure", mwperf::EdgeRewardKind::departure},
        std::pair{"arrival", mwperf::EdgeRewardKind::arrival}};
    for (const auto& [wire, expected] : rewards) {
      auto parsed = parse_text(make_analysis(single_metric(
          "stationary_edge_reward",
          std::string{"{\"reward\":\""} + wire +
              "\",\"moment_order\":1}")));
      INFO(wire);
      REQUIRE(parsed);
      const auto& metric = std::get<mwperf::StationaryEdgeRewardMetric>(
          parsed.value().metrics.front().metric);
      CHECK(metric.reward == expected);
    }
  }

  SECTION("gap-event tags in both gap metric shapes") {
    const std::array events{
        std::pair{"departure", mwperf::GapEventKind::departure},
        std::pair{"admission", mwperf::GapEventKind::admission},
        std::pair{"busy_denial", mwperf::GapEventKind::busy_denial}};
    for (const auto& [wire, expected] : events) {
      auto mean = parse_text(make_analysis(single_metric(
          "mean_event_gap", std::string{"{\"event\":\""} + wire + "\"}")));
      INFO(wire);
      REQUIRE(mean);
      CHECK(std::get<mwperf::MeanEventGapMetric>(
                mean.value().metrics.front().metric)
                .event == expected);

      auto distribution = parse_text(make_analysis(single_metric(
          "event_gap_distribution",
          std::string{"{\"event\":\""} + wire + "\",\"horizon\":0}")));
      REQUIRE(distribution);
      CHECK(std::get<mwperf::EventGapDistributionMetric>(
                distribution.value().metrics.front().metric)
                .event == expected);
    }
  }

  SECTION("binary predicates include threshold distribution") {
    struct Fixture final {
      const char* wire;
      mwperf::BinaryPredicateKind expected;
      bool has_threshold;
    };
    const std::array fixtures{
        Fixture{"busy", mwperf::BinaryPredicateKind::busy, false},
        Fixture{"idle", mwperf::BinaryPredicateKind::idle, false},
        Fixture{"busy_denial", mwperf::BinaryPredicateKind::busy_denial,
                false},
        Fixture{"threshold_above",
                mwperf::BinaryPredicateKind::threshold_above, true}};
    for (const Fixture& fixture : fixtures) {
      const std::string threshold =
          fixture.has_threshold ? R"(,"threshold":3)" : "";
      auto mean = parse_text(make_analysis(single_metric(
          "mean_binary_run", std::string{"{\"predicate\":\""} +
                                 fixture.wire + "\"" + threshold + "}")));
      INFO(fixture.wire);
      REQUIRE(mean);
      const auto& mean_metric = std::get<mwperf::MeanBinaryRunMetric>(
          mean.value().metrics.front().metric);
      CHECK(mean_metric.predicate == fixture.expected);
      CHECK(mean_metric.threshold.has_value() == fixture.has_threshold);

      auto distribution = parse_text(make_analysis(single_metric(
          "binary_run_distribution",
          std::string{"{\"predicate\":\""} + fixture.wire + "\"" +
              threshold + ",\"horizon\":6}")));
      REQUIRE(distribution);
      const auto& distribution_metric =
          std::get<mwperf::BinaryRunDistributionMetric>(
              distribution.value().metrics.front().metric);
      CHECK(distribution_metric.predicate == fixture.expected);
      CHECK(distribution_metric.threshold.has_value() ==
            fixture.has_threshold);
    }
  }

  SECTION("every hit-set tag") {
    const std::array sets{
        std::pair{"at_or_above", mwperf::HitSetKind::at_or_above},
        std::pair{"at_or_below", mwperf::HitSetKind::at_or_below},
        std::pair{"equal", mwperf::HitSetKind::equal}};
    for (const auto& [wire, expected] : sets) {
      auto parsed = parse_text(make_analysis(single_metric(
          "first_hit", std::string{"{\"set\":{\"kind\":\""} + wire +
                           "\",\"level\":0},\"horizon\":0,\"include_mean\":false}")));
      INFO(wire);
      REQUIRE(parsed);
      CHECK(std::get<mwperf::FirstHitMetric>(
                parsed.value().metrics.front().metric)
                .set.kind == expected);
    }
  }

  SECTION("FIFO outputs and conditioning alternatives") {
    const std::array unconditioned{
        std::pair{"{\"output\":\"pmf\",\"horizon\":0}", 0U},
        std::pair{"{\"output\":\"tail\",\"horizon\":0}", 1U},
        std::pair{"{\"output\":\"quantile\",\"probability\":0.5}", 2U},
        std::pair{"{\"output\":\"moment\",\"order\":1}", 3U}};
    for (const auto& [parameters, expected_index] : unconditioned) {
      auto parsed = parse_text(
          make_analysis(single_metric("fifo_delay", parameters)));
      INFO(parameters);
      REQUIRE(parsed);
      const auto& metric = std::get<mwperf::FifoDelayMetric>(
          parsed.value().metrics.front().metric);
      CHECK(metric.request.index() == expected_index);
    }

    const std::array conditioned{
        std::pair{"{\"output\":\"pmf\",\"horizon\":0,\"condition\":{\"kind\":\"rank\",\"value\":1}}",
                  0U},
        std::pair{"{\"output\":\"tail\",\"horizon\":0,\"condition\":{\"kind\":\"batch\",\"value\":2}}",
                  1U},
        std::pair{"{\"output\":\"quantile\",\"probability\":0.5,\"condition\":{\"kind\":\"class\",\"value\":\"gold\"}}",
                  2U},
        std::pair{"{\"output\":\"moment\",\"order\":2,\"condition\":{\"kind\":\"phase\",\"value\":3}}",
                  3U}};
    for (std::size_t index = 0; index < conditioned.size(); ++index) {
      const auto& [parameters, expected_request_index] = conditioned[index];
      auto parsed = parse_text(make_analysis(
          single_metric("fifo_delay_conditioned", parameters)));
      INFO(parameters);
      REQUIRE(parsed);
      const auto& metric = std::get<mwperf::FifoDelayConditionedMetric>(
          parsed.value().metrics.front().metric);
      CHECK(metric.request.index() == expected_request_index);
      CHECK(metric.condition.index() == index);
    }
  }

  SECTION("joint-delay non-lagged sampling tags forbid a lag") {
    const std::array samplings{
        std::pair{"coincident", mwperf::JointDelaySampling::coincident},
        std::pair{"independent_palm",
                  mwperf::JointDelaySampling::independent_palm}};
    for (const auto& [wire, expected] : samplings) {
      auto parsed = parse_text(make_analysis(single_metric(
          "joint_delay", std::string{"{\"sampling\":\""} + wire +
                             "\",\"horizon\":0}")));
      INFO(wire);
      REQUIRE(parsed);
      const auto& metric = std::get<mwperf::JointDelayMetric>(
          parsed.value().metrics.front().metric);
      CHECK(metric.sampling == expected);
      CHECK_FALSE(metric.lag);
    }
  }
}

TEST_CASE("C03 provider payload is opaque but cannot choose transport",
          "[c03][unit][negative]") {
  const std::string metric =
      R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])";
  SECTION("mathematical provider data and resolution-like names are inert") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})",
        R"({"kind":"none","parameters":{}})", "null",
        R"({"context_bank_size":50,"optimizer":{"max_calls":999999},"sampling":{"max_generator_draws":999999}})"));
    REQUIRE(parsed);
    CHECK(parsed.value().context->resolution.optimizer.max_calls->to_decimal_string() ==
          "100");
    CHECK_FALSE(parsed.value().context->resolution.sampling.max_generator_draws);
  }
  SECTION("nested executable selector is rejected") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})",
        R"({"kind":"none","parameters":{}})", "null",
        R"({"builder":{"executable_path":"/tmp/tool"}})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.provider_transport_forbidden");
    CHECK(parsed.error().json_pointer ==
          "/surrogate/parameters/builder/executable_path");
  }
  SECTION("recursive diagnostics follow authored preorder") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})",
        R"({"kind":"none","parameters":{}})", "null",
        R"({"first":{"command":"bad"},"second":{"url":"also-bad"}})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.provider_transport_forbidden");
    CHECK(parsed.error().json_pointer ==
          "/surrogate/parameters/first/command");
  }
  SECTION("transient surrogate-initial data is opaque and inert") {
    std::string selection = transient_selection(R"({"kind":"trace_origin"})");
    const std::string marker =
        R"("surrogate_initial":{"phase_hint":0})";
    const std::string replacement =
        R"("surrogate_initial":{"optimizer":{"max_calls":999999},"sampling":{"max_generator_draws":999999}})";
    REQUIRE(selection.find(marker) != std::string::npos);
    selection.replace(selection.find(marker), marker.size(), replacement);
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"transient_backlog_law","parameters":{"horizons":[0]}}])",
        selection));
    REQUIRE(parsed);
    CHECK(parsed.value().context->resolution.optimizer.max_calls
              ->to_decimal_string() == "100");
    CHECK_FALSE(parsed.value().context->resolution.sampling.max_generator_draws);
  }
  SECTION("nested transient surrogate-initial transport is rejected") {
    std::string selection = transient_selection(R"({"kind":"trace_origin"})");
    const std::string marker =
        R"("surrogate_initial":{"phase_hint":0})";
    const std::string replacement =
        R"("surrogate_initial":{"bank":[{"environment":{"TOKEN":"inert"}}]})";
    REQUIRE(selection.find(marker) != std::string::npos);
    selection.replace(selection.find(marker), marker.size(), replacement);
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"transient_backlog_law","parameters":{"horizons":[0]}}])",
        selection));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.provider_transport_forbidden");
    CHECK(parsed.error().json_pointer ==
          "/selection/parameters/initial_law/atoms/0/surrogate_initial/bank/0/environment");
  }
  SECTION("the closed surrogate envelope rejects transport fields") {
    std::string analysis = make_analysis(metric);
    const std::string marker = R"("surrogate":{"id":"provider")";
    const std::string replacement =
        R"("surrogate":{"transport":"process","id":"provider")";
    REQUIRE(analysis.find(marker) != std::string::npos);
    analysis.replace(analysis.find(marker), marker.size(), replacement);
    auto parsed = parse_text(analysis);
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "unknown_object_key");
    CHECK(parsed.error().json_pointer == "/surrogate/transport");
  }
  SECTION("the closed top level rejects command fields") {
    std::string analysis = make_analysis(metric);
    analysis.replace(0U, 1U, R"({"command":"run",)");
    auto parsed = parse_text(analysis);
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "unknown_object_key");
    CHECK(parsed.error().json_pointer == "/command");
  }
  SECTION("surrogate version is nonempty but otherwise opaque") {
    auto parsed = parse_text(make_analysis(
        metric, R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"direct","parameters":{}})",
        R"({"kind":"none","parameters":{}})", "null", "{}", R"(" v1 ")"));
    REQUIRE(parsed);
    CHECK(parsed.value().surrogate.version == " v1 ");
  }
}

TEST_CASE("C03 analysis parser rejects local wire violations",
          "[c03][negative]") {
  SECTION("trimmed identifiers reject Unicode edge whitespace") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"\u00a0metric","kind":"stationary_throughput","parameters":{}}])"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.noncanonical_string");
  }
  SECTION("Monte Carlo has no implicit draw grant") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])",
        R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"monte_carlo","parameters":{"replications":10,"confidence_level":0.9,"interval_method":"none"}})"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code ==
          "analysis.monte_carlo_requires_draw_grant");
  }
  SECTION("metric ids are duplicate-free") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"same","kind":"stationary_throughput","parameters":{}},{"id":"same","kind":"mean_sojourn","parameters":{}}])"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.duplicate_metric_id");
    CHECK(parsed.error().json_pointer == "/metrics/1/id");
  }
  SECTION("transient backlog queue ids are duplicate-free") {
    std::string selection = transient_selection(R"({"kind":"trace_origin"})");
    const std::string marker = R"({"queue_id":"q1","value":2})";
    REQUIRE(selection.find(marker) != std::string::npos);
    selection.replace(selection.find(marker), marker.size(),
                      R"({"queue_id":"q0","value":2})");
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"transient_backlog_law","parameters":{"horizons":[0]}}])",
        selection));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.duplicate_backlog_queue");
    CHECK(parsed.error().json_pointer ==
          "/selection/parameters/initial_law/atoms/0/backlog/1/queue_id");
  }
  SECTION("positive natural fields reject zero") {
    auto metric_zero = parse_text(make_analysis(single_metric(
        "service_window_count", R"({"width":0})")));
    REQUIRE_FALSE(metric_zero);
    CHECK(metric_zero.error().code == "analysis.expected_positive_integer");

    std::string resolution_zero = make_analysis(single_metric(
        "stationary_throughput", "{}"));
    const std::string marker = R"("max_states":1000)";
    REQUIRE(resolution_zero.find(marker) != std::string::npos);
    resolution_zero.replace(resolution_zero.find(marker), marker.size(),
                            R"("max_states":0)");
    auto resolution = parse_text(resolution_zero);
    REQUIRE_FALSE(resolution);
    CHECK(resolution.error().code == "analysis.expected_positive_integer");
  }
  SECTION("open probabilities reject both endpoints") {
    for (const std::string_view probability : {"0", "1"}) {
      auto parsed = parse_text(make_analysis(single_metric(
          "stationary_backlog_quantile",
          std::string{"{\"probability\":"} + std::string(probability) + "}")));
      INFO(probability);
      REQUIRE_FALSE(parsed);
      CHECK(parsed.error().code == "analysis.probability_out_of_range");
    }
  }
  SECTION("closed initial-atom probability rejects values above one") {
    std::string selection = transient_selection(R"({"kind":"trace_origin"})");
    const std::string marker = R"("probability":1)";
    REQUIRE(selection.find(marker) != std::string::npos);
    selection.replace(selection.find(marker), marker.size(),
                      R"("probability":1.0001)");
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"transient_backlog_law","parameters":{"horizons":[0]}}])",
        selection));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "probability_out_of_range");
  }
  SECTION("unknown tagged alternatives are rejected without fallback") {
    auto metric = parse_text(make_analysis(single_metric("future_metric", "{}")));
    REQUIRE_FALSE(metric);
    CHECK(metric.error().code == "analysis.unknown_metric_kind");

    auto predicate = parse_text(make_analysis(single_metric(
        "mean_binary_run", R"({"predicate":"sometimes"})")));
    REQUIRE_FALSE(predicate);
    CHECK(predicate.error().code == "analysis.unknown_predicate");

    auto solver = parse_text(make_analysis(
        single_metric("stationary_throughput", "{}"),
        R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"future","parameters":{}})"));
    REQUIRE_FALSE(solver);
    CHECK(solver.error().code == "analysis.unknown_solver_kind");
  }
  SECTION("non-lagged joint delay forbids a stray lag") {
    auto parsed = parse_text(make_analysis(single_metric(
        "joint_delay",
        R"({"sampling":"coincident","lag":0,"horizon":0})")));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "unknown_object_key");
  }
  SECTION("set-like arrays are duplicate-free") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"service_autocovariance","parameters":{"lags":[1,1]}}])"));
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "analysis.duplicate_metric_query");
  }
  SECTION("positional thresholds may repeat") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"joint_backlog_event","parameters":{"relation":"any_at_or_above","thresholds":[3,3]}}])"));
    REQUIRE(parsed);
  }
  SECTION("positional thresholds match the target count") {
    auto short_row = parse_text(make_analysis(
        R"([{"id":"m","kind":"joint_backlog_event","parameters":{"relation":"any_at_or_above","thresholds":[3]}}])"));
    REQUIRE_FALSE(short_row);
    CHECK(short_row.error().code ==
          "analysis.joint_threshold_target_count");

    auto long_row = parse_text(make_analysis(
        R"([{"id":"m","kind":"joint_backlog_event","parameters":{"relation":"any_at_or_above","thresholds":[3,3,4]}}])"));
    REQUIRE_FALSE(long_row);
    CHECK(long_row.error().code ==
          "analysis.joint_threshold_target_count");
  }
  SECTION("direct parameters are exactly empty") {
    auto parsed = parse_text(make_analysis(
        R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])",
        R"({"kind":"stationary_unique","parameters":{}})",
        R"({"kind":"direct","parameters":{"max_iterations":1}})"));
    REQUIRE_FALSE(parsed);
  }
  SECTION("typed duplicate targets are rejected without conflating types") {
    auto duplicate = make_analysis(
        R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])");
    const std::string marker = R"("targets":["q0","q1"])";
    duplicate.replace(duplicate.find(marker), marker.size(),
                      R"("targets":[1,1])");
    REQUIRE_FALSE(parse_text(duplicate));

    auto distinct = make_analysis(
        R"([{"id":"m","kind":"stationary_throughput","parameters":{}}])");
    distinct.replace(distinct.find(marker), marker.size(),
                     R"("targets":[1,"1"])");
    REQUIRE(parse_text(distinct));
  }
}

TEST_CASE("C03 checked-in analysis schema tracks the frozen parser catalog",
          "[c03][unit]") {
  std::ifstream input(MWPERF_C03_ANALYSIS_SCHEMA_PATH, std::ios::binary);
  REQUIRE(input.is_open());
  const nlohmann::json schema = nlohmann::json::parse(input);

  const nlohmann::json fixture = nlohmann::json::parse(all_metric_items());
  std::set<std::string> expected_tags;
  for (const nlohmann::json& metric : fixture) {
    expected_tags.insert(metric.at("kind").get<std::string>());
  }
  REQUIRE(expected_tags.size() == 29U);

  const nlohmann::json& metric_schema = schema.at("$defs").at("metric");
  std::set<std::string> schema_tags;
  for (const nlohmann::json& tag :
       metric_schema.at("properties").at("kind").at("enum")) {
    schema_tags.insert(tag.get<std::string>());
  }
  CHECK(schema_tags == expected_tags);

  constexpr std::string_view metric_prefix = "#/$defs/metric_";
  std::set<std::string> alternative_tags;
  for (const nlohmann::json& alternative :
       metric_schema.at("allOf").at(0).at("oneOf")) {
    const std::string reference = alternative.at("$ref").get<std::string>();
    REQUIRE(reference.starts_with(metric_prefix));
    alternative_tags.insert(reference.substr(metric_prefix.size()));
  }
  CHECK(alternative_tags == expected_tags);

  const std::set<std::string> expected_top_level{
      "analysis_schema_version", "targets", "metrics", "surrogate",
      "resolution", "selection", "solver"};
  std::set<std::string> required_top_level;
  for (const nlohmann::json& key : schema.at("required")) {
    required_top_level.insert(key.get<std::string>());
  }
  CHECK(required_top_level == expected_top_level);

  const std::set<std::string> expected_interval_methods{
      "exact_binomial", "hoeffding", "none"};
  std::set<std::string> interval_methods;
  const nlohmann::json& solver_alternatives =
      schema.at("$defs").at("solver").at("oneOf");
  REQUIRE(solver_alternatives.size() == 4U);
  for (const nlohmann::json& alternative : solver_alternatives) {
    const nlohmann::json& properties = alternative.at("properties");
    if (properties.at("kind").at("const") == "monte_carlo") {
      for (const nlohmann::json& method : properties.at("parameters")
                                                .at("properties")
                                                .at("interval_method")
                                                .at("enum")) {
        interval_methods.insert(method.get<std::string>());
      }
    }
  }
  CHECK(interval_methods == expected_interval_methods);

  std::function<void(const nlohmann::json&)> check_references;
  check_references = [&](const nlohmann::json& value) {
    if (value.is_object()) {
      if (const auto found = value.find("$ref"); found != value.end()) {
        const std::string reference = found->get<std::string>();
        REQUIRE(reference.starts_with('#'));
        CHECK(schema.contains(
            nlohmann::json::json_pointer(reference.substr(1U))));
      }
      for (const auto& [key, child] : value.items()) {
        static_cast<void>(key);
        check_references(child);
      }
    } else if (value.is_array()) {
      for (const nlohmann::json& child : value) {
        check_references(child);
      }
    }
  };
  check_references(schema);
}
