#include <string>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/surrogate/plug_contract.hpp"

TEST_CASE("C17 V0 binds the supplied descriptor to its validated identity",
          "[c17][negative][v0]") {
  auto prepared =
      mwperf::testing::c17_temporal::prepare_generic_temporal_framework(
          [](mwperf::PlugDescriptor& descriptor) {
            REQUIRE(descriptor.c_plus.has_value());
            descriptor.c_plus->patch_codec = {
                "c17.fixture.foreign-postclosure-patch", 1U};
            auto descriptor_digest =
                mwperf::canonical_plug_descriptor_digest_v1(descriptor);
            REQUIRE(descriptor_digest);
            descriptor.descriptor_digest = descriptor_digest.value();

            auto c16_shape = mwperf::validate_plug_descriptor_v1(descriptor);
            INFO((c16_shape ? std::string{}
                            : c16_shape.error().code + ": " +
                                  c16_shape.error().message));
            REQUIRE(c16_shape);
          });

  auto rejected = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c17.descriptor_binding_mismatch");
}
