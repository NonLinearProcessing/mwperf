#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "support/c16_end_to_end_fixture.hpp"

namespace {

using Json = nlohmann::json;

struct Arguments final {
  std::filesystem::path request;
  std::filesystem::path result;
};

[[nodiscard]] bool parse_arguments(const int count, char** values,
                                   Arguments& result) {
  if (count != 5) return false;
  if (std::string_view(values[1]) != "--request" ||
      std::string_view(values[3]) != "--result") {
    return false;
  }
  result.request = values[2];
  result.result = values[4];
  return true;
}

[[nodiscard]] std::optional<Json> read_request(
    const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  if (!input.is_open()) return std::nullopt;
  const std::string bytes((std::istreambuf_iterator<char>(input)),
                          std::istreambuf_iterator<char>());
  if (!(input.good() || input.eof())) return std::nullopt;
  auto parsed = Json::parse(bytes, nullptr, false);
  if (parsed.is_discarded() || !parsed.is_object()) return std::nullopt;
  return parsed;
}

[[nodiscard]] bool write_result(const std::filesystem::path& path,
                                const std::vector<std::byte>& bytes) {
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  if (!output.is_open()) return false;
  output.write(reinterpret_cast<const char*>(bytes.data()),
               static_cast<std::streamsize>(bytes.size()));
  return output.good();
}

[[nodiscard]] std::optional<mwperf::Digest256> json_digest(
    const Json& value) {
  if (!value.is_string()) return std::nullopt;
  auto parsed = mwperf::Digest256::from_hex(value.get_ref<const std::string&>());
  if (!parsed) return std::nullopt;
  return std::move(parsed).value();
}

[[nodiscard]] bool has_zero_count_grant(const Json& value) {
  return value.is_object() && value.size() == 2U &&
         value.value("applicability", "") == "applicable" &&
         value.value("amount", "") == "0";
}

[[nodiscard]] bool has_not_applicable_tolerance(const Json& value) {
  return value.is_object() && value.size() == 2U &&
         value.value("applicability", "") == "not_applicable" &&
         value.contains("amount") && value.at("amount").is_null();
}

[[nodiscard]] mwperf::ConstructionBudget zero_budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

[[nodiscard]] bool matches_zero_budget(const Json& value) {
  if (!value.is_object() || value.value("schema_version", 0U) != 1U) {
    return false;
  }
  return has_zero_count_grant(value.value("exact_optimizer_calls", Json{})) &&
         has_zero_count_grant(
             value.value("optimizer_search_states", Json{})) &&
         has_zero_count_grant(
             value.value("configured_generator_draws", Json{})) &&
         has_not_applicable_tolerance(
             value.value("linear_residual_abs", Json{})) &&
         has_not_applicable_tolerance(
             value.value("integration_abs", Json{})) &&
         has_not_applicable_tolerance(value.value("tail_abs", Json{})) &&
         has_not_applicable_tolerance(
             value.value("fixed_point_abs", Json{}));
}

[[nodiscard]] std::optional<mwperf::testing::c16_flow_fixture::FlowBuildInputsV1>
decode_inputs(const Json& request,
              const mwperf::ValidatedProviderManifest& manifest) {
  using namespace mwperf;
  using namespace mwperf::testing::c16_flow_fixture;
  if (request.value("protocol_version", 0U) != 1U ||
      request.value("required_build_report_schema", 0U) != 1U ||
      !request.contains("provider_binding") ||
      !request.contains("classifications") ||
      !request.contains("framework_problem_view") ||
      !request.contains("accepted_capability_contract") ||
      !request.contains("construction_budget")) {
    return std::nullopt;
  }
  const Json& binding = request.at("provider_binding");
  const Json& classifications = request.at("classifications");
  const Json& problem = request.at("framework_problem_view");
  const Json& contract = request.at("accepted_capability_contract");
  const auto request_digest = json_digest(request.at("request_digest"));
  const auto scientific =
      json_digest(binding.at("provider_scientific_contract_digest"));
  const auto compiled_arrival =
      json_digest(problem.at("compiled_arrival_fingerprint"));
  const auto target_selection =
      json_digest(problem.at("target_selection_fingerprint"));
  const auto tie_and_timing =
      json_digest(problem.at("tie_timing_fingerprint"));
  if (!request_digest.has_value() || !scientific.has_value() ||
      !compiled_arrival.has_value() || !target_selection.has_value() ||
      !tie_and_timing.has_value()) {
    return std::nullopt;
  }
  const auto& raw = manifest.value();
  if (binding.value("provider_id", "") != raw.provider.provider_id ||
      binding.value("provider_version", "") !=
          raw.provider.provider_version ||
      binding.value("parameter_schema_version", 0U) !=
          raw.parameter_schema_version ||
      *scientific != manifest.scientific_contract_digest().value() ||
      classifications.value("construction_method", "") !=
          "engineered_deterministic" ||
      classifications.value("producer_mode", "") !=
          "local_executable_builder" ||
      classifications.value("proposed_semantic_tag", "") !=
          "scalar_backlog_response" ||
      classifications.value("proposed_access_tag", "") !=
          "finite_parameter_analytic_family" ||
      classifications.value("proposed_payload_tag", "") !=
          "three_bin_scalar_response_v1" ||
      !matches_zero_budget(request.at("construction_budget"))) {
    return std::nullopt;
  }
  const Json& targets = problem.at("target_selection").at("ordered_targets");
  if (!targets.is_array() || targets.size() != 1U ||
      targets.front().value("kind", "") != "text" ||
      targets.front().value("value", "") != "q0") {
    return std::nullopt;
  }
  const Json& support = contract.at("structural_metric_support_manifest");
  const auto support_digest = json_digest(support.at("manifest_digest"));
  if (!support_digest.has_value() ||
      *support_digest != raw.metric_clause_upper_envelope.canonical_digest()) {
    return std::nullopt;
  }
  return FlowBuildInputsV1{
      *request_digest,
      raw.provider,
      *scientific,
      raw.construction_method,
      raw.producer_mode,
      raw.deployed_semantic_tag,
      raw.runtime_access_tag,
      raw.payload_class,
      queue("q0"),
      *compiled_arrival,
      raw.metric_clause_upper_envelope,
      zero_budget(),
      *target_selection,
      *tie_and_timing};
}

}  // namespace

int main(const int argc, char** argv) {
  using namespace mwperf;
  using namespace mwperf::testing::c16_flow_fixture;
  Arguments arguments;
  if (!parse_arguments(argc, argv, arguments)) return 64;
  const auto request = read_request(arguments.request);
  if (!request.has_value()) return 65;
  auto raw_manifest = provider_manifest(
      "c16.fixture.flow.local",
      ConstructionMethodV1::engineered_deterministic,
      ProducerModeV1::local_executable_builder,
      LocalExecutableDeclarationV1{
          "c16.fixture.flow.local-executable", 1U,
          {"--request", "{request_path}", "--result", "{result_path}"},
          true});
  if (!raw_manifest) return 66;
  auto manifest = validate_provider_manifest(raw_manifest.value());
  if (!manifest) return 67;
  auto inputs = decode_inputs(*request, manifest.value());
  if (!inputs.has_value()) return 68;
  auto result = built_result(*inputs, raw_manifest.value());
  if (!result) return 69;
  auto bytes = artifact::detail::canonical_surrogate_build_result_bytes_v1(
      result.value());
  if (!bytes) return 70;
  return write_result(arguments.result, bytes.value()) ? 0 : 74;
}
