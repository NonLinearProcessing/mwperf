#include <algorithm>
#include <array>
#include <atomic>
#include <concepts>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <span>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/surrogate/provider.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_test_providers.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace {

[[nodiscard]] mwperf::TypedLabel label(const std::string_view text) {
  auto value = mwperf::TypedLabel::text(std::string(text));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::QueueId queue(const std::string_view text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::Digest256 digest(const std::string_view text) {
  auto value = mwperf::sha256(
      std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-provider-contract-matrix";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct PreviewInput final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
};

[[nodiscard]] PreviewInput preview_input() {
  static constexpr std::string_view model_text = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
      "params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],
                "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis_text = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.preview.purity","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);
  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto metric = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(metric);
  auto requirements = mwperf::aggregate_metric_requirements(
      std::vector<mwperf::MetricRequest>{metric.value()});
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements)};
}

[[nodiscard]] mwperf::SourceNode parameter_object() {
  const mwperf::SourceLocation location{
      "c16-preview-purity-parameters.json", 1U, 1U, 0U};
  return mwperf::SourceNode::make_object(
      {{"resolution_level", location,
        mwperf::SourceNode::make_number("1", location,
                                        "/resolution_level")}},
      location, "");
}

[[nodiscard]] mwperf::ConstructionBudget budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

template <typename T>
concept HasRequestDigest = requires(const T& value) {
  value.request_digest;
};

template <typename T>
concept HasBuildSeed = requires(const T& value) {
  value.build_seed;
};

template <typename T>
concept HasArtifactId = requires(const T& value) {
  value.artifact_id;
};

template <typename T>
concept HasPayloadIdentity = requires(const T& value) {
  value.payload_identity;
};

template <typename T>
concept HasProductIdentity = requires(const T& value) {
  value.product_id;
};

template <typename T>
concept HasEvidenceIdentity = requires(const T& value) {
  value.evidence_id;
};

[[nodiscard]] mwperf::SurrogateProviderRegistrationV1 registration(
    mwperf::SurrogateProviderManifestV1 manifest,
    const std::shared_ptr<std::atomic<unsigned>>& parameter_calls) {
  auto value = mwperf::testing::c16_test_registration(std::move(manifest));
  value.parameter_validator =
      [parameter_calls](const mwperf::SourceNode&)
      -> mwperf::Result<mwperf::ValidatedParameterPayloadV1> {
    parameter_calls->fetch_add(1U, std::memory_order_relaxed);
    return mwperf::Result<mwperf::ValidatedParameterPayloadV1>::failure(
        mwperf::testing::c16_fixture_detail::fixture_error(
            "c16.fixture.forbidden_parameter_callback",
            "manifest rejection must precede parameter validation"));
  };
  return value;
}

void reseal(mwperf::SurrogateProviderManifestV1& manifest) {
  auto digest = mwperf::digest_provider_manifest_v1(manifest);
  INFO((digest ? std::string{}
               : digest.error().code + ": " + digest.error().message));
  REQUIRE(digest);
  manifest.manifest_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::SurrogateProviderManifestV1 baseline_manifest(
    const std::string_view suffix) {
  return mwperf::testing::c16_test_manifest(
      "c16.fixture.invalid-manifest." + std::string(suffix),
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder);
}

}  // namespace

TEST_CASE("C16 preview schema cannot carry identities from the future",
          "[c16][unit][preview-purity][provider-contract-matrix]") {
  using ExactPreviewOperation =
      std::function<mwperf::Result<mwperf::PlugDescriptorPreview>(
          const mwperf::FrameworkProblemView&,
          const mwperf::MetricRequirements&,
          const mwperf::ConstructionBudget&,
          const mwperf::ValidatedSurrogateParameters&)>;
  STATIC_REQUIRE(std::same_as<mwperf::DescriptorPreviewerV1,
                              ExactPreviewOperation>);
  STATIC_REQUIRE(!std::is_invocable_v<
                 mwperf::DescriptorPreviewerV1,
                 const mwperf::FrameworkProblemView&,
                 const mwperf::MetricRequirements&,
                 const mwperf::ConstructionBudget&,
                 const mwperf::ValidatedSurrogateParameters&,
                 mwperf::BuildExecutionContext&>);
  STATIC_REQUIRE(!std::is_invocable_v<
                 mwperf::DescriptorPreviewerV1,
                 const mwperf::FrameworkProblemView&,
                 const mwperf::MetricRequirements&,
                 const mwperf::ConstructionBudget&,
                 const mwperf::ValidatedSurrogateParameters&,
                 const mwperf::ValidatedSurrogateArtifact&>);
  STATIC_REQUIRE(!HasRequestDigest<mwperf::PlugDescriptorPreview>);
  STATIC_REQUIRE(!HasBuildSeed<mwperf::PlugDescriptorPreview>);
  STATIC_REQUIRE(!HasArtifactId<mwperf::PlugDescriptorPreview>);
  STATIC_REQUIRE(!HasPayloadIdentity<mwperf::PlugDescriptorPreview>);
  STATIC_REQUIRE(!HasProductIdentity<mwperf::PlugDescriptorPreview>);
  STATIC_REQUIRE(!HasEvidenceIdentity<mwperf::PlugDescriptorPreview>);

  // A preview owns only symbolic MetricSupportRoleV1 requirements.  Realized
  // request, payload, product, and evidence identities first appear in C15's
  // post-build BoundRealizedMetricBindingsV1, which is not a preview member.
  STATIC_REQUIRE(
      !std::is_convertible_v<mwperf::BoundRealizedMetricBindingsV1,
                             mwperf::PlugDescriptorPreview>);
}

TEST_CASE("C16 preview is cold against every prohibited effect class",
          "[c16][integration][preview-purity][provider-contract-matrix]") {
  using mwperf::testing::c16_fixture_detail::preview_purity_counters;
  using mwperf::testing::c16_fixture_detail::reset_preview_purity_counters;
  using mwperf::testing::c16_fixture_detail::reset_side_effect_counters;

  reset_side_effect_counters();
  reset_preview_purity_counters();
  auto input = preview_input();
  auto id = mwperf::SurrogateId::parse("c16.fixture.preview.purity");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.preview.purity.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), parameter_object());
  REQUIRE(parameters);
  const auto selected_budget = budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, selected_budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);

  // These counters are wired to this provider's dormant producer and
  // materializer seams.  Their zero values establish that F07 invoked neither
  // seam; the companion signature assertions establish that F07 cannot be
  // handed a BuildExecutionContext or artifact through which to reach the
  // underlying process/optimizer/row/sample/decoder operations.
  const auto& counters = preview_purity_counters();
  CHECK(counters.artifact_reads.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.process_launches.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.optimizer_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.row_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.sample_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.decoder_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
            std::memory_order_relaxed) == 1U);

  // Give every future identity class a distinctive value and prove none can
  // alias any digest that exists at preview time.  The compile-time checks in
  // the companion case prove there is no hidden field in which to place it.
  const std::array future_identities{
      digest("c16.future.request"), digest("c16.future.artifact"),
      digest("c16.future.product"), digest("c16.future.evidence")};
  const std::array preview_identities{
      preview.value().core.core_digest,
      preview.value().core.metric_support_manifest_digest,
      preview.value().problem_view_digest, preview.value().parameter_digest,
      preview.value().budget_digest, preview.value().preview_digest};
  for (const auto& future : future_identities) {
    CHECK(std::find(preview_identities.begin(), preview_identities.end(),
                    future) == preview_identities.end());
  }

  // C14 consumes one immutable preview value.  Even a deterministic C14
  // rejection has no callback by which it could ask this or another provider
  // for a fallback pair.
  auto rejected_preview = preview.value();
  rejected_preview.preview_digest = digest("c16.rejected.preview");
  const auto decision = mwperf::negotiate_capabilities(
      input.requirements, rejected_preview,
      view.value().configured_arrival().capabilities());
  CHECK_FALSE(mwperf::capability_decision_is_accepted(decision));
  CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
            std::memory_order_relaxed) == 1U);
  CHECK(counters.artifact_reads.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.process_launches.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.optimizer_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.row_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.sample_calls.load(std::memory_order_relaxed) == 0U);
  CHECK(counters.decoder_calls.load(std::memory_order_relaxed) == 0U);
}

TEST_CASE("C16 registry rejects every named malformed manifest class cold",
          "[c16][negative][registry][provider-contract-matrix]") {
  auto parameter_calls = std::make_shared<std::atomic<unsigned>>(0U);

  const auto reject = [&](mwperf::SurrogateProviderManifestV1 manifest,
                          const std::string_view expected_code,
                          const bool manifest_is_canonicalizable = true) {
    if (manifest_is_canonicalizable) reseal(manifest);
    auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
        {registration(std::move(manifest), parameter_calls)});
    REQUIRE_FALSE(registry);
    CHECK(registry.error().code == expected_code);
    CHECK(parameter_calls->load(std::memory_order_relaxed) == 0U);
  };

  SECTION("unknown construction method enum") {
    auto manifest = baseline_manifest("construction-method");
    manifest.construction_method =
        static_cast<mwperf::ConstructionMethodV1>(0xffU);
    reject(std::move(manifest), "c15.unknown_manifest_enum", false);
  }

  SECTION("unknown producer mode enum") {
    auto manifest = baseline_manifest("producer-mode");
    manifest.producer_mode = static_cast<mwperf::ProducerModeV1>(0xffU);
    reject(std::move(manifest), "c15.unknown_manifest_enum", false);
  }

  SECTION("unknown scheduler family key") {
    auto manifest = baseline_manifest("scheduler-key");
    manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs
        .front()
        .service_family = static_cast<mwperf::ServiceFamily>(0xffU);
    reject(std::move(manifest), "c15.unknown_manifest_enum", false);
  }

  SECTION("unknown optimizer key") {
    auto manifest = baseline_manifest("optimizer-key");
    manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs
        .front()
        .optimizer = static_cast<mwperf::OptimizerId>(0xffU);
    reject(std::move(manifest), "c15.unknown_manifest_enum", false);
  }

  SECTION("unsupported build request version") {
    auto manifest = baseline_manifest("request-version");
    manifest.supported_build_request_versions = {2U};
    reject(std::move(manifest), "c15.unsupported_protocol_versions");
  }

  SECTION("unsupported artifact version") {
    auto manifest = baseline_manifest("artifact-version");
    manifest.supported_artifact_versions = {2U};
    reject(std::move(manifest), "c15.unsupported_protocol_versions");
  }

  SECTION("unsupported build report version") {
    auto manifest = baseline_manifest("report-version");
    manifest.required_build_report_schema_versions = {2U};
    reject(std::move(manifest), "c15.unsupported_protocol_versions");
  }

  SECTION("metric clause changes the singular registered pair") {
    auto manifest = baseline_manifest("metric-clause");
    auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
        manifest.metric_clause_upper_envelope.clauses().begin(),
        manifest.metric_clause_upper_envelope.clauses().end());
    clauses.front().runtime_access =
        mwperf::RuntimeAccessTagV1::analytic_transform;
    auto altered =
        mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
    REQUIRE(altered);
    manifest.metric_clause_upper_envelope = std::move(altered).value();
    reject(std::move(manifest), "c15.upper_envelope_tuple_mismatch");
  }

  SECTION("scheduler and optimizer form no released applicability key") {
    auto manifest = baseline_manifest("applicability-key");
    manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs = {
        {mwperf::ServiceFamily::crossbar_matching,
         mwperf::OptimizerId::mwis_branch_memo_exact}};
    reject(std::move(manifest), "c15.invalid_applicability");
  }

  SECTION("applicability keys are duplicated") {
    auto manifest = baseline_manifest("duplicate-applicability");
    const auto pair = manifest.optimizer_constraint_applicability
                          .scheduler_optimizer_pairs.front();
    manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs = {
        pair, pair};
    reject(std::move(manifest), "c15.noncanonical_applicability");
  }

  SECTION("applicability set is empty") {
    auto manifest = baseline_manifest("empty-applicability");
    manifest.optimizer_constraint_applicability.scheduler_optimizer_pairs
        .clear();
    reject(std::move(manifest), "c15.invalid_applicability");
  }

  SECTION("two versions claim the same omitted-version default") {
    auto first = baseline_manifest("duplicate-default");
    auto second = first;
    second.provider.provider_version = "2.0.0";
    reseal(second);
    auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
        {registration(std::move(first), parameter_calls),
         registration(std::move(second), parameter_calls)});
    REQUIRE_FALSE(registry);
    CHECK(registry.error().code ==
          "c16.multiple_default_provider_versions");
    CHECK(parameter_calls->load(std::memory_order_relaxed) == 0U);
  }
}

TEST_CASE("C16 singular provider pair forbids post-rejection alternatives",
          "[c16][negative][provider-contract-matrix][atomicity]") {
  auto parameter_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto manifest = baseline_manifest("attempted-multi-pair");
  auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
      manifest.metric_clause_upper_envelope.clauses().begin(),
      manifest.metric_clause_upper_envelope.clauses().end());
  auto alternate = clauses.front();
  alternate.clause_id.authored_index = 1U;
  alternate.semantic = mwperf::SemanticTagV1::response_envelope_law;
  alternate.runtime_access = mwperf::RuntimeAccessTagV1::analytic_transform;
  alternate.payload_class = {
      mwperf::PayloadClassTagV1::response_envelope_evidence_v1, 1U};
  clauses.push_back(std::move(alternate));
  auto advertised =
      mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
  REQUIRE_FALSE(advertised);
  CHECK(advertised.error().code == "metric_manifest_primary_role_missing");
  CHECK(parameter_calls->load(std::memory_order_relaxed) == 0U);
}
