#include <cmath>
#include <cstddef>
#include <numeric>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(mwperf::BigInt numerator,
                                              mwperf::BigInt denominator) {
  auto result = mwperf::ExactRational::make(std::move(numerator),
                                            std::move(denominator));
  if (!result.has_value()) {
    throw std::logic_error("invalid exact rational in probability test");
  }
  return std::move(result).value();
}

[[nodiscard]] mwperf::AuthoredProbability probability(
    mwperf::BigInt numerator, mwperf::BigInt denominator) {
  auto result = mwperf::AuthoredProbability::from_exact(
      rational(std::move(numerator), std::move(denominator)));
  if (!result.has_value()) {
    throw std::logic_error("invalid authored probability in test");
  }
  return std::move(result).value();
}

[[nodiscard]] bool exact_is(const mwperf::ExactRational& value,
                            const mwperf::BigInt& numerator,
                            const mwperf::BigInt& denominator) {
  return value.numerator() == numerator && value.denominator() == denominator;
}

[[nodiscard]] mwperf::BigInt power_of_ten(const std::size_t exponent) {
  mwperf::BigInt result = 1;
  for (std::size_t index = 0; index < exponent; ++index) {
    result *= 10;
  }
  return result;
}

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::AuthoredProbability>);
static_assert(!std::is_default_constructible_v<mwperf::NormalizedPmf>);
static_assert(std::is_move_constructible_v<mwperf::NormalizedPmf>);
static_assert(std::is_move_assignable_v<mwperf::NormalizedPmf>);

TEST_CASE("authored probabilities retain exact and numerical forms",
          "[c02][unit][probability]") {
  const auto one_tenth = probability(1, 10);
  CHECK(exact_is(one_tenth.exact_value(), 1, 10));
  CHECK(one_tenth.numerical_image() > 0.0L);
  CHECK(one_tenth.numerical_image() < 1.0L);

  auto negative = mwperf::AuthoredProbability::from_exact(rational(-1, 10));
  REQUIRE_FALSE(negative.has_value());
  CHECK(negative.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(negative.error().code == "probability_out_of_range");

  auto above_one = mwperf::AuthoredProbability::from_exact(rational(11, 10));
  REQUIRE_FALSE(above_one.has_value());
  CHECK(above_one.error().code == "probability_out_of_range");
}

TEST_CASE("physical PMF tolerance is the exact authored decimal 1e-9",
          "[c02][unit][probability]") {
  CHECK(exact_is(mwperf::physical_pmf_tolerance(), 1, 1000000000));

  const std::vector<mwperf::AuthoredProbability> row{probability(1, 1)};
  const auto unit = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(unit.has_value());
  CHECK(unit.value().sampling_bit_width() == 0);
  CHECK(unit.value().sampling_limb_count() == 0);

  const auto wrong_tolerance = rational(1, 1000000001);
  const auto result =
      mwperf::validate_and_normalize_pmf(row, wrong_tolerance);
  REQUIRE_FALSE(result.has_value());
  CHECK(result.error().code == "pmf_invalid_tolerance");
}

TEST_CASE("PMF normalization yields a primitive exact mass vector",
          "[c02][unit][probability]") {
  const std::vector<mwperf::AuthoredProbability> row{
      probability(0, 1), probability(2, 6), probability(0, 1),
      probability(4, 6), probability(0, 1)};

  const auto result = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(result.has_value());
  const auto& pmf = result.value();

  REQUIRE(pmf.size() == 5);
  CHECK(exact_is(pmf.authored_sum(), 1, 1));
  CHECK(exact_is(pmf.normalization_delta(), 0, 1));
  REQUIRE(pmf.normalized_weights().size() == 5);
  CHECK(exact_is(pmf.normalized_weights()[0], 0, 1));
  CHECK(exact_is(pmf.normalized_weights()[1], 1, 3));
  CHECK(exact_is(pmf.normalized_weights()[2], 0, 1));
  CHECK(exact_is(pmf.normalized_weights()[3], 2, 3));
  CHECK(exact_is(pmf.normalized_weights()[4], 0, 1));

  REQUIRE(pmf.integral_masses().size() == 5);
  CHECK(pmf.integral_masses()[0].value() == 0);
  CHECK(pmf.integral_masses()[1].value() == 1);
  CHECK(pmf.integral_masses()[2].value() == 0);
  CHECK(pmf.integral_masses()[3].value() == 2);
  CHECK(pmf.integral_masses()[4].value() == 0);
  CHECK(pmf.integral_denominator().value() == 3);
  CHECK(pmf.sampling_bit_width() == 2);
  CHECK(pmf.sampling_limb_count() == 1);

  REQUIRE(pmf.cumulative_masses().size() == 5);
  CHECK(pmf.cumulative_masses()[0].value() == 0);
  CHECK(pmf.cumulative_masses()[1].value() == 1);
  CHECK(pmf.cumulative_masses()[2].value() == 1);
  CHECK(pmf.cumulative_masses()[3].value() == 3);
  CHECK(pmf.cumulative_masses()[4].value() == 3);
}

TEST_CASE("PMF tolerance boundaries are decided with exact rationals",
          "[c02][unit][negative][probability]") {
  const std::vector<mwperf::AuthoredProbability> plus_boundary{
      probability(1, 1), probability(1, 1000000000)};
  const auto plus_result = mwperf::validate_and_normalize_pmf(
      plus_boundary, mwperf::physical_pmf_tolerance());
  REQUIRE(plus_result.has_value());
  CHECK(exact_is(plus_result.value().authored_sum(), 1000000001,
                 1000000000));
  CHECK(exact_is(plus_result.value().normalization_delta(), 1,
                 1000000000));

  const std::vector<mwperf::AuthoredProbability> minus_boundary{
      probability(999999999, 1000000000)};
  const auto minus_result = mwperf::validate_and_normalize_pmf(
      minus_boundary, mwperf::physical_pmf_tolerance());
  REQUIRE(minus_result.has_value());
  CHECK(exact_is(minus_result.value().normalization_delta(), -1,
                 1000000000));

  const std::vector<mwperf::AuthoredProbability> plus_outside{
      probability(1, 1), probability(1, 999999999)};
  const auto outside_result = mwperf::validate_and_normalize_pmf(
      plus_outside, mwperf::physical_pmf_tolerance());
  REQUIRE_FALSE(outside_result.has_value());
  CHECK(outside_result.error().code == "pmf_mass_outside_tolerance");
  REQUIRE(outside_result.error().notes.size() == 3);
  CHECK(outside_result.error().notes[2].starts_with(
      "compensated long-double residual "));
}

TEST_CASE("normalization is exact when authored mass is near one",
          "[c02][unit][probability]") {
  const std::vector<mwperf::AuthoredProbability> row{
      probability(1, 2), probability(5000000001, 10000000000)};
  const auto result = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(result.has_value());
  const auto& pmf = result.value();

  CHECK(exact_is(pmf.authored_sum(), 10000000001, 10000000000));
  CHECK(exact_is(pmf.normalization_delta(), 1, 10000000000));
  CHECK(exact_is(pmf.normalized_weights()[0], 5000000000,
                 10000000001));
  CHECK(exact_is(pmf.normalized_weights()[1], 5000000001,
                 10000000001));
  CHECK(pmf.integral_masses()[0].value() == 5000000000ULL);
  CHECK(pmf.integral_masses()[1].value() == 5000000001ULL);
  CHECK(pmf.integral_denominator().value() == 10000000001ULL);

  const auto& diagnostics = pmf.numerical_diagnostics();
  CHECK(std::isfinite(diagnostics.authored_mass));
  CHECK(std::isfinite(diagnostics.authored_residual));
  CHECK(std::isfinite(diagnostics.normalized_mass));
  CHECK(std::isfinite(diagnostics.normalized_residual));
  CHECK(diagnostics.authored_residual == diagnostics.authored_mass - 1.0L);
  CHECK(diagnostics.normalized_residual ==
        diagnostics.normalized_mass - 1.0L);
}

TEST_CASE("revalidation preserves every exact and numerical PMF field",
          "[c02][unit][property][probability]") {
  const std::vector<mwperf::AuthoredProbability> row{
      probability(1, 7), probability(2, 7), probability(4, 7)};
  const auto first = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(first.has_value());

  const auto second = mwperf::revalidate_normalized_pmf(
      first.value(), mwperf::physical_pmf_tolerance());
  REQUIRE(second.has_value());
  CHECK(second.value() == first.value());
  CHECK(second.value().integral_masses() ==
        first.value().integral_masses());
  CHECK(second.value().cumulative_masses() ==
        first.value().cumulative_masses());
  CHECK(second.value().numerical_image() ==
        first.value().numerical_image());
}

TEST_CASE("PMF representation budgets are enforced but are not law identity",
          "[c02][unit][negative][probability]") {
  const std::vector<mwperf::AuthoredProbability> row{
      probability(1, 3), probability(2, 3)};

  const auto unbounded = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(unbounded.has_value());
  CHECK_FALSE(unbounded.value()
                  .representation_budget()
                  .maximum_integral_bits.has_value());

  const mwperf::PmfRepresentationBudget exact_budget{
      .maximum_integral_bits = 2};
  const auto bounded = mwperf::validate_and_normalize_pmf_with_budget(
      row, mwperf::physical_pmf_tolerance(), exact_budget);
  REQUIRE(bounded.has_value());
  REQUIRE(bounded.value()
              .representation_budget()
              .maximum_integral_bits.has_value());
  CHECK(*bounded.value()
             .representation_budget()
             .maximum_integral_bits == 2);
  CHECK(bounded.value().integral_denominator().bit_length() == 2);
  // The construction envelope is audit metadata, not mathematical identity.
  CHECK(bounded.value() == unbounded.value());
  const auto bounded_revalidated = mwperf::revalidate_normalized_pmf(
      bounded.value(), mwperf::physical_pmf_tolerance());
  REQUIRE(bounded_revalidated.has_value());
  REQUIRE(bounded_revalidated.value()
              .representation_budget()
              .maximum_integral_bits.has_value());
  CHECK(*bounded_revalidated.value()
             .representation_budget()
             .maximum_integral_bits == 2);

  const mwperf::PmfRepresentationBudget insufficient_budget{
      .maximum_integral_bits = 1};
  const auto rejected = mwperf::validate_and_normalize_pmf_with_budget(
      row, mwperf::physical_pmf_tolerance(), insufficient_budget);
  REQUIRE_FALSE(rejected.has_value());
  CHECK(rejected.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(rejected.error().code == "pmf_integral_bit_budget_exceeded");
  REQUIRE(rejected.error().notes.size() == 2);
  CHECK(rejected.error().notes[0] == "maximum_integral_bits 1");

  const mwperf::PmfRepresentationBudget zero_budget{
      .maximum_integral_bits = 0};
  const std::vector<mwperf::AuthoredProbability> unit_row{
      probability(1, 1)};
  const auto zero_rejected = mwperf::validate_and_normalize_pmf_with_budget(
      unit_row, mwperf::physical_pmf_tolerance(), zero_budget);
  REQUIRE_FALSE(zero_rejected.has_value());
  CHECK(zero_rejected.error().code ==
        "pmf_integral_bit_budget_exceeded");
}

TEST_CASE("moving PMF values preserves both source and destination invariants",
          "[c02][unit][property][probability]") {
  const std::vector<mwperf::AuthoredProbability> row{
      probability(1, 5), probability(4, 5)};
  auto source_result = mwperf::validate_and_normalize_pmf_with_budget(
      row, mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget{.maximum_integral_bits = 3});
  REQUIRE(source_result.has_value());
  mwperf::NormalizedPmf source = source_result.value();
  const mwperf::NormalizedPmf expected = source;

  mwperf::NormalizedPmf moved(std::move(source));
  CHECK(moved == expected);
  CHECK(source == expected);
  REQUIRE(mwperf::revalidate_normalized_pmf(
              moved, mwperf::physical_pmf_tolerance())
              .has_value());
  REQUIRE(mwperf::revalidate_normalized_pmf(
              source, mwperf::physical_pmf_tolerance())
              .has_value());

  const std::vector<mwperf::AuthoredProbability> other_row{
      probability(1, 2), probability(1, 2)};
  auto destination_result = mwperf::validate_and_normalize_pmf(
      other_row, mwperf::physical_pmf_tolerance());
  REQUIRE(destination_result.has_value());
  mwperf::NormalizedPmf destination = destination_result.value();
  destination = std::move(moved);
  CHECK(destination == expected);
  CHECK(moved == expected);
  REQUIRE(mwperf::revalidate_normalized_pmf(
              destination, mwperf::physical_pmf_tolerance())
              .has_value());
  REQUIRE(mwperf::revalidate_normalized_pmf(
              moved, mwperf::physical_pmf_tolerance())
              .has_value());

  auto authored = probability(1, 7);
  mwperf::AuthoredProbability moved_authored(std::move(authored));
  CHECK(exact_is(moved_authored.exact_value(), 1, 7));
  CHECK(authored.exact_value() == mwperf::ExactRational::zero());
  CHECK(authored.numerical_image() == 0.0L);

  auto assigned_source = probability(3, 11);
  auto assigned_destination = probability(2, 9);
  assigned_destination = std::move(assigned_source);
  CHECK(exact_is(assigned_destination.exact_value(), 3, 11));
  CHECK(assigned_destination.numerical_image() > 0.0L);
  CHECK(assigned_source.exact_value() == mwperf::ExactRational::zero());
  CHECK(assigned_source.numerical_image() == 0.0L);
}

TEST_CASE("small integral rows always reduce to primitive exact masses",
          "[c02][unit][property][probability]") {
  for (unsigned int first = 0; first <= 4; ++first) {
    for (unsigned int second = 0; second <= 4; ++second) {
      for (unsigned int third = 0; third <= 4; ++third) {
        const unsigned int total = first + second + third;
        if (total == 0) {
          continue;
        }
        const std::vector<mwperf::AuthoredProbability> row{
            probability(first, total), probability(second, total),
            probability(third, total)};
        const auto result = mwperf::validate_and_normalize_pmf(
            row, mwperf::physical_pmf_tolerance());
        REQUIRE(result.has_value());

        const unsigned int divisor =
            std::gcd(first, std::gcd(second, third));
        const auto& pmf = result.value();
        REQUIRE(pmf.integral_masses().size() == 3);
        CHECK(pmf.integral_masses()[0].value() == first / divisor);
        CHECK(pmf.integral_masses()[1].value() == second / divisor);
        CHECK(pmf.integral_masses()[2].value() == third / divisor);
        CHECK(pmf.integral_denominator().value() == total / divisor);
        CHECK(pmf.cumulative_masses().back().value() ==
              pmf.integral_denominator().value());

        mwperf::ExactRational exact_total = mwperf::ExactRational::zero();
        for (const mwperf::ExactRational& weight :
             pmf.normalized_weights()) {
          exact_total = exact_total + weight;
        }
        CHECK(exact_total == mwperf::ExactRational::one());
      }
    }
  }
}

TEST_CASE("exact positive mass survives long-double underflow",
          "[c02][unit][probability]") {
  const mwperf::BigInt denominator = power_of_ten(10000);
  const std::vector<mwperf::AuthoredProbability> row{
      probability(1, denominator),
      probability(denominator - 1, denominator)};

  const auto result = mwperf::validate_and_normalize_pmf(
      row, mwperf::physical_pmf_tolerance());
  REQUIRE(result.has_value());
  const auto& pmf = result.value();
  CHECK(pmf.authored_probabilities()[0].exact_value().numerator() == 1);
  CHECK(pmf.authored_probabilities()[0].numerical_image() == 0.0L);
  CHECK(pmf.numerical_image()[0] == 0.0L);
  CHECK(pmf.integral_masses()[0].value() == 1);
  CHECK(pmf.integral_masses()[1].value() == denominator - 1);
  CHECK(pmf.integral_denominator().value() == denominator);
  CHECK(pmf.sampling_bit_width() > 64);
  CHECK(pmf.sampling_limb_count() > 1);
}

TEST_CASE("invalid categorical rows fail before normalization",
          "[c02][negative][probability]") {
  const std::vector<mwperf::AuthoredProbability> empty;
  const auto empty_result = mwperf::validate_and_normalize_pmf(
      empty, mwperf::physical_pmf_tolerance());
  REQUIRE_FALSE(empty_result.has_value());
  CHECK(empty_result.error().code == "pmf_empty");

  const std::vector<mwperf::AuthoredProbability> zero_row{
      probability(0, 1), probability(0, 1)};
  const auto zero_result = mwperf::validate_and_normalize_pmf(
      zero_row, mwperf::physical_pmf_tolerance());
  REQUIRE_FALSE(zero_result.has_value());
  CHECK(zero_result.error().code == "pmf_zero_total_mass");

  const std::vector<mwperf::AuthoredProbability> too_small{
      probability(999999998, 1000000000)};
  const auto too_small_result = mwperf::validate_and_normalize_pmf(
      too_small, mwperf::physical_pmf_tolerance());
  REQUIRE_FALSE(too_small_result.has_value());
  CHECK(too_small_result.error().code == "pmf_mass_outside_tolerance");
}
