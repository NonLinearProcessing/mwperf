#pragma once

#if !defined(MWPERF_C17_TEST_SEAMS)
#error "generic_temporal_fixture.hpp is available only to C17 tests"
#endif

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <functional>
#include <iterator>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_registered_pair_matrix_fixture.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing::c17_temporal {

namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

struct GenericTemporalFrameworkV1 final {
  AuditedCompiledFramework framework;
  ResolvedInstance instance;
  std::vector<QueueId> ordered_targets;
  ExactReducedStateSchemaV1 state_schema;
  PlugDescriptor descriptor;
  ReducedStateV1 initial_state;
  RuntimeMarkIdV1 entrance_mark;
  std::shared_ptr<std::atomic<unsigned>> entrance_decoder_calls;
  std::shared_ptr<std::atomic<unsigned>> residence_generator_calls;
};

struct PreparedGenericTemporalFrameworkV1 final {
  CompiledFrameworkCandidate candidate;
  PlugDescriptor descriptor;
  KernelAccess access;
  ResolvedInstance instance;
  std::vector<QueueId> ordered_targets;
  ExactReducedStateSchemaV1 state_schema;
  ReducedStateV1 initial_state;
  RuntimeMarkIdV1 entrance_mark;
  std::shared_ptr<std::atomic<unsigned>> entrance_decoder_calls;
  std::shared_ptr<std::atomic<unsigned>> residence_generator_calls;
};

// C17--C23 use this file as a carrier fixture for V0, temporal, residence,
// and suspension tests.  Several of those inherited tests deliberately feed
// a historical metric request whose C14 route is unrelated to the runtime
// carrier under test.  Keep that test-only mint separate from real capability
// negotiation and bind any usable route to the same canonical support-clause
// identity that C14 would publish.  The fallback also names the temporal
// carrier backend needed by V0, without representing it as a metric result.
// C24's Monte Carlo sampling request is never allowed through this seam.
[[nodiscard]] inline Digest256 fixture_support_clause_digest(
    const MetricSupportManifest& manifest,
    const MetricSupportClauseV1& clause) {
  std::vector<std::byte> bytes;
  const auto append_u64 = [&bytes](const std::uint64_t value) {
    for (unsigned shift = 64U; shift != 0U; shift -= 8U) {
      bytes.push_back(static_cast<std::byte>(
          static_cast<std::uint8_t>(value >> (shift - 8U))));
    }
  };
  const auto append_raw = [&bytes, &append_u64](
                              const std::span<const std::byte> value) {
    append_u64(static_cast<std::uint64_t>(value.size()));
    bytes.insert(bytes.end(), value.begin(), value.end());
  };
  const auto append_string = [&bytes, &append_u64](
                                 const std::string_view value) {
    append_u64(static_cast<std::uint64_t>(value.size()));
    for (const char character : value) {
      bytes.push_back(static_cast<std::byte>(
          static_cast<std::uint8_t>(static_cast<unsigned char>(character))));
    }
  };
  append_raw(manifest.canonical_digest().bytes());
  append_string(clause.clause_id.metric_id);
  append_u64(static_cast<std::uint64_t>(clause.clause_id.authored_index));
  auto digest = sha256_domain_separated(
      "mwperf.c14.metric_support_clause.v1", bytes);
  REQUIRE(digest);
  return std::move(digest).value();
}

// The verified C23 fixture has four narrowly identified C14/carrier
// mismatches.  This predicate is deliberately an allow-list over the exact
// provider, request, primary axis, failure kind, and rendered diagnostic;
// no other capability rejection may acquire a test-only contract.
[[nodiscard]] inline bool is_inherited_carrier_fixture_mismatch(
    const matrix::ProfileV1& profile,
    const designated::InputV1& source,
    const CapabilityDecision& decision,
    const Diagnostic& diagnostic) {
  const auto* const rejected = rejected_capability_decision(decision);
  if (rejected == nullptr || rejected->ordered_failures.empty()) {
    return false;
  }
  const MetricRequestHeader& request = metric_request_header(source.request);
  const CapabilityFailureV1& primary = rejected->ordered_failures.front();
  if (primary.metric_id != request.metric_id ||
      primary.authored_metric_index != request.authored_index) {
    return false;
  }

  // These two inherited C21 carriers deliberately negotiate an enumerated
  // metric request against a weaker C20 fixture manifest before C21 re-mints
  // its exact stationary route.  Keep the exceptions pinned to the complete
  // request/provider/diagnostic tuple; no other enumerated rejection may use
  // the carrier seam.
  const bool historical_c21_selection_probe =
      request.metric_id == "c21-empty" &&
      request.solver_regime == MetricSolverRegimeV1::enumerated &&
      profile.provider_id == "c20.fixture.pair.romr-reset" &&
      diagnostic.code == "c14_capability_selection_not_supported" &&
      primary.axis == CapabilityAxisV1::selection &&
      primary.kind == CapabilityFailureKindV1::selection_not_supported;
  if (historical_c21_selection_probe) {
    return true;
  }
  const bool historical_c21_transient_probe =
      request.metric_id == "c21-empty" &&
      request.solver_regime == MetricSolverRegimeV1::enumerated &&
      profile.provider_id == "c20.fixture.pair.romr-enumerable" &&
      diagnostic.code == "c14_capability_missing_semantic_contract" &&
      primary.axis == CapabilityAxisV1::semantic &&
      primary.kind == CapabilityFailureKindV1::missing_semantic_contract;
  if (historical_c21_transient_probe) {
    return true;
  }

  if (request.solver_regime != MetricSolverRegimeV1::analytic) {
    return false;
  }

  const bool historical_throughput_profile =
      request.metric_id == "throughput" &&
      (profile.provider_id == "c16.fixture.pair.romr-residence" ||
       profile.provider_id == "c20.fixture.pair.romr-enumerable" ||
       profile.provider_id == "c20.fixture.pair.romr-countable" ||
       profile.provider_id == "c20.fixture.pair.romr-reset");
  if (historical_throughput_profile &&
      diagnostic.code == "c14_capability_missing_semantic_contract" &&
      primary.axis == CapabilityAxisV1::semantic &&
      primary.kind == CapabilityFailureKindV1::missing_semantic_contract) {
    return true;
  }

  const bool historical_sampler_view_gate =
      request.metric_id == "throughput" &&
      profile.provider_id ==
          "c16.fixture.pair.temporal-continuation";
  if (historical_sampler_view_gate &&
      diagnostic.code == "c14_capability_incompatible_runtime_access" &&
      primary.axis == CapabilityAxisV1::runtime_access &&
      primary.kind == CapabilityFailureKindV1::incompatible_runtime_access) {
    return true;
  }

  const bool historical_stopped_profile =
      request.metric_id == "throughput" &&
      profile.provider_id == "c16.fixture.pair.stopped-path";
  if (historical_stopped_profile &&
      diagnostic.code == "c14_capability_unsupported_manifest_clause" &&
      primary.axis == CapabilityAxisV1::manifest &&
      primary.kind == CapabilityFailureKindV1::unsupported_manifest_clause) {
    return true;
  }

  return false;
}

[[nodiscard]] inline AcceptedCapabilityContract
carrier_fixture_contract(
    const matrix::ProfileV1& profile,
    const designated::InputV1& source,
    const FrameworkProblemView& view,
    const ValidatedSurrogateParameters& parameters,
    const PlugDescriptorPreview& preview,
    const ValidatedProviderManifest& provider_manifest,
    const ConstructionBudget& budget) {
  const auto carrier_backend = [&profile] {
    if (profile.access ==
        RuntimeAccessTagV1::normalized_conditional_sampler) {
      return BackendRouteKindV1::conditional_row_monte_carlo;
    }
    switch (profile.semantic) {
      case SemanticTagV1::temporal_one_slot_continuation:
      case SemanticTagV1::coupled_target_schedule_law:
        return BackendRouteKindV1::finite_temporal_cylinder;
      case SemanticTagV1::romr_residence_word_law:
      case SemanticTagV1::stopped_path_law:
        return BackendRouteKindV1::residence_or_stopped_law;
      case SemanticTagV1::stationary_marked_edge:
        return BackendRouteKindV1::stationary_edge_reward;
      case SemanticTagV1::scalar_backlog_response:
      case SemanticTagV1::staged_opportunity_flux_law:
      case SemanticTagV1::direct_metric_decoder:
      case SemanticTagV1::response_envelope_law:
        return BackendRouteKindV1::analytic_metric_family;
    }
    return BackendRouteKindV1::analytic_metric_family;
  }();
  REQUIRE(preview.metric_support_manifest != nullptr);
  std::vector<ResolvedMetricContractV1> resolved;
  for (const MetricRequirementClause& requirement :
       source.requirements.clauses()) {
    const auto support = std::ranges::find_if(
        preview.metric_support_manifest->clauses(),
        [&](const MetricSupportClauseV1& candidate) {
          return candidate.clause_id == requirement.origin.clause_id;
        });
    if (support == preview.metric_support_manifest->clauses().end()) {
      continue;
    }
    const auto route = std::ranges::find_if(
        requirement.route_alternatives,
        [&](const MetricRouteAlternativeV1& candidate) {
          return candidate.access.runtime_access == profile.access;
        });
    const BackendRouteKindV1 backend =
        route == requirement.route_alternatives.end()
            ? carrier_backend
            : route->access.backend_route;
    resolved.push_back(
        {requirement.origin.clause_id.authored_index,
         requirement.origin.clause_id,
         requirement.origin.clause_id.metric_id,
         requirement.origin.ordered_targets,
         support->semantic,
         support->runtime_access,
         support->target_coupling,
         support->solver_route,
         backend,
         fixture_support_clause_digest(*preview.metric_support_manifest,
                                       *support)});
  }
  auto budget_digest = digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  return C15ProtocolFixtureFactory::accepted_contract(
      provider_manifest.value(), preview.core,
      *preview.metric_support_manifest, source.requirements,
      view.configured_arrival().capabilities(), std::move(resolved),
      preview.construction_target_scope, preview.policies,
      preview.construction_prerequisites, view.canonical_digest().value(),
      parameters.canonical_value_digest(), budget_digest.value());
}

// Production C14 intentionally exposes only the conditional-reward Monte
// Carlo route today. F-C24-03 still needs a trusted accepted row-route fixture
// to prove that it cannot borrow reward authority. Re-mint exactly one
// separately named `c24-row` clause through the existing C15 test factory;
// no production negotiation vocabulary or constructor is widened.
[[nodiscard]] inline AcceptedCapabilityContract
trusted_c24_row_fixture_contract(
    const AcceptedCapabilityContract& accepted,
    const designated::InputV1& source,
    const FrameworkProblemView& view,
    const ValidatedSurrogateParameters& parameters,
    const PlugDescriptorPreview& preview,
    const ValidatedProviderManifest& provider_manifest,
    const ConstructionBudget& budget) {
  REQUIRE(preview.metric_support_manifest != nullptr);
  std::vector<ResolvedMetricContractV1> resolved(
      accepted.metric_contracts().begin(), accepted.metric_contracts().end());
  std::size_t row_routes = 0U;
  for (ResolvedMetricContractV1& contract : resolved) {
    if (contract.clause_id.metric_id == "c24-row" &&
        contract.runtime_access ==
            RuntimeAccessTagV1::normalized_conditional_sampler &&
        contract.solver_regime == SolverRegimeV1::monte_carlo &&
        contract.backend_route ==
            BackendRouteKindV1::conditional_reward_monte_carlo) {
      contract.backend_route =
          BackendRouteKindV1::conditional_row_monte_carlo;
      ++row_routes;
    }
  }
  REQUIRE(row_routes == 1U);
  auto budget_digest = digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  return C15ProtocolFixtureFactory::accepted_contract(
      provider_manifest.value(), preview.core,
      *preview.metric_support_manifest, source.requirements,
      view.configured_arrival().capabilities(), std::move(resolved),
      preview.construction_target_scope, preview.policies,
      preview.construction_prerequisites, view.canonical_digest().value(),
      parameters.canonical_value_digest(), budget_digest.value());
}

[[nodiscard]] inline const matrix::ProfileV1& temporal_profile(
    const SemanticTagV1 semantic) {
  const auto found = std::ranges::find_if(
      matrix::kProfiles, [semantic](const matrix::ProfileV1& profile) {
        return profile.semantic == semantic;
      });
  REQUIRE(found != matrix::kProfiles.end());
  return *found;
}

[[nodiscard]] inline const matrix::ProfileV1& temporal_profile() {
  return temporal_profile(SemanticTagV1::romr_residence_word_law);
}

[[nodiscard]] inline C16DesignatedScenarioV1 temporal_scenario(
    designated::InputV1 source, const matrix::ProfileV1& profile,
    const std::optional<BackendRouteKindV1> trusted_sampling_backend =
        std::nullopt) {
  auto id = SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{}
                 : provider.error().code + ": " +
                       provider.error().message));
  REQUIRE(provider);
  const auto& header = metric_request_header(source.request);
  std::vector<QueueId> ordered_targets;
  ordered_targets.reserve(header.ordered_targets.size());
  for (const ResolvedMetricTargetV1& target : header.ordered_targets) {
    ordered_targets.push_back(target.queue_id);
  }
  const TargetSelection selection{
      1U,
      std::move(ordered_targets),
      ConstructionGroupIdV1(
          designated::label("c17.temporal.construction-group"))};
  auto view = build_framework_problem_view(
      source.instance, *source.arrival, selection);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);
  auto parameters = validate_surrogate_parameters(
      provider.value(), designated::parameters());
  REQUIRE(parameters);
  auto budget = designated::budget();
  if (header.solver_regime == MetricSolverRegimeV1::monte_carlo) {
    REQUIRE(source.instance.analysis_spec().context);
    const auto& draw_cap = source.instance.analysis_spec()
                               .context->resolution.sampling
                               .max_generator_draws;
    REQUIRE(draw_cap.has_value());
    budget.configured_generator_draws = {
        BudgetApplicabilityV1::applicable, *draw_cap};
  }
  auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements, budget,
      parameters.value());
  REQUIRE(preview);
  const CapabilityDecision decision = negotiate_capabilities(
      source.requirements, preview.value(),
      view.value().configured_arrival().capabilities());
  const Diagnostic capability_diagnostic =
      explain_capability_failure(decision);
  std::string capability_detail = capability_diagnostic.code + ": " +
                                  capability_diagnostic.message;
  for (const std::string& note : capability_diagnostic.notes) {
    capability_detail += "; " + note;
  }
  INFO(capability_detail);
  AcceptedCapabilityContract contract = [&] {
    if (const AcceptedCapabilityContract* const accepted =
            accepted_capability_contract(decision);
        accepted != nullptr) {
      return *accepted;
    }
    REQUIRE(is_inherited_carrier_fixture_mismatch(
        profile, source, decision, capability_diagnostic));
    return carrier_fixture_contract(
        profile, source, view.value(), parameters.value(), preview.value(),
        provider.value().manifest(), budget);
  }();
  if (trusted_sampling_backend.has_value()) {
    REQUIRE(*trusted_sampling_backend ==
            BackendRouteKindV1::conditional_row_monte_carlo);
    contract = trusted_c24_row_fixture_contract(
        contract, source, view.value(), parameters.value(), preview.value(),
        provider.value().manifest(), budget);
  }
  auto request = make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, MasterSeed{0xC1710U});
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(), manifest,
          std::move(source.instance), std::move(source.arrival),
          std::move(source.requirements), std::move(source.request),
          std::move(view).value(), std::move(parameters).value(),
          std::move(preview).value(), std::move(contract), budget,
          std::move(request).value()};
}

[[nodiscard]] inline C16DesignatedScenarioV1 temporal_scenario(
    designated::InputV1 source) {
  return temporal_scenario(std::move(source), temporal_profile());
}

[[nodiscard]] inline C16DesignatedScenarioV1 temporal_scenario(
    const matrix::ProfileV1& profile) {
  return temporal_scenario(designated::input(profile.provider_id), profile);
}

[[nodiscard]] inline C16DesignatedScenarioV1 temporal_scenario() {
  return temporal_scenario(temporal_profile());
}

[[nodiscard]] inline ArtifactObjectReferenceV1 role_subject(
    const MetricSupportRoleV1 role,
    const ArtifactObjectReferenceV1& payload,
    const ArtifactObjectReferenceV1& validity) {
  if (role == MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    return validity;
  }
  return payload;
}

[[nodiscard]] inline BoundRealizedMetricBindingsV1 realized_bindings(
    const C16DesignatedScenarioV1& scenario,
    const ArtifactObjectReferenceV1& payload_identity,
    const Digest256& payload_digest) {
  const auto validity = designated::object("c17.temporal.validity");
  std::vector<RealizedMetricBindingV1> bindings;
  std::size_t binding_count = 0U;
  for (const auto& clause :
       scenario.contract.structural_manifest().clauses()) {
    binding_count += clause.required_roles.size();
  }
  bindings.reserve(binding_count);
  for (const auto& clause :
       scenario.contract.structural_manifest().clauses()) {
    for (const auto& requirement : clause.required_roles) {
      std::vector<RealizedRoleRelationV1> role_relations;
      role_relations.reserve(requirement.role_relations.size());
      for (const auto& relation : requirement.role_relations) {
        role_relations.push_back(
            {relation.relation,
             {clause.clause_id, relation.other_role},
             role_subject(relation.other_role, payload_identity, validity)});
      }
      std::vector<RealizedInternalReferenceV1> internal_relations;
      internal_relations.reserve(requirement.internal_relations.size());
      for (const auto& relation : requirement.internal_relations) {
        ArtifactObjectReferenceV1 referenced = designated::object(
            "c17.temporal.internal." +
            std::to_string(static_cast<unsigned>(relation.purpose)));
        if (relation.purpose ==
                InternalReferencePurposeV1::artifact_payload ||
            relation.purpose == InternalReferencePurposeV1::law_or_result) {
          referenced = payload_identity;
        } else if (relation.purpose ==
                   InternalReferencePurposeV1::normalized_request) {
          referenced.object_digest = scenario.contract.requirements_digest();
        } else if (relation.purpose ==
                   InternalReferencePurposeV1::selection_binding) {
          referenced.object_digest =
              scenario.view.fingerprints().target_selection;
        } else if (relation.purpose ==
                   InternalReferencePurposeV1::configured_arrival_binding) {
          referenced.object_digest =
              scenario.view.fingerprints().compiled_arrival;
        }
        internal_relations.push_back(
            {relation.relation, relation.purpose, std::move(referenced)});
      }
      RealizedReferenceCoreV1 core{
          clause.ordered_targets,
          requirement.target_scope,
          requirement.result_scope,
          requirement.evidence_scope,
          std::move(role_relations),
          std::move(internal_relations)};
      RealizedReferenceV1 reference =
          requirement.role == MetricSupportRoleV1::deployed_payload
              ? RealizedReferenceV1{DeployedPayloadReferenceV1{
                    std::move(core), ArtifactPayloadRef{payload_identity}}}
          : requirement.role ==
                    MetricSupportRoleV1::temporal_continuation_law
              ? RealizedReferenceV1{TemporalContinuationLawReferenceV1{
                    std::move(core),
                    TemporalContinuationLawRef{payload_identity}}}
          : requirement.role == MetricSupportRoleV1::residence_word_law
              ? RealizedReferenceV1{ResidenceWordLawReferenceV1{
                    std::move(core), ResidenceWordLawRef{payload_identity}}}
          : requirement.role == MetricSupportRoleV1::stopped_path_law
              ? RealizedReferenceV1{StoppedPathLawReferenceV1{
                    std::move(core), StoppedPathLawRef{payload_identity}}}
              : RealizedReferenceV1{
                    ReportedValidityOrLiftEvidenceReferenceV1{
                        std::move(core),
                        ReportedValidityOrLiftEvidenceRef{validity}}};
      bindings.push_back(
          {{clause.clause_id, requirement.role}, std::move(reference)});
    }
  }
  return {scenario.request.request_digest().value(), payload_digest,
          std::move(bindings)};
}

struct TemporalMaterializationV1 final {
  ValidatedSurrogateArtifact artifact;
  PortablePlugPayload payload;
};

[[nodiscard]] inline ArtifactPayloadV1 temporal_payload(
    const C16DesignatedScenarioV1& scenario) {
  if (scenario.contract.payload_class().tag ==
      PayloadClassTagV1::registered_runtime_recipe_v1) {
    return ArtifactPayloadV1{RegisteredRuntimeRecipeV1{
        1U,
        "c16.registered-pair.recipe",
        1U,
        "c16.registered-pair.recipe-parameters",
        1U,
        "c16.registered-pair.recipe-state",
        1U,
        "c16.registered-pair.recipe-mark",
        1U,
        scenario.provider.identity(),
        scenario.preview.core.deployed_targets,
        {{std::string(matrix::kC17TemporalFixtureParameter),
          designated::scalar(1, 1)}},
        scenario.preview.core.state_fields,
        scenario.preview.core.marks}};
  }

  REQUIRE(scenario.contract.payload_class().tag ==
          PayloadClassTagV1::finite_law_tables_v1);
  REQUIRE(scenario.contract.semantic() ==
          SemanticTagV1::romr_residence_word_law);
  REQUIRE(scenario.contract.runtime_access() ==
          RuntimeAccessTagV1::finite_enumerated_row);

  // This portable table is the exact row authority paired with the C20
  // homogeneous fixture.  State labels are finite event representatives: the
  // physical boundary remains in runtime words and is intentionally absent
  // from this finite event-state dictionary.
  const std::vector<TypedLabel> event_states{
      designated::label("c20.fixture.enumerable-romr.state.b0.p0"),
      designated::label("c20.fixture.enumerable-romr.state.b0.p1"),
      designated::label("c20.fixture.enumerable-romr.state.b2.p0"),
      designated::label("c20.fixture.enumerable-romr.state.b2.p1")};
  const std::vector<TypedLabel> outcome_marks{
      designated::label("c20.fixture.enumerable-romr.outcome.0"),
      designated::label("c20.fixture.enumerable-romr.outcome.1")};

  const auto state_coordinates = [&](const std::int64_t backlog,
                                     const std::int64_t phase) {
    std::vector<PortableScientificScalar> coordinates(
        scenario.preview.core.state_fields.size(),
        designated::scalar(0, 1));
    REQUIRE(coordinates.size() >= 2U);
    coordinates[0U] = designated::scalar(backlog, 1);
    coordinates[1U] = designated::scalar(phase, 1);
    return coordinates;
  };
  std::vector<PortableFiniteDictionaryEntryV1> states{
      {event_states[0U], state_coordinates(0, 0)},
      {event_states[1U], state_coordinates(0, 1)},
      {event_states[2U], state_coordinates(2, 0)},
      {event_states[3U], state_coordinates(2, 1)}};

  const auto mark_coordinates = [&](const std::int64_t outcome) {
    std::vector<PortableScientificScalar> coordinates(
        scenario.preview.core.marks.size(), designated::scalar(0, 1));
    REQUIRE(!coordinates.empty());
    coordinates.front() = designated::scalar(outcome, 1);
    return coordinates;
  };
  std::vector<PortableFiniteDictionaryEntryV1> marks{
      {outcome_marks[0U], mark_coordinates(0)},
      {outcome_marks[1U], mark_coordinates(1)}};

  std::vector<ExplicitOrderedWordV1> words;
  words.reserve(12U);
  // A zero-backlog entry has a one-slot residence.  Each C09 phase outcome
  // has exact mass one half and determines the successor phase class.
  for (std::size_t entrance = 0U; entrance != 2U; ++entrance) {
    words.push_back({event_states[entrance], BigNat{1U},
                     {outcome_marks[0U]}, event_states[0U], event_states[0U],
                     designated::scalar(1, 2)});
    words.push_back({event_states[entrance], BigNat{1U},
                     {outcome_marks[1U]}, event_states[1U], event_states[1U],
                     designated::scalar(1, 2)});
  }
  // A backlog-two entry is drained in two deterministic service slots.  The
  // four ordered C09 outcome histories are distinct exact words of mass 1/4;
  // only the last phase selects the zero-clock event endpoint.
  for (std::size_t entrance = 2U; entrance != 4U; ++entrance) {
    words.push_back({event_states[entrance], BigNat{2U},
                     {outcome_marks[0U], outcome_marks[0U]}, event_states[0U],
                     event_states[0U], designated::scalar(1, 4)});
    words.push_back({event_states[entrance], BigNat{2U},
                     {outcome_marks[0U], outcome_marks[1U]}, event_states[1U],
                     event_states[1U], designated::scalar(1, 4)});
    words.push_back({event_states[entrance], BigNat{2U},
                     {outcome_marks[1U], outcome_marks[0U]}, event_states[0U],
                     event_states[0U], designated::scalar(1, 4)});
    words.push_back({event_states[entrance], BigNat{2U},
                     {outcome_marks[1U], outcome_marks[1U]}, event_states[1U],
                     event_states[1U], designated::scalar(1, 4)});
  }
  FiniteLawTableAlternativeV1 table{RomrResidenceWordTableV1{
      1U,
      designated::object(matrix::kC20EnumerableRomrLaw),
      "c20.fixture.enumerable-romr.backlog-empty-stop",
      event_states,
      event_states,
      outcome_marks,
      std::move(words),
      designated::scalar(0, 1),
      {designated::object(
          "c20.fixture.enumerable-romr.complete-mass-evidence")}}};
  auto law_digest = artifact::detail::finite_law_table_digest_v1(table);
  REQUIRE(law_digest);
  std::get<RomrResidenceWordTableV1>(table).law_id.object_digest =
      std::move(law_digest).value();

  return ArtifactPayloadV1{FiniteLawTablesV1{
      1U,
      scenario.preview.core.deployed_targets,
      SemanticTagV1::romr_residence_word_law,
      RuntimeAccessTagV1::finite_enumerated_row,
      scenario.view.fingerprints().compiled_arrival,
      scenario.view.fingerprints().target_selection,
      std::move(states),
      std::move(marks),
      std::move(table)}};
}

[[nodiscard]] inline TemporalMaterializationV1 temporal_materialization(
    const C16DesignatedScenarioV1& scenario) {
  ArtifactPayloadV1 payload_value = temporal_payload(scenario);
  auto payload_digest = canonical_artifact_payload_digest_v1(payload_value);
  REQUIRE(payload_digest);
  const ArtifactObjectReferenceV1 payload_identity{
      designated::label("c17.temporal.payload"), payload_digest.value()};
  auto realized = realized_bindings(
      scenario, payload_identity, payload_digest.value());
  const auto echo = designated::manifest_echo(
      scenario.contract.structural_manifest());
  SurrogateArtifactV1 source{
      1U,
      scenario.request.request_digest().value(),
      scenario.provider.identity(),
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.contract.construction_method(),
      scenario.contract.producer_mode(),
      scenario.contract.semantic(),
      scenario.contract.runtime_access(),
      scenario.contract.payload_class(),
      payload_identity,
      std::move(payload_value),
      payload_digest.value(),
      echo,
      std::move(realized),
      scenario.preview.core,
      designated::report(scenario),
      {},
      {},
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  const ArtifactValidationBindingsV1 validation{
      scenario.request.build_identity_digest().digest(),
      scenario.request.request_digest().value(),
      scenario.provider.identity(),
      scenario.provider.manifest().value().parameter_schema_version,
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.contract.construction_method(),
      scenario.contract.producer_mode(),
      scenario.contract.semantic(),
      scenario.contract.runtime_access(),
      scenario.contract.payload_class(),
      scenario.view.canonical_digest().value(),
      std::move(selection_digest).value(),
      scenario.contract.contract_digest(),
      scenario.contract.requirements_digest(),
      scenario.contract.arrival_capabilities_digest(),
      scenario.contract.preview_digest(),
      scenario.contract.parameter_digest(),
      scenario.contract.budget_digest(),
      scenario.contract.structural_manifest().canonical_digest()};
  auto artifact = C15ProtocolFixtureFactory::validated_artifact(
      std::move(source), validation);
  auto payload = adapt_portable_payload(artifact);
  REQUIRE(payload);
  return {std::move(artifact), std::move(payload).value()};
}

template <typename DescriptorMutation, typename StateSchemaFactory,
          typename InitialStateFactory, typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
    C16DesignatedScenarioV1 scenario,
    const ArrivalInitialState& arrival_initial_state,
    std::optional<BigNat> execution_optimizer_max_calls,
    DescriptorMutation&& mutate_descriptor,
    StateSchemaFactory&& make_state_schema,
    InitialStateFactory&& make_initial_state,
    ProgramMutation&& mutate_program,
    std::function<void(AuditedFrameworkSeedV1&)> mutate_seed = {}) {
  matrix::c17_temporal_generator_calls()->store(
      0U, std::memory_order_relaxed);
  matrix::C17TemporalFixtureOverrideV1 scenario_bound_override =
      matrix::c17_temporal_fixture_override_slot() == nullptr
          ? matrix::C17TemporalFixtureOverrideV1{}
          : *matrix::c17_temporal_fixture_override_slot();
  if (!scenario_bound_override
           .preserve_authored_conditional_sampler_arrival_binding) {
    scenario_bound_override
        .conditional_sampler_configured_arrival_binding =
        scenario.view.fingerprints().compiled_arrival;
  }
  const matrix::ScopedC17TemporalFixtureOverride scenario_binding_guard(
      scenario_bound_override);
  auto materialization = temporal_materialization(scenario);
  auto plug = materialize_and_validate_surrogate_plug(
      materialization.payload, materialization.artifact, scenario.contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  PlugDescriptor descriptor = plug.value().descriptor();
  std::forward<DescriptorMutation>(mutate_descriptor)(descriptor);
  std::vector<RuntimeMarkDescriptorV1> entrance_descriptors;
  std::ranges::copy_if(
      descriptor.marks, std::back_inserter(entrance_descriptors),
      [](const RuntimeMarkDescriptorV1& mark) {
        return mark.decoder_source ==
               MarkDecoderSourceV1::entrance_realization;
      });
  REQUIRE_FALSE(entrance_descriptors.empty());

  const std::vector<QueueId> targets(
      descriptor.core.deployed_targets.begin(),
      descriptor.core.deployed_targets.end());
  auto realized = validate_realized_metric_bindings_v1(
      scenario.contract.structural_manifest(),
      RealizedBindingValidationContextV1{
          RealizedBindingTargetContextV1{
              targets, std::optional<QueueId>{targets.front()},
              std::vector<QueueId>(
                  scenario.contract.construction_target_scope().begin(),
                  scenario.contract.construction_target_scope().end())},
          scenario.contract.policies()},
      materialization.artifact.value().realized_metric_bindings.bindings);
  INFO((realized ? std::string{}
                 : realized.error().code + ": " +
                       realized.error().message));
  REQUIRE(realized);

  const CompiledArrivalLaw configured_arrival = *scenario.arrival;
  auto instance_key = make_physical_reference_instance_key(
      scenario.instance.fingerprints().combined, BigNat{0U});
  REQUIRE(instance_key);
  auto stream = make_configured_arrival_stream_key(
      configured_arrival,
      derive_rng_stream(MasterSeed{0xC1711U},
                        StageTag::configured_arrival,
                        instance_key.value()));
  REQUIRE(stream);
  auto process = instantiate_arrival_process(
      configured_arrival, arrival_initial_state,
      std::move(stream).value());
  REQUIRE(process);
  auto first = next_arrival_step(process.value(), BigNat{0U});
  REQUIRE(first);
  auto state_schema = std::forward<StateSchemaFactory>(make_state_schema)(
      scenario.instance, std::span<const QueueId>(targets),
      configured_arrival,
      first.value().phase_before, first.value().phase_after);
  auto entrance_calls = std::make_shared<std::atomic<unsigned>>(0U);
  for (const RuntimeMarkDescriptorV1& entrance : entrance_descriptors) {
    state_schema.framework_mark_decoders.emplace_back(
        DeterministicRuntimeMarkDecoderSchemaV1{
            entrance.decoder_id, entrance.id, entrance.decoder_source,
            entrance.decoder_input_codec, entrance.c14_mark.codec},
        [entrance_calls, codec = entrance.c14_mark.codec](
            const CanonicalRuntimeValueV1&) {
          entrance_calls->fetch_add(1U, std::memory_order_relaxed);
          if (codec.id == "mwperf.c23.typed_label" &&
              codec.version == 1U) {
            const auto encoded =
                TypedLabel::numeric(BigNat{1U}).canonical_bytes();
            std::vector<std::byte> bytes;
            bytes.reserve(encoded.size());
            for (const std::uint8_t value : encoded) {
              bytes.push_back(static_cast<std::byte>(value));
            }
            return Result<CanonicalRuntimeValueV1>::success(
                {codec, std::move(bytes)});
          }
          return Result<CanonicalRuntimeValueV1>::success(
              {codec, {std::byte{0x01}}});
        });
  }
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::decision_schedule) {
      continue;
    }
    state_schema.framework_mark_decoders.emplace_back(
        DeterministicRuntimeMarkDecoderSchemaV1{
            mark.decoder_id, mark.id, mark.decoder_source,
            mark.decoder_input_codec, mark.c14_mark.codec},
        [codec = mark.c14_mark.codec](const CanonicalRuntimeValueV1&) {
          if (codec.id == "mwperf.c23.typed_label" &&
              codec.version == 1U) {
            const auto encoded =
                TypedLabel::numeric(BigNat{1U}).canonical_bytes();
            std::vector<std::byte> bytes;
            bytes.reserve(encoded.size());
            for (const std::uint8_t value : encoded) {
              bytes.push_back(static_cast<std::byte>(value));
            }
            return Result<CanonicalRuntimeValueV1>::success(
                {codec, std::move(bytes)});
          }
          return Result<CanonicalRuntimeValueV1>::success(
              {codec, {std::byte{0x01}}});
        });
  }

  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      scenario.instance, std::move(execution_optimizer_max_calls));
  REQUIRE(optimizer);
  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          scenario.view.target_selection().ordered_targets);
  REQUIRE(ordered_target_digest);
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  auto canonical_access =
      C17FixtureAccess::canonical_raw_access_identity(access.value());
  REQUIRE(canonical_access);
  AuditedFrameworkBindingsV1 bindings{
      scenario.view.fingerprints(),
      scenario.view.canonical_digest(),
      state_schema.exact_state_schema_digest,
      state_schema.reduced_state_schema_digest,
      descriptor.descriptor_digest,
      canonical_access.value(),
      scenario.contract.contract_digest(),
      scenario.contract.requirements_digest(),
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      scenario.request.request_digest().value(),
      std::nullopt};
  auto initial_mass = ProbabilityMass::exact_rational(
      ExactRational::one(), true);
  REQUIRE(initial_mass);
  const ReducedStateV1 initial_state =
      std::forward<InitialStateFactory>(make_initial_state)(
          std::span<const QueueId>(targets), state_schema);
  const auto domain_validator = state_schema.validate_domain;
  const Digest256 instance_digest = scenario.instance.fingerprints().combined;
  const Digest256 exact_schema_digest = state_schema.exact_state_schema_digest;
  AuditedFrameworkSeedV1 seed{
      bindings,
      scenario.view.target_selection(),
      state_schema.reduced_state_codec,
      descriptor.core.selection,
      {SelectionKindV1::stationary_unique,
       c17::digest("c17.temporal.selection-evidence")},
      [state_codec = state_schema.reduced_state_codec,
       exact_schema_digest,
       reduced_schema_digest = state_schema.reduced_state_schema_digest,
       selected_law_digest = bindings.selection_digest,
       selection_support = descriptor.core.selection,
       initial_state,
       initial_mass = std::move(initial_mass).value()](
          const SelectionSpec&,
          const std::optional<InitialPhysicalLaw>&) {
        return Result<ReducedInitialLawCandidateV1>::success(
            {state_codec, exact_schema_digest, reduced_schema_digest,
             selected_law_digest, selection_support,
             {{initial_state, initial_mass, std::nullopt}}});
      },
      [instance_digest, exact_schema_digest](
          const ResolvedInstance& instance,
          const Digest256& supplied_schema) {
        if (instance.fingerprints().combined != instance_digest ||
            supplied_schema != exact_schema_digest) {
          return c17::failure<void>(
              "c17.fixture.initial_schema_binding",
              "foreign exact initial-state schema");
        }
        return Result<void>::success();
      },
      domain_validator,
      [domain_validator](std::size_t, const InitialPhysicalAtom&,
                         const ReducedStateV1& reduced) {
        return domain_validator(reduced);
      }};
  if (mutate_seed) {
    mutate_seed(seed);
  }
  ExactCausalProgramV1 program{
      ExactCausalProgramModeV1::generic_bound_operations,
      physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(), {}};
  program.maximum_residence_slots = 1U;
  program.event_entry_domain_is_exact_state_domain = true;
  std::forward<ProgramMutation>(mutate_program)(program);
  CompiledFrameworkCandidateInputsV1 inputs{
      scenario.request.build_identity_digest(),
      scenario.request.request_digest().value(),
      scenario.instance,
      configured_arrival,
      scenario.contract,
      std::move(realized).value(),
      state_schema,
      std::move(program),
      std::nullopt,
      std::move(optimizer).value(),
      std::move(seed)};
  auto candidate = C17FixtureAccess::make_candidate(
      std::move(plug).value(), std::move(inputs));
  return {std::move(candidate), descriptor, std::move(access).value(),
          scenario.instance, targets, std::move(state_schema), initial_state,
          entrance_descriptors.front().id, std::move(entrance_calls),
          matrix::c17_temporal_generator_calls()};
}

template <typename DescriptorMutation, typename StateSchemaFactory,
          typename InitialStateFactory, typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_generic_temporal_framework_from_scenario(
    C16DesignatedScenarioV1 scenario,
    DescriptorMutation&& mutate_descriptor,
    StateSchemaFactory&& make_state_schema,
    InitialStateFactory&& make_initial_state,
    ProgramMutation&& mutate_program) {
  return prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
      std::move(scenario), ArrivalInitialState{TraceOrigin{}}, BigNat{0U},
      std::forward<DescriptorMutation>(mutate_descriptor),
      std::forward<StateSchemaFactory>(make_state_schema),
      std::forward<InitialStateFactory>(make_initial_state),
      std::forward<ProgramMutation>(mutate_program));
}

template <typename DescriptorMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_generic_temporal_framework(DescriptorMutation&& mutate_descriptor) {
  return prepare_generic_temporal_framework_from_scenario(
      temporal_scenario(),
      std::forward<DescriptorMutation>(mutate_descriptor),
      [](const ResolvedInstance& instance,
         const std::span<const QueueId> targets,
         const CompiledArrivalLaw&,
         const ArrivalPhase& before, const ArrivalPhase& after) {
        return c17::exact_state_schema(instance, targets, before, after);
      },
      [](const std::span<const QueueId> targets,
         const ExactReducedStateSchemaV1&) {
        return c17::reduced_state(targets, {1U});
      },
      [](ExactCausalProgramV1&) {});
}

template <typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_profile_temporal_framework(
    C16DesignatedScenarioV1 scenario,
    ProgramMutation&& mutate_program) {
  return prepare_generic_temporal_framework_from_scenario(
      std::move(scenario), [](PlugDescriptor&) {},
      [](const ResolvedInstance& instance,
         const std::span<const QueueId> targets,
         const CompiledArrivalLaw&,
         const ArrivalPhase& before, const ArrivalPhase& after) {
        return c17::exact_state_schema(instance, targets, before, after);
      },
      [](const std::span<const QueueId> targets,
         const ExactReducedStateSchemaV1&) {
        return c17::reduced_state(targets, {1U});
      },
      std::forward<ProgramMutation>(mutate_program));
}

// C24's normalized-sampler fixture is negotiated under the Monte Carlo
// stationary-edge-reward request authored for that profile.  Keep this
// opt-in entry point separate from the inherited C17--C23 profile helper:
// changing temporal_scenario(profile) would silently replace the historical
// analysis request for every earlier checkpoint that reuses this fixture.
template <typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_conditional_sampling_framework(
    const matrix::ProfileV1& profile,
    const std::uint64_t replications,
    const StatisticalIntervalKindV1 interval,
    const BackendRouteKindV1 accepted_backend_route,
    ProgramMutation&& mutate_program) {
  REQUIRE((accepted_backend_route ==
               BackendRouteKindV1::conditional_row_monte_carlo ||
           accepted_backend_route ==
               BackendRouteKindV1::conditional_reward_monte_carlo));
  if (accepted_backend_route ==
      BackendRouteKindV1::conditional_row_monte_carlo) {
    REQUIRE(interval == StatisticalIntervalKindV1::none);
  }
  const std::string_view interval_name = [&] {
    switch (interval) {
      case StatisticalIntervalKindV1::none:
        return std::string_view{"none"};
      case StatisticalIntervalKindV1::exact_binomial:
        return std::string_view{"exact_binomial"};
      case StatisticalIntervalKindV1::hoeffding:
        return std::string_view{"hoeffding"};
      default:
        return std::string_view{"none"};
    }
  }();
  const std::string_view metric_id = [&] {
    if (accepted_backend_route ==
        BackendRouteKindV1::conditional_row_monte_carlo) {
      return std::string_view{"c24-row"};
    }
    switch (interval) {
      case StatisticalIntervalKindV1::exact_binomial:
        return std::string_view{"c24-exact-binomial"};
      case StatisticalIntervalKindV1::hoeffding:
        return std::string_view{"c24-hoeffding"};
      default:
        return std::string_view{"c24-none"};
    }
  }();
  return prepare_profile_temporal_framework(
      temporal_scenario(designated::input(profile.provider_id, true,
                                          replications, interval_name,
                                          metric_id),
                        profile,
                        accepted_backend_route ==
                                BackendRouteKindV1::conditional_row_monte_carlo
                            ? std::optional<BackendRouteKindV1>{
                                  accepted_backend_route}
                            : std::nullopt),
      std::forward<ProgramMutation>(mutate_program));
}

template <typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_conditional_sampling_framework(
    const matrix::ProfileV1& profile,
    const std::uint64_t replications,
    const StatisticalIntervalKindV1 interval,
    ProgramMutation&& mutate_program) {
  return prepare_conditional_sampling_framework(
      profile, replications, interval,
      BackendRouteKindV1::conditional_reward_monte_carlo,
      std::forward<ProgramMutation>(mutate_program));
}

template <typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_conditional_sampling_framework(
    const matrix::ProfileV1& profile,
    ProgramMutation&& mutate_program) {
  return prepare_conditional_sampling_framework(
      profile, 64U, StatisticalIntervalKindV1::none,
      std::forward<ProgramMutation>(mutate_program));
}

template <typename ProgramMutation>
[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_profile_temporal_framework(
    const matrix::ProfileV1& profile,
    ProgramMutation&& mutate_program) {
  return prepare_profile_temporal_framework(
      temporal_scenario(profile),
      std::forward<ProgramMutation>(mutate_program));
}

[[nodiscard]] inline PreparedGenericTemporalFrameworkV1
prepare_generic_temporal_framework() {
  return prepare_generic_temporal_framework([](PlugDescriptor&) {});
}

[[nodiscard]] inline GenericTemporalFrameworkV1
make_generic_temporal_framework() {
  auto prepared = prepare_generic_temporal_framework();
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(), std::move(prepared.instance),
          std::move(prepared.ordered_targets),
          std::move(prepared.state_schema), std::move(prepared.descriptor),
          std::move(prepared.initial_state),
          std::move(prepared.entrance_mark),
          std::move(prepared.entrance_decoder_calls),
          std::move(prepared.residence_generator_calls)};
}

}  // namespace mwperf::testing::c17_temporal
