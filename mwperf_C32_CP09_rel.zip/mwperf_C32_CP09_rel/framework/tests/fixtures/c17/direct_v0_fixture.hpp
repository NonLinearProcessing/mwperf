#pragma once

#if !defined(MWPERF_C17_TEST_SEAMS)
#error "direct_v0_fixture.hpp is available only to C17 tests"
#endif

#include <algorithm>
#include <atomic>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_registered_pair_matrix_fixture.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing::c17_direct {

namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

struct MaterializationV1 final {
  ValidatedSurrogateArtifact artifact;
  PortablePlugPayload payload;
};

struct FactorFrameworkV1 final {
  AuditedCompiledFramework framework;
  ResolvedInstance instance;
  std::vector<QueueId> ordered_targets;
  ExactReducedStateSchemaV1 state_schema;
  ReducedStateV1 initial_state;
};

struct FactorRecipeV1 final {
  RuntimeDirectFactorRecipeV1 recipe;
  ExactReducedStateSchemaV1 state_schema;
  ReducedStateV1 initial_state;
};

struct DirectScenarioV1 final {
  C16DesignatedScenarioV1 factor;
  C16DesignatedScenarioV1 direct;
  MaterializationV1 direct_materialization;
};

struct PreparedDirectCandidateV1 final {
  DirectMetricCompositeCandidateV1 candidate;
  OptimizerCallLedgerObserver optimizer_observer;
};

[[nodiscard]] inline const matrix::ProfileV1& profile(
    const SemanticTagV1 semantic) {
  const auto found = std::ranges::find_if(
      matrix::kProfiles, [semantic](const matrix::ProfileV1& candidate) {
        return candidate.semantic == semantic;
      });
  REQUIRE(found != matrix::kProfiles.end());
  return *found;
}

[[nodiscard]] inline designated::InputV1 direct_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.pair.direct-metric",
                 "version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":16,"max_search_states_per_call":16},
      "sampling":{"max_generator_draws":16},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"direct","parameters":{}}
  })json";
  auto model_document = load_document(
      designated::write_input("c17-direct-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c17-direct-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  auto requirements = requirements_for_metric(request.value());
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline C16DesignatedScenarioV1 scenario(
    const matrix::ProfileV1& selected_profile,
    const designated::InputV1& source,
    const BackendRouteKindV1 backend_route,
    const SolverRegimeV1 solver_regime) {
  auto id = SurrogateId::parse(std::string(selected_profile.provider_id));
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const TargetSelection selection{
      1U,
      {designated::queue("q0")},
      ConstructionGroupIdV1(
          designated::label("c17.direct.construction-group"))};
  auto view = build_framework_problem_view(
      source.instance, *source.arrival, selection);
  REQUIRE(view);
  auto parameters = validate_surrogate_parameters(
      provider.value(), designated::parameters());
  REQUIRE(parameters);
  const auto budget = designated::budget();
  auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements, budget,
      parameters.value());
  REQUIRE(preview);
  auto budget_digest = digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const auto& header = metric_request_header(source.request);
  std::vector<ResolvedMetricContractV1> metric_contracts{{
      header.authored_index,
      {header.metric_id, header.authored_index},
      header.metric_id,
      header.ordered_targets,
      selected_profile.semantic,
      selected_profile.access,
      TargetCouplingV1::scalar_target,
      solver_regime,
      backend_route,
      preview.value().metric_support_manifest->canonical_digest()}};
  auto contract = C15ProtocolFixtureFactory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, source.requirements,
      view.value().configured_arrival().capabilities(),
      std::move(metric_contracts), preview.value().construction_target_scope,
      preview.value().policies, preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, MasterSeed{0xC1713U});
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(), manifest, source.instance,
          source.arrival, source.requirements, source.request,
          std::move(view).value(), std::move(parameters).value(),
          std::move(preview).value(), std::move(contract), budget,
          std::move(request).value()};
}

[[nodiscard]] inline ArtifactObjectReferenceV1 role_subject(
    const MetricSupportRoleV1 role,
    const ArtifactObjectReferenceV1& payload,
    const ArtifactObjectReferenceV1& primary,
    const ArtifactObjectReferenceV1& stability,
    const ArtifactObjectReferenceV1& validity) {
  if (role == MetricSupportRoleV1::deployed_payload) return payload;
  if (role == MetricSupportRoleV1::stability_certificate) {
    return stability;
  }
  if (role == MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    return validity;
  }
  return primary;
}

[[nodiscard]] inline BoundRealizedMetricBindingsV1 realized_bindings(
    const C16DesignatedScenarioV1& selected,
    const ArtifactObjectReferenceV1& payload_identity,
    const ArtifactObjectReferenceV1& primary_identity,
    const ArtifactObjectReferenceV1& validity_identity,
    const Digest256& payload_digest) {
  const auto& clause = selected.contract.structural_manifest().clauses().front();
  const auto stability_identity =
      designated::object("c17.direct.stability");
  std::vector<RealizedMetricBindingV1> bindings;
  bindings.reserve(clause.required_roles.size());
  for (const auto& requirement : clause.required_roles) {
    std::vector<RealizedRoleRelationV1> role_relations;
    role_relations.reserve(requirement.role_relations.size());
    for (const auto& relation : requirement.role_relations) {
      role_relations.push_back(
          {relation.relation,
           {clause.clause_id, relation.other_role},
           role_subject(relation.other_role, payload_identity,
                        primary_identity, stability_identity,
                        validity_identity)});
    }
    std::vector<RealizedInternalReferenceV1> internal_relations;
    internal_relations.reserve(requirement.internal_relations.size());
    for (const auto& relation : requirement.internal_relations) {
      ArtifactObjectReferenceV1 referenced = designated::object(
          "c17.direct.internal." +
          std::to_string(static_cast<unsigned>(relation.purpose)));
      if (relation.purpose == InternalReferencePurposeV1::artifact_payload) {
        referenced = payload_identity;
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::law_or_result) {
        referenced = primary_identity;
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::deployed_law) {
        referenced = primary_identity;
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::normalized_request) {
        referenced.object_digest = selected.contract.requirements_digest();
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::selection_binding) {
        referenced.object_digest =
            selected.view.fingerprints().target_selection;
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::configured_arrival_binding) {
        referenced.object_digest =
            selected.view.fingerprints().compiled_arrival;
      }
      internal_relations.push_back(
          {relation.relation, relation.purpose, std::move(referenced)});
    }
    RealizedReferenceCoreV1 core{
        clause.ordered_targets,
        requirement.target_scope,
        requirement.result_scope,
        requirement.evidence_scope,
        std::move(role_relations),
        std::move(internal_relations)};
    RealizedReferenceV1 reference =
        requirement.role == MetricSupportRoleV1::deployed_payload
            ? RealizedReferenceV1{DeployedPayloadReferenceV1{
                  std::move(core), ArtifactPayloadRef{payload_identity}}}
        : requirement.role == MetricSupportRoleV1::stationary_marked_edge_law
            ? RealizedReferenceV1{StationaryMarkedEdgeLawReferenceV1{
                  std::move(core),
                  StationaryMarkedEdgeLawRef{primary_identity}}}
        : requirement.role == MetricSupportRoleV1::direct_metric_value
            ? RealizedReferenceV1{DirectMetricValueReferenceV1{
                  std::move(core), DirectMetricValueRef{primary_identity}}}
        : requirement.role == MetricSupportRoleV1::stability_certificate
            ? RealizedReferenceV1{StabilityCertificateReferenceV1{
                  std::move(core),
                  StabilityCertificateRef{stability_identity}}}
            : RealizedReferenceV1{
                  ReportedValidityOrLiftEvidenceReferenceV1{
                      std::move(core),
                      ReportedValidityOrLiftEvidenceRef{validity_identity}}};
    bindings.push_back(
        {{clause.clause_id, requirement.role}, std::move(reference)});
  }
  return {selected.request.request_digest().value(), payload_digest,
          std::move(bindings)};
}

[[nodiscard]] inline MaterializationV1 materialization(
    const C16DesignatedScenarioV1& selected, ArtifactPayloadV1 payload_value,
    const ArtifactObjectReferenceV1& primary_identity,
    const ArtifactObjectReferenceV1& validity_identity) {
  auto payload_digest = canonical_artifact_payload_digest_v1(payload_value);
  REQUIRE(payload_digest);
  const ArtifactObjectReferenceV1 payload_identity{
      designated::label("c17.direct.payload"), payload_digest.value()};
  auto realized = realized_bindings(
      selected, payload_identity, primary_identity, validity_identity,
      payload_digest.value());
  SurrogateArtifactV1 source{
      1U,
      selected.request.request_digest().value(),
      selected.provider.identity(),
      selected.provider.manifest().scientific_contract_digest().value(),
      selected.contract.construction_method(),
      selected.contract.producer_mode(),
      selected.contract.semantic(),
      selected.contract.runtime_access(),
      selected.contract.payload_class(),
      payload_identity,
      std::move(payload_value),
      payload_digest.value(),
      designated::manifest_echo(selected.contract.structural_manifest()),
      std::move(realized),
      selected.preview.core,
      designated::report(selected),
      {},
      {},
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          selected.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  const ArtifactValidationBindingsV1 validation{
      selected.request.build_identity_digest().digest(),
      selected.request.request_digest().value(),
      selected.provider.identity(),
      selected.provider.manifest().value().parameter_schema_version,
      selected.provider.manifest().scientific_contract_digest().value(),
      selected.contract.construction_method(),
      selected.contract.producer_mode(),
      selected.contract.semantic(),
      selected.contract.runtime_access(),
      selected.contract.payload_class(),
      selected.view.canonical_digest().value(),
      std::move(selection_digest).value(),
      selected.contract.contract_digest(),
      selected.contract.requirements_digest(),
      selected.contract.arrival_capabilities_digest(),
      selected.contract.preview_digest(),
      selected.contract.parameter_digest(),
      selected.contract.budget_digest(),
      selected.contract.structural_manifest().canonical_digest()};
  auto artifact = C15ProtocolFixtureFactory::validated_artifact(
      std::move(source), validation);
  auto payload = adapt_portable_payload(artifact);
  INFO((payload ? std::string{}
                : payload.error().code + ": " + payload.error().message));
  REQUIRE(payload);
  return {std::move(artifact), std::move(payload).value()};
}

[[nodiscard]] inline MaterializationV1 factor_materialization(
    const C16DesignatedScenarioV1& factor) {
  const auto law = designated::object(matrix::kC17DirectFactorLaw);
  const auto validity = designated::object("c17.direct.factor.validity");
  const auto zero = designated::scalar(0, 1);
  const auto one = designated::scalar(1, 1);
  const auto state_zero = designated::label("c17.direct.factor.state.0");
  const auto state_one = designated::label("c17.direct.factor.state.1");
  const auto mark_zero = designated::label("c17.direct.factor.mark.0");
  const auto mark_one = designated::label("c17.direct.factor.mark.1");
  FiniteLawTablesV1 tables{
      1U,
      factor.preview.core.deployed_targets,
      SemanticTagV1::stationary_marked_edge,
      RuntimeAccessTagV1::finite_enumerated_row,
      factor.view.fingerprints().compiled_arrival,
      factor.view.fingerprints().target_selection,
      {{state_zero, {zero}}, {state_one, {one}}},
      {{mark_zero, {zero}}, {mark_one, {one}}},
      StationaryMarkedEdgeTableV1{
          1U,
          law,
          FiniteTableStorageV1::dense,
          {{designated::label("c17.direct.factor.row.0"), state_zero,
            FiniteRowConditioningStageV1::stationary_edge,
            {{state_zero, {mark_zero}, one, std::nullopt}}},
           {designated::label("c17.direct.factor.row.1"), state_one,
            FiniteRowConditioningStageV1::stationary_edge,
            {{state_zero, {mark_one}, one, std::nullopt}}}},
          {"queue.big_nat", 1U},
          {"arrival.phase", 1U},
          {"service.bit", 1U},
          {"queue.big_nat", 1U},
          factor.view.fingerprints().target_selection}};
  return materialization(factor, ArtifactPayloadV1{std::move(tables)},
                         law, validity);
}

[[nodiscard]] inline MaterializationV1 direct_materialization(
    const C16DesignatedScenarioV1& direct) {
  const auto validity = designated::object("c17.direct.validity");
  const auto& clause = direct.contract.structural_manifest().clauses().front();
  DirectMetricValueV1 value{
      designated::object(matrix::kC17DirectValue),
      clause.clause_id,
      clause.ordered_targets,
      designated::scalar(1, 2),
      direct.request.request_digest().value(),
      direct.contract.requirements_digest(),
      direct.view.fingerprints().target_selection,
      direct.view.fingerprints().compiled_arrival,
      direct.contract.contract_digest(),
      clause.selection_domain.kinds,
      clause.arrival_assumptions,
      clause.result_scope,
      DirectMetricValidityBasisV1::exact_finite_enumeration,
      {validity}};
  auto value_digest = artifact::detail::direct_metric_value_digest_v1(value);
  REQUIRE(value_digest);
  value.value_id.object_digest = std::move(value_digest).value();
  const ArtifactObjectReferenceV1 value_identity = value.value_id;
  return materialization(
      direct, ArtifactPayloadV1{DirectMetricPayloadV1{1U, {std::move(value)}}},
      value_identity, validity);
}

[[nodiscard]] inline RealizedMetricBindingsV1 validate_realized(
    const C16DesignatedScenarioV1& selected,
    const MaterializationV1& carried) {
  const auto targets = selected.view.target_selection().ordered_targets;
  auto realized = validate_realized_metric_bindings_v1(
      selected.contract.structural_manifest(),
      RealizedBindingValidationContextV1{
          RealizedBindingTargetContextV1{
              targets, std::optional<QueueId>{targets.front()},
              std::vector<QueueId>(
                  selected.contract.construction_target_scope().begin(),
                  selected.contract.construction_target_scope().end())},
          selected.contract.policies()},
      carried.artifact.value().realized_metric_bindings.bindings);
  INFO((realized ? std::string{}
                 : realized.error().code + ": " +
                       realized.error().message));
  REQUIRE(realized);
  return std::move(realized).value();
}

[[nodiscard]] inline AuditedFrameworkSeedV1 framework_seed(
    const C16DesignatedScenarioV1& selected,
    const PlugDescriptor& descriptor,
    const KernelAccess& access,
    const ExactReducedStateSchemaV1& state_schema,
    const ReducedStateV1& initial_state,
    const std::optional<ExactMetricDecoderDomainV1>& direct_domain =
        std::nullopt) {
  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          selected.view.target_selection().ordered_targets);
  REQUIRE(ordered_target_digest);
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          selected.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  auto access_digest = C17FixtureAccess::canonical_raw_access_identity(access);
  REQUIRE(access_digest);
  AuditedFrameworkBindingsV1 bindings{
      selected.view.fingerprints(),
      selected.view.canonical_digest(),
      state_schema.exact_state_schema_digest,
      state_schema.reduced_state_schema_digest,
      descriptor.descriptor_digest,
      std::move(access_digest).value(),
      selected.contract.contract_digest(),
      selected.contract.requirements_digest(),
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      selected.request.request_digest().value(),
      direct_domain};
  auto initial_mass = ProbabilityMass::exact_rational(
      ExactRational::one(), true);
  REQUIRE(initial_mass);
  const auto domain_validator = state_schema.validate_domain;
  const auto state_codec = state_schema.reduced_state_codec;
  const auto exact_schema_digest = state_schema.exact_state_schema_digest;
  const auto reduced_schema_digest = state_schema.reduced_state_schema_digest;
  const auto selected_law_digest = bindings.selection_digest;
  const auto selection_support = descriptor.core.selection;
  const auto instance_digest = selected.instance.fingerprints().combined;
  return {
      bindings,
      selected.view.target_selection(),
      state_codec,
      selection_support,
      {SelectionKindV1::stationary_unique,
       c17::digest("c17.direct.selection-evidence")},
      [state_codec, exact_schema_digest, reduced_schema_digest,
       selected_law_digest, selection_support, initial_state,
       initial_mass = std::move(initial_mass).value()](
          const SelectionSpec&,
          const std::optional<InitialPhysicalLaw>&) {
        return Result<ReducedInitialLawCandidateV1>::success(
            {state_codec, exact_schema_digest, reduced_schema_digest,
             selected_law_digest, selection_support,
             {{initial_state, initial_mass, std::nullopt}}});
      },
      [instance_digest, exact_schema_digest](
          const ResolvedInstance& instance,
          const Digest256& supplied_schema) {
        if (instance.fingerprints().combined != instance_digest ||
            supplied_schema != exact_schema_digest) {
          return c17::failure<void>(
              "c17.fixture.initial_schema_binding",
              "foreign exact initial-state schema");
        }
        return Result<void>::success();
      },
      domain_validator,
      [domain_validator](std::size_t, const InitialPhysicalAtom&,
                         const ReducedStateV1& reduced) {
        return domain_validator(reduced);
      }};
}

[[nodiscard]] inline ExactReducedStateSchemaV1 state_schema(
    const C16DesignatedScenarioV1& selected,
    const PlugDescriptor& descriptor) {
  const CompiledArrivalLaw configured_arrival = *selected.arrival;
  auto instance_key = make_physical_reference_instance_key(
      selected.instance.fingerprints().combined, BigNat{0U});
  REQUIRE(instance_key);
  auto stream = make_configured_arrival_stream_key(
      configured_arrival,
      derive_rng_stream(MasterSeed{0xC1714U},
                        StageTag::configured_arrival,
                        instance_key.value()));
  REQUIRE(stream);
  auto process = instantiate_arrival_process(
      configured_arrival, ArrivalInitialState{TraceOrigin{}},
      std::move(stream).value());
  REQUIRE(process);
  auto first = next_arrival_step(process.value(), BigNat{0U});
  REQUIRE(first);
  auto result = c17::exact_state_schema(
      selected.instance, selected.view.target_selection().ordered_targets,
      first.value().phase_before, first.value().phase_after);
  const auto departure = std::ranges::find_if(
      descriptor.marks, [](const RuntimeMarkDescriptorV1& mark) {
        return mark.c14_mark.kind == MetricMarkKindV1::actual_departure;
      });
  REQUIRE(departure != descriptor.marks.end());
  result.framework_mark_decoders.emplace_back(
      DeterministicRuntimeMarkDecoderSchemaV1{
          departure->decoder_id, departure->id, departure->decoder_source,
          departure->decoder_input_codec, departure->c14_mark.codec},
      [codec = departure->c14_mark.codec](
          const CanonicalRuntimeValueV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, {std::byte{0x01}}});
      });

  struct SuccessorBacklogMarkBindingV1 final {
    RuntimeMarkIdV1 mark;
    CodecIdentityV1 codec;
  };
  std::vector<SuccessorBacklogMarkBindingV1> successor_backlog_marks;
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::postarrival_state) {
      continue;
    }
    REQUIRE(mark.c14_mark.kind == MetricMarkKindV1::successor_backlog);
    REQUIRE(mark.field_dependencies.empty());
    result.postarrival_mark_decoder.ordered_mark_schemas.push_back(
        {mark.decoder_id, mark.id, mark.decoder_source,
         mark.decoder_input_codec, mark.c14_mark.codec});
    successor_backlog_marks.push_back({mark.id, mark.c14_mark.codec});
  }
  if (!successor_backlog_marks.empty()) {
    result.postarrival_mark_decoder.decode =
        [successor_backlog_marks](
            const ExactReducedCoordinatesV1&,
            const ExactReducedCoordinatesV1& after,
            const ResolvedAction&, const ArrivalTransition&)
        -> Result<std::vector<RuntimeDecodedMarkV1>> {
      if (after.backlog.values().empty() ||
          after.backlog.values().front().bit_length() > 8U) {
        return c17::failure<std::vector<RuntimeDecodedMarkV1>>(
            "c17.fixture.successor_backlog_mark",
            "the exact successor backlog is outside the fixture codec");
      }
      const std::byte encoded = static_cast<std::byte>(
          after.backlog.values().front().value().convert_to<std::uint8_t>());
      std::vector<RuntimeDecodedMarkV1> decoded;
      decoded.reserve(successor_backlog_marks.size());
      for (const SuccessorBacklogMarkBindingV1& binding :
           successor_backlog_marks) {
        decoded.push_back({binding.mark, {binding.codec, {encoded}}});
      }
      return Result<std::vector<RuntimeDecodedMarkV1>>::success(
          std::move(decoded));
    };
  }
  return result;
}

[[nodiscard]] inline DirectScenarioV1 make_scenarios() {
  auto source = direct_input();
  REQUIRE(metric_request_header(source.request).solver_regime ==
          MetricSolverRegimeV1::direct);
  auto factor = scenario(
      profile(SemanticTagV1::stationary_marked_edge), source,
      BackendRouteKindV1::finite_temporal_cylinder,
      SolverRegimeV1::analytic);
  auto direct = scenario(
      profile(SemanticTagV1::direct_metric_decoder), source,
      BackendRouteKindV1::exact_direct, SolverRegimeV1::direct);
  REQUIRE(factor.view.fingerprints() == direct.view.fingerprints());
  REQUIRE(factor.view.canonical_digest() == direct.view.canonical_digest());
  auto carried = direct_materialization(direct);
  return {std::move(factor), std::move(direct), std::move(carried)};
}

[[nodiscard]] inline FactorRecipeV1 make_factor_recipe(
    const C16DesignatedScenarioV1& direct,
    const MaterializationV1& carried) {
  auto raw = matrix::c17_direct_factor_fixture_candidate(
      carried.payload, direct.contract);
  INFO((raw ? std::string{}
            : raw.error().code + ": " + raw.error().message));
  REQUIRE(raw);
  const PlugDescriptor descriptor = raw.value().descriptor;
  const KernelAccess factor_access = kernel_access_v1(raw.value().plug);
  auto exact_schema = state_schema(direct, descriptor);
  const std::vector<QueueId> targets(
      direct.view.target_selection().ordered_targets.begin(),
      direct.view.target_selection().ordered_targets.end());
  const ReducedStateV1 initial = c17::reduced_state(targets, {1U});
  OptimizerFreeFrameworkCandidateInputsV1 inputs{
      direct.request.build_identity_digest(),
      direct.request.request_digest().value(),
      direct.instance,
      *direct.arrival,
      direct.contract,
      validate_realized(direct, carried),
      exact_schema,
      {ExactCausalProgramModeV1::generic_bound_operations,
       physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(),
       {initial}},
      framework_seed(direct, descriptor, factor_access, exact_schema,
                     initial)};
  RuntimeDirectFactorRecipeV1 recipe(
      std::move(raw).value(), std::move(inputs));
  return {std::move(recipe), std::move(exact_schema), initial};
}

[[nodiscard]] inline FactorFrameworkV1 make_factor_framework(
    const C16DesignatedScenarioV1& factor) {
  auto carried = factor_materialization(factor);
  auto plug = materialize_and_validate_surrogate_plug(
      carried.payload, carried.artifact, factor.contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  const PlugDescriptor descriptor = plug.value().descriptor();
  auto exact_schema = state_schema(factor, descriptor);
  const std::vector<QueueId> targets(
      factor.view.target_selection().ordered_targets.begin(),
      factor.view.target_selection().ordered_targets.end());
  const ReducedStateV1 initial = c17::reduced_state(targets, {1U});
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      factor.instance, BigNat{0U});
  REQUIRE(optimizer);
  CompiledFrameworkCandidateInputsV1 inputs{
      factor.request.build_identity_digest(),
      factor.request.request_digest().value(),
      factor.instance,
      *factor.arrival,
      factor.contract,
      validate_realized(factor, carried),
      exact_schema,
      {ExactCausalProgramModeV1::generic_bound_operations,
       physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(),
       {initial}},
      std::nullopt,
      std::move(optimizer).value(),
      framework_seed(factor, descriptor, access.value(), exact_schema,
                     initial)};
  auto candidate = C17FixtureAccess::make_candidate(
      std::move(plug).value(), std::move(inputs));
  auto framework = audit_v0_causality(
      std::move(candidate), descriptor, std::move(access).value());
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(), factor.instance, targets,
          std::move(exact_schema), initial};
}

[[nodiscard]] inline DirectMetricRequestDomainV1 direct_domain(
    const C16DesignatedScenarioV1& direct,
    const RawDirectDecoderDomainV1& raw) {
  const auto& clause = direct.contract.requirements().clauses().front();
  return {raw.metric_domain,
          direct.contract.requirements_digest(),
          raw.canonical_request_domain_digest,
          clause.origin.ordered_targets,
          raw.ordered_target_digest,
          raw.selection_digest,
          clause.origin.selection_regime,
          raw.result_codec};
}

[[nodiscard]] inline PreparedDirectCandidateV1 prepare_direct_candidate(
    const C16DesignatedScenarioV1& direct,
    const MaterializationV1& carried,
    const ExactReducedStateSchemaV1& exact_schema,
    const ReducedStateV1& initial_state,
    RuntimeDirectFactorRecipeV1 factor_recipe,
    std::optional<KernelAccess> replacement_direct_access = std::nullopt) {
  auto plug = materialize_and_validate_surrogate_plug(
      carried.payload, carried.artifact, direct.contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  const PlugDescriptor descriptor = plug.value().descriptor();
  KernelAccess selected_access = replacement_direct_access.has_value()
                                     ? std::move(*replacement_direct_access)
                                     : std::move(access).value();
  const auto* raw =
      std::get_if<RawDirectDecoderAccess>(&selected_access);
  REQUIRE(raw != nullptr);
  const auto sealed_domain = direct_domain(direct, raw->domain());
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      direct.instance, BigNat{0U});
  REQUIRE(optimizer);
  auto observer = optimizer.value().ledger_observer();
  OptimizerFreeFrameworkCandidateInputsV1 inputs{
      direct.request.build_identity_digest(),
      direct.request.request_digest().value(),
      direct.instance,
      *direct.arrival,
      direct.contract,
      validate_realized(direct, carried),
      exact_schema,
      {ExactCausalProgramModeV1::bound_direct_decoder,
       physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(), {}},
      framework_seed(direct, descriptor, selected_access, exact_schema,
                     initial_state, raw->domain().metric_domain)};
  RuntimeDirectMetricActivationV1 activation(
      sealed_domain, std::move(factor_recipe));
  auto candidate = C17AuditedFrameworkMint::make_direct_composite_candidate(
      std::move(plug).value(), std::move(selected_access),
      std::move(inputs), std::move(activation),
      std::move(optimizer).value(), BigNat{0U});
  return {std::move(candidate), std::move(observer)};
}

[[nodiscard]] inline KernelAccess fresh_direct_access(
    const C16DesignatedScenarioV1& direct,
    const MaterializationV1& carried) {
  auto plug = materialize_and_validate_surrogate_plug(
      carried.payload, carried.artifact, direct.contract);
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  return std::move(access).value();
}

}  // namespace mwperf::testing::c17_direct
