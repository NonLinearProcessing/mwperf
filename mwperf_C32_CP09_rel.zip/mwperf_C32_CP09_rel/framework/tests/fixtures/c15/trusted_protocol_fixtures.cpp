#include "fixtures/c15/trusted_protocol_fixtures.hpp"

#include <memory>
#include <span>
#include <string_view>

#include "mwperf/core/sha256.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"

namespace mwperf::testing {
namespace {

[[nodiscard]] Digest256 bytes_digest(const std::span<const std::byte> bytes) {
  const auto result = digest_surrogate_parameter_values_v1(bytes);
  // Test fixture inputs are canonical JSON and deliberately tiny.  There is
  // no recovery path if a fixture author breaks that invariant.
  return result.value();
}

[[nodiscard]] Digest256 fixture_digest(const std::string_view text) {
  const auto bytes =
      std::as_bytes(std::span<const char>(text.data(), text.size()));
  return sha256(bytes).value();
}

}  // namespace

SurrogateBuildRequest C15ProtocolFixtureFactory::rebuild_request(
    const SurrogateBuildRequest& request,
    BuildIdentityDigest build_identity_digest,
    SurrogateBuildRequestDigest request_digest, FrameworkProblemView view,
    BuildSeed seed) {
  return SurrogateBuildRequest(
      request.protocol_version(), std::move(build_identity_digest),
      std::move(request_digest), request.provider_binding(),
      request.classifications(), std::move(view),
      request.accepted_capability_contract(),
      std::vector<std::byte>(request.validated_parameters().begin(),
                             request.validated_parameters().end()),
      request.construction_budget(), std::move(seed),
      request.required_build_report_schema());
}

SurrogateBuildRequest C15ProtocolFixtureFactory::with_provider_binding(
    const SurrogateBuildRequest& request, BuildProviderBindingV1 binding) {
  return SurrogateBuildRequest(
      request.protocol_version(), request.build_identity_digest(),
      request.request_digest(), std::move(binding), request.classifications(),
      request.framework_problem_view(), request.accepted_capability_contract(),
      std::vector<std::byte>(request.validated_parameters().begin(),
                             request.validated_parameters().end()),
      request.construction_budget(), request.build_seed(),
      request.required_build_report_schema());
}

AcceptedCapabilityContract C15ProtocolFixtureFactory::rebuild_contract(
    const AcceptedCapabilityContract& contract,
    std::vector<QueueId> construction_target_scope,
    PreviewPoliciesV1 policies) {
  return AcceptedCapabilityContract(
      contract.schema_version(), contract.provider(),
      contract.construction_method(), contract.producer_mode(),
      contract.payload_class(), contract.semantic(), contract.runtime_access(),
      contract.descriptor_core(), contract.structural_manifest(),
      contract.requirements(), contract.arrival_capabilities(),
      std::vector<ResolvedMetricContractV1>(
          contract.metric_contracts().begin(),
          contract.metric_contracts().end()),
      std::move(construction_target_scope), std::move(policies),
      contract.construction_prerequisites(), contract.requirements_digest(),
      contract.arrival_capabilities_digest(), contract.preview_digest(),
      contract.parameter_digest(), contract.budget_digest(),
      contract.contract_digest());
}

ValidatedSurrogateParameters
C15ProtocolFixtureFactory::validated_parameters(
    ProviderIdentityV1 provider, const std::uint32_t parameter_schema_version,
    Digest256 parameter_schema_digest,
    std::vector<std::byte> canonical_value_bytes,
    std::optional<Digest256> forced_digest) {
  Digest256 digest = forced_digest.has_value()
                         ? std::move(*forced_digest)
                         : bytes_digest(canonical_value_bytes);
  return ValidatedSurrogateParameters(
      std::move(provider), parameter_schema_version,
      std::move(parameter_schema_digest),
      std::move(canonical_value_bytes), std::move(digest), {});
}

ValidatedSurrogateBuildReport
C15ProtocolFixtureFactory::validated_build_report(CommonBuildReportV1 report) {
  return ValidatedSurrogateBuildReport(std::move(report));
}

RawResponseProductId C15ProtocolFixtureFactory::raw_response_product_id(
    ArtifactObjectReferenceV1 identity) {
  return RawResponseProductId(std::move(identity));
}

NominalResponseProductId
C15ProtocolFixtureFactory::nominal_response_product_id(
    ArtifactObjectReferenceV1 identity) {
  return NominalResponseProductId(std::move(identity));
}

ProjectionCenterProductId
C15ProtocolFixtureFactory::projection_center_product_id(
    ArtifactObjectReferenceV1 identity) {
  return ProjectionCenterProductId(std::move(identity));
}

ProjectedMeanProductId
C15ProtocolFixtureFactory::projected_mean_product_id(
    ArtifactObjectReferenceV1 identity) {
  return ProjectedMeanProductId(std::move(identity));
}

RecodedResponseProductId
C15ProtocolFixtureFactory::recoded_response_product_id(
    ArtifactObjectReferenceV1 identity) {
  return RecodedResponseProductId(std::move(identity));
}

ValidatedSurrogateArtifact C15ProtocolFixtureFactory::validated_artifact(
    SurrogateArtifactV1 artifact,
    std::optional<ArtifactValidationBindingsV1> validation_bindings) {
  if (!validation_bindings.has_value()) {
    validation_bindings = ArtifactValidationBindingsV1{
        fixture_digest("c15.fixture.build-identity"),
        artifact.request_digest,
        artifact.provider,
        1U,
        artifact.provider_scientific_contract_digest,
        artifact.construction_method,
        artifact.producer_mode,
        artifact.deployed_semantic,
        artifact.runtime_access,
        artifact.payload_class,
        fixture_digest("c15.fixture.problem-view"),
        fixture_digest("c15.fixture.analysis-selection"),
        fixture_digest("c15.fixture.accepted-contract"),
        fixture_digest("c15.fixture.requirements"),
        fixture_digest("c15.fixture.arrival-capabilities"),
        fixture_digest("c15.fixture.preview"),
        fixture_digest("c15.fixture.parameters"),
        fixture_digest("c15.fixture.budget"),
        artifact.structural_manifest_echo.manifest_digest};
  }
  return ValidatedSurrogateArtifact(std::move(artifact),
                                    std::move(*validation_bindings));
}

ValidatedBuiltResultV1 C15ProtocolFixtureFactory::validated_built_result(
    ValidatedSurrogateArtifact artifact) {
  return ValidatedBuiltResultV1(std::move(artifact));
}

ValidatedSurrogateBuildResult C15ProtocolFixtureFactory::validated_result(
    ValidatedSurrogateBuildResultValueV1 value,
    MetricRequirements accepted_requirements) {
  return ValidatedSurrogateBuildResult(std::move(value),
                                       std::move(accepted_requirements));
}

PortablePlugPayload C15ProtocolFixtureFactory::portable_payload(
    PortablePlugPayloadValueV1 value) {
  return PortablePlugPayload(std::move(value));
}

SurrogateBuildRequest C15ProtocolFixtureFactory::with_build_identity_digest(
    const SurrogateBuildRequest& request, BuildIdentityDigest digest) {
  return C15ProtocolFixtureFactory::rebuild_request(
      request, std::move(digest), request.request_digest(),
      request.framework_problem_view(), request.build_seed());
}

SurrogateBuildRequest C15ProtocolFixtureFactory::with_request_digest(
    const SurrogateBuildRequest& request,
    SurrogateBuildRequestDigest digest) {
  return C15ProtocolFixtureFactory::rebuild_request(
      request, request.build_identity_digest(), std::move(digest),
      request.framework_problem_view(), request.build_seed());
}

SurrogateBuildRequest C15ProtocolFixtureFactory::with_build_seed(
    const SurrogateBuildRequest& request, BuildSeed seed) {
  return C15ProtocolFixtureFactory::rebuild_request(
      request, request.build_identity_digest(), request.request_digest(),
      request.framework_problem_view(), std::move(seed));
}

SurrogateBuildRequest C15ProtocolFixtureFactory::with_problem_view(
    const SurrogateBuildRequest& request, FrameworkProblemView view) {
  return C15ProtocolFixtureFactory::rebuild_request(
      request, request.build_identity_digest(), request.request_digest(),
      std::move(view), request.build_seed());
}

FrameworkProblemView C15ProtocolFixtureFactory::with_problem_view_digest(
    const FrameworkProblemView& view, FrameworkProblemViewDigest digest) {
  return FrameworkProblemView(
      view.schema_version(), view.fingerprints(),
      std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                        view.queues().end()),
      view.target_selection(), view.applicability_key(),
      view.constraint_geometry(),
      std::vector<QueueId>(view.priority_order().begin(),
                           view.priority_order().end()),
      view.timing(), view.configured_arrival(), view.analysis_selection(),
      view.initial_predictive_law(), view.units_and_encodings(),
      std::move(digest));
}

FrameworkProblemView C15ProtocolFixtureFactory::with_target_selection(
    const FrameworkProblemView& view, TargetSelection targets) {
  return FrameworkProblemView(
      view.schema_version(), view.fingerprints(),
      std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                        view.queues().end()),
      std::move(targets), view.applicability_key(),
      view.constraint_geometry(),
      std::vector<QueueId>(view.priority_order().begin(),
                           view.priority_order().end()),
      view.timing(), view.configured_arrival(), view.analysis_selection(),
      view.initial_predictive_law(), view.units_and_encodings(),
      view.canonical_digest());
}

FrameworkProblemView C15ProtocolFixtureFactory::with_constraint_geometry(
    const FrameworkProblemView& view,
    SchedulerConstraintPairV1 applicability_key,
    PortableConstraintGeometryV1 constraint_geometry) {
  // This seam is used only by the narrow five-geometry structural predicate.
  // That predicate intentionally does not consume the view digest.  Whole-view
  // digest tests construct their views through F-C15-02 instead.
  return FrameworkProblemView(
      view.schema_version(), view.fingerprints(),
      std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                        view.queues().end()),
      view.target_selection(), std::move(applicability_key),
      std::move(constraint_geometry),
      std::vector<QueueId>(view.priority_order().begin(),
                           view.priority_order().end()),
      view.timing(), view.configured_arrival(), view.analysis_selection(),
      view.initial_predictive_law(), view.units_and_encodings(),
      view.canonical_digest());
}

FrameworkProblemView C15ProtocolFixtureFactory::with_configured_arrival(
    const FrameworkProblemView& view, BuilderArrivalView arrival) {
  FrameworkProblemFingerprintsV1 fingerprints = view.fingerprints();
  fingerprints.compiled_arrival = arrival.digest().value();
  FrameworkProblemView provisional(
      view.schema_version(), fingerprints,
      std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                        view.queues().end()),
      view.target_selection(), view.applicability_key(),
      view.constraint_geometry(),
      std::vector<QueueId>(view.priority_order().begin(),
                           view.priority_order().end()),
      view.timing(), std::move(arrival), view.analysis_selection(),
      view.initial_predictive_law(), view.units_and_encodings(),
      view.canonical_digest());
  auto digest =
      artifact::detail::canonical_framework_problem_view_digest_v1(
          provisional);
  return FrameworkProblemView(
      provisional.schema_version(), provisional.fingerprints(),
      std::vector<PortableQueueEntryV1>(provisional.queues().begin(),
                                        provisional.queues().end()),
      provisional.target_selection(), provisional.applicability_key(),
      provisional.constraint_geometry(),
      std::vector<QueueId>(provisional.priority_order().begin(),
                           provisional.priority_order().end()),
      provisional.timing(), provisional.configured_arrival(),
      provisional.analysis_selection(), provisional.initial_predictive_law(),
      provisional.units_and_encodings(), std::move(digest).value());
}

AcceptedCapabilityContract
C15ProtocolFixtureFactory::with_construction_scope(
    const AcceptedCapabilityContract& contract,
    std::vector<QueueId> construction_target_scope) {
  return C15ProtocolFixtureFactory::rebuild_contract(
      contract, std::move(construction_target_scope), contract.policies());
}

AcceptedCapabilityContract C15ProtocolFixtureFactory::with_policies(
    const AcceptedCapabilityContract& contract, PreviewPoliciesV1 policies) {
  return C15ProtocolFixtureFactory::rebuild_contract(
      contract,
      std::vector<QueueId>(contract.construction_target_scope().begin(),
                           contract.construction_target_scope().end()),
      std::move(policies));
}

AcceptedCapabilityContract C15ProtocolFixtureFactory::accepted_contract(
    const SurrogateProviderManifestV1& provider_manifest,
    PlugDescriptorCore descriptor, MetricSupportManifest structural_manifest,
    MetricRequirements requirements, ArrivalCapabilities arrival_capabilities,
    std::vector<ResolvedMetricContractV1> metric_contracts,
    std::vector<QueueId> construction_target_scope,
    PreviewPoliciesV1 policies,
    ConstructionPrerequisitesV1 construction_prerequisites,
    Digest256 problem_view_digest, Digest256 parameter_digest,
    Digest256 budget_digest) {
  const auto requirements_digest =
      canonical_metric_requirements_digest(requirements);
  const auto arrival_digest =
      canonical_arrival_capabilities_digest_v1(arrival_capabilities);
  auto manifest_owner =
      std::make_shared<const MetricSupportManifest>(structural_manifest);
  PlugDescriptorPreview preview{
      1U,
      descriptor,
      provider_manifest.construction_method,
      provider_manifest.producer_mode,
      construction_target_scope,
      policies,
      construction_prerequisites,
      std::move(manifest_owner),
      problem_view_digest,
      parameter_digest,
      budget_digest,
      fixture_digest("c15.fixture.preview.placeholder")};
  const auto preview_digest =
      canonical_plug_descriptor_preview_digest_v1(preview);
  return AcceptedCapabilityContract(
      1U, provider_manifest.provider, provider_manifest.construction_method,
      provider_manifest.producer_mode, provider_manifest.payload_class,
      provider_manifest.deployed_semantic_tag,
      provider_manifest.runtime_access_tag, std::move(descriptor),
      std::move(structural_manifest), std::move(requirements),
      std::move(arrival_capabilities), std::move(metric_contracts),
      std::move(construction_target_scope), std::move(policies),
      std::move(construction_prerequisites), requirements_digest.value(),
      arrival_digest.value(), preview_digest.value(),
      std::move(parameter_digest),
      std::move(budget_digest),
      fixture_digest("c15.fixture.contract"));
}

}  // namespace mwperf::testing
