#pragma once

#if !defined(MWPERF_C15_TEST_SEAMS)
#error "C15GoldenSourceV1 is C15 test support only"
#endif

#include <string>
#include <vector>

#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::testing {

// An exact, authenticated source for checked-in C15 wire goldens.  The Built
// branch has crossed the canonical wire parser and F06, and portable_payload
// is the corresponding F07/F08 result.  Keeping this bridge in test support
// prevents the golden emitter from manufacturing privileged validated values.
struct C15GoldenSourceV1 final {
  std::string name;
  BuiltSurrogateResultV1 source_built;
  PortablePlugPayloadValueV1 portable_payload;
};

[[nodiscard]] std::vector<C15GoldenSourceV1>
make_non_three_c15_golden_sources_v1();

[[nodiscard]] std::vector<C15GoldenSourceV1>
make_finite_table_c15_golden_sources_v1();

[[nodiscard]] C15GoldenSourceV1
make_response_envelope_optimizer_interval_raw_c15_golden_source_v1();

[[nodiscard]] C15GoldenSourceV1
make_response_envelope_physical_bound_c15_golden_source_v1();

[[nodiscard]] C15GoldenSourceV1
make_stopped_path_explicit_words_c15_golden_source_v1();

[[nodiscard]] C15GoldenSourceV1
make_romr_residence_predictive_tables_c15_golden_source_v1();

[[nodiscard]] C15GoldenSourceV1 make_three_bin_c15_golden_source_v1();

}  // namespace mwperf::testing
