#include "fixtures/c15/mode_erased_law_projection.hpp"

#include <algorithm>
#include <string>
#include <type_traits>
#include <utility>

namespace mwperf::testing {
namespace {

[[nodiscard]] Diagnostic projection_error(std::string code,
                                          std::string message) {
  return Diagnostic{DiagnosticCategory::internal, std::move(code),
                    std::move(message), std::nullopt, std::nullopt, {}};
}

[[nodiscard]] ExactRational exact_scalar_value(
    const PortableScientificScalar& value) {
  return value.kind() == PortableScientificScalarKind::rational
             ? value.rational_value()
             : binary64_as_exact_rational(value);
}

[[nodiscard]] const ResponseCoefficientTripleV1* deployed_coefficients(
    const ThreeBinScalarResponseV1& payload) {
  return std::visit(
      [&payload](const auto& selected) -> const ResponseCoefficientTripleV1* {
        using Selected = std::decay_t<decltype(selected)>;
        if constexpr (std::is_same_v<Selected, RawResponseProductId>) {
          return nullptr;
        } else if constexpr (std::is_same_v<Selected,
                                            NominalResponseProductId>) {
          return payload.nominal_response.has_value() &&
                         payload.nominal_response->product_id == selected
                     ? &payload.nominal_response->coefficients
                     : nullptr;
        } else {
          return payload.recoded_response.has_value() &&
                         payload.recoded_response->product_id == selected
                     ? &payload.recoded_response->coefficients
                     : nullptr;
        }
      },
      payload.deployed_response_product_id);
}

[[nodiscard]] Result<std::array<ExactRational, 4U>> law_parameters(
    const ThreeBinScalarResponseV1& payload) {
  std::array<ExactRational, 4U> result{
      ExactRational::zero(), ExactRational::zero(), ExactRational::zero(),
      ExactRational::zero()};
  if (const auto* coefficients = deployed_coefficients(payload);
      coefficients != nullptr) {
    for (std::size_t index = 0U; index < coefficients->size(); ++index) {
      if ((*coefficients)[index].bin !=
          static_cast<ThreeBinCoefficientV1>(index)) {
        return Result<std::array<ExactRational, 4U>>::failure(
            projection_error(
                "mode_erased_noncanonical_bins",
                "the deployed three-bin response is not in protocol bin "
                "order"));
      }
      result[index + 1U] = exact_scalar_value((*coefficients)[index].value);
    }
    return Result<std::array<ExactRational, 4U>>::success(std::move(result));
  }

  const auto* raw = std::get_if<RawResponseProductId>(
      &payload.deployed_response_product_id);
  if (raw == nullptr || payload.raw_response.product_id != *raw) {
    return Result<std::array<ExactRational, 4U>>::failure(projection_error(
        "mode_erased_missing_deployed_product",
        "the selected response product is absent"));
  }
  for (std::size_t index = 0U;
       index < payload.raw_response.identifications.size(); ++index) {
    const auto& identification = payload.raw_response.identifications[index];
    if (identification.target_bin_binding !=
            static_cast<ThreeBinCoefficientV1>(index) ||
        !identification.raw_point.has_value()) {
      return Result<std::array<ExactRational, 4U>>::failure(
          projection_error(
              "mode_erased_raw_product_not_point",
              "the selected raw response is not a complete point product"));
    }
    result[index + 1U] = exact_scalar_value(*identification.raw_point);
  }
  return Result<std::array<ExactRational, 4U>>::success(std::move(result));
}

[[nodiscard]] ConfiguredArrivalCompositionV1 arrival_composition(
    const FrameworkProblemView& view,
    const PlugDescriptorCore& descriptor) {
  (void)view;
  return descriptor.phase.arrival_composition;
}

}  // namespace

Result<ModeErasedLawProjectionV1> make_mode_erased_law_projection_v1(
    const ValidatedSurrogateArtifact& validated_artifact,
    const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& accepted_contract) {
  const auto& artifact = validated_artifact.value();
  const auto* response =
      std::get_if<ThreeBinScalarResponseV1>(&artifact.payload);
  if (response == nullptr) {
    return Result<ModeErasedLawProjectionV1>::failure(projection_error(
        "mode_erased_payload_not_three_bin",
        "the version-1 test projection supports the audited three-bin law"));
  }
  auto parameters = law_parameters(*response);
  if (!parameters) {
    return Result<ModeErasedLawProjectionV1>::failure(parameters.error());
  }

  std::vector<MetricRevealStageV1> reveal_stages;
  reveal_stages.reserve(artifact.deployed_descriptor.marks.size());
  for (const auto& mark : artifact.deployed_descriptor.marks) {
    reveal_stages.push_back(mark.reveal_stage);
  }

  std::vector<MetricResultScopeV1> result_scopes;
  std::vector<ModeErasedMetricKindAndParametersV1> metrics;
  std::vector<ModeErasedConditioningConventionV1> conditioning;
  result_scopes.reserve(
      accepted_contract.structural_manifest().clauses().size());
  metrics.reserve(accepted_contract.structural_manifest().clauses().size());
  conditioning.reserve(
      accepted_contract.structural_manifest().clauses().size());
  for (const auto& clause :
       accepted_contract.structural_manifest().clauses()) {
    std::vector<MetricRequestParametersV1> parameters_for_metric;
    std::visit(
        [&parameters_for_metric](const auto& domain) {
          using Domain = std::decay_t<decltype(domain)>;
          if constexpr (std::is_same_v<Domain,
                                       ExactMetricParameterSetV1>) {
            parameters_for_metric = domain.values;
          } else {
            parameters_for_metric.push_back(domain.exact_parameters);
          }
        },
        clause.parameter_domain);
    metrics.push_back(
        {clause.metric_kind, std::move(parameters_for_metric)});

    std::vector<StateFieldKindV1> state_fields;
    state_fields.reserve(clause.state_fields.size());
    for (const auto& state_field : clause.state_fields) {
      state_fields.push_back(state_field.kind);
    }
    conditioning.push_back(
        {clause.target_coupling, std::move(state_fields),
         clause.phase_domain.payload_phase,
         clause.phase_domain.arrival_composition,
         clause.phase_domain.retains_configured_predictive_phase,
         clause.arrival_assumptions, clause.hypotheses});
    result_scopes.push_back(clause.result_scope);
  }

  const FrameworkProblemView& view = request.framework_problem_view();
  const auto& configured = view.configured_arrival().configured_law();
  return Result<ModeErasedLawProjectionV1>::success(
      ModeErasedLawProjectionV1{
      1U,
      {artifact.payload_class.tag,
       artifact.payload_class.version,
       artifact.deployed_semantic,
       ModeErasedStateDomainV1::nonnegative_integer_singleton_backlog,
       ModeErasedTargetConventionV1::selected_target_relative_three_bins,
       std::move(parameters).value(),
       ModeErasedServiceRandomizationV1::
           independent_fresh_uniform_given_current_backlog},
      {configured.schema, configured.canonical_data,
       arrival_composition(view, artifact.deployed_descriptor),
       view.initial_predictive_law()},
      {view.timing(), std::move(reveal_stages)},
      {std::move(metrics), std::move(conditioning),
       view.analysis_selection(), std::move(result_scopes)}});
}

}  // namespace mwperf::testing
