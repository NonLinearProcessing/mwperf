#pragma once

#if !defined(MWPERF_C15_TEST_SEAMS)
#error "C15 trusted protocol fixtures are test-only"
#endif

#include <cstdint>
#include <optional>
#include <utility>
#include <vector>

#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf::testing {

// All methods in this authority are linked only into mwperf_tests.  Production
// code merely forward-friends the incomplete class, so none of these trusted
// constructors is part of an installed or runtime surface.
class C15ProtocolFixtureFactory final {
 public:
  C15ProtocolFixtureFactory() = delete;

  [[nodiscard]] static ValidatedSurrogateParameters validated_parameters(
      ProviderIdentityV1 provider, std::uint32_t parameter_schema_version,
      Digest256 parameter_schema_digest,
      std::vector<std::byte> canonical_value_bytes,
      std::optional<Digest256> forced_digest = std::nullopt);

  [[nodiscard]] static ValidatedSurrogateBuildReport validated_build_report(
      CommonBuildReportV1 report);

  [[nodiscard]] static RawResponseProductId raw_response_product_id(
      ArtifactObjectReferenceV1 identity);
  [[nodiscard]] static NominalResponseProductId nominal_response_product_id(
      ArtifactObjectReferenceV1 identity);
  [[nodiscard]] static ProjectionCenterProductId projection_center_product_id(
      ArtifactObjectReferenceV1 identity);
  [[nodiscard]] static ProjectedMeanProductId projected_mean_product_id(
      ArtifactObjectReferenceV1 identity);
  [[nodiscard]] static RecodedResponseProductId recoded_response_product_id(
      ArtifactObjectReferenceV1 identity);

  [[nodiscard]] static ValidatedSurrogateArtifact validated_artifact(
      SurrogateArtifactV1 artifact,
      std::optional<ArtifactValidationBindingsV1> validation_bindings =
          std::nullopt);
  [[nodiscard]] static ValidatedBuiltResultV1 validated_built_result(
      ValidatedSurrogateArtifact artifact);
  [[nodiscard]] static ValidatedSurrogateBuildResult validated_result(
      ValidatedSurrogateBuildResultValueV1 value,
      MetricRequirements accepted_requirements);
  [[nodiscard]] static PortablePlugPayload portable_payload(
      PortablePlugPayloadValueV1 value);

  [[nodiscard]] static SurrogateBuildRequest with_build_identity_digest(
      const SurrogateBuildRequest& request, BuildIdentityDigest digest);
  [[nodiscard]] static SurrogateBuildRequest with_request_digest(
      const SurrogateBuildRequest& request,
      SurrogateBuildRequestDigest digest);
  [[nodiscard]] static SurrogateBuildRequest with_build_seed(
      const SurrogateBuildRequest& request, BuildSeed seed);
  [[nodiscard]] static SurrogateBuildRequest with_provider_binding(
      const SurrogateBuildRequest& request, BuildProviderBindingV1 binding);
  [[nodiscard]] static SurrogateBuildRequest with_problem_view(
      const SurrogateBuildRequest& request, FrameworkProblemView view);

  [[nodiscard]] static FrameworkProblemView with_problem_view_digest(
      const FrameworkProblemView& view, FrameworkProblemViewDigest digest);
  [[nodiscard]] static FrameworkProblemView with_target_selection(
      const FrameworkProblemView& view, TargetSelection targets);
  [[nodiscard]] static FrameworkProblemView with_constraint_geometry(
      const FrameworkProblemView& view,
      SchedulerConstraintPairV1 applicability_key,
      PortableConstraintGeometryV1 constraint_geometry);
  [[nodiscard]] static FrameworkProblemView with_configured_arrival(
      const FrameworkProblemView& view, BuilderArrivalView arrival);

  [[nodiscard]] static AcceptedCapabilityContract with_construction_scope(
      const AcceptedCapabilityContract& contract,
      std::vector<QueueId> construction_target_scope);
  [[nodiscard]] static AcceptedCapabilityContract with_policies(
      const AcceptedCapabilityContract& contract, PreviewPoliciesV1 policies);
  [[nodiscard]] static AcceptedCapabilityContract accepted_contract(
      const SurrogateProviderManifestV1& provider_manifest,
      PlugDescriptorCore descriptor, MetricSupportManifest structural_manifest,
      MetricRequirements requirements, ArrivalCapabilities arrival_capabilities,
      std::vector<ResolvedMetricContractV1> metric_contracts,
      std::vector<QueueId> construction_target_scope,
      PreviewPoliciesV1 policies,
      ConstructionPrerequisitesV1 construction_prerequisites,
      Digest256 problem_view_digest, Digest256 parameter_digest,
      Digest256 budget_digest);

 private:
  [[nodiscard]] static SurrogateBuildRequest rebuild_request(
      const SurrogateBuildRequest& request,
      BuildIdentityDigest build_identity_digest,
      SurrogateBuildRequestDigest request_digest, FrameworkProblemView view,
      BuildSeed seed);
  [[nodiscard]] static AcceptedCapabilityContract rebuild_contract(
      const AcceptedCapabilityContract& contract,
      std::vector<QueueId> construction_target_scope,
      PreviewPoliciesV1 policies);
};

}  // namespace mwperf::testing
