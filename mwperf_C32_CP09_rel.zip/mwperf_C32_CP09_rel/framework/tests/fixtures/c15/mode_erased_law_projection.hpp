#pragma once

#if !defined(MWPERF_C15_TEST_SEAMS)
#error "ModeErasedLawProjectionV1 is C15 test support only"
#endif

#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf::testing {

enum class ModeErasedStateDomainV1 : std::uint8_t {
  nonnegative_integer_singleton_backlog,
};

enum class ModeErasedTargetConventionV1 : std::uint8_t {
  selected_target_relative_three_bins,
};

enum class ModeErasedServiceRandomizationV1 : std::uint8_t {
  independent_fresh_uniform_given_current_backlog,
};

struct ModeErasedDeployedLawV1 final {
  PayloadClassTagV1 payload_family_tag;
  std::uint32_t payload_family_version;
  SemanticTagV1 semantic_tag;
  ModeErasedStateDomainV1 mathematical_state_domain;
  ModeErasedTargetConventionV1 target_relative_state_and_mark_convention;
  // Protocol order is mu(0), s1, s2, c.  mu(0) is always exact zero.
  std::array<ExactRational, 4U> canonical_law_parameters;
  ModeErasedServiceRandomizationV1 service_randomization_convention;

  friend bool operator==(const ModeErasedDeployedLawV1&,
                         const ModeErasedDeployedLawV1&) = default;
};

struct ModeErasedConfiguredArrivalMathV1 final {
  PortableArrivalLawSchema arrival_family_tag;
  std::vector<std::byte> canonical_joint_law_or_recipe;
  ConfiguredArrivalCompositionV1 predictive_phase_semantics;
  std::optional<PortableInitialPredictiveLawV1>
      initial_predictive_state_law;

  friend bool operator==(const ModeErasedConfiguredArrivalMathV1&,
                         const ModeErasedConfiguredArrivalMathV1&) = default;
};

struct ModeErasedTimingConventionV1 final {
  TimingConvention decision_service_arrival_order;
  std::vector<MetricRevealStageV1> observation_and_reveal_stages;

  friend bool operator==(const ModeErasedTimingConventionV1&,
                         const ModeErasedTimingConventionV1&) = default;
};

struct ModeErasedMetricKindAndParametersV1 final {
  MetricKindV1 metric_kind;
  std::vector<MetricRequestParametersV1> normalized_parameters;

  friend bool operator==(const ModeErasedMetricKindAndParametersV1&,
                         const ModeErasedMetricKindAndParametersV1&) =
      default;
};

struct ModeErasedConditioningConventionV1 final {
  TargetCouplingV1 target_coupling;
  std::vector<StateFieldKindV1> mathematical_state_fields;
  PayloadPhaseKindV1 payload_phase;
  ConfiguredArrivalCompositionV1 arrival_composition;
  bool retains_configured_predictive_phase;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;
  std::vector<HypothesisClaimV1> hypotheses;

  friend bool operator==(const ModeErasedConditioningConventionV1&,
                         const ModeErasedConditioningConventionV1&) =
      default;
};

struct ModeErasedMetricConventionV1 final {
  std::vector<ModeErasedMetricKindAndParametersV1>
      normalized_metric_kinds_and_parameters;
  std::vector<ModeErasedConditioningConventionV1>
      conditioning_convention;
  // This is the framework's normalized analysis selection, not the
  // provider descriptor's capability ceiling.  In particular, transient
  // initial-law semantics and authored stationary-mixture order survive the
  // mode erasure exactly.
  PortableAnalysisSelectionV1 initial_or_stationary_selection;
  std::vector<MetricResultScopeV1> result_scope;

  friend bool operator==(const ModeErasedMetricConventionV1&,
                         const ModeErasedMetricConventionV1&) = default;
};

// This exact four-part schema is test support only.  In particular it has no
// provider, method, producer mode, runtime-access, identity, digest, report,
// budget, counter, executable, path, or process field.
struct ModeErasedLawProjectionV1 final {
  std::uint32_t projection_version;
  ModeErasedDeployedLawV1 deployed_law;
  ModeErasedConfiguredArrivalMathV1 configured_arrival_math;
  ModeErasedTimingConventionV1 timing_convention;
  ModeErasedMetricConventionV1 metric_convention;

  friend bool operator==(const ModeErasedLawProjectionV1&,
                         const ModeErasedLawProjectionV1&) = default;
};

[[nodiscard]] Result<ModeErasedLawProjectionV1>
make_mode_erased_law_projection_v1(
    const ValidatedSurrogateArtifact& artifact,
    const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& accepted_contract);

}  // namespace mwperf::testing
