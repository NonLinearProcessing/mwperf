#pragma once

#if !defined(MWPERF_C20_TEST_SEAMS)
#error "multi_slot_temporal_fixture.hpp is available only to C20 tests"
#endif

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"

namespace mwperf::testing::c20 {

namespace temporal_fixture = c17_temporal;
namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

[[nodiscard]] inline designated::InputV1 three_slot_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[
      {"slot":1,"queue_id":"q0","count":2}],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":")json") +
      std::string(temporal_fixture::temporal_profile().provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = load_document(
      designated::write_input("c20-three-slot-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c20-three-slot-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline ExactReducedStateSchemaV1 three_slot_state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const CompiledArrivalLaw& configured_arrival) {
  auto instance_key = make_physical_reference_instance_key(
      instance.fingerprints().combined, BigNat{0U});
  REQUIRE(instance_key);
  auto stream = make_configured_arrival_stream_key(
      configured_arrival,
      derive_rng_stream(MasterSeed{0xC203510U},
                        StageTag::configured_arrival,
                        instance_key.value()));
  REQUIRE(stream);
  auto process = instantiate_arrival_process(
      configured_arrival, ArrivalInitialState{TraceOrigin{}},
      std::move(stream).value());
  REQUIRE(process);

  std::vector<ArrivalPhase> phases;
  phases.reserve(4U);
  for (std::size_t slot = 0U; slot < 3U; ++slot) {
    auto transition = next_arrival_step(process.value(), BigNat{slot});
    REQUIRE(transition);
    if (slot == 0U) {
      phases.push_back(transition.value().phase_before);
    } else {
      REQUIRE(c17::same_phase(phases.back(),
                              transition.value().phase_before));
    }
    phases.push_back(transition.value().phase_after);
  }
  REQUIRE(phases.size() == 4U);

  std::vector<QueueId> targets(ordered_targets.begin(),
                               ordered_targets.end());
  std::vector<BigNat> zeros(targets.size(), BigNat{0U});
  auto target_prototype = TargetBacklogV1::from_values(
      instance, targets, std::move(zeros));
  REQUIRE(target_prototype);
  const std::size_t cardinality = targets.size();
  auto phase_table =
      std::make_shared<const std::vector<ArrivalPhase>>(std::move(phases));

  return {
      c17::kReducedStateCodec,
      c17::digest("c20.fixture.three-slot.exact-state-schema"),
      c17::digest("c20.fixture.three-slot.reduced-state-schema"),
      c17::digest("c20.fixture.three-slot.ownership-schema"),
      c17::digest("c20.fixture.three-slot.exact-update-schema"),
      [target_prototype = std::move(target_prototype).value(), phase_table,
       cardinality](const ReducedStateV1& state)
          -> Result<ExactReducedCoordinatesV1> {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.three_slot_state_shape",
              "the deterministic three-slot state has a foreign shape");
        }
        std::vector<BigNat> values;
        values.reserve(cardinality);
        for (std::size_t index = 0U; index < cardinality; ++index) {
          values.emplace_back(std::to_integer<std::uint8_t>(
              state.canonical_value[index]));
        }
        auto backlog = target_prototype.with_values(std::move(values));
        if (!backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(backlog.error());
        }
        const std::size_t phase_index = std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality]);
        if (phase_index >= phase_table->size()) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.three_slot_phase",
              "the deterministic three-slot phase index is out of range");
        }
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(backlog).value(), (*phase_table)[phase_index],
             BigNat{std::to_integer<std::uint8_t>(
                 state.canonical_value[cardinality + 1U])},
             std::nullopt, {}, std::nullopt, {}});
      },
      [phase_table, cardinality](
          const ExactReducedCoordinatesV1& coordinates,
          const UnresolvedPatch& patch) -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != cardinality ||
            !patch.fields().empty()) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.three_slot_rebuild_shape",
              "the deterministic three-slot rebuild received a foreign "
              "coordinate");
        }
        const auto phase = std::ranges::find_if(
            *phase_table, [&](const ArrivalPhase& candidate) {
              return c17::same_phase(candidate, coordinates.arrival_phase);
            });
        if (phase == phase_table->end() ||
            coordinates.boundary_index.bit_length() > 8U) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.three_slot_rebuild_phase",
              "the deterministic three-slot rebuild received an unknown "
              "phase or oversized boundary");
        }
        std::vector<std::byte> bytes;
        bytes.reserve(cardinality + 2U);
        for (const BigNat& value : coordinates.backlog.values()) {
          if (value.bit_length() > 8U) {
            return c17::failure<ReducedStateV1>(
                "c20.fixture.three_slot_rebuild_backlog",
                "the deterministic three-slot backlog exceeded one byte");
          }
          bytes.push_back(static_cast<std::byte>(
              value.value().convert_to<std::uint8_t>()));
        }
        bytes.push_back(static_cast<std::byte>(
            static_cast<std::size_t>(phase - phase_table->begin())));
        bytes.push_back(static_cast<std::byte>(
            coordinates.boundary_index.value().convert_to<std::uint8_t>()));
        return Result<ReducedStateV1>::success(
            {c17::kReducedStateCodec, std::move(bytes)});
      },
      [phase_table, cardinality](const ReducedStateV1& state) {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[cardinality]) >= phase_table->size()) {
          return c17::failure<void>(
              "c20.fixture.three_slot_domain",
              "state is outside the deterministic three-slot domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {}};
}

[[nodiscard]] inline matrix::C17TemporalFixtureOverrideV1
three_slot_operation_override() {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.maximum_residence_slots = 3U;
  const QueueId target = designated::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto output = [target, opportunity_codec](
                          const CMinusInputV1& input)
      -> Result<CMinusOutputV1> {
    if (input.predecision_state.canonical_value.size() != 3U) {
      return c17::failure<CMinusOutputV1>(
          "c20.fixture.three_slot_cminus_shape",
          "the deterministic three-slot C-minus input has a foreign shape");
    }
    const std::uint8_t phase = std::to_integer<std::uint8_t>(
        input.predecision_state.canonical_value[1U]);
    const ExactRational idle_score =
        phase == 1U ? c17::rational(2, 1) : ExactRational::zero();
    std::vector<V0ScheduleFaceAtomV1> alternatives{
        V0ScheduleFaceAtomV1{{}, {}, idle_score},
        V0ScheduleFaceAtomV1{{target}, {}, ExactRational::zero()}};
    return Result<CMinusOutputV1>::success(
        {{opportunity_codec, {static_cast<std::byte>(phase)}}, {},
         V0EmittedOpportunityFaceV1{std::move(alternatives)}, std::nullopt});
  };
  override.c_minus =
      [output](const CMinusInputV1& input, DeterministicRng&) {
        return output(input);
      };
  override.enumerate_c_minus = [output](const CMinusInputV1& input) {
    auto atom = output(input);
    if (!atom) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          atom.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    if (!mass) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          mass.error());
    }
    std::vector<EnumeratedCMinusAtomV1> row;
    row.push_back({std::move(atom).value(), std::move(mass).value()});
    return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
        std::move(row));
  };
  override.stopping_indicator = [](const CanonicalRuntimeValueV1& state) {
    const CodecIdentityV1 codec{"c17.fixture.temporal.indicator", 1U};
    if (state.canonical_value.size() != 3U) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.three_slot_stop_shape",
          "the deterministic three-slot stop received a foreign state");
    }
    const bool stops = state.canonical_value[0U] == std::byte{0x02} &&
                       state.canonical_value[1U] == std::byte{0x03};
    return Result<CanonicalRuntimeValueV1>::success(
        {codec, {stops ? std::byte{0x01} : std::byte{0x00}}});
  };
  override.predecision_projection = [](
                                         const EventPredecisionProjectionInputV1&
                                             input) {
    const CodecIdentityV1 codec{
        "c17.fixture.temporal.predecision-projection", 1U};
    if (input.completed_prefix.size() > 0xffU) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.three_slot_projection_overflow",
          "the deterministic three-slot prefix index exceeded one byte");
    }
    return Result<CanonicalRuntimeValueV1>::success(
        {codec,
         {static_cast<std::byte>(input.completed_prefix.size())}});
  };
  override.completed_edge_projection = [](
                                           const EventCompletedEdgeProjectionInputV1&
                                               input) {
    const CodecIdentityV1 codec{
        "c17.fixture.temporal.completed-edge-projection", 1U};
    if (input.predecision_projection.canonical_value.size() != 1U) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.three_slot_completed_projection_shape",
          "the deterministic three-slot completed projection received a "
          "foreign prefix index");
    }
    const std::uint8_t index = std::to_integer<std::uint8_t>(
        input.predecision_projection.canonical_value.front());
    return Result<CanonicalRuntimeValueV1>::success(
        {codec, {static_cast<std::byte>(index + 1U)}});
  };
  return override;
}

[[nodiscard]] inline temporal_fixture::GenericTemporalFrameworkV1
make_deterministic_three_slot_framework_with_maximum(
    const std::size_t maximum_residence_slots) {
  matrix::C17TemporalFixtureOverrideV1 override =
      three_slot_operation_override();
  override.maximum_residence_slots = maximum_residence_slots;
  matrix::ScopedC17TemporalFixtureOverride override_scope(override);
  auto prepared =
      temporal_fixture::prepare_generic_temporal_framework_from_scenario(
          temporal_fixture::temporal_scenario(three_slot_input()),
          [](PlugDescriptor&) {},
          [](const ResolvedInstance& instance,
             const std::span<const QueueId> targets,
             const CompiledArrivalLaw& arrival,
             const ArrivalPhase&, const ArrivalPhase&) {
            return three_slot_state_schema(instance, targets, arrival);
          },
          [](const std::span<const QueueId> targets,
             const ExactReducedStateSchemaV1&) {
            return c17::reduced_state(targets, {2U}, false, 0U);
          },
          [maximum_residence_slots](ExactCausalProgramV1& program) {
            program.maximum_residence_slots = maximum_residence_slots;
          });
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(), std::move(prepared.instance),
          std::move(prepared.ordered_targets),
          std::move(prepared.state_schema), std::move(prepared.descriptor),
          std::move(prepared.initial_state),
          std::move(prepared.entrance_mark),
          std::move(prepared.entrance_decoder_calls),
          std::move(prepared.residence_generator_calls)};
}

[[nodiscard]] inline temporal_fixture::GenericTemporalFrameworkV1
make_deterministic_three_slot_framework() {
  return make_deterministic_three_slot_framework_with_maximum(3U);
}

// The same adapted stopping rule first becomes true at slot three, while the
// C17 seal binds a maximum of two slots.  It is therefore a direct fixture for
// C20's rule that continuing at the declared maximum is a contract failure,
// never a manufactured stop or a complete word.
[[nodiscard]] inline temporal_fixture::GenericTemporalFrameworkV1
make_continuing_at_sealed_maximum_framework() {
  return make_deterministic_three_slot_framework_with_maximum(2U);
}

[[nodiscard]] inline std::uint8_t backlog_value(
    const ReducedStateV1& state) {
  REQUIRE(state.canonical_value.size() == 3U);
  return std::to_integer<std::uint8_t>(state.canonical_value[0U]);
}

[[nodiscard]] inline std::uint8_t phase_index(
    const ReducedStateV1& state) {
  REQUIRE(state.canonical_value.size() == 3U);
  return std::to_integer<std::uint8_t>(state.canonical_value[1U]);
}

[[nodiscard]] inline std::uint8_t one_byte_projection(
    const CanonicalRuntimeValueV1& projection) {
  REQUIRE(projection.canonical_value.size() == 1U);
  return std::to_integer<std::uint8_t>(projection.canonical_value.front());
}

}  // namespace mwperf::testing::c20
