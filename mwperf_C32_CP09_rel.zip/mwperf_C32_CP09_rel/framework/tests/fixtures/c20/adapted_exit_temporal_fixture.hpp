#pragma once

#if !defined(MWPERF_C20_TEST_SEAMS)
#error "adapted_exit_temporal_fixture.hpp is available only to C20 tests"
#endif

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"

namespace mwperf::testing::c20 {

namespace adapted_detail {

namespace temporal_fixture = c17_temporal;
namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

inline constexpr std::size_t kQueueCount = 3U;
inline constexpr std::size_t kPairExitOffset = 4U;
inline constexpr std::size_t kPhaseOffset = 5U;

// Keep the portable unsigned-byte order explicit.  GCC 13's optimized
// libstdc++ vector comparison can otherwise emit a spurious overread warning.
struct CanonicalByteVectorLess final {
  [[nodiscard]] bool operator()(const std::vector<std::byte>& left,
                                const std::vector<std::byte>& right) const
      noexcept {
    const std::size_t common_size = std::min(left.size(), right.size());
    for (std::size_t index = 0U; index < common_size; ++index) {
      const unsigned int left_byte =
          std::to_integer<unsigned int>(left[index]);
      const unsigned int right_byte =
          std::to_integer<unsigned int>(right[index]);
      if (left_byte != right_byte) {
        return left_byte < right_byte;
      }
    }
    return left.size() < right.size();
  }
};

struct ExactStateStoreV1 final {
  std::mutex mutex;
  std::map<std::vector<std::byte>, ExactReducedCoordinatesV1,
           CanonicalByteVectorLess>
      states;
};

struct StateSchemaAndEntranceV1 final {
  ExactReducedStateSchemaV1 schema;
  ReducedStateV1 entrance;
};

[[nodiscard]] inline Result<std::vector<std::byte>> encode_state(
    const ExactReducedCoordinatesV1& coordinates,
    const Digest256& entrance_pair_identity) {
  if (coordinates.backlog.size() != 1U ||
      coordinates.margins.size() != 1U ||
      coordinates.resources.has_value() ||
      coordinates.controller.has_value() ||
      !coordinates.unresolved_fields.empty()) {
    return c17::failure<std::vector<std::byte>>(
        "c20.fixture.adapted_exit_coordinate_shape",
        "the adapted-exit state requires one target backlog, one exact "
        "pair margin, and no unrelated exact coordinates");
  }
  const PairMargin& margin = coordinates.margins.front();
  const auto full = margin.evaluation_backlog().values();
  if (full.size() != kQueueCount ||
      full.front() != coordinates.backlog.values().front() ||
      margin.pair().identity_digest() != entrance_pair_identity ||
      coordinates.boundary_index.bit_length() > 8U) {
    return c17::failure<std::vector<std::byte>>(
        "c20.fixture.adapted_exit_coordinate_binding",
        "the adapted-exit target, full margin backlog, or boundary is "
        "inconsistent");
  }

  const auto phase = arrival_phase_canonical_state(
      coordinates.arrival_phase);
  std::vector<std::byte> encoded;
  encoded.reserve(kPhaseOffset + phase.size());
  for (const BigNat& value : full) {
    if (value.bit_length() > 8U) {
      return c17::failure<std::vector<std::byte>>(
          "c20.fixture.adapted_exit_backlog_width",
          "the adapted-exit hand fixture stores only one-byte backlogs");
    }
    encoded.push_back(static_cast<std::byte>(
        value.value().convert_to<std::uint8_t>()));
  }
  encoded.push_back(static_cast<std::byte>(
      coordinates.boundary_index.value().convert_to<std::uint8_t>()));
  encoded.push_back(margin.pair_valid() ? std::byte{0x00}
                                        : std::byte{0x01});
  encoded.insert(encoded.end(), phase.begin(), phase.end());
  return Result<std::vector<std::byte>>::success(std::move(encoded));
}

[[nodiscard]] inline StateSchemaAndEntranceV1 make_state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const ArrivalPhase& entrance_phase) {
  REQUIRE(ordered_targets.size() == 1U);
  auto target_index = TargetIndex::from_instance(instance, 0U);
  REQUIRE(target_index);
  auto full_backlog = Backlog::from_values(
      QueueDimensionToken::from_instance(instance),
      {BigNat{10U}, BigNat{9U}, BigNat{8U}});
  REQUIRE(full_backlog);
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      instance);
  REQUIRE(optimizer);
  auto opportunity = compute_target_opportunity(
      instance, full_backlog.value(), target_index.value(),
      optimizer.value());
  REQUIRE(opportunity);
  auto forced_out = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), {0U, 1U, 0U});
  auto forced_in = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), {1U, 0U, 0U});
  REQUIRE(forced_out);
  REQUIRE(forced_in);
  auto pair = SchedulePair::make(
      instance, target_index.value(), std::move(forced_out).value(),
      std::move(forced_in).value());
  REQUIRE(pair);
  auto margin = evaluate_margin_pair(
      full_backlog.value(), pair.value(), opportunity.value());
  REQUIRE(margin);
  REQUIRE(margin.value().pair_valid());
  const Digest256 entrance_pair_identity =
      margin.value().pair().identity_digest();

  auto target_backlog = TargetBacklogV1::from_values(
      instance, std::vector<QueueId>(ordered_targets.begin(),
                                     ordered_targets.end()),
      {BigNat{10U}});
  REQUIRE(target_backlog);
  ExactReducedCoordinatesV1 entrance_coordinates{
      std::move(target_backlog).value(), entrance_phase, BigNat{0U},
      std::nullopt, {std::move(margin).value()}, std::nullopt, {}};
  auto entrance_bytes = encode_state(
      entrance_coordinates, entrance_pair_identity);
  REQUIRE(entrance_bytes);
  ReducedStateV1 entrance{c17::kReducedStateCodec,
                          std::move(entrance_bytes).value()};

  auto store = std::make_shared<ExactStateStoreV1>();
  store->states.emplace(entrance.canonical_value, entrance_coordinates);
  const auto decode = [store](const ReducedStateV1& state)
      -> Result<ExactReducedCoordinatesV1> {
    if (state.codec != c17::kReducedStateCodec ||
        state.canonical_value.size() < kPhaseOffset) {
      return c17::failure<ExactReducedCoordinatesV1>(
          "c20.fixture.adapted_exit_state_shape",
          "the adapted-exit state has a foreign codec or shape");
    }
    const std::scoped_lock lock(store->mutex);
    const auto found = store->states.find(state.canonical_value);
    if (found == store->states.end()) {
      return c17::failure<ExactReducedCoordinatesV1>(
          "c20.fixture.adapted_exit_unknown_state",
          "the adapted-exit state was not produced by its exact rebuild");
    }
    return Result<ExactReducedCoordinatesV1>::success(found->second);
  };
  const auto rebuild = [store, entrance_pair_identity](
                           const ExactReducedCoordinatesV1& coordinates,
                           const UnresolvedPatch& patch)
      -> Result<ReducedStateV1> {
    if (!patch.fields().empty()) {
      return c17::failure<ReducedStateV1>(
          "c20.fixture.adapted_exit_unresolved_patch",
          "the adapted-exit fixture has no surrogate-owned state");
    }
    auto encoded = encode_state(coordinates, entrance_pair_identity);
    if (!encoded) {
      return Result<ReducedStateV1>::failure(encoded.error());
    }
    ReducedStateV1 state{c17::kReducedStateCodec,
                         std::move(encoded).value()};
    {
      const std::scoped_lock lock(store->mutex);
      store->states.insert_or_assign(state.canonical_value, coordinates);
    }
    return Result<ReducedStateV1>::success(std::move(state));
  };
  const auto validate = [store](const ReducedStateV1& state) {
    if (state.codec != c17::kReducedStateCodec ||
        state.canonical_value.size() < kPhaseOffset) {
      return c17::failure<void>(
          "c20.fixture.adapted_exit_domain_shape",
          "the adapted-exit state is outside its exact domain");
    }
    const std::scoped_lock lock(store->mutex);
    if (!store->states.contains(state.canonical_value)) {
      return c17::failure<void>(
          "c20.fixture.adapted_exit_domain_unknown",
          "the adapted-exit state is not an exact reachable state");
    }
    return Result<void>::success();
  };

  ExactReducedStateSchemaV1 schema{
      c17::kReducedStateCodec,
      c17::digest("c20.fixture.adapted-exit.exact-state-schema"),
      c17::digest("c20.fixture.adapted-exit.reduced-state-schema"),
      c17::digest("c20.fixture.adapted-exit.ownership-schema"),
      c17::digest("c20.fixture.adapted-exit.exact-update-schema"),
      decode,
      rebuild,
      validate,
      {},
      {},
      {}};
  return {std::move(schema), std::move(entrance)};
}

[[nodiscard]] inline designated::InputV1 adapted_exit_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[["q0","q1"],["q0","q2"],
                                   ["q1","q2"]]},
      "priority":["q0","q1","q2"],"max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"a0"},{"id":"a1"},{"id":"b0"},
                 {"id":"b1"},{"id":"b2"},{"id":"b3"}],
      "states":["on"],"initial":{"state":"on"},
      "outcomes":[
        {"state":"on","next_state":"on","probability":0.5,
         "emissions":[
           {"source_id":"a0","d":2,"queue_id":"q0"},
           {"source_id":"a1","d":2,"queue_id":"q0"},
           {"source_id":"b0","d":2,"queue_id":"q2"},
           {"source_id":"b1","d":2,"queue_id":"q2"},
           {"source_id":"b2","d":2,"queue_id":"q2"},
           {"source_id":"b3","d":2,"queue_id":"q2"}]},
        {"state":"on","next_state":"on","probability":0.5,
         "emissions":[
           {"source_id":"a0","d":1,"queue_id":"q0"},
           {"source_id":"a1","d":1,"queue_id":"q0"},
           {"source_id":"b0","d":1,"queue_id":"q2"},
           {"source_id":"b1","d":1,"queue_id":"q2"},
           {"source_id":"b2","d":1,"queue_id":"q2"},
           {"source_id":"b3","d":1,"queue_id":"q2"}]}
      ],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":")json") +
      std::string(temporal_fixture::temporal_profile().provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":512,"max_search_states_per_call":512},
      "sampling":{"max_generator_draws":512},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = load_document(
      designated::write_input("c20-adapted-exit-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c20-adapted-exit-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline matrix::C17TemporalFixtureOverrideV1
adapted_exit_operation_override() {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.maximum_residence_slots = 2U;
  const QueueId target = designated::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto output = [target, opportunity_codec](const CMinusInputV1&) {
    return Result<CMinusOutputV1>::success(CMinusOutputV1{
        {opportunity_codec, {std::byte{0x01}}}, {},
        V0EmittedOpportunityFaceV1{{
            {{}, {}, ExactRational::zero()},
            {{target}, {}, ExactRational::zero()}}},
        std::nullopt});
  };
  override.c_minus =
      [output](const CMinusInputV1& input, DeterministicRng&) {
        return output(input);
      };
  override.enumerate_c_minus = [output](const CMinusInputV1& input) {
    auto atom = output(input);
    if (!atom) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          atom.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    if (!mass) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          mass.error());
    }
    return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
        {{std::move(atom).value(), std::move(mass).value()}});
  };
  override.stopping_indicator = [](const CanonicalRuntimeValueV1& state) {
    const CodecIdentityV1 codec{"c17.fixture.temporal.indicator", 1U};
    if (state.codec != c17::kReducedStateCodec ||
        state.canonical_value.size() < kPhaseOffset) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.adapted_exit_stop_shape",
          "the adapted-exit stopping rule received a foreign state");
    }
    const bool exited =
        state.canonical_value[kPairExitOffset] == std::byte{0x01};
    return Result<CanonicalRuntimeValueV1>::success(
        {codec, {exited ? std::byte{0x01} : std::byte{0x00}}});
  };
  return override;
}

}  // namespace adapted_detail

[[nodiscard]] inline c17_temporal::GenericTemporalFrameworkV1
make_adapted_exit_framework() {
  using namespace adapted_detail;
  matrix::C17TemporalFixtureOverrideV1 override =
      adapted_exit_operation_override();
  matrix::ScopedC17TemporalFixtureOverride override_scope(override);
  auto entrance = std::make_shared<std::optional<ReducedStateV1>>();
  auto prepared =
      temporal_fixture::
          prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
              temporal_fixture::temporal_scenario(adapted_exit_input()),
              ArrivalInitialState{SharedRoundState{"on"}},
              std::nullopt,
              [](PlugDescriptor&) {},
              [entrance](const ResolvedInstance& instance,
                         const std::span<const QueueId> targets,
                         const CompiledArrivalLaw&, const ArrivalPhase& before,
                         const ArrivalPhase&) {
                auto bundle = make_state_schema(instance, targets, before);
                *entrance = bundle.entrance;
                return std::move(bundle.schema);
              },
              [entrance](const std::span<const QueueId>,
                         const ExactReducedStateSchemaV1&) {
                REQUIRE(entrance->has_value());
                return **entrance;
              },
              [](ExactCausalProgramV1& program) {
                program.maximum_residence_slots = 2U;
              });
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(), std::move(prepared.instance),
          std::move(prepared.ordered_targets),
          std::move(prepared.state_schema), std::move(prepared.descriptor),
          std::move(prepared.initial_state),
          std::move(prepared.entrance_mark),
          std::move(prepared.entrance_decoder_calls),
          std::move(prepared.residence_generator_calls)};
}

[[nodiscard]] inline std::vector<std::uint8_t> adapted_full_backlog(
    const ReducedStateV1& state) {
  REQUIRE(state.canonical_value.size() >= adapted_detail::kPhaseOffset);
  std::vector<std::uint8_t> result;
  result.reserve(adapted_detail::kQueueCount);
  for (std::size_t index = 0U; index < adapted_detail::kQueueCount; ++index) {
    result.push_back(
        std::to_integer<std::uint8_t>(state.canonical_value[index]));
  }
  return result;
}

[[nodiscard]] inline bool adapted_pair_cell_exited(
    const ReducedStateV1& state) {
  REQUIRE(state.canonical_value.size() >= adapted_detail::kPhaseOffset);
  return state.canonical_value[adapted_detail::kPairExitOffset] ==
         std::byte{0x01};
}

}  // namespace mwperf::testing::c20
