#pragma once

#if !defined(MWPERF_C20_TEST_SEAMS)
#error "enumerable_four_word_fixture.hpp is available only to C20 tests"
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/initial_law.hpp"
#include "fixtures/c20/multi_slot_temporal_fixture.hpp"

namespace mwperf::testing {

// Rebinds a resolved shared-round instance to a private C09 exact law while
// retaining the physical input identity, queue catalog, authored provenance,
// exact positive-support mask, and any authored physical initial law.  The
// production constructors remain inaccessible outside this C20 test seam.
class C20ArrivalFixtureAccess final {
 public:
  C20ArrivalFixtureAccess() = delete;

  [[nodiscard]] static Result<ResolvedInstance> bind(
      const ResolvedInstance& source,
      std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
    const auto reject = [](std::string code, std::string message) {
      return Result<ResolvedInstance>::failure(
          {DiagnosticCategory::input_validation, std::move(code),
           std::move(message), std::nullopt, std::nullopt, {}});
    };
    if (!configured_arrival) {
      return reject("c20.fixture_arrival_missing",
                    "the C20 homogeneous fixture requires an exact arrival "
                    "law");
    }
    const PhysicalBindingIdentity physical = source.arrival().identity();
    const ArrivalBinding& binding =
        arrival_law_binding(*configured_arrival);
    if (physical.combined_input != source.fingerprints().combined ||
        binding.family != physical.arrival_family ||
        binding.timing != source.timing() ||
        binding.timing != physical.timing ||
        binding.queue_cardinality != source.queues().size() ||
        binding.queue_cardinality != physical.queue_cardinality) {
      return reject("c20.fixture_arrival_physical_binding_mismatch",
                    "the finite homogeneous law does not match the resolved "
                    "physical arrival family, timing, or queue dimension");
    }
    auto catalog_digest = detail::digest_queue_catalog(source.queues());
    if (!catalog_digest ||
        binding.catalog_digest != catalog_digest.value()) {
      return catalog_digest
                 ? reject("c20.fixture_arrival_catalog_mismatch",
                          "the finite homogeneous law does not match the "
                          "resolved queue catalog")
                 : Result<ResolvedInstance>::failure(
                       catalog_digest.error());
    }
    QueueMask support = positive_arrival_support(*configured_arrival);
    if (support.size() != source.queues().size() ||
        support.bytes() != source.positive_arrival_support().bytes()) {
      return reject("c20.fixture_arrival_support_mismatch",
                    "the finite homogeneous and authored shared-round laws "
                    "must have identical positive queue support");
    }

    const ArrivalProductBindingIdentity product_identity{
        binding.family, binding.timing, binding.queue_cardinality,
        binding.law_digest.value(), binding.catalog_digest.value()};
    const auto references = source.arrival().queue_references();
    ConfiguredArrivalBinding rebound_arrival(
        physical,
        std::vector<BoundQueueReference>(references.begin(),
                                         references.end()),
        std::shared_ptr<const void>(configured_arrival),
        ArrivalCompiledProductKind::compiled_arrival_law_v1,
        product_identity);

    std::optional<InitialLawBinding> rebound_initial_law;
    if (source.initial_law().has_value()) {
      const InitialLawBinding& authored_initial = *source.initial_law();
      if (authored_initial.identity() != physical) {
        return reject("c20.fixture_initial_physical_binding_mismatch",
                      "the retained authored initial law does not match the "
                      "resolved physical arrival binding");
      }
      auto compiled_initial = compile_initial_physical_law(
          authored_initial.law(), *configured_arrival);
      if (!compiled_initial) {
        return Result<ResolvedInstance>::failure(compiled_initial.error());
      }
      if (compiled_initial.value().arrival_binding() != binding) {
        return reject("c20.fixture_initial_arrival_binding_mismatch",
                      "the recompiled initial law does not match the exact "
                      "replacement arrival law");
      }
      try {
        auto initial_owner = std::make_shared<const InitialPhysicalLaw>(
            std::move(compiled_initial).value());
        InitialLawBinding rebound_initial(
            physical, authored_initial.law(),
            std::shared_ptr<const void>(std::move(initial_owner)),
            InitialCompiledProductKind::initial_physical_law_v1,
            product_identity);
        rebound_initial_law = std::move(rebound_initial);
      } catch (const std::bad_alloc&) {
        return Result<ResolvedInstance>::failure(
            {DiagnosticCategory::resource_limit,
             "c20.fixture_initial_product_allocation_failure",
             "retaining the recompiled fixture initial law exhausted memory",
             std::nullopt, std::nullopt, {}});
      }
    }

    return Result<ResolvedInstance>::success(ResolvedInstance(
        source.authored_model(), source.analysis_spec(),
        source.fingerprints(), source.queues(), source.priority(),
        source.constraint(), source.service_identity(), source.serviceable(),
        source.optimizer_budget(), source.targets(),
        std::move(rebound_arrival), std::move(support),
        std::move(rebound_initial_law), source.timing()));
  }
};

}  // namespace mwperf::testing

namespace mwperf::testing::c20 {

struct FourWordEnumerableFrameworkV1 final {
  c17_temporal::GenericTemporalFrameworkV1 temporal;
  std::shared_ptr<std::atomic<unsigned>> cminus_realize_calls;
  std::shared_ptr<std::atomic<unsigned>> cminus_enumerate_calls;
  std::shared_ptr<std::atomic<unsigned>> callback_clock_or;
};

enum class FourWordEventSelectionV1 : std::uint8_t {
  unique,
  transient_class,
};

enum class FourWordMetricFixtureV1 : std::uint8_t {
  throughput,
  stationary_empty_probability,
};

[[nodiscard]] inline c16_designated_detail::InputV1
four_word_enumerable_input(
    const bool reverse_arrival_row = false,
    const FourWordEventSelectionV1 selection =
        FourWordEventSelectionV1::unique,
    const FourWordMetricFixtureV1 metric =
        FourWordMetricFixtureV1::throughput) {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q1"},{"id":"q2"},{"id":"q0"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"a"},{"id":"b"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q1"},
                      {"source_id":"b","d":1,"queue_id":"q2"}]},
        {"state":"h0","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q1"},
                      {"source_id":"b","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q1"},
                      {"source_id":"b","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q1"},
                      {"source_id":"b","d":1,"queue_id":"q2"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string selection_json =
      selection == FourWordEventSelectionV1::unique
          ? R"json({"kind":"stationary_unique","parameters":{}})json"
          : R"json({"kind":"stationary_class","parameters":{"class_id":1}})json";
  const std::string metric_json =
      metric == FourWordMetricFixtureV1::throughput
          ? R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json"
          : R"json({"id":"c21-empty","kind":"stationary_empty_probability","parameters":{}})json";
  const std::string solver_json =
      metric == FourWordMetricFixtureV1::throughput
          ? R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json"
          : R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})json";
  const std::string linear_tolerance_json =
      metric == FourWordMetricFixtureV1::throughput ? "null" : "0";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + metric_json + R"json(],
    "surrogate":{"id":")json" +
      std::string(
          c16_registered_pair_matrix::kC20EnumerableRomrProfile.provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":)json" +
      linear_tolerance_json + R"json(,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" + selection_json + R"json(,
    "solver":)json" + solver_json + R"json(
  })json";

  auto model_document = load_document(
      c16_designated_detail::write_input("c20-four-word-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      c16_designated_detail::write_input("c20-four-word-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  REQUIRE(instance);
  auto fixture_law = make_c09_time_homogeneous_correlated_fixture_law(
      instance.value().queues(), reverse_arrival_row);
  REQUIRE(fixture_law);
  auto arrival = std::make_shared<const CompiledArrivalLaw>(
      std::move(fixture_law).value());
  auto rebound = C20ArrivalFixtureAccess::bind(
      instance.value(), arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  auto request = parse_metric_request(
      rebound.value().analysis_spec().metrics.front(),
      rebound.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(rebound).value(), std::move(arrival),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline C16DesignatedScenarioV1
four_word_stationary_scenario(
    c16_designated_detail::InputV1 input,
    const c16_registered_pair_matrix::ProfileV1& profile) {
  C16DesignatedScenarioV1 scenario =
      c17_temporal::temporal_scenario(std::move(input), profile);
  std::vector<ResolvedMetricContractV1> contracts;
  for (const MetricRequirementClause& clause :
       scenario.requirements.clauses()) {
    const auto route = std::ranges::find_if(
        clause.route_alternatives,
        [&](const MetricRouteAlternativeV1& alternative) {
          return alternative.access.backend_route ==
                     BackendRouteKindV1::stationary_invariant &&
                 alternative.access.runtime_access == profile.access;
        });
    if (route == clause.route_alternatives.end()) {
      continue;
    }
    contracts.push_back(ResolvedMetricContractV1{
        clause.origin.clause_id.authored_index,
        clause.origin.clause_id,
        clause.origin.clause_id.metric_id,
        clause.origin.ordered_targets,
        profile.semantic,
        profile.access,
        route->semantic.coupling,
        clause.access.solver_regime,
        BackendRouteKindV1::stationary_invariant,
        scenario.preview.metric_support_manifest->canonical_digest()});
  }
  REQUIRE(contracts.size() == 1U);

  auto budget_digest = digest_construction_budget_v1(scenario.budget);
  REQUIRE(budget_digest);
  const PreviewPoliciesV1 policies{
      PointDeploymentPolicyV1::not_applicable,
      CoefficientCompletionPolicyV1::not_applicable,
      ProjectionPolicyV1::not_applicable,
      RecodingPolicyV1::not_applicable,
      EvidenceRolePolicyV1::exact_manifest_roles};
  auto contract = C15ProtocolFixtureFactory::accepted_contract(
      scenario.provider.manifest().value(), scenario.preview.core,
      *scenario.preview.metric_support_manifest, scenario.requirements,
      scenario.view.configured_arrival().capabilities(),
      std::move(contracts), scenario.preview.construction_target_scope,
      policies, scenario.preview.construction_prerequisites,
      scenario.view.canonical_digest().value(),
      scenario.parameters.canonical_value_digest(), budget_digest.value());
  auto request = make_surrogate_build_request(
      scenario.provider.manifest(), scenario.view, contract,
      scenario.parameters, scenario.budget, MasterSeed{0xC1710U});
  REQUIRE(request);
  scenario.contract = std::move(contract);
  scenario.request = std::move(request).value();
  return scenario;
}

[[nodiscard]] inline c17_temporal::PreparedGenericTemporalFrameworkV1
prepare_empty_trace_countable_candidate(const bool request_clock_quotient) {
  const auto& profile =
      c16_registered_pair_matrix::kC20CountableRomrProfile;
  const std::vector<QueueId> targets{
      c16_designated_detail::queue("q0")};
  return c17_temporal::prepare_generic_temporal_framework_from_scenario(
      c17_temporal::temporal_scenario(
          c16_designated_detail::input(profile.provider_id), profile),
      [](PlugDescriptor&) {},
      [](const ResolvedInstance& instance,
         const std::span<const QueueId> ordered_targets,
         const CompiledArrivalLaw&, const ArrivalPhase& before,
         const ArrivalPhase& after) {
        return c17::exact_state_schema(
            instance, ordered_targets, before, after);
      },
      [](const std::span<const QueueId> ordered_targets,
         const ExactReducedStateSchemaV1&) {
        return c17::reduced_state(ordered_targets, {1U}, false, 0U);
      },
      [targets, request_clock_quotient](ExactCausalProgramV1& program) {
        const ReducedStateV1 entry =
            c17::reduced_state(targets, {1U}, false, 0U);
        program.maximum_residence_slots = 1U;
        program.reachable_audit_states = {entry};
        if (request_clock_quotient) {
          program.finite_event_domain_states =
              std::vector<ReducedStateV1>{entry};
          program.event_entry_domain_is_exact_state_domain = false;
          program.event_clock_semantics = EventClockSemanticsV1::
              finite_phase_time_homogeneous_quotient;
        }
      });
}

[[nodiscard]] inline ExactReducedStateSchemaV1 four_word_state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const CompiledArrivalLaw& configured_arrival) {
  std::vector<QueueId> targets(ordered_targets.begin(),
                               ordered_targets.end());
  std::vector<BigNat> zeros(targets.size(), BigNat{0U});
  auto target_prototype = TargetBacklogV1::from_values(
      instance, targets, std::move(zeros));
  REQUIRE(target_prototype);

  // The reduced bytes retain the physical boundary.  Each decode reconstructs
  // a phase whose private C09 cursor expects that same absolute slot; the
  // finite event domain below uses only the boundary-zero representatives.
  std::vector<ArrivalPhase> phases;
  phases.reserve(6U);
  for (std::uint8_t boundary = 0U; boundary != 3U; ++boundary) {
    for (std::uint8_t phase = 0U; phase != 2U; ++phase) {
      auto value = make_c09_fixture_phase_for_testing(
          configured_arrival, phase, BigNat{boundary});
      REQUIRE(value);
      phases.push_back(std::move(value).value());
    }
  }
  auto phase_table =
      std::make_shared<const std::vector<ArrivalPhase>>(std::move(phases));
  const std::size_t cardinality = targets.size();

  return {
      c17::kReducedStateCodec,
      c17::digest("c20.fixture.four-word.exact-state-schema"),
      c17::digest("c20.fixture.four-word.reduced-state-schema"),
      c17::digest("c20.fixture.four-word.ownership-schema"),
      c17::digest("c20.fixture.four-word.exact-update-schema"),
      [target_prototype = std::move(target_prototype).value(), phase_table,
       cardinality](const ReducedStateV1& state)
          -> Result<ExactReducedCoordinatesV1> {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.four_word_state_shape",
              "the homogeneous four-word state has a foreign shape");
        }
        const std::uint8_t phase = std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality]);
        const std::uint8_t boundary = std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality + 1U]);
        if (phase > 1U || boundary > 2U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.four_word_clock_range",
              "the homogeneous four-word phase or physical boundary is out "
              "of range");
        }
        std::vector<BigNat> values;
        values.reserve(cardinality);
        for (std::size_t index = 0U; index < cardinality; ++index) {
          values.emplace_back(std::to_integer<std::uint8_t>(
              state.canonical_value[index]));
        }
        auto backlog = target_prototype.with_values(std::move(values));
        if (!backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(backlog.error());
        }
        const std::size_t phase_index =
            static_cast<std::size_t>(boundary) * 2U + phase;
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(backlog).value(), (*phase_table)[phase_index],
             BigNat{boundary}, std::nullopt, {}, std::nullopt, {}});
      },
      [phase_table, cardinality](
          const ExactReducedCoordinatesV1& coordinates,
          const UnresolvedPatch& patch) -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != cardinality ||
            !patch.fields().empty() ||
            coordinates.boundary_index.bit_length() > 8U) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.four_word_rebuild_shape",
              "the homogeneous four-word rebuild received a foreign "
              "coordinate");
        }
        const auto canonical =
            arrival_phase_canonical_state(coordinates.arrival_phase);
        const std::uint8_t boundary =
            coordinates.boundary_index.value().convert_to<std::uint8_t>();
        if (canonical.size() != 1U ||
            (canonical.front() != std::byte{0U} &&
             canonical.front() != std::byte{1U}) ||
            boundary > 2U ||
            arrival_phase_family(coordinates.arrival_phase) !=
                ArrivalFamily::shared_joint_round_markov_renewal) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.four_word_rebuild_phase",
              "the homogeneous four-word rebuild received an unknown phase "
              "or physical boundary");
        }
        const std::uint8_t phase =
            std::to_integer<std::uint8_t>(canonical.front());
        const ArrivalPhase& expected =
            (*phase_table)[static_cast<std::size_t>(boundary) * 2U + phase];
        if (!c17::same_phase(expected, coordinates.arrival_phase)) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.four_word_rebuild_phase",
              "the homogeneous four-word rebuild received a foreign "
              "predictive phase");
        }
        std::vector<std::byte> bytes;
        bytes.reserve(cardinality + 2U);
        for (const BigNat& value : coordinates.backlog.values()) {
          if (value.bit_length() > 8U) {
            return c17::failure<ReducedStateV1>(
                "c20.fixture.four_word_rebuild_backlog",
                "the homogeneous four-word backlog exceeded one byte");
          }
          bytes.push_back(static_cast<std::byte>(
              value.value().convert_to<std::uint8_t>()));
        }
        bytes.push_back(static_cast<std::byte>(phase));
        bytes.push_back(static_cast<std::byte>(boundary));
        return Result<ReducedStateV1>::success(
            {c17::kReducedStateCodec, std::move(bytes)});
      },
      [cardinality](const ReducedStateV1& state) {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[cardinality]) > 1U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[cardinality + 1U]) > 2U) {
          return c17::failure<void>(
              "c20.fixture.four_word_domain",
              "state is outside the homogeneous four-word exact domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {}};
}

[[nodiscard]] inline c16_registered_pair_matrix::C17TemporalFixtureOverrideV1
four_word_operation_override(
    std::shared_ptr<std::atomic<unsigned>> realize_calls,
    std::shared_ptr<std::atomic<unsigned>> enumerate_calls,
    std::shared_ptr<std::atomic<unsigned>> callback_clock_or,
    const bool legacy_boundary_stop) {
  auto override = three_slot_operation_override();
  override.maximum_residence_slots = 2U;
  const QueueId target = c16_designated_detail::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto output = [target, opportunity_codec, callback_clock_or](
                          const CMinusInputV1& input)
      -> Result<CMinusOutputV1> {
    if (input.predecision_state.canonical_value.size() != 3U) {
      return c17::failure<CMinusOutputV1>(
          "c20.fixture.four_word_cminus_shape",
          "the four-word C-minus input has a foreign shape");
    }
    callback_clock_or->fetch_or(
        std::to_integer<unsigned>(input.predecision_state.canonical_value[2U]),
        std::memory_order_relaxed);
    // One exact service opportunity drains q0 whenever it is nonempty.  The
    // callback is independent of the physical boundary and configured-arrival
    // slot; all stochastic branching is supplied by C09's homogeneous row.
    std::vector<V0ScheduleFaceAtomV1> alternatives{
        {{}, {}, ExactRational::zero()},
        {{target}, {}, ExactRational::zero()}};
    return Result<CMinusOutputV1>::success(
        {{opportunity_codec,
          {std::byte{0x01}}},
         {}, V0EmittedOpportunityFaceV1{std::move(alternatives)},
         std::nullopt});
  };
  override.c_minus =
      [output, realize_calls = std::move(realize_calls)](
          const CMinusInputV1& input, DeterministicRng&) {
        realize_calls->fetch_add(1U, std::memory_order_relaxed);
        return output(input);
      };
  override.enumerate_c_minus =
      [output, enumerate_calls = std::move(enumerate_calls)](
          const CMinusInputV1& input) {
        enumerate_calls->fetch_add(1U, std::memory_order_relaxed);
        auto atom = output(input);
        if (!atom) {
          return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
              atom.error());
        }
        auto mass = ProbabilityMass::exact_rational(
            ExactRational::one(), true);
        if (!mass) {
          return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
              mass.error());
        }
        return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
            {{std::move(atom).value(), std::move(mass).value()}});
      };
  override.stopping_indicator =
      [callback_clock_or, legacy_boundary_stop](
          const CanonicalRuntimeValueV1& state) {
    const CodecIdentityV1 codec{"c17.fixture.temporal.indicator", 1U};
    if (state.canonical_value.size() != 3U) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.four_word_stop_shape",
          "the four-word stopping rule received a foreign state");
    }
    callback_clock_or->fetch_or(
        std::to_integer<unsigned>(state.canonical_value[2U]),
        std::memory_order_relaxed);
    // Adapted stopping depends only on the exact target backlog, never on the
    // absolute boundary.  A zero-backlog event entry therefore stops after
    // one physical slot; backlog two stops after exactly two.
    const bool stops = legacy_boundary_stop
                           ? state.canonical_value[2U] == std::byte{0x02}
                           : state.canonical_value[0U] == std::byte{0x00};
    return Result<CanonicalRuntimeValueV1>::success(
        {codec, {stops ? std::byte{0x01} : std::byte{0x00}}});
  };
  return override;
}

[[nodiscard]] inline FourWordEnumerableFrameworkV1
make_four_word_enumerable_framework(
    const bool reverse_domain_order = false,
    const bool legacy_boundary_stop = false,
    const bool reverse_arrival_row = false,
    const FourWordEventSelectionV1 selection =
        FourWordEventSelectionV1::unique,
    const FourWordMetricFixtureV1 metric =
        FourWordMetricFixtureV1::throughput) {
  auto realize_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto enumerate_calls = std::make_shared<std::atomic<unsigned>>(0U);
  auto callback_clock_or = std::make_shared<std::atomic<unsigned>>(0U);
  auto override = four_word_operation_override(
      realize_calls, enumerate_calls, callback_clock_or,
      legacy_boundary_stop);
  c16_registered_pair_matrix::ScopedC17TemporalFixtureOverride scope(
      override);
  const auto& profile =
      c16_registered_pair_matrix::kC20EnumerableRomrProfile;
  const std::vector<QueueId> audit_targets{
      c16_designated_detail::queue("q0")};
  auto input = four_word_enumerable_input(reverse_arrival_row, selection,
                                          metric);
  C16DesignatedScenarioV1 scenario =
      metric == FourWordMetricFixtureV1::stationary_empty_probability
          ? four_word_stationary_scenario(std::move(input), profile)
          : c17_temporal::temporal_scenario(std::move(input), profile);
  auto prepared =
      c17_temporal::
          prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          std::move(scenario),
          ArrivalInitialState{SharedRoundState{"h0"}},
          std::nullopt,
          [](PlugDescriptor&) {},
          [](const ResolvedInstance& instance,
             const std::span<const QueueId> targets,
             const CompiledArrivalLaw& arrival, const ArrivalPhase&,
             const ArrivalPhase&) {
            return four_word_state_schema(instance, targets, arrival);
          },
          [](const std::span<const QueueId> targets,
             const ExactReducedStateSchemaV1&) {
            return c17::reduced_state(targets, {2U}, false, 0U);
          },
          [audit_targets, reverse_domain_order](
              ExactCausalProgramV1& program) {
            std::vector<ReducedStateV1> domain{
                c17::reduced_state(audit_targets, {2U}, false, 0U),
                c17::reduced_state(audit_targets, {2U}, true, 0U),
                c17::reduced_state(audit_targets, {0U}, false, 0U),
                c17::reduced_state(audit_targets, {0U}, true, 0U)};
            if (reverse_domain_order) {
              std::reverse(domain.begin(), domain.end());
            }
            program.maximum_residence_slots = 2U;
            program.reachable_audit_states = domain;
            program.finite_event_domain_states = std::move(domain);
            program.event_entry_domain_is_exact_state_domain = false;
            program.event_clock_semantics = EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient;
          });
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  c17_temporal::GenericTemporalFrameworkV1 temporal{
      std::move(framework).value(), std::move(prepared.instance),
      std::move(prepared.ordered_targets),
      std::move(prepared.state_schema), std::move(prepared.descriptor),
      std::move(prepared.initial_state),
      std::move(prepared.entrance_mark),
      std::move(prepared.entrance_decoder_calls),
      std::move(prepared.residence_generator_calls)};
  return {std::move(temporal), std::move(realize_calls),
          std::move(enumerate_calls), std::move(callback_clock_or)};
}

}  // namespace mwperf::testing::c20
