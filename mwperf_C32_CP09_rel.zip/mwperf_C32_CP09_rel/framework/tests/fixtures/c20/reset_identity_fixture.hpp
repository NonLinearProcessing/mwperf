#pragma once

#if !defined(MWPERF_C20_TEST_SEAMS)
#error "reset_identity_fixture.hpp is available only to C20 tests"
#endif

#include <cstddef>
#include <cstdint>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/temporal/romr.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing::c20_reset {

[[nodiscard]] inline RuntimeFieldIdV1 field_id(
    const std::string_view name) {
  return RuntimeFieldIdV1(c17::label(name));
}

[[nodiscard]] inline ResourceState one_resource_state(
    const ResolvedInstance& instance, const std::uint64_t workload) {
  std::vector<BigNat> direction_values(instance.queues().size(), BigNat{0U});
  REQUIRE_FALSE(direction_values.empty());
  direction_values.front() = BigNat{1U};
  auto direction = NonnegativeIntegralDirection::from_values(
      QueueDimensionToken::from_instance(instance),
      std::move(direction_values));
  REQUIRE(direction);
  auto coordinate = ResourceCoordinate::make(
      std::move(direction).value(), BigNat{1U}, BigNat{workload},
      BigNat{0U}, BigNat{0U}, true);
  REQUIRE(coordinate);
  auto state = ResourceState::from_coordinates(
      {std::move(coordinate).value()});
  REQUIRE(state);
  return std::move(state).value();
}

[[nodiscard]] inline PairMargin one_margin(
    const ResolvedInstance& instance,
    const std::uint64_t target_workload = 2U) {
  std::vector<BigNat> values(instance.queues().size(), BigNat{1U});
  values.front() = BigNat{target_workload};
  auto backlog = Backlog::from_values(
      QueueDimensionToken::from_instance(instance), std::move(values));
  REQUIRE(backlog);
  auto target = TargetIndex::from_instance(instance, 0U);
  REQUIRE(target);
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(optimizer);
  auto opportunity = compute_target_opportunity(
      instance, backlog.value(), target.value(), optimizer.value());
  REQUIRE(opportunity);

  std::vector<std::uint8_t> forced_out(instance.queues().size(), 0U);
  std::vector<std::uint8_t> forced_in(instance.queues().size(), 0U);
  forced_in.front() = 1U;
  auto out = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), std::move(forced_out));
  auto in = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), std::move(forced_in));
  REQUIRE(out);
  REQUIRE(in);
  auto pair = SchedulePair::make(instance, target.value(),
                                 std::move(out).value(),
                                 std::move(in).value());
  REQUIRE(pair);
  auto margin = evaluate_margin_pair(backlog.value(), pair.value(),
                                     opportunity.value());
  REQUIRE(margin);
  return std::move(margin).value();
}

struct ResetCoordinatesV1 final {
  ExactReducedCoordinatesV1 baseline;
  ArrivalPhase alternate_phase;
  TargetBacklogV1 alternate_backlog;
  ResourceState alternate_resources;
  PairMargin alternate_margin;
  RuntimeFieldIdV1 local_age;
  RuntimeFieldIdV1 persistent_mode;
};

[[nodiscard]] inline ResetCoordinatesV1 reset_coordinates() {
  auto fixture = c17::make_nonmonotone_three_bin_framework();
  auto before_state = c17::reduced_state(fixture.ordered_targets, {2U}, false,
                                         7U);
  auto phase_state = c17::reduced_state(fixture.ordered_targets, {2U}, true,
                                        7U);
  auto backlog_state = c17::reduced_state(fixture.ordered_targets, {3U}, false,
                                          7U);
  auto before = fixture.state_schema.decode(before_state);
  auto phase = fixture.state_schema.decode(phase_state);
  auto backlog = fixture.state_schema.decode(backlog_state);
  REQUIRE(before);
  REQUIRE(phase);
  REQUIRE(backlog);

  const RuntimeFieldIdV1 local_age =
      field_id("c20.fixture.residence-local-age");
  const RuntimeFieldIdV1 persistent_mode =
      field_id("c20.fixture.persistent-mode");
  before.value().resources = one_resource_state(fixture.instance, 1U);
  before.value().margins = {one_margin(fixture.instance)};
  before.value().controller =
      c17::value("c20.fixture.controller", {0x41U});
  before.value().unresolved_fields = {
      {local_age, c17::value("c20.fixture.age", {0x07U})},
      {persistent_mode, c17::value("c20.fixture.mode", {0x02U})}};

  return {std::move(before).value(), phase.value().arrival_phase,
          std::move(backlog).value().backlog,
          one_resource_state(fixture.instance, 2U),
          one_margin(fixture.instance, 3U), local_age, persistent_mode};
}

}  // namespace mwperf::testing::c20_reset
