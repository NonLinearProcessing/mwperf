#pragma once

#if !defined(MWPERF_C20_TEST_SEAMS)
#error "audited_reset_temporal_fixture.hpp is available only to C20 tests"
#endif

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"

namespace mwperf::testing::c20_reset_audited {

namespace temporal_fixture = c17_temporal;
namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

inline constexpr std::size_t kBacklogOffset = 0U;
inline constexpr std::size_t kPhaseOffset = 1U;
inline constexpr std::size_t kBoundaryOffset = 2U;
inline constexpr std::size_t kAgeOffset = 3U;
inline constexpr std::size_t kMarginOffset = 4U;
inline constexpr std::size_t kStateSize = 5U;

inline const CodecIdentityV1 kAgeCodec{"c20.fixture.residence-age", 1U};

[[nodiscard]] inline RuntimeFieldIdV1 age_field() {
  // The reset-only manifest has the two canonical framework fields followed
  // by its sole surrogate-owned field.
  return RuntimeFieldIdV1(designated::label("field.2"));
}

[[nodiscard]] inline RuntimeMarkIdV1 raw_age_mark() {
  // active_component sorts before the entrance phase_label in the C14 mark
  // set, so its stable runtime projection is mark.0.
  return RuntimeMarkIdV1(designated::label("mark.0"));
}

[[nodiscard]] inline RuntimeDecoderIdV1 raw_age_decoder() {
  return RuntimeDecoderIdV1(designated::label("decoder.0"));
}

[[nodiscard]] inline designated::InputV1 reset_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":")json") +
      std::string(matrix::kC20ResetRomrProfile.provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = load_document(
      designated::write_input("c20-reset-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c20-reset-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline PairMargin margin(
    const ResolvedInstance& instance, const std::uint8_t backlog_value,
    const bool alternate_pair) {
  std::vector<BigNat> values(instance.queues().size(), BigNat{0U});
  REQUIRE(values.size() >= 2U);
  values.front() = BigNat{backlog_value};
  auto backlog = Backlog::from_values(
      QueueDimensionToken::from_instance(instance), std::move(values));
  REQUIRE(backlog);
  auto target = TargetIndex::from_instance(instance, 0U);
  REQUIRE(target);
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(optimizer);
  auto opportunity = compute_target_opportunity(
      instance, backlog.value(), target.value(), optimizer.value());
  REQUIRE(opportunity);

  std::vector<std::uint8_t> forced_out(instance.queues().size(), 0U);
  std::vector<std::uint8_t> forced_in(instance.queues().size(), 0U);
  forced_in.front() = 1U;
  if (alternate_pair) {
    forced_out[1U] = 1U;
    forced_in[1U] = 1U;
  }
  auto out = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), std::move(forced_out));
  auto in = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), std::move(forced_in));
  REQUIRE(out);
  REQUIRE(in);
  auto pair = SchedulePair::make(instance, target.value(),
                                 std::move(out).value(),
                                 std::move(in).value());
  REQUIRE(pair);
  auto result = evaluate_margin_pair(backlog.value(), pair.value(),
                                     opportunity.value());
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline ExactReducedStateSchemaV1 state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets, ArrivalPhase before,
    ArrivalPhase after) {
  REQUIRE(ordered_targets.size() == 1U);
  std::vector<QueueId> targets(ordered_targets.begin(), ordered_targets.end());
  auto prototype = TargetBacklogV1::from_values(
      instance, targets, std::vector<BigNat>{BigNat{0U}});
  REQUIRE(prototype);
  auto ordinary_margin_two = std::make_shared<const PairMargin>(
      margin(instance, 2U, false));
  auto alternate_margin_two = std::make_shared<const PairMargin>(
      margin(instance, 2U, true));
  auto ordinary_margin_one = std::make_shared<const PairMargin>(
      margin(instance, 1U, false));
  auto alternate_margin_one = std::make_shared<const PairMargin>(
      margin(instance, 1U, true));
  REQUIRE_FALSE(*ordinary_margin_two == *alternate_margin_two);
  REQUIRE_FALSE(*ordinary_margin_one == *alternate_margin_one);
  const RuntimeFieldIdV1 local_age = age_field();
  const RuntimeMarkIdV1 age_mark = raw_age_mark();

  ExactReducedStateSchemaV1 schema{
      c17::kReducedStateCodec,
      c17::digest("c20.fixture.reset.exact-state-schema"),
      c17::digest("c20.fixture.reset.reduced-state-schema"),
      c17::digest("c20.fixture.reset.ownership-schema"),
      c17::digest("c20.fixture.reset.exact-update-schema"),
      [prototype = std::move(prototype).value(), before, after,
      ordinary_margin_two, alternate_margin_two, ordinary_margin_one,
       alternate_margin_one,
       local_age](const ReducedStateV1& state)
          -> Result<ExactReducedCoordinatesV1> {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != kStateSize) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.reset_state_shape",
              "the reset fixture state has a foreign shape");
        }
        const std::uint8_t phase = std::to_integer<std::uint8_t>(
            state.canonical_value[kPhaseOffset]);
        const std::uint8_t margin_selector =
            std::to_integer<std::uint8_t>(
                state.canonical_value[kMarginOffset]);
        const std::uint8_t backlog_value =
            std::to_integer<std::uint8_t>(
                state.canonical_value[kBacklogOffset]);
        if (phase > 1U || margin_selector > 1U || backlog_value < 1U ||
            backlog_value > 2U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c20.fixture.reset_state_selector",
              "the reset fixture backlog, phase, or margin selector is "
              "invalid");
        }
        auto backlog = prototype.with_values({BigNat{
            backlog_value}});
        if (!backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(backlog.error());
        }
        CanonicalRuntimeValueV1 age{
            kAgeCodec, {state.canonical_value[kAgeOffset]}};
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(backlog).value(), phase == 0U ? before : after,
             BigNat{std::to_integer<std::uint8_t>(
                 state.canonical_value[kBoundaryOffset])},
             std::nullopt,
             {backlog_value == 2U
                  ? (margin_selector == 0U ? *ordinary_margin_two
                                           : *alternate_margin_two)
                  : (margin_selector == 0U ? *ordinary_margin_one
                                           : *alternate_margin_one)},
             std::nullopt,
             {{local_age, std::move(age)}}});
      },
      [before, after, ordinary_margin_two, alternate_margin_two,
       ordinary_margin_one, alternate_margin_one,
       local_age](const ExactReducedCoordinatesV1& coordinates,
                  const UnresolvedPatch& patch) -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != 1U ||
            coordinates.resources.has_value() ||
            coordinates.controller.has_value() ||
            coordinates.margins.size() != 1U ||
            coordinates.unresolved_fields.size() != 1U ||
            coordinates.unresolved_fields.front().field != local_age ||
            coordinates.unresolved_fields.front().value.codec != kAgeCodec ||
            coordinates.unresolved_fields.front().value.canonical_value.size() !=
                1U) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.reset_rebuild_shape",
              "the reset fixture rebuild received a foreign coordinate");
        }
        CanonicalRuntimeValueV1 age =
            coordinates.unresolved_fields.front().value;
        for (const RuntimeFieldPatchV1& update : patch.fields()) {
          if (update.field != local_age || update.value.codec != kAgeCodec ||
              update.value.canonical_value.size() != 1U) {
            return c17::failure<ReducedStateV1>(
                "c20.fixture.reset_patch_shape",
                "the reset fixture received a foreign unresolved patch");
          }
          age = update.value;
        }
        const bool before_phase =
            c17::same_phase(coordinates.arrival_phase, before);
        const bool after_phase =
            c17::same_phase(coordinates.arrival_phase, after);
        if ((!before_phase && !after_phase) ||
            coordinates.boundary_index.bit_length() > 8U ||
            coordinates.backlog.value_at_target_ordinal(0U).bit_length() >
                8U) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.reset_rebuild_exact_value",
              "the reset fixture cannot encode an exact coordinate");
        }
        const BigNat& encoded_backlog =
            coordinates.backlog.value_at_target_ordinal(0U);
        if (!(encoded_backlog == BigNat{1U}) &&
            !(encoded_backlog == BigNat{2U})) {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.reset_rebuild_backlog",
              "the reset fixture received an unencodable exact backlog");
        }
        const PairMargin& ordinary_margin =
            encoded_backlog == BigNat{2U} ? *ordinary_margin_two
                                          : *ordinary_margin_one;
        const PairMargin& alternate_margin =
            encoded_backlog == BigNat{2U} ? *alternate_margin_two
                                          : *alternate_margin_one;
        std::uint8_t margin_selector = 0U;
        if (coordinates.margins.front() == ordinary_margin) {
          margin_selector = 0U;
        } else if (coordinates.margins.front() == alternate_margin) {
          margin_selector = 1U;
        } else {
          return c17::failure<ReducedStateV1>(
              "c20.fixture.reset_rebuild_margin",
              "the reset fixture received an unknown exact margin");
        }
        return Result<ReducedStateV1>::success(
            {c17::kReducedStateCodec,
             {static_cast<std::byte>(
                  coordinates.backlog.value_at_target_ordinal(0U)
                      .value()
                      .convert_to<std::uint8_t>()),
              after_phase ? std::byte{0x01} : std::byte{0x00},
              static_cast<std::byte>(coordinates.boundary_index.value()
                                         .convert_to<std::uint8_t>()),
              age.canonical_value.front(),
              static_cast<std::byte>(margin_selector)}});
      },
      [](const ReducedStateV1& state) {
        if (state.codec != c17::kReducedStateCodec ||
            state.canonical_value.size() != kStateSize ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[kBacklogOffset]) < 1U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[kBacklogOffset]) > 2U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[kPhaseOffset]) > 1U ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[kMarginOffset]) > 1U) {
          return c17::failure<void>(
              "c20.fixture.reset_state_domain",
              "the reset fixture state is outside its exact domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {{{raw_age_decoder(), age_mark,
         MarkDecoderSourceV1::completed_edge,
         {"c17.fixture.temporal.completed-edge-projection", 1U},
         kAgeCodec}},
       [local_age, age_mark](const ExactReducedCoordinatesV1&,
                             const ExactReducedCoordinatesV1& after,
                             const OpportunityMark&, const ResolvedAction&,
                             const ArrivalTransition&, const PostClosure&)
           -> Result<std::vector<RuntimeDecodedMarkV1>> {
         const auto age = std::ranges::find_if(
             after.unresolved_fields,
             [&](const RuntimeFieldPatchV1& field) {
               return field.field == local_age;
             });
         if (age == after.unresolved_fields.end()) {
           return c17::failure<std::vector<RuntimeDecodedMarkV1>>(
               "c20.fixture.reset_raw_age_missing",
               "the completed edge omitted its raw residence age");
         }
         return Result<std::vector<RuntimeDecodedMarkV1>>::success(
             {{age_mark, age->value}});
       }}};
  return schema;
}

enum class ResetFaultV1 : std::uint8_t {
  none,
  entry_phase,
  terminal_margin,
};

[[nodiscard]] inline matrix::C17TemporalFixtureOverrideV1 operation_override(
    const ResetFaultV1 fault) {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.maximum_residence_slots = 1U;
  override.residence_local_reset_fields = {age_field()};
  override.c_plus_writable_unresolved_fields = {age_field()};

  const QueueId target = designated::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto c_minus = [opportunity_codec, target](const CMinusInputV1&)
      -> Result<CMinusOutputV1> {
    return Result<CMinusOutputV1>::success(
        {{opportunity_codec, {std::byte{0x00}}}, {},
         V0EmittedOpportunityFaceV1{
             {{{}, {}, ExactRational::zero()},
              {{target}, {}, ExactRational::zero()}}},
         std::nullopt});
  };
  override.c_minus = [c_minus](const CMinusInputV1& input,
                                DeterministicRng&) {
    return c_minus(input);
  };
  override.enumerate_c_minus = [c_minus](const CMinusInputV1& input) {
    auto value = c_minus(input);
    if (!value) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          value.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    REQUIRE(mass);
    return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
        {{std::move(value).value(), std::move(mass).value()}});
  };

  const auto c_plus = [](const CPlusInputV1&) -> Result<CPlusOutputV1> {
    return Result<CPlusOutputV1>::success(
        {{{age_field(),
           {kAgeCodec, {std::byte{0x07}}}}},
         {}});
  };
  override.c_plus = [c_plus](const CPlusInputV1& input,
                             DeterministicRng&) { return c_plus(input); };
  override.enumerate_c_plus = [c_plus](const CPlusInputV1& input) {
    auto value = c_plus(input);
    if (!value) {
      return Result<std::vector<EnumeratedCPlusAtomV1>>::failure(
          value.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    REQUIRE(mass);
    return Result<std::vector<EnumeratedCPlusAtomV1>>::success(
        {{std::move(value).value(), std::move(mass).value()}});
  };

  override.entry_initializer =
      [fault](const CanonicalRuntimeValueV1& input)
          -> Result<CanonicalRuntimeValueV1> {
    if (input.codec != c17::kReducedStateCodec ||
        input.canonical_value.size() != kStateSize) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c20.fixture.reset_initializer_shape",
          "the reset initializer received a foreign state");
    }
    CanonicalRuntimeValueV1 output = input;
    output.canonical_value[kAgeOffset] = std::byte{0x00};
    const bool event_entry =
        output.canonical_value[kBoundaryOffset] == std::byte{0x00};
    if (fault == ResetFaultV1::entry_phase && event_entry) {
      output.canonical_value[kPhaseOffset] =
          output.canonical_value[kPhaseOffset] == std::byte{0x00}
              ? std::byte{0x01}
              : std::byte{0x00};
    }
    if (fault == ResetFaultV1::terminal_margin && !event_entry) {
      output.canonical_value[kMarginOffset] = std::byte{0x01};
    }
    return Result<CanonicalRuntimeValueV1>::success(std::move(output));
  };
  override.stopping_indicator = [](const CanonicalRuntimeValueV1&) {
    return Result<CanonicalRuntimeValueV1>::success(
        {{"c17.fixture.temporal.indicator", 1U}, {std::byte{0x01}}});
  };
  override.terminal_reentry = [](
                                      const EventTerminalReentryInputV1& input) {
    return Result<CanonicalRuntimeValueV1>::success(input.successor_state);
  };
  return override;
}

[[nodiscard]] inline temporal_fixture::GenericTemporalFrameworkV1 framework(
    const ResetFaultV1 fault = ResetFaultV1::none) {
  matrix::C17TemporalFixtureOverrideV1 override = operation_override(fault);
  matrix::ScopedC17TemporalFixtureOverride scope(override);
  auto prepared =
      temporal_fixture::
          prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          temporal_fixture::temporal_scenario(
              reset_input(), matrix::kC20ResetRomrProfile),
          ArrivalInitialState{TraceOrigin{}}, std::nullopt,
          [](PlugDescriptor&) {},
          [](const ResolvedInstance& instance,
             const std::span<const QueueId> targets,
             const CompiledArrivalLaw&, const ArrivalPhase& before,
             const ArrivalPhase& after) {
            return state_schema(instance, targets, before, after);
          },
          [](const std::span<const QueueId>,
             const ExactReducedStateSchemaV1&) {
            return ReducedStateV1{
                c17::kReducedStateCodec,
                {std::byte{0x02}, std::byte{0x00}, std::byte{0x00},
                 std::byte{0x07}, std::byte{0x00}}};
          },
          [](ExactCausalProgramV1& program) {
            program.maximum_residence_slots = 1U;
          });
  auto audited = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((audited ? std::string{}
                : audited.error().code + ": " + audited.error().message));
  REQUIRE(audited);
  return {std::move(audited).value(), std::move(prepared.instance),
          std::move(prepared.ordered_targets),
          std::move(prepared.state_schema), std::move(prepared.descriptor),
          std::move(prepared.initial_state),
          std::move(prepared.entrance_mark),
          std::move(prepared.entrance_decoder_calls),
          std::move(prepared.residence_generator_calls)};
}

[[nodiscard]] inline std::uint8_t state_byte(
    const CanonicalRuntimeValueV1& state, const std::size_t offset) {
  REQUIRE(state.canonical_value.size() == kStateSize);
  return std::to_integer<std::uint8_t>(state.canonical_value[offset]);
}

}  // namespace mwperf::testing::c20_reset_audited
