#pragma once

#if !defined(MWPERF_C21_TEST_SEAMS)
#error "stationary_suspension_fixture.hpp is available only to C21 tests"
#endif

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c20/audited_reset_temporal_fixture.hpp"
#include "fixtures/c20/enumerable_four_word_fixture.hpp"
#include "mwperf/stationary/suspension.hpp"

namespace mwperf::testing::c21 {

namespace temporal_fixture = c17_temporal;
namespace matrix = c16_registered_pair_matrix;
namespace designated = c16_designated_detail;

inline constexpr std::size_t kBacklogOffset = 0U;
inline constexpr std::size_t kPhaseOffset = 1U;
inline constexpr std::size_t kBoundaryOffset = 2U;
inline constexpr std::size_t kAgeOffset = 3U;
inline constexpr std::size_t kStateSize = 4U;

enum class EventSelectionFixtureV1 : std::uint8_t {
  equal_mixture,
  nonunit_equal_mixture,
  unique,
  transient_class,
  unknown_class,
};

enum class ProjectionPlanFixtureV1 : std::uint8_t {
  stationary_reward,
  stationary_pmf,
  stationary_pmf_window,
  stationary_pgf,
  stationary_quantile,
  evolving_phase,
  finite_cylinder,
  audited_temporal_law,
  mean_binary_run,
  stationary_stopped,
  fifo_service,
};

struct StationarySuspensionFixtureV1 final {
  temporal_fixture::GenericTemporalFrameworkV1 temporal;
  AuditedResidenceProvider provider;
  FiniteEventStateDomain domain;
  EmbeddedKernel kernel;
  ReducedStateV1 class_a;
  ReducedStateV1 class_b;
  // This spy is attached to the descriptor-bound completed-edge age decoder.
  // It records only that decoder's callback-visible pre-state clock.
  std::shared_ptr<std::atomic<unsigned>> completed_decoder_clock_or;
};

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline SourceNode source(
    const std::string& pointer = "/c21-test") {
  return SourceNode::make_null(
      SourceLocation{"c21-stationary-suspension-test", 1U, 1U, 0U},
      pointer);
}

[[nodiscard]] inline AuthoredProbability probability(
    const ExactRational& value) {
  auto result = AuthoredProbability::from_exact(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline SelectionSpec equal_mixture_selection() {
  std::vector<StationaryMixtureComponent> components;
  components.push_back(
      {TypedLabel::numeric(BigNat{0U}), probability(rational(1, 2)),
       source("/selection/components/0")});
  components.push_back(
      {TypedLabel::numeric(BigNat{1U}), probability(rational(1, 2)),
       source("/selection/components/1")});
  return StationaryMixtureSelection{std::move(components),
                                    source("/selection")};
}

[[nodiscard]] inline SelectionSpec unique_selection() {
  return StationaryUniqueSelection{source("/selection")};
}

[[nodiscard]] inline SelectionSpec unknown_class_selection() {
  return StationaryClassSelection{TypedLabel::numeric(BigNat{99U}),
                                  source("/selection")};
}

[[nodiscard]] inline const SelectionSpec& configured_selection(
    const StationarySuspensionFixtureV1& fixture) {
  REQUIRE(fixture.temporal.instance.analysis_spec().context);
  return fixture.temporal.instance.analysis_spec().context->selection;
}

[[nodiscard]] inline SolverPolicy solver_policy(
    const StationarySuspensionFixtureV1& fixture) {
  return {LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000000LL), ExactRational::zero(),
          fixture.temporal.instance.fingerprints().analysis};
}

[[nodiscard]] inline std::string selection_json(
    const EventSelectionFixtureV1 selection) {
  switch (selection) {
    case EventSelectionFixtureV1::equal_mixture:
    case EventSelectionFixtureV1::nonunit_equal_mixture:
      return R"json({"kind":"stationary_mixture","parameters":{"components":[{"class_id":0,"probability":0.5},{"class_id":1,"probability":0.5}]}})json";
    case EventSelectionFixtureV1::unique:
      return R"json({"kind":"stationary_unique","parameters":{}})json";
    case EventSelectionFixtureV1::transient_class:
      return R"json({"kind":"stationary_class","parameters":{"class_id":1}})json";
    case EventSelectionFixtureV1::unknown_class:
      return R"json({"kind":"stationary_class","parameters":{"class_id":99}})json";
  }
  return {};
}

[[nodiscard]] inline designated::InputV1 suspension_input(
    const EventSelectionFixtureV1 selection,
    const ExactRational& configured_phase_zero,
    const ExactRational& configured_phase_one,
    const ProjectionPlanFixtureV1 plan =
        ProjectionPlanFixtureV1::stationary_reward,
    const bool identity_variant = false) {
  static constexpr std::string_view base_model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q1"},{"id":"q2"},{"id":"q0"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"a"},{"id":"b"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":1,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q1"},
                      {"source_id":"b","d":4,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h1","probability":1,
         "emissions":[{"source_id":"a","d":3,"queue_id":"q1"},
                      {"source_id":"b","d":2,"queue_id":"q2"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  // The FIFO variant uses q0 as the first C09 fixture coordinate.  In its
  // selected absorbing phase this gives exactly one q0 admission per slot;
  // its operation override serves exactly one q0 packet, preserving the
  // fixture's stationary backlog of one and yielding positive finite
  // admission intensity without an invented entrance law.
  static constexpr std::string_view fifo_model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"a"},{"id":"b"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":1,
         "emissions":[{"source_id":"a","d":1,"queue_id":"q0"},
                      {"source_id":"b","d":4,"queue_id":"q1"}]},
        {"state":"h1","next_state":"h1","probability":1,
         "emissions":[{"source_id":"a","d":3,"queue_id":"q0"},
                      {"source_id":"b","d":2,"queue_id":"q1"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string_view metric = [&]() -> std::string_view {
    switch (plan) {
      case ProjectionPlanFixtureV1::stationary_reward:
        return R"json({"id":"c21-empty","kind":"stationary_empty_probability","parameters":{}})json";
      case ProjectionPlanFixtureV1::stationary_pmf:
        return R"json({"id":"c21-pmf","kind":"stationary_backlog_pmf","parameters":{}})json";
      case ProjectionPlanFixtureV1::stationary_pmf_window:
        return R"json({"id":"c21-pmf-window","kind":"stationary_backlog_pmf","parameters":{"max_level":0}})json";
      case ProjectionPlanFixtureV1::stationary_pgf:
        return R"json({"id":"c21-pgf","kind":"stationary_backlog_pgf","parameters":{"points":[0,0.5,1,2]}})json";
      case ProjectionPlanFixtureV1::stationary_quantile:
        return R"json({"id":"c21-quantile","kind":"stationary_backlog_quantile","parameters":{"probability":0.5}})json";
      case ProjectionPlanFixtureV1::evolving_phase:
        return R"json({"id":"c21-evolving","kind":"stationary_empty_probability","parameters":{}})json";
      case ProjectionPlanFixtureV1::finite_cylinder:
        return R"json({"id":"c21-persistence","kind":"service_persistence","parameters":{}})json";
      case ProjectionPlanFixtureV1::audited_temporal_law:
        return R"json({"id":"c21-autocovariance","kind":"service_autocovariance","parameters":{"lags":[6]}})json";
      case ProjectionPlanFixtureV1::mean_binary_run:
        return R"json({"id":"c21-mean-run","kind":"mean_binary_run","parameters":{"predicate":"busy"}})json";
      case ProjectionPlanFixtureV1::stationary_stopped:
        return R"json({"id":"c21-hit","kind":"first_hit","parameters":{"set":{"kind":"equal","level":2},"horizon":4,"include_mean":false}})json";
      case ProjectionPlanFixtureV1::fifo_service:
        return R"json({"id":"c21-fifo","kind":"fifo_delay","parameters":{"output":"pmf","horizon":4}})json";
    }
    return {};
  }();
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + std::string(metric) + R"json(],
    "surrogate":{"id":")json" +
      std::string(matrix::kC20ResetRomrProfile.provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":0,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" +
      selection_json(selection) + R"json(,
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  std::string model_text(
      plan == ProjectionPlanFixtureV1::fifo_service ? fifo_model : base_model);
  if (identity_variant) {
    const std::size_t seed = model_text.find(R"json("seed":17)json");
    REQUIRE(seed != std::string::npos);
    model_text.replace(seed, std::string_view{R"json("seed":17)json"}.size(),
                       R"json("seed":18)json");
  }
  auto model_document = load_document(designated::write_input(
      "c21-suspension-model", model_text));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c21-suspension-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  REQUIRE(instance);

  auto law = plan == ProjectionPlanFixtureV1::evolving_phase
                 ? make_c09_time_homogeneous_correlated_fixture_law(
                       instance.value().queues())
                 : make_c09_absorbing_two_phase_time_homogeneous_fixture_law(
                       instance.value().queues(), configured_phase_zero,
                       configured_phase_one);
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  auto arrival =
      std::make_shared<const CompiledArrivalLaw>(std::move(law).value());
  auto rebound = C20ArrivalFixtureAccess::bind(instance.value(), arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  auto request = parse_metric_request(
      rebound.value().analysis_spec().metrics.front(),
      rebound.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(rebound).value(), std::move(arrival),
          std::move(requirements), std::move(request).value()};
}

// The generic C17 fixture predates C21 and seals only its historical
// residence/stopped route. Rebind the otherwise identical contract by
// selecting actual complete C14 route alternatives from this request.  A
// desired backend is admitted only when the requirement clause offers it at
// this provider's runtime access; this prevents the test fixture from merely
// relabelling an unrelated throughput or temporal contract.
[[nodiscard]] inline std::vector<BackendRouteKindV1> projection_plan_routes(
    const ProjectionPlanFixtureV1 plan) {
  switch (plan) {
    case ProjectionPlanFixtureV1::stationary_reward:
      return {BackendRouteKindV1::stationary_invariant,
              BackendRouteKindV1::stationary_edge_reward};
    case ProjectionPlanFixtureV1::stationary_pmf:
    case ProjectionPlanFixtureV1::stationary_pmf_window:
    case ProjectionPlanFixtureV1::stationary_pgf:
    case ProjectionPlanFixtureV1::stationary_quantile:
      return {BackendRouteKindV1::stationary_invariant};
    case ProjectionPlanFixtureV1::evolving_phase:
      return {BackendRouteKindV1::stationary_invariant,
              BackendRouteKindV1::stationary_edge_reward};
    case ProjectionPlanFixtureV1::finite_cylinder:
    case ProjectionPlanFixtureV1::audited_temporal_law:
      return {BackendRouteKindV1::finite_temporal_cylinder};
    case ProjectionPlanFixtureV1::mean_binary_run:
      return {BackendRouteKindV1::analytic_metric_family};
    case ProjectionPlanFixtureV1::stationary_stopped:
      return {BackendRouteKindV1::residence_or_stopped_law};
    case ProjectionPlanFixtureV1::fifo_service:
      return {BackendRouteKindV1::palm_or_fifo_law};
  }
  return {};
}

[[nodiscard]] inline C16DesignatedScenarioV1 stationary_temporal_scenario(
    designated::InputV1 input, const matrix::ProfileV1& profile,
    const ProjectionPlanFixtureV1 plan =
        ProjectionPlanFixtureV1::stationary_reward) {
  C16DesignatedScenarioV1 scenario =
      temporal_fixture::temporal_scenario(std::move(input), profile);
  std::vector<ResolvedMetricContractV1> contracts;
  const auto negotiated_contracts = scenario.contract.metric_contracts();
  const auto append_route = [&](const BackendRouteKindV1 desired) {
    bool matched = false;
    for (const MetricRequirementClause& clause :
         scenario.requirements.clauses()) {
      const auto route = std::ranges::find_if(
          clause.route_alternatives,
          [&](const MetricRouteAlternativeV1& alternative) {
            return alternative.access.backend_route == desired &&
                   alternative.access.runtime_access == profile.access;
          });
      if (route == clause.route_alternatives.end()) {
        continue;
      }
      matched = true;
      const auto negotiated = std::ranges::find_if(
          negotiated_contracts,
          [&](const ResolvedMetricContractV1& candidate) {
            return candidate.clause_id == clause.origin.clause_id &&
                   candidate.authored_metric_index ==
                       clause.origin.clause_id.authored_index &&
                   candidate.metric_id == clause.origin.clause_id.metric_id;
          });
      REQUIRE(negotiated != negotiated_contracts.end());
      contracts.push_back(ResolvedMetricContractV1{
          clause.origin.clause_id.authored_index,
          clause.origin.clause_id,
          clause.origin.clause_id.metric_id,
          clause.origin.ordered_targets,
          profile.semantic,
          profile.access,
          route->semantic.coupling,
          clause.access.solver_regime,
          desired,
          negotiated->support_clause_digest});
      // A FIFO analysis can legitimately request several readouts and Palm
      // conditions from one projection.  Preserve every accepted FIFO
      // clause so C23 tests exercise the real multi-request contract.  Older
      // fixture plans retain their historical single-route behavior.
      if (plan != ProjectionPlanFixtureV1::fifo_service) {
        return;
      }
    }
    if (!matched) {
      FAIL("the C21 fixture request has no matching accepted route");
    }
  };
  for (const BackendRouteKindV1 route : projection_plan_routes(plan)) {
    append_route(route);
  }

  auto budget_digest = digest_construction_budget_v1(scenario.budget);
  REQUIRE(budget_digest);
  const PreviewPoliciesV1 policies{
      PointDeploymentPolicyV1::not_applicable,
      CoefficientCompletionPolicyV1::not_applicable,
      ProjectionPolicyV1::not_applicable,
      RecodingPolicyV1::not_applicable,
      EvidenceRolePolicyV1::exact_manifest_roles};
  auto contract = C15ProtocolFixtureFactory::accepted_contract(
      scenario.provider.manifest().value(), scenario.preview.core,
      *scenario.preview.metric_support_manifest, scenario.requirements,
      scenario.view.configured_arrival().capabilities(), std::move(contracts),
      scenario.preview.construction_target_scope, policies,
      scenario.preview.construction_prerequisites,
      scenario.view.canonical_digest().value(),
      scenario.parameters.canonical_value_digest(), budget_digest.value());
  auto request = make_surrogate_build_request(
      scenario.provider.manifest(), scenario.view, contract,
      scenario.parameters, scenario.budget, MasterSeed{0xC1710U});
  REQUIRE(request);
  scenario.contract = std::move(contract);
  scenario.request = std::move(request).value();
  return scenario;
}

[[nodiscard]] inline ReducedStateV1 state(
    const std::span<const QueueId> targets, const std::uint8_t phase,
    const std::uint8_t boundary = 0U, const std::uint8_t age = 0U) {
  REQUIRE(targets.size() == 1U);
  return {c17::kReducedStateCodec,
          {std::byte{0x01}, static_cast<std::byte>(phase),
           static_cast<std::byte>(boundary), static_cast<std::byte>(age)}};
}

[[nodiscard]] inline ExactReducedStateSchemaV1 suspension_state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const CompiledArrivalLaw& configured_arrival,
    std::shared_ptr<std::atomic<unsigned>> completed_decoder_clock_or) {
  REQUIRE(ordered_targets.size() == 1U);
  std::vector<QueueId> targets(ordered_targets.begin(),
                               ordered_targets.end());
  auto prototype = TargetBacklogV1::from_values(
      instance, targets, std::vector<BigNat>{BigNat{0U}});
  REQUIRE(prototype);

  std::vector<ArrivalPhase> phases;
  phases.reserve(8U);
  for (std::uint8_t boundary = 0U; boundary != 4U; ++boundary) {
    for (std::uint8_t phase = 0U; phase != 2U; ++phase) {
      auto value = make_c09_fixture_phase_for_testing(
          configured_arrival, phase, BigNat{boundary});
      REQUIRE(value);
      phases.push_back(std::move(value).value());
    }
  }
  auto phase_table =
      std::make_shared<const std::vector<ArrivalPhase>>(std::move(phases));
  const RuntimeFieldIdV1 local_age = c20_reset_audited::age_field();
  const RuntimeMarkIdV1 age_mark = c20_reset_audited::raw_age_mark();

  return {
      c17::kReducedStateCodec,
      c17::digest("c21.fixture.suspension.exact-state-schema"),
      c17::digest("c21.fixture.suspension.reduced-state-schema"),
      c17::digest("c21.fixture.suspension.ownership-schema"),
      c17::digest("c21.fixture.suspension.exact-update-schema"),
      [prototype = std::move(prototype).value(), phase_table,
       local_age](const ReducedStateV1& input)
          -> Result<ExactReducedCoordinatesV1> {
        if (input.codec != c17::kReducedStateCodec ||
            input.canonical_value.size() != kStateSize ||
            input.canonical_value[kBacklogOffset] != std::byte{0x01}) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c21.fixture.suspension_state_shape",
              "the suspension fixture state has a foreign shape");
        }
        const std::uint8_t phase = std::to_integer<std::uint8_t>(
            input.canonical_value[kPhaseOffset]);
        const std::uint8_t boundary = std::to_integer<std::uint8_t>(
            input.canonical_value[kBoundaryOffset]);
        const std::uint8_t age = std::to_integer<std::uint8_t>(
            input.canonical_value[kAgeOffset]);
        if (phase > 1U || boundary > 3U || age > 3U) {
          return c17::failure<ExactReducedCoordinatesV1>(
              "c21.fixture.suspension_state_range",
              "the suspension fixture phase, boundary, or age is out of range");
        }
        auto backlog = prototype.with_values({BigNat{1U}});
        if (!backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(backlog.error());
        }
        const std::size_t phase_index =
            static_cast<std::size_t>(boundary) * 2U + phase;
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(backlog).value(), (*phase_table)[phase_index],
             BigNat{boundary}, std::nullopt, {}, std::nullopt,
             {{local_age,
               {c20_reset_audited::kAgeCodec,
                {static_cast<std::byte>(age)}}}}});
      },
      [phase_table, local_age](const ExactReducedCoordinatesV1& coordinates,
                               const UnresolvedPatch& patch)
          -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != 1U ||
            coordinates.backlog.value_at_target_ordinal(0U) != BigNat{1U} ||
            coordinates.resources.has_value() || !coordinates.margins.empty() ||
            coordinates.controller.has_value() ||
            coordinates.unresolved_fields.size() != 1U ||
            coordinates.unresolved_fields.front().field != local_age ||
            coordinates.unresolved_fields.front().value.codec !=
                c20_reset_audited::kAgeCodec ||
            coordinates.unresolved_fields.front().value.canonical_value.size() !=
                1U ||
            coordinates.boundary_index.bit_length() > 8U) {
          return c17::failure<ReducedStateV1>(
              "c21.fixture.suspension_rebuild_shape",
              "the suspension fixture rebuild received a foreign coordinate");
        }
        CanonicalRuntimeValueV1 age =
            coordinates.unresolved_fields.front().value;
        for (const RuntimeFieldPatchV1& update : patch.fields()) {
          if (update.field != local_age ||
              update.value.codec != c20_reset_audited::kAgeCodec ||
              update.value.canonical_value.size() != 1U) {
            return c17::failure<ReducedStateV1>(
                "c21.fixture.suspension_patch_shape",
                "the suspension fixture received a foreign unresolved patch");
          }
          age = update.value;
        }
        const auto canonical =
            arrival_phase_canonical_state(coordinates.arrival_phase);
        if (arrival_phase_family(coordinates.arrival_phase) !=
                ArrivalFamily::shared_joint_round_markov_renewal ||
            canonical.size() != 1U ||
            (canonical.front() != std::byte{0U} &&
             canonical.front() != std::byte{1U})) {
          return c17::failure<ReducedStateV1>(
              "c21.fixture.suspension_rebuild_phase",
              "the suspension fixture rebuild received a foreign phase");
        }
        const std::uint8_t boundary =
            coordinates.boundary_index.value().convert_to<std::uint8_t>();
        if (boundary > 3U) {
          return c17::failure<ReducedStateV1>(
              "c21.fixture.suspension_rebuild_boundary",
              "the suspension fixture boundary is out of range");
        }
        const std::uint8_t phase =
            std::to_integer<std::uint8_t>(canonical.front());
        const ArrivalPhase& expected =
            (*phase_table)[static_cast<std::size_t>(boundary) * 2U + phase];
        if (!c17::same_phase(expected, coordinates.arrival_phase)) {
          return c17::failure<ReducedStateV1>(
              "c21.fixture.suspension_rebuild_binding",
              "the suspension fixture phase has foreign provenance");
        }
        return Result<ReducedStateV1>::success(
            {c17::kReducedStateCodec,
             {std::byte{0x01}, static_cast<std::byte>(phase),
              static_cast<std::byte>(boundary),
              age.canonical_value.front()}});
      },
      [](const ReducedStateV1& input) {
        if (input.codec != c17::kReducedStateCodec ||
            input.canonical_value.size() != kStateSize ||
            input.canonical_value[kBacklogOffset] != std::byte{0x01} ||
            std::to_integer<std::uint8_t>(
                input.canonical_value[kPhaseOffset]) > 1U ||
            std::to_integer<std::uint8_t>(
                input.canonical_value[kAgeOffset]) > 3U) {
          return c17::failure<void>(
              "c21.fixture.suspension_state_domain",
              "state is outside the suspension fixture exact domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {{{c20_reset_audited::raw_age_decoder(), age_mark,
         MarkDecoderSourceV1::completed_edge,
         {"c17.fixture.temporal.completed-edge-projection", 1U},
         c20_reset_audited::kAgeCodec}},
       [local_age, age_mark,
        completed_decoder_clock_or =
            std::move(completed_decoder_clock_or)](
           const ExactReducedCoordinatesV1& before,
                             const ExactReducedCoordinatesV1& after,
                             const OpportunityMark&, const ResolvedAction&,
                             const ArrivalTransition&, const PostClosure&)
           -> Result<std::vector<RuntimeDecodedMarkV1>> {
         completed_decoder_clock_or->fetch_or(
             before.boundary_index.value().convert_to<unsigned>(),
             std::memory_order_relaxed);
         const auto age = std::ranges::find_if(
             after.unresolved_fields,
             [&](const RuntimeFieldPatchV1& field) {
               return field.field == local_age;
             });
         if (age == after.unresolved_fields.end()) {
           return c17::failure<std::vector<RuntimeDecodedMarkV1>>(
               "c21.fixture.suspension_age_missing",
               "the completed edge omitted its residence age");
         }
         return Result<std::vector<RuntimeDecodedMarkV1>>::success(
             {{age_mark, age->value}});
       }}};
}

[[nodiscard]] inline matrix::C17TemporalFixtureOverrideV1
suspension_operation_override(const std::uint8_t class_b_length = 3U,
                              const bool serve_target = false,
                              const bool evolving_phase = false) {
  REQUIRE(class_b_length >= 1U);
  REQUIRE(class_b_length <= 3U);
  matrix::C17TemporalFixtureOverrideV1 override;
  override.maximum_residence_slots = class_b_length;
  override.residence_local_reset_fields = {
      c20_reset_audited::age_field()};
  override.c_plus_writable_unresolved_fields = {
      c20_reset_audited::age_field()};

  const QueueId target = designated::queue("q0");
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  const auto c_minus = [target, opportunity_codec,
                        serve_target](const CMinusInputV1&)
      -> Result<CMinusOutputV1> {
    const ExactRational high = rational(10, 1);
    const ExactRational zero = ExactRational::zero();
    std::vector<V0ScheduleFaceAtomV1> alternatives;
    alternatives.reserve(2U);
    if (serve_target) {
      alternatives.push_back({{}, {}, zero});
      alternatives.push_back({{target}, {}, high});
    } else {
      alternatives.push_back({{}, {}, high});
      alternatives.push_back({{target}, {}, zero});
    }
    return Result<CMinusOutputV1>::success(
        {{opportunity_codec, {std::byte{0x00}}}, {},
         V0EmittedOpportunityFaceV1{std::move(alternatives)},
         std::nullopt});
  };
  override.c_minus = [c_minus](const CMinusInputV1& input,
                                DeterministicRng&) {
    return c_minus(input);
  };
  override.enumerate_c_minus = [c_minus](const CMinusInputV1& input) {
    auto value = c_minus(input);
    if (!value) {
      return Result<std::vector<EnumeratedCMinusAtomV1>>::failure(
          value.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    REQUIRE(mass);
    return Result<std::vector<EnumeratedCMinusAtomV1>>::success(
        {{std::move(value).value(), std::move(mass).value()}});
  };

  const auto c_plus = [](const CPlusInputV1& input)
      -> Result<CPlusOutputV1> {
    if (input.prearrival_state.codec != c17::kReducedStateCodec ||
        input.prearrival_state.canonical_value.size() != kStateSize) {
      return c17::failure<CPlusOutputV1>(
          "c21.fixture.suspension_cplus_shape",
          "the suspension fixture C-plus input has a foreign shape");
    }
    const std::uint8_t age = std::to_integer<std::uint8_t>(
        input.prearrival_state.canonical_value[kAgeOffset]);
    if (age >= 3U) {
      return c17::failure<CPlusOutputV1>(
          "c21.fixture.suspension_cplus_age",
          "the suspension fixture cannot advance beyond age three");
    }
    return Result<CPlusOutputV1>::success(
        {{{c20_reset_audited::age_field(),
           {c20_reset_audited::kAgeCodec,
            {static_cast<std::byte>(age + 1U)}}}},
         {}});
  };
  override.c_plus = [c_plus](const CPlusInputV1& input,
                             DeterministicRng&) { return c_plus(input); };
  override.enumerate_c_plus = [c_plus](const CPlusInputV1& input) {
    auto value = c_plus(input);
    if (!value) {
      return Result<std::vector<EnumeratedCPlusAtomV1>>::failure(
          value.error());
    }
    auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
    REQUIRE(mass);
    return Result<std::vector<EnumeratedCPlusAtomV1>>::success(
        {{std::move(value).value(), std::move(mass).value()}});
  };

  override.entry_initializer = [](const CanonicalRuntimeValueV1& input)
      -> Result<CanonicalRuntimeValueV1> {
    if (input.codec != c17::kReducedStateCodec ||
        input.canonical_value.size() != kStateSize) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c21.fixture.suspension_initializer_shape",
          "the suspension fixture initializer received a foreign state");
    }
    CanonicalRuntimeValueV1 output = input;
    output.canonical_value[kAgeOffset] = std::byte{0x00};
    return Result<CanonicalRuntimeValueV1>::success(std::move(output));
  };
  override.stopping_indicator = [class_b_length, evolving_phase](
                                    const CanonicalRuntimeValueV1& input)
      -> Result<CanonicalRuntimeValueV1> {
    if (input.codec != c17::kReducedStateCodec ||
        input.canonical_value.size() != kStateSize) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c21.fixture.suspension_stop_shape",
          "the suspension fixture stop received a foreign state");
    }
    const std::uint8_t phase = std::to_integer<std::uint8_t>(
        input.canonical_value[kPhaseOffset]);
    const std::uint8_t age = std::to_integer<std::uint8_t>(
        input.canonical_value[kAgeOffset]);
    const bool stops = evolving_phase
                           ? (age == class_b_length ||
                              (phase == 0U && age == 1U))
                           : ((phase == 0U && age == 1U) ||
                              (phase == 1U && age == class_b_length));
    return Result<CanonicalRuntimeValueV1>::success(
        {{"c17.fixture.temporal.indicator", 1U},
         {stops ? std::byte{0x01} : std::byte{0x00}}});
  };
  override.terminal_reentry = [](
                                  const EventTerminalReentryInputV1& input) {
    if (input.successor_state.codec != c17::kReducedStateCodec ||
        input.successor_state.canonical_value.size() != kStateSize) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c21.fixture.suspension_reentry_shape",
          "the suspension fixture terminal reentry received a foreign "
          "state");
    }
    CanonicalRuntimeValueV1 output = input.successor_state;
    // Residence age is explicitly declared local/resettable by the V0
    // descriptor.  The completed final edge keeps its age-L successor, while
    // only the next event entry is returned to the age-zero domain.
    output.canonical_value[kAgeOffset] = std::byte{0x00};
    return Result<CanonicalRuntimeValueV1>::success(std::move(output));
  };
  override.predecision_projection = [](
      const EventPredecisionProjectionInputV1& input) {
    if (input.completed_prefix.size() > 0xffU) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c21.fixture.suspension_projection_overflow",
          "the suspension fixture prefix exceeded one byte");
    }
    return Result<CanonicalRuntimeValueV1>::success(
        {{"c17.fixture.temporal.predecision-projection", 1U},
         {static_cast<std::byte>(input.completed_prefix.size())}});
  };
  override.completed_edge_projection = [](
      const EventCompletedEdgeProjectionInputV1& input) {
    if (input.predecision_projection.canonical_value.size() != 1U) {
      return c17::failure<CanonicalRuntimeValueV1>(
          "c21.fixture.suspension_completed_projection_shape",
          "the suspension fixture completed projection has a foreign shape");
    }
    const std::uint8_t offset = std::to_integer<std::uint8_t>(
        input.predecision_projection.canonical_value.front());
    return Result<CanonicalRuntimeValueV1>::success(
        {{"c17.fixture.temporal.completed-edge-projection", 1U},
         {static_cast<std::byte>(offset + 1U)}});
  };
  return override;
}

[[nodiscard]] inline StationarySuspensionFixtureV1 make_fixture(
    const EventSelectionFixtureV1 selection =
        EventSelectionFixtureV1::equal_mixture,
    const ExactRational& configured_phase_zero = rational(1, 4),
    const ExactRational& configured_phase_one = rational(3, 4),
    const bool reverse_domain_order = false,
    const std::uint8_t class_b_length = 3U,
    const bool single_phase_domain = false,
    const ProjectionPlanFixtureV1 plan =
        ProjectionPlanFixtureV1::stationary_reward,
    const bool identity_variant = false) {
  if (plan == ProjectionPlanFixtureV1::fifo_service) {
    REQUIRE(selection == EventSelectionFixtureV1::unique);
    REQUIRE(configured_phase_zero == ExactRational::one());
    REQUIRE(configured_phase_one == ExactRational::zero());
    REQUIRE(single_phase_domain);
  }
  if (plan == ProjectionPlanFixtureV1::evolving_phase) {
    REQUIRE(selection == EventSelectionFixtureV1::unique);
    REQUIRE(configured_phase_zero == rational(1, 2));
    REQUIRE(configured_phase_one == rational(1, 2));
    REQUIRE(class_b_length == 2U);
    REQUIRE_FALSE(single_phase_domain);
  }
  matrix::C17TemporalFixtureOverrideV1 override =
      suspension_operation_override(
          class_b_length,
          plan == ProjectionPlanFixtureV1::fifo_service,
          plan == ProjectionPlanFixtureV1::evolving_phase);
  auto completed_decoder_clock_or =
      std::make_shared<std::atomic<unsigned>>(0U);
  matrix::ScopedC17TemporalFixtureOverride scope(override);
  auto prepared = temporal_fixture::
      prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          stationary_temporal_scenario(
              suspension_input(selection, configured_phase_zero,
                               configured_phase_one, plan,
                               identity_variant),
              matrix::kC20ResetRomrProfile, plan),
          ArrivalInitialState{SharedRoundState{"h0"}}, std::nullopt,
          [](PlugDescriptor&) {},
          [completed_decoder_clock_or](
              const ResolvedInstance& instance,
              const std::span<const QueueId> targets,
              const CompiledArrivalLaw& arrival, const ArrivalPhase&,
              const ArrivalPhase&) {
            return suspension_state_schema(instance, targets, arrival,
                                           completed_decoder_clock_or);
          },
          [](const std::span<const QueueId> targets,
             const ExactReducedStateSchemaV1&) {
            return state(targets, 0U);
          },
          [reverse_domain_order, class_b_length, single_phase_domain](
              ExactCausalProgramV1& program) {
            const std::vector<QueueId> targets{designated::queue("q0")};
            std::vector<ReducedStateV1> domain{state(targets, 0U)};
            if (!single_phase_domain) {
              domain.push_back(state(targets, 1U));
            }
            if (reverse_domain_order) {
              std::reverse(domain.begin(), domain.end());
            }
            program.maximum_residence_slots = class_b_length;
            program.reachable_audit_states = domain;
            program.finite_event_domain_states = std::move(domain);
            program.event_entry_domain_is_exact_state_domain = false;
            program.event_clock_semantics = EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient;
          });
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  temporal_fixture::GenericTemporalFrameworkV1 temporal{
      std::move(framework).value(), std::move(prepared.instance),
      std::move(prepared.ordered_targets), std::move(prepared.state_schema),
      std::move(prepared.descriptor), std::move(prepared.initial_state),
      std::move(prepared.entrance_mark),
      std::move(prepared.entrance_decoder_calls),
      std::move(prepared.residence_generator_calls)};
  auto provider = audited_residence_provider(temporal.framework);
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  auto domain = FiniteEventStateDomain::from_audited_provider(
      provider.value());
  REQUIRE(domain);
  auto kernel = assemble_embedded_event_kernel(domain.value(),
                                                provider.value());
  INFO((kernel ? std::string{}
               : kernel.error().code + ": " + kernel.error().message));
  REQUIRE(kernel);
  const ReducedStateV1 class_a = state(temporal.ordered_targets, 0U);
  const ReducedStateV1 class_b = state(temporal.ordered_targets, 1U);
  return {std::move(temporal), std::move(provider).value(),
          std::move(domain).value(), std::move(kernel).value(), class_a,
          class_b, std::move(completed_decoder_clock_or)};
}

[[nodiscard]] inline StationarySuspensionFixtureV1 make_transient_fixture(
    const EventSelectionFixtureV1 selection =
        EventSelectionFixtureV1::unique) {
  const auto four_word_selection =
      selection == EventSelectionFixtureV1::transient_class
          ? c20::FourWordEventSelectionV1::transient_class
          : c20::FourWordEventSelectionV1::unique;
  REQUIRE((selection == EventSelectionFixtureV1::unique ||
           selection == EventSelectionFixtureV1::transient_class));
  auto source = c20::make_four_word_enumerable_framework(
      false, false, false, four_word_selection,
      c20::FourWordMetricFixtureV1::stationary_empty_probability);
  auto provider = audited_residence_provider(source.temporal.framework);
  REQUIRE(provider);
  auto domain = FiniteEventStateDomain::from_audited_provider(
      provider.value());
  REQUIRE(domain);
  auto kernel = assemble_embedded_event_kernel(domain.value(),
                                                provider.value());
  REQUIRE(kernel);
  const std::vector<QueueId> targets{designated::queue("q0")};
  const ReducedStateV1 transient =
      c17::reduced_state(targets, {2U}, false, 0U);
  const ReducedStateV1 closed =
      c17::reduced_state(targets, {0U}, false, 0U);
  return {std::move(source.temporal), std::move(provider).value(),
          std::move(domain).value(), std::move(kernel).value(), transient,
          closed, std::make_shared<std::atomic<unsigned>>(0U)};
}

[[nodiscard]] inline StationarySuspensionFixtureV1 make_plan_fixture(
    const ProjectionPlanFixtureV1 plan,
    const bool reverse_domain_order = false,
    const bool identity_variant = false) {
  if (plan == ProjectionPlanFixtureV1::fifo_service) {
    return make_fixture(EventSelectionFixtureV1::unique, rational(1, 1),
                        rational(0, 1), reverse_domain_order, 1U, true,
                        plan, identity_variant);
  }
  if (plan == ProjectionPlanFixtureV1::evolving_phase) {
    return make_fixture(EventSelectionFixtureV1::unique, rational(1, 2),
                        rational(1, 2), reverse_domain_order, 2U, false,
                        plan, identity_variant);
  }
  return make_fixture(EventSelectionFixtureV1::equal_mixture,
                      rational(1, 4), rational(3, 4),
                      reverse_domain_order, 3U, false, plan,
                      identity_variant);
}

[[nodiscard]] inline std::uint8_t phase(const ReducedStateV1& value) {
  REQUIRE(value.canonical_value.size() == kStateSize);
  return std::to_integer<std::uint8_t>(
      value.canonical_value[kPhaseOffset]);
}

[[nodiscard]] inline std::uint8_t age(const ReducedStateV1& value) {
  REQUIRE(value.canonical_value.size() == kStateSize);
  return std::to_integer<std::uint8_t>(
      value.canonical_value[kAgeOffset]);
}

}  // namespace mwperf::testing::c21
