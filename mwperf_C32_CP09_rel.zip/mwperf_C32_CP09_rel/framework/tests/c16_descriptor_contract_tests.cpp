#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/kernel_access.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "support/c16_audited_handle_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace mwperf::testing {
[[nodiscard]] Result<void> validate_c16_operation_carriers_for_test(
    const PlugDescriptor& descriptor, const SurrogatePlug& plug);
}  // namespace mwperf::testing

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::TypedLabel label(const std::string_view value) {
  auto result = mwperf::TypedLabel::text(std::string(value));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue(const std::string_view value) {
  return mwperf::QueueId(label(value));
}

[[nodiscard]] mwperf::Digest256 digest(const std::string_view value) {
  auto result = mwperf::sha256(
      std::as_bytes(std::span(value.data(), value.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::DeterministicRng c_plus_test_rng(
    const std::uint64_t replication) {
  auto key = mwperf::make_physical_reference_instance_key(
      digest("c16.c-plus.output-guard"), mwperf::BigNat(replication));
  REQUIRE(key);
  return mwperf::derive_rng_stream(mwperf::MasterSeed(0xc1600U),
                                   mwperf::StageTag::postarrival_closure,
                                   key.value());
}

[[nodiscard]] mwperf::RuntimeFieldIdV1 field_id(
    const std::string_view value) {
  return mwperf::RuntimeFieldIdV1(label(value));
}

[[nodiscard]] mwperf::RuntimeMarkIdV1 mark_id(
    const std::string_view value) {
  return mwperf::RuntimeMarkIdV1(label(value));
}

[[nodiscard]] mwperf::RuntimeDecoderIdV1 decoder_id(
    const std::string_view value) {
  return mwperf::RuntimeDecoderIdV1(label(value));
}

[[nodiscard]] mwperf::RuntimeOperationIdentityV1 operation(
    const std::string_view value) {
  return {mwperf::RuntimeOperationIdV1(label(value)), 1U};
}

void reseal_core(mwperf::PlugDescriptorCore& core) {
  auto digest = mwperf::canonical_plug_descriptor_core_digest_v1(core);
  REQUIRE(digest);
  core.core_digest = std::move(digest).value();
}

void reseal(mwperf::PlugDescriptor& descriptor) {
  reseal_core(descriptor.core);
  auto digest = mwperf::canonical_plug_descriptor_digest_v1(descriptor);
  REQUIRE(digest);
  descriptor.descriptor_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::PlugDescriptor valid_stationary_descriptor() {
  const auto manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.descriptor-contract",
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::closed_form,
      mwperf::ProducerModeV1::inline_immediate);
  mwperf::PlugDescriptorCore core =
      mwperf::testing::c16_fixture_detail::scalar_core(
          manifest, {queue("q0")});
  core.payload_class =
      {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U};
  core.semantic = mwperf::SemanticTagV1::stationary_marked_edge;
  core.runtime_access = mwperf::RuntimeAccessTagV1::finite_enumerated_row;
  reseal_core(core);

  mwperf::PlugDescriptor descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  descriptor.transition_state_schema = mwperf::TransitionStateSchemaV1{
      {"c16.aggregate.conditioning-state", 1U},
      {"c16.aggregate.successor-state", 1U},
      {descriptor.state_fields.front().id}};
  reseal(descriptor);
  return descriptor;
}

[[nodiscard]] mwperf::TemporalEventContractV1 event_contract(
    const mwperf::EventContractKindV1 kind) {
  return {
      kind,
      operation("c16.event.generator"),
      operation("c16.event.entry-initializer"),
      operation("c16.event.stopping-indicator"),
      operation("c16.event.terminal-reentry"),
      operation("c16.event.predecision-projection"),
      operation("c16.event.completed-edge-projection"),
      mwperf::EventFiltrationV1::generated_slot_natural_filtration,
      {"c16.event.continuation", 1U},
      {"c16.event.entrance", 1U},
      {"c16.event.exact-successor", 1U},
      {"c16.event.entrance", 1U},
      {"c16.event.stopping-indicator", 1U},
      {"c16.event.predecision-projection", 1U},
      {"c16.event.completed-edge-projection", 1U},
      true,
      true,
      true,
      false};
}

[[nodiscard]] mwperf::PlugDescriptor valid_temporal_descriptor() {
  mwperf::PlugDescriptor descriptor = valid_stationary_descriptor();
  descriptor.core.semantic =
      mwperf::SemanticTagV1::temporal_one_slot_continuation;
  descriptor.event_contract =
      event_contract(mwperf::EventContractKindV1::one_slot_continuation);
  reseal(descriptor);
  return descriptor;
}

[[nodiscard]] std::string rejection_code(
    mwperf::PlugDescriptor descriptor) {
  reseal(descriptor);
  auto result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  return result.error().code;
}

[[nodiscard]] mwperf::PlugDescriptor exact_coordinate_descriptor() {
  mwperf::PlugDescriptor descriptor = valid_stationary_descriptor();
  descriptor.core.state_fields = {
      {mwperf::StateFieldKindV1::target_backlog,
       mwperf::FieldOwnershipV1::framework_exact,
       {"c16.state.backlog", 1U}},
      {mwperf::StateFieldKindV1::configured_arrival_predictive_phase,
       mwperf::FieldOwnershipV1::framework_exact,
       {"c16.state.predictive-phase", 1U}},
      {mwperf::StateFieldKindV1::controller_memory,
       mwperf::FieldOwnershipV1::framework_exact,
       {"c16.state.controller", 1U}},
      {mwperf::StateFieldKindV1::resource_coordinate,
       mwperf::FieldOwnershipV1::framework_exact,
       {"c16.state.resource", 1U}},
      {mwperf::StateFieldKindV1::local_margin,
       mwperf::FieldOwnershipV1::framework_exact,
       {"c16.state.margin", 1U}}};
  descriptor.state_fields.clear();
  std::vector<mwperf::RuntimeFieldIdV1> ordered_fields;
  for (std::size_t index = 0U;
       index < descriptor.core.state_fields.size(); ++index) {
    const auto id = field_id("c16.field." + std::to_string(index));
    descriptor.state_fields.push_back(
        {id, descriptor.core.state_fields[index],
         mwperf::RuntimeDomainKindV1::countable});
    ordered_fields.push_back(id);
  }
  descriptor.transition_state_schema = mwperf::TransitionStateSchemaV1{
      {"c16.aggregate.conditioning-state", 1U},
      {"c16.aggregate.successor-state", 1U},
      std::move(ordered_fields)};
  reseal(descriptor);
  return descriptor;
}

[[nodiscard]] mwperf::PlugDescriptor ownership_matrix_descriptor() {
  mwperf::PlugDescriptor descriptor = exact_coordinate_descriptor();
  const std::array surrogate_fields{
      mwperf::StateFieldDescriptorV1{
          mwperf::StateFieldKindV1::surrogate_phase,
          mwperf::FieldOwnershipV1::surrogate_owned,
          {"c16.state.surrogate-phase", 1U}},
      mwperf::StateFieldDescriptorV1{
          mwperf::StateFieldKindV1::event_state,
          mwperf::FieldOwnershipV1::surrogate_owned,
          {"c16.state.event", 1U}},
      mwperf::StateFieldDescriptorV1{
          mwperf::StateFieldKindV1::entrance_label_state,
          mwperf::FieldOwnershipV1::surrogate_owned,
          {"c16.state.entrance-label", 1U}}};
  descriptor.core.state_fields.insert(
      descriptor.core.state_fields.begin() + 2, surrogate_fields.front());
  descriptor.core.state_fields.push_back(surrogate_fields[1U]);
  descriptor.core.state_fields.push_back(surrogate_fields[2U]);

  // C14 defines state_fields as a canonical set.  Rebuild the C16 projection
  // in that exact kind order after inserting surrogate_phase between the two
  // leading exact kinds and the remaining exact coordinates.
  descriptor.state_fields.clear();
  descriptor.transition_state_schema->ordered_fields.clear();
  for (std::size_t index = 0U;
       index < descriptor.core.state_fields.size(); ++index) {
    const auto id = field_id("c16.field." + std::to_string(index));
    descriptor.state_fields.push_back(
        {id, descriptor.core.state_fields[index],
         mwperf::RuntimeDomainKindV1::countable});
    descriptor.transition_state_schema->ordered_fields.push_back(id);
  }
  reseal(descriptor);
  return descriptor;
}

[[nodiscard]] mwperf::PlugDescriptor valid_causal_descriptor() {
  mwperf::PlugDescriptor descriptor = valid_stationary_descriptor();

  descriptor.core.state_fields.push_back(
      {mwperf::StateFieldKindV1::surrogate_phase,
       mwperf::FieldOwnershipV1::surrogate_owned,
       {"c16.state.surrogate-phase", 1U}});
  descriptor.state_fields.push_back(
      {field_id("c16.field.surrogate-phase"),
       descriptor.core.state_fields.back(),
       mwperf::RuntimeDomainKindV1::countable});
  descriptor.transition_state_schema->ordered_fields.push_back(
      descriptor.state_fields.back().id);

  descriptor.core.marks = {
      {mwperf::MetricMarkKindV1::opportunity,
       mwperf::MetricRevealStageV1::predecision,
       {"c16.opportunity", 1U},
       ""},
      {mwperf::MetricMarkKindV1::actual_departure,
       mwperf::MetricRevealStageV1::decision,
       {"service.bit", 1U},
       ""},
      {mwperf::MetricMarkKindV1::edge_increment,
       mwperf::MetricRevealStageV1::completed_edge,
       {"c16.edge-increment", 1U},
       ""}};
  descriptor.marks = {
      {mark_id("c16.mark.opportunity"),
       descriptor.core.marks[0U],
       decoder_id("c16.decoder.opportunity"),
       mwperf::MarkDecoderSourceV1::c_minus_joint_output,
       mwperf::RuntimeDomainKindV1::countable,
       {"c16.opportunity", 1U},
       {},
       {}},
      {mark_id("c16.mark.departure"),
       descriptor.core.marks[1U],
       decoder_id("c16.decoder.departure"),
       mwperf::MarkDecoderSourceV1::decision_schedule,
       mwperf::RuntimeDomainKindV1::finite,
       {"c16.decision", 1U},
       {},
       {}},
      {mark_id("c16.mark.edge-increment"),
       descriptor.core.marks[2U],
       decoder_id("c16.decoder.edge-increment"),
       mwperf::MarkDecoderSourceV1::c_plus_joint_output,
       mwperf::RuntimeDomainKindV1::countable,
       {"c16.patch", 1U},
       {},
       {}}};
  descriptor.c_minus = mwperf::CMinusOperationSchemaV1{
      mwperf::RuntimeOperationIdV1(label("c16.operation.c-minus")),
      1U,
      descriptor.transition_state_schema->conditioning_state_codec,
      {"c16.opportunity", 1U},
      {descriptor.state_fields.front().id},
      {descriptor.marks[0U].id}};
  descriptor.c_plus = mwperf::CPlusOperationSchemaV1{
      mwperf::RuntimeOperationIdV1(label("c16.operation.c-plus")),
      1U,
      {"c16.prearrival-state", 1U},
      {std::string(mwperf::kC17EmittedOpportunityCodecIdV1),
       mwperf::kC17EmittedOpportunityCodecVersionV1},
      {"c16.decision", 1U},
      {"c16.configured-arrival", 1U},
      {"c16.patch", 1U},
      {descriptor.state_fields.back().id},
      {descriptor.marks[1U].id},
      {descriptor.marks[2U].id}};
  reseal(descriptor);
  return descriptor;
}

struct CausalCallbackCounters final {
  std::atomic<unsigned> c_minus{0U};
  std::atomic<unsigned> c_plus{0U};
  std::atomic<unsigned> access{0U};
};

[[nodiscard]] mwperf::PortablePlugPayload opaque_test_payload(
    const mwperf::PlugDescriptor& descriptor) {
  const auto payload_digest = digest("c16.causal.payload");
  mwperf::PortablePayloadContextV1 context{
      {mwperf::PayloadClassTagV1::finite_parameter_analytic_data_v1, 1U},
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      digest("c16.causal.build-identity"),
      digest("c16.causal.request"),
      digest("c16.causal.problem-view"),
      descriptor.core.deployed_targets,
      {label("c16.causal.payload"), payload_digest},
      payload_digest,
      {1U, {}, digest("c16.causal.manifest")},
      {digest("c16.causal.request"), payload_digest, {}},
      {},
      {}};
  mwperf::FiniteParameterAnalyticDataV1 data{
      1U,
      "c16.causal.fixture",
      1U,
      "c16.causal.parameters",
      1U,
      "c16.causal.domain",
      1U,
      descriptor.core.provider,
      descriptor.core.deployed_targets,
      {},
      {},
      {},
      descriptor.core.state_fields,
      {}};
  return Factory::portable_payload(
      mwperf::PortableFiniteParameterAnalyticDataV1{std::move(context),
                                                    std::move(data)});
}

[[nodiscard]] mwperf::KernelAccess causal_access(
    const mwperf::PlugDescriptor& descriptor,
    CausalCallbackCounters& counters) {
  std::vector<mwperf::CodecIdentityV1> mark_codecs;
  mark_codecs.reserve(descriptor.marks.size());
  for (const auto& mark : descriptor.marks) {
    mark_codecs.push_back(mark.c14_mark.codec);
  }
  const auto& state = *descriptor.transition_state_schema;
  return mwperf::FiniteEnumeratedRowAccess(
      {state.conditioning_state_codec, state.successor_state_codec,
       std::move(mark_codecs), 8U, std::nullopt},
      [&counters](const mwperf::CanonicalRuntimeValueV1&) {
        counters.access.fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<std::vector<mwperf::KernelRowAtomV1>>::success(
            {});
      });
}

[[nodiscard]] mwperf::SurrogatePlug causal_plug(
    const mwperf::PlugDescriptor& descriptor,
    CausalCallbackCounters& counters,
    mwperf::CMinusOperationSchemaV1 c_minus,
    mwperf::CPlusOperationSchemaV1 c_plus,
    const bool include_c_minus = true,
    const bool include_c_plus = true,
    const bool provide_c_minus_callback = true,
    const bool provide_c_plus_callback = true) {
  mwperf::CausalSurrogateOperationsV1 operations;
  if (include_c_minus) {
    mwperf::CMinusCallbackV1 callback;
    if (provide_c_minus_callback) {
      callback = [&counters](const mwperf::CMinusInputV1&,
                             mwperf::DeterministicRng&) {
        counters.c_minus.fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<mwperf::CMinusOutputV1>::success(
            {{{"c16.opportunity", 1U}, {}}, {}, std::nullopt,
             std::nullopt});
      };
    }
    operations.c_minus =
        mwperf::CMinusOperationV1(std::move(c_minus), std::move(callback));
  }
  if (include_c_plus) {
    mwperf::CPlusCallbackV1 callback;
    if (provide_c_plus_callback) {
      callback = [&counters](const mwperf::CPlusInputV1&,
                             mwperf::DeterministicRng&) {
        counters.c_plus.fetch_add(1U, std::memory_order_relaxed);
        return mwperf::Result<mwperf::CPlusOutputV1>::success({{}, {}});
      };
    }
    operations.c_plus =
        mwperf::CPlusOperationV1(std::move(c_plus), std::move(callback));
  }
  return mwperf::StationaryMarkedEdgePlugV1{
      opaque_test_payload(descriptor), causal_access(descriptor, counters),
      std::move(operations)};
}

template <typename Value>
concept ExposesArrivalSampler = requires(Value& value) {
  value.arrival_sampler;
};

template <typename Value>
concept ExposesIndependentTargetArrivalProjection = requires(Value& value) {
  value.independent_target_arrival_projection;
};

}  // namespace

TEST_CASE("C16 descriptor accepts minimal stationary and temporal truth shapes",
          "[c16][unit][descriptor]") {
  auto stationary = valid_stationary_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(stationary));

  auto temporal = valid_temporal_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(temporal));
}

TEST_CASE("C16 descriptor rejects semantic active-field mismatch",
          "[c16][negative][descriptor]") {
  SECTION("temporal semantic without event operations") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.semantic =
        mwperf::SemanticTagV1::temporal_one_slot_continuation;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.temporal_event_contract_mismatch");
  }

  SECTION("non-temporal semantic with event operations") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.event_contract =
        event_contract(mwperf::EventContractKindV1::one_slot_continuation);
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.temporal_event_contract_mismatch");
  }
}

TEST_CASE("C16 descriptor rejects missing and invalid state codecs",
          "[c16][negative][descriptor]") {
  SECTION("missing C16 state projection") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.state_fields.clear();
    descriptor.transition_state_schema->ordered_fields.clear();
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.state_field_projection_mismatch");
  }

  SECTION("invalid runtime field codec") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.state_fields.front().c14_field.codec = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.state_field_projection_mismatch");
  }

  SECTION("missing aggregate transition-state schema") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.transition_state_schema.reset();
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.transition_state_schema_presence_mismatch");
  }

  SECTION("invalid aggregate conditioning codec") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.transition_state_schema->conditioning_state_codec = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_transition_state_schema");
  }

  SECTION("invalid aggregate successor codec") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.transition_state_schema->successor_state_codec = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_transition_state_schema");
  }

  SECTION("aggregate schema names a foreign field") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.transition_state_schema->ordered_fields.front() =
        field_id("c16.field.foreign");
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.transition_state_field_order_mismatch");
  }
}

TEST_CASE("C16 descriptor rejects target and coupling contradictions",
          "[c16][negative][descriptor]") {
  SECTION("multiple targets with scalar coupling") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.deployed_targets.push_back(queue("q1"));
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.multitarget_scalar_coupling");
  }

  SECTION("coupled semantic claiming scalar target") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.semantic =
        mwperf::SemanticTagV1::coupled_target_schedule_law;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c14_descriptor_core");
  }

  SECTION("common schedule without a feasible schedule mark") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.semantic =
        mwperf::SemanticTagV1::coupled_target_schedule_law;
    descriptor.core.target_coupling =
        mwperf::TargetCouplingV1::common_schedule_projection;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.coupled_schedule_mark_missing");
  }
}

TEST_CASE("C16 descriptor rejects duplicate IDs and invalid ownership",
          "[c16][negative][descriptor]") {
  SECTION("duplicate runtime field IDs") {
    auto descriptor = exact_coordinate_descriptor();
    descriptor.state_fields[1U].id = descriptor.state_fields[0U].id;
    descriptor.transition_state_schema->ordered_fields[1U] =
        descriptor.state_fields[0U].id;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.duplicate_runtime_field_id");
  }

  SECTION("unknown field ownership") {
    auto descriptor = valid_stationary_descriptor();
    constexpr auto invalid_ownership =
        static_cast<mwperf::FieldOwnershipV1>(0xffU);
    descriptor.core.state_fields.front().ownership = invalid_ownership;
    descriptor.state_fields.front().c14_field.ownership = invalid_ownership;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c14_descriptor_core");
  }
}

TEST_CASE("C16 descriptor enforces the complete field ownership matrix",
          "[c16][negative][descriptor][ownership]") {
  const auto base = ownership_matrix_descriptor();
  const auto base_validation = mwperf::validate_plug_descriptor_v1(base);
  INFO((base_validation ? std::string{}
                        : base_validation.error().code + ": " +
                              base_validation.error().message));
  REQUIRE(base_validation);
  REQUIRE(base.state_fields.size() == 8U);

  for (std::size_t index = 0U; index < base.state_fields.size(); ++index) {
    DYNAMIC_SECTION("wrong ownership for field kind " << index) {
      auto descriptor = base;
      const auto wrong_ownership =
          descriptor.core.state_fields[index].ownership ==
                  mwperf::FieldOwnershipV1::framework_exact
              ? mwperf::FieldOwnershipV1::surrogate_owned
              : mwperf::FieldOwnershipV1::framework_exact;
      descriptor.core.state_fields[index].ownership = wrong_ownership;
      descriptor.state_fields[index].c14_field.ownership = wrong_ownership;
      REQUIRE(rejection_code(std::move(descriptor)) ==
              "c16.state_field_ownership_mismatch");
    }
  }
}

TEST_CASE("C16 C-plus cannot write an exact framework coordinate",
          "[c16][negative][descriptor][ownership]") {
  const auto base = exact_coordinate_descriptor();
  for (std::size_t index = 0U; index < base.state_fields.size(); ++index) {
    DYNAMIC_SECTION("exact field index " << index) {
      auto descriptor = base;
      descriptor.c_plus = mwperf::CPlusOperationSchemaV1{
          mwperf::RuntimeOperationIdV1(label("c16.c-plus")),
          1U,
          {"c16.aggregate.prearrival", 1U},
          {std::string(mwperf::kC17EmittedOpportunityCodecIdV1),
           mwperf::kC17EmittedOpportunityCodecVersionV1},
          {"schedule.realization", 1U},
          {"c16.arrival.batch", 1U},
          {"c16.surrogate.patch", 1U},
          {descriptor.state_fields[index].id},
          {},
          {}};
      REQUIRE(rejection_code(std::move(descriptor)) ==
              "c16.c_plus_exact_coordinate_write");
    }
  }
}

TEST_CASE("C16 C-plus execution enforces its unresolved-field write set",
          "[c16][unit][negative][descriptor][ownership][execution]") {
  const auto descriptor = valid_causal_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(descriptor));
  REQUIRE(descriptor.c_plus.has_value());
  REQUIRE(descriptor.c_plus->writable_unresolved_fields.size() == 1U);

  const auto& schema = *descriptor.c_plus;
  const mwperf::CPlusInputV1 input{
      {schema.prearrival_state_codec, {}},
      {schema.opportunity_codec, {}},
      {schema.decision_codec, {}},
      {schema.configured_arrival_codec, {}},
      {}};

  const auto invoke = [&](std::vector<mwperf::RuntimeFieldIdV1> fields) {
    std::atomic<unsigned> calls{0U};
    mwperf::CPlusOperationV1 operation(
        schema,
        [&calls, fields = std::move(fields)](
            const mwperf::CPlusInputV1&,
            mwperf::DeterministicRng&) {
          calls.fetch_add(1U, std::memory_order_relaxed);
          std::vector<mwperf::RuntimeFieldPatchV1> patch;
          patch.reserve(fields.size());
          for (const auto& field : fields) {
            patch.push_back({field, {{"c16.patch-value", 1U}, {}}});
          }
          return mwperf::Result<mwperf::CPlusOutputV1>::success(
              {std::move(patch), {}});
        });

    // Constructing the guarded carrier and validating its callback-free
    // descriptor must remain observational.
    REQUIRE(operation.has_operation());
    REQUIRE(mwperf::validate_plug_descriptor_v1(descriptor));
    CHECK(calls.load(std::memory_order_relaxed) == 0U);

    auto rng = c_plus_test_rng(0U);
    auto result = mwperf::testing::C16FixtureAuditedMint::execute_c_plus(
        operation, input, rng);
    CHECK(calls.load(std::memory_order_relaxed) == 1U);
    return result;
  };

  SECTION("the declared unresolved field escapes unchanged") {
    auto result = invoke(schema.writable_unresolved_fields);
    REQUIRE(result);
    REQUIRE(result.value().unresolved_patch.size() == 1U);
    CHECK(result.value().unresolved_patch.front().field ==
          schema.writable_unresolved_fields.front());
  }

  SECTION("a framework-exact field is rejected after one callback") {
    REQUIRE(descriptor.state_fields.front().c14_field.ownership ==
            mwperf::FieldOwnershipV1::framework_exact);
    auto result = invoke({descriptor.state_fields.front().id});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_plus_patch_field_not_writable");
    CHECK(result.error().json_pointer ==
          "/c_plus/output/unresolved_patch/0/field");
  }

  SECTION("a field absent from the operation write set is rejected") {
    auto result = invoke({field_id("c16.field.undeclared-patch")});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_plus_patch_field_not_writable");
  }

  SECTION("duplicate writes to an allowed field are rejected") {
    const auto allowed = schema.writable_unresolved_fields.front();
    auto result = invoke({allowed, allowed});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_plus_duplicate_field_patch");
    CHECK(result.error().json_pointer ==
          "/c_plus/output/unresolved_patch/1/field");
  }
}

TEST_CASE("C16 C-minus and C-plus require their exact v1 schemas",
          "[c16][negative][descriptor][causality]") {
  const auto base = valid_causal_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(base));

  for (const std::uint32_t version : {0U, 2U}) {
    DYNAMIC_SECTION("C-minus schema version " << version) {
      auto descriptor = base;
      descriptor.c_minus->schema_version = version;
      REQUIRE(rejection_code(std::move(descriptor)) ==
              "c16.invalid_c_minus_schema");
    }
    DYNAMIC_SECTION("C-plus schema version " << version) {
      auto descriptor = base;
      descriptor.c_plus->schema_version = version;
      REQUIRE(rejection_code(std::move(descriptor)) ==
              "c16.invalid_c_plus_schema");
    }
  }
}

TEST_CASE("C16 validates complete C-minus and C-plus descriptor topology",
          "[c16][negative][descriptor][causality]") {
  const auto base = valid_causal_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(base));

  SECTION("C-minus reads only declared fields") {
    auto descriptor = base;
    descriptor.c_minus->read_fields = {field_id("c16.field.foreign")};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c_minus_field");
  }
  SECTION("C-minus names only its own jointly emitted marks") {
    auto descriptor = base;
    descriptor.c_minus->jointly_emitted_marks = {descriptor.marks[1U].id};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c_minus_mark");
  }
  SECTION("a C-minus mark cannot be left without its emitting operation") {
    auto descriptor = base;
    descriptor.c_minus->jointly_emitted_marks.clear();
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.unowned_joint_mark");
  }
  SECTION("C-plus reads only declared causally available marks") {
    auto descriptor = base;
    descriptor.c_plus->read_marks = {mark_id("c16.mark.foreign")};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c_plus_mark");
  }
  SECTION("C-plus names only its own jointly emitted marks") {
    auto descriptor = base;
    descriptor.c_plus->jointly_emitted_marks = {descriptor.marks[1U].id};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_c_plus_emitted_mark");
  }
  SECTION("a C-plus mark cannot be left without its emitting operation") {
    auto descriptor = base;
    descriptor.c_plus->jointly_emitted_marks.clear();
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.unowned_joint_mark");
  }
}

TEST_CASE("C16 operation-carrier validation is exact and noninvoking",
          "[c16][negative][descriptor][carrier][cold]") {
  const auto descriptor = valid_causal_descriptor();
  REQUIRE(mwperf::validate_plug_descriptor_v1(descriptor));
  CausalCallbackCounters counters;

  const auto require_cold = [&] {
    CHECK(counters.c_minus.load(std::memory_order_relaxed) == 0U);
    CHECK(counters.c_plus.load(std::memory_order_relaxed) == 0U);
    CHECK(counters.access.load(std::memory_order_relaxed) == 0U);
  };

  SECTION("matching C-minus and C-plus carriers are valid") {
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            *descriptor.c_plus);
    REQUIRE(mwperf::validate_kernel_access_shape_v1(
        mwperf::kernel_access_v1(plug)));
    REQUIRE(mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug));
    require_cold();
  }
  SECTION("missing C-minus carrier is rejected") {
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            *descriptor.c_plus, false);
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.operation_presence_mismatch");
    require_cold();
  }
  SECTION("missing C-plus carrier is rejected") {
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            *descriptor.c_plus, true, false);
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.operation_presence_mismatch");
    require_cold();
  }
  SECTION("missing C-minus callback is rejected without invoking C-plus") {
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            *descriptor.c_plus, true, true, false, true);
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_minus_carrier_mismatch");
    require_cold();
  }
  SECTION("missing C-plus callback is rejected without invoking C-minus") {
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            *descriptor.c_plus, true, true, true, false);
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_plus_carrier_mismatch");
    require_cold();
  }
  SECTION("same-shaped foreign C-minus schema is rejected") {
    auto c_minus = *descriptor.c_minus;
    c_minus.opportunity_codec = {"c16.opportunity.foreign", 1U};
    auto plug = causal_plug(descriptor, counters, std::move(c_minus),
                            *descriptor.c_plus);
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_minus_carrier_mismatch");
    require_cold();
  }
  SECTION("same-shaped foreign C-plus schema is rejected") {
    auto c_plus = *descriptor.c_plus;
    c_plus.configured_arrival_codec = {"c16.configured-arrival.foreign", 1U};
    auto plug = causal_plug(descriptor, counters, *descriptor.c_minus,
                            std::move(c_plus));
    auto result = mwperf::testing::validate_c16_operation_carriers_for_test(
        descriptor, plug);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.c_plus_carrier_mismatch");
    require_cold();
  }
}

TEST_CASE("C16 closed types reject plug-owned arrival generation",
          "[c16][negative][descriptor][arrival][ownership]") {
  STATIC_REQUIRE_FALSE(ExposesArrivalSampler<mwperf::PlugDescriptor>);
  STATIC_REQUIRE_FALSE(
      ExposesArrivalSampler<mwperf::CausalSurrogateOperationsV1>);
  STATIC_REQUIRE_FALSE(ExposesArrivalSampler<mwperf::CPlusInputV1>);
  STATIC_REQUIRE_FALSE(
      ExposesIndependentTargetArrivalProjection<mwperf::PlugDescriptor>);
  STATIC_REQUIRE_FALSE(ExposesIndependentTargetArrivalProjection<
                       mwperf::CausalSurrogateOperationsV1>);

  SECTION("configured arrival ownership has no surrogate-owned alternative") {
    auto descriptor = valid_causal_descriptor();
    descriptor.configured_arrival_ownership =
        static_cast<mwperf::ConfiguredArrivalOwnershipV1>(0xffU);
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.invalid_configured_arrival_ownership");
  }
  SECTION("a C-plus-emitted arrival projection is rejected") {
    auto descriptor = valid_causal_descriptor();
    descriptor.core.marks[2U].kind = mwperf::MetricMarkKindV1::arrival_batch;
    descriptor.core.marks[2U].reveal_stage =
        mwperf::MetricRevealStageV1::arrival;
    descriptor.marks[2U].c14_mark = descriptor.core.marks[2U];
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.mark_decoder_source_mismatch");
  }
}

TEST_CASE("C16 rejects a Palm label revealed after entrance",
          "[c16][negative][descriptor][causality]") {
  auto descriptor = valid_stationary_descriptor();
  descriptor.core.marks = {
      {mwperf::MetricMarkKindV1::within_batch_rank,
       mwperf::MetricRevealStageV1::completed_edge,
       {"c16.palm.rank", 1U},
       ""}};
  descriptor.marks = {
      {mark_id("c16.palm.rank"),
       descriptor.core.marks.front(),
       decoder_id("c16.palm.rank.decoder"),
       mwperf::MarkDecoderSourceV1::entrance_realization,
       mwperf::RuntimeDomainKindV1::countable,
       {"c16.event.entrance", 1U},
       {},
       {}}};
  REQUIRE(rejection_code(std::move(descriptor)) ==
          "c16.invalid_c14_descriptor_core");
}

TEST_CASE("C16 temporal descriptor requires complete positive event maps",
          "[c16][negative][descriptor][temporal]") {
  SECTION("nonpositive first stop") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->first_stop_strictly_positive = false;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }

  SECTION("missing predecision projection") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->predecision_projection = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }

  SECTION("missing completed-edge projection") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->completed_edge_projection = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }

  SECTION("unversioned event operation") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->terminal_reentry_operation.operation_version =
        0U;
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }

  SECTION("entry and reentry spaces differ") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->reentry_space =
        {"c16.event.foreign-reentry", 1U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }

  SECTION("terminal exact-state space is absent") {
    auto descriptor = valid_temporal_descriptor();
    descriptor.event_contract->terminal_space = {"", 0U};
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.incomplete_temporal_event_contract");
  }
}

TEST_CASE("C16 seals every temporal operation identity and version",
          "[c16][negative][descriptor][temporal][digest]") {
  constexpr std::array<std::string_view, 6U> operation_names{
      "generator", "entry", "stopping", "terminal-reentry",
      "predecision-projection", "completed-edge-projection"};

  for (std::size_t index = 0U; index < operation_names.size(); ++index) {
    DYNAMIC_SECTION(operation_names[index]
                    << " identity participates in digest") {
      auto descriptor = valid_temporal_descriptor();
      auto& event = *descriptor.event_contract;
      const std::array<mwperf::RuntimeOperationIdentityV1*, 6U> operations{
          &event.event_generator_operation,
          &event.entry_initializer_operation,
          &event.stopping_indicator_operation,
          &event.terminal_reentry_operation,
          &event.predecision_projection_operation,
          &event.completed_edge_projection_operation};
      operations[index]->operation_id = mwperf::RuntimeOperationIdV1(
          label("c16.event.mutated." + std::to_string(index)));

      auto stale = mwperf::validate_plug_descriptor_v1(descriptor);
      REQUIRE_FALSE(stale);
      REQUIRE(stale.error().code ==
              "c16.runtime_descriptor_digest_mismatch");

      reseal(descriptor);
      REQUIRE(mwperf::validate_plug_descriptor_v1(descriptor));
    }

    DYNAMIC_SECTION(operation_names[index] << " requires version one") {
      auto descriptor = valid_temporal_descriptor();
      auto& event = *descriptor.event_contract;
      const std::array<mwperf::RuntimeOperationIdentityV1*, 6U> operations{
          &event.event_generator_operation,
          &event.entry_initializer_operation,
          &event.stopping_indicator_operation,
          &event.terminal_reentry_operation,
          &event.predecision_projection_operation,
          &event.completed_edge_projection_operation};
      operations[index]->operation_version = 2U;
      REQUIRE(rejection_code(std::move(descriptor)) ==
              "c16.incomplete_temporal_event_contract");
    }
  }
}

TEST_CASE("C16 residence access rejects nonpositive residence support",
          "[c16][negative][descriptor][temporal]") {
  mwperf::KernelAccess access = mwperf::ProceduralResidenceGeneratorAccess(
      {{"c16.event.entrance", 1U},
       {"c16.event.continuation", 1U},
       {"c16.event.exact-successor", 1U},
       {"c16.event.entrance", 1U},
       {{"service.bit", 1U}},
       8U},
      {mwperf::KernelOperationIdV1(label("c16.event.generator")), 1U,
       {"c16.event.stopping-indicator", 1U}},
      false,
      [](const mwperf::CanonicalRuntimeValueV1&,
         mwperf::DeterministicRng&)
          -> mwperf::Result<mwperf::GeneratedResidenceWordV1> {
        return mwperf::Result<mwperf::GeneratedResidenceWordV1>::failure(
            {mwperf::DiagnosticCategory::internal,
             "c16.fixture.uninvoked",
             "this callback must not be invoked by shape validation",
             std::nullopt,
             std::nullopt,
             {}});
      });
  auto result = mwperf::validate_kernel_access_shape_v1(access);
  REQUIRE_FALSE(result);
  REQUIRE(result.error().code == "c16.invalid_residence_event_contract");
}

TEST_CASE("C16 operation prototypes do not retain hidden warm state",
          "[c16][unit][descriptor][cold]") {
  using Operation = std::function<unsigned()>;
  mwperf::kernel_access_detail::ImmutableOperationPrototypeV1<Operation>
      prototype(Operation{[count = 0U]() mutable { return ++count; }});
  REQUIRE(prototype.present());

  auto first = prototype.fresh_copy();
  auto second = prototype.fresh_copy();
  REQUIRE(first() == 1U);
  REQUIRE(first() == 2U);
  REQUIRE(second() == 1U);
}

TEST_CASE("C16 V1 and V2 claims require their own witness shapes",
          "[c16][negative][descriptor][certificate]") {
  SECTION("V1 without witness") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.optional_reported_evidence = {
        {mwperf::OptionalReportedEvidenceKindV1::v1_fibre_realizability,
         "c16.witness.v1",
         1U}};
    descriptor.certificates.push_back(
        {mwperf::CertificateCategoryV1::geometry,
         mwperf::CertificateLevelV1::v1_witness,
         std::nullopt});
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.certificate_core_evidence_mismatch");
  }

  SECTION("V2 without witness") {
    auto descriptor = valid_stationary_descriptor();
    descriptor.core.optional_reported_evidence = {
        {mwperf::OptionalReportedEvidenceKindV1::v1_fibre_realizability,
         "c16.witness.v1",
         1U},
        {mwperf::OptionalReportedEvidenceKindV1::v2_dynamic_lift,
         "c16.witness.v2",
         1U}};
    descriptor.certificates.push_back(
        {mwperf::CertificateCategoryV1::geometry,
         mwperf::CertificateLevelV1::v1_witness,
         mwperf::CodecIdentityV1{"c16.witness.v1", 1U}});
    descriptor.certificates.push_back(
        {mwperf::CertificateCategoryV1::lift,
         mwperf::CertificateLevelV1::v2_witness,
         std::nullopt});
    REQUIRE(rejection_code(std::move(descriptor)) ==
            "c16.certificate_core_evidence_mismatch");
  }
}

TEST_CASE("C16 never infers one certificate field from another",
          "[c16][negative][descriptor][certificate]") {
  auto descriptor = valid_stationary_descriptor();
  descriptor.core.optional_reported_evidence = {
      {mwperf::OptionalReportedEvidenceKindV1::physical_fidelity,
       "c16.witness.fidelity",
       1U}};
  REQUIRE(rejection_code(std::move(descriptor)) ==
          "c16.missing_runtime_certificate_projection");
}

TEST_CASE("C16 optimizer state admission uses the exact optional product",
          "[c16][unit][budget]") {
  using mwperf::artifact::detail::
      checked_required_optimizer_search_states_v1;
  std::optional<mwperf::BigNat> required;

  SECTION("no per-call requirement imposes no state floor") {
    const mwperf::ConstructionPrerequisitesV1 prerequisites{
        {}, mwperf::BigNat{3U}, std::nullopt, std::nullopt};
    REQUIRE(checked_required_optimizer_search_states_v1(prerequisites,
                                                        required));
    CHECK_FALSE(required.has_value());
  }

  SECTION("per-call alone preserves the existing single-call floor") {
    const mwperf::ConstructionPrerequisitesV1 prerequisites{
        {}, std::nullopt, std::nullopt, mwperf::BigNat{4U}};
    REQUIRE(checked_required_optimizer_search_states_v1(prerequisites,
                                                        required));
    REQUIRE(required.has_value());
    CHECK(*required == mwperf::BigNat{4U});
  }

  SECTION("calls and per-call states require their exact product") {
    const mwperf::ConstructionPrerequisitesV1 prerequisites{
        {}, mwperf::BigNat{3U}, std::nullopt, mwperf::BigNat{4U}};
    REQUIRE(checked_required_optimizer_search_states_v1(prerequisites,
                                                        required));
    REQUIRE(required.has_value());
    CHECK(*required == mwperf::BigNat{12U});
  }

  SECTION("the product remains arbitrary precision") {
    const auto large = mwperf::BigNat::from_big_int(
        mwperf::BigInt{1} << 80U);
    REQUIRE(large);
    const mwperf::ConstructionPrerequisitesV1 prerequisites{
        {}, large.value(), std::nullopt, large.value()};
    REQUIRE(checked_required_optimizer_search_states_v1(prerequisites,
                                                        required));
    REQUIRE(required.has_value());
    CHECK(required->value() == (mwperf::BigInt{1} << 160U));
  }
}
