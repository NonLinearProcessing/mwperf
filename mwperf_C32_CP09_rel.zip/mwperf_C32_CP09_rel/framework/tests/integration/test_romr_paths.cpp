#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <limits>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "fixtures/c20/adapted_exit_temporal_fixture.hpp"
#include "fixtures/c20/enumerable_four_word_fixture.hpp"
#include "fixtures/c20/multi_slot_temporal_fixture.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/temporal/romr.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

struct C20DecodedResidenceWordV1 final {
  mwperf::BigNat length;
  mwperf::ReducedStateV1 entry_state;
  mwperf::ReducedStateV1 event_endpoint;
  mwperf::BigNat event_endpoint_boundary;
  mwperf::Digest256 word_digest;
};

struct C20DecodedResidenceOffsetV1 final {
  std::size_t offset;
  mwperf::ReducedStateV1 pre_state;
  mwperf::ReducedStateV1 successor_state;
  mwperf::CanonicalRuntimeValueV1 predecision_projection;
  mwperf::CanonicalRuntimeValueV1 completed_edge_projection;
};

// Structural C21-handoff consumer required by the C20 checkpoint.  This spy
// deliberately knows only the finite embedded kernel, the matching complete
// residence provider, and exact word/offset decoders.  In particular, it has
// no event-law selector, invariant solver, suspension operation, or
// slot-stationary result input.
class C20SuspensionInputSinkSpy final {
 public:
  template <typename ExactWordDecoder, typename ExactOffsetDecoder>
  [[nodiscard]] bool consume(
      const mwperf::EmbeddedKernel& kernel,
      const mwperf::AuditedResidenceProvider& provider,
      ExactWordDecoder&& decode_word,
      ExactOffsetDecoder&& decode_offset) {
    ++consume_calls_;
    auto provider_domain =
        mwperf::FiniteEventStateDomain::from_audited_provider(provider);
    if (!provider_domain ||
        provider_domain.value().fingerprint() !=
            kernel.domain().fingerprint() ||
        provider_domain.value().states().size() !=
            kernel.domain().states().size() ||
        kernel.rows().size() != kernel.domain().states().size() ||
        kernel.rows().empty()) {
      return false;
    }
    for (std::size_t index = 0U;
         index < kernel.domain().states().size(); ++index) {
      if (provider_domain.value().states()[index] !=
          kernel.domain().states()[index]) {
        return false;
      }
    }

    const mwperf::PmfRepresentationBudget frozen_budget =
        kernel.rows().front().word_row.representation_budget();
    const mwperf::Digest256 provider_fingerprint =
        kernel.rows().front().word_row.provider_fingerprint();
    for (std::size_t row_index = 0U; row_index < kernel.rows().size();
         ++row_index) {
      const auto& row = kernel.rows()[row_index];
      if (row.word_row.entry_state() !=
              kernel.domain().states()[row_index] ||
          row.word_row.representation_budget() != frozen_budget ||
          row.word_row.provider_fingerprint() != provider_fingerprint ||
          row.word_row.exact_total_mass() !=
              mwperf::ExactRational::one() ||
          row.exact_total_mass != mwperf::ExactRational::one()) {
        return false;
      }

      // Re-enumeration through the supplied provider, under exactly the
      // retained frozen budget, establishes the provider/row binding without
      // asking the sink to inspect an opaque C17 seal.
      auto reproduced = mwperf::enumerate_residence_word_row(
          provider, row.word_row.entry_state(), frozen_budget);
      if (!reproduced || !same_word_rows(row.word_row, reproduced.value())) {
        return false;
      }

      for (const auto& atom : row.word_row.atoms()) {
        const C20DecodedResidenceWordV1 decoded = decode_word(atom.word);
        ++word_decoder_calls_;
        if (decoded.length != atom.word.length() ||
            decoded.entry_state != atom.word.entry_state() ||
            decoded.event_endpoint != atom.word.event_endpoint() ||
            decoded.event_endpoint_boundary == mwperf::BigNat{0U} ||
            decoded.word_digest != atom.word.word_digest() ||
            atom.word.length() !=
                mwperf::BigNat{atom.word.edges().size()} ||
            atom.word.predecision_projections().size() !=
                atom.word.edges().size() ||
            atom.word.completed_edge_projections().size() !=
                atom.word.edges().size()) {
          return false;
        }

        // A quotient never rewrites the path-bearing word: its raw endpoint
        // intentionally is not a zero-clock event-domain key.
        if (kernel.domain().index_of(decoded.event_endpoint).has_value()) {
          return false;
        }

        for (std::size_t offset = 0U;
             offset < atom.word.edges().size(); ++offset) {
          const C20DecodedResidenceOffsetV1 decoded_offset =
              decode_offset(atom.word, offset);
          ++offset_decoder_calls_;
          if (decoded_offset.offset != offset ||
              decoded_offset.pre_state !=
                  atom.word.edges()[offset].pre_state() ||
              decoded_offset.successor_state !=
                  atom.word.edges()[offset].successor_state() ||
              decoded_offset.predecision_projection !=
                  atom.word.predecision_projections()[offset] ||
              decoded_offset.completed_edge_projection !=
                  atom.word.completed_edge_projections()[offset]) {
            return false;
          }
        }
      }

      mwperf::ExactRational endpoint_total =
          mwperf::ExactRational::zero();
      for (const auto& endpoint : row.endpoint_atoms) {
        if (endpoint.endpoint_index >= kernel.domain().states().size() ||
            endpoint.exact_mass <= mwperf::ExactRational::zero()) {
          return false;
        }
        endpoint_total = endpoint_total + endpoint.exact_mass;
      }
      if (endpoint_total != mwperf::ExactRational::one()) {
        return false;
      }
    }

    ++accepted_handoffs_;
    return true;
  }

  [[nodiscard]] std::size_t consume_calls() const noexcept {
    return consume_calls_;
  }
  [[nodiscard]] std::size_t accepted_handoffs() const noexcept {
    return accepted_handoffs_;
  }
  [[nodiscard]] std::size_t word_decoder_calls() const noexcept {
    return word_decoder_calls_;
  }
  [[nodiscard]] std::size_t offset_decoder_calls() const noexcept {
    return offset_decoder_calls_;
  }
  [[nodiscard]] std::size_t event_law_selection_calls() const noexcept {
    return event_law_selection_calls_;
  }
  [[nodiscard]] std::size_t invariant_solve_calls() const noexcept {
    return invariant_solve_calls_;
  }
  [[nodiscard]] std::size_t suspension_calls() const noexcept {
    return suspension_calls_;
  }
  [[nodiscard]] std::size_t slot_stationary_result_calls() const noexcept {
    return slot_stationary_result_calls_;
  }

 private:
  [[nodiscard]] static bool same_word_rows(
      const mwperf::ResidenceWordRow& left,
      const mwperf::ResidenceWordRow& right) {
    if (left.entry_state() != right.entry_state() ||
        left.exact_total_mass() != right.exact_total_mass() ||
        left.representation_budget() != right.representation_budget() ||
        left.provider_fingerprint() != right.provider_fingerprint() ||
        left.atoms().size() != right.atoms().size()) {
      return false;
    }
    for (std::size_t index = 0U; index < left.atoms().size(); ++index) {
      const auto& left_atom = left.atoms()[index];
      const auto& right_atom = right.atoms()[index];
      if (left_atom.exact_mass != right_atom.exact_mass ||
          left_atom.structural_support != right_atom.structural_support ||
          left_atom.exact_cumulative_mass !=
              right_atom.exact_cumulative_mass ||
          left_atom.word.word_digest() !=
              right_atom.word.word_digest()) {
        return false;
      }
    }
    return true;
  }

  std::size_t consume_calls_{0U};
  std::size_t accepted_handoffs_{0U};
  std::size_t word_decoder_calls_{0U};
  std::size_t offset_decoder_calls_{0U};
  std::size_t event_law_selection_calls_{0U};
  std::size_t invariant_solve_calls_{0U};
  std::size_t suspension_calls_{0U};
  std::size_t slot_stationary_result_calls_{0U};
};

template <typename AtomRange>
[[nodiscard]] mwperf::CompensatedNumericalRowImageV1
recompute_numerical_image(const AtomRange& atoms) {
  long double sum = 0.0L;
  long double correction = 0.0L;
  auto status = mwperf::NumericalProbabilityImageStatusV1::finite;
  for (const auto& atom : atoms) {
    const long double updated = sum + atom.numerical_image;
    if (std::fabs(sum) >= std::fabs(atom.numerical_image)) {
      correction += (sum - updated) + atom.numerical_image;
    } else {
      correction += (atom.numerical_image - updated) + sum;
    }
    sum = updated;
    if (atom.numerical_image_status ==
        mwperf::NumericalProbabilityImageStatusV1::overflow) {
      status = mwperf::NumericalProbabilityImageStatusV1::overflow;
    } else if (
        status == mwperf::NumericalProbabilityImageStatusV1::finite &&
        atom.numerical_image_status ==
            mwperf::NumericalProbabilityImageStatusV1::positive_underflow) {
      status =
          mwperf::NumericalProbabilityImageStatusV1::positive_underflow;
    }
  }
  const long double total = sum + correction;
  return {total, total - 1.0L, status};
}

[[nodiscard]] mwperf::ReducedInitialLaw make_initial_law(
    const mwperf::ResolvedInstance& instance,
    const mwperf::AuditedCompiledFramework& framework) {
  REQUIRE(instance.analysis_spec().context);
  auto law = mwperf::construct_reduced_initial_law(
      instance, framework, instance.analysis_spec().context->selection,
      std::nullopt);
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  REQUIRE(mwperf::validate_reduced_initial_law_v1(law.value()));
  return std::move(law).value();
}

template <typename ProgramMutation>
[[nodiscard]] mwperf::AuditedCompiledFramework seal_temporal_profile(
    const mwperf::testing::c16_registered_pair_matrix::ProfileV1& profile,
    ProgramMutation&& mutate_program) {
  auto prepared =
      mwperf::testing::c17_temporal::prepare_profile_temporal_framework(
          profile, std::forward<ProgramMutation>(mutate_program));
  auto framework = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return std::move(framework).value();
}

template <typename ProgramMutation>
[[nodiscard]] mwperf::AuditedCompiledFramework seal_temporal_scenario(
    mwperf::testing::C16DesignatedScenarioV1 scenario,
    ProgramMutation&& mutate_program) {
  auto prepared =
      mwperf::testing::c17_temporal::prepare_profile_temporal_framework(
          std::move(scenario),
          std::forward<ProgramMutation>(mutate_program));
  auto framework = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return std::move(framework).value();
}

[[nodiscard]] mwperf::testing::c16_designated_detail::InputV1
stopped_path_input(
    const mwperf::testing::c16_registered_pair_matrix::ProfileV1& profile) {
  namespace designated = mwperf::testing::c16_designated_detail;
  auto source = designated::input(profile.provider_id);
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"first_hit","parameters":{
      "set":{"kind":"equal","level":1},"horizon":2,
      "include_mean":false}}],
    "surrogate":{"id":")json") +
      std::string(profile.provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";
  auto document = mwperf::load_document(
      designated::write_input("c20-stopped-view-gate", analysis));
  REQUIRE(document);
  auto authored = mwperf::parse_analysis_spec_v1(document.value());
  REQUIRE(authored);
  auto request = mwperf::parse_metric_request(
      authored.value().metrics.front(), source.instance.queues());
  REQUIRE(request);
  std::vector<mwperf::MetricRequest> requests{request.value()};
  source.requirements = mwperf::aggregate_metric_requirements(requests);
  source.request = std::move(request).value();
  return source;
}

void check_c20_views_unavailable(
    const mwperf::AuditedCompiledFramework& framework) {
  auto view = mwperf::audited_romr_view(framework);
  auto provider = mwperf::audited_residence_provider(framework);
  auto temporal = mwperf::audited_temporal_framework(framework);
  REQUIRE_FALSE(view);
  REQUIRE_FALSE(provider);
  REQUIRE_FALSE(temporal);
  CHECK(view.error().code == "c17.audited_romr_view_unavailable");
  CHECK(provider.error().code ==
        "c17.audited_residence_provider_unavailable");
  CHECK(temporal.error().code ==
        "c17.audited_temporal_framework_unavailable");
}

void check_path_prefix(const mwperf::TemporalPath& prefix,
                       const mwperf::TemporalPath& longer) {
  CHECK(prefix.initial_state() == longer.initial_state());
  CHECK(prefix.framework_fingerprint() == longer.framework_fingerprint());
  CHECK(prefix.reduced_initial_law_digest() ==
        longer.reduced_initial_law_digest());
  CHECK(prefix.path_stream_identity() == longer.path_stream_identity());
  REQUIRE(prefix.slots().size() <= longer.slots().size());
  for (std::size_t index = 0U; index < prefix.slots().size(); ++index) {
    CHECK(prefix.slots()[index].global_offset ==
          longer.slots()[index].global_offset);
    CHECK(prefix.slots()[index].event_index ==
          longer.slots()[index].event_index);
    CHECK(prefix.slots()[index].residence_offset ==
          longer.slots()[index].residence_offset);
    CHECK(prefix.slots()[index].edge == longer.slots()[index].edge);
    CHECK(prefix.slots()[index].predecision_projection ==
          longer.slots()[index].predecision_projection);
    CHECK(prefix.slots()[index].completed_edge_projection ==
          longer.slots()[index].completed_edge_projection);
  }
  REQUIRE(prefix.completed_words().size() <= longer.completed_words().size());
  for (std::size_t index = 0U; index < prefix.completed_words().size();
       ++index) {
    CHECK(prefix.completed_words()[index].word_digest() ==
          longer.completed_words()[index].word_digest());
  }
  REQUIRE(prefix.event_epochs().size() <= longer.event_epochs().size());
  for (std::size_t index = 0U; index < prefix.event_epochs().size(); ++index) {
    CHECK(prefix.event_epochs()[index] == longer.event_epochs()[index]);
  }
  if (prefix.slots().size() < longer.slots().size()) {
    CHECK(prefix.final_state() ==
          longer.slots()[prefix.slots().size()].edge.pre_state());
  } else {
    CHECK(prefix.final_state() == longer.final_state());
  }
}

TEST_CASE("C20 temporal execution covers exactly the requested horizon",
          "[c20][integration][path]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(temporal);
  const auto initial = make_initial_law(fixture.instance, fixture.framework);

  auto empty = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{0U},
      mwperf::MasterSeed{0xC20400U});
  REQUIRE(empty);
  CHECK(empty.value().horizon() == mwperf::BigNat{0U});
  CHECK(empty.value().slots().empty());
  CHECK(empty.value().completed_words().empty());
  CHECK_FALSE(empty.value().unfinished().has_value());
  CHECK(empty.value().initial_state() == empty.value().final_state());

  auto path = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{3U},
      mwperf::MasterSeed{0xC20400U});
  REQUIRE(path);
  CHECK(empty.value().path_stream_identity() ==
        path.value().path_stream_identity());
  CHECK(path.value().horizon() == mwperf::BigNat{3U});
  REQUIRE(path.value().slots().size() == 3U);
  REQUIRE(path.value().completed_words().size() == 3U);
  CHECK_FALSE(path.value().unfinished().has_value());
  REQUIRE(path.value().event_epochs().size() == 4U);
  CHECK(path.value().event_epochs().front() == mwperf::BigNat{0U});
  CHECK(path.value().event_epochs().back() == mwperf::BigNat{3U});
  for (std::size_t index = 0U; index < path.value().slots().size(); ++index) {
    CHECK(path.value().slots()[index].global_offset == mwperf::BigNat{index});
    CHECK(path.value().slots()[index].event_index == mwperf::BigNat{index});
    CHECK(path.value().slots()[index].residence_offset == mwperf::BigNat{0U});
    CHECK(path.value().slots()[index].edge.stage_trace() ==
          mwperf::kCausalStageOrderV1);
    CHECK(path.value().completed_words()[index].length() ==
          mwperf::BigNat{1U});
    if (index != 0U) {
      const auto& previous = path.value().slots()[index - 1U].edge;
      const auto& current = path.value().slots()[index].edge;
      CHECK(previous.successor_state() == current.pre_state());
      CHECK(mwperf::testing::c17::same_phase(
          previous.arrival().phase_after, current.arrival().phase_before));
    }
  }
  CHECK(path.value().final_state() ==
        path.value().slots().back().edge.successor_state());
}

TEST_CASE("C20 partial horizon owns a resumable deterministic residence",
          "[c20][integration][path][multi-slot][snapshot]") {
  auto fixture =
      mwperf::testing::c20::make_deterministic_three_slot_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(temporal);
  REQUIRE(executor);
  const auto initial = make_initial_law(fixture.instance, fixture.framework);
  REQUIRE(initial.atoms().size() == 1U);
  CHECK(initial.atoms().front().state == fixture.initial_state);
  const auto seed = mwperf::MasterSeed{0xC203530U};

  auto prefix = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{2U}, seed);
  auto complete = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{3U}, seed);
  REQUIRE(prefix);
  REQUIRE(complete);
  REQUIRE(prefix.value().slots().size() == 2U);
  CHECK(prefix.value().completed_words().empty());
  REQUIRE(prefix.value().event_epochs().size() == 1U);
  CHECK(prefix.value().event_epochs().front() == mwperf::BigNat{0U});
  REQUIRE(prefix.value().unfinished().has_value());
  const auto& unfinished = *prefix.value().unfinished();
  CHECK(unfinished.cursor.lifecycle() ==
        mwperf::ResidenceLifecycleV1::open);
  CHECK(unfinished.cursor.offset() == mwperf::BigNat{2U});
  CHECK(unfinished.cursor.version() == mwperf::BigNat{2U});
  CHECK(mwperf::testing::c20::backlog_value(
            unfinished.cursor.current_state()) == 3U);
  CHECK(mwperf::testing::c20::phase_index(
            unfinished.cursor.current_state()) == 2U);
  CHECK(unfinished.rng_snapshot.initialized);
  CHECK(unfinished.audited_view_fingerprint ==
        unfinished.cursor.audited_view_fingerprint());
  CHECK(unfinished.ops_handle_identity ==
        unfinished.cursor.ops_handle().identity());

  REQUIRE(complete.value().slots().size() == 3U);
  REQUIRE(complete.value().completed_words().size() == 1U);
  CHECK_FALSE(complete.value().unfinished().has_value());
  CHECK(complete.value().completed_words().front().length() ==
        mwperf::BigNat{3U});
  for (std::size_t slot = 0U; slot < 2U; ++slot) {
    CHECK(prefix.value().slots()[slot].edge ==
          complete.value().slots()[slot].edge);
    CHECK(prefix.value().slots()[slot].predecision_projection ==
          complete.value().slots()[slot].predecision_projection);
    CHECK(prefix.value().slots()[slot].completed_edge_projection ==
          complete.value().slots()[slot].completed_edge_projection);
  }

  mwperf::ResidenceCursor resumed = unfinished.cursor;
  auto bank = mwperf::testing::C20FixtureAccess::restore_temporal_bank(
      unfinished.rng_snapshot);
  REQUIRE(bank);
  auto third = mwperf::advance_residence(
      resumed, executor.value(), bank.value());
  REQUIRE(third);
  CHECK(third.value().edge() == complete.value().slots()[2U].edge);
  CHECK(third.value().predecision_projection() ==
        complete.value().slots()[2U].predecision_projection);
  CHECK(third.value().completed_edge_projection() ==
        complete.value().slots()[2U].completed_edge_projection);
  auto stop = mwperf::validate_residence_stop(resumed, third.value());
  REQUIRE(stop);
  REQUIRE(stop.value().stops());
  auto resumed_word = mwperf::finalize_residence_word(resumed);
  REQUIRE(resumed_word);
  CHECK(resumed_word.value().word_digest() ==
        complete.value().completed_words().front().word_digest());
  CHECK(resumed_word.value().event_endpoint() ==
        complete.value().final_state());
  CHECK(mwperf::testing::c20::backlog_value(
            resumed_word.value().event_endpoint()) == 2U);
  CHECK(mwperf::testing::c20::phase_index(
            resumed_word.value().event_endpoint()) == 3U);
}

TEST_CASE("C20 temporal path key omits horizon and preserves prefixes",
          "[c20][integration][rng][prefix]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(temporal);
  const auto initial = make_initial_law(fixture.instance, fixture.framework);
  const auto seed = mwperf::MasterSeed{0xC20401U};

  auto short_path = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{2U}, seed);
  auto long_path = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{5U}, seed);
  auto repeated = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{2U}, seed);
  REQUIRE(short_path);
  REQUIRE(long_path);
  REQUIRE(repeated);
  CHECK(short_path.value().path_stream_identity() ==
        long_path.value().path_stream_identity());
  CHECK(short_path.value().path_stream_identity() ==
        repeated.value().path_stream_identity());
  check_path_prefix(short_path.value(), long_path.value());
  check_path_prefix(short_path.value(), repeated.value());
  CHECK(short_path.value().final_state() == repeated.value().final_state());
}

TEST_CASE("C20 every finite horizon coldly replays one common prefix",
          "[c20][integration][rng][prefix][replay]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(temporal);
  const auto initial = make_initial_law(fixture.instance, fixture.framework);
  const auto seed = mwperf::MasterSeed{0xC20403U};

  auto reference = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{6U}, seed);
  REQUIRE(reference);
  for (std::size_t horizon = 0U; horizon <= 6U; ++horizon) {
    auto prefix = mwperf::execute_temporal_path(
        temporal.value(), initial, mwperf::BigNat{horizon}, seed);
    REQUIRE(prefix);
    CHECK(prefix.value().horizon() == mwperf::BigNat{horizon});
    REQUIRE(prefix.value().slots().size() == horizon);
    check_path_prefix(prefix.value(), reference.value());
  }
}

TEST_CASE("C20 enumerable route emits exact complete unit-residence mass",
          "[c20][integration][enumeration]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(row);
  REQUIRE(row.value().atoms().size() == 2U);
  CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());
  for (const auto& atom : row.value().atoms()) {
    CHECK(atom.word.length() == mwperf::BigNat{1U});
    REQUIRE(atom.word.edges().size() == 1U);
    CHECK(atom.word.edges().front().stage_trace() ==
          mwperf::kCausalStageOrderV1);
    CHECK(atom.word.event_endpoint() ==
          atom.word.edges().front().successor_state());
  }
}

TEST_CASE("C20 procedural framework executes through audited C17 slots",
          "[c20][integration][procedural]") {
  auto fixture =
      mwperf::testing::c17_temporal::make_generic_temporal_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(temporal);
  REQUIRE(view);
  REQUIRE(executor);
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE_FALSE(provider);
  CHECK(provider.error().code ==
        "c17.audited_residence_provider_unavailable");

  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC20402U});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(
      cursor.value(), executor.value(), bank.value());
  REQUIRE(step);
  auto stop = mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(stop);
  REQUIRE(stop.value().stops());
  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  CHECK(word.value().length() == mwperf::BigNat{1U});
  CHECK(fixture.residence_generator_calls->load(std::memory_order_relaxed) ==
        0U);

  const auto initial = make_initial_law(fixture.instance, fixture.framework);
  auto path = mwperf::execute_temporal_path(
      temporal.value(), initial, mwperf::BigNat{1U},
      mwperf::MasterSeed{0xC20402U});
  REQUIRE(path);
  REQUIRE(path.value().slots().size() == 1U);
  CHECK(path.value().slots().front().edge.stage_trace() ==
        mwperf::kCausalStageOrderV1);
  CHECK(fixture.residence_generator_calls->load(std::memory_order_relaxed) ==
        0U);
}

TEST_CASE("C20 views exclude a temporal-shaped conditional sampler",
          "[c20][integration][view-gate][sampler]") {
  const auto& profile =
      mwperf::testing::c17_temporal::temporal_profile(
          mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto framework = seal_temporal_profile(
      profile, [](mwperf::ExactCausalProgramV1&) {});

  auto slot = mwperf::audited_slot_executor(framework);
  auto sampler = mwperf::audited_sampler_descriptor(framework);
  REQUIRE(slot);
  REQUIRE(sampler);
  check_c20_views_unavailable(framework);
}

TEST_CASE("C20 views exclude defective stopped-path contracts",
          "[c20][integration][view-gate][stopped][defective]") {
  const auto& profile =
      mwperf::testing::c17_temporal::temporal_profile(
          mwperf::SemanticTagV1::stopped_path_law);
  auto scenario = mwperf::testing::c17_temporal::temporal_scenario(
      stopped_path_input(profile), profile);
  auto framework = seal_temporal_scenario(
      std::move(scenario), [](mwperf::ExactCausalProgramV1&) {});
  auto slot = mwperf::audited_slot_executor(framework);
  REQUIRE(slot);
  check_c20_views_unavailable(framework);
}

TEST_CASE("C20 views require a sealed event-entry domain descriptor",
          "[c20][integration][view-gate][domain]") {
  const auto& profile =
      mwperf::testing::c17_temporal::temporal_profile();
  auto framework = seal_temporal_profile(
      profile, [](mwperf::ExactCausalProgramV1& program) {
        program.finite_event_domain_states.reset();
        program.event_entry_domain_is_exact_state_domain = false;
      });
  auto slot = mwperf::audited_slot_executor(framework);
  REQUIRE(slot);
  check_c20_views_unavailable(framework);
}

TEST_CASE("C20 accepts a declared procedural exact-state event domain",
          "[c20][integration][view-gate][domain][procedural]") {
  const auto& profile =
      mwperf::testing::c17_temporal::temporal_profile();
  auto framework = seal_temporal_profile(
      profile, [](mwperf::ExactCausalProgramV1&) {});
  auto view = mwperf::audited_romr_view(framework);
  auto temporal = mwperf::audited_temporal_framework(framework);
  auto provider = mwperf::audited_residence_provider(framework);
  REQUIRE(view);
  REQUIRE(temporal);
  REQUIRE_FALSE(provider);
  CHECK(provider.error().code ==
        "c17.audited_residence_provider_unavailable");
}

TEST_CASE("C20 finite quotient assembles an exact suspension handoff",
          "[c20][integration][kernel][pushforward][handoff]") {
  auto fixture =
      mwperf::testing::c20::make_four_word_enumerable_framework();
  auto provider =
      mwperf::audited_residence_provider(fixture.temporal.framework);
  REQUIRE(provider);
  auto domain =
      mwperf::FiniteEventStateDomain::from_audited_provider(provider.value());
  REQUIRE(domain);
  REQUIRE_FALSE(domain.value().states().empty());

  // Finite matrix keys are the audited zero-clock quotient representatives.
  for (const auto& state : domain.value().states()) {
    const auto decoded = fixture.temporal.state_schema.decode(state);
    REQUIRE(decoded);
    CHECK(decoded.value().boundary_index == mwperf::BigNat{0U});
  }

  auto kernel = mwperf::assemble_embedded_event_kernel(
      domain.value(), provider.value());
  INFO((kernel ? std::string{}
               : kernel.error().code + ": " + kernel.error().message));
  REQUIRE(kernel);
  REQUIRE(kernel.value().rows().size() == domain.value().states().size());
  CHECK(kernel.value().domain().fingerprint() ==
        domain.value().fingerprint());

  const auto same_quotient_coordinates = [](
                                             const auto& raw,
                                             const auto& representative) {
    const auto raw_phase = mwperf::arrival_phase_canonical_state(
        raw.arrival_phase);
    const auto representative_phase =
        mwperf::arrival_phase_canonical_state(
            representative.arrival_phase);
    return raw.backlog == representative.backlog &&
           mwperf::arrival_phase_family(raw.arrival_phase) ==
               mwperf::arrival_phase_family(
                   representative.arrival_phase) &&
           raw_phase.size() == representative_phase.size() &&
           std::equal(raw_phase.begin(), raw_phase.end(),
                      representative_phase.begin()) &&
           raw.resources == representative.resources &&
           raw.margins == representative.margins &&
           raw.controller == representative.controller &&
           raw.unresolved_fields == representative.unresolved_fields;
  };

  for (std::size_t row_index = 0U;
       row_index < kernel.value().rows().size(); ++row_index) {
    const auto& row = kernel.value().rows()[row_index];
    CHECK(row.word_row.entry_state() == domain.value().states()[row_index]);
    CHECK(row.word_row.exact_total_mass() == mwperf::ExactRational::one());
    CHECK(row.exact_total_mass == mwperf::ExactRational::one());
    CHECK(row.word_row.numerical_row_image() ==
          recompute_numerical_image(row.word_row.atoms()));
    CHECK(row.numerical_row_image ==
          recompute_numerical_image(row.endpoint_atoms));

    std::vector<mwperf::ExactRational> expected_endpoint_mass(
        domain.value().states().size(), mwperf::ExactRational::zero());

    // Complete words retain the physical endpoint clock; only the embedded
    // row above indexes the corresponding zero-clock event representative.
    for (const auto& atom : row.word_row.atoms()) {
      const auto raw = fixture.temporal.state_schema.decode(
          atom.word.event_endpoint());
      REQUIRE(raw);
      CHECK(raw.value().boundary_index == atom.word.length());
      CHECK(raw.value().boundary_index > mwperf::BigNat{0U});
      CHECK_FALSE(domain.value().index_of(
                      atom.word.event_endpoint()).has_value());

      std::optional<std::size_t> quotient_index;
      for (std::size_t candidate = 0U;
           candidate < domain.value().states().size(); ++candidate) {
        const auto representative = fixture.temporal.state_schema.decode(
            domain.value().states()[candidate]);
        REQUIRE(representative);
        if (same_quotient_coordinates(raw.value(), representative.value())) {
          REQUIRE_FALSE(quotient_index.has_value());
          quotient_index = candidate;
        }
      }
      REQUIRE(quotient_index.has_value());
      expected_endpoint_mass[*quotient_index] =
          expected_endpoint_mass[*quotient_index] + atom.exact_mass;
    }

    mwperf::ExactRational endpoint_total =
        mwperf::ExactRational::zero();
    std::size_t expected_nonzero = 0U;
    for (const auto& mass : expected_endpoint_mass) {
      expected_nonzero += mass == mwperf::ExactRational::zero() ? 0U : 1U;
    }
    REQUIRE(row.endpoint_atoms.size() == expected_nonzero);
    for (const auto& endpoint : row.endpoint_atoms) {
      REQUIRE(endpoint.endpoint_index < domain.value().states().size());
      const auto projected = fixture.temporal.state_schema.decode(
          domain.value().states()[endpoint.endpoint_index]);
      REQUIRE(projected);
      CHECK(projected.value().boundary_index == mwperf::BigNat{0U});
      CHECK(endpoint.exact_mass ==
            expected_endpoint_mass[endpoint.endpoint_index]);
      endpoint_total = endpoint_total + endpoint.exact_mass;
    }
    CHECK(endpoint_total == mwperf::ExactRational::one());
  }

  const auto exact_word_decoder =
      [&schema = fixture.temporal.state_schema](
          const mwperf::ResidenceWord& word) {
        const auto endpoint = schema.decode(word.event_endpoint());
        REQUIRE(endpoint);
        return C20DecodedResidenceWordV1{
            word.length(), word.entry_state(), word.event_endpoint(),
            endpoint.value().boundary_index, word.word_digest()};
      };
  const auto exact_offset_decoder = [](
                                        const mwperf::ResidenceWord& word,
                                        const std::size_t offset) {
    REQUIRE(offset < word.edges().size());
    REQUIRE(offset < word.predecision_projections().size());
    REQUIRE(offset < word.completed_edge_projections().size());
    return C20DecodedResidenceOffsetV1{
        offset,
        word.edges()[offset].pre_state(),
        word.edges()[offset].successor_state(),
        word.predecision_projections()[offset],
        word.completed_edge_projections()[offset]};
  };
  C20SuspensionInputSinkSpy handoff_sink;
  REQUIRE(handoff_sink.consume(
      kernel.value(), provider.value(), exact_word_decoder,
      exact_offset_decoder));
  CHECK(handoff_sink.consume_calls() == 1U);
  CHECK(handoff_sink.accepted_handoffs() == 1U);
  CHECK(handoff_sink.word_decoder_calls() > 0U);
  CHECK(handoff_sink.offset_decoder_calls() > 0U);
  CHECK(handoff_sink.event_law_selection_calls() == 0U);
  CHECK(handoff_sink.invariant_solve_calls() == 0U);
  CHECK(handoff_sink.suspension_calls() == 0U);
  CHECK(handoff_sink.slot_stationary_result_calls() == 0U);
  CHECK(fixture.cminus_realize_calls->load(std::memory_order_relaxed) ==
        0U);
  CHECK(fixture.cminus_enumerate_calls->load(std::memory_order_relaxed) >
        0U);
}

TEST_CASE("C20 refuses finite-kernel assembly for an exact countable domain",
          "[c20][integration][kernel][domain][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(provider);

  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(row);
  CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());

  auto domain =
      mwperf::FiniteEventStateDomain::from_audited_provider(provider.value());
  REQUIRE_FALSE(domain);
  CHECK(domain.error().code == "c20.finite_event_domain_unavailable");
}

TEST_CASE("C20 rejects foreign initial laws before temporal execution",
          "[c20][integration][initial-law][binding][negative]") {
  auto left = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto right = mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto temporal = mwperf::audited_temporal_framework(left.framework);
  REQUIRE(temporal);
  const auto left_initial = make_initial_law(left.instance, left.framework);
  const auto foreign_initial =
      make_initial_law(right.instance, right.framework);
  const auto seed = mwperf::MasterSeed{0xC20404U};

  auto rejected = mwperf::execute_temporal_path(
      temporal.value(), foreign_initial, mwperf::BigNat{1U}, seed);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c20.initial_law_binding_mismatch");

  auto first = mwperf::execute_temporal_path(
      temporal.value(), left_initial, mwperf::BigNat{2U}, seed);
  auto repeated = mwperf::execute_temporal_path(
      temporal.value(), left_initial, mwperf::BigNat{2U}, seed);
  REQUIRE(first);
  REQUIRE(repeated);
  check_path_prefix(first.value(), repeated.value());
}

TEST_CASE("C20 rejects a horizon larger than native path indexing",
          "[c20][integration][horizon][overflow][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(temporal);
  const auto initial = make_initial_law(fixture.instance, fixture.framework);
  mwperf::BigInt magnitude{1U};
  magnitude <<= std::numeric_limits<std::size_t>::digits;
  auto huge_horizon = mwperf::BigNat::from_big_int(std::move(magnitude));
  REQUIRE(huge_horizon);

  auto rejected = mwperf::execute_temporal_path(
      temporal.value(), initial, huge_horizon.value(),
      mwperf::MasterSeed{0xC20405U});
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c20.horizon_storage_overflow");
}

TEST_CASE("C20 adapted exit observes the completed two-branch slot",
          "[c20][integration][adapted-stop][large-cell]") {
  auto fixture = mwperf::testing::c20::make_adapted_exit_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  REQUIRE_FALSE(provider);
  CHECK(provider.error().code ==
        "c17.audited_residence_provider_unavailable");
  CHECK(mwperf::testing::c20::adapted_full_backlog(
            fixture.initial_state) ==
        std::vector<std::uint8_t>{10U, 9U, 8U});
  CHECK_FALSE(mwperf::testing::c20::adapted_pair_cell_exited(
      fixture.initial_state));

  // tau_pair is first positive: the public C20 state machine cannot seal the
  // anticipative tau_pair-1 = 0 word before a completed edge exists.
  auto time_zero = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(time_zero);
  CHECK(time_zero.value().offset() == mwperf::BigNat{0U});
  auto anticipative = mwperf::finalize_residence_word(time_zero.value());
  REQUIRE_FALSE(anticipative);
  CHECK(anticipative.error().code == "c20.cursor_not_stopped");

  auto q0 = fixture.instance.queues().index_at(0U);
  auto q1 = fixture.instance.queues().index_at(1U);
  auto q2 = fixture.instance.queues().index_at(2U);
  REQUIRE(q0);
  REQUIRE(q1);
  REQUIRE(q2);

  bool saw_staying_branch = false;
  bool saw_exiting_branch = false;
  for (std::uint64_t seed = 0U;
       seed < 128U && !(saw_staying_branch && saw_exiting_branch); ++seed) {
    auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
    REQUIRE(cursor);
    auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
        view.value(), fixture.instance,
        mwperf::MasterSeed{0xC20A000U + seed});
    REQUIRE(bank);
    auto step = mwperf::advance_residence(
        cursor.value(), executor.value(), bank.value());
    INFO((step ? std::string{}
               : step.error().code + ": " + step.error().message));
    REQUIRE(step);

    const auto& edge = step.value().edge();
    CHECK(edge.stage_trace() == mwperf::kCausalStageOrderV1);
    CHECK(mwperf::testing::c20::adapted_full_backlog(edge.pre_state()) ==
          std::vector<std::uint8_t>{10U, 9U, 8U});
    static constexpr std::array<std::uint8_t, 3U> expected_service{
        1U, 0U, 0U};
    CHECK(std::ranges::equal(edge.action().schedule.bytes(),
                             expected_service));
    CHECK(std::ranges::equal(edge.action().actual_departure.bytes(),
                             expected_service));
    REQUIRE(edge.arrival().batch.binding().has_value());
    const auto& binding = *edge.arrival().batch.binding();
    auto arrival0 = mwperf::project_arrival_count(
        edge.arrival().batch, q0.value(), binding);
    auto arrival1 = mwperf::project_arrival_count(
        edge.arrival().batch, q1.value(), binding);
    auto arrival2 = mwperf::project_arrival_count(
        edge.arrival().batch, q2.value(), binding);
    REQUIRE(arrival0);
    REQUIRE(arrival1);
    REQUIRE(arrival2);
    REQUIRE(arrival1.value().is_zero());
    const bool large = arrival0.value() == mwperf::BigNat{2U};
    if (large) {
      CHECK(arrival2.value() == mwperf::BigNat{4U});
    } else {
      CHECK(arrival0.value().is_zero());
      CHECK(arrival2.value().is_zero());
    }

    const std::vector<std::uint8_t> expected =
        large ? std::vector<std::uint8_t>{11U, 9U, 12U}
              : std::vector<std::uint8_t>{9U, 9U, 8U};
    CHECK(mwperf::testing::c20::adapted_full_backlog(
              edge.successor_state()) == expected);
    CHECK(mwperf::testing::c20::adapted_pair_cell_exited(
              edge.successor_state()) == large);
    auto decoded_successor =
        fixture.state_schema.decode(edge.successor_state());
    REQUIRE(decoded_successor);
    REQUIRE(decoded_successor.value().margins.size() == 1U);
    const auto& corrected_margin =
        decoded_successor.value().margins.front();
    CHECK(corrected_margin.pair_valid() == !large);
    CHECK(corrected_margin.old_pair_linear_coordinate() ==
          mwperf::BigInt(large ? 2 : 0));
    CHECK(corrected_margin.reoptimized_margin() ==
          mwperf::BigInt(large ? -1 : 0));
    CHECK(corrected_margin.regret0() ==
          mwperf::BigNat{large ? 3U : 0U});
    CHECK(corrected_margin.regret1().is_zero());

    // The stop callback is evaluated only now, over the completed successor.
    auto decision =
        mwperf::validate_residence_stop(cursor.value(), step.value());
    REQUIRE(decision);
    CHECK(decision.value().offset() == mwperf::BigNat{1U});
    CHECK(decision.value().stops() == large);
    if (large) {
      saw_exiting_branch = true;
      auto word = mwperf::finalize_residence_word(cursor.value());
      REQUIRE(word);
      CHECK(word.value().length() == mwperf::BigNat{1U});
      CHECK(mwperf::testing::c20::adapted_full_backlog(
                word.value().raw_terminal_state()) == expected);
      CHECK(mwperf::testing::c20::adapted_full_backlog(
                word.value().event_endpoint()) == expected);
      CHECK(mwperf::testing::c20::adapted_pair_cell_exited(
          word.value().event_endpoint()));
    } else {
      saw_staying_branch = true;
      CHECK(cursor.value().lifecycle() ==
            mwperf::ResidenceLifecycleV1::open);
      auto not_stopped = mwperf::finalize_residence_word(cursor.value());
      REQUIRE_FALSE(not_stopped);
      CHECK(not_stopped.error().code == "c20.cursor_not_stopped");
    }
  }
  CHECK(saw_staying_branch);
  CHECK(saw_exiting_branch);
}

}  // namespace
