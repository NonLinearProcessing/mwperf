#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/app/result_artifact.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/diagnostics/error_budget.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/typed_label.hpp"
#include "support/c30_observation_fixture.hpp"

namespace mwperf {

// Private C27 test seam: production callers cannot submit arbitrary JSON to
// the writer and therefore cannot bypass the typed ResultArtifact boundary.
[[nodiscard]] Result<void> validate_result_v1_json_schema_for_test(
    std::string_view document);

}  // namespace mwperf

namespace {

[[nodiscard]] mwperf::Digest256 digest(const std::string_view name) {
  const auto* first = reinterpret_cast<const std::byte*>(name.data());
  auto result = mwperf::sha256_domain_separated(
      "mwperf.c27.result.fixture",
      std::span<const std::byte>(first, name.size()));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto result = mwperf::TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TypedLabel numeric_label(const std::uint64_t value) {
  return mwperf::TypedLabel::numeric(mwperf::BigNat{value});
}

[[nodiscard]] mwperf::QueueId queue(const std::string& value) {
  return mwperf::QueueId(text_label(value));
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object_reference(
    const std::string& value) {
  return {.object_id = text_label(value),
          .object_digest = digest(value + ".digest")};
}

[[nodiscard]] mwperf::PortableScientificScalar rational(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(value);
  return mwperf::PortableScientificScalar::rational(
      std::move(value).value());
}

[[nodiscard]] mwperf::ResultMetricHeaderV1 metric_header(
    const std::string& id, const mwperf::MetricKindV1 kind) {
  return {
      .metric_id = id,
      .kind = kind,
      .ordered_targets = {queue("q0")},
      .units = "packets",
      .convention = "early_service_late_admission",
      .law_identity = digest(id + ".law"),
      .scientific_scope = mwperf::MetricResultScopeV1::surrogate_law,
      .assumptions = {"fixture assumption"},
      .error_refs = {},
      .residual_refs = {},
  };
}

[[nodiscard]] mwperf::ResultDiagnosticV1 execution_diagnostic(
    const std::string& id, const std::string& code) {
  return {
      .diagnostic_id = id,
      .category = mwperf::DiagnosticCategory::internal,
      .code = code,
      .message = "fixture execution diagnostic",
      .component_scope = std::nullopt,
      .kind = mwperf::ResultDiagnosticKindV1::execution,
      .product = std::nullopt,
      .value = std::nullopt,
      .assumptions = {},
      .evidence_refs = {},
  };
}

[[nodiscard]] mwperf::ResultCertificateV1 v0_certificate(
    const std::string& id, const std::string& diagnostic_ref) {
  return {
      .certificate_id = id,
      .kind = mwperf::CertificateClaimKindV1::validation,
      .claim_state = mwperf::CertificateClaimStateV1::established,
      .assumptions = {"fixture V0 premise"},
      .evidence_refs = {},
      .diagnostic_refs = {diagnostic_ref},
  };
}

[[nodiscard]] mwperf::ResultDiagnosticV1 scoped_component(
    const std::string& id, const mwperf::ComponentScopeV1 scope,
    const mwperf::ProductKindV1 product_kind) {
  return {
      .diagnostic_id = id,
      .category = mwperf::DiagnosticCategory::information,
      .code = id,
      .message = "separate scoped component",
      .component_scope = scope,
      .kind = mwperf::ResultDiagnosticKindV1::component,
      .product = mwperf::ResultProductBindingV1{
          .product_kind = product_kind,
          .provider = {"c27-fixture-provider", "1.0.0"},
          .artifact_identity = object_reference(id + ".artifact"),
          .payload_identity = object_reference(id + ".payload"),
          .build_identity = digest(id + ".build"),
          .request_identity = digest(id + ".request"),
          .product_identity = object_reference(id + ".product"),
          .response_target =
              product_kind == mwperf::ProductKindV1::recoded_response
                  ? std::optional<mwperf::QueueId>(queue("q0"))
                  : std::nullopt,
          .ordered_construction_targets =
              product_kind == mwperf::ProductKindV1::projection_center
                  ? std::vector<mwperf::QueueId>{queue("q0")}
                  : std::vector<mwperf::QueueId>{},
          .phase_identity = std::nullopt,
          .frozen_input_bank_id = std::nullopt,
          .final_probe_id = text_label("final-probe"),
          .raw_value_form = std::nullopt,
          .response_bin =
              product_kind == mwperf::ProductKindV1::recoded_response
                  ? std::optional<mwperf::ThreeBinCoefficientV1>(
                        mwperf::ThreeBinCoefficientV1::tail_from_three)
                  : std::nullopt,
          .law_identity = std::nullopt,
      },
      .value = mwperf::ResultDiagnosticIntervalV1{
          .claim_state = mwperf::CertificateClaimStateV1::established,
          .value_status = mwperf::BoundValueStatusV1::finite,
          .lower = rational(0),
          .upper = rational(1, 10),
      },
      .assumptions = {"fixture separation premise"},
      .evidence_refs = {},
  };
}

[[nodiscard]] mwperf::ResultArtifactDataV1 base_data(
    const mwperf::ResultStatusV1 status,
    std::vector<std::string> metric_ids) {
  const mwperf::Digest256 model = digest("model");
  const mwperf::Digest256 analysis = digest("analysis");
  const mwperf::Digest256 combined = digest("combined");
  const mwperf::BuildIdentityDigest build_identity(digest("build-identity"));
  const mwperf::MasterSeed master_seed(0x12345678U);
  const mwperf::BuildSeed build_seed(master_seed, build_identity);

  return {
      .status = status,
      .failure = std::nullopt,
      .input_fingerprints =
          mwperf::InputFingerprintBundle{
              .model = model,
              .analysis = analysis,
              .combined = combined,
          },
      .build =
          mwperf::ResultBuildProvenanceV1{
              .core = "c27-test-core",
              .rng = "rng-v1",
              .interfaces = "interfaces-v1",
          },
      .execution =
          mwperf::ResultExecutionProvenanceV1{
              .actual_seed = master_seed,
              .build_request_identity = mwperf::ResultBuildRequestIdentityV1{
                  .build_identity_digest = build_identity,
                  .build_seed = build_seed,
                  .build_request_digest = mwperf::SurrogateBuildRequestDigest(
                      digest("build-request")),
              },
              .replay_streams =
                  {mwperf::ResultConstructionReplayStreamV1{
                       .stage_tag = mwperf::StageTag::surrogate_build_probe,
                       .stream_instance_id = text_label("proposal-probe-4"),
                       .draws = mwperf::BigNat{11U},
                   },
                   mwperf::ResultRuntimeReplayStreamV1{
                       .stage_tag = mwperf::StageTag::solver_sampling,
                       .stream_identity = digest("solver-stream"),
                       .draws = mwperf::BigNat{7U},
                   }},
              .budget_usage =
                  {mwperf::ResultBudgetUsageV1{
                      .name =
                          "construction.configured_generator_draws",
                      .applicability =
                          mwperf::ResultBudgetApplicabilityV1::applicable,
                      .granted = mwperf::BigNat{11U},
                      .used = mwperf::BigNat{11U},
                      .unit = "count",
                  }},
              .execution_seal_digest = digest("execution-seal"),
          },
      .model =
          mwperf::ResultModelProvenanceV1{
              .schema_version = "3.0.0",
              .fingerprint = model,
          },
      .analysis =
          mwperf::ResultAnalysisProvenanceV1{
              .schema_version = "1.0.0",
              .fingerprint = analysis,
              .ordered_targets = {queue("q0")},
              .metric_ids = std::move(metric_ids),
              .selection = mwperf::PortableStationaryUniqueSelectionV1{},
              .solver_regime = mwperf::MetricSolverRegimeV1::analytic,
          },
      .surrogate =
          mwperf::ResultSurrogateProvenanceV1{
              .provider = {"c27-fixture-provider", "1.0.0"},
              .construction_method =
                  mwperf::ConstructionMethodV1::engineered_deterministic,
              .producer_mode = mwperf::ProducerModeV1::inline_immediate,
              .provider_digest = mwperf::ProviderScientificContractDigest(
                  digest("provider-scientific-contract")),
              .payload_digest = digest("payload"),
              .plug_kind = "three_bin_scalar_response_v1",
          },
      .metrics = {},
      .certificates = {},
      .diagnostics = {},
      .budgets_used = {},
      .config_name = "fixture.json",
      .response_curve = std::nullopt,
      .wall_clock_times =
          mwperf::ResultWallClockTimesV1{
              .end_to_end = std::chrono::seconds(3),
              .sampler = std::chrono::seconds(1),
              .framework = std::chrono::seconds(2),
          },
      .output_resources = false,
      .worker_count = 2U,
      .optimizer_calls_observed = mwperf::BigNat{0U},
      .optimizer_search_states_observed = mwperf::BigNat{0U},
  };
}

[[nodiscard]] mwperf::ResultArtifactDataV1 successful_data() {
  auto data = base_data(mwperf::ResultStatusV1::success,
                        {"exact", "infinite", "defective"});
  data.response_curve = mwperf::ResultResponseCurveV1{
      .target = queue("q0"),
      .backlog_zero = rational(0),
      .backlog_one = rational(1, 2),
      .backlog_two = rational(3, 4),
      .backlog_at_least_three = rational(7, 8),
  };
  data.metrics.emplace_back(mwperf::EstablishedResultMetricV1{
      .header = metric_header("exact",
                              mwperf::MetricKindV1::stationary_backlog_moment),
      .value = rational(3, 4),
  });
  data.metrics.emplace_back(mwperf::EstablishedResultMetricV1{
      .header = metric_header("infinite",
                              mwperf::MetricKindV1::stationary_backlog_moment),
      .value = mwperf::PositiveInfinityV1{},
  });
  data.metrics.emplace_back(mwperf::EstablishedResultMetricV1{
      .header = metric_header("defective", mwperf::MetricKindV1::first_hit),
      .value = mwperf::ResultProbabilityLawV1{
          .coordinate_names = {"hitting_time"},
          .atoms = {{.outcome = {text_label("1")}, .mass = rational(1, 4)},
                    {.outcome = {numeric_label(1U)},
                     .mass = rational(1, 4)}},
          .defective_mass = rational(1, 2),
          .defective_mass_proven = true,
      },
  });
  data.diagnostics.push_back(scoped_component(
      "diag.projection", mwperf::ComponentScopeV1::projection,
      mwperf::ProductKindV1::projection_center));
  data.diagnostics.push_back(scoped_component(
      "diag.recode", mwperf::ComponentScopeV1::recode,
      mwperf::ProductKindV1::recoded_response));
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV1 unavailable_data() {
  auto data =
      base_data(mwperf::ResultStatusV1::unavailable, {"mean-backlog"});
  data.surrogate.payload_digest = std::nullopt;
  data.surrogate.plug_kind = std::nullopt;
  data.execution.execution_seal_digest = std::nullopt;
  data.execution.replay_streams.clear();
  data.execution.budget_usage.front().used = mwperf::BigNat{0U};
  data.diagnostics.push_back(
      execution_diagnostic("diag.unavailable", "required_metric_unavailable"));
  data.metrics.emplace_back(mwperf::UnavailableResultMetricV1{
      .header = metric_header(
          "mean-backlog", mwperf::MetricKindV1::stationary_backlog_moment),
      .reason_code = "required_metric_unavailable",
      .diagnostic_refs = {"diag.unavailable"},
  });
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV1 k_wide_unavailable_data(
    const bool report_diagnostics) {
  auto data =
      base_data(mwperf::ResultStatusV1::unavailable, {"mean-backlog"});
  data.surrogate.plug_kind =
      "finite_prefix_constant_tail_response_v1";
  data.diagnostics.push_back(execution_diagnostic(
      "diag.k-wide-unavailable", "c27.k_bin_metric_not_established"));
  data.metrics.emplace_back(mwperf::UnavailableResultMetricV1{
      .header = metric_header(
          "mean-backlog", mwperf::MetricKindV1::stationary_backlog_moment),
      .reason_code = "c27.k_bin_metric_not_established",
      .diagnostic_refs = {"diag.k-wide-unavailable"},
  });
  std::vector<mwperf::ResultKBinCoefficientDiagnosticV1> coefficients;
  const std::array<mwperf::PortableScientificScalar, 4U> nominal{
      rational(0), rational(1, 2), rational(1, 2), rational(1, 4)};
  for (std::size_t index = 0U; index < nominal.size(); ++index) {
    coefficients.push_back(mwperf::ResultKBinCoefficientDiagnosticV1{
        .coordinate_kind =
            index == 0U
                ? mwperf::ResultKBinCoordinateKindV1::structural_level_zero
                : (index < 3U
                       ? mwperf::ResultKBinCoordinateKindV1::exact_level
                       : mwperf::ResultKBinCoordinateKindV1::constant_tail),
        .level_or_tail_from = mwperf::BigNat{
            static_cast<std::uint64_t>(index)},
        .pooled_unserved_mass = rational(index == 0U ? 0 : 1, 8),
        .pooled_served_mass = rational(index == 0U ? 0 : 1, 16),
        .nominal_service_probability = nominal[index],
        .construction_interval_lower = rational(0),
        .construction_interval_upper = rational(1),
    });
  }
  data.unavailable_diagnostics = mwperf::ResultUnavailableDiagnosticsV1{
      .response_cutoff = mwperf::BigNat{2U},
      .causes =
          {mwperf::ResultUnavailableCauseV1{
              .code = "c27.k_bin_metric_not_established",
              .message = "the C19 finite-prefix summary did not establish the requested metric",
              .metric_id = "mean-backlog",
          }},
      .coefficient_diagnostics = std::move(coefficients),
      .c19 =
          mwperf::ResultC19UnavailableDiagnosticsV1{
              .analytic_status = "outside_strict_tail_profile",
              .arrival_mean = rational(1, 2),
              .service_by_level =
                  {rational(0), rational(1, 2), rational(1, 2)},
              .tail_from = mwperf::BigNat{3U},
              .tail_service = rational(1, 4),
              .tail_slack = rational(-1, 4),
              .tail_slack_applicability = "applicable",
              .normalization_residual = rational(0),
              .invariance_residual = rational(0),
              .tail_remainder_bound = std::nullopt,
              .terms_evaluated = mwperf::BigNat{3U},
          },
  };
  data.report_unavailable_diagnostics = report_diagnostics;
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV1 failed_data() {
  auto data = base_data(mwperf::ResultStatusV1::failed, {"mean-backlog"});
  data.failure = mwperf::ResultFailureV1{
      .stage = mwperf::ResultFailureStageV1::backend,
      .code = "backend_fixture_failure",
      .diagnostic_refs = {"diag.failure"},
  };
  data.metrics.clear();
  data.diagnostics.push_back(
      execution_diagnostic("diag.failure", "backend_fixture_failure"));
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV1
request_construction_failed_data() {
  auto data = failed_data();
  data.failure->stage =
      mwperf::ResultFailureStageV1::request_construction;
  data.failure->code = "request_fixture_failure";
  data.diagnostics.front().code = "request_fixture_failure";
  data.execution.build_request_identity = std::nullopt;
  data.execution.replay_streams.clear();
  data.execution.budget_usage.clear();
  data.execution.execution_seal_digest = std::nullopt;
  data.surrogate.payload_digest = std::nullopt;
  data.surrogate.plug_kind = std::nullopt;
  data.budgets_used.clear();
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV1
nonbuilt_construction_accounting_failure_data() {
  auto data = failed_data();
  data.failure->stage =
      mwperf::ResultFailureStageV1::build_contract_validation;
  data.execution.replay_streams.clear();
  data.execution.execution_seal_digest = std::nullopt;
  data.surrogate.payload_digest = std::nullopt;
  data.surrogate.plug_kind = std::nullopt;
  return data;
}

[[nodiscard]] std::filesystem::path result_directory() {
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c27-result";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  return directory;
}

[[nodiscard]] std::string read_bytes(const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  REQUIRE(input.is_open());
  return std::string(std::istreambuf_iterator<char>(input),
                     std::istreambuf_iterator<char>());
}

void write_bytes(const std::filesystem::path& path,
                 const std::string_view bytes) {
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  REQUIRE(output.good());
}

[[nodiscard]] nlohmann::ordered_json valid_c30_result_v2_json(
    const bool with_gap_telemetry = false,
    const bool with_registered_empty_start = false,
    const bool with_partial_replications = false) {
  mwperf::ConstructionObservationBundleV1 raw_observation =
      with_gap_telemetry
          ? mwperf::testing::c30::exact_gap_bundle(
                mwperf::ObservationSourceRoleV1::short_restart_reference)
          : mwperf::testing::c30::exact_bundle(
                mwperf::ObservationSourceRoleV1::short_restart_reference);
  if (with_registered_empty_start) {
    auto registered_digest =
        mwperf::registered_empty_backlog_initial_law_digest_v1();
    REQUIRE(registered_digest);
    raw_observation.initialization = mwperf::ObservationInitializationV1{
        "empty_backlog_v1", std::move(registered_digest).value()};
  }
  if (with_partial_replications) {
    auto partial_block = raw_observation.replications.front().blocks.front();
    partial_block.completeness =
        mwperf::ObservationCompletenessV1::partial;
    partial_block.committed_through_boundary = 2U;
    REQUIRE(partial_block.levels.size() >= 2U);
    partial_block.levels.erase(partial_block.levels.begin() + 2U,
                               partial_block.levels.end());
    partial_block.exposure_mass_balance =
        mwperf::testing::c30::exact_balance(2);
    partial_block.committed_boundary_law.boundary = 2U;

    auto partial = raw_observation.replications.front();
    partial.replication_id =
        mwperf::TypedLabel::numeric(mwperf::BigNat{1U});
    partial.replay_identity = mwperf::testing::c30::digest('c');
    partial.completeness = mwperf::ObservationCompletenessV1::partial;
    partial.committed_through_boundary = 2U;
    partial.blocks = {std::move(partial_block)};
    raw_observation.replications.push_back(std::move(partial));

    auto empty = raw_observation.replications.front();
    empty.replication_id =
        mwperf::TypedLabel::numeric(mwperf::BigNat{2U});
    empty.replay_identity = mwperf::testing::c30::digest('d');
    empty.completeness = mwperf::ObservationCompletenessV1::partial;
    empty.committed_through_boundary = raw_observation.warmup_boundary;
    empty.blocks.clear();
    raw_observation.replications.push_back(std::move(empty));
  }
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(
          std::move(raw_observation)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      std::move(validated).value());
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}};
  options.run_diagnostic_fits = false;
  options.compute_delete_one_replication_jackknife = false;
  auto analyzed =
      mwperf::analyze_compression_observations_v1(*observation, options);
  REQUIRE(analyzed);
  auto analysis =
      std::make_shared<const mwperf::CompressionAnalysisResultV1>(
          std::move(analyzed).value());
  auto supplement =
      std::make_shared<const mwperf::AnalysisDiagnosticSupplementV2>(
          std::move(observation), std::move(analysis), std::nullopt,
          mwperf::AnalysisProviderSuppliedProfileV2{
              mwperf::AnalysisProviderSuppliedProfileStatusV2::
                  not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDecoderProfileV2{
              mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDiagnosticTerminalV2{
              mwperf::ResultStatusV1::success, std::nullopt,
              std::nullopt},
          options);
  auto artifact = mwperf::make_result_artifact_v2_for_test(
      mwperf::ResultArtifactDataV2{successful_data(),
                                   std::move(supplement)});
  REQUIRE(artifact);
  auto encoded =
      mwperf::canonical_result_artifact_v2_json_for_test(artifact.value());
  REQUIRE(encoded);
  return nlohmann::ordered_json::parse(encoded.value());
}

[[nodiscard]] mwperf::Result<mwperf::ParsedResultArtifactV2>
parse_c30_result_v2(const std::string& document) {
  return mwperf::parse_result_artifact_v2(
      std::as_bytes(std::span(document.data(), document.size())),
      mwperf::default_result_artifact_parse_limits_v2());
}

[[nodiscard]] mwperf::Result<mwperf::ParsedResultArtifactV2>
parse_c30_result_v2(const nlohmann::ordered_json& document) {
  return parse_c30_result_v2(document.dump());
}

[[nodiscard]] bool contains_object_key(const nlohmann::json& value,
                                       const std::string_view key) {
  if (value.is_object()) {
    for (auto member = value.begin(); member != value.end(); ++member) {
      if (member.key() == key || contains_object_key(member.value(), key)) {
        return true;
      }
    }
  } else if (value.is_array()) {
    for (const nlohmann::json& element : value) {
      if (contains_object_key(element, key)) {
        return true;
      }
    }
  }
  return false;
}

}  // namespace

TEST_CASE("C30 result-v2 reader round-trips a non-null diagnostic supplement",
          "[c30][result-model][result-v2][integration]") {
  const auto document = valid_c30_result_v2_json();
  auto parsed = parse_c30_result_v2(document);
  REQUIRE(parsed);
  CHECK(parsed.value().status() == mwperf::ResultStatusV1::success);
  REQUIRE(parsed.value().observation());
  REQUIRE(parsed.value().analysis_digest());
  REQUIRE(parsed.value().analysis());
  REQUIRE(parsed.value().analysis_options());
  CHECK(parsed.value().analysis()->analysis_digest ==
        *parsed.value().analysis_digest());
  CHECK(parsed.value().analysis_options()->cutoffs ==
        std::vector<mwperf::BigNat>{mwperf::BigNat{1U}});
  REQUIRE(parsed.value().analysis()->replications.size() == 1U);
  const auto& raw = document.at("diagnostic_supplement")
                        .at("analysis")
                        .at("replications")
                        .at(0U);
  CHECK(raw.at("completeness") == "complete");
  CHECK(raw.at("inclusion") == "included_complete");
  CHECK(raw.at("measured_slot_count") == "4");
  REQUIRE(raw.at("cutoffs").size() == 1U);
  CHECK(raw.at("cutoffs").at(0U).at("cutoff") == "1");
  CHECK(parsed.value().observation()->digest().hex() ==
        document.at("diagnostic_supplement")
            .at("observation_bundle_digest")
            .get<std::string>());
  CHECK(parsed.value().canonical_bytes().size() == document.dump().size());
}

TEST_CASE("C30 result-v2 round-trips partial and zero-block replication summaries",
          "[c30][result-model][result-v2][integration]") {
  const auto document = valid_c30_result_v2_json(false, false, true);
  auto parsed = parse_c30_result_v2(document);
  REQUIRE(parsed);
  REQUIRE(parsed.value().analysis());
  const auto& replications = parsed.value().analysis()->replications;
  REQUIRE(replications.size() == 3U);

  CHECK(replications[1].completeness ==
        mwperf::ObservationCompletenessV1::partial);
  CHECK(replications[1].inclusion ==
        mwperf::CompressionReplicationInclusionV1::excluded_incomplete);
  CHECK(replications[1].measured_slot_count == mwperf::BigNat{2U});
  CHECK(replications[1].initial_first_moment.has_value());
  CHECK(replications[1].committed_first_moment.has_value());

  CHECK(replications[2].completeness ==
        mwperf::ObservationCompletenessV1::partial);
  CHECK(replications[2].inclusion ==
        mwperf::CompressionReplicationInclusionV1::excluded_incomplete);
  CHECK(replications[2].measured_slot_count == mwperf::BigNat{0U});
  CHECK_FALSE(replications[2].initial_first_moment.has_value());
  CHECK_FALSE(replications[2].committed_first_moment.has_value());
}

TEST_CASE("C30 result-v2 writer rejects an analysis option-digest mismatch",
          "[c30][result-model][result-v2][negative]") {
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      mwperf::testing::c30::validated_bundle(
          mwperf::ObservationSourceRoleV1::short_restart_reference));
  mwperf::CompressionAnalysisOptionsV1 analyzed_options;
  analyzed_options.cutoffs = {mwperf::BigNat{1U}};
  analyzed_options.run_diagnostic_fits = false;
  auto analyzed = mwperf::analyze_compression_observations_v1(
      *observation, analyzed_options);
  REQUIRE(analyzed);
  auto analysis =
      std::make_shared<const mwperf::CompressionAnalysisResultV1>(
          std::move(analyzed).value());
  mwperf::CompressionAnalysisOptionsV1 mismatched_options =
      analyzed_options;
  mismatched_options.cutoffs = {mwperf::BigNat{2U}};
  auto supplement =
      std::make_shared<const mwperf::AnalysisDiagnosticSupplementV2>(
          std::move(observation), std::move(analysis), std::nullopt,
          mwperf::AnalysisProviderSuppliedProfileV2{
              mwperf::AnalysisProviderSuppliedProfileStatusV2::
                  not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDecoderProfileV2{
              mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDiagnosticTerminalV2{
              mwperf::ResultStatusV1::success, std::nullopt,
              std::nullopt},
          std::move(mismatched_options));
  auto rejected = mwperf::make_result_artifact_v2_for_test(
      mwperf::ResultArtifactDataV2{successful_data(),
                                   std::move(supplement)});
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c30.result_v2_analysis_binding_mismatch");
}

TEST_CASE("C30 result-v2 writer verifies the complete typed analysis projection",
          "[c30][result-model][result-v2][negative]") {
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      mwperf::testing::c30::validated_bundle(
          mwperf::ObservationSourceRoleV1::short_restart_reference));
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}};
  options.run_diagnostic_fits = false;
  auto analyzed = mwperf::analyze_compression_observations_v1(
      *observation, options);
  REQUIRE(analyzed);

  const auto require_writer_rejection =
      [&](mwperf::CompressionAnalysisResultV1 mutated) {
        auto supplement = std::make_shared<
            const mwperf::AnalysisDiagnosticSupplementV2>(
            observation,
            std::make_shared<
                const mwperf::CompressionAnalysisResultV1>(
                std::move(mutated)),
            std::nullopt,
            mwperf::AnalysisProviderSuppliedProfileV2{
                mwperf::AnalysisProviderSuppliedProfileStatusV2::
                    not_applicable,
                std::nullopt, std::nullopt},
            mwperf::AnalysisDecoderProfileV2{
                mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
                std::nullopt, std::nullopt},
            mwperf::AnalysisDiagnosticTerminalV2{
                mwperf::ResultStatusV1::success, std::nullopt,
                std::nullopt},
            options);
        auto rejected = mwperf::make_result_artifact_v2_for_test(
            mwperf::ResultArtifactDataV2{successful_data(),
                                         std::move(supplement)});
        REQUIRE_FALSE(rejected);
        CHECK(rejected.error().code ==
              "c30.result_v2_analysis_verification_failed");
      };

  SECTION("raw replication numerator") {
    auto mutated = analyzed.value();
    REQUIRE_FALSE(mutated.replications.empty());
    mutated.replications.front().exposure_mass.value =
        mwperf::testing::c30::rational(5);
    require_writer_rejection(std::move(mutated));
  }

  SECTION("derived non-digest closure") {
    auto mutated = analyzed.value();
    REQUIRE(mutated.finite_window.moment_identity_closure.estimate);
    mutated.finite_window.moment_identity_closure.estimate->value =
        mwperf::testing::c30::rational(123);
    require_writer_rejection(std::move(mutated));
  }
}

TEST_CASE("C30 result-v2 reader scientifically verifies serialized analysis",
          "[c30][result-model][result-v2][negative]") {
  const auto mutate_available_quantity =
      [](nlohmann::ordered_json& quantity) {
        REQUIRE(quantity.at("estimate").is_object());
        quantity["estimate"]["value"] =
            nlohmann::ordered_json{{"exact", "123/1"},
                                   {"decimal", 123.0}};
      };
  const auto require_verification_failure = [](const auto& document) {
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.result_v2_analysis_verification_failed");
  };

  SECTION("derived tail reward mutation") {
    auto document = valid_c30_result_v2_json();
    mutate_available_quantity(
        document["diagnostic_supplement"]["analysis"]["cutoffs"][0]
                ["four_tail_rewards"]["tail_probability"]);
    require_verification_failure(document);
  }

  SECTION("derived exact gap reward mutation") {
    auto document = valid_c30_result_v2_json(true);
    mutate_available_quantity(
        document["diagnostic_supplement"]["analysis"]["competition"]
                ["cutoffs"][0]["positive_gap_tail_reward"]);
    require_verification_failure(document);
  }

  SECTION("raw replication numerator mutation") {
    auto document = valid_c30_result_v2_json();
    document["diagnostic_supplement"]["analysis"]["replications"][0]
            ["exposure_mass"]["value"] =
        nlohmann::ordered_json{{"exact", "5/1"}, {"decimal", 5.0}};
    require_verification_failure(document);
  }

  SECTION("derived closure mutation") {
    auto document = valid_c30_result_v2_json();
    mutate_available_quantity(
        document["diagnostic_supplement"]["analysis"]["finite_window"]
                ["moment_identity_closure"]);
    require_verification_failure(document);
  }

  SECTION("analysis digest mutation") {
    auto document = valid_c30_result_v2_json();
    auto& encoded = document["diagnostic_supplement"]["analysis"]
                            ["analysis_digest"];
    std::string mutated = encoded.get<std::string>();
    REQUIRE(mutated.size() == 64U);
    mutated[0] = mutated[0] == '0' ? '1' : '0';
    encoded = std::move(mutated);
    require_verification_failure(document);
  }

  SECTION("analysis cutoff option mutation") {
    auto document = valid_c30_result_v2_json();
    document["diagnostic_supplement"]["analysis_options"]["cutoffs"][0] =
        "2";
    require_verification_failure(document);
  }

  SECTION("derived effective selection seed mutation") {
    auto document = valid_c30_result_v2_json(false, true);
    auto& seed = document["diagnostic_supplement"]["analysis_options"]
                         ["effective_selection_seed"];
    REQUIRE(seed.size() == 1U);
    CHECK(seed[0]["backlog"] == "0");
    CHECK(seed[0]["selection_mass"]["exact"] == "1/1");
    seed[0]["backlog"] = "1";
    require_verification_failure(document);
  }

  SECTION("derived effective selection seed omission is not repaired") {
    auto document = valid_c30_result_v2_json(false, true);
    auto& seed = document["diagnostic_supplement"]["analysis_options"]
                         ["effective_selection_seed"];
    REQUIRE(seed.size() == 1U);
    seed = nlohmann::ordered_json::array();
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.result_v2_analysis_options_not_effective");
  }
}

TEST_CASE("C30 result-v2 preflight and rational canonicality are fail closed",
          "[c30][result-model][result-v2][negative]") {
  SECTION("duplicate decoded keys fail in SAX preflight") {
    std::string document = valid_c30_result_v2_json().dump();
    constexpr std::string_view first_member{"{\"result_version\":2"};
    REQUIRE(document.starts_with(first_member));
    document.insert(first_member.size(), ",\"result_version\":2");
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_duplicate_key");
  }

  SECTION("unreduced main-result rational is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& value = document["main_result"]["metrics"][0]["value"];
    value["exact"] = "2/2";
    value["decimal"] = 1.0;
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_rational_invalid");
  }

  SECTION("negative zero in an analysis quantity is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& value = document["diagnostic_supplement"]["analysis"]["pooled"]
                          ["observed_mean"]["estimate"]["value"];
    REQUIRE(value.is_object());
    value["exact"] = "-0/1";
    value["decimal"] = -0.0;
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_rational_invalid");
  }

  SECTION("inconsistent decimal projection is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& value = document["diagnostic_supplement"]["analysis"]["pooled"]
                          ["observed_mean"]["estimate"]["value"];
    REQUIRE(value.is_object());
    value["decimal"] = 0.125;
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_rational_invalid");
  }

  SECTION("omitted finite decimal projection is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& value = document["main_result"]["metrics"][0]["value"];
    REQUIRE(value.erase("decimal") == 1U);
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_rational_invalid");
  }

  SECTION("present-empty provider not-reached reason is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& provider = document["diagnostic_supplement"]
                             ["provider_supplied_profile"];
    provider["status"] = "not_reached";
    provider["reason_code"] = "";
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.result_v2_schema_validation_failed");
  }

  SECTION("present-empty decoder not-reached reason is rejected") {
    auto document = valid_c30_result_v2_json();
    auto& decoder =
        document["diagnostic_supplement"]["decoder_profile"];
    decoder["status"] = "not_reached";
    decoder["reason_code"] = "";
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.result_v2_schema_validation_failed");
  }

  SECTION("empty analysis cutoff set is rejected by the published schema") {
    auto document = valid_c30_result_v2_json();
    document["diagnostic_supplement"]["analysis_options"]["cutoffs"] =
        nlohmann::ordered_json::array();
    auto rejected = parse_c30_result_v2(document);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c30.result_v2_schema_validation_failed");
  }

}

TEST_CASE("C27 status reduction distinguishes established extended results",
          "[c27][unit]") {
  auto success = mwperf::make_result_artifact_for_test(successful_data());
  INFO((success ? std::string{}
                : success.error().code + ": " + success.error().message));
  REQUIRE(success);
  CHECK(success.value().status() == mwperf::ResultStatusV1::success);
  REQUIRE(success.value().value().metrics.size() == 3U);
  CHECK(std::holds_alternative<mwperf::PortableScientificScalar>(
      std::get<mwperf::EstablishedResultMetricV1>(
          success.value().value().metrics[0])
          .value));
  CHECK(std::holds_alternative<mwperf::PositiveInfinityV1>(
      std::get<mwperf::EstablishedResultMetricV1>(
          success.value().value().metrics[1])
          .value));
  const auto& law = std::get<mwperf::ResultProbabilityLawV1>(
      std::get<mwperf::EstablishedResultMetricV1>(
          success.value().value().metrics[2])
          .value);
  CHECK(law.defective_mass_proven);
  CHECK(law.defective_mass == rational(1, 2));

  auto unavailable =
      mwperf::make_result_artifact_for_test(unavailable_data());
  REQUIRE(unavailable);
  CHECK(unavailable.value().status() == mwperf::ResultStatusV1::unavailable);
  CHECK_FALSE(unavailable.value().value().failure.has_value());
  REQUIRE(unavailable.value().value().metrics.size() == 1U);
  CHECK(std::holds_alternative<mwperf::UnavailableResultMetricV1>(
      unavailable.value().value().metrics.front()));

  auto failed = mwperf::make_result_artifact_for_test(failed_data());
  REQUIRE(failed);
  CHECK(failed.value().status() == mwperf::ResultStatusV1::failed);
  REQUIRE(failed.value().value().failure.has_value());
  CHECK(failed.value().value().metrics.empty());

  auto request_failed = mwperf::make_result_artifact_for_test(
      request_construction_failed_data());
  REQUIRE(request_failed);
  REQUIRE(request_failed.value().value().failure.has_value());
  CHECK(request_failed.value().value().failure->stage ==
        mwperf::ResultFailureStageV1::request_construction);

  // A failed non-Built provider can truthfully retain validated construction
  // usage even though no artifact stream identities exist to publish.
  auto accounting_failure = mwperf::make_result_artifact_for_test(
      nonbuilt_construction_accounting_failure_data());
  REQUIRE(accounting_failure);
  REQUIRE(accounting_failure.value().value().failure.has_value());
  CHECK(accounting_failure.value().value().failure->stage ==
        mwperf::ResultFailureStageV1::build_contract_validation);
}

TEST_CASE("C27 result validation rejects status and reference corruption",
          "[c27][negative]") {
  SECTION("publication requires a configuration name") {
    auto data = successful_data();
    data.config_name.clear();
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_publication_context_invalid");
  }

  SECTION("wall-clock components must partition nonnegative end-to-end time") {
    auto negative = successful_data();
    negative.wall_clock_times.sampler = std::chrono::nanoseconds(-1);
    auto negative_artifact =
        mwperf::make_result_artifact_for_test(std::move(negative));
    REQUIRE_FALSE(negative_artifact);
    CHECK(negative_artifact.error().code == "c27.result_wall_clock_invalid");

    auto inconsistent = successful_data();
    inconsistent.wall_clock_times.framework = std::chrono::seconds(1);
    auto inconsistent_artifact =
        mwperf::make_result_artifact_for_test(std::move(inconsistent));
    REQUIRE_FALSE(inconsistent_artifact);
    CHECK(inconsistent_artifact.error().code ==
          "c27.result_wall_clock_invalid");
  }

  SECTION("all response-curve regions are probabilities") {
    auto data = successful_data();
    REQUIRE(data.response_curve.has_value());
    data.response_curve->backlog_at_least_three = rational(5, 4);
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_response_curve_invalid");
  }

  SECTION("a successful scalar-response result requires its bound curve") {
    auto absent = successful_data();
    absent.response_curve.reset();
    auto absent_artifact =
        mwperf::make_result_artifact_for_test(std::move(absent));
    REQUIRE_FALSE(absent_artifact);
    CHECK(absent_artifact.error().code ==
          "c27.result_response_curve_missing");

    auto foreign = successful_data();
    REQUIRE(foreign.response_curve.has_value());
    foreign.response_curve->target = queue("q1");
    auto foreign_artifact =
        mwperf::make_result_artifact_for_test(std::move(foreign));
    REQUIRE_FALSE(foreign_artifact);
    CHECK(foreign_artifact.error().code ==
          "c27.result_response_curve_binding_invalid");
  }

  SECTION("success cannot contain an unavailable metric") {
    auto data = successful_data();
    data.metrics[0] = mwperf::UnavailableResultMetricV1{
        .header = metric_header(
            "exact", mwperf::MetricKindV1::stationary_backlog_moment),
        .reason_code = "not_established",
        .diagnostic_refs = {"diag.projection"},
    };
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
  }

  SECTION("unavailable cannot carry a failure object") {
    auto data = unavailable_data();
    data.failure = mwperf::ResultFailureV1{
        .stage = mwperf::ResultFailureStageV1::backend,
        .code = "wrong_branch",
        .diagnostic_refs = {"diag.unavailable"},
    };
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
  }

  SECTION("K-wide unavailable diagnostics preserve coordinate and slack identities") {
    auto coordinate = k_wide_unavailable_data(true);
    REQUIRE(coordinate.unavailable_diagnostics.has_value());
    coordinate.unavailable_diagnostics->coefficient_diagnostics.back()
        .level_or_tail_from = mwperf::BigNat{2U};
    auto coordinate_artifact =
        mwperf::make_result_artifact_for_test(std::move(coordinate));
    REQUIRE_FALSE(coordinate_artifact);
    CHECK(coordinate_artifact.error().code ==
          "c27.result_unavailable_diagnostics_invalid");

    auto slack = k_wide_unavailable_data(true);
    REQUIRE(slack.unavailable_diagnostics.has_value());
    REQUIRE(slack.unavailable_diagnostics->c19.has_value());
    slack.unavailable_diagnostics->c19->tail_slack = rational(0);
    auto slack_artifact =
        mwperf::make_result_artifact_for_test(std::move(slack));
    REQUIRE_FALSE(slack_artifact);
    CHECK(slack_artifact.error().code ==
          "c27.result_unavailable_diagnostics_invalid");
  }

  SECTION("failed cannot leak a partial metric") {
    auto data = failed_data();
    data.metrics.emplace_back(mwperf::EstablishedResultMetricV1{
        .header = metric_header(
            "mean-backlog", mwperf::MetricKindV1::stationary_backlog_moment),
        .value = rational(1),
    });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
  }

  SECTION("failure references must resolve") {
    auto data = failed_data();
    data.failure->diagnostic_refs = {"diag.missing"};
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
  }

  SECTION("the model fingerprint is copied rather than relabelled") {
    auto data = successful_data();
    data.model.fingerprint = digest("foreign-model");
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
  }

  SECTION("construction replay identity is stage and typed instance") {
    auto data = successful_data();
    data.execution.replay_streams.push_back(
        mwperf::ResultConstructionReplayStreamV1{
            .stage_tag = mwperf::StageTag::surrogate_build_probe,
            .stream_instance_id = text_label("proposal-probe-4"),
            .draws = mwperf::BigNat{99U},
        });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code == "c27.result_replay_invalid");
  }

  SECTION("runtime replay identity is stage and derived digest") {
    auto data = successful_data();
    data.execution.replay_streams.push_back(
        mwperf::ResultRuntimeReplayStreamV1{
            .stage_tag = mwperf::StageTag::solver_sampling,
            .stream_identity = digest("solver-stream"),
            .draws = mwperf::BigNat{99U},
        });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code == "c27.result_replay_invalid");
  }

  SECTION("construction records reject runtime stages") {
    auto data = successful_data();
    data.execution.replay_streams[0] =
        mwperf::ResultConstructionReplayStreamV1{
            .stage_tag = mwperf::StageTag::solver_sampling,
            .stream_instance_id = text_label("proposal-probe-4"),
            .draws = mwperf::BigNat{11U},
        };
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code == "c27.result_replay_invalid");
  }

  SECTION("runtime records reject construction stages") {
    auto data = successful_data();
    data.execution.replay_streams[1] =
        mwperf::ResultRuntimeReplayStreamV1{
            .stage_tag = mwperf::StageTag::surrogate_build_probe,
            .stream_identity = digest("solver-stream"),
            .draws = mwperf::BigNat{7U},
        };
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code == "c27.result_replay_invalid");
  }

  SECTION("construction replay requires a Built payload") {
    auto data = unavailable_data();
    data.execution.replay_streams.push_back(
        mwperf::ResultConstructionReplayStreamV1{
            .stage_tag = mwperf::StageTag::surrogate_build_probe,
            .stream_instance_id = text_label("orphan-construction-stream"),
            .draws = mwperf::BigNat{0U},
        });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_replay_provenance_invalid");
  }

  SECTION("construction replay requires its configured draw row") {
    auto data = successful_data();
    data.execution.budget_usage.clear();
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_construction_replay_budget_missing");
  }

  SECTION("construction replay counts equal configured draw usage") {
    auto data = successful_data();
    data.execution.budget_usage.front().used = mwperf::BigNat{10U};
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_construction_replay_count_mismatch");
  }

  SECTION("Built payload cannot omit consumed construction streams") {
    auto data = successful_data();
    data.execution.replay_streams.erase(
        data.execution.replay_streams.begin());
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_construction_replay_count_mismatch");
  }

  SECTION("runtime replay requires an audited execution seal") {
    auto data = unavailable_data();
    data.execution.replay_streams.push_back(
        mwperf::ResultRuntimeReplayStreamV1{
            .stage_tag = mwperf::StageTag::generic_sampling,
            .stream_identity = digest("orphan-runtime-stream"),
            .draws = mwperf::BigNat{1U},
        });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_replay_provenance_invalid");
  }

  SECTION("backend budget usage requires an audited execution seal") {
    auto data = unavailable_data();
    data.budgets_used.push_back(mwperf::ResultBudgetUsageV1{
        .name = "backend.fixture.stopped_iterations",
        .applicability =
            mwperf::ResultBudgetApplicabilityV1::applicable,
        .granted = mwperf::BigNat{1U},
        .used = mwperf::BigNat{0U},
        .unit = "iterations",
    });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_replay_provenance_invalid");
  }

  SECTION("request-construction failure rejects later provenance") {
    auto data = failed_data();
    data.failure->stage =
        mwperf::ResultFailureStageV1::request_construction;
    data.failure->code = "request_fixture_failure";
    data.diagnostics.front().code = "request_fixture_failure";
    data.execution.build_request_identity = std::nullopt;
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_request_construction_provenance_invalid");
  }

  SECTION("a pre-Built failure cannot retain a payload or seal") {
    auto data = failed_data();
    data.failure->stage = mwperf::ResultFailureStageV1::wire_parse;
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_failure_stage_provenance_invalid");
  }

  SECTION("a V0 failure cannot retain the execution seal") {
    auto data = failed_data();
    data.failure->stage = mwperf::ResultFailureStageV1::v0_audit;
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_failure_stage_provenance_invalid");
  }

  SECTION("a V0 failure cannot retain certificates") {
    auto data = failed_data();
    data.failure->stage = mwperf::ResultFailureStageV1::v0_audit;
    data.execution.execution_seal_digest = std::nullopt;
    data.execution.replay_streams.erase(
        data.execution.replay_streams.begin() + 1);
    data.certificates.push_back(
        v0_certificate("c25.fixture.validation", "diag.failure"));
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_failure_stage_provenance_invalid");
  }

  SECTION("an assembly failure is never an inner result stage") {
    auto data = failed_data();
    data.failure->stage =
        mwperf::ResultFailureStageV1::result_assembly;
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_assembly_stage_not_publishable");
  }

  SECTION("post-V0 failures retain only certificates already validated") {
    auto initial = failed_data();
    initial.failure->stage = mwperf::ResultFailureStageV1::initial_law;
    initial.certificates.push_back(
        v0_certificate("c25.fixture.validation", "diag.failure"));
    auto initial_artifact =
        mwperf::make_result_artifact_for_test(std::move(initial));
    REQUIRE(initial_artifact);

    auto certificate = failed_data();
    certificate.failure->stage =
        mwperf::ResultFailureStageV1::certificate;
    auto certificate_artifact =
        mwperf::make_result_artifact_for_test(std::move(certificate));
    REQUIRE(certificate_artifact);
  }

  SECTION("recursive optimizer ledger requires the shared call ledger") {
    auto data = successful_data();
    data.execution.budget_usage.push_back(mwperf::ResultBudgetUsageV1{
        .name = "execution.shared_optimizer_search_states",
        .applicability =
            mwperf::ResultBudgetApplicabilityV1::applicable,
        .granted = mwperf::BigNat{4U},
        .used = mwperf::BigNat{1U},
        .unit = "states",
    });
    auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
    REQUIRE_FALSE(artifact);
    CHECK(artifact.error().code ==
          "c27.result_optimizer_accounting_invalid");
  }
}

TEST_CASE("C27 canonical result JSON contains only compact scientific output",
          "[c27][property]") {
  auto data = successful_data();
  REQUIRE(data.diagnostics.front().product.has_value());
  data.diagnostics.front().product->artifact_identity = std::nullopt;
  auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
  REQUIRE(artifact);
  const std::filesystem::path first = result_directory() / "canonical-a.json";
  const std::filesystem::path second = result_directory() / "canonical-b.json";
  REQUIRE(mwperf::write_result_artifact(artifact.value(), first));
  REQUIRE(mwperf::write_result_artifact(artifact.value(), second));
  const std::string first_bytes = read_bytes(first);
  CHECK(first_bytes == read_bytes(second));

  const nlohmann::json document = nlohmann::json::parse(first_bytes);
  REQUIRE(document.size() == 4U);
  CHECK(document.at("config") == "fixture.json");
  CHECK(document.contains("response_curve"));
  CHECK(document.contains("metrics"));
  CHECK(document.contains("wall_clock_seconds"));
  CHECK_FALSE(document.contains("resources"));
  const std::size_t config_position = first_bytes.find("\"config\"");
  const std::size_t response_position =
      first_bytes.find("\"response_curve\"");
  const std::size_t metrics_position = first_bytes.find("\"metrics\"");
  const std::size_t wall_clock_position =
      first_bytes.find("\"wall_clock_seconds\"");
  REQUIRE(config_position != std::string::npos);
  REQUIRE(response_position != std::string::npos);
  REQUIRE(metrics_position != std::string::npos);
  REQUIRE(wall_clock_position != std::string::npos);
  CHECK(config_position < response_position);
  CHECK(response_position < metrics_position);
  CHECK(metrics_position < wall_clock_position);

  const auto& curve = document.at("response_curve");
  CHECK(curve.at("target") == "q0");
  REQUIRE(curve.at("regions").size() == 4U);
  const std::array<std::string_view, 4U> backlogs{"0", "1", "2", ">=3"};
  const std::array<std::string_view, 4U> probabilities{
      "0/1", "1/2", "3/4", "7/8"};
  for (std::size_t index = 0U; index < backlogs.size(); ++index) {
    CHECK(curve.at("regions").at(index).at("backlog") ==
          std::string(backlogs[index]));
    CHECK(curve.at("regions")
              .at(index)
              .at("service_probability")
              .at("exact") == std::string(probabilities[index]));
    CHECK(curve.at("regions")
              .at(index)
              .at("service_probability")
              .at("decimal")
              .is_number());
  }

  REQUIRE(document.at("metrics").size() == 3U);
  const auto& exact = document.at("metrics").at(0);
  CHECK(exact.size() == 5U);
  CHECK(exact.at("id") == "exact");
  CHECK(exact.at("target") == "q0");
  CHECK(exact.at("value").at("exact") == "3/4");
  CHECK(exact.at("value").at("decimal").is_number());
  CHECK(document.at("metrics").at(1).at("value") ==
        "positive_infinity");
  const auto& probabilities_value =
      document.at("metrics").at(2).at("value");
  REQUIRE(probabilities_value.at("coordinates").size() == 1U);
  CHECK(probabilities_value.at("coordinates").at(0) == "hitting_time");
  REQUIRE(probabilities_value.at("probabilities").size() == 2U);
  CHECK(probabilities_value.at("probabilities").at(0).at("outcome") == "1");
  CHECK(probabilities_value.at("probabilities")
            .at(0)
            .at("probability")
            .at("exact") == "1/4");
  CHECK(probabilities_value.at("probabilities")
            .at(1)
            .at("outcome")
            .at("integer") == "1");
  CHECK(probabilities_value.at("probabilities")
            .at(1)
            .at("probability")
            .at("exact") == "1/4");
  CHECK(probabilities_value.at("defective_mass").at("exact") == "1/2");

  const auto& wall_clock = document.at("wall_clock_seconds");
  CHECK(wall_clock.at("end_to_end") == 3.0);
  CHECK(wall_clock.at("sampler") == 1.0);
  CHECK(wall_clock.at("framework") == 2.0);

  for (const std::string_view forbidden :
       {"diagnostics", "certificates", "assumptions", "scientific_scope",
        "evidence_refs", "law_identity", "execution", "surrogate", "status",
        "unavailable", "failure", "build", "model", "analysis",
        "result_schema_version", "provenance", "convention"}) {
    CAPTURE(forbidden);
    CHECK_FALSE(contains_object_key(document, forbidden));
  }
}

TEST_CASE("C27 result schema and publication boundary are closed",
          "[c27][integration]") {
  const nlohmann::json schema =
      nlohmann::json::parse(read_bytes(MWPERF_C27_RESULT_SCHEMA_PATH));
  REQUIRE(schema.at("oneOf").is_array());
  CHECK(schema.at("oneOf").size() == 2U);
  const auto& definitions = schema.at("$defs");
  for (const std::string_view name :
       {"scalar", "probabilityScalar", "probabilityLaw", "table", "metric", "responseCurve",
        "wallClock", "resources", "success", "unavailableCause",
        "kBinCoordinate", "constructionInterval",
        "kBinCoefficientDiagnostic", "constantTailDiagnostic",
        "c19UnavailableDiagnostics", "unavailableDiagnostics", "error",
        "errorResult"}) {
    INFO("closed compact result definition: " << name);
    REQUIRE(definitions.contains(name));
    CHECK(definitions.at(name).at("additionalProperties") == false);
  }
  CHECK_FALSE(definitions.contains("diagnostic"));
  CHECK_FALSE(definitions.contains("certificate"));
  CHECK_FALSE(definitions.contains("execution"));
  CHECK_FALSE(definitions.contains("surrogate"));
  CHECK_FALSE(definitions.contains("canonicalValue"));

  auto artifact = mwperf::make_result_artifact_for_test(successful_data());
  REQUIRE(artifact);
  constexpr std::string_view sentinel = "previous-result-is-immutable";
  const std::array failure_points{
      mwperf::ResultPublicationFailurePointV1::open,
      mwperf::ResultPublicationFailurePointV1::write,
      mwperf::ResultPublicationFailurePointV1::flush,
      mwperf::ResultPublicationFailurePointV1::close,
      mwperf::ResultPublicationFailurePointV1::rename,
  };
  for (std::size_t index = 0U; index < failure_points.size(); ++index) {
    const std::filesystem::path path =
        result_directory() / ("publication-" + std::to_string(index) +
                              ".json");
    write_bytes(path, sentinel);
    auto published = mwperf::write_result_artifact_with_failure_for_test(
        artifact.value(), path, failure_points[index]);
    REQUIRE_FALSE(published);
    CHECK(published.error().code == "output_publication_failed");
    CHECK(read_bytes(path) == sentinel);
  }
}

TEST_CASE("C27 K-wide unavailable diagnostics are explicit and opt-in",
          "[c27][integration]") {
  auto compact = mwperf::make_result_artifact_for_test(
      k_wide_unavailable_data(false));
  REQUIRE(compact);
  const std::filesystem::path compact_path =
      result_directory() / "k-wide-unavailable-compact.json";
  REQUIRE(mwperf::write_result_artifact(compact.value(), compact_path));
  const nlohmann::json compact_document =
      nlohmann::json::parse(read_bytes(compact_path));
  REQUIRE(compact_document.at("error").size() == 3U);
  CHECK(compact_document.at("error").at("code") ==
        "c27.k_bin_metric_not_established");
  CHECK(compact_document.at("error").at("response_cutoff") == "2");
  CHECK_FALSE(compact_document.at("error").contains(
      "unavailable_diagnostics"));

  auto detailed = mwperf::make_result_artifact_for_test(
      k_wide_unavailable_data(true));
  REQUIRE(detailed);
  const std::filesystem::path detailed_path =
      result_directory() / "k-wide-unavailable-detailed.json";
  REQUIRE(mwperf::write_result_artifact(detailed.value(), detailed_path));
  const nlohmann::json document =
      nlohmann::json::parse(read_bytes(detailed_path));
  const auto& diagnostics =
      document.at("error").at("unavailable_diagnostics");
  REQUIRE(diagnostics.at("reasons").size() == 1U);
  CHECK(diagnostics.at("reasons").at(0).at("metric_id") ==
        "mean-backlog");
  REQUIRE(diagnostics.at("coefficient_diagnostics").size() == 4U);
  CHECK(diagnostics.at("coefficient_diagnostics")
            .at(3)
            .at("coordinate")
            .at("kind") == "constant_tail");
  CHECK(diagnostics.at("coefficient_diagnostics")
            .at(1)
            .at("pooled_unserved_mass")
            .at("exact") == "1/8");
  CHECK(diagnostics.at("coefficient_diagnostics")
            .at(1)
            .at("pooled_served_mass")
            .at("exact") == "1/16");
  const auto& c19 = diagnostics.at("c19");
  CHECK(c19.at("analytic_status") == "outside_strict_tail_profile");
  CHECK(c19.at("arrival_mean").at("exact") == "1/2");
  CHECK(c19.at("constant_tail").at("service_probability").at("exact") ==
        "1/4");
  CHECK(c19.at("tail_slack").at("exact") == "-1/4");
  REQUIRE(mwperf::validate_result_v1_json_schema_for_test(document.dump()));
  nlohmann::json detached = document;
  detached.at("error").erase("response_cutoff");
  REQUIRE_FALSE(
      mwperf::validate_result_v1_json_schema_for_test(detached.dump()));

  auto success_data = successful_data();
  success_data.report_unavailable_diagnostics = true;
  auto success =
      mwperf::make_result_artifact_for_test(std::move(success_data));
  REQUIRE(success);
  const std::filesystem::path success_path =
      result_directory() / "diagnostics-flag-success.json";
  REQUIRE(mwperf::write_result_artifact(success.value(), success_path));
  CHECK_FALSE(contains_object_key(
      nlohmann::json::parse(read_bytes(success_path)),
      "unavailable_diagnostics"));

  auto failure_data = failed_data();
  failure_data.report_unavailable_diagnostics = true;
  auto failure =
      mwperf::make_result_artifact_for_test(std::move(failure_data));
  REQUIRE(failure);
  const std::filesystem::path failure_path =
      result_directory() / "diagnostics-flag-failed.json";
  REQUIRE(mwperf::write_result_artifact(failure.value(), failure_path));
  CHECK_FALSE(contains_object_key(
      nlohmann::json::parse(read_bytes(failure_path)),
      "unavailable_diagnostics"));
}

TEST_CASE("C27 every transactional status self-validates before publication",
          "[c27][integration]") {
  struct StatusFixture final {
    std::string_view name;
    mwperf::ResultArtifactDataV1 data;
  };
  std::array fixtures{
      StatusFixture{"success", successful_data()},
      StatusFixture{"unavailable", unavailable_data()},
      StatusFixture{"failed", failed_data()},
  };

  for (StatusFixture& fixture : fixtures) {
    DYNAMIC_SECTION(fixture.name) {
      auto artifact =
          mwperf::make_result_artifact_for_test(std::move(fixture.data));
      REQUIRE(artifact);
      const std::filesystem::path path =
          result_directory() /
          ("self-validated-" + std::string(fixture.name) + ".json");
      auto published = mwperf::write_result_artifact(artifact.value(), path);
      INFO((published ? std::string{}
                      : published.error().code + ": " +
                            published.error().message));
      REQUIRE(published);
      const nlohmann::json document =
          nlohmann::json::parse(read_bytes(path));
      CHECK(document.at("config") == "fixture.json");
      CHECK(document.contains("wall_clock_seconds"));
      if (fixture.name == "success") {
        CHECK(document.contains("response_curve"));
        CHECK(document.contains("metrics"));
        CHECK_FALSE(document.contains("error"));
      } else {
        CHECK(document.contains("error"));
        CHECK_FALSE(document.contains("response_curve"));
        CHECK_FALSE(document.contains("metrics"));
      }
    }
  }
}

TEST_CASE("C27 dynamic response keeps the public compatibility curve null",
          "[c27][integration]") {
  auto data = successful_data();
  data.surrogate.plug_kind =
      "finite_prefix_constant_tail_response_v1";
  data.response_curve.reset();
  auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
  INFO((artifact ? std::string{}
                 : artifact.error().code + ": " +
                       artifact.error().message));
  REQUIRE(artifact);

  const std::filesystem::path path =
      result_directory() / "dynamic-response-null-curve.json";
  REQUIRE(mwperf::write_result_artifact(artifact.value(), path));
  const nlohmann::json document =
      nlohmann::json::parse(read_bytes(path));
  REQUIRE(document.contains("response_curve"));
  CHECK(document.at("response_curve").is_null());
}

TEST_CASE("C27 resource telemetry is opt-in and deliberately narrow",
          "[c27][integration]") {
  auto data = successful_data();
  data.output_resources = true;
  data.optimizer_calls_observed = mwperf::BigNat{13U};
  data.optimizer_search_states_observed = mwperf::BigNat{37U};
  auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
  REQUIRE(artifact);
  const std::filesystem::path path =
      result_directory() / "resources-opt-in.json";
  REQUIRE(mwperf::write_result_artifact(artifact.value(), path));
  const nlohmann::json document =
      nlohmann::json::parse(read_bytes(path));

  REQUIRE(document.contains("resources"));
  const auto& resources = document.at("resources");
  REQUIRE(resources.size() == 4U);
  CHECK(resources.at("workers") == 2U);
  CHECK(resources.at("optimizer_calls") == "13");
  CHECK(resources.at("configured_generator_draws") == "11");
  CHECK(resources.at("optimizer_search_states") == "37");
  CHECK_FALSE(resources.contains("build_identity"));
  CHECK_FALSE(resources.contains("replay_streams"));
  CHECK_FALSE(resources.contains("budgets"));
}

TEST_CASE("C27 normal output rejects opaque metric byte carriers",
          "[c27][negative]") {
  auto data = successful_data();
  data.metrics[0] = mwperf::EstablishedResultMetricV1{
      .header = metric_header(
          "exact", mwperf::MetricKindV1::stationary_backlog_moment),
      .value = mwperf::ResultCanonicalValueV1{
          .codec = mwperf::CodecIdentityV1{"internal.metric", 1U},
          .canonical_value = {std::byte{0x42}},
      },
  };
  auto artifact = mwperf::make_result_artifact_for_test(std::move(data));
  REQUIRE(artifact);

  const std::filesystem::path path =
      result_directory() / "opaque-metric-rejected.json";
  constexpr std::string_view sentinel = "preserve-existing-output";
  write_bytes(path, sentinel);
  auto published = mwperf::write_result_artifact(artifact.value(), path);
  REQUIRE_FALSE(published);
  CHECK(published.error().code == "output_publication_failed");
  CHECK(read_bytes(path) == sentinel);
}

TEST_CASE("C27 compact schema rejects non-scientific output fields",
          "[c27][negative]") {
  auto artifact = mwperf::make_result_artifact_for_test(successful_data());
  REQUIRE(artifact);
  const std::filesystem::path path =
      result_directory() / "schema-negative-source.json";
  REQUIRE(mwperf::write_result_artifact(artifact.value(), path));
  const nlohmann::json valid =
      nlohmann::json::parse(read_bytes(path));
  REQUIRE(mwperf::validate_result_v1_json_schema_for_test(valid.dump()));

  SECTION("compact success rejects internal reporting fields") {
    for (const std::string_view internal_field :
         {"diagnostics", "certificates", "assumptions", "execution",
          "surrogate", "provenance"}) {
      CAPTURE(internal_field);
      nlohmann::json mutated = valid;
      mutated[std::string(internal_field)] = nlohmann::json::object();
      auto checked =
          mwperf::validate_result_v1_json_schema_for_test(mutated.dump());
      REQUIRE_FALSE(checked);
      CHECK(checked.error().code ==
            "c27.result_schema_self_validation_failed");
    }
  }

  SECTION("compact metrics reject undeclared members") {
    nlohmann::json mutated = valid;
    mutated.at("metrics").at(0)["assumptions"] =
        nlohmann::json::array({"must never be published"});
    auto checked =
        mwperf::validate_result_v1_json_schema_for_test(mutated.dump());
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code ==
          "c27.result_schema_self_validation_failed");
  }

  SECTION("compact success requires all four ordered response regions") {
    nlohmann::json missing = valid;
    missing.at("response_curve").at("regions").erase(
        missing.at("response_curve").at("regions").begin() + 3);
    auto missing_checked =
        mwperf::validate_result_v1_json_schema_for_test(missing.dump());
    REQUIRE_FALSE(missing_checked);

    nlohmann::json mislabeled = valid;
    mislabeled.at("response_curve").at("regions").at(3)["backlog"] = "3";
    auto mislabeled_checked =
        mwperf::validate_result_v1_json_schema_for_test(mislabeled.dump());
    REQUIRE_FALSE(mislabeled_checked);
  }

  SECTION("compact decimal renderings cannot be strings") {
    nlohmann::json exact_only = valid;
    exact_only.at("metrics").at(0).at("value").erase("decimal");
    REQUIRE(mwperf::validate_result_v1_json_schema_for_test(
        exact_only.dump()));

    nlohmann::json mutated = valid;
    mutated.at("metrics").at(0).at("value")["decimal"] = "0.75";
    auto checked =
        mwperf::validate_result_v1_json_schema_for_test(mutated.dump());
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code ==
          "c27.result_schema_self_validation_failed");

    nlohmann::json invalid_probability = valid;
    invalid_probability.at("response_curve")
        .at("regions")
        .at(0)
        .at("service_probability")["decimal"] = 1.25;
    REQUIRE_FALSE(mwperf::validate_result_v1_json_schema_for_test(
        invalid_probability.dump()));
  }

  SECTION("wall-clock values are mandatory and nonnegative") {
    nlohmann::json absent = valid;
    absent.erase("wall_clock_seconds");
    REQUIRE_FALSE(
        mwperf::validate_result_v1_json_schema_for_test(absent.dump()));

    nlohmann::json negative = valid;
    negative.at("wall_clock_seconds")["sampler"] = -1.0;
    REQUIRE_FALSE(
        mwperf::validate_result_v1_json_schema_for_test(negative.dump()));
  }

  SECTION("selected resource telemetry is optional and closed") {
    nlohmann::json with_resources = valid;
    with_resources["resources"] =
        nlohmann::json{{"workers", 2},
                       {"optimizer_calls", "7"},
                       {"configured_generator_draws", "11"},
                       {"optimizer_search_states", "37"}};
    REQUIRE(mwperf::validate_result_v1_json_schema_for_test(
        with_resources.dump()));

    with_resources.at("resources")["build_digest"] = "not-scientific";
    REQUIRE_FALSE(mwperf::validate_result_v1_json_schema_for_test(
        with_resources.dump()));
  }

  SECTION("compact errors cannot carry partial metrics or internals") {
    auto failed_artifact =
        mwperf::make_result_artifact_for_test(failed_data());
    REQUIRE(failed_artifact);
    const std::filesystem::path failed_path =
        result_directory() / "schema-negative-error-source.json";
    REQUIRE(mwperf::write_result_artifact(failed_artifact.value(),
                                          failed_path));
    nlohmann::json error = nlohmann::json::parse(read_bytes(failed_path));
    REQUIRE(mwperf::validate_result_v1_json_schema_for_test(error.dump()));
    error["metrics"] = nlohmann::json::array();
    REQUIRE_FALSE(
        mwperf::validate_result_v1_json_schema_for_test(error.dump()));
  }

}
