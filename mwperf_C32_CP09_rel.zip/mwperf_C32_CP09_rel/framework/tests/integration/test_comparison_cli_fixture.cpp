#include <chrono>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/app/result_artifact.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

void write_observation(
    const std::filesystem::path& path,
    const mwperf::ObservationSourceRoleV1 role) {
  const auto envelope = mwperf::testing::c30::envelope_for(
      mwperf::testing::c30::exact_bundle(role));
  auto encoded =
      mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
  REQUIRE(encoded);
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(reinterpret_cast<const char*>(encoded.value().data()),
               static_cast<std::streamsize>(encoded.value().size()));
  REQUIRE(output.good());
}

void write_result_v3(const std::filesystem::path& path) {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(
          mwperf::testing::c30::exact_bundle(
              mwperf::ObservationSourceRoleV1::weighted_ensemble)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      std::move(validated).value());

  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{0U}};
  options.run_diagnostic_fits = false;
  options.compute_delete_one_replication_jackknife = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  auto analyzed =
      mwperf::analyze_compression_observations_v1(*observation, options);
  REQUIRE(analyzed);
  auto analysis =
      std::make_shared<const mwperf::CompressionAnalysisResultV1>(
          std::move(analyzed).value());

  const mwperf::Digest256 provider_result_digest =
      mwperf::testing::c30::digest('5');
  auto supplement =
      std::make_shared<const mwperf::AnalysisDiagnosticSupplementV2>(
          observation, analysis, std::nullopt,
          mwperf::AnalysisProviderSuppliedProfileV2{
              mwperf::AnalysisProviderSuppliedProfileStatusV2::not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDecoderProfileV2{
              mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
              std::nullopt, std::nullopt},
          mwperf::AnalysisDiagnosticTerminalV2{
              mwperf::ResultStatusV1::success, std::nullopt, std::nullopt},
          options, provider_result_digest);
  auto framework_prediction =
      std::make_shared<const mwperf::FrameworkEmpiricalPredictionV1>(
          mwperf::derive_framework_empirical_prediction_v1(
              *observation, *analysis, options));

  const mwperf::Digest256 model = mwperf::testing::c30::digest('1');
  const mwperf::Digest256 analysis_input =
      mwperf::testing::c30::digest('2');
  const mwperf::BuildIdentityDigest build_identity(
      mwperf::testing::c30::digest('6'));
  const mwperf::MasterSeed master_seed{9U};
  const mwperf::BuildSeed build_seed(master_seed, build_identity);
  auto artifact = mwperf::make_result_artifact_v3_for_test(
      mwperf::ResultArtifactDataV3{
          .status = mwperf::ResultStatusV1::success,
          .failure = std::nullopt,
          .input_fingerprints =
              mwperf::InputFingerprintBundle{
                  model, analysis_input, mwperf::testing::c30::digest('3')},
          .provider =
              mwperf::ProviderIdentityV1{
                  "full_orbit_framework_sampler", "1.4.0"},
          .provider_digest = mwperf::ProviderScientificContractDigest(
              mwperf::testing::c30::digest('4')),
          .provider_result_digest = provider_result_digest,
          .master_seed = master_seed,
          .build_request_identity =
              mwperf::ResultBuildRequestIdentityV1{
                  build_identity, build_seed,
                  mwperf::SurrogateBuildRequestDigest(
                      mwperf::testing::c30::digest('7'))},
          .model = mwperf::ResultModelProvenanceV1{"4", model},
          .analysis =
              mwperf::ResultAnalysisProvenanceV1{
                  "1", analysis_input, {}, {},
                  mwperf::PortableTransientSelectionV1{},
                  mwperf::MetricSolverRegimeV1::monte_carlo},
          .config_name = "c32-comparison-fixture",
          .wall_clock_times =
              mwperf::ResultWallClockTimesV1{
                  std::chrono::nanoseconds::zero(),
                  std::chrono::nanoseconds::zero(),
                  std::chrono::nanoseconds::zero()},
          .worker_count = 1U,
          .diagnostic_supplement = std::move(supplement),
          .framework_prediction = std::move(framework_prediction),
      });
  REQUIRE(artifact);
  auto encoded =
      mwperf::canonical_result_artifact_v3_json_for_test(artifact.value());
  REQUIRE(encoded);
  auto parsed = mwperf::parse_result_artifact_v3(
      std::as_bytes(
          std::span(encoded.value().data(), encoded.value().size())),
      mwperf::default_result_artifact_parse_limits_v2());
  REQUIRE(parsed);
  REQUIRE(parsed.value().observation());
  REQUIRE(parsed.value().analysis());
  REQUIRE(parsed.value().analysis_options());
  REQUIRE(parsed.value().framework_prediction());
  CHECK(parsed.value().analysis()->analysis_digest ==
        analysis->analysis_digest);
  CHECK(parsed.value().framework_prediction()->analysis_digest ==
        analysis->analysis_digest);
  CHECK(parsed.value().framework_prediction()->observation_digest ==
        observation->digest());
  CHECK(parsed.value().framework_prediction()->target_id ==
        observation->value().bindings.target.target_id);
  REQUIRE(parsed.value().provider_result_digest());
  CHECK(*parsed.value().provider_result_digest() == provider_result_digest);

  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(encoded.value().data(),
               static_cast<std::streamsize>(encoded.value().size()));
  REQUIRE(output.good());
}

}  // namespace

TEST_CASE("C30 comparison CLI fixture publishes three ordinary records",
          "[c30][cli-fixture]") {
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c30-comparison-cli";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  write_observation(
      directory / "stationary.json",
      mwperf::ObservationSourceRoleV1::long_stationary_reference);
  write_observation(
      directory / "finite.json",
      mwperf::ObservationSourceRoleV1::short_restart_reference);
  write_observation(directory / "ensemble.json",
                    mwperf::ObservationSourceRoleV1::weighted_ensemble);
  write_result_v3(directory / "ensemble-v3.json");
  std::filesystem::remove(directory / "comparison.json", error);
  CHECK_FALSE(error);
  std::filesystem::remove(directory / "comparison-v3.json", error);
  CHECK_FALSE(error);
}
