#include <algorithm>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/direct_v0_fixture.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/stationary/flux.hpp"

namespace {

namespace c17 = mwperf::testing::c17;
namespace direct = mwperf::testing::c17_direct;
namespace designated = mwperf::testing::c16_designated_detail;

[[nodiscard]] designated::InputV1 c18_enumerated_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":18,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.pair.direct-metric",
                 "version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":16,"max_search_states_per_call":16},
      "sampling":{"max_generator_draws":16},
      "tolerance":{"linear_residual_abs":1e-12,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  auto model_document =
      mwperf::load_document(designated::write_input("c18-model", model));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = mwperf::load_document(
      designated::write_input("c18-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = mwperf::resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      mwperf::fingerprint_inputs(canonical));
  REQUIRE(instance);
  auto arrival = mwperf::detail::CompiledArrivalAccess::get(
      instance.value().arrival());
  REQUIRE(arrival);
  auto request = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  auto requirements = mwperf::requirements_for_metric(request.value());
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] direct::FactorFrameworkV1 c18_framework() {
  auto input = c18_enumerated_input();
  REQUIRE(mwperf::metric_request_header(input.request).solver_regime ==
          mwperf::MetricSolverRegimeV1::enumerated);
  auto scenario = direct::scenario(
      direct::profile(mwperf::SemanticTagV1::stationary_marked_edge), input,
      mwperf::BackendRouteKindV1::stationary_edge_reward,
      mwperf::SolverRegimeV1::enumerated);
  return direct::make_factor_framework(scenario);
}

[[nodiscard]] mwperf::Digest256 digest(const std::string_view text) {
  auto result = mwperf::sha256(std::as_bytes(
      std::span<const char>(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::BoundaryRule exact_closed_boundary() {
  return {mwperf::BoundaryCompletionKindV1::exact_closed, std::nullopt, true,
          {}};
}

[[nodiscard]] mwperf::BoundaryRule marked_self_completion(
    const mwperf::ReducedStateV1& retained_state,
    const mwperf::Digest256& identity) {
  return {
      mwperf::BoundaryCompletionKindV1::marked_completion,
      identity,
      false,
      [retained_state](const mwperf::MarkedFluxAtomV1& leaking) {
        mwperf::MarkedFluxEdgeV1 transformed = leaking.edge;
        transformed.successor_state = retained_state;
        transformed.phase_after = transformed.phase_before;
        for (std::size_t target = 0U;
             target < transformed.target_departures.size(); ++target) {
          transformed.target_arrivals[target] = mwperf::BigNat{
              transformed.target_departures[target]};
        }
        return mwperf::Result<
            std::vector<mwperf::BoundaryCompletionAtomV1>>::success(
            {{retained_state, mwperf::ExactRational::one(),
              std::move(transformed)}});
      }};
}

[[nodiscard]] mwperf::BoundaryRule marked_recurrence_mismatch_completion(
    const mwperf::ReducedStateV1& retained_state,
    const mwperf::Digest256& identity) {
  return {
      mwperf::BoundaryCompletionKindV1::marked_completion,
      identity,
      false,
      [retained_state](const mwperf::MarkedFluxAtomV1& leaking) {
        mwperf::MarkedFluxEdgeV1 transformed = leaking.edge;
        transformed.successor_state = retained_state;
        transformed.phase_after = transformed.phase_before;
        return mwperf::Result<
            std::vector<mwperf::BoundaryCompletionAtomV1>>::success(
            {{retained_state, mwperf::ExactRational::one(),
              std::move(transformed)}});
      }};
}

[[nodiscard]] mwperf::BoundaryRule state_only_self_completion(
    const mwperf::ReducedStateV1& retained_state,
    const mwperf::Digest256& identity) {
  return {
      mwperf::BoundaryCompletionKindV1::state_only_completion,
      identity,
      false,
      [retained_state](const mwperf::MarkedFluxAtomV1&) {
        return mwperf::Result<
            std::vector<mwperf::BoundaryCompletionAtomV1>>::success(
            {{retained_state, mwperf::ExactRational::one(), std::nullopt}});
      }};
}

[[nodiscard]] mwperf::InvariantLaw solve(
    const mwperf::TransitionMatrix& matrix,
    const mwperf::SelectionSpec& selection) {
  auto selected = mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(matrix), selection);
  INFO((selected ? std::string{}
                 : selected.error().code + ": " +
                       selected.error().message));
  REQUIRE(selected);
  auto law = mwperf::solve_invariant_distribution(
      matrix, std::move(selected).value(), matrix.bound_solver_policy());
  INFO((law ? std::string{}
            : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::RewardDecoder departure_reward() {
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            REQUIRE(argument.edge != nullptr);
            REQUIRE(argument.edge->target_departures.size() == 1U);
            return mwperf::Result<long double>::success(
                static_cast<long double>(
                    argument.edge->target_departures.front()));
          },
          {"c18.integration.scalar", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder backlog_reward(
    const mwperf::ReducedStateV1& unit_state,
    const bool requires_temporal_continuation = false) {
  return {mwperf::StationaryRewardDomainV1::state,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          requires_temporal_continuation,
          {},
          [unit_state](const mwperf::StationaryRewardArgumentV1& argument) {
            return mwperf::Result<long double>::success(
                argument.state == unit_state ? 1.0L : 0.0L);
          },
          {"c18.integration.scalar", 1U}};
}

[[nodiscard]] long double scalar(const mwperf::MetricValue& value) {
  auto result = mwperf::testing::C18FixtureAccess::decode_metric_scalar(value);
  REQUIRE(result);
  return result.value();
}

[[nodiscard]] bool has_note(const mwperf::Diagnostic& diagnostic,
                            const std::string_view fragment) {
  return std::ranges::any_of(
      diagnostic.notes, [fragment](const std::string& note) {
        return note.find(fragment) != std::string::npos;
      });
}

struct C18DiagnosticEvidenceV1 final {
  std::size_t state_count;
  std::size_t closed_class_count;
  mwperf::BoundaryCompletionKindV1 completion_kind;
  std::optional<long double> flow_difference;
  long double invariant_l1_residual;
};

class C18DiagnosticSinkSpy final {
 public:
  [[nodiscard]] C18DiagnosticEvidenceV1 consume(
      const mwperf::DiagnosticBundle& diagnostics) {
    ++calls_;
    return {diagnostics.state_count, diagnostics.closed_class_count,
            diagnostics.completion_kind, diagnostics.flow_difference,
            diagnostics.invariant.l1_invariance_residual};
  }

  [[nodiscard]] std::size_t calls() const noexcept { return calls_; }

 private:
  std::size_t calls_{0U};
};

template <typename Sink>
concept CanMintStabilityCertificate = requires(Sink& sink) {
  sink.mint_stability_certificate();
};

template <typename Extra>
concept RewardAcceptsExtraProvider =
    requires(const mwperf::InvariantLaw& law,
             const mwperf::RewardDecoder& decoder, const Extra& extra) {
      mwperf::evaluate_stationary_edge_reward(law, decoder, extra);
    };

template <typename Extra>
concept DiagnosticsAcceptExtraProvider =
    requires(const mwperf::InvariantLaw& law,
             const mwperf::ResolvedInstance& instance, const Extra& extra) {
      mwperf::compute_stationary_flux_diagnostics(law, instance, extra);
    };

static_assert(!CanMintStabilityCertificate<C18DiagnosticSinkSpy>);
static_assert(!RewardAcceptsExtraProvider<mwperf::AuditedRowProvider>);
static_assert(!RewardAcceptsExtraProvider<mwperf::KernelAccess>);
static_assert(!DiagnosticsAcceptExtraProvider<mwperf::AuditedRowProvider>);
static_assert(!DiagnosticsAcceptExtraProvider<mwperf::KernelAccess>);

}  // namespace

TEST_CASE("C18 consumes one C17 sealed row and evaluates its completed flux",
          "[c18][integration]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto compiled = mwperf::compile_reduced_kernel_row(
      provider.value(), framework.initial_state);
  REQUIRE(compiled);
  REQUIRE(compiled.value().exact_total_mass() ==
          mwperf::ExactRational::one());
  auto projected = mwperf::project_marked_row_to_endpoint(compiled.value());
  REQUIRE(projected);
  CHECK(projected.value().exact_total_mass() ==
        mwperf::ExactRational::one());

  const auto completion_identity = digest("c18.integration.marked-tail");
  const auto completion =
      marked_self_completion(framework.initial_state, completion_identity);
  auto assembled = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(), completion);
  INFO((assembled ? std::string{}
                  : assembled.error().code + ": " +
                        assembled.error().message));
  REQUIRE(assembled);
  const auto& selection =
      framework.instance.analysis_spec().context->selection;
  const auto law = solve(assembled.value(), selection);

  mwperf::ExactRational direct_departure = mwperf::ExactRational::zero();
  for (const auto& atom : law.marked_flux().rows().front().atoms) {
    REQUIRE(atom.edge.has_value());
    REQUIRE(atom.edge->target_departures.size() == 1U);
    direct_departure =
        direct_departure +
        atom.exact_mass *
            mwperf::ExactRational::make(
                mwperf::BigInt{atom.edge->target_departures.front()},
                mwperf::BigInt{1})
                .value();
  }
  const auto evaluated = mwperf::evaluate_stationary_edge_reward(
      law, departure_reward());
  REQUIRE(evaluated);
  CHECK(std::abs(scalar(evaluated.value()) -
                 direct_departure.to_long_double()) <= 1.0e-15L);
  CHECK(law.marked_flux().completion_identity() ==
        std::optional<mwperf::Digest256>{completion_identity});
}

TEST_CASE("C18 stationary state rewards do not imply temporal continuation",
          "[c18][integration]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto matrix = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_self_completion(framework.initial_state,
                             digest("c18.integration.backlog-tail")));
  REQUIRE(matrix);
  const auto law = solve(
      matrix.value(), framework.instance.analysis_spec().context->selection);

  auto backlog = mwperf::evaluate_stationary_edge_reward(
      law, backlog_reward(framework.initial_state));
  REQUIRE(backlog);
  CHECK(scalar(backlog.value()) == 1.0L);

  auto lag_two = mwperf::evaluate_stationary_edge_reward(
      law, backlog_reward(framework.initial_state, true));
  REQUIRE_FALSE(lag_two);
  CHECK(lag_two.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK(lag_two.error().code == "missing_temporal_continuation");
}

TEST_CASE("C18 requires and records an explicit finite-tail completion",
          "[c18][integration]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto compiled = mwperf::compile_reduced_kernel_row(
      provider.value(), framework.initial_state);
  REQUIRE(compiled);
  REQUIRE(compiled.value().atoms().size() == 1U);
  const auto& omitted_endpoint =
      compiled.value().atoms().front().edge.successor_state();

  auto absent = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(), exact_closed_boundary());
  REQUIRE_FALSE(absent);
  CHECK(absent.error().code == "c18.positive_domain_leakage");
  CHECK(has_note(absent.error(), "mass 1/1"));
  CHECK(has_note(absent.error(), "endpoint"));
  CHECK_FALSE(omitted_endpoint == framework.initial_state);

  auto state_only = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      state_only_self_completion(
          framework.initial_state,
          digest("c18.integration.state-only-tail")));
  REQUIRE(state_only);
  const auto state_only_law = solve(
      state_only.value(),
      framework.instance.analysis_spec().context->selection);
  auto state_value = mwperf::evaluate_stationary_edge_reward(
      state_only_law, backlog_reward(framework.initial_state));
  REQUIRE(state_value);
  CHECK(scalar(state_value.value()) == 1.0L);
  auto unavailable_edge = mwperf::evaluate_stationary_edge_reward(
      state_only_law, departure_reward());
  REQUIRE_FALSE(unavailable_edge);
  CHECK(unavailable_edge.error().code ==
        "c18.edge_reward_unavailable_after_state_completion");
  const auto state_only_diagnostics =
      mwperf::compute_stationary_flux_diagnostics(state_only_law,
                                                  framework.instance);
  CHECK(state_only_diagnostics.instance_binding_matches);
  CHECK_FALSE(state_only_diagnostics.completion_mark_scope_available);
  CHECK_FALSE(state_only_diagnostics.expected_departures.has_value());
  CHECK_FALSE(state_only_diagnostics.expected_arrivals.has_value());
  CHECK_FALSE(state_only_diagnostics.flow_difference.has_value());

  const auto completion_identity = digest("c18.integration.tail-provenance");
  auto completed = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_self_completion(framework.initial_state, completion_identity));
  REQUIRE(completed);
  REQUIRE(completed.value().marked_flux().leakage().size() == 1U);
  CHECK(completed.value().marked_flux().leakage().front().original_successor ==
        omitted_endpoint);
  CHECK(completed.value().marked_flux().exact_completed_mass() ==
        mwperf::ExactRational::one());
  CHECK(completed.value().marked_flux().completion_identity() ==
        std::optional<mwperf::Digest256>{completion_identity});

  const auto law = solve(
      completed.value(), framework.instance.analysis_spec().context->selection);
  CHECK(law.marked_flux().completion_identity() ==
        completed.value().marked_flux().completion_identity());
  const auto diagnostics = mwperf::compute_stationary_flux_diagnostics(
      law, framework.instance);
  CHECK(diagnostics.instance_binding_matches);
  CHECK(diagnostics.completion_kind ==
        mwperf::BoundaryCompletionKindV1::marked_completion);
  CHECK(diagnostics.exact_completed_mass ==
        std::optional<mwperf::ExactRational>{mwperf::ExactRational::one()});
  CHECK(diagnostics.completed_mass == 1.0L);
  REQUIRE(diagnostics.leakage.size() == 1U);
}

TEST_CASE("C18 rejects a completed C17 edge that violates exact N-D+A",
          "[c18][integration][negative]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto compiled = mwperf::compile_reduced_kernel_row(
      provider.value(), framework.initial_state);
  REQUIRE(compiled);
  REQUIRE(compiled.value().atoms().size() == 1U);
  CHECK_FALSE(compiled.value().atoms().front().edge.successor_state() ==
              framework.initial_state);

  auto assembled = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_recurrence_mismatch_completion(
          framework.initial_state,
          digest("c18.integration.recurrence-mismatch")));
  REQUIRE_FALSE(assembled);
  CHECK(assembled.error().code == "c18.mark_to_endpoint_mismatch");
}

TEST_CASE("C18 diagnostics are evidence and never a stability certificate",
          "[c18][integration]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto matrix = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_self_completion(framework.initial_state,
                             digest("c18.integration.diagnostic-tail")));
  REQUIRE(matrix);
  const auto law = solve(
      matrix.value(), framework.instance.analysis_spec().context->selection);
  const auto diagnostics = mwperf::compute_stationary_flux_diagnostics(
      law, framework.instance);

  C18DiagnosticSinkSpy sink;
  const auto evidence = sink.consume(diagnostics);
  CHECK(sink.calls() == 1U);
  CHECK(evidence.state_count == 1U);
  CHECK(evidence.closed_class_count == 1U);
  CHECK(evidence.completion_kind ==
        mwperf::BoundaryCompletionKindV1::marked_completion);
  CHECK(evidence.flow_difference == diagnostics.flow_difference);
  CHECK(evidence.invariant_l1_residual ==
        diagnostics.invariant.l1_invariance_residual);
}

TEST_CASE("C18 invariant laws retain their own completion-bound marked flux",
          "[c18][integration]") {
  auto framework = c18_framework();
  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  const auto completion_identity = digest("c18.integration.bound-flux");
  auto matrix = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_self_completion(framework.initial_state, completion_identity));
  REQUIRE(matrix);
  const auto law = solve(
      matrix.value(), framework.instance.analysis_spec().context->selection);
  CHECK(law.matrix_identity() == matrix.value().matrix_identity());
  REQUIRE(law.marked_flux().completion_identity().has_value());
  CHECK(*law.marked_flux().completion_identity() == completion_identity);
}

TEST_CASE("C18 production diagnostics reject a value-identical foreign instance",
          "[c18][integration][negative]") {
  auto framework = c18_framework();
  auto foreign = c18_framework();
  CHECK(framework.instance.fingerprints() == foreign.instance.fingerprints());
  CHECK_FALSE(framework.instance.arrival().shares_compiled_product_with(
      foreign.instance.arrival()));

  auto provider = mwperf::audited_row_provider(framework.framework);
  REQUIRE(provider);
  auto matrix = mwperf::assemble_finite_transition_matrix(
      {{framework.initial_state}}, provider.value(),
      marked_self_completion(
          framework.initial_state,
          digest("c18.integration.foreign-instance-tail")));
  REQUIRE(matrix);
  const auto law = solve(
      matrix.value(), framework.instance.analysis_spec().context->selection);
  const auto diagnostics = mwperf::compute_stationary_flux_diagnostics(
      law, foreign.instance);
  CHECK_FALSE(diagnostics.instance_binding_matches);
  CHECK(diagnostics.fatal);
  CHECK_FALSE(diagnostics.publication_allowed);
  CHECK_FALSE(diagnostics.arrival_phase_marginal_available);
  CHECK_FALSE(diagnostics.expected_departures.has_value());
  CHECK_FALSE(diagnostics.expected_arrivals.has_value());
  CHECK_FALSE(diagnostics.flow_difference.has_value());
}
