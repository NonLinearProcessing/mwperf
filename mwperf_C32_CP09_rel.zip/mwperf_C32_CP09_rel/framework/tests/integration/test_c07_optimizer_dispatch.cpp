#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

struct PreparedQuery final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

[[nodiscard]] std::filesystem::path write_input(const std::string& stem,
                                                const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c07-dispatch";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (stem + '-' + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string analysis_text() {
  return R"({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":64,"max_search_states_per_call":5},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })";
}

[[nodiscard]] std::string model_text(const std::string& scheduler,
                                     const std::string& queues) {
  return R"({"schema_version":"3.0.0","run":{"seed":7,"slots":3,"warmup_slots":0,"termination":"fixed_slots"},"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues + R"(},"scheduler":)" + scheduler +
         R"(,"arrival":{"family":"deterministic_trace","events":[]},"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})";
}

[[nodiscard]] ParsedPair parse_pair(const std::string& scheduler,
                                    const std::string& queues) {
  auto model_document = mwperf::load_document(
      write_input("model", model_text(scheduler, queues)));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto parsed_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(parsed_model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text()));
  REQUIRE(analysis_document);
  auto parsed_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(parsed_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      parsed_model.value(), parsed_analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(parsed_model).value(),
                    std::move(parsed_analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] mwperf::detail::ResolutionChildServices
production_constraint_children() {
  mwperf::detail::ResolutionChildServices services;
  services.constraint =
      [](const mwperf::AuthoredSchedulerConfig& scheduler,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::compile_constraint_descriptor(scheduler, catalog);
      };
  services.arrival =
      [](const mwperf::AuthoredArrivalConfig&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-arrival-placeholder");
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  services.support =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::PhysicalBindingIdentity&,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::QueueMask::from_bytes(
            std::vector<std::uint8_t>(catalog.size(), 0U), catalog.size());
      };
  services.initial =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::ResolvedTransientInitialLaw&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-initial-placeholder");
        return mwperf::detail::InitialCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  return services;
}

[[nodiscard]] mwperf::ResolvedInstance resolved_instance(
    const std::string& scheduler, const std::string& queues) {
  const ParsedPair pair = parse_pair(scheduler, queues);
  const auto children = production_constraint_children();
  auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  INFO((resolved ? std::string{} : resolved.error().code));
  REQUIRE(resolved);
  REQUIRE(resolved.value().constraint().compiled_product().has_owner());
  return std::move(resolved).value();
}

[[nodiscard]] mwperf::PrimaryWeights make_primary(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values) {
  auto result = mwperf::PrimaryWeights::from_values(
      mwperf::QueueDimensionToken::from_instance(instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] PreparedQuery prepare_query(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values,
    std::vector<std::uint8_t> eligibility_values) {
  auto primary = make_primary(instance, std::move(values));
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      primary.dimension(), std::move(eligibility_values));
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary, instance.priority(), eligibility.value());
  REQUIRE(weights);
  return PreparedQuery{std::move(primary),
                       std::move(eligibility).value(),
                       std::move(weights).value()};
}

[[nodiscard]] mwperf::OptimizerExecutionContext execution_context(
    const mwperf::ResolvedInstance& instance) {
  auto result =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerSolution solve_production(
    const mwperf::ResolvedInstance& instance, const PreparedQuery& query) {
  auto context = execution_context(instance);
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto solution = mwperf::solve_exact(instance.constraint(),
                                      query.eligibility, query.weights,
                                      budget.value());
  INFO((solution ? std::string{} : solution.error().code));
  REQUIRE(solution);
  auto validation = mwperf::validate_optimizer_solution(
      solution.value(), instance.constraint(), query.eligibility,
      query.weights);
  INFO((validation ? std::string{} : validation.error().code));
  REQUIRE(validation);
  CHECK(solution.value().accounting().completed_expansions().is_zero());
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "1");
  return std::move(solution).value();
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::string canonical_node_scheduler() {
  return R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C","D","E","isolated"],"links":[{"queue_id":"q0","u":"A","v":"B"},{"queue_id":"q1","u":"B","v":"A"},{"queue_id":"q2","u":"C","v":"D"},{"queue_id":"q3","u":"A","v":"C"},{"queue_id":"q4","u":"B","v":"E"}]},"priority":["q1","q0","q2","q3","q4"]}})";
}

[[nodiscard]] std::string forced_scheduler(const bool reverse_residual) {
  const std::string priority =
      reverse_residual
          ? R"(["q0","q1","q4","q5","q2","q3","q6"])"
          : R"(["q0","q1","q5","q4","q2","q3","q6"])";
  return R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C","D","E","F"],"links":[{"queue_id":"q0","u":"A","v":"B"},{"queue_id":"q1","u":"B","v":"A"},{"queue_id":"q2","u":"A","v":"C"},{"queue_id":"q3","u":"B","v":"D"},{"queue_id":"q4","u":"C","v":"D"},{"queue_id":"q5","u":"D","v":"C"},{"queue_id":"q6","u":"E","v":"F"}]},"priority":)" +
         priority + R"(}})";
}

[[nodiscard]] bool node_feasible(
    const mwperf::ResolvedNodeExclusiveConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<std::uint8_t> used(constraint.vertices.size(), 0U);
  for (const auto& link : constraint.links) {
    if (selected[link.queue.ordinal()] == 0U) {
      continue;
    }
    if (used[link.u.ordinal()] != 0U || used[link.v.ordinal()] != 0U) {
      return false;
    }
    used[link.u.ordinal()] = 1U;
    used[link.v.ordinal()] = 1U;
  }
  return true;
}

[[nodiscard]] mwperf::BigNat exhaustive_forced_primary(
    const mwperf::ResolvedInstance& instance,
    const mwperf::EligibilityMask& eligibility,
    const mwperf::PrimaryWeights& primary, const std::size_t target,
    const mwperf::ForcedTargetBit side) {
  REQUIRE(primary.size() < std::numeric_limits<std::uint64_t>::digits);
  const auto& constraint =
      std::get<mwperf::ResolvedNodeExclusiveConstraint>(
          instance.constraint().value());
  std::optional<mwperf::BigNat> best;
  const std::uint64_t count = std::uint64_t{1U} << primary.size();
  for (std::uint64_t mask = 0U; mask < count; ++mask) {
    std::vector<std::uint8_t> selected(primary.size(), 0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      selected[queue] =
          static_cast<std::uint8_t>((mask >> queue) & 1U);
      if (queue != target && selected[queue] != 0U &&
          eligibility.bytes()[queue] == 0U) {
        allowed = false;
      }
    }
    const bool target_one = side == mwperf::ForcedTargetBit::one;
    if ((selected[target] != 0U) != target_one) {
      allowed = false;
    }
    if (!allowed || !node_feasible(constraint, selected)) {
      continue;
    }
    mwperf::BigNat objective(0U);
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      if (queue != target && selected[queue] != 0U) {
        objective += primary.values()[queue];
      }
    }
    if (!best.has_value() || objective > *best) {
      best = std::move(objective);
    }
  }
  REQUIRE(best.has_value());
  return std::move(*best);
}

[[nodiscard]] mwperf::TargetIndex target(
    const mwperf::ResolvedInstance& instance, const std::size_t ordinal) {
  auto result = mwperf::TargetIndex::from_instance(instance, ordinal);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::string queue_list(const std::size_t count) {
  std::ostringstream output;
  output << '[';
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"q" << queue << "\"";
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string large_node_scheduler() {
  std::ostringstream links;
  links << '[';
  for (std::size_t queue = 0U; queue < 65U; ++queue) {
    if (queue != 0U) {
      links << ',';
    }
    links << "{\"queue_id\":\"q" << queue
          << "\",\"u\":\"A\",\"v\":\"B\"}";
  }
  const std::vector<std::pair<std::string, std::string>> cycle{
      {"C", "D"}, {"D", "E"}, {"E", "F"}, {"F", "G"},
      {"G", "C"}};
  for (std::size_t edge = 0U; edge < cycle.size(); ++edge) {
    links << ",{\"queue_id\":\"q" << (65U + edge)
          << "\",\"u\":\"" << cycle[edge].first
          << "\",\"v\":\"" << cycle[edge].second << "\"}";
  }
  links << ']';
  return R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C","D","E","F","G","isolated"],"links":)" +
         links.str() + R"(},"priority":null}})";
}

[[nodiscard]] mwperf::BigNat power_of_two(const unsigned int shift) {
  mwperf::BigInt value = 1;
  value <<= shift;
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result);
  return std::move(result).value();
}

}  // namespace

TEST_CASE("C07 production compile dispatch and validation satisfy the exact ABI",
          "[c07][integration][dispatch]") {
  const auto instance = resolved_instance(canonical_node_scheduler(),
                                          R"(["q0","q1","q2","q3","q4"])");
  REQUIRE(instance.constraint().family() ==
          mwperf::ServiceFamily::node_exclusive_matching);
  CHECK(instance.constraint().identity().optimizer ==
        mwperf::OptimizerId::edmonds_blossom_exact);
  const auto query = prepare_query(
      instance,
      {mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(6U),
       mwperf::BigNat(5U), mwperf::BigNat(5U)},
      {1U, 1U, 1U, 1U, 1U});
  const auto solution = solve_production(instance, query);
  CHECK((schedule_bits(solution.schedule()) ==
         std::vector<std::uint8_t>{0U, 1U, 1U, 0U, 0U}));
  CHECK(solution.family() == mwperf::ServiceFamily::node_exclusive_matching);
  CHECK(solution.backend_id() == mwperf::OptimizerId::edmonds_blossom_exact);
}

TEST_CASE("C07 repeated production solves are cold and byte deterministic",
          "[c07][integration][determinism]") {
  const auto instance = resolved_instance(canonical_node_scheduler(),
                                          R"(["q0","q1","q2","q3","q4"])");
  const auto query = prepare_query(
      instance,
      {mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(6U),
       mwperf::BigNat(5U), mwperf::BigNat(5U)},
      {1U, 1U, 1U, 1U, 1U});
  const auto first = solve_production(instance, query);
  const auto second = solve_production(instance, query);
  CHECK(first == second);
  CHECK(std::ranges::equal(first.schedule().bytes(),
                           second.schedule().bytes()));
  CHECK(first.composite_objective() == second.composite_objective());
  CHECK(std::ranges::equal(first.proof_notes(), second.proof_notes()));
}

TEST_CASE("C07 node-exclusive remains multiprecision above sixty-four queues",
          "[c07][integration][multiprecision]") {
  constexpr std::size_t queue_count = 70U;
  const auto instance =
      resolved_instance(large_node_scheduler(), queue_list(queue_count));
  const mwperf::BigNat huge = power_of_two(200U);
  std::vector<mwperf::BigNat> values(queue_count, huge);
  values[0U] += mwperf::BigNat(1U);
  values[65U] += mwperf::BigNat(5U);
  values[66U] += mwperf::BigNat(4U);
  values[67U] += mwperf::BigNat(3U);
  values[68U] += mwperf::BigNat(2U);
  values[69U] += mwperf::BigNat(1U);
  const auto query = prepare_query(
      instance, std::move(values), std::vector<std::uint8_t>(queue_count, 1U));
  const auto solution = solve_production(instance, query);
  REQUIRE(solution.schedule().size() == queue_count);
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    const bool expected = queue == 0U || queue == 65U || queue == 67U;
    INFO(queue);
    CHECK((solution.schedule().bytes()[queue] != 0U) == expected);
  }
  CHECK(solution.composite_objective().bit_length() > 256U);
  CHECK(solution.accounting().completed_expansions().is_zero());
}

TEST_CASE("C07 forced-target faces agree with labelled exhaustive enumeration",
          "[c07][integration][forced-target]") {
  for (const bool reverse_residual : {false, true}) {
    const auto instance = resolved_instance(
        forced_scheduler(reverse_residual),
        R"(["q0","q1","q2","q3","q4","q5","q6"])");
    const auto dimension =
        mwperf::QueueDimensionToken::from_instance(instance);
    auto eligibility_result = mwperf::EligibilityMask::from_bytes(
        dimension, {0U, 1U, 1U, 1U, 1U, 1U, 1U});
    REQUIRE(eligibility_result);
    const auto eligibility = std::move(eligibility_result).value();
    const auto primary = make_primary(
        instance,
        {mwperf::BigNat(1000U), mwperf::BigNat(31U),
         mwperf::BigNat(19U), mwperf::BigNat(18U),
         mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(11U)});
    std::vector<mwperf::BigNat> changed_values(
        primary.values().begin(), primary.values().end());
    changed_values[0U] = power_of_two(180U);
    const auto changed = make_primary(instance, std::move(changed_values));
    const auto selected_target = target(instance, 0U);

    const auto solve_side = [&](const mwperf::PrimaryWeights& weights,
                                const mwperf::ForcedTargetBit side) {
      auto context = execution_context(instance);
      auto result = mwperf::solve_forced_target(
          context, instance.constraint(), eligibility, weights,
          selected_target, side, instance.priority());
      INFO((result ? std::string{} : result.error().code));
      REQUIRE(result);
      CHECK(result.value().value == exhaustive_forced_primary(
                                          instance, eligibility, weights,
                                          0U, side));
      CHECK(result.value().family ==
            mwperf::ServiceFamily::node_exclusive_matching);
      CHECK(result.value().backend_id ==
            mwperf::OptimizerId::edmonds_blossom_exact);
      CHECK(result.value().accounting.completed_expansions().is_zero());
      CHECK((result.value().witness.bytes()[0U] != 0U) ==
            (side == mwperf::ForcedTargetBit::one));
      return std::move(result).value();
    };

    const auto zero = solve_side(primary, mwperf::ForcedTargetBit::zero);
    const auto one = solve_side(primary, mwperf::ForcedTargetBit::one);
    const auto changed_zero =
        solve_side(changed, mwperf::ForcedTargetBit::zero);
    const auto changed_one = solve_side(changed, mwperf::ForcedTargetBit::one);
    CHECK(zero.value.to_decimal_string() == "49");
    CHECK(one.value.to_decimal_string() == "18");
    CHECK(zero == changed_zero);
    CHECK(one == changed_one);
    const std::size_t preferred_residual = reverse_residual ? 4U : 5U;
    CHECK(zero.witness.bytes()[preferred_residual] == 1U);
    CHECK(one.witness.bytes()[preferred_residual] == 1U);
    CHECK(zero.witness.bytes()[9U - preferred_residual] == 0U);
    CHECK(one.witness.bytes()[9U - preferred_residual] == 0U);
  }
}

TEST_CASE("C07 addition leaves both C06 exact backends unchanged",
          "[c07][integration][regression]") {
  struct Case final {
    std::string scheduler;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId optimizer;
  };
  const std::vector<Case> cases{
      {
          R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"}]},"priority":null}})",
          mwperf::ServiceFamily::crossbar_matching,
          mwperf::OptimizerId::hungarian_exact,
      },
      {
          R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":3},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":1,"right":3}]},"priority":null}})",
          mwperf::ServiceFamily::nonoverlapping_intervals,
          mwperf::OptimizerId::weighted_interval_dp_exact,
      },
  };
  for (const auto& family_case : cases) {
    const auto instance = resolved_instance(
        family_case.scheduler, R"(["q0","q1","q2"])");
    const auto query = prepare_query(
        instance,
        {mwperf::BigNat(10U), mwperf::BigNat(4U), mwperf::BigNat(4U)},
        {1U, 1U, 1U});
    const auto solution = solve_production(instance, query);
    CHECK((schedule_bits(solution.schedule()) ==
           std::vector<std::uint8_t>{1U, 0U, 0U}));
    CHECK(solution.family() == family_case.family);
    CHECK(solution.backend_id() == family_case.optimizer);
  }
}

TEST_CASE("C07 remains unchanged when C08 compiler registrations are added",
          "[c07][integration][dispatch]") {
  struct CurrentFamilyCase final {
    std::string scheduler;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId optimizer;
  };
  const std::vector<CurrentFamilyCase> cases{
      {
          R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":9}})",
          mwperf::ServiceFamily::pairwise_conflicts,
          mwperf::OptimizerId::mwis_branch_memo_exact,
      },
      {
          R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]}]},"priority":null,"max_search_states":9}})",
          mwperf::ServiceFamily::resource_packing,
          mwperf::OptimizerId::binary_packing_memo_exact,
      },
  };
  for (const CurrentFamilyCase& family_case : cases) {
    const ParsedPair pair =
        parse_pair(family_case.scheduler, R"(["q0","q1"])");
    auto catalog = mwperf::build_queue_catalog(pair.model.switch_config);
    REQUIRE(catalog);
    auto result = mwperf::compile_constraint_descriptor(
        pair.model.scheduler, catalog.value());
    REQUIRE(result);
    CHECK(result.value().compiled_product().has_owner());
    CHECK(result.value().family() == family_case.family);
    CHECK(result.value().identity().optimizer == family_case.optimizer);
  }
}
