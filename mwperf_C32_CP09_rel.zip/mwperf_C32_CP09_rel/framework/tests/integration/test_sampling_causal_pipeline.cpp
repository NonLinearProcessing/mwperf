#include <algorithm>
#include <array>
#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "fixtures/c17/direct_v0_fixture.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/sampling/estimators.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_test_providers.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing {

// C19's test seam is the existing narrow authority for rebinding a resolved
// physical instance to an exact C09 law.  The historical C19 executable owns
// the same definition only when that deprecated target is built; C24 supplies
// its definition inside this runner so the normal release graph stays closed.
Result<ResolvedInstance> C19FixtureAccess::bind_resolved_arrival_for_testing(
    const ResolvedInstance& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
  const auto reject = [](std::string code, std::string message) {
    return Result<ResolvedInstance>::failure(
        {DiagnosticCategory::input_validation, std::move(code),
         std::move(message), std::nullopt, std::nullopt, {}});
  };
  if (!configured_arrival) {
    return reject("c24.fixture_arrival_missing",
                  "the C24 route fixture requires an exact arrival law");
  }
  if (source.initial_law().has_value()) {
    return reject("c24.fixture_initial_law_bound_to_previous_arrival",
                  "the C24 route fixture requires stationary selection");
  }

  const PhysicalBindingIdentity physical = source.arrival().identity();
  const ArrivalBinding& binding = arrival_law_binding(*configured_arrival);
  if (physical.combined_input != source.fingerprints().combined ||
      binding.family != physical.arrival_family ||
      binding.timing != source.timing() ||
      binding.timing != physical.timing ||
      binding.queue_cardinality != source.queues().size() ||
      binding.queue_cardinality != physical.queue_cardinality) {
    return reject("c24.fixture_arrival_physical_binding_mismatch",
                  "the fixture law does not match the resolved physical "
                  "arrival binding");
  }
  auto catalog_digest = detail::digest_queue_catalog(source.queues());
  if (!catalog_digest || binding.catalog_digest != catalog_digest.value()) {
    return catalog_digest
               ? reject("c24.fixture_arrival_catalog_mismatch",
                        "the fixture law does not match the queue catalog")
               : Result<ResolvedInstance>::failure(catalog_digest.error());
  }
  QueueMask support = positive_arrival_support(*configured_arrival);
  if (support.size() != source.queues().size() ||
      support.bytes() != source.positive_arrival_support().bytes()) {
    return reject("c24.fixture_arrival_support_mismatch",
                  "the fixture law and authored law have different support");
  }

  const ArrivalProductBindingIdentity product_identity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
  const auto references = source.arrival().queue_references();
  ConfiguredArrivalBinding rebound_arrival(
      physical,
      std::vector<BoundQueueReference>(references.begin(), references.end()),
      std::shared_ptr<const void>(configured_arrival),
      ArrivalCompiledProductKind::compiled_arrival_law_v1,
      product_identity);
  return Result<ResolvedInstance>::success(ResolvedInstance(
      source.authored_model(), source.analysis_spec(), source.fingerprints(),
      source.queues(), source.priority(), source.constraint(),
      source.service_identity(), source.serviceable(),
      source.optimizer_budget(), source.targets(), std::move(rebound_arrival),
      std::move(support), source.initial_law(), source.timing()));
}

namespace c24_profile_route {
namespace {

using Factory = C15ProtocolFixtureFactory;
namespace designated = c16_designated_detail;
namespace c17 = mwperf::testing::c17;
namespace c17_direct = mwperf::testing::c17_direct;

enum class ArrivalMode : std::uint8_t { exact_iid, supported_temporal };

struct ProfileInput final {
  ResolvedInstance instance;
  std::shared_ptr<const CompiledArrivalLaw> arrival;
  MetricRequirements requirements;
  MetricRequest metric_request;
};

struct PreparedProfile final {
  SurrogateProvider provider;
  ValidatedProviderManifest manifest;
  ProfileInput input;
  FrameworkProblemView view;
  ValidatedSurrogateParameters parameters;
  PlugDescriptorPreview preview;
  ConstructionBudget budget;
};

struct ProfileFlow final {
  ValidatedSurrogateArtifact artifact;
  PortablePlugPayload payload;
  ValidatedSurrogatePlug plug;
  KernelAccess access;
};

[[nodiscard]] std::string_view scheduler_for_profile(
    const ServiceFamily family) {
  switch (family) {
    case ServiceFamily::node_exclusive_matching:
      return R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x","y","z"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"w","v":"x"},{"queue_id":"q2","u":"y","v":"z"}]},"priority":["q0","q1","q2"]}})json";
    case ServiceFamily::pairwise_conflicts:
      return R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2"],"max_search_states":null}})json";
    case ServiceFamily::resource_packing:
      return R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[2]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":null}})json";
    case ServiceFamily::crossbar_matching:
    case ServiceFamily::nonoverlapping_intervals:
      break;
  }
  FAIL("C24 selected a profile outside Blossom/MWIS/Packing");
  return {};
}

[[nodiscard]] ProfileInput profile_input(
    const C16TestProfileV1& profile, const ArrivalMode arrival_mode,
    const std::string_view metric_json) {
  static constexpr std::string_view model_template = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q1"},{"id":"q2"},{"id":"q0"}]},
    "scheduler":__C24_SCHEDULER__,
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s0"},{"id":"s1"},{"id":"s2"},
                 {"id":"s3"},{"id":"s4"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q2"},
                      {"source_id":"s2","d":1,"queue_id":"q2"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h0","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q1"},
                      {"source_id":"s2","d":1,"queue_id":"q1"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q2"},
                      {"source_id":"s2","d":1,"queue_id":"q2"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q1"},
                      {"source_id":"s2","d":1,"queue_id":"q1"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  std::string model(model_template);
  static constexpr std::string_view placeholder = "__C24_SCHEDULER__";
  const auto position = model.find(placeholder);
  REQUIRE(position != std::string::npos);
  model.replace(position, placeholder.size(),
                scheduler_for_profile(profile.family));

  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + std::string(metric_json) + R"json(],
    "surrogate":{"id":")json" + std::string(profile.provider_id) +
                               R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":8,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":8},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document =
      load_document(designated::write_input("c24-profile-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      designated::write_input("c24-profile-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  REQUIRE(instance);

  Result<CompiledArrivalLaw> configured =
      arrival_mode == ArrivalMode::exact_iid
          ? make_c09_correlated_fixture_law(
                instance.value().queues(), FixtureFailureMode::none,
                FixtureConstructionProfile::portable_iid_joint_table)
          : make_c09_correlated_fixture_law(instance.value().queues());
  REQUIRE(configured);
  auto arrival = std::make_shared<const CompiledArrivalLaw>(
      std::move(configured).value());
  auto rebound = C19FixtureAccess::bind_resolved_arrival_for_testing(
      instance.value(), arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  auto metric_request = parse_metric_request(
      rebound.value().analysis_spec().metrics.front(),
      rebound.value().queues());
  REQUIRE(metric_request);
  auto requirements = aggregate_metric_requirements(
      std::vector<MetricRequest>{metric_request.value()});
  return {std::move(rebound).value(), std::move(arrival),
          std::move(requirements), std::move(metric_request).value()};
}

[[nodiscard]] PreparedProfile prepare_profile(
    const C16TestProfileV1& profile, const ArrivalMode arrival_mode,
    const std::string_view metric_json) {
  auto input = profile_input(profile, arrival_mode, metric_json);
  auto id = SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{}
                 : provider.error().code + ": " +
                       provider.error().message));
  REQUIRE(provider);
  const TargetSelection targets{
      1U, {designated::queue("q0")},
      ConstructionGroupIdV1(designated::label("c24.profile.group"))};
  auto view = build_framework_problem_view(
      input.instance, *input.arrival, targets);
  INFO((view ? std::string{}
             : view.error().code + ": " + view.error().message));
  REQUIRE(view);
  auto parameters = validate_surrogate_parameters(
      provider.value(), designated::parameters());
  REQUIRE(parameters);
  const auto budget = designated::budget();
  auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(), manifest, std::move(input),
          std::move(view).value(), std::move(parameters).value(),
          std::move(preview).value(), budget};
}

[[nodiscard]] std::filesystem::path execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c24-profile-runs";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

[[nodiscard]] ArrivalPhase profile_phase(
    const C16DesignatedScenarioV1& scenario, std::string state,
    const std::uint64_t seed, const std::uint64_t replica,
    const bool return_after = false) {
  auto key = make_physical_reference_instance_key(
      scenario.instance.fingerprints().combined, BigNat{replica});
  REQUIRE(key);
  auto stream = make_configured_arrival_stream_key(
      *scenario.arrival,
      derive_rng_stream(MasterSeed{seed}, StageTag::configured_arrival,
                        key.value()));
  REQUIRE(stream);
  const bool trace_origin =
      scenario.instance.arrival().identity().arrival_family ==
      ArrivalFamily::deterministic_trace;
  ArrivalInitialState initial = trace_origin
                                    ? ArrivalInitialState{TraceOrigin{}}
                                    : ArrivalInitialState{
                                          SharedRoundState{state}};
  auto process = instantiate_arrival_process(
      *scenario.arrival, std::move(initial), std::move(stream).value());
  REQUIRE(process);
  auto first = next_arrival_step(process.value(), BigNat{0U});
  REQUIRE(first);
  return trace_origin && return_after ? first.value().phase_after
                                      : first.value().phase_before;
}

[[nodiscard]] C16DesignatedScenarioV1 accepted_profile_scenario(
    const C16TestProfileV1& profile, const ArrivalMode arrival_mode) {
  static constexpr std::string_view metric =
      R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json";
  auto prepared = prepare_profile(profile, arrival_mode, metric);
  auto budget_digest = digest_construction_budget_v1(prepared.budget);
  REQUIRE(budget_digest);
  const auto& header = metric_request_header(prepared.input.metric_request);
  const auto backend = arrival_mode == ArrivalMode::exact_iid
                           ? BackendRouteKindV1::analytic_metric_family
                           : BackendRouteKindV1::residence_or_stopped_law;
  std::vector<ResolvedMetricContractV1> metric_contracts{{
      header.authored_index,
      {header.metric_id, header.authored_index},
      header.metric_id,
      header.ordered_targets,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      TargetCouplingV1::scalar_target,
      SolverRegimeV1::analytic,
      backend,
      prepared.preview.metric_support_manifest->canonical_digest()}};
  auto contract = Factory::accepted_contract(
      prepared.manifest.value(), prepared.preview.core,
      *prepared.preview.metric_support_manifest, prepared.input.requirements,
      prepared.view.configured_arrival().capabilities(),
      std::move(metric_contracts),
      prepared.preview.construction_target_scope, prepared.preview.policies,
      prepared.preview.construction_prerequisites,
      prepared.view.canonical_digest().value(),
      prepared.parameters.canonical_value_digest(), budget_digest.value());
  auto request = make_surrogate_build_request(
      prepared.manifest, prepared.view, contract, prepared.parameters,
      prepared.budget, MasterSeed{0xC2409U});
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  return {std::move(prepared.provider), prepared.manifest,
          std::move(prepared.input.instance),
          std::move(prepared.input.arrival),
          std::move(prepared.input.requirements),
          std::move(prepared.input.metric_request),
          std::move(prepared.view), std::move(prepared.parameters),
          std::move(prepared.preview), std::move(contract),
          prepared.budget, std::move(request).value()};
}

[[nodiscard]] CapabilityDecision negotiate_profile_metric(
    const C16TestProfileV1& profile, const ArrivalMode arrival_mode,
    const std::string_view metric_json) {
  auto prepared = prepare_profile(profile, arrival_mode, metric_json);
  return negotiate_capabilities(
      prepared.input.requirements, prepared.preview,
      prepared.view.configured_arrival().capabilities());
}

[[nodiscard]] ProfileFlow run_profile_flow(
    const C16DesignatedScenarioV1& scenario) {
  auto context = BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root());
  REQUIRE(context);
  auto outcome = execute_surrogate_provider(
      scenario.provider, scenario.request, context.value());
  const auto* completed = std::get_if<CompletedProviderExecution>(&outcome);
  INFO((completed != nullptr
            ? std::string{}
            : std::get<FailedProviderExecution>(outcome).diagnostic.code));
  REQUIRE(completed != nullptr);
  const ArtifactParseLimits limits{
      1U << 20U, 64U,       1U << 14U, 1U << 14U,
      1U << 16U, 1U << 16U, 8U << 20U};
  auto parsed = parse_surrogate_build_result(completed->bytes, limits);
  REQUIRE(parsed);
  auto report = validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.budget);
  REQUIRE(report);
  auto validated = validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.provider.manifest(),
      scenario.contract, report.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto realized = resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  const auto* built = std::get_if<RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(built != nullptr);
  auto payload = adapt_portable_payload(built->artifact);
  REQUIRE(payload);
  auto plug = materialize_and_validate_surrogate_plug(
      payload.value(), built->artifact, scenario.contract);
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  return {built->artifact, std::move(payload).value(),
          std::move(plug).value(), std::move(access).value()};
}

[[nodiscard]] AuditedCompiledFramework audit_profile(
    const C16DesignatedScenarioV1& scenario, ProfileFlow flow) {
  const PlugDescriptor descriptor = flow.plug.descriptor();
  const std::vector<QueueId> targets(
      scenario.view.target_selection().ordered_targets.begin(),
      scenario.view.target_selection().ordered_targets.end());
  const bool trace_origin =
      scenario.instance.arrival().identity().arrival_family ==
      ArrivalFamily::deterministic_trace;
  auto phase_zero = profile_phase(scenario, "h0", 0xC240AU, 0U);
  auto phase_one =
      profile_phase(scenario, "h1", 0xC240BU, 1U, trace_origin);
  auto state_schema = c17::exact_state_schema(
      scenario.instance, targets, phase_zero, phase_one);
  const auto initial = c17::reduced_state(targets, {0U});
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      scenario.instance, BigNat{0U});
  REQUIRE(optimizer);
  const c17_direct::MaterializationV1 carried{flow.artifact, flow.payload};
  auto framework_seed = c17_direct::framework_seed(
      scenario, descriptor, flow.access, state_schema, initial);
  CompiledFrameworkCandidateInputsV1 inputs{
      scenario.request.build_identity_digest(),
      scenario.request.request_digest().value(),
      scenario.instance,
      *scenario.arrival,
      scenario.contract,
      c17_direct::validate_realized(scenario, carried),
      state_schema,
      {ExactCausalProgramModeV1::closed_three_bin_scalar,
       physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(),
       {c17::reduced_state(targets, {0U}),
        c17::reduced_state(targets, {1U}),
        c17::reduced_state(targets, {2U}),
        c17::reduced_state(targets, {3U})}},
      std::nullopt,
      std::move(optimizer).value(),
      std::move(framework_seed)};
  auto candidate = C17FixtureAccess::make_candidate(
      std::move(flow.plug), std::move(inputs));
  auto framework = audit_v0_causality(
      std::move(candidate), descriptor, std::move(flow.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return std::move(framework).value();
}

}  // namespace
}  // namespace c24_profile_route
}  // namespace mwperf::testing

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix = mwperf::testing::c16_registered_pair_matrix;
namespace c17 = mwperf::testing::c17;
namespace profile_route = mwperf::testing::c24_profile_route;

template <typename Source>
concept C24GeneratorValidationInput = requires(const Source& source) {
  { mwperf::validate_conditional_generator(source) } ->
      std::same_as<mwperf::Result<mwperf::NormalizedSamplerAccess>>;
};

template <typename Source>
concept C17SamplerDescriptorSource = requires(const Source& source) {
  { mwperf::audited_sampler_descriptor(source) } ->
      std::same_as<mwperf::Result<mwperf::AuditedSamplerDescriptor>>;
};

template <typename Source>
concept C17SlotExecutorSource = requires(const Source& source) {
  { mwperf::audited_slot_executor(source) } ->
      std::same_as<mwperf::Result<mwperf::AuditedSlotExecutor>>;
};

template <typename Source>
concept C24EmpiricalRowEstimatorSource =
    requires(const Source& source, const mwperf::ConditioningState& row,
             const mwperf::SamplingPlan& plan) {
      { mwperf::estimate_discrete_kernel_row(source, row, plan) } ->
          std::same_as<mwperf::Result<mwperf::EmpiricalRow>>;
    };

template <typename Source>
concept C24RewardEstimatorSource =
    requires(const Source& source, const mwperf::ConditioningState& row,
             const mwperf::RewardDecoder& reward,
             const mwperf::SamplingPlan& plan) {
      { mwperf::estimate_reward_expectation(source, row, reward, plan) } ->
          std::same_as<mwperf::Result<mwperf::Estimate>>;
    };

static_assert(C24GeneratorValidationInput<mwperf::AuditedSamplerDescriptor>);
static_assert(!C24GeneratorValidationInput<mwperf::KernelAccess>);
static_assert(
    !C24GeneratorValidationInput<mwperf::NormalizedConditionalSamplerAccess>);
static_assert(!C24GeneratorValidationInput<mwperf::CompiledFrameworkCandidate>);

static_assert(!C17SamplerDescriptorSource<mwperf::Sample>);
static_assert(!C17SamplerDescriptorSource<mwperf::EmpiricalRow>);
static_assert(!C17SamplerDescriptorSource<mwperf::Estimate>);
static_assert(!C17SamplerDescriptorSource<mwperf::SurrogateProvider>);
static_assert(
    !C17SamplerDescriptorSource<mwperf::ValidatedProviderManifest>);
static_assert(!C17SamplerDescriptorSource<mwperf::PlugDescriptorPreview>);
static_assert(!C24GeneratorValidationInput<mwperf::AuditedThreeBinResponse>);
static_assert(!C17SlotExecutorSource<mwperf::Sample>);
static_assert(!C17SlotExecutorSource<mwperf::EmpiricalRow>);
static_assert(!C17SlotExecutorSource<mwperf::Estimate>);
static_assert(!std::is_constructible_v<mwperf::CompletedReducedEdge,
                                       mwperf::Sample>);
static_assert(!std::is_constructible_v<mwperf::AuditedTemporalKernel,
                                       mwperf::EmpiricalRow>);
static_assert(!std::is_constructible_v<mwperf::AuditedTemporalLaw,
                                       mwperf::Estimate>);
static_assert(!std::is_constructible_v<mwperf::AuditedCylinderLaw,
                                       mwperf::EmpiricalResidual>);
static_assert(!C24EmpiricalRowEstimatorSource<
              mwperf::ArtifactProvenanceV1>);
static_assert(!C24RewardEstimatorSource<mwperf::ArtifactProvenanceV1>);
static_assert(!C24EmpiricalRowEstimatorSource<
              mwperf::RawResponseEnvelopeV1>);
static_assert(!C24RewardEstimatorSource<mwperf::RawResponseEnvelopeV1>);
static_assert(!C24EmpiricalRowEstimatorSource<
              mwperf::ThreeBinScalarResponseV1>);
static_assert(!C24RewardEstimatorSource<mwperf::ThreeBinScalarResponseV1>);

struct CausalSamplerFixture final {
  mwperf::AuditedCompiledFramework framework;
  mwperf::ResolvedInstance instance;
  mwperf::ReducedStateV1 initial_state;
  std::vector<mwperf::QueueId> ordered_targets;
  mwperf::NormalizedSamplerAccess sampler;
  mwperf::ConditioningState row;
  std::shared_ptr<std::atomic<unsigned>> calls;
};

[[nodiscard]] CausalSamplerFixture seal_causal_sampler(
    matrix::C17TemporalFixtureOverrideV1 override = {},
    const std::uint64_t replications = 11U,
    const mwperf::StatisticalIntervalKindV1 interval =
        mwperf::StatisticalIntervalKindV1::none,
    const mwperf::BackendRouteKindV1 accepted_backend_route =
        mwperf::BackendRouteKindV1::conditional_reward_monte_carlo) {
  if (!override.conditional_sampler_calls) {
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
  }
  const auto calls = override.conditional_sampler_calls;
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, replications, interval, accepted_backend_route,
      [](mwperf::ExactCausalProgramV1&) {});
  const mwperf::ConditioningState row = prepared.initial_state;
  const mwperf::ReducedStateV1 initial_state = prepared.initial_state;
  mwperf::ResolvedInstance instance = prepared.instance;
  auto ordered_targets = prepared.ordered_targets;

  // Candidate construction and F-C17-07 are structural. Neither is allowed
  // to probe a stochastic callback merely to infer normalization or return.
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((sealed ? std::string{}
               : sealed.error().code + ": " + sealed.error().message));
  REQUIRE(sealed);
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  auto framework = std::move(sealed).value();

  auto descriptor = mwperf::audited_sampler_descriptor(framework);
  INFO((descriptor ? std::string{}
                   : descriptor.error().code + ": " +
                         descriptor.error().message));
  REQUIRE(descriptor);
  auto sampler = mwperf::validate_conditional_generator(descriptor.value());
  INFO((sampler ? std::string{}
                : sampler.error().code + ": " + sampler.error().message));
  REQUIRE(sampler);
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  return {std::move(framework), std::move(instance), initial_state,
          std::move(ordered_targets), std::move(sampler).value(), row,
          std::move(calls)};
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                              const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::KernelTransitionV1 residual_atom(
    const mwperf::ConditioningState& state, const std::uint8_t first,
    const std::uint8_t second) {
  const mwperf::CodecIdentityV1 mark_codec{"mwperf.c23.typed_label", 1U};
  return {state,
          {{mark_codec, {static_cast<std::byte>(first)}},
           {mark_codec, {static_cast<std::byte>(second)}},
           {mark_codec, {static_cast<std::byte>(second)}}}};
}

[[nodiscard]] mwperf::ConditionalSamplerContractV1 integration_contract(
    const std::string_view prefix,
    const mwperf::ConditionalSamplerRevealStageV1 reveal_stage,
    const mwperf::ConditionalSampleDependenceV1 dependence,
    const bool prearrival_excludes_fresh_arrival = true) {
  const auto keyed = [prefix](const std::string_view suffix) {
    return matrix::digest(std::string(prefix) + "." + std::string(suffix));
  };
  return {1U,
          reveal_stage,
          dependence,
          mwperf::ConditionalSupportKindV1::finite_declared,
          2U,
          matrix::digest("c17.fixture.reduced-state-schema"),
          keyed("support"),
          keyed("proposal"),
          keyed("residual"),
          keyed("output"),
          keyed("arrival"),
          keyed("common"),
          true,
          true,
          true,
          true,
          prearrival_excludes_fresh_arrival,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerEvidenceScopeV1::construction_enforced,
          mwperf::SamplerV1EvidenceScopeV1::row_conditional,
          keyed("v1"),
          mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
          keyed("v2"),
          keyed("foreign")};
}

[[nodiscard]] matrix::C17TemporalFixtureOverrideV1 residual_override(
    const std::string_view prefix,
    const mwperf::ConditionalSamplerRevealStageV1 reveal_stage,
    const mwperf::ConditionalSampleDependenceV1 dependence,
    const bool paired_records,
    const bool prearrival_excludes_fresh_arrival = true) {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_sampler_contract = integration_contract(
      prefix, reveal_stage, dependence,
      prearrival_excludes_fresh_arrival);
  override.conditional_sampler_operation =
      [paired_records](const mwperf::CanonicalRuntimeValueV1& state,
                       mwperf::DeterministicRng& rng) {
        const std::uint8_t residual =
            static_cast<std::uint8_t>(rng.next_u64() & 1U);
        const std::uint8_t second = paired_records ? residual : 0U;
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            residual_atom(state, residual, second));
      };
  override.conditional_support_enumerator =
      [paired_records](const mwperf::CanonicalRuntimeValueV1& state) {
        return mwperf::Result<std::vector<mwperf::KernelTransitionV1>>::
            success({residual_atom(state, 0U, 0U),
                     residual_atom(state, 1U,
                                   paired_records ? 1U : 0U)});
      };
  override.conditional_support_query =
      [paired_records](const mwperf::CanonicalRuntimeValueV1& state,
                       const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<bool>::success(
            sample == residual_atom(state, 0U, 0U) ||
            sample == residual_atom(state, 1U,
                                    paired_records ? 1U : 0U));
      };
  return override;
}

[[nodiscard]] mwperf::SamplingPlan causal_plan(
    const mwperf::NormalizedSamplerAccess& sampler,
    const std::uint64_t replications = 11U,
    const mwperf::StageTag stage = mwperf::StageTag::generic_sampling,
    const std::string_view estimator_id =
        "c24.integration.residual-row",
    std::optional<mwperf::TotalVariationRequestV1> tv = std::nullopt) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  auto plan = mwperf::SamplingPlan::from_accepted_clause(
      sampler,
      mwperf::SamplingPlanSpecV1{
          {mwperf::BigNat{replications}, rational(19, 20),
           mwperf::StatisticalIntervalKindV1::none,
           mwperf::StatisticalEstimandKindV1::
               point_with_variance_diagnostics,
           mwperf::ExactRational::zero(), mwperf::ExactRational::one()},
          mwperf::MasterSeed{UINT64_C(0xC240401)},
          std::string(estimator_id),
          sampler.accepted_sampling_clauses().front().metric_target_digest,
          mwperf::BigNat{replications}, stage, true, false,
          std::move(tv)});
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  return std::move(plan).value();
}

[[nodiscard]] mwperf::SamplingPlan bounded_reward_plan(
    const mwperf::NormalizedSamplerAccess& sampler,
    const std::uint64_t replications, const mwperf::StageTag stage,
    const std::string_view estimator_id) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  auto plan = mwperf::SamplingPlan::from_accepted_clause(
      sampler,
      mwperf::SamplingPlanSpecV1{
          {mwperf::BigNat{replications}, rational(19, 20),
           mwperf::StatisticalIntervalKindV1::hoeffding,
           mwperf::StatisticalEstimandKindV1::binary_proportion,
           mwperf::ExactRational::zero(), mwperf::ExactRational::one()},
          mwperf::MasterSeed{UINT64_C(0xC240401)},
          std::string(estimator_id),
          sampler.accepted_sampling_clauses().front().metric_target_digest,
          mwperf::BigNat{replications}, stage, true, false, std::nullopt});
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  return std::move(plan).value();
}

[[nodiscard]] mwperf::RewardDecoder residual_indicator_reward(
    const mwperf::Digest256& output_schema,
    const mwperf::Digest256& metric_target_digest) {
  auto conditional =
      std::make_shared<const mwperf::ConditionalSamplingRewardV1>(
          mwperf::ConditionalSamplingRewardV1{
              "c24.integration.explicit-boundary.reward",
              matrix::digest("c24.integration.explicit-boundary.decoder"),
              metric_target_digest,
              output_schema,
              mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
              true,
              mwperf::ExactRational::zero(),
              mwperf::ExactRational::one(),
              [](const mwperf::ConditioningState&,
                 const mwperf::Sample& sample) {
                if (sample.ordered_marks.empty() ||
                    sample.ordered_marks.front().canonical_value.empty()) {
                  return mwperf::Result<long double>::failure(
                      {mwperf::DiagnosticCategory::input_validation,
                       "c24.integration.malformed-indicator",
                       "the residual indicator mark is missing",
                       std::nullopt, std::nullopt, {}});
                }
                return mwperf::Result<long double>::success(
                    static_cast<long double>(
                        std::to_integer<std::uint8_t>(
                            sample.ordered_marks.front()
                                .canonical_value.front())));
              },
              true});
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          {},
          {"c24.integration.reward.scalar", 1U},
          std::move(conditional)};
}

}  // namespace

TEST_CASE("C24 activates only after C17 issues the sealed sampler view",
          "[c24][integration][causal][seal]") {
  const auto trace = std::make_shared<c17::SpyTrace>();
  const auto cplus_arrival_source =
      std::make_shared<std::optional<mwperf::CanonicalRuntimeValueV1>>();
  const auto cminus_output = [] {
    const auto target =
        mwperf::testing::c16_designated_detail::queue("q0");
    return mwperf::CMinusOutputV1{
        {mwperf::CodecIdentityV1{"c17.fixture.temporal.opportunity", 1U},
         {std::byte{0x01U}}},
        {},
        mwperf::V0EmittedOpportunityFaceV1{{
            {{}, {}, mwperf::ExactRational::zero()},
            {{target}, {}, mwperf::ExactRational::zero()}}},
        std::nullopt};
  };
  matrix::C17TemporalFixtureOverrideV1 slot_spy;
  slot_spy.c_minus =
      [trace, cminus_output](const mwperf::CMinusInputV1&,
                             mwperf::DeterministicRng&) {
        trace->enter(mwperf::CausalStageV1::c_minus);
        return mwperf::Result<mwperf::CMinusOutputV1>::success(
            cminus_output());
      };
  // Suppress the fixture's exact enumerator so C17-08 must exercise the
  // sealed sampled C-minus route.  An engaged optional containing an empty
  // callback deliberately replaces the fixture default.
  slot_spy.enumerate_c_minus = mwperf::EnumerateCMinusExactLawV1{};
  slot_spy.c_plus =
      [trace, cplus_arrival_source](const mwperf::CPlusInputV1& input,
                                    mwperf::DeterministicRng&) {
        trace->enter(mwperf::CausalStageV1::c_plus);
        *cplus_arrival_source = input.configured_arrival;
        return mwperf::Result<mwperf::CPlusOutputV1>::success({{}, {}});
      };
  // Likewise force the sampled C-plus route, which receives the one
  // configured-arrival transition produced between resolver and C-plus.
  slot_spy.enumerate_c_plus = mwperf::EnumerateCPlusExactLawV1{};
  auto fixture = seal_causal_sampler(
      std::move(slot_spy), 11U, mwperf::StatisticalIntervalKindV1::none,
      mwperf::BackendRouteKindV1::conditional_row_monte_carlo);
  // V0 is allowed to enumerate exact operation witnesses while sealing.  The
  // following counters are scoped to the public C17-08 execution itself.
  trace->callback_entries.clear();
  trace->arrival_applications = 0U;
  trace->opportunity_applications = 0U;
  trace->resolver_applications = 0U;
  trace->postclosure_applications = 0U;
  cplus_arrival_source->reset();
  CHECK(fixture.calls->load(std::memory_order_relaxed) == 0U);
  CHECK(fixture.sampler.contract().v1_evidence_reference ==
        std::nullopt);
  CHECK(fixture.sampler.contract().v2_evidence_reference ==
        std::nullopt);

  auto exact_row = mwperf::audited_row_provider(fixture.framework);
  REQUIRE_FALSE(exact_row);
  CHECK(exact_row.error().code == "c17.audited_row_unavailable");
  auto slot = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(slot);

  const auto plan = causal_plan(fixture.sampler);
  auto empirical = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  INFO((empirical ? std::string{}
                  : empirical.error().code + ": " +
                        empirical.error().message));
  REQUIRE(empirical);
  CHECK(fixture.calls->load(std::memory_order_relaxed) == 11U);
  CHECK(empirical.value().total() == mwperf::BigNat{11U});
  CHECK(empirical.value().seal_digest() == fixture.sampler.seal_digest());
  REQUIRE(empirical.value().atoms().size() == 1U);
  const auto& residual = empirical.value().atoms().front().sample;
  CHECK(residual.successor_state.codec ==
        fixture.sampler.shape().successor_state_codec);
  REQUIRE(residual.ordered_marks.size() ==
          fixture.sampler.shape().ordered_mark_codecs.size());
  for (std::size_t index = 0U;
       index < residual.ordered_marks.size(); ++index) {
    CHECK(residual.ordered_marks[index].codec ==
          fixture.sampler.shape().ordered_mark_codecs[index]);
  }

  // C24's residual row is never fed back as a completed physical edge. A
  // separate C17-08 call owns resolver/arrival/C-plus/Psi composition and
  // returns the only complete-slot type.
  auto bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{UINT64_C(0xC240402)});
  REQUIRE(bank);
  auto edge = mwperf::execute_reduced_slot(
      slot.value(), fixture.initial_state, bank.value());
  INFO((edge ? std::string{}
             : edge.error().code + ": " + edge.error().message));
  REQUIRE(edge);
  CHECK(edge.value().stage_trace() == mwperf::kCausalStageOrderV1);
  CHECK(fixture.calls->load(std::memory_order_relaxed) == 11U);
  CHECK(trace->opportunity_applications == 1U);
  CHECK(trace->postclosure_applications == 1U);
  CHECK(trace->callback_entries ==
        std::vector{mwperf::CausalStageV1::c_minus,
                    mwperf::CausalStageV1::c_plus});
  REQUIRE(cplus_arrival_source->has_value());
  CHECK(**cplus_arrival_source == edge.value().arrival().canonical_source);

  // C17-08 owns one complete configured-arrival transition.  Every queue
  // projection is read from that same immutable batch; there is no
  // per-projection arrival callback or opportunity for the already-computed
  // C24 empirical row to become a completed slot.
  auto configured_arrival =
      mwperf::detail::CompiledArrivalAccess::get(fixture.instance.arrival());
  REQUIRE(configured_arrival);
  const auto& binding =
      mwperf::arrival_law_binding(*configured_arrival.value());
  std::size_t projection_count = 0U;
  for (std::size_t ordinal = 0U;
       ordinal < fixture.instance.queues().size(); ++ordinal) {
    auto queue = fixture.instance.queues().index_at(ordinal);
    REQUIRE(queue);
    auto projected = mwperf::project_arrival_count(
        edge.value().arrival().batch, queue.value(), binding);
    REQUIRE(projected);
    ++projection_count;
  }
  CHECK(projection_count == fixture.instance.queues().size());
}

TEST_CASE("C17 uses one joint arrival after the common resolver for every target",
          "[c24][integration][causal][multi-target-spy]") {
  const auto& base = c17::math_base();
  std::vector<mwperf::QueueId> targets;
  targets.reserve(base.instance.queues().size());
  for (std::size_t ordinal = 0U;
       ordinal < base.instance.queues().size(); ++ordinal) {
    auto dense = base.instance.queues().index_at(ordinal);
    REQUIRE(dense);
    targets.push_back(base.instance.queues().queue_id(dense.value()));
  }
  REQUIRE(targets.size() == 3U);
  const auto state = c17::reduced_state(targets, {2U, 2U, 2U});
  const auto backlog =
      c17::target_backlog(base.instance, targets, {2U, 2U, 2U});
  const auto trace = std::make_shared<c17::SpyTrace>();
  const auto arrivals_seen_by_cplus =
      std::make_shared<std::vector<mwperf::CanonicalRuntimeValueV1>>();

  mwperf::C17GenericCallbackProgramV1 callbacks{
      [trace, backlog](const mwperf::PreArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_minus);
        return mwperf::Result<
            std::vector<mwperf::OpportunityLawAtomV1>>::success(
            {{{context.branch(), backlog, std::nullopt, std::nullopt,
               c17::value("c24.integration.multi-target-opportunity",
                          {0x01U}),
               {}},
              mwperf::ExactRational::one(), true}});
      },
      {},
      [trace, base_ptr = &base](const mwperf::ResolverContext& context,
                                mwperf::OptimizerExecutionContext&) {
        trace->enter(mwperf::CausalStageV1::resolver);
        return mwperf::Result<
            std::vector<mwperf::ActionLawAtomV1>>::success(
            {{c17::action(*base_ptr, context.opportunity().branch,
                          *context.opportunity().prearrival_backlog,
                          {1U, 0U, 0U}, 0x01U),
              mwperf::ExactRational::one(), true}});
      },
      {},
      [trace, arrivals_seen_by_cplus](
          const mwperf::PostArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_plus);
        arrivals_seen_by_cplus->push_back(
            context.arrival().canonical_source);
        return mwperf::Result<std::vector<
            mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {}, {}},
              mwperf::ExactRational::one(), true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 exact_fixture{
      base.instance,
      base.configured_arrival,
      c17::exact_state_schema(base.instance, targets, base.phase_zero,
                              base.phase_one),
      std::move(program), std::move(callbacks),
      std::move(optimizer).value()};
  mwperf::PlugDescriptor descriptor = base.descriptor;
  descriptor.core.deployed_targets = targets;
  descriptor.core.target_coupling =
      mwperf::TargetCouplingV1::common_schedule_projection;
  descriptor.marks.clear();

  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      exact_fixture, descriptor, state);
  INFO((row ? std::string{}
            : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  // One enumeration of the configured *joint* arrival law has two atoms.  It
  // is not enumerated independently for the three target projections (which
  // would create a Cartesian product).
  REQUIRE(row.value().atoms().size() == 2U);
  CHECK(trace->opportunity_applications == 1U);
  CHECK(trace->resolver_applications == 1U);
  CHECK(trace->postclosure_applications == row.value().atoms().size());
  REQUIRE(trace->callback_entries.size() == 4U);
  CHECK(trace->callback_entries.front() == mwperf::CausalStageV1::c_minus);
  CHECK(trace->callback_entries[1U] == mwperf::CausalStageV1::resolver);
  CHECK(trace->callback_entries[2U] == mwperf::CausalStageV1::c_plus);
  CHECK(trace->callback_entries[3U] == mwperf::CausalStageV1::c_plus);
  REQUIRE(arrivals_seen_by_cplus->size() == row.value().atoms().size());

  const auto& binding =
      mwperf::arrival_law_binding(base.configured_arrival);
  std::vector<std::vector<mwperf::BigNat>> joint_projections;
  for (std::size_t atom_index = 0U;
       atom_index < row.value().atoms().size(); ++atom_index) {
    const auto& atom = row.value().atoms()[atom_index];
    CHECK(atom.edge.stage_trace() == mwperf::kCausalStageOrderV1);
    CHECK(atom.edge.arrival().canonical_source ==
          arrivals_seen_by_cplus->at(atom_index));
    std::vector<mwperf::BigNat> projection;
    projection.reserve(targets.size());
    for (std::size_t target_ordinal = 0U;
         target_ordinal < targets.size(); ++target_ordinal) {
      const auto dense =
          base.instance.queues().index_at(target_ordinal);
      REQUIRE(dense);
      auto count = mwperf::project_arrival_count(
          atom.edge.arrival().batch, dense.value(), binding);
      REQUIRE(count);
      projection.push_back(count.value());
    }
    joint_projections.push_back(std::move(projection));
  }
  REQUIRE(joint_projections.size() == 2U);
  CHECK(joint_projections[0U] != joint_projections[1U]);
}

TEST_CASE("C17 rejects paired prearrival records and retains the fresh-arrival product",
          "[c24][integration][causal][arrival-factorization]") {
  // Replaying the genuine observations (D,A)=(0,0),(1,1) as a prearrival
  // residual would expose the fresh configured arrival before its causal
  // stage.  C17 rejects that contract structurally and never probes it.
  auto paired = residual_override(
      "c24.integration.paired-records",
      mwperf::ConditionalSamplerRevealStageV1::prearrival_residual,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, true,
      false);
  {
    const matrix::ScopedC17TemporalFixtureOverride guard(paired);
    const auto& profile = temporal::temporal_profile(
        mwperf::SemanticTagV1::temporal_one_slot_continuation);
    auto prepared = temporal::prepare_conditional_sampling_framework(
        profile, 64U, mwperf::StatisticalIntervalKindV1::none,
        [](mwperf::ExactCausalProgramV1&) {});
    auto rejected = mwperf::audit_v0_causality(
        std::move(prepared.candidate), prepared.descriptor,
        std::move(prepared.access));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c17.prearrival_sampler_claims_fresh_arrival");
  }
  CHECK(paired.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);

  // A valid deployed sampler exposes D only.  Its empirical row remains a
  // residual row; the configured A law is not copied into its marks.
  auto residual = residual_override(
      "c24.integration.prearrival-residual",
      mwperf::ConditionalSamplerRevealStageV1::prearrival_residual,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, false);
  constexpr std::uint64_t kReplications = 512U;
  auto reward_residual = residual;
  reward_residual.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto sampled = seal_causal_sampler(
      std::move(residual), kReplications,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::BackendRouteKindV1::conditional_row_monte_carlo);
  auto reward_sampled = seal_causal_sampler(
      std::move(reward_residual), kReplications,
      mwperf::StatisticalIntervalKindV1::hoeffding);
  const auto plan = causal_plan(
      sampled.sampler, kReplications,
      mwperf::StageTag::prearrival_closure,
      "c24.integration.explicit-boundary",
      mwperf::TotalVariationRequestV1{0.1L, 0.05L, 1U});
  auto empirical = mwperf::estimate_discrete_kernel_row(
      sampled.sampler, sampled.row, plan);
  REQUIRE(empirical);
  REQUIRE(empirical.value().atoms().size() == 2U);
  REQUIRE(empirical.value().total_variation_bound().has_value());
  CHECK(empirical.value().total_variation_bound()->controls ==
        mwperf::SamplingClaimScopeV1::row_conditional_surrogate);
  mwperf::ExactRational residual_one_mass =
      mwperf::ExactRational::zero();
  for (const auto& atom : empirical.value().atoms()) {
    REQUIRE(atom.sample.ordered_marks.size() == 3U);
    REQUIRE_FALSE(atom.sample.ordered_marks[0U].canonical_value.empty());
    REQUIRE_FALSE(atom.sample.ordered_marks[1U].canonical_value.empty());
    const auto d = std::to_integer<std::uint8_t>(
        atom.sample.ordered_marks[0U].canonical_value.front());
    const auto copied_arrival = std::to_integer<std::uint8_t>(
        atom.sample.ordered_marks[1U].canonical_value.front());
    CHECK(copied_arrival == 0U);
    if (d == 1U) residual_one_mass = atom.probability;
  }
  // This fixed, predeclared seed/budget is one deterministic conformance
  // fixture for the authored TV procedure, not an empirical proof of it.
  CHECK(residual_one_mass >= rational(2, 5));
  CHECK(residual_one_mass <= rational(3, 5));

  const auto reward = residual_indicator_reward(
      reward_sampled.sampler.contract().output_schema,
      reward_sampled.sampler.accepted_sampling_clauses()
          .front()
          .metric_target_digest);
  const auto reward_plan = bounded_reward_plan(
      reward_sampled.sampler, kReplications,
      mwperf::StageTag::prearrival_closure,
      "c24.integration.explicit-boundary");
  auto estimate = mwperf::estimate_reward_expectation(
      reward_sampled.sampler, reward_sampled.row, reward, reward_plan);
  REQUIRE(estimate);
  REQUIRE(estimate.value().interval().has_value());
  CHECK(estimate.value().claim_scope() ==
        mwperf::SamplingClaimScopeV1::row_conditional_surrogate);
  CHECK(estimate.value().value() >= 0.4L);
  CHECK(estimate.value().value() <= 0.6L);
  CHECK(estimate.value().interval()->lower <= 0.5L);
  CHECK(estimate.value().interval()->upper >= 0.5L);

  // C17, not C24, owns the cross product with one fresh configured arrival.
  // The existing exact C17 fixture has two configured-arrival atoms of mass
  // 1/2.  Crossing those with the same two-point D law produces all four
  // combinations with exact mass 1/4; paired replay would produce only two.
  const auto& base = c17::math_base();
  const auto state = c17::reduced_state(base, {2U});
  const auto backlog = c17::target_backlog(base, {2U});
  const auto half = rational(1, 2);
  mwperf::C17GenericCallbackProgramV1 callbacks{
      [backlog, half](const mwperf::PreArrivalContext& context) {
        return mwperf::Result<
            std::vector<mwperf::OpportunityLawAtomV1>>::success(
            {{{context.branch(), backlog, std::nullopt, std::nullopt,
               c17::value("c24.integration.residual-d", {0x00U}), {}},
              half, true},
             {{context.branch(), backlog, std::nullopt, std::nullopt,
               c17::value("c24.integration.residual-d", {0x01U}), {}},
              half, true}});
      },
      {},
      [base_ptr = &base](const mwperf::ResolverContext& context,
                          mwperf::OptimizerExecutionContext&) {
        const auto& encoded =
            context.opportunity().opportunity.canonical_value;
        const bool departure =
            !encoded.empty() && encoded.front() == std::byte{0x01U};
        return mwperf::Result<
            std::vector<mwperf::ActionLawAtomV1>>::success(
            {{c17::action(*base_ptr, context.opportunity().branch,
                          *context.opportunity().prearrival_backlog,
                          {static_cast<std::uint8_t>(departure ? 1U : 0U),
                           std::uint8_t{0U}, std::uint8_t{0U}},
                          departure ? 0x01U : 0x00U),
              mwperf::ExactRational::one(), true}});
      },
      {},
      [](const mwperf::PostArrivalContext& context) {
        return mwperf::Result<std::vector<
            mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {}, {}},
              mwperf::ExactRational::one(), true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 exact_program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 exact_fixture{
      base.instance, base.configured_arrival, c17::exact_state_schema(base),
      std::move(exact_program), std::move(callbacks),
      std::move(optimizer).value()};
  mwperf::PlugDescriptor unmarked = base.descriptor;
  unmarked.marks.clear();
  auto product = mwperf::testing::C17FixtureAccess::compose_generic(
      exact_fixture, unmarked, state);
  INFO((product ? std::string{}
                : product.error().code + ": " + product.error().message));
  REQUIRE(product);
  REQUIRE(product.value().atoms().size() == 4U);
  const auto q0 = base.instance.queues().index_at(0U);
  REQUIRE(q0);
  const auto& arrival_binding =
      mwperf::arrival_law_binding(base.configured_arrival);
  std::array<bool, 4U> combinations{};
  for (const auto& atom : product.value().atoms()) {
    CHECK(atom.exact_mass == rational(1, 4));
    CHECK(atom.edge.stage_trace() == mwperf::kCausalStageOrderV1);
    auto arrival = mwperf::project_arrival_count(
        atom.edge.arrival().batch, q0.value(), arrival_binding);
    REQUIRE(arrival);
    const bool departure = atom.edge.action().actual_departure.at(q0.value());
    const bool second_arrival_atom = arrival.value() == mwperf::BigNat{3U};
    CHECK((arrival.value() == mwperf::BigNat{1U} ||
           second_arrival_atom));
    combinations[(departure ? 2U : 0U) +
                 (second_arrival_atom ? 1U : 0U)] = true;
  }
  for (const bool observed : combinations) CHECK(observed);
}

TEST_CASE("C17 rejects hidden sampler memory and C24 preserves correlated evidence",
          "[c24][integration][state][provenance]") {
  auto hidden = residual_override(
      "c24.integration.hidden-state",
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, false);
  const auto hidden_bit = std::make_shared<bool>(false);
  hidden.conditional_sampler_operation =
      [hidden_bit](const mwperf::CanonicalRuntimeValueV1& state,
                   mwperf::DeterministicRng&) {
        *hidden_bit = !*hidden_bit;
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            residual_atom(state, *hidden_bit ? 1U : 0U, 0U));
      };
  hidden.conditional_sampler_contract->persistent_memory_is_explicit = false;
  {
    const matrix::ScopedC17TemporalFixtureOverride guard(hidden);
    const auto& profile = temporal::temporal_profile(
        mwperf::SemanticTagV1::temporal_one_slot_continuation);
    auto prepared = temporal::prepare_conditional_sampling_framework(
        profile, 64U, mwperf::StatisticalIntervalKindV1::none,
        [](mwperf::ExactCausalProgramV1&) {});
    auto rejected = mwperf::audit_v0_causality(
        std::move(prepared.candidate), prepared.descriptor,
        std::move(prepared.access));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c17.incomplete_conditional_sampler_contract");
  }
  CHECK(hidden.conditional_sampler_calls->load(
            std::memory_order_relaxed) == 0U);
  CHECK_FALSE(*hidden_bit);

  auto correlated = residual_override(
      "c24.integration.correlated-modified",
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
      mwperf::ConditionalSampleDependenceV1::correlated_trace, false);
  auto expected_contract = *correlated.conditional_sampler_contract;
  auto fixture = seal_causal_sampler(
      std::move(correlated), 19U,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::BackendRouteKindV1::conditional_row_monte_carlo);
  // The generic C17 fixture replaces its authored placeholder with the
  // scenario's actual compiled-arrival fingerprint before V0 sealing.
  expected_contract.configured_arrival_law =
      fixture.sampler.contract().configured_arrival_law;
  CHECK(fixture.sampler.contract() == expected_contract);
  CHECK(fixture.sampler.contract().v1_evidence_reference ==
        expected_contract.v1_evidence_reference);
  CHECK(fixture.sampler.contract().v2_evidence_reference ==
        expected_contract.v2_evidence_reference);
  CHECK(fixture.sampler.contract().foreign_construction_evidence ==
        expected_contract.foreign_construction_evidence);
  CHECK(fixture.sampler.contract().normalization_evidence ==
        mwperf::SamplerEvidenceScopeV1::declared);
  CHECK(fixture.sampler.contract().termination_evidence ==
        mwperf::SamplerEvidenceScopeV1::construction_enforced);

  const auto modified_row =
      c17::reduced_state(fixture.ordered_targets, {2U}, true, 5U);
  const auto plan = causal_plan(
      fixture.sampler, 19U, mwperf::StageTag::generic_sampling,
      "c24.integration.correlated-modified");
  auto row = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, modified_row, plan);
  REQUIRE(row);
  CHECK_FALSE(row.value().iid_replications());
  CHECK_FALSE(row.value().total_variation_bound().has_value());
  CHECK_FALSE(row.value().advertised_tv_failure_bound().has_value());
  for (const auto& atom : row.value().atoms()) {
    CHECK(atom.sample.successor_state == modified_row);
  }
  // The static exclusions at the top of this file prove that neither this
  // modified-state row nor any evidence reference can mint a slot, temporal,
  // stopped, Palm, or FIFO authority.
}

TEST_CASE("declared persistent state is threaded explicitly and replays row and reward draws",
          "[c24][integration][state][replay]") {
  auto explicit_memory = residual_override(
      "c24.integration.explicit-state",
      mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
      mwperf::ConditionalSampleDependenceV1::iid_cold_replications, false);

  // The fixture's final reduced-state byte is a declared boundary coordinate.
  // Use its low bit as the persistent generator bit: every draw derives the
  // successor solely from the supplied row and therefore owns no warm object
  // state between addressed invocations.
  const auto toggle_explicit_bit =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        mwperf::CanonicalRuntimeValueV1 successor = state;
        if (!successor.canonical_value.empty()) {
          const auto bit = std::to_integer<std::uint8_t>(
                               successor.canonical_value.back()) &
                           1U;
          successor.canonical_value.back() =
              static_cast<std::byte>(bit == 0U ? 1U : 0U);
        }
        return successor;
      };
  explicit_memory.conditional_sampler_operation =
      [toggle_explicit_bit](const mwperf::CanonicalRuntimeValueV1& state,
                            mwperf::DeterministicRng& rng) {
        const auto residual =
            static_cast<std::uint8_t>(rng.next_u64() & 1U);
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            residual_atom(toggle_explicit_bit(state), residual, 0U));
      };
  explicit_memory.conditional_support_enumerator =
      [toggle_explicit_bit](const mwperf::CanonicalRuntimeValueV1& state) {
        const auto successor = toggle_explicit_bit(state);
        return mwperf::Result<std::vector<mwperf::KernelTransitionV1>>::
            success({residual_atom(successor, 0U, 0U),
                     residual_atom(successor, 1U, 0U)});
      };
  explicit_memory.conditional_support_query =
      [toggle_explicit_bit](const mwperf::CanonicalRuntimeValueV1& state,
                            const mwperf::KernelTransitionV1& sample) {
        const auto successor = toggle_explicit_bit(state);
        return mwperf::Result<bool>::success(
            sample == residual_atom(successor, 0U, 0U) ||
            sample == residual_atom(successor, 1U, 0U));
      };

  auto reward_memory = explicit_memory;
  reward_memory.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  auto fixture = seal_causal_sampler(
      std::move(explicit_memory), 31U,
      mwperf::StatisticalIntervalKindV1::none,
      mwperf::BackendRouteKindV1::conditional_row_monte_carlo);
  auto reward_fixture = seal_causal_sampler(
      std::move(reward_memory), 31U,
      mwperf::StatisticalIntervalKindV1::hoeffding);
  const auto row_zero =
      c17::reduced_state(fixture.ordered_targets, {2U}, false, 0U);
  const auto expected_row_one =
      c17::reduced_state(fixture.ordered_targets, {2U}, false, 1U);
  const auto row_plan = causal_plan(
      fixture.sampler, 31U, mwperf::StageTag::generic_sampling,
      "c24.integration.explicit-state-row");

  auto zero_first = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, row_zero, row_plan);
  auto zero_replay = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, row_zero, row_plan);
  REQUIRE(zero_first);
  REQUIRE(zero_replay);
  REQUIRE(zero_first.value().atoms().size() ==
          zero_replay.value().atoms().size());
  REQUIRE_FALSE(zero_first.value().atoms().empty());
  for (std::size_t index = 0U;
       index < zero_first.value().atoms().size(); ++index) {
    const auto& first = zero_first.value().atoms()[index];
    const auto& replay = zero_replay.value().atoms()[index];
    CHECK(first.sample == replay.sample);
    CHECK(first.count == replay.count);
    CHECK(first.probability == replay.probability);
    CHECK(first.sample.successor_state == expected_row_one);
  }

  // Thread the returned persistent coordinate into the next row explicitly.
  // A second replay from that row must toggle back to the original state.
  const auto threaded_row =
      zero_first.value().atoms().front().sample.successor_state;
  REQUIRE(threaded_row == expected_row_one);
  auto one_first = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, threaded_row, row_plan);
  auto one_replay = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, threaded_row, row_plan);
  REQUIRE(one_first);
  REQUIRE(one_replay);
  REQUIRE(one_first.value().atoms().size() ==
          one_replay.value().atoms().size());
  for (std::size_t index = 0U;
       index < one_first.value().atoms().size(); ++index) {
    const auto& first = one_first.value().atoms()[index];
    const auto& replay = one_replay.value().atoms()[index];
    CHECK(first.sample == replay.sample);
    CHECK(first.count == replay.count);
    CHECK(first.probability == replay.probability);
    CHECK(first.sample.successor_state == row_zero);
  }

  const auto reward = residual_indicator_reward(
      reward_fixture.sampler.contract().output_schema,
      reward_fixture.sampler.accepted_sampling_clauses()
          .front()
          .metric_target_digest);
  const auto reward_plan = bounded_reward_plan(
      reward_fixture.sampler, 31U,
      mwperf::StageTag::generic_sampling,
      "c24.integration.explicit-state-reward");
  auto reward_first = mwperf::estimate_reward_expectation(
      reward_fixture.sampler, row_zero, reward, reward_plan);
  auto reward_replay = mwperf::estimate_reward_expectation(
      reward_fixture.sampler, row_zero, reward, reward_plan);
  REQUIRE(reward_first);
  REQUIRE(reward_replay);
  CHECK(reward_first.value().value() == reward_replay.value().value());
  CHECK(reward_first.value().sample_variance() ==
        reward_replay.value().sample_variance());
  CHECK(std::ranges::equal(reward_first.value().raw_rewards(),
                           reward_replay.value().raw_rewards()));
}

TEST_CASE("offline sampled analytic profiles cannot activate C24",
          "[c24][integration][dispatch][offline-sampling]") {
  constexpr std::size_t kFirstProfile = 4U;
  constexpr std::size_t kProfileCount = 6U;
  const auto profiles =
      std::span(mwperf::testing::kC16TestProfiles)
          .subspan(kFirstProfile, kProfileCount);
  REQUIRE(profiles.size() == kProfileCount);

  std::size_t sampled_offline_count = 0U;
  std::vector<mwperf::Digest256> manifest_provenance;
  std::vector<mwperf::ProviderScientificContractDigest>
      scientific_provenance;
  std::vector<mwperf::StationaryAnalyticLawIdentityV1> iid_identities;
  manifest_provenance.reserve(profiles.size());
  scientific_provenance.reserve(profiles.size());
  iid_identities.reserve(profiles.size());
  for (const auto& profile : profiles) {
    INFO(profile.provider_id);
    sampled_offline_count +=
        profile.construction_method ==
                mwperf::ConstructionMethodV1::sampled_offline
            ? 1U
            : 0U;

    // Inspect the actual statically registered C16 profile, rather than a
    // locally restated look-alike identity.  Construction method remains
    // immutable scientific provenance; all dispatch-bearing fields remain
    // the analytic scalar carrier shared by these six fixtures.
    auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
    REQUIRE(id);
    auto provider = mwperf::lookup_surrogate_provider(id.value());
    INFO((provider ? std::string{}
                   : provider.error().code + ": " +
                         provider.error().message));
    REQUIRE(provider);
    const auto& validated_manifest = provider.value().manifest();
    const auto& manifest = validated_manifest.value();
    CHECK(provider.value().identity() == manifest.provider);
    CHECK(manifest.provider.provider_id == profile.provider_id);
    CHECK(manifest.construction_method == profile.construction_method);
    CHECK(manifest.deployed_semantic_tag ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(manifest.runtime_access_tag ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    CHECK(manifest.payload_class.tag ==
          mwperf::PayloadClassTagV1::three_bin_scalar_response_v1);
    REQUIRE(manifest.optimizer_constraint_applicability
                .scheduler_optimizer_pairs.size() == 1U);
    CHECK((manifest.optimizer_constraint_applicability
               .scheduler_optimizer_pairs.front() ==
           mwperf::SchedulerConstraintPairV1{profile.family,
                                             profile.optimizer}));

    REQUIRE(manifest.metric_clause_upper_envelope.clauses().size() == 1U);
    const auto& clause =
        manifest.metric_clause_upper_envelope.clauses().front();
    CHECK(clause.semantic ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(clause.runtime_access ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    CHECK(clause.payload_class.tag ==
          mwperf::PayloadClassTagV1::three_bin_scalar_response_v1);
    CHECK(clause.solver_route == mwperf::SolverRegimeV1::analytic);
    CHECK(clause.phase_domain.payload_phase ==
          mwperf::PayloadPhaseKindV1::phase_free);
    CHECK(clause.phase_domain.arrival_composition ==
          mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition);
    CHECK_FALSE(clause.phase_domain.retains_configured_predictive_phase);

    const auto& scientific = validated_manifest.scientific_projection();
    CHECK(scientific.provider == manifest.provider);
    CHECK(scientific.construction_method == profile.construction_method);
    CHECK(scientific.deployed_semantic_tag ==
          manifest.deployed_semantic_tag);
    CHECK(scientific.runtime_access_tag == manifest.runtime_access_tag);
    CHECK(scientific.payload_class == manifest.payload_class);
    CHECK(scientific.metric_clause_upper_envelope ==
          manifest.metric_clause_upper_envelope);
    manifest_provenance.push_back(manifest.manifest_digest);
    scientific_provenance.push_back(
        validated_manifest.scientific_contract_digest());

    // Execute the actual registered provider under the IID contract, cross
    // the C15/C16 artifact boundary, seal it through C17, and invoke C19's
    // public analytic route.  No name or ConstructionMethod dispatch is
    // involved: the final semantic/access pair selects this route.
    auto iid_scenario = profile_route::accepted_profile_scenario(
        profile, profile_route::ArrivalMode::exact_iid);
    CHECK(iid_scenario.contract.construction_method() ==
          profile.construction_method);
    CHECK(iid_scenario.contract.semantic() ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(iid_scenario.contract.runtime_access() ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    REQUIRE(iid_scenario.contract.metric_contracts().size() == 1U);
    CHECK(iid_scenario.contract.metric_contracts().front().backend_route ==
          mwperf::BackendRouteKindV1::analytic_metric_family);

    auto iid_flow = profile_route::run_profile_flow(iid_scenario);
    CHECK(iid_flow.artifact.value().construction_method ==
          profile.construction_method);
    CHECK(iid_flow.artifact.value().runtime_access ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    const auto* iid_payload =
        std::get_if<mwperf::ThreeBinScalarResponseV1>(
            &iid_flow.artifact.value().payload);
    REQUIRE(iid_payload != nullptr);
    const auto iid_identifications = iid_payload->raw_response.identifications;
    const auto iid_bands = iid_payload->raw_envelopes;

    auto iid_framework =
        profile_route::audit_profile(iid_scenario, std::move(iid_flow));
    auto iid_response = mwperf::audited_three_bin_response(iid_framework);
    REQUIRE(iid_response);
    for (const auto& [level, expected] :
         std::array<std::pair<std::uint64_t, mwperf::ExactRational>, 3U>{
             std::pair{1U, rational(1, 4)},
             std::pair{2U, rational(3, 4)},
             std::pair{3U, rational(1, 2)}}) {
      auto coefficient = iid_response.value().service_probability(
          mwperf::BigNat{level});
      REQUIRE(coefficient);
      CHECK(coefficient.value() == expected);
    }
    auto iid_sampler = mwperf::audited_sampler_descriptor(iid_framework);
    REQUIRE_FALSE(iid_sampler);
    CHECK(iid_sampler.error().code ==
          "c17.audited_sampler_descriptor_unavailable");
    auto iid_arrival = mwperf::ArrivalLaw::from_audited(iid_response.value());
    INFO((iid_arrival ? std::string{}
                      : iid_arrival.error().code + ": " +
                            iid_arrival.error().message));
    REQUIRE(iid_arrival);
    auto summary = mwperf::summarize_three_bin_iid_response(
        iid_response.value(), iid_arrival.value());
    INFO((summary ? std::string{}
                  : summary.error().code + ": " + summary.error().message));
    REQUIRE(summary);
    CHECK(summary.value().status() ==
          mwperf::AnalyticStationaryStatusV1::
              finite_closed_tail_unreachable);
    REQUIRE(summary.value().exact_mean_backlog().has_value());
    CHECK(summary.value().exact_mean_backlog()->is_zero());
    CHECK(summary.value().law_identity().artifact().construction_method ==
          profile.construction_method);
    iid_identities.push_back(summary.value().law_identity());

    // Execute the same registered identity under a genuinely temporal C09
    // law.  Its accepted contract selects C17's residence/stopped temporal
    // execution route; the deployed response remains phase-free analytic and
    // cannot be reinterpreted as either IID input or a C24 generator.
    auto temporal_scenario = profile_route::accepted_profile_scenario(
        profile, profile_route::ArrivalMode::supported_temporal);
    CHECK(temporal_scenario.contract.construction_method() ==
          profile.construction_method);
    CHECK(temporal_scenario.contract.semantic() ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(temporal_scenario.contract.runtime_access() ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    REQUIRE(temporal_scenario.contract.metric_contracts().size() == 1U);
    CHECK(temporal_scenario.contract.metric_contracts().front().backend_route ==
          mwperf::BackendRouteKindV1::residence_or_stopped_law);

    auto temporal_flow = profile_route::run_profile_flow(temporal_scenario);
    CHECK(temporal_flow.artifact.value().construction_method ==
          profile.construction_method);
    const auto* temporal_payload =
        std::get_if<mwperf::ThreeBinScalarResponseV1>(
            &temporal_flow.artifact.value().payload);
    REQUIRE(temporal_payload != nullptr);
    REQUIRE(temporal_payload->raw_response.identifications.size() ==
            iid_identifications.size());
    for (std::size_t index = 0U; index < iid_identifications.size(); ++index) {
      CHECK(temporal_payload->raw_response.identifications[index].raw_point ==
            iid_identifications[index].raw_point);
      CHECK(temporal_payload->raw_response.identifications[index]
                .coefficient_status ==
            iid_identifications[index].coefficient_status);
      CHECK(temporal_payload->raw_response.identifications[index]
                .proposal_conditioning ==
            iid_identifications[index].proposal_conditioning);
    }
    // Any fixture-authored construction envelope is immutable across runtime
    // route selection.  The current six legacy profiles author an empty
    // envelope vector; equality still guards against C24 synthesizing one.
    CHECK(temporal_payload->raw_envelopes == iid_bands);

    auto temporal_framework = profile_route::audit_profile(
        temporal_scenario, std::move(temporal_flow));
    auto temporal_response =
        mwperf::audited_three_bin_response(temporal_framework);
    REQUIRE(temporal_response);
    auto temporal_sampler =
        mwperf::audited_sampler_descriptor(temporal_framework);
    REQUIRE_FALSE(temporal_sampler);
    CHECK(temporal_sampler.error().code ==
          "c17.audited_sampler_descriptor_unavailable");
    auto false_iid =
        mwperf::ArrivalLaw::from_audited(temporal_response.value());
    REQUIRE_FALSE(false_iid);
    CHECK(false_iid.error().code.find("iid") != std::string::npos);

    auto row_provider = mwperf::audited_row_provider(temporal_framework);
    REQUIRE(row_provider);
    const std::vector<mwperf::QueueId> temporal_targets(
        temporal_scenario.view.target_selection().ordered_targets.begin(),
        temporal_scenario.view.target_selection().ordered_targets.end());
    const auto temporal_state =
        c17::reduced_state(temporal_targets, {2U});
    auto temporal_row = mwperf::compile_reduced_kernel_row(
        row_provider.value(), temporal_state);
    REQUIRE(temporal_row);
    CHECK(temporal_row.value().exact_total_mass() ==
          mwperf::ExactRational::one());
    REQUIRE_FALSE(temporal_row.value().atoms().empty());
    auto slot = mwperf::audited_slot_executor(temporal_framework);
    REQUIRE(slot);
    auto bank = mwperf::RngBank::for_physical_reference(
        temporal_scenario.instance,
        mwperf::MasterSeed{UINT64_C(0xC240900)});
    REQUIRE(bank);
    auto edge = mwperf::execute_reduced_slot(
        slot.value(), temporal_state, bank.value());
    REQUIRE(edge);
    CHECK(edge.value().stage_trace() == mwperf::kCausalStageOrderV1);

    // A metric outside the profile's scalar-response envelope is rejected by
    // C14 while the real provider remains cold.  Temporal arrival dependence
    // cannot change the response semantic/access or activate C24.
    auto unsupported = profile_route::negotiate_profile_metric(
        profile, profile_route::ArrivalMode::supported_temporal,
        R"json({"id":"throughput","kind":"service_autocovariance","parameters":{"lags":[1]}})json");
    REQUIRE_FALSE(mwperf::capability_decision_is_accepted(unsupported));
    const auto* rejection =
        mwperf::rejected_capability_decision(unsupported);
    REQUIRE(rejection != nullptr);
    REQUIRE_FALSE(rejection->ordered_failures.empty());
  }
  CHECK(sampled_offline_count == 3U);

  // C24 does not erase or rewrite construction provenance while deciding
  // whether the final deployed access is a runtime sampler.
  for (std::size_t left = 0U; left < profiles.size(); ++left) {
    for (std::size_t right = left + 1U; right < profiles.size(); ++right) {
      CHECK(manifest_provenance[left] != manifest_provenance[right]);
      CHECK(scientific_provenance[left] != scientific_provenance[right]);
      CHECK(iid_identities[left] != iid_identities[right]);
    }
  }
}

TEST_CASE("a sampler-looking analytic provider name cannot activate C24",
          "[c24][integration][negative][dispatch][provider-name]") {
  const mwperf::testing::C16TestProfileV1 profile{
      "c24.fixture.analytic_sampler",
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::sampled_offline};
  REQUIRE(profile.provider_id.ends_with("_sampler"));
  REQUIRE(profile.construction_method ==
          mwperf::ConstructionMethodV1::sampled_offline);

  auto registration = mwperf::testing::c16_profile_registration(
      mwperf::testing::c16_test_manifest(
          std::string(profile.provider_id), profile.family, profile.optimizer,
          profile.construction_method,
          mwperf::ProducerModeV1::in_process_builder));
  auto registry = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {std::move(registration)});
  REQUIRE(registry);
  auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = mwperf::detail::lookup_in_surrogate_registry(
      registry.value(), id.value(), std::nullopt);
  REQUIRE(provider);
  CHECK(provider.value().identity().provider_id == profile.provider_id);
  CHECK(provider.value().manifest().value().deployed_semantic_tag ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(provider.value().manifest().value().runtime_access_tag ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);

  // The private registry proves that the misleading name is a valid provider
  // identity but grants no executable authority.  Exercise the same final
  // semantic/access/construction tuple through an existing registered
  // sampled-offline fixture: C17 dispatch observes only that final tuple.
  const auto& executable_profile = mwperf::testing::kC16TestProfiles.at(5U);
  REQUIRE(executable_profile.construction_method ==
          profile.construction_method);
  auto scenario = profile_route::accepted_profile_scenario(
      executable_profile, profile_route::ArrivalMode::exact_iid);
  REQUIRE(scenario.contract.metric_contracts().size() == 1U);
  CHECK(scenario.contract.metric_contracts().front().backend_route ==
        mwperf::BackendRouteKindV1::analytic_metric_family);
  auto flow = profile_route::run_profile_flow(scenario);
  CHECK(flow.artifact.value().construction_method ==
        mwperf::ConstructionMethodV1::sampled_offline);
  CHECK(flow.artifact.value().runtime_access ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  auto framework = profile_route::audit_profile(scenario, std::move(flow));

  auto response = mwperf::audited_three_bin_response(framework);
  REQUIRE(response);
  auto sampler = mwperf::audited_sampler_descriptor(framework);
  REQUIRE_FALSE(sampler);
  CHECK(sampler.error().code ==
        "c17.audited_sampler_descriptor_unavailable");
}

TEST_CASE("offline context-bank and confidence-band carriers stay analytic",
          "[c24][integration][negative][dispatch][construction-evidence]") {
  using Stage = mwperf::testing::C16DesignatedResponseStageV1;
  auto options =
      mwperf::testing::c16_designated_payload_options_v1(Stage::nominal);
  auto& sampled = options.coefficient_statuses.at(1U);
  sampled.source = mwperf::ProposalConditioningSourceV1::empirical_average;
  sampled.population =
      mwperf::PopulationConditioningStatusV1::positive_with_confidence;
  sampled.raw = mwperf::RawValueStatusV1::interval_only;
  sampled.raw_point = std::nullopt;
  sampled.completion_policy =
      mwperf::testing::c16_designated_detail::object(
          "c16.designated.completion-policy");

  auto scenario = mwperf::testing::make_c16_designated_scenario_v1(
      Stage::nominal);
  auto response = mwperf::testing::make_c16_designated_response_v1(
      scenario, options);
  REQUIRE(response.raw_envelopes.size() == 1U);
  // The C16 helper uses an interval origin to allocate a typed raw-envelope
  // carrier.  C24 is testing that retained offline construction evidence does
  // not change analytic runtime access, so keep that carrier while restoring
  // the validated response ledger to its exact-population point product.
  auto& band_origin = response.raw_response.identifications.at(1U);
  band_origin.proposal_conditioning.source =
      mwperf::ProposalConditioningSourceV1::exact_population;
  band_origin.proposal_conditioning.frozen_evaluation_id = std::nullopt;
  band_origin.coefficient_status.population_conditioning_status =
      mwperf::PopulationConditioningStatusV1::proved_positive;
  band_origin.coefficient_status.raw_value_status =
      mwperf::RawValueStatusV1::exact_point;
  band_origin.raw_point =
      mwperf::testing::c16_designated_detail::scalar(3, 4);
  band_origin.completion_policy_id = std::nullopt;
  response.raw_envelopes.front().coverage =
      mwperf::RawEnvelopeCoverageV1::marginal;
  response.raw_envelopes.front().sample_size = mwperf::BigNat{64U};
  mwperf::testing::reseal_c16_designated_response_graph_v1(response);
  auto artifact = mwperf::testing::rebuild_c16_designated_artifact_v1(
      scenario, std::move(response));
  auto* artifact_response =
      std::get_if<mwperf::ThreeBinScalarResponseV1>(&artifact.payload);
  REQUIRE(artifact_response != nullptr);
  auto& identification =
      artifact_response->raw_response.identifications.at(1U);
  auto& raw_band = artifact_response->raw_envelopes.front();
  REQUIRE(identification.family_evidence_envelope_ids.size() == 1U);
  REQUIRE(raw_band.family_evidence_envelope_ids.size() == 1U);
  REQUIRE(identification.family_evidence_envelope_ids.front().object_id ==
          raw_band.family_evidence_envelope_ids.front().object_id);

  const auto family_body = mwperf::testing::c16_designated_detail::bytes(
      R"json({"claim":"c24-offline-empirical-context-band"})json");
  auto family_body_digest =
      mwperf::artifact::detail::family_evidence_body_digest_v1(family_body);
  REQUIRE(family_body_digest);
  mwperf::FamilyEvidenceEnvelopeV1 construction_evidence{
      1U,
      identification.family_evidence_envelope_ids.front(),
      "c16.fixture.evidence",
      1U,
      mwperf::testing::c16_designated_detail::conformance(scenario),
      scenario.provider.identity(),
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.request.request_digest().value(),
      artifact.payload_digest,
      {identification.coefficient_id, raw_band.envelope_id},
      {artifact_response->raw_response.product_id.identity()},
      std::vector<mwperf::QueueId>(
          scenario.contract.construction_target_scope().begin(),
          scenario.contract.construction_target_scope().end()),
      mwperf::MetricEvidenceScopeV1::raw_static_proposal,
      family_body,
      std::move(family_body_digest).value()};
  std::ranges::sort(construction_evidence.subject_references);
  auto construction_evidence_digest =
      mwperf::artifact::detail::family_evidence_envelope_digest_v1(
          construction_evidence);
  REQUIRE(construction_evidence_digest);
  construction_evidence.evidence_id.object_digest =
      std::move(construction_evidence_digest).value();
  identification.family_evidence_envelope_ids.front() =
      construction_evidence.evidence_id;
  raw_band.family_evidence_envelope_ids.front() =
      construction_evidence.evidence_id;
  artifact.family_evidence.push_back(construction_evidence);
  std::ranges::sort(artifact.family_evidence, {},
                    &mwperf::FamilyEvidenceEnvelopeV1::evidence_id);
  const auto rebound_payload_digest =
      mwperf::canonical_artifact_payload_digest_v1(artifact.payload);
  REQUIRE(rebound_payload_digest);
  REQUIRE(rebound_payload_digest.value() == artifact.payload_digest);
  const auto expected_bands = artifact_response->raw_envelopes;
  artifact.provenance.frozen_input_bank_id =
      mwperf::testing::c16_designated_detail::label(
          "c24.offline-evidence.empirical-context-bank");
  artifact.provenance.proposal_id =
      mwperf::testing::c16_designated_detail::label(
          "c16.designated.proposal");
  artifact.provenance.final_evaluation_id =
      mwperf::testing::c16_designated_detail::label(
          "c16.designated.status-evaluation");
  artifact.provenance.method_decisions.push_back(
      "offline empirical numerator/denominator context bank retained as "
      "construction evidence only");

  auto carried =
      mwperf::testing::validate_and_adapt_c16_designated_artifact_v1(
          scenario, artifact);
  INFO((carried ? std::string{}
                : carried.error().code + ": " + carried.error().message));
  REQUIRE(carried);
  REQUIRE(carried.value().artifact.value().provenance.frozen_input_bank_id ==
          artifact.provenance.frozen_input_bank_id);
  REQUIRE(carried.value().artifact.value().provenance.proposal_id ==
          artifact.provenance.proposal_id);
  const auto* validated_response =
      std::get_if<mwperf::ThreeBinScalarResponseV1>(
          &carried.value().artifact.value().payload);
  REQUIRE(validated_response != nullptr);
  CHECK(validated_response->raw_envelopes == expected_bands);
  const auto* portable_response =
      std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
          &carried.value().payload.value());
  REQUIRE(portable_response != nullptr);
  CHECK(portable_response->normalized_record.raw_envelopes == expected_bands);

  auto plug = mwperf::materialize_and_validate_surrogate_plug(
      carried.value().payload, carried.value().artifact, scenario.contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  auto access = mwperf::validate_kernel_access(plug.value());
  REQUIRE(access);
  CHECK(mwperf::runtime_access_tag_v1(access.value()) ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  profile_route::ProfileFlow flow{
      carried.value().artifact, carried.value().payload,
      std::move(plug).value(), std::move(access).value()};
  auto framework = profile_route::audit_profile(scenario, std::move(flow));

  auto analytic = mwperf::audited_three_bin_response(framework);
  REQUIRE(analytic);
  auto sampler = mwperf::audited_sampler_descriptor(framework);
  REQUIRE_FALSE(sampler);
  CHECK(sampler.error().code ==
        "c17.audited_sampler_descriptor_unavailable");
}
