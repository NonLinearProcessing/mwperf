#include <array>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

using Json = nlohmann::ordered_json;

[[nodiscard]] mwperf::ArtifactParseLimits artifact_limits() {
  return {16U << 20U, 64U, 1U << 15U, 1U << 15U, 1U << 17U,
          1U << 17U, 64U << 20U};
}

[[nodiscard]] std::vector<std::byte> bytes_of(const std::string& text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  return {bytes.begin(), bytes.end()};
}

[[nodiscard]] Json read_json(const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  REQUIRE(input.is_open());
  return Json::parse(std::istreambuf_iterator<char>{input},
                     std::istreambuf_iterator<char>{});
}

[[nodiscard]] Json observation_json_for(
    mwperf::ConstructionObservationBundleV1 bundle) {
  const auto envelope =
      mwperf::testing::c30::envelope_for(std::move(bundle));
  auto encoded =
      mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
  REQUIRE(encoded);
  const std::string text(
      reinterpret_cast<const char*>(encoded.value().data()),
      encoded.value().size());
  return Json::parse(text);
}

[[nodiscard]] Json observation_json() {
  return observation_json_for(mwperf::testing::c30::exact_bundle());
}

[[nodiscard]] Json provider_v2_fixture(const std::string_view filename) {
  Json document = read_json(
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
      "fixtures" / "c15" / "golden" / filename);
  document["envelope"]["protocol_version"] = 2U;
  const Json observation = observation_json();
  document["envelope"]["observation_bundle"] =
      observation.at("observation_bundle");
  document["envelope"]["observation_bundle_digest"] =
      observation.at("observation_bundle_digest");
  return document;
}

[[nodiscard]] mwperf::Result<mwperf::ParsedSurrogateResultFrameV2>
parse_v2(
    const Json& document,
    const mwperf::ObservationParseLimitsV1& observation_limits =
        mwperf::default_observation_parse_limits_v1()) {
  const auto bytes = bytes_of(document.dump());
  return mwperf::parse_surrogate_build_result_v2(
      bytes, artifact_limits(), observation_limits);
}

[[nodiscard]] mwperf::Result<mwperf::ParsedSurrogateResultFrameV2>
parse_v2_text(
    const std::string& text,
    const mwperf::ObservationParseLimitsV1& observation_limits =
        mwperf::default_observation_parse_limits_v1()) {
  const auto bytes = bytes_of(text);
  return mwperf::parse_surrogate_build_result_v2(
      bytes, artifact_limits(), observation_limits);
}

void require_retained_valid_observation(
    const mwperf::ParsedSurrogateResultFrameV2& frame) {
  REQUIRE(frame.envelope.observation.has_value());
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      *frame.envelope.observation,
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  CHECK(validated.value().digest() ==
        frame.envelope.observation->observation_bundle_digest);
}

}  // namespace

TEST_CASE("C30 canonical observation wire covers every source role",
          "[c30][protocol][observation][roles]") {
  constexpr std::array<mwperf::ObservationSourceRoleV1, 3U> roles{
      mwperf::ObservationSourceRoleV1::weighted_ensemble,
      mwperf::ObservationSourceRoleV1::short_restart_reference,
      mwperf::ObservationSourceRoleV1::long_stationary_reference};

  for (const auto role : roles) {
    const auto envelope = mwperf::testing::c30::envelope_for(
        mwperf::testing::c30::exact_bundle(role));
    auto first =
        mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
    auto second =
        mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
    REQUIRE(first);
    REQUIRE(second);
    CHECK(first.value() == second.value());

    auto parsed = mwperf::parse_construction_observation_envelope_v1(
        first.value(), mwperf::default_observation_parse_limits_v1());
    REQUIRE(parsed);
    auto validated = mwperf::validate_construction_observation_envelope_v1(
        std::move(parsed).value(),
        mwperf::default_observation_parse_limits_v1());
    REQUIRE(validated);
    CHECK(validated.value().value().source_role == role);
    CHECK(validated.value().digest() == envelope.observation_bundle_digest);
  }
}

TEST_CASE("C30 provider-result-v2 stages Built Unavailable and Failed",
          "[c30][protocol][provider-result-v2]") {
  struct Case final {
    std::string_view filename;
    mwperf::ProviderResultKindV2 kind;
  };
  constexpr std::array<Case, 3U> cases{{
      {"result_built.json", mwperf::ProviderResultKindV2::built},
      {"result_unavailable_construction_domain_unavailable.json",
       mwperf::ProviderResultKindV2::unavailable},
      {"result_failed_construction_failure.json",
       mwperf::ProviderResultKindV2::failed},
  }};

  for (const auto& test : cases) {
    INFO(test.filename);
    auto frame = parse_v2(provider_v2_fixture(test.filename));
    REQUIRE(frame);
    CHECK(frame.value().declared_kind == test.kind);
    CHECK(std::holds_alternative<mwperf::SurrogateBuildResultBranchV2>(
        frame.value().branch_decode_outcome));
    require_retained_valid_observation(frame.value());
    auto assembled = mwperf::assemble_surrogate_build_result_v2(
        std::move(frame).value());
    REQUIRE(assembled);
    auto canonical =
        mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v2(
            assembled.value());
    REQUIRE(canonical);
    auto reparsed = mwperf::parse_surrogate_build_result_v2(
        canonical.value(), artifact_limits(),
        mwperf::default_observation_parse_limits_v1());
    REQUIRE(reparsed);
    CHECK(reparsed.value().declared_kind == test.kind);
    CHECK(std::holds_alternative<mwperf::SurrogateBuildResultBranchV2>(
        reparsed.value().branch_decode_outcome));
    require_retained_valid_observation(reparsed.value());
    switch (test.kind) {
      case mwperf::ProviderResultKindV2::built:
        CHECK(std::holds_alternative<mwperf::BuiltSurrogateResultV2>(
            assembled.value()));
        break;
      case mwperf::ProviderResultKindV2::unavailable:
        CHECK(std::holds_alternative<mwperf::UnavailableSurrogateResultV2>(
            assembled.value()));
        break;
      case mwperf::ProviderResultKindV2::failed:
        CHECK(std::holds_alternative<mwperf::FailedSurrogateResultV2>(
            assembled.value()));
        break;
      case mwperf::ProviderResultKindV2::observed:
        FAIL("provider-result v2 cannot decode the v3 Observed terminal");
        break;
    }
  }
}

TEST_CASE("C30 staged branch failures retain the common observation",
          "[c30][protocol][provider-result-v2][negative]") {
  struct Case final {
    std::string_view filename;
    void (*mutate)(Json&);
  };
  const std::array<Case, 3U> cases{{
      {"result_built.json",
       +[](Json& value) {
         value["artifact"]["artifact_protocol_version"] = "broken";
       }},
      {"result_unavailable_construction_domain_unavailable.json",
       +[](Json& value) { value["reasons"] = Json::object(); }},
      {"result_failed_construction_failure.json",
       +[](Json& value) {
         value["failure"]["kind"] = "unknown_failure_kind";
       }},
  }};

  for (const auto& test : cases) {
    INFO(test.filename);
    Json document = provider_v2_fixture(test.filename);
    test.mutate(document);
    auto frame = parse_v2(document);
    REQUIRE(frame);
    CHECK(std::holds_alternative<mwperf::SurrogateResultBranchDecodeFailureV2>(
        frame.value().branch_decode_outcome));
    require_retained_valid_observation(frame.value());
    auto assembled = mwperf::assemble_surrogate_build_result_v2(
        std::move(frame).value());
    REQUIRE_FALSE(assembled);
  }
}

TEST_CASE("C30 outer-envelope failures retain no staged frame",
          "[c30][protocol][provider-result-v2][negative]") {
  SECTION("unknown root member") {
    Json document = provider_v2_fixture("result_built.json");
    document["unexpected_root_member"] = true;
    auto frame = parse_v2(document);
    REQUIRE_FALSE(frame);
    CHECK(frame.error().code == "artifact_wire_unknown_field");
    CHECK(frame.error().json_pointer == "/unexpected_root_member");
  }

  SECTION("invalid common request digest") {
    Json document = provider_v2_fixture("result_built.json");
    document["envelope"]["request_digest"] = "not-a-digest";
    auto frame = parse_v2(document);
    REQUIRE_FALSE(frame);
    CHECK(frame.error().code.starts_with("artifact_wire_"));
  }

  SECTION("malformed common observation report") {
    Json document = provider_v2_fixture("result_built.json");
    REQUIRE(document["envelope"].erase("observation_bundle_digest") == 1U);
    auto frame = parse_v2(document);
    REQUIRE_FALSE(frame);
    CHECK(frame.error().code ==
          "artifact_wire_observation_pair_incomplete");
  }
}

TEST_CASE("C30 provider-result-v2 applies embedded observation limits before decode",
          "[c30][protocol][provider-result-v2][negative][limits]") {
  Json document = provider_v2_fixture("result_built.json");
  const std::size_t canonical_observation_bytes =
      observation_json().dump().size();
  REQUIRE(canonical_observation_bytes > 0U);
  auto limits = mwperf::default_observation_parse_limits_v1();
  limits.maximum_bytes = canonical_observation_bytes - 1U;

  auto frame = parse_v2(document, limits);
  REQUIRE_FALSE(frame);
  CHECK(frame.error().category == mwperf::DiagnosticCategory::resource_limit);
  CHECK(frame.error().code == "observation_parse_input_bytes_limit");
}

TEST_CASE("C30 provider-result-v2 rejects duplicate observation keys before DOM decode",
          "[c30][protocol][provider-result-v2][negative][limits]") {
  std::string text = provider_v2_fixture("result_built.json").dump();
  constexpr std::string_view needle{
      "\"observation_bundle\":{\"schema_version\":1,"};
  const std::size_t position = text.find(needle);
  REQUIRE(position != std::string::npos);
  text.replace(position, needle.size(),
               "\"observation_bundle\":{\"schema_version\":1,"
               "\"schema_version\":1,");

  auto frame = parse_v2_text(text);
  REQUIRE_FALSE(frame);
  CHECK(frame.error().code == "artifact_parse_duplicate_key");
}

TEST_CASE("C30 provider-result-v2 rejects noncanonical embedded scalars",
          "[c30][protocol][provider-result-v2][negative][scalar]") {
  Json document = provider_v2_fixture("result_built.json");
  Json& scalar = document["envelope"]["observation_bundle"]
                         ["replications"][0]["blocks"][0]["levels"][0]
                         ["exposure_mass"]["value"];
  scalar["numerator"] = "2";
  scalar["denominator"] = "2";

  auto frame = parse_v2(document);
  REQUIRE_FALSE(frame);
  CHECK(frame.error().category ==
        mwperf::DiagnosticCategory::input_validation);
}

TEST_CASE("C30 provider-result-v2 retains bytes but rejects mutated scientific bindings",
          "[c30][protocol][provider-result-v2][negative][bindings]") {
  SECTION("unit-multiplier capability disagrees with the bound target") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    bundle.bindings.target.maxweight_multiplier =
        mwperf::testing::c30::rational(2);
    Json document = provider_v2_fixture("result_built.json");
    const Json observation = observation_json_for(std::move(bundle));
    document["envelope"]["observation_bundle"] =
        observation.at("observation_bundle");
    document["envelope"]["observation_bundle_digest"] =
        observation.at("observation_bundle_digest");

    auto frame = parse_v2(document);
    REQUIRE(frame);
    REQUIRE(frame.value().envelope.observation);
    auto validated = mwperf::validate_construction_observation_envelope_v1(
        *frame.value().envelope.observation,
        mwperf::default_observation_parse_limits_v1());
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code ==
          "observation_multiplier_capability_mismatch");
  }

  SECTION("declared arrival moments disagree with the exact marginal") {
    auto bundle = mwperf::testing::c30::exact_bundle();
    bundle.bindings.arrival.mean = mwperf::testing::c30::rational(1, 2);
    Json document = provider_v2_fixture("result_built.json");
    const Json observation = observation_json_for(std::move(bundle));
    document["envelope"]["observation_bundle"] =
        observation.at("observation_bundle");
    document["envelope"]["observation_bundle_digest"] =
        observation.at("observation_bundle_digest");

    auto frame = parse_v2(document);
    REQUIRE(frame);
    REQUIRE(frame.value().envelope.observation);
    auto validated = mwperf::validate_construction_observation_envelope_v1(
        *frame.value().envelope.observation,
        mwperf::default_observation_parse_limits_v1());
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "observation_arrival_moment_mismatch");
  }
}
