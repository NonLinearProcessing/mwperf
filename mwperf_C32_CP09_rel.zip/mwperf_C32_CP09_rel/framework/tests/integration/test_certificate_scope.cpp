#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/certificates/transfer_bounds.hpp"
#include "mwperf/diagnostics/error_budget.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix = mwperf::testing::c16_registered_pair_matrix;
using ProtocolFactory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object(
    const std::string_view name) {
  return {matrix::label(name), matrix::digest(name)};
}

[[nodiscard]] mwperf::QueueId queue(const std::string_view name) {
  return mwperf::QueueId(matrix::label(name));
}

[[nodiscard]] mwperf::MetricGeometry tv_geometry(
    const std::string_view name) {
  return {.value = mwperf::TotalVariationGeometryV1{
              .geometry_identity = matrix::digest(std::string(name) + ".tv"),
              .state_space_identity =
                  matrix::digest(std::string(name) + ".state"),
              .observable_identity =
                  matrix::digest(std::string(name) + ".observable"),
              .convention =
                  mwperf::TvConventionV1::supremum_event_difference,
              .reward_lower = std::nullopt,
              .reward_upper = std::nullopt,
          }};
}

[[nodiscard]] mwperf::RowErrorEvidenceV1 relational_row(
    const std::string_view name, const long double initial_defect,
    const long double row_defect) {
  return {
      .evidence_id = object(std::string(name) + ".evidence"),
      .reference_law = object(std::string(name) + ".physical-c22-hit-law"),
      .approximate_law =
          object(std::string(name) + ".surrogate-c22-hit-law"),
      .kind = mwperf::RowErrorKindV1::approximate_relational_slot_row,
      .horizon_domain = mwperf::HorizonDomainV1::relational_slots,
      .consequence_domain =
          matrix::digest(std::string(name) + ".threshold-hit-event"),
      .geometry = tv_geometry(name),
      .row_defect = row_defect,
      .initial_defect = initial_defect,
      .equal_initial_law = initial_defect == 0.0L,
      .common_refinement_established = true,
      .orientation = mwperf::TransferOrientationV1::reference_to_approximate,
      .reward = {.kind = mwperf::RewardGeometryKindV1::event_indicator,
                 .lower = std::nullopt,
                 .upper = std::nullopt,
                 .lipschitz_modulus = std::nullopt,
                 .required_moments_established = true},
      .dependencies = {},
  };
}

[[nodiscard]] mwperf::ValidatedCertificates validate(
    const mwperf::AuditedCompiledFramework& framework,
    std::vector<mwperf::CertificateEvidenceNodeV1> nodes,
    const std::function<void(mwperf::CertificateBundle&)>& select) {
  std::vector<mwperf::CertificateEvidenceNodeV1> premises;
  const std::size_t authored_nodes = nodes.size();
  premises.reserve(authored_nodes);
  for (std::size_t index = 0U; index < authored_nodes; ++index) {
    std::visit(
        [&](auto& node) {
          using Node = std::decay_t<decltype(node)>;
          std::optional<mwperf::CertificateClaimKindV1> claim;
          if constexpr (std::is_same_v<Node, mwperf::RowErrorEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::finite_horizon_transfer;
          } else if constexpr (std::is_same_v<
                                   Node,
                                   mwperf::DecisionSensitivityEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::decision_sensitivity;
          } else if constexpr (std::is_same_v<
                                   Node, mwperf::PoissonDefectEvidenceV1>) {
            claim = mwperf::CertificateClaimKindV1::poisson_reward;
          } else {
            return;
          }

          const std::string name =
              "c25.integration.typed-premise." + std::to_string(index) +
              "." + std::to_string(static_cast<unsigned int>(*claim));
          mwperf::Digest256 product = matrix::digest(name + ".product");
          mwperf::Digest256 law = matrix::digest(name + ".law");
          if constexpr (requires {
                          node.subject_product_identity;
                          node.subject_law_identity;
                        }) {
            product = node.subject_product_identity;
            law = node.subject_law_identity;
          }
          mwperf::CertificatePremiseEvidenceV1 premise{
              .evidence_id = object(name),
              .supported_claim = *claim,
              .subject_product_identity = product,
              .subject_law_identity = law,
              .premise_identity = matrix::digest(name + ".premise"),
              .provenance_identity = object(name + ".provenance"),
              .coverage =
                  mwperf::CertificateCoverageV1::global_declared_domain,
              .origin =
                  mwperf::CertificateEvidenceOriginV1::independent_a_priori,
              .dependencies = {}};
          node.dependencies.push_back(premise.evidence_id);
          premises.emplace_back(std::move(premise));
        },
        nodes[index]);
  }
  nodes.insert(nodes.end(), std::make_move_iterator(premises.begin()),
               std::make_move_iterator(premises.end()));

  auto evidence = mwperf::Evidence::bind(framework, std::move(nodes));
  INFO((evidence ? std::string{}
                 : evidence.error().code + ": " + evidence.error().message));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  select(bundle);
  auto result = mwperf::validate_certificate_bundle(
      bundle, framework, evidence.value());
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] const mwperf::ValidatedClaimV1& claim_of_kind(
    const mwperf::ValidatedCertificates& certificates,
    const mwperf::CertificateClaimKindV1 kind) {
  const auto claims = certificates.claims();
  const auto found = std::find_if(
      claims.begin(), claims.end(),
      [kind](const mwperf::ValidatedClaimV1& claim) {
        return claim.kind == kind;
      });
  REQUIRE(found != claims.end());
  return *found;
}

[[nodiscard]] mwperf::DiagnosticValueIntervalV1 finite_interval(
    const long double lower = 0.0L, const long double upper = 0.125L) {
  return {mwperf::CertificateClaimStateV1::established,
          mwperf::BoundValueStatusV1::finite, lower, upper};
}

[[nodiscard]] mwperf::DiagnosticValueIntervalV1 unknown_interval() {
  return {mwperf::CertificateClaimStateV1::not_established,
          mwperf::BoundValueStatusV1::unresolved, std::nullopt,
          std::nullopt};
}

struct ProfileLedgerFixture final {
  mwperf::ResponseIdentityContextV1 response;
  mwperf::MeanIdentityContextV1 means;
  mwperf::RawResponseCoefficientIdentityV1 raw_one;
  mwperf::RawResponseCoefficientIdentityV1 raw_two;
  mwperf::RawResponseCoefficientIdentityV1 raw_tail;
  mwperf::NominalResponseCoefficientIdentityV1 nominal_one;
  mwperf::ProjectionCenterIdentityV1 projection_center;
  mwperf::ProjectedMeanIdentityV1 projected_mean;
  mwperf::DeployedLawProductIdentityV1 deployed_law;
  mwperf::MetricGeometry geometry;
};

[[nodiscard]] ProfileLedgerFixture profile_ledger_fixture(
    const std::string_view provider_id) {
  const std::string prefix(provider_id);
  const mwperf::ProviderIdentityV1 provider{prefix, "1.0.0"};
  const mwperf::ResponseIdentityContextV1 response{
      provider,
      object(prefix + ".artifact"),
      object(prefix + ".payload"),
      matrix::digest(prefix + ".build"),
      matrix::digest(prefix + ".request"),
      queue("q0"),
      std::nullopt,
      matrix::label(prefix + ".frozen-bank"),
      matrix::label(prefix + ".final-probe")};
  const mwperf::MeanIdentityContextV1 means{
      provider,
      response.artifact_identity,
      response.payload_identity,
      response.build_identity,
      response.request_identity,
      {queue("q0"), queue("q1"), queue("q2")},
      std::nullopt,
      response.frozen_input_bank_id,
      response.final_probe_id};
  const auto raw = ProtocolFactory::raw_response_product_id(
      object(prefix + ".raw-response"));
  const auto nominal = ProtocolFactory::nominal_response_product_id(
      object(prefix + ".nominal-response"));
  const auto center = ProtocolFactory::projection_center_product_id(
      object(prefix + ".projection-center"));
  const auto projected = ProtocolFactory::projected_mean_product_id(
      object(prefix + ".projected-mean"));
  const auto recoded = ProtocolFactory::recoded_response_product_id(
      object(prefix + ".recoded-response"));
  auto law = mwperf::LawIdentityV1::make(
      {.response = response,
       .deployed_product =
           mwperf::RecodedResponseProductRef{recoded.identity()},
       .configured_arrival_law =
           matrix::digest(prefix + ".configured-arrival"),
       .execution_identity = matrix::digest(prefix + ".execution"),
       .metric_target_identity = matrix::digest(prefix + ".metric-target")});
  INFO((law ? std::string{}
            : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return {
      response,
      means,
      {response, raw, mwperf::ResponseProductValueFormV1::interval_only,
       mwperf::ThreeBinCoefficientV1::one},
      {response, raw, mwperf::ResponseProductValueFormV1::interval_only,
       mwperf::ThreeBinCoefficientV1::two},
      {response, raw, mwperf::ResponseProductValueFormV1::interval_only,
       mwperf::ThreeBinCoefficientV1::tail_from_three},
      {response, nominal, mwperf::ThreeBinCoefficientV1::one},
      {means, center},
      {means, projected},
      {std::move(law).value()},
      {.value = mwperf::TotalVariationGeometryV1{
           .geometry_identity = matrix::digest(prefix + ".tv"),
           .state_space_identity = matrix::digest(prefix + ".state"),
           .observable_identity = matrix::digest(prefix + ".observable"),
           .convention =
               mwperf::TvConventionV1::supremum_event_difference,
           .reward_lower = 0.0L,
           .reward_upper = 1.0L}}};
}

[[nodiscard]] mwperf::DiagnosticComponent ledger_component(
    const ProfileLedgerFixture& fixture, const std::string_view name,
    const mwperf::ComponentScopeV1 scope, mwperf::ProductIdentityV1 source,
    std::optional<mwperf::DiagnosticConfidenceV1> confidence = std::nullopt) {
  const std::string prefix(name);
  auto made = mwperf::DiagnosticComponent::make(
      {.component_identity = object(prefix + ".component"),
       .scope = scope,
       .source_product = std::move(source),
       .destination_product = std::nullopt,
       .metric = "scalar_backlog_response diagnostic",
       .geometry = fixture.geometry,
       .value = finite_interval(),
       .confidence = std::move(confidence),
       .deterministic_tolerance = std::nullopt,
       .theorem_or_method = prefix + ".scoped-method",
       .assumptions = {"synthetic framework wire fixture"},
       .evidence_references = {object(prefix + ".evidence")},
       .provenance_identity = object(prefix + ".provenance"),
       .bridge = std::nullopt,
       .triangle_contribution = std::nullopt,
       .physical_fidelity_anchor = std::nullopt,
       .evaluated_transfer_bound = std::nullopt});
  INFO((made ? std::string{}
             : made.error().code + ": " + made.error().message));
  REQUIRE(made);
  return std::move(made).value();
}

[[nodiscard]] std::vector<mwperf::DiagnosticComponent> profile_components(
    const ProfileLedgerFixture& fixture, const std::string_view provider_id,
    const bool sampling) {
  const std::string prefix(provider_id);
  std::vector<mwperf::DiagnosticComponent> result;
  result.reserve(sampling ? 8U : 7U);
  result.push_back(ledger_component(
      fixture, prefix + ".construction",
      mwperf::ComponentScopeV1::construction_integration,
      fixture.raw_one));
  result.push_back(ledger_component(
      fixture, prefix + ".input-bank",
      mwperf::ComponentScopeV1::input_bank_initialization,
      fixture.raw_two));
  result.push_back(ledger_component(
      fixture, prefix + ".optimizer", mwperf::ComponentScopeV1::optimizer,
      fixture.raw_tail));
  if (sampling) {
    result.push_back(ledger_component(
        fixture, prefix + ".coefficient-sampling",
        mwperf::ComponentScopeV1::coefficient_sampling, fixture.raw_one,
        mwperf::DiagnosticConfidenceV1{0.95L, "simultaneous proposal band",
                                       "raw-response three-bin family",
                                       true}));
  }
  result.push_back(ledger_component(
      fixture, prefix + ".compression",
      mwperf::ComponentScopeV1::compression, fixture.nominal_one));
  result.push_back(ledger_component(
      fixture, prefix + ".projection", mwperf::ComponentScopeV1::projection,
      fixture.projection_center));
  result.push_back(ledger_component(
      fixture, prefix + ".recode", mwperf::ComponentScopeV1::recode,
      fixture.projected_mean));
  result.push_back(ledger_component(
      fixture, prefix + ".solver", mwperf::ComponentScopeV1::solver,
      fixture.deployed_law));
  return result;
}

[[nodiscard]] mwperf::testing::ModeErasedLawProjectionV1
mode_erased_scalar_projection() {
  return {
      1U,
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
       1U,
       mwperf::SemanticTagV1::scalar_backlog_response,
       mwperf::testing::ModeErasedStateDomainV1::
           nonnegative_integer_singleton_backlog,
       mwperf::testing::ModeErasedTargetConventionV1::
           selected_target_relative_three_bins,
       {mwperf::ExactRational::zero(), mwperf::ExactRational::one(),
        mwperf::ExactRational::one(), mwperf::ExactRational::one()},
       mwperf::testing::ModeErasedServiceRandomizationV1::
           independent_fresh_uniform_given_current_backlog},
      {mwperf::PortableArrivalLawSchema::deterministic_trace_v1,
       {std::byte{0x01}},
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival,
       std::nullopt},
      {mwperf::TimingConvention::early_service_late_admission, {}},
      {{}, {}, mwperf::PortableStationaryUniqueSelectionV1{}, {}}};
}

}  // namespace

TEST_CASE("C25 validates a V0-only carrier without inventing stronger claims",
          "[c25][integration]") {
  auto fixture = temporal::make_generic_temporal_framework();
  auto evidence = mwperf::Evidence::bind(fixture.framework, {});
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  auto validated = mwperf::validate_certificate_bundle(
      bundle, fixture.framework, evidence.value());
  INFO((validated
            ? std::string{}
            : validated.error().code + ": " + validated.error().message));
  REQUIRE(validated);

  CHECK(validated.value().v0_report().passed());
  CHECK(validated.value().v1_geometry().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.value().v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.value().stationary_integrated_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.value().physical_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(validated.value().stability().state ==
        mwperf::CertificateClaimStateV1::not_established);

  // Optional evidence validation is a layer around the already usable V0
  // carrier.  This fixture intentionally exposes a temporal executor rather
  // than an enumerable residence row, so exercise the exact released runtime
  // route that the carrier actually declares.
  auto temporal_view = mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(temporal_view);
  auto executor = mwperf::audited_slot_executor(temporal_view.value());
  REQUIRE(executor);
  auto bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{0xC2501U});
  REQUIRE(bank);
  auto edge = mwperf::execute_reduced_slot(
      executor.value(), fixture.initial_state, bank.value());
  REQUIRE(edge);
  CHECK(edge.value().stage_trace() == mwperf::kCausalStageOrderV1);
}

TEST_CASE("C25 issues theorem views only for selected validated evidence",
          "[c25][integration][negative]") {
  auto fixture = temporal::make_generic_temporal_framework();
  const auto row = relational_row("c25.integration.selection", 0.1L, 0.05L);

  auto unselected = validate(
      fixture.framework, {row}, [](mwperf::CertificateBundle&) {});
  auto missing_view = unselected.row_error_bound(row.evidence_id);
  REQUIRE_FALSE(missing_view);
  CHECK(missing_view.error().code == "c25.validated_view_not_selected");

  auto selected = validate(
      fixture.framework, {row},
      [&](mwperf::CertificateBundle& bundle) {
        bundle.transfer_claims = {row.evidence_id};
      });
  auto view = selected.row_error_bound(row.evidence_id);
  REQUIRE(view);
  auto bound = mwperf::compute_finite_horizon_tv_transfer(
      view.value(), mwperf::Horizon{10U});
  REQUIRE(bound);
  CHECK(bound.value().claim_state ==
        mwperf::CertificateClaimStateV1::established);
}

TEST_CASE("C25 scopes a C22 threshold-hit transfer to transient slots",
          "[c25][integration]") {
  auto fixture = temporal::make_generic_temporal_framework();
  const auto row =
      relational_row("c25.integration.c22-threshold-hit", 0.1L, 0.05L);
  auto certificates = validate(
      fixture.framework, {row},
      [&](mwperf::CertificateBundle& bundle) {
        bundle.transfer_claims = {row.evidence_id};
      });
  auto view = certificates.row_error_bound(row.evidence_id);
  REQUIRE(view);
  auto bound = mwperf::compute_finite_horizon_tv_transfer(
      view.value(), mwperf::Horizon{4U});
  REQUIRE(bound);
  CHECK(bound.value().scope ==
        mwperf::TransferScopeV1::finite_relational_slots);
  CHECK(bound.value().theorem_id.find("relational_slot") !=
        std::string::npos);
  CHECK(bound.value().presented_value.has_value());
  CHECK(*bound.value().presented_value <= 1.0L);
  CHECK(std::none_of(
      bound.value().assumptions.begin(), bound.value().assumptions.end(),
      [](const std::string& assumption) {
        return assumption.find("stationary conclusion") !=
               std::string::npos;
      }));
}

TEST_CASE("C25 leaves unrelated claims untouched when Poisson evidence is local",
          "[c25][integration]") {
  auto fixture = temporal::make_generic_temporal_framework();
  const mwperf::DecisionSensitivityEvidenceV1 decision{
      .evidence_id = object("c25.integration.decision"),
      .subject_product_identity = matrix::digest("c25.integration.product"),
      .subject_law_identity = matrix::digest("c25.integration.law"),
      .coupling_identity = matrix::digest("c25.integration.coupling"),
      .eta = 0.25L,
      .near_boundary_probability = 0.1L,
      .reconstruction_probability = 0.05L,
      .eligibility_probability = 0.02L,
      .tie_probability = 0.03L,
      .every_term_independently_bounded = true,
      .dependencies = {},
  };
  const mwperf::PoissonDefectEvidenceV1 local_poisson{
      .evidence_id = object("c25.integration.poisson"),
      .subject_product_identity = matrix::digest("c25.integration.product"),
      .subject_law_identity = matrix::digest("c25.integration.law"),
      .reward_identity = matrix::digest("c25.integration.reward"),
      .corrector_identity = matrix::digest("c25.integration.corrector"),
      .coverage = mwperf::CertificateCoverageV1::sampled_only,
      .delta = 0.01L,
      .moment_bound = 4.0L,
      .invariant_law_established = true,
      .invariant_coboundary_identity_justified = true,
      .domain_and_integrability_established = true,
      .global_residual_established = false,
      .dependencies = {},
  };
  auto certificates = validate(
      fixture.framework, {decision, local_poisson},
      [&](mwperf::CertificateBundle& bundle) {
        bundle.decision_diagnostics = {decision.evidence_id};
        bundle.poisson_rewards = {local_poisson.evidence_id};
      });

  CHECK(claim_of_kind(certificates,
                      mwperf::CertificateClaimKindV1::decision_sensitivity)
            .state == mwperf::CertificateClaimStateV1::established);
  CHECK(claim_of_kind(certificates,
                      mwperf::CertificateClaimKindV1::poisson_reward)
            .state == mwperf::CertificateClaimStateV1::not_established);
  CHECK(certificates.physical_fidelity().state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(certificates.v2_dynamic_lift().state ==
        mwperf::CertificateClaimStateV1::not_established);
}

TEST_CASE("C25 keeps all six released profile ledgers product scoped",
          "[c25][integration][diagnostics]") {
  struct Profile final {
    std::string_view provider_id;
    bool sampling;
  };
  constexpr std::array profiles{
      Profile{"c16.fixture.blossom.engineered", false},
      Profile{"c16.fixture.blossom.sampling", true},
      Profile{"c16.fixture.mwis.engineered", false},
      Profile{"c16.fixture.mwis.sampling", true},
      Profile{"c16.fixture.packing.engineered", false},
      Profile{"c16.fixture.packing.sampling", true}};

  for (const auto& profile : profiles) {
    CAPTURE(profile.provider_id, profile.sampling);
    const auto identities = profile_ledger_fixture(profile.provider_id);
    const auto components = profile_components(
        identities, profile.provider_id, profile.sampling);
    const auto bundle =
        mwperf::compose_diagnostic_and_error_budget(components);
    REQUIRE(bundle.valid());
    CHECK(bundle.ordered_components().size() ==
          (profile.sampling ? 8U : 7U));
    CHECK(bundle.final_law_total().claim_state ==
          mwperf::CertificateClaimStateV1::not_established);
    CHECK(bundle.physical_total().claim_state ==
          mwperf::CertificateClaimStateV1::not_established);

    // The deployed response is a phase-free singleton target.  The larger
    // ordered construction target vector belongs only to mean-stage
    // provenance and must not be substituted for the deployed response.
    CHECK_FALSE(identities.response.phase_identity.has_value());
    CHECK(identities.response.response_target == queue("q0"));
    REQUIRE(identities.means.ordered_construction_targets.size() == 3U);
    CHECK(identities.means.ordered_construction_targets.front() ==
          identities.response.response_target);
    CHECK(std::ranges::all_of(
        bundle.ordered_components(), [&](const auto& component) {
          return std::visit(
              [&](const auto& product) {
                using Product = std::decay_t<decltype(product)>;
                if constexpr (std::is_same_v<
                                  Product,
                                  mwperf::DeployedLawProductIdentityV1>) {
                  return product.law.response_context().provider ==
                         identities.response.provider;
                } else {
                  return product.context.provider ==
                         identities.response.provider;
                }
              },
              component.source_product());
        }));

    const auto coefficient_count = std::ranges::count_if(
        bundle.ordered_components(), [](const auto& component) {
          return component.scope() ==
                 mwperf::ComponentScopeV1::coefficient_sampling;
        });
    CHECK(coefficient_count == (profile.sampling ? 1 : 0));

    if (profile.sampling) {
      const auto proposal = std::ranges::find_if(
          bundle.ordered_components(), [](const auto& component) {
            return component.scope() ==
                   mwperf::ComponentScopeV1::coefficient_sampling;
          });
      const auto solver = std::ranges::find_if(
          bundle.ordered_components(), [](const auto& component) {
            return component.scope() == mwperf::ComponentScopeV1::solver;
          });
      REQUIRE(proposal != bundle.ordered_components().end());
      REQUIRE(solver != bundle.ordered_components().end());
      REQUIRE(proposal->confidence().has_value());
      CHECK(proposal->confidence()->simultaneous);
      CHECK(mwperf::product_kind_v1(proposal->source_product()) ==
            mwperf::ProductKindV1::raw_response);
      CHECK(mwperf::product_kind_v1(solver->source_product()) ==
            mwperf::ProductKindV1::recoded_response);
      CHECK(proposal->source_product() != solver->source_product());
      // C15 proposal sampling and the deployed C24/runtime solver record are
      // both retained, but no unproved raw-to-final bridge is invented.
      CHECK(bundle.final_law_total().value_status ==
            mwperf::BoundValueStatusV1::unresolved);
    }
  }
}

TEST_CASE("C25 consumes mode-erased equality without erasing ledger identity",
          "[c25][integration][diagnostics][mode-erased]") {
  const auto first_projection = mode_erased_scalar_projection();
  const auto second_projection = mode_erased_scalar_projection();
  REQUIRE(first_projection == second_projection);

  const auto engineered =
      profile_ledger_fixture("c16.fixture.blossom.engineered");
  const auto sampling =
      profile_ledger_fixture("c16.fixture.blossom.sampling");
  std::vector<mwperf::DiagnosticComponent> components;
  components.push_back(ledger_component(
      engineered, "c25.mode-erased.engineered",
      mwperf::ComponentScopeV1::solver, engineered.deployed_law));
  components.push_back(ledger_component(
      sampling, "c25.mode-erased.sampling",
      mwperf::ComponentScopeV1::solver, sampling.deployed_law));
  const auto bundle =
      mwperf::compose_diagnostic_and_error_budget(components);
  REQUIRE(bundle.valid());
  REQUIRE(bundle.ordered_components().size() == 2U);
  CHECK(bundle.ordered_components()[0].source_product() !=
        bundle.ordered_components()[1].source_product());

  const auto& first = std::get<mwperf::DeployedLawProductIdentityV1>(
      bundle.ordered_components()[0].source_product());
  const auto& second = std::get<mwperf::DeployedLawProductIdentityV1>(
      bundle.ordered_components()[1].source_product());
  CHECK(first.law.response_context().provider !=
        second.law.response_context().provider);
  CHECK(first.law.response_context().artifact_identity !=
        second.law.response_context().artifact_identity);
  CHECK(first.law.response_context().request_identity !=
        second.law.response_context().request_identity);
  CHECK(first.law.execution_identity() != second.law.execution_identity());
}

TEST_CASE("C25 separates offline proposal runtime solver and unknown closure",
          "[c25][integration][diagnostics][c24]") {
  const auto fixture =
      profile_ledger_fixture("c16.fixture.mwis.sampling");
  std::vector<mwperf::DiagnosticComponent> components;
  components.push_back(ledger_component(
      fixture, "c25.c24.offline-coefficient",
      mwperf::ComponentScopeV1::coefficient_sampling, fixture.raw_one,
      mwperf::DiagnosticConfidenceV1{0.95L, "proposal ratio band",
                                     "three raw coefficients", true}));
  components.push_back(ledger_component(
      fixture, "c25.c24.runtime-reward",
      mwperf::ComponentScopeV1::solver, fixture.deployed_law,
      mwperf::DiagnosticConfidenceV1{0.95L, "deployed reward estimator",
                                     "configured deployed law", false}));

  auto residual = mwperf::DiagnosticComponent::make(
      {.component_identity = object("c25.c24.residual.component"),
       .scope = mwperf::ComponentScopeV1::solver,
       .source_product = fixture.deployed_law,
       .destination_product = std::nullopt,
       .metric = "stationary solver residual",
       .geometry = fixture.geometry,
       .value = finite_interval(0.0L, 0.000001L),
       .confidence = std::nullopt,
       .deterministic_tolerance = 0.000001L,
       .theorem_or_method = "deterministic residual conversion",
       .assumptions = {"deployed law linear system"},
       .evidence_references = {object("c25.c24.residual.evidence")},
       .provenance_identity = object("c25.c24.residual.provenance"),
       .bridge = std::nullopt,
       .triangle_contribution = std::nullopt,
       .physical_fidelity_anchor = std::nullopt,
       .evaluated_transfer_bound = std::nullopt});
  REQUIRE(residual);
  components.push_back(std::move(residual).value());

  auto opportunity = mwperf::DiagnosticComponent::make(
      {.component_identity = object("c25.c24.opportunity.component"),
       .scope = mwperf::ComponentScopeV1::compression,
       .source_product = fixture.nominal_one,
       .destination_product = std::nullopt,
       .metric = "opportunity-closure bias",
       .geometry = fixture.geometry,
       .value = unknown_interval(),
       .confidence = std::nullopt,
       .deterministic_tolerance = std::nullopt,
       .theorem_or_method = "opportunity closure unavailable",
       .assumptions = {"unresolved opportunity bin"},
       .evidence_references = {object("c25.c24.opportunity.evidence")},
       .provenance_identity = object("c25.c24.opportunity.provenance"),
       .bridge = std::nullopt,
       .triangle_contribution = std::nullopt,
       .physical_fidelity_anchor = std::nullopt,
       .evaluated_transfer_bound = std::nullopt});
  REQUIRE(opportunity);
  components.push_back(std::move(opportunity).value());

  const auto bundle =
      mwperf::compose_diagnostic_and_error_budget(components);
  REQUIRE(bundle.valid());
  REQUIRE(bundle.ordered_components().size() == 4U);
  CHECK(std::ranges::count_if(
            bundle.ordered_components(), [](const auto& component) {
              return component.scope() == mwperf::ComponentScopeV1::solver;
            }) == 2);
  CHECK(std::ranges::count_if(
            bundle.ordered_components(), [](const auto& component) {
              return component.scope() ==
                     mwperf::ComponentScopeV1::coefficient_sampling;
            }) == 1);
  CHECK(std::ranges::any_of(
      bundle.ordered_components(), [](const auto& component) {
        return component.value().claim_state ==
               mwperf::CertificateClaimStateV1::not_established;
      }));
  CHECK(bundle.final_law_total().claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(bundle.physical_total().claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  // Equal-looking numerical intervals and a valid C24 runtime estimator do
  // not turn the raw proposal band into a final mean or physical bound.
  CHECK(bundle.final_law_total().upper_bound == std::nullopt);
  CHECK(bundle.physical_total().upper_bound == std::nullopt);
}
