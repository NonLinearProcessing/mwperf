#include <algorithm>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/compression_comparison.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const char digit) {
  auto value = mwperf::Digest256::from_hex(std::string(64U, digit));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::CompressionNumericalValueV1 exact_number(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  return {rational(numerator, denominator), mwperf::ExactRational::zero()};
}

[[nodiscard]] mwperf::CompressionQuantityV1 exact_quantity(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  return {exact_number(numerator, denominator), {}};
}

[[nodiscard]] const mwperf::ExactRational& estimate(
    const mwperf::CompressionQuantityV1& quantity) {
  REQUIRE(quantity.available());
  REQUIRE(quantity.estimate);
  CHECK(quantity.estimate->absolute_error_bound.is_zero());
  return quantity.estimate->value;
}

[[nodiscard]] bool has_reason(
    const mwperf::CompressionMetricStatusV1& status,
    const mwperf::CompressionUnavailableReasonV1 reason) {
  return std::find(status.unavailable_reasons.begin(),
                   status.unavailable_reasons.end(), reason) !=
         status.unavailable_reasons.end();
}

[[nodiscard]] mwperf::ObservationScientificBindingsV1 bindings() {
  return {
      digest('1'),
      digest('2'),
      digest('3'),
      {mwperf::QueueId(
           mwperf::TypedLabel::numeric(mwperf::BigNat{17U})),
       0U, rational(1)},
      {"iid_batch_v1",
       digest('4'),
       mwperf::ExactTargetArrivalMarginalV1{
           {{mwperf::BigNat{0U}, rational(3, 4)},
            {mwperf::BigNat{1U}, rational(1, 4)}}},
       rational(1, 4), rational(1, 4)},
      digest('5'),
      digest('6'),
      digest('7'),
      digest('8'),
      digest('9'),
      digest('a')};
}

[[nodiscard]] mwperf::ObservationSlotConventionV1 direct_slot_order() {
  return {{mwperf::ObservationSlotStageV1::solve_primary_maxweight,
           mwperf::ObservationSlotStageV1::observe_pre_service,
           mwperf::ObservationSlotStageV1::apply_actual_service,
           mwperf::ObservationSlotStageV1::apply_fresh_late_arrival,
           mwperf::ObservationSlotStageV1::commit_post_slot_state,
           mwperf::ObservationSlotStageV1::emit_committed_observation},
          digest('b')};
}

[[nodiscard]] mwperf::ObservationSlotConventionV1 weighted_slot_order() {
  return {{mwperf::ObservationSlotStageV1::solve_primary_maxweight,
           mwperf::ObservationSlotStageV1::observe_pre_service,
           mwperf::ObservationSlotStageV1::apply_actual_service,
           mwperf::ObservationSlotStageV1::classify_and_resample,
           mwperf::ObservationSlotStageV1::allocate_child_lineage,
           mwperf::ObservationSlotStageV1::apply_fresh_late_arrival,
           mwperf::ObservationSlotStageV1::commit_post_slot_state,
           mwperf::ObservationSlotStageV1::emit_committed_observation},
          // Resampling is an explicit role-specific stage, while this digest
          // binds the shared pre-service/fresh-late scientific convention.
          digest('b')};
}

[[nodiscard]] mwperf::FinitePrefixFitResultV1 fit_with_mean(
    const std::int64_t mean) {
  return {
      mwperf::FinitePrefixFitStatusV1::strict_tail_stable,
      {digest('d'), digest('4')},
      {rational(0), rational(1)},
      rational(1),
      rational(1, 4),
      rational(1, 4),
      std::nullopt,
      std::vector<mwperf::ExactRational>{rational(1)},
      rational(0),
      rational(mean),
      std::nullopt,
      mwperf::FinitePrefixFitSlackApplicabilityV1::applicable,
      rational(3, 4),
      {rational(0), rational(0), rational(0)},
      mwperf::BigNat{1U},
      {}};
}

[[nodiscard]] mwperf::FourTailRewardsV1 tail_with_defect(
    const std::int64_t defect) {
  return {exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(defect), {}};
}

[[nodiscard]] mwperf::EmpiricalCompressionDecompositionV1
empty_decomposition() {
  return {exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), {}};
}

[[nodiscard]] mwperf::CompressionCutoffAnalysisV1 cutoff_with_fit(
    const std::int64_t fitted_mean, const std::int64_t stationary_defect) {
  return {mwperf::BigNat{1U},
          {mwperf::BigNat{1U}, {}, exact_quantity(0), {}},
          std::nullopt,
          tail_with_defect(stationary_defect),
          fit_with_mean(fitted_mean),
          std::nullopt,
          {},
          exact_quantity(fitted_mean),
          empty_decomposition(),
          std::nullopt,
          {}};
}

[[nodiscard]] mwperf::PooledObservationMomentsV1 pooled_with_mean(
    const std::int64_t mean) {
  return {mwperf::BigNat{1U},
          1U,
          0U,
          {},
          exact_number(1),
          exact_quantity(1),
          exact_quantity(0),
          exact_quantity(0),
          exact_quantity(mean),
          exact_quantity(0),
          exact_quantity(0),
          exact_quantity(mean),
          exact_quantity(0),
          {}};
}

[[nodiscard]] mwperf::FiniteWindowAnalysisV1 empty_finite_window() {
  return {exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0), {}, {}};
}

[[nodiscard]] mwperf::CompetitionAnalysisV1 empty_competition() {
  return {exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), {}, {}};
}

[[nodiscard]] mwperf::TieAnalysisV1 empty_ties() {
  return {{},
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0),
          exact_quantity(0), exact_quantity(0), exact_quantity(0), {}};
}

[[nodiscard]] mwperf::CompressionAnalysisResultV1 analysis(
    const mwperf::ObservationSourceRoleV1 role, const char observation_digit,
    const std::int64_t observed_mean, const std::int64_t fitted_mean,
    const std::int64_t stationary_defect) {
  return {digest(observation_digit),
          digest(observation_digit),
          role,
          bindings(),
          role == mwperf::ObservationSourceRoleV1::weighted_ensemble
              ? weighted_slot_order()
              : direct_slot_order(),
          {"point_mass_zero", digest('e')},
          0U,
          4U,
          pooled_with_mean(observed_mean),
          std::nullopt,
          {},
          {cutoff_with_fit(fitted_mean, stationary_defect)},
          empty_finite_window(),
          empty_competition(),
          empty_ties(),
          {},
          {},
          mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
              finite_prefix_constant_tail,
          std::nullopt};
}

}  // namespace

TEST_CASE("C30 exact gaps telescope from competition scale to compression",
          "[c30][comparison][property]") {
  const auto stationary = analysis(
      mwperf::ObservationSourceRoleV1::long_stationary_reference, '1', 10,
      12, 2);
  const auto finite = analysis(
      mwperf::ObservationSourceRoleV1::short_restart_reference, '2', 0, 15,
      0);
  const auto ensemble = analysis(
      mwperf::ObservationSourceRoleV1::weighted_ensemble, '3', 0, 14, 0);

  auto compared = mwperf::compare_compression_profiles_v1(
      stationary, finite, ensemble,
      {digest('f'), true, std::nullopt});
  REQUIRE(compared);
  REQUIRE(compared.value().status.available());
  REQUIRE(compared.value().cutoffs.size() == 1U);
  const auto& row = compared.value().cutoffs.front();
  CHECK(estimate(row.compression) == rational(2));
  CHECK(estimate(row.finite_window_construction) == rational(3));
  CHECK(estimate(row.weighted_ensemble_sampling) == rational(-1));
  CHECK(estimate(row.provider_transformation).is_zero());
  CHECK(estimate(row.three_term_sum) == rational(4));
  CHECK(estimate(row.three_term_target) == rational(4));
  CHECK(estimate(row.three_term_closure).is_zero());
  CHECK(estimate(row.four_term_sum) == rational(4));
  CHECK(estimate(row.four_term_target) == rational(4));
  CHECK(estimate(row.four_term_closure).is_zero());
  CHECK(estimate(row.stationary_tail_crosscheck).is_zero());
  CHECK(row.fit_resamples == mwperf::FitResampleCountsV1{});
  CHECK_FALSE(row.fit_failure_rate.available());
  CHECK(has_reason(
      row.fit_failure_rate.status,
      mwperf::CompressionUnavailableReasonV1::
          insufficient_independent_replications));
  CHECK(row.transformation_is_definitionally_zero);
}

TEST_CASE("C30 comparison refuses to join mismatched scientific contexts",
          "[c30][comparison][negative]") {
  const auto stationary = analysis(
      mwperf::ObservationSourceRoleV1::long_stationary_reference, '1', 10,
      12, 2);
  const auto finite = analysis(
      mwperf::ObservationSourceRoleV1::short_restart_reference, '2', 0, 15,
      0);
  auto ensemble = analysis(
      mwperf::ObservationSourceRoleV1::weighted_ensemble, '3', 0, 14, 0);
  ensemble.bindings.experiment_digest = digest('0');

  auto compared = mwperf::compare_compression_profiles_v1(
      stationary, finite, ensemble,
      {digest('f'), true, std::nullopt});
  REQUIRE(compared);
  CHECK(has_reason(compared.value().status,
                   mwperf::CompressionUnavailableReasonV1::context_mismatch));
  REQUIRE(compared.value().cutoffs.size() == 1U);
  CHECK(has_reason(compared.value().cutoffs.front().status,
                   mwperf::CompressionUnavailableReasonV1::context_mismatch));
  CHECK_FALSE(compared.value().cutoffs.front().compression.available());
}

TEST_CASE("C30 comparison requires one initialization across all source roles",
          "[c30][comparison][negative]") {
  auto stationary = analysis(
      mwperf::ObservationSourceRoleV1::long_stationary_reference, '1', 10,
      12, 2);
  const auto finite = analysis(
      mwperf::ObservationSourceRoleV1::short_restart_reference, '2', 0, 15,
      0);
  const auto ensemble = analysis(
      mwperf::ObservationSourceRoleV1::weighted_ensemble, '3', 0, 14, 0);
  stationary.initialization.initial_law_digest = digest('0');

  auto compared = mwperf::compare_compression_profiles_v1(
      stationary, finite, ensemble,
      {digest('f'), true, std::nullopt});
  REQUIRE(compared);
  CHECK(has_reason(compared.value().status,
                   mwperf::CompressionUnavailableReasonV1::context_mismatch));
  REQUIRE(compared.value().cutoffs.size() == 1U);
  CHECK(has_reason(compared.value().cutoffs.front().status,
                   mwperf::CompressionUnavailableReasonV1::context_mismatch));
  CHECK_FALSE(compared.value().cutoffs.front().compression.available());
}

TEST_CASE("C30 comparison rejects contradictory transformation authority",
          "[c30][comparison][negative]") {
  const auto stationary = analysis(
      mwperf::ObservationSourceRoleV1::long_stationary_reference, '1', 10,
      12, 2);
  const auto finite = analysis(
      mwperf::ObservationSourceRoleV1::short_restart_reference, '2', 0, 15,
      0);
  const auto ensemble = analysis(
      mwperf::ObservationSourceRoleV1::weighted_ensemble, '3', 0, 14, 0);
  mwperf::DecoderTransformedProfileV1 transformed{
      digest('3'), digest('3'), digest('4'), digest('f'), {}};

  auto compared = mwperf::compare_compression_profiles_v1(
      stationary, finite, ensemble,
      {digest('f'), true, std::move(transformed)});
  REQUIRE_FALSE(compared);
  CHECK(compared.error().code ==
        "compression_comparison.ambiguous_transformation");
}
