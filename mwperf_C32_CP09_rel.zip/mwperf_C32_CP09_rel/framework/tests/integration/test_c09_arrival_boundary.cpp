#include <array>
#include <atomic>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct ParsedModel final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
  mwperf::QueueCatalog queues;
};

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c09-arrival-boundary";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory /
      (std::string(stem) + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string model_document(const std::string_view arrival) {
  return std::string(R"json({
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
                 "params":{"constraint":{"conflicts":[]},
                           "priority":["q0","q1"],
                           "max_search_states":null}},
    "arrival":)json") +
         std::string(arrival) + R"json(
  })json";
}

[[nodiscard]] ParsedModel parse_model(const std::string_view arrival) {
  auto document =
      mwperf::load_document(write_fixture("model", model_document(arrival)));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedModel{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] std::string transient_analysis() {
  return R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"law","kind":"transient_backlog_law",
                "parameters":{"horizons":[0,1]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":null,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{"atoms":[
      {"probability":0.2,
       "backlog":[{"queue_id":"q0","value":0},
                  {"queue_id":"q1","value":0}],
       "controller_state":{},
       "arrival_state":{"kind":"shared_round_state","state":"h0"},
       "static_context":{},"surrogate_initial":{"tag":"a"}},
      {"probability":0.3,
       "backlog":[{"queue_id":"q1","value":0},
                  {"queue_id":"q0","value":0}],
       "controller_state":{},
       "arrival_state":{"kind":"shared_round_state","state":"h0"},
       "static_context":{},"surrogate_initial":{"tag":"a"}},
      {"probability":0.5,
       "backlog":[{"queue_id":"q0","value":5},
                  {"queue_id":"q1","value":0}],
       "controller_state":{},
       "arrival_state":{"kind":"shared_round_state","state":"h1"},
       "static_context":{},"surrogate_initial":{"tag":"b"}}
    ]}}},
    "solver":{"kind":"enumerated",
              "parameters":{"linear_method":"dense_pivoted",
                            "max_iterations":null}}
  })json";
}

[[nodiscard]] ParsedPair parse_transient_pair(
    const std::string_view arrival) {
  ParsedModel parsed_model = parse_model(arrival);
  auto analysis_document =
      mwperf::load_document(write_fixture("analysis", transient_analysis()));
  REQUIRE(analysis_document);
  auto analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((!analysis ? analysis.error().code + ": " + analysis.error().message
                  : std::string{}));
  REQUIRE(analysis);
  const mwperf::CanonicalInputPair canonical =
      mwperf::canonicalize_authored_inputs(parsed_model.model,
                                           analysis.value());
  mwperf::InputFingerprintBundle fingerprints =
      mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(parsed_model.model),
                    std::move(analysis).value(), std::move(fingerprints),
                    std::move(parsed_model.queues)};
}

constexpr std::string_view kFixtureArrival = R"json({
  "family":"shared_joint_round_markov_renewal",
  "sources":[{"id":"s"}],
  "states":["h0","h1"],
  "initial":{"distribution":[{"state":"h0","probability":0.5},
                                {"state":"h1","probability":0.5}]},
  "outcomes":[
    {"state":"h0","next_state":"h0","probability":1,
     "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
    {"state":"h1","next_state":"h1","probability":1,
     "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]}
  ],
  "metadata":{}
})json";

[[nodiscard]] bool checkpoint_pending_code(const std::string& actual,
                                           const std::string_view expected) {
  return actual == expected;
}

[[nodiscard]] mwperf::ArrivalProductBindingIdentity product_identity(
    const mwperf::ArrivalBinding& binding) {
  return mwperf::ArrivalProductBindingIdentity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
}

[[nodiscard]] mwperf::Result<mwperf::detail::CompiledArrivalProduct>
unused_normalized_row_compiler(const mwperf::PreparedArrivalCompilation&) {
  return mwperf::Result<mwperf::detail::CompiledArrivalProduct>::failure(
      mwperf::Diagnostic{
          .category = mwperf::DiagnosticCategory::internal,
          .code = "c09_test_unused_arrival_slot",
          .message = "the normalized-row test invoked another slot",
          .authored_path = std::nullopt,
          .json_pointer = std::nullopt,
          .notes = {}});
}

[[nodiscard]] mwperf::Result<mwperf::detail::CompiledArrivalProduct>
selected_normalized_row_compiler(
    const mwperf::PreparedArrivalCompilation& request) {
  mwperf::ArrivalCapabilities capabilities;
  capabilities.exact_positive_support =
      mwperf::CapabilityAvailability::available;

  // Deliberately return a reversed child-owned copy. The registry must
  // overwrite it with its complete authoritative sequence.
  std::vector<mwperf::NormalizedArrivalRow> misleading(
      request.normalized_rows.rbegin(), request.normalized_rows.rend());
  std::vector<std::uint8_t> support(request.queues.size(), 0U);
  support[0U] = 1U;
  support[1U] = 1U;
  return mwperf::Result<mwperf::detail::CompiledArrivalProduct>::success(
      mwperf::detail::CompiledArrivalProduct{
          .family = mwperf::ArrivalFamily::independent_marked_renewal,
          .normalized_rows = std::move(misleading),
          .positive_support = std::move(support),
          .capabilities = std::move(capabilities),
          .canonical_law_data =
              std::vector<std::byte>{std::byte{0xc0}, std::byte{0x09}},
          .portable_schema = mwperf::PortableArrivalLawSchema::
              independent_marked_renewal_v1,
          .payload = std::make_shared<const std::uint8_t>(0U),
          .runtime = {},
          .iid_joint_table = std::nullopt,
          .moments = std::nullopt,
          .covariances = std::nullopt,
          .analytic_transform = std::nullopt,
          .joint_distribution = std::nullopt,
          .coordinate_distributions = std::nullopt,
          .replay_codec = std::nullopt,
          .unit_cube = std::nullopt,
          .finite_phase = std::nullopt,
          .transition_rows = std::nullopt,
          .stationary_phase_law = std::nullopt});
}

[[nodiscard]] mwperf::detail::ArrivalBackendRegistry
normalized_row_test_registry() {
  auto registry = mwperf::detail::c09_pending_arrival_registry();
  registry[0U].compile = unused_normalized_row_compiler;
  registry[1U].compile = unused_normalized_row_compiler;
  registry[2U].compile = unused_normalized_row_compiler;
  registry[3U].compile = selected_normalized_row_compiler;
  registry[4U].compile = unused_normalized_row_compiler;
  registry[5U].compile = unused_normalized_row_compiler;
  return registry;
}

}  // namespace

TEST_CASE("C09 baseline registry exposes six distinct pending child routes",
          "[c09][integration]") {
  const std::array<std::string_view, 6U> arrivals{
      R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":1}],"metadata":{}})json",
      R"json({"family":"periodic_global_phase","period":2,"phase":1,"sources":[{"id":"s","entries":[{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json",
      R"json({"family":"periodic_source_delays","period":2,"sources":[{"id":"s","delay":1,"entries":[{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json",
      R"json({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kind":"deterministic","d":1},"destination_pmf":[{"queue_id":"q0","probability":1}]}],"metadata":{}})json",
      R"json({"family":"independent_private_markov_renewal","sources":[{"id":"s","states":["on"],"initial":{"state":"on"},"gaps":[{"state":"on","d":1}],"transitions":[{"state":"on","next_state":"on","probability":1}],"destination_pmf":[{"queue_id":"q0","probability":1}]}],"metadata":{}})json",
      R"json({"family":"shared_joint_round_markov_renewal","sources":[{"id":"a"},{"id":"b"}],"states":["on"],"initial":{"state":"on"},"outcomes":[{"state":"on","next_state":"on","probability":1,"emissions":[{"source_id":"a","d":1,"queue_id":"q0"},{"source_id":"b","d":2,"queue_id":"q1"}]}],"metadata":{}})json",
  };
  const std::array<std::string_view, 6U> expected_codes{
      "arrival_backend_pending_c10_deterministic_trace",
      "arrival_backend_pending_c10_periodic_global_phase",
      "arrival_backend_pending_c10_periodic_source_delays",
      "arrival_backend_pending_c11_independent_marked_renewal",
      "arrival_backend_pending_c11_independent_private_markov_renewal",
      "arrival_backend_pending_c11_shared_joint_round_markov_renewal",
  };

  for (std::size_t index = 0U; index < arrivals.size(); ++index) {
    CAPTURE(index);
    ParsedModel parsed = parse_model(arrivals[index]);
    auto compiled = mwperf::detail::compile_arrival_law_with_registry(
        parsed.model.arrival, parsed.queues,
        mwperf::detail::c09_pending_arrival_registry());
    REQUIRE_FALSE(compiled);
    CHECK(compiled.error().category ==
          mwperf::DiagnosticCategory::unavailable);
    CHECK(checkpoint_pending_code(compiled.error().code,
                                  expected_codes[index]));
  }
}

TEST_CASE("C09 rejects compatibility-only arrival families before a backend",
          "[c09][integration][negative]") {
  ParsedModel parsed = parse_model(
      R"json({"family":"iid_table","alphabet":[{"id":"a","edges":[],"probability":1}]})json");
  auto compiled =
      mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  REQUIRE_FALSE(compiled);
  CHECK(compiled.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(compiled.error().code == "unsupported_arrival_family");
}

TEST_CASE("C09 retains and fingerprints its once-normalized authored rows",
          "[c09][integration][pmf]") {
  constexpr std::string_view kExactRows = R"json({
    "family":"independent_marked_renewal",
    "sources":[{
      "id":"s",
      "interarrival":{"kind":"finite_pmf","outcomes":[
        {"d":1,"probability":0.4},
        {"d":2,"probability":0.6}
      ]},
      "destination_pmf":[
        {"queue_id":"q0","probability":0.25},
        {"queue_id":"q1","probability":0.75}
      ]
    }],
    "metadata":{}
  })json";
  constexpr std::string_view kWithinToleranceRows = R"json({
    "family":"independent_marked_renewal",
    "sources":[{
      "id":"s",
      "interarrival":{"kind":"finite_pmf","outcomes":[
        {"d":1,"probability":0.4000000002},
        {"d":2,"probability":0.6000000003}
      ]},
      "destination_pmf":[
        {"queue_id":"q0","probability":0.25},
        {"queue_id":"q1","probability":0.75}
      ]
    }],
    "metadata":{}
  })json";
  constexpr std::string_view kReorderedRows = R"json({
    "family":"independent_marked_renewal",
    "sources":[{
      "id":"s",
      "interarrival":{"kind":"finite_pmf","outcomes":[
        {"d":2,"probability":0.6},
        {"d":1,"probability":0.4}
      ]},
      "destination_pmf":[
        {"queue_id":"q1","probability":0.75},
        {"queue_id":"q0","probability":0.25}
      ]
    }],
    "metadata":{}
  })json";

  ParsedModel exact = parse_model(kExactRows);
  ParsedModel adjusted = parse_model(kWithinToleranceRows);
  ParsedModel reordered = parse_model(kReorderedRows);
  const auto registry = normalized_row_test_registry();
  auto exact_law = mwperf::detail::compile_arrival_law_with_registry(
      exact.model.arrival, exact.queues, registry);
  auto adjusted_law = mwperf::detail::compile_arrival_law_with_registry(
      adjusted.model.arrival, adjusted.queues, registry);
  auto reordered_law = mwperf::detail::compile_arrival_law_with_registry(
      reordered.model.arrival, reordered.queues, registry);
  INFO((!exact_law ? exact_law.error().code + ": " +
                         exact_law.error().message
                   : std::string{}));
  INFO((!adjusted_law ? adjusted_law.error().code + ": " +
                            adjusted_law.error().message
                      : std::string{}));
  INFO((!reordered_law ? reordered_law.error().code + ": " +
                             reordered_law.error().message
                       : std::string{}));
  REQUIRE(exact_law);
  REQUIRE(adjusted_law);
  REQUIRE(reordered_law);

  const auto exact_rows =
      mwperf::testing::normalized_arrival_rows_for_testing(exact_law.value());
  const auto adjusted_rows =
      mwperf::testing::normalized_arrival_rows_for_testing(
          adjusted_law.value());
  REQUIRE(exact_rows.size() == 2U);
  REQUIRE(adjusted_rows.size() == 2U);
  CHECK(exact_rows[0U].kind ==
        mwperf::ArrivalCategoricalRowKind::finite_interarrival);
  CHECK(exact_rows[1U].kind ==
        mwperf::ArrivalCategoricalRowKind::destination);
  CHECK(exact_rows[0U].source_ordinal == 0U);
  CHECK(exact_rows[0U].state_ordinal == 0U);
  CHECK(exact_rows[0U].normalization_delta().is_zero());
  CHECK(adjusted_rows[0U].normalization_delta().to_canonical_string() ==
        "1/2000000000");
  REQUIRE(adjusted_rows[0U].pmf.normalized_weights().size() == 2U);
  CHECK(adjusted_rows[0U].pmf.normalized_weights()[0U]
            .to_canonical_string() == "2/5");
  CHECK(adjusted_rows[0U].pmf.normalized_weights()[1U]
            .to_canonical_string() == "3/5");
  CHECK(adjusted_rows[1U].normalization_delta().is_zero());

  // The child returned identical family bytes for both laws. Their law
  // identities must still differ because C09 fingerprints the exact authored
  // row and its signed normalization delta.
  CHECK_FALSE(mwperf::arrival_law_binding(exact_law.value()).law_digest ==
              mwperf::arrival_law_binding(adjusted_law.value()).law_digest);

  const auto reordered_rows =
      mwperf::testing::normalized_arrival_rows_for_testing(
          reordered_law.value());
  REQUIRE(reordered_rows.size() == 2U);
  CHECK(reordered_rows[0U].pmf.authored_probabilities()[0U]
            .exact_value()
            .to_canonical_string() == "3/5");
  CHECK(reordered_rows[1U].pmf.authored_probabilities()[0U]
            .exact_value()
            .to_canonical_string() == "3/4");
  CHECK(mwperf::positive_arrival_support(reordered_law.value()).bytes() ==
        mwperf::positive_arrival_support(exact_law.value()).bytes());
  CHECK_FALSE(mwperf::arrival_law_binding(exact_law.value()).law_digest ==
              mwperf::arrival_law_binding(reordered_law.value()).law_digest);
}

TEST_CASE("C09 normalizes a malformed duplicate-state logical row once",
          "[c09][integration][pmf][negative]") {
  ParsedModel parsed = parse_model(R"json({
    "family":"independent_private_markov_renewal",
    "sources":[{
      "id":"s",
      "states":["on"],
      "initial":{"state":"on"},
      "gaps":[{"state":"on","d":1}],
      "transitions":[
        {"state":"on","next_state":"on","probability":1}
      ],
      "destination_pmf":[{"queue_id":"q0","probability":1}]
    }],
    "metadata":{}
  })json");
  // C03 normally rejects this malformed declaration. Mutate the otherwise
  // well-formed typed fixture after parsing so the C09 registry boundary can
  // independently prove that duplicate declarations do not duplicate one
  // logical authored transition row before the C11 family diagnostic.
  auto& malformed_family =
      std::get<mwperf::IndependentPrivateMarkovRenewalArrival>(
          parsed.model.arrival.value);
  auto& malformed_states =
      malformed_family.sources.value[0U].states.value;
  malformed_states.push_back(malformed_states.front());

  std::size_t retained_transition_rows = 0U;
  std::size_t retained_total_rows = 0U;
  std::size_t retained_transition_atom_count = 0U;
  bool child_observed_duplicate_declaration = false;
  auto registry = normalized_row_test_registry();
  registry[4U].compile =
      [&](const mwperf::PreparedArrivalCompilation& request) {
        retained_total_rows = request.normalized_rows.size();
        for (const auto& row : request.normalized_rows) {
          if (row.kind ==
              mwperf::ArrivalCategoricalRowKind::private_transition) {
            ++retained_transition_rows;
            retained_transition_atom_count = row.pmf.size();
          }
        }
        if (const auto* family = std::get_if<
                mwperf::IndependentPrivateMarkovRenewalArrival>(
                &request.authored.value);
            family != nullptr && !family->sources.value.empty()) {
          const auto& states = family->sources.value[0U].states.value;
          child_observed_duplicate_declaration =
              states.size() == 2U && states[0U].value == states[1U].value;
        }
        return mwperf::Result<mwperf::detail::CompiledArrivalProduct>::failure(
            mwperf::Diagnostic{
                .category = mwperf::DiagnosticCategory::input_validation,
                .code = "fixture_duplicate_markov_state_declaration",
                .message =
                    "the family compiler rejected a duplicate state label",
                .authored_path = std::nullopt,
                .json_pointer = std::nullopt,
                .notes = {}});
      };

  auto compiled = mwperf::detail::compile_arrival_law_with_registry(
      parsed.model.arrival, parsed.queues, registry);
  REQUIRE_FALSE(compiled);
  CHECK(compiled.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(compiled.error().code ==
        "fixture_duplicate_markov_state_declaration");
  CHECK(child_observed_duplicate_declaration);
  CHECK(retained_total_rows == 2U);
  CHECK(retained_transition_rows == 1U);
  CHECK(retained_transition_atom_count == 1U);
}

TEST_CASE("C09 preserves a coupled initial law and emits one joint batch",
          "[c09][integration]") {
  ParsedPair pair = parse_transient_pair(kFixtureArrival);
  auto fixture = mwperf::testing::make_c09_correlated_fixture_law(pair.queues);
  INFO((!fixture ? fixture.error().code + ": " + fixture.error().message
                 : std::string{}));
  REQUIRE(fixture);
  auto fixture_owner = std::make_shared<const mwperf::CompiledArrivalLaw>(
      fixture.value());
  const mwperf::ArrivalBinding fixture_binding =
      mwperf::arrival_law_binding(*fixture_owner);

  std::shared_ptr<const mwperf::InitialPhysicalLaw> compiled_initial;
  mwperf::detail::ResolutionChildServices children;
  children.arrival =
      [fixture_owner, fixture_binding](
          const mwperf::AuthoredArrivalConfig&,
          const mwperf::PhysicalBindingIdentity& identity,
          std::span<const mwperf::BoundQueueReference> references,
          const mwperf::QueueCatalog& queues) {
        CHECK(identity.arrival_family == fixture_binding.family);
        CHECK(identity.timing == fixture_binding.timing);
        CHECK(identity.queue_cardinality == fixture_binding.queue_cardinality);
        CHECK(references.size() == 2U);
        CHECK(queues.size() == fixture_binding.queue_cardinality);
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            identity, fixture_owner);
      };
  children.support =
      [fixture_owner](
          const mwperf::detail::ArrivalCompilationToken& token,
          const mwperf::PhysicalBindingIdentity& identity,
          std::span<const mwperf::BoundQueueReference> references,
          const mwperf::QueueCatalog& queues) {
        CHECK(token.binding() == identity);
        CHECK(token.owner_for_adapter().get() == fixture_owner.get());
        CHECK(references.size() == 2U);
        CHECK(queues.size() == identity.queue_cardinality);
        return mwperf::Result<mwperf::QueueMask>::success(
            mwperf::positive_arrival_support(*fixture_owner));
      };
  children.initial =
      [fixture_owner, &compiled_initial](
          const mwperf::detail::ArrivalCompilationToken& token,
          const mwperf::ResolvedTransientInitialLaw& resolved,
          const mwperf::PhysicalBindingIdentity& identity,
          std::span<const mwperf::BoundQueueReference> references,
          const mwperf::QueueCatalog& queues)
      -> mwperf::Result<mwperf::detail::InitialCompilationToken> {
    CHECK(token.binding() == identity);
    CHECK(token.owner_for_adapter().get() == fixture_owner.get());
    CHECK(references.size() == 2U);
    CHECK(queues.size() == identity.queue_cardinality);
    auto compiled =
        mwperf::compile_initial_physical_law(resolved, *fixture_owner);
    if (!compiled) {
      return mwperf::Result<mwperf::detail::InitialCompilationToken>::failure(
          compiled.error());
    }
    compiled_initial = std::make_shared<const mwperf::InitialPhysicalLaw>(
        std::move(compiled).value());
    return mwperf::detail::InitialCompilationToken::for_fixture(
        identity, compiled_initial);
  };

  auto resolved = mwperf::detail::resolve_physical_instance_with_child_services(
      pair.model, pair.analysis, pair.fingerprints, children);
  INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                  : std::string{}));
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_law());
  REQUIRE(compiled_initial);
  auto opaque_arrival_recovery =
      mwperf::detail::CompiledArrivalAccess::get(resolved.value().arrival());
  REQUIRE_FALSE(opaque_arrival_recovery);
  CHECK(opaque_arrival_recovery.error().code ==
        "arrival_compiled_product_type_mismatch");
  auto opaque_initial_recovery = mwperf::detail::CompiledInitialLawAccess::get(
      *resolved.value().initial_law());
  REQUIRE_FALSE(opaque_initial_recovery);
  CHECK(opaque_initial_recovery.error().code ==
        "initial_compiled_product_type_mismatch");
  CHECK(resolved.value().positive_arrival_support().bytes() ==
        mwperf::positive_arrival_support(*fixture_owner).bytes());

  CHECK(compiled_initial->arrival_binding() ==
        mwperf::arrival_law_binding(*fixture_owner));

  const mwperf::PhysicalBindingIdentity physical_identity =
      resolved.value().arrival().identity();
  const mwperf::ArrivalProductBindingIdentity retained_identity =
      product_identity(fixture_binding);
  auto recovered_law =
      mwperf::detail::CompiledArrivalAccess::recover_for_testing(
          physical_identity, retained_identity, fixture_owner);
  REQUIRE(recovered_law);
  CHECK(recovered_law.value().get() == fixture_owner.get());
  auto recovered_initial =
      mwperf::detail::CompiledInitialLawAccess::recover_for_testing(
          physical_identity, retained_identity,
          resolved.value().initial_law()->law(), compiled_initial);
  REQUIRE(recovered_initial);
  CHECK(recovered_initial.value().get() == compiled_initial.get());

  const auto wrong_digest = mwperf::Digest256::from_hex(
      "0000000000000000000000000000000000000000000000000000000000000000");
  REQUIRE(wrong_digest);
  std::array<mwperf::ArrivalProductBindingIdentity, 5U> corrupt_identities{
      retained_identity, retained_identity, retained_identity,
      retained_identity, retained_identity};
  corrupt_identities[0U].family =
      mwperf::ArrivalFamily::deterministic_trace;
  corrupt_identities[1U].timing = static_cast<mwperf::TimingConvention>(99U);
  ++corrupt_identities[2U].queue_cardinality;
  corrupt_identities[3U].law_digest = wrong_digest.value();
  corrupt_identities[4U].catalog_digest = wrong_digest.value();
  for (const auto& corrupt : corrupt_identities) {
    auto rejected_law =
        mwperf::detail::CompiledArrivalAccess::recover_for_testing(
            physical_identity, corrupt, fixture_owner);
    REQUIRE_FALSE(rejected_law);
    CHECK(rejected_law.error().category ==
          mwperf::DiagnosticCategory::internal);
    CHECK(rejected_law.error().code ==
          "arrival_compiled_product_binding_mismatch");

    auto rejected_initial =
        mwperf::detail::CompiledInitialLawAccess::recover_for_testing(
            physical_identity, corrupt,
            resolved.value().initial_law()->law(), compiled_initial);
    REQUIRE_FALSE(rejected_initial);
    CHECK(rejected_initial.error().category ==
          mwperf::DiagnosticCategory::internal);
    CHECK(rejected_initial.error().code ==
          "initial_compiled_product_binding_mismatch");
  }

  // Even mutually consistent carrier metadata cannot disguise a recovered
  // object's family, timing convention, or queue cardinality.
  std::array<mwperf::PhysicalBindingIdentity, 3U> forged_physical{
      physical_identity, physical_identity, physical_identity};
  forged_physical[0U].arrival_family = corrupt_identities[0U].family;
  forged_physical[1U].timing = corrupt_identities[1U].timing;
  forged_physical[2U].queue_cardinality =
      corrupt_identities[2U].queue_cardinality;
  for (std::size_t index = 0U; index < forged_physical.size(); ++index) {
    auto rejected_law =
        mwperf::detail::CompiledArrivalAccess::recover_for_testing(
            forged_physical[index], corrupt_identities[index], fixture_owner);
    REQUIRE_FALSE(rejected_law);
    CHECK(rejected_law.error().code ==
          "arrival_compiled_product_binding_mismatch");

    auto rejected_initial =
        mwperf::detail::CompiledInitialLawAccess::recover_for_testing(
            forged_physical[index], corrupt_identities[index],
            resolved.value().initial_law()->law(), compiled_initial);
    REQUIRE_FALSE(rejected_initial);
    CHECK(rejected_initial.error().code ==
          "initial_compiled_product_binding_mismatch");
  }

  auto wrong_family_law = resolved.value().initial_law()->law();
  wrong_family_law.atoms[0U].arrival_state = mwperf::RenewalOrigin{};
  auto wrong_family_initial = mwperf::compile_initial_physical_law(
      wrong_family_law, *fixture_owner);
  REQUIRE_FALSE(wrong_family_initial);
  CHECK(wrong_family_initial.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(wrong_family_initial.error().code ==
        "arrival_initial_state_family_mismatch");

  auto unreachable_law = resolved.value().initial_law()->law();
  unreachable_law.atoms[0U].arrival_state =
      mwperf::SharedRoundState{"unreachable"};
  auto unreachable_initial = mwperf::compile_initial_physical_law(
      unreachable_law, *fixture_owner);
  REQUIRE_FALSE(unreachable_initial);
  CHECK(unreachable_initial.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(unreachable_initial.error().code ==
        "arrival_initial_state_unreachable");

  CHECK(compiled_initial->original_pmf().size() == 3U);
  CHECK(compiled_initial->original_pmf()
            .normalized_weights()[0U]
            .to_canonical_string() == "1/5");
  CHECK(compiled_initial->original_pmf()
            .normalized_weights()[1U]
            .to_canonical_string() == "3/10");
  CHECK(compiled_initial->original_pmf()
            .normalized_weights()[2U]
            .to_canonical_string() == "1/2");
  CHECK(compiled_initial->normalization_delta().is_zero());
  REQUIRE(compiled_initial->atoms().size() == 2U);
  REQUIRE(compiled_initial->original_to_atom().size() == 3U);
  CHECK(compiled_initial->original_to_atom()[0U] == 0U);
  CHECK(compiled_initial->original_to_atom()[1U] == 0U);
  CHECK(compiled_initial->original_to_atom()[2U] == 1U);
  CHECK(compiled_initial->atoms()[0U]
            .probability.to_canonical_string() == "1/2");
  CHECK(compiled_initial->atoms()[1U]
            .probability.to_canonical_string() == "1/2");
  CHECK(compiled_initial->atoms()[0U].backlog[0U].is_zero());
  CHECK(compiled_initial->atoms()[1U].backlog[0U].to_decimal_string() == "5");
  REQUIRE(std::holds_alternative<mwperf::SharedRoundState>(
      compiled_initial->atoms()[0U].arrival_state));
  REQUIRE(std::holds_alternative<mwperf::SharedRoundState>(
      compiled_initial->atoms()[1U].arrival_state));
  CHECK(std::get<mwperf::SharedRoundState>(
            compiled_initial->atoms()[0U].arrival_state)
            .state == "h0");
  CHECK(std::get<mwperf::SharedRoundState>(
            compiled_initial->atoms()[1U].arrival_state)
            .state == "h1");

  auto instance_key = mwperf::make_physical_reference_instance_key(
      pair.fingerprints.combined, mwperf::BigNat(0U));
  REQUIRE(instance_key);
  mwperf::DeterministicRng rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed(907U), mwperf::StageTag::configured_arrival,
      instance_key.value());
  const mwperf::Digest256 expected_stream_identity = rng.stream_identity();
  auto stream = mwperf::make_configured_arrival_stream_key(
      *fixture_owner, std::move(rng));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      *fixture_owner, compiled_initial->atoms()[0U].arrival_state,
      std::move(stream).value());
  REQUIRE(process);

  auto before = mwperf::testing::snapshot_arrival_process(process.value());
  REQUIRE(before);
  CHECK(before.value().expected_slot.is_zero());
  CHECK(before.value().rng.consumed_words().is_zero());
  CHECK(before.value().rng.stream_identity() == expected_stream_identity);

  auto step = mwperf::next_arrival_step(process.value(), mwperf::BigNat(0U));
  INFO((!step ? step.error().code + ": " + step.error().message
              : std::string{}));
  REQUIRE(step);
  CHECK(step.value().authored_slot.is_zero());
  CHECK(step.value().physical_arrival_epoch() == mwperf::BigNat(1U));
  CHECK(step.value().law_digest == fixture_binding.law_digest);
  CHECK(step.value().batch.binding().has_value());
  CHECK(*step.value().batch.binding() ==
        mwperf::arrival_law_binding(*fixture_owner));
  CHECK(mwperf::arrival_phase_family(step.value().phase_before) ==
        mwperf::ArrivalFamily::shared_joint_round_markov_renewal);
  CHECK(mwperf::arrival_phase_digest(step.value().phase_before) ==
        before.value().phase_digest);
  REQUIRE_FALSE(
      mwperf::arrival_phase_canonical_state(step.value().phase_before)
          .empty());
  CHECK(mwperf::arrival_phase_canonical_state(step.value().phase_before)
            .back() == std::byte{0});
  CHECK(mwperf::arrival_phases_share_cursor(step.value().phase_before,
                                             step.value().phase_after));

  auto queue0 = pair.queues.index_at(0U);
  auto queue1 = pair.queues.index_at(1U);
  REQUIRE(queue0);
  REQUIRE(queue1);
  auto first = mwperf::project_arrival_count(step.value().batch,
                                             queue0.value(), fixture_binding);
  auto second = mwperf::project_arrival_count(step.value().batch,
                                              queue1.value(), fixture_binding);
  REQUIRE(first);
  REQUIRE(second);
  const bool first_joint_outcome =
      first.value() == mwperf::BigNat(1U) &&
      second.value() == mwperf::BigNat(4U);
  const bool second_joint_outcome =
      first.value() == mwperf::BigNat(3U) &&
      second.value() == mwperf::BigNat(2U);
  CHECK((first_joint_outcome || second_joint_outcome));

  auto after = mwperf::testing::snapshot_arrival_process(process.value());
  REQUIRE(after);
  CHECK(after.value().expected_slot == mwperf::BigNat(1U));
  CHECK(after.value().rng.consumed_words().to_decimal_string() == "1");

  // Projection is a pure read of the one returned joint vector; requesting
  // both coordinates cannot consume another arrival word or advance phase.
  auto first_again = mwperf::project_arrival_count(
      step.value().batch, queue0.value(), fixture_binding);
  auto second_again = mwperf::project_arrival_count(
      step.value().batch, queue1.value(), fixture_binding);
  auto after_projection =
      mwperf::testing::snapshot_arrival_process(process.value());
  REQUIRE(first_again);
  REQUIRE(second_again);
  REQUIRE(after_projection);
  CHECK(first_again.value() == first.value());
  CHECK(second_again.value() == second.value());
  CHECK(after_projection.value().expected_slot == after.value().expected_slot);
  CHECK(after_projection.value().rng.stream_identity() ==
        after.value().rng.stream_identity());
  CHECK(after_projection.value().rng.state_words() ==
        after.value().rng.state_words());
  CHECK(after_projection.value().rng.consumed_words() ==
        after.value().rng.consumed_words());
}
