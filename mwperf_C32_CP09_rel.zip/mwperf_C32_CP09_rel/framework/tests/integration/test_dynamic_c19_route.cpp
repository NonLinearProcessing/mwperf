#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/stationary/finite_prefix_summary.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(
      mwperf::BigInt{numerator}, mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

struct FinitePrefixIidInput final {
  mwperf::testing::c16_designated_detail::InputV1 input;
  std::pair<mwperf::ArrivalPhase, mwperf::ArrivalPhase> phases;
};

[[nodiscard]] FinitePrefixIidInput finite_prefix_iid_input() {
  auto source = mwperf::testing::c17::make_shared_arrival_instance();
  auto configured = mwperf::testing::make_c09_correlated_fixture_law(
      source.queues(), mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::
          portable_iid_bernoulli_joint_table);
  REQUIRE(configured);
  auto arrival = std::make_shared<const mwperf::CompiledArrivalLaw>(
      std::move(configured).value());
  auto rebound =
      mwperf::testing::C19FixtureAccess::bind_resolved_arrival_for_testing(
          source, arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);

  auto instance_key = mwperf::make_physical_reference_instance_key(
      rebound.value().fingerprints().combined, mwperf::BigNat{0U});
  REQUIRE(instance_key);
  const auto phase = [&](const std::string& state,
                         const std::uint64_t seed) {
    auto stream = mwperf::make_configured_arrival_stream_key(
        *arrival,
        mwperf::derive_rng_stream(
            mwperf::MasterSeed{seed},
            mwperf::StageTag::configured_arrival,
            instance_key.value()));
    REQUIRE(stream);
    auto process = mwperf::instantiate_arrival_process(
        *arrival,
        mwperf::ArrivalInitialState{mwperf::SharedRoundState{state}},
        std::move(stream).value());
    REQUIRE(process);
    auto first = mwperf::next_arrival_step(process.value(),
                                           mwperf::BigNat{0U});
    REQUIRE(first);
    return first.value().phase_before;
  };
  auto phase_zero = phase("h0", 0xC2710U);
  auto phase_one = phase("h1", 0xC2711U);
  REQUIRE_FALSE(mwperf::testing::c17::same_phase(phase_zero, phase_one));

  auto request = mwperf::parse_metric_request(
      rebound.value().analysis_spec().metrics.front(),
      rebound.value().queues());
  REQUIRE(request);
  std::vector<mwperf::MetricRequest> requests{request.value()};
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  return {{std::move(rebound).value(), std::move(arrival),
           std::move(requirements), std::move(request).value()},
          {std::move(phase_zero), std::move(phase_one)}};
}

}  // namespace

TEST_CASE(
    "C27 dynamic scalar seal feeds one native K-wide C19 summary",
    "[c27][integration]") {
  const std::vector<mwperf::ExactRational> service{
      rational(0), rational(3, 4), rational(2, 3),
      rational(5, 6), rational(4, 5), rational(7, 8)};
  const mwperf::ExactRational tail_service = rational(3, 4);
  auto iid_input = finite_prefix_iid_input();
  auto fixture = mwperf::testing::c17::
      make_finite_prefix_constant_tail_framework_from_input(
          service, tail_service, std::move(iid_input.input),
          mwperf::BackendRouteKindV1::analytic_metric_family,
          std::optional<std::pair<mwperf::ArrivalPhase,
                                  mwperf::ArrivalPhase>>{
              std::move(iid_input.phases)});

  REQUIRE(mwperf::v0_witness_report(fixture.framework).passed());
  REQUIRE(fixture.ordered_targets.size() == 1U);
  CHECK((fixture.descriptor.core.payload_class ==
         mwperf::PayloadClassV1{
             mwperf::PayloadClassTagV1::
                 finite_prefix_constant_tail_response_v1,
             1U}));
  CHECK(fixture.descriptor.core.runtime_access ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  CHECK(fixture.descriptor.core.phase.payload_phase ==
        mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(fixture.descriptor.core.tail.kind ==
        mwperf::TailRepresentationKindV1::constant_response);
  CHECK(fixture.descriptor.core.tail.boundary ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{6U}});

  auto response = mwperf::audited_response_law(fixture.framework);
  INFO((response ? std::string{}
                 : response.error().code + ": " +
                       response.error().message));
  REQUIRE(response);

  // The dynamic seal has exactly the generic phase-free scalar facade used
  // by C19.  It is neither folded into the legacy K=2 facade nor promoted to
  // a phase-state response.
  auto legacy = mwperf::audited_three_bin_response(fixture.framework);
  REQUIRE_FALSE(legacy);
  CHECK(legacy.error().code == "c17.audited_three_bin_unavailable");
  auto phased = mwperf::audited_phase_response(fixture.framework);
  REQUIRE_FALSE(phased);
  CHECK(phased.error().code == "c17.audited_phase_response_unavailable");
  auto rows = mwperf::audited_row_provider(fixture.framework);
  REQUIRE_FALSE(rows);
  CHECK(rows.error().code == "c17.audited_row_unavailable");
  auto slots = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE_FALSE(slots);
  CHECK(slots.error().code == "c17.audited_slot_unavailable");

  auto projected_arrival = mwperf::ArrivalLaw::from_audited(response.value());
  INFO((projected_arrival
            ? std::string{}
            : projected_arrival.error().code + ": " +
                  projected_arrival.error().message));
  REQUIRE(projected_arrival);
  REQUIRE(projected_arrival.value().atoms().size() == 2U);
  CHECK((projected_arrival.value().atoms()[0U] ==
         mwperf::ScalarArrivalMassV1{mwperf::BigNat{0U}, rational(1, 2)}));
  CHECK((projected_arrival.value().atoms()[1U] ==
         mwperf::ScalarArrivalMassV1{mwperf::BigNat{1U}, rational(1, 2)}));
  CHECK(projected_arrival.value().mean() == rational(1, 2));

  auto result =
      mwperf::summarize_finite_prefix_iid_stationary_unique(response.value());
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  const mwperf::FinitePrefixIidSummary& summary = result.value();

  CHECK(summary.cutoff() == mwperf::BigNat{5U});
  REQUIRE(summary.service_by_level().size() == service.size());
  for (std::size_t level = 0U; level < service.size(); ++level) {
    INFO("level=" << level);
    CHECK(summary.service_by_level()[level] == service[level]);
  }
  CHECK((summary.tail_coefficient() ==
         mwperf::FinitePrefixConstantTailCoefficientV1{
             mwperf::BigNat{6U}, tail_service}));

  // Anti-fold: every native coefficient beyond the legacy K=2 boundary is
  // retained, including nonmonotonicity and values strictly above c.
  CHECK(summary.service_by_level()[3U] != summary.service_by_level()[2U]);
  CHECK(summary.service_by_level()[3U] != summary.service_by_level()[4U]);
  CHECK(summary.service_by_level()[4U] != summary.service_by_level()[5U]);
  for (std::size_t level = 3U; level <= 5U; ++level) {
    CHECK(summary.service_by_level()[level] > tail_service);
  }

  CHECK(summary.status() ==
        mwperf::AnalyticStationaryStatusV1::strict_tail_stable);
  CHECK(summary.arrival_mean() == rational(1, 2));
  CHECK(summary.tail_slack_applicability() ==
        mwperf::TailSlackApplicabilityV1::applicable);
  CHECK(summary.tail_slack() ==
        std::optional<mwperf::ExactRational>{rational(1, 4)});
  CHECK(summary.sojourn_counting_convention() ==
        mwperf::MeanSojournCountingConventionV1::includes_departure_slot);
  CHECK(summary.diagnostics().normalization_residual.is_zero());
  CHECK(summary.diagnostics().invariance_residual.is_zero());

  REQUIRE(summary.prefix_masses().has_value());
  REQUIRE(summary.aggregate_tail_mass().has_value());
  const auto& prefix = *summary.prefix_masses();
  REQUIRE(prefix.size() == service.size());
  mwperf::ExactRational total = *summary.aggregate_tail_mass();
  for (const auto& mass : prefix) total = total + mass;
  CHECK(total == mwperf::ExactRational::one());

  // These are exactly the native summary projections consumed by C27's
  // unchanged empty, PMF-through-{0,1,2}, threshold-3 tail, first-mean, and
  // conditioned-service clauses.
  CHECK(prefix.front().is_positive());
  for (std::size_t maximum_level = 0U; maximum_level <= 2U;
       ++maximum_level) {
    mwperf::ExactRational coarsened_tail = *summary.aggregate_tail_mass();
    for (std::size_t level = maximum_level + 1U; level < prefix.size();
         ++level) {
      coarsened_tail = coarsened_tail + prefix[level];
    }
    mwperf::ExactRational partition = coarsened_tail;
    for (std::size_t level = 0U; level <= maximum_level; ++level) {
      partition = partition + prefix[level];
    }
    CHECK(partition == mwperf::ExactRational::one());
  }
  mwperf::ExactRational tail_from_three = *summary.aggregate_tail_mass();
  for (std::size_t level = 3U; level < prefix.size(); ++level) {
    tail_from_three = tail_from_three + prefix[level];
  }
  CHECK(tail_from_three == mwperf::ExactRational::one() - prefix[0U] -
                               prefix[1U] - prefix[2U]);
  CHECK(tail_from_three != tail_service);
  REQUIRE(summary.exact_mean_backlog().has_value());
  REQUIRE(summary.numerical_mean_backlog().has_value());
  CHECK_FALSE(summary.exact_mean_sojourn().has_value());
  CHECK_FALSE(summary.numerical_mean_sojourn().has_value());
  for (const std::size_t level : {0U, 1U, 2U}) {
    CHECK(prefix[level].is_positive());
    CHECK(summary.service_by_level()[level] == service[level]);
  }

  const auto& identity = summary.law_identity();
  CHECK(identity.payload_phase() == mwperf::PayloadPhaseKindV1::phase_free);
  CHECK(identity.cutoff() ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{5U}});
  CHECK(identity.tail_service() ==
        std::optional<mwperf::ExactRational>{tail_service});
  CHECK(identity.result_scope() == mwperf::MetricResultScopeV1::surrogate_law);
  CHECK(identity.target() == fixture.ordered_targets.front());
  const auto construction_targets = identity.construction_targets();
  REQUIRE(construction_targets.size() == fixture.instance.queues().size());
  CHECK(construction_targets.size() == 3U);
  for (std::size_t ordinal = 0U; ordinal < construction_targets.size();
       ++ordinal) {
    CHECK(construction_targets[ordinal] ==
          fixture.instance.queues().entries()[ordinal].id);
  }
  CHECK(construction_targets.size() > fixture.ordered_targets.size());
  REQUIRE(identity.accepted_metric_clause().has_value());
  REQUIRE(identity.realized_metric_binding().has_value());
  CHECK(identity.response_stage() ==
        std::optional<mwperf::ResponseProductStageV1>{
            mwperf::ResponseProductStageV1::raw_response});
  CHECK(identity.response_product() ==
        std::optional<mwperf::ArtifactObjectReferenceV1>{
            summary.response_product_identity()});
  CHECK(summary.response_identity() != summary.response_product_identity());
}
