#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct ParsedArrival final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

struct ExpectedEntry final {
  std::size_t queue;
  std::string_view count;
};

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c10-arrival-dispatch";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string model_document(const std::string_view arrival) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
                 "params":{"constraint":{"conflicts":[]},
                           "priority":["q0","q1","q2"],
                           "max_search_states":null}},
    "arrival":)json") +
         std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] ParsedArrival parse_arrival(const std::string_view arrival) {
  auto document = mwperf::load_document(write_fixture(model_document(arrival)));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedArrival{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t realization) {
  auto digest = mwperf::sha256(std::span<const std::byte>{});
  REQUIRE(digest);
  auto key = mwperf::make_physical_reference_instance_key(
      digest.value(), mwperf::BigNat(realization));
  REQUIRE(key);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::ArrivalInitialState& initial_state,
    const std::uint64_t seed = 1001U,
    const std::uint64_t realization = 0U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, realization));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, initial_state, std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

void check_batch(const mwperf::ArrivalStep& step,
                 const std::span<const ExpectedEntry> expected) {
  REQUIRE(step.batch.entries().size() == expected.size());
  for (std::size_t index = 0U; index < expected.size(); ++index) {
    CHECK(step.batch.entries()[index].queue.ordinal() == expected[index].queue);
    CHECK(step.batch.entries()[index].count.to_decimal_string() ==
          expected[index].count);
  }
  CHECK(step.physical_arrival_epoch() == step.authored_slot + mwperf::BigNat(1U));
}

void check_same_step(const mwperf::ArrivalStep& left,
                     const mwperf::ArrivalStep& right) {
  CHECK(left.authored_slot == right.authored_slot);
  CHECK(left.batch == right.batch);
  CHECK(left.law_digest == right.law_digest);
  CHECK(left.realization_identity == right.realization_identity);
  CHECK(mwperf::arrival_phase_family(left.phase_before) ==
        mwperf::arrival_phase_family(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_before) ==
        mwperf::arrival_phase_digest(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_after) ==
        mwperf::arrival_phase_digest(right.phase_after));
  const auto left_before =
      mwperf::arrival_phase_canonical_state(left.phase_before);
  const auto right_before =
      mwperf::arrival_phase_canonical_state(right.phase_before);
  CHECK(std::vector<std::byte>(left_before.begin(), left_before.end()) ==
        std::vector<std::byte>(right_before.begin(), right_before.end()));
  const auto left_after = mwperf::arrival_phase_canonical_state(left.phase_after);
  const auto right_after =
      mwperf::arrival_phase_canonical_state(right.phase_after);
  CHECK(std::vector<std::byte>(left_after.begin(), left_after.end()) ==
        std::vector<std::byte>(right_after.begin(), right_after.end()));
}

void check_conservative_capabilities(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::PortableArrivalLawSchema expected_schema) {
  const mwperf::ArrivalCapabilities capabilities =
      mwperf::arrival_capabilities(law);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());

  const mwperf::BuilderArrivalView view = mwperf::builder_arrival_view(law);
  CHECK(view.configured_law().schema == expected_schema);
  CHECK(view.configured_law().version == 1U);
  CHECK(view.binding() == mwperf::arrival_law_binding(law));
  CHECK(view.capabilities() == capabilities);
  CHECK_FALSE(view.configured_law().canonical_data.empty());
}

}  // namespace

TEST_CASE("C10 canonical deterministic families dispatch through the C09 ABI",
          "[c10][integration]") {
  struct Fixture final {
    std::string_view arrival;
    mwperf::ArrivalFamily family;
    mwperf::PortableArrivalLawSchema schema;
    mwperf::ArrivalInitialState initial;
    std::vector<std::vector<ExpectedEntry>> expected;
  };

  const std::vector<Fixture> fixtures{
      {R"json({"family":"deterministic_trace","events":[
          {"slot":0,"queue_id":"q0","count":2},
          {"slot":2,"queue_id":"q1","count":1}],"metadata":{}})json",
       mwperf::ArrivalFamily::deterministic_trace,
       mwperf::PortableArrivalLawSchema::deterministic_trace_v1,
       mwperf::TraceOrigin{},
       {{{0U, "2"}}, {}, {{1U, "1"}}, {}, {}}},
      {R"json({"family":"periodic_global_phase","period":4,"phase":1,
          "sources":[
            {"id":"first","entries":[
              {"offset":0,"queue_id":"q0","count":1},
              {"offset":3,"queue_id":"q1","count":2}]},
            {"id":"second","entries":[
              {"offset":0,"queue_id":"q0","count":2}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::periodic_global_phase,
       mwperf::PortableArrivalLawSchema::periodic_global_phase_v1,
       mwperf::GlobalPeriodicOrigin{},
       {{{1U, "2"}}, {{0U, "3"}}, {}, {}, {{1U, "2"}}, {{0U, "3"}}}},
      {R"json({"family":"periodic_source_delays","period":3,
          "sources":[
            {"id":"first","delay":2,"entries":[
              {"offset":0,"queue_id":"q0","count":1}]},
            {"id":"second","delay":1,"entries":[
              {"offset":2,"queue_id":"q1","count":2}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::periodic_source_delays,
       mwperf::PortableArrivalLawSchema::periodic_source_delays_v1,
       mwperf::SourceDelayOrigin{},
       {{}, {}, {{0U, "1"}}, {{1U, "2"}}, {}, {{0U, "1"}},
        {{1U, "2"}}}},
  };

  for (const Fixture& fixture : fixtures) {
    CAPTURE(fixture.family);
    ParsedArrival parsed = parse_arrival(fixture.arrival);
    auto compiled =
        mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    INFO((!compiled ? compiled.error().code + ": " + compiled.error().message
                    : std::string{}));
    REQUIRE(compiled);
    CHECK(compiled.value().family() == fixture.family);
    check_conservative_capabilities(compiled.value(), fixture.schema);

    const mwperf::QueueMask support =
        mwperf::positive_arrival_support(compiled.value());
    REQUIRE(support.size() == 3U);
    CHECK(support.bytes() == std::vector<std::uint8_t>{1U, 1U, 0U});

    mwperf::ArrivalProcess first =
        instantiate(compiled.value(), fixture.initial, 701U, 4U);
    mwperf::ArrivalProcess replay =
        instantiate(compiled.value(), fixture.initial, 701U, 4U);
    auto first_before = mwperf::testing::snapshot_arrival_process(first);
    auto replay_before = mwperf::testing::snapshot_arrival_process(replay);
    REQUIRE(first_before);
    REQUIRE(replay_before);
    CHECK(first_before.value().rng.consumed_words().is_zero());
    CHECK(replay_before.value().rng.consumed_words().is_zero());

    for (std::size_t slot = 0U; slot < fixture.expected.size(); ++slot) {
      auto first_step =
          mwperf::next_arrival_step(first, mwperf::BigNat(slot));
      auto replay_step =
          mwperf::next_arrival_step(replay, mwperf::BigNat(slot));
      REQUIRE(first_step);
      REQUIRE(replay_step);
      check_batch(first_step.value(), fixture.expected[slot]);
      check_same_step(first_step.value(), replay_step.value());
    }

    auto first_after = mwperf::testing::snapshot_arrival_process(first);
    auto replay_after = mwperf::testing::snapshot_arrival_process(replay);
    REQUIRE(first_after);
    REQUIRE(replay_after);
    CHECK(first_after.value().rng.consumed_words().is_zero());
    CHECK(replay_after.value().rng.consumed_words().is_zero());
    CHECK(first_after.value().rng.stream_identity() ==
          replay_after.value().rng.stream_identity());
  }
}

TEST_CASE("C10 slot-zero trace packets are admitted only after slot-zero service",
          "[c10][integration]") {
  ParsedArrival parsed = parse_arrival(
      R"json({"family":"deterministic_trace","events":[
        {"slot":0,"queue_id":"q0","count":3}],"metadata":{}})json");
  auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  REQUIRE(law);
  mwperf::ArrivalProcess process =
      instantiate(law.value(), mwperf::TraceOrigin{});

  const mwperf::BigNat predecision_backlog(0U);
  const bool scheduled_service = true;
  const mwperf::BigNat after_early_service =
      predecision_backlog.is_zero() && scheduled_service
          ? mwperf::BigNat(0U)
          : predecision_backlog;
  CHECK(after_early_service.is_zero());

  auto arrivals = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
  REQUIRE(arrivals);
  const std::vector<ExpectedEntry> expected{{0U, "3"}};
  check_batch(arrivals.value(), expected);
  const mwperf::BigNat post_slot_backlog =
      after_early_service + arrivals.value().batch.entries()[0U].count;
  CHECK(post_slot_backlog == mwperf::BigNat(3U));
  CHECK(arrivals.value().physical_arrival_epoch() == mwperf::BigNat(1U));
}

TEST_CASE("C10 leaves C11 pending and compatibility arrivals unsupported",
          "[c10][integration][negative]") {
  const std::vector<std::pair<std::string_view, std::string_view>> pending{
      {R"json({"family":"independent_marked_renewal","sources":[{
        "id":"s","interarrival":{"kind":"deterministic","d":1},
        "destination_pmf":[{"queue_id":"q0","probability":1}]}],
        "metadata":{}})json",
       "arrival_backend_pending_c11_independent_marked_renewal"},
      {R"json({"family":"independent_private_markov_renewal","sources":[{
        "id":"s","states":["on"],"initial":{"state":"on"},
        "gaps":[{"state":"on","d":1}],
        "transitions":[{"state":"on","next_state":"on","probability":1}],
        "destination_pmf":[{"queue_id":"q0","probability":1}]}],
        "metadata":{}})json",
       "arrival_backend_pending_c11_independent_private_markov_renewal"},
      {R"json({"family":"shared_joint_round_markov_renewal",
        "sources":[{"id":"s"}],"states":["on"],
        "initial":{"state":"on"},
        "outcomes":[{"state":"on","next_state":"on","probability":1,
          "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]}],
        "metadata":{}})json",
       "arrival_backend_pending_c11_shared_joint_round_markov_renewal"},
  };

  for (const auto& [arrival, code] : pending) {
    ParsedArrival parsed = parse_arrival(arrival);
    auto law = mwperf::detail::compile_arrival_law_with_registry(
        parsed.model.arrival, parsed.queues,
        mwperf::detail::c10_arrival_registry());
    REQUIRE_FALSE(law);
    CHECK(law.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(law.error().code == code);
  }

  ParsedArrival compatibility = parse_arrival(
      R"json({"family":"iid_table","alphabet":[{
        "id":"empty","edges":[],"probability":1}]})json");
  auto unsupported = mwperf::compile_arrival_law(
      compatibility.model.arrival, compatibility.queues);
  REQUIRE_FALSE(unsupported);
  CHECK(unsupported.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(unsupported.error().code == "unsupported_arrival_family");
}
