#include <algorithm>
#include <cmath>
#include <optional>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/compression_analysis.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

[[nodiscard]] const mwperf::ExactRational& value_of(
    const mwperf::CompressionQuantityV1& quantity) {
  REQUIRE(quantity.available());
  REQUIRE(quantity.estimate);
  return quantity.estimate->value;
}

[[nodiscard]] mwperf::PortableScientificScalar binary(const double value) {
  auto result = mwperf::PortableScientificScalar::from_binary64(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ObservationScalarV1 enclosed_scalar(
    const double value, const double absolute_error = 0.0) {
  return {binary(value),
          mwperf::ObservationNumericalEnclosureV1{
              binary(absolute_error),
              binary(std::abs(value) + absolute_error)}};
}

[[nodiscard]] mwperf::ConstructionObservationBundleV1 finite_closure_bundle(
    const bool uncertain_prefix_center = false,
    const mwperf::ObservationSourceRoleV1 role =
        mwperf::ObservationSourceRoleV1::weighted_ensemble) {
  auto bundle = mwperf::testing::c30::exact_bundle(
      role);
  auto initial_law_digest =
      mwperf::registered_empty_backlog_initial_law_digest_v1();
  REQUIRE(initial_law_digest);
  bundle.initialization =
      {"empty_backlog_v1", std::move(initial_law_digest).value()};
  bundle.bindings.arrival.target_arrival =
      mwperf::ExactTargetArrivalMarginalV1{
          {{mwperf::BigNat{0U}, mwperf::ExactRational::one()}}};
  bundle.bindings.arrival.mean = mwperf::ExactRational::zero();
  bundle.bindings.arrival.second_moment = mwperf::ExactRational::zero();
  auto& block = bundle.replications.front().blocks.front();
  for (auto& row : block.levels) {
    row.served_mass = mwperf::testing::c30::scalar(0);
  }

  if (!uncertain_prefix_center) {
    return bundle;
  }

  bundle.scalar_representation =
      mwperf::ObservationScalarRepresentationV1::enclosed_binary64;
  block.levels[0].exposure_mass = enclosed_scalar(1.0);
  block.levels[0].served_mass = enclosed_scalar(0.0);
  block.levels[1].exposure_mass = enclosed_scalar(1.0);
  block.levels[1].served_mass = enclosed_scalar(0.0, 0.125);
  block.levels[2].exposure_mass = enclosed_scalar(2.0);
  block.levels[2].served_mass = enclosed_scalar(0.0);
  block.exposure_mass_balance.recorded_mass = enclosed_scalar(4.0);
  block.exposure_mass_balance.signed_mass_defect = enclosed_scalar(0.0);
  block.initial_boundary_law.rows.front().mass = enclosed_scalar(1.0);
  block.initial_boundary_law.mass_balance.recorded_mass = enclosed_scalar(1.0);
  block.initial_boundary_law.mass_balance.signed_mass_defect =
      enclosed_scalar(0.0);
  block.committed_boundary_law.rows.front().mass = enclosed_scalar(1.0);
  block.committed_boundary_law.mass_balance.recorded_mass = enclosed_scalar(1.0);
  block.committed_boundary_law.mass_balance.signed_mass_defect =
      enclosed_scalar(0.0);
  return bundle;
}

[[nodiscard]] mwperf::ValidatedConstructionObservationBundleV1 validate(
    mwperf::ConstructionObservationBundleV1 bundle) {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  return std::move(validated).value();
}

}  // namespace

TEST_CASE("C30 authenticated observations flow into exact diagnostics",
          "[c30][integration][observation-flow]") {
  const auto source = mwperf::testing::c30::envelope_for(
      mwperf::testing::c30::exact_gap_bundle());
  auto bytes =
      mwperf::canonical_construction_observation_envelope_bytes_v1(source);
  REQUIRE(bytes);
  auto parsed = mwperf::parse_construction_observation_envelope_v1(
      bytes.value(), mwperf::default_observation_parse_limits_v1());
  REQUIRE(parsed);
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      std::move(parsed).value(),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);

  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, true, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  CHECK(analysis.value().observation_digest == validated.value().digest());
  CHECK(analysis.value().analysis_digest != analysis.value().observation_digest);
  CHECK(analysis.value().work.input_level_rows == 3U);
  CHECK(analysis.value().work.input_boundary_rows == 2U);
  CHECK(analysis.value().work.merged_level_rows == 3U);
  CHECK(analysis.value().work.merged_boundary_rows == 2U);
  CHECK(analysis.value().work.point_fit_invocations == 1U);
  CHECK(analysis.value().work.jackknife_fit_invocations == 0U);
  CHECK(analysis.value().work.top_level_reservation_events > 0U);
  CHECK(analysis.value().work.analysis_allocation_events > 0U);
  CHECK(analysis.value().work.input_row_bytes > 0U);
  CHECK(analysis.value().work.estimated_peak_retained_bytes > 0U);
  REQUIRE(analysis.value().replications.size() == 1U);
  const auto& replication = analysis.value().replications.front();
  CHECK(replication.replication_id ==
        mwperf::TypedLabel::numeric(mwperf::BigNat{0U}));
  CHECK(replication.completeness ==
        mwperf::ObservationCompletenessV1::complete);
  CHECK(replication.inclusion ==
        mwperf::CompressionReplicationInclusionV1::included_complete);
  CHECK(replication.measured_slot_count == mwperf::BigNat{4U});
  CHECK(replication.exposure_mass.value ==
        mwperf::testing::c30::rational(4));
  CHECK(replication.service_mass.value ==
        mwperf::testing::c30::rational(2));
  CHECK(replication.backlog_exposure_mass.value ==
        mwperf::testing::c30::rational(5));
  CHECK(replication.backlog_service_mass.value ==
        mwperf::testing::c30::rational(3));
  REQUIRE(replication.initial_first_moment);
  REQUIRE(replication.committed_first_moment);
  REQUIRE(replication.initial_second_moment);
  REQUIRE(replication.committed_second_moment);
  CHECK(replication.initial_first_moment->value.is_zero());
  CHECK(replication.committed_first_moment->value.is_zero());
  CHECK(replication.initial_second_moment->value.is_zero());
  CHECK(replication.committed_second_moment->value.is_zero());
  REQUIRE(replication.cutoffs.size() == 1U);
  const auto& raw_tail = replication.cutoffs.front();
  CHECK(raw_tail.cutoff == mwperf::BigNat{1U});
  CHECK(raw_tail.tail_exposure_mass.value ==
        mwperf::testing::c30::rational(2));
  CHECK(raw_tail.tail_service_mass.value ==
        mwperf::testing::c30::rational(1));
  CHECK(raw_tail.backlog_tail_exposure_mass.value ==
        mwperf::testing::c30::rational(4));
  CHECK(raw_tail.backlog_tail_service_mass.value ==
        mwperf::testing::c30::rational(2));
  REQUIRE(raw_tail.positive_gap_tail_magnitude_mass);
  REQUIRE(raw_tail.negative_gap_tail_magnitude_mass);
  CHECK(raw_tail.positive_gap_tail_magnitude_mass->value.is_zero());
  CHECK(raw_tail.negative_gap_tail_magnitude_mass->value.is_zero());
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  CHECK(value_of(analysis.value().cutoffs.front().tail.tail_probability) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(value_of(analysis.value().finite_window.moment_identity_closure)
            .is_zero());
  REQUIRE(analysis.value().ties.response_by_level.size() == 3U);
  for (const auto& point : analysis.value().ties.response_by_level) {
    CHECK(value_of(point.response_reconstruction_closure).is_zero());
  }
}

TEST_CASE("C30 nonunit recorded-mass warning respects the error enclosure",
          "[c30][integration][observation-flow][enclosure][mass-defect]") {
  const auto analyze = [](const double defect,
                          const double absolute_error,
                          const mwperf::ObservationNormalizationClaimV1 claim) {
    auto bundle = finite_closure_bundle(true);
    auto& block = bundle.replications.front().blocks.front();
    block.levels[1U].served_mass = enclosed_scalar(0.0);
    block.levels[2U].exposure_mass =
        enclosed_scalar(2.0 + defect, absolute_error);
    block.exposure_mass_balance = {
        claim, enclosed_scalar(4.0 + defect, absolute_error),
        enclosed_scalar(defect, absolute_error)};

    const auto observation = validate(std::move(bundle));
    mwperf::CompressionAnalysisOptionsV1 options;
    options.cutoffs = {mwperf::BigNat{1U}};
    options.run_diagnostic_fits = false;
    auto result = mwperf::analyze_compression_observations_v1(
        observation, options);
    REQUIRE(result);
    return std::move(result).value();
  };

  SECTION("zero is retained by the enclosure") {
    const auto analysis = analyze(
        1.0e-12, 2.0e-12,
        mwperf::ObservationNormalizationClaimV1::enclosed);
    REQUIRE(analysis.pooled.signed_mass_defect.estimate);
    const auto& defect = *analysis.pooled.signed_mass_defect.estimate;
    CHECK(defect.value <= defect.absolute_error_bound);
    CHECK(-defect.value <= defect.absolute_error_bound);
    CHECK(std::find(
              analysis.pooled.status.warnings.begin(),
              analysis.pooled.status.warnings.end(),
              mwperf::CompressionWarningCodeV1::nonunit_recorded_mass) ==
          analysis.pooled.status.warnings.end());
  }

  SECTION("zero is excluded by the enclosure") {
    const auto analysis = analyze(
        0.25, 0.01,
        mwperf::ObservationNormalizationClaimV1::not_claimed);
    REQUIRE(analysis.pooled.signed_mass_defect.estimate);
    const auto& defect = *analysis.pooled.signed_mass_defect.estimate;
    CHECK(defect.value > defect.absolute_error_bound);
    CHECK(std::find(
              analysis.pooled.status.warnings.begin(),
              analysis.pooled.status.warnings.end(),
              mwperf::CompressionWarningCodeV1::nonunit_recorded_mass) !=
          analysis.pooled.status.warnings.end());
  }
}

TEST_CASE("C30 raw replication summaries retain excluded partial records",
          "[c30][integration][observation-flow][replications]") {
  auto bundle = mwperf::testing::c30::exact_bundle();
  auto partial = bundle.replications.front();
  partial.replication_id =
      mwperf::TypedLabel::numeric(mwperf::BigNat{1U});
  partial.replay_identity = mwperf::testing::c30::digest('c');
  partial.completeness = mwperf::ObservationCompletenessV1::partial;
  partial.committed_through_boundary = 2U;
  auto& block = partial.blocks.front();
  block.completeness = mwperf::ObservationCompletenessV1::partial;
  block.committed_through_boundary = 2U;
  block.levels = {
      {mwperf::BigNat{0U}, mwperf::testing::c30::scalar(1),
       mwperf::testing::c30::scalar(0), std::nullopt},
      {mwperf::BigNat{1U}, mwperf::testing::c30::scalar(1),
       mwperf::testing::c30::scalar(1), std::nullopt}};
  block.exposure_mass_balance =
      mwperf::testing::c30::exact_balance(2);
  block.committed_boundary_law = {
      2U,
      {{mwperf::BigNat{1U}, mwperf::testing::c30::scalar(1)}},
      mwperf::testing::c30::exact_balance(1)};
  auto stopped_at_warmup = bundle.replications.front();
  stopped_at_warmup.replication_id =
      mwperf::TypedLabel::numeric(mwperf::BigNat{2U});
  stopped_at_warmup.replay_identity = mwperf::testing::c30::digest('d');
  stopped_at_warmup.completeness =
      mwperf::ObservationCompletenessV1::partial;
  stopped_at_warmup.committed_through_boundary = 0U;
  stopped_at_warmup.blocks.clear();
  bundle.replications.push_back(std::move(partial));
  bundle.replications.push_back(std::move(stopped_at_warmup));

  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}};
  options.run_diagnostic_fits = false;
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().replications.size() == 3U);
  const auto& summary = analysis.value().replications[1U];
  CHECK(summary.completeness ==
        mwperf::ObservationCompletenessV1::partial);
  CHECK(summary.inclusion ==
        mwperf::CompressionReplicationInclusionV1::excluded_incomplete);
  CHECK(summary.measured_slot_count == mwperf::BigNat{2U});
  CHECK(summary.exposure_mass.value == mwperf::testing::c30::rational(2));
  CHECK(summary.service_mass.value == mwperf::testing::c30::rational(1));
  CHECK(summary.backlog_exposure_mass.value ==
        mwperf::testing::c30::rational(1));
  CHECK(summary.backlog_service_mass.value ==
        mwperf::testing::c30::rational(1));
  REQUIRE(summary.initial_first_moment);
  REQUIRE(summary.committed_first_moment);
  REQUIRE(summary.initial_second_moment);
  REQUIRE(summary.committed_second_moment);
  CHECK(summary.initial_first_moment->value.is_zero());
  CHECK(summary.initial_second_moment->value.is_zero());
  CHECK(summary.committed_first_moment->value ==
        mwperf::testing::c30::rational(1));
  CHECK(summary.committed_second_moment->value ==
        mwperf::testing::c30::rational(1));
  REQUIRE(summary.cutoffs.size() == 1U);
  CHECK(summary.cutoffs.front().tail_exposure_mass.value.is_zero());
  CHECK(summary.cutoffs.front().tail_service_mass.value.is_zero());
  CHECK_FALSE(summary.cutoffs.front().positive_gap_tail_magnitude_mass);
  CHECK_FALSE(summary.cutoffs.front().negative_gap_tail_magnitude_mass);
  const auto& empty_summary = analysis.value().replications[2U];
  CHECK(empty_summary.inclusion ==
        mwperf::CompressionReplicationInclusionV1::excluded_incomplete);
  CHECK(empty_summary.measured_slot_count.is_zero());
  CHECK(empty_summary.exposure_mass.value.is_zero());
  CHECK(empty_summary.service_mass.value.is_zero());
  CHECK_FALSE(empty_summary.initial_first_moment);
  CHECK_FALSE(empty_summary.committed_first_moment);
  CHECK_FALSE(empty_summary.initial_second_moment);
  CHECK_FALSE(empty_summary.committed_second_moment);
  REQUIRE(empty_summary.cutoffs.size() == 1U);
  CHECK_FALSE(
      empty_summary.cutoffs.front().positive_gap_tail_magnitude_mass);
  CHECK_FALSE(
      empty_summary.cutoffs.front().negative_gap_tail_magnitude_mass);
  CHECK(analysis.value().pooled.included_complete_replications == 1U);
  CHECK(analysis.value().pooled.excluded_partial_replications == 2U);
  CHECK(analysis.value().work.input_level_rows == 5U);
  CHECK(analysis.value().work.input_boundary_rows == 4U);
}

TEST_CASE("C30 raw replication cutoff numerators use one ordered suffix",
          "[c30][integration][observation-flow][replications][cutoff]") {
  auto bundle = mwperf::testing::c30::exact_gap_bundle();
  // Keep both certified magnitude signs nonzero in the tail above K=0.  The
  // level-two row still reconstructs one unit of service from one served tie.
  bundle.replications.front().blocks.front().levels[2U].gap =
      mwperf::ObservationGapCellV1{
          mwperf::testing::c30::scalar(1),
          mwperf::testing::c30::scalar(1),
          mwperf::testing::c30::scalar(0),
          mwperf::testing::c30::scalar(1),
          mwperf::testing::c30::scalar(0),
          mwperf::testing::c30::scalar(2)};
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {
      mwperf::BigNat{2U}, mwperf::BigNat{0U}, mwperf::BigNat{1U}};
  options.run_diagnostic_fits = false;
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().replications.size() == 1U);
  const auto& cutoffs = analysis.value().replications.front().cutoffs;
  REQUIRE(cutoffs.size() == 3U);
  CHECK(cutoffs[0U].cutoff == mwperf::BigNat{0U});
  CHECK(cutoffs[0U].tail_exposure_mass.value ==
        mwperf::testing::c30::rational(3));
  CHECK(cutoffs[0U].tail_service_mass.value ==
        mwperf::testing::c30::rational(2));
  CHECK(cutoffs[0U].backlog_tail_exposure_mass.value ==
        mwperf::testing::c30::rational(5));
  CHECK(cutoffs[0U].backlog_tail_service_mass.value ==
        mwperf::testing::c30::rational(3));
  REQUIRE(cutoffs[0U].positive_gap_tail_magnitude_mass);
  REQUIRE(cutoffs[0U].negative_gap_tail_magnitude_mass);
  CHECK(cutoffs[0U].positive_gap_tail_magnitude_mass->value ==
        mwperf::testing::c30::rational(1));
  CHECK(cutoffs[0U].negative_gap_tail_magnitude_mass->value ==
        mwperf::testing::c30::rational(2));
  CHECK(cutoffs[1U].cutoff == mwperf::BigNat{1U});
  CHECK(cutoffs[1U].tail_exposure_mass.value ==
        mwperf::testing::c30::rational(2));
  CHECK(cutoffs[1U].backlog_tail_exposure_mass.value ==
        mwperf::testing::c30::rational(4));
  REQUIRE(cutoffs[1U].positive_gap_tail_magnitude_mass);
  REQUIRE(cutoffs[1U].negative_gap_tail_magnitude_mass);
  CHECK(cutoffs[1U].positive_gap_tail_magnitude_mass->value.is_zero());
  CHECK(cutoffs[1U].negative_gap_tail_magnitude_mass->value ==
        mwperf::testing::c30::rational(2));
  CHECK(cutoffs[2U].cutoff == mwperf::BigNat{2U});
  CHECK(cutoffs[2U].tail_exposure_mass.value.is_zero());
  CHECK(cutoffs[2U].backlog_tail_exposure_mass.value.is_zero());
  REQUIRE(cutoffs[2U].positive_gap_tail_magnitude_mass);
  REQUIRE(cutoffs[2U].negative_gap_tail_magnitude_mass);
  CHECK(cutoffs[2U].positive_gap_tail_magnitude_mass->value.is_zero());
  CHECK(cutoffs[2U].negative_gap_tail_magnitude_mass->value.is_zero());
}

TEST_CASE("C30 optional diagnostic work stays disabled by explicit options",
          "[c30][integration][observation-flow][performance]") {
  const auto validated = mwperf::testing::c30::validated_bundle(
      mwperf::ObservationSourceRoleV1::short_restart_reference);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated, options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  CHECK_FALSE(analysis.value().cutoffs.front().diagnostic_fit.has_value());
  CHECK_FALSE(analysis.value().cutoffs.front().jackknife.has_value());
  CHECK(analysis.value().cutoffs.front().diagnostic_fit_failure ==
        std::nullopt);
  CHECK(analysis.value().work.point_fit_invocations == 0U);
  CHECK(analysis.value().work.jackknife_fit_invocations == 0U);
}

TEST_CASE("C30 authenticated Full Orbit empty initialization selects finite closure before slack",
          "[c30][integration][observation-flow][finite-closure]") {
  const auto observation = validate(finite_closure_bundle());
  mwperf::CompressionAnalysisOptionsV1 requested;
  requested.cutoffs = {mwperf::BigNat{1U}};

  auto effective = mwperf::effective_compression_analysis_options_v1(
      observation, requested);
  REQUIRE(effective);
  REQUIRE(effective.value().selection_seed.size() == 1U);
  CHECK(effective.value().selection_seed.front().backlog ==
        mwperf::BigNat{0U});
  CHECK(effective.value().selection_seed.front().selection_mass ==
        mwperf::ExactRational::one());

  auto analysis = mwperf::analyze_compression_observations_v1(
      observation, requested);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  const auto& cutoff = analysis.value().cutoffs.front();
  REQUIRE(cutoff.diagnostic_fit);
  CHECK(cutoff.diagnostic_fit->status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
  CHECK_FALSE(cutoff.diagnostic_fit->tail_slack.has_value());
  REQUIRE(cutoff.diagnostic_fit->fitted_mean_backlog);
  CHECK(cutoff.diagnostic_fit->fitted_mean_backlog->is_zero());
  CHECK(cutoff.diagnostic_fitted_mean.available());
  CHECK(std::find(cutoff.diagnostic_fit_status.warnings.begin(),
                  cutoff.diagnostic_fit_status.warnings.end(),
                  mwperf::CompressionWarningCodeV1::
                      finite_closure_with_nonpositive_slack) !=
        cutoff.diagnostic_fit_status.warnings.end());

  auto explicit_options = requested;
  explicit_options.selection_seed = {
      {mwperf::BigNat{0U}, mwperf::ExactRational::one()}};
  auto explicit_analysis = mwperf::analyze_compression_observations_v1(
      observation, explicit_options);
  REQUIRE(explicit_analysis);
  CHECK(explicit_analysis.value().analysis_digest ==
        analysis.value().analysis_digest);
}

TEST_CASE("C30 empty initialization selects every authenticated source role",
          "[c30][integration][observation-flow][finite-closure][role]") {
  mwperf::CompressionAnalysisOptionsV1 requested;
  requested.cutoffs = {mwperf::BigNat{1U}};

  const auto short_restart = validate(finite_closure_bundle(
      false, mwperf::ObservationSourceRoleV1::short_restart_reference));
  auto short_options = mwperf::effective_compression_analysis_options_v1(
      short_restart, requested);
  REQUIRE(short_options);
  REQUIRE(short_options.value().selection_seed.size() == 1U);
  auto short_analysis = mwperf::analyze_compression_observations_v1(
      short_restart, requested);
  REQUIRE(short_analysis);
  REQUIRE(short_analysis.value().cutoffs.front().diagnostic_fit);
  CHECK(short_analysis.value().cutoffs.front().diagnostic_fit->status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);

  const auto long_stationary = validate(finite_closure_bundle(
      false, mwperf::ObservationSourceRoleV1::long_stationary_reference));
  auto long_options = mwperf::effective_compression_analysis_options_v1(
      long_stationary, requested);
  REQUIRE(long_options);
  REQUIRE(long_options.value().selection_seed.size() == 1U);
  auto long_analysis = mwperf::analyze_compression_observations_v1(
      long_stationary, requested);
  REQUIRE(long_analysis);
  REQUIRE(long_analysis.value().cutoffs.front().diagnostic_fit);
  CHECK(long_analysis.value().cutoffs.front().diagnostic_fit->status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
}

TEST_CASE("C30 altered Full Orbit initialization descriptor cannot select finite closure",
          "[c30][integration][observation-flow][finite-closure][negative]") {
  SECTION("altered id") {
    auto bundle = finite_closure_bundle();
    bundle.initialization.initial_law_id = "unknown_empty_backlog_v1";
    const auto observation = validate(std::move(bundle));
    mwperf::CompressionAnalysisOptionsV1 requested;
    requested.cutoffs = {mwperf::BigNat{1U}};
    auto effective = mwperf::effective_compression_analysis_options_v1(
        observation, requested);
    REQUIRE(effective);
    CHECK(effective.value().selection_seed.empty());
    auto analysis = mwperf::analyze_compression_observations_v1(
        observation, requested);
    REQUIRE(analysis);
    REQUIRE(analysis.value().cutoffs.front().diagnostic_fit);
    CHECK(analysis.value().cutoffs.front().diagnostic_fit->status ==
          mwperf::FinitePrefixFitStatusV1::outside_strict_tail_profile);
  }

  SECTION("altered digest") {
    auto bundle = finite_closure_bundle();
    bundle.initialization.initial_law_digest =
        mwperf::testing::c30::digest('c');
    const auto observation = validate(std::move(bundle));
    mwperf::CompressionAnalysisOptionsV1 requested;
    requested.cutoffs = {mwperf::BigNat{1U}};
    auto effective = mwperf::effective_compression_analysis_options_v1(
        observation, requested);
    REQUIRE(effective);
    CHECK(effective.value().selection_seed.empty());
    auto analysis = mwperf::analyze_compression_observations_v1(
        observation, requested);
    REQUIRE(analysis);
    REQUIRE(analysis.value().cutoffs.front().diagnostic_fit);
    CHECK(analysis.value().cutoffs.front().diagnostic_fit->status ==
          mwperf::FinitePrefixFitStatusV1::outside_strict_tail_profile);
  }
}

TEST_CASE("C30 uncertain weighted-ensemble center reports finite closure mean unavailable",
          "[c30][integration][observation-flow][finite-closure][enclosure]") {
  const auto observation = validate(finite_closure_bundle(true));
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}};
  auto analysis = mwperf::analyze_compression_observations_v1(
      observation, options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  const auto& cutoff = analysis.value().cutoffs.front();
  REQUIRE(cutoff.diagnostic_fit);
  CHECK(cutoff.diagnostic_fit->status ==
        mwperf::FinitePrefixFitStatusV1::finite_closed_tail_unreachable);
  REQUIRE(cutoff.diagnostic_fit->fitted_mean_backlog);
  CHECK(cutoff.diagnostic_fit->fitted_mean_backlog->is_zero());
  CHECK_FALSE(cutoff.diagnostic_fitted_mean.available());
  CHECK(std::find(
            cutoff.diagnostic_fitted_mean.status.unavailable_reasons.begin(),
            cutoff.diagnostic_fitted_mean.status.unavailable_reasons.end(),
            mwperf::CompressionUnavailableReasonV1::fitted_law_unavailable) !=
        cutoff.diagnostic_fitted_mean.status.unavailable_reasons.end());
  CHECK(std::find(cutoff.diagnostic_fit_status.warnings.begin(),
                  cutoff.diagnostic_fit_status.warnings.end(),
                  mwperf::CompressionWarningCodeV1::
                      numerical_enclosure_required) !=
        cutoff.diagnostic_fit_status.warnings.end());
}
