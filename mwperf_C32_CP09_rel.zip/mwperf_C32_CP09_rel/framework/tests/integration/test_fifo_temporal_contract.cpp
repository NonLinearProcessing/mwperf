#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "metrics/c23_bounded_internal.hpp"
#include "mwperf/metrics/palm_fifo.hpp"
#include "mwperf/stationary/suspension.hpp"

namespace {

namespace c21 = mwperf::testing::c21;

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

template <typename T>
[[nodiscard]] const T& require_available(
    const mwperf::StationaryProjectionSlotV1<T>& slot) {
  const auto* value = std::get_if<T>(&slot);
  REQUIRE(value != nullptr);
  return *value;
}

struct FifoProjectionPath final {
  c21::StationarySuspensionFixtureV1 fixture;
  mwperf::EventInvariantLaw event_law;
  mwperf::PositiveFiniteMean mean;
  mwperf::StationaryTemporalProjection projection;
};

[[nodiscard]] FifoProjectionPath complete_projection(
    c21::StationarySuspensionFixtureV1 fixture) {
  auto event_law = require_value(mwperf::select_event_invariant_law(
      fixture.kernel, c21::configured_selection(fixture),
      c21::solver_policy(fixture)));
  auto mean = require_value(
      mwperf::compute_mean_residence(event_law, fixture.provider));
  auto projection = require_value(
      mwperf::build_stationary_temporal_projection(
          event_law, fixture.provider, mean));
  return {std::move(fixture), std::move(event_law), std::move(mean),
          std::move(projection)};
}

[[nodiscard]] FifoProjectionPath make_fifo_projection(
    const bool identity_variant = false) {
  return complete_projection(c21::make_plan_fixture(
      c21::ProjectionPlanFixtureV1::fifo_service, false,
      identity_variant));
}

[[nodiscard]] c21::designated::InputV1 input_for_metrics(
    const std::string_view metrics, const bool identity_variant = false) {
  using namespace mwperf;
  auto input = c21::suspension_input(
      c21::EventSelectionFixtureV1::unique, c21::rational(1, 1),
      c21::rational(0, 1), c21::ProjectionPlanFixtureV1::fifo_service,
      identity_variant);
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + std::string(metrics) + R"json(],
    "surrogate":{"id":")json" +
      std::string(c21::matrix::kC20ResetRomrProfile.provider_id) +
      R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":0,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";
  auto document = load_document(c21::designated::write_input(
      "c23-custom-analysis", analysis));
  REQUIRE(document);
  auto authored = parse_analysis_spec_v1(document.value());
  REQUIRE(authored);
  const auto canonical = canonicalize_authored_inputs(
      input.instance.authored_model(), authored.value());
  auto resolved = resolve_physical_instance(
      input.instance.authored_model(), authored.value(),
      fingerprint_inputs(canonical));
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " +
                       resolved.error().message));
  REQUIRE(resolved);
  auto rebound = testing::C20ArrivalFixtureAccess::bind(
      resolved.value(), input.arrival);
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  input.instance = std::move(rebound).value();
  std::vector<MetricRequest> requests;
  requests.reserve(input.instance.analysis_spec().metrics.size());
  for (const auto& metric : input.instance.analysis_spec().metrics) {
    auto request = parse_metric_request(metric, input.instance.queues());
    REQUIRE(request);
    requests.push_back(std::move(request).value());
  }
  REQUIRE_FALSE(requests.empty());
  input.requirements = aggregate_metric_requirements(requests);
  input.request = std::move(requests.front());
  return input;
}

[[nodiscard]] c21::designated::InputV1 input_for_metric(
    const std::string_view metric, const bool identity_variant = false) {
  return input_for_metrics(metric, identity_variant);
}

[[nodiscard]] c21::StationarySuspensionFixtureV1 make_custom_fixture(
    const std::string_view metric,
    const c21::ProjectionPlanFixtureV1 contract_plan,
    const std::uint8_t residence_length = 1U,
    const bool force_full_residence = false,
    const bool identity_variant = false) {
  using namespace mwperf;

  auto operation = c21::suspension_operation_override(
      residence_length, true, false);
  if (force_full_residence) {
    operation.stopping_indicator =
        [residence_length](const CanonicalRuntimeValueV1& input)
        -> Result<CanonicalRuntimeValueV1> {
      if (input.codec != testing::c17::kReducedStateCodec ||
          input.canonical_value.size() != c21::kStateSize) {
        return testing::c17::failure<CanonicalRuntimeValueV1>(
            "c23.fixture.multislot_stop_shape",
            "the C23 multi-slot stop received a foreign state");
      }
      const std::uint8_t age = std::to_integer<std::uint8_t>(
          input.canonical_value[c21::kAgeOffset]);
      return Result<CanonicalRuntimeValueV1>::success(
          {{"c17.fixture.temporal.indicator", 1U},
           {age == residence_length ? std::byte{0x01} : std::byte{0x00}}});
    };
  }

  auto completed_decoder_clock_or =
      std::make_shared<std::atomic<unsigned>>(0U);
  c21::matrix::ScopedC17TemporalFixtureOverride scope(operation);
  auto prepared = c21::temporal_fixture::
      prepare_generic_temporal_framework_from_scenario_with_arrival_initial_state(
          c21::stationary_temporal_scenario(
              input_for_metric(metric, identity_variant),
              c21::matrix::kC20ResetRomrProfile,
              contract_plan),
          ArrivalInitialState{SharedRoundState{"h0"}}, std::nullopt,
          [](PlugDescriptor&) {},
          [completed_decoder_clock_or](
              const ResolvedInstance& instance,
              const std::span<const QueueId> targets,
              const CompiledArrivalLaw& arrival, const ArrivalPhase&,
              const ArrivalPhase&) {
            return c21::suspension_state_schema(
                instance, targets, arrival, completed_decoder_clock_or);
          },
          [](const std::span<const QueueId> targets,
             const ExactReducedStateSchemaV1&) {
            return c21::state(targets, 0U);
          },
          [residence_length](ExactCausalProgramV1& program) {
            const std::vector<QueueId> targets{
                c21::designated::queue("q0")};
            std::vector<ReducedStateV1> domain{c21::state(targets, 0U)};
            program.maximum_residence_slots = residence_length;
            program.reachable_audit_states = domain;
            program.finite_event_domain_states = std::move(domain);
            program.event_entry_domain_is_exact_state_domain = false;
            program.event_clock_semantics = EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient;
          });
  auto framework = audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  c21::temporal_fixture::GenericTemporalFrameworkV1 temporal{
      std::move(framework).value(), std::move(prepared.instance),
      std::move(prepared.ordered_targets), std::move(prepared.state_schema),
      std::move(prepared.descriptor), std::move(prepared.initial_state),
      std::move(prepared.entrance_mark),
      std::move(prepared.entrance_decoder_calls),
      std::move(prepared.residence_generator_calls)};
  auto provider = audited_residence_provider(temporal.framework);
  INFO((provider ? std::string{}
                 : provider.error().code + ": " + provider.error().message));
  REQUIRE(provider);
  auto domain = FiniteEventStateDomain::from_audited_provider(
      provider.value());
  REQUIRE(domain);
  auto kernel = assemble_embedded_event_kernel(domain.value(),
                                                provider.value());
  INFO((kernel ? std::string{}
               : kernel.error().code + ": " + kernel.error().message));
  REQUIRE(kernel);
  const ReducedStateV1 class_a =
      c21::state(temporal.ordered_targets, 0U);
  const ReducedStateV1 class_b =
      c21::state(temporal.ordered_targets, 1U);
  return {std::move(temporal), std::move(provider).value(),
          std::move(domain).value(), std::move(kernel).value(), class_a,
          class_b, std::move(completed_decoder_clock_or)};
}

[[nodiscard]] FifoProjectionPath make_multislot_fifo_projection() {
  return complete_projection(make_custom_fixture(
      R"json({"id":"c23-multislot","kind":"fifo_delay","parameters":{"output":"pmf","horizon":2}})json",
      c21::ProjectionPlanFixtureV1::fifo_service, 3U, true));
}

[[nodiscard]] FifoProjectionPath make_conditioned_fifo_projection(
    const std::uint64_t rank = 1U) {
  const std::string metric =
      std::string{"{\"id\":\"c23-conditioned\",\"kind\":\"fifo_delay_conditioned\",\"parameters\":{\"output\":\"pmf\",\"horizon\":2,\"condition\":{\"kind\":\"rank\",\"value\":"} +
      std::to_string(rank) + "}}}";
  return complete_projection(make_custom_fixture(
      metric, c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_fifo_mean_projection(
    const bool identity_variant = false) {
  return complete_projection(make_custom_fixture(
      R"json({"id":"c23-mean","kind":"fifo_delay","parameters":{"output":"moment","order":1}})json",
      c21::ProjectionPlanFixtureV1::fifo_service, 1U, false,
      identity_variant));
}

[[nodiscard]] FifoProjectionPath make_fifo_quantile_projection() {
  return complete_projection(make_custom_fixture(
      R"json({"id":"c23-quantile","kind":"fifo_delay","parameters":{"output":"quantile","probability":0.5}})json",
      c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_fifo_multi_output_projection() {
  return complete_projection(make_custom_fixture(
      R"json({"id":"c23-pmf","kind":"fifo_delay","parameters":{"output":"pmf","horizon":2}},
             {"id":"c23-moment-3","kind":"fifo_delay","parameters":{"output":"moment","order":3}})json",
      c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_fifo_multi_condition_projection() {
  return complete_projection(make_custom_fixture(
      R"json({"id":"c23-all","kind":"fifo_delay","parameters":{"output":"pmf","horizon":2}},
             {"id":"c23-rank-one","kind":"fifo_delay_conditioned","parameters":{"output":"tail","horizon":2,"condition":{"kind":"rank","value":1}}},
             {"id":"c23-class-one","kind":"fifo_delay_conditioned","parameters":{"output":"pmf","horizon":2,"condition":{"kind":"class","value":1}}})json",
      c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_label_conditioned_fifo_projection(
    const std::string_view kind, const std::uint64_t value) {
  const std::string metric =
      std::string{"{\"id\":\"c23-label-conditioned\",\"kind\":\"fifo_delay_conditioned\",\"parameters\":{\"output\":\"pmf\",\"horizon\":2,\"condition\":{\"kind\":\""} +
      std::string(kind) + "\",\"value\":" + std::to_string(value) +
      "}}}";
  return complete_projection(make_custom_fixture(
      metric, c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_batch_conditioned_fifo_projection(
    const std::uint64_t value) {
  const std::string metric =
      std::string{"{\"id\":\"c23-batch-conditioned\",\"kind\":\"fifo_delay_conditioned\",\"parameters\":{\"output\":\"pmf\",\"horizon\":2,\"condition\":{\"kind\":\"batch\",\"value\":"} +
      std::to_string(value) + "}}}";
  return complete_projection(make_custom_fixture(
      metric, c21::ProjectionPlanFixtureV1::fifo_service));
}

[[nodiscard]] FifoProjectionPath make_event_gap_projection(
    const std::string_view event = "admission") {
  const std::string metric =
      std::string{"{\"id\":\"c23-gap\",\"kind\":\"event_gap_distribution\",\"parameters\":{\"event\":\""} +
      std::string(event) + "\",\"horizon\":1}}";
  return complete_projection(make_custom_fixture(
      metric, c21::ProjectionPlanFixtureV1::stationary_stopped));
}

[[nodiscard]] mwperf::ExactRational exact_atom_mass(
    const mwperf::AdmissionPalmLaw& law) {
  mwperf::ExactRational total = mwperf::ExactRational::zero();
  for (const auto& atom : law.atoms()) {
    total = total + atom.exact_mass;
  }
  return total;
}

[[nodiscard]] mwperf::ExactRational exact_tag_mass(
    const mwperf::TagInitialLaw& law) {
  mwperf::ExactRational total = mwperf::ExactRational::zero();
  for (const auto& atom : law.atoms()) {
    total = total + atom.exact_mass;
  }
  return total;
}

using SyntheticFifoNode = mwperf::testing::C23SyntheticFifoNodeV1;
using SyntheticFifoTransition =
    mwperf::testing::C23SyntheticServiceTransitionV1;
using SyntheticFifoEntrance =
    mwperf::testing::C23SyntheticFifoEntranceV1;

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 synthetic_phase(
    const std::uint8_t value = 0U) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] mwperf::Result<mwperf::DelayLaw>
evaluate_synthetic_fifo_result(
    FifoProjectionPath& seed, std::vector<SyntheticFifoNode> nodes,
    std::vector<SyntheticFifoEntrance> entrance,
    std::vector<mwperf::FifoDelayOutputV1> outputs,
    const mwperf::HorizonSpec& horizon) {
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          seed.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(seed.projection.predictive_service_split())));
  return mwperf::testing::C23FixtureAccess::evaluate_synthetic_fifo_delay(
      initial,
      require_available(seed.projection.temporal_service_kernel()),
      std::move(nodes), std::move(entrance), std::move(outputs), horizon,
      c21::solver_policy(seed.fixture));
}

[[nodiscard]] mwperf::DelayLaw evaluate_synthetic_fifo(
    FifoProjectionPath& seed, std::vector<SyntheticFifoNode> nodes,
    std::vector<SyntheticFifoEntrance> entrance,
    std::vector<mwperf::FifoDelayOutputV1> outputs,
    const mwperf::HorizonSpec& horizon) {
  return require_value(evaluate_synthetic_fifo_result(
      seed, std::move(nodes), std::move(entrance), std::move(outputs),
      horizon));
}

[[nodiscard]] std::vector<mwperf::ExactRational> exact_tails(
    const mwperf::DelayLaw& law) {
  std::vector<mwperf::ExactRational> result;
  result.reserve(law.tails().size());
  for (const auto& tail : law.tails()) {
    result.push_back(tail.exact_probability);
  }
  return result;
}

[[nodiscard]] mwperf::ExactRational exact_finite_pmf_mass(
    const mwperf::DelayLaw& law) {
  mwperf::ExactRational result = mwperf::ExactRational::zero();
  for (const auto& atom : law.finite_pmf()) {
    result = result + atom.exact_probability;
  }
  return result;
}

}  // namespace

TEST_CASE("C23 evaluates the real C21 FIFO projection through C22 stopping",
          "[c23][integration][c21][c22][fifo]") {
  auto path = make_fifo_projection();
  const unsigned generator_calls_before =
      path.fixture.temporal.residence_generator_calls->load(
          std::memory_order_relaxed);

  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  CHECK(admission.projection_fingerprint() == path.projection.fingerprint());
  CHECK(admission.admission_rate().exact_value() ==
        mwperf::ExactRational::one());
  CHECK(exact_atom_mass(admission) == mwperf::ExactRational::one());
  REQUIRE_FALSE(admission.atoms().empty());
  for (const auto& atom : admission.atoms()) {
    CHECK(atom.batch_size == mwperf::BigNat{1U});
    CHECK(atom.within_batch_rank == mwperf::BigNat{1U});
    CHECK(atom.prearrival_backlog == mwperf::BigNat{1U});
    CHECK(atom.actual_departure == 1U);
    CHECK(atom.first_eligible_backlog == mwperf::BigNat{1U});
  }

  const auto& split =
      require_available(path.projection.predictive_service_split());
  const auto initial =
      require_value(mwperf::lift_fifo_tag_state(admission, split));
  CHECK(initial.projection_fingerprint() == path.projection.fingerprint());
  CHECK(initial.is_unconditioned_all_admissions());
  CHECK(exact_tag_mass(initial) == mwperf::ExactRational::one());
  REQUIRE_FALSE(initial.atoms().empty());
  for (const auto& atom : initial.atoms()) {
    REQUIRE(atom.state.untagged_state.canonical_value.size() ==
            c21::kStateSize);
    CHECK(std::to_integer<std::uint8_t>(
              atom.state.untagged_state
                  .canonical_value[c21::kBacklogOffset]) == 1U);
    CHECK(atom.state.predecessors == mwperf::BigNat{0U});
    CHECK(atom.label.batch_size == mwperf::BigNat{1U});
    CHECK(atom.label.within_batch_rank == mwperf::BigNat{1U});
  }

  const auto& service =
      require_available(path.projection.temporal_service_kernel());
  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          initial, service,
          mwperf::HorizonSpec{mwperf::BigNat{4U}, false, true},
          c21::solver_policy(path.fixture)));
  const auto bounded_delay = require_value(
      mwperf::metrics::detail::evaluate_fifo_delay_distribution_bounded(
          initial, service,
          mwperf::HorizonSpec{mwperf::BigNat{4U}, false, true},
          c21::solver_policy(path.fixture), 64U, 64U));
  CHECK(bounded_delay.actual_state_count <= 64U);
  CHECK(bounded_delay.actual_maximum_row_atoms <= 64U);
  const auto state_limited =
      mwperf::metrics::detail::evaluate_fifo_delay_distribution_bounded(
          initial, service,
          mwperf::HorizonSpec{mwperf::BigNat{4U}, false, true},
          c21::solver_policy(path.fixture), 0U, 64U);
  REQUIRE_FALSE(state_limited);
  CHECK(state_limited.error().code ==
        "c23.fifo_lift_state_budget_exceeded");
  const auto row_limited =
      mwperf::metrics::detail::evaluate_fifo_delay_distribution_bounded(
          initial, service,
          mwperf::HorizonSpec{mwperf::BigNat{4U}, false, true},
          c21::solver_policy(path.fixture), 64U, 0U);
  REQUIRE_FALSE(row_limited);
  CHECK(row_limited.error().code ==
        "c23.fifo_lift_row_width_budget_exceeded");

  CHECK(delay.projection_fingerprint() == path.projection.fingerprint());
  CHECK(delay.is_unconditioned_all_admissions());
  REQUIRE(delay.tails().size() == 5U);
  CHECK(delay.tails()[0U].completed_eligible_slots == mwperf::BigNat{0U});
  CHECK(delay.tails()[0U].exact_probability ==
        mwperf::ExactRational::one());
  for (std::size_t index = 1U; index < delay.tails().size(); ++index) {
    CHECK(delay.tails()[index].completed_eligible_slots ==
          mwperf::BigNat{index});
    CHECK(delay.tails()[index].exact_probability.is_zero());
  }
  REQUIRE_FALSE(delay.finite_pmf().empty());
  CHECK(delay.finite_pmf().front().sojourn_slots == mwperf::BigNat{1U});
  CHECK(delay.finite_pmf().front().exact_probability ==
        mwperf::ExactRational::one());
  CHECK(delay.proven_defective_mass().is_zero());
  CHECK(delay.unresolved_tail_mass().is_zero());
  CHECK(delay.absorption_status() ==
        mwperf::AbsorptionStatusV1::nondefective);
  CHECK(delay.mean_sojourn().status ==
        mwperf::ExtendedNonnegativeStatusV1::not_established);
  CHECK(delay.stopped_backend_result().initial_law_kind ==
        mwperf::InitialLawKindV1::fifo_tag);
  CHECK(delay.diagnostics().exact_entrance_mass_residual.is_zero());
  CHECK(delay.diagnostics().exact_maximum_killed_row_residual.is_zero());
  CHECK(delay.diagnostics().coefficient_crosscheck_performed);
  CHECK(delay.diagnostics().coefficient_crosscheck_exact);
  CHECK_FALSE(
      delay.diagnostics().coefficient_crosscheck_diagnostic.has_value());
  REQUIRE(delay.finite_pmf().size() + 1U == delay.tails().size());
  for (std::size_t index = 0U; index < delay.finite_pmf().size(); ++index) {
    CHECK(delay.tails()[index].exact_probability >=
          delay.tails()[index + 1U].exact_probability);
    CHECK(delay.finite_pmf()[index].exact_probability ==
          delay.tails()[index].exact_probability -
              delay.tails()[index + 1U].exact_probability);
  }

  const auto little = mwperf::verify_little_identity(
      delay.stationary_queue_law(), delay.admission_rate(), delay);
  CHECK(little.category == mwperf::DiagnosticCategory::unavailable);
  CHECK(little.code == "c23.little_identity_moment_unresolved");

  CHECK(path.fixture.temporal.residence_generator_calls->load(
            std::memory_order_relaxed) == generator_calls_before);
}

TEST_CASE("C23 edge-only projections keep FIFO service slots typed unavailable",
          "[c23][integration][fifo][capability][negative]") {
  using Plan = c21::ProjectionPlanFixtureV1;
  const auto edge_only = complete_projection(
      c21::make_plan_fixture(Plan::stationary_reward));

  const auto* split_unavailable =
      std::get_if<mwperf::StationaryProjectionUnavailableV1>(
          &edge_only.projection.predictive_service_split());
  const auto* kernel_unavailable =
      std::get_if<mwperf::StationaryProjectionUnavailableV1>(
          &edge_only.projection.temporal_service_kernel());
  REQUIRE(split_unavailable != nullptr);
  REQUIRE(kernel_unavailable != nullptr);
  CHECK(split_unavailable->kind ==
        mwperf::StationaryProjectionUnavailableKindV1::unrequested);
  CHECK(kernel_unavailable->kind ==
        mwperf::StationaryProjectionUnavailableKindV1::unrequested);
  CHECK_FALSE(split_unavailable->code.empty());
  CHECK_FALSE(kernel_unavailable->code.empty());
}

TEST_CASE("C23 production admission Palm size-biases batches and keeps timing",
          "[c23][integration][c21][palm][size-bias][timing]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  auto path = make_fifo_projection();
  const auto marked_edge = require_value(
      mwperf::testing::C23FixtureAccess::with_synthetic_admission_edges(
          path.projection.marked_edge(),
          {Edge{c21::rational(1, 2), mwperf::BigNat{5U}, 1U,
                mwperf::BigNat{1U}},
           Edge{c21::rational(1, 2), mwperf::BigNat{5U}, 1U,
                mwperf::BigNat{3U}}}));

  // The seam only prepares a closed C21 carrier.  The law under test is
  // produced by the public F-C23-02 implementation.
  const auto palm = require_value(mwperf::construct_admission_palm_law(
      marked_edge,
      mwperf::ArrivalCountMark{
          0U, mwperf::AdmissionCountingSemanticsV1::
                  retained_edge_packet_labels}));
  const auto entrance_limited =
      mwperf::metrics::detail::construct_admission_palm_law_bounded(
          marked_edge,
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels},
          3U);
  REQUIRE_FALSE(entrance_limited);
  CHECK(entrance_limited.error().code ==
        "c23.admission_palm_state_budget_exceeded");
  const auto bounded_palm = require_value(
      mwperf::metrics::detail::construct_admission_palm_law_bounded(
          marked_edge,
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels},
          4U));
  CHECK(bounded_palm.actual_entrance_atoms == 4U);

  CHECK(palm.admission_rate().exact_value() == c21::rational(2, 1));
  CHECK(exact_atom_mass(palm) == mwperf::ExactRational::one());
  REQUIRE(palm.atoms().size() == 4U);

  const auto& singleton = palm.atoms()[0U];
  CHECK(singleton.batch_size == mwperf::BigNat{1U});
  CHECK(singleton.within_batch_rank == mwperf::BigNat{1U});
  CHECK(singleton.exact_mass == c21::rational(1, 4));

  mwperf::ExactRational batch_three_mass =
      mwperf::ExactRational::zero();
  for (std::size_t index = 1U; index < palm.atoms().size(); ++index) {
    const auto& atom = palm.atoms()[index];
    CHECK(atom.batch_size == mwperf::BigNat{3U});
    CHECK(atom.within_batch_rank == mwperf::BigNat{index});
    CHECK(atom.exact_mass == c21::rational(1, 4));
    batch_three_mass = batch_three_mass + atom.exact_mass;
  }
  CHECK(batch_three_mass == c21::rational(3, 4));

  // N(t)=5, D(t)=1, A(t+1)=3 and j=2 imply
  // R0=N-D+j-1=5 and N(t+1)=N-D+A=7.
  const auto& rank_two = palm.atoms()[2U];
  CHECK(rank_two.prearrival_backlog == mwperf::BigNat{5U});
  CHECK(rank_two.actual_departure == 1U);
  CHECK(rank_two.within_batch_rank == mwperf::BigNat{2U});
  const auto after_service = require_value(mwperf::checked_subtract(
      rank_two.prearrival_backlog, mwperf::BigNat{1U}));
  const auto rank_offset = require_value(mwperf::checked_subtract(
      rank_two.within_batch_rank, mwperf::BigNat{1U}));
  const auto predecessors = after_service + rank_offset;
  CHECK(predecessors == mwperf::BigNat{5U});
  CHECK(rank_two.first_eligible_backlog == mwperf::BigNat{7U});
  CHECK(predecessors < rank_two.first_eligible_backlog);
}

TEST_CASE("C23 randomized production Palm equals direct labelled counting",
          "[c23][property][palm][production]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  auto seed = make_fifo_projection();
  std::uint32_t generator = 0xc23a02U;

  for (std::size_t fixture = 0U; fixture < 16U; ++fixture) {
    generator = generator * 1664525U + 1013904223U;
    const std::size_t edge_count = 2U + generator % 4U;
    std::vector<std::uint32_t> weights(edge_count);
    std::vector<std::uint32_t> batches(edge_count);
    std::uint32_t weight_total = 0U;
    std::size_t label_count = 0U;
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      generator = generator * 1664525U + 1013904223U;
      weights[edge] = 1U + generator % 11U;
      weight_total += weights[edge];
      generator = generator * 1664525U + 1013904223U;
      batches[edge] = generator % 5U;
      label_count += batches[edge];
    }
    if (label_count == 0U) {
      batches.front() = 1U;
      label_count = 1U;
    }

    std::vector<Edge> edges;
    edges.reserve(edge_count);
    mwperf::ExactRational direct_intensity =
        mwperf::ExactRational::zero();
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      const auto slot_mass = c21::rational(
          static_cast<std::int64_t>(weights[edge]),
          static_cast<std::int64_t>(weight_total));
      direct_intensity =
          direct_intensity +
          slot_mass * c21::rational(
                          static_cast<std::int64_t>(batches[edge]), 1);
      edges.push_back(Edge{slot_mass, mwperf::BigNat{8U},
                           static_cast<std::uint8_t>(edge % 2U),
                           mwperf::BigNat{batches[edge]}});
    }

    const auto marked_edge = require_value(
        mwperf::testing::C23FixtureAccess::with_synthetic_admission_edges(
            seed.projection.marked_edge(), std::move(edges)));
    const auto palm = require_value(mwperf::construct_admission_palm_law(
        marked_edge,
        mwperf::ArrivalCountMark{
            0U, mwperf::AdmissionCountingSemanticsV1::
                    retained_edge_packet_labels}));
    CAPTURE(fixture, edge_count, label_count);
    CHECK(palm.admission_rate().exact_value() == direct_intensity);
    CHECK(exact_atom_mass(palm) == mwperf::ExactRational::one());
    REQUIRE(palm.atoms().size() == label_count);

    std::size_t atom_index = 0U;
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      const auto slot_mass = c21::rational(
          static_cast<std::int64_t>(weights[edge]),
          static_cast<std::int64_t>(weight_total));
      const auto per_label =
          require_value(mwperf::checked_divide(slot_mass, direct_intensity));
      for (std::size_t rank = 1U; rank <= batches[edge]; ++rank) {
        REQUIRE(atom_index < palm.atoms().size());
        const auto& atom = palm.atoms()[atom_index++];
        CHECK(atom.edge_atom_index == edge);
        CHECK(atom.batch_size == mwperf::BigNat{batches[edge]});
        CHECK(atom.within_batch_rank == mwperf::BigNat{rank});
        CHECK(atom.exact_mass == per_label);
      }
    }
    CHECK(atom_index == palm.atoms().size());
  }
}

TEST_CASE("C23 constructs a fingerprint-bound event Palm entrance from C21",
          "[c23][integration][c21][event-palm]") {
  const auto path = make_event_gap_projection();
  const auto palm = require_value(mwperf::construct_event_palm_law(
      path.projection.temporal_law(),
      mwperf::EventIndicator{
          "target-admission", "binary-admission-event",
          mwperf::BinaryEventCountV1{
              mwperf::PositiveTargetArrivalPredicateV1{0U}}}));

  CHECK(palm.exact_event_intensity() == mwperf::ExactRational::one());
  CHECK(palm.projection_fingerprint() == path.projection.fingerprint());
  CHECK(palm.initial_law().kind() == mwperf::InitialLawKindV1::event_palm);
  REQUIRE_FALSE(palm.atoms().empty());
  mwperf::ExactRational total = mwperf::ExactRational::zero();
  for (const auto& atom : palm.atoms()) {
    CHECK(atom.event_label == mwperf::BigNat{1U});
    total = total + atom.exact_mass;
  }
  CHECK(total == mwperf::ExactRational::one());

  // The packet-count rule uses the admission-Palm route accepted by a FIFO
  // request; it must not require an unrelated binary event-gap contract.
  const auto fifo_path = make_fifo_projection();
  const auto packet_palm = require_value(mwperf::construct_event_palm_law(
      fifo_path.projection.temporal_law(),
      mwperf::EventIndicator{"target-admission", "within-batch-rank",
                             mwperf::TargetArrivalEventCountV1{0U}}));
  CHECK(packet_palm.exact_event_intensity() ==
        mwperf::ExactRational::one());
  CHECK(packet_palm.projection_fingerprint() ==
        fifo_path.projection.fingerprint());

  const auto zero_path = make_event_gap_projection("busy_denial");
  const auto zero = mwperf::construct_event_palm_law(
      zero_path.projection.temporal_law(),
      mwperf::EventIndicator{
          "target-busy-denial", "binary-event",
          mwperf::BinaryEventCountV1{
              mwperf::BusyDenialEdgePredicateV1{0U}}});
  REQUIRE_FALSE(zero);
  CHECK(zero.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK_FALSE(zero.error().code.empty());
}

TEST_CASE("C23 serves multiple accepted outputs and exact higher moments",
          "[c23][integration][fifo][multi-output][moment]") {
  const auto path = make_fifo_multi_output_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));
  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          initial,
          require_available(path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, true, true},
          c21::solver_policy(path.fixture)));

  REQUIRE(delay.finite_pmf().size() == 2U);
  CHECK(delay.finite_pmf()[0U].exact_probability ==
        mwperf::ExactRational::one());
  const auto third = require_value(delay.moment(mwperf::BigNat{3U}));
  CHECK(third.status == mwperf::DelayMomentStatusV1::established);
  REQUIRE(third.exact_value.has_value());
  CHECK(*third.exact_value == mwperf::ExactRational::one());
  const auto unauthorized = delay.moment(mwperf::BigNat{2U});
  REQUIRE_FALSE(unauthorized);
  CHECK(unauthorized.error().code == "c23.fifo_moment_not_authorized");
}

TEST_CASE("C23 real lifted and polynomial backends agree when P0 P1 do not commute",
          "[c23][integration][fifo][polynomial][noncommuting]") {
  auto seed = make_fifo_projection();
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {
          SyntheticFifoNode{
              mwperf::BigNat{2U}, synthetic_phase(),
              {SyntheticFifoTransition{1U, 0U, c21::rational(1, 2)},
               SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)}}},
          SyntheticFifoNode{
              mwperf::BigNat{2U}, synthetic_phase(),
              {SyntheticFifoTransition{0U, 0U, c21::rational(1, 4)},
               SyntheticFifoTransition{1U, 1U, c21::rational(3, 4)}}},
      },
      {SyntheticFifoEntrance{0U, mwperf::BigNat{1U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{5U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{5U}, false, true});

  const std::vector<mwperf::ExactRational> expected{
      c21::rational(1, 1), c21::rational(1, 1), c21::rational(3, 4),
      c21::rational(9, 32), c21::rational(11, 64),
      c21::rational(7, 128)};
  CHECK(exact_tails(delay) == expected);
  CHECK(delay.diagnostics().coefficient_crosscheck_performed);
  CHECK(delay.diagnostics().coefficient_crosscheck_exact);
  CHECK_FALSE(
      delay.diagnostics().coefficient_crosscheck_diagnostic.has_value());
  REQUIRE(delay.finite_pmf().size() + 1U == delay.tails().size());
  for (std::size_t index = 0U; index < delay.finite_pmf().size(); ++index) {
    CHECK(delay.finite_pmf()[index].sojourn_slots ==
          mwperf::BigNat{index + 1U});
    CHECK(delay.finite_pmf()[index].exact_probability ==
          expected[index] - expected[index + 1U]);
  }
  CHECK(delay.proven_defective_mass().is_zero());
  CHECK(delay.unresolved_tail_mass() == expected.back());
  CHECK(exact_finite_pmf_mass(delay) + delay.unresolved_tail_mass() +
            delay.proven_defective_mass() ==
        mwperf::ExactRational::one());
}

TEST_CASE("C23 F05 delegates through the passive adapter and C22 in order",
          "[c23][integration][fifo][call-order]") {
  auto seed = make_fifo_projection();
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {
          SyntheticFifoNode{
              mwperf::BigNat{1U}, synthetic_phase(),
              {SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)},
               SyntheticFifoTransition{1U, 1U, c21::rational(1, 2)}}},
          // This row is only the successor metadata of a killed edge.  It is
          // not a live tag row and therefore must never be requested from the
          // lazy F-C23-04 adapter.
          SyntheticFifoNode{
              mwperf::BigNat{1U}, synthetic_phase(1U),
              {SyntheticFifoTransition{1U, 0U, c21::rational(1, 3)},
               SyntheticFifoTransition{1U, 0U, c21::rational(1, 3)},
               SyntheticFifoTransition{1U, 0U, c21::rational(1, 3)}}},
      },
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{1U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{1U}, false, true});
  REQUIRE(delay.finite_pmf().size() == 1U);
  CHECK(delay.finite_pmf().front().exact_probability ==
        mwperf::ExactRational::one());

  using Stage = mwperf::testing::C23ExecutionStageV1;
  const auto trace =
      mwperf::testing::C23FixtureAccess::last_fifo_execution_trace();
  const auto passive = std::find(
      trace.begin(), trace.end(), Stage::passive_tag_adapter_advance);
  const auto construct = std::find(
      trace.begin(), trace.end(), Stage::construct_killed_kernel);
  const auto evaluate = std::find(
      trace.begin(), trace.end(), Stage::evaluate_hit_survival_absorption);
  const auto coefficient =
      std::find(trace.begin(), trace.end(), Stage::coefficient_backend);
  REQUIRE(passive != trace.end());
  REQUIRE(construct != trace.end());
  REQUIRE(evaluate != trace.end());
  REQUIRE(coefficient != trace.end());
  CHECK(passive < construct);
  CHECK(construct < evaluate);
  CHECK(evaluate < coefficient);
  CHECK(std::count(trace.begin(), trace.end(),
                   Stage::passive_tag_adapter_advance) == 2);
}

TEST_CASE("C23 coefficient resource loss preserves the explicit F05 result",
          "[c23][integration][fifo][polynomial][fallback]") {
  auto seed = make_fifo_projection();
  mwperf::testing::C23FixtureAccess::limit_next_coefficient_backend(0U, 0U);
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {SyntheticFifoNode{
          mwperf::BigNat{1U}, synthetic_phase(),
          {SyntheticFifoTransition{
              0U, 1U, mwperf::ExactRational::one()}}}},
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{2U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true});

  REQUIRE(delay.tails().size() == 3U);
  CHECK(delay.tails()[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(delay.tails()[1U].exact_probability.is_zero());
  CHECK(delay.tails()[2U].exact_probability.is_zero());
  REQUIRE(delay.finite_pmf().size() == 2U);
  CHECK(delay.finite_pmf()[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(delay.finite_pmf()[1U].exact_probability.is_zero());

  const auto& diagnostics = delay.diagnostics();
  CHECK_FALSE(diagnostics.coefficient_crosscheck_performed);
  CHECK_FALSE(diagnostics.coefficient_crosscheck_exact);
  REQUIRE(diagnostics.coefficient_crosscheck_diagnostic.has_value());
  CHECK(diagnostics.coefficient_crosscheck_diagnostic->category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK_FALSE(diagnostics.coefficient_crosscheck_diagnostic->code.empty());
}

TEST_CASE("C23 coefficient disagreement preserves the explicit F05 result",
          "[c23][integration][fifo][polynomial][fallback]") {
  auto seed = make_fifo_projection();
  using FixtureAccess = mwperf::testing::C23FixtureAccess;
  FixtureAccess::mismatch_next_coefficient_crosscheck();
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {SyntheticFifoNode{
          mwperf::BigNat{1U}, synthetic_phase(),
          {SyntheticFifoTransition{
              0U, 1U, mwperf::ExactRational::one()}}}},
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{1U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{1U}, false, true});

  REQUIRE(delay.tails().size() == 2U);
  CHECK(delay.tails()[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(delay.tails()[1U].exact_probability.is_zero());
  REQUIRE(delay.finite_pmf().size() == 1U);
  CHECK(delay.finite_pmf()[0U].exact_probability ==
        mwperf::ExactRational::one());

  const auto& diagnostics = delay.diagnostics();
  CHECK(diagnostics.coefficient_crosscheck_performed);
  CHECK_FALSE(diagnostics.coefficient_crosscheck_exact);
  REQUIRE(diagnostics.coefficient_crosscheck_diagnostic.has_value());
  CHECK(diagnostics.coefficient_crosscheck_diagnostic->category ==
        mwperf::DiagnosticCategory::internal);
  CHECK(diagnostics.coefficient_crosscheck_diagnostic->code ==
        "c23.fifo_coefficient_crosscheck_failure");
}

TEST_CASE("C23 real delay mapping matches a labelled batch path oracle",
          "[c23][integration][fifo][batch][path-oracle]") {
  auto seed = make_fifo_projection();
  const std::vector<mwperf::testing::C23SyntheticServiceStateV1>
      polynomial_states{
          {{{1U, 0U, c21::rational(1, 2)},
            {0U, 1U, c21::rational(1, 2)}}},
          {{{0U, 0U, c21::rational(1, 4)},
            {1U, 1U, c21::rational(3, 4)}}},
      };
  const std::vector<mwperf::testing::C23SyntheticPolynomialEntranceV1>
      polynomial_entrance{
          {1U, 0U, c21::rational(1, 3)},
          {1U, 1U, c21::rational(1, 3)},
          {1U, 2U, c21::rational(1, 3)},
      };
  const auto oracle = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          polynomial_states, polynomial_entrance, 6U));
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {
          SyntheticFifoNode{
              mwperf::BigNat{3U}, synthetic_phase(),
              {SyntheticFifoTransition{1U, 0U, c21::rational(1, 2)},
               SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)}}},
          SyntheticFifoNode{
              mwperf::BigNat{3U}, synthetic_phase(),
              {SyntheticFifoTransition{0U, 0U, c21::rational(1, 4)},
               SyntheticFifoTransition{1U, 1U, c21::rational(3, 4)}}},
      },
      {
          SyntheticFifoEntrance{1U, mwperf::BigNat{0U},
                                c21::rational(1, 3)},
          SyntheticFifoEntrance{1U, mwperf::BigNat{1U},
                                c21::rational(1, 3)},
          SyntheticFifoEntrance{1U, mwperf::BigNat{2U},
                                c21::rational(1, 3)},
      },
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{6U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{6U}, false, true});

  CHECK(exact_tails(delay) == oracle);
  CHECK(delay.diagnostics().maximum_initial_rank == 2U);
  CHECK(delay.diagnostics().coefficient_crosscheck_exact);
}

TEST_CASE("C23 real service tails distinguish total backlog at fixed rank and phase",
          "[c23][integration][fifo][backlog-state]") {
  const std::vector<SyntheticFifoNode> nodes{
      SyntheticFifoNode{
          mwperf::BigNat{1U}, synthetic_phase(0U),
          {SyntheticFifoTransition{3U, 1U,
                                   mwperf::ExactRational::one()}}},
      SyntheticFifoNode{
          mwperf::BigNat{2U}, synthetic_phase(0U),
          {SyntheticFifoTransition{2U, 0U,
                                   mwperf::ExactRational::one()}}},
      SyntheticFifoNode{
          mwperf::BigNat{2U}, synthetic_phase(1U),
          {SyntheticFifoTransition{0U, 1U,
                                   mwperf::ExactRational::one()}}},
      SyntheticFifoNode{
          mwperf::BigNat{0U}, synthetic_phase(1U),
          {SyntheticFifoTransition{3U, 0U,
                                   mwperf::ExactRational::one()}}},
  };
  const std::vector<mwperf::FifoDelayOutputV1> outputs{
      mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayTailOutputV1{mwperf::BigNat{2U}}}};

  auto low_seed = make_fifo_projection();
  const auto low = evaluate_synthetic_fifo(
      low_seed, nodes,
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      outputs, mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true});
  auto high_seed = make_fifo_projection();
  const auto high = evaluate_synthetic_fifo(
      high_seed, nodes,
      {SyntheticFifoEntrance{1U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      outputs, mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true});

  CHECK(exact_tails(low) ==
        std::vector<mwperf::ExactRational>{c21::rational(1, 1),
                                           c21::rational(0, 1),
                                           c21::rational(0, 1)});
  CHECK(exact_tails(high) ==
        std::vector<mwperf::ExactRational>{c21::rational(1, 1),
                                           c21::rational(1, 1),
                                           c21::rational(0, 1)});
}

TEST_CASE("C23 real unconditioned mapping is invariant to batch-label order",
          "[c23][integration][fifo][palm][relabel]") {
  const std::vector<SyntheticFifoNode> nodes{
      SyntheticFifoNode{
          mwperf::BigNat{3U}, synthetic_phase(),
          {SyntheticFifoTransition{0U, 0U, c21::rational(1, 2)},
           SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)}}},
  };
  const std::vector<SyntheticFifoEntrance> canonical{
      {0U, mwperf::BigNat{0U}, c21::rational(1, 3)},
      {0U, mwperf::BigNat{1U}, c21::rational(1, 3)},
      {0U, mwperf::BigNat{2U}, c21::rational(1, 3)},
  };
  const std::vector<SyntheticFifoEntrance> relabeled{
      canonical[2U], canonical[0U], canonical[1U]};
  const std::vector<mwperf::FifoDelayOutputV1> outputs{
      mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{5U}}}};
  auto first_seed = make_fifo_projection();
  const auto first = evaluate_synthetic_fifo(
      first_seed, nodes, canonical, outputs,
      mwperf::HorizonSpec{mwperf::BigNat{5U}, false, true});
  auto second_seed = make_fifo_projection();
  const auto second = evaluate_synthetic_fifo(
      second_seed, nodes, relabeled, outputs,
      mwperf::HorizonSpec{mwperf::BigNat{5U}, false, true});
  CHECK(exact_tails(first) == exact_tails(second));
  CHECK(first.finite_pmf().size() == second.finite_pmf().size());
  for (std::size_t index = 0U; index < first.finite_pmf().size(); ++index) {
    CHECK(first.finite_pmf()[index].exact_probability ==
          second.finite_pmf()[index].exact_probability);
  }
}

TEST_CASE("C23 real delay mapping preserves exact defect and infinite mean",
          "[c23][integration][fifo][defect][negative]") {
  auto denial_seed = make_fifo_projection();
  const auto denial = evaluate_synthetic_fifo(
      denial_seed,
      {SyntheticFifoNode{
          mwperf::BigNat{1U}, synthetic_phase(),
          {SyntheticFifoTransition{0U, 0U,
                                   mwperf::ExactRational::one()}}}},
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
           mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{4U}}},
       mwperf::FifoDelayOutputV1{
           mwperf::FifoDelayMomentOutputV1{mwperf::BigNat{1U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{4U}, true, true});
  CHECK(denial.absorption_status() ==
        mwperf::AbsorptionStatusV1::defective);
  CHECK(denial.proven_defective_mass() ==
        mwperf::ExactRational::one());
  CHECK(denial.unresolved_tail_mass().is_zero());
  CHECK(denial.mean_sojourn().status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
  const auto& denial_evidence =
      denial.stationary_queue_law().labelled_evidence();
  CHECK_FALSE(denial_evidence.two_sided_stationary);
  CHECK_FALSE(denial_evidence.finite_slot_occupancy_almost_surely);
  CHECK_FALSE(denial_evidence.occupancy_equals_admitted_not_departed);
  for (const auto& mass : denial.finite_pmf()) {
    CHECK(mass.exact_probability.is_zero());
  }
  const auto denial_moment =
      require_value(denial.moment(mwperf::BigNat{1U}));
  CHECK(denial_moment.status ==
        mwperf::DelayMomentStatusV1::positive_infinity);

  const auto epsilon = c21::rational(1, 1000000000000000000LL);
  auto near_seed = make_fifo_projection();
  const auto near_unit = evaluate_synthetic_fifo(
      near_seed,
      {
          SyntheticFifoNode{
              mwperf::BigNat{1U}, synthetic_phase(),
              {SyntheticFifoTransition{
                   2U, 1U, mwperf::ExactRational::one() - epsilon},
               SyntheticFifoTransition{1U, 0U, epsilon}}},
          SyntheticFifoNode{
              mwperf::BigNat{1U}, synthetic_phase(),
              {SyntheticFifoTransition{1U, 0U,
                                       mwperf::ExactRational::one()}}},
          SyntheticFifoNode{
              mwperf::BigNat{0U}, synthetic_phase(),
              {SyntheticFifoTransition{2U, 0U,
                                       mwperf::ExactRational::one()}}},
      },
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
           mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{1U}}},
       mwperf::FifoDelayOutputV1{
           mwperf::FifoDelayMomentOutputV1{mwperf::BigNat{1U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{1U}, true, true});
  REQUIRE(near_unit.finite_pmf().size() == 1U);
  CHECK(near_unit.finite_pmf().front().exact_probability ==
        mwperf::ExactRational::one() - epsilon);
  CHECK(near_unit.proven_defective_mass() == epsilon);
  CHECK(near_unit.unresolved_tail_mass().is_zero());
  CHECK(near_unit.mean_sojourn().status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
}

TEST_CASE("C23 exact higher moments are nontrivial on deterministic T equals two",
          "[c23][integration][fifo][moment]") {
  auto seed = make_fifo_projection();
  const auto delay = evaluate_synthetic_fifo(
      seed,
      {
          SyntheticFifoNode{
              mwperf::BigNat{2U}, synthetic_phase(),
              {SyntheticFifoTransition{1U, 1U,
                                       mwperf::ExactRational::one()}}},
          SyntheticFifoNode{
              mwperf::BigNat{1U}, synthetic_phase(),
              {SyntheticFifoTransition{2U, 1U,
                                       mwperf::ExactRational::one()}}},
          SyntheticFifoNode{
              mwperf::BigNat{0U}, synthetic_phase(),
              {SyntheticFifoTransition{2U, 0U,
                                       mwperf::ExactRational::one()}}},
      },
      {SyntheticFifoEntrance{0U, mwperf::BigNat{1U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayMomentOutputV1{mwperf::BigNat{3U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{2U}, true, true});

  CHECK(delay.mean_sojourn().status ==
        mwperf::ExtendedNonnegativeStatusV1::finite);
  REQUIRE(delay.mean_sojourn().exact_value.has_value());
  CHECK(*delay.mean_sojourn().exact_value == c21::rational(2, 1));
  const auto third = require_value(delay.moment(mwperf::BigNat{3U}));
  CHECK(third.status == mwperf::DelayMomentStatusV1::established);
  REQUIRE(third.exact_value.has_value());
  CHECK(*third.exact_value == c21::rational(8, 1));
}

TEST_CASE("C23 rejects infeasible joint higher-moment work before solving",
          "[c23][integration][fifo][moment][resource-limit]") {
  constexpr std::size_t live_state_count = 17U;
  std::vector<SyntheticFifoNode> nodes;
  nodes.reserve(live_state_count);
  for (std::size_t index = 0U; index < live_state_count; ++index) {
    const bool final = index + 1U == live_state_count;
    nodes.push_back(SyntheticFifoNode{
        mwperf::BigNat{1U}, synthetic_phase(),
        {SyntheticFifoTransition{
            final ? index : index + 1U,
            static_cast<std::uint8_t>(final ? 1U : 0U),
            mwperf::ExactRational::one()}}});
  }

  auto seed = make_fifo_projection();
  const auto rejected = evaluate_synthetic_fifo_result(
      seed, std::move(nodes),
      {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                             mwperf::ExactRational::one()}},
      {mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayMomentOutputV1{mwperf::BigNat{4096U}}}},
      mwperf::HorizonSpec{mwperf::BigNat{0U}, true, true});

  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(rejected.error().code ==
        "c23.fifo_moment_work_budget_exceeded");
}

TEST_CASE("C23 returns an authorized exact lower-inverse delay quantile",
          "[c23][integration][fifo][quantile]") {
  const auto path = make_fifo_quantile_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));
  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          initial,
          require_available(path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(path.fixture)));

  const auto quantile = require_value(delay.quantile(c21::rational(1, 2)));
  CHECK(quantile.status == mwperf::DelayQuantileStatusV1::established);
  REQUIRE(quantile.sojourn_slots.has_value());
  CHECK(*quantile.sojourn_slots == mwperf::BigNat{1U});
  CHECK(quantile.exact_cdf_below.is_zero());
  CHECK(quantile.exact_cdf_at == mwperf::ExactRational::one());
}

TEST_CASE("C23 distinguishes unresolved and defective delay quantiles",
          "[c23][integration][fifo][quantile][defect]") {
  const auto probability = c21::rational(3, 4);
  const std::vector<mwperf::FifoDelayOutputV1> outputs{
      mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayPmfOutputV1{mwperf::BigNat{1U}}},
      mwperf::FifoDelayOutputV1{
          mwperf::FifoDelayQuantileOutputV1{probability}}};

  SECTION("a proper law whose requested quantile exceeds the horizon") {
    auto seed = make_fifo_projection();
    const auto delay = evaluate_synthetic_fifo(
        seed,
        {SyntheticFifoNode{
            mwperf::BigNat{1U}, synthetic_phase(),
            {SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)},
             SyntheticFifoTransition{0U, 0U, c21::rational(1, 2)}}}},
        {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                               mwperf::ExactRational::one()}},
        outputs, mwperf::HorizonSpec{mwperf::BigNat{1U}, false, true});

    REQUIRE(delay.finite_pmf().size() == 1U);
    CHECK(delay.finite_pmf().front().exact_probability ==
          c21::rational(1, 2));
    CHECK(delay.proven_defective_mass().is_zero());
    CHECK(delay.unresolved_tail_mass() == c21::rational(1, 2));
    CHECK(exact_finite_pmf_mass(delay) + delay.unresolved_tail_mass() +
              delay.proven_defective_mass() ==
          mwperf::ExactRational::one());

    const auto quantile = require_value(delay.quantile(probability));
    CHECK(quantile.status ==
          mwperf::DelayQuantileStatusV1::unresolved_horizon);
    CHECK_FALSE(quantile.sojourn_slots.has_value());
    CHECK(quantile.exact_cdf_below == c21::rational(1, 2));
    CHECK(quantile.exact_cdf_at == c21::rational(1, 2));
  }

  SECTION("a quantile beyond the attainable mass of a defective law") {
    auto seed = make_fifo_projection();
    const auto delay = evaluate_synthetic_fifo(
        seed,
        {
            SyntheticFifoNode{
                mwperf::BigNat{1U}, synthetic_phase(),
                {SyntheticFifoTransition{0U, 1U, c21::rational(1, 2)},
                 SyntheticFifoTransition{1U, 0U, c21::rational(1, 2)}}},
            SyntheticFifoNode{
                mwperf::BigNat{1U}, synthetic_phase(),
                {SyntheticFifoTransition{
                    1U, 0U, mwperf::ExactRational::one()}}},
        },
        {SyntheticFifoEntrance{0U, mwperf::BigNat{0U},
                               mwperf::ExactRational::one()}},
        outputs, mwperf::HorizonSpec{mwperf::BigNat{1U}, false, true});

    REQUIRE(delay.finite_pmf().size() == 1U);
    CHECK(delay.finite_pmf().front().exact_probability ==
          c21::rational(1, 2));
    CHECK(delay.proven_defective_mass() == c21::rational(1, 2));
    CHECK(delay.unresolved_tail_mass().is_zero());
    CHECK(exact_finite_pmf_mass(delay) + delay.unresolved_tail_mass() +
              delay.proven_defective_mass() ==
          mwperf::ExactRational::one());

    const auto quantile = require_value(delay.quantile(probability));
    CHECK(quantile.status ==
          mwperf::DelayQuantileStatusV1::beyond_defective_mass);
    CHECK_FALSE(quantile.sojourn_slots.has_value());
    CHECK(quantile.exact_cdf_below == c21::rational(1, 2));
    CHECK(quantile.exact_cdf_at == c21::rational(1, 2));
  }
}

TEST_CASE("C23 Little verification keeps evidence and extended statuses typed",
          "[c23][integration][little]") {
  const auto path = make_fifo_mean_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));
  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          initial,
          require_available(path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, true, true},
          c21::solver_policy(path.fixture)));

  const auto verified = mwperf::verify_little_identity(
      delay.stationary_queue_law(), delay.admission_rate(), delay);
  CHECK(verified.category == mwperf::DiagnosticCategory::information);
  CHECK(verified.code == "c23.little_identity_verified");

  REQUIRE(delay.stationary_queue_law().mean_backlog().exact_value.has_value());
  REQUIRE(delay.mean_sojourn().exact_value.has_value());
  const auto quotient = require_value(mwperf::checked_divide(
      *delay.stationary_queue_law().mean_backlog().exact_value,
      delay.admission_rate().exact_value()));
  const mwperf::ExactRational direct_labelled_cycle_count =
      mwperf::ExactRational::one();
  CHECK(quotient == *delay.mean_sojourn().exact_value);
  CHECK(quotient == direct_labelled_cycle_count);

  const auto missing_evidence = require_value(
      mwperf::testing::C23FixtureAccess::with_labelled_occupancy_evidence(
          delay.stationary_queue_law(),
          mwperf::LabelledOccupancyEvidenceV1{false, false, false, false,
                                              false, false}));
  const auto absent = mwperf::verify_little_identity(
      missing_evidence, delay.admission_rate(), delay);
  CHECK(absent.category == mwperf::DiagnosticCategory::unavailable);
  CHECK(absent.code ==
        "c23.little_identity_labelled_occupancy_unavailable");

  const auto first_moment = require_value(delay.moment(mwperf::BigNat{1U}));
  CHECK(first_moment.status == mwperf::DelayMomentStatusV1::established);
  REQUIRE(first_moment.exact_value.has_value());
  CHECK(*first_moment.exact_value == mwperf::ExactRational::one());
  const auto unauthorized_moment = delay.moment(mwperf::BigNat{2U});
  REQUIRE_FALSE(unauthorized_moment);
  const auto unauthorized_quantile =
      delay.quantile(c21::rational(1, 2));
  REQUIRE_FALSE(unauthorized_quantile);

  const auto zero_rate = require_value(
      mwperf::testing::C23FixtureAccess::with_exact_admission_rate(
          delay.admission_rate(), mwperf::ExactRational::zero()));
  CHECK(mwperf::verify_little_identity(delay.stationary_queue_law(),
                                       zero_rate, delay).code ==
        "c23.little_identity_admission_rate_unavailable");

  const auto nonlossless = require_value(
      mwperf::testing::C23FixtureAccess::with_labelled_occupancy_evidence(
          delay.stationary_queue_law(),
          mwperf::LabelledOccupancyEvidenceV1{true, true, true, true, false,
                                              true}));
  CHECK(mwperf::verify_little_identity(nonlossless, delay.admission_rate(),
                                       delay)
            .code == "c23.little_identity_labelled_occupancy_unavailable");

  const auto foreign_path = make_fifo_mean_projection(true);
  const auto foreign_admission = require_value(
      mwperf::construct_admission_palm_law(
          foreign_path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  CHECK(mwperf::verify_little_identity(
            foreign_admission.stationary_queue_law(),
            delay.admission_rate(), delay)
            .code == "c23.little_identity_binding_mismatch");
  CHECK(mwperf::verify_little_identity(
            delay.stationary_queue_law(),
            foreign_admission.admission_rate(), delay)
            .code == "c23.little_identity_binding_mismatch");
}

TEST_CASE("C23 event Palm entrance evaluates through the matching C22 source",
          "[c23][integration][c21][c22][event-palm]") {
  const auto path = make_event_gap_projection();
  const auto palm = require_value(mwperf::construct_event_palm_law(
      path.projection.temporal_law(),
      mwperf::EventIndicator{
          "target-admission", "binary-admission-event",
          mwperf::BinaryEventCountV1{
              mwperf::PositiveTargetArrivalPredicateV1{0U}}}));
  const auto& kernel = require_available(path.projection.temporal_kernel());
  const auto killed = require_value(mwperf::construct_killed_kernel(
      kernel, mwperf::SafeSet{mwperf::AnyStatePredicateV1{}},
      mwperf::AbsorptionMarks{{mwperf::TypedAbsorptionMarkV1{
          "next-slot", mwperf::AnyStatePredicateV1{},
          mwperf::PositiveTargetArrivalPredicateV1{0U}}}}));
  const auto stopped = require_value(
      mwperf::evaluate_hit_survival_absorption(
          killed, palm.initial_law(),
          mwperf::HorizonSpec{mwperf::BigNat{1U}, false, true},
          c21::solver_policy(path.fixture)));

  CHECK(stopped.initial_law_kind == mwperf::InitialLawKindV1::event_palm);
  REQUIRE(stopped.survival_tails.size() == 2U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[1U].exact_probability.is_zero());
  REQUIRE(stopped.absorption_masses.size() == 1U);
  CHECK(stopped.absorption_masses[0U].hitting_time == mwperf::BigNat{1U});
  CHECK(stopped.absorption_masses[0U].exact_probability ==
        mwperf::ExactRational::one());
}

TEST_CASE("C23 FIFO entrance preserves continuation across a ROMR boundary",
          "[c23][integration][c21][fifo][residence-boundary]") {
  auto path = make_multislot_fifo_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));

  REQUIRE(admission.atoms().size() == 3U);
  REQUIRE(initial.atoms().size() == admission.atoms().size());
  const auto terminal = std::find_if(
      admission.atoms().begin(), admission.atoms().end(),
      [](const mwperf::AdmissionPalmAtomV1& atom) {
        return atom.edge_atom_index == 2U;
      });
  REQUIRE(terminal != admission.atoms().end());
  const std::size_t terminal_index = static_cast<std::size_t>(
      std::distance(admission.atoms().begin(), terminal));
  CHECK(initial.atoms()[terminal_index].continuation_index == 0U);
  REQUIRE(initial.atoms()[terminal_index]
              .state.untagged_state.canonical_value.size() ==
          c21::kStateSize);
  CHECK(std::to_integer<std::uint8_t>(
            initial.atoms()[terminal_index]
                .state.untagged_state
                .canonical_value[c21::kBacklogOffset]) == 1U);
  CHECK(initial.atoms()[terminal_index].state.predecessors.is_zero());

  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          initial,
          require_available(path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(path.fixture)));
  REQUIRE(delay.tails().size() == 3U);
  CHECK(delay.tails()[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(delay.tails()[1U].exact_probability.is_zero());
  CHECK(delay.diagnostics().coefficient_crosscheck_exact);
}

TEST_CASE("C23 rejects non-Palm admission semantics on a real stationary edge",
          "[c23][integration][palm][negative]") {
  const auto path = make_fifo_projection();
  for (const auto semantics : {
           mwperf::AdmissionCountingSemanticsV1::nonempty_slot_conditioning,
           mwperf::AdmissionCountingSemanticsV1::
               independently_redrawn_batch}) {
    const auto rejected = mwperf::construct_admission_palm_law(
        path.projection.marked_edge(),
        mwperf::ArrivalCountMark{0U, semantics});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().category ==
          mwperf::DiagnosticCategory::input_validation);
    CHECK_FALSE(rejected.error().code.empty());
  }
}

TEST_CASE("C23 conditions only at Palm entrance and preserves the total rate",
          "[c23][integration][conditioning]") {
  const auto path = make_conditioned_fifo_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto conditioned = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));

  CHECK_FALSE(conditioned.is_unconditioned_all_admissions());
  REQUIRE(conditioned.conditioning().has_value());
  CHECK(conditioned.admission_rate().exact_value() ==
        admission.admission_rate().exact_value());
  CHECK(exact_tag_mass(conditioned) == mwperf::ExactRational::one());

  const auto delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          conditioned,
          require_available(path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(path.fixture)));
  CHECK_FALSE(delay.is_unconditioned_all_admissions());
  const auto little = mwperf::verify_little_identity(
      delay.stationary_queue_law(), delay.admission_rate(), delay);
  CHECK(little.category == mwperf::DiagnosticCategory::unavailable);
  CHECK_FALSE(little.code.empty());

  const auto zero_path = make_conditioned_fifo_projection(2U);
  const auto zero_admission = require_value(
      mwperf::construct_admission_palm_law(
          zero_path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto zero_mass = mwperf::lift_fifo_tag_state(
      zero_admission,
      require_available(zero_path.projection.predictive_service_split()));
  REQUIRE_FALSE(zero_mass);
  CHECK(zero_mass.error().category ==
        mwperf::DiagnosticCategory::unavailable);
}

TEST_CASE("C23 decodes class and phase labels at the first eligible entrance",
          "[c23][integration][conditioning][entrance-label]") {
  for (const std::string_view kind : {std::string_view{"class"},
                                      std::string_view{"phase"}}) {
    CAPTURE(kind);
    const auto path = make_label_conditioned_fifo_projection(kind, 1U);
    CHECK(path.fixture.temporal.entrance_decoder_calls->load(
              std::memory_order_relaxed) > 0U);
    const auto admission = require_value(
        mwperf::construct_admission_palm_law(
            path.projection.marked_edge(),
            mwperf::ArrivalCountMark{
                0U, mwperf::AdmissionCountingSemanticsV1::
                        retained_edge_packet_labels}));
    REQUIRE_FALSE(admission.atoms().empty());
    for (const auto& atom : admission.atoms()) {
      REQUIRE(atom.entrance_labels.size() == 2U);
      for (const auto& label : atom.entrance_labels) {
        CHECK(std::none_of(
            atom.retained_edge_marks.begin(), atom.retained_edge_marks.end(),
            [&](const mwperf::CausalMarkV1& edge_mark) {
              return edge_mark.mark.mark == label.mark;
            }));
      }
    }
    const auto conditioned = require_value(mwperf::lift_fifo_tag_state(
        admission,
        require_available(path.projection.predictive_service_split())));
    REQUIRE(conditioned.conditioning().has_value());
    CHECK(std::holds_alternative<mwperf::RetainedMarkPalmConditionV1>(
        *conditioned.conditioning()));
    CHECK(exact_tag_mass(conditioned) == mwperf::ExactRational::one());
    const auto delay = require_value(
        mwperf::evaluate_fifo_delay_distribution(
            conditioned,
            require_available(path.projection.temporal_service_kernel()),
            mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
            c21::solver_policy(path.fixture)));
    CHECK(delay.diagnostics().conditioned_entrance);

    const auto zero_path =
        make_label_conditioned_fifo_projection(kind, 2U);
    const auto zero_admission = require_value(
        mwperf::construct_admission_palm_law(
            zero_path.projection.marked_edge(),
            mwperf::ArrivalCountMark{
                0U, mwperf::AdmissionCountingSemanticsV1::
                        retained_edge_packet_labels}));
    const auto zero = mwperf::lift_fifo_tag_state(
        zero_admission,
        require_available(zero_path.projection.predictive_service_split()));
    REQUIRE_FALSE(zero);
    CHECK(zero.error().code == "c23.fifo_condition_zero_palm_mass");
  }
}

TEST_CASE("C23 supports batch conditioning and selects accepted Palm clauses",
          "[c23][integration][conditioning][multi-request]") {
  const auto batch_path = make_batch_conditioned_fifo_projection(1U);
  const auto batch_admission = require_value(
      mwperf::construct_admission_palm_law(
          batch_path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto batch = require_value(mwperf::lift_fifo_tag_state(
      batch_admission,
      require_available(batch_path.projection.predictive_service_split())));
  REQUIRE(batch.conditioning().has_value());
  CHECK(std::holds_alternative<mwperf::BatchPalmConditionV1>(
      *batch.conditioning()));

  const auto zero_path = make_batch_conditioned_fifo_projection(2U);
  const auto zero_admission = require_value(
      mwperf::construct_admission_palm_law(
          zero_path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto zero = mwperf::lift_fifo_tag_state(
      zero_admission,
      require_available(zero_path.projection.predictive_service_split()));
  REQUIRE_FALSE(zero);
  CHECK(zero.error().code == "c23.fifo_condition_zero_palm_mass");

  const auto multi_path = make_fifo_multi_condition_projection();
  const auto multi_admission = require_value(
      mwperf::construct_admission_palm_law(
          multi_path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto all_admissions = require_value(mwperf::lift_fifo_tag_state(
      multi_admission,
      require_available(multi_path.projection.predictive_service_split())));
  CHECK(all_admissions.is_unconditioned_all_admissions());
  const auto all_delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          all_admissions,
          require_available(multi_path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(multi_path.fixture)));
  CHECK(all_delay.is_unconditioned_all_admissions());

  const auto rank_one = require_value(mwperf::condition_tag_initial_law(
      all_admissions,
      mwperf::PalmConditionV1{
          mwperf::RankPalmConditionV1{mwperf::BigNat{1U}}}));
  CHECK_FALSE(rank_one.is_unconditioned_all_admissions());
  const auto rank_delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          rank_one,
          require_available(multi_path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(multi_path.fixture)));
  CHECK_FALSE(rank_delay.is_unconditioned_all_admissions());

  const auto class_one = require_value(mwperf::condition_tag_initial_law(
      all_admissions,
      mwperf::FifoConditionV1{mwperf::FifoClassConditionV1{
          mwperf::TypedLabel::numeric(mwperf::BigNat{1U})}}));
  REQUIRE(class_one.conditioning().has_value());
  CHECK(std::holds_alternative<mwperf::RetainedMarkPalmConditionV1>(
      *class_one.conditioning()));
  CHECK(exact_tag_mass(class_one) == mwperf::ExactRational::one());
  const auto class_delay = require_value(
      mwperf::evaluate_fifo_delay_distribution(
          class_one,
          require_available(multi_path.projection.temporal_service_kernel()),
          mwperf::HorizonSpec{mwperf::BigNat{2U}, false, true},
          c21::solver_policy(multi_path.fixture)));
  CHECK(class_delay.diagnostics().conditioned_entrance);

  const auto unaccepted = mwperf::condition_tag_initial_law(
      all_admissions,
      mwperf::PalmConditionV1{
          mwperf::RankPalmConditionV1{mwperf::BigNat{2U}}});
  REQUIRE_FALSE(unaccepted);
  CHECK(unaccepted.error().code == "c23.fifo_condition_not_authorized");
}

TEST_CASE("C23 rejects equal-shaped service views from another projection",
          "[c23][integration][binding][negative]") {
  const auto local = make_fifo_projection();
  const auto foreign = make_fifo_projection(true);
  REQUIRE_FALSE(local.projection.fingerprint() ==
                foreign.projection.fingerprint());

  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          local.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto& local_split =
      require_available(local.projection.predictive_service_split());
  const auto& foreign_split =
      require_available(foreign.projection.predictive_service_split());

  const auto foreign_entrance =
      mwperf::lift_fifo_tag_state(admission, foreign_split);
  REQUIRE_FALSE(foreign_entrance);
  CHECK_FALSE(foreign_entrance.error().code.empty());

  const auto initial =
      require_value(mwperf::lift_fifo_tag_state(admission, local_split));
  const auto& foreign_service =
      require_available(foreign.projection.temporal_service_kernel());
  const auto rejected = mwperf::evaluate_fifo_delay_distribution(
      initial, foreign_service,
      mwperf::HorizonSpec{mwperf::BigNat{2U}, false, false},
      c21::solver_policy(local.fixture));
  REQUIRE_FALSE(rejected);
  CHECK_FALSE(rejected.error().code.empty());
}

TEST_CASE("C23 rejects malformed predictive service partitions",
          "[c23][integration][fifo][split][negative]") {
  const auto path = make_fifo_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto& split =
      require_available(path.projection.predictive_service_split());

  const auto wrong_mass = require_value(
      mwperf::testing::C23FixtureAccess::with_predictive_split_fault(
          split, mwperf::testing::C23PredictiveSplitFaultV1::
                     conditional_mass_mismatch));
  const auto mass_rejected =
      mwperf::lift_fifo_tag_state(admission, wrong_mass);
  REQUIRE_FALSE(mass_rejected);
  CHECK(mass_rejected.error().code ==
        "c23.fifo_split_not_chronological_partition");

  const auto incomplete = require_value(
      mwperf::testing::C23FixtureAccess::with_predictive_split_fault(
          split, mwperf::testing::C23PredictiveSplitFaultV1::
                     incomplete_partition));
  const auto incomplete_rejected =
      mwperf::lift_fifo_tag_state(admission, incomplete);
  REQUIRE_FALSE(incomplete_rejected);
  CHECK(incomplete_rejected.error().code == "c23.fifo_split_incomplete");

  const auto wrong_schema = require_value(
      mwperf::testing::C23FixtureAccess::with_predictive_split_fault(
          split, mwperf::testing::C23PredictiveSplitFaultV1::
                     service_schema_mismatch));
  const auto schema_rejected =
      mwperf::lift_fifo_tag_state(admission, wrong_schema);
  REQUIRE_FALSE(schema_rejected);
  CHECK(schema_rejected.error().code ==
        "c23.fifo_split_projection_binding_mismatch");

  const auto wrong_successor_schema = require_value(
      mwperf::testing::C23FixtureAccess::with_predictive_split_fault(
          split, mwperf::testing::C23PredictiveSplitFaultV1::
                     successor_phase_schema_mismatch));
  const auto successor_schema_rejected =
      mwperf::lift_fifo_tag_state(admission, wrong_successor_schema);
  REQUIRE_FALSE(successor_schema_rejected);
  CHECK(successor_schema_rejected.error().code ==
        "c23.fifo_split_not_chronological_partition");
}

TEST_CASE("C23 validates Palm rank and pre-service backlog before tag lift",
          "[c23][integration][palm][rank][negative]") {
  const auto path = make_fifo_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto& split =
      require_available(path.projection.predictive_service_split());

  const std::vector<std::pair<
      mwperf::testing::C23AdmissionPalmFaultV1, std::string_view>> faults{
      {mwperf::testing::C23AdmissionPalmFaultV1::rank_zero,
       "c23.invalid_fifo_entrance_rank"},
      {mwperf::testing::C23AdmissionPalmFaultV1::rank_above_batch,
       "c23.invalid_fifo_entrance_rank"},
      {mwperf::testing::C23AdmissionPalmFaultV1::
           departure_exceeds_backlog,
       "c23.fifo_entrance_departure_exceeds_backlog"},
  };
  for (const auto& [fault, code] : faults) {
    CAPTURE(code);
    const auto malformed = require_value(
        mwperf::testing::C23FixtureAccess::with_admission_palm_fault(
            admission, fault));
    const auto rejected = mwperf::lift_fifo_tag_state(malformed, split);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == code);
  }
}

TEST_CASE("C23 rejects every violated passive FIFO premise at evaluation",
          "[c23][integration][fifo][hypotheses][negative]") {
  const auto path = make_fifo_projection();
  const auto admission = require_value(
      mwperf::construct_admission_palm_law(
          path.projection.marked_edge(),
          mwperf::ArrivalCountMark{
              0U, mwperf::AdmissionCountingSemanticsV1::
                      retained_edge_packet_labels}));
  const auto initial = require_value(mwperf::lift_fifo_tag_state(
      admission,
      require_available(path.projection.predictive_service_split())));
  const auto& service =
      require_available(path.projection.temporal_service_kernel());

  using Assumptions = mwperf::FifoTagAssumptionsV1;
  const std::vector<std::pair<std::string_view, bool Assumptions::*>>
      violations{
          {"priority discipline", &Assumptions::global_fifo},
          {"processor sharing", &Assumptions::global_fifo},
          {"non-unit packets", &Assumptions::unit_packets},
          {"packet loss", &Assumptions::lossless},
          {"abandonment", &Assumptions::lossless},
          {"unbounded admission batch",
           &Assumptions::finite_batches_almost_surely},
          {"zero or infinite admission intensity",
           &Assumptions::positive_finite_admission_intensity},
          {"nonpredictive service",
           &Assumptions::full_history_predictive_service},
          {"active scheduling tag", &Assumptions::passive_tag},
      };
  for (const auto& [description, premise] : violations) {
    CAPTURE(description);
    auto assumptions = initial.assumptions();
    assumptions.*premise = false;
    const auto corrupted = require_value(
        mwperf::testing::C23FixtureAccess::with_fifo_assumptions(
            initial, assumptions));
    const auto rejected = mwperf::evaluate_fifo_delay_distribution(
        corrupted, service,
        mwperf::HorizonSpec{mwperf::BigNat{4U}, false, true},
        c21::solver_policy(path.fixture));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().category ==
          mwperf::DiagnosticCategory::unavailable);
    CHECK(rejected.error().code ==
          "c23.fifo_delay_hypotheses_unavailable");
  }
}
