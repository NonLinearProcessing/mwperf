#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"

namespace {

constexpr std::string_view kHuge = "1844674407370955161600000";

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

[[nodiscard]] std::filesystem::path write_resolution_fixture(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c04-resolution";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (std::string(stem) + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedPair parse_resolution_pair(const std::string& model_text,
                                               const std::string& analysis_text) {
  auto model_document =
      mwperf::load_document(write_resolution_fixture("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);

  auto analysis_document = mwperf::load_document(
      write_resolution_fixture("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((!analysis ? analysis.error().code + ": " + analysis.error().message
                  : std::string{}));
  REQUIRE(analysis);

  const auto canonical = mwperf::canonicalize_authored_inputs(
      model.value(), analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(model).value(), std::move(analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] std::string stationary_analysis() {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":[")json") + std::string(kHuge) + R"json(",)json" +
         std::string(kHuge) + R"json(],
    "metrics":[{"id":"throughput","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":"1","parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":29,"max_search_states_per_call":7},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })json";
}

[[nodiscard]] std::string transient_analysis() {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":[)json") + std::string(kHuge) + R"json(],
    "metrics":[{"id":"law","kind":"transient_backlog_law","parameters":{"horizons":[0,1]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":29,"max_search_states_per_call":7},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"transient","parameters":{"initial_law":{"atoms":[
      {"probability":0.25,"backlog":[{"queue_id":)json" +
         std::string(kHuge) + R"json(,"value":2},{"queue_id":")json" +
         std::string(kHuge) + R"json(","value":4}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{"tag":"a"}},
      {"probability":0.75,"backlog":[{"queue_id":")json" +
         std::string(kHuge) + R"json(","value":3},{"queue_id":)json" +
         std::string(kHuge) + R"json(,"value":7}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{"tag":"b"}}
    ]}}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })json";
}

[[nodiscard]] std::string one_queue_analysis(const std::string& target) {
  return R"({"analysis_schema_version":"1.0.0","targets":[)" + target +
         R"(],"metrics":[{"id":"m","kind":"stationary_throughput","parameters":{}}],"surrogate":{"id":"future","version":null,"parameters":{}},"resolution":{"level":{"max_states":null,"max_row_atoms":null},"tail":{"kind":"none","parameters":{}},"phase":{"max_phase_states":null},"optimizer":{"max_calls":null,"max_search_states_per_call":null},"sampling":{"max_generator_draws":null},"tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}},"selection":{"kind":"stationary_unique","parameters":{}},"solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}})";
}

[[nodiscard]] std::string one_queue_model(const std::string& arrival_queue) {
  return R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":[{"id":1}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":null,"max_search_states":null}},"arrival":{"family":"deterministic_trace","events":[{"slot":0,"queue_id":)" +
         arrival_queue + R"(,"count":1}]}})";
}

[[nodiscard]] std::string model(const std::string& scheduler,
                                const std::string& arrival) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":31,"warmup_slots":3,"termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,"queues":[
      {"id":)json") + std::string(kHuge) +
         R"json(,"legacy_voq":[0,0]},{"id":")json" +
         std::string(kHuge) + R"json(","legacy_voq":[0,1]}],"legacy_n_ports":2},
    "scheduler":)json" + scheduler + R"json(,
    "arrival":)json" + arrival + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"sparse_nonzero","include_packet_events":true,"include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{"purpose":"c04"}
  })json";
}

[[nodiscard]] std::array<std::string, 5U> schedulers() {
  const std::string numeric(kHuge);
  const std::string text = "\"" + numeric + "\"";
  return {
      R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":)json" +
          numeric + R"json(,"input":"i0","output":"o0"},{"queue_id":)json" +
          text + R"json(,"input":"i1","output":"o1"}]},"priority":[)json" +
          text + "," + numeric + "]}}",
      R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":)json" +
          numeric + R"json(,"left":0,"right":1},{"queue_id":)json" + text +
          R"json(,"left":1,"right":2}]},"priority":[)json" + text + "," +
          numeric + "]}}",
      R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v"],"links":[{"queue_id":)json" +
          numeric + R"json(,"u":"u","v":"v"},{"queue_id":)json" + text +
          R"json(,"u":"u","v":"v"}]},"priority":[)json" + text + "," +
          numeric + "]}}",
      std::string(R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":)json") +
          "[" + text + "," + numeric +
          R"json(],"max_search_states":5}})json",
      R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[5],"demands":[{"queue_id":)json" +
          numeric + R"json(,"demand":[5]},{"queue_id":)json" + text +
          R"json(,"demand":[0]}]},"priority":[)json" + text + "," + numeric +
          R"json(],"max_search_states":5}})json",
  };
}

[[nodiscard]] std::array<std::string, 6U> arrivals() {
  const std::string numeric(kHuge);
  const std::string text = "\"" + numeric + "\"";
  return {
      R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":)json" +
          text + R"json(,"count":1},{"slot":1,"queue_id":)json" + numeric +
          R"json(,"count":2}],"metadata":{}})json",
      R"json({"family":"periodic_global_phase","period":2,"phase":0,"sources":[{"id":"s","entries":[{"offset":0,"queue_id":)json" +
          text + R"json(,"count":1},{"offset":1,"queue_id":)json" + numeric +
          R"json(,"count":1}]}],"metadata":{}})json",
      R"json({"family":"periodic_source_delays","period":2,"sources":[{"id":"s","delay":0,"entries":[{"offset":0,"queue_id":)json" +
          text + R"json(,"count":1},{"offset":1,"queue_id":)json" + numeric +
          R"json(,"count":1}]}],"metadata":{}})json",
      R"json({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kind":"deterministic","d":1},"destination_pmf":[{"queue_id":)json" +
          text + R"json(,"probability":0.5},{"queue_id":)json" + numeric +
          R"json(,"probability":0.5}]}],"metadata":{}})json",
      R"json({"family":"independent_private_markov_renewal","sources":[{"id":"s","states":["on"],"initial":{"state":"on"},"gaps":[{"state":"on","d":1}],"transitions":[{"state":"on","next_state":"on","probability":1}],"destination_pmf":[{"queue_id":)json" +
          text + R"json(,"probability":0.5},{"queue_id":)json" + numeric +
          R"json(,"probability":0.5}]}],"metadata":{}})json",
      R"json({"family":"shared_joint_round_markov_renewal","sources":[{"id":"s"}],"states":["on"],"initial":{"state":"on"},"outcomes":[{"state":"on","next_state":"on","probability":1,"emissions":[{"source_id":"s","d":1,"queue_id":)json" +
          text + R"json(},{"source_id":"s","d":1,"queue_id":)json" + numeric +
          R"json(}]}],"metadata":{}})json",
  };
}

struct Calls final {
  std::array<unsigned int, 5U> families{};
  unsigned int arrival = 0U;
  unsigned int support = 0U;
  unsigned int initial = 0U;
  bool token_preserved = true;
  std::weak_ptr<const void> constraint_owner;
  std::weak_ptr<const void> arrival_owner;
  std::weak_ptr<const void> initial_owner;
};

[[nodiscard]] mwperf::detail::ResolutionChildServices successful_children(
    Calls& calls) {
  mwperf::detail::ResolutionChildServices children;
  children.constraint = [&calls](const mwperf::AuthoredSchedulerConfig& scheduler,
                                 const mwperf::QueueCatalog& queues) {
    mwperf::detail::ConstraintCompilerServices services;
    const auto make_product = [&calls](const std::size_t index,
                                       const mwperf::ServiceFamily family) {
      ++calls.families[index];
      auto owner = std::make_shared<const std::size_t>(index);
      calls.constraint_owner = owner;
      return mwperf::CompiledConstraintProduct::for_fixture(family,
                                                            std::move(owner));
    };
    services.crossbar = [&make_product](const mwperf::ResolvedCrossbarConstraint&) {
      return make_product(0U, mwperf::ServiceFamily::crossbar_matching);
    };
    services.intervals = [&make_product](const mwperf::ResolvedIntervalConstraint&) {
      return make_product(1U,
                          mwperf::ServiceFamily::nonoverlapping_intervals);
    };
    services.node_exclusive =
        [&make_product](const mwperf::ResolvedNodeExclusiveConstraint&) {
          return make_product(2U,
                              mwperf::ServiceFamily::node_exclusive_matching);
        };
    services.conflicts = [&make_product](const mwperf::ResolvedConflictConstraint&) {
      return make_product(3U, mwperf::ServiceFamily::pairwise_conflicts);
    };
    services.packing = [&make_product](const mwperf::ResolvedPackingConstraint&) {
      return make_product(4U, mwperf::ServiceFamily::resource_packing);
    };
    return mwperf::detail::compile_constraint_descriptor_with_child_services(
        scheduler, queues, services);
  };
  children.arrival =
      [&calls](const mwperf::AuthoredArrivalConfig&,
               const mwperf::PhysicalBindingIdentity& identity,
               std::span<const mwperf::BoundQueueReference>,
               const mwperf::QueueCatalog&) {
        ++calls.arrival;
        auto owner = std::make_shared<const std::string>("compiled-arrival");
        calls.arrival_owner = owner;
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            identity, std::move(owner));
      };
  children.support =
      [&calls](const mwperf::detail::ArrivalCompilationToken& token,
               const mwperf::PhysicalBindingIdentity& identity,
               std::span<const mwperf::BoundQueueReference>,
               const mwperf::QueueCatalog& queues) {
        ++calls.support;
        const auto expected = calls.arrival_owner.lock();
        calls.token_preserved = calls.token_preserved && expected &&
                                token.binding() == identity &&
                                token.owner_for_adapter().get() ==
                                    expected.get();
        return mwperf::QueueMask::from_bytes({1U, 0U}, queues.size());
      };
  children.initial =
      [&calls](const mwperf::detail::ArrivalCompilationToken& token,
               const mwperf::ResolvedTransientInitialLaw&,
               const mwperf::PhysicalBindingIdentity& identity,
               std::span<const mwperf::BoundQueueReference>,
               const mwperf::QueueCatalog&) {
        ++calls.initial;
        const auto expected = calls.arrival_owner.lock();
        calls.token_preserved = calls.token_preserved && expected &&
                                token.binding() == identity &&
                                token.owner_for_adapter().get() ==
                                    expected.get();
        auto owner = std::make_shared<const std::string>("compiled-initial");
        calls.initial_owner = owner;
        return mwperf::detail::InitialCompilationToken::for_fixture(
            identity, std::move(owner));
      };
  return children;
}

void refresh_analysis_context(ParsedPair& pair,
                              std::shared_ptr<mwperf::AnalysisContext> context) {
  pair.analysis.context = context;
  for (auto& metric : pair.analysis.metrics) {
    metric.context = context;
  }
  pair.fingerprints = mwperf::fingerprint_inputs(
      mwperf::canonicalize_authored_inputs(pair.model, pair.analysis));
}

void refresh_model_fingerprint(ParsedPair& pair) {
  pair.fingerprints = mwperf::fingerprint_inputs(
      mwperf::canonicalize_authored_inputs(pair.model, pair.analysis));
}

}  // namespace

TEST_CASE("C04 resolves the structural five-by-six family matrix",
          "[c04][integration]") {
  constexpr std::array<mwperf::ServiceFamily, 5U> expected_service{
      mwperf::ServiceFamily::crossbar_matching,
      mwperf::ServiceFamily::nonoverlapping_intervals,
      mwperf::ServiceFamily::node_exclusive_matching,
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::ServiceFamily::resource_packing,
  };
  constexpr std::array<mwperf::OptimizerId, 5U> expected_optimizer{
      mwperf::OptimizerId::hungarian_exact,
      mwperf::OptimizerId::weighted_interval_dp_exact,
      mwperf::OptimizerId::edmonds_blossom_exact,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::OptimizerId::binary_packing_memo_exact,
  };
  constexpr std::array<mwperf::ArrivalFamily, 6U> expected_arrival{
      mwperf::ArrivalFamily::deterministic_trace,
      mwperf::ArrivalFamily::periodic_global_phase,
      mwperf::ArrivalFamily::periodic_source_delays,
      mwperf::ArrivalFamily::independent_marked_renewal,
      mwperf::ArrivalFamily::independent_private_markov_renewal,
      mwperf::ArrivalFamily::shared_joint_round_markov_renewal,
  };

  const auto scheduler_values = schedulers();
  const auto arrival_values = arrivals();
  for (std::size_t scheduler = 0U; scheduler < scheduler_values.size();
       ++scheduler) {
    for (std::size_t arrival = 0U; arrival < arrival_values.size(); ++arrival) {
      CAPTURE(scheduler, arrival);
      const ParsedPair pair = parse_resolution_pair(
          model(scheduler_values[scheduler], arrival_values[arrival]),
          stationary_analysis());
      Calls calls;
      const auto children = successful_children(calls);
      auto resolved =
          mwperf::detail::resolve_physical_instance_with_child_services(
              pair.model, pair.analysis, pair.fingerprints, children);
      INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                      : std::string{}));
      REQUIRE(resolved);
      CHECK(resolved.value().service_identity().family ==
            expected_service[scheduler]);
      CHECK(resolved.value().service_identity().optimizer ==
            expected_optimizer[scheduler]);
      CHECK(resolved.value().arrival().family() == expected_arrival[arrival]);
      CHECK(resolved.value().arrival().queue_references().size() == 2U);
      CHECK(resolved.value().targets().values()[0].queue.ordinal() == 1U);
      CHECK(resolved.value().targets().values()[1].queue.ordinal() == 0U);
      CHECK(resolved.value().priority().queue_at_rank(0U).ordinal() == 1U);
      CHECK(resolved.value().timing() ==
            mwperf::TimingConvention::early_service_late_admission);
      CHECK(resolved.value().fingerprints() == pair.fingerprints);
      CHECK(resolved.value().arrival().identity().combined_input ==
            pair.fingerprints.combined);
      CHECK(resolved.value().arrival().identity().queue_cardinality == 2U);
      CHECK(resolved.value().constraint().compiled_product().has_owner());
      CHECK(resolved.value().arrival().has_compiled_product());
      CHECK_FALSE(calls.constraint_owner.expired());
      CHECK_FALSE(calls.arrival_owner.expired());
      CHECK(calls.families[scheduler] == 1U);
      CHECK(calls.arrival == 1U);
      CHECK(calls.support == 1U);
      CHECK(calls.initial == 0U);
      CHECK(calls.token_preserved);
      REQUIRE(resolved.value().optimizer_budget().effective_per_call);
      const std::string expected_cap = scheduler >= 3U ? "5" : "7";
      CHECK(resolved.value()
                .optimizer_budget()
                .effective_per_call->to_decimal_string() == expected_cap);
    }
  }
}

TEST_CASE("C04 retains coupled transient atoms and validates one initial law",
          "[c04][integration]") {
  const ParsedPair pair = parse_resolution_pair(
      model(schedulers()[3], arrivals()[0]), transient_analysis());
  Calls calls;
  const auto children = successful_children(calls);
  auto resolved = mwperf::detail::resolve_physical_instance_with_child_services(
      pair.model, pair.analysis, pair.fingerprints, children);
  INFO((!resolved ? resolved.error().code + ": " + resolved.error().message
                  : std::string{}));
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_law());
  const auto& binding = *resolved.value().initial_law();
  CHECK(binding.identity() == resolved.value().arrival().identity());
  CHECK(binding.has_compiled_product());
  CHECK_FALSE(calls.initial_owner.expired());
  REQUIRE(binding.law().atoms.size() == 2U);
  CHECK(binding.law().atoms[0].probability.exact_value().to_canonical_string() ==
        "1/4");
  CHECK(binding.law().atoms[1].probability.exact_value().to_canonical_string() ==
        "3/4");
  CHECK(binding.law().atoms[0].backlog[0].to_decimal_string() == "2");
  CHECK(binding.law().atoms[0].backlog[1].to_decimal_string() == "4");
  CHECK(binding.law().atoms[1].backlog[0].to_decimal_string() == "7");
  CHECK(binding.law().atoms[1].backlog[1].to_decimal_string() == "3");
  CHECK(binding.law().atoms[0].probability_source.json_pointer().ends_with(
      "/probability"));
  CHECK(binding.law().atoms[0].arrival_state_source.json_pointer().ends_with(
      "/arrival_state"));
  CHECK(calls.initial == 1U);
  CHECK(calls.token_preserved);
}

TEST_CASE("C04 resolved snapshots support concurrent read-only queries",
          "[c04][integration]") {
  const ParsedPair pair = parse_resolution_pair(
      model(schedulers()[3], arrivals()[0]), stationary_analysis());
  Calls calls;
  const auto children = successful_children(calls);
  auto result = mwperf::detail::resolve_physical_instance_with_child_services(
      pair.model, pair.analysis, pair.fingerprints, children);
  REQUIRE(result);
  const auto resolved =
      std::make_shared<const mwperf::ResolvedInstance>(std::move(result).value());
  std::atomic<bool> consistent{true};
  std::vector<std::jthread> readers;
  for (unsigned int thread = 0U; thread < 6U; ++thread) {
    readers.emplace_back([resolved, &consistent] {
      for (unsigned int iteration = 0U; iteration < 200U; ++iteration) {
        const auto first = resolved->queues().index_at(0U);
        if (!first || resolved->queues().size() != 2U ||
            resolved->priority().rank_of(first.value()) != 1U ||
            !resolved->serviceable().at(first.value()) ||
            resolved->fingerprints().combined !=
                resolved->arrival().identity().combined_input) {
          consistent.store(false);
        }
      }
    });
  }
  readers.clear();
  CHECK(consistent.load());
}

TEST_CASE("C04 enforces serviceability before arrival support",
          "[c04][integration][negative]") {
  ParsedPair pair = parse_resolution_pair(
      model(schedulers()[4],
            R"({"family":"deterministic_trace","events":[],"metadata":{}})"),
      stationary_analysis());
  auto& scheduler = std::get<mwperf::ResourcePackingMaxWeightScheduler>(
      pair.model.scheduler.value);
  scheduler.constraint.value.demands.value[0].demand.value[0].value =
      mwperf::BigNat(std::uint64_t{6U});
  refresh_model_fingerprint(pair);

  Calls calls;
  const auto children = successful_children(calls);
  const auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK(resolved.error().code == "queue_not_individually_serviceable");
  CHECK(calls.families[4] == 1U);
  CHECK(calls.arrival == 0U);
  CHECK(calls.support == 0U);
}

TEST_CASE("C04 rejects target and arrival queue references before C09",
          "[c04][integration][negative]") {
  SECTION("target") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    context->targets.queue_ids[0] =
        mwperf::TypedLabel::text("absent-target").value();
    refresh_analysis_context(pair, std::move(context));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "unknown_queue_reference");
    CHECK(calls.arrival == 0U);
  }

  SECTION("arrival") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    auto& arrival = std::get<mwperf::DeterministicTraceArrival>(
        pair.model.arrival.value);
    arrival.events.value[0].queue_id.value = mwperf::QueueId(
        mwperf::TypedLabel::text("absent-arrival").value());
    refresh_model_fingerprint(pair);
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "unknown_queue_reference");
    CHECK(calls.arrival == 0U);
    CHECK(calls.support == 0U);
  }

  SECTION("duplicate target") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    context->targets.queue_ids[1] = context->targets.queue_ids[0];
    refresh_analysis_context(pair, std::move(context));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "duplicate_target_queue");
    CHECK(calls.arrival == 0U);
  }
}

TEST_CASE("C04 preserves numeric versus string queue identity at references",
          "[c04][integration][negative]") {
  SECTION("target string does not bind numeric queue") {
    const ParsedPair pair = parse_resolution_pair(one_queue_model("1"),
                                                  one_queue_analysis("\"1\""));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "unknown_queue_reference");
    CHECK(calls.arrival == 0U);
  }

  SECTION("arrival string does not bind numeric queue") {
    const ParsedPair pair = parse_resolution_pair(one_queue_model("\"1\""),
                                                  one_queue_analysis("1"));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "unknown_queue_reference");
    CHECK(calls.arrival == 0U);
  }
}

TEST_CASE("C04 rejects compatibility arrivals before C09",
          "[c04][integration][negative]") {
  const ParsedPair pair = parse_resolution_pair(
      model(schedulers()[3],
            R"({"family":"iid_table","alphabet":[{"id":"a","edges":[],"probability":1}]})"),
      stationary_analysis());
  Calls calls;
  const auto children = successful_children(calls);
  const auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK(resolved.error().code == "unsupported_arrival_family");
  CHECK(calls.arrival == 0U);
  CHECK(calls.support == 0U);
}

TEST_CASE("C04 revalidates complete transient backlog coupling",
          "[c04][integration][negative]") {
  SECTION("incomplete") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    auto& transient =
        std::get<mwperf::TransientSelection>(context->selection);
    transient.atoms[0].backlog.pop_back();
    refresh_analysis_context(pair, std::move(context));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "incomplete_initial_backlog");
    CHECK(calls.arrival == 0U);
  }

  SECTION("duplicate") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    auto& transient =
        std::get<mwperf::TransientSelection>(context->selection);
    transient.atoms[0].backlog[1].queue_id =
        transient.atoms[0].backlog[0].queue_id;
    refresh_analysis_context(pair, std::move(context));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "duplicate_initial_backlog_queue");
    CHECK(calls.arrival == 0U);
  }

  SECTION("unknown queue points to the queue_id leaf") {
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    auto& transient =
        std::get<mwperf::TransientSelection>(context->selection);
    transient.atoms[0].backlog[0].queue_id =
        mwperf::TypedLabel::text("absent-initial-queue").value();
    refresh_analysis_context(pair, std::move(context));
    Calls calls;
    const auto children = successful_children(calls);
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "unknown_queue_reference");
    REQUIRE(resolved.error().json_pointer);
    CHECK(resolved.error().json_pointer->ends_with("/queue_id"));
    CHECK(calls.arrival == 0U);
  }
}

TEST_CASE("C04 resolves optimizer cap precedence without a mutable ledger",
          "[c04][integration]") {
  struct Case final {
    std::size_t scheduler;
    std::optional<std::uint64_t> physical;
    std::optional<std::uint64_t> analysis;
    std::optional<std::uint64_t> effective;
  };
  constexpr std::array<Case, 6U> cases{{
      {0U, std::nullopt, std::nullopt, std::nullopt},
      {3U, 5U, std::nullopt, 5U},
      {0U, std::nullopt, 7U, 7U},
      {3U, 5U, 5U, 5U},
      {3U, 5U, 9U, 5U},
      {3U, 9U, 5U, 5U},
  }};

  for (const Case& item : cases) {
    CAPTURE(item.scheduler, item.physical, item.analysis, item.effective);
    ParsedPair pair = parse_resolution_pair(
        model(schedulers()[item.scheduler], arrivals()[0]),
        stationary_analysis());
    if (item.scheduler == 3U) {
      auto& scheduler = std::get<mwperf::ConflictGraphMaxWeightScheduler>(
          pair.model.scheduler.value);
      scheduler.max_search_states.value =
          item.physical.has_value()
              ? std::optional<mwperf::BigNat>(mwperf::BigNat(*item.physical))
              : std::nullopt;
    }
    auto context = std::make_shared<mwperf::AnalysisContext>(*pair.analysis.context);
    context->resolution.optimizer.max_search_states_per_call =
        item.analysis.has_value()
            ? std::optional<mwperf::BigNat>(mwperf::BigNat(*item.analysis))
            : std::nullopt;
    const auto huge_calls = mwperf::parse_exact_nonnegative_integer(
        mwperf::JsonNumber("1844674407370955161600001"),
        mwperf::BoundPolicy::unbounded());
    REQUIRE(huge_calls);
    context->resolution.optimizer.max_calls = huge_calls.value();
    refresh_analysis_context(pair, std::move(context));
    refresh_model_fingerprint(pair);

    Calls calls;
    const auto children = successful_children(calls);
    auto resolved = mwperf::detail::resolve_physical_instance_with_child_services(
        pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE(resolved);
    const auto& policy = resolved.value().optimizer_budget();
    CHECK(policy.physical_per_call.has_value() == item.physical.has_value());
    CHECK(policy.analysis_per_call.has_value() == item.analysis.has_value());
    CHECK(policy.effective_per_call.has_value() == item.effective.has_value());
    if (item.effective.has_value()) {
      CHECK(policy.effective_per_call->to_decimal_string() ==
            std::to_string(*item.effective));
    }
    REQUIRE(policy.max_calls);
    CHECK(policy.max_calls->to_decimal_string() ==
          "1844674407370955161600001");
  }
}

TEST_CASE("C04 retains and releases opaque child-product ownership",
          "[c04][integration]") {
  std::weak_ptr<const void> constraint_owner;
  std::weak_ptr<const void> arrival_owner;
  std::weak_ptr<const void> initial_owner;
  {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    Calls calls;
    const auto children = successful_children(calls);
    auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE(resolved);
    constraint_owner = calls.constraint_owner;
    arrival_owner = calls.arrival_owner;
    initial_owner = calls.initial_owner;
    CHECK_FALSE(constraint_owner.expired());
    CHECK_FALSE(arrival_owner.expired());
    CHECK_FALSE(initial_owner.expired());
  }
  CHECK(constraint_owner.expired());
  CHECK(arrival_owner.expired());
  CHECK(initial_owner.expired());
}

TEST_CASE("C04 distinguishes each unavailable C09 child seam",
          "[c04][integration][negative]") {
  SECTION("arrival compiler") {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    Calls calls;
    auto children = successful_children(calls);
    children.arrival = nullptr;
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(resolved.error().code == "arrival_compiler_unavailable_c09");
    CHECK(calls.support == 0U);
  }

  SECTION("positive support") {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    Calls calls;
    auto children = successful_children(calls);
    children.support = nullptr;
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(resolved.error().code == "arrival_support_unavailable_c09");
    CHECK(calls.arrival == 1U);
    CHECK(calls.initial == 0U);
  }

  SECTION("transient initial law") {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    Calls calls;
    auto children = successful_children(calls);
    children.initial = nullptr;
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
    CHECK(resolved.error().code == "initial_law_compiler_unavailable_c09");
    CHECK(calls.arrival == 1U);
    CHECK(calls.support == 1U);
  }

  SECTION("foreign arrival product") {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), stationary_analysis());
    Calls calls;
    auto children = successful_children(calls);
    children.arrival =
        [](const mwperf::AuthoredArrivalConfig&,
           const mwperf::PhysicalBindingIdentity& identity,
           std::span<const mwperf::BoundQueueReference>,
           const mwperf::QueueCatalog&) {
          mwperf::PhysicalBindingIdentity foreign = identity;
          ++foreign.queue_cardinality;
          return mwperf::detail::ArrivalCompilationToken::for_fixture(
              std::move(foreign), std::make_shared<const int>(1));
        };
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "arrival_compilation_binding_mismatch");
    CHECK(calls.support == 0U);
  }

  SECTION("foreign initial product") {
    const ParsedPair pair = parse_resolution_pair(
        model(schedulers()[3], arrivals()[0]), transient_analysis());
    Calls calls;
    auto children = successful_children(calls);
    children.initial =
        [](const mwperf::detail::ArrivalCompilationToken&,
           const mwperf::ResolvedTransientInitialLaw&,
           const mwperf::PhysicalBindingIdentity& identity,
           std::span<const mwperf::BoundQueueReference>,
           const mwperf::QueueCatalog&) {
          mwperf::PhysicalBindingIdentity foreign = identity;
          ++foreign.queue_cardinality;
          return mwperf::detail::InitialCompilationToken::for_fixture(
              std::move(foreign), std::make_shared<const int>(2));
        };
    const auto resolved =
        mwperf::detail::resolve_physical_instance_with_child_services(
            pair.model, pair.analysis, pair.fingerprints, children);
    REQUIRE_FALSE(resolved);
    CHECK(resolved.error().code == "initial_compilation_binding_mismatch");
    CHECK(calls.arrival == 1U);
    CHECK(calls.support == 1U);
  }
}

TEST_CASE("C04 future-child tokens reject null ownership",
          "[c04][unit][negative]") {
  const ParsedPair pair = parse_resolution_pair(
      model(schedulers()[3], arrivals()[0]), stationary_analysis());
  const mwperf::PhysicalBindingIdentity identity{
      .combined_input = pair.fingerprints.combined,
      .arrival_family = mwperf::ArrivalFamily::deterministic_trace,
      .timing = mwperf::TimingConvention::early_service_late_admission,
      .queue_cardinality = 2U,
  };

  auto arrival = mwperf::detail::ArrivalCompilationToken::for_fixture(
      identity, std::shared_ptr<const void>{});
  REQUIRE_FALSE(arrival);
  CHECK(arrival.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(arrival.error().code == "null_arrival_compilation_fixture");

  auto initial = mwperf::detail::InitialCompilationToken::for_fixture(
      identity, std::shared_ptr<const void>{});
  REQUIRE_FALSE(initial);
  CHECK(initial.error().category == mwperf::DiagnosticCategory::internal);
  CHECK(initial.error().code == "null_initial_compilation_fixture");
}

TEST_CASE("C04 propagates a typed invalid-causal-law child failure",
          "[c04][integration][negative]") {
  const ParsedPair pair = parse_resolution_pair(
      model(schedulers()[3], arrivals()[0]), stationary_analysis());
  Calls calls;
  auto children = successful_children(calls);
  children.support =
      [&calls](const mwperf::detail::ArrivalCompilationToken&,
               const mwperf::PhysicalBindingIdentity&,
               std::span<const mwperf::BoundQueueReference>,
               const mwperf::QueueCatalog&) {
        ++calls.support;
        return mwperf::Result<mwperf::QueueMask>::failure(mwperf::Diagnostic{
            mwperf::DiagnosticCategory::input_validation,
            "c09_invalid_causal_law",
            "the injected C09 fixture rejected the causal arrival law",
            std::nullopt,
            std::nullopt,
            {},
        });
      };

  const auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(resolved.error().code == "c09_invalid_causal_law");
  CHECK(calls.arrival == 1U);
  CHECK(calls.support == 1U);
  CHECK(calls.initial == 0U);
}

TEST_CASE("C04 fingerprint mismatch invokes no child",
          "[c04][integration][negative]") {
  const ParsedPair first = parse_resolution_pair(
      model(schedulers()[3], arrivals()[0]), stationary_analysis());
  ParsedPair second = parse_resolution_pair(
      model(schedulers()[3], arrivals()[1]), stationary_analysis());
  Calls calls;
  const auto children = successful_children(calls);
  const auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          first.model, first.analysis, second.fingerprints, children);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().code == "input_fingerprint_mismatch");
  const std::array<unsigned int, 5U> no_family_calls{};
  CHECK(calls.families == no_family_calls);
  CHECK(calls.arrival == 0U);
  CHECK(calls.support == 0U);
}
