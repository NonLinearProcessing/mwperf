#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/packing.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

struct PreparedQuery final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct SolveAttempt final {
  mwperf::Result<mwperf::OptimizerSolution> result;
  mwperf::SearchAccounting accounting;
  mwperf::BigNat calls_reserved;
};

[[nodiscard]] std::filesystem::path write_input(const std::string& stem,
                                                const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c08-dispatch";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (stem + '-' + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string analysis_text() {
  return R"({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":64,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })";
}

[[nodiscard]] std::string model_text(const std::string& scheduler,
                                     const std::string& queues) {
  return R"({"schema_version":"3.0.0","run":{"seed":8,"slots":3,"warmup_slots":0,"termination":"fixed_slots"},"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues + R"(},"scheduler":)" + scheduler +
         R"(,"arrival":{"family":"deterministic_trace","events":[]},"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})";
}

[[nodiscard]] ParsedPair parse_pair(const std::string& scheduler,
                                    const std::string& queues) {
  auto model_document = mwperf::load_document(
      write_input("model", model_text(scheduler, queues)));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto parsed_model = mwperf::parse_model_config_v3(model_node.value());
  INFO((parsed_model ? std::string{} : parsed_model.error().code));
  REQUIRE(parsed_model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text()));
  REQUIRE(analysis_document);
  auto parsed_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(parsed_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      parsed_model.value(), parsed_analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(parsed_model).value(),
                    std::move(parsed_analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] mwperf::detail::ResolutionChildServices
production_constraint_children() {
  mwperf::detail::ResolutionChildServices services;
  services.constraint =
      [](const mwperf::AuthoredSchedulerConfig& scheduler,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::compile_constraint_descriptor(scheduler, catalog);
      };
  services.arrival =
      [](const mwperf::AuthoredArrivalConfig&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-arrival-placeholder");
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  services.support =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::PhysicalBindingIdentity&,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::QueueMask::from_bytes(
            std::vector<std::uint8_t>(catalog.size(), 0U), catalog.size());
      };
  services.initial =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::ResolvedTransientInitialLaw&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-initial-placeholder");
        return mwperf::detail::InitialCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  return services;
}

[[nodiscard]] mwperf::ResolvedInstance resolved_instance(
    const std::string& scheduler, const std::string& queues) {
  const ParsedPair pair = parse_pair(scheduler, queues);
  const auto children = production_constraint_children();
  auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  INFO((resolved ? std::string{} : resolved.error().code));
  REQUIRE(resolved);
  REQUIRE(resolved.value().constraint().compiled_product().has_owner());
  return std::move(resolved).value();
}

[[nodiscard]] mwperf::PrimaryWeights make_primary(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values) {
  auto result = mwperf::PrimaryWeights::from_values(
      mwperf::QueueDimensionToken::from_instance(instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] PreparedQuery prepare_query(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values,
    std::vector<std::uint8_t> eligibility_values) {
  auto primary = make_primary(instance, std::move(values));
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      primary.dimension(), std::move(eligibility_values));
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary, instance.priority(), eligibility.value());
  REQUIRE(weights);
  return PreparedQuery{std::move(primary),
                       std::move(eligibility).value(),
                       std::move(weights).value()};
}

[[nodiscard]] mwperf::OptimizerExecutionContext execution_context(
    const mwperf::ResolvedInstance& instance) {
  auto result =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SolveAttempt solve_attempt(
    const mwperf::ResolvedInstance& instance, const PreparedQuery& query) {
  auto context = execution_context(instance);
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto result = mwperf::solve_exact(instance.constraint(), query.eligibility,
                                    query.weights, budget.value());
  const auto accounting = budget.value().accounting();
  if (result) {
    auto validation = mwperf::validate_optimizer_solution(
        result.value(), instance.constraint(), query.eligibility,
        query.weights);
    INFO((validation ? std::string{} : validation.error().code));
    REQUIRE(validation);
    CHECK(result.value().accounting() == accounting);
  }
  return SolveAttempt{std::move(result), accounting,
                      context.ledger_snapshot().calls_reserved()};
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::vector<mwperf::BigNat> naturals(
    const std::initializer_list<std::uint64_t> values) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] mwperf::BigNat power_of_two(const unsigned int shift) {
  mwperf::BigInt value = 1;
  value <<= shift;
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::string queue_list(const std::size_t count) {
  std::ostringstream output;
  output << '[';
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"q" << queue << "\"";
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string conflict_scheduler(
    const std::string& limit = "null") {
  return R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":)" +
         limit + "}}";
}

[[nodiscard]] std::string packing_scheduler(
    const std::string& limit = "null") {
  return R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["cpu","ram"],"capacity":[4,4],"demands":[{"queue_id":"q0","demand":[4,1]},{"queue_id":"q1","demand":[1,4]},{"queue_id":"q2","demand":[2,2]},{"queue_id":"q3","demand":[2,2]}]},"priority":["q0","q1","q2","q3"],"max_search_states":)" +
         limit + "}}";
}

[[nodiscard]] bool conflict_feasible(
    const mwperf::ResolvedConflictConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  for (const auto& pair : constraint.conflicts) {
    if (selected[pair.first.ordinal()] != 0U &&
        selected[pair.second.ordinal()] != 0U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool packing_feasible(
    const mwperf::ResolvedPackingConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<mwperf::BigNat> used(constraint.resources.size(),
                                   mwperf::BigNat(0U));
  for (const auto& demand : constraint.demands) {
    if (selected[demand.queue.ordinal()] == 0U) {
      continue;
    }
    for (std::size_t resource = 0U; resource < used.size(); ++resource) {
      used[resource] += demand.demand[resource];
    }
  }
  for (std::size_t resource = 0U; resource < used.size(); ++resource) {
    if (used[resource] > constraint.capacity[resource]) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool recursive_feasible(
    const mwperf::ConstraintDescriptor& descriptor,
    const std::vector<std::uint8_t>& selected) {
  return std::visit(
      [&selected](const auto& constraint) {
        using Constraint = std::decay_t<decltype(constraint)>;
        if constexpr (std::is_same_v<Constraint,
                                     mwperf::ResolvedConflictConstraint>) {
          return conflict_feasible(constraint, selected);
        } else if constexpr (std::is_same_v<
                                 Constraint,
                                 mwperf::ResolvedPackingConstraint>) {
          return packing_feasible(constraint, selected);
        } else {
          return false;
        }
      },
      descriptor.value());
}

[[nodiscard]] mwperf::BigNat exhaustive_forced_primary(
    const mwperf::ResolvedInstance& instance,
    const mwperf::EligibilityMask& eligibility,
    const mwperf::PrimaryWeights& primary, const std::size_t target,
    const mwperf::ForcedTargetBit side) {
  REQUIRE(primary.size() < std::numeric_limits<std::uint64_t>::digits);
  std::optional<mwperf::BigNat> best;
  const std::uint64_t count = std::uint64_t{1U} << primary.size();
  for (std::uint64_t mask = 0U; mask < count; ++mask) {
    std::vector<std::uint8_t> selected(primary.size(), 0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      selected[queue] =
          static_cast<std::uint8_t>((mask >> queue) & std::uint64_t{1U});
      if (queue != target && selected[queue] != 0U &&
          eligibility.bytes()[queue] == 0U) {
        allowed = false;
      }
    }
    if ((selected[target] != 0U) !=
        (side == mwperf::ForcedTargetBit::one)) {
      allowed = false;
    }
    if (!allowed || !recursive_feasible(instance.constraint(), selected)) {
      continue;
    }
    mwperf::BigNat objective(0U);
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      if (queue != target && selected[queue] != 0U) {
        objective += primary.values()[queue];
      }
    }
    if (!best.has_value() || objective > *best) {
      best = std::move(objective);
    }
  }
  REQUIRE(best.has_value());
  return std::move(*best);
}

[[nodiscard]] mwperf::TargetIndex target(
    const mwperf::ResolvedInstance& instance, const std::size_t ordinal) {
  auto result = mwperf::TargetIndex::from_instance(instance, ordinal);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::string forced_conflict_scheduler() {
  return R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q0","q2"],["q1","q3"]]},"priority":["q0","q1","q2","q3","q4"],"max_search_states":null}})";
}

[[nodiscard]] std::string forced_packing_scheduler() {
  return R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r0","r1"],"capacity":[3,3],"demands":[{"queue_id":"q0","demand":[2,3]},{"queue_id":"q1","demand":[1,0]},{"queue_id":"q2","demand":[0,1]},{"queue_id":"q3","demand":[2,2]},{"queue_id":"q4","demand":[0,0]}]},"priority":["q0","q1","q2","q3","q4"],"max_search_states":null}})";
}

[[nodiscard]] std::string large_packing_scheduler(
    const std::size_t queue_count, const std::string& huge) {
  std::ostringstream demands;
  demands << '[';
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    if (queue != 0U) {
      demands << ',';
    }
    demands << "{\"queue_id\":\"q" << queue << "\",\"demand\":[";
    demands << (queue == 0U ? huge : "0") << "]}";
  }
  demands << ']';
  return R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["wide"],"capacity":[)" +
         huge + R"(],"demands":)" + demands.str() +
         R"(},"priority":null,"max_search_states":null}})";
}

}  // namespace

TEST_CASE("C08 canonical conflict and packing configs reach their exact backends",
          "[c08][integration][dispatch]") {
  struct Case final {
    std::string scheduler;
    std::string queues;
    std::vector<mwperf::BigNat> primary;
    std::vector<std::uint8_t> expected;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId backend;
  };
  std::vector<Case> cases;
  cases.push_back(Case{conflict_scheduler(), R"(["q0","q1","q2"])",
                       naturals({3U, 5U, 3U}), {1U, 0U, 1U},
                       mwperf::ServiceFamily::pairwise_conflicts,
                       mwperf::OptimizerId::mwis_branch_memo_exact});
  cases.push_back(Case{packing_scheduler(),
                       R"(["q0","q1","q2","q3"])",
                       naturals({7U, 7U, 6U, 6U}), {0U, 0U, 1U, 1U},
                       mwperf::ServiceFamily::resource_packing,
                       mwperf::OptimizerId::binary_packing_memo_exact});

  for (auto& family_case : cases) {
    const auto instance =
        resolved_instance(family_case.scheduler, family_case.queues);
    CHECK(instance.constraint().family() == family_case.family);
    CHECK(instance.constraint().identity().optimizer == family_case.backend);
    const auto query = prepare_query(
        instance, std::move(family_case.primary),
        std::vector<std::uint8_t>(family_case.expected.size(), 1U));
    auto attempt = solve_attempt(instance, query);
    INFO((attempt.result ? std::string{} : attempt.result.error().code));
    REQUIRE(attempt.result);
    CHECK(schedule_bits(attempt.result.value().schedule()) ==
          family_case.expected);
    CHECK(attempt.result.value().family() == family_case.family);
    CHECK(attempt.result.value().backend_id() == family_case.backend);
    CHECK(attempt.accounting.completed_expansions() > mwperf::BigNat(0U));
    CHECK_FALSE(attempt.accounting.exhausted());
    CHECK(attempt.calls_reserved == mwperf::BigNat(1U));
  }
}

TEST_CASE("C08 all five preferred scheduler IDs retain one exact dispatch identity",
          "[c08][integration][dispatch][regression]") {
  struct Case final {
    std::string scheduler;
    std::string queues;
    std::vector<mwperf::BigNat> primary;
    std::vector<std::uint8_t> expected;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId backend;
  };
  std::vector<Case> cases;
  cases.push_back(Case{
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"}]},"priority":null}})",
      R"(["q0","q1","q2"])", naturals({10U, 4U, 4U}),
      {1U, 0U, 0U}, mwperf::ServiceFamily::crossbar_matching,
      mwperf::OptimizerId::hungarian_exact});
  cases.push_back(Case{
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":3},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":1,"right":3}]},"priority":null}})",
      R"(["q0","q1","q2"])", naturals({10U, 4U, 4U}),
      {1U, 0U, 0U}, mwperf::ServiceFamily::nonoverlapping_intervals,
      mwperf::OptimizerId::weighted_interval_dp_exact});
  cases.push_back(Case{
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C"],"links":[{"queue_id":"q0","u":"A","v":"B"},{"queue_id":"q1","u":"B","v":"C"},{"queue_id":"q2","u":"C","v":"A"}]},"priority":null}})",
      R"(["q0","q1","q2"])", naturals({10U, 4U, 4U}),
      {1U, 0U, 0U}, mwperf::ServiceFamily::node_exclusive_matching,
      mwperf::OptimizerId::edmonds_blossom_exact});
  cases.push_back(Case{conflict_scheduler(), R"(["q0","q1","q2"])",
                       naturals({3U, 5U, 3U}), {1U, 0U, 1U},
                       mwperf::ServiceFamily::pairwise_conflicts,
                       mwperf::OptimizerId::mwis_branch_memo_exact});
  cases.push_back(Case{packing_scheduler(),
                       R"(["q0","q1","q2","q3"])",
                       naturals({7U, 7U, 6U, 6U}), {0U, 0U, 1U, 1U},
                       mwperf::ServiceFamily::resource_packing,
                       mwperf::OptimizerId::binary_packing_memo_exact});

  for (auto& family_case : cases) {
    const auto instance =
        resolved_instance(family_case.scheduler, family_case.queues);
    const auto query = prepare_query(
        instance, std::move(family_case.primary),
        std::vector<std::uint8_t>(family_case.expected.size(), 1U));
    auto attempt = solve_attempt(instance, query);
    INFO((attempt.result ? std::string{} : attempt.result.error().code));
    REQUIRE(attempt.result);
    CHECK(schedule_bits(attempt.result.value().schedule()) ==
          family_case.expected);
    CHECK(attempt.result.value().family() == family_case.family);
    CHECK(attempt.result.value().backend_id() == family_case.backend);
    CHECK(attempt.accounting.family() == family_case.family);
  }
}

TEST_CASE("C08 recursive solves are cold and deterministically replay accounting",
          "[c08][integration][determinism][accounting]") {
  struct Case final {
    std::string scheduler;
    std::string queues;
    std::vector<mwperf::BigNat> primary;
  };
  std::vector<Case> cases;
  cases.push_back(Case{conflict_scheduler(), R"(["q0","q1","q2"])",
                       naturals({3U, 5U, 3U})});
  cases.push_back(Case{packing_scheduler(),
                       R"(["q0","q1","q2","q3"])",
                       naturals({7U, 7U, 6U, 6U})});

  for (auto& family_case : cases) {
    const auto instance =
        resolved_instance(family_case.scheduler, family_case.queues);
    const std::size_t queue_count = family_case.primary.size();
    const auto query = prepare_query(
        instance, std::move(family_case.primary),
        std::vector<std::uint8_t>(queue_count, 1U));
    auto first = solve_attempt(instance, query);
    auto second = solve_attempt(instance, query);
    REQUIRE(first.result);
    REQUIRE(second.result);
    CHECK(first.result.value() == second.result.value());
    CHECK(first.accounting == second.accounting);
    CHECK(first.accounting.completed_expansions() > mwperf::BigNat(0U));
    CHECK(first.accounting.call_ordinal() == mwperf::BigNat(1U));
    CHECK(first.calls_reserved == mwperf::BigNat(1U));
    CHECK(second.calls_reserved == mwperf::BigNat(1U));
    CHECK(std::ranges::equal(first.result.value().schedule().bytes(),
                             second.result.value().schedule().bytes()));
    CHECK(std::ranges::equal(first.result.value().proof_notes(),
                             second.result.value().proof_notes()));
  }
}

TEST_CASE("C08 packing remains exact beyond sixty-four queues and machine width",
          "[c08][integration][multiprecision]") {
  constexpr std::size_t queue_count = 65U;
  const mwperf::BigNat huge = power_of_two(200U);
  const auto instance = resolved_instance(
      large_packing_scheduler(queue_count, huge.to_decimal_string()),
      queue_list(queue_count));
  const auto& geometry = std::get<mwperf::ResolvedPackingConstraint>(
      instance.constraint().value());
  REQUIRE(geometry.capacity.size() == 1U);
  CHECK(geometry.capacity[0U] == huge);

  std::vector<mwperf::BigNat> primary(queue_count, huge);
  primary[0U] += mwperf::BigNat(1U);
  const auto query = prepare_query(
      instance, std::move(primary),
      std::vector<std::uint8_t>(queue_count, 1U));
  auto attempt = solve_attempt(instance, query);
  INFO((attempt.result ? std::string{} : attempt.result.error().code));
  REQUIRE(attempt.result);
  REQUIRE(attempt.result.value().schedule().size() == queue_count);
  for (const std::uint8_t bit : attempt.result.value().schedule().bytes()) {
    CHECK(bit == 1U);
  }
  CHECK(attempt.result.value().composite_objective().bit_length() > 256U);
  CHECK(attempt.accounting.completed_expansions() > mwperf::BigNat(64U));
}

TEST_CASE("C08 forced-target primary faces agree with independent enumeration",
          "[c08][integration][forced-target]") {
  struct Case final {
    std::string scheduler;
    std::vector<mwperf::BigNat> primary;
    mwperf::BigNat expected_zero;
    mwperf::BigNat expected_one;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId backend;
  };
  std::vector<Case> cases;
  cases.push_back(Case{forced_conflict_scheduler(),
                       naturals({1000U, 7U, 6U, 5U, 4U}),
                       mwperf::BigNat(17U), mwperf::BigNat(9U),
                       mwperf::ServiceFamily::pairwise_conflicts,
                       mwperf::OptimizerId::mwis_branch_memo_exact});
  cases.push_back(Case{forced_packing_scheduler(),
                       naturals({1000U, 5U, 4U, 8U, 2U}),
                       mwperf::BigNat(19U), mwperf::BigNat(7U),
                       mwperf::ServiceFamily::resource_packing,
                       mwperf::OptimizerId::binary_packing_memo_exact});

  for (auto& family_case : cases) {
    const auto instance = resolved_instance(
        family_case.scheduler, R"(["q0","q1","q2","q3","q4"])");
    const auto query = prepare_query(instance, std::move(family_case.primary),
                                     {0U, 1U, 1U, 1U, 1U});
    const auto selected_target = target(instance, 0U);
    const auto solve_side = [&](const mwperf::ForcedTargetBit side) {
      auto context = execution_context(instance);
      auto result = mwperf::solve_forced_target(
          context, instance.constraint(), query.eligibility, query.primary,
          selected_target, side, instance.priority());
      INFO((result ? std::string{} : result.error().code));
      REQUIRE(result);
      CHECK(result.value().value == exhaustive_forced_primary(
                                          instance, query.eligibility,
                                          query.primary, 0U, side));
      CHECK(result.value().family == family_case.family);
      CHECK(result.value().backend_id == family_case.backend);
      CHECK((result.value().witness.bytes()[0U] != 0U) ==
            (side == mwperf::ForcedTargetBit::one));
      CHECK(result.value().accounting.completed_expansions() >
            mwperf::BigNat(0U));
      CHECK(context.ledger_snapshot().calls_reserved() ==
            mwperf::BigNat(1U));
      return std::move(result).value();
    };
    const auto zero = solve_side(mwperf::ForcedTargetBit::zero);
    const auto one = solve_side(mwperf::ForcedTargetBit::one);
    CHECK(zero.value == family_case.expected_zero);
    CHECK(one.value == family_case.expected_one);

    std::vector<mwperf::BigNat> changed_values(query.primary.values().begin(),
                                               query.primary.values().end());
    changed_values[0U] = power_of_two(190U);
    const auto changed = make_primary(instance, std::move(changed_values));
    for (const auto side : {mwperf::ForcedTargetBit::zero,
                            mwperf::ForcedTargetBit::one}) {
      auto context = execution_context(instance);
      auto result = mwperf::solve_forced_target(
          context, instance.constraint(), query.eligibility, changed,
          selected_target, side, instance.priority());
      REQUIRE(result);
      CHECK(result.value().value ==
            (side == mwperf::ForcedTargetBit::zero ? zero.value : one.value));
    }
  }
}

TEST_CASE("C08 search exhaustion is atomic after completed recursive work",
          "[c08][integration][negative][accounting]") {
  const std::string scheduler =
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":4}})";
  const auto instance =
      resolved_instance(scheduler, R"(["q0","q1","q2"])");
  const auto query = prepare_query(instance, naturals({1U, 1U, 1U}),
                                   {1U, 1U, 1U});
  auto attempt = solve_attempt(instance, query);
  REQUIRE_FALSE(attempt.result);
  CHECK(attempt.result.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(attempt.result.error().code == "search_state_limit_exhausted");
  CHECK(attempt.accounting.completed_expansions() == mwperf::BigNat(4U));
  CHECK(attempt.accounting.exhausted());
  REQUIRE(attempt.accounting.effective_per_call_limit());
  CHECK(*attempt.accounting.effective_per_call_limit() ==
        mwperf::BigNat(4U));
  CHECK(attempt.calls_reserved == mwperf::BigNat(1U));
}

TEST_CASE("C08 packing scope rejects an unserviceable singleton before arrivals",
          "[c08][integration][negative][scope]") {
  const std::string scheduler =
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[2]},{"queue_id":"q1","demand":[0]}]},"priority":null,"max_search_states":null}})";
  const ParsedPair pair = parse_pair(scheduler, R"(["q0","q1"])");
  const auto children = production_constraint_children();
  auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().category == mwperf::DiagnosticCategory::unavailable);
  CHECK(resolved.error().code == "queue_not_individually_serviceable");
}
