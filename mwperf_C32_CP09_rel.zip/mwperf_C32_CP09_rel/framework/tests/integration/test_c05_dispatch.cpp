#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <optional>
#include <ranges>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

[[nodiscard]] std::filesystem::path write_input(const std::string& stem,
                                                const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c05-dispatch";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (stem + '-' + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string analysis() {
  return R"({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":20,"max_search_states_per_call":5},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })";
}

[[nodiscard]] std::string model(
    const std::string& scheduler,
    const std::string& queues = R"(["q0","q1"])") {
  return R"({"schema_version":"3.0.0","run":{"seed":7,"slots":3,"warmup_slots":0,"termination":"fixed_slots"},"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues + R"(},"scheduler":)" + scheduler +
         R"(,"arrival":{"family":"deterministic_trace","events":[]},"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})";
}

[[nodiscard]] std::vector<std::string> schedulers() {
  return {
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i","output":"o0"},{"queue_id":"q1","input":"i","output":"o1"}]},"priority":null}})",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3}]},"priority":null}})",
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"v","v":"w"}]},"priority":null}})",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":9}})",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]}]},"priority":null,"max_search_states":9}})",
  };
}

[[nodiscard]] std::vector<std::string>
schedulers_with_compatible_third_queue() {
  return {
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1","o2"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o2"}]},"priority":null}})",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3},{"queue_id":"q2","left":3,"right":4}]},"priority":null}})",
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x","y"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"v","v":"w"},{"queue_id":"q2","u":"x","v":"y"}]},"priority":null}})",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":9}})",
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[3],"demands":[{"queue_id":"q0","demand":[2]},{"queue_id":"q1","demand":[2]},{"queue_id":"q2","demand":[1]}]},"priority":null,"max_search_states":9}})",
  };
}

[[nodiscard]] ParsedPair parse_pair(const std::string& model_text) {
  auto model_document =
      mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto parsed_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(parsed_model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis()));
  REQUIRE(analysis_document);
  auto parsed_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(parsed_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      parsed_model.value(), parsed_analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(parsed_model).value(),
                    std::move(parsed_analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] mwperf::Result<mwperf::CompiledConstraintProduct> product(
    const mwperf::ServiceFamily family) {
  std::shared_ptr<const void> owner =
      std::make_shared<const std::string>(mwperf::to_string(family));
  return mwperf::CompiledConstraintProduct::for_fixture(family,
                                                        std::move(owner));
}

[[nodiscard]] mwperf::detail::ConstraintCompilerServices compilers() {
  return mwperf::detail::ConstraintCompilerServices{
      .crossbar = [](const mwperf::ResolvedCrossbarConstraint&) {
        return product(mwperf::ServiceFamily::crossbar_matching);
      },
      .intervals = [](const mwperf::ResolvedIntervalConstraint&) {
        return product(mwperf::ServiceFamily::nonoverlapping_intervals);
      },
      .node_exclusive = [](const mwperf::ResolvedNodeExclusiveConstraint&) {
        return product(mwperf::ServiceFamily::node_exclusive_matching);
      },
      .conflicts = [](const mwperf::ResolvedConflictConstraint&) {
        return product(mwperf::ServiceFamily::pairwise_conflicts);
      },
      .packing = [](const mwperf::ResolvedPackingConstraint&) {
        return product(mwperf::ServiceFamily::resource_packing);
      },
  };
}

[[nodiscard]] mwperf::detail::ResolutionChildServices resolution_children() {
  mwperf::detail::ResolutionChildServices services;
  services.constraint = [](const mwperf::AuthoredSchedulerConfig& scheduler,
                           const mwperf::QueueCatalog& catalog) {
    const auto children = compilers();
    return mwperf::detail::compile_constraint_descriptor_with_child_services(
        scheduler, catalog, children);
  };
  services.arrival =
      [](const mwperf::AuthoredArrivalConfig&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("arrival");
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  services.support =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::PhysicalBindingIdentity&,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::QueueMask::from_bytes(
            std::vector<std::uint8_t>(catalog.size(), 0U), catalog.size());
      };
  services.initial =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::ResolvedTransientInitialLaw&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("initial");
        return mwperf::detail::InitialCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  return services;
}

[[nodiscard]] mwperf::ResolvedInstance resolved(
    const std::string& scheduler,
    const std::string& queues = R"(["q0","q1"])") {
  const auto pair = parse_pair(model(scheduler, queues));
  const auto children = resolution_children();
  auto result = mwperf::detail::resolve_physical_instance_with_child_services(
      pair.model, pair.analysis, pair.fingerprints, children);
  INFO((result ? std::string{} : result.error().code));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedCrossbarConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<bool> inputs(constraint.inputs.size());
  std::vector<bool> outputs(constraint.outputs.size());
  for (const auto& edge : constraint.edges) {
    if (selected[edge.queue.ordinal()] == 0U) {
      continue;
    }
    if (inputs[edge.input.ordinal()] || outputs[edge.output.ordinal()]) {
      return false;
    }
    inputs[edge.input.ordinal()] = true;
    outputs[edge.output.ordinal()] = true;
  }
  return true;
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedIntervalConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  for (std::size_t first = 0U; first < constraint.intervals.size(); ++first) {
    if (selected[constraint.intervals[first].queue.ordinal()] == 0U) {
      continue;
    }
    for (std::size_t second = first + 1U;
         second < constraint.intervals.size(); ++second) {
      if (selected[constraint.intervals[second].queue.ordinal()] == 0U) {
        continue;
      }
      const auto& lhs = constraint.intervals[first];
      const auto& rhs = constraint.intervals[second];
      if (!(lhs.right <= rhs.left || rhs.right <= lhs.left)) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedNodeExclusiveConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<bool> used(constraint.vertices.size());
  for (const auto& link : constraint.links) {
    if (selected[link.queue.ordinal()] == 0U) {
      continue;
    }
    if (used[link.u.ordinal()] || used[link.v.ordinal()]) {
      return false;
    }
    used[link.u.ordinal()] = true;
    used[link.v.ordinal()] = true;
  }
  return true;
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedConflictConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  return std::ranges::none_of(
      constraint.conflicts, [&](const auto& pair) {
        return selected[pair.first.ordinal()] != 0U &&
               selected[pair.second.ordinal()] != 0U;
      });
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedPackingConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<mwperf::BigInt> used(constraint.resources.size(), 0);
  for (const auto& demand : constraint.demands) {
    if (selected[demand.queue.ordinal()] == 0U) {
      continue;
    }
    for (std::size_t resource = 0U; resource < used.size(); ++resource) {
      used[resource] += demand.demand[resource].value();
      if (used[resource] > constraint.capacity[resource].value()) {
        return false;
      }
    }
  }
  return true;
}

template <typename Constraint>
[[nodiscard]] mwperf::Result<mwperf::detail::ExactBackendCandidate>
exhaustive_backend(
    const Constraint& constraint,
    const mwperf::CompiledConstraintProduct&,
    const mwperf::EligibilityMask& eligibility,
    const mwperf::LexWeights& weights, mwperf::SearchBudget& budget,
    const std::optional<mwperf::detail::ForcedTargetCondition>& condition,
    const mwperf::detail::ExactBackendAuthority& authority) {
  REQUIRE(weights.size() < std::numeric_limits<std::uint64_t>::digits);
  std::optional<std::vector<std::uint8_t>> best;
  mwperf::BigNat best_value(0U);
  const std::uint64_t count = std::uint64_t{1U} << weights.size();
  for (std::uint64_t mask = 0U; mask < count; ++mask) {
    std::vector<std::uint8_t> selected(weights.size(), 0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < weights.size(); ++queue) {
      selected[queue] = static_cast<std::uint8_t>((mask >> queue) & 1U);
      if (selected[queue] != 0U && eligibility.bytes()[queue] == 0U) {
        allowed = false;
      }
    }
    if (condition.has_value()) {
      const bool required = condition->bit == mwperf::ForcedTargetBit::one;
      if ((selected[condition->target.ordinal()] != 0U) != required) {
        allowed = false;
      }
    }
    if (!allowed || !feasible(constraint, selected)) {
      continue;
    }
    mwperf::BigNat value(0U);
    for (std::size_t queue = 0U; queue < weights.size(); ++queue) {
      if (selected[queue] != 0U) {
        value += weights.values()[queue];
      }
    }
    if (!best.has_value() || value > best_value) {
      best = selected;
      best_value = std::move(value);
    }
  }
  if (!best.has_value()) {
    return mwperf::Result<mwperf::detail::ExactBackendCandidate>::failure(
        mwperf::Diagnostic{.category = mwperf::DiagnosticCategory::unavailable,
                           .code = "infeasible_side",
                           .message = "the forced target side is infeasible",
                           .authored_path = std::nullopt,
                           .json_pointer = std::nullopt,
                           .notes = {}});
  }
  auto schedule = mwperf::Schedule::from_bytes(weights.dimension(),
                                                std::move(*best));
  REQUIRE(schedule);
  return mwperf::Result<mwperf::detail::ExactBackendCandidate>::success(
      authority.make_candidate(
          std::move(schedule).value(), std::move(best_value),
          weights.dimension().family(),
          [&]() {
            if constexpr (std::same_as<Constraint,
                                       mwperf::ResolvedCrossbarConstraint>) {
              return mwperf::OptimizerId::hungarian_exact;
            } else if constexpr (std::same_as<
                                     Constraint,
                                     mwperf::ResolvedIntervalConstraint>) {
              return mwperf::OptimizerId::weighted_interval_dp_exact;
            } else if constexpr (std::same_as<
                                     Constraint,
                                     mwperf::ResolvedNodeExclusiveConstraint>) {
              return mwperf::OptimizerId::edmonds_blossom_exact;
            } else if constexpr (std::same_as<
                                     Constraint,
                                     mwperf::ResolvedConflictConstraint>) {
              return mwperf::OptimizerId::mwis_branch_memo_exact;
            } else {
              return mwperf::OptimizerId::binary_packing_memo_exact;
            }
          }(),
          budget.accounting(), {"test-only exhaustive exact witness"}));
}

[[nodiscard]] mwperf::detail::ExactOptimizerBackendServices toy_backends() {
  mwperf::detail::ExactOptimizerBackendServices services;
  services.crossbar = exhaustive_backend<mwperf::ResolvedCrossbarConstraint>;
  services.intervals = exhaustive_backend<mwperf::ResolvedIntervalConstraint>;
  services.node_exclusive =
      exhaustive_backend<mwperf::ResolvedNodeExclusiveConstraint>;
  services.conflicts = exhaustive_backend<mwperf::ResolvedConflictConstraint>;
  services.packing = exhaustive_backend<mwperf::ResolvedPackingConstraint>;
  return services;
}

[[nodiscard]] mwperf::Backlog backlog(const mwperf::ResolvedInstance& instance,
                                      const std::uint64_t first,
                                      const std::uint64_t second) {
  auto result = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(instance),
      {mwperf::BigNat(first), mwperf::BigNat(second)});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerExecutionContext execution_context(
    const mwperf::ResolvedInstance& instance,
    std::optional<std::uint64_t> assigned = std::nullopt) {
  auto result = mwperf::OptimizerExecutionContext::from_resolved_instance(
      instance,
      assigned.has_value()
          ? std::optional<mwperf::BigNat>(mwperf::BigNat(*assigned))
          : std::nullopt);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TargetIndex target(
    const mwperf::ResolvedInstance& instance, const std::size_t ordinal) {
  auto result = mwperf::TargetIndex::from_instance(instance, ordinal);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy recursive_policy(
    const std::uint64_t per_call_limit) {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = mwperf::BigNat(per_call_limit),
      .effective_per_call = mwperf::BigNat(per_call_limit),
      .max_calls = mwperf::BigNat(1U),
  };
}

}  // namespace

TEST_CASE("C05 missing injected current-family backends are internal errors",
          "[c05][integration][negative][dispatch]") {
  const auto scheduler_values = schedulers();
  for (std::size_t index = 3U; index < scheduler_values.size(); ++index) {
    const auto instance = resolved(scheduler_values[index]);
    auto services = toy_backends();
    if (index == 3U) {
      services.conflicts = {};
    } else {
      services.packing = {};
    }
    auto context = execution_context(instance);
    auto decision =
        mwperf::detail::resolve_maxweight_schedule_with_backend_services(
            instance, backlog(instance, 2U, 1U),
            mwperf::TieContext::configured_priority(), context, services);
    INFO(index);
    REQUIRE_FALSE(decision);
    CHECK(decision.error().category == mwperf::DiagnosticCategory::internal);
    CHECK(decision.error().code ==
          "optimizer_registered_backend_route_missing");
    CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
          "1");
  }
}

TEST_CASE("C05 resolves empty eligibility as the unique common base case",
          "[c05][integration][dispatch]") {
  const auto instance = resolved(schedulers().at(3U));
  auto context = execution_context(instance);
  auto decision = mwperf::resolve_maxweight_schedule(
      instance, backlog(instance, 0U, 0U),
      mwperf::TieContext::configured_priority(), context);
  REQUIRE(decision);
  CHECK(std::ranges::equal(decision.value().schedule.bytes(),
                           std::vector<std::uint8_t>{0U, 0U}));
  CHECK(decision.value().primary_objective.is_zero());
  CHECK(decision.value().composite_objective.is_zero());
  CHECK(decision.value().priority_code.is_zero());
  CHECK(decision.value().accounting.call_ordinal().to_decimal_string() == "1");
}

TEST_CASE("C05 test-only exact backend traverses the complete resolver",
          "[c05][integration][dispatch]") {
  const auto instance = resolved(schedulers().at(3U));
  const auto services = toy_backends();
  auto context = execution_context(instance);
  auto decision =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          instance, backlog(instance, 7U, 7U),
          mwperf::TieContext::configured_priority(), context, services);
  REQUIRE(decision);
  CHECK(std::ranges::equal(decision.value().schedule.bytes(),
                           std::vector<std::uint8_t>{1U, 0U}));
  CHECK(decision.value().primary_objective.to_decimal_string() == "7");
  CHECK(decision.value().priority_code.to_decimal_string() == "2");
  CHECK(decision.value().composite_objective.to_decimal_string() == "30");
  CHECK(decision.value().family ==
        mwperf::ServiceFamily::pairwise_conflicts);
  CHECK(decision.value().backend_id ==
        mwperf::OptimizerId::mwis_branch_memo_exact);
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "1");
}

TEST_CASE("C05 identical cold calls return identical decisions and accounting",
          "[c05][integration][dispatch]") {
  const auto instance = resolved(schedulers().at(3U));
  const auto services = toy_backends();
  auto first_context = execution_context(instance);
  auto second_context = execution_context(instance);
  const auto queue = backlog(instance, 9U, 4U);
  auto first = mwperf::detail::resolve_maxweight_schedule_with_backend_services(
      instance, queue, mwperf::TieContext::configured_priority(),
      first_context, services);
  auto second = mwperf::detail::resolve_maxweight_schedule_with_backend_services(
      instance, queue, mwperf::TieContext::configured_priority(),
      second_context, services);
  REQUIRE(first);
  REQUIRE(second);
  CHECK(first.value() == second.value());
}

TEST_CASE("C05 configured priority reverses an exact primary tie",
          "[c05][integration][dispatch]") {
  const std::string reversed =
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":["q1","q0"],"max_search_states":9}})";
  const auto instance = resolved(reversed);
  const auto services = toy_backends();
  auto context = execution_context(instance);
  auto decision =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          instance, backlog(instance, 7U, 7U),
          mwperf::TieContext::configured_priority(), context, services);
  REQUIRE(decision);
  CHECK(std::ranges::equal(decision.value().schedule.bytes(),
                           std::vector<std::uint8_t>{0U, 1U}));
  CHECK(decision.value().primary_objective.to_decimal_string() == "7");
  CHECK(decision.value().priority_code.to_decimal_string() == "2");
}

TEST_CASE("C05 queue-storage permutation preserves the typed decision",
          "[c05][property][dispatch]") {
  const std::string scheduler =
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":["q0","q1"],"max_search_states":9}})";
  const auto forward = resolved(scheduler, R"(["q0","q1"])");
  const auto permuted = resolved(scheduler, R"(["q1","q0"])");
  const auto services = toy_backends();
  auto forward_context = execution_context(forward);
  auto permuted_context = execution_context(permuted);
  auto forward_decision =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          forward, backlog(forward, 9U, 4U),
          mwperf::TieContext::configured_priority(), forward_context,
          services);
  auto permuted_decision =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          permuted, backlog(permuted, 4U, 9U),
          mwperf::TieContext::configured_priority(), permuted_context,
          services);
  REQUIRE(forward_decision);
  REQUIRE(permuted_decision);
  CHECK(std::ranges::equal(forward_decision.value().schedule.bytes(),
                           std::vector<std::uint8_t>{1U, 0U}));
  CHECK(std::ranges::equal(permuted_decision.value().schedule.bytes(),
                           std::vector<std::uint8_t>{0U, 1U}));
  const auto forward_selected = forward.queues().index_at(0U);
  const auto permuted_selected = permuted.queues().index_at(1U);
  REQUIRE(forward_selected);
  REQUIRE(permuted_selected);
  CHECK(forward.queues().queue_id(forward_selected.value()) ==
        permuted.queues().queue_id(permuted_selected.value()));
  CHECK(forward_decision.value().primary_objective ==
        permuted_decision.value().primary_objective);
}

TEST_CASE("C05 foreign backlog and context identities fail before charging",
          "[c05][integration][negative]") {
  const auto first = resolved(schedulers().at(3U));
  const auto foreign = resolved(schedulers().at(3U));
  const auto services = toy_backends();

  auto first_context = execution_context(first);
  auto foreign_backlog =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          first, backlog(foreign, 3U, 2U),
          mwperf::TieContext::configured_priority(), first_context,
          services);
  REQUIRE_FALSE(foreign_backlog);
  CHECK(foreign_backlog.error().code ==
        "maxweight_backlog_instance_mismatch");
  CHECK(first_context.ledger_snapshot().calls_reserved().is_zero());

  auto foreign_context = execution_context(foreign);
  auto wrong_context =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          first, backlog(first, 3U, 2U),
          mwperf::TieContext::configured_priority(), foreign_context,
          services);
  REQUIRE_FALSE(wrong_context);
  CHECK(wrong_context.error().code ==
        "maxweight_optimizer_context_mismatch");
  CHECK(foreign_context.ledger_snapshot().calls_reserved().is_zero());

  auto mismatched_policy = first.optimizer_budget();
  mismatched_policy.max_calls = mwperf::BigNat(19U);
  auto policy_context = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(mismatched_policy), std::nullopt,
      mwperf::QueueDimensionToken::from_instance(first));
  REQUIRE_FALSE(policy_context);
  CHECK(policy_context.error().code ==
        "optimizer_context_binding_policy_mismatch");
}

TEST_CASE("C05 rejects stochastic or stateful tie policies before charging",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  for (const auto policy : {mwperf::TiePolicy::random, mwperf::TiePolicy::sticky,
                            mwperf::TiePolicy::round_robin,
                            mwperf::TiePolicy::arrival_observing}) {
    auto context = execution_context(instance);
    auto decision = mwperf::resolve_maxweight_schedule(
        instance, backlog(instance, 1U, 1U), mwperf::TieContext(policy),
        context);
    REQUIRE_FALSE(decision);
    CHECK(decision.error().code == "unsupported_tie_policy");
    CHECK(context.ledger_snapshot().calls_reserved().is_zero());
  }
}

TEST_CASE("C05 full resolver rejects an unproven corrupt backend candidate",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  auto services = toy_backends();
  services.conflicts =
      [](const mwperf::ResolvedConflictConstraint&,
         const mwperf::CompiledConstraintProduct&,
         const mwperf::EligibilityMask&,
         const mwperf::LexWeights& weights, mwperf::SearchBudget& budget,
         const std::optional<mwperf::detail::ForcedTargetCondition>&,
         const mwperf::detail::ExactBackendAuthority& authority) {
        auto schedule = mwperf::Schedule::from_bytes(weights.dimension(),
                                                     {1U, 0U});
        REQUIRE(schedule);
        return mwperf::Result<mwperf::detail::ExactBackendCandidate>::success(
            authority.make_candidate(
                std::move(schedule).value(), mwperf::BigNat(0U),
                mwperf::ServiceFamily::pairwise_conflicts,
                mwperf::OptimizerId::mwis_branch_memo_exact,
                budget.accounting()));
      };
  auto context = execution_context(instance);
  auto result =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          instance, backlog(instance, 7U, 7U),
          mwperf::TieContext::configured_priority(), context, services);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "optimizer_solution_objective_mismatch");
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "1");
}

TEST_CASE("C05 every family forces both sides and excludes target weight",
          "[c05][integration][dispatch]") {
  const auto services = toy_backends();
  const auto scheduler_values = schedulers_with_compatible_third_queue();
  for (std::size_t family = 0U; family < scheduler_values.size(); ++family) {
    const auto instance =
        resolved(scheduler_values[family], R"(["q0","q1","q2"])");
    const auto dimension =
        mwperf::QueueDimensionToken::from_instance(instance);
    auto primary = mwperf::PrimaryWeights::from_values(
        dimension, {mwperf::BigNat(1000U), mwperf::BigNat(7U),
                    mwperf::BigNat(5U)});
    REQUIRE(primary);
    // The target begins ineligible. Forced one must override only that bit;
    // q1 remains eligible but is structurally excluded, while compatible q2
    // must remain eligible and selected on both conditioned faces.
    auto eligible =
        mwperf::EligibilityMask::from_bytes(dimension, {0U, 1U, 1U});
    REQUIRE(eligible);
    const auto selected_target = target(instance, 0U);
    auto context = execution_context(instance);

    auto forced_zero =
        mwperf::detail::solve_forced_target_with_backend_services(
            context, instance.constraint(), eligible.value(), primary.value(),
            selected_target, mwperf::ForcedTargetBit::zero,
            instance.priority(), services);
    INFO(family);
    REQUIRE(forced_zero);
    CHECK(forced_zero.value().value.to_decimal_string() == "12");
    CHECK(std::ranges::equal(forced_zero.value().witness.bytes(),
                             std::vector<std::uint8_t>{0U, 1U, 1U}));
    CHECK(forced_zero.value().target == selected_target);
    CHECK(forced_zero.value().side == mwperf::ForcedTargetBit::zero);
    CHECK(forced_zero.value().accounting.query_kind() ==
          mwperf::OptimizerQueryKind::forced_zero);
    REQUIRE(forced_zero.value().accounting.target().has_value());
    CHECK(*forced_zero.value().accounting.target() == selected_target);
    CHECK(forced_zero.value().accounting.call_ordinal().to_decimal_string() ==
          "1");

    auto forced_one =
        mwperf::detail::solve_forced_target_with_backend_services(
            context, instance.constraint(), eligible.value(), primary.value(),
            selected_target, mwperf::ForcedTargetBit::one,
            instance.priority(), services);
    REQUIRE(forced_one);
    CHECK(forced_one.value().value.to_decimal_string() == "5");
    CHECK(std::ranges::equal(forced_one.value().witness.bytes(),
                             std::vector<std::uint8_t>{1U, 0U, 1U}));
    CHECK(forced_one.value().target == selected_target);
    CHECK(forced_one.value().side == mwperf::ForcedTargetBit::one);
    CHECK(forced_one.value().accounting.query_kind() ==
          mwperf::OptimizerQueryKind::forced_one);
    REQUIRE(forced_one.value().accounting.target().has_value());
    CHECK(*forced_one.value().accounting.target() == selected_target);
    CHECK(forced_one.value().accounting.call_ordinal().to_decimal_string() ==
          "2");
    CHECK(forced_one.value().secondary_code.to_decimal_string() == "5");
    CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
          "2");
  }
}

TEST_CASE("C05 configured priority selects equal-Psi forced witnesses",
          "[c05][integration][dispatch]") {
  const std::string forward_scheduler =
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q1","q2"]]},"priority":["q1","q2","q0"],"max_search_states":9}})";
  const std::string reverse_scheduler =
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q1","q2"]]},"priority":["q2","q1","q0"],"max_search_states":9}})";
  const auto forward = resolved(forward_scheduler, R"(["q0","q1","q2"])");
  const auto reverse = resolved(reverse_scheduler, R"(["q0","q1","q2"])");
  const auto services = toy_backends();

  const auto solve_both_faces =
      [&services](const mwperf::ResolvedInstance& instance) {
        const auto dimension =
            mwperf::QueueDimensionToken::from_instance(instance);
        auto primary = mwperf::PrimaryWeights::from_values(
            dimension, {mwperf::BigNat(999U), mwperf::BigNat(7U),
                        mwperf::BigNat(7U)});
        REQUIRE(primary);
        auto eligible =
            mwperf::EligibilityMask::from_bytes(dimension, {0U, 1U, 1U});
        REQUIRE(eligible);
        auto context = execution_context(instance);
        auto forced_zero =
            mwperf::detail::solve_forced_target_with_backend_services(
                context, instance.constraint(), eligible.value(),
                primary.value(), target(instance, 0U),
                mwperf::ForcedTargetBit::zero, instance.priority(), services);
        REQUIRE(forced_zero);
        auto forced_one =
            mwperf::detail::solve_forced_target_with_backend_services(
                context, instance.constraint(), eligible.value(),
                primary.value(), target(instance, 0U),
                mwperf::ForcedTargetBit::one, instance.priority(), services);
        REQUIRE(forced_one);
        CHECK(forced_zero.value().value.to_decimal_string() == "7");
        CHECK(forced_one.value().value.to_decimal_string() == "7");
        return std::pair{std::move(forced_zero).value(),
                         std::move(forced_one).value()};
      };

  const auto forward_faces = solve_both_faces(forward);
  const auto reverse_faces = solve_both_faces(reverse);
  CHECK(std::ranges::equal(forward_faces.first.witness.bytes(),
                           std::vector<std::uint8_t>{0U, 1U, 0U}));
  CHECK(std::ranges::equal(forward_faces.second.witness.bytes(),
                           std::vector<std::uint8_t>{1U, 1U, 0U}));
  CHECK(std::ranges::equal(reverse_faces.first.witness.bytes(),
                           std::vector<std::uint8_t>{0U, 0U, 1U}));
  CHECK(std::ranges::equal(reverse_faces.second.witness.bytes(),
                           std::vector<std::uint8_t>{1U, 0U, 1U}));
}

TEST_CASE("C05 forced call exhaustion occurs before backend work",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  const auto dimension = mwperf::QueueDimensionToken::from_instance(instance);
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension, {mwperf::BigNat(4U), mwperf::BigNat(3U)});
  REQUIRE(primary);
  const auto eligible = mwperf::EligibilityMask::all(dimension);
  bool backend_invoked = false;
  auto services = toy_backends();
  services.conflicts =
      [&backend_invoked](
          const mwperf::ResolvedConflictConstraint& constraint,
          const mwperf::CompiledConstraintProduct& product,
          const mwperf::EligibilityMask& query_eligibility,
          const mwperf::LexWeights& query_weights,
          mwperf::SearchBudget& budget,
          const std::optional<mwperf::detail::ForcedTargetCondition>&
              condition,
          const mwperf::detail::ExactBackendAuthority& authority) {
        backend_invoked = true;
        return exhaustive_backend(constraint, product, query_eligibility,
                                  query_weights, budget, condition, authority);
      };
  auto context = execution_context(instance, 0U);
  auto exhausted =
      mwperf::detail::solve_forced_target_with_backend_services(
          context, instance.constraint(), eligible, primary.value(),
          target(instance, 0U), mwperf::ForcedTargetBit::one,
          instance.priority(), services);
  REQUIRE_FALSE(exhausted);
  CHECK(exhausted.error().code == "optimizer_call_limit_exhausted");
  CHECK_FALSE(backend_invoked);
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());
}

TEST_CASE("C05 forced target identity and bit errors cannot consume a call",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  const auto foreign = resolved(schedulers().at(3U));
  const auto services = toy_backends();
  const auto dimension = mwperf::QueueDimensionToken::from_instance(instance);
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension, {mwperf::BigNat(1U), mwperf::BigNat(1U)});
  REQUIRE(primary);
  const auto eligible = mwperf::EligibilityMask::all(dimension);

  auto out_of_range = mwperf::TargetIndex::from_instance(instance, 2U);
  REQUIRE_FALSE(out_of_range);
  CHECK(out_of_range.error().code == "target_index_out_of_range");

  auto context = execution_context(instance);
  auto foreign_result =
      mwperf::detail::solve_forced_target_with_backend_services(
          context, instance.constraint(), eligible, primary.value(),
          target(foreign, 0U), mwperf::ForcedTargetBit::one,
          instance.priority(), services);
  REQUIRE_FALSE(foreign_result);
  CHECK(foreign_result.error().code == "forced_target_identity_mismatch");
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());

  auto invalid_bit =
      mwperf::detail::solve_forced_target_with_backend_services(
          context, instance.constraint(), eligible, primary.value(),
          target(instance, 0U), static_cast<mwperf::ForcedTargetBit>(2U),
          instance.priority(), services);
  REQUIRE_FALSE(invalid_bit);
  CHECK(invalid_bit.error().code == "forced_target_bit_invalid");
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());
}

TEST_CASE("C05 an impossible forced-one packing face is typed infeasible",
          "[c05][integration][negative]") {
  const std::string over_capacity =
      R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[0],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[0]}]},"priority":null,"max_search_states":9}})";
  const auto pair = parse_pair(model(over_capacity));
  auto catalog = mwperf::build_queue_catalog(pair.model.switch_config);
  REQUIRE(catalog);
  auto priority = mwperf::resolve_priority(pair.model.scheduler,
                                           catalog.value());
  REQUIRE(priority);
  const auto compiler_services = compilers();
  auto descriptor =
      mwperf::detail::compile_constraint_descriptor_with_child_services(
          pair.model.scheduler, catalog.value(), compiler_services);
  REQUIRE(descriptor);
  const mwperf::OptimizerBudgetPolicy policy{
      .physical_per_call = mwperf::BigNat(9U),
      .analysis_per_call = mwperf::BigNat(5U),
      .effective_per_call = mwperf::BigNat(5U),
      .max_calls = mwperf::BigNat(20U),
  };
  const auto dimension = mwperf::QueueDimensionToken::for_fixture(
      pair.fingerprints.combined, catalog.value().size(), descriptor.value(),
      priority.value(), policy);
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension, {mwperf::BigNat(3U), mwperf::BigNat(7U)});
  REQUIRE(primary);
  const auto eligible = mwperf::EligibilityMask::all(dimension);
  auto selected_target = mwperf::TargetIndex::from_dimension(dimension, 0U);
  REQUIRE(selected_target);
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      policy, std::nullopt, dimension);
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  const auto services = toy_backends();
  auto forced_one =
      mwperf::detail::solve_forced_target_with_backend_services(
          context, descriptor.value(), eligible, primary.value(),
          selected_target.value(), mwperf::ForcedTargetBit::one,
          priority.value(), services);
  REQUIRE_FALSE(forced_one);
  CHECK(forced_one.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(forced_one.error().code == "infeasible_side");
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "1");
}

TEST_CASE("C05 recursive root and deep exhaustion return no incumbent",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  for (const std::uint64_t limit : {0U, 2U}) {
    const auto policy = recursive_policy(limit);
    const auto dimension = mwperf::QueueDimensionToken::for_fixture(
        instance.fingerprints().combined, instance.queues().size(),
        instance.constraint(), instance.priority(), policy);
    auto primary = mwperf::PrimaryWeights::from_values(
        dimension, {mwperf::BigNat(5U), mwperf::BigNat(4U)});
    REQUIRE(primary);
    const auto eligible = mwperf::EligibilityMask::all(dimension);
    auto weights = mwperf::compose_lexicographic_weights(
        primary.value(), instance.priority(), eligible);
    REQUIRE(weights);
    auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
        policy, std::nullopt, dimension);
    REQUIRE(context_result);
    auto context = std::move(context_result).value();
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(budget.value().set_query_kind(
        mwperf::OptimizerQueryKind::ordinary));

    auto services = toy_backends();
    services.conflicts =
        [limit](const mwperf::ResolvedConflictConstraint&,
                const mwperf::CompiledConstraintProduct&,
                const mwperf::EligibilityMask&,
                const mwperf::LexWeights& query_weights,
                mwperf::SearchBudget& solve_budget,
                const std::optional<
                    mwperf::detail::ForcedTargetCondition>&,
                const mwperf::detail::ExactBackendAuthority& authority) {
          for (std::uint64_t attempt = 0U; attempt <= limit; ++attempt) {
            auto charged =
                mwperf::detail::SearchBudgetAccess::charge_expansion(
                    solve_budget);
            if (!charged) {
              return mwperf::Result<
                  mwperf::detail::ExactBackendCandidate>::failure(
                  std::move(charged.error()));
            }
          }
          return mwperf::Result<
              mwperf::detail::ExactBackendCandidate>::success(
              authority.make_candidate(
                  mwperf::Schedule::none(query_weights.dimension()),
                  mwperf::BigNat(0U),
                  mwperf::ServiceFamily::pairwise_conflicts,
                  mwperf::OptimizerId::mwis_branch_memo_exact,
                  solve_budget.accounting()));
        };
    auto exhausted = mwperf::detail::solve_exact_with_backend_services(
        instance.constraint(), eligible, weights.value(), budget.value(),
        std::nullopt, services);
    INFO(limit);
    REQUIRE_FALSE(exhausted);
    CHECK(exhausted.error().code == "search_state_limit_exhausted");
    REQUIRE(exhausted.error().notes.size() >= 4U);
    CHECK(exhausted.error().notes[0] ==
          "effective per-call expansion limit: " + std::to_string(limit));
    CHECK(exhausted.error().notes[1] ==
          "completed recursive expansions: " + std::to_string(limit));
    CHECK(exhausted.error().notes[2] ==
          "service family: pairwise_conflicts");
    CHECK(exhausted.error().notes[3] == "query kind: ordinary");
    CHECK(budget.value().completed_expansions().to_decimal_string() ==
          std::to_string(limit));
    CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
          "1");
  }
}

TEST_CASE("C05 call exhaustion prevents backend work",
          "[c05][integration][negative]") {
  const auto instance = resolved(schedulers().at(3U));
  const auto services = toy_backends();
  auto context = execution_context(instance, 1U);
  REQUIRE(mwperf::detail::resolve_maxweight_schedule_with_backend_services(
      instance, backlog(instance, 1U, 0U),
      mwperf::TieContext::configured_priority(), context, services));
  auto exhausted =
      mwperf::detail::resolve_maxweight_schedule_with_backend_services(
          instance, backlog(instance, 1U, 0U),
          mwperf::TieContext::configured_priority(), context, services);
  REQUIRE_FALSE(exhausted);
  CHECK(exhausted.error().code == "optimizer_call_limit_exhausted");
  CHECK(context.ledger_snapshot().calls_reserved().to_decimal_string() ==
        "1");
}
