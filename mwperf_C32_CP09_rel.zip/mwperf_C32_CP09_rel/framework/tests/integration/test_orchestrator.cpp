#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <memory>
#include <optional>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/app/execution_plan.hpp"
#include "mwperf/app/resolved_request.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/reduction/exact_reductions.hpp"
#include "c22/support/transient_dispatch_fixture.hpp"
#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "support/c30_observation_fixture.hpp"
#include "support/c16_test_providers.hpp"
#include "cli_runtime.hpp"

namespace mwperf::testing {

class C27ExecutionPlanFixtureFactory final {
 public:
  static void remove_metric_plans(ExecutionPlan& plan) {
    plan.metric_plans_.clear();
  }

  static void replace_backend_with_foreign_route(ExecutionPlan& plan) {
    auto proof = std::get<FrameworkScalarIdentityBackendPlanV1>(
                     plan.metric_plans_.front().backend_)
                     .stationary_proof;
    plan.metric_plans_.front().backend_ =
        FrameworkScalarIdentityBackendPlanV1{
            FrameworkScalarKindV1::stationary_backlog_mean,
            std::move(proof)};
  }

  static void replace_homogeneous_selection_regime(ExecutionPlan& plan) {
    plan.selection_regime_ = MetricSelectionRegimeV1::fixed_point_unique;
  }

  static void remove_framework_stationarity_requirement(
      ExecutionPlan& plan) {
    auto& backend = std::get<FrameworkScalarIdentityBackendPlanV1>(
        plan.metric_plans_.front().backend_);
    backend.stationary_proof.requires_proper_normalized_invariant = false;
  }

  static void remove_framework_exact_iid_requirement(ExecutionPlan& plan) {
    auto& backend = std::get<FrameworkScalarIdentityBackendPlanV1>(
        plan.metric_plans_.front().backend_);
    backend.stationary_proof.requires_exact_iid_law = false;
  }

  static void replace_dependency_arrival_identity(ExecutionPlan& plan) {
    ++plan.dependency_schedule_.front()
          .identity.configured_arrival.queue_cardinality;
  }
};

class C27AnalysisBundleFixtureFactory final {
 public:
  static void replace_diagnostic_supplement(
      AnalysisBundle& bundle,
      std::shared_ptr<const AnalysisDiagnosticSupplementV2> supplement) {
    bundle.diagnostic_supplement_ = std::move(supplement);
  }

  static bool increment_execution_budget(AnalysisBundle& bundle,
                                         const std::string_view name) {
    const auto row = std::ranges::find_if(
        bundle.execution_budget_usage_, [&](const auto& candidate) {
          return candidate.name == name;
        });
    if (row == bundle.execution_budget_usage_.end()) return false;
    ++row->used;
    return true;
  }

  static bool remove_backend_budget(AnalysisBundle& bundle,
                                    const std::string_view name) {
    const auto row = std::ranges::find_if(
        bundle.backend_budget_usage_, [&](const auto& candidate) {
          return candidate.name == name;
        });
    if (row == bundle.backend_budget_usage_.end()) return false;
    bundle.backend_budget_usage_.erase(row);
    return true;
  }

  static void append_backend_budget(AnalysisBundle& bundle,
                                    const std::string_view name,
                                    const BigNat& granted,
                                    const std::string_view unit) {
    bundle.backend_budget_usage_.push_back(ResultBudgetUsageV1{
        std::string(name), ResultBudgetApplicabilityV1::applicable,
        granted, BigNat{0U}, std::string(unit)});
  }

  static void replace_with_failure(
      AnalysisBundle& bundle, const ResultFailureStageV1 stage,
      const std::string_view code) {
    const std::string diagnostic_id =
        "c27.fixture.shared_optimizer_failure";
    bundle.status_ = ResultStatusV1::failed;
    bundle.failure_ =
        ResultFailureV1{stage, std::string(code), {diagnostic_id}};
    bundle.metrics_.clear();
    bundle.response_curve_.reset();
    bundle.unavailable_diagnostics_.reset();
    if (stage == ResultFailureStageV1::v0_audit) {
      bundle.execution_identity_.execution_seal_digest.reset();
      bundle.certificates_.clear();
      bundle.diagnostics_.clear();
      bundle.backend_budget_usage_.clear();
      std::erase_if(bundle.replay_streams_, [](const auto& stream) {
        return std::holds_alternative<ResultRuntimeReplayStreamV1>(stream);
      });
    }
    bundle.diagnostics_.push_back(ResultDiagnosticV1{
        diagnostic_id,
        DiagnosticCategory::internal,
        std::string(code),
        "fixture shared optimizer accounting failure",
        std::nullopt,
        ResultDiagnosticKindV1::budget_termination,
        std::nullopt,
        std::nullopt,
        {},
        {}});
  }

  static bool replace_with_accounting_failure_without_budgets(
      AnalysisBundle& bundle, const std::span<const std::string_view> names,
      const std::string_view code) {
    for (const std::string_view name : names) {
      const auto row = std::ranges::find_if(
          bundle.execution_budget_usage_, [&](const auto& candidate) {
            return candidate.name == name;
          });
      if (row == bundle.execution_budget_usage_.end()) return false;
      bundle.execution_budget_usage_.erase(row);
    }
    replace_with_failure(bundle, ResultFailureStageV1::backend, code);
    return true;
  }
};

}  // namespace mwperf::testing

namespace {

[[nodiscard]] std::filesystem::path c27_directory() {
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c27-orchestrator";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  return directory;
}

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view stem, const std::string_view contents) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path path =
      c27_directory() /
      (std::string(stem) + "-" + std::to_string(next.fetch_add(1U)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string read_bytes(const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  REQUIRE(input.is_open());
  return std::string(std::istreambuf_iterator<char>(input),
                     std::istreambuf_iterator<char>());
}

[[nodiscard]] const mwperf::ResultBudgetUsageV1* execution_budget(
    const mwperf::AnalysisBundle& bundle, const std::string_view name) {
  const auto rows = bundle.execution_budget_usage();
  const auto found = std::ranges::find_if(
      rows, [&](const auto& row) {
        return row.name == name;
      });
  return found == rows.end() ? nullptr : &*found;
}

[[nodiscard]] std::string model_with_seed(const std::string_view seed_fields) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{
      )json") +
         std::string(seed_fields) + R"json(,
      "slots":8,
      "warmup_slots":0,
      "termination":"fixed_slots"
    },
    "switch":{
      "kind":"generalized",
      "queue_capacity":null,
      "queues":[{"id":"q0"}]
    },
    "scheduler":{
      "name":"conflict_graph_max_weight",
      "params":{
        "constraint":{"conflicts":[]},
        "priority":["q0"],
        "max_search_states":null
      }
    },
    "arrival":{
      "family":"deterministic_trace",
      "events":[{"slot":0,"queue_id":"q0","count":1}],
      "metadata":{}
    },
    "telemetry":{
      "format":"jsonl",
      "queue_snapshot":"sparse_nonzero",
      "include_packet_events":false,
      "include_scheduler_state":false,
      "write_slot_trace":false
    },
    "metadata":{"fixture":"c27"}
  })json";
}

[[nodiscard]] std::string c27_factorized_iid_model(
    const std::size_t source_count) {
  REQUIRE(source_count > 0U);
  std::string sources;
  for (std::size_t source = 0U; source < source_count; ++source) {
    if (!sources.empty()) {
      sources += ',';
    }
    sources +=
        R"json({"id":"s)json" +
        std::to_string(source) +
        R"json(","interarrival":{"kind":"geometric_grid","d_min":1,
          "delta":1,"p":0.001953125},"destination_pmf":[
          {"queue_id":"q0","probability":0.5},
          {"queue_id":"q1","probability":0.5}]})json";
  }
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":43,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":{"family":"independent_marked_renewal","sources":[)json") +
         sources + R"json(],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"sparse_nonzero",
      "include_packet_events":false,"include_scheduler_state":false,
      "write_slot_trace":false},
    "metadata":{"fixture":"c27-factorized-iid"}
  })json";
}

[[nodiscard]] std::string c27_shared_arrival_model() {
  return R"json({
    "schema_version":"3.0.0",
    "run":{"seed":43,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s"}],"states":["h0","h1"],
      "initial":{"state":"h0"},"outcomes":[
        {"state":"h0","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
        {"state":"h0","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]},
        {"state":"h1","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
        {"state":"h1","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"sparse_nonzero",
      "include_packet_events":false,"include_scheduler_state":false,
      "write_slot_trace":false},
    "metadata":{"fixture":"c27-framework-identity"}
  })json";
}

[[nodiscard]] std::string c27_target_last_arrival_model() {
  std::string model = c27_shared_arrival_model();
  const auto replace_once = [&](const std::string_view before,
                                const std::string_view after) {
    const std::size_t offset = model.find(before);
    REQUIRE(offset != std::string::npos);
    model.replace(offset, before.size(), after);
  };
  replace_once(
      R"json("queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}])json",
      R"json("queues":[{"id":"q1"},{"id":"q2"},{"id":"q0"}])json");
  replace_once(R"json("priority":["q0","q1","q2"])json",
               R"json("priority":["q1","q2","q0"])json");
  // Keep the authored shared-round support aligned with the physical queue
  // ordinals after placing the requested target last.  A temporary token
  // avoids collapsing the q0->q1 and q1->q2 substitutions.
  for (std::size_t occurrence = 0U; occurrence < 2U; ++occurrence) {
    replace_once(
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"q0"}])json",
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"__c27_q1"}])json");
  }
  for (std::size_t occurrence = 0U; occurrence < 2U; ++occurrence) {
    replace_once(
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"q1"}])json",
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"q2"}])json");
  }
  for (std::size_t occurrence = 0U; occurrence < 2U; ++occurrence) {
    replace_once(
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"__c27_q1"}])json",
        R"json("emissions":[{"source_id":"s","d":1,"queue_id":"q1"}])json");
  }
  return model;
}

[[nodiscard]] std::string analysis_with_provider(
    const std::string_view provider,
    const std::string_view parameters = "{}",
    const std::string_view solver =
        R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})json") {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{
      "id":"throughput",
      "kind":"stationary_throughput",
      "parameters":{}
    }],
    "surrogate":{"id":")json") +
         std::string(provider) + R"json(","version":null,"parameters":)json" +
         std::string(parameters) + R"json(},
    "resolution":{
      "level":{"max_states":128,"max_row_atoms":128},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":16},
      "optimizer":{"max_calls":128,"max_search_states_per_call":128},
      "sampling":{"max_generator_draws":null},
      "tolerance":{
        "linear_residual_abs":null,
        "integration_abs":null,
        "tail_abs":null,
        "fixed_point_abs":null
      }
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":)json" + std::string(solver) + R"json(
  })json";
}

struct RequestFiles final {
  std::filesystem::path model;
  std::filesystem::path analysis;
  std::filesystem::path output;
};

[[nodiscard]] RequestFiles request_files(const std::string_view seed_fields,
                                         const std::string_view provider,
                                         const std::string_view parameters =
                                             "{}",
                                         const std::string_view solver =
                                             R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}})json") {
  return {
      .model = write_fixture("model", model_with_seed(seed_fields)),
      .analysis = write_fixture(
          "analysis", analysis_with_provider(provider, parameters, solver)),
      .output = c27_directory() / "result-v1.json",
  };
}

[[nodiscard]] mwperf::CliRequest cli_request(const RequestFiles& files) {
  return mwperf::CliRequest{mwperf::Analyze{
      .model_path = {files.model.string(), files.model},
      .analysis_path = {files.analysis.string(), files.analysis},
      .output_path = {files.output.string(), files.output},
  }};
}

[[nodiscard]] mwperf::ResolvedRequest resolved_iid_request(
    const std::string_view provider, const std::string_view parameters,
    const std::int64_t first_outcome_numerator,
    const std::int64_t first_outcome_denominator,
    const mwperf::testing::FixtureConstructionProfile profile =
        mwperf::testing::FixtureConstructionProfile::
            portable_iid_bernoulli_joint_table) {
  const RequestFiles files{
      write_fixture("iid-model", c27_shared_arrival_model()),
      write_fixture(
          "iid-analysis",
          analysis_with_provider(
              provider, parameters,
              R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json")),
      c27_directory() / "iid-result-v1.json"};
  REQUIRE(read_bytes(files.analysis).find(std::string(parameters)) !=
          std::string::npos);
  auto authored = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(321U);
      });
  REQUIRE(authored);
  auto first_mass = mwperf::ExactRational::make(
      mwperf::BigInt{first_outcome_numerator},
      mwperf::BigInt{first_outcome_denominator});
  REQUIRE(first_mass);
  auto fixture_law = mwperf::testing::make_c09_weighted_correlated_fixture_law(
      authored.value().instance().queues(), first_mass.value(), profile);
  REQUIRE(fixture_law);
  auto rebound = mwperf::testing::rebind_resolved_request_arrival_for_testing(
      authored.value(),
      std::make_shared<const mwperf::CompiledArrivalLaw>(
          std::move(fixture_law).value()));
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  return std::move(rebound).value();
}

[[nodiscard]] std::shared_ptr<const mwperf::AnalysisDiagnosticSupplementV2>
c30_diagnostic_supplement(
    const mwperf::AnalysisDiagnosticTerminalV2 terminal,
    const bool local_analysis_failure = false) {
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      mwperf::testing::c30::validated_bundle(
          mwperf::ObservationSourceRoleV1::short_restart_reference));
  std::shared_ptr<const mwperf::CompressionAnalysisResultV1> analysis;
  std::optional<mwperf::Diagnostic> analysis_failure;
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{1U}};
  options.run_diagnostic_fits = false;
  options.compute_delete_one_replication_jackknife = false;
  if (local_analysis_failure) {
    analysis_failure = mwperf::Diagnostic{
        mwperf::DiagnosticCategory::internal,
        "c30.fixture.local_analysis_failure",
        "fixture-local diagnostic analysis failure",
        std::nullopt,
        std::nullopt,
        {}};
  } else {
    auto analyzed =
        mwperf::analyze_compression_observations_v1(*observation, options);
    INFO((analyzed ? std::string{}
                   : analyzed.error().code + ": " +
                         analyzed.error().message));
    REQUIRE(analyzed);
    analysis = std::make_shared<const mwperf::CompressionAnalysisResultV1>(
        std::move(analyzed).value());
  }
  return std::make_shared<const mwperf::AnalysisDiagnosticSupplementV2>(
      std::move(observation), std::move(analysis),
      std::move(analysis_failure),
      mwperf::AnalysisProviderSuppliedProfileV2{
          mwperf::AnalysisProviderSuppliedProfileStatusV2::not_applicable,
          std::nullopt, std::nullopt},
      mwperf::AnalysisDecoderProfileV2{
          mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
          std::nullopt, std::nullopt},
      terminal, std::move(options));
}

void require_c30_result_projection_invariant(
    const mwperf::ResolvedRequest& resolved,
    const mwperf::ExecutionPlan& plan,
    mwperf::AnalysisBundle bundle,
    const std::optional<std::string> nonfailure_terminal_code = std::nullopt,
    const bool local_analysis_failure = false) {
  auto legacy = mwperf::assemble_result_artifact(resolved, plan, bundle);
  INFO((legacy ? std::string{}
               : legacy.error().code + ": " + legacy.error().message));
  REQUIRE(legacy);

  const mwperf::AnalysisDiagnosticTerminalV2 terminal{
      bundle.status(),
      bundle.failure().has_value()
          ? std::optional<mwperf::ResultFailureStageV1>{
                bundle.failure()->stage}
          : std::nullopt,
      bundle.failure().has_value()
          ? std::optional<std::string>{bundle.failure()->code}
          : nonfailure_terminal_code};
  const auto supplement =
      c30_diagnostic_supplement(terminal, local_analysis_failure);
  mwperf::testing::C27AnalysisBundleFixtureFactory::
      replace_diagnostic_supplement(bundle, supplement);

  auto selected = mwperf::assemble_selected_result_artifact(
      resolved, plan, bundle,
      mwperf::ResultVersionSelectionV1::automatic);
  INFO((selected ? std::string{}
                 : selected.error().code + ": " +
                       selected.error().message));
  REQUIRE(selected);
  CHECK(selected.value().version() == mwperf::ResultArtifactVersionV1::v2);
  CHECK(selected.value().status() == bundle.status());
  const auto* v2 =
      std::get_if<mwperf::ResultArtifactV2>(&selected.value().value());
  REQUIRE(v2 != nullptr);
  CHECK(v2->value().main == legacy.value().value());
  CHECK(v2->value().diagnostic_supplement == supplement);

  auto forbidden = mwperf::assemble_selected_result_artifact(
      resolved, plan, bundle, mwperf::ResultVersionSelectionV1::v1);
  REQUIRE_FALSE(forbidden);
  CHECK(forbidden.error().code ==
        "c30.result_v1_would_discard_diagnostics");
}

struct C30ExecutedFixture final {
  mwperf::ResolvedRequest resolved;
  mwperf::ExecutionPlan plan;
  mwperf::AnalysisBundle bundle;
};

[[nodiscard]] C30ExecutedFixture c30_execute_fixture(
    const std::string_view provider) {
  mwperf::ResolvedRequest resolved = resolved_iid_request(
      provider, R"json({"resolution_level":2})json", 3, 4);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  mwperf::ExecutionPlan frozen = std::move(plan).value();
  mwperf::AnalysisBundle bundle = mwperf::execute_analysis(frozen);
  return {std::move(resolved), std::move(frozen), std::move(bundle)};
}

[[nodiscard]] mwperf::Result<std::uint64_t> entropy_failure() {
  return mwperf::Result<std::uint64_t>::failure(mwperf::Diagnostic{
      .category = mwperf::DiagnosticCategory::unavailable,
      .code = "fixture_entropy_failure",
      .message = "injected entropy failure",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  });
}

[[nodiscard]] mwperf::Result<mwperf::detail::PublishedAnalysisStatus>
published_success(const mwperf::Analyze&) {
  return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::success(
      mwperf::detail::PublishedAnalysisStatus::success);
}

[[nodiscard]] mwperf::Result<mwperf::detail::PublishedAnalysisStatus>
published_unavailable(const mwperf::Analyze&) {
  return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::success(
      mwperf::detail::PublishedAnalysisStatus::unavailable);
}

[[nodiscard]] mwperf::Result<mwperf::detail::PublishedAnalysisStatus>
published_failed(const mwperf::Analyze&) {
  return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::success(
      mwperf::detail::PublishedAnalysisStatus::failed);
}

[[nodiscard]] mwperf::Result<mwperf::detail::PublishedAnalysisStatus>
publication_error(const mwperf::Analyze&) {
  return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
      mwperf::Diagnostic{mwperf::DiagnosticCategory::internal,
                         "fixture_publication_error",
                         "the fixture deliberately failed publication",
                         std::nullopt,
                         std::nullopt,
                         {}});
}

[[nodiscard]] int published_cli_status(
    const mwperf::detail::PublishedAnalyzeEntrypoint entrypoint,
    std::string& standard_output, std::string& standard_error) {
  std::array<std::string, 7U> storage{
      "mwperf", "--model", "model.json", "--analysis", "analysis.json",
      "--output", "result.json"};
  std::array<char*, 7U> arguments{};
  for (std::size_t index = 0U; index < storage.size(); ++index) {
    arguments[index] = storage[index].data();
  }
  std::ostringstream output;
  std::ostringstream error;
  const int status = mwperf::detail::run_cli_boundary(
      static_cast<int>(arguments.size()), arguments.data(), output, error,
      entrypoint);
  standard_output = output.str();
  standard_error = error.str();
  return status;
}

}  // namespace

TEST_CASE("C27 builds the universal Full Orbit analysis from --target",
          "[c27][c27_1][integration]") {
  std::string model = c27_shared_arrival_model();
  std::size_t offset = 0U;
  while ((offset = model.find("q0", offset)) != std::string::npos) {
    model.replace(offset, 2U, "hub");
    offset += 3U;
  }
  const auto model_path = write_fixture("builtin-analysis-model", model);
  const auto output_path = c27_directory() / "builtin-analysis-result.json";
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {},
      .output_path = {output_path.string(), output_path},
      .target_queue = std::string("hub"),
  }};

  auto first = mwperf::testing::load_and_resolve_request_with_entropy(
      request, [] { return mwperf::Result<std::uint64_t>::success(1U); });
  INFO((first ? std::string{}
              : first.error().code + ": " + first.error().message));
  REQUIRE(first);
  auto second = mwperf::testing::load_and_resolve_request_with_entropy(
      request, [] { return mwperf::Result<std::uint64_t>::success(2U); });
  REQUIRE(second);

  const auto& analysis = first.value().instance().analysis_spec();
  REQUIRE(analysis.context != nullptr);
  REQUIRE(analysis.context->targets.queue_ids.size() == 1U);
  CHECK(analysis.context->targets.queue_ids.front().is_text());
  CHECK(*analysis.context->targets.queue_ids.front().text_value() == "hub");
  CHECK(analysis.metrics.size() == 6U);
  CHECK(analysis.surrogate.id == "full_orbit_framework_sampler");
  CHECK(analysis.surrogate.version == std::optional<std::string>{"1.2.0"});
  REQUIRE(analysis.surrogate.parameters.kind() ==
          mwperf::SourceNodeKind::object);
  const auto* schema_version =
      analysis.surrogate.parameters.find("schema_version");
  const auto* warmup_slots =
      analysis.surrogate.parameters.find("warmup_slots");
  const auto* horizon_slots =
      analysis.surrogate.parameters.find("horizon_slots");
  const auto* replications =
      analysis.surrogate.parameters.find("replications");
  const auto* population_size =
      analysis.surrogate.parameters.find("population_size");
  const auto* response_cutoff =
      analysis.surrogate.parameters.find("response_cutoff");
  REQUIRE(schema_version != nullptr);
  REQUIRE(warmup_slots != nullptr);
  REQUIRE(horizon_slots != nullptr);
  REQUIRE(replications != nullptr);
  REQUIRE(population_size != nullptr);
  REQUIRE(response_cutoff != nullptr);
  CHECK(*schema_version->number_lexeme() == "2");
  CHECK(*warmup_slots->number_lexeme() == "20");
  CHECK(*horizon_slots->number_lexeme() == "100");
  CHECK(*replications->number_lexeme() == "8");
  CHECK(*population_size->number_lexeme() == "64");
  CHECK(*response_cutoff->number_lexeme() == "2");
  REQUIRE(analysis.context->resolution.optimizer.max_calls.has_value());
  CHECK(*analysis.context->resolution.optimizer.max_calls ==
        mwperf::BigNat{51200U});
  CHECK(*analysis.context->resolution.optimizer.max_calls ==
        mwperf::BigNat{8U} * mwperf::BigNat{64U} * mwperf::BigNat{100U});
  CHECK_FALSE(
      analysis.context->resolution.optimizer.max_search_states_per_call
          .has_value());
  CHECK_FALSE(analysis.context->resolution.sampling.max_generator_draws
                  .has_value());
  CHECK(first.value().analysis_path().authored.empty());
  CHECK(first.value().fingerprints() == second.value().fingerprints());
  CHECK(first.value().canonical_inputs() == second.value().canonical_inputs());
}

TEST_CASE("C27 --target rejects an unknown queue before planning",
          "[c27][c27_1][negative]") {
  const auto model_path =
      write_fixture("builtin-analysis-unknown", c27_shared_arrival_model());
  const auto output_path = c27_directory() / "unknown-target-result.json";
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {},
      .output_path = {output_path.string(), output_path},
      .target_queue = std::string("missing"),
  }};
  auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
      request, [] { return mwperf::Result<std::uint64_t>::success(1U); });
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().code == "cli_target_queue_unknown");
}

TEST_CASE("C27 resolver enforces one analysis source for direct callers",
          "[c27][c27_1][negative]") {
  const auto model_path = write_fixture("builtin-analysis-conflict-model",
                                        c27_shared_arrival_model());
  const auto analysis_path =
      write_fixture("builtin-analysis-conflict-analysis", "{}");
  const auto output_path = c27_directory() / "conflicting-source-result.json";
  const mwperf::CliRequest request{mwperf::Analyze{
      .model_path = {model_path.string(), model_path},
      .analysis_path = {analysis_path.string(), analysis_path},
      .output_path = {output_path.string(), output_path},
      .target_queue = std::string("q0"),
  }};
  auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
      request, [] { return mwperf::Result<std::uint64_t>::success(1U); });
  REQUIRE_FALSE(resolved);
  CHECK(resolved.error().code == "cli_analysis_source_invalid");
}

TEST_CASE("C27 resolves authored and automatic seeds exactly once",
          "[c27][unit]") {
  SECTION("a fixed authored seed never observes entropy") {
    const RequestFiles files =
        request_files(R"json("seed":17)json", "unregistered-c27-provider");
    unsigned int entropy_calls = 0U;
    auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
        cli_request(files), [&entropy_calls]() {
          ++entropy_calls;
          return mwperf::Result<std::uint64_t>::success(9001U);
        });
    INFO((resolved ? std::string{}
                   : resolved.error().code + ": " + resolved.error().message));
    REQUIRE(resolved);
    CHECK(entropy_calls == 0U);
    CHECK(resolved.value().master_seed() == mwperf::MasterSeed(17U));
    CHECK(resolved.value().seed_source() ==
          mwperf::ResolvedSeedSource::authored_fixed);
  }

  SECTION("the automatic sentinel consumes one injected word") {
    const RequestFiles files =
        request_files(R"json("seed":-1)json", "unregistered-c27-provider");
    unsigned int entropy_calls = 0U;
    auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
        cli_request(files), [&entropy_calls]() {
          ++entropy_calls;
          return mwperf::Result<std::uint64_t>::success(0x123456789abcdef0ULL);
        });
    INFO((resolved ? std::string{}
                   : resolved.error().code + ": " + resolved.error().message));
    REQUIRE(resolved);
    CHECK(entropy_calls == 1U);
    CHECK(resolved.value().master_seed() ==
          mwperf::MasterSeed(0x123456789abcdef0ULL));
    CHECK(resolved.value().seed_source() ==
          mwperf::ResolvedSeedSource::operating_system_entropy);
  }
}

TEST_CASE("C27 seed resolution does not change authored fingerprints",
          "[c27][property]") {
  const RequestFiles files =
      request_files(R"json("seed":-1)json", "unregistered-c27-provider");
  auto first = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(11U);
      });
  auto second = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(29U);
      });
  REQUIRE(first);
  REQUIRE(second);

  CHECK(first.value().fingerprints() == second.value().fingerprints());
  CHECK(first.value().canonical_inputs() == second.value().canonical_inputs());
  CHECK_FALSE(first.value().master_seed() == second.value().master_seed());

  const mwperf::ResolvedRequest shared = first.value();
  CHECK(shared.shares_resolution_owner_with(first.value()));
  CHECK_FALSE(shared.shares_resolution_owner_with(second.value()));
}

TEST_CASE("C27 entropy failure is typed and leaves output untouched",
          "[c27][negative]") {
  const RequestFiles files =
      request_files(R"json("seed":-1)json", "unregistered-c27-provider");
  constexpr std::string_view sentinel = "prior-result-must-survive";
  {
    std::ofstream output(files.output, std::ios::binary | std::ios::trunc);
    REQUIRE(output.is_open());
    output.write(sentinel.data(),
                 static_cast<std::streamsize>(sentinel.size()));
    REQUIRE(output.good());
  }

  unsigned int entropy_calls = 0U;
  auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [&entropy_calls]() {
        ++entropy_calls;
        return entropy_failure();
      });
  REQUIRE_FALSE(resolved);
  CHECK(entropy_calls == 1U);
  CHECK(resolved.error().code == "seed_entropy_unavailable");
  CHECK(read_bytes(files.output) == sentinel);
}

TEST_CASE("C27 unknown providers are rejected before execution or output",
          "[c27][integration]") {
  const RequestFiles files =
      request_files(R"json("seed":23)json", "unregistered-c27-provider");
  constexpr std::string_view sentinel = "preplan-output-must-not-change";
  {
    std::ofstream output(files.output, std::ios::binary | std::ios::trunc);
    REQUIRE(output.is_open());
    output.write(sentinel.data(),
                 static_cast<std::streamsize>(sentinel.size()));
    REQUIRE(output.good());
  }

  auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(999U);
      });
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code == "c16.unknown_surrogate_id");
  CHECK(read_bytes(files.output) == sentinel);
}

TEST_CASE("C27 independently rejects a mutated frozen execution plan",
          "[c27][negative]") {
  const mwperf::ResolvedRequest resolved = resolved_iid_request(
      "c16.fixture.mwis.engineered", R"json({"resolution_level":2})json",
      3, 4);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  const auto* framework_scalar =
      std::get_if<mwperf::FrameworkScalarIdentityBackendPlanV1>(
          &plan.value().metric_plans().front().backend());
  REQUIRE(framework_scalar != nullptr);
  CHECK(framework_scalar->scalar ==
        mwperf::FrameworkScalarKindV1::arrival_intensity);
  CHECK(framework_scalar->stationary_proof.backend ==
        mwperf::StationaryProofBackendV1::c19_scalar_iid_summary);
  CHECK(framework_scalar->stationary_proof.selected_regime ==
        mwperf::MetricSelectionRegimeV1::stationary_unique);
  CHECK(framework_scalar->stationary_proof.requires_exact_iid_law);
  CHECK(framework_scalar->stationary_proof.requires_proper_normalized_invariant);

  SECTION("metric cardinality is part of the frozen identity") {
    auto corrupted = plan.value();
    mwperf::testing::C27ExecutionPlanFixtureFactory::remove_metric_plans(
        corrupted);
    auto validated = mwperf::validate_execution_plan(corrupted);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c27.plan_metric_cardinality_mismatch");
  }

  SECTION("the accepted backend law cannot be re-selected by metric kind") {
    auto corrupted = plan.value();
    mwperf::testing::C27ExecutionPlanFixtureFactory::
        replace_backend_with_foreign_route(corrupted);
    auto validated = mwperf::validate_execution_plan(corrupted);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c27.plan_backend_payload_mismatch");
  }

  SECTION("the scalar identity cannot discard its stationary proof") {
    auto corrupted = plan.value();
    mwperf::testing::C27ExecutionPlanFixtureFactory::
        remove_framework_stationarity_requirement(corrupted);
    auto validated = mwperf::validate_execution_plan(corrupted);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c27.plan_backend_payload_mismatch");
  }

  SECTION("the C19 proof cannot discard its exact IID arrival premise") {
    auto corrupted = plan.value();
    mwperf::testing::C27ExecutionPlanFixtureFactory::
        remove_framework_exact_iid_requirement(corrupted);
    auto validated = mwperf::validate_execution_plan(corrupted);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c27.plan_backend_payload_mismatch");
  }

  SECTION("dependency sharing retains the configured arrival identity") {
    auto corrupted = plan.value();
    mwperf::testing::C27ExecutionPlanFixtureFactory::
        replace_dependency_arrival_identity(corrupted);
    auto validated = mwperf::validate_execution_plan(corrupted);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "c27.plan_dependency_schedule_mismatch");
  }
}

TEST_CASE("C27 provider outcomes remain transactional after planning",
          "[c27][integration]") {
  const auto execute_fixture = [](const std::string_view provider) {
    const mwperf::ResolvedRequest resolved =
        resolved_iid_request(provider, R"json({"resolution_level":2})json",
                             3, 4);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(mwperf::validate_execution_plan(plan.value()));
    return mwperf::execute_analysis(plan.value());
  };

  SECTION("validated wire Unavailable retains no payload or metric value") {
    const mwperf::AnalysisBundle bundle =
        execute_fixture("c16.fixture.flow.unavailable");
    CHECK(bundle.status() == mwperf::ResultStatusV1::unavailable);
    CHECK_FALSE(bundle.failure().has_value());
    REQUIRE(bundle.build_report().has_value());
    REQUIRE(bundle.execution_identity().request_identity.has_value());
    CHECK_FALSE(bundle.execution_identity().payload_digest.has_value());
    CHECK_FALSE(bundle.execution_identity().plug_kind.has_value());
    const auto* search_states = execution_budget(
        bundle, "execution.shared_optimizer_search_states");
    REQUIRE(search_states != nullptr);
    REQUIRE(search_states->granted.has_value());
    CHECK(*search_states->granted == mwperf::BigNat{16384U});
    CHECK(search_states->used.is_zero());
    CHECK(search_states->unit == "states");
    REQUIRE(bundle.metrics().size() == 1U);
    CHECK(std::holds_alternative<mwperf::UnavailableResultMetricV1>(
        bundle.metrics().front()));
    CHECK_FALSE(std::holds_alternative<mwperf::EstablishedResultMetricV1>(
        bundle.metrics().front()));
  }

  SECTION("validated wire Failed discards every staged metric") {
    const mwperf::AnalysisBundle bundle =
        execute_fixture("c16.fixture.flow.failed");
    CHECK(bundle.status() == mwperf::ResultStatusV1::failed);
    REQUIRE(bundle.failure().has_value());
    CHECK(bundle.failure()->stage ==
          mwperf::ResultFailureStageV1::producer_execution);
    CHECK(bundle.failure()->code == "c16.fixture.flow.failed");
    REQUIRE(bundle.failure()->diagnostic_refs.size() == 1U);
    const auto failure_diagnostic = std::ranges::find_if(
        bundle.diagnostics(), [&](const mwperf::ResultDiagnosticV1& value) {
          return value.diagnostic_id ==
                 bundle.failure()->diagnostic_refs.front();
        });
    REQUIRE(failure_diagnostic != bundle.diagnostics().end());
    CHECK(failure_diagnostic->code == bundle.failure()->code);
    CHECK(failure_diagnostic->category ==
          mwperf::DiagnosticCategory::internal);
    CHECK(failure_diagnostic->assumptions ==
          std::vector<std::string>{
              "provider_failure_kind=construction_failure"});
    REQUIRE(bundle.build_report().has_value());
    REQUIRE(bundle.execution_identity().request_identity.has_value());
    CHECK_FALSE(bundle.execution_identity().payload_digest.has_value());
    CHECK_FALSE(bundle.execution_identity().plug_kind.has_value());
    const auto* optimizer_calls = execution_budget(
        bundle, "execution.shared_optimizer_calls");
    const auto* search_states = execution_budget(
        bundle, "execution.shared_optimizer_search_states");
    REQUIRE(optimizer_calls != nullptr);
    REQUIRE(search_states != nullptr);
    REQUIRE(optimizer_calls->granted.has_value());
    REQUIRE(search_states->granted.has_value());
    CHECK(*optimizer_calls->granted == mwperf::BigNat{128U});
    CHECK(optimizer_calls->used ==
          bundle.build_report()->optimizer_calls.used);
    CHECK(optimizer_calls->unit == "calls");
    CHECK(*search_states->granted == mwperf::BigNat{16384U});
    CHECK(search_states->used ==
          bundle.build_report()->optimizer_search_states.used);
    CHECK(search_states->unit == "states");
    const std::array construction_rows{
        std::pair{"construction.exact_optimizer_calls",
                  &bundle.build_report()->optimizer_calls},
        std::pair{"construction.optimizer_search_states",
                  &bundle.build_report()->optimizer_search_states},
        std::pair{"construction.configured_generator_draws",
                  &bundle.build_report()->configured_generator_draws},
    };
    for (const auto& [name, counter] : construction_rows) {
      const auto* row = execution_budget(bundle, name);
      REQUIRE(row != nullptr);
      CHECK(row->used == counter->used);
      CHECK(row->unit == "count");
    }
    CHECK(bundle.metrics().empty());
  }

  SECTION("provider failure codes cannot impersonate a Built mismatch") {
    const mwperf::AnalysisBundle bundle =
        execute_fixture("c27.fixture.flow.failed-reserved-code");
    CHECK(bundle.status() == mwperf::ResultStatusV1::failed);
    REQUIRE(bundle.failure().has_value());
    CHECK(bundle.failure()->stage ==
          mwperf::ResultFailureStageV1::producer_execution);
    CHECK(bundle.failure()->code == "requirements_not_exactly_accepted");
    REQUIRE(bundle.failure()->diagnostic_refs.size() == 1U);
    const auto failure_diagnostic = std::ranges::find_if(
        bundle.diagnostics(), [&](const mwperf::ResultDiagnosticV1& value) {
          return value.diagnostic_id ==
                 bundle.failure()->diagnostic_refs.front();
        });
    REQUIRE(failure_diagnostic != bundle.diagnostics().end());
    CHECK(failure_diagnostic->code == bundle.failure()->code);
    CHECK(failure_diagnostic->category ==
          mwperf::DiagnosticCategory::internal);
    CHECK(failure_diagnostic->assumptions ==
          std::vector<std::string>{
              "provider_failure_kind=construction_failure"});
    REQUIRE(bundle.build_report().has_value());
    CHECK_FALSE(bundle.execution_identity().payload_digest.has_value());
    CHECK_FALSE(bundle.execution_identity().plug_kind.has_value());
    CHECK(bundle.metrics().empty());
  }
}

TEST_CASE("C30 diagnostic supplements preserve every main terminal outcome",
          "[c30][result-model][integration]") {
  SECTION("adapter V0 and backend success") {
    auto fixture = c30_execute_fixture("c16.fixture.mwis.engineered");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::success);
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle));
  }

  SECTION("wire Unavailable") {
    auto fixture = c30_execute_fixture("c16.fixture.flow.unavailable");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::unavailable);
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle),
        std::string("c16.fixture.flow.unavailable"));
  }

  SECTION("provider Failed") {
    auto fixture = c30_execute_fixture("c16.fixture.flow.failed");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::failed);
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle));
  }

  SECTION("V0 audit failure") {
    auto fixture = c30_execute_fixture("c16.fixture.mwis.engineered");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::success);
    mwperf::testing::C27AnalysisBundleFixtureFactory::replace_with_failure(
        fixture.bundle, mwperf::ResultFailureStageV1::v0_audit,
        "c17.direct_factor_optimizer_bound_exceeded");
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle));
  }

  SECTION("backend failure") {
    auto fixture = c30_execute_fixture("c16.fixture.mwis.engineered");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::success);
    mwperf::testing::C27AnalysisBundleFixtureFactory::replace_with_failure(
        fixture.bundle, mwperf::ResultFailureStageV1::backend,
        "c30.fixture.backend_failure");
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle));
  }

  SECTION("local diagnostic analysis failure does not change main success") {
    auto fixture = c30_execute_fixture("c16.fixture.mwis.engineered");
    REQUIRE(fixture.bundle.status() == mwperf::ResultStatusV1::success);
    require_c30_result_projection_invariant(
        fixture.resolved, fixture.plan, std::move(fixture.bundle),
        std::nullopt, true);
  }
}

TEST_CASE("C30 execute retains a validated v2 observation on every post-envelope terminal",
          "[c30][result-model][integration][provider-result-v2]") {
  struct Case final {
    std::string_view provider;
    mwperf::ResultStatusV1 expected_status;
    std::optional<mwperf::ResultFailureStageV1> expected_failure_stage;
  };
  constexpr std::array<Case, 4U> cases{{
      {"c30.fixture.flow.built", mwperf::ResultStatusV1::success,
       std::nullopt},
      {"c30.fixture.flow.unavailable", mwperf::ResultStatusV1::unavailable,
       std::nullopt},
      {"c30.fixture.flow.failed", mwperf::ResultStatusV1::failed,
       mwperf::ResultFailureStageV1::producer_execution},
      {"c30.fixture.flow.branch-decode", mwperf::ResultStatusV1::failed,
       mwperf::ResultFailureStageV1::wire_parse},
  }};

  for (const auto& test : cases) {
    CAPTURE(test.provider);
    const auto fixture = c30_execute_fixture(test.provider);
    CHECK(fixture.bundle.status() == test.expected_status);
    if (test.expected_failure_stage) {
      REQUIRE(fixture.bundle.failure());
      CHECK(fixture.bundle.failure()->stage == *test.expected_failure_stage);
    } else {
      CHECK_FALSE(fixture.bundle.failure().has_value());
    }

    const auto& supplement = fixture.bundle.diagnostic_supplement();
    REQUIRE(supplement);
    REQUIRE(supplement->observation());
    REQUIRE(supplement->analysis());
    CHECK_FALSE(supplement->analysis_failure().has_value());
    CHECK(supplement->analysis()->observation_digest ==
          supplement->observation()->digest());
    CHECK(supplement->terminal().main_status == test.expected_status);
    CHECK(supplement->terminal().failure_stage == test.expected_failure_stage);
    if (test.expected_status == mwperf::ResultStatusV1::failed) {
      REQUIRE(fixture.bundle.failure());
      CHECK(supplement->terminal().code == fixture.bundle.failure()->code);
    }
  }
}

TEST_CASE("C30 execute retains no observation when common-report validation fails",
          "[c30][result-model][integration][provider-result-v2][negative]") {
  const auto fixture =
      c30_execute_fixture("c30.fixture.flow.invalid-common-report");
  CHECK(fixture.bundle.status() == mwperf::ResultStatusV1::failed);
  REQUIRE(fixture.bundle.failure());
  CHECK(fixture.bundle.failure()->stage ==
        mwperf::ResultFailureStageV1::build_contract_validation);
  CHECK(fixture.bundle.failure()->code == "c15.report_request_digest");
  CHECK_FALSE(fixture.bundle.build_report().has_value());
  CHECK_FALSE(fixture.bundle.diagnostic_supplement());
}

TEST_CASE("C27 binds optimizer accounting to the frozen downstream route",
          "[c27][integration][accounting]") {
  const mwperf::ResolvedRequest resolved = resolved_iid_request(
      "c16.fixture.flow.closed-form", R"json({"resolution_level":2})json",
      3, 4);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  REQUIRE(plan.value().metric_plans().size() == 1U);
  REQUIRE(plan.value().metric_plans().front().route_kind() !=
          mwperf::BackendRouteKindV1::exact_direct);

  const mwperf::AnalysisBundle original =
      mwperf::execute_analysis(plan.value());
  INFO((original.failure().has_value() ? original.failure()->code
                                       : std::string{}));
  REQUIRE(original.status() == mwperf::ResultStatusV1::success);
  REQUIRE(mwperf::assemble_result_artifact(resolved, plan.value(), original));

  SECTION("optimizer-free routes reject invented shared calls") {
    auto corrupted = original;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                increment_execution_budget(
                    corrupted, "execution.shared_optimizer_calls"));
    auto assembled =
        mwperf::assemble_result_artifact(resolved, plan.value(), corrupted);
    REQUIRE_FALSE(assembled);
    CHECK(assembled.error().code ==
          "c27.result_optimizer_budget_mismatch");
  }

  SECTION("optimizer-free routes reject invented shared search states") {
    auto corrupted = original;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                increment_execution_budget(
                    corrupted,
                    "execution.shared_optimizer_search_states"));
    auto assembled =
        mwperf::assemble_result_artifact(resolved, plan.value(), corrupted);
    REQUIRE_FALSE(assembled);
    CHECK(assembled.error().code ==
          "c27.result_optimizer_search_state_budget_mismatch");
  }

  SECTION("referenced call-cap failure remains publishable") {
    auto terminal = original;
    const std::array<std::string_view, 2U> omitted{
        "execution.shared_optimizer_calls",
        "execution.shared_optimizer_search_states"};
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                replace_with_accounting_failure_without_budgets(
                    terminal, omitted,
                    "c27.shared_optimizer_ledger_cap_exceeded"));
    auto assembled =
        mwperf::assemble_result_artifact(resolved, plan.value(), terminal);
    INFO((assembled ? std::string{}
                    : assembled.error().code + ": " +
                          assembled.error().message));
    CHECK(assembled);
  }

  SECTION("referenced search-state-cap failure remains publishable") {
    auto terminal = original;
    const std::array<std::string_view, 1U> omitted{
        "execution.shared_optimizer_search_states"};
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                replace_with_accounting_failure_without_budgets(
                    terminal, omitted,
                    "c27.shared_optimizer_search_state_cap_exceeded"));
    auto assembled =
        mwperf::assemble_result_artifact(resolved, plan.value(), terminal);
    INFO((assembled ? std::string{}
                    : assembled.error().code + ": " +
                          assembled.error().message));
    CHECK(assembled);
  }
}

TEST_CASE("C27 framework scalar identity requires a proper stationary law",
          "[c27][integration]") {
  const mwperf::ResolvedRequest rebound = resolved_iid_request(
      "c16.fixture.flow.closed-form", R"json({"resolution_level":2})json",
      3, 4);

  auto plan = mwperf::build_execution_plan(rebound);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(plan.value().metric_plans().size() == 1U);
  CHECK(plan.value().metric_plans().front().route_kind() ==
        mwperf::BackendRouteKindV1::framework_scalar_identity);

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  std::string outcome_reason;
  if (!bundle.metrics().empty()) {
    if (const auto* unavailable =
            std::get_if<mwperf::UnavailableResultMetricV1>(
                &bundle.metrics().front())) {
      outcome_reason = unavailable->reason_code;
    }
  }
  INFO(outcome_reason);
  CHECK(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.execution_identity().execution_seal_digest.has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* established =
      std::get_if<mwperf::EstablishedResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(established != nullptr);
  CHECK(established->header.units == "packets/slot");
  CHECK(established->header.scientific_scope ==
        mwperf::MetricResultScopeV1::surrogate_law);
  CHECK(established->header.law_identity ==
        *bundle.execution_identity().execution_seal_digest);
  const auto* scalar =
      std::get_if<mwperf::PortableScientificScalar>(&established->value);
  REQUIRE(scalar != nullptr);
  CHECK(scalar->kind() ==
        mwperf::PortableScientificScalarKind::rational);
  auto expected = mwperf::ExactRational::make(mwperf::BigInt{1},
                                               mwperf::BigInt{4});
  REQUIRE(expected);
  CHECK(scalar->rational_value() == expected.value());
  CHECK(std::ranges::any_of(
      bundle.diagnostics(), [](const mwperf::ResultDiagnosticV1& diagnostic) {
        return diagnostic.code == "c27.c19.normalization_residual";
      }));
  CHECK(std::ranges::any_of(
      bundle.diagnostics(), [](const mwperf::ResultDiagnosticV1& diagnostic) {
        return diagnostic.code == "c27.c19.invariance_residual";
      }));
  CHECK(established->header.residual_refs ==
        std::vector<std::string>{"c27.c19.normalization_residual",
                                 "c27.c19.invariance_residual"});

  SECTION("an unstable deployed response makes stationary throughput unavailable") {
    const mwperf::ResolvedRequest unstable = resolved_iid_request(
        "c16.fixture.flow.closed-form",
        R"json({"resolution_level":2})json", 1, 4);
    auto unstable_plan = mwperf::build_execution_plan(unstable);
    REQUIRE(unstable_plan);
    const mwperf::AnalysisBundle unavailable =
        mwperf::execute_analysis(unstable_plan.value());
    CHECK(unavailable.status() == mwperf::ResultStatusV1::unavailable);
    CHECK_FALSE(unavailable.failure().has_value());
    REQUIRE(unavailable.metrics().size() == 1U);
    const auto* missing =
        std::get_if<mwperf::UnavailableResultMetricV1>(
            &unavailable.metrics().front());
    REQUIRE(missing != nullptr);
    CHECK(missing->reason_code ==
          "c27.stationary_throughput_not_established");
  }

  SECTION("a foreign arrival family is rejected by the rebind seam") {
    const RequestFiles foreign_files = request_files(
        R"json("seed":47)json", "c16.fixture.flow.closed-form");
    auto foreign = mwperf::testing::load_and_resolve_request_with_entropy(
        cli_request(foreign_files), [] {
          return mwperf::Result<std::uint64_t>::success(654U);
        });
    REQUIRE(foreign);
    auto rejected =
        mwperf::testing::rebind_resolved_request_arrival_for_testing(
            rebound,
            std::make_shared<const mwperf::CompiledArrivalLaw>(
                foreign.value().compiled_arrival()));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c27.fixture_arrival_physical_binding_mismatch");
  }
}

TEST_CASE("C27.9 C19 projects one target PMF from the compact factorized IID "
          "law",
          "[c27][c27_9][integration][stationary]") {
  constexpr std::size_t source_count = 65U;
  const RequestFiles files{
      write_fixture("factorized-iid-model",
                    c27_factorized_iid_model(source_count)),
      write_fixture(
          "factorized-iid-analysis",
          analysis_with_provider(
              "c16.fixture.flow.closed-form",
              R"json({"resolution_level":2})json",
              R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json")),
      c27_directory() / "factorized-iid-result-v1.json"};
  auto resolved = mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(321U);
      });
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);

  const auto capabilities =
      mwperf::arrival_capabilities(resolved.value().compiled_arrival());
  REQUIRE(capabilities.exact_factorized_iid_generator.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  const auto arrival_view =
      mwperf::builder_arrival_view(resolved.value().compiled_arrival());
  CHECK_FALSE(arrival_view.iid_joint_table().has_value());

  auto plan = mwperf::build_execution_plan(resolved.value());
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  REQUIRE(plan.value().metric_plans().size() == 1U);
  const auto* backend =
      std::get_if<mwperf::FrameworkScalarIdentityBackendPlanV1>(
          &plan.value().metric_plans().front().backend());
  REQUIRE(backend != nullptr);
  CHECK(backend->stationary_proof.requires_exact_iid_law);

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  REQUIRE(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* established =
      std::get_if<mwperf::EstablishedResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(established != nullptr);
  const auto* throughput =
      std::get_if<mwperf::PortableScientificScalar>(&established->value);
  REQUIRE(throughput != nullptr);
  REQUIRE(throughput->kind() ==
          mwperf::PortableScientificScalarKind::rational);
  auto expected_target_mean = mwperf::ExactRational::make(
      mwperf::BigInt{65}, mwperf::BigInt{1024});
  REQUIRE(expected_target_mean);
  CHECK(throughput->rational_value() == expected_target_mean.value());
}

TEST_CASE("C27 never publishes impossible throughput for an unstable "
          "unit-service queue",
          "[c27][integration]") {
  // The exact IID table is (A_q0,A_q1)=(0,1) with mass 1/4 and
  // (A_q0,A_q1)=(2,0) with mass 3/4.  Hence E[A_q0]=3/2 while every
  // nonempty-slot service is exactly one packet.
  const mwperf::ResolvedRequest unstable = resolved_iid_request(
      "c27.fixture.flow.unit-service", R"json({"resolution_level":2})json",
      1, 4,
      mwperf::testing::FixtureConstructionProfile::
          portable_iid_batch_joint_table);

  const auto& arrival = unstable.compiled_arrival();
  const auto capabilities = mwperf::arrival_capabilities(arrival);
  REQUIRE(capabilities.exact_iid_joint_vector.has_value());
  REQUIRE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_coordinate_moments->maximum_order ==
        std::optional<mwperf::BigNat>{mwperf::BigNat{1U}});
  const auto view = mwperf::builder_arrival_view(arrival);
  REQUIRE(view.iid_joint_table().has_value());
  REQUIRE(view.iid_joint_table()->size() == 2U);
  REQUIRE(view.moments().has_value());
  auto target = unstable.instance().queues().index_at(0U);
  REQUIRE(target);
  auto expected_mean = mwperf::ExactRational::make(
      mwperf::BigInt{3}, mwperf::BigInt{2});
  REQUIRE(expected_mean);
  const auto moment = std::ranges::find_if(
      *view.moments(), [&](const mwperf::ExactMomentDatum& datum) {
        return datum.coordinates ==
                   std::vector<mwperf::DenseQueueIndex>{target.value()} &&
               datum.order == mwperf::BigNat{1U};
      });
  REQUIRE(moment != view.moments()->end());
  CHECK(moment->value == expected_mean.value());

  auto plan = mwperf::build_execution_plan(unstable);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  CHECK(bundle.status() == mwperf::ResultStatusV1::unavailable);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.execution_identity().execution_seal_digest.has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* unavailable =
      std::get_if<mwperf::UnavailableResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(unavailable != nullptr);
  CHECK_FALSE(unavailable->reason_code.empty());
  CHECK_FALSE(std::ranges::any_of(
      bundle.metrics(), [](const mwperf::ResultMetricV1& metric) {
        return std::holds_alternative<mwperf::EstablishedResultMetricV1>(
            metric);
      }));
}

TEST_CASE("C27 backend unavailability classification fails closed",
          "[c27][unit]") {
  const auto diagnostic = [](
      const std::string_view code,
      const mwperf::DiagnosticCategory category =
          mwperf::DiagnosticCategory::unavailable) {
    return mwperf::Diagnostic{category, std::string(code), "fixture",
                              std::nullopt, std::nullopt, {}};
  };
  static constexpr std::array<std::string_view, 16U> scientific{
      "c19.stationary_unique_not_established",
      "c22.zero_departure_intensity_for_persistence",
      "c22.zero_event_intensity",
      "c22.zero_run_start_intensity",
      "c23.admission_palm_zero_intensity",
      "c23.event_palm_zero_intensity",
      "c23.fifo_condition_zero_palm_mass",
      "c27.conditioning_mass_not_positive",
      "c27.fifo_moment_unresolved",
      "c27.fifo_quantile_unresolved_horizon",
      "c27.stationary_first_hit_entrance_not_outside_set",
      "c27.stationary_first_hit_mean_not_established",
      "c27.stationary_publication_not_established",
      "c27.stationary_throughput_not_established",
      "c27.k_bin_metric_not_established",
      "c27.three_bin_metric_not_established",
  };
  for (const std::string_view code : scientific) {
    INFO(code);
    CHECK(mwperf::testing::
              is_permitted_backend_scientific_unavailability(
                  diagnostic(code)));
  }

  static constexpr std::array<std::string_view, 6U> failures{
      "c18.audited_row_provider_unavailable",
      "c21.required_audited_projection_view_unavailable",
      "c22.temporal_kernel_source_binding_mismatch",
      "c23.admission_batch_mark_not_retained",
      "c21.mean_residence_product_overflow",
      "c27.future_unreviewed_unavailable",
  };
  for (const std::string_view code : failures) {
    INFO(code);
    CHECK_FALSE(mwperf::testing::
                    is_permitted_backend_scientific_unavailability(
                        diagnostic(code)));
  }
  CHECK_FALSE(
      mwperf::testing::is_permitted_backend_scientific_unavailability(
          diagnostic("c27.stationary_throughput_not_established",
                     mwperf::DiagnosticCategory::internal)));
}

TEST_CASE("C27 published result states have stable CLI exit semantics",
          "[c27][unit]") {
  std::string standard_output;
  std::string standard_error;

  CHECK(published_cli_status(&published_success, standard_output,
                             standard_error) == 0);
  CHECK(standard_output.empty());
  CHECK(standard_error.empty());

  CHECK(published_cli_status(&published_unavailable, standard_output,
                             standard_error) == 3);
  CHECK(standard_output.empty());
  CHECK(standard_error.empty());

  CHECK(published_cli_status(&published_failed, standard_output,
                             standard_error) == 1);
  CHECK(standard_output.empty());
  CHECK(standard_error.empty());

  CHECK(published_cli_status(&publication_error, standard_output,
                             standard_error) == 1);
  CHECK(standard_output.empty());
  CHECK(standard_error.find("fixture_publication_error") !=
        std::string::npos);
}

namespace {

[[nodiscard]] std::string c27_planning_two_queue_model() {
  return R"json({
    "schema_version":"3.0.0",
    "run":{"seed":59,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"sparse_nonzero",
      "include_packet_events":false,"include_scheduler_state":false,
      "write_slot_trace":false},
    "metadata":{"fixture":"c27-planning"}
  })json";
}

[[nodiscard]] std::string c27_planning_analysis(
    const std::string_view provider, const std::string_view targets,
    const std::string_view metrics, const std::string_view solver,
    const std::string_view max_generator_draws = "null",
    const std::string_view optimizer_calls = "128",
    const std::string_view optimizer_states = "128",
    const std::string_view max_states = "128",
    const std::string_view linear_residual_abs = "null",
    const std::string_view selection =
        R"json({"kind":"stationary_unique","parameters":{}})json") {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":)json") +
         std::string(targets) + R"json(,
    "metrics":)json" + std::string(metrics) + R"json(,
    "surrogate":{"id":")json" + std::string(provider) +
         R"json(","version":null,"parameters":{"resolution_level":2}},
    "resolution":{
      "level":{"max_states":)json" + std::string(max_states) + R"json(,"max_row_atoms":128},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":16},
      "optimizer":{"max_calls":)json" + std::string(optimizer_calls) +
         R"json(,"max_search_states_per_call":)json" +
         std::string(optimizer_states) + R"json(},
      "sampling":{"max_generator_draws":)json" +
         std::string(max_generator_draws) + R"json(},
      "tolerance":{"linear_residual_abs":)json" +
         std::string(linear_residual_abs) + R"json(,"integration_abs":null,
        "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" + std::string(selection) + R"json(,
    "solver":)json" + std::string(solver) + "}";
}

[[nodiscard]] RequestFiles c27_planning_request(
    const std::string_view model, const std::string_view analysis,
    const std::string_view stem) {
  return {write_fixture(std::string(stem) + "-model", model),
          write_fixture(std::string(stem) + "-analysis", analysis),
          c27_directory() / (std::string(stem) + "-result-v1.json")};
}

[[nodiscard]] mwperf::Result<mwperf::ResolvedRequest>
c27_resolve_planning_request(const RequestFiles& files) {
  return mwperf::testing::load_and_resolve_request_with_entropy(
      cli_request(files), [] {
        return mwperf::Result<std::uint64_t>::success(0xC27U);
      });
}

[[nodiscard]] mwperf::ResolvedRequest c27_rebind_planning_iid(
    const RequestFiles& files,
    const std::int64_t first_outcome_numerator = 3,
    const std::int64_t first_outcome_denominator = 4) {
  auto authored = c27_resolve_planning_request(files);
  REQUIRE(authored);
  auto first_mass = mwperf::ExactRational::make(
      mwperf::BigInt{first_outcome_numerator},
      mwperf::BigInt{first_outcome_denominator});
  REQUIRE(first_mass);
  auto fixture_law = mwperf::testing::make_c09_weighted_correlated_fixture_law(
      authored.value().instance().queues(), first_mass.value(),
      mwperf::testing::FixtureConstructionProfile::
          portable_iid_bernoulli_joint_table);
  REQUIRE(fixture_law);
  auto rebound = mwperf::testing::rebind_resolved_request_arrival_for_testing(
      authored.value(),
      std::make_shared<const mwperf::CompiledArrivalLaw>(
          std::move(fixture_law).value()));
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  return std::move(rebound).value();
}

enum class C27TemporalArrivalFixtureV1 : std::uint8_t {
  stationary_homogeneous,
  stationary_absorbing_phase_zero,
  transient_phase_selective,
};

// The reset-ROMR test provider declares exact finite predictive-phase rows.
// The authored shared-round model deliberately retains only its conservative
// sequential capability record, so exact C20--C23 integration routes rebind
// to this private C09 seam before C14 negotiation.  That keeps the provider's
// finite-row claim and the configured arrival law structurally identical.
[[nodiscard]] mwperf::ResolvedRequest c27_rebind_planning_temporal(
    const RequestFiles& files,
    const C27TemporalArrivalFixtureV1 fixture) {
  auto authored = c27_resolve_planning_request(files);
  REQUIRE(authored);
  auto law = [&]() -> mwperf::Result<mwperf::CompiledArrivalLaw> {
    switch (fixture) {
      case C27TemporalArrivalFixtureV1::stationary_homogeneous:
        return mwperf::testing::
            make_c09_time_homogeneous_correlated_fixture_law(
                authored.value().instance().queues());
      case C27TemporalArrivalFixtureV1::stationary_absorbing_phase_zero:
        return mwperf::testing::
            make_c09_absorbing_two_phase_time_homogeneous_fixture_law(
                authored.value().instance().queues(),
                mwperf::ExactRational::one(),
                mwperf::ExactRational::zero());
      case C27TemporalArrivalFixtureV1::transient_phase_selective:
        return mwperf::testing::
            make_c09_phase_selective_transient_fixture_law(
                authored.value().instance().queues());
    }
    return mwperf::testing::
        make_c09_phase_selective_transient_fixture_law(
            authored.value().instance().queues());
  }();
  INFO((law ? std::string{}
            : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  auto rebound = mwperf::testing::rebind_resolved_request_arrival_for_testing(
      authored.value(),
      std::make_shared<const mwperf::CompiledArrivalLaw>(
          std::move(law).value()));
  INFO((rebound ? std::string{}
                : rebound.error().code + ": " + rebound.error().message));
  REQUIRE(rebound);
  return std::move(rebound).value();
}

void check_c27_successful_metric(
    const mwperf::AnalysisBundle& bundle,
    const mwperf::MetricKindV1 expected_kind) {
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  REQUIRE(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* established =
      std::get_if<mwperf::EstablishedResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(established != nullptr);
  CHECK(established->header.kind == expected_kind);
  REQUIRE(bundle.certificates().size() == 5U);
  CHECK(std::ranges::all_of(
      bundle.certificates(),
      [](const mwperf::ResultCertificateV1& certificate) {
        return certificate.diagnostic_refs ==
               std::vector<std::string>{
                   "c27.v0.causal_admissibility"};
      }));
}

}  // namespace

TEST_CASE("C27 rejects a frozen plan that loses its homogeneous regime",
          "[c27][negative]") {
  const mwperf::ResolvedRequest resolved = resolved_iid_request(
      "c16.fixture.mwis.engineered", R"json({"resolution_level":2})json",
      3, 4);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);

  auto corrupted = plan.value();
  mwperf::testing::C27ExecutionPlanFixtureFactory::
      replace_homogeneous_selection_regime(corrupted);
  auto checked = mwperf::validate_execution_plan(corrupted);
  REQUIRE_FALSE(checked);
  CHECK(checked.error().code == "c27.plan_regime_mismatch");
}

TEST_CASE("C27 dormant C12 edge shares the execution optimizer ledger",
          "[c27][integration][c12]") {
  // analysis-v1 has no authored selector for F-C12-05, so execute_analysis
  // does not select this edge.  Exercise the conditional edge directly with
  // an explicit fixture horizon (distinct from run.slots) and publish no
  // metric claim.  Construction, ordinary backend, and C12 exact queries
  // must all consume one non-resetting execution-local ledger.
  const std::string selection =
      R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0},{"queue_id":"q2","value":0}],"controller_state":{},"arrival_state":{"kind":"shared_round_state","state":"h0"},"static_context":{},"surrogate_initial":{}}]}}})json";
  const std::string analysis = c27_planning_analysis(
      "c20.fixture.pair.romr-reset", R"json(["q0"])json",
      R"json([{"id":"transient-law","kind":"transient_backlog_law","parameters":{"horizons":[2]}}])json",
      R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
      "null", "128", "128", "128", "0", selection);
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis, "dormant-c12-ledger");
  auto resolved = c27_resolve_planning_request(files);
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_physical_law().has_value());

  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      resolved.value().instance());
  REQUIRE(optimizer);
  const auto observer = optimizer.value().ledger_observer();
  const auto dimension = mwperf::QueueDimensionToken::from_instance(
      resolved.value().instance());
  auto backlog = mwperf::Backlog::from_values(
      dimension,
      std::vector<mwperf::BigNat>(dimension.cardinality(),
                                  mwperf::BigNat{1U}));
  REQUIRE(backlog);
  auto target =
      mwperf::TargetIndex::from_instance(resolved.value().instance(), 0U);
  REQUIRE(target);
  auto direction = mwperf::NonnegativeIntegralDirection::from_values(
      dimension,
      std::vector<mwperf::BigNat>(dimension.cardinality(),
                                  mwperf::BigNat{1U}));
  REQUIRE(direction);

  auto exact = mwperf::detail::ConstructionExactQueryBindingAccess::bind(
      resolved.value().instance(),
      mwperf::BuildIdentityDigest(resolved.value().fingerprints().combined),
      optimizer.value(), mwperf::BigNat{3U});
  REQUIRE(exact);
  auto opportunity = exact.value().query_opportunity(
      exact.value().scope_token(), backlog.value(), target.value());
  REQUIRE(opportunity);
  CHECK(observer.snapshot().calls_reserved() == mwperf::BigNat{2U});
  auto capacity = exact.value().query_integral_capacity(
      exact.value().scope_token(), direction.value());
  REQUIRE(capacity);
  CHECK(observer.snapshot().calls_reserved() == mwperf::BigNat{3U});

  auto decision = mwperf::resolve_maxweight_schedule(
      resolved.value().instance(), backlog.value(),
      mwperf::TieContext::configured_priority(), optimizer.value());
  REQUIRE(decision);
  CHECK(observer.snapshot().calls_reserved() == mwperf::BigNat{4U});

  auto reference = mwperf::execute_reference_path(
      resolved.value().instance(), resolved.value().compiled_arrival(),
      *resolved.value().initial_physical_law(), mwperf::BigNat{2U},
      mwperf::MasterSeed{0xC2705U}, optimizer.value());
  INFO((reference ? std::string{}
                  : reference.error().code + ": " +
                        reference.error().message));
  REQUIRE(reference);
  CHECK(reference.value().edges().size() == 2U);
  CHECK(observer.snapshot().calls_reserved() == mwperf::BigNat{6U});
  CHECK(observer.snapshot().context_active());
}

TEST_CASE("C27 rejects an unsupported metric before provider execution",
          "[c27][negative]") {
  using namespace mwperf::testing::c16_fixture_detail;
  reset_side_effect_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.mwis.engineered", R"json(["q0"])json",
      R"json([{"id":"tail","kind":"stationary_backlog_tail","parameters":{"threshold":3}}])json",
      R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "unsupported-metric");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);
  auto plan = mwperf::build_execution_plan(resolved);
  REQUIRE_FALSE(plan);
  CHECK_FALSE(plan.error().code.empty());
  CHECK(construction_calls().load(std::memory_order_relaxed) == 0U);
  CHECK(materializer_calls().load(std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 enforces the ThreeBin singleton runtime target before preview",
          "[c27][negative]") {
  using namespace mwperf::testing::c16_fixture_detail;
  reset_side_effect_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.mwis.engineered", R"json(["q0","q1"])json",
      R"json([{"id":"joint","kind":"joint_backlog_covariance","parameters":{}}])json",
      R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json");
  const RequestFiles files = c27_planning_request(
      c27_planning_two_queue_model(), analysis, "three-bin-multi-target");
  auto resolved = c27_resolve_planning_request(files);
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code == "c27.three_bin_singleton_target_required");
  CHECK(preview_calls().load(std::memory_order_relaxed) == 0U);
  CHECK(construction_calls().load(std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 dependency sharing is deterministic and preserves authored order",
          "[c27][property]") {
  const std::string analysis = c27_planning_analysis(
      "c27.fixture.shared-throughput", R"json(["q0"])json",
      R"json([{"id":"throughput-a","kind":"stationary_throughput","parameters":{}},{"id":"throughput-b","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "dependency-order");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);

  auto first = mwperf::build_execution_plan(resolved);
  INFO((first ? std::string{}
              : first.error().code + ": " + first.error().message));
  REQUIRE(first);
  auto second = mwperf::build_execution_plan(resolved);
  INFO((second ? std::string{}
               : second.error().code + ": " + second.error().message));
  REQUIRE(second);
  REQUIRE(first.value().dependency_schedule().size() == 1U);
  REQUIRE(first.value().dependency_schedule().size() ==
          second.value().dependency_schedule().size());
  CHECK(std::equal(first.value().dependency_schedule().begin(),
                   first.value().dependency_schedule().end(),
                   second.value().dependency_schedule().begin()));
  const auto& group = first.value().dependency_schedule().front();
  CHECK(group.kind ==
        mwperf::SharedDependencyKindV1::c19_scalar_iid_stationary_summary);
  CHECK(group.identity.configured_arrival ==
        mwperf::arrival_law_binding(first.value().compiled_arrival_law()));
  CHECK(group.identity.descriptor_core_digest ==
        first.value().preview().core.core_digest);
  CHECK(group.identity.metric_kind ==
        mwperf::MetricKindV1::stationary_throughput);
  const auto* proof =
      std::get_if<mwperf::FrameworkScalarIdentityBackendPlanV1>(
          &group.identity.backend);
  REQUIRE(proof != nullptr);
  CHECK(proof->stationary_proof.backend ==
        mwperf::StationaryProofBackendV1::c19_scalar_iid_summary);
  CHECK(proof->stationary_proof.requires_exact_iid_law);
  CHECK(proof->stationary_proof.requires_proper_normalized_invariant);
  CHECK(group.authored_metric_indices == std::vector<std::size_t>{0U, 1U});
  REQUIRE(first.value().metric_plans().size() == 2U);
  CHECK(mwperf::metric_request_header(first.value().metric_plans()[0].request())
            .metric_id == "throughput-a");
  CHECK(mwperf::metric_request_header(first.value().metric_plans()[1].request())
            .metric_id == "throughput-b");
}

TEST_CASE("C27 unavailable results preserve per-metric causes atomically",
          "[c27][integration]") {
  const auto execute_shared = [](
      const std::string_view provider,
      const std::int64_t first_outcome_numerator = 3,
      const std::int64_t first_outcome_denominator = 4) {
    const std::string analysis = c27_planning_analysis(
        provider, R"json(["q0"])json",
        R"json([{"id":"throughput-a","kind":"stationary_throughput","parameters":{}},{"id":"throughput-b","kind":"stationary_throughput","parameters":{}}])json",
        R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json");
    const RequestFiles files = c27_planning_request(
        c27_shared_arrival_model(), analysis,
        std::string(provider) + "-unavailable-mapping");
    const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(
        files, first_outcome_numerator, first_outcome_denominator);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(mwperf::validate_execution_plan(plan.value()));
    return mwperf::execute_analysis(plan.value());
  };
  const auto diagnostic_for = [](
      const mwperf::AnalysisBundle& bundle,
      const std::string& id) -> const mwperf::ResultDiagnosticV1* {
    const auto found = std::ranges::find_if(
        bundle.diagnostics(), [&](const mwperf::ResultDiagnosticV1& item) {
          return item.diagnostic_id == id;
        });
    return found == bundle.diagnostics().end() ? nullptr : &*found;
  };

  SECTION("validated wire reasons retain typed clause and subject bindings") {
    const mwperf::AnalysisBundle bundle = execute_shared(
        "c27.fixture.shared-throughput-unavailable");
    CHECK(bundle.status() == mwperf::ResultStatusV1::unavailable);
    CHECK_FALSE(bundle.failure().has_value());
    REQUIRE(bundle.metrics().size() == 2U);

    const std::array<std::string_view, 2U> expected_codes{
        "c27.fixture.shared_unavailable.throughput_a",
        "c27.fixture.shared_unavailable.throughput_b"};
    const std::array<std::string_view, 2U> expected_kinds{
        "coefficient_unresolved", "required_evidence_unavailable"};
    for (std::size_t index = 0U; index < bundle.metrics().size(); ++index) {
      const auto* unavailable =
          std::get_if<mwperf::UnavailableResultMetricV1>(
              &bundle.metrics()[index]);
      REQUIRE(unavailable != nullptr);
      CHECK(unavailable->reason_code == expected_codes[index]);
      REQUIRE(unavailable->diagnostic_refs.size() == 1U);
      const mwperf::ResultDiagnosticV1* diagnostic =
          diagnostic_for(bundle, unavailable->diagnostic_refs.front());
      REQUIRE(diagnostic != nullptr);
      CHECK(diagnostic->code == expected_codes[index]);
      CHECK(std::ranges::find(
                diagnostic->assumptions,
                "provider_unavailable_reason_kind=" +
                    std::string(expected_kinds[index])) !=
            diagnostic->assumptions.end());
      CHECK(std::ranges::find(
                diagnostic->assumptions,
                "metric_clause_id.metric_id=throughput-" +
                    std::string(1U, static_cast<char>('a' + index))) !=
            diagnostic->assumptions.end());
      CHECK(std::ranges::find(
                diagnostic->assumptions,
                "metric_clause_id.authored_index=" +
                    std::to_string(index)) != diagnostic->assumptions.end());
    }
    const auto& first = std::get<mwperf::UnavailableResultMetricV1>(
        bundle.metrics().front());
    const mwperf::ResultDiagnosticV1* first_diagnostic =
        diagnostic_for(bundle, first.diagnostic_refs.front());
    REQUIRE(first_diagnostic != nullptr);
    CHECK(std::ranges::any_of(
        first_diagnostic->assumptions, [](const std::string& note) {
          return note.starts_with("subject.object_id=");
        }));
    CHECK(std::ranges::any_of(
        first_diagnostic->assumptions, [](const std::string& note) {
          return note.starts_with("subject.object_digest=");
        }));
  }

  SECTION("one backend cause suppresses every other staged metric") {
    const mwperf::AnalysisBundle bundle = execute_shared(
        "c27.fixture.shared-throughput-built", 1, 4);
    CHECK(bundle.status() == mwperf::ResultStatusV1::unavailable);
    CHECK_FALSE(bundle.failure().has_value());
    REQUIRE(bundle.metrics().size() == 2U);
    const auto* cause = std::get_if<mwperf::UnavailableResultMetricV1>(
        &bundle.metrics()[0]);
    const auto* suppressed = std::get_if<mwperf::UnavailableResultMetricV1>(
        &bundle.metrics()[1]);
    REQUIRE(cause != nullptr);
    REQUIRE(suppressed != nullptr);
    CHECK(cause->reason_code ==
          "c27.stationary_throughput_not_established");
    CHECK(suppressed->reason_code == "c27.atomic_result_suppressed");
    REQUIRE(cause->diagnostic_refs.size() == 1U);
    REQUIRE(suppressed->diagnostic_refs.size() == 2U);
    CHECK(suppressed->diagnostic_refs[1] == cause->diagnostic_refs.front());
    const mwperf::ResultDiagnosticV1* suppression =
        diagnostic_for(bundle, suppressed->diagnostic_refs.front());
    REQUIRE(suppression != nullptr);
    CHECK(suppression->code == "c27.atomic_result_suppressed");
    CHECK(std::ranges::find(
              suppression->assumptions,
              "trigger_metric_id=throughput-a") !=
          suppression->assumptions.end());
    CHECK_FALSE(std::ranges::any_of(
        bundle.metrics(), [](const mwperf::ResultMetricV1& metric) {
          return std::holds_alternative<mwperf::EstablishedResultMetricV1>(
              metric);
        }));
  }
}

TEST_CASE("C27 accounts Monte Carlo draws before provider preview",
          "[c27][negative]") {
  using namespace mwperf::testing::c16_fixture_detail;
  reset_side_effect_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.mwis.engineered", R"json(["q0"])json",
      R"json([{"id":"mc-a","kind":"stationary_throughput","parameters":{}},{"id":"mc-b","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"kind":"monte_carlo","parameters":{"replications":7,"confidence_level":0.95,"interval_method":"hoeffding"}})json",
      "13");
  const RequestFiles files = c27_planning_request(
      model_with_seed(R"json("seed":73)json"), analysis,
      "monte-carlo-draw-cap");
  auto resolved = c27_resolve_planning_request(files);
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code == "c27.generator_draw_budget_insufficient");
  CHECK(preview_calls().load(std::memory_order_relaxed) == 0U);
  CHECK(construction_calls().load(std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 rejects multiple direct metrics before provider preview",
          "[c27][negative]") {
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;
  matrix::reset_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.pair.direct-metric", R"json(["q0"])json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}},{"id":"empty","kind":"stationary_empty_probability","parameters":{}}])json",
      R"json({"kind":"direct","parameters":{}})json", "null", "null",
      "null");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "exact-direct-metric-cardinality");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);
  auto plan = mwperf::build_execution_plan(resolved);
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code ==
        "c27.direct_decoder_single_metric_required");
  constexpr std::size_t direct_index = 7U;
  CHECK(matrix::counters()[direct_index].parameter.load(
            std::memory_order_relaxed) == 0U);
  CHECK(matrix::counters()[direct_index].preview.load(
            std::memory_order_relaxed) == 0U);
  CHECK(matrix::counters()[direct_index].execute.load(
            std::memory_order_relaxed) == 0U);
  CHECK(matrix::counters()[direct_index].materialize.load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 rejects a direct route without an audited causal factor",
          "[c27][unit]") {
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;
  matrix::reset_counters();
  const std::string analysis = c27_planning_analysis(
      "c27.fixture.direct-without-factor", R"json(["q0"])json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"kind":"direct","parameters":{}})json", "null", "null",
      "null");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "exact-direct-route");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);
  auto plan = mwperf::build_execution_plan(resolved);
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code == "c27.direct_causal_factor_not_registered");
  constexpr std::size_t direct_index = 7U;
  CHECK(matrix::counters()[direct_index].execute.load(
            std::memory_order_relaxed) == 0U);
  CHECK(matrix::counters()[direct_index].materialize.load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 executes one direct value after its request-bound factor audit",
          "[c27][integration][c17]") {
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;
  matrix::reset_counters();
  matrix::reset_c17_direct_runtime_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.pair.direct-metric", R"json(["q0"])json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"kind":"direct","parameters":{}})json");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "exact-direct-route-success");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  REQUIRE(plan.value().metric_plans().size() == 1U);
  CHECK(plan.value().metric_plans().front().route_kind() ==
        mwperf::BackendRouteKindV1::exact_direct);

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  REQUIRE(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* established =
      std::get_if<mwperf::EstablishedResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(established != nullptr);
  const auto* value =
      std::get_if<mwperf::ResultCanonicalValueV1>(&established->value);
  REQUIRE(value != nullptr);
  const mwperf::CodecIdentityV1 expected_codec{
      "mwperf.c16.direct_metric_value", 1U};
  CHECK(value->codec == expected_codec);
  CHECK(value->canonical_value == matrix::c17_direct_half_bytes());

  const auto counters = matrix::c17_direct_runtime_counters();
  CHECK(counters->factor_cminus_enumerator.load(
            std::memory_order_relaxed) > 0U);
  CHECK(matrix::c17_direct_factor_row_calls()->load(
            std::memory_order_relaxed) == 0U);
  CHECK(counters->request_encoder.load(std::memory_order_relaxed) == 1U);
  CHECK(counters->decoder.load(std::memory_order_relaxed) == 1U);
  CHECK(counters->result_validator.load(std::memory_order_relaxed) == 1U);
  constexpr std::size_t direct_index = 7U;
  CHECK(matrix::counters()[direct_index].execute.load(
            std::memory_order_relaxed) == 1U);
  CHECK(matrix::counters()[direct_index].materialize.load(
            std::memory_order_relaxed) == 1U);

  const auto* optimizer_calls =
      execution_budget(bundle, "execution.shared_optimizer_calls");
  REQUIRE(optimizer_calls != nullptr);
  REQUIRE(optimizer_calls->granted.has_value());
  CHECK(*optimizer_calls->granted == mwperf::BigNat{128U});
  CHECK(optimizer_calls->used.is_zero());

  auto invented_call = bundle;
  REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
              increment_execution_budget(
                  invented_call, "execution.shared_optimizer_calls"));
  auto rejected_call =
      mwperf::assemble_result_artifact(resolved, plan.value(), invented_call);
  REQUIRE_FALSE(rejected_call);
  CHECK(rejected_call.error().code ==
        "c27.result_direct_optimizer_call_bound_exceeded");

  mwperf::testing::C27AnalysisBundleFixtureFactory::replace_with_failure(
      invented_call, mwperf::ResultFailureStageV1::v0_audit,
      "c17.direct_factor_optimizer_bound_exceeded");
  auto published_bound_failure =
      mwperf::assemble_result_artifact(resolved, plan.value(), invented_call);
  INFO((published_bound_failure
            ? std::string{}
            : published_bound_failure.error().code + ": " +
                  published_bound_failure.error().message));
  CHECK(published_bound_failure);

  auto invented_state = bundle;
  REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
              increment_execution_budget(
                  invented_state,
                  "execution.shared_optimizer_search_states"));
  auto rejected_state =
      mwperf::assemble_result_artifact(resolved, plan.value(), invented_state);
  REQUIRE_FALSE(rejected_state);
  CHECK(rejected_state.error().code ==
        "c27.result_direct_optimizer_search_state_bound_exceeded");
}

TEST_CASE("C27 rejects a stationary claim from one C24 conditional row",
          "[c27][negative]") {
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;
  matrix::reset_counters();
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.pair.temporal-continuation", R"json(["q0"])json",
      R"json([{"id":"c24-none","kind":"stationary_edge_reward","parameters":{"reward":"departure","moment_order":1}}])json",
      R"json({"kind":"monte_carlo","parameters":{"replications":7,"confidence_level":0.95,"interval_method":"none"}})json",
      "7", "null", "null");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis, "c24-authored-accuracy");
  auto resolved = c27_resolve_planning_request(files);
  REQUIRE(resolved);
  auto plan = mwperf::build_execution_plan(resolved.value());
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code ==
        "c27.conditional_reward_conditioning_law_unavailable");
  constexpr std::size_t temporal_index = 3U;
  CHECK(matrix::counters()[temporal_index].execute.load(
            std::memory_order_relaxed) == 0U);
  CHECK(matrix::counters()[temporal_index].materialize.load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C27 executes one exact-point C24 conditional service row",
          "[c27][integration]") {
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;
  matrix::reset_c27_conditional_reward_sample_calls();
  const std::string analysis = c27_planning_analysis(
      "c27.fixture.c24.conditioned-service", R"json(["q0"])json",
      R"json([{"id":"c27-conditioned","kind":"backlog_conditioned_service","parameters":{"levels":[1]}}])json",
      R"json({"kind":"monte_carlo","parameters":{"replications":7,"confidence_level":0.95,"interval_method":"none"}})json",
      "7", "null", "null");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis,
      "c24-conditioned-service-success");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_iid(files);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  REQUIRE(plan.value().metric_plans().size() == 1U);
  CHECK(plan.value().metric_plans().front().route_kind() ==
        mwperf::BackendRouteKindV1::conditional_reward_monte_carlo);

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  INFO((bundle.failure().has_value() ? bundle.failure()->code
                                     : std::string{}));
  REQUIRE(bundle.status() == mwperf::ResultStatusV1::success);
  CHECK_FALSE(bundle.failure().has_value());
  REQUIRE(bundle.metrics().size() == 1U);
  const auto* established =
      std::get_if<mwperf::EstablishedResultMetricV1>(
          &bundle.metrics().front());
  REQUIRE(established != nullptr);
  const auto* values =
      std::get_if<mwperf::ResultScalarVectorV1>(&established->value);
  REQUIRE(values != nullptr);
  REQUIRE(values->values.size() == 1U);
  CHECK(values->values.front().kind() ==
        mwperf::PortableScientificScalarKind::binary64);
  CHECK(values->values.front().binary64_value() == 1.0);
  CHECK(matrix::c27_conditional_reward_sample_calls().load(
            std::memory_order_relaxed) == 7U);

  const auto budget = std::ranges::find_if(
      bundle.backend_budget_usage(),
      [](const mwperf::ResultBudgetUsageV1& value) {
        return value.name ==
               "backend.c27-conditioned.conditional_generator_draws";
      });
  REQUIRE(budget != bundle.backend_budget_usage().end());
  CHECK(budget->applicability ==
        mwperf::ResultBudgetApplicabilityV1::applicable);
  REQUIRE(budget->granted.has_value());
  CHECK(*budget->granted == mwperf::BigNat{7U});
  CHECK(budget->used == mwperf::BigNat{7U});

  REQUIRE(bundle.replay_streams().size() == 7U);
  CHECK(std::ranges::all_of(
      bundle.replay_streams(),
      [](const mwperf::ResultReplayStreamV1& stream) {
        const auto* runtime =
            std::get_if<mwperf::ResultRuntimeReplayStreamV1>(&stream);
        return runtime != nullptr &&
               runtime->stage_tag == mwperf::StageTag::generic_sampling &&
               runtime->draws == mwperf::BigNat{1U};
      }));
}

TEST_CASE("C27 executes the registered finite C18 scalar identity route",
          "[c27][integration][c18]") {
  const std::string analysis = c27_planning_analysis(
      "c16.fixture.pair.stationary", R"json(["q0"])json",
      R"json([{"id":"throughput","kind":"stationary_throughput","parameters":{}}])json",
      R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
      "null", "4", "3", "128", "0");
  const RequestFiles files = c27_planning_request(
      c27_target_last_arrival_model(), analysis,
      "c18-scalar-success");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
      files,
      C27TemporalArrivalFixtureV1::stationary_absorbing_phase_zero);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(mwperf::validate_execution_plan(plan.value()));
  REQUIRE(plan.value().metric_plans().size() == 1U);
  CHECK(plan.value().metric_plans().front().route_kind() ==
        mwperf::BackendRouteKindV1::framework_scalar_identity);
  const auto* scalar =
      std::get_if<mwperf::FrameworkScalarIdentityBackendPlanV1>(
          &plan.value().metric_plans().front().backend());
  REQUIRE(scalar != nullptr);
  CHECK(scalar->stationary_proof.backend ==
        mwperf::StationaryProofBackendV1::c18_selected_finite_invariant);
  REQUIRE(plan.value().work_bounds().optimizer_calls.has_value());
  REQUIRE(plan.value().work_bounds().optimizer_search_states.has_value());
  CHECK(*plan.value().work_bounds().optimizer_calls == mwperf::BigNat{4U});
  CHECK(*plan.value().work_bounds().optimizer_search_states ==
        mwperf::BigNat{12U});

  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  check_c27_successful_metric(
      bundle, mwperf::MetricKindV1::stationary_throughput);
  const auto* calls =
      execution_budget(bundle, "execution.shared_optimizer_calls");
  const auto* states = execution_budget(
      bundle, "execution.shared_optimizer_search_states");
  REQUIRE(calls != nullptr);
  REQUIRE(states != nullptr);
  REQUIRE(calls->granted.has_value());
  REQUIRE(states->granted.has_value());
  CHECK(*calls->granted == mwperf::BigNat{4U});
  CHECK(calls->used.is_zero());
  CHECK(*states->granted == mwperf::BigNat{12U});
  CHECK(states->used.is_zero());
}

TEST_CASE("C27 producer modes preserve the metric law but not execution "
          "identity",
          "[c27][integration][identity]") {
  std::vector<std::pair<std::string_view, mwperf::ProducerModeV1>> providers{
      {"c16.fixture.flow.closed-form",
       mwperf::ProducerModeV1::inline_immediate},
      {"c16.fixture.flow.in-process",
       mwperf::ProducerModeV1::in_process_builder}};
#if defined(MWPERF_C16_FLOW_BUILDER_PATH)
  providers.emplace_back("c16.fixture.flow.local",
                         mwperf::ProducerModeV1::local_executable_builder);
#endif

  std::vector<mwperf::AnalysisBundle> bundles;
  bundles.reserve(providers.size());
  for (const auto& [provider, expected_mode] : providers) {
    CAPTURE(provider);
    const mwperf::ResolvedRequest resolved = resolved_iid_request(
        provider, R"json({"resolution_level":2})json", 3, 4);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(mwperf::validate_execution_plan(plan.value()));
    mwperf::AnalysisBundle bundle =
        mwperf::execute_analysis(plan.value());
    INFO((bundle.failure().has_value() ? bundle.failure()->code
                                       : std::string{}));
    REQUIRE(bundle.status() == mwperf::ResultStatusV1::success);
    CHECK(bundle.execution_identity().producer_mode == expected_mode);
    REQUIRE(bundle.execution_identity().request_identity.has_value());
    REQUIRE(bundle.execution_identity().payload_digest.has_value());
    REQUIRE(bundle.execution_identity().execution_seal_digest.has_value());
    REQUIRE(bundle.metrics().size() == 1U);
    const auto* search_states = execution_budget(
        bundle, "execution.shared_optimizer_search_states");
    REQUIRE(search_states != nullptr);
    REQUIRE(plan.value().work_bounds().optimizer_search_states.has_value());
    REQUIRE(search_states->granted.has_value());
    CHECK(*search_states->granted ==
          *plan.value().work_bounds().optimizer_search_states);
    CHECK(search_states->used <= *search_states->granted);
    CHECK(search_states->unit == "states");
    const auto* metric =
        std::get_if<mwperf::EstablishedResultMetricV1>(
            &bundle.metrics().front());
    REQUIRE(metric != nullptr);
    CHECK(metric->header.law_identity ==
          *bundle.execution_identity().execution_seal_digest);
    if (!bundles.empty()) {
      const auto* reference =
          std::get_if<mwperf::EstablishedResultMetricV1>(
              &bundles.front().metrics().front());
      REQUIRE(reference != nullptr);
      CHECK(metric->value == reference->value);
    }
    bundles.push_back(std::move(bundle));
  }

  for (std::size_t left = 0U; left < bundles.size(); ++left) {
    for (std::size_t right = left + 1U; right < bundles.size(); ++right) {
      const auto& lhs = bundles[left].execution_identity();
      const auto& rhs = bundles[right].execution_identity();
      CHECK(lhs.provider != rhs.provider);
      CHECK(lhs.request_identity != rhs.request_identity);
      CHECK(lhs.payload_digest != rhs.payload_digest);
      CHECK(lhs.execution_seal_digest != rhs.execution_seal_digest);
    }
  }
}

TEST_CASE("C27 executes registered C20 and C21 stationary temporal routes",
          "[c27][integration][c20][c21]") {
  const auto execute = [](const std::string_view metric,
                          const mwperf::BackendRouteKindV1 expected_route,
                          const mwperf::MetricKindV1 expected_kind,
                          const std::string_view stem,
                          const std::string& model,
                          const C27TemporalArrivalFixtureV1 fixture,
                          std::vector<std::uint8_t>
                              finite_domain_phase_selectors) {
    const std::string analysis = c27_planning_analysis(
        "c20.fixture.pair.romr-reset", R"json(["q0"])json", metric,
        R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
        "null", "null", "null", "128", "0");
    const RequestFiles files = c27_planning_request(model, analysis, stem);
    const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
        files, fixture);
    auto operations =
        mwperf::testing::c21::suspension_operation_override(1U, true, true);
    operations.finite_domain_phase_selectors =
        std::move(finite_domain_phase_selectors);
    mwperf::testing::c16_registered_pair_matrix::
        ScopedC17TemporalFixtureOverride scope(operations);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(mwperf::validate_execution_plan(plan.value()));
    REQUIRE(plan.value().metric_plans().size() == 1U);
    CHECK(plan.value().metric_plans().front().route_kind() ==
          expected_route);
    check_c27_successful_metric(mwperf::execute_analysis(plan.value()),
                                expected_kind);
  };

  SECTION("finite cylinder") {
    execute(
        R"json([{"id":"c21-persistence","kind":"service_persistence","parameters":{}}])json",
        mwperf::BackendRouteKindV1::finite_temporal_cylinder,
        mwperf::MetricKindV1::service_persistence,
        "c20-finite-cylinder-success", c27_shared_arrival_model(),
        C27TemporalArrivalFixtureV1::stationary_absorbing_phase_zero,
        {0U});
  }

  SECTION("stationary suspension") {
    execute(
        R"json([{"id":"c21-empty","kind":"stationary_empty_probability","parameters":{}}])json",
        mwperf::BackendRouteKindV1::stationary_invariant,
        mwperf::MetricKindV1::stationary_empty_probability,
        "c21-stationary-success", c27_target_last_arrival_model(),
        C27TemporalArrivalFixtureV1::stationary_homogeneous, {});
  }
}

TEST_CASE("C27 executes transient and stationary stopped C22 routes",
          "[c27][integration][c22]") {
  SECTION("transient backlog law") {
    const std::string selection =
        R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0},{"queue_id":"q2","value":0}],"controller_state":{},"arrival_state":{"kind":"shared_round_state","state":"h0"},"static_context":{},"surrogate_initial":{}}]}}})json";
    const std::string analysis = c27_planning_analysis(
        "c20.fixture.pair.romr-reset", R"json(["q0"])json",
        R"json([{"id":"c22-transient-law","kind":"transient_backlog_law","parameters":{"horizons":[3,0,1]}}])json",
        R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
        "null", "null", "null", "128", "0", selection);
    const RequestFiles files = c27_planning_request(
        c27_shared_arrival_model(), analysis, "c22-transient-success");
    const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
        files, C27TemporalArrivalFixtureV1::transient_phase_selective);
    auto operations = mwperf::testing::c22_transient::operation_override();
    mwperf::testing::c16_registered_pair_matrix::
        ScopedC17TemporalFixtureOverride scope(operations);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(plan.value().metric_plans().front().route_kind() ==
            mwperf::BackendRouteKindV1::finite_temporal_cylinder);
    const mwperf::AnalysisBundle bundle =
        mwperf::execute_analysis(plan.value());
    check_c27_successful_metric(
        bundle, mwperf::MetricKindV1::transient_backlog_law);
    const auto assert_budget = [&](const std::string_view suffix,
                                   const mwperf::BigNat& granted) {
      const auto row = std::ranges::find_if(
          bundle.backend_budget_usage(), [&](const auto& value) {
            return value.name ==
                   "backend.c22-transient-law." + std::string(suffix);
          });
      REQUIRE(row != bundle.backend_budget_usage().end());
      REQUIRE(row->granted.has_value());
      CHECK(*row->granted == granted);
      CHECK(row->used <= granted);
      CHECK(row->applicability ==
            mwperf::ResultBudgetApplicabilityV1::applicable);
    };
    assert_budget("stopped_states", mwperf::BigNat{128U});
    assert_budget("stopped_row_atoms", mwperf::BigNat{128U});

    REQUIRE(mwperf::assemble_result_artifact(
        resolved, plan.value(), bundle));
    auto missing_state = bundle;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                remove_backend_budget(
                    missing_state,
                    "backend.c22-transient-law.stopped_states"));
    auto rejected_missing = mwperf::assemble_result_artifact(
        resolved, plan.value(), missing_state);
    REQUIRE_FALSE(rejected_missing);
    CHECK(rejected_missing.error().code ==
          "c27.result_stopped_budget_missing");

    auto invented_iteration = bundle;
    mwperf::testing::C27AnalysisBundleFixtureFactory::append_backend_budget(
        invented_iteration,
        "backend.c22-transient-law.stopped_iterations",
        mwperf::BigNat{64U}, "iterations");
    auto rejected_iteration = mwperf::assemble_result_artifact(
        resolved, plan.value(), invented_iteration);
    REQUIRE_FALSE(rejected_iteration);
    CHECK(rejected_iteration.error().code ==
          "c27.result_backend_budget_unknown");
  }

  SECTION("transient first hit") {
    const std::string selection =
        R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0},{"queue_id":"q2","value":0}],"controller_state":{},"arrival_state":{"kind":"shared_round_state","state":"h0"},"static_context":{},"surrogate_initial":{}}]}}})json";
    const std::string analysis = c27_planning_analysis(
        "c20.fixture.pair.romr-reset", R"json(["q0"])json",
        R"json([{"id":"c22-first-hit","kind":"first_hit","parameters":{"set":{"kind":"at_or_above","level":1},"horizon":2,"include_mean":false}}])json",
        R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
        "null", "null", "null", "128", "0", selection);
    const RequestFiles files = c27_planning_request(
        c27_shared_arrival_model(), analysis,
        "c22-transient-stopped-success");
    const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
        files, C27TemporalArrivalFixtureV1::transient_phase_selective);
    auto operations = mwperf::testing::c22_transient::operation_override();
    mwperf::testing::c16_registered_pair_matrix::
        ScopedC17TemporalFixtureOverride scope(operations);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(plan.value().metric_plans().front().route_kind() ==
            mwperf::BackendRouteKindV1::residence_or_stopped_law);
    const mwperf::AnalysisBundle bundle =
        mwperf::execute_analysis(plan.value());
    check_c27_successful_metric(bundle, mwperf::MetricKindV1::first_hit);
    const auto assert_budget = [&](const std::string_view suffix,
                                   const mwperf::BigNat& granted) {
      const auto row = std::ranges::find_if(
          bundle.backend_budget_usage(), [&](const auto& value) {
            return value.name ==
                   "backend.c22-first-hit." + std::string(suffix);
          });
      REQUIRE(row != bundle.backend_budget_usage().end());
      REQUIRE(row->granted.has_value());
      CHECK(*row->granted == granted);
      CHECK(row->used <= granted);
      CHECK(row->applicability ==
            mwperf::ResultBudgetApplicabilityV1::applicable);
    };
    assert_budget("stopped_states", mwperf::BigNat{128U});
    assert_budget("stopped_row_atoms", mwperf::BigNat{128U});
    assert_budget("stopped_iterations", mwperf::BigNat{64U});

    REQUIRE(mwperf::assemble_result_artifact(
        resolved, plan.value(), bundle));
    auto missing_iterations = bundle;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                remove_backend_budget(
                    missing_iterations,
                    "backend.c22-first-hit.stopped_iterations"));
    auto rejected_missing = mwperf::assemble_result_artifact(
        resolved, plan.value(), missing_iterations);
    REQUIRE_FALSE(rejected_missing);
    CHECK(rejected_missing.error().code ==
          "c27.result_stopped_budget_missing");

    auto partial_terminal_group = bundle;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                remove_backend_budget(
                    partial_terminal_group,
                    "backend.c22-first-hit.stopped_iterations"));
    mwperf::testing::C27AnalysisBundleFixtureFactory::replace_with_failure(
        partial_terminal_group, mwperf::ResultFailureStageV1::backend,
        "c27.fixture.partial_stopped_budget_group");
    auto rejected_partial_terminal = mwperf::assemble_result_artifact(
        resolved, plan.value(), partial_terminal_group);
    REQUIRE_FALSE(rejected_partial_terminal);
    CHECK(rejected_partial_terminal.error().code ==
          "c27.result_stopped_budget_group_incomplete");
  }

  SECTION("stationary first hit") {
    const std::string analysis = c27_planning_analysis(
        "c20.fixture.pair.romr-reset", R"json(["q0"])json",
        R"json([{"id":"c21-hit","kind":"first_hit","parameters":{"set":{"kind":"equal","level":2},"horizon":4,"include_mean":false}}])json",
        R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
        "null", "null", "null", "128", "0");
    const RequestFiles files = c27_planning_request(
        c27_target_last_arrival_model(), analysis,
        "c22-stationary-stopped-success");
    const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
        files, C27TemporalArrivalFixtureV1::stationary_homogeneous);
    auto operations =
        mwperf::testing::c21::suspension_operation_override(1U, true, true);
    mwperf::testing::c16_registered_pair_matrix::
        ScopedC17TemporalFixtureOverride scope(operations);
    auto plan = mwperf::build_execution_plan(resolved);
    INFO((plan ? std::string{}
               : plan.error().code + ": " + plan.error().message));
    REQUIRE(plan);
    REQUIRE(plan.value().metric_plans().front().route_kind() ==
            mwperf::BackendRouteKindV1::residence_or_stopped_law);
    const mwperf::AnalysisBundle bundle =
        mwperf::execute_analysis(plan.value());
    check_c27_successful_metric(bundle, mwperf::MetricKindV1::first_hit);
    REQUIRE(mwperf::assemble_result_artifact(
        resolved, plan.value(), bundle));
    auto missing_iterations = bundle;
    REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
                remove_backend_budget(
                    missing_iterations,
                    "backend.c21-hit.stopped_iterations"));
    auto rejected_missing = mwperf::assemble_result_artifact(
        resolved, plan.value(), missing_iterations);
    REQUIRE_FALSE(rejected_missing);
    CHECK(rejected_missing.error().code ==
          "c27.result_stopped_budget_missing");
  }
}

TEST_CASE("C27 executes the registered scalar C23 FIFO route",
          "[c27][integration][c23]") {
  const std::string analysis = c27_planning_analysis(
      "c20.fixture.pair.romr-reset", R"json(["q0"])json",
      R"json([{"id":"c23-mean","kind":"fifo_delay","parameters":{"output":"moment","order":1}}])json",
      R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
      "null", "null", "null", "128", "0");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis, "c23-fifo-success");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
      files,
      C27TemporalArrivalFixtureV1::stationary_absorbing_phase_zero);
  auto operations =
      mwperf::testing::c21::suspension_operation_override(1U, true, true);
  operations.finite_domain_phase_selectors = {0U};
  mwperf::testing::c16_registered_pair_matrix::
      ScopedC17TemporalFixtureOverride scope(operations);
  auto plan = mwperf::build_execution_plan(resolved);
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  REQUIRE(plan.value().metric_plans().front().route_kind() ==
          mwperf::BackendRouteKindV1::palm_or_fifo_law);
  const mwperf::AnalysisBundle bundle =
      mwperf::execute_analysis(plan.value());
  check_c27_successful_metric(bundle, mwperf::MetricKindV1::fifo_delay);
  REQUIRE(mwperf::assemble_result_artifact(
      resolved, plan.value(), bundle));

  auto missing_group_state = bundle;
  REQUIRE(mwperf::testing::C27AnalysisBundleFixtureFactory::
              remove_backend_budget(
                  missing_group_state,
                  "backend.fifo_group.0.stopped_states"));
  auto rejected_missing = mwperf::assemble_result_artifact(
      resolved, plan.value(), missing_group_state);
  REQUIRE_FALSE(rejected_missing);
  CHECK(rejected_missing.error().code ==
        "c27.result_stopped_budget_missing");

  auto invented_group = bundle;
  mwperf::testing::C27AnalysisBundleFixtureFactory::append_backend_budget(
      invented_group, "backend.fifo_group.1.stopped_states",
      mwperf::BigNat{128U}, "states");
  auto rejected_group = mwperf::assemble_result_artifact(
      resolved, plan.value(), invented_group);
  REQUIRE_FALSE(rejected_group);
  CHECK(rejected_group.error().code ==
        "c27.result_backend_budget_unknown");
}

TEST_CASE("C27 requires dense stationary C20/C21 solves before execution",
          "[c27][negative]") {
  const std::string analysis = c27_planning_analysis(
      "c20.fixture.pair.romr-reset", R"json(["q0"])json",
      R"json([{"id":"c21-empty","kind":"stationary_empty_probability","parameters":{}}])json",
      R"json({"kind":"enumerated","parameters":{"linear_method":"sparse_iterative","max_iterations":64}})json",
      "null", "null", "null", "64", "0");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis, "c21-sparse-stationary-solve");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
      files, C27TemporalArrivalFixtureV1::stationary_homogeneous);
  auto plan = mwperf::build_execution_plan(resolved);
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code ==
        "c27.stationary_temporal_dense_solver_required");
}

TEST_CASE("C27 requires a transient stopped state cap before execution",
          "[c27][negative]") {
  const std::string analysis = c27_planning_analysis(
      "c20.fixture.pair.romr-reset", R"json(["q0"])json",
      R"json([{"id":"c22-first-hit","kind":"first_hit","parameters":{"set":{"kind":"at_or_above","level":1},"horizon":2,"include_mean":false}}])json",
      R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":64}})json",
      "null", "null", "null", "null", "null",
      R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0},{"queue_id":"q2","value":0}],"controller_state":{},"arrival_state":{"kind":"shared_round_state","state":"h0"},"static_context":{},"surrogate_initial":{}}]}}})json");
  const RequestFiles files = c27_planning_request(
      c27_shared_arrival_model(), analysis, "c22-stopped-state-cap");
  const mwperf::ResolvedRequest resolved = c27_rebind_planning_temporal(
      files, C27TemporalArrivalFixtureV1::transient_phase_selective);
  auto plan = mwperf::build_execution_plan(resolved);
  REQUIRE_FALSE(plan);
  CHECK(plan.error().code ==
        "c27.transient_stopped_state_budget_required");
}
