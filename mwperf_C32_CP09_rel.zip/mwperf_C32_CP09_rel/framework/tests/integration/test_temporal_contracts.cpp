#include <cmath>
#include <concepts>
#include <cstddef>
#include <numbers>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "c22/support/integration_temporal_contract_fixture.hpp"
#include "c22/support/transient_dispatch_fixture.hpp"
#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "mwperf/metrics/temporal.hpp"
#include "mwperf/stationary/suspension.hpp"
#include "mwperf/surrogate/kernel_access.hpp"

namespace {

namespace c21 = mwperf::testing::c21;
namespace c22 = mwperf::testing::c22_integration;
namespace c22_transient = mwperf::testing::c22_transient;

template <typename T>
concept C22CylinderSource = requires(const T& source,
                                     const mwperf::CylinderEvent& event,
                                     const mwperf::Horizon& horizon) {
  { mwperf::evaluate_finite_cylinder(source, event, horizon) } ->
      std::same_as<mwperf::Result<mwperf::MetricValue>>;
};

template <typename T>
concept C22KilledSource = requires(const T& source,
                                   const mwperf::SafeSet& safe,
                                   const mwperf::AbsorptionMarks& marks) {
  { mwperf::construct_killed_kernel(source, safe, marks) } ->
      std::same_as<mwperf::Result<mwperf::KilledKernel>>;
};

template <typename T>
concept C22TemporalStatisticSource = requires(
    const T& source, const mwperf::BinaryMark& mark,
    const mwperf::LagSpec& lags) {
  { mwperf::evaluate_runs_gaps_autocorrelation(source, mark, lags) } ->
      std::same_as<mwperf::Result<mwperf::MetricValue>>;
};

static_assert(C22CylinderSource<mwperf::AuditedCylinderLaw>);
static_assert(C22KilledSource<mwperf::AuditedTemporalKernel>);
static_assert(C22TemporalStatisticSource<mwperf::AuditedTemporalLaw>);
static_assert(!C22CylinderSource<mwperf::StationaryMarkedEdge>);
static_assert(!C22KilledSource<mwperf::StationaryMarkedEdge>);
static_assert(!C22TemporalStatisticSource<mwperf::StationaryMarkedEdge>);
static_assert(!C22CylinderSource<mwperf::StationaryTemporalLaw>);
static_assert(!C22KilledSource<mwperf::KernelAccess>);
static_assert(!C22KilledSource<mwperf::NormalizedConditionalSamplerAccess>);
static_assert(!C22TemporalStatisticSource<mwperf::AuditedSamplerDescriptor>);
static_assert(
    !C22CylinderSource<mwperf::TemporalOneSlotContinuationPlugV1>);
static_assert(
    !C22KilledSource<mwperf::TemporalOneSlotContinuationPlugV1>);
static_assert(!C22TemporalStatisticSource<
              mwperf::TemporalOneSlotContinuationPlugV1>);
static_assert(!C22CylinderSource<mwperf::StoppedPathPlugV1>);
static_assert(!C22KilledSource<mwperf::StoppedPathPlugV1>);
static_assert(!C22TemporalStatisticSource<mwperf::StoppedPathPlugV1>);
static_assert(!C22CylinderSource<mwperf::TemporalContinuationTableV1>);
static_assert(!C22KilledSource<mwperf::TemporalContinuationTableV1>);
static_assert(
    !C22TemporalStatisticSource<mwperf::TemporalContinuationTableV1>);
static_assert(!C22CylinderSource<mwperf::DirectMetricDecoderPlugV1>);
static_assert(!C22KilledSource<mwperf::DirectMetricDecoderPlugV1>);
static_assert(!C22TemporalStatisticSource<mwperf::DirectMetricDecoderPlugV1>);
static_assert(!std::default_initializable<mwperf::AuditedCylinderLaw>);
static_assert(!std::default_initializable<mwperf::AuditedTemporalKernel>);
static_assert(!std::default_initializable<mwperf::AuditedTemporalLaw>);
static_assert(!std::default_initializable<mwperf::InitialLaw>);
static_assert(!std::constructible_from<mwperf::BigNat, int>);
static_assert(!std::constructible_from<mwperf::BigNat, std::int64_t>);

struct C21C22Path final {
  c21::StationarySuspensionFixtureV1 fixture;
  mwperf::EventInvariantLaw event_law;
  mwperf::PositiveFiniteMean mean;
  mwperf::StationaryTemporalProjection projection;
};

[[nodiscard]] C21C22Path make_projection(
    const c21::ProjectionPlanFixtureV1 plan,
    const bool identity_variant = false) {
  auto fixture = c21::make_plan_fixture(plan, false, identity_variant);
  auto event_law = c22::require_value(mwperf::select_event_invariant_law(
      fixture.kernel, c21::configured_selection(fixture),
      c21::solver_policy(fixture)));
  auto mean = c22::require_value(
      mwperf::compute_mean_residence(event_law, fixture.provider));
  auto projection = c22::require_value(
      mwperf::build_stationary_temporal_projection(
          event_law, fixture.provider, mean));
  return {std::move(fixture), std::move(event_law), std::move(mean),
          std::move(projection)};
}

template <typename T>
[[nodiscard]] const T& require_available(
    const mwperf::StationaryProjectionSlotV1<T>& slot) {
  const auto* value = std::get_if<T>(&slot);
  REQUIRE(value != nullptr);
  return *value;
}

template <typename T>
[[nodiscard]] const T& require_optional(const std::optional<T>& value) {
  REQUIRE(value.has_value());
  return *value;
}

[[nodiscard]] mwperf::ExactRational one_edge_departure_mass(
    const mwperf::StationaryMarkedEdge& edge,
    const mwperf::DenseQueueIndex target) {
  mwperf::ExactRational result = mwperf::ExactRational::zero();
  for (const auto& atom : edge.atoms()) {
    if (atom.raw_edge.action().actual_departure.at(target)) {
      result = result + atom.exact_mass;
    }
  }
  return result;
}

[[nodiscard]] mwperf::DenseQueueIndex require_queue_index(
    const mwperf::QueueCatalog& catalog, const mwperf::QueueId& queue) {
  std::optional<mwperf::DenseQueueIndex> result;
  for (std::size_t ordinal = 0U; ordinal < catalog.entries().size();
       ++ordinal) {
    if (catalog.entries()[ordinal].id == queue) {
      result = c22::require_value(catalog.index_at(ordinal));
      break;
    }
  }
  REQUIRE(result.has_value());
  return *result;
}

[[nodiscard]] mwperf::ExactRational transient_backlog_mass(
    const mwperf::testing::C22MetricEnvelopeInspectionV1& metric,
    const mwperf::BigNat& horizon, const mwperf::BigNat& level) {
  REQUIRE(metric.indices.size() == 2U * metric.exact_values.size());
  mwperf::ExactRational result = mwperf::ExactRational::zero();
  for (std::size_t atom = 0U; atom < metric.exact_values.size(); ++atom) {
    if (metric.indices[2U * atom] == horizon &&
        metric.indices[2U * atom + 1U] == level) {
      result = result + metric.exact_values[atom];
    }
  }
  return result;
}

struct ConcatenatedWordCursorV1 final {
  std::size_t event_state_index;
  std::size_t word_index;
  std::size_t offset;
  mwperf::ExactRational exact_mass;
};

template <typename Matches>
[[nodiscard]] mwperf::ExactRational independent_concatenated_edge_pair(
    const mwperf::EventInvariantLaw& law,
    const mwperf::PositiveFiniteMean& mean,
    const std::size_t later_offset, Matches&& matches) {
  REQUIRE(mean.exact_value().has_value());
  const auto rows = law.embedded_kernel().rows();
  std::vector<ConcatenatedWordCursorV1> frontier;
  for (const auto& event_mass : law.masses()) {
    REQUIRE(event_mass.state_index < rows.size());
    const auto words = rows[event_mass.state_index].word_row.atoms();
    for (std::size_t word_index = 0U; word_index < words.size();
         ++word_index) {
      const auto& word = words[word_index];
      auto suspension_mass = mwperf::checked_divide(
          event_mass.exact_mass * word.exact_mass, *mean.exact_value());
      REQUIRE(suspension_mass);
      for (std::size_t offset = 0U; offset < word.word.edges().size();
           ++offset) {
        if (!matches(word.word.edges()[offset])) {
          continue;
        }
        frontier.push_back({event_mass.state_index, word_index, offset,
                            suspension_mass.value()});
      }
    }
  }

  for (std::size_t step = 0U; step < later_offset; ++step) {
    std::vector<ConcatenatedWordCursorV1> next;
    for (const auto& cursor : frontier) {
      const auto words = rows[cursor.event_state_index].word_row.atoms();
      REQUIRE(cursor.word_index < words.size());
      const auto& word = words[cursor.word_index].word;
      REQUIRE(cursor.offset < word.edges().size());
      if (cursor.offset + 1U < word.edges().size()) {
        next.push_back({cursor.event_state_index, cursor.word_index,
                        cursor.offset + 1U, cursor.exact_mass});
        continue;
      }
      // The complete word deliberately retains its absolute physical
      // boundary.  The embedded event chain instead indexes the audited
      // finite-phase, time-homogeneous representative at boundary zero.
      // Apply that fixture-specific quotient only to this independent event
      // index; never replace the raw endpoint kept by the word.
      mwperf::ReducedStateV1 event_index_state = word.event_endpoint();
      REQUIRE(event_index_state.canonical_value.size() == c21::kStateSize);
      event_index_state.canonical_value[c21::kBoundaryOffset] =
          std::byte{0x00};
      const auto endpoint = law.domain().index_of(event_index_state);
      REQUIRE(endpoint.has_value());
      REQUIRE(*endpoint < rows.size());
      const auto successor_words = rows[*endpoint].word_row.atoms();
      for (std::size_t word_index = 0U;
           word_index < successor_words.size(); ++word_index) {
        const auto& successor = successor_words[word_index];
        if (!successor.exact_mass.is_positive()) {
          continue;
        }
        next.push_back({*endpoint, word_index, 0U,
                        cursor.exact_mass * successor.exact_mass});
      }
    }
    frontier = std::move(next);
  }

  mwperf::ExactRational result = mwperf::ExactRational::zero();
  for (const auto& cursor : frontier) {
    const auto words = rows[cursor.event_state_index].word_row.atoms();
    REQUIRE(cursor.word_index < words.size());
    const auto& edges = words[cursor.word_index].word.edges();
    REQUIRE(cursor.offset < edges.size());
    if (matches(edges[cursor.offset])) {
      result = result + cursor.exact_mass;
    }
  }
  return result;
}

[[nodiscard]] bool has_completed_age_mark(
    const mwperf::CompletedReducedEdge& edge, const std::uint8_t age) {
  for (const mwperf::CausalMarkV1& mark : edge.marks()) {
    if (mark.mark.mark ==
            mwperf::testing::c20_reset_audited::raw_age_mark() &&
        mark.mark.value.codec ==
            mwperf::testing::c20_reset_audited::kAgeCodec &&
        mark.mark.value.canonical_value.size() == 1U &&
        std::to_integer<std::uint8_t>(
            mark.mark.value.canonical_value.front()) == age) {
      return true;
    }
  }
  return false;
}

}  // namespace

TEST_CASE("C22 evaluates a real C21 cylinder across residence boundaries",
          "[c22][integration][c21][cylinder]") {
  const auto path =
      make_projection(c21::ProjectionPlanFixtureV1::audited_temporal_law);
  const auto& cylinder = require_available(path.projection.cylinder_law());

  // EdgeMarkAt(6) requires seven completed physical slots.  Every retained
  // C21 residence is at most three slots, so this necessarily traverses at
  // least two event boundaries.  StateAt(0) is predecision and requires no
  // extra transition.  The latent chain, not the stationary edge image,
  // performs the propagation.
  const mwperf::CylinderEvent event{{
      mwperf::StateAtV1{mwperf::BigNat{0U},
                        mwperf::AnyStatePredicateV1{}},
      mwperf::EdgeMarkAtV1{
          mwperf::BigNat{0U},
          mwperf::ExactRuntimeMarkPredicateV1{
              mwperf::testing::c20_reset_audited::raw_age_mark(),
              mwperf::testing::c20_reset_audited::kAgeCodec,
              {std::byte{0x01}}}},
      mwperf::EdgeMarkAtV1{
          mwperf::BigNat{6U},
          mwperf::ExactRuntimeMarkPredicateV1{
              mwperf::testing::c20_reset_audited::raw_age_mark(),
              mwperf::testing::c20_reset_audited::kAgeCodec,
              {std::byte{0x01}}}},
  }};
  auto result = c22::require_value(
      mwperf::evaluate_finite_cylinder(cylinder, event,
                                       mwperf::BigNat{7U}));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(result));
  CHECK(decoded.kind == "finite_cylinder_probability");
  REQUIRE(decoded.exact_values.size() == 1U);
  const mwperf::ExactRational oracle =
      independent_concatenated_edge_pair(
          path.event_law, path.mean, 6U,
          [](const mwperf::CompletedReducedEdge& edge) {
            return has_completed_age_mark(edge, 1U);
          });
  CHECK(oracle == c21::rational(1, 2));
  CHECK(oracle.is_positive());
  CHECK(oracle < mwperf::ExactRational::one());
  CHECK(decoded.exact_values.front() == oracle);
  CHECK(decoded.completed_steps == 7U);
  CHECK(decoded.source_fingerprint == cylinder.source_fingerprint());
  CHECK(cylinder.source_kind() ==
        mwperf::AuditedTemporalSourceKindV1::stationary_projection);
}

TEST_CASE("C22 uses temporal continuation while matching C21 one-edge mass",
          "[c22][integration][c21][temporal-law]") {
  const auto path =
      make_projection(c21::ProjectionPlanFixtureV1::audited_temporal_law);
  const auto& temporal =
      require_available(path.projection.audited_temporal_law());
  const mwperf::BinaryMark departure{
      mwperf::BinaryMarkKindV1::target_departure, 0U, std::nullopt};
  const mwperf::LagSpec lags{
      mwperf::TemporalStatisticKindV1::autocovariance,
      {mwperf::BigNat{6U}},
      std::nullopt,
      std::nullopt,
      {}};

  const auto metric = c22::require_value(
      mwperf::evaluate_runs_gaps_autocorrelation(temporal, departure,
                                                 lags));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));
  REQUIRE(decoded.exact_values.size() == 1U);
  CHECK(decoded.completed_steps == 7U);

  REQUIRE(path.fixture.temporal.ordered_targets.size() == 1U);
  const auto target = require_queue_index(
      path.fixture.temporal.instance.queues(),
      path.fixture.temporal.ordered_targets.front());
  const mwperf::ExactRational lambda =
      one_edge_departure_mass(path.projection.marked_edge(), target);
  const mwperf::ExactRational lag_six_joint =
      independent_concatenated_edge_pair(
          path.event_law, path.mean, 6U,
          [target](const mwperf::CompletedReducedEdge& edge) {
            return edge.action().actual_departure.at(target);
          });
  CHECK(decoded.exact_values.front() ==
        lag_six_joint - lambda * lambda);
  CHECK(decoded.source_fingerprint == temporal.source_fingerprint());
  CHECK(temporal.projection_fingerprint() == path.projection.fingerprint());
}

TEST_CASE("C22 authorizes the exact C21 state-run predicate and both state "
          "offsets",
          "[c22][integration][c21][temporal-law][run]") {
  const auto path =
      make_projection(c21::ProjectionPlanFixtureV1::mean_binary_run);
  const auto raw_row =
      mwperf::audited_row_provider(path.fixture.temporal.framework);
  REQUIRE_FALSE(raw_row);
  CHECK(raw_row.error().code == "c17.audited_row_unavailable");
  const auto raw_slot =
      mwperf::audited_slot_executor(path.fixture.temporal.framework);
  REQUIRE_FALSE(raw_slot);
  CHECK(raw_slot.error().code == "c17.audited_slot_unavailable");
  const auto& temporal =
      require_available(path.projection.audited_temporal_law());
  const mwperf::BinaryMark busy{
      mwperf::BinaryMarkKindV1::state_predicate,
      0U,
      mwperf::BinaryStatePredicateV1{
          0U, mwperf::BasicBinaryPredicateV1::busy}};
  const mwperf::LagSpec mean_run{
      mwperf::TemporalStatisticKindV1::mean_binary_run,
      {},
      std::nullopt,
      std::nullopt,
      {}};

  // Backlog is one throughout this fixture, so the accepted busy predicate
  // is the all-one invariant process.  Reaching the zero-start diagnostic
  // proves the retained state budget admitted both offsets 0 and 1; the old
  // C21 bug failed earlier as beyond-budget.
  const auto no_start = mwperf::evaluate_runs_gaps_autocorrelation(
      temporal, busy, mean_run);
  REQUIRE_FALSE(no_start);
  CHECK(no_start.error().code == "c22.zero_run_start_intensity");

  const mwperf::BinaryMark unauthorized_exact_state{
      mwperf::BinaryMarkKindV1::state_predicate,
      0U,
      mwperf::ExactStatePredicateV1{path.fixture.class_b}};
  const auto rejected = mwperf::evaluate_runs_gaps_autocorrelation(
      temporal, unauthorized_exact_state, mean_run);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c22.temporal_statistic_not_authorized_by_accepted_contract");
}

TEST_CASE("C22 service spectrum stops exactly at its authored truncation lag",
          "[c22][integration][spectrum][finite-cylinder]") {
  const auto source = c22::iid_departure_source(
      "c22.integration.spectrum-boundary", 3U);
  REQUIRE(source.law.has_value());
  const mwperf::BinaryMark departure{
      mwperf::BinaryMarkKindV1::target_departure, 0U, std::nullopt};
  const mwperf::LagSpec exact_boundary{
      mwperf::TemporalStatisticKindV1::service_spectrum,
      {},
      std::nullopt,
      mwperf::BigNat{3U},
      {mwperf::ExactRational::zero(), c22::rational(1, 2)}};
  const auto metric = c22::require_value(
      mwperf::evaluate_runs_gaps_autocorrelation(*source.law, departure,
                                                 exact_boundary));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));
  CHECK(decoded.kind ==
        "rectangularly_truncated_covariance_fourier_sum");
  CHECK(decoded.rectangular_truncation);
  CHECK(decoded.angular_radians);
  CHECK(decoded.completed_steps == 4U);
  REQUIRE(decoded.exact_values.size() == 4U);
  CHECK(decoded.exact_values.front() == c22::rational(1, 4));
  for (std::size_t lag = 1U; lag < decoded.exact_values.size(); ++lag) {
    CHECK(decoded.exact_values[lag].is_zero());
  }
  CHECK(decoded.numerical_values.size() == 2U);
  CHECK(decoded.transcendental_error_bound > 0.0L);
  CHECK_FALSE(decoded.authored_absolute_tolerance.has_value());
  CHECK(decoded.exact_probability_kernel_error.is_zero());
  CHECK(decoded.conservative_transcendental_enclosure_radius ==
        decoded.transcendental_error_bound);
  CHECK(decoded.transcendental_enclosure_is_whole_range);
  const long double expected =
      1.0L / (8.0L * std::numbers::pi_v<long double>);
  for (const long double actual : decoded.numerical_values) {
    CHECK(std::fabs(actual - expected) <=
          4.0L * decoded.transcendental_error_bound);
  }

  mwperf::LagSpec beyond = exact_boundary;
  beyond.truncation_lag = mwperf::BigNat{4U};
  const auto rejected = mwperf::evaluate_runs_gaps_autocorrelation(
      *source.law, departure, beyond);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c22.service_spectrum_beyond_temporal_budget");
}

TEST_CASE("C22 transient dispatch retains predictive phase and authored horizon",
          "[c22][integration][transient][cylinder]") {
  const auto target_arrival = c22_transient::backlog_case(
      c22_transient::PredictivePhaseV1::target_arrival_then_quiet);
  const auto other_queue = c22_transient::backlog_case(
      c22_transient::PredictivePhaseV1::other_queue_only);

  const auto target_value = c22::require_value(
      mwperf::evaluate_transient_metric(
          target_arrival.temporal.framework, target_arrival.initial_law,
          target_arrival.request));
  const auto other_value = c22::require_value(
      mwperf::evaluate_transient_metric(
          other_queue.temporal.framework, other_queue.initial_law,
          other_queue.request));
  const auto accounting = c22::require_value(
      mwperf::detail::evaluate_transient_metric_with_budget(
          target_arrival.temporal.framework, target_arrival.initial_law,
          target_arrival.request));
  CHECK(accounting.actual_maximum_row_atoms == 1U);
  CHECK(accounting.actual_maximum_row_atoms <=
        accounting.budget.actual_row_atom_count);
  REQUIRE(accounting.budget.maximum_row_atoms.has_value());
  CHECK(accounting.actual_maximum_row_atoms <=
        *accounting.budget.maximum_row_atoms);
  const auto target = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(target_value));
  const auto other = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(other_value));

  CHECK(target.kind == "transient_backlog_law");
  CHECK(other.kind == "transient_backlog_law");
  CHECK(target.completed_steps == 3U);
  CHECK(other.completed_steps == 3U);
  CHECK(target.temporal_budget.actual_state_count > 0U);
  CHECK(target.temporal_budget.actual_row_atom_count > 0U);
  CHECK(target.temporal_budget.requested_horizon == 3U);
  CHECK(target.temporal_budget.authorized_maximum_state_offset == 3U);
  REQUIRE(target.temporal_budget.authorized_maximum_edge_offset.has_value());
  CHECK(*target.temporal_budget.authorized_maximum_edge_offset == 2U);
  REQUIRE(target.temporal_budget.maximum_states.has_value());
  CHECK(*target.temporal_budget.maximum_states == 64U);
  REQUIRE(target.temporal_budget.maximum_row_atoms.has_value());
  CHECK(*target.temporal_budget.maximum_row_atoms == 64U);
  CHECK(target.temporal_budget.solver_iterations == 0U);
  CHECK_FALSE(target.temporal_budget.budget_stop);
  // The model fixture has run.slots=2 and warmup_slots=1.  The authored
  // analysis horizon is three, proving neither simulation field was reused
  // as C22's mathematical horizon.
  REQUIRE(target.indices.size() >= 2U);
  REQUIRE(other.indices.size() >= 2U);
  CHECK(target.indices.front() == mwperf::BigNat{3U});
  CHECK(other.indices.front() == mwperf::BigNat{3U});
  CHECK(transient_backlog_mass(target, mwperf::BigNat{0U},
                               mwperf::BigNat{0U}) ==
        mwperf::ExactRational::one());
  CHECK(transient_backlog_mass(other, mwperf::BigNat{0U},
                               mwperf::BigNat{0U}) ==
        mwperf::ExactRational::one());
  CHECK(transient_backlog_mass(target, mwperf::BigNat{1U},
                               mwperf::BigNat{1U}) ==
        mwperf::ExactRational::one());
  CHECK(transient_backlog_mass(other, mwperf::BigNat{1U},
                               mwperf::BigNat{0U}) ==
        mwperf::ExactRational::one());
  CHECK((target.exact_values != other.exact_values ||
         target.indices != other.indices));
  CHECK(target.source_fingerprint != other.source_fingerprint);
}

TEST_CASE("C22 transient clockful successors retain the audited event quotient",
          "[c22][integration][transient][clock]") {
  const auto source = c22_transient::backlog_case(
      c22_transient::PredictivePhaseV1::target_arrival_then_quiet);
  auto provider = mwperf::audited_residence_provider(source.temporal.framework);
  REQUIRE(provider);
  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), source.temporal.initial_state,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(row);
  REQUIRE_FALSE(row.value().atoms().empty());
  for (const auto& atom : row.value().atoms()) {
    const auto& endpoint = atom.word.event_endpoint();
    REQUIRE(endpoint.canonical_value.size() == c22_transient::kStateSize);
    CHECK(std::to_integer<std::uint8_t>(
              endpoint.canonical_value[c22_transient::kBoundaryOffset]) ==
          1U);
  }

  auto domain =
      mwperf::FiniteEventStateDomain::from_audited_provider(provider.value());
  REQUIRE(domain);
  REQUIRE_FALSE(domain.value().states().empty());
  for (const auto& representative : domain.value().states()) {
    REQUIRE(representative.canonical_value.size() ==
            c22_transient::kStateSize);
    CHECK(std::to_integer<std::uint8_t>(
              representative.canonical_value[
                  c22_transient::kBoundaryOffset]) == 0U);
  }
}

TEST_CASE("C22 transient stopped dispatch uses the killed evaluator",
          "[c22][integration][transient][stopped]") {
  const auto stopped_case = c22_transient::first_hit_case();
  const auto metric = c22::require_value(
      mwperf::evaluate_transient_metric(
          stopped_case.temporal.framework, stopped_case.initial_law,
          stopped_case.request));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));

  CHECK(decoded.kind == "transient_first_hit");
  CHECK(decoded.completed_steps == 2U);
  REQUIRE(decoded.exact_values.size() == 6U);
  REQUIRE(decoded.indices.size() == 5U);
  CHECK(decoded.exact_values[0U] == mwperf::ExactRational::one());
  CHECK(decoded.exact_values[1U].is_zero());
  CHECK(decoded.exact_values[2U].is_zero());
  CHECK(decoded.exact_values[3U] == mwperf::ExactRational::one());
  CHECK(decoded.exact_values[4U].is_zero());
  CHECK(decoded.exact_values[5U].is_zero());
  CHECK(decoded.indices[0U] == mwperf::BigNat{0U});
  CHECK(decoded.indices[1U] == mwperf::BigNat{1U});
  CHECK(decoded.indices[2U] == mwperf::BigNat{2U});
  CHECK(decoded.indices[3U] == mwperf::BigNat{1U});
  CHECK(decoded.indices[4U] == mwperf::BigNat{2U});
  REQUIRE(decoded.stopped_metric.has_value());
  const auto& stopped = *decoded.stopped_metric;
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::nondefective);
  CHECK(stopped.exact_defect_probability.is_zero());
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::not_established);
  CHECK(stopped.budget.requested_horizon == 2U);
  CHECK(stopped.budget.state_count == 1U);
  CHECK(stopped.budget.row_atom_count == 1U);
  CHECK(stopped.budget.iterations > 0U);
  CHECK_FALSE(stopped.budget.budget_stop);
  REQUIRE(stopped.typed_exit_defect_solve_diagnostics.has_value());
  CHECK(stopped.typed_exit_defect_solve_diagnostics->status ==
        mwperf::StoppedSolveStatusV1::established);
  CHECK_FALSE(stopped.potential_solve_diagnostics.has_value());
  REQUIRE(decoded.exact_killed_row_balance_residuals.size() == 1U);
  CHECK(decoded.exact_killed_row_balance_residuals.front().is_zero());
}

TEST_CASE("C22 transient threshold excursion returns through its killed route",
          "[c22][integration][transient][threshold-return]") {
  const auto threshold_case = c22_transient::threshold_return_case();
  const auto metric = c22::require_value(
      mwperf::evaluate_transient_metric(
          threshold_case.temporal.framework, threshold_case.initial_law,
          threshold_case.request));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));

  CHECK(decoded.kind == "transient_threshold_excursion");
  CHECK(decoded.completed_steps == 2U);
  REQUIRE(decoded.stopped_metric.has_value());
  const auto& stopped = *decoded.stopped_metric;
  REQUIRE(stopped.survival_tails.size() == 3U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[1U].exact_probability.is_zero());
  CHECK(stopped.survival_tails[2U].exact_probability.is_zero());
  REQUIRE(stopped.absorption_masses.size() == 2U);
  CHECK(stopped.absorption_masses[0U].type_id == "return");
  CHECK(stopped.absorption_masses[0U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.absorption_masses[1U].exact_probability.is_zero());
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::nondefective);
  CHECK(stopped.exact_defect_probability.is_zero());
}

TEST_CASE("C22 transient dispatch maps a nonfirst physical target exactly",
          "[c22][integration][transient][target-order]") {
  const auto target_case = c22_transient::nonfirst_target_case();
  const auto metric = c22::require_value(
      mwperf::evaluate_transient_metric(
          target_case.temporal.framework, target_case.initial_law,
          target_case.request));
  const auto decoded = c22::require_value(
      mwperf::testing::C22FixtureAccess::decode_metric_value(metric));

  CHECK(decoded.kind == "transient_first_hit");
  REQUIRE(decoded.stopped_metric.has_value());
  const auto& stopped = *decoded.stopped_metric;
  REQUIRE(stopped.survival_tails.size() == 3U);
  CHECK(stopped.survival_tails[0U].exact_probability ==
        mwperf::ExactRational::one());
  // q0 is the second physical queue in this fixture. Phase h0 first emits to
  // physical q1, so selected q0 remains safe until the following h1 emission.
  CHECK(stopped.survival_tails[1U].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.survival_tails[2U].exact_probability.is_zero());
  REQUIRE(stopped.absorption_masses.size() == 2U);
  CHECK(stopped.absorption_masses[0U].exact_probability.is_zero());
  CHECK(stopped.absorption_masses[1U].exact_probability ==
        mwperf::ExactRational::one());
}

TEST_CASE("C22 transient dispatch rejects omitted and foreign predictive phase",
          "[c22][integration][transient][negative]") {
  CHECK(c22_transient::omitted_phase_error_code() ==
        "analysis.missing_key");

  const auto first = c22_transient::backlog_case(
      c22_transient::PredictivePhaseV1::target_arrival_then_quiet);
  const auto foreign = c22_transient::backlog_case(
      c22_transient::PredictivePhaseV1::other_queue_only);
  const auto foreign_entrance = mwperf::evaluate_transient_metric(
      first.temporal.framework, foreign.initial_law, first.request);
  REQUIRE_FALSE(foreign_entrance);
  CHECK(foreign_entrance.error().code ==
        "c22.transient_initial_law_v0_seal_mismatch");

  const auto foreign_request = mwperf::evaluate_transient_metric(
      first.temporal.framework, first.initial_law, foreign.request);
  REQUIRE_FALSE(foreign_request);
  CHECK(foreign_request.error().code ==
        "c22.transient_request_requirement_mismatch");
}

TEST_CASE("C22 rejects a negative authored horizon before temporal dispatch",
          "[c22][integration][transient][horizon][negative]") {
  CHECK(c22_transient::negative_horizon_error_code() ==
        "integer_negative");
}

TEST_CASE("C22 never relabels a state-budget cutoff as a physical hit",
          "[c22][integration][transient][budget][negative]") {
  const auto cutoff = c22_transient::cutoff_budget_case();
  const auto rejected = mwperf::evaluate_transient_metric(
      cutoff.temporal.framework, cutoff.initial_law, cutoff.request);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c22.transient_state_budget_exhausted");
}

TEST_CASE("C22 sampler-only transient request never probes a C24 adapter",
          "[c22][integration][transient][sampler][negative]") {
  const c22_transient::C22SamplingAdapterPoisonSpy poison;
  poison.reset();
  // C24's registered sampler clause now passes preview; the fixture's cold
  // materializer sentinel remains the expected boundary, and the poison spy
  // proves that no deployed sampler callback is executed.
  CHECK(c22_transient::sampler_only_error_code(poison) ==
        "c16.fixture.registered_pair_materializer_reached");
  CHECK(poison.calls() == 0U);
}

TEST_CASE("C22 consumes only a matched C21 stationary kernel and entrance",
          "[c22][integration][c21][stopped][binding]") {
  const auto first =
      make_projection(c21::ProjectionPlanFixtureV1::stationary_stopped);
  const auto foreign = make_projection(
      c21::ProjectionPlanFixtureV1::stationary_stopped, true);
  const auto& kernel_view =
      require_available(first.projection.temporal_kernel());
  const auto& entrance = require_available(first.projection.initial_law());
  const auto& foreign_entrance =
      require_available(foreign.projection.initial_law());

  const auto killed = c22::require_value(mwperf::construct_killed_kernel(
      kernel_view, mwperf::SafeSet{mwperf::AnyStatePredicateV1{}},
      mwperf::AbsorptionMarks{}));
  const mwperf::HorizonSpec horizon{mwperf::BigNat{3U}, false, true};
  const auto stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          killed, entrance, horizon, c21::solver_policy(first.fixture)));
  REQUIRE(stopped.survival_tails.size() == 4U);
  for (const auto& tail : stopped.survival_tails) {
    CHECK(tail.exact_probability == mwperf::ExactRational::one());
  }
  CHECK(stopped.exact_defect_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::defective);
  CHECK(stopped.initial_law_kind == mwperf::InitialLawKindV1::stationary);

  const auto cross_pair = mwperf::evaluate_hit_survival_absorption(
      killed, foreign_entrance, horizon,
      c21::solver_policy(first.fixture));
  REQUIRE_FALSE(cross_pair);
  CHECK(cross_pair.error().code ==
        "c22.killed_kernel_initial_law_binding_mismatch");
}

TEST_CASE("C22 exhausts synthetic event-Palm and passive FIFO alternatives",
          "[c22][integration][closed-carriers][binding]") {
  const auto event_palm = c22::one_step_exit_source(
      mwperf::AuditedTemporalSourceKindV1::stationary_projection,
      mwperf::InitialLawKindV1::event_palm, "c22.integration.event-palm");
  const auto fifo = c22::one_step_exit_source(
      mwperf::AuditedTemporalSourceKindV1::passive_fifo_tag,
      mwperf::InitialLawKindV1::fifo_tag, "c22.integration.fifo-tag");
  REQUIRE(event_palm.kernel.has_value());
  REQUIRE(fifo.kernel.has_value());
  CHECK_FALSE(event_palm.cylinder.has_value());
  CHECK_FALSE(event_palm.law.has_value());
  CHECK_FALSE(fifo.cylinder.has_value());
  CHECK_FALSE(fifo.law.has_value());

  const auto event_killed = c22::require_value(
      mwperf::construct_killed_kernel(*event_palm.kernel,
                                      c22::safe_state_zero(),
                                      c22::hit_state_one()));
  const auto fifo_killed = c22::require_value(
      mwperf::construct_killed_kernel(*fifo.kernel, c22::safe_state_zero(),
                                      c22::hit_state_one()));
  CHECK(event_killed.state_count() == 1U);
  CHECK(event_killed.row_diagnostics().size() == 1U);
  CHECK(fifo_killed.state_count() == 1U);
  const mwperf::HorizonSpec horizon{mwperf::BigNat{2U}, false, true};

  const auto event_stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          event_killed, require_optional(event_palm.entrance), horizon,
          c22::solver_policy("c22.integration.event-palm")));
  CHECK(event_stopped.initial_law_kind ==
        mwperf::InitialLawKindV1::event_palm);
  REQUIRE(event_stopped.survival_tails.size() == 3U);
  CHECK(event_stopped.survival_tails[0].exact_probability ==
        mwperf::ExactRational::one());
  CHECK(event_stopped.survival_tails[1].exact_probability ==
        mwperf::ExactRational::zero());
  REQUIRE(event_stopped.absorption_masses.size() == 2U);
  CHECK(event_stopped.absorption_masses[0].exact_probability ==
        mwperf::ExactRational::one());

  const auto fifo_stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          fifo_killed, require_optional(fifo.entrance), horizon,
          c22::solver_policy("c22.integration.fifo-tag")));
  CHECK(fifo_stopped.initial_law_kind ==
        mwperf::InitialLawKindV1::fifo_tag);
  CHECK(fifo_stopped.survival_tails[1].exact_probability ==
        mwperf::ExactRational::zero());

  const auto event_with_fifo_entrance =
      mwperf::evaluate_hit_survival_absorption(
          event_killed, require_optional(fifo.entrance), horizon,
          c22::solver_policy("c22.integration.event-palm"));
  const auto fifo_with_event_entrance =
      mwperf::evaluate_hit_survival_absorption(
          fifo_killed, require_optional(event_palm.entrance), horizon,
          c22::solver_policy("c22.integration.fifo-tag"));
  REQUIRE_FALSE(event_with_fifo_entrance);
  REQUIRE_FALSE(fifo_with_event_entrance);
  CHECK(event_with_fifo_entrance.error().code ==
        "c22.killed_kernel_initial_law_binding_mismatch");
  CHECK(fifo_with_event_entrance.error().code ==
        "c22.killed_kernel_initial_law_binding_mismatch");
}

TEST_CASE("C22 excludes unsafe rows and allows edge-mark killing in a safe "
          "successor",
          "[c22][integration][killed-domain][edge-mark]") {
  const auto edge_source = c22::one_step_exit_source(
      mwperf::AuditedTemporalSourceKindV1::stationary_projection,
      mwperf::InitialLawKindV1::event_palm,
      "c22.integration.safe-edge-kill");
  REQUIRE(edge_source.kernel.has_value());
  const mwperf::AbsorptionMarks departure_kill{{{
      "departure",
      mwperf::AnyStatePredicateV1{},
      mwperf::TargetDeparturePredicateV1{0U, true},
  }}};
  const auto edge_killed = c22::require_value(
      mwperf::construct_killed_kernel(
          *edge_source.kernel,
          mwperf::SafeSet{mwperf::AnyStatePredicateV1{}},
          departure_kill));
  CHECK(edge_killed.state_count() == 2U);
  const auto edge_stopped = c22::require_value(
      mwperf::evaluate_hit_survival_absorption(
          edge_killed, require_optional(edge_source.entrance),
          mwperf::HorizonSpec{mwperf::BigNat{1U}, false, false},
          c22::solver_policy("c22.integration.safe-edge-kill")));
  CHECK(edge_stopped.survival_tails[1].exact_probability ==
        mwperf::ExactRational::zero());
  REQUIRE(edge_stopped.absorption_masses.size() == 1U);
  CHECK(edge_stopped.absorption_masses[0].exact_probability ==
        mwperf::ExactRational::one());

  const auto unsafe_entrance = c22::one_step_exit_source(
      mwperf::AuditedTemporalSourceKindV1::stationary_projection,
      mwperf::InitialLawKindV1::event_palm,
      "c22.integration.unsafe-entrance", 1U);
  REQUIRE(unsafe_entrance.kernel.has_value());
  const auto compact_killed = c22::require_value(
      mwperf::construct_killed_kernel(*unsafe_entrance.kernel,
                                      c22::safe_state_zero(),
                                      c22::hit_state_one()));
  CHECK(compact_killed.state_count() == 1U);
  const auto rejected = mwperf::evaluate_hit_survival_absorption(
      compact_killed, require_optional(unsafe_entrance.entrance),
      mwperf::HorizonSpec{mwperf::BigNat{1U}, false, false},
      c22::solver_policy("c22.integration.unsafe-entrance"));
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c22.initial_law_not_supported_on_safe_set");
}
