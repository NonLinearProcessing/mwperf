#include <catch2/catch_test_macros.hpp>

#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>
#include <variant>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::CanonicalInputPair canonical;
  mwperf::InputFingerprintBundle fingerprints;
};

[[nodiscard]] std::filesystem::path runtime_directory() {
  const std::filesystem::path root(MWPERF_TEST_TEMP_DIRECTORY);
  const std::filesystem::path directory = root / "c03-input-pair";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  return directory;
}

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view name, const std::string_view contents) {
  const std::filesystem::path path = runtime_directory() / name;
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedPair parse_pair(const std::filesystem::path& model_path,
                                    const std::filesystem::path& analysis_path) {
  auto model_document = mwperf::load_document(model_path);
  REQUIRE(model_document.has_value());
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node.has_value());
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model.has_value());

  auto analysis_document = mwperf::load_document(analysis_path);
  REQUIRE(analysis_document.has_value());
  auto analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis.has_value());

  mwperf::CanonicalInputPair canonical = mwperf::canonicalize_authored_inputs(
      model.value(), analysis.value());
  mwperf::InputFingerprintBundle fingerprints =
      mwperf::fingerprint_inputs(canonical);
  return ParsedPair{
      .model = std::move(model).value(),
      .analysis = std::move(analysis).value(),
      .canonical = std::move(canonical),
      .fingerprints = std::move(fingerprints),
  };
}

constexpr std::string_view kModelJson = R"json({
  "schema_version": "3.0.0",
  "run": {
    "seed": 1,
    "slots": 10,
    "warmup_slots": 0,
    "termination": "fixed_slots"
  },
  "switch": {
    "kind": "generalized",
    "queue_capacity": 64,
    "queues": [{"id": "q0"}, {"id": "q1"}]
  },
  "scheduler": {
    "name": "conflict_graph_max_weight",
    "params": {
      "constraint": {"conflicts": [["q0", "q1"]]},
      "priority": ["q0", "q1"],
      "max_search_states": null
    }
  },
  "arrival": {
    "family": "deterministic_trace",
    "events": [
      {"slot": 0, "queue_id": "q0", "count": 2},
      {"slot": 0, "queue_id": "q1", "count": 1}
    ],
    "metadata": {}
  },
  "telemetry": {
    "format": "jsonl",
    "queue_snapshot": "sparse_nonzero",
    "include_packet_events": true,
    "include_scheduler_state": false,
    "write_slot_trace": true
  },
  "metadata": {"template_role": "canonical_runnable_example"}
})json";

constexpr std::string_view kModelYaml = R"yaml(schema_version: 3.0.0
run:
  seed: 1
  slots: 10
  warmup_slots: 0
  termination: fixed_slots
switch:
  kind: generalized
  queue_capacity: 64
  queues:
    - id: q0
    - id: q1
scheduler:
  name: conflict_graph_max_weight
  params:
    constraint:
      conflicts:
        - [q0, q1]
    priority: [q0, q1]
    max_search_states: null
arrival:
  family: deterministic_trace
  events:
    - {slot: 0, queue_id: q0, count: 2}
    - {slot: 0, queue_id: q1, count: 1}
  metadata: {}
telemetry:
  format: jsonl
  queue_snapshot: sparse_nonzero
  include_packet_events: true
  include_scheduler_state: false
  write_slot_trace: true
metadata:
  template_role: canonical_runnable_example
)yaml";

constexpr std::string_view kAnalysisJson = R"json({
  "analysis_schema_version": "1.0.0",
  "targets": ["q0"],
  "metrics": [{
    "id": "q0_mean_backlog",
    "kind": "stationary_backlog_moment",
    "parameters": {"order": 1}
  }],
  "surrogate": {
    "id": "future_surrogate_id",
    "version": null,
    "parameters": {}
  },
  "resolution": {
    "level": {"max_states": 10000, "max_row_atoms": 10000},
    "tail": {"kind": "none", "parameters": {}},
    "phase": {"max_phase_states": 1000},
    "optimizer": {
      "max_calls": 100000,
      "max_search_states_per_call": 100000
    },
    "sampling": {"max_generator_draws": null},
    "tolerance": {
      "linear_residual_abs": 1e-12,
      "integration_abs": null,
      "tail_abs": null,
      "fixed_point_abs": null
    }
  },
  "selection": {"kind": "stationary_unique", "parameters": {}},
  "solver": {
    "kind": "enumerated",
    "parameters": {"linear_method": "dense_pivoted", "max_iterations": null}
  }
})json";

constexpr std::string_view kAnalysisYaml = R"yaml(analysis_schema_version: 1.0.0
targets: [q0]
metrics:
  - id: q0_mean_backlog
    kind: stationary_backlog_moment
    parameters: {order: 1}
surrogate:
  id: future_surrogate_id
  version: null
  parameters: {}
resolution:
  level: {max_states: 10000, max_row_atoms: 10000}
  tail: {kind: none, parameters: {}}
  phase: {max_phase_states: 1000}
  optimizer: {max_calls: 100000, max_search_states_per_call: 100000}
  sampling: {max_generator_draws: null}
  tolerance:
    linear_residual_abs: 1e-12
    integration_abs: null
    tail_abs: null
    fixed_point_abs: null
selection: {kind: stationary_unique, parameters: {}}
solver:
  kind: enumerated
  parameters: {linear_method: dense_pivoted, max_iterations: null}
)yaml";

}  // namespace

TEST_CASE("C03 parses JSON and YAML input pairs to one canonical identity",
          "[c03][integration]") {
  const std::filesystem::path json_model =
      write_fixture("model.json", kModelJson);
  const std::filesystem::path yaml_model =
      write_fixture("model.yaml", kModelYaml);
  const std::filesystem::path json_analysis =
      write_fixture("analysis.json", kAnalysisJson);
  const std::filesystem::path yaml_analysis =
      write_fixture("analysis.yaml", kAnalysisYaml);

  const ParsedPair json_model_yaml_analysis =
      parse_pair(json_model, yaml_analysis);
  const ParsedPair yaml_model_json_analysis =
      parse_pair(yaml_model, json_analysis);

  CHECK(json_model_yaml_analysis.canonical ==
        yaml_model_json_analysis.canonical);
  CHECK(json_model_yaml_analysis.fingerprints ==
        yaml_model_json_analysis.fingerprints);

  // C03 hands C04 an ordered queue catalog candidate and unresolved typed
  // queue references.  Merely parsing/canonicalizing this pair does not bind a
  // dense index, compile the conflict graph, or execute an arrival/optimizer.
  const auto* switch_config = std::get_if<mwperf::GeneralizedSwitchConfig>(
      &json_model_yaml_analysis.model.switch_config);
  REQUIRE(switch_config != nullptr);
  REQUIRE(switch_config->queues.value.size() == 2U);
  REQUIRE(switch_config->queues.value[0].id.value.label().text_value() !=
          nullptr);
  CHECK(*switch_config->queues.value[0].id.value.label().text_value() == "q0");
  REQUIRE(switch_config->queues.value[1].id.value.label().text_value() !=
          nullptr);
  CHECK(*switch_config->queues.value[1].id.value.label().text_value() == "q1");

  const auto* scheduler =
      std::get_if<mwperf::ConflictGraphMaxWeightScheduler>(
          &json_model_yaml_analysis.model.scheduler.value);
  REQUIRE(scheduler != nullptr);
  REQUIRE(scheduler->constraint.value.conflicts.value.size() == 1U);
  CHECK(scheduler->constraint.value.conflicts.value.front().first.value ==
        switch_config->queues.value[0].id.value);
  CHECK(scheduler->constraint.value.conflicts.value.front().second.value ==
        switch_config->queues.value[1].id.value);

  const auto* arrival = std::get_if<mwperf::DeterministicTraceArrival>(
      &json_model_yaml_analysis.model.arrival.value);
  REQUIRE(arrival != nullptr);
  REQUIRE(arrival->events.value.size() == 2U);
  CHECK(arrival->events.value.front().queue_id.value ==
        switch_config->queues.value.front().id.value);

  REQUIRE(json_model_yaml_analysis.analysis.context != nullptr);
  REQUIRE(json_model_yaml_analysis.analysis.context->targets.queue_ids.size() ==
          1U);
  CHECK(json_model_yaml_analysis.analysis.context->targets.queue_ids.front() ==
        switch_config->queues.value.front().id.value.label());
}

TEST_CASE("C03 input fingerprint components isolate physical and analysis changes",
          "[c03][integration]") {
  const std::filesystem::path model = write_fixture("base-model.json", kModelJson);
  const std::filesystem::path analysis =
      write_fixture("base-analysis.json", kAnalysisJson);
  const ParsedPair baseline = parse_pair(model, analysis);

  std::string changed_model(kModelJson);
  const std::string old_metadata =
      R"("template_role": "canonical_runnable_example")";
  const std::size_t metadata_position = changed_model.find(old_metadata);
  REQUIRE(metadata_position != std::string::npos);
  changed_model.replace(metadata_position, old_metadata.size(),
                        R"("template_role": "integration_variant")");
  const ParsedPair physical_change = parse_pair(
      write_fixture("changed-model.json", changed_model), analysis);
  CHECK(physical_change.fingerprints.model != baseline.fingerprints.model);
  CHECK(physical_change.fingerprints.analysis == baseline.fingerprints.analysis);
  CHECK(physical_change.fingerprints.combined != baseline.fingerprints.combined);

  std::string changed_analysis(kAnalysisJson);
  const std::string old_parameters = R"("parameters": {})";
  const std::size_t parameters_position = changed_analysis.find(old_parameters);
  REQUIRE(parameters_position != std::string::npos);
  changed_analysis.replace(parameters_position, old_parameters.size(),
                           R"("parameters": {"pattern_width": 3})");
  const ParsedPair analysis_change = parse_pair(
      model, write_fixture("changed-analysis.json", changed_analysis));
  CHECK(analysis_change.fingerprints.model == baseline.fingerprints.model);
  CHECK(analysis_change.fingerprints.analysis != baseline.fingerprints.analysis);
  CHECK(analysis_change.fingerprints.combined != baseline.fingerprints.combined);
}
