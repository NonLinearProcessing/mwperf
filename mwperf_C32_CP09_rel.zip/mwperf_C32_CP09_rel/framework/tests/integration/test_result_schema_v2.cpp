#include <algorithm>
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <iterator>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/app/result_artifact.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/app/compression_comparison_v1_schema_embedded.hpp"
#include "mwperf/app/result_v2_schema_embedded.hpp"
#include "mwperf/app/result_v3_schema_embedded.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

using Json = nlohmann::ordered_json;

[[nodiscard]] std::string read_text(const std::filesystem::path& path) {
  std::ifstream stream(path, std::ios::binary);
  REQUIRE(stream.is_open());
  return {std::istreambuf_iterator<char>(stream),
          std::istreambuf_iterator<char>()};
}

void require_closed_object_schemas(const Json& node) {
  if (node.is_object()) {
    if (node.value("type", std::string{}) == "object") {
      REQUIRE(node.contains("additionalProperties"));
      CHECK(node.at("additionalProperties") == false);
    }
    for (const auto& [name, child] : node.items()) {
      INFO("schema member=" << name);
      require_closed_object_schemas(child);
    }
  } else if (node.is_array()) {
    for (const Json& child : node) {
      require_closed_object_schemas(child);
    }
  }
}

[[nodiscard]] std::vector<std::string> property_order(const Json& schema) {
  std::vector<std::string> result;
  for (const auto& [name, unused] : schema.at("properties").items()) {
    static_cast<void>(unused);
    result.push_back(name);
  }
  return result;
}

void require_property_order(
    const Json& schema,
    const std::initializer_list<std::string_view> expected_names) {
  std::vector<std::string> expected;
  expected.reserve(expected_names.size());
  for (const std::string_view name : expected_names) {
    expected.emplace_back(name);
  }
  CHECK(property_order(schema) == expected);
  CHECK(schema.at("required") == Json(expected));
}

[[nodiscard]] std::vector<std::byte> bytes_of(const std::string& text) {
  std::vector<std::byte> bytes;
  bytes.reserve(text.size());
  for (const char character : text) {
    bytes.push_back(
        static_cast<std::byte>(static_cast<unsigned char>(character)));
  }
  return bytes;
}

[[nodiscard]] Json minimal_failed_result_v2() {
  return Json{
      {"result_version", 2U},
      {"status", "failed"},
      {"failure",
       Json{{"stage", "wire_parse"},
            {"code", "fixture_failure"},
            {"diagnostic_refs", Json::array({"diag.fixture"})}}},
      {"main_result",
       Json{{"config", "c30-schema-fixture"},
            {"error",
             Json{{"code", "fixture_failure"},
                  {"message", "analysis failed"}}},
            {"wall_clock_seconds",
             Json{{"end_to_end", 0.0},
                  {"sampler", 0.0},
                  {"framework", 0.0}}}}},
      {"diagnostic_supplement", nullptr}};
}

[[nodiscard]] Json minimal_pre_observation_failed_result_v3() {
  return Json{
      {"result_version", 3U},
      {"status", "failed"},
      {"failure",
       Json{{"stage", "request_construction"},
            {"code", "fixture_failure"},
            {"diagnostic_refs", Json::array({"diag.fixture"})}}},
      {"result_kind", "failed"},
      {"main_result", nullptr},
      {"provenance",
       Json{{"config", "c32-schema-fixture"},
            {"input_fingerprints",
             Json{{"model", std::string(64U, 'a')},
                  {"analysis", std::string(64U, 'b')},
                  {"combined", std::string(64U, 'c')}}},
            {"provider",
             Json{{"provider_id", "full_orbit_framework_sampler"},
                  {"provider_version", "1.4.0"},
                  {"scientific_contract_digest", std::string(64U, 'd')}}},
            {"provider_result_digest", nullptr},
            {"master_seed", "0"},
            {"build_request", nullptr},
            {"model",
             Json{{"schema_version", "4"},
                  {"fingerprint", std::string(64U, 'a')}}},
            {"analysis",
             Json{{"schema_version", "1"},
                  {"fingerprint", std::string(64U, 'b')}}},
            {"wall_clock_seconds",
             Json{{"end_to_end", 0.0},
                  {"sampler", 0.0},
                  {"framework", 0.0}}},
            {"worker_count", 1U}}},
      {"diagnostic_supplement", nullptr}};
}

[[nodiscard]] mwperf::Digest256 repeated_digest(const char digit) {
  auto parsed = mwperf::Digest256::from_hex(std::string(64U, digit));
  REQUIRE(parsed);
  return std::move(parsed).value();
}

[[nodiscard]] std::shared_ptr<
    const mwperf::AnalysisDiagnosticSupplementV2>
observation_supplement_v3(
    const mwperf::ResultStatusV1 status,
    const std::optional<mwperf::ResultFailureStageV1> stage,
    std::optional<std::string> terminal_code,
    const mwperf::Digest256& provider_result_digest) {
  auto observation = std::make_shared<
      const mwperf::ValidatedConstructionObservationBundleV1>(
      mwperf::testing::c30::validated_bundle(
          mwperf::ObservationSourceRoleV1::weighted_ensemble));
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = {mwperf::BigNat{0U}};
  options.run_diagnostic_fits = false;
  options.compute_delete_one_replication_jackknife = false;
  options.projection_mode =
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  options.ensemble_population_size = mwperf::BigNat{64U};
  auto analyzed =
      mwperf::analyze_compression_observations_v1(*observation, options);
  REQUIRE(analyzed);
  auto analysis =
      std::make_shared<const mwperf::CompressionAnalysisResultV1>(
          std::move(analyzed).value());
  return std::make_shared<const mwperf::AnalysisDiagnosticSupplementV2>(
      std::move(observation), std::move(analysis), std::nullopt,
      mwperf::AnalysisProviderSuppliedProfileV2{
          mwperf::AnalysisProviderSuppliedProfileStatusV2::not_applicable,
          std::nullopt, std::nullopt},
      mwperf::AnalysisDecoderProfileV2{
          mwperf::AnalysisDecoderProfileStatusV2::not_applicable,
          std::nullopt, std::nullopt},
      mwperf::AnalysisDiagnosticTerminalV2{
          status, stage, std::move(terminal_code)},
      std::move(options), provider_result_digest);
}

[[nodiscard]] mwperf::ResultArtifactDataV3
minimal_pre_observation_failed_data_v3() {
  const mwperf::Digest256 model = repeated_digest('a');
  const mwperf::Digest256 analysis = repeated_digest('b');
  return mwperf::ResultArtifactDataV3{
      .status = mwperf::ResultStatusV1::failed,
      .failure =
          mwperf::ResultFailureV1{
              mwperf::ResultFailureStageV1::request_construction,
              "fixture_failure", {"diag.fixture"}},
      .input_fingerprints =
          mwperf::InputFingerprintBundle{
              model, analysis, repeated_digest('c')},
      .provider =
          mwperf::ProviderIdentityV1{
              "full_orbit_framework_sampler", "1.4.0"},
      .provider_digest =
          mwperf::ProviderScientificContractDigest(repeated_digest('d')),
      .provider_result_digest = std::nullopt,
      .master_seed = mwperf::MasterSeed{0U},
      .build_request_identity = std::nullopt,
      .model = mwperf::ResultModelProvenanceV1{"4", model},
      .analysis =
          mwperf::ResultAnalysisProvenanceV1{
              "1", analysis, {}, {},
              mwperf::PortableTransientSelectionV1{},
              mwperf::MetricSolverRegimeV1::monte_carlo},
      .config_name = "c32-schema-fixture",
      .wall_clock_times =
          mwperf::ResultWallClockTimesV1{
              std::chrono::nanoseconds::zero(),
              std::chrono::nanoseconds::zero(),
              std::chrono::nanoseconds::zero()},
      .worker_count = 1U,
      .diagnostic_supplement = {},
      .framework_prediction = {},
  };
}

[[nodiscard]] mwperf::ResultArtifactDataV3
observed_failed_data_v3(const mwperf::ResultFailureStageV1 stage,
                        std::string terminal_code) {
  auto data = minimal_pre_observation_failed_data_v3();
  data.failure->stage = stage;
  const mwperf::Digest256 provider_result_digest = repeated_digest('9');
  data.provider_result_digest = provider_result_digest;
  if (stage != mwperf::ResultFailureStageV1::request_construction) {
    const mwperf::BuildIdentityDigest build_identity(repeated_digest('e'));
    const mwperf::BuildSeed build_seed(data.master_seed, build_identity);
    data.build_request_identity = mwperf::ResultBuildRequestIdentityV1{
        build_identity, build_seed,
        mwperf::SurrogateBuildRequestDigest(repeated_digest('f'))};
  }
  data.diagnostic_supplement = observation_supplement_v3(
      mwperf::ResultStatusV1::failed, stage, std::move(terminal_code),
      provider_result_digest);
  data.framework_prediction =
      std::make_shared<const mwperf::FrameworkEmpiricalPredictionV1>(
          mwperf::derive_framework_empirical_prediction_v1(
              *data.diagnostic_supplement->observation(),
              *data.diagnostic_supplement->analysis(),
              data.diagnostic_supplement->analysis_options()));
  return data;
}

[[nodiscard]] mwperf::ResultArtifactDataV3 observed_success_data_v3() {
  auto data = minimal_pre_observation_failed_data_v3();
  data.status = mwperf::ResultStatusV1::success;
  data.failure = std::nullopt;
  const mwperf::Digest256 provider_result_digest = repeated_digest('9');
  data.provider_result_digest = provider_result_digest;
  const mwperf::BuildIdentityDigest build_identity(repeated_digest('e'));
  const mwperf::BuildSeed build_seed(data.master_seed, build_identity);
  data.build_request_identity = mwperf::ResultBuildRequestIdentityV1{
      build_identity, build_seed,
      mwperf::SurrogateBuildRequestDigest(repeated_digest('f'))};
  data.diagnostic_supplement = observation_supplement_v3(
      mwperf::ResultStatusV1::success, std::nullopt, std::nullopt,
      provider_result_digest);
  data.framework_prediction =
      std::make_shared<const mwperf::FrameworkEmpiricalPredictionV1>(
          mwperf::derive_framework_empirical_prediction_v1(
              *data.diagnostic_supplement->observation(),
              *data.diagnostic_supplement->analysis(),
              data.diagnostic_supplement->analysis_options()));
  return data;
}

[[nodiscard]] Json minimal_build_request_v3() {
  return Json{{"build_identity_digest", std::string(64U, 'e')},
              {"build_request_digest", std::string(64U, 'f')},
              {"rng_version", 1U}};
}

[[nodiscard]] Json empty_compression_status() {
  return Json{{"unavailable_reasons", Json::array()},
              {"warnings", Json::array()}};
}

[[nodiscard]] Json exact_zero_quantity() {
  return Json{
      {"estimate",
       Json{{"value", Json{{"exact", "0/1"}}},
            {"absolute_error_bound", Json{{"exact", "0/1"}}}}},
      {"status", empty_compression_status()}};
}

[[nodiscard]] Json minimal_comparison_v1() {
  Json cutoff = Json::object();
  cutoff["cutoff"] = "4";
  for (const std::string_view field : {
           "compression", "finite_window_construction",
           "weighted_ensemble_sampling", "provider_transformation",
           "three_term_sum", "three_term_target", "three_term_closure",
           "four_term_sum", "four_term_target", "four_term_closure",
           "stationary_tail_crosscheck"}) {
    cutoff[std::string(field)] = exact_zero_quantity();
  }
  cutoff["fit_resamples"] =
      Json{{"eligible_fit_resamples", 0U},
           {"failed_fit_resamples", 0U},
           {"unavailable_fit_resamples", 0U},
           {"unavailable_estimate_resamples", 0U}};
  cutoff["fit_failure_rate"] = exact_zero_quantity();
  cutoff["uncertainty"] =
      Json{{"compression_squared_standard_error", exact_zero_quantity()},
           {"finite_window_squared_standard_error", exact_zero_quantity()},
           {"sampling_squared_standard_error", exact_zero_quantity()},
           {"transformation_squared_standard_error", exact_zero_quantity()},
           {"status", empty_compression_status()}};
  cutoff["transformation_is_definitionally_zero"] = true;
  cutoff["status"] = empty_compression_status();
  return Json{
      {"comparison_version", 1U},
      {"kind", "compression_error_separation"},
      {"experiment_digest", std::string(64U, '1')},
      {"decoder_semantics_digest", std::string(64U, '2')},
      {"stationary_observation_digest", std::string(64U, '3')},
      {"finite_window_observation_digest", std::string(64U, '4')},
      {"weighted_ensemble_observation_digest", std::string(64U, '5')},
      {"stationary_analysis_digest", std::string(64U, '6')},
      {"finite_window_analysis_digest", std::string(64U, '7')},
      {"weighted_ensemble_analysis_digest", std::string(64U, '8')},
      {"provider_result_digest", nullptr},
      {"cutoffs", Json::array({std::move(cutoff)})},
      {"status", empty_compression_status()}};
}

}  // namespace

TEST_CASE("C30 result-v2 published and embedded schemas are identical",
          "[c30][result-v2][integration]") {
  const Json installed = Json::parse(read_text(MWPERF_C30_RESULT_V2_SCHEMA_PATH));
  const Json embedded =
      Json::parse(mwperf::detail::kPublishedResultV2SchemaJson);
  CHECK(installed == embedded);
  CHECK(installed.at("$id") ==
        "https://mwperf.invalid/schemas/result-v2.schema.json");

  const Json legacy = Json::parse(read_text(MWPERF_C30_RESULT_V1_SCHEMA_PATH));
  CHECK(legacy.at("$id") ==
        "https://mwperf.invalid/schemas/result-v1.schema.json");
  CHECK(legacy != installed);
}

TEST_CASE("C32 result-v3 published and embedded schemas are identical",
          "[c32][result-v3][integration]") {
  const Json installed =
      Json::parse(read_text(MWPERF_C32_RESULT_V3_SCHEMA_PATH));
  const Json embedded =
      Json::parse(mwperf::detail::kPublishedResultV3SchemaJson);
  CHECK(installed == embedded);
  CHECK(installed.at("$id") ==
        "https://mwperf.invalid/schemas/result-v3.schema.json");

  require_closed_object_schemas(installed);
  const Json& supplement = installed.at("$defs").at("diagnosticSupplement");
  REQUIRE(supplement.at("oneOf").size() == 2U);
  CHECK(supplement.at("properties").at("analysis_options").at("$ref") ==
        "#/$defs/compressionAnalysisOptions");
  CHECK(supplement.at("properties").at("analysis").at("oneOf").front().at(
            "$ref") == "#/$defs/compressionAnalysis");
  CHECK(supplement.at("properties").at("observation_bundle").at("$ref") ==
        "#/$defs/observationBundle");

  const Json& options =
      installed.at("$defs").at("compressionAnalysisOptions");
  CHECK(options.at("properties").at("projection_mode").at("const") ==
        "empirical_finite_window_response_v1");
  CHECK_FALSE(options.at("properties").at("cutoffs").contains("maxItems"));
  CHECK(options.at("properties")
            .at("compute_delete_one_replication_jackknife")
            .at("const") == false);
  CHECK(options.at("properties")
            .at("stationary_coefficients_established")
            .at("const") == false);
  CHECK(options.at("properties")
            .at("prefix_preservation_established")
            .at("const") == false);
  CHECK(options.at("properties")
            .at("poisson_mixture_overshoot_v1")
            .contains("oneOf"));
  const Json& analysis = installed.at("$defs").at("compressionAnalysis");
  CHECK(analysis.at("properties")
            .at("empirical_finite_window_response_v1")
            .at("$ref") == "#/$defs/empiricalFiniteWindowResponse");
  CHECK(analysis.at("properties")
            .at("poisson_overshoot_evaluation_v1")
            .contains("oneOf"));

  CHECK(installed.at("properties")
            .at("main_result")
            .at("oneOf")
            .front()
            .at("$ref") == "#/$defs/frameworkEmpiricalPrediction");
  require_property_order(
      installed.at("$defs").at("frameworkPredictionQuantity"),
      {"status", "value", "reason_code"});
  require_property_order(
      installed.at("$defs").at("frameworkPredictionResponsePoint"),
      {"level", "observed_response", "observation_status", "role"});
  require_property_order(
      installed.at("$defs").at("frameworkPredictionResponseTreatment"),
      {"observed_complete_through", "prefix_cutoff", "constant_tail_from",
       "completion_policy", "unobserved_levels", "empirical_zero_or_one",
       "structural_zero", "coefficient_value_treatment",
       "numerical_enclosures_present", "points"});
  require_property_order(
      installed.at("$defs").at("frameworkPoissonArrivalPoint"),
      {"arrival_count", "probability"});
  require_property_order(
      installed.at("$defs").at("frameworkPoissonArrivalReconstruction"),
      {"algorithm_id", "algorithm_version", "descriptor_digest",
       "law_support", "configured_rate_treatment",
       "operational_rate_treatment", "projection_role",
       "represented_through", "probability_prefix",
       "omitted_probability", "omitted_first_raw_moment",
       "omitted_second_raw_moment", "omitted_third_raw_moment",
       "exact_first_raw_moment", "exact_second_raw_moment",
       "exact_third_raw_moment", "exponential_absolute_tolerance",
       "recurrence_steps"});
  require_property_order(
      installed.at("$defs").at("frameworkPredictionStationary"),
      {"interpretation", "physical_metric_claim", "pmf",
       "remaining_tail_probability", "empty_probability",
       "first_backlog_moment", "second_backlog_moment", "mean_sojourn",
       "arrival_mean"});
  require_property_order(
      installed.at("$defs").at("frameworkEmpiricalPredictionV1"),
      {"method_id", "method_version", "calculation_status",
       "calculation_reason_code", "observation_digest", "analysis_digest",
       "target_id", "response_treatment", "stationary"});
  require_property_order(
      installed.at("$defs").at("frameworkEmpiricalPredictionV2"),
      {"method_id", "method_version", "calculation_status",
       "calculation_reason_code", "observation_digest", "analysis_digest",
       "target_id", "response_treatment",
       "poisson_arrival_reconstruction_v1", "stationary"});
  const Json& prediction_v1 =
      installed.at("$defs").at("frameworkEmpiricalPredictionV1");
  const Json& prediction_v2 =
      installed.at("$defs").at("frameworkEmpiricalPredictionV2");
  REQUIRE(prediction_v1.at("allOf").size() == 2U);
  REQUIRE(prediction_v2.at("allOf").size() == 2U);
  CHECK(prediction_v1.at("allOf").at(1U).at("properties")
            .at("stationary").at("properties").at("interpretation")
            .at("const") ==
        "empirical_plugin_prediction_conditional_on_exact_dyadic_response_centers");
  CHECK(prediction_v2.at("allOf").at(1U).at("properties")
            .at("stationary").at("properties").at("interpretation")
            .at("const") ==
        "empirical_plugin_prediction_conditional_on_exact_dyadic_response_and_certified_poisson_representative");
  const Json& prediction_union =
      installed.at("$defs").at("frameworkEmpiricalPrediction");
  REQUIRE(prediction_union.at("oneOf").size() == 2U);
  CHECK(prediction_union.at("oneOf").at(0U).at("$ref") ==
        "#/$defs/frameworkEmpiricalPredictionV1");
  CHECK(prediction_union.at("oneOf").at(1U).at("$ref") ==
        "#/$defs/frameworkEmpiricalPredictionV2");

  REQUIRE(installed.at("allOf").size() == 6U);
  CHECK(installed.at("allOf").at(0).at("then").at("properties")
            .at("result_kind").at("const") == "observed");
  CHECK(installed.at("allOf").at(1).at("then").at("properties")
            .at("result_kind").at("const") == "unavailable");
  CHECK(installed.at("allOf").at(2).at("then").at("properties")
            .at("result_kind").at("const") == "failed");
  const Json& failed_conditionals =
      installed.at("allOf").at(2).at("then").at("allOf");
  REQUIRE(failed_conditionals.size() == 13U);
  CHECK(failed_conditionals.at(1)
            .at("then")
            .at("properties")
            .at("diagnostic_supplement")
            .at("type") == "null");
  CHECK(failed_conditionals.at(3)
            .at("if")
            .at("properties")
            .at("failure")
            .at("properties")
            .at("stage")
            .at("const") == "producer_execution");
  CHECK(failed_conditionals.at(3)
            .at("then")
            .at("properties")
            .at("diagnostic_supplement")
            .at("properties")
            .at("terminal")
            .at("properties")
            .at("failure_stage")
            .at("const") == "producer_execution");
  const Json& success_supplement =
      installed.at("$defs").at("successDiagnosticSupplement");
  CHECK(success_supplement.at("allOf").at(1).at("properties")
            .at("terminal").at("properties").at("main_status").at("const") ==
        "success");
  CHECK(success_supplement.at("allOf").at(1).at("properties")
            .at("analysis_failure").at("type") == "null");
  const Json& unavailable_supplement =
      installed.at("$defs").at("unavailableDiagnosticSupplement");
  CHECK(unavailable_supplement.at("allOf").at(1).at("properties")
            .at("terminal").at("properties").at("main_status").at("const") ==
        "unavailable");
  const Json& failed_supplement =
      installed.at("$defs").at("failedDiagnosticSupplement");
  CHECK(failed_supplement.at("allOf").at(1).at("properties")
            .at("terminal").at("properties").at("main_status").at("const") ==
        "failed");
  const Json& observation_only_supplement =
      installed.at("$defs").at("observationOnlyDiagnosticSupplement");
  CHECK(observation_only_supplement.at("allOf").at(1).at("properties")
            .at("provider_supplied_profile").at("properties")
            .at("status").at("const") == "not_applicable");
  CHECK(observation_only_supplement.at("allOf").at(1).at("properties")
            .at("decoder_profile").at("properties").at("status")
            .at("const") == "not_applicable");

  CHECK(installed.at("properties")
            .at("diagnostic_supplement")
            .at("oneOf")
            .back()
            .at("type") == "null");
  const Json& provenance = installed.at("$defs").at("provenanceV3");
  CHECK(provenance.at("properties")
            .at("provider_result_digest")
            .at("oneOf")
            .back()
            .at("type") == "null");
  CHECK(provenance.at("properties")
            .at("build_request")
            .at("oneOf")
            .back()
            .at("type") == "null");

  const Json pre_observation_failure =
      minimal_pre_observation_failed_result_v3();
  REQUIRE(mwperf::validate_result_v3_json_schema_for_test(
      pre_observation_failure.dump()));

  SECTION("verified analysis publishes a bound framework prediction") {
    auto artifact = mwperf::make_result_artifact_v3_for_test(
        observed_success_data_v3());
    REQUIRE(artifact);
    auto encoded = mwperf::canonical_result_artifact_v3_json_for_test(
        artifact.value());
    REQUIRE(encoded);
    const Json published = Json::parse(encoded.value());
    REQUIRE(mwperf::validate_result_v3_json_schema_for_test(
        published.dump()));

    const Json& main = published.at("main_result");
    REQUIRE(main.is_object());
    CHECK(main.at("method_id") ==
          "framework_empirical_constant_last_observed_v1");
    CHECK(main.at("method_version") == 1U);
    CHECK(main.at("calculation_status") == "available");
    CHECK(main.at("calculation_reason_code").is_null());
    CHECK(main.at("observation_digest") ==
          published.at("diagnostic_supplement")
              .at("observation_bundle_digest"));
    CHECK(main.at("analysis_digest") ==
          published.at("diagnostic_supplement")
              .at("analysis")
              .at("analysis_digest"));
    const Json expected_target_id{{"integer", "17"}};
    CHECK(main.at("target_id") == expected_target_id);

    const Json& response = main.at("response_treatment");
    CHECK(response.at("observed_complete_through") == "2");
    CHECK(response.at("prefix_cutoff") == "2");
    CHECK(response.at("constant_tail_from") == "3");
    CHECK(response.at("completion_policy") == "constant_last_observed");
    CHECK(response.at("unobserved_levels") ==
          "constant_equal_to_last_observed_response");
    CHECK(response.at("empirical_zero_or_one") ==
          "retained_as_observed_coefficient");
    CHECK(response.at("structural_zero") == "mu_0_equals_zero");
    CHECK(response.at("coefficient_value_treatment") ==
          "exact_dyadic_point_estimate_with_absolute_error_retained");
    CHECK(response.at("numerical_enclosures_present") == false);
    REQUIRE(response.at("points").size() == 3U);
    for (std::size_t level = 0U; level < 3U; ++level) {
      CHECK(response.at("points").at(level).at("level") ==
            std::to_string(level));
    }
    CHECK(response.at("points").front().at("observation_status") ==
          "structural_zero");
    CHECK(response.at("points").at(0U).at("observed_response")
              .at("value").at("exact") == "0/1");
    CHECK(response.at("points").at(1U).at("observed_response")
              .at("value").at("exact") == "1/1");
    CHECK(response.at("points").at(2U).at("observed_response")
              .at("value").at("exact") == "1/2");
    CHECK(response.at("points").back().at("role") ==
          "finite_prefix_and_constant_tail_anchor");

    const Json& stationary = main.at("stationary");
    CHECK(stationary.at("interpretation") ==
          "empirical_plugin_prediction_conditional_on_exact_dyadic_response_centers");
    CHECK(stationary.at("physical_metric_claim") ==
          "not_established_source_absolute_error_bounds_retained");
    REQUIRE(stationary.at("pmf").size() == 3U);
    for (std::size_t level = 0U; level < 3U; ++level) {
      CHECK(stationary.at("pmf").at(level).at("level") ==
            std::to_string(level));
      CHECK(stationary.at("pmf").at(level).at("probability").at("status") ==
            "available");
    }
    for (const std::string_view field : {
             "remaining_tail_probability", "empty_probability",
             "first_backlog_moment", "second_backlog_moment",
             "mean_sojourn", "arrival_mean"}) {
      INFO("prediction quantity=" << field);
      const Json& quantity = stationary.at(std::string(field));
      CHECK(quantity.at("status") == "available");
      CHECK(quantity.at("value").is_object());
      CHECK(quantity.at("reason_code").is_null());
    }
    CHECK(stationary.at("remaining_tail_probability")
              .at("value")
              .at("exact") == "0/1");
    CHECK(stationary.at("empty_probability").at("value").at("exact") ==
          "3/4");
    CHECK(stationary.at("first_backlog_moment")
              .at("value")
              .at("exact") == "1/4");
    CHECK(stationary.at("second_backlog_moment")
              .at("value")
              .at("exact") == "1/4");
    CHECK(stationary.at("mean_sojourn").at("value").at("exact") ==
          "1/1");

    auto parsed = mwperf::parse_result_artifact_v3(
        bytes_of(encoded.value()),
        mwperf::default_result_artifact_parse_limits_v2());
    REQUIRE(parsed);
    REQUIRE(parsed.value().framework_prediction());
    CHECK(*parsed.value().framework_prediction() ==
          *artifact.value().value().framework_prediction);

    SECTION("success cannot erase its framework prediction") {
      Json mutated = published;
      mutated["main_result"] = nullptr;
      auto rejected = mwperf::validate_result_v3_json_schema_for_test(
          mutated.dump());
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code ==
            "c32.result_v3_schema_validation_failed");
    }

    SECTION("quantity availability has an exact value-reason XOR") {
      Json mutated = published;
      mutated["main_result"]["stationary"]["empty_probability"]["status"] =
          "unavailable";
      auto rejected = mwperf::validate_result_v3_json_schema_for_test(
          mutated.dump());
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code ==
            "c32.result_v3_schema_validation_failed");
    }

    SECTION("canonical but altered predictions fail deterministic verification") {
      Json mutated = published;
      auto& probability =
          mutated["main_result"]["stationary"]["pmf"][2]["probability"]
                 ["value"];
      probability["exact"] = "1/1";
      probability["decimal"] = 1.0;
      auto rejected = mwperf::parse_result_artifact_v3(
          bytes_of(mutated.dump()),
          mwperf::default_result_artifact_parse_limits_v2());
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code ==
            "c32.framework_prediction_verification_failed");
    }

    SECTION("pre-observation failure cannot fabricate a prediction") {
      Json mutated = pre_observation_failure;
      mutated["main_result"] = main;
      auto rejected = mwperf::validate_result_v3_json_schema_for_test(
          mutated.dump());
      REQUIRE_FALSE(rejected);
      CHECK(rejected.error().code ==
            "c32.result_v3_schema_validation_failed");
    }
  }

  SECTION("typed pre-observation failure publishes without fabricated evidence") {
    auto artifact = mwperf::make_result_artifact_v3_for_test(
        minimal_pre_observation_failed_data_v3());
    REQUIRE(artifact);
    auto encoded = mwperf::canonical_result_artifact_v3_json_for_test(
        artifact.value());
    REQUIRE(encoded);
    const Json published = Json::parse(encoded.value());
    CHECK(published.at("diagnostic_supplement").is_null());
    CHECK(published.at("provenance")
              .at("provider_result_digest")
              .is_null());
    CHECK(published.at("provenance").at("build_request").is_null());
  }

  SECTION("typed request construction failure rejects a fabricated supplement") {
    auto rejected = mwperf::make_result_artifact_v3_for_test(
        observed_failed_data_v3(
            mwperf::ResultFailureStageV1::request_construction,
            "fixture_failure"));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_pre_observation_shape_invalid");
  }

  SECTION("typed failed terminal code must equal its outer failure code") {
    auto rejected = mwperf::make_result_artifact_v3_for_test(
        observed_failed_data_v3(
            mwperf::ResultFailureStageV1::producer_execution,
            "different_fixture_failure"));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c32.result_v3_terminal_invalid");
  }

  SECTION("a pre-observation failure cannot claim a provider-result digest") {
    auto data = minimal_pre_observation_failed_data_v3();
    data.provider_result_digest = repeated_digest('e');
    auto rejected =
        mwperf::make_result_artifact_v3_for_test(std::move(data));
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_pre_observation_shape_invalid");
  }

  SECTION("the schema binds an omitted supplement to an omitted digest") {
    Json mutated = pre_observation_failure;
    mutated["provenance"]["provider_result_digest"] =
        std::string(64U, '9');
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        mutated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");
  }

  SECTION("only a pre-observation stage may omit the supplement") {
    Json mutated = pre_observation_failure;
    mutated["failure"]["stage"] = "backend";
    mutated["provenance"]["build_request"] = minimal_build_request_v3();
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        mutated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");
  }

  SECTION("request construction alone omits build-request provenance") {
    Json fabricated = pre_observation_failure;
    fabricated["provenance"]["build_request"] = minimal_build_request_v3();
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        fabricated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");

    Json later_failure = pre_observation_failure;
    later_failure["failure"]["stage"] = "wire_parse";
    later_failure["provenance"]["build_request"] = minimal_build_request_v3();
    REQUIRE(mwperf::validate_result_v3_json_schema_for_test(
        later_failure.dump()));
  }

  SECTION("request construction cannot carry an observation supplement") {
    auto valid_artifact = mwperf::make_result_artifact_v3_for_test(
        observed_failed_data_v3(
            mwperf::ResultFailureStageV1::producer_execution,
            "fixture_failure"));
    REQUIRE(valid_artifact);
    auto encoded = mwperf::canonical_result_artifact_v3_json_for_test(
        valid_artifact.value());
    REQUIRE(encoded);
    Json fabricated = Json::parse(encoded.value());
    fabricated["failure"]["stage"] = "request_construction";
    fabricated["provenance"]["build_request"] = nullptr;
    fabricated["diagnostic_supplement"]["terminal"]["failure_stage"] =
        "request_construction";
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        fabricated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");
  }

  SECTION("success cannot omit its authenticated observation") {
    Json mutated = pre_observation_failure;
    mutated["status"] = "success";
    mutated["failure"] = nullptr;
    mutated["result_kind"] = "observed";
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        mutated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");
  }

  SECTION("unavailable cannot omit its authenticated observation") {
    Json mutated = pre_observation_failure;
    mutated["status"] = "unavailable";
    mutated["failure"] = nullptr;
    mutated["result_kind"] = "unavailable";
    auto rejected = mwperf::validate_result_v3_json_schema_for_test(
        mutated.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c32.result_v3_schema_validation_failed");
  }
}

TEST_CASE("C32 result-v3 bounded reader retains pre-observation terminals",
          "[c32][result-v3][integration]") {
  const std::string canonical =
      minimal_pre_observation_failed_result_v3().dump();
  const auto bytes = bytes_of(canonical);
  auto parsed = mwperf::parse_result_artifact_v3(
      bytes, mwperf::default_result_artifact_parse_limits_v2());
  REQUIRE(parsed);
  CHECK(parsed.value().status() == mwperf::ResultStatusV1::failed);
  REQUIRE(parsed.value().failure());
  CHECK(parsed.value().failure()->stage ==
        mwperf::ResultFailureStageV1::request_construction);
  CHECK(parsed.value().failure()->code == "fixture_failure");
  CHECK_FALSE(parsed.value().observation());
  CHECK_FALSE(parsed.value().analysis());
  CHECK_FALSE(parsed.value().analysis_options());
  CHECK_FALSE(parsed.value().provider_result_digest());
  CHECK(parsed.value().canonical_bytes().size() == canonical.size());

  SECTION("a result-v3 byte cap rejects before DOM construction") {
    auto limits = mwperf::default_result_artifact_parse_limits_v2();
    limits.maximum_bytes = bytes.size() - 1U;
    auto rejected = mwperf::parse_result_artifact_v3(bytes, limits);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c32.result_v3_byte_limit");
  }
}

TEST_CASE("C30 result-v2 schema is recursively closed and keeps analysis XOR",
          "[c30][result-v2][unit]") {
  const Json schema =
      Json::parse(read_text(MWPERF_C30_RESULT_V2_SCHEMA_PATH));
  require_closed_object_schemas(schema);
  const Json& supplement = schema.at("$defs").at("diagnosticSupplement");
  REQUIRE(supplement.at("oneOf").size() == 2U);
  const auto& required = supplement.at("required");
  CHECK(std::find(required.begin(), required.end(), "analysis") !=
        required.end());
  CHECK(std::find(required.begin(), required.end(), "analysis_failure") !=
        required.end());
  CHECK(supplement.at("properties").contains("observation_bundle"));
  CHECK(supplement.at("properties").contains(
      "observation_bundle_digest"));
  CHECK(supplement.at("properties").contains("provider_supplied_profile"));
  CHECK(supplement.at("properties").contains("analysis_options"));
  require_property_order(
      supplement,
      {"terminal", "provider_supplied_profile", "decoder_profile",
       "analysis_options", "analysis", "analysis_failure",
       "observation_bundle_digest", "observation_bundle"});
  const Json& analysis_options =
      schema.at("$defs").at("compressionAnalysisOptions");
  require_property_order(
      analysis_options,
      {"cutoffs", "fit_limits", "effective_selection_seed",
       "provider_supplied_profiles", "ill_conditioned_slack_threshold",
       "run_diagnostic_fits",
       "compute_delete_one_replication_jackknife",
       "stationary_coefficients_established",
       "prefix_preservation_established"});
  const Json& provider = schema.at("$defs").at("providerSuppliedProfile");
  CHECK(provider.at("properties").contains("observation_digest"));
  CHECK(provider.at("properties").contains("provider_result_digest"));
  CHECK(provider.at("properties").contains("payload_digest"));
  require_property_order(
      provider,
      {"status", "profile", "reason_code", "observation_digest",
       "provider_result_digest", "payload_digest"});
  const Json& decoder = schema.at("$defs").at("decoderProfile");
  CHECK(decoder.at("properties").contains("provider_result_digest"));
  CHECK(decoder.at("properties").contains("decoder_semantics_digest"));
  require_property_order(
      decoder,
      {"status", "profile", "reason_code", "provider_result_digest",
       "decoder_semantics_digest"});

  const Json& analysis = schema.at("$defs").at("compressionAnalysis");
  require_property_order(
      analysis,
      {"observation_digest", "analysis_digest", "source_role",
       "warmup_boundary", "end_boundary", "pooled", "replications", "cutoffs",
       "finite_window", "competition", "ties", "work", "status"});
  require_property_order(
      schema.at("$defs").at("replicationSummary"),
      {"replication_id", "completeness", "inclusion",
       "measured_slot_count", "exposure_mass", "service_mass",
       "backlog_exposure_mass", "backlog_service_mass",
       "initial_first_moment", "committed_first_moment",
       "initial_second_moment", "committed_second_moment", "cutoffs"});
  require_property_order(
      schema.at("$defs").at("replicationCutoffSummary"),
      {"cutoff", "tail_exposure_mass", "tail_service_mass",
       "backlog_tail_exposure_mass", "backlog_tail_service_mass",
       "positive_gap_tail_magnitude_mass",
       "negative_gap_tail_magnitude_mass"});
  const Json& work = schema.at("$defs").at("compressionWork");
  require_property_order(
      work,
      {"input_level_rows", "input_boundary_rows", "input_row_bytes",
       "merged_level_rows",
       "merged_boundary_rows", "merge_key_comparisons",
       "merge_heap_operations", "point_fit_invocations",
       "jackknife_fit_invocations", "top_level_reservation_events",
       "analysis_allocation_events", "peak_retained_top_level_objects",
       "estimated_peak_retained_bytes"});
  const Json& cutoff = schema.at("$defs").at("cutoffAnalysis");
  require_property_order(
      cutoff,
      {"cutoff", "empirical_profile", "provider_supplied_profile",
       "four_tail_rewards", "diagnostic_fit", "diagnostic_fit_failure",
       "diagnostic_fit_status", "diagnostic_fitted_mean",
       "empirical_decomposition", "jackknife", "status"});
  const Json& jackknife = schema.at("$defs").at("cutoffJackknife");
  require_property_order(
      jackknife,
      {"fitted_mean", "fitted_minus_observed_mean",
       "tail_association_ratio", "fit_resamples"});

  CHECK(schema.at("$defs").at("pooledMoments").at("properties")
            .at("observed_mean")
            .at("$ref") == "#/$defs/quantity");
  CHECK(schema.at("$defs").at("empiricalPoint").at("properties")
            .at("occupation_probability")
            .at("$ref") == "#/$defs/quantity");
}

TEST_CASE("C30 result-v2 bounded reader accepts canonical closed roots",
          "[c30][result-v2][integration]") {
  const std::string canonical = minimal_failed_result_v2().dump();
  const auto bytes = bytes_of(canonical);
  auto parsed = mwperf::parse_result_artifact_v2(
      bytes, mwperf::default_result_artifact_parse_limits_v2());
  REQUIRE(parsed);
  CHECK(parsed.value().status() == mwperf::ResultStatusV1::failed);
  REQUIRE(parsed.value().failure());
  CHECK(parsed.value().failure()->code == "fixture_failure");
  CHECK_FALSE(parsed.value().observation());

  auto schema_accepted = mwperf::validate_result_v2_json_schema_for_test(
      canonical);
  REQUIRE(schema_accepted);

  SECTION("closed root rejects an unknown field") {
    Json mutated = minimal_failed_result_v2();
    mutated["unknown"] = true;
    const auto mutated_bytes = bytes_of(mutated.dump());
    auto rejected = mwperf::parse_result_artifact_v2(
        mutated_bytes, mwperf::default_result_artifact_parse_limits_v2());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_schema_validation_failed");
  }

  SECTION("byte cap rejects before DOM decode") {
    auto limits = mwperf::default_result_artifact_parse_limits_v2();
    limits.maximum_bytes = bytes.size() - 1U;
    auto rejected = mwperf::parse_result_artifact_v2(bytes, limits);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_byte_limit");
  }

  SECTION("root property order is part of the canonical schema contract") {
    const Json value = minimal_failed_result_v2();
    Json reordered = Json::object();
    reordered["status"] = value.at("status");
    reordered["result_version"] = value.at("result_version");
    reordered["failure"] = value.at("failure");
    reordered["main_result"] = value.at("main_result");
    reordered["diagnostic_supplement"] =
        value.at("diagnostic_supplement");
    auto rejected = mwperf::validate_result_v2_json_schema_for_test(
        reordered.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_schema_validation_failed");
  }

  SECTION("nested property order is part of the canonical schema contract") {
    Json reordered = minimal_failed_result_v2();
    reordered["failure"] =
        Json{{"code", "fixture_failure"},
             {"stage", "wire_parse"},
             {"diagnostic_refs", Json::array({"diag.fixture"})}};
    auto rejected = mwperf::validate_result_v2_json_schema_for_test(
        reordered.dump());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_schema_validation_failed");
  }

  SECTION("failed result requires diagnostic evidence references") {
    Json mutated = minimal_failed_result_v2();
    mutated["failure"]["diagnostic_refs"] = Json::array();
    auto rejected = mwperf::parse_result_artifact_v2(
        bytes_of(mutated.dump()),
        mwperf::default_result_artifact_parse_limits_v2());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_schema_validation_failed");
  }

  SECTION("failed result diagnostic evidence references are unique") {
    Json mutated = minimal_failed_result_v2();
    mutated["failure"]["diagnostic_refs"] =
        Json::array({"diag.fixture", "diag.fixture"});
    auto rejected = mwperf::parse_result_artifact_v2(
        bytes_of(mutated.dump()),
        mwperf::default_result_artifact_parse_limits_v2());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c30.result_v2_schema_validation_failed");
  }
}

TEST_CASE("C30 comparison-v1 published and embedded schemas are identical",
          "[c30][comparison][result-v2][integration]") {
  const Json published =
      Json::parse(read_text(MWPERF_C30_COMPARISON_SCHEMA_PATH));
  const Json embedded = Json::parse(
      mwperf::detail::kPublishedCompressionComparisonV1SchemaJson);
  CHECK(published == embedded);
  CHECK(published.at("$id") ==
        "https://mwperf.invalid/schemas/compression-comparison-v1.schema.json");
  require_closed_object_schemas(published);
  require_property_order(
      published,
      {"comparison_version", "kind", "experiment_digest",
       "decoder_semantics_digest", "stationary_observation_digest",
       "finite_window_observation_digest",
       "weighted_ensemble_observation_digest", "stationary_analysis_digest",
       "finite_window_analysis_digest", "weighted_ensemble_analysis_digest",
       "provider_result_digest", "cutoffs", "status"});
  require_property_order(
      published.at("$defs").at("cutoff"),
      {"cutoff", "compression", "finite_window_construction",
       "weighted_ensemble_sampling", "provider_transformation",
       "three_term_sum", "three_term_target", "three_term_closure",
       "four_term_sum", "four_term_target", "four_term_closure",
       "stationary_tail_crosscheck", "fit_resamples", "fit_failure_rate",
       "uncertainty", "transformation_is_definitionally_zero", "status"});

  const Json valid = minimal_comparison_v1();
  auto accepted =
      mwperf::validate_compression_comparison_v1_json_schema_for_test(
          valid.dump());
  REQUIRE(accepted);

  Json mutated = valid;
  mutated["cutoffs"][0]["uncertainty"]["unknown"] = true;
  auto rejected =
      mwperf::validate_compression_comparison_v1_json_schema_for_test(
          mutated.dump());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c30.comparison_schema_validation_failed");

  Json reordered = valid;
  Json reordered_counts = Json::object();
  reordered_counts["failed_fit_resamples"] = 0U;
  reordered_counts["eligible_fit_resamples"] = 0U;
  reordered_counts["unavailable_fit_resamples"] = 0U;
  reordered_counts["unavailable_estimate_resamples"] = 0U;
  reordered["cutoffs"][0]["fit_resamples"] = std::move(reordered_counts);
  auto order_rejected =
      mwperf::validate_compression_comparison_v1_json_schema_for_test(
          reordered.dump());
  REQUIRE_FALSE(order_rejected);
  CHECK(order_rejected.error().code ==
        "c30.comparison_schema_validation_failed");
}
