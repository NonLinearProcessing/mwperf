#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <ranges>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ParsedPair final {
  mwperf::AuthoredModelConfig model;
  mwperf::AnalysisSpec analysis;
  mwperf::InputFingerprintBundle fingerprints;
};

struct C06FamilyCase final {
  std::string scheduler;
  mwperf::ServiceFamily family;
  mwperf::OptimizerId backend;
};

[[nodiscard]] std::filesystem::path write_input(const std::string& stem,
                                                const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c06-dispatch";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    (stem + '-' + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string analysis_text() {
  return R"({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput","parameters":{}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":64,"max_search_states_per_call":5},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,"tail_abs":null,"fixed_point_abs":null}
    },
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":null}}
  })";
}

[[nodiscard]] std::string model_text(const std::string& scheduler,
                                     const std::string& queues) {
  return R"({"schema_version":"3.0.0","run":{"seed":7,"slots":3,"warmup_slots":0,"termination":"fixed_slots"},"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         queues + R"(},"scheduler":)" + scheduler +
         R"(,"arrival":{"family":"deterministic_trace","events":[]},"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})";
}

[[nodiscard]] ParsedPair parse_pair(const std::string& scheduler,
                                    const std::string& queues) {
  auto model_document = mwperf::load_document(
      write_input("model", model_text(scheduler, queues)));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto parsed_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(parsed_model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text()));
  REQUIRE(analysis_document);
  auto parsed_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(parsed_analysis);

  const auto canonical = mwperf::canonicalize_authored_inputs(
      parsed_model.value(), parsed_analysis.value());
  auto fingerprints = mwperf::fingerprint_inputs(canonical);
  return ParsedPair{std::move(parsed_model).value(),
                    std::move(parsed_analysis).value(),
                    std::move(fingerprints)};
}

[[nodiscard]] mwperf::detail::ResolutionChildServices
production_constraint_children() {
  mwperf::detail::ResolutionChildServices services;
  services.constraint =
      [](const mwperf::AuthoredSchedulerConfig& scheduler,
         const mwperf::QueueCatalog& catalog) {
        // This is deliberately the public production C04 -> C06 compiler,
        // not the C04 compiled-product fixture used by the older tests.
        return mwperf::compile_constraint_descriptor(scheduler, catalog);
      };
  services.arrival =
      [](const mwperf::AuthoredArrivalConfig&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-arrival-placeholder");
        return mwperf::detail::ArrivalCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  services.support =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::PhysicalBindingIdentity&,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog& catalog) {
        return mwperf::QueueMask::from_bytes(
            std::vector<std::uint8_t>(catalog.size(), 0U), catalog.size());
      };
  services.initial =
      [](const mwperf::detail::ArrivalCompilationToken&,
         const mwperf::ResolvedTransientInitialLaw&,
         const mwperf::PhysicalBindingIdentity& binding,
         std::span<const mwperf::BoundQueueReference>,
         const mwperf::QueueCatalog&) {
        std::shared_ptr<const void> owner =
            std::make_shared<const std::string>("c09-initial-placeholder");
        return mwperf::detail::InitialCompilationToken::for_fixture(
            binding, std::move(owner));
      };
  return services;
}

[[nodiscard]] mwperf::ResolvedInstance resolved_c06(
    const std::string& scheduler,
    const std::string& queues = R"(["q0","q1","q2"])") {
  const ParsedPair pair = parse_pair(scheduler, queues);
  const auto children = production_constraint_children();
  auto resolved =
      mwperf::detail::resolve_physical_instance_with_child_services(
          pair.model, pair.analysis, pair.fingerprints, children);
  INFO((resolved ? std::string{} : resolved.error().code));
  REQUIRE(resolved);
  REQUIRE(resolved.value().constraint().compiled_product().has_owner());
  return std::move(resolved).value();
}

[[nodiscard]] std::vector<C06FamilyCase> small_c06_cases() {
  return {
      {
          R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"}]},"priority":["q0","q1","q2"]}})",
          mwperf::ServiceFamily::crossbar_matching,
          mwperf::OptimizerId::hungarian_exact,
      },
      {
          R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":3},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":1,"right":3}]},"priority":["q0","q1","q2"]}})",
          mwperf::ServiceFamily::nonoverlapping_intervals,
          mwperf::OptimizerId::weighted_interval_dp_exact,
      },
  };
}

[[nodiscard]] std::vector<C06FamilyCase> forced_c06_cases() {
  return {
      {
          R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1","i2"],"outputs":["o0","o1","o2","o3"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o2"},{"queue_id":"q3","input":"i2","output":"o3"}]},"priority":["q0","q1","q2","q3"]}})",
          mwperf::ServiceFamily::crossbar_matching,
          mwperf::OptimizerId::hungarian_exact,
      },
      {
          R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":3},{"queue_id":"q1","left":0,"right":1},{"queue_id":"q2","left":3,"right":4},{"queue_id":"q3","left":-1,"right":0}]},"priority":["q0","q1","q2","q3"]}})",
          mwperf::ServiceFamily::nonoverlapping_intervals,
          mwperf::OptimizerId::weighted_interval_dp_exact,
      },
  };
}

[[nodiscard]] mwperf::Backlog make_backlog(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values) {
  auto result = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::PrimaryWeights make_primary(
    const mwperf::ResolvedInstance& instance,
    std::vector<mwperf::BigNat> values) {
  auto result = mwperf::PrimaryWeights::from_values(
      mwperf::QueueDimensionToken::from_instance(instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerExecutionContext execution_context(
    const mwperf::ResolvedInstance& instance) {
  auto result =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TargetIndex target(
    const mwperf::ResolvedInstance& instance, const std::size_t ordinal) {
  auto result = mwperf::TargetIndex::from_instance(instance, ordinal);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] bool crossbar_feasible(
    const mwperf::ResolvedCrossbarConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<std::uint8_t> inputs(constraint.inputs.size(), 0U);
  std::vector<std::uint8_t> outputs(constraint.outputs.size(), 0U);
  for (const mwperf::ResolvedCrossbarEdge& edge : constraint.edges) {
    if (selected[edge.queue.ordinal()] == 0U) {
      continue;
    }
    if (inputs[edge.input.ordinal()] != 0U ||
        outputs[edge.output.ordinal()] != 0U) {
      return false;
    }
    inputs[edge.input.ordinal()] = 1U;
    outputs[edge.output.ordinal()] = 1U;
  }
  return true;
}

[[nodiscard]] bool interval_feasible(
    const mwperf::ResolvedIntervalConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  for (std::size_t first = 0U; first < constraint.intervals.size(); ++first) {
    const auto& lhs = constraint.intervals[first];
    if (selected[lhs.queue.ordinal()] == 0U) {
      continue;
    }
    for (std::size_t second = first + 1U;
         second < constraint.intervals.size(); ++second) {
      const auto& rhs = constraint.intervals[second];
      if (selected[rhs.queue.ordinal()] != 0U &&
          !(lhs.right <= rhs.left || rhs.right <= lhs.left)) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool feasible(const mwperf::ConstraintDescriptor& descriptor,
                            const std::vector<std::uint8_t>& selected) {
  return std::visit(
      [&selected](const auto& constraint) {
        using Constraint = std::decay_t<decltype(constraint)>;
        if constexpr (std::is_same_v<Constraint,
                                     mwperf::ResolvedCrossbarConstraint>) {
          return crossbar_feasible(constraint, selected);
        } else if constexpr (std::is_same_v<
                                 Constraint,
                                 mwperf::ResolvedIntervalConstraint>) {
          return interval_feasible(constraint, selected);
        } else {
          return false;
        }
      },
      descriptor.value());
}

[[nodiscard]] mwperf::BigNat exhaustive_forced_primary(
    const mwperf::ConstraintDescriptor& descriptor,
    const mwperf::EligibilityMask& eligibility,
    const mwperf::PrimaryWeights& primary, const std::size_t target_queue,
    const mwperf::ForcedTargetBit bit) {
  REQUIRE(primary.size() < std::numeric_limits<std::uint64_t>::digits);
  std::optional<mwperf::BigNat> best;
  const std::uint64_t schedule_count =
      std::uint64_t{1U} << primary.size();
  for (std::uint64_t mask = 0U; mask < schedule_count; ++mask) {
    std::vector<std::uint8_t> selected(primary.size(), 0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      selected[queue] =
          static_cast<std::uint8_t>((mask >> queue) & std::uint64_t{1U});
      if (queue != target_queue && selected[queue] != 0U &&
          eligibility.bytes()[queue] == 0U) {
        allowed = false;
      }
    }
    const bool target_required = bit == mwperf::ForcedTargetBit::one;
    if ((selected[target_queue] != 0U) != target_required) {
      allowed = false;
    }
    if (!allowed || !feasible(descriptor, selected)) {
      continue;
    }

    mwperf::BigNat objective(0U);
    for (std::size_t queue = 0U; queue < primary.size(); ++queue) {
      if (queue != target_queue && selected[queue] != 0U) {
        objective += primary.values()[queue];
      }
    }
    if (!best.has_value() || objective > *best) {
      best = std::move(objective);
    }
  }
  REQUIRE(best.has_value());
  return std::move(*best);
}

[[nodiscard]] std::string queue_list(const std::size_t count) {
  std::ostringstream output;
  output << '[';
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"q" << queue << "\"";
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string large_crossbar_scheduler(const std::size_t count) {
  std::ostringstream output;
  output << R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":[)";
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"i" << queue << "\"";
  }
  output << R"(],"outputs":[)";
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "\"o" << queue << "\"";
  }
  output << R"(],"edges":[)";
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "{\"queue_id\":\"q" << queue
           << "\",\"input\":\"i" << queue
           << "\",\"output\":\"o" << queue << "\"}";
  }
  output << R"(]},"priority":null}})";
  return output.str();
}

[[nodiscard]] std::string large_interval_scheduler(const std::size_t count) {
  std::ostringstream output;
  output << R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[)";
  for (std::size_t queue = 0U; queue < count; ++queue) {
    if (queue != 0U) {
      output << ',';
    }
    output << "{\"queue_id\":\"q" << queue << "\",\"left\":"
           << queue << ",\"right\":" << queue + 1U << '}';
  }
  output << R"(]},"priority":null}})";
  return output.str();
}

[[nodiscard]] mwperf::Result<mwperf::CompiledConstraintProduct>
fixture_product(const mwperf::ServiceFamily family) {
  std::shared_ptr<const void> owner =
      std::make_shared<const std::string>(mwperf::to_string(family));
  return mwperf::CompiledConstraintProduct::for_fixture(family,
                                                        std::move(owner));
}

[[nodiscard]] mwperf::detail::ConstraintCompilerServices fixture_compilers() {
  mwperf::detail::ConstraintCompilerServices services;
  services.crossbar = [](const mwperf::ResolvedCrossbarConstraint&) {
    return fixture_product(mwperf::ServiceFamily::crossbar_matching);
  };
  services.intervals = [](const mwperf::ResolvedIntervalConstraint&) {
    return fixture_product(
        mwperf::ServiceFamily::nonoverlapping_intervals);
  };
  services.node_exclusive =
      [](const mwperf::ResolvedNodeExclusiveConstraint&) {
        return fixture_product(
            mwperf::ServiceFamily::node_exclusive_matching);
      };
  services.conflicts = [](const mwperf::ResolvedConflictConstraint&) {
    return fixture_product(mwperf::ServiceFamily::pairwise_conflicts);
  };
  services.packing = [](const mwperf::ResolvedPackingConstraint&) {
    return fixture_product(mwperf::ServiceFamily::resource_packing);
  };
  return services;
}

[[nodiscard]] mwperf::Diagnostic trap_diagnostic() {
  return mwperf::Diagnostic{
      .category = mwperf::DiagnosticCategory::internal,
      .code = "c06_fallback_trap",
      .message = "a C06 backend was incorrectly used as a fallback",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

}  // namespace

TEST_CASE("C06 production compile and dispatch satisfy the common exact ABI",
          "[c06][integration][dispatch]") {
  for (const C06FamilyCase& family_case : small_c06_cases()) {
    const auto instance = resolved_c06(family_case.scheduler);
    INFO(mwperf::to_string(family_case.family));
    CHECK(instance.constraint().family() == family_case.family);
    CHECK(instance.constraint().identity().optimizer == family_case.backend);

    const auto primary = make_primary(
        instance,
        {mwperf::BigNat(9U), mwperf::BigNat(6U), mwperf::BigNat(7U)});
    const auto eligibility = mwperf::EligibilityMask::all(
        mwperf::QueueDimensionToken::from_instance(instance));
    auto weights = mwperf::compose_lexicographic_weights(
        primary, instance.priority(), eligibility);
    REQUIRE(weights);

    auto context = execution_context(instance);
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(budget.value().set_query_kind(
        mwperf::OptimizerQueryKind::ordinary));
    auto solution = mwperf::solve_exact(instance.constraint(), eligibility,
                                        weights.value(), budget.value());
    INFO((solution ? std::string{} : solution.error().code));
    REQUIRE(solution);

    // Invoke the public common checker independently of the dispatcher's
    // mandatory transactional validation.
    auto validation = mwperf::validate_optimizer_solution(
        solution.value(), instance.constraint(), eligibility,
        weights.value());
    INFO((validation ? std::string{} : validation.error().code));
    REQUIRE(validation);
    CHECK(std::ranges::equal(solution.value().schedule().bytes(),
                             std::vector<std::uint8_t>{0U, 1U, 1U}));
    CHECK(solution.value().composite_objective().to_decimal_string() ==
          "107");
    CHECK(solution.value().family() == family_case.family);
    CHECK(solution.value().backend_id() == family_case.backend);
    CHECK(solution.value().accounting().completed_expansions().is_zero());
    CHECK(budget.value().completed_expansions().is_zero());

    auto resolver_context = execution_context(instance);
    auto decision = mwperf::resolve_maxweight_schedule(
        instance,
        make_backlog(instance, {mwperf::BigNat(9U), mwperf::BigNat(6U),
                                mwperf::BigNat(7U)}),
        mwperf::TieContext::configured_priority(), resolver_context);
    REQUIRE(decision);
    CHECK(decision.value().schedule == solution.value().schedule());
    CHECK(decision.value().primary_objective.to_decimal_string() == "13");
    CHECK(decision.value().priority_code.to_decimal_string() == "3");
    CHECK(decision.value().composite_objective ==
          solution.value().composite_objective());
    CHECK(decision.value().accounting.completed_expansions().is_zero());
  }
}

TEST_CASE("C06 dispatch translates backend workspace allocation failures",
          "[c06][integration][negative][transactional]") {
  const auto instance = resolved_c06(small_c06_cases().front().scheduler);
  const auto primary = make_primary(
      instance,
      {mwperf::BigNat(3U), mwperf::BigNat(2U), mwperf::BigNat(1U)});
  const auto eligibility = mwperf::EligibilityMask::all(
      mwperf::QueueDimensionToken::from_instance(instance));
  auto weights = mwperf::compose_lexicographic_weights(
      primary, instance.priority(), eligibility);
  REQUIRE(weights);

  const auto run = [&](const bool length_failure) {
    mwperf::detail::ExactOptimizerBackendServices services;
    services.crossbar =
        [length_failure](
            const mwperf::ResolvedCrossbarConstraint&,
            const mwperf::CompiledConstraintProduct&,
            const mwperf::EligibilityMask&, const mwperf::LexWeights&,
            mwperf::SearchBudget&,
            const std::optional<mwperf::detail::ForcedTargetCondition>&,
            const mwperf::detail::ExactBackendAuthority&)
        -> mwperf::Result<mwperf::detail::ExactBackendCandidate> {
      if (length_failure) {
        throw std::length_error("injected C06 representation failure");
      }
      throw std::bad_alloc{};
    };

    auto context = execution_context(instance);
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(budget.value().set_query_kind(
        mwperf::OptimizerQueryKind::ordinary));
    return mwperf::detail::solve_exact_with_backend_services(
        instance.constraint(), eligibility, weights.value(), budget.value(),
        std::nullopt, services);
  };

  auto allocation = run(false);
  REQUIRE_FALSE(allocation);
  CHECK(allocation.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(allocation.error().code == "optimizer_dispatch_allocation_failure");

  auto representation = run(true);
  REQUIRE_FALSE(representation);
  CHECK(representation.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(representation.error().code ==
        "optimizer_dispatch_representation_failure");
}

TEST_CASE("C06 repeated cold production solves are byte-deterministic",
          "[c06][integration][determinism]") {
  for (const C06FamilyCase& family_case : small_c06_cases()) {
    const auto instance = resolved_c06(family_case.scheduler);
    const auto queue = make_backlog(
        instance,
        {mwperf::BigNat(9U), mwperf::BigNat(6U), mwperf::BigNat(7U)});
    auto first_context = execution_context(instance);
    auto second_context = execution_context(instance);
    auto first = mwperf::resolve_maxweight_schedule(
        instance, queue, mwperf::TieContext::configured_priority(),
        first_context);
    auto second = mwperf::resolve_maxweight_schedule(
        instance, queue, mwperf::TieContext::configured_priority(),
        second_context);
    INFO(mwperf::to_string(family_case.family));
    REQUIRE(first);
    REQUIRE(second);

    CHECK(first.value() == second.value());
    CHECK(std::ranges::equal(first.value().schedule.bytes(),
                             second.value().schedule.bytes()));
    CHECK(first.value().primary_objective.to_decimal_string() ==
          second.value().primary_objective.to_decimal_string());
    CHECK(first.value().composite_objective.to_decimal_string() ==
          second.value().composite_objective.to_decimal_string());
    CHECK(first.value().priority_code.to_decimal_string() ==
          second.value().priority_code.to_decimal_string());
    CHECK(first.value().accounting.completed_expansions().is_zero());
    CHECK(second.value().accounting.completed_expansions().is_zero());
    CHECK(first_context.ledger_snapshot()
              .calls_reserved()
              .to_decimal_string() == "1");
    CHECK(second_context.ledger_snapshot()
              .calls_reserved()
              .to_decimal_string() == "1");
  }
}

TEST_CASE("C06 both polynomial paths remain exact above sixty-four queues",
          "[c06][integration][multiprecision]") {
  constexpr std::size_t queue_count = 65U;
  mwperf::BigInt huge_value = 1;
  huge_value <<= 200U;
  auto huge_result = mwperf::BigNat::from_big_int(std::move(huge_value));
  REQUIRE(huge_result);
  const mwperf::BigNat huge = std::move(huge_result).value();

  const std::vector<C06FamilyCase> cases{
      {large_crossbar_scheduler(queue_count),
       mwperf::ServiceFamily::crossbar_matching,
       mwperf::OptimizerId::hungarian_exact},
      {large_interval_scheduler(queue_count),
       mwperf::ServiceFamily::nonoverlapping_intervals,
       mwperf::OptimizerId::weighted_interval_dp_exact},
  };
  for (const C06FamilyCase& family_case : cases) {
    const auto instance =
        resolved_c06(family_case.scheduler, queue_list(queue_count));
    std::vector<mwperf::BigNat> values(queue_count, mwperf::BigNat(1U));
    values.front() = huge;
    mwperf::BigNat expected = huge;
    for (std::size_t queue = 1U; queue < queue_count; ++queue) {
      expected += mwperf::BigNat(1U);
    }

    auto context = execution_context(instance);
    auto decision = mwperf::resolve_maxweight_schedule(
        instance, make_backlog(instance, std::move(values)),
        mwperf::TieContext::configured_priority(), context);
    INFO(mwperf::to_string(family_case.family));
    INFO((decision ? std::string{} : decision.error().code));
    REQUIRE(decision);
    CHECK(decision.value().schedule.size() == queue_count);
    CHECK(std::ranges::all_of(
        decision.value().schedule.bytes(),
        [](const std::uint8_t selected) { return selected == 1U; }));
    CHECK(decision.value().primary_objective == expected);
    CHECK(decision.value().primary_objective.bit_length() == 201U);
    CHECK(decision.value().composite_objective.bit_length() > 256U);
    CHECK(decision.value().family == family_case.family);
    CHECK(decision.value().backend_id == family_case.backend);
    CHECK(decision.value().accounting.completed_expansions().is_zero());
  }
}

TEST_CASE("C06 forced-target primary faces agree with independent enumeration",
          "[c06][integration][forced-target]") {
  for (const C06FamilyCase& family_case : forced_c06_cases()) {
    const auto instance =
        resolved_c06(family_case.scheduler, R"(["q0","q1","q2","q3"])");
    const auto dimension =
        mwperf::QueueDimensionToken::from_instance(instance);
    auto eligibility_result = mwperf::EligibilityMask::from_bytes(
        dimension, {0U, 1U, 1U, 1U});
    REQUIRE(eligibility_result);
    const mwperf::EligibilityMask eligibility =
        std::move(eligibility_result).value();

    mwperf::BigInt enormous_value = 1;
    enormous_value <<= 180U;
    auto enormous_result =
        mwperf::BigNat::from_big_int(std::move(enormous_value));
    REQUIRE(enormous_result);
    const mwperf::BigNat enormous = std::move(enormous_result).value();

    const auto ordinary_target_weight = make_primary(
        instance, {mwperf::BigNat(1000U), mwperf::BigNat(7U),
                   mwperf::BigNat(5U), mwperf::BigNat(3U)});
    const auto changed_target_weight = make_primary(
        instance, {enormous, mwperf::BigNat(7U), mwperf::BigNat(5U),
                   mwperf::BigNat(3U)});
    const auto selected_target = target(instance, 0U);

    const auto solve_side =
        [&](const mwperf::PrimaryWeights& primary,
            const mwperf::ForcedTargetBit bit) {
          auto context = execution_context(instance);
          auto result = mwperf::solve_forced_target(
              context, instance.constraint(), eligibility, primary,
              selected_target, bit, instance.priority());
          INFO(mwperf::to_string(family_case.family));
          INFO((result ? std::string{} : result.error().code));
          REQUIRE(result);
          CHECK(result.value().accounting.completed_expansions().is_zero());
          CHECK(result.value().family == family_case.family);
          CHECK(result.value().backend_id == family_case.backend);
          CHECK((result.value().witness.bytes()[0U] != 0U) ==
                (bit == mwperf::ForcedTargetBit::one));
          CHECK(feasible(instance.constraint(),
                         std::vector<std::uint8_t>(
                             result.value().witness.bytes().begin(),
                             result.value().witness.bytes().end())));
          CHECK(result.value().value == exhaustive_forced_primary(
                                             instance.constraint(),
                                             eligibility, primary, 0U, bit));
          return std::move(result).value();
        };

    const auto psi_zero = solve_side(ordinary_target_weight,
                                     mwperf::ForcedTargetBit::zero);
    const auto psi_one = solve_side(ordinary_target_weight,
                                    mwperf::ForcedTargetBit::one);
    const auto changed_psi_zero = solve_side(changed_target_weight,
                                             mwperf::ForcedTargetBit::zero);
    const auto changed_psi_one = solve_side(changed_target_weight,
                                            mwperf::ForcedTargetBit::one);

    CHECK(psi_zero.value.to_decimal_string() == "15");
    CHECK(psi_one.value.to_decimal_string() == "8");
    CHECK(psi_zero.secondary_code.to_decimal_string() == "7");
    CHECK(psi_one.secondary_code.to_decimal_string() == "11");
    CHECK(std::ranges::equal(psi_zero.witness.bytes(),
                             std::vector<std::uint8_t>{0U, 1U, 1U, 1U}));
    CHECK(std::ranges::equal(psi_one.witness.bytes(),
                             std::vector<std::uint8_t>{1U, 0U, 1U, 1U}));

    // q0 began ordinarily ineligible, yet forced one commits it. Changing
    // only q0's primary score cannot affect either residual optimum or its
    // deterministic witness because Psi scores only non-target coordinates.
    CHECK(changed_psi_zero == psi_zero);
    CHECK(changed_psi_one == psi_one);

    // Forced zero actively clears the target as well as preserving an already
    // absent target. Its large ordinary primary coordinate must not leak into
    // the residual objective when it starts eligible.
    const auto all_eligible = mwperf::EligibilityMask::all(dimension);
    auto eligible_context = execution_context(instance);
    auto eligible_zero = mwperf::solve_forced_target(
        eligible_context, instance.constraint(), all_eligible,
        ordinary_target_weight, selected_target,
        mwperf::ForcedTargetBit::zero, instance.priority());
    REQUIRE(eligible_zero);
    CHECK(eligible_zero.value().value == psi_zero.value);
    CHECK(eligible_zero.value().secondary_code == psi_zero.secondary_code);
    CHECK(eligible_zero.value().witness == psi_zero.witness);
  }
}

TEST_CASE("C06 forced residual ties follow the supplied composite priority",
          "[c06][integration][forced-target][priority]") {
  struct PriorityPair final {
    std::string forward;
    std::string reverse;
  };
  const std::vector<PriorityPair> pairs{
      {
          R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1","o2"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"},{"queue_id":"q2","input":"i1","output":"o2"}]},"priority":["q0","q1","q2"]}})",
          R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1","o2"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"},{"queue_id":"q2","input":"i1","output":"o2"}]},"priority":["q0","q2","q1"]}})",
      },
      {
          R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2},{"queue_id":"q2","left":1,"right":2}]},"priority":["q0","q1","q2"]}})",
          R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2},{"queue_id":"q2","left":1,"right":2}]},"priority":["q0","q2","q1"]}})",
      },
  };

  for (const PriorityPair& pair : pairs) {
    const auto solve_priority = [](const std::string& scheduler,
                                   const std::size_t expected_residual) {
      const auto instance = resolved_c06(scheduler);
      const auto dimension =
          mwperf::QueueDimensionToken::from_instance(instance);
      const auto eligibility = mwperf::EligibilityMask::all(dimension);
      const auto primary = make_primary(
          instance,
          {mwperf::BigNat(999U), mwperf::BigNat(5U), mwperf::BigNat(5U)});
      const auto selected_target = target(instance, 0U);

      for (const mwperf::ForcedTargetBit side :
           {mwperf::ForcedTargetBit::zero,
            mwperf::ForcedTargetBit::one}) {
        auto context = execution_context(instance);
        auto result = mwperf::solve_forced_target(
            context, instance.constraint(), eligibility, primary,
            selected_target, side, instance.priority());
        REQUIRE(result);
        CHECK(result.value().value.to_decimal_string() == "5");
        CHECK(result.value().witness.bytes()[0U] ==
              (side == mwperf::ForcedTargetBit::one ? 1U : 0U));
        CHECK(result.value().witness.bytes()[expected_residual] == 1U);
        CHECK(result.value().witness.bytes()[3U - expected_residual] == 0U);
        CHECK(result.value().secondary_code.to_decimal_string() ==
              (side == mwperf::ForcedTargetBit::one ? "6" : "2"));
      }
    };

    solve_priority(pair.forward, 1U);
    solve_priority(pair.reverse, 2U);
  }
}

TEST_CASE("C06 production dispatch rejects untyped fixture products before recovery",
          "[c06][integration][negative][dispatch]") {
  for (const C06FamilyCase& family_case : small_c06_cases()) {
    const ParsedPair pair =
        parse_pair(family_case.scheduler, R"(["q0","q1","q2"])");
    auto catalog = mwperf::build_queue_catalog(pair.model.switch_config);
    REQUIRE(catalog);
    auto priority =
        mwperf::resolve_priority(pair.model.scheduler, catalog.value());
    REQUIRE(priority);

    const auto compilers = fixture_compilers();
    auto descriptor =
        mwperf::detail::compile_constraint_descriptor_with_child_services(
            pair.model.scheduler, catalog.value(), compilers);
    REQUIRE(descriptor);
    REQUIRE(descriptor.value().family() == family_case.family);

    const mwperf::OptimizerBudgetPolicy policy{
        .physical_per_call = std::nullopt,
        .analysis_per_call = std::nullopt,
        .effective_per_call = std::nullopt,
        .max_calls = mwperf::BigNat(1U),
    };
    const auto dimension = mwperf::QueueDimensionToken::for_fixture(
        pair.fingerprints.combined, catalog.value().size(), descriptor.value(),
        priority.value(), policy);
    auto primary = mwperf::PrimaryWeights::from_values(
        dimension,
        {mwperf::BigNat(3U), mwperf::BigNat(2U), mwperf::BigNat(1U)});
    REQUIRE(primary);
    const auto eligibility = mwperf::EligibilityMask::all(dimension);
    auto weights = mwperf::compose_lexicographic_weights(
        primary.value(), priority.value(), eligibility);
    REQUIRE(weights);
    auto context = mwperf::OptimizerExecutionContext::for_fixture(
        policy, std::nullopt, dimension);
    REQUIRE(context);
    auto budget = mwperf::begin_search_budget(context.value());
    REQUIRE(budget);
    REQUIRE(budget.value().set_query_kind(
        mwperf::OptimizerQueryKind::ordinary));

    auto solved = mwperf::solve_exact(descriptor.value(), eligibility,
                                      weights.value(), budget.value());
    REQUIRE_FALSE(solved);
    CHECK(solved.error().category == mwperf::DiagnosticCategory::internal);
    CHECK(solved.error().code ==
          (family_case.family == mwperf::ServiceFamily::crossbar_matching
               ? "crossbar_compiled_product_type_mismatch"
               : "interval_compiled_product_type_mismatch"));
    CHECK(budget.value().completed_expansions().is_zero());
  }
}

TEST_CASE("C06 raw primitives reject a same-size foreign family query",
          "[c06][integration][negative][dimension]") {
  const std::vector<C06FamilyCase> cases = small_c06_cases();
  REQUIRE(cases.size() == 2U);
  const mwperf::ResolvedInstance crossbar = resolved_c06(cases[0U].scheduler);
  const mwperf::ResolvedInstance intervals = resolved_c06(cases[1U].scheduler);

  const auto& crossbar_geometry =
      std::get<mwperf::ResolvedCrossbarConstraint>(
          crossbar.constraint().value());
  auto crossbar_problem =
      mwperf::compile_crossbar_problem(crossbar_geometry);
  REQUIRE(crossbar_problem);
  const auto& interval_geometry =
      std::get<mwperf::ResolvedIntervalConstraint>(
          intervals.constraint().value());
  auto interval_problem =
      mwperf::compile_interval_problem(interval_geometry);
  REQUIRE(interval_problem);

  const auto crossbar_primary = make_primary(
      crossbar,
      {mwperf::BigNat(3U), mwperf::BigNat(2U), mwperf::BigNat(1U)});
  const auto crossbar_eligibility =
      mwperf::EligibilityMask::all(crossbar_primary.dimension());
  auto crossbar_weights = mwperf::compose_lexicographic_weights(
      crossbar_primary, crossbar.priority(), crossbar_eligibility);
  REQUIRE(crossbar_weights);

  const auto interval_primary = make_primary(
      intervals,
      {mwperf::BigNat(3U), mwperf::BigNat(2U), mwperf::BigNat(1U)});
  const auto interval_eligibility =
      mwperf::EligibilityMask::all(interval_primary.dimension());
  auto interval_weights = mwperf::compose_lexicographic_weights(
      interval_primary, intervals.priority(), interval_eligibility);
  REQUIRE(interval_weights);

  auto interval_with_crossbar_query = mwperf::detail::solve_interval_exact(
      interval_problem.value(), crossbar_eligibility,
      crossbar_weights.value(), nullptr);
  REQUIRE_FALSE(interval_with_crossbar_query);
  CHECK(interval_with_crossbar_query.error().code ==
        "interval_query_family_mismatch");

  auto crossbar_with_interval_query = mwperf::detail::solve_crossbar_exact(
      crossbar_problem.value(), interval_eligibility,
      interval_weights.value(), nullptr);
  REQUIRE_FALSE(crossbar_with_interval_query);
  CHECK(crossbar_with_interval_query.error().code ==
        "crossbar_query_family_mismatch");
}

TEST_CASE("C06 registrations remain isolated from current C08 families",
          "[c06][integration][negative][dispatch]") {
  struct CurrentFamilyCase final {
    std::string scheduler;
    mwperf::ServiceFamily family;
  };
  const std::vector<CurrentFamilyCase> cases{
      {
          R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":null,"max_search_states":9}})",
          mwperf::ServiceFamily::pairwise_conflicts,
      },
      {
          R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]}]},"priority":null,"max_search_states":9}})",
          mwperf::ServiceFamily::resource_packing,
      },
  };

  for (const CurrentFamilyCase& current : cases) {
    const ParsedPair pair = parse_pair(current.scheduler, R"(["q0","q1"])");
    auto catalog = mwperf::build_queue_catalog(pair.model.switch_config);
    REQUIRE(catalog);
    auto priority =
        mwperf::resolve_priority(pair.model.scheduler, catalog.value());
    REQUIRE(priority);

    auto descriptor = mwperf::compile_constraint_descriptor(
        pair.model.scheduler, catalog.value());
    INFO(mwperf::to_string(current.family));
    REQUIRE(descriptor);
    REQUIRE(descriptor.value().family() == current.family);
    REQUIRE(descriptor.value().compiled_product().has_owner());

    const mwperf::OptimizerBudgetPolicy policy{
        .physical_per_call = std::nullopt,
        .analysis_per_call = mwperf::BigNat(5U),
        .effective_per_call = mwperf::BigNat(5U),
        .max_calls = mwperf::BigNat(2U),
    };
    const auto dimension = mwperf::QueueDimensionToken::for_fixture(
        pair.fingerprints.combined, catalog.value().size(),
        descriptor.value(), priority.value(), policy);
    auto primary = mwperf::PrimaryWeights::from_values(
        dimension, {mwperf::BigNat(2U), mwperf::BigNat(1U)});
    REQUIRE(primary);
    const auto eligibility = mwperf::EligibilityMask::all(dimension);
    auto weights = mwperf::compose_lexicographic_weights(
        primary.value(), priority.value(), eligibility);
    REQUIRE(weights);

    bool c06_fallback_called = false;
    mwperf::detail::ExactOptimizerBackendServices services;
    services.crossbar =
        [&c06_fallback_called](
            const mwperf::ResolvedCrossbarConstraint&,
            const mwperf::CompiledConstraintProduct&,
            const mwperf::EligibilityMask&, const mwperf::LexWeights&,
            mwperf::SearchBudget&,
            const std::optional<mwperf::detail::ForcedTargetCondition>&,
            const mwperf::detail::ExactBackendAuthority&) {
          c06_fallback_called = true;
          return mwperf::Result<mwperf::detail::ExactBackendCandidate>::failure(
              trap_diagnostic());
        };
    services.intervals =
        [&c06_fallback_called](
            const mwperf::ResolvedIntervalConstraint&,
            const mwperf::CompiledConstraintProduct&,
            const mwperf::EligibilityMask&, const mwperf::LexWeights&,
            mwperf::SearchBudget&,
            const std::optional<mwperf::detail::ForcedTargetCondition>&,
            const mwperf::detail::ExactBackendAuthority&) {
          c06_fallback_called = true;
          return mwperf::Result<mwperf::detail::ExactBackendCandidate>::failure(
              trap_diagnostic());
        };

    auto context = mwperf::OptimizerExecutionContext::for_fixture(
        policy, std::nullopt, dimension);
    REQUIRE(context);
    auto budget = mwperf::begin_search_budget(context.value());
    REQUIRE(budget);
    REQUIRE(budget.value().set_query_kind(
        mwperf::OptimizerQueryKind::ordinary));
    auto solve = mwperf::detail::solve_exact_with_backend_services(
        descriptor.value(), eligibility, weights.value(), budget.value(),
        std::nullopt, services);
    REQUIRE_FALSE(solve);
    CHECK(solve.error().category == mwperf::DiagnosticCategory::internal);
    CHECK(solve.error().code ==
          "optimizer_registered_backend_route_missing");
    CHECK_FALSE(c06_fallback_called);
    CHECK(budget.value().completed_expansions().is_zero());
    CHECK(context.value()
              .ledger_snapshot()
              .calls_reserved()
              .to_decimal_string() == "1");
  }
}
