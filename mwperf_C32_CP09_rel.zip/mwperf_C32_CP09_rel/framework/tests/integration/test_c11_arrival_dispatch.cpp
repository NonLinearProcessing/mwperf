#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct ParsedArrival final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

struct ExpectedEntry final {
  std::size_t queue;
  std::string_view count;
};

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c11-arrival-dispatch";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string model_document(const std::string_view arrival) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight",
                 "params":{"constraint":{"conflicts":[]},
                           "priority":["q0","q1","q2"],
                           "max_search_states":null}},
    "arrival":)json") +
         std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] ParsedArrival parse_arrival(const std::string_view arrival) {
  auto document = mwperf::load_document(write_fixture(model_document(arrival)));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedArrival{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t realization) {
  auto digest = mwperf::sha256(std::span<const std::byte>{});
  REQUIRE(digest);
  auto key = mwperf::make_physical_reference_instance_key(
      digest.value(), mwperf::BigNat(realization));
  REQUIRE(key);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::ArrivalInitialState& initial_state,
    const std::uint64_t seed = 1111U,
    const std::uint64_t realization = 0U) {
  auto stream = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, realization));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law, initial_state, std::move(stream).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::SourceNode initial_source_node() {
  return mwperf::SourceNode::make_object(
      std::vector<mwperf::SourceObjectMember>{},
      mwperf::SourceLocation{"c11-arrival-dispatch", 1U, 1U, 0U},
      "/arrival_state");
}

[[nodiscard]] mwperf::ArrivalInitialState private_state(
    const std::string_view source, const std::string_view state) {
  std::vector<mwperf::PrivateMarkovState> values;
  values.push_back(mwperf::PrivateMarkovState{
      std::string(source), std::string(state), initial_source_node()});
  return mwperf::PrivateMarkovStates{std::move(values)};
}

void check_batch(const mwperf::ArrivalStep& step,
                 const std::span<const ExpectedEntry> expected) {
  REQUIRE(step.batch.entries().size() == expected.size());
  for (std::size_t index = 0U; index < expected.size(); ++index) {
    CHECK(step.batch.entries()[index].queue.ordinal() == expected[index].queue);
    CHECK(step.batch.entries()[index].count.to_decimal_string() ==
          expected[index].count);
  }
  CHECK(step.physical_arrival_epoch() == step.authored_slot + mwperf::BigNat(1U));
}

void check_same_step(const mwperf::ArrivalStep& left,
                     const mwperf::ArrivalStep& right) {
  CHECK(left.authored_slot == right.authored_slot);
  CHECK(left.batch == right.batch);
  CHECK(left.law_digest == right.law_digest);
  CHECK(left.realization_identity == right.realization_identity);
  CHECK(mwperf::arrival_phase_family(left.phase_before) ==
        mwperf::arrival_phase_family(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_before) ==
        mwperf::arrival_phase_digest(right.phase_before));
  CHECK(mwperf::arrival_phase_digest(left.phase_after) ==
        mwperf::arrival_phase_digest(right.phase_after));
  const auto left_before =
      mwperf::arrival_phase_canonical_state(left.phase_before);
  const auto right_before =
      mwperf::arrival_phase_canonical_state(right.phase_before);
  CHECK(std::vector<std::byte>(left_before.begin(), left_before.end()) ==
        std::vector<std::byte>(right_before.begin(), right_before.end()));
  const auto left_after =
      mwperf::arrival_phase_canonical_state(left.phase_after);
  const auto right_after =
      mwperf::arrival_phase_canonical_state(right.phase_after);
  CHECK(std::vector<std::byte>(left_after.begin(), left_after.end()) ==
        std::vector<std::byte>(right_after.begin(), right_after.end()));
}

void check_conservative_capabilities(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::PortableArrivalLawSchema expected_schema) {
  const mwperf::ArrivalCapabilities capabilities =
      mwperf::arrival_capabilities(law);
  CHECK(capabilities.exact_positive_support ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.sequential_normalized_sampler ==
        mwperf::CapabilityAvailability::available);
  CHECK(capabilities.finite_enumerated_predictive_phase ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.finite_enumerated_transition_row ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.stationary_phase_law ==
        mwperf::StationaryPhaseLawStatus::unavailable);
  CHECK_FALSE(capabilities.analytic_transform.has_value());
  CHECK_FALSE(capabilities.analytic_moments.has_value());
  CHECK_FALSE(capabilities.exact_iid_joint_vector.has_value());
  CHECK_FALSE(capabilities.exact_joint_moments.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_moments.has_value());
  CHECK(capabilities.exact_covariance ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK(capabilities.exact_cross_moments ==
        mwperf::CapabilityAvailability::unavailable);
  CHECK_FALSE(capabilities.exact_joint_distribution.has_value());
  CHECK_FALSE(capabilities.exact_coordinate_distributions.has_value());
  CHECK_FALSE(capabilities.adjacent_batch_replay.has_value());
  CHECK_FALSE(capabilities.unit_cube_transform.has_value());

  const mwperf::BuilderArrivalView view = mwperf::builder_arrival_view(law);
  CHECK(view.configured_law().schema == expected_schema);
  CHECK(view.configured_law().version == 1U);
  CHECK(view.binding() == mwperf::arrival_law_binding(law));
  CHECK(view.capabilities() == capabilities);
  CHECK_FALSE(view.configured_law().canonical_data.empty());
}

struct FamilyFixture final {
  std::string_view arrival;
  mwperf::ArrivalFamily family;
  mwperf::PortableArrivalLawSchema schema;
  mwperf::ArrivalInitialState initial;
};

[[nodiscard]] std::vector<FamilyFixture> six_family_fixtures() {
  return {
      {R"json({"family":"deterministic_trace","events":[
          {"slot":0,"queue_id":"q0","count":1}],"metadata":{}})json",
       mwperf::ArrivalFamily::deterministic_trace,
       mwperf::PortableArrivalLawSchema::deterministic_trace_v1,
       mwperf::TraceOrigin{}},
      {R"json({"family":"periodic_global_phase","period":2,"phase":0,
          "sources":[{"id":"s","entries":[
            {"offset":0,"queue_id":"q0","count":1}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::periodic_global_phase,
       mwperf::PortableArrivalLawSchema::periodic_global_phase_v1,
       mwperf::GlobalPeriodicOrigin{}},
      {R"json({"family":"periodic_source_delays","period":2,
          "sources":[{"id":"s","delay":0,"entries":[
            {"offset":0,"queue_id":"q0","count":1}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::periodic_source_delays,
       mwperf::PortableArrivalLawSchema::periodic_source_delays_v1,
       mwperf::SourceDelayOrigin{}},
      {R"json({"family":"independent_marked_renewal","sources":[{
          "id":"s","interarrival":{"kind":"deterministic","d":1},
          "destination_pmf":[{"queue_id":"q0","probability":1}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::independent_marked_renewal,
       mwperf::PortableArrivalLawSchema::independent_marked_renewal_v1,
       mwperf::RenewalOrigin{}},
      {R"json({"family":"independent_private_markov_renewal","sources":[{
          "id":"s","states":["on"],"initial":{"state":"on"},
          "gaps":[{"state":"on","d":1}],
          "transitions":[{"state":"on","next_state":"on",
                          "probability":1}],
          "destination_pmf":[{"queue_id":"q0","probability":1}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::independent_private_markov_renewal,
       mwperf::PortableArrivalLawSchema::
           independent_private_markov_renewal_v1,
       private_state("s", "on")},
      {R"json({"family":"shared_joint_round_markov_renewal",
          "sources":[{"id":"s"}],"states":["on"],
          "initial":{"state":"on"},
          "outcomes":[{"state":"on","next_state":"on","probability":1,
            "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]}],
          "metadata":{}})json",
       mwperf::ArrivalFamily::shared_joint_round_markov_renewal,
       mwperf::PortableArrivalLawSchema::
           shared_joint_round_markov_renewal_v1,
       mwperf::SharedRoundState{"on"}},
  };
}

}  // namespace

TEST_CASE("C11 active registry gives all six preferred families one concrete "
          "visitor route",
          "[c11][integration]") {
  const std::vector<FamilyFixture> fixtures = six_family_fixtures();
  std::array<bool, 6U> visited{};

  for (std::size_t index = 0U; index < fixtures.size(); ++index) {
    const FamilyFixture& fixture = fixtures[index];
    CAPTURE(index, fixture.family);
    ParsedArrival parsed = parse_arrival(fixture.arrival);
    auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    INFO((!law ? law.error().code + ": " + law.error().message
               : std::string{}));
    REQUIRE(law);
    CHECK(law.value().family() == fixture.family);
    REQUIRE(law.value().variant().index() < visited.size());
    CHECK_FALSE(visited[law.value().variant().index()]);
    visited[law.value().variant().index()] = true;
    check_conservative_capabilities(law.value(), fixture.schema);

    mwperf::ArrivalProcess process = instantiate(
        law.value(), fixture.initial, 9001U, static_cast<std::uint64_t>(index));
    for (std::uint64_t slot = 0U; slot < 4U; ++slot) {
      auto step = mwperf::next_arrival_step(process, mwperf::BigNat(slot));
      INFO((!step ? step.error().code + ": " + step.error().message
                  : std::string{}));
      REQUIRE(step);
      CHECK(step.value().authored_slot == mwperf::BigNat(slot));
      CHECK(mwperf::arrival_phase_family(step.value().phase_before) ==
            fixture.family);
      CHECK(mwperf::arrival_phase_family(step.value().phase_after) ==
            fixture.family);
    }
  }
  CHECK(visited == std::array<bool, 6U>{true, true, true, true, true, true});
}

TEST_CASE("C11 stochastic visitors preserve renewal private and shared timing",
          "[c11][integration]") {
  struct TimingFixture final {
    std::string_view arrival;
    mwperf::ArrivalInitialState initial;
    std::vector<std::vector<ExpectedEntry>> expected;
    std::vector<std::uint8_t> support;
  };
  const std::vector<TimingFixture> fixtures{
      {R"json({"family":"independent_marked_renewal","sources":[{
          "id":"renewal","interarrival":{"kind":"deterministic","d":1},
          "destination_pmf":[{"queue_id":"q0","probability":1}]}],
          "metadata":{}})json",
       mwperf::RenewalOrigin{},
       {{{0U, "1"}}, {{0U, "1"}}, {{0U, "1"}}, {{0U, "1"}},
        {{0U, "1"}}},
       {1U, 0U, 0U}},
      {R"json({"family":"independent_private_markov_renewal","sources":[{
          "id":"private","states":["fast","slow"],
          "initial":{"state":"fast"},
          "gaps":[{"state":"fast","d":1},{"state":"slow","d":3}],
          "transitions":[
            {"state":"fast","next_state":"slow","probability":1},
            {"state":"slow","next_state":"fast","probability":1}],
          "destination_pmf":[{"queue_id":"q1","probability":1}]}],
          "metadata":{}})json",
       private_state("private", "fast"),
       {{{1U, "1"}}, {}, {}, {{1U, "1"}}, {{1U, "1"}}},
       {0U, 1U, 0U}},
      {R"json({"family":"shared_joint_round_markov_renewal",
          "sources":[{"id":"fast"},{"id":"slow"}],"states":["on"],
          "initial":{"state":"on"},
          "outcomes":[{"state":"on","next_state":"on","probability":1,
            "emissions":[
              {"source_id":"fast","d":1,"queue_id":"q0"},
              {"source_id":"slow","d":3,"queue_id":"q1"}]}],
          "metadata":{}})json",
       mwperf::SharedRoundState{"on"},
       {{{0U, "1"}}, {{0U, "1"}}, {{0U, "1"}, {1U, "1"}},
        {{0U, "1"}}, {{0U, "1"}}},
       {1U, 1U, 0U}},
  };

  for (std::size_t fixture_index = 0U; fixture_index < fixtures.size();
       ++fixture_index) {
    const TimingFixture& fixture = fixtures[fixture_index];
    CAPTURE(fixture_index);
    ParsedArrival parsed = parse_arrival(fixture.arrival);
    auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE(law);
    CHECK(mwperf::positive_arrival_support(law.value()).bytes() ==
          fixture.support);
    auto first = instantiate(law.value(), fixture.initial, 3301U, 7U);
    auto replay = instantiate(law.value(), fixture.initial, 3301U, 7U);

    for (std::size_t slot = 0U; slot < fixture.expected.size(); ++slot) {
      auto left = mwperf::next_arrival_step(first, mwperf::BigNat(slot));
      auto right = mwperf::next_arrival_step(replay, mwperf::BigNat(slot));
      REQUIRE(left);
      REQUIRE(right);
      check_batch(left.value(), fixture.expected[slot]);
      check_same_step(left.value(), right.value());
    }

    auto first_snapshot = mwperf::testing::snapshot_arrival_process(first);
    auto replay_snapshot = mwperf::testing::snapshot_arrival_process(replay);
    REQUIRE(first_snapshot);
    REQUIRE(replay_snapshot);
    CHECK(first_snapshot.value().expected_slot ==
          replay_snapshot.value().expected_slot);
    CHECK(first_snapshot.value().phase_digest ==
          replay_snapshot.value().phase_digest);
    CHECK(first_snapshot.value().rng.stream_identity() ==
          replay_snapshot.value().rng.stream_identity());
    CHECK(first_snapshot.value().rng.state_words() ==
          replay_snapshot.value().rng.state_words());
    CHECK(first_snapshot.value().rng.consumed_words() ==
          replay_snapshot.value().rng.consumed_words());
  }
}

TEST_CASE("C11 fixed keys replay stochastic clocks states marks and pending "
          "events",
          "[c11][integration][replay]") {
  struct ReplayFixture final {
    std::string_view arrival;
    mwperf::ArrivalInitialState initial;
  };
  const std::vector<ReplayFixture> fixtures{
      {R"json({"family":"independent_marked_renewal","sources":[{
          "id":"s","interarrival":{"kind":"finite_pmf","outcomes":[
            {"d":1,"probability":0.5},{"d":2,"probability":0.5}]},
          "destination_pmf":[
            {"queue_id":"q0","probability":0.5},
            {"queue_id":"q1","probability":0.5}]}],
          "metadata":{}})json",
       mwperf::RenewalOrigin{}},
      {R"json({"family":"independent_private_markov_renewal","sources":[{
          "id":"s","states":["a","b"],
          "initial":{"distribution":[
            {"state":"a","probability":0.5},
            {"state":"b","probability":0.5}]},
          "gaps":[{"state":"a","d":1},{"state":"b","d":2}],
          "transitions":[
            {"state":"a","next_state":"a","probability":0.5},
            {"state":"a","next_state":"b","probability":0.5},
            {"state":"b","next_state":"a","probability":0.5},
            {"state":"b","next_state":"b","probability":0.5}],
          "destination_pmf":[
            {"queue_id":"q0","probability":0.5},
            {"queue_id":"q1","probability":0.5}]}],
          "metadata":{}})json",
       private_state("s", "a")},
      {R"json({"family":"shared_joint_round_markov_renewal",
          "sources":[{"id":"left"},{"id":"right"}],
          "states":["a","b"],
          "initial":{"distribution":[
            {"state":"a","probability":0.5},
            {"state":"b","probability":0.5}]},
          "outcomes":[
            {"state":"a","next_state":"a","probability":0.5,
             "emissions":[
               {"source_id":"left","d":1,"queue_id":"q0"},
               {"source_id":"right","d":3,"queue_id":"q1"}]},
            {"state":"a","next_state":"b","probability":0.5,
             "emissions":[
               {"source_id":"left","d":2,"queue_id":"q1"},
               {"source_id":"right","d":1,"queue_id":"q0"}]},
            {"state":"b","next_state":"a","probability":0.5,
             "emissions":[
               {"source_id":"left","d":1,"queue_id":"q1"},
               {"source_id":"right","d":2,"queue_id":"q0"}]},
            {"state":"b","next_state":"b","probability":0.5,
             "emissions":[
               {"source_id":"left","d":3,"queue_id":"q0"},
               {"source_id":"right","d":1,"queue_id":"q1"}]}
          ],"metadata":{}})json",
       mwperf::SharedRoundState{"a"}},
  };

  for (std::size_t fixture_index = 0U; fixture_index < fixtures.size();
       ++fixture_index) {
    CAPTURE(fixture_index);
    ParsedArrival parsed = parse_arrival(fixtures[fixture_index].arrival);
    auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE(law);
    auto first = instantiate(law.value(), fixtures[fixture_index].initial,
                             515151U, 29U);
    auto replay = instantiate(law.value(), fixtures[fixture_index].initial,
                              515151U, 29U);
    for (std::uint64_t slot = 0U; slot < 48U; ++slot) {
      auto left = mwperf::next_arrival_step(first, mwperf::BigNat(slot));
      auto right = mwperf::next_arrival_step(replay, mwperf::BigNat(slot));
      REQUIRE(left);
      REQUIRE(right);
      check_same_step(left.value(), right.value());
    }
    auto first_snapshot = mwperf::testing::snapshot_arrival_process(first);
    auto replay_snapshot = mwperf::testing::snapshot_arrival_process(replay);
    REQUIRE(first_snapshot);
    REQUIRE(replay_snapshot);
    CHECK(first_snapshot.value().expected_slot ==
          replay_snapshot.value().expected_slot);
    CHECK(first_snapshot.value().phase_digest ==
          replay_snapshot.value().phase_digest);
    CHECK(first_snapshot.value().rng.state_words() ==
          replay_snapshot.value().rng.state_words());
    CHECK(first_snapshot.value().rng.consumed_words() ==
          replay_snapshot.value().rng.consumed_words());
    CHECK_FALSE(first_snapshot.value().rng.consumed_words().is_zero());
  }
}

TEST_CASE("C11 concrete private and shared initial states are installed without "
          "redrawing their configured marginals",
          "[c11][integration]") {
  ParsedArrival private_parsed = parse_arrival(R"json({
    "family":"independent_private_markov_renewal","sources":[{
      "id":"s","states":["fast","slow"],
      "initial":{"distribution":[
        {"state":"fast","probability":0.5},
        {"state":"slow","probability":0.5}]},
      "gaps":[{"state":"fast","d":1},{"state":"slow","d":4}],
      "transitions":[
        {"state":"fast","next_state":"fast","probability":1},
        {"state":"slow","next_state":"slow","probability":1}],
      "destination_pmf":[{"queue_id":"q0","probability":1}]}],
    "metadata":{}})json");
  auto private_law = mwperf::compile_arrival_law(
      private_parsed.model.arrival, private_parsed.queues);
  REQUIRE(private_law);
  auto private_fast = instantiate(private_law.value(), private_state("s", "fast"),
                                  8181U, 3U);
  auto private_slow = instantiate(private_law.value(), private_state("s", "slow"),
                                  8181U, 3U);
  auto private_fast_origin =
      mwperf::testing::snapshot_arrival_process(private_fast);
  auto private_slow_origin =
      mwperf::testing::snapshot_arrival_process(private_slow);
  REQUIRE(private_fast_origin);
  REQUIRE(private_slow_origin);
  CHECK(private_fast_origin.value().rng.consumed_words().is_zero());
  CHECK(private_slow_origin.value().rng.consumed_words().is_zero());
  CHECK_FALSE(private_fast_origin.value().phase_digest ==
              private_slow_origin.value().phase_digest);

  auto private_fast_zero =
      mwperf::next_arrival_step(private_fast, mwperf::BigNat(0U));
  auto private_slow_zero =
      mwperf::next_arrival_step(private_slow, mwperf::BigNat(0U));
  REQUIRE(private_fast_zero);
  REQUIRE(private_slow_zero);
  CHECK_FALSE(private_fast_zero.value().batch.empty_batch());
  CHECK(private_slow_zero.value().batch.empty_batch());

  ParsedArrival shared_parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"s"}],"states":["fast","slow"],
    "initial":{"distribution":[
      {"state":"fast","probability":0.5},
      {"state":"slow","probability":0.5}]},
    "outcomes":[
      {"state":"fast","next_state":"fast","probability":1,
       "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
      {"state":"slow","next_state":"slow","probability":1,
       "emissions":[{"source_id":"s","d":4,"queue_id":"q1"}]}],
    "metadata":{}})json");
  auto shared_law = mwperf::compile_arrival_law(
      shared_parsed.model.arrival, shared_parsed.queues);
  REQUIRE(shared_law);
  auto shared_fast = instantiate(
      shared_law.value(), mwperf::SharedRoundState{"fast"}, 9292U, 4U);
  auto shared_slow = instantiate(
      shared_law.value(), mwperf::SharedRoundState{"slow"}, 9292U, 4U);
  auto shared_fast_origin =
      mwperf::testing::snapshot_arrival_process(shared_fast);
  auto shared_slow_origin =
      mwperf::testing::snapshot_arrival_process(shared_slow);
  REQUIRE(shared_fast_origin);
  REQUIRE(shared_slow_origin);
  CHECK(shared_fast_origin.value().rng.consumed_words().is_zero());
  CHECK(shared_slow_origin.value().rng.consumed_words().is_zero());
  CHECK_FALSE(shared_fast_origin.value().phase_digest ==
              shared_slow_origin.value().phase_digest);

  auto shared_fast_zero =
      mwperf::next_arrival_step(shared_fast, mwperf::BigNat(0U));
  auto shared_slow_zero =
      mwperf::next_arrival_step(shared_slow, mwperf::BigNat(0U));
  REQUIRE(shared_fast_zero);
  REQUIRE(shared_slow_zero);
  CHECK_FALSE(shared_fast_zero.value().batch.empty_batch());
  CHECK(shared_slow_zero.value().batch.empty_batch());
}

TEST_CASE("C11 slot-zero arrivals enter only the late-admission backlog",
          "[c11][integration]") {
  const std::vector<FamilyFixture> fixtures = six_family_fixtures();
  for (std::size_t index = 3U; index < fixtures.size(); ++index) {
    CAPTURE(index);
    ParsedArrival parsed = parse_arrival(fixtures[index].arrival);
    auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE(law);
    auto process = instantiate(law.value(), fixtures[index].initial);

    const mwperf::BigNat predecision_backlog(0U);
    const bool service_selected = true;
    const mwperf::BigNat after_early_service =
        predecision_backlog.is_zero() && service_selected
            ? mwperf::BigNat(0U)
            : predecision_backlog;
    CHECK(after_early_service.is_zero());

    auto arrivals = mwperf::next_arrival_step(process, mwperf::BigNat(0U));
    REQUIRE(arrivals);
    REQUIRE(arrivals.value().batch.entries().size() == 1U);
    CHECK(arrivals.value().batch.entries()[0U].queue.ordinal() == 0U);
    CHECK(arrivals.value().batch.entries()[0U].count == mwperf::BigNat(1U));
    const mwperf::BigNat post_slot_backlog =
        after_early_service + arrivals.value().batch.entries()[0U].count;
    CHECK(post_slot_backlog == mwperf::BigNat(1U));
    CHECK(arrivals.value().physical_arrival_epoch() == mwperf::BigNat(1U));
  }
}

TEST_CASE("C11 canonical IDs compile while compatibility families remain "
          "rejected",
          "[c11][integration][negative]") {
  for (const FamilyFixture& fixture : six_family_fixtures()) {
    ParsedArrival parsed = parse_arrival(fixture.arrival);
    auto law = mwperf::detail::compile_arrival_law_with_registry(
        parsed.model.arrival, parsed.queues,
        mwperf::detail::c11_arrival_registry());
    REQUIRE(law);
    CHECK(law.value().family() == fixture.family);
  }

  ParsedArrival compatibility = parse_arrival(
      R"json({"family":"iid_table","alphabet":[{
        "id":"empty","edges":[],"probability":1}]})json");
  auto unsupported = mwperf::compile_arrival_law(
      compatibility.model.arrival, compatibility.queues);
  REQUIRE_FALSE(unsupported);
  CHECK(unsupported.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(unsupported.error().code == "unsupported_arrival_family");
}
