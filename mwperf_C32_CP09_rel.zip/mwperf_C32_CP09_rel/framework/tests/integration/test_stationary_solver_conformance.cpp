#include <algorithm>
#include <array>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <boost/multiprecision/cpp_dec_float.hpp>
#include <catch2/catch_approx.hpp>
#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "fixtures/c17/direct_v0_fixture.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/stationary/analytic.hpp"
#include "mwperf/stationary/flux.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf::testing {

Result<ResolvedInstance> C19FixtureAccess::bind_resolved_arrival_for_testing(
    const ResolvedInstance& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
  const auto reject = [](std::string code, std::string message) {
    return Result<ResolvedInstance>::failure(
        {DiagnosticCategory::input_validation, std::move(code),
         std::move(message), std::nullopt, std::nullopt, {}});
  };
  if (!configured_arrival) {
    return reject("c19.fixture_arrival_missing",
                  "the C19 bound-arrival fixture requires an exact law");
  }
  if (source.initial_law().has_value()) {
    return reject("c19.fixture_initial_law_bound_to_previous_arrival",
                  "the C19 bound-arrival fixture requires stationary "
                  "selection without a transient arrival-state law");
  }

  const PhysicalBindingIdentity physical = source.arrival().identity();
  const ArrivalBinding& binding = arrival_law_binding(*configured_arrival);
  if (physical.combined_input != source.fingerprints().combined ||
      binding.family != physical.arrival_family ||
      binding.timing != source.timing() ||
      binding.timing != physical.timing ||
      binding.queue_cardinality != source.queues().size() ||
      binding.queue_cardinality != physical.queue_cardinality) {
    return reject("c19.fixture_arrival_physical_binding_mismatch",
                  "the exact IID fixture does not match the resolved "
                  "physical arrival family, timing, or queue dimension");
  }
  auto catalog_digest = detail::digest_queue_catalog(source.queues());
  if (!catalog_digest || binding.catalog_digest != catalog_digest.value()) {
    return catalog_digest
               ? reject("c19.fixture_arrival_catalog_mismatch",
                        "the exact IID fixture does not match the resolved "
                        "queue catalog")
               : Result<ResolvedInstance>::failure(catalog_digest.error());
  }
  QueueMask support = positive_arrival_support(*configured_arrival);
  if (support.size() != source.queues().size() ||
      support.bytes() != source.positive_arrival_support().bytes()) {
    return reject("c19.fixture_arrival_support_mismatch",
                  "the exact IID fixture and authored shared-round law must "
                  "have identical positive queue support");
  }

  const ArrivalProductBindingIdentity product_identity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
  const auto references = source.arrival().queue_references();
  ConfiguredArrivalBinding rebound_arrival(
      physical,
      std::vector<BoundQueueReference>(references.begin(), references.end()),
      std::shared_ptr<const void>(configured_arrival),
      ArrivalCompiledProductKind::compiled_arrival_law_v1,
      product_identity);

  return Result<ResolvedInstance>::success(ResolvedInstance(
      source.authored_model(), source.analysis_spec(), source.fingerprints(),
      source.queues(), source.priority(), source.constraint(),
      source.service_identity(), source.serviceable(),
      source.optimizer_budget(), source.targets(), std::move(rebound_arrival),
      std::move(support), source.initial_law(), source.timing()));
}

}  // namespace mwperf::testing

namespace {

using BigFloat = boost::multiprecision::cpp_dec_float_100;
using mwperf::ExactRational;

static_assert(!std::default_initializable<
              mwperf::StationaryConditioningMassStatus>);
static_assert(!std::constructible_from<
              mwperf::StationaryConditioningMassStatus,
              mwperf::ProposalConditioningMeasureV1>);
static_assert(!std::convertible_to<
              mwperf::ProposalConditioningMeasureV1,
              mwperf::StationaryConditioningMassStatus>);

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator = 1) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] ExactRational divide(const ExactRational& numerator,
                                   const ExactRational& denominator) {
  auto value = mwperf::checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto value =
      mwperf::sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::SourceNode source(const std::string& pointer) {
  return mwperf::SourceNode::make_null(
      mwperf::SourceLocation{"c19-integration", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] mwperf::SelectionSpec stationary_unique_selection() {
  return mwperf::StationaryUniqueSelection{
      source("/selection/stationary-unique")};
}

[[nodiscard]] mwperf::SelectionSpec fixed_point_unique_selection() {
  mwperf::FixedPointSelection fixed =
      mwperf::FixedPointUniqueSelection{source("/selection/fixed-point")};
  return mwperf::SelectionSpec{std::move(fixed)};
}

[[nodiscard]] mwperf::SolverPolicy stationary_policy(
    const std::string& identity) {
  return {mwperf::LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000000LL), ExactRational::zero(),
          digest("c19.integration." + identity)};
}

[[nodiscard]] mwperf::SolverPolicy fixed_point_policy(
    const std::string& identity, const std::uint64_t iterations) {
  return {mwperf::LinearMethod::dense_pivoted, mwperf::BigNat{iterations},
          rational(1, 1000000), ExactRational::zero(),
          digest("c19.integration.fixed." + identity)};
}

[[nodiscard]] mwperf::ArrivalLaw arrival_law(
    std::vector<ExactRational> probabilities) {
  std::vector<mwperf::ScalarArrivalMassV1> atoms;
  atoms.reserve(probabilities.size());
  for (std::size_t index = 0U; index < probabilities.size(); ++index) {
    atoms.push_back({mwperf::BigNat{static_cast<std::uint64_t>(index)},
                     std::move(probabilities[index])});
  }
  auto law =
      mwperf::testing::C19FixtureAccess::arrival_law(std::move(atoms));
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::testing::ExactScalarResponseFixtureV1 scalar_response(
    std::vector<ExactRational> service_by_level,
    std::optional<std::uint64_t> constant_tail_from,
    std::optional<ExactRational> constant_tail_service) {
  std::optional<mwperf::BigNat> tail_from;
  if (constant_tail_from.has_value()) {
    tail_from = mwperf::BigNat{*constant_tail_from};
  }
  return {std::move(service_by_level), std::move(tail_from),
          std::move(constant_tail_service)};
}

[[nodiscard]] mwperf::TailService tail_service(
    const ExactRational& probability) {
  auto value = mwperf::TailService::make(probability);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ReducedStateV1 level_state(
    const std::uint8_t level) {
  return {{"c19.integration.level", 1U}, {static_cast<std::byte>(level)}};
}

[[nodiscard]] mwperf::InvariantLaw solve_c18(
    mwperf::C18ExactMatrixFixtureV1 fixture,
    const mwperf::SelectionSpec& selection,
    const mwperf::SolverPolicy& policy) {
  auto matrix =
      mwperf::testing::C18FixtureAccess::transition_matrix(std::move(fixture));
  INFO((matrix ? std::string{}
               : matrix.error().code + ": " + matrix.error().message));
  REQUIRE(matrix);
  auto selected = mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(matrix.value()), selection);
  INFO((selected ? std::string{}
                 : selected.error().code + ": " + selected.error().message));
  REQUIRE(selected);
  auto law = mwperf::solve_invariant_distribution(
      matrix.value(), selected.value(), policy);
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] BigFloat promoted(const ExactRational& value) {
  return BigFloat{value.numerator_decimal()} /
         BigFloat{value.denominator_decimal()};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::testing::ExactPhaseResponseFixtureV1
alternating_phase_fixture() {
  // K0=[[0,0],[1,0]], K1=[[0,1],[0,0]].  Service is level-major:
  // mu(0,.)=0 and mu(1,.)=1.  Hence (0,0)<->(1,1) is the unique
  // exact closed class; there is no cutoff reflection or censored mass.
  return {{phase(0U), phase(1U)},
          {{mwperf::BigNat{0U},
            {ExactRational::zero(), ExactRational::zero(),
             ExactRational::one(), ExactRational::zero()}},
           {mwperf::BigNat{1U},
            {ExactRational::zero(), ExactRational::one(),
             ExactRational::zero(), ExactRational::zero()}}},
          {rational(1, 2), rational(1, 2)},
          {ExactRational::zero(), ExactRational::zero(),
           ExactRational::one(), ExactRational::one()},
          {mwperf::PhaseLevelCompletionKindV1::exact_closed,
           mwperf::BigNat{1U}, std::nullopt, {}}};
}

using C19ProfileScenario = mwperf::testing::C16DesignatedScenarioV1;

[[nodiscard]] std::string_view c19_scheduler_for_profile(
    const mwperf::ServiceFamily family) {
  switch (family) {
    case mwperf::ServiceFamily::node_exclusive_matching:
      return R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x","y","z"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"w","v":"x"},{"queue_id":"q2","u":"y","v":"z"}]},"priority":["q0","q1","q2"]}})json";
    case mwperf::ServiceFamily::pairwise_conflicts:
      return R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2"],"max_search_states":null}})json";
    case mwperf::ServiceFamily::resource_packing:
      return R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[2]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":null}})json";
    case mwperf::ServiceFamily::crossbar_matching:
    case mwperf::ServiceFamily::nonoverlapping_intervals:
      break;
  }
  FAIL("the C19 six-profile fixture selected a family outside its scope");
  return {};
}

struct C19ProfileInput final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
  mwperf::MetricRequest metric_request;
};

[[nodiscard]] C19ProfileInput c19_profile_input(
    const mwperf::testing::C16TestProfileV1& profile) {
  static constexpr std::string_view model_template = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q1"},{"id":"q2"},{"id":"q0"}]},
    "scheduler":__C19_SCHEDULER__,
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s0"},{"id":"s1"},{"id":"s2"},
                 {"id":"s3"},{"id":"s4"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q2"},
                      {"source_id":"s2","d":1,"queue_id":"q2"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h0","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q1"},
                      {"source_id":"s2","d":1,"queue_id":"q1"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q2"},
                      {"source_id":"s2","d":1,"queue_id":"q2"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]},
        {"state":"h1","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s0","d":1,"queue_id":"q1"},
                      {"source_id":"s1","d":1,"queue_id":"q1"},
                      {"source_id":"s2","d":1,"queue_id":"q1"},
                      {"source_id":"s3","d":1,"queue_id":"q2"},
                      {"source_id":"s4","d":1,"queue_id":"q2"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  std::string model(model_template);
  static constexpr std::string_view scheduler_placeholder =
      "__C19_SCHEDULER__";
  const auto scheduler_position = model.find(scheduler_placeholder);
  REQUIRE(scheduler_position != std::string::npos);
  model.replace(scheduler_position, scheduler_placeholder.size(),
                c19_scheduler_for_profile(profile.family));
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":")json") + std::string(profile.provider_id) +
                               R"json(","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":8,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":8},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                 "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c19-profile-model", model));
  REQUIRE(model_document);
  auto model_node =
      mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c19-profile-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis =
      mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = mwperf::canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = mwperf::resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      mwperf::fingerprint_inputs(canonical));
  REQUIRE(instance);
  auto iid_arrival = mwperf::testing::make_c09_correlated_fixture_law(
      instance.value().queues(), mwperf::testing::FixtureFailureMode::none,
      mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
  REQUIRE(iid_arrival);
  auto configured_arrival =
      std::make_shared<const mwperf::CompiledArrivalLaw>(
          std::move(iid_arrival).value());
  auto rebound_instance =
      mwperf::testing::C19FixtureAccess::bind_resolved_arrival_for_testing(
          instance.value(), configured_arrival);
  INFO((rebound_instance
            ? std::string{}
            : rebound_instance.error().code + ": " +
                  rebound_instance.error().message));
  REQUIRE(rebound_instance);
  auto metric_request = mwperf::parse_metric_request(
      rebound_instance.value().analysis_spec().metrics.front(),
      rebound_instance.value().queues());
  REQUIRE(metric_request);
  auto requirements = mwperf::aggregate_metric_requirements(
      std::vector<mwperf::MetricRequest>{metric_request.value()});
  return {std::move(rebound_instance).value(),
          std::move(configured_arrival),
          std::move(requirements), std::move(metric_request).value()};
}

[[nodiscard]] C19ProfileScenario c19_profile_scenario(
    const mwperf::testing::C16TestProfileV1& profile) {
  auto input = c19_profile_input(profile);
  auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{} : provider.error().code));
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {mwperf::testing::c16_designated_detail::queue("q0")},
      mwperf::ConstructionGroupIdV1(
          mwperf::testing::c16_designated_detail::label(
              "c19.profile.group"))};
  auto bound_view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  INFO((bound_view ? std::string{}
                   : bound_view.error().code + ": " +
                         bound_view.error().message));
  REQUIRE(bound_view);
  mwperf::FrameworkProblemView view = std::move(bound_view).value();
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(),
      mwperf::testing::c16_designated_detail::parameters());
  REQUIRE(parameters);
  const auto budget = mwperf::testing::c16_designated_detail::budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view, input.requirements, budget, parameters.value());
  INFO((preview ? std::string{} : preview.error().code));
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const auto& metric_header =
      mwperf::metric_request_header(input.metric_request);
  std::vector<mwperf::ResolvedMetricContractV1> metric_contracts{{
      metric_header.authored_index,
      {metric_header.metric_id, metric_header.authored_index},
      metric_header.metric_id,
      metric_header.ordered_targets,
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      mwperf::TargetCouplingV1::scalar_target,
      mwperf::SolverRegimeV1::analytic,
      mwperf::BackendRouteKindV1::analytic_metric_family,
      preview.value().metric_support_manifest->canonical_digest()}};
  auto contract =
      mwperf::testing::C15ProtocolFixtureFactory::accepted_contract(
          provider.value().manifest().value(), preview.value().core,
          *preview.value().metric_support_manifest, input.requirements,
          view.configured_arrival().capabilities(),
          std::move(metric_contracts),
          preview.value().construction_target_scope, preview.value().policies,
          preview.value().construction_prerequisites,
          view.canonical_digest().value(),
          parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view, contract,
      parameters.value(), budget, mwperf::MasterSeed{0xC1909U});
  INFO((request ? std::string{}
                : request.error().code + ": " + request.error().message));
  REQUIRE(request);
  const auto manifest = provider.value().manifest();
  return {std::move(provider).value(), manifest, std::move(input.instance),
          std::move(input.arrival), std::move(input.requirements),
          std::move(input.metric_request), std::move(view),
          std::move(parameters).value(), std::move(preview).value(),
          std::move(contract), budget, std::move(request).value()};
}

[[nodiscard]] std::filesystem::path c19_profile_execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c19-profile-runs";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

struct C19ProfileFlow final {
  mwperf::ValidatedSurrogateArtifact artifact;
  mwperf::PortablePlugPayload payload;
  mwperf::ValidatedSurrogatePlug plug;
  mwperf::KernelAccess access;
};

[[nodiscard]] C19ProfileFlow c19_run_profile_flow(
    const C19ProfileScenario& scenario) {
  auto context = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(),
      c19_profile_execution_root());
  REQUIRE(context);
  auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context.value());
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  INFO((completed != nullptr
            ? std::string{}
            : std::get<mwperf::FailedProviderExecution>(outcome)
                  .diagnostic.code));
  REQUIRE(completed != nullptr);
  const mwperf::ArtifactParseLimits limits{
      1U << 20U, 64U,       1U << 14U, 1U << 14U,
      1U << 16U, 1U << 16U, 8U << 20U};
  auto parsed = mwperf::parse_surrogate_build_result(completed->bytes, limits);
  REQUIRE(parsed);
  auto report = mwperf::validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.budget);
  REQUIRE(report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.provider.manifest(),
      scenario.contract, report.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  const auto* built =
      std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(built != nullptr);
  auto payload = mwperf::adapt_portable_payload(built->artifact);
  REQUIRE(payload);
  auto plug = mwperf::materialize_and_validate_surrogate_plug(
      payload.value(), built->artifact, scenario.contract);
  REQUIRE(plug);
  auto access = mwperf::validate_kernel_access(plug.value());
  REQUIRE(access);
  return {built->artifact, std::move(payload).value(),
          std::move(plug).value(), std::move(access).value()};
}

[[nodiscard]] mwperf::ArrivalPhase c19_profile_phase(
    const C19ProfileScenario& scenario, std::string state,
    const std::uint64_t seed, const std::uint64_t replica) {
  auto key = mwperf::make_physical_reference_instance_key(
      scenario.instance.fingerprints().combined, mwperf::BigNat{replica});
  REQUIRE(key);
  auto stream = mwperf::make_configured_arrival_stream_key(
      *scenario.arrival,
      mwperf::derive_rng_stream(mwperf::MasterSeed{seed},
                                mwperf::StageTag::configured_arrival,
                                key.value()));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      *scenario.arrival,
      mwperf::ArrivalInitialState{
          mwperf::SharedRoundState{std::move(state)}},
      std::move(stream).value());
  REQUIRE(process);
  auto first = mwperf::next_arrival_step(process.value(), mwperf::BigNat{0U});
  REQUIRE(first);
  return first.value().phase_before;
}

[[nodiscard]] mwperf::AuditedCompiledFramework c19_audit_profile(
    const C19ProfileScenario& scenario, C19ProfileFlow flow) {
  const mwperf::PlugDescriptor descriptor = flow.plug.descriptor();
  const std::vector<mwperf::QueueId> targets(
      scenario.view.target_selection().ordered_targets.begin(),
      scenario.view.target_selection().ordered_targets.end());
  auto phase_zero = c19_profile_phase(scenario, "h0", 0xC190A, 0U);
  auto phase_one = c19_profile_phase(scenario, "h1", 0xC190B, 1U);
  auto state_schema = mwperf::testing::c17::exact_state_schema(
      scenario.instance, targets, phase_zero, phase_one);
  const auto initial =
      mwperf::testing::c17::reduced_state(targets, {0U});
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      scenario.instance, mwperf::BigNat{0U});
  REQUIRE(optimizer);
  const mwperf::testing::c17_direct::MaterializationV1 carried{
      flow.artifact, flow.payload};
  auto framework_seed =
      mwperf::testing::c17_direct::framework_seed(
          scenario, descriptor, flow.access, state_schema, initial);
  mwperf::CompiledFrameworkCandidateInputsV1 inputs{
      scenario.request.build_identity_digest(),
      scenario.request.request_digest().value(),
      scenario.instance,
      *scenario.arrival,
      scenario.contract,
      mwperf::testing::c17_direct::validate_realized(scenario, carried),
      state_schema,
      {mwperf::ExactCausalProgramModeV1::closed_three_bin_scalar,
       mwperf::physical_pmf_tolerance(),
       mwperf::PmfRepresentationBudget::unbounded(),
       {mwperf::testing::c17::reduced_state(targets, {0U}),
        mwperf::testing::c17::reduced_state(targets, {1U}),
        mwperf::testing::c17::reduced_state(targets, {2U}),
        mwperf::testing::c17::reduced_state(targets, {3U})}},
      std::nullopt,
      std::move(optimizer).value(),
      std::move(framework_seed)};
  auto candidate = mwperf::testing::C17FixtureAccess::make_candidate(
      std::move(flow.plug), std::move(inputs));
  auto framework = mwperf::audit_v0_causality(
      std::move(candidate), descriptor, std::move(flow.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return std::move(framework).value();
}

enum class C19ObservedRouteV1 : std::uint8_t {
  three_bin_iid_analytic,
  poison_sampling,
};

class C19RouteSpy final {
 public:
  [[nodiscard]] mwperf::Result<mwperf::ThreeBinIidSummary> execute(
      const mwperf::AcceptedCapabilityContract& contract,
      const mwperf::AuditedThreeBinResponse& response,
      const mwperf::ArrivalLaw& arrival) {
    const C19ObservedRouteV1 route =
        contract.semantic() ==
                    mwperf::SemanticTagV1::scalar_backlog_response &&
                contract.runtime_access() ==
                    mwperf::RuntimeAccessTagV1::
                        finite_parameter_analytic_family
            ? C19ObservedRouteV1::three_bin_iid_analytic
            : C19ObservedRouteV1::poison_sampling;
    observed_.push_back(route);
    if (route == C19ObservedRouteV1::three_bin_iid_analytic) {
      return mwperf::summarize_three_bin_iid_response(response, arrival);
    }
    ++poison_sampling_calls_;
    return mwperf::Result<mwperf::ThreeBinIidSummary>::failure(
        {mwperf::DiagnosticCategory::internal,
         "c19.fixture.poison_sampling_route",
         "a finite-parameter three-bin law was routed to sampling",
         std::nullopt, std::nullopt, {}});
  }

  [[nodiscard]] std::span<const C19ObservedRouteV1> observed() const {
    return observed_;
  }
  [[nodiscard]] std::size_t poison_sampling_calls() const noexcept {
    return poison_sampling_calls_;
  }

 private:
  std::vector<C19ObservedRouteV1> observed_;
  std::size_t poison_sampling_calls_{0U};
};

void check_same_c19_summary_math(const mwperf::ThreeBinIidSummary& actual,
                                 const mwperf::ThreeBinIidSummary& expected) {
  CHECK(actual.pi_zero() == expected.pi_zero());
  CHECK(actual.pi_one() == expected.pi_one());
  CHECK(actual.pi_two() == expected.pi_two());
  CHECK(actual.tail_mass_from_three() == expected.tail_mass_from_three());
  CHECK(actual.mu_zero() == expected.mu_zero());
  CHECK(actual.mu_one() == expected.mu_one());
  CHECK(actual.mu_two() == expected.mu_two());
  CHECK(actual.mu_tail_from_three() == expected.mu_tail_from_three());
  CHECK(actual.arrival_mean() == expected.arrival_mean());
  CHECK(actual.exact_mean_backlog() == expected.exact_mean_backlog());
  CHECK(actual.numerical_mean_backlog() ==
        expected.numerical_mean_backlog());
  CHECK(actual.exact_mean_sojourn() == expected.exact_mean_sojourn());
  CHECK(actual.numerical_mean_sojourn() ==
        expected.numerical_mean_sojourn());
  CHECK(actual.sojourn_counting_convention() ==
        expected.sojourn_counting_convention());
  CHECK(actual.tail_slack_applicability() ==
        expected.tail_slack_applicability());
  CHECK(actual.tail_slack() == expected.tail_slack());
  CHECK(actual.status() == expected.status());
  const auto actual_bins = actual.bins();
  const auto expected_bins = expected.bins();
  for (std::size_t index = 0U; index < actual_bins.size(); ++index) {
    CHECK(actual_bins[index].region == expected_bins[index].region);
    CHECK(actual_bins[index].response == expected_bins[index].response);
    CHECK(actual_bins[index].conditioning_mass ==
          expected_bins[index].conditioning_mass);
  }
  const auto& actual_diagnostics = actual.diagnostics();
  const auto& expected_diagnostics = expected.diagnostics();
  CHECK(actual_diagnostics.normalization_residual ==
        expected_diagnostics.normalization_residual);
  CHECK(actual_diagnostics.invariance_residual ==
        expected_diagnostics.invariance_residual);
  CHECK(actual_diagnostics.tail_remainder_bound ==
        expected_diagnostics.tail_remainder_bound);
  CHECK(actual_diagnostics.tail_slack == expected_diagnostics.tail_slack);
  CHECK(actual_diagnostics.terms_evaluated ==
        expected_diagnostics.terms_evaluated);
  CHECK_FALSE(std::isnan(actual_diagnostics.numerical_condition_estimate));
  CHECK(actual_diagnostics.numerical_condition_estimate ==
        expected_diagnostics.numerical_condition_estimate);
}

[[nodiscard]] mwperf::Digest256 c19_response_product_digest(
    const mwperf::ValidatedSurrogateArtifact& artifact) {
  const auto* response = std::get_if<mwperf::ThreeBinScalarResponseV1>(
      &artifact.value().payload);
  REQUIRE(response != nullptr);
  return std::visit(
      [](const auto& product) { return product.identity().object_digest; },
      response->deployed_response_product_id);
}

}  // namespace

TEST_CASE("C19 scalar backends agree with an exact closed C18 matrix",
          "[c19][integration][scalar][c18]") {
  const ExactRational lambda = rational(1, 4);
  const auto arrival =
      arrival_law({ExactRational::one() - lambda, lambda});
  const auto response = scalar_response(
      {ExactRational::zero(), ExactRational::one()}, 2U,
      ExactRational::one());

  auto flux = mwperf::testing::C19FixtureAccess::scalar_flux(arrival, response);
  REQUIRE(flux);
  auto general = mwperf::solve_scalar_cut_recursion(
      flux.value(), mwperf::TailPolicy::exact_finite_closure(
                        mwperf::Cutoff{mwperf::BigNat{1U}}));
  REQUIRE(general);
  auto birth_death =
      mwperf::testing::C19FixtureAccess::solve_bernoulli(arrival, response);
  REQUIRE(birth_death);
  auto constant_tail =
      mwperf::testing::C19FixtureAccess::solve_constant_tail(
          arrival, response, mwperf::Cutoff{mwperf::BigNat{1U}},
          tail_service(ExactRational::one()));
  REQUIRE(constant_tail);

  const auto selection = stationary_unique_selection();
  const auto policy = stationary_policy("scalar-c18");
  const std::vector<ExactRational> exact_matrix{
      ExactRational::one() - lambda, lambda,
      ExactRational::one() - lambda, lambda};
  mwperf::C18ExactMatrixFixtureV1 c18_fixture{
      .states = {level_state(0U), level_state(1U)},
      .exact_entries = exact_matrix,
      .bound_selection = selection,
      .bound_solver_policy = policy,
      .numerical_entries = std::nullopt,
      .marked_rows = {},
      .completion_kind = mwperf::BoundaryCompletionKindV1::exact_closed,
      .completion_identity = std::nullopt,
      .physical_mark_preserving = true,
      .bound_instance = std::nullopt,
      .bound_configured_arrival = std::nullopt,
      .bound_target_selection = std::nullopt,
      .exact_state_schema_digest = std::nullopt,
      .reduced_state_schema_digest = std::nullopt,
      .configured_phase_states = {},
      .configured_phase_masses = {},
      .configured_phase_kernel = std::nullopt,
      .state_phases = {}};
  auto c18 = solve_c18(std::move(c18_fixture), selection, policy);

  CHECK(c18.marked_flux().completion_kind() ==
        mwperf::BoundaryCompletionKindV1::exact_closed);
  CHECK(c18.marked_flux().physical_mark_preserving());
  for (std::size_t source_level = 0U; source_level < 2U; ++source_level) {
    ExactRational row_total = ExactRational::zero();
    for (std::size_t destination_level = 0U; destination_level < 2U;
         ++destination_level) {
      auto entry = flux.value().transition_probability(
          mwperf::BigNat{static_cast<std::uint64_t>(source_level)},
          mwperf::BigNat{static_cast<std::uint64_t>(destination_level)});
      REQUIRE(entry);
      CHECK(entry.value() ==
            exact_matrix[source_level * 2U + destination_level]);
      row_total = row_total + entry.value();
    }
    CHECK(row_total == ExactRational::one());
  }
  auto escaped = flux.value().transition_probability(mwperf::BigNat{1U},
                                                     mwperf::BigNat{2U});
  REQUIRE(escaped);
  CHECK(escaped.value() == ExactRational::zero());

  const std::vector<const mwperf::ScalarStationaryLaw*> c19_laws{
      &general.value(), &birth_death.value(), &constant_tail.value()};
  REQUIRE(c18.masses().size() == 2U);
  for (const auto* law : c19_laws) {
    REQUIRE(law->normalized_law_established());
    auto pi_zero = law->mass(mwperf::BigNat{0U});
    auto pi_one = law->mass(mwperf::BigNat{1U});
    REQUIRE(pi_zero);
    REQUIRE(pi_one);
    CHECK(pi_zero.value() == ExactRational::one() - lambda);
    CHECK(pi_one.value() == lambda);
    CHECK(c18.masses()[0U] ==
          Catch::Approx(pi_zero.value().to_long_double()).epsilon(1e-14));
    CHECK(c18.masses()[1U] ==
          Catch::Approx(pi_one.value().to_long_double()).epsilon(1e-14));
  }
}

TEST_CASE("C19 constant tail agrees with an explicit C18 four-bin aggregate",
          "[c19][integration][scalar][constant-tail][c18]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const auto arrival =
      arrival_law({ExactRational::one() - lambda, lambda});
  const auto response = scalar_response(
      {ExactRational::zero(), service, service}, 3U, service);
  auto c19 = mwperf::testing::C19FixtureAccess::solve_constant_tail(
      arrival, response, mwperf::Cutoff{mwperf::BigNat{2U}},
      tail_service(service));
  INFO((c19 ? std::string{}
            : c19.error().code + ": " + c19.error().message));
  REQUIRE(c19);
  REQUIRE(c19.value().normalized_law_established());
  CHECK(c19.value().status() ==
        mwperf::AnalyticStationaryStatusV1::strict_tail_stable);

  // This is the explicit stationary aggregation of the constant-response
  // chain into {0}, {1}, {2}, and {N>=3}; no production lumping helper is
  // used to construct the independent C18 matrix.
  const std::vector<ExactRational> aggregate_matrix{
      rational(3, 4), rational(1, 4), ExactRational::zero(),
      ExactRational::zero(), rational(3, 8), rational(1, 2),
      rational(1, 8), ExactRational::zero(), ExactRational::zero(),
      rational(3, 8), rational(1, 2), rational(1, 8),
      ExactRational::zero(), ExactRational::zero(), rational(1, 4),
      rational(3, 4)};
  const auto selection = stationary_unique_selection();
  const auto policy = stationary_policy("constant-tail-four-bin");
  mwperf::C18ExactMatrixFixtureV1 fixture{
      .states = {level_state(0U), level_state(1U), level_state(2U),
                 level_state(3U)},
      .exact_entries = aggregate_matrix,
      .bound_selection = selection,
      .bound_solver_policy = policy,
      .numerical_entries = std::nullopt,
      .marked_rows = {},
      .completion_kind = mwperf::BoundaryCompletionKindV1::exact_closed,
      .completion_identity = std::nullopt,
      .physical_mark_preserving = true,
      .bound_instance = std::nullopt,
      .bound_configured_arrival = std::nullopt,
      .bound_target_selection = std::nullopt,
      .exact_state_schema_digest = std::nullopt,
      .reduced_state_schema_digest = std::nullopt,
      .configured_phase_states = {},
      .configured_phase_masses = {},
      .configured_phase_kernel = std::nullopt,
      .state_phases = {}};
  const auto c18 = solve_c18(std::move(fixture), selection, policy);
  const std::array<ExactRational, 4U> expected{
      rational(1, 2), rational(1, 3), rational(1, 9), rational(1, 18)};
  REQUIRE(c18.masses().size() == expected.size());
  for (std::size_t index = 0U; index < expected.size(); ++index) {
    CHECK(c18.masses()[index] ==
          Catch::Approx(expected[index].to_long_double()).epsilon(1e-14));
  }
  for (std::size_t level = 0U; level < 3U; ++level) {
    auto mass = c19.value().mass(
        mwperf::BigNat{static_cast<std::uint64_t>(level)});
    REQUIRE(mass);
    CHECK(mass.value() == expected[level]);
  }
  REQUIRE(c19.value().exact_tail_mass().has_value());
  CHECK(*c19.value().exact_tail_mass() == expected[3U]);
  REQUIRE(c19.value().exact_mean_backlog().has_value());
  CHECK(*c19.value().exact_mean_backlog() == rational(3, 4));
}

TEST_CASE("C19 alternating phase fixture follows the full block solve path",
          "[c19][integration][phase]") {
  auto flux = mwperf::testing::C19FixtureAccess::phase_flux(
      alternating_phase_fixture());
  REQUIRE(flux);
  auto up = flux.value().transition_probability(
      mwperf::BigNat{0U}, 0U, mwperf::BigNat{1U}, 1U);
  auto down = flux.value().transition_probability(
      mwperf::BigNat{1U}, 1U, mwperf::BigNat{0U}, 0U);
  REQUIRE(up);
  REQUIRE(down);
  CHECK(up.value() == ExactRational::one());
  CHECK(down.value() == ExactRational::one());

  const auto selection = stationary_unique_selection();
  const auto policy = stationary_policy("alternating-phase");
  auto law = mwperf::solve_markov_additive_stationary(
      flux.value(), selection, policy);
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  auto pi_00 = law.value().mass(mwperf::BigNat{0U}, 0U);
  auto pi_01 = law.value().mass(mwperf::BigNat{0U}, 1U);
  auto pi_10 = law.value().mass(mwperf::BigNat{1U}, 0U);
  auto pi_11 = law.value().mass(mwperf::BigNat{1U}, 1U);
  REQUIRE(pi_00);
  REQUIRE(pi_01);
  REQUIRE(pi_10);
  REQUIRE(pi_11);
  CHECK(pi_00.value() == Catch::Approx(0.5L).epsilon(1e-14));
  CHECK(pi_01.value() == Catch::Approx(0.0L).margin(1e-15));
  CHECK(pi_10.value() == Catch::Approx(0.0L).margin(1e-15));
  CHECK(pi_11.value() == Catch::Approx(0.5L).epsilon(1e-14));

  REQUIRE(law.value().phase_marginal().size() == 2U);
  for (const auto& marginal : law.value().phase_marginal()) {
    CHECK(marginal.invariant_mass == Catch::Approx(0.5L).epsilon(1e-14));
    CHECK(marginal.configured_mass == Catch::Approx(0.5L).epsilon(1e-14));
    CHECK(marginal.residual == Catch::Approx(0.0L).margin(1e-15));
    CHECK(std::fabs(marginal.residual) <= marginal.residual_bound);
  }
}

TEST_CASE("C19 near-one PGF agrees with a promoted direct series and tail",
          "[c19][integration][pgf][tail]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational half = rational(1, 2);
  const auto arrival =
      arrival_law({ExactRational::one() - lambda, lambda});
  constexpr std::uint64_t cutoff_value = 64U;
  std::vector<ExactRational> service(cutoff_value + 1U, half);
  service.front() = ExactRational::zero();
  const auto response = scalar_response(
      std::move(service), cutoff_value + 1U, half);
  auto law = mwperf::testing::C19FixtureAccess::solve_constant_tail(
      arrival, response, mwperf::Cutoff{mwperf::BigNat{cutoff_value}},
      tail_service(half));
  REQUIRE(law);
  REQUIRE(law.value().normalized_law_established());
  REQUIRE(law.value().exact_mean_backlog().has_value());
  CHECK(*law.value().exact_mean_backlog() == rational(3, 4));

  const ExactRational z = rational(1099511627775LL, 1099511627776LL);
  auto point = mwperf::EvaluationPoint::make(z);
  REQUIRE(point);
  auto readout = mwperf::evaluate_scalar_pgf_and_moments(
      law.value(), mwperf::ArrivalTransform::from(arrival), point.value());
  INFO((readout ? std::string{}
                : readout.error().code + ": " + readout.error().message));
  REQUIRE(readout);
  REQUIRE(readout.value().exact_pgf().has_value());

  // For lambda=1/4 and mu(n)=1/2 on n>0, pi0=1/2 and pi_n=3^-n.
  // This is an independent promoted-precision partial sum; the omitted mass
  // after N is exactly 1/(2*3^N), and z^n<=1 supplies the certified PGF tail.
  constexpr unsigned terms = 160U;
  const BigFloat promoted_z = promoted(z);
  BigFloat z_power = 1;
  BigFloat mass = 1;
  BigFloat partial = BigFloat{1} / 2;
  for (unsigned level = 1U; level <= terms; ++level) {
    z_power *= promoted_z;
    mass /= 3;
    partial += mass * z_power;
  }
  BigFloat three_power = 1;
  for (unsigned index = 0U; index < terms; ++index) {
    three_power *= 3;
  }
  const BigFloat certified_tail = BigFloat{1} / (2 * three_power);
  const BigFloat exact_image = promoted(*readout.value().exact_pgf());
  CHECK(boost::multiprecision::abs(exact_image - partial) <= certified_tail);

  const ExactRational closed_form =
      half + divide(z, rational(3) - z);
  CHECK(*readout.value().exact_pgf() == closed_form);
  if (readout.value().numerical_pgf().has_value()) {
    CHECK(std::fabs(*readout.value().numerical_pgf() -
                    closed_form.to_long_double()) <=
          64.0L * std::numeric_limits<long double>::epsilon());
  }
}

TEST_CASE("C19 rejects a foreign arrival transform before evaluation",
          "[c19][negative][integration][identity]") {
  const auto first =
      arrival_law({rational(3, 4), rational(1, 4)});
  const auto foreign =
      arrival_law({rational(2, 3), rational(1, 3)});
  CHECK(first.identity_digest() != foreign.identity_digest());

  auto law = mwperf::testing::C19FixtureAccess::solve_constant_tail(
      first,
      scalar_response({ExactRational::zero(), rational(1, 2)}, 2U,
                      rational(1, 2)),
      mwperf::Cutoff{mwperf::BigNat{1U}}, tail_service(rational(1, 2)));
  REQUIRE(law);
  auto point = mwperf::EvaluationPoint::make(rational(1, 2));
  REQUIRE(point);
  auto rejected = mwperf::evaluate_scalar_pgf_and_moments(
      law.value(), mwperf::ArrivalTransform::from(foreign), point.value());
  REQUIRE_FALSE(rejected);
}

TEST_CASE("C19 classifies singular scalar branches without invented mass",
          "[c19][negative][integration][scalar]") {
  SECTION("exact closure is solved before a zero a0 recursion pivot") {
    const auto no_zero_arrival =
        arrival_law({ExactRational::zero(), ExactRational::one()});
    auto flux = mwperf::testing::C19FixtureAccess::scalar_flux(
        no_zero_arrival,
        scalar_response({ExactRational::zero(), ExactRational::one()}, 2U,
                        ExactRational::one()));
    REQUIRE(flux);
    auto classified = mwperf::solve_scalar_cut_recursion(
        flux.value(), mwperf::TailPolicy::exact_finite_closure(
                          mwperf::Cutoff{mwperf::BigNat{1U}}));
    REQUIRE(classified);
    CHECK(classified.value().status() ==
          mwperf::AnalyticStationaryStatusV1::finite);
    REQUIRE(classified.value().normalized_law_established());
    auto pi_zero = classified.value().mass(mwperf::BigNat{0U});
    auto pi_one = classified.value().mass(mwperf::BigNat{1U});
    REQUIRE(pi_zero);
    REQUIRE(pi_one);
    CHECK(pi_zero.value() == ExactRational::zero());
    CHECK(pi_one.value() == ExactRational::one());
    CHECK(std::isfinite(
        classified.value().diagnostics().numerical_condition_estimate));
  }

  SECTION("a reachable nonpositive tail slack publishes no law fields") {
    const ExactRational lambda = rational(3, 4);
    const ExactRational c = rational(1, 2);
    const auto arrival =
        arrival_law({ExactRational::one() - lambda, lambda});
    auto classified = mwperf::testing::C19FixtureAccess::solve_constant_tail(
        arrival,
        scalar_response({ExactRational::zero(), c}, 2U, c),
        mwperf::Cutoff{mwperf::BigNat{1U}}, tail_service(c));
    REQUIRE(classified);
    CHECK(classified.value().status() ==
          mwperf::AnalyticStationaryStatusV1::outside_strict_tail_profile);
    CHECK_FALSE(classified.value().normalized_law_established());
    CHECK_FALSE(classified.value().exact_mean_backlog().has_value());
    CHECK_FALSE(classified.value().exact_tail_mass().has_value());
  }

  SECTION("exact reachable closure is decided before an off-class slack") {
    const ExactRational lambda = rational(1, 2);
    const auto arrival =
        arrival_law({ExactRational::one() - lambda, lambda});
    auto closed = mwperf::testing::C19FixtureAccess::solve_constant_tail(
        arrival,
        scalar_response({ExactRational::zero(), ExactRational::one(),
                         ExactRational::zero()},
                        3U, ExactRational::zero()),
        mwperf::Cutoff{mwperf::BigNat{2U}},
        tail_service(ExactRational::zero()));
    REQUIRE(closed);
    CHECK(closed.value().status() ==
          mwperf::AnalyticStationaryStatusV1::
              finite_closed_tail_unreachable);
    CHECK(closed.value().normalized_law_established());
    REQUIRE(closed.value().exact_mean_backlog().has_value());
    CHECK(*closed.value().exact_mean_backlog() == rational(1, 2));
    REQUIRE(closed.value().exact_tail_mass().has_value());
    CHECK(closed.value().exact_tail_mass()->is_zero());
    CHECK_FALSE(closed.value().diagnostics().tail_slack.has_value());
  }
}

TEST_CASE("C19 rejects invalid phase mass and incomplete leaked mass",
          "[c19][negative][integration][phase]") {
  SECTION("arrival-phase kernel rows must be exact probability rows") {
    auto invalid = alternating_phase_fixture();
    invalid.arrival_blocks[1U].row_major[1U] = ExactRational::zero();
    auto rejected =
        mwperf::testing::C19FixtureAccess::phase_flux(std::move(invalid));
    REQUIRE_FALSE(rejected);
  }

  SECTION("a finite represented level cannot discard SF.26 leak") {
    auto incomplete = alternating_phase_fixture();
    incomplete.service_row_major = {ExactRational::zero(),
                                    ExactRational::zero()};
    incomplete.completion = {
        mwperf::PhaseLevelCompletionKindV1::additive_completion,
        mwperf::BigNat{0U}, digest("c19.integration.incomplete-leak"), {}};
    auto rejected =
        mwperf::testing::C19FixtureAccess::phase_flux(std::move(incomplete));
    REQUIRE_FALSE(rejected);
  }
}

TEST_CASE("C19 fixed maps enforce their declared domain and call budget",
          "[c19][negative][integration][fixed-point]") {
  const auto identity_map = [](const std::span<const ExactRational> value) {
    return mwperf::Result<std::vector<ExactRational>>::success(
        {value.front()});
  };
  auto outside_domain = mwperf::testing::C19FixtureAccess::fixed_point_law(
      {{ExactRational::zero()}, {ExactRational::one()}, {rational(2)}, true,
       {}, identity_map},
      fixed_point_unique_selection(), fixed_point_policy("domain", 4U));
  REQUIRE_FALSE(outside_domain);

  const auto oscillating_map =
      [](const std::span<const ExactRational> value) {
        return mwperf::Result<std::vector<ExactRational>>::success(
            {ExactRational::one() - value.front()});
      };
  auto exhausted = mwperf::testing::C19FixtureAccess::fixed_point_law(
      {{ExactRational::zero()}, {ExactRational::one()},
       {ExactRational::zero()}, true, {}, oscillating_map},
      fixed_point_unique_selection(), fixed_point_policy("budget", 4U));
  REQUIRE(exhausted);
  CHECK(exhausted.value().termination() ==
        mwperf::FixedPointTerminationV1::iteration_budget_exhausted);
  CHECK(exhausted.value().evaluation_count() == mwperf::BigNat{4U});
  CHECK(exhausted.value().iterate_difference() == ExactRational::one());
  CHECK(exhausted.value().fixed_point_residual() == ExactRational::one());
  REQUIRE(exhausted.value().parameters().size() == 1U);
  CHECK(exhausted.value().parameters().front() != rational(1, 2));
}

TEST_CASE(
    "C19 routes six equivalent Blossom MWIS and packing profiles analytically",
    "[c19][integration][three-bin][identity][route]") {
  constexpr std::size_t first_c19_profile = 4U;
  constexpr std::size_t profile_count = 6U;
  const auto profiles = std::span(mwperf::testing::kC16TestProfiles)
                            .subspan(first_c19_profile, profile_count);
  REQUIRE(profiles.size() == profile_count);

  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  std::optional<mwperf::testing::ModeErasedLawProjectionV1>
      reference_projection;
  std::optional<mwperf::ThreeBinIidSummary> reference_summary;
  std::vector<mwperf::ProviderIdentityV1> providers;
  std::vector<mwperf::Digest256> requests;
  std::vector<mwperf::ArtifactObjectReferenceV1> artifacts;
  std::vector<mwperf::ArtifactObjectReferenceV1> products;
  std::vector<mwperf::Digest256> plugs;
  std::vector<mwperf::Digest256> descriptors;
  std::vector<mwperf::StationaryAnalyticLawIdentityV1> summary_identities;
  std::optional<mwperf::ArrivalBinding> reference_arrival;
  C19RouteSpy route_spy;

  for (const auto& profile : profiles) {
    CAPTURE(profile.provider_id);
    CHECK((profile.family ==
               mwperf::ServiceFamily::node_exclusive_matching ||
           profile.family == mwperf::ServiceFamily::pairwise_conflicts ||
           profile.family == mwperf::ServiceFamily::resource_packing));
    CHECK((profile.construction_method ==
               mwperf::ConstructionMethodV1::engineered_deterministic ||
           profile.construction_method ==
               mwperf::ConstructionMethodV1::sampled_offline));

    auto scenario = c19_profile_scenario(profile);
    CHECK(scenario.contract.construction_method() ==
          profile.construction_method);
    auto flow = c19_run_profile_flow(scenario);
    auto projection = mwperf::testing::make_mode_erased_law_projection_v1(
        flow.artifact, scenario.request, scenario.contract);
    REQUIRE(projection);
    if (!reference_projection.has_value()) {
      reference_projection = projection.value();
    } else {
      CHECK(projection.value() == *reference_projection);
    }

    const auto provider = scenario.provider.identity();
    const auto request = scenario.request.request_digest().value();
    const auto artifact = flow.artifact.value().payload_identity;
    const auto product = c19_response_product_digest(flow.artifact);
    const auto product_reference = std::visit(
        [](const auto& typed) { return typed.identity(); },
        std::get<mwperf::ThreeBinScalarResponseV1>(
            flow.artifact.value().payload)
            .deployed_response_product_id);
    const auto plug = flow.plug.artifact_bindings().build_identity_digest;
    const auto descriptor = flow.plug.descriptor().descriptor_digest;
    const auto plug_bindings = flow.plug.artifact_bindings();
    const auto expected_contract = std::find_if(
        scenario.contract.metric_contracts().begin(),
        scenario.contract.metric_contracts().end(), [](const auto& contract) {
          return contract.backend_route ==
                     mwperf::BackendRouteKindV1::analytic_metric_family &&
                 contract.semantic ==
                     mwperf::SemanticTagV1::scalar_backlog_response &&
                 contract.runtime_access ==
                     mwperf::RuntimeAccessTagV1::
                         finite_parameter_analytic_family;
        });
    REQUIRE(expected_contract != scenario.contract.metric_contracts().end());
    const auto expected_binding = std::find_if(
        flow.artifact.value().realized_metric_bindings.bindings.begin(),
        flow.artifact.value().realized_metric_bindings.bindings.end(),
        [&](const auto& binding) {
          return binding.key.clause_id == expected_contract->clause_id &&
                 binding.key.role ==
                     mwperf::MetricSupportRoleV1::deployed_response;
        });
    REQUIRE(expected_binding !=
            flow.artifact.value().realized_metric_bindings.bindings.end());
    const mwperf::MetricClauseIdV1 expected_clause_id =
        expected_contract->clause_id;
    const mwperf::RealizedMetricBindingV1 expected_realized_binding =
        *expected_binding;
    const auto configured_arrival =
        mwperf::builder_arrival_view(*scenario.arrival).binding();
    if (!reference_arrival.has_value()) {
      reference_arrival = configured_arrival;
    } else {
      CHECK(configured_arrival == *reference_arrival);
    }

    auto framework = c19_audit_profile(scenario, std::move(flow));
    auto response = mwperf::audited_three_bin_response(framework);
    INFO((response ? std::string{} : response.error().code));
    REQUIRE(response);
    for (const auto& [level, expected] :
         std::array<std::pair<std::uint64_t, ExactRational>, 3U>{
             std::pair{1U, rational(1, 4)},
             std::pair{2U, rational(3, 4)},
             std::pair{3U, rational(1, 2)}}) {
      auto actual = response.value().service_probability(
          mwperf::BigNat{level});
      REQUIRE(actual);
      CHECK(actual.value() == expected);
    }
    auto arrival = mwperf::ArrivalLaw::from_audited(response.value());
    INFO((arrival ? std::string{} : arrival.error().code));
    REQUIRE(arrival);
    CHECK(arrival.value().mean() == ExactRational::zero());

    auto summary = route_spy.execute(scenario.contract, response.value(),
                                     arrival.value());
    INFO((summary ? std::string{}
                  : summary.error().code + ": " + summary.error().message));
    REQUIRE(summary);
    CHECK(summary.value().status() ==
          mwperf::AnalyticStationaryStatusV1::
              finite_closed_tail_unreachable);
    REQUIRE(summary.value().pi_zero().has_value());
    CHECK(*summary.value().pi_zero() == ExactRational::one());
    REQUIRE(summary.value().pi_one().has_value());
    REQUIRE(summary.value().pi_two().has_value());
    REQUIRE(summary.value().tail_mass_from_three().has_value());
    CHECK(summary.value().pi_one()->is_zero());
    CHECK(summary.value().pi_two()->is_zero());
    CHECK(summary.value().tail_mass_from_three()->is_zero());
    REQUIRE(summary.value().exact_mean_backlog().has_value());
    REQUIRE(summary.value().numerical_mean_backlog().has_value());
    CHECK(summary.value().exact_mean_backlog()->is_zero());
    CHECK(*summary.value().numerical_mean_backlog() == 0.0L);
    if (!reference_summary.has_value()) {
      reference_summary = summary.value();
    } else {
      check_same_c19_summary_math(summary.value(), *reference_summary);
    }

    const auto& identity = summary.value().law_identity();
    CHECK(identity.artifact() == plug_bindings);
    CHECK(identity.artifact().provider == provider);
    CHECK(identity.artifact().request_digest == request);
    CHECK(identity.artifact().build_identity_digest == plug);
    CHECK(identity.artifact().construction_method ==
          profile.construction_method);
    CHECK(identity.framework().descriptor_digest == descriptor);
    CHECK(identity.framework().build_request_digest == request);
    CHECK(identity.payload() == artifact);
    REQUIRE(identity.accepted_metric_clause().has_value());
    CHECK(*identity.accepted_metric_clause() == expected_clause_id);
    REQUIRE(identity.realized_metric_binding().has_value());
    CHECK(*identity.realized_metric_binding() == expected_realized_binding);
    CHECK(identity.payload_phase() ==
          mwperf::PayloadPhaseKindV1::phase_free);
    REQUIRE(identity.response_product().has_value());
    CHECK(*identity.response_product() == product_reference);
    CHECK(identity.response_product()->object_digest == product);
    CHECK(identity.response_stage() ==
          std::optional{mwperf::ResponseProductStageV1::raw_response});
    CHECK_FALSE(identity.derivation().has_value());
    REQUIRE(identity.cutoff().has_value());
    CHECK(*identity.cutoff() == mwperf::BigNat{2U});
    REQUIRE(identity.tail_service().has_value());
    CHECK(*identity.tail_service() == rational(1, 2));
    CHECK(identity.configured_arrival() == configured_arrival);
    CHECK(identity.target() ==
          mwperf::testing::c16_designated_detail::queue("q0"));
    REQUIRE(identity.construction_targets().size() == 1U);
    CHECK(identity.construction_targets().front() == identity.target());
    CHECK(identity.result_scope() == mwperf::MetricResultScopeV1::surrogate_law);

    providers.push_back(provider);
    requests.push_back(request);
    artifacts.push_back(artifact);
    products.push_back(product_reference);
    plugs.push_back(plug);
    descriptors.push_back(descriptor);
    summary_identities.push_back(identity);
    REQUIRE_FALSE(route_spy.observed().empty());
    CHECK(route_spy.observed().back() ==
          C19ObservedRouteV1::three_bin_iid_analytic);
  }

  REQUIRE(providers.size() == profile_count);
  REQUIRE(route_spy.observed().size() == profile_count);
  CHECK(route_spy.poison_sampling_calls() == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load() ==
        profile_count);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load() ==
        profile_count);
  for (std::size_t left = 0U; left < profile_count; ++left) {
    for (std::size_t right = left + 1U; right < profile_count; ++right) {
      CHECK(providers[left] != providers[right]);
      CHECK(requests[left] != requests[right]);
      CHECK(artifacts[left] != artifacts[right]);
      CHECK(products[left] != products[right]);
      CHECK(plugs[left] != plugs[right]);
      CHECK(descriptors[left] != descriptors[right]);
      CHECK(summary_identities[left] != summary_identities[right]);
      CHECK(summary_identities[left].artifact() !=
            summary_identities[right].artifact());
      CHECK(summary_identities[left].framework().descriptor_digest !=
            summary_identities[right].framework().descriptor_digest);
      CHECK(summary_identities[left].execution_seal_digest() !=
            summary_identities[right].execution_seal_digest());
      CHECK(summary_identities[left].payload() !=
            summary_identities[right].payload());
      CHECK(summary_identities[left].response_product() !=
            summary_identities[right].response_product());
    }
  }
}

TEST_CASE("C19 IID rejection leaves the C17 temporal three-bin route intact",
          "[c19][negative][integration][three-bin][temporal]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto response = mwperf::audited_three_bin_response(fixture.framework);
  REQUIRE(response);
  auto iid_arrival = mwperf::ArrivalLaw::from_audited(response.value());
  REQUIRE_FALSE(iid_arrival);
  CHECK(iid_arrival.error().code.find("iid") != std::string::npos);

  // Failure is local to the IID analytic route.  The same seal-bound response
  // and its C17-composed temporal row remain usable without reinterpretation.
  auto coefficient =
      response.value().service_probability(mwperf::BigNat{2U});
  REQUIRE(coefficient);
  CHECK(coefficient.value() == rational(1, 4));
  auto row_provider = mwperf::audited_row_provider(fixture.framework);
  REQUIRE(row_provider);
  const auto empty = mwperf::testing::c17::reduced_state(
      fixture.ordered_targets, {0U});
  auto row =
      mwperf::compile_reduced_kernel_row(row_provider.value(), empty);
  REQUIRE(row);
  CHECK(row.value().exact_total_mass() == ExactRational::one());
  REQUIRE_FALSE(row.value().atoms().empty());
}
