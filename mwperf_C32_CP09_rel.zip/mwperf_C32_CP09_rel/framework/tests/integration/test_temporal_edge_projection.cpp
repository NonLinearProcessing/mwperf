#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/stationary/suspension.hpp"

namespace {

[[nodiscard]] bool same_bytes(const std::span<const std::byte> left,
                              const std::span<const std::byte> right) {
  return left.size() == right.size() &&
         std::equal(left.begin(), left.end(), right.begin());
}

[[nodiscard]] bool same_digest(const mwperf::Digest256& left,
                               const mwperf::Digest256& right) {
  return same_bytes(left.bytes(), right.bytes());
}

[[nodiscard]] bool same_state(const mwperf::ReducedStateV1& left,
                              const mwperf::ReducedStateV1& right) {
  return left.codec == right.codec &&
         same_bytes(left.canonical_value, right.canonical_value);
}

// Keep this comparator explicit: GCC 13 can diagnose the libstdc++
// vector<byte> three-way comparator as a stringop-overread under -Werror.
struct ReducedStateBytesLess final {
  [[nodiscard]] bool operator()(const mwperf::ReducedStateV1& left,
                                const mwperf::ReducedStateV1& right) const {
    if (left.codec != right.codec) {
      if (left.codec.id != right.codec.id) {
        return left.codec.id < right.codec.id;
      }
      return left.codec.version < right.codec.version;
    }
    return std::lexicographical_compare(
        left.canonical_value.begin(), left.canonical_value.end(),
        right.canonical_value.begin(), right.canonical_value.end(),
        [](const std::byte lhs, const std::byte rhs) {
          return std::to_integer<unsigned>(lhs) <
                 std::to_integer<unsigned>(rhs);
        });
  }
};

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

struct C21ProductionPathV1 final {
  mwperf::testing::c21::StationarySuspensionFixtureV1 fixture;
  mwperf::EventInvariantLaw event_law;
  mwperf::PositiveFiniteMean mean;
  mwperf::StationaryTemporalProjection projection;
};

[[nodiscard]] C21ProductionPathV1 make_projection(
    const bool reverse_domain_order = false,
    const mwperf::testing::c21::ProjectionPlanFixtureV1 plan =
        mwperf::testing::c21::ProjectionPlanFixtureV1::stationary_reward,
    const bool identity_variant = false) {
  auto fixture = mwperf::testing::c21::make_plan_fixture(
      plan, reverse_domain_order, identity_variant);
  auto event_law = require_value(mwperf::select_event_invariant_law(
      fixture.kernel, mwperf::testing::c21::configured_selection(fixture),
      mwperf::testing::c21::solver_policy(fixture)));
  auto mean = require_value(
      mwperf::compute_mean_residence(event_law, fixture.provider));
  auto projection = require_value(
      mwperf::build_stationary_temporal_projection(
          event_law, fixture.provider, mean));
  return {std::move(fixture), std::move(event_law), std::move(mean),
          std::move(projection)};
}

[[nodiscard]] mwperf::MetricRequest configured_request(
    const mwperf::testing::c21::StationarySuspensionFixtureV1& fixture) {
  REQUIRE(fixture.temporal.instance.analysis_spec().metrics.size() == 1U);
  return require_value(mwperf::parse_metric_request(
      fixture.temporal.instance.analysis_spec().metrics.front(),
      fixture.temporal.instance.queues()));
}

class C21PalmInputSinkSpy final {
 public:
  [[nodiscard]] bool accept_event_palm_input(
      const mwperf::StationaryTemporalLaw& law,
      const mwperf::Digest256& expected_fingerprint) {
    ++event_calls_;
    return same_digest(law.projection_fingerprint(), expected_fingerprint);
  }

  [[nodiscard]] bool accept_admission_palm_input(
      const mwperf::StationaryMarkedEdge& edge,
      const mwperf::Digest256& expected_fingerprint) {
    ++admission_calls_;
    return same_digest(edge.projection_fingerprint(), expected_fingerprint);
  }

  [[nodiscard]] std::size_t event_calls() const noexcept {
    return event_calls_;
  }
  [[nodiscard]] std::size_t admission_calls() const noexcept {
    return admission_calls_;
  }

 private:
  std::size_t event_calls_{0U};
  std::size_t admission_calls_{0U};
};

template <typename T>
concept C21EventPalmInput = requires(C21PalmInputSinkSpy& sink,
                                     const T& value,
                                     const mwperf::Digest256& fingerprint) {
  { sink.accept_event_palm_input(value, fingerprint) } ->
      std::same_as<bool>;
};

template <typename T>
concept C21AdmissionPalmInput = requires(
    C21PalmInputSinkSpy& sink, const T& value,
    const mwperf::Digest256& fingerprint) {
  { sink.accept_admission_palm_input(value, fingerprint) } ->
      std::same_as<bool>;
};

template <typename T>
concept C21StationaryMetricInput = requires(
    const T& value, const mwperf::MetricRequest& request) {
  { mwperf::evaluate_stationary_temporal_metric(value, request) } ->
      std::same_as<mwperf::Result<mwperf::MetricValue>>;
};

template <typename Provider>
concept C21MeanProvider = requires(const mwperf::EventInvariantLaw& law,
                                   const Provider& provider) {
  { mwperf::compute_mean_residence(law, provider) } ->
      std::same_as<mwperf::Result<mwperf::PositiveFiniteMean>>;
};

template <typename Provider>
concept C21ProjectionProvider = requires(
    const mwperf::EventInvariantLaw& law, const Provider& provider,
    const mwperf::PositiveFiniteMean& mean) {
  { mwperf::build_stationary_temporal_projection(law, provider, mean) } ->
      std::same_as<mwperf::Result<mwperf::StationaryTemporalProjection>>;
};

static_assert(C21EventPalmInput<mwperf::StationaryTemporalLaw>);
static_assert(!C21EventPalmInput<mwperf::StationaryMarkedEdge>);
static_assert(C21AdmissionPalmInput<mwperf::StationaryMarkedEdge>);
static_assert(!C21AdmissionPalmInput<mwperf::StationaryTemporalLaw>);
static_assert(C21StationaryMetricInput<mwperf::StationaryTemporalLaw>);
static_assert(!C21StationaryMetricInput<mwperf::StationaryMarkedEdge>);
static_assert(C21MeanProvider<mwperf::AuditedResidenceProvider>);
static_assert(!C21MeanProvider<mwperf::AuditedSamplerDescriptor>);
static_assert(C21ProjectionProvider<mwperf::AuditedResidenceProvider>);
static_assert(!C21ProjectionProvider<mwperf::AuditedSamplerDescriptor>);
static_assert(!std::convertible_to<mwperf::StationaryTemporalLaw,
                                   mwperf::StationaryMarkedEdge>);
static_assert(!std::convertible_to<mwperf::StationaryMarkedEdge,
                                   mwperf::StationaryTemporalLaw>);

class C21ProjectionConsumerSinkSpy final {
 public:
  [[nodiscard]] bool accept_cylinder(
      const mwperf::AuditedCylinderLaw& value,
      const mwperf::Digest256& expected) {
    return accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_temporal_law(
      const mwperf::AuditedTemporalLaw& value,
      const mwperf::Digest256& expected) {
    return accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_temporal_kernel(
      const mwperf::AuditedTemporalKernel& value,
      const mwperf::Digest256& expected) {
    return accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_initial_law(
      const mwperf::InitialLaw& value,
      const mwperf::Digest256& expected) {
    return value.kind() == mwperf::InitialLawKindV1::stationary &&
           accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_service_split(
      const mwperf::PredictiveServiceSplit& value,
      const mwperf::Digest256& expected) {
    return accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_service_kernel(
      const mwperf::TemporalServiceKernel& value,
      const mwperf::Digest256& expected) {
    return accept(value.projection_fingerprint(), expected);
  }

  [[nodiscard]] bool accept_unavailable(
      const mwperf::StationaryProjectionUnavailableV1&) {
    ++rejected_unavailable_;
    return false;
  }

  [[nodiscard]] std::size_t calls() const noexcept { return calls_; }
  [[nodiscard]] std::size_t rejected_unavailable() const noexcept {
    return rejected_unavailable_;
  }

 private:
  [[nodiscard]] bool accept(const mwperf::Digest256& actual,
                            const mwperf::Digest256& expected) {
    ++calls_;
    return same_digest(actual, expected);
  }

  std::size_t calls_{0U};
  std::size_t rejected_unavailable_{0U};
};

template <typename T>
concept C21CylinderSinkInput = requires(
    C21ProjectionConsumerSinkSpy& sink, const T& value,
    const mwperf::Digest256& fingerprint) {
  { sink.accept_cylinder(value, fingerprint) } -> std::same_as<bool>;
};

template <typename T>
concept C21TemporalKernelSinkInput = requires(
    C21ProjectionConsumerSinkSpy& sink, const T& value,
    const mwperf::Digest256& fingerprint) {
  { sink.accept_temporal_kernel(value, fingerprint) } -> std::same_as<bool>;
};

static_assert(C21CylinderSinkInput<mwperf::AuditedCylinderLaw>);
static_assert(!C21CylinderSinkInput<mwperf::AuditedTemporalLaw>);
static_assert(!C21CylinderSinkInput<mwperf::AuditedResidenceProvider>);
static_assert(C21TemporalKernelSinkInput<mwperf::AuditedTemporalKernel>);
static_assert(!C21TemporalKernelSinkInput<mwperf::StationaryMarkedEdge>);
static_assert(!std::default_initializable<mwperf::AuditedCylinderLaw>);
static_assert(!std::default_initializable<mwperf::AuditedTemporalLaw>);
static_assert(!std::default_initializable<mwperf::AuditedTemporalKernel>);
static_assert(!std::default_initializable<mwperf::InitialLaw>);
static_assert(!std::default_initializable<mwperf::PredictiveServiceSplit>);
static_assert(!std::default_initializable<mwperf::TemporalServiceKernel>);

[[nodiscard]] std::string stationary_analysis(
    const std::string_view metric, const bool transient) {
  const std::string selection = transient
      ? R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{}}]}}})json"
      : R"json({"kind":"stationary_unique","parameters":{}})json";
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + std::string(metric) + R"json(],
    "surrogate":{"id":"c20.fixture.pair.romr-enumerable",
                 "version":"1.0.0","parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":0,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":)json" + selection + R"json(,
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":64}}
  })json";
}

[[nodiscard]] mwperf::MetricRequest parse_metric(
    const mwperf::QueueCatalog& catalog, const std::string_view metric,
    const bool transient = false) {
  const auto path =
      mwperf::testing::c16_designated_detail::write_input(
          "c21-temporal-metric", stationary_analysis(metric, transient));
  auto document = require_value(mwperf::load_document(path));
  auto analysis = require_value(mwperf::parse_analysis_spec_v1(document));
  REQUIRE(analysis.metrics.size() == 1U);
  return require_value(
      mwperf::parse_metric_request(analysis.metrics.front(), catalog));
}

[[nodiscard]] bool unavailable_metric_result(
    const mwperf::Result<mwperf::MetricValue>& result) {
  return !result &&
         result.error().category == mwperf::DiagnosticCategory::unavailable;
}

[[nodiscard]] mwperf::DenseQueueIndex require_queue_index(
    const mwperf::QueueCatalog& catalog, const mwperf::QueueId& queue) {
  std::optional<mwperf::DenseQueueIndex> result;
  for (std::size_t ordinal = 0U; ordinal < catalog.entries().size();
       ++ordinal) {
    if (catalog.entries()[ordinal].id != queue) {
      continue;
    }
    result = require_value(catalog.index_at(ordinal));
    break;
  }
  REQUIRE(result.has_value());
  return *result;
}

[[nodiscard]] bool phase_matches_state(
    const mwperf::ArrivalPhase& phase,
    const mwperf::ReducedStateV1& state) {
  if (state.canonical_value.size() !=
      mwperf::testing::c21::kStateSize) {
    return false;
  }
  const auto canonical = mwperf::arrival_phase_canonical_state(phase);
  return mwperf::arrival_phase_family(phase) ==
             mwperf::ArrivalFamily::shared_joint_round_markov_renewal &&
         canonical.size() == 1U &&
         canonical.front() ==
             state.canonical_value[mwperf::testing::c21::kPhaseOffset];
}

template <typename T, typename Accept>
void inspect_slot(const mwperf::StationaryProjectionSlotV1<T>& slot,
                  const mwperf::Digest256& projection_fingerprint,
                  C21ProjectionConsumerSinkSpy& sink,
                  Accept&& accept, std::size_t& available,
                  std::size_t& unavailable) {
  if (const auto* value = std::get_if<T>(&slot)) {
    ++available;
    CHECK(std::forward<Accept>(accept)(sink, *value,
                                      projection_fingerprint));
    return;
  }
  const auto* reason =
      std::get_if<mwperf::StationaryProjectionUnavailableV1>(&slot);
  REQUIRE(reason != nullptr);
  CHECK_FALSE(reason->code.empty());
  CHECK_FALSE(reason->message.empty());
  CHECK_FALSE(sink.accept_unavailable(*reason));
  ++unavailable;
}

template <typename T>
[[nodiscard]] const T& require_available(
    const mwperf::StationaryProjectionSlotV1<T>& slot) {
  const auto* value = std::get_if<T>(&slot);
  REQUIRE(value != nullptr);
  return *value;
}

template <typename T>
[[nodiscard]] bool is_unavailable(
    const mwperf::StationaryProjectionSlotV1<T>& slot) {
  const auto* value =
      std::get_if<mwperf::StationaryProjectionUnavailableV1>(&slot);
  return value != nullptr && !value->code.empty() && !value->message.empty();
}

}  // namespace

TEST_CASE("C21 projects a C20 residence kernel to one fingerprint-bound "
          "temporal law and edge",
          "[c21][integration]") {
  const auto path = make_projection();
  const auto& projection = path.projection;
  const auto& temporal = projection.temporal_law();
  const auto& edge = projection.marked_edge();

  CHECK(same_digest(temporal.projection_fingerprint(),
                    projection.fingerprint()));
  CHECK(same_digest(edge.projection_fingerprint(),
                    projection.fingerprint()));
  CHECK(projection.diagnostics().three_way_identity_matches);
  CHECK(projection.diagnostics().constructed_in_one_residence_pass);
  CHECK(projection.diagnostics().edge_mass_is_one);
  CHECK(projection.diagnostics().edge_marginals_match);
  CHECK(projection.diagnostics().endpoint_is_invariant);
  CHECK(edge.diagnostics().exact_total_mass ==
        mwperf::ExactRational::one());
  CHECK(edge.diagnostics().exact_left_right_marginals_equal);
  CHECK(edge.diagnostics().exact_queue_updates_hold);
  CHECK(edge.diagnostics().exact_endpoint_invariance_holds);
  CHECK(edge.diagnostics().zero_mass_rows_left_undefined);
  CHECK_FALSE(edge.atoms().empty());
  CHECK(edge.positive_conditional_rows().size() ==
        edge.left_marginal().size());
  const ReducedStateBytesLess state_less;
  CHECK(std::is_sorted(
      edge.left_marginal().begin(), edge.left_marginal().end(),
      [&state_less](const auto& left, const auto& right) {
        return state_less(left.state, right.state);
      }));

  for (const auto& left : edge.left_marginal()) {
    const auto right = std::find_if(
        edge.right_marginal().begin(), edge.right_marginal().end(),
        [&left](const auto& candidate) {
          return same_state(left.state, candidate.state);
        });
    REQUIRE(right != edge.right_marginal().end());
    CHECK(left.exact_mass == right->exact_mass);
  }

  C21PalmInputSinkSpy palm_sink;
  CHECK(palm_sink.accept_event_palm_input(temporal,
                                          projection.fingerprint()));
  CHECK(palm_sink.accept_admission_palm_input(edge,
                                              projection.fingerprint()));
  CHECK(palm_sink.event_calls() == 1U);
  CHECK(palm_sink.admission_calls() == 1U);

  auto metric = mwperf::evaluate_stationary_temporal_metric(
      temporal, configured_request(path.fixture));
  INFO((metric ? std::string{}
               : metric.error().code + ": " + metric.error().message));
  REQUIRE(metric);
  auto envelope =
      mwperf::testing::C21FixtureAccess::decode_metric_envelope(metric.value());
  INFO((envelope ? std::string{}
                 : envelope.error().code + ": " + envelope.error().message));
  REQUIRE(envelope);
  CHECK(same_digest(envelope.value().source_fingerprint,
                    projection.fingerprint()));
  REQUIRE(path.mean.exact_value().has_value());
  CHECK(*path.mean.exact_value() ==
        mwperf::testing::c21::rational(2, 1));
  CHECK(envelope.value().exact_denominator ==
        *path.mean.exact_value());
  CHECK(envelope.value().exact_ratio.has_value());
}

TEST_CASE("C21 verifies slot-time arrival phase occupation without equating "
          "it to an event marginal",
          "[c21][integration]") {
  const auto path = make_projection();
  const auto& diagnostics = path.projection.temporal_law().diagnostics();

  REQUIRE(diagnostics.configured_phase_identity_available);
  CHECK(diagnostics.configured_phase_identity_matches);
  CHECK(path.projection.diagnostics().phase_occupation_matches);
  REQUIRE_FALSE(diagnostics.phase_occupation.empty());

  mwperf::ExactRational event_phase_zero = mwperf::ExactRational::zero();
  mwperf::ExactRational event_phase_one = mwperf::ExactRational::zero();
  for (const auto& atom : path.event_law.masses()) {
    REQUIRE(atom.state_index < path.event_law.domain().states().size());
    const std::uint8_t phase = mwperf::testing::c21::phase(
        path.event_law.domain().states()[atom.state_index]);
    if (phase == 0U) {
      event_phase_zero = event_phase_zero + atom.exact_mass;
    } else {
      REQUIRE(phase == 1U);
      event_phase_one = event_phase_one + atom.exact_mass;
    }
  }
  CHECK(event_phase_zero == mwperf::testing::c21::rational(1, 2));
  CHECK(event_phase_one == mwperf::testing::c21::rational(1, 2));

  mwperf::ExactRational total = mwperf::ExactRational::zero();
  mwperf::ExactRational slot_phase_zero = mwperf::ExactRational::zero();
  mwperf::ExactRational slot_phase_one = mwperf::ExactRational::zero();
  for (const auto& phase : diagnostics.phase_occupation) {
    total = total + phase.exact_slot_mass;
    REQUIRE(phase.configured_exact_mass.has_value());
    CHECK(phase.exact_slot_mass == *phase.configured_exact_mass);
    REQUIRE(phase.phase.canonical_state.size() == 1U);
    if (phase.phase.canonical_state.front() == std::byte{0U}) {
      slot_phase_zero = slot_phase_zero + phase.exact_slot_mass;
    } else {
      REQUIRE(phase.phase.canonical_state.front() == std::byte{1U});
      slot_phase_one = slot_phase_one + phase.exact_slot_mass;
    }
  }
  CHECK(total == mwperf::ExactRational::one());
  CHECK(slot_phase_zero == mwperf::testing::c21::rational(1, 4));
  CHECK(slot_phase_one == mwperf::testing::c21::rational(3, 4));
  CHECK(event_phase_zero != slot_phase_zero);
  CHECK(event_phase_one != slot_phase_one);
}

TEST_CASE("C21 length-biases an evolving Markov phase across residences",
          "[c21][integration]") {
  using Plan = mwperf::testing::c21::ProjectionPlanFixtureV1;
  const auto path = make_projection(false, Plan::evolving_phase);
  REQUIRE(path.mean.exact_value().has_value());
  CHECK(*path.mean.exact_value() ==
        mwperf::testing::c21::rational(3, 2));

  mwperf::ExactRational event_phase_zero = mwperf::ExactRational::zero();
  mwperf::ExactRational event_phase_one = mwperf::ExactRational::zero();
  for (const auto& atom : path.event_law.masses()) {
    REQUIRE(atom.state_index < path.event_law.domain().states().size());
    const auto phase = mwperf::testing::c21::phase(
        path.event_law.domain().states()[atom.state_index]);
    if (phase == 0U) {
      event_phase_zero = event_phase_zero + atom.exact_mass;
    } else {
      REQUIRE(phase == 1U);
      event_phase_one = event_phase_one + atom.exact_mass;
    }
  }
  CHECK(event_phase_zero == mwperf::testing::c21::rational(3, 4));
  CHECK(event_phase_one == mwperf::testing::c21::rational(1, 4));

  const auto& diagnostics = path.projection.temporal_law().diagnostics();
  REQUIRE(diagnostics.configured_phase_identity_available);
  CHECK(diagnostics.configured_phase_identity_matches);
  CHECK(path.projection.diagnostics().phase_occupation_matches);
  mwperf::ExactRational slot_phase_zero = mwperf::ExactRational::zero();
  mwperf::ExactRational slot_phase_one = mwperf::ExactRational::zero();
  for (const auto& occupation : diagnostics.phase_occupation) {
    REQUIRE(occupation.phase.canonical_state.size() == 1U);
    REQUIRE(occupation.configured_exact_mass.has_value());
    CHECK(occupation.exact_slot_mass ==
          *occupation.configured_exact_mass);
    if (occupation.phase.canonical_state.front() == std::byte{0U}) {
      slot_phase_zero = slot_phase_zero + occupation.exact_slot_mass;
    } else {
      REQUIRE(occupation.phase.canonical_state.front() == std::byte{1U});
      slot_phase_one = slot_phase_one + occupation.exact_slot_mass;
    }
  }
  CHECK(slot_phase_zero == mwperf::testing::c21::rational(1, 2));
  CHECK(slot_phase_one == mwperf::testing::c21::rational(1, 2));
  CHECK(event_phase_zero != slot_phase_zero);
  CHECK(event_phase_one != slot_phase_one);
}

TEST_CASE("C21 projection slots remain closed typed capabilities",
          "[c21][integration]") {
  using Plan = mwperf::testing::c21::ProjectionPlanFixtureV1;
  const auto base = make_projection(false, Plan::stationary_reward);
  const auto cylinder = make_projection(false, Plan::finite_cylinder);
  const auto temporal = make_projection(false, Plan::audited_temporal_law);
  const auto stopped = make_projection(false, Plan::stationary_stopped);
  const auto fifo = make_projection(false, Plan::fifo_service);
  C21ProjectionConsumerSinkSpy sink;

  // The C23-facing service views are opaque by design, but their common C21
  // source edge remains inspectable.  Check that the same projection really
  // retained D, A, predictive phase, and the completed-edge auxiliary mark
  // before accepting its fingerprint-bound P=P0+P1/service restrictions.
  const auto q0 = require_queue_index(
      fifo.fixture.temporal.instance.queues(),
      mwperf::testing::c16_designated_detail::queue("q0"));
  mwperf::ExactRational departure_mass = mwperf::ExactRational::zero();
  mwperf::ExactRational admission_mass = mwperf::ExactRational::zero();
  mwperf::ExactRational auxiliary_mark_mass =
      mwperf::ExactRational::zero();
  for (const auto& atom : fifo.projection.marked_edge().atoms()) {
    const auto& raw = atom.raw_edge;
    CHECK(raw.stage_trace() == mwperf::kCausalStageOrderV1);
    CHECK(phase_matches_state(raw.arrival().phase_before,
                              raw.pre_state()));
    CHECK(phase_matches_state(raw.arrival().phase_after,
                              raw.successor_state()));

    if (raw.action().actual_departure.at(q0)) {
      departure_mass = departure_mass + atom.exact_mass;
    }
    REQUIRE(raw.arrival().batch.binding().has_value());
    const auto admitted = mwperf::project_arrival_count(
        raw.arrival().batch, q0, *raw.arrival().batch.binding());
    REQUIRE(admitted);
    CHECK(admitted.value() == mwperf::BigNat{1U});
    if (admitted.value() == mwperf::BigNat{1U}) {
      admission_mass = admission_mass + atom.exact_mass;
    }

    const auto auxiliary = std::find_if(
        raw.marks().begin(), raw.marks().end(), [](const auto& candidate) {
          return candidate.mark.mark ==
                     mwperf::testing::c20_reset_audited::raw_age_mark() &&
                 candidate.mark.value.codec ==
                     mwperf::testing::c20_reset_audited::kAgeCodec &&
                 candidate.reveal_stage == mwperf::CausalStageV1::psi;
        });
    REQUIRE(auxiliary != raw.marks().end());
    REQUIRE(auxiliary->mark.value.canonical_value.size() == 1U);
    REQUIRE(raw.successor_state().canonical_value.size() ==
            mwperf::testing::c21::kStateSize);
    CHECK(auxiliary->mark.value.canonical_value.front() ==
          raw.successor_state()
              .canonical_value[mwperf::testing::c21::kAgeOffset]);
    auxiliary_mark_mass = auxiliary_mark_mass + atom.exact_mass;
  }
  CHECK(departure_mass == mwperf::ExactRational::one());
  CHECK(admission_mass == mwperf::ExactRational::one());
  CHECK(auxiliary_mark_mass == mwperf::ExactRational::one());

  const auto& cylinder_view =
      require_available(cylinder.projection.cylinder_law());
  CHECK(sink.accept_cylinder(cylinder_view,
                             cylinder.projection.fingerprint()));

  const auto& temporal_view =
      require_available(temporal.projection.audited_temporal_law());
  CHECK(sink.accept_temporal_law(temporal_view,
                                 temporal.projection.fingerprint()));

  const auto& kernel_view =
      require_available(stopped.projection.temporal_kernel());
  CHECK(sink.accept_temporal_kernel(kernel_view,
                                    stopped.projection.fingerprint()));
  const auto& initial_view =
      require_available(stopped.projection.initial_law());
  CHECK(sink.accept_initial_law(initial_view,
                                stopped.projection.fingerprint()));

  const auto& split_view =
      require_available(fifo.projection.predictive_service_split());
  CHECK(sink.accept_service_split(split_view, fifo.projection.fingerprint()));
  const auto& service_view =
      require_available(fifo.projection.temporal_service_kernel());
  CHECK(sink.accept_service_kernel(service_view,
                                    fifo.projection.fingerprint()));
  CHECK(sink.calls() == 6U);

  // Each plan publishes only the restrictions its real accepted C14 route
  // requested.  In particular, accepting a finite cylinder does not invent a
  // stopped kernel, and accepting a stopped view does not invent FIFO state.
  CHECK(is_unavailable(cylinder.projection.temporal_kernel()));
  CHECK(is_unavailable(cylinder.projection.predictive_service_split()));
  CHECK(is_unavailable(stopped.projection.cylinder_law()));
  CHECK(is_unavailable(stopped.projection.predictive_service_split()));
  CHECK(is_unavailable(fifo.projection.cylinder_law()));
  CHECK(is_unavailable(fifo.projection.initial_law()));

  // The accepted state-reward plan requests no optional downstream C22/C23
  // capability.  Its six closed unavailable slots must not prevent its
  // complete-word reward.
  std::size_t base_available = 0U;
  std::size_t base_unavailable = 0U;
  inspect_slot(
      base.projection.cylinder_law(), base.projection.fingerprint(), sink,
      [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_cylinder(value, fingerprint);
      },
      base_available, base_unavailable);
  inspect_slot(
      base.projection.audited_temporal_law(), base.projection.fingerprint(),
      sink, [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_temporal_law(value, fingerprint);
      },
      base_available, base_unavailable);
  inspect_slot(
      base.projection.temporal_kernel(), base.projection.fingerprint(), sink,
      [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_temporal_kernel(value, fingerprint);
      },
      base_available, base_unavailable);
  inspect_slot(
      base.projection.initial_law(), base.projection.fingerprint(), sink,
      [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_initial_law(value, fingerprint);
      },
      base_available, base_unavailable);
  inspect_slot(
      base.projection.predictive_service_split(),
      base.projection.fingerprint(), sink,
      [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_service_split(value, fingerprint);
      },
      base_available, base_unavailable);
  inspect_slot(
      base.projection.temporal_service_kernel(),
      base.projection.fingerprint(), sink,
      [](auto& consumer, const auto& value, const auto& fingerprint) {
        return consumer.accept_service_kernel(value, fingerprint);
      },
      base_available, base_unavailable);
  CHECK(base_available == 0U);
  CHECK(base_unavailable == 6U);
  CHECK(sink.rejected_unavailable() == 6U);
  auto supported = mwperf::evaluate_stationary_temporal_metric(
      base.projection.temporal_law(), configured_request(base.fixture));
  REQUIRE(supported);
}

TEST_CASE("C21 accepted stationary route rejects unavailable temporal "
          "continuation before decoding",
          "[c21][integration][negative]") {
  const auto path = make_projection();
  bool decoder_called = false;
  const mwperf::RewardDecoder requires_continuation{
      mwperf::StationaryRewardDomainV1::state,
      mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
      true,
      {},
      [&decoder_called](const mwperf::StationaryRewardArgumentV1&)
          -> mwperf::Result<long double> {
        decoder_called = true;
        return mwperf::Result<long double>::success(1.0L);
      },
      {"c21.test.requires-temporal-continuation", 1U}};

  const auto rejected = mwperf::suspend_event_law_to_slots(
      path.event_law, path.fixture.provider, path.mean,
      requires_continuation);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(rejected.error().code ==
        "c14_capability_missing_temporal_continuation");
  CHECK_FALSE(decoder_called);
}

TEST_CASE("C21 typed sinks reject members from another projection",
          "[c21][integration][negative]") {
  using Plan = mwperf::testing::c21::ProjectionPlanFixtureV1;
  const auto cylinder_local = make_projection(false, Plan::finite_cylinder);
  const auto cylinder_foreign =
      make_projection(false, Plan::finite_cylinder, true);
  const auto temporal_local =
      make_projection(false, Plan::audited_temporal_law);
  const auto temporal_foreign =
      make_projection(false, Plan::audited_temporal_law, true);
  const auto stopped_local = make_projection(false, Plan::stationary_stopped);
  const auto stopped_foreign =
      make_projection(false, Plan::stationary_stopped, true);
  const auto fifo_local = make_projection(false, Plan::fifo_service);
  const auto fifo_foreign =
      make_projection(false, Plan::fifo_service, true);

  const auto require_foreign_identity = [](const auto& local,
                                           const auto& foreign) {
    REQUIRE_FALSE(same_digest(local.projection.fingerprint(),
                              foreign.projection.fingerprint()));
  };
  require_foreign_identity(cylinder_local, cylinder_foreign);
  require_foreign_identity(temporal_local, temporal_foreign);
  require_foreign_identity(stopped_local, stopped_foreign);
  require_foreign_identity(fifo_local, fifo_foreign);

  C21PalmInputSinkSpy sink;
  CHECK(sink.accept_event_palm_input(
      temporal_local.projection.temporal_law(),
      temporal_local.projection.fingerprint()));
  CHECK(sink.accept_admission_palm_input(
      temporal_local.projection.marked_edge(),
      temporal_local.projection.fingerprint()));
  CHECK_FALSE(sink.accept_event_palm_input(
      temporal_foreign.projection.temporal_law(),
      temporal_local.projection.fingerprint()));
  CHECK_FALSE(sink.accept_admission_palm_input(
      temporal_foreign.projection.marked_edge(),
      temporal_local.projection.fingerprint()));

  C21ProjectionConsumerSinkSpy consumer;
  const auto reject_foreign = [&](const auto& local_slot,
                                  const auto& foreign_slot,
                                  const auto& expected,
                                  auto&& accept) {
    using Slot = std::remove_cvref_t<decltype(local_slot)>;
    using Value = std::variant_alternative_t<0U, Slot>;
    const auto* local_value = std::get_if<Value>(&local_slot);
    const auto* foreign_value = std::get_if<Value>(&foreign_slot);
    REQUIRE(local_value != nullptr);
    REQUIRE(foreign_value != nullptr);
    CHECK(accept(consumer, *local_value, expected));
    CHECK_FALSE(accept(consumer, *foreign_value, expected));
  };
  reject_foreign(
      cylinder_local.projection.cylinder_law(),
      cylinder_foreign.projection.cylinder_law(),
      cylinder_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_cylinder(value, fingerprint);
      });
  reject_foreign(
      temporal_local.projection.audited_temporal_law(),
      temporal_foreign.projection.audited_temporal_law(),
      temporal_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_temporal_law(value, fingerprint);
      });
  reject_foreign(
      stopped_local.projection.temporal_kernel(),
      stopped_foreign.projection.temporal_kernel(),
      stopped_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_temporal_kernel(value, fingerprint);
      });
  reject_foreign(
      stopped_local.projection.initial_law(),
      stopped_foreign.projection.initial_law(),
      stopped_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_initial_law(value, fingerprint);
      });
  reject_foreign(
      fifo_local.projection.predictive_service_split(),
      fifo_foreign.projection.predictive_service_split(),
      fifo_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_service_split(value, fingerprint);
      });
  reject_foreign(
      fifo_local.projection.temporal_service_kernel(),
      fifo_foreign.projection.temporal_service_kernel(),
      fifo_local.projection.fingerprint(),
      [](auto& target, const auto& value, const auto& fingerprint) {
        return target.accept_service_kernel(value, fingerprint);
      });
}

TEST_CASE("C21 edge image cannot answer lag run gap hit or FIFO requests",
          "[c21][integration][negative]") {
  const auto path = make_projection();
  const auto& catalog = path.fixture.temporal.instance.queues();
  const std::array<mwperf::MetricRequest, 5U> requests{
      parse_metric(
          catalog,
          R"json({"id":"lag","kind":"service_autocovariance","parameters":{"lags":[1]}})json"),
      parse_metric(
          catalog,
          R"json({"id":"run","kind":"mean_binary_run","parameters":{"predicate":"busy"}})json"),
      parse_metric(
          catalog,
          R"json({"id":"gap","kind":"event_gap_distribution","parameters":{"event":"departure","horizon":4}})json"),
      parse_metric(
          catalog,
          R"json({"id":"hit","kind":"first_hit","parameters":{"set":{"kind":"at_or_above","level":1},"horizon":4,"include_mean":false}})json",
          true),
      parse_metric(
          catalog,
          R"json({"id":"fifo","kind":"fifo_delay","parameters":{"output":"pmf","horizon":4}})json")};

  for (const auto& request : requests) {
    const auto rejected = mwperf::evaluate_stationary_temporal_metric(
        path.projection.temporal_law(), request);
    INFO((rejected ? std::string{"unexpected success"}
                   : rejected.error().code + ": " +
                         rejected.error().message));
    CHECK(unavailable_metric_result(rejected));
  }

  // This assertion is deliberately compile-time: there is no runtime
  // overload that could power or otherwise reinterpret the marked edge as a
  // temporal continuation.
  STATIC_REQUIRE_FALSE(
      C21StationaryMetricInput<mwperf::StationaryMarkedEdge>);
}

TEST_CASE("C21 metric dispatch rejects a shape-compatible request that was "
          "not accepted",
          "[c21][negative]") {
  const auto path = make_projection();
  const auto& catalog = path.fixture.temporal.instance.queues();

  // Preserve authored index, id, ordered target, selection, solver, and the
  // stationary-invariant backend route.  Only the metric semantics differ
  // from the accepted stationary_empty_probability request.  Matching a
  // request solely by those shape fields would incorrectly broaden the C14
  // contract after the V0 audit.
  const auto altered = parse_metric(
      catalog,
      R"json({"id":"c21-empty","kind":"stationary_backlog_moment","parameters":{"order":2}})json");
  const auto rejected = mwperf::evaluate_stationary_temporal_metric(
      path.projection.temporal_law(), altered);
  INFO((rejected ? std::string{"unexpected success"}
                 : rejected.error().code + ": " +
                       rejected.error().message));
  CHECK(unavailable_metric_result(rejected));
}
