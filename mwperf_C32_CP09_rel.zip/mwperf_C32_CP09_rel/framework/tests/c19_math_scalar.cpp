#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/stationary/three_bin_summary.hpp"
#include "support/c19_math_test_util.hpp"

namespace {

using namespace mwperf;
using namespace mwperf::testing::c19_math;

[[nodiscard]] ArrivalLaw arrival_from(const AuditedResponseLaw& response) {
  auto arrival = ArrivalLaw::from_audited(response);
  INFO((arrival ? std::string{} : arrival.error().code));
  REQUIRE(arrival);
  return std::move(arrival).value();
}

[[nodiscard]] ArrivalLaw arrival_from(
    const AuditedThreeBinResponse& response) {
  auto arrival = ArrivalLaw::from_audited(response);
  INFO((arrival ? std::string{} : arrival.error().code));
  REQUIRE(arrival);
  return std::move(arrival).value();
}

[[nodiscard]] AuditedResponseLaw scalar_response(ScalarCarrierSpec spec) {
  auto response = mint_scalar_response(std::move(spec));
  INFO((response ? std::string{} : response.error().code));
  REQUIRE(response);
  return std::move(response).value();
}

[[nodiscard]] AuditedThreeBinResponse three_bin_response(
    ScalarCarrierSpec spec) {
  auto response = mint_three_bin_response(std::move(spec));
  INFO((response ? std::string{} : response.error().code));
  REQUIRE(response);
  return std::move(response).value();
}

[[nodiscard]] ScalarCarrierSpec constant_bernoulli_spec(
    CarrierLineageSpec carrier_lineage, const ExactRational& arrival_rate,
    const ExactRational& service) {
  return scalar_carrier(std::move(carrier_lineage),
                        bernoulli_atoms(arrival_rate),
                        {ExactRational::zero()}, BigNat{1U}, service);
}

[[nodiscard]] ScalarCarrierSpec nonmonotone_three_bin_spec(
    CarrierLineageSpec carrier_lineage,
    const bool second_moment_available = true) {
  return scalar_carrier(
      std::move(carrier_lineage), bernoulli_atoms(rational(1, 4)),
      {ExactRational::zero(), rational(3, 4), rational(1, 4)}, BigNat{3U},
      rational(2, 3), second_moment_available);
}

[[nodiscard]] ScalarFluxOperator scalar_flux(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival) {
  auto flux = assemble_iid_scalar_flux(response, ArrivalPmf::from(arrival));
  INFO((flux ? std::string{} : flux.error().code));
  REQUIRE(flux);
  return std::move(flux).value();
}

}  // namespace

TEST_CASE("C19 public F01 is exactly the early-service SF.14 row",
          "[c19][math][sf14]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const auto response = scalar_response(constant_bernoulli_spec(
      lineage("sf14"), lambda, service));
  const ArrivalLaw arrival = arrival_from(response);
  const ScalarFluxOperator flux = scalar_flux(response, arrival);  // F-C19-01

  const auto probability = [&](const std::uint64_t source,
                               const std::uint64_t destination) {
    auto value = flux.transition_probability(BigNat{source},
                                             BigNat{destination});
    REQUIRE(value);
    return std::move(value).value();
  };
  CHECK(probability(0U, 0U) == rational(3, 4));
  CHECK(probability(0U, 1U) == rational(1, 4));
  CHECK(probability(2U, 1U) == rational(3, 8));
  CHECK(probability(2U, 2U) == rational(1, 2));
  CHECK(probability(2U, 3U) == rational(1, 8));
  CHECK(probability(2U, 1U) + probability(2U, 2U) +
            probability(2U, 3U) ==
        ExactRational::one());
  REQUIRE(flux.identity().accepted_metric_clause());
  REQUIRE(flux.identity().realized_metric_binding());
}

TEST_CASE("C19 public F02 F03 and F04 share the Bernoulli exact law",
          "[c19][math][sf19][sf21]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const auto response = scalar_response(constant_bernoulli_spec(
      lineage("bernoulli-overlap"), lambda, service));
  const ArrivalLaw arrival = arrival_from(response);
  const ScalarFluxOperator flux = scalar_flux(response, arrival);

  auto cut = solve_scalar_cut_recursion(
      flux, TailPolicy::constant_response(Cutoff{BigNat{0U}},
                                          tail_service(service)));  // F-C19-02
  REQUIRE(cut);
  auto rate = BernoulliRate::from(arrival);
  REQUIRE(rate);
  auto birth_death =
      solve_bernoulli_birth_death(response, rate.value());  // F-C19-04
  REQUIRE(birth_death);

  const std::array<ExactRational, 4U> expected{
      rational(1, 2), rational(1, 3), rational(1, 9), rational(1, 27)};
  for (std::size_t level = 0U; level < expected.size(); ++level) {
    CAPTURE(level);
    CHECK(scalar_mass(cut.value(), level) == expected[level]);
    CHECK(scalar_mass(birth_death.value(), level) == expected[level]);
  }
  REQUIRE(cut.value().exact_mean_backlog());
  REQUIRE(birth_death.value().exact_mean_backlog());
  CHECK(*cut.value().exact_mean_backlog() == rational(3, 4));
  CHECK(*birth_death.value().exact_mean_backlog() == rational(3, 4));

  auto readout = evaluate_scalar_pgf_and_moments(
      cut.value(), ArrivalTransform::from(arrival),
      evaluation_point(rational(1, 2)));  // F-C19-03
  REQUIRE(readout);
  REQUIRE(readout.value().exact_pgf());
  REQUIRE(readout.value().exact_response_weighted_pgf());
  CHECK(*readout.value().exact_pgf() == rational(7, 10));
  CHECK(*readout.value().exact_response_weighted_pgf() == rational(1, 10));

  auto flow = evaluate_scalar_pgf_and_moments(
      cut.value(), ArrivalTransform::from(arrival),
      evaluation_point(ExactRational::one()));
  REQUIRE(flow);
  REQUIRE(flow.value().exact_response_weighted_pgf());
  CHECK(*flow.value().exact_response_weighted_pgf() == lambda);
}

TEST_CASE("C19 SF.19 batch fixture retains its infinite normalization",
          "[c19][math][sf19][batch]") {
  auto spec = scalar_carrier(
      lineage("batch-sf19"),
      {{BigNat{0U}, rational(3, 4)}, {BigNat{2U}, rational(1, 4)}},
      {ExactRational::zero()}, BigNat{1U}, ExactRational::one());
  const auto response = scalar_response(std::move(spec));
  const ArrivalLaw arrival = arrival_from(response);
  const ScalarFluxOperator flux = scalar_flux(response, arrival);
  auto law = solve_scalar_cut_recursion(
      flux, TailPolicy::constant_response(
                Cutoff{BigNat{0U}}, tail_service(ExactRational::one())));
  REQUIRE(law);

  const std::array<ExactRational, 5U> expected{
      rational(1, 2), rational(1, 6), rational(2, 9), rational(2, 27),
      rational(2, 81)};
  for (std::size_t level = 0U; level < expected.size(); ++level) {
    CAPTURE(level);
    CHECK(scalar_mass(law.value(), level) == expected[level]);
  }
  REQUIRE(law.value().exact_mean_backlog());
  CHECK(*law.value().exact_mean_backlog() == ExactRational::one());
}

TEST_CASE("C19 scalar exceptional branches form one classification table",
          "[c19][math][classification]") {
  enum class Scenario : std::uint8_t {
    zero_denominator,
    nonsummable_tail,
    incomplete_tail,
    unavailable_moment,
    zero_rate_endpoint,
    unit_rate_endpoint,
  };
  constexpr std::array scenarios{
      Scenario::zero_denominator, Scenario::nonsummable_tail,
      Scenario::incomplete_tail, Scenario::unavailable_moment,
      Scenario::zero_rate_endpoint, Scenario::unit_rate_endpoint};

  for (const Scenario scenario : scenarios) {
    CAPTURE(static_cast<unsigned>(scenario));
    if (scenario == Scenario::zero_denominator) {
      auto spec = scalar_carrier(
          lineage("classification-zero"), bernoulli_atoms(rational(1, 2)),
          {ExactRational::zero(), ExactRational::zero()}, std::nullopt,
          std::nullopt);
      const auto response = scalar_response(std::move(spec));
      const ArrivalLaw arrival = arrival_from(response);
      const ScalarFluxOperator flux = scalar_flux(response, arrival);
      auto result = solve_scalar_cut_recursion(
          flux, TailPolicy::no_completion(BigNat{2U}));
      REQUIRE(result);
      CHECK(result.value().status() ==
            AnalyticStationaryStatusV1::unsupported_assumptions);
      CHECK_FALSE(result.value().normalized_law_established());
      CHECK_FALSE(result.value().exact_tail_mass());
      CHECK_FALSE(result.value().exact_mean_backlog());
      REQUIRE(result.value().diagnostics().terms_evaluated);
      CHECK(*result.value().diagnostics().terms_evaluated == BigNat{1U});
    } else if (scenario == Scenario::nonsummable_tail) {
      auto spec = constant_bernoulli_spec(
          lineage("classification-nonsummable"), rational(3, 5),
          rational(1, 2));
      const auto response = scalar_response(std::move(spec));
      const ArrivalLaw arrival = arrival_from(response);
      auto rate = BernoulliRate::from(arrival);
      REQUIRE(rate);
      auto result = solve_bernoulli_birth_death(response, rate.value());
      REQUIRE(result);
      CHECK(result.value().status() == AnalyticStationaryStatusV1::not_summable);
      CHECK_FALSE(result.value().normalized_law_established());
    } else if (scenario == Scenario::incomplete_tail) {
      auto spec = scalar_carrier(
          lineage("classification-incomplete"),
          bernoulli_atoms(rational(1, 4)),
          {ExactRational::zero(), rational(1, 2)}, std::nullopt, std::nullopt);
      const auto response = scalar_response(std::move(spec));
      const ArrivalLaw arrival = arrival_from(response);
      const ScalarFluxOperator flux = scalar_flux(response, arrival);
      auto result = solve_scalar_cut_recursion(
          flux, TailPolicy::no_completion(BigNat{2U}));
      REQUIRE(result);
      CHECK(result.value().status() ==
            AnalyticStationaryStatusV1::incomplete_tail);
      CHECK_FALSE(result.value().normalized_law_established());
    } else if (scenario == Scenario::unavailable_moment) {
      auto spec = nonmonotone_three_bin_spec(
          lineage("classification-moment"), false);
      const auto response = scalar_response(std::move(spec));
      const ArrivalLaw arrival = arrival_from(response);
      auto result = solve_constant_tail_response(
          response, arrival, Cutoff{BigNat{2U}},
          tail_service(rational(2, 3)));
      REQUIRE(result);
      CHECK(result.value().status() ==
            AnalyticStationaryStatusV1::required_moment_unavailable);
      CHECK(result.value().normalized_law_established());
      CHECK_FALSE(result.value().exact_mean_backlog());
    } else {
      const bool unit_rate = scenario == Scenario::unit_rate_endpoint;
      const ExactRational rate = unit_rate ? ExactRational::one()
                                           : ExactRational::zero();
      const ExactRational service = unit_rate ? ExactRational::one()
                                              : rational(1, 2);
      auto spec = constant_bernoulli_spec(
          lineage(unit_rate ? "classification-unit-rate"
                            : "classification-zero-rate"),
          rate, service);
      if (!unit_rate) {
        spec.selection_seed.clear();
      }
      const auto response = scalar_response(std::move(spec));
      const ArrivalLaw arrival = arrival_from(response);
      auto bernoulli = BernoulliRate::from(arrival);
      REQUIRE(bernoulli);
      auto result = solve_bernoulli_birth_death(response, bernoulli.value());
      REQUIRE(result);
      CHECK(result.value().status() ==
            AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
      CHECK(result.value().normalized_law_established());
      CHECK(scalar_mass(result.value(), unit_rate ? 1U : 0U) ==
            ExactRational::one());
      CHECK(scalar_mass(result.value(), unit_rate ? 0U : 1U).is_zero());
    }
  }
}

TEST_CASE("C19 F05 proves finite closure before testing tail slack",
          "[c19][math][sf22][finite-closure]") {
  SECTION("the selected Bernoulli class is pinned to levels zero and one") {
    auto spec = scalar_carrier(
        lineage("finite-before-slack"), bernoulli_atoms(rational(1, 2)),
        {ExactRational::zero(), ExactRational::one(), ExactRational::zero()},
        BigNat{3U}, ExactRational::zero());
    const auto response = scalar_response(std::move(spec));
    const ArrivalLaw arrival = arrival_from(response);
    auto law = solve_constant_tail_response(
        response, arrival, Cutoff{BigNat{2U}},
        tail_service(ExactRational::zero()));  // F-C19-05
    REQUIRE(law);
    CHECK(law.value().status() ==
          AnalyticStationaryStatusV1::finite_closed_tail_unreachable);
    CHECK(law.value().normalized_law_established());
    CHECK(scalar_mass(law.value(), 0U) == rational(1, 2));
    CHECK(scalar_mass(law.value(), 1U) == rational(1, 2));
    CHECK(scalar_mass(law.value(), 2U).is_zero());
    REQUIRE(law.value().exact_mean_backlog());
    REQUIRE(law.value().exact_tail_mass());
    CHECK(*law.value().exact_mean_backlog() == rational(1, 2));
    CHECK(law.value().exact_tail_mass()->is_zero());
    CHECK_FALSE(law.value().diagnostics().tail_slack);
    REQUIRE(law.value().finite_closure_proof());
    const auto support =
        law.value().finite_closure_proof()->reachable_support();
    REQUIRE(support.size() == 2U);
    CHECK(support[0U] == BigNat{0U});
    CHECK(support[1U] == BigNat{1U});
  }

  SECTION("a sealed level-one class seed yields the exact delta-one law") {
    auto spec = scalar_carrier(
        lineage("finite-selected-delta-one"),
        {{BigNat{0U}, ExactRational::one()}},
        {ExactRational::zero(), ExactRational::zero()}, BigNat{2U},
        ExactRational::zero());
    spec.selection_seed = {{BigNat{1U}, ExactRational::one()}};
    spec.selection = stationary_class_selection(1U);
    spec.little_law.positive_finite_intensity = false;
    spec.little_law.little_law = false;
    const auto response = scalar_response(std::move(spec));
    const ArrivalLaw arrival = arrival_from(response);
    auto law = solve_constant_tail_response(
        response, arrival, Cutoff{BigNat{1U}},
        tail_service(ExactRational::zero()));  // F-C19-05
    REQUIRE(law);
    CHECK(law.value().status() ==
          AnalyticStationaryStatusV1::finite_closed_tail_unreachable);
    CHECK(scalar_mass(law.value(), 0U).is_zero());
    CHECK(scalar_mass(law.value(), 1U) == ExactRational::one());
    REQUIRE(law.value().exact_mean_backlog());
    CHECK(*law.value().exact_mean_backlog() == ExactRational::one());
    REQUIRE(law.value().finite_closure_proof());
    const auto support =
        law.value().finite_closure_proof()->reachable_support();
    REQUIRE(support.size() == 1U);
    CHECK(support.front() == BigNat{1U});
    CHECK_FALSE(law.value().diagnostics().tail_slack);
  }
}

TEST_CASE("C19 nonmonotone SF.22 and public F09 return one exact summary",
          "[c19][math][sf22][three-bin]") {
  const auto scalar = scalar_response(
      nonmonotone_three_bin_spec(lineage("nonmonotone-scalar")));
  const ArrivalLaw scalar_arrival = arrival_from(scalar);
  auto law = solve_constant_tail_response(
      scalar, scalar_arrival, Cutoff{BigNat{2U}},
      tail_service(rational(2, 3)));
  REQUIRE(law);

  const auto response = three_bin_response(
      nonmonotone_three_bin_spec(lineage("nonmonotone-summary")));
  const ArrivalLaw arrival = arrival_from(response);
  auto summary = summarize_three_bin_iid_response(response, arrival);  // F-C19-09
  REQUIRE(summary);

  const ExactRational pi0 = rational(135, 224);
  const ExactRational pi1 = rational(15, 56);
  const ExactRational pi2 = rational(5, 56);
  const ExactRational tail = rational(9, 224);
  CHECK(scalar_mass(law.value(), 0U) == pi0);
  CHECK(scalar_mass(law.value(), 1U) == pi1);
  CHECK(scalar_mass(law.value(), 2U) == pi2);
  REQUIRE(law.value().exact_tail_mass());
  CHECK(*law.value().exact_tail_mass() == tail);
  REQUIRE(law.value().exact_mean_backlog());
  CHECK(*law.value().exact_mean_backlog() == rational(23, 40));
  REQUIRE(summary.value().pi_zero());
  REQUIRE(summary.value().pi_one());
  REQUIRE(summary.value().pi_two());
  REQUIRE(summary.value().tail_mass_from_three());
  CHECK(*summary.value().pi_zero() == pi0);
  CHECK(*summary.value().pi_one() == pi1);
  CHECK(*summary.value().pi_two() == pi2);
  CHECK(*summary.value().tail_mass_from_three() == tail);
  CHECK(*summary.value().pi_zero() + *summary.value().pi_one() +
            *summary.value().pi_two() +
            *summary.value().tail_mass_from_three() ==
        ExactRational::one());
  CHECK(*summary.value().pi_zero() == scalar_mass(law.value(), 0U));
  CHECK(*summary.value().pi_one() == scalar_mass(law.value(), 1U));
  CHECK(*summary.value().pi_two() == scalar_mass(law.value(), 2U));
  CHECK(*summary.value().tail_mass_from_three() ==
        *law.value().exact_tail_mass());
  const std::array regions{
      StationaryConditioningRegionV1::backlog_zero,
      StationaryConditioningRegionV1::backlog_one,
      StationaryConditioningRegionV1::backlog_two,
      StationaryConditioningRegionV1::backlog_at_least_three};
  const std::array responses{ExactRational::zero(), rational(3, 4),
                             rational(1, 4), rational(2, 3)};
  const std::array masses{pi0, pi1, pi2, tail};
  const std::array kinds{
      StationaryConditioningMassKindV1::established_positive,
      StationaryConditioningMassKindV1::established_positive,
      StationaryConditioningMassKindV1::established_positive,
      StationaryConditioningMassKindV1::aggregate_only};
  const auto bins = summary.value().bins();
  for (std::size_t index = 0U; index < bins.size(); ++index) {
    CAPTURE(index);
    CHECK(bins[index].region == regions[index]);
    CHECK(bins[index].response == responses[index]);
    CHECK(bins[index].conditioning_mass.kind() == kinds[index]);
    REQUIRE(bins[index].conditioning_mass.mass());
    CHECK(*bins[index].conditioning_mass.mass() == masses[index]);
  }
  REQUIRE(bins.back().conditioning_mass.region());
  CHECK(*bins.back().conditioning_mass.region() ==
        StationaryConditioningRegionV1::backlog_at_least_three);
  REQUIRE(summary.value().exact_mean_backlog());
  REQUIRE(summary.value().exact_mean_sojourn());
  CHECK(*summary.value().exact_mean_backlog() == rational(23, 40));
  CHECK(*summary.value().exact_mean_sojourn() == rational(23, 10));
  CHECK(summary.value().tail_slack_applicability() ==
        TailSlackApplicabilityV1::applicable);
  REQUIRE(summary.value().tail_slack());
  CHECK(*summary.value().tail_slack() == rational(5, 12));
}

TEST_CASE("C19 F03 handles zero one and a near-one point exactly",
          "[c19][math][transform]") {
  const ExactRational lambda = rational(1, 4);
  const ExactRational service = rational(1, 2);
  const auto response = scalar_response(constant_bernoulli_spec(
      lineage("transform-points"), lambda, service));
  const ArrivalLaw arrival = arrival_from(response);
  const ScalarFluxOperator flux = scalar_flux(response, arrival);
  auto law = solve_scalar_cut_recursion(
      flux, TailPolicy::constant_response(Cutoff{BigNat{0U}},
                                          tail_service(service)));
  REQUIRE(law);

  const std::array points{ExactRational::zero(), ExactRational::one(),
                          rational(999, 1000)};
  for (const ExactRational& z : points) {
    auto readout = evaluate_scalar_pgf_and_moments(
        law.value(), ArrivalTransform::from(arrival), evaluation_point(z));
    REQUIRE(readout);
    REQUIRE(readout.value().exact_pgf());
    const ExactRational expected =
        rational(1, 2) + divide(z, rational(3) - z);
    CHECK(*readout.value().exact_pgf() == expected);
  }
}

TEST_CASE("C19 carrier routes preserve mode identity and reject temporal IID",
          "[c19][math][identity][temporal]") {
  auto engineered_spec = nonmonotone_three_bin_spec(lineage(
      "mode-engineered", ConstructionMethodV1::engineered_deterministic,
      ProducerModeV1::in_process_builder));
  auto sampled_spec = nonmonotone_three_bin_spec(lineage(
      "mode-sampled", ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder));
  const auto engineered = three_bin_response(std::move(engineered_spec));
  const auto sampled = three_bin_response(std::move(sampled_spec));
  const ArrivalLaw engineered_arrival = arrival_from(engineered);
  const ArrivalLaw sampled_arrival = arrival_from(sampled);
  auto engineered_summary =
      summarize_three_bin_iid_response(engineered, engineered_arrival);
  auto sampled_summary =
      summarize_three_bin_iid_response(sampled, sampled_arrival);
  REQUIRE(engineered_summary);
  REQUIRE(sampled_summary);
  CHECK(engineered_summary.value().pi_zero() ==
        sampled_summary.value().pi_zero());
  CHECK(engineered_summary.value().pi_one() ==
        sampled_summary.value().pi_one());
  CHECK(engineered_summary.value().pi_two() ==
        sampled_summary.value().pi_two());
  CHECK(engineered_summary.value().tail_mass_from_three() ==
        sampled_summary.value().tail_mass_from_three());
  CHECK(engineered_summary.value().exact_mean_backlog() ==
        sampled_summary.value().exact_mean_backlog());
  CHECK(engineered_summary.value().law_identity() !=
        sampled_summary.value().law_identity());
  CHECK(engineered_summary.value()
            .law_identity()
            .artifact()
            .construction_method ==
        ConstructionMethodV1::engineered_deterministic);
  CHECK(sampled_summary.value()
            .law_identity()
            .artifact()
            .construction_method == ConstructionMethodV1::sampled_offline);

  auto temporal_spec = constant_bernoulli_spec(
      lineage("temporal-not-iid"), rational(1, 4), rational(1, 2));
  temporal_spec.temporal_iid = false;
  const auto temporal = scalar_response(std::move(temporal_spec));
  auto rejected = ArrivalLaw::from_audited(temporal);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code.find("iid") != std::string::npos);
}
