#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#if defined(__linux__)
#include <elf.h>
#include <signal.h>
#endif

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

#if defined(__linux__) && defined(MWPERF_C16_TEST_BUILDER_PATH)
template <typename ElfHeader, typename ProgramHeader>
[[nodiscard]] bool helper_has_no_interpreter(
    std::ifstream& input, const unsigned char expected_class,
    const std::uint16_t expected_machine) {
  ElfHeader header{};
  input.read(reinterpret_cast<char*>(&header), sizeof(header));
  if (!input || std::memcmp(header.e_ident, ELFMAG, SELFMAG) != 0 ||
      header.e_ident[EI_CLASS] != expected_class ||
      header.e_ident[EI_DATA] != ELFDATA2LSB ||
      header.e_machine != expected_machine ||
      (header.e_type != ET_EXEC && header.e_type != ET_DYN) ||
      header.e_phentsize != sizeof(ProgramHeader) || header.e_phnum == 0U ||
      header.e_phnum == PN_XNUM) {
    return false;
  }
  for (std::uint16_t index = 0U; index < header.e_phnum; ++index) {
    ProgramHeader program{};
    const auto offset = static_cast<std::uintmax_t>(header.e_phoff) +
                        static_cast<std::uintmax_t>(index) *
                            sizeof(ProgramHeader);
    input.clear();
    input.seekg(static_cast<std::streamoff>(offset), std::ios::beg);
    input.read(reinterpret_cast<char*>(&program), sizeof(program));
    if (!input || program.p_type == PT_INTERP) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool test_builder_is_native_static_elf() {
  std::ifstream input(MWPERF_C16_TEST_BUILDER_PATH, std::ios::binary);
  if (!input.is_open()) {
    return false;
  }
#if defined(__x86_64__)
  return helper_has_no_interpreter<Elf64_Ehdr, Elf64_Phdr>(
      input, ELFCLASS64, EM_X86_64);
#elif defined(__aarch64__)
  return helper_has_no_interpreter<Elf64_Ehdr, Elf64_Phdr>(
      input, ELFCLASS64, EM_AARCH64);
#elif defined(__i386__)
  return helper_has_no_interpreter<Elf32_Ehdr, Elf32_Phdr>(
      input, ELFCLASS32, EM_386);
#else
  return false;
#endif
}
#endif

[[nodiscard]] mwperf::TypedLabel label(const std::string& text) {
  auto result = mwperf::TypedLabel::text(text);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::SourceNode object_node() {
  const mwperf::SourceLocation location{
      "c16-local-builder-security.json", 1U, 1U, 0U};
  return mwperf::SourceNode::make_object(
      {{"resolution_level", location,
        mwperf::SourceNode::make_number(
            "1", location, "/resolution_level")}},
      location, "");
}

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-local-builder-input";
  std::error_code filesystem_error;
  std::filesystem::create_directories(directory, filesystem_error);
  REQUIRE_FALSE(filesystem_error);
  const auto path =
      directory /
      (std::string(stem) + "-" +
       std::to_string(serial.fetch_add(1U, std::memory_order_relaxed)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] mwperf::ConstructionBudget construction_budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct LocalScenario final {
  mwperf::SurrogateProvider provider;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] LocalScenario make_local_scenario(const std::string& id) {
  static constexpr std::string_view kModel = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view kAnalysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.mwis.engineered","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}}
  })json";

  auto model_document = mwperf::load_document(
      write_input("runner-model", kModel));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);
  auto analysis_document = mwperf::load_document(
      write_input("runner-analysis", kAnalysis));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto metric_request = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(metric_request);
  const std::vector<mwperf::MetricRequest> metric_requests{
      metric_request.value()};
  auto requirements =
      mwperf::aggregate_metric_requirements(metric_requests);

  auto typed_id = mwperf::SurrogateId::parse(id);
  REQUIRE(typed_id);
  auto provider = mwperf::lookup_surrogate_provider(typed_id.value());
  INFO((provider ? std::string{} : provider.error().code));
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U,
      {mwperf::QueueId(label("q0"))},
      mwperf::ConstructionGroupIdV1(label("c16.runner.group"))};
  auto view = mwperf::build_framework_problem_view(
      instance.value(), *arrival.value(), targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), object_node());
  REQUIRE(parameters);
  auto budget = construction_budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), requirements, budget,
      parameters.value());
  INFO((preview ? std::string{} : preview.error().code));
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const auto& manifest = provider.value().manifest().value();
  auto contract = Factory::accepted_contract(
      manifest, preview.value().core,
      *preview.value().metric_support_manifest, requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, mwperf::MasterSeed(0xC16U));
  INFO((request ? std::string{} : request.error().code));
  REQUIRE(request);
  return {std::move(provider).value(), std::move(request).value()};
}

[[nodiscard]] std::filesystem::path execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
              "c16-local-builder-runs";
  std::error_code filesystem_error;
  std::filesystem::create_directories(root, filesystem_error);
  REQUIRE_FALSE(filesystem_error);
  root = std::filesystem::canonical(root, filesystem_error);
  REQUIRE_FALSE(filesystem_error);
  return root;
}

[[nodiscard]] mwperf::BuildExecutionContext execution_context(
    const LocalScenario& scenario) {
  auto context = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root());
  INFO((context ? std::string{} : context.error().code));
  REQUIRE(context);
  return std::move(context).value();
}

[[nodiscard]] std::string failure_code(
    const mwperf::ProviderExecutionOutcome& outcome) {
  const auto* failure = std::get_if<mwperf::FailedProviderExecution>(&outcome);
  REQUIRE(failure != nullptr);
  for (const auto& note : failure->diagnostic.notes) {
    UNSCOPED_INFO(note);
  }
  return failure->diagnostic.code;
}

[[nodiscard]] std::size_t private_run_directory_count() {
  std::error_code filesystem_error;
  std::size_t count = 0U;
  for (std::filesystem::directory_iterator iterator(
           execution_root(), filesystem_error), end;
       !filesystem_error && iterator != end;
       iterator.increment(filesystem_error)) {
    if (iterator->is_directory(filesystem_error) && !filesystem_error &&
        iterator->path().filename().string().starts_with(
            ".mwperf-surrogate-build-v1-")) {
      ++count;
    }
  }
  REQUIRE_FALSE(filesystem_error);
  return count;
}

class ScopedPathRemoval final {
 public:
  explicit ScopedPathRemoval(std::filesystem::path path)
      : path_(std::move(path)) {}
  ScopedPathRemoval(const ScopedPathRemoval&) = delete;
  ScopedPathRemoval& operator=(const ScopedPathRemoval&) = delete;
  ~ScopedPathRemoval() {
    std::error_code ignored;
    (void)std::filesystem::remove(path_, ignored);
  }

 private:
  std::filesystem::path path_;
};

#if defined(__linux__)
class ScopedIgnoredBlockedSignal final {
 public:
  ScopedIgnoredBlockedSignal() = default;
  ScopedIgnoredBlockedSignal(const ScopedIgnoredBlockedSignal&) = delete;
  ScopedIgnoredBlockedSignal& operator=(const ScopedIgnoredBlockedSignal&) =
      delete;
  ~ScopedIgnoredBlockedSignal() {
    if (saved_action_) {
      (void)::sigaction(SIGUSR1, &original_action_, nullptr);
    }
    if (saved_mask_) {
      (void)::sigprocmask(SIG_SETMASK, &original_mask_, nullptr);
    }
  }

  [[nodiscard]] bool apply() {
    if (::sigaction(SIGUSR1, nullptr, &original_action_) != 0) {
      return false;
    }
    saved_action_ = true;
    if (::sigprocmask(SIG_SETMASK, nullptr, &original_mask_) != 0) {
      return false;
    }
    saved_mask_ = true;
    struct sigaction ignored {};
    ignored.sa_handler = SIG_IGN;
    if (::sigemptyset(&ignored.sa_mask) != 0 ||
        ::sigaction(SIGUSR1, &ignored, nullptr) != 0) {
      return false;
    }
    sigset_t blocked = original_mask_;
    if (::sigaddset(&blocked, SIGUSR1) != 0 ||
        ::sigprocmask(SIG_SETMASK, &blocked, nullptr) != 0) {
      return false;
    }
    return true;
  }

 private:
  struct sigaction original_action_ {};
  sigset_t original_mask_{};
  bool saved_action_{false};
  bool saved_mask_{false};
};
#endif

}  // namespace

TEST_CASE("C16 parent retains a no-throw child reap guard",
          "[c16][unit][runner-security]") {
  const auto source_path =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) /
      "src/surrogate/local_builder_runner.cpp";
  std::ifstream input(source_path, std::ios::binary);
  REQUIRE(input.is_open());
  const std::string source((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());

  const auto guard_type = source.find("class ScopedChildProcess final");
  const auto noexcept_cleanup =
      source.find("~ScopedChildProcess() noexcept", guard_type);
  const auto process_creation =
      source.find("const pid_t child = ::clone(static_builder_child_main,");
  const auto guard = source.find("ScopedChildProcess child_guard(child);",
                                 process_creation);
  const auto observe = source.find("auto observation = observe_process(",
                                   guard);
  const auto release = source.find("child_guard.release();", observe);

  REQUIRE(guard_type != std::string::npos);
  CHECK(noexcept_cleanup != std::string::npos);
  REQUIRE(process_creation != std::string::npos);
  REQUIRE(guard != std::string::npos);
  REQUIRE(observe != std::string::npos);
  CHECK(process_creation < guard);
  CHECK(guard < observe);
  CHECK(release != std::string::npos);
}

#if defined(__linux__) && defined(MWPERF_C16_TEST_BUILDER_PATH)

TEST_CASE("C16 local test builder is native static ELF",
          "[c16][unit][runner-security]") {
  REQUIRE(test_builder_is_native_static_elf());
}

TEST_CASE("C16 local builder cannot read an ambient sibling file",
          "[c16][integration][runner-security]") {
  const auto sentinel = execution_root() / "ambient-sentinel";
  ScopedPathRemoval cleanup(sentinel);
  std::ofstream output(sentinel, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output << "ambient secret";
  REQUIRE(output.good());
  output.close();

  const auto before = private_run_directory_count();
  auto scenario = make_local_scenario(
      "c16.fixture.transport.local.ambient-read-denied");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  if (completed == nullptr) {
    CHECK(failure_code(outcome) ==
          "c16.local_builder_forbidden_filesystem_access");
  }
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 local builder cannot read an ambient absolute file",
          "[c16][integration][runner-security]") {
  const auto before = private_run_directory_count();
  auto scenario = make_local_scenario(
      "c16.fixture.transport.local.ambient-absolute-read-denied");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  if (completed == nullptr) {
    CHECK(failure_code(outcome) ==
          "c16.local_builder_forbidden_filesystem_access");
  }
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 capability broker confines arbitrary first paths",
          "[c16][integration][runner-security]") {
  const auto sentinel = execution_root() / "capability-write-sentinel";
  ScopedPathRemoval cleanup(sentinel);
  REQUIRE_FALSE(std::filesystem::exists(sentinel));
  const auto before = private_run_directory_count();
  auto scenario = make_local_scenario(
      "c16.fixture.transport.local.ambient-first-virtualized");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  const bool virtualized =
      std::holds_alternative<mwperf::CompletedProviderExecution>(outcome);
  INFO((virtualized ? std::string{} : failure_code(outcome)));
  // Exact-path carriers reject the foreign pathname immediately.  A carrier
  // that forbids safe cross-memory inspection instead maps it only to the
  // sealed protocol capability.  Neither branch can read or write the named
  // ambient object.
  CHECK((virtualized ||
         failure_code(outcome) ==
             "c16.local_builder_forbidden_filesystem_access"));
  CHECK_FALSE(std::filesystem::exists(sentinel));
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 local builder treats shell metacharacters as inert argv data",
          "[c16][integration][runner-security]") {
  const auto before = private_run_directory_count();
  auto scenario =
      make_local_scenario("c16.fixture.transport.local.metacharacters");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  INFO((std::holds_alternative<mwperf::CompletedProviderExecution>(outcome)
            ? std::string{}
            : failure_code(outcome)));
  REQUIRE(std::holds_alternative<mwperf::CompletedProviderExecution>(outcome));
  CHECK(private_run_directory_count() == before);
  CHECK_FALSE(std::filesystem::exists(execution_root() /
                                      "shell-injection-sentinel"));
}

TEST_CASE("C16 local builder cannot obtain ambient entropy or SysV IPC",
          "[c16][integration][runner-security]") {
  const auto before = private_run_directory_count();
  auto scenario = make_local_scenario(
      "c16.fixture.transport.local.ambient-kernel-state-denied");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  INFO((std::holds_alternative<mwperf::CompletedProviderExecution>(outcome)
            ? std::string{}
            : failure_code(outcome)));
  REQUIRE(std::holds_alternative<mwperf::CompletedProviderExecution>(outcome));
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 local builder normalizes inherited signal state",
          "[c16][negative][runner-security]") {
  auto scenario = make_local_scenario("c16.fixture.transport.local.signal");
  auto context = execution_context(scenario);
  ScopedIgnoredBlockedSignal inherited_state;
  REQUIRE(inherited_state.apply());
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  CHECK(failure_code(outcome) == "c16.local_builder_signaled");
}

TEST_CASE("C16 local builder permits contained worker threads",
          "[c16][integration][runner-security]") {
  const auto before = private_run_directory_count();
  auto scenario =
      make_local_scenario("c16.fixture.transport.local.threaded");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  INFO((std::holds_alternative<mwperf::CompletedProviderExecution>(outcome)
            ? std::string{}
            : failure_code(outcome)));
  REQUIRE(std::holds_alternative<mwperf::CompletedProviderExecution>(outcome));
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 thread permission does not admit process or namespace clone",
          "[c16][integration][runner-security]") {
  const auto before = private_run_directory_count();
  auto scenario =
      make_local_scenario("c16.fixture.transport.local.clone-policy");
  auto context = execution_context(scenario);
  const auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  INFO((std::holds_alternative<mwperf::CompletedProviderExecution>(outcome)
            ? std::string{}
            : failure_code(outcome)));
  REQUIRE(std::holds_alternative<mwperf::CompletedProviderExecution>(outcome));
  CHECK(private_run_directory_count() == before);
}

TEST_CASE("C16 local builder rejects every incomplete transport outcome",
          "[c16][negative][runner-security]") {
  const std::array cases{
      std::pair{"missing-result", "c16.local_builder_missing_result"},
      std::pair{"partial-result", "c16.local_builder_timeout"},
      std::pair{"extra-file", "c16.local_builder_duplicate_output"},
      std::pair{"nonzero", "c16.local_builder_nonzero_exit"},
      std::pair{"signal", "c16.local_builder_signaled"},
      std::pair{"timeout", "c16.local_builder_timeout"},
      std::pair{"stdout", "c16.local_builder_stdout_forbidden"},
      std::pair{"stderr", "c16.local_builder_stderr_limit"},
      std::pair{"stderr-large", "c16.local_builder_stderr_limit"},
      std::pair{"oversize", "c16.local_builder_result_limit"}};
  for (const auto& [suffix, expected] : cases) {
    const auto before = private_run_directory_count();
    auto scenario = make_local_scenario(
        std::string("c16.fixture.transport.local.") + suffix);
    auto context = execution_context(scenario);
    const auto started = std::chrono::steady_clock::now();
    const auto outcome = mwperf::execute_surrogate_provider(
        scenario.provider, scenario.request, context);
    const auto elapsed = std::chrono::steady_clock::now() - started;
    INFO(suffix);
    CHECK(failure_code(outcome) == expected);
    if (std::string_view(suffix) == "timeout" ||
        std::string_view(suffix) == "partial-result") {
      INFO(std::chrono::duration_cast<std::chrono::milliseconds>(elapsed)
               .count());
      CHECK(elapsed < std::chrono::seconds(2));
    }
    CHECK(private_run_directory_count() == before);
  }
}

TEST_CASE("C16 local runner never launches an inert unregistered spec",
          "[c16][negative][runner-security]") {
  auto scenario =
      make_local_scenario("c16.fixture.transport.local.success");
  auto context = execution_context(scenario);
  auto inert = mwperf::detail::SurrogateRegistryAssembler::executable_spec(
      scenario.provider.identity(),
      scenario.provider.manifest().value().manifest_digest,
      "c16.fixture.builder.unregistered",
      std::filesystem::path(MWPERF_C16_TEST_BUILDER_PATH), 1U, {},
      std::chrono::milliseconds(2000), 4096U, 1U << 20U, 1U << 20U);
  REQUIRE(inert);
  const auto before = private_run_directory_count();
  const auto outcome = mwperf::run_local_surrogate_builder(
      inert.value(), scenario.request, context);
  CHECK(failure_code(outcome) == "c16.unregistered_executable_spec");
  CHECK_FALSE(context.local_transport_accounting().launch_attempted);
  CHECK_FALSE(context.local_transport_accounting().process_started);
  CHECK(private_run_directory_count() == before);
}

#endif
