#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "support/c16_audited_handle_fixture.hpp"

namespace {

[[nodiscard]] mwperf::Diagnostic test_error(std::string code,
                                            std::string message) {
  return {mwperf::DiagnosticCategory::internal, std::move(code),
          std::move(message), std::nullopt, std::nullopt, {}};
}

[[nodiscard]] mwperf::TypedLabel label(const std::string& text) {
  auto result = mwperf::TypedLabel::text(text);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue_id(const std::string& text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::Digest256 digest_of(const std::string_view text) {
  auto result = mwperf::sha256(
      std::as_bytes(std::span<const char>(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ProbabilityMass exact_mass(
    const std::int64_t numerator, const std::int64_t denominator) {
  auto result = mwperf::ProbabilityMass::exact_rational(
      rational(numerator, denominator), true);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-initial-law";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

constexpr std::string_view kModel = R"json({
  "schema_version":"3.0.0",
  "run":{"seed":23,"slots":8,"warmup_slots":0,
         "termination":"fixed_slots"},
  "switch":{"kind":"generalized","queue_capacity":null,
            "queues":[{"id":"q0"},{"id":"q1"}]},
  "scheduler":{"name":"conflict_graph_max_weight","params":{
    "constraint":{"conflicts":[]},"priority":["q0","q1"],
    "max_search_states":null}},
  "arrival":{
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"s"}],
    "states":["h0","h1"],
    "initial":{"distribution":[
      {"state":"h0","probability":0.25},
      {"state":"h1","probability":0.75}]},
    "outcomes":[
      {"state":"h0","next_state":"h0","probability":1,
       "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
      {"state":"h1","next_state":"h1","probability":1,
       "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]}],
    "metadata":{}},
  "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
               "include_packet_events":false,
               "include_scheduler_state":false,"write_slot_trace":false},
  "metadata":{}
})json";

constexpr std::string_view kTransientAnalysis = R"json({
  "analysis_schema_version":"1.0.0",
  "targets":["q0"],
  "metrics":[{"id":"law","kind":"transient_backlog_law",
              "parameters":{"horizons":[0,1]}}],
  "surrogate":{"id":"future","version":null,"parameters":{}},
  "resolution":{
    "level":{"max_states":64,"max_row_atoms":64},
    "tail":{"kind":"none","parameters":{}},
    "phase":{"max_phase_states":64},
    "optimizer":{"max_calls":1,"max_search_states_per_call":1},
    "sampling":{"max_generator_draws":1},
    "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                 "tail_abs":null,"fixed_point_abs":null}},
  "selection":{"kind":"transient","parameters":{"initial_law":{"atoms":[
    {"probability":0.25,
     "backlog":[{"queue_id":"q0","value":0},
                {"queue_id":"q1","value":2}],
     "controller_state":{},
     "arrival_state":{"kind":"shared_round_state","state":"h0"},
     "static_context":{},"surrogate_initial":{"tag":"physical-a"}},
    {"probability":0.75,
     "backlog":[{"queue_id":"q0","value":5},
                {"queue_id":"q1","value":0}],
     "controller_state":{},
     "arrival_state":{"kind":"shared_round_state","state":"h1"},
     "static_context":{},"surrogate_initial":{"tag":"physical-b"}}
  ]}}},
  "solver":{"kind":"enumerated","parameters":{
    "linear_method":"dense_pivoted","max_iterations":null}}
})json";

constexpr std::string_view kStationaryAnalysis = R"json({
  "analysis_schema_version":"1.0.0",
  "targets":["q0"],
  "metrics":[{"id":"throughput","kind":"stationary_throughput",
              "parameters":{}}],
  "surrogate":{"id":"future","version":null,"parameters":{}},
  "resolution":{
    "level":{"max_states":64,"max_row_atoms":64},
    "tail":{"kind":"none","parameters":{}},
    "phase":{"max_phase_states":64},
    "optimizer":{"max_calls":1,"max_search_states_per_call":1},
    "sampling":{"max_generator_draws":1},
    "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                 "tail_abs":null,"fixed_point_abs":null}},
  "selection":{"kind":"stationary_unique","parameters":{}},
  "solver":{"kind":"analytic","parameters":{
    "precision_bits":128,"max_iterations":null}}
})json";

struct InitialFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  std::optional<mwperf::InitialPhysicalLaw> physical_initializer;
  mwperf::TargetSelection targets;
  mwperf::FrameworkProblemView view;
};

[[nodiscard]] InitialFixture make_fixture_from_inputs(
    const std::string_view model_text,
    const std::string_view analysis_text, const bool transient) {
  auto model_document =
      mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);

  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((instance ? std::string{} : instance.error().code));
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);

  std::optional<mwperf::InitialPhysicalLaw> initializer;
  if (transient) {
    REQUIRE(instance.value().initial_law());
    auto compiled = mwperf::detail::CompiledInitialLawAccess::get(
        *instance.value().initial_law());
    REQUIRE(compiled);
    initializer = *compiled.value();
  }

  mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.initial-law.group"))};
  auto view = mwperf::build_framework_problem_view(
      instance.value(), *arrival.value(), targets);
  REQUIRE(view);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(initializer), std::move(targets),
          std::move(view).value()};
}

[[nodiscard]] InitialFixture make_fixture_from_analysis(
    const std::string_view analysis_text, const bool transient) {
  return make_fixture_from_inputs(kModel, analysis_text, transient);
}

[[nodiscard]] InitialFixture make_fixture(const bool transient) {
  return make_fixture_from_analysis(
      transient ? kTransientAnalysis : kStationaryAnalysis, transient);
}

[[nodiscard]] InitialFixture make_fixed_point_fixture() {
  std::string analysis(kStationaryAnalysis);
  static constexpr std::string_view stationary =
      R"json("selection":{"kind":"stationary_unique","parameters":{}})json";
  static constexpr std::string_view fixed =
      R"json("selection":{"kind":"fixed_point","parameters":{"mode":"unique"}})json";
  const auto position = analysis.find(stationary);
  REQUIRE(position != std::string::npos);
  analysis.replace(position, stationary.size(), fixed);
  return make_fixture_from_analysis(analysis, false);
}

[[nodiscard]] InitialFixture make_stationary_class_fixture() {
  std::string analysis(kStationaryAnalysis);
  static constexpr std::string_view stationary =
      R"json("selection":{"kind":"stationary_unique","parameters":{}})json";
  static constexpr std::string_view selected =
      R"json("selection":{"kind":"stationary_class","parameters":{"class_id":"class-a"}})json";
  const auto position = analysis.find(stationary);
  REQUIRE(position != std::string::npos);
  analysis.replace(position, stationary.size(), selected);
  return make_fixture_from_analysis(analysis, false);
}

[[nodiscard]] InitialFixture make_fixed_point_id_fixture() {
  std::string analysis(kStationaryAnalysis);
  static constexpr std::string_view stationary =
      R"json("selection":{"kind":"stationary_unique","parameters":{}})json";
  static constexpr std::string_view selected =
      R"json("selection":{"kind":"fixed_point","parameters":{"mode":"id","solution_id":"root-a"}})json";
  const auto position = analysis.find(stationary);
  REQUIRE(position != std::string::npos);
  analysis.replace(position, stationary.size(), selected);
  return make_fixture_from_analysis(analysis, false);
}

struct SeamIdentity final {
  mwperf::CodecIdentityV1 codec{"c16.initial-law.reduced-state", 1U};
  mwperf::Digest256 exact_state_schema =
      digest_of("c16.initial-law.exact-state-schema");
  mwperf::Digest256 reduced_state_schema =
      digest_of("c16.initial-law.reduced-state-schema");
  mwperf::Digest256 selection = digest_of("c16.initial-law.selection");
};

[[nodiscard]] mwperf::AuditedFrameworkBindingsV1 bindings_for(
    const InitialFixture& fixture, const SeamIdentity& identity) {
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          fixture.targets.ordered_targets);
  REQUIRE(ordered_target_digest);
  return {fixture.view.fingerprints(),
          fixture.view.canonical_digest(),
          identity.exact_state_schema,
          identity.reduced_state_schema,
          digest_of("c16.initial-law.descriptor"),
          digest_of("c16.initial-law.access"),
          digest_of("c16.initial-law.accepted-contract"),
          digest_of("c16.initial-law.metric-requirements"),
          std::move(ordered_target_digest).value(),
          identity.selection,
          digest_of("c16.initial-law.build-request"),
          std::nullopt};
}

[[nodiscard]] mwperf::ReducedStateV1 reduced_state_coordinates(
    const SeamIdentity& identity, const std::uint8_t backlog_ordinal,
    const std::uint8_t arrival_ordinal,
    const std::uint8_t controller_ordinal,
    const std::uint8_t surrogate_phase) {
  return {identity.codec,
          {std::byte{0x4e}, std::byte{backlog_ordinal}, std::byte{0x48},
           std::byte{arrival_ordinal}, std::byte{0x43},
           std::byte{controller_ordinal}, std::byte{0x5a},
           std::byte{surrogate_phase}}};
}

[[nodiscard]] mwperf::ReducedStateV1 reduced_state(
    const SeamIdentity& identity, const std::uint8_t physical_ordinal,
    const std::uint8_t surrogate_phase) {
  return reduced_state_coordinates(identity, physical_ordinal,
                                   physical_ordinal, physical_ordinal,
                                   surrogate_phase);
}

[[nodiscard]] mwperf::ReducedInitialLawCandidateV1 transient_candidate(
    const SeamIdentity& identity,
    const mwperf::SelectionSupportV1& support) {
  return {identity.codec,
          identity.exact_state_schema,
          identity.reduced_state_schema,
          identity.selection,
          support,
          {{reduced_state(identity, 0U, 0U), exact_mass(1, 2), 0U},
           {reduced_state(identity, 0U, 1U), exact_mass(1, 2), 0U},
           {reduced_state(identity, 1U, 0U), exact_mass(1, 1), 1U}}};
}

[[nodiscard]] mwperf::ReducedInitialLawCandidateV1 stationary_candidate(
    const SeamIdentity& identity,
    const mwperf::SelectionSupportV1& support) {
  return {identity.codec,
          identity.exact_state_schema,
          identity.reduced_state_schema,
          identity.selection,
          support,
          {{reduced_state(identity, 0U, 0U), exact_mass(1, 1),
            std::nullopt}}};
}

[[nodiscard]] mwperf::SealedExactStateSchemaValidatorV1 accept_exact_schema(
    const SeamIdentity& identity) {
  return [expected = identity.exact_state_schema](
             const mwperf::ResolvedInstance&,
             const mwperf::Digest256& supplied) {
    if (supplied != expected) {
      return mwperf::Result<void>::failure(test_error(
          "test.c16.exact_state_schema_mismatch",
          "the exact-state schema supplied by the seam was not sealed"));
    }
    return mwperf::Result<void>::success();
  };
}

[[nodiscard]] mwperf::SealedReducedStateDomainValidatorV1
accept_reduced_domain(const SeamIdentity& identity) {
  return [codec = identity.codec](const mwperf::ReducedStateV1& state) {
    if (state.codec != codec || state.canonical_value.size() != 8U) {
      return mwperf::Result<void>::failure(test_error(
          "test.c16.reduced_state_domain_mismatch",
          "the reduced state is outside the sealed fixture domain"));
    }
    return mwperf::Result<void>::success();
  };
}

[[nodiscard]] mwperf::SealedPhysicalAtomProjectionValidatorV1
exact_physical_projection() {
  return [](const std::size_t ordinal,
            const mwperf::InitialPhysicalAtom& physical,
            const mwperf::ReducedStateV1& state) {
    if (ordinal > 1U || physical.backlog.size() != 2U ||
        physical.controller_state.kind() != mwperf::SourceNodeKind::object ||
        !physical.controller_state.object_members().empty() ||
        !std::holds_alternative<mwperf::SharedRoundState>(
            physical.arrival_state) ||
        state.canonical_value.size() != 8U) {
      return mwperf::Result<void>::failure(test_error(
          "test.c16.physical_projection_shape",
          "the complete physical atom has an unexpected joint shape"));
    }
    const auto& arrival =
        std::get<mwperf::SharedRoundState>(physical.arrival_state);
    const auto* tag = physical.surrogate_initial.find("tag");
    const std::string expected_arrival = ordinal == 0U ? "h0" : "h1";
    const std::string expected_tag =
        ordinal == 0U ? "physical-a" : "physical-b";
    const std::string expected_q0 = ordinal == 0U ? "0" : "5";
    const std::string expected_q1 = ordinal == 0U ? "2" : "0";
    const auto encoded =
        static_cast<unsigned char>(state.canonical_value[1U]);
    const auto encoded_arrival =
        static_cast<unsigned char>(state.canonical_value[3U]);
    const auto encoded_controller =
        static_cast<unsigned char>(state.canonical_value[5U]);
    if (arrival.state != expected_arrival || tag == nullptr ||
        tag->string_value() == nullptr ||
        *tag->string_value() != expected_tag ||
        physical.backlog[0U].to_decimal_string() != expected_q0 ||
        physical.backlog[1U].to_decimal_string() != expected_q1 ||
        state.canonical_value[0U] != std::byte{0x4e} ||
        state.canonical_value[2U] != std::byte{0x48} ||
        state.canonical_value[4U] != std::byte{0x43} ||
        state.canonical_value[6U] != std::byte{0x5a} ||
        encoded != ordinal || encoded_arrival != ordinal ||
        encoded_controller != ordinal) {
      return mwperf::Result<void>::failure(test_error(
          "test.c16.physical_projection_not_joint",
          "the reduced state did not retain the exact N/H/controller/Z atom"));
    }
    return mwperf::Result<void>::success();
  };
}

[[nodiscard]] mwperf::Result<mwperf::AuditedCompiledFramework> mint_framework(
    const InitialFixture& fixture, const SeamIdentity& identity,
    mwperf::SelectionSupportV1 support,
    mwperf::InitialSelectionAuthorityV1 authority,
    mwperf::ReducedInitialMapperV1 mapper,
    mwperf::SealedExactStateSchemaValidatorV1 schema_validator,
    mwperf::SealedReducedStateDomainValidatorV1 domain_validator,
    mwperf::SealedPhysicalAtomProjectionValidatorV1 projection_validator) {
  return mwperf::testing::C16FixtureAuditedMint::framework(
      bindings_for(fixture, identity), fixture.targets, identity.codec,
      std::move(support), std::move(authority), std::move(mapper),
      std::move(schema_validator), std::move(domain_validator),
      std::move(projection_validator));
}

}  // namespace

TEST_CASE("C16 F06 preserves the exact joint transient push-forward",
          "[c16][property]") {
  auto fixture = make_fixture(true);
  REQUIRE(fixture.physical_initializer);
  REQUIRE(fixture.physical_initializer->atoms().size() == 2U);
  CHECK(fixture.physical_initializer->atoms()[0U].probability ==
        rational(1, 4));
  CHECK(fixture.physical_initializer->atoms()[1U].probability ==
        rational(3, 4));

  const SeamIdentity identity;
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::transient_initial}, {}, {}};
  std::size_t alpha_calls = 0U;
  std::size_t schema_calls = 0U;
  std::size_t projection_calls = 0U;
  auto framework = mint_framework(
      fixture, identity, support,
      {mwperf::SelectionKindV1::transient_initial, std::nullopt},
      [&, identity, support](
          const mwperf::SelectionSpec& selection,
          const std::optional<mwperf::InitialPhysicalLaw>& initializer) {
        ++alpha_calls;
        if (!std::holds_alternative<mwperf::TransientSelection>(selection) ||
            !initializer || initializer->atoms().size() != 2U ||
            !initializer->shares_origin_with(*fixture.physical_initializer) ||
            initializer->arrival_binding() !=
                fixture.physical_initializer->arrival_binding() ||
            initializer->arrival_binding().timing != fixture.instance.timing()) {
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::failure(test_error(
              "test.c16.alpha0_input_mismatch",
              "alpha0 did not receive the exact transient joint law"));
        }
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            transient_candidate(identity, support));
      },
      [&](const mwperf::ResolvedInstance& instance,
          const mwperf::Digest256& exact_schema) {
        ++schema_calls;
        if (instance.fingerprints() != fixture.instance.fingerprints() ||
            instance.timing() != fixture.instance.timing() ||
            exact_schema != identity.exact_state_schema) {
          return mwperf::Result<void>::failure(test_error(
              "test.c16.exact_carrier_binding_mismatch",
              "the sealed schema validator received a foreign carrier"));
        }
        return mwperf::Result<void>::success();
      },
      accept_reduced_domain(identity),
      [&, projection = exact_physical_projection()](
          const std::size_t ordinal,
          const mwperf::InitialPhysicalAtom& physical,
          const mwperf::ReducedStateV1& state) {
        ++projection_calls;
        return projection(ordinal, physical, state);
      });
  REQUIRE(framework);
  REQUIRE(fixture.instance.analysis_spec().context);
  auto law = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection,
      fixture.physical_initializer);
  INFO((law ? std::string{} : law.error().code));
  REQUIRE(law);
  REQUIRE(mwperf::validate_reduced_initial_law_v1(law.value()));
  REQUIRE(law.value().atoms().size() == 3U);
  CHECK(law.value().atoms()[0U].mass.exact_value() == rational(1, 8));
  CHECK(law.value().atoms()[1U].mass.exact_value() == rational(1, 8));
  CHECK(law.value().atoms()[2U].mass.exact_value() == rational(3, 4));
  CHECK(law.value().state_codec() == identity.codec);
  CHECK(law.value().exact_state_schema_digest() ==
        identity.exact_state_schema);
  CHECK(law.value().reduced_state_schema_digest() ==
        identity.reduced_state_schema);
  CHECK(law.value().selection_digest() == identity.selection);
  CHECK(law.value().selection_support() == support);
  CHECK(alpha_calls == 1U);
  CHECK(schema_calls == 1U);
  CHECK(projection_calls == 3U);
}

TEST_CASE("C16 F06 enforces the physical-initializer selection boundary",
          "[c16][negative]") {
  const SeamIdentity identity;

  SECTION("transient requires its initializer") {
    auto fixture = make_fixture(true);
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::transient_initial}, {}, {}};
    std::size_t alpha_calls = 0U;
    std::size_t schema_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::transient_initial, std::nullopt},
        [&](const mwperf::SelectionSpec&,
            const std::optional<mwperf::InitialPhysicalLaw>&) {
          ++alpha_calls;
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              transient_candidate(identity, support));
        },
        [&](const mwperf::ResolvedInstance&, const mwperf::Digest256&) {
          ++schema_calls;
          return mwperf::Result<void>::success();
        },
        accept_reduced_domain(identity), exact_physical_projection());
    REQUIRE(framework);
    auto result = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection, std::nullopt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.transient_initializer_required");
    CHECK(alpha_calls == 0U);
    CHECK(schema_calls == 0U);
  }

  SECTION("stationary forbids a transient initializer") {
    auto fixture = make_fixture(false);
    auto transient = make_fixture(true);
    REQUIRE(transient.physical_initializer);
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::stationary_unique,
         digest_of("c16.stationary.uniqueness-evidence")},
        [&](const mwperf::SelectionSpec&,
            const std::optional<mwperf::InitialPhysicalLaw>&) {
          ++alpha_calls;
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto result = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection,
        transient.physical_initializer);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.nontransient_initializer_forbidden");
    CHECK(alpha_calls == 0U);
  }

  SECTION("fixed point forbids a transient initializer") {
    auto fixture = make_fixed_point_fixture();
    auto transient = make_fixture(true);
    REQUIRE(transient.physical_initializer);
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::fixed_point_unique}, {}, {}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::fixed_point_unique,
         digest_of("c16.fixed-point.uniqueness-evidence")},
        [&](const mwperf::SelectionSpec&,
            const std::optional<mwperf::InitialPhysicalLaw>&) {
          ++alpha_calls;
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto result = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection,
        transient.physical_initializer);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.nontransient_initializer_forbidden");
    CHECK(alpha_calls == 0U);
  }
}

TEST_CASE("C16 F06 validates the sealed exact-state schema before alpha0",
          "[c16][negative]") {
  auto fixture = make_fixture(true);
  REQUIRE(fixture.physical_initializer);
  const SeamIdentity identity;
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::transient_initial}, {}, {}};
  std::size_t schema_calls = 0U;
  std::size_t alpha_calls = 0U;
  std::size_t domain_calls = 0U;
  std::size_t projection_calls = 0U;
  auto framework = mint_framework(
      fixture, identity, support,
      {mwperf::SelectionKindV1::transient_initial, std::nullopt},
      [&, identity, support](const mwperf::SelectionSpec&,
                             const std::optional<mwperf::InitialPhysicalLaw>&) {
        ++alpha_calls;
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            transient_candidate(identity, support));
      },
      [&](const mwperf::ResolvedInstance&, const mwperf::Digest256&) {
        ++schema_calls;
        return mwperf::Result<void>::failure(test_error(
            "test.c16.sealed_exact_schema_rejected",
            "the fixture rejected the foreign exact-state schema"));
      },
      [&](const mwperf::ReducedStateV1&) {
        ++domain_calls;
        return mwperf::Result<void>::success();
      },
      [&](std::size_t, const mwperf::InitialPhysicalAtom&,
          const mwperf::ReducedStateV1&) {
        ++projection_calls;
        return mwperf::Result<void>::success();
      });
  REQUIRE(framework);
  auto result = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection,
      fixture.physical_initializer);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "test.c16.sealed_exact_schema_rejected");
  CHECK(schema_calls == 1U);
  CHECK(alpha_calls == 0U);
  CHECK(domain_calls == 0U);
  CHECK(projection_calls == 0U);
}

TEST_CASE("C16 F06 requires evidence for a unique stationary selection",
          "[c16][negative]") {
  auto fixture = make_fixture(false);
  const SeamIdentity identity;
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
  std::size_t alpha_calls = 0U;
  auto framework = mint_framework(
      fixture, identity, support,
      {mwperf::SelectionKindV1::stationary_unique, std::nullopt},
      [&, identity, support](const mwperf::SelectionSpec&,
                             const std::optional<mwperf::InitialPhysicalLaw>&) {
        ++alpha_calls;
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            stationary_candidate(identity, support));
      },
      accept_exact_schema(identity), accept_reduced_domain(identity),
      exact_physical_projection());
  REQUIRE(framework);
  auto result = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection, std::nullopt);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.initial_selection_evidence_missing");
  CHECK(alpha_calls == 0U);
}

TEST_CASE("C16 F06 rejects plural support for a unique selection",
          "[c16][negative]") {
  const SeamIdentity identity;

  SECTION("stationary unique") {
    auto fixture = make_fixture(false);
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::stationary_unique},
        {label("stationary-a"), label("stationary-b")}, {}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::stationary_unique,
         digest_of("c16.stationary.uniqueness-evidence")},
        [&, identity, support](
            const mwperf::SelectionSpec&,
            const std::optional<mwperf::InitialPhysicalLaw>&) {
          ++alpha_calls;
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto result = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection, std::nullopt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c16.stationary_uniqueness_contradicted");
    CHECK(alpha_calls == 0U);
  }

  SECTION("fixed-point unique") {
    auto fixture = make_fixed_point_fixture();
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::fixed_point_unique}, {},
        {label("fixed-a"), label("fixed-b")}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::fixed_point_unique,
         digest_of("c16.fixed-point.uniqueness-evidence")},
        [&, identity, support](
            const mwperf::SelectionSpec&,
            const std::optional<mwperf::InitialPhysicalLaw>&) {
          ++alpha_calls;
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto result = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection, std::nullopt);
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "c16.fixed_point_uniqueness_contradicted");
    CHECK(alpha_calls == 0U);
  }
}

TEST_CASE("C16 F06 accepts configured explicit stationary selectors",
          "[c16][property]") {
  const SeamIdentity identity;

  SECTION("named stationary class") {
    auto fixture = make_stationary_class_fixture();
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::stationary_class},
        {label("class-a"), label("class-b")}, {}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::stationary_class, std::nullopt},
        [&, identity, support](
            const mwperf::SelectionSpec& selection,
            const std::optional<mwperf::InitialPhysicalLaw>& initializer) {
          ++alpha_calls;
          const auto* selected =
              std::get_if<mwperf::StationaryClassSelection>(&selection);
          if (selected == nullptr || selected->class_id != label("class-a") ||
              initializer.has_value()) {
            return mwperf::Result<
                mwperf::ReducedInitialLawCandidateV1>::failure(test_error(
                "test.c16.stationary_selector_mismatch",
                "alpha0 did not receive the configured stationary class"));
          }
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto law = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection, std::nullopt);
    INFO((law ? std::string{} : law.error().code));
    REQUIRE(law);
    CHECK(law.value().selection_support() == support);
    CHECK(alpha_calls == 1U);
  }

  SECTION("named fixed point") {
    auto fixture = make_fixed_point_id_fixture();
    const mwperf::SelectionSupportV1 support{
        {mwperf::SelectionKindV1::fixed_point_id}, {},
        {label("root-a"), label("root-b")}};
    std::size_t alpha_calls = 0U;
    auto framework = mint_framework(
        fixture, identity, support,
        {mwperf::SelectionKindV1::fixed_point_id, std::nullopt},
        [&, identity, support](
            const mwperf::SelectionSpec& selection,
            const std::optional<mwperf::InitialPhysicalLaw>& initializer) {
          ++alpha_calls;
          const auto* fixed =
              std::get_if<mwperf::FixedPointSelection>(&selection);
          const auto* selected =
              fixed == nullptr
                  ? nullptr
                  : std::get_if<mwperf::FixedPointIdSelection>(fixed);
          if (selected == nullptr ||
              selected->solution_id != label("root-a") ||
              initializer.has_value()) {
            return mwperf::Result<
                mwperf::ReducedInitialLawCandidateV1>::failure(test_error(
                "test.c16.fixed_point_selector_mismatch",
                "alpha0 did not receive the configured fixed-point ID"));
          }
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::success(
              stationary_candidate(identity, support));
        },
        accept_exact_schema(identity), accept_reduced_domain(identity),
        exact_physical_projection());
    REQUIRE(framework);
    auto law = mwperf::construct_reduced_initial_law(
        fixture.instance, framework.value(),
        fixture.instance.analysis_spec().context->selection, std::nullopt);
    INFO((law ? std::string{} : law.error().code));
    REQUIRE(law);
    CHECK(law.value().selection_support() == support);
    CHECK(alpha_calls == 1U);
  }
}

TEST_CASE("C16 F06 rejects correct marginals with the wrong joint coupling",
          "[c16][negative][property]") {
  auto fixture = make_fixture(true);
  REQUIRE(fixture.physical_initializer);
  const SeamIdentity identity;
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::transient_initial}, {}, {}};

  // The malicious candidate below has the same separate marginals as the
  // accepted fixture: N/H/controller ordinals have masses (1/4, 3/4), while
  // Z has masses (7/8, 1/8).  Its physical coordinates are cross-coupled,
  // however: H is inverted on 1/4 of the mass in each direction.
  const auto physical_zero = rational(1, 4);
  const auto physical_one = rational(3, 4);
  CHECK(physical_zero * rational(1, 2) + physical_one == rational(7, 8));
  CHECK(physical_zero * rational(1, 2) == rational(1, 8));
  CHECK(physical_one * rational(1, 3) == rational(1, 4));
  CHECK(physical_zero + physical_one * rational(2, 3) == rational(3, 4));

  std::size_t alpha_calls = 0U;
  std::size_t domain_calls = 0U;
  std::size_t projection_calls = 0U;
  auto framework = mint_framework(
      fixture, identity, support,
      {mwperf::SelectionKindV1::transient_initial, std::nullopt},
      [&, identity, support](
          const mwperf::SelectionSpec&,
          const std::optional<mwperf::InitialPhysicalLaw>&) {
        ++alpha_calls;
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            {identity.codec,
             identity.exact_state_schema,
             identity.reduced_state_schema,
             identity.selection,
             support,
             {{reduced_state_coordinates(identity, 0U, 1U, 0U, 0U),
               exact_mass(1, 2), 0U},
              {reduced_state_coordinates(identity, 0U, 1U, 0U, 1U),
               exact_mass(1, 2), 0U},
              {reduced_state_coordinates(identity, 1U, 1U, 1U, 0U),
               exact_mass(2, 3), 1U},
              {reduced_state_coordinates(identity, 1U, 0U, 1U, 0U),
               exact_mass(1, 3), 1U}}});
      },
      accept_exact_schema(identity),
      [&, validator = accept_reduced_domain(identity)](
          const mwperf::ReducedStateV1& state) {
        ++domain_calls;
        return validator(state);
      },
      [&, validator = exact_physical_projection()](
          const std::size_t ordinal,
          const mwperf::InitialPhysicalAtom& physical,
          const mwperf::ReducedStateV1& state) {
        ++projection_calls;
        return validator(ordinal, physical, state);
      });
  REQUIRE(framework);
  auto law = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection,
      fixture.physical_initializer);
  REQUIRE_FALSE(law);
  CHECK(law.error().code == "test.c16.physical_projection_not_joint");
  CHECK(alpha_calls == 1U);
  CHECK(domain_calls == 1U);
  CHECK(projection_calls == 1U);
}

TEST_CASE("C16 F06 rejects foreign inputs before invoking sealed callbacks",
          "[c16][negative]") {
  auto fixture = make_fixture(true);
  auto foreign_initializer = make_fixture(true);
  std::string foreign_model(kModel);
  static constexpr std::string_view original_seed = R"json("seed":23)json";
  static constexpr std::string_view foreign_seed = R"json("seed":29)json";
  const auto seed_position = foreign_model.find(original_seed);
  REQUIRE(seed_position != std::string::npos);
  foreign_model.replace(seed_position, original_seed.size(), foreign_seed);
  auto foreign_instance = make_fixture_from_inputs(
      foreign_model, kTransientAnalysis, true);
  auto stationary = make_fixture(false);
  REQUIRE(fixture.physical_initializer);
  REQUIRE(foreign_initializer.physical_initializer);
  REQUIRE(foreign_instance.physical_initializer);
  REQUIRE(stationary.instance.analysis_spec().context);
  REQUIRE(foreign_instance.instance.analysis_spec().context);
  CHECK(foreign_initializer.instance.fingerprints() ==
        fixture.instance.fingerprints());
  CHECK(foreign_initializer.physical_initializer->arrival_binding() ==
        fixture.physical_initializer->arrival_binding());
  CHECK_FALSE(foreign_initializer.physical_initializer->shares_origin_with(
      *fixture.physical_initializer));
  CHECK(foreign_instance.instance.fingerprints() !=
        fixture.instance.fingerprints());
  CHECK(foreign_instance.instance.timing() == fixture.instance.timing());
  REQUIRE(foreign_instance.physical_initializer->atoms().size() ==
          fixture.physical_initializer->atoms().size());
  CHECK(foreign_instance.view.queues().size() == fixture.view.queues().size());
  const SeamIdentity identity;
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::transient_initial}, {}, {}};
  std::size_t alpha_calls = 0U;
  std::size_t schema_calls = 0U;
  auto mapper = [&, identity, support](
                    const mwperf::SelectionSpec&,
                    const std::optional<mwperf::InitialPhysicalLaw>&) {
    ++alpha_calls;
    return mwperf::Result<
        mwperf::ReducedInitialLawCandidateV1>::success(
        transient_candidate(identity, support));
  };
  auto schema = [&](const mwperf::ResolvedInstance&,
                    const mwperf::Digest256&) {
    ++schema_calls;
    return mwperf::Result<void>::success();
  };
  auto framework = mint_framework(
      fixture, identity, support,
      {mwperf::SelectionKindV1::transient_initial, std::nullopt}, mapper,
      schema, accept_reduced_domain(identity), exact_physical_projection());
  REQUIRE(framework);

  auto wrong_instance = mwperf::construct_reduced_initial_law(
      foreign_instance.instance, framework.value(),
      foreign_instance.instance.analysis_spec().context->selection,
      foreign_instance.physical_initializer);
  REQUIRE_FALSE(wrong_instance);
  CHECK(wrong_instance.error().code == "c16.audited_instance_input_mismatch");
  CHECK(alpha_calls == 0U);
  CHECK(schema_calls == 0U);

  auto wrong_selection = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      stationary.instance.analysis_spec().context->selection, std::nullopt);
  REQUIRE_FALSE(wrong_selection);
  CHECK(wrong_selection.error().code == "c16.selection_binding_mismatch");
  CHECK(alpha_calls == 0U);
  CHECK(schema_calls == 0U);

  auto wrong_initializer = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection,
      foreign_initializer.physical_initializer);
  REQUIRE_FALSE(wrong_initializer);
  CHECK(wrong_initializer.error().code == "c16.initializer_origin_mismatch");
  CHECK(alpha_calls == 0U);
  CHECK(schema_calls == 0U);

  auto sealed = std::move(framework.value());
  auto moved_from_seal = mwperf::construct_reduced_initial_law(
      fixture.instance, framework.value(),
      fixture.instance.analysis_spec().context->selection,
      fixture.physical_initializer);
  REQUIRE_FALSE(moved_from_seal);
  CHECK(moved_from_seal.error().code == "c16.invalid_audited_framework_seal");
  CHECK(alpha_calls == 0U);
  CHECK(schema_calls == 0U);

  auto valid = mwperf::construct_reduced_initial_law(
      fixture.instance, sealed,
      fixture.instance.analysis_spec().context->selection,
      fixture.physical_initializer);
  INFO((valid ? std::string{} : valid.error().code));
  REQUIRE(valid);
  CHECK(alpha_calls == 1U);
  CHECK(schema_calls == 1U);
}
