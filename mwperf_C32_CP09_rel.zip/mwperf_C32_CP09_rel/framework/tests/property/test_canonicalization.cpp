#include <catch2/catch_test_macros.hpp>

#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"

namespace mwperf {
namespace {

[[nodiscard]] std::filesystem::path canonical_test_directory() {
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c03-canonical-property";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  return directory;
}

[[nodiscard]] std::filesystem::path write_canonical_fixture(
    const std::string_view name, const std::string_view content) {
  const std::filesystem::path path = canonical_test_directory() / name;
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(content.data(), static_cast<std::streamsize>(content.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] AuthoredModelConfig parse_model_fixture(
    const std::string_view name, const std::string_view content) {
  Result<ParsedDocument> document =
      load_document(write_canonical_fixture(name, content));
  REQUIRE(document.has_value());
  Result<ModelNode> node = extract_executable_model(document.value());
  REQUIRE(node.has_value());
  Result<AuthoredModelConfig> parsed = parse_model_config_v3(node.value());
  REQUIRE(parsed.has_value());
  return std::move(parsed).value();
}

[[nodiscard]] AnalysisSpec parse_analysis_fixture(
    const std::string_view name, const std::string_view content) {
  Result<ParsedDocument> document =
      load_document(write_canonical_fixture(name, content));
  REQUIRE(document.has_value());
  Result<AnalysisSpec> parsed = parse_analysis_spec_v1(document.value());
  REQUIRE(parsed.has_value());
  return std::move(parsed).value();
}

constexpr std::string_view kCanonicalPropertyModel = R"json({
  "metadata":{"z":1.0,"a":1e-3,"large":1e20,"negative":-2.500e-2,
    "é":"utf8","escape":"line\nquote\""},
  "arrival":{"metadata":{},"events":[
    {"count":1,"queue_id":1,"slot":0},
    {"count":2,"queue_id":"1","slot":0}
  ],"family":"deterministic_trace"},
  "scheduler":{"params":{"priority":[1,"1"],"max_search_states":null,
    "constraint":{"conflicts":[[1,"1"]]}},"name":"conflict_graph_max_weight"},
  "switch":{"queues":[1,{"id":"1"}],"queue_capacity":null,"kind":"generalized"},
  "schema_version":"3.0.0",
  "run":{"termination":"fixed_slots","warmup_slots":0,"slots":10,"seed":1},
  "telemetry":{"write_slot_trace":false,"queue_snapshot":"disabled",
    "include_scheduler_state":false,"include_packet_events":false,"format":"jsonl"}
})json";

constexpr std::string_view kCanonicalPropertyAnalysis = R"json({
  "solver":{"parameters":{"max_iterations":null,"linear_method":"dense_pivoted"},"kind":"enumerated"},
  "selection":{"parameters":{},"kind":"stationary_unique"},
  "surrogate":{"parameters":{"numeric":10e-1,"nested":{"b":2,"a":1}},"version":null,"id":"fixture"},
  "metrics":[
    {"parameters":{"points":[125e-2,1e-3]},"kind":"stationary_backlog_pgf","id":"pgf"},
    {"parameters":{"lags":[1,2]},"kind":"service_autocovariance","id":"acf"}
  ],
  "targets":[1,"1"],
  "resolution":{
    "tolerance":{"tail_abs":null,"linear_residual_abs":1e-12,"integration_abs":null,"fixed_point_abs":null},
    "sampling":{"max_generator_draws":null},
    "optimizer":{"max_search_states_per_call":null,"max_calls":100},
    "phase":{"max_phase_states":10},
    "tail":{"parameters":{},"kind":"none"},
    "level":{"max_states":1000,"max_row_atoms":100}
  },
  "analysis_schema_version":"1.0.0"
})json";

TEST_CASE("C03 input fingerprints match independent version-1 vectors",
          "[c03][property][fingerprint]") {
  const CanonicalInputPair inputs{
      .model = R"({"a":1})",
      .analysis = R"({"b":2})",
  };

  const InputFingerprintBundle fingerprints = fingerprint_inputs(inputs);
  CHECK(fingerprints.model.hex() ==
        "44144ce2c79e69564b09da736e15eb03adcd37640fe8ce39301867b1cacec544");
  CHECK(fingerprints.analysis.hex() ==
        "953b582bddd295ebd4284031af56107cb1ab0ee90270ffd45d8784a0a38f8f24");
  CHECK(fingerprints.combined.hex() ==
        "204bfb85dc5a590d6b09f8a4cdfe885a211054e2d1a47cfd4cd4a0e1a3f29aae");
}

TEST_CASE("C03 fingerprint domains and components are isolated",
          "[c03][property][fingerprint]") {
  const CanonicalInputPair baseline{.model = "{}", .analysis = "{}"};
  const InputFingerprintBundle first = fingerprint_inputs(baseline);
  const InputFingerprintBundle replay = fingerprint_inputs(baseline);
  REQUIRE(first == replay);

  CHECK(first.model.hex() ==
        "02f274719e786f9ec9b153f6cc71b3c9095cd5c599f0cdeb2e16e89f4bb993e1");
  CHECK(first.analysis.hex() ==
        "b64adeee6c13eafa1e56cc2948a0ecfbaa224ba257e988e8abaa9a54e726be71");
  CHECK(first.combined.hex() ==
        "b3576f5724cbd80a1cefc2bbe4c1734c46e09b6bca3554acc5688dae727f8bf1");
  CHECK(first.model != first.analysis);
  CHECK(first.combined != first.model);
  CHECK(first.combined != first.analysis);

  CanonicalInputPair model_changed = baseline;
  model_changed.model = R"({"x":0})";
  const InputFingerprintBundle after_model = fingerprint_inputs(model_changed);
  CHECK(after_model.model != first.model);
  CHECK(after_model.analysis == first.analysis);
  CHECK(after_model.combined != first.combined);

  CanonicalInputPair analysis_changed = baseline;
  analysis_changed.analysis = R"({"x":0})";
  const InputFingerprintBundle after_analysis =
      fingerprint_inputs(analysis_changed);
  CHECK(after_analysis.model == first.model);
  CHECK(after_analysis.analysis != first.analysis);
  CHECK(after_analysis.combined != first.combined);
}

TEST_CASE("C03 fingerprint length framing prevents concatenation ambiguity",
          "[c03][property][fingerprint]") {
  const InputFingerprintBundle short_then_long =
      fingerprint_inputs(CanonicalInputPair{.model = "a", .analysis = "bc"});
  const InputFingerprintBundle long_then_short =
      fingerprint_inputs(CanonicalInputPair{.model = "ab", .analysis = "c"});

  CHECK(short_then_long.model != long_then_short.model);
  CHECK(short_then_long.analysis != long_then_short.analysis);
  CHECK(short_then_long.combined != long_then_short.combined);
}

TEST_CASE("C03 canonical JSON is reparsable and byte-idempotent",
          "[c03][property][canonical]") {
  const AuthoredModelConfig model = parse_model_fixture(
      "canonical-source-model.json", kCanonicalPropertyModel);
  const AnalysisSpec analysis = parse_analysis_fixture(
      "canonical-source-analysis.json", kCanonicalPropertyAnalysis);
  const CanonicalInputPair first =
      canonicalize_authored_inputs(model, analysis);

  // Exact decimal spellings are algebraically normalized, object keys use
  // unsigned UTF-8 ordering, typed labels preserve their JSON alternatives,
  // and no insignificant whitespace remains.
  CHECK(first.model.find(R"("a":0.001)") != std::string::npos);
  CHECK(first.model.find(R"("z":1)") != std::string::npos);
  CHECK(first.model.find(R"("large":100000000000000000000)") !=
        std::string::npos);
  CHECK(first.model.find(R"("negative":-0.025)") != std::string::npos);
  CHECK(first.model.find(R"("escape":"line\nquote\"")") !=
        std::string::npos);
  CHECK(first.model.find(R"("queues":[{"id":1},{"id":"1"}])") !=
        std::string::npos);
  CHECK(first.analysis.find(R"("points":[1.25,0.001])") !=
        std::string::npos);
  CHECK(first.analysis.find(R"("numeric":1)") != std::string::npos);
  CHECK(first.model.find('\n') == std::string::npos);
  CHECK(first.analysis.find('\n') == std::string::npos);

  const std::size_t key_a = first.model.find(R"("a":0.001)");
  const std::size_t key_z = first.model.find(R"("z":1)");
  const std::size_t key_utf8 = first.model.find(R"("é":"utf8")");
  REQUIRE(key_a != std::string::npos);
  REQUIRE(key_z != std::string::npos);
  REQUIRE(key_utf8 != std::string::npos);
  CHECK(key_a < key_z);
  CHECK(key_z < key_utf8);

  const AuthoredModelConfig reparsed_model =
      parse_model_fixture("canonical-reparse-model.json", first.model);
  const AnalysisSpec reparsed_analysis =
      parse_analysis_fixture("canonical-reparse-analysis.json", first.analysis);
  const CanonicalInputPair second =
      canonicalize_authored_inputs(reparsed_model, reparsed_analysis);
  CHECK(second == first);
  CHECK(fingerprint_inputs(second) == fingerprint_inputs(first));
}

TEST_CASE("C03 object member order does not affect canonical identity",
          "[c03][property][canonical]") {
  constexpr std::string_view first_model = R"json({
    "metadata":{"z":2,"a":1},
    "switch":{"kind":"generalized","queues":["q"]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "priority":null,"max_search_states":null,
      "constraint":{"conflicts":[]}}},
    "arrival":{"family":"deterministic_trace","events":[]}
  })json";
  constexpr std::string_view reordered_model = R"json({
    "arrival":{"events":[],"family":"deterministic_trace"},
    "scheduler":{"params":{
      "constraint":{"conflicts":[]},"max_search_states":null,
      "priority":null},"name":"conflict_graph_max_weight"},
    "switch":{"queues":["q"],"kind":"generalized"},
    "metadata":{"a":1,"z":2}
  })json";

  const AnalysisSpec analysis = parse_analysis_fixture(
      "object-order-analysis.json", kCanonicalPropertyAnalysis);
  const CanonicalInputPair first = canonicalize_authored_inputs(
      parse_model_fixture("object-order-first.json", first_model), analysis);
  const CanonicalInputPair reordered = canonicalize_authored_inputs(
      parse_model_fixture("object-order-second.json", reordered_model),
      analysis);

  CHECK(reordered == first);
  CHECK(fingerprint_inputs(reordered) == fingerprint_inputs(first));
}

TEST_CASE("C03 replay seed form remains mutually exclusive when canonicalized",
          "[c03][property][canonical]") {
  std::string replay_model(kCanonicalPropertyModel);
  const std::string authored_seed = R"("seed":1)";
  const std::string replay_seed =
      R"("requested_seed":-1,"actual_seed":42)";
  const std::size_t seed_position = replay_model.find(authored_seed);
  REQUIRE(seed_position != std::string::npos);
  replay_model.replace(seed_position, authored_seed.size(), replay_seed);

  const AuthoredModelConfig model = parse_model_fixture(
      "canonical-replay-seed-model.json", replay_model);
  const AnalysisSpec analysis = parse_analysis_fixture(
      "canonical-replay-seed-analysis.json", kCanonicalPropertyAnalysis);
  const CanonicalInputPair first =
      canonicalize_authored_inputs(model, analysis);

  CHECK(first.model.find(R"("requested_seed":-1)") != std::string::npos);
  CHECK(first.model.find(R"("actual_seed":42)") != std::string::npos);
  CHECK(first.model.find(R"("seed":)") == std::string::npos);

  const AuthoredModelConfig reparsed = parse_model_fixture(
      "canonical-replay-seed-reparse.json", first.model);
  CHECK(canonicalize_authored_inputs(reparsed, analysis).model == first.model);
}

TEST_CASE("C03 compatibility scheduler defaults have one canonical form",
          "[c03][property][canonical]") {
  const AnalysisSpec analysis = parse_analysis_fixture(
      "compatibility-default-analysis.json", kCanonicalPropertyAnalysis);

  const auto check_default = [&analysis](const std::string_view fixture_name,
                                         const std::string_view scheduler,
                                         const std::string_view expected) {
    const std::string model =
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":4},"scheduler":{"name":")" +
        std::string(scheduler) +
        R"(","params":{}},"arrival":{"family":"deterministic_trace","events":[],"metadata":{}}})";
    const AuthoredModelConfig parsed =
        parse_model_fixture(fixture_name, model);
    const CanonicalInputPair first =
        canonicalize_authored_inputs(parsed, analysis);
    CHECK(first.model.find(expected) != std::string::npos);
    const AuthoredModelConfig reparsed = parse_model_fixture(
        std::string(fixture_name) + ".reparsed.json", first.model);
    CHECK(canonicalize_authored_inputs(reparsed, analysis).model == first.model);
  };

  check_default("random-maximal-defaults.json", "random_maximal",
                R"("params":{})");
  check_default("round-robin-defaults.json", "round_robin",
                R"("params":{"input_offset":0,"output_offset":0})");
  check_default("islip-rga-defaults.json", "islip_rga",
                R"("params":{"k":1})");
  check_default("islip-canonical-defaults.json", "islip_canonical",
                R"("params":{"k":1})");

  const auto canonical_default = [&analysis](const std::string_view name,
                                              const std::string_view scheduler) {
    const std::string model =
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":4},)" +
        std::string(scheduler) +
        R"("arrival":{"family":"deterministic_trace","events":[],"metadata":{}}})";
    return canonicalize_authored_inputs(parse_model_fixture(name, model),
                                        analysis)
        .model;
  };
  const std::string section_omitted = canonical_default(
      "scheduler-section-omitted.json", "");
  const std::string name_omitted = canonical_default(
      "scheduler-name-omitted.json", R"("scheduler":{"params":{}},)");
  const std::string explicit_random = canonical_default(
      "scheduler-random-explicit.json",
      R"("scheduler":{"name":"random_maximal","params":{}},)");
  CHECK(name_omitted == section_omitted);
  CHECK(explicit_random == section_omitted);
  CHECK(section_omitted.find(
            R"("scheduler":{"name":"random_maximal","params":{}})") !=
        std::string::npos);
  const AuthoredModelConfig default_reparsed = parse_model_fixture(
      "scheduler-default-reparse.json", section_omitted);
  CHECK(canonicalize_authored_inputs(default_reparsed, analysis).model ==
        section_omitted);

  const AuthoredModelConfig pointer_model = parse_model_fixture(
      "islip-canonical-pointers.json",
      R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":4},"scheduler":{"name":"islip_canonical","params":{"k":3,"initial_grant_pointers":[0,1],"initial_accept_pointers":[1,0]}},"arrival":{"family":"deterministic_trace","events":[],"metadata":{}}})");
  const std::string canonical =
      canonicalize_authored_inputs(pointer_model, analysis).model;
  CHECK(canonical.find(
            R"("params":{"initial_accept_pointers":[1,0],"initial_grant_pointers":[0,1],"k":3})") !=
        std::string::npos);
  const AuthoredModelConfig reparsed = parse_model_fixture(
      "islip-canonical-pointers-reparse.json", canonical);
  CHECK(canonicalize_authored_inputs(reparsed, analysis).model == canonical);
}

TEST_CASE("C03 compatibility arrivals canonicalize typed defaults and tokens",
          "[c03][property][canonical]") {
  const AnalysisSpec analysis = parse_analysis_fixture(
      "compatibility-arrival-analysis.json", kCanonicalPropertyAnalysis);

  const auto canonical_model = [&analysis](const std::string_view name,
                                            const std::string_view arrival) {
    const std::string model =
        R"({"switch":{"kind":"legacy_crossbar","n_ports":2,"voq_capacity":4},"arrival":)" +
        std::string(arrival) + "}";
    return canonicalize_authored_inputs(parse_model_fixture(name, model),
                                        analysis)
        .model;
  };
  const auto require_round_trip = [&analysis](const std::string_view name,
                                               const std::string& canonical) {
    const AuthoredModelConfig reparsed = parse_model_fixture(name, canonical);
    CHECK(canonicalize_authored_inputs(reparsed, analysis).model == canonical);
  };

  SECTION("iid_table omitted common fields and normalized atom id") {
    const std::string omitted = canonical_model(
        "iid-compatibility-omitted.json",
        R"({"family":"iid_table","alphabet":[{"id":" Arrival-A ","edges":[[0,1]],"probability":1}]})");
    const std::string explicit_defaults = canonical_model(
        "iid-compatibility-explicit.json",
        R"({"family":"iid_table","allowed_edges":{"mode":"full","edges":[]},"alphabet_constraint":"unrestricted","alphabet":[{"id":"arrival_a","edges":[[0,1]],"probability":1.0}],"metadata":{}})");

    CHECK(omitted == explicit_defaults);
    CHECK(omitted.find(R"("allowed_edges":{"mode":"full"})") !=
          std::string::npos);
    CHECK(omitted.find(R"("alphabet_constraint":"unrestricted")") !=
          std::string::npos);
    CHECK(omitted.find(R"("id":"arrival_a")") != std::string::npos);
    require_round_trip("iid-compatibility-reparse.json", omitted);
  }

  SECTION("markov_kernel uses one normalized namespace spelling") {
    const std::string authored = canonical_model(
        "markov-compatibility-authored.json",
        R"({"family":"markov_kernel","states":[" State-A "],"alphabet":[{"id":" Mask-A ","edges":[]}],"kernel":[{"state":"state a","mask_id":"mask-a","next_state":"STATE_A","probability":1}],"initial":{"distribution":[{"state":"state-a","probability":1.00}]}})");
    const std::string normalized = canonical_model(
        "markov-compatibility-normalized.json",
        R"({"family":"markov_kernel","allowed_edges":{"mode":"full"},"alphabet_constraint":"unrestricted","states":["state_a"],"alphabet":[{"id":"mask_a","edges":[]}],"kernel":[{"state":"state_a","mask_id":"mask_a","next_state":"state_a","probability":1.0}],"initial":{"distribution":[{"state":"state_a","probability":1}]},"metadata":{}})");

    CHECK(authored == normalized);
    CHECK(authored.find(R"("states":["state_a"])" ) !=
          std::string::npos);
    CHECK(authored.find(R"("mask_id":"mask_a")") != std::string::npos);
    require_round_trip("markov-compatibility-reparse.json", authored);
  }

  SECTION("factorized_bernoulli materializes empty overrides") {
    const std::string omitted = canonical_model(
        "bernoulli-compatibility-omitted.json",
        R"({"family":"factorized_bernoulli","lambda":{"default":5e-1}})");
    const std::string explicit_defaults = canonical_model(
        "bernoulli-compatibility-explicit.json",
        R"({"family":"factorized_bernoulli","allowed_edges":{"mode":"full","edges":[]},"alphabet_constraint":"unrestricted","lambda":{"default":0.500,"overrides":{}},"metadata":{}})");

    CHECK(omitted == explicit_defaults);
    CHECK(omitted.find(R"("lambda":{"default":0.5,"overrides":{}})") !=
          std::string::npos);
    require_round_trip("bernoulli-compatibility-reparse.json", omitted);

    const std::string with_overrides = canonical_model(
        "bernoulli-compatibility-overrides.json",
        R"({"family":"factorized_bernoulli","allowed_edges":{"mode":"explicit","edges":[[1,0],[0,1]]},"alphabet_constraint":"unrestricted","lambda":{"default":0,"overrides":{"[1,0]":2.5e-1,"[0,1]":0.75}}})");
    CHECK(with_overrides.find(
              R"("allowed_edges":{"edges":[[1,0],[0,1]],"mode":"explicit"})") !=
          std::string::npos);
    CHECK(with_overrides.find(
              R"("overrides":{"[0,1]":0.75,"[1,0]":0.25})") !=
          std::string::npos);
    require_round_trip("bernoulli-compatibility-overrides-reparse.json",
                       with_overrides);
  }
}

TEST_CASE("C03 equivalent exact spellings have one canonical fingerprint",
          "[c03][property][canonical]") {
  const AuthoredModelConfig model = parse_model_fixture(
      "decimal-base-model.json", kCanonicalPropertyModel);
  const AnalysisSpec baseline_analysis = parse_analysis_fixture(
      "decimal-base-analysis.json", kCanonicalPropertyAnalysis);

  std::string equivalent(kCanonicalPropertyAnalysis);
  const std::vector<std::pair<std::string, std::string>> replacements{
      {"125e-2", "1.2500"},
      {"1e-3", "0.0010"},
      {"10e-1", "1.000"},
      {"1e-12", "0.0000000000010"},
  };
  for (const auto& [from, to] : replacements) {
    const std::size_t position = equivalent.find(from);
    REQUIRE(position != std::string::npos);
    equivalent.replace(position, from.size(), to);
  }
  const AnalysisSpec equivalent_analysis = parse_analysis_fixture(
      "decimal-equivalent-analysis.json", equivalent);

  const CanonicalInputPair baseline =
      canonicalize_authored_inputs(model, baseline_analysis);
  const CanonicalInputPair changed =
      canonicalize_authored_inputs(model, equivalent_analysis);
  CHECK(changed == baseline);
  CHECK(fingerprint_inputs(changed) == fingerprint_inputs(baseline));
}

TEST_CASE("C03 preserves every semantically significant array order",
          "[c03][property][canonical]") {
  const AuthoredModelConfig model = parse_model_fixture(
      "order-source-model.json", kCanonicalPropertyModel);
  const AnalysisSpec analysis = parse_analysis_fixture(
      "order-source-analysis.json", kCanonicalPropertyAnalysis);
  const CanonicalInputPair baseline =
      canonicalize_authored_inputs(model, analysis);

  std::string reordered_model(kCanonicalPropertyModel);
  const std::string old_events =
      R"({"count":1,"queue_id":1,"slot":0},
    {"count":2,"queue_id":"1","slot":0})";
  const std::string new_events =
      R"({"count":2,"queue_id":"1","slot":0},
    {"count":1,"queue_id":1,"slot":0})";
  const std::size_t event_position = reordered_model.find(old_events);
  REQUIRE(event_position != std::string::npos);
  reordered_model.replace(event_position, old_events.size(), new_events);
  const CanonicalInputPair changed = canonicalize_authored_inputs(
      parse_model_fixture("order-changed-model.json", reordered_model),
      analysis);

  CHECK(changed.model != baseline.model);
  CHECK(changed.analysis == baseline.analysis);
  CHECK(fingerprint_inputs(changed).model !=
        fingerprint_inputs(baseline).model);
}

}  // namespace
}  // namespace mwperf
