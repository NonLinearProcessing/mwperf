#include <algorithm>
#include <array>
#include <barrier>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/build_services.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace {

class DeterministicGenerator final {
 public:
  explicit DeterministicGenerator(const std::uint64_t seed) noexcept
      : state_(seed) {}

  [[nodiscard]] std::uint64_t next() noexcept {
    state_ = state_ * 6364136223846793005ULL + 1442695040888963407ULL;
    return state_;
  }

  [[nodiscard]] std::size_t below(const std::size_t limit) noexcept {
    return static_cast<std::size_t>(next() % limit);
  }

  template <typename T>
  void shuffle(std::vector<T>& values) noexcept {
    for (std::size_t remaining = values.size(); remaining > 1U; --remaining) {
      const std::size_t selected = below(remaining);
      std::swap(values[remaining - 1U], values[selected]);
    }
  }

 private:
  std::uint64_t state_;
};

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::QueueId queue_id(const std::size_t ordinal) {
  auto label = mwperf::TypedLabel::text("q" + std::to_string(ordinal));
  REQUIRE(label);
  return mwperf::QueueId(std::move(label).value());
}

[[nodiscard]] mwperf::AuthoredQueue authored_queue(
    const std::size_t ordinal) {
  const std::string base = "/switch/queues/" + std::to_string(ordinal);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{queue_id(ordinal),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<
          std::optional<mwperf::LegacyVoqCoordinate>>{
          std::nullopt, provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::QueueCatalog make_catalog(
    const std::size_t queue_count) {
  std::vector<mwperf::AuthoredQueue> queues;
  queues.reserve(queue_count);
  for (std::size_t ordinal = 0U; ordinal < queue_count; ++ordinal) {
    queues.push_back(authored_queue(ordinal));
  }
  mwperf::AuthoredSwitchConfig authored = mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          std::move(queues), provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<mwperf::BigNat>>{
          std::nullopt, provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
  auto catalog = mwperf::build_queue_catalog(authored);
  REQUIRE(catalog);
  return std::move(catalog).value();
}

[[nodiscard]] mwperf::Digest256 fixed_digest() {
  auto digest = mwperf::Digest256::from_hex(
      "9f1dd927bf5d6416210f6ac66a84f9a493a4c9fc43d60b64671c165ed0762e93");
  REQUIRE(digest);
  return std::move(digest).value();
}

[[nodiscard]] mwperf::DeterministicRng derived_arrival_rng(
    const mwperf::StageTag stage, const std::uint64_t path_id) {
  auto instance = mwperf::make_physical_reference_instance_key(
      fixed_digest(), mwperf::BigNat(path_id));
  REQUIRE(instance);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(0x7e57c09b51a9d20fULL), stage, instance.value());
}

[[nodiscard]] mwperf::Result<mwperf::ArrivalStreamKey> arrival_stream_key(
    const mwperf::CompiledArrivalLaw& law, const std::uint64_t path_id) {
  auto stream = derived_arrival_rng(mwperf::StageTag::configured_arrival,
                                    path_id);
  return mwperf::make_configured_arrival_stream_key(law, std::move(stream));
}

[[nodiscard]] mwperf::Result<mwperf::BuilderArrivalStreamKey>
builder_arrival_stream_key(const mwperf::CompiledArrivalLaw& law,
                           const mwperf::StageTag stage,
                           const std::uint64_t path_id) {
  auto stream = derived_arrival_rng(stage, path_id);
  return mwperf::make_builder_arrival_stream_key(law, stage,
                                                  std::move(stream));
}

[[nodiscard]] mwperf::AuthoredProbability authored_probability(
    const std::int64_t numerator, const std::int64_t denominator) {
  auto exact = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                           mwperf::BigInt(denominator));
  REQUIRE(exact);
  auto probability =
      mwperf::AuthoredProbability::from_exact(std::move(exact).value());
  REQUIRE(probability);
  return std::move(probability).value();
}

[[nodiscard]] mwperf::AuthoredArrivalConfig marked_renewal_row(
    const std::int64_t second_numerator,
    const std::int64_t second_denominator) {
  const std::string base = "/arrival/sources/0";
  std::vector<mwperf::JointRenewalMass> masses;
  masses.push_back(mwperf::JointRenewalMass{
      mwperf::AuthoredField<mwperf::BigNat>{mwperf::BigNat(1U),
                                            provenance(base + "/joint_pmf/0/d")},
      mwperf::AuthoredField<mwperf::QueueId>{
          queue_id(0U), provenance(base + "/joint_pmf/0/queue_id")},
      mwperf::AuthoredField<mwperf::AuthoredProbability>{
          authored_probability(1, 2),
          provenance(base + "/joint_pmf/0/probability")},
      provenance(base + "/joint_pmf/0")});
  masses.push_back(mwperf::JointRenewalMass{
      mwperf::AuthoredField<mwperf::BigNat>{mwperf::BigNat(2U),
                                            provenance(base + "/joint_pmf/1/d")},
      mwperf::AuthoredField<mwperf::QueueId>{
          queue_id(1U), provenance(base + "/joint_pmf/1/queue_id")},
      mwperf::AuthoredField<mwperf::AuthoredProbability>{
          authored_probability(second_numerator, second_denominator),
          provenance(base + "/joint_pmf/1/probability")},
      provenance(base + "/joint_pmf/1")});

  mwperf::JointRenewalSource source{
      mwperf::NormalizedToken{"source", "source", provenance(base + "/id")},
      mwperf::AuthoredField<std::vector<mwperf::JointRenewalMass>>{
          std::move(masses), provenance(base + "/joint_pmf")},
      provenance(base)};
  std::vector<mwperf::MarkedRenewalSource> sources;
  sources.emplace_back(std::move(source));
  mwperf::IndependentMarkedRenewalArrival arrival{
      mwperf::AuthoredField<std::vector<mwperf::MarkedRenewalSource>>{
          std::move(sources), provenance("/arrival/sources")},
      mwperf::AuthoredMetadata{std::nullopt, provenance("/arrival/metadata")},
      provenance("/arrival")};
  return mwperf::AuthoredArrivalConfig{
      mwperf::AuthoredArrivalVariant(std::move(arrival)),
      provenance("/arrival")};
}

[[nodiscard]] mwperf::BigNat manual_projection(
    const mwperf::ArrivalBatch& batch, const std::size_t ordinal) {
  for (const auto& entry : batch.entries()) {
    if (entry.queue.ordinal() == ordinal) {
      return entry.count;
    }
  }
  return mwperf::BigNat(0U);
}

void check_same_realized_step(const mwperf::ArrivalStep& first,
                              const mwperf::ArrivalStep& second) {
  CHECK(first.authored_slot == second.authored_slot);
  CHECK(first.physical_arrival_epoch() == second.physical_arrival_epoch());
  CHECK(first.batch == second.batch);
  CHECK(first.law_digest == second.law_digest);
  CHECK(first.realization_identity == second.realization_identity);
  CHECK(mwperf::arrival_phase_family(first.phase_before) ==
        mwperf::arrival_phase_family(second.phase_before));
  CHECK(mwperf::arrival_phase_family(first.phase_after) ==
        mwperf::arrival_phase_family(second.phase_after));
  CHECK(mwperf::arrival_phase_digest(first.phase_before) ==
        mwperf::arrival_phase_digest(second.phase_before));
  CHECK(mwperf::arrival_phase_digest(first.phase_after) ==
        mwperf::arrival_phase_digest(second.phase_after));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(first.phase_before),
      mwperf::arrival_phase_canonical_state(second.phase_before)));
  CHECK(std::ranges::equal(
      mwperf::arrival_phase_canonical_state(first.phase_after),
      mwperf::arrival_phase_canonical_state(second.phase_after)));
}

void check_same_replay(const mwperf::AdjacentReplayResult& first,
                       const mwperf::AdjacentReplayResult& second) {
  CHECK(first.view_digest == second.view_digest);
  CHECK(first.replay_identity == second.replay_identity);
  CHECK(first.status == second.status);
  CHECK(first.accounting.transitions == second.accounting.transitions);
  CHECK(first.accounting.rng_words == second.accounting.rng_words);
  REQUIRE(first.steps.size() == second.steps.size());
  for (std::size_t index = 0U; index < first.steps.size(); ++index) {
    check_same_realized_step(first.steps[index], second.steps[index]);
  }
}

}  // namespace

TEST_CASE("C09 checked aggregation is permutation invariant and associative",
          "[c09][property][arrival][aggregation]") {
  constexpr std::size_t kQueueCount = 5U;
  mwperf::QueueCatalog catalog = make_catalog(kQueueCount);
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const mwperf::ArrivalBinding binding =
      mwperf::arrival_law_binding(law.value());

  DeterministicGenerator generator(0xc09a6615b7c3d229ULL);
  for (std::size_t trial = 0U; trial < 200U; ++trial) {
    const std::size_t atom_count = 1U + generator.below(48U);
    std::vector<mwperf::ArrivalAtom> atoms;
    atoms.reserve(atom_count);
    for (std::size_t atom = 0U; atom < atom_count; ++atom) {
      auto queue = catalog.index_at(generator.below(kQueueCount));
      REQUIRE(queue);
      auto contribution = mwperf::ArrivalAtom::make(
          queue.value(), mwperf::BigNat(1U + generator.below(1000000U)),
          binding);
      REQUIRE(contribution);
      atoms.push_back(std::move(contribution).value());
    }

    auto direct = mwperf::aggregate_arrival_batch(atoms);
    REQUIRE(direct);

    std::vector<mwperf::ArrivalAtom> shuffled = atoms;
    generator.shuffle(shuffled);
    auto permuted = mwperf::aggregate_arrival_batch(shuffled);
    REQUIRE(permuted);
    CHECK(permuted.value() == direct.value());

    std::size_t first_cut = generator.below(atom_count + 1U);
    std::size_t second_cut = generator.below(atom_count + 1U);
    if (second_cut < first_cut) {
      std::swap(first_cut, second_cut);
    }
    const std::array<std::pair<std::size_t, std::size_t>, 3U> ranges{{
        {0U, first_cut},
        {first_cut, second_cut},
        {second_cut, atom_count},
    }};
    std::vector<mwperf::ArrivalAtom> partial_atoms;
    for (const auto& [begin, end] : ranges) {
      const std::span<const mwperf::ArrivalAtom> part(atoms.data() + begin,
                                                       end - begin);
      auto partial = mwperf::aggregate_arrival_batch(part);
      REQUIRE(partial);
      for (const auto& entry : partial.value().entries()) {
        auto contribution = mwperf::ArrivalAtom::make(
            entry.queue, entry.count, binding);
        REQUIRE(contribution);
        partial_atoms.push_back(std::move(contribution).value());
      }
    }
    auto associated = mwperf::aggregate_arrival_batch(partial_atoms);
    REQUIRE(associated);
    CHECK(associated.value() == direct.value());

    std::vector<mwperf::BigNat> dense;
    dense.reserve(kQueueCount);
    for (std::size_t queue = 0U; queue < kQueueCount; ++queue) {
      dense.emplace_back(0U);
    }
    for (const auto& entry : direct.value().entries()) {
      dense[entry.queue.ordinal()] = entry.count;
    }
    std::vector<mwperf::ArrivalAtom> round_trip_atoms;
    for (std::size_t queue = 0U; queue < kQueueCount; ++queue) {
      if (dense[queue].is_zero()) {
        continue;
      }
      auto index = catalog.index_at(queue);
      REQUIRE(index);
      auto atom =
          mwperf::ArrivalAtom::make(index.value(), dense[queue], binding);
      REQUIRE(atom);
      round_trip_atoms.push_back(std::move(atom).value());
    }
    auto round_trip = mwperf::aggregate_arrival_batch(round_trip_atoms);
    REQUIRE(round_trip);
    CHECK(round_trip.value() == direct.value());
  }
}

TEST_CASE("C09 equal stream keys replay independently under interleaving",
          "[c09][property][arrival][cursor]") {
  constexpr std::size_t kQueueCount = 4U;
  mwperf::QueueCatalog catalog = make_catalog(kQueueCount);
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);

  const mwperf::QueueMask support =
      mwperf::positive_arrival_support(law.value());
  REQUIRE(support.size() == kQueueCount);
  auto queue0 = catalog.index_at(0U);
  auto queue1 = catalog.index_at(1U);
  auto queue2 = catalog.index_at(2U);
  auto queue3 = catalog.index_at(3U);
  REQUIRE(queue0);
  REQUIRE(queue1);
  REQUIRE(queue2);
  REQUIRE(queue3);
  CHECK(support.at(queue0.value()));
  CHECK(support.at(queue1.value()));
  CHECK_FALSE(support.at(queue2.value()));
  CHECK_FALSE(support.at(queue3.value()));

  auto first_key = arrival_stream_key(law.value(), 17U);
  auto replay_key = arrival_stream_key(law.value(), 17U);
  auto unrelated_key = arrival_stream_key(law.value(), 18U);
  REQUIRE(first_key);
  REQUIRE(replay_key);
  REQUIRE(unrelated_key);
  CHECK(first_key.value().stream_identity() ==
        replay_key.value().stream_identity());
  CHECK_FALSE(first_key.value().stream_identity() ==
              unrelated_key.value().stream_identity());

  const mwperf::ArrivalInitialState initial = mwperf::SharedRoundState{"h0"};
  const mwperf::ArrivalInitialState unrelated_initial =
      mwperf::SharedRoundState{"h1"};
  auto first = mwperf::instantiate_arrival_process(
      law.value(), initial, std::move(first_key).value());
  auto replay = mwperf::instantiate_arrival_process(
      law.value(), initial, std::move(replay_key).value());
  auto unrelated = mwperf::instantiate_arrival_process(
      law.value(), unrelated_initial, std::move(unrelated_key).value());
  REQUIRE(first);
  REQUIRE(replay);
  REQUIRE(unrelated);

  std::optional<mwperf::ArrivalPhase> previous_first_phase;
  std::optional<mwperf::ArrivalPhase> previous_replay_phase;
  for (std::uint64_t slot = 0U; slot < 96U; ++slot) {
    const mwperf::BigNat authored_slot(slot);
    auto first_step =
        mwperf::next_arrival_step(first.value(), authored_slot);
    REQUIRE(first_step);

    auto noise_step =
        mwperf::next_arrival_step(unrelated.value(), authored_slot);
    REQUIRE(noise_step);

    auto replay_step =
        mwperf::next_arrival_step(replay.value(), authored_slot);
    REQUIRE(replay_step);
    check_same_realized_step(first_step.value(), replay_step.value());

    CHECK(mwperf::arrival_phases_share_cursor(first_step.value().phase_before,
                                               first_step.value().phase_after));
    CHECK(mwperf::arrival_phases_share_cursor(replay_step.value().phase_before,
                                               replay_step.value().phase_after));
    CHECK_FALSE(mwperf::arrival_phases_share_cursor(
        first_step.value().phase_before, replay_step.value().phase_before));
    if (previous_first_phase.has_value()) {
      CHECK(mwperf::arrival_phases_share_cursor(
          *previous_first_phase, first_step.value().phase_before));
      CHECK(mwperf::arrival_phases_share_cursor(
          *previous_replay_phase, replay_step.value().phase_before));
    }
    previous_first_phase = first_step.value().phase_after;
    previous_replay_phase = replay_step.value().phase_after;

    for (std::size_t queue = 0U; queue < kQueueCount; ++queue) {
      auto index = catalog.index_at(queue);
      REQUIRE(index);
      auto projected = mwperf::project_arrival_count(
          first_step.value().batch, index.value(),
          mwperf::arrival_law_binding(law.value()));
      REQUIRE(projected);
      CHECK(projected.value() ==
            manual_projection(first_step.value().batch, queue));
    }

    const mwperf::BigNat first_count = manual_projection(
        first_step.value().batch, queue0.value().ordinal());
    const mwperf::BigNat second_count = manual_projection(
        first_step.value().batch, queue1.value().ordinal());
    const bool first_joint_outcome =
        first_count == mwperf::BigNat(1U) &&
        second_count == mwperf::BigNat(4U);
    const bool second_joint_outcome =
        first_count == mwperf::BigNat(3U) &&
        second_count == mwperf::BigNat(2U);
    CHECK((first_joint_outcome || second_joint_outcome));

    for (const auto& entry : first_step.value().batch.entries()) {
      CHECK(support.at(entry.queue));
      CHECK(entry.count > mwperf::BigNat(0U));
    }
  }
}

TEST_CASE("C09 arrival PMF tolerance is enforced before the pending backend",
          "[c09][property][arrival][pmf][negative]") {
  constexpr std::int64_t kDenominator = 1000000000000000000LL;
  constexpr std::int64_t kHalfNumerator = 500000000000000000LL;
  constexpr std::int64_t kJustInsideTolerance = 999999999LL;
  constexpr std::int64_t kJustOutsideTolerance = 1000000001LL;
  const mwperf::QueueCatalog catalog = make_catalog(2U);

  const auto inside = marked_renewal_row(
      kHalfNumerator + kJustInsideTolerance, kDenominator);
  auto inside_result = mwperf::detail::compile_arrival_law_with_registry(
      inside, catalog, mwperf::detail::c09_pending_arrival_registry());
  REQUIRE_FALSE(inside_result);
  CHECK(inside_result.error().category ==
        mwperf::DiagnosticCategory::unavailable);
  CHECK(inside_result.error().code ==
        "arrival_backend_pending_c11_independent_marked_renewal");

  const auto outside = marked_renewal_row(
      kHalfNumerator + kJustOutsideTolerance, kDenominator);
  auto outside_result = mwperf::compile_arrival_law(outside, catalog);
  REQUIRE_FALSE(outside_result);
  CHECK(outside_result.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(outside_result.error().code == "pmf_mass_outside_tolerance");
}

TEST_CASE("C09 builder replay is keyed by explicit initialization and stage",
          "[c09][property][arrival][replay]") {
  const mwperf::QueueCatalog catalog = make_catalog(3U);
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  const mwperf::BuilderArrivalView view =
      mwperf::builder_arrival_view(law.value());
  auto services = mwperf::make_builder_arrival_services(law.value(), view);
  REQUIRE(services);

  constexpr std::uint64_t kReplayPath = 0xc09017U;
  constexpr std::uint64_t kLength = 48U;
  auto first_key = builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_probe, kReplayPath);
  auto second_key = builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_probe, kReplayPath);
  auto changed_initial_key = builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_probe, kReplayPath);
  auto changed_stage_key = builder_arrival_stream_key(
      law.value(), mwperf::StageTag::surrogate_build_context, kReplayPath);
  REQUIRE(first_key);
  REQUIRE(second_key);
  REQUIRE(changed_initial_key);
  REQUIRE(changed_stage_key);
  CHECK(first_key.value().stream_identity() ==
        second_key.value().stream_identity());
  CHECK(first_key.value().stream_identity() ==
        changed_initial_key.value().stream_identity());
  CHECK_FALSE(first_key.value().stream_identity() ==
              changed_stage_key.value().stream_identity());

  auto first = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::ExplicitReplayInitialState{
          mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h0"}}},
      mwperf::BigNat(0U), mwperf::BigNat(kLength),
      std::move(first_key).value(), "property-replay"});
  auto second = services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
      view.digest(),
      mwperf::ExplicitReplayInitialState{
          mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h0"}}},
      mwperf::BigNat(0U), mwperf::BigNat(kLength),
      std::move(second_key).value(), "property-replay"});
  auto changed_initial =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayInitialState{
              mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h1"}}},
          mwperf::BigNat(0U), mwperf::BigNat(kLength),
          std::move(changed_initial_key).value(), "changed-initial"});
  auto changed_stage =
      services.value().replay_service()->replay(mwperf::AdjacentReplayRequest{
          view.digest(),
          mwperf::ExplicitReplayInitialState{
              mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h0"}}},
          mwperf::BigNat(0U), mwperf::BigNat(kLength),
          std::move(changed_stage_key).value(), "changed-stage"});
  REQUIRE(first);
  REQUIRE(second);
  REQUIRE(changed_initial);
  REQUIRE(changed_stage);
  check_same_replay(first.value(), second.value());
  REQUIRE(first.value().steps.size() == kLength);
  REQUIRE(changed_initial.value().steps.size() == kLength);
  REQUIRE(changed_stage.value().steps.size() == kLength);

  CHECK_FALSE(mwperf::arrival_phase_digest(
                  first.value().steps.front().phase_before) ==
              mwperf::arrival_phase_digest(
                  changed_initial.value().steps.front().phase_before));
  CHECK_FALSE(first.value().steps.front().realization_identity ==
              changed_stage.value().steps.front().realization_identity);
  CHECK(first.value().status ==
        mwperf::ReplayContextStatus::ordered_dependent_contexts);
  CHECK(changed_initial.value().status ==
        mwperf::ReplayContextStatus::ordered_dependent_contexts);
  CHECK(changed_stage.value().status ==
        mwperf::ReplayContextStatus::ordered_dependent_contexts);
}

TEST_CASE("C09 concurrent cursor mutation fails atomically",
          "[c09][property][arrival][cursor][concurrency][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog(2U);
  auto law = mwperf::testing::make_c09_correlated_fixture_law(catalog);
  REQUIRE(law);
  auto stream = arrival_stream_key(law.value(), 0xc09018U);
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law.value(),
      mwperf::ArrivalInitialState{mwperf::SharedRoundState{"h0"}},
      std::move(stream).value());
  REQUIRE(process);

  std::barrier start(3);
  std::optional<mwperf::Result<mwperf::ArrivalStep>> first;
  std::optional<mwperf::Result<mwperf::ArrivalStep>> second;
  std::thread first_thread([&] {
    start.arrive_and_wait();
    first.emplace(
        mwperf::next_arrival_step(process.value(), mwperf::BigNat(0U)));
  });
  std::thread second_thread([&] {
    start.arrive_and_wait();
    second.emplace(
        mwperf::next_arrival_step(process.value(), mwperf::BigNat(0U)));
  });
  start.arrive_and_wait();
  first_thread.join();
  second_thread.join();

  REQUIRE(first.has_value());
  REQUIRE(second.has_value());
  const std::size_t successes = static_cast<std::size_t>(first->has_value()) +
                                static_cast<std::size_t>(second->has_value());
  REQUIRE(successes == 1U);
  const auto& rejected = first->has_value() ? *second : *first;
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "nonsequential_arrival_access");

  auto after_race = mwperf::testing::snapshot_arrival_process(process.value());
  REQUIRE(after_race);
  CHECK(after_race.value().expected_slot == mwperf::BigNat(1U));
  CHECK(after_race.value().rng.consumed_words() == mwperf::BigNat(1U));
  auto next =
      mwperf::next_arrival_step(process.value(), mwperf::BigNat(1U));
  REQUIRE(next);
  auto after_next = mwperf::testing::snapshot_arrival_process(process.value());
  REQUIRE(after_next);
  CHECK(after_next.value().expected_slot == mwperf::BigNat(2U));
  CHECK(after_next.value().rng.consumed_words() == mwperf::BigNat(2U));
}
