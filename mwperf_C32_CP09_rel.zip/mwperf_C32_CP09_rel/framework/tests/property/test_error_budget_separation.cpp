#include <algorithm>
#include <array>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <random>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/diagnostics/error_budget.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

[[nodiscard]] mwperf::Digest256 digest(const std::string_view text) {
  auto value = mwperf::sha256(std::as_bytes(
      std::span<const char>(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::TypedLabel label(const std::string_view text) {
  auto value = mwperf::TypedLabel::text(std::string(text));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object(
    const std::string_view text) {
  return {label(text), digest(text)};
}

[[nodiscard]] mwperf::QueueId queue(const std::string_view text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::DiagnosticValueIntervalV1 finite_interval(
    const long double lower = 0.125L,
    const long double upper = 0.125L) {
  return {mwperf::CertificateClaimStateV1::established,
          mwperf::BoundValueStatusV1::finite, lower, upper};
}

[[nodiscard]] mwperf::DiagnosticValueIntervalV1 unknown_interval() {
  return {mwperf::CertificateClaimStateV1::not_established,
          mwperf::BoundValueStatusV1::unresolved, std::nullopt,
          std::nullopt};
}

struct IdentityFixture final {
  mwperf::ResponseIdentityContextV1 response_context;
  mwperf::MeanIdentityContextV1 mean_context;
  mwperf::RawResponseProductId raw_product;
  mwperf::NominalResponseProductId nominal_product;
  mwperf::ProjectionCenterProductId center_product;
  mwperf::ProjectedMeanProductId mean_product;
  mwperf::RecodedResponseProductId recoded_product;
  std::vector<mwperf::RawResponseCoefficientIdentityV1> raw_bins;
  std::vector<mwperf::NominalResponseCoefficientIdentityV1> nominal_bins;
  mwperf::ProjectionCenterIdentityV1 center;
  mwperf::ProjectedMeanIdentityV1 projected_mean;
  std::vector<mwperf::RecodedResponseCoefficientIdentityV1> recoded_bins;
  mwperf::DeployedLawProductIdentityV1 deployed_law;
  mwperf::MetricGeometry geometry;
  mwperf::PhysicalFidelityAnchor physical_anchor;
};

[[nodiscard]] IdentityFixture identities() {
  const mwperf::ProviderIdentityV1 provider{"c25.fixture.provider", "1.0.0"};
  const mwperf::ResponseIdentityContextV1 response{
      provider,
      object("c25.fixture.artifact"),
      object("c25.fixture.payload"),
      digest("c25.fixture.build"),
      digest("c25.fixture.request"),
      queue("q0"),
      digest("c25.fixture.phase"),
      label("c25.fixture.bank"),
      label("c25.fixture.final-probe")};
  const mwperf::MeanIdentityContextV1 mean{
      provider,
      response.artifact_identity,
      response.payload_identity,
      response.build_identity,
      response.request_identity,
      {queue("q0"), queue("q1")},
      response.phase_identity,
      response.frozen_input_bank_id,
      response.final_probe_id};

  const auto raw = Factory::raw_response_product_id(
      object("c25.fixture.raw-product"));
  const auto nominal = Factory::nominal_response_product_id(
      object("c25.fixture.nominal-product"));
  const auto center = Factory::projection_center_product_id(
      object("c25.fixture.projection-center"));
  const auto projected = Factory::projected_mean_product_id(
      object("c25.fixture.projected-mean"));
  const auto recoded = Factory::recoded_response_product_id(
      object("c25.fixture.recoded-product"));
  constexpr std::array bins{
      mwperf::ThreeBinCoefficientV1::one,
      mwperf::ThreeBinCoefficientV1::two,
      mwperf::ThreeBinCoefficientV1::tail_from_three};
  std::vector<mwperf::RawResponseCoefficientIdentityV1> raw_bins;
  std::vector<mwperf::NominalResponseCoefficientIdentityV1> nominal_bins;
  std::vector<mwperf::RecodedResponseCoefficientIdentityV1> recoded_bins;
  for (const auto bin : bins) {
    raw_bins.push_back({response, raw,
                        mwperf::ResponseProductValueFormV1::interval_only,
                        bin});
    nominal_bins.push_back({response, nominal, bin});
    recoded_bins.push_back({response, recoded, bin});
  }

  auto law = mwperf::LawIdentityV1::make(
      {response,
       mwperf::DeployedResponseProductReferenceV1(
           mwperf::RecodedResponseProductRef{recoded.identity()}),
       digest("c25.fixture.configured-arrival"),
       digest("c25.fixture.execution"), digest("c25.fixture.metric-target")});
  REQUIRE(law);

  auto carrier =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto v0_evidence = mwperf::Evidence::bind(carrier.framework, {});
  REQUIRE(v0_evidence);
  const auto physical_evidence_id =
      object("c25.fixture.physical-fidelity-evidence");
  const auto physical_premise_id =
      object("c25.fixture.physical-fidelity-premise");
  std::vector<mwperf::CertificateEvidenceNodeV1> physical_nodes{
      mwperf::CertificatePremiseEvidenceV1{
          .evidence_id = physical_premise_id,
          .supported_claim =
              mwperf::CertificateClaimKindV1::physical_fidelity,
          .subject_product_identity = recoded.identity().object_digest,
          .subject_law_identity = digest("c25.fixture.execution"),
          .premise_identity =
              digest("c25.fixture.physical-comparison-premise"),
          .provenance_identity =
              object("c25.fixture.physical-comparison-provenance"),
          .coverage =
              mwperf::CertificateCoverageV1::global_declared_domain,
          .origin =
              mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          .dependencies = {},
      },
      mwperf::PhysicalFidelityEvidenceV1{
          physical_evidence_id,
          mwperf::CodecIdentityV1{"mwperf.c25.physical-fidelity", 1U},
          v0_evidence.value()
              .framework_bindings()
              .problem_fingerprints.resolved_instance,
          recoded.identity().object_digest,
          digest("c25.fixture.execution"),
          digest("c25.fixture.physical-reference-law"),
          digest("c25.fixture.metric-target"),
          digest("c25.fixture.physical-regime"),
          digest("c25.fixture.physical-comparison-theorem"),
          mwperf::PhysicalFidelityKindV1::bounded,
          mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          false,
          0.125L,
          {physical_premise_id}}};
  auto physical_evidence =
      mwperf::Evidence::bind(carrier.framework, std::move(physical_nodes));
  REQUIRE(physical_evidence);
  auto certificates =
      mwperf::CertificateBundle::v0_only(physical_evidence.value());
  certificates.physical_fidelity = physical_evidence_id;
  auto validated = mwperf::validate_certificate_bundle(
      certificates, carrier.framework, physical_evidence.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto physical_anchor = validated.value().physical_fidelity_anchor();
  REQUIRE(physical_anchor);

  return {response,
          mean,
          raw,
          nominal,
          center,
          projected,
          recoded,
          std::move(raw_bins),
          std::move(nominal_bins),
          {mean, center},
          {mean, projected},
          std::move(recoded_bins),
          {std::move(law).value()},
          {{mwperf::TotalVariationGeometryV1{
              digest("c25.fixture.tv-geometry"),
              digest("c25.fixture.state-space"),
              digest("c25.fixture.observable"),
              mwperf::TvConventionV1::supremum_event_difference, 0.0L,
              1.0L}}},
          std::move(physical_anchor).value()};
}

static_assert(!std::default_initializable<mwperf::LawIdentityV1>);
static_assert(!std::default_initializable<mwperf::DiagnosticComponent>);
static_assert(!std::same_as<mwperf::RawResponseProductId,
                            mwperf::NominalResponseProductId>);
static_assert(!std::same_as<mwperf::ProjectionCenterProductId,
                            mwperf::ProjectedMeanProductId>);
static_assert(!std::constructible_from<mwperf::DeployedResponseProductIdV1,
                                       mwperf::ProjectionCenterProductId>);
static_assert(!std::constructible_from<mwperf::DeployedResponseProductIdV1,
                                       mwperf::ProjectedMeanProductId>);
static_assert(
    !std::constructible_from<mwperf::DeployedResponseProductReferenceV1,
                             mwperf::ProjectionCenterProductRef>);
static_assert(
    !std::constructible_from<mwperf::DeployedResponseProductReferenceV1,
                             mwperf::ProjectedMeanProductRef>);

[[nodiscard]] mwperf::DiagnosticComponent component(
    const IdentityFixture& fixture, const std::string_view name,
    const mwperf::ComponentScopeV1 scope,
    mwperf::ProductIdentityV1 source,
    mwperf::DiagnosticValueIntervalV1 value = finite_interval(),
    std::optional<mwperf::ProductIdentityV1> destination = std::nullopt,
    std::optional<mwperf::ProductBridgeV1> bridge = std::nullopt,
    std::optional<mwperf::TriangleContributionV1> triangle = std::nullopt,
    std::optional<mwperf::DiagnosticConfidenceV1> confidence = std::nullopt,
    std::optional<long double> tolerance = 0.0L,
    std::optional<mwperf::PhysicalFidelityAnchor> physical_anchor =
        std::nullopt) {
  const auto base = std::string(name);
  auto made = mwperf::DiagnosticComponent::make(
      {object(base + ".component"),
       scope,
       std::move(source),
       std::move(destination),
       "total-variation diagnostic",
       fixture.geometry,
       value,
       std::move(confidence),
       tolerance,
       "c25.fixture.theorem-or-method",
       {"exact product identity", "declared geometry"},
       {object(base + ".evidence")},
       object(base + ".provenance"),
       std::move(bridge),
       std::move(triangle),
       std::move(physical_anchor),
       std::nullopt});
  INFO((made ? std::string{}
             : made.error().code + ": " + made.error().message));
  REQUIRE(made);
  return std::move(made).value();
}

[[nodiscard]] std::vector<mwperf::DiagnosticComponent> all_scopes(
    const IdentityFixture& fixture) {
  return {
      component(fixture, "c25.fixture.construction",
                mwperf::ComponentScopeV1::construction_integration,
                fixture.raw_bins[0]),
      component(fixture, "c25.fixture.input-bank",
                mwperf::ComponentScopeV1::input_bank_initialization,
                fixture.raw_bins[1]),
      component(fixture, "c25.fixture.optimizer",
                mwperf::ComponentScopeV1::optimizer, fixture.raw_bins[2]),
      component(
          fixture, "c25.fixture.coefficient-sampling",
          mwperf::ComponentScopeV1::coefficient_sampling,
          fixture.raw_bins[0], finite_interval(), std::nullopt, std::nullopt,
          std::nullopt,
          mwperf::DiagnosticConfidenceV1{0.95L, "simultaneous band",
                                         "raw-proposal-family", true},
          std::nullopt),
      component(fixture, "c25.fixture.compression",
                mwperf::ComponentScopeV1::compression,
                fixture.nominal_bins[0]),
      component(fixture, "c25.fixture.projection",
                mwperf::ComponentScopeV1::projection, fixture.center),
      component(fixture, "c25.fixture.recode",
                mwperf::ComponentScopeV1::recode,
                fixture.projected_mean),
      component(fixture, "c25.fixture.solver",
                mwperf::ComponentScopeV1::solver, fixture.deployed_law),
      component(fixture, "c25.fixture.physical",
                mwperf::ComponentScopeV1::physical_fidelity,
                fixture.deployed_law, finite_interval(), std::nullopt,
                std::nullopt, std::nullopt, std::nullopt, 0.0L,
                fixture.physical_anchor)};
}

[[nodiscard]] std::vector<mwperf::ArtifactObjectReferenceV1> ordered_ids(
    const mwperf::DiagnosticBundle& bundle) {
  std::vector<mwperf::ArtifactObjectReferenceV1> result;
  result.reserve(bundle.ordered_components().size());
  for (const auto& item : bundle.ordered_components()) {
    result.push_back(item.component_identity());
  }
  return result;
}

[[nodiscard]] mwperf::ResponseToProjectionCenterBridgeV1 raw_to_center(
    const IdentityFixture& fixture) {
  return {fixture.raw_bins,
          fixture.center,
          object("c25.fixture.raw-to-center.evidence"),
          "decoded-response-to-projection-center",
          {"joint interval map"},
          {finite_interval(0.0L, 0.15L),
           finite_interval(0.0L, 0.20L)}};
}

[[nodiscard]] mwperf::ProjectionCenterToProjectedMeanBridgeV1
center_to_mean(const IdentityFixture& fixture) {
  return {fixture.center,
          fixture.projected_mean,
          object("c25.fixture.center-to-mean.evidence"),
          "constrained-mean-projection",
          {"nonexpansive in declared norm"},
          {finite_interval(0.0L, 0.10L),
           finite_interval(0.0L, 0.12L)}};
}

[[nodiscard]] mwperf::ProjectedMeanToRecodedResponseBridgeV1 mean_to_recoded(
    const IdentityFixture& fixture) {
  return {fixture.projected_mean,
          fixture.recoded_bins,
          object("c25.fixture.mean-to-recoded.evidence"),
          "deterministic-three-bin-recode",
          {"reference response fixed"},
          {finite_interval(0.0L, 0.08L),
           finite_interval(0.0L, 0.09L),
           finite_interval(0.0L, 0.11L)}};
}

[[nodiscard]] mwperf::TriangleContributionV1 final_triangle(
    const IdentityFixture& fixture) {
  return {object("c25.fixture.final-law-total"),
          mwperf::TriangleTotalKindV1::final_law_error,
          fixture.deployed_law,
          mwperf::TriangleCombinationRuleV1::deterministic,
          true,
          {object("c25.fixture.raw-uncertainty.component"),
           object("c25.fixture.projection-uncertainty.component"),
           object("c25.fixture.recode-uncertainty.component")},
          {object("c25.fixture.raw-to-center.evidence"),
           object("c25.fixture.center-to-mean.evidence"),
           object("c25.fixture.mean-to-recoded.evidence")}};
}

[[nodiscard]] std::vector<mwperf::DiagnosticComponent> bridge_chain(
    const IdentityFixture& fixture, const int omitted_bridge = 0) {
  const auto declaration = final_triangle(fixture);
  std::vector<mwperf::DiagnosticComponent> result;
  if (omitted_bridge == 1) {
    result.push_back(component(
        fixture, "c25.fixture.raw-uncertainty",
        mwperf::ComponentScopeV1::coefficient_sampling, fixture.raw_bins[0],
        finite_interval(0.0L, 0.1L), std::nullopt, std::nullopt,
        declaration));
  } else {
    result.push_back(component(
        fixture, "c25.fixture.raw-uncertainty",
        mwperf::ComponentScopeV1::coefficient_sampling, fixture.raw_bins[0],
        finite_interval(0.0L, 0.1L), fixture.center,
        mwperf::ProductBridgeV1(raw_to_center(fixture)), declaration));
  }
  if (omitted_bridge == 2) {
    result.push_back(component(
        fixture, "c25.fixture.projection-uncertainty",
        mwperf::ComponentScopeV1::projection, fixture.center,
        finite_interval(0.0L, 0.2L), std::nullopt, std::nullopt,
        declaration));
  } else {
    result.push_back(component(
        fixture, "c25.fixture.projection-uncertainty",
        mwperf::ComponentScopeV1::projection, fixture.center,
        finite_interval(0.0L, 0.2L), fixture.projected_mean,
        mwperf::ProductBridgeV1(center_to_mean(fixture)), declaration));
  }
  if (omitted_bridge == 3) {
    result.push_back(component(
        fixture, "c25.fixture.recode-uncertainty",
        mwperf::ComponentScopeV1::recode, fixture.projected_mean,
        finite_interval(0.0L, 0.3L), std::nullopt, std::nullopt,
        declaration));
  } else {
    result.push_back(component(
        fixture, "c25.fixture.recode-uncertainty",
        mwperf::ComponentScopeV1::recode, fixture.projected_mean,
        finite_interval(0.0L, 0.3L), fixture.recoded_bins[0],
        mwperf::ProductBridgeV1(mean_to_recoded(fixture)), declaration));
  }
  return result;
}

}  // namespace

TEST_CASE("C25 all nine error scopes and exact product stages remain distinct",
          "[c25][property][diagnostics][separation]") {
  const auto fixture = identities();
  const auto components = all_scopes(fixture);
  const auto bundle = mwperf::compose_diagnostic_and_error_budget(components);

  REQUIRE(bundle.valid());
  REQUIRE(bundle.ordered_components().size() == 9U);
  std::array<unsigned int, 9U> scope_counts{};
  std::array<unsigned int, 5U> product_counts{};
  for (const auto& item : bundle.ordered_components()) {
    ++scope_counts[static_cast<std::size_t>(item.scope())];
    ++product_counts[static_cast<std::size_t>(
        mwperf::product_kind_v1(item.source_product()))];
    REQUIRE(item.value().upper);
    CHECK(*item.value().upper == 0.125L);
  }
  for (const auto count : scope_counts) {
    CHECK(count == 1U);
  }
  CHECK(product_counts[static_cast<std::size_t>(
            mwperf::ProductKindV1::raw_response)] == 4U);
  CHECK(product_counts[static_cast<std::size_t>(
            mwperf::ProductKindV1::nominal_response)] == 1U);
  CHECK(product_counts[static_cast<std::size_t>(
            mwperf::ProductKindV1::projection_center)] == 1U);
  CHECK(product_counts[static_cast<std::size_t>(
            mwperf::ProductKindV1::projected_mean)] == 1U);
  CHECK(product_counts[static_cast<std::size_t>(
            mwperf::ProductKindV1::recoded_response)] == 2U);
}

TEST_CASE("C25 ledger order is canonical for diagnostic permutations",
          "[c25][property][diagnostics][canonical-order]") {
  const auto fixture = identities();
  auto components = all_scopes(fixture);
  const auto expected = ordered_ids(
      mwperf::compose_diagnostic_and_error_budget(components));
  std::mt19937_64 engine(0xC25D1A6ULL);
  for (std::size_t trial = 0; trial < 128U; ++trial) {
    std::shuffle(components.begin(), components.end(), engine);
    const auto bundle =
        mwperf::compose_diagnostic_and_error_budget(components);
    CAPTURE(trial);
    REQUIRE(bundle.valid());
    CHECK(ordered_ids(bundle) == expected);
  }
}

TEST_CASE("C25 three typed bridges are required to reach a recoded law",
          "[c25][property][diagnostics][bridge-chain]") {
  const auto fixture = identities();
  SECTION("complete chain") {
    const auto components = bridge_chain(fixture);
    const auto bundle =
        mwperf::compose_diagnostic_and_error_budget(components);
    REQUIRE(bundle.valid());
    REQUIRE(bundle.final_law_total().upper_bound);
    CHECK(bundle.final_law_total().claim_state ==
          mwperf::CertificateClaimStateV1::established);
    CHECK(bundle.final_law_total().value_status ==
          mwperf::BoundValueStatusV1::finite);
    CHECK(std::fabs(*bundle.final_law_total().upper_bound - 0.6L) < 1e-18L);
    REQUIRE(bundle.triangle_totals().size() == 1U);
    CHECK(bundle.triangle_totals().front().bridge_evidence_identities.size() ==
          3U);
  }

  SECTION("removing any bridge keeps the total unknown") {
    for (int omitted = 1; omitted <= 3; ++omitted) {
      const auto components = bridge_chain(fixture, omitted);
      const auto bundle =
          mwperf::compose_diagnostic_and_error_budget(components);
      CAPTURE(omitted);
      CHECK(bundle.ordered_components().size() == 3U);
      CHECK(bundle.final_law_total().claim_state ==
            mwperf::CertificateClaimStateV1::not_established);
      CHECK(bundle.final_law_total().value_status ==
            mwperf::BoundValueStatusV1::unresolved);
      CHECK_FALSE(bundle.final_law_total().upper_bound);
    }
  }

  SECTION("a present bridge with an unresolved result cannot authorize") {
    auto declaration = final_triangle(fixture);
    auto unresolved = raw_to_center(fixture);
    unresolved.resulting_intervals.front() = unknown_interval();
    std::vector<mwperf::DiagnosticComponent> components;
    components.push_back(component(
        fixture, "c25.fixture.raw-uncertainty",
        mwperf::ComponentScopeV1::coefficient_sampling, fixture.raw_bins[0],
        finite_interval(0.0L, 0.1L), fixture.center,
        mwperf::ProductBridgeV1(std::move(unresolved)), declaration));
    components.push_back(component(
        fixture, "c25.fixture.projection-uncertainty",
        mwperf::ComponentScopeV1::projection, fixture.center,
        finite_interval(0.0L, 0.2L), fixture.projected_mean,
        mwperf::ProductBridgeV1(center_to_mean(fixture)), declaration));
    components.push_back(component(
        fixture, "c25.fixture.recode-uncertainty",
        mwperf::ComponentScopeV1::recode, fixture.projected_mean,
        finite_interval(0.0L, 0.3L), fixture.recoded_bins[0],
        mwperf::ProductBridgeV1(mean_to_recoded(fixture)), declaration));

    const auto bundle =
        mwperf::compose_diagnostic_and_error_budget(components);
    CHECK(bundle.final_law_total().claim_state ==
          mwperf::CertificateClaimStateV1::not_established);
    CHECK_FALSE(bundle.final_law_total().upper_bound);
    CHECK(std::ranges::any_of(bundle.validation_diagnostics(),
                              [](const mwperf::Diagnostic& item) {
                                return item.code ==
                                       "c25.triangle_bridge_result_not_"
                                       "established";
                              }));
  }

  SECTION("omitting a declared contributor keeps the total unknown") {
    auto components = bridge_chain(fixture);
    components.erase(components.begin() + 1);
    const auto bundle =
        mwperf::compose_diagnostic_and_error_budget(components);
    CHECK(bundle.final_law_total().claim_state ==
          mwperf::CertificateClaimStateV1::not_established);
    CHECK_FALSE(bundle.final_law_total().upper_bound);
    CHECK(std::ranges::any_of(bundle.validation_diagnostics(),
                              [](const mwperf::Diagnostic& item) {
                                return item.code ==
                                       "c25.triangle_component_set_incomplete";
                              }));
  }
}

TEST_CASE("C25 an unknown required component prevents a physical total",
          "[c25][property][diagnostics][unknown-total]") {
  const auto fixture = identities();
  const mwperf::TriangleContributionV1 declaration{
      object("c25.fixture.physical-total"),
      mwperf::TriangleTotalKindV1::physical_error,
      fixture.deployed_law,
      mwperf::TriangleCombinationRuleV1::deterministic,
      true,
      {object("c25.fixture.runtime-sampling.component"),
       object("c25.fixture.stationary-residual.component"),
       object("c25.fixture.opportunity-closure.component")},
      {}};
  std::vector<mwperf::DiagnosticComponent> components;
  components.push_back(component(
      fixture, "c25.fixture.runtime-sampling", mwperf::ComponentScopeV1::solver,
      fixture.deployed_law, finite_interval(0.0L, 0.04L), std::nullopt,
      std::nullopt, declaration));
  components.push_back(component(
      fixture, "c25.fixture.stationary-residual",
      mwperf::ComponentScopeV1::solver, fixture.deployed_law,
      finite_interval(0.0L, 0.02L), std::nullopt, std::nullopt,
      declaration));
  components.push_back(component(
      fixture, "c25.fixture.opportunity-closure",
      mwperf::ComponentScopeV1::optimizer, fixture.deployed_law,
      unknown_interval(), std::nullopt, std::nullopt, declaration));
  const auto bundle = mwperf::compose_diagnostic_and_error_budget(components);
  CHECK(bundle.ordered_components().size() == 3U);
  CHECK(bundle.physical_total().claim_state ==
        mwperf::CertificateClaimStateV1::not_established);
  CHECK(bundle.physical_total().value_status ==
        mwperf::BoundValueStatusV1::unresolved);
  CHECK_FALSE(bundle.physical_total().upper_bound);
}

TEST_CASE("C25 cross-product identity cannot be replaced by equal numbers",
          "[c25][negative][diagnostics][identity-by-value]") {
  const auto fixture = identities();

  SECTION("different stage without a bridge") {
    auto rejected = mwperf::DiagnosticComponent::make(
        {object("c25.fixture.unbridged.component"),
         mwperf::ComponentScopeV1::projection,
         fixture.raw_bins[0],
         fixture.center,
         "same numeric interval",
         fixture.geometry,
         finite_interval(0.125L, 0.125L),
         std::nullopt,
         0.0L,
         "numeric equality is not a map",
         {},
         {object("c25.fixture.unbridged.evidence")},
         object("c25.fixture.unbridged.provenance"),
         std::nullopt,
         std::nullopt,
         std::nullopt,
         std::nullopt});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.cross_product_transfer_missing");
  }

  SECTION("bridge source stage does not match the component") {
    auto rejected = mwperf::DiagnosticComponent::make(
        {object("c25.fixture.wrong-stage.component"),
         mwperf::ComponentScopeV1::projection,
         fixture.nominal_bins[0],
         fixture.center,
         "same numeric interval",
         fixture.geometry,
         finite_interval(0.125L, 0.125L),
         std::nullopt,
         0.0L,
         "raw bridge cannot cover nominal response",
         {},
         {object("c25.fixture.wrong-stage.evidence")},
         object("c25.fixture.wrong-stage.provenance"),
         mwperf::ProductBridgeV1(raw_to_center(fixture)),
         std::nullopt,
         std::nullopt,
         std::nullopt});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.bridge_attachment_mismatch");
  }

  SECTION("changing only the frozen-run identity breaks the bridge") {
    auto foreign_bridge = raw_to_center(fixture);
    auto* foreign_sources =
        std::get_if<std::vector<mwperf::RawResponseCoefficientIdentityV1>>(
            &foreign_bridge.sources);
    REQUIRE(foreign_sources != nullptr);
    for (auto& source : *foreign_sources) {
      source.context.final_probe_id = label("c25.fixture.foreign-final-probe");
    }
    auto rejected = mwperf::DiagnosticComponent::make(
        {object("c25.fixture.foreign-run.component"),
         mwperf::ComponentScopeV1::projection,
         foreign_sources->front(),
         fixture.center,
         "same numeric interval",
         fixture.geometry,
         finite_interval(0.125L, 0.125L),
         std::nullopt,
         0.0L,
         "identity-bound bridge",
         {},
         {object("c25.fixture.foreign-run.evidence")},
         object("c25.fixture.foreign-run.provenance"),
         mwperf::ProductBridgeV1(std::move(foreign_bridge)),
         std::nullopt,
         std::nullopt,
         std::nullopt});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.bridge_cross_fingerprint");
  }

  SECTION("raw bins with mixed value forms cannot form one bridge") {
    auto mixed = raw_to_center(fixture);
    auto* sources =
        std::get_if<std::vector<mwperf::RawResponseCoefficientIdentityV1>>(
            &mixed.sources);
    REQUIRE(sources != nullptr);
    (*sources)[1].value_form =
        mwperf::ResponseProductValueFormV1::exact_point;
    auto rejected = mwperf::DiagnosticComponent::make(
        {object("c25.fixture.mixed-form.component"),
         mwperf::ComponentScopeV1::projection,
         sources->front(),
         fixture.center,
         "raw product value form",
         fixture.geometry,
         finite_interval(0.0L, 0.1L),
         std::nullopt,
         0.0L,
         "identity-bound bridge",
         {},
         {object("c25.fixture.mixed-form.evidence")},
         object("c25.fixture.mixed-form.provenance"),
         mwperf::ProductBridgeV1(std::move(mixed)),
         std::nullopt,
         std::nullopt,
         std::nullopt});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.bridge_mixed_response_product");
  }

  SECTION("an interval-only raw response is not a deployed law") {
    auto rejected = mwperf::LawIdentityV1::make(
        {fixture.response_context,
         mwperf::DeployedResponseProductReferenceV1(
             mwperf::RawResponseProductRef{
                 fixture.raw_product.identity(),
                 mwperf::ResponseProductValueFormV1::interval_only}),
         digest("c25.fixture.configured-arrival"),
         digest("c25.fixture.execution"),
         digest("c25.fixture.metric-target")});
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c25.interval_raw_not_deployable");
  }
}

TEST_CASE("C25 product bridges retain their closed diagnostic owners",
          "[c25][negative][diagnostics][bridge-owner]") {
  const auto fixture = identities();
  const auto make_component =
      [&](const std::string_view name, const mwperf::ComponentScopeV1 scope,
          mwperf::ProductIdentityV1 source,
          mwperf::ProductIdentityV1 destination,
          mwperf::ProductBridgeV1 bridge) {
        const auto base = std::string(name);
        return mwperf::DiagnosticComponent::make(
            {object(base + ".component"),
             scope,
             std::move(source),
             std::move(destination),
             "owned product transfer",
             fixture.geometry,
             finite_interval(0.0L, 0.1L),
             std::nullopt,
             0.0L,
             "typed product map",
             {},
             {object(base + ".evidence")},
             object(base + ".provenance"),
             std::move(bridge),
             std::nullopt,
             std::nullopt,
             std::nullopt});
      };

  SECTION("response-to-center accepts its compression owner") {
    auto accepted = make_component(
        "c25.fixture.compression-owned-response-bridge",
        mwperf::ComponentScopeV1::compression, fixture.raw_bins[0],
        fixture.center, mwperf::ProductBridgeV1(raw_to_center(fixture)));
    INFO((accepted ? std::string{}
                   : accepted.error().code + ": " +
                         accepted.error().message));
    REQUIRE(accepted);
  }

  const auto require_owner_rejection =
      [&](const std::string_view name, const mwperf::ComponentScopeV1 scope,
          mwperf::ProductIdentityV1 source,
          mwperf::ProductIdentityV1 destination,
          mwperf::ProductBridgeV1 bridge) {
        auto rejected = make_component(name, scope, std::move(source),
                                       std::move(destination),
                                       std::move(bridge));
        REQUIRE_FALSE(rejected);
        CHECK(rejected.error().code == "c25.bridge_scope_owner_mismatch");
      };

  SECTION("solver cannot carry response-to-center construction") {
    require_owner_rejection(
        "c25.fixture.solver-response-bridge",
        mwperf::ComponentScopeV1::solver, fixture.raw_bins[0], fixture.center,
        mwperf::ProductBridgeV1(raw_to_center(fixture)));
  }
  SECTION("physical fidelity cannot carry an internal construction bridge") {
    require_owner_rejection(
        "c25.fixture.physical-response-bridge",
        mwperf::ComponentScopeV1::physical_fidelity, fixture.raw_bins[0],
        fixture.center, mwperf::ProductBridgeV1(raw_to_center(fixture)));
  }
  SECTION("recode cannot carry center-to-projected-mean projection") {
    require_owner_rejection(
        "c25.fixture.recode-projection-bridge",
        mwperf::ComponentScopeV1::recode, fixture.center,
        fixture.projected_mean,
        mwperf::ProductBridgeV1(center_to_mean(fixture)));
  }
  SECTION("projection cannot carry projected-mean-to-response recoding") {
    require_owner_rejection(
        "c25.fixture.projection-recode-bridge",
        mwperf::ComponentScopeV1::projection, fixture.projected_mean,
        fixture.recoded_bins[0],
        mwperf::ProductBridgeV1(mean_to_recoded(fixture)));
  }
}

TEST_CASE("C25 duplicate component identities cannot overwrite a category",
          "[c25][negative][diagnostics][no-overwrite]") {
  const auto fixture = identities();
  auto first = component(fixture, "c25.fixture.duplicate",
                         mwperf::ComponentScopeV1::optimizer,
                         fixture.raw_bins[0]);
  auto second_spec = mwperf::DiagnosticComponent::make(
      {first.component_identity(),
       mwperf::ComponentScopeV1::solver,
       fixture.deployed_law,
       std::nullopt,
       "total-variation diagnostic",
       fixture.geometry,
       finite_interval(),
       std::nullopt,
       0.0L,
       "distinct solver method",
       {},
       {object("c25.fixture.duplicate.second-evidence")},
       object("c25.fixture.duplicate.second-provenance"),
       std::nullopt,
       std::nullopt,
       std::nullopt,
       std::nullopt});
  REQUIRE(second_spec);
  std::vector<mwperf::DiagnosticComponent> components;
  components.push_back(std::move(first));
  components.push_back(std::move(second_spec).value());

  const auto bundle = mwperf::compose_diagnostic_and_error_budget(components);
  CHECK(bundle.ordered_components().size() == 2U);
  CHECK_FALSE(bundle.valid());
  CHECK(std::ranges::any_of(bundle.validation_diagnostics(),
                            [](const mwperf::Diagnostic& item) {
                              return item.code ==
                                     "c25.component_identity_overwrite";
                            }));
}

TEST_CASE("C25 physical fidelity requires an exact deployed law identity",
          "[c25][negative][diagnostics][physical-firewall]") {
  const auto fixture = identities();
  auto rejected = mwperf::DiagnosticComponent::make(
      {object("c25.fixture.false-physical.component"),
       mwperf::ComponentScopeV1::physical_fidelity,
       fixture.raw_bins[0],
       std::nullopt,
       "physical backlog law",
       fixture.geometry,
       finite_interval(0.0L, 0.0L),
       std::nullopt,
       0.0L,
       "internal optimizer exactness",
       {},
       {object("c25.fixture.optimizer-only.evidence")},
       object("c25.fixture.optimizer-only.provenance"),
       std::nullopt,
       std::nullopt,
       std::nullopt,
       std::nullopt});
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c25.physical_fidelity_law_missing");

  auto missing_anchor = mwperf::DiagnosticComponent::make(
      {object("c25.fixture.unanchored-physical.component"),
       mwperf::ComponentScopeV1::physical_fidelity,
       fixture.deployed_law,
       std::nullopt,
       "physical backlog law",
       fixture.geometry,
       finite_interval(0.0L, 0.0L),
       std::nullopt,
       0.0L,
       "claimed physical comparison",
       {},
       {object("c25.fixture.unanchored-physical.evidence")},
       object("c25.fixture.unanchored-physical.provenance"),
       std::nullopt,
       std::nullopt,
       std::nullopt,
       std::nullopt});
  REQUIRE_FALSE(missing_anchor);
  CHECK(missing_anchor.error().code ==
        "c25.physical_fidelity_anchor_missing");
}
