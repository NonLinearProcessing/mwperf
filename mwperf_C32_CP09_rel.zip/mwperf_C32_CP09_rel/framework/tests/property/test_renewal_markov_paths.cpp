#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/private_markov_renewal.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/arrival/shared_round_renewal.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct ParsedArrival final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

struct StepRecord final {
  mwperf::ArrivalBatch batch;
  mwperf::ArrivalStateDigest phase_before;
  mwperf::ArrivalStateDigest phase_after;
  std::vector<std::byte> phase_before_bytes;
  std::vector<std::byte> phase_after_bytes;
};

[[nodiscard]] std::filesystem::path write_fixture(
    const std::string_view contents) {
  static std::atomic<unsigned int> serial{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c11-renewal-markov-properties";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory /
      ("path-" + std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(contents.data(),
               static_cast<std::streamsize>(contents.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] ParsedArrival parse_arrival(const std::string_view arrival) {
  const std::string document_text =
      R"json({"schema_version":"3.0.0","switch":{"kind":"generalized","queue_capacity":null,"queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1","q2"],"max_search_states":null}},"arrival":)json" +
      std::string(arrival) +
      R"json(,"telemetry":{"format":"jsonl","queue_snapshot":"disabled","include_packet_events":false,"include_scheduler_state":false,"write_slot_trace":false},"metadata":{}})json";
  auto document = mwperf::load_document(write_fixture(document_text));
  REQUIRE(document);
  auto executable = mwperf::extract_executable_model(document.value());
  REQUIRE(executable);
  auto model = mwperf::parse_model_config_v3(executable.value());
  INFO((!model ? model.error().code + ": " + model.error().message
               : std::string{}));
  REQUIRE(model);
  auto queues = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(queues);
  return ParsedArrival{std::move(model).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::CompiledArrivalLaw compile(const ParsedArrival& parsed) {
  auto law = mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
  INFO((!law ? law.error().code + ": " + law.error().message
             : std::string{}));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::DeterministicRng configured_rng(
    const std::uint64_t seed, const std::uint64_t instance) {
  auto digest = mwperf::sha256(std::span<const std::byte>{});
  REQUIRE(digest);
  auto key = mwperf::make_physical_reference_instance_key(
      digest.value(), mwperf::BigNat(instance));
  REQUIRE(key);
  return mwperf::derive_rng_stream(
      mwperf::MasterSeed(seed), mwperf::StageTag::configured_arrival,
      key.value());
}

[[nodiscard]] mwperf::SourceNode initial_source_node() {
  return mwperf::SourceNode::make_object(
      std::vector<mwperf::SourceObjectMember>{},
      mwperf::SourceLocation{"c11-property", 1U, 1U, 0U},
      "/initial/arrival_state");
}

[[nodiscard]] mwperf::ArrivalInitialState private_initial(
    const std::initializer_list<std::pair<std::string_view,
                                          std::string_view>> states) {
  std::vector<mwperf::PrivateMarkovState> concrete;
  concrete.reserve(states.size());
  for (const auto& [source, state] : states) {
    concrete.push_back(mwperf::PrivateMarkovState{
        std::string(source), std::string(state), initial_source_node()});
  }
  return mwperf::PrivateMarkovStates{std::move(concrete)};
}

[[nodiscard]] mwperf::ArrivalProcess instantiate(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::ArrivalInitialState& initial, const std::uint64_t seed,
    const std::uint64_t instance) {
  auto key = mwperf::make_configured_arrival_stream_key(
      law, configured_rng(seed, instance));
  REQUIRE(key);
  auto process = mwperf::instantiate_arrival_process(
      law, initial, std::move(key).value());
  INFO((!process ? process.error().code + ": " + process.error().message
                 : std::string{}));
  REQUIRE(process);
  return std::move(process).value();
}

[[nodiscard]] mwperf::BigNat count_at(const mwperf::ArrivalBatch& batch,
                                      const std::size_t queue) {
  for (const auto& entry : batch.entries()) {
    if (entry.queue.ordinal() == queue) {
      return entry.count;
    }
  }
  return mwperf::BigNat(0U);
}

[[nodiscard]] std::vector<std::byte> phase_bytes(
    const mwperf::ArrivalPhase& phase) {
  const auto bytes = mwperf::arrival_phase_canonical_state(phase);
  return std::vector<std::byte>(bytes.begin(), bytes.end());
}

[[nodiscard]] StepRecord record(const mwperf::ArrivalStep& step) {
  return StepRecord{step.batch,
                    mwperf::arrival_phase_digest(step.phase_before),
                    mwperf::arrival_phase_digest(step.phase_after),
                    phase_bytes(step.phase_before),
                    phase_bytes(step.phase_after)};
}

void check_record(const mwperf::ArrivalStep& step,
                  const StepRecord& expected) {
  CHECK(step.batch == expected.batch);
  CHECK(mwperf::arrival_phase_digest(step.phase_before) ==
        expected.phase_before);
  CHECK(mwperf::arrival_phase_digest(step.phase_after) ==
        expected.phase_after);
  CHECK(phase_bytes(step.phase_before) == expected.phase_before_bytes);
  CHECK(phase_bytes(step.phase_after) == expected.phase_after_bytes);
}

void check_supported(const mwperf::ArrivalStep& step,
                     const mwperf::QueueMask& support) {
  for (const auto& entry : step.batch.entries()) {
    CHECK(entry.count > mwperf::BigNat(0U));
    CHECK(support.at(entry.queue));
  }
}

[[nodiscard]] mwperf::testing::ArrivalProcessSnapshot snapshot(
    const mwperf::ArrivalProcess& process) {
  auto result = mwperf::testing::snapshot_arrival_process(process);
  REQUIRE(result);
  return std::move(result).value();
}

void check_same_snapshot(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  CHECK(left.expected_slot == right.expected_slot);
  CHECK(left.phase_digest == right.phase_digest);
  CHECK(left.rng.stream_identity() == right.rng.stream_identity());
  CHECK(left.rng.state_words() == right.rng.state_words());
  CHECK(left.rng.consumed_words() == right.rng.consumed_words());
}

}  // namespace

TEST_CASE("C11 renewal paths equal exact cumulative sampled gaps",
          "[c11][property][renewal]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[{
      "id":"source","joint_pmf":[
        {"d":1,"queue_id":"q0","probability":0.25},
        {"d":2,"queue_id":"q1","probability":0.25},
        {"d":5,"queue_id":"q2","probability":0.5}]
    }],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = compile(parsed);
  const mwperf::QueueMask support = mwperf::positive_arrival_support(law);
  auto primary = instantiate(law, mwperf::RenewalOrigin{}, 0xc110001U, 7U);
  auto replay = instantiate(law, mwperf::RenewalOrigin{}, 0xc110001U, 7U);
  auto interleaved =
      instantiate(law, mwperf::RenewalOrigin{}, 0xc110002U, 8U);

  mwperf::BigNat cumulative_gap(0U);
  std::size_t event_count = 0U;
  for (std::uint64_t slot = 0U; slot < 800U; ++slot) {
    auto first = mwperf::next_marked_renewal_batch(primary,
                                                   mwperf::BigNat(slot));
    REQUIRE(first);
    auto noise = mwperf::next_marked_renewal_batch(interleaved,
                                                   mwperf::BigNat(slot));
    REQUIRE(noise);
    auto second = mwperf::next_marked_renewal_batch(replay,
                                                    mwperf::BigNat(slot));
    REQUIRE(second);
    check_record(second.value(), record(first.value()));
    check_supported(first.value(), support);

    if (first.value().batch.empty_batch()) {
      continue;
    }
    REQUIRE(first.value().batch.entries().size() == 1U);
    const auto& event = first.value().batch.entries().front();
    REQUIRE(event.count == mwperf::BigNat(1U));
    const std::vector<mwperf::BigNat> gap_by_queue{
        mwperf::BigNat(1U), mwperf::BigNat(2U), mwperf::BigNat(5U)};
    REQUIRE(event.queue.ordinal() < gap_by_queue.size());
    cumulative_gap += gap_by_queue[event.queue.ordinal()];
    CHECK(cumulative_gap == mwperf::BigNat(slot + 1U));
    ++event_count;
  }
  CHECK(event_count > 150U);
  check_same_snapshot(snapshot(primary), snapshot(replay));
}

TEST_CASE("C11 renewal clocks retain values beyond fixed-width time",
          "[c11][property][renewal][large-clock]") {
  ParsedArrival parsed = parse_arrival(R"json({
    "family":"independent_marked_renewal","sources":[{
      "id":"large","interarrival":{"kind":"deterministic","d":1},
      "destination_pmf":[{"queue_id":"q0","probability":1}]
    }],"metadata":{}
  })json");
  auto huge = mwperf::BigNat::from_big_int(
      mwperf::BigInt("184467440737095516170000000000000000000"));
  REQUIRE(huge);
  auto& renewal = std::get<mwperf::IndependentMarkedRenewalArrival>(
      parsed.model.arrival.value);
  auto& source = std::get<mwperf::FactorizedRenewalSource>(
      renewal.sources.value.front());
  std::get<mwperf::DeterministicInterarrival>(source.interarrival.value)
      .d.value = huge.value();

  auto geometry = mwperf::compile_marked_renewal(renewal, parsed.queues);
  REQUIRE(geometry);
  const auto& compiled_source =
      std::get<mwperf::FactorizedRenewalLawSource>(
          geometry.value().sources().front());
  CHECK(std::get<mwperf::DeterministicRenewalGap>(
            compiled_source.interarrival)
            .gap == huge.value());

  const mwperf::CompiledArrivalLaw law = compile(parsed);
  auto process = instantiate(law, mwperf::RenewalOrigin{}, 0xc110003U, 9U);
  auto zero = mwperf::next_marked_renewal_batch(process, mwperf::BigNat(0U));
  REQUIRE(zero);
  CHECK(zero.value().batch.empty_batch());
  CHECK(snapshot(process).expected_slot == mwperf::BigNat(1U));
  CHECK(snapshot(process).rng.consumed_words().is_zero());
}

TEST_CASE("C11 private chains advance only at events and use the new-state gap",
          "[c11][property][private-markov]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"independent_private_markov_renewal","sources":[{
      "id":"source","states":["a","b"],"initial":{"state":"a"},
      "gaps":[{"state":"a","d":2},{"state":"b","d":5}],
      "transitions":[
        {"state":"a","next_state":"b","probability":1},
        {"state":"b","next_state":"a","probability":1}],
      "destination_pmf":[{"queue_id":"q1","probability":1}]
    }],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = compile(parsed);
  auto process = instantiate(law, private_initial({{"source", "a"}}),
                             0xc110004U, 10U);
  const mwperf::QueueMask support = mwperf::positive_arrival_support(law);

  mwperf::BigNat next_epoch(2U);
  bool next_state_is_b = true;
  std::size_t observed = 0U;
  for (std::uint64_t slot = 0U; slot < 80U; ++slot) {
    auto step = mwperf::next_private_markov_batch(process,
                                                  mwperf::BigNat(slot));
    REQUIRE(step);
    check_supported(step.value(), support);
    const bool expected_event = next_epoch == mwperf::BigNat(slot + 1U);
    CHECK(count_at(step.value().batch, 1U) ==
          mwperf::BigNat(expected_event ? 1U : 0U));
    CHECK(step.value().batch.entries().size() ==
          static_cast<std::size_t>(expected_event ? 1U : 0U));
    if (!expected_event) {
      continue;
    }

    // Transition happens after this emission.  The next epoch therefore uses
    // the gap of the newly entered state, rather than reusing the old gap.
    next_epoch += mwperf::BigNat(next_state_is_b ? 5U : 2U);
    next_state_is_b = !next_state_is_b;
    ++observed;
  }
  CHECK(observed > 20U);
}

TEST_CASE("C11 shared projections preserve sampled rounds across horizons",
          "[c11][property][shared-round]") {
  const ParsedArrival parsed = parse_arrival(R"json({
    "family":"shared_joint_round_markov_renewal",
    "sources":[{"id":"fast"},{"id":"slow"}],
    "states":["state"],"initial":{"state":"state"},
    "outcomes":[
      {"state":"state","next_state":"state","probability":0.5,
       "emissions":[{"source_id":"fast","d":1,"queue_id":"q0"},
                    {"source_id":"slow","d":5,"queue_id":"q2"}]},
      {"state":"state","next_state":"state","probability":0.5,
       "emissions":[{"source_id":"fast","d":2,"queue_id":"q1"},
                    {"source_id":"slow","d":3,"queue_id":"q2"}]}
    ],"metadata":{}
  })json");
  const mwperf::CompiledArrivalLaw law = compile(parsed);
  const mwperf::ArrivalInitialState initial = mwperf::SharedRoundState{"state"};
  auto uninterrupted = instantiate(law, initial, 0xc110005U, 11U);
  auto segmented = instantiate(law, initial, 0xc110005U, 11U);
  auto interleaved = instantiate(law, initial, 0xc110006U, 12U);
  const mwperf::QueueMask support = mwperf::positive_arrival_support(law);

  constexpr std::uint64_t kPrefix = 73U;
  constexpr std::uint64_t kTotal = 320U;
  std::vector<StepRecord> uninterrupted_path;
  uninterrupted_path.reserve(kTotal);
  std::vector<std::uint64_t> observed_slow_slots;
  std::vector<std::uint64_t> expected_slow_slots;
  mwperf::BigNat fast_epoch(0U);
  mwperf::BigNat slow_epoch(0U);

  for (std::uint64_t slot = 0U; slot < kTotal; ++slot) {
    auto step = mwperf::next_shared_round_batch(uninterrupted,
                                                mwperf::BigNat(slot));
    REQUIRE(step);
    check_supported(step.value(), support);
    uninterrupted_path.push_back(record(step.value()));

    const bool first_outcome = !count_at(step.value().batch, 0U).is_zero();
    const bool second_outcome = !count_at(step.value().batch, 1U).is_zero();
    REQUIRE_FALSE((first_outcome && second_outcome));
    if (first_outcome || second_outcome) {
      REQUIRE(count_at(step.value().batch, first_outcome ? 0U : 1U) ==
              mwperf::BigNat(1U));
      fast_epoch += mwperf::BigNat(first_outcome ? 1U : 2U);
      CHECK(fast_epoch == mwperf::BigNat(slot + 1U));
      slow_epoch += mwperf::BigNat(first_outcome ? 5U : 3U);
      if (slow_epoch <= mwperf::BigNat(kTotal)) {
        expected_slow_slots.push_back(
            slow_epoch.value().convert_to<std::uint64_t>() - 1U);
      }
    }
    if (!count_at(step.value().batch, 2U).is_zero()) {
      REQUIRE(count_at(step.value().batch, 2U) == mwperf::BigNat(1U));
      observed_slow_slots.push_back(slot);
    }

    auto noise = mwperf::next_shared_round_batch(interleaved,
                                                 mwperf::BigNat(slot));
    REQUIRE(noise);
  }

  // Advance to a caller horizon, retain the cursor, and then extend it.  The
  // entire result must equal the path produced without a horizon boundary.
  for (std::uint64_t slot = 0U; slot < kPrefix; ++slot) {
    auto step = mwperf::next_shared_round_batch(segmented,
                                                mwperf::BigNat(slot));
    REQUIRE(step);
    check_record(step.value(), uninterrupted_path[slot]);
  }
  const auto horizon_snapshot = snapshot(segmented);
  CHECK(horizon_snapshot.expected_slot == mwperf::BigNat(kPrefix));
  for (std::uint64_t slot = kPrefix; slot < kTotal; ++slot) {
    auto step = mwperf::next_shared_round_batch(segmented,
                                                mwperf::BigNat(slot));
    REQUIRE(step);
    check_record(step.value(), uninterrupted_path[slot]);
  }

  CHECK(observed_slow_slots == expected_slow_slots);
  CHECK(observed_slow_slots.size() > 40U);
  check_same_snapshot(snapshot(uninterrupted), snapshot(segmented));
}
