#include <optional>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/compression_analysis.hpp"
#include "support/c30_observation_fixture.hpp"

namespace {

[[nodiscard]] const mwperf::ExactRational& exact_value(
    const mwperf::CompressionQuantityV1& quantity) {
  REQUIRE(quantity.available());
  REQUIRE(quantity.estimate);
  REQUIRE(quantity.estimate->absolute_error_bound.is_zero());
  return quantity.estimate->value;
}

}  // namespace

TEST_CASE("C30 empirical compression identities close in exact arithmetic",
          "[c30][math][property][identities]") {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(
          mwperf::testing::c30::exact_gap_bundle()),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, true, false, true,
      true,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);

  const auto& cutoff = analysis.value().cutoffs.front();
  CHECK(exact_value(analysis.value().pooled.mass_per_slot) ==
        mwperf::testing::c30::rational(1));
  CHECK(exact_value(analysis.value().pooled.signed_mass_defect).is_zero());
  CHECK(exact_value(analysis.value().pooled.departure_rate) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(analysis.value().pooled.observed_mean) ==
        mwperf::testing::c30::rational(5, 4));
  CHECK(exact_value(analysis.value().pooled.service_moment) ==
        mwperf::testing::c30::rational(3, 4));

  CHECK(exact_value(cutoff.tail.tail_probability) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(cutoff.tail.tail_service_mass) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(cutoff.tail.backlog_tail_reward) ==
        mwperf::testing::c30::rational(1));
  CHECK(exact_value(cutoff.tail.backlog_service_tail_reward) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(cutoff.tail.constant_tail_response) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(cutoff.tail.tail_slack) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(cutoff.tail.discarded_association_reward).is_zero());
  CHECK(exact_value(cutoff.tail.tail_mean_fraction) ==
        mwperf::testing::c30::rational(4, 5));
  CHECK(exact_value(cutoff.tail.stationary_compression_defect).is_zero());

  CHECK(exact_value(cutoff.decomposition.arrival_balance_constant) ==
        mwperf::testing::c30::rational(3, 16));
  CHECK(exact_value(cutoff.decomposition.empirical_balance_residual) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(cutoff.decomposition.observed_prefix_correction) ==
        mwperf::testing::c30::rational(-1, 8));
  CHECK(exact_value(cutoff.decomposition.observation_balance_lhs) ==
        mwperf::testing::c30::rational(5, 16));
  CHECK(exact_value(cutoff.decomposition.observation_balance_rhs) ==
        mwperf::testing::c30::rational(5, 16));
  CHECK(exact_value(cutoff.decomposition.observation_balance_closure)
            .is_zero());
  CHECK(exact_value(cutoff.diagnostic_fitted_mean) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(cutoff.decomposition.fitted_prefix_correction) ==
        mwperf::testing::c30::rational(-1, 8));
  CHECK(exact_value(cutoff.decomposition.fitted_minus_observed_mean) ==
        mwperf::testing::c30::rational(-1));
  CHECK(exact_value(cutoff.decomposition.numerator_lhs) ==
        mwperf::testing::c30::rational(-1, 4));
  CHECK(exact_value(cutoff.decomposition.numerator_rhs) ==
        mwperf::testing::c30::rational(-1, 4));
  CHECK(exact_value(cutoff.decomposition.numerator_closure).is_zero());
  CHECK(exact_value(cutoff.decomposition.compression_term).is_zero());
  CHECK(exact_value(cutoff.decomposition.fitted_prefix_term).is_zero());
  CHECK(exact_value(cutoff.decomposition.finite_window_balance_term) ==
        mwperf::testing::c30::rational(-1));
  CHECK(exact_value(cutoff.decomposition.divided_term_sum) ==
        mwperf::testing::c30::rational(-1));
  CHECK(exact_value(cutoff.decomposition.divided_closure).is_zero());

  const auto& window = analysis.value().finite_window;
  CHECK(exact_value(window.first_moment_endpoint_drift).is_zero());
  CHECK(exact_value(window.second_moment_endpoint_drift).is_zero());
  CHECK(exact_value(window.first_moment_expected_increment) ==
        mwperf::testing::c30::rational(-1, 4));
  CHECK(exact_value(window.second_moment_expected_increment) ==
        mwperf::testing::c30::rational(-3, 8));
  CHECK(exact_value(window.first_moment_innovation) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(window.second_moment_innovation) ==
        mwperf::testing::c30::rational(3, 8));
  CHECK(exact_value(window.starred_balance_residual) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(window.mass_defect_corrected_balance_residual) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(window.first_moment_endpoint_drift) ==
        exact_value(window.first_moment_expected_increment) +
            exact_value(window.first_moment_innovation));
  CHECK(exact_value(window.second_moment_endpoint_drift) ==
        exact_value(window.second_moment_expected_increment) +
            exact_value(window.second_moment_innovation));
  CHECK(exact_value(window.moment_identity_closure).is_zero());
  REQUIRE(window.cutoffs.size() == 1U);
  CHECK(exact_value(window.cutoffs.front().hinge_endpoint_drift).is_zero());
  CHECK(exact_value(window.cutoffs.front().tail_probability_per_slot) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(window.cutoffs.front().overshoot_reward_normalized)
            .is_zero());
  CHECK(exact_value(window.cutoffs.front().overshoot_reward_per_slot)
            .is_zero());
  CHECK(exact_value(window.cutoffs.front().innovation) ==
        mwperf::testing::c30::rational(1, 8));
  CHECK(exact_value(window.cutoffs.front().realized_identity_closure)
            .is_zero());

  REQUIRE(analysis.value().competition.cutoffs.size() == 1U);
  CHECK(exact_value(analysis.value().competition.mean_gap).is_zero());
  CHECK(exact_value(analysis.value().competition.mean_absolute_gap) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(analysis.value().competition.mean_competition_scale) ==
        mwperf::testing::c30::rational(5, 4));
  CHECK(exact_value(analysis.value().competition.normalized_gap_scale) ==
        mwperf::testing::c30::rational(2, 5));
  CHECK(exact_value(analysis.value()
                        .competition.cutoffs.front()
                        .association_split_closure)
            .is_zero());
  for (const auto& point : analysis.value().ties.response_by_level) {
    CHECK(exact_value(point.reconstructed_response) ==
          exact_value(point.observed_response));
    CHECK(exact_value(point.response_reconstruction_closure).is_zero());
  }
  CHECK(exact_value(analysis.value().ties.strict_loss_backlog_reward)
            .is_zero());
  CHECK(exact_value(analysis.value().ties.lost_tie_backlog_reward) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(analysis.value().ties.empirical_identity_lhs) ==
        mwperf::testing::c30::rational(15, 16));
  CHECK(exact_value(analysis.value().ties.empirical_identity_rhs) ==
        mwperf::testing::c30::rational(15, 16));
  CHECK(exact_value(analysis.value().ties.empirical_identity_closure)
            .is_zero());
  CHECK(exact_value(analysis.value().ties.isolated_server_baseline) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(analysis.value().ties.strict_loss_mean_contribution)
            .is_zero());
  CHECK(exact_value(analysis.value().ties.lost_tie_mean_contribution) ==
        mwperf::testing::c30::rational(2, 3));
  CHECK(exact_value(analysis.value().ties.stationary_mean_reconstruction) ==
        mwperf::testing::c30::rational(11, 12));
}

TEST_CASE("C30 exact gap split connects nonzero competition and compression scales",
          "[c30][math][property][identities][gap]") {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(
          mwperf::testing::c30::exact_gap_bundle()),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{0U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  REQUIRE(analysis.value().competition.cutoffs.size() == 1U);

  const auto& tail = analysis.value().cutoffs.front().tail;
  CHECK(exact_value(tail.tail_probability) ==
        mwperf::testing::c30::rational(3, 4));
  CHECK(exact_value(tail.tail_service_mass) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(tail.backlog_tail_reward) ==
        mwperf::testing::c30::rational(5, 4));
  CHECK(exact_value(tail.backlog_service_tail_reward) ==
        mwperf::testing::c30::rational(3, 4));
  CHECK(exact_value(tail.constant_tail_response) ==
        mwperf::testing::c30::rational(2, 3));
  CHECK(exact_value(tail.discarded_association_reward) ==
        mwperf::testing::c30::rational(-1, 12));

  const auto& gap = analysis.value().competition.cutoffs.front();
  CHECK(exact_value(gap.positive_gap_tail_reward) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(gap.negative_gap_tail_reward).is_zero());
  CHECK(exact_value(gap.gap_association_reward) ==
        mwperf::testing::c30::rational(1, 12));
  CHECK(exact_value(gap.competition_association_reward) ==
        mwperf::testing::c30::rational(-1, 6));
  CHECK(exact_value(gap.competition_backlog_tail_reward) ==
        mwperf::testing::c30::rational(1));
  CHECK(exact_value(gap.competition_service_tail_reward) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(gap.direct_competition_association_reward) ==
        mwperf::testing::c30::rational(-1, 6));
  CHECK(exact_value(gap.association_split_closure).is_zero());
}

TEST_CASE("C30 mass-defect correction preserves normalized and starred balances",
          "[c30][math][property][identities][mass-defect]") {
  auto bundle = mwperf::testing::c30::exact_bundle(
      mwperf::ObservationSourceRoleV1::weighted_ensemble);
  auto& block = bundle.replications.front().blocks.front();
  block.levels.back().exposure_mass = mwperf::testing::c30::scalar(1);
  block.exposure_mass_balance = {
      mwperf::ObservationNormalizationClaimV1::not_claimed,
      mwperf::testing::c30::scalar(3),
      mwperf::testing::c30::scalar(-1)};

  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);

  CHECK(exact_value(analysis.value().pooled.mass_per_slot) ==
        mwperf::testing::c30::rational(3, 4));
  CHECK(exact_value(analysis.value().pooled.signed_mass_defect) ==
        mwperf::testing::c30::rational(-1, 4));
  CHECK(exact_value(analysis.value().pooled.observed_mean) ==
        mwperf::testing::c30::rational(1));
  CHECK(exact_value(analysis.value().finite_window.starred_balance_residual) ==
        mwperf::testing::c30::rational(3, 8));
  CHECK(exact_value(analysis.value()
                        .finite_window
                        .mass_defect_corrected_balance_residual) ==
        mwperf::testing::c30::rational(9, 16));
  CHECK(exact_value(analysis.value().finite_window.moment_identity_closure)
            .is_zero());
}

TEST_CASE("C30 batch-arrival overshoot is retained in the hinge account",
          "[c30][math][property][identities][batch-arrival]") {
  auto bundle = mwperf::testing::c30::exact_bundle();
  bundle.bindings.arrival.target_arrival =
      mwperf::ExactTargetArrivalMarginalV1{
          {{mwperf::BigNat{0U}, mwperf::testing::c30::rational(1, 2)},
           {mwperf::BigNat{2U}, mwperf::testing::c30::rational(1, 2)}}};
  bundle.bindings.arrival.mean = mwperf::testing::c30::rational(1);
  bundle.bindings.arrival.second_moment =
      mwperf::testing::c30::rational(2);

  auto validated = mwperf::validate_construction_observation_envelope_v1(
      mwperf::testing::c30::envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().finite_window.cutoffs.size() == 1U);
  const auto& hinge = analysis.value().finite_window.cutoffs.front();
  CHECK(exact_value(hinge.hinge_endpoint_drift).is_zero());
  CHECK(exact_value(hinge.tail_probability_per_slot) ==
        mwperf::testing::c30::rational(1, 2));
  CHECK(exact_value(hinge.overshoot_reward_normalized) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(hinge.overshoot_reward_per_slot) ==
        mwperf::testing::c30::rational(1, 4));
  CHECK(exact_value(hinge.innovation) ==
        mwperf::testing::c30::rational(-1, 2));
  CHECK(exact_value(hinge.realized_identity_closure).is_zero());
}
