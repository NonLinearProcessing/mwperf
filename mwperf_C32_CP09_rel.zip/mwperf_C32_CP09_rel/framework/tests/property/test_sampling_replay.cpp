#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <future>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "mwperf/sampling/estimators.hpp"
#include "sampling/c24_internal.hpp"

namespace {

namespace temporal = mwperf::testing::c17_temporal;
namespace matrix = mwperf::testing::c16_registered_pair_matrix;
namespace c17 = mwperf::testing::c17;

[[nodiscard]] mwperf::Digest256 zero_digest() {
  const std::array<std::byte, mwperf::Digest256::kSize> bytes{};
  return mwperf::Digest256::from_bytes(bytes).value();
}

struct ReplaySamplerFixture final {
  mwperf::AuditedCompiledFramework framework;
  mwperf::NormalizedSamplerAccess sampler;
  mwperf::ConditioningState row;
  std::vector<mwperf::QueueId> ordered_targets;
  std::shared_ptr<std::atomic<unsigned>> calls;
};

[[nodiscard]] mwperf::KernelTransitionV1 replay_atom(
    const mwperf::ConditioningState& state, const std::byte value) {
  const mwperf::CodecIdentityV1 mark_codec{"mwperf.c23.typed_label", 1U};
  return {state,
          {{mark_codec, {value}},
           {mark_codec, {value}},
           {mark_codec, {value}}}};
}

[[nodiscard]] std::uint8_t first_mark_value(
    const mwperf::Sample& sample) {
  REQUIRE_FALSE(sample.ordered_marks.empty());
  REQUIRE_FALSE(sample.ordered_marks.front().canonical_value.empty());
  return std::to_integer<std::uint8_t>(
      sample.ordered_marks.front().canonical_value.front());
}

[[nodiscard]] std::uint8_t mark_value(const mwperf::Sample& sample,
                                      const std::size_t index) {
  REQUIRE(index < sample.ordered_marks.size());
  REQUIRE_FALSE(sample.ordered_marks[index].canonical_value.empty());
  return std::to_integer<std::uint8_t>(
      sample.ordered_marks[index].canonical_value.front());
}

[[nodiscard]] mwperf::KernelTransitionV1 pair_atom(
    const mwperf::ConditioningState& state, const std::uint8_t residual,
    const std::uint8_t innovation) {
  const mwperf::CodecIdentityV1 mark_codec{"mwperf.c23.typed_label", 1U};
  return {state,
          {{mark_codec, {static_cast<std::byte>(residual)}},
           {mark_codec, {static_cast<std::byte>(innovation)}},
           {mark_codec, {static_cast<std::byte>(innovation)}}}};
}

[[nodiscard]] ReplaySamplerFixture seal_replay_sampler(
    const std::uint64_t replications,
    const mwperf::StatisticalIntervalKindV1 interval,
    const mwperf::BackendRouteKindV1 accepted_backend_route =
        mwperf::BackendRouteKindV1::conditional_row_monte_carlo) {
  auto calls = std::make_shared<std::atomic<unsigned>>(0U);
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls = calls;
  override.conditional_sampler_contract =
      mwperf::ConditionalSamplerContractV1{
          1U,
          mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
          mwperf::ConditionalSampleDependenceV1::iid_cold_replications,
          mwperf::ConditionalSupportKindV1::finite_declared,
          2U,
          matrix::digest("c17.fixture.reduced-state-schema"),
          matrix::digest("c24.property.replay.support"),
          matrix::digest("c24.property.replay.proposal"),
          matrix::digest("c24.property.replay.residual"),
          matrix::digest("c24.property.replay.output"),
          matrix::digest("c24.property.replay.configured-arrival"),
          matrix::digest("c24.property.replay.common-projection"),
          true,
          true,
          true,
          true,
          true,
          mwperf::SamplerEvidenceScopeV1::construction_enforced,
          mwperf::SamplerEvidenceScopeV1::independently_audited,
          mwperf::SamplerV1EvidenceScopeV1::row_conditional,
          matrix::digest("c24.property.replay.v1-evidence"),
          mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
          matrix::digest("c24.property.replay.v2-evidence"),
          matrix::digest("c24.property.replay.foreign-evidence"),
          mwperf::RuntimeSamplingProvenanceV1::physical_trace};
  override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        const std::byte value = (rng.next_u64() & 1U) == 0U
                                    ? std::byte{0x00}
                                    : std::byte{0x01};
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            replay_atom(state, value));
      };
  override.conditional_support_enumerator =
      [](const mwperf::CanonicalRuntimeValueV1& state) {
        return mwperf::Result<std::vector<mwperf::KernelTransitionV1>>::
            success({replay_atom(state, std::byte{0x00}),
                     replay_atom(state, std::byte{0x01})});
      };
  override.conditional_support_query =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         const mwperf::KernelTransitionV1& sample) {
        return mwperf::Result<bool>::success(
            sample == replay_atom(state, std::byte{0x00}) ||
            sample == replay_atom(state, std::byte{0x01}));
      };

  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, replications, interval, accepted_backend_route,
      [](mwperf::ExactCausalProgramV1&) {});
  const mwperf::ConditioningState row = prepared.initial_state;
  auto ordered_targets = prepared.ordered_targets;
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((sealed ? std::string{}
               : sealed.error().code + ": " + sealed.error().message));
  REQUIRE(sealed);
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  auto framework = std::move(sealed).value();
  auto descriptor = mwperf::audited_sampler_descriptor(framework);
  REQUIRE(descriptor);
  auto sampler = mwperf::validate_conditional_generator(descriptor.value());
  INFO((sampler ? std::string{}
                : sampler.error().code + ": " + sampler.error().message));
  REQUIRE(sampler);
  CHECK(calls->load(std::memory_order_relaxed) == 0U);
  return {std::move(framework), std::move(sampler).value(), row,
          std::move(ordered_targets), std::move(calls)};
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                              const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] bool close(const long double left, const long double right,
                         const long double tolerance = 1.0e-12L) {
  return std::fabs(left - right) <= tolerance;
}

[[nodiscard]] mwperf::ConditionalSamplerContractV1 property_contract(
    const std::string_view prefix, const std::size_t support_size,
    const mwperf::ConditionalSampleDependenceV1 dependence) {
  const auto keyed = [prefix](const std::string_view suffix) {
    return matrix::digest(std::string(prefix) + "." + std::string(suffix));
  };
  return {1U,
          mwperf::ConditionalSamplerRevealStageV1::generic_row_residual,
          dependence,
          mwperf::ConditionalSupportKindV1::finite_declared,
          support_size,
          matrix::digest("c17.fixture.reduced-state-schema"),
          keyed("support"),
          keyed("proposal"),
          keyed("residual"),
          keyed("output"),
          keyed("arrival"),
          keyed("common"),
          true,
          true,
          true,
          true,
          true,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerEvidenceScopeV1::declared,
          mwperf::SamplerV1EvidenceScopeV1::none,
          std::nullopt,
          mwperf::SamplerV2EvidenceScopeV1::none,
          std::nullopt,
          std::nullopt};
}

[[nodiscard]] matrix::C17TemporalFixtureOverrideV1 finite_atom_override(
    const std::string_view prefix, const std::size_t support_size,
    const mwperf::ConditionalSampleDependenceV1 dependence) {
  matrix::C17TemporalFixtureOverrideV1 override;
  override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  override.conditional_sampler_contract =
      property_contract(prefix, support_size, dependence);
  override.conditional_sampler_operation =
      [support_size](const mwperf::CanonicalRuntimeValueV1& state,
                     mwperf::DeterministicRng& rng) {
        const auto selected = static_cast<std::uint8_t>(
            rng.next_u64() % static_cast<std::uint64_t>(support_size));
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            replay_atom(state, static_cast<std::byte>(selected)));
      };
  override.conditional_support_enumerator =
      [support_size](const mwperf::CanonicalRuntimeValueV1& state) {
        std::vector<mwperf::KernelTransitionV1> support;
        support.reserve(support_size);
        for (std::size_t index = 0U; index < support_size; ++index) {
          support.push_back(replay_atom(
              state, static_cast<std::byte>(index)));
        }
        return mwperf::Result<
            std::vector<mwperf::KernelTransitionV1>>::success(
            std::move(support));
      };
  override.conditional_support_query =
      [support_size](const mwperf::CanonicalRuntimeValueV1& state,
                     const mwperf::KernelTransitionV1& sample) {
        const bool shaped = sample.successor_state == state &&
                            sample.ordered_marks.size() == 3U &&
                            !sample.ordered_marks.front()
                                 .canonical_value.empty();
        return mwperf::Result<bool>::success(
            shaped && first_mark_value(sample) < support_size);
      };
  return override;
}

struct PropertySamplerFixture final {
  mwperf::AuditedCompiledFramework framework;
  mwperf::NormalizedSamplerAccess sampler;
  mwperf::ConditioningState row;
};

[[nodiscard]] PropertySamplerFixture seal_property_sampler(
    const matrix::C17TemporalFixtureOverrideV1& override,
    const std::uint64_t replications,
    const mwperf::StatisticalIntervalKindV1 interval) {
  const matrix::ScopedC17TemporalFixtureOverride guard(override);
  const auto& profile = temporal::temporal_profile(
      mwperf::SemanticTagV1::temporal_one_slot_continuation);
  auto prepared = temporal::prepare_conditional_sampling_framework(
      profile, replications, interval,
      [](mwperf::ExactCausalProgramV1&) {});
  auto row = prepared.initial_state;
  auto sealed = mwperf::audit_v0_causality(
      std::move(prepared.candidate), prepared.descriptor,
      std::move(prepared.access));
  INFO((sealed ? std::string{}
               : sealed.error().code + ": " + sealed.error().message));
  REQUIRE(sealed);
  auto framework = std::move(sealed).value();
  auto descriptor = mwperf::audited_sampler_descriptor(framework);
  REQUIRE(descriptor);
  auto sampler = mwperf::validate_conditional_generator(descriptor.value());
  INFO((sampler ? std::string{}
                : sampler.error().code + ": " + sampler.error().message));
  REQUIRE(sampler);
  return {std::move(framework), std::move(sampler).value(), std::move(row)};
}

using PropertyRewardFunction = std::function<mwperf::Result<long double>(
    const mwperf::ConditioningState&, const mwperf::Sample&)>;

[[nodiscard]] mwperf::RewardDecoder property_reward(
    const std::string_view id, const mwperf::Digest256& decoder_digest,
    const mwperf::Digest256& target, const mwperf::Digest256& output_schema,
    PropertyRewardFunction decode, const bool binary = false,
    std::optional<mwperf::ExactRational> lower = std::nullopt,
    std::optional<mwperf::ExactRational> upper = std::nullopt) {
  auto conditional =
      std::make_shared<const mwperf::ConditionalSamplingRewardV1>(
          mwperf::ConditionalSamplingRewardV1{
              std::string(id), decoder_digest, target, output_schema,
              mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
              binary, std::move(lower), std::move(upper),
              std::move(decode), true});
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          {},
          {"c24.property.reward.scalar", 1U},
          std::move(conditional)};
}

[[nodiscard]] mwperf::SamplingPlan property_plan(
    const mwperf::NormalizedSamplerAccess& sampler,
    const std::uint64_t seed, std::string estimator_id,
    const mwperf::Digest256& target, const std::uint64_t replications,
    const mwperf::StatisticalIntervalKindV1 interval =
        mwperf::StatisticalIntervalKindV1::none,
    const mwperf::StatisticalEstimandKindV1 estimand =
        mwperf::StatisticalEstimandKindV1::
            point_with_variance_diagnostics,
    std::optional<mwperf::ExactRational> lower = std::nullopt,
    std::optional<mwperf::ExactRational> upper = std::nullopt,
    const mwperf::StageTag stage = mwperf::StageTag::generic_sampling,
    const bool rao_blackwell = false,
    std::optional<mwperf::TotalVariationRequestV1> tv = std::nullopt) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  REQUIRE(target == sampler.accepted_sampling_clauses()
                        .front()
                        .metric_target_digest);
  if (!lower.has_value() && !upper.has_value()) {
    lower = mwperf::ExactRational::zero();
    upper = mwperf::ExactRational::one();
  }
  auto plan = mwperf::SamplingPlan::from_accepted_clause(
      sampler,
      mwperf::SamplingPlanSpecV1{
          {mwperf::BigNat{replications}, rational(19, 20), interval,
           estimand, std::move(lower), std::move(upper)},
          mwperf::MasterSeed{seed}, std::move(estimator_id),
          sampler.accepted_sampling_clauses().front().metric_target_digest,
          mwperf::BigNat{replications}, stage, true, rao_blackwell,
          std::move(tv)});
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  return std::move(plan).value();
}

void attach_property_ratio(
    matrix::C17TemporalFixtureOverrideV1& override,
    const mwperf::Digest256& target,
    const mwperf::Digest256& decoder_digest,
    mwperf::ConditionalTargetRatioCallbackV1 operation) {
  (void)target;
  REQUIRE(override.conditional_sampler_contract.has_value());
  const auto& sampler = *override.conditional_sampler_contract;
  override.target_ratio_contract = mwperf::ConditionalTargetRatioContractV1{
      1U,
      mwperf::ImportanceTargetKindV1::transition_row,
      matrix::digest("c24.property.permutation.target-law"),
      zero_digest(),
      decoder_digest,
      sampler.residual_schema,
      sampler.output_schema,
      true,
      true,
      true,
      true,
      true,
      true};
  override.target_ratio_operation = std::move(operation);
}

void attach_property_innovation(
    matrix::C17TemporalFixtureOverrideV1& override,
    const mwperf::Digest256& decoder_digest,
    mwperf::ConditionalExactInnovationCallbackV1 operation) {
  REQUIRE(override.conditional_sampler_contract.has_value());
  const auto& sampler = *override.conditional_sampler_contract;
  override.exact_innovation_contract =
      mwperf::ConditionalExactInnovationContractV1{
          1U,
          matrix::digest("c24.property.affine.innovation"),
          zero_digest(),
          sampler.configured_arrival_law,
          decoder_digest,
          sampler.residual_schema,
          sampler.output_schema,
          true,
          mwperf::ExactRational::zero()};
  override.exact_innovation_operation = std::move(operation);
}

[[nodiscard]] mwperf::SamplingPlan replay_plan(
    const mwperf::NormalizedSamplerAccess& sampler,
    const std::uint64_t seed, const std::string_view estimator_id,
    const std::uint64_t replications = 64U,
    const mwperf::StageTag stage = mwperf::StageTag::generic_sampling) {
  REQUIRE(sampler.accepted_sampling_clauses().size() == 1U);
  auto plan = mwperf::SamplingPlan::from_accepted_clause(
      sampler,
      mwperf::SamplingPlanSpecV1{
          {mwperf::BigNat{replications}, rational(19, 20),
           mwperf::StatisticalIntervalKindV1::none,
           mwperf::StatisticalEstimandKindV1::
               point_with_variance_diagnostics,
           mwperf::ExactRational::zero(), mwperf::ExactRational::one()},
          mwperf::MasterSeed{seed}, std::string(estimator_id),
          sampler.accepted_sampling_clauses().front().metric_target_digest,
          mwperf::BigNat{replications}, stage, true, false, std::nullopt});
  INFO((plan ? std::string{}
             : plan.error().code + ": " + plan.error().message));
  REQUIRE(plan);
  return std::move(plan).value();
}

void check_same_row(const mwperf::EmpiricalRow& left,
                    const mwperf::EmpiricalRow& right) {
  REQUIRE(left.total() == right.total());
  REQUIRE(left.iid_replications() == right.iid_replications());
  REQUIRE(left.seal_digest() == right.seal_digest());
  REQUIRE(left.conditioning_row_digest() ==
          right.conditioning_row_digest());
  REQUIRE(left.plan_digest() == right.plan_digest());
  REQUIRE(left.metric_target_digest() == right.metric_target_digest());
  REQUIRE(left.sampling_evidence() == right.sampling_evidence());
  REQUIRE(left.costs() == right.costs());
  REQUIRE(left.advertised_tv_failure_bound() ==
          right.advertised_tv_failure_bound());
  REQUIRE(left.failed_draws() == right.failed_draws());
  REQUIRE(left.atoms().size() == right.atoms().size());
  for (std::size_t index = 0U; index < left.atoms().size(); ++index) {
    CHECK(left.atoms()[index].sample == right.atoms()[index].sample);
    CHECK(left.atoms()[index].count == right.atoms()[index].count);
    CHECK(left.atoms()[index].probability ==
          right.atoms()[index].probability);
  }
}

void check_normalized_count_row(const mwperf::EmpiricalRow& row) {
  mwperf::BigNat count_sum{0U};
  mwperf::ExactRational probability_sum = mwperf::ExactRational::zero();
  REQUIRE(row.atoms().size() == 2U);
  for (const auto& atom : row.atoms()) {
    count_sum += atom.count;
    probability_sum = probability_sum + atom.probability;
    CHECK(atom.probability.is_nonnegative());
  }
  CHECK(count_sum == row.total());
  CHECK(probability_sum == mwperf::ExactRational::one());
  CHECK(row.failed_draws() == 0U);
  CHECK(row.costs().draws == row.total());
  CHECK(row.costs().failed_draws == mwperf::BigNat{0U});
  CHECK(row.costs().exact_innovation_atoms == mwperf::BigNat{0U});
  CHECK(row.costs().optimizer_probes == mwperf::BigNat{0U});
  CHECK(row.iid_replications());
}

struct AddressedPartitionResult final {
  std::vector<std::pair<std::size_t, mwperf::Sample>> indexed_samples;
  std::string error;
};

struct AddressedSequenceResult final {
  std::vector<mwperf::Sample> samples;
  std::string error;
};

[[nodiscard]] AddressedPartitionResult draw_address_partition(
    const mwperf::NormalizedSamplerAccess& sampler,
    const mwperf::ConditioningState& row,
    const mwperf::Digest256& row_digest, const std::uint64_t seed,
    const std::string_view estimator_id,
    const std::vector<std::size_t>& replication_indices) {
  AddressedPartitionResult result;
  result.indexed_samples.reserve(replication_indices.size());
  for (const std::size_t index : replication_indices) {
    auto bank = mwperf::sampling::detail::C24RngAccess::make(
        sampler.seal_digest(), row_digest, estimator_id,
        mwperf::BigNat{static_cast<std::uint64_t>(index)},
        mwperf::MasterSeed{seed}, mwperf::StageTag::generic_sampling);
    if (!bank) {
      result.error = bank.error().code + ": " + bank.error().message;
      return result;
    }
    auto sample = mwperf::draw_conditional_sample(sampler, row, bank.value());
    if (!sample) {
      result.error = sample.error().code + ": " + sample.error().message;
      return result;
    }
    result.indexed_samples.emplace_back(index, std::move(sample).value());
  }
  return result;
}

[[nodiscard]] AddressedSequenceResult draw_partitioned_sequence(
    const mwperf::NormalizedSamplerAccess& sampler,
    const mwperf::ConditioningState& row, const std::uint64_t seed,
    const std::string_view estimator_id,
    const std::vector<std::vector<std::size_t>>& partitions,
    const bool parallel) {
  auto row_digest =
      mwperf::sampling::detail::conditioning_state_digest(row);
  if (!row_digest) {
    return {{}, row_digest.error().code + ": " + row_digest.error().message};
  }

  std::vector<AddressedPartitionResult> completed;
  completed.reserve(partitions.size());
  if (parallel) {
    std::vector<std::future<AddressedPartitionResult>> futures;
    futures.reserve(partitions.size());
    for (const auto& partition : partitions) {
      futures.push_back(std::async(
          std::launch::async,
          [sampler, row, digest = row_digest.value(), seed,
           estimator_id = std::string(estimator_id), partition]() {
            return draw_address_partition(sampler, row, digest, seed,
                                          estimator_id, partition);
          }));
    }
    for (auto& future : futures) completed.push_back(future.get());
  } else {
    for (const auto& partition : partitions) {
      completed.push_back(draw_address_partition(
          sampler, row, row_digest.value(), seed, estimator_id, partition));
    }
  }

  std::size_t replication_count = 0U;
  for (const auto& partition : partitions) {
    replication_count += partition.size();
  }
  std::vector<std::optional<mwperf::Sample>> indexed(replication_count);
  for (auto& partition : completed) {
    if (!partition.error.empty()) return {{}, std::move(partition.error)};
    for (auto& [index, sample] : partition.indexed_samples) {
      if (index >= indexed.size() || indexed[index].has_value()) {
        return {{}, "duplicate or out-of-range replication address"};
      }
      indexed[index].emplace(std::move(sample));
    }
  }

  AddressedSequenceResult result;
  result.samples.reserve(replication_count);
  for (auto& sample : indexed) {
    if (!sample.has_value()) {
      return {{}, "the batch partition omitted a replication address"};
    }
    result.samples.push_back(std::move(*sample));
  }
  return result;
}

[[nodiscard]] std::vector<std::vector<std::size_t>> contiguous_partitions(
    const std::size_t replication_count,
    const std::vector<std::size_t>& authored_sizes) {
  std::vector<std::vector<std::size_t>> result;
  std::size_t next = 0U;
  for (const std::size_t authored : authored_sizes) {
    const std::size_t size = std::min(authored, replication_count - next);
    std::vector<std::size_t> partition;
    partition.reserve(size);
    for (std::size_t offset = 0U; offset < size; ++offset) {
      partition.push_back(next++);
    }
    result.push_back(std::move(partition));
    if (next == replication_count) break;
  }
  if (next < replication_count) {
    std::vector<std::size_t> tail;
    tail.reserve(replication_count - next);
    while (next < replication_count) tail.push_back(next++);
    result.push_back(std::move(tail));
  }
  return result;
}

[[nodiscard]] std::vector<std::vector<std::size_t>> strided_partitions(
    const std::size_t replication_count, const std::size_t workers) {
  std::vector<std::vector<std::size_t>> result(workers);
  for (std::size_t index = 0U; index < replication_count; ++index) {
    result[index % workers].push_back(index);
  }
  return result;
}

[[nodiscard]] std::uint64_t splitmix64(std::uint64_t& state) noexcept {
  state += UINT64_C(0x9e3779b97f4a7c15);
  std::uint64_t value = state;
  value = (value ^ (value >> 30U)) * UINT64_C(0xbf58476d1ce4e5b9);
  value = (value ^ (value >> 27U)) * UINT64_C(0x94d049bb133111eb);
  return value ^ (value >> 31U);
}

}  // namespace

TEST_CASE("C24 empirical rows replay for varied seeds and conditioning states",
          "[c24][property][replay][address]") {
  auto fixture = seal_replay_sampler(
      64U, mwperf::StatisticalIntervalKindV1::none);
  REQUIRE(fixture.sampler.contract().v1_evidence_reference.has_value());
  REQUIRE(fixture.sampler.contract().v2_evidence_reference.has_value());
  REQUIRE(
      fixture.sampler.contract().foreign_construction_evidence.has_value());
  CHECK(*fixture.sampler.contract().v1_evidence_reference ==
        matrix::digest("c24.property.replay.v1-evidence"));
  CHECK(*fixture.sampler.contract().v2_evidence_reference ==
        matrix::digest("c24.property.replay.v2-evidence"));
  CHECK(*fixture.sampler.contract().foreign_construction_evidence ==
        matrix::digest("c24.property.replay.foreign-evidence"));
  CHECK(fixture.sampler.contract().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::physical_trace);
  const mwperf::SamplingEvidenceSnapshotV1 expected_evidence{
      mwperf::RuntimeSamplingProvenanceV1::physical_trace,
      mwperf::SamplerEvidenceScopeV1::construction_enforced,
      mwperf::SamplerEvidenceScopeV1::independently_audited,
      mwperf::SamplerV1EvidenceScopeV1::row_conditional,
      matrix::digest("c24.property.replay.v1-evidence"),
      mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
      matrix::digest("c24.property.replay.v2-evidence"),
      matrix::digest("c24.property.replay.foreign-evidence")};
  const std::array<std::uint64_t, 4U> seeds{
      0U, 1U, UINT64_C(0xC240301), UINT64_C(0xffffffffffffffff)};
  const std::array<mwperf::ConditioningState, 4U> states{
      c17::reduced_state(fixture.ordered_targets, {0U}),
      c17::reduced_state(fixture.ordered_targets, {1U}),
      c17::reduced_state(fixture.ordered_targets, {2U}, true, 1U),
      c17::reduced_state(fixture.ordered_targets, {3U}, false, 7U)};

  for (const std::uint64_t seed : seeds) {
    const auto plan = replay_plan(
        fixture.sampler, seed, "c24.property.seed-state");
    for (const auto& row : states) {
      auto first = mwperf::estimate_discrete_kernel_row(
          fixture.sampler, row, plan);
      auto replay = mwperf::estimate_discrete_kernel_row(
          fixture.sampler, row, plan);
      REQUIRE(first);
      REQUIRE(replay);
      CHECK(first.value().sampling_evidence() == expected_evidence);
      CHECK(replay.value().sampling_evidence() == expected_evidence);
      check_same_row(first.value(), replay.value());
      check_normalized_count_row(first.value());
      for (const auto& atom : first.value().atoms()) {
        CHECK(atom.sample.successor_state == row);
      }
    }
  }
  const auto expected_calls = static_cast<unsigned>(
      seeds.size() * states.size() * 2U * 64U);
  CHECK(fixture.calls->load(std::memory_order_relaxed) == expected_calls);
}

TEST_CASE("C24 addressed replay is invariant to row order and thread schedule",
          "[c24][property][replay][ordering][threads]") {
  auto fixture = seal_replay_sampler(
      97U, mwperf::StatisticalIntervalKindV1::none);
  const mwperf::SamplingEvidenceSnapshotV1 expected_evidence{
      mwperf::RuntimeSamplingProvenanceV1::physical_trace,
      mwperf::SamplerEvidenceScopeV1::construction_enforced,
      mwperf::SamplerEvidenceScopeV1::independently_audited,
      mwperf::SamplerV1EvidenceScopeV1::row_conditional,
      matrix::digest("c24.property.replay.v1-evidence"),
      mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
      matrix::digest("c24.property.replay.v2-evidence"),
      matrix::digest("c24.property.replay.foreign-evidence")};
  const auto plan = replay_plan(
      fixture.sampler, UINT64_C(0xC240302), "c24.property.order", 97U,
      mwperf::StageTag::generic_sampling);
  const mwperf::ConditioningState first_row =
      c17::reduced_state(fixture.ordered_targets, {4U}, false, 2U);
  const mwperf::ConditioningState second_row =
      c17::reduced_state(fixture.ordered_targets, {5U}, true, 3U);

  auto first_then = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, first_row, plan);
  auto second_then = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, second_row, plan);
  auto second_again = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, second_row, plan);
  auto first_again = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, first_row, plan);
  REQUIRE(first_then);
  REQUIRE(second_then);
  REQUIRE(second_again);
  REQUIRE(first_again);
  CHECK(first_then.value().sampling_evidence() == expected_evidence);
  CHECK(second_then.value().sampling_evidence() == expected_evidence);
  CHECK(second_again.value().sampling_evidence() == expected_evidence);
  CHECK(first_again.value().sampling_evidence() == expected_evidence);
  check_same_row(first_then.value(), first_again.value());
  check_same_row(second_then.value(), second_again.value());

  const auto other_plan = replay_plan(
      fixture.sampler, UINT64_C(0xC240302),
      "c24.property.other-estimator", 97U,
      mwperf::StageTag::generic_sampling);
  CHECK(other_plan.plan_digest() != plan.plan_digest());
  auto other_before = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, first_row, other_plan);
  auto other_after = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, first_row, other_plan);
  REQUIRE(other_before);
  REQUIRE(other_after);
  check_same_row(other_before.value(), other_after.value());

  // Independent calls own fresh addressed banks. Scheduling them on separate
  // workers therefore cannot introduce a shared cursor or warm sampler state.
  const auto sampler_copy = fixture.sampler;
  const auto plan_copy = plan;
  auto first_future = std::async(
      std::launch::async, [sampler_copy, first_row, plan_copy]() {
        return mwperf::estimate_discrete_kernel_row(
            sampler_copy, first_row, plan_copy);
      });
  auto second_future = std::async(
      std::launch::async, [sampler_copy, second_row, plan_copy]() {
        return mwperf::estimate_discrete_kernel_row(
            sampler_copy, second_row, plan_copy);
      });
  auto first_parallel = first_future.get();
  auto second_parallel = second_future.get();
  REQUIRE(first_parallel);
  REQUIRE(second_parallel);
  check_same_row(first_then.value(), first_parallel.value());
  check_same_row(second_then.value(), second_parallel.value());
  CHECK(fixture.calls->load(std::memory_order_relaxed) == 8U * 97U);
}

TEST_CASE("C24 addressed banks are identical across random rows batch partitions and worker counts",
          "[c24][property][replay][batching][threads]") {
  constexpr std::size_t kCases = 12U;
  constexpr std::size_t kReplications = 37U;
  constexpr std::string_view kEstimator =
      "c24.property.partition-invariance";
  auto fixture = seal_replay_sampler(
      kReplications, mwperf::StatisticalIntervalKindV1::none);
  std::uint64_t generator_state = UINT64_C(0xc2403b47f21d9e65);

  const auto one_batch = contiguous_partitions(kReplications, {kReplications});
  const auto singleton_batches = contiguous_partitions(
      kReplications, std::vector<std::size_t>(kReplications, 1U));
  const auto uneven_batches =
      contiguous_partitions(kReplications, {1U, 7U, 3U, 11U, 2U});

  for (std::size_t property_case = 0U; property_case < kCases;
       ++property_case) {
    const std::uint64_t seed = splitmix64(generator_state);
    const auto backlog = static_cast<std::uint8_t>(
        splitmix64(generator_state) % 17U);
    const bool boundary_flag = (splitmix64(generator_state) & 1U) != 0U;
    const auto boundary_value = static_cast<std::uint8_t>(
        splitmix64(generator_state) % 8U);
    const auto row = c17::reduced_state(
        fixture.ordered_targets, {backlog}, boundary_flag, boundary_value);

    const auto baseline = draw_partitioned_sequence(
        fixture.sampler, row, seed, kEstimator, one_batch, false);
    INFO(baseline.error);
    REQUIRE(baseline.error.empty());
    REQUIRE(baseline.samples.size() == kReplications);

    const auto singleton = draw_partitioned_sequence(
        fixture.sampler, row, seed, kEstimator, singleton_batches, false);
    INFO(singleton.error);
    REQUIRE(singleton.error.empty());
    CHECK(singleton.samples == baseline.samples);

    const auto uneven = draw_partitioned_sequence(
        fixture.sampler, row, seed, kEstimator, uneven_batches, false);
    INFO(uneven.error);
    REQUIRE(uneven.error.empty());
    CHECK(uneven.samples == baseline.samples);

    for (const std::size_t workers : {1U, 2U, 4U}) {
      const auto threaded = draw_partitioned_sequence(
          fixture.sampler, row, seed, kEstimator,
          strided_partitions(kReplications, workers), workers != 1U);
      INFO("workers=" << workers << ", error=" << threaded.error);
      REQUIRE(threaded.error.empty());
      CHECK(threaded.samples == baseline.samples);
    }

    // The public estimator must perform the same canonical index-order
    // reduction as every explicitly partitioned addressed bank above.
    const auto plan = replay_plan(fixture.sampler, seed, kEstimator,
                                  kReplications);
    const auto row_estimate = mwperf::estimate_discrete_kernel_row(
        fixture.sampler, row, plan);
    REQUIRE(row_estimate);
    std::array<std::uint64_t, 2U> expected_counts{};
    for (const auto& sample : baseline.samples) {
      const auto value = first_mark_value(sample);
      REQUIRE(value < expected_counts.size());
      ++expected_counts[value];
    }
    REQUIRE(row_estimate.value().atoms().size() == expected_counts.size());
    for (const auto& atom : row_estimate.value().atoms()) {
      const auto value = first_mark_value(atom.sample);
      REQUIRE(value < expected_counts.size());
      CHECK(atom.count == mwperf::BigNat{expected_counts[value]});
    }
  }

  CHECK(fixture.calls->load(std::memory_order_relaxed) ==
        kCases * 7U * kReplications);
}

TEST_CASE("C24 retains declared but unseen finite-support atoms",
          "[c24][property][counts][support]") {
  auto fixture = seal_replay_sampler(
      1U, mwperf::StatisticalIntervalKindV1::none);
  const auto plan = replay_plan(
      fixture.sampler, UINT64_C(0xC240303),
      "c24.property.unseen-support", 1U);
  auto row = mwperf::estimate_discrete_kernel_row(
      fixture.sampler, fixture.row, plan);
  REQUIRE(row);
  check_normalized_count_row(row.value());
  REQUIRE(row.value().atoms().size() == 2U);
  const bool first_unseen = row.value().atoms()[0U].count.is_zero();
  const bool second_unseen = row.value().atoms()[1U].count.is_zero();
  CHECK(first_unseen != second_unseen);
  CHECK(row.value().atoms()[0U].probability.is_zero() == first_unseen);
  CHECK(row.value().atoms()[1U].probability.is_zero() == second_unseen);
  CHECK(fixture.calls->load(std::memory_order_relaxed) == 1U);
}

TEST_CASE("C24 Hoeffding and TV guarantees are conservative across addressed seeds",
          "[c24][property][coverage][hoeffding][tv]") {
  // This deterministic many-seed check is a regression sanity test for the
  // advertised procedures.  It is deliberately not treated as a proof of
  // coverage or as a replacement for their finite-sample inequalities.
  constexpr std::size_t kTrials = 256U;
  constexpr std::uint64_t kHoeffdingReplications = 32U;
  constexpr std::uint64_t kTvReplications = 98U;
  constexpr long double kAlpha = 0.05L;
  constexpr long double kTvEpsilon = 0.15L;
  constexpr std::size_t kSanityCeiling =
      static_cast<std::size_t>(2.0L * kAlpha * kTrials) + 1U;

  auto hoeffding_fixture = seal_replay_sampler(
      kHoeffdingReplications,
      mwperf::StatisticalIntervalKindV1::hoeffding,
      mwperf::BackendRouteKindV1::conditional_reward_monte_carlo);
  auto tv_fixture = seal_replay_sampler(
      kTvReplications, mwperf::StatisticalIntervalKindV1::none);
  const mwperf::SamplingEvidenceSnapshotV1 expected_evidence{
      mwperf::RuntimeSamplingProvenanceV1::physical_trace,
      mwperf::SamplerEvidenceScopeV1::construction_enforced,
      mwperf::SamplerEvidenceScopeV1::independently_audited,
      mwperf::SamplerV1EvidenceScopeV1::row_conditional,
      matrix::digest("c24.property.replay.v1-evidence"),
      mwperf::SamplerV2EvidenceScopeV1::marked_path_dynamic_lift,
      matrix::digest("c24.property.replay.v2-evidence"),
      matrix::digest("c24.property.replay.foreign-evidence")};
  const auto target =
      hoeffding_fixture.sampler.accepted_sampling_clauses().front()
          .metric_target_digest;
  const auto decoder_digest =
      matrix::digest("c24.property.coverage.decoder");
  const auto reward = property_reward(
      "c24.property.coverage.binary", decoder_digest, target,
      hoeffding_fixture.sampler.contract().output_schema,
      [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        return mwperf::Result<long double>::success(
            static_cast<long double>(first_mark_value(sample)));
      },
      true, mwperf::ExactRational::zero(),
      mwperf::ExactRational::one());

  const auto tv_budget = mwperf::SamplingPlan::sufficient_iid_tv_budget(
      2U, kTvEpsilon, kAlpha);
  REQUIRE(tv_budget);
  REQUIRE(tv_budget.value() == mwperf::BigNat{kTvReplications});

  std::size_t hoeffding_failures = 0U;
  std::size_t tv_failures = 0U;
  for (std::uint64_t seed = 0U; seed < kTrials; ++seed) {
    const auto hoeffding_plan = property_plan(
        hoeffding_fixture.sampler, seed,
        "c24.property.coverage.hoeffding", target,
        kHoeffdingReplications,
        mwperf::StatisticalIntervalKindV1::hoeffding,
        mwperf::StatisticalEstimandKindV1::binary_proportion,
        mwperf::ExactRational::zero(), mwperf::ExactRational::one());
    const auto estimate = mwperf::estimate_reward_expectation(
        hoeffding_fixture.sampler, hoeffding_fixture.row, reward,
        hoeffding_plan);
    REQUIRE(estimate);
    CHECK(estimate.value().sampling_evidence() == expected_evidence);
    REQUIRE(estimate.value().interval().has_value());
    const auto& interval = *estimate.value().interval();
    CHECK(close(interval.confidence_level, 1.0L - kAlpha));
    if (0.5L < interval.lower || 0.5L > interval.upper) {
      ++hoeffding_failures;
    }

    const auto tv_target =
        tv_fixture.sampler.accepted_sampling_clauses().front()
            .metric_target_digest;
    const auto tv_plan = property_plan(
        tv_fixture.sampler, seed, "c24.property.coverage.tv", tv_target,
        kTvReplications,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::
            point_with_variance_diagnostics,
        std::nullopt, std::nullopt, mwperf::StageTag::generic_sampling,
        false,
        mwperf::TotalVariationRequestV1{kTvEpsilon, kAlpha, 1U});
    const auto row = mwperf::estimate_discrete_kernel_row(
        tv_fixture.sampler, tv_fixture.row, tv_plan);
    REQUIRE(row);
    CHECK(row.value().sampling_evidence() == expected_evidence);
    REQUIRE(row.value().total_variation_bound().has_value());
    CHECK(row.value().total_variation_bound()->advertised_failure_bound <=
          kAlpha);
    REQUIRE(row.value().atoms().size() == 2U);
    const long double probability_one =
        row.value().atoms()[0U].sample ==
                replay_atom(tv_fixture.row, std::byte{0x01})
            ? row.value().atoms()[0U].probability.to_long_double()
            : row.value().atoms()[1U].probability.to_long_double();
    if (std::fabs(probability_one - 0.5L) > kTvEpsilon) {
      ++tv_failures;
    }
  }

  INFO("Hoeffding exceedances: " << hoeffding_failures << "/" << kTrials);
  INFO("TV exceedances: " << tv_failures << "/" << kTrials);
  CHECK(hoeffding_failures <= kSanityCeiling);
  CHECK(tv_failures <= kSanityCeiling);
}

TEST_CASE("C24 raw and Rao-Blackwell estimators respect affine rewards",
          "[c24][property][reward][affine][rao-blackwell]") {
  SECTION("raw fixed-bank mean and variance transform") {
    // Three base atoms {0,1,2} and the decreasing affine image
    // 1-base/2 exercise a non-unit variance scale and endpoint reversal while
    // retaining the exact [0,1] reward envelope authored by the accepted C14
    // sampling clause.  Do not give the decoder range authority inconsistent
    // with the bound plan merely because this section requests no interval.
    constexpr long double kScale = -0.5L;
    constexpr long double kShift = 1.0L;
    constexpr std::uint64_t kReplications = 37U;
    auto target = matrix::digest("c24.property.affine.raw.target");
    const auto decoder_digest =
        matrix::digest("c24.property.affine.raw.decoder");
    auto override = finite_atom_override(
        "c24.property.affine.raw", 3U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
    auto fixture = seal_property_sampler(
        override, kReplications,
        mwperf::StatisticalIntervalKindV1::none);
    target = fixture.sampler.accepted_sampling_clauses().front()
                 .metric_target_digest;
    const auto reward = property_reward(
        "c24.property.affine.raw", decoder_digest, target,
        fixture.sampler.contract().output_schema,
        [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
          const long double base =
              static_cast<long double>(first_mark_value(sample));
          return mwperf::Result<long double>::success(
              kScale * base + kShift);
        },
        false, rational(0, 1), rational(1, 1));
    const auto plan = property_plan(
        fixture.sampler, UINT64_C(0xC240611),
        "c24.property.affine.raw", target,
        kReplications, mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::
            point_with_variance_diagnostics);
    const auto estimate = mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan);
    INFO((estimate ? std::string{}
                   : estimate.error().code + ": " +
                         estimate.error().message));
    REQUIRE(estimate);
    REQUIRE(estimate.value().has_empirical_residual());
    const auto samples = estimate.value().empirical_residual().samples();
    REQUIRE(samples.size() == kReplications);
    REQUIRE(estimate.value().raw_rewards().size() == samples.size());

    long double base_mean = 0.0L;
    for (std::size_t index = 0U; index < samples.size(); ++index) {
      const long double base =
          static_cast<long double>(first_mark_value(samples[index]));
      base_mean += base;
      CHECK(close(estimate.value().raw_rewards()[index],
                  kScale * base + kShift));
    }
    base_mean /= static_cast<long double>(samples.size());
    long double base_square_deviation = 0.0L;
    for (const auto& sample : samples) {
      const long double deviation =
          static_cast<long double>(first_mark_value(sample)) - base_mean;
      base_square_deviation += deviation * deviation;
    }
    const long double base_sample_variance =
        base_square_deviation /
        static_cast<long double>(samples.size() - 1U);
    CHECK(close(estimate.value().value(),
                kScale * base_mean + kShift));
    REQUIRE(estimate.value().sample_variance().has_value());
    CHECK(close(*estimate.value().sample_variance(),
                kScale * kScale * base_sample_variance));

    CHECK_FALSE(estimate.value().interval().has_value());
  }

  SECTION("exact innovation preserves affine moments and range metadata") {
    // The completed reward C+U has exact range [0,2].  Its decreasing affine
    // image 1-(C+U)/2 has exact range [0,1], so this case detects omission of
    // the scale and the endpoint reversal without widening the accepted C24
    // Hoeffding contract.
    constexpr long double kScale = -0.5L;
    constexpr long double kShift = 1.0L;
    constexpr long double kAffineLower = 0.0L;
    constexpr long double kAffineUpper = 1.0L;
    constexpr std::uint64_t kReplications = 41U;
    auto target = matrix::digest("c24.property.affine.rb.target");
    const auto decoder_digest =
        matrix::digest("c24.property.affine.rb.decoder");
    matrix::C17TemporalFixtureOverrideV1 override;
    override.conditional_sampler_calls =
        std::make_shared<std::atomic<unsigned>>(0U);
    override.conditional_sampler_contract = property_contract(
        "c24.property.affine.rb", 4U,
        mwperf::ConditionalSampleDependenceV1::iid_cold_replications);
    override.conditional_sampler_operation =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           mwperf::DeterministicRng& rng) {
          const std::uint64_t bits = rng.next_u64();
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              pair_atom(state, static_cast<std::uint8_t>(bits & 1U),
                        static_cast<std::uint8_t>((bits >> 1U) & 1U)));
        };
    override.conditional_support_enumerator =
        [](const mwperf::CanonicalRuntimeValueV1& state) {
          return mwperf::Result<
              std::vector<mwperf::KernelTransitionV1>>::success(
              {pair_atom(state, 0U, 0U), pair_atom(state, 0U, 1U),
               pair_atom(state, 1U, 0U), pair_atom(state, 1U, 1U)});
        };
    override.conditional_support_query =
        [](const mwperf::CanonicalRuntimeValueV1& state,
           const mwperf::KernelTransitionV1& sample) {
          const bool shaped = sample.successor_state == state &&
                              sample.ordered_marks.size() == 3U &&
                              !sample.ordered_marks[0U]
                                   .canonical_value.empty() &&
                              !sample.ordered_marks[1U]
                                   .canonical_value.empty();
          return mwperf::Result<bool>::success(
              shaped && mark_value(sample, 0U) < 2U &&
              mark_value(sample, 1U) < 2U);
        };
    const auto half = rational(1, 2);
    attach_property_innovation(
        override, decoder_digest,
        [half](const mwperf::CanonicalRuntimeValueV1& state,
               const mwperf::KernelTransitionV1& residual) {
          const std::uint8_t c = mark_value(residual, 0U);
          return mwperf::Result<
              std::vector<mwperf::ExactInnovationAtomV1>>::success(
              {{pair_atom(state, c, 0U), half},
               {pair_atom(state, c, 1U), half}});
        });
    auto fixture = seal_property_sampler(
        override, kReplications,
        mwperf::StatisticalIntervalKindV1::hoeffding);
    target = fixture.sampler.accepted_sampling_clauses().front()
                 .metric_target_digest;
    const auto reward = property_reward(
        "c24.property.affine.rb", decoder_digest, target,
        fixture.sampler.contract().output_schema,
        [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
          const long double base =
              static_cast<long double>(mark_value(sample, 0U) +
                                       mark_value(sample, 1U));
          return mwperf::Result<long double>::success(
              kScale * base + kShift);
        },
        false, rational(0, 1), rational(1, 1));
    const auto plan = property_plan(
        fixture.sampler, UINT64_C(0xC240612),
        "c24.property.affine.rb", target,
        kReplications, mwperf::StatisticalIntervalKindV1::hoeffding,
        mwperf::StatisticalEstimandKindV1::binary_proportion,
        rational(0, 1), rational(1, 1),
        mwperf::StageTag::generic_sampling, true);
    const auto estimate = mwperf::estimate_reward_expectation(
        fixture.sampler, fixture.row, reward, plan);
    REQUIRE(estimate);
    REQUIRE(estimate.value().has_empirical_residual());
    CHECK(estimate.value().claim_scope() ==
          mwperf::SamplingClaimScopeV1::rao_blackwell_row);
    const auto residuals = estimate.value().empirical_residual().samples();
    REQUIRE(residuals.size() == kReplications);
    REQUIRE(estimate.value().raw_rewards().size() == residuals.size());

    long double base_mean = 0.0L;
    for (std::size_t index = 0U; index < residuals.size(); ++index) {
      const long double conditional_base =
          static_cast<long double>(mark_value(residuals[index], 0U)) +
          0.5L;
      base_mean += conditional_base;
      CHECK(close(estimate.value().raw_rewards()[index],
                  kScale * conditional_base + kShift));
    }
    base_mean /= static_cast<long double>(residuals.size());
    long double base_square_deviation = 0.0L;
    for (const auto& residual : residuals) {
      const long double conditional_base =
          static_cast<long double>(mark_value(residual, 0U)) + 0.5L;
      const long double deviation = conditional_base - base_mean;
      base_square_deviation += deviation * deviation;
    }
    const long double base_sample_variance =
        base_square_deviation /
        static_cast<long double>(residuals.size() - 1U);
    CHECK(close(estimate.value().value(),
                kScale * base_mean + kShift));
    REQUIRE(estimate.value().sample_variance().has_value());
    CHECK(close(*estimate.value().sample_variance(),
                kScale * kScale * base_sample_variance));
    REQUIRE(estimate.value().exact_integration_absolute_error().has_value());
    CHECK(*estimate.value().exact_integration_absolute_error() >= 0.0L);
    REQUIRE(estimate.value().interval().has_value());
    const auto& interval = *estimate.value().interval();
    CHECK(interval.method == mwperf::StatisticalIntervalKindV1::hoeffding);
    REQUIRE(interval.almost_sure_lower.has_value());
    REQUIRE(interval.almost_sure_upper.has_value());
    CHECK(close(*interval.almost_sure_lower, kAffineLower));
    CHECK(close(*interval.almost_sure_upper, kAffineUpper));
    CHECK(interval.lower >= kAffineLower);
    CHECK(interval.upper <= kAffineUpper);
    CHECK(interval.iid_premise);
    CHECK(interval.fixed_sample_size);
    CHECK(interval.controls ==
          mwperf::SamplingClaimScopeV1::rao_blackwell_row);
  }
}

TEST_CASE("C24 importance reduction is invariant to a sample-index permutation",
          "[c24][property][importance][permutation]") {
  auto target = matrix::digest("c24.property.permutation.target");
  const auto decoder_digest =
      matrix::digest("c24.property.permutation.decoder");
  auto forward_override = finite_atom_override(
      "c24.property.permutation", 4U,
      mwperf::ConditionalSampleDependenceV1::iid_proposal);
  forward_override.conditional_sampler_contract->runtime_provenance =
      mwperf::RuntimeSamplingProvenanceV1::proposal;
  auto reverse_override = forward_override;
  reverse_override.conditional_sampler_calls =
      std::make_shared<std::atomic<unsigned>>(0U);
  reverse_override.conditional_sampler_operation =
      [](const mwperf::CanonicalRuntimeValueV1& state,
         mwperf::DeterministicRng& rng) {
        const auto selected = static_cast<std::uint8_t>(rng.next_u64() % 4U);
        return mwperf::Result<mwperf::KernelTransitionV1>::success(
            replay_atom(state,
                        static_cast<std::byte>(3U - selected)));
      };
  const auto ratio_operation =
      [](const mwperf::CanonicalRuntimeValueV1&,
         const mwperf::KernelTransitionV1& sample) {
        const auto exponent = first_mark_value(sample);
        return mwperf::Result<mwperf::ImportanceWeightV1>::success(
            {mwperf::ImportanceWeightRepresentationV1::direct_nonnegative,
             static_cast<long double>(UINT64_C(1) << exponent)});
      };
  attach_property_ratio(forward_override, target, decoder_digest,
                        ratio_operation);
  attach_property_ratio(reverse_override, target, decoder_digest,
                        ratio_operation);
  auto forward = seal_property_sampler(
      forward_override, 4U, mwperf::StatisticalIntervalKindV1::none);
  auto reverse = seal_property_sampler(
      reverse_override, 4U, mwperf::StatisticalIntervalKindV1::none);
  target = forward.sampler.accepted_sampling_clauses().front()
               .metric_target_digest;
  REQUIRE(forward.sampler.seal_digest() == reverse.sampler.seal_digest());
  const auto reward = property_reward(
      "c24.property.permutation", decoder_digest, target,
      forward.sampler.contract().output_schema,
      [](const mwperf::ConditioningState&, const mwperf::Sample& sample) {
        return mwperf::Result<long double>::success(
            1.0L + 2.0L *
                       static_cast<long double>(first_mark_value(sample)));
      });

  std::optional<mwperf::Estimate> forward_selected;
  std::optional<mwperf::Estimate> reverse_selected;
  for (std::uint64_t seed = 0U; seed < 4096U; ++seed) {
    const auto plan = property_plan(
        forward.sampler, seed, "c24.property.permutation", target, 4U,
        mwperf::StatisticalIntervalKindV1::none,
        mwperf::StatisticalEstimandKindV1::
            point_with_variance_diagnostics,
        std::nullopt, std::nullopt,
        mwperf::StageTag::importance_proposal);
    auto forward_ratio =
        forward.sampler.bind_target_density_ratio(forward.row, plan);
    auto reverse_ratio =
        reverse.sampler.bind_target_density_ratio(reverse.row, plan);
    REQUIRE(forward_ratio);
    REQUIRE(reverse_ratio);
    auto forward_estimate = mwperf::estimate_importance_weighted(
        forward.sampler, forward.row, forward_ratio.value(), reward, plan);
    auto reverse_estimate = mwperf::estimate_importance_weighted(
        reverse.sampler, reverse.row, reverse_ratio.value(), reward, plan);
    REQUIRE(forward_estimate);
    REQUIRE(reverse_estimate);
    std::vector<long double> forward_rewards(
        forward_estimate.value().raw_rewards().begin(),
        forward_estimate.value().raw_rewards().end());
    std::vector<long double> reverse_rewards(
        reverse_estimate.value().raw_rewards().begin(),
        reverse_estimate.value().raw_rewards().end());
    std::ranges::sort(forward_rewards);
    std::ranges::sort(reverse_rewards);
    const std::vector<long double> desired{1.0L, 3.0L, 5.0L, 7.0L};
    if (forward_rewards == desired && reverse_rewards == desired) {
      forward_selected = std::move(forward_estimate).value();
      reverse_selected = std::move(reverse_estimate).value();
      break;
    }
  }
  REQUIRE(forward_selected.has_value());
  REQUIRE(reverse_selected.has_value());
  CHECK(forward_selected->sampling_evidence().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::proposal);
  CHECK(reverse_selected->sampling_evidence().runtime_provenance ==
        mwperf::RuntimeSamplingProvenanceV1::proposal);
  REQUIRE(forward_selected->raw_rewards().size() == 4U);
  REQUIRE(reverse_selected->raw_rewards().size() == 4U);
  REQUIRE(forward_selected->raw_weights().size() == 4U);
  REQUIRE(reverse_selected->raw_weights().size() == 4U);

  // The two samplers apply v -> 3-v to the same four addressed random words.
  // On the selected complete bank this changes every sample index while
  // preserving exactly the reward/weight multiset supplied to reduction.
  bool order_changed = false;
  std::vector<std::pair<long double, long double>> forward_terms;
  std::vector<std::pair<long double, long double>> reverse_terms;
  for (std::size_t index = 0U; index < 4U; ++index) {
    order_changed = order_changed ||
                    forward_selected->raw_rewards()[index] !=
                        reverse_selected->raw_rewards()[index];
    forward_terms.emplace_back(
        forward_selected->raw_rewards()[index],
        forward_selected->raw_weights()[index].common_scaled_weight);
    reverse_terms.emplace_back(
        reverse_selected->raw_rewards()[index],
        reverse_selected->raw_weights()[index].common_scaled_weight);
  }
  REQUIRE(order_changed);
  std::ranges::sort(forward_terms);
  std::ranges::sort(reverse_terms);
  REQUIRE(forward_terms == reverse_terms);
  CHECK(close(forward_selected->value(), 83.0L / 15.0L));
  CHECK(close(reverse_selected->value(), 83.0L / 15.0L));
  CHECK(close(forward_selected->value(), reverse_selected->value()));
  REQUIRE(forward_selected->importance_diagnostics().has_value());
  REQUIRE(reverse_selected->importance_diagnostics().has_value());
  CHECK(close(
      forward_selected->importance_diagnostics()->effective_sample_size,
      reverse_selected->importance_diagnostics()->effective_sample_size));
  CHECK(close(
      forward_selected->importance_diagnostics()->maximum_normalized_weight,
      reverse_selected->importance_diagnostics()->maximum_normalized_weight));
  CHECK(forward_selected->importance_diagnostics()->zero_weight_count ==
        reverse_selected->importance_diagnostics()->zero_weight_count);
}
