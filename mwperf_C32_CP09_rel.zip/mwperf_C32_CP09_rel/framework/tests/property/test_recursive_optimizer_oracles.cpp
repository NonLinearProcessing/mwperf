#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <numeric>
#include <optional>
#include <sstream>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ConflictEdge final {
  std::size_t first;
  std::size_t second;
};

struct RecursiveFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

struct PreparedQuery final {
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct OracleOptimum final {
  std::vector<std::uint8_t> bits;
  mwperf::BigNat objective;
  std::size_t maximizing_schedules;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c08-recursive-property";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::vector<std::string> labels(const std::string& prefix,
                                              const std::size_t count) {
  std::vector<std::string> result;
  result.reserve(count);
  for (std::size_t index = 0U; index < count; ++index) {
    result.push_back(prefix + std::to_string(index));
  }
  return result;
}

[[nodiscard]] std::string quoted_array(
    const std::vector<std::string>& values) {
  std::ostringstream output;
  output << '[';
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (index != 0U) {
      output << ',';
    }
    output << '"' << values[index] << '"';
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string priority_json(
    const std::vector<std::size_t>& priority) {
  std::vector<std::string> ids;
  ids.reserve(priority.size());
  for (const std::size_t queue : priority) {
    ids.push_back("q" + std::to_string(queue));
  }
  return quoted_array(ids);
}

[[nodiscard]] std::string conflict_scheduler(
    const std::vector<ConflictEdge>& edges,
    const std::vector<std::size_t>& authored_order,
    const std::vector<std::size_t>& priority, const bool reverse_endpoints) {
  std::ostringstream conflicts;
  conflicts << '[';
  for (std::size_t position = 0U; position < authored_order.size();
       ++position) {
    const std::size_t edge_index = authored_order[position];
    REQUIRE(edge_index < edges.size());
    if (position != 0U) {
      conflicts << ',';
    }
    const auto& edge = edges[edge_index];
    const std::size_t first = reverse_endpoints ? edge.second : edge.first;
    const std::size_t second = reverse_endpoints ? edge.first : edge.second;
    conflicts << "[\"q" << first << "\",\"q" << second << "\"]";
  }
  conflicts << ']';
  return R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":)" +
         conflicts.str() + R"(},"priority":)" + priority_json(priority) +
         R"(,"max_search_states":null}})";
}

[[nodiscard]] std::string packing_scheduler(
    const std::vector<std::uint64_t>& capacities,
    const std::vector<std::vector<std::uint64_t>>& demands,
    const std::vector<std::size_t>& resource_order,
    const std::vector<std::size_t>& demand_order,
    const std::vector<std::size_t>& priority) {
  std::vector<std::string> resource_ids;
  resource_ids.reserve(resource_order.size());
  for (const std::size_t resource : resource_order) {
    REQUIRE(resource < capacities.size());
    resource_ids.push_back("r" + std::to_string(resource));
  }

  std::ostringstream capacity_json;
  capacity_json << '[';
  for (std::size_t position = 0U; position < resource_order.size();
       ++position) {
    if (position != 0U) {
      capacity_json << ',';
    }
    capacity_json << capacities[resource_order[position]];
  }
  capacity_json << ']';

  std::ostringstream demand_json;
  demand_json << '[';
  for (std::size_t position = 0U; position < demand_order.size();
       ++position) {
    const std::size_t queue = demand_order[position];
    REQUIRE(queue < demands.size());
    REQUIRE(demands[queue].size() == capacities.size());
    if (position != 0U) {
      demand_json << ',';
    }
    demand_json << "{\"queue_id\":\"q" << queue << "\",\"demand\":[";
    for (std::size_t coordinate = 0U; coordinate < resource_order.size();
         ++coordinate) {
      if (coordinate != 0U) {
        demand_json << ',';
      }
      demand_json << demands[queue][resource_order[coordinate]];
    }
    demand_json << "]}";
  }
  demand_json << ']';

  return R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":)" +
         quoted_array(resource_ids) + R"(,"capacity":)" +
         capacity_json.str() + R"(,"demands":)" + demand_json.str() +
         R"(},"priority":)" + priority_json(priority) +
         R"(,"max_search_states":null}})";
}

[[nodiscard]] RecursiveFixture make_fixture(
    const std::size_t queue_count, const std::string& scheduler) {
  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      quoted_array(labels("q", queue_count)) + R"(},"scheduler":)" +
      scheduler +
      R"(,"arrival":{"family":"deterministic_trace","events":[]}})";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  INFO((model ? std::string{} : model.error().code));
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  return RecursiveFixture{std::move(catalog).value(),
                          std::move(priority).value(),
                          std::move(descriptor).value()};
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy policy(
    const std::optional<mwperf::BigNat>& limit = std::nullopt) {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = limit,
      .analysis_per_call = std::nullopt,
      .effective_per_call = limit,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto result = mwperf::Digest256::from_hex(std::string(64U, 'a'));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const RecursiveFixture& fixture,
    const mwperf::OptimizerBudgetPolicy& budget_policy) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, budget_policy);
}

[[nodiscard]] PreparedQuery prepare_query(
    const RecursiveFixture& fixture,
    const std::vector<mwperf::BigNat>& primary_values,
    const std::vector<std::uint8_t>& eligibility_values,
    const mwperf::OptimizerBudgetPolicy& budget_policy = policy()) {
  const auto token = dimension(fixture, budget_policy);
  auto primary =
      mwperf::PrimaryWeights::from_values(token, primary_values);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      token, eligibility_values);
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return PreparedQuery{std::move(eligibility).value(),
                       std::move(weights).value()};
}

[[nodiscard]] mwperf::OptimizerSolution solve_production(
    const RecursiveFixture& fixture, const PreparedQuery& query,
    const mwperf::OptimizerBudgetPolicy& budget_policy = policy()) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      budget_policy, std::nullopt, query.weights.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto solution = mwperf::solve_exact(fixture.descriptor, query.eligibility,
                                      query.weights, budget.value());
  INFO((solution ? std::string{} : solution.error().code));
  REQUIRE(solution);
  auto validation = mwperf::validate_optimizer_solution(
      solution.value(), fixture.descriptor, query.eligibility,
      query.weights);
  INFO((validation ? std::string{} : validation.error().code));
  REQUIRE(validation);
  return std::move(solution).value();
}

[[nodiscard]] bool conflict_feasible(
    const mwperf::ResolvedConflictConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  for (const auto& edge : constraint.conflicts) {
    if (selected[edge.first.ordinal()] != 0U &&
        selected[edge.second.ordinal()] != 0U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool packing_feasible(
    const mwperf::ResolvedPackingConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<mwperf::BigNat> used;
  used.reserve(constraint.capacity.size());
  for (std::size_t resource = 0U; resource < constraint.capacity.size();
       ++resource) {
    used.emplace_back(0U);
  }
  for (const auto& row : constraint.demands) {
    if (selected[row.queue.ordinal()] == 0U) {
      continue;
    }
    REQUIRE(row.demand.size() == used.size());
    for (std::size_t resource = 0U; resource < used.size(); ++resource) {
      used[resource] += row.demand[resource];
      if (used[resource] > constraint.capacity[resource]) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] OracleOptimum enumerate_optimum(
    const RecursiveFixture& fixture, const PreparedQuery& query) {
  const std::size_t queue_count = fixture.catalog.size();
  REQUIRE(queue_count <= 8U);
  const std::uint64_t subset_count = std::uint64_t{1U} << queue_count;
  OracleOptimum best{{}, mwperf::BigNat(0U), 0U};
  bool initialized = false;
  for (std::uint64_t subset = 0U; subset < subset_count; ++subset) {
    std::vector<std::uint8_t> selected(queue_count, 0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if ((subset & (std::uint64_t{1U} << queue)) == 0U) {
        continue;
      }
      if (query.eligibility.bytes()[queue] == 0U) {
        allowed = false;
        break;
      }
      selected[queue] = 1U;
    }
    if (!allowed) {
      continue;
    }
    const bool feasible = std::visit(
        [&selected](const auto& constraint) {
          using Constraint = std::decay_t<decltype(constraint)>;
          if constexpr (std::same_as<Constraint,
                                     mwperf::ResolvedConflictConstraint>) {
            return conflict_feasible(constraint, selected);
          } else if constexpr (std::same_as<
                                   Constraint,
                                   mwperf::ResolvedPackingConstraint>) {
            return packing_feasible(constraint, selected);
          } else {
            return false;
          }
        },
        fixture.descriptor.value());
    if (!feasible) {
      continue;
    }
    mwperf::BigNat objective(0U);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (selected[queue] != 0U) {
        objective += query.weights.values()[queue];
      }
    }
    if (!initialized || objective > best.objective) {
      best = OracleOptimum{std::move(selected), std::move(objective), 1U};
      initialized = true;
    } else if (objective == best.objective) {
      ++best.maximizing_schedules;
    }
  }
  REQUIRE(initialized);
  return best;
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bits(
    const mwperf::OptimizerSolution& solution) {
  return {solution.schedule().bytes().begin(),
          solution.schedule().bytes().end()};
}

[[nodiscard]] std::uint64_t next_random(std::uint64_t& state) {
  state = state * UINT64_C(6364136223846793005) +
          UINT64_C(1442695040888963407);
  return state;
}

[[nodiscard]] std::vector<std::size_t> random_permutation(
    const std::size_t count, std::uint64_t& state) {
  std::vector<std::size_t> result(count);
  std::iota(result.begin(), result.end(), 0U);
  for (std::size_t remaining = count; remaining > 1U; --remaining) {
    const std::size_t other = static_cast<std::size_t>(
        next_random(state) % static_cast<std::uint64_t>(remaining));
    std::swap(result[remaining - 1U], result[other]);
  }
  return result;
}

[[nodiscard]] std::vector<mwperf::BigNat> random_primary(
    const std::size_t count, std::uint64_t& state) {
  std::vector<mwperf::BigNat> result;
  result.reserve(count);
  for (std::size_t queue = 0U; queue < count; ++queue) {
    result.emplace_back(next_random(state) % 17U);
  }
  return result;
}

[[nodiscard]] std::vector<std::uint8_t> random_eligibility(
    const std::size_t count, std::uint64_t& state) {
  std::vector<std::uint8_t> result(count, 0U);
  for (std::size_t queue = 0U; queue < count; ++queue) {
    result[queue] = static_cast<std::uint8_t>(next_random(state) & 1U);
  }
  return result;
}

[[nodiscard]] mwperf::BigNat power_of_two(const unsigned int shift) {
  mwperf::BigInt value = 1;
  value <<= shift;
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::string no_resource_packing_scheduler(
    const std::size_t queue_count,
    const std::vector<std::size_t>& priority) {
  std::vector<std::vector<std::uint64_t>> demands(queue_count);
  std::vector<std::size_t> order(queue_count);
  std::iota(order.begin(), order.end(), 0U);
  return packing_scheduler({}, demands, {}, order, priority);
}

}  // namespace

TEST_CASE("C08 random recursive optimizers match independent exhaustive oracles",
          "[c08][property][recursive][oracle]") {
  std::uint64_t state = UINT64_C(0x8a11c0de5eed1234);

  for (std::size_t trial = 0U; trial < 80U; ++trial) {
    const std::size_t queue_count =
        1U + static_cast<std::size_t>(next_random(state) % 8U);
    std::vector<ConflictEdge> edges;
    for (std::size_t first = 0U; first < queue_count; ++first) {
      for (std::size_t second = first + 1U; second < queue_count; ++second) {
        if ((next_random(state) % 4U) == 0U) {
          edges.push_back(ConflictEdge{first, second});
        }
      }
    }
    std::vector<std::size_t> edge_order(edges.size());
    std::iota(edge_order.begin(), edge_order.end(), 0U);
    const auto priority = random_permutation(queue_count, state);
    const auto fixture = make_fixture(
        queue_count,
        conflict_scheduler(edges, edge_order, priority, false));
    const auto query = prepare_query(
        fixture, random_primary(queue_count, state),
        random_eligibility(queue_count, state));
    const auto oracle = enumerate_optimum(fixture, query);
    const auto exact = solve_production(fixture, query);
    INFO("conflict trial " << trial);
    CHECK(oracle.maximizing_schedules == 1U);
    CHECK(schedule_bits(exact) == oracle.bits);
    CHECK(exact.composite_objective() == oracle.objective);
  }

  for (std::size_t trial = 0U; trial < 80U; ++trial) {
    const std::size_t queue_count =
        1U + static_cast<std::size_t>(next_random(state) % 8U);
    const std::size_t resource_count =
        static_cast<std::size_t>(next_random(state) % 4U);
    std::vector<std::uint64_t> capacities(resource_count, 0U);
    for (auto& capacity : capacities) {
      capacity = next_random(state) % 7U;
    }
    std::vector<std::vector<std::uint64_t>> demands(
        queue_count, std::vector<std::uint64_t>(resource_count, 0U));
    for (auto& row : demands) {
      for (auto& demand : row) {
        demand = next_random(state) % 8U;
      }
    }
    std::vector<std::size_t> resource_order(resource_count);
    std::iota(resource_order.begin(), resource_order.end(), 0U);
    std::vector<std::size_t> demand_order(queue_count);
    std::iota(demand_order.begin(), demand_order.end(), 0U);
    const auto priority = random_permutation(queue_count, state);
    const auto fixture = make_fixture(
        queue_count,
        packing_scheduler(capacities, demands, resource_order, demand_order,
                          priority));
    const auto query = prepare_query(
        fixture, random_primary(queue_count, state),
        random_eligibility(queue_count, state));
    const auto oracle = enumerate_optimum(fixture, query);
    const auto exact = solve_production(fixture, query);
    INFO("packing trial " << trial);
    CHECK(oracle.maximizing_schedules == 1U);
    CHECK(schedule_bits(exact) == oracle.bits);
    CHECK(exact.composite_objective() == oracle.objective);
  }
}

TEST_CASE("C08 authored conflict and packing permutations preserve queue answers",
          "[c08][property][recursive][permutation]") {
  const std::vector<std::size_t> priority{4U, 1U, 3U, 0U, 2U};
  const std::vector<mwperf::BigNat> primary{
      mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(5U),
      mwperf::BigNat(8U), mwperf::BigNat(4U)};
  const std::vector<std::uint8_t> eligibility{1U, 1U, 1U, 1U, 1U};

  SECTION("conflict row order and pair orientation") {
    const std::vector<ConflictEdge> edges{{0U, 1U}, {0U, 3U}, {1U, 2U},
                                          {2U, 4U}, {3U, 4U}};
    const std::vector<std::size_t> forward{0U, 1U, 2U, 3U, 4U};
    const std::vector<std::size_t> permuted{3U, 0U, 4U, 2U, 1U};
    const auto first = make_fixture(
        5U, conflict_scheduler(edges, forward, priority, false));
    const auto second = make_fixture(
        5U, conflict_scheduler(edges, permuted, priority, true));
    const auto first_query =
        prepare_query(first, primary, eligibility);
    const auto second_query =
        prepare_query(second, primary, eligibility);
    const auto first_result = solve_production(first, first_query);
    const auto second_result = solve_production(second, second_query);
    CHECK(schedule_bits(first_result) == schedule_bits(second_result));
    CHECK(first_result.composite_objective() ==
          second_result.composite_objective());
    CHECK(first_result.accounting().completed_expansions() ==
          second_result.accounting().completed_expansions());
  }

  SECTION("resource and demand record order") {
    const std::vector<std::uint64_t> capacities{4U, 5U, 3U};
    const std::vector<std::vector<std::uint64_t>> demands{
        {4U, 0U, 1U}, {0U, 5U, 1U}, {2U, 2U, 1U},
        {1U, 3U, 2U}, {0U, 0U, 0U}};
    const std::vector<std::size_t> resources{0U, 1U, 2U};
    const std::vector<std::size_t> permuted_resources{2U, 0U, 1U};
    const std::vector<std::size_t> rows{0U, 1U, 2U, 3U, 4U};
    const std::vector<std::size_t> permuted_rows{4U, 2U, 0U, 3U, 1U};
    const auto first = make_fixture(
        5U, packing_scheduler(capacities, demands, resources, rows,
                              priority));
    const auto second = make_fixture(
        5U, packing_scheduler(capacities, demands, permuted_resources,
                              permuted_rows, priority));
    const auto first_query =
        prepare_query(first, primary, eligibility);
    const auto second_query =
        prepare_query(second, primary, eligibility);
    const auto first_result = solve_production(first, first_query);
    const auto second_result = solve_production(second, second_query);
    CHECK(schedule_bits(first_result) == schedule_bits(second_result));
    CHECK(first_result.composite_objective() ==
          second_result.composite_objective());
    CHECK(first_result.accounting().completed_expansions() ==
          second_result.accounting().completed_expansions());
  }
}

TEST_CASE("C08 recursive solve budgets replay at the exact observed state count",
          "[c08][property][recursive][budget]") {
  const std::vector<ConflictEdge> edges{{0U, 2U}, {1U, 2U}, {2U, 3U},
                                        {3U, 4U}};
  const std::vector<std::size_t> edge_order{0U, 1U, 2U, 3U};
  const std::vector<std::size_t> priority{3U, 0U, 4U, 1U, 2U};
  const auto conflict = make_fixture(
      5U, conflict_scheduler(edges, edge_order, priority, false));
  const std::vector<mwperf::BigNat> primary{
      mwperf::BigNat(4U), mwperf::BigNat(3U), mwperf::BigNat(6U),
      mwperf::BigNat(2U), mwperf::BigNat(5U)};
  const std::vector<std::uint8_t> eligibility(5U, 1U);
  const auto unlimited_query = prepare_query(conflict, primary, eligibility);
  const auto unlimited_result =
      solve_production(conflict, unlimited_query);
  const auto conflict_limit = std::optional<mwperf::BigNat>(
      unlimited_result.accounting().completed_expansions());
  const auto finite_policy = policy(conflict_limit);
  const auto finite_query =
      prepare_query(conflict, primary, eligibility, finite_policy);
  const auto finite_result =
      solve_production(conflict, finite_query, finite_policy);
  CHECK(schedule_bits(finite_result) == schedule_bits(unlimited_result));
  CHECK(finite_result.composite_objective() ==
        unlimited_result.composite_objective());
  CHECK(finite_result.accounting().completed_expansions() ==
        unlimited_result.accounting().completed_expansions());

  const std::vector<std::uint64_t> capacities{3U, 4U};
  const std::vector<std::vector<std::uint64_t>> demands{
      {2U, 2U}, {1U, 3U}, {2U, 1U}, {0U, 0U}, {3U, 4U}};
  const std::vector<std::size_t> resources{0U, 1U};
  const std::vector<std::size_t> rows{0U, 1U, 2U, 3U, 4U};
  const auto packing = make_fixture(
      5U, packing_scheduler(capacities, demands, resources, rows, priority));
  const auto unlimited_packing_query =
      prepare_query(packing, primary, eligibility);
  const auto unlimited_packing_result =
      solve_production(packing, unlimited_packing_query);
  const auto packing_limit = std::optional<mwperf::BigNat>(
      unlimited_packing_result.accounting().completed_expansions());
  const auto finite_packing_policy = policy(packing_limit);
  const auto finite_packing_query =
      prepare_query(packing, primary, eligibility, finite_packing_policy);
  const auto finite_packing_result = solve_production(
      packing, finite_packing_query, finite_packing_policy);
  CHECK(schedule_bits(finite_packing_result) ==
        schedule_bits(unlimited_packing_result));
  CHECK(finite_packing_result.composite_objective() ==
        unlimited_packing_result.composite_objective());
  CHECK(finite_packing_result.accounting().completed_expansions() ==
        unlimited_packing_result.accounting().completed_expansions());
}

TEST_CASE("C08 capacity monotonicity and zero-support coordinates hold exactly",
          "[c08][property][recursive][monotonicity]") {
  const std::vector<std::vector<std::uint64_t>> demands{
      {2U, 0U}, {0U, 2U}, {1U, 1U}, {0U, 0U}};
  const std::vector<std::size_t> resources{0U, 1U};
  const std::vector<std::size_t> rows{0U, 1U, 2U, 3U};
  const std::vector<std::size_t> priority{2U, 0U, 1U, 3U};
  const auto lower = make_fixture(
      4U, packing_scheduler({2U, 2U}, demands, resources, rows, priority));
  const auto higher = make_fixture(
      4U, packing_scheduler({3U, 3U}, demands, resources, rows, priority));
  const std::vector<mwperf::BigNat> primary{
      mwperf::BigNat(5U), mwperf::BigNat(5U), mwperf::BigNat(6U),
      mwperf::BigNat(0U)};
  const std::vector<std::uint8_t> eligibility(4U, 1U);
  const auto lower_query = prepare_query(lower, primary, eligibility);
  const auto higher_query = prepare_query(higher, primary, eligibility);
  const auto lower_result = solve_production(lower, lower_query);
  const auto higher_result = solve_production(higher, higher_query);
  CHECK(higher_result.composite_objective() >=
        lower_result.composite_objective());
  CHECK(schedule_bits(lower_result)[3U] == 1U);
  CHECK(schedule_bits(higher_result)[3U] == 1U);

  const std::vector<ConflictEdge> base_edges{{0U, 1U}, {1U, 2U}};
  const std::vector<std::size_t> edge_order{0U, 1U};
  const std::vector<std::size_t> conflict_priority{0U, 1U, 2U, 3U};
  const auto with_isolate = make_fixture(
      4U, conflict_scheduler(base_edges, edge_order, conflict_priority,
                             false));
  const auto isolate_query = prepare_query(
      with_isolate,
      {mwperf::BigNat(2U), mwperf::BigNat(3U), mwperf::BigNat(2U),
       mwperf::BigNat(0U)},
      {1U, 1U, 1U, 1U});
  const auto isolate_result = solve_production(with_isolate, isolate_query);
  CHECK(schedule_bits(isolate_result)[3U] == 1U);
}

TEST_CASE("C08 dynamic subsets and exact weights remain correct beyond 64 queues",
          "[c08][property][recursive][multiprecision]") {
  constexpr std::size_t queue_count = 70U;
  std::vector<std::size_t> order(queue_count);
  std::iota(order.begin(), order.end(), 0U);
  std::vector<mwperf::BigNat> primary;
  primary.reserve(queue_count);
  const mwperf::BigNat huge = power_of_two(180U);
  std::vector<std::uint8_t> eligibility(queue_count, 1U);
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    primary.push_back(huge + mwperf::BigNat(queue));
    if ((queue % 9U) == 0U) {
      eligibility[queue] = 0U;
    }
  }

  const auto conflicts = make_fixture(
      queue_count, conflict_scheduler({}, {}, order, false));
  const auto conflict_query =
      prepare_query(conflicts, primary, eligibility);
  const auto conflict_result =
      solve_production(conflicts, conflict_query);
  CHECK(schedule_bits(conflict_result) == eligibility);
  CHECK(conflict_result.composite_objective().bit_length() > 180U);

  const auto packing = make_fixture(
      queue_count, no_resource_packing_scheduler(queue_count, order));
  const auto packing_query = prepare_query(packing, primary, eligibility);
  const auto packing_result = solve_production(packing, packing_query);
  CHECK(schedule_bits(packing_result) == eligibility);
  CHECK(packing_result.composite_objective().bit_length() > 180U);
}
