#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <numeric>
#include <optional>
#include <ranges>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct OptimizerFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

struct PreparedQuery final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct OracleOptimum final {
  std::vector<std::uint8_t> bits;
  mwperf::BigNat composite;
  mwperf::BigNat primary;
  std::size_t primary_maximizers;
  std::size_t composite_maximizers;
};

struct CrossbarEndpoint final {
  std::size_t input;
  std::size_t output;
};

struct IntervalLexemes final {
  std::string left;
  std::string right;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c06-property";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::string quoted_array(
    const std::vector<std::string>& values) {
  std::string result{"["};
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (index != 0U) {
      result += ',';
    }
    result += "\"" + values[index] + "\"";
  }
  result += ']';
  return result;
}

[[nodiscard]] std::vector<std::string> labels(const std::string& prefix,
                                              const std::size_t count) {
  std::vector<std::string> result;
  result.reserve(count);
  for (std::size_t index = 0U; index < count; ++index) {
    result.push_back(prefix + std::to_string(index));
  }
  return result;
}

[[nodiscard]] std::string priority_json(
    const std::vector<std::size_t>& priority) {
  std::vector<std::string> queue_ids;
  queue_ids.reserve(priority.size());
  for (const std::size_t queue : priority) {
    queue_ids.push_back("q" + std::to_string(queue));
  }
  return quoted_array(queue_ids);
}

[[nodiscard]] std::string crossbar_scheduler(
    const std::vector<CrossbarEndpoint>& edges,
    const std::vector<std::size_t>& priority,
    const std::vector<std::string>& input_names,
    const std::vector<std::string>& output_names) {
  std::string edge_json{"["};
  for (std::size_t queue = 0U; queue < edges.size(); ++queue) {
    if (queue != 0U) {
      edge_json += ',';
    }
    REQUIRE(edges[queue].input < input_names.size());
    REQUIRE(edges[queue].output < output_names.size());
    edge_json += "{\"queue_id\":\"q" + std::to_string(queue) +
                 "\",\"input\":\"" + input_names[edges[queue].input] +
                 "\",\"output\":\"" +
                 output_names[edges[queue].output] + "\"}";
  }
  edge_json += ']';
  return R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":)" +
         quoted_array(input_names) + R"(,"outputs":)" +
         quoted_array(output_names) + R"(,"edges":)" + edge_json +
         R"(},"priority":)" + priority_json(priority) + R"(}})";
}

[[nodiscard]] std::string interval_scheduler(
    const std::vector<IntervalLexemes>& intervals,
    const std::vector<std::size_t>& authored_order,
    const std::vector<std::size_t>& priority) {
  std::string interval_json{"["};
  for (std::size_t position = 0U; position < authored_order.size();
       ++position) {
    if (position != 0U) {
      interval_json += ',';
    }
    const std::size_t queue = authored_order[position];
    REQUIRE(queue < intervals.size());
    interval_json += "{\"queue_id\":\"q" + std::to_string(queue) +
                     "\",\"left\":" + intervals[queue].left +
                     ",\"right\":" + intervals[queue].right + "}";
  }
  interval_json += ']';
  return R"({"name":"interval_max_weight","params":{"constraint":{"intervals":)" +
         interval_json + R"(},"priority":)" + priority_json(priority) +
         R"(}})";
}

[[nodiscard]] OptimizerFixture make_fixture(
    const std::size_t queue_count, const std::string& scheduler) {
  const std::vector<std::string> queue_ids = labels("q", queue_count);
  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      quoted_array(queue_ids) + R"(},"scheduler":)" + scheduler +
      R"(,"arrival":{"family":"deterministic_trace","events":[]}})";

  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  return OptimizerFixture{std::move(catalog).value(),
                          std::move(priority).value(),
                          std::move(descriptor).value()};
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto result = mwperf::Digest256::from_hex(std::string(64U, '6'));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const OptimizerFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] PreparedQuery prepare_query(
    const OptimizerFixture& fixture,
    const std::vector<mwperf::BigNat>& primary_values,
    const std::vector<std::uint8_t>& eligibility_values) {
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension(fixture), primary_values);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      dimension(fixture), eligibility_values);
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return PreparedQuery{std::move(primary).value(),
                       std::move(eligibility).value(),
                       std::move(weights).value()};
}

[[nodiscard]] mwperf::OptimizerSolution solve_production(
    const OptimizerFixture& fixture, const PreparedQuery& query) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      unlimited_policy(), std::nullopt, query.weights.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto solution = mwperf::solve_exact(fixture.descriptor, query.eligibility,
                                      query.weights, budget.value());
  INFO((solution ? std::string{} : solution.error().code));
  REQUIRE(solution);
  auto validation = mwperf::validate_optimizer_solution(
      solution.value(), fixture.descriptor, query.eligibility,
      query.weights);
  INFO((validation ? std::string{} : validation.error().code));
  REQUIRE(validation);
  CHECK(solution.value().accounting().completed_expansions() ==
        mwperf::BigNat(std::uint64_t{0U}));
  return std::move(solution).value();
}

[[nodiscard]] bool crossbar_feasible(
    const mwperf::ResolvedCrossbarConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<std::uint8_t> used_inputs(constraint.inputs.size(), 0U);
  std::vector<std::uint8_t> used_outputs(constraint.outputs.size(), 0U);
  for (const mwperf::ResolvedCrossbarEdge& edge : constraint.edges) {
    if (selected[edge.queue.ordinal()] == 0U) {
      continue;
    }
    const std::size_t input = edge.input.ordinal();
    const std::size_t output = edge.output.ordinal();
    if (used_inputs[input] != 0U || used_outputs[output] != 0U) {
      return false;
    }
    used_inputs[input] = 1U;
    used_outputs[output] = 1U;
  }
  return true;
}

[[nodiscard]] bool interval_feasible(
    const mwperf::ResolvedIntervalConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  for (std::size_t first = 0U; first < constraint.intervals.size(); ++first) {
    const mwperf::ResolvedInterval& lhs = constraint.intervals[first];
    if (selected[lhs.queue.ordinal()] == 0U) {
      continue;
    }
    for (std::size_t second = first + 1U;
         second < constraint.intervals.size(); ++second) {
      const mwperf::ResolvedInterval& rhs = constraint.intervals[second];
      if (selected[rhs.queue.ordinal()] != 0U &&
          !(lhs.right <= rhs.left || rhs.right <= lhs.left)) {
        return false;
      }
    }
  }
  return true;
}

template <typename FeasibilityPredicate>
[[nodiscard]] OracleOptimum enumerate_optimum(
    const PreparedQuery& query, FeasibilityPredicate&& feasible) {
  REQUIRE(query.weights.size() <= 8U);
  const std::uint64_t subset_count =
      std::uint64_t{1U} << query.weights.size();
  std::vector<std::uint8_t> best_bits(query.weights.size(), 0U);
  mwperf::BigNat best_composite(std::uint64_t{0U});
  mwperf::BigNat best_primary(std::uint64_t{0U});
  bool composite_initialized = false;
  bool primary_initialized = false;
  std::size_t composite_maximizers = 0U;
  std::size_t primary_maximizers = 0U;

  for (std::uint64_t subset = 0U; subset < subset_count; ++subset) {
    std::vector<std::uint8_t> candidate(query.weights.size(), 0U);
    bool eligible = true;
    mwperf::BigNat composite(std::uint64_t{0U});
    mwperf::BigNat primary(std::uint64_t{0U});
    for (std::size_t queue = 0U; queue < query.weights.size(); ++queue) {
      candidate[queue] =
          static_cast<std::uint8_t>((subset >> queue) & 1U);
      if (candidate[queue] == 0U) {
        continue;
      }
      if (query.eligibility.bytes()[queue] == 0U) {
        eligible = false;
        break;
      }
      composite += query.weights.values()[queue];
      primary += query.primary.values()[queue];
    }
    if (!eligible || !feasible(candidate)) {
      continue;
    }

    if (!primary_initialized || primary > best_primary) {
      best_primary = primary;
      primary_maximizers = 1U;
      primary_initialized = true;
    } else if (primary == best_primary) {
      ++primary_maximizers;
    }

    if (!composite_initialized || composite > best_composite) {
      best_bits = std::move(candidate);
      best_composite = composite;
      composite_maximizers = 1U;
      composite_initialized = true;
    } else if (composite == best_composite) {
      ++composite_maximizers;
    }
  }

  REQUIRE(composite_initialized);
  REQUIRE(primary_initialized);
  return OracleOptimum{std::move(best_bits), std::move(best_composite),
                       std::move(best_primary), primary_maximizers,
                       composite_maximizers};
}

[[nodiscard]] OracleOptimum crossbar_oracle(
    const OptimizerFixture& fixture, const PreparedQuery& query) {
  const auto& constraint = std::get<mwperf::ResolvedCrossbarConstraint>(
      fixture.descriptor.value());
  return enumerate_optimum(query, [&](const auto& selected) {
    return crossbar_feasible(constraint, selected);
  });
}

[[nodiscard]] OracleOptimum interval_oracle(
    const OptimizerFixture& fixture, const PreparedQuery& query) {
  const auto& constraint = std::get<mwperf::ResolvedIntervalConstraint>(
      fixture.descriptor.value());
  return enumerate_optimum(query, [&](const auto& selected) {
    return interval_feasible(constraint, selected);
  });
}

[[nodiscard]] std::uint64_t next_random(std::uint64_t& state) {
  state = state * 6364136223846793005ULL + 1442695040888963407ULL;
  return state;
}

template <typename Value>
void deterministic_shuffle(std::vector<Value>& values,
                           std::uint64_t& state) {
  for (std::size_t end = values.size(); end > 1U; --end) {
    const std::size_t other =
        static_cast<std::size_t>(next_random(state) % end);
    std::swap(values[end - 1U], values[other]);
  }
}

[[nodiscard]] std::vector<std::size_t> random_priority(
    const std::size_t count, std::uint64_t& state) {
  std::vector<std::size_t> priority(count);
  std::iota(priority.begin(), priority.end(), std::size_t{0U});
  deterministic_shuffle(priority, state);
  return priority;
}

[[nodiscard]] std::string quarter_lexeme(const int ticks) {
  const bool negative = ticks < 0;
  const unsigned int magnitude =
      static_cast<unsigned int>(negative ? -ticks : ticks);
  const unsigned int whole = magnitude / 4U;
  const unsigned int remainder = magnitude % 4U;
  std::string result = negative ? "-" : "";
  result += std::to_string(whole);
  if (remainder == 1U) {
    result += ".25";
  } else if (remainder == 2U) {
    result += ".5";
  } else if (remainder == 3U) {
    result += ".75";
  }
  return result;
}

[[nodiscard]] std::vector<mwperf::BigNat> scaled_values(
    const std::vector<mwperf::BigNat>& values, const std::uint64_t factor) {
  std::vector<mwperf::BigNat> scaled;
  scaled.reserve(values.size());
  const mwperf::BigNat multiplier(factor);
  for (const mwperf::BigNat& value : values) {
    scaled.push_back(value * multiplier);
  }
  return scaled;
}

void check_solution(const mwperf::OptimizerSolution& actual,
                    const OracleOptimum& expected,
                    const mwperf::ServiceFamily family,
                    const mwperf::OptimizerId backend) {
  CHECK(expected.composite_maximizers == 1U);
  CHECK(std::ranges::equal(actual.schedule().bytes(), expected.bits));
  CHECK(actual.composite_objective() == expected.composite);
  CHECK(actual.family() == family);
  CHECK(actual.backend_id() == backend);
}

void check_interval_predecessors(const OptimizerFixture& fixture) {
  const auto& constraint = std::get<mwperf::ResolvedIntervalConstraint>(
      fixture.descriptor.value());
  auto compiled = mwperf::compile_interval_problem(constraint);
  REQUIRE(compiled);
  const auto intervals = compiled.value().intervals();
  const auto predecessors = compiled.value().predecessors();
  REQUIRE(intervals.size() == predecessors.size());

  for (std::size_t current = 0U; current < intervals.size(); ++current) {
    std::optional<std::size_t> independently_scanned;
    for (std::size_t earlier = 0U; earlier < current; ++earlier) {
      if (intervals[earlier].right <= intervals[current].left) {
        independently_scanned = earlier;
      }
    }
    INFO(current);
    CHECK(predecessors[current] == independently_scanned);
    if (predecessors[current].has_value()) {
      CHECK(*predecessors[current] < current);
      CHECK(intervals[*predecessors[current]].right <=
            intervals[current].left);
      for (std::size_t later = *predecessors[current] + 1U;
           later < current; ++later) {
        CHECK_FALSE(intervals[later].right <= intervals[current].left);
      }
    }
  }
}

}  // namespace

TEST_CASE("C06 random sparse crossbars agree with exhaustive subset oracles",
          "[c06][property][crossbar]") {
  std::uint64_t state = 0xd1b54a32d192ed03ULL;

  for (std::size_t queue_count = 1U; queue_count <= 8U; ++queue_count) {
    for (std::size_t trial = 0U; trial < 5U; ++trial) {
      const std::size_t input_count =
          1U + static_cast<std::size_t>(next_random(state) % 4U);
      const std::size_t minimum_outputs =
          (queue_count + input_count - 1U) / input_count;
      const std::size_t output_count =
          minimum_outputs +
          static_cast<std::size_t>(next_random(state) % 3U);

      std::vector<CrossbarEndpoint> all_pairs;
      for (std::size_t input = 0U; input < input_count; ++input) {
        for (std::size_t output = 0U; output < output_count; ++output) {
          all_pairs.push_back(CrossbarEndpoint{input, output});
        }
      }
      deterministic_shuffle(all_pairs, state);
      all_pairs.resize(queue_count);
      const std::vector<std::size_t> priority =
          random_priority(queue_count, state);
      const OptimizerFixture fixture = make_fixture(
          queue_count,
          crossbar_scheduler(all_pairs, priority,
                             labels("input_", input_count),
                             labels("output_", output_count)));

      std::vector<mwperf::BigNat> primary_values;
      std::vector<std::uint8_t> eligibility;
      primary_values.reserve(queue_count);
      eligibility.reserve(queue_count);
      for (std::size_t queue = 0U; queue < queue_count; ++queue) {
        primary_values.emplace_back(next_random(state) % 32U);
        eligibility.push_back(static_cast<std::uint8_t>(
            (next_random(state) & std::uint64_t{3U}) != 0U));
      }

      const PreparedQuery query =
          prepare_query(fixture, primary_values, eligibility);
      const OracleOptimum expected = crossbar_oracle(fixture, query);
      const mwperf::OptimizerSolution actual =
          solve_production(fixture, query);
      INFO(queue_count);
      INFO(trial);
      check_solution(actual, expected,
                     mwperf::ServiceFamily::crossbar_matching,
                     mwperf::OptimizerId::hungarian_exact);

      const std::uint64_t factor = 1U + next_random(state) % 7U;
      const PreparedQuery scaled = prepare_query(
          fixture, scaled_values(primary_values, factor), eligibility);
      const OracleOptimum scaled_expected =
          crossbar_oracle(fixture, scaled);
      const mwperf::OptimizerSolution scaled_actual =
          solve_production(fixture, scaled);
      check_solution(scaled_actual, scaled_expected,
                     mwperf::ServiceFamily::crossbar_matching,
                     mwperf::OptimizerId::hungarian_exact);
      CHECK(std::ranges::equal(scaled_expected.bits, expected.bits));
      CHECK(scaled_expected.primary ==
            expected.primary * mwperf::BigNat(factor));
      if (expected.primary_maximizers == 1U) {
        CHECK(std::ranges::equal(scaled_actual.schedule().bytes(),
                                 actual.schedule().bytes()));
      }
    }
  }
}

TEST_CASE("C06 random exact intervals agree with exhaustive subset oracles",
          "[c06][property][interval]") {
  std::uint64_t state = 0x94d049bb133111ebULL;

  for (std::size_t queue_count = 1U; queue_count <= 8U; ++queue_count) {
    for (std::size_t trial = 0U; trial < 5U; ++trial) {
      std::vector<IntervalLexemes> intervals;
      intervals.reserve(queue_count);
      for (std::size_t queue = 0U; queue < queue_count; ++queue) {
        const int left_ticks =
            static_cast<int>(next_random(state) % 33U) - 16;
        const int width_ticks =
            1 + static_cast<int>(next_random(state) % 12U);
        intervals.push_back(IntervalLexemes{
            quarter_lexeme(left_ticks),
            quarter_lexeme(left_ticks + width_ticks)});
      }
      std::vector<std::size_t> authored_order(queue_count);
      std::iota(authored_order.begin(), authored_order.end(),
                std::size_t{0U});
      deterministic_shuffle(authored_order, state);
      const std::vector<std::size_t> priority =
          random_priority(queue_count, state);
      const OptimizerFixture fixture = make_fixture(
          queue_count,
          interval_scheduler(intervals, authored_order, priority));

      std::vector<mwperf::BigNat> primary_values;
      std::vector<std::uint8_t> eligibility;
      primary_values.reserve(queue_count);
      eligibility.reserve(queue_count);
      for (std::size_t queue = 0U; queue < queue_count; ++queue) {
        primary_values.emplace_back(next_random(state) % 32U);
        eligibility.push_back(static_cast<std::uint8_t>(
            (next_random(state) & std::uint64_t{3U}) != 0U));
      }

      const PreparedQuery query =
          prepare_query(fixture, primary_values, eligibility);
      const OracleOptimum expected = interval_oracle(fixture, query);
      const mwperf::OptimizerSolution actual =
          solve_production(fixture, query);
      INFO(queue_count);
      INFO(trial);
      check_solution(actual, expected,
                     mwperf::ServiceFamily::nonoverlapping_intervals,
                     mwperf::OptimizerId::weighted_interval_dp_exact);
      check_interval_predecessors(fixture);

      const std::uint64_t factor = 1U + next_random(state) % 7U;
      const PreparedQuery scaled = prepare_query(
          fixture, scaled_values(primary_values, factor), eligibility);
      const OracleOptimum scaled_expected = interval_oracle(fixture, scaled);
      const mwperf::OptimizerSolution scaled_actual =
          solve_production(fixture, scaled);
      check_solution(scaled_actual, scaled_expected,
                     mwperf::ServiceFamily::nonoverlapping_intervals,
                     mwperf::OptimizerId::weighted_interval_dp_exact);
      CHECK(std::ranges::equal(scaled_expected.bits, expected.bits));
      CHECK(scaled_expected.primary ==
            expected.primary * mwperf::BigNat(factor));
      if (expected.primary_maximizers == 1U) {
        CHECK(std::ranges::equal(scaled_actual.schedule().bytes(),
                                 actual.schedule().bytes()));
      }
    }
  }
}

TEST_CASE("C06 structural relabeling and authored permutation preserve bits",
          "[c06][property][invariance]") {
  SECTION("crossbar port labels") {
    const std::vector<CrossbarEndpoint> edges{
        {0U, 0U}, {0U, 2U}, {1U, 1U},
        {2U, 0U}, {2U, 2U}, {1U, 3U},
    };
    const std::vector<std::size_t> priority{2U, 5U, 1U, 4U, 0U, 3U};
    const OptimizerFixture original = make_fixture(
        edges.size(), crossbar_scheduler(edges, priority,
                                          {"i0", "i1", "i2"},
                                          {"o0", "o1", "o2", "o3"}));
    const OptimizerFixture relabeled = make_fixture(
        edges.size(),
        crossbar_scheduler(edges, priority,
                           {"north", "amber", "port_z"},
                           {"egress_c", "egress_a", "egress_d", "egress_b"}));
    const std::vector<mwperf::BigNat> primary{
        mwperf::BigNat(9U),  mwperf::BigNat(4U), mwperf::BigNat(8U),
        mwperf::BigNat(13U), mwperf::BigNat(7U), mwperf::BigNat(5U),
    };
    const std::vector<std::uint8_t> eligibility{1U, 1U, 1U, 1U, 1U, 1U};
    const PreparedQuery original_query =
        prepare_query(original, primary, eligibility);
    const PreparedQuery relabeled_query =
        prepare_query(relabeled, primary, eligibility);
    const auto original_solution = solve_production(original, original_query);
    const auto relabeled_solution =
        solve_production(relabeled, relabeled_query);
    check_solution(original_solution, crossbar_oracle(original, original_query),
                   mwperf::ServiceFamily::crossbar_matching,
                   mwperf::OptimizerId::hungarian_exact);
    check_solution(relabeled_solution,
                   crossbar_oracle(relabeled, relabeled_query),
                   mwperf::ServiceFamily::crossbar_matching,
                   mwperf::OptimizerId::hungarian_exact);
    CHECK(std::ranges::equal(original_solution.schedule().bytes(),
                             relabeled_solution.schedule().bytes()));
  }

  SECTION("interval authored order") {
    const std::vector<IntervalLexemes> intervals{
        {"-2.5", "-1"}, {"-1", "0.5"}, {"-0.25", "1.25"},
        {"0.5", "2"},   {"1.25", "2.5"}, {"2.5", "3"},
    };
    const std::vector<std::size_t> priority{2U, 5U, 1U, 4U, 0U, 3U};
    const OptimizerFixture original = make_fixture(
        intervals.size(),
        interval_scheduler(intervals, {0U, 1U, 2U, 3U, 4U, 5U}, priority));
    const OptimizerFixture permuted = make_fixture(
        intervals.size(),
        interval_scheduler(intervals, {4U, 1U, 5U, 0U, 3U, 2U}, priority));
    const std::vector<mwperf::BigNat> primary{
        mwperf::BigNat(3U),  mwperf::BigNat(5U),  mwperf::BigNat(7U),
        mwperf::BigNat(11U), mwperf::BigNat(13U), mwperf::BigNat(17U),
    };
    const std::vector<std::uint8_t> eligibility{1U, 1U, 1U, 1U, 1U, 1U};
    const PreparedQuery original_query =
        prepare_query(original, primary, eligibility);
    const PreparedQuery permuted_query =
        prepare_query(permuted, primary, eligibility);
    const auto original_solution = solve_production(original, original_query);
    const auto permuted_solution = solve_production(permuted, permuted_query);
    check_solution(original_solution, interval_oracle(original, original_query),
                   mwperf::ServiceFamily::nonoverlapping_intervals,
                   mwperf::OptimizerId::weighted_interval_dp_exact);
    check_solution(permuted_solution, interval_oracle(permuted, permuted_query),
                   mwperf::ServiceFamily::nonoverlapping_intervals,
                   mwperf::OptimizerId::weighted_interval_dp_exact);
    CHECK(std::ranges::equal(original_solution.schedule().bytes(),
                             permuted_solution.schedule().bytes()));
    check_interval_predecessors(original);
    check_interval_predecessors(permuted);
  }
}

TEST_CASE("C06 configured priority exactly refines tied primary optima",
          "[c06][property][priority]") {
  SECTION("crossbar matching face") {
    const std::vector<CrossbarEndpoint> edges{
        {0U, 0U}, {0U, 1U}, {1U, 0U}, {1U, 1U}};
    const OptimizerFixture diagonal = make_fixture(
        edges.size(), crossbar_scheduler(edges, {0U, 3U, 1U, 2U},
                                          {"i0", "i1"}, {"o0", "o1"}));
    const OptimizerFixture off_diagonal = make_fixture(
        edges.size(), crossbar_scheduler(edges, {1U, 2U, 0U, 3U},
                                          {"i0", "i1"}, {"o0", "o1"}));
    const std::vector<mwperf::BigNat> primary(
        edges.size(), mwperf::BigNat(std::uint64_t{1U}));
    const std::vector<std::uint8_t> eligibility(edges.size(), 1U);
    const PreparedQuery diagonal_query =
        prepare_query(diagonal, primary, eligibility);
    const PreparedQuery off_diagonal_query =
        prepare_query(off_diagonal, primary, eligibility);
    const OracleOptimum diagonal_expected =
        crossbar_oracle(diagonal, diagonal_query);
    const OracleOptimum off_diagonal_expected =
        crossbar_oracle(off_diagonal, off_diagonal_query);
    const auto diagonal_actual = solve_production(diagonal, diagonal_query);
    const auto off_diagonal_actual =
        solve_production(off_diagonal, off_diagonal_query);
    check_solution(diagonal_actual, diagonal_expected,
                   mwperf::ServiceFamily::crossbar_matching,
                   mwperf::OptimizerId::hungarian_exact);
    check_solution(off_diagonal_actual, off_diagonal_expected,
                   mwperf::ServiceFamily::crossbar_matching,
                   mwperf::OptimizerId::hungarian_exact);
    CHECK(diagonal_expected.primary == off_diagonal_expected.primary);
    CHECK_FALSE(std::ranges::equal(diagonal_actual.schedule().bytes(),
                                   off_diagonal_actual.schedule().bytes()));
  }

  SECTION("interval scheduling face") {
    const std::vector<IntervalLexemes> intervals{
        {"0", "2"}, {"0", "1"}, {"1", "2"}};
    const OptimizerFixture long_first = make_fixture(
        intervals.size(),
        interval_scheduler(intervals, {0U, 1U, 2U}, {0U, 1U, 2U}));
    const OptimizerFixture pieces_first = make_fixture(
        intervals.size(),
        interval_scheduler(intervals, {2U, 0U, 1U}, {1U, 2U, 0U}));
    const std::vector<mwperf::BigNat> primary{
        mwperf::BigNat(2U), mwperf::BigNat(1U), mwperf::BigNat(1U)};
    const std::vector<std::uint8_t> eligibility{1U, 1U, 1U};
    const PreparedQuery long_query =
        prepare_query(long_first, primary, eligibility);
    const PreparedQuery pieces_query =
        prepare_query(pieces_first, primary, eligibility);
    const OracleOptimum long_expected =
        interval_oracle(long_first, long_query);
    const OracleOptimum pieces_expected =
        interval_oracle(pieces_first, pieces_query);
    const auto long_actual = solve_production(long_first, long_query);
    const auto pieces_actual = solve_production(pieces_first, pieces_query);
    check_solution(long_actual, long_expected,
                   mwperf::ServiceFamily::nonoverlapping_intervals,
                   mwperf::OptimizerId::weighted_interval_dp_exact);
    check_solution(pieces_actual, pieces_expected,
                   mwperf::ServiceFamily::nonoverlapping_intervals,
                   mwperf::OptimizerId::weighted_interval_dp_exact);
    CHECK(long_expected.primary == pieces_expected.primary);
    CHECK_FALSE(std::ranges::equal(long_actual.schedule().bytes(),
                                   pieces_actual.schedule().bytes()));
  }
}
