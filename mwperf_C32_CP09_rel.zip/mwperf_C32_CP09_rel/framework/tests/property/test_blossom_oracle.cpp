#include <algorithm>
#include <atomic>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <numeric>
#include <optional>
#include <ranges>
#include <sstream>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct LabelledEdge final {
  std::size_t first;
  std::size_t second;
};

struct NodeFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

struct PreparedQuery final {
  mwperf::PrimaryWeights primary;
  mwperf::EligibilityMask eligibility;
  mwperf::LexWeights weights;
};

struct OracleOptimum final {
  std::vector<std::uint8_t> bits;
  mwperf::BigNat composite;
  mwperf::BigNat primary;
  std::size_t primary_maximizers;
  std::size_t composite_maximizers;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c07-blossom-property";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) +
                     ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] std::vector<std::string> labels(const std::string& prefix,
                                              const std::size_t count) {
  std::vector<std::string> result;
  result.reserve(count);
  for (std::size_t index = 0U; index < count; ++index) {
    result.push_back(prefix + std::to_string(index));
  }
  return result;
}

[[nodiscard]] std::string quoted_array(
    const std::vector<std::string>& values) {
  std::ostringstream output;
  output << '[';
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (index != 0U) {
      output << ',';
    }
    output << '"' << values[index] << '"';
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string priority_json(
    const std::vector<std::size_t>& priority) {
  std::vector<std::string> ids;
  ids.reserve(priority.size());
  for (const std::size_t queue : priority) {
    ids.push_back("q" + std::to_string(queue));
  }
  return quoted_array(ids);
}

[[nodiscard]] std::string node_scheduler(
    const std::vector<LabelledEdge>& edges,
    const std::vector<std::size_t>& authored_order,
    const std::vector<std::size_t>& priority,
    const std::vector<std::string>& vertex_names,
    const std::vector<std::size_t>& vertex_order,
    const bool reverse_endpoints) {
  std::vector<std::string> declared_vertices;
  declared_vertices.reserve(vertex_order.size());
  for (const std::size_t vertex : vertex_order) {
    REQUIRE(vertex < vertex_names.size());
    declared_vertices.push_back(vertex_names[vertex]);
  }

  std::ostringstream link_json;
  link_json << '[';
  for (std::size_t position = 0U; position < authored_order.size();
       ++position) {
    const std::size_t queue = authored_order[position];
    REQUIRE(queue < edges.size());
    REQUIRE(edges[queue].first < vertex_names.size());
    REQUIRE(edges[queue].second < vertex_names.size());
    if (position != 0U) {
      link_json << ',';
    }
    const std::size_t first = reverse_endpoints ? edges[queue].second
                                                : edges[queue].first;
    const std::size_t second = reverse_endpoints ? edges[queue].first
                                                 : edges[queue].second;
    link_json << "{\"queue_id\":\"q" << queue << "\",\"u\":\""
              << vertex_names[first] << "\",\"v\":\""
              << vertex_names[second] << "\"}";
  }
  link_json << ']';
  return R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":)" +
         quoted_array(declared_vertices) + R"(,"links":)" +
         link_json.str() + R"(},"priority":)" + priority_json(priority) +
         R"(}})";
}

[[nodiscard]] NodeFixture make_fixture(const std::size_t queue_count,
                                       const std::string& scheduler) {
  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      quoted_array(labels("q", queue_count)) + R"(},"scheduler":)" +
      scheduler +
      R"(,"arrival":{"family":"deterministic_trace","events":[]}})";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(priority);
  auto descriptor = mwperf::compile_constraint_descriptor(
      model.value().scheduler, catalog.value());
  INFO((descriptor ? std::string{} : descriptor.error().code));
  REQUIRE(descriptor);
  return NodeFixture{std::move(catalog).value(),
                     std::move(priority).value(),
                     std::move(descriptor).value()};
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::Digest256 fixture_digest() {
  auto result = mwperf::Digest256::from_hex(std::string(64U, '7'));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueDimensionToken dimension(
    const NodeFixture& fixture) {
  return mwperf::QueueDimensionToken::for_fixture(
      fixture_digest(), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] PreparedQuery prepare_query(
    const NodeFixture& fixture,
    const std::vector<mwperf::BigNat>& primary_values,
    const std::vector<std::uint8_t>& eligibility_values) {
  auto primary = mwperf::PrimaryWeights::from_values(
      dimension(fixture), primary_values);
  auto eligibility = mwperf::EligibilityMask::from_bytes(
      dimension(fixture), eligibility_values);
  REQUIRE(primary);
  REQUIRE(eligibility);
  auto weights = mwperf::compose_lexicographic_weights(
      primary.value(), fixture.priority, eligibility.value());
  REQUIRE(weights);
  return PreparedQuery{std::move(primary).value(),
                       std::move(eligibility).value(),
                       std::move(weights).value()};
}

[[nodiscard]] mwperf::OptimizerSolution solve_production(
    const NodeFixture& fixture, const PreparedQuery& query) {
  auto context_result = mwperf::OptimizerExecutionContext::for_fixture(
      unlimited_policy(), std::nullopt, query.weights.dimension());
  REQUIRE(context_result);
  auto context = std::move(context_result).value();
  auto budget = mwperf::begin_search_budget(context);
  REQUIRE(budget);
  REQUIRE(
      budget.value().set_query_kind(mwperf::OptimizerQueryKind::ordinary));
  auto solution = mwperf::solve_exact(fixture.descriptor, query.eligibility,
                                      query.weights, budget.value());
  INFO((solution ? std::string{} : solution.error().code));
  REQUIRE(solution);
  auto validation = mwperf::validate_optimizer_solution(
      solution.value(), fixture.descriptor, query.eligibility,
      query.weights);
  INFO((validation ? std::string{} : validation.error().code));
  REQUIRE(validation);
  CHECK(solution.value().accounting().completed_expansions().is_zero());
  return std::move(solution).value();
}

[[nodiscard]] bool feasible(
    const mwperf::ResolvedNodeExclusiveConstraint& constraint,
    const std::vector<std::uint8_t>& selected) {
  std::vector<std::uint8_t> used(constraint.vertices.size(), 0U);
  for (const mwperf::ResolvedNodeExclusiveLink& link : constraint.links) {
    if (selected[link.queue.ordinal()] == 0U) {
      continue;
    }
    const std::size_t first = link.u.ordinal();
    const std::size_t second = link.v.ordinal();
    if (used[first] != 0U || used[second] != 0U) {
      return false;
    }
    used[first] = 1U;
    used[second] = 1U;
  }
  return true;
}

[[nodiscard]] OracleOptimum enumerate_optimum(
    const NodeFixture& fixture, const PreparedQuery& query) {
  REQUIRE(query.weights.size() <= 8U);
  const auto& constraint =
      std::get<mwperf::ResolvedNodeExclusiveConstraint>(
          fixture.descriptor.value());
  const std::uint64_t subset_count =
      std::uint64_t{1U} << query.weights.size();
  OracleOptimum result{
      std::vector<std::uint8_t>(query.weights.size(), 0U),
      mwperf::BigNat(0U), mwperf::BigNat(0U), 0U, 0U};
  bool composite_initialized = false;
  bool primary_initialized = false;

  for (std::uint64_t subset = 0U; subset < subset_count; ++subset) {
    std::vector<std::uint8_t> candidate(query.weights.size(), 0U);
    mwperf::BigNat composite(0U);
    mwperf::BigNat primary(0U);
    bool allowed = true;
    for (std::size_t queue = 0U; queue < query.weights.size(); ++queue) {
      candidate[queue] =
          static_cast<std::uint8_t>((subset >> queue) & 1U);
      if (candidate[queue] == 0U) {
        continue;
      }
      if (query.eligibility.bytes()[queue] == 0U) {
        allowed = false;
        break;
      }
      composite += query.weights.values()[queue];
      primary += query.primary.values()[queue];
    }
    if (!allowed || !feasible(constraint, candidate)) {
      continue;
    }
    if (!primary_initialized || primary > result.primary) {
      result.primary = primary;
      result.primary_maximizers = 1U;
      primary_initialized = true;
    } else if (primary == result.primary) {
      ++result.primary_maximizers;
    }
    if (!composite_initialized || composite > result.composite) {
      result.bits = std::move(candidate);
      result.composite = composite;
      result.composite_maximizers = 1U;
      composite_initialized = true;
    } else if (composite == result.composite) {
      ++result.composite_maximizers;
    }
  }
  REQUIRE(composite_initialized);
  REQUIRE(primary_initialized);
  return result;
}

[[nodiscard]] std::uint64_t next_random(std::uint64_t& state) {
  state = state * 6364136223846793005ULL + 1442695040888963407ULL;
  return state;
}

template <typename Value>
void deterministic_shuffle(std::vector<Value>& values,
                           std::uint64_t& state) {
  for (std::size_t end = values.size(); end > 1U; --end) {
    const std::size_t other =
        static_cast<std::size_t>(next_random(state) % end);
    std::swap(values[end - 1U], values[other]);
  }
}

[[nodiscard]] std::vector<std::size_t> identity_order(
    const std::size_t count) {
  std::vector<std::size_t> result(count);
  std::iota(result.begin(), result.end(), std::size_t{0U});
  return result;
}

[[nodiscard]] std::vector<mwperf::BigNat> scaled_values(
    const std::vector<mwperf::BigNat>& values, const std::uint64_t factor) {
  std::vector<mwperf::BigNat> result;
  result.reserve(values.size());
  for (const auto& value : values) {
    result.push_back(value * mwperf::BigNat(factor));
  }
  return result;
}

void check_solution(const mwperf::OptimizerSolution& actual,
                    const OracleOptimum& expected) {
  CHECK(expected.composite_maximizers == 1U);
  CHECK(std::ranges::equal(actual.schedule().bytes(), expected.bits));
  CHECK(actual.composite_objective() == expected.composite);
  CHECK(actual.family() == mwperf::ServiceFamily::node_exclusive_matching);
  CHECK(actual.backend_id() == mwperf::OptimizerId::edmonds_blossom_exact);
}

[[nodiscard]] mwperf::BigNat vertex_subset_optimum(
    const mwperf::RepresentativeGraph& graph) {
  REQUIRE(graph.vertex_count() < 16U);
  const std::uint64_t full =
      (std::uint64_t{1U} << graph.vertex_count()) - 1U;
  std::vector<std::optional<mwperf::BigNat>> memo(
      static_cast<std::size_t>(full + 1U));
  std::function<mwperf::BigNat(std::uint64_t)> solve =
      [&](const std::uint64_t remaining) -> mwperf::BigNat {
    if (remaining == 0U) {
      return mwperf::BigNat(0U);
    }
    auto& cell = memo[static_cast<std::size_t>(remaining)];
    if (cell.has_value()) {
      return *cell;
    }
    const std::size_t vertex =
        static_cast<std::size_t>(std::countr_zero(remaining));
    const std::uint64_t without_vertex =
        remaining & ~(std::uint64_t{1U} << vertex);
    mwperf::BigNat best = solve(without_vertex);
    for (const auto& edge : graph.edges()) {
      std::optional<std::size_t> other;
      if (edge.first == vertex) {
        other = edge.second;
      } else if (edge.second == vertex) {
        other = edge.first;
      }
      if (!other.has_value() ||
          (without_vertex & (std::uint64_t{1U} << *other)) == 0U) {
        continue;
      }
      const std::uint64_t residual =
          without_vertex & ~(std::uint64_t{1U} << *other);
      mwperf::BigNat candidate = edge.weight + solve(residual);
      if (candidate > best) {
        best = std::move(candidate);
      }
    }
    cell = best;
    return best;
  };
  return solve(full);
}

}  // namespace

TEST_CASE("C07 random labelled multigraphs agree with exhaustive matching enumeration",
          "[c07][property][blossom][oracle]") {
  std::uint64_t state = 0xa0761d6478bd642fULL;
  for (std::size_t queue_count = 1U; queue_count <= 8U; ++queue_count) {
    for (std::size_t trial = 0U; trial < 6U; ++trial) {
      const std::size_t vertex_count =
          2U + static_cast<std::size_t>(next_random(state) % 6U);
      std::vector<LabelledEdge> edges;
      edges.reserve(queue_count);
      for (std::size_t queue = 0U; queue < queue_count; ++queue) {
        const std::size_t first =
            static_cast<std::size_t>(next_random(state) % vertex_count);
        std::size_t second = static_cast<std::size_t>(
            next_random(state) % (vertex_count - 1U));
        if (second >= first) {
          ++second;
        }
        edges.push_back({first, second});
      }
      auto authored = identity_order(queue_count);
      auto priority = identity_order(queue_count);
      deterministic_shuffle(authored, state);
      deterministic_shuffle(priority, state);
      const auto vertices = labels("v", vertex_count);
      const auto fixture = make_fixture(
          queue_count,
          node_scheduler(edges, authored, priority, vertices,
                         identity_order(vertex_count), false));

      std::vector<mwperf::BigNat> primary;
      std::vector<std::uint8_t> eligibility;
      primary.reserve(queue_count);
      eligibility.reserve(queue_count);
      for (std::size_t queue = 0U; queue < queue_count; ++queue) {
        primary.emplace_back(next_random(state) % 32U);
        eligibility.push_back(static_cast<std::uint8_t>(
            (next_random(state) & std::uint64_t{3U}) != 0U));
      }
      const auto query = prepare_query(fixture, primary, eligibility);
      const auto expected = enumerate_optimum(fixture, query);
      const auto actual = solve_production(fixture, query);
      INFO(queue_count);
      INFO(trial);
      check_solution(actual, expected);

      const std::uint64_t factor = 1U + next_random(state) % 7U;
      const auto scaled = prepare_query(
          fixture, scaled_values(primary, factor), eligibility);
      const auto scaled_expected = enumerate_optimum(fixture, scaled);
      const auto scaled_actual = solve_production(fixture, scaled);
      check_solution(scaled_actual, scaled_expected);
      CHECK(std::ranges::equal(scaled_expected.bits, expected.bits));
      CHECK(scaled_expected.primary ==
            expected.primary * mwperf::BigNat(factor));
      CHECK(std::ranges::equal(scaled_actual.schedule().bytes(),
                               actual.schedule().bytes()));
    }
  }
}

TEST_CASE("C07 raw Blossom objectives agree with an independent vertex-subset DP",
          "[c07][property][blossom][subset-dp]") {
  std::uint64_t state = 0xe7037ed1a0b428dbULL;
  for (std::size_t trial = 0U; trial < 30U; ++trial) {
    const std::size_t vertex_count =
        2U + static_cast<std::size_t>(next_random(state) % 8U);
    std::vector<LabelledEdge> all_pairs;
    for (std::size_t first = 0U; first < vertex_count; ++first) {
      for (std::size_t second = first + 1U; second < vertex_count;
           ++second) {
        all_pairs.push_back({first, second});
      }
    }
    deterministic_shuffle(all_pairs, state);
    const std::size_t edge_count =
        1U + static_cast<std::size_t>(next_random(state) %
                                     std::min<std::size_t>(8U,
                                                           all_pairs.size()));
    all_pairs.resize(edge_count);
    const auto fixture = make_fixture(
        edge_count,
        node_scheduler(all_pairs, identity_order(edge_count),
                       identity_order(edge_count), labels("v", vertex_count),
                       identity_order(vertex_count), false));
    std::vector<mwperf::BigNat> primary;
    primary.reserve(edge_count);
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      primary.emplace_back(1U + next_random(state) % 100U);
    }
    const std::vector<std::uint8_t> eligibility(edge_count, 1U);
    const auto query = prepare_query(fixture, primary, eligibility);
    const auto& constraint =
        std::get<mwperf::ResolvedNodeExclusiveConstraint>(
            fixture.descriptor.value());
    auto problem = mwperf::compile_node_exclusive_problem(constraint);
    REQUIRE(problem);
    auto graph = mwperf::select_parallel_link_representatives(
        problem.value(), query.eligibility, query.weights);
    REQUIRE(graph);
    auto matching = mwperf::detail::solve_blossom_exact(graph.value());
    REQUIRE(matching);
    INFO(trial);
    CHECK(matching.value().objective() ==
          vertex_subset_optimum(graph.value()));
  }
}

TEST_CASE("C07 vertex relabeling endpoint reversal and authored permutations preserve queue bits",
          "[c07][property][blossom][invariance]") {
  const std::vector<LabelledEdge> edges{
      {0U, 1U}, {1U, 0U}, {1U, 2U}, {2U, 3U},
      {3U, 4U}, {4U, 0U}, {1U, 4U}};
  const std::vector<std::size_t> priority{4U, 1U, 6U, 0U, 3U, 5U, 2U};
  const std::vector<std::string> original_names{
      "v0", "v1", "v2", "v3", "v4", "isolated"};
  const std::vector<std::string> relabeled_names{
      "north", "amber", "west", "delta", "east", "alone"};
  const auto original = make_fixture(
      edges.size(),
      node_scheduler(edges, identity_order(edges.size()), priority,
                     original_names, identity_order(original_names.size()),
                     false));
  const auto transformed = make_fixture(
      edges.size(),
      node_scheduler(edges, {5U, 2U, 0U, 6U, 1U, 4U, 3U}, priority,
                     relabeled_names, {3U, 5U, 1U, 4U, 0U, 2U}, true));
  const std::vector<mwperf::BigNat> primary{
      mwperf::BigNat(7U),  mwperf::BigNat(7U), mwperf::BigNat(13U),
      mwperf::BigNat(11U), mwperf::BigNat(9U), mwperf::BigNat(17U),
      mwperf::BigNat(5U)};
  const std::vector<std::uint8_t> eligibility(edges.size(), 1U);
  const auto original_query = prepare_query(original, primary, eligibility);
  const auto transformed_query =
      prepare_query(transformed, primary, eligibility);
  const auto first = solve_production(original, original_query);
  const auto second = solve_production(transformed, transformed_query);
  check_solution(first, enumerate_optimum(original, original_query));
  check_solution(second, enumerate_optimum(transformed, transformed_query));
  CHECK(std::ranges::equal(first.schedule().bytes(),
                           second.schedule().bytes()));
  CHECK(first.composite_objective() == second.composite_objective());
}

TEST_CASE("C07 lower-weight parallel duplicates cannot displace their representative",
          "[c07][property][blossom][parallel]") {
  const std::vector<LabelledEdge> edges{{0U, 1U}, {1U, 0U}, {2U, 3U}};
  const auto fixture = make_fixture(
      edges.size(),
      node_scheduler(edges, {2U, 1U, 0U}, {1U, 0U, 2U},
                     labels("v", 4U), identity_order(4U), false));
  const std::vector<mwperf::BigNat> primary{
      mwperf::BigNat(10U), mwperf::BigNat(4U), mwperf::BigNat(7U)};
  const auto absent_duplicate =
      prepare_query(fixture, primary, {1U, 0U, 1U});
  const auto present_duplicate =
      prepare_query(fixture, primary, {1U, 1U, 1U});
  const auto first = solve_production(fixture, absent_duplicate);
  const auto second = solve_production(fixture, present_duplicate);
  CHECK((std::vector<std::uint8_t>(first.schedule().bytes().begin(),
                                   first.schedule().bytes().end()) ==
         std::vector<std::uint8_t>{1U, 0U, 1U}));
  CHECK(std::ranges::equal(first.schedule().bytes(),
                           second.schedule().bytes()));
}
