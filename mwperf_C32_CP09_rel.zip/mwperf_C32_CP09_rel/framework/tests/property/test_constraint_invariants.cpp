#include <algorithm>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace mwperf {
namespace {

class PropertyFixtureFile final {
 public:
  explicit PropertyFixtureFile(const std::string_view contents) {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
        "c04-constraint-property";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    if (error) {
      throw std::runtime_error("failed to create C04 property fixture path");
    }
    path_ = directory /
            ("property-" + std::to_string(next_id.fetch_add(1U)) + ".json");
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    if (!output.is_open()) {
      throw std::runtime_error("failed to open C04 property fixture");
    }
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output.good()) {
      throw std::runtime_error("failed to write C04 property fixture");
    }
  }

  PropertyFixtureFile(const PropertyFixtureFile&) = delete;
  PropertyFixtureFile& operator=(const PropertyFixtureFile&) = delete;

  ~PropertyFixtureFile() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

struct PropertyConstraint final {
  QueueCatalog catalog;
  ConstraintDescriptor descriptor;
};

[[nodiscard]] Result<CompiledConstraintProduct> property_product(
    const ServiceFamily family) {
  std::shared_ptr<const void> owner =
      std::make_shared<const std::string>(std::string(to_string(family)));
  return CompiledConstraintProduct::for_fixture(family, std::move(owner));
}

[[nodiscard]] detail::ConstraintCompilerServices property_compilers() {
  return detail::ConstraintCompilerServices{
      .crossbar = [](const ResolvedCrossbarConstraint&) {
        return property_product(ServiceFamily::crossbar_matching);
      },
      .intervals = [](const ResolvedIntervalConstraint&) {
        return property_product(ServiceFamily::nonoverlapping_intervals);
      },
      .node_exclusive = [](const ResolvedNodeExclusiveConstraint&) {
        return property_product(ServiceFamily::node_exclusive_matching);
      },
      .conflicts = [](const ResolvedConflictConstraint&) {
        return property_product(ServiceFamily::pairwise_conflicts);
      },
      .packing = [](const ResolvedPackingConstraint&) {
        return property_product(ServiceFamily::resource_packing);
      },
  };
}

[[nodiscard]] std::string model_text(const std::string_view queues,
                                     const std::string_view scheduler) {
  return std::string{"{"} +
         R"("switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
         std::string{queues} + R"(},"scheduler":)" + std::string{scheduler} +
         R"(,"arrival":{"family":"deterministic_trace","events":[]}})";
}

[[nodiscard]] Result<PropertyConstraint> compile_property_model(
    const std::string& text) {
  PropertyFixtureFile file(text);
  auto document = load_document(file.path());
  if (!document) {
    return Result<PropertyConstraint>::failure(std::move(document.error()));
  }
  auto model_node = extract_executable_model(document.value());
  if (!model_node) {
    return Result<PropertyConstraint>::failure(std::move(model_node.error()));
  }
  auto model = parse_model_config_v3(model_node.value());
  if (!model) {
    return Result<PropertyConstraint>::failure(std::move(model.error()));
  }
  auto catalog = build_queue_catalog(model.value().switch_config);
  if (!catalog) {
    return Result<PropertyConstraint>::failure(std::move(catalog.error()));
  }
  const detail::ConstraintCompilerServices children = property_compilers();
  auto descriptor = detail::compile_constraint_descriptor_with_child_services(
      model.value().scheduler, catalog.value(), children);
  if (!descriptor) {
    return Result<PropertyConstraint>::failure(std::move(descriptor.error()));
  }
  return Result<PropertyConstraint>::success(
      PropertyConstraint{std::move(catalog).value(),
                         std::move(descriptor).value()});
}

}  // namespace

TEST_CASE("C04 bijective relabeling preserves crossbar dense geometry",
          "[c04][property][constraint]") {
  auto first = compile_property_model(model_text(
      R"([1,"one","third"])",
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":1,"input":"i0","output":"o0"},{"queue_id":"one","input":"i0","output":"o1"},{"queue_id":"third","input":"i1","output":"o0"}]},"priority":null}})"));
  auto relabeled = compile_property_model(model_text(
      R"(["alpha",9,"omega"])",
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":[0,1],"outputs":["x","y"],"edges":[{"queue_id":"alpha","input":0,"output":"x"},{"queue_id":9,"input":0,"output":"y"},{"queue_id":"omega","input":1,"output":"x"}]},"priority":null}})"));
  REQUIRE(first);
  REQUIRE(relabeled);
  const auto& left =
      std::get<ResolvedCrossbarConstraint>(first.value().descriptor.value());
  const auto& right = std::get<ResolvedCrossbarConstraint>(
      relabeled.value().descriptor.value());
  REQUIRE(left.edges.size() == right.edges.size());
  for (std::size_t index = 0U; index < left.edges.size(); ++index) {
    CHECK(left.edges[index].queue.ordinal() ==
          right.edges[index].queue.ordinal());
    CHECK(left.edges[index].input.ordinal() ==
          right.edges[index].input.ordinal());
    CHECK(left.edges[index].output.ordinal() ==
          right.edges[index].output.ordinal());
  }
  CHECK(compute_individual_serviceability(first.value().descriptor).all());
  CHECK(compute_individual_serviceability(relabeled.value().descriptor).all());
}

TEST_CASE("C04 queue-order permutation induces the same dense permutation",
          "[c04][property][constraint]") {
  auto original = compile_property_model(model_text(
      R"(["a","b","c"])",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"a","left":0,"right":1},{"queue_id":"b","left":1,"right":2},{"queue_id":"c","left":2,"right":3}]},"priority":null}})"));
  auto permuted = compile_property_model(model_text(
      R"(["c","a","b"])",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"a","left":0,"right":1},{"queue_id":"b","left":1,"right":2},{"queue_id":"c","left":2,"right":3}]},"priority":null}})"));
  REQUIRE(original);
  REQUIRE(permuted);
  const auto& left =
      std::get<ResolvedIntervalConstraint>(original.value().descriptor.value());
  const auto& right =
      std::get<ResolvedIntervalConstraint>(permuted.value().descriptor.value());
  REQUIRE(left.intervals.size() == 3U);
  REQUIRE(right.intervals.size() == 3U);
  CHECK(left.intervals[0].queue.ordinal() == 0U);
  CHECK(left.intervals[1].queue.ordinal() == 1U);
  CHECK(left.intervals[2].queue.ordinal() == 2U);
  CHECK(right.intervals[0].queue.ordinal() == 1U);
  CHECK(right.intervals[1].queue.ordinal() == 2U);
  CHECK(right.intervals[2].queue.ordinal() == 0U);
  for (std::size_t index = 0U; index < 3U; ++index) {
    CHECK(left.intervals[index].left == right.intervals[index].left);
    CHECK(left.intervals[index].right == right.intervals[index].right);
  }
}

TEST_CASE("C04 every bound nonpacking singleton is serviceable",
          "[c04][property][constraint]") {
  const std::vector<std::string> schedulers{
      R"({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":["o"],"edges":[{"queue_id":"q","input":"i","output":"o"}]},"priority":null}})",
      R"({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q","left":-0.0000000000000000001,"right":0}]},"priority":null}})",
      R"({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v"],"links":[{"queue_id":"q","u":"u","v":"v"}]},"priority":null}})",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":null,"max_search_states":null}})"};

  for (const std::string& scheduler : schedulers) {
    auto compiled =
        compile_property_model(model_text(R"(["q"])", scheduler));
    INFO((compiled ? std::string{} : compiled.error().code));
    REQUIRE(compiled);
    const ServiceableMask singleton =
        compute_individual_serviceability(compiled.value().descriptor);
    REQUIRE(singleton.size() == 1U);
    CHECK(singleton.all());
    CHECK(singleton.at(compiled.value().catalog.index_at(0U).value()));
  }
}

TEST_CASE("C04 packing singleton serviceability equals exact demand capacity",
          "[c04][property][constraint]") {
  for (unsigned int capacity = 0U; capacity <= 7U; ++capacity) {
    for (unsigned int demand = 0U; demand <= 9U; ++demand) {
      const std::string scheduler =
          R"({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[)" +
          std::to_string(capacity) +
          R"(],"demands":[{"queue_id":"q","demand":[)" +
          std::to_string(demand) +
          R"(]}]},"priority":null,"max_search_states":null}})";
      auto compiled =
          compile_property_model(model_text(R"(["q"])", scheduler));
      INFO("capacity=" << capacity << " demand=" << demand);
      REQUIRE(compiled);
      const ServiceableMask serviceable =
          compute_individual_serviceability(compiled.value().descriptor);
      CHECK(serviceable.all() == (demand <= capacity));
    }
  }
}

TEST_CASE("C04 canonical conflict pairs are simple and symmetric",
          "[c04][property][constraint]") {
  auto compiled = compile_property_model(model_text(
      R"(["q0","q1","q2","q3"])",
      R"({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q3","q0"],["q2","q1"],["q3","q2"]]},"priority":null,"max_search_states":null}})"));
  REQUIRE(compiled);
  const auto& conflict = std::get<ResolvedConflictConstraint>(
      compiled.value().descriptor.value());
  for (const ResolvedConflictPair& pair : conflict.conflicts) {
    CHECK(pair.first.ordinal() < pair.second.ordinal());
    const auto& first_neighbors = conflict.adjacency[pair.first.ordinal()];
    const auto& second_neighbors = conflict.adjacency[pair.second.ordinal()];
    CHECK(std::find(first_neighbors.begin(), first_neighbors.end(),
                    pair.second) != first_neighbors.end());
    CHECK(std::find(second_neighbors.begin(), second_neighbors.end(),
                    pair.first) != second_neighbors.end());
  }
}

}  // namespace mwperf
