#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "mwperf/stationary/suspension.hpp"

namespace {

using mwperf::AuditedResidenceProvider;
using mwperf::BigNat;
using mwperf::EmbeddedKernel;
using mwperf::EventInvariantLaw;
using mwperf::ExactRational;
using mwperf::PositiveFiniteMean;
using mwperf::ReducedStateV1;
using mwperf::StationaryMarkedEdge;
using mwperf::StationaryMarkedEdgeAtomV1;
using mwperf::StationaryStateMassV1;
using mwperf::StationaryTemporalLaw;
using mwperf::StationaryTemporalProjection;
using mwperf::testing::StationaryTemporalAtomInspectionV1;
namespace c21_fixture = mwperf::testing::c21;

static_assert(!std::is_default_constructible_v<EventInvariantLaw>);
static_assert(!std::is_default_constructible_v<PositiveFiniteMean>);
static_assert(!std::is_default_constructible_v<StationaryTemporalLaw>);
static_assert(!std::is_default_constructible_v<StationaryMarkedEdge>);
static_assert(!std::is_default_constructible_v<StationaryTemporalProjection>);
static_assert(!std::is_convertible_v<StationaryMarkedEdge,
                                     StationaryTemporalLaw>);
static_assert(!std::is_convertible_v<StationaryTemporalLaw,
                                     StationaryMarkedEdge>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::compute_mean_residence),
              const EventInvariantLaw&, const mwperf::KernelAccess&>);
static_assert(!std::is_invocable_v<
              decltype(&mwperf::compute_mean_residence),
              const EventInvariantLaw&,
              const mwperf::AuditedSamplerDescriptor&>);

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] ExactRational exact_ratio(const ExactRational& numerator,
                                        const ExactRational& denominator) {
  auto value = mwperf::checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

struct ExactSuspensionAtomOracleV1 final {
  std::size_t event_state_index;
  std::size_t word_index;
  std::size_t offset;
  ReducedStateV1 raw_left_state;
  ReducedStateV1 raw_right_state;
  ExactRational mass;
};

[[nodiscard]] const ExactRational& exact_mean(
    const PositiveFiniteMean& mean) {
  REQUIRE(mean.exact_value().has_value());
  return *mean.exact_value();
}

// This is deliberately independent of C21's latent atom builder: it traverses
// the released C20 kernel in equation-(12.15) order and performs the exact
// rational multiplication and division itself.
[[nodiscard]] std::vector<ExactSuspensionAtomOracleV1>
enumerate_exact_suspension_oracle(const EventInvariantLaw& law,
                                  const PositiveFiniteMean& mean) {
  std::vector<ExactSuspensionAtomOracleV1> atoms;
  const auto rows = law.embedded_kernel().rows();
  for (const auto& event_mass : law.masses()) {
    REQUIRE(event_mass.state_index < rows.size());
    const auto words = rows[event_mass.state_index].word_row.atoms();
    for (std::size_t word_index = 0U; word_index < words.size();
         ++word_index) {
      const auto& word_atom = words[word_index];
      const ExactRational atom_mass = exact_ratio(
          event_mass.exact_mass * word_atom.exact_mass, exact_mean(mean));
      const auto edges = word_atom.word.edges();
      REQUIRE(word_atom.word.length() == BigNat{edges.size()});
      for (std::size_t offset = 0U; offset < edges.size(); ++offset) {
        atoms.push_back({event_mass.state_index, word_index, offset,
                         edges[offset].pre_state(),
                         edges[offset].successor_state(), atom_mass});
      }
    }
  }
  return atoms;
}

[[nodiscard]] std::vector<StationaryTemporalAtomInspectionV1>
inspect_temporal_atoms(const StationaryTemporalLaw& law) {
  return mwperf::testing::C21FixtureAccess::temporal_atoms(law);
}

[[nodiscard]] ExactRational total_mass(
    const std::span<const ExactSuspensionAtomOracleV1> atoms) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.mass;
  }
  return total;
}

[[nodiscard]] ExactRational total_mass(
    const std::span<const StationaryTemporalAtomInspectionV1> atoms) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.exact_mass;
  }
  return total;
}

[[nodiscard]] ExactRational word_start_mass(
    const std::span<const StationaryTemporalAtomInspectionV1> atoms) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    if (atom.residence_offset == BigNat{0U}) {
      total = total + atom.exact_mass;
    }
  }
  return total;
}

[[nodiscard]] bool same_oracle_atom(
    const ExactSuspensionAtomOracleV1& expected,
    const StationaryTemporalAtomInspectionV1& actual) {
  return expected.event_state_index == actual.event_state_index &&
         expected.word_index == actual.word_index &&
         BigNat{expected.offset} == actual.residence_offset &&
         expected.raw_left_state == actual.raw_edge.pre_state() &&
         expected.raw_right_state == actual.raw_edge.successor_state() &&
         expected.mass == actual.exact_mass;
}

void require_exact_enumeration(
    const std::span<const ExactSuspensionAtomOracleV1> expected,
    const std::span<const StationaryTemporalAtomInspectionV1> actual) {
  REQUIRE(actual.size() == expected.size());
  std::vector<bool> consumed(actual.size(), false);
  for (const auto& oracle_atom : expected) {
    std::optional<std::size_t> match;
    for (std::size_t index = 0U; index < actual.size(); ++index) {
      if (!consumed[index] && same_oracle_atom(oracle_atom, actual[index])) {
        match = index;
        break;
      }
    }
    REQUIRE(match.has_value());
    consumed[*match] = true;
  }
  CHECK(std::ranges::all_of(consumed,
                            [](const bool value) { return value; }));
}

struct ExactStateMassOracleV1 final {
  ReducedStateV1 state;
  ExactRational mass;
};

void add_state_mass(std::vector<ExactStateMassOracleV1>& marginal,
                    const ReducedStateV1& state,
                    const ExactRational& mass) {
  const auto existing =
      std::find_if(marginal.begin(), marginal.end(), [&](const auto& atom) {
        return atom.state == state;
      });
  if (existing == marginal.end()) {
    marginal.push_back({state, mass});
  } else {
    existing->mass = existing->mass + mass;
  }
}

[[nodiscard]] std::vector<ExactStateMassOracleV1> edge_marginal(
    const std::span<const StationaryMarkedEdgeAtomV1> atoms,
    const bool left) {
  std::vector<ExactStateMassOracleV1> marginal;
  for (const auto& atom : atoms) {
    add_state_mass(marginal,
                   left ? atom.stationary_left_state
                        : atom.stationary_right_state,
                   atom.exact_mass);
  }
  return marginal;
}

[[nodiscard]] const StationaryStateMassV1* find_state_mass(
    const std::span<const StationaryStateMassV1> marginal,
    const ReducedStateV1& state) {
  const auto found =
      std::find_if(marginal.begin(), marginal.end(), [&](const auto& atom) {
        return atom.state == state;
      });
  return found == marginal.end() ? nullptr : &*found;
}

void require_marginal(
    const std::span<const ExactStateMassOracleV1> expected,
    const std::span<const StationaryStateMassV1> actual) {
  REQUIRE(actual.size() == expected.size());
  for (const auto& atom : expected) {
    const auto* found = find_state_mass(actual, atom.state);
    REQUIRE(found != nullptr);
    CHECK(found->exact_mass == atom.mass);
  }
}

[[nodiscard]] bool same_semantic_edge_atom(
    const StationaryMarkedEdgeAtomV1& left,
    const StationaryMarkedEdgeAtomV1& right) {
  const auto same_phase = [](const mwperf::ArrivalPhase& a,
                             const mwperf::ArrivalPhase& b) {
    const auto a_state = mwperf::arrival_phase_canonical_state(a);
    const auto b_state = mwperf::arrival_phase_canonical_state(b);
    return mwperf::arrival_phase_family(a) ==
               mwperf::arrival_phase_family(b) &&
           a_state.size() == b_state.size() &&
           std::equal(a_state.begin(), a_state.end(), b_state.begin());
  };
  const auto same_batch = [](const mwperf::ArrivalBatch& a,
                             const mwperf::ArrivalBatch& b) {
    if (a.entries().size() != b.entries().size()) {
      return false;
    }
    for (std::size_t index = 0U; index < a.entries().size(); ++index) {
      if (a.entries()[index].queue.ordinal() !=
              b.entries()[index].queue.ordinal() ||
          a.entries()[index].count != b.entries()[index].count) {
        return false;
      }
    }
    return true;
  };
  const auto same_target_backlog = [](
                                       const std::optional<
                                           mwperf::TargetBacklogV1>& a,
                                       const std::optional<
                                           mwperf::TargetBacklogV1>& b) {
    if (a.has_value() != b.has_value()) {
      return false;
    }
    if (!a.has_value()) {
      return true;
    }
    if (a->size() != b->size()) {
      return false;
    }
    for (std::size_t index = 0U; index < a->size(); ++index) {
      if (a->ordered_targets()[index].ordinal() !=
              b->ordered_targets()[index].ordinal() ||
          a->values()[index] != b->values()[index]) {
        return false;
      }
    }
    return true;
  };
  const auto same_schedule = [](const mwperf::Schedule& a,
                                const mwperf::Schedule& b) {
    return a.size() == b.size() &&
           std::equal(a.bytes().begin(), a.bytes().end(), b.bytes().begin());
  };
  const auto same_action_evidence = [](
                                        const mwperf::ResolvedActionEvidenceV1&
                                            a,
                                        const mwperf::ResolvedActionEvidenceV1&
                                            b) {
    if (a.resolution_kind != b.resolution_kind ||
        a.common_feasible_schedule != b.common_feasible_schedule ||
        a.exact_target_class != b.exact_target_class ||
        a.emitted_face.has_value() != b.emitted_face.has_value()) {
      return false;
    }
    if (!a.emitted_face.has_value()) {
      return true;
    }
    const auto& a_face = *a.emitted_face;
    const auto& b_face = *b.emitted_face;
    if (a_face.selected_primary_score != b_face.selected_primary_score ||
        a_face.configured_secondary_code !=
            b_face.configured_secondary_code ||
        a_face.ordered_target_faces.size() !=
            b_face.ordered_target_faces.size()) {
      return false;
    }
    for (std::size_t index = 0U;
         index < a_face.ordered_target_faces.size(); ++index) {
      const auto& a_target = a_face.ordered_target_faces[index];
      const auto& b_target = b_face.ordered_target_faces[index];
      if (a_target.target.ordinal() != b_target.target.ordinal() ||
          a_target.forced_out_residual_max !=
              b_target.forced_out_residual_max ||
          a_target.forced_in_residual_max !=
              b_target.forced_in_residual_max ||
          a_target.algebraic_margin != b_target.algebraic_margin ||
          a_target.exact_class != b_target.exact_class ||
          a_target.target_eligible != b_target.target_eligible) {
        return false;
      }
    }
    return true;
  };
  const auto& left_edge = left.raw_edge;
  const auto& right_edge = right.raw_edge;
  const auto& left_opportunity = left_edge.opportunity();
  const auto& right_opportunity = right_edge.opportunity();
  const auto& left_action = left_edge.action();
  const auto& right_action = right_edge.action();
  const auto& left_arrival = left_edge.arrival();
  const auto& right_arrival = right_edge.arrival();
  const auto& left_post = left_edge.postclosure();
  const auto& right_post = right_edge.postclosure();
  return left.stationary_left_state == right.stationary_left_state &&
         left.stationary_right_state == right.stationary_right_state &&
         same_target_backlog(left_opportunity.prearrival_backlog,
                             right_opportunity.prearrival_backlog) &&
         left_opportunity.resolver_face == right_opportunity.resolver_face &&
         mwperf::same_exact_opportunity_evidence(
             left_opportunity.exact_opportunity_evidence,
             right_opportunity.exact_opportunity_evidence) &&
         left_opportunity.opportunity == right_opportunity.opportunity &&
         left_opportunity.marks == right_opportunity.marks &&
         same_schedule(left_action.schedule, right_action.schedule) &&
         same_schedule(left_action.actual_departure,
                       right_action.actual_departure) &&
         left_action.schedule_identity == right_action.schedule_identity &&
         same_action_evidence(left_action.evidence, right_action.evidence) &&
         left_action.decision == right_action.decision &&
         left_action.interim_controller == right_action.interim_controller &&
         left_action.postupdate_controller_tape ==
             right_action.postupdate_controller_tape &&
         left_action.marks == right_action.marks &&
         left_arrival.authored_slot == right_arrival.authored_slot &&
         same_batch(left_arrival.batch, right_arrival.batch) &&
         same_phase(left_arrival.phase_before,
                    right_arrival.phase_before) &&
         same_phase(left_arrival.phase_after, right_arrival.phase_after) &&
         left_arrival.law_digest == right_arrival.law_digest &&
         left_arrival.canonical_source == right_arrival.canonical_source &&
         left_arrival.marks == right_arrival.marks &&
         left_post.unresolved_patch == right_post.unresolved_patch &&
         left_post.marks == right_post.marks &&
         left_edge.marks().size() == right_edge.marks().size() &&
         std::equal(left_edge.marks().begin(), left_edge.marks().end(),
                    right_edge.marks().begin()) &&
         left_edge.stage_trace() == right_edge.stage_trace() &&
         left.exact_mass == right.exact_mass;
}

// A C21-local exact oracle for the complete marked tuple in (12.18).  It is
// intentionally a plain value object: unlike StationaryMarkedEdge, it grants
// no conditional row or continuation operation and cannot mint a projection.
struct ExactMarkedTupleOracleV1 final {
  ReducedStateV1 stationary_left_state;
  mwperf::CompletedReducedEdge raw_edge;
  ReducedStateV1 stationary_right_state;
  ExactRational exact_mass;
};

[[nodiscard]] bool same_marked_tuple_key(
    const ExactMarkedTupleOracleV1& left,
    const ExactMarkedTupleOracleV1& right) {
  return left.stationary_left_state == right.stationary_left_state &&
         left.stationary_right_state == right.stationary_right_state &&
         mwperf::same_completed_reduced_outcome(left.raw_edge,
                                                right.raw_edge);
}

[[nodiscard]] bool same_marked_tuple_key(
    const ExactMarkedTupleOracleV1& expected,
    const StationaryMarkedEdgeAtomV1& actual) {
  return expected.stationary_left_state == actual.stationary_left_state &&
         expected.stationary_right_state == actual.stationary_right_state &&
         mwperf::same_completed_reduced_outcome(expected.raw_edge,
                                                actual.raw_edge);
}

[[nodiscard]] std::vector<ExactMarkedTupleOracleV1>
exact_marked_tuple_measure(
    const std::span<const StationaryTemporalAtomInspectionV1> atoms,
    const std::span<const ExactRational> replacement_masses = {}) {
  REQUIRE((replacement_masses.empty() ||
           replacement_masses.size() == atoms.size()));
  std::vector<ExactMarkedTupleOracleV1> result;
  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    const auto& atom = atoms[index];
    const ExactRational& mass = replacement_masses.empty()
                                    ? atom.exact_mass
                                    : replacement_masses[index];
    const auto existing =
        std::find_if(result.begin(), result.end(), [&](const auto& item) {
          return item.stationary_left_state == atom.stationary_left_state &&
                 item.stationary_right_state == atom.stationary_right_state &&
                 mwperf::same_completed_reduced_outcome(item.raw_edge,
                                                        atom.raw_edge);
        });
    if (existing == result.end()) {
      result.push_back({atom.stationary_left_state, atom.raw_edge,
                        atom.stationary_right_state, mass});
    } else {
      existing->exact_mass = existing->exact_mass + mass;
    }
  }
  return result;
}

void require_same_marked_tuple_measure(
    const std::span<const ExactMarkedTupleOracleV1> left,
    const std::span<const ExactMarkedTupleOracleV1> right) {
  REQUIRE(left.size() == right.size());
  std::vector<bool> consumed(right.size(), false);
  for (const auto& left_atom : left) {
    std::optional<std::size_t> match;
    for (std::size_t index = 0U; index < right.size(); ++index) {
      if (!consumed[index] && same_marked_tuple_key(left_atom, right[index]) &&
          left_atom.exact_mass == right[index].exact_mass) {
        match = index;
        break;
      }
    }
    REQUIRE(match.has_value());
    consumed[*match] = true;
  }
  CHECK(std::ranges::all_of(consumed,
                            [](const bool value) { return value; }));
}

void require_marked_tuple_oracle_matches_edge(
    const std::span<const ExactMarkedTupleOracleV1> expected,
    const StationaryMarkedEdge& actual) {
  REQUIRE(expected.size() == actual.atoms().size());
  std::vector<bool> consumed(actual.atoms().size(), false);
  for (const auto& expected_atom : expected) {
    std::optional<std::size_t> match;
    for (std::size_t index = 0U; index < actual.atoms().size(); ++index) {
      const auto& actual_atom = actual.atoms()[index];
      if (!consumed[index] &&
          same_marked_tuple_key(expected_atom, actual_atom) &&
          expected_atom.exact_mass == actual_atom.exact_mass) {
        match = index;
        break;
      }
    }
    REQUIRE(match.has_value());
    consumed[*match] = true;
  }
  CHECK(std::ranges::all_of(consumed,
                            [](const bool value) { return value; }));
}

void require_same_edge_measure(
    const StationaryMarkedEdge& left,
    const StationaryMarkedEdge& right) {
  REQUIRE(left.atoms().size() == right.atoms().size());
  std::vector<bool> consumed(right.atoms().size(), false);
  for (const auto& left_atom : left.atoms()) {
    std::optional<std::size_t> match;
    for (std::size_t index = 0U; index < right.atoms().size(); ++index) {
      if (!consumed[index] &&
          same_semantic_edge_atom(left_atom, right.atoms()[index])) {
        match = index;
        break;
      }
    }
    REQUIRE(match.has_value());
    consumed[*match] = true;
  }
}

[[nodiscard]] ExactRational departure_reward(
    const std::span<const StationaryTemporalAtomInspectionV1> atoms,
    const mwperf::DenseQueueIndex target) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    if (atom.raw_edge.action().actual_departure.at(target)) {
      total = total + atom.exact_mass;
    }
  }
  return total;
}

[[nodiscard]] ExactRational departure_reward(
    const std::span<const StationaryMarkedEdgeAtomV1> atoms,
    const mwperf::DenseQueueIndex target) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    if (atom.raw_edge.action().actual_departure.at(target)) {
      total = total + atom.exact_mass;
    }
  }
  return total;
}

void require_edge_identities(const StationaryMarkedEdge& edge) {
  ExactRational edge_mass = ExactRational::zero();
  for (const auto& atom : edge.atoms()) {
    edge_mass = edge_mass + atom.exact_mass;
  }
  CHECK(edge_mass == ExactRational::one());
  require_marginal(edge_marginal(edge.atoms(), true), edge.left_marginal());
  require_marginal(edge_marginal(edge.atoms(), false),
                   edge.right_marginal());
  require_marginal(edge_marginal(edge.atoms(), true),
                   edge.right_marginal());

  for (const auto& row : edge.positive_conditional_rows()) {
    CHECK(row.exact_left_mass.is_positive());
    ExactRational total = ExactRational::zero();
    for (const auto& atom : row.atoms) {
      REQUIRE(atom.edge_atom_index < edge.atoms().size());
      total = total + atom.exact_conditional_mass;
    }
    CHECK(total == ExactRational::one());
    CHECK(row.exact_total_conditional_mass == ExactRational::one());
  }
  for (const auto& row : edge.endpoint_rows()) {
    CHECK(row.exact_left_mass.is_positive());
    ExactRational total = ExactRational::zero();
    for (const auto& atom : row.atoms) {
      total = total + atom.exact_conditional_mass;
    }
    CHECK(total == ExactRational::one());
    CHECK(row.exact_total_conditional_mass == ExactRational::one());
  }
  CHECK(edge.diagnostics().exact_total_mass == ExactRational::one());
  CHECK(edge.diagnostics().exact_left_right_marginals_equal);
  CHECK(edge.diagnostics().exact_queue_updates_hold);
  CHECK(edge.diagnostics().exact_endpoint_invariance_holds);
  CHECK(edge.diagnostics().zero_mass_rows_left_undefined);
  CHECK_FALSE(edge.diagnostics().explicit_completion_identity.has_value());
}

struct BuiltSuspensionV1 final {
  c21_fixture::StationarySuspensionFixtureV1 fixture;
  EventInvariantLaw event_law;
  PositiveFiniteMean mean;
  StationaryTemporalProjection projection;
};

[[nodiscard]] BuiltSuspensionV1 build_suspension(
    const bool reverse_domain_order = false) {
  auto fixture = c21_fixture::make_fixture(
      c21_fixture::EventSelectionFixtureV1::equal_mixture,
      c21_fixture::rational(1, 4), c21_fixture::rational(3, 4),
      reverse_domain_order);
  auto event_law = mwperf::select_event_invariant_law(
      fixture.kernel, c21_fixture::configured_selection(fixture),
      c21_fixture::solver_policy(fixture));
  INFO((event_law ? std::string{}
                  : event_law.error().code + ": " +
                        event_law.error().message));
  REQUIRE(event_law);
  auto mean = mwperf::compute_mean_residence(event_law.value(),
                                             fixture.provider);
  INFO((mean ? std::string{}
             : mean.error().code + ": " + mean.error().message));
  REQUIRE(mean);
  auto projection = mwperf::build_stationary_temporal_projection(
      event_law.value(), fixture.provider, mean.value());
  INFO((projection ? std::string{}
                   : projection.error().code + ": " +
                         projection.error().message));
  REQUIRE(projection);
  return {std::move(fixture), std::move(event_law).value(),
          std::move(mean).value(), std::move(projection).value()};
}

[[nodiscard]] mwperf::RewardDecoder constant_one_reward() {
  return {mwperf::StationaryRewardDomainV1::state,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1&) {
            return mwperf::Result<long double>::success(1.0L);
          },
          {"c21.property.exact-scalar", 1U}};
}

[[nodiscard]] ExactRational event_mass_for_state(
    const EventInvariantLaw& law, const ReducedStateV1& state) {
  for (const auto& atom : law.masses()) {
    REQUIRE(atom.state_index < law.domain().states().size());
    if (law.domain().states()[atom.state_index] == state) {
      return atom.exact_mass;
    }
  }
  FAIL("event state is absent from the selected invariant law");
  return ExactRational::zero();
}

[[nodiscard]] ExactRational class_mean_length(
    const EventInvariantLaw& law, const ReducedStateV1& state) {
  const auto index = law.domain().index_of(state);
  REQUIRE(index.has_value());
  const auto& row = law.embedded_kernel().rows()[*index].word_row;
  ExactRational mean = ExactRational::zero();
  for (const auto& word : row.atoms()) {
    auto length = ExactRational::make(word.word.length().value(),
                                      mwperf::BigInt{1});
    REQUIRE(length);
    mean = mean + word.exact_mass * length.value();
  }
  return mean;
}

[[nodiscard]] ExactRational slot_mass_for_phase(
    const std::span<const StationaryTemporalAtomInspectionV1> atoms,
    const std::uint8_t phase) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    if (c21_fixture::phase(atom.stationary_left_state) == phase) {
      total = total + atom.exact_mass;
    }
  }
  return total;
}

[[nodiscard]] ExactRational slot_mass_for_phase(
    const std::span<const StationaryMarkedEdgeAtomV1> atoms,
    const std::uint8_t phase) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : atoms) {
    if (c21_fixture::phase(atom.stationary_left_state) == phase) {
      total = total + atom.exact_mass;
    }
  }
  return total;
}

}  // namespace

TEST_CASE("C21 suspension equals independent exact (y,w,j) enumeration",
          "[c21][property][suspension][exact-enumeration]") {
  auto built = build_suspension();
  const auto oracle =
      enumerate_exact_suspension_oracle(built.event_law, built.mean);
  const auto atoms = inspect_temporal_atoms(built.projection.temporal_law());

  require_exact_enumeration(oracle, atoms);
  CHECK(total_mass(oracle) == ExactRational::one());
  CHECK(total_mass(atoms) == ExactRational::one());
  CHECK(built.projection.temporal_law().diagnostics().exact_total_mass ==
        ExactRational::one());

  // Reward one has cycle numerator E[L] and hence slot expectation one.
  auto reward = mwperf::suspend_event_law_to_slots(
      built.event_law, built.fixture.provider, built.mean,
      constant_one_reward());
  INFO((reward ? std::string{}
               : reward.error().code + ": " + reward.error().message));
  REQUIRE(reward);
  auto envelope =
      mwperf::testing::C21FixtureAccess::decode_metric_envelope(
          reward.value());
  REQUIRE(envelope);
  REQUIRE(envelope.value().exact_numerator.has_value());
  REQUIRE(envelope.value().exact_ratio.has_value());
  CHECK(*envelope.value().exact_numerator == exact_mean(built.mean));
  CHECK(envelope.value().exact_denominator == exact_mean(built.mean));
  CHECK(*envelope.value().exact_ratio == ExactRational::one());

  // There is exactly one start offset per event word, so its ordinary-slot
  // mass is the event intensity 1/E[L].
  CHECK(word_start_mass(atoms) ==
        exact_ratio(ExactRational::one(), exact_mean(built.mean)));
}

TEST_CASE("C21 marked edge has exact stationary marginals and shared rewards",
          "[c21][property][marked-edge][invariance][reward]") {
  auto built = build_suspension();
  const auto atoms = inspect_temporal_atoms(built.projection.temporal_law());
  const auto& edge = built.projection.marked_edge();
  require_edge_identities(edge);

  auto target = built.fixture.temporal.instance.queues().index_at(2U);
  REQUIRE(target);
  REQUIRE(built.fixture.temporal.instance.queues().queue_id(target.value()) ==
          mwperf::testing::c16_designated_detail::queue("q0"));
  CHECK(departure_reward(atoms, target.value()) ==
        departure_reward(edge.atoms(), target.value()));
  CHECK(slot_mass_for_phase(atoms, 1U) == rational(3, 4));
  CHECK(slot_mass_for_phase(atoms, 1U) ==
        slot_mass_for_phase(edge.atoms(), 1U));
  CHECK(total_mass(atoms) == edge.diagnostics().exact_total_mass);
}

TEST_CASE("C21 canonical suspension is invariant to enumeration permutations",
          "[c21][property][permutation][cold]") {
  auto forward = build_suspension(false);
  auto reversed_domain = build_suspension(true);
  CHECK(exact_mean(forward.mean) == exact_mean(reversed_domain.mean));
  CHECK(event_mass_for_state(forward.event_law, forward.fixture.class_a) ==
        event_mass_for_state(reversed_domain.event_law,
                             reversed_domain.fixture.class_a));
  CHECK(event_mass_for_state(forward.event_law, forward.fixture.class_b) ==
        event_mass_for_state(reversed_domain.event_law,
                             reversed_domain.fixture.class_b));
  require_same_edge_measure(forward.projection.marked_edge(),
                            reversed_domain.projection.marked_edge());

  // Word/offset order is deliberately destroyed after test-only inspection;
  // all symmetric exact identities remain unchanged.  Production itself
  // traverses the canonical event/word/offset order checked above.
  auto canonical = inspect_temporal_atoms(forward.projection.temporal_law());
  auto permuted = canonical;
  std::reverse(permuted.begin(), permuted.end());
  CHECK(total_mass(canonical) == total_mass(permuted));
  CHECK(word_start_mass(canonical) == word_start_mass(permuted));
  auto target = forward.fixture.temporal.instance.queues().index_at(2U);
  REQUIRE(target);
  CHECK(departure_reward(canonical, target.value()) ==
        departure_reward(permuted, target.value()));

  // This is the strongest C21-local order oracle available across the sealed
  // C20 boundary: compare every quotient endpoint, retained C17 edge/mark and
  // exact mass after changing the accumulation order.  C20 itself canonical
  // sorts words by word digest, while offsets are chronological path edges,
  // so neither can be author-reordered through a public production API.
  const auto canonical_measure = exact_marked_tuple_measure(canonical);
  const auto permuted_measure = exact_marked_tuple_measure(permuted);
  require_same_marked_tuple_measure(canonical_measure, permuted_measure);
  require_marked_tuple_oracle_matches_edge(
      canonical_measure, forward.projection.marked_edge());
}

TEST_CASE("C21 event-class mixtures are length biased by alpha times L",
          "[c21][property][mixture][length-bias]") {
  auto built = build_suspension();
  const ExactRational alpha_a =
      event_mass_for_state(built.event_law, built.fixture.class_a);
  const ExactRational alpha_b =
      event_mass_for_state(built.event_law, built.fixture.class_b);
  const ExactRational length_a =
      class_mean_length(built.event_law, built.fixture.class_a);
  const ExactRational length_b =
      class_mean_length(built.event_law, built.fixture.class_b);
  CHECK(alpha_a == rational(1, 2));
  CHECK(alpha_b == rational(1, 2));
  CHECK(length_a == ExactRational::one());
  CHECK(length_b == rational(3, 1));
  CHECK(exact_mean(built.mean) == rational(2, 1));

  const auto atoms = inspect_temporal_atoms(built.projection.temporal_law());
  CHECK(slot_mass_for_phase(atoms, 0U) ==
        exact_ratio(alpha_a * length_a, exact_mean(built.mean)));
  CHECK(slot_mass_for_phase(atoms, 1U) ==
        exact_ratio(alpha_b * length_b, exact_mean(built.mean)));
  CHECK(slot_mass_for_phase(atoms, 0U) == rational(1, 4));
  CHECK(slot_mass_for_phase(atoms, 1U) == rational(3, 4));
}

TEST_CASE("C21 adapted split and merge preserve slot and edge measures",
          "[c21][property][metamorphic][split-merge]") {
  auto built = build_suspension();
  const auto atoms = inspect_temporal_atoms(built.projection.temporal_law());
  REQUIRE(atoms.size() == 4U);

  // This is an exact C21-local regrouping oracle, not a claim that a second
  // production provider was minted.  Split the length-three B residence after
  // its first slot.  Per original A/B cycle this creates event types A, B0,
  // and B-suffix with lengths 1, 1, and 2.  Their induced event weights are
  // 1/3 each and the new event mean is 4/3.
  const ExactRational split_alpha_a = rational(1, 3);
  const ExactRational split_alpha_b0 = rational(1, 3);
  const ExactRational split_alpha_b_suffix = rational(1, 3);
  const ExactRational split_mean =
      split_alpha_a * rational(1, 1) +
      split_alpha_b0 * rational(1, 1) +
      split_alpha_b_suffix * rational(2, 1);
  CHECK(split_mean == rational(4, 3));
  const ExactRational split_offset_mass =
      exact_ratio(split_alpha_a, split_mean);
  CHECK(split_offset_mass == rational(1, 4));

  for (std::size_t offset = 0U; offset < 3U; ++offset) {
    CHECK(std::ranges::count_if(atoms, [&](const auto& atom) {
            return c21_fixture::phase(atom.stationary_left_state) == 1U &&
                   atom.residence_offset == BigNat{offset};
          }) == 1);
  }
  CHECK(std::ranges::count_if(atoms, [&](const auto& atom) {
          return c21_fixture::phase(atom.stationary_left_state) == 0U &&
                 atom.residence_offset == BigNat{0U};
        }) == 1);

  ExactRational split_total = ExactRational::zero();
  std::vector<ExactRational> split_masses;
  split_masses.reserve(atoms.size());
  for (const auto& atom : atoms) {
    INFO("phase=" +
         std::to_string(c21_fixture::phase(atom.stationary_left_state)) +
         " offset=" + atom.residence_offset.to_decimal_string());
    ExactRational atom_mass = ExactRational::zero();
    if (c21_fixture::phase(atom.stationary_left_state) == 0U) {
      atom_mass = exact_ratio(split_alpha_a, split_mean);
    } else if (atom.residence_offset == BigNat{0U}) {
      atom_mass = exact_ratio(split_alpha_b0, split_mean);
    } else {
      atom_mass = exact_ratio(split_alpha_b_suffix, split_mean);
    }
    split_masses.push_back(atom_mass);
    split_total = split_total + atom_mass;
    CHECK(atom.exact_mass == atom_mass);
  }
  CHECK(split_total == ExactRational::one());

  // Merging B0 and B1 restores event weights (1/2,1/2), lengths (1,3),
  // mean two, and therefore the identical four marked slot atoms.
  const ExactRational merged_alpha_a = rational(1, 2);
  const ExactRational merged_alpha_b = rational(1, 2);
  const ExactRational merged_mean =
      merged_alpha_a * rational(1, 1) +
      merged_alpha_b * rational(3, 1);
  CHECK(merged_mean == rational(2, 1));
  std::vector<ExactRational> merged_masses;
  merged_masses.reserve(atoms.size());
  for (const auto& atom : atoms) {
    const ExactRational& alpha =
        c21_fixture::phase(atom.stationary_left_state) == 0U
            ? merged_alpha_a
            : merged_alpha_b;
    merged_masses.push_back(exact_ratio(alpha, merged_mean));
  }
  const ExactRational merged_offset_mass = merged_masses.front();
  CHECK(merged_offset_mass == split_offset_mass);
  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    CHECK(split_masses[index] == merged_masses[index]);
    CHECK(merged_masses[index] == atoms[index].exact_mass);
  }

  // Compare the entire marked tuple measure, not merely a scalar reward:
  // quotient endpoints, complete C17 raw edge (D, A, phase and auxiliary
  // marks), and exact coalesced mass must all agree with the production edge.
  const auto split_measure = exact_marked_tuple_measure(atoms, split_masses);
  const auto merged_measure = exact_marked_tuple_measure(atoms, merged_masses);
  require_same_marked_tuple_measure(split_measure, merged_measure);
  require_marked_tuple_oracle_matches_edge(
      merged_measure, built.projection.marked_edge());
  require_edge_identities(built.projection.marked_edge());
}

TEST_CASE("C21 marked-edge coalescing retains marks that share an endpoint",
          "[c21][property][marked-edge][coalescing]") {
  const ReducedStateV1 state{{"c21.property.edge-state", 1U},
                             {std::byte{0x01}}};
  const mwperf::ArrivalPhaseIdentityV1 phase{
      mwperf::ArrivalFamily::periodic_global_phase, {std::byte{0x00}}};
  const auto make_edge = [&](const std::uint8_t departure,
                             const std::uint64_t arrival) {
    return mwperf::MarkedFluxEdgeV1{
        state,
        state,
        {BigNat{1U}},
        {departure},
        {BigNat{arrival}},
        phase,
        phase,
        {}};
  };
  std::vector<mwperf::testing::C21MarkedEdgeFixtureAtomV1> atoms;
  atoms.push_back({make_edge(0U, 0U), rational(1, 2)});
  atoms.push_back({make_edge(1U, 1U), rational(1, 2)});

  auto inspected =
      mwperf::testing::C21FixtureAccess::inspect_marked_edge_coalescing(
          std::move(atoms));
  INFO((inspected ? std::string{}
                  : inspected.error().code + ": " +
                        inspected.error().message));
  REQUIRE(inspected);
  CHECK(inspected.value().retained_marked_atom_count == 2U);
  CHECK(inspected.value().endpoint_pushforward_atom_count == 1U);
  CHECK(inspected.value().exact_total_mass == ExactRational::one());
  CHECK(inspected.value().exact_departure_mass == rational(1, 2));
  CHECK(inspected.value().exact_arrival_mass == rational(1, 2));
  CHECK(inspected.value().exact_queue_updates_hold);
  CHECK(inspected.value().exact_left_right_marginals_equal);
  CHECK(inspected.value().exact_endpoint_invariance_holds);
}

TEST_CASE("C21 C20 quotient hides the physical clock from callbacks and a "
          "bound typed decoder",
          "[c21][property][quotient][compatibility]") {
  auto callback_fixture =
      mwperf::testing::c20::make_four_word_enumerable_framework();
  auto callback_provider = mwperf::audited_residence_provider(
      callback_fixture.temporal.framework);
  REQUIRE(callback_provider);
  callback_fixture.callback_clock_or->store(0U,
                                             std::memory_order_relaxed);
  auto callback_row = mwperf::enumerate_residence_word_row(
      callback_provider.value(), callback_fixture.temporal.initial_state,
      mwperf::PmfRepresentationBudget::unbounded());
  INFO((callback_row ? std::string{}
                     : callback_row.error().code + ": " +
                           callback_row.error().message));
  REQUIRE(callback_row);
  // C-minus and the adapted stopping callback observe the same slot-zero
  // quotient on every residence offset.
  CHECK(callback_fixture.callback_clock_or->load(
            std::memory_order_relaxed) == 0U);
  REQUIRE(callback_row.value().atoms().size() == 4U);
  for (const auto& atom : callback_row.value().atoms()) {
    REQUIRE(atom.word.edges().size() == 2U);
    REQUIRE(atom.word.continuation_path().size() == 3U);
    const auto require_shared_arrival_cursor =
        [&](const auto& raw_state, const auto& lifted_state) {
          auto raw = callback_fixture.temporal.state_schema.decode(raw_state);
          auto lifted =
              callback_fixture.temporal.state_schema.decode(lifted_state);
          REQUIRE(raw);
          REQUIRE(lifted);
          CHECK(mwperf::arrival_phases_share_cursor(
              raw.value().arrival_phase, lifted.value().arrival_phase));
        };

    // All three quotient-lift sites restore the physical cursor/RNG lineage:
    // entry initialization, terminal reentry, and next-residence reset.
    require_shared_arrival_cursor(atom.word.entry_state(),
                                  atom.word.continuation_path().front());
    require_shared_arrival_cursor(atom.word.raw_terminal_state(),
                                  atom.word.event_endpoint());
    require_shared_arrival_cursor(atom.word.event_endpoint(),
                                  atom.word.continuation_path().back());
    for (std::size_t offset = 0U; offset < 2U; ++offset) {
      auto before = callback_fixture.temporal.state_schema.decode(
          atom.word.edges()[offset].pre_state());
      auto after = callback_fixture.temporal.state_schema.decode(
          atom.word.edges()[offset].successor_state());
      REQUIRE(before);
      REQUIRE(after);
      CHECK(before.value().boundary_index == BigNat{offset});
      CHECK(after.value().boundary_index == BigNat{offset + 1U});
      CHECK(atom.word.edges()[offset].arrival().authored_slot ==
            BigNat{offset});
    }
  }

  auto fixture = mwperf::testing::c21::make_fixture();
  const auto declared = std::ranges::find_if(
      fixture.temporal.descriptor.marks,
      [](const mwperf::RuntimeMarkDescriptorV1& mark) {
        return mark.decoder_source ==
               mwperf::MarkDecoderSourceV1::completed_edge;
      });
  REQUIRE(declared != fixture.temporal.descriptor.marks.end());
  REQUIRE(declared->field_dependencies.size() == 1U);
  REQUIRE(fixture.temporal.descriptor.event_contract.has_value());
  CHECK(std::ranges::find(
            fixture.temporal.descriptor.event_contract
                ->residence_local_reset_fields,
            declared->field_dependencies.front()) !=
        fixture.temporal.descriptor.event_contract
            ->residence_local_reset_fields.end());
  const auto& decoder_schemas = fixture.temporal.state_schema
                                    .completed_edge_mark_decoder
                                    .ordered_mark_schemas;
  REQUIRE(decoder_schemas.size() == 1U);
  CHECK(decoder_schemas.front().decoder_id == declared->decoder_id);
  CHECK(decoder_schemas.front().mark == declared->id);
  CHECK(decoder_schemas.front().source == declared->decoder_source);
  CHECK(decoder_schemas.front().input_codec ==
        declared->decoder_input_codec);
  CHECK(decoder_schemas.front().output_codec == declared->c14_mark.codec);

  fixture.completed_decoder_clock_or->store(0U,
                                             std::memory_order_relaxed);
  auto row = mwperf::enumerate_residence_word_row(
      fixture.provider, fixture.class_b,
      mwperf::PmfRepresentationBudget::unbounded());
  INFO((row ? std::string{}
            : row.error().code + ": " + row.error().message));
  REQUIRE(row);

  // This is the descriptor-bound completed-edge age decoder: its schema has
  // the exact declared decoder/mark IDs, completed-edge input codec, age
  // output codec, and residence-local dependency.  It must see the slot-zero
  // callback pre-state on every physical edge.
  CHECK(fixture.completed_decoder_clock_or->load(
            std::memory_order_relaxed) == 0U);

  REQUIRE(row.value().atoms().size() == 1U);
  for (const auto& atom : row.value().atoms()) {
    REQUIRE(atom.word.edges().size() == 3U);
    for (std::size_t offset = 0U; offset < 3U; ++offset) {
      const auto& edge = atom.word.edges()[offset];
      auto before = fixture.temporal.state_schema.decode(edge.pre_state());
      auto after =
          fixture.temporal.state_schema.decode(edge.successor_state());
      REQUIRE(before);
      REQUIRE(after);
      CHECK(before.value().boundary_index == BigNat{offset});
      CHECK(after.value().boundary_index == BigNat{offset + 1U});
      CHECK(edge.arrival().authored_slot == BigNat{offset});
    }
    auto endpoint =
        fixture.temporal.state_schema.decode(atom.word.event_endpoint());
    REQUIRE(endpoint);
    CHECK(endpoint.value().boundary_index == BigNat{3U});
  }
}

TEST_CASE("C21 leaves transient zero-pi event states without stationary rows",
          "[c21][property][marked-edge][zero-pi][transient]") {
  auto fixture = c21_fixture::make_transient_fixture(
      c21_fixture::EventSelectionFixtureV1::unique);
  const auto transient_index = fixture.domain.index_of(fixture.class_a);
  REQUIRE(transient_index.has_value());

  auto event_law = mwperf::select_event_invariant_law(
      fixture.kernel, c21_fixture::configured_selection(fixture),
      c21_fixture::solver_policy(fixture));
  INFO((event_law ? std::string{}
                  : event_law.error().code + ": " +
                        event_law.error().message));
  REQUIRE(event_law);
  REQUIRE(*transient_index < event_law.value().masses().size());
  const auto transient_mass = std::ranges::find_if(
      event_law.value().masses(), [&](const auto& atom) {
        return atom.state_index == *transient_index;
      });
  REQUIRE(transient_mass != event_law.value().masses().end());
  CHECK(transient_mass->exact_mass == ExactRational::zero());

  auto mean = mwperf::compute_mean_residence(event_law.value(),
                                             fixture.provider);
  INFO((mean ? std::string{}
             : mean.error().code + ": " + mean.error().message));
  REQUIRE(mean);
  auto projection = mwperf::build_stationary_temporal_projection(
      event_law.value(), fixture.provider, mean.value());
  INFO((projection ? std::string{}
                   : projection.error().code + ": " +
                         projection.error().message));
  REQUIRE(projection);

  const auto& edge = projection.value().marked_edge();
  require_edge_identities(edge);
  CHECK(find_state_mass(edge.left_marginal(), fixture.class_a) == nullptr);
  CHECK(find_state_mass(edge.right_marginal(), fixture.class_a) == nullptr);
  CHECK(std::ranges::none_of(
      edge.positive_conditional_rows(), [&](const auto& row) {
        return row.stationary_left_state == fixture.class_a;
      }));
  CHECK(std::ranges::none_of(edge.endpoint_rows(), [&](const auto& row) {
    return row.stationary_left_state == fixture.class_a;
  }));
  CHECK(std::ranges::none_of(edge.atoms(), [&](const auto& atom) {
    return atom.stationary_left_state == fixture.class_a ||
           atom.stationary_right_state == fixture.class_a;
  }));

  // No conditional or endpoint row exists at the zero-pi state, so in
  // particular C21 has not invented a self-loop or a global completion.
  CHECK(edge.diagnostics().zero_mass_rows_left_undefined);
  CHECK_FALSE(edge.diagnostics().explicit_completion_identity.has_value());
  REQUIRE(edge.positive_conditional_rows().size() ==
          edge.left_marginal().size());
  REQUIRE(edge.endpoint_rows().size() == edge.left_marginal().size());
  for (const auto& row : edge.positive_conditional_rows()) {
    CHECK(row.exact_left_mass.is_positive());
    CHECK(row.exact_total_conditional_mass == ExactRational::one());
  }
  for (const auto& row : edge.endpoint_rows()) {
    CHECK(row.exact_left_mass.is_positive());
    CHECK(row.exact_total_conditional_mass == ExactRational::one());
  }
}
