#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "arrival/core_internal.hpp"
#include "fixtures/c20/enumerable_four_word_fixture.hpp"
#include "fixtures/c20/multi_slot_temporal_fixture.hpp"
#include "mwperf/temporal/romr.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

[[nodiscard]] mwperf::detail::CompiledArrivalProduct clone_arrival_product(
    const mwperf::CompiledArrivalLaw& law) {
  const auto& core = mwperf::detail::ArrivalCoreAccess::law_core(law);
  const auto& view = core->builder_view;
  return {
      .family = core->binding.family,
      .normalized_rows = core->normalized_rows,
      .positive_support = std::vector<std::uint8_t>(
          view.positive_support().bytes().begin(),
          view.positive_support().bytes().end()),
      .capabilities = core->capabilities,
      .canonical_law_data = view.configured_law().canonical_data,
      .portable_schema = view.configured_law().schema,
      .payload = core->payload,
      .runtime = core->runtime,
      .iid_joint_table = view.iid_joint_table(),
      .moments = view.moments(),
      .covariances = view.covariances(),
      .analytic_transform = view.analytic_transform(),
      .joint_distribution = view.joint_distribution(),
      .coordinate_distributions = view.coordinate_distributions(),
      .replay_codec = view.replay_codec(),
      .unit_cube = view.unit_cube(),
      .finite_phase = view.finite_phase(),
      .transition_rows = view.transition_rows(),
      .stationary_phase_law = view.stationary_phase_law()};
}

void make_arrival_access_portable_only(
    mwperf::detail::CompiledArrivalProduct& product) {
  REQUIRE(product.capabilities.adjacent_batch_replay.has_value());
  REQUIRE(product.capabilities.unit_cube_transform.has_value());
  REQUIRE(product.unit_cube.has_value());
  product.capabilities.adjacent_batch_replay->provision =
      mwperf::AccessProvision::portable_only;
  product.capabilities.unit_cube_transform->provision =
      mwperf::AccessProvision::portable_only;
  product.unit_cube->capability =
      *product.capabilities.unit_cube_transform;
  product.runtime.unit_cube = {};
}

[[nodiscard]] mwperf::ResidenceWord realize_unit_word(
    const mwperf::testing::c17::ThreeBinFrameworkV1& fixture,
    const mwperf::AuditedRomrView& view,
    const mwperf::AuditedSlotExecutor& executor,
    const mwperf::ReducedStateV1& entrance, const std::uint64_t seed) {
  auto cursor = mwperf::begin_residence(view, entrance);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view, fixture.instance, mwperf::MasterSeed{seed});
  REQUIRE(bank);
  auto step = mwperf::advance_residence(cursor.value(), executor, bank.value());
  REQUIRE(step);
  auto stop = mwperf::validate_residence_stop(cursor.value(), step.value());
  REQUIRE(stop);
  REQUIRE(stop.value().stops());
  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  return std::move(word).value();
}

void check_same_word_row(const mwperf::ResidenceWordRow& left,
                         const mwperf::ResidenceWordRow& right) {
  CHECK(left.entry_state() == right.entry_state());
  CHECK(left.exact_total_mass() == right.exact_total_mass());
  CHECK(left.representation_budget() == right.representation_budget());
  CHECK(left.provider_fingerprint() == right.provider_fingerprint());
  REQUIRE(left.atoms().size() == right.atoms().size());
  for (std::size_t index = 0U; index < left.atoms().size(); ++index) {
    const auto& left_atom = left.atoms()[index];
    const auto& right_atom = right.atoms()[index];
    CHECK(left_atom.exact_mass == right_atom.exact_mass);
    CHECK(left_atom.structural_support == right_atom.structural_support);
    CHECK(left_atom.numerical_image == right_atom.numerical_image);
    CHECK(left_atom.numerical_image_status ==
          right_atom.numerical_image_status);
    CHECK(left_atom.exact_cumulative_mass ==
          right_atom.exact_cumulative_mass);
    CHECK(left_atom.word.word_digest() == right_atom.word.word_digest());
    CHECK(left_atom.word.entry_state() == right_atom.word.entry_state());
    CHECK(left_atom.word.event_endpoint() ==
          right_atom.word.event_endpoint());
    CHECK(left_atom.word.raw_terminal_state() ==
          right_atom.word.raw_terminal_state());
    REQUIRE(left_atom.word.edges().size() ==
            right_atom.word.edges().size());
    REQUIRE(left_atom.word.continuation_path().size() ==
            right_atom.word.continuation_path().size());
    for (std::size_t edge = 0U; edge < left_atom.word.edges().size(); ++edge) {
      CHECK(left_atom.word.edges()[edge] == right_atom.word.edges()[edge]);
      CHECK(left_atom.word.continuation_path()[edge] ==
            right_atom.word.continuation_path()[edge]);
    }
    CHECK(left_atom.word.continuation_path().back() ==
          right_atom.word.continuation_path().back());
  }
}

TEST_CASE("C20 exact residence rows preserve the C17 causal atoms",
          "[c20][property][enumeration][causality]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  auto row_provider = mwperf::audited_row_provider(fixture.framework);
  REQUIRE(provider);
  REQUIRE(row_provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  auto residence = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(residence);
  auto slot =
      mwperf::compile_reduced_kernel_row(row_provider.value(), entrance);
  REQUIRE(slot);
  REQUIRE(residence.value().atoms().size() == slot.value().atoms().size());
  CHECK(residence.value().exact_total_mass() == mwperf::ExactRational::one());
  CHECK(residence.value().representation_budget() ==
        mwperf::PmfRepresentationBudget::unbounded());

  mwperf::ExactRational cumulative = mwperf::ExactRational::zero();
  for (const auto& word_atom : residence.value().atoms()) {
    cumulative = cumulative + word_atom.exact_mass;
    CHECK(word_atom.word.length() == mwperf::BigNat{1U});
    REQUIRE(word_atom.word.edges().size() == 1U);
    CHECK(word_atom.word.entry_state() == entrance);
    const auto matching_slot = std::ranges::find_if(
        slot.value().atoms(), [&](const mwperf::MarkedKernelRowAtomV1& atom) {
          return atom.edge == word_atom.word.edges().front();
        });
    REQUIRE(matching_slot != slot.value().atoms().end());
    CHECK(word_atom.word.event_endpoint() ==
          matching_slot->edge.successor_state());
    CHECK(word_atom.exact_mass == matching_slot->exact_mass);
    CHECK(word_atom.structural_support == matching_slot->structural_support);
    CHECK(word_atom.exact_cumulative_mass == cumulative);
  }
  CHECK(cumulative == mwperf::ExactRational::one());
}

TEST_CASE("C20 retains exact positive word support when its image underflows",
          "[c20][property][enumeration][numerical]") {
  auto fixture =
      mwperf::testing::c17::make_positive_underflow_three_bin_framework();
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(row);
  CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());

  bool found_positive_underflow = false;
  for (const auto& atom : row.value().atoms()) {
    if (atom.numerical_image_status ==
        mwperf::NumericalProbabilityImageStatusV1::positive_underflow) {
      found_positive_underflow = true;
      CHECK(atom.exact_mass.is_positive());
      CHECK(atom.structural_support);
      CHECK(atom.numerical_image == 0.0L);
    }
  }
  CHECK(found_positive_underflow);
  CHECK(row.value().numerical_row_image().status ==
        mwperf::NumericalProbabilityImageStatusV1::positive_underflow);
  CHECK(row.value().numerical_row_image().signed_residual_from_one ==
        row.value().numerical_row_image().compensated_total - 1.0L);
}

TEST_CASE("C20 finite homogeneous arrival rows are canonical and executable",
          "[c20][property][arrival][homogeneous]") {
  auto input = mwperf::testing::c20::four_word_enumerable_input();
  const auto baseline_view =
      mwperf::builder_arrival_view(*input.arrival);

  {
    INFO("semantic outcome splitting preserves the portable witness");
    auto product = clone_arrival_product(*input.arrival);
    const auto original = product.runtime.enumerate_time_homogeneous;
    auto half = mwperf::ExactRational::make(mwperf::BigInt{1},
                                            mwperf::BigInt{2});
    REQUIRE(half);
    product.runtime.enumerate_time_homogeneous =
        [original, half = std::move(half).value()](
            const std::shared_ptr<const void>& payload,
            const mwperf::detail::ArrivalCursorState& cursor,
            const mwperf::ArrivalBinding& binding)
        -> mwperf::Result<std::vector<
            mwperf::detail::ExactArrivalTransitionAtom>> {
      auto row = original(payload, cursor, binding);
      if (!row) {
        return row;
      }
      std::vector<mwperf::detail::ExactArrivalTransitionAtom> split;
      split.reserve(row.value().size() * 2U);
      for (const auto& source : row.value()) {
        auto first = source;
        auto second = source;
        first.mass = first.mass * half;
        second.mass = second.mass * half;
        split.push_back(std::move(first));
        split.push_back(std::move(second));
      }
      return mwperf::Result<std::vector<
          mwperf::detail::ExactArrivalTransitionAtom>>::success(
          std::move(split));
    };
    auto republished = mwperf::detail::publish_compiled_arrival_law(
        input.instance.queues(), std::move(product));
    INFO((republished ? std::string{}
                      : republished.error().code + ": " +
                            republished.error().message));
    REQUIRE(republished);
    const auto split_view =
        mwperf::builder_arrival_view(republished.value());
    REQUIRE(baseline_view.transition_rows().has_value());
    REQUIRE(split_view.transition_rows().has_value());
    CHECK(split_view.transition_rows()->canonical_rows ==
          baseline_view.transition_rows()->canonical_rows);
    CHECK(split_view.digest() == baseline_view.digest());
  }

  {
    INFO("raw atom decomposition preserves the canonical batch witness");
    auto product = clone_arrival_product(*input.arrival);
    const auto original = product.runtime.enumerate_time_homogeneous;
    product.runtime.enumerate_time_homogeneous =
        [original](const std::shared_ptr<const void>& payload,
                   const mwperf::detail::ArrivalCursorState& cursor,
                   const mwperf::ArrivalBinding& binding)
        -> mwperf::Result<std::vector<
            mwperf::detail::ExactArrivalTransitionAtom>> {
      auto row = original(payload, cursor, binding);
      if (!row) {
        return row;
      }
      for (auto& outcome : row.value()) {
        std::vector<mwperf::ArrivalAtom> decomposed;
        for (const auto& source : outcome.atoms) {
          const std::uint64_t count =
              source.count().value().convert_to<std::uint64_t>();
          decomposed.reserve(decomposed.size() +
                             static_cast<std::size_t>(count));
          for (std::uint64_t index = 0U; index < count; ++index) {
            auto unit = mwperf::ArrivalAtom::make(
                source.queue(), mwperf::BigNat{1U}, source.binding());
            if (!unit) {
              return mwperf::Result<std::vector<
                  mwperf::detail::ExactArrivalTransitionAtom>>::failure(
                  unit.error());
            }
            decomposed.push_back(std::move(unit).value());
          }
        }
        outcome.atoms = std::move(decomposed);
      }
      return row;
    };
    auto republished = mwperf::detail::publish_compiled_arrival_law(
        input.instance.queues(), std::move(product));
    INFO((republished ? std::string{}
                      : republished.error().code + ": " +
                            republished.error().message));
    REQUIRE(republished);
    const auto decomposed_view =
        mwperf::builder_arrival_view(republished.value());
    REQUIRE(baseline_view.transition_rows().has_value());
    REQUIRE(decomposed_view.transition_rows().has_value());
    CHECK(decomposed_view.transition_rows()->canonical_rows ==
          baseline_view.transition_rows()->canonical_rows);
    CHECK(decomposed_view.digest() == baseline_view.digest());
  }

  {
    INFO("overflow is rejected before a homogeneous witness is sealed");
    auto product = clone_arrival_product(*input.arrival);
    const auto original = product.runtime.enumerate_time_homogeneous;
    auto queue = input.instance.queues().index_at(0U);
    REQUIRE(queue);
    const auto& binding = mwperf::arrival_law_binding(*input.arrival);
    auto maximum = mwperf::ArrivalAtom::make(
        queue.value(),
        mwperf::BigNat{static_cast<std::uint64_t>(
            std::numeric_limits<std::int64_t>::max())},
        binding);
    auto one = mwperf::ArrivalAtom::make(
        queue.value(), mwperf::BigNat{1U}, binding);
    REQUIRE(maximum);
    REQUIRE(one);
    std::vector<mwperf::ArrivalAtom> overflowing_atoms{
        std::move(maximum).value(), std::move(one).value()};
    product.runtime.enumerate_time_homogeneous =
        [original, overflowing_atoms = std::move(overflowing_atoms)](
            const std::shared_ptr<const void>& payload,
            const mwperf::detail::ArrivalCursorState& cursor,
            const mwperf::ArrivalBinding& row_binding) mutable {
      auto row = original(payload, cursor, row_binding);
      if (row) {
        row.value().front().atoms = overflowing_atoms;
      }
      return row;
    };
    auto republished = mwperf::detail::publish_compiled_arrival_law(
        input.instance.queues(), std::move(product));
    REQUIRE_FALSE(republished);
    CHECK(republished.error().category ==
          mwperf::DiagnosticCategory::internal);
    CHECK(republished.error().code ==
          "arrival_homogeneous_row_invalid_batch");
    REQUIRE_FALSE(republished.error().notes.empty());
    CHECK(republished.error().notes.front() == "arrival_count_overflow");
  }

  {
    INFO("advertised support must equal the positive homogeneous union");
    auto product = clone_arrival_product(*input.arrival);
    const auto original = product.runtime.enumerate_time_homogeneous;
    auto omitted = input.instance.queues().index_at(1U);
    REQUIRE(omitted);
    product.runtime.enumerate_time_homogeneous =
        [original, omitted = omitted.value()](
            const std::shared_ptr<const void>& payload,
            const mwperf::detail::ArrivalCursorState& cursor,
            const mwperf::ArrivalBinding& binding) {
      auto row = original(payload, cursor, binding);
      if (row) {
        for (auto& outcome : row.value()) {
          std::erase_if(outcome.atoms, [omitted](const auto& atom) {
            return atom.queue() == omitted;
          });
        }
      }
      return row;
    };
    auto republished = mwperf::detail::publish_compiled_arrival_law(
        input.instance.queues(), std::move(product));
    REQUIRE_FALSE(republished);
    CHECK(republished.error().code ==
          "arrival_homogeneous_row_support_mismatch");
  }

  {
    INFO("complete phase codecs are required only by the homogeneous lane");
    auto authored = mwperf::testing::make_c09_correlated_fixture_law(
        input.instance.queues());
    REQUIRE(authored);
    auto authored_product = clone_arrival_product(authored.value());
    authored_product.runtime.decode_phase = {};
    make_arrival_access_portable_only(authored_product);
    auto authored_republished =
        mwperf::detail::publish_compiled_arrival_law(
            input.instance.queues(), std::move(authored_product));
    INFO((authored_republished
              ? std::string{}
              : authored_republished.error().code + ": " +
                    authored_republished.error().message));
    REQUIRE(authored_republished);
    REQUIRE(mwperf::builder_arrival_view(authored_republished.value())
                .finite_phase()
                .has_value());
    CHECK(mwperf::builder_arrival_view(authored_republished.value())
              .finite_phase()
              ->row_clock_semantics ==
          mwperf::ArrivalRowClockSemanticsV1::authored_slot_conditioned);

    auto homogeneous_product = clone_arrival_product(*input.arrival);
    homogeneous_product.runtime.decode_phase = {};
    make_arrival_access_portable_only(homogeneous_product);
    auto homogeneous_republished =
        mwperf::detail::publish_compiled_arrival_law(
            input.instance.queues(), std::move(homogeneous_product));
    REQUIRE_FALSE(homogeneous_republished);
    CHECK(homogeneous_republished.error().code ==
          "arrival_capability_contract_mismatch");
  }
}

TEST_CASE("C20 homogeneous quotient yields four exact clockful words and a finite kernel",
          "[c20][property][enumeration][multi-slot][branch-order][kernel]") {
  const auto enumerate = [](const bool reverse_domain_order,
                            const bool reverse_arrival_row) {
    auto fixture =
        mwperf::testing::c20::make_four_word_enumerable_framework(
            reverse_domain_order, false, reverse_arrival_row);
    auto provider =
        mwperf::audited_residence_provider(fixture.temporal.framework);
    REQUIRE(provider);
    auto slot = mwperf::audited_slot_executor(fixture.temporal.framework);
    auto temporal =
        mwperf::audited_temporal_framework(fixture.temporal.framework);
    REQUIRE_FALSE(slot);
    REQUIRE_FALSE(temporal);
    CHECK(slot.error().code == "c17.audited_slot_unavailable");
    CHECK(temporal.error().code ==
          "c17.audited_temporal_framework_unavailable");
    fixture.cminus_realize_calls->store(0U, std::memory_order_relaxed);
    fixture.cminus_enumerate_calls->store(0U, std::memory_order_relaxed);
    fixture.callback_clock_or->store(0U, std::memory_order_relaxed);
    fixture.temporal.residence_generator_calls->store(
        0U, std::memory_order_relaxed);

    auto row = mwperf::enumerate_residence_word_row(
        provider.value(), fixture.temporal.initial_state,
        mwperf::PmfRepresentationBudget::unbounded());
    INFO((row ? std::string{}
              : row.error().code + ": " + row.error().message));
    REQUIRE(row);
    CHECK(fixture.cminus_realize_calls->load(std::memory_order_relaxed) ==
          0U);
    CHECK(fixture.cminus_enumerate_calls->load(
              std::memory_order_relaxed) == 3U);
    CHECK(fixture.temporal.residence_generator_calls->load(
              std::memory_order_relaxed) == 0U);
    CHECK(fixture.callback_clock_or->load(std::memory_order_relaxed) == 0U);
    CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());
    REQUIRE(row.value().atoms().size() == 4U);

    std::array<bool, 4U> observed_arrival_histories{};
    std::array<mwperf::ExactRational, 2U> endpoint_phase_mass{
        mwperf::ExactRational::zero(), mwperf::ExactRational::zero()};
    std::vector<mwperf::Digest256> canonical_word_digests;
    canonical_word_digests.reserve(row.value().atoms().size());
    mwperf::ExactRational cumulative = mwperf::ExactRational::zero();
    const auto quarter = mwperf::testing::c17::rational(1, 4);
    const auto half = mwperf::testing::c17::rational(1, 2);
    auto q0 = fixture.temporal.instance.queues().index_at(2U);
    REQUIRE(q0);
    CHECK(fixture.temporal.instance.queues().queue_id(q0.value()) ==
          mwperf::testing::c16_designated_detail::queue("q0"));
    for (const auto& atom : row.value().atoms()) {
      CHECK(atom.exact_mass == quarter);
      CHECK(atom.structural_support);
      cumulative = cumulative + quarter;
      CHECK(atom.exact_cumulative_mass == cumulative);
      CHECK(atom.word.length() == mwperf::BigNat{2U});
      REQUIRE(atom.word.edges().size() == 2U);
      REQUIRE(atom.word.continuation_path().size() == 3U);
      CHECK(atom.word.edges()[0U].action().actual_departure.at(q0.value()));
      CHECK(atom.word.edges()[1U].action().actual_departure.at(q0.value()));

      std::size_t arrival_history = 0U;
      canonical_word_digests.push_back(atom.word.word_digest());
      for (std::size_t edge_index = 0U;
           edge_index < atom.word.edges().size(); ++edge_index) {
        const auto& edge = atom.word.edges()[edge_index];
        CHECK(edge.arrival().authored_slot ==
              mwperf::BigNat{static_cast<std::uint64_t>(edge_index)});
        const auto before_core =
            mwperf::detail::ArrivalCoreAccess::phase_core(
                edge.arrival().phase_before);
        const auto after_core =
            mwperf::detail::ArrivalCoreAccess::phase_core(
                edge.arrival().phase_after);
        REQUIRE(before_core);
        REQUIRE(after_core);
        CHECK(before_core->next_authored_slot ==
              mwperf::BigNat{static_cast<std::uint64_t>(edge_index)});
        CHECK(after_core->next_authored_slot ==
              mwperf::BigNat{static_cast<std::uint64_t>(edge_index + 1U)});
        const auto phase = mwperf::arrival_phase_canonical_state(
            edge.arrival().phase_after);
        REQUIRE(phase.size() == 1U);
        REQUIRE((phase.front() == std::byte{0U} ||
                 phase.front() == std::byte{1U}));
        arrival_history =
            arrival_history * 2U +
            std::to_integer<std::uint8_t>(phase.front());
      }
      REQUIRE(arrival_history < observed_arrival_histories.size());
      CHECK_FALSE(observed_arrival_histories[arrival_history]);
      observed_arrival_histories[arrival_history] = true;

      const auto endpoint = fixture.temporal.state_schema.decode(
          atom.word.event_endpoint());
      REQUIRE(endpoint);
      CHECK(endpoint.value().backlog.value_at_target_ordinal(0U) ==
            mwperf::BigNat{0U});
      CHECK(endpoint.value().boundary_index == mwperf::BigNat{2U});
      const auto endpoint_phase = mwperf::arrival_phase_canonical_state(
          endpoint.value().arrival_phase);
      REQUIRE(endpoint_phase.size() == 1U);
      const std::size_t endpoint_phase_index =
          std::to_integer<std::uint8_t>(endpoint_phase.front());
      REQUIRE(endpoint_phase_index < endpoint_phase_mass.size());
      CHECK(endpoint_phase_index == arrival_history % 2U);
      endpoint_phase_mass[endpoint_phase_index] =
          endpoint_phase_mass[endpoint_phase_index] + atom.exact_mass;
      CHECK(atom.word.raw_terminal_state() == atom.word.event_endpoint());
    }
    CHECK(std::ranges::all_of(observed_arrival_histories,
                              [](const bool seen) { return seen; }));
    CHECK(cumulative == mwperf::ExactRational::one());
    CHECK(endpoint_phase_mass[0U] == half);
    CHECK(endpoint_phase_mass[1U] == half);

    auto domain =
        mwperf::FiniteEventStateDomain::from_audited_provider(
            provider.value());
    INFO((domain ? std::string{}
                 : domain.error().code + ": " + domain.error().message));
    REQUIRE(domain);
    REQUIRE(domain.value().states().size() == 4U);
    for (const auto& state : domain.value().states()) {
      auto decoded = fixture.temporal.state_schema.decode(state);
      REQUIRE(decoded);
      CHECK(decoded.value().boundary_index == mwperf::BigNat{0U});
      const auto phase = mwperf::arrival_phase_canonical_state(
          decoded.value().arrival_phase);
      REQUIRE(phase.size() == 1U);
      CHECK((phase.front() == std::byte{0U} ||
             phase.front() == std::byte{1U}));
    }
    // Exact words retain the absolute physical boundary and therefore are not
    // themselves members of the zero-clock event quotient.
    for (const auto& atom : row.value().atoms()) {
      CHECK_FALSE(
          domain.value().index_of(atom.word.event_endpoint()).has_value());
    }

    auto kernel = mwperf::assemble_embedded_event_kernel(
        domain.value(), provider.value());
    INFO((kernel ? std::string{}
                 : kernel.error().code + ": " + kernel.error().message));
    REQUIRE(kernel);
    REQUIRE(kernel.value().rows().size() == 4U);
    std::vector<mwperf::ExactRational> semantic_endpoint_mass(
        8U, mwperf::ExactRational::zero());
    for (const auto& kernel_row : kernel.value().rows()) {
      auto entry = fixture.temporal.state_schema.decode(
          kernel_row.word_row.entry_state());
      REQUIRE(entry);
      CHECK(entry.value().boundary_index == mwperf::BigNat{0U});
      const auto entry_phase_bytes = mwperf::arrival_phase_canonical_state(
          entry.value().arrival_phase);
      REQUIRE(entry_phase_bytes.size() == 1U);
      const std::size_t entry_phase =
          std::to_integer<std::uint8_t>(entry_phase_bytes.front());
      REQUIRE(entry_phase < 2U);
      const mwperf::BigNat& entry_backlog =
          entry.value().backlog.value_at_target_ordinal(0U);
      REQUIRE((entry_backlog == mwperf::BigNat{0U} ||
               entry_backlog == mwperf::BigNat{2U}));
      const bool two_slot = entry_backlog == mwperf::BigNat{2U};
      const std::size_t row_class =
          (two_slot ? 0U : 2U) + entry_phase;
      REQUIRE(kernel_row.word_row.atoms().size() ==
              (two_slot ? 4U : 2U));
      for (const auto& word_atom : kernel_row.word_row.atoms()) {
        CHECK(word_atom.word.length() ==
              mwperf::BigNat{two_slot ? 2U : 1U});
        auto endpoint = fixture.temporal.state_schema.decode(
            word_atom.word.event_endpoint());
        REQUIRE(endpoint);
        CHECK(endpoint.value().boundary_index ==
              mwperf::BigNat{two_slot ? 2U : 1U});
        CHECK(endpoint.value().backlog.value_at_target_ordinal(0U) ==
              mwperf::BigNat{0U});
        CHECK_FALSE(domain.value()
                        .index_of(word_atom.word.event_endpoint())
                        .has_value());
      }
      CHECK(kernel_row.exact_total_mass == mwperf::ExactRational::one());
      REQUIRE(kernel_row.endpoint_atoms.size() == 2U);
      for (const auto& endpoint_atom : kernel_row.endpoint_atoms) {
        REQUIRE(endpoint_atom.endpoint_index <
                domain.value().states().size());
        auto endpoint = fixture.temporal.state_schema.decode(
            domain.value().states()[endpoint_atom.endpoint_index]);
        REQUIRE(endpoint);
        CHECK(endpoint.value().boundary_index == mwperf::BigNat{0U});
        CHECK(endpoint.value().backlog.value_at_target_ordinal(0U) ==
              mwperf::BigNat{0U});
        const auto phase_bytes = mwperf::arrival_phase_canonical_state(
            endpoint.value().arrival_phase);
        REQUIRE(phase_bytes.size() == 1U);
        const std::size_t endpoint_phase =
            std::to_integer<std::uint8_t>(phase_bytes.front());
        REQUIRE(endpoint_phase < 2U);
        CHECK(endpoint_atom.exact_mass == half);
        semantic_endpoint_mass[row_class * 2U + endpoint_phase] =
            semantic_endpoint_mass[row_class * 2U + endpoint_phase] +
            endpoint_atom.exact_mass;
      }
    }
    CHECK(std::ranges::all_of(
        semantic_endpoint_mass,
        [&half](const mwperf::ExactRational& mass) { return mass == half; }));
    CHECK(fixture.cminus_realize_calls->load(std::memory_order_relaxed) ==
          0U);
    CHECK(fixture.temporal.residence_generator_calls->load(
              std::memory_order_relaxed) == 0U);
    CHECK(fixture.callback_clock_or->load(std::memory_order_relaxed) == 0U);
    return std::pair{semantic_endpoint_mass, canonical_word_digests};
  };

  const auto forward = enumerate(false, false);
  const auto reversed_frontier = enumerate(false, true);
  const auto reversed_domain = enumerate(true, false);
  // C09 returns the same exact atoms in the opposite order.  C17/C20 must
  // canonicalize the completed frontier back to identical word order and
  // digests, not merely preserve the endpoint aggregate.
  CHECK(forward == reversed_frontier);
  CHECK(forward.first == reversed_domain.first);
}

TEST_CASE("C20 quotient callbacks cannot recover the physical boundary",
          "[c20][property][enumeration][quotient][negative]") {
  auto fixture =
      mwperf::testing::c20::make_four_word_enumerable_framework(false, true);
  auto provider =
      mwperf::audited_residence_provider(fixture.temporal.framework);
  REQUIRE(provider);
  fixture.cminus_realize_calls->store(0U, std::memory_order_relaxed);
  fixture.callback_clock_or->store(0U, std::memory_order_relaxed);
  fixture.temporal.residence_generator_calls->store(
      0U, std::memory_order_relaxed);

  // This fixture intentionally uses the inherited pre-correction predicate
  // "boundary == 2".  The audited quotient ABI presents boundary zero to the
  // callback, so it cannot manufacture a stop from the physical clock and the
  // exact frontier is rejected at the declared residence maximum.
  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), fixture.temporal.initial_state,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE_FALSE(row);
  CHECK(row.error().code == "c20.declared_max_residence_exceeded");
  CHECK(fixture.callback_clock_or->load(std::memory_order_relaxed) == 0U);
  CHECK(fixture.cminus_realize_calls->load(std::memory_order_relaxed) ==
        0U);
  CHECK(fixture.temporal.residence_generator_calls->load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C20 empty deterministic trace remains countable and cannot seal a clock quotient",
          "[c20][property][enumeration][quotient][negative][nonhomogeneous]") {
  auto countable =
      mwperf::testing::c20::prepare_empty_trace_countable_candidate(false);
  CHECK(countable.instance.arrival().family() ==
        mwperf::ArrivalFamily::deterministic_trace);
  auto framework = mwperf::audit_v0_causality(
      std::move(countable.candidate), countable.descriptor,
      std::move(countable.access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  auto provider = mwperf::audited_residence_provider(framework.value());
  REQUIRE(provider);
  auto domain = mwperf::FiniteEventStateDomain::from_audited_provider(
      provider.value());
  REQUIRE_FALSE(domain);
  CHECK(domain.error().code == "c20.finite_event_domain_unavailable");

  auto quotient =
      mwperf::testing::c20::prepare_empty_trace_countable_candidate(true);
  CHECK(quotient.instance.arrival().family() ==
        mwperf::ArrivalFamily::deterministic_trace);
  auto rejected = mwperf::audit_v0_causality(
      std::move(quotient.candidate), quotient.descriptor,
      std::move(quotient.access));
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code ==
        "c17.unaudited_finite_event_clock_quotient");
}

TEST_CASE("C20 multi-slot word obeys exact backlog and phase recursion",
          "[c20][property][replay][multi-slot]") {
  auto fixture =
      mwperf::testing::c20::make_deterministic_three_slot_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  auto cursor = mwperf::begin_residence(view.value(), fixture.initial_state);
  REQUIRE(cursor);
  auto bank = mwperf::testing::C20FixtureAccess::initialized_temporal_bank(
      view.value(), fixture.instance, mwperf::MasterSeed{0xC203540U});
  REQUIRE(bank);
  auto q0 = fixture.instance.queues().index_at(0U);
  REQUIRE(q0);

  std::size_t slots = 0U;
  while (cursor.value().lifecycle() ==
         mwperf::ResidenceLifecycleV1::open) {
    auto step = mwperf::advance_residence(
        cursor.value(), executor.value(), bank.value());
    REQUIRE(step);
    const auto before = fixture.state_schema.decode(
        step.value().edge().pre_state());
    const auto after = fixture.state_schema.decode(
        step.value().edge().successor_state());
    REQUIRE(before);
    REQUIRE(after);
    REQUIRE(step.value().edge().arrival().batch.binding().has_value());
    auto arrival = mwperf::project_arrival_count(
        step.value().edge().arrival().batch, q0.value(),
        *step.value().edge().arrival().batch.binding());
    REQUIRE(arrival);
    auto after_service = mwperf::checked_subtract(
        before.value().backlog.value_at_target_ordinal(0U),
        mwperf::BigNat{
            step.value().edge().action().actual_departure.at(q0.value())
                ? 1U
                : 0U});
    REQUIRE(after_service);
    CHECK(after.value().backlog.value_at_target_ordinal(0U) ==
          after_service.value() + arrival.value());
    CHECK(mwperf::testing::c17::same_phase(
        before.value().arrival_phase,
        step.value().edge().arrival().phase_before));
    CHECK(mwperf::testing::c17::same_phase(
        after.value().arrival_phase,
        step.value().edge().arrival().phase_after));
    CHECK(step.value().edge().pre_state() ==
          cursor.value().edges().back().pre_state());
    CHECK(step.value().edge().successor_state() ==
          cursor.value().current_state());
    ++slots;
    auto stop = mwperf::validate_residence_stop(
        cursor.value(), step.value());
    REQUIRE(stop);
    CHECK(stop.value().stops() == (slots == 3U));
  }
  CHECK(slots == 3U);
  auto word = mwperf::finalize_residence_word(cursor.value());
  REQUIRE(word);
  REQUIRE(word.value().continuation_path().size() ==
          word.value().edges().size() + 1U);
  for (std::size_t slot = 0U; slot < word.value().edges().size(); ++slot) {
    CHECK(word.value().continuation_path()[slot].canonical_value ==
          word.value().edges()[slot].pre_state().canonical_value);
    CHECK(word.value().continuation_path()[slot + 1U].canonical_value ==
          word.value().edges()[slot].successor_state().canonical_value);
    if (slot != 0U) {
      CHECK(word.value().edges()[slot - 1U].successor_state() ==
            word.value().edges()[slot].pre_state());
    }
  }
  CHECK(word.value().event_endpoint() ==
        word.value().edges().back().successor_state());
}

TEST_CASE("C20 every realized unit word belongs to exact enumerable support",
          "[c20][property][realized-support]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  REQUIRE(provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(row);

  for (std::uint64_t seed = 0U; seed != 24U; ++seed) {
    const auto word = realize_unit_word(
        fixture, view.value(), executor.value(), entrance, 0xC20100U + seed);
    const auto found = std::ranges::find_if(
        row.value().atoms(), [&](const mwperf::ResidenceWordRowAtomV1& atom) {
          return atom.word.word_digest() == word.word_digest() &&
                 atom.structural_support;
        });
    CHECK(found != row.value().atoms().end());
  }
}

TEST_CASE("C20 residence replay is exact backlog and arrival-phase recursion",
          "[c20][property][replay]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  const auto q0 = fixture.instance.queues().index_at(0U);
  REQUIRE(q0);

  for (std::uint8_t backlog = 0U; backlog != 4U; ++backlog) {
    for (const bool phase_one : std::array{false, true}) {
      const auto entrance = mwperf::testing::c17::reduced_state(
          fixture.ordered_targets, {backlog}, phase_one,
          phase_one ? 1U : 0U);
      const auto word = realize_unit_word(
          fixture, view.value(), executor.value(), entrance,
          0xC20200U + backlog * 2U + static_cast<std::uint64_t>(phase_one));
      REQUIRE(word.edges().size() == 1U);
      REQUIRE(word.continuation_path().size() == 2U);
      const auto& edge = word.edges().front();
      CHECK(word.continuation_path().front() == edge.pre_state());
      CHECK(word.continuation_path().back() == edge.successor_state());
      CHECK(word.entry_state() == edge.pre_state());
      CHECK(word.event_endpoint() == edge.successor_state());
      const auto before = fixture.state_schema.decode(edge.pre_state());
      const auto after = fixture.state_schema.decode(edge.successor_state());
      REQUIRE(before);
      REQUIRE(after);
      REQUIRE(edge.arrival().batch.binding().has_value());
      auto arrival = mwperf::project_arrival_count(
          edge.arrival().batch, q0.value(),
          *edge.arrival().batch.binding());
      REQUIRE(arrival);
      auto after_service = mwperf::checked_subtract(
          before.value().backlog.value_at_target_ordinal(0U),
          mwperf::BigNat{edge.action().actual_departure.at(q0.value()) ? 1U
                                                                      : 0U});
      REQUIRE(after_service);
      CHECK(after.value().backlog.value_at_target_ordinal(0U) ==
            after_service.value() + arrival.value());
      CHECK(mwperf::testing::c17::same_phase(
          before.value().arrival_phase, edge.arrival().phase_before));
      CHECK(mwperf::testing::c17::same_phase(
          after.value().arrival_phase, edge.arrival().phase_after));
      CHECK(edge.stage_trace() == mwperf::kCausalStageOrderV1);
    }
  }
}

TEST_CASE("C20 repeated realization and enumeration have no drift",
          "[c20][property][determinism][cold]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto view = mwperf::audited_romr_view(fixture.framework);
  auto executor = mwperf::audited_slot_executor(fixture.framework);
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  auto row_provider = mwperf::audited_row_provider(fixture.framework);
  REQUIRE(view);
  REQUIRE(executor);
  REQUIRE(provider);
  REQUIRE(row_provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  const auto first_word = realize_unit_word(
      fixture, view.value(), executor.value(), entrance, 0xC20301U);
  const auto second_word = realize_unit_word(
      fixture, view.value(), executor.value(), entrance, 0xC20301U);
  CHECK(first_word.word_digest() == second_word.word_digest());
  CHECK(first_word.edges().front() == second_word.edges().front());

  auto first_row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(first_row);

  // Interleave C17 row compilation.  Neither operation may warm or spend
  // mutable optimizer state that changes a subsequent pure word enumeration.
  auto first_slot_row =
      mwperf::compile_reduced_kernel_row(row_provider.value(), entrance);
  auto second_slot_row =
      mwperf::compile_reduced_kernel_row(row_provider.value(), entrance);
  REQUIRE(first_slot_row);
  REQUIRE(second_slot_row);
  REQUIRE(first_slot_row.value().atoms().size() ==
          second_slot_row.value().atoms().size());
  for (std::size_t index = 0U; index < first_slot_row.value().atoms().size();
       ++index) {
    CHECK(first_slot_row.value().atoms()[index].edge ==
          second_slot_row.value().atoms()[index].edge);
    CHECK(first_slot_row.value().atoms()[index].exact_mass ==
          second_slot_row.value().atoms()[index].exact_mass);
  }
  auto domain =
      mwperf::FiniteEventStateDomain::from_audited_provider(provider.value());
  REQUIRE_FALSE(domain);
  CHECK(domain.error().code == "c20.finite_event_domain_unavailable");

  auto second_row = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(second_row);
  check_same_word_row(first_row.value(), second_row.value());
}

TEST_CASE("C20 forwards a frozen representation budget without fallback",
          "[c20][property][budget][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto provider = mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(provider);
  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});

  const mwperf::PmfRepresentationBudget tiny{1U};
  auto rejected = mwperf::enumerate_residence_word_row(
      provider.value(), entrance, tiny);
  REQUIRE_FALSE(rejected);
  CHECK((std::string_view(rejected.error().code).starts_with("c17.") ||
         std::string_view(rejected.error().code).starts_with("c20.")));

  auto exact = mwperf::enumerate_residence_word_row(
      provider.value(), entrance,
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(exact);
  CHECK(exact.value().exact_total_mass() == mwperf::ExactRational::one());
}

}  // namespace
