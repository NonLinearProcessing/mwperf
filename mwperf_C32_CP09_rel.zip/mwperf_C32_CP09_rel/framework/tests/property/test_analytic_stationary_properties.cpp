#include <cstddef>
#include <cstdint>
#include <cmath>
#include <optional>
#include <random>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/stationary/analytic.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"

namespace {

using mwperf::ExactRational;

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto value =
      mwperf::sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::SourceNode source(const std::string& pointer) {
  return mwperf::SourceNode::make_null(
      mwperf::SourceLocation{"c19-property", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] mwperf::SelectionSpec fixed_point_unique_selection() {
  mwperf::FixedPointSelection fixed =
      mwperf::FixedPointUniqueSelection{source("/selection/fixed-point")};
  return mwperf::SelectionSpec{std::move(fixed)};
}

[[nodiscard]] mwperf::SelectionSpec stationary_unique_selection() {
  return mwperf::StationaryUniqueSelection{
      source("/selection/stationary-unique")};
}

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator = 1) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::SolverPolicy fixed_point_policy(
    const std::string& identity, const std::uint64_t iterations) {
  return {mwperf::LinearMethod::dense_pivoted, mwperf::BigNat{iterations},
          rational(1, 1048576), ExactRational::zero(),
          digest("c19.property.fixed-point." + identity)};
}

[[nodiscard]] mwperf::SolverPolicy stationary_policy(
    const std::string& identity) {
  return {mwperf::LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000LL), ExactRational::zero(),
          digest("c19.property.stationary." + identity)};
}

[[nodiscard]] mwperf::ArrivalLaw arrival_law(
    const std::vector<ExactRational>& probabilities) {
  std::vector<mwperf::ScalarArrivalMassV1> atoms;
  atoms.reserve(probabilities.size());
  for (std::size_t index = 0U; index < probabilities.size(); ++index) {
    atoms.push_back({mwperf::BigNat{static_cast<std::uint64_t>(index)},
                     probabilities[index]});
  }
  auto law =
      mwperf::testing::C19FixtureAccess::arrival_law(std::move(atoms));
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] mwperf::testing::ExactScalarResponseFixtureV1 scalar_response(
    std::vector<ExactRational> prefix,
    std::optional<std::uint64_t> constant_tail_from = std::nullopt,
    std::optional<ExactRational> constant_tail_service = std::nullopt) {
  std::optional<mwperf::BigNat> cutoff;
  if (constant_tail_from.has_value()) {
    cutoff = mwperf::BigNat{*constant_tail_from};
  }
  return {std::move(prefix), std::move(cutoff),
          std::move(constant_tail_service)};
}

[[nodiscard]] mwperf::TailService tail_service(const ExactRational& value) {
  auto service = mwperf::TailService::make(value);
  REQUIRE(service);
  return std::move(service).value();
}

[[nodiscard]] ExactRational divide(const ExactRational& numerator,
                                   const ExactRational& denominator) {
  auto value = mwperf::checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] ExactRational pmf_at(
    const std::vector<ExactRational>& arrival,
    const std::int64_t index) {
  if (index < 0 || static_cast<std::size_t>(index) >= arrival.size()) {
    return ExactRational::zero();
  }
  return arrival[static_cast<std::size_t>(index)];
}

[[nodiscard]] ExactRational survival_at(
    const std::vector<ExactRational>& arrival,
    const std::int64_t threshold) {
  if (threshold <= 0) {
    return ExactRational::one();
  }
  ExactRational mass = ExactRational::zero();
  for (std::size_t index = static_cast<std::size_t>(threshold);
       index < arrival.size(); ++index) {
    mass = mass + arrival[index];
  }
  return mass;
}

// Direct enumeration of (D,A) in SF.14. This deliberately does not call a
// production row/recurrence helper.
[[nodiscard]] ExactRational direct_sf14_entry(
    const std::vector<ExactRational>& arrival,
    const ExactRational& service, const std::uint64_t from,
    const std::uint64_t to) {
  const auto offset = static_cast<std::int64_t>(to) -
                      static_cast<std::int64_t>(from);
  return service * pmf_at(arrival, offset + 1) +
         (ExactRational::one() - service) * pmf_at(arrival, offset);
}

[[nodiscard]] ExactRational direct_cut_rhs(
    const std::vector<ExactRational>& arrival,
    const std::vector<ExactRational>& service,
    const std::vector<ExactRational>& masses, const std::size_t cut) {
  ExactRational rhs = ExactRational::zero();
  for (std::size_t index = 0U; index < cut; ++index) {
    const auto distance = static_cast<std::int64_t>(cut - index);
    rhs = rhs + masses[index] *
                    ((ExactRational::one() - service[index]) *
                         survival_at(arrival, distance) +
                     service[index] * survival_at(arrival, distance + 1));
  }
  return rhs;
}

struct ThreeBinOracle final {
  ExactRational w1;
  ExactRational w2;
  ExactRational pi0;
  ExactRational pi1;
  ExactRational pi2;
  ExactRational tail;
  ExactRational mean;
};

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::testing::ExactPhaseResponseFixtureV1
alternating_phase_fixture(const bool permuted) {
  const std::vector<mwperf::ArrivalPhaseIdentityV1> original_phases{
      phase(0U), phase(1U)};
  const std::vector<ExactRational> original_k0{
      ExactRational::zero(), ExactRational::zero(), ExactRational::one(),
      ExactRational::zero()};
  const std::vector<ExactRational> original_k1{
      ExactRational::zero(), ExactRational::one(), ExactRational::zero(),
      ExactRational::zero()};
  const std::vector<ExactRational> original_service{
      ExactRational::zero(), ExactRational::zero(), ExactRational::one(),
      ExactRational::one()};
  const std::vector<std::size_t> order =
      permuted ? std::vector<std::size_t>{1U, 0U}
               : std::vector<std::size_t>{0U, 1U};
  auto conjugate = [&order](const std::vector<ExactRational>& matrix) {
    std::vector<ExactRational> result;
    result.reserve(4U);
    for (const std::size_t row : order) {
      for (const std::size_t column : order) {
        result.push_back(matrix[row * 2U + column]);
      }
    }
    return result;
  };

  std::vector<mwperf::ArrivalPhaseIdentityV1> phases;
  std::vector<ExactRational> configured_marginal;
  std::vector<ExactRational> service;
  phases.reserve(2U);
  configured_marginal.reserve(2U);
  service.reserve(4U);
  for (const std::size_t index : order) {
    phases.push_back(original_phases[index]);
    configured_marginal.push_back(rational(1, 2));
  }
  for (std::size_t level = 0U; level <= 1U; ++level) {
    for (const std::size_t index : order) {
      service.push_back(original_service[level * 2U + index]);
    }
  }
  return {std::move(phases),
          {{mwperf::BigNat{0U}, conjugate(original_k0)},
           {mwperf::BigNat{1U}, conjugate(original_k1)}},
          std::move(configured_marginal),
          std::move(service),
          {mwperf::PhaseLevelCompletionKindV1::exact_closed,
           mwperf::BigNat{1U}, std::nullopt, {}}};
}

// Appendix D.5--D.7 / SF.22d--e, kept independent of every production
// recurrence, PGF, and three-bin summary helper.
[[nodiscard]] ThreeBinOracle independent_three_bin_oracle(
    const std::vector<ExactRational>& arrival, const ExactRational& s1,
    const ExactRational& s2, const ExactRational& c) {
  REQUIRE(arrival.size() >= 2U);
  const ExactRational a0 = arrival[0U];
  const ExactRational a1 = arrival[1U];
  const ExactRational w1 =
      divide(ExactRational::one() - a0, a0 * s1);
  const ExactRational w2_numerator =
      ExactRational::one() - a0 - a1 +
      w1 * ((ExactRational::one() - s1) *
                (ExactRational::one() - a0) +
            s1 * (ExactRational::one() - a0 - a1));
  const ExactRational w2 = divide(w2_numerator, a0 * s2);

  ExactRational lambda = ExactRational::zero();
  ExactRational second_moment = ExactRational::zero();
  for (std::size_t index = 0U; index < arrival.size(); ++index) {
    const ExactRational level = rational(static_cast<std::int64_t>(index));
    lambda = lambda + level * arrival[index];
    second_moment = second_moment + level * level * arrival[index];
  }

  const ExactRational normalization =
      c + w1 * (c - s1) + w2 * (c - s2);
  const ExactRational pi0 = divide(c - lambda, normalization);
  const ExactRational pi1 = w1 * pi0;
  const ExactRational pi2 = w2 * pi0;
  const ExactRational tail =
      ExactRational::one() - pi0 - pi1 - pi2;
  const ExactRational correction_derivative =
      pi1 * (c - s1) + rational(2) * pi2 * (c - s2);
  const ExactRational mean = divide(
      second_moment + lambda - rational(2) * lambda * lambda +
          rational(2) * correction_derivative,
      rational(2) * (c - lambda));
  return {w1, w2, pi0, pi1, pi2, tail, mean};
}

}  // namespace

TEST_CASE("C19 SF.14 agrees with direct D-A enumeration and exact row mass",
          "[c19][property][sf14]") {
  std::mt19937_64 generator{0xC19014ULL};
  constexpr std::size_t case_count = 12U;
  for (std::size_t case_index = 0U; case_index < case_count; ++case_index) {
    CAPTURE(case_index);
    const std::int64_t arrival_denominator =
        3 + static_cast<std::int64_t>(generator() % 17U);
    const std::int64_t arrival_numerator =
        1 + static_cast<std::int64_t>(
                generator() %
                static_cast<std::uint64_t>(arrival_denominator - 1));
    const std::vector<ExactRational> arrival{
        rational(arrival_denominator - arrival_numerator,
                 arrival_denominator),
        rational(arrival_numerator, arrival_denominator)};

    const std::size_t closure_level =
        1U + static_cast<std::size_t>(generator() % 3U);
    std::vector<ExactRational> services(closure_level + 2U,
                                        ExactRational::zero());
    for (std::size_t level = 1U; level < services.size(); ++level) {
      const std::int64_t denominator =
          2 + static_cast<std::int64_t>(generator() % 17U);
      const std::int64_t numerator =
          1 + static_cast<std::int64_t>(
                  generator() % static_cast<std::uint64_t>(denominator - 1));
      services[level] = rational(numerator, denominator);
    }
    // With Bernoulli input, mu(closure_level)=1 prevents every transition
    // above the declared boundary, so this is an exact finite closure rather
    // than a numerical truncation.
    services[closure_level] = ExactRational::one();

    const auto configured = arrival_law(arrival);
    auto assembled = mwperf::testing::C19FixtureAccess::scalar_flux(
        configured, scalar_response(services));
    INFO((assembled ? std::string{}
                    : assembled.error().code + ": " +
                          assembled.error().message));
    REQUIRE(assembled);
    const auto flux = std::move(assembled).value();
    auto closed = mwperf::solve_scalar_cut_recursion(
        flux, mwperf::TailPolicy::exact_finite_closure(
                  mwperf::Cutoff{mwperf::BigNat{
                      static_cast<std::uint64_t>(closure_level)}}));
    REQUIRE(closed);
    REQUIRE(closed.value().normalized_law_established());
    for (std::size_t level = 0U; level < services.size(); ++level) {
      const ExactRational service =
          level == 0U ? ExactRational::zero() : services[level];
      ExactRational row_mass = ExactRational::zero();
      const std::uint64_t last = static_cast<std::uint64_t>(level + 1U);
      for (std::uint64_t destination = 0U; destination <= last;
           ++destination) {
        const ExactRational enumerated = direct_sf14_entry(
            arrival, service, static_cast<std::uint64_t>(level), destination);
        ExactRational by_events = ExactRational::zero();
        for (std::size_t arrival_count = 0U;
             arrival_count < arrival.size(); ++arrival_count) {
          const auto no_departure_destination =
              static_cast<std::uint64_t>(level + arrival_count);
          if (destination == no_departure_destination) {
            by_events = by_events +
                        (ExactRational::one() - service) *
                            arrival[arrival_count];
          }
          if (level > 0U) {
            const auto departure_destination =
                static_cast<std::uint64_t>(level - 1U + arrival_count);
            if (destination == departure_destination) {
              by_events = by_events + service * arrival[arrival_count];
            }
          }
        }
        CAPTURE(level, destination);
        CHECK(enumerated == by_events);
        auto actual = flux.transition_probability(
            mwperf::BigNat{static_cast<std::uint64_t>(level)},
            mwperf::BigNat{destination});
        REQUIRE(actual);
        CHECK(actual.value() == enumerated);
        row_mass = row_mass + enumerated;
      }
      CHECK(row_mass == ExactRational::one());
    }
  }
}

TEST_CASE("C19 SF.19 cuts hold on exact finite Bernoulli closures",
          "[c19][property][sf19][finite-closure]") {
  const std::vector<ExactRational> rates{
      rational(1, 5), rational(3, 10), rational(1, 2), rational(3, 4)};
  for (const auto& rate : rates) {
    const std::vector<ExactRational> arrival{
        ExactRational::one() - rate, rate};
    const std::vector<ExactRational> service{
        ExactRational::zero(), ExactRational::one(), ExactRational::zero()};
    const std::vector<ExactRational> masses{
        ExactRational::one() - rate, rate, ExactRational::zero()};
    const auto configured = arrival_law(arrival);
    auto assembled = mwperf::testing::C19FixtureAccess::scalar_flux(
        configured,
        scalar_response({ExactRational::zero(), ExactRational::one()}));
    REQUIRE(assembled);
    auto solved = mwperf::solve_scalar_cut_recursion(
        assembled.value(),
        mwperf::TailPolicy::exact_finite_closure(
            mwperf::Cutoff{mwperf::BigNat{1U}}));
    INFO((solved ? std::string{}
                 : solved.error().code + ": " + solved.error().message));
    REQUIRE(solved);
    REQUIRE(solved.value().normalized_law_established());
    for (std::uint64_t level = 0U; level <= 2U; ++level) {
      auto mass = solved.value().mass(mwperf::BigNat{level});
      REQUIRE(mass);
      CHECK(mass.value() == masses[static_cast<std::size_t>(level)]);
    }
    for (std::size_t cut = 1U; cut <= 2U; ++cut) {
      const ExactRational lhs =
          masses[cut] * service[cut] * arrival.front();
      CHECK(lhs == direct_cut_rhs(arrival, service, masses, cut));
    }
    CHECK(masses[0U] + masses[1U] + masses[2U] ==
          ExactRational::one());
  }
}

TEST_CASE("C19 cut, birth-death, and constant-tail solvers overlap exactly",
          "[c19][property][solver-overlap]") {
  const auto configured =
      arrival_law({rational(3, 4), rational(1, 4)});
  const auto response = scalar_response(
      {ExactRational::zero()}, 1U, rational(1, 2));
  const auto c = tail_service(rational(1, 2));

  auto flux = mwperf::testing::C19FixtureAccess::scalar_flux(configured,
                                                             response);
  REQUIRE(flux);
  auto cut = mwperf::solve_scalar_cut_recursion(
      flux.value(), mwperf::TailPolicy::constant_response(
                        mwperf::Cutoff{mwperf::BigNat{0U}}, c));
  auto birth_death =
      mwperf::testing::C19FixtureAccess::solve_bernoulli(configured, response);
  auto constant_tail = mwperf::testing::C19FixtureAccess::solve_constant_tail(
      configured, response, mwperf::Cutoff{mwperf::BigNat{0U}}, c);
  INFO((cut ? std::string{}
            : cut.error().code + ": " + cut.error().message));
  INFO((birth_death
            ? std::string{}
            : birth_death.error().code + ": " + birth_death.error().message));
  INFO((constant_tail
            ? std::string{}
            : constant_tail.error().code + ": " +
                  constant_tail.error().message));
  REQUIRE(cut);
  REQUIRE(birth_death);
  REQUIRE(constant_tail);
  REQUIRE(cut.value().normalized_law_established());
  REQUIRE(birth_death.value().normalized_law_established());
  REQUIRE(constant_tail.value().normalized_law_established());

  ExactRational expected = rational(1, 2);
  for (std::uint64_t level = 0U; level <= 8U; ++level) {
    if (level == 1U) {
      expected = rational(1, 3);
    } else if (level > 1U) {
      expected = divide(expected, rational(3));
    }
    auto cut_mass = cut.value().mass(mwperf::BigNat{level});
    auto birth_death_mass =
        birth_death.value().mass(mwperf::BigNat{level});
    auto constant_tail_mass =
        constant_tail.value().mass(mwperf::BigNat{level});
    REQUIRE(cut_mass);
    REQUIRE(birth_death_mass);
    REQUIRE(constant_tail_mass);
    CHECK(cut_mass.value() == birth_death_mass.value());
    CHECK(cut_mass.value() == constant_tail_mass.value());
    CHECK(cut_mass.value() == expected);
  }

  REQUIRE(cut.value().exact_mean_backlog());
  REQUIRE(birth_death.value().exact_mean_backlog());
  REQUIRE(constant_tail.value().exact_mean_backlog());
  CHECK(*cut.value().exact_mean_backlog() == rational(3, 4));
  CHECK(*birth_death.value().exact_mean_backlog() == rational(3, 4));
  CHECK(*constant_tail.value().exact_mean_backlog() == rational(3, 4));

  const auto transform = mwperf::ArrivalTransform::from(configured);
  const std::vector<ExactRational> points{
      ExactRational::zero(), rational(1, 4), rational(1, 2),
      rational(3, 4), ExactRational::one()};
  std::optional<ExactRational> previous;
  for (const auto& z : points) {
    auto point = mwperf::EvaluationPoint::make(z);
    REQUIRE(point);
    const ExactRational expected_pgf =
        rational(1, 2) + divide(z * rational(1, 3),
                                ExactRational::one() - z * rational(1, 3));
    const ExactRational expected_response_pgf =
        rational(1, 2) * (expected_pgf - rational(1, 2));
    std::optional<ExactRational> reference_pgf;
    std::optional<ExactRational> reference_response_pgf;
    for (const auto* law :
         {&cut.value(), &birth_death.value(), &constant_tail.value()}) {
      auto readout = mwperf::evaluate_scalar_pgf_and_moments(
          *law, transform, point.value());
      REQUIRE(readout);
      REQUIRE(readout.value().exact_pgf());
      REQUIRE(readout.value().exact_response_weighted_pgf());
      CHECK(*readout.value().exact_pgf() == expected_pgf);
      CHECK(*readout.value().exact_response_weighted_pgf() ==
            expected_response_pgf);
      if (reference_pgf.has_value()) {
        CHECK(*readout.value().exact_pgf() == *reference_pgf);
        CHECK(*readout.value().exact_response_weighted_pgf() ==
              *reference_response_pgf);
      } else {
        reference_pgf = *readout.value().exact_pgf();
        reference_response_pgf =
            *readout.value().exact_response_weighted_pgf();
      }
    }
    REQUIRE(reference_pgf);
    if (previous.has_value()) {
      CHECK(!(*reference_pgf < *previous));
    }
    previous = *reference_pgf;
  }
  REQUIRE(previous);
  CHECK(*previous == ExactRational::one());
}

TEST_CASE("C19 independent D.5-D.7 oracle retains exact rational cases",
          "[c19][property][three-bin][oracle]") {
  struct Case final {
    std::vector<ExactRational> arrival;
    ExactRational s1;
    ExactRational s2;
    ExactRational c;
    ExactRational pi0;
    ExactRational pi1;
    ExactRational pi2;
    ExactRational tail;
    ExactRational mean;
    mwperf::AnalyticStationaryStatusV1 status;
  };
  std::vector<Case> cases{
      {{rational(3, 4), rational(1, 4)},
       rational(1, 2), rational(1, 2), rational(1, 2),
       rational(1, 2), rational(1, 3), rational(1, 9), rational(1, 18),
       rational(3, 4),
       mwperf::AnalyticStationaryStatusV1::strict_tail_stable},
      {{rational(4, 5), rational(1, 5)},
       rational(3, 4), rational(1, 4), rational(2, 3),
       rational(336, 485), rational(112, 485), rational(28, 485),
       rational(9, 485), rational(1374, 3395),
       mwperf::AnalyticStationaryStatusV1::strict_tail_stable},
      {{rational(1, 2), rational(1, 3), rational(1, 6)},
       rational(2, 3), rational(3, 4), rational(4, 5),
       rational(12, 97), rational(18, 97), rational(56, 291),
       rational(145, 291), rational(3779, 1164),
       mwperf::AnalyticStationaryStatusV1::strict_tail_stable},
      {{rational(7, 10), rational(3, 10)},
       ExactRational::one(), rational(3, 10), rational(7, 10),
       rational(7, 10), rational(3, 10), ExactRational::zero(),
       ExactRational::zero(), rational(3, 10),
       mwperf::AnalyticStationaryStatusV1::finite_closed_tail_unreachable}};

  std::mt19937_64 generator{0xC19008ULL};
  constexpr std::size_t generated_pairs = 6U;
  for (std::size_t pair = 0U; pair < generated_pairs; ++pair) {
    const std::int64_t a0_weight =
        20 + static_cast<std::int64_t>(generator() % 11U);
    const std::int64_t a1_weight =
        1 + static_cast<std::int64_t>(generator() % 5U);
    const std::int64_t a2_weight =
        1 + static_cast<std::int64_t>(generator() % 3U);
    const std::int64_t total = a0_weight + a1_weight + a2_weight;
    const std::vector<ExactRational> arrival{
        rational(a0_weight, total), rational(a1_weight, total),
        rational(a2_weight, total)};
    const ExactRational low =
        rational(1 + static_cast<std::int64_t>(generator() % 3U), 10);
    const ExactRational high =
        rational(7 + static_cast<std::int64_t>(generator() % 3U), 10);
    const ExactRational c =
        rational(5 + static_cast<std::int64_t>(generator() % 5U), 10);

    const auto append_case = [&](const ExactRational& s1,
                                 const ExactRational& s2) {
      const ThreeBinOracle oracle =
          independent_three_bin_oracle(arrival, s1, s2, c);
      cases.push_back({arrival, s1, s2, c, oracle.pi0, oracle.pi1,
                       oracle.pi2, oracle.tail, oracle.mean,
                       mwperf::AnalyticStationaryStatusV1::strict_tail_stable});
    };
    // Each exact batch PMF is checked with both coefficient permutations;
    // the high-then-low ordering is deliberately nonmonotone.
    append_case(high, low);
    append_case(low, high);
  }

  for (std::size_t index = 0U; index < cases.size(); ++index) {
    CAPTURE(index);
    const auto& item = cases[index];
    const ThreeBinOracle oracle = independent_three_bin_oracle(
        item.arrival, item.s1, item.s2, item.c);
    CHECK(oracle.pi0 == item.pi0);
    CHECK(oracle.pi1 == item.pi1);
    CHECK(oracle.pi2 == item.pi2);
    CHECK(oracle.tail == item.tail);
    CHECK(oracle.mean == item.mean);
    CHECK(oracle.pi0 + oracle.pi1 + oracle.pi2 + oracle.tail ==
          ExactRational::one());

    const auto configured = arrival_law(item.arrival);
    const auto response = scalar_response(
        {ExactRational::zero(), item.s1, item.s2}, 3U, item.c);
    auto solved = mwperf::testing::C19FixtureAccess::solve_constant_tail(
        configured, response, mwperf::Cutoff{mwperf::BigNat{2U}},
        tail_service(item.c));
    INFO((solved ? std::string{}
                 : solved.error().code + ": " + solved.error().message));
    REQUIRE(solved);
    REQUIRE(solved.value().normalized_law_established());
    auto pi0 = solved.value().mass(mwperf::BigNat{0U});
    auto pi1 = solved.value().mass(mwperf::BigNat{1U});
    auto pi2 = solved.value().mass(mwperf::BigNat{2U});
    REQUIRE(pi0);
    REQUIRE(pi1);
    REQUIRE(pi2);
    CHECK(pi0.value() == oracle.pi0);
    CHECK(pi1.value() == oracle.pi1);
    CHECK(pi2.value() == oracle.pi2);
    REQUIRE(solved.value().exact_tail_mass());
    CHECK(*solved.value().exact_tail_mass() == oracle.tail);
    REQUIRE(solved.value().exact_mean_backlog());
    CHECK(*solved.value().exact_mean_backlog() == oracle.mean);
    CHECK(solved.value().status() == item.status);

    auto summary = mwperf::testing::C19ThreeBinFixtureAccess::summarize(
        configured, response, {true, true, true, true, true, true});
    INFO((summary ? std::string{}
                  : summary.error().code + ": " + summary.error().message));
    REQUIRE(summary);
    REQUIRE(summary.value().pi_zero());
    REQUIRE(summary.value().pi_one());
    REQUIRE(summary.value().pi_two());
    REQUIRE(summary.value().tail_mass_from_three());
    CHECK(*summary.value().pi_zero() == oracle.pi0);
    CHECK(*summary.value().pi_one() == oracle.pi1);
    CHECK(*summary.value().pi_two() == oracle.pi2);
    CHECK(*summary.value().tail_mass_from_three() == oracle.tail);
    CHECK(summary.value().mu_zero() == ExactRational::zero());
    CHECK(summary.value().mu_one() == item.s1);
    CHECK(summary.value().mu_two() == item.s2);
    CHECK(summary.value().mu_tail_from_three() == item.c);
    REQUIRE(summary.value().exact_mean_backlog());
    CHECK(*summary.value().exact_mean_backlog() == oracle.mean);
    CHECK(summary.value().status() == solved.value().status());
    CHECK(summary.value().law_identity() == solved.value().identity());
    CHECK(summary.value().diagnostics().normalization_residual ==
          solved.value().diagnostics().normalization_residual);
    CHECK(summary.value().diagnostics().invariance_residual ==
          solved.value().diagnostics().invariance_residual);

    const auto bins = summary.value().bins();
    REQUIRE(bins.size() == 4U);
    const std::vector<ExactRational> bin_masses{
        oracle.pi0, oracle.pi1, oracle.pi2, oracle.tail};
    for (std::size_t bin = 0U; bin < bins.size(); ++bin) {
      const bool aggregate = bin == 3U && oracle.tail.is_positive();
      const bool positive = bin_masses[bin].is_positive();
      const auto expected_kind =
          aggregate
              ? mwperf::StationaryConditioningMassKindV1::aggregate_only
              : (positive
                     ? mwperf::StationaryConditioningMassKindV1::
                           established_positive
                     : mwperf::StationaryConditioningMassKindV1::
                           established_zero);
      CHECK(bins[bin].conditioning_mass.kind() == expected_kind);
      if (positive) {
        REQUIRE(bins[bin].conditioning_mass.mass());
        CHECK(*bins[bin].conditioning_mass.mass() == bin_masses[bin]);
      } else {
        CHECK_FALSE(bins[bin].conditioning_mass.mass().has_value());
      }
    }

    if (item.status == mwperf::AnalyticStationaryStatusV1::
                           finite_closed_tail_unreachable) {
      CHECK(summary.value().tail_slack_applicability() ==
            mwperf::TailSlackApplicabilityV1::not_applicable_off_class);
      CHECK_FALSE(summary.value().tail_slack().has_value());
    } else {
      ExactRational lambda = ExactRational::zero();
      for (std::size_t arrival_count = 0U;
           arrival_count < item.arrival.size(); ++arrival_count) {
        lambda =
            lambda + rational(static_cast<std::int64_t>(arrival_count)) *
                         item.arrival[arrival_count];
      }
      CHECK(summary.value().tail_slack_applicability() ==
            mwperf::TailSlackApplicabilityV1::applicable);
      REQUIRE(summary.value().tail_slack());
      CHECK(*summary.value().tail_slack() == item.c - lambda);
    }
  }
}

TEST_CASE("C19 phase relabeling conjugates SF.26 and its invariant law",
          "[c19][property][phase-permutation]") {
  auto original_flux = mwperf::testing::C19FixtureAccess::phase_flux(
      alternating_phase_fixture(false));
  auto permuted_flux = mwperf::testing::C19FixtureAccess::phase_flux(
      alternating_phase_fixture(true));
  REQUIRE(original_flux);
  REQUIRE(permuted_flux);
  REQUIRE(original_flux.value().phase_count() == 2U);
  REQUIRE(permuted_flux.value().phase_count() == 2U);

  for (std::uint64_t source_level = 0U; source_level <= 1U;
       ++source_level) {
    for (std::uint64_t destination_level = 0U; destination_level <= 1U;
         ++destination_level) {
      for (std::size_t source_phase = 0U; source_phase < 2U;
           ++source_phase) {
        for (std::size_t destination_phase = 0U; destination_phase < 2U;
             ++destination_phase) {
          auto original = original_flux.value().transition_probability(
              mwperf::BigNat{source_level}, source_phase,
              mwperf::BigNat{destination_level}, destination_phase);
          auto permuted = permuted_flux.value().transition_probability(
              mwperf::BigNat{source_level}, 1U - source_phase,
              mwperf::BigNat{destination_level}, 1U - destination_phase);
          REQUIRE(original);
          REQUIRE(permuted);
          CHECK(original.value() == permuted.value());
        }
      }
    }
  }

  const auto original_selection = stationary_unique_selection();
  const auto permuted_selection = stationary_unique_selection();
  const auto original_policy = stationary_policy("phase-original");
  const auto permuted_policy = stationary_policy("phase-permuted");
  auto original_law = mwperf::solve_markov_additive_stationary(
      original_flux.value(), original_selection, original_policy);
  auto permuted_law = mwperf::solve_markov_additive_stationary(
      permuted_flux.value(), permuted_selection, permuted_policy);
  INFO((original_law
            ? std::string{}
            : original_law.error().code + ": " +
                  original_law.error().message));
  INFO((permuted_law
            ? std::string{}
            : permuted_law.error().code + ": " +
                  permuted_law.error().message));
  REQUIRE(original_law);
  REQUIRE(permuted_law);

  long double original_mean = 0.0L;
  long double permuted_mean = 0.0L;
  for (std::uint64_t level = 0U; level <= 1U; ++level) {
    for (std::size_t phase_index = 0U; phase_index < 2U; ++phase_index) {
      auto original = original_law.value().mass(
          mwperf::BigNat{level}, phase_index);
      auto permuted = permuted_law.value().mass(
          mwperf::BigNat{level}, 1U - phase_index);
      REQUIRE(original);
      REQUIRE(permuted);
      CHECK(std::abs(original.value() - permuted.value()) <= 1.0e-14L);
      original_mean += static_cast<long double>(level) * original.value();
      permuted_mean += static_cast<long double>(level) * permuted.value();
    }
  }
  CHECK(std::abs(original_mean - 0.5L) <= 1.0e-14L);
  CHECK(std::abs(permuted_mean - original_mean) <= 1.0e-14L);
}

TEST_CASE("C19 declared fixed points repeat from identical cold inputs",
          "[c19][property][fixed-point][cold]") {
  const auto selection = fixed_point_unique_selection();
  const auto policy = fixed_point_policy("repeat", 64U);
  const auto contraction = [] {
    return mwperf::testing::ExactFixedPointFixtureV1{
        {ExactRational::zero()},
        {ExactRational::one()},
        {ExactRational::zero()},
        true,
        {},
        [](const std::span<const ExactRational> input) {
          return mwperf::Result<std::vector<ExactRational>>::success(
              {rational(1, 4) + input.front() * rational(1, 2)});
        }};
  };

  auto first = mwperf::testing::C19FixtureAccess::fixed_point_law(
      contraction(), selection, policy);
  REQUIRE(first);
  CHECK(first.value().termination() ==
        mwperf::FixedPointTerminationV1::converged);

  const auto unrelated_policy = fixed_point_policy("oscillation", 6U);
  auto unrelated = mwperf::testing::C19FixtureAccess::fixed_point_law(
      {{ExactRational::zero()},
       {ExactRational::one()},
       {ExactRational::zero()},
       true,
       {},
       [](const std::span<const ExactRational> input) {
         return mwperf::Result<std::vector<ExactRational>>::success(
             {ExactRational::one() - input.front()});
       }},
      selection, unrelated_policy);
  REQUIRE(unrelated);
  CHECK(unrelated.value().termination() ==
        mwperf::FixedPointTerminationV1::iteration_budget_exhausted);

  auto repeated = mwperf::testing::C19FixtureAccess::fixed_point_law(
      contraction(), selection, policy);
  REQUIRE(repeated);
  CHECK(repeated.value().termination() == first.value().termination());
  CHECK(repeated.value().iteration_count() == first.value().iteration_count());
  CHECK(repeated.value().evaluation_count() == first.value().evaluation_count());
  CHECK(repeated.value().iterate_difference() ==
        first.value().iterate_difference());
  CHECK(repeated.value().fixed_point_residual() ==
        first.value().fixed_point_residual());
  CHECK(repeated.value().selector_digest() == first.value().selector_digest());
  CHECK(repeated.value().identity() == first.value().identity());
  REQUIRE(repeated.value().parameters().size() ==
          first.value().parameters().size());
  for (std::size_t index = 0U; index < first.value().parameters().size();
       ++index) {
    CHECK(repeated.value().parameters()[index] ==
          first.value().parameters()[index]);
  }
}
