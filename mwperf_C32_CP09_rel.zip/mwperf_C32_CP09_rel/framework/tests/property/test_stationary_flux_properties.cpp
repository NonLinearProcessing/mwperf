#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/stationary/flux.hpp"

namespace {

using mwperf::C18ExactMatrixFixtureV1;
using mwperf::CompletionBoundMarkedAtomV1;
using mwperf::CompletionBoundMarkedRowV1;
using mwperf::ExactRational;
using mwperf::InvariantLaw;
using mwperf::MarkedFluxEdgeV1;
using mwperf::ReducedStateV1;
using mwperf::SelectionSpec;
using mwperf::SolverPolicy;
using mwperf::SourceLocation;
using mwperf::SourceNode;
using mwperf::StationaryMixtureComponent;
using mwperf::StationaryMixtureSelection;
using mwperf::StationaryUniqueSelection;
using mwperf::TransitionMatrix;

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator) {
  auto result = ExactRational::make(mwperf::BigInt{numerator},
                                    mwperf::BigInt{denominator});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto result =
      mwperf::sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SourceNode source(const std::string& pointer) {
  return SourceNode::make_null(
      SourceLocation{"c18-property", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] ReducedStateV1 state(const std::uint8_t ordinal) {
  return {{"c18.property.state", 1U},
          {std::byte{1U}, static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::TypedLabel class_id(const std::uint64_t ordinal) {
  return mwperf::TypedLabel::numeric(mwperf::BigNat{ordinal});
}

[[nodiscard]] SelectionSpec unique_selection() {
  return StationaryUniqueSelection{source("/selection/unique")};
}

[[nodiscard]] mwperf::AuthoredProbability probability(
    const ExactRational& weight) {
  auto result = mwperf::AuthoredProbability::from_exact(weight);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SelectionSpec mixture_selection(const ExactRational& first,
                                              const ExactRational& second) {
  std::vector<StationaryMixtureComponent> components;
  components.push_back(
      {class_id(0U), probability(first), source("/mixture/0")});
  components.push_back(
      {class_id(1U), probability(second), source("/mixture/1")});
  return StationaryMixtureSelection{std::move(components),
                                    source("/mixture")};
}

[[nodiscard]] SolverPolicy solver_policy(const std::string& identity) {
  return {mwperf::LinearMethod::dense_pivoted, std::nullopt,
          rational(1, 1000000000000000LL), ExactRational::zero(),
          digest("c18.property.policy." + identity)};
}

[[nodiscard]] MarkedFluxEdgeV1 edge(const ReducedStateV1& from,
                                    const ReducedStateV1& to,
                                    const std::uint64_t backlog,
                                    const std::uint8_t departure,
                                    const std::uint64_t arrival,
                                    const std::uint8_t phase_from,
                                    const std::uint8_t phase_to) {
  return {from,
          to,
          {mwperf::BigNat{backlog}},
          {departure},
          {mwperf::BigNat{arrival}},
          phase(phase_from),
          phase(phase_to),
          {}};
}

[[nodiscard]] C18ExactMatrixFixtureV1 fixture(
    std::vector<ReducedStateV1> states,
    std::vector<ExactRational> entries, SelectionSpec selection,
    SolverPolicy policy,
    std::optional<std::vector<CompletionBoundMarkedRowV1>> rows =
        std::nullopt) {
  auto marked = rows ? std::move(*rows)
                     : std::vector<CompletionBoundMarkedRowV1>{};
  std::vector<mwperf::ArrivalPhaseIdentityV1> state_phases;
  state_phases.reserve(states.size());
  for (std::size_t index = 0U; index < states.size(); ++index) {
    state_phases.push_back(phase(static_cast<std::uint8_t>(index)));
  }
  return {std::move(states),
          std::move(entries),
          std::move(selection),
          std::move(policy),
          std::nullopt,
          std::move(marked),
          mwperf::BoundaryCompletionKindV1::exact_closed,
          std::nullopt,
          true,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          digest("c18.property.exact-state-schema"),
          digest("c18.property.reduced-state-schema"),
          {},
          {},
          std::nullopt,
          std::move(state_phases)};
}

[[nodiscard]] TransitionMatrix matrix(C18ExactMatrixFixtureV1 input) {
  auto result = mwperf::testing::C18FixtureAccess::transition_matrix(
      std::move(input));
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] InvariantLaw solve(const TransitionMatrix& input,
                                 const SelectionSpec& selection,
                                 const SolverPolicy& policy) {
  auto selected = mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(input), selection);
  REQUIRE(selected);
  auto law = mwperf::solve_invariant_distribution(
      input, std::move(selected).value(), policy);
  INFO((law ? std::string{}
            : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] long double scalar(const mwperf::MetricValue& value) {
  auto decoded = mwperf::testing::C18FixtureAccess::decode_metric_scalar(value);
  REQUIRE(decoded);
  return decoded.value();
}

[[nodiscard]] mwperf::RewardDecoder departure_reward() {
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            REQUIRE(argument.edge != nullptr);
            REQUIRE(argument.edge->target_departures.size() == 1U);
            return mwperf::Result<long double>::success(
                static_cast<long double>(
                    argument.edge->target_departures.front()));
          },
          {"c18.property.scalar", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder arrival_minus_departure_reward() {
  return {mwperf::StationaryRewardDomainV1::one_edge,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            REQUIRE(argument.edge != nullptr);
            REQUIRE(argument.edge->target_departures.size() == 1U);
            REQUIRE(argument.edge->target_arrivals.size() == 1U);
            const auto arrival = static_cast<long double>(
                argument.edge->target_arrivals.front().value()
                    .convert_to<std::uint64_t>());
            const auto departure = static_cast<long double>(
                argument.edge->target_departures.front());
            return mwperf::Result<long double>::success(arrival - departure);
          },
          {"c18.property.scalar", 1U}};
}

[[nodiscard]] mwperf::RewardDecoder state_ordinal_reward() {
  return {mwperf::StationaryRewardDomainV1::state,
          mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
          false,
          {},
          [](const mwperf::StationaryRewardArgumentV1& argument) {
            REQUIRE_FALSE(argument.state.canonical_value.empty());
            return mwperf::Result<long double>::success(
                std::to_integer<unsigned int>(
                    argument.state.canonical_value.back()));
          },
          {"c18.property.scalar", 1U}};
}

void check_close(const long double actual, const long double expected,
                 const long double tolerance = 1.0e-13L) {
  CHECK(std::isfinite(actual));
  CHECK(std::abs(actual - expected) <= tolerance);
}

struct TwoStateRationalOracleV1 final {
  ExactRational a;
  ExactRational b;

  [[nodiscard]] std::vector<ExactRational> invariant_law() const {
    const ExactRational total = a + b;
    auto first = mwperf::checked_divide(b, total);
    auto second = mwperf::checked_divide(a, total);
    REQUIRE(first);
    REQUIRE(second);
    return {std::move(first).value(), std::move(second).value()};
  }
};

}  // namespace

TEST_CASE("C18 rational cases agree with an independent two-state oracle",
          "[c18][property]") {
  const std::vector<TwoStateRationalOracleV1> cases{
      {rational(1, 4), rational(1, 2)},
      {rational(1, 3), rational(2, 5)},
      {rational(2, 7), rational(3, 8)},
      {rational(3, 10), rational(1, 6)}};

  std::size_t case_index = 0U;
  for (const auto& oracle : cases) {
    CAPTURE(case_index);
    const auto selection = unique_selection();
    const auto policy = solver_policy("oracle-" + std::to_string(case_index));
    const std::vector<ExactRational> entries{
        ExactRational::one() - oracle.a, oracle.a, oracle.b,
        ExactRational::one() - oracle.b};
    const auto transition = matrix(
        fixture({state(0U), state(1U)}, entries, selection, policy));
    const auto classes = mwperf::analyze_communicating_classes(transition);
    REQUIRE(classes.classes().size() == 1U);
    REQUIRE(classes.closed_class_indices().size() == 1U);
    const auto law = solve(transition, selection, policy);
    const auto expected = oracle.invariant_law();
    REQUIRE(law.masses().size() == expected.size());
    check_close(law.masses()[0], expected[0].to_long_double());
    check_close(law.masses()[1], expected[1].to_long_double());
    CHECK(law.solve_diagnostics().normalization_residual <=
          law.solve_diagnostics().normalization_bound);
    CHECK(law.solve_diagnostics().l1_invariance_residual <=
          law.solve_diagnostics().l1_invariance_bound);
    ++case_index;
  }
}

TEST_CASE("C18 state permutation preserves the stationary equations",
          "[c18][property]") {
  const std::vector<ReducedStateV1> original_states{state(0U), state(1U),
                                                    state(2U)};
  const std::vector<ExactRational> original_entries{
      rational(1, 2), rational(1, 2), ExactRational::zero(),
      rational(1, 4), rational(1, 2), rational(1, 4),
      ExactRational::zero(), rational(1, 2), rational(1, 2)};
  const std::vector<std::size_t> permutation{2U, 0U, 1U};
  std::vector<ReducedStateV1> permuted_states;
  std::vector<ExactRational> permuted_entries;
  for (const auto old_row : permutation) {
    permuted_states.push_back(original_states[old_row]);
    for (const auto old_column : permutation) {
      permuted_entries.push_back(original_entries[old_row * 3U + old_column]);
    }
  }

  const auto original_selection = unique_selection();
  const auto original_policy = solver_policy("permutation-original");
  const auto original_matrix = matrix(fixture(
      original_states, original_entries, original_selection, original_policy));
  const auto original_law =
      solve(original_matrix, original_selection, original_policy);
  const auto original_classes =
      mwperf::analyze_communicating_classes(original_matrix);

  const auto permuted_selection = unique_selection();
  const auto permuted_policy = solver_policy("permutation-permuted");
  const auto permuted_matrix = matrix(fixture(
      permuted_states, permuted_entries, permuted_selection, permuted_policy));
  const auto permuted_law =
      solve(permuted_matrix, permuted_selection, permuted_policy);
  const auto permuted_classes =
      mwperf::analyze_communicating_classes(permuted_matrix);

  for (std::size_t original_index = 0U; original_index < 3U;
       ++original_index) {
    const auto found = std::find(permuted_matrix.states().begin(),
                                 permuted_matrix.states().end(),
                                 original_states[original_index]);
    REQUIRE(found != permuted_matrix.states().end());
    const auto permuted_index = static_cast<std::size_t>(
        std::distance(permuted_matrix.states().begin(), found));
    check_close(original_law.masses()[original_index],
                permuted_law.masses()[permuted_index]);
  }
  CHECK(original_law.selected_classes().front().exact_weight ==
        permuted_law.selected_classes().front().exact_weight);
  REQUIRE(original_classes.classes().size() ==
          permuted_classes.classes().size());
  CHECK(original_classes.classes().front().member_indices ==
        permuted_classes.classes().front().member_indices);
  CHECK(original_classes.classes().front().closed ==
        permuted_classes.classes().front().closed);
  CHECK(original_law.solve_diagnostics().class_solves.front().dimension ==
        permuted_law.solve_diagnostics().class_solves.front().dimension);
  CHECK(original_law.solve_diagnostics().class_solves.front().rank ==
        permuted_law.solve_diagnostics().class_solves.front().rank);
  CHECK(original_law.solve_diagnostics().normalization_residual ==
        permuted_law.solve_diagnostics().normalization_residual);
  CHECK(original_law.solve_diagnostics().l1_invariance_residual ==
        permuted_law.solve_diagnostics().l1_invariance_residual);
  const auto original_reward = mwperf::evaluate_stationary_edge_reward(
      original_law, state_ordinal_reward());
  const auto permuted_reward = mwperf::evaluate_stationary_edge_reward(
      permuted_law, state_ordinal_reward());
  REQUIRE(original_reward);
  REQUIRE(permuted_reward);
  check_close(scalar(original_reward.value()),
              scalar(permuted_reward.value()));
}

TEST_CASE("C18 splitting identical marked atoms preserves flux rewards",
          "[c18][property]") {
  const auto only = state(0U);
  auto merged_selection = unique_selection();
  const auto merged_policy = solver_policy("merged");
  std::vector<CompletionBoundMarkedRowV1> merged_rows(1U);
  merged_rows.front().atoms = {{
      0U, ExactRational::one(), 1.0L, false,
      edge(only, only, 1U, 1U, 1U, 0U, 0U)}};
  const auto merged_matrix = matrix(fixture(
      {only}, {ExactRational::one()}, merged_selection, merged_policy,
      std::move(merged_rows)));
  const auto merged_law =
      solve(merged_matrix, merged_selection, merged_policy);

  auto split_selection = unique_selection();
  const auto split_policy = solver_policy("split");
  std::vector<CompletionBoundMarkedRowV1> split_rows(1U);
  split_rows.front().atoms = {
      {0U, rational(1, 3), 1.0L / 3.0L, false,
       edge(only, only, 1U, 1U, 1U, 0U, 0U)},
      {0U, rational(2, 3), 2.0L / 3.0L, false,
       edge(only, only, 1U, 1U, 1U, 0U, 0U)}};
  const auto split_matrix = matrix(fixture(
      {only}, {ExactRational::one()}, split_selection, split_policy,
      std::move(split_rows)));
  const auto split_law = solve(split_matrix, split_selection, split_policy);

  CHECK(merged_matrix.exact_entry(0U, 0U) ==
        split_matrix.exact_entry(0U, 0U));
  const auto merged_reward = mwperf::evaluate_stationary_edge_reward(
      merged_law, departure_reward());
  const auto split_reward = mwperf::evaluate_stationary_edge_reward(
      split_law, departure_reward());
  REQUIRE(merged_reward);
  REQUIRE(split_reward);
  check_close(scalar(merged_reward.value()), scalar(split_reward.value()));
}

TEST_CASE("C18 endpoint rows and stationary marked flux retain unit mass",
          "[c18][property]") {
  const auto selection = unique_selection();
  const auto policy = solver_policy("mass-preservation");
  const auto zero = state(0U);
  const auto one = state(1U);
  const std::vector<ExactRational> entries{
      rational(2, 5), rational(3, 5), rational(1, 4), rational(3, 4)};
  std::vector<CompletionBoundMarkedRowV1> rows(2U);
  rows[0U].atoms = {
      {0U, rational(2, 5), 0.4L, false,
       edge(zero, zero, 0U, 0U, 0U, 0U, 0U)},
      {1U, rational(3, 5), 0.6L, false,
       edge(zero, one, 0U, 0U, 1U, 0U, 1U)}};
  rows[1U].atoms = {
      {0U, rational(1, 4), 0.25L, false,
       edge(one, zero, 1U, 1U, 0U, 1U, 0U)},
      {1U, rational(3, 4), 0.75L, false,
       edge(one, one, 1U, 0U, 0U, 1U, 1U)}};
  const auto transition = matrix(fixture(
      {zero, one}, entries, selection, policy, std::move(rows)));
  const auto law = solve(transition, selection, policy);

  for (std::size_t row = 0U; row < transition.size(); ++row) {
    ExactRational exact_row_mass = ExactRational::zero();
    ExactRational exact_marked_mass = ExactRational::zero();
    for (std::size_t column = 0U; column < transition.size(); ++column) {
      exact_row_mass = exact_row_mass + transition.exact_entry(row, column);
    }
    for (const auto& atom : transition.marked_flux().rows()[row].atoms) {
      exact_marked_mass = exact_marked_mass + atom.exact_mass;
    }
    CHECK(exact_row_mass == ExactRational::one());
    CHECK(exact_marked_mass == ExactRational::one());
  }

  long double stationary_flux_mass = 0.0L;
  for (std::size_t row = 0U; row < transition.size(); ++row) {
    for (const auto& atom : transition.marked_flux().rows()[row].atoms) {
      stationary_flux_mass += law.masses()[row] * atom.numerical_image;
    }
  }
  check_close(stationary_flux_mass, 1.0L);
}

TEST_CASE("C18 closed lossless marked flux telescopes queue increments",
          "[c18][property]") {
  const auto zero = state(0U);
  const auto one = state(1U);
  const auto selection = unique_selection();
  const auto policy = solver_policy("telescoping");
  const std::vector<ExactRational> entries{
      rational(1, 2), rational(1, 2), rational(1, 2), rational(1, 2)};
  std::vector<CompletionBoundMarkedRowV1> rows(2U);
  rows[0U].atoms = {
      {0U, rational(1, 2), 0.5L, false,
       edge(zero, zero, 0U, 0U, 0U, 0U, 0U)},
      {1U, rational(1, 2), 0.5L, false,
       edge(zero, one, 0U, 0U, 1U, 0U, 1U)}};
  rows[1U].atoms = {
      {0U, rational(1, 2), 0.5L, false,
       edge(one, zero, 1U, 1U, 0U, 1U, 0U)},
      {1U, rational(1, 2), 0.5L, false,
       edge(one, one, 1U, 1U, 1U, 1U, 1U)}};
  const auto transition = matrix(fixture(
      {zero, one}, entries, selection, policy, std::move(rows)));
  const auto law = solve(transition, selection, policy);
  const auto increment = mwperf::evaluate_stationary_edge_reward(
      law, arrival_minus_departure_reward());
  REQUIRE(increment);
  check_close(scalar(increment.value()), 0.0L);
}

TEST_CASE("C18 mixture normalization is invariant to positive scaling",
          "[c18][property]") {
  const std::vector<ExactRational> entries{
      ExactRational::one(), ExactRational::zero(),
      ExactRational::zero(), ExactRational::one()};
  const auto base_selection = mixture_selection(rational(1, 5), rational(2, 5));
  const auto base_policy = solver_policy("mixture-base");
  const auto base_matrix = matrix(
      fixture({state(0U), state(1U)}, entries, base_selection, base_policy));
  const auto base_law = solve(base_matrix, base_selection, base_policy);

  const auto scaled_selection =
      mixture_selection(rational(2, 5), rational(4, 5));
  const auto scaled_policy = solver_policy("mixture-scaled");
  const auto scaled_matrix = matrix(fixture(
      {state(0U), state(1U)}, entries, scaled_selection, scaled_policy));
  const auto scaled_law =
      solve(scaled_matrix, scaled_selection, scaled_policy);

  REQUIRE(base_law.masses().size() == 2U);
  REQUIRE(scaled_law.masses().size() == 2U);
  check_close(base_law.masses()[0], 1.0L / 3.0L);
  check_close(base_law.masses()[1], 2.0L / 3.0L);
  check_close(base_law.masses()[0], scaled_law.masses()[0]);
  check_close(base_law.masses()[1], scaled_law.masses()[1]);

  SECTION("negative authored weight is rejected at the typed boundary") {
    CHECK_FALSE(mwperf::AuthoredProbability::from_exact(rational(-1, 2)));
  }
}
