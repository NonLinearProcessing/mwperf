#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/temporal.hpp"

namespace {

using mwperf::AbsorptionMarks;
using mwperf::AnyEdgePredicateV1;
using mwperf::AuditedTemporalSourceKindV1;
using mwperf::BacklogRelationV1;
using mwperf::BigNat;
using mwperf::BinaryMark;
using mwperf::BinaryMarkKindV1;
using mwperf::CylinderEvent;
using mwperf::EdgeMarkAtV1;
using mwperf::ExactRational;
using mwperf::ExactStatePredicateV1;
using mwperf::HorizonSpec;
using mwperf::InitialLawKindV1;
using mwperf::LagSpec;
using mwperf::MarkedFluxEdgeV1;
using mwperf::ReducedStateV1;
using mwperf::SafeSet;
using mwperf::SolverPolicy;
using mwperf::StateAtV1;
using mwperf::TargetBacklogPredicateV1;
using mwperf::TargetDeparturePredicateV1;
using mwperf::TemporalStatisticKindV1;
using mwperf::TypedAbsorptionMarkV1;
using mwperf::testing::C22FixtureAccess;
using mwperf::testing::C22MetricEnvelopeInspectionV1;
using mwperf::testing::C22SyntheticEntranceV1;
using mwperf::testing::C22SyntheticF05AuthorizationV1;
using mwperf::testing::C22SyntheticNodeV1;
using mwperf::testing::C22SyntheticSourceIdentityV1;
using mwperf::testing::C22SyntheticTransitionV1;
using mwperf::testing::C22SyntheticViewsV1;

[[nodiscard]] ExactRational rational(const std::int64_t numerator,
                                     const std::int64_t denominator = 1) {
  auto value = ExactRational::make(mwperf::BigInt{numerator},
                                   mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string& text) {
  auto value =
      mwperf::sha256(std::as_bytes(std::span(text.data(), text.size())));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] C22SyntheticSourceIdentityV1 identity(
    const std::string& name, const bool projection_bound = false) {
  return {
      digest(name + ".source"),
      projection_bound
          ? std::optional<mwperf::Digest256>{digest(name + ".projection")}
          : std::nullopt,
      digest(name + ".contract"),
      digest(name + ".requirements"),
      digest(name + ".analysis"),
      digest(name + ".instance"),
      digest(name + ".targets"),
      digest(name + ".arrivals"),
      digest(name + ".selection"),
      digest(name + ".exact-state"),
      digest(name + ".reduced-state"),
      digest(name + ".marks"),
      digest(name + ".continuation"),
      digest(name + ".target-service"),
      digest(name + ".timing"),
      {"mwperf.c22.property.state", 1U},
  };
}

[[nodiscard]] ReducedStateV1 state(const std::uint8_t ordinal) {
  return {{"mwperf.c22.property.state", 1U},
          {std::byte{0x22U}, static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] MarkedFluxEdgeV1 edge(const ReducedStateV1& from,
                                    const ReducedStateV1& to,
                                    const std::uint64_t backlog,
                                    const bool departure,
                                    const std::uint64_t arrival,
                                    const std::uint8_t phase_from,
                                    const std::uint8_t phase_to) {
  return {from,
          to,
          {BigNat{backlog}},
          {static_cast<std::uint8_t>(departure ? 1U : 0U)},
          {BigNat{arrival}},
          phase(phase_from),
          phase(phase_to),
          {}};
}

[[nodiscard]] SolverPolicy policy(const std::string& name) {
  return {mwperf::LinearMethod::dense_pivoted, BigNat{256U},
          rational(1, 1000000000000LL), ExactRational::zero(),
          digest(name + ".analysis")};
}

[[nodiscard]] C22SyntheticViewsV1 mint_stationary(
    const std::string& name, std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    const std::size_t maximum_offset = 16U,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations = {}) {
  auto views = C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::stationary, identity(name, true), std::move(nodes),
      std::move(entrance), maximum_offset, maximum_offset,
      std::move(f05_authorizations));
  INFO((views ? std::string{}
              : views.error().code + ": " + views.error().message));
  REQUIRE(views);
  return std::move(views).value();
}

template <typename T>
[[nodiscard]] const T& require_optional(const std::optional<T>& value) {
  REQUIRE(value.has_value());
  return *value;
}

[[nodiscard]] C22SyntheticViewsV1 mint_transient(
    const std::string& name, std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    const std::size_t maximum_offset = 32U) {
  auto views = C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::transient_dispatch,
      InitialLawKindV1::transient, identity(name), std::move(nodes),
      std::move(entrance), maximum_offset, maximum_offset);
  INFO((views ? std::string{}
              : views.error().code + ": " + views.error().message));
  REQUIRE(views);
  return std::move(views).value();
}

[[nodiscard]] C22MetricEnvelopeInspectionV1 decode(
    const mwperf::MetricValue& value) {
  auto decoded = C22FixtureAccess::decode_metric_value(value);
  INFO((decoded ? std::string{}
                : decoded.error().code + ": " + decoded.error().message));
  REQUIRE(decoded);
  return std::move(decoded).value();
}

[[nodiscard]] std::vector<C22SyntheticNodeV1> marked_two_state_nodes() {
  const ReducedStateV1 zero = state(0U);
  const ReducedStateV1 one = state(1U);
  return {
      {zero,
       {{0U, edge(zero, zero, 1U, false, 0U, 0U, 0U), rational(1, 2)},
        {1U, edge(zero, one, 1U, true, 1U, 0U, 1U), rational(1, 2)}},
       0U},
      {one,
       {{0U, edge(one, zero, 1U, true, 1U, 1U, 0U), rational(1, 3)},
        {1U, edge(one, one, 1U, false, 0U, 1U, 1U), rational(2, 3)}},
       0U},
  };
}

struct OracleTransition final {
  std::size_t successor;
  bool departure;
  ExactRational mass;
};

using OracleRows = std::vector<std::vector<OracleTransition>>;

void enumerate_ordered_words(const OracleRows& rows,
                             const std::size_t state_index,
                             const std::size_t completed,
                             const std::size_t width,
                             const std::size_t departure_count,
                             const ExactRational& path_mass,
                             std::vector<ExactRational>& pmf) {
  if (completed == width) {
    pmf[departure_count] = pmf[departure_count] + path_mass;
    return;
  }
  for (const auto& transition : rows[state_index]) {
    enumerate_ordered_words(
        rows, transition.successor, completed + 1U, width,
        departure_count + (transition.departure ? 1U : 0U),
        path_mass * transition.mass, pmf);
  }
}

[[nodiscard]] std::vector<ExactRational> exhaustive_window_pmf(
    const std::size_t width) {
  const OracleRows rows{
      {{0U, false, rational(1, 2)}, {1U, true, rational(1, 2)}},
      {{0U, true, rational(1, 3)}, {1U, false, rational(2, 3)}},
  };
  const std::vector<ExactRational> entrance{rational(2, 5), rational(3, 5)};
  std::vector<ExactRational> pmf(width + 1U, ExactRational::zero());
  for (std::size_t initial = 0U; initial < entrance.size(); ++initial) {
    enumerate_ordered_words(rows, initial, 0U, width, 0U,
                            entrance[initial], pmf);
  }
  return pmf;
}

[[nodiscard]] SafeSet positive_backlog_safe_set() {
  return {TargetBacklogPredicateV1{0U, BacklogRelationV1::at_or_above,
                                   BigNat{1U}}};
}

[[nodiscard]] ExactRational absorption_at(
    const mwperf::StoppedMetricBundle& bundle, const BigNat& time) {
  ExactRational total = ExactRational::zero();
  for (const auto& atom : bundle.absorption_masses) {
    if (atom.hitting_time == time) {
      CHECK(atom.exact_probability.is_nonnegative());
      total = total + atom.exact_probability;
    }
  }
  return total;
}

TEST_CASE("C22 finite cylinders are projectively consistent under exact marginalization",
          "[c22][property][cylinder]") {
  auto views = mint_stationary(
      "c22.property.projectivity", marked_two_state_nodes(),
      {{0U, rational(2, 5)}, {1U, rational(3, 5)}});
  REQUIRE(views.cylinder.has_value());

  CylinderEvent prefix{{
      EdgeMarkAtV1{BigNat{0U}, TargetDeparturePredicateV1{0U, true}},
      StateAtV1{BigNat{2U}, ExactStatePredicateV1{state(0U)}},
  }};
  auto prefix_result = mwperf::evaluate_finite_cylinder(
      *views.cylinder, prefix, BigNat{2U});
  REQUIRE(prefix_result);
  const auto prefix_value = decode(prefix_result.value());
  REQUIRE(prefix_value.exact_values.size() == 1U);
  CHECK(prefix_value.completed_steps == 2U);

  ExactRational marginalized = ExactRational::zero();
  for (const std::uint8_t terminal : {std::uint8_t{0U},
                                      std::uint8_t{1U}}) {
    CylinderEvent extension = prefix;
    extension.observations.push_back(
        StateAtV1{BigNat{3U}, ExactStatePredicateV1{state(terminal)}});
    auto result = mwperf::evaluate_finite_cylinder(
        *views.cylinder, extension, BigNat{3U});
    REQUIRE(result);
    const auto decoded = decode(result.value());
    REQUIRE(decoded.exact_values.size() == 1U);
    CHECK(decoded.completed_steps == 3U);
    marginalized = marginalized + decoded.exact_values.front();
  }
  CHECK(marginalized == prefix_value.exact_values.front());
}

TEST_CASE("C22 exact stopped recursions conserve mass and have nonincreasing tails",
          "[c22][property][stopped]") {
  // A fixed seed makes the generated exact kernels reproducible while
  // exercising substantially more row shapes than a hand-picked grid.
  std::uint32_t generator = 0x22c0ffeeU;
  for (std::size_t fixture = 0U; fixture < 32U; ++fixture) {
      const std::string source_name =
          "c22.property.survival." + std::to_string(fixture);
      generator = generator * 1664525U + 1013904223U;
      const ExactRational p =
          rational(static_cast<std::int64_t>(generator % 31U + 1U), 32);
      generator = generator * 1664525U + 1013904223U;
      const ExactRational q =
          rational(static_cast<std::int64_t>(generator % 31U + 1U), 32);
      const ReducedStateV1 zero = state(0U);
      const ReducedStateV1 one = state(1U);
      const ReducedStateV1 absorbed = state(2U);
      std::vector<C22SyntheticNodeV1> nodes{
          {zero,
           {{1U, edge(zero, one, 1U, false, 0U, 0U, 1U), p},
            {2U, edge(zero, absorbed, 1U, true, 0U, 0U, 2U),
             ExactRational::one() - p}},
           std::nullopt},
          {one,
           {{0U, edge(one, zero, 1U, false, 0U, 1U, 0U), q},
            {2U, edge(one, absorbed, 1U, true, 0U, 1U, 2U),
             ExactRational::one() - q}},
           std::nullopt},
          {absorbed,
           {{2U, edge(absorbed, absorbed, 0U, false, 0U, 2U, 2U),
             ExactRational::one()}},
           std::nullopt},
      };
      auto views = mint_transient(source_name, std::move(nodes),
                                  {{0U, ExactRational::one()}});
      REQUIRE(views.kernel.has_value());
      auto killed = mwperf::construct_killed_kernel(
          *views.kernel, positive_backlog_safe_set(),
          AbsorptionMarks{{TypedAbsorptionMarkV1{
              "exit", ExactStatePredicateV1{absorbed},
              AnyEdgePredicateV1{}}}});
      REQUIRE(killed);
      REQUIRE(killed.value().row_diagnostics().size() == 2U);
      for (const auto& row : killed.value().row_diagnostics()) {
        ExactRational classified = row.exact_survivor_mass;
        for (const auto& exit : row.exact_typed_exit_masses) {
          classified = classified + exit;
        }
        CHECK(row.exact_source_mass == ExactRational::one());
        CHECK(classified == row.exact_source_mass);
        CHECK(row.exact_balance_residual.is_zero());
        CHECK(row.source_error_lower.is_zero());
        CHECK(row.source_error_upper.is_zero());
      }

      auto stopped = mwperf::evaluate_hit_survival_absorption(
          killed.value(), require_optional(views.entrance),
          HorizonSpec{BigNat{8U}, false, true},
          policy(source_name));
      REQUIRE(stopped);
      const auto& bundle = stopped.value();
      REQUIRE(bundle.survival_tails.size() == 9U);
      CHECK(bundle.survival_tails.front().exact_probability ==
            ExactRational::one());

      ExactRational cumulative = ExactRational::zero();
      for (std::size_t index = 1U;
           index < bundle.survival_tails.size(); ++index) {
        const auto& previous = bundle.survival_tails[index - 1U];
        const auto& current = bundle.survival_tails[index];
        const ExactRational step_absorption =
            absorption_at(bundle, current.index);
        CHECK(current.exact_probability.is_nonnegative());
        CHECK(current.exact_probability <= previous.exact_probability);
        CHECK(previous.exact_probability - current.exact_probability ==
              step_absorption);
        cumulative = cumulative + step_absorption;
        CHECK(cumulative + current.exact_probability ==
              ExactRational::one());
      }
  }
}

TEST_CASE("C22 ordered service-window coefficients equal exhaustive word enumeration",
          "[c22][property][service-window]") {
  std::vector<C22SyntheticF05AuthorizationV1> authorizations;
  for (std::size_t width = 1U; width <= 6U; ++width) {
    authorizations.push_back(
        {mwperf::MetricKindV1::service_window_count, 0U,
         mwperf::ServiceWindowCountParametersV1{BigNat{width}}});
  }
  auto views = mint_stationary(
      "c22.property.ordered-window", marked_two_state_nodes(),
      {{0U, rational(2, 5)}, {1U, rational(3, 5)}}, 16U,
      std::move(authorizations));
  REQUIRE(views.law.has_value());
  const BinaryMark departure{BinaryMarkKindV1::target_departure, 0U,
                             std::nullopt};

  for (std::size_t width = 1U; width <= 6U; ++width) {
    const LagSpec request{TemporalStatisticKindV1::service_window_count,
                          {}, BigNat{width}, std::nullopt, {}};
    auto result = mwperf::evaluate_runs_gaps_autocorrelation(
        *views.law, departure, request);
    REQUIRE(result);
    const auto decoded = decode(result.value());
    CAPTURE(width);
    CHECK(decoded.kind == "service_window_count");
    CHECK(decoded.completed_steps == width);
    CHECK(decoded.exact_values == exhaustive_window_pmf(width));
    REQUIRE(decoded.indices.size() == width + 1U);
    for (std::size_t count = 0U; count <= width; ++count) {
      CHECK(decoded.indices[count] == BigNat{count});
    }
  }
}

TEST_CASE("C22 zero-start hitting iteration is monotone and selects the minimal branch",
          "[c22][property][hitting]") {
  const std::vector<ExactRational> probabilities{
      rational(1, 4), rational(1, 2), rational(3, 4)};
  std::size_t fixture = 0U;
  for (const auto& p : probabilities) {
    for (const auto& r : probabilities) {
      const std::string source_name =
          "c22.property.hitting." + std::to_string(fixture++);
      const ReducedStateV1 zero = state(0U);
      const ReducedStateV1 one = state(1U);
      const ReducedStateV1 hit = state(2U);
      const ReducedStateV1 kill = state(3U);
      std::vector<C22SyntheticNodeV1> nodes{
          {zero,
           {{1U, edge(zero, one, 1U, false, 0U, 0U, 1U), p},
            {3U, edge(zero, kill, 1U, false, 0U, 0U, 3U),
             ExactRational::one() - p}},
           std::nullopt},
          {one,
           {{2U, edge(one, hit, 1U, true, 0U, 1U, 2U), r},
            {3U, edge(one, kill, 1U, false, 0U, 1U, 3U),
             ExactRational::one() - r}},
           std::nullopt},
          {hit,
           {{2U, edge(hit, hit, 0U, false, 0U, 2U, 2U),
             ExactRational::one()}},
           std::nullopt},
          {kill,
           {{3U, edge(kill, kill, 0U, false, 0U, 3U, 3U),
             ExactRational::one()}},
           std::nullopt},
      };
      auto views = mint_transient(source_name, std::move(nodes),
                                  {{0U, ExactRational::one()}});
      REQUIRE(views.kernel.has_value());
      auto killed = mwperf::construct_killed_kernel(
          *views.kernel, positive_backlog_safe_set(),
          AbsorptionMarks{{
              TypedAbsorptionMarkV1{"hit", ExactStatePredicateV1{hit},
                                      AnyEdgePredicateV1{}},
              TypedAbsorptionMarkV1{"kill", ExactStatePredicateV1{kill},
                                      AnyEdgePredicateV1{}},
          }});
      REQUIRE(killed);
      auto stopped = mwperf::evaluate_hit_survival_absorption(
          killed.value(), require_optional(views.entrance),
          HorizonSpec{BigNat{3U}, false, true},
          policy(source_name));
      REQUIRE(stopped);

      std::vector<ExactRational> iterate(2U, ExactRational::zero());
      for (std::size_t iteration = 0U; iteration < 3U; ++iteration) {
        const std::vector<ExactRational> next{
            p * iterate[1U],
            r,
        };
        for (std::size_t coordinate = 0U; coordinate < next.size();
             ++coordinate) {
          CHECK(next[coordinate] >= iterate[coordinate]);
          CHECK(next[coordinate].is_nonnegative());
          CHECK(next[coordinate] <= ExactRational::one());
        }
        iterate = next;
      }
      CHECK(iterate[0U] == p * r);

      const auto found = std::find_if(
          stopped.value().eventual_typed_exit_probabilities.begin(),
          stopped.value().eventual_typed_exit_probabilities.end(),
          [](const auto& value) { return value.type_id == "hit"; });
      REQUIRE(found !=
              stopped.value().eventual_typed_exit_probabilities.end());
      CHECK(found->exact_probability == iterate[0U]);
      CHECK(stopped.value().exact_defect_probability ==
            ExactRational::zero());
    }
  }

  {
    INFO("a closed safe class keeps the singular minimal solution at zero");
    const ReducedStateV1 safe = state(0U);
    const ReducedStateV1 hit = state(2U);
    std::vector<C22SyntheticNodeV1> nodes{
        {safe,
         {{0U, edge(safe, safe, 1U, false, 0U, 0U, 0U),
           ExactRational::one()}},
         std::nullopt},
        {hit,
         {{1U, edge(hit, hit, 0U, false, 0U, 2U, 2U),
           ExactRational::one()}},
         std::nullopt},
    };
    auto views = mint_transient("c22.property.singular-minimal",
                                std::move(nodes),
                                {{0U, ExactRational::one()}});
    REQUIRE(views.kernel.has_value());
    auto killed = mwperf::construct_killed_kernel(
        *views.kernel, positive_backlog_safe_set(),
        AbsorptionMarks{{TypedAbsorptionMarkV1{
            "hit", ExactStatePredicateV1{hit}, AnyEdgePredicateV1{}}}});
    REQUIRE(killed);
    auto stopped = mwperf::evaluate_hit_survival_absorption(
        killed.value(), require_optional(views.entrance),
        HorizonSpec{BigNat{4U}, false, true},
        policy("c22.property.singular-minimal"));
    REQUIRE(stopped);
    REQUIRE(stopped.value().eventual_typed_exit_probabilities.size() == 1U);
    CHECK(stopped.value().eventual_typed_exit_probabilities.front()
              .exact_probability == ExactRational::zero());
    CHECK(stopped.value().exact_defect_probability == ExactRational::one());
  }
}

TEST_CASE("C22 busy-denial spells end exactly at the first actual departure",
          "[c22][property][busy-denial]") {
  {
    INFO("the audited temporal law reports the pathwise spell length");
    const ReducedStateV1 zero = state(0U);
    const ReducedStateV1 one = state(1U);
    const ReducedStateV1 two = state(2U);
    const ReducedStateV1 three = state(3U);
    std::vector<C22SyntheticNodeV1> nodes{
        {zero,
         {{1U, edge(zero, one, 1U, false, 0U, 0U, 1U),
           ExactRational::one()}},
         0U},
        {one,
         {{2U, edge(one, two, 1U, false, 1U, 1U, 2U),
           ExactRational::one()}},
         0U},
        {two,
         {{3U, edge(two, three, 2U, true, 0U, 2U, 3U),
           ExactRational::one()}},
         0U},
        {three,
         {{0U, edge(three, zero, 1U, true, 1U, 3U, 0U),
           ExactRational::one()}},
         0U},
    };
    auto views = mint_stationary(
        "c22.property.busy-denial-cycle", std::move(nodes),
        {{0U, rational(1, 4)}, {1U, rational(1, 4)},
         {2U, rational(1, 4)}, {3U, rational(1, 4)}},
        16U,
        {{mwperf::MetricKindV1::mean_binary_run, 0U,
          mwperf::MeanBinaryRunParametersV1{
              mwperf::BasicBinaryPredicateV1::busy_denial}}});
    REQUIRE(views.law.has_value());
    const BinaryMark denial{BinaryMarkKindV1::busy_denial, 0U,
                            std::nullopt};

    auto mean_run = mwperf::evaluate_runs_gaps_autocorrelation(
        *views.law, denial,
        LagSpec{TemporalStatisticKindV1::mean_binary_run, {}, std::nullopt,
                std::nullopt, {}});
    REQUIRE(mean_run);
    const auto mean_result = decode(mean_run.value());
    REQUIRE(mean_result.exact_values.size() == 1U);
    CHECK(mean_result.exact_values.front() == rational(2));
  }

  constexpr std::size_t horizon = 7U;
  for (std::size_t first_departure = 1U;
       first_departure < horizon; ++first_departure) {
    for (std::uint32_t arrival_word = 0U;
         arrival_word < (1U << horizon); ++arrival_word) {
      std::uint64_t backlog = 1U;
      std::size_t denial_length = 0U;
      for (std::size_t slot = 0U; slot < horizon; ++slot) {
        const bool departure = slot == first_departure;
        const bool busy_denial = backlog != 0U && !departure;
        if (slot < first_departure) {
          CHECK(busy_denial);
          ++denial_length;
        } else if (slot == first_departure) {
          CHECK_FALSE(busy_denial);
        }
        const std::uint64_t arrival =
            (arrival_word & (1U << slot)) == 0U ? 0U : 1U;
        backlog = backlog - (departure ? 1U : 0U) + arrival;
      }
      CHECK(denial_length == first_departure);
    }
  }

  {
    INFO("no future removal gives an infinite denial spell and a defective "
         "C22 departure stop");
    const ReducedStateV1 only = state(0U);
    auto views = mint_transient(
        "c22.property.busy-denial-infinite",
        {{only,
          {{0U, edge(only, only, 1U, false, 0U, 0U, 0U),
            ExactRational::one()}},
          0U}},
        {{0U, ExactRational::one()}});
    REQUIRE(views.kernel.has_value());
    const auto killed = mwperf::construct_killed_kernel(
        *views.kernel,
        SafeSet{mwperf::AnyStatePredicateV1{}},
        AbsorptionMarks{{TypedAbsorptionMarkV1{
            "departure", mwperf::AnyStatePredicateV1{},
            TargetDeparturePredicateV1{0U, true}}}});
    REQUIRE(killed);
    const auto stopped = mwperf::evaluate_hit_survival_absorption(
        killed.value(), require_optional(views.entrance),
        HorizonSpec{BigNat{4U}, true, true},
        policy("c22.property.busy-denial-infinite"));
    REQUIRE(stopped);
    REQUIRE(stopped.value().survival_tails.size() == 5U);
    for (const auto& tail : stopped.value().survival_tails) {
      CHECK(tail.exact_probability == ExactRational::one());
    }
    CHECK(stopped.value().absorption_status ==
          mwperf::AbsorptionStatusV1::defective);
    CHECK(stopped.value().exact_defect_probability ==
          ExactRational::one());
    CHECK(stopped.value().mean_stopping_time.status ==
          mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
    REQUIRE(stopped.value().eventual_typed_exit_probabilities.size() == 1U);
    CHECK(stopped.value().eventual_typed_exit_probabilities.front()
              .exact_probability.is_zero());

    std::uint64_t backlog = 1U;
    constexpr std::size_t arbitrary_prefix = 256U;
    for (std::size_t slot = 0U; slot < arbitrary_prefix; ++slot) {
      const bool departure = false;
      const bool busy_denial = backlog != 0U && !departure;
      REQUIRE(busy_denial);
    }
    CHECK(backlog != 0U);
    const std::optional<std::size_t> first_future_departure = std::nullopt;
    CHECK_FALSE(first_future_departure.has_value());
  }
}

}  // namespace
