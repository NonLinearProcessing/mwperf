#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "c22/support/temporal_metrics_fixture.hpp"
#include "mwperf/metrics/palm_fifo.hpp"

namespace {

using ServiceState = mwperf::testing::C23SyntheticServiceStateV1;
using ServiceTransition =
    mwperf::testing::C23SyntheticServiceTransitionV1;
using Entrance = mwperf::testing::C23SyntheticPolynomialEntranceV1;

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator =
                                                 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

template <typename T>
[[nodiscard]] T require_value(mwperf::Result<T> result) {
  INFO((result ? std::string{}
               : result.error().code + ": " + result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational divide(
    const mwperf::ExactRational& numerator,
    const mwperf::ExactRational& denominator) {
  return require_value(mwperf::checked_divide(numerator, denominator));
}

struct OraclePath final {
  std::size_t state_index;
  std::size_t departures;
  std::size_t maximum_surviving_departures;
  mwperf::ExactRational exact_mass;
};

[[nodiscard]] std::vector<mwperf::ExactRational> exhaustive_tails(
    const std::vector<ServiceState>& states,
    const std::vector<Entrance>& entrance,
    const std::size_t maximum_tail_index) {
  std::vector<OraclePath> frontier;
  frontier.reserve(entrance.size());
  for (const auto& atom : entrance) {
    frontier.push_back(
        {atom.state_index, 0U, atom.predecessors, atom.exact_mass});
  }

  std::vector<mwperf::ExactRational> tails;
  tails.reserve(maximum_tail_index + 1U);
  for (std::size_t completed = 0U; completed <= maximum_tail_index;
       ++completed) {
    mwperf::ExactRational survival = mwperf::ExactRational::zero();
    for (const auto& path : frontier) {
      if (path.departures <= path.maximum_surviving_departures) {
        survival = survival + path.exact_mass;
      }
    }
    tails.push_back(std::move(survival));
    if (completed == maximum_tail_index) {
      break;
    }

    std::vector<OraclePath> next;
    for (const auto& path : frontier) {
      REQUIRE(path.state_index < states.size());
      for (const auto& transition : states[path.state_index].transitions) {
        next.push_back(
            {transition.successor_index,
             path.departures +
                 (transition.departure == 0U ? 0U : 1U),
             path.maximum_surviving_departures,
             path.exact_mass * transition.exact_mass});
      }
    }
    frontier = std::move(next);
  }
  return tails;
}

[[nodiscard]] std::vector<ServiceState> two_state_service(
    const mwperf::ExactRational& state_zero_denial,
    const mwperf::ExactRational& state_one_denial) {
  return {
      ServiceState{{
          ServiceTransition{1U, 0U, state_zero_denial},
          ServiceTransition{0U, 1U,
                            mwperf::ExactRational::one() -
                                state_zero_denial},
      }},
      ServiceState{{
          ServiceTransition{0U, 0U, state_one_denial},
          ServiceTransition{1U, 1U,
                            mwperf::ExactRational::one() -
                                state_one_denial},
      }},
  };
}

inline const mwperf::CodecIdentityV1 kSyntheticTagMarkCodec{
    "mwperf.c23.boolean_tag_departure", 1U};

[[nodiscard]] mwperf::RuntimeMarkIdV1 synthetic_tag_mark_id() {
  return mwperf::testing::c22::runtime_mark_id(
      "mwperf.c23.tagged_packet_departure");
}

[[nodiscard]] mwperf::testing::C22SyntheticTransitionV1 tagged_transition(
    const std::size_t successor, const mwperf::ReducedStateV1& before,
    const mwperf::ReducedStateV1& after, const std::uint64_t backlog,
    const bool physical_departure, const bool tag_departure,
    const mwperf::ExactRational& mass) {
  auto result = mwperf::testing::c22::transition(
      successor, before, after, backlog,
      static_cast<std::uint8_t>(physical_departure ? 1U : 0U), mass);
  result.edge.marks.push_back(mwperf::testing::c22::runtime_mark(
      synthetic_tag_mark_id(), kSyntheticTagMarkCodec,
      {tag_departure ? std::byte{0x01} : std::byte{0x00}}));
  return result;
}

[[nodiscard]] mwperf::StoppedMetricBundle evaluate_synthetic_tag_stop(
    const std::string_view name,
    std::vector<mwperf::testing::C22SyntheticNodeV1> nodes,
    std::vector<mwperf::testing::C22SyntheticEntranceV1> entrance,
    const std::size_t horizon) {
  using namespace mwperf;
  auto views = require_value(testing::C22FixtureAccess::mint_exact_source(
      AuditedTemporalSourceKindV1::passive_fifo_tag,
      InitialLawKindV1::fifo_tag,
      testing::c22::identity(name, true), std::move(nodes),
      std::move(entrance), 32U, 32U));
  REQUIRE(views.kernel.has_value());
  REQUIRE(views.entrance.has_value());
  const auto killed = require_value(construct_killed_kernel(
      *views.kernel, SafeSet{AnyStatePredicateV1{}},
      AbsorptionMarks{{TypedAbsorptionMarkV1{
          "tagged_packet_departure", AnyStatePredicateV1{},
          ExactRuntimeMarkPredicateV1{
              synthetic_tag_mark_id(), kSyntheticTagMarkCodec,
              {std::byte{0x01}}}}}}));
  return require_value(evaluate_hit_survival_absorption(
      killed, *views.entrance,
      HorizonSpec{BigNat{horizon}, true, true},
      testing::c22::solver_policy(name)));
}

}  // namespace

TEST_CASE("C23 chronological departure polynomial matches a noncommuting oracle",
          "[c23][property][fifo][polynomial]") {
  const auto states = two_state_service(rational(1, 2), rational(1, 4));
  const std::vector<Entrance> entrance{{0U, 1U,
                                        mwperf::ExactRational::one()}};

  const auto tails = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, entrance, 5U));
  const std::vector<mwperf::ExactRational> expected{
      rational(1), rational(1), rational(3, 4), rational(9, 32),
      rational(11, 64), rational(7, 128)};
  CHECK(tails == expected);
  CHECK(tails == exhaustive_tails(states, entrance, 5U));

  // P0 P1 and P1 P0 differ for this fixture.  This explicitly rules out a
  // binomial/commuting shortcut in the coefficient implementation.
  const auto p0_p1_zero_one = rational(1, 2) * rational(3, 4);
  const auto p1_p0_zero_one = rational(1, 2) * rational(1, 2);
  const auto p0_p1_one_zero = rational(1, 4) * rational(1, 2);
  const auto p1_p0_one_zero = rational(3, 4) * rational(1, 4);
  CHECK(p0_p1_zero_one == rational(3, 8));
  CHECK(p1_p0_zero_one == rational(1, 4));
  CHECK(p0_p1_one_zero == rational(1, 8));
  CHECK(p1_p0_one_zero == rational(3, 16));
  CHECK(p0_p1_zero_one != p1_p0_zero_one);
  CHECK(p0_p1_one_zero != p1_p0_one_zero);
}

TEST_CASE("C23 degree truncation equals exhaustive departure-word enumeration",
          "[c23][property][fifo][polynomial]") {
  const std::vector<mwperf::ExactRational> probabilities{
      rational(1, 4), rational(1, 2), rational(3, 4)};

  for (const auto& p : probabilities) {
    for (const auto& q : probabilities) {
      const auto states = two_state_service(p, q);
      for (std::size_t rank = 0U; rank <= 3U; ++rank) {
        CAPTURE(p.to_canonical_string(), q.to_canonical_string(), rank);
        const std::vector<Entrance> entrance{{
            0U, rank, mwperf::ExactRational::one()}};
        const auto actual = require_value(
            mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
                states, entrance, 6U));
        const auto expected = exhaustive_tails(states, entrance, 6U);
        CHECK(actual == expected);
        REQUIRE(actual.size() == 7U);
        CHECK(actual.front() == mwperf::ExactRational::one());
        for (std::size_t index = 1U; index < actual.size(); ++index) {
          CHECK(actual[index].is_nonnegative());
          CHECK(actual[index] <= actual[index - 1U]);
          const auto mass = actual[index - 1U] - actual[index];
          CHECK(mass.is_nonnegative());
        }
      }
    }
  }
}

TEST_CASE("C23 passive-tag projection preserves every randomized untagged row",
          "[c23][property][fifo][passive-projection]") {
  std::uint32_t generator = 0xc23a04U;
  constexpr std::size_t state_count = 4U;
  constexpr std::size_t atom_count = 7U;

  for (std::size_t fixture = 0U; fixture < 32U; ++fixture) {
    std::vector<std::size_t> successors(atom_count);
    std::vector<std::uint8_t> departures(atom_count);
    std::vector<std::uint32_t> weights(atom_count);
    std::uint32_t weight_total = 0U;
    for (std::size_t atom = 0U; atom < atom_count; ++atom) {
      generator = generator * 1664525U + 1013904223U;
      successors[atom] = generator % state_count;
      generator = generator * 1664525U + 1013904223U;
      departures[atom] = static_cast<std::uint8_t>(generator % 2U);
      generator = generator * 1664525U + 1013904223U;
      weights[atom] = 1U + generator % 13U;
      weight_total += weights[atom];
    }

    std::vector<mwperf::ExactRational> original(
        state_count, mwperf::ExactRational::zero());
    for (std::size_t atom = 0U; atom < atom_count; ++atom) {
      original[successors[atom]] =
          original[successors[atom]] +
          rational(weights[atom], weight_total);
    }

    for (std::size_t rank = 0U; rank <= 5U; ++rank) {
      CAPTURE(fixture, rank);
      std::vector<mwperf::ExactRational> projected(
          state_count, mwperf::ExactRational::zero());
      mwperf::ExactRational survivor_mass = mwperf::ExactRational::zero();
      mwperf::ExactRational absorbed_mass = mwperf::ExactRational::zero();
      const mwperf::TagState tagged{
          mwperf::testing::c22::state(
              static_cast<std::uint8_t>(state_count)),
          mwperf::BigNat{rank}};

      for (std::size_t atom = 0U; atom < atom_count; ++atom) {
        const auto successor = mwperf::testing::c22::state(
            static_cast<std::uint8_t>(successors[atom]));
        const mwperf::TemporalServiceStep step{
            successor, mwperf::BigNat{8U}, departures[atom]};
        const auto advanced =
            require_value(mwperf::advance_passive_fifo_tag(tagged, step));
        const auto mass = rational(weights[atom], weight_total);

        projected[successors[atom]] =
            projected[successors[atom]] + mass;
        if (advanced.tag_departed) {
          CHECK(rank == 0U);
          CHECK(departures[atom] == 1U);
          CHECK_FALSE(advanced.survivor.has_value());
          absorbed_mass = absorbed_mass + mass;
        } else {
          REQUIRE(advanced.survivor.has_value());
          CHECK(advanced.survivor->untagged_state == successor);
          const std::size_t expected_rank =
              rank == 0U ? 0U : rank - departures[atom];
          CHECK(advanced.survivor->predecessors ==
                mwperf::BigNat{expected_rank});
          survivor_mass = survivor_mass + mass;
        }
      }

      CHECK(projected == original);
      CHECK(survivor_mass + absorbed_mass ==
            mwperf::ExactRational::one());
      if (rank > 0U) {
        CHECK(absorbed_mass.is_zero());
      }
    }
  }
}

TEST_CASE("C23 finite Palm enumerations agree with direct labelled counting",
          "[c23][property][palm]") {
  using Edge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  std::uint32_t generator = 0xc23f1f0U;

  for (std::size_t fixture = 0U; fixture < 32U; ++fixture) {
    generator = generator * 1664525U + 1013904223U;
    const std::size_t edge_count = 2U + generator % 4U;
    std::vector<std::uint32_t> weights(edge_count);
    std::vector<std::uint32_t> batches(edge_count);
    std::uint32_t weight_total = 0U;
    std::size_t label_count = 0U;
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      generator = generator * 1664525U + 1013904223U;
      weights[edge] = 1U + generator % 11U;
      weight_total += weights[edge];
      generator = generator * 1664525U + 1013904223U;
      batches[edge] = generator % 5U;
      label_count += batches[edge];
    }
    if (label_count == 0U) {
      batches.front() = 1U;
      label_count = 1U;
    }

    std::vector<Edge> edges;
    mwperf::ExactRational direct_intensity =
        mwperf::ExactRational::zero();
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      const auto slot_mass = rational(weights[edge], weight_total);
      direct_intensity =
          direct_intensity + slot_mass * rational(batches[edge]);
      edges.push_back({slot_mass, mwperf::BigNat{8U}, 0U,
                       mwperf::BigNat{batches[edge]}});
    }

    const auto palm = require_value(
        mwperf::testing::C23FixtureAccess::inspect_admission_palm(edges));
    CAPTURE(fixture, edge_count, label_count);
    CHECK(palm.exact_intensity == direct_intensity);
    CHECK(palm.exact_total_mass == mwperf::ExactRational::one());
    REQUIRE(palm.atoms.size() == label_count);

    mwperf::ExactRational direct_reward =
        mwperf::ExactRational::zero();
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      const auto slot_mass = rational(weights[edge], weight_total);
      for (std::size_t rank = 1U; rank <= batches[edge]; ++rank) {
        const std::int64_t reward = static_cast<std::int64_t>(
            10U * (edge + 1U) + rank);
        direct_reward = direct_reward + slot_mass * rational(reward);
      }
    }
    direct_reward = divide(direct_reward, direct_intensity);

    mwperf::ExactRational palm_reward =
        mwperf::ExactRational::zero();
    std::vector<std::size_t> labels_per_edge(edge_count, 0U);
    for (const auto& atom : palm.atoms) {
      REQUIRE(atom.edge_index < edge_count);
      ++labels_per_edge[atom.edge_index];
      CHECK(atom.batch_size ==
            mwperf::BigNat{batches[atom.edge_index]});
      CHECK(atom.rank >= mwperf::BigNat{1U});
      CHECK(atom.rank <= atom.batch_size);
      CHECK(atom.exact_mass ==
            divide(rational(weights[atom.edge_index], weight_total),
                   direct_intensity));
      const std::int64_t reward = static_cast<std::int64_t>(
          10U * (atom.edge_index + 1U) +
          atom.rank.value().convert_to<std::size_t>());
      palm_reward = palm_reward + atom.exact_mass * rational(reward);
    }
    for (std::size_t edge = 0U; edge < edge_count; ++edge) {
      CHECK(labels_per_edge[edge] == batches[edge]);
    }
    CHECK(palm_reward == direct_reward);
  }
}

TEST_CASE("C23 batch entrances match exact backlog-dependent path enumeration",
          "[c23][property][fifo][path-oracle][batch]") {
  const std::vector<ServiceState> states{
      ServiceState{{
          ServiceTransition{0U, 0U, rational(1, 2)},
          ServiceTransition{1U, 1U, rational(1, 2)},
      }},
      ServiceState{{
          ServiceTransition{0U, 0U, rational(1, 4)},
          ServiceTransition{1U, 1U, rational(3, 4)},
      }},
  };
  // One batch of three labelled packets enters at a backlog-dependent
  // service state.  Its canonical ranks correspond to predecessor counts
  // zero, one, and two and each carries one third of the packet Palm mass.
  const std::vector<Entrance> entrance{
      {1U, 0U, rational(1, 3)},
      {1U, 1U, rational(1, 3)},
      {1U, 2U, rational(1, 3)},
  };
  const auto actual = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, entrance, 6U));
  const auto expected = exhaustive_tails(states, entrance, 6U);
  CHECK(actual == expected);
  REQUIRE(actual.size() == 7U);
  for (std::size_t index = 1U; index < actual.size(); ++index) {
    CHECK(actual[index] <= actual[index - 1U]);
  }
}

TEST_CASE("C23 total backlog remains a necessary service-state coordinate",
          "[c23][property][fifo][backlog-state]") {
  const std::vector<ServiceState> states{
      ServiceState{{ServiceTransition{
          0U, 1U, mwperf::ExactRational::one()}}},
      ServiceState{{ServiceTransition{
          0U, 0U, mwperf::ExactRational::one()}}},
  };
  // The two entrances have the same predecessor rank (R=0).  Their phase is
  // represented by the same deterministic service clock; only the base
  // state, which retains total N, differs.  Low N serves now, high N denies
  // once and then moves to the low-N state.
  const auto low_backlog = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, {{0U, 0U, mwperf::ExactRational::one()}}, 2U));
  const auto high_backlog = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, {{1U, 0U, mwperf::ExactRational::one()}}, 2U));
  CHECK(low_backlog ==
        std::vector<mwperf::ExactRational>{rational(1), rational(0),
                                           rational(0)});
  CHECK(high_backlog ==
        std::vector<mwperf::ExactRational>{rational(1), rational(1),
                                           rational(0)});
  CHECK(low_backlog != high_backlog);
}

TEST_CASE("C23 within-batch relabeling preserves the unconditioned delay law",
          "[c23][property][fifo][palm][relabel]") {
  const auto states = two_state_service(rational(1, 2), rational(1, 4));
  const std::vector<Entrance> canonical{
      {0U, 0U, rational(1, 3)},
      {0U, 1U, rational(1, 3)},
      {0U, 2U, rational(1, 3)},
  };
  const std::vector<Entrance> relabeled{
      canonical[2U], canonical[0U], canonical[1U]};
  const auto expected = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, canonical, 6U));
  const auto actual = require_value(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          states, relabeled, 6U));
  CHECK(actual == expected);
}

TEST_CASE("C23 a denial-forever FIFO tag has unit defect and infinite mean",
          "[c23][property][fifo][defect]") {
  using mwperf::testing::C22SyntheticEntranceV1;
  using mwperf::testing::C22SyntheticNodeV1;
  const auto only = mwperf::testing::c22::state(0U);
  const auto stopped = evaluate_synthetic_tag_stop(
      "c23.fifo.denial-forever",
      {C22SyntheticNodeV1{
          only,
          {tagged_transition(0U, only, only, 1U, false, false,
                             mwperf::ExactRational::one())},
          std::nullopt}},
      {C22SyntheticEntranceV1{0U, mwperf::ExactRational::one()}}, 4U);

  REQUIRE(stopped.survival_tails.size() == 5U);
  for (const auto& tail : stopped.survival_tails) {
    CHECK(tail.exact_probability == mwperf::ExactRational::one());
  }
  for (const auto& mass : stopped.absorption_masses) {
    CHECK(mass.exact_probability.is_zero());
  }
  CHECK(stopped.exact_defect_probability ==
        mwperf::ExactRational::one());
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::defective);
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
}

TEST_CASE("C23 a nearly complete finite PMF cannot hide exact defect mass",
          "[c23][property][fifo][defect][negative]") {
  using mwperf::testing::C22SyntheticEntranceV1;
  using mwperf::testing::C22SyntheticNodeV1;
  const auto entrance_state = mwperf::testing::c22::state(0U);
  const auto denial_class = mwperf::testing::c22::state(1U);
  const auto epsilon = rational(1, 1000000000000000000LL);
  const auto stopped = evaluate_synthetic_tag_stop(
      "c23.fifo.near-unit-pmf",
      {
          C22SyntheticNodeV1{
              entrance_state,
              {tagged_transition(0U, entrance_state, entrance_state, 1U,
                                 true, true,
                                 mwperf::ExactRational::one() - epsilon),
               tagged_transition(1U, entrance_state, denial_class, 1U,
                                 false, false, epsilon)},
              std::nullopt},
          C22SyntheticNodeV1{
              denial_class,
              {tagged_transition(1U, denial_class, denial_class, 1U,
                                 false, false,
                                 mwperf::ExactRational::one())},
              std::nullopt},
      },
      {C22SyntheticEntranceV1{0U, mwperf::ExactRational::one()}}, 1U);

  REQUIRE(stopped.absorption_masses.size() == 1U);
  CHECK(stopped.absorption_masses.front().exact_probability ==
        mwperf::ExactRational::one() - epsilon);
  CHECK(stopped.survival_tails.back().exact_probability == epsilon);
  CHECK(stopped.exact_defect_probability == epsilon);
  CHECK(stopped.absorption_status == mwperf::AbsorptionStatusV1::defective);
  CHECK(stopped.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
}
