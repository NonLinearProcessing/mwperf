#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"

namespace {

struct ConflictFixture final {
  mwperf::QueueCatalog catalog;
  mwperf::PriorityOrder priority;
  mwperf::ConstraintDescriptor descriptor;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> next{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c05-property";
  std::filesystem::create_directories(directory);
  const auto path = directory /
                    ("model-" + std::to_string(next.fetch_add(1U)) + ".json");
  std::ofstream stream(path, std::ios::binary | std::ios::trunc);
  REQUIRE(stream.is_open());
  stream << text;
  REQUIRE(stream.good());
  return path;
}

[[nodiscard]] ConflictFixture conflict_fixture(
    const std::size_t dimension,
    const std::vector<std::pair<std::size_t, std::size_t>>& conflicts,
    const std::vector<std::size_t>& priority_order) {
  std::string queues{"["};
  std::string priority_json{"["};
  for (std::size_t index = 0U; index < dimension; ++index) {
    if (index != 0U) {
      queues += ',';
      priority_json += ',';
    }
    queues += "\"q" + std::to_string(index) + "\"";
    priority_json +=
        "\"q" + std::to_string(priority_order[index]) + "\"";
  }
  queues += ']';
  priority_json += ']';
  std::string pairs{"["};
  for (std::size_t index = 0U; index < conflicts.size(); ++index) {
    if (index != 0U) {
      pairs += ',';
    }
    pairs += "[\"q" + std::to_string(conflicts[index].first) +
             "\",\"q" + std::to_string(conflicts[index].second) + "\"]";
  }
  pairs += ']';
  const std::string text =
      R"({"switch":{"kind":"generalized","queue_capacity":null,"queues":)" +
      queues +
      R"(},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":)" +
      pairs + R"(},"priority":)" + priority_json +
      R"(,"max_search_states":null}},"arrival":{"family":"deterministic_trace","events":[]}})";
  auto document = mwperf::load_document(write_model(text));
  REQUIRE(document);
  auto node = mwperf::extract_executable_model(document.value());
  REQUIRE(node);
  auto model = mwperf::parse_model_config_v3(node.value());
  REQUIRE(model);
  auto catalog = mwperf::build_queue_catalog(model.value().switch_config);
  REQUIRE(catalog);
  auto resolved_priority =
      mwperf::resolve_priority(model.value().scheduler, catalog.value());
  REQUIRE(resolved_priority);
  mwperf::detail::ConstraintCompilerServices compilers;
  compilers.conflicts = [](const mwperf::ResolvedConflictConstraint&) {
    std::shared_ptr<const void> owner =
        std::make_shared<const std::string>("conflict");
    return mwperf::CompiledConstraintProduct::for_fixture(
        mwperf::ServiceFamily::pairwise_conflicts, std::move(owner));
  };
  auto descriptor =
      mwperf::detail::compile_constraint_descriptor_with_child_services(
          model.value().scheduler, catalog.value(), compilers);
  REQUIRE(descriptor);
  return ConflictFixture{std::move(catalog).value(),
                         std::move(resolved_priority).value(),
                         std::move(descriptor).value()};
}

[[nodiscard]] mwperf::Digest256 digest(const char fill) {
  auto result = mwperf::Digest256::from_hex(std::string(64U, fill));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::OptimizerBudgetPolicy unlimited_policy() {
  return mwperf::OptimizerBudgetPolicy{
      .physical_per_call = std::nullopt,
      .analysis_per_call = std::nullopt,
      .effective_per_call = std::nullopt,
      .max_calls = std::nullopt,
  };
}

[[nodiscard]] mwperf::OptimizerExecutionContext make_context(
    mwperf::OptimizerBudgetPolicy policy,
    std::optional<mwperf::QueueDimensionToken> binding = std::nullopt) {
  auto result = mwperf::OptimizerExecutionContext::for_fixture(
      std::move(policy), std::nullopt, std::move(binding));
  INFO((result ? std::string{"context constructed"} : result.error().code));
  INFO((result ? std::string{} : result.error().message));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueDimensionToken token(
    const ConflictFixture& fixture, const char fill = '1') {
  return mwperf::QueueDimensionToken::for_fixture(
      digest(fill), fixture.catalog.size(), fixture.descriptor,
      fixture.priority, unlimited_policy());
}

[[nodiscard]] bool feasible(const mwperf::ResolvedConflictConstraint& graph,
                            const std::vector<std::uint8_t>& schedule) {
  return std::ranges::none_of(graph.conflicts, [&](const auto& edge) {
    return schedule[edge.first.ordinal()] != 0U &&
           schedule[edge.second.ordinal()] != 0U;
  });
}

[[nodiscard]] std::pair<std::vector<std::uint8_t>, mwperf::BigNat>
enumerated_optimum(const mwperf::ResolvedConflictConstraint& graph,
                   const mwperf::EligibilityMask& eligibility,
                   const mwperf::LexWeights& weights) {
  std::vector<std::uint8_t> best(weights.size(), 0U);
  mwperf::BigNat best_value(0U);
  bool initialized = false;
  const std::uint64_t count = std::uint64_t{1U} << weights.size();
  for (std::uint64_t mask = 0U; mask < count; ++mask) {
    std::vector<std::uint8_t> candidate(weights.size(), 0U);
    bool allowed = true;
    mwperf::BigNat objective(0U);
    for (std::size_t queue = 0U; queue < weights.size(); ++queue) {
      candidate[queue] = static_cast<std::uint8_t>((mask >> queue) & 1U);
      if (candidate[queue] != 0U) {
        allowed = allowed && eligibility.bytes()[queue] != 0U;
        objective += weights.values()[queue];
      }
    }
    if (allowed && feasible(graph, candidate) &&
        (!initialized || objective > best_value)) {
      best = std::move(candidate);
      best_value = std::move(objective);
      initialized = true;
    }
  }
  return {std::move(best), std::move(best_value)};
}

[[nodiscard]] mwperf::Result<mwperf::detail::ExactBackendCandidate>
toy_conflict_backend(
    const mwperf::ResolvedConflictConstraint& graph,
    const mwperf::CompiledConstraintProduct&,
    const mwperf::EligibilityMask& eligibility,
    const mwperf::LexWeights& weights, mwperf::SearchBudget& budget,
    const std::optional<mwperf::detail::ForcedTargetCondition>& condition,
    const mwperf::detail::ExactBackendAuthority& authority) {
  if (condition.has_value()) {
    return mwperf::Result<mwperf::detail::ExactBackendCandidate>::failure(
        mwperf::Diagnostic{.category = mwperf::DiagnosticCategory::internal,
                           .code = "test_backend_unexpected_condition",
                           .message = "this property backend is ordinary-only",
                           .authored_path = std::nullopt,
                           .json_pointer = std::nullopt,
                           .notes = {}});
  }
  // Deliberately use depth-first include/exclude recursion here. The reference
  // oracle above scans bitmasks, giving two independent test implementations.
  std::vector<std::uint8_t> current(weights.size(), 0U);
  std::vector<std::uint8_t> best(weights.size(), 0U);
  mwperf::BigNat best_value(0U);
  const auto visit = [&](const auto& self, const std::size_t queue,
                         const mwperf::BigNat& value) -> void {
    if (queue == weights.size()) {
      if (value > best_value) {
        best_value = value;
        best = current;
      }
      return;
    }
    current[queue] = 0U;
    self(self, queue + 1U, value);
    if (eligibility.bytes()[queue] == 0U) {
      return;
    }
    current[queue] = 1U;
    if (feasible(graph, current)) {
      self(self, queue + 1U, value + weights.values()[queue]);
    }
    current[queue] = 0U;
  };
  visit(visit, 0U, mwperf::BigNat(0U));
  auto schedule = mwperf::Schedule::from_bytes(weights.dimension(),
                                                std::move(best));
  REQUIRE(schedule);
  return mwperf::Result<mwperf::detail::ExactBackendCandidate>::success(
      authority.make_candidate(
          std::move(schedule).value(), std::move(best_value),
          mwperf::ServiceFamily::pairwise_conflicts,
          mwperf::OptimizerId::mwis_branch_memo_exact,
          budget.accounting()));
}

}  // namespace

TEST_CASE("C05 exhaustive small conflict families satisfy the exact contract",
          "[c05][property][optimizer]") {
  mwperf::detail::ExactOptimizerBackendServices services;
  services.conflicts = toy_conflict_backend;

  std::uint64_t state = 0x9e3779b97f4a7c15ULL;
  for (std::size_t dimension = 1U; dimension <= 7U; ++dimension) {
    for (std::size_t trial = 0U; trial < 9U; ++trial) {
      std::vector<std::pair<std::size_t, std::size_t>> edges;
      for (std::size_t first = 0U; first < dimension; ++first) {
        for (std::size_t second = first + 1U; second < dimension; ++second) {
          state = state * 6364136223846793005ULL + 1442695040888963407ULL;
          if ((state >> 61U) < 3U) {
            edges.emplace_back(first, second);
          }
        }
      }
      std::vector<std::size_t> priority(dimension);
      for (std::size_t index = 0U; index < dimension; ++index) {
        priority[index] = (index + trial) % dimension;
      }
      const auto fixture = conflict_fixture(dimension, edges, priority);
      std::vector<mwperf::BigNat> primary_values;
      std::vector<std::uint8_t> mask_values;
      for (std::size_t index = 0U; index < dimension; ++index) {
        state = state * 2862933555777941757ULL + 3037000493ULL;
        primary_values.emplace_back((state >> 59U) & 0x1fU);
        mask_values.push_back(
            static_cast<std::uint8_t>(((state >> 7U) & 3U) != 0U));
      }
      auto primary = mwperf::PrimaryWeights::from_values(
          token(fixture), std::move(primary_values));
      auto eligible = mwperf::EligibilityMask::from_bytes(
          token(fixture), std::move(mask_values));
      REQUIRE(primary);
      REQUIRE(eligible);
      auto weights = mwperf::compose_lexicographic_weights(
          primary.value(), fixture.priority, eligible.value());
      REQUIRE(weights);
      const auto& graph = std::get<mwperf::ResolvedConflictConstraint>(
          fixture.descriptor.value());
      const auto expected =
          enumerated_optimum(graph, eligible.value(), weights.value());

      auto context = make_context(unlimited_policy(), token(fixture));
      auto budget = mwperf::begin_search_budget(context);
      REQUIRE(budget);
      REQUIRE(budget.value().set_query_kind(
          mwperf::OptimizerQueryKind::ordinary));
      auto actual = mwperf::detail::solve_exact_with_backend_services(
          fixture.descriptor, eligible.value(), weights.value(),
          budget.value(), std::nullopt, services);
      INFO(dimension);
      INFO(trial);
      REQUIRE(actual);
      CHECK(std::ranges::equal(actual.value().schedule().bytes(),
                               expected.first));
      CHECK(actual.value().composite_objective() == expected.second);
    }
  }
}

TEST_CASE("C05 composite comparison exactly refines primary then lex order",
          "[c05][property][lex]") {
  for (std::size_t dimension = 1U; dimension <= 7U; ++dimension) {
    std::vector<std::size_t> priority(dimension);
    for (std::size_t index = 0U; index < dimension; ++index) {
      priority[index] = dimension - index - 1U;
    }
    const auto fixture = conflict_fixture(dimension, {}, priority);
    std::vector<mwperf::BigNat> values;
    for (std::size_t index = 0U; index < dimension; ++index) {
      values.emplace_back((index * index + 3U * index + 1U) % 5U);
    }
    auto primary =
        mwperf::PrimaryWeights::from_values(token(fixture), std::move(values));
    REQUIRE(primary);
    const auto eligible = mwperf::EligibilityMask::all(token(fixture));
    auto weights = mwperf::compose_lexicographic_weights(
        primary.value(), fixture.priority, eligible);
    REQUIRE(weights);
    const std::uint64_t count = std::uint64_t{1U} << dimension;
    for (std::uint64_t left = 0U; left < count; ++left) {
      for (std::uint64_t right = 0U; right < count; ++right) {
        mwperf::BigNat left_primary(0U);
        mwperf::BigNat right_primary(0U);
        mwperf::BigNat left_composite(0U);
        mwperf::BigNat right_composite(0U);
        mwperf::BigNat left_secondary(0U);
        mwperf::BigNat right_secondary(0U);
        for (std::size_t queue = 0U; queue < dimension; ++queue) {
          if (((left >> queue) & 1U) != 0U) {
            left_primary += primary.value().values()[queue];
            left_composite += weights.value().values()[queue];
            left_secondary += weights.value().secondary_weights()[queue];
          }
          if (((right >> queue) & 1U) != 0U) {
            right_primary += primary.value().values()[queue];
            right_composite += weights.value().values()[queue];
            right_secondary += weights.value().secondary_weights()[queue];
          }
        }
        if (left_primary != right_primary) {
          CHECK((left_composite < right_composite) ==
                (left_primary < right_primary));
        } else {
          CHECK((left_composite < right_composite) ==
                (left_secondary < right_secondary));
        }
      }
    }
  }
}

TEST_CASE("C05 recursive accounting charges each first expanded key only",
          "[c05][property][budget]") {
  for (std::size_t trial = 1U; trial <= 30U; ++trial) {
    mwperf::OptimizerBudgetPolicy policy = unlimited_policy();
    policy.analysis_per_call = mwperf::BigNat(30U);
    policy.effective_per_call = mwperf::BigNat(30U);
    auto context = make_context(std::move(policy));
    auto budget = mwperf::begin_search_budget(context);
    REQUIRE(budget);
    REQUIRE(mwperf::detail::SearchBudgetAccess::claim_dispatch(
        budget.value(), mwperf::ServiceFamily::pairwise_conflicts));
    std::set<std::size_t> expanded;
    for (std::size_t step = 0U; step < 80U; ++step) {
      const std::size_t key = (step * 17U + trial * 11U) % 31U;
      const bool base_case = key % 7U == 0U;
      if (!base_case && expanded.insert(key).second) {
        REQUIRE(mwperf::detail::SearchBudgetAccess::charge_expansion(
            budget.value()));
      }
    }
    CHECK(budget.value().completed_expansions().to_decimal_string() ==
          std::to_string(expanded.size()));
  }
}
