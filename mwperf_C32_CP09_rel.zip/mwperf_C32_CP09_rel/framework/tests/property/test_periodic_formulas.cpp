#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <random>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/periodic.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace {

struct Entry final {
  std::uint64_t offset;
  std::size_t queue;
  std::uint64_t count;
};

struct Source final {
  std::uint64_t delay;
  std::vector<Entry> entries;
};

struct Parsed final {
  mwperf::AuthoredModelConfig model;
  mwperf::QueueCatalog queues;
};

[[nodiscard]] std::filesystem::path write_model(const std::string& text) {
  static std::atomic<unsigned int> serial{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c10-periodic-properties";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory / ("case-" + std::to_string(serial.fetch_add(1U)) +
                   ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output << text;
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] Parsed parse(const std::string& arrival) {
  const std::string model =
      R"json({"switch":{"kind":"generalized","queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},"scheduler":{"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":null,"max_search_states":null}},"arrival":)json" +
      arrival + "}";
  auto document = mwperf::load_document(write_model(model));
  REQUIRE(document);
  auto executable = mwperf::extract_executable_model(document.value());
  REQUIRE(executable);
  auto authored = mwperf::parse_model_config_v3(executable.value());
  INFO((!authored ? authored.error().code + ": " + authored.error().message
                  : std::string{}));
  REQUIRE(authored);
  auto queues = mwperf::build_queue_catalog(authored.value().switch_config);
  REQUIRE(queues);
  return Parsed{std::move(authored).value(), std::move(queues).value()};
}

[[nodiscard]] mwperf::Digest256 digest() {
  auto result = mwperf::Digest256::from_hex(
      "808182838485868788898a8b8c8d8e8f"
      "909192939495969798999a9b9c9d9e9f");
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArrivalProcess process(
    const mwperf::CompiledArrivalLaw& law,
    mwperf::ArrivalInitialState initial,
    const std::uint64_t instance) {
  auto instance_key = mwperf::make_physical_reference_instance_key(
      digest(), mwperf::BigNat(instance));
  REQUIRE(instance_key);
  auto rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed(0xc10U), mwperf::StageTag::configured_arrival,
      instance_key.value());
  auto stream =
      mwperf::make_configured_arrival_stream_key(law, std::move(rng));
  REQUIRE(stream);
  auto result = mwperf::instantiate_arrival_process(
      law, initial, std::move(stream).value());
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<std::uint64_t> dense(
    const mwperf::ArrivalBatch& batch) {
  std::vector<std::uint64_t> result(3U, 0U);
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    result[entry.queue.ordinal()] =
        entry.count.value().convert_to<std::uint64_t>();
  }
  return result;
}

[[nodiscard]] std::string entries_json(const std::vector<Entry>& entries) {
  std::ostringstream output;
  output << '[';
  for (std::size_t index = 0U; index < entries.size(); ++index) {
    if (index != 0U) {
      output << ',';
    }
    const Entry& entry = entries[index];
    output << "{\"offset\":" << entry.offset
           << ",\"queue_id\":\"q" << entry.queue
           << "\",\"count\":" << entry.count << '}';
  }
  output << ']';
  return output.str();
}

[[nodiscard]] std::string global_json(const std::uint64_t period,
                                      const std::uint64_t phase,
                                      const std::vector<Source>& sources) {
  std::ostringstream output;
  output << "{\"family\":\"periodic_global_phase\",\"period\":"
         << period << ",\"phase\":" << phase << ",\"sources\":[";
  for (std::size_t index = 0U; index < sources.size(); ++index) {
    if (index != 0U) {
      output << ',';
    }
    output << "{\"id\":\"s" << index << "\",\"entries\":"
           << entries_json(sources[index].entries) << '}';
  }
  output << "],\"metadata\":{}}";
  return output.str();
}

[[nodiscard]] std::string delayed_json(const std::uint64_t period,
                                       const std::vector<Source>& sources) {
  std::ostringstream output;
  output << "{\"family\":\"periodic_source_delays\",\"period\":"
         << period << ",\"sources\":[";
  for (std::size_t index = 0U; index < sources.size(); ++index) {
    if (index != 0U) {
      output << ',';
    }
    output << "{\"id\":\"s" << index << "\",\"delay\":"
           << sources[index].delay << ",\"entries\":"
           << entries_json(sources[index].entries) << '}';
  }
  output << "],\"metadata\":{}}";
  return output.str();
}

[[nodiscard]] std::vector<Source> random_sources(std::mt19937_64& generator,
                                                 const std::uint64_t period,
                                                 const bool with_delays) {
  std::vector<Source> sources(3U);
  for (Source& source : sources) {
    source.delay = with_delays ? generator() % 11U : 0U;
    const std::size_t entry_count = static_cast<std::size_t>(generator() % 7U);
    for (std::size_t entry = 0U; entry < entry_count; ++entry) {
      source.entries.push_back(Entry{generator() % period,
                                     static_cast<std::size_t>(generator() % 3U),
                                     1U + generator() % 7U});
    }
  }
  return sources;
}

}  // namespace

TEST_CASE("C10 random global-periodic paths satisfy the exact indicator formula",
          "[c10][property]") {
  std::mt19937_64 generator(0xc10001U);
  for (std::uint64_t trial = 0U; trial < 48U; ++trial) {
    const std::uint64_t period = 1U + generator() % 7U;
    const std::uint64_t phase = generator() % period;
    const std::vector<Source> sources =
        random_sources(generator, period, false);
    auto parsed = parse(global_json(period, phase, sources));
    auto compiled =
        mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE(compiled);
    auto cursor = process(compiled.value(), mwperf::GlobalPeriodicOrigin{},
                          1000U + trial);
    std::vector<bool> observed(3U, false);
    for (std::uint64_t slot = 0U; slot < 3U * period; ++slot) {
      std::vector<std::uint64_t> expected(3U, 0U);
      for (const Source& source : sources) {
        for (const Entry& entry : source.entries) {
          if (slot % period == (entry.offset + phase) % period) {
            expected[entry.queue] += entry.count;
          }
        }
      }
      auto step = mwperf::next_periodic_batch(cursor, mwperf::BigNat(slot));
      REQUIRE(step);
      const auto actual = dense(step.value().batch);
      CHECK(actual == expected);
      for (std::size_t queue = 0U; queue < actual.size(); ++queue) {
        observed[queue] = observed[queue] || actual[queue] != 0U;
      }
    }
    const auto support = mwperf::positive_arrival_support(compiled.value());
    for (std::size_t queue = 0U; queue < observed.size(); ++queue) {
      auto dense_queue = parsed.queues.index_at(queue);
      REQUIRE(dense_queue);
      CHECK(support.at(dense_queue.value()) == observed[queue]);
    }
    auto snapshot = mwperf::testing::snapshot_arrival_process(cursor);
    REQUIRE(snapshot);
    CHECK(snapshot.value().rng.consumed_words().is_zero());
  }
}

TEST_CASE("C10 random delayed paths satisfy the guarded exact indicator formula",
          "[c10][property]") {
  std::mt19937_64 generator(0xc10002U);
  for (std::uint64_t trial = 0U; trial < 48U; ++trial) {
    const std::uint64_t period = 1U + generator() % 7U;
    const std::vector<Source> sources =
        random_sources(generator, period, true);
    auto parsed = parse(delayed_json(period, sources));
    auto compiled =
        mwperf::compile_arrival_law(parsed.model.arrival, parsed.queues);
    REQUIRE(compiled);
    auto cursor = process(compiled.value(), mwperf::SourceDelayOrigin{},
                          2000U + trial);
    std::uint64_t maximum_delay = 0U;
    for (const Source& source : sources) {
      maximum_delay = std::max(maximum_delay, source.delay);
    }
    std::vector<bool> observed(3U, false);
    const std::uint64_t horizon = maximum_delay + 3U * period;
    for (std::uint64_t slot = 0U; slot < horizon; ++slot) {
      std::vector<std::uint64_t> expected(3U, 0U);
      for (const Source& source : sources) {
        if (slot < source.delay) {
          continue;
        }
        for (const Entry& entry : source.entries) {
          if ((slot - source.delay) % period == entry.offset) {
            expected[entry.queue] += entry.count;
          }
        }
      }
      auto step = mwperf::next_periodic_batch(cursor, mwperf::BigNat(slot));
      REQUIRE(step);
      const auto actual = dense(step.value().batch);
      CHECK(actual == expected);
      for (std::size_t queue = 0U; queue < actual.size(); ++queue) {
        observed[queue] = observed[queue] || actual[queue] != 0U;
      }
    }
    const auto support = mwperf::positive_arrival_support(compiled.value());
    for (std::size_t queue = 0U; queue < observed.size(); ++queue) {
      auto dense_queue = parsed.queues.index_at(queue);
      REQUIRE(dense_queue);
      CHECK(support.at(dense_queue.value()) == observed[queue]);
    }
    auto snapshot = mwperf::testing::snapshot_arrival_process(cursor);
    REQUIRE(snapshot);
    CHECK(snapshot.value().rng.consumed_words().is_zero());
  }
}

TEST_CASE("C10 offset and opposite phase shifts preserve global batches",
          "[c10][property]") {
  const std::uint64_t period = 5U;
  const std::uint64_t phase = 3U;
  const std::uint64_t shift = 2U;
  const std::vector<Source> original{
      Source{0U, {{0U, 0U, 2U}, {4U, 1U, 3U}}},
      Source{0U, {{2U, 0U, 5U}, {0U, 2U, 7U}}}};
  std::vector<Source> shifted = original;
  for (Source& source : shifted) {
    for (Entry& entry : source.entries) {
      entry.offset = (entry.offset + shift) % period;
    }
  }
  const std::uint64_t opposite_phase = (phase + period - shift) % period;
  auto first_parsed = parse(global_json(period, phase, original));
  auto second_parsed = parse(global_json(period, opposite_phase, shifted));
  auto first_law = mwperf::compile_arrival_law(first_parsed.model.arrival,
                                               first_parsed.queues);
  auto second_law = mwperf::compile_arrival_law(second_parsed.model.arrival,
                                                second_parsed.queues);
  REQUIRE(first_law);
  REQUIRE(second_law);
  auto first = process(first_law.value(), mwperf::GlobalPeriodicOrigin{}, 1U);
  auto second = process(second_law.value(), mwperf::GlobalPeriodicOrigin{}, 1U);
  for (std::uint64_t slot = 0U; slot < 4U * period; ++slot) {
    auto left = mwperf::next_periodic_batch(first, mwperf::BigNat(slot));
    auto right = mwperf::next_periodic_batch(second, mwperf::BigNat(slot));
    REQUIRE(left);
    REQUIRE(right);
    CHECK(dense(left.value().batch) == dense(right.value().batch));
  }
}

TEST_CASE("C10 adding whole periods to a source delay preserves its active residue path",
          "[c10][property]") {
  constexpr std::uint64_t period = 5U;
  constexpr std::uint64_t original_delay = 2U;
  constexpr std::uint64_t period_shift = 3U;
  constexpr std::uint64_t shifted_delay =
      original_delay + period_shift * period;
  const std::vector<Entry> entries{
      {0U, 0U, 2U}, {1U, 2U, 7U}, {4U, 1U, 3U}};

  auto original_parsed = parse(delayed_json(
      period, std::vector<Source>{Source{original_delay, entries}}));
  auto shifted_parsed = parse(delayed_json(
      period, std::vector<Source>{Source{shifted_delay, entries}}));
  auto original_law = mwperf::compile_arrival_law(
      original_parsed.model.arrival, original_parsed.queues);
  auto shifted_law = mwperf::compile_arrival_law(
      shifted_parsed.model.arrival, shifted_parsed.queues);
  REQUIRE(original_law);
  REQUIRE(shifted_law);
  auto original = process(original_law.value(), mwperf::SourceDelayOrigin{},
                          3001U);
  auto shifted = process(shifted_law.value(), mwperf::SourceDelayOrigin{},
                         3002U);

  std::vector<std::vector<std::uint64_t>> original_path;
  const std::uint64_t horizon = shifted_delay + 3U * period;
  original_path.reserve(static_cast<std::size_t>(horizon));
  for (std::uint64_t slot = 0U; slot < horizon; ++slot) {
    auto original_step =
        mwperf::next_periodic_batch(original, mwperf::BigNat(slot));
    auto shifted_step =
        mwperf::next_periodic_batch(shifted, mwperf::BigNat(slot));
    REQUIRE(original_step);
    REQUIRE(shifted_step);
    const auto original_batch = dense(original_step.value().batch);
    const auto shifted_batch = dense(shifted_step.value().batch);
    original_path.push_back(original_batch);

    if (slot < shifted_delay) {
      CHECK(shifted_batch == std::vector<std::uint64_t>(3U, 0U));
      continue;
    }

    // Adding kP changes only the one-sided activation boundary. Once the
    // shifted source is active, its residue agrees both at the same absolute
    // slot and with the original path shifted forward by exactly kP.
    CHECK(shifted_batch == original_batch);
    CHECK(shifted_batch ==
          original_path[static_cast<std::size_t>(
              slot - period_shift * period)]);
  }
}

TEST_CASE("C10 entry permutations retain canonical compiled periodic identity",
          "[c10][property]") {
  const std::string first = R"json({"family":"periodic_source_delays","period":3,"sources":[{"id":"a","delay":2,"entries":[{"offset":2,"queue_id":"q1","count":4},{"offset":0,"queue_id":"q0","count":1},{"offset":0,"queue_id":"q0","count":2}]}],"metadata":{}})json";
  const std::string second = R"json({"family":"periodic_source_delays","period":3,"sources":[{"id":"a","delay":2,"entries":[{"offset":0,"queue_id":"q0","count":2},{"offset":2,"queue_id":"q1","count":4},{"offset":0,"queue_id":"q0","count":1}]}],"metadata":{}})json";
  auto left = parse(first);
  auto right = parse(second);
  auto left_law =
      mwperf::compile_arrival_law(left.model.arrival, left.queues);
  auto right_law =
      mwperf::compile_arrival_law(right.model.arrival, right.queues);
  REQUIRE(left_law);
  REQUIRE(right_law);
  CHECK(mwperf::arrival_law_binding(left_law.value()).law_digest ==
        mwperf::arrival_law_binding(right_law.value()).law_digest);
  CHECK(mwperf::builder_arrival_view(left_law.value()).configured_law() ==
        mwperf::builder_arrival_view(right_law.value()).configured_law());
}
