#include <chrono>
#include <cerrno>
#include <csignal>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

#if defined(__linux__)
#include <sched.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/syscall.h>
#include <unistd.h>
#endif

namespace {

struct Arguments final {
  std::filesystem::path request;
  std::filesystem::path result;
  std::string mode{"success"};
};

[[nodiscard]] bool parse_arguments(const int argc, char** argv,
                                   Arguments& result) {
  if (argc < 5 || std::string_view(argv[1]) != "--request") {
    return false;
  }
  for (int index = 1; index < argc; ++index) {
    const std::string_view argument(argv[index]);
    if (argument == "--request" && index + 1 < argc) {
      result.request = argv[++index];
    } else if (argument == "--result" && index + 1 < argc) {
      result.result = argv[++index];
    } else if (argument.starts_with("--mode=")) {
      result.mode = std::string(argument.substr(7U));
    } else {
      return false;
    }
  }
  return !result.request.empty() && !result.result.empty();
}

[[nodiscard]] bool write_bytes(const std::filesystem::path& path,
                               const std::string_view bytes) {
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  output.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  return output.good();
}

[[nodiscard]] bool consume_request(const std::filesystem::path& path) {
  std::ifstream input(path, std::ios::binary);
  if (!input.is_open()) {
    return false;
  }
  const std::string bytes((std::istreambuf_iterator<char>(input)),
                          std::istreambuf_iterator<char>());
  return input.good() || (input.eof() && !bytes.empty());
}

}  // namespace

int main(const int argc, char** argv) {
  Arguments arguments;
  if (!parse_arguments(argc, argv, arguments)) {
    return 64;
  }
  if (arguments.mode == "ambient-first-virtualized") {
    errno = 0;
    std::ifstream ambient("/etc/passwd", std::ios::binary);
    if (ambient.is_open()) {
      const std::string received((std::istreambuf_iterator<char>(ambient)),
                                 std::istreambuf_iterator<char>());
      if (received.find("\"build_identity_digest\"") ==
              std::string::npos ||
          received.find("root:") != std::string::npos) {
        return 82;
      }
      return write_bytes("../capability-write-sentinel",
                         R"({"protocol_version":1,"fixture":"complete"})")
                 ? 0
                 : 83;
    }
    if (errno != EACCES && errno != EPERM) {
      return 84;
    }
  }
  if (!consume_request(arguments.request)) {
    return 65;
  }
  if (arguments.mode == "nonzero") {
    return 9;
  }
  if (arguments.mode == "stdout") {
    std::cout << "forbidden";
    return 0;
  }
  if (arguments.mode == "stderr") {
    std::cerr << "bounded fixture diagnostic";
    return 7;
  }
  if (arguments.mode == "stderr-large") {
    std::cerr << std::string(128U << 10U, 'e');
    return 7;
  }
  if (arguments.mode == "timeout") {
    std::this_thread::sleep_for(std::chrono::seconds(10));
    return 0;
  }
  if (arguments.mode == "partial-result") {
    if (!write_bytes(arguments.result, "{")) {
      return 74;
    }
    std::this_thread::sleep_for(std::chrono::seconds(10));
    return 0;
  }
  if (arguments.mode == "threaded") {
    std::vector<unsigned> values(4U, 0U);
    std::vector<std::thread> workers;
    workers.reserve(values.size());
    for (std::size_t index = 0; index < values.size(); ++index) {
      workers.emplace_back([&values, index] {
        values[index] = static_cast<unsigned>((index + 1U) * (index + 1U));
      });
    }
    for (auto& worker : workers) {
      worker.join();
    }
    if (values != std::vector<unsigned>{1U, 4U, 9U, 16U}) {
      return 85;
    }
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
  }
  if (arguments.mode == "clone-policy") {
#if defined(__linux__) && defined(SYS_clone) && defined(CLONE_NEWUSER)
    errno = 0;
    const long process_clone = ::syscall(
        SYS_clone, static_cast<unsigned long>(SIGCHLD), nullptr, nullptr,
        nullptr, 0UL);
    if (process_clone != -1L || errno != EPERM) {
      if (process_clone == 0L) {
        ::_exit(86);
      }
      return 86;
    }

    errno = 0;
    const auto namespace_flags = static_cast<unsigned long>(
        CLONE_VM | CLONE_SIGHAND | CLONE_THREAD | CLONE_NEWUSER);
    const long namespace_clone = ::syscall(
        SYS_clone, namespace_flags, nullptr, nullptr, nullptr, 0UL);
    if (namespace_clone != -1L || errno != EPERM) {
      if (namespace_clone == 0L) {
        ::_exit(87);
      }
      return 87;
    }
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
#else
    return 88;
#endif
  }
  if (arguments.mode == "signal") {
    (void)std::raise(SIGUSR1);
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
  }
  if (arguments.mode == "missing-result") {
    return 0;
  }
  if (arguments.mode == "extra-file") {
    return write_bytes(arguments.result, "{}") &&
                   write_bytes(arguments.result.parent_path() / "extra", "x")
               ? 0
               : 74;
  }
  if (arguments.mode == "mutate-request") {
    return write_bytes(arguments.request, "mutated") &&
                   write_bytes(arguments.result, "{}")
               ? 0
               : 74;
  }
  if (arguments.mode == "oversize") {
    return write_bytes(arguments.result, std::string(8192U, 'x')) ? 0 : 74;
  }
  if (arguments.mode == "wrong-version") {
    return write_bytes(arguments.result,
                       R"({"kind":"unavailable","envelope":{"protocol_version":999,"request_digest":"fd6fde90fcce43a2a69fb9b6f1755632dee395713a174bbda6215206d4e89c20","provider":{"provider_id":"c15.fixture.golden","provider_version":"1.0.0"},"build_report":{"report_schema_version":1,"report_id":{"kind":"text","value":"c15.fixture.report"},"report_digest":"acd583390426bced1ebcc5db606c5880432cc190fd254b277ce7e06c7c7c52f9","request_digest":"fd6fde90fcce43a2a69fb9b6f1755632dee395713a174bbda6215206d4e89c20","construction_budget_digest":"aa6e598d3d6e53d39efdf59a7f23d4657ef0cd46e5014cd2f4fce9a2810c8c46","optimizer_calls":{"applicability":"applicable","used":"0"},"optimizer_search_states":{"applicability":"applicable","used":"0"},"configured_generator_draws":{"applicability":"applicable","used":"0"},"optional_component_digests":[],"optional_method_counters":[]}},"reasons":[{"kind":"unmet_construction_assumption","code":"c15.golden.unmet_construction_assumption","message":"canonical unavailable reason unmet_construction_assumption","metric_clause_id":{"metric_id":"throughput","authored_index":"0"},"subject":{"object_id":{"kind":"text","value":"coefficient-1"},"object_digest":"a721b93149b404a835117a6e7fe7c5a0136b79fa8d9bcc576d2187e75fd1bde3"}}]})")
               ? 0
               : 74;
  }
  if (arguments.mode == "ambient-read-denied") {
    errno = 0;
    std::ifstream ambient("../ambient-sentinel", std::ios::binary);
    if (ambient.is_open() || (errno != EACCES && errno != EPERM)) {
      return 77;
    }
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
  }
  if (arguments.mode == "ambient-absolute-read-denied") {
    errno = 0;
    std::ifstream ambient("/etc/passwd", std::ios::binary);
    if (ambient.is_open() || (errno != EACCES && errno != EPERM)) {
      return 77;
    }
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
  }
  if (arguments.mode == "ambient-kernel-state-denied") {
#if defined(__linux__) && defined(SYS_getrandom) && defined(SYS_shmget)
    unsigned char entropy = 0U;
    errno = 0;
    const long entropy_result =
        ::syscall(SYS_getrandom, &entropy, sizeof(entropy), 0U);
    if (entropy_result != -1L || errno != EPERM) {
      return 78;
    }
    errno = 0;
    const long shared_memory =
        ::syscall(SYS_shmget, IPC_PRIVATE, 4096U, IPC_CREAT | 0600);
    if (shared_memory >= 0L) {
      (void)::shmctl(static_cast<int>(shared_memory), IPC_RMID, nullptr);
      return 79;
    }
    if (errno != EPERM) {
      return 80;
    }
    return write_bytes(arguments.result,
                       R"({"protocol_version":1,"fixture":"complete"})")
               ? 0
               : 74;
#else
    return 81;
#endif
  }
  return write_bytes(arguments.result,
                     R"({"protocol_version":1,"fixture":"complete"})")
             ? 0
             : 74;
}
