#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "arrival/core_internal.hpp"
#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "support/c16_audited_handle_fixture.hpp"
#include "support/c16_test_providers.hpp"
#include "surrogate/payload_wire.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;

template <typename Access>
concept DirectMetricExecutionAccess = requires(
    const mwperf::AuditedCompiledFramework& framework,
    const Access& access, const mwperf::MetricRequest& request) {
  mwperf::execute_direct_metric_decoder(framework, access, request);
};

[[nodiscard]] mwperf::TypedLabel label(const std::string& text) {
  auto result = mwperf::TypedLabel::text(text);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue_id(const std::string& text) {
  return mwperf::QueueId(label(text));
}

[[nodiscard]] mwperf::Digest256 digest_of(const std::string_view text) {
  auto result = mwperf::sha256(
      std::as_bytes(std::span<const char>(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::RawDirectRequestEncoderV1 fixed_direct_encoder(
    mwperf::CodecIdentityV1 request_codec) {
  return [request_codec = std::move(request_codec)](
             const mwperf::MetricRequest&) {
    return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
        {request_codec, {}});
  };
}

[[nodiscard]] mwperf::RawDirectResultValidatorV1 direct_result_validator(
    mwperf::ExactMetricDecoderKeyV1 decoder_key,
    mwperf::CodecIdentityV1 result_codec) {
  return [decoder_key = std::move(decoder_key),
          result_codec = std::move(result_codec)](
             const mwperf::ExactMetricDecoderKeyV1& supplied_key,
             const mwperf::CodecIdentityV1& supplied_codec,
             const std::span<const std::byte>) {
    if (!(supplied_key == decoder_key) || supplied_codec != result_codec) {
      return mwperf::Result<void>::failure({
          mwperf::DiagnosticCategory::input_validation,
          "c16.fixture.direct_result_binding_mismatch",
          "the decoded value is outside the fixed direct-result domain",
          std::nullopt,
          std::nullopt,
          {}});
    }
    return mwperf::Result<void>::success();
  };
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::PortableScientificScalar scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return mwperf::PortableScientificScalar::rational(
      rational(numerator, denominator));
}

[[nodiscard]] mwperf::SourceNode object_node(
    const std::string_view resolution_level = "1") {
  const mwperf::SourceLocation location{
      "c16-fixture.json", 1U, 1U, 0U};
  return mwperf::SourceNode::make_object(
      {{"resolution_level", location,
        mwperf::SourceNode::make_number(
            std::string(resolution_level), location,
            "/resolution_level")}},
      location, "");
}

[[nodiscard]] std::filesystem::path write_input(const std::string_view stem,
                                                const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c16-input";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct InputFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  mwperf::MetricRequirements requirements;
  mwperf::MetricRequest request;
};

[[nodiscard]] InputFixture make_input_fixture(
    const bool direct_solver = false,
    const std::string_view arrival_json =
        R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
    const std::string_view scheduler_json =
        R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],"max_search_states":null}})json") {
  static constexpr std::string_view model_template = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":__C16_SCHEDULER__,
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  std::string model_text(model_template);
  static constexpr std::string_view default_arrival =
      R"json({"family":"deterministic_trace","events":[],"metadata":{}})json";
  const auto arrival_position = model_text.find(default_arrival);
  REQUIRE(arrival_position != std::string::npos);
  model_text.replace(arrival_position, default_arrival.size(), arrival_json);
  static constexpr std::string_view scheduler_placeholder =
      "__C16_SCHEDULER__";
  const auto scheduler_position = model_text.find(scheduler_placeholder);
  REQUIRE(scheduler_position != std::string::npos);
  model_text.replace(scheduler_position, scheduler_placeholder.size(),
                     scheduler_json);
  static constexpr std::string_view analysis_template = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.mwis.engineered","version":"1.0.0",
                 "parameters":{}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}}
  })json";
  std::string analysis_text(analysis_template);
  if (direct_solver) {
    static constexpr std::string_view analytic =
        R"json({"kind":"analytic","parameters":{"precision_bits":128,
                                                     "max_iterations":null}})json";
    static constexpr std::string_view direct =
        R"json({"kind":"direct","parameters":{}})json";
    const auto position = analysis_text.find(analytic);
    REQUIRE(position != std::string::npos);
    analysis_text.replace(position, analytic.size(), direct);
  }

  auto model_document = mwperf::load_document(write_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  REQUIRE(model);
  auto analysis_document =
      mwperf::load_document(write_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(analysis);
  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = mwperf::parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<mwperf::MetricRequest> requests{request.value()};
  auto requirements = mwperf::aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

// Re-publish an otherwise valid C09 test law with its portable configured-law
// recipe removed.  The live runtime adapter remains present, so a view with no
// other portable table is the callback-only negative required by C16.  When
// the source has an IID table or finite rows, those remain an independent
// callback-free reconstruction witness.
[[nodiscard]] mwperf::Result<mwperf::CompiledArrivalLaw>
without_portable_arrival_recipe(
    const mwperf::CompiledArrivalLaw& law,
    const mwperf::QueueCatalog& queues) {
  const auto& core = mwperf::detail::ArrivalCoreAccess::law_core(law);
  const auto& view = core->builder_view;
  return mwperf::detail::publish_compiled_arrival_law(
      queues,
      mwperf::detail::CompiledArrivalProduct{
          .family = core->binding.family,
          .normalized_rows = core->normalized_rows,
          .positive_support = std::vector<std::uint8_t>(
              view.positive_support().bytes().begin(),
              view.positive_support().bytes().end()),
          .capabilities = core->capabilities,
          .canonical_law_data = {},
          .portable_schema = view.configured_law().schema,
          .payload = core->payload,
          .runtime = core->runtime,
          .iid_joint_table = view.iid_joint_table(),
          .moments = view.moments(),
          .covariances = view.covariances(),
          .analytic_transform = view.analytic_transform(),
          .joint_distribution = view.joint_distribution(),
          .coordinate_distributions = view.coordinate_distributions(),
          .replay_codec = view.replay_codec(),
          .unit_cube = view.unit_cube(),
          .finite_phase = view.finite_phase(),
          .transition_rows = view.transition_rows(),
          .stationary_phase_law = view.stationary_phase_law()});
}

[[nodiscard]] std::string_view scheduler_for_family(
    const mwperf::ServiceFamily family) {
  switch (family) {
    case mwperf::ServiceFamily::crossbar_matching:
      return R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i1","output":"o1"}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::nonoverlapping_intervals:
      return R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":1},{"queue_id":"q1","left":1,"right":2}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::node_exclusive_matching:
      return R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["u","v","w","x"],"links":[{"queue_id":"q0","u":"u","v":"v"},{"queue_id":"q1","u":"w","v":"x"}]},"priority":["q0","q1"]}})json";
    case mwperf::ServiceFamily::pairwise_conflicts:
      return R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0","q1"],"max_search_states":null}})json";
    case mwperf::ServiceFamily::resource_packing:
      return R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[2]}]},"priority":["q0","q1"],"max_search_states":null}})json";
  }
  FAIL("unreachable C16 fixture service family");
  return {};
}

[[nodiscard]] mwperf::ConstructionBudget construction_budget() {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::applicable, mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

struct BoundScenario final {
  mwperf::SurrogateProvider provider;
  mwperf::ResolvedInstance instance;
  mwperf::MetricRequirements requirements;
  mwperf::MetricRequest metric_request;
  mwperf::FrameworkProblemView view;
  mwperf::ValidatedSurrogateParameters parameters;
  mwperf::PlugDescriptorPreview preview;
  mwperf::AcceptedCapabilityContract contract;
  mwperf::ConstructionBudget budget;
  mwperf::SurrogateBuildRequest request;
};

[[nodiscard]] BoundScenario make_bound_scenario(
    const std::string& id,
    std::optional<mwperf::ConstructionBudget> selected_budget = std::nullopt,
    std::optional<mwperf::ConstructionPrerequisitesV1>
        selected_prerequisites = std::nullopt) {
  auto input = make_input_fixture();
  auto typed_id = mwperf::SurrogateId::parse(id);
  REQUIRE(typed_id);
  auto provider = mwperf::lookup_surrogate_provider(typed_id.value());
  INFO((provider ? std::string{} : provider.error().code));
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.fixture.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), object_node());
  REQUIRE(parameters);
  auto budget = selected_budget.has_value() ? std::move(*selected_budget)
                                            : construction_budget();
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, budget,
      parameters.value());
  INFO((preview ? std::string{} : preview.error().code));
  REQUIRE(preview);
  auto budget_digest = mwperf::digest_construction_budget_v1(budget);
  REQUIRE(budget_digest);
  const auto& raw_manifest = provider.value().manifest().value();
  auto contract = Factory::accepted_contract(
      raw_manifest, preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      selected_prerequisites.has_value()
          ? std::move(*selected_prerequisites)
          : preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), budget, mwperf::MasterSeed(0xC16U));
  INFO((request ? std::string{} : request.error().code));
  REQUIRE(request);
  return {std::move(provider).value(), std::move(input.instance),
          std::move(input.requirements), std::move(input.request),
          std::move(view).value(), std::move(parameters).value(),
          std::move(preview).value(), std::move(contract), std::move(budget),
          std::move(request).value()};
}

[[nodiscard]] std::filesystem::path execution_root() {
  auto root = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c16-runs";
  std::error_code error;
  std::filesystem::create_directories(root, error);
  REQUIRE_FALSE(error);
  root = std::filesystem::canonical(root, error);
  REQUIRE_FALSE(error);
  return root;
}

[[nodiscard]] mwperf::BuildExecutionContext execution_context(
    const BoundScenario& scenario) {
  auto context = mwperf::BuildExecutionContext::create(
      scenario.request, scenario.provider.manifest(), execution_root());
  INFO((context ? std::string{} : context.error().code));
  REQUIRE(context);
  return std::move(context).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object_ref(
    const std::string& name) {
  return {label(name), digest_of(name)};
}

void reseal_descriptor(mwperf::PlugDescriptor& descriptor,
                       const bool core_changed = false) {
  if (core_changed) {
    auto core_digest =
        mwperf::canonical_plug_descriptor_core_digest_v1(descriptor.core);
    REQUIRE(core_digest);
    descriptor.core.core_digest = std::move(core_digest).value();
  }
  auto descriptor_digest =
      mwperf::canonical_plug_descriptor_digest_v1(descriptor);
  REQUIRE(descriptor_digest);
  descriptor.descriptor_digest = std::move(descriptor_digest).value();
}

[[nodiscard]] mwperf::ProviderConformanceReportRef conformance(
    const BoundScenario& scenario) {
  const auto& anchor = scenario.provider.manifest().value()
                           .family_evidence_conformance_report_anchors.front();
  return {anchor.report_schema_version,
          anchor.report_id,
          anchor.report_digest,
          scenario.provider.identity(),
          scenario.provider.manifest().scientific_contract_digest().value(),
          anchor.family_evidence_schema_id,
          anchor.family_evidence_schema_version};
}

[[nodiscard]] mwperf::CoefficientIdentificationV1 identification(
    const BoundScenario& scenario, const mwperf::ThreeBinCoefficientV1 bin,
    const mwperf::PortableScientificScalar& point) {
  mwperf::CoefficientIdentificationV1 result{
      object_ref("c16.coefficient." +
                 std::to_string(static_cast<unsigned>(bin))),
      {mwperf::ProposalConditioningSourceV1::exact_population, scalar(1, 1),
       std::nullopt},
      {mwperf::PopulationConditioningStatusV1::proved_positive,
       mwperf::RawValueStatusV1::exact_point},
      point,
      {},
      conformance(scenario),
      std::nullopt,
      bin};
  auto digest =
      mwperf::artifact::detail::coefficient_identification_digest_v1(result);
  REQUIRE(digest);
  result.coefficient_id.object_digest = std::move(digest).value();
  return result;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 response_record(
    const BoundScenario& scenario) {
  const auto q0 = scenario.view.target_selection().ordered_targets.front();
  std::array identifications{
      identification(scenario, mwperf::ThreeBinCoefficientV1::one,
                     scalar(1, 4)),
      identification(scenario, mwperf::ThreeBinCoefficientV1::two,
                     scalar(3, 4)),
      identification(scenario, mwperf::ThreeBinCoefficientV1::tail_from_three,
                     scalar(1, 2))};
  auto raw_id = Factory::raw_response_product_id(object_ref("c16.raw"));
  mwperf::RawResponseProductV1 raw{
      raw_id,
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      q0,
      scenario.view.fingerprints().compiled_arrival,
      digest_of("c16.proposal-law"),
      std::move(identifications)};
  auto raw_digest = mwperf::canonical_raw_response_product_digest_v1(raw);
  REQUIRE(raw_digest);
  raw.product_id = Factory::raw_response_product_id(
      {label("c16.raw"), std::move(raw_digest).value()});
  mwperf::ThreeBinScalarResponseV1 response{
      1U,
      object_ref("c16.response-row"),
      q0,
      scenario.view.fingerprints().compiled_arrival,
      std::move(raw),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      raw_id,
      {}};
  response.deployed_response_product_id = response.raw_response.product_id;
  auto row_digest = mwperf::canonical_three_bin_response_row_digest_v1(response);
  REQUIRE(row_digest);
  response.response_row_id.object_digest = std::move(row_digest).value();
  return response;
}

struct MaterializationFixture final {
  mwperf::ValidatedSurrogateArtifact artifact;
  mwperf::PortablePlugPayload payload;
};

[[nodiscard]] MaterializationFixture materialization_fixture(
    const BoundScenario& scenario) {
  auto record = response_record(scenario);
  const auto payload_identity =
      object_ref("c16.payload." + scenario.provider.identity().provider_id);
  const auto payload_digest =
      digest_of("c16.payload.bytes." + scenario.provider.identity().provider_id);
  auto manifest_bytes = mwperf::canonical_metric_support_manifest_bytes_v1(
      scenario.contract.structural_manifest());
  REQUIRE(manifest_bytes);
  const mwperf::MetricSupportManifestEchoV1 echo{
      1U, std::move(manifest_bytes).value(),
      scenario.contract.structural_manifest().canonical_digest()};
  const mwperf::BoundRealizedMetricBindingsV1 realized{
      scenario.request.request_digest().value(), payload_digest, {}};
  const mwperf::PortablePayloadContextV1 context{
      scenario.contract.payload_class(),
      scenario.contract.semantic(),
      scenario.contract.runtime_access(),
      scenario.request.build_identity_digest().digest(),
      scenario.request.request_digest().value(),
      scenario.view.canonical_digest().value(),
      {scenario.view.target_selection().ordered_targets.front()},
      payload_identity,
      payload_digest,
      echo,
      realized,
      {},
      {}};
  mwperf::PortableThreeBinScalarResponseV1 portable{
      context,
      scenario.view.target_selection().ordered_targets.front(),
      {rational(1, 4), rational(3, 4), rational(1, 2)},
      record.deployed_response_product_id,
      record};
  auto payload = Factory::portable_payload(std::move(portable));
  mwperf::SurrogateArtifactV1 source{
      1U,
      scenario.request.request_digest().value(),
      scenario.provider.identity(),
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.contract.construction_method(),
      scenario.contract.producer_mode(),
      scenario.contract.semantic(),
      scenario.contract.runtime_access(),
      scenario.contract.payload_class(),
      payload_identity,
      record,
      payload_digest,
      echo,
      realized,
      scenario.contract.descriptor_core(),
      {1U,
       label("c16.report"),
       digest_of("c16.report"),
       scenario.request.request_digest().value(),
       scenario.contract.budget_digest(),
       {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
       {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
       {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
       {},
       {}},
      {},
      {},
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt, std::nullopt}};
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);
  const mwperf::ArtifactValidationBindingsV1 bindings{
      scenario.request.build_identity_digest().digest(),
      scenario.request.request_digest().value(),
      scenario.provider.identity(),
      scenario.provider.manifest().value().parameter_schema_version,
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.contract.construction_method(),
      scenario.contract.producer_mode(),
      scenario.contract.semantic(),
      scenario.contract.runtime_access(),
      scenario.contract.payload_class(),
      scenario.view.canonical_digest().value(),
      std::move(selection_digest).value(),
      scenario.contract.contract_digest(),
      scenario.contract.requirements_digest(),
      scenario.contract.arrival_capabilities_digest(),
      scenario.contract.preview_digest(),
      scenario.contract.parameter_digest(),
      scenario.contract.budget_digest(),
      scenario.contract.structural_manifest().canonical_digest()};
  return {Factory::validated_artifact(std::move(source), bindings),
          std::move(payload)};
}

[[nodiscard]] mwperf::CommonBuildReportV1 sealed_report(
    const BoundScenario& scenario) {
  mwperf::CommonBuildReportV1 report{
      1U,
      label("c16.report"),
      digest_of("c16.report.placeholder"),
      scenario.request.request_digest().value(),
      scenario.contract.budget_digest(),
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {mwperf::WorkCounterApplicabilityV1::applicable, mwperf::BigNat{0U}},
      {},
      {}};
  auto digest = mwperf::canonical_common_build_report_digest_v1(report);
  REQUIRE(digest);
  report.report_digest = std::move(digest).value();
  return report;
}

void reseal_report(mwperf::CommonBuildReportV1& report) {
  auto digest = mwperf::canonical_common_build_report_digest_v1(report);
  REQUIRE(digest);
  report.report_digest = std::move(digest).value();
}

[[nodiscard]] mwperf::SurrogateBuildResult built_result(
    const BoundScenario& scenario,
    const mwperf::CommonBuildReportV1& report) {
  auto materialization = materialization_fixture(scenario);
  return mwperf::BuiltSurrogateResultV1{
      {1U, scenario.request.request_digest().value(),
       scenario.provider.identity(), report},
      materialization.artifact.value()};
}

[[nodiscard]] std::vector<mwperf::KernelAccess> all_access_fixtures(
    std::atomic<unsigned>& calls) {
  const mwperf::CodecIdentityV1 state_codec{"c16.state", 1U};
  const mwperf::CodecIdentityV1 result_codec{"c16.result", 1U};
  const mwperf::CodecIdentityV1 mark_codec{"c16.mark", 1U};
  const mwperf::TransitionKernelAccessShapeV1 row_shape{
      state_codec, state_codec, {mark_codec}, 8U, std::nullopt};
  const auto row = [&calls](const mwperf::CanonicalRuntimeValueV1&) {
    calls.fetch_add(1U);
    return mwperf::Result<std::vector<mwperf::KernelRowAtomV1>>::success({});
  };
  const auto sampler = [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                                mwperf::DeterministicRng&) {
    calls.fetch_add(1U);
    return mwperf::Result<mwperf::KernelTransitionV1>::success(
        {state, {mwperf::CanonicalRuntimeValueV1{
                    {"c16.mark", 1U}, {std::byte{0x01}}}}});
  };
  const auto transform =
      [&calls](const mwperf::RuntimeDecoderIdV1&,
               const mwperf::CanonicalRuntimeValueV1&,
               const mwperf::ExactRational&) {
        calls.fetch_add(1U);
        return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
            {{"c16.result", 1U}, {std::byte{0x01}}});
      };
  const auto analytic =
      [&calls](const mwperf::CanonicalRuntimeValueV1&) {
        calls.fetch_add(1U);
        return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
            {{"c16.result", 1U}, {std::byte{0x01}}});
      };
  const auto residence =
      [&calls, state_codec, mark_codec](
          const mwperf::CanonicalRuntimeValueV1& state,
          mwperf::DeterministicRng&) {
        calls.fetch_add(1U);
        return mwperf::Result<mwperf::GeneratedResidenceWordV1>::success(
            {mwperf::BigNat{1U},
             {{state,
               {state, {{mark_codec, {std::byte{0x01}}}}}}},
             {state_codec, {std::byte{0x02}}},
             {state_codec, {std::byte{0x03}}}});
      };
  const auto direct = [&calls](const mwperf::CanonicalRuntimeValueV1&) {
    calls.fetch_add(1U);
    return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
        {{"c16.result", 1U}, {std::byte{0x01}}});
  };
  mwperf::RawDirectDecoderDomainV1 direct_domain{
      {mwperf::ExactMetricDecoderKeyV1(label("c16.direct")),
       mwperf::StationaryThroughputParametersV1{}},
      digest_of("c16.request-domain"), digest_of("c16.build-request"),
      digest_of("c16.target-selection"), digest_of("c16.ordered-targets"),
      digest_of("c16.selection"), digest_of("c16.configured-arrival"),
      digest_of("c16.accepted-contract"), {"c16.request", 1U},
      result_codec};
  auto direct_encoder = fixed_direct_encoder(direct_domain.request_codec);
  auto direct_validator = direct_result_validator(
      direct_domain.metric_domain.decoder_key, direct_domain.result_codec);

  std::vector<mwperf::KernelAccess> accesses;
  accesses.emplace_back(mwperf::FiniteEnumeratedRowAccess(row_shape, row));
  accesses.emplace_back(mwperf::SparseRowAccess(row_shape, row));
  accesses.emplace_back(mwperf::NormalizedConditionalSamplerAccess(
      {state_codec, state_codec, {mark_codec}, std::nullopt, std::nullopt},
      sampler));
  accesses.emplace_back(mwperf::AnalyticTransformAccess(
      {state_codec, result_codec},
      {mwperf::RuntimeDecoderIdV1(label("c16.decoder"))}, transform));
  accesses.emplace_back(mwperf::FiniteParameterAnalyticFamilyAccess(
      {state_codec, result_codec},
      {"c16.family", 1U, {"c16.parameters", 1U}, {"c16.domain", 1U}},
      analytic));
  accesses.emplace_back(mwperf::ProceduralResidenceGeneratorAccess(
      {state_codec, state_codec, state_codec, state_codec, {mark_codec}, 8U},
      {mwperf::KernelOperationIdV1(label("c16.residence.operation")), 1U,
       {"c16.event", 1U}},
      true, residence));
  accesses.emplace_back(mwperf::RawDirectDecoderAccess(
      std::move(direct_domain), std::move(direct_encoder), direct,
      std::move(direct_validator)));
  return accesses;
}

[[nodiscard]] std::string failure_code(
    const mwperf::ProviderExecutionOutcome& outcome) {
  const auto* failure = std::get_if<mwperf::FailedProviderExecution>(&outcome);
  REQUIRE(failure != nullptr);
  return failure->diagnostic.code;
}

[[nodiscard]] mwperf::AuditedFrameworkBindingsV1 audited_bindings(
    const BoundScenario& scenario,
    const mwperf::Digest256& normalized_requirements_digest,
    std::optional<mwperf::ExactMetricDecoderDomainV1> direct_domain =
        std::nullopt) {
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          scenario.view.target_selection().ordered_targets);
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(ordered_target_digest);
  REQUIRE(selection_digest);
  return {scenario.view.fingerprints(),
          scenario.view.canonical_digest(),
          digest_of("c16.exact-state-schema"),
          digest_of("c16.reduced-state-schema"),
          digest_of("c16.descriptor"),
          digest_of("c16.access"),
          scenario.contract.contract_digest(),
          normalized_requirements_digest,
          std::move(ordered_target_digest).value(),
          std::move(selection_digest).value(),
          scenario.request.request_digest().value(),
          std::move(direct_domain)};
}

[[nodiscard]] mwperf::Result<mwperf::AuditedCompiledFramework>
audited_framework(const BoundScenario& scenario,
                  const mwperf::Digest256& normalized_requirements_digest,
                  mwperf::ReducedInitialMapperV1 mapper = {}) {
  const mwperf::CodecIdentityV1 codec{"c16.reduced-state", 1U};
  const auto exact_state_schema = digest_of("c16.exact-state-schema");
  const auto reduced_state_schema = digest_of("c16.reduced-state-schema");
  auto selection_result =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_result);
  const auto selection = std::move(selection_result).value();
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
  if (!mapper) {
    mapper = [codec, exact_state_schema, reduced_state_schema, selection,
              support](const mwperf::SelectionSpec&,
                       const std::optional<mwperf::InitialPhysicalLaw>&) {
      auto mass = mwperf::ProbabilityMass::exact_rational(
          mwperf::ExactRational::one(), true);
      if (!mass) {
        return mwperf::Result<mwperf::ReducedInitialLawCandidateV1>::failure(
            mass.error());
      }
      return mwperf::Result<mwperf::ReducedInitialLawCandidateV1>::success(
          {codec,
           exact_state_schema,
           reduced_state_schema,
           selection,
           support,
           {{{codec,
              {std::byte{0x4e}, std::byte{0x00}, std::byte{0x48},
               std::byte{0x00}, std::byte{0x5a}, std::byte{0x00}}},
             std::move(mass).value(), std::nullopt}}});
    };
  }
  return mwperf::testing::C16FixtureAuditedMint::framework(
      audited_bindings(scenario, normalized_requirements_digest),
      scenario.view.target_selection(), codec, support,
      {mwperf::SelectionKindV1::stationary_unique,
       digest_of("c16.stationary-unique-authority")},
      std::move(mapper),
      [exact_state_schema](const mwperf::ResolvedInstance&,
                           const mwperf::Digest256& supplied) {
        if (supplied != exact_state_schema) {
          return mwperf::Result<void>::failure(
              mwperf::testing::c16_fixture_detail::fixture_error(
                  "c16.fixture.exact_state_schema",
                  "the fixture received a foreign exact-state schema"));
        }
        return mwperf::Result<void>::success();
      },
      [codec](const mwperf::ReducedStateV1& state) {
        if (state.codec != codec) {
          return mwperf::Result<void>::failure(
              mwperf::testing::c16_fixture_detail::fixture_error(
                  "c16.fixture.reduced_state_domain",
                  "the fixture reduced state used a foreign codec"));
        }
        return mwperf::Result<void>::success();
      },
      [](std::size_t, const mwperf::InitialPhysicalAtom&,
         const mwperf::ReducedStateV1&) {
        return mwperf::Result<void>::success();
      });
}

[[nodiscard]] mwperf::Result<mwperf::AuditedCompiledFramework>
direct_audited_framework(
    const mwperf::FrameworkProblemView& view,
    const mwperf::Digest256& normalized_requirements_digest,
    const mwperf::ExactMetricDecoderDomainV1& decoder_domain) {
  const mwperf::CodecIdentityV1 codec{"c16.direct.reduced-state", 1U};
  const auto exact_state_schema = digest_of("c16.direct.exact-state-schema");
  const auto reduced_state_schema =
      digest_of("c16.direct.reduced-state-schema");
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          view.target_selection().ordered_targets);
  auto selection_result =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          view.analysis_selection());
  REQUIRE(ordered_target_digest);
  REQUIRE(selection_result);
  const auto selection = std::move(selection_result).value();
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
  mwperf::AuditedFrameworkBindingsV1 bindings{
      view.fingerprints(),
      view.canonical_digest(),
      exact_state_schema,
      reduced_state_schema,
      digest_of("c16.direct.descriptor"),
      digest_of("c16.direct.access"),
      digest_of("c16.direct.contract"),
      normalized_requirements_digest,
      std::move(ordered_target_digest).value(),
      selection,
      digest_of("c16.direct.build-request"),
      decoder_domain};
  return mwperf::testing::C16FixtureAuditedMint::framework(
      std::move(bindings), view.target_selection(), codec, support,
      {mwperf::SelectionKindV1::stationary_unique,
       digest_of("c16.direct.stationary-unique-authority")},
      [codec, exact_state_schema, reduced_state_schema, selection,
       support](const mwperf::SelectionSpec&,
                const std::optional<mwperf::InitialPhysicalLaw>&) {
        auto mass = mwperf::ProbabilityMass::exact_rational(
            mwperf::ExactRational::one(), true);
        if (!mass) {
          return mwperf::Result<
              mwperf::ReducedInitialLawCandidateV1>::failure(mass.error());
        }
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            {codec,
             exact_state_schema,
             reduced_state_schema,
             selection,
             support,
             {{{codec, {std::byte{0x01}}}, std::move(mass).value(),
               std::nullopt}}});
      },
      [exact_state_schema](const mwperf::ResolvedInstance&,
                           const mwperf::Digest256& supplied) {
        if (supplied != exact_state_schema) {
          return mwperf::Result<void>::failure(
              mwperf::testing::c16_fixture_detail::fixture_error(
                  "c16.fixture.direct_exact_state_schema",
                  "the fixture received a foreign exact-state schema"));
        }
        return mwperf::Result<void>::success();
      },
      [](const mwperf::ReducedStateV1&) {
        return mwperf::Result<void>::success();
      },
      [](std::size_t, const mwperf::InitialPhysicalAtom&,
         const mwperf::ReducedStateV1&) {
        return mwperf::Result<void>::success();
      });
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1 f05_role_requirement(
    const mwperf::MetricSupportRoleV1 role,
    const mwperf::MetricTargetScopeV1 target_scope,
    const mwperf::MetricResultScopeV1 result_scope,
    const mwperf::MetricEvidenceScopeV1 evidence_scope) {
  const auto* schema = mwperf::metric_support_role_schema_v1(role);
  REQUIRE(schema != nullptr);
  std::vector<mwperf::MetricRoleRelationRequirementV1> role_relations;
  const auto append_roles =
      [&role_relations](const std::uint32_t mask,
                        const mwperf::MetricRoleRelationKindV1 relation) {
        for (const auto candidate : mwperf::all_metric_support_roles_v1()) {
          if ((mask & mwperf::metric_support_role_bit_v1(candidate)) != 0U) {
            role_relations.push_back({relation, candidate});
          }
        }
      };
  append_roles(schema->required_lineage_parent_roles,
               mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_roles(schema->required_binding_roles,
               mwperf::MetricRoleRelationKindV1::binding);
  append_roles(schema->required_evidence_roles,
               mwperf::MetricRoleRelationKindV1::evidence);
  append_roles(schema->required_subject_roles,
               mwperf::MetricRoleRelationKindV1::subject);

  std::vector<mwperf::InternalRelationRequirementV1> internal_relations;
  const auto append_internal =
      [&internal_relations](const std::uint64_t mask,
                            const mwperf::MetricRoleRelationKindV1 relation) {
        const auto last = static_cast<std::uint8_t>(
            mwperf::InternalReferencePurposeV1::error_object);
        for (std::uint8_t index = 0U; index <= last; ++index) {
          const auto purpose =
              static_cast<mwperf::InternalReferencePurposeV1>(index);
          if ((mask &
               mwperf::internal_reference_purpose_bit_v1(purpose)) != 0U) {
            internal_relations.push_back({relation, purpose});
          }
        }
      };
  append_internal(schema->required_internal_lineage_parents,
                  mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_internal(schema->required_internal_bindings,
                  mwperf::MetricRoleRelationKindV1::binding);
  append_internal(schema->required_internal_evidence,
                  mwperf::MetricRoleRelationKindV1::evidence);
  append_internal(schema->required_internal_subjects,
                  mwperf::MetricRoleRelationKindV1::subject);
  return {role, target_scope, result_scope, evidence_scope,
          std::move(role_relations), std::move(internal_relations)};
}

[[nodiscard]] mwperf::MetricSupportManifest f05_direct_manifest(
    const BoundScenario& scenario,
    const mwperf::ExactMetricDecoderKeyV1& decoder_key) {
  auto clause = scenario.contract.structural_manifest().clauses().front();
  clause.parameter_domain = mwperf::ExactMetricDecoderDomainV1{
      decoder_key, mwperf::metric_request_parameters(scenario.metric_request)};
  clause.payload_class =
      {mwperf::PayloadClassTagV1::direct_metric_payload_v1, 1U};
  clause.semantic = mwperf::SemanticTagV1::direct_metric_decoder;
  clause.runtime_access = mwperf::RuntimeAccessTagV1::direct_metric_decoder;
  clause.solver_route = mwperf::SolverRegimeV1::direct;
  clause.requested_accuracy = mwperf::DirectExactAccuracyV1{};
  clause.required_roles = {
      f05_role_requirement(
          mwperf::MetricSupportRoleV1::deployed_payload,
          mwperf::MetricTargetScopeV1::payload_targets,
          mwperf::MetricResultScopeV1::surrogate_law,
          mwperf::MetricEvidenceScopeV1::none),
      f05_role_requirement(
          mwperf::MetricSupportRoleV1::direct_metric_value,
          mwperf::MetricTargetScopeV1::exact_request_targets,
          mwperf::MetricResultScopeV1::surrogate_law,
          mwperf::MetricEvidenceScopeV1::deployed_surrogate_law),
      f05_role_requirement(
          mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
          mwperf::MetricTargetScopeV1::exact_request_targets,
          mwperf::MetricResultScopeV1::not_a_metric_result,
          mwperf::MetricEvidenceScopeV1::validity_or_lift)};
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return mwperf::metric_support_role_rank_v1(left.role) <
                     mwperf::metric_support_role_rank_v1(right.role);
            });
  auto manifest =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((manifest ? std::string{}
                 : manifest.error().code + ": " + manifest.error().message));
  REQUIRE(manifest);
  return std::move(manifest).value();
}

[[nodiscard]] mwperf::PlugDescriptor f05_descriptor(
    const BoundScenario& scenario, const mwperf::SemanticTagV1 semantic,
    const mwperf::RuntimeAccessTagV1 access,
    const mwperf::PayloadClassTagV1 payload_class,
    const mwperf::Digest256& manifest_digest) {
  auto core = scenario.contract.descriptor_core();
  core.semantic = semantic;
  core.runtime_access = access;
  core.payload_class = {payload_class, 1U};
  core.metric_support_manifest_digest = manifest_digest;
  auto core_digest = mwperf::canonical_plug_descriptor_core_digest_v1(core);
  REQUIRE(core_digest);
  core.core_digest = std::move(core_digest).value();
  auto descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  if (access == mwperf::RuntimeAccessTagV1::finite_enumerated_row ||
      access == mwperf::RuntimeAccessTagV1::sparse_row ||
      access == mwperf::RuntimeAccessTagV1::normalized_conditional_sampler) {
    std::vector<mwperf::RuntimeFieldIdV1> ordered_fields;
    ordered_fields.reserve(descriptor.state_fields.size());
    for (const auto& field : descriptor.state_fields) {
      ordered_fields.push_back(field.id);
    }
    descriptor.transition_state_schema = mwperf::TransitionStateSchemaV1{
        {"c16.f05.conditioning-state", 1U},
        {"c16.f05.successor-state", 1U}, std::move(ordered_fields)};
  }
  reseal_descriptor(descriptor);
  return descriptor;
}

[[nodiscard]] mwperf::RuntimeOperationIdentityV1 f05_operation(
    const std::string_view name) {
  return {mwperf::RuntimeOperationIdV1(label(std::string(name))), 1U};
}

[[nodiscard]] mwperf::TemporalEventContractV1 f05_event_contract(
    const mwperf::EventContractKindV1 kind =
        mwperf::EventContractKindV1::romr_residence) {
  return {
      kind,
      f05_operation("c16.f05.event.generator"),
      f05_operation("c16.f05.event.entry"),
      f05_operation("c16.f05.event.stopping"),
      f05_operation("c16.f05.event.reentry"),
      f05_operation("c16.f05.event.predecision"),
      f05_operation("c16.f05.event.completed-edge"),
      mwperf::EventFiltrationV1::generated_slot_natural_filtration,
      {"c16.f05.event.continuation", 1U},
      {"c16.f05.event.entrance", 1U},
      {"c16.f05.event.terminal", 1U},
      {"c16.f05.event.entrance", 1U},
      {"c16.f05.event.indicator", 1U},
      {"c16.f05.event.predecision-projection", 1U},
      {"c16.f05.event.completed-edge-projection", 1U},
      true,
      true,
      true,
      false};
}

[[nodiscard]] mwperf::TemporalEventOperationsV1 f05_event_operations(
    const mwperf::TemporalEventContractV1& event,
    std::atomic<unsigned>& calls) {
  return {
      mwperf::EventEntryInitializerOperationV1(
          {event.entry_initializer_operation, event.entrance_space,
           event.continuation_space},
          [&calls](const mwperf::CanonicalRuntimeValueV1& value) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                value);
          }),
      mwperf::EventStoppingIndicatorOperationV1(
          {event.stopping_indicator_operation, event.stopping_filtration,
           event.continuation_space, event.stopping_indicator},
          [&calls](const mwperf::CanonicalRuntimeValueV1& value) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                value);
          }),
      mwperf::EventTerminalReentryOperationV1(
          {event.terminal_reentry_operation, event.terminal_space,
           event.continuation_space, event.reentry_space},
          [&calls](const mwperf::EventTerminalReentryInputV1& input) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                input.successor_state);
          }),
      mwperf::EventPredecisionProjectionOperationV1(
          {event.predecision_projection_operation, event.entrance_space,
           event.continuation_space, event.predecision_projection},
          [&calls](const mwperf::EventPredecisionProjectionInputV1& input) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                input.current_predecision_state);
          }),
      mwperf::EventCompletedEdgeProjectionOperationV1(
          {event.completed_edge_projection_operation,
           event.predecision_projection, event.continuation_space,
           event.completed_edge_projection},
          [&calls](const mwperf::EventCompletedEdgeProjectionInputV1& input) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
                input.predecision_projection);
          })};
}

[[nodiscard]] mwperf::PortablePayloadContextV1 f05_payload_context(
    const mwperf::PortablePlugPayload& payload) {
  return std::visit([](const auto& active) { return active.context; },
                    payload.value());
}

struct F05DirectFixture final {
  mwperf::MetricSupportManifest manifest;
  mwperf::PortablePlugPayload payload;
  mwperf::RawDirectDecoderDomainV1 domain;
};

[[nodiscard]] F05DirectFixture f05_direct_fixture(
    const BoundScenario& scenario,
    const MaterializationFixture& materialization,
    const mwperf::ExactMetricDecoderKeyV1& decoder_key) {
  auto manifest = f05_direct_manifest(scenario, decoder_key);
  const auto& clause = manifest.clauses().front();
  auto context = f05_payload_context(materialization.payload);
  context.payload_class =
      {mwperf::PayloadClassTagV1::direct_metric_payload_v1, 1U};
  context.semantic = mwperf::SemanticTagV1::direct_metric_decoder;
  context.runtime_access = mwperf::RuntimeAccessTagV1::direct_metric_decoder;
  const auto ordered_targets = clause.ordered_targets;
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          ordered_targets);
  REQUIRE(ordered_target_digest);
  const auto request_digest =
      materialization.artifact.validation_bindings().request_digest;
  const auto normalized_request = digest_of("c16.f05.normalized-request");
  const auto target_selection = digest_of("c16.f05.target-selection");
  const auto configured_arrival = digest_of("c16.f05.configured-arrival");
  const auto accepted_contract = scenario.contract.contract_digest();
  mwperf::DirectMetricValueV1 value{
      object_ref("c16.f05.direct-value"),
      clause.clause_id,
      ordered_targets,
      scalar(1, 2),
      request_digest,
      normalized_request,
      target_selection,
      configured_arrival,
      accepted_contract,
      {mwperf::SelectionKindV1::stationary_unique},
      {},
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::DirectMetricValidityBasisV1::exact_closed_form,
      {}};
  mwperf::PortableDirectMetricPayloadV1 direct_payload{
      std::move(context), {1U, {std::move(value)}}};
  mwperf::RawDirectDecoderDomainV1 domain{
      {decoder_key, mwperf::metric_request_parameters(scenario.metric_request)},
      normalized_request,
      request_digest,
      target_selection,
      std::move(ordered_target_digest).value(),
      materialization.artifact.validation_bindings()
          .analysis_selection_digest,
      configured_arrival,
      accepted_contract,
      {"mwperf.c16.direct_metric_request", 1U},
      {"mwperf.c16.direct_metric_value", 1U}};
  return {std::move(manifest),
          Factory::portable_payload(std::move(direct_payload)),
          std::move(domain)};
}

[[nodiscard]] mwperf::Result<mwperf::ValidatedSurrogatePlug> f05_mint(
    mwperf::PlugDescriptor descriptor, mwperf::SurrogatePlug plug,
    const MaterializationFixture& materialization,
    const mwperf::Digest256& accepted_contract_digest,
    mwperf::MetricSupportManifest manifest) {
  return mwperf::testing::C16FixtureAuditedMint::validated_plug(
      std::move(descriptor), std::move(plug),
      materialization.artifact.validation_bindings(),
      accepted_contract_digest, std::move(manifest));
}

[[nodiscard]] mwperf::PortablePayloadContextV1 f05_semantic_context(
    const MaterializationFixture& materialization,
    const mwperf::SemanticTagV1 semantic,
    const mwperf::RuntimeAccessTagV1 access,
    const mwperf::PayloadClassTagV1 payload_class,
    std::vector<mwperf::QueueId> targets) {
  auto context = f05_payload_context(materialization.payload);
  context.payload_class = {payload_class, 1U};
  context.semantic = semantic;
  context.runtime_access = access;
  context.ordered_deployed_targets = std::move(targets);
  context.payload_identity = object_ref(
      "c16.f05.semantic-payload." +
      std::to_string(static_cast<unsigned>(semantic)));
  context.payload_digest = digest_of(
      "c16.f05.semantic-payload-digest." +
      std::to_string(static_cast<unsigned>(semantic)));
  context.family_evidence.clear();
  context.scoped_evidence.clear();
  return context;
}

[[nodiscard]] mwperf::FiniteLawTableAlternativeV1 f05_finite_table(
    const mwperf::SemanticTagV1 semantic,
    const std::span<const mwperf::QueueId> targets) {
  const auto law = object_ref("c16.f05.finite-law");
  const auto state = label("c16.f05.state.0");
  const auto mark = label("c16.f05.mark.0");
  const mwperf::FiniteLawAtomV1 atom{
      state, {mark}, scalar(1, 1), std::nullopt};
  const auto row = [&](const std::string& id,
                       const mwperf::FiniteRowConditioningStageV1 stage) {
    return mwperf::FiniteLawRowV1{label(id), state, stage, {atom}};
  };
  switch (semantic) {
    case mwperf::SemanticTagV1::stationary_marked_edge:
      return mwperf::StationaryMarkedEdgeTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::dense,
          {row("c16.f05.stationary-row",
               mwperf::FiniteRowConditioningStageV1::stationary_edge)},
          {"queue.big_nat", 1U},
          {"arrival.phase", 1U},
          {"service.bit", 1U},
          {"edge.mark", 1U},
          digest_of("c16.f05.stationary-conditioning")};
    case mwperf::SemanticTagV1::staged_opportunity_flux_law:
      return mwperf::StagedOpportunityFluxTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::sparse,
          {state},
          {state},
          {row("c16.f05.prearrival-row",
               mwperf::FiniteRowConditioningStageV1::prearrival)},
          {row("c16.f05.postarrival-row",
               mwperf::FiniteRowConditioningStageV1::postarrival)},
          digest_of("c16.f05.arrival"),
          {"arrival.innovation", 1U},
          object_ref("c16.f05.deterministic-update"),
          object_ref("c16.f05.retained-coordinate"),
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival,
           mwperf::MetricRevealStageV1::completed_edge}};
    case mwperf::SemanticTagV1::temporal_one_slot_continuation:
      return mwperf::TemporalContinuationTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::dense,
          {row("c16.f05.continuation-row",
               mwperf::FiniteRowConditioningStageV1::one_slot_current)},
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival,
           mwperf::MetricRevealStageV1::completed_edge},
          {"arrival.phase", 1U},
          std::nullopt};
    case mwperf::SemanticTagV1::romr_residence_word_law: {
      const mwperf::ExplicitOrderedWordV1 word{
          state, mwperf::BigNat{1U}, {mark}, label("c16.f05.terminal"),
          state, scalar(1, 1)};
      return mwperf::RomrResidenceWordTableV1{
          1U,
          law,
          "c16.f05.event",
          {state},
          {state},
          {mark},
          std::vector<mwperf::ExplicitOrderedWordV1>{word},
          scalar(0, 1),
          {object_ref("c16.f05.termination")}};
    }
    case mwperf::SemanticTagV1::stopped_path_law: {
      const auto continuation = row(
          "c16.f05.stopped-continuation",
          mwperf::FiniteRowConditioningStageV1::stopped_continuation);
      const mwperf::FinitePredictiveStoppingTablesV1 predictive{
          {continuation}, {continuation}, {continuation}};
      return mwperf::StoppedPathTableV1{
          1U,
          law,
          "c16.f05.stop",
          {state},
          {state},
          {mark},
          false,
          predictive,
          scalar(0, 1),
          {object_ref("c16.f05.absorption")}};
    }
    case mwperf::SemanticTagV1::coupled_target_schedule_law: {
      std::vector<mwperf::BigNat> zero_backlogs(
          targets.size(), mwperf::BigNat{0U});
      std::vector<std::uint8_t> departures(targets.size(), 0U);
      const mwperf::CommonScheduleRealizationV1 common{
          std::vector<mwperf::QueueId>(targets.begin(), targets.end()),
          zero_backlogs,
          zero_backlogs,
          zero_backlogs,
          std::move(departures),
          true,
          object_ref("c16.f05.schedule-projection")};
      const mwperf::FiniteLawRowV1 common_row{
          label("c16.f05.common-row"),
          state,
          mwperf::FiniteRowConditioningStageV1::common_schedule,
          {{state, {mark}, scalar(1, 1), common}}};
      return mwperf::CoupledCommonScheduleTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::dense,
          {common_row},
          digest_of("c16.f05.constraint-geometry"),
          digest_of("c16.f05.tie-phase-arrival")};
    }
    case mwperf::SemanticTagV1::scalar_backlog_response:
    case mwperf::SemanticTagV1::direct_metric_decoder:
    case mwperf::SemanticTagV1::response_envelope_law:
      break;
  }
  FAIL("non-finite semantic requested from finite-table fixture");
  return mwperf::StationaryMarkedEdgeTableV1{
      1U, law, mwperf::FiniteTableStorageV1::dense, {},
      {"queue.big_nat", 1U}, {"arrival.phase", 1U},
      {"service.bit", 1U}, {"edge.mark", 1U},
      digest_of("c16.f05.unreachable")};
}

[[nodiscard]] mwperf::PortablePlugPayload f05_finite_payload(
    const MaterializationFixture& materialization,
    const mwperf::SemanticTagV1 semantic,
    const mwperf::RuntimeAccessTagV1 access,
    std::vector<mwperf::QueueId> targets) {
  const std::size_t coordinate_count =
      semantic == mwperf::SemanticTagV1::coupled_target_schedule_law
          ? targets.size()
          : 1U;
  std::vector<mwperf::PortableScientificScalar> coordinates;
  coordinates.reserve(coordinate_count);
  for (std::size_t index = 0U; index < coordinate_count; ++index) {
    coordinates.push_back(scalar(0, 1));
  }
  auto table = f05_finite_table(semantic, targets);
  auto context = f05_semantic_context(
      materialization, semantic, access,
      mwperf::PayloadClassTagV1::finite_law_tables_v1, targets);
  return Factory::portable_payload(mwperf::PortableFiniteLawTablesV1{
      std::move(context),
      {1U,
       std::move(targets),
       semantic,
       access,
       digest_of("c16.f05.configured-arrival"),
       materialization.artifact.validation_bindings()
           .analysis_selection_digest,
       {{label("c16.f05.state.0"), coordinates}},
       {{label("c16.f05.mark.0"), std::move(coordinates)}},
       std::move(table)}});
}

[[nodiscard]] mwperf::PortablePlugPayload f05_response_envelope_payload(
    const MaterializationFixture& materialization) {
  const auto& response =
      std::get<mwperf::PortableThreeBinScalarResponseV1>(
          materialization.payload.value());
  auto context = f05_semantic_context(
      materialization, mwperf::SemanticTagV1::response_envelope_law,
      mwperf::RuntimeAccessTagV1::analytic_transform,
      mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
      {response.deployed_target});
  return Factory::portable_payload(mwperf::PortableResponseEnvelopeEvidenceV1{
      std::move(context),
      {1U,
       {response.deployed_target},
       mwperf::MetricResultScopeV1::response_envelope,
       mwperf::MetricEvidenceScopeV1::validity_or_lift,
       response.normalized_record,
       response.normalized_record,
       response.selected_product,
       response.selected_product,
       object_ref("c16.f05.envelope-comparison"),
       {mwperf::deployed_response_product_identity_v1(
           response.selected_product)},
       true,
       response.selected_product}});
}

[[nodiscard]] mwperf::PlugDescriptor f05_coupled_descriptor(
    const BoundScenario& scenario, const mwperf::Digest256& manifest_digest) {
  auto core = scenario.contract.descriptor_core();
  core.semantic = mwperf::SemanticTagV1::coupled_target_schedule_law;
  core.runtime_access = mwperf::RuntimeAccessTagV1::finite_enumerated_row;
  core.payload_class =
      {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U};
  core.deployed_targets = {queue_id("q0"), queue_id("q1")};
  core.target_coupling = mwperf::TargetCouplingV1::common_schedule_projection;
  core.marks = {{mwperf::MetricMarkKindV1::schedule_projection,
                 mwperf::MetricRevealStageV1::decision,
                 {"schedule.projection", 1U},
                 ""}};
  core.metric_support_manifest_digest = manifest_digest;
  auto core_digest = mwperf::canonical_plug_descriptor_core_digest_v1(core);
  REQUIRE(core_digest);
  core.core_digest = std::move(core_digest).value();
  auto descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  std::vector<mwperf::RuntimeFieldIdV1> fields;
  fields.reserve(descriptor.state_fields.size());
  for (const auto& field : descriptor.state_fields) {
    fields.push_back(field.id);
  }
  descriptor.transition_state_schema = mwperf::TransitionStateSchemaV1{
      {"c16.f05.conditioning-state", 1U},
      {"c16.f05.successor-state", 1U},
      std::move(fields)};
  reseal_descriptor(descriptor);
  return descriptor;
}

[[nodiscard]] mwperf::MetricSupportManifest f05_semantic_manifest(
    const BoundScenario& scenario, const mwperf::SemanticTagV1 semantic,
    const mwperf::RuntimeAccessTagV1 access,
    const mwperf::PayloadClassTagV1 payload_class) {
  auto clause = scenario.contract.structural_manifest().clauses().front();
  clause.semantic = semantic;
  clause.runtime_access = access;
  clause.payload_class = {payload_class, 1U};
  if (semantic == mwperf::SemanticTagV1::coupled_target_schedule_law) {
    clause.metric_kind = mwperf::MetricKindV1::joint_backlog_covariance;
    clause.parameter_domain = mwperf::ExactMetricParameterSetV1{{
        mwperf::MetricRequestParametersV1{
            mwperf::JointBacklogCovarianceParametersV1{}}}};
    clause.ordered_targets = {queue_id("q0"), queue_id("q1")};
    clause.target_coupling =
        mwperf::TargetCouplingV1::common_schedule_projection;
    clause.marks = {{mwperf::MetricMarkKindV1::schedule_projection,
                     mwperf::MetricRevealStageV1::decision,
                     {"schedule.projection", 1U},
                     ""}};
  }
  const auto primary_role = [&] {
    switch (semantic) {
      case mwperf::SemanticTagV1::stationary_marked_edge:
        return mwperf::MetricSupportRoleV1::stationary_marked_edge_law;
      case mwperf::SemanticTagV1::staged_opportunity_flux_law:
        return mwperf::MetricSupportRoleV1::staged_opportunity_flux_law;
      case mwperf::SemanticTagV1::temporal_one_slot_continuation:
        return mwperf::MetricSupportRoleV1::temporal_continuation_law;
      case mwperf::SemanticTagV1::romr_residence_word_law:
        return mwperf::MetricSupportRoleV1::residence_word_law;
      case mwperf::SemanticTagV1::stopped_path_law:
        return mwperf::MetricSupportRoleV1::stopped_path_law;
      case mwperf::SemanticTagV1::coupled_target_schedule_law:
        return mwperf::MetricSupportRoleV1::coupled_schedule_law;
      case mwperf::SemanticTagV1::direct_metric_decoder:
        return mwperf::MetricSupportRoleV1::direct_metric_value;
      case mwperf::SemanticTagV1::response_envelope_law:
        return mwperf::MetricSupportRoleV1::response_envelope;
      case mwperf::SemanticTagV1::scalar_backlog_response:
        return mwperf::MetricSupportRoleV1::deployed_response;
    }
    return mwperf::MetricSupportRoleV1::deployed_payload;
  }();
  if (semantic == mwperf::SemanticTagV1::response_envelope_law) {
    clause.result_scope = mwperf::MetricResultScopeV1::response_envelope;
    clause.error_promise = {
        mwperf::StructuralErrorFormV1::validity_witness,
        mwperf::MetricEvidenceScopeV1::validity_or_lift,
        std::nullopt};
  }
  std::vector<mwperf::MetricSupportRoleRequirementV1> roles;
  const auto add_role = [&](const auto& self,
                            const mwperf::MetricSupportRoleV1 role) -> void {
    if (std::any_of(roles.begin(), roles.end(), [role](const auto& value) {
          return value.role == role;
        })) {
      return;
    }
    mwperf::MetricTargetScopeV1 target_scope =
        mwperf::MetricTargetScopeV1::ordered_metric_targets;
    mwperf::MetricResultScopeV1 result_scope =
        mwperf::MetricResultScopeV1::surrogate_law;
    mwperf::MetricEvidenceScopeV1 evidence_scope =
        mwperf::MetricEvidenceScopeV1::deployed_surrogate_law;
    switch (role) {
      case mwperf::MetricSupportRoleV1::deployed_payload:
        target_scope = mwperf::MetricTargetScopeV1::payload_targets;
        result_scope = clause.result_scope;
        evidence_scope = mwperf::MetricEvidenceScopeV1::none;
        break;
      case mwperf::MetricSupportRoleV1::direct_metric_value:
        target_scope = mwperf::MetricTargetScopeV1::exact_request_targets;
        break;
      case mwperf::MetricSupportRoleV1::stability_certificate:
        result_scope = mwperf::MetricResultScopeV1::not_a_metric_result;
        evidence_scope =
            mwperf::MetricEvidenceScopeV1::deployed_surrogate_law;
        break;
      case mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence:
        result_scope = mwperf::MetricResultScopeV1::not_a_metric_result;
        evidence_scope = mwperf::MetricEvidenceScopeV1::validity_or_lift;
        break;
      case mwperf::MetricSupportRoleV1::response_envelope:
        target_scope =
            mwperf::MetricTargetScopeV1::deployed_singleton_target;
        result_scope = mwperf::MetricResultScopeV1::response_envelope;
        evidence_scope = mwperf::MetricEvidenceScopeV1::validity_or_lift;
        break;
      case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
        target_scope =
            mwperf::MetricTargetScopeV1::deployed_singleton_target;
        result_scope = mwperf::MetricResultScopeV1::not_a_metric_result;
        evidence_scope =
            mwperf::MetricEvidenceScopeV1::raw_static_proposal;
        break;
      case mwperf::MetricSupportRoleV1::response_order_evidence:
        target_scope =
            mwperf::MetricTargetScopeV1::deployed_singleton_target;
        result_scope = mwperf::MetricResultScopeV1::not_a_metric_result;
        break;
      case mwperf::MetricSupportRoleV1::raw_response:
        target_scope =
            mwperf::MetricTargetScopeV1::deployed_singleton_target;
        result_scope = mwperf::MetricResultScopeV1::proposal_raw;
        evidence_scope =
            mwperf::MetricEvidenceScopeV1::raw_static_proposal;
        break;
      default:
        break;
    }
    auto requirement = f05_role_requirement(
        role, target_scope, result_scope, evidence_scope);
    if (role == mwperf::MetricSupportRoleV1::temporal_continuation_law) {
      requirement.internal_relations.push_back(
          {mwperf::MetricRoleRelationKindV1::binding,
           mwperf::InternalReferencePurposeV1::selection_binding});
      std::sort(requirement.internal_relations.begin(),
                requirement.internal_relations.end());
    }
    const auto related = requirement.role_relations;
    roles.push_back(std::move(requirement));
    for (const auto& relation : related) {
      self(self, relation.other_role);
    }
  };
  add_role(add_role, primary_role);
  const bool needs_stability = std::ranges::any_of(
          clause.hypotheses,
          [](const mwperf::HypothesisClaimV1& hypothesis) {
            return hypothesis.kind ==
                       mwperf::HypothesisKindV1::proper_stationary ||
                   hypothesis.kind ==
                       mwperf::HypothesisKindV1::invariant_selected ||
                   hypothesis.kind == mwperf::HypothesisKindV1::stable;
          });
  if (needs_stability) {
    add_role(add_role, mwperf::MetricSupportRoleV1::stability_certificate);
    if (primary_role ==
        mwperf::MetricSupportRoleV1::stationary_marked_edge_law) {
      const auto primary = std::ranges::find_if(
          roles, [primary_role](const auto& requirement) {
            return requirement.role == primary_role;
          });
      REQUIRE(primary != roles.end());
      primary->role_relations.push_back(
          {mwperf::MetricRoleRelationKindV1::evidence,
           mwperf::MetricSupportRoleV1::stability_certificate});
    }
  }
  std::sort(roles.begin(), roles.end(), [](const auto& left,
                                          const auto& right) {
    return mwperf::metric_support_role_rank_v1(left.role) <
           mwperf::metric_support_role_rank_v1(right.role);
  });
  clause.required_roles = std::move(roles);
  auto manifest =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  INFO((manifest ? std::string{}
                 : manifest.error().code + ": " + manifest.error().message));
  REQUIRE(manifest);
  return std::move(manifest).value();
}

}  // namespace

TEST_CASE("C16 exposes closed and strongly typed boundary alternatives",
          "[c16][unit]") {
  STATIC_REQUIRE(std::variant_size_v<mwperf::SurrogatePlug> == 9U);
  STATIC_REQUIRE(std::variant_size_v<mwperf::KernelAccess> == 7U);
  STATIC_REQUIRE(std::variant_size_v<mwperf::ProviderExecutionOutcome> == 2U);
  STATIC_REQUIRE(!std::same_as<mwperf::SurrogateId,
                               mwperf::SurrogateVersion>);
  STATIC_REQUIRE(!std::is_default_constructible_v<
                 mwperf::AuditedCompiledFramework>);
  STATIC_REQUIRE(!std::is_copy_constructible_v<
                 mwperf::AuditedCompiledFramework>);
  STATIC_REQUIRE(!std::is_default_constructible_v<mwperf::DirectMetricAccess>);
  STATIC_REQUIRE(!std::is_constructible_v<mwperf::ProbabilityMass, double>);
  STATIC_REQUIRE(
      !std::is_constructible_v<mwperf::ProbabilityMass, long double>);
  STATIC_REQUIRE(
      !DirectMetricExecutionAccess<mwperf::RawDirectDecoderAccess>);
  STATIC_REQUIRE(DirectMetricExecutionAccess<mwperf::DirectMetricAccess>);
}

TEST_CASE("C16 constructs every semantic alternative with an exact tag",
          "[c16][unit]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto fixture = materialization_fixture(scenario);
  const auto access =
      mwperf::testing::c16_fixture_detail::scalar_access(
          scenario.contract.descriptor_core());
  const mwperf::CausalSurrogateOperationsV1 causal{
      std::nullopt, std::nullopt, std::nullopt};
  std::vector<mwperf::SurrogatePlug> plugs;
  plugs.emplace_back(
      mwperf::ScalarBacklogResponsePlugV1{fixture.payload, access});
  plugs.emplace_back(
      mwperf::StationaryMarkedEdgePlugV1{fixture.payload, access, causal});
  plugs.emplace_back(
      mwperf::StagedOpportunityFluxPlugV1{fixture.payload, access, causal});
  plugs.emplace_back(mwperf::TemporalOneSlotContinuationPlugV1{
      fixture.payload, access, causal});
  plugs.emplace_back(
      mwperf::RomrResidenceWordPlugV1{fixture.payload, access, causal});
  plugs.emplace_back(
      mwperf::StoppedPathPlugV1{fixture.payload, access, causal});
  plugs.emplace_back(
      mwperf::CoupledTargetSchedulePlugV1{fixture.payload, access, causal});
  plugs.emplace_back(
      mwperf::DirectMetricDecoderPlugV1{fixture.payload, access});
  plugs.emplace_back(mwperf::ResponseEnvelopePlugV1{fixture.payload, access});
  const std::array expected{
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::SemanticTagV1::stationary_marked_edge,
      mwperf::SemanticTagV1::staged_opportunity_flux_law,
      mwperf::SemanticTagV1::temporal_one_slot_continuation,
      mwperf::SemanticTagV1::romr_residence_word_law,
      mwperf::SemanticTagV1::stopped_path_law,
      mwperf::SemanticTagV1::coupled_target_schedule_law,
      mwperf::SemanticTagV1::direct_metric_decoder,
      mwperf::SemanticTagV1::response_envelope_law};
  REQUIRE(plugs.size() == expected.size());
  for (std::size_t index = 0U; index < plugs.size(); ++index) {
    CHECK(mwperf::semantic_tag_v1(plugs[index]) == expected[index]);
  }
}

TEST_CASE("C16 constructs and structurally validates every access alternative",
          "[c16][unit]") {
  std::atomic<unsigned> calls{0U};
  const auto accesses = all_access_fixtures(calls);
  const std::array expected{
      mwperf::RuntimeAccessTagV1::finite_enumerated_row,
      mwperf::RuntimeAccessTagV1::sparse_row,
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler,
      mwperf::RuntimeAccessTagV1::analytic_transform,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      mwperf::RuntimeAccessTagV1::procedural_residence_generator,
      mwperf::RuntimeAccessTagV1::direct_metric_decoder};
  REQUIRE(accesses.size() == expected.size());
  for (std::size_t index = 0U; index < accesses.size(); ++index) {
    INFO(index);
    REQUIRE(mwperf::validate_kernel_access_shape_v1(accesses[index]));
    CHECK(mwperf::runtime_access_tag_v1(accesses[index]) == expected[index]);
  }
  CHECK(calls.load() == 0U);
}

TEST_CASE("C16 F05 validates all seven descriptor-bound access alternatives",
          "[c16][integration][access-matrix]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto materialization = materialization_fixture(scenario);
  const auto scalar_manifest = scenario.contract.structural_manifest();
  const auto scalar_manifest_digest = scalar_manifest.canonical_digest();
  const mwperf::ExactMetricDecoderKeyV1 decoder_key(
      label("c16.f05.decoder"));
  const auto direct_template =
      f05_direct_fixture(scenario, materialization, decoder_key);
  std::atomic<unsigned> calls{0U};

  const auto validate = [&](mwperf::PlugDescriptor descriptor,
                            mwperf::SurrogatePlug plug,
                            mwperf::MetricSupportManifest manifest,
                            const mwperf::RuntimeAccessTagV1 expected) {
    auto minted = f05_mint(
        std::move(descriptor), std::move(plug), materialization,
        scenario.contract.contract_digest(), std::move(manifest));
    REQUIRE(minted);
    auto access = mwperf::validate_kernel_access(minted.value());
    INFO((access ? std::string{}
                 : access.error().code + ": " + access.error().message));
    REQUIRE(access);
    CHECK(mwperf::runtime_access_tag_v1(access.value()) == expected);
    CHECK(calls.load() == 0U);
  };

  for (const auto access_tag :
       {mwperf::RuntimeAccessTagV1::finite_enumerated_row,
        mwperf::RuntimeAccessTagV1::sparse_row}) {
    const char* section_name =
        access_tag == mwperf::RuntimeAccessTagV1::finite_enumerated_row
            ? "finite enumerated row"
            : "sparse row";
    DYNAMIC_SECTION(section_name) {
      auto descriptor = f05_descriptor(
          scenario, mwperf::SemanticTagV1::stationary_marked_edge,
          access_tag, mwperf::PayloadClassTagV1::finite_law_tables_v1,
          scalar_manifest_digest);
      const auto& transition = *descriptor.transition_state_schema;
      const mwperf::TransitionKernelAccessShapeV1 shape{
          transition.conditioning_state_codec,
          transition.successor_state_codec,
          {descriptor.marks.front().c14_mark.codec}, 8U, std::nullopt};
      const auto operation =
          [&calls](const mwperf::CanonicalRuntimeValueV1&) {
            calls.fetch_add(1U);
            return mwperf::Result<
                std::vector<mwperf::KernelRowAtomV1>>::success({});
          };
      mwperf::KernelAccess access =
          access_tag == mwperf::RuntimeAccessTagV1::finite_enumerated_row
              ? mwperf::KernelAccess{
                    mwperf::FiniteEnumeratedRowAccess(shape, operation)}
              : mwperf::KernelAccess{
                    mwperf::SparseRowAccess(shape, operation)};
      mwperf::SurrogatePlug plug = mwperf::StationaryMarkedEdgePlugV1{
          materialization.payload, std::move(access),
          {std::nullopt, std::nullopt, std::nullopt}};
      validate(std::move(descriptor), std::move(plug), scalar_manifest,
               access_tag);
    }
  }

  {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::stationary_marked_edge,
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        scalar_manifest_digest);
    const auto& transition = *descriptor.transition_state_schema;
    mwperf::KernelAccess access = mwperf::NormalizedConditionalSamplerAccess(
        {transition.conditioning_state_codec,
         transition.successor_state_codec,
         {descriptor.marks.front().c14_mark.codec}, std::nullopt,
         std::nullopt},
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              {state, {}});
        });
    mwperf::SurrogatePlug plug = mwperf::StationaryMarkedEdgePlugV1{
        materialization.payload, std::move(access),
        {std::nullopt, std::nullopt, std::nullopt}};
    validate(std::move(descriptor), std::move(plug), scalar_manifest,
             mwperf::RuntimeAccessTagV1::normalized_conditional_sampler);
  }

  {
    const auto analytic_manifest = f05_semantic_manifest(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1);
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
        analytic_manifest.canonical_digest());
    mwperf::KernelAccess access = mwperf::AnalyticTransformAccess(
        {descriptor.state_fields.front().c14_field.codec,
         descriptor.marks.front().c14_mark.codec},
        {descriptor.marks.front().decoder_id},
        [&calls](const mwperf::RuntimeDecoderIdV1&,
                 const mwperf::CanonicalRuntimeValueV1& value,
                 const mwperf::ExactRational&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        });
    mwperf::SurrogatePlug plug = mwperf::ResponseEnvelopePlugV1{
        f05_response_envelope_payload(materialization), std::move(access)};
    validate(std::move(descriptor), std::move(plug), analytic_manifest,
             mwperf::RuntimeAccessTagV1::analytic_transform);
  }

  {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::scalar_backlog_response,
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
        mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
        scalar_manifest_digest);
    mwperf::KernelAccess access =
        mwperf::FiniteParameterAnalyticFamilyAccess(
            {descriptor.state_fields.front().c14_field.codec,
             {std::string(mwperf::kThreeBinServiceResponseCodecIdV1), 1U}},
            {std::string(mwperf::kThreeBinResponseFamilyIdV1), 1U,
             {std::string(mwperf::kThreeBinResponseParameterSchemaIdV1),
              1U},
             descriptor.state_fields.front().c14_field.codec},
            [&calls](const mwperf::CanonicalRuntimeValueV1&) {
              calls.fetch_add(1U);
              return mwperf::Result<
                  mwperf::CanonicalRuntimeValueV1>::success(
                  {{std::string(
                        mwperf::kThreeBinServiceResponseCodecIdV1),
                    1U},
                   {std::byte{0x01}}});
            });
    mwperf::SurrogatePlug plug = mwperf::ScalarBacklogResponsePlugV1{
        materialization.payload, std::move(access)};
    validate(std::move(descriptor), std::move(plug), scalar_manifest,
             mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  }

  {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::romr_residence_word_law,
        mwperf::RuntimeAccessTagV1::procedural_residence_generator,
        mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
        scalar_manifest_digest);
    descriptor.event_contract = f05_event_contract();
    reseal_descriptor(descriptor);
    const auto& event = *descriptor.event_contract;
    const auto mark_codec = descriptor.marks.front().c14_mark.codec;
    mwperf::KernelAccess access = mwperf::ProceduralResidenceGeneratorAccess(
        {event.entrance_space, event.continuation_space,
         event.terminal_space, event.reentry_space, {mark_codec}, 8U},
        {mwperf::KernelOperationIdV1(
             label("c16.f05.event.generator")),
         event.event_generator_operation.operation_version,
         event.stopping_indicator},
        true,
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::GeneratedResidenceWordV1>::success(
              {mwperf::BigNat{1U}, {}, state, state});
        });
    mwperf::CausalSurrogateOperationsV1 operations{
        std::nullopt, std::nullopt,
        f05_event_operations(event, calls)};
    mwperf::SurrogatePlug plug = mwperf::RomrResidenceWordPlugV1{
        materialization.payload, std::move(access), std::move(operations)};
    validate(std::move(descriptor), std::move(plug), scalar_manifest,
             mwperf::RuntimeAccessTagV1::procedural_residence_generator);
  }

  {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::direct_metric_decoder,
        mwperf::RuntimeAccessTagV1::direct_metric_decoder,
        mwperf::PayloadClassTagV1::direct_metric_payload_v1,
        direct_template.manifest.canonical_digest());
    auto direct_encoder =
        fixed_direct_encoder(direct_template.domain.request_codec);
    auto direct_validator = direct_result_validator(
        direct_template.domain.metric_domain.decoder_key,
        direct_template.domain.result_codec);
    mwperf::KernelAccess access = mwperf::RawDirectDecoderAccess(
        direct_template.domain, std::move(direct_encoder),
        [&calls](const mwperf::CanonicalRuntimeValueV1& value) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        },
        std::move(direct_validator));
    mwperf::SurrogatePlug plug = mwperf::DirectMetricDecoderPlugV1{
        direct_template.payload, std::move(access)};
    validate(std::move(descriptor), std::move(plug),
             direct_template.manifest,
             mwperf::RuntimeAccessTagV1::direct_metric_decoder);
  }
  CHECK(calls.load() == 0U);
}

TEST_CASE("C16 F05 rejects cross-bound access shapes without invoking them",
          "[c16][negative][access-matrix]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto materialization = materialization_fixture(scenario);
  const auto scalar_manifest = scenario.contract.structural_manifest();
  const auto scalar_manifest_digest = scalar_manifest.canonical_digest();
  const mwperf::ExactMetricDecoderKeyV1 decoder_key(
      label("c16.f05.decoder"));
  const auto direct_template =
      f05_direct_fixture(scenario, materialization, decoder_key);
  std::atomic<unsigned> calls{0U};

  const auto row_operation =
      [&calls](const mwperf::CanonicalRuntimeValueV1&) {
        calls.fetch_add(1U);
        return mwperf::Result<std::vector<mwperf::KernelRowAtomV1>>::success(
            {});
      };
  const auto reject = [&](mwperf::PlugDescriptor descriptor,
                          mwperf::SurrogatePlug plug,
                          mwperf::MetricSupportManifest manifest,
                          const std::string_view code) {
    auto minted = f05_mint(
        std::move(descriptor), std::move(plug), materialization,
        scenario.contract.contract_digest(), std::move(manifest));
    REQUIRE(minted);
    auto access = mwperf::validate_kernel_access(minted.value());
    REQUIRE_FALSE(access);
    CHECK(access.error().code == code);
    CHECK(calls.load() == 0U);
  };

  SECTION("active alternative differs from the descriptor tag") {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::stationary_marked_edge,
        mwperf::RuntimeAccessTagV1::finite_enumerated_row,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        scalar_manifest_digest);
    const auto& transition = *descriptor.transition_state_schema;
    mwperf::KernelAccess access = mwperf::SparseRowAccess(
        {transition.conditioning_state_codec,
         transition.successor_state_codec,
         {descriptor.marks.front().c14_mark.codec}, 8U, std::nullopt},
        row_operation);
    reject(std::move(descriptor),
           mwperf::StationaryMarkedEdgePlugV1{
               materialization.payload, std::move(access),
               {std::nullopt, std::nullopt, std::nullopt}},
           scalar_manifest, "c16.kernel_access_tag_mismatch");
  }

  for (const bool conditioning : {true, false}) {
    const char* section_name = conditioning ? "foreign conditioning codec"
                                            : "foreign successor codec";
    DYNAMIC_SECTION(section_name) {
      auto descriptor = f05_descriptor(
          scenario, mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::finite_enumerated_row,
          mwperf::PayloadClassTagV1::finite_law_tables_v1,
          scalar_manifest_digest);
      const auto& transition = *descriptor.transition_state_schema;
      auto conditioning_codec = transition.conditioning_state_codec;
      auto successor_codec = transition.successor_state_codec;
      (conditioning ? conditioning_codec : successor_codec) =
          {conditioning ? "c16.f05.foreign-conditioning"
                        : "c16.f05.foreign-successor",
           1U};
      mwperf::KernelAccess access = mwperf::FiniteEnumeratedRowAccess(
          {std::move(conditioning_codec), std::move(successor_codec),
           {descriptor.marks.front().c14_mark.codec}, 8U, std::nullopt},
          row_operation);
      reject(std::move(descriptor),
             mwperf::StationaryMarkedEdgePlugV1{
                 materialization.payload, std::move(access),
                 {std::nullopt, std::nullopt, std::nullopt}},
             scalar_manifest, "c16.transition_access_descriptor_mismatch");
    }
  }

  SECTION("temporal transition generator operation label is exact") {
    const auto semantic =
        mwperf::SemanticTagV1::temporal_one_slot_continuation;
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::finite_enumerated_row;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        manifest.canonical_digest());
    descriptor.event_contract =
        f05_event_contract(mwperf::EventContractKindV1::one_slot_continuation);
    reseal_descriptor(descriptor);
    const auto& transition = *descriptor.transition_state_schema;
    const auto& event = *descriptor.event_contract;
    mwperf::KernelAccess access = mwperf::FiniteEnumeratedRowAccess(
        {transition.conditioning_state_codec,
         transition.successor_state_codec,
         {descriptor.marks.front().c14_mark.codec}, 8U,
         mwperf::TransitionGeneratorOperationIdentityV1{
             mwperf::KernelOperationIdV1(
                 label("c16.f05.foreign-event-generator")),
             event.event_generator_operation.operation_version}},
        row_operation);
    mwperf::CausalSurrogateOperationsV1 operations{
        std::nullopt, std::nullopt,
        f05_event_operations(event, calls)};
    reject(std::move(descriptor),
           mwperf::TemporalOneSlotContinuationPlugV1{
               f05_finite_payload(materialization, semantic, access_tag,
                                  scenario.contract.descriptor_core()
                                      .deployed_targets),
               std::move(access), std::move(operations)},
           manifest, "c16.transition_event_generator_identity_mismatch");
  }

  SECTION("sampler cannot advertise a finite row") {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::stationary_marked_edge,
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        scalar_manifest_digest);
    const auto& transition = *descriptor.transition_state_schema;
    mwperf::KernelAccess access = mwperf::NormalizedConditionalSamplerAccess(
        {transition.conditioning_state_codec,
         transition.successor_state_codec,
         {descriptor.marks.front().c14_mark.codec}, 8U, std::nullopt},
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::KernelTransitionV1>::success(
              {state, {}});
        });
    reject(std::move(descriptor),
           mwperf::StationaryMarkedEdgePlugV1{
               materialization.payload, std::move(access),
               {std::nullopt, std::nullopt, std::nullopt}},
           scalar_manifest, "c16.sampler_advertised_as_finite_row");
  }

  SECTION("transform result codec must be a declared output codec") {
    const auto analytic_manifest = f05_semantic_manifest(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1);
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
        analytic_manifest.canonical_digest());
    mwperf::KernelAccess access = mwperf::AnalyticTransformAccess(
        {descriptor.state_fields.front().c14_field.codec,
         {"c16.f05.foreign-result", 1U}},
        {descriptor.marks.front().decoder_id},
        [&calls](const mwperf::RuntimeDecoderIdV1&,
                 const mwperf::CanonicalRuntimeValueV1& value,
                 const mwperf::ExactRational&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        });
    reject(std::move(descriptor),
           mwperf::ResponseEnvelopePlugV1{
               f05_response_envelope_payload(materialization),
               std::move(access)},
           analytic_manifest,
           "c16.transform_codec_descriptor_mismatch");
  }

  SECTION("transform decoder must be listed by the descriptor") {
    const auto analytic_manifest = f05_semantic_manifest(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1);
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::response_envelope_law,
        mwperf::RuntimeAccessTagV1::analytic_transform,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
        analytic_manifest.canonical_digest());
    mwperf::KernelAccess access = mwperf::AnalyticTransformAccess(
        {descriptor.state_fields.front().c14_field.codec,
         descriptor.marks.front().c14_mark.codec},
        {mwperf::RuntimeDecoderIdV1(
            label("c16.f05.unlisted-decoder"))},
        [&calls](const mwperf::RuntimeDecoderIdV1&,
                 const mwperf::CanonicalRuntimeValueV1& value,
                 const mwperf::ExactRational&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        });
    reject(std::move(descriptor),
           mwperf::ResponseEnvelopePlugV1{
               f05_response_envelope_payload(materialization),
               std::move(access)},
           analytic_manifest,
           "c16.transform_decoder_domain_mismatch");
  }

  SECTION("residence generator requires event semantics") {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::stationary_marked_edge,
        mwperf::RuntimeAccessTagV1::procedural_residence_generator,
        mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
        scalar_manifest_digest);
    const auto event = f05_event_contract();
    const auto mark_codec = descriptor.marks.front().c14_mark.codec;
    mwperf::KernelAccess access = mwperf::ProceduralResidenceGeneratorAccess(
        {event.entrance_space, event.continuation_space, event.terminal_space,
         event.reentry_space, {mark_codec}, 8U},
        {mwperf::KernelOperationIdV1(label("c16.f05.event.generator")), 1U,
         event.stopping_indicator},
        true,
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::GeneratedResidenceWordV1>::success(
              {mwperf::BigNat{1U}, {}, state, state});
        });
    reject(std::move(descriptor),
           mwperf::StationaryMarkedEdgePlugV1{
               materialization.payload, std::move(access),
               {std::nullopt, std::nullopt, std::nullopt}},
           scalar_manifest, "c16.residence_access_without_event_semantics");
  }

  SECTION("residence generator operation label is exact and callback-cold") {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::romr_residence_word_law,
        mwperf::RuntimeAccessTagV1::procedural_residence_generator,
        mwperf::PayloadClassTagV1::registered_runtime_recipe_v1,
        scalar_manifest_digest);
    descriptor.event_contract = f05_event_contract();
    reseal_descriptor(descriptor);
    const auto& event = *descriptor.event_contract;
    mwperf::KernelAccess access = mwperf::ProceduralResidenceGeneratorAccess(
        {event.entrance_space, event.continuation_space,
         event.terminal_space, event.reentry_space,
         {descriptor.marks.front().c14_mark.codec}, 8U},
        {mwperf::KernelOperationIdV1(
             label("c16.f05.foreign-event-generator")),
         event.event_generator_operation.operation_version,
         event.stopping_indicator},
        true,
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::GeneratedResidenceWordV1>::success(
              {mwperf::BigNat{1U}, {}, state, state});
        });
    mwperf::CausalSurrogateOperationsV1 operations{
        std::nullopt, std::nullopt,
        f05_event_operations(event, calls)};
    reject(std::move(descriptor),
           mwperf::RomrResidenceWordPlugV1{
               materialization.payload, std::move(access),
               std::move(operations)},
           scalar_manifest, "c16.residence_event_cross_binding_mismatch");
  }
}

TEST_CASE("C16 F05 binds every raw-direct domain coordinate before callback",
          "[c16][negative][access-matrix][direct]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto materialization = materialization_fixture(scenario);
  const mwperf::ExactMetricDecoderKeyV1 decoder_key(
      label("c16.f05.decoder"));
  const auto baseline =
      f05_direct_fixture(scenario, materialization, decoder_key);
  std::atomic<unsigned> calls{0U};

  const auto reject = [&](mwperf::PortablePlugPayload payload,
                          mwperf::RawDirectDecoderDomainV1 domain,
                          const std::string_view code) {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::direct_metric_decoder,
        mwperf::RuntimeAccessTagV1::direct_metric_decoder,
        mwperf::PayloadClassTagV1::direct_metric_payload_v1,
        baseline.manifest.canonical_digest());
    auto direct_encoder = fixed_direct_encoder(domain.request_codec);
    auto direct_validator = direct_result_validator(
        domain.metric_domain.decoder_key, domain.result_codec);
    mwperf::KernelAccess access = mwperf::RawDirectDecoderAccess(
        std::move(domain), std::move(direct_encoder),
        [&calls](const mwperf::CanonicalRuntimeValueV1& value) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        },
        std::move(direct_validator));
    auto minted = f05_mint(
        std::move(descriptor),
        mwperf::DirectMetricDecoderPlugV1{std::move(payload),
                                          std::move(access)},
        materialization, scenario.contract.contract_digest(),
        baseline.manifest);
    REQUIRE(minted);
    auto result = mwperf::validate_kernel_access(minted.value());
    REQUIRE_FALSE(result);
    CHECK(result.error().code == code);
    CHECK(calls.load() == 0U);
  };

  using DomainMutation =
      void (*)(mwperf::RawDirectDecoderDomainV1& domain);
  const std::array<std::pair<std::string_view, DomainMutation>, 8U>
      mutations{{
          {"canonical request",
           [](auto& domain) {
             domain.canonical_request_domain_digest =
                 digest_of("c16.f05.foreign-normalized-request");
           }},
          {"C15 build request",
           [](auto& domain) {
             domain.build_request_digest =
                 digest_of("c16.f05.foreign-build-request");
           }},
          {"target selection",
           [](auto& domain) {
             domain.target_selection_digest =
                 digest_of("c16.f05.foreign-target-selection");
           }},
          {"ordered targets",
           [](auto& domain) {
             domain.ordered_target_digest =
                 digest_of("c16.f05.foreign-ordered-targets");
           }},
          {"analysis selection",
           [](auto& domain) {
             domain.selection_digest =
                 digest_of("c16.f05.foreign-analysis-selection");
           }},
          {"configured arrival",
           [](auto& domain) {
             domain.configured_arrival_digest =
                 digest_of("c16.f05.foreign-arrival");
           }},
          {"accepted contract",
           [](auto& domain) {
             domain.accepted_contract_digest =
                 digest_of("c16.f05.foreign-contract");
           }},
          {"fixed request codec",
           [](auto& domain) {
             domain.request_codec = {"c16.f05.foreign-request", 1U};
           }},
      }};
  for (const auto& [name, mutate] : mutations) {
    DYNAMIC_SECTION(name) {
      auto domain = baseline.domain;
      mutate(domain);
      reject(baseline.payload, std::move(domain),
             "c16.direct_decoder_payload_domain_mismatch");
    }
  }

  SECTION("fixed result codec") {
    auto domain = baseline.domain;
    domain.result_codec = {"c16.f05.foreign-result", 1U};
    reject(baseline.payload, std::move(domain),
           "c16.direct_decoder_payload_domain_mismatch");
  }

  SECTION("exactly one direct value") {
    auto direct =
        std::get<mwperf::PortableDirectMetricPayloadV1>(baseline.payload.value());
    direct.normalized_record.values.clear();
    reject(Factory::portable_payload(std::move(direct)), baseline.domain,
           "c16.direct_decoder_domain_not_singleton");
  }
}

TEST_CASE("C16 constructs nine genuinely matching semantic plug tuples",
          "[c16][integration][semantic-matrix][access-matrix]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto materialization = materialization_fixture(scenario);
  const mwperf::ExactMetricDecoderKeyV1 decoder_key(
      label("c16.f05.decoder"));
  const auto direct =
      f05_direct_fixture(scenario, materialization, decoder_key);
  std::atomic<unsigned> calls{0U};
  std::vector<mwperf::SemanticTagV1> seen;

  const auto validate = [&](mwperf::PlugDescriptor descriptor,
                            mwperf::SurrogatePlug plug,
                            mwperf::MetricSupportManifest manifest) {
    const auto semantic = mwperf::semantic_tag_v1(plug);
    const auto access_tag =
        mwperf::runtime_access_tag_v1(mwperf::kernel_access_v1(plug));
    const auto& context =
        f05_payload_context(mwperf::portable_source_v1(plug));
    CHECK(semantic == descriptor.core.semantic);
    CHECK(access_tag == descriptor.core.runtime_access);
    CHECK(context.semantic == semantic);
    CHECK(context.runtime_access == access_tag);
    CHECK(context.payload_class == descriptor.core.payload_class);
    CHECK(context.ordered_deployed_targets ==
          descriptor.core.deployed_targets);
    if (const auto* tables =
            std::get_if<mwperf::PortableFiniteLawTablesV1>(
                &mwperf::portable_source_v1(plug).value())) {
      CHECK(tables->normalized_record.semantic == semantic);
      CHECK(tables->normalized_record.runtime_access == access_tag);
      CHECK(tables->normalized_record.ordered_deployed_targets ==
            descriptor.core.deployed_targets);
    }
    auto descriptor_result =
        mwperf::validate_plug_descriptor_v1(descriptor);
    INFO((descriptor_result
              ? std::string{}
              : descriptor_result.error().code + ": " +
                    descriptor_result.error().message));
    REQUIRE(descriptor_result);
    auto minted = f05_mint(
        std::move(descriptor), std::move(plug), materialization,
        scenario.contract.contract_digest(), std::move(manifest));
    REQUIRE(minted);
    auto access = mwperf::validate_kernel_access(minted.value());
    INFO((access ? std::string{}
                 : access.error().code + ": " + access.error().message));
    REQUIRE(access);
    CHECK(mwperf::runtime_access_tag_v1(access.value()) == access_tag);
    CHECK(calls.load() == 0U);
    seen.push_back(semantic);
  };

  const auto row_access =
      [&](const mwperf::PlugDescriptor& descriptor,
          const mwperf::RuntimeAccessTagV1 access_tag,
          const bool temporal) -> mwperf::KernelAccess {
    const auto& transition = *descriptor.transition_state_schema;
    mwperf::TransitionKernelAccessShapeV1 shape{
        transition.conditioning_state_codec,
        transition.successor_state_codec,
        {descriptor.marks.front().c14_mark.codec},
        access_tag ==
                mwperf::RuntimeAccessTagV1::normalized_conditional_sampler
            ? std::nullopt
            : std::optional<std::size_t>{8U},
        temporal
            ? std::optional<mwperf::TransitionGeneratorOperationIdentityV1>{
                  mwperf::TransitionGeneratorOperationIdentityV1{
                      mwperf::KernelOperationIdV1(
                          label("c16.f05.event.generator")),
                      1U}}
            : std::nullopt};
    if (access_tag ==
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler) {
      return mwperf::NormalizedConditionalSamplerAccess(
          std::move(shape),
          [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                   mwperf::DeterministicRng&) {
            calls.fetch_add(1U);
            return mwperf::Result<mwperf::KernelTransitionV1>::success(
                {state, {}});
          });
    }
    const auto operation =
        [&calls](const mwperf::CanonicalRuntimeValueV1&) {
          calls.fetch_add(1U);
          return mwperf::Result<
              std::vector<mwperf::KernelRowAtomV1>>::success({});
        };
    if (access_tag == mwperf::RuntimeAccessTagV1::sparse_row) {
      return mwperf::SparseRowAccess(std::move(shape), operation);
    }
    return mwperf::FiniteEnumeratedRowAccess(std::move(shape), operation);
  };

  const auto residence_access =
      [&](const mwperf::PlugDescriptor& descriptor,
          const mwperf::TemporalEventContractV1& event) {
    return mwperf::KernelAccess{mwperf::ProceduralResidenceGeneratorAccess(
        {event.entrance_space, event.continuation_space,
         event.terminal_space, event.reentry_space,
         {descriptor.marks.front().c14_mark.codec}, 8U},
        {mwperf::KernelOperationIdV1(
             label("c16.f05.event.generator")),
         event.event_generator_operation.operation_version,
         event.stopping_indicator},
        true,
        [&calls](const mwperf::CanonicalRuntimeValueV1& state,
                 mwperf::DeterministicRng&) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::GeneratedResidenceWordV1>::success(
              {mwperf::BigNat{1U}, {}, state, state});
        })};
  };

  {
    const auto manifest = scenario.contract.structural_manifest();
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::scalar_backlog_response,
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
        mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
        manifest.canonical_digest());
    mwperf::KernelAccess access =
        mwperf::FiniteParameterAnalyticFamilyAccess(
            {descriptor.state_fields.front().c14_field.codec,
             {std::string(mwperf::kThreeBinServiceResponseCodecIdV1), 1U}},
            {std::string(mwperf::kThreeBinResponseFamilyIdV1), 1U,
             {std::string(mwperf::kThreeBinResponseParameterSchemaIdV1),
              1U},
             descriptor.state_fields.front().c14_field.codec},
            [&calls](const mwperf::CanonicalRuntimeValueV1&) {
              calls.fetch_add(1U);
              return mwperf::Result<
                  mwperf::CanonicalRuntimeValueV1>::success(
                  {{std::string(
                        mwperf::kThreeBinServiceResponseCodecIdV1),
                    1U},
                   {std::byte{0x01}}});
            });
    validate(std::move(descriptor),
             mwperf::ScalarBacklogResponsePlugV1{
                 materialization.payload, std::move(access)},
             manifest);
  }

  {
    const auto semantic = mwperf::SemanticTagV1::stationary_marked_edge;
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::finite_enumerated_row;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        manifest.canonical_digest());
    auto source = f05_finite_payload(
        materialization, semantic, access_tag,
        descriptor.core.deployed_targets);
    auto access = row_access(descriptor, access_tag, false);
    validate(std::move(descriptor),
             mwperf::StationaryMarkedEdgePlugV1{
                 std::move(source), std::move(access),
                 {std::nullopt, std::nullopt, std::nullopt}},
             manifest);
  }

  {
    const auto semantic =
        mwperf::SemanticTagV1::staged_opportunity_flux_law;
    const auto access_tag = mwperf::RuntimeAccessTagV1::sparse_row;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        manifest.canonical_digest());
    descriptor.c_minus = mwperf::CMinusOperationSchemaV1{
        mwperf::RuntimeOperationIdV1(label("c16.f05.c-minus")),
        1U,
        {"c16.f05.predecision", 1U},
        {"c16.f05.opportunity", 1U},
        {descriptor.state_fields.front().id},
        {}};
    descriptor.c_plus = mwperf::CPlusOperationSchemaV1{
        mwperf::RuntimeOperationIdV1(label("c16.f05.c-plus")),
        1U,
        {"c16.f05.prearrival", 1U},
        {"c16.f05.opportunity", 1U},
        {"schedule.realization", 1U},
        {"arrival.batch", 1U},
        {"c16.f05.patch", 1U},
        {},
        {},
        {}};
    reseal_descriptor(descriptor);
    mwperf::CausalSurrogateOperationsV1 operations{
        mwperf::CMinusOperationV1(
            *descriptor.c_minus,
            [&calls](const mwperf::CMinusInputV1& input,
                     mwperf::DeterministicRng&) {
              calls.fetch_add(1U);
              return mwperf::Result<mwperf::CMinusOutputV1>::success(
                  {input.predecision_state, {}, std::nullopt,
                   std::nullopt});
            }),
        mwperf::CPlusOperationV1(
            *descriptor.c_plus,
            [&calls](const mwperf::CPlusInputV1&,
                     mwperf::DeterministicRng&) {
              calls.fetch_add(1U);
              return mwperf::Result<mwperf::CPlusOutputV1>::success(
                  {{}, {}});
            }),
        std::nullopt};
    auto source = f05_finite_payload(
        materialization, semantic, access_tag,
        descriptor.core.deployed_targets);
    auto access = row_access(descriptor, access_tag, false);
    validate(std::move(descriptor),
             mwperf::StagedOpportunityFluxPlugV1{
                 std::move(source), std::move(access),
                 std::move(operations)},
             manifest);
  }

  {
    const auto semantic =
        mwperf::SemanticTagV1::temporal_one_slot_continuation;
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::normalized_conditional_sampler;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        manifest.canonical_digest());
    descriptor.event_contract = f05_event_contract(
        mwperf::EventContractKindV1::one_slot_continuation);
    reseal_descriptor(descriptor);
    auto source = f05_finite_payload(
        materialization, semantic, access_tag,
        descriptor.core.deployed_targets);
    auto access = row_access(descriptor, access_tag, true);
    mwperf::CausalSurrogateOperationsV1 operations{
        std::nullopt, std::nullopt,
        f05_event_operations(*descriptor.event_contract, calls)};
    validate(std::move(descriptor),
             mwperf::TemporalOneSlotContinuationPlugV1{
                 std::move(source), std::move(access),
                 std::move(operations)},
             manifest);
  }

  for (const auto semantic :
       {mwperf::SemanticTagV1::romr_residence_word_law,
        mwperf::SemanticTagV1::stopped_path_law}) {
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::procedural_residence_generator;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1,
        manifest.canonical_digest());
    descriptor.event_contract = f05_event_contract(
        semantic == mwperf::SemanticTagV1::romr_residence_word_law
            ? mwperf::EventContractKindV1::romr_residence
            : mwperf::EventContractKindV1::stopped_path);
    reseal_descriptor(descriptor);
    auto source = f05_finite_payload(
        materialization, semantic, access_tag,
        descriptor.core.deployed_targets);
    auto access = residence_access(descriptor, *descriptor.event_contract);
    mwperf::CausalSurrogateOperationsV1 operations{
        std::nullopt, std::nullopt,
        f05_event_operations(*descriptor.event_contract, calls)};
    if (semantic == mwperf::SemanticTagV1::romr_residence_word_law) {
      validate(std::move(descriptor),
               mwperf::RomrResidenceWordPlugV1{
                   std::move(source), std::move(access),
                   std::move(operations)},
               manifest);
    } else {
      validate(std::move(descriptor),
               mwperf::StoppedPathPlugV1{
                   std::move(source), std::move(access),
                   std::move(operations)},
               manifest);
    }
  }

  {
    const auto semantic =
        mwperf::SemanticTagV1::coupled_target_schedule_law;
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::finite_enumerated_row;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::finite_law_tables_v1);
    auto descriptor =
        f05_coupled_descriptor(scenario, manifest.canonical_digest());
    auto source = f05_finite_payload(
        materialization, semantic, access_tag,
        descriptor.core.deployed_targets);
    auto access = row_access(descriptor, access_tag, false);
    validate(std::move(descriptor),
             mwperf::CoupledTargetSchedulePlugV1{
                 std::move(source), std::move(access),
                 {std::nullopt, std::nullopt, std::nullopt}},
             manifest);
  }

  {
    auto descriptor = f05_descriptor(
        scenario, mwperf::SemanticTagV1::direct_metric_decoder,
        mwperf::RuntimeAccessTagV1::direct_metric_decoder,
        mwperf::PayloadClassTagV1::direct_metric_payload_v1,
        direct.manifest.canonical_digest());
    auto direct_encoder = fixed_direct_encoder(direct.domain.request_codec);
    auto direct_validator = direct_result_validator(
        direct.domain.metric_domain.decoder_key,
        direct.domain.result_codec);
    mwperf::KernelAccess access = mwperf::RawDirectDecoderAccess(
        direct.domain, std::move(direct_encoder),
        [&calls](const mwperf::CanonicalRuntimeValueV1& value) {
          calls.fetch_add(1U);
          return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(
              value);
        },
        std::move(direct_validator));
    validate(std::move(descriptor),
             mwperf::DirectMetricDecoderPlugV1{direct.payload,
                                               std::move(access)},
             direct.manifest);
  }

  {
    const auto semantic = mwperf::SemanticTagV1::response_envelope_law;
    const auto access_tag =
        mwperf::RuntimeAccessTagV1::analytic_transform;
    const auto manifest = f05_semantic_manifest(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1);
    auto descriptor = f05_descriptor(
        scenario, semantic, access_tag,
        mwperf::PayloadClassTagV1::response_envelope_evidence_v1,
        manifest.canonical_digest());
    mwperf::KernelAccess access = mwperf::AnalyticTransformAccess(
        {descriptor.state_fields.front().c14_field.codec,
         descriptor.marks.front().c14_mark.codec},
        {descriptor.marks.front().decoder_id},
        [&calls](const mwperf::RuntimeDecoderIdV1&,
                 const mwperf::CanonicalRuntimeValueV1& value,
                 const mwperf::ExactRational&) {
          calls.fetch_add(1U);
          return mwperf::Result<
              mwperf::CanonicalRuntimeValueV1>::success(value);
        });
    validate(std::move(descriptor),
             mwperf::ResponseEnvelopePlugV1{
                 f05_response_envelope_payload(materialization),
                 std::move(access)},
             manifest);
  }

  std::sort(seen.begin(), seen.end(), [](const auto left, const auto right) {
    return static_cast<unsigned>(left) < static_cast<unsigned>(right);
  });
  CHECK(std::adjacent_find(seen.begin(), seen.end()) == seen.end());
  CHECK(seen.size() == 9U);
  CHECK(calls.load() == 0U);
}

TEST_CASE("C16 production test registry covers all ten family-build profiles",
          "[c16][unit]") {
  for (const auto& profile : mwperf::testing::kC16TestProfiles) {
    auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
    REQUIRE(id);
    auto selected = mwperf::lookup_surrogate_provider(id.value());
    INFO(std::string(profile.provider_id));
    REQUIRE(selected);
    CHECK(selected.value().is_default());
    CHECK(selected.value().manifest().value().construction_method ==
          profile.construction_method);
    CHECK(selected.value().manifest().value().producer_mode ==
          mwperf::ProducerModeV1::in_process_builder);
    CHECK(selected.value().manifest().value().deployed_semantic_tag ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(selected.value().manifest().value().runtime_access_tag ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  }
}

TEST_CASE("C16 all ten profiles preserve IID and temporal C09 bindings",
          "[c16][integration]") {
  for (const auto& profile : mwperf::testing::kC16TestProfiles) {
    CAPTURE(profile.provider_id);
    auto profile_input = make_input_fixture(
        false,
        R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
        scheduler_for_family(profile.family));
    auto iid_law = mwperf::testing::make_c09_correlated_fixture_law(
        profile_input.instance.queues(),
        mwperf::testing::FixtureFailureMode::none,
        mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
    auto temporal_law = mwperf::testing::make_c09_correlated_fixture_law(
        profile_input.instance.queues());
    REQUIRE(iid_law);
    REQUIRE(temporal_law);
    const auto iid_before = mwperf::builder_arrival_view(iid_law.value());
    const auto temporal_before =
        mwperf::builder_arrival_view(temporal_law.value());
    REQUIRE(iid_before.iid_joint_table());
    CHECK_FALSE(temporal_before.iid_joint_table());
    // The portable IID fixture also retains its valid temporal construction
    // representation.  Its distinguishing portable contract is the exact IID
    // table; the baseline temporal fixture is distinguished by lacking it.
    REQUIRE(iid_before.finite_phase());
    REQUIRE(iid_before.transition_rows());
    REQUIRE(temporal_before.finite_phase());
    REQUIRE(temporal_before.transition_rows());
    CHECK(temporal_before.capabilities().finite_enumerated_predictive_phase ==
          mwperf::CapabilityAvailability::available);
    CHECK(temporal_before.capabilities().finite_enumerated_transition_row ==
          mwperf::CapabilityAvailability::available);
    CHECK_FALSE(iid_before.digest() == temporal_before.digest());

    auto id = mwperf::SurrogateId::parse(std::string(profile.provider_id));
    REQUIRE(id);
    auto provider = mwperf::lookup_surrogate_provider(id.value());
    REQUIRE(provider);
    const mwperf::TargetSelection targets{
        1U, {queue_id("q0")},
        mwperf::ConstructionGroupIdV1(label("c16.profile.group"))};
    auto view = mwperf::build_framework_problem_view(
        profile_input.instance, *profile_input.arrival, targets);
    REQUIRE(view);
    auto parameters = mwperf::validate_surrogate_parameters(
        provider.value(), object_node());
    REQUIRE(parameters);
    const auto budget = construction_budget();
    auto preview = mwperf::preview_surrogate_descriptor(
        provider.value(), view.value(), profile_input.requirements, budget,
        parameters.value());
    INFO((preview ? std::string{} : preview.error().code));
    REQUIRE(preview);
    CHECK(preview.value().core.provider == provider.value().identity());
    CHECK(preview.value().core.semantic ==
          mwperf::SemanticTagV1::scalar_backlog_response);
    CHECK(preview.value().core.runtime_access ==
          mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    CHECK(preview.value().core.phase.payload_phase ==
          mwperf::PayloadPhaseKindV1::phase_free);
    CHECK(preview.value().core.phase.arrival_composition ==
          mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition);
    CHECK_FALSE(
        preview.value().core.phase.retains_configured_predictive_phase);
    CHECK_FALSE(preview.value().core.phase.predictive_phase_codec);
    CHECK(preview.value().construction_prerequisites.arrival.empty());
    for (const auto& clause :
         preview.value().metric_support_manifest->clauses()) {
      CHECK(clause.phase_domain.payload_phase ==
            mwperf::PayloadPhaseKindV1::phase_free);
      CHECK(clause.phase_domain.arrival_composition ==
            mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition);
      CHECK_FALSE(clause.phase_domain.retains_configured_predictive_phase);
      CHECK_FALSE(clause.phase_domain.predictive_phase_codec);
    }

    const auto iid_after = mwperf::builder_arrival_view(iid_law.value());
    const auto temporal_after =
        mwperf::builder_arrival_view(temporal_law.value());
    CHECK(iid_after.binding() == iid_before.binding());
    CHECK(iid_after.digest() == iid_before.digest());
    CHECK(iid_after.capabilities() == iid_before.capabilities());
    CHECK(iid_after.configured_law() == iid_before.configured_law());
    CHECK(iid_after.iid_joint_table() == iid_before.iid_joint_table());
    CHECK(temporal_after.binding() == temporal_before.binding());
    CHECK(temporal_after.digest() == temporal_before.digest());
    CHECK(temporal_after.capabilities() == temporal_before.capabilities());
    CHECK(temporal_after.configured_law() == temporal_before.configured_law());
    CHECK(temporal_after.finite_phase() == temporal_before.finite_phase());
    CHECK(temporal_after.transition_rows() ==
          temporal_before.transition_rows());
  }
}

#if defined(MWPERF_C16_TEST_BUILDER_PATH)
TEST_CASE("C16 local preview proves portable C09 arrival reconstruction before "
          "provider code",
          "[c16][integration][negative]") {
  auto input = make_input_fixture();
  auto id = mwperf::SurrogateId::parse(
      "c16.fixture.transport.local.success");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.local-arrival.group"))};
  auto base_view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(base_view);
  auto parameters = mwperf::validate_surrogate_parameters(
      provider.value(), object_node());
  REQUIRE(parameters);
  const auto budget = construction_budget();

  const auto preview_with = [&](const mwperf::BuilderArrivalView& arrival) {
    auto view = Factory::with_configured_arrival(base_view.value(), arrival);
    return mwperf::preview_surrogate_descriptor(
        provider.value(), view, input.requirements, budget,
        parameters.value());
  };
  const auto assert_no_construction = [] {
    CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
              std::memory_order_relaxed) == 0U);
    CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
              std::memory_order_relaxed) == 0U);
  };

  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  SECTION("portable configured-law recipe is eligible") {
    auto preview = preview_with(base_view.value().configured_arrival());
    INFO((preview ? std::string{} : preview.error().code));
    REQUIRE(preview);
    CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
              std::memory_order_relaxed) == 1U);
    assert_no_construction();
  }

  SECTION("portable finite table remains eligible without a recipe") {
    auto table_law = mwperf::testing::make_c09_correlated_fixture_law(
        input.instance.queues(), mwperf::testing::FixtureFailureMode::none,
        mwperf::testing::FixtureConstructionProfile::portable_iid_joint_table);
    REQUIRE(table_law);
    auto table_only = without_portable_arrival_recipe(
        table_law.value(), input.instance.queues());
    REQUIRE(table_only);
    const auto table_view =
        mwperf::builder_arrival_view(table_only.value());
    REQUIRE(table_view.iid_joint_table());
    CHECK_FALSE(table_view.iid_joint_table()->empty());
    CHECK(table_view.configured_law().canonical_data.empty());

    auto preview = preview_with(table_view);
    INFO((preview ? std::string{} : preview.error().code));
    REQUIRE(preview);
    CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
              std::memory_order_relaxed) == 1U);
    assert_no_construction();
  }

  SECTION("callback-only arrival is rejected before provider preview") {
    auto callback_only_law = without_portable_arrival_recipe(
        *input.arrival, input.instance.queues());
    REQUIRE(callback_only_law);
    const auto callback_only =
        mwperf::builder_arrival_view(callback_only_law.value());
    CHECK(callback_only.configured_law().canonical_data.empty());
    CHECK_FALSE(callback_only.iid_joint_table());
    CHECK_FALSE(callback_only.finite_phase());
    CHECK_FALSE(callback_only.transition_rows());
    CHECK(callback_only.capabilities().sequential_normalized_sampler ==
          mwperf::CapabilityAvailability::available);

    auto rejected = preview_with(callback_only);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c16.local_builder_arrival_not_reconstructible");
    CHECK(rejected.error().message ==
          "this arrival construction input requires the in-process builder "
          "route");
    REQUIRE(rejected.error().json_pointer);
    CHECK(*rejected.error().json_pointer ==
          "/framework_problem_view/configured_arrival");
    CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
              std::memory_order_relaxed) == 0U);
    assert_no_construction();
  }
}
#endif

TEST_CASE("C16 parameter validation retains exact provider schema ownership",
          "[c16][unit]") {
  auto id = mwperf::SurrogateId::parse("c16.fixture.mwis.engineered");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  auto validated =
      mwperf::validate_surrogate_parameters(provider.value(), object_node());
  REQUIRE(validated);
  CHECK(validated.value().provider() == provider.value().identity());
  CHECK(validated.value().typed_value_owner() != nullptr);
  constexpr std::string_view expected_text =
      R"json({"resolution_level":1})json";
  const auto expected = std::as_bytes(
      std::span(expected_text.data(), expected_text.size()));
  CHECK(std::ranges::equal(validated.value().canonical_value_bytes(),
                           expected));
}

TEST_CASE("C16 foreign validated parameters stay preview and execution cold",
          "[c16][negative][atomicity]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  const auto& manifest = scenario.provider.manifest().value();
  const std::vector<std::byte> canonical_bytes(
      scenario.parameters.canonical_value_bytes().begin(),
      scenario.parameters.canonical_value_bytes().end());

  auto foreign_id = manifest.provider;
  foreign_id.provider_id = "c16.fixture.foreign-parameter-owner";
  auto foreign_version = manifest.provider;
  foreign_version.provider_version = "9.9.9";
  const std::array foreign{
      Factory::validated_parameters(
          foreign_id, manifest.parameter_schema_version,
          manifest.parameter_schema_digest, canonical_bytes),
      Factory::validated_parameters(
          foreign_version, manifest.parameter_schema_version,
          manifest.parameter_schema_digest, canonical_bytes),
      Factory::validated_parameters(
          manifest.provider, manifest.parameter_schema_version + 1U,
          manifest.parameter_schema_digest, canonical_bytes),
      Factory::validated_parameters(
          manifest.provider, manifest.parameter_schema_version,
          digest_of("c16.foreign-parameter-schema"), canonical_bytes)};

  for (const auto& parameters : foreign) {
    CAPTURE(parameters.provider().provider_id,
            parameters.provider().provider_version,
            parameters.parameter_schema_version(),
            parameters.parameter_schema_digest().hex());
    mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
    auto preview = mwperf::preview_surrogate_descriptor(
        scenario.provider, scenario.view, scenario.requirements,
        scenario.budget, parameters);
    REQUIRE_FALSE(preview);
    CHECK(preview.error().code == "c16.foreign_validated_parameters");
    CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
              std::memory_order_relaxed) == 0U);

    // The public F03 predecessor also refuses to mint a request from the
    // foreign carrier.
    auto rejected_request = mwperf::make_surrogate_build_request(
        scenario.provider.manifest(), scenario.view, scenario.contract,
        parameters, scenario.budget, mwperf::MasterSeed(0xC1602U));
    REQUIRE_FALSE(rejected_request);
    CHECK(rejected_request.error().code ==
          "c15.validated_parameter_binding_mismatch");

    // Exercise F-C16-03 itself with a test-seam request whose provider
    // binding carries the foreign parameter origin.  Protocol v1 folds the
    // parameter-schema fingerprint into the provider scientific-contract
    // digest rather than transporting it as a second digest field.
    auto foreign_binding = scenario.request.provider_binding();
    foreign_binding.provider = parameters.provider();
    foreign_binding.parameter_schema_version =
        parameters.parameter_schema_version();
    if (parameters.parameter_schema_digest() !=
        manifest.parameter_schema_digest) {
      foreign_binding.provider_scientific_contract_digest =
          mwperf::ProviderScientificContractDigest(
              parameters.parameter_schema_digest());
    }
    const auto executable_request = Factory::with_provider_binding(
        scenario.request, std::move(foreign_binding));
    auto context = execution_context(scenario);
    const auto outcome = mwperf::execute_surrogate_provider(
        scenario.provider, executable_request, context);
    CHECK(failure_code(outcome) == "c15.request_provider_binding_mismatch");
    CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
              std::memory_order_relaxed) == 0U);
    CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
              std::memory_order_relaxed) == 0U);
    CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
              std::memory_order_relaxed) == 0U);
  }
}

TEST_CASE("C16 every fixture provider enforces its closed parameter schema",
          "[c16][negative]") {
  std::vector<std::string> provider_ids;
  provider_ids.reserve(mwperf::testing::kC16TestProfiles.size() + 42U);
  for (const auto& profile : mwperf::testing::kC16TestProfiles) {
    provider_ids.emplace_back(profile.provider_id);
  }
  for (const auto& profile :
       mwperf::testing::c16_registered_pair_matrix::kProfiles) {
    provider_ids.emplace_back(profile.provider_id);
  }
  for (const std::string_view provider_id : {
           "c16.fixture.transport.inline", "c16.fixture.context.exact",
           "c16.fixture.preview.purity",
           "c16.fixture.coupled-common-schedule",
           "c16.fixture.designated.raw", "c16.fixture.designated.nominal",
           "c16.fixture.designated.recoded", "c16.fixture.search-product",
           "c16.fixture.flow.closed-form", "c16.fixture.flow.precomputed",
           "c16.fixture.flow.in-process", "c16.fixture.flow.unavailable",
           "c16.fixture.flow.failed", "c16.fixture.flow.malformed"}) {
    provider_ids.emplace_back(provider_id);
  }
#if defined(MWPERF_C16_FLOW_BUILDER_PATH)
  provider_ids.emplace_back("c16.fixture.flow.local");
#endif
#if defined(MWPERF_C16_TEST_BUILDER_PATH)
  for (const std::string_view suffix : {
           "success", "wrong-version", "stdout", "nonzero", "stderr",
           "stderr-large", "timeout", "extra-file", "mutate-request",
           "oversize", "missing-result", "partial-result", "threaded",
           "clone-policy", "signal",
           "ambient-read-denied", "ambient-absolute-read-denied",
           "ambient-kernel-state-denied", "ambient-first-virtualized",
           "metacharacters"}) {
    provider_ids.push_back("c16.fixture.transport.local." +
                           std::string(suffix));
  }
#endif

  const auto location = [] {
    return mwperf::SourceLocation{
        "c16-parameter-matrix.json", 1U, 1U, 0U};
  };
  const auto object = [&](std::vector<mwperf::SourceObjectMember> members) {
    return mwperf::SourceNode::make_object(
        std::move(members), location(), "");
  };
  const auto member = [&](std::string key, mwperf::SourceNode value) {
    return mwperf::SourceObjectMember{
        std::move(key), location(), std::move(value)};
  };

  for (const std::string& owned_id : provider_ids) {
    CAPTURE(owned_id);
    auto id = mwperf::SurrogateId::parse(owned_id);
    REQUIRE(id);
    auto provider = mwperf::lookup_surrogate_provider(id.value());
    REQUIRE(provider);

    const auto check_rejected = [&](mwperf::SourceNode parameters,
                                    const std::string_view code) {
      mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
      auto result = mwperf::validate_surrogate_parameters(
          provider.value(), parameters);
      REQUIRE_FALSE(result);
      const std::string_view expected =
          owned_id == "c16.fixture.coupled-common-schedule"
              ? "c16.fixture.coupled_parameters"
              : code;
      CHECK(result.error().code == expected);
      CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
                std::memory_order_relaxed) == 0U);
      CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
                std::memory_order_relaxed) == 0U);
    };

    check_rejected(object({}), "c16.fixture.parameter_missing");
    check_rejected(
        object({member(
            "unknown",
            mwperf::SourceNode::make_number(
                "1", location(), "/unknown"))}),
        "c16.fixture.parameter_unknown");
    check_rejected(
        object({member(
            "resolution_level",
            mwperf::SourceNode::make_string(
                "1", location(), "/resolution_level"))}),
        "c16.fixture.parameter_wrong_type");
    check_rejected(
        object({member(
            "resolution_level",
            mwperf::SourceNode::make_number(
                "0", location(), "/resolution_level"))}),
        "c16.fixture.parameter_out_of_domain");
    check_rejected(
        object({member(
                    "resolution_level",
                    mwperf::SourceNode::make_number(
                        "1", location(), "/resolution_level")),
                member("unknown",
                       mwperf::SourceNode::make_number(
                           "1", location(), "/unknown"))}),
        "c16.fixture.parameter_unknown");

    mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
    auto accepted = mwperf::validate_surrogate_parameters(
        provider.value(), object_node());
    REQUIRE(accepted);
    CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
              std::memory_order_relaxed) == 0U);
    CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
              std::memory_order_relaxed) == 0U);
  }
}

TEST_CASE("C16 registry lookup is exact and never guesses versions",
          "[c16][negative]") {
  auto unknown = mwperf::SurrogateId::parse("c16.fixture.absent");
  REQUIRE(unknown);
  auto result = mwperf::lookup_surrogate_provider(unknown.value());
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.unknown_surrogate_id");

  auto id = mwperf::SurrogateId::parse("c16.fixture.mwis.engineered");
  auto version = mwperf::SurrogateVersion::parse("9.9.9");
  REQUIRE(id);
  REQUIRE(version);
  result = mwperf::lookup_surrogate_provider(id.value(), version.value());
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.unknown_surrogate_version");
}

TEST_CASE("C16 registry rejects duplicates and callback-shape drift",
          "[c16][negative]") {
  auto manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.duplicate", mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder);
  auto first = mwperf::testing::c16_test_registration(manifest);
  auto second = mwperf::testing::c16_test_registration(manifest);
  auto duplicate = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {std::move(first), std::move(second)});
  REQUIRE_FALSE(duplicate);
  CHECK(duplicate.error().code == "c16.duplicate_provider_version");

  auto incomplete = mwperf::testing::c16_test_registration(
      mwperf::testing::c16_test_manifest(
          "c16.fixture.no-validator",
          mwperf::ServiceFamily::pairwise_conflicts,
          mwperf::OptimizerId::mwis_branch_memo_exact,
          mwperf::ConstructionMethodV1::engineered_deterministic,
          mwperf::ProducerModeV1::in_process_builder));
  incomplete.parameter_validator = {};
  auto rejected = mwperf::detail::SurrogateRegistryAssembler::assemble(
      {std::move(incomplete)});
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c16.invalid_provider_callback_shape");
}

TEST_CASE("C16 ProbabilityMass preserves exact dyadic binary64 identity",
          "[c16][property]") {
  struct Example final {
    std::uint64_t bits;
    std::int64_t numerator;
    std::int64_t denominator;
  };
  constexpr std::array examples{
      Example{UINT64_C(0x0000000000000000), 0, 1},
      Example{UINT64_C(0x3fd0000000000000), 1, 4},
      Example{UINT64_C(0x3fe0000000000000), 1, 2},
      Example{UINT64_C(0x3ff0000000000000), 1, 1}};
  for (const auto example : examples) {
    const bool positive = example.numerator != 0;
    auto mass = mwperf::ProbabilityMass::canonical_binary64_bits(
        example.bits, positive);
    REQUIRE(mass);
    CHECK(mass.value().kind() ==
          mwperf::ProbabilityMassKindV1::canonical_binary64_bits);
    CHECK(mass.value().exact_value() ==
          rational(example.numerator, example.denominator));
    CHECK(mass.value().structural_support() == positive);
  }

  mwperf::BigInt subnormal_denominator{1};
  subnormal_denominator <<= 1074U;
  auto exact_subnormal = mwperf::ExactRational::make(
      mwperf::BigInt{1}, std::move(subnormal_denominator));
  REQUIRE(exact_subnormal);
  auto subnormal = mwperf::ProbabilityMass::canonical_binary64_bits(
      UINT64_C(0x0000000000000001), true);
  REQUIRE(subnormal);
  CHECK(subnormal.value().exact_value() == exact_subnormal.value());
  CHECK(subnormal.value().structural_support());

  auto representative_normal =
      mwperf::ProbabilityMass::canonical_binary64_bits(
          UINT64_C(0x3fe8000000000000), true);
  REQUIRE(representative_normal);
  CHECK(representative_normal.value().exact_value() == rational(3, 4));
  CHECK(representative_normal.value().structural_support());

  auto non_support_normal =
      mwperf::ProbabilityMass::canonical_binary64_bits(
          UINT64_C(0x3fe8000000000000), false);
  REQUIRE(non_support_normal);
  CHECK(non_support_normal.value().exact_value() == rational(3, 4));
  CHECK_FALSE(non_support_normal.value().structural_support());
}

TEST_CASE("C16 parameter and probability roots reject noncanonical values",
          "[c16][negative]") {
  auto id = mwperf::SurrogateId::parse("c16.fixture.mwis.engineered");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  auto number = mwperf::SourceNode::make_number(
      "1", {"c16-fixture.json", 1U, 1U, 0U}, "");
  auto parameters =
      mwperf::validate_surrogate_parameters(provider.value(), number);
  REQUIRE_FALSE(parameters);
  CHECK(parameters.error().code == "c16.parameters_not_object");

  CHECK_FALSE(mwperf::ProbabilityMass::canonical_binary64_bits(
      UINT64_C(0x8000000000000000), false));
  CHECK_FALSE(mwperf::ProbabilityMass::canonical_binary64_bits(
      UINT64_C(0x7ff0000000000000), true));
  CHECK_FALSE(mwperf::ProbabilityMass::exact_rational(
      mwperf::ExactRational::zero(), true));

  struct InvalidBits final {
    std::uint64_t bits;
    bool support;
    std::string_view code;
  };
  constexpr std::array invalid_binary64{
      InvalidBits{UINT64_C(0x8000000000000000), false,
                  "c16.noncanonical_negative_zero_mass"},
      InvalidBits{UINT64_C(0xbfe0000000000000), true,
                  "c16.negative_binary64_mass"},
      InvalidBits{UINT64_C(0x7ff0000000000000), true,
                  "c16.nonfinite_binary64_mass"},
      InvalidBits{UINT64_C(0xfff0000000000000), true,
                  "c16.negative_binary64_mass"},
      InvalidBits{UINT64_C(0x7ff8000000000000), true,
                  "c16.nonfinite_binary64_mass"},
      InvalidBits{UINT64_C(0xfff8000000000000), true,
                  "c16.negative_binary64_mass"},
      InvalidBits{UINT64_C(0x3ff0000000000001), true,
                  "c16.probability_mass_out_of_range"},
      InvalidBits{UINT64_C(0x4000000000000000), true,
                  "c16.probability_mass_out_of_range"},
      InvalidBits{UINT64_C(0x0000000000000000), true,
                  "c16.claimed_positive_zero_mass"}};
  for (const auto& invalid : invalid_binary64) {
    CAPTURE(invalid.bits, invalid.support);
    auto rejected = mwperf::ProbabilityMass::canonical_binary64_bits(
        invalid.bits, invalid.support);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == invalid.code);
  }

  for (auto invalid : {rational(-1, 2), rational(3, 2)}) {
    auto rejected = mwperf::ProbabilityMass::exact_rational(
        std::move(invalid), true);
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.probability_mass_out_of_range");
  }
  auto exact_zero_support = mwperf::ProbabilityMass::exact_rational(
      mwperf::ExactRational::zero(), true);
  REQUIRE_FALSE(exact_zero_support);
  CHECK(exact_zero_support.error().code ==
        "c16.claimed_positive_zero_mass");

  auto exact_zero_nonsupport = mwperf::ProbabilityMass::exact_rational(
      mwperf::ExactRational::zero(), false);
  REQUIRE(exact_zero_nonsupport);
  CHECK_FALSE(exact_zero_nonsupport.value().structural_support());
}

TEST_CASE("C16 preview is parameter resolved without executing a producer",
          "[c16][integration]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  CHECK(scenario.preview.core.provider == scenario.provider.identity());
  CHECK(scenario.preview.core.semantic ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  CHECK(scenario.preview.core.runtime_access ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  CHECK(scenario.preview.construction_target_scope ==
        scenario.view.target_selection().ordered_targets);
  CHECK(scenario.preview.problem_view_digest ==
        scenario.view.canonical_digest().value());
  CHECK(scenario.preview.parameter_digest ==
        scenario.parameters.canonical_value_digest());
  CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
            std::memory_order_relaxed) == 1U);
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);

  auto changed_parameters = mwperf::validate_surrogate_parameters(
      scenario.provider, object_node("2"));
  REQUIRE(changed_parameters);
  CHECK(changed_parameters.value().canonical_value_digest() !=
        scenario.parameters.canonical_value_digest());
  auto changed_preview = mwperf::preview_surrogate_descriptor(
      scenario.provider, scenario.view, scenario.requirements,
      scenario.budget, changed_parameters.value());
  REQUIRE(changed_preview);
  CHECK(changed_preview.value().parameter_digest ==
        changed_parameters.value().canonical_value_digest());
  CHECK(changed_preview.value().preview_digest !=
        scenario.preview.preview_digest);
  CHECK(changed_preview.value().core == scenario.preview.core);
  CHECK(mwperf::testing::c16_fixture_detail::preview_calls().load(
            std::memory_order_relaxed) == 2U);
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C16 in-process and inline transports remain separate axes",
          "[c16][integration]") {
  for (const auto id : {"c16.fixture.mwis.sampling",
                        "c16.fixture.transport.inline"}) {
    auto scenario = make_bound_scenario(id);
    auto context = execution_context(scenario);
    const auto outcome = mwperf::execute_surrogate_provider(
        scenario.provider, scenario.request, context);
    const auto* completed =
        std::get_if<mwperf::CompletedProviderExecution>(&outcome);
    REQUIRE(completed != nullptr);
    if (scenario.provider.manifest().value().producer_mode ==
        mwperf::ProducerModeV1::in_process_builder) {
      CHECK(completed->bytes.size() > 2U);
    } else {
      CHECK(completed->bytes ==
            std::vector<std::byte>{std::byte{'{'}, std::byte{'}'}});
    }
  }
}

#if defined(MWPERF_C16_TEST_BUILDER_PATH)
TEST_CASE("C16 all three transports preserve one mode-erased law",
          "[c16][integration]") {
  auto inline_scenario =
      make_bound_scenario("c16.fixture.transport.inline");
  auto process_scenario =
      make_bound_scenario("c16.fixture.mwis.engineered");
  auto local_scenario =
      make_bound_scenario("c16.fixture.transport.local.success");
  auto inline_payload = materialization_fixture(inline_scenario);
  auto process_payload = materialization_fixture(process_scenario);
  auto local_payload = materialization_fixture(local_scenario);
  auto inline_law = mwperf::testing::make_mode_erased_law_projection_v1(
      inline_payload.artifact, inline_scenario.request,
      inline_scenario.contract);
  auto process_law = mwperf::testing::make_mode_erased_law_projection_v1(
      process_payload.artifact, process_scenario.request,
      process_scenario.contract);
  auto local_law = mwperf::testing::make_mode_erased_law_projection_v1(
      local_payload.artifact, local_scenario.request,
      local_scenario.contract);
  REQUIRE(inline_law);
  REQUIRE(process_law);
  REQUIRE(local_law);
  CHECK(inline_law.value() == process_law.value());
  CHECK(process_law.value() == local_law.value());
  CHECK(inline_scenario.provider.identity() !=
        process_scenario.provider.identity());
  CHECK(process_scenario.provider.identity() !=
        local_scenario.provider.identity());
  CHECK(inline_scenario.request.request_digest() !=
        process_scenario.request.request_digest());
  CHECK(process_scenario.request.request_digest() !=
        local_scenario.request.request_digest());
  CHECK(inline_payload.artifact.value().payload_identity !=
        process_payload.artifact.value().payload_identity);
  CHECK(process_payload.artifact.value().payload_identity !=
        local_payload.artifact.value().payload_identity);
  CHECK(inline_payload.artifact.validation_bindings().build_identity_digest !=
        process_payload.artifact.validation_bindings().build_identity_digest);
}
#endif

TEST_CASE("C16 materialization binds one semantic and one access variant",
          "[c16][integration]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto fixture = materialization_fixture(scenario);
  auto plug = mwperf::materialize_and_validate_surrogate_plug(
      fixture.payload, fixture.artifact, scenario.contract);
  INFO((plug ? std::string{} : plug.error().code));
  REQUIRE(plug);
  CHECK(plug.value().descriptor().core.semantic ==
        mwperf::SemanticTagV1::scalar_backlog_response);
  auto access = mwperf::validate_kernel_access(plug.value());
  REQUIRE(access);
  CHECK(mwperf::runtime_access_tag_v1(access.value()) ==
        mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
  CHECK(plug.value().descriptor().configured_arrival_ownership ==
        mwperf::ConfiguredArrivalOwnershipV1::framework_external_exactly_once);
}

TEST_CASE("C16 descriptor rejects exact-coordinate writes and causal reversal",
          "[c16][negative]") {
  auto manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.descriptor", mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder);
  auto core = mwperf::testing::c16_fixture_detail::scalar_core(
      manifest, {queue_id("q0")});
  auto descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  REQUIRE(mwperf::validate_plug_descriptor_v1(descriptor));
  CHECK(descriptor.marks.front().c14_mark.reveal_stage ==
        mwperf::MetricRevealStageV1::completed_edge);
  CHECK(descriptor.marks.front().decoder_source ==
        mwperf::MarkDecoderSourceV1::decision_schedule);
  descriptor.c_plus = mwperf::CPlusOperationSchemaV1{
      mwperf::RuntimeOperationIdV1(label("c-plus")), 1U,
      {"c16.prearrival-state", 1U}, {"c16.opportunity", 1U},
      {"c16.decision", 1U},
      {"c16.configured-arrival", 1U}, {"c16.patch", 1U},
      {descriptor.state_fields.front().id}, {}, {}};
  descriptor.descriptor_digest =
      mwperf::canonical_plug_descriptor_digest_v1(descriptor).value();
  auto result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.c_plus_exact_coordinate_write");

  descriptor = mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  descriptor.marks.front().c14_mark.reveal_stage =
      mwperf::MetricRevealStageV1::predecision;
  descriptor.core.marks.front().reveal_stage =
      mwperf::MetricRevealStageV1::predecision;
  descriptor.core.core_digest =
      mwperf::canonical_plug_descriptor_core_digest_v1(descriptor.core)
          .value();
  descriptor.marks.front().decoder_source =
      mwperf::MarkDecoderSourceV1::configured_arrival;
  descriptor.descriptor_digest =
      mwperf::canonical_plug_descriptor_digest_v1(descriptor).value();
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.invalid_c14_descriptor_core");
}

TEST_CASE("C16 mark dependencies are declared acyclic causal data",
          "[c16][negative]") {
  auto manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.mark-dependencies",
      mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder);
  const auto base_core = mwperf::testing::c16_fixture_detail::scalar_core(
      manifest, {queue_id("q0")});

  auto descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(base_core);
  descriptor.marks.front().dependencies = {
      {descriptor.marks.front().id}};
  reseal_descriptor(descriptor);
  auto result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.cyclic_mark_dependency");

  descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(base_core);
  descriptor.marks.front().field_dependencies = {
      mwperf::RuntimeFieldIdV1(label("field.absent"))};
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.missing_mark_field_dependency");

  descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(base_core);
  descriptor.marks.front().dependencies = {
      {mwperf::RuntimeMarkIdV1(label("mark.absent"))}};
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.missing_mark_dependency");

  descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(base_core);
  descriptor.marks.front().dependencies = {
      {descriptor.marks.front().id}, {descriptor.marks.front().id}};
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.noncanonical_mark_dependencies");

  auto causal_core = base_core;
  causal_core.marks = {
      {mwperf::MetricMarkKindV1::target_backlog,
       mwperf::MetricRevealStageV1::predecision,
       {"queue.big_nat", 1U}, ""},
      {mwperf::MetricMarkKindV1::actual_departure,
       mwperf::MetricRevealStageV1::completed_edge,
       {"service.bit", 1U}, ""}};
  auto causal_core_digest =
      mwperf::canonical_plug_descriptor_core_digest_v1(causal_core);
  REQUIRE(causal_core_digest);
  causal_core.core_digest = std::move(causal_core_digest).value();
  descriptor =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(causal_core);
  descriptor.marks.front().decoder_source =
      mwperf::MarkDecoderSourceV1::predecision_state;
  descriptor.marks.front().decoder_input_codec = {"queue.big_nat", 1U};
  descriptor.marks.front().dependencies = {{descriptor.marks.back().id}};
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.future_to_past_mark_dependency");
}

TEST_CASE("C16 certificate claims remain independent and schema bound",
          "[c16][negative]") {
  auto manifest = mwperf::testing::c16_test_manifest(
      "c16.fixture.certificates", mwperf::ServiceFamily::pairwise_conflicts,
      mwperf::OptimizerId::mwis_branch_memo_exact,
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder);
  const auto core = mwperf::testing::c16_fixture_detail::scalar_core(
      manifest, {queue_id("q0")});
  const auto baseline =
      mwperf::testing::c16_fixture_detail::runtime_descriptor(core);
  REQUIRE(mwperf::validate_plug_descriptor_v1(baseline));

  auto descriptor = baseline;
  descriptor.certificates.clear();
  reseal_descriptor(descriptor);
  auto result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.missing_v0_certificate_projection");

  descriptor = baseline;
  descriptor.certificates.front().witness_schema =
      mwperf::CodecIdentityV1{"c16.foreign-v0", 1U};
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.v0_certificate_core_mismatch");

  descriptor = baseline;
  descriptor.certificates.push_back(descriptor.certificates.front());
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.noncanonical_certificate_order");

  descriptor = baseline;
  descriptor.certificates.push_back(
      {mwperf::CertificateCategoryV1::stability,
       mwperf::CertificateLevelV1::declaration,
       mwperf::CodecIdentityV1{"c16.unbound-stability", 1U}});
  reseal_descriptor(descriptor);
  result = mwperf::validate_plug_descriptor_v1(descriptor);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.unbound_certificate_witness");
}

TEST_CASE("C16 access validation is structural and noninvoking",
          "[c16][unit]") {
  std::atomic<unsigned> calls{0U};
  const mwperf::FiniteParameterAnalyticFamilyAccessShapeV1 shape{
      {"state", 1U}, {"state", 1U}};
  mwperf::KernelAccess access = mwperf::FiniteParameterAnalyticFamilyAccess(
      shape,
      {"family", 1U, {"parameters", 1U}, {"domain", 1U}},
      [&](const mwperf::CanonicalRuntimeValueV1& state) {
        calls.fetch_add(1U);
        return mwperf::Result<mwperf::CanonicalRuntimeValueV1>::success(state);
      });
  REQUIRE(mwperf::validate_kernel_access_shape_v1(access));
  CHECK(calls.load() == 0U);

  access = mwperf::FiniteParameterAnalyticFamilyAccess(
      shape, {"family", 1U, {"parameters", 1U}, {"domain", 1U}}, {});
  auto missing = mwperf::validate_kernel_access_shape_v1(access);
  REQUIRE_FALSE(missing);
  CHECK(missing.error().code == "c16.missing_kernel_access_callback");
}

TEST_CASE("C16 analytic transform decoder domains are closed and noninvoking",
          "[c16][unit][negative][access]") {
  std::atomic<unsigned> calls{0U};
  const auto alpha =
      mwperf::RuntimeDecoderIdV1(label("c16.transform.alpha"));
  const auto beta =
      mwperf::RuntimeDecoderIdV1(label("c16.transform.beta"));
  const auto validate = [&](std::vector<mwperf::RuntimeDecoderIdV1> ids) {
    mwperf::KernelAccess access = mwperf::AnalyticTransformAccess(
        {{"c16.transform.argument", 1U},
         {"c16.transform.result", 1U}},
        std::move(ids),
        [&calls](const mwperf::RuntimeDecoderIdV1&,
                 const mwperf::CanonicalRuntimeValueV1& value,
                 const mwperf::ExactRational&) {
          calls.fetch_add(1U);
          return mwperf::Result<
              mwperf::CanonicalRuntimeValueV1>::success(value);
        });
    return mwperf::validate_kernel_access_shape_v1(access);
  };

  SECTION("ordered unique domain is accepted") {
    REQUIRE(validate({alpha, beta}));
  }
  SECTION("empty domain is rejected") {
    auto result = validate({});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.missing_transform_decoder_domain");
  }
  SECTION("duplicate domain is rejected") {
    auto result = validate({alpha, alpha});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.invalid_transform_decoder_domain");
  }
  SECTION("unsorted domain is rejected") {
    auto result = validate({beta, alpha});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "c16.invalid_transform_decoder_domain");
  }
  CHECK(calls.load() == 0U);
}

TEST_CASE("C16 build-report validation preserves request and budget binding",
          "[c16][integration]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto report = sealed_report(scenario);
  mwperf::SurrogateBuildResult result = mwperf::UnavailableSurrogateResultV1{
      {1U, scenario.request.request_digest().value(),
       scenario.provider.identity(), report},
      {}, std::nullopt};
  auto validated = mwperf::validate_surrogate_build_report(
      result, scenario.request, scenario.budget);
  INFO((validated ? std::string{} : validated.error().code));
  REQUIRE(validated);
  CHECK(validated.value().value() == report);

  auto foreign = construction_budget();
  foreign.exact_optimizer_calls.amount = mwperf::BigNat{1U};
  auto rejected = mwperf::validate_surrogate_build_report(
      result, scenario.request, foreign);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c16.foreign_construction_budget");
}

TEST_CASE("C16 Built reports meet request-bound common work minima",
          "[c16][integration]") {
  auto budget = construction_budget();
  budget.exact_optimizer_calls.amount = mwperf::BigNat{3U};
  budget.optimizer_search_states.amount = mwperf::BigNat{12U};
  budget.configured_generator_draws.amount = mwperf::BigNat{5U};
  const mwperf::ConstructionPrerequisitesV1 prerequisites{
      {}, mwperf::BigNat{3U}, mwperf::BigNat{5U}, mwperf::BigNat{4U}};
  auto scenario = make_bound_scenario("c16.fixture.mwis.sampling", budget,
                                      prerequisites);
  auto early_report = sealed_report(scenario);
  mwperf::SurrogateBuildResult unavailable =
      mwperf::UnavailableSurrogateResultV1{
          {1U, scenario.request.request_digest().value(),
           scenario.provider.identity(), early_report},
          {}, std::nullopt};
  REQUIRE(mwperf::validate_surrogate_build_report(
      unavailable, scenario.request, scenario.budget));

  auto report = sealed_report(scenario);
  report.optimizer_calls.used = mwperf::BigNat{3U};
  report.optimizer_search_states.used = mwperf::BigNat{12U};
  report.configured_generator_draws.used = mwperf::BigNat{5U};
  reseal_report(report);
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_result(scenario, report), scenario.request, scenario.budget));

  SECTION("optimizer calls are independently bounded") {
    report.optimizer_calls.used = mwperf::BigNat{2U};
    reseal_report(report);
    auto checked = mwperf::validate_surrogate_build_report(
        built_result(scenario, report), scenario.request, scenario.budget);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c16.required_work_underreported");
  }
  SECTION("search states multiply the per-call minimum exactly") {
    report.optimizer_search_states.used = mwperf::BigNat{11U};
    reseal_report(report);
    auto checked = mwperf::validate_surrogate_build_report(
        built_result(scenario, report), scenario.request, scenario.budget);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c16.required_work_underreported");
  }
  SECTION("configured generator draws are independently bounded") {
    report.configured_generator_draws.used = mwperf::BigNat{4U};
    reseal_report(report);
    auto checked = mwperf::validate_surrogate_build_report(
        built_result(scenario, report), scenario.request, scenario.budget);
    REQUIRE_FALSE(checked);
    CHECK(checked.error().code == "c16.required_work_underreported");
  }
}

TEST_CASE("C16 common report applicability matches every request grant",
          "[c16][integration]") {
  for (unsigned index = 0U; index < 3U; ++index) {
    CAPTURE(index);
    auto budget = construction_budget();
    mwperf::CountConstructionGrantV1* grant = nullptr;
    switch (index) {
      case 0U:
        grant = &budget.exact_optimizer_calls;
        break;
      case 1U:
        grant = &budget.optimizer_search_states;
        break;
      case 2U:
        grant = &budget.configured_generator_draws;
        break;
      default:
        FAIL("unreachable common counter index");
    }
    grant->applicability = mwperf::BudgetApplicabilityV1::not_applicable;
    grant->amount = std::nullopt;
    auto scenario =
        make_bound_scenario("c16.fixture.mwis.sampling", budget);
    auto report = sealed_report(scenario);
    mwperf::CommonWorkCounterV1* counter = nullptr;
    switch (index) {
      case 0U:
        counter = &report.optimizer_calls;
        break;
      case 1U:
        counter = &report.optimizer_search_states;
        break;
      case 2U:
        counter = &report.configured_generator_draws;
        break;
      default:
        FAIL("unreachable common counter index");
    }
    counter->applicability =
        mwperf::WorkCounterApplicabilityV1::not_applicable;
    reseal_report(report);
    REQUIRE(mwperf::validate_surrogate_build_report(
        built_result(scenario, report), scenario.request, scenario.budget));

    counter->applicability = mwperf::WorkCounterApplicabilityV1::applicable;
    reseal_report(report);
    auto mismatch = mwperf::validate_surrogate_build_report(
        built_result(scenario, report), scenario.request, scenario.budget);
    REQUIRE_FALSE(mismatch);
    CHECK(mismatch.error().code == "c15.report_counter_applicability");
  }
}

TEST_CASE("C16 search-state arithmetic is arbitrary precision",
          "[c16][integration]") {
  const auto large_result =
      mwperf::BigNat::from_big_int(mwperf::BigInt{1} << 80U);
  REQUIRE(large_result);
  const mwperf::BigNat large = large_result.value();
  const mwperf::BigNat product = large * large;
  auto budget = construction_budget();
  budget.exact_optimizer_calls.amount = large;
  budget.optimizer_search_states.amount = product;
  const mwperf::ConstructionPrerequisitesV1 prerequisites{
      {}, large, std::nullopt, large};
  auto scenario = make_bound_scenario("c16.fixture.mwis.sampling", budget,
                                      prerequisites);
  auto report = sealed_report(scenario);
  report.optimizer_calls.used = large;
  report.optimizer_search_states.used = product;
  reseal_report(report);
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_result(scenario, report), scenario.request, scenario.budget));
}

TEST_CASE("C16 provider-specific report minima are manifest bound",
          "[c16][integration]") {
  auto required = make_bound_scenario("c16.fixture.mwis.engineered");
  auto report = sealed_report(required);
  auto missing = mwperf::validate_surrogate_build_report(
      built_result(required, report), required.request, required.budget);
  REQUIRE_FALSE(missing);
  CHECK(missing.error().code == "c16.required_method_counter_missing");

  report.optional_method_counters = {
      {"integration_evaluations", scalar(6, 1)}};
  reseal_report(report);
  auto low = mwperf::validate_surrogate_build_report(
      built_result(required, report), required.request, required.budget);
  REQUIRE_FALSE(low);
  CHECK(low.error().code == "c16.required_method_counter_underreported");

  report.optional_method_counters.front().value = scalar(13, 2);
  reseal_report(report);
  auto fractional = mwperf::validate_surrogate_build_report(
      built_result(required, report), required.request, required.budget);
  REQUIRE_FALSE(fractional);
  CHECK(fractional.error().code == "c16.method_counter_not_natural");

  report.optional_method_counters.front().value =
      std::vector<mwperf::PortableScientificScalar>{scalar(7, 1)};
  reseal_report(report);
  auto vector = mwperf::validate_surrogate_build_report(
      built_result(required, report), required.request, required.budget);
  REQUIRE_FALSE(vector);
  CHECK(vector.error().code == "c16.method_counter_not_scalar");

  report.optional_method_counters.front().value = scalar(7, 1);
  reseal_report(report);
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_result(required, report), required.request, required.budget));

  auto optional = make_bound_scenario("c16.fixture.mwis.sampling");
  auto optional_report = sealed_report(optional);
  REQUIRE(mwperf::validate_surrogate_build_report(
      built_result(optional, optional_report), optional.request,
      optional.budget));
}

TEST_CASE("C16 rejects a request bound to a stale manifest counter policy",
          "[c16][integration]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  auto stale_raw = scenario.provider.manifest().value();
  stale_raw.required_method_counters.push_back(
      {"refinement_rounds", mwperf::BigNat{1U}});
  auto manifest_digest = mwperf::digest_provider_manifest_v1(stale_raw);
  REQUIRE(manifest_digest);
  stale_raw.manifest_digest = std::move(manifest_digest).value();
  auto stale_manifest = mwperf::validate_provider_manifest(stale_raw);
  REQUIRE(stale_manifest);
  auto stale_request = mwperf::make_surrogate_build_request(
      stale_manifest.value(), scenario.view, scenario.contract,
      scenario.parameters, scenario.budget, mwperf::MasterSeed(0xC16010U));
  REQUIRE(stale_request);

  auto report = sealed_report(scenario);
  report.request_digest = stale_request.value().request_digest().value();
  reseal_report(report);
  auto artifact = materialization_fixture(scenario).artifact.value();
  mwperf::SurrogateBuildResult result = mwperf::BuiltSurrogateResultV1{
      {1U, stale_request.value().request_digest().value(),
       scenario.provider.identity(), report},
      std::move(artifact)};
  auto checked = mwperf::validate_surrogate_build_report(
      result, stale_request.value(), scenario.budget);
  REQUIRE_FALSE(checked);
  CHECK(checked.error().code == "c15.request_provider_binding_mismatch");
}

#if defined(MWPERF_C16_TEST_BUILDER_PATH)
TEST_CASE("C16 local executable transport returns opaque completed bytes",
          "[c16][integration]") {
  auto scenario =
      make_bound_scenario("c16.fixture.transport.local.success");
  auto context = execution_context(scenario);
  auto outcome = mwperf::run_local_surrogate_builder(
      *scenario.provider.registered_executable(), scenario.request, context);
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  REQUIRE(completed != nullptr);
  const std::string bytes(reinterpret_cast<const char*>(completed->bytes.data()),
                          completed->bytes.size());
  CHECK(bytes == R"({"protocol_version":1,"fixture":"complete"})");
  CHECK(context.local_transport_accounting().launch_attempted);
  CHECK(context.local_transport_accounting().process_started);
  CHECK(context.local_transport_accounting().result_bytes ==
        completed->bytes.size());

  auto repeated = mwperf::run_local_surrogate_builder(
      *scenario.provider.registered_executable(), scenario.request, context);
  CHECK(failure_code(repeated) == "c16.local_builder_repeated_execution");
}

TEST_CASE("C16 local transport distinguishes scientific bytes from completion",
          "[c16][integration]") {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  auto scenario =
      make_bound_scenario("c16.fixture.transport.local.wrong-version");
  auto context = execution_context(scenario);
  auto outcome = mwperf::execute_surrogate_provider(
      scenario.provider, scenario.request, context);
  const auto* completed =
      std::get_if<mwperf::CompletedProviderExecution>(&outcome);
  REQUIRE(completed != nullptr);
  const std::string bytes(reinterpret_cast<const char*>(completed->bytes.data()),
                          completed->bytes.size());
  CHECK(bytes.find("999") != std::string::npos);

  const mwperf::ArtifactParseLimits parse_limits{
      1U << 20U, 64U, 1U << 14U, 1U << 14U,
      1U << 16U, 1U << 16U, 8U << 20U};
  auto parsed =
      mwperf::parse_surrogate_build_result(completed->bytes, parse_limits);
  REQUIRE_FALSE(parsed);
  CHECK(parsed.error().code == "artifact_wire_unsupported_version");
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}

TEST_CASE("C16 local transport enforces process and filesystem boundaries",
          "[c16][negative]") {
  const std::array cases{
      std::pair{"stdout", "c16.local_builder_stdout_forbidden"},
      std::pair{"nonzero", "c16.local_builder_nonzero_exit"},
      std::pair{"stderr", "c16.local_builder_stderr_limit"},
      std::pair{"timeout", "c16.local_builder_timeout"},
      std::pair{"extra-file", "c16.local_builder_duplicate_output"},
      std::pair{"mutate-request", "c16.local_builder_request_mutated"},
      std::pair{"oversize", "c16.local_builder_result_limit"}};
  for (const auto& [suffix, expected] : cases) {
    auto scenario = make_bound_scenario(
        std::string("c16.fixture.transport.local.") + suffix);
    auto context = execution_context(scenario);
    const auto outcome = mwperf::execute_surrogate_provider(
        scenario.provider, scenario.request, context);
    INFO(suffix);
    const auto actual = failure_code(outcome);
    if (std::string_view(suffix) == "mutate-request") {
      // Exact-path carriers identify the attempted request mutation directly.
      // Capability-only carriers cannot inspect pathname bytes; they safely
      // virtualize the first write to the result and reject the attempted
      // second write as a duplicate without modifying the sealed request.
      // Landlock-backed carriers instead deny the first write through the
      // read-only request descriptor, so the fixture exits before publishing
      // any result. All three outcomes reject the mutation fail-closed.
      CHECK((actual == expected ||
             actual == "c16.local_builder_duplicate_output" ||
             actual == "c16.local_builder_nonzero_exit"));
    } else {
      CHECK(actual == expected);
    }
  }
}
#endif

TEST_CASE("C16 reduced initial laws retain exact joint masses",
          "[c16][property]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  const auto normalized =
      mwperf::canonical_metric_requirements_digest(scenario.requirements);
  REQUIRE(normalized);
  const mwperf::CodecIdentityV1 codec{"c16.reduced-state", 1U};
  const auto exact_state_digest = digest_of("c16.exact-state-schema");
  const auto reduced_state_digest = digest_of("c16.reduced-state-schema");
  auto selection_result =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_result);
  const auto selection_digest = std::move(selection_result).value();
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
  auto framework = audited_framework(
      scenario, normalized.value(),
      [codec, exact_state_digest, reduced_state_digest, selection_digest,
       support](const mwperf::SelectionSpec&,
                const std::optional<mwperf::InitialPhysicalLaw>&) {
        auto one_third = mwperf::ProbabilityMass::exact_rational(
            rational(1, 3), true);
        auto two_thirds = mwperf::ProbabilityMass::exact_rational(
            rational(2, 3), true);
        REQUIRE(one_third);
        REQUIRE(two_thirds);
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            {codec,
             exact_state_digest,
             reduced_state_digest,
             selection_digest,
             support,
             {{{codec, {std::byte{0x01}, std::byte{0x02}}},
               std::move(one_third).value(), std::nullopt},
              {{codec, {std::byte{0x02}, std::byte{0x01}}},
               std::move(two_thirds).value(), std::nullopt}}});
      });
  REQUIRE(framework);
  REQUIRE(scenario.instance.analysis_spec().context);
  auto law = mwperf::construct_reduced_initial_law(
      scenario.instance, framework.value(),
      scenario.instance.analysis_spec().context->selection, std::nullopt);
  REQUIRE(law);
  REQUIRE(mwperf::validate_reduced_initial_law_v1(law.value()));
  CHECK(law.value().atoms().size() == 2U);
  CHECK(law.value().atoms()[0].state != law.value().atoms()[1].state);
}

TEST_CASE("C16 reduced initial laws reject reconstructed or inexact marginals",
          "[c16][negative]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  const auto normalized =
      mwperf::canonical_metric_requirements_digest(scenario.requirements);
  REQUIRE(normalized);
  const mwperf::CodecIdentityV1 codec{"c16.reduced-state", 1U};
  const auto exact_state_digest = digest_of("c16.exact-state-schema");
  const auto reduced_state_digest = digest_of("c16.reduced-state-schema");
  auto selection_result =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_result);
  const auto selection_digest = std::move(selection_result).value();
  const mwperf::SelectionSupportV1 support{
      {mwperf::SelectionKindV1::stationary_unique}, {}, {}};
  auto half_mapper =
      [codec, exact_state_digest, reduced_state_digest, selection_digest,
       support](const mwperf::SelectionSpec&,
                const std::optional<mwperf::InitialPhysicalLaw>&) {
        auto half = mwperf::ProbabilityMass::exact_rational(
            rational(1, 2), true);
        REQUIRE(half);
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            {codec,
             exact_state_digest,
             reduced_state_digest,
             selection_digest,
             support,
             {{{codec, {std::byte{0x01}}}, std::move(half).value(),
               std::nullopt}}});
      };
  auto framework = audited_framework(scenario, normalized.value(), half_mapper);
  REQUIRE(framework);
  REQUIRE(scenario.instance.analysis_spec().context);
  const auto& selection = scenario.instance.analysis_spec().context->selection;
  auto unnormalized = mwperf::construct_reduced_initial_law(
      scenario.instance, framework.value(), selection, std::nullopt);
  REQUIRE_FALSE(unnormalized);
  CHECK(unnormalized.error().code == "c16.reduced_initial_mass_not_one");

  auto binary_mapper =
      [codec, exact_state_digest, reduced_state_digest, selection_digest,
       support](const mwperf::SelectionSpec&,
                const std::optional<mwperf::InitialPhysicalLaw>&) {
        auto binary = mwperf::ProbabilityMass::canonical_binary64_bits(
            UINT64_C(0x3ff0000000000000), true);
        REQUIRE(binary);
        return mwperf::Result<
            mwperf::ReducedInitialLawCandidateV1>::success(
            {codec,
             exact_state_digest,
             reduced_state_digest,
             selection_digest,
             support,
             {{{codec, {std::byte{0x01}}}, std::move(binary).value(),
               std::nullopt}}});
      };
  auto binary_framework =
      audited_framework(scenario, normalized.value(), binary_mapper);
  REQUIRE(binary_framework);
  auto inexact = mwperf::construct_reduced_initial_law(
      scenario.instance, binary_framework.value(), selection, std::nullopt);
  REQUIRE_FALSE(inexact);
  CHECK(inexact.error().code == "c16.inexact_reduced_initial_mass");
}

TEST_CASE("C16 audited initialization preserves a complete joint state law",
          "[c16][integration]") {
  auto scenario = make_bound_scenario("c16.fixture.mwis.engineered");
  const auto normalized =
      mwperf::canonical_metric_requirements_digest(scenario.requirements);
  REQUIRE(normalized);
  auto framework = audited_framework(scenario, normalized.value());
  REQUIRE(framework);
  REQUIRE(scenario.instance.analysis_spec().context);
  const auto& selection = scenario.instance.analysis_spec().context->selection;
  auto law = mwperf::construct_reduced_initial_law(
      scenario.instance, framework.value(), selection, std::nullopt);
  INFO((law ? std::string{} : law.error().code));
  REQUIRE(law);
  REQUIRE(law.value().atoms().size() == 1U);
  CHECK(law.value().atoms().front().state.canonical_value ==
        std::vector<std::byte>{std::byte{0x4e}, std::byte{0x00},
                               std::byte{0x48}, std::byte{0x00},
                               std::byte{0x5a}, std::byte{0x00}});
  CHECK(law.value().atoms().front().mass.exact_value() ==
        mwperf::ExactRational::one());
}

TEST_CASE("C16 direct metric decoding requires a matching audited seal",
          "[c16][integration]") {
  auto input = make_input_fixture(true);
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.direct.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  const auto one_request_requirements =
      mwperf::requirements_for_metric(input.request);
  auto normalized = mwperf::canonical_metric_requirements_digest(
      one_request_requirements);
  REQUIRE(normalized);

  const auto& header = mwperf::metric_request_header(input.request);
  REQUIRE(header.context);
  CHECK(header.solver_regime == mwperf::MetricSolverRegimeV1::direct);
  const mwperf::CodecIdentityV1 result_codec{"metric.scalar", 1U};
  const mwperf::ExactMetricDecoderDomainV1 decoder_domain{
      mwperf::ExactMetricDecoderKeyV1(label("c16.direct.throughput")),
      mwperf::metric_request_parameters(input.request)};
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          header.ordered_targets);
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          header.context->selection);
  REQUIRE(ordered_target_digest);
  REQUIRE(selection_digest);
  auto framework = direct_audited_framework(
      view.value(), normalized.value(), decoder_domain);
  REQUIRE(framework);
  mwperf::DirectMetricRequestDomainV1 domain{
      decoder_domain,
      normalized.value(),
      normalized.value(),
      header.ordered_targets,
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      mwperf::MetricSelectionRegimeV1::stationary_unique,
      result_codec};
  std::atomic<unsigned> calls{0U};
  std::atomic<unsigned> validations{0U};
  auto access = mwperf::testing::C16FixtureAuditedMint::direct_metric_access(
      framework.value(), domain,
      [&](const mwperf::MetricRequest&) {
        calls.fetch_add(1U);
        return mwperf::Result<mwperf::MetricValue>::success(
            mwperf::MetricValue{result_codec,
                                {std::byte{0x00}, std::byte{0x01}}});
      },
      [&](const mwperf::ExactMetricDecoderKeyV1& key,
          const mwperf::CodecIdentityV1& codec,
          const std::span<const std::byte> bytes) {
        validations.fetch_add(1U);
        CHECK(key == decoder_domain.decoder_key);
        CHECK(codec == result_codec);
        CHECK(bytes.size() == 2U);
        return mwperf::Result<void>::success();
      });
  REQUIRE(access);
  auto decoded = mwperf::execute_direct_metric_decoder(
      framework.value(), access.value(), input.request);
  INFO((decoded ? std::string{} : decoded.error().code));
  REQUIRE(decoded);
  CHECK(decoded.value().codec == result_codec);
  CHECK(calls.load() == 1U);
  CHECK(validations.load() == 1U);

  auto foreign_framework = direct_audited_framework(
      view.value(), normalized.value(), decoder_domain);
  REQUIRE(foreign_framework);
  auto rejected = mwperf::execute_direct_metric_decoder(
      foreign_framework.value(), access.value(), input.request);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c16.direct_access_seal_mismatch");
  CHECK(calls.load() == 1U);
  CHECK(validations.load() == 1U);
}

TEST_CASE("C16 direct decoding rejects domain and result drift atomically",
          "[c16][negative]") {
  auto input = make_input_fixture(true);
  const mwperf::TargetSelection targets{
      1U, {queue_id("q0")},
      mwperf::ConstructionGroupIdV1(label("c16.direct.negative.group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  const auto requirements = mwperf::requirements_for_metric(input.request);
  auto normalized = mwperf::canonical_metric_requirements_digest(requirements);
  REQUIRE(normalized);
  const auto& header = mwperf::metric_request_header(input.request);
  REQUIRE(header.context);
  const mwperf::CodecIdentityV1 result_codec{"metric.scalar", 1U};
  const mwperf::ExactMetricDecoderDomainV1 decoder_domain{
      mwperf::ExactMetricDecoderKeyV1(label("c16.direct.throughput")),
      mwperf::metric_request_parameters(input.request)};
  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          header.ordered_targets);
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          header.context->selection);
  REQUIRE(ordered_target_digest);
  REQUIRE(selection_digest);
  auto framework = direct_audited_framework(
      view.value(), normalized.value(), decoder_domain);
  REQUIRE(framework);
  const mwperf::DirectMetricRequestDomainV1 base_domain{
      decoder_domain,
      normalized.value(),
      normalized.value(),
      header.ordered_targets,
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      mwperf::MetricSelectionRegimeV1::stationary_unique,
      result_codec};
  std::atomic<unsigned> decoder_calls{0U};
  std::atomic<unsigned> validator_calls{0U};
  const auto valid_decoder = [&]() -> mwperf::SealedDirectMetricDecoderV1 {
    return [&](const mwperf::MetricRequest&) {
      decoder_calls.fetch_add(1U);
      return mwperf::Result<mwperf::MetricValue>::success(
          {result_codec, {std::byte{0x00}, std::byte{0x01}}});
    };
  };
  const auto valid_validator =
      [&]() -> mwperf::SealedCanonicalResultBytesValidatorV1 {
    return [&](const mwperf::ExactMetricDecoderKeyV1&,
               const mwperf::CodecIdentityV1&,
               const std::span<const std::byte>) {
      validator_calls.fetch_add(1U);
      return mwperf::Result<void>::success();
    };
  };
  const auto execute =
      [&](mwperf::DirectMetricRequestDomainV1 domain,
          mwperf::SealedDirectMetricDecoderV1 decoder,
          mwperf::SealedCanonicalResultBytesValidatorV1 validator) {
        auto access =
            mwperf::testing::C16FixtureAuditedMint::direct_metric_access(
                framework.value(), std::move(domain), std::move(decoder),
                std::move(validator));
        REQUIRE(access);
        return mwperf::execute_direct_metric_decoder(
            framework.value(), access.value(), input.request);
      };

  SECTION("normalized requirements cannot cross the seal") {
    auto domain = base_domain;
    domain.normalized_metric_request_digest = digest_of("c16.foreign.req");
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_access_domain_binding_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("ordered target identity cannot cross the seal") {
    auto domain = base_domain;
    domain.ordered_target_digest = digest_of("c16.foreign.ordered-targets");
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_access_domain_binding_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("analysis selection identity cannot cross the seal") {
    auto domain = base_domain;
    domain.selection_digest = digest_of("c16.foreign.selection");
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_access_domain_binding_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("selection regime cannot cross the typed request domain") {
    auto domain = base_domain;
    domain.selection_regime =
        mwperf::MetricSelectionRegimeV1::stationary_class;
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_request_domain_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("exact metric parameters cannot cross the typed request domain") {
    auto domain = base_domain;
    domain.metric_domain.exact_parameters =
        mwperf::StationaryEmptyProbabilityParametersV1{};
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_access_domain_binding_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("typed decoder keys cannot cross the seal") {
    auto domain = base_domain;
    domain.metric_domain.decoder_key =
        mwperf::ExactMetricDecoderKeyV1(label("c16.direct.foreign"));
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_access_domain_binding_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("canonical request identity is recomputed") {
    auto domain = base_domain;
    domain.canonical_request_domain_digest =
        digest_of("c16.foreign.canonical-request");
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_request_digest_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("typed target lists are checked independently of their digest") {
    auto domain = base_domain;
    domain.ordered_targets.clear();
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_request_domain_mismatch");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("both sealed operations are mandatory") {
    auto missing_decoder = execute(
        base_domain, mwperf::SealedDirectMetricDecoderV1{},
        valid_validator());
    REQUIRE_FALSE(missing_decoder);
    CHECK(missing_decoder.error().code ==
          "c16.sealed_direct_decoder_incomplete");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);

    auto missing_validator = execute(
        base_domain, valid_decoder(),
        mwperf::SealedCanonicalResultBytesValidatorV1{});
    REQUIRE_FALSE(missing_validator);
    CHECK(missing_validator.error().code ==
          "c16.sealed_direct_decoder_incomplete");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("an invalid result codec is rejected before decoding") {
    auto domain = base_domain;
    domain.result_codec = {"", 0U};
    auto rejected = execute(std::move(domain), valid_decoder(),
                            valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.invalid_direct_access_domain");
    CHECK(decoder_calls.load() == 0U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("decoded result codec is checked before canonical bytes") {
    auto rejected = execute(
        base_domain,
        [&](const mwperf::MetricRequest&) {
          decoder_calls.fetch_add(1U);
          return mwperf::Result<mwperf::MetricValue>::success(
              {{"metric.foreign", 1U}, {std::byte{0x01}}});
        },
        valid_validator());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "c16.direct_metric_result_type_mismatch");
    CHECK(decoder_calls.load() == 1U);
    CHECK(validator_calls.load() == 0U);
  }

  SECTION("canonical result validation errors propagate exactly once") {
    auto rejected = execute(
        base_domain, valid_decoder(),
        [&](const mwperf::ExactMetricDecoderKeyV1&,
            const mwperf::CodecIdentityV1&,
            const std::span<const std::byte>) {
          validator_calls.fetch_add(1U);
          return mwperf::Result<void>::failure(
              mwperf::testing::c16_fixture_detail::fixture_error(
                  "c16.fixture.noncanonical-direct-result",
                  "the fixture rejected noncanonical result bytes"));
        });
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code ==
          "c16.fixture.noncanonical-direct-result");
    CHECK(decoder_calls.load() == 1U);
    CHECK(validator_calls.load() == 1U);
  }
}
