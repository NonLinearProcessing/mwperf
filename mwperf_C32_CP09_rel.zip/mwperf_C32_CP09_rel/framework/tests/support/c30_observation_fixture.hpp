#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/observation_record.hpp"

namespace mwperf::testing::c30 {

[[nodiscard]] inline ExactRational rational(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline Digest256 digest(const char digit) {
  auto value = Digest256::from_hex(std::string(64U, digit));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline ObservationScalarV1 scalar(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  return {PortableScientificScalar::rational(
              rational(numerator, denominator)),
          std::nullopt};
}

[[nodiscard]] inline ObservationMassBalanceV1 exact_balance(
    const std::int64_t recorded_mass) {
  return {ObservationNormalizationClaimV1::exact, scalar(recorded_mass),
          scalar(0)};
}

[[nodiscard]] inline ObservationCapabilityStateV1 available() {
  return {true, std::nullopt};
}

[[nodiscard]] inline ObservationCapabilityStateV1 unavailable(
    std::string reason) {
  return {false, std::move(reason)};
}

[[nodiscard]] inline ObservationSlotConventionV1 slot_convention(
    const ObservationSourceRoleV1 role) {
  std::vector<ObservationSlotStageV1> order{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service};
  if (role == ObservationSourceRoleV1::weighted_ensemble) {
    order.push_back(ObservationSlotStageV1::classify_and_resample);
    order.push_back(ObservationSlotStageV1::allocate_child_lineage);
  }
  order.push_back(ObservationSlotStageV1::apply_fresh_late_arrival);
  order.push_back(ObservationSlotStageV1::commit_post_slot_state);
  order.push_back(ObservationSlotStageV1::emit_committed_observation);
  // The digest names the common pre-service/fresh-late scientific convention;
  // the role-specific resampling stages remain explicit in step_order.
  return {std::move(order), digest('b')};
}

[[nodiscard]] inline ConstructionObservationBundleV1 exact_bundle(
    const ObservationSourceRoleV1 role =
        ObservationSourceRoleV1::short_restart_reference) {
  BoundaryBacklogLawV1 initial{
      0U, {{BigNat{0U}, scalar(1)}}, exact_balance(1)};
  BoundaryBacklogLawV1 committed{
      4U, {{BigNat{0U}, scalar(1)}}, exact_balance(1)};
  ConstructionObservationBlockV1 block{
      0U,
      4U,
      ObservationCompletenessV1::complete,
      4U,
      {{BigNat{0U}, scalar(1), scalar(0), std::nullopt},
       {BigNat{1U}, scalar(1), scalar(1), std::nullopt},
       {BigNat{2U}, scalar(2), scalar(1), std::nullopt}},
      exact_balance(4),
      std::move(initial),
      std::move(committed)};

  ObservationCapabilitiesV1 capabilities{
      available(), available(), available(), available(), available(),
      available(), unavailable("not_requested")};
  return ConstructionObservationBundleV1{
      1U,
      role,
      ObservationScalarRepresentationV1::exact_rational,
      {digest('1'),
       digest('2'),
       digest('3'),
       {QueueId(TypedLabel::numeric(BigNat{17U})), 0U, rational(1)},
       {"iid_batch_v1",
        digest('4'),
        ExactTargetArrivalMarginalV1{
            {{BigNat{0U}, rational(3, 4)},
             {BigNat{1U}, rational(1, 4)}}},
        rational(1, 4), rational(1, 4)},
       digest('5'),
       digest('6'),
       digest('7'),
       digest('8'),
       digest('9'),
       digest('a')},
      slot_convention(role),
      {"point_mass_zero", digest('d')},
      {"counter_rng", 1U, digest('e')},
      0U,
      4U,
      {0U, 4U},
      std::move(capabilities),
      {{TypedLabel::numeric(BigNat{0U}), digest('f'),
        role == ObservationSourceRoleV1::weighted_ensemble
            ? std::optional<Digest256>{digest('0')}
            : std::nullopt,
        ObservationCompletenessV1::complete, 4U, {std::move(block)}}}};
}

[[nodiscard]] inline ConstructionObservationBundleV1 exact_gap_bundle(
    const ObservationSourceRoleV1 role =
        ObservationSourceRoleV1::short_restart_reference) {
  auto bundle = exact_bundle(role);
  bundle.capabilities.certified_gap_probe = available();
  auto& levels = bundle.replications.front().blocks.front().levels;
  levels[0].gap = ObservationGapCellV1{
      scalar(1), scalar(0), scalar(0), scalar(0), scalar(0), scalar(1)};
  levels[1].gap = ObservationGapCellV1{
      scalar(0), scalar(0), scalar(1), scalar(0), scalar(1), scalar(0)};
  levels[2].gap = ObservationGapCellV1{
      scalar(0), scalar(2), scalar(0), scalar(1), scalar(0), scalar(0)};
  return bundle;
}

[[nodiscard]] inline ConstructionObservationEnvelopeV1 envelope_for(
    ConstructionObservationBundleV1 bundle) {
  auto body_digest = construction_observation_bundle_digest_v1(bundle);
  REQUIRE(body_digest);
  return {std::move(bundle), std::move(body_digest).value()};
}

[[nodiscard]] inline ValidatedConstructionObservationBundleV1
validated_bundle(const ObservationSourceRoleV1 role) {
  auto validated = validate_construction_observation_envelope_v1(
      envelope_for(exact_bundle(role)),
      default_observation_parse_limits_v1());
  REQUIRE(validated);
  return std::move(validated).value();
}

}  // namespace mwperf::testing::c30
