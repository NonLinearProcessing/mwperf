#include "support/c19_math_carriers.hpp"

#include <cstddef>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "stationary/c19_carrier_internal.hpp"

namespace mwperf::testing::c19_math {
namespace {

[[nodiscard]] Result<Digest256> carrier_digest(const std::string& identity,
                                               const std::string& suffix) {
  const std::string canonical = identity + suffix;
  return sha256_domain_separated(
      "mwperf.c19.math_test_carrier.v1",
      std::as_bytes(std::span(canonical.data(), canonical.size())));
}

[[nodiscard]] Result<stationary::detail::C19CarrierLineageV1>
make_lineage(const CarrierLineageSpec& spec) {
  auto identity = carrier_digest(spec.identity, ".lineage");
  if (!identity) {
    return Result<stationary::detail::C19CarrierLineageV1>::failure(
        identity.error());
  }
  auto analysis = carrier_digest(spec.identity, ".analysis");
  if (!analysis) {
    return Result<stationary::detail::C19CarrierLineageV1>::failure(
        analysis.error());
  }
  return Result<stationary::detail::C19CarrierLineageV1>::success(
      stationary::detail::C19CarrierLineageV1{
          std::move(identity).value(), std::move(analysis).value(),
          spec.construction_method, spec.producer_mode, spec.arrival_family});
}

}  // namespace

Result<Digest256> analysis_fingerprint(const CarrierLineageSpec& lineage) {
  return carrier_digest(lineage.identity, ".analysis");
}

Result<AuditedResponseLaw> mint_scalar_response(ScalarCarrierSpec spec) {
  auto lineage = make_lineage(spec.lineage);
  if (!lineage) {
    return Result<AuditedResponseLaw>::failure(lineage.error());
  }
  std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> seed;
  seed.reserve(spec.selection_seed.size());
  for (auto& atom : spec.selection_seed) {
    seed.push_back(
        {std::move(atom.backlog), std::move(atom.selection_mass)});
  }
  return stationary::detail::mint_c19_scalar_response(
      stationary::detail::C19ScalarResponseCarrierSpecV1{
          std::move(lineage).value(), std::move(spec.arrival_atoms),
          spec.second_moment_available, spec.temporal_iid,
          std::move(spec.service_by_level),
          std::move(spec.constant_tail_from),
          std::move(spec.constant_tail_service),
          std::move(seed),
          stationary::detail::C19LittleLawPremisesV1{
              spec.little_law.lossless, spec.little_law.unit_packets,
              spec.little_law.eventual_departure,
              spec.little_law.positive_finite_intensity,
              spec.little_law.finite_first_backlog_moment,
              spec.little_law.little_law},
          std::move(spec.selection)});
}

Result<AuditedThreeBinResponse> mint_three_bin_response(
    ScalarCarrierSpec spec) {
  auto lineage = make_lineage(spec.lineage);
  if (!lineage) {
    return Result<AuditedThreeBinResponse>::failure(lineage.error());
  }
  std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> seed;
  seed.reserve(spec.selection_seed.size());
  for (auto& atom : spec.selection_seed) {
    seed.push_back(
        {std::move(atom.backlog), std::move(atom.selection_mass)});
  }
  return stationary::detail::mint_c19_three_bin_response(
      stationary::detail::C19ScalarResponseCarrierSpecV1{
          std::move(lineage).value(), std::move(spec.arrival_atoms),
          spec.second_moment_available, spec.temporal_iid,
          std::move(spec.service_by_level),
          std::move(spec.constant_tail_from),
          std::move(spec.constant_tail_service),
          std::move(seed),
          stationary::detail::C19LittleLawPremisesV1{
              spec.little_law.lossless, spec.little_law.unit_packets,
              spec.little_law.eventual_departure,
              spec.little_law.positive_finite_intensity,
              spec.little_law.finite_first_backlog_moment,
              spec.little_law.little_law},
          std::move(spec.selection)});
}

Result<AuditedPhaseResponse> mint_phase_response(PhaseCarrierSpec spec) {
  auto lineage = make_lineage(spec.lineage);
  if (!lineage) {
    return Result<AuditedPhaseResponse>::failure(lineage.error());
  }
  return stationary::detail::mint_c19_phase_response(
      stationary::detail::C19PhaseResponseCarrierSpecV1{
          std::move(lineage).value(), std::move(spec.phases),
          std::move(spec.arrival_blocks),
          std::move(spec.configured_phase_marginal),
          std::move(spec.service_row_major), std::move(spec.completion),
          std::move(spec.selection), std::move(spec.solver_policy)});
}

Result<AuditedFixedPointFamily> mint_fixed_point_family(
    FixedPointCarrierSpec spec) {
  auto lineage = make_lineage(spec.lineage);
  if (!lineage) {
    return Result<AuditedFixedPointFamily>::failure(lineage.error());
  }
  auto map_identity = carrier_digest(spec.lineage.identity, ".map");
  if (!map_identity) {
    return Result<AuditedFixedPointFamily>::failure(map_identity.error());
  }
  std::vector<stationary::detail::C19NamedFixedPointSolutionV1> named;
  named.reserve(spec.named_solutions.size());
  for (auto& solution : spec.named_solutions) {
    named.push_back({std::move(solution.id), std::move(solution.parameters)});
  }
  const std::string family_id = "mwperf.c19.math_test." + spec.lineage.identity;
  const CodecIdentityV1 domain_codec{family_id + ".domain", 1U};
  return stationary::detail::mint_c19_fixed_point_family(
      stationary::detail::C19FixedPointCarrierSpecV1{
          std::move(lineage).value(), std::move(spec.domain_lower),
          std::move(spec.domain_upper), std::move(spec.codomain_lower),
          std::move(spec.codomain_upper), std::move(spec.cold_initial),
          stationary::detail::C19FixedPointStoppingNormV1::maximum_absolute,
          std::move(spec.iteration_budget), std::move(spec.evaluation_budget),
          spec.uniqueness_declared, std::move(named), std::move(spec.map),
          ArtifactObjectReferenceV1{TypedLabel::numeric(BigNat{19U}),
                                    std::move(map_identity).value()},
          AnalyticFamilyIdentityV1{
              family_id, 1U,
              CodecIdentityV1{family_id + ".parameters", 1U}, domain_codec},
          FiniteParameterAnalyticFamilyAccessShapeV1{
              domain_codec, CodecIdentityV1{family_id + ".response", 1U}},
          std::move(spec.selection), std::move(spec.solver_policy)});
}

}  // namespace mwperf::testing::c19_math
