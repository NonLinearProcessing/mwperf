#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_test_providers.hpp is available only to the C16 test target"
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <iterator>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "c16_coupled_schedule_fixture.hpp"
#include "c16_end_to_end_fixture.hpp"
#include "c16_registered_pair_matrix_fixture.hpp"
#include "c30_observation_fixture.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace mwperf::testing {

struct C16TestProfileV1 final {
  std::string_view provider_id;
  ServiceFamily family;
  OptimizerId optimizer;
  ConstructionMethodV1 construction_method;
};

inline constexpr std::array<C16TestProfileV1, 10U> kC16TestProfiles{{
    {"c16.fixture.crossbar.engineered", ServiceFamily::crossbar_matching,
     OptimizerId::hungarian_exact,
     ConstructionMethodV1::engineered_deterministic},
    {"c16.fixture.crossbar.sampling", ServiceFamily::crossbar_matching,
     OptimizerId::hungarian_exact, ConstructionMethodV1::sampled_offline},
    {"c16.fixture.interval.engineered",
     ServiceFamily::nonoverlapping_intervals,
     OptimizerId::weighted_interval_dp_exact,
     ConstructionMethodV1::engineered_deterministic},
    {"c16.fixture.interval.sampling",
     ServiceFamily::nonoverlapping_intervals,
     OptimizerId::weighted_interval_dp_exact,
     ConstructionMethodV1::sampled_offline},
    {"c16.fixture.blossom.engineered",
     ServiceFamily::node_exclusive_matching,
     OptimizerId::edmonds_blossom_exact,
     ConstructionMethodV1::engineered_deterministic},
    {"c16.fixture.blossom.sampling",
     ServiceFamily::node_exclusive_matching,
     OptimizerId::edmonds_blossom_exact,
     ConstructionMethodV1::sampled_offline},
    {"c16.fixture.mwis.engineered", ServiceFamily::pairwise_conflicts,
     OptimizerId::mwis_branch_memo_exact,
     ConstructionMethodV1::engineered_deterministic},
    {"c16.fixture.mwis.sampling", ServiceFamily::pairwise_conflicts,
     OptimizerId::mwis_branch_memo_exact,
     ConstructionMethodV1::sampled_offline},
    {"c16.fixture.packing.engineered", ServiceFamily::resource_packing,
     OptimizerId::binary_packing_memo_exact,
     ConstructionMethodV1::engineered_deterministic},
    {"c16.fixture.packing.sampling", ServiceFamily::resource_packing,
     OptimizerId::binary_packing_memo_exact,
     ConstructionMethodV1::sampled_offline},
}};

namespace c16_fixture_detail {

[[nodiscard]] inline std::atomic<unsigned>& construction_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

[[nodiscard]] inline std::atomic<unsigned>& preview_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

[[nodiscard]] inline std::atomic<unsigned>& materializer_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

struct PreviewPurityCountersV1 final {
  std::atomic<unsigned> artifact_reads{0U};
  std::atomic<unsigned> process_launches{0U};
  std::atomic<unsigned> optimizer_calls{0U};
  std::atomic<unsigned> row_calls{0U};
  std::atomic<unsigned> sample_calls{0U};
  std::atomic<unsigned> decoder_calls{0U};
};

[[nodiscard]] inline PreviewPurityCountersV1& preview_purity_counters() {
  static PreviewPurityCountersV1 value;
  return value;
}

inline void reset_preview_purity_counters() noexcept {
  auto& counters = preview_purity_counters();
  counters.artifact_reads.store(0U, std::memory_order_relaxed);
  counters.process_launches.store(0U, std::memory_order_relaxed);
  counters.optimizer_calls.store(0U, std::memory_order_relaxed);
  counters.row_calls.store(0U, std::memory_order_relaxed);
  counters.sample_calls.store(0U, std::memory_order_relaxed);
  counters.decoder_calls.store(0U, std::memory_order_relaxed);
}

inline void reset_side_effect_counters() noexcept {
  preview_calls().store(0U, std::memory_order_relaxed);
  construction_calls().store(0U, std::memory_order_relaxed);
  materializer_calls().store(0U, std::memory_order_relaxed);
}

[[nodiscard]] inline TypedLabel label(const std::string& value) {
  return std::move(TypedLabel::text(value)).value();
}

[[nodiscard]] inline QueueId queue(const std::string& value) {
  return QueueId(label(value));
}

[[nodiscard]] inline Digest256 digest(const std::string_view value) {
  return std::move(
             sha256(std::as_bytes(std::span(value.data(), value.size()))))
      .value();
}

[[nodiscard]] inline MetricSupportRoleRequirementV1 role(
    const MetricSupportRoleV1 value,
    const MetricTargetScopeV1 target_scope,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope) {
  return {value, target_scope, result_scope, evidence_scope, {}, {}};
}

[[nodiscard]] inline ArrivalAssumptionV1 target_intensity_assumption() {
  return {ArrivalNeedKindV1::target_intensity,
          ArrivalCapabilityUseV1::runtime,
          CapabilityProvisionNeedV1::any,
          std::nullopt,
          false,
          false,
          std::nullopt,
          std::nullopt,
          std::nullopt};
}

[[nodiscard]] inline MetricSupportManifest scalar_manifest(
    const SchedulerConstraintPairV1&) {
  auto deployed_payload = role(
      MetricSupportRoleV1::deployed_payload,
      MetricTargetScopeV1::payload_targets,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::none);
  auto deployed_response = role(
      MetricSupportRoleV1::deployed_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law);
  deployed_response.role_relations = {
      {MetricRoleRelationKindV1::binding,
       MetricSupportRoleV1::deployed_payload},
      {MetricRoleRelationKindV1::subject,
       MetricSupportRoleV1::raw_response}};
  auto raw_response = role(
      MetricSupportRoleV1::raw_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::proposal_raw,
      MetricEvidenceScopeV1::raw_static_proposal);
  raw_response.role_relations = {
      {MetricRoleRelationKindV1::binding,
       MetricSupportRoleV1::deployed_payload}};
  raw_response.internal_relations = {
      {MetricRoleRelationKindV1::lineage_parent,
       InternalReferencePurposeV1::coefficient_origin}};
  auto validity = role(
      MetricSupportRoleV1::reported_validity_or_lift_evidence,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::not_a_metric_result,
      MetricEvidenceScopeV1::validity_or_lift);
  for (const auto purpose :
       std::array{InternalReferencePurposeV1::coordinate_codec,
                  InternalReferencePurposeV1::mark_codec,
                  InternalReferencePurposeV1::configured_arrival_binding,
                  InternalReferencePurposeV1::selection_binding,
                  InternalReferencePurposeV1::timing_binding,
                  InternalReferencePurposeV1::validity_basis}) {
    validity.internal_relations.push_back(
        {MetricRoleRelationKindV1::binding, purpose});
  }
  validity.internal_relations.push_back(
      {MetricRoleRelationKindV1::evidence,
       InternalReferencePurposeV1::validity_witness});
  validity.internal_relations.push_back(
      {MetricRoleRelationKindV1::subject,
       InternalReferencePurposeV1::artifact_payload});
  validity.internal_relations.push_back(
      {MetricRoleRelationKindV1::subject,
       InternalReferencePurposeV1::law_or_result});

  MetricSupportClauseV1 clause{
      {"throughput", 0U},
      MetricKindV1::stationary_throughput,
      ExactMetricParameterSetV1{{StationaryThroughputParametersV1{}}},
      {queue("q0")},
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog,
        FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{MetricMarkKindV1::actual_departure,
        MetricRevealStageV1::completed_edge,
        {"service.bit", 1U},
        ""}},
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::no_arrival_composition,
       false,
       std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {target_intensity_assumption()},
      {{HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::lossless, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::moment_finite, MomentVariableV1::arrival,
        BigNat{1U}, std::nullopt}},
      SolverRegimeV1::analytic,
      AnalyticAccuracyV1{BigNat{128U}, {}},
      {StructuralErrorFormV1::exact, MetricEvidenceScopeV1::none,
       ExactRational::zero()},
      MetricResultScopeV1::surrogate_law,
      {V0DeclarationKindV1::structural_witness_required,
       "c16.fixture.v0", 1U},
      {std::move(deployed_payload), std::move(deployed_response),
       std::move(raw_response), std::move(validity)}};
  return std::move(
             MetricSupportManifest::from_clauses({std::move(clause)}))
      .value();
}

[[nodiscard]] inline std::optional<MetricSupportRoleV1>
designated_response_role(const std::string_view provider_id) {
  if (provider_id == "c16.fixture.designated.raw") {
    return MetricSupportRoleV1::raw_response;
  }
  if (provider_id == "c16.fixture.designated.nominal") {
    return MetricSupportRoleV1::nominal_response;
  }
  if (provider_id == "c16.fixture.designated.recoded") {
    return MetricSupportRoleV1::recoded_response;
  }
  return std::nullopt;
}

[[nodiscard]] inline MetricSupportManifest designated_scalar_manifest(
    const SchedulerConstraintPairV1& pair,
    const MetricSupportRoleV1 deployed_role) {
  auto clause = scalar_manifest(pair).clauses().front();
  auto deployed = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [](const MetricSupportRoleRequirementV1& requirement) {
        return requirement.role == MetricSupportRoleV1::deployed_response;
      });
  auto deployed_subject = std::find_if(
      deployed->role_relations.begin(), deployed->role_relations.end(),
      [](const auto& relation) {
        return relation.relation == MetricRoleRelationKindV1::subject;
      });
  deployed_subject->other_role = deployed_role;

  auto nominal = role(
      MetricSupportRoleV1::nominal_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::not_a_metric_result,
      MetricEvidenceScopeV1::nominal_static_proposal);
  nominal.role_relations.push_back(
      {MetricRoleRelationKindV1::lineage_parent,
       MetricSupportRoleV1::raw_response});
  nominal.internal_relations.push_back(
      {MetricRoleRelationKindV1::binding,
       InternalReferencePurposeV1::completion_policy});

  auto center = role(
      MetricSupportRoleV1::projection_center,
      MetricTargetScopeV1::ordered_construction_targets,
      MetricResultScopeV1::not_a_metric_result,
      MetricEvidenceScopeV1::projection_center);
  center.internal_relations.push_back(
      {MetricRoleRelationKindV1::lineage_parent,
       InternalReferencePurposeV1::projection_source});

  auto mean = role(
      MetricSupportRoleV1::projected_mean,
      MetricTargetScopeV1::ordered_construction_targets,
      MetricResultScopeV1::not_a_metric_result,
      MetricEvidenceScopeV1::projected_surrogate_mean);
  mean.role_relations.push_back(
      {MetricRoleRelationKindV1::lineage_parent,
       MetricSupportRoleV1::projection_center});
  mean.internal_relations.push_back(
      {MetricRoleRelationKindV1::binding,
       InternalReferencePurposeV1::projection_policy});

  auto recoded = role(
      MetricSupportRoleV1::recoded_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::not_a_metric_result,
      MetricEvidenceScopeV1::recoded_static_proposal);
  recoded.role_relations = {
      {MetricRoleRelationKindV1::lineage_parent,
       MetricSupportRoleV1::nominal_response},
      {MetricRoleRelationKindV1::lineage_parent,
       MetricSupportRoleV1::projected_mean}};
  recoded.internal_relations.push_back(
      {MetricRoleRelationKindV1::binding,
       InternalReferencePurposeV1::recoding_policy});

  clause.required_roles.push_back(std::move(nominal));
  clause.required_roles.push_back(std::move(center));
  clause.required_roles.push_back(std::move(mean));
  clause.required_roles.push_back(std::move(recoded));
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const MetricSupportRoleRequirementV1& left,
               const MetricSupportRoleRequirementV1& right) {
              return metric_support_role_rank_v1(left.role) <
                     metric_support_role_rank_v1(right.role);
            });
  return std::move(
             MetricSupportManifest::from_clauses({std::move(clause)}))
      .value();
}

[[nodiscard]] inline PlugDescriptorCore scalar_core(
    const SurrogateProviderManifestV1& manifest,
    const std::vector<QueueId>& targets) {
  PlugDescriptorCore core{
      1U,
      manifest.provider,
      manifest.optimizer_constraint_applicability,
      manifest.payload_class,
      manifest.deployed_semantic_tag,
      manifest.runtime_access_tag,
      targets,
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog,
        FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{MetricMarkKindV1::actual_departure,
        MetricRevealStageV1::completed_edge,
        {"service.bit", 1U},
        ""}},
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::no_arrival_composition,
       false,
       std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {TailRepresentationKindV1::constant_response, BigNat{3U},
       std::nullopt},
      manifest.target_and_arrival_scientific_prerequisites
          .arrival_assumptions,
      manifest.metric_clause_upper_envelope.clauses().front().hypotheses,
      {V0DeclarationKindV1::structural_witness_required,
       "c16.fixture.v0", 1U},
      {},
      {AnalyticAccuracyV1{BigNat{128U}, {}}},
      {ConstructionResultScopeV1::surrogate_law,
       ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest.metric_clause_upper_envelope.canonical_digest(),
      digest("c16.fixture.core.placeholder")};
  core.core_digest =
      std::move(canonical_plug_descriptor_core_digest_v1(core)).value();
  return core;
}

[[nodiscard]] inline PlugDescriptor runtime_descriptor(
    const PlugDescriptorCore& core) {
  std::vector<RuntimeStateFieldV1> fields;
  fields.reserve(core.state_fields.size());
  for (std::size_t index = 0U; index < core.state_fields.size(); ++index) {
    fields.push_back({RuntimeFieldIdV1(label("field." +
                                                  std::to_string(index))),
                      core.state_fields[index], RuntimeDomainKindV1::countable});
  }
  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    marks.push_back({RuntimeMarkIdV1(label("mark." +
                                                std::to_string(index))),
                     core.marks[index],
                     RuntimeDecoderIdV1(label("decoder." +
                                                   std::to_string(index))),
                     MarkDecoderSourceV1::decision_schedule,
                     RuntimeDomainKindV1::finite,
                     {"schedule.realization", 1U},
                     {},
                     {}});
  }
  PlugDescriptor descriptor{
      1U,
      core,
      std::move(fields),
      std::nullopt,
      std::nullopt,
      std::move(marks),
      std::nullopt,
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity,
        CertificateLevelV1::v0_shape,
        CodecIdentityV1{core.mandatory_v0.factor_schema_id,
                        core.mandatory_v0.factor_schema_version}}},
      std::nullopt,
      digest("c16.fixture.runtime-descriptor.placeholder")};
  descriptor.descriptor_digest =
      std::move(canonical_plug_descriptor_digest_v1(descriptor)).value();
  return descriptor;
}

[[nodiscard]] inline KernelAccess scalar_access(
    const PlugDescriptorCore& core) {
  FiniteParameterAnalyticFamilyAccessShapeV1 shape{
      core.state_fields.front().codec,
      {"mwperf.c16.three_bin_service_response", 1U}};
  return FiniteParameterAnalyticFamilyAccess(
      std::move(shape),
      {"mwperf.c16.three_bin_scalar_response", 1U,
       {"mwperf.c16.three_bin_coefficients", 1U},
       core.state_fields.front().codec},
      [](const CanonicalRuntimeValueV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {{"mwperf.c16.three_bin_service_response", 1U},
             {std::byte{0x01}}});
      });
}

[[nodiscard]] inline Diagnostic fixture_error(std::string code,
                                              std::string message) {
  return {DiagnosticCategory::input_validation, std::move(code),
          std::move(message), std::nullopt, std::nullopt, {}};
}

}  // namespace c16_fixture_detail

[[nodiscard]] inline SurrogateProviderManifestV1 c16_test_manifest(
    std::string provider_id, const ServiceFamily family,
    const OptimizerId optimizer, const ConstructionMethodV1 method,
    const ProducerModeV1 mode, const bool default_selection = true,
    std::optional<LocalExecutableDeclarationV1> local = std::nullopt) {
  using namespace c16_fixture_detail;
  const SchedulerConstraintPairV1 pair{family, optimizer};
  const auto manifest = scalar_manifest(pair);
  SurrogateProviderManifestV1 value{
      1U,
      {std::move(provider_id), "1.0.0"},
      default_selection,
      digest("c16.fixture.source-build"),
      method,
      mode,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      1U,
      digest("c16.fixture.parameter-schema"),
      {1U},
      {1U},
      {1U},
      {},
      {{pair}, {TimingConvention::early_service_late_admission}},
      {1U, 1U, {TargetCouplingV1::scalar_target},
       {target_intensity_assumption()}},
      manifest,
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::deployed_response,
       MetricSupportRoleV1::raw_response,
       MetricSupportRoleV1::reported_validity_or_lift_evidence},
      {{"c16.fixture.evidence", 1U, 4096U}},
      {{"c16.fixture.evidence", 1U, 1U, label("c16.conformance"),
        digest("c16.fixture.conformance")}},
      {1U,
       {PointDeploymentPolicyV1::deploy_raw_point},
       {CoefficientCompletionPolicyV1::require_complete_raw_points},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      std::move(local),
      {1U << 20U, 1U << 20U},
      digest("c16.fixture.manifest.placeholder")};
  if (value.provider.provider_id == "c16.fixture.mwis.engineered") {
    value.required_method_counters = {
        {"integration_evaluations", BigNat{7U}}};
  }
  value.manifest_digest = std::move(digest_provider_manifest_v1(value)).value();
  return value;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1 c16_test_registration(
    SurrogateProviderManifestV1 manifest,
    std::vector<std::byte> completed_bytes =
        {std::byte{'{'}, std::byte{'}'}}) {
  using namespace c16_fixture_detail;
  const auto manifest_for_preview = manifest;
  const auto mode = manifest.producer_mode;
  ParameterValidatorV1 parameters =
      [invocation_count = 0U](const SourceNode& source) mutable {
    if (++invocation_count != 1U) {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          "c16.fixture.warm_parameter_validator",
          "the framework reused mutable parameter-validator closure state"));
    }
    const auto members = source.object_members();
    const SourceNode* resolution_level = source.find("resolution_level");
    if (resolution_level == nullptr) {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          members.empty() ? "c16.fixture.parameter_missing"
                          : "c16.fixture.parameter_unknown",
          members.empty()
              ? "the fixture requires parameter resolution_level"
              : "the fixture parameter object contains an unknown member"));
    }
    if (members.size() != 1U) {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          "c16.fixture.parameter_unknown",
          "the fixture parameter object contains an unknown member"));
    }
    if (resolution_level->kind() != SourceNodeKind::number) {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          "c16.fixture.parameter_wrong_type",
          "fixture parameter resolution_level must be an integer"));
    }
    const std::string& lexeme = *resolution_level->number_lexeme();
    if (lexeme.size() != 1U || lexeme.front() < '1' ||
        lexeme.front() > '8') {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          "c16.fixture.parameter_out_of_domain",
          "fixture parameter resolution_level must lie in [1,8]"));
    }
    const std::string canonical =
        std::string("{\"resolution_level\":") + lexeme + "}";
    return Result<ValidatedParameterPayloadV1>::success(
        ValidatedParameterPayloadV1{
            std::vector<std::byte>(
                reinterpret_cast<const std::byte*>(canonical.data()),
                reinterpret_cast<const std::byte*>(canonical.data() +
                                                   canonical.size())),
            std::make_shared<const std::uint32_t>(
                static_cast<std::uint32_t>(lexeme.front() - '0'))});
  };
  DescriptorPreviewerV1 previewer =
      [manifest_for_preview,
       invocation_count = 0U](const FrameworkProblemView& problem,
                              const MetricRequirements&,
                              const ConstructionBudget& budget,
                              const ValidatedSurrogateParameters& parameters)
          mutable {
        preview_calls().fetch_add(1U, std::memory_order_relaxed);
        if (++invocation_count != 1U) {
          return Result<PlugDescriptorPreview>::failure(fixture_error(
              "c16.fixture.warm_previewer",
              "the framework reused mutable previewer closure state"));
        }
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        if (problem.target_selection().ordered_targets.size() != 1U) {
          return Result<PlugDescriptorPreview>::failure(fixture_error(
              "c16.fixture.requires_single_target",
              "the three-bin provider fixture requires one deployed target"));
        }
        auto manifest_owner = std::make_shared<const MetricSupportManifest>(
            manifest_for_preview.metric_clause_upper_envelope);
        ConstructionPrerequisitesV1 construction_prerequisites{};
        const auto& registered_arrival =
            manifest_for_preview.target_and_arrival_scientific_prerequisites
                .arrival_assumptions;
        std::copy_if(registered_arrival.begin(), registered_arrival.end(),
                     std::back_inserter(construction_prerequisites.arrival),
                     [](const ArrivalAssumptionV1& assumption) {
                       return assumption.use ==
                              ArrivalCapabilityUseV1::construction;
                     });
        if (manifest_for_preview.provider.provider_id ==
            "c16.fixture.context.exact") {
          construction_prerequisites.required_optimizer_calls.emplace(1U);
        }
        PlugDescriptorPreview preview{
            1U,
            scalar_core(manifest_for_preview,
                        problem.target_selection().ordered_targets),
            manifest_for_preview.construction_method,
            manifest_for_preview.producer_mode,
            problem.target_selection().ordered_targets,
            {PointDeploymentPolicyV1::deploy_raw_point,
             CoefficientCompletionPolicyV1::require_complete_raw_points,
             ProjectionPolicyV1::not_applicable,
             RecodingPolicyV1::not_applicable,
             EvidenceRolePolicyV1::exact_manifest_roles},
            std::move(construction_prerequisites),
            std::move(manifest_owner),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.fixture.preview.placeholder")};
        preview.preview_digest =
            std::move(canonical_plug_descriptor_preview_digest_v1(preview))
                .value();
        return Result<PlugDescriptorPreview>::success(std::move(preview));
      };
  ProviderProducerV1 producer = InlineImmediateProducerV1{
      [completed_bytes,
       invocation_count = 0U](const SurrogateBuildRequest&) mutable {
        if (++invocation_count != 1U) {
          return ProviderExecutionOutcome(FailedProviderExecution{
              fixture_error(
                  "c16.fixture.warm_inline_producer",
                  "the framework reused mutable inline-producer closure state")});
        }
        construction_calls().fetch_add(1U, std::memory_order_relaxed);
        return ProviderExecutionOutcome(
            CompletedProviderExecution{completed_bytes});
      }};
  if (mode == ProducerModeV1::in_process_builder) {
    producer = InProcessBuilderV1{
        [completed_bytes, invocation_count = 0U](
            const SurrogateBuildRequest&, BuildExecutionContext&) mutable {
          if (++invocation_count != 1U) {
            return ProviderExecutionOutcome(FailedProviderExecution{
                fixture_error(
                    "c16.fixture.warm_in_process_producer",
                    "the framework reused mutable in-process producer closure state")});
          }
          construction_calls().fetch_add(1U, std::memory_order_relaxed);
          return ProviderExecutionOutcome(
              CompletedProviderExecution{completed_bytes});
        }};
  }
  RuntimePlugMaterializerV1 materializer =
      [invocation_count = 0U](
          const PortablePlugPayload& payload,
          const ValidatedSurrogateArtifact& artifact,
          const AcceptedCapabilityContract&) mutable {
        if (++invocation_count != 1U) {
          return Result<RuntimePlugCandidateV1>::failure(fixture_error(
              "c16.fixture.warm_materializer",
              "the framework reused mutable materializer closure state"));
        }
        materializer_calls().fetch_add(1U, std::memory_order_relaxed);
        const PlugDescriptor descriptor =
            runtime_descriptor(artifact.value().deployed_descriptor);
        SurrogatePlug plug = ScalarBacklogResponsePlugV1{
            payload, scalar_access(artifact.value().deployed_descriptor)};
        return Result<RuntimePlugCandidateV1>::success(
            RuntimePlugCandidateV1{descriptor, std::move(plug)});
      };
  return {std::move(manifest), std::move(parameters), std::move(previewer),
          std::move(producer), std::move(materializer), std::nullopt};
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c16_profile_registration(SurrogateProviderManifestV1 manifest) {
  using namespace c16_fixture_detail;
  auto registration = c16_test_registration(manifest);
  registration.producer = InProcessBuilderV1{
      [manifest = std::move(manifest)](const SurrogateBuildRequest& request,
                                       BuildExecutionContext&) {
        construction_calls().fetch_add(1U, std::memory_order_relaxed);
        return c16_flow_fixture::serialized(
            c16_flow_fixture::built_result(request, manifest));
      }};
  return registration;
}

// C27 planning fixture with two authored throughput clauses over one
// deployed scalar law.  It exists solely to exercise deterministic
// dependency sharing; the ordinary C16 scalar fixtures intentionally keep a
// one-clause upper envelope.
[[nodiscard]] inline SurrogateProviderManifestV1
c27_shared_throughput_manifest(std::string provider_id) {
  auto manifest = c16_test_manifest(
      std::move(provider_id), ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact, ConstructionMethodV1::closed_form,
      ProducerModeV1::inline_immediate);
  MetricSupportClauseV1 first =
      manifest.metric_clause_upper_envelope.clauses().front();
  MetricSupportClauseV1 second = first;
  first.clause_id = {"throughput-a", 0U};
  second.clause_id = {"throughput-b", 1U};
  auto support = MetricSupportManifest::from_clauses(
      {std::move(first), std::move(second)});
  if (!support) {
    throw std::logic_error(support.error().code + ": " +
                           support.error().message);
  }
  manifest.metric_clause_upper_envelope = std::move(support).value();
  auto sealed = digest_provider_manifest_v1(manifest);
  if (!sealed) {
    throw std::logic_error(sealed.error().code + ": " +
                           sealed.error().message);
  }
  manifest.manifest_digest = std::move(sealed).value();
  return manifest;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c27_shared_throughput_registration() {
  return c16_test_registration(c27_shared_throughput_manifest(
      "c27.fixture.shared-throughput"));
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c27_shared_throughput_built_registration() {
  using namespace c16_fixture_detail;
  auto manifest = c27_shared_throughput_manifest(
      "c27.fixture.shared-throughput-built");
  auto registration = c16_test_registration(manifest);
  registration.producer = InlineImmediateProducerV1{
      [manifest = std::move(manifest)](const SurrogateBuildRequest& request) {
        construction_calls().fetch_add(1U, std::memory_order_relaxed);
        return c16_flow_fixture::serialized(
            c16_flow_fixture::built_result(request, manifest));
      }};
  return registration;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c27_shared_throughput_unavailable_registration() {
  using namespace c16_fixture_detail;
  auto manifest = c27_shared_throughput_manifest(
      "c27.fixture.shared-throughput-unavailable");
  auto registration = c16_test_registration(manifest);
  registration.producer = InlineImmediateProducerV1{
      [](const SurrogateBuildRequest& request) {
        construction_calls().fetch_add(1U, std::memory_order_relaxed);
        auto report = c16_flow_fixture::report(request);
        if (!report) {
          return ProviderExecutionOutcome(
              FailedProviderExecution{report.error()});
        }
        return c16_flow_fixture::serialized(
            Result<SurrogateBuildResult>::success(
                UnavailableSurrogateResultV1{
                    {1U, request.request_digest().value(),
                     request.provider_binding().provider,
                     std::move(report).value()},
                    {{UnavailableReasonKindV1::coefficient_unresolved,
                      "c27.fixture.shared_unavailable.throughput_a",
                      "the first synthetic throughput coefficient is unresolved",
                      MetricClauseIdV1{"throughput-a", 0U},
                      c16_flow_fixture::object(
                          "c27.fixture.shared_unavailable.subject")},
                     {UnavailableReasonKindV1::required_evidence_unavailable,
                      "c27.fixture.shared_unavailable.throughput_b",
                      "the second synthetic throughput clause lacks required evidence",
                      MetricClauseIdV1{"throughput-b", 1U},
                      std::nullopt}},
                    std::nullopt}));
      }};
  return registration;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c16_preview_purity_registration() {
  using namespace c16_fixture_detail;
  auto manifest = c16_test_manifest(
      "c16.fixture.preview.purity", ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact,
      ConstructionMethodV1::engineered_deterministic,
      ProducerModeV1::in_process_builder);
  auto registration = c16_test_registration(manifest);
  registration.producer = InProcessBuilderV1{
      [](const SurrogateBuildRequest&, BuildExecutionContext&) {
        auto& counters = preview_purity_counters();
        counters.artifact_reads.fetch_add(1U, std::memory_order_relaxed);
        counters.process_launches.fetch_add(1U, std::memory_order_relaxed);
        counters.optimizer_calls.fetch_add(1U, std::memory_order_relaxed);
        counters.row_calls.fetch_add(1U, std::memory_order_relaxed);
        counters.sample_calls.fetch_add(1U, std::memory_order_relaxed);
        counters.decoder_calls.fetch_add(1U, std::memory_order_relaxed);
        return ProviderExecutionOutcome(FailedProviderExecution{
            fixture_error("c16.fixture.preview_reached_producer",
                          "preview purity fixture reached its producer")});
      }};
  registration.materializer =
      [](const PortablePlugPayload&, const ValidatedSurrogateArtifact&,
         const AcceptedCapabilityContract&) {
        auto& counters = preview_purity_counters();
        counters.artifact_reads.fetch_add(1U, std::memory_order_relaxed);
        counters.row_calls.fetch_add(1U, std::memory_order_relaxed);
        counters.sample_calls.fetch_add(1U, std::memory_order_relaxed);
        counters.decoder_calls.fetch_add(1U, std::memory_order_relaxed);
        return Result<RuntimePlugCandidateV1>::failure(fixture_error(
            "c16.fixture.preview_reached_materializer",
            "preview purity fixture reached its materializer"));
      };
  return registration;
}

[[nodiscard]] inline SurrogateProviderManifestV1 c16_designated_manifest(
    std::string provider_id,
    const PointDeploymentPolicyV1 point_deployment,
    const MetricSupportRoleV1 deployed_role) {
  using namespace c16_fixture_detail;
  const SchedulerConstraintPairV1 pair{
      ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact};
  auto value = c16_test_manifest(
      std::move(provider_id), pair.service_family, pair.optimizer,
      ConstructionMethodV1::closed_form,
      ProducerModeV1::inline_immediate);
  value.metric_clause_upper_envelope =
      designated_scalar_manifest(pair, deployed_role);
  value.allowed_metric_support_roles = {
      MetricSupportRoleV1::deployed_payload,
      MetricSupportRoleV1::deployed_response,
      MetricSupportRoleV1::raw_response,
      MetricSupportRoleV1::nominal_response,
      MetricSupportRoleV1::projection_center,
      MetricSupportRoleV1::projected_mean,
      MetricSupportRoleV1::recoded_response,
      MetricSupportRoleV1::reported_validity_or_lift_evidence};
  value.scientific_construction_policy_schema = {
      1U,
      {point_deployment},
      {CoefficientCompletionPolicyV1::declared_nominal_completion},
      {ProjectionPolicyV1::convex_feasible_mean},
      {RecodingPolicyV1::mean_inversion},
      {EvidenceRolePolicyV1::exact_manifest_roles},
      {},
      {}};
  value.manifest_digest = std::move(digest_provider_manifest_v1(value)).value();
  return value;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c16_designated_registration(SurrogateProviderManifestV1 manifest,
                            const PointDeploymentPolicyV1 point_deployment) {
  using namespace c16_fixture_detail;
  auto registration = c16_test_registration(manifest);
  const auto manifest_for_preview = manifest;
  registration.previewer =
      [manifest_for_preview, point_deployment](
          const FrameworkProblemView& problem, const MetricRequirements&,
          const ConstructionBudget& budget,
          const ValidatedSurrogateParameters& parameters) {
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        if (problem.target_selection().ordered_targets.size() != 1U) {
          return Result<PlugDescriptorPreview>::failure(fixture_error(
              "c16.fixture.requires_single_target",
              "the designated three-bin fixture requires one deployed target"));
        }
        std::vector<QueueId> construction_targets;
        construction_targets.reserve(problem.queues().size());
        for (const auto& entry : problem.queues()) {
          construction_targets.push_back(entry.queue_id);
        }
        auto manifest_owner = std::make_shared<const MetricSupportManifest>(
            manifest_for_preview.metric_clause_upper_envelope);
        PlugDescriptorPreview preview{
            1U,
            scalar_core(manifest_for_preview,
                        problem.target_selection().ordered_targets),
            manifest_for_preview.construction_method,
            manifest_for_preview.producer_mode,
            std::move(construction_targets),
            {point_deployment,
             CoefficientCompletionPolicyV1::declared_nominal_completion,
             ProjectionPolicyV1::convex_feasible_mean,
             RecodingPolicyV1::mean_inversion,
             EvidenceRolePolicyV1::exact_manifest_roles},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(manifest_owner),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.fixture.designated.preview.placeholder")};
        auto sealed = canonical_plug_descriptor_preview_digest_v1(preview);
        if (!sealed) {
          return Result<PlugDescriptorPreview>::failure(sealed.error());
        }
        preview.preview_digest = std::move(sealed).value();
        return Result<PlugDescriptorPreview>::success(std::move(preview));
      };
  return registration;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c16_search_product_registration() {
  using namespace c16_fixture_detail;
  auto manifest = c16_test_manifest(
      "c16.fixture.search-product", ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact,
      ConstructionMethodV1::closed_form,
      ProducerModeV1::inline_immediate);
  auto registration = c16_test_registration(manifest);
  const auto manifest_for_preview = manifest;
  registration.previewer =
      [manifest_for_preview](
          const FrameworkProblemView& problem, const MetricRequirements&,
          const ConstructionBudget& budget,
          const ValidatedSurrogateParameters& parameters) {
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        auto manifest_owner = std::make_shared<const MetricSupportManifest>(
            manifest_for_preview.metric_clause_upper_envelope);
        PlugDescriptorPreview preview{
            1U,
            scalar_core(manifest_for_preview,
                        problem.target_selection().ordered_targets),
            manifest_for_preview.construction_method,
            manifest_for_preview.producer_mode,
            problem.target_selection().ordered_targets,
            {PointDeploymentPolicyV1::deploy_raw_point,
             CoefficientCompletionPolicyV1::require_complete_raw_points,
             ProjectionPolicyV1::not_applicable,
             RecodingPolicyV1::not_applicable,
             EvidenceRolePolicyV1::exact_manifest_roles},
            {{}, BigNat{3U}, std::nullopt, BigNat{4U}},
            std::move(manifest_owner),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.fixture.search-product.preview.placeholder")};
        auto sealed = canonical_plug_descriptor_preview_digest_v1(preview);
        if (!sealed) {
          return Result<PlugDescriptorPreview>::failure(sealed.error());
        }
        preview.preview_digest = std::move(sealed).value();
        return Result<PlugDescriptorPreview>::success(std::move(preview));
      };
  return registration;
}

enum class C16FlowOutcomeV1 : std::uint8_t {
  built,
  unavailable,
  failed,
  failed_reserved_contract_code,
  malformed,
};

[[nodiscard]] inline SurrogateProviderManifestV1 c16_flow_manifest(
    std::string provider_id, const ConstructionMethodV1 method,
    const ProducerModeV1 mode) {
  return std::move(c16_flow_fixture::provider_manifest(
                       std::move(provider_id), method, mode))
      .value();
}

[[nodiscard]] inline SurrogateProviderRegistrationV1 c16_flow_registration(
    SurrogateProviderManifestV1 manifest,
    const C16FlowOutcomeV1 outcome) {
  using namespace c16_fixture_detail;
  auto registration = c16_test_registration(manifest);
  const auto manifest_for_preview = manifest;
  registration.previewer =
      [manifest_for_preview](const FrameworkProblemView& problem,
                             const MetricRequirements&,
                             const ConstructionBudget& budget,
                             const ValidatedSurrogateParameters& parameters) {
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        auto core = c16_flow_fixture::descriptor_core(
            manifest_for_preview,
            problem.target_selection().ordered_targets);
        if (!core) {
          return Result<PlugDescriptorPreview>::failure(core.error());
        }
        auto manifest_owner = std::make_shared<const MetricSupportManifest>(
            manifest_for_preview.metric_clause_upper_envelope);
        PlugDescriptorPreview preview{
            1U,
            std::move(core).value(),
            manifest_for_preview.construction_method,
            manifest_for_preview.producer_mode,
            problem.target_selection().ordered_targets,
            {PointDeploymentPolicyV1::deploy_raw_point,
             CoefficientCompletionPolicyV1::require_complete_raw_points,
             ProjectionPolicyV1::not_applicable,
             RecodingPolicyV1::not_applicable,
             EvidenceRolePolicyV1::not_applicable},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(manifest_owner),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.fixture.flow.preview.placeholder")};
        auto sealed =
            canonical_plug_descriptor_preview_digest_v1(preview);
        if (!sealed) {
          return Result<PlugDescriptorPreview>::failure(sealed.error());
        }
        preview.preview_digest = std::move(sealed).value();
        return Result<PlugDescriptorPreview>::success(std::move(preview));
      };

  const auto invoke = [manifest, outcome](const SurrogateBuildRequest& request) {
    construction_calls().fetch_add(1U, std::memory_order_relaxed);
    switch (outcome) {
      case C16FlowOutcomeV1::built:
        return c16_flow_fixture::serialized(
            c16_flow_fixture::built_result(request, manifest));
      case C16FlowOutcomeV1::unavailable:
        return c16_flow_fixture::serialized(
            c16_flow_fixture::unavailable_result(request));
      case C16FlowOutcomeV1::failed:
        return c16_flow_fixture::serialized(
            c16_flow_fixture::failed_result(request));
      case C16FlowOutcomeV1::failed_reserved_contract_code: {
        auto result = c16_flow_fixture::failed_result(request);
        if (result) {
          auto& failed = std::get<FailedSurrogateResultV1>(result.value());
          failed.failure.code = "requirements_not_exactly_accepted";
          failed.failure.message =
              "the provider-authored failure deliberately uses the "
              "framework Built-contract mismatch code";
        }
        return c16_flow_fixture::serialized(std::move(result));
      }
      case C16FlowOutcomeV1::malformed:
        return ProviderExecutionOutcome(CompletedProviderExecution{
            {std::byte{'{'}, std::byte{'n'}, std::byte{'o'}}});
    }
    return ProviderExecutionOutcome(FailedProviderExecution{
        fixture_error("c16.fixture.flow.unreachable",
                      "unreachable synthetic flow outcome")});
  };
  if (manifest.producer_mode == ProducerModeV1::in_process_builder) {
    registration.producer = InProcessBuilderV1{
        [invoke](const SurrogateBuildRequest& request,
                 BuildExecutionContext&) { return invoke(request); }};
  } else {
    registration.producer = InlineImmediateProducerV1{invoke};
  }
  registration.materializer =
      [](const PortablePlugPayload& payload,
         const ValidatedSurrogateArtifact& artifact,
         const AcceptedCapabilityContract&) {
        materializer_calls().fetch_add(1U, std::memory_order_relaxed);
        const PlugDescriptor descriptor =
            runtime_descriptor(artifact.value().deployed_descriptor);
        SurrogatePlug plug = ScalarBacklogResponsePlugV1{
            payload, scalar_access(artifact.value().deployed_descriptor)};
        return Result<RuntimePlugCandidateV1>::success(
            RuntimePlugCandidateV1{descriptor, std::move(plug)});
      };
  return registration;
}

enum class C30FlowOutcomeV1 : std::uint8_t {
  built,
  unavailable,
  failed,
  branch_decode_failure,
  invalid_common_report,
};

[[nodiscard]] inline Result<SurrogateBuildResultV2> c30_flow_result(
    const SurrogateBuildRequest& request,
    const SurrogateProviderManifestV1& manifest,
    const C30FlowOutcomeV1 outcome) {
  const auto envelope_v2 = [](ResultEnvelopeV1 envelope) {
    return ResultEnvelopeV2{
        2U, envelope.request_digest, std::move(envelope.provider),
        std::move(envelope.build_report),
        c30::envelope_for(c30::exact_gap_bundle())};
  };
  if (outcome == C30FlowOutcomeV1::unavailable) {
    auto source = c16_flow_fixture::unavailable_result(request);
    if (!source) {
      return Result<SurrogateBuildResultV2>::failure(source.error());
    }
    auto value = std::get<UnavailableSurrogateResultV1>(
        std::move(source).value());
    return Result<SurrogateBuildResultV2>::success(
        UnavailableSurrogateResultV2{
            envelope_v2(std::move(value.envelope)),
            std::move(value.reasons),
            std::move(value.strongest_truthful_alternative)});
  }
  if (outcome == C30FlowOutcomeV1::failed) {
    auto source = c16_flow_fixture::failed_result(request);
    if (!source) {
      return Result<SurrogateBuildResultV2>::failure(source.error());
    }
    auto value =
        std::get<FailedSurrogateResultV1>(std::move(source).value());
    return Result<SurrogateBuildResultV2>::success(
        FailedSurrogateResultV2{
            envelope_v2(std::move(value.envelope)),
            std::move(value.failure)});
  }
  auto source = c16_flow_fixture::built_result(request, manifest);
  if (!source) {
    return Result<SurrogateBuildResultV2>::failure(source.error());
  }
  auto value = std::get<BuiltSurrogateResultV1>(std::move(source).value());
  if (outcome == C30FlowOutcomeV1::invalid_common_report) {
    // Keep the v2 outer envelope and observation byte-valid while making the
    // common report reach and fail its request-bound semantic validation. This
    // exercises the F3 rule that pre-envelope/common-report failures retain
    // no diagnostic supplement.
    auto& report = value.envelope.build_report;
    report.request_digest = c16_fixture_detail::digest(
        "c30.fixture.flow.invalid-common-report.foreign-request");
    auto sealed = canonical_common_build_report_digest_v1(report);
    if (!sealed) {
      return Result<SurrogateBuildResultV2>::failure(sealed.error());
    }
    report.report_digest = std::move(sealed).value();
  }
  return Result<SurrogateBuildResultV2>::success(
      BuiltSurrogateResultV2{envelope_v2(std::move(value.envelope)),
                             std::move(value.artifact)});
}

[[nodiscard]] inline ProviderExecutionOutcome c30_serialized_flow_result(
    Result<SurrogateBuildResultV2> result,
    const bool corrupt_built_branch) {
  if (!result) {
    return FailedProviderExecution{result.error()};
  }
  auto bytes = artifact::detail::canonical_surrogate_build_result_bytes_v2(
      result.value());
  if (!bytes) {
    return FailedProviderExecution{bytes.error()};
  }
  if (corrupt_built_branch) {
    std::string text(
        reinterpret_cast<const char*>(bytes.value().data()),
        bytes.value().size());
    constexpr std::string_view valid{"\"artifact_protocol_version\":1"};
    constexpr std::string_view invalid{
        "\"artifact_protocol_version\":\"broken\""};
    const std::size_t position = text.find(valid);
    if (position == std::string::npos ||
        text.find(valid, position + valid.size()) != std::string::npos) {
      return FailedProviderExecution{c16_fixture_detail::fixture_error(
          "c30.fixture.branch_mutation_failed",
          "the result-v2 fixture could not uniquely locate its Built branch")};
    }
    text.replace(position, valid.size(), invalid);
    const auto view = std::as_bytes(std::span(text.data(), text.size()));
    return CompletedProviderExecution{
        std::vector<std::byte>(view.begin(), view.end())};
  }
  return CompletedProviderExecution{std::move(bytes).value()};
}

[[nodiscard]] inline SurrogateProviderRegistrationV1
c30_observation_flow_registration(SurrogateProviderManifestV1 manifest,
                                  const C30FlowOutcomeV1 outcome) {
  using namespace c16_fixture_detail;
  auto registration = c16_flow_registration(manifest,
                                             C16FlowOutcomeV1::built);
  registration.producer = InlineImmediateProducerV1{
      [manifest = std::move(manifest), outcome](
          const SurrogateBuildRequest& request) {
        construction_calls().fetch_add(1U, std::memory_order_relaxed);
        return c30_serialized_flow_result(
            c30_flow_result(request, manifest, outcome),
            outcome == C30FlowOutcomeV1::branch_decode_failure);
      }};
  registration.result_protocol_version = 2U;
  registration.observation_envelope_validator =
      [](const ObservationEnvelopeValidationContextV1& context,
         const ValidatedConstructionObservationBundleV1* observation) {
        if (!context.observation_was_present || observation == nullptr) {
          return Result<void>::failure(fixture_error(
              "c30.fixture.observation_missing",
              "the C30 execution fixture requires an observation sidecar"));
        }
        return Result<void>::success();
      };
  return registration;
}

[[nodiscard]] inline std::vector<SurrogateProviderRegistrationV1>
c16_test_provider_registrations() {
  std::vector<SurrogateProviderRegistrationV1> result;
  result.reserve(kC16TestProfiles.size() +
                 c16_registered_pair_matrix::kProfiles.size() + 40U);
  for (const auto& profile : kC16TestProfiles) {
    result.push_back(c16_profile_registration(c16_test_manifest(
        std::string(profile.provider_id), profile.family, profile.optimizer,
        profile.construction_method, ProducerModeV1::in_process_builder)));
  }
  for (std::size_t index = 0U;
       index < c16_registered_pair_matrix::kProfiles.size(); ++index) {
    const auto& profile = c16_registered_pair_matrix::kProfiles[index];
    auto manifest = c16_registered_pair_matrix::bind_manifest(
        c16_test_manifest(
            std::string(profile.provider_id),
            ServiceFamily::pairwise_conflicts,
            OptimizerId::mwis_branch_memo_exact,
            ConstructionMethodV1::closed_form,
            ProducerModeV1::inline_immediate),
        profile);
    result.push_back(c16_registered_pair_matrix::instrument(
        c16_test_registration(std::move(manifest)), index));
  }
  {
    constexpr std::size_t direct_index = 7U;
    const auto& profile =
        c16_registered_pair_matrix::kC27DirectWithoutFactorProfile;
    auto manifest = c16_registered_pair_matrix::bind_manifest(
        c16_test_manifest(
            std::string(profile.provider_id),
            ServiceFamily::pairwise_conflicts,
            OptimizerId::mwis_branch_memo_exact,
            ConstructionMethodV1::closed_form,
            ProducerModeV1::inline_immediate),
        profile);
    auto registration = c16_registered_pair_matrix::instrument_profile(
        c16_test_registration(std::move(manifest)), direct_index, profile);
    registration.framework_activation.reset();
    result.push_back(std::move(registration));
  }
  {
    const auto& profile =
        c16_registered_pair_matrix::kC20EnumerableRomrProfile;
    auto manifest =
        c16_registered_pair_matrix::bind_c20_enumerable_stationary_manifest(
            c16_test_manifest(
            std::string(profile.provider_id),
            ServiceFamily::pairwise_conflicts,
            OptimizerId::mwis_branch_memo_exact,
            ConstructionMethodV1::closed_form,
            ProducerModeV1::inline_immediate));
    result.push_back(
        c16_registered_pair_matrix::instrument_c20_enumerable_romr(
            c16_test_registration(std::move(manifest))));
  }
  {
    const auto& profile =
        c16_registered_pair_matrix::kC20CountableRomrProfile;
    auto manifest = c16_registered_pair_matrix::bind_manifest(
        c16_test_manifest(
            std::string(profile.provider_id),
            ServiceFamily::pairwise_conflicts,
            OptimizerId::mwis_branch_memo_exact,
            ConstructionMethodV1::closed_form,
            ProducerModeV1::inline_immediate),
        profile);
    result.push_back(
        c16_registered_pair_matrix::instrument_c20_enumerable_romr(
            c16_test_registration(std::move(manifest))));
  }
  {
    auto manifest =
        c16_registered_pair_matrix::bind_c20_reset_manifest(
            c16_test_manifest(
                std::string(c16_registered_pair_matrix::
                                kC20ResetRomrProfile.provider_id),
                ServiceFamily::pairwise_conflicts,
                OptimizerId::mwis_branch_memo_exact,
                ConstructionMethodV1::closed_form,
                ProducerModeV1::inline_immediate));
    result.push_back(
        c16_registered_pair_matrix::instrument_c20_reset_romr(
            c16_test_registration(std::move(manifest))));
  }
  {
    auto manifest =
        c16_registered_pair_matrix::bind_c27_conditional_reward_manifest(
            c16_test_manifest(
                std::string(c16_registered_pair_matrix::
                                kC27ConditionalRewardProfile.provider_id),
                ServiceFamily::pairwise_conflicts,
                OptimizerId::mwis_branch_memo_exact,
                ConstructionMethodV1::closed_form,
                ProducerModeV1::inline_immediate));
    result.push_back(
        c16_registered_pair_matrix::instrument_c27_conditional_reward(
            c16_test_registration(std::move(manifest))));
  }
  result.push_back(c16_test_registration(c16_test_manifest(
      "c16.fixture.transport.inline", ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact, ConstructionMethodV1::closed_form,
      ProducerModeV1::inline_immediate)));
  result.push_back(c16_test_registration(c16_test_manifest(
      "c16.fixture.context.exact", ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact,
      ConstructionMethodV1::engineered_deterministic,
      ProducerModeV1::in_process_builder)));
  result.push_back(c16_preview_purity_registration());
  result.push_back(c27_shared_throughput_registration());
  result.push_back(c27_shared_throughput_built_registration());
  result.push_back(c27_shared_throughput_unavailable_registration());
  result.push_back(c16_coupled_fixture::registration());
  result.push_back(c16_designated_registration(
      c16_designated_manifest(
          "c16.fixture.designated.raw",
          PointDeploymentPolicyV1::deploy_raw_point,
          MetricSupportRoleV1::raw_response),
      PointDeploymentPolicyV1::deploy_raw_point));
  result.push_back(c16_designated_registration(
      c16_designated_manifest(
          "c16.fixture.designated.nominal",
          PointDeploymentPolicyV1::deploy_nominal_point,
          MetricSupportRoleV1::nominal_response),
      PointDeploymentPolicyV1::deploy_nominal_point));
  result.push_back(c16_designated_registration(
      c16_designated_manifest(
          "c16.fixture.designated.recoded",
          PointDeploymentPolicyV1::deploy_recoded_point,
          MetricSupportRoleV1::recoded_response),
      PointDeploymentPolicyV1::deploy_recoded_point));
  result.push_back(c16_search_product_registration());
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.closed-form",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::built));
  // C27 stability guard: this otherwise ordinary ThreeBin fixture emits the
  // exact unit-service response mu(1)=mu(2)=c=1.  Its integration test binds
  // an independently authored batch-arrival law with mean 3/2.
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c27.fixture.flow.unit-service",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::built));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.precomputed",
                        ConstructionMethodV1::precomputed,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::built));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.in-process",
                        ConstructionMethodV1::engineered_deterministic,
                        ProducerModeV1::in_process_builder),
      C16FlowOutcomeV1::built));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.unavailable",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::unavailable));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.failed",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::failed));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c27.fixture.flow.failed-reserved-code",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::failed_reserved_contract_code));
  result.push_back(c16_flow_registration(
      c16_flow_manifest("c16.fixture.flow.malformed",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C16FlowOutcomeV1::malformed));
  result.push_back(c30_observation_flow_registration(
      c16_flow_manifest("c30.fixture.flow.built",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C30FlowOutcomeV1::built));
  result.push_back(c30_observation_flow_registration(
      c16_flow_manifest("c30.fixture.flow.unavailable",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C30FlowOutcomeV1::unavailable));
  result.push_back(c30_observation_flow_registration(
      c16_flow_manifest("c30.fixture.flow.failed",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C30FlowOutcomeV1::failed));
  result.push_back(c30_observation_flow_registration(
      c16_flow_manifest("c30.fixture.flow.branch-decode",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C30FlowOutcomeV1::branch_decode_failure));
  result.push_back(c30_observation_flow_registration(
      c16_flow_manifest("c30.fixture.flow.invalid-common-report",
                        ConstructionMethodV1::closed_form,
                        ProducerModeV1::inline_immediate),
      C30FlowOutcomeV1::invalid_common_report));

#if defined(MWPERF_C16_FLOW_BUILDER_PATH)
  auto local_flow_manifest =
      std::move(c16_flow_fixture::provider_manifest(
                    "c16.fixture.flow.local",
                    ConstructionMethodV1::engineered_deterministic,
                    ProducerModeV1::local_executable_builder,
                    LocalExecutableDeclarationV1{
                        "c16.fixture.flow.local-executable", 1U,
                        {"--request", "{request_path}", "--result",
                         "{result_path}"},
                        true}))
          .value();
  auto local_flow_executable =
      detail::SurrogateRegistryAssembler::executable_spec(
          local_flow_manifest.provider, local_flow_manifest.manifest_digest,
          "c16.fixture.flow.local-executable",
          std::filesystem::path(MWPERF_C16_FLOW_BUILDER_PATH), 1U, {},
          std::chrono::milliseconds(5000), 4096U, 1U << 20U, 1U << 20U);
  if (local_flow_executable) {
    auto local_flow = c16_flow_registration(
        local_flow_manifest, C16FlowOutcomeV1::built);
    local_flow.producer = LocalExecutableBuilderV1{
        std::move(local_flow_executable).value()};
    result.push_back(std::move(local_flow));
  }
#endif

#if defined(MWPERF_C16_TEST_BUILDER_PATH)
  const auto append_local = [&](const std::string& suffix,
                                std::vector<std::string> fixed_arguments,
                                const std::chrono::milliseconds wall_limit,
                                const std::size_t stderr_limit,
                                const std::size_t result_limit) {
    const std::string executable_id = "c16.fixture.builder." + suffix;
    auto local_manifest = c16_test_manifest(
        "c16.fixture.transport.local." + suffix,
        ServiceFamily::pairwise_conflicts,
        OptimizerId::mwis_branch_memo_exact,
        ConstructionMethodV1::sampled_offline,
        ProducerModeV1::local_executable_builder, true,
        LocalExecutableDeclarationV1{
            executable_id, 1U,
            {"--request", "{request_path}", "--result", "{result_path}"},
            true});
    auto executable = detail::SurrogateRegistryAssembler::executable_spec(
        local_manifest.provider, local_manifest.manifest_digest,
        executable_id,
        std::filesystem::path(MWPERF_C16_TEST_BUILDER_PATH), 1U,
        std::move(fixed_arguments), wall_limit, stderr_limit, 1U << 20U,
        result_limit);
    if (executable) {
      auto registration = c16_test_registration(local_manifest);
      registration.producer =
          LocalExecutableBuilderV1{std::move(executable).value()};
      result.push_back(std::move(registration));
    }
  };
  append_local("success", {}, std::chrono::milliseconds(2000), 4096U,
               1U << 20U);
  append_local("wrong-version", {"--mode=wrong-version"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("stdout", {"--mode=stdout"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("nonzero", {"--mode=nonzero"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("stderr", {"--mode=stderr"},
               std::chrono::milliseconds(2000), 8U, 1U << 20U);
  append_local("stderr-large", {"--mode=stderr-large"},
               std::chrono::milliseconds(2000), 96U << 10U, 1U << 20U);
  append_local("timeout", {"--mode=timeout"},
               std::chrono::milliseconds(50), 4096U, 1U << 20U);
  append_local("extra-file", {"--mode=extra-file"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("mutate-request", {"--mode=mutate-request"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("oversize", {"--mode=oversize"},
               std::chrono::milliseconds(2000), 4096U, 1024U);
  append_local("missing-result", {"--mode=missing-result"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("partial-result", {"--mode=partial-result"},
               std::chrono::milliseconds(50), 4096U, 1U << 20U);
  append_local("threaded", {"--mode=threaded"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("clone-policy", {"--mode=clone-policy"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("signal", {"--mode=signal"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("ambient-read-denied", {"--mode=ambient-read-denied"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("ambient-absolute-read-denied",
               {"--mode=ambient-absolute-read-denied"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("ambient-kernel-state-denied",
               {"--mode=ambient-kernel-state-denied"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("ambient-first-virtualized",
               {"--mode=ambient-first-virtualized"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
  append_local("metacharacters",
               {"--mode=success;touch shell-injection-sentinel"},
               std::chrono::milliseconds(2000), 4096U, 1U << 20U);
#endif
  return result;
}

}  // namespace mwperf::testing
