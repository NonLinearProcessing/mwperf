#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_end_to_end_fixture.hpp is available only to C16 tests"
#endif

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "../fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf::testing::c16_flow_fixture {

using Factory = C15ProtocolFixtureFactory;

[[nodiscard]] inline Diagnostic error(std::string code,
                                      std::string message) {
  return {DiagnosticCategory::internal, std::move(code), std::move(message),
          std::nullopt, std::nullopt, {}};
}

[[nodiscard]] inline TypedLabel label(const std::string& value) {
  return std::move(TypedLabel::text(value)).value();
}

[[nodiscard]] inline QueueId queue(const std::string& value) {
  return QueueId(label(value));
}

[[nodiscard]] inline Digest256 digest(const std::string_view value) {
  return std::move(
             sha256(std::as_bytes(std::span(value.data(), value.size()))))
      .value();
}

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  return std::move(
             ExactRational::make(BigInt(numerator), BigInt(denominator)))
      .value();
}

[[nodiscard]] inline PortableScientificScalar scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return PortableScientificScalar::rational(
      rational(numerator, denominator));
}

[[nodiscard]] inline ArtifactObjectReferenceV1 object(
    const std::string& value) {
  return {label(value), digest(value)};
}

[[nodiscard]] inline MetricSupportRoleRequirementV1 role(
    const MetricSupportRoleV1 value,
    const MetricTargetScopeV1 target_scope,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope) {
  return {value, target_scope, result_scope, evidence_scope, {}, {}};
}

[[nodiscard]] inline ArrivalAssumptionV1 target_intensity_assumption() {
  return {ArrivalNeedKindV1::target_intensity,
          ArrivalCapabilityUseV1::runtime,
          CapabilityProvisionNeedV1::any,
          std::nullopt,
          false,
          false,
          std::nullopt,
          std::nullopt,
          std::nullopt};
}

// A deliberately small but fully legitimate three-bin manifest.  It carries
// the deployed payload, selected raw response, and raw product lineage.  No
// evidence role is claimed, so the corresponding policy is not_applicable.
[[nodiscard]] inline Result<MetricSupportManifest> manifest(
    const SchedulerConstraintPairV1& applicability) {
  auto deployed_payload = role(
      MetricSupportRoleV1::deployed_payload,
      MetricTargetScopeV1::payload_targets,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::none);
  auto deployed_response = role(
      MetricSupportRoleV1::deployed_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law);
  deployed_response.role_relations = {
      {MetricRoleRelationKindV1::binding,
       MetricSupportRoleV1::deployed_payload},
      {MetricRoleRelationKindV1::subject,
       MetricSupportRoleV1::raw_response}};
  auto raw_response = role(
      MetricSupportRoleV1::raw_response,
      MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::proposal_raw,
      MetricEvidenceScopeV1::raw_static_proposal);
  raw_response.role_relations = {
      {MetricRoleRelationKindV1::binding,
       MetricSupportRoleV1::deployed_payload}};
  raw_response.internal_relations = {
      {MetricRoleRelationKindV1::lineage_parent,
       InternalReferencePurposeV1::coefficient_origin}};

  MetricSupportClauseV1 clause{
      {"throughput", 0U},
      MetricKindV1::stationary_throughput,
      ExactMetricParameterSetV1{{StationaryThroughputParametersV1{}}},
      {queue("q0")},
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog,
        FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{MetricMarkKindV1::actual_departure,
        MetricRevealStageV1::completed_edge,
        {"service.bit", 1U},
        ""}},
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::no_arrival_composition,
       false,
       std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {target_intensity_assumption()},
      {{HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::lossless, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::moment_finite, MomentVariableV1::arrival,
        BigNat{1U}, std::nullopt}},
      SolverRegimeV1::analytic,
      AnalyticAccuracyV1{BigNat{128U}, {}},
      {StructuralErrorFormV1::exact, MetricEvidenceScopeV1::none,
       ExactRational::zero()},
      MetricResultScopeV1::surrogate_law,
      {V0DeclarationKindV1::structural_witness_required,
       "c16.fixture.v0", 1U},
      {std::move(deployed_payload), std::move(deployed_response),
       std::move(raw_response)}};
  (void)applicability;
  return MetricSupportManifest::from_clauses({std::move(clause)});
}

[[nodiscard]] inline Result<SurrogateProviderManifestV1> provider_manifest(
    std::string provider_id, const ConstructionMethodV1 method,
    const ProducerModeV1 mode,
    std::optional<LocalExecutableDeclarationV1> local = std::nullopt) {
  const SchedulerConstraintPairV1 pair{
      ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact};
  auto support = manifest(pair);
  if (!support) {
    return Result<SurrogateProviderManifestV1>::failure(support.error());
  }
  SurrogateProviderManifestV1 value{
      1U,
      {std::move(provider_id), "1.0.0"},
      true,
      digest("c16.fixture.flow.source-build"),
      method,
      mode,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      1U,
      digest("c16.fixture.parameter-schema"),
      {1U},
      {1U},
      {1U},
      {},
      {{pair}, {TimingConvention::early_service_late_admission}},
      {1U, 1U, {TargetCouplingV1::scalar_target},
       {target_intensity_assumption()}},
      std::move(support).value(),
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::deployed_response,
       MetricSupportRoleV1::raw_response},
      {{"c16.fixture.evidence", 1U, 4096U}},
      {{"c16.fixture.evidence", 1U, 1U, label("c16.conformance"),
        digest("c16.fixture.conformance")}},
      {1U,
       {PointDeploymentPolicyV1::deploy_raw_point},
       {CoefficientCompletionPolicyV1::require_complete_raw_points},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::not_applicable},
       {},
       {}},
      std::move(local),
      {1U << 20U, 1U << 20U},
      digest("c16.fixture.flow.manifest.placeholder")};
  auto sealed = digest_provider_manifest_v1(value);
  if (!sealed) {
    return Result<SurrogateProviderManifestV1>::failure(sealed.error());
  }
  value.manifest_digest = std::move(sealed).value();
  return Result<SurrogateProviderManifestV1>::success(std::move(value));
}

[[nodiscard]] inline Result<PlugDescriptorCore> descriptor_core(
    const SurrogateProviderManifestV1& provider,
    const std::span<const QueueId> targets) {
  if (targets.size() != 1U) {
    return Result<PlugDescriptorCore>::failure(error(
        "c16.fixture.flow.target_count",
        "the end-to-end flow fixture requires exactly one target"));
  }
  PlugDescriptorCore core{
      1U,
      provider.provider,
      provider.optimizer_constraint_applicability,
      provider.payload_class,
      provider.deployed_semantic_tag,
      provider.runtime_access_tag,
      {targets.front()},
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog,
        FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{MetricMarkKindV1::actual_departure,
        MetricRevealStageV1::completed_edge,
        {"service.bit", 1U},
        ""}},
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::no_arrival_composition,
       false,
       std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {TailRepresentationKindV1::constant_response, BigNat{3U},
       std::nullopt},
      provider.target_and_arrival_scientific_prerequisites
          .arrival_assumptions,
      provider.metric_clause_upper_envelope.clauses().front().hypotheses,
      {V0DeclarationKindV1::structural_witness_required,
       "c16.fixture.v0", 1U},
      {},
      {AnalyticAccuracyV1{BigNat{128U}, {}}},
      {ConstructionResultScopeV1::surrogate_law,
       ConstructionErrorScopeV1::deployed_surrogate_law},
      provider.metric_clause_upper_envelope.canonical_digest(),
      digest("c16.fixture.flow.core.placeholder")};
  auto sealed = canonical_plug_descriptor_core_digest_v1(core);
  if (!sealed) {
    return Result<PlugDescriptorCore>::failure(sealed.error());
  }
  core.core_digest = std::move(sealed).value();
  return Result<PlugDescriptorCore>::success(std::move(core));
}

[[nodiscard]] inline CommonWorkCounterV1 zero_counter(
    const CountConstructionGrantV1& grant) {
  return {grant.applicability == BudgetApplicabilityV1::applicable
              ? WorkCounterApplicabilityV1::applicable
              : WorkCounterApplicabilityV1::not_applicable,
          BigNat{0U}};
}

// The local test builder intentionally receives only canonical request bytes.
// This value is the exact immutable subset needed to construct the scientific
// result; the parent and child paths therefore share one result constructor
// without introducing a request parser into production.
struct FlowBuildInputsV1 final {
  Digest256 request_digest;
  ProviderIdentityV1 provider;
  Digest256 provider_scientific_contract_digest;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  PayloadClassV1 payload_class;
  QueueId deployed_target;
  Digest256 compiled_arrival_fingerprint;
  MetricSupportManifest structural_manifest;
  ConstructionBudget construction_budget;
  std::optional<Digest256> target_selection_fingerprint;
  std::optional<Digest256> tie_and_timing_fingerprint;
};

[[nodiscard]] inline Result<FlowBuildInputsV1> flow_build_inputs(
    const SurrogateBuildRequest& request) {
  const auto targets =
      request.framework_problem_view().target_selection().ordered_targets;
  if (targets.size() != 1U) {
    return Result<FlowBuildInputsV1>::failure(error(
        "c16.fixture.flow.target_count",
        "the end-to-end flow fixture requires exactly one target"));
  }
  return Result<FlowBuildInputsV1>::success(
      {request.request_digest().value(),
       request.provider_binding().provider,
       request.provider_binding().provider_scientific_contract_digest.value(),
       request.classifications().construction_method,
       request.classifications().producer_mode,
       request.classifications().proposed_semantic_tag,
       request.classifications().proposed_access_tag,
       {request.classifications().proposed_payload_tag, 1U},
       targets.front(),
       request.framework_problem_view().fingerprints().compiled_arrival,
       request.accepted_capability_contract()
           .structural_metric_support_manifest,
       request.construction_budget(),
       request.framework_problem_view().fingerprints().target_selection,
       request.framework_problem_view().fingerprints().tie_and_timing});
}

[[nodiscard]] inline Result<CommonBuildReportV1> report(
    const FlowBuildInputsV1& inputs,
    const std::span<const RequiredMethodCounterV1> required_counters = {}) {
  auto budget = digest_construction_budget_v1(inputs.construction_budget);
  if (!budget) {
    return Result<CommonBuildReportV1>::failure(budget.error());
  }
  const auto& grants = inputs.construction_budget;
  std::vector<NamedPortableValueV1> method_counters;
  method_counters.reserve(required_counters.size());
  for (const auto& required : required_counters) {
    auto value = ExactRational::make(required.minimum_used.value(), BigInt{1});
    if (!value) {
      return Result<CommonBuildReportV1>::failure(value.error());
    }
    method_counters.push_back(
        {required.name,
         PortableScientificScalar::rational(std::move(value).value())});
  }
  CommonBuildReportV1 result{
      1U,
      label("c16.fixture.flow.report"),
      digest("c16.fixture.flow.report.placeholder"),
      inputs.request_digest,
      std::move(budget).value(),
      zero_counter(grants.exact_optimizer_calls),
      zero_counter(grants.optimizer_search_states),
      zero_counter(grants.configured_generator_draws),
      {},
      std::move(method_counters)};
  auto sealed = canonical_common_build_report_digest_v1(result);
  if (!sealed) {
    return Result<CommonBuildReportV1>::failure(sealed.error());
  }
  result.report_digest = std::move(sealed).value();
  return Result<CommonBuildReportV1>::success(std::move(result));
}

[[nodiscard]] inline Result<ThreeBinScalarResponseV1> response(
    const FlowBuildInputsV1& inputs,
    const SurrogateProviderManifestV1& provider) {
  if (provider.family_evidence_conformance_report_anchors.size() != 1U ||
      provider.allowed_family_evidence_schemas.size() != 1U) {
    return Result<ThreeBinScalarResponseV1>::failure(error(
        "c16.fixture.flow.invalid_registration",
        "the end-to-end fixture registration is internally inconsistent"));
  }
  const auto& anchor =
      provider.family_evidence_conformance_report_anchors.front();
  const ProviderConformanceReportRef conformance{
      anchor.report_schema_version,
      anchor.report_id,
      anchor.report_digest,
      inputs.provider,
      inputs.provider_scientific_contract_digest,
      anchor.family_evidence_schema_id,
      anchor.family_evidence_schema_version};

  const auto make_identification =
      [&](const std::size_t index,
          const PortableScientificScalar& point)
      -> Result<CoefficientIdentificationV1> {
    CoefficientIdentificationV1 identification{
        object("c16.fixture.flow.coefficient." + std::to_string(index)),
        {ProposalConditioningSourceV1::exact_population, scalar(1, 1),
         std::nullopt},
        {PopulationConditioningStatusV1::proved_positive,
         RawValueStatusV1::exact_point},
        point,
        {},
        conformance,
        std::nullopt,
        static_cast<ThreeBinCoefficientV1>(index)};
    auto sealed = artifact::detail::coefficient_identification_digest_v1(
        identification);
    if (!sealed) {
      return Result<CoefficientIdentificationV1>::failure(sealed.error());
    }
    identification.coefficient_id.object_digest = std::move(sealed).value();
    return Result<CoefficientIdentificationV1>::success(
        std::move(identification));
  };
  const bool unit_service =
      inputs.provider.provider_id == "c27.fixture.flow.unit-service";
  auto first = make_identification(
      0U, unit_service ? scalar(1, 1) : scalar(1, 4));
  auto second = make_identification(
      1U, unit_service ? scalar(1, 1) : scalar(3, 4));
  auto tail = make_identification(
      2U, unit_service ? scalar(1, 1) : scalar(1, 2));
  if (!first) return Result<ThreeBinScalarResponseV1>::failure(first.error());
  if (!second) {
    return Result<ThreeBinScalarResponseV1>::failure(second.error());
  }
  if (!tail) return Result<ThreeBinScalarResponseV1>::failure(tail.error());
  std::array<CoefficientIdentificationV1, 3U> identifications{
      std::move(first).value(), std::move(second).value(),
      std::move(tail).value()};

  RawResponseProductV1 raw{
      Factory::raw_response_product_id(object("c16.fixture.flow.raw")),
      inputs.provider,
      inputs.request_digest,
      inputs.deployed_target,
      inputs.compiled_arrival_fingerprint,
      digest("c16.fixture.flow.proposal-law"),
      std::move(identifications)};
  auto raw_digest = canonical_raw_response_product_digest_v1(raw);
  if (!raw_digest) {
    return Result<ThreeBinScalarResponseV1>::failure(raw_digest.error());
  }
  raw.product_id = Factory::raw_response_product_id(
      {label("c16.fixture.flow.raw"), std::move(raw_digest).value()});

  ThreeBinScalarResponseV1 result{
      1U,
      object("c16.fixture.flow.response-row"),
      inputs.deployed_target,
      inputs.compiled_arrival_fingerprint,
      std::move(raw),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      Factory::raw_response_product_id(
          object("c16.fixture.flow.unsealed-selected")),
      {}};
  result.deployed_response_product_id = result.raw_response.product_id;
  auto row_digest = canonical_three_bin_response_row_digest_v1(result);
  if (!row_digest) {
    return Result<ThreeBinScalarResponseV1>::failure(row_digest.error());
  }
  result.response_row_id.object_digest = std::move(row_digest).value();
  return Result<ThreeBinScalarResponseV1>::success(std::move(result));
}

[[nodiscard]] inline Result<MetricSupportManifestEchoV1> manifest_echo(
    const MetricSupportManifest& support) {
  auto bytes = canonical_metric_support_manifest_bytes_v1(support);
  if (!bytes) {
    return Result<MetricSupportManifestEchoV1>::failure(bytes.error());
  }
  return Result<MetricSupportManifestEchoV1>::success(
      {1U, std::move(bytes).value(), support.canonical_digest()});
}

struct ValidityEvidenceV1 final {
  FamilyEvidenceEnvelopeV1 family;
  ScopedArtifactEvidenceV1 scoped;
  RealizedReferenceCoreV1 realized_core;
};

[[nodiscard]] inline std::vector<std::byte> bytes(
    const std::string_view value) {
  const auto source = std::as_bytes(std::span(value.data(), value.size()));
  return {source.begin(), source.end()};
}

[[nodiscard]] inline Result<std::optional<ValidityEvidenceV1>>
validity_evidence(
    const FlowBuildInputsV1& inputs,
    const SurrogateProviderManifestV1& provider,
    const ThreeBinScalarResponseV1& response_value,
    const ArtifactObjectReferenceV1& payload_identity,
    const Digest256& payload_digest) {
  const auto& clauses = inputs.structural_manifest.clauses();
  if (clauses.empty()) {
    return Result<std::optional<ValidityEvidenceV1>>::failure(error(
        "c16.fixture.flow.clause_count",
        "the end-to-end fixture requires at least one accepted metric clause"));
  }
  const auto& roles = clauses.front().required_roles;
  const auto found = std::find_if(
      roles.begin(), roles.end(), [](const auto& requirement) {
        return requirement.role ==
               MetricSupportRoleV1::reported_validity_or_lift_evidence;
      });
  if (found == roles.end()) {
    return Result<std::optional<ValidityEvidenceV1>>::success(std::nullopt);
  }
  // The C27 dependency-sharing fixture deliberately binds two authored
  // clauses to one immutable deployed law.  A shared validity object is
  // sound only when every clause requests the exact same validity role.
  for (const auto& clause : clauses) {
    const auto candidate = std::find_if(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const auto& requirement) {
          return requirement.role ==
                 MetricSupportRoleV1::reported_validity_or_lift_evidence;
        });
    if (candidate == clause.required_roles.end() || !(*candidate == *found)) {
      return Result<std::optional<ValidityEvidenceV1>>::failure(error(
          "c16.fixture.flow.shared_validity_role_mismatch",
          "clauses sharing the fixture law must require the same validity-evidence role"));
    }
  }
  if (!inputs.target_selection_fingerprint.has_value() ||
      !inputs.tie_and_timing_fingerprint.has_value() ||
      provider.family_evidence_conformance_report_anchors.size() != 1U ||
      provider.allowed_family_evidence_schemas.size() != 1U) {
    return Result<std::optional<ValidityEvidenceV1>>::failure(error(
        "c16.fixture.flow.validity_inputs",
        "the profile validity fixture lacks a request or conformance binding"));
  }

  const auto& anchor =
      provider.family_evidence_conformance_report_anchors.front();
  const ProviderConformanceReportRef conformance{
      anchor.report_schema_version,
      anchor.report_id,
      anchor.report_digest,
      inputs.provider,
      inputs.provider_scientific_contract_digest,
      anchor.family_evidence_schema_id,
      anchor.family_evidence_schema_version};
  auto family_body = bytes(R"json({"claim":"c16-profile-validity"})json");
  auto family_body_digest =
      artifact::detail::family_evidence_body_digest_v1(family_body);
  if (!family_body_digest) {
    return Result<std::optional<ValidityEvidenceV1>>::failure(
        family_body_digest.error());
  }
  FamilyEvidenceEnvelopeV1 family{
      1U,
      object("c16.fixture.flow.family-evidence"),
      anchor.family_evidence_schema_id,
      anchor.family_evidence_schema_version,
      conformance,
      inputs.provider,
      inputs.provider_scientific_contract_digest,
      inputs.request_digest,
      payload_digest,
      {payload_identity, response_value.response_row_id},
      {},
      {inputs.deployed_target},
      MetricEvidenceScopeV1::validity_or_lift,
      std::move(family_body),
      std::move(family_body_digest).value()};
  auto sealed_family =
      artifact::detail::family_evidence_envelope_digest_v1(family);
  if (!sealed_family) {
    return Result<std::optional<ValidityEvidenceV1>>::failure(
        sealed_family.error());
  }
  family.evidence_id.object_digest = std::move(sealed_family).value();

  const auto internal_subject = [&](const InternalReferencePurposeV1 purpose) {
    switch (purpose) {
      case InternalReferencePurposeV1::coordinate_codec:
        return object("c16.fixture.flow.coordinate-codec");
      case InternalReferencePurposeV1::mark_codec:
        return object("c16.fixture.flow.mark-codec");
      case InternalReferencePurposeV1::configured_arrival_binding:
        return ArtifactObjectReferenceV1{
            label("c16.fixture.flow.configured-arrival"),
            inputs.compiled_arrival_fingerprint};
      case InternalReferencePurposeV1::selection_binding:
        return ArtifactObjectReferenceV1{
            label("c16.fixture.flow.selection-binding"),
            *inputs.target_selection_fingerprint};
      case InternalReferencePurposeV1::timing_binding:
        return ArtifactObjectReferenceV1{
            label("c16.fixture.flow.timing-binding"),
            *inputs.tie_and_timing_fingerprint};
      case InternalReferencePurposeV1::validity_basis:
        return object("c16.fixture.flow.validity-basis");
      case InternalReferencePurposeV1::validity_witness:
        return family.evidence_id;
      case InternalReferencePurposeV1::artifact_payload:
        return payload_identity;
      case InternalReferencePurposeV1::law_or_result:
        return response_value.response_row_id;
      default:
        return object("c16.fixture.flow.unsupported-validity-purpose");
    }
  };

  std::vector<RealizedInternalReferenceV1> internal;
  internal.reserve(found->internal_relations.size());
  for (const auto& relation : found->internal_relations) {
    internal.push_back(
        {relation.relation, relation.purpose,
         internal_subject(relation.purpose)});
  }
  RealizedReferenceCoreV1 realized_core{
      {inputs.deployed_target}, found->target_scope, found->result_scope,
      found->evidence_scope, {}, internal};

  std::vector<ArtifactObjectReferenceV1> subjects;
  std::vector<ArtifactObjectReferenceV1> parents;
  for (const auto& relation : realized_core.internal_relations) {
    if (relation.relation == MetricRoleRelationKindV1::subject) {
      subjects.push_back(relation.referenced_object);
    } else if (relation.relation ==
               MetricRoleRelationKindV1::lineage_parent) {
      parents.push_back(relation.referenced_object);
    }
  }
  std::sort(subjects.begin(), subjects.end());
  subjects.erase(std::unique(subjects.begin(), subjects.end()),
                 subjects.end());
  std::sort(parents.begin(), parents.end());
  parents.erase(std::unique(parents.begin(), parents.end()), parents.end());
  ScopedArtifactEvidenceV1 scoped{
      object("c16.fixture.flow.validity-evidence"),
      ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
      {inputs.deployed_target},
      found->result_scope,
      found->evidence_scope,
      std::move(subjects),
      std::move(parents),
      {family.evidence_id},
      internal};
  auto sealed_scoped =
      artifact::detail::scoped_artifact_evidence_digest_v1(scoped);
  if (!sealed_scoped) {
    return Result<std::optional<ValidityEvidenceV1>>::failure(
        sealed_scoped.error());
  }
  scoped.evidence_id.object_digest = std::move(sealed_scoped).value();
  return Result<std::optional<ValidityEvidenceV1>>::success(
      ValidityEvidenceV1{std::move(family), std::move(scoped),
                         std::move(realized_core)});
}

[[nodiscard]] inline Result<BoundRealizedMetricBindingsV1> bindings(
    const FlowBuildInputsV1& inputs,
    const ThreeBinScalarResponseV1& response_value,
    const ArtifactObjectReferenceV1& payload_identity,
    const Digest256& payload_digest,
    const std::optional<ValidityEvidenceV1>& validity) {
  const auto& support = inputs.structural_manifest;
  if (support.clauses().empty()) {
    return Result<BoundRealizedMetricBindingsV1>::failure(error(
        "c16.fixture.flow.clause_count",
        "the end-to-end fixture requires at least one accepted metric clause"));
  }
  const auto target = response_value.deployed_target;
  const auto& raw_identity = response_value.raw_response.product_id.identity();

  std::vector<RealizedMetricBindingV1> realized;
  realized.reserve(support.clauses().size() * (validity ? 4U : 3U));
  for (const MetricSupportClauseV1& support_clause : support.clauses()) {
    const MetricClauseIdV1& clause = support_clause.clause_id;
    const MetricRoleKeyV1 payload_key{
        clause, MetricSupportRoleV1::deployed_payload};
    const MetricRoleKeyV1 deployed_key{
        clause, MetricSupportRoleV1::deployed_response};
    const MetricRoleKeyV1 raw_key{clause,
                                  MetricSupportRoleV1::raw_response};
    realized.push_back(
        {payload_key,
         DeployedPayloadReferenceV1{
             {{target}, MetricTargetScopeV1::payload_targets,
              MetricResultScopeV1::surrogate_law,
              MetricEvidenceScopeV1::none, {}, {}},
             {payload_identity}}});
    realized.push_back(
        {deployed_key,
         DeployedResponseReferenceV1{
             {{target}, MetricTargetScopeV1::deployed_singleton_target,
              MetricResultScopeV1::surrogate_law,
              MetricEvidenceScopeV1::deployed_surrogate_law,
              {{MetricRoleRelationKindV1::binding, payload_key,
                payload_identity},
               {MetricRoleRelationKindV1::subject, raw_key, raw_identity}},
              {}},
             RawResponseProductRef{raw_identity,
                                   ResponseProductValueFormV1::exact_point}}});
    realized.push_back(
        {raw_key,
         RawResponseProductReferenceV1{
             {{target}, MetricTargetScopeV1::deployed_singleton_target,
              MetricResultScopeV1::proposal_raw,
              MetricEvidenceScopeV1::raw_static_proposal,
              {{MetricRoleRelationKindV1::binding, payload_key,
                payload_identity}},
              {{MetricRoleRelationKindV1::lineage_parent,
                InternalReferencePurposeV1::coefficient_origin,
                response_value.raw_response.identifications.front()
                    .coefficient_id}}},
             {raw_identity, ResponseProductValueFormV1::exact_point}}});
    if (validity.has_value()) {
      const MetricRoleKeyV1 validity_key{
          clause,
          MetricSupportRoleV1::reported_validity_or_lift_evidence};
      realized.push_back(
          {validity_key,
           ReportedValidityOrLiftEvidenceReferenceV1{
               validity->realized_core,
               ReportedValidityOrLiftEvidenceRef{
                   validity->scoped.evidence_id}}});
    }
  }
  return Result<BoundRealizedMetricBindingsV1>::success(
      {inputs.request_digest, payload_digest,
       std::move(realized)});
}

[[nodiscard]] inline Result<SurrogateBuildResult> built_result(
    const FlowBuildInputsV1& inputs,
    const SurrogateProviderManifestV1& provider) {
  auto built_report = report(inputs, provider.required_method_counters);
  if (!built_report) {
    return Result<SurrogateBuildResult>::failure(built_report.error());
  }
  auto payload_record = response(inputs, provider);
  if (!payload_record) {
    return Result<SurrogateBuildResult>::failure(payload_record.error());
  }
  ArtifactPayloadV1 payload = payload_record.value();
  auto payload_digest = canonical_artifact_payload_digest_v1(payload);
  if (!payload_digest) {
    return Result<SurrogateBuildResult>::failure(payload_digest.error());
  }
  const ArtifactObjectReferenceV1 payload_identity{
      label("c16.fixture.flow.payload"), payload_digest.value()};
  auto echo = manifest_echo(inputs.structural_manifest);
  if (!echo) {
    return Result<SurrogateBuildResult>::failure(echo.error());
  }
  auto validity = validity_evidence(inputs, provider, payload_record.value(),
                                    payload_identity,
                                    payload_digest.value());
  if (!validity) {
    return Result<SurrogateBuildResult>::failure(validity.error());
  }
  auto realized = bindings(inputs, payload_record.value(), payload_identity,
                           payload_digest.value(), validity.value());
  if (!realized) {
    return Result<SurrogateBuildResult>::failure(realized.error());
  }
  auto core = descriptor_core(
      provider,
      std::span<const QueueId>(&inputs.deployed_target, 1U));
  if (!core) {
    return Result<SurrogateBuildResult>::failure(core.error());
  }

  std::vector<FamilyEvidenceEnvelopeV1> family_evidence;
  std::vector<ScopedArtifactEvidenceV1> scoped_evidence;
  if (validity.value().has_value()) {
    family_evidence.push_back(validity.value()->family);
    scoped_evidence.push_back(validity.value()->scoped);
  }
  SurrogateArtifactV1 artifact{
      1U,
      inputs.request_digest,
      inputs.provider,
      inputs.provider_scientific_contract_digest,
      inputs.construction_method,
      inputs.producer_mode,
      inputs.semantic,
      inputs.runtime_access,
      inputs.payload_class,
      payload_identity,
      std::move(payload),
      payload_digest.value(),
      std::move(echo).value(),
      std::move(realized).value(),
      std::move(core).value(),
      built_report.value(),
      std::move(family_evidence),
      std::move(scoped_evidence),
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  return Result<SurrogateBuildResult>::success(
      BuiltSurrogateResultV1{
          {1U, inputs.request_digest, inputs.provider, built_report.value()},
          std::move(artifact)});
}

[[nodiscard]] inline Result<SurrogateBuildResult> built_result(
    const SurrogateBuildRequest& request,
    const SurrogateProviderManifestV1& provider) {
  auto inputs = flow_build_inputs(request);
  if (!inputs) {
    return Result<SurrogateBuildResult>::failure(inputs.error());
  }
  return built_result(inputs.value(), provider);
}

[[nodiscard]] inline Result<CommonBuildReportV1> report(
    const SurrogateBuildRequest& request) {
  auto inputs = flow_build_inputs(request);
  if (!inputs) {
    return Result<CommonBuildReportV1>::failure(inputs.error());
  }
  return report(inputs.value());
}

[[nodiscard]] inline Result<SurrogateBuildResult> unavailable_result(
    const SurrogateBuildRequest& request) {
  auto built_report = report(request);
  if (!built_report) {
    return Result<SurrogateBuildResult>::failure(built_report.error());
  }
  return Result<SurrogateBuildResult>::success(
      UnavailableSurrogateResultV1{
          {1U, request.request_digest().value(),
           request.provider_binding().provider,
           std::move(built_report).value()},
          {{UnavailableReasonKindV1::construction_domain_unavailable,
            "c16.fixture.flow.unavailable",
            "the synthetic fixture deliberately reports scientific unavailability",
            std::nullopt, std::nullopt}},
          std::nullopt});
}

[[nodiscard]] inline Result<SurrogateBuildResult> failed_result(
    const SurrogateBuildRequest& request) {
  auto built_report = report(request);
  if (!built_report) {
    return Result<SurrogateBuildResult>::failure(built_report.error());
  }
  return Result<SurrogateBuildResult>::success(
      FailedSurrogateResultV1{
          {1U, request.request_digest().value(),
           request.provider_binding().provider,
           std::move(built_report).value()},
          {ProviderFailureKindV1::construction_failure,
           "c16.fixture.flow.failed",
           "the synthetic fixture deliberately reports scientific failure"}});
}

[[nodiscard]] inline ProviderExecutionOutcome serialized(
    Result<SurrogateBuildResult> result) {
  if (!result) {
    return FailedProviderExecution{result.error()};
  }
  auto bytes = artifact::detail::canonical_surrogate_build_result_bytes_v1(
      result.value());
  if (!bytes) {
    return FailedProviderExecution{bytes.error()};
  }
  return CompletedProviderExecution{std::move(bytes).value()};
}

}  // namespace mwperf::testing::c16_flow_fixture
