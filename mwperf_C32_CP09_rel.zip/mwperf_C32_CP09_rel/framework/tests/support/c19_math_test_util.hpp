#pragma once

#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/source_node.hpp"
#include "mwperf/math/probability.hpp"
#include "support/c19_math_carriers.hpp"

namespace mwperf::testing::c19_math {

[[nodiscard]] inline ExactRational rational(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  auto value = ExactRational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline ExactRational divide(const ExactRational& numerator,
                                          const ExactRational& denominator) {
  auto value = checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] inline SourceNode source(const std::string& pointer) {
  return SourceNode::make_null(
      SourceLocation{"c19-math-tests", 1U, 1U, 0U}, pointer);
}

[[nodiscard]] inline TypedLabel label(const std::string& value) {
  auto result = TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline SelectionSpec stationary_unique_selection() {
  return StationaryUniqueSelection{source("/selection/stationary-unique")};
}

[[nodiscard]] inline SelectionSpec stationary_class_selection(
    const std::uint64_t ordinal) {
  return StationaryClassSelection{
      TypedLabel::numeric(BigNat{ordinal}),
      source("/selection/stationary-class")};
}

[[nodiscard]] inline AuthoredProbability probability(
    const ExactRational& value) {
  auto result = AuthoredProbability::from_exact(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline SelectionSpec equal_stationary_mixture() {
  return StationaryMixtureSelection{
      {{TypedLabel::numeric(BigNat{0U}), probability(rational(1, 2)),
        source("/selection/mixture/0")},
       {TypedLabel::numeric(BigNat{1U}), probability(rational(1, 2)),
        source("/selection/mixture/1")}},
      source("/selection/mixture")};
}

[[nodiscard]] inline SelectionSpec fixed_unique_selection() {
  return FixedPointSelection{
      FixedPointUniqueSelection{source("/selection/fixed-unique")}};
}

[[nodiscard]] inline SelectionSpec fixed_id_selection(
    const std::string& value) {
  return FixedPointSelection{FixedPointIdSelection{
      label(value), source("/selection/fixed-id")}};
}

[[nodiscard]] inline CarrierLineageSpec lineage(
    std::string identity,
    const ConstructionMethodV1 method = ConstructionMethodV1::closed_form,
    const ProducerModeV1 producer = ProducerModeV1::inline_immediate,
    const ArrivalFamily family = ArrivalFamily::deterministic_trace) {
  return {std::move(identity), method, producer, family};
}

[[nodiscard]] inline SolverPolicy policy(
    const CarrierLineageSpec& carrier_lineage,
    const std::uint64_t maximum_iterations = 64U,
    const ExactRational& tolerance = rational(1, 1024)) {
  auto fingerprint = analysis_fingerprint(carrier_lineage);
  REQUIRE(fingerprint);
  return {LinearMethod::dense_pivoted, BigNat{maximum_iterations}, tolerance,
          ExactRational::zero(), std::move(fingerprint).value()};
}

[[nodiscard]] inline TailService tail_service(const ExactRational& value) {
  auto result = TailService::make(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline EvaluationPoint evaluation_point(
    const ExactRational& value) {
  auto result = EvaluationPoint::make(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline ExactRational scalar_mass(
    const ScalarStationaryLaw& law, const std::uint64_t level) {
  auto result = law.mass(BigNat{level});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline ScalarCarrierSpec scalar_carrier(
    CarrierLineageSpec carrier_lineage,
    std::vector<ScalarArrivalMassV1> arrival_atoms,
    std::vector<ExactRational> service_by_level,
    std::optional<BigNat> constant_tail_from,
    std::optional<ExactRational> constant_tail_service,
    const bool second_moment_available = true,
    const bool temporal_iid = true) {
  return {std::move(carrier_lineage), std::move(arrival_atoms),
          second_moment_available, temporal_iid,
          std::move(service_by_level), std::move(constant_tail_from),
          std::move(constant_tail_service),
          {{BigNat{0U}, ExactRational::one()}}, LittleLawSpec{},
          stationary_unique_selection()};
}

[[nodiscard]] inline std::vector<ScalarArrivalMassV1> bernoulli_atoms(
    const ExactRational& rate) {
  return {{BigNat{0U}, ExactRational::one() - rate},
          {BigNat{1U}, rate}};
}

[[nodiscard]] inline ArrivalPhaseIdentityV1 phase(
    const std::uint8_t ordinal) {
  return {ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(ordinal)}};
}

[[nodiscard]] inline ExactPhaseArrivalBlockV1 phase_block(
    const std::uint64_t arrivals, std::vector<ExactRational> row_major) {
  return {BigNat{arrivals}, std::move(row_major)};
}

[[nodiscard]] inline PhaseLevelCompletionV1 exact_closed_completion(
    const std::uint64_t maximum_level) {
  return {PhaseLevelCompletionKindV1::exact_closed, BigNat{maximum_level},
          std::nullopt, {}};
}

}  // namespace mwperf::testing::c19_math
