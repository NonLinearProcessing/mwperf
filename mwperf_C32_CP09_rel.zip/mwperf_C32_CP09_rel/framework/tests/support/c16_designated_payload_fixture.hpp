#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_designated_payload_fixture.hpp is test-only"
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "c16_test_providers.hpp"

namespace mwperf::testing {

// A deliberately noninstalled fixture for the F-C16-04 tests.  It passes an
// all-five-stage response through the real C15 validation/adaptation path;
// trusted constructors are used only to build the C14 accepted contract.
enum class C16DesignatedResponseStageV1 : std::uint8_t {
  raw,
  nominal,
  recoded,
};

struct C16DesignatedCoefficientStatusV1 final {
  ProposalConditioningSourceV1 source{
      ProposalConditioningSourceV1::exact_population};
  PopulationConditioningStatusV1 population{
      PopulationConditioningStatusV1::proved_positive};
  RawValueStatusV1 raw{RawValueStatusV1::exact_point};
  PortableScientificScalar observed_population{
      PortableScientificScalar::rational(ExactRational::one())};
  std::optional<PortableScientificScalar> raw_point{
      PortableScientificScalar::rational(ExactRational::one())};
  std::optional<ArtifactObjectReferenceV1> completion_policy;
};

struct C16DesignatedPayloadOptionsV1 final {
  C16DesignatedResponseStageV1 deployed_stage{
      C16DesignatedResponseStageV1::recoded};
  std::array<C16DesignatedCoefficientStatusV1, 3U> coefficient_statuses;
};

struct C16DesignatedScenarioV1 final {
  SurrogateProvider provider;
  ValidatedProviderManifest manifest;
  ResolvedInstance instance;
  std::shared_ptr<const CompiledArrivalLaw> arrival;
  MetricRequirements requirements;
  MetricRequest metric_request;
  FrameworkProblemView view;
  ValidatedSurrogateParameters parameters;
  PlugDescriptorPreview preview;
  AcceptedCapabilityContract contract;
  ConstructionBudget budget;
  SurrogateBuildRequest request;
};

struct C16DesignatedPayloadFixtureV1 final {
  C16DesignatedScenarioV1 scenario;
  CommonBuildReportV1 report;
  SurrogateArtifactV1 source_artifact;
  ValidatedSurrogateBuildResult validated_result;
  ValidatedSurrogateArtifact validated_artifact;
  PortablePlugPayload portable_payload;
};

struct C16DesignatedValidatedPayloadV1 final {
  ValidatedSurrogateBuildResult result;
  ValidatedSurrogateArtifact artifact;
  PortablePlugPayload payload;
};

namespace c16_designated_detail {

using Factory = C15ProtocolFixtureFactory;

[[nodiscard]] inline TypedLabel label(const std::string_view text) {
  return std::move(TypedLabel::text(std::string(text))).value();
}

[[nodiscard]] inline QueueId queue(const std::string_view text) {
  return QueueId(label(text));
}

[[nodiscard]] inline Digest256 digest(const std::string_view text) {
  return std::move(sha256(std::as_bytes(
                       std::span<const char>(text.data(), text.size()))))
      .value();
}

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  return std::move(
             ExactRational::make(BigInt(numerator), BigInt(denominator)))
      .value();
}

[[nodiscard]] inline PortableScientificScalar scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return PortableScientificScalar::rational(
      rational(numerator, denominator));
}

[[nodiscard]] inline ArtifactObjectReferenceV1 object(
    const std::string_view name) {
  return {label(name), digest(name)};
}

[[nodiscard]] inline std::vector<std::byte> bytes(
    const std::string_view text) {
  const auto source = std::as_bytes(
      std::span<const char>(text.data(), text.size()));
  return {source.begin(), source.end()};
}

[[nodiscard]] inline SourceNode parameters() {
  const SourceLocation location{"c16-designated-parameters.json", 1U, 1U,
                                0U};
  return SourceNode::make_object(
      {{"resolution_level", location,
        SourceNode::make_number("1", location, "/resolution_level")}},
      location, "");
}

[[nodiscard]] inline std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-designated-input";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct InputV1 final {
  ResolvedInstance instance;
  std::shared_ptr<const CompiledArrivalLaw> arrival;
  MetricRequirements requirements;
  MetricRequest request;
};

[[nodiscard]] inline InputV1 input(
    const std::string_view provider_id,
    const bool monte_carlo_solver = false,
    const std::uint64_t monte_carlo_replications = 64U,
    const std::string_view monte_carlo_interval = "none",
    const std::string_view monte_carlo_metric_id = "c24-none") {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string solver = monte_carlo_solver
      ? std::string(R"json({"kind":"monte_carlo","parameters":{"replications":)json") +
            std::to_string(monte_carlo_replications) +
            R"json(,"confidence_level":0.95,"interval_method":")json" +
            std::string(monte_carlo_interval) + R"json("}})json"
      : R"json({"kind":"analytic","parameters":{"precision_bits":128,"max_iterations":null}})json";
  const std::string metric = monte_carlo_solver
      ? std::string(R"json({"id":")json") +
            std::string(monte_carlo_metric_id) +
            R"json(","kind":"stationary_edge_reward","parameters":{"reward":"departure","moment_order":1}})json"
      : R"json({"id":"throughput","kind":"stationary_throughput","parameters":{}})json";
  const std::string sampling_draw_cap =
      monte_carlo_solver ? std::to_string(monte_carlo_replications) : "1";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[)json") + metric + R"json(],
    "surrogate":{"id":")json" + std::string(provider_id) + R"json(",
                 "version":"1.0.0","parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":)json" + sampling_draw_cap + R"json(},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":)json" + solver + R"json(
  })json";

  auto model_document = load_document(write_input("model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(write_input("analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline std::string provider_id(
    const C16DesignatedResponseStageV1 stage) {
  switch (stage) {
    case C16DesignatedResponseStageV1::raw:
      return "c16.fixture.designated.raw";
    case C16DesignatedResponseStageV1::nominal:
      return "c16.fixture.designated.nominal";
    case C16DesignatedResponseStageV1::recoded:
      return "c16.fixture.designated.recoded";
  }
  return "c16.fixture.designated.recoded";
}

[[nodiscard]] inline ConstructionBudget budget() {
  return {1U,
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

[[nodiscard]] inline ProviderConformanceReportRef conformance(
    const C16DesignatedScenarioV1& scenario) {
  const auto& anchor = scenario.provider.manifest().value()
                           .family_evidence_conformance_report_anchors.front();
  return {anchor.report_schema_version,
          anchor.report_id,
          anchor.report_digest,
          scenario.provider.identity(),
          scenario.provider.manifest().scientific_contract_digest().value(),
          anchor.family_evidence_schema_id,
          anchor.family_evidence_schema_version};
}

[[nodiscard]] inline CommonBuildReportV1 report(
    const C16DesignatedScenarioV1& scenario) {
  CommonBuildReportV1 value{
      1U,
      label("c16.designated.report"),
      digest("c16.designated.report.placeholder"),
      scenario.request.request_digest().value(),
      scenario.contract.budget_digest(),
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {},
      {}};
  value.report_digest =
      std::move(canonical_common_build_report_digest_v1(value)).value();
  return value;
}

}  // namespace c16_designated_detail

[[nodiscard]] inline C16DesignatedPayloadOptionsV1
c16_designated_payload_options_v1(
    const C16DesignatedResponseStageV1 stage =
        C16DesignatedResponseStageV1::recoded) {
  using namespace c16_designated_detail;
  const std::array<PortableScientificScalar, 3U> points{
      scalar(1, 4), scalar(3, 4), scalar(1, 2)};
  C16DesignatedPayloadOptionsV1 options;
  options.deployed_stage = stage;
  for (std::size_t index = 0U; index < options.coefficient_statuses.size();
       ++index) {
    options.coefficient_statuses[index] = {
        ProposalConditioningSourceV1::exact_population,
        PopulationConditioningStatusV1::proved_positive,
        RawValueStatusV1::exact_point,
        scalar(1, 1),
        points[index],
        std::nullopt};
  }
  return options;
}

[[nodiscard]] inline C16DesignatedScenarioV1
make_c16_designated_scenario_from_input_v1(
    const C16DesignatedResponseStageV1 stage,
    c16_designated_detail::InputV1 source) {
  using namespace c16_designated_detail;
  const std::string id_text = provider_id(stage);
  auto id = SurrogateId::parse(id_text);
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const TargetSelection targets{
      1U, {queue("q0")},
      ConstructionGroupIdV1(label("c16.designated.construction-group"))};
  auto view = build_framework_problem_view(
      source.instance, *source.arrival, targets);
  REQUIRE(view);
  auto validated_parameters = validate_surrogate_parameters(
      provider.value(), parameters());
  REQUIRE(validated_parameters);
  auto selected_budget = budget();
  auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements, selected_budget,
      validated_parameters.value());
  REQUIRE(preview);
  auto budget_digest = digest_construction_budget_v1(selected_budget);
  REQUIRE(budget_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, source.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      validated_parameters.value().canonical_value_digest(),
      budget_digest.value());
  auto request = make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      validated_parameters.value(), selected_budget, MasterSeed(0xC1604U));
  REQUIRE(request);
  const auto validated_manifest = provider.value().manifest();
  return {std::move(provider).value(), std::move(validated_manifest),
          std::move(source.instance),
          std::move(source.arrival), std::move(source.requirements),
          std::move(source.request), std::move(view).value(),
          std::move(validated_parameters).value(), std::move(preview).value(),
          std::move(contract), std::move(selected_budget),
          std::move(request).value()};
}

[[nodiscard]] inline C16DesignatedScenarioV1
make_c16_designated_scenario_v1(
    const C16DesignatedResponseStageV1 stage =
        C16DesignatedResponseStageV1::recoded) {
  return make_c16_designated_scenario_from_input_v1(
      stage, c16_designated_detail::input(
                 c16_designated_detail::provider_id(stage)));
}

inline void reseal_c16_designated_response_graph_v1(
    ThreeBinScalarResponseV1& response) {
  using namespace c16_designated_detail;
  const std::size_t deployed_index =
      response.deployed_response_product_id.index();
  for (auto& identification : response.raw_response.identifications) {
    identification.coefficient_id.object_digest =
        std::move(artifact::detail::coefficient_identification_digest_v1(
                      identification))
            .value();
  }
  response.raw_response.product_id = Factory::raw_response_product_id(
      {response.raw_response.product_id.identity().object_id,
       std::move(canonical_raw_response_product_digest_v1(
                     response.raw_response))
           .value()});

  for (auto& envelope : response.raw_envelopes) {
    envelope.source_product = response.raw_response.product_id;
    envelope.construction_law_digest =
        response.raw_response.proposal_law_digest;
    envelope.envelope_id.object_digest =
        std::move(artifact::detail::raw_response_envelope_digest_v1(envelope))
            .value();
  }
  std::sort(response.raw_envelopes.begin(), response.raw_envelopes.end(),
            [](const auto& left, const auto& right) {
              return left.envelope_id < right.envelope_id;
            });

  if (response.nominal_response.has_value()) {
    auto& nominal = *response.nominal_response;
    nominal.raw_parent = response.raw_response.product_id;
    for (std::size_t index = 0U; index < nominal.coefficients.size();
         ++index) {
      nominal.coefficients[index].origin_coefficient_id =
          response.raw_response.identifications[index].coefficient_id;
    }
    nominal.product_id = Factory::nominal_response_product_id(
        {nominal.product_id.identity().object_id,
         std::move(canonical_nominal_response_product_digest_v1(nominal))
             .value()});
  }

  if (response.projection_center.has_value()) {
    auto& center = *response.projection_center;
    std::visit(
        [&](auto& source) {
          using Source = std::decay_t<decltype(source)>;
          if constexpr (std::same_as<Source, RawResponseProductId>) {
            source = response.raw_response.product_id;
          } else {
            REQUIRE(response.nominal_response.has_value());
            source = response.nominal_response->product_id;
          }
        },
        center.response_source);
    center.product_id = Factory::projection_center_product_id(
        {center.product_id.identity().object_id,
         std::move(canonical_projection_center_product_digest_v1(center))
             .value()});
  }

  if (response.projected_mean.has_value()) {
    auto& mean = *response.projected_mean;
    REQUIRE(response.projection_center.has_value());
    mean.center_parent = response.projection_center->product_id;
    mean.product_id = Factory::projected_mean_product_id(
        {mean.product_id.identity().object_id,
         std::move(canonical_projected_mean_product_digest_v1(mean)).value()});
  }

  if (response.recoded_response.has_value()) {
    auto& recoded = *response.recoded_response;
    for (std::size_t index = 0U; index < recoded.coefficients.size();
         ++index) {
      recoded.coefficients[index].origin_coefficient_id =
          response.raw_response.identifications[index].coefficient_id;
    }
    if (recoded.projected_mean_parent.has_value()) {
      REQUIRE(response.projected_mean.has_value());
      recoded.projected_mean_parent = response.projected_mean->product_id;
    }
    std::visit(
        [&](auto& source) {
          using Source = std::decay_t<decltype(source)>;
          if constexpr (std::same_as<Source, RawResponseProductId>) {
            source = response.raw_response.product_id;
          } else if constexpr (std::same_as<Source,
                                             NominalResponseProductId>) {
            REQUIRE(response.nominal_response.has_value());
            source = response.nominal_response->product_id;
          }
        },
        recoded.reference_response_parent);
    recoded.product_id = Factory::recoded_response_product_id(
        {recoded.product_id.identity().object_id,
         std::move(canonical_recoded_response_product_digest_v1(recoded))
             .value()});
  }

  if (deployed_index == 0U) {
    response.deployed_response_product_id = response.raw_response.product_id;
  } else if (deployed_index == 1U) {
    REQUIRE(response.nominal_response.has_value());
    response.deployed_response_product_id =
        response.nominal_response->product_id;
  } else {
    REQUIRE(response.recoded_response.has_value());
    response.deployed_response_product_id =
        response.recoded_response->product_id;
  }
  response.response_row_id.object_digest =
      std::move(canonical_three_bin_response_row_digest_v1(response)).value();
}

[[nodiscard]] inline ThreeBinScalarResponseV1
make_c16_designated_response_v1(
    const C16DesignatedScenarioV1& scenario,
    const C16DesignatedPayloadOptionsV1& options =
        c16_designated_payload_options_v1()) {
  using namespace c16_designated_detail;
  const QueueId deployed_target = queue("q0");
  const std::array<PortableScientificScalar, 3U> values{
      scalar(1, 4), scalar(3, 4), scalar(1, 2)};
  const std::array<ThreeBinCoefficientV1, 3U> bins{
      ThreeBinCoefficientV1::one, ThreeBinCoefficientV1::two,
      ThreeBinCoefficientV1::tail_from_three};
  const auto identification = [&](const std::size_t index) {
    const auto& status = options.coefficient_statuses[index];
    const auto status_evidence =
        object("c16.designated.status-evidence");
    return CoefficientIdentificationV1{
        object("c16.designated.coefficient." + std::to_string(index)),
        {status.source, status.observed_population,
         status.source == ProposalConditioningSourceV1::empirical_average
             ? std::optional<TypedLabel>{
                   label("c16.designated.status-evaluation")}
             : std::nullopt},
        {status.population, status.raw},
        status.raw_point,
        status.raw == RawValueStatusV1::exact_point
            ? std::vector<ArtifactObjectReferenceV1>{}
            : std::vector<ArtifactObjectReferenceV1>{status_evidence},
        conformance(scenario),
        status.completion_policy,
        bins[index]};
  };
  std::array<CoefficientIdentificationV1, 3U> identifications{
      identification(0U), identification(1U), identification(2U)};

  RawResponseProductV1 raw{
      Factory::raw_response_product_id(object("c16.designated.raw")),
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      deployed_target,
      scenario.view.fingerprints().compiled_arrival,
      digest("c16.designated.proposal-law"),
      std::move(identifications)};
  const ResponseCoefficientTripleV1 coefficients{{
      {bins[0U], values[0U], raw.identifications[0U].coefficient_id},
      {bins[1U], values[1U], raw.identifications[1U].coefficient_id},
      {bins[2U], values[2U], raw.identifications[2U].coefficient_id},
  }};
  const auto completion_policy = object("c16.designated.completion-policy");
  NominalResponseProductV1 nominal{
      Factory::nominal_response_product_id(
          object("c16.designated.nominal")),
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      deployed_target,
      coefficients,
      raw.product_id,
      completion_policy,
      std::nullopt};
  const auto construction_targets = std::vector<QueueId>(
      scenario.contract.construction_target_scope().begin(),
      scenario.contract.construction_target_scope().end());
  ProjectionCenterProductV1 center{
      Factory::projection_center_product_id(
          object("c16.designated.projection-center")),
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      construction_targets,
      deployed_target,
      ProjectionCenterSourceKindV1::decoded_raw_response,
      {scalar(1, 4), scalar(1, 2), scalar(3, 4)},
      raw.product_id,
      std::nullopt};
  ProjectedMeanProductV1 mean{
      Factory::projected_mean_product_id(
          object("c16.designated.projected-mean")),
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      construction_targets,
      deployed_target,
      {scalar(1, 8), scalar(1, 2), scalar(7, 8)},
      center.product_id,
      object("c16.designated.projection-policy"),
      std::nullopt};
  RecodedResponseProductV1 recoded{
      Factory::recoded_response_product_id(
          object("c16.designated.recoded")),
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      deployed_target,
      coefficients,
      ProductDerivationKindV1::mean_inversion_recoding,
      mean.product_id,
      nominal.product_id,
      std::nullopt,
      object("c16.designated.recoding-policy"),
      std::nullopt};

  std::vector<RawResponseEnvelopeV1> envelopes;
  for (std::size_t index = 0U;
       index < options.coefficient_statuses.size(); ++index) {
    const auto& status = options.coefficient_statuses[index];
    if (status.raw != RawValueStatusV1::interval_only) continue;
    const auto status_evidence =
        object("c16.designated.status-evidence");
    envelopes.push_back(
        {object("c16.designated.raw-envelope." + std::to_string(index)),
         raw.product_id,
         raw.proposal_law_digest,
         {bins[index]},
         {scalar(0, 1)},
         {scalar(1, 1)},
         "c16.fixture.conditional-unit-interval",
         RawEnvelopeCoverageV1::deterministic,
         PopulationConditioningPremiseV1::
             conditional_on_population_positivity,
         status.source == ProposalConditioningSourceV1::empirical_average
             ? std::optional<TypedLabel>{
                   label("c16.designated.status-evaluation")}
             : std::nullopt,
         std::nullopt,
         RawEnvelopeScopeV1::proposal_raw,
         {status_evidence}});
  }

  DeployedResponseProductIdV1 deployed = raw.product_id;
  if (options.deployed_stage == C16DesignatedResponseStageV1::nominal) {
    deployed = nominal.product_id;
  } else if (options.deployed_stage ==
             C16DesignatedResponseStageV1::recoded) {
    deployed = recoded.product_id;
  }
  ThreeBinScalarResponseV1 response{
      1U,
      object("c16.designated.response-row"),
      deployed_target,
      scenario.view.fingerprints().compiled_arrival,
      std::move(raw),
      std::move(nominal),
      std::move(center),
      std::move(mean),
      std::move(recoded),
      std::move(deployed),
      std::move(envelopes)};
  reseal_c16_designated_response_graph_v1(response);
  return response;
}

namespace c16_designated_detail {

[[nodiscard]] inline MetricSupportManifestEchoV1 manifest_echo(
    const MetricSupportManifest& manifest) {
  return {1U,
          std::move(canonical_metric_support_manifest_bytes_v1(manifest))
              .value(),
          manifest.canonical_digest()};
}

[[nodiscard]] inline const MetricSupportRoleRequirementV1& requirement(
    const MetricSupportManifest& manifest, const MetricSupportRoleV1 role) {
  REQUIRE(manifest.clauses().size() == 1U);
  const auto& requirements = manifest.clauses().front().required_roles;
  const auto found = std::find_if(
      requirements.begin(), requirements.end(),
      [role](const auto& item) { return item.role == role; });
  REQUIRE(found != requirements.end());
  return *found;
}

[[nodiscard]] inline ArtifactObjectReferenceV1 selected_product(
    const ThreeBinScalarResponseV1& response) {
  return std::visit(
      [](const auto& selected) { return selected.identity(); },
      response.deployed_response_product_id);
}

[[nodiscard]] inline ArtifactObjectReferenceV1 role_subject(
    const MetricSupportRoleV1 role,
    const ArtifactObjectReferenceV1& payload_identity,
    const ThreeBinScalarResponseV1& response,
    const ArtifactObjectReferenceV1& validity) {
  switch (role) {
    case MetricSupportRoleV1::deployed_payload:
      return payload_identity;
    case MetricSupportRoleV1::deployed_response:
      return selected_product(response);
    case MetricSupportRoleV1::raw_response:
      return response.raw_response.product_id.identity();
    case MetricSupportRoleV1::nominal_response:
      REQUIRE(response.nominal_response.has_value());
      return response.nominal_response->product_id.identity();
    case MetricSupportRoleV1::projection_center:
      REQUIRE(response.projection_center.has_value());
      return response.projection_center->product_id.identity();
    case MetricSupportRoleV1::projected_mean:
      REQUIRE(response.projected_mean.has_value());
      return response.projected_mean->product_id.identity();
    case MetricSupportRoleV1::recoded_response:
      REQUIRE(response.recoded_response.has_value());
      return response.recoded_response->product_id.identity();
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return validity;
    default:
      FAIL("unsupported role in designated response fixture");
  }
  return payload_identity;
}

[[nodiscard]] inline ArtifactObjectReferenceV1 internal_subject(
    const C16DesignatedScenarioV1& scenario,
    const CommonBuildReportV1& report,
    const InternalReferencePurposeV1 purpose,
    const ArtifactObjectReferenceV1& payload_identity,
    const ThreeBinScalarResponseV1& response,
    const ArtifactObjectReferenceV1& validity) {
  switch (purpose) {
    case InternalReferencePurposeV1::coefficient_origin:
      return response.raw_response.identifications.front().coefficient_id;
    case InternalReferencePurposeV1::configured_arrival_binding:
      return {label("c16.designated.configured-arrival"),
              response.configured_arrival_binding};
    case InternalReferencePurposeV1::artifact_payload:
      return payload_identity;
    case InternalReferencePurposeV1::law_or_result:
      return response.response_row_id;
    case InternalReferencePurposeV1::validity_witness:
      return validity;
    case InternalReferencePurposeV1::coordinate_codec:
      return object("c16.designated.coordinate-codec");
    case InternalReferencePurposeV1::mark_codec:
      return object("c16.designated.mark-codec");
    case InternalReferencePurposeV1::selection_binding:
      return object("c16.designated.selection-binding");
    case InternalReferencePurposeV1::timing_binding:
      return {label("c16.designated.timing-binding"),
              scenario.view.fingerprints().tie_and_timing};
    case InternalReferencePurposeV1::validity_basis:
      return object("c16.designated.validity-basis");
    case InternalReferencePurposeV1::completion_policy:
      if (response.nominal_response.has_value() &&
          response.nominal_response->completion_policy_id.has_value()) {
        return *response.nominal_response->completion_policy_id;
      }
      return object("c16.designated.missing-completion-policy");
    case InternalReferencePurposeV1::projection_source:
      REQUIRE(response.projection_center.has_value());
      return std::visit(
          [](const auto& source) { return source.identity(); },
          response.projection_center->response_source);
    case InternalReferencePurposeV1::projection_policy:
      REQUIRE(response.projected_mean.has_value());
      return response.projected_mean->projection_policy_id;
    case InternalReferencePurposeV1::recoding_policy:
      REQUIRE(response.recoded_response.has_value());
      return response.recoded_response->recoding_policy_id;
    case InternalReferencePurposeV1::proposal_identity:
      return {label("c16.designated.proposal"),
              response.raw_response.proposal_law_digest};
    case InternalReferencePurposeV1::evaluation_identity:
      return object("c16.designated.evaluation");
    case InternalReferencePurposeV1::call_report_identity:
      return {report.report_id, report.report_digest};
    default:
      FAIL("unsupported internal relation in designated response fixture");
  }
  return payload_identity;
}

[[nodiscard]] inline RealizedReferenceCoreV1 realized_core(
    const C16DesignatedScenarioV1& scenario,
    const CommonBuildReportV1& report,
    const MetricSupportRoleRequirementV1& expected,
    const ArtifactObjectReferenceV1& payload_identity,
    const ThreeBinScalarResponseV1& response,
    const ArtifactObjectReferenceV1& validity_subject,
    const ArtifactObjectReferenceV1& validity_witness) {
  const auto clause =
      scenario.contract.structural_manifest().clauses().front().clause_id;
  std::vector<RealizedRoleRelationV1> roles;
  for (const auto& relation : expected.role_relations) {
    roles.push_back(
        {relation.relation,
         {clause, relation.other_role},
         role_subject(relation.other_role, payload_identity, response,
                      validity_subject)});
  }
  std::vector<RealizedInternalReferenceV1> internal;
  for (const auto& relation : expected.internal_relations) {
    internal.push_back(
        {relation.relation, relation.purpose,
         internal_subject(scenario, report, relation.purpose,
                          payload_identity, response, validity_witness)});
  }
  std::vector<QueueId> targets{response.deployed_target};
  if (expected.target_scope ==
      MetricTargetScopeV1::ordered_construction_targets) {
    targets.assign(scenario.contract.construction_target_scope().begin(),
                   scenario.contract.construction_target_scope().end());
  }
  return {std::move(targets), expected.target_scope,
          expected.result_scope, expected.evidence_scope, std::move(roles),
          std::move(internal)};
}

[[nodiscard]] inline RealizedReferenceV1 realized_reference(
    const C16DesignatedScenarioV1& scenario,
    const CommonBuildReportV1& report,
    const MetricSupportRoleRequirementV1& expected,
    const ArtifactObjectReferenceV1& payload_identity,
    const ThreeBinScalarResponseV1& response,
    const ArtifactObjectReferenceV1& validity_subject,
    const ArtifactObjectReferenceV1& validity_witness) {
  auto core = realized_core(scenario, report, expected, payload_identity,
                            response, validity_subject, validity_witness);
  switch (expected.role) {
    case MetricSupportRoleV1::deployed_payload:
      return DeployedPayloadReferenceV1{
          std::move(core), ArtifactPayloadRef{payload_identity}};
    case MetricSupportRoleV1::deployed_response:
      return std::visit(
          [&](const auto& selected) -> RealizedReferenceV1 {
            using Selected = std::decay_t<decltype(selected)>;
            if constexpr (std::same_as<Selected, RawResponseProductId>) {
              return DeployedResponseReferenceV1{
                  std::move(core),
                  RawResponseProductRef{
                      selected.identity(),
                      ResponseProductValueFormV1::exact_point}};
            } else if constexpr (std::same_as<Selected,
                                              NominalResponseProductId>) {
              return DeployedResponseReferenceV1{
                  std::move(core),
                  NominalResponseProductRef{selected.identity()}};
            } else {
              return DeployedResponseReferenceV1{
                  std::move(core),
                  RecodedResponseProductRef{selected.identity()}};
            }
          },
          response.deployed_response_product_id);
    case MetricSupportRoleV1::raw_response:
      return RawResponseProductReferenceV1{
          std::move(core),
          {response.raw_response.product_id.identity(),
           ResponseProductValueFormV1::exact_point}};
    case MetricSupportRoleV1::nominal_response:
      REQUIRE(response.nominal_response.has_value());
      return NominalResponseProductReferenceV1{
          std::move(core),
          {response.nominal_response->product_id.identity()}};
    case MetricSupportRoleV1::projection_center:
      REQUIRE(response.projection_center.has_value());
      return ProjectionCenterProductReferenceV1{
          std::move(core),
          {response.projection_center->product_id.identity()}};
    case MetricSupportRoleV1::projected_mean:
      REQUIRE(response.projected_mean.has_value());
      return ProjectedMeanProductReferenceV1{
          std::move(core),
          {response.projected_mean->product_id.identity()}};
    case MetricSupportRoleV1::recoded_response:
      REQUIRE(response.recoded_response.has_value());
      return RecodedResponseProductReferenceV1{
          std::move(core),
          {response.recoded_response->product_id.identity()}};
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core),
          ReportedValidityOrLiftEvidenceRef{validity_subject}};
    default:
      FAIL("unsupported realized role in designated response fixture");
  }
  return DeployedPayloadReferenceV1{
      std::move(core), ArtifactPayloadRef{payload_identity}};
}

}  // namespace c16_designated_detail

[[nodiscard]] inline SurrogateArtifactV1
rebuild_c16_designated_artifact_v1(
    const C16DesignatedScenarioV1& scenario,
    ThreeBinScalarResponseV1 response) {
  using namespace c16_designated_detail;
  reseal_c16_designated_response_graph_v1(response);
  ArtifactPayloadV1 payload = response;
  const auto payload_digest =
      std::move(canonical_artifact_payload_digest_v1(payload)).value();
  const ArtifactObjectReferenceV1 payload_identity{
      label("c16.designated.payload"), payload_digest};
  const auto build_report = report(scenario);

  const auto family_body =
      bytes(R"json({"claim":"c16-designated-validity"})json");
  const auto family_body_digest =
      std::move(artifact::detail::family_evidence_body_digest_v1(
                    family_body))
          .value();
  FamilyEvidenceEnvelopeV1 family{
      1U,
      object("c16.designated.family-evidence"),
      "c16.fixture.evidence",
      1U,
      conformance(scenario),
      scenario.provider.identity(),
      scenario.provider.manifest().scientific_contract_digest().value(),
      scenario.request.request_digest().value(),
      payload_digest,
      {payload_identity, response.response_row_id},
      {},
      std::vector<QueueId>(
          scenario.contract.construction_target_scope().begin(),
          scenario.contract.construction_target_scope().end()),
      MetricEvidenceScopeV1::validity_or_lift,
      family_body,
      family_body_digest};
  family.evidence_id.object_digest =
      std::move(artifact::detail::family_evidence_envelope_digest_v1(family))
          .value();

  const auto& manifest = scenario.contract.structural_manifest();
  const auto& validity_requirement = requirement(
      manifest, MetricSupportRoleV1::reported_validity_or_lift_evidence);
  const auto validity_core = realized_core(
      scenario, build_report, validity_requirement, payload_identity,
      response, family.evidence_id, family.evidence_id);
  std::vector<ArtifactObjectReferenceV1> validity_subjects;
  std::vector<ArtifactObjectReferenceV1> validity_parents;
  for (const auto& relation : validity_core.role_relations) {
    if (relation.relation == MetricRoleRelationKindV1::subject) {
      validity_subjects.push_back(relation.referenced_object);
    } else if (relation.relation ==
               MetricRoleRelationKindV1::lineage_parent) {
      validity_parents.push_back(relation.referenced_object);
    }
  }
  for (const auto& relation : validity_core.internal_relations) {
    if (relation.relation == MetricRoleRelationKindV1::subject) {
      validity_subjects.push_back(relation.referenced_object);
    } else if (relation.relation ==
               MetricRoleRelationKindV1::lineage_parent) {
      validity_parents.push_back(relation.referenced_object);
    }
  }
  std::sort(validity_subjects.begin(), validity_subjects.end());
  validity_subjects.erase(
      std::unique(validity_subjects.begin(), validity_subjects.end()),
      validity_subjects.end());
  std::sort(validity_parents.begin(), validity_parents.end());
  validity_parents.erase(
      std::unique(validity_parents.begin(), validity_parents.end()),
      validity_parents.end());
  ScopedArtifactEvidenceV1 scoped{
      object("c16.designated.validity-evidence"),
      ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
      {response.deployed_target},
      validity_requirement.result_scope,
      validity_requirement.evidence_scope,
      std::move(validity_subjects),
      std::move(validity_parents),
      {family.evidence_id},
      validity_core.internal_relations};
  scoped.evidence_id.object_digest =
      std::move(artifact::detail::scoped_artifact_evidence_digest_v1(scoped))
          .value();

  std::vector<RealizedMetricBindingV1> bindings;
  const auto& clause = manifest.clauses().front();
  bindings.reserve(clause.required_roles.size());
  for (const auto& expected : clause.required_roles) {
    bindings.push_back(
        {{clause.clause_id, expected.role},
         realized_reference(scenario, build_report, expected,
                            payload_identity, response,
                            scoped.evidence_id, family.evidence_id)});
  }

  return {1U,
          scenario.request.request_digest().value(),
          scenario.provider.identity(),
          scenario.provider.manifest().scientific_contract_digest().value(),
          scenario.contract.construction_method(),
          scenario.contract.producer_mode(),
          scenario.contract.semantic(),
          scenario.contract.runtime_access(),
          scenario.contract.payload_class(),
          payload_identity,
          std::move(payload),
          payload_digest,
          manifest_echo(manifest),
          {scenario.request.request_digest().value(), payload_digest,
           std::move(bindings)},
          scenario.contract.descriptor_core(),
          build_report,
          {std::move(family)},
          {std::move(scoped)},
          {},
          {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
           std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
           std::nullopt}};
}

[[nodiscard]] inline Result<C16DesignatedValidatedPayloadV1>
validate_and_adapt_c16_designated_artifact_v1(
    const C16DesignatedScenarioV1& scenario,
    const SurrogateArtifactV1& source_artifact) {
  const ResultEnvelopeV1 envelope{
      1U, scenario.request.request_digest().value(),
      scenario.provider.identity(), source_artifact.build_report_echo};
  const SurrogateBuildResult result =
      BuiltSurrogateResultV1{envelope, source_artifact};
  auto report = validate_surrogate_build_report(
      result, scenario.request, scenario.budget);
  if (!report) {
    return Result<C16DesignatedValidatedPayloadV1>::failure(report.error());
  }
  auto validated = validate_surrogate_build_result(
      result, scenario.request, scenario.manifest, scenario.contract,
      report.value());
  if (!validated) {
    return Result<C16DesignatedValidatedPayloadV1>::failure(
        validated.error());
  }
  auto realized = resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  const auto* built = std::get_if<RealizedBuiltCapabilitiesV1>(&realized);
  if (built == nullptr) {
    return Result<C16DesignatedValidatedPayloadV1>::failure(
        c16_fixture_detail::fixture_error(
            "c16.fixture.designated_not_built",
            "the designated response fixture did not realize Built capabilities"));
  }
  auto portable = adapt_portable_payload(built->artifact);
  if (!portable) {
    return Result<C16DesignatedValidatedPayloadV1>::failure(
        portable.error());
  }
  return Result<C16DesignatedValidatedPayloadV1>::success(
      {std::move(validated).value(), built->artifact,
       std::move(portable).value()});
}

[[nodiscard]] inline Result<C16DesignatedValidatedPayloadV1>
validate_and_adapt_c16_designated_artifact_v1(
    const C16DesignatedPayloadFixtureV1& fixture,
    const SurrogateArtifactV1& source_artifact) {
  return validate_and_adapt_c16_designated_artifact_v1(fixture.scenario,
                                                       source_artifact);
}

[[nodiscard]] inline PortablePlugPayload
rebind_c16_designated_portable_context_v1(
    const ValidatedSurrogateArtifact& artifact,
    PortableThreeBinScalarResponseV1 response) {
  const auto& source = artifact.value();
  const auto& bindings = artifact.validation_bindings();
  response.context = {source.payload_class,
                      source.deployed_semantic,
                      source.runtime_access,
                      bindings.build_identity_digest,
                      bindings.request_digest,
                      bindings.framework_problem_view_digest,
                      source.deployed_descriptor.deployed_targets,
                      source.payload_identity,
                      source.payload_digest,
                      source.structural_manifest_echo,
                      source.realized_metric_bindings,
                      source.family_evidence,
                      source.scoped_evidence};
  return C15ProtocolFixtureFactory::portable_payload(std::move(response));
}

[[nodiscard]] inline ValidatedSurrogateArtifact
remint_c16_designated_artifact_v1(
    SurrogateArtifactV1 source,
    const ArtifactValidationBindingsV1& bindings) {
  return C15ProtocolFixtureFactory::validated_artifact(
      std::move(source), bindings);
}

[[nodiscard]] inline C16DesignatedPayloadFixtureV1
make_c16_designated_payload_fixture_v1(
    const C16DesignatedPayloadOptionsV1& options =
        c16_designated_payload_options_v1()) {
  auto scenario = make_c16_designated_scenario_v1(options.deployed_stage);
  auto response = make_c16_designated_response_v1(scenario, options);
  auto artifact = rebuild_c16_designated_artifact_v1(
      scenario, std::move(response));
  auto validated = validate_and_adapt_c16_designated_artifact_v1(
      scenario, artifact);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto carried = std::move(validated).value();
  return {std::move(scenario),
          artifact.build_report_echo,
          std::move(artifact),
          std::move(carried.result),
          std::move(carried.artifact),
          std::move(carried.payload)};
}

}  // namespace mwperf::testing
