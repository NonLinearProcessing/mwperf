#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_audited_handle_fixture.hpp is available only to the C16 test target"
#endif

#include <exception>
#include <new>
#include <string>
#include <utility>

#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/plug_contract.hpp"

namespace mwperf {

// This noninstalled C16 fixture supplies the definition of the sole friend
// name already declared by the production seam.  C17 will own that definition
// in production; no test-only friend or macro-conditioned access path exists
// in the installed header.
class C17AuditedFrameworkMint final {
 public:
  [[nodiscard]] static Result<CPlusOutputV1> execute_c_plus_for_fixture(
      const CPlusOperationV1& operation, const CPlusInputV1& input,
      DeterministicRng& rng) {
    CPlusCallbackV1 callback = operation.fresh_operation();
    if (!callback) {
      return failure<CPlusOutputV1>(
          "c16.fixture_c_plus_operation_missing",
          "the test-only C-plus carrier has no operation");
    }
    return callback(input, rng);
  }

  [[nodiscard]] static Result<ValidatedSurrogatePlug> validated_plug(
      PlugDescriptor descriptor, SurrogatePlug plug,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 accepted_contract_digest,
      MetricSupportManifest accepted_structural_manifest) {
    try {
      return Result<ValidatedSurrogatePlug>::success(
          ValidatedSurrogatePlug(
              std::move(descriptor), std::move(plug),
              std::move(artifact_bindings),
              std::move(accepted_contract_digest),
              std::move(accepted_structural_manifest)));
    } catch (const std::bad_alloc&) {
      return failure<ValidatedSurrogatePlug>(
          "c16.fixture_plug_allocation_failure",
          "allocating the test-only validated plug exhausted memory");
    } catch (const std::exception&) {
      return failure<ValidatedSurrogatePlug>(
          "c16.fixture_plug_construction_failure",
          "constructing the test-only validated plug failed");
    } catch (...) {
      return failure<ValidatedSurrogatePlug>(
          "c16.fixture_plug_unknown_failure",
          "constructing the test-only validated plug raised an unknown "
          "exception");
    }
  }

  [[nodiscard]] static Result<AuditedCompiledFramework> framework(
      AuditedFrameworkBindingsV1 bindings,
      TargetSelection target_selection,
      CodecIdentityV1 reduced_state_codec,
      SelectionSupportV1 selection_support,
      InitialSelectionAuthorityV1 initial_selection_authority,
      ReducedInitialMapperV1 initial_mapper,
      SealedExactStateSchemaValidatorV1 exact_state_schema_validator,
      SealedReducedStateDomainValidatorV1 reduced_state_domain_validator,
      SealedPhysicalAtomProjectionValidatorV1
          physical_atom_projection_validator) {
    try {
      return Result<AuditedCompiledFramework>::success(
          AuditedCompiledFramework(
              std::move(bindings), std::move(target_selection),
              std::move(reduced_state_codec), std::move(selection_support),
              std::move(initial_selection_authority),
              std::move(initial_mapper),
              std::move(exact_state_schema_validator),
              std::move(reduced_state_domain_validator),
              std::move(physical_atom_projection_validator)));
    } catch (const std::bad_alloc&) {
      return failure<AuditedCompiledFramework>(
          "c16.fixture_seal_allocation_failure",
          "allocating the test-only audited framework seal exhausted memory");
    } catch (const std::exception&) {
      return failure<AuditedCompiledFramework>(
          "c16.fixture_seal_construction_failure",
          "constructing the test-only audited framework seal failed");
    } catch (...) {
      return failure<AuditedCompiledFramework>(
          "c16.fixture_seal_unknown_failure",
          "constructing the test-only audited framework seal raised an "
          "unknown exception");
    }
  }

  [[nodiscard]] static Result<DirectMetricAccess> direct_metric_access(
      const AuditedCompiledFramework& framework,
      DirectMetricRequestDomainV1 domain,
      SealedDirectMetricDecoderV1 decoder,
      SealedCanonicalResultBytesValidatorV1 result_validator) {
    try {
      return Result<DirectMetricAccess>::success(DirectMetricAccess(
          framework.seal_, framework.bindings_, std::move(domain),
          std::move(decoder), std::move(result_validator)));
    } catch (const std::bad_alloc&) {
      return failure<DirectMetricAccess>(
          "c16.fixture_direct_access_allocation_failure",
          "allocating the test-only sealed direct access exhausted memory");
    } catch (const std::exception&) {
      return failure<DirectMetricAccess>(
          "c16.fixture_direct_access_construction_failure",
          "constructing the test-only sealed direct access failed");
    } catch (...) {
      return failure<DirectMetricAccess>(
          "c16.fixture_direct_access_unknown_failure",
          "constructing the test-only sealed direct access raised an unknown "
          "exception");
    }
  }

 private:
  template <typename T>
  [[nodiscard]] static Result<T> failure(std::string code,
                                         std::string message) {
    return Result<T>::failure(Diagnostic{
        DiagnosticCategory::resource_limit, std::move(code),
        std::move(message), std::nullopt, std::nullopt, {}});
  }
};

namespace testing {

class C16FixtureAuditedMint final {
 public:
  [[nodiscard]] static Result<CPlusOutputV1> execute_c_plus(
      const CPlusOperationV1& operation, const CPlusInputV1& input,
      DeterministicRng& rng) {
    return C17AuditedFrameworkMint::execute_c_plus_for_fixture(operation,
                                                               input, rng);
  }

  [[nodiscard]] static Result<ValidatedSurrogatePlug> validated_plug(
      PlugDescriptor descriptor, SurrogatePlug plug,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 accepted_contract_digest,
      MetricSupportManifest accepted_structural_manifest) {
    return C17AuditedFrameworkMint::validated_plug(
        std::move(descriptor), std::move(plug),
        std::move(artifact_bindings),
        std::move(accepted_contract_digest),
        std::move(accepted_structural_manifest));
  }

  [[nodiscard]] static Result<AuditedCompiledFramework> framework(
      AuditedFrameworkBindingsV1 bindings,
      TargetSelection target_selection,
      CodecIdentityV1 reduced_state_codec,
      SelectionSupportV1 selection_support,
      InitialSelectionAuthorityV1 initial_selection_authority,
      ReducedInitialMapperV1 initial_mapper,
      SealedExactStateSchemaValidatorV1 exact_state_schema_validator,
      SealedReducedStateDomainValidatorV1 reduced_state_domain_validator,
      SealedPhysicalAtomProjectionValidatorV1
          physical_atom_projection_validator) {
    return C17AuditedFrameworkMint::framework(
        std::move(bindings), std::move(target_selection),
        std::move(reduced_state_codec), std::move(selection_support),
        std::move(initial_selection_authority), std::move(initial_mapper),
        std::move(exact_state_schema_validator),
        std::move(reduced_state_domain_validator),
        std::move(physical_atom_projection_validator));
  }

  [[nodiscard]] static Result<DirectMetricAccess> direct_metric_access(
      const AuditedCompiledFramework& framework,
      DirectMetricRequestDomainV1 domain,
      SealedDirectMetricDecoderV1 decoder,
      SealedCanonicalResultBytesValidatorV1 result_validator) {
    return C17AuditedFrameworkMint::direct_metric_access(
        framework, std::move(domain), std::move(decoder),
        std::move(result_validator));
  }
};

}  // namespace testing
}  // namespace mwperf
