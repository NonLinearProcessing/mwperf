#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_registered_pair_matrix_fixture.hpp is test-only"
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/arrival/contract.hpp"
#if defined(MWPERF_C27_TEST_SEAMS)
#include "mwperf/kernel/framework_activation.hpp"
#include "mwperf/sampling/estimators.hpp"
#endif
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "c16_end_to_end_fixture.hpp"

namespace mwperf::testing::c16_registered_pair_matrix {

struct ProfileV1 final {
  std::string_view provider_id;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 access;
  PayloadClassTagV1 payload;
};

// One legal singular tuple per semantic.  Together these nine tuples cover
// all seven runtime-access alternatives without advertising a fallback pair
// in any one provider manifest.
inline constexpr std::array<ProfileV1, 9U> kProfiles{{
    {"c16.fixture.pair.scalar", SemanticTagV1::scalar_backlog_response,
     RuntimeAccessTagV1::finite_parameter_analytic_family,
     PayloadClassTagV1::three_bin_scalar_response_v1},
    {"c16.fixture.pair.stationary", SemanticTagV1::stationary_marked_edge,
     RuntimeAccessTagV1::finite_enumerated_row,
     PayloadClassTagV1::finite_law_tables_v1},
    {"c16.fixture.pair.staged-flux",
     SemanticTagV1::staged_opportunity_flux_law,
     RuntimeAccessTagV1::sparse_row,
     PayloadClassTagV1::finite_law_tables_v1},
    {"c16.fixture.pair.temporal-continuation",
     SemanticTagV1::temporal_one_slot_continuation,
     RuntimeAccessTagV1::normalized_conditional_sampler,
     PayloadClassTagV1::registered_runtime_recipe_v1},
    {"c16.fixture.pair.romr-residence",
     SemanticTagV1::romr_residence_word_law,
     RuntimeAccessTagV1::procedural_residence_generator,
     PayloadClassTagV1::registered_runtime_recipe_v1},
    {"c16.fixture.pair.stopped-path", SemanticTagV1::stopped_path_law,
     RuntimeAccessTagV1::procedural_residence_generator,
     PayloadClassTagV1::registered_runtime_recipe_v1},
    {"c16.fixture.pair.coupled-schedule",
     SemanticTagV1::coupled_target_schedule_law,
     RuntimeAccessTagV1::finite_enumerated_row,
     PayloadClassTagV1::finite_law_tables_v1},
    {"c16.fixture.pair.direct-metric",
     SemanticTagV1::direct_metric_decoder,
     RuntimeAccessTagV1::direct_metric_decoder,
     PayloadClassTagV1::direct_metric_payload_v1},
    {"c16.fixture.pair.response-envelope",
     SemanticTagV1::response_envelope_law,
     RuntimeAccessTagV1::analytic_transform,
     PayloadClassTagV1::response_envelope_evidence_v1},
}};

// Supplemental C20-only tuple.  It is intentionally outside kProfiles: that
// array is the C16 one-per-semantic catalog fixture, whereas this provider is
// needed to exercise a genuinely enumerable, multi-slot ROMR law.
inline constexpr ProfileV1 kC20EnumerableRomrProfile{
    "c20.fixture.pair.romr-enumerable",
    SemanticTagV1::romr_residence_word_law,
    RuntimeAccessTagV1::finite_enumerated_row,
    PayloadClassTagV1::finite_law_tables_v1};

// Negative C20 control: the same enumerable ROMR carrier retains ordinary
// sequential arrival composition.  It lets V0 prove that even an empty
// deterministic trace cannot acquire the finite homogeneous clock quotient.
inline constexpr ProfileV1 kC20CountableRomrProfile{
    "c20.fixture.pair.romr-countable",
    SemanticTagV1::romr_residence_word_law,
    RuntimeAccessTagV1::finite_enumerated_row,
    PayloadClassTagV1::finite_law_tables_v1};

// Supplemental C20-only procedural profile whose manifest carries one
// surrogate-owned residence age and one completed-edge raw-age mark.  Keeping
// it outside kProfiles preserves the C16 nine-profile coverage counters.
inline constexpr ProfileV1 kC20ResetRomrProfile{
    "c20.fixture.pair.romr-reset",
    SemanticTagV1::romr_residence_word_law,
    RuntimeAccessTagV1::procedural_residence_generator,
    PayloadClassTagV1::registered_runtime_recipe_v1};

// Supplemental C27 positive carrier for the narrowly admitted C24
// row-conditional reward lane.  It deliberately remains outside kProfiles:
// the C16 matrix already has its one-per-semantic coverage tuple, while this
// recipe binds a different access/payload pair for one exact point request.
inline constexpr ProfileV1 kC27ConditionalRewardProfile{
    "c27.fixture.c24.conditioned-service",
    SemanticTagV1::staged_opportunity_flux_law,
    RuntimeAccessTagV1::normalized_conditional_sampler,
    PayloadClassTagV1::registered_runtime_recipe_v1};

// Negative C27 control: the same exact direct contract is registered without
// a C17 activation recipe, proving that planning fails before provider work.
inline constexpr ProfileV1 kC27DirectWithoutFactorProfile{
    "c27.fixture.direct-without-factor",
    SemanticTagV1::direct_metric_decoder,
    RuntimeAccessTagV1::direct_metric_decoder,
    PayloadClassTagV1::direct_metric_payload_v1};

[[nodiscard]] inline std::atomic<unsigned>&
c27_conditional_reward_sample_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

inline void reset_c27_conditional_reward_sample_calls() noexcept {
  c27_conditional_reward_sample_calls().store(0U,
                                               std::memory_order_relaxed);
}

struct StageCountersV1 final {
  std::atomic<unsigned> parameter{0U};
  std::atomic<unsigned> preview{0U};
  std::atomic<unsigned> execute{0U};
  std::atomic<unsigned> materialize{0U};
};

[[nodiscard]] inline std::array<StageCountersV1, kProfiles.size()>&
counters() {
  static std::array<StageCountersV1, kProfiles.size()> value{};
  return value;
}

inline void reset_counters() noexcept {
  for (auto& value : counters()) {
    value.parameter.store(0U, std::memory_order_relaxed);
    value.preview.store(0U, std::memory_order_relaxed);
    value.execute.store(0U, std::memory_order_relaxed);
    value.materialize.store(0U, std::memory_order_relaxed);
  }
}

[[nodiscard]] inline TypedLabel label(const std::string_view value) {
  return std::move(TypedLabel::text(std::string(value))).value();
}

[[nodiscard]] inline Digest256 digest(const std::string_view value) {
  return std::move(sha256(
                       std::as_bytes(std::span(value.data(), value.size()))))
      .value();
}

[[nodiscard]] inline MetricSupportRoleRequirementV1 role_requirement(
    const MetricSupportRoleV1 role,
    const MetricTargetScopeV1 target_scope,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope) {
  const auto* schema = metric_support_role_schema_v1(role);
  std::vector<MetricRoleRelationRequirementV1> role_relations;
  const auto add_roles = [&](const std::uint32_t mask,
                             const MetricRoleRelationKindV1 relation) {
    for (const auto candidate : all_metric_support_roles_v1()) {
      if ((mask & metric_support_role_bit_v1(candidate)) != 0U) {
        role_relations.push_back({relation, candidate});
      }
    }
  };
  add_roles(schema->required_lineage_parent_roles,
            MetricRoleRelationKindV1::lineage_parent);
  add_roles(schema->required_binding_roles,
            MetricRoleRelationKindV1::binding);
  add_roles(schema->required_evidence_roles,
            MetricRoleRelationKindV1::evidence);
  add_roles(schema->required_subject_roles,
            MetricRoleRelationKindV1::subject);

  std::vector<InternalRelationRequirementV1> internal_relations;
  const auto add_internal = [&](const std::uint64_t mask,
                                const MetricRoleRelationKindV1 relation) {
    const auto last = static_cast<std::uint8_t>(
        InternalReferencePurposeV1::error_object);
    for (std::uint8_t index = 0U; index <= last; ++index) {
      const auto purpose = static_cast<InternalReferencePurposeV1>(index);
      if ((mask & internal_reference_purpose_bit_v1(purpose)) != 0U) {
        internal_relations.push_back({relation, purpose});
      }
    }
  };
  add_internal(schema->required_internal_lineage_parents,
               MetricRoleRelationKindV1::lineage_parent);
  add_internal(schema->required_internal_bindings,
               MetricRoleRelationKindV1::binding);
  add_internal(schema->required_internal_evidence,
               MetricRoleRelationKindV1::evidence);
  add_internal(schema->required_internal_subjects,
               MetricRoleRelationKindV1::subject);
  return {role, target_scope, result_scope, evidence_scope,
          std::move(role_relations), std::move(internal_relations)};
}

[[nodiscard]] inline MetricSupportRoleV1 primary_role(
    const SemanticTagV1 semantic) noexcept {
  switch (semantic) {
    case SemanticTagV1::scalar_backlog_response:
      return MetricSupportRoleV1::deployed_response;
    case SemanticTagV1::stationary_marked_edge:
      return MetricSupportRoleV1::stationary_marked_edge_law;
    case SemanticTagV1::staged_opportunity_flux_law:
      return MetricSupportRoleV1::staged_opportunity_flux_law;
    case SemanticTagV1::temporal_one_slot_continuation:
      return MetricSupportRoleV1::temporal_continuation_law;
    case SemanticTagV1::romr_residence_word_law:
      return MetricSupportRoleV1::residence_word_law;
    case SemanticTagV1::stopped_path_law:
      return MetricSupportRoleV1::stopped_path_law;
    case SemanticTagV1::coupled_target_schedule_law:
      return MetricSupportRoleV1::coupled_schedule_law;
    case SemanticTagV1::direct_metric_decoder:
      return MetricSupportRoleV1::direct_metric_value;
    case SemanticTagV1::response_envelope_law:
      return MetricSupportRoleV1::response_envelope;
  }
  return MetricSupportRoleV1::deployed_payload;
}

[[nodiscard]] inline SurrogateProviderManifestV1 bind_manifest(
    SurrogateProviderManifestV1 manifest, const ProfileV1& profile) {
  auto clause = manifest.metric_clause_upper_envelope.clauses().front();
  clause.semantic = profile.semantic;
  clause.runtime_access = profile.access;
  clause.payload_class = {profile.payload, 1U};
  if (profile.semantic != SemanticTagV1::scalar_backlog_response &&
      profile.semantic != SemanticTagV1::stationary_marked_edge &&
      profile.semantic != SemanticTagV1::direct_metric_decoder) {
    // The scalar response and C18 stationary-edge fixtures both implement
    // the stationary-throughput identity, so both retain the target-intensity
    // and first-arrival-moment premises.  Other registered-pair fixtures
    // replace that semantic carrier and must not inherit hypotheses or
    // arrival needs from an unrelated scalar law.  Specialized routes below
    // add back only the assumptions they actually validate.
    clause.arrival_assumptions.clear();
    clause.hypotheses.clear();
    manifest.target_and_arrival_scientific_prerequisites
        .arrival_assumptions.clear();
  }
  if (profile.semantic == SemanticTagV1::direct_metric_decoder) {
    clause.parameter_domain = ExactMetricDecoderDomainV1{
        ExactMetricDecoderKeyV1(label("c16.registered-pair.decoder")),
        StationaryThroughputParametersV1{}};
    clause.solver_route = SolverRegimeV1::direct;
    clause.requested_accuracy = DirectExactAccuracyV1{};
  }
  if (profile.semantic == SemanticTagV1::stationary_marked_edge ||
      profile.semantic == SemanticTagV1::direct_metric_decoder) {
    manifest.scientific_construction_policy_schema.point_deployment = {
        PointDeploymentPolicyV1::not_applicable};
    manifest.scientific_construction_policy_schema.coefficient_completion = {
        CoefficientCompletionPolicyV1::not_applicable};
  }
  if (profile.semantic == SemanticTagV1::stationary_marked_edge) {
    // The C18 scalar identity is evaluated from an exact finite invariant;
    // its advertised finite-row access must therefore carry the enumerated
    // solver contract rather than the analytic contract inherited from the
    // scalar-response seed manifest.
    clause.solver_route = SolverRegimeV1::enumerated;
    clause.requested_accuracy = EnumeratedAccuracyV1{{
        {DeterministicToleranceKindV1::linear_residual_abs,
         ExactRational::zero()}}};
    // C15's stationary-edge table binds both the decision mark and the
    // retained successor coordinate.  The latter is decoded from the exact
    // postarrival state by C17 rather than inferred from the table row.
    clause.marks.push_back(
        {MetricMarkKindV1::successor_backlog,
         MetricRevealStageV1::completed_edge,
         {"queue.big_nat", 1U}, ""});
  }
  if (profile.semantic == SemanticTagV1::response_envelope_law) {
    clause.result_scope = MetricResultScopeV1::response_envelope;
    clause.error_promise = {
        StructuralErrorFormV1::validity_witness,
        MetricEvidenceScopeV1::validity_or_lift, std::nullopt};
  }
  if (profile.semantic == SemanticTagV1::coupled_target_schedule_law) {
    clause.clause_id = {"joint", 0U};
    clause.metric_kind = MetricKindV1::joint_backlog_covariance;
    clause.parameter_domain = ExactMetricParameterSetV1{{
        MetricRequestParametersV1{JointBacklogCovarianceParametersV1{}}}};
    clause.ordered_targets = {QueueId(label("q0")), QueueId(label("q1"))};
    clause.target_coupling = TargetCouplingV1::common_schedule_projection;
    clause.marks = {{MetricMarkKindV1::schedule_projection,
                     MetricRevealStageV1::decision,
                     {"schedule.projection", 1U}, ""}};
  }
  if (profile.semantic == SemanticTagV1::temporal_one_slot_continuation ||
      profile.semantic == SemanticTagV1::romr_residence_word_law ||
      profile.semantic == SemanticTagV1::stopped_path_law) {
    clause.state_fields = {
        {StateFieldKindV1::target_backlog,
         FieldOwnershipV1::framework_exact,
         {"queue.big_nat", 1U}},
        {StateFieldKindV1::configured_arrival_predictive_phase,
         FieldOwnershipV1::framework_exact,
         {"arrival.phase", 1U}}};
    clause.marks = {
        {MetricMarkKindV1::class_label,
         MetricRevealStageV1::entrance_label,
         {"mwperf.c23.typed_label", 1U},
         "c23.fixture.entrance-realization"},
        {MetricMarkKindV1::phase_label,
         MetricRevealStageV1::entrance_label,
         {"mwperf.c23.typed_label", 1U},
         "c23.fixture.entrance-realization"}};
    clause.phase_domain = {
        PayloadPhaseKindV1::predictive_phase_indexed,
        profile.provider_id == kC20EnumerableRomrProfile.provider_id
            ? ConfiguredArrivalCompositionV1::
                  finite_enumerated_predictive_phase
            : ConfiguredArrivalCompositionV1::sequential_predictive_phase,
        true,
        CodecIdentityV1{"arrival.phase", 1U},
        FiniteHorizonCoverageKindV1::every_finite_horizon,
        std::nullopt};
    manifest.scientific_construction_policy_schema.point_deployment = {
        PointDeploymentPolicyV1::not_applicable};
    manifest.scientific_construction_policy_schema.coefficient_completion = {
        CoefficientCompletionPolicyV1::not_applicable};
    if (profile.provider_id == kC20EnumerableRomrProfile.provider_id) {
      // The finite C20 four-word carrier has one closed event class plus
      // transient event states.  C21's negative selector fixture therefore
      // truthfully admits an explicit stationary-class selector in addition
      // to the historical unique-class request.
      clause.selection_domain.kinds = {
          SelectionKindV1::stationary_unique,
          SelectionKindV1::stationary_class};
    }
  }
  std::vector<MetricSupportRoleRequirementV1> roles;
  const auto add_role = [&](const auto& self,
                            const MetricSupportRoleV1 role) -> void {
    if (std::any_of(roles.begin(), roles.end(), [role](const auto& value) {
          return value.role == role;
        })) {
      return;
    }
    MetricTargetScopeV1 target_scope =
        MetricTargetScopeV1::ordered_metric_targets;
    MetricResultScopeV1 result_scope = clause.result_scope;
    MetricEvidenceScopeV1 evidence_scope =
        MetricEvidenceScopeV1::deployed_surrogate_law;
    if (role == MetricSupportRoleV1::deployed_payload) {
      target_scope = MetricTargetScopeV1::payload_targets;
      evidence_scope = MetricEvidenceScopeV1::none;
    } else if (role == MetricSupportRoleV1::deployed_response) {
      target_scope = MetricTargetScopeV1::deployed_singleton_target;
      result_scope = MetricResultScopeV1::surrogate_law;
      evidence_scope = MetricEvidenceScopeV1::deployed_surrogate_law;
    } else if (role == MetricSupportRoleV1::direct_metric_value) {
      target_scope = MetricTargetScopeV1::exact_request_targets;
    } else if (role == MetricSupportRoleV1::stability_certificate) {
      result_scope = MetricResultScopeV1::not_a_metric_result;
      evidence_scope = MetricEvidenceScopeV1::deployed_surrogate_law;
    } else if (role ==
               MetricSupportRoleV1::reported_validity_or_lift_evidence) {
      result_scope = MetricResultScopeV1::not_a_metric_result;
      evidence_scope = MetricEvidenceScopeV1::validity_or_lift;
    } else if (role == MetricSupportRoleV1::response_envelope) {
      target_scope = MetricTargetScopeV1::deployed_singleton_target;
      result_scope = MetricResultScopeV1::response_envelope;
      evidence_scope = MetricEvidenceScopeV1::validity_or_lift;
    } else if (role == MetricSupportRoleV1::raw_response_bound_evidence) {
      target_scope = MetricTargetScopeV1::deployed_singleton_target;
      result_scope = MetricResultScopeV1::not_a_metric_result;
      evidence_scope = MetricEvidenceScopeV1::raw_static_proposal;
    } else if (role == MetricSupportRoleV1::response_order_evidence) {
      target_scope = MetricTargetScopeV1::deployed_singleton_target;
      result_scope = MetricResultScopeV1::not_a_metric_result;
    } else if (role == MetricSupportRoleV1::raw_response) {
      target_scope = MetricTargetScopeV1::deployed_singleton_target;
      result_scope = MetricResultScopeV1::proposal_raw;
      evidence_scope = MetricEvidenceScopeV1::raw_static_proposal;
    }
    auto requirement = role_requirement(
        role, target_scope, result_scope, evidence_scope);
    if (role == MetricSupportRoleV1::deployed_response) {
      requirement.role_relations.push_back(
          {MetricRoleRelationKindV1::subject,
           MetricSupportRoleV1::raw_response});
    }
    if (role == MetricSupportRoleV1::temporal_continuation_law) {
      requirement.internal_relations.push_back(
          {MetricRoleRelationKindV1::binding,
           InternalReferencePurposeV1::selection_binding});
      std::sort(requirement.internal_relations.begin(),
                requirement.internal_relations.end());
    }
    const auto related = requirement.role_relations;
    roles.push_back(std::move(requirement));
    for (const auto& relation : related) self(self, relation.other_role);
  };
  add_role(add_role, MetricSupportRoleV1::deployed_payload);
  const MetricSupportRoleV1 primary = primary_role(profile.semantic);
  add_role(add_role, primary);
  if (profile.semantic == SemanticTagV1::stationary_marked_edge) {
    add_role(add_role, MetricSupportRoleV1::stability_certificate);
    const auto stationary = std::ranges::find_if(
        roles, [primary](const auto& requirement) {
          return requirement.role == primary;
        });
    if (stationary == roles.end()) {
      throw std::logic_error(
          "the stationary fixture omitted its primary law role");
    }
    stationary->role_relations.push_back(
        {MetricRoleRelationKindV1::evidence,
         MetricSupportRoleV1::stability_certificate});
  }
  std::sort(roles.begin(), roles.end(), [](const auto& left,
                                          const auto& right) {
    return metric_support_role_rank_v1(left.role) <
           metric_support_role_rank_v1(right.role);
  });
  clause.required_roles = roles;
  std::vector<MetricSupportClauseV1> supported_clauses{clause};
  if (profile.access ==
      RuntimeAccessTagV1::normalized_conditional_sampler) {
    auto confidence = ExactRational::make(BigInt{19}, BigInt{20});
    if (!confidence) {
      throw std::logic_error(
          "the C24 fixture confidence rational is invalid");
    }
    MetricSupportClauseV1 monte_carlo = clause;
    monte_carlo.clause_id.metric_id = "c24-none";
    monte_carlo.solver_route = SolverRegimeV1::monte_carlo;
    monte_carlo.requested_accuracy = MonteCarloAccuracyV1{
        BigNat{1000000U}, confidence.value(),
        StatisticalIntervalKindV1::none,
        StatisticalEstimandKindV1::point_with_variance_diagnostics,
        ExactRational::zero(), ExactRational::one()};
    monte_carlo.metric_kind = MetricKindV1::stationary_edge_reward;
    monte_carlo.parameter_domain = ExactMetricParameterSetV1{{
        MetricRequestParametersV1{StationaryEdgeRewardParametersV1{
            EdgeRewardKind::departure, BigNat{1U}}}}};
    // The generic scalar fixture already carries an actual-departure mark at
    // completed-edge reveal.  A normalized conditional sampler instead owns
    // that mark at decision reveal.  Replace the inherited declaration so
    // the support clause has one canonical declaration for the mark kind;
    // retaining both makes registry construction throw before any provider
    // lookup can return its typed result.
    std::erase_if(monte_carlo.marks, [](const MarkDescriptorV1& mark) {
      return mark.kind == MetricMarkKindV1::actual_departure;
    });
    monte_carlo.marks.push_back(
        {MetricMarkKindV1::actual_departure,
         MetricRevealStageV1::decision,
         {"mwperf.c23.typed_label", 1U},
         "c24.fixture.completed-edge"});
    monte_carlo.arrival_assumptions = {
        {ArrivalNeedKindV1::full_common_batch,
         ArrivalCapabilityUseV1::runtime,
         CapabilityProvisionNeedV1::any,
         std::nullopt, false, false, std::nullopt, std::nullopt,
         std::nullopt},
        {ArrivalNeedKindV1::predictive_phase,
         ArrivalCapabilityUseV1::runtime,
         CapabilityProvisionNeedV1::any,
         std::nullopt, false, false, std::nullopt, std::nullopt,
         std::nullopt},
        {ArrivalNeedKindV1::sequential_law,
         ArrivalCapabilityUseV1::runtime,
         CapabilityProvisionNeedV1::any,
         std::nullopt, false, false, std::nullopt, std::nullopt,
         std::nullopt}};
    monte_carlo.hypotheses = {
        {HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
         std::nullopt},
        {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
         std::nullopt},
        {HypothesisKindV1::predictive_phase, std::nullopt, std::nullopt,
         std::nullopt},
        {HypothesisKindV1::reward_integrable,
         MomentVariableV1::edge_reward, BigNat{1U}, std::nullopt},
        {HypothesisKindV1::c21_suspension_inversion, std::nullopt,
         std::nullopt, std::nullopt}};
    manifest.target_and_arrival_scientific_prerequisites
        .arrival_assumptions = monte_carlo.arrival_assumptions;
    supported_clauses.push_back(monte_carlo);

    // C24 tests use a distinct request identity when exercising F-C24-03's
    // row-only backend gate. Production C14 intentionally has no generic row
    // route vocabulary; the trusted C15 test seam re-mints the accepted route
    // after ordinary capability negotiation.
    MetricSupportClauseV1 conditional_row = monte_carlo;
    conditional_row.clause_id.metric_id = "c24-row";
    supported_clauses.push_back(std::move(conditional_row));

    MetricSupportClauseV1 exact_binomial = monte_carlo;
    exact_binomial.clause_id.metric_id = "c24-exact-binomial";
    exact_binomial.requested_accuracy = MonteCarloAccuracyV1{
        BigNat{1000000U},
        std::get<MonteCarloAccuracyV1>(monte_carlo.requested_accuracy)
            .confidence_level,
        StatisticalIntervalKindV1::exact_binomial,
        StatisticalEstimandKindV1::binary_proportion,
        ExactRational::zero(), ExactRational::one()};
    exact_binomial.error_promise = {
        StructuralErrorFormV1::statistical_interval,
        MetricEvidenceScopeV1::deployed_surrogate_law, std::nullopt};
    supported_clauses.push_back(std::move(exact_binomial));

    MetricSupportClauseV1 hoeffding = monte_carlo;
    hoeffding.clause_id.metric_id = "c24-hoeffding";
    hoeffding.requested_accuracy = MonteCarloAccuracyV1{
        BigNat{1000000U},
        std::get<MonteCarloAccuracyV1>(monte_carlo.requested_accuracy)
            .confidence_level,
        StatisticalIntervalKindV1::hoeffding,
        StatisticalEstimandKindV1::binary_proportion,
        ExactRational::zero(), ExactRational::one()};
    hoeffding.error_promise = {
        StructuralErrorFormV1::statistical_interval,
        MetricEvidenceScopeV1::deployed_surrogate_law, std::nullopt};
    supported_clauses.push_back(std::move(hoeffding));
  }
  auto upper_envelope =
      MetricSupportManifest::from_clauses(std::move(supported_clauses));
  if (!upper_envelope) {
    throw std::logic_error(
        std::string(profile.provider_id) + ": " +
        upper_envelope.error().code + ": " +
        upper_envelope.error().message);
  }
  manifest.metric_clause_upper_envelope =
      std::move(upper_envelope).value();
  manifest.allowed_metric_support_roles.clear();
  for (const auto& role : roles) {
    manifest.allowed_metric_support_roles.push_back(role.role);
  }
  const bool has_evidence_role = std::ranges::any_of(
      roles, [](const MetricSupportRoleRequirementV1& requirement) {
        return metric_support_role_rank_v1(requirement.role) >=
               metric_support_role_rank_v1(
                   MetricSupportRoleV1::raw_response_bound_evidence);
      });
  manifest.scientific_construction_policy_schema.evidence_roles = {
      has_evidence_role ? EvidenceRolePolicyV1::exact_manifest_roles
                        : EvidenceRolePolicyV1::not_applicable};
  manifest.deployed_semantic_tag = profile.semantic;
  manifest.runtime_access_tag = profile.access;
  manifest.payload_class = {profile.payload, 1U};
  if (profile.semantic == SemanticTagV1::coupled_target_schedule_law) {
    manifest.target_and_arrival_scientific_prerequisites = {
        2U, 2U, {TargetCouplingV1::common_schedule_projection}, {}};
  }
  manifest.scientific_construction_policy_schema
      .registered_runtime_recipes.clear();
  if (profile.payload == PayloadClassTagV1::registered_runtime_recipe_v1) {
    manifest.scientific_construction_policy_schema.registered_runtime_recipes =
        {{"c16.registered-pair.recipe", 1U,
          "c16.registered-pair.recipe-parameters", 1U,
          "c16.registered-pair.recipe-state", 1U,
          "c16.registered-pair.recipe-mark", 1U}};
  }
  auto manifest_digest = digest_provider_manifest_v1(manifest);
  if (!manifest_digest) {
    throw std::logic_error(
        std::string(profile.provider_id) + ": " +
        manifest_digest.error().code + ": " +
        manifest_digest.error().message);
  }
  manifest.manifest_digest = std::move(manifest_digest).value();
  return manifest;
}

[[nodiscard]] inline SurrogateProviderManifestV1
bind_c27_conditional_reward_manifest(
    SurrogateProviderManifestV1 manifest) {
  manifest = bind_manifest(std::move(manifest),
                           kC27ConditionalRewardProfile);
  const auto seed = std::ranges::find_if(
      manifest.metric_clause_upper_envelope.clauses(),
      [](const MetricSupportClauseV1& candidate) {
        return candidate.clause_id.metric_id == "c24-none";
      });
  if (seed == manifest.metric_clause_upper_envelope.clauses().end()) {
    throw std::logic_error(
        "the C27 conditional-reward fixture requires the C24 no-interval "
        "support clause");
  }
  MetricSupportClauseV1 clause = *seed;
  clause.clause_id = {"c27-conditioned", 0U};
  clause.metric_kind = MetricKindV1::backlog_conditioned_service;
  clause.parameter_domain = ExactMetricParameterSetV1{{
      MetricRequestParametersV1{
          BacklogConditionedServiceParametersV1{{BigNat{1U}}}}}};
  clause.ordered_targets = {QueueId(label("q0"))};
  clause.target_coupling = TargetCouplingV1::scalar_target;
  clause.state_fields = {{StateFieldKindV1::target_backlog,
                          FieldOwnershipV1::framework_exact,
                          {"queue.big_nat", 1U}}};
  clause.marks = {
      {MetricMarkKindV1::target_backlog,
       MetricRevealStageV1::predecision,
       {"queue.big_nat", 1U}, ""},
      {MetricMarkKindV1::opportunity,
       MetricRevealStageV1::predecision,
       {"service.bit", 1U}, ""}};
  clause.selection_domain =
      {{SelectionKindV1::stationary_unique}, {}, {}};
  clause.phase_domain = {
      PayloadPhaseKindV1::phase_free,
      ConfiguredArrivalCompositionV1::iid_late_arrival,
      false,
      std::nullopt,
      FiniteHorizonCoverageKindV1::every_finite_horizon,
      std::nullopt};
  const auto arrival = [](const ArrivalNeedKindV1 kind) {
    return ArrivalAssumptionV1{
        kind, ArrivalCapabilityUseV1::runtime,
        CapabilityProvisionNeedV1::any, std::nullopt, false, false,
        std::nullopt, std::nullopt, std::nullopt};
  };
  clause.arrival_assumptions = {
      arrival(ArrivalNeedKindV1::full_common_batch),
      arrival(ArrivalNeedKindV1::exact_iid_late)};
  std::sort(clause.arrival_assumptions.begin(),
            clause.arrival_assumptions.end(),
            [](const auto& left, const auto& right) {
              return left.kind < right.kind;
            });
  clause.hypotheses = {
      {HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
       std::nullopt},
      {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
       std::nullopt},
      // No off-support convention is invoked at the sealed level-one row:
      // this fixture positively asserts the conditioning-mass premise.
      {HypothesisKindV1::positive_conditioning_mass, std::nullopt,
       std::nullopt, std::nullopt},
      {HypothesisKindV1::iid_late_arrival, std::nullopt, std::nullopt,
       std::nullopt}};
  auto confidence = ExactRational::make(BigInt{19}, BigInt{20});
  if (!confidence) {
    throw std::logic_error(
        "the C27 conditional-reward confidence rational is invalid");
  }
  clause.solver_route = SolverRegimeV1::monte_carlo;
  clause.requested_accuracy = MonteCarloAccuracyV1{
      BigNat{1000000U}, confidence.value(),
      StatisticalIntervalKindV1::none,
      StatisticalEstimandKindV1::point_with_variance_diagnostics,
      ExactRational::zero(), ExactRational::one()};
  clause.result_scope = MetricResultScopeV1::surrogate_law;

  auto support = MetricSupportManifest::from_clauses({std::move(clause)});
  if (!support) {
    throw std::logic_error(
        std::string(kC27ConditionalRewardProfile.provider_id) + ": " +
        support.error().code + ": " + support.error().message);
  }
  manifest.metric_clause_upper_envelope = std::move(support).value();
  manifest.target_and_arrival_scientific_prerequisites = {
      1U, 1U, {TargetCouplingV1::scalar_target},
      {// C15 canonicalizes provider prerequisites by their ordered-JSON
       // spelling, so "exact_iid_late" precedes "full_common_batch".  The
       // C14 support clause above retains its own enum/canonical-byte order;
       // provider prerequisite membership is set-like and need not copy that
       // distinct ordering.
       arrival(ArrivalNeedKindV1::exact_iid_late),
       arrival(ArrivalNeedKindV1::full_common_batch)}};
  manifest.scientific_construction_policy_schema.point_deployment = {
      PointDeploymentPolicyV1::not_applicable};
  manifest.scientific_construction_policy_schema.coefficient_completion = {
      CoefficientCompletionPolicyV1::not_applicable};
  auto manifest_digest = digest_provider_manifest_v1(manifest);
  if (!manifest_digest) {
    throw std::logic_error(
        std::string(kC27ConditionalRewardProfile.provider_id) + ": " +
        manifest_digest.error().code + ": " +
        manifest_digest.error().message);
  }
  manifest.manifest_digest = std::move(manifest_digest).value();
  return manifest;
}

[[nodiscard]] inline SurrogateProviderManifestV1 bind_c20_reset_manifest(
    SurrogateProviderManifestV1 manifest) {
  manifest = bind_manifest(std::move(manifest), kC20ResetRomrProfile);
  MetricSupportClauseV1 clause =
      manifest.metric_clause_upper_envelope.clauses().front();
  // The base clause remains the historical sequential C20 carrier.  C21's
  // metric-specific clauses below use the C09 finite-phase, slot-free exact
  // row operation and bind that stronger composition individually.
  clause.state_fields.push_back(
      {StateFieldKindV1::surrogate_phase, FieldOwnershipV1::surrogate_owned,
       {"c20.fixture.residence-age", 1U}});
  clause.marks.push_back(
      {MetricMarkKindV1::active_component,
       MetricRevealStageV1::completed_edge,
       {"c20.fixture.residence-age", 1U}, ""});
  clause.selection_domain.kinds = {
      SelectionKindV1::transient_initial,
      SelectionKindV1::stationary_unique,
      SelectionKindV1::stationary_class,
      SelectionKindV1::stationary_mixture};
  // The reset fixture's finite event quotient has exactly the two closed
  // classes used by the C21 equal-mixture selection.  Advertising the
  // mixture kind without its selectable class identities would make the
  // otherwise exact stationary route fail the selection-domain audit.
  clause.selection_domain.named_classes = {
      TypedLabel::numeric(BigNat{0U}), TypedLabel::numeric(BigNat{1U})};
  const auto c21_clause = [&clause](
                              std::string id, const MetricKindV1 kind,
                              MetricRequestParametersV1 parameters,
                              const bool admission_palm = false) {
    MetricSupportClauseV1 result = clause;
    result.clause_id = {std::move(id), 0U};
    result.metric_kind = kind;
    result.parameter_domain =
        ExactMetricParameterSetV1{{std::move(parameters)}};
    result.solver_route = SolverRegimeV1::enumerated;
    result.requested_accuracy = EnumeratedAccuracyV1{{
        {DeterministicToleranceKindV1::linear_residual_abs,
         ExactRational::zero()}}};
    result.phase_domain.arrival_composition =
        ConfiguredArrivalCompositionV1::finite_enumerated_predictive_phase;
    result.phase_domain.retains_configured_predictive_phase = true;
    const auto arrival = [](const ArrivalNeedKindV1 need) {
      return ArrivalAssumptionV1{
          need, ArrivalCapabilityUseV1::runtime,
          CapabilityProvisionNeedV1::any, std::nullopt, false, false,
          std::nullopt, std::nullopt, std::nullopt};
    };
    result.arrival_assumptions = {
        arrival(ArrivalNeedKindV1::full_common_batch),
        arrival(ArrivalNeedKindV1::predictive_phase),
        arrival(ArrivalNeedKindV1::sequential_law)};
    if (admission_palm) {
      result.arrival_assumptions.push_back(
          arrival(ArrivalNeedKindV1::entrance_labels));
      result.arrival_assumptions.push_back(
          arrival(ArrivalNeedKindV1::target_intensity));
    }
    std::sort(result.arrival_assumptions.begin(),
              result.arrival_assumptions.end(),
              [](const auto& left, const auto& right) {
                return left.kind < right.kind;
              });

    const auto add_hypothesis = [&](const HypothesisKindV1 hypothesis) {
      if (std::ranges::none_of(
              result.hypotheses, [hypothesis](const auto& existing) {
                return existing.kind == hypothesis;
              })) {
        result.hypotheses.push_back(
            {hypothesis, std::nullopt, std::nullopt, std::nullopt});
      }
    };
    add_hypothesis(HypothesisKindV1::predictive_phase);
    const bool transient_clause =
        result.clause_id.metric_id.rfind("c22-", 0U) == 0U;
    if (transient_clause &&
        (kind == MetricKindV1::first_hit ||
         kind == MetricKindV1::threshold_excursion)) {
      // A transient stopped calculation binds both its authored reduced
      // initializer and the corresponding predictive entrance.  These are
      // distinct selection claims, so the stopped clauses must advertise
      // prescribed_entrance in addition to transient_initial.
      result.selection_domain.kinds.push_back(
          SelectionKindV1::prescribed_entrance);
      std::sort(result.selection_domain.kinds.begin(),
                result.selection_domain.kinds.end());
    }
    if (!transient_clause) {
      add_hypothesis(HypothesisKindV1::proper_stationary);
      add_hypothesis(HypothesisKindV1::invariant_selected);
      add_hypothesis(HypothesisKindV1::c21_suspension_inversion);
    }
    if (kind == MetricKindV1::service_persistence ||
        kind == MetricKindV1::event_gap_distribution) {
      add_hypothesis(HypothesisKindV1::positive_event_intensity);
    }
    if (kind == MetricKindV1::mean_binary_run) {
      add_hypothesis(HypothesisKindV1::positive_start_intensity);
      add_hypothesis(HypothesisKindV1::finite_start_component);
    }
    if (admission_palm) {
      add_hypothesis(HypothesisKindV1::proper_stationary);
      add_hypothesis(HypothesisKindV1::invariant_selected);
      add_hypothesis(HypothesisKindV1::c21_suspension_inversion);
      add_hypothesis(HypothesisKindV1::lossless);
      add_hypothesis(HypothesisKindV1::unit_packets);
      add_hypothesis(HypothesisKindV1::fifo);
      add_hypothesis(HypothesisKindV1::little_law);
      add_hypothesis(HypothesisKindV1::positive_finite_intensity);
      add_hypothesis(
          HypothesisKindV1::eventual_departure_or_accessible_class);
      result.hypotheses.push_back(
          {HypothesisKindV1::moment_finite,
           MomentVariableV1::fifo_delay, BigNat{3U}, std::nullopt});
    }
    std::sort(result.hypotheses.begin(), result.hypotheses.end(),
              [](const auto& left, const auto& right) {
                return left.kind < right.kind;
              });
    if (admission_palm) {
      result.selection_domain.kinds.push_back(
          SelectionKindV1::admission_palm);
    }
    if (kind == MetricKindV1::event_gap_distribution) {
      result.selection_domain.kinds.push_back(SelectionKindV1::event_palm);
    }
    std::sort(result.selection_domain.kinds.begin(),
              result.selection_domain.kinds.end());
    return result;
  };

  auto half = ExactRational::make(BigInt{1}, BigInt{2});
  if (!half) {
    throw std::logic_error(
        "c21 reset fixture could not construct the exact half");
  }
  std::vector<MetricSupportClauseV1> clauses;
  clauses.reserve(30U);
  clauses.push_back(clause);
  clauses.push_back(c21_clause(
      "c21-empty", MetricKindV1::stationary_empty_probability,
      StationaryEmptyProbabilityParametersV1{}));
  clauses.push_back(c21_clause(
      "c21-pmf", MetricKindV1::stationary_backlog_pmf,
      StationaryBacklogPmfParametersV1{CompletePmfDomainV1{}}));
  clauses.push_back(c21_clause(
      "c21-pmf-window", MetricKindV1::stationary_backlog_pmf,
      StationaryBacklogPmfParametersV1{PmfThroughLevelV1{BigNat{0U}}}));
  clauses.push_back(c21_clause(
      "c21-pgf", MetricKindV1::stationary_backlog_pgf,
      StationaryBacklogPgfParametersV1{{
          ExactRational::zero(), half.value(), ExactRational::one(),
          ExactRational::one() + ExactRational::one()}}));
  clauses.push_back(c21_clause(
      "c21-quantile", MetricKindV1::stationary_backlog_quantile,
      StationaryBacklogQuantileParametersV1{half.value()}));
  clauses.push_back(c21_clause(
      "c21-evolving", MetricKindV1::stationary_empty_probability,
      StationaryEmptyProbabilityParametersV1{}));
  clauses.push_back(c21_clause(
      "c21-persistence", MetricKindV1::service_persistence,
      ServicePersistenceParametersV1{}));
  clauses.push_back(c21_clause(
      "c21-autocovariance", MetricKindV1::service_autocovariance,
      ServiceAutocovarianceParametersV1{{BigNat{6U}}}));
  clauses.push_back(c21_clause(
      "c21-mean-run", MetricKindV1::mean_binary_run,
      MeanBinaryRunParametersV1{BasicBinaryPredicateV1::busy}));
  clauses.push_back(c21_clause(
      "c21-hit", MetricKindV1::first_hit,
      FirstHitParametersV1{{HitSetKind::equal, BigNat{2U}}, BigNat{4U},
                           false}));
  auto fifo_delay = c21_clause(
      "c21-fifo", MetricKindV1::fifo_delay,
      FifoDelayParametersV1{FifoDelayPmfOutputV1{BigNat{4U}}}, true);
  auto& fifo_delay_parameters =
      std::get<ExactMetricParameterSetV1>(fifo_delay.parameter_domain).values;
  fifo_delay_parameters.push_back(
      FifoDelayParametersV1{FifoDelayPmfOutputV1{BigNat{2U}}});
  fifo_delay_parameters.push_back(
      FifoDelayParametersV1{FifoDelayMomentOutputV1{BigNat{1U}}});
  fifo_delay_parameters.push_back(
      FifoDelayParametersV1{FifoDelayMomentOutputV1{BigNat{3U}}});
  fifo_delay_parameters.push_back(FifoDelayParametersV1{
      FifoDelayQuantileOutputV1{
          half.value(), DiscreteQuantileConventionV1::lower_inverse_cdf}});
  const auto add_alias = [&clauses](const MetricSupportClauseV1& prototype,
                                    const std::string_view metric_id,
                                    const std::size_t authored_index = 0U) {
    MetricSupportClauseV1 alias = prototype;
    alias.clause_id = {std::string(metric_id), authored_index};
    clauses.push_back(std::move(alias));
  };
  const auto add_aliases = [&add_alias](
                               const MetricSupportClauseV1& prototype,
                               const std::initializer_list<std::string_view>
                                   metric_ids) {
    for (const std::string_view metric_id : metric_ids) {
      add_alias(prototype, metric_id);
    }
  };
  add_aliases(fifo_delay,
              {"c21-fifo", "c23-multislot", "c23-mean",
               "c23-quantile", "c23-pmf", "c23-all"});
  add_alias(fifo_delay, "c23-moment-3", 1U);

  auto fifo_conditioned = c21_clause(
      "c23-fifo-conditioned", MetricKindV1::fifo_delay_conditioned,
      FifoDelayConditionedParametersV1{
          FifoDelayPmfOutputV1{BigNat{2U}},
          FifoRankConditionV1{BigNat{1U}}},
      true);
  auto& conditioned_parameters =
      std::get<ExactMetricParameterSetV1>(fifo_conditioned.parameter_domain)
          .values;
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoRankConditionV1{BigNat{2U}}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayTailOutputV1{BigNat{2U}},
      FifoRankConditionV1{BigNat{1U}}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoBatchConditionV1{BigNat{1U}}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoBatchConditionV1{BigNat{2U}}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoClassConditionV1{TypedLabel::numeric(BigNat{1U})}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoClassConditionV1{TypedLabel::numeric(BigNat{2U})}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoPhaseConditionV1{TypedLabel::numeric(BigNat{1U})}});
  conditioned_parameters.push_back(FifoDelayConditionedParametersV1{
      FifoDelayPmfOutputV1{BigNat{2U}},
      FifoPhaseConditionV1{TypedLabel::numeric(BigNat{2U})}});
  add_aliases(fifo_conditioned,
              {"c23-fifo-conditioned", "c23-conditioned",
               "c23-label-conditioned", "c23-batch-conditioned"});
  add_alias(fifo_conditioned, "c23-rank-one", 1U);
  add_alias(fifo_conditioned, "c23-class-one", 2U);

  auto event_gap = c21_clause(
      "c23-event-gap", MetricKindV1::event_gap_distribution,
      EventGapDistributionParametersV1{
          GapEventKind::admission, BigNat{1U}});
  std::get<ExactMetricParameterSetV1>(event_gap.parameter_domain)
      .values.push_back(EventGapDistributionParametersV1{
          GapEventKind::busy_denial, BigNat{1U}});
  add_aliases(event_gap, {"c23-event-gap", "c23-gap"});
  // C22 exercises its transient orchestrator through the same real C16/C17
  // registered-provider and V0-seal path.  These are exact enumerated
  // clauses, not synthetic C22 source mints.
  clauses.push_back(c21_clause(
      "c22-transient-law", MetricKindV1::transient_backlog_law,
      TransientBacklogLawParametersV1{
          {BigNat{3U}, BigNat{0U}, BigNat{1U}}}));
  clauses.push_back(c21_clause(
      "c22-first-hit", MetricKindV1::first_hit,
      FirstHitParametersV1{{HitSetKind::at_or_above, BigNat{1U}},
                           BigNat{2U}, false}));
  clauses.push_back(c21_clause(
      "c22-threshold-return", MetricKindV1::threshold_excursion,
      ThresholdExcursionParametersV1{
          {HitSetKind::at_or_above, BigNat{1U}}, BigNat{2U}, false}));
  auto support = MetricSupportManifest::from_clauses(std::move(clauses));
  if (!support) {
    throw std::logic_error(
        std::string(kC20ResetRomrProfile.provider_id) + ": " +
        support.error().code + ": " + support.error().message);
  }
  manifest.metric_clause_upper_envelope = std::move(support).value();
  // The provider-level scientific prerequisite is the ceiling for every
  // clause-level arrival assumption.  Keep the five runtime assumptions in
  // the canonical ordered-JSON key order required by C15; they are runtime
  // needs and therefore must not be copied into the preview's construction
  // prerequisites.
  const auto runtime_arrival = [](const ArrivalNeedKindV1 need) {
    return ArrivalAssumptionV1{
        need, ArrivalCapabilityUseV1::runtime,
        CapabilityProvisionNeedV1::any, std::nullopt, false, false,
        std::nullopt, std::nullopt, std::nullopt};
  };
  manifest.target_and_arrival_scientific_prerequisites
      .arrival_assumptions = {
      runtime_arrival(ArrivalNeedKindV1::entrance_labels),
      runtime_arrival(ArrivalNeedKindV1::full_common_batch),
      runtime_arrival(ArrivalNeedKindV1::predictive_phase),
      runtime_arrival(ArrivalNeedKindV1::sequential_law),
      runtime_arrival(ArrivalNeedKindV1::target_intensity)};
  auto digest_result = digest_provider_manifest_v1(manifest);
  if (!digest_result) {
    throw std::logic_error(
        std::string(kC20ResetRomrProfile.provider_id) + ": " +
        digest_result.error().code + ": " + digest_result.error().message);
  }
  manifest.manifest_digest = std::move(digest_result).value();
  return manifest;
}

// C21 reuses the already-audited C20 four-word law to exercise transient
// embedded-event topology.  Add only the exact stationary state-reward
// clause needed by that higher-checkpoint fixture; the C20 throughput clause
// and the provider's finite-law carrier remain unchanged.
[[nodiscard]] inline SurrogateProviderManifestV1
bind_c20_enumerable_stationary_manifest(
    SurrogateProviderManifestV1 manifest) {
  manifest = bind_manifest(std::move(manifest),
                           kC20EnumerableRomrProfile);
  MetricSupportClauseV1 stationary =
      manifest.metric_clause_upper_envelope.clauses().front();
  stationary.clause_id = {"c21-empty", 0U};
  stationary.metric_kind = MetricKindV1::stationary_empty_probability;
  stationary.parameter_domain = ExactMetricParameterSetV1{{
      MetricRequestParametersV1{StationaryEmptyProbabilityParametersV1{}}}};
  stationary.selection_domain.kinds = {
      SelectionKindV1::stationary_unique,
      SelectionKindV1::stationary_class};
  stationary.solver_route = SolverRegimeV1::enumerated;
  stationary.requested_accuracy = EnumeratedAccuracyV1{{
      {DeterministicToleranceKindV1::linear_residual_abs,
       ExactRational::zero()}}};

  std::vector<MetricSupportClauseV1> clauses(
      manifest.metric_clause_upper_envelope.clauses().begin(),
      manifest.metric_clause_upper_envelope.clauses().end());
  clauses.push_back(std::move(stationary));
  auto support = MetricSupportManifest::from_clauses(std::move(clauses));
  if (!support) {
    throw std::logic_error(
        std::string(kC20EnumerableRomrProfile.provider_id) + ": " +
        support.error().code + ": " + support.error().message);
  }
  manifest.metric_clause_upper_envelope = std::move(support).value();
  auto digest_result = digest_provider_manifest_v1(manifest);
  if (!digest_result) {
    throw std::logic_error(
        std::string(kC20EnumerableRomrProfile.provider_id) + ": " +
        digest_result.error().code + ": " + digest_result.error().message);
  }
  manifest.manifest_digest = std::move(digest_result).value();
  return manifest;
}

[[nodiscard]] inline Diagnostic reached_materializer() {
  return {DiagnosticCategory::input_validation,
          "c16.fixture.registered_pair_materializer_reached",
          "the singular registered-pair matrix reached its static materializer",
          std::nullopt, std::nullopt, {}};
}

inline constexpr std::string_view kC17TemporalFixtureParameter =
    "c17.temporal.fixture";
inline constexpr std::string_view kC20EnumerableRomrLaw =
    "c20.fixture.enumerable-romr.law";

// C17/C20 test-only customization point for the registered temporal fixture.
// The materializer is invoked indirectly through the real C16 registry, so a
// scoped thread-local override is the only way for a higher-level fixture to
// vary its immutable operation prototypes without adding a production seam.
// The guard supports nesting and restores the previous pointer on every exit.
struct C17TemporalFixtureOverrideV1 final {
  std::size_t maximum_residence_slots{1U};
  // C27's request-bound activation normally exposes both finite predictive
  // phases.  A stationary law supported on one absorbing phase can narrow
  // that exact event-entry domain without claiming closure for the
  // zero-mass foreign class.
  std::vector<std::uint8_t> finite_domain_phase_selectors;
  std::vector<RuntimeFieldIdV1> residence_local_reset_fields;
  std::vector<RuntimeFieldIdV1> c_plus_writable_unresolved_fields;
  std::optional<CMinusCallbackV1> c_minus;
  std::optional<EnumerateCMinusExactLawV1> enumerate_c_minus;
  std::optional<CPlusCallbackV1> c_plus;
  std::optional<EnumerateCPlusExactLawV1> enumerate_c_plus;
  std::optional<EventEntryInitializerCallbackV1> entry_initializer;
  std::optional<EventStoppingIndicatorCallbackV1> stopping_indicator;
  std::optional<EventTerminalReentryCallbackV1> terminal_reentry;
  std::optional<EventPredecisionProjectionCallbackV1>
      predecision_projection;
  std::optional<EventCompletedEdgeProjectionCallbackV1>
      completed_edge_projection;
  // C22's local sampling poison spy observes the sampler probe seam without
  // replacing the sampler or importing any C24 implementation.  Higher-level
  // tests reset the counter after C17 validation and require C22 dispatch to
  // leave it at zero.
  std::shared_ptr<std::atomic<unsigned>> conditional_sampler_calls;
  // C24 exercises nontrivial finite supports, importance ratios, and exact
  // innovation kernels through the same C16 -> C17 materialization path.
  // Every field remains optional so inherited C17--C23 fixtures keep their
  // original singleton conditional sampler unchanged.
  std::optional<ConditionalSamplerCallbackV1>
      conditional_sampler_operation;
  std::optional<ConditionalSamplerContractV1>
      conditional_sampler_contract;
  // Higher-level generic fixtures bind this to the actual compiled-arrival
  // fingerprint of their scenario before C16 materialization.  Negative V0
  // tests can preserve an explicitly authored foreign binding instead.
  std::optional<Digest256>
      conditional_sampler_configured_arrival_binding;
  bool preserve_authored_conditional_sampler_arrival_binding{false};
  std::optional<ConditionalSampleValidatorV1>
      conditional_sample_validator;
  bool suppress_conditional_sample_validator{false};
  std::optional<ConditionalSupportEnumeratorV1>
      conditional_support_enumerator;
  std::optional<ConditionalSupportQueryV1> conditional_support_query;
  std::optional<ConditionalTargetRatioContractV1> target_ratio_contract;
  std::optional<ConditionalTargetRatioCallbackV1> target_ratio_operation;
  std::optional<ConditionalExactInnovationContractV1>
      exact_innovation_contract;
  std::optional<ConditionalExactInnovationCallbackV1>
      exact_innovation_operation;
};

[[nodiscard]] inline const C17TemporalFixtureOverrideV1*&
c17_temporal_fixture_override_slot() noexcept {
  static thread_local const C17TemporalFixtureOverrideV1* active = nullptr;
  return active;
}

class ScopedC17TemporalFixtureOverride final {
 public:
  explicit ScopedC17TemporalFixtureOverride(
      const C17TemporalFixtureOverrideV1& replacement) noexcept
      : previous_(c17_temporal_fixture_override_slot()) {
    c17_temporal_fixture_override_slot() = &replacement;
  }

  ScopedC17TemporalFixtureOverride(
      const ScopedC17TemporalFixtureOverride&) = delete;
  ScopedC17TemporalFixtureOverride& operator=(
      const ScopedC17TemporalFixtureOverride&) = delete;

  ~ScopedC17TemporalFixtureOverride() {
    c17_temporal_fixture_override_slot() = previous_;
  }

 private:
  const C17TemporalFixtureOverrideV1* previous_;
};

inline constexpr std::string_view kC17DirectFactorLaw =
    "c17.direct.factor.law";
inline constexpr std::string_view kC17DirectValue =
    "c17.direct.value";

struct DirectRuntimeCountersV1 final {
  std::atomic<unsigned> factor_cminus_enumerator{0U};
  std::atomic<unsigned> request_encoder{0U};
  std::atomic<unsigned> decoder{0U};
  std::atomic<unsigned> result_validator{0U};
};

[[nodiscard]] inline std::shared_ptr<std::atomic<unsigned>>&
c17_direct_factor_row_calls() {
  static auto calls = std::make_shared<std::atomic<unsigned>>(0U);
  return calls;
}

[[nodiscard]] inline std::shared_ptr<DirectRuntimeCountersV1>&
c17_direct_runtime_counters() {
  static auto calls = std::make_shared<DirectRuntimeCountersV1>();
  return calls;
}

inline void reset_c17_direct_runtime_counters() noexcept {
  c17_direct_factor_row_calls()->store(0U, std::memory_order_relaxed);
  c17_direct_runtime_counters()->factor_cminus_enumerator.store(
      0U, std::memory_order_relaxed);
  c17_direct_runtime_counters()->request_encoder.store(
      0U, std::memory_order_relaxed);
  c17_direct_runtime_counters()->decoder.store(0U,
                                                std::memory_order_relaxed);
  c17_direct_runtime_counters()->result_validator.store(
      0U, std::memory_order_relaxed);
}

[[nodiscard]] inline std::vector<std::byte> c17_direct_half_bytes() {
  return {std::byte{0x01}, std::byte{0x02}};
}

[[nodiscard]] inline std::shared_ptr<std::atomic<unsigned>>&
c17_temporal_generator_calls() {
  static auto calls = std::make_shared<std::atomic<unsigned>>(0U);
  return calls;
}

[[nodiscard]] inline bool is_c17_temporal_fixture(
    const PortablePlugPayload& payload) {
  const auto* recipe =
      std::get_if<PortableRegisteredRuntimeRecipeV1>(&payload.value());
  if (recipe != nullptr) {
    return recipe->normalized_record.parameters.size() == 1U &&
           recipe->normalized_record.parameters.front().name ==
               kC17TemporalFixtureParameter;
  }
  const auto* finite =
      std::get_if<PortableFiniteLawTablesV1>(&payload.value());
  if (finite == nullptr) return false;
  const auto* residence = std::get_if<RomrResidenceWordTableV1>(
      &finite->normalized_record.table);
  return residence != nullptr &&
         residence->law_id.object_id == label(kC20EnumerableRomrLaw);
}

[[nodiscard]] inline RuntimeOperationIdentityV1 temporal_operation(
    const std::string_view name) {
  return {RuntimeOperationIdV1(label(name)), 1U};
}

[[nodiscard]] inline TemporalEventContractV1 temporal_event_contract(
    const EventContractKindV1 kind = EventContractKindV1::romr_residence,
    const bool defective_hitting_law = false) {
  return {
      kind,
      temporal_operation("c17.fixture.temporal.generator"),
      temporal_operation("c17.fixture.temporal.entry"),
      temporal_operation("c17.fixture.temporal.stopping"),
      temporal_operation("c17.fixture.temporal.reentry"),
      temporal_operation("c17.fixture.temporal.predecision"),
      temporal_operation("c17.fixture.temporal.completed-edge"),
      EventFiltrationV1::generated_slot_natural_filtration,
      {"c17.fixture.exact-reduced-state", 1U},
      {"c17.fixture.exact-reduced-state", 1U},
      {"c17.fixture.exact-reduced-state", 1U},
      {"c17.fixture.exact-reduced-state", 1U},
      {"c17.fixture.temporal.indicator", 1U},
      {"c17.fixture.temporal.predecision-projection", 1U},
      {"c17.fixture.temporal.completed-edge-projection", 1U},
      true,
      true,
      true,
      defective_hitting_law};
}

[[nodiscard]] inline TemporalEventOperationsV1 temporal_event_operations(
    const TemporalEventContractV1& event) {
  const C17TemporalFixtureOverrideV1* const override =
      c17_temporal_fixture_override_slot();
  EventEntryInitializerCallbackV1 entry_initializer =
      [codec = event.continuation_space](
          const CanonicalRuntimeValueV1& input) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, input.canonical_value});
      };
  EventStoppingIndicatorCallbackV1 stopping_indicator =
      [codec = event.stopping_indicator](const CanonicalRuntimeValueV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, {std::byte{0x01}}});
      };
  EventTerminalReentryCallbackV1 terminal_reentry =
      [codec = event.reentry_space](
          const EventTerminalReentryInputV1& input) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, input.successor_state.canonical_value});
      };
  EventPredecisionProjectionCallbackV1 predecision_projection =
      [codec = event.predecision_projection](
          const EventPredecisionProjectionInputV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, {std::byte{0x01}}});
      };
  EventCompletedEdgeProjectionCallbackV1 completed_edge_projection =
      [codec = event.completed_edge_projection](
          const EventCompletedEdgeProjectionInputV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {codec, {std::byte{0x01}}});
      };
  if (override != nullptr) {
    if (override->entry_initializer.has_value()) {
      entry_initializer = *override->entry_initializer;
    }
    if (override->stopping_indicator.has_value()) {
      stopping_indicator = *override->stopping_indicator;
    }
    if (override->terminal_reentry.has_value()) {
      terminal_reentry = *override->terminal_reentry;
    }
    if (override->predecision_projection.has_value()) {
      predecision_projection = *override->predecision_projection;
    }
    if (override->completed_edge_projection.has_value()) {
      completed_edge_projection = *override->completed_edge_projection;
    }
  }
  return {
      EventEntryInitializerOperationV1(
          {event.entry_initializer_operation, event.entrance_space,
           event.continuation_space},
          std::move(entry_initializer)),
      EventStoppingIndicatorOperationV1(
          {event.stopping_indicator_operation, event.stopping_filtration,
           event.continuation_space, event.stopping_indicator},
          std::move(stopping_indicator)),
      EventTerminalReentryOperationV1(
          {event.terminal_reentry_operation, event.terminal_space,
           event.continuation_space, event.reentry_space},
          std::move(terminal_reentry)),
      EventPredecisionProjectionOperationV1(
          {event.predecision_projection_operation, event.entrance_space,
           event.continuation_space, event.predecision_projection},
          std::move(predecision_projection)),
      EventCompletedEdgeProjectionOperationV1(
          {event.completed_edge_projection_operation,
           event.predecision_projection, event.continuation_space,
           event.completed_edge_projection},
          std::move(completed_edge_projection))};
}

[[nodiscard]] inline Result<RuntimePlugCandidateV1>
c17_temporal_fixture_candidate(
    const PortablePlugPayload& payload,
    const AcceptedCapabilityContract& contract,
    const std::optional<Digest256> configured_arrival_binding =
        std::nullopt,
    const bool bind_declared_surrogate_reset_fields = false) {
  PlugDescriptorCore core = contract.descriptor_core();
  const bool non_temporal_staged =
      core.semantic == SemanticTagV1::staged_opportunity_flux_law;
  std::vector<RuntimeStateFieldV1> fields;
  fields.reserve(core.state_fields.size());
  for (std::size_t index = 0U; index < core.state_fields.size(); ++index) {
    fields.push_back(
        {RuntimeFieldIdV1(label("field." + std::to_string(index))),
         core.state_fields[index], RuntimeDomainKindV1::countable});
  }
  std::vector<RuntimeFieldIdV1> read_fields;
  read_fields.reserve(fields.size());
  for (const RuntimeStateFieldV1& field : fields) {
    read_fields.push_back(field.id);
  }
  const std::vector<RuntimeFieldIdV1> transition_fields = read_fields;

  const CodecIdentityV1 state_codec{
      "c17.fixture.exact-reduced-state", 1U};
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.temporal.opportunity", 1U};
  CMinusOperationSchemaV1 c_minus{
      RuntimeOperationIdV1(label("c17.fixture.temporal.c-minus")),
      1U, state_codec, opportunity_codec, std::move(read_fields), {}};
  CPlusOperationSchemaV1 c_plus{
      RuntimeOperationIdV1(label("c17.fixture.temporal.c-plus")),
      1U,
      state_codec,
      {std::string(kC17EmittedOpportunityCodecIdV1),
       kC17EmittedOpportunityCodecVersionV1},
      {std::string(kC17ResolvedActionCodecIdV1),
       kC17ResolvedActionCodecVersionV1},
      {std::string(kC17ConfiguredArrivalTransitionCodecIdV1),
       kC17ConfiguredArrivalTransitionCodecVersionV1},
      {"c17.fixture.temporal.patch", 1U},
      {},
      {},
      {}};
  const EventContractKindV1 event_kind =
      core.semantic == SemanticTagV1::temporal_one_slot_continuation
          ? EventContractKindV1::one_slot_continuation
      : core.semantic == SemanticTagV1::stopped_path_law
          ? EventContractKindV1::stopped_path
          : EventContractKindV1::romr_residence;
  TemporalEventContractV1 event = temporal_event_contract(
      event_kind, event_kind == EventContractKindV1::stopped_path);
  if (bind_declared_surrogate_reset_fields) {
    for (const RuntimeStateFieldV1& field : fields) {
      if (field.c14_field.ownership == FieldOwnershipV1::surrogate_owned) {
        event.residence_local_reset_fields.push_back(field.id);
        c_plus.writable_unresolved_fields.push_back(field.id);
      }
    }
  }
  if (const C17TemporalFixtureOverrideV1* const override =
          c17_temporal_fixture_override_slot();
      override != nullptr) {
    event.residence_local_reset_fields =
        override->residence_local_reset_fields;
    c_plus.writable_unresolved_fields =
        override->c_plus_writable_unresolved_fields;
  }
  if (core.marks.empty()) {
    return Result<RuntimePlugCandidateV1>::failure(
        reached_materializer());
  }
  const bool conditional_sampler =
      core.runtime_access ==
      RuntimeAccessTagV1::normalized_conditional_sampler;
  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  std::vector<RuntimeMarkIdV1> c_minus_marks;
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    const MarkDescriptorV1& mark = core.marks[index];
    const RuntimeMarkIdV1 mark_id(
        label("mark." + std::to_string(index)));
    const bool entrance =
        mark.reveal_stage == MetricRevealStageV1::entrance_label;
    const bool sampled_departure =
        conditional_sampler &&
        mark.kind == MetricMarkKindV1::actual_departure &&
        mark.reveal_stage == MetricRevealStageV1::decision;
    const bool staged_backlog =
        non_temporal_staged &&
        mark.kind == MetricMarkKindV1::target_backlog &&
        mark.reveal_stage == MetricRevealStageV1::predecision;
    const bool staged_opportunity =
        non_temporal_staged &&
        mark.kind == MetricMarkKindV1::opportunity &&
        mark.reveal_stage == MetricRevealStageV1::predecision;
    if (!entrance && !sampled_departure && !staged_backlog &&
        !staged_opportunity &&
        !(mark.kind == MetricMarkKindV1::active_component &&
          mark.reveal_stage == MetricRevealStageV1::completed_edge)) {
      return Result<RuntimePlugCandidateV1>::failure(
          reached_materializer());
    }
    std::vector<RuntimeFieldIdV1> dependencies;
    if (!entrance && !sampled_departure && !staged_backlog &&
        !staged_opportunity) {
      const auto local_field = std::ranges::find_if(
          fields, [&](const RuntimeStateFieldV1& field) {
            return field.c14_field.kind ==
                       StateFieldKindV1::surrogate_phase &&
                   field.c14_field.codec == mark.codec &&
                   std::ranges::find(event.residence_local_reset_fields,
                                     field.id) !=
                       event.residence_local_reset_fields.end();
          });
      if (local_field == fields.end()) {
        return Result<RuntimePlugCandidateV1>::failure(
            reached_materializer());
      }
      dependencies.push_back(local_field->id);
    }
    if (staged_opportunity) c_minus_marks.push_back(mark_id);
    marks.push_back(
        {mark_id, mark,
         RuntimeDecoderIdV1(label("decoder." + std::to_string(index))),
         entrance ? MarkDecoderSourceV1::entrance_realization
         : sampled_departure ? MarkDecoderSourceV1::decision_schedule
         : staged_backlog ? MarkDecoderSourceV1::predecision_state
         : staged_opportunity ? MarkDecoderSourceV1::c_minus_joint_output
                  : MarkDecoderSourceV1::completed_edge,
         staged_backlog ? RuntimeDomainKindV1::countable
                        : RuntimeDomainKindV1::finite,
         entrance ? event.entrance_space
         : sampled_departure
             ? CodecIdentityV1{
                   std::string(kC17ResolvedActionCodecIdV1),
                   kC17ResolvedActionCodecVersionV1}
         : staged_backlog ? state_codec
         : staged_opportunity ? opportunity_codec
                  : event.completed_edge_projection,
         std::move(dependencies),
         {}});
  }
  c_minus.jointly_emitted_marks = c_minus_marks;
  const bool finite_row =
      core.runtime_access == RuntimeAccessTagV1::finite_enumerated_row;
  const bool sparse_row =
      core.runtime_access == RuntimeAccessTagV1::sparse_row;
  PlugDescriptor descriptor{
      1U,
      std::move(core),
      std::move(fields),
      c_minus,
      c_plus,
      std::move(marks),
      non_temporal_staged
          ? std::optional<TemporalEventContractV1>{}
          : std::optional<TemporalEventContractV1>{event},
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity, CertificateLevelV1::v0_shape,
        CodecIdentityV1{contract.descriptor_core().mandatory_v0.factor_schema_id,
                        contract.descriptor_core().mandatory_v0
                            .factor_schema_version}}},
      (conditional_sampler || finite_row || sparse_row)
          ? std::optional<TransitionStateSchemaV1>{TransitionStateSchemaV1{
                state_codec, state_codec, transition_fields}}
          : std::nullopt,
      digest("c17.fixture.temporal.descriptor.placeholder")};
  auto descriptor_digest = canonical_plug_descriptor_digest_v1(descriptor);
  if (!descriptor_digest) {
    return Result<RuntimePlugCandidateV1>::failure(
        descriptor_digest.error());
  }
  descriptor.descriptor_digest = std::move(descriptor_digest).value();

  const QueueId target = descriptor.core.deployed_targets.front();
  const auto c_minus_output =
      [target, opportunity_codec, c_minus_marks,
       opportunity_mark_codec = [&descriptor]() {
         const auto found = std::ranges::find_if(
             descriptor.marks, [](const RuntimeMarkDescriptorV1& mark) {
               return mark.c14_mark.kind == MetricMarkKindV1::opportunity;
             });
         return found == descriptor.marks.end()
                    ? CodecIdentityV1{"service.bit", 1U}
                    : found->c14_mark.codec;
       }()] {
    std::vector<RuntimeDecodedMarkV1> jointly_emitted;
    if (!c_minus_marks.empty()) {
      jointly_emitted.push_back(
          {c_minus_marks.front(),
           {opportunity_mark_codec, {std::byte{0x01}}}});
    }
    return CMinusOutputV1{
        {opportunity_codec, {std::byte{0x01}}},
        std::move(jointly_emitted),
        V0EmittedOpportunityFaceV1{{
            {{}, {}, ExactRational::zero()},
            {{target}, {}, ExactRational::zero()}}},
        std::nullopt};
  };
  CMinusCallbackV1 realize_c_minus =
      [c_minus_output](const CMinusInputV1&, DeterministicRng&) {
        return Result<CMinusOutputV1>::success(c_minus_output());
      };
  EnumerateCMinusExactLawV1 enumerate_c_minus =
      [c_minus_output](const CMinusInputV1&) {
        return Result<std::vector<EnumeratedCMinusAtomV1>>::success({
            {c_minus_output(),
             ProbabilityMass::exact_rational(ExactRational::one(), true)
                 .value()}});
      };
  if (const C17TemporalFixtureOverrideV1* const override =
          c17_temporal_fixture_override_slot();
      override != nullptr) {
    if (override->c_minus.has_value()) {
      realize_c_minus = *override->c_minus;
    }
    if (override->enumerate_c_minus.has_value()) {
      enumerate_c_minus = *override->enumerate_c_minus;
    }
  }
  CMinusOperationV1 c_minus_operation{
      c_minus, std::move(realize_c_minus), std::move(enumerate_c_minus)};
  const auto c_plus_output = [] { return CPlusOutputV1{{}, {}}; };
  CPlusCallbackV1 realize_c_plus =
      [c_plus_output](const CPlusInputV1&, DeterministicRng&) {
        return Result<CPlusOutputV1>::success(c_plus_output());
      };
  EnumerateCPlusExactLawV1 enumerate_c_plus =
      [c_plus_output](const CPlusInputV1&) {
        return Result<std::vector<EnumeratedCPlusAtomV1>>::success({
            {c_plus_output(),
             ProbabilityMass::exact_rational(ExactRational::one(), true)
                 .value()}});
      };
  if (const C17TemporalFixtureOverrideV1* const override =
          c17_temporal_fixture_override_slot();
      override != nullptr) {
    if (override->c_plus.has_value()) {
      realize_c_plus = *override->c_plus;
    }
    if (override->enumerate_c_plus.has_value()) {
      enumerate_c_plus = *override->enumerate_c_plus;
    }
  }
  CPlusOperationV1 c_plus_operation{
      c_plus, std::move(realize_c_plus), std::move(enumerate_c_plus)};
  CausalSurrogateOperationsV1 operations{
      std::move(c_minus_operation), std::move(c_plus_operation),
      non_temporal_staged
          ? std::optional<TemporalEventOperationsV1>{}
          : std::optional<TemporalEventOperationsV1>{
                temporal_event_operations(event)}};

  std::vector<CodecIdentityV1> mark_codecs;
  mark_codecs.reserve(descriptor.marks.size());
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    mark_codecs.push_back(mark.c14_mark.codec);
  }
  KernelAccess access = [&]() -> KernelAccess {
    if (conditional_sampler) {
      ConditionalSamplerCallbackV1 sampler =
          [mark_codecs, non_temporal_staged](
              const CanonicalRuntimeValueV1& state,
              DeterministicRng& rng) {
            if (non_temporal_staged) {
              c27_conditional_reward_sample_calls().fetch_add(
                  1U, std::memory_order_relaxed);
              // Consume the one advertised generic-sampling word even though
              // this positive fixture's supported row is a singleton.  The
              // execution result can therefore account one truthful replayed
              // draw per requested replication.
              (void)rng.next_u64();
            }
            std::vector<CanonicalRuntimeValueV1> generated;
            generated.reserve(mark_codecs.size());
            for (const CodecIdentityV1& codec : mark_codecs) {
              generated.push_back({codec, {std::byte{0x01}}});
            }
            return Result<KernelTransitionV1>::success(
                {state, std::move(generated)});
          };
      ConditionalSamplerContractV1 sampler_contract{
          1U,
          ConditionalSamplerRevealStageV1::generic_row_residual,
          ConditionalSampleDependenceV1::iid_cold_replications,
          ConditionalSupportKindV1::finite_declared,
          1U,
          digest("c17.fixture.reduced-state-schema"),
          digest("c17.fixture.sampler.support"),
          digest("c17.fixture.sampler.proposal"),
          digest("c17.fixture.sampler.residual-schema"),
          digest("c17.fixture.sampler.output-schema"),
          digest("c17.fixture.sampler.configured-arrival"),
          digest("c17.fixture.sampler.common-projection"),
          true,
          true,
          true,
          true,
          true,
          SamplerEvidenceScopeV1::declared,
          SamplerEvidenceScopeV1::declared,
          SamplerV1EvidenceScopeV1::none,
          std::nullopt,
          SamplerV2EvidenceScopeV1::none,
          std::nullopt,
          std::nullopt};
      ConditionalSupportEnumeratorV1 support_enumerator =
          [mark_codecs](const CanonicalRuntimeValueV1& state) {
            std::vector<CanonicalRuntimeValueV1> generated;
            generated.reserve(mark_codecs.size());
            for (const CodecIdentityV1& codec : mark_codecs) {
              generated.push_back({codec, {std::byte{0x01}}});
            }
            return Result<std::vector<KernelTransitionV1>>::success(
                {{state, std::move(generated)}});
          };
      ConditionalSupportQueryV1 support_query =
          [mark_codecs](const CanonicalRuntimeValueV1& state,
                        const KernelTransitionV1& sample) {
            if (sample.successor_state != state ||
                sample.ordered_marks.size() != mark_codecs.size()) {
              return Result<bool>::success(false);
            }
            for (std::size_t index = 0U; index < mark_codecs.size();
                 ++index) {
              if (sample.ordered_marks[index].codec != mark_codecs[index] ||
                  sample.ordered_marks[index].canonical_value !=
                      std::vector<std::byte>{std::byte{0x01}}) {
                return Result<bool>::success(false);
              }
            }
            return Result<bool>::success(true);
          };
      ConditionalSampleValidatorV1 sample_validator;
      bool suppress_sample_validator = false;
      std::optional<ConditionalTargetRatioContractV1> ratio_contract;
      ConditionalTargetRatioCallbackV1 ratio;
      std::optional<ConditionalExactInnovationContractV1>
          innovation_contract;
      ConditionalExactInnovationCallbackV1 innovation;

      if (const C17TemporalFixtureOverrideV1* const override =
              c17_temporal_fixture_override_slot();
          override != nullptr) {
        if (override->conditional_sampler_operation.has_value()) {
          sampler = *override->conditional_sampler_operation;
        }
        if (override->conditional_sampler_contract.has_value()) {
          sampler_contract = *override->conditional_sampler_contract;
        }
        if (override->conditional_sample_validator.has_value()) {
          sample_validator = *override->conditional_sample_validator;
        }
        suppress_sample_validator =
            override->suppress_conditional_sample_validator;
        if (override->conditional_support_enumerator.has_value()) {
          support_enumerator = *override->conditional_support_enumerator;
        }
        if (override->conditional_support_query.has_value()) {
          support_query = *override->conditional_support_query;
        }
        ratio_contract = override->target_ratio_contract;
        if (override->target_ratio_operation.has_value()) {
          ratio = *override->target_ratio_operation;
        }
        innovation_contract = override->exact_innovation_contract;
        if (override->exact_innovation_operation.has_value()) {
          innovation = *override->exact_innovation_operation;
        }
        if (override->conditional_sampler_calls) {
          auto operation = std::move(sampler);
          const auto calls = override->conditional_sampler_calls;
          sampler = [operation = std::move(operation), calls](
                        const CanonicalRuntimeValueV1& state,
                        DeterministicRng& rng) {
            calls->fetch_add(1U, std::memory_order_relaxed);
            return operation(state, rng);
          };
        }
        if (override->conditional_sampler_configured_arrival_binding
                .has_value()) {
          const Digest256 authored_arrival =
              sampler_contract.configured_arrival_law;
          sampler_contract.configured_arrival_law =
              *override->conditional_sampler_configured_arrival_binding;
          // A fixture innovation authored against the same sampler placeholder
          // follows the sampler to the scenario binding.  An intentionally
          // foreign innovation identity is left untouched for negative tests.
          if (innovation_contract.has_value() &&
              innovation_contract->configured_arrival_law ==
                  authored_arrival) {
            innovation_contract->configured_arrival_law =
                sampler_contract.configured_arrival_law;
          }
        }
      }
      if (configured_arrival_binding.has_value()) {
        sampler_contract.configured_arrival_law =
            *configured_arrival_binding;
      }

      const auto accepted_sampling_contract = std::ranges::find_if(
          contract.metric_contracts(),
          [](const ResolvedMetricContractV1& resolved) {
            return resolved.runtime_access ==
                       RuntimeAccessTagV1::normalized_conditional_sampler &&
                   resolved.solver_regime == SolverRegimeV1::monte_carlo &&
                   (resolved.backend_route ==
                        BackendRouteKindV1::conditional_row_monte_carlo ||
                    resolved.backend_route ==
                        BackendRouteKindV1::conditional_reward_monte_carlo);
          });
      if (accepted_sampling_contract != contract.metric_contracts().end()) {
        const auto is_zero_digest = [](const Digest256& value) {
          return std::ranges::all_of(value.bytes(), [](const std::byte byte) {
            return byte == std::byte{0};
          });
        };
        // A zero test-fixture placeholder requests binding to the exact
        // accepted support clause. Nonzero foreign values are preserved so
        // V0 negative tests can prove that no authority is repaired.
        if (ratio_contract.has_value() &&
            is_zero_digest(ratio_contract->metric_target_digest)) {
          ratio_contract->metric_target_digest =
              accepted_sampling_contract->support_clause_digest;
        }
        if (innovation_contract.has_value() &&
            is_zero_digest(innovation_contract->metric_target_digest)) {
          innovation_contract->metric_target_digest =
              accepted_sampling_contract->support_clause_digest;
        }
      }

      if (!sample_validator && !suppress_sample_validator) {
        std::vector<MarkDescriptorV1> declared_marks;
        declared_marks.reserve(descriptor.marks.size());
        for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
          declared_marks.push_back(mark.c14_mark);
        }
        const auto reveal_stage = sampler_contract.reveal_stage;
        const bool common_projection =
            sampler_contract.common_projection_identity.has_value();
        sample_validator =
            [declared_marks = std::move(declared_marks), reveal_stage,
             common_projection](
                const CanonicalRuntimeValueV1& state,
                const KernelTransitionV1& sample) -> Result<void> {
          for (const auto& mark : sample.ordered_marks) {
            if (mark.canonical_value.size() != 1U) {
              return Result<void>::failure({
                  DiagnosticCategory::input_validation,
                  "c24.fixture.sample_mark_outside_value_domain",
                  "a sampled mark is outside its sealed one-byte value "
                  "domain",
                  std::nullopt, std::nullopt, {}});
            }
          }
          if (sample.successor_state.canonical_value.size() !=
                  state.canonical_value.size() ||
              (state.canonical_value.size() > 1U &&
               !std::equal(state.canonical_value.begin(),
                           state.canonical_value.end() - 1,
                           sample.successor_state.canonical_value.begin()))) {
            return Result<void>::failure({
                DiagnosticCategory::input_validation,
                "c24.fixture.exact_coordinate_update_violation",
                "the sample changed a fixture-owned exact coordinate",
                std::nullopt, std::nullopt, {}});
          }
          if (reveal_stage ==
              ConditionalSamplerRevealStageV1::prearrival_residual) {
            const bool reveals_fresh_arrival = std::ranges::any_of(
                declared_marks, [](const MarkDescriptorV1& mark) {
                  return mark.kind == MetricMarkKindV1::arrival_batch ||
                         mark.kind ==
                             MetricMarkKindV1::successor_backlog ||
                         mark.reveal_stage ==
                             MetricRevealStageV1::arrival ||
                         mark.reveal_stage ==
                             MetricRevealStageV1::postarrival ||
                         mark.reveal_stage ==
                             MetricRevealStageV1::completed_edge;
                });
            if (reveals_fresh_arrival) {
              return Result<void>::failure({
                  DiagnosticCategory::input_validation,
                  "c24.fixture.sample_reveal_stage_violation",
                  "a prearrival residual sample revealed a later-stage "
                  "mark",
                  std::nullopt, std::nullopt, {}});
            }
          }
          if (common_projection && sample.ordered_marks.size() >= 3U &&
              sample.ordered_marks[1] != sample.ordered_marks[2]) {
            return Result<void>::failure({
                DiagnosticCategory::input_validation,
                "c24.fixture.common_projection_violation",
                "the completed sample is inconsistent with the sealed "
                "common projection for its conditioning row",
                std::nullopt, std::nullopt, {}});
          }
          return Result<void>::success();
        };
      }

      return NormalizedConditionalSamplerAccess(
          {state_codec, state_codec, mark_codecs, std::nullopt,
           non_temporal_staged
               ? std::optional<TransitionGeneratorOperationIdentityV1>{}
               : std::optional<TransitionGeneratorOperationIdentityV1>{
                     TransitionGeneratorOperationIdentityV1{
                         KernelOperationIdV1(label(
                             "c17.fixture.temporal.generator")),
                         event.event_generator_operation
                             .operation_version}}},
          std::move(sampler), std::move(sampler_contract),
          std::move(sample_validator),
          std::move(support_enumerator), std::move(support_query),
          std::move(ratio_contract), std::move(ratio),
          std::move(innovation_contract), std::move(innovation));
    }
    if (finite_row || sparse_row) {
      TransitionKernelAccessShapeV1 shape{
          state_codec,
          state_codec,
          mark_codecs,
          4U,
          TransitionGeneratorOperationIdentityV1{
              KernelOperationIdV1(
                  label("c17.fixture.temporal.generator")),
              event.event_generator_operation.operation_version}};
      EnumeratedRowCallbackV1 row =
          [state_codec, mark_codecs](const CanonicalRuntimeValueV1& state) {
            if (state.codec != state_codec) {
              return Result<std::vector<KernelRowAtomV1>>::failure(
                  reached_materializer());
            }
            auto mass = ProbabilityMass::exact_rational(
                ExactRational::one(), true);
            if (!mass) {
              return Result<std::vector<KernelRowAtomV1>>::failure(
                  mass.error());
            }
            std::vector<CanonicalRuntimeValueV1> generated;
            generated.reserve(mark_codecs.size());
            for (const CodecIdentityV1& codec : mark_codecs) {
              generated.push_back({codec, {std::byte{0x01}}});
            }
            std::vector<KernelRowAtomV1> atoms;
            atoms.push_back(
                {{state, std::move(generated)},
                 std::move(mass).value()});
            return Result<std::vector<KernelRowAtomV1>>::success(
                std::move(atoms));
          };
      if (finite_row) {
        return FiniteEnumeratedRowAccess(std::move(shape), std::move(row));
      }
      return SparseRowAccess(std::move(shape), std::move(row));
    }
    return ProceduralResidenceGeneratorAccess(
        {event.entrance_space, event.continuation_space,
         event.terminal_space, event.reentry_space, mark_codecs,
         c17_temporal_fixture_override_slot() == nullptr
             ? 1U
             : c17_temporal_fixture_override_slot()
                   ->maximum_residence_slots},
        {KernelOperationIdV1(
             label("c17.fixture.temporal.generator")),
         event.event_generator_operation.operation_version,
         event.stopping_indicator},
        true,
        [event, mark_codecs,
         calls = c17_temporal_generator_calls()](
            const CanonicalRuntimeValueV1&, DeterministicRng&) {
          calls->fetch_add(1U, std::memory_order_relaxed);
          const CanonicalRuntimeValueV1 continuation{
              event.continuation_space, {std::byte{0x01}}};
          std::vector<CanonicalRuntimeValueV1> generated;
          generated.reserve(mark_codecs.size());
          for (const CodecIdentityV1& codec : mark_codecs) {
            generated.push_back({codec, {std::byte{0x01}}});
          }
          return Result<GeneratedResidenceWordV1>::success(
              {BigNat{1U},
               {{continuation,
                 {continuation, std::move(generated)}}},
               {event.terminal_space, {std::byte{0x01}}},
               {event.reentry_space, {std::byte{0x01}}}});
        });
  }();
  SurrogatePlug plug = [&]() -> SurrogatePlug {
    if (descriptor.core.semantic ==
        SemanticTagV1::staged_opportunity_flux_law) {
      return StagedOpportunityFluxPlugV1{
          payload, std::move(access), std::move(operations)};
    }
    if (descriptor.core.semantic ==
        SemanticTagV1::temporal_one_slot_continuation) {
      return TemporalOneSlotContinuationPlugV1{
          payload, std::move(access), std::move(operations)};
    }
    if (descriptor.core.semantic == SemanticTagV1::stopped_path_law) {
      return StoppedPathPlugV1{
          payload, std::move(access), std::move(operations)};
    }
    return RomrResidenceWordPlugV1{
        payload, std::move(access), std::move(operations)};
  }();
  return Result<RuntimePlugCandidateV1>::success(
      {std::move(descriptor), std::move(plug)});
}

[[nodiscard]] inline bool is_c17_direct_factor_fixture(
    const PortablePlugPayload& payload) {
  const auto* finite =
      std::get_if<PortableFiniteLawTablesV1>(&payload.value());
  if (finite == nullptr) return false;
  const auto* table = std::get_if<StationaryMarkedEdgeTableV1>(
      &finite->normalized_record.table);
  return table != nullptr &&
         table->law_id.object_id == label(kC17DirectFactorLaw);
}

[[nodiscard]] inline bool is_c17_direct_decoder_fixture(
    const PortablePlugPayload& payload) {
  const auto* direct =
      std::get_if<PortableDirectMetricPayloadV1>(&payload.value());
  return direct != nullptr && direct->normalized_record.values.size() == 1U &&
         direct->normalized_record.values.front().value_id.object_id ==
             label(kC17DirectValue);
}

[[nodiscard]] inline Result<RuntimePlugCandidateV1>
c17_direct_factor_fixture_candidate(
    const PortablePlugPayload& payload,
    const AcceptedCapabilityContract& contract) {
  PlugDescriptorCore core = contract.descriptor_core();
  // This is an auxiliary request-local recipe, not a second C15 artifact or
  // accepted capability contract.  Retain every outer direct-request axis
  // while giving C17 the exact generative semantic/access pair it must audit.
  core.semantic = SemanticTagV1::stationary_marked_edge;
  core.runtime_access = RuntimeAccessTagV1::finite_enumerated_row;
  auto factor_core_digest = canonical_plug_descriptor_core_digest_v1(core);
  if (!factor_core_digest) {
    return Result<RuntimePlugCandidateV1>::failure(
        factor_core_digest.error());
  }
  core.core_digest = std::move(factor_core_digest).value();
  if (core.deployed_targets.size() != 1U || core.marks.empty() ||
      core.marks.size() > 2U ||
      core.marks.front().kind != MetricMarkKindV1::actual_departure ||
      (core.marks.size() == 2U &&
       core.marks.back().kind != MetricMarkKindV1::successor_backlog)) {
    return Result<RuntimePlugCandidateV1>::failure(reached_materializer());
  }
  std::vector<RuntimeStateFieldV1> fields;
  std::vector<RuntimeFieldIdV1> ordered_fields;
  fields.reserve(core.state_fields.size());
  ordered_fields.reserve(core.state_fields.size());
  for (std::size_t index = 0U; index < core.state_fields.size(); ++index) {
    RuntimeFieldIdV1 id(label("field." + std::to_string(index)));
    ordered_fields.push_back(id);
    fields.push_back(
        {std::move(id), core.state_fields[index],
         RuntimeDomainKindV1::countable});
  }

  const CodecIdentityV1 state_codec{
      "c17.fixture.exact-reduced-state", 1U};
  const CodecIdentityV1 opportunity_codec{
      "c17.fixture.direct-factor.opportunity", 1U};
  CMinusOperationSchemaV1 c_minus{
      RuntimeOperationIdV1(label("c17.fixture.direct-factor.c-minus")),
      1U, state_codec, opportunity_codec, ordered_fields, {}};
  CPlusOperationSchemaV1 c_plus{
      RuntimeOperationIdV1(label("c17.fixture.direct-factor.c-plus")),
      1U,
      state_codec,
      {std::string(kC17EmittedOpportunityCodecIdV1),
       kC17EmittedOpportunityCodecVersionV1},
      {std::string(kC17ResolvedActionCodecIdV1),
       kC17ResolvedActionCodecVersionV1},
      {std::string(kC17ConfiguredArrivalTransitionCodecIdV1),
       kC17ConfiguredArrivalTransitionCodecVersionV1},
      {"c17.fixture.direct-factor.patch", 1U},
      {},
      {},
      {}};
  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    const bool successor =
        core.marks[index].kind == MetricMarkKindV1::successor_backlog;
    marks.push_back(
        {RuntimeMarkIdV1(label("mark." + std::to_string(index))),
         core.marks[index],
         RuntimeDecoderIdV1(label("decoder." + std::to_string(index))),
         successor ? MarkDecoderSourceV1::postarrival_state
                   : MarkDecoderSourceV1::decision_schedule,
         successor ? RuntimeDomainKindV1::countable
                   : RuntimeDomainKindV1::finite,
         successor
             ? state_codec
             : CodecIdentityV1{
                   std::string(kC17ResolvedActionCodecIdV1),
                   kC17ResolvedActionCodecVersionV1},
         {},
         {}});
  }
  PlugDescriptor descriptor{
      1U,
      std::move(core),
      std::move(fields),
      c_minus,
      c_plus,
      std::move(marks),
      std::nullopt,
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity, CertificateLevelV1::v0_shape,
        CodecIdentityV1{contract.descriptor_core().mandatory_v0.factor_schema_id,
                        contract.descriptor_core().mandatory_v0
                            .factor_schema_version}}},
      TransitionStateSchemaV1{state_codec, state_codec, ordered_fields},
      digest("c17.fixture.direct-factor.descriptor.placeholder")};
  auto descriptor_digest = canonical_plug_descriptor_digest_v1(descriptor);
  if (!descriptor_digest) {
    return Result<RuntimePlugCandidateV1>::failure(
        descriptor_digest.error());
  }
  descriptor.descriptor_digest = std::move(descriptor_digest).value();

  const QueueId target = descriptor.core.deployed_targets.front();
  const auto c_minus_output = [target, opportunity_codec] {
    return CMinusOutputV1{
        {opportunity_codec, {std::byte{0x01}}},
        {},
        V0EmittedOpportunityFaceV1{{
            {{}, {}, ExactRational::zero()},
            {{target}, {}, ExactRational::zero()}}},
        std::nullopt};
  };
  auto direct_counters = c17_direct_runtime_counters();
  CMinusOperationV1 c_minus_operation{
      c_minus,
      [c_minus_output](const CMinusInputV1&, DeterministicRng&) {
        return Result<CMinusOutputV1>::success(c_minus_output());
      },
      [c_minus_output, direct_counters](const CMinusInputV1&) {
        direct_counters->factor_cminus_enumerator.fetch_add(
            1U, std::memory_order_relaxed);
        return Result<std::vector<EnumeratedCMinusAtomV1>>::success({
            {c_minus_output(),
             ProbabilityMass::exact_rational(ExactRational::one(), true)
                 .value()}});
      }};
  const auto c_plus_output = [] { return CPlusOutputV1{{}, {}}; };
  CPlusOperationV1 c_plus_operation{
      c_plus,
      [c_plus_output](const CPlusInputV1&, DeterministicRng&) {
        return Result<CPlusOutputV1>::success(c_plus_output());
      },
      [c_plus_output](const CPlusInputV1&) {
        return Result<std::vector<EnumeratedCPlusAtomV1>>::success({
            {c_plus_output(),
             ProbabilityMass::exact_rational(ExactRational::one(), true)
                 .value()}});
      }};
  CausalSurrogateOperationsV1 operations{
      std::move(c_minus_operation), std::move(c_plus_operation),
      std::nullopt};

  std::vector<CodecIdentityV1> mark_codecs;
  mark_codecs.reserve(descriptor.marks.size());
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    mark_codecs.push_back(mark.c14_mark.codec);
  }
  KernelAccess access = FiniteEnumeratedRowAccess(
      {state_codec, state_codec, mark_codecs, 1U, std::nullopt},
      [state_codec, mark_codecs,
       calls = c17_direct_factor_row_calls()](
          const CanonicalRuntimeValueV1& state) {
        calls->fetch_add(1U, std::memory_order_relaxed);
        CanonicalRuntimeValueV1 successor = state;
        bool departure = false;
        if (successor.codec == state_codec &&
            !successor.canonical_value.empty() &&
            successor.canonical_value.front() != std::byte{0x00}) {
          const auto value = std::to_integer<unsigned char>(
              successor.canonical_value.front());
          successor.canonical_value.front() =
              static_cast<std::byte>(value - 1U);
          departure = true;
        }
        std::vector<CanonicalRuntimeValueV1> generated_marks{
            {mark_codecs.front(),
             {departure ? std::byte{0x01} : std::byte{0x00}}}};
        if (mark_codecs.size() == 2U) {
          generated_marks.push_back(
              {mark_codecs.back(),
               {successor.canonical_value.empty()
                    ? std::byte{0x00}
                    : successor.canonical_value.front()}});
        }
        return Result<std::vector<KernelRowAtomV1>>::success({
            {{std::move(successor),
              std::move(generated_marks)},
             ProbabilityMass::exact_rational(ExactRational::one(), true)
                 .value()}});
      });
  SurrogatePlug plug = StationaryMarkedEdgePlugV1{
      payload, std::move(access), std::move(operations)};
  return Result<RuntimePlugCandidateV1>::success(
      {std::move(descriptor), std::move(plug)});
}

[[nodiscard]] inline Result<RuntimePlugCandidateV1>
c17_direct_decoder_fixture_candidate(
    const PortablePlugPayload& payload,
    const ValidatedSurrogateArtifact& artifact,
    const AcceptedCapabilityContract& contract) {
  const auto& direct =
      std::get<PortableDirectMetricPayloadV1>(payload.value())
          .normalized_record;
  const auto& value = direct.values.front();
  const auto& clauses = contract.structural_manifest().clauses();
  if (clauses.size() != 1U) {
    return Result<RuntimePlugCandidateV1>::failure(reached_materializer());
  }
  const auto* metric_domain =
      std::get_if<ExactMetricDecoderDomainV1>(&clauses.front().parameter_domain);
  if (metric_domain == nullptr) {
    return Result<RuntimePlugCandidateV1>::failure(reached_materializer());
  }
  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          value.ordered_targets);
  if (!ordered_target_digest) {
    return Result<RuntimePlugCandidateV1>::failure(
        ordered_target_digest.error());
  }

  PlugDescriptorCore core = contract.descriptor_core();
  std::vector<RuntimeStateFieldV1> fields;
  fields.reserve(core.state_fields.size());
  for (std::size_t index = 0U; index < core.state_fields.size(); ++index) {
    fields.push_back(
        {RuntimeFieldIdV1(label("field." + std::to_string(index))),
         core.state_fields[index], RuntimeDomainKindV1::countable});
  }
  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    marks.push_back({
        RuntimeMarkIdV1(label("mark." + std::to_string(index))),
        core.marks[index],
        RuntimeDecoderIdV1(label("decoder." + std::to_string(index))),
        MarkDecoderSourceV1::decision_schedule,
        RuntimeDomainKindV1::finite,
        {std::string(kC17ResolvedActionCodecIdV1),
         kC17ResolvedActionCodecVersionV1},
        {},
        {}});
  }
  PlugDescriptor descriptor{
      1U,
      std::move(core),
      std::move(fields),
      std::nullopt,
      std::nullopt,
      std::move(marks),
      std::nullopt,
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity, CertificateLevelV1::v0_shape,
        CodecIdentityV1{contract.descriptor_core().mandatory_v0.factor_schema_id,
                        contract.descriptor_core().mandatory_v0
                            .factor_schema_version}}},
      std::nullopt,
      digest("c17.fixture.direct.descriptor.placeholder")};
  auto descriptor_digest = canonical_plug_descriptor_digest_v1(descriptor);
  if (!descriptor_digest) {
    return Result<RuntimePlugCandidateV1>::failure(
        descriptor_digest.error());
  }
  descriptor.descriptor_digest = std::move(descriptor_digest).value();

  const CodecIdentityV1 request_codec{
      "mwperf.c16.direct_metric_request", 1U};
  const CodecIdentityV1 result_codec{
      "mwperf.c16.direct_metric_value", 1U};
  RawDirectDecoderDomainV1 domain{
      *metric_domain,
      value.normalized_metric_request_digest,
      value.request_digest,
      value.target_selection_digest,
      std::move(ordered_target_digest).value(),
      artifact.validation_bindings().analysis_selection_digest,
      value.configured_arrival_digest,
      value.accepted_contract_digest,
      request_codec,
      result_codec};
  auto counters = c17_direct_runtime_counters();
  RawDirectDecoderAccess access(
      domain,
      [counters, request_codec](const MetricRequest&) {
        counters->request_encoder.fetch_add(1U, std::memory_order_relaxed);
        return Result<CanonicalRuntimeValueV1>::success(
            {request_codec, {std::byte{0x01}}});
      },
      [counters, request_codec, result_codec](
          const CanonicalRuntimeValueV1& encoded) {
        counters->decoder.fetch_add(1U, std::memory_order_relaxed);
        if (encoded.codec != request_codec) {
          return Result<CanonicalRuntimeValueV1>::failure(
              reached_materializer());
        }
        return Result<CanonicalRuntimeValueV1>::success(
            {result_codec, c17_direct_half_bytes()});
      },
      [counters, decoder_key = metric_domain->decoder_key,
       result_codec](const ExactMetricDecoderKeyV1& supplied_key,
                     const CodecIdentityV1& supplied_codec,
                     const std::span<const std::byte> supplied_value) {
        counters->result_validator.fetch_add(1U,
                                             std::memory_order_relaxed);
        if (supplied_key != decoder_key || supplied_codec != result_codec ||
            !std::ranges::equal(supplied_value, c17_direct_half_bytes())) {
          return Result<void>::failure(reached_materializer());
        }
        return Result<void>::success();
      });
  SurrogatePlug plug =
      DirectMetricDecoderPlugV1{payload, KernelAccess(std::move(access))};
  return Result<RuntimePlugCandidateV1>::success(
      {std::move(descriptor), std::move(plug)});
}

[[nodiscard]] inline PlugDescriptorCore preview_core(
    const SurrogateProviderManifestV1& manifest,
    const std::vector<QueueId>& targets,
    const MetricSupportClauseV1& clause,
    const Digest256& structural_manifest_digest);

[[nodiscard]] inline PlugDescriptorCore preview_core(
    const SurrogateProviderManifestV1& manifest,
    const std::vector<QueueId>& targets) {
  const auto& clause = manifest.metric_clause_upper_envelope.clauses().front();
  return preview_core(manifest, targets, clause,
                      manifest.metric_clause_upper_envelope
                          .canonical_digest());
}

[[nodiscard]] inline PlugDescriptorCore preview_core(
    const SurrogateProviderManifestV1& manifest,
    const std::vector<QueueId>& targets,
    const MetricSupportClauseV1& clause,
    const Digest256& structural_manifest_digest) {
  const bool envelope =
      manifest.deployed_semantic_tag == SemanticTagV1::response_envelope_law;
  PlugDescriptorCore core{
      1U,
      manifest.provider,
      manifest.optimizer_constraint_applicability,
      manifest.payload_class,
      manifest.deployed_semantic_tag,
      manifest.runtime_access_tag,
      targets,
      clause.target_coupling,
      clause.state_fields,
      clause.marks,
      clause.selection_domain,
      clause.phase_domain,
      {TailRepresentationKindV1::constant_response, BigNat{3U},
       std::nullopt},
      clause.arrival_assumptions,
      clause.hypotheses,
      clause.mandatory_v0,
      {},
      {clause.requested_accuracy},
      {envelope ? ConstructionResultScopeV1::response_envelope
                : ConstructionResultScopeV1::surrogate_law,
       envelope ? ConstructionErrorScopeV1::validity_or_lift
                : ConstructionErrorScopeV1::deployed_surrogate_law},
      structural_manifest_digest,
      digest("c16.registered-pair.core.placeholder")};
  core.core_digest =
      std::move(canonical_plug_descriptor_core_digest_v1(core)).value();
  return core;
}

[[nodiscard]] inline ArtifactObjectReferenceV1 runtime_fixture_object(
    const std::string_view name) {
  return {label(name), digest(name)};
}

[[nodiscard]] inline ArtifactPayloadV1 runtime_fixture_payload(
    const SurrogateBuildRequest& request,
    const SurrogateProviderManifestV1& manifest,
    const ProfileV1& profile) {
  const auto& snapshot = request.accepted_capability_contract();
  const auto& structural = snapshot.structural_metric_support_manifest;
  const auto& clause = structural.clauses().front();
  const auto targets =
      request.framework_problem_view().target_selection().ordered_targets;
  const auto zero = c16_flow_fixture::scalar(0, 1);
  const auto one = c16_flow_fixture::scalar(1, 1);

  if (profile.payload ==
      PayloadClassTagV1::three_bin_scalar_response_v1) {
    auto inputs = c16_flow_fixture::flow_build_inputs(request);
    if (!inputs) throw std::logic_error(inputs.error().code);
    auto response = c16_flow_fixture::response(inputs.value(), manifest);
    if (!response) throw std::logic_error(response.error().code);
    return std::move(response).value();
  }

  if (profile.payload ==
      PayloadClassTagV1::registered_runtime_recipe_v1) {
    return RegisteredRuntimeRecipeV1{
        1U,
        "c16.registered-pair.recipe",
        1U,
        "c16.registered-pair.recipe-parameters",
        1U,
        "c16.registered-pair.recipe-state",
        1U,
        "c16.registered-pair.recipe-mark",
        1U,
        manifest.provider,
        targets,
        {{std::string(kC17TemporalFixtureParameter), one}},
        clause.state_fields,
        clause.marks};
  }

  if (profile.semantic == SemanticTagV1::stationary_marked_edge) {
    auto law = runtime_fixture_object(kC17DirectFactorLaw);
    const auto state_zero = label("c27.runtime.state.0");
    const auto state_one = label("c27.runtime.state.1");
    const auto mark_zero = label("c27.runtime.mark.0");
    const auto mark_one = label("c27.runtime.mark.1");
    return FiniteLawTablesV1{
        1U,
        targets,
        profile.semantic,
        profile.access,
        request.framework_problem_view().fingerprints().compiled_arrival,
        request.framework_problem_view().fingerprints().target_selection,
        {{state_zero, {zero}}, {state_one, {one}}},
        {{mark_zero, {zero, zero}}, {mark_one, {one, zero}}},
        StationaryMarkedEdgeTableV1{
            1U,
            std::move(law),
            FiniteTableStorageV1::dense,
            {{label("c27.runtime.row.0"), state_zero,
              FiniteRowConditioningStageV1::stationary_edge,
              {{state_zero, {mark_zero}, one, std::nullopt}}},
             {label("c27.runtime.row.1"), state_one,
              FiniteRowConditioningStageV1::stationary_edge,
              {{state_zero, {mark_one}, one, std::nullopt}}}},
            {"queue.big_nat", 1U},
            {"arrival.phase", 1U},
            {"service.bit", 1U},
            {"queue.big_nat", 1U},
            request.framework_problem_view().fingerprints().target_selection}};
  }

  if (profile.semantic == SemanticTagV1::direct_metric_decoder) {
    auto value_id = runtime_fixture_object(kC17DirectValue);
    DirectMetricValueV1 value{
        value_id,
        clause.clause_id,
        clause.ordered_targets,
        c16_flow_fixture::scalar(1, 2),
        request.request_digest().value(),
        snapshot.normalized_metric_requirements_digest,
        request.framework_problem_view().fingerprints().target_selection,
        request.framework_problem_view().fingerprints().compiled_arrival,
        snapshot.accepted_contract_digest,
        clause.selection_domain.kinds,
        clause.arrival_assumptions,
        clause.result_scope,
        DirectMetricValidityBasisV1::exact_finite_enumeration,
        {runtime_fixture_object("c27.runtime.direct.validity")}};
    auto sealed = artifact::detail::direct_metric_value_digest_v1(value);
    if (sealed) value.value_id.object_digest = std::move(sealed).value();
    return DirectMetricPayloadV1{1U, {std::move(value)}};
  }

  if (profile.semantic == SemanticTagV1::response_envelope_law) {
    auto inputs = c16_flow_fixture::flow_build_inputs(request);
    if (!inputs) throw std::logic_error(inputs.error().code);
    auto response = c16_flow_fixture::response(inputs.value(), manifest);
    if (!response) throw std::logic_error(response.error().code);
    ThreeBinScalarResponseV1 lower = response.value();
    ThreeBinScalarResponseV1 upper = std::move(response).value();
    const auto selected = lower.deployed_response_product_id;
    return ResponseEnvelopeEvidenceV1{
        1U,
        targets,
        MetricResultScopeV1::response_envelope,
        MetricEvidenceScopeV1::validity_or_lift,
        std::move(lower),
        std::move(upper),
        selected,
        selected,
        runtime_fixture_object("c27.runtime.envelope-domain"),
        {runtime_fixture_object("c27.runtime.envelope-evidence")},
        true,
        selected};
  }

  // The remaining finite-table profiles are construction/transport fixtures.
  // Their executable C27 carriers are supplied by the activation record; the
  // payload still truthfully preserves its advertised semantic and binding.
  FiniteLawTableAlternativeV1 table =
      profile.semantic == SemanticTagV1::staged_opportunity_flux_law
          ? FiniteLawTableAlternativeV1{StagedOpportunityFluxTableV1{
                1U,
                runtime_fixture_object("c27.runtime.staged-law"),
                FiniteTableStorageV1::sparse,
                {},
                {},
                {},
                {},
                request.framework_problem_view().fingerprints()
                    .compiled_arrival,
                {"arrival.innovation", 1U},
                runtime_fixture_object("c27.runtime.update"),
                runtime_fixture_object("c27.runtime.retained"),
                {MetricRevealStageV1::predecision,
                 MetricRevealStageV1::arrival,
                 MetricRevealStageV1::completed_edge}}}
          : FiniteLawTableAlternativeV1{CoupledCommonScheduleTableV1{
                1U,
                runtime_fixture_object("c27.runtime.coupled-law"),
                FiniteTableStorageV1::dense,
                {},
                request.framework_problem_view().fingerprints()
                    .constraint,
                request.framework_problem_view().fingerprints()
                    .tie_and_timing}};
  return FiniteLawTablesV1{
      1U,
      targets,
      profile.semantic,
      profile.access,
      request.framework_problem_view().fingerprints().compiled_arrival,
      request.framework_problem_view().fingerprints().target_selection,
      {},
      {},
      std::move(table)};
}

[[nodiscard]] inline ArtifactObjectReferenceV1 runtime_fixture_primary(
    const ArtifactPayloadV1& payload,
    const ArtifactObjectReferenceV1& payload_identity) {
  if (const auto* tables = std::get_if<FiniteLawTablesV1>(&payload)) {
    return std::visit([](const auto& table) { return table.law_id; },
                      tables->table);
  }
  if (const auto* direct = std::get_if<DirectMetricPayloadV1>(&payload);
      direct != nullptr && !direct->values.empty()) {
    return direct->values.front().value_id;
  }
  return payload_identity;
}

[[nodiscard]] inline ArtifactObjectReferenceV1 runtime_fixture_role_subject(
    const MetricSupportRoleV1 role,
    const ArtifactObjectReferenceV1& payload,
    const ArtifactObjectReferenceV1& primary,
    const ArtifactObjectReferenceV1& stability,
    const ArtifactObjectReferenceV1& validity) {
  if (role == MetricSupportRoleV1::deployed_payload) return payload;
  if (role == MetricSupportRoleV1::stability_certificate) {
    return stability;
  }
  if (role ==
      MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    return validity;
  }
  return primary;
}

[[nodiscard]] inline RealizedReferenceV1 runtime_fixture_reference(
    const MetricSupportRoleV1 role, RealizedReferenceCoreV1 core,
    const ArtifactObjectReferenceV1& payload,
    const ArtifactObjectReferenceV1& primary,
    const ArtifactObjectReferenceV1& stability,
    const ArtifactObjectReferenceV1& validity) {
  switch (role) {
    case MetricSupportRoleV1::deployed_payload:
      return DeployedPayloadReferenceV1{std::move(core),
                                        ArtifactPayloadRef{payload}};
    case MetricSupportRoleV1::stationary_marked_edge_law:
      return StationaryMarkedEdgeLawReferenceV1{
          std::move(core), StationaryMarkedEdgeLawRef{primary}};
    case MetricSupportRoleV1::staged_opportunity_flux_law:
      return StagedOpportunityFluxLawReferenceV1{
          std::move(core), StagedOpportunityFluxLawRef{primary}};
    case MetricSupportRoleV1::temporal_continuation_law:
      return TemporalContinuationLawReferenceV1{
          std::move(core), TemporalContinuationLawRef{primary}};
    case MetricSupportRoleV1::residence_word_law:
      return ResidenceWordLawReferenceV1{std::move(core),
                                         ResidenceWordLawRef{primary}};
    case MetricSupportRoleV1::stopped_path_law:
      return StoppedPathLawReferenceV1{std::move(core),
                                       StoppedPathLawRef{primary}};
    case MetricSupportRoleV1::coupled_schedule_law:
      return CoupledScheduleLawReferenceV1{std::move(core),
                                           CoupledScheduleLawRef{primary}};
    case MetricSupportRoleV1::direct_metric_value:
      return DirectMetricValueReferenceV1{std::move(core),
                                          DirectMetricValueRef{primary}};
    case MetricSupportRoleV1::stability_certificate:
      return StabilityCertificateReferenceV1{
          std::move(core), StabilityCertificateRef{stability}};
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core), ReportedValidityOrLiftEvidenceRef{validity}};
    default:
      return ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core), ReportedValidityOrLiftEvidenceRef{primary}};
  }
}

[[nodiscard]] inline Result<CommonBuildReportV1> runtime_fixture_report(
    const SurrogateBuildRequest& request,
    const SurrogateProviderManifestV1& manifest) {
  const auto targets =
      request.framework_problem_view().target_selection().ordered_targets;
  if (targets.empty()) {
    return Result<CommonBuildReportV1>::failure(reached_materializer());
  }
  c16_flow_fixture::FlowBuildInputsV1 inputs{
      request.request_digest().value(),
      request.provider_binding().provider,
      request.provider_binding().provider_scientific_contract_digest.value(),
      request.classifications().construction_method,
      request.classifications().producer_mode,
      request.classifications().proposed_semantic_tag,
      request.classifications().proposed_access_tag,
      {request.classifications().proposed_payload_tag, 1U},
      targets.front(),
      request.framework_problem_view().fingerprints().compiled_arrival,
      request.accepted_capability_contract()
          .structural_metric_support_manifest,
      request.construction_budget(),
      request.framework_problem_view().fingerprints().target_selection,
      request.framework_problem_view().fingerprints().tie_and_timing};
  return c16_flow_fixture::report(inputs, manifest.required_method_counters);
}

[[nodiscard]] inline Result<SurrogateBuildResult>
runtime_fixture_unavailable_result(
    const SurrogateBuildRequest& request,
    const SurrogateProviderManifestV1& manifest) {
  auto report = runtime_fixture_report(request, manifest);
  if (!report) {
    return Result<SurrogateBuildResult>::failure(report.error());
  }
  return Result<SurrogateBuildResult>::success(
      UnavailableSurrogateResultV1{
          {1U, request.request_digest().value(),
           request.provider_binding().provider, std::move(report).value()},
          {{UnavailableReasonKindV1::construction_domain_unavailable,
            "c16.fixture.registered-pair.catalog-only",
            "the catalog-only registered pair has no executable payload for "
            "this accepted request",
            std::nullopt, std::nullopt}},
          std::nullopt});
}

[[nodiscard]] inline Result<SurrogateBuildResult>
runtime_fixture_built_result(const SurrogateBuildRequest& request,
                             const SurrogateProviderManifestV1& manifest,
                             const ProfileV1& profile) {
  // These five C16 tuples cover registration and transport boundaries.  The
  // staged/coupled rows intentionally carry no finite dictionaries, while
  // the envelope tuple inherits a stationary-throughput request rather than
  // C15's later closed backlog-conditioned envelope route.  The singular
  // ROMR and stopped-path catalog profiles likewise receive the historical
  // analytic throughput request, which neither semantic can truthfully
  // realize.  Publishing any of them as Built would therefore assert
  // mathematics their catalog fixtures do not contain.  They still traverse
  // the provider transaction through the protocol's typed unavailable
  // branch.  Match the two temporal cases by provider id so the executable
  // C20--C23 ROMR profiles remain unaffected.  The C27 conditional staged
  // recipe is also a distinct, executable profile and does not enter here.
  const bool catalog_only_transport =
      (profile.semantic ==
           SemanticTagV1::staged_opportunity_flux_law &&
       profile.payload == PayloadClassTagV1::finite_law_tables_v1) ||
      profile.provider_id == kProfiles[4U].provider_id ||
      profile.provider_id == kProfiles[5U].provider_id ||
      profile.semantic == SemanticTagV1::coupled_target_schedule_law ||
      profile.semantic == SemanticTagV1::response_envelope_law;
  if (catalog_only_transport) {
    return runtime_fixture_unavailable_result(request, manifest);
  }
  const auto& snapshot = request.accepted_capability_contract();
  if (snapshot.structural_metric_support_manifest.clauses().empty()) {
    return Result<SurrogateBuildResult>::failure(reached_materializer());
  }
  ArtifactPayloadV1 payload = runtime_fixture_payload(request, manifest,
                                                       profile);
  if (auto* finite = std::get_if<FiniteLawTablesV1>(&payload);
      finite != nullptr) {
    // A finite table's law identity is content-bound independently of the
    // enclosing payload identity.  Seal that inner identity before hashing
    // the payload; finite_law_table_digest_v1 deliberately projects the
    // late-bound evidence backlinks and the law digest itself.
    auto law_digest =
        artifact::detail::finite_law_table_digest_v1(finite->table);
    if (!law_digest) {
      return Result<SurrogateBuildResult>::failure(law_digest.error());
    }
    std::visit(
        [&law_digest](auto& table) {
          table.law_id.object_digest = law_digest.value();
        },
        finite->table);
  }
  auto payload_digest = canonical_artifact_payload_digest_v1(payload);
  if (!payload_digest) {
    return Result<SurrogateBuildResult>::failure(payload_digest.error());
  }
  const ArtifactObjectReferenceV1 payload_identity{
      label("c27.runtime.payload"), payload_digest.value()};
  ArtifactObjectReferenceV1 primary =
      runtime_fixture_primary(payload, payload_identity);
  const auto& accepted_clauses =
      snapshot.structural_metric_support_manifest.clauses();
  const auto& accepted_clause = accepted_clauses.front();
  const auto stability_requirement = std::ranges::find_if(
      accepted_clause.required_roles, [](const auto& requirement) {
        return requirement.role ==
               MetricSupportRoleV1::stability_certificate;
      });
  const auto validity_requirement = std::ranges::find_if(
      accepted_clause.required_roles, [](const auto& requirement) {
        return requirement.role ==
               MetricSupportRoleV1::reported_validity_or_lift_evidence;
      });
  std::optional<ArtifactObjectReferenceV1> validity_witness;
  const auto internal_references =
      [&](const MetricSupportRoleRequirementV1& requirement) {
        std::vector<RealizedInternalReferenceV1> internal;
        internal.reserve(requirement.internal_relations.size());
        for (const auto& relation : requirement.internal_relations) {
          ArtifactObjectReferenceV1 referenced = runtime_fixture_object(
              "c27.runtime.internal." +
              std::to_string(static_cast<unsigned>(relation.purpose)));
          if (relation.purpose ==
              InternalReferencePurposeV1::artifact_payload) {
            referenced = payload_identity;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::law_or_result) {
            referenced = primary;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::deployed_law) {
            referenced = primary;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::normalized_request) {
            referenced.object_digest =
                snapshot.normalized_metric_requirements_digest;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::selection_binding) {
            referenced.object_digest =
                request.framework_problem_view().fingerprints()
                    .target_selection;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::configured_arrival_binding) {
            referenced.object_digest =
                request.framework_problem_view().fingerprints()
                    .compiled_arrival;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::timing_binding) {
            referenced.object_digest =
                request.framework_problem_view().fingerprints()
                    .tie_and_timing;
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::validity_witness) {
            if (validity_witness.has_value()) {
              referenced = *validity_witness;
            }
          } else if (relation.purpose ==
                     InternalReferencePurposeV1::stage_law) {
            const auto* finite = std::get_if<FiniteLawTablesV1>(&payload);
            const auto* staged =
                finite == nullptr
                    ? nullptr
                    : std::get_if<StagedOpportunityFluxTableV1>(
                          &finite->table);
            if (staged != nullptr) {
              referenced = staged->deterministic_update_descriptor;
            } else if (std::holds_alternative<RegisteredRuntimeRecipeV1>(
                           payload)) {
              // A registered recipe is itself the immutable stage-law body.
              referenced = payload_identity;
            }
          }
          internal.push_back(
              {relation.relation, relation.purpose, std::move(referenced)});
        }
        return internal;
      };
  ArtifactObjectReferenceV1 stability_identity = primary;
  std::optional<RealizedReferenceCoreV1> stability_core;
  ArtifactObjectReferenceV1 validity_identity = primary;
  std::optional<RealizedReferenceCoreV1> validity_core;
  std::vector<FamilyEvidenceEnvelopeV1> family_evidence;
  std::vector<ScopedArtifactEvidenceV1> scoped_evidence;
  if (validity_requirement != accepted_clause.required_roles.end()) {
    if (manifest.allowed_family_evidence_schemas.empty() ||
        manifest.family_evidence_conformance_report_anchors.empty()) {
      return Result<SurrogateBuildResult>::failure(reached_materializer());
    }
    const auto& family_schema =
        manifest.allowed_family_evidence_schemas.front();
    const auto family_anchor = std::ranges::find_if(
        manifest.family_evidence_conformance_report_anchors,
        [&family_schema](const auto& anchor) {
          return anchor.family_evidence_schema_id == family_schema.schema_id &&
                 anchor.family_evidence_schema_version ==
                     family_schema.schema_version;
        });
    if (family_anchor ==
        manifest.family_evidence_conformance_report_anchors.end()) {
      return Result<SurrogateBuildResult>::failure(reached_materializer());
    }

    const std::string_view family_body_text =
        R"json({"claim":"c27-runtime-validity"})json";
    const auto family_body_span =
        std::as_bytes(std::span(family_body_text.data(),
                               family_body_text.size()));
    std::vector<std::byte> family_body(family_body_span.begin(),
                                       family_body_span.end());
    auto family_body_digest =
        artifact::detail::family_evidence_body_digest_v1(family_body);
    if (!family_body_digest) {
      return Result<SurrogateBuildResult>::failure(
          family_body_digest.error());
    }
    std::vector<ArtifactObjectReferenceV1> family_subjects{
        payload_identity, primary};
    std::sort(family_subjects.begin(), family_subjects.end());
    family_subjects.erase(
        std::unique(family_subjects.begin(), family_subjects.end()),
        family_subjects.end());
    const auto scientific_digest = request.provider_binding()
                                       .provider_scientific_contract_digest
                                       .value();
    FamilyEvidenceEnvelopeV1 family{
        1U,
        runtime_fixture_object("c27.runtime.family-validity"),
        family_schema.schema_id,
        family_schema.schema_version,
        {family_anchor->report_schema_version,
         family_anchor->report_id,
         family_anchor->report_digest,
         manifest.provider,
         scientific_digest,
         family_schema.schema_id,
         family_schema.schema_version},
        manifest.provider,
        scientific_digest,
        request.request_digest().value(),
        payload_digest.value(),
        std::move(family_subjects),
        {},
        snapshot.construction_target_scope,
        MetricEvidenceScopeV1::validity_or_lift,
        std::move(family_body),
        std::move(family_body_digest).value()};
    auto family_digest =
        artifact::detail::family_evidence_envelope_digest_v1(family);
    if (!family_digest) {
      return Result<SurrogateBuildResult>::failure(family_digest.error());
    }
    family.evidence_id.object_digest = std::move(family_digest).value();
    validity_witness = family.evidence_id;

    validity_core = RealizedReferenceCoreV1{
        accepted_clause.ordered_targets,
        validity_requirement->target_scope,
        validity_requirement->result_scope,
        validity_requirement->evidence_scope,
        {},
        internal_references(*validity_requirement)};
    std::vector<ArtifactObjectReferenceV1> validity_subjects;
    std::vector<ArtifactObjectReferenceV1> validity_parents;
    for (const auto& relation : validity_core->internal_relations) {
      if (relation.relation == MetricRoleRelationKindV1::subject) {
        validity_subjects.push_back(relation.referenced_object);
      } else if (relation.relation ==
                 MetricRoleRelationKindV1::lineage_parent) {
        validity_parents.push_back(relation.referenced_object);
      }
    }
    std::sort(validity_subjects.begin(), validity_subjects.end());
    validity_subjects.erase(
        std::unique(validity_subjects.begin(), validity_subjects.end()),
        validity_subjects.end());
    std::sort(validity_parents.begin(), validity_parents.end());
    validity_parents.erase(
        std::unique(validity_parents.begin(), validity_parents.end()),
        validity_parents.end());
    ScopedArtifactEvidenceV1 validity{
        runtime_fixture_object("c27.runtime.direct.validity"),
        ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
        validity_core->ordered_targets,
        validity_core->result_scope,
        validity_core->evidence_scope,
        std::move(validity_subjects),
        std::move(validity_parents),
        {family.evidence_id},
        validity_core->internal_relations};
    auto validity_digest =
        artifact::detail::scoped_artifact_evidence_digest_v1(validity);
    if (!validity_digest) {
      return Result<SurrogateBuildResult>::failure(validity_digest.error());
    }
    validity.evidence_id.object_digest = std::move(validity_digest).value();
    validity_identity = validity.evidence_id;
    family_evidence.push_back(std::move(family));
    scoped_evidence.push_back(std::move(validity));
  }

  if (stability_requirement != accepted_clause.required_roles.end()) {
    stability_core = RealizedReferenceCoreV1{
        accepted_clause.ordered_targets,
        stability_requirement->target_scope,
        stability_requirement->result_scope,
        stability_requirement->evidence_scope,
        {},
        internal_references(*stability_requirement)};
    std::vector<ArtifactObjectReferenceV1> stability_subjects;
    std::vector<ArtifactObjectReferenceV1> stability_parents;
    for (const auto& relation : stability_core->internal_relations) {
      if (relation.relation == MetricRoleRelationKindV1::subject) {
        stability_subjects.push_back(relation.referenced_object);
      } else if (relation.relation ==
                 MetricRoleRelationKindV1::lineage_parent) {
        stability_parents.push_back(relation.referenced_object);
      }
    }
    std::sort(stability_subjects.begin(), stability_subjects.end());
    stability_subjects.erase(
        std::unique(stability_subjects.begin(), stability_subjects.end()),
        stability_subjects.end());
    std::sort(stability_parents.begin(), stability_parents.end());
    stability_parents.erase(
        std::unique(stability_parents.begin(), stability_parents.end()),
        stability_parents.end());
    ScopedArtifactEvidenceV1 stability{
        runtime_fixture_object("c27.runtime.stability"),
        ArtifactReferenceKindV1::stability_certificate,
        stability_core->ordered_targets,
        stability_core->result_scope,
        stability_core->evidence_scope,
        std::move(stability_subjects),
        std::move(stability_parents),
        {},
        stability_core->internal_relations};
    auto stability_digest =
        artifact::detail::scoped_artifact_evidence_digest_v1(stability);
    if (!stability_digest) {
      return Result<SurrogateBuildResult>::failure(
          stability_digest.error());
    }
    stability.evidence_id.object_digest =
        std::move(stability_digest).value();
    stability_identity = stability.evidence_id;
    scoped_evidence.push_back(std::move(stability));
  }

  if (auto* direct = std::get_if<DirectMetricPayloadV1>(&payload);
      direct != nullptr) {
    if (direct->values.size() != 1U || !validity_core.has_value()) {
      return Result<SurrogateBuildResult>::failure(reached_materializer());
    }
    direct->values.front().evidence_ids = {validity_identity};
    auto value_digest = artifact::detail::direct_metric_value_digest_v1(
        direct->values.front());
    if (!value_digest) {
      return Result<SurrogateBuildResult>::failure(value_digest.error());
    }
    direct->values.front().value_id.object_digest =
        std::move(value_digest).value();
    auto rebound_payload_digest = canonical_artifact_payload_digest_v1(payload);
    if (!rebound_payload_digest ||
        rebound_payload_digest.value() != payload_digest.value()) {
      return Result<SurrogateBuildResult>::failure(
          rebound_payload_digest
              ? reached_materializer()
              : rebound_payload_digest.error());
    }
    primary = direct->values.front().value_id;
  }

  std::sort(scoped_evidence.begin(), scoped_evidence.end(),
            [](const auto& left, const auto& right) {
              return left.evidence_id < right.evidence_id;
            });

  std::vector<RealizedMetricBindingV1> bindings;
  if (profile.semantic == SemanticTagV1::scalar_backlog_response) {
    // The scalar tuple owns real response products rather than the generic
    // law identity used by the other executable profiles.  Reuse the sealed
    // flow binding constructor so deployed/raw alternatives, coefficient
    // lineage, and product identities all name that exact retained ledger.
    const auto* response = std::get_if<ThreeBinScalarResponseV1>(&payload);
    auto inputs = c16_flow_fixture::flow_build_inputs(request);
    if (response == nullptr || !inputs) {
      return Result<SurrogateBuildResult>::failure(
          inputs ? reached_materializer() : inputs.error());
    }
    auto scalar_bindings = c16_flow_fixture::bindings(
        inputs.value(), *response, payload_identity, payload_digest.value(),
        std::nullopt);
    if (!scalar_bindings) {
      return Result<SurrogateBuildResult>::failure(
          scalar_bindings.error());
    }
    bindings = std::move(scalar_bindings).value().bindings;
  } else {
    for (const auto& clause : accepted_clauses) {
      for (const auto& requirement : clause.required_roles) {
        std::vector<RealizedRoleRelationV1> roles;
        for (const auto& relation : requirement.role_relations) {
          roles.push_back(
              {relation.relation,
               {clause.clause_id, relation.other_role},
               runtime_fixture_role_subject(relation.other_role,
                                            payload_identity, primary,
                                            stability_identity,
                                            validity_identity)});
        }
        std::vector<RealizedInternalReferenceV1> internal =
            requirement.role == MetricSupportRoleV1::stability_certificate
                ? stability_core->internal_relations
            : requirement.role ==
                    MetricSupportRoleV1::reported_validity_or_lift_evidence
                ? validity_core->internal_relations
                : internal_references(requirement);
        RealizedReferenceCoreV1 core{
            clause.ordered_targets,
            requirement.target_scope,
            requirement.result_scope,
            requirement.evidence_scope,
            std::move(roles),
            std::move(internal)};
        bindings.push_back(
            {{clause.clause_id, requirement.role},
             runtime_fixture_reference(requirement.role, std::move(core),
                                       payload_identity, primary,
                                       stability_identity,
                                       validity_identity)});
      }
    }
  }
  auto report = runtime_fixture_report(request, manifest);
  if (!report) return Result<SurrogateBuildResult>::failure(report.error());
  auto echo = c16_flow_fixture::manifest_echo(
      snapshot.structural_metric_support_manifest);
  if (!echo) return Result<SurrogateBuildResult>::failure(echo.error());
  const auto& clause =
      snapshot.structural_metric_support_manifest.clauses().front();
  PlugDescriptorCore core = preview_core(
      manifest,
      request.framework_problem_view().target_selection().ordered_targets,
      clause, snapshot.structural_metric_support_manifest.canonical_digest());
  SurrogateArtifactV1 artifact{
      1U,
      request.request_digest().value(),
      manifest.provider,
      request.provider_binding().provider_scientific_contract_digest.value(),
      request.classifications().construction_method,
      request.classifications().producer_mode,
      profile.semantic,
      profile.access,
      {profile.payload, 1U},
      payload_identity,
      std::move(payload),
      payload_digest.value(),
      std::move(echo).value(),
      {request.request_digest().value(), payload_digest.value(),
       std::move(bindings)},
      std::move(core),
      report.value(),
      std::move(family_evidence),
      std::move(scoped_evidence),
      {},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
       std::nullopt}};
  return Result<SurrogateBuildResult>::success(BuiltSurrogateResultV1{
      {1U, request.request_digest().value(), manifest.provider,
       report.value()},
      std::move(artifact)});
}

#if defined(MWPERF_C27_TEST_SEAMS)
[[nodiscard]] inline ReducedStateV1 runtime_fixture_state(
    const CodecIdentityV1& codec, const std::size_t target_count,
    const std::uint8_t first_backlog, const bool after_phase = false,
    const std::uint8_t boundary = 0U,
    const std::size_t surrogate_field_count = 0U) {
  std::vector<std::byte> bytes(target_count, std::byte{0x00});
  if (!bytes.empty()) bytes.front() = static_cast<std::byte>(first_backlog);
  bytes.push_back(after_phase ? std::byte{0x01} : std::byte{0x00});
  bytes.push_back(static_cast<std::byte>(boundary));
  bytes.insert(bytes.end(), surrogate_field_count, std::byte{0x00});
  return {codec, std::move(bytes)};
}

[[nodiscard]] inline bool runtime_fixture_same_phase(
    const ArrivalPhase& left, const ArrivalPhase& right) {
  return arrival_phase_family(left) == arrival_phase_family(right) &&
         arrival_phase_digest(left) == arrival_phase_digest(right) &&
         std::ranges::equal(arrival_phase_canonical_state(left),
                            arrival_phase_canonical_state(right));
}

struct RuntimeFixturePhasesV1 final {
  ArrivalPhase before;
  ArrivalPhase after;
};

[[nodiscard]] inline Result<RuntimeFixturePhasesV1> runtime_fixture_phases(
    const RuntimeFrameworkActivationContextV1& context) {
  auto before = testing::make_c09_fixture_phase_for_testing(
      context.configured_arrival, 0U, BigNat{0U});
  if (!before) {
    return Result<RuntimeFixturePhasesV1>::failure(before.error());
  }
  auto after = testing::make_c09_fixture_phase_for_testing(
      context.configured_arrival, 1U, BigNat{0U});
  if (!after) {
    return Result<RuntimeFixturePhasesV1>::failure(after.error());
  }
  return Result<RuntimeFixturePhasesV1>::success(
      {std::move(before).value(), std::move(after).value()});
}

[[nodiscard]] inline Result<ExactReducedStateSchemaV1>
runtime_fixture_state_schema(
    const RuntimeFrameworkActivationContextV1& context) {
  const auto targets =
      context.problem_view.target_selection().ordered_targets;
  std::vector<QueueId> target_ids(targets.begin(), targets.end());
  std::vector<BigNat> zeros(target_ids.size(), BigNat{0U});
  auto prototype = TargetBacklogV1::from_values(
      context.resolved_instance, target_ids, std::move(zeros));
  if (!prototype) {
    return Result<ExactReducedStateSchemaV1>::failure(prototype.error());
  }
  auto phases = runtime_fixture_phases(context);
  if (!phases) {
    return Result<ExactReducedStateSchemaV1>::failure(phases.error());
  }
  const CodecIdentityV1 codec{"c17.fixture.exact-reduced-state", 1U};
  const std::size_t cardinality = target_ids.size();
  std::vector<RuntimeStateFieldV1> surrogate_fields;
  for (const RuntimeStateFieldV1& field :
       context.descriptor.state_fields) {
    if (field.c14_field.ownership == FieldOwnershipV1::surrogate_owned) {
      surrogate_fields.push_back(field);
    }
  }
  ExactReducedStateSchemaV1 schema{
      codec,
      digest("c17.fixture.exact-state-schema"),
      digest("c17.fixture.reduced-state-schema"),
      digest("c17.fixture.ownership-schema"),
      digest("c17.fixture.exact-update-schema"),
      [prototype = std::move(prototype).value(), phases = phases.value(),
       codec, cardinality, surrogate_fields](const ReducedStateV1& state)
          -> Result<ExactReducedCoordinatesV1> {
        if (state.codec != codec ||
            state.canonical_value.size() !=
                cardinality + 2U + surrogate_fields.size()) {
          return Result<ExactReducedCoordinatesV1>::failure(
              reached_materializer());
        }
        std::vector<BigNat> backlog;
        backlog.reserve(cardinality);
        for (std::size_t index = 0U; index < cardinality; ++index) {
          backlog.emplace_back(std::to_integer<std::uint8_t>(
              state.canonical_value[index]));
        }
        auto exact = prototype.with_values(std::move(backlog));
        if (!exact) {
          return Result<ExactReducedCoordinatesV1>::failure(exact.error());
        }
        const auto phase_selector = std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality]);
        if (phase_selector > 1U) {
          return Result<ExactReducedCoordinatesV1>::failure(
              reached_materializer());
        }
        const BigNat boundary{std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality + 1U])};
        auto phase = testing::reanchor_c09_fixture_phase_for_testing(
            phase_selector == 0U ? phases.before : phases.after, boundary);
        if (!phase) {
          return Result<ExactReducedCoordinatesV1>::failure(phase.error());
        }
        std::vector<RuntimeFieldPatchV1> unresolved;
        unresolved.reserve(surrogate_fields.size());
        for (std::size_t index = 0U; index < surrogate_fields.size();
             ++index) {
          unresolved.push_back(
              {surrogate_fields[index].id,
               {surrogate_fields[index].c14_field.codec,
                {state.canonical_value[cardinality + 2U + index]}}});
        }
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(exact).value(), std::move(phase).value(), boundary,
             std::nullopt, {}, std::nullopt, std::move(unresolved)});
      },
      [phases = phases.value(), codec,
       cardinality, surrogate_fields](const ExactReducedCoordinatesV1& coordinates,
                    const UnresolvedPatch& unresolved)
          -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != cardinality ||
            coordinates.unresolved_fields.size() !=
                surrogate_fields.size() ||
            coordinates.boundary_index.bit_length() > 8U) {
          return Result<ReducedStateV1>::failure(reached_materializer());
        }
        const bool before =
            runtime_fixture_same_phase(coordinates.arrival_phase,
                                       phases.before);
        const bool after =
            runtime_fixture_same_phase(coordinates.arrival_phase,
                                       phases.after);
        if (!before && !after) {
          return Result<ReducedStateV1>::failure(reached_materializer());
        }
        std::vector<std::byte> bytes;
        bytes.reserve(cardinality + 2U + surrogate_fields.size());
        for (const BigNat& value : coordinates.backlog.values()) {
          if (value.bit_length() > 8U) {
            return Result<ReducedStateV1>::failure(
                reached_materializer());
          }
          bytes.push_back(static_cast<std::byte>(
              value.value().convert_to<std::uint8_t>()));
        }
        bytes.push_back(after ? std::byte{0x01} : std::byte{0x00});
        bytes.push_back(static_cast<std::byte>(
            coordinates.boundary_index.value().convert_to<std::uint8_t>()));
        std::vector<RuntimeFieldPatchV1> local_values =
            coordinates.unresolved_fields;
        for (const RuntimeFieldPatchV1& update : unresolved.fields()) {
          const auto found = std::ranges::find_if(
              local_values, [&](const RuntimeFieldPatchV1& value) {
                return value.field == update.field;
              });
          if (found == local_values.end()) {
            return Result<ReducedStateV1>::failure(
                reached_materializer());
          }
          found->value = update.value;
        }
        for (std::size_t index = 0U; index < surrogate_fields.size();
             ++index) {
          const auto found = std::ranges::find_if(
              local_values, [&](const RuntimeFieldPatchV1& value) {
                return value.field == surrogate_fields[index].id;
              });
          if (found == local_values.end() ||
              found->value.codec != surrogate_fields[index].c14_field.codec ||
              found->value.canonical_value.size() != 1U) {
            return Result<ReducedStateV1>::failure(
                reached_materializer());
          }
          bytes.push_back(found->value.canonical_value.front());
        }
        return Result<ReducedStateV1>::success(
            {codec, std::move(bytes)});
      },
      [codec, cardinality,
       surrogate_field_count = surrogate_fields.size()](
          const ReducedStateV1& state) {
        if (state.codec != codec ||
            state.canonical_value.size() !=
                cardinality + 2U + surrogate_field_count ||
            std::to_integer<std::uint8_t>(
                state.canonical_value[cardinality]) > 1U) {
          return Result<void>::failure(reached_materializer());
        }
        return Result<void>::success();
      },
      {},
      {},
      {}};

  struct PostarrivalBacklogMarkBindingV1 final {
    RuntimeMarkIdV1 mark;
    CodecIdentityV1 codec;
  };
  std::vector<PostarrivalBacklogMarkBindingV1> postarrival_backlog_marks;
  for (const RuntimeMarkDescriptorV1& mark : context.descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::postarrival_state) {
      continue;
    }
    if (mark.c14_mark.kind != MetricMarkKindV1::successor_backlog ||
        !mark.field_dependencies.empty()) {
      return Result<ExactReducedStateSchemaV1>::failure(
          reached_materializer());
    }
    schema.postarrival_mark_decoder.ordered_mark_schemas.push_back(
        {mark.decoder_id, mark.id, mark.decoder_source,
         mark.decoder_input_codec, mark.c14_mark.codec});
    postarrival_backlog_marks.push_back({mark.id, mark.c14_mark.codec});
  }
  if (!postarrival_backlog_marks.empty()) {
    schema.postarrival_mark_decoder.decode =
        [postarrival_backlog_marks](
            const ExactReducedCoordinatesV1&,
            const ExactReducedCoordinatesV1& after,
            const ResolvedAction&, const ArrivalTransition&)
        -> Result<std::vector<RuntimeDecodedMarkV1>> {
      if (after.backlog.values().empty() ||
          after.backlog.values().front().bit_length() > 8U) {
        return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
            reached_materializer());
      }
      const std::byte encoded = static_cast<std::byte>(
          after.backlog.values().front().value().convert_to<std::uint8_t>());
      std::vector<RuntimeDecodedMarkV1> decoded;
      decoded.reserve(postarrival_backlog_marks.size());
      for (const PostarrivalBacklogMarkBindingV1& binding :
           postarrival_backlog_marks) {
        decoded.push_back(
            {binding.mark, {binding.codec, {encoded}}});
      }
      return Result<std::vector<RuntimeDecodedMarkV1>>::success(
          std::move(decoded));
    };
  }

  struct CompletedLocalMarkBindingV1 final {
    RuntimeMarkIdV1 mark;
    RuntimeFieldIdV1 field;
  };
  std::vector<CompletedLocalMarkBindingV1> completed_local_marks;
  for (const RuntimeMarkDescriptorV1& mark : context.descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::completed_edge) continue;
    if (mark.field_dependencies.size() != 1U) {
      return Result<ExactReducedStateSchemaV1>::failure(
          reached_materializer());
    }
    schema.completed_edge_mark_decoder.ordered_mark_schemas.push_back(
        {mark.decoder_id, mark.id, mark.decoder_source,
         mark.decoder_input_codec, mark.c14_mark.codec});
    completed_local_marks.push_back(
        {mark.id, mark.field_dependencies.front()});
  }
  if (!completed_local_marks.empty()) {
    schema.completed_edge_mark_decoder.decode =
        [completed_local_marks](
            const ExactReducedCoordinatesV1&,
            const ExactReducedCoordinatesV1& after,
            const OpportunityMark&, const ResolvedAction&,
            const ArrivalTransition&, const PostClosure&)
        -> Result<std::vector<RuntimeDecodedMarkV1>> {
      std::vector<RuntimeDecodedMarkV1> decoded;
      decoded.reserve(completed_local_marks.size());
      for (const CompletedLocalMarkBindingV1& binding :
           completed_local_marks) {
        const auto field = std::ranges::find_if(
            after.unresolved_fields,
            [&](const RuntimeFieldPatchV1& value) {
              return value.field == binding.field;
            });
        if (field == after.unresolved_fields.end()) {
          return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
              reached_materializer());
        }
        decoded.push_back({binding.mark, field->value});
      }
      return Result<std::vector<RuntimeDecodedMarkV1>>::success(
          std::move(decoded));
    };
  }

  for (const RuntimeMarkDescriptorV1& mark : context.descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::predecision_state &&
        mark.decoder_source != MarkDecoderSourceV1::decision_schedule &&
        mark.decoder_source != MarkDecoderSourceV1::configured_arrival &&
        mark.decoder_source != MarkDecoderSourceV1::entrance_realization) {
      continue;
    }
    schema.framework_mark_decoders.emplace_back(
        DeterministicRuntimeMarkDecoderSchemaV1{
            mark.decoder_id, mark.id, mark.decoder_source,
            mark.decoder_input_codec, mark.c14_mark.codec},
        [codec = mark.c14_mark.codec, kind = mark.c14_mark.kind](
            const CanonicalRuntimeValueV1& input) {
          if (kind == MetricMarkKindV1::target_backlog &&
              !input.canonical_value.empty()) {
            return Result<CanonicalRuntimeValueV1>::success(
                {codec, {input.canonical_value.front()}});
          }
          if (codec.id == "mwperf.c23.typed_label" &&
              codec.version == 1U) {
            const auto encoded = TypedLabel::numeric(BigNat{1U})
                                     .canonical_bytes();
            std::vector<std::byte> bytes;
            bytes.reserve(encoded.size());
            for (const std::uint8_t byte : encoded) {
              bytes.push_back(static_cast<std::byte>(byte));
            }
            return Result<CanonicalRuntimeValueV1>::success(
                {codec, std::move(bytes)});
          }
          return Result<CanonicalRuntimeValueV1>::success(
              {codec, {std::byte{0x01}}});
        });
  }
  return Result<ExactReducedStateSchemaV1>::success(std::move(schema));
}

[[nodiscard]] inline Result<RuntimeFrameworkActivationV1>
runtime_fixture_activation(
    const ProfileV1& profile,
    const RuntimeFrameworkActivationContextV1& context) {
  const bool conditional_only =
      profile.provider_id == kC27ConditionalRewardProfile.provider_id;
  auto schema = runtime_fixture_state_schema(context);
  if (!schema) {
    return Result<RuntimeFrameworkActivationV1>::failure(schema.error());
  }
  const std::size_t target_count =
      context.problem_view.target_selection().ordered_targets.size();
  const std::size_t surrogate_field_count = static_cast<std::size_t>(
      std::ranges::count_if(
          context.descriptor.state_fields,
          [](const RuntimeStateFieldV1& field) {
            return field.c14_field.ownership ==
                   FieldOwnershipV1::surrogate_owned;
          }));
  const bool finite_temporal_profile =
      profile.provider_id == kC20EnumerableRomrProfile.provider_id ||
      profile.provider_id == kC20ResetRomrProfile.provider_id;
  std::vector<ReducedStateV1> domain;
  const auto append_state = [&](const std::uint8_t backlog,
                                const bool after_phase) {
    domain.push_back(runtime_fixture_state(
        schema.value().reduced_state_codec, target_count, backlog,
        after_phase, 0U, surrogate_field_count));
  };
  std::vector<std::uint8_t> domain_phases{0U};
  if (finite_temporal_profile) domain_phases.push_back(1U);
  if (const C17TemporalFixtureOverrideV1* const override =
          c17_temporal_fixture_override_slot();
      finite_temporal_profile && override != nullptr &&
      !override->finite_domain_phase_selectors.empty()) {
    domain_phases = override->finite_domain_phase_selectors;
  }
  std::ranges::sort(domain_phases);
  if (domain_phases.empty() || domain_phases.back() > 1U ||
      std::ranges::adjacent_find(domain_phases) != domain_phases.end()) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        reached_materializer());
  }
  for (const std::uint8_t phase : domain_phases) {
    append_state(0U, phase == 1U);
    append_state(1U, phase == 1U);
  }
  auto mass = ProbabilityMass::exact_rational(ExactRational::one(), true);
  if (!mass) {
    return Result<RuntimeFrameworkActivationV1>::failure(mass.error());
  }
  if (context.descriptor.core.selection.kinds.empty()) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        reached_materializer());
  }
  const auto requirements = context.accepted_contract.requirements().clauses();
  if (requirements.empty()) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        reached_materializer());
  }
  const SelectionKindV1 configured_selection = [&] {
    switch (requirements.front().origin.selection_regime) {
      case MetricSelectionRegimeV1::transient:
        return SelectionKindV1::transient_initial;
      case MetricSelectionRegimeV1::stationary_unique:
        return SelectionKindV1::stationary_unique;
      case MetricSelectionRegimeV1::stationary_class:
        return SelectionKindV1::stationary_class;
      case MetricSelectionRegimeV1::stationary_mixture:
        return SelectionKindV1::stationary_mixture;
      case MetricSelectionRegimeV1::fixed_point_unique:
        return SelectionKindV1::fixed_point_unique;
      case MetricSelectionRegimeV1::fixed_point_id:
        return SelectionKindV1::fixed_point_id;
    }
    return SelectionKindV1::transient_initial;
  }();
  if (std::ranges::find(context.descriptor.core.selection.kinds,
                        configured_selection) ==
      context.descriptor.core.selection.kinds.end()) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        reached_materializer());
  }
  const ReducedStateV1 initial = domain.front();
  const auto bindings =
      context.framework_binding_context.bind_state_schema(schema.value());
  const auto domain_validator = schema.value().validate_domain;
  const QueueId& target =
      context.problem_view.target_selection().ordered_targets.front();
  const auto target_entry = std::ranges::find_if(
      context.resolved_instance.queues().entries(),
      [&](const QueueCatalogEntry& entry) { return entry.id == target; });
  if (target_entry == context.resolved_instance.queues().entries().end()) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        reached_materializer());
  }
  const std::size_t target_physical_ordinal = static_cast<std::size_t>(
      target_entry - context.resolved_instance.queues().entries().begin());
  const auto reduced_from_physical =
      [codec = schema.value().reduced_state_codec, target_count,
       surrogate_field_count,
       target_physical_ordinal](const InitialPhysicalAtom& atom)
      -> Result<ReducedStateV1> {
    const auto* phase = std::get_if<SharedRoundState>(&atom.arrival_state);
    if (phase == nullptr ||
        (phase->state != "h0" && phase->state != "h1") ||
        target_physical_ordinal >= atom.backlog.size() ||
        atom.backlog[target_physical_ordinal].bit_length() > 8U) {
      return Result<ReducedStateV1>::failure(reached_materializer());
    }
    const std::uint8_t backlog =
        atom.backlog[target_physical_ordinal]
            .value().convert_to<std::uint8_t>();
    if (backlog > 1U) {
      return Result<ReducedStateV1>::failure(reached_materializer());
    }
    return Result<ReducedStateV1>::success(runtime_fixture_state(
        codec, target_count, backlog, phase->state == "h1", 0U,
        surrogate_field_count));
  };
  AuditedFrameworkSeedV1 seed{
      bindings,
      context.problem_view.target_selection(),
      schema.value().reduced_state_codec,
      context.descriptor.core.selection,
      {configured_selection,
       configured_selection == SelectionKindV1::stationary_unique ||
               configured_selection == SelectionKindV1::fixed_point_unique
           ? std::optional<Digest256>{
                 digest("c27.runtime.selection-evidence")}
           : std::nullopt},
      [state_codec = schema.value().reduced_state_codec,
       exact_digest = schema.value().exact_state_schema_digest,
       reduced_digest = schema.value().reduced_state_schema_digest,
       selection_digest = bindings.selection_digest,
       selection = context.descriptor.core.selection,
       configured_selection, initial, mass = mass.value(),
       reduced_from_physical](
          const SelectionSpec&,
          const std::optional<InitialPhysicalLaw>& physical) {
        if (configured_selection == SelectionKindV1::transient_initial) {
          if (!physical.has_value() || physical->atoms().empty()) {
            return Result<ReducedInitialLawCandidateV1>::failure(
                reached_materializer());
          }
          std::vector<ReducedInitialCandidateAtomV1> atoms;
          atoms.reserve(physical->atoms().size());
          for (std::size_t index = 0U; index < physical->atoms().size();
               ++index) {
            auto reduced = reduced_from_physical(physical->atoms()[index]);
            auto probability = ProbabilityMass::exact_rational(
                physical->atoms()[index].probability, true);
            if (!reduced) {
              return Result<ReducedInitialLawCandidateV1>::failure(
                  reduced.error());
            }
            if (!probability) {
              return Result<ReducedInitialLawCandidateV1>::failure(
                  probability.error());
            }
            atoms.push_back({std::move(reduced).value(),
                             std::move(probability).value(), index});
          }
          return Result<ReducedInitialLawCandidateV1>::success(
              {state_codec, exact_digest, reduced_digest, selection_digest,
               selection, std::move(atoms)});
        }
        return Result<ReducedInitialLawCandidateV1>::success(
            {state_codec, exact_digest, reduced_digest, selection_digest,
             selection, {{initial, mass, std::nullopt}}});
      },
      [instance = context.resolved_instance.fingerprints().combined,
       exact_digest = schema.value().exact_state_schema_digest](
          const ResolvedInstance& supplied, const Digest256& schema_digest) {
        if (supplied.fingerprints().combined != instance ||
            schema_digest != exact_digest) {
          return Result<void>::failure(reached_materializer());
        }
        return Result<void>::success();
      },
      domain_validator,
      [domain_validator,
       reduced_from_physical](std::size_t, const InitialPhysicalAtom& atom,
                         const ReducedStateV1& reduced) {
        auto valid = domain_validator(reduced);
        if (!valid) return valid;
        auto expected = reduced_from_physical(atom);
        if (!expected || expected.value() != reduced) {
          return Result<void>::failure(reached_materializer());
        }
        return Result<void>::success();
      }};
  const bool direct =
      profile.semantic == SemanticTagV1::direct_metric_decoder;
  const bool temporal_event =
      profile.semantic ==
          SemanticTagV1::temporal_one_slot_continuation ||
      profile.semantic == SemanticTagV1::romr_residence_word_law ||
      profile.semantic == SemanticTagV1::stopped_path_law;
  ExactCausalProgramV1 program{
      direct ? ExactCausalProgramModeV1::bound_direct_decoder
             : ExactCausalProgramModeV1::generic_bound_operations,
      physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(),
      direct ? std::vector<ReducedStateV1>{} : domain};
  if (profile.semantic == SemanticTagV1::stationary_marked_edge) {
    // The C18 backend indexes the exact slot-zero representatives.  C17
    // therefore invokes every provider callback through its audited
    // time-homogeneous clock-erased ABI, while retaining the complete raw
    // one-step edge for C18's mark-preserving endpoint quotient.
    program.event_clock_semantics =
        EventClockSemanticsV1::finite_phase_time_homogeneous_quotient;
  }
  if (temporal_event) {
    program.maximum_residence_slots =
        c17_temporal_fixture_override_slot() == nullptr
            ? 1U
            : c17_temporal_fixture_override_slot()
                  ->maximum_residence_slots;
    if (finite_temporal_profile) {
      // The supplemental C20/C21 carrier explicitly enumerates the complete
      // boundary-zero backlog/phase quotient used by the registered reset
      // recipe.  Surrogate-local residence coordinates are reset at entry;
      // physical clock is retained inside a word and quotiented only at the
      // terminal re-entry boundary.
      program.finite_event_domain_states = domain;
      program.event_entry_domain_is_exact_state_domain = false;
      program.event_clock_semantics =
          EventClockSemanticsV1::finite_phase_time_homogeneous_quotient;
    } else {
      program.event_entry_domain_is_exact_state_domain = true;
      program.event_clock_semantics =
          EventClockSemanticsV1::absolute_physical_slot;
    }
  }

  std::vector<RuntimeFrameworkActivationV1::
                  ConditionalRewardDecoderBindingV1>
      reward_decoders;
  std::optional<RuntimeFrameworkActivationV1::
                    SingleConditioningStateBindingV1>
      conditioning_state;
  if (profile.access ==
      RuntimeAccessTagV1::normalized_conditional_sampler) {
    const auto accepted = std::ranges::find_if(
        context.accepted_contract.metric_contracts(),
        [](const ResolvedMetricContractV1& metric) {
          return metric.solver_regime == SolverRegimeV1::monte_carlo;
        });
    if (accepted != context.accepted_contract.metric_contracts().end()) {
      const ReducedStateV1& bound_conditioning_state =
          conditional_only ? domain.back() : domain.front();
      const auto opportunity_mark = std::ranges::find_if(
          context.descriptor.core.marks,
          [](const MarkDescriptorV1& mark) {
            return mark.kind == MetricMarkKindV1::opportunity;
          });
      const std::size_t reward_mark_index =
          opportunity_mark == context.descriptor.core.marks.end()
              ? 0U
              : static_cast<std::size_t>(
                    opportunity_mark -
                    context.descriptor.core.marks.begin());
      // C27 admits this fixture only for a one-metric conditional-reward
      // plan, so the accepted aggregate digest is exactly the normalized
      // one-metric request digest carried by both typed bindings.
      conditioning_state.emplace(
          RuntimeFrameworkActivationV1::
              SingleConditioningStateBindingV1{
                  accepted->clause_id, accepted->support_clause_digest,
                  context.accepted_contract.requirements_digest(),
                  bound_conditioning_state});
      auto decoder =
          std::make_shared<const ConditionalSamplingRewardV1>(
              ConditionalSamplingRewardV1{
                  "c27.runtime.conditional-reward",
                  digest("c27.runtime.conditional-reward"),
                  accepted->support_clause_digest,
                  digest("c17.fixture.sampler.output-schema"),
                  StationaryRewardIntegrabilityV1::finite_absolute,
                  true,
                  ExactRational::zero(),
                  ExactRational::one(),
                  [reward_mark_index](const ConditioningState&,
                                      const Sample& sample) {
                    if (reward_mark_index >= sample.ordered_marks.size() ||
                        sample.ordered_marks[reward_mark_index]
                            .canonical_value.empty()) {
                      return Result<long double>::failure(
                          reached_materializer());
                    }
                    return Result<long double>::success(
                        static_cast<long double>(
                            std::to_integer<std::uint8_t>(
                                sample.ordered_marks[reward_mark_index]
                                    .canonical_value.front())));
                  },
                  true});
      reward_decoders.push_back(
          {accepted->clause_id, accepted->support_clause_digest,
           context.accepted_contract.requirements_digest(),
           std::move(decoder)});
    }
  }

  std::shared_ptr<RuntimeDirectMetricActivationV1> direct_activation;
  if (direct) {
    auto factor = c17_direct_factor_fixture_candidate(
        context.portable_payload, context.accepted_contract);
    if (!factor) {
      return Result<RuntimeFrameworkActivationV1>::failure(
          factor.error());
    }
    AuditedFrameworkSeedV1 factor_seed = seed;
    // The recipe is auxiliary raw code registration, not another C16
    // artifact.  C17 derives its descriptor/access identities from the
    // consumed raw candidate before validating every retained outer binding.
    factor_seed.bindings.direct_metric_decoder_domain.reset();
    ExactCausalProgramV1 factor_program{
        ExactCausalProgramModeV1::generic_bound_operations,
        physical_pmf_tolerance(), PmfRepresentationBudget::unbounded(),
        domain};
    OptimizerFreeFrameworkCandidateInputsV1 factor_inputs{
        context.build_identity, context.final_request_identity,
        context.resolved_instance, context.configured_arrival,
        context.accepted_contract, context.realized_metric_bindings,
        schema.value(), std::move(factor_program),
        std::move(factor_seed)};

    const auto* raw_direct =
        std::get_if<RawDirectDecoderAccess>(&context.kernel_access);
    if (raw_direct == nullptr || requirements.size() != 1U) {
      return Result<RuntimeFrameworkActivationV1>::failure(
          reached_materializer());
    }
    DirectMetricRequestDomainV1 direct_domain{
        raw_direct->domain().metric_domain,
        context.accepted_contract.requirements_digest(),
        raw_direct->domain().canonical_request_domain_digest,
        requirements.front().origin.ordered_targets,
        raw_direct->domain().ordered_target_digest,
        raw_direct->domain().selection_digest,
        requirements.front().origin.selection_regime,
        raw_direct->domain().result_codec};
    RuntimeDirectFactorRecipeV1 factor_recipe(
        std::move(factor).value(), std::move(factor_inputs));
    direct_activation =
        std::make_shared<RuntimeDirectMetricActivationV1>(
            std::move(direct_domain), std::move(factor_recipe));
  }
  return Result<RuntimeFrameworkActivationV1>::success(
      {std::move(schema).value(),
       std::make_shared<const ExactCausalProgramV1>(std::move(program)),
       std::make_shared<const AuditedFrameworkSeedV1>(std::move(seed)),
       std::move(direct_activation),
       (conditional_only || direct) ? std::vector<ReducedStateV1>{}
                                    : domain,
       !conditional_only && !direct,
       std::move(conditioning_state),
       std::move(reward_decoders)});
}

[[nodiscard]] inline std::optional<FrameworkActivationRegistrationV1>
runtime_fixture_activation_registration(const ProfileV1& profile) {
  if (profile.semantic == SemanticTagV1::direct_metric_decoder) {
    // The cold activation constructs a fresh, private raw causal-factor
    // recipe from this same validated direct request.  It is not a second
    // provider result and cannot execute until the composite C17 audit.
    return FrameworkActivationRegistrationV1{
        {false, false, false, true, false, std::nullopt, false,
         std::nullopt, std::nullopt, std::nullopt, std::nullopt,
         std::optional<BigNat>{BigNat{0U}}},
        [profile](const RuntimeFrameworkActivationContextV1& context) {
          return runtime_fixture_activation(profile, context);
        }};
  }
  const bool sampler = profile.access ==
                       RuntimeAccessTagV1::normalized_conditional_sampler;
  const bool supported =
      profile.semantic == SemanticTagV1::stationary_marked_edge ||
      profile.semantic == SemanticTagV1::staged_opportunity_flux_law ||
      profile.semantic == SemanticTagV1::temporal_one_slot_continuation ||
      profile.semantic == SemanticTagV1::romr_residence_word_law ||
      profile.semantic == SemanticTagV1::stopped_path_law;
  if (!supported) return std::nullopt;
  const bool residence =
      profile.semantic == SemanticTagV1::temporal_one_slot_continuation ||
      profile.semantic == SemanticTagV1::romr_residence_word_law ||
      profile.semantic == SemanticTagV1::stopped_path_law;
  const bool conditional_only =
      profile.provider_id == kC27ConditionalRewardProfile.provider_id;
  const bool finite_temporal_profile =
      profile.provider_id == kC20EnumerableRomrProfile.provider_id ||
      profile.provider_id == kC20ResetRomrProfile.provider_id;
  const std::optional<BigNat> row_atom_bound =
      sampler ? std::optional<BigNat>{BigNat{1U}}
      : (profile.access == RuntimeAccessTagV1::finite_enumerated_row ||
         profile.access == RuntimeAccessTagV1::sparse_row || residence)
          ? std::optional<BigNat>{BigNat{4U}}
          : std::nullopt;
  return FrameworkActivationRegistrationV1{
      {!conditional_only, !conditional_only, sampler, false, sampler,
       sampler ? std::optional<StageTag>{StageTag::generic_sampling}
               : std::nullopt,
       finite_temporal_profile,
       conditional_only
           ? std::nullopt
           : std::optional<BigNat>{
                 finite_temporal_profile ? BigNat{4U} : BigNat{2U}},
       finite_temporal_profile
           ? std::optional<BigNat>{BigNat{4U}}
           : std::nullopt,
       row_atom_bound,
       residence ? std::optional<BigNat>{BigNat{3U}} : std::nullopt,
       std::nullopt,
       sampler ? std::optional<ConditionalSampleDependenceV1>{
                     ConditionalSampleDependenceV1::iid_cold_replications}
               : std::nullopt,
       sampler ? std::optional<ConditionalEstimatorProcedureV1>{
                     ConditionalEstimatorProcedureV1::conditional_reward_mean}
               : std::nullopt,
       sampler ? std::optional<ConditionalRewardPremisesV1>{
                     ConditionalRewardPremisesV1{
                         true, ExactRational::zero(), ExactRational::one()}}
               : std::nullopt},
      [profile](const RuntimeFrameworkActivationContextV1& context) {
        return runtime_fixture_activation(profile, context);
      }};
}
#endif

[[nodiscard]] inline SurrogateProviderRegistrationV1 instrument_profile(
    SurrogateProviderRegistrationV1 registration, const std::size_t index,
    const ProfileV1 profile) {
  const auto manifest = registration.manifest;
  auto parameter = std::move(registration.parameter_validator);
  registration.parameter_validator =
      [index, parameter = std::move(parameter)](const SourceNode& source)
          mutable {
            counters()[index].parameter.fetch_add(1U,
                                                   std::memory_order_relaxed);
            return parameter(source);
          };
  registration.previewer =
      [index, manifest](
          const FrameworkProblemView& problem,
          const MetricRequirements& requirements,
          const ConstructionBudget& budget,
          const ValidatedSurrogateParameters& parameters) {
        counters()[index].preview.fetch_add(1U, std::memory_order_relaxed);
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        MetricSupportManifest structural_manifest =
            manifest.metric_clause_upper_envelope;
        if (manifest.runtime_access_tag ==
            RuntimeAccessTagV1::normalized_conditional_sampler) {
          std::vector<MetricSupportClauseV1> selected;
          selected.reserve(requirements.clauses().size());
          for (const MetricRequirementClause& requirement :
               requirements.clauses()) {
            const auto found = std::ranges::find_if(
                manifest.metric_clause_upper_envelope.clauses(),
                [&](const MetricSupportClauseV1& candidate) {
                  return candidate.clause_id ==
                             requirement.origin.clause_id &&
                         candidate.metric_kind == requirement.origin.kind;
                });
            if (found ==
                manifest.metric_clause_upper_envelope.clauses().end()) {
              return Result<PlugDescriptorPreview>::failure(
                  reached_materializer());
            }
            selected.push_back(*found);
          }
          auto narrowed =
              MetricSupportManifest::from_clauses(std::move(selected));
          if (!narrowed) {
            return Result<PlugDescriptorPreview>::failure(
                narrowed.error());
          }
          structural_manifest = std::move(narrowed).value();
        }
        auto structural = std::make_shared<const MetricSupportManifest>(
            std::move(structural_manifest));
        PlugDescriptorCore core =
            manifest.runtime_access_tag ==
                    RuntimeAccessTagV1::normalized_conditional_sampler
                ? preview_core(
                      manifest,
                      problem.target_selection().ordered_targets,
                      structural->clauses().front(),
                      structural->canonical_digest())
                : preview_core(
                      manifest,
                      problem.target_selection().ordered_targets);
        PlugDescriptorPreview value{
            1U,
            std::move(core),
            manifest.construction_method,
            manifest.producer_mode,
            problem.target_selection().ordered_targets,
            {manifest.scientific_construction_policy_schema
                 .point_deployment.front(),
             manifest.scientific_construction_policy_schema
                 .coefficient_completion.front(),
             manifest.scientific_construction_policy_schema
                 .projection.front(),
             manifest.scientific_construction_policy_schema
                 .recoding.front(),
             manifest.scientific_construction_policy_schema
                 .evidence_roles.front()},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(structural),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.registered-pair.preview.placeholder")};
        value.preview_digest =
            std::move(canonical_plug_descriptor_preview_digest_v1(value))
                .value();
        return Result<PlugDescriptorPreview>::success(std::move(value));
      };
  (void)std::get<InlineImmediateProducerV1>(std::move(registration.producer));
  registration.producer = InlineImmediateProducerV1{
      [index, manifest, profile](
          const SurrogateBuildRequest& request) mutable {
        counters()[index].execute.fetch_add(1U, std::memory_order_relaxed);
        return c16_flow_fixture::serialized(runtime_fixture_built_result(
            request, manifest, profile));
      }};
  registration.materializer =
      [index, profile](const PortablePlugPayload& payload,
                       const ValidatedSurrogateArtifact& artifact,
                       const AcceptedCapabilityContract& contract) {
        counters()[index].materialize.fetch_add(1U,
                                                std::memory_order_relaxed);
        if ((profile.semantic ==
                 SemanticTagV1::temporal_one_slot_continuation ||
             profile.semantic ==
                 SemanticTagV1::romr_residence_word_law ||
             profile.semantic == SemanticTagV1::stopped_path_law) &&
            is_c17_temporal_fixture(payload)) {
          return c17_temporal_fixture_candidate(payload, contract);
        }
        if (profile.semantic ==
                SemanticTagV1::stationary_marked_edge &&
            is_c17_direct_factor_fixture(payload)) {
          return c17_direct_factor_fixture_candidate(payload, contract);
        }
        if (profile.semantic ==
                SemanticTagV1::direct_metric_decoder &&
            is_c17_direct_decoder_fixture(payload)) {
          return c17_direct_decoder_fixture_candidate(
              payload, artifact, contract);
        }
        return Result<RuntimePlugCandidateV1>::failure(
            reached_materializer());
      };
#if defined(MWPERF_C27_TEST_SEAMS)
  registration.framework_activation =
      runtime_fixture_activation_registration(profile);
#endif
  return registration;
}

[[nodiscard]] inline SurrogateProviderRegistrationV1 instrument(
    SurrogateProviderRegistrationV1 registration, const std::size_t index) {
  return instrument_profile(
      std::move(registration), index, kProfiles[index]);
}

// A small non-catalog registration adapter for the supplemental C20 profile.
// It uses the same real parameter/preview/artifact boundaries as the C16
// matrix while avoiding changes to the nine-profile C16 coverage counters.
[[nodiscard]] inline SurrogateProviderRegistrationV1
instrument_c20_enumerable_romr(
    SurrogateProviderRegistrationV1 registration) {
  const auto manifest = registration.manifest;
  registration.previewer =
      [manifest](const FrameworkProblemView& problem,
                 const MetricRequirements& requirements,
                 const ConstructionBudget& budget,
                 const ValidatedSurrogateParameters& parameters) {
        std::vector<MetricSupportClauseV1> selected;
        selected.reserve(requirements.clauses().size());
        for (const MetricRequirementClause& requirement :
             requirements.clauses()) {
          const auto found = std::ranges::find_if(
              manifest.metric_clause_upper_envelope.clauses(),
              [&](const MetricSupportClauseV1& candidate) {
                if (candidate.clause_id != requirement.origin.clause_id ||
                    candidate.metric_kind != requirement.origin.kind) {
                  return false;
                }
                const auto* parameter_set =
                    std::get_if<ExactMetricParameterSetV1>(
                        &candidate.parameter_domain);
                return parameter_set != nullptr &&
                       std::ranges::find(parameter_set->values,
                                         requirement.origin.parameters) !=
                           parameter_set->values.end();
              });
          if (found ==
              manifest.metric_clause_upper_envelope.clauses().end()) {
            return Result<PlugDescriptorPreview>::failure(
                reached_materializer());
          }
          selected.push_back(*found);
        }
        auto narrowed =
            MetricSupportManifest::from_clauses(std::move(selected));
        if (!narrowed) {
          return Result<PlugDescriptorPreview>::failure(narrowed.error());
        }
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        auto structural = std::make_shared<const MetricSupportManifest>(
            std::move(narrowed).value());
        PlugDescriptorPreview value{
            1U,
            preview_core(manifest,
                         problem.target_selection().ordered_targets,
                         structural->clauses().front(),
                         structural->canonical_digest()),
            manifest.construction_method,
            manifest.producer_mode,
            problem.target_selection().ordered_targets,
            {manifest.scientific_construction_policy_schema
                 .point_deployment.front(),
             manifest.scientific_construction_policy_schema
                 .coefficient_completion.front(),
             manifest.scientific_construction_policy_schema
                 .projection.front(),
             manifest.scientific_construction_policy_schema
                 .recoding.front(),
             manifest.scientific_construction_policy_schema
                 .evidence_roles.front()},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(structural),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c20.fixture.enumerable-romr.preview.placeholder")};
        value.preview_digest =
            std::move(canonical_plug_descriptor_preview_digest_v1(value))
                .value();
        return Result<PlugDescriptorPreview>::success(std::move(value));
      };
  registration.materializer =
      [](const PortablePlugPayload& payload,
         const ValidatedSurrogateArtifact&,
         const AcceptedCapabilityContract& contract) {
        if (is_c17_temporal_fixture(payload)) {
          return c17_temporal_fixture_candidate(payload, contract);
        }
        return Result<RuntimePlugCandidateV1>::failure(
            reached_materializer());
      };
  return registration;
}

// The C27 positive sampler uses the same exact request-narrowing preview as
// the supplemental C20 adapters, then supplies its own recipe artifact,
// non-temporal staged materializer, and request-bound activation.
[[nodiscard]] inline SurrogateProviderRegistrationV1
instrument_c27_conditional_reward(
    SurrogateProviderRegistrationV1 registration) {
  registration = instrument_c20_enumerable_romr(std::move(registration));
  const auto manifest = registration.manifest;
  (void)std::get<InlineImmediateProducerV1>(
      std::move(registration.producer));
  registration.producer = InlineImmediateProducerV1{
      [manifest](const SurrogateBuildRequest& request) {
        return c16_flow_fixture::serialized(runtime_fixture_built_result(
            request, manifest, kC27ConditionalRewardProfile));
      }};
  registration.materializer =
      [](const PortablePlugPayload& payload,
          const ValidatedSurrogateArtifact& artifact,
          const AcceptedCapabilityContract& contract) {
        std::optional<Digest256> configured_arrival_binding;
        for (const RealizedMetricBindingV1& binding :
             artifact.value().realized_metric_bindings.bindings) {
          const auto& core =
              realized_reference_core_v1(binding.reference);
          for (const RealizedInternalReferenceV1& relation :
               core.internal_relations) {
            if (relation.purpose !=
                InternalReferencePurposeV1::configured_arrival_binding) {
              continue;
            }
            if (configured_arrival_binding.has_value()) {
              return Result<RuntimePlugCandidateV1>::failure(
                  reached_materializer());
            }
            configured_arrival_binding =
                relation.referenced_object.object_digest;
          }
        }
        if (is_c17_temporal_fixture(payload) &&
            configured_arrival_binding.has_value()) {
          return c17_temporal_fixture_candidate(
              payload, contract, configured_arrival_binding);
        }
        return Result<RuntimePlugCandidateV1>::failure(
            reached_materializer());
      };
#if defined(MWPERF_C27_TEST_SEAMS)
  registration.framework_activation =
      runtime_fixture_activation_registration(
          kC27ConditionalRewardProfile);
#endif
  return registration;
}

// The reset provider is reused by C21 for several distinct stationary plans.
// Its registered manifest is an upper envelope, while each preview must bind
// exactly the authored clause rather than returning the historical
// throughput clause under a different request identity.
[[nodiscard]] inline SurrogateProviderRegistrationV1
instrument_c20_reset_romr(
    SurrogateProviderRegistrationV1 registration) {
  const auto manifest = registration.manifest;
  registration.previewer =
      [manifest](const FrameworkProblemView& problem,
                 const MetricRequirements& requirements,
                 const ConstructionBudget& budget,
                 const ValidatedSurrogateParameters& parameters) {
        std::vector<MetricSupportClauseV1> selected;
        selected.reserve(requirements.clauses().size());
        for (const MetricRequirementClause& requirement :
             requirements.clauses()) {
          const auto found = std::ranges::find_if(
              manifest.metric_clause_upper_envelope.clauses(),
              [&](const MetricSupportClauseV1& candidate) {
                if (candidate.clause_id != requirement.origin.clause_id ||
                    candidate.metric_kind != requirement.origin.kind) {
                  return false;
                }
                const auto* parameters =
                    std::get_if<ExactMetricParameterSetV1>(
                        &candidate.parameter_domain);
                return parameters != nullptr &&
                       std::ranges::find(parameters->values,
                                         requirement.origin.parameters) !=
                           parameters->values.end();
              });
          if (found ==
              manifest.metric_clause_upper_envelope.clauses().end()) {
            return Result<PlugDescriptorPreview>::failure(
                reached_materializer());
          }
          selected.push_back(*found);
        }
        auto narrowed = MetricSupportManifest::from_clauses(
            std::move(selected));
        if (!narrowed) {
          return Result<PlugDescriptorPreview>::failure(narrowed.error());
        }
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        auto structural = std::make_shared<const MetricSupportManifest>(
            std::move(narrowed).value());
        PlugDescriptorCore core = preview_core(
            manifest, problem.target_selection().ordered_targets,
            structural->clauses().front(),
            structural->canonical_digest());
        PlugDescriptorPreview value{
            1U,
            std::move(core),
            manifest.construction_method,
            manifest.producer_mode,
            problem.target_selection().ordered_targets,
            {manifest.scientific_construction_policy_schema
                 .point_deployment.front(),
             manifest.scientific_construction_policy_schema
                 .coefficient_completion.front(),
             manifest.scientific_construction_policy_schema
                 .projection.front(),
             manifest.scientific_construction_policy_schema
                 .recoding.front(),
             manifest.scientific_construction_policy_schema
                 .evidence_roles.front()},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(structural),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c20.fixture.reset-romr.preview.placeholder")};
        value.preview_digest =
            std::move(canonical_plug_descriptor_preview_digest_v1(value))
                .value();
        return Result<PlugDescriptorPreview>::success(std::move(value));
      };
  (void)std::get<InlineImmediateProducerV1>(
      std::move(registration.producer));
  registration.producer = InlineImmediateProducerV1{
      [manifest](const SurrogateBuildRequest& request) {
        return c16_flow_fixture::serialized(runtime_fixture_built_result(
            request, manifest, kC20ResetRomrProfile));
      }};
  registration.materializer =
      [](const PortablePlugPayload& payload,
         const ValidatedSurrogateArtifact&,
         const AcceptedCapabilityContract& contract) {
        if (is_c17_temporal_fixture(payload)) {
          return c17_temporal_fixture_candidate(
              payload, contract, std::nullopt, true);
        }
        return Result<RuntimePlugCandidateV1>::failure(
            reached_materializer());
      };
#if defined(MWPERF_C27_TEST_SEAMS)
  registration.framework_activation =
      runtime_fixture_activation_registration(kC20ResetRomrProfile);
#endif
  return registration;
}

}  // namespace mwperf::testing::c16_registered_pair_matrix
