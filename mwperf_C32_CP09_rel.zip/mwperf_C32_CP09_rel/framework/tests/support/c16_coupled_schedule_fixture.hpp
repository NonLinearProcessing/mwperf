#pragma once

#if !defined(MWPERF_C16_TEST_SEAMS)
#error "c16_coupled_schedule_fixture.hpp is test-only"
#endif

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "../fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"

namespace mwperf::testing::c16_coupled_fixture {

using Factory = C15ProtocolFixtureFactory;

inline constexpr std::string_view kProviderId =
    "c16.fixture.coupled-common-schedule";

[[nodiscard]] inline std::atomic<unsigned>& materializer_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

[[nodiscard]] inline std::atomic<unsigned>& row_calls() {
  static std::atomic<unsigned> value{0U};
  return value;
}

inline void reset_counters() noexcept {
  materializer_calls().store(0U, std::memory_order_relaxed);
  row_calls().store(0U, std::memory_order_relaxed);
}

[[nodiscard]] inline TypedLabel label(const std::string_view text) {
  return std::move(TypedLabel::text(std::string(text))).value();
}

[[nodiscard]] inline QueueId queue(const std::string_view text) {
  return QueueId(label(text));
}

[[nodiscard]] inline Digest256 digest(const std::string_view text) {
  return std::move(
             sha256(std::as_bytes(
                 std::span<const char>(text.data(), text.size()))))
      .value();
}

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  return std::move(
             ExactRational::make(BigInt(numerator), BigInt(denominator)))
      .value();
}

[[nodiscard]] inline PortableScientificScalar scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return PortableScientificScalar::rational(
      rational(numerator, denominator));
}

[[nodiscard]] inline ArtifactObjectReferenceV1 object(
    const std::string_view name) {
  return {label(name), digest(name)};
}

[[nodiscard]] inline std::vector<std::byte> bytes(
    const std::string_view text) {
  const auto source = std::as_bytes(
      std::span<const char>(text.data(), text.size()));
  return {source.begin(), source.end()};
}

[[nodiscard]] inline Diagnostic fixture_error(std::string code,
                                              std::string message) {
  return {DiagnosticCategory::input_validation, std::move(code),
          std::move(message), std::nullopt, std::nullopt, {}};
}

[[nodiscard]] inline MetricSupportRoleRequirementV1 role(
    const MetricSupportRoleV1 selected,
    const MetricTargetScopeV1 target_scope,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope) {
  const auto* schema = metric_support_role_schema_v1(selected);
  REQUIRE(schema != nullptr);

  std::vector<MetricRoleRelationRequirementV1> role_relations;
  const auto append_roles =
      [&role_relations](const std::uint32_t mask,
                        const MetricRoleRelationKindV1 relation) {
        for (const auto candidate : all_metric_support_roles_v1()) {
          if ((mask & metric_support_role_bit_v1(candidate)) != 0U) {
            role_relations.push_back({relation, candidate});
          }
        }
      };
  append_roles(schema->required_lineage_parent_roles,
               MetricRoleRelationKindV1::lineage_parent);
  append_roles(schema->required_binding_roles,
               MetricRoleRelationKindV1::binding);
  append_roles(schema->required_evidence_roles,
               MetricRoleRelationKindV1::evidence);
  append_roles(schema->required_subject_roles,
               MetricRoleRelationKindV1::subject);

  std::vector<InternalRelationRequirementV1> internal_relations;
  const auto append_internal =
      [&internal_relations](const std::uint64_t mask,
                            const MetricRoleRelationKindV1 relation) {
        const auto last = static_cast<std::uint8_t>(
            InternalReferencePurposeV1::error_object);
        for (std::uint8_t index = 0U; index <= last; ++index) {
          const auto purpose =
              static_cast<InternalReferencePurposeV1>(index);
          if ((mask & internal_reference_purpose_bit_v1(purpose)) != 0U) {
            internal_relations.push_back({relation, purpose});
          }
        }
      };
  append_internal(schema->required_internal_lineage_parents,
                  MetricRoleRelationKindV1::lineage_parent);
  append_internal(schema->required_internal_bindings,
                  MetricRoleRelationKindV1::binding);
  append_internal(schema->required_internal_evidence,
                  MetricRoleRelationKindV1::evidence);
  append_internal(schema->required_internal_subjects,
                  MetricRoleRelationKindV1::subject);
  return {selected, target_scope, result_scope, evidence_scope,
          std::move(role_relations), std::move(internal_relations)};
}

[[nodiscard]] inline MetricSupportManifest structural_manifest() {
  const std::vector<QueueId> targets{queue("q0"), queue("q1")};
  auto result = MetricSupportManifest::from_clauses({{
      {"joint", 0U},
      MetricKindV1::joint_backlog_event,
      ExactMetricParameterSetV1{{JointBacklogEventParametersV1{
          JointBacklogRelation::any_at_or_above,
          {BigNat{1U}, BigNat{1U}}}}},
      targets,
      TargetCouplingV1::common_schedule_projection,
      {{StateFieldKindV1::target_backlog,
        FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {{MetricMarkKindV1::actual_departure,
        MetricRevealStageV1::decision,
        {"service.vector-bit", 1U},
        "c16.coupled.common-schedule"},
       {MetricMarkKindV1::schedule_projection,
        MetricRevealStageV1::decision,
        {"schedule.projection", 1U},
        "c16.coupled.common-schedule"}},
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::iid_late_arrival,
       false,
       std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon,
       std::nullopt},
      {PayloadClassTagV1::finite_law_tables_v1, 1U},
      SemanticTagV1::coupled_target_schedule_law,
      RuntimeAccessTagV1::finite_enumerated_row,
      {},
      {{HypothesisKindV1::common_schedule, std::nullopt, std::nullopt,
        std::nullopt}},
      SolverRegimeV1::enumerated,
      EnumeratedAccuracyV1{{}},
      {StructuralErrorFormV1::exact, MetricEvidenceScopeV1::none,
       ExactRational::zero()},
      MetricResultScopeV1::surrogate_law,
      {V0DeclarationKindV1::structural_witness_required,
       "c16.coupled.v0", 1U},
      {role(MetricSupportRoleV1::deployed_payload,
            MetricTargetScopeV1::payload_targets,
            MetricResultScopeV1::surrogate_law,
            MetricEvidenceScopeV1::none),
       role(MetricSupportRoleV1::coupled_schedule_law,
            MetricTargetScopeV1::ordered_metric_targets,
            MetricResultScopeV1::surrogate_law,
            MetricEvidenceScopeV1::deployed_surrogate_law),
       role(MetricSupportRoleV1::reported_validity_or_lift_evidence,
            MetricTargetScopeV1::ordered_metric_targets,
            MetricResultScopeV1::not_a_metric_result,
            MetricEvidenceScopeV1::validity_or_lift)}}});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline PlugDescriptorCore descriptor_core(
    const SurrogateProviderManifestV1& provider,
    const MetricSupportManifest& manifest) {
  const auto& clause = manifest.clauses().front();
  PlugDescriptorCore core{
      1U,
      provider.provider,
      provider.optimizer_constraint_applicability,
      provider.payload_class,
      provider.deployed_semantic_tag,
      provider.runtime_access_tag,
      clause.ordered_targets,
      clause.target_coupling,
      clause.state_fields,
      clause.marks,
      clause.selection_domain,
      clause.phase_domain,
      {TailRepresentationKindV1::exact_unbounded, std::nullopt,
       std::nullopt},
      clause.arrival_assumptions,
      clause.hypotheses,
      clause.mandatory_v0,
      {},
      {clause.requested_accuracy},
      {ConstructionResultScopeV1::surrogate_law,
       ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest.canonical_digest(),
      digest("c16.coupled.core.placeholder")};
  core.core_digest =
      std::move(canonical_plug_descriptor_core_digest_v1(core)).value();
  return core;
}

[[nodiscard]] inline SurrogateProviderManifestV1 provider_manifest() {
  auto manifest = structural_manifest();
  SurrogateProviderManifestV1 value{
      1U,
      {std::string(kProviderId), "1.0.0"},
      true,
      digest("c16.coupled.source-build"),
      ConstructionMethodV1::engineered_deterministic,
      ProducerModeV1::in_process_builder,
      SemanticTagV1::coupled_target_schedule_law,
      RuntimeAccessTagV1::finite_enumerated_row,
      {PayloadClassTagV1::finite_law_tables_v1, 1U},
      1U,
      digest("c16.coupled.parameter-schema"),
      {1U},
      {1U},
      {1U},
      {},
      {{{ServiceFamily::pairwise_conflicts,
         OptimizerId::mwis_branch_memo_exact}},
       {TimingConvention::early_service_late_admission}},
      {2U, 2U, {TargetCouplingV1::common_schedule_projection}, {}},
      std::move(manifest),
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::coupled_schedule_law,
       MetricSupportRoleV1::reported_validity_or_lift_evidence},
      {{"c16.coupled.evidence", 1U, 4096U}},
      {{"c16.coupled.evidence", 1U, 1U,
        label("c16.coupled.conformance"),
        digest("c16.coupled.conformance")}},
      {1U,
       {PointDeploymentPolicyV1::not_applicable},
       {CoefficientCompletionPolicyV1::not_applicable},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      std::nullopt,
      {1U << 20U, 1U << 20U},
      digest("c16.coupled.manifest.placeholder")};
  value.manifest_digest =
      std::move(digest_provider_manifest_v1(value)).value();
  return value;
}

[[nodiscard]] inline PlugDescriptor runtime_descriptor(
    const PlugDescriptorCore& core) {
  std::vector<RuntimeStateFieldV1> fields;
  fields.reserve(core.state_fields.size());
  for (std::size_t index = 0U; index < core.state_fields.size(); ++index) {
    fields.push_back(
        {RuntimeFieldIdV1(label("c16.coupled.field." +
                                std::to_string(index))),
         core.state_fields[index], RuntimeDomainKindV1::countable});
  }

  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    marks.push_back(
        {RuntimeMarkIdV1(label("c16.coupled.mark." +
                               std::to_string(index))),
         core.marks[index],
         RuntimeDecoderIdV1(label("c16.coupled.decoder." +
                                  std::to_string(index))),
         MarkDecoderSourceV1::decision_schedule,
         RuntimeDomainKindV1::finite,
         {"c16.coupled.schedule-realization", 1U},
         {},
         {}});
  }
  std::vector<RuntimeFieldIdV1> ordered_fields;
  ordered_fields.reserve(fields.size());
  for (const auto& field : fields) ordered_fields.push_back(field.id);

  PlugDescriptor descriptor{
      1U,
      core,
      std::move(fields),
      std::nullopt,
      std::nullopt,
      std::move(marks),
      std::nullopt,
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity, CertificateLevelV1::v0_shape,
        CodecIdentityV1{core.mandatory_v0.factor_schema_id,
                        core.mandatory_v0.factor_schema_version}}},
      TransitionStateSchemaV1{{"c16.coupled.state", 1U},
                              {"c16.coupled.state", 1U},
                              std::move(ordered_fields)},
      digest("c16.coupled.runtime-descriptor.placeholder")};
  descriptor.descriptor_digest =
      std::move(canonical_plug_descriptor_digest_v1(descriptor)).value();
  return descriptor;
}

[[nodiscard]] inline KernelAccess finite_access(
    const PlugDescriptor& descriptor) {
  std::vector<CodecIdentityV1> mark_codecs;
  mark_codecs.reserve(descriptor.marks.size());
  for (const auto& mark : descriptor.marks) {
    mark_codecs.push_back(mark.c14_mark.codec);
  }
  const auto& transition = *descriptor.transition_state_schema;
  return FiniteEnumeratedRowAccess(
      {transition.conditioning_state_codec,
       transition.successor_state_codec,
       std::move(mark_codecs),
       2U,
       std::nullopt},
      [](const CanonicalRuntimeValueV1&) {
        row_calls().fetch_add(1U, std::memory_order_relaxed);
        return Result<std::vector<KernelRowAtomV1>>::success({});
      });
}

[[nodiscard]] inline SurrogateProviderRegistrationV1 registration() {
  auto manifest = provider_manifest();
  const auto manifest_for_preview = manifest;
  ParameterValidatorV1 parameters = [](const SourceNode& source) {
    const SourceNode* level = source.find("resolution_level");
    if (source.kind() != SourceNodeKind::object || level == nullptr ||
        source.object_members().size() != 1U ||
        level->kind() != SourceNodeKind::number ||
        *level->number_lexeme() != "1") {
      return Result<ValidatedParameterPayloadV1>::failure(fixture_error(
          "c16.fixture.coupled_parameters",
          "the coupled fixture requires exactly resolution_level=1"));
    }
    return Result<ValidatedParameterPayloadV1>::success(
        {bytes(R"json({"resolution_level":1})json"),
         std::make_shared<const std::uint32_t>(1U)});
  };
  DescriptorPreviewerV1 previewer =
      [manifest_for_preview](const FrameworkProblemView& problem,
                             const MetricRequirements&,
                             const ConstructionBudget& budget,
                             const ValidatedSurrogateParameters& parameters) {
        const auto expected = std::vector<QueueId>{queue("q0"), queue("q1")};
        if (problem.target_selection().ordered_targets != expected) {
          return Result<PlugDescriptorPreview>::failure(fixture_error(
              "c16.fixture.coupled_target_order",
              "the coupled fixture requires the exact ordered q0,q1 target set"));
        }
        auto budget_digest = digest_construction_budget_v1(budget);
        if (!budget_digest) {
          return Result<PlugDescriptorPreview>::failure(
              budget_digest.error());
        }
        auto owned_manifest = std::make_shared<const MetricSupportManifest>(
            manifest_for_preview.metric_clause_upper_envelope);
        PlugDescriptorPreview preview{
            1U,
            descriptor_core(manifest_for_preview, *owned_manifest),
            manifest_for_preview.construction_method,
            manifest_for_preview.producer_mode,
            expected,
            {PointDeploymentPolicyV1::not_applicable,
             CoefficientCompletionPolicyV1::not_applicable,
             ProjectionPolicyV1::not_applicable,
             RecodingPolicyV1::not_applicable,
             EvidenceRolePolicyV1::exact_manifest_roles},
            {{}, std::nullopt, std::nullopt, std::nullopt},
            std::move(owned_manifest),
            problem.canonical_digest().value(),
            parameters.canonical_value_digest(),
            std::move(budget_digest).value(),
            digest("c16.coupled.preview.placeholder")};
        preview.preview_digest =
            std::move(canonical_plug_descriptor_preview_digest_v1(preview))
                .value();
        return Result<PlugDescriptorPreview>::success(std::move(preview));
      };
  RuntimePlugMaterializerV1 materializer =
      [](const PortablePlugPayload& payload,
         const ValidatedSurrogateArtifact& artifact,
         const AcceptedCapabilityContract&) {
        materializer_calls().fetch_add(1U, std::memory_order_relaxed);
        auto descriptor = runtime_descriptor(
            artifact.value().deployed_descriptor);
        SurrogatePlug plug = CoupledTargetSchedulePlugV1{
            payload, finite_access(descriptor),
            {std::nullopt, std::nullopt, std::nullopt}};
        return Result<RuntimePlugCandidateV1>::success(
            {std::move(descriptor), std::move(plug)});
      };
  return {
      std::move(manifest), std::move(parameters), std::move(previewer),
      InProcessBuilderV1{
          [](const SurrogateBuildRequest&, BuildExecutionContext&) {
            return ProviderExecutionOutcome(
                CompletedProviderExecution{{std::byte{'{'}, std::byte{'}'}}});
          }},
      std::move(materializer),
      std::nullopt};
}

struct Scenario final {
  SurrogateProvider provider;
  ValidatedProviderManifest manifest;
  ResolvedInstance instance;
  std::shared_ptr<const CompiledArrivalLaw> arrival;
  MetricRequirements requirements;
  FrameworkProblemView view;
  ValidatedSurrogateParameters parameters;
  PlugDescriptorPreview preview;
  AcceptedCapabilityContract contract;
  ConstructionBudget budget;
  SurrogateBuildRequest request;
};

struct Fixture final {
  Scenario scenario;
  SurrogateArtifactV1 source_artifact;
  ValidatedSurrogateBuildResult validated_result;
  ValidatedSurrogateArtifact validated_artifact;
  PortablePlugPayload portable_payload;
};

[[nodiscard]] inline std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned> serial{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c16-coupled-input";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path = directory /
                    (std::string(stem) + "-" +
                     std::to_string(serial.fetch_add(1U)) + ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

struct Input final {
  ResolvedInstance instance;
  std::shared_ptr<const CompiledArrivalLaw> arrival;
  MetricRequirements requirements;
};

[[nodiscard]] inline Input input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  const std::string analysis = std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0","q1"],
    "metrics":[{"id":"joint","kind":"joint_backlog_event",
      "parameters":{"relation":"any_at_or_above","thresholds":[1,1]}}],
    "surrogate":{"id":")json") + std::string(kProviderId) + R"json(",
                 "version":"1.0.0","parameters":{"resolution_level":1}},
    "resolution":{
      "level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":1,"max_search_states_per_call":1},
      "sampling":{"max_generator_draws":1},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  auto model_document = load_document(write_input("model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(write_input("analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  const auto fingerprints = fingerprint_inputs(canonical);
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(), fingerprints);
  REQUIRE(instance);
  auto arrival = detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements)};
}

[[nodiscard]] inline SourceNode parameter_node() {
  const SourceLocation location{"c16-coupled-parameters.json", 1U, 1U, 0U};
  return SourceNode::make_object(
      {{"resolution_level", location,
        SourceNode::make_number("1", location, "/resolution_level")}},
      location, "");
}

[[nodiscard]] inline ConstructionBudget budget() {
  return {1U,
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::applicable, BigNat{0U}},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt},
          {BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

[[nodiscard]] inline Scenario make_scenario() {
  auto source = input();
  auto id = SurrogateId::parse(std::string(kProviderId));
  REQUIRE(id);
  auto provider = lookup_surrogate_provider(id.value());
  INFO((provider ? std::string{}
                 : provider.error().code + ": " +
                       provider.error().message + " at " +
                       provider.error().json_pointer.value_or("<none>")));
  REQUIRE(provider);
  const TargetSelection targets{
      1U, {queue("q0"), queue("q1")},
      ConstructionGroupIdV1(label("c16.coupled.group"))};
  auto view = build_framework_problem_view(
      source.instance, *source.arrival, targets);
  REQUIRE(view);
  auto parameters = validate_surrogate_parameters(
      provider.value(), parameter_node());
  REQUIRE(parameters);
  auto selected_budget = budget();
  auto preview = preview_surrogate_descriptor(
      provider.value(), view.value(), source.requirements, selected_budget,
      parameters.value());
  INFO((preview ? std::string{}
                : preview.error().code + ": " + preview.error().message));
  REQUIRE(preview);
  auto budget_digest = digest_construction_budget_v1(selected_budget);
  REQUIRE(budget_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, source.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      parameters.value().canonical_value_digest(), budget_digest.value());
  auto request = make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      parameters.value(), selected_budget, MasterSeed(0xC160249U));
  REQUIRE(request);
  auto validated_manifest = provider.value().manifest();
  return {std::move(provider).value(),
          std::move(validated_manifest),
          std::move(source.instance),
          std::move(source.arrival),
          std::move(source.requirements),
          std::move(view).value(),
          std::move(parameters).value(),
          std::move(preview).value(),
          std::move(contract),
          std::move(selected_budget),
          std::move(request).value()};
}

[[nodiscard]] inline CommonBuildReportV1 build_report(
    const Scenario& scenario) {
  CommonBuildReportV1 report{
      1U,
      label("c16.coupled.report"),
      digest("c16.coupled.report.placeholder"),
      scenario.request.request_digest().value(),
      scenario.contract.budget_digest(),
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {WorkCounterApplicabilityV1::applicable, BigNat{0U}},
      {},
      {}};
  report.report_digest =
      std::move(canonical_common_build_report_digest_v1(report)).value();
  return report;
}

[[nodiscard]] inline ProviderConformanceReportRef conformance(
    const Scenario& scenario) {
  const auto& anchor = scenario.manifest.value()
                           .family_evidence_conformance_report_anchors.front();
  return {anchor.report_schema_version,
          anchor.report_id,
          anchor.report_digest,
          scenario.provider.identity(),
          scenario.manifest.scientific_contract_digest().value(),
          anchor.family_evidence_schema_id,
          anchor.family_evidence_schema_version};
}

[[nodiscard]] inline FiniteLawTablesV1 payload(const Scenario& scenario) {
  const auto s00 = label("c16.coupled.s00");
  const auto s11 = label("c16.coupled.s11");
  const auto d00 = label("c16.coupled.d00");
  const auto d11 = label("c16.coupled.d11");

  std::vector<PortableScientificScalar> zero_marks;
  std::vector<PortableScientificScalar> one_marks;
  for (const auto& mark : scenario.contract.descriptor_core().marks) {
    if (mark.kind == MetricMarkKindV1::actual_departure) {
      zero_marks.push_back(scalar(0, 1));
      zero_marks.push_back(scalar(0, 1));
      one_marks.push_back(scalar(1, 1));
      one_marks.push_back(scalar(1, 1));
    } else {
      zero_marks.push_back(scalar(0, 1));
      one_marks.push_back(scalar(1, 1));
    }
  }

  const CommonScheduleRealizationV1 full{
      {queue("q0"), queue("q1")},
      {BigNat{1U}, BigNat{1U}},
      {BigNat{1U}, BigNat{1U}},
      {BigNat{0U}, BigNat{0U}},
      {1U, 1U},
      false,
      std::nullopt};
  const CommonScheduleRealizationV1 empty{
      {}, {}, {BigNat{0U}, BigNat{0U}}, {BigNat{0U}, BigNat{0U}},
      {0U, 0U}, false, std::nullopt};
  auto binding =
      artifact::detail::coupled_tie_phase_arrival_binding_v1(scenario.view);
  REQUIRE(binding);
  CoupledCommonScheduleTableV1 table{
      1U,
      object("c16.coupled.law"),
      FiniteTableStorageV1::dense,
      {{label("c16.coupled.row.s00"),
        s00,
        FiniteRowConditioningStageV1::common_schedule,
        {{s00, {d00}, scalar(1, 1), empty}}},
       {label("c16.coupled.row.s11"),
        s11,
        FiniteRowConditioningStageV1::common_schedule,
        {{s00, {d11}, scalar(1, 1), full}}}},
      scenario.view.fingerprints().constraint,
      std::move(binding).value()};
  FiniteLawTableAlternativeV1 alternative{std::move(table)};
  auto law_digest = artifact::detail::finite_law_table_digest_v1(alternative);
  REQUIRE(law_digest);
  std::get<CoupledCommonScheduleTableV1>(alternative)
      .law_id.object_digest = std::move(law_digest).value();

  return {1U,
          {queue("q0"), queue("q1")},
          SemanticTagV1::coupled_target_schedule_law,
          RuntimeAccessTagV1::finite_enumerated_row,
          scenario.view.fingerprints().compiled_arrival,
          scenario.view.fingerprints().target_selection,
          {{s00, {scalar(0, 1), scalar(0, 1)}},
           {s11, {scalar(1, 1), scalar(1, 1)}}},
          {{d00, std::move(zero_marks)}, {d11, std::move(one_marks)}},
          std::move(alternative)};
}

[[nodiscard]] inline MetricSupportManifestEchoV1 manifest_echo(
    const MetricSupportManifest& manifest) {
  return {1U,
          std::move(canonical_metric_support_manifest_bytes_v1(manifest))
              .value(),
          manifest.canonical_digest()};
}

struct Objects final {
  ArtifactObjectReferenceV1 payload;
  ArtifactObjectReferenceV1 law;
  ArtifactObjectReferenceV1 family;
  ArtifactObjectReferenceV1 validity;
};

[[nodiscard]] inline ArtifactObjectReferenceV1 role_subject(
    const MetricSupportRoleV1 selected, const Objects& objects) {
  if (selected == MetricSupportRoleV1::deployed_payload) {
    return objects.payload;
  }
  if (selected == MetricSupportRoleV1::coupled_schedule_law) {
    return objects.law;
  }
  if (selected ==
      MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    return objects.validity;
  }
  FAIL("unsupported coupled fixture role subject");
  return objects.payload;
}

[[nodiscard]] inline ArtifactObjectReferenceV1 internal_subject(
    const Scenario& scenario, const InternalReferencePurposeV1 purpose,
    const Objects& objects) {
  switch (purpose) {
    case InternalReferencePurposeV1::artifact_payload:
      return objects.payload;
    case InternalReferencePurposeV1::law_or_result:
      return objects.law;
    case InternalReferencePurposeV1::validity_witness:
      return objects.family;
    case InternalReferencePurposeV1::projected_schedule:
      return object("c16.coupled.projected-schedule");
    case InternalReferencePurposeV1::feasibility_domain_codec:
      return {label("c16.coupled.feasibility-domain"),
              scenario.view.fingerprints().constraint};
    case InternalReferencePurposeV1::configured_arrival_binding:
      return {label("c16.coupled.arrival-binding"),
              scenario.view.fingerprints().compiled_arrival};
    case InternalReferencePurposeV1::selection_binding:
      return {label("c16.coupled.selection-binding"),
              scenario.view.fingerprints().target_selection};
    case InternalReferencePurposeV1::timing_binding:
      return {label("c16.coupled.timing-binding"),
              scenario.view.fingerprints().tie_and_timing};
    default:
      return object("c16.coupled.purpose." +
                    std::to_string(static_cast<unsigned>(purpose)));
  }
}

[[nodiscard]] inline std::vector<RealizedRoleRelationV1> role_relations(
    const Scenario& scenario,
    const MetricSupportRoleRequirementV1& requirement,
    const Objects& objects) {
  std::vector<RealizedRoleRelationV1> result;
  const auto clause =
      scenario.contract.structural_manifest().clauses().front().clause_id;
  for (const auto& relation : requirement.role_relations) {
    result.push_back({relation.relation,
                      {clause, relation.other_role},
                      role_subject(relation.other_role, objects)});
  }
  return result;
}

[[nodiscard]] inline std::vector<RealizedInternalReferenceV1>
internal_relations(const Scenario& scenario,
                   const MetricSupportRoleRequirementV1& requirement,
                   const Objects& objects) {
  std::vector<RealizedInternalReferenceV1> result;
  for (const auto& relation : requirement.internal_relations) {
    result.push_back({relation.relation, relation.purpose,
                      internal_subject(scenario, relation.purpose,
                                       objects)});
  }
  return result;
}

[[nodiscard]] inline std::vector<ArtifactObjectReferenceV1>
relation_projection(const std::vector<RealizedRoleRelationV1>& roles,
                    const std::vector<RealizedInternalReferenceV1>& internal,
                    const MetricRoleRelationKindV1 selected) {
  std::vector<ArtifactObjectReferenceV1> result;
  for (const auto& relation : roles) {
    if (relation.relation == selected) {
      result.push_back(relation.referenced_object);
    }
  }
  for (const auto& relation : internal) {
    if (relation.relation == selected) {
      result.push_back(relation.referenced_object);
    }
  }
  std::sort(result.begin(), result.end());
  result.erase(std::unique(result.begin(), result.end()), result.end());
  return result;
}

[[nodiscard]] inline RealizedReferenceCoreV1 realized_core(
    const Scenario& scenario,
    const MetricSupportRoleRequirementV1& requirement,
    const Objects& objects) {
  return {scenario.contract.structural_manifest().clauses().front()
              .ordered_targets,
          requirement.target_scope,
          requirement.result_scope,
          requirement.evidence_scope,
          role_relations(scenario, requirement, objects),
          internal_relations(scenario, requirement, objects)};
}

[[nodiscard]] inline RealizedReferenceV1 realized_reference(
    const Scenario& scenario,
    const MetricSupportRoleRequirementV1& requirement,
    const Objects& objects) {
  auto core = realized_core(scenario, requirement, objects);
  switch (requirement.role) {
    case MetricSupportRoleV1::deployed_payload:
      return DeployedPayloadReferenceV1{
          std::move(core), ArtifactPayloadRef{objects.payload}};
    case MetricSupportRoleV1::coupled_schedule_law:
      return CoupledScheduleLawReferenceV1{
          std::move(core), CoupledScheduleLawRef{objects.law}};
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core),
          ReportedValidityOrLiftEvidenceRef{objects.validity}};
    default:
      FAIL("unsupported coupled fixture realized reference");
  }
  return DeployedPayloadReferenceV1{
      std::move(core), ArtifactPayloadRef{objects.payload}};
}

[[nodiscard]] inline SurrogateArtifactV1 artifact(
    const Scenario& scenario) {
  ArtifactPayloadV1 payload_value = payload(scenario);
  const auto payload_digest =
      std::move(canonical_artifact_payload_digest_v1(payload_value)).value();
  const auto& table = std::get<CoupledCommonScheduleTableV1>(
      std::get<FiniteLawTablesV1>(payload_value).table);
  Objects objects{{label("c16.coupled.payload"), payload_digest},
                  table.law_id,
                  object("c16.coupled.family.placeholder"),
                  object("c16.coupled.validity.placeholder")};

  const auto family_body = bytes(R"json({"claim":"coupled-valid"})json");
  std::vector<ArtifactObjectReferenceV1> family_subjects{
      objects.payload, objects.law};
  std::sort(family_subjects.begin(), family_subjects.end());
  FamilyEvidenceEnvelopeV1 family{
      1U,
      objects.family,
      "c16.coupled.evidence",
      1U,
      conformance(scenario),
      scenario.provider.identity(),
      scenario.manifest.scientific_contract_digest().value(),
      scenario.request.request_digest().value(),
      payload_digest,
      std::move(family_subjects),
      {},
      {queue("q0"), queue("q1")},
      MetricEvidenceScopeV1::validity_or_lift,
      family_body,
      std::move(artifact::detail::family_evidence_body_digest_v1(
                    family_body))
          .value()};
  family.evidence_id.object_digest =
      std::move(artifact::detail::family_evidence_envelope_digest_v1(family))
          .value();
  objects.family = family.evidence_id;

  const auto& manifest = scenario.contract.structural_manifest();
  const auto found = std::find_if(
      manifest.clauses().front().required_roles.begin(),
      manifest.clauses().front().required_roles.end(),
      [](const auto& requirement) {
        return requirement.role ==
               MetricSupportRoleV1::reported_validity_or_lift_evidence;
      });
  REQUIRE(found != manifest.clauses().front().required_roles.end());
  const auto roles = role_relations(scenario, *found, objects);
  auto internal = internal_relations(scenario, *found, objects);
  ScopedArtifactEvidenceV1 scoped{
      objects.validity,
      ArtifactReferenceKindV1::reported_validity_or_lift_evidence,
      manifest.clauses().front().ordered_targets,
      found->result_scope,
      found->evidence_scope,
      relation_projection(roles, internal,
                          MetricRoleRelationKindV1::subject),
      relation_projection(roles, internal,
                          MetricRoleRelationKindV1::lineage_parent),
      {family.evidence_id},
      std::move(internal)};
  scoped.evidence_id.object_digest =
      std::move(artifact::detail::scoped_artifact_evidence_digest_v1(scoped))
          .value();
  objects.validity = scoped.evidence_id;

  std::vector<RealizedMetricBindingV1> bindings;
  for (const auto& requirement : manifest.clauses().front().required_roles) {
    bindings.push_back(
        {{manifest.clauses().front().clause_id, requirement.role},
         realized_reference(scenario, requirement, objects)});
  }

  const auto report = build_report(scenario);
  return {1U,
          scenario.request.request_digest().value(),
          scenario.provider.identity(),
          scenario.manifest.scientific_contract_digest().value(),
          scenario.contract.construction_method(),
          scenario.contract.producer_mode(),
          scenario.contract.semantic(),
          scenario.contract.runtime_access(),
          scenario.contract.payload_class(),
          objects.payload,
          std::move(payload_value),
          payload_digest,
          manifest_echo(manifest),
          {scenario.request.request_digest().value(), payload_digest,
           std::move(bindings)},
          scenario.contract.descriptor_core(),
          report,
          {std::move(family)},
          {std::move(scoped)},
          {},
          {std::nullopt, std::nullopt, std::nullopt, std::nullopt,
           std::nullopt, {}, {}, {}, std::nullopt, std::nullopt,
           std::nullopt}};
}

[[nodiscard]] inline Fixture make_fixture() {
  auto scenario = make_scenario();
  auto source = artifact(scenario);
  const ResultEnvelopeV1 envelope{
      1U, scenario.request.request_digest().value(),
      scenario.provider.identity(), source.build_report_echo};
  const SurrogateBuildResult result =
      BuiltSurrogateResultV1{envelope, source};
  auto report = validate_surrogate_build_report(
      result, scenario.request, scenario.budget);
  INFO((report ? std::string{}
               : report.error().code + ": " + report.error().message));
  REQUIRE(report);
  auto validated = validate_surrogate_build_result(
      result, scenario.request, scenario.manifest, scenario.contract,
      report.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message + " at " +
                        validated.error().json_pointer.value_or("<none>")));
  REQUIRE(validated);
  auto realized = resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  const auto* built = std::get_if<RealizedBuiltCapabilitiesV1>(&realized);
  REQUIRE(built != nullptr);
  auto portable = adapt_portable_payload(built->artifact);
  INFO((portable ? std::string{}
                 : portable.error().code + ": " + portable.error().message));
  REQUIRE(portable);
  return {std::move(scenario),
          std::move(source),
          std::move(validated).value(),
          built->artifact,
          std::move(portable).value()};
}

}  // namespace mwperf::testing::c16_coupled_fixture
