#pragma once

#if !defined(MWPERF_C17_TEST_SEAMS)
#error "c17_spy_plugs.hpp is available only to C17 tests"
#endif

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/kernel/stage_context.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/kernel_access.hpp"
#include "support/c16_designated_payload_fixture.hpp"

namespace mwperf::testing::c17 {

[[nodiscard]] inline ExactRational rational(const std::int64_t numerator,
                                            const std::int64_t denominator) {
  return std::move(
             ExactRational::make(BigInt{numerator}, BigInt{denominator}))
      .value();
}

[[nodiscard]] inline Digest256 digest(const std::string_view text) {
  return std::move(sha256(std::as_bytes(std::span(text.data(), text.size()))))
      .value();
}

[[nodiscard]] inline CanonicalRuntimeValueV1 value(
    std::string codec, const std::initializer_list<std::uint8_t> bytes) {
  std::vector<std::byte> canonical;
  canonical.reserve(bytes.size());
  for (const std::uint8_t byte : bytes) {
    canonical.push_back(static_cast<std::byte>(byte));
  }
  return {{std::move(codec), 1U}, std::move(canonical)};
}

[[nodiscard]] inline TypedLabel label(const std::string_view text) {
  return std::move(TypedLabel::text(std::string(text))).value();
}

[[nodiscard]] inline Diagnostic error(std::string code,
                                      std::string message) {
  return {DiagnosticCategory::input_validation, std::move(code),
          std::move(message), std::nullopt, std::nullopt, {}};
}

template <typename T>
[[nodiscard]] inline Result<T> failure(std::string code,
                                       std::string message) {
  return Result<T>::failure(error(std::move(code), std::move(message)));
}

struct MathBaseV1 final {
  C16DesignatedScenarioV1 scenario;
  ResolvedInstance instance;
  CompiledArrivalLaw configured_arrival;
  PlugDescriptor descriptor;
  ArrivalPhase phase_zero;
  ArrivalPhase phase_one;
};

[[nodiscard]] inline ResolvedInstance make_shared_arrival_instance() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"shared_joint_round_markov_renewal",
      "sources":[{"id":"s"}],
      "states":["h0","h1"],"initial":{"state":"h0"},
      "outcomes":[
        {"state":"h0","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
        {"state":"h0","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]},
        {"state":"h1","next_state":"h0","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q0"}]},
        {"state":"h1","next_state":"h1","probability":0.5,
         "emissions":[{"source_id":"s","d":1,"queue_id":"q1"}]}],
      "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.designated.recoded",
                 "version":"1.0.0","parameters":{"resolution_level":1}},
    "resolution":{"level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
               "max_iterations":null}}
  })json";

  auto model_document = load_document(
      c16_designated_detail::write_input("c17-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      c16_designated_detail::write_input("c17-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  INFO((instance ? std::string{}
                 : instance.error().code + ": " + instance.error().message));
  REQUIRE(instance);
  return std::move(instance).value();
}

[[nodiscard]] inline c16_designated_detail::InputV1
make_alternating_three_bin_input() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"},{"id":"q2"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0","q1","q2"],
      "max_search_states":null}},
    "arrival":{"family":"periodic_global_phase","period":2,"phase":0,
      "sources":[{"id":"s","entries":[
        {"offset":0,"queue_id":"q0","count":1},
        {"offset":1,"queue_id":"q1","count":1}]}],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,"write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"throughput","kind":"stationary_throughput",
                "parameters":{}}],
    "surrogate":{"id":"c16.fixture.designated.raw",
                 "version":"1.0.0","parameters":{"resolution_level":1}},
    "resolution":{"level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"analytic","parameters":{"precision_bits":128,
               "max_iterations":null}}
  })json";

  auto model_document = load_document(
      c16_designated_detail::write_input("c17-three-bin-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      c16_designated_detail::write_input("c17-three-bin-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  INFO((instance ? std::string{}
                 : instance.error().code + ": " + instance.error().message));
  REQUIRE(instance);
  auto arrival =
      detail::CompiledArrivalAccess::get(instance.value().arrival());
  REQUIRE(arrival);
  auto request = parse_metric_request(
      instance.value().analysis_spec().metrics.front(),
      instance.value().queues());
  REQUIRE(request);
  std::vector<MetricRequest> requests{request.value()};
  auto requirements = aggregate_metric_requirements(requests);
  return {std::move(instance).value(), std::move(arrival).value(),
          std::move(requirements), std::move(request).value()};
}

[[nodiscard]] inline ResolvedInstance make_conflicting_face_instance() {
  static constexpr std::string_view model = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[["q0","q1"]]},
      "priority":["q0","q1"],"max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[],
               "metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0","q1"],
    "metrics":[{"id":"joint","kind":"joint_backlog_event",
      "parameters":{"relation":"any_at_or_above",
                    "thresholds":[1,1]}}],
    "surrogate":{"id":"c17.fixture.common-face","version":"1.0.0",
                 "parameters":{"resolution_level":1}},
    "resolution":{"level":{"max_states":64,"max_row_atoms":64},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":64},
      "optimizer":{"max_calls":64,"max_search_states_per_call":64},
      "sampling":{"max_generator_draws":64},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"stationary_unique","parameters":{}},
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  auto model_document = load_document(
      c16_designated_detail::write_input("c17-face-model", model));
  REQUIRE(model_document);
  auto model_node = extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto authored_model = parse_model_config_v3(model_node.value());
  REQUIRE(authored_model);
  auto analysis_document = load_document(
      c16_designated_detail::write_input("c17-face-analysis", analysis));
  REQUIRE(analysis_document);
  auto authored_analysis = parse_analysis_spec_v1(analysis_document.value());
  REQUIRE(authored_analysis);
  const auto canonical = canonicalize_authored_inputs(
      authored_model.value(), authored_analysis.value());
  auto instance = resolve_physical_instance(
      authored_model.value(), authored_analysis.value(),
      fingerprint_inputs(canonical));
  REQUIRE(instance);
  return std::move(instance).value();
}

[[nodiscard]] inline const ResolvedInstance& conflicting_face_instance() {
  static const ResolvedInstance instance = make_conflicting_face_instance();
  return instance;
}

[[nodiscard]] inline MathBaseV1 make_math_base() {
  auto scenario = make_c16_designated_scenario_v1();
  auto instance = make_shared_arrival_instance();
  auto configured_arrival = make_c09_correlated_fixture_law(
      instance.queues());
  REQUIRE(configured_arrival);
  auto instance_key = make_physical_reference_instance_key(
      instance.fingerprints().combined, BigNat{0U});
  REQUIRE(instance_key);
  const auto phase = [&](std::string state, const std::uint64_t seed) {
    auto stream = make_configured_arrival_stream_key(
        configured_arrival.value(),
        derive_rng_stream(MasterSeed{seed}, StageTag::configured_arrival,
                          instance_key.value()));
    REQUIRE(stream);
    auto process = instantiate_arrival_process(
        configured_arrival.value(),
        ArrivalInitialState{SharedRoundState{std::move(state)}},
        std::move(stream).value());
    REQUIRE(process);
    auto first = next_arrival_step(process.value(), BigNat{0U});
    REQUIRE(first);
    return first.value().phase_before;
  };
  auto descriptor = c16_fixture_detail::runtime_descriptor(
      scenario.contract.descriptor_core());
  auto phase_zero = phase("h0", 0xC1701U);
  auto phase_one = phase("h1", 0xC1702U);
  return {std::move(scenario), std::move(instance),
          std::move(configured_arrival).value(), std::move(descriptor),
          std::move(phase_zero), std::move(phase_one)};
}

[[nodiscard]] inline const MathBaseV1& math_base() {
  static const MathBaseV1 fixture = make_math_base();
  return fixture;
}

[[nodiscard]] inline TargetBacklogV1 target_backlog(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets,
    const std::initializer_list<std::uint64_t> values) {
  std::vector<BigNat> exact;
  exact.reserve(values.size());
  for (const std::uint64_t item : values) {
    exact.emplace_back(item);
  }
  auto result = TargetBacklogV1::from_values(
      instance, ordered_targets, std::move(exact));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline TargetBacklogV1 target_backlog(
    const MathBaseV1& base,
    const std::initializer_list<std::uint64_t> values) {
  return target_backlog(base.instance, base.descriptor.core.deployed_targets,
                        values);
}

[[nodiscard]] inline Schedule schedule(
    const ResolvedInstance& instance,
    const std::initializer_list<std::uint8_t> values) {
  auto result = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance),
      std::vector<std::uint8_t>(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] inline ArrivalBatch arrival_batch(
    const MathBaseV1& base,
    const std::initializer_list<std::pair<std::size_t, std::uint64_t>>
        entries) {
  std::vector<ArrivalAtom> atoms;
  atoms.reserve(entries.size());
  for (const auto& [ordinal, count] : entries) {
    auto queue = base.instance.queues().index_at(ordinal);
    REQUIRE(queue);
    auto atom = ArrivalAtom::make(
        queue.value(), BigNat{count},
        arrival_law_binding(base.configured_arrival));
    REQUIRE(atom);
    atoms.push_back(std::move(atom).value());
  }
  auto batch = aggregate_arrival_batch(atoms);
  REQUIRE(batch);
  return std::move(batch).value();
}

[[nodiscard]] inline bool same_phase(const ArrivalPhase& left,
                                     const ArrivalPhase& right) {
  const auto left_bytes = arrival_phase_canonical_state(left);
  const auto right_bytes = arrival_phase_canonical_state(right);
  return arrival_phase_family(left) == arrival_phase_family(right) &&
         left_bytes.size() == right_bytes.size() &&
         std::equal(left_bytes.begin(), left_bytes.end(),
                    right_bytes.begin());
}

inline const CodecIdentityV1 kReducedStateCodec{
    "c17.fixture.exact-reduced-state", 1U};
inline constexpr std::uint8_t kHiddenUnitStateFlagV1 = 0x80U;

[[nodiscard]] inline ReducedStateV1 reduced_state(
    const std::span<const QueueId> ordered_targets,
    const std::initializer_list<std::uint8_t> backlog_values,
    const bool after_arrival_phase = false,
    const std::uint8_t boundary = 0U) {
  REQUIRE(backlog_values.size() == ordered_targets.size());
  std::vector<std::byte> bytes;
  bytes.reserve(backlog_values.size() + 2U);
  for (const std::uint8_t item : backlog_values) {
    bytes.push_back(static_cast<std::byte>(item));
  }
  bytes.push_back(after_arrival_phase ? std::byte{1U} : std::byte{0U});
  bytes.push_back(static_cast<std::byte>(boundary));
  return {kReducedStateCodec, std::move(bytes)};
}

[[nodiscard]] inline ExactReducedStateSchemaV1 exact_state_schema(
    const ResolvedInstance& instance,
    const std::span<const QueueId> ordered_targets, ArrivalPhase before,
    ArrivalPhase after) {
  std::vector<QueueId> target_ids(ordered_targets.begin(),
                                  ordered_targets.end());
  std::vector<BigNat> zeros(target_ids.size(), BigNat{0U});
  auto target_prototype = TargetBacklogV1::from_values(
      instance, target_ids, std::move(zeros));
  REQUIRE(target_prototype);
  const std::size_t cardinality = target_ids.size();

  return {
      kReducedStateCodec,
      digest("c17.fixture.exact-state-schema"),
      digest("c17.fixture.reduced-state-schema"),
      digest("c17.fixture.ownership-schema"),
      digest("c17.fixture.exact-update-schema"),
      [target_prototype = std::move(target_prototype).value(), before, after,
       cardinality](const ReducedStateV1& state)
          -> Result<ExactReducedCoordinatesV1> {
        if (state.codec != kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U) {
          return failure<ExactReducedCoordinatesV1>(
              "c17.fixture.state_shape", "invalid exact-state fixture shape");
        }
        std::vector<BigNat> values;
        values.reserve(cardinality);
        for (std::size_t index = 0U; index < cardinality; ++index) {
          values.emplace_back(std::to_integer<std::uint8_t>(
              state.canonical_value[index]));
        }
        auto exact_backlog = target_prototype.with_values(std::move(values));
        if (!exact_backlog) {
          return Result<ExactReducedCoordinatesV1>::failure(
              exact_backlog.error());
        }
        const std::uint8_t phase = std::to_integer<std::uint8_t>(
            state.canonical_value[cardinality]);
        if (phase > 1U) {
          return failure<ExactReducedCoordinatesV1>(
              "c17.fixture.phase", "invalid exact-state phase selector");
        }
        const BigNat boundary{
            std::to_integer<std::uint8_t>(
                state.canonical_value[cardinality + 1U])};
        auto anchored =
            mwperf::testing::reanchor_c09_fixture_phase_for_testing(
                phase == 0U ? before : after, boundary);
        if (!anchored) {
          return Result<ExactReducedCoordinatesV1>::failure(
              anchored.error());
        }
        return Result<ExactReducedCoordinatesV1>::success(
            {std::move(exact_backlog).value(),
             std::move(anchored).value(), boundary,
             std::nullopt,
             {},
             std::nullopt,
             {}});
      },
      [before, after,
       cardinality](const ExactReducedCoordinatesV1& coordinates,
                    const UnresolvedPatch& unresolved)
          -> Result<ReducedStateV1> {
        if (coordinates.backlog.size() != cardinality ||
            !unresolved.fields().empty()) {
          return failure<ReducedStateV1>(
              "c17.fixture.rebuild_shape",
              "the exact fixture rebuild received a foreign coordinate");
        }
        const bool is_before = same_phase(coordinates.arrival_phase, before);
        const bool is_after = same_phase(coordinates.arrival_phase, after);
        if (!is_before && !is_after) {
          return failure<ReducedStateV1>(
              "c17.fixture.rebuild_phase",
              "the exact fixture rebuild received a foreign arrival phase");
        }
        if (coordinates.boundary_index.bit_length() > 8U) {
          return failure<ReducedStateV1>(
              "c17.fixture.rebuild_boundary",
              "the direct one-slot fixture boundary exceeded one byte");
        }
        std::vector<std::byte> bytes;
        bytes.reserve(cardinality + 2U);
        for (const BigNat& value : coordinates.backlog.values()) {
          if (value.bit_length() > 8U) {
            return failure<ReducedStateV1>(
                "c17.fixture.rebuild_backlog",
                "the direct one-slot fixture backlog exceeded one byte");
          }
          bytes.push_back(static_cast<std::byte>(
              value.value().convert_to<std::uint8_t>()));
        }
        bytes.push_back(is_after ? std::byte{1U} : std::byte{0U});
        bytes.push_back(static_cast<std::byte>(
            coordinates.boundary_index.value().convert_to<std::uint8_t>()));
        return Result<ReducedStateV1>::success(
            {kReducedStateCodec, std::move(bytes)});
      },
      [cardinality](const ReducedStateV1& state) {
        if (state.codec != kReducedStateCodec ||
            state.canonical_value.size() != cardinality + 2U) {
          return failure<void>("c17.fixture.domain",
                               "state is outside the exact fixture domain");
        }
        return Result<void>::success();
      },
      {},
      {},
      {}};
}

[[nodiscard]] inline ReducedStateV1 reduced_state(
    const MathBaseV1& base,
    const std::initializer_list<std::uint8_t> backlog_values,
    const bool after_arrival_phase = false,
    const std::uint8_t boundary = 0U) {
  return reduced_state(base.descriptor.core.deployed_targets, backlog_values,
                       after_arrival_phase, boundary);
}

[[nodiscard]] inline ExactReducedStateSchemaV1 exact_state_schema(
    const MathBaseV1& base) {
  return exact_state_schema(base.instance,
                            base.descriptor.core.deployed_targets,
                            base.phase_zero, base.phase_one);
}

struct ThreeBinFrameworkV1 final {
  AuditedCompiledFramework framework;
  ResolvedInstance instance;
  std::vector<QueueId> ordered_targets;
  ExactReducedStateSchemaV1 state_schema;
  PlugDescriptor descriptor;
};

[[nodiscard]] inline ThreeBinFrameworkV1
finish_closed_scalar_framework_v1(
    C16DesignatedScenarioV1 scenario, ValidatedSurrogatePlug plug,
    KernelAccess access, PlugDescriptor descriptor,
    RealizedMetricBindingsV1 realized, const bool admit_hidden_unit_state,
    const std::uint8_t largest_audit_backlog,
    const ExactCausalProgramModeV1 program_mode,
    const std::optional<std::pair<ArrivalPhase, ArrivalPhase>>&
        phase_override = std::nullopt) {
  const std::vector<QueueId> deployed_targets(
      descriptor.core.deployed_targets.begin(),
      descriptor.core.deployed_targets.end());
  const CompiledArrivalLaw configured_arrival = *scenario.arrival;
  // Existing C17 callers retain the original periodic two-step phase probe.
  // The C27 IID integration fixture supplies the two exact shared-round
  // phases because that arrival family has a different typed initializer.
  const auto phases = [&]() -> std::pair<ArrivalPhase, ArrivalPhase> {
    if (phase_override.has_value()) return *phase_override;
    auto instance_key = make_physical_reference_instance_key(
        scenario.instance.fingerprints().combined, BigNat{0U});
    REQUIRE(instance_key);
    auto stream = make_configured_arrival_stream_key(
        configured_arrival,
        derive_rng_stream(MasterSeed{0xC1703U},
                          StageTag::configured_arrival,
                          instance_key.value()));
    REQUIRE(stream);
    auto process = instantiate_arrival_process(
        configured_arrival, ArrivalInitialState{GlobalPeriodicOrigin{}},
        std::move(stream).value());
    REQUIRE(process);
    auto first_arrival = next_arrival_step(process.value(), BigNat{0U});
    auto second_arrival = next_arrival_step(process.value(), BigNat{1U});
    REQUIRE(first_arrival);
    REQUIRE(second_arrival);
    REQUIRE_FALSE(same_phase(first_arrival.value().phase_before,
                             first_arrival.value().phase_after));
    REQUIRE(same_phase(first_arrival.value().phase_after,
                       second_arrival.value().phase_before));
    REQUIRE(same_phase(first_arrival.value().phase_before,
                       second_arrival.value().phase_after));
    return {first_arrival.value().phase_before,
            first_arrival.value().phase_after};
  }();
  auto state_schema = exact_state_schema(
      scenario.instance, deployed_targets, phases.first, phases.second);
  if (admit_hidden_unit_state) {
    const RuntimeFieldPatchV1 hidden{
        RuntimeFieldIdV1(label("c17.fixture.hidden-unit-z")),
        value("c17.fixture.hidden-unit-z", {0x01U})};
    auto decode = std::move(state_schema.decode);
    auto rebuild = std::move(state_schema.rebuild);
    state_schema.decode =
        [decode = std::move(decode), hidden](const ReducedStateV1& state) {
          ReducedStateV1 normalized = state;
          const bool carries_hidden =
              !normalized.canonical_value.empty() &&
              (std::to_integer<std::uint8_t>(
                   normalized.canonical_value.back()) &
               kHiddenUnitStateFlagV1) != 0U;
          if (carries_hidden) {
            normalized.canonical_value.back() = static_cast<std::byte>(
                std::to_integer<std::uint8_t>(
                    normalized.canonical_value.back()) &
                static_cast<std::uint8_t>(~kHiddenUnitStateFlagV1));
          }
          auto decoded = decode(normalized);
          if (decoded && carries_hidden) {
            decoded.value().unresolved_fields.push_back(hidden);
          }
          return decoded;
        };
    state_schema.rebuild =
        [rebuild = std::move(rebuild), hidden](
            const ExactReducedCoordinatesV1& coordinates,
            const UnresolvedPatch& patch) {
          ExactReducedCoordinatesV1 normalized = coordinates;
          const auto hidden_field = std::ranges::find(
              normalized.unresolved_fields, hidden);
          const bool carries_hidden =
              hidden_field != normalized.unresolved_fields.end();
          if (carries_hidden) {
            normalized.unresolved_fields.erase(hidden_field);
          }
          auto state = rebuild(normalized, patch);
          if (state && carries_hidden) {
            state.value().canonical_value.back() = static_cast<std::byte>(
                std::to_integer<std::uint8_t>(
                    state.value().canonical_value.back()) |
                kHiddenUnitStateFlagV1);
          }
          return state;
        };
    state_schema.exact_state_schema_digest =
        digest("c17.fixture.hidden-unit.exact-state-schema");
    state_schema.reduced_state_schema_digest =
        digest("c17.fixture.hidden-unit.reduced-state-schema");
    state_schema.ownership_schema_digest =
        digest("c17.fixture.hidden-unit.ownership-schema");
    state_schema.exact_update_schema_digest =
        digest("c17.fixture.hidden-unit.exact-update-schema");
  }
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      scenario.instance, BigNat{0U});
  REQUIRE(optimizer);
  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          scenario.view.target_selection().ordered_targets);
  REQUIRE(ordered_target_digest);
  REQUIRE(scenario.instance.analysis_spec().context);
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          scenario.instance.analysis_spec().context->selection);
  REQUIRE(selection_digest);

  auto canonical_access =
      C17FixtureAccess::canonical_raw_access_identity(access);
  REQUIRE(canonical_access);
  const Digest256 access_digest = std::move(canonical_access).value();
  AuditedFrameworkBindingsV1 bindings{
      scenario.view.fingerprints(),
      scenario.view.canonical_digest(),
      state_schema.exact_state_schema_digest,
      state_schema.reduced_state_schema_digest,
      descriptor.descriptor_digest,
      access_digest,
      scenario.contract.contract_digest(),
      scenario.contract.requirements_digest(),
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      scenario.request.request_digest().value(),
      std::nullopt};
  auto initial_mass = ProbabilityMass::exact_rational(
      ExactRational::one(), true);
  REQUIRE(initial_mass);
  const ReducedStateV1 initial_state =
      reduced_state(deployed_targets, {0U});
  const CodecIdentityV1 state_codec = state_schema.reduced_state_codec;
  const Digest256 exact_schema_digest =
      state_schema.exact_state_schema_digest;
  const Digest256 reduced_schema_digest =
      state_schema.reduced_state_schema_digest;
  const Digest256 selected_law_digest = bindings.selection_digest;
  const SelectionSupportV1 selection_support = descriptor.core.selection;
  const Digest256 instance_digest =
      scenario.instance.fingerprints().combined;
  const auto domain_validator = state_schema.validate_domain;
  AuditedFrameworkSeedV1 seed{
      bindings,
      scenario.view.target_selection(),
      state_schema.reduced_state_codec,
      descriptor.core.selection,
      {SelectionKindV1::stationary_unique,
       digest("c17.fixture.selection-evidence")},
      [state_codec, exact_schema_digest, reduced_schema_digest,
       selected_law_digest, selection_support, initial_state,
       initial_mass = std::move(initial_mass).value()](
          const SelectionSpec&,
          const std::optional<InitialPhysicalLaw>&) {
        return Result<ReducedInitialLawCandidateV1>::success(
            {state_codec, exact_schema_digest, reduced_schema_digest,
             selected_law_digest, selection_support,
             {{initial_state, initial_mass, std::nullopt}}});
      },
      [instance_digest, exact_schema_digest](
          const ResolvedInstance& instance,
          const Digest256& supplied_schema) {
        if (instance.fingerprints().combined != instance_digest ||
            supplied_schema != exact_schema_digest) {
          return failure<void>("c17.fixture.initial_schema_binding",
                               "foreign exact initial-state schema");
        }
        return Result<void>::success();
      },
      domain_validator,
      [domain_validator](std::size_t, const InitialPhysicalAtom&,
                         const ReducedStateV1& reduced) {
        return domain_validator(reduced);
      }};
  std::vector<ReducedStateV1> audit_states;
  audit_states.reserve(
      static_cast<std::size_t>(largest_audit_backlog) + 1U);
  for (std::uint16_t backlog = 0U;
       backlog <= static_cast<std::uint16_t>(largest_audit_backlog);
       ++backlog) {
    const auto value = static_cast<std::uint8_t>(backlog);
    audit_states.push_back(reduced_state(deployed_targets, {value}, false));
  }
  ExactCausalProgramV1 program{
      program_mode,
      physical_pmf_tolerance(),
      PmfRepresentationBudget::unbounded(),
      std::move(audit_states)};
  // Every positive-length edge advances the exact boundary index and the
  // configured predictive phase.  The finite audit probe set is therefore
  // never an endpoint-closed event-domain certificate.
  program.event_entry_domain_is_exact_state_domain = true;
  CompiledFrameworkCandidateInputsV1 inputs{
      scenario.request.build_identity_digest(),
      scenario.request.request_digest().value(),
      scenario.instance,
      configured_arrival,
      scenario.contract,
      std::move(realized),
      state_schema,
      std::move(program),
      std::nullopt,
      std::move(optimizer).value(),
      std::move(seed)};
  auto candidate = C17FixtureAccess::make_candidate(
      std::move(plug), std::move(inputs));
  auto framework = audit_v0_causality(
      std::move(candidate), descriptor, std::move(access));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  return {std::move(framework).value(), scenario.instance,
          deployed_targets, std::move(state_schema), std::move(descriptor)};
}

[[nodiscard]] inline ThreeBinFrameworkV1 make_three_bin_framework_v1(
    const std::array<ExactRational, 3U>& coefficients,
    const bool admit_hidden_unit_state,
    const std::uint8_t largest_audit_backlog) {
  const auto options = c16_designated_payload_options_v1(
      C16DesignatedResponseStageV1::raw);
  auto scenario = make_c16_designated_scenario_from_input_v1(
      C16DesignatedResponseStageV1::raw,
      make_alternating_three_bin_input());
  const auto& metric_header = metric_request_header(scenario.metric_request);
  std::vector<ResolvedMetricContractV1> metric_contracts{{
      metric_header.authored_index,
      {metric_header.metric_id, metric_header.authored_index},
      metric_header.metric_id,
      metric_header.ordered_targets,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      TargetCouplingV1::scalar_target,
      SolverRegimeV1::analytic,
      BackendRouteKindV1::residence_or_stopped_law,
      scenario.contract.structural_manifest().canonical_digest()}};
  auto residence_contract = C15ProtocolFixtureFactory::accepted_contract(
      scenario.manifest.value(), scenario.contract.descriptor_core(),
      scenario.contract.structural_manifest(),
      scenario.contract.requirements(),
      scenario.contract.arrival_capabilities(),
      std::move(metric_contracts),
      std::vector<QueueId>(
          scenario.contract.construction_target_scope().begin(),
          scenario.contract.construction_target_scope().end()),
      scenario.contract.policies(),
      scenario.contract.construction_prerequisites(),
      scenario.view.canonical_digest().value(),
      scenario.parameters.canonical_value_digest(),
      scenario.contract.budget_digest());
  auto residence_request = make_surrogate_build_request(
      scenario.manifest, scenario.view, residence_contract,
      scenario.parameters, scenario.budget, MasterSeed{0xC1707U});
  REQUIRE(residence_request);
  scenario.contract = std::move(residence_contract);
  scenario.request = std::move(residence_request).value();

  auto response = make_c16_designated_response_v1(scenario, options);
  for (std::size_t index = 0U; index < coefficients.size(); ++index) {
    const auto scalar =
        PortableScientificScalar::rational(coefficients[index]);
    response.raw_response.identifications[index].raw_point = scalar;
    REQUIRE(response.nominal_response.has_value());
    response.nominal_response->coefficients[index].value = scalar;
    REQUIRE(response.recoded_response.has_value());
    response.recoded_response->coefficients[index].value = scalar;
  }
  auto source = rebuild_c16_designated_artifact_v1(
      scenario, std::move(response));
  auto adapted = validate_and_adapt_c16_designated_artifact_v1(
      scenario, source);
  INFO((adapted ? std::string{}
                : adapted.error().code + ": " + adapted.error().message));
  REQUIRE(adapted);
  auto carried = std::move(adapted).value();
  auto plug = materialize_and_validate_surrogate_plug(
      carried.payload, carried.artifact, scenario.contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  auto access = validate_kernel_access(plug.value());
  REQUIRE(access);
  PlugDescriptor descriptor = plug.value().descriptor();

  const std::vector<QueueId> deployed_targets(
      descriptor.core.deployed_targets.begin(),
      descriptor.core.deployed_targets.end());
  auto realized = validate_realized_metric_bindings_v1(
      scenario.contract.structural_manifest(),
      RealizedBindingValidationContextV1{
          RealizedBindingTargetContextV1{
              deployed_targets,
              std::optional<QueueId>{deployed_targets.front()},
              std::vector<QueueId>(
                  scenario.contract.construction_target_scope().begin(),
                  scenario.contract.construction_target_scope().end())},
          scenario.contract.policies()},
      carried.artifact.value().realized_metric_bindings.bindings);
  REQUIRE(realized);
  return finish_closed_scalar_framework_v1(
      std::move(scenario), std::move(plug).value(),
      std::move(access).value(), std::move(descriptor),
      std::move(realized).value(), admit_hidden_unit_state,
      largest_audit_backlog,
      ExactCausalProgramModeV1::closed_three_bin_scalar);
}

[[nodiscard]] inline ThreeBinFrameworkV1
make_finite_prefix_constant_tail_framework_from_input(
    const std::vector<ExactRational>& service_by_level,
    const ExactRational& constant_tail_service,
    c16_designated_detail::InputV1 input,
    const BackendRouteKindV1 accepted_backend_route,
    const std::optional<std::pair<ArrivalPhase, ArrivalPhase>>&
        phase_override,
    const std::uint8_t largest_audit_backlog = 8U) {
  REQUIRE(service_by_level.size() >= 3U);
  REQUIRE(service_by_level.size() <= 6U);
  REQUIRE(service_by_level.front().is_zero());
  const std::size_t cutoff = service_by_level.size() - 1U;

  const auto options = c16_designated_payload_options_v1(
      C16DesignatedResponseStageV1::raw);
  auto scenario = make_c16_designated_scenario_from_input_v1(
      C16DesignatedResponseStageV1::raw,
      std::move(input));
  const auto& metric_header = metric_request_header(scenario.metric_request);
  std::vector<ResolvedMetricContractV1> metric_contracts{{
      metric_header.authored_index,
      {metric_header.metric_id, metric_header.authored_index},
      metric_header.metric_id,
      metric_header.ordered_targets,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      TargetCouplingV1::scalar_target,
      SolverRegimeV1::analytic,
      accepted_backend_route,
      scenario.contract.structural_manifest().canonical_digest()}};
  auto residence_contract = C15ProtocolFixtureFactory::accepted_contract(
      scenario.manifest.value(), scenario.contract.descriptor_core(),
      scenario.contract.structural_manifest(),
      scenario.contract.requirements(),
      scenario.contract.arrival_capabilities(), metric_contracts,
      std::vector<QueueId>(
          scenario.contract.construction_target_scope().begin(),
          scenario.contract.construction_target_scope().end()),
      scenario.contract.policies(),
      scenario.contract.construction_prerequisites(),
      scenario.view.canonical_digest().value(),
      scenario.parameters.canonical_value_digest(),
      scenario.contract.budget_digest());
  auto residence_request = make_surrogate_build_request(
      scenario.manifest, scenario.view, residence_contract,
      scenario.parameters, scenario.budget, MasterSeed{0xC1707U});
  REQUIRE(residence_request);
  scenario.contract = std::move(residence_contract);
  scenario.request = std::move(residence_request).value();

  // Reuse the designated fixture only to obtain already-bound C14/C15
  // request identities and realized role references.  The dynamic portable
  // response below is a distinct native product and never folds through the
  // legacy coefficient triple.
  auto baseline_response =
      make_c16_designated_response_v1(scenario, options);
  auto baseline_source = rebuild_c16_designated_artifact_v1(
      scenario, std::move(baseline_response));
  auto baseline_adapted = validate_and_adapt_c16_designated_artifact_v1(
      scenario, baseline_source);
  REQUIRE(baseline_adapted);
  auto carried = std::move(baseline_adapted).value();
  auto baseline_plug = materialize_and_validate_surrogate_plug(
      carried.payload, carried.artifact, scenario.contract);
  REQUIRE(baseline_plug);
  PlugDescriptor descriptor = baseline_plug.value().descriptor();

  std::vector<MetricSupportClauseV1> dynamic_clauses(
      scenario.contract.structural_manifest().clauses().begin(),
      scenario.contract.structural_manifest().clauses().end());
  using EvidenceScope = MetricEvidenceScopeV1;
  using InternalPurpose = InternalReferencePurposeV1;
  using RelationKind = MetricRoleRelationKindV1;
  using ResultScope = MetricResultScopeV1;
  using Role = MetricSupportRoleV1;
  using TargetScope = MetricTargetScopeV1;
  const auto support_role = [](
      const Role role, const TargetScope target_scope,
      const ResultScope result_scope, const EvidenceScope evidence_scope,
      std::vector<MetricRoleRelationRequirementV1> role_relations = {},
      std::vector<InternalRelationRequirementV1> internal_relations = {}) {
    return MetricSupportRoleRequirementV1{
        role, target_scope, result_scope, evidence_scope,
        std::move(role_relations), std::move(internal_relations)};
  };
  const std::vector<MetricSupportRoleRequirementV1> dynamic_roles{
      support_role(Role::deployed_payload, TargetScope::payload_targets,
                   ResultScope::surrogate_law, EvidenceScope::none),
      support_role(
          Role::deployed_response, TargetScope::deployed_singleton_target,
          ResultScope::surrogate_law,
          EvidenceScope::deployed_surrogate_law,
          {{RelationKind::binding, Role::deployed_payload},
           {RelationKind::subject, Role::raw_response}}),
      support_role(
          Role::raw_response, TargetScope::deployed_singleton_target,
          ResultScope::proposal_raw, EvidenceScope::raw_static_proposal,
          {{RelationKind::binding, Role::deployed_payload},
           {RelationKind::evidence,
            Role::raw_response_bound_evidence}},
          {{RelationKind::lineage_parent,
            InternalPurpose::coefficient_origin}}),
      support_role(
          Role::raw_response_bound_evidence,
          TargetScope::deployed_singleton_target,
          ResultScope::not_a_metric_result,
          EvidenceScope::raw_static_proposal,
          {{RelationKind::subject, Role::raw_response}},
          {{RelationKind::binding, InternalPurpose::evaluation_identity},
           {RelationKind::binding, InternalPurpose::proposal_identity},
           {RelationKind::subject, InternalPurpose::coefficient_origin}}),
      support_role(
          Role::statistical_evidence,
          TargetScope::deployed_singleton_target,
          ResultScope::not_a_metric_result,
          EvidenceScope::raw_static_proposal, {},
          {{RelationKind::binding, InternalPurpose::evaluation_identity},
           {RelationKind::binding, InternalPurpose::sampling_bank},
           {RelationKind::binding, InternalPurpose::sampling_probe},
           {RelationKind::binding, InternalPurpose::coverage_family},
           {RelationKind::subject, InternalPurpose::estimand}})};
  for (auto& clause : dynamic_clauses) {
    clause.payload_class = {
        PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U};
    clause.required_roles = dynamic_roles;
  }
  auto dynamic_manifest_result =
      MetricSupportManifest::from_clauses(std::move(dynamic_clauses));
  REQUIRE(dynamic_manifest_result);
  MetricSupportManifest dynamic_manifest =
      std::move(dynamic_manifest_result).value();

  PlugDescriptorCore dynamic_core = descriptor.core;
  dynamic_core.payload_class = {
      PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U};
  dynamic_core.tail = {
      TailRepresentationKindV1::constant_response,
      BigNat{cutoff + 1U}, std::nullopt};
  dynamic_core.metric_support_manifest_digest =
      dynamic_manifest.canonical_digest();
  auto core_digest = canonical_plug_descriptor_core_digest_v1(dynamic_core);
  REQUIRE(core_digest);
  dynamic_core.core_digest = std::move(core_digest).value();

  SurrogateProviderManifestV1 dynamic_provider = scenario.manifest.value();
  dynamic_provider.payload_class = dynamic_core.payload_class;
  dynamic_provider.metric_clause_upper_envelope = dynamic_manifest;
  dynamic_provider.allowed_metric_support_roles = {
      Role::deployed_payload, Role::deployed_response, Role::raw_response,
      Role::raw_response_bound_evidence, Role::statistical_evidence};
  dynamic_provider.scientific_construction_policy_schema = {
      1U,
      {PointDeploymentPolicyV1::deploy_raw_point},
      {CoefficientCompletionPolicyV1::require_complete_raw_points},
      {ProjectionPolicyV1::not_applicable},
      {RecodingPolicyV1::not_applicable},
      {EvidenceRolePolicyV1::exact_manifest_roles},
      {},
      {}};
  auto provider_digest = digest_provider_manifest_v1(dynamic_provider);
  REQUIRE(provider_digest);
  dynamic_provider.manifest_digest = std::move(provider_digest).value();
  for (auto& contract : metric_contracts) {
    contract.support_clause_digest = dynamic_manifest.canonical_digest();
  }
  const PreviewPoliciesV1 dynamic_policies{
      PointDeploymentPolicyV1::deploy_raw_point,
      CoefficientCompletionPolicyV1::require_complete_raw_points,
      ProjectionPolicyV1::not_applicable,
      RecodingPolicyV1::not_applicable,
      EvidenceRolePolicyV1::exact_manifest_roles};
  auto dynamic_contract = C15ProtocolFixtureFactory::accepted_contract(
      dynamic_provider, dynamic_core, dynamic_manifest,
      scenario.contract.requirements(),
      scenario.contract.arrival_capabilities(), std::move(metric_contracts),
      std::vector<QueueId>(
          scenario.contract.construction_target_scope().begin(),
          scenario.contract.construction_target_scope().end()),
      dynamic_policies,
      scenario.contract.construction_prerequisites(),
      scenario.view.canonical_digest().value(),
      scenario.parameters.canonical_value_digest(),
      scenario.contract.budget_digest());
  scenario.contract = std::move(dynamic_contract);
  auto validated_dynamic_manifest =
      validate_provider_manifest(dynamic_provider);
  REQUIRE(validated_dynamic_manifest);
  scenario.manifest = std::move(validated_dynamic_manifest).value();
  auto dynamic_request = make_surrogate_build_request(
      scenario.manifest, scenario.view, scenario.contract,
      scenario.parameters, scenario.budget, MasterSeed{0xC1707U});
  REQUIRE(dynamic_request);
  scenario.request = std::move(dynamic_request).value();

  descriptor.core = dynamic_core;
  auto descriptor_digest = canonical_plug_descriptor_digest_v1(descriptor);
  REQUIRE(descriptor_digest);
  descriptor.descriptor_digest = std::move(descriptor_digest).value();

  const auto* baseline_portable =
      std::get_if<PortableThreeBinScalarResponseV1>(
          &carried.payload.value());
  REQUIRE(baseline_portable != nullptr);
  PortablePayloadContextV1 context = baseline_portable->context;
  context.payload_class = dynamic_core.payload_class;
  context.build_identity_digest =
      scenario.request.build_identity_digest().digest();
  context.request_digest = scenario.request.request_digest().value();
  context.family_evidence.clear();
  context.scoped_evidence.clear();
  context.structural_manifest_echo = {
      1U,
      std::move(canonical_metric_support_manifest_bytes_v1(dynamic_manifest))
          .value(),
      dynamic_manifest.canonical_digest()};

  const QueueId target = dynamic_core.deployed_targets.front();
  const auto raw_product_id =
      C15ProtocolFixtureFactory::raw_response_product_id(
          {label("c17.fixture.finite-prefix.raw"),
           digest("c17.fixture.finite-prefix.raw")});
  std::vector<FinitePrefixCoefficientIdentificationV1> identifications;
  std::vector<FinitePrefixResponseCoordinateV1> covered_coordinates;
  std::vector<PortableScientificScalar> interval_lower;
  std::vector<PortableScientificScalar> interval_upper;
  identifications.reserve(cutoff + 2U);
  covered_coordinates.reserve(cutoff + 2U);
  interval_lower.reserve(cutoff + 2U);
  interval_upper.reserve(cutoff + 2U);
  const auto& conformance_anchor = scenario.manifest.value()
                                       .family_evidence_conformance_report_anchors
                                       .front();
  const ProviderConformanceReportRef conformance{
      conformance_anchor.report_schema_version,
      conformance_anchor.report_id,
      conformance_anchor.report_digest,
      scenario.provider.identity(),
      scenario.manifest.scientific_contract_digest().value(),
      conformance_anchor.family_evidence_schema_id,
      conformance_anchor.family_evidence_schema_version};
  for (std::size_t level = 0U; level <= cutoff; ++level) {
    const ExactRational& point = service_by_level[level];
    const FinitePrefixResponseCoordinateV1 coordinate{
        level == 0U
            ? FinitePrefixResponseCoordinateKindV1::structural_level_zero
            : FinitePrefixResponseCoordinateKindV1::exact_level,
        BigNat{level}};
    identifications.push_back({
        {label("c17.fixture.finite-prefix.coefficient." +
               std::to_string(level)),
         digest("c17.fixture.finite-prefix.coefficient." +
                std::to_string(level))},
        coordinate,
        PortableScientificScalar::rational(ExactRational::one() - point),
        PortableScientificScalar::rational(point),
        PortableScientificScalar::rational(point),
        {},
        conformance});
    covered_coordinates.push_back(coordinate);
    interval_lower.push_back(PortableScientificScalar::rational(point));
    interval_upper.push_back(PortableScientificScalar::rational(point));
  }
  const FinitePrefixResponseCoordinateV1 tail_coordinate{
      FinitePrefixResponseCoordinateKindV1::constant_tail,
      BigNat{cutoff + 1U}};
  identifications.push_back({
      {label("c17.fixture.finite-prefix.coefficient.tail"),
       digest("c17.fixture.finite-prefix.coefficient.tail")},
      tail_coordinate,
      PortableScientificScalar::rational(
          ExactRational::one() - constant_tail_service),
      PortableScientificScalar::rational(constant_tail_service),
      PortableScientificScalar::rational(constant_tail_service),
      {},
      conformance});
  covered_coordinates.push_back(tail_coordinate);
  interval_lower.push_back(
      PortableScientificScalar::rational(constant_tail_service));
  interval_upper.push_back(
      PortableScientificScalar::rational(constant_tail_service));
  const Digest256 proposal_law_digest =
      digest("c17.fixture.finite-prefix.proposal-law");
  FinitePrefixRawResponseProductV1 raw{
      raw_product_id,
      scenario.provider.identity(),
      scenario.request.request_digest().value(),
      target,
      scenario.view.fingerprints().compiled_arrival,
      proposal_law_digest,
      BigNat{cutoff},
      BigNat{8U},
      BigNat{16U},
      std::move(identifications)};
  const ArtifactObjectReferenceV1 raw_envelope_identity{
      label("c17.fixture.finite-prefix.raw-envelope"),
      digest("c17.fixture.finite-prefix.raw-envelope")};
  FinitePrefixRawResponseEnvelopeV1 raw_envelope{
      raw_envelope_identity,
      raw_product_id,
      proposal_law_digest,
      BigNat{cutoff},
      std::move(covered_coordinates),
      std::move(interval_lower),
      std::move(interval_upper),
      PortableScientificScalar::rational(ExactRational::zero()),
      PortableScientificScalar::rational(ExactRational::zero()),
      PortableScientificScalar::rational(ExactRational::zero()),
      "c17.fixture.finite-prefix.exact-interval",
      RawEnvelopeCoverageV1::simultaneous,
      PopulationConditioningPremiseV1::unconditional,
      label("c17.fixture.finite-prefix.evaluation"),
      BigNat{8U},
      RawEnvelopeScopeV1::proposal_raw,
      {}};
  FinitePrefixConstantTailResponseV1 normalized{
      1U,
      {label("c17.fixture.finite-prefix.response"),
       digest("c17.fixture.finite-prefix.response")},
      target,
      scenario.view.fingerprints().compiled_arrival,
      BigNat{cutoff},
      std::move(raw),
      raw_product_id,
      {std::move(raw_envelope)}};

  ArtifactPayloadV1 normalized_payload{normalized};
  auto normalized_payload_digest =
      canonical_artifact_payload_digest_v1(normalized_payload);
  REQUIRE(normalized_payload_digest);
  context.payload_digest = std::move(normalized_payload_digest).value();
  context.payload_identity.object_digest = context.payload_digest;

  const ArtifactObjectReferenceV1 statistical_identity{
      label("c17.fixture.finite-prefix.statistical-evidence"),
      digest("c17.fixture.finite-prefix.statistical-evidence")};
  const ArtifactObjectReferenceV1 evaluation_identity{
      label("c17.fixture.finite-prefix.evaluation"),
      digest("c17.fixture.finite-prefix.evaluation")};
  const ArtifactObjectReferenceV1 proposal_identity{
      label("c17.fixture.finite-prefix.proposal"), proposal_law_digest};
  const ArtifactObjectReferenceV1 sampling_bank_identity{
      label("c17.fixture.finite-prefix.sampling-bank"),
      digest("c17.fixture.finite-prefix.sampling-bank")};
  const ArtifactObjectReferenceV1 sampling_probe_identity{
      label("c17.fixture.finite-prefix.sampling-probe"),
      digest("c17.fixture.finite-prefix.sampling-probe")};
  const ArtifactObjectReferenceV1 coverage_family_identity{
      label("c17.fixture.finite-prefix.coverage-family"),
      digest("c17.fixture.finite-prefix.coverage-family")};
  const ArtifactObjectReferenceV1 estimand_identity{
      label("c17.fixture.finite-prefix.estimand"),
      digest("c17.fixture.finite-prefix.estimand")};
  const ArtifactObjectReferenceV1 coefficient_origin =
      normalized.raw_response.identifications.front().coefficient_id;
  const auto internal_object = [&](const InternalPurpose purpose)
      -> ArtifactObjectReferenceV1 {
    switch (purpose) {
      case InternalPurpose::coefficient_origin:
        return coefficient_origin;
      case InternalPurpose::evaluation_identity:
        return evaluation_identity;
      case InternalPurpose::proposal_identity:
        return proposal_identity;
      case InternalPurpose::sampling_bank:
        return sampling_bank_identity;
      case InternalPurpose::sampling_probe:
        return sampling_probe_identity;
      case InternalPurpose::coverage_family:
        return coverage_family_identity;
      case InternalPurpose::estimand:
        return estimand_identity;
      default:
        FAIL("unexpected internal relation in dynamic C17 fixture");
    }
    return estimand_identity;
  };
  const auto role_object = [&](const Role role)
      -> ArtifactObjectReferenceV1 {
    switch (role) {
      case Role::deployed_payload:
        return context.payload_identity;
      case Role::deployed_response:
      case Role::raw_response:
        return raw_product_id.identity();
      case Role::raw_response_bound_evidence:
        return raw_envelope_identity;
      case Role::statistical_evidence:
        return statistical_identity;
      default:
        FAIL("unexpected role relation in dynamic C17 fixture");
    }
    return context.payload_identity;
  };
  const MetricSupportClauseV1& dynamic_clause =
      dynamic_manifest.clauses().front();
  std::vector<RealizedMetricBindingV1> dynamic_binding_entries;
  dynamic_binding_entries.reserve(dynamic_clause.required_roles.size());
  for (const auto& requirement : dynamic_clause.required_roles) {
    std::vector<RealizedRoleRelationV1> role_relations;
    role_relations.reserve(requirement.role_relations.size());
    for (const auto& relation : requirement.role_relations) {
      role_relations.push_back(
          {relation.relation,
           {dynamic_clause.clause_id, relation.other_role},
           role_object(relation.other_role)});
    }
    std::vector<RealizedInternalReferenceV1> internal_relations;
    internal_relations.reserve(requirement.internal_relations.size());
    for (const auto& relation : requirement.internal_relations) {
      internal_relations.push_back(
          {relation.relation, relation.purpose,
           internal_object(relation.purpose)});
    }
    RealizedReferenceCoreV1 core{
        {target}, requirement.target_scope, requirement.result_scope,
        requirement.evidence_scope, std::move(role_relations),
        std::move(internal_relations)};
    auto reference = [&]() -> RealizedReferenceV1 {
      switch (requirement.role) {
        case Role::deployed_payload:
          return DeployedPayloadReferenceV1{
              std::move(core), ArtifactPayloadRef{context.payload_identity}};
        case Role::deployed_response:
          return DeployedResponseReferenceV1{
              std::move(core),
              RawResponseProductRef{raw_product_id.identity(),
                                    ResponseProductValueFormV1::exact_point}};
        case Role::raw_response:
          return RawResponseProductReferenceV1{
              std::move(core),
              {raw_product_id.identity(),
               ResponseProductValueFormV1::exact_point}};
        case Role::raw_response_bound_evidence:
          return RawResponseBoundEvidenceReferenceV1{
              std::move(core),
              RawResponseBoundEvidenceRef{raw_envelope_identity}};
        case Role::statistical_evidence:
          return StatisticalEvidenceReferenceV1{
              std::move(core),
              StatisticalEvidenceRef{statistical_identity}};
        default:
          FAIL("unexpected realized role in dynamic C17 fixture");
      }
      return DeployedPayloadReferenceV1{
          std::move(core), ArtifactPayloadRef{context.payload_identity}};
    }();
    dynamic_binding_entries.push_back(
        {{dynamic_clause.clause_id, requirement.role},
         std::move(reference)});
  }
  context.realized_metric_bindings = {
      scenario.request.request_digest().value(), context.payload_digest,
      dynamic_binding_entries};
  std::vector<RealizedInternalReferenceV1> statistical_internal;
  for (const auto& relation : dynamic_roles.back().internal_relations) {
    statistical_internal.push_back(
        {relation.relation, relation.purpose,
         internal_object(relation.purpose)});
  }
  context.scoped_evidence.push_back({
      statistical_identity,
      ArtifactReferenceKindV1::statistical_evidence,
      {target},
      ResultScope::not_a_metric_result,
      EvidenceScope::raw_static_proposal,
      {estimand_identity},
      {},
      {},
      std::move(statistical_internal)});
  PortableFinitePrefixConstantTailResponseV1 portable{
      std::move(context),
      target,
      BigNat{cutoff},
      service_by_level,
      BigNat{cutoff + 1U},
      constant_tail_service,
      raw_product_id,
      std::move(normalized)};
  PortablePlugPayload payload =
      C15ProtocolFixtureFactory::portable_payload(std::move(portable));

  const auto make_access = [&]() -> KernelAccess {
    return FiniteParameterAnalyticFamilyAccess(
        {dynamic_core.state_fields.front().codec,
         {std::string(kFinitePrefixConstantTailServiceResponseCodecIdV1),
          1U}},
        {std::string(kFinitePrefixConstantTailResponseFamilyIdV1), 1U,
         {std::string(
              kFinitePrefixConstantTailResponseParameterSchemaIdV1),
          1U},
         dynamic_core.state_fields.front().codec},
        [](const CanonicalRuntimeValueV1&) {
          return Result<CanonicalRuntimeValueV1>::success(
              {{std::string(
                    kFinitePrefixConstantTailServiceResponseCodecIdV1),
                1U},
               {std::byte{0x01}}});
        });
  };
  KernelAccess embedded_access = make_access();
  SurrogatePlug raw_plug = ScalarBacklogResponsePlugV1{
      payload, std::move(embedded_access)};

  ArtifactValidationBindingsV1 artifact_bindings =
      carried.artifact.validation_bindings();
  artifact_bindings.build_identity_digest =
      scenario.request.build_identity_digest().digest();
  artifact_bindings.request_digest =
      scenario.request.request_digest().value();
  artifact_bindings.provider_scientific_contract_digest =
      scenario.manifest.scientific_contract_digest().value();
  artifact_bindings.payload_class = dynamic_core.payload_class;
  artifact_bindings.accepted_contract_digest =
      scenario.contract.contract_digest();
  artifact_bindings.requirements_digest =
      scenario.contract.requirements_digest();
  artifact_bindings.arrival_capabilities_digest =
      scenario.contract.arrival_capabilities_digest();
  artifact_bindings.preview_digest = scenario.contract.preview_digest();
  artifact_bindings.parameter_digest = scenario.contract.parameter_digest();
  artifact_bindings.budget_digest = scenario.contract.budget_digest();
  artifact_bindings.structural_manifest_digest =
      dynamic_manifest.canonical_digest();
  auto validated_plug = C17FixtureAccess::validated_plug(
      descriptor, std::move(raw_plug), std::move(artifact_bindings),
      scenario.contract.contract_digest(), dynamic_manifest);
  // Preserve the exact immutable operation owner carried by the validated
  // plug, as the production boundary does for C17's separately consumed view.
  auto audited_access = validate_kernel_access(validated_plug);
  REQUIRE(audited_access);

  const std::vector<QueueId> deployed_targets(
      dynamic_core.deployed_targets.begin(),
      dynamic_core.deployed_targets.end());
  auto realized = validate_realized_metric_bindings_v1(
      dynamic_manifest,
      RealizedBindingValidationContextV1{
          RealizedBindingTargetContextV1{
              deployed_targets,
              std::optional<QueueId>{deployed_targets.front()},
              std::vector<QueueId>(
                  scenario.contract.construction_target_scope().begin(),
                  scenario.contract.construction_target_scope().end())},
          dynamic_policies},
      dynamic_binding_entries);
  REQUIRE(realized);

  return finish_closed_scalar_framework_v1(
      std::move(scenario), std::move(validated_plug),
      std::move(audited_access).value(), std::move(descriptor),
      std::move(realized).value(), false, largest_audit_backlog,
      ExactCausalProgramModeV1::
          closed_finite_prefix_constant_tail_scalar,
      phase_override);
}

[[nodiscard]] inline ThreeBinFrameworkV1
make_finite_prefix_constant_tail_framework(
    const std::vector<ExactRational>& service_by_level,
    const ExactRational& constant_tail_service,
    const std::uint8_t largest_audit_backlog = 8U) {
  return make_finite_prefix_constant_tail_framework_from_input(
      service_by_level, constant_tail_service,
      make_alternating_three_bin_input(),
      BackendRouteKindV1::residence_or_stopped_law, std::nullopt,
      largest_audit_backlog);
}

[[nodiscard]] inline ThreeBinFrameworkV1
make_nonmonotone_three_bin_framework(
    const bool admit_hidden_unit_state = false) {
  return make_three_bin_framework_v1(
      {rational(3, 4), rational(1, 4), rational(2, 3)},
      admit_hidden_unit_state, 3U);
}

[[nodiscard]] inline ThreeBinFrameworkV1
make_positive_underflow_three_bin_framework() {
  const BigInt denominator = BigInt{1} << 20000U;
  auto epsilon = ExactRational::make(BigInt{1}, denominator);
  REQUIRE(epsilon);
  return make_three_bin_framework_v1(
      {rational(1, 2), std::move(epsilon).value(), rational(1, 2)},
      false, 3U);
}

[[nodiscard]] inline CausalBranchIdentityV1 branch(
    const std::string_view name,
    std::vector<std::size_t> atom_path = {}) {
  return {digest(name), std::move(atom_path)};
}

[[nodiscard]] inline OpportunityLawAtomV1 opportunity_atom(
    const std::string_view branch_name,
    const TargetBacklogV1& prearrival_backlog,
    const ExactRational& raw_mass,
    const bool structural_support = true,
    std::vector<std::size_t> atom_path = {},
    const std::uint8_t value_byte = 0x01U) {
  return {{branch(branch_name, std::move(atom_path)),
           prearrival_backlog,
           std::nullopt,
           std::nullopt,
           value("c17.fixture.opportunity", {value_byte}),
           {}},
          raw_mass,
          structural_support};
}

[[nodiscard]] inline RuntimeDecodedMarkV1 mark(
    const RuntimeMarkIdV1& id, const std::uint8_t value_byte) {
  return {id, value("c17.fixture.mark", {value_byte})};
}

[[nodiscard]] inline ResolvedAction action(
    const MathBaseV1& base, const CausalBranchIdentityV1& branch_identity,
    const TargetBacklogV1& prearrival_backlog,
    const std::initializer_list<std::uint8_t> schedule_bits,
    const std::uint8_t decision_byte) {
  auto selected = schedule(base.instance, schedule_bits);
  std::vector<std::uint8_t> departure_bits(base.instance.queues().size(), 0U);
  for (std::size_t target_ordinal = 0U;
       target_ordinal < prearrival_backlog.size(); ++target_ordinal) {
    const auto& target =
        prearrival_backlog.target_at_target_ordinal(target_ordinal);
    auto dense = base.instance.queues().index_at(target.ordinal());
    REQUIRE(dense);
    departure_bits[target.ordinal()] =
        selected.at(dense.value()) &&
                !prearrival_backlog
                     .value_at_target_ordinal(target_ordinal)
                     .is_zero()
            ? 1U
            : 0U;
  }
  auto departure = Schedule::from_bytes(
      QueueDimensionToken::from_instance(base.instance),
      std::move(departure_bits));
  REQUIRE(departure);
  return {branch_identity,
          selected,
          std::move(departure).value(),
          C17FixtureAccess::schedule_identity(base.instance,
                                              selected),
          {ActionResolutionKindV1::configured_maxweight, true, std::nullopt,
           std::nullopt},
          value("c17.fixture.decision", {decision_byte}),
          std::nullopt,
          std::nullopt,
          {}};
}

// A deliberately passive witness.  Production C17 records the authoritative
// per-edge stage trace; this spy only counts the stochastic-stage callbacks so
// the tests can distinguish one distributional arrival application from the
// number of atoms returned by that application.
struct SpyTrace final {
  std::vector<CausalStageV1> callback_entries;
  std::size_t arrival_applications{0U};
  std::size_t opportunity_applications{0U};
  std::size_t resolver_applications{0U};
  std::size_t postclosure_applications{0U};

  void enter(const CausalStageV1 stage) {
    callback_entries.push_back(stage);
    switch (stage) {
      case CausalStageV1::c_minus:
        ++opportunity_applications;
        break;
      case CausalStageV1::resolver:
        ++resolver_applications;
        break;
      case CausalStageV1::arrival:
        ++arrival_applications;
        break;
      case CausalStageV1::c_plus:
        ++postclosure_applications;
        break;
      case CausalStageV1::psi:
        break;
    }
  }
};

template <typename T>
concept PubliclyEnumerableLaw = requires(const T& law) { law.atoms(); };

template <typename T>
concept PubliclySampleableLaw = requires(T& law) { law.sample(); };

template <typename T>
concept NamesFreshArrival = requires(const T& context) {
  context.arrival();
};

template <typename T>
concept NamesArrivalCapability = requires(T& context) {
  context.arrival_capability();
};

template <typename T>
concept NamesV1Witness = requires(const T& report) { report.v1; };

template <typename T>
concept NamesV2Witness = requires(const T& report) { report.v2; };

template <typename T>
concept NamesPhysicalFidelity = requires(const T& report) {
  report.physical_fidelity;
};

template <typename T>
concept NamesStability = requires(const T& report) { report.stability; };

}  // namespace mwperf::testing::c17
