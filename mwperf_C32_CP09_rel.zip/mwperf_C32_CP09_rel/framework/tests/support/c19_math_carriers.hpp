#pragma once

#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/stationary/analytic.hpp"

namespace mwperf::testing::c19_math {

struct CarrierLineageSpec final {
  std::string identity;
  ConstructionMethodV1 construction_method{ConstructionMethodV1::closed_form};
  ProducerModeV1 producer_mode{ProducerModeV1::inline_immediate};
  ArrivalFamily arrival_family{ArrivalFamily::deterministic_trace};
};

struct LittleLawSpec final {
  bool lossless{true};
  bool unit_packets{true};
  bool eventual_departure{true};
  bool positive_finite_intensity{true};
  bool finite_first_backlog_moment{true};
  bool little_law{true};
};

struct ScalarSelectionSeedAtom final {
  BigNat backlog;
  ExactRational selection_mass;
};

struct ScalarCarrierSpec final {
  CarrierLineageSpec lineage;
  std::vector<ScalarArrivalMassV1> arrival_atoms;
  bool second_moment_available{true};
  bool temporal_iid{true};
  std::vector<ExactRational> service_by_level;
  std::optional<BigNat> constant_tail_from;
  std::optional<ExactRational> constant_tail_service;
  std::vector<ScalarSelectionSeedAtom> selection_seed;
  LittleLawSpec little_law;
  SelectionSpec selection;
};

struct PhaseCarrierSpec final {
  CarrierLineageSpec lineage;
  std::vector<ArrivalPhaseIdentityV1> phases;
  std::vector<ExactPhaseArrivalBlockV1> arrival_blocks;
  std::vector<ExactRational> configured_phase_marginal;
  std::vector<ExactRational> service_row_major;
  PhaseLevelCompletionV1 completion;
  SelectionSpec selection;
  SolverPolicy solver_policy;
};

using ExactFixedPointMap = std::function<Result<std::vector<ExactRational>>(
    std::span<const ExactRational>)>;

struct NamedFixedPointSolution final {
  TypedLabel id;
  std::vector<ExactRational> parameters;
};

struct FixedPointCarrierSpec final {
  CarrierLineageSpec lineage;
  std::vector<ExactRational> domain_lower;
  std::vector<ExactRational> domain_upper;
  std::vector<ExactRational> codomain_lower;
  std::vector<ExactRational> codomain_upper;
  std::vector<ExactRational> cold_initial;
  BigNat iteration_budget;
  BigNat evaluation_budget;
  bool uniqueness_declared;
  std::vector<NamedFixedPointSolution> named_solutions;
  ExactFixedPointMap map;
  SelectionSpec selection;
  SolverPolicy solver_policy;
};

[[nodiscard]] Result<Digest256> analysis_fingerprint(
    const CarrierLineageSpec& lineage);

[[nodiscard]] Result<AuditedResponseLaw> mint_scalar_response(
    ScalarCarrierSpec spec);
[[nodiscard]] Result<AuditedThreeBinResponse> mint_three_bin_response(
    ScalarCarrierSpec spec);
[[nodiscard]] Result<AuditedPhaseResponse> mint_phase_response(
    PhaseCarrierSpec spec);
[[nodiscard]] Result<AuditedFixedPointFamily> mint_fixed_point_family(
    FixedPointCarrierSpec spec);

}  // namespace mwperf::testing::c19_math
