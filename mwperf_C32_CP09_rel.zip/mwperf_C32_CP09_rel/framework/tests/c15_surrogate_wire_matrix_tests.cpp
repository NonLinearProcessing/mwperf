#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
using Json = nlohmann::ordered_json;

[[nodiscard]] mwperf::TypedLabel wire_label(const std::string& text) {
  auto value = mwperf::TypedLabel::text(text);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::QueueId wire_queue(const std::string& text) {
  return mwperf::QueueId(wire_label(text));
}

[[nodiscard]] mwperf::Digest256 wire_digest(const std::string_view text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  auto value = mwperf::sha256(bytes);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 wire_object(
    const std::string& name) {
  return {wire_label(name), wire_digest(name)};
}

[[nodiscard]] mwperf::ProviderIdentityV1 wire_provider() {
  return {"c15.wire.provider", "1.0.0"};
}

[[nodiscard]] mwperf::ExactRational wire_rational(
    const std::int64_t numerator, const std::int64_t denominator) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                            mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::PortableScientificScalar wire_scalar(
    const std::int64_t numerator, const std::int64_t denominator) {
  return mwperf::PortableScientificScalar::rational(
      wire_rational(numerator, denominator));
}

[[nodiscard]] mwperf::PortableScientificScalar wire_binary(
    const std::string_view bits) {
  auto value = mwperf::PortableScientificScalar::parse_binary64(bits);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ProviderConformanceReportRef wire_conformance() {
  return {1U,
          wire_label("c15.wire.conformance"),
          wire_digest("conformance"),
          wire_provider(),
          wire_digest("scientific-contract"),
          "c15.wire.family-evidence",
          1U};
}

[[nodiscard]] mwperf::RawResponseProductId wire_raw_id(
    const std::string& name = "raw") {
  return Factory::raw_response_product_id(wire_object(name));
}

[[nodiscard]] mwperf::NominalResponseProductId wire_nominal_id(
    const std::string& name = "nominal") {
  return Factory::nominal_response_product_id(wire_object(name));
}

[[nodiscard]] mwperf::ProjectionCenterProductId wire_center_id(
    const std::string& name = "center") {
  return Factory::projection_center_product_id(wire_object(name));
}

[[nodiscard]] mwperf::ProjectedMeanProductId wire_mean_id(
    const std::string& name = "mean") {
  return Factory::projected_mean_product_id(wire_object(name));
}

[[nodiscard]] mwperf::RecodedResponseProductId wire_recoded_id(
    const std::string& name = "recoded") {
  return Factory::recoded_response_product_id(wire_object(name));
}

struct CoefficientWireCase final {
  std::string_view name;
  mwperf::ProposalConditioningSourceV1 source;
  mwperf::PopulationConditioningStatusV1 population;
  mwperf::RawValueStatusV1 raw;
  bool carries_raw_point;
  bool carries_frozen_evaluation;
};

[[nodiscard]] mwperf::CoefficientIdentificationV1 wire_identification(
    const mwperf::ThreeBinCoefficientV1 bin,
    const CoefficientWireCase& status_case,
    const bool explicit_completion = false) {
  return {
      wire_object("coefficient-" +
                  std::to_string(static_cast<unsigned int>(bin))),
      {status_case.source, wire_scalar(1, 1),
       status_case.carries_frozen_evaluation
           ? std::optional<mwperf::TypedLabel>{
                 wire_label("c15.wire.frozen-evaluation")}
           : std::nullopt},
      {status_case.population, status_case.raw},
      status_case.carries_raw_point
          ? std::optional<mwperf::PortableScientificScalar>{wire_scalar(1, 2)}
          : std::nullopt,
      {},
      wire_conformance(),
      explicit_completion
          ? std::optional<mwperf::ArtifactObjectReferenceV1>{
                wire_object("explicit-completion-policy")}
          : std::nullopt,
      bin};
}

inline constexpr CoefficientWireCase kExactPointCase{
    "exact-positive-point",
    mwperf::ProposalConditioningSourceV1::exact_population,
    mwperf::PopulationConditioningStatusV1::proved_positive,
    mwperf::RawValueStatusV1::exact_point, true, false};

[[nodiscard]] mwperf::ResponseCoefficientTripleV1 wire_coefficients() {
  return {{{mwperf::ThreeBinCoefficientV1::one, wire_scalar(1, 4),
            wire_object("coefficient-0")},
           {mwperf::ThreeBinCoefficientV1::two, wire_scalar(3, 4),
            wire_object("coefficient-1")},
           {mwperf::ThreeBinCoefficientV1::tail_from_three,
            wire_scalar(1, 2), wire_object("coefficient-2")}}};
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 wire_three_bin(
    const CoefficientWireCase& first_case = kExactPointCase,
    const bool explicit_completion = false) {
  const auto target = wire_queue("q0");
  const auto raw_id = wire_raw_id();
  const auto nominal_id = wire_nominal_id();
  const auto center_id = wire_center_id();
  const auto mean_id = wire_mean_id();
  const auto recoded_id = wire_recoded_id();
  const auto request = wire_digest("request");
  const auto arrival = wire_digest("configured-arrival");

  const std::array<mwperf::CoefficientIdentificationV1, 3U>
      identifications{
          wire_identification(mwperf::ThreeBinCoefficientV1::one, first_case,
                              explicit_completion),
          wire_identification(mwperf::ThreeBinCoefficientV1::two,
                              kExactPointCase),
          wire_identification(mwperf::ThreeBinCoefficientV1::tail_from_three,
                              kExactPointCase)};
  const mwperf::RawResponseProductV1 raw{
      raw_id, wire_provider(), request, target, arrival,
      wire_digest("proposal-law"), identifications};
  const mwperf::NominalResponseProductV1 nominal{
      nominal_id, wire_provider(), request, target, wire_coefficients(), raw_id,
      std::nullopt, std::nullopt};
  const mwperf::ProjectionCenterProductV1 center{
      center_id,
      wire_provider(),
      request,
      {target, wire_queue("q1")},
      target,
      mwperf::ProjectionCenterSourceKindV1::decoded_raw_response,
      {wire_scalar(1, 4), wire_scalar(3, 4)},
      nominal_id,
      std::nullopt};
  const mwperf::ProjectedMeanProductV1 mean{
      mean_id,
      wire_provider(),
      request,
      {target, wire_queue("q1")},
      target,
      {wire_scalar(1, 2), wire_scalar(1, 4)},
      center_id,
      wire_object("projection-policy"),
      std::nullopt};
  const mwperf::RecodedResponseProductV1 recoded{
      recoded_id,
      wire_provider(),
      request,
      target,
      wire_coefficients(),
      mwperf::ProductDerivationKindV1::mean_inversion_recoding,
      mean_id,
      nominal_id,
      std::nullopt,
      wire_object("recoding-policy"),
      std::nullopt};
  const mwperf::RawResponseEnvelopeV1 envelope{
      wire_object("raw-envelope"),
      raw_id,
      wire_digest("proposal-law"),
      {mwperf::ThreeBinCoefficientV1::one,
       mwperf::ThreeBinCoefficientV1::two,
       mwperf::ThreeBinCoefficientV1::tail_from_three},
      {wire_scalar(0, 1), wire_scalar(0, 1), wire_scalar(0, 1)},
      {wire_scalar(1, 1), wire_scalar(1, 1), wire_scalar(1, 1)},
      "c15.wire.interval",
      mwperf::RawEnvelopeCoverageV1::deterministic,
      mwperf::PopulationConditioningPremiseV1::unconditional,
      wire_label("c15.wire.envelope-evaluation"),
      mwperf::BigNat{7U},
      mwperf::RawEnvelopeScopeV1::proposal_raw,
      {}};
  return {1U,
          wire_object("three-bin-row"),
          target,
          arrival,
          raw,
          nominal,
          center,
          mean,
          recoded,
          recoded_id,
          {envelope}};
}

[[nodiscard]] mwperf::PlugDescriptorCore wire_descriptor(
    const mwperf::PayloadClassV1 payload_class) {
  return {
      1U,
      wire_provider(),
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      payload_class,
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      {wire_queue("q0")},
      mwperf::TargetCouplingV1::scalar_target,
      {},
      {},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition, false,
       std::nullopt, mwperf::FiniteHorizonCoverageKindV1::none, std::nullopt},
      {mwperf::TailRepresentationKindV1::none, std::nullopt, std::nullopt},
      {},
      {},
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c15.wire.v0", 1U},
      {},
      {mwperf::DirectExactAccuracyV1{}},
      {mwperf::ConstructionResultScopeV1::not_a_metric_result,
       mwperf::ConstructionErrorScopeV1::none},
      wire_digest("manifest"),
      wire_digest("descriptor")};
}

[[nodiscard]] mwperf::CommonBuildReportV1 wire_report() {
  return {1U,
          wire_label("c15.wire.report"),
          wire_digest("report"),
          wire_digest("request"),
          wire_digest("budget"),
          {mwperf::WorkCounterApplicabilityV1::applicable,
           mwperf::BigNat{0U}},
          {mwperf::WorkCounterApplicabilityV1::not_applicable,
           mwperf::BigNat{0U}},
          {mwperf::WorkCounterApplicabilityV1::applicable,
           mwperf::BigNat{1U}},
          {},
          {}};
}

[[nodiscard]] mwperf::SurrogateBuildResultV1 wire_built(
    mwperf::ArtifactPayloadV1 payload) {
  const auto payload_class = mwperf::artifact_payload_class_v1(payload);
  const auto report = wire_report();
  mwperf::SurrogateArtifactV1 artifact{
      1U,
      wire_digest("request"),
      wire_provider(),
      wire_digest("scientific-contract"),
      mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      payload_class,
      wire_object("payload"),
      std::move(payload),
      wire_digest("payload"),
      {1U, {}, wire_digest("manifest")},
      {wire_digest("request"), wire_digest("payload"), {}},
      wire_descriptor(payload_class),
      report,
      {},
      {},
      {{1U,
        wire_label("c15.wire.diagnostic"),
        mwperf::ArtifactDiagnosticScopeV1::construction_integration,
        "c15.wire.diagnostic",
        "wire-only diagnostic",
        {},
        {}}},
      {std::nullopt, std::nullopt, std::nullopt, std::nullopt, std::nullopt,
       {}, {}, {}, std::nullopt, std::nullopt, std::nullopt}};
  return mwperf::BuiltSurrogateResultV1{
      {1U, wire_digest("request"), wire_provider(), report},
      std::move(artifact)};
}

[[nodiscard]] mwperf::SurrogateBuildResultV1 wire_unavailable(
    const mwperf::UnavailableReasonKindV1 kind =
        mwperf::UnavailableReasonKindV1::construction_domain_unavailable) {
  return mwperf::UnavailableSurrogateResultV1{
      {1U, wire_digest("request"), wire_provider(), wire_report()},
      {{kind, "c15.wire.unavailable", "wire-only unavailable result",
        std::nullopt, std::nullopt}},
      std::nullopt};
}

[[nodiscard]] mwperf::SurrogateBuildResultV1 wire_failed(
    const mwperf::ProviderFailureKindV1 kind =
        mwperf::ProviderFailureKindV1::construction_failure) {
  return mwperf::FailedSurrogateResultV1{
      {1U, wire_digest("request"), wire_provider(), wire_report()},
      {kind, "c15.wire.failure", "wire-only provider failure"}};
}

[[nodiscard]] mwperf::ArtifactParseLimits wire_limits() {
  return {1U << 20U, 64U, 1U << 14U, 1U << 14U, 1U << 16U, 1U << 16U,
          8U << 20U};
}

[[nodiscard]] std::vector<std::byte> wire_bytes(const std::string& text) {
  const auto bytes = std::as_bytes(std::span(text.data(), text.size()));
  return {bytes.begin(), bytes.end()};
}

[[nodiscard]] Json wire_json(const mwperf::SurrogateBuildResultV1& result) {
  auto encoded =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          result);
  REQUIRE(encoded);
  const std::string text(reinterpret_cast<const char*>(encoded.value().data()),
                         encoded.value().size());
  return Json::parse(text);
}

[[nodiscard]] mwperf::Result<mwperf::SurrogateBuildResult> parse_json(
    const Json& value) {
  const auto bytes = wire_bytes(value.dump());
  return mwperf::parse_surrogate_build_result(bytes, wire_limits());
}

void require_round_trip(const mwperf::SurrogateBuildResultV1& value) {
  const auto json = wire_json(value);
  auto decoded = parse_json(json);
  INFO((decoded ? std::string{}
                : decoded.error().code + ": " + decoded.error().message));
  REQUIRE(decoded);
  CHECK(decoded.value() == value);
}

template <std::size_t N>
void require_closed_domain(const Json& baseline, const std::string& pointer,
                           const std::array<std::string_view, N>& spellings) {
  const Json::json_pointer member(pointer);
  for (const auto spelling : spellings) {
    auto candidate = baseline;
    candidate.at(member) = std::string(spelling);
    INFO(pointer + " = " + std::string(spelling));
    auto parsed = parse_json(candidate);
    INFO((parsed ? std::string{}
                 : parsed.error().code + ": " + parsed.error().message));
    CHECK(parsed);
  }
  auto unknown = baseline;
  unknown.at(member) = "c15_unknown_closed_value";
  INFO(pointer + " = c15_unknown_closed_value");
  CHECK_FALSE(parse_json(unknown));
}

[[nodiscard]] mwperf::FiniteLawRowV1 wire_row(
    const mwperf::FiniteRowConditioningStageV1 stage) {
  return {wire_label("row"), wire_label("state"), stage,
          {{wire_label("state"), {wire_label("mark")}, wire_scalar(1, 1),
            std::nullopt}}};
}

[[nodiscard]] std::vector<mwperf::FiniteLawTableAlternativeV1>
wire_table_alternatives() {
  const auto law = wire_object("finite-law");
  const auto state = wire_label("state");
  const auto mark = wire_label("mark");
  const mwperf::ExplicitOrderedWordV1 word{
      state, mwperf::BigNat{1U}, {mark}, wire_label("terminal"), state,
      wire_scalar(1, 1)};
  const mwperf::FinitePredictiveStoppingTablesV1 predictive{
      {wire_row(mwperf::FiniteRowConditioningStageV1::stopped_continuation)},
      {wire_row(mwperf::FiniteRowConditioningStageV1::stopped_continuation)},
      {wire_row(mwperf::FiniteRowConditioningStageV1::stopped_continuation)}};
  return {
      mwperf::StationaryMarkedEdgeTableV1{
          1U, law, mwperf::FiniteTableStorageV1::dense,
          {wire_row(mwperf::FiniteRowConditioningStageV1::stationary_edge)},
          {"queue.big_nat", 1U}, {"arrival.phase", 1U},
          {"service.bit", 1U}, {"edge.mark", 1U},
          wire_digest("conditioning")},
      mwperf::StagedOpportunityFluxTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::sparse,
          {state},
          {state},
          {wire_row(mwperf::FiniteRowConditioningStageV1::prearrival)},
          {wire_row(mwperf::FiniteRowConditioningStageV1::postarrival)},
          wire_digest("arrival"),
          {"arrival.innovation", 1U},
          wire_object("update"),
          wire_object("retained"),
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::arrival}},
      mwperf::TemporalContinuationTableV1{
          1U,
          law,
          mwperf::FiniteTableStorageV1::dense,
          {wire_row(mwperf::FiniteRowConditioningStageV1::one_slot_current)},
          {mwperf::MetricRevealStageV1::predecision,
           mwperf::MetricRevealStageV1::completed_edge},
          {"arrival.phase", 1U},
          std::nullopt},
      mwperf::StoppedPathTableV1{
          1U, law, "hit", {state}, {state}, {mark}, true,
          std::vector<mwperf::ExplicitOrderedWordV1>{word}, wire_scalar(0, 1),
          {}},
      mwperf::RomrResidenceWordTableV1{
          1U, law, "event", {state}, {state}, {mark}, predictive,
          wire_scalar(0, 1), {}},
      mwperf::CoupledCommonScheduleTableV1{
          1U, law, mwperf::FiniteTableStorageV1::dense,
          {wire_row(mwperf::FiniteRowConditioningStageV1::common_schedule)},
          wire_digest("constraint"), wire_digest("tie-phase-arrival")}};
}

[[nodiscard]] mwperf::FiniteLawTablesV1 wire_finite_payload(
    mwperf::FiniteLawTableAlternativeV1 table) {
  return {1U,
          {wire_queue("q0")},
          mwperf::SemanticTagV1::stationary_marked_edge,
          mwperf::RuntimeAccessTagV1::finite_enumerated_row,
          wire_digest("configured-arrival"),
          wire_digest("selection"),
          {{wire_label("state"), {wire_scalar(0, 1)}}},
          {{wire_label("mark"), {wire_scalar(0, 1)}}},
          std::move(table)};
}

[[nodiscard]] mwperf::FiniteParameterAnalyticDataV1 wire_analytic_payload() {
  return {1U,
          "c15.wire.family",
          1U,
          "c15.wire.parameters",
          1U,
          "c15.wire.domain",
          1U,
          wire_provider(),
          {wire_queue("q0")},
          {{"theta", wire_scalar(1, 2)}},
          {{"knots", std::vector<mwperf::PortableScientificScalar>{
                         wire_scalar(0, 1), wire_binary("0x3fe0000000000000")}}},
          {{"backlog", wire_scalar(0, 1), wire_scalar(4, 1), true, true}},
          {},
          {wire_object("analytic-response")}};
}

[[nodiscard]] mwperf::RegisteredRuntimeRecipeV1 wire_recipe_payload() {
  return {1U,
          "c15.wire.recipe",
          1U,
          "c15.wire.parameters",
          1U,
          "c15.wire.state-codec",
          1U,
          "c15.wire.mark-codec",
          1U,
          wire_provider(),
          {wire_queue("q0")},
          {{"theta", wire_scalar(1, 2)}},
          {},
          {}};
}

[[nodiscard]] mwperf::ResponseEnvelopeEvidenceV1
wire_response_envelope_payload() {
  auto lower = wire_three_bin();
  auto upper = wire_three_bin();
  const auto lower_product = lower.deployed_response_product_id;
  const auto upper_product = upper.deployed_response_product_id;
  return {1U,
          {wire_queue("q0")},
          mwperf::MetricResultScopeV1::response_envelope,
          mwperf::MetricEvidenceScopeV1::raw_static_proposal,
          std::move(lower),
          std::move(upper),
          lower_product,
          upper_product,
          wire_object("comparison-domain"),
          {wire_object("comparison-evidence")},
          false,
          std::nullopt};
}

[[nodiscard]] mwperf::DirectMetricValueV1 wire_direct_value(
    const std::string& name, mwperf::PortableValueV1 value,
    const mwperf::DirectMetricValidityBasisV1 basis) {
  return {wire_object(name),
          {"metric", 0U},
          {wire_queue("q0")},
          std::move(value),
          wire_digest("request"),
          wire_digest("metric-request"),
          wire_digest("target-selection"),
          wire_digest("configured-arrival"),
          wire_digest("accepted-contract"),
          {},
          {},
          mwperf::MetricResultScopeV1::surrogate_law,
          basis,
          {}};
}

[[nodiscard]] mwperf::DirectMetricPayloadV1 wire_direct_payload() {
  return {1U,
          {wire_direct_value(
               "direct-scalar", wire_scalar(1, 2),
               mwperf::DirectMetricValidityBasisV1::exact_closed_form),
           wire_direct_value(
               "direct-vector",
               std::vector<mwperf::PortableScientificScalar>{
                   wire_scalar(0, 1), wire_binary("0x3ff0000000000000")},
               mwperf::DirectMetricValidityBasisV1::certified_bound)}};
}

[[nodiscard]] mwperf::FinitePrefixConstantTailResponseV1
wire_finite_prefix_payload() {
  using Coordinate = mwperf::FinitePrefixResponseCoordinateV1;
  using CoordinateKind = mwperf::FinitePrefixResponseCoordinateKindV1;

  const auto target = wire_queue("q0");
  const auto raw_id = wire_raw_id("finite-prefix-raw");
  const auto family = wire_object("finite-prefix-family");
  const auto request = wire_digest("request");
  const auto arrival = wire_digest("configured-arrival");
  const auto proposal = wire_digest("finite-prefix-proposal");
  const mwperf::BigNat cutoff{2U};
  const std::vector<Coordinate> coordinates{
      {CoordinateKind::structural_level_zero, mwperf::BigNat{0U}},
      {CoordinateKind::exact_level, mwperf::BigNat{1U}},
      {CoordinateKind::exact_level, mwperf::BigNat{2U}},
      {CoordinateKind::constant_tail, mwperf::BigNat{3U}}};
  const std::array<std::string_view, 4U> points{
      "0x0000000000000000", "0x3fd0000000000000",
      "0x0000000000000000", "0x3fe8000000000000"};

  std::vector<mwperf::FinitePrefixCoefficientIdentificationV1>
      identifications;
  identifications.reserve(coordinates.size());
  for (std::size_t index = 0U; index < coordinates.size(); ++index) {
    identifications.push_back(
        {wire_object("finite-prefix-coefficient-" + std::to_string(index)),
         coordinates[index], wire_binary("0x3fe0000000000000"),
         wire_binary("0x3fe0000000000000"), wire_binary(points[index]),
         {family}, wire_conformance()});
  }
  const mwperf::FinitePrefixRawResponseProductV1 raw{
      raw_id, wire_provider(), request, target, arrival, proposal, cutoff,
      mwperf::BigNat{7U}, mwperf::BigNat{11U}, std::move(identifications)};
  const mwperf::FinitePrefixRawResponseEnvelopeV1 envelope{
      wire_object("finite-prefix-envelope"),
      raw_id,
      proposal,
      cutoff,
      coordinates,
      {wire_binary("0x0000000000000000"),
       wire_binary("0x0000000000000000"),
       wire_binary("0x0000000000000000"),
       wire_binary("0x0000000000000000")},
      {wire_binary("0x0000000000000000"),
       wire_binary("0x3fe0000000000000"),
       wire_binary("0x3fd0000000000000"),
       wire_binary("0x3ff0000000000000")},
      wire_binary("0x3fc0000000000000"),
      wire_binary("0x3fc0000000000000"),
      wire_binary("0x0000000000000000"),
      "c15.wire.simultaneous-interval",
      mwperf::RawEnvelopeCoverageV1::simultaneous,
      mwperf::PopulationConditioningPremiseV1::
          conditional_on_population_positivity,
      wire_label("c15.wire.finite-prefix-evaluation"),
      mwperf::BigNat{7U},
      mwperf::RawEnvelopeScopeV1::proposal_raw,
      {family}};
  return {1U, wire_object("finite-prefix-row"), target, arrival, cutoff, raw,
          raw_id, {envelope}};
}

[[nodiscard]] std::vector<mwperf::ArtifactPayloadV1> wire_payloads() {
  auto tables = wire_table_alternatives();
  return {wire_three_bin(),
          wire_analytic_payload(),
          wire_finite_payload(std::move(tables.front())),
          wire_recipe_payload(),
          wire_response_envelope_payload(),
          wire_direct_payload(),
          wire_finite_prefix_payload()};
}

TEST_CASE("C15 result wire closes every payload and nested table tag",
          "[c15][wire][unit]") {
  const std::array<std::string_view, 7U> payload_tags{
      "three_bin_scalar_response_v1", "finite_parameter_analytic_data_v1",
      "finite_law_tables_v1", "registered_runtime_recipe_v1",
      "response_envelope_evidence_v1", "direct_metric_payload_v1",
      "finite_prefix_constant_tail_response_v1"};
  auto payloads = wire_payloads();
  REQUIRE(payloads.size() == payload_tags.size());
  for (std::size_t index = 0U; index < payloads.size(); ++index) {
    const auto result = wire_built(std::move(payloads[index]));
    const auto json = wire_json(result);
    CAPTURE(index);
    CHECK(json.at("artifact").at("payload").at("payload_tag") ==
          payload_tags[index]);
    require_round_trip(result);

    auto unsupported_body_version = json;
    unsupported_body_version.at("artifact")
        .at("payload")
        .at("body")
        .at("payload_version") = 2U;
    CHECK_FALSE(parse_json(unsupported_body_version));
  }

  auto three_bin = wire_json(wire_built(wire_three_bin()));
  three_bin.at("artifact").at("payload").at("payload_tag") =
      "c15_unknown_payload";
  CHECK_FALSE(parse_json(three_bin));

  const auto table_tags = std::array<std::string_view, 6U>{
      "stationary_marked_edge", "staged_opportunity_flux",
      "temporal_one_slot_continuation", "stopped_path",
      "romr_residence_word", "coupled_common_schedule"};
  auto tables = wire_table_alternatives();
  REQUIRE(tables.size() == table_tags.size());
  for (std::size_t index = 0U; index < tables.size(); ++index) {
    const auto result =
        wire_built(wire_finite_payload(std::move(tables[index])));
    const auto json = wire_json(result);
    CAPTURE(index);
    CHECK(json.at("artifact")
              .at("payload")
              .at("body")
              .at("table")
              .at("table_tag") == table_tags[index]);
    require_round_trip(result);
  }

  auto unknown_table = wire_json(wire_built(wire_finite_payload(
      wire_table_alternatives().front())));
  unknown_table.at("artifact")
      .at("payload")
      .at("body")
      .at("table")
      .at("table_tag") = "c15_unknown_table";
  CHECK_FALSE(parse_json(unknown_table));

  require_round_trip(wire_unavailable());
  require_round_trip(wire_failed());
  auto unknown_result = wire_json(wire_failed());
  unknown_result.at("kind") = "c15_unknown_result";
  CHECK_FALSE(parse_json(unknown_result));
}

TEST_CASE("C15 result wire enumerates every C15-owned closed spelling",
          "[c15][wire][unit]") {
  const auto three_bin = wire_json(wire_built(wire_three_bin()));
  require_closed_domain(
      three_bin,
      "/artifact/payload/body/raw_response/identifications/0/target_bin_binding",
      std::array<std::string_view, 3U>{"one", "two", "tail_from_three"});
  require_closed_domain(
      three_bin,
      "/artifact/payload/body/raw_response/identifications/0/proposal_conditioning/source",
      std::array<std::string_view, 2U>{"exact_population",
                                       "empirical_average"});
  require_closed_domain(
      three_bin,
      "/artifact/payload/body/raw_response/identifications/0/coefficient_status/population_conditioning_status",
      std::array<std::string_view, 4U>{
          "proved_positive", "proved_zero", "positive_with_confidence",
          "unresolved"});
  require_closed_domain(
      three_bin,
      "/artifact/payload/body/raw_response/identifications/0/coefficient_status/raw_value_status",
      std::array<std::string_view, 3U>{"exact_point", "interval_only",
                                       "absent"});
  require_closed_domain(
      three_bin, "/artifact/payload/body/projection_center/source_kind",
      std::array<std::string_view, 3U>{"decoded_raw_response",
                                       "synthetic_snapshot_mean",
                                       "explicit_fallback"});
  require_closed_domain(
      three_bin, "/artifact/payload/body/recoded_response/derivation_kind",
      std::array<std::string_view, 5U>{
          "nominal_completion", "admissibility_projection",
          "identity_recoding", "mean_inversion_recoding",
          "endpoint_completion"});
  require_closed_domain(
      three_bin, "/artifact/payload/body/raw_envelopes/0/coverage",
      std::array<std::string_view, 3U>{"deterministic", "marginal",
                                       "simultaneous"});
  require_closed_domain(
      three_bin,
      "/artifact/payload/body/raw_envelopes/0/population_conditioning_premise",
      std::array<std::string_view, 2U>{
          "unconditional", "conditional_on_population_positivity"});
  require_closed_domain(
      three_bin, "/artifact/payload/body/raw_envelopes/0/scope",
      std::array<std::string_view, 4U>{
          "proposal_raw", "optimizer_interval_raw",
          "deterministic_quadrature_raw", "physical_response_bound"});
  require_closed_domain(
      three_bin,
      "/artifact/build_report_echo/optimizer_calls/applicability",
      std::array<std::string_view, 2U>{"not_applicable", "applicable"});
  require_closed_domain(
      three_bin, "/artifact/diagnostic_components/0/scope",
      std::array<std::string_view, 9U>{
          "construction_integration", "input_bank_initialization",
          "optimizer_certification", "coefficient_sampling", "compression",
          "projection", "recoding", "solver", "physical_fidelity"});

  const auto finite = wire_json(wire_built(wire_finite_payload(
      wire_table_alternatives().front())));
  require_closed_domain(
      finite, "/artifact/payload/body/table/storage",
      std::array<std::string_view, 2U>{"dense", "sparse"});
  require_closed_domain(
      finite,
      "/artifact/payload/body/table/joint_edge_rows/0/conditioning_stage",
      std::array<std::string_view, 7U>{
          "stationary_edge", "prearrival", "postarrival",
          "one_slot_current", "stopped_continuation",
          "residence_continuation", "common_schedule"});

  const auto direct = wire_json(wire_built(wire_direct_payload()));
  require_closed_domain(
      direct, "/artifact/payload/body/values/0/validity_basis",
      std::array<std::string_view, 3U>{
          "exact_closed_form", "exact_finite_enumeration",
          "certified_bound"});

  const auto unavailable = wire_json(wire_unavailable());
  require_closed_domain(
      unavailable, "/reasons/0/kind",
      std::array<std::string_view, 8U>{
          "inapplicable_target_structure", "coefficient_proved_zero",
          "coefficient_unresolved", "interval_only_without_authorized_point",
          "unmet_construction_assumption", "construction_domain_unavailable",
          "required_evidence_unavailable",
          "realized_capability_narrower_than_accepted"});

  const auto failed = wire_json(wire_failed());
  require_closed_domain(
      failed, "/failure/kind",
      std::array<std::string_view, 4U>{
          "construction_failure", "resource_exhausted",
          "invariant_violation", "provider_internal_error"});
}

TEST_CASE("C15 typed response-product stages exhaust the wire vocabulary",
          "[c15][wire][unit]") {
  const auto json = wire_json(wire_built(wire_three_bin()));
  const std::array<std::pair<std::string_view, std::string_view>, 5U> stages{{
      {"/artifact/payload/body/raw_response/product_id/stage", "raw_response"},
      {"/artifact/payload/body/nominal_response/product_id/stage",
       "nominal_response"},
      {"/artifact/payload/body/projection_center/product_id/stage",
       "projection_center"},
      {"/artifact/payload/body/projected_mean/product_id/stage",
       "projected_mean"},
      {"/artifact/payload/body/recoded_response/product_id/stage",
       "recoded_response"},
  }};
  for (const auto& [pointer, spelling] : stages) {
    const Json::json_pointer member{std::string(pointer)};
    CAPTURE(pointer, spelling);
    CHECK(json.at(member) == spelling);
    auto unknown = json;
    unknown.at(member) = "c15_unknown_product_stage";
    CHECK_FALSE(parse_json(unknown));
  }
  require_round_trip(wire_built(wire_three_bin()));
}

TEST_CASE("C15 F04 parses all six coefficient shapes without doing F06 math",
          "[c15][wire][unit]") {
  const std::array<CoefficientWireCase, 6U> cases{{
      kExactPointCase,
      {"exact-positive-interval",
       mwperf::ProposalConditioningSourceV1::exact_population,
       mwperf::PopulationConditioningStatusV1::proved_positive,
       mwperf::RawValueStatusV1::interval_only, false, false},
      {"empirical-confidence-interval",
       mwperf::ProposalConditioningSourceV1::empirical_average,
       mwperf::PopulationConditioningStatusV1::positive_with_confidence,
       mwperf::RawValueStatusV1::interval_only, false, true},
      {"unresolved-interval",
       mwperf::ProposalConditioningSourceV1::exact_population,
       mwperf::PopulationConditioningStatusV1::unresolved,
       mwperf::RawValueStatusV1::interval_only, false, false},
      {"exact-zero-absent",
       mwperf::ProposalConditioningSourceV1::exact_population,
       mwperf::PopulationConditioningStatusV1::proved_zero,
       mwperf::RawValueStatusV1::absent, false, false},
      {"unresolved-absent",
       mwperf::ProposalConditioningSourceV1::exact_population,
       mwperf::PopulationConditioningStatusV1::unresolved,
       mwperf::RawValueStatusV1::absent, false, false},
  }};
  for (const auto& status_case : cases) {
    CAPTURE(status_case.name);
    require_round_trip(wire_built(wire_three_bin(status_case)));
  }

  // This tuple consists entirely of legal wire enum values.  F-C15-04 must
  // preserve it so F-C15-06, the sole semantic validator, can diagnose the
  // forbidden empirical/proved-zero cross-product.
  const CoefficientWireCase forbidden{
      "empirical-proved-zero-absent",
      mwperf::ProposalConditioningSourceV1::empirical_average,
      mwperf::PopulationConditioningStatusV1::proved_zero,
      mwperf::RawValueStatusV1::absent, false, true};
  require_round_trip(wire_built(wire_three_bin(forbidden)));
}

TEST_CASE("C15 explicit completion is invariant and implicit completion is not wire data",
          "[c15][wire][unit]") {
  const CoefficientWireCase unresolved{
      "unresolved-absent",
      mwperf::ProposalConditioningSourceV1::exact_population,
      mwperf::PopulationConditioningStatusV1::unresolved,
      mwperf::RawValueStatusV1::absent, false, false};
  const auto value = wire_built(wire_three_bin(unresolved, true));
  auto parsed = parse_json(wire_json(value));
  REQUIRE(parsed);
  const auto& built = std::get<mwperf::BuiltSurrogateResultV1>(parsed.value());
  const auto& response =
      std::get<mwperf::ThreeBinScalarResponseV1>(built.artifact.payload);
  const auto& coefficient = response.raw_response.identifications.front();
  CHECK(coefficient.coefficient_status.population_conditioning_status ==
        mwperf::PopulationConditioningStatusV1::unresolved);
  CHECK(coefficient.coefficient_status.raw_value_status ==
        mwperf::RawValueStatusV1::absent);
  CHECK_FALSE(coefficient.raw_point.has_value());
  CHECK(coefficient.completion_policy_id.has_value());

  auto implicit = wire_json(value);
  implicit.at("artifact")
      .at("payload")
      .at("body")
      .at("raw_response")
      .at("identifications")
      .at(0U)["implicit_completion"] = true;
  CHECK_FALSE(parse_json(implicit));

  auto null_completion = wire_json(value);
  null_completion.at("artifact")
      .at("payload")
      .at("body")
      .at("raw_response")
      .at("identifications")
      .at(0U)
      .at("completion_policy_id") = nullptr;
  CHECK_FALSE(parse_json(null_completion));
}

TEST_CASE("C15 scalar and exact-integer wire grammars are exhaustive",
          "[c15][wire][unit]") {
  const std::array<std::pair<std::string_view, std::string_view>, 3U>
      rationals{{{"3", "7"}, {"-3", "7"}, {"0", "1"}}};
  for (const auto& [numerator, denominator] : rationals) {
    CAPTURE(numerator, denominator);
    CHECK(mwperf::PortableScientificScalar::parse_rational(numerator,
                                                            denominator));
  }
  const std::array<std::string_view, 6U> binary64{
      "0x0000000000000000", "0x0000000000000001",
      "0x0010000000000000", "0x3ff0000000000000",
      "0xbff0000000000000", "0x7fefffffffffffff"};
  for (const auto bits : binary64) {
    CAPTURE(bits);
    CHECK(mwperf::PortableScientificScalar::parse_binary64(bits));
  }

  const std::array<std::pair<std::string_view, std::string_view>, 9U>
      invalid_rationals{{{"2", "4"},
                         {"+1", "2"},
                         {"01", "2"},
                         {"-0", "1"},
                         {"1", "0"},
                         {"1", "-2"},
                         {"1", "+2"},
                         {"1", "02"},
                         {"", "1"}}};
  for (const auto& [numerator, denominator] : invalid_rationals) {
    CAPTURE(numerator, denominator);
    CHECK_FALSE(mwperf::PortableScientificScalar::parse_rational(
        numerator, denominator));
  }
  const std::array<std::string_view, 9U> invalid_binary64{
      "0X3ff0000000000000", "0x3FF0000000000000",
      "0x000000000000000", "0x00000000000000000",
      "0x8000000000000000", "0x7ff0000000000000",
      "0xfff0000000000000", "0x7ff8000000000000",
      "0x000000000000000g"};
  for (const auto bits : invalid_binary64) {
    CAPTURE(bits);
    CHECK_FALSE(mwperf::PortableScientificScalar::parse_binary64(bits));
  }

  auto scalar_wire = wire_json(wire_built(wire_three_bin()));
  auto& raw_point = scalar_wire.at("artifact")
                        .at("payload")
                        .at("body")
                        .at("raw_response")
                        .at("identifications")
                        .at(0U)
                        .at("raw_point");
  raw_point = Json{{"kind", "binary64"}, {"bits", "0x0000000000000001"}};
  CHECK(parse_json(scalar_wire));
  raw_point = Json{{"kind", "decimal"}, {"value", "0.5"}};
  CHECK_FALSE(parse_json(scalar_wire));
  raw_point = Json{{"kind", "rational"},
                   {"numerator", 1},
                   {"denominator", "2"}};
  CHECK_FALSE(parse_json(scalar_wire));
  raw_point = Json{{"kind", "rational"},
                   {"numerator", "1"},
                   {"denominator", "2"},
                   {"decimal", "0.5"}};
  CHECK_FALSE(parse_json(scalar_wire));

  const auto report_wire = wire_json(wire_built(wire_three_bin()));
  const Json::json_pointer used(
      "/artifact/build_report_echo/optimizer_calls/used");
  for (const auto value : std::array<std::string_view, 3U>{
           "0", "1", "18446744073709551616000000000000000000"}) {
    auto candidate = report_wire;
    candidate.at(used) = std::string(value);
    CAPTURE(value);
    CHECK(parse_json(candidate));
  }
  for (const auto value : std::array<std::string_view, 5U>{
           "00", "+1", "-1", "1.0", "1e3"}) {
    auto candidate = report_wire;
    candidate.at(used) = std::string(value);
    CAPTURE(value);
    CHECK_FALSE(parse_json(candidate));
  }
  auto numeric_integer = report_wire;
  numeric_integer.at(used) = 1U;
  CHECK_FALSE(parse_json(numeric_integer));
}

TEST_CASE("C15 payload and protocol versions reject every non-v1 value",
          "[c15][wire][unit]") {
  const auto baseline = wire_json(wire_built(wire_three_bin()));
  const std::array<std::string_view, 5U> version_paths{
      "/envelope/protocol_version", "/artifact/artifact_protocol_version",
      "/artifact/payload_class/version",
      "/artifact/payload/body/payload_version",
      "/artifact/deployed_descriptor/schema_version"};
  for (const auto path : version_paths) {
    auto candidate = baseline;
    candidate.at(Json::json_pointer(std::string(path))) = 2U;
    CAPTURE(path);
    CHECK_FALSE(parse_json(candidate));
  }

  auto unknown_class = baseline;
  unknown_class.at("artifact").at("payload_class").at("tag") =
      "c15_unknown_payload_class";
  CHECK_FALSE(parse_json(unknown_class));
}

TEST_CASE("C15 portable values and stopping representations close their tags",
          "[c15][wire][unit]") {
  const auto direct = wire_json(wire_built(wire_direct_payload()));
  CHECK(direct.at("artifact")
            .at("payload")
            .at("body")
            .at("values")
            .at(0U)
            .at("value")
            .at("kind") == "scalar");
  CHECK(direct.at("artifact")
            .at("payload")
            .at("body")
            .at("values")
            .at(1U)
            .at("value")
            .at("kind") == "vector");
  require_round_trip(wire_built(wire_direct_payload()));
  auto unknown_value = direct;
  unknown_value.at("artifact")
      .at("payload")
      .at("body")
      .at("values")
      .at(0U)
      .at("value")
      .at("kind") = "c15_unknown_portable_value";
  CHECK_FALSE(parse_json(unknown_value));

  auto tables = wire_table_alternatives();
  auto explicit_stopped = std::get<mwperf::StoppedPathTableV1>(tables.at(3U));
  const auto explicit_json = wire_json(
      wire_built(wire_finite_payload(explicit_stopped)));
  CHECK(explicit_json.at("artifact")
            .at("payload")
            .at("body")
            .at("table")
            .at("representation")
            .at("kind") == "explicit_words");
  require_round_trip(wire_built(wire_finite_payload(explicit_stopped)));

  explicit_stopped.representation = mwperf::FinitePredictiveStoppingTablesV1{
      {wire_row(mwperf::FiniteRowConditioningStageV1::stopped_continuation)},
      {}, {}};
  const auto predictive_json = wire_json(
      wire_built(wire_finite_payload(explicit_stopped)));
  CHECK(predictive_json.at("artifact")
            .at("payload")
            .at("body")
            .at("table")
            .at("representation")
            .at("kind") == "finite_predictive");
  require_round_trip(wire_built(wire_finite_payload(explicit_stopped)));

  auto unknown_representation = predictive_json;
  unknown_representation.at("artifact")
      .at("payload")
      .at("body")
      .at("table")
      .at("representation")
      .at("kind") = "c15_unknown_stopping_representation";
  CHECK_FALSE(parse_json(unknown_representation));
}

}  // namespace
