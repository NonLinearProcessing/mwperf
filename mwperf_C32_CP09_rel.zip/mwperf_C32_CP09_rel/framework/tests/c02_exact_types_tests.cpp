#include <bit>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/model/typed_label.hpp"

namespace {

[[nodiscard]] mwperf::BigNat nat_from(mwperf::BigInt value) {
  auto result = mwperf::BigNat::from_big_int(std::move(value));
  REQUIRE(result.has_value());
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational rational_from(const std::string& text) {
  auto result =
      mwperf::parse_decimal_rational(mwperf::NumericLexeme(text));
  REQUIRE(result.has_value());
  return std::move(result).value();
}

[[nodiscard]] mwperf::Result<mwperf::BigNat> parse_nat(
    const std::string& text,
    mwperf::BoundPolicy policy = mwperf::BoundPolicy::unbounded()) {
  return mwperf::parse_exact_nonnegative_integer(mwperf::JsonNumber(text),
                                                 std::move(policy));
}

}  // namespace

static_assert(!std::is_default_constructible_v<mwperf::BigNat>);
static_assert(!std::is_default_constructible_v<mwperf::ExactRational>);
static_assert(
    !std::is_default_constructible_v<mwperf::PortableScientificScalar>);
static_assert(!std::is_convertible_v<mwperf::BigNat, std::size_t>);
static_assert(!std::is_constructible_v<mwperf::BigNat, int>);
static_assert(!std::is_constructible_v<mwperf::BigNat, bool>);
static_assert(!std::is_default_constructible_v<mwperf::JsonValue>);
static_assert(!std::is_default_constructible_v<mwperf::TypedLabel>);
static_assert(!std::is_default_constructible_v<mwperf::QueueId>);
static_assert(!std::is_convertible_v<mwperf::TypedLabel, mwperf::QueueId>);
static_assert(!std::is_constructible_v<mwperf::PortId, mwperf::QueueId>);
using QueueProtocolAlias = mwperf::StrongId<"queue">;
using OtherProtocolDomain = mwperf::StrongId<"queue-other">;
static_assert(std::same_as<QueueProtocolAlias, mwperf::QueueId>);
static_assert(!std::same_as<OtherProtocolDomain, mwperf::QueueId>);

TEST_CASE("BigNat construction and canonical magnitude are exact",
          "[c02][unit][exact]") {
  const mwperf::BigNat zero(0U);
  CHECK(zero.to_decimal_string() == "0");
  CHECK(zero.bit_length() == 0U);
  CHECK(zero.canonical_magnitude_bytes() == std::vector<std::uint8_t>{0U});

  const mwperf::BigNat multi = nat_from(mwperf::BigInt("1193046"));
  CHECK(multi.to_decimal_string() == "1193046");
  CHECK(multi.canonical_magnitude_bytes() ==
        std::vector<std::uint8_t>{0x12U, 0x34U, 0x56U});

  mwperf::BigNat move_source = multi;
  const mwperf::BigNat moved(std::move(move_source));
  CHECK(move_source.is_zero());
  CHECK(moved == multi);
  mwperf::BigNat move_assigned(1U);
  move_assigned = std::move(move_source = multi);
  CHECK(move_source.is_zero());
  CHECK(move_assigned == multi);

  const auto negative = mwperf::BigNat::from_big_int(-1);
  REQUIRE_FALSE(negative.has_value());
  CHECK(negative.error().code == "big_nat_negative");

  mwperf::BigNat arithmetic(7U);
  arithmetic += mwperf::BigNat(5U);
  arithmetic *= mwperf::BigNat(3U);
  ++arithmetic;
  CHECK(arithmetic.to_decimal_string() == "37");
  CHECK(mwperf::checked_subtract(arithmetic, mwperf::BigNat(2U))
            .value()
            .to_decimal_string() == "35");
  const auto underflow =
      mwperf::checked_subtract(mwperf::BigNat(1U), mwperf::BigNat(2U));
  REQUIRE_FALSE(underflow.has_value());
  CHECK(underflow.error().code == "big_nat_subtraction_negative");
}

TEST_CASE("exact nonnegative integer parsing is algebraic",
          "[c02][unit][exact]") {
  CHECK(parse_nat("0").value() == mwperf::BigNat(0U));
  CHECK(parse_nat("12e3").value().to_decimal_string() == "12000");
  CHECK(parse_nat("1200e-2").value().to_decimal_string() == "12");
  CHECK(parse_nat("1.000e+2").value().to_decimal_string() == "100");
  CHECK(parse_nat("0.000e-999999999999999999999999")
            .value()
            .is_zero());

  const std::string beyond_u64 = "340282366920938463463374607431768211456";
  const auto huge = parse_nat(beyond_u64);
  REQUIRE(huge.has_value());
  CHECK(huge.value().to_decimal_string() == beyond_u64);

  for (std::uint64_t value = 0U; value < 1000U; ++value) {
    const std::string encoded = std::to_string(value);
    const auto parsed = parse_nat(encoded);
    REQUIRE(parsed.has_value());
    CHECK(parsed.value().to_decimal_string() == encoded);
  }
}

TEST_CASE("integer parsing rejects every non-natural input class",
          "[c02][negative][exact]") {
  const auto boolean = mwperf::parse_exact_nonnegative_integer(
      mwperf::JsonNumber::boolean(true), mwperf::BoundPolicy::unbounded());
  REQUIRE_FALSE(boolean.has_value());
  CHECK(boolean.error().code == "integer_boolean");

  const auto other = mwperf::parse_exact_nonnegative_integer(
      mwperf::JsonNumber::other("1"), mwperf::BoundPolicy::unbounded());
  REQUIRE_FALSE(other.has_value());
  CHECK(other.error().code == "integer_wrong_type");

  for (const std::string text : {"-1", "-0", "1.5", "1e-1", "",
                                 "+1", "01", "1.", ".1", "NaN",
                                 "Infinity", "0x10", "1_000", "1:20"}) {
    const auto result = parse_nat(text);
    INFO(text);
    REQUIRE_FALSE(result.has_value());
  }
}

TEST_CASE("integer mathematical and resource bounds are distinct",
          "[c02][unit][negative][exact]") {
  mwperf::BoundPolicy mathematical;
  mathematical.mathematical_maximum = mwperf::BigNat(99U);
  const auto math_failure = parse_nat("100", mathematical);
  REQUIRE_FALSE(math_failure.has_value());
  CHECK(math_failure.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(math_failure.error().code == "integer_mathematical_bound_exceeded");

  mwperf::BoundPolicy digits;
  digits.maximum_decimal_digits = 3U;
  const auto digit_failure = parse_nat("1e3", digits);
  REQUIRE_FALSE(digit_failure.has_value());
  CHECK(digit_failure.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(digit_failure.error().code ==
        "integer_decimal_digit_budget_exceeded");

  mwperf::BoundPolicy bits;
  bits.maximum_bits = 8U;
  CHECK(parse_nat("255", bits).has_value());
  const auto bit_failure = parse_nat("256", bits);
  REQUIRE_FALSE(bit_failure.has_value());
  CHECK(bit_failure.error().code == "integer_bit_budget_exceeded");

  mwperf::BoundPolicy exponent_budget;
  exponent_budget.maximum_decimal_digits = 10U;
  const auto exponent_failure =
      parse_nat("1e1000000000", exponent_budget);
  REQUIRE_FALSE(exponent_failure.has_value());
  CHECK(exponent_failure.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(exponent_failure.error().code ==
        "integer_decimal_digit_budget_exceeded");
}

TEST_CASE("checked_index separates native representation from domain range",
          "[c02][unit][negative][exact]") {
  CHECK(mwperf::checked_index(mwperf::BigNat(0U), 1U).value() == 0U);
  CHECK(mwperf::checked_index(mwperf::BigNat(4U), 5U).value() == 4U);

  const auto empty = mwperf::checked_index(mwperf::BigNat(0U), 0U);
  REQUIRE_FALSE(empty.has_value());
  CHECK(empty.error().code == "index_out_of_range");

  const auto upper = mwperf::checked_index(mwperf::BigNat(5U), 5U);
  REQUIRE_FALSE(upper.has_value());
  CHECK(upper.error().code == "index_out_of_range");

  const mwperf::BigNat native_max = nat_from(
      mwperf::BigInt(std::numeric_limits<std::size_t>::max()));
  const auto max_at_same_upper = mwperf::checked_index(
      native_max, std::numeric_limits<std::size_t>::max());
  REQUIRE_FALSE(max_at_same_upper.has_value());
  CHECK(max_at_same_upper.error().code == "index_out_of_range");

  const mwperf::BigNat above_native = nat_from(
      mwperf::BigInt(std::numeric_limits<std::size_t>::max()) + 1);
  const auto representation = mwperf::checked_index(above_native, 1U);
  REQUIRE_FALSE(representation.has_value());
  CHECK(representation.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(representation.error().code == "index_not_representable");
}

TEST_CASE("decimal rational parser preserves exact authored value",
          "[c02][unit][property][exact]") {
  const mwperf::ExactRational expected = rational_from("1.25");
  CHECK(expected.numerator() == 5);
  CHECK(expected.denominator() == 4);
  CHECK(rational_from("125e-2") == expected);
  CHECK(rational_from("0.0125e2") == expected);
  CHECK(rational_from("-0").to_canonical_string() == "0/1");
  CHECK(rational_from("-12.50e-1").to_canonical_string() == "-5/4");

  const mwperf::ExactRational left = rational_from("0.1");
  const mwperf::ExactRational touching = rational_from("0.10000000000000000000");
  const mwperf::ExactRational greater =
      rational_from("0.10000000000000000001");
  CHECK(left == touching);
  CHECK(left < greater);
  CHECK(left <= touching);

  for (int numerator = -25; numerator <= 25; ++numerator) {
    for (int denominator = 1; denominator <= 12; ++denominator) {
      auto value = mwperf::ExactRational::make(numerator, denominator);
      REQUIRE(value.has_value());
      auto reparsed = mwperf::PortableScientificScalar::parse_rational(
          value.value().numerator_decimal(),
          value.value().denominator_decimal());
      REQUIRE(reparsed.has_value());
      CHECK(reparsed.value().rational_value() == value.value());
    }
  }
}

TEST_CASE("malformed decimal rationals and zero denominator are rejected",
          "[c02][negative][exact]") {
  for (const std::string text : {"", "+1", "01", ".5", "1.", "1e",
                                 "0x1", "1,5", "1_2", "1:20", "NaN",
                                 "Infinity", "-Infinity"}) {
    const auto result =
        mwperf::parse_decimal_rational(mwperf::NumericLexeme(text));
    INFO(text);
    REQUIRE_FALSE(result.has_value());
  }
  const auto invalid = mwperf::ExactRational::make(1, 0);
  REQUIRE_FALSE(invalid.has_value());
  CHECK(invalid.error().code == "rational_zero_denominator");
  const auto divide_zero = mwperf::checked_divide(
      mwperf::ExactRational::one(), mwperf::ExactRational::zero());
  REQUIRE_FALSE(divide_zero.has_value());
  CHECK(divide_zero.error().code == "rational_division_by_zero");
}

TEST_CASE("rational resource policy rejects expansion before allocation",
          "[c02][unit][negative][exact]") {
  mwperf::RationalBoundPolicy decimal_policy;
  decimal_policy.maximum_decimal_digits = 32U;
  const auto huge_positive = mwperf::parse_decimal_rational(
      mwperf::NumericLexeme("1e1000000000", decimal_policy));
  REQUIRE_FALSE(huge_positive.has_value());
  CHECK(huge_positive.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(huge_positive.error().code ==
        "rational_decimal_digit_budget_exceeded");

  const auto huge_negative = mwperf::parse_decimal_rational(
      mwperf::NumericLexeme("1e-1000000000", decimal_policy));
  REQUIRE_FALSE(huge_negative.has_value());
  CHECK(huge_negative.error().code ==
        "rational_decimal_digit_budget_exceeded");

  mwperf::RationalBoundPolicy bit_policy;
  bit_policy.maximum_bits = 4U;
  CHECK(mwperf::parse_decimal_rational(
            mwperf::NumericLexeme("1e1", bit_policy))
            .has_value());
  const auto too_many_bits = mwperf::parse_decimal_rational(
      mwperf::NumericLexeme("1e2", bit_policy));
  REQUIRE_FALSE(too_many_bits.has_value());
  CHECK(too_many_bits.error().code == "rational_bit_budget_exceeded");

  // Preflight is conservative and final enforcement observes reduction.
  const auto reduced = mwperf::parse_decimal_rational(
      mwperf::NumericLexeme("1000e-3", bit_policy));
  REQUIRE(reduced.has_value());
  CHECK(reduced.value() == mwperf::ExactRational::one());
}

TEST_CASE("exact rational arithmetic remains reduced",
          "[c02][unit][property][exact]") {
  const mwperf::ExactRational half = rational_from("0.5");
  const mwperf::ExactRational third = rational_from("0.333333333333333333e0") +
                                     rational_from("0.000000000000000000333333333333333333");
  CHECK((half + half) == mwperf::ExactRational::one());
  CHECK((half * rational_from("2")) == mwperf::ExactRational::one());
  CHECK((half - mwperf::ExactRational::one()).to_canonical_string() ==
        "-1/2");
  CHECK(mwperf::absolute_value(-half) == half);
  CHECK(third > rational_from("0.333333333333333333"));
}

TEST_CASE("moving an exact rational preserves both value invariants",
          "[c02][unit][exact]") {
  mwperf::ExactRational source = rational_from("-1.25");
  const mwperf::ExactRational moved(std::move(source));
  CHECK(source.to_canonical_string() == "0/1");
  CHECK(moved.to_canonical_string() == "-5/4");

  mwperf::ExactRational movable = rational_from("-1.25");
  mwperf::ExactRational assigned = mwperf::ExactRational::zero();
  assigned = std::move(movable);
  CHECK(movable.to_canonical_string() == "0/1");
  CHECK(assigned.to_canonical_string() == "-5/4");
}

TEST_CASE("long-double image scales numerator and denominator together",
          "[c02][unit][exact]") {
  const mwperf::BigInt enormous_denominator = mwperf::BigInt(1) << 200000U;
  auto near_one = mwperf::ExactRational::make(
      enormous_denominator - 1, enormous_denominator);
  REQUIRE(near_one.has_value());
  CHECK(near_one.value().to_long_double() == 1.0L);

  auto underflow = mwperf::ExactRational::make(1, enormous_denominator);
  REQUIRE(underflow.has_value());
  CHECK(underflow.value().to_long_double() == 0.0L);
  CHECK(underflow.value().is_positive());
}

TEST_CASE("portable rational encoding is canonical and tagged",
          "[c02][unit][negative][exact]") {
  const auto exact = mwperf::PortableScientificScalar::rational(
      rational_from("0.1"));
  CHECK(exact.kind() == mwperf::PortableScientificScalarKind::rational);
  CHECK(exact.canonical_tagged_encoding() == "rational:1/10");
  CHECK(exact.canonical_bytes() ==
        std::vector<std::uint8_t>{
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, '1',
            0U, 0U, 0U, 0U, 0U, 0U, 0U, 2U, '1', '0'});

  REQUIRE(mwperf::PortableScientificScalar::parse_rational("1", "10")
              .has_value());
  for (const auto& [numerator, denominator] :
       std::vector<std::pair<std::string, std::string>>{
           {"+1", "10"}, {"01", "10"}, {"-0", "1"},
           {"2", "4"}, {"1", "01"}, {"1", "0"}, {"", "1"}}) {
    const auto result = mwperf::PortableScientificScalar::parse_rational(
        numerator, denominator);
    INFO(numerator << '/' << denominator);
    REQUIRE_FALSE(result.has_value());
  }

  mwperf::RationalBoundPolicy artifact_policy;
  artifact_policy.maximum_bits = 64U;
  REQUIRE(mwperf::PortableScientificScalar::parse_rational(
              "1", "10", artifact_policy)
              .has_value());
  const std::string oversized_denominator =
      "1" + std::string(10000U, '0');
  const auto oversized = mwperf::PortableScientificScalar::parse_rational(
      "1", oversized_denominator, artifact_policy);
  REQUIRE_FALSE(oversized.has_value());
  CHECK(oversized.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(oversized.error().code == "rational_bit_budget_exceeded");
}

TEST_CASE("portable binary64 encoding preserves finite canonical bits",
          "[c02][unit][negative][exact]") {
  const auto tenth =
      mwperf::PortableScientificScalar::from_binary64(0.1);
  REQUIRE(tenth.has_value());
  CHECK(tenth.value().kind() ==
        mwperf::PortableScientificScalarKind::binary64);
  CHECK(tenth.value().binary64_encoding() == "0x3fb999999999999a");
  CHECK(tenth.value().canonical_tagged_encoding() ==
        "binary64:0x3fb999999999999a");
  CHECK(tenth.value().canonical_bytes() ==
        std::vector<std::uint8_t>{1U, 0x3fU, 0xb9U, 0x99U, 0x99U,
                                  0x99U, 0x99U, 0x99U, 0x9aU});

  const auto reparsed = mwperf::PortableScientificScalar::parse_binary64(
      tenth.value().binary64_encoding());
  REQUIRE(reparsed.has_value());
  CHECK(reparsed.value() == tenth.value());
  CHECK_FALSE(reparsed.value() == mwperf::PortableScientificScalar::rational(
                                      rational_from("0.1")));

  const auto negative_zero =
      mwperf::PortableScientificScalar::from_binary64(-0.0);
  REQUIRE(negative_zero.has_value());
  CHECK(negative_zero.value().binary64_encoding() == "0x0000000000000000");
  CHECK(std::bit_cast<std::uint64_t>(negative_zero.value().binary64_value()) ==
        0U);

  for (const std::string text : {
           "0X3ff0000000000000", "0x3FF0000000000000",
           "0x3ff000000000000", "0x03ff00000000000000",
           "0x8000000000000000", "0x7ff0000000000000",
           "0xfff0000000000000", "0x7ff8000000000000"}) {
    const auto result =
        mwperf::PortableScientificScalar::parse_binary64(text);
    INFO(text);
    REQUIRE_FALSE(result.has_value());
  }

  CHECK_FALSE(mwperf::PortableScientificScalar::from_binary64(
                  std::numeric_limits<double>::infinity())
                  .has_value());
  CHECK_FALSE(mwperf::PortableScientificScalar::from_binary64(
                  std::numeric_limits<double>::quiet_NaN())
                  .has_value());
}

TEST_CASE("binary64 numerical conversion and range checks are explicit",
          "[c02][unit][exact]") {
  const auto half =
      mwperf::PortableScientificScalar::parse_binary64("0x3fe0000000000000");
  REQUIRE(half.has_value());
  CHECK(mwperf::binary64_as_exact_rational(half.value()) ==
        rational_from("0.5"));

  const auto smallest =
      mwperf::PortableScientificScalar::parse_binary64("0x0000000000000001");
  REQUIRE(smallest.has_value());
  const mwperf::ExactRational smallest_exact =
      mwperf::binary64_as_exact_rational(smallest.value());
  CHECK(smallest_exact > mwperf::ExactRational::zero());
  CHECK(smallest_exact.denominator() == (mwperf::BigInt(1) << 1074U));

  CHECK(mwperf::validate_in_closed_interval(
            half.value(), mwperf::ExactRational::zero(),
            mwperf::ExactRational::one())
            .has_value());
  const auto above_one =
      mwperf::PortableScientificScalar::parse_binary64("0x3ff0000000000001");
  REQUIRE(above_one.has_value());
  const auto invalid_probability = mwperf::validate_in_closed_interval(
      above_one.value(), mwperf::ExactRational::zero(),
      mwperf::ExactRational::one());
  REQUIRE_FALSE(invalid_probability.has_value());
  CHECK(invalid_probability.error().code == "portable_scalar_out_of_range");
}

TEST_CASE("typed labels preserve number versus string identity",
          "[c02][unit][label]") {
  const auto numeric =
      mwperf::parse_typed_label(mwperf::JsonValue::number("1.00e0"));
  const auto text =
      mwperf::parse_typed_label(mwperf::JsonValue::string("1"));
  REQUIRE(numeric.has_value());
  REQUIRE(text.has_value());

  CHECK(numeric.value().is_numeric());
  CHECK_FALSE(numeric.value().is_text());
  REQUIRE(numeric.value().numeric_value() != nullptr);
  CHECK(numeric.value().numeric_value()->value() == 1);
  CHECK(numeric.value().text_value() == nullptr);

  CHECK(text.value().is_text());
  CHECK_FALSE(text.value().is_numeric());
  REQUIRE(text.value().text_value() != nullptr);
  CHECK(*text.value().text_value() == "1");
  CHECK(text.value().numeric_value() == nullptr);

  CHECK_FALSE(numeric.value() == text.value());
  CHECK(numeric.value().stable_hash() != text.value().stable_hash());
  CHECK(numeric.value() < text.value());
}

TEST_CASE("numeric label parsing retains the exact-number resource policy",
          "[c02][unit][negative][label]") {
  mwperf::BoundPolicy policy;
  policy.maximum_decimal_digits = 32U;
  const auto result = mwperf::parse_typed_label(
      mwperf::JsonValue::number("1e1000000000", std::move(policy)));
  REQUIRE_FALSE(result.has_value());
  CHECK(result.error().category ==
        mwperf::DiagnosticCategory::resource_limit);
  CHECK(result.error().code ==
        "integer_decimal_digit_budget_exceeded");
}

TEST_CASE("moving typed labels and strong identifiers preserves invariants",
          "[c02][unit][label]") {
  auto text_result =
      mwperf::parse_typed_label(mwperf::JsonValue::string("alpha"));
  REQUIRE(text_result.has_value());
  mwperf::TypedLabel source = std::move(text_result).value();
  const mwperf::TypedLabel moved(std::move(source));
  CHECK(source.is_text());
  CHECK(source.text_value() != nullptr);
  CHECK(*source.text_value() == "alpha");
  CHECK(moved == source);

  auto number_result =
      mwperf::parse_typed_label(mwperf::JsonValue::number("7"));
  REQUIRE(number_result.has_value());
  mwperf::TypedLabel assigned = std::move(number_result).value();
  assigned = std::move(source);
  CHECK(source.is_text());
  CHECK(assigned == source);

  mwperf::QueueId queue_source(source);
  const mwperf::QueueId queue_moved(std::move(queue_source));
  CHECK(queue_source.label().is_text());
  CHECK(queue_moved == queue_source);
}

TEST_CASE("typed-label canonical bytes and total order are exact",
          "[c02][unit][property][label]") {
  const auto zero =
      mwperf::parse_typed_label(mwperf::JsonValue::number("0"));
  const auto multi =
      mwperf::parse_typed_label(mwperf::JsonValue::number("1193046"));
  const auto string_zero =
      mwperf::parse_typed_label(mwperf::JsonValue::string("0"));
  const auto utf8 = mwperf::parse_typed_label(
      mwperf::JsonValue::string(std::string("\xC3\xA9", 2U)));
  REQUIRE(zero.has_value());
  REQUIRE(multi.has_value());
  REQUIRE(string_zero.has_value());
  REQUIRE(utf8.has_value());

  CHECK(zero.value().canonical_bytes() ==
        std::vector<std::uint8_t>{0x00U, 0x00U});
  CHECK(multi.value().canonical_bytes() ==
        std::vector<std::uint8_t>{0x00U, 0x12U, 0x34U, 0x56U});
  CHECK(string_zero.value().canonical_bytes() ==
        std::vector<std::uint8_t>{0x01U, 0x30U});
  CHECK(utf8.value().canonical_bytes() ==
        std::vector<std::uint8_t>{0x01U, 0xC3U, 0xA9U});
  CHECK(mwperf::canonical_typed_label_bytes(multi.value()) ==
        multi.value().canonical_bytes());

  const auto two =
      mwperf::parse_typed_label(mwperf::JsonValue::number("2"));
  const auto ten =
      mwperf::parse_typed_label(mwperf::JsonValue::number("10"));
  const auto ascii_z =
      mwperf::parse_typed_label(mwperf::JsonValue::string("z"));
  REQUIRE(two.has_value());
  REQUIRE(ten.has_value());
  REQUIRE(ascii_z.has_value());
  CHECK(two.value() < ten.value());
  CHECK(ten.value() < ascii_z.value());
  CHECK(ascii_z.value() < utf8.value());
}

TEST_CASE("typed labels require valid already-trimmed UTF-8",
          "[c02][unit][negative][label]") {
  const auto empty =
      mwperf::parse_typed_label(mwperf::JsonValue::string(""));
  const auto leading_ascii =
      mwperf::parse_typed_label(mwperf::JsonValue::string(" label"));
  const auto trailing_ascii =
      mwperf::parse_typed_label(mwperf::JsonValue::string("label\t"));
  const auto leading_nbsp = mwperf::parse_typed_label(
      mwperf::JsonValue::string(std::string("\xC2\xA0x", 3U)));
  const auto trailing_ideographic = mwperf::parse_typed_label(
      mwperf::JsonValue::string(std::string("x\xE3\x80\x80", 4U)));

  REQUIRE_FALSE(empty.has_value());
  REQUIRE_FALSE(leading_ascii.has_value());
  REQUIRE_FALSE(trailing_ascii.has_value());
  REQUIRE_FALSE(leading_nbsp.has_value());
  REQUIRE_FALSE(trailing_ideographic.has_value());
  CHECK(empty.error().code == "typed_label_empty");
  CHECK(leading_ascii.error().code == "typed_label_not_trimmed");
  CHECK(trailing_ascii.error().code == "typed_label_not_trimmed");
  CHECK(leading_nbsp.error().code == "typed_label_not_trimmed");
  CHECK(trailing_ideographic.error().code == "typed_label_not_trimmed");

  for (const std::string& invalid : {
           std::string("\xC0\x80", 2U),
           std::string("\xE2\x82", 2U),
           std::string("\xED\xA0\x80", 3U),
           std::string("\xF4\x90\x80\x80", 4U),
       }) {
    const auto result =
        mwperf::parse_typed_label(mwperf::JsonValue::string(invalid));
    REQUIRE_FALSE(result.has_value());
    CHECK(result.error().code == "typed_label_invalid_utf8");
  }

  const auto interior_space =
      mwperf::parse_typed_label(mwperf::JsonValue::string("left right"));
  const auto emoji = mwperf::parse_typed_label(
      mwperf::JsonValue::string(std::string("\xF0\x9F\x98\x80", 4U)));
  REQUIRE(interior_space.has_value());
  REQUIRE(emoji.has_value());
}

TEST_CASE("typed-label parser rejects booleans and nonscalar JSON kinds",
          "[c02][unit][negative][label]") {
  const auto boolean =
      mwperf::parse_typed_label(mwperf::JsonValue::boolean(true));
  REQUIRE_FALSE(boolean.has_value());
  CHECK(boolean.error().category ==
        mwperf::DiagnosticCategory::input_validation);
  CHECK(boolean.error().code == "typed_label_boolean");

  const auto negative =
      mwperf::parse_typed_label(mwperf::JsonValue::number("-1"));
  const auto fractional =
      mwperf::parse_typed_label(mwperf::JsonValue::number("1.5"));
  REQUIRE_FALSE(negative.has_value());
  REQUIRE_FALSE(fractional.has_value());
  CHECK(negative.error().code == "integer_negative");
  CHECK(fractional.error().code == "integer_nonintegral");

  for (const mwperf::JsonValue& wrong : {
           mwperf::JsonValue::null(),
           mwperf::JsonValue::array(),
           mwperf::JsonValue::object(),
       }) {
    const auto result = mwperf::parse_typed_label(wrong);
    REQUIRE_FALSE(result.has_value());
    CHECK(result.error().code == "typed_label_wrong_type");
  }
}

TEST_CASE("strong identifiers separate domains in type and bytes",
          "[c02][unit][property][label]") {
  const auto label_result =
      mwperf::parse_typed_label(mwperf::JsonValue::number("0"));
  REQUIRE(label_result.has_value());
  const mwperf::TypedLabel label = label_result.value();

  const mwperf::QueueId queue(label);
  const mwperf::QueueId same_queue(label);
  const mwperf::PortId port(label);
  const mwperf::VertexId vertex(label);
  const mwperf::ResourceId resource(label);

  CHECK(mwperf::same_strong_id(queue, same_queue));
  CHECK_FALSE(mwperf::same_strong_id(queue, port));
  CHECK(queue.canonical_bytes() != port.canonical_bytes());
  CHECK(queue.canonical_bytes() != vertex.canonical_bytes());
  CHECK(queue.canonical_bytes() != resource.canonical_bytes());
  CHECK(queue.stable_hash() != port.stable_hash());

  const std::vector<std::uint8_t> expected_queue_zero{
      0x6dU, 0x77U, 0x70U, 0x65U, 0x72U, 0x66U, 0x2eU, 0x73U,
      0x74U, 0x72U, 0x6fU, 0x6eU, 0x67U, 0x5fU, 0x69U, 0x64U,
      0x00U, 0x00U, 0x00U, 0x00U, 0x01U,
      0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x05U,
      0x71U, 0x75U, 0x65U, 0x75U, 0x65U,
      0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x02U,
      0x00U, 0x00U};
  CHECK(queue.canonical_bytes() == expected_queue_zero);
}
