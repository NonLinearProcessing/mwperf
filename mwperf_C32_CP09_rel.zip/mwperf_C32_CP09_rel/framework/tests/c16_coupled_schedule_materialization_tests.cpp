#include <algorithm>
#include <atomic>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "support/c16_coupled_schedule_fixture.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
namespace Coupled = mwperf::testing::c16_coupled_fixture;

[[nodiscard]] mwperf::PortableFiniteLawTablesV1 portable_tables(
    const Coupled::Fixture& fixture) {
  const auto* value = std::get_if<mwperf::PortableFiniteLawTablesV1>(
      &fixture.portable_payload.value());
  REQUIRE(value != nullptr);
  return *value;
}

[[nodiscard]] mwperf::PortablePlugPayload remint_tables(
    mwperf::PortableFiniteLawTablesV1 value) {
  return Factory::portable_payload(
      mwperf::PortablePlugPayloadValueV1{std::move(value)});
}

void require_cold_rejection(
    const Coupled::Fixture& fixture,
    const mwperf::PortablePlugPayload& payload,
    const std::string_view code) {
  Coupled::reset_counters();
  auto rejected = mwperf::materialize_and_validate_surrogate_plug(
      payload, fixture.validated_artifact, fixture.scenario.contract);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == code);
  CHECK(Coupled::materializer_calls().load(std::memory_order_relaxed) == 0U);
  CHECK(Coupled::row_calls().load(std::memory_order_relaxed) == 0U);
}

}  // namespace

TEST_CASE(
    "C16 accepts one authentic multi-target common-schedule payload",
    "[c16][integration][coupled-schedule]") {
  const auto fixture = Coupled::make_fixture();
  const auto& contract = fixture.scenario.contract;
  const std::vector<mwperf::QueueId> expected{
      Coupled::queue("q0"), Coupled::queue("q1")};

  CHECK(contract.descriptor_core().deployed_targets == expected);
  CHECK(contract.descriptor_core().target_coupling ==
        mwperf::TargetCouplingV1::common_schedule_projection);
  REQUIRE(contract.structural_manifest().clauses().size() == 1U);
  const auto& clause = contract.structural_manifest().clauses().front();
  CHECK(clause.ordered_targets == expected);
  CHECK(clause.target_coupling ==
        mwperf::TargetCouplingV1::common_schedule_projection);

  const auto tables = portable_tables(fixture);
  CHECK(tables.context.ordered_deployed_targets == expected);
  CHECK(tables.normalized_record.ordered_deployed_targets == expected);
  const auto* schedule_table =
      std::get_if<mwperf::CoupledCommonScheduleTableV1>(
          &tables.normalized_record.table);
  REQUIRE(schedule_table != nullptr);
  REQUIRE(schedule_table->common_joint_rows.size() == 2U);
  const auto active = std::find_if(
      schedule_table->common_joint_rows.begin(),
      schedule_table->common_joint_rows.end(), [](const auto& row) {
        return row.conditioning_state_id == Coupled::label("c16.coupled.s11");
      });
  REQUIRE(active != schedule_table->common_joint_rows.end());
  REQUIRE(active->atoms.size() == 1U);
  REQUIRE(active->atoms.front().common_schedule.has_value());
  const auto& common = *active->atoms.front().common_schedule;
  CHECK(common.selected_full_schedule == expected);
  CHECK(common.current_target_backlogs ==
        std::vector<mwperf::BigNat>{mwperf::BigNat{1U},
                                    mwperf::BigNat{1U}});
  CHECK(common.retained_target_backlogs ==
        std::vector<mwperf::BigNat>{mwperf::BigNat{0U},
                                    mwperf::BigNat{0U}});
  CHECK(common.joint_target_departures ==
        std::vector<std::uint8_t>{1U, 1U});
  CHECK_FALSE(common.structurally_witnessed_projection);
  CHECK_FALSE(common.projection_witness.has_value());
  CHECK(schedule_table->constraint_geometry_digest ==
        fixture.scenario.view.fingerprints().constraint);

  REQUIRE(fixture.source_artifact.realized_metric_bindings.bindings.size() ==
          clause.required_roles.size());
  for (const auto& binding :
       fixture.source_artifact.realized_metric_bindings.bindings) {
    CHECK(mwperf::realized_reference_core_v1(binding.reference)
              .ordered_targets == expected);
  }
  const auto coupled_binding = std::find_if(
      fixture.source_artifact.realized_metric_bindings.bindings.begin(),
      fixture.source_artifact.realized_metric_bindings.bindings.end(),
      [](const auto& binding) {
        return binding.key.role ==
               mwperf::MetricSupportRoleV1::coupled_schedule_law;
      });
  REQUIRE(coupled_binding !=
          fixture.source_artifact.realized_metric_bindings.bindings.end());
  const auto* coupled_reference =
      std::get_if<mwperf::CoupledScheduleLawReferenceV1>(
          &coupled_binding->reference);
  REQUIRE(coupled_reference != nullptr);
  CHECK(coupled_reference->law.identity == schedule_table->law_id);
  const auto projected_schedule = std::find_if(
      coupled_reference->core.internal_relations.begin(),
      coupled_reference->core.internal_relations.end(),
      [](const auto& relation) {
        return relation.purpose ==
               mwperf::InternalReferencePurposeV1::projected_schedule;
      });
  const auto feasibility = std::find_if(
      coupled_reference->core.internal_relations.begin(),
      coupled_reference->core.internal_relations.end(),
      [](const auto& relation) {
        return relation.purpose ==
               mwperf::InternalReferencePurposeV1::feasibility_domain_codec;
      });
  REQUIRE(projected_schedule !=
          coupled_reference->core.internal_relations.end());
  REQUIRE(feasibility != coupled_reference->core.internal_relations.end());
  CHECK(projected_schedule->referenced_object ==
        Coupled::object("c16.coupled.projected-schedule"));
  CHECK(feasibility->referenced_object.object_digest ==
        fixture.scenario.view.fingerprints().constraint);

  Coupled::reset_counters();
  auto plug = mwperf::materialize_and_validate_surrogate_plug(
      fixture.portable_payload, fixture.validated_artifact, contract);
  INFO((plug ? std::string{}
             : plug.error().code + ": " + plug.error().message));
  REQUIRE(plug);
  CHECK(Coupled::materializer_calls().load(std::memory_order_relaxed) == 1U);
  CHECK(Coupled::row_calls().load(std::memory_order_relaxed) == 0U);
  CHECK(plug.value().descriptor().core.semantic ==
        mwperf::SemanticTagV1::coupled_target_schedule_law);

  auto access = mwperf::validate_kernel_access(plug.value());
  INFO((access ? std::string{}
               : access.error().code + ": " + access.error().message));
  REQUIRE(access);
  CHECK(mwperf::runtime_access_tag_v1(access.value()) ==
        mwperf::RuntimeAccessTagV1::finite_enumerated_row);
  CHECK(Coupled::row_calls().load(std::memory_order_relaxed) == 0U);
}

TEST_CASE(
    "C16 rejects missing extra and reordered coupled target bindings cold",
    "[c16][negative][coupled-schedule]") {
  const auto fixture = Coupled::make_fixture();

  SECTION("missing target") {
    auto value = portable_tables(fixture);
    value.context.ordered_deployed_targets.pop_back();
    require_cold_rejection(
        fixture, remint_tables(std::move(value)),
        "c16.materialization_binding_mismatch");
  }

  SECTION("extra target") {
    auto value = portable_tables(fixture);
    value.context.ordered_deployed_targets.push_back(Coupled::queue("q2"));
    require_cold_rejection(
        fixture, remint_tables(std::move(value)),
        "c16.materialization_binding_mismatch");
  }

  SECTION("reordered targets") {
    auto value = portable_tables(fixture);
    std::swap(value.context.ordered_deployed_targets[0U],
              value.context.ordered_deployed_targets[1U]);
    require_cold_rejection(
        fixture, remint_tables(std::move(value)),
        "c16.materialization_binding_mismatch");
  }
}

TEST_CASE("C16 rejects a multi-target ThreeBin payload separately",
          "[c16][negative][coupled-schedule]") {
  const auto designated =
      mwperf::testing::make_c16_designated_payload_fixture_v1(
          mwperf::testing::c16_designated_payload_options_v1(
              mwperf::testing::C16DesignatedResponseStageV1::raw));
  auto descriptor = designated.scenario.contract.descriptor_core();
  descriptor.deployed_targets.push_back(Coupled::queue("q1"));
  descriptor.target_coupling =
      mwperf::TargetCouplingV1::common_schedule_projection;
  descriptor.core_digest =
      std::move(mwperf::canonical_plug_descriptor_core_digest_v1(descriptor))
          .value();
  auto construction_targets = std::vector<mwperf::QueueId>(
      designated.scenario.contract.construction_target_scope().begin(),
      designated.scenario.contract.construction_target_scope().end());
  auto contract = Factory::accepted_contract(
      designated.scenario.provider.manifest().value(), descriptor,
      designated.scenario.contract.structural_manifest(),
      designated.scenario.contract.requirements(),
      designated.scenario.contract.arrival_capabilities(), {},
      std::move(construction_targets), designated.scenario.contract.policies(),
      designated.scenario.contract.construction_prerequisites(),
      designated.scenario.view.canonical_digest().value(),
      designated.scenario.parameters.canonical_value_digest(),
      designated.scenario.contract.budget_digest());

  auto source = designated.source_artifact;
  source.deployed_descriptor = descriptor;
  auto bindings = designated.validated_artifact.validation_bindings();
  bindings.accepted_contract_digest = contract.contract_digest();
  bindings.preview_digest = contract.preview_digest();
  auto forged_artifact = Factory::validated_artifact(
      std::move(source), std::move(bindings));
  auto portable = mwperf::adapt_portable_payload(forged_artifact);
  REQUIRE(portable);

  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  const auto rejected = mwperf::materialize_and_validate_surrogate_plug(
      portable.value(), forged_artifact, contract);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c16.invalid_three_bin_runtime_tuple");
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}
