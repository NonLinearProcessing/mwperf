#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/trusted_protocol_fixtures.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "support/c16_designated_payload_fixture.hpp"
#include "support/c16_test_providers.hpp"

namespace {

using Factory = mwperf::testing::C15ProtocolFixtureFactory;
using Stage = mwperf::testing::C16DesignatedResponseStageV1;

struct NamedStage final {
  std::string_view name;
  Stage value;
};

constexpr std::array<NamedStage, 3U> kStages{{
    {"raw", Stage::raw},
    {"nominal", Stage::nominal},
    {"recoded", Stage::recoded},
}};

[[nodiscard]] const mwperf::ThreeBinScalarResponseV1& source_response(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture) {
  const auto* response = std::get_if<mwperf::ThreeBinScalarResponseV1>(
      &fixture.source_artifact.payload);
  REQUIRE(response != nullptr);
  return *response;
}

[[nodiscard]] mwperf::ThreeBinScalarResponseV1 mutable_response(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture) {
  return source_response(fixture);
}

[[nodiscard]] mwperf::PortableThreeBinScalarResponseV1 portable_response(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture) {
  const auto* response =
      std::get_if<mwperf::PortableThreeBinScalarResponseV1>(
          &fixture.portable_payload.value());
  REQUIRE(response != nullptr);
  return *response;
}

[[nodiscard]] mwperf::PortablePlugPayload remint_portable(
    mwperf::PortableThreeBinScalarResponseV1 response) {
  return Factory::portable_payload(
      mwperf::PortablePlugPayloadValueV1{std::move(response)});
}

[[nodiscard]] mwperf::Result<mwperf::ValidatedSurrogatePlug> materialize(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture,
    const mwperf::PortablePlugPayload& payload) {
  return mwperf::materialize_and_validate_surrogate_plug(
      payload, fixture.validated_artifact, fixture.scenario.contract);
}

void require_cold_f04_rejection(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture,
    const mwperf::PortablePlugPayload& payload,
    const std::string_view code) {
  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  const auto rejected = materialize(fixture, payload);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == code);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}

[[nodiscard]] mwperf::RealizedMetricBindingV1& realized_binding(
    mwperf::SurrogateArtifactV1& artifact,
    const mwperf::MetricSupportRoleV1 role) {
  const auto found = std::find_if(
      artifact.realized_metric_bindings.bindings.begin(),
      artifact.realized_metric_bindings.bindings.end(),
      [role](const auto& binding) { return binding.key.role == role; });
  REQUIRE(found != artifact.realized_metric_bindings.bindings.end());
  return *found;
}

[[nodiscard]] mwperf::Result<
    mwperf::testing::C16DesignatedValidatedPayloadV1>
validate_mutated_response(
    const mwperf::testing::C16DesignatedPayloadFixtureV1& fixture,
    mwperf::ThreeBinScalarResponseV1 response) {
  mwperf::testing::reseal_c16_designated_response_graph_v1(response);
  auto artifact = mwperf::testing::rebuild_c16_designated_artifact_v1(
      fixture.scenario, std::move(response));
  return mwperf::testing::validate_and_adapt_c16_designated_artifact_v1(
      fixture, std::move(artifact));
}

[[nodiscard]] mwperf::ConstructionBudget search_product_budget(
    const std::uint64_t search_states) {
  return {1U,
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{3U}},
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{search_states}},
          {mwperf::BudgetApplicabilityV1::applicable,
           mwperf::BigNat{0U}},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt},
          {mwperf::BudgetApplicabilityV1::not_applicable, std::nullopt}};
}

}  // namespace

TEST_CASE(
    "C16 F04 materializes only the exact designated all-stage response",
    "[c16][integration]") {
  for (const auto& stage : kStages) {
    DYNAMIC_SECTION(stage.name) {
      const auto options =
          mwperf::testing::c16_designated_payload_options_v1(stage.value);
      const auto fixture =
          mwperf::testing::make_c16_designated_payload_fixture_v1(options);
      const auto& response = source_response(fixture);
      REQUIRE(response.nominal_response.has_value());
      REQUIRE(response.projection_center.has_value());
      REQUIRE(response.projected_mean.has_value());
      REQUIRE(response.recoded_response.has_value());

      const std::vector<mwperf::QueueId> deployed_targets(
          fixture.scenario.contract.descriptor_core().deployed_targets.begin(),
          fixture.scenario.contract.descriptor_core().deployed_targets.end());
      const std::vector<mwperf::QueueId> construction_targets(
          fixture.scenario.contract.construction_target_scope().begin(),
          fixture.scenario.contract.construction_target_scope().end());
      CHECK(deployed_targets.size() == 1U);
      CHECK(construction_targets.size() == 3U);
      CHECK(std::equal(deployed_targets.begin(), deployed_targets.end(),
                       construction_targets.begin()));
      CHECK(response.projection_center->ordered_construction_targets ==
            construction_targets);
      CHECK(response.projected_mean->ordered_construction_targets ==
            construction_targets);

      const auto portable = portable_response(fixture);
      CHECK(portable.deployed_target == deployed_targets.front());
      CHECK(portable.normalized_record.nominal_response.has_value());
      CHECK(portable.normalized_record.projection_center.has_value());
      CHECK(portable.normalized_record.projected_mean.has_value());
      CHECK(portable.normalized_record.recoded_response.has_value());
      if (stage.value == Stage::raw) {
        CHECK(std::holds_alternative<mwperf::RawResponseProductId>(
            portable.selected_product));
      } else if (stage.value == Stage::nominal) {
        CHECK(std::holds_alternative<mwperf::NominalResponseProductId>(
            portable.selected_product));
      } else {
        CHECK(std::holds_alternative<mwperf::RecodedResponseProductId>(
            portable.selected_product));
      }

      mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
      auto plug = materialize(fixture, fixture.portable_payload);
      INFO((plug ? std::string{} : plug.error().code + ": " +
                                      plug.error().message));
      REQUIRE(plug);
      CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
                std::memory_order_relaxed) == 1U);
      CHECK(plug.value().descriptor().core.phase.payload_phase ==
            mwperf::PayloadPhaseKindV1::phase_free);
      CHECK(plug.value().descriptor().core.deployed_targets ==
            deployed_targets);
      auto access = mwperf::validate_kernel_access(plug.value());
      REQUIRE(access);
      CHECK(mwperf::runtime_access_tag_v1(access.value()) ==
            mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family);
    }
  }
}

TEST_CASE(
    "C16 F04 rejects mean-stage and undesignated portable substitutions cold",
    "[c16][negative]") {
  SECTION("an interval-only raw record cannot be presented as the final point") {
    const auto fixture =
        mwperf::testing::make_c16_designated_payload_fixture_v1(
            mwperf::testing::c16_designated_payload_options_v1(Stage::raw));
    auto forged = portable_response(fixture);
    auto& identification =
        forged.normalized_record.raw_response.identifications.at(1U);
    identification.coefficient_status.raw_value_status =
        mwperf::RawValueStatusV1::interval_only;
    identification.raw_point = std::nullopt;
    require_cold_f04_rejection(
        fixture, remint_portable(std::move(forged)),
        "c16.portable_payload_body_mismatch");
  }

  SECTION("a projection center cannot be interpreted as a coefficient triple") {
    const auto fixture =
        mwperf::testing::make_c16_designated_payload_fixture_v1(
            mwperf::testing::c16_designated_payload_options_v1(Stage::raw));
    auto forged = portable_response(fixture);
    const auto& center = *forged.normalized_record.projection_center;
    REQUIRE(center.mean_vector.size() == forged.coefficients.size());
    for (std::size_t index = 0U; index < forged.coefficients.size(); ++index) {
      REQUIRE(center.mean_vector[index].kind() ==
              mwperf::PortableScientificScalarKind::rational);
      forged.coefficients[index] =
          center.mean_vector[index].rational_value();
    }
    require_cold_f04_rejection(
        fixture, remint_portable(std::move(forged)),
        "c16.portable_payload_body_mismatch");
  }

  SECTION("projected mean cannot be interpreted as a coefficient triple") {
    const auto fixture =
        mwperf::testing::make_c16_designated_payload_fixture_v1(
            mwperf::testing::c16_designated_payload_options_v1(
                Stage::recoded));
    auto forged = portable_response(fixture);
    const auto& mean = *forged.normalized_record.projected_mean;
    REQUIRE(mean.mean_vector.size() == forged.coefficients.size());
    for (std::size_t index = 0U; index < forged.coefficients.size(); ++index) {
      REQUIRE(mean.mean_vector[index].kind() ==
              mwperf::PortableScientificScalarKind::rational);
      forged.coefficients[index] = mean.mean_vector[index].rational_value();
    }
    require_cold_f04_rejection(
        fixture, remint_portable(std::move(forged)),
        "c16.portable_payload_body_mismatch");
  }

  for (const auto& deployed : kStages) {
    DYNAMIC_SECTION("an undesignated " << deployed.name
                                        << " response cannot replace the final law") {
      const Stage accepted = deployed.value == Stage::raw ? Stage::recoded
                                                          : Stage::raw;
      const auto fixture =
          mwperf::testing::make_c16_designated_payload_fixture_v1(
              mwperf::testing::c16_designated_payload_options_v1(accepted));
      auto forged = portable_response(fixture);
      if (deployed.value == Stage::raw) {
        forged.selected_product = forged.normalized_record.raw_response.product_id;
      } else if (deployed.value == Stage::nominal) {
        forged.selected_product =
            forged.normalized_record.nominal_response->product_id;
      } else {
        forged.selected_product =
            forged.normalized_record.recoded_response->product_id;
      }
      forged.normalized_record.deployed_response_product_id =
          forged.selected_product;
      require_cold_f04_rejection(
          fixture, remint_portable(std::move(forged)),
          "c16.portable_payload_body_mismatch");
    }
  }

  SECTION("a structural manifest changed after acceptance is rejected") {
    const auto fixture =
        mwperf::testing::make_c16_designated_payload_fixture_v1(
            mwperf::testing::c16_designated_payload_options_v1());
    auto forged = portable_response(fixture);
    forged.context.structural_manifest_echo.canonical_manifest_bytes.push_back(
        std::byte{0U});
    require_cold_f04_rejection(fixture, remint_portable(std::move(forged)),
                               "c16.materialization_binding_mismatch");
  }

  SECTION("a realized binding cannot point at another product stage") {
    const auto fixture =
        mwperf::testing::make_c16_designated_payload_fixture_v1(
            mwperf::testing::c16_designated_payload_options_v1());
    auto forged = portable_response(fixture);
    const auto binding_iterator = std::find_if(
        forged.context.realized_metric_bindings.bindings.begin(),
        forged.context.realized_metric_bindings.bindings.end(),
        [](const auto& candidate) {
          return candidate.key.role ==
                 mwperf::MetricSupportRoleV1::deployed_response;
        });
    REQUIRE(binding_iterator !=
            forged.context.realized_metric_bindings.bindings.end());
    auto& binding = *binding_iterator;
    auto& reference = std::get<mwperf::DeployedResponseReferenceV1>(
        binding.reference);
    reference.selected_product = mwperf::RawResponseProductRef{
        forged.normalized_record.raw_response.product_id.identity(),
        mwperf::ResponseProductValueFormV1::exact_point};
    require_cold_f04_rejection(fixture, remint_portable(std::move(forged)),
                               "c16.materialization_binding_mismatch");
  }
}

TEST_CASE(
    "C16 all-stage artifacts reject phase target derivation and stage drift",
    "[c16][negative]") {
  const auto fixture =
      mwperf::testing::make_c16_designated_payload_fixture_v1(
          mwperf::testing::c16_designated_payload_options_v1());

  SECTION("phase presence is not a phase-free scalar response") {
    auto artifact = fixture.source_artifact;
    artifact.deployed_descriptor.phase.payload_phase =
        mwperf::PayloadPhaseKindV1::predictive_phase_indexed;
    artifact.deployed_descriptor.core_digest =
        mwperf::canonical_plug_descriptor_core_digest_v1(
            artifact.deployed_descriptor)
            .value();
    const auto rejected =
        mwperf::testing::validate_and_adapt_c16_designated_artifact_v1(
            fixture, std::move(artifact));
    REQUIRE_FALSE(rejected);
  }

  SECTION("requested target identity cannot drift") {
    auto response = mutable_response(fixture);
    response.deployed_target = response.projection_center
                                   ->ordered_construction_targets.at(1U);
    REQUIRE_FALSE(validate_mutated_response(fixture, std::move(response)));
  }

  SECTION("recoded derivation cannot drift from its exact parents") {
    auto response = mutable_response(fixture);
    response.recoded_response->derivation_kind =
        mwperf::ProductDerivationKindV1::identity_recoding;
    REQUIRE_FALSE(validate_mutated_response(fixture, std::move(response)));
  }

  for (const auto& undesignated : kStages) {
    if (undesignated.value == Stage::recoded) continue;
    DYNAMIC_SECTION("C15 rejects a resealed undesignated "
                    << undesignated.name << " response") {
      auto response = mutable_response(fixture);
      if (undesignated.value == Stage::raw) {
        response.deployed_response_product_id =
            response.raw_response.product_id;
      } else {
        response.deployed_response_product_id =
            response.nominal_response->product_id;
      }
      REQUIRE_FALSE(validate_mutated_response(fixture, std::move(response)));
    }
  }

  SECTION("realized clause binding cannot point at the wrong stage") {
    auto artifact = fixture.source_artifact;
    const auto& response =
        std::get<mwperf::ThreeBinScalarResponseV1>(artifact.payload);
    auto& binding = realized_binding(
        artifact, mwperf::MetricSupportRoleV1::deployed_response);
    auto& reference = std::get<mwperf::DeployedResponseReferenceV1>(
        binding.reference);
    reference.selected_product = mwperf::RawResponseProductRef{
        response.raw_response.product_id.identity(),
        mwperf::ResponseProductValueFormV1::exact_point};
    const auto rejected =
        mwperf::testing::validate_and_adapt_c16_designated_artifact_v1(
            fixture, std::move(artifact));
    REQUIRE_FALSE(rejected);
  }
}

TEST_CASE(
    "C16 designated points preserve population conditioning obligations",
    "[c16][negative]") {
  const auto base =
      mwperf::testing::make_c16_designated_payload_fixture_v1(
          mwperf::testing::c16_designated_payload_options_v1(Stage::nominal));

  SECTION("empirical average cannot prove population zero") {
    auto options = mwperf::testing::c16_designated_payload_options_v1(
        Stage::nominal);
    auto& status = options.coefficient_statuses.at(1U);
    status.source = mwperf::ProposalConditioningSourceV1::empirical_average;
    status.population =
        mwperf::PopulationConditioningStatusV1::proved_zero;
    status.raw = mwperf::RawValueStatusV1::absent;
    status.raw_point = std::nullopt;
    auto response = mwperf::testing::make_c16_designated_response_v1(
        base.scenario, options);
    REQUIRE_FALSE(validate_mutated_response(base, std::move(response)));
  }

  SECTION("unresolved unit interval cannot be presented as unconditional") {
    auto options = mwperf::testing::c16_designated_payload_options_v1(
        Stage::nominal);
    auto& status = options.coefficient_statuses.at(1U);
    status.population = mwperf::PopulationConditioningStatusV1::unresolved;
    status.raw = mwperf::RawValueStatusV1::interval_only;
    status.raw_point = std::nullopt;
    auto response = mwperf::testing::make_c16_designated_response_v1(
        base.scenario, options);
    REQUIRE_FALSE(response.raw_envelopes.empty());
    response.raw_envelopes.front().lower = {
        mwperf::PortableScientificScalar::rational(
            mwperf::ExactRational::zero())};
    response.raw_envelopes.front().upper = {
        mwperf::PortableScientificScalar::rational(
            mwperf::ExactRational::one())};
    response.raw_envelopes.front().population_conditioning_premise =
        mwperf::PopulationConditioningPremiseV1::unconditional;
    REQUIRE_FALSE(validate_mutated_response(base, std::move(response)));
  }

  for (const auto population :
       {mwperf::PopulationConditioningStatusV1::proved_zero,
        mwperf::PopulationConditioningStatusV1::unresolved}) {
    DYNAMIC_SECTION("a final point with conditioning "
                    << static_cast<unsigned int>(population)
                    << " requires its exact authorized completion identity") {
      auto options = mwperf::testing::c16_designated_payload_options_v1(
          Stage::nominal);
      auto& status = options.coefficient_statuses.at(1U);
      status.population = population;
      status.raw = population ==
                           mwperf::PopulationConditioningStatusV1::proved_zero
                       ? mwperf::RawValueStatusV1::absent
                       : mwperf::RawValueStatusV1::interval_only;
      status.raw_point = std::nullopt;
      status.completion_policy = std::nullopt;
      auto response = mwperf::testing::make_c16_designated_response_v1(
          base.scenario, options);
      response.nominal_response->completion_policy_id = std::nullopt;
      REQUIRE_FALSE(validate_mutated_response(base, std::move(response)));
    }
  }
}

TEST_CASE("C16 preview and request admission enforce three times four states",
          "[c16][integration][budget]") {
  using namespace mwperf::testing::c16_designated_detail;
  auto input = mwperf::testing::c16_designated_detail::input(
      "c16.fixture.search-product");
  auto id = mwperf::SurrogateId::parse("c16.fixture.search-product");
  REQUIRE(id);
  auto provider = mwperf::lookup_surrogate_provider(id.value());
  REQUIRE(provider);
  const mwperf::TargetSelection targets{
      1U,
      {queue("q0")},
      mwperf::ConstructionGroupIdV1(
          label("c16.search-product.construction-group"))};
  auto view = mwperf::build_framework_problem_view(
      input.instance, *input.arrival, targets);
  REQUIRE(view);
  auto validated_parameters = mwperf::validate_surrogate_parameters(
      provider.value(), parameters());
  REQUIRE(validated_parameters);

  mwperf::testing::c16_fixture_detail::reset_side_effect_counters();
  const auto insufficient = search_product_budget(11U);
  auto rejected_preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, insufficient,
      validated_parameters.value());
  REQUIRE_FALSE(rejected_preview);
  CHECK(rejected_preview.error().code ==
        "c16.preview_prerequisite_mismatch");
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);

  const auto exact = search_product_budget(12U);
  auto preview = mwperf::preview_surrogate_descriptor(
      provider.value(), view.value(), input.requirements, exact,
      validated_parameters.value());
  INFO((preview ? std::string{} : preview.error().code + ": " +
                                      preview.error().message));
  REQUIRE(preview);
  CHECK(preview.value().construction_prerequisites
            .required_optimizer_calls == mwperf::BigNat{3U});
  CHECK(preview.value().construction_prerequisites
            .required_search_states_per_call == mwperf::BigNat{4U});

  auto insufficient_digest =
      mwperf::digest_construction_budget_v1(insufficient);
  REQUIRE(insufficient_digest);
  auto forged_contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      validated_parameters.value().canonical_value_digest(),
      insufficient_digest.value());
  auto rejected_request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), forged_contract,
      validated_parameters.value(), insufficient, mwperf::MasterSeed(0x3411U));
  REQUIRE_FALSE(rejected_request);
  CHECK(rejected_request.error().code ==
        "c15.construction_budget_insufficient");

  auto exact_digest = mwperf::digest_construction_budget_v1(exact);
  REQUIRE(exact_digest);
  auto contract = Factory::accepted_contract(
      provider.value().manifest().value(), preview.value().core,
      *preview.value().metric_support_manifest, input.requirements,
      view.value().configured_arrival().capabilities(), {},
      preview.value().construction_target_scope, preview.value().policies,
      preview.value().construction_prerequisites,
      view.value().canonical_digest().value(),
      validated_parameters.value().canonical_value_digest(),
      exact_digest.value());
  auto request = mwperf::make_surrogate_build_request(
      provider.value().manifest(), view.value(), contract,
      validated_parameters.value(), exact, mwperf::MasterSeed(0x3412U));
  INFO((request ? std::string{} : request.error().code + ": " +
                                      request.error().message));
  REQUIRE(request);
  CHECK(request.value().construction_budget().optimizer_search_states.amount ==
        mwperf::BigNat{12U});
  CHECK(mwperf::testing::c16_fixture_detail::construction_calls().load(
            std::memory_order_relaxed) == 0U);
  CHECK(mwperf::testing::c16_fixture_detail::materializer_calls().load(
            std::memory_order_relaxed) == 0U);
}
