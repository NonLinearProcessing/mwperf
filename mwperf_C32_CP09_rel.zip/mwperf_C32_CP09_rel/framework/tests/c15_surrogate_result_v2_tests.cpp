#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/diagnostics/observation_record.hpp"

namespace {

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::Digest256 digest(const char digit) {
  auto value = mwperf::Digest256::from_hex(std::string(64U, digit));
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ObservationScalarV1 scalar(
    const std::int64_t numerator, const std::int64_t denominator = 1) {
  return {mwperf::PortableScientificScalar::rational(
              rational(numerator, denominator)),
          std::nullopt};
}

[[nodiscard]] mwperf::ObservationMassBalanceV1 exact_balance(
    const std::int64_t recorded_mass) {
  return {mwperf::ObservationNormalizationClaimV1::exact,
          scalar(recorded_mass), scalar(0)};
}

[[nodiscard]] mwperf::ObservationCapabilityStateV1 available() {
  return {true, std::nullopt};
}

[[nodiscard]] mwperf::ObservationCapabilityStateV1 unavailable(
    std::string reason) {
  return {false, std::move(reason)};
}

[[nodiscard]] mwperf::ConstructionObservationBundleV1 exact_bundle() {
  mwperf::BoundaryBacklogLawV1 initial{
      0U, {{mwperf::BigNat{0U}, scalar(1)}}, exact_balance(1)};
  mwperf::BoundaryBacklogLawV1 committed{
      4U, {{mwperf::BigNat{0U}, scalar(1)}}, exact_balance(1)};
  mwperf::ConstructionObservationBlockV1 block{
      0U,
      4U,
      mwperf::ObservationCompletenessV1::complete,
      4U,
      {{mwperf::BigNat{0U}, scalar(1), scalar(0), std::nullopt},
       {mwperf::BigNat{1U}, scalar(1), scalar(1), std::nullopt},
       {mwperf::BigNat{2U}, scalar(2), scalar(1), std::nullopt}},
      exact_balance(4),
      std::move(initial),
      std::move(committed)};

  mwperf::ObservationCapabilitiesV1 capabilities{
      available(), available(), available(), available(), available(),
      available(), unavailable("not_requested")};
  return mwperf::ConstructionObservationBundleV1{
      1U,
      mwperf::ObservationSourceRoleV1::short_restart_reference,
      mwperf::ObservationScalarRepresentationV1::exact_rational,
      {digest('1'),
       digest('2'),
       digest('3'),
       {mwperf::QueueId(
            mwperf::TypedLabel::numeric(mwperf::BigNat{17U})),
        0U, rational(1)},
       {"iid_batch_v1",
        digest('4'),
        mwperf::ExactTargetArrivalMarginalV1{
            {{mwperf::BigNat{0U}, rational(3, 4)},
             {mwperf::BigNat{1U}, rational(1, 4)}}},
        rational(1, 4), rational(1, 4)},
       digest('5'),
       digest('6'),
       digest('7'),
       digest('8'),
       digest('9'),
       digest('a')},
      {{mwperf::ObservationSlotStageV1::solve_primary_maxweight,
        mwperf::ObservationSlotStageV1::observe_pre_service,
        mwperf::ObservationSlotStageV1::apply_actual_service,
        mwperf::ObservationSlotStageV1::apply_fresh_late_arrival,
        mwperf::ObservationSlotStageV1::commit_post_slot_state,
        mwperf::ObservationSlotStageV1::emit_committed_observation},
       digest('b')},
      {"point_mass_zero", digest('c')},
      {"counter_rng", 1U, digest('d')},
      0U,
      4U,
      {0U, 4U},
      std::move(capabilities),
      {{mwperf::TypedLabel::numeric(mwperf::BigNat{0U}), digest('e'),
        std::nullopt, mwperf::ObservationCompletenessV1::complete, 4U,
        {std::move(block)}}}};
}

[[nodiscard]] mwperf::ConstructionObservationEnvelopeV1 envelope_for(
    mwperf::ConstructionObservationBundleV1 bundle) {
  auto body_digest =
      mwperf::construction_observation_bundle_digest_v1(bundle);
  REQUIRE(body_digest);
  return {std::move(bundle), std::move(body_digest).value()};
}

[[nodiscard]] mwperf::ConstructionObservationBundleV1 exact_gap_bundle() {
  auto bundle = exact_bundle();
  bundle.capabilities.certified_gap_probe = available();
  auto& levels = bundle.replications.front().blocks.front().levels;
  levels[0].gap = mwperf::ObservationGapCellV1{
      scalar(1), scalar(0), scalar(0), scalar(0), scalar(0), scalar(1)};
  levels[1].gap = mwperf::ObservationGapCellV1{
      scalar(0), scalar(0), scalar(1), scalar(0), scalar(1), scalar(0)};
  levels[2].gap = mwperf::ObservationGapCellV1{
      scalar(0), scalar(2), scalar(0), scalar(1), scalar(0), scalar(0)};
  return bundle;
}

[[nodiscard]] const mwperf::ExactRational& quantity_value(
    const mwperf::CompressionQuantityV1& quantity) {
  REQUIRE(quantity.available());
  REQUIRE(quantity.estimate);
  CHECK(quantity.estimate->absolute_error_bound.is_zero());
  return quantity.estimate->value;
}

}  // namespace

TEST_CASE("C30 observation-v1 codec is canonical and digest bound",
          "[c30][protocol][unit]") {
  const auto envelope = envelope_for(exact_bundle());
  auto first =
      mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
  auto second =
      mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
  REQUIRE(first);
  REQUIRE(second);
  CHECK(first.value() == second.value());

  const auto limits = mwperf::default_observation_parse_limits_v1();
  auto parsed = mwperf::parse_construction_observation_envelope_v1(
      first.value(), limits);
  REQUIRE(parsed);
  CHECK(parsed.value() == envelope);
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      std::move(parsed).value(), limits);
  REQUIRE(validated);
  CHECK(validated.value().value() == envelope.observation_bundle);
  CHECK(validated.value().digest() == envelope.observation_bundle_digest);
}

TEST_CASE("C30 observation-v1 rejects digest and sparse-order mutations",
          "[c30][protocol][negative]") {
  const auto limits = mwperf::default_observation_parse_limits_v1();

  SECTION("digest mismatch") {
    auto envelope = envelope_for(exact_bundle());
    envelope.observation_bundle_digest = digest('f');
    auto validated = mwperf::validate_construction_observation_envelope_v1(
        std::move(envelope), limits);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "observation_bundle_digest_mismatch");
  }

  SECTION("duplicate or descending level") {
    auto bundle = exact_bundle();
    std::swap(bundle.replications.front().blocks.front().levels[0],
              bundle.replications.front().blocks.front().levels[1]);
    auto validated = mwperf::validate_construction_observation_envelope_v1(
        envelope_for(std::move(bundle)), limits);
    REQUIRE_FALSE(validated);
    CHECK(validated.error().code == "observation_unsorted_level_rows");
  }
}

TEST_CASE("C30 observation-v1 parser enforces caps before typed decoding",
          "[c30][protocol][negative]") {
  const auto envelope = envelope_for(exact_bundle());
  auto bytes =
      mwperf::canonical_construction_observation_envelope_bytes_v1(envelope);
  REQUIRE(bytes);

  SECTION("encoded-byte cap") {
    auto limits = mwperf::default_observation_parse_limits_v1();
    limits.maximum_bytes = bytes.value().size() - 1U;
    auto parsed = mwperf::parse_construction_observation_envelope_v1(
        bytes.value(), limits);
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().code == "observation_parse_input_bytes_limit");
    CHECK(parsed.error().category ==
          mwperf::DiagnosticCategory::resource_limit);
  }

  SECTION("replication cardinality cap") {
    auto limits = mwperf::default_observation_parse_limits_v1();
    limits.maximum_replications = 0U;
    auto parsed = mwperf::parse_construction_observation_envelope_v1(
        bytes.value(), limits);
    REQUIRE_FALSE(parsed);
    CHECK(parsed.error().category ==
          mwperf::DiagnosticCategory::resource_limit);
  }
}

TEST_CASE("C30 compression analysis reports all four exact tail rewards",
          "[c30][math][property]") {
  const auto limits = mwperf::default_observation_parse_limits_v1();
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      envelope_for(exact_bundle()), limits);
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, true, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  const auto& tail = analysis.value().cutoffs.front().tail;
  CHECK(quantity_value(tail.tail_probability) == rational(1, 2));
  CHECK(quantity_value(tail.tail_service_mass) == rational(1, 4));
  CHECK(quantity_value(tail.backlog_tail_reward) == rational(1));
  CHECK(quantity_value(tail.backlog_service_tail_reward) == rational(1, 2));
  CHECK(quantity_value(tail.constant_tail_response) == rational(1, 2));
  CHECK(quantity_value(tail.tail_slack) == rational(1, 4));
  CHECK(quantity_value(tail.discarded_association_reward).is_zero());
  CHECK(quantity_value(tail.tail_mean_fraction) == rational(4, 5));
  CHECK(quantity_value(tail.tail_association_ratio).is_zero());

  const auto& decomposition =
      analysis.value().cutoffs.front().decomposition;
  CHECK(quantity_value(decomposition.observation_balance_closure).is_zero());
  CHECK(quantity_value(decomposition.numerator_closure).is_zero());
  CHECK(quantity_value(decomposition.divided_closure).is_zero());
}

TEST_CASE("C30 finite-window drift is split from its innovation exactly",
          "[c30][math][property]") {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      envelope_for(exact_bundle()),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  const auto& finite = analysis.value().finite_window;
  CHECK(quantity_value(finite.first_moment_endpoint_drift) ==
        quantity_value(finite.first_moment_expected_increment) +
            quantity_value(finite.first_moment_innovation));
  CHECK(quantity_value(finite.second_moment_endpoint_drift) ==
        quantity_value(finite.second_moment_expected_increment) +
            quantity_value(finite.second_moment_innovation));
  CHECK(quantity_value(finite.moment_identity_closure).is_zero());
  REQUIRE(finite.cutoffs.size() == 1U);
  CHECK(quantity_value(finite.cutoffs.front().realized_identity_closure)
            .is_zero());
}

TEST_CASE("C30 tie telemetry reconstructs response and exact backlog reward",
          "[c30][math][property]") {
  auto validated = mwperf::validate_construction_observation_envelope_v1(
      envelope_for(exact_gap_bundle()),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  const auto& ties = analysis.value().ties;
  REQUIRE(ties.response_by_level.size() == 3U);
  for (const auto& point : ties.response_by_level) {
    CHECK(quantity_value(point.response_reconstruction_closure).is_zero());
    CHECK(quantity_value(point.reconstructed_response) ==
          quantity_value(point.observed_response));
  }
  CHECK(quantity_value(ties.strict_loss_backlog_reward).is_zero());
  CHECK(quantity_value(ties.lost_tie_backlog_reward) == rational(1, 2));

  REQUIRE(analysis.value().competition.cutoffs.size() == 1U);
  CHECK(quantity_value(
            analysis.value().competition.cutoffs.front()
                .association_split_closure)
            .is_zero());
}

TEST_CASE("C30 point estimates pool masses before forming response ratios",
          "[c30][math][property]") {
  auto bundle = exact_bundle();
  auto& first = bundle.replications.front();
  first.blocks.front().levels = {
      {mwperf::BigNat{0U}, scalar(3), scalar(0), std::nullopt},
      {mwperf::BigNat{2U}, scalar(1), scalar(1), std::nullopt}};

  auto second = first;
  second.replication_id =
      mwperf::TypedLabel::numeric(mwperf::BigNat{1U});
  second.replay_identity = digest('f');
  second.blocks.front().levels = {
      {mwperf::BigNat{0U}, scalar(1), scalar(0), std::nullopt},
      {mwperf::BigNat{2U}, scalar(3), scalar(0), std::nullopt}};
  bundle.replications.push_back(std::move(second));

  auto validated = mwperf::validate_construction_observation_envelope_v1(
      envelope_for(std::move(bundle)),
      mwperf::default_observation_parse_limits_v1());
  REQUIRE(validated);
  mwperf::CompressionAnalysisOptionsV1 options{
      {mwperf::BigNat{1U}}, {}, {}, {}, std::nullopt, false, false, false,
      false,
      mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
          finite_prefix_constant_tail,
      std::nullopt, std::nullopt};
  auto analysis = mwperf::analyze_compression_observations_v1(
      validated.value(), options);
  REQUIRE(analysis);
  REQUIRE(analysis.value().cutoffs.size() == 1U);
  // The two per-replication tail responses are 1 and 0.  Pooling their raw
  // tail masses gives 1/(1+3)=1/4, deliberately not their arithmetic mean.
  CHECK(quantity_value(
            analysis.value().cutoffs.front().tail.constant_tail_response) ==
        rational(1, 4));
}
