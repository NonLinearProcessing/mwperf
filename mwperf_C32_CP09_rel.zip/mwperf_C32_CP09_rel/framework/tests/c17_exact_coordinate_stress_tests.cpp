#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/reduction/resource_coordinates.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

const mwperf::CodecIdentityV1 kLargeExactStateCodec{
    "c17.fixture.large-exact-state", 1U};

[[nodiscard]] mwperf::BigNat power_of_two(const unsigned exponent) {
  auto value = mwperf::BigNat::from_big_int(mwperf::BigInt{1} << exponent);
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ExactRational integral_rational(
    const mwperf::BigNat& value) {
  auto rational =
      mwperf::ExactRational::make(value.value(), mwperf::BigInt{1});
  REQUIRE(rational);
  return std::move(rational).value();
}

[[nodiscard]] mwperf::Digest256 exact_reduced_state_identity(
    const mwperf::ReducedStateV1& state) {
  mwperf::Sha256 hash;
  REQUIRE(hash.update(std::as_bytes(
      std::span(state.codec.id.data(), state.codec.id.size()))));
  const std::array<std::byte, 4U> version{
      static_cast<std::byte>((state.codec.version >> 24U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 16U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 8U) & 0xffU),
      static_cast<std::byte>(state.codec.version & 0xffU)};
  REQUIRE(hash.update(version));
  REQUIRE(hash.update(state.canonical_value));
  return hash.finalize();
}

[[nodiscard]] mwperf::ReducedStateV1 endpoint_state(
    const std::uint8_t selector) {
  return {kLargeExactStateCodec,
          {static_cast<std::byte>(selector)}};
}

[[nodiscard]] bool same_exact_coordinates(
    const mwperf::ExactReducedCoordinatesV1& left,
    const mwperf::ExactReducedCoordinatesV1& right) {
  return left.backlog == right.backlog &&
         mwperf::testing::c17::same_phase(left.arrival_phase,
                                         right.arrival_phase) &&
         left.boundary_index == right.boundary_index &&
         left.resources == right.resources && left.margins == right.margins &&
         left.controller == right.controller &&
         left.unresolved_fields == right.unresolved_fields;
}

[[nodiscard]] mwperf::ExactReducedStateSchemaV1 two_endpoint_schema(
    mwperf::ExactReducedCoordinatesV1 before,
    mwperf::ExactReducedCoordinatesV1 after) {
  return {
      kLargeExactStateCodec,
      mwperf::testing::c17::digest("c17.fixture.large-exact-schema"),
      mwperf::testing::c17::digest("c17.fixture.large-state-schema"),
      mwperf::testing::c17::digest("c17.fixture.large-ownership-schema"),
      mwperf::testing::c17::digest("c17.fixture.large-update-schema"),
      [before, after](const mwperf::ReducedStateV1& state)
          -> mwperf::Result<mwperf::ExactReducedCoordinatesV1> {
        if (state.codec != kLargeExactStateCodec ||
            state.canonical_value.size() != 1U) {
          return mwperf::testing::c17::failure<
              mwperf::ExactReducedCoordinatesV1>(
              "c17.fixture.large_state_shape",
              "the exact stress state must name one endpoint");
        }
        const std::uint8_t selector =
            std::to_integer<std::uint8_t>(state.canonical_value.front());
        if (selector > 1U) {
          return mwperf::testing::c17::failure<
              mwperf::ExactReducedCoordinatesV1>(
              "c17.fixture.large_state_selector",
              "the exact stress state selector must be zero or one");
        }
        return mwperf::Result<mwperf::ExactReducedCoordinatesV1>::success(
            selector == 0U ? before : after);
      },
      [before, after](const mwperf::ExactReducedCoordinatesV1& coordinates,
                      const mwperf::UnresolvedPatch& unresolved)
          -> mwperf::Result<mwperf::ReducedStateV1> {
        if (!unresolved.fields().empty()) {
          return mwperf::testing::c17::failure<mwperf::ReducedStateV1>(
              "c17.fixture.large_unresolved_patch",
              "the exact stress recurrence has no unresolved coordinate");
        }
        if (same_exact_coordinates(coordinates, before)) {
          return mwperf::Result<mwperf::ReducedStateV1>::success(
              endpoint_state(0U));
        }
        if (same_exact_coordinates(coordinates, after)) {
          return mwperf::Result<mwperf::ReducedStateV1>::success(
              endpoint_state(1U));
        }
        return mwperf::testing::c17::failure<mwperf::ReducedStateV1>(
            "c17.fixture.large_rebuild_value",
            "the rebuilt coordinates differ from both exact endpoints");
      },
      [](const mwperf::ReducedStateV1& state) {
        if (state.codec != kLargeExactStateCodec ||
            state.canonical_value.size() != 1U ||
            std::to_integer<std::uint8_t>(state.canonical_value.front()) >
                1U) {
          return mwperf::testing::c17::failure<void>(
              "c17.fixture.large_state_domain",
              "the exact stress state lies outside its two endpoints");
        }
        return mwperf::Result<void>::success();
      },
      {},
      {},
      {}};
}

[[nodiscard]] mwperf::PlugDescriptor unmarked_descriptor(
    const mwperf::PlugDescriptor& source) {
  mwperf::PlugDescriptor descriptor = source;
  descriptor.marks.clear();
  return descriptor;
}

}  // namespace

TEST_CASE("C17 emitted-face signs remain exact beyond native integer range",
          "[c17][property]") {
  const auto& instance = mwperf::testing::c17::conflicting_face_instance();
  const auto queues = instance.queues().entries();
  REQUIRE(queues.size() == 2U);
  const std::vector<mwperf::QueueId> targets{queues[0U].id, queues[1U].id};

  const mwperf::BigNat large = power_of_two(130U);
  const mwperf::BigNat large_plus_one = large + mwperf::BigNat{1U};
  REQUIRE(large.bit_length() > 128U);
  auto backlog = mwperf::TargetBacklogV1::from_values(
      instance, targets, {large, large_plus_one});
  REQUIRE(backlog);

  const auto state = endpoint_state(0U);
  const mwperf::CausalBranchIdentityV1 branch{
      exact_reduced_state_identity(state), {}};
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, mwperf::ExactRational::zero()},
      {{queues[0U].id}, {}, mwperf::ExactRational::zero()},
      {{queues[1U].id}, {}, mwperf::ExactRational::zero()},
  }};
  const mwperf::OpportunityMark opportunity{
      branch, backlog.value(), face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.large-face", {0x01U}), {}};

  auto optimizer =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(optimizer);
  auto law = mwperf::prepare_reduced_action_law(
      instance, state, opportunity, optimizer.value());
  REQUIRE(law);
  const auto atoms = mwperf::testing::C17FixtureAccess::atoms(law.value());
  REQUIRE(atoms.size() == 1U);
  const auto& action = atoms.front().outcome;
  REQUIRE(action.evidence.emitted_face.has_value());
  const auto& decision = *action.evidence.emitted_face;
  REQUIRE(decision.ordered_target_faces.size() == 2U);

  const auto& q0 = decision.ordered_target_faces[0U];
  CHECK(q0.forced_out_residual_max == integral_rational(large_plus_one));
  CHECK(q0.forced_in_residual_max == mwperf::ExactRational::zero());
  CHECK(q0.algebraic_margin ==
        mwperf::testing::c17::rational(-1, 1));
  CHECK(q0.exact_class == mwperf::AlgebraicTargetClass::forced_out);

  const auto& q1 = decision.ordered_target_faces[1U];
  CHECK(q1.forced_out_residual_max == integral_rational(large));
  CHECK(q1.forced_in_residual_max == mwperf::ExactRational::zero());
  CHECK(q1.algebraic_margin == mwperf::ExactRational::one());
  CHECK(q1.exact_class == mwperf::AlgebraicTargetClass::forced_in);

  CHECK(decision.selected_primary_score == integral_rational(large_plus_one));
  const auto q0_id = instance.queues().index_at(0U).value();
  const auto q1_id = instance.queues().index_at(1U).value();
  CHECK_FALSE(action.schedule.at(q0_id));
  CHECK(action.schedule.at(q1_id));
}

TEST_CASE("C17 Psi preserves exact target and resource recurrences beyond native range",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto q0_id = base.instance.queues().entries()[0U].id;
  const mwperf::BigNat scale = power_of_two(130U);
  REQUIRE(scale.bit_length() > 128U);

  auto backlog = mwperf::TargetBacklogV1::from_values(
      base.instance, base.descriptor.core.deployed_targets, {scale});
  REQUIRE(backlog);
  const auto state = endpoint_state(0U);
  const mwperf::CausalBranchIdentityV1 branch{
      exact_reduced_state_identity(state), {}};
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, mwperf::ExactRational::zero()},
      {{q0_id}, {}, mwperf::ExactRational::zero()},
  }};
  const mwperf::OpportunityMark opportunity{
      branch, backlog.value(), face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.large-psi-face", {0x01U}),
      {}};

  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  auto action_law = mwperf::prepare_reduced_action_law(
      base.instance, state, opportunity, optimizer.value());
  REQUIRE(action_law);
  const auto action_atoms =
      mwperf::testing::C17FixtureAccess::atoms(action_law.value());
  REQUIRE(action_atoms.size() == 1U);
  const auto action = action_atoms.front().outcome;
  REQUIRE(action.actual_departure.at(q0));

  auto prepared_arrival = mwperf::prepare_configured_arrival_law(
      base.configured_arrival, base.phase_zero);
  REQUIRE(prepared_arrival);
  auto arrival_law =
      mwperf::testing::C17FixtureAccess::apply_arrival_enumeration(
          prepared_arrival.value(),
          mwperf::testing::C17FixtureAccess::arrival_capability(branch),
          mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(arrival_law);
  const auto arrival_atoms =
      mwperf::testing::C17FixtureAccess::atoms(arrival_law.value());
  REQUIRE_FALSE(arrival_atoms.empty());
  const auto arrival = arrival_atoms.front().outcome;

  auto direction = mwperf::NonnegativeIntegralDirection::from_values(
      mwperf::QueueDimensionToken::from_instance(base.instance),
      {scale, mwperf::BigNat{0U}, mwperf::BigNat{0U}});
  REQUIRE(direction);
  const mwperf::BigNat capacity = scale;
  const mwperf::BigNat workload = scale * mwperf::BigNat{3U};
  const mwperf::BigNat lower_queue = scale * mwperf::BigNat{2U};
  auto coordinate = mwperf::ResourceCoordinate::make(
      std::move(direction).value(), capacity, workload, mwperf::BigNat{0U},
      lower_queue, true);
  REQUIRE(coordinate);
  auto resources_before = mwperf::ResourceState::from_coordinates(
      {std::move(coordinate).value()});
  REQUIRE(resources_before);

  auto admitted = mwperf::project_arrival_count(
      arrival.batch, q0,
      mwperf::arrival_law_binding(base.configured_arrival));
  REQUIRE(admitted);
  const mwperf::BigNat served =
      scale * mwperf::BigNat{action.actual_departure.at(q0) ? 1U : 0U};
  const mwperf::BigNat arrived = scale * admitted.value();
  auto remaining_workload = mwperf::checked_subtract(workload, served);
  auto expected_unused = mwperf::checked_subtract(capacity, served);
  auto remaining_lower = mwperf::checked_subtract(lower_queue, capacity);
  REQUIRE(remaining_workload);
  REQUIRE(expected_unused);
  REQUIRE(remaining_lower);
  const mwperf::BigNat expected_workload =
      remaining_workload.value() + arrived;
  const mwperf::BigNat expected_lower = remaining_lower.value() + arrived;

  auto expected_direction =
      mwperf::NonnegativeIntegralDirection::from_values(
          mwperf::QueueDimensionToken::from_instance(base.instance),
          {scale, mwperf::BigNat{0U}, mwperf::BigNat{0U}});
  REQUIRE(expected_direction);
  auto expected_coordinate = mwperf::ResourceCoordinate::make(
      std::move(expected_direction).value(), capacity, expected_workload,
      expected_unused.value(), expected_lower, true);
  REQUIRE(expected_coordinate);
  auto expected_resources = mwperf::ResourceState::from_coordinates(
      {std::move(expected_coordinate).value()});
  REQUIRE(expected_resources);

  auto direct_resource_update = mwperf::update_resource_coordinates(
      resources_before.value(), action.actual_departure, arrival.batch);
  REQUIRE(direct_resource_update);
  CHECK(direct_resource_update.value() == expected_resources.value());

  auto after_service = mwperf::checked_subtract(scale, mwperf::BigNat{1U});
  REQUIRE(after_service);
  const mwperf::BigNat expected_target =
      after_service.value() + admitted.value();
  auto successor_backlog = backlog.value().with_values({expected_target});
  REQUIRE(successor_backlog);

  const mwperf::ExactReducedCoordinatesV1 before{
      backlog.value(), base.phase_zero, mwperf::BigNat{0U},
      resources_before.value(), {}, std::nullopt, {}};
  const mwperf::ExactReducedCoordinatesV1 after{
      successor_backlog.value(), arrival.phase_after, mwperf::BigNat{1U},
      expected_resources.value(), {}, std::nullopt, {}};
  auto schema = two_endpoint_schema(before, after);
  const auto descriptor = unmarked_descriptor(base.descriptor);
  auto post_law = mwperf::testing::C17FixtureAccess::postclosure_law(
      {{{branch, {}, {}}, mwperf::ExactRational::one(), true}}, descriptor,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(post_law);
  const auto post_atoms =
      mwperf::testing::C17FixtureAccess::atoms(post_law.value());
  REQUIRE(post_atoms.size() == 1U);

  auto edge = mwperf::apply_exact_reduced_update(
      mwperf::testing::C17FixtureAccess::resolved_state_inputs(
          base.instance, state, opportunity, action, arrival,
          post_atoms.front().outcome, descriptor, schema,
          optimizer.value()));
  INFO((edge ? std::string{}
             : edge.error().code + ": " + edge.error().message));
  REQUIRE(edge);
  auto successor = schema.decode(edge.value().successor_state());
  REQUIRE(successor);

  CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
        expected_target);
  CHECK(successor.value().boundary_index == mwperf::BigNat{1U});
  CHECK(mwperf::testing::c17::same_phase(
      successor.value().arrival_phase, arrival.phase_after));
  REQUIRE(successor.value().resources.has_value());
  REQUIRE(successor.value().resources->coordinates().size() == 1U);
  const auto& successor_resource =
      successor.value().resources->coordinates().front();
  CHECK(successor_resource.workload() == expected_workload);
  CHECK(successor_resource.unused_capacity() == expected_unused.value());
  CHECK(successor_resource.lower_queue() == expected_lower);
  CHECK(successor_resource.capacity() == capacity);
}
