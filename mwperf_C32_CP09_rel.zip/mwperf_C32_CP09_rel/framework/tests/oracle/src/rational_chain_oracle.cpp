#include "mwperf_oracle/full_state_oracle.hpp"

#include <algorithm>
#include <cstddef>
#include <limits>
#include <string>
#include <utility>
#include <vector>

#include <boost/multiprecision/cpp_dec_float.hpp>

namespace mwperf_oracle {
namespace {

[[nodiscard]] BigInt absolute(BigInt value) {
  if (value < 0) {
    value = -value;
  }
  return value;
}

[[nodiscard]] BigInt greatest_common_divisor(BigInt lhs, BigInt rhs) {
  lhs = absolute(std::move(lhs));
  rhs = absolute(std::move(rhs));
  while (rhs != 0) {
    BigInt remainder = lhs % rhs;
    lhs = std::move(rhs);
    rhs = std::move(remainder);
  }
  return lhs;
}

template <typename T>
[[nodiscard]] Result<T> failure(std::string code, std::string message,
                                std::size_t states_examined = 0U,
                                std::size_t branches_examined = 0U) {
  return Result<T>::failure(OracleError{std::move(code), std::move(message),
                                        states_examined, branches_examined});
}

[[nodiscard]] Rational exact_quotient(const Rational& numerator,
                                      const Rational& denominator) {
  // All callers establish a nonzero denominator before reaching this helper.
  return checked_divide(numerator, denominator).value();
}

[[nodiscard]] Rational rational_size(std::size_t value) {
  return Rational(BigInt{value});
}

[[nodiscard]] Rational rational_power(Rational base, std::size_t exponent) {
  Rational result = Rational::one();
  while (exponent != 0U) {
    if ((exponent & 1U) != 0U) {
      result = result * base;
    }
    exponent >>= 1U;
    if (exponent != 0U) {
      base = base * base;
    }
  }
  return result;
}

[[nodiscard]] bool is_probability(const Rational& value) {
  return value >= Rational::zero() && value <= Rational::one();
}

[[nodiscard]] Result<void> validate_response(
    const ThreeBinScalarResponse& response) {
  if (!is_probability(response.s1) || !is_probability(response.s2) ||
      !is_probability(response.tail)) {
    return Result<void>::failure(
        OracleError{"oracle_invalid_probability",
                    "three-bin service probabilities must lie in [0,1]"});
  }
  return Result<void>::success();
}

[[nodiscard]] std::vector<std::vector<std::size_t>> compute_closed_classes(
    const std::vector<std::vector<Rational>>& probabilities) {
  const std::size_t dimension = probabilities.size();
  std::vector<std::size_t> index(dimension, dimension);
  std::vector<std::size_t> lowlink(dimension, 0U);
  std::vector<std::size_t> stack;
  std::vector<std::uint8_t> on_stack(dimension, 0U);
  std::vector<std::vector<std::size_t>> components;
  std::size_t next_index = 0U;

  const auto strong_connect = [&](const auto& self, std::size_t vertex) -> void {
    index[vertex] = next_index;
    lowlink[vertex] = next_index;
    ++next_index;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;

    for (std::size_t destination = 0U; destination < dimension;
         ++destination) {
      if (!probabilities[vertex][destination].is_positive()) {
        continue;
      }
      if (index[destination] == dimension) {
        self(self, destination);
        lowlink[vertex] =
            std::min(lowlink[vertex], lowlink[destination]);
      } else if (on_stack[destination] != 0U) {
        lowlink[vertex] = std::min(lowlink[vertex], index[destination]);
      }
    }

    if (lowlink[vertex] != index[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (!stack.empty()) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::sort(component.begin(), component.end());
    components.push_back(std::move(component));
  };

  for (std::size_t state = 0U; state < dimension; ++state) {
    if (index[state] == dimension) {
      strong_connect(strong_connect, state);
    }
  }

  std::vector<std::vector<std::size_t>> closed;
  for (auto& component : components) {
    std::vector<std::uint8_t> belongs(dimension, 0U);
    for (const std::size_t state : component) {
      belongs[state] = 1U;
    }
    bool is_closed = true;
    for (const std::size_t state : component) {
      for (std::size_t destination = 0U; destination < dimension;
           ++destination) {
        if (belongs[destination] == 0U &&
            probabilities[state][destination].is_positive()) {
          is_closed = false;
          break;
        }
      }
      if (!is_closed) {
        break;
      }
    }
    if (is_closed) {
      closed.push_back(std::move(component));
    }
  }
  std::sort(closed.begin(), closed.end());
  return closed;
}

[[nodiscard]] Result<void> validate_matrix_shape(
    const ExactTransitionMatrix& matrix) {
  const std::size_t dimension = matrix.probabilities.size();
  if (dimension == 0U || matrix.state_labels.size() != dimension) {
    return Result<void>::failure(OracleError{
        "oracle_invalid_finite_model",
        "an exact transition matrix needs one nonempty square state set"});
  }
  for (const auto& row : matrix.probabilities) {
    if (row.size() != dimension) {
      return Result<void>::failure(
          OracleError{"oracle_invalid_finite_model",
                      "the exact transition matrix is not square"});
    }
    Rational total = Rational::zero();
    for (const Rational& probability : row) {
      if (!probability.is_nonnegative()) {
        return Result<void>::failure(
            OracleError{"oracle_invalid_probability",
                        "transition probabilities must be nonnegative"});
      }
      total = total + probability;
    }
    if (total != Rational::one()) {
      return Result<void>::failure(
          OracleError{"oracle_mass_not_one",
                      "every exact transition row must have mass one"});
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::vector<Rational>> solve_one_closed_class(
    const ExactTransitionMatrix& matrix,
    const std::vector<std::size_t>& closed_class) {
  const std::size_t dimension = closed_class.size();
  if (dimension == 0U) {
    return failure<std::vector<Rational>>(
        "oracle_singular_invariant_system", "a closed class is empty");
  }

  std::vector<std::vector<Rational>> augmented(
      dimension, std::vector<Rational>(dimension + 1U, Rational::zero()));
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    const std::size_t destination = closed_class[equation];
    for (std::size_t unknown = 0U; unknown < dimension; ++unknown) {
      augmented[equation][unknown] =
          matrix.probabilities[closed_class[unknown]][destination];
      if (unknown == equation) {
        augmented[equation][unknown] =
            augmented[equation][unknown] - Rational::one();
      }
    }
  }
  for (std::size_t unknown = 0U; unknown < dimension; ++unknown) {
    augmented[dimension - 1U][unknown] = Rational::one();
  }
  augmented[dimension - 1U][dimension] = Rational::one();

  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension && augmented[pivot][column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return failure<std::vector<Rational>>(
          "oracle_singular_invariant_system",
          "the selected class invariant equations are singular");
    }
    if (pivot != column) {
      std::swap(augmented[pivot], augmented[column]);
    }
    const Rational pivot_value = augmented[column][column];
    for (std::size_t entry = column; entry <= dimension; ++entry) {
      augmented[column][entry] =
          exact_quotient(augmented[column][entry], pivot_value);
    }
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column || augmented[row][column].is_zero()) {
        continue;
      }
      const Rational factor = augmented[row][column];
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        augmented[row][entry] =
            augmented[row][entry] - factor * augmented[column][entry];
      }
    }
  }

  std::vector<Rational> solution(dimension, Rational::zero());
  for (std::size_t index = 0U; index < dimension; ++index) {
    solution[index] = augmented[index][dimension];
    if (!solution[index].is_nonnegative()) {
      return failure<std::vector<Rational>>(
          "oracle_singular_invariant_system",
          "the selected class produced a negative invariant mass");
    }
  }
  return Result<std::vector<Rational>>::success(std::move(solution));
}

[[nodiscard]] bool scalar_state_less(const ScalarStateAtom& lhs,
                                     const ScalarStateAtom& rhs) {
  if (lhs.state.backlog != rhs.state.backlog) {
    return lhs.state.backlog < rhs.state.backlog;
  }
  return lhs.state.phase < rhs.state.phase;
}

[[nodiscard]] std::vector<ScalarStateAtom> merge_scalar_states(
    std::vector<ScalarStateAtom> atoms) {
  atoms.erase(std::remove_if(atoms.begin(), atoms.end(),
                             [](const ScalarStateAtom& atom) {
                               return atom.mass.is_zero();
                             }),
              atoms.end());
  std::sort(atoms.begin(), atoms.end(), scalar_state_less);
  std::vector<ScalarStateAtom> merged;
  for (auto& atom : atoms) {
    if (!merged.empty() && merged.back().state == atom.state) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  return merged;
}

}  // namespace

Result<Rational> Rational::make(BigInt numerator, BigInt denominator) {
  if (denominator == 0) {
    return failure<Rational>("oracle_zero_denominator",
                             "a rational denominator cannot be zero");
  }
  return Result<Rational>::success(
      reduced(std::move(numerator), std::move(denominator)));
}

Rational Rational::reduced(BigInt numerator, BigInt denominator) {
  if (numerator == 0) {
    return Rational{};
  }
  if (denominator < 0) {
    numerator = -numerator;
    denominator = -denominator;
  }
  const BigInt divisor = greatest_common_divisor(numerator, denominator);
  return Rational(numerator / divisor, denominator / divisor, ReducedTag{});
}

std::string Rational::canonical() const {
  return numerator_.convert_to<std::string>() + "/" +
         denominator_.convert_to<std::string>();
}

long double Rational::to_long_double() const {
  using Decimal = boost::multiprecision::cpp_dec_float_100;
  const Decimal numerator(numerator_.convert_to<std::string>());
  const Decimal denominator(denominator_.convert_to<std::string>());
  return (numerator / denominator).convert_to<long double>();
}

Rational operator+(const Rational& lhs, const Rational& rhs) {
  return Rational::reduced(
      lhs.numerator_ * rhs.denominator_ + rhs.numerator_ * lhs.denominator_,
      lhs.denominator_ * rhs.denominator_);
}

Rational operator-(const Rational& lhs, const Rational& rhs) {
  return Rational::reduced(
      lhs.numerator_ * rhs.denominator_ - rhs.numerator_ * lhs.denominator_,
      lhs.denominator_ * rhs.denominator_);
}

Rational operator*(const Rational& lhs, const Rational& rhs) {
  return Rational::reduced(lhs.numerator_ * rhs.numerator_,
                           lhs.denominator_ * rhs.denominator_);
}

Result<Rational> checked_divide(const Rational& numerator,
                                const Rational& denominator) {
  if (denominator.is_zero()) {
    return failure<Rational>("oracle_division_by_zero",
                             "cannot divide by a zero rational");
  }
  return Result<Rational>::success(Rational::reduced(
      numerator.numerator_ * denominator.denominator_,
      numerator.denominator_ * denominator.numerator_));
}

Result<ExactTransitionMatrix> oracle_build_rational_matrix(
    const SmallFiniteModel& model) {
  const std::size_t dimension = model.state_labels.size();
  if (dimension == 0U || model.rows.size() != dimension ||
      model.state_and_mark_convention.empty()) {
    return failure<ExactTransitionMatrix>(
        "oracle_invalid_finite_model",
        "a finite model needs states, one row per state, and an explicit "
        "state/mark convention");
  }
  if (dimension > model.limits.maximum_states ||
      (dimension != 0U &&
       dimension > model.limits.maximum_matrix_cells / dimension)) {
    return failure<ExactTransitionMatrix>(
        "oracle_budget_exhausted",
        "the finite matrix exceeds its declared exact state/cell budget",
        dimension, 0U);
  }
  std::size_t transition_count = 0U;
  for (const auto& row : model.rows) {
    if (transition_count > model.limits.maximum_branches ||
        row.size() > model.limits.maximum_branches - transition_count) {
      return failure<ExactTransitionMatrix>(
          "oracle_budget_exhausted",
          "the finite matrix exceeds its declared transition-branch budget",
          dimension, model.limits.maximum_branches);
    }
    transition_count += row.size();
  }
  std::vector<std::string> labels = model.state_labels;
  std::sort(labels.begin(), labels.end());
  if (labels.front().empty() ||
      std::adjacent_find(labels.begin(), labels.end()) != labels.end()) {
    return failure<ExactTransitionMatrix>(
        "oracle_invalid_finite_model",
        "finite-model state labels must be nonempty and unique");
  }

  std::vector<std::vector<Rational>> probabilities(
      dimension, std::vector<Rational>(dimension, Rational::zero()));
  for (std::size_t origin = 0U; origin < dimension; ++origin) {
    Rational row_mass = Rational::zero();
    for (const FiniteTransitionAtom& atom : model.rows[origin]) {
      if (atom.destination >= dimension) {
        return failure<ExactTransitionMatrix>(
            "oracle_transition_out_of_range",
            "a finite transition destination is outside the state set");
      }
      if (!atom.mass.is_nonnegative()) {
        return failure<ExactTransitionMatrix>(
            "oracle_invalid_probability",
            "finite transition probabilities must be nonnegative");
      }
      row_mass = row_mass + atom.mass;
      probabilities[origin][atom.destination] =
          probabilities[origin][atom.destination] + atom.mass;
    }
    if (row_mass != Rational::one()) {
      return failure<ExactTransitionMatrix>(
          "oracle_mass_not_one",
          "every finite transition row must have exact mass one");
    }
  }

  ExactTransitionMatrix matrix;
  matrix.semantics = model.semantics;
  matrix.state_labels = model.state_labels;
  matrix.state_and_mark_convention = model.state_and_mark_convention;
  matrix.probabilities = std::move(probabilities);
  matrix.marked_rows = model.rows;
  matrix.closed_classes = compute_closed_classes(matrix.probabilities);
  matrix.states_examined = dimension;
  matrix.branches_examined = transition_count;
  return Result<ExactTransitionMatrix>::success(std::move(matrix));
}

Result<ExactInvariantLaw> oracle_solve_rational_invariant(
    const ExactTransitionMatrix& matrix, const ExactSelection& selection) {
  const Result<void> shape = validate_matrix_shape(matrix);
  if (!shape) {
    return Result<ExactInvariantLaw>::failure(shape.error());
  }
  const auto actual_closed = compute_closed_classes(matrix.probabilities);
  auto declared_closed = matrix.closed_classes;
  for (auto& closed_class : declared_closed) {
    std::sort(closed_class.begin(), closed_class.end());
  }
  std::sort(declared_closed.begin(), declared_closed.end());
  if (declared_closed != actual_closed) {
    return failure<ExactInvariantLaw>(
        "oracle_invalid_finite_model",
        "the declared closed classes do not match the exact matrix graph");
  }

  std::vector<Rational> class_weights(actual_closed.size(), Rational::zero());
  switch (selection.kind) {
    case SelectionKind::require_unique_closed_class:
      if (actual_closed.size() != 1U) {
        return failure<ExactInvariantLaw>(
            "oracle_unselected_closed_classes",
            "a reducible matrix requires an exact class selection");
      }
      class_weights.front() = Rational::one();
      break;
    case SelectionKind::closed_class_index:
      if (!selection.closed_class.has_value() ||
          selection.closed_class.value() >= actual_closed.size()) {
        return failure<ExactInvariantLaw>(
            "oracle_invalid_selection",
            "the selected closed-class index is absent or out of range");
      }
      class_weights[selection.closed_class.value()] = Rational::one();
      break;
    case SelectionKind::exact_closed_class_mixture: {
      if (selection.mixture.empty()) {
        return failure<ExactInvariantLaw>(
            "oracle_invalid_selection",
            "an exact closed-class mixture cannot be empty");
      }
      Rational total = Rational::zero();
      for (const auto& [class_index, weight] : selection.mixture) {
        if (class_index >= actual_closed.size()) {
          return failure<ExactInvariantLaw>(
              "oracle_invalid_selection",
              "a mixture closed-class index is out of range");
        }
        if (!weight.is_nonnegative()) {
          return failure<ExactInvariantLaw>(
              "oracle_invalid_probability",
              "closed-class mixture weights must be nonnegative");
        }
        class_weights[class_index] = class_weights[class_index] + weight;
        total = total + weight;
      }
      if (total != Rational::one()) {
        return failure<ExactInvariantLaw>(
            "oracle_mass_not_one",
            "closed-class mixture weights must have exact mass one");
      }
      break;
    }
  }

  std::vector<Rational> invariant(matrix.probabilities.size(),
                                  Rational::zero());
  for (std::size_t class_index = 0U; class_index < actual_closed.size();
       ++class_index) {
    if (class_weights[class_index].is_zero()) {
      continue;
    }
    auto local = solve_one_closed_class(matrix, actual_closed[class_index]);
    if (!local) {
      return Result<ExactInvariantLaw>::failure(local.error());
    }
    for (std::size_t offset = 0U;
         offset < actual_closed[class_index].size(); ++offset) {
      invariant[actual_closed[class_index][offset]] =
          invariant[actual_closed[class_index][offset]] +
          class_weights[class_index] * local.value()[offset];
    }
  }

  Rational total = Rational::zero();
  for (const Rational& mass : invariant) {
    if (!mass.is_nonnegative()) {
      return failure<ExactInvariantLaw>(
          "oracle_singular_invariant_system",
          "the exact invariant contains a negative mass");
    }
    total = total + mass;
  }
  if (total != Rational::one()) {
    return failure<ExactInvariantLaw>(
        "oracle_singular_invariant_system",
        "the exact invariant does not normalize to one");
  }
  for (std::size_t destination = 0U; destination < invariant.size();
       ++destination) {
    Rational image = Rational::zero();
    for (std::size_t origin = 0U; origin < invariant.size(); ++origin) {
      image = image +
              invariant[origin] * matrix.probabilities[origin][destination];
    }
    if (image != invariant[destination]) {
      return failure<ExactInvariantLaw>(
          "oracle_singular_invariant_system",
          "the computed law fails exact invariant verification");
    }
  }

  ExactInvariantLaw law;
  law.probabilities = std::move(invariant);
  law.closed_classes = actual_closed;
  law.selection = selection;
  return Result<ExactInvariantLaw>::success(std::move(law));
}

Rational ThreeBinScalarResponse::service(const BigInt& backlog) const {
  if (backlog <= 0) {
    return Rational::zero();
  }
  if (backlog == 1) {
    return s1;
  }
  if (backlog == 2) {
    return s2;
  }
  return tail;
}

Rational BernoulliScalarStationaryLaw::probability(std::size_t level) const {
  if (level == 0U) {
    return pi0;
  }
  if (level == 1U) {
    return pi1;
  }
  if (level == 2U) {
    return pi2;
  }
  return pi3 * rational_power(tail_ratio, level - 3U);
}

Result<BernoulliScalarStationaryLaw> oracle_solve_three_bin_bernoulli(
    const ThreeBinScalarResponse& response, const Rational& lambda) {
  const Result<void> response_valid = validate_response(response);
  if (!response_valid) {
    return Result<BernoulliScalarStationaryLaw>::failure(
        response_valid.error());
  }
  if (!is_probability(lambda)) {
    return failure<BernoulliScalarStationaryLaw>(
        "oracle_invalid_probability",
        "the Bernoulli arrival probability must lie in [0,1]");
  }

  BernoulliScalarStationaryLaw law;
  law.lambda = lambda;
  law.response = response;
  law.pi0 = Rational::zero();
  law.pi1 = Rational::zero();
  law.pi2 = Rational::zero();
  law.pi3 = Rational::zero();
  law.tail_ratio = Rational::zero();
  law.mean_backlog = Rational::zero();
  law.mean_departures = Rational::zero();

  if (lambda.is_zero()) {
    law.pi0 = Rational::one();
    return Result<BernoulliScalarStationaryLaw>::success(std::move(law));
  }

  if (lambda == Rational::one()) {
    std::size_t absorbing_level = 0U;
    if (response.s1 == Rational::one()) {
      absorbing_level = 1U;
    } else if (response.s2 == Rational::one()) {
      absorbing_level = 2U;
    } else if (response.tail == Rational::one()) {
      absorbing_level = 3U;
    } else {
      return failure<BernoulliScalarStationaryLaw>(
          "oracle_tail_not_stable",
          "unit-rate arrivals have no accessible absorbing service level");
    }
    if (absorbing_level == 1U) {
      law.pi1 = Rational::one();
    } else if (absorbing_level == 2U) {
      law.pi2 = Rational::one();
    } else {
      law.pi3 = Rational::one();
    }
    law.mean_backlog = rational_size(absorbing_level);
    law.mean_departures = Rational::one();
    return Result<BernoulliScalarStationaryLaw>::success(std::move(law));
  }

  const Rational one_minus_lambda = Rational::one() - lambda;
  const std::vector<Rational> service = {Rational::zero(), response.s1,
                                         response.s2, response.tail};

  std::optional<std::size_t> finite_boundary;
  if (response.s1 == Rational::one()) {
    finite_boundary = 1U;
  } else if (response.s2 == Rational::one()) {
    finite_boundary = 2U;
  } else if (response.tail == Rational::one()) {
    finite_boundary = 3U;
  }

  const std::size_t last_boundary = finite_boundary.value_or(3U);
  std::size_t class_floor = 0U;
  for (std::size_t level = 1U; level <= last_boundary; ++level) {
    if (service[level].is_zero()) {
      class_floor = level;
    }
  }
  if (!finite_boundary.has_value() && response.tail.is_zero()) {
    return failure<BernoulliScalarStationaryLaw>(
        "oracle_tail_not_stable",
        "a reachable zero-service tail has no finite invariant law");
  }

  std::vector<Rational> weights(4U, Rational::zero());
  weights[class_floor] = Rational::one();
  const std::size_t upper = finite_boundary.value_or(3U);
  for (std::size_t level = class_floor + 1U; level <= upper; ++level) {
    const Rational upward =
        lambda * (Rational::one() - service[level - 1U]);
    const Rational downward = one_minus_lambda * service[level];
    if (downward.is_zero()) {
      return failure<BernoulliScalarStationaryLaw>(
          "oracle_tail_not_stable",
          "a reachable birth-death edge has no downward probability");
    }
    weights[level] = weights[level - 1U] *
                     exact_quotient(upward, downward);
  }

  Rational normalization = Rational::zero();
  if (finite_boundary.has_value()) {
    for (std::size_t level = class_floor;
         level <= finite_boundary.value(); ++level) {
      normalization = normalization + weights[level];
    }
  } else {
    law.tail_ratio =
        exact_quotient(lambda * (Rational::one() - response.tail),
                       one_minus_lambda * response.tail);
    if (law.tail_ratio >= Rational::one()) {
      return failure<BernoulliScalarStationaryLaw>(
          "oracle_tail_not_stable",
          "the constant tail ratio is not strictly below one");
    }
    for (std::size_t level = class_floor; level < 3U; ++level) {
      normalization = normalization + weights[level];
    }
    normalization =
        normalization +
        exact_quotient(weights[3U], Rational::one() - law.tail_ratio);
  }

  if (normalization.is_zero()) {
    return failure<BernoulliScalarStationaryLaw>(
        "oracle_singular_invariant_system",
        "the scalar stationary normalization vanished");
  }
  law.pi0 = exact_quotient(weights[0U], normalization);
  law.pi1 = exact_quotient(weights[1U], normalization);
  law.pi2 = exact_quotient(weights[2U], normalization);
  law.pi3 = exact_quotient(weights[3U], normalization);

  law.mean_backlog = law.pi1 + rational_size(2U) * law.pi2;
  if (finite_boundary.has_value()) {
    if (finite_boundary.value() == 3U) {
      law.mean_backlog =
          law.mean_backlog + rational_size(3U) * law.pi3;
    }
    law.mean_departures = law.pi1 * response.s1 + law.pi2 * response.s2 +
                          law.pi3 * response.tail;
  } else {
    const Rational one_minus_ratio = Rational::one() - law.tail_ratio;
    const Rational tail_mass = exact_quotient(law.pi3, one_minus_ratio);
    const Rational tail_first_moment =
        law.pi3 *
        (exact_quotient(rational_size(3U), one_minus_ratio) +
         exact_quotient(law.tail_ratio,
                        one_minus_ratio * one_minus_ratio));
    law.mean_backlog = law.mean_backlog + tail_first_moment;
    law.mean_departures = law.pi1 * response.s1 + law.pi2 * response.s2 +
                          tail_mass * response.tail;
  }
  if (law.mean_departures != lambda) {
    return failure<BernoulliScalarStationaryLaw>(
        "oracle_singular_invariant_system",
        "the scalar invariant fails the exact flow-balance check");
  }
  return Result<BernoulliScalarStationaryLaw>::success(std::move(law));
}

Rational Batch012StationaryLaw::probability(std::size_t level) const {
  if (level == 0U) {
    return pi0;
  }
  if (level == 1U) {
    return pi1;
  }
  return pi2 * rational_power(tail_ratio, level - 2U);
}

Result<Batch012StationaryLaw> oracle_solve_work_conserving_batch_012(
    std::span<const Rational> batch_probabilities) {
  if (batch_probabilities.size() != 3U) {
    return failure<Batch012StationaryLaw>(
        "oracle_invalid_finite_model",
        "the work-conserving batch fixture requires masses for 0, 1, and 2");
  }
  Rational total = Rational::zero();
  for (const Rational& probability : batch_probabilities) {
    if (!probability.is_nonnegative()) {
      return failure<Batch012StationaryLaw>(
          "oracle_invalid_probability",
          "batch-arrival probabilities must be nonnegative");
    }
    total = total + probability;
  }
  if (total != Rational::one()) {
    return failure<Batch012StationaryLaw>(
        "oracle_mass_not_one",
        "the batch-arrival probabilities must have exact mass one");
  }

  const Rational p0 = batch_probabilities[0U];
  const Rational p1 = batch_probabilities[1U];
  const Rational p2 = batch_probabilities[2U];
  const Rational arrival_mean = p1 + rational_size(2U) * p2;
  if (arrival_mean >= Rational::one() || p0.is_zero()) {
    return failure<Batch012StationaryLaw>(
        "oracle_tail_not_stable",
        "work conservation requires batch-arrival mean strictly below one");
  }

  Batch012StationaryLaw law;
  law.arrival_zero = p0;
  law.arrival_one = p1;
  law.arrival_two = p2;
  law.pi0 = Rational::one() - arrival_mean;
  law.pi1 = law.pi0 * exact_quotient(Rational::one() - p0, p0);
  law.pi2 = exact_quotient(
      law.pi1 - p1 * (law.pi0 + law.pi1), p0);
  law.tail_ratio = exact_quotient(p2, p0);
  if (!law.pi2.is_nonnegative() || law.tail_ratio >= Rational::one()) {
    return failure<Batch012StationaryLaw>(
        "oracle_tail_not_stable",
        "the batch fixture does not define a nonnegative summable tail");
  }

  const Rational one_minus_ratio = Rational::one() - law.tail_ratio;
  const Rational normalization =
      law.pi0 + law.pi1 + exact_quotient(law.pi2, one_minus_ratio);
  if (normalization != Rational::one()) {
    return failure<Batch012StationaryLaw>(
        "oracle_singular_invariant_system",
        "the batch stationary law fails exact normalization");
  }
  law.mean_backlog =
      law.pi1 +
      law.pi2 *
          (exact_quotient(rational_size(2U), one_minus_ratio) +
           exact_quotient(law.tail_ratio,
                          one_minus_ratio * one_minus_ratio));
  law.mean_departures = Rational::one() - law.pi0;
  if (law.mean_departures != arrival_mean) {
    return failure<Batch012StationaryLaw>(
        "oracle_singular_invariant_system",
        "the batch stationary law fails exact flow balance");
  }
  return Result<Batch012StationaryLaw>::success(std::move(law));
}

Result<ScalarTransientLaw> oracle_enumerate_scalar_temporal(
    const ThreeBinScalarResponse& response,
    const ScalarTemporalArrival& arrivals,
    std::vector<ScalarStateAtom> initial, std::size_t horizon,
    OracleLimits limits) {
  const Result<void> response_valid = validate_response(response);
  if (!response_valid) {
    return Result<ScalarTransientLaw>::failure(response_valid.error());
  }
  if (horizon > limits.maximum_horizon) {
    return failure<ScalarTransientLaw>(
        "oracle_budget_exhausted",
        "the scalar temporal horizon exceeds the oracle limit");
  }
  if (arrivals.rows.empty() || initial.empty()) {
    return failure<ScalarTransientLaw>(
        "oracle_invalid_temporal_arrival",
        "temporal arrivals and the initial law must be nonempty");
  }
  for (const auto& row : arrivals.rows) {
    if (row.empty()) {
      return failure<ScalarTransientLaw>(
          "oracle_invalid_temporal_arrival",
          "every temporal arrival phase needs a finite exact row");
    }
    Rational total = Rational::zero();
    for (const auto& atom : row) {
      if (atom.arrivals < 0 || atom.next_phase >= arrivals.rows.size()) {
        return failure<ScalarTransientLaw>(
            "oracle_invalid_temporal_arrival",
            "a temporal arrival atom has a negative batch or bad phase");
      }
      if (!atom.mass.is_nonnegative()) {
        return failure<ScalarTransientLaw>(
            "oracle_invalid_probability",
            "temporal arrival probabilities must be nonnegative");
      }
      total = total + atom.mass;
    }
    if (total != Rational::one()) {
      return failure<ScalarTransientLaw>(
          "oracle_mass_not_one",
          "every temporal arrival row must have exact mass one");
    }
  }

  Rational initial_mass = Rational::zero();
  for (const auto& atom : initial) {
    if (atom.state.backlog < 0 || atom.state.phase >= arrivals.rows.size()) {
      return failure<ScalarTransientLaw>(
          "oracle_invalid_temporal_arrival",
          "an initial scalar state has a negative backlog or bad phase");
    }
    if (!atom.mass.is_nonnegative()) {
      return failure<ScalarTransientLaw>(
          "oracle_invalid_probability",
          "initial scalar probabilities must be nonnegative");
    }
    initial_mass = initial_mass + atom.mass;
  }
  if (initial_mass != Rational::one()) {
    return failure<ScalarTransientLaw>(
        "oracle_mass_not_one", "the initial scalar law must have mass one");
  }
  initial = merge_scalar_states(std::move(initial));
  if (initial.size() > limits.maximum_states) {
    return failure<ScalarTransientLaw>(
        "oracle_budget_exhausted",
        "the initial scalar frontier exceeds the state budget",
        initial.size(), 0U);
  }

  ScalarTransientLaw law;
  law.frontiers.push_back(std::move(initial));
  std::size_t states_examined = law.frontiers.front().size();
  std::size_t branches_examined = 0U;
  for (std::size_t step = 0U; step < horizon; ++step) {
    const auto& current = law.frontiers.back();
    std::vector<ScalarStateAtom> successors;
    for (const ScalarStateAtom& state_atom : current) {
      const Rational service_probability =
          response.service(state_atom.state.backlog);
      const std::pair<BigInt, Rational> service_branches[2] = {
          {BigInt{0}, Rational::one() - service_probability},
          {BigInt{1}, service_probability}};
      for (const auto& [departure, service_mass] : service_branches) {
        if (service_mass.is_zero()) {
          continue;
        }
        if (departure != 0 && state_atom.state.backlog == 0) {
          continue;
        }
        for (const ScalarTemporalArrivalAtom& arrival :
             arrivals.rows[state_atom.state.phase]) {
          if (arrival.mass.is_zero()) {
            continue;
          }
          ++branches_examined;
          if (branches_examined > limits.maximum_branches) {
            return failure<ScalarTransientLaw>(
                "oracle_budget_exhausted",
                "scalar temporal enumeration exhausted its branch budget",
                states_examined, branches_examined);
          }
          ScalarStateAtom successor;
          successor.state.backlog =
              state_atom.state.backlog - departure + arrival.arrivals;
          successor.state.phase = arrival.next_phase;
          successor.mass =
              state_atom.mass * service_mass * arrival.mass;
          successors.push_back(std::move(successor));
        }
      }
    }
    successors = merge_scalar_states(std::move(successors));
    states_examined += successors.size();
    if (states_examined > limits.maximum_states) {
      return failure<ScalarTransientLaw>(
          "oracle_budget_exhausted",
          "scalar temporal enumeration exhausted its state budget",
          states_examined, branches_examined);
    }
    Rational mass = Rational::zero();
    for (const auto& successor : successors) {
      mass = mass + successor.mass;
    }
    if (mass != Rational::one()) {
      return failure<ScalarTransientLaw>(
          "oracle_mass_not_one",
          "a merged scalar temporal frontier lost exact mass",
          states_examined, branches_examined);
    }
    law.frontiers.push_back(std::move(successors));
  }
  return Result<ScalarTransientLaw>::success(std::move(law));
}

Result<Rational> oracle_length_biased_reward_mean(
    std::span<const std::pair<std::vector<BigInt>, Rational>> event_words) {
  auto summary = oracle_summarize_length_biased_words(event_words);
  if (!summary) {
    return Result<Rational>::failure(summary.error());
  }
  return Result<Rational>::success(summary.value().slot_reward_mean);
}

Result<LengthBiasedWordSummary> oracle_summarize_length_biased_words(
    std::span<const std::pair<std::vector<BigInt>, Rational>> event_words) {
  if (event_words.empty()) {
    return failure<LengthBiasedWordSummary>(
        "oracle_invalid_finite_model", "an event-word law cannot be empty");
  }
  Rational law_mass = Rational::zero();
  Rational weighted_length = Rational::zero();
  Rational weighted_reward = Rational::zero();
  LengthBiasedWordSummary summary;
  summary.event_word_probabilities.reserve(event_words.size());
  summary.slot_word_probabilities.reserve(event_words.size());
  for (const auto& [word, mass] : event_words) {
    if (word.empty()) {
      return failure<LengthBiasedWordSummary>(
          "oracle_invalid_finite_model",
          "a residence word must have positive length");
    }
    if (!mass.is_nonnegative()) {
      return failure<LengthBiasedWordSummary>(
          "oracle_invalid_probability",
          "event-word probabilities must be nonnegative");
    }
    summary.event_word_probabilities.push_back(mass);
    law_mass = law_mass + mass;
    weighted_length = weighted_length + mass * rational_size(word.size());
    BigInt reward = 0;
    for (const BigInt& value : word) {
      reward += value;
    }
    weighted_reward = weighted_reward + mass * Rational(std::move(reward));
  }
  if (law_mass != Rational::one()) {
    return failure<LengthBiasedWordSummary>(
        "oracle_mass_not_one", "the event-word law must have exact mass one");
  }
  if (weighted_length.is_zero()) {
    return failure<LengthBiasedWordSummary>(
        "oracle_division_by_zero", "the length-biased denominator is zero");
  }
  summary.mean_word_length = weighted_length;
  summary.slot_reward_mean =
      exact_quotient(weighted_reward, weighted_length);
  for (std::size_t index = 0U; index < event_words.size(); ++index) {
    summary.slot_word_probabilities.push_back(exact_quotient(
        summary.event_word_probabilities[index] *
            rational_size(event_words[index].first.size()),
        weighted_length));
  }
  return Result<LengthBiasedWordSummary>::success(std::move(summary));
}

Result<std::vector<PalmRankAtom>> oracle_packet_palm_ranks(
    std::span<const std::pair<BigInt, Rational>> batch_law) {
  if (batch_law.empty()) {
    return failure<std::vector<PalmRankAtom>>(
        "oracle_invalid_finite_model", "an admission batch law cannot be empty");
  }
  std::vector<std::pair<BigInt, Rational>> coalesced(batch_law.begin(),
                                                     batch_law.end());
  for (const auto& [batch, mass] : coalesced) {
    if (batch < 0) {
      return failure<std::vector<PalmRankAtom>>(
          "oracle_invalid_finite_model",
          "admission batches must be nonnegative integers");
    }
    if (!mass.is_nonnegative()) {
      return failure<std::vector<PalmRankAtom>>(
          "oracle_invalid_probability",
          "admission batch probabilities must be nonnegative");
    }
  }
  std::sort(coalesced.begin(), coalesced.end(),
            [](const auto& lhs, const auto& rhs) {
              return lhs.first < rhs.first;
            });
  std::vector<std::pair<BigInt, Rational>> unique;
  for (auto& atom : coalesced) {
    if (!unique.empty() && unique.back().first == atom.first) {
      unique.back().second = unique.back().second + atom.second;
    } else {
      unique.push_back(std::move(atom));
    }
  }

  Rational total = Rational::zero();
  Rational intensity = Rational::zero();
  BigInt packet_atoms = 0;
  for (const auto& [batch, mass] : unique) {
    total = total + mass;
    intensity = intensity + Rational(batch) * mass;
    if (!mass.is_zero()) {
      packet_atoms += batch;
    }
  }
  if (total != Rational::one()) {
    return failure<std::vector<PalmRankAtom>>(
        "oracle_mass_not_one", "the admission batch law must have mass one");
  }
  if (intensity.is_zero()) {
    return failure<std::vector<PalmRankAtom>>(
        "oracle_zero_admission_intensity",
        "packet-Palm ranks require positive admission intensity");
  }
  const BigInt branch_limit = BigInt{OracleLimits{}.maximum_branches};
  if (packet_atoms > branch_limit) {
    return failure<std::vector<PalmRankAtom>>(
        "oracle_budget_exhausted",
        "packet-Palm rank expansion exceeds the oracle branch budget", 0U,
        OracleLimits{}.maximum_branches + 1U);
  }

  std::vector<PalmRankAtom> result;
  result.reserve(packet_atoms.convert_to<std::size_t>());
  for (const auto& [batch, mass] : unique) {
    if (mass.is_zero()) {
      continue;
    }
    for (BigInt rank = 1; rank <= batch; ++rank) {
      result.push_back(
          PalmRankAtom{batch, rank, exact_quotient(mass, intensity)});
    }
  }
  return Result<std::vector<PalmRankAtom>>::success(std::move(result));
}

Result<Rational> oracle_fifo_tail_one_predecessor(
    std::size_t slots, const Rational& service_probability) {
  if (!is_probability(service_probability)) {
    return failure<Rational>(
        "oracle_invalid_probability",
        "the FIFO service probability must lie in [0,1]");
  }
  const Rational failure_probability =
      Rational::one() - service_probability;
  Rational tail = rational_power(failure_probability, slots);
  if (slots != 0U) {
    tail = tail + rational_size(slots) * service_probability *
                      rational_power(failure_probability, slots - 1U);
  }
  return Result<Rational>::success(std::move(tail));
}

Result<Rational> oracle_fifo_mean_one_predecessor(
    const Rational& service_probability) {
  if (!is_probability(service_probability)) {
    return failure<Rational>(
        "oracle_invalid_probability",
        "the FIFO service probability must lie in [0,1]");
  }
  if (service_probability.is_zero()) {
    return failure<Rational>(
        "oracle_infinite_fifo_mean",
        "a passive tag with a predecessor never departs at zero service rate");
  }
  return checked_divide(rational_size(2U), service_probability);
}

Result<PermanentActivityPalmSummary> oracle_permanent_activity_palm(
    const Rational& stationary_active_mass) {
  if (!is_probability(stationary_active_mass)) {
    return failure<PermanentActivityPalmSummary>(
        "oracle_invalid_probability",
        "the permanent-active mixture mass must lie in [0,1]");
  }
  if (stationary_active_mass.is_zero()) {
    return failure<PermanentActivityPalmSummary>(
        "oracle_zero_event_intensity",
        "a permanently inactive mixture has no event-Palm law");
  }
  PermanentActivityPalmSummary summary;
  summary.stationary_active_mass = stationary_active_mass;
  summary.stationary_event_intensity = stationary_active_mass;
  summary.palm_active_mass = Rational::one();
  summary.palm_next_gap_mean = Rational::one();
  return Result<PermanentActivityPalmSummary>::success(std::move(summary));
}

Result<ValidatedScalarResponseFixture>
oracle_validate_scalar_response_fixture(
    const ScalarResponseFixture& fixture,
    const ScalarResponseFixtureBindingContract& contract) {
  const auto missing = [](const std::string& identity) {
    return identity.empty();
  };
  if (missing(fixture.provider_identity) ||
      missing(fixture.construction_method_identity) ||
      missing(fixture.request_identity) || missing(fixture.artifact_identity) ||
      missing(fixture.plug_identity) || missing(fixture.descriptor_identity) ||
      missing(fixture.runtime_target) || missing(fixture.request_target) ||
      missing(fixture.configured_arrival_binding) ||
      missing(fixture.frozen_build_identity) ||
      missing(fixture.raw_product_identity) ||
      missing(fixture.deployed.product_identity) ||
      missing(contract.expected_provider_identity) ||
      missing(contract.expected_construction_method_identity) ||
      missing(contract.expected_request_identity) ||
      missing(contract.expected_artifact_identity) ||
      missing(contract.expected_plug_identity) ||
      missing(contract.expected_descriptor_identity) ||
      missing(contract.expected_runtime_target) ||
      missing(contract.expected_configured_arrival_binding) ||
      missing(contract.expected_frozen_build_identity) ||
      missing(contract.expected_raw_product_identity) ||
      missing(contract.expected_deployed_product_identity) ||
      std::any_of(
          contract.expected_coefficient_evidence_identity.begin(),
          contract.expected_coefficient_evidence_identity.end(), missing) ||
      (contract.expected_completion_identity.has_value() &&
       contract.expected_completion_identity->empty()) ||
      (contract.expected_recoding_identity.has_value() &&
       contract.expected_recoding_identity->empty())) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_missing_identity",
        "a scalar-response fixture and binding contract require every "
        "identity-bearing field");
  }

  if (fixture.provider_identity != contract.expected_provider_identity ||
      fixture.request_identity != contract.expected_request_identity ||
      fixture.artifact_identity != contract.expected_artifact_identity ||
      fixture.plug_identity != contract.expected_plug_identity ||
      fixture.descriptor_identity != contract.expected_descriptor_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_identity_binding",
        "the provider-bound request, artifact, plug, or descriptor identity "
        "differs from the comparison contract");
  }
  if (fixture.construction_method_identity !=
      contract.expected_construction_method_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_construction_binding",
        "the construction-method identity differs from the comparison "
        "contract");
  }
  if (fixture.producer_mode != contract.expected_producer_mode) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_producer_mode_binding",
        "the producer mode differs from the comparison contract");
  }

  if (contract.expected_scope != ScientificScope::surrogate_law ||
      fixture.scientific_scope != ScientificScope::surrogate_law ||
      fixture.scientific_scope != contract.expected_scope) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_scope_binding",
        "a deployed scalar closure is scoped only as a surrogate law; it "
        "cannot be relabelled as a physical result");
  }
  if (fixture.runtime_target != contract.expected_runtime_target ||
      fixture.request_target != contract.expected_runtime_target ||
      fixture.deployed_targets.size() != 1U ||
      fixture.deployed_targets.front() != contract.expected_runtime_target) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_target_binding",
        "the phase-free response must bind exactly the singleton runtime and "
        "request target");
  }
  if (fixture.configured_arrival_binding !=
      contract.expected_configured_arrival_binding) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_arrival_binding",
        "the configured arrival binding differs from the comparison "
        "contract");
  }
  if (fixture.frozen_build_identity !=
      contract.expected_frozen_build_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_build_binding",
        "the fixture does not name the contract's frozen build");
  }
  if (fixture.raw_product_identity !=
      contract.expected_raw_product_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_product_binding",
        "the raw response product differs from the comparison contract");
  }
  const Result<void> expected_response_valid =
      validate_response(contract.expected_deployed_response);
  if (!expected_response_valid) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_expected_response_invalid",
        "the binding contract's expected deployed response is not a "
        "probability triple");
  }
  if (fixture.deployed.response != contract.expected_deployed_response) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_deployed_value_binding",
        "the deployed phase-free coefficient triple differs from the exact "
        "binding contract");
  }
  if (fixture.proposal_bank_dependence !=
      contract.expected_proposal_bank_dependence) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_dependence_binding",
        "the proposal bank dependence differs from the exact comparison "
        "contract");
  }

  if (fixture.deployed.stage == ScalarCoefficientStage::projection_center ||
      fixture.deployed.stage == ScalarCoefficientStage::projected_mean) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_mean_stage_product",
        "projection-center and projected-mean vectors are not response "
        "coefficients");
  }
  if (fixture.deployed.product_identity !=
      contract.expected_deployed_product_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_product_binding",
        "the deployed point product differs from the comparison contract");
  }
  if (fixture.deployed.completion_identity !=
      contract.expected_completion_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_completion_binding",
        "the completion identity differs from the comparison contract");
  }
  if (fixture.deployed.recoding_identity !=
      contract.expected_recoding_identity) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_recoding_binding",
        "the recoding identity differs from the comparison contract");
  }
  switch (fixture.deployed.stage) {
    case ScalarCoefficientStage::raw_response:
      if (fixture.deployed.product_identity != fixture.raw_product_identity) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_product_binding",
            "a raw deployed point must name the exact raw product");
      }
      break;
    case ScalarCoefficientStage::nominal_response:
      if (!fixture.nominal_product_identity.has_value() ||
          fixture.nominal_product_identity->empty() ||
          fixture.deployed.product_identity !=
              *fixture.nominal_product_identity) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_product_binding",
            "a nominal deployed point must name the exact nominal product");
      }
      break;
    case ScalarCoefficientStage::recoded_response:
      if (!fixture.recoded_product_identity.has_value() ||
          fixture.recoded_product_identity->empty() ||
          fixture.deployed.product_identity !=
              *fixture.recoded_product_identity) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_product_binding",
            "a recoded deployed point must name the exact recoded product");
      }
      if (!fixture.deployed.recoding_identity.has_value() ||
          fixture.deployed.recoding_identity->empty()) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_recoding_binding",
            "a recoded deployed point requires an explicit recoding "
            "identity");
      }
      break;
    case ScalarCoefficientStage::projection_center:
    case ScalarCoefficientStage::projected_mean:
      // Rejected before product lookup so the diagnostic is independent of a
      // copied mean-stage product identity.
      break;
  }

  const auto valid_mean_product = [](const auto& product) {
    if (product.product_identity.empty() ||
        product.ordered_construction_targets.empty() ||
        product.exact_values.size() !=
            product.ordered_construction_targets.size()) {
      return false;
    }
    for (std::size_t index = 0U;
         index < product.ordered_construction_targets.size(); ++index) {
      if (product.ordered_construction_targets[index].empty() ||
          std::find(product.ordered_construction_targets.begin(),
                    product.ordered_construction_targets.begin() +
                        static_cast<std::ptrdiff_t>(index),
                    product.ordered_construction_targets[index]) !=
              product.ordered_construction_targets.begin() +
                  static_cast<std::ptrdiff_t>(index) ||
          !product.exact_values[index].is_nonnegative()) {
        return false;
      }
    }
    return true;
  };
  if (fixture.projection_center != contract.expected_projection_center ||
      fixture.projected_mean != contract.expected_projected_mean) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_mean_product_binding",
        "the projection-center or projected-mean vector differs from the "
        "exact comparison contract");
  }
  if (fixture.projection_center.has_value()) {
    const auto& center = *fixture.projection_center;
    const bool source_is_raw =
        center.response_source_product_identity ==
        fixture.raw_product_identity;
    const bool source_is_nominal =
        fixture.nominal_product_identity.has_value() &&
        center.response_source_product_identity ==
            *fixture.nominal_product_identity;
    if (!valid_mean_product(center) ||
        (!source_is_raw && !source_is_nominal) ||
        center.product_identity == fixture.raw_product_identity ||
        center.product_identity == fixture.deployed.product_identity) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_mean_product_binding",
          "a projection center must be a distinct ordered mean vector with "
          "an exact raw or nominal response source");
    }
  }
  if (fixture.projected_mean.has_value()) {
    const auto& mean = *fixture.projected_mean;
    if (!fixture.projection_center.has_value() ||
        !valid_mean_product(mean) ||
        mean.projection_center_parent_identity !=
            fixture.projection_center->product_identity ||
        mean.ordered_construction_targets !=
            fixture.projection_center->ordered_construction_targets ||
        mean.product_identity == fixture.projection_center->product_identity ||
        mean.product_identity == fixture.raw_product_identity ||
        mean.product_identity == fixture.deployed.product_identity) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_mean_product_binding",
          "a projected mean must be a distinct ordered mean vector bound to "
          "its projection center");
    }
  }

  if (fixture.metric_capabilities !=
      contract.expected_metric_capabilities) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_metric_manifest_binding",
        "the accepted metric/backend manifest differs from the exact "
        "comparison contract");
  }
  if (fixture.metric_capabilities.backend_identity.empty() ||
      !std::is_sorted(
          fixture.metric_capabilities.supported_requests.begin(),
          fixture.metric_capabilities.supported_requests.end()) ||
      std::adjacent_find(
          fixture.metric_capabilities.supported_requests.begin(),
          fixture.metric_capabilities.supported_requests.end()) !=
          fixture.metric_capabilities.supported_requests.end()) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_metric_manifest_invalid",
        "the scalar metric manifest needs one backend identity and a "
        "canonical duplicate-free request set");
  }
  for (const ScalarMetricRequestKind request :
       fixture.metric_capabilities.supported_requests) {
    if (request == ScalarMetricRequestKind::joint_schedule ||
        request == ScalarMetricRequestKind::cross_target_law ||
        request == ScalarMetricRequestKind::lagged_correlation ||
        request == ScalarMetricRequestKind::arbitrary_queue_tail ||
        request == ScalarMetricRequestKind::physical_fifo_delay) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_metric_manifest_invalid",
          "a scalar-response backend cannot declare a joint, cross-target, "
          "lagged, arbitrary-tail, or physical-FIFO metric");
    }
  }

  const Result<void> response_valid = validate_response(fixture.deployed.response);
  if (!response_valid) {
    return Result<ValidatedScalarResponseFixture>::failure(
        response_valid.error());
  }

  const std::array<Rational, 3U> deployed_values{
      fixture.deployed.response.s1, fixture.deployed.response.s2,
      fixture.deployed.response.tail};
  bool every_raw_value_is_an_exact_deployable_point = true;
  bool needs_completion = false;
  std::optional<std::string> simultaneous_allocation;
  std::optional<std::size_t> simultaneous_family_size;
  std::array<ScalarPopulationConditioningStatus, 3U>
      proposal_conditioning{};
  for (std::size_t index = 0U; index < fixture.coefficients.size(); ++index) {
    const ScalarCoefficientEvidence& coefficient =
        fixture.coefficients[index];
    if (coefficient.bin != static_cast<ScalarCoefficientBin>(index)) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_bin_binding",
          "the three raw origins must appear in one, two, tail-from-three "
          "order");
    }
    if (coefficient.evidence_identity.empty()) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_missing_identity",
          "every coefficient origin requires an evidence identity");
    }
    if (coefficient.evidence_identity !=
        contract.expected_coefficient_evidence_identity[index]) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_evidence_binding",
          "a coefficient origin names different evidence from the "
          "comparison contract");
    }
    if (coefficient.frozen_build_identity !=
            fixture.frozen_build_identity ||
        coefficient.frozen_build_identity !=
            contract.expected_frozen_build_identity) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_build_binding",
          "a coefficient origin was taken from a different frozen build");
    }
    if (coefficient.source_product_identity !=
            fixture.raw_product_identity ||
        coefficient.source_product_identity !=
            contract.expected_raw_product_identity) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_product_binding",
          "a coefficient origin was taken from a different raw product");
    }
    if (coefficient.observation_source ==
            ScalarObservationSource::empirical_average &&
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::proved_zero) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_empirical_proved_zero",
          "an empirical average of zero is not an exact population-zero "
          "proof");
    }

    const bool has_point = coefficient.raw_point.has_value();
    const bool has_band = coefficient.proposal_band.has_value();
    const bool exact_point =
        coefficient.observation_source ==
            ScalarObservationSource::exact_population &&
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::proved_positive &&
        coefficient.raw_value_status == ScalarRawValueStatus::exact_point &&
        has_point && !has_band;
    const bool exact_interval =
        coefficient.observation_source ==
            ScalarObservationSource::exact_population &&
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::proved_positive &&
        coefficient.raw_value_status == ScalarRawValueStatus::interval_only &&
        !has_point && has_band;
    const bool empirical_interval =
        coefficient.observation_source ==
            ScalarObservationSource::empirical_average &&
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::positive_with_confidence &&
        coefficient.raw_value_status == ScalarRawValueStatus::interval_only &&
        !has_point && has_band;
    const bool unresolved_interval =
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::unresolved &&
        coefficient.raw_value_status == ScalarRawValueStatus::interval_only &&
        !has_point && has_band;
    const bool proved_zero_absent =
        coefficient.observation_source ==
            ScalarObservationSource::exact_population &&
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::proved_zero &&
        coefficient.raw_value_status == ScalarRawValueStatus::absent &&
        !has_point && !has_band;
    const bool unresolved_absent =
        coefficient.population_conditioning ==
            ScalarPopulationConditioningStatus::unresolved &&
        coefficient.raw_value_status == ScalarRawValueStatus::absent &&
        !has_point && !has_band;
    if (!(exact_point || exact_interval || empirical_interval ||
          unresolved_interval || proved_zero_absent ||
          unresolved_absent)) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_status_combination",
          "the proposal source, population status, raw-value status, and "
          "evidence shape are inconsistent");
    }

    if (has_point && !is_probability(*coefficient.raw_point)) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_invalid_probability",
          "a raw response point must lie in [0,1]");
    }
    if (has_band) {
      const ScalarProposalBand& band = *coefficient.proposal_band;
      if (band.scope != ScalarProposalBandScope::proposal_raw) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_scope_binding",
            "a proposal interval cannot be relabelled as a deployed or "
            "physical interval");
      }
      if (band.source_product_identity != fixture.raw_product_identity ||
          band.source_product_identity !=
              coefficient.source_product_identity) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_product_binding",
            "a proposal interval must bind the exact raw product");
      }
      if (band.frozen_build_identity != fixture.frozen_build_identity ||
          band.frozen_build_identity !=
              coefficient.frozen_build_identity) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_build_binding",
            "a proposal interval must bind the exact frozen build");
      }
      if (band.evidence_identity.empty()) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_missing_identity",
            "a proposal interval requires its own evidence identity");
      }
      if (!contract.expected_proposal_band_evidence_identity[index]
               .has_value() ||
          band.evidence_identity !=
              *contract.expected_proposal_band_evidence_identity[index]) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_evidence_binding",
            "a proposal interval names different evidence from the "
            "comparison contract");
      }
      if (!is_probability(band.lower) || !is_probability(band.upper) ||
          band.upper < band.lower) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_invalid_interval",
            "a proposal interval must be an ordered subset of [0,1]");
      }
      if (coefficient.observation_source ==
          ScalarObservationSource::empirical_average) {
        if (fixture.proposal_bank_dependence ==
            ScalarProposalBankDependence::not_applicable) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_dependence_claim",
              "an empirical proposal interval requires its actual bank "
              "dependence classification");
        }
        if (band.asymptotic_premise ==
                ScalarProposalAsymptoticPremise::iid_lln &&
            fixture.proposal_bank_dependence !=
                ScalarProposalBankDependence::iid) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_dependence_claim",
              "a serial/non-IID proposal bank cannot be advertised under an "
              "IID/LLN premise");
        }
        if (band.asymptotic_premise ==
                ScalarProposalAsymptoticPremise::dependence_adjusted &&
            fixture.proposal_bank_dependence !=
                ScalarProposalBankDependence::serial_non_iid) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_dependence_claim",
              "a dependence-adjusted premise requires a declared serial/non-"
              "IID proposal bank");
        }
        if (band.asymptotic_premise ==
                ScalarProposalAsymptoticPremise::not_applicable ||
            band.coverage == ScalarProposalCoverage::deterministic) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_dependence_claim",
              "an empirical interval requires a statistical premise and "
              "cannot claim deterministic coverage");
        }
      } else if (band.asymptotic_premise !=
                     ScalarProposalAsymptoticPremise::not_applicable ||
                 band.coverage != ScalarProposalCoverage::deterministic) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_dependence_claim",
            "an exact-population interval cannot claim an IID/LLN or "
            "sampling-coverage premise");
      }

      if (band.coverage == ScalarProposalCoverage::simultaneous) {
        if (!band.simultaneous_allocation_identity.has_value() ||
            band.simultaneous_allocation_identity->empty() ||
            band.simultaneous_family_size == 0U) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_simultaneous_allocation",
              "simultaneous coverage requires an explicit nonempty "
              "allocation identity and family size");
        }
        if (!simultaneous_allocation.has_value()) {
          simultaneous_allocation =
              band.simultaneous_allocation_identity;
          simultaneous_family_size = band.simultaneous_family_size;
        } else if (simultaneous_allocation !=
                       band.simultaneous_allocation_identity ||
                   simultaneous_family_size !=
                       band.simultaneous_family_size) {
          return failure<ValidatedScalarResponseFixture>(
              "oracle_scalar_simultaneous_allocation",
              "simultaneous proposal bands must share one allocation "
              "identity and family size");
        }
      } else if (band.simultaneous_allocation_identity.has_value() ||
                 band.simultaneous_family_size != 0U) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_simultaneous_allocation",
            "marginal or deterministic coverage cannot retain a "
            "simultaneous-allocation claim");
      }
      if (!contract.expected_proposal_bands[index].has_value() ||
          band != *contract.expected_proposal_bands[index]) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_band_binding",
            "the proposal interval or its statistical scope differs from "
            "the exact comparison contract");
      }
    } else if (contract.expected_proposal_band_evidence_identity[index]
                   .has_value() ||
               contract.expected_proposal_bands[index].has_value()) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_evidence_binding",
          "the contract's proposal-band evidence is absent from the "
          "coefficient origin");
    }

    proposal_conditioning[index] = coefficient.population_conditioning;
    if (!exact_point) {
      every_raw_value_is_an_exact_deployable_point = false;
      needs_completion = true;
    }
  }

  if (fixture.deployed.stage == ScalarCoefficientStage::raw_response) {
    if (!every_raw_value_is_an_exact_deployable_point) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_interval_not_deployable",
          "an interval-only or absent raw origin is not a point-valued "
          "deployed response");
    }
    for (std::size_t index = 0U; index < fixture.coefficients.size(); ++index) {
      if (*fixture.coefficients[index].raw_point != deployed_values[index]) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_scalar_coefficient_value",
            "the raw deployed point differs from its exact raw coefficient");
      }
    }
  } else if (needs_completion &&
             (!fixture.deployed.completion_identity.has_value() ||
              fixture.deployed.completion_identity->empty())) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_completion_binding",
        "a nominal or recoded point derived from a non-point raw origin "
        "requires an authorized completion identity");
  }

  if (fixture.deployed_stationary_conditioning !=
      contract.expected_deployed_stationary_conditioning) {
    return failure<ValidatedScalarResponseFixture>(
        "oracle_scalar_stationary_binding",
        "the deployed stationary conditioning record differs from the exact "
        "law/selection binding contract");
  }
  if (fixture.deployed_stationary_conditioning.has_value()) {
    const auto& conditioning =
        *fixture.deployed_stationary_conditioning;
    if (conditioning.stationary_law_identity.empty() ||
        conditioning.selection_identity.empty() ||
        conditioning.deployed_response_product_identity.empty() ||
        conditioning.deployed_response_product_identity !=
            fixture.deployed.product_identity) {
      return failure<ValidatedScalarResponseFixture>(
          "oracle_scalar_stationary_binding",
          "stationary conditioning must name its law, selection, and exact "
          "deployed response product");
    }
    for (const auto& mass : conditioning.bin_mass) {
      if (mass.has_value() && !is_probability(*mass)) {
        return failure<ValidatedScalarResponseFixture>(
            "oracle_invalid_probability",
            "a deployed stationary bin mass must lie in [0,1]");
      }
    }
  }

  ValidatedScalarResponseFixture validated;
  validated.response = fixture.deployed.response;
  validated.deployed_stage = fixture.deployed.stage;
  validated.deployed_product_identity = fixture.deployed.product_identity;
  validated.proposal_conditioning = proposal_conditioning;
  validated.coefficient_evidence = fixture.coefficients;
  validated.completion_identity = fixture.deployed.completion_identity;
  validated.recoding_identity = fixture.deployed.recoding_identity;
  validated.projection_center = fixture.projection_center;
  validated.projected_mean = fixture.projected_mean;
  validated.metric_capabilities = fixture.metric_capabilities;
  validated.deployed_stationary_conditioning =
      fixture.deployed_stationary_conditioning;
  return Result<ValidatedScalarResponseFixture>::success(
      std::move(validated));
}

ScalarMetricCapabilityDecision oracle_scalar_fixture_metric_capability(
    const ValidatedScalarResponseFixture& fixture,
    const ScalarMetricRequestKind request) noexcept {
  switch (request) {
    case ScalarMetricRequestKind::joint_schedule:
      return {false,
              ScalarMetricCapabilityReason::
                  joint_schedule_not_in_scalar_contract};
    case ScalarMetricRequestKind::cross_target_law:
      return {false,
              ScalarMetricCapabilityReason::
                  cross_target_law_not_in_scalar_contract};
    case ScalarMetricRequestKind::lagged_correlation:
      return {false,
              ScalarMetricCapabilityReason::
                  lagged_correlation_not_in_scalar_contract};
    case ScalarMetricRequestKind::arbitrary_queue_tail:
      return {false,
              ScalarMetricCapabilityReason::
                  arbitrary_tail_not_in_scalar_contract};
    case ScalarMetricRequestKind::physical_fifo_delay:
      return {false,
              ScalarMetricCapabilityReason::
                  physical_fifo_not_in_scalar_contract};
    case ScalarMetricRequestKind::stationary_mean_backlog:
    case ScalarMetricRequestKind::stationary_mean_departures:
    case ScalarMetricRequestKind::backlog_conditioned_service:
      break;
  }
  if (std::find(fixture.metric_capabilities.supported_requests.begin(),
                fixture.metric_capabilities.supported_requests.end(),
                request) ==
      fixture.metric_capabilities.supported_requests.end()) {
    return {false, ScalarMetricCapabilityReason::request_not_declared};
  }
  return {true, ScalarMetricCapabilityReason::supported};
}

}  // namespace mwperf_oracle
