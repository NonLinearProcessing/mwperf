#include "mwperf_oracle/full_state_oracle.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <map>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace mwperf_oracle {
namespace {

[[nodiscard]] ConformanceReport failure_report(
    const ComparisonContract& contract, std::string code,
    std::string message, std::optional<std::size_t> mismatch = std::nullopt,
    std::optional<std::string> path = std::nullopt) {
  return ConformanceReport{false,
                           std::move(code),
                           std::move(message),
                           mismatch,
                           std::move(path),
                           contract.domain,
                           contract.scope,
                           std::nullopt,
                           false};
}

[[nodiscard]] ConformanceReport success_report(
    const ComparisonContract& contract) {
  return ConformanceReport{true,
                           "oracle_conformant",
                           "the production artifact conforms to the exact "
                           "oracle under the declared comparison contract",
                           std::nullopt,
                           std::nullopt,
                           contract.domain,
                           contract.scope,
                           std::nullopt,
                           false};
}

[[nodiscard]] std::string indexed_path(const std::string_view prefix,
                                       const std::size_t index) {
  return std::string(prefix) + '/' + std::to_string(index);
}

[[nodiscard]] std::string rational_mismatch_message(
    const Rational& expected, const Rational& actual) {
  return "expected " + expected.canonical() + ", observed " +
         actual.canonical();
}

[[nodiscard]] std::string_view exact_mismatch_code(
    const ComparisonContract& contract) noexcept {
  return contract.arithmetic == ArithmeticMode::distributional_identity
             ? "oracle_distribution_mismatch"
             : "oracle_exact_mismatch";
}

[[nodiscard]] ConformanceReport compare_discrete(
    const ExactDiscreteArtifact& expected,
    const ExactDiscreteArtifact& actual,
    const ComparisonContract& contract) {
  if (expected.coordinates.size() != actual.coordinates.size()) {
    return failure_report(
        contract, std::string(exact_mismatch_code(contract)),
        "the exact discrete artifacts have different coordinate counts",
        std::min(expected.coordinates.size(), actual.coordinates.size()),
        "/payload/coordinates/size");
  }
  for (std::size_t index = 0U; index < expected.coordinates.size(); ++index) {
    if (expected.coordinates[index] != actual.coordinates[index]) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "expected " + expected.coordinates[index] + ", observed " +
              actual.coordinates[index],
          index, indexed_path("/payload/coordinates", index));
    }
  }
  return success_report(contract);
}

[[nodiscard]] ConformanceReport compare_vector(
    const ExactVectorArtifact& expected, const ExactVectorArtifact& actual,
    const ComparisonContract& contract) {
  if (expected.values.size() != actual.values.size()) {
    return failure_report(
        contract, std::string(exact_mismatch_code(contract)),
        "the exact rational vectors have different coordinate counts",
        std::min(expected.values.size(), actual.values.size()),
        "/payload/values/size");
  }
  for (std::size_t index = 0U; index < expected.values.size(); ++index) {
    if (expected.values[index] != actual.values[index]) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          rational_mismatch_message(expected.values[index],
                                    actual.values[index]),
          index, indexed_path("/payload/values", index));
    }
  }
  return success_report(contract);
}

[[nodiscard]] bool is_probability(const Rational& value) {
  return value.is_nonnegative() && value <= Rational::one();
}

[[nodiscard]] std::optional<ConformanceReport> validate_proposal_raw(
    const ProposalRawArtifact& proposal, const ComparisonContract& contract,
    const std::string_view owner_path) {
  const std::string base(owner_path);
  if (proposal.frozen_build_identity.empty()) {
    return failure_report(contract, "oracle_invalid_proposal_raw",
                          "proposal-raw evidence omits its frozen build "
                          "identity",
                          std::nullopt, base + "/frozen_build_identity");
  }
  if (proposal.target_identity.empty()) {
    return failure_report(contract, "oracle_invalid_proposal_raw",
                          "proposal-raw evidence omits its exact target "
                          "identity",
                          std::nullopt, base + "/target_identity");
  }
  if (proposal.evidence_identity.empty()) {
    return failure_report(contract, "oracle_invalid_proposal_raw",
                          "proposal-raw evidence omits its immutable evidence "
                          "identity",
                          std::nullopt, base + "/evidence_identity");
  }
  if (proposal.band_scope !=
      ProposalBandScope::exact_frozen_raw_coefficient) {
    return failure_report(
        contract, "oracle_invalid_proposal_raw",
        "only the exact frozen raw proposal coefficient may inhabit "
        "proposal-raw scope",
        std::nullopt, base + "/band_scope");
  }
  if (proposal.value_status == ProposalRawValueStatus::exact_point) {
    if (!proposal.exact_point.has_value() ||
        proposal.interval_lower.has_value() ||
        proposal.interval_upper.has_value() ||
        !is_probability(*proposal.exact_point)) {
      return failure_report(
          contract, "oracle_invalid_proposal_raw",
          "an exact proposal point requires exactly one value in [0,1] and "
          "cannot also carry interval endpoints",
          std::nullopt, base + "/value");
    }
    return std::nullopt;
  }
  if (proposal.exact_point.has_value() ||
      !proposal.interval_lower.has_value() ||
      !proposal.interval_upper.has_value() ||
      !is_probability(*proposal.interval_lower) ||
      !is_probability(*proposal.interval_upper) ||
      *proposal.interval_lower > *proposal.interval_upper) {
    return failure_report(
        contract, "oracle_invalid_proposal_raw",
        "an interval-only proposal requires ordered [0,1] endpoints and no "
        "designated point",
        std::nullopt, base + "/interval");
  }
  return std::nullopt;
}

[[nodiscard]] ConformanceReport compare_proposal_raw(
    const ProposalRawArtifact& expected, const ProposalRawArtifact& actual,
    const ComparisonContract& contract) {
  if (auto invalid =
          validate_proposal_raw(expected, contract, "/oracle/payload")) {
    return std::move(*invalid);
  }
  if (auto invalid =
          validate_proposal_raw(actual, contract, "/production/payload")) {
    return std::move(*invalid);
  }
  if (expected.frozen_build_identity != actual.frozen_build_identity) {
    return failure_report(
        contract, "oracle_proposal_binding_mismatch",
        "proposal evidence was reused across frozen build identities",
        std::nullopt, "/payload/frozen_build_identity");
  }
  if (expected.target_identity != actual.target_identity) {
    return failure_report(contract, "oracle_proposal_binding_mismatch",
                          "proposal evidence was reused across target "
                          "identities",
                          std::nullopt, "/payload/target_identity");
  }
  if (expected.bin != actual.bin) {
    return failure_report(contract, "oracle_proposal_binding_mismatch",
                          "proposal evidence was reused across response bins",
                          std::nullopt, "/payload/bin");
  }
  if (expected.band_scope != actual.band_scope ||
      expected.value_status != actual.value_status ||
      expected.evidence_identity != actual.evidence_identity) {
    return failure_report(
        contract, "oracle_proposal_binding_mismatch",
        "proposal value form, band scope, or evidence identity differs",
        std::nullopt, "/payload/proposal_binding");
  }
  if (expected.exact_point != actual.exact_point ||
      expected.interval_lower != actual.interval_lower ||
      expected.interval_upper != actual.interval_upper) {
    return failure_report(contract, "oracle_distribution_mismatch",
                          "the exact proposal point or interval differs",
                          0U, "/payload/value");
  }
  return success_report(contract);
}

using CanonicalLaw = std::map<std::string, Rational, std::less<>>;

[[nodiscard]] bool canonical_atoms(
    const std::vector<std::pair<std::string, Rational>>& atoms,
    const bool require_nonempty, CanonicalLaw& result, Rational& total_mass,
    std::string& error_message) {
  result.clear();
  total_mass = Rational::zero();
  if (require_nonempty && atoms.empty()) {
    error_message = "an exact probability law cannot be empty";
    return false;
  }
  for (const auto& [label, mass] : atoms) {
    if (label.empty()) {
      error_message = "an exact-law atom has an empty state/mark label";
      return false;
    }
    if (!mass.is_nonnegative()) {
      error_message = "an exact-law atom has negative mass";
      return false;
    }
    const auto [position, inserted] = result.emplace(label, mass);
    if (!inserted) {
      position->second = position->second + mass;
    }
    total_mass = total_mass + mass;
  }
  for (auto position = result.begin(); position != result.end();) {
    if (position->second.is_zero()) {
      position = result.erase(position);
    } else {
      ++position;
    }
  }
  if (require_nonempty && result.empty()) {
    error_message = "an exact probability law has no positive-mass atom";
    return false;
  }
  return true;
}

[[nodiscard]] bool canonical_law(const ExactLawArtifact& artifact,
                                 CanonicalLaw& result,
                                 std::string& error_message) {
  Rational total = Rational::zero();
  if (!canonical_atoms(artifact.atoms, true, result, total, error_message)) {
    return false;
  }
  if (total != Rational::one()) {
    error_message = "an exact probability law must have exact mass one";
    return false;
  }
  return true;
}

[[nodiscard]] bool canonical_stopped_law(
    const StoppedLawArtifact& artifact, CanonicalLaw& result,
    std::string& error_message) {
  if (!artifact.defective_mass.is_nonnegative() ||
      artifact.defective_mass > Rational::one()) {
    error_message = "a stopped law has defective mass outside [0,1]";
    return false;
  }
  Rational surviving_mass = Rational::zero();
  if (!canonical_atoms(artifact.surviving_atoms, false, result,
                       surviving_mass, error_message)) {
    return false;
  }
  if (surviving_mass + artifact.defective_mass != Rational::one()) {
    error_message =
        "a stopped law's surviving and defective masses must sum to one";
    return false;
  }
  return true;
}

[[nodiscard]] ConformanceReport compare_law(
    const ExactLawArtifact& expected, const ExactLawArtifact& actual,
    const ComparisonContract& contract) {
  std::string error_message;
  CanonicalLaw canonical_expected;
  if (!canonical_law(expected, canonical_expected, error_message)) {
    return failure_report(contract, "oracle_invalid_exact_law",
                          std::move(error_message), std::nullopt,
                          "/oracle/payload/atoms");
  }
  CanonicalLaw canonical_actual;
  if (!canonical_law(actual, canonical_actual, error_message)) {
    return failure_report(contract, "oracle_invalid_exact_law",
                          std::move(error_message), std::nullopt,
                          "/production/payload/atoms");
  }

  auto expected_it = canonical_expected.begin();
  auto actual_it = canonical_actual.begin();
  std::size_t index = 0U;
  while (expected_it != canonical_expected.end() ||
         actual_it != canonical_actual.end()) {
    if (actual_it == canonical_actual.end() ||
        (expected_it != canonical_expected.end() &&
         expected_it->first < actual_it->first)) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "the production law omits atom " + expected_it->first, index,
          indexed_path("/payload/atoms", index));
    }
    if (expected_it == canonical_expected.end() ||
        actual_it->first < expected_it->first) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "the production law contains unexpected atom " + actual_it->first,
          index, indexed_path("/payload/atoms", index));
    }
    if (expected_it->second != actual_it->second) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "atom " + expected_it->first + ": " +
              rational_mismatch_message(expected_it->second,
                                        actual_it->second),
          index, indexed_path("/payload/atoms", index) + "/mass");
    }
    ++expected_it;
    ++actual_it;
    ++index;
  }
  return success_report(contract);
}

[[nodiscard]] ConformanceReport compare_stopped_law(
    const StoppedLawArtifact& expected, const StoppedLawArtifact& actual,
    const ComparisonContract& contract) {
  std::string error_message;
  CanonicalLaw canonical_expected;
  if (!canonical_stopped_law(expected, canonical_expected, error_message)) {
    return failure_report(contract, "oracle_invalid_stopped_law",
                          std::move(error_message), std::nullopt,
                          "/oracle/payload/stopped_law");
  }
  CanonicalLaw canonical_actual;
  if (!canonical_stopped_law(actual, canonical_actual, error_message)) {
    return failure_report(contract, "oracle_invalid_stopped_law",
                          std::move(error_message), std::nullopt,
                          "/production/payload/stopped_law");
  }

  if (expected.defective_mass != actual.defective_mass) {
    return failure_report(
        contract, std::string(exact_mismatch_code(contract)),
        rational_mismatch_message(expected.defective_mass,
                                  actual.defective_mass),
        0U, "/payload/stopped_law/defective_mass");
  }

  auto expected_it = canonical_expected.begin();
  auto actual_it = canonical_actual.begin();
  std::size_t index = 0U;
  while (expected_it != canonical_expected.end() ||
         actual_it != canonical_actual.end()) {
    if (actual_it == canonical_actual.end() ||
        (expected_it != canonical_expected.end() &&
         expected_it->first < actual_it->first)) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "the production stopped law omits surviving atom " +
              expected_it->first,
          index, indexed_path("/payload/stopped_law/surviving_atoms", index));
    }
    if (expected_it == canonical_expected.end() ||
        actual_it->first < expected_it->first) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "the production stopped law contains unexpected surviving atom " +
              actual_it->first,
          index, indexed_path("/payload/stopped_law/surviving_atoms", index));
    }
    if (expected_it->second != actual_it->second) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          "surviving atom " + expected_it->first + ": " +
              rational_mismatch_message(expected_it->second,
                                        actual_it->second),
          index,
          indexed_path("/payload/stopped_law/surviving_atoms", index) +
              "/mass");
    }
    ++expected_it;
    ++actual_it;
    ++index;
  }
  return success_report(contract);
}

[[nodiscard]] Result<void> validate_constant_tail(
    const ConstantTailLawArtifact& law) {
  if (law.tail_start != law.boundary_masses.size()) {
    return Result<void>::failure(
        {"oracle_invalid_constant_tail",
         "tail_start must equal the number of explicitly represented "
         "boundary masses",
         0U, 0U});
  }
  for (const Rational& mass : law.boundary_masses) {
    if (!mass.is_nonnegative()) {
      return Result<void>::failure(
          {"oracle_invalid_constant_tail",
           "a boundary mass is negative", 0U, 0U});
    }
  }
  if (!law.tail_anchor.is_nonnegative() ||
      !law.tail_ratio.is_nonnegative() ||
      !(law.tail_ratio < Rational::one()) ||
      !law.mean_backlog.is_nonnegative() ||
      !law.mean_departures.is_nonnegative()) {
    return Result<void>::failure(
        {"oracle_invalid_constant_tail",
         "constant-tail masses, moments, and the geometric ratio must have "
         "their declared nonnegative/stable ranges",
         0U, 0U});
  }

  const Rational one_minus_ratio = Rational::one() - law.tail_ratio;
  auto tail_mass = checked_divide(law.tail_anchor, one_minus_ratio);
  if (!tail_mass) {
    return Result<void>::failure(tail_mass.error());
  }
  Rational computed_normalization = tail_mass.value();
  Rational computed_mean = Rational::zero();
  for (std::size_t level = 0U; level < law.boundary_masses.size(); ++level) {
    computed_normalization =
        computed_normalization + law.boundary_masses[level];
    computed_mean =
        computed_mean + Rational(BigInt{level}) * law.boundary_masses[level];
  }
  auto tail_offset = checked_divide(
      law.tail_ratio, one_minus_ratio * one_minus_ratio);
  if (!tail_offset) {
    return Result<void>::failure(tail_offset.error());
  }
  computed_mean =
      computed_mean +
      Rational(BigInt{law.tail_start}) * tail_mass.value() +
      law.tail_anchor * tail_offset.value();

  if (computed_normalization != law.normalization ||
      law.normalization != Rational::one()) {
    return Result<void>::failure(
        {"oracle_invalid_constant_tail",
         "the boundary and geometric-tail masses are not normalized",
         0U, 0U});
  }
  if (computed_mean != law.mean_backlog) {
    return Result<void>::failure(
        {"oracle_invalid_constant_tail",
         "the declared mean backlog does not equal the full geometric-tail "
         "first moment",
         0U, 0U});
  }
  return Result<void>::success();
}

[[nodiscard]] ConformanceReport compare_constant_tail(
    const ConstantTailLawArtifact& expected,
    const ConstantTailLawArtifact& actual,
    const ComparisonContract& contract) {
  auto expected_valid = validate_constant_tail(expected);
  if (!expected_valid) {
    return failure_report(contract, expected_valid.error().code,
                          expected_valid.error().message, std::nullopt,
                          "/oracle/payload/constant_tail");
  }
  auto actual_valid = validate_constant_tail(actual);
  if (!actual_valid) {
    return failure_report(contract, actual_valid.error().code,
                          actual_valid.error().message, std::nullopt,
                          "/production/payload/constant_tail");
  }
  if (expected.boundary_masses.size() != actual.boundary_masses.size()) {
    return failure_report(
        contract, std::string(exact_mismatch_code(contract)),
        "the constant-tail laws have different boundary sizes",
        std::min(expected.boundary_masses.size(),
                 actual.boundary_masses.size()),
        "/payload/constant_tail/boundary_masses/size");
  }
  for (std::size_t index = 0U; index < expected.boundary_masses.size();
       ++index) {
    if (expected.boundary_masses[index] != actual.boundary_masses[index]) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          rational_mismatch_message(expected.boundary_masses[index],
                                    actual.boundary_masses[index]),
          index,
          indexed_path("/payload/constant_tail/boundary_masses", index));
    }
  }
  if (expected.tail_start != actual.tail_start) {
    return failure_report(contract, std::string(exact_mismatch_code(contract)),
                          "the constant-tail start levels differ",
                          expected.boundary_masses.size(),
                          "/payload/constant_tail/tail_start");
  }

  struct Field final {
    std::string_view name;
    const Rational* expected;
    const Rational* actual;
  };
  const std::vector<Field> fields{
      {"tail_anchor", &expected.tail_anchor, &actual.tail_anchor},
      {"tail_ratio", &expected.tail_ratio, &actual.tail_ratio},
      {"normalization", &expected.normalization, &actual.normalization},
      {"mean_backlog", &expected.mean_backlog, &actual.mean_backlog},
      {"mean_departures", &expected.mean_departures,
       &actual.mean_departures}};
  for (std::size_t offset = 0U; offset < fields.size(); ++offset) {
    if (*fields[offset].expected != *fields[offset].actual) {
      return failure_report(
          contract, std::string(exact_mismatch_code(contract)),
          rational_mismatch_message(*fields[offset].expected,
                                    *fields[offset].actual),
          expected.boundary_masses.size() + 1U + offset,
          "/payload/constant_tail/" + std::string(fields[offset].name));
    }
  }
  return success_report(contract);
}

struct NumericalReference final {
  std::optional<std::vector<Rational>> values;
  std::string code;
  std::string message;
};

[[nodiscard]] NumericalReference numerical_reference(
    const ArtifactPayload& payload) {
  if (const auto* vector = std::get_if<ExactVectorArtifact>(&payload)) {
    return {vector->values, {}, {}};
  }
  if (const auto* law = std::get_if<ExactLawArtifact>(&payload)) {
    std::string error_message;
    CanonicalLaw canonical;
    if (!canonical_law(*law, canonical, error_message)) {
      return {std::nullopt, "oracle_invalid_exact_law",
              std::move(error_message)};
    }
    std::vector<Rational> result;
    result.reserve(canonical.size());
    for (const auto& [label, mass] : canonical) {
      (void)label;
      result.push_back(mass);
    }
    return {std::move(result), {}, {}};
  }
  if (const auto* tail = std::get_if<ConstantTailLawArtifact>(&payload)) {
    auto valid = validate_constant_tail(*tail);
    if (!valid) {
      return {std::nullopt, valid.error().code, valid.error().message};
    }
    std::vector<Rational> result = tail->boundary_masses;
    result.push_back(tail->tail_anchor);
    result.push_back(tail->tail_ratio);
    result.push_back(tail->normalization);
    result.push_back(tail->mean_backlog);
    result.push_back(tail->mean_departures);
    return {std::move(result), {}, {}};
  }
  return {std::nullopt, "oracle_arithmetic_mode_mismatch",
          "numerical-image comparison requires an exact rational oracle "
          "vector, law, or constant-tail law"};
}

[[nodiscard]] ConformanceReport compare_numerical(
    const ArtifactPayload& oracle_payload,
    const NumericalImageArtifact& actual,
    const ComparisonContract& contract) {
  if (!std::isfinite(contract.numerical_absolute_tolerance) ||
      contract.numerical_absolute_tolerance < 0.0L) {
    return failure_report(contract, "oracle_invalid_numerical_report",
                          "the numerical absolute tolerance is not finite and "
                          "nonnegative",
                          std::nullopt,
                          "/contract/numerical_absolute_tolerance");
  }
  if (contract.require_residual_and_conditioning &&
      (!actual.residual.has_value() || !actual.conditioning.has_value())) {
    return failure_report(contract, "oracle_numerical_report_missing",
                          "the production numerical image omits its residual "
                          "or conditioning report",
                          std::nullopt, "/production/payload/numerics");
  }
  if ((actual.residual.has_value() &&
       (!std::isfinite(*actual.residual) || *actual.residual < 0.0L)) ||
      (actual.conditioning.has_value() &&
       (!std::isfinite(*actual.conditioning) ||
        *actual.conditioning < 0.0L))) {
    return failure_report(contract, "oracle_invalid_numerical_report",
                          "the production residual or conditioning value is "
                          "not finite and nonnegative",
                          std::nullopt, "/production/payload/numerics");
  }

  auto reference = numerical_reference(oracle_payload);
  if (!reference.values) {
    return failure_report(contract, std::move(reference.code),
                          std::move(reference.message), std::nullopt,
                          "/oracle/payload");
  }
  if (reference.values->size() != actual.values.size()) {
    return failure_report(
        contract, "oracle_numerical_mismatch",
        "the exact reference and production numerical image have different "
        "coordinate counts",
        std::min(reference.values->size(), actual.values.size()),
        "/payload/numerical_image/size");
  }
  for (std::size_t index = 0U; index < reference.values->size(); ++index) {
    const long double expected = (*reference.values)[index].to_long_double();
    const long double observed = actual.values[index];
    if (!std::isfinite(expected) || !std::isfinite(observed)) {
      return failure_report(
          contract, "oracle_invalid_numerical_report",
          "the exact rational image or production value is non-finite", index,
          indexed_path("/payload/numerical_image", index));
    }
    if (std::fabs(expected - observed) >
        contract.numerical_absolute_tolerance) {
      std::ostringstream message;
      message.precision(20);
      message << "expected " << expected << ", observed " << observed
              << ", tolerance "
              << contract.numerical_absolute_tolerance;
      return failure_report(
          contract, "oracle_numerical_mismatch", message.str(), index,
          indexed_path("/payload/numerical_image", index));
    }
  }
  return success_report(contract);
}

[[nodiscard]] bool is_capped(const FiniteModelSemantics semantics) {
  return semantics == FiniteModelSemantics::capped_with_drops ||
         semantics == FiniteModelSemantics::capped_with_blocking;
}

[[nodiscard]] ConformanceReport compare_exact_payloads(
    const ArtifactPayload& oracle_payload,
    const ArtifactPayload& production_payload,
    const ComparisonContract& contract) {
  if (oracle_payload.index() != production_payload.index()) {
    return failure_report(contract, "oracle_arithmetic_mode_mismatch",
                          "the exact artifacts use different payload kinds",
                          std::nullopt, "/payload/type");
  }
  if (const auto* expected =
          std::get_if<ExactDiscreteArtifact>(&oracle_payload)) {
    return compare_discrete(
        *expected, std::get<ExactDiscreteArtifact>(production_payload),
        contract);
  }
  if (const auto* expected = std::get_if<ExactLawArtifact>(&oracle_payload)) {
    return compare_law(*expected,
                       std::get<ExactLawArtifact>(production_payload),
                       contract);
  }
  if (const auto* expected =
          std::get_if<StoppedLawArtifact>(&oracle_payload)) {
    return compare_stopped_law(
        *expected, std::get<StoppedLawArtifact>(production_payload), contract);
  }
  if (const auto* expected =
          std::get_if<ExactVectorArtifact>(&oracle_payload)) {
    return compare_vector(
        *expected, std::get<ExactVectorArtifact>(production_payload),
        contract);
  }
  if (const auto* expected =
          std::get_if<ConstantTailLawArtifact>(&oracle_payload)) {
    return compare_constant_tail(
        *expected, std::get<ConstantTailLawArtifact>(production_payload),
        contract);
  }
  if (const auto* expected =
          std::get_if<ProposalRawArtifact>(&oracle_payload)) {
    return compare_proposal_raw(
        *expected, std::get<ProposalRawArtifact>(production_payload),
        contract);
  }
  return failure_report(
      contract, "oracle_arithmetic_mode_mismatch",
      "an exact arithmetic mode cannot consume numerical or capability "
      "payloads",
      std::nullopt, "/payload/type");
}

[[nodiscard]] bool is_exact_law_payload(const ArtifactPayload& payload) {
  return std::holds_alternative<ExactLawArtifact>(payload) ||
         std::holds_alternative<StoppedLawArtifact>(payload) ||
         std::holds_alternative<ConstantTailLawArtifact>(payload);
}

[[nodiscard]] std::optional<ConformanceReport> validate_payload_contract(
    const OracleArtifact& oracle, const ProductionArtifact& production,
    const ComparisonContract& contract) {
  const bool oracle_stopped =
      std::holds_alternative<StoppedLawArtifact>(oracle.payload);
  const bool production_stopped =
      std::holds_alternative<StoppedLawArtifact>(production.payload);
  if (contract.domain == ArtifactDomain::stopped_survival_and_defect) {
    if (contract.arithmetic != ArithmeticMode::exact_projected_law &&
        contract.arithmetic != ArithmeticMode::distributional_identity) {
      return failure_report(
          contract, "oracle_arithmetic_mode_mismatch",
          "stopped survival/defect comparisons require an exact law mode",
          std::nullopt, "/contract/arithmetic");
    }
    if (!oracle_stopped || !production_stopped) {
      return failure_report(
          contract, "oracle_payload_domain_mismatch",
          "the stopped domain requires two separately typed stopped laws",
          std::nullopt, "/payload/type");
    }
  } else if (oracle_stopped || production_stopped) {
    return failure_report(
        contract, "oracle_payload_domain_mismatch",
        "a stopped subprobability payload cannot be used outside the stopped "
        "survival/defect domain",
        std::nullopt, "/payload/type");
  }

  switch (contract.arithmetic) {
    case ArithmeticMode::exact_discrete:
      if (!std::holds_alternative<ExactDiscreteArtifact>(oracle.payload) ||
          !std::holds_alternative<ExactDiscreteArtifact>(production.payload)) {
        return failure_report(
            contract, "oracle_arithmetic_mode_mismatch",
            "exact-discrete arithmetic requires two exact discrete payloads",
            std::nullopt, "/payload/type");
      }
      break;
    case ArithmeticMode::exact_projected_law:
      if (!is_exact_law_payload(oracle.payload) ||
          !is_exact_law_payload(production.payload)) {
        return failure_report(
            contract, "oracle_arithmetic_mode_mismatch",
            "exact-projected-law arithmetic requires two exact law payloads",
            std::nullopt, "/payload/type");
      }
      break;
    case ArithmeticMode::distributional_identity:
      if ((!is_exact_law_payload(oracle.payload) &&
           !std::holds_alternative<ExactVectorArtifact>(oracle.payload) &&
           !std::holds_alternative<ProposalRawArtifact>(oracle.payload)) ||
          (!is_exact_law_payload(production.payload) &&
           !std::holds_alternative<ExactVectorArtifact>(production.payload) &&
           !std::holds_alternative<ProposalRawArtifact>(
               production.payload))) {
        return failure_report(
            contract, "oracle_arithmetic_mode_mismatch",
            "distributional-identity arithmetic requires exact laws or exact "
            "coefficient vectors",
            std::nullopt, "/payload/type");
      }
      break;
    case ArithmeticMode::numerical_image_of_exact_law:
      if (std::holds_alternative<StoppedLawArtifact>(oracle.payload) ||
          !std::holds_alternative<NumericalImageArtifact>(production.payload)) {
        return failure_report(
            contract, "oracle_arithmetic_mode_mismatch",
            "numerical-image arithmetic requires a supported exact oracle "
            "payload and a production numerical image",
            std::nullopt, "/payload/type");
      }
      break;
    case ArithmeticMode::capability_rejection:
      if (!std::holds_alternative<CapabilityArtifact>(oracle.payload) ||
          !std::holds_alternative<CapabilityArtifact>(production.payload)) {
        return failure_report(
            contract, "oracle_arithmetic_mode_mismatch",
            "capability-rejection arithmetic requires two capability payloads",
            std::nullopt, "/payload/type");
      }
      break;
  }

  const bool numerical =
      contract.arithmetic == ArithmeticMode::numerical_image_of_exact_law;
  const bool ordinary_laws =
      std::holds_alternative<ExactLawArtifact>(oracle.payload) &&
      (numerical ||
       std::holds_alternative<ExactLawArtifact>(production.payload));
  const bool invariant_laws =
      ordinary_laws ||
      (std::holds_alternative<ConstantTailLawArtifact>(oracle.payload) &&
       (numerical || std::holds_alternative<ConstantTailLawArtifact>(
                         production.payload)));

  switch (contract.domain) {
    case ArtifactDomain::schedule:
    case ArtifactDomain::opportunity:
      if (contract.arithmetic != ArithmeticMode::exact_discrete) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "schedule and opportunity domains require exact-discrete "
            "arithmetic",
            std::nullopt, "/contract/domain");
      }
      break;
    case ArtifactDomain::physical_path:
      if (contract.arithmetic != ArithmeticMode::exact_discrete &&
          !ordinary_laws) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "a projected physical-path comparison requires ordinary exact "
            "path-law payloads",
            std::nullopt, "/payload/type");
      }
      break;
    case ArtifactDomain::kernel_row:
    case ArtifactDomain::romr_word_law:
    case ArtifactDomain::romr_concatenated_slots:
    case ArtifactDomain::suspension_occupation:
    case ArtifactDomain::stationary_marked_edge:
    case ArtifactDomain::palm_entrance:
    case ArtifactDomain::fifo_delay:
      if (!ordinary_laws) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "the selected stochastic-law domain requires ordinary exact law "
            "payloads",
            std::nullopt, "/payload/type");
      }
      break;
    case ArtifactDomain::invariant_law:
      if (!invariant_laws) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "the invariant-law domain requires an ordinary or constant-tail "
            "exact law payload",
            std::nullopt, "/payload/type");
      }
      break;
    case ArtifactDomain::stopped_survival_and_defect:
      // The separately typed stopped-law checks above are exhaustive.
      break;
    case ArtifactDomain::scalar_metric:
      if (!std::holds_alternative<ExactVectorArtifact>(oracle.payload) ||
          (!numerical && !std::holds_alternative<ExactVectorArtifact>(
                             production.payload))) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "a scalar-metric comparison requires an exact oracle metric vector",
            std::nullopt, "/payload/type");
      }
      break;
    case ArtifactDomain::proposal_coefficient:
      if (contract.scope != ScientificScope::proposal_raw ||
          contract.arithmetic != ArithmeticMode::distributional_identity ||
          !std::holds_alternative<ProposalRawArtifact>(oracle.payload) ||
          !std::holds_alternative<ProposalRawArtifact>(production.payload)) {
        return failure_report(
            contract, "oracle_payload_domain_mismatch",
            "the proposal-coefficient domain requires proposal-raw scope, "
            "distributional identity, and two typed raw coefficient "
            "payloads",
            std::nullopt, "/payload/type");
      }
      break;
    case ArtifactDomain::capability:
      // Capability comparisons return through the dedicated branch before
      // reaching this validator.
      break;
  }
  return std::nullopt;
}

}  // namespace

namespace {

[[nodiscard]] ConformanceReport oracle_compare_production_impl(
    const OracleArtifact& oracle, const ProductionArtifact& production,
    const ComparisonContract& contract) {
  // Firewalls are intentionally evaluated in a stable semantic order. A
  // later numerical coincidence can never conceal an earlier domain, scope,
  // identity, or finite-model mismatch.
  if (oracle.domain != contract.domain) {
    return failure_report(contract, "oracle_domain_mismatch",
                          "the oracle artifact has the wrong scientific "
                          "domain for this comparison",
                          std::nullopt, "/oracle/domain");
  }
  if (production.domain != contract.domain) {
    return failure_report(contract, "oracle_domain_mismatch",
                          "the production artifact has the wrong scientific "
                          "domain for this comparison",
                          std::nullopt, "/production/domain");
  }
  if (oracle.scope != contract.scope) {
    return failure_report(contract, "oracle_scope_mismatch",
                          "the oracle artifact cannot be relabelled into the "
                          "contract scientific scope",
                          std::nullopt, "/oracle/scope");
  }
  if (production.scope != contract.scope) {
    return failure_report(contract, "oracle_scope_mismatch",
                          "the production artifact cannot be relabelled into "
                          "the contract scientific scope",
                          std::nullopt, "/production/scope");
  }
  if ((contract.scope == ScientificScope::proposal_raw) !=
      (contract.domain == ArtifactDomain::proposal_coefficient)) {
    return failure_report(
        contract, "oracle_scope_mismatch",
        "proposal-raw scope is available only for the typed proposal "
        "coefficient domain",
        std::nullopt, "/contract/scope");
  }
  if (contract.scope == ScientificScope::physical_bound &&
      (!oracle.explicit_physical_bound_certificate ||
       !production.explicit_physical_bound_certificate)) {
    return failure_report(
        contract, "oracle_physical_bound_certificate_missing",
        "physical-bound scope requires an explicit certificate on both "
        "compared artifacts",
        std::nullopt, "/physical_bound_certificate");
  }
  if (contract.scope == ScientificScope::physical_bound) {
    if (oracle.explicit_physical_bound_certificate.identity().empty() ||
        production.explicit_physical_bound_certificate.identity().empty()) {
      return failure_report(
          contract, "oracle_physical_bound_certificate_missing",
          "physical-bound scope requires a nonempty typed certificate "
          "identity on both artifacts; a bare presence flag is insufficient",
          std::nullopt, "/physical_bound_certificate/identity");
    }
    if (oracle.explicit_physical_bound_certificate.identity() !=
        production.explicit_physical_bound_certificate.identity()) {
      return failure_report(
          contract, "oracle_physical_bound_certificate_mismatch",
          "the compared artifacts do not bind the same physical-bound "
          "certificate identity",
          std::nullopt, "/physical_bound_certificate/identity");
    }
  }

  if (contract.projection_identity.empty()) {
    return failure_report(contract, "oracle_projection_mismatch",
                          "the comparison contract omits its projection "
                          "identity",
                          std::nullopt, "/contract/projection_identity");
  }
  if (oracle.projection_identity != contract.projection_identity) {
    return failure_report(contract, "oracle_projection_mismatch",
                          "the oracle artifact has the wrong projection "
                          "identity",
                          std::nullopt, "/oracle/projection_identity");
  }
  if (production.projection_identity != contract.projection_identity) {
    return failure_report(contract, "oracle_projection_mismatch",
                          "the production artifact has the wrong projection "
                          "identity",
                          std::nullopt,
                          "/production/projection_identity");
  }
  if (oracle.product_identity.empty() || production.product_identity.empty()) {
    return failure_report(
        contract, "oracle_product_mismatch",
        "each compared artifact requires a nonempty product identity",
        std::nullopt, "/product_identity");
  }
  if (contract.scope == ScientificScope::physical_bound &&
      (!oracle.explicit_physical_bound_certificate.binds(
           contract.domain, contract.projection_identity,
           oracle.product_identity, production.product_identity) ||
       !production.explicit_physical_bound_certificate.binds(
           contract.domain, contract.projection_identity,
           oracle.product_identity, production.product_identity))) {
    return failure_report(
        contract, "oracle_physical_bound_certificate_binding_mismatch",
        "the physical-bound certificate does not bind this comparison's "
        "domain, projection, oracle/source product, and "
        "production/destination product",
        std::nullopt, "/physical_bound_certificate/binding");
  }
  // A projection comparison intentionally permits different producer-bound
  // identities: that is how C15 mode erasure compares equal mathematics
  // without collapsing provenance. Raw proposal evidence is the exception;
  // it is valid only for its exact frozen proposal product.
  if ((contract.scope == ScientificScope::proposal_raw ||
       contract.arithmetic == ArithmeticMode::exact_discrete) &&
      oracle.product_identity != production.product_identity) {
    return failure_report(
        contract, "oracle_product_mismatch",
        contract.scope == ScientificScope::proposal_raw
            ? "proposal-raw comparison cannot cross frozen product identities"
            : "exact-discrete comparison requires one common product "
              "identity",
        std::nullopt, "/product_identity");
  }

  if (contract.finite_model_comparison &&
      (!oracle.finite_semantics.has_value() ||
       !production.finite_semantics.has_value())) {
    return failure_report(
        contract, "oracle_finite_semantics_missing",
        "a declared finite-model comparison requires explicit semantics on "
        "both artifacts; omitting both cannot erase capped behavior",
        std::nullopt, "/finite_semantics");
  }
  if (oracle.finite_semantics != production.finite_semantics) {
    return failure_report(
        contract, "oracle_semantics_mismatch",
        "the artifacts declare different finite-model semantics",
        std::nullopt, "/finite_semantics");
  }
  if (contract.infinite_buffer_physical_semantics) {
    if (contract.scope != ScientificScope::physical_model) {
      return failure_report(
          contract, "oracle_semantics_mismatch",
          "infinite-buffer physical semantics require physical-model scope",
          std::nullopt, "/contract/infinite_buffer_physical_semantics");
    }
    if (oracle.finite_semantics.has_value() &&
        is_capped(*oracle.finite_semantics)) {
      return failure_report(
          contract, "oracle_semantics_mismatch",
          "a capped drop/blocking model cannot validate an infinite-buffer "
          "physical contract",
          std::nullopt, "/finite_semantics");
    }
  }

  if (contract.arithmetic == ArithmeticMode::capability_rejection) {
    if (contract.domain != ArtifactDomain::capability) {
      return failure_report(
          contract, "oracle_arithmetic_mode_mismatch",
          "capability-rejection arithmetic requires the capability domain",
          std::nullopt, "/contract/arithmetic");
    }
    const auto* expected =
        std::get_if<CapabilityArtifact>(&oracle.payload);
    const auto* actual =
        std::get_if<CapabilityArtifact>(&production.payload);
    if (expected == nullptr || actual == nullptr ||
        expected->unsupported_reason.empty() ||
        actual->unsupported_reason.empty()) {
      return failure_report(
          contract, "oracle_arithmetic_mode_mismatch",
          "capability-rejection comparison requires two typed unsupported "
          "reasons",
          std::nullopt, "/payload/type");
    }
    if (expected->unsupported_reason != actual->unsupported_reason) {
      return failure_report(
          contract, "oracle_capability_mismatch",
          "expected unsupported reason " + expected->unsupported_reason +
              ", observed " + actual->unsupported_reason,
          0U, "/payload/unsupported_reason");
    }
    return success_report(contract);
  }
  if (contract.domain == ArtifactDomain::capability) {
    return failure_report(contract, "oracle_arithmetic_mode_mismatch",
                          "the capability domain requires capability-rejection "
                          "arithmetic",
                          std::nullopt, "/contract/arithmetic");
  }

  if (auto incompatibility =
          validate_payload_contract(oracle, production, contract)) {
    return std::move(*incompatibility);
  }

  if (contract.arithmetic ==
      ArithmeticMode::numerical_image_of_exact_law) {
    const auto* actual =
        std::get_if<NumericalImageArtifact>(&production.payload);
    if (actual == nullptr) {
      return failure_report(
          contract, "oracle_arithmetic_mode_mismatch",
          "numerical-image comparison requires a production numerical image",
          std::nullopt, "/production/payload/type");
    }
    return compare_numerical(oracle.payload, *actual, contract);
  }

  return compare_exact_payloads(oracle.payload, production.payload, contract);
}

}  // namespace

ConformanceReport oracle_compare_production(
    const OracleArtifact& oracle, const ProductionArtifact& production,
    const ComparisonContract& contract) {
  auto report = oracle_compare_production_impl(oracle, production, contract);
  report.finite_semantics = oracle.finite_semantics.has_value()
                                ? oracle.finite_semantics
                                : production.finite_semantics;
  return report;
}

}  // namespace mwperf_oracle
