#include "mwperf_oracle/full_state_oracle.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <set>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

namespace mwperf_oracle {
namespace {

[[nodiscard]] OracleError schedule_error(std::string code,
                                         std::string message,
                                         const std::size_t examined = 0U) {
  return OracleError{
      .code = std::move(code),
      .message = std::move(message),
      .states_examined = 0U,
      .branches_examined = examined,
  };
}

[[nodiscard]] std::size_t constraint_dimension(
    const SmallConstraint& constraint) {
  return std::visit(
      [](const auto& value) -> std::size_t {
        using Constraint = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Constraint, CrossbarConstraint>) {
          return value.edges.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            IntervalConstraint>) {
          return value.intervals.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            NodeExclusiveConstraint>) {
          return value.links.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            ConflictConstraint>) {
          return value.adjacency.size();
        } else {
          return value.demands.size();
        }
      },
      constraint);
}

[[nodiscard]] Result<void> validate_constraint(
    const SmallConstraint& constraint) {
  return std::visit(
      [](const auto& value) -> Result<void> {
        using Constraint = std::decay_t<decltype(value)>;

        if constexpr (std::is_same_v<Constraint, CrossbarConstraint>) {
          std::set<std::pair<std::size_t, std::size_t>> endpoints;
          for (const CrossbarEdge& edge : value.edges) {
            if (!endpoints.emplace(edge.input, edge.output).second) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "a crossbar constraint repeats an input/output pair"));
            }
          }
        } else if constexpr (std::is_same_v<Constraint,
                                            IntervalConstraint>) {
          for (const HalfOpenInterval& interval : value.intervals) {
            if (!(interval.left < interval.right)) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "every oracle interval must satisfy exact left < right"));
            }
          }
        } else if constexpr (std::is_same_v<Constraint,
                                            NodeExclusiveConstraint>) {
          for (const UndirectedLink& link : value.links) {
            if (link.first == link.second) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "a node-exclusive link cannot be a self loop"));
            }
          }
        } else if constexpr (std::is_same_v<Constraint,
                                            ConflictConstraint>) {
          const std::size_t dimension = value.adjacency.size();
          for (std::size_t row = 0U; row < dimension; ++row) {
            if (value.adjacency[row].size() != dimension) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "the conflict adjacency matrix must be square"));
            }
            for (std::size_t column = 0U; column < dimension; ++column) {
              const std::uint8_t entry = value.adjacency[row][column];
              if (entry > 1U) {
                return Result<void>::failure(schedule_error(
                    "oracle_invalid_constraint",
                    "conflict adjacency entries must be binary"));
              }
              if (row == column && entry != 0U) {
                return Result<void>::failure(schedule_error(
                    "oracle_invalid_constraint",
                    "the conflict adjacency diagonal must be zero"));
              }
              if (entry != value.adjacency[column][row]) {
                return Result<void>::failure(schedule_error(
                    "oracle_invalid_constraint",
                    "the conflict adjacency matrix must be symmetric"));
              }
            }
          }
        } else {
          for (const BigInt& capacity : value.capacity) {
            if (capacity < 0) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "packing capacities must be nonnegative"));
            }
          }
          for (const auto& demand : value.demands) {
            if (demand.size() != value.capacity.size()) {
              return Result<void>::failure(schedule_error(
                  "oracle_invalid_constraint",
                  "every packing demand must match the capacity dimension"));
            }
            for (const BigInt& coordinate : demand) {
              if (coordinate < 0) {
                return Result<void>::failure(schedule_error(
                    "oracle_invalid_constraint",
                    "packing demands must be nonnegative"));
              }
            }
          }
        }
        return Result<void>::success();
      },
      constraint);
}

[[nodiscard]] bool crossbar_feasible(const CrossbarConstraint& constraint,
                                     const Schedule& schedule) {
  std::set<std::size_t> used_inputs;
  std::set<std::size_t> used_outputs;
  for (std::size_t queue = 0U; queue < schedule.size(); ++queue) {
    if (schedule[queue] == 0U) {
      continue;
    }
    const CrossbarEdge& edge = constraint.edges[queue];
    if (!used_inputs.insert(edge.input).second ||
        !used_outputs.insert(edge.output).second) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool interval_feasible(const IntervalConstraint& constraint,
                                     const Schedule& schedule) {
  for (std::size_t first = 0U; first < schedule.size(); ++first) {
    if (schedule[first] == 0U) {
      continue;
    }
    for (std::size_t second = first + 1U; second < schedule.size(); ++second) {
      if (schedule[second] == 0U) {
        continue;
      }
      const HalfOpenInterval& left = constraint.intervals[first];
      const HalfOpenInterval& right = constraint.intervals[second];
      if (!(left.right <= right.left || right.right <= left.left)) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool node_exclusive_feasible(
    const NodeExclusiveConstraint& constraint, const Schedule& schedule) {
  std::set<std::size_t> used_vertices;
  for (std::size_t queue = 0U; queue < schedule.size(); ++queue) {
    if (schedule[queue] == 0U) {
      continue;
    }
    const UndirectedLink& link = constraint.links[queue];
    if (!used_vertices.insert(link.first).second ||
        !used_vertices.insert(link.second).second) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool conflict_feasible(const ConflictConstraint& constraint,
                                     const Schedule& schedule) {
  for (std::size_t first = 0U; first < schedule.size(); ++first) {
    if (schedule[first] == 0U) {
      continue;
    }
    for (std::size_t second = first + 1U; second < schedule.size(); ++second) {
      if (schedule[second] != 0U &&
          constraint.adjacency[first][second] != 0U) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool packing_feasible(const PackingConstraint& constraint,
                                    const Schedule& schedule) {
  for (std::size_t resource = 0U; resource < constraint.capacity.size();
       ++resource) {
    BigInt used = 0;
    for (std::size_t queue = 0U; queue < schedule.size(); ++queue) {
      if (schedule[queue] != 0U) {
        used += constraint.demands[queue][resource];
      }
    }
    if (used > constraint.capacity[resource]) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool structurally_feasible(const SmallConstraint& constraint,
                                         const Schedule& schedule) {
  return std::visit(
      [&](const auto& value) -> bool {
        using Constraint = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Constraint, CrossbarConstraint>) {
          return crossbar_feasible(value, schedule);
        } else if constexpr (std::is_same_v<Constraint,
                                            IntervalConstraint>) {
          return interval_feasible(value, schedule);
        } else if constexpr (std::is_same_v<Constraint,
                                            NodeExclusiveConstraint>) {
          return node_exclusive_feasible(value, schedule);
        } else if constexpr (std::is_same_v<Constraint,
                                            ConflictConstraint>) {
          return conflict_feasible(value, schedule);
        } else {
          return packing_feasible(value, schedule);
        }
      },
      constraint);
}

[[nodiscard]] bool respects_eligibility(const Schedule& schedule,
                                        const EligibilityMask& eligibility) {
  for (std::size_t queue = 0U; queue < schedule.size(); ++queue) {
    if (schedule[queue] != 0U && eligibility[queue] == 0U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] BigInt primary_objective(const Backlog& backlog,
                                       const Schedule& schedule,
                                       const std::optional<std::size_t> skip =
                                           std::nullopt) {
  BigInt objective = 0;
  for (std::size_t queue = 0U; queue < schedule.size(); ++queue) {
    if ((!skip.has_value() || queue != *skip) && schedule[queue] != 0U) {
      objective += backlog[queue];
    }
  }
  return objective;
}

[[nodiscard]] bool lexicographically_preferred(
    const Schedule& candidate, const Schedule& incumbent,
    const PriorityOrder& priority) {
  for (const std::size_t queue : priority) {
    if (candidate[queue] != incumbent[queue]) {
      return candidate[queue] > incumbent[queue];
    }
  }
  return false;
}

[[nodiscard]] bool canonical_schedule_less(const Schedule& left,
                                           const Schedule& right) {
  const std::size_t size = std::min(left.size(), right.size());
  for (std::size_t index = 0U; index < size; ++index) {
    if (left[index] != right[index]) {
      return left[index] < right[index];
    }
  }
  return left.size() < right.size();
}

[[nodiscard]] Schedule schedule_from_mask(const std::size_t dimension,
                                          const std::size_t mask) {
  Schedule schedule(dimension, 0U);
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    schedule[queue] =
        static_cast<std::uint8_t>((mask >> queue) & std::size_t{1U});
  }
  return schedule;
}

[[nodiscard]] Result<void> validate_query(
    const SmallConstraint& constraint, const Backlog& backlog,
    const EligibilityMask& eligibility, const PriorityOrder& priority,
    const OracleLimits& limits) {
  const auto constraint_result = validate_constraint(constraint);
  if (!constraint_result) {
    return Result<void>::failure(constraint_result.error());
  }

  const std::size_t dimension = constraint_dimension(constraint);
  constexpr std::size_t mathematical_maximum_dimension = 8U;
  if (dimension > mathematical_maximum_dimension ||
      dimension > limits.maximum_schedule_dimension) {
    return Result<void>::failure(schedule_error(
        "oracle_invalid_dimension",
        "schedule enumeration exceeds its declared exact dimension limit"));
  }
  if (backlog.size() != dimension) {
    return Result<void>::failure(schedule_error(
        "oracle_backlog_dimension_mismatch",
        "the backlog dimension does not match the constraint"));
  }
  for (const BigInt& value : backlog) {
    if (value < 0) {
      return Result<void>::failure(schedule_error(
          "oracle_invalid_dimension",
          "oracle backlogs must be nonnegative exact integers"));
    }
  }
  if (eligibility.size() != dimension) {
    return Result<void>::failure(schedule_error(
        "oracle_eligibility_dimension_mismatch",
        "the eligibility dimension does not match the constraint"));
  }
  for (const std::uint8_t value : eligibility) {
    if (value > 1U) {
      return Result<void>::failure(schedule_error(
          "oracle_invalid_eligibility",
          "oracle eligibility entries must be binary"));
    }
  }
  if (priority.size() != dimension) {
    return Result<void>::failure(schedule_error(
        "oracle_priority_dimension_mismatch",
        "the priority dimension does not match the constraint"));
  }
  std::vector<std::uint8_t> seen(dimension, 0U);
  for (const std::size_t queue : priority) {
    if (queue >= dimension || seen[queue] != 0U) {
      return Result<void>::failure(schedule_error(
          "oracle_invalid_priority",
          "the priority order must be a permutation of the queue indices"));
    }
    seen[queue] = 1U;
  }
  return Result<void>::success();
}

}  // namespace

Result<ExactScheduleFace> oracle_enumerate_schedule_face(
    const SmallConstraint& constraint, const Backlog& backlog,
    const EligibilityMask& eligibility, const PriorityOrder& priority,
    const OracleLimits limits) {
  const auto validation =
      validate_query(constraint, backlog, eligibility, priority, limits);
  if (!validation) {
    return Result<ExactScheduleFace>::failure(validation.error());
  }

  const std::size_t dimension = constraint_dimension(constraint);
  const std::size_t schedule_count = std::size_t{1U} << dimension;
  if (schedule_count > limits.maximum_branches) {
    return Result<ExactScheduleFace>::failure(schedule_error(
        "oracle_budget_exhausted",
        "the exact schedule enumeration branch budget is exhausted",
        limits.maximum_branches));
  }

  struct StructuralCandidate final {
    Schedule schedule;
  };
  std::vector<StructuralCandidate> structural;
  structural.reserve(schedule_count);

  std::optional<BigInt> best_physical;
  std::vector<Schedule> maximizing_face;
  EligibilityMask effective_eligibility = eligibility;
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    if (backlog[queue] == 0) {
      effective_eligibility[queue] = 0U;
    }
  }
  for (std::size_t mask = 0U; mask < schedule_count; ++mask) {
    Schedule schedule = schedule_from_mask(dimension, mask);
    if (!structurally_feasible(constraint, schedule)) {
      continue;
    }

    BigInt objective = primary_objective(backlog, schedule);
    structural.push_back(StructuralCandidate{schedule});
    if (!respects_eligibility(schedule, effective_eligibility)) {
      continue;
    }

    if (!best_physical.has_value() || objective > *best_physical) {
      best_physical = objective;
      maximizing_face.clear();
      maximizing_face.push_back(std::move(schedule));
    } else if (objective == *best_physical) {
      maximizing_face.push_back(std::move(schedule));
    }
  }

  // The empty schedule is feasible for every validated family, including a
  // zero-resource packing problem, so a valid query must have a physical face.
  if (!best_physical.has_value() || maximizing_face.empty()) {
    return Result<ExactScheduleFace>::failure(schedule_error(
        "oracle_invalid_constraint",
        "the validated structural family unexpectedly has no feasible schedule",
        schedule_count));
  }

  Schedule priority_choice = maximizing_face.front();
  for (std::size_t index = 1U; index < maximizing_face.size(); ++index) {
    if (lexicographically_preferred(maximizing_face[index], priority_choice,
                                   priority)) {
      priority_choice = maximizing_face[index];
    }
  }
  std::sort(maximizing_face.begin(), maximizing_face.end(),
            canonical_schedule_less);

  std::vector<ForcedOpportunity> opportunities;
  opportunities.reserve(dimension);
  for (std::size_t target = 0U; target < dimension; ++target) {
    std::optional<BigInt> psi_zero;
    std::optional<BigInt> psi_one;
    for (const StructuralCandidate& candidate : structural) {
      const BigInt non_target =
          primary_objective(backlog, candidate.schedule, target);
      std::optional<BigInt>& selected =
          candidate.schedule[target] == 0U ? psi_zero : psi_one;
      if (!selected.has_value() || non_target > *selected) {
        selected = non_target;
      }
    }

    ForcedOpportunity opportunity{
        .target = target,
        .forced_zero_feasible = psi_zero.has_value(),
        .forced_one_feasible = psi_one.has_value(),
        .psi_zero = psi_zero,
        .psi_one = psi_one,
        .theta = std::nullopt,
        .margin = std::nullopt,
    };
    if (psi_zero.has_value() && psi_one.has_value()) {
      opportunity.theta = *psi_zero - *psi_one;
      opportunity.margin = backlog[target] - *opportunity.theta;
    }
    opportunities.push_back(std::move(opportunity));
  }

  return Result<ExactScheduleFace>::success(ExactScheduleFace{
      .dimension = dimension,
      .primary_objective = *best_physical,
      .maximizing_face = std::move(maximizing_face),
      .priority_choice = std::move(priority_choice),
      .opportunities = std::move(opportunities),
      .schedules_examined = schedule_count,
  });
}

BigInt oracle_composite_score_identity(const BigInt& primary,
                                       const Schedule& schedule,
                                       const PriorityOrder& priority) {
  const std::size_t dimension = schedule.size();
  if (priority.size() != dimension) {
    return BigInt{-1};
  }

  std::vector<std::uint8_t> seen(dimension, 0U);
  BigInt secondary = 0;
  for (std::size_t rank = 0U; rank < dimension; ++rank) {
    const std::size_t queue = priority[rank];
    if (queue >= dimension || seen[queue] != 0U || schedule[queue] > 1U) {
      return BigInt{-1};
    }
    seen[queue] = 1U;
    if (schedule[queue] != 0U) {
      BigInt bit = 1;
      bit <<= (dimension - rank - 1U);
      secondary += bit;
    }
  }

  BigInt scale = 1;
  scale <<= dimension;
  return primary * scale + secondary;
}

}  // namespace mwperf_oracle
