#include "mwperf_oracle/full_state_oracle.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace mwperf_oracle {
namespace {

[[nodiscard]] OracleError make_error(std::string code, std::string message,
                                     const std::size_t states = 0U,
                                     const std::size_t branches = 0U) {
  return OracleError{std::move(code), std::move(message), states, branches};
}

[[nodiscard]] int compare_big_int(const BigInt& lhs, const BigInt& rhs) {
  if (lhs < rhs) {
    return -1;
  }
  if (rhs < lhs) {
    return 1;
  }
  return 0;
}

template <typename T, typename CompareElement>
[[nodiscard]] int compare_vectors(const std::vector<T>& lhs,
                                  const std::vector<T>& rhs,
                                  CompareElement compare_element) {
  const auto common = std::min(lhs.size(), rhs.size());
  for (std::size_t index = 0U; index < common; ++index) {
    const int comparison = compare_element(lhs[index], rhs[index]);
    if (comparison != 0) {
      return comparison;
    }
  }
  if (lhs.size() < rhs.size()) {
    return -1;
  }
  if (rhs.size() < lhs.size()) {
    return 1;
  }
  return 0;
}

[[nodiscard]] int compare_size(const std::size_t lhs, const std::size_t rhs) {
  if (lhs < rhs) {
    return -1;
  }
  if (rhs < lhs) {
    return 1;
  }
  return 0;
}

[[nodiscard]] int compare_byte(const std::uint8_t lhs,
                               const std::uint8_t rhs) {
  if (lhs < rhs) {
    return -1;
  }
  if (rhs < lhs) {
    return 1;
  }
  return 0;
}

[[nodiscard]] int compare_string(const std::string& lhs,
                                 const std::string& rhs) {
  if (lhs < rhs) {
    return -1;
  }
  if (rhs < lhs) {
    return 1;
  }
  return 0;
}

[[nodiscard]] int compare_exact_joint_mark(const ExactJointMark& lhs,
                                           const ExactJointMark& rhs) {
  if (const int identities = compare_string(lhs.id, rhs.id);
      identities != 0) {
    return identities;
  }
  return compare_big_int(lhs.value, rhs.value);
}

[[nodiscard]] int compare_full_state(const FullState& lhs,
                                     const FullState& rhs) {
  if (const int queues =
          compare_vectors(lhs.queue, rhs.queue, compare_big_int);
      queues != 0) {
    return queues;
  }
  if (const int phases = compare_size(lhs.arrival_phase, rhs.arrival_phase);
      phases != 0) {
    return phases;
  }
  return compare_vectors(lhs.controller_memory, rhs.controller_memory,
                         compare_big_int);
}

[[nodiscard]] int compare_slot_record(const SlotRecord& lhs,
                                      const SlotRecord& rhs) {
  if (const int predecision =
          compare_full_state(lhs.predecision, rhs.predecision);
      predecision != 0) {
    return predecision;
  }
  if (const int schedules =
          compare_vectors(lhs.schedule, rhs.schedule, compare_byte);
      schedules != 0) {
    return schedules;
  }
  if (const int departures =
          compare_vectors(lhs.departures, rhs.departures, compare_byte);
      departures != 0) {
    return departures;
  }
  if (const int arrivals =
          compare_vectors(lhs.arrivals, rhs.arrivals, compare_big_int);
      arrivals != 0) {
    return arrivals;
  }
  if (const int marks = compare_vectors(lhs.joint_marks, rhs.joint_marks,
                                        compare_exact_joint_mark);
      marks != 0) {
    return marks;
  }
  if (const int postarrival =
          compare_full_state(lhs.postarrival, rhs.postarrival);
      postarrival != 0) {
    return postarrival;
  }
  if (const int identity =
          compare_string(lhs.tie_branch_identity, rhs.tie_branch_identity);
      identity != 0) {
    return identity;
  }
  if (const int slots = compare_size(lhs.decision_slot, rhs.decision_slot);
      slots != 0) {
    return slots;
  }
  if (const int boundaries =
          compare_size(lhs.admission_boundary, rhs.admission_boundary);
      boundaries != 0) {
    return boundaries;
  }
  return compare_size(static_cast<std::size_t>(lhs.timing),
                      static_cast<std::size_t>(rhs.timing));
}

[[nodiscard]] int compare_history(const PathHistory& lhs,
                                  const PathHistory& rhs) {
  return compare_vectors(lhs.slots, rhs.slots, compare_slot_record);
}

[[nodiscard]] int compare_path_atom_key(const PathAtom& lhs,
                                        const PathAtom& rhs) {
  if (const int states = compare_full_state(lhs.state, rhs.state);
      states != 0) {
    return states;
  }
  return compare_history(lhs.history, rhs.history);
}

[[nodiscard]] int compare_initial_atom_key(const InitialAtom& lhs,
                                           const InitialAtom& rhs) {
  return compare_full_state(lhs.state, rhs.state);
}

[[nodiscard]] int compare_residence_word(const ResidenceWord& lhs,
                                         const ResidenceWord& rhs) {
  if (const int slots =
          compare_vectors(lhs.slots, rhs.slots, compare_slot_record);
      slots != 0) {
    return slots;
  }
  if (lhs.right_censored == rhs.right_censored) {
    return 0;
  }
  return lhs.right_censored ? 1 : -1;
}

[[nodiscard]] int compare_residence_path(const ResidencePathAtom& lhs,
                                         const ResidencePathAtom& rhs) {
  return compare_vectors(lhs.words, rhs.words, compare_residence_word);
}

[[nodiscard]] int compare_residence_word_law_key(
    const ResidenceWordLawAtom& lhs, const ResidenceWordLawAtom& rhs) {
  if (const int entrance = compare_full_state(lhs.entrance, rhs.entrance);
      entrance != 0) {
    return entrance;
  }
  if (const int words = compare_residence_word(lhs.word, rhs.word);
      words != 0) {
    return words;
  }
  return compare_full_state(lhs.endpoint, rhs.endpoint);
}

[[nodiscard]] int compare_concatenated_residence_key(
    const ConcatenatedResidencePathAtom& lhs,
    const ConcatenatedResidencePathAtom& rhs) {
  if (const int slots =
          compare_vectors(lhs.slots, rhs.slots, compare_slot_record);
      slots != 0) {
    return slots;
  }
  if (const int boundaries = compare_vectors(
          lhs.complete_word_boundaries, rhs.complete_word_boundaries,
          [](const std::size_t left, const std::size_t right) {
            return compare_size(left, right);
          });
      boundaries != 0) {
    return boundaries;
  }
  if (lhs.right_censored == rhs.right_censored) {
    return 0;
  }
  return lhs.right_censored ? 1 : -1;
}

[[nodiscard]] int compare_marked_edge(const ResidenceMarkedEdge& lhs,
                                      const ResidenceMarkedEdge& rhs) {
  if (const int predecision =
          compare_full_state(lhs.predecision, rhs.predecision);
      predecision != 0) {
    return predecision;
  }
  if (const int schedules =
          compare_vectors(lhs.schedule, rhs.schedule, compare_byte);
      schedules != 0) {
    return schedules;
  }
  if (const int departures =
          compare_vectors(lhs.departures, rhs.departures, compare_byte);
      departures != 0) {
    return departures;
  }
  if (const int arrivals =
          compare_vectors(lhs.arrivals, rhs.arrivals, compare_big_int);
      arrivals != 0) {
    return arrivals;
  }
  if (const int marks = compare_vectors(lhs.joint_marks, rhs.joint_marks,
                                        compare_exact_joint_mark);
      marks != 0) {
    return marks;
  }
  if (const int postarrival =
          compare_full_state(lhs.postarrival, rhs.postarrival);
      postarrival != 0) {
    return postarrival;
  }
  if (const int identity =
          compare_string(lhs.tie_branch_identity, rhs.tie_branch_identity);
      identity != 0) {
    return identity;
  }
  return compare_size(static_cast<std::size_t>(lhs.timing),
                      static_cast<std::size_t>(rhs.timing));
}

[[nodiscard]] bool nonnegative_backlog(const Backlog& backlog) {
  return std::all_of(backlog.begin(), backlog.end(),
                     [](const BigInt& value) { return value >= 0; });
}

[[nodiscard]] Rational total_initial_mass(
    const std::vector<InitialAtom>& atoms) {
  Rational total = Rational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.mass;
  }
  return total;
}

[[nodiscard]] Rational total_path_mass(const std::vector<PathAtom>& atoms) {
  Rational total = Rational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.mass;
  }
  return total;
}

[[nodiscard]] Rational total_residence_mass(
    const std::vector<ResidencePathAtom>& atoms) {
  Rational total = Rational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.mass;
  }
  return total;
}

[[nodiscard]] std::size_t constraint_dimension(
    const SmallConstraint& constraint) {
  return std::visit(
      [](const auto& concrete) -> std::size_t {
        using Constraint = std::decay_t<decltype(concrete)>;
        if constexpr (std::is_same_v<Constraint, CrossbarConstraint>) {
          return concrete.edges.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            IntervalConstraint>) {
          return concrete.intervals.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            NodeExclusiveConstraint>) {
          return concrete.links.size();
        } else if constexpr (std::is_same_v<Constraint,
                                            ConflictConstraint>) {
          return concrete.adjacency.size();
        } else {
          return concrete.demands.size();
        }
      },
      constraint);
}

[[nodiscard]] bool valid_arrival_family(const FiniteArrivalFamily family) {
  switch (family) {
    case FiniteArrivalFamily::finite_joint_iid:
    case FiniteArrivalFamily::deterministic_trace:
    case FiniteArrivalFamily::global_periodic:
    case FiniteArrivalFamily::source_delay_periodic:
    case FiniteArrivalFamily::finite_renewal:
    case FiniteArrivalFamily::private_markov_renewal:
    case FiniteArrivalFamily::shared_round_renewal:
      return true;
  }
  return false;
}

[[nodiscard]] bool batch_has_shape(const Backlog& batch,
                                   const std::size_t dimension) {
  return batch.size() == dimension && nonnegative_backlog(batch);
}

[[nodiscard]] Result<void> validate_exact_mass_one(
    const std::vector<ExactGapAtom>& law, const std::string& context) {
  if (law.empty()) {
    return Result<void>::failure(make_error(
        "oracle_arrival_law_empty", context + " has empty finite support"));
  }
  Rational total = Rational::zero();
  for (const ExactGapAtom& atom : law) {
    if (atom.gap == 0U) {
      return Result<void>::failure(make_error(
          "oracle_arrival_gap_invalid", context + " contains gap zero"));
    }
    if (!atom.mass.is_positive()) {
      return Result<void>::failure(make_error(
          "oracle_arrival_mass_nonpositive",
          context + " contains a nonpositive rational mass"));
    }
    total = total + atom.mass;
  }
  if (total != Rational::one()) {
    return Result<void>::failure(make_error(
        "oracle_mass_not_one", context + " must have exact total mass one"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::size_t> checked_state_product(
    const std::size_t lhs, const std::size_t rhs, const OracleLimits& limits,
    const std::string& context) {
  if (rhs != 0U && lhs > limits.maximum_states / rhs) {
    return Result<std::size_t>::failure(make_error(
        "oracle_budget_exhausted",
        context + " exceeds the predictive-state budget"));
  }
  return Result<std::size_t>::success(lhs * rhs);
}

[[nodiscard]] std::size_t greatest_common_divisor(std::size_t lhs,
                                                   std::size_t rhs) {
  while (rhs != 0U) {
    const std::size_t remainder = lhs % rhs;
    lhs = rhs;
    rhs = remainder;
  }
  return lhs;
}

[[nodiscard]] Result<std::size_t> checked_period_lcm(
    const std::size_t lhs, const std::size_t rhs, const OracleLimits& limits) {
  const std::size_t divisor = greatest_common_divisor(lhs, rhs);
  const std::size_t reduced = lhs / divisor;
  return checked_state_product(reduced, rhs, limits,
                               "the source-delay joint period");
}

[[nodiscard]] ArrivalAtom deterministic_arrival_atom(
    Backlog arrivals, const std::size_t next_phase,
    std::vector<ExactJointMark> marks = {}) {
  return ArrivalAtom{std::move(arrivals), next_phase, Rational::one(),
                     std::nullopt, std::move(marks)};
}

[[nodiscard]] Result<std::vector<ArrivalRow>> materialize_deterministic_trace(
    const DeterministicTraceArrival& authored, const std::size_t dimension,
    const OracleLimits& limits) {
  if (authored.slots.empty()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_law_empty", "a deterministic trace is empty"));
  }
  if (authored.slots.size() >= limits.maximum_states) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_budget_exhausted",
        "the deterministic trace plus its terminal phase exceeds the state "
        "budget"));
  }
  std::vector<ArrivalRow> rows(authored.slots.size() + 1U);
  for (std::size_t slot = 0U; slot < authored.slots.size(); ++slot) {
    if (!batch_has_shape(authored.slots[slot], dimension)) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_atom_invalid",
          "a deterministic trace batch has the wrong dimension or is "
          "negative"));
    }
    rows[slot].atoms.push_back(deterministic_arrival_atom(
        authored.slots[slot], slot + 1U));
  }
  rows.back().atoms.push_back(deterministic_arrival_atom(
      Backlog(dimension, BigInt{0}), rows.size() - 1U));
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] Result<std::vector<ArrivalRow>> materialize_global_periodic(
    const GlobalPeriodicArrival& authored, const std::size_t dimension,
    const OracleLimits& limits) {
  if (authored.period.empty()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_law_empty", "a global periodic word is empty"));
  }
  if (authored.period.size() > limits.maximum_states) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_budget_exhausted",
        "the global period exceeds the predictive-state budget"));
  }
  std::vector<ArrivalRow> rows(authored.period.size());
  for (std::size_t phase = 0U; phase < rows.size(); ++phase) {
    if (!batch_has_shape(authored.period[phase], dimension)) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_atom_invalid",
          "a global periodic batch has the wrong dimension or is negative"));
    }
    rows[phase].atoms.push_back(deterministic_arrival_atom(
        authored.period[phase], (phase + 1U) % rows.size()));
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] Result<std::vector<ArrivalRow>>
materialize_source_delay_periodic(const SourceDelayPeriodicArrival& authored,
                                  const std::size_t dimension,
                                  const OracleLimits& limits) {
  if (authored.sources.size() != dimension) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_atom_invalid",
        "source-delay periodic input needs one authored source per queue"));
  }
  std::size_t joint_period = 1U;
  for (const SourcePeriodicPattern& source : authored.sources) {
    if (source.period.empty() ||
        std::any_of(source.period.begin(), source.period.end(),
                    [](const BigInt& batch) { return batch < 0; })) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_atom_invalid",
          "every source period must be finite, nonempty, and nonnegative"));
    }
    auto combined =
        checked_period_lcm(joint_period, source.period.size(), limits);
    if (!combined) {
      return Result<std::vector<ArrivalRow>>::failure(combined.error());
    }
    joint_period = combined.value();
  }
  std::vector<ArrivalRow> rows(joint_period);
  for (std::size_t phase = 0U; phase < joint_period; ++phase) {
    Backlog arrivals(dimension, BigInt{0});
    for (std::size_t source = 0U; source < dimension; ++source) {
      const SourcePeriodicPattern& pattern = authored.sources[source];
      const std::size_t index =
          (phase + pattern.phase_offset % pattern.period.size()) %
          pattern.period.size();
      arrivals[source] = pattern.period[index];
    }
    rows[phase].atoms.push_back(deterministic_arrival_atom(
        std::move(arrivals), (phase + 1U) % joint_period));
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] std::vector<std::size_t> decode_mixed_radix(
    std::size_t encoded, const std::vector<std::size_t>& radices) {
  std::vector<std::size_t> digits(radices.size(), 0U);
  for (std::size_t index = 0U; index < radices.size(); ++index) {
    digits[index] = encoded % radices[index];
    encoded /= radices[index];
  }
  return digits;
}

[[nodiscard]] std::size_t encode_mixed_radix(
    const std::vector<std::size_t>& digits,
    const std::vector<std::size_t>& radices) {
  std::size_t encoded = 0U;
  std::size_t multiplier = 1U;
  for (std::size_t index = 0U; index < radices.size(); ++index) {
    encoded += digits[index] * multiplier;
    multiplier *= radices[index];
  }
  return encoded;
}

struct RenewalWorkingAtom final {
  Backlog arrivals;
  std::vector<std::size_t> next_digits;
  Rational mass;
};

[[nodiscard]] Result<std::vector<ArrivalRow>>
materialize_factorized_renewal(const FactorizedRenewalArrival& authored,
                               const std::size_t dimension,
                               const OracleLimits& limits) {
  if (authored.sources.size() != dimension) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_atom_invalid",
        "factorized renewal input needs one authored source per queue"));
  }
  std::vector<std::size_t> radices;
  radices.reserve(dimension);
  std::size_t state_count = 1U;
  for (std::size_t source = 0U; source < dimension; ++source) {
    const FactorizedRenewalSource& input = authored.sources[source];
    if (input.batch < 0) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_atom_invalid",
          "a factorized renewal batch cannot be negative"));
    }
    auto valid = validate_exact_mass_one(
        input.gap_law, "factorized renewal source " + std::to_string(source));
    if (!valid) {
      return Result<std::vector<ArrivalRow>>::failure(valid.error());
    }
    std::size_t maximum_gap = 0U;
    for (const ExactGapAtom& gap : input.gap_law) {
      maximum_gap = std::max(maximum_gap, gap.gap);
    }
    radices.push_back(maximum_gap);
    auto product = checked_state_product(state_count, maximum_gap, limits,
                                         "the renewal countdown product");
    if (!product) {
      return Result<std::vector<ArrivalRow>>::failure(product.error());
    }
    state_count = product.value();
  }

  std::vector<ArrivalRow> rows(state_count);
  for (std::size_t phase = 0U; phase < state_count; ++phase) {
    const std::vector<std::size_t> countdowns =
        decode_mixed_radix(phase, radices);
    std::vector<RenewalWorkingAtom> work{
        RenewalWorkingAtom{Backlog(dimension, BigInt{0}), countdowns,
                           Rational::one()}};
    for (std::size_t source = 0U; source < dimension; ++source) {
      if (countdowns[source] != 0U) {
        for (RenewalWorkingAtom& atom : work) {
          atom.next_digits[source] = countdowns[source] - 1U;
        }
        continue;
      }
      std::vector<RenewalWorkingAtom> expanded;
      for (const RenewalWorkingAtom& prior : work) {
        for (const ExactGapAtom& gap : authored.sources[source].gap_law) {
          if (expanded.size() >= limits.maximum_branches) {
            return Result<std::vector<ArrivalRow>>::failure(make_error(
                "oracle_budget_exhausted",
                "one factorized renewal row exhausted the branch budget"));
          }
          RenewalWorkingAtom next = prior;
          next.arrivals[source] = authored.sources[source].batch;
          next.next_digits[source] = gap.gap - 1U;
          next.mass = prior.mass * gap.mass;
          expanded.push_back(std::move(next));
        }
      }
      work = std::move(expanded);
    }
    if (work.size() > limits.maximum_branches) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_budget_exhausted",
          "one factorized renewal row exceeds the branch budget"));
    }
    for (RenewalWorkingAtom& atom : work) {
      rows[phase].atoms.push_back(ArrivalAtom{
          std::move(atom.arrivals),
          encode_mixed_radix(atom.next_digits, radices), atom.mass,
          std::nullopt, {}});
    }
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] Result<std::vector<ArrivalRow>> materialize_joint_renewal(
    const JointRenewalArrival& authored, const std::size_t dimension,
    const OracleLimits& limits) {
  if (authored.law.empty()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_law_empty", "a joint renewal law is empty"));
  }
  Rational total = Rational::zero();
  std::size_t maximum_gap = 0U;
  for (const JointRenewalAtom& atom : authored.law) {
    if (!batch_has_shape(atom.arrivals, dimension) || atom.gap == 0U) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_atom_invalid",
          "a joint renewal atom has an invalid batch or gap"));
    }
    if (!atom.mass.is_positive()) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_mass_nonpositive",
          "a joint renewal atom has nonpositive mass"));
    }
    maximum_gap = std::max(maximum_gap, atom.gap);
    total = total + atom.mass;
  }
  if (total != Rational::one()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_mass_not_one",
        "the joint renewal law must have exact total mass one"));
  }
  if (maximum_gap > limits.maximum_states) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_budget_exhausted",
        "the joint renewal countdown exceeds the state budget"));
  }
  std::vector<ArrivalRow> rows(maximum_gap);
  for (const JointRenewalAtom& atom : authored.law) {
    rows[0U].atoms.push_back(ArrivalAtom{atom.arrivals, atom.gap - 1U,
                                         atom.mass, std::nullopt,
                                         atom.joint_marks});
  }
  const Backlog zero(dimension, BigInt{0});
  for (std::size_t countdown = 1U; countdown < maximum_gap; ++countdown) {
    rows[countdown].atoms.push_back(
        deterministic_arrival_atom(zero, countdown - 1U));
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

struct PrivateLocalState final {
  std::size_t markov_state{0U};
  std::size_t countdown{0U};
  friend bool operator==(const PrivateLocalState&,
                         const PrivateLocalState&) = default;
};

[[nodiscard]] std::optional<std::size_t> find_private_local(
    const std::vector<PrivateLocalState>& states,
    const PrivateLocalState& sought) {
  const auto found = std::find(states.begin(), states.end(), sought);
  if (found == states.end()) {
    return std::nullopt;
  }
  return static_cast<std::size_t>(std::distance(states.begin(), found));
}

[[nodiscard]] Result<std::vector<ArrivalRow>>
materialize_private_markov_renewal(
    const PrivateMarkovRenewalArrival& authored,
    const std::size_t dimension, const OracleLimits& limits) {
  if (authored.sources.size() != dimension) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_atom_invalid",
        "private Markov renewal input needs one source per queue"));
  }
  std::vector<std::vector<PrivateLocalState>> local_states(dimension);
  std::vector<std::size_t> radices;
  std::size_t state_count = 1U;
  for (std::size_t source = 0U; source < dimension; ++source) {
    const PrivateMarkovRenewalSource& input = authored.sources[source];
    if (input.states.empty() || input.initial_state >= input.states.size() ||
        input.initial_gap == 0U) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_markov_invalid",
          "a private Markov source has invalid initialization"));
    }
    for (std::size_t state = 0U; state < input.states.size(); ++state) {
      const PrivateMarkovRenewalState& row = input.states[state];
      if (row.event_batch < 0 || row.transitions.empty()) {
        return Result<std::vector<ArrivalRow>>::failure(make_error(
            "oracle_arrival_markov_invalid",
            "a private Markov state has a negative batch or no transition"));
      }
      Rational transition_mass = Rational::zero();
      for (const PrivateMarkovTransition& transition : row.transitions) {
        if (transition.next_state >= input.states.size() ||
            !transition.mass.is_positive()) {
          return Result<std::vector<ArrivalRow>>::failure(make_error(
              "oracle_arrival_markov_invalid",
              "a private Markov transition is invalid"));
        }
        transition_mass = transition_mass + transition.mass;
      }
      if (transition_mass != Rational::one()) {
        return Result<std::vector<ArrivalRow>>::failure(make_error(
            "oracle_mass_not_one",
            "a private Markov transition row must have mass one"));
      }
      auto gap_valid = validate_exact_mass_one(
          row.entered_gap_law,
          "private Markov entered-state gap law " + std::to_string(state));
      if (!gap_valid) {
        return Result<std::vector<ArrivalRow>>::failure(gap_valid.error());
      }
    }

    auto& locals = local_states[source];
    locals.push_back(
        PrivateLocalState{input.initial_state, input.initial_gap - 1U});
    for (std::size_t state = 0U; state < input.states.size(); ++state) {
      std::size_t maximum_gap = 0U;
      for (const ExactGapAtom& gap : input.states[state].entered_gap_law) {
        maximum_gap = std::max(maximum_gap, gap.gap);
      }
      if (state == input.initial_state) {
        maximum_gap = std::max(maximum_gap, input.initial_gap);
      }
      if (maximum_gap > limits.maximum_states ||
          locals.size() > limits.maximum_states - maximum_gap) {
        return Result<std::vector<ArrivalRow>>::failure(make_error(
            "oracle_budget_exhausted",
            "a private Markov countdown schema exceeds the state budget"));
      }
      for (std::size_t countdown = 0U; countdown < maximum_gap; ++countdown) {
        const PrivateLocalState candidate{state, countdown};
        if (std::find(locals.begin(), locals.end(), candidate) ==
            locals.end()) {
          locals.push_back(candidate);
        }
      }
    }
    radices.push_back(locals.size());
    auto product = checked_state_product(
        state_count, locals.size(), limits,
        "the private Markov predictive-state product");
    if (!product) {
      return Result<std::vector<ArrivalRow>>::failure(product.error());
    }
    state_count = product.value();
  }

  std::vector<ArrivalRow> rows(state_count);
  for (std::size_t phase = 0U; phase < state_count; ++phase) {
    const std::vector<std::size_t> local_indices =
        decode_mixed_radix(phase, radices);
    std::vector<RenewalWorkingAtom> work{
        RenewalWorkingAtom{Backlog(dimension, BigInt{0}), local_indices,
                           Rational::one()}};
    for (std::size_t source = 0U; source < dimension; ++source) {
      const PrivateLocalState current =
          local_states[source][local_indices[source]];
      if (current.countdown != 0U) {
        const auto next = find_private_local(
            local_states[source],
            PrivateLocalState{current.markov_state, current.countdown - 1U});
        if (!next.has_value()) {
          return Result<std::vector<ArrivalRow>>::failure(make_error(
              "oracle_arrival_markov_invalid",
              "a private countdown successor is not representable"));
        }
        for (RenewalWorkingAtom& atom : work) {
          atom.next_digits[source] = *next;
        }
        continue;
      }

      const PrivateMarkovRenewalSource& input = authored.sources[source];
      const PrivateMarkovRenewalState& current_row =
          input.states[current.markov_state];
      std::vector<RenewalWorkingAtom> expanded;
      for (const RenewalWorkingAtom& prior : work) {
        for (const PrivateMarkovTransition& transition :
             current_row.transitions) {
          // Deliberately draw from the entered state's law.  Drawing from
          // current_row here is the transition-order mutation caught by C26.
          for (const ExactGapAtom& gap :
               input.states[transition.next_state].entered_gap_law) {
            if (expanded.size() >= limits.maximum_branches) {
              return Result<std::vector<ArrivalRow>>::failure(make_error(
                  "oracle_budget_exhausted",
                  "one private Markov row exhausted the branch budget"));
            }
            const auto next = find_private_local(
                local_states[source],
                PrivateLocalState{transition.next_state, gap.gap - 1U});
            if (!next.has_value()) {
              return Result<std::vector<ArrivalRow>>::failure(make_error(
                  "oracle_arrival_markov_invalid",
                  "an entered-state gap successor is not representable"));
            }
            RenewalWorkingAtom atom = prior;
            atom.arrivals[source] = current_row.event_batch;
            atom.next_digits[source] = *next;
            atom.mass = prior.mass * transition.mass * gap.mass;
            expanded.push_back(std::move(atom));
          }
        }
      }
      work = std::move(expanded);
    }
    if (work.size() > limits.maximum_branches) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_budget_exhausted",
          "one private Markov row exceeds the branch budget"));
    }
    for (RenewalWorkingAtom& atom : work) {
      rows[phase].atoms.push_back(ArrivalAtom{
          std::move(atom.arrivals),
          encode_mixed_radix(atom.next_digits, radices), atom.mass,
          std::nullopt, {}});
    }
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] const SharedRoundEmission* shared_emission_at(
    const SharedRoundAtom& round, const std::size_t delay) {
  const auto found =
      std::find_if(round.emissions.begin(), round.emissions.end(),
                   [&](const SharedRoundEmission& emission) {
                     return emission.delay == delay;
                   });
  return found == round.emissions.end() ? nullptr : &*found;
}

[[nodiscard]] Result<std::vector<ArrivalRow>> materialize_shared_round(
    const SharedRoundArrival& authored, const std::size_t dimension,
    const OracleLimits& limits) {
  if (authored.round_length == 0U || authored.rounds.empty()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_shared_round_invalid",
        "a shared-round law needs positive length and finite support"));
  }
  Rational total = Rational::zero();
  for (std::size_t round_index = 0U; round_index < authored.rounds.size();
       ++round_index) {
    const SharedRoundAtom& round = authored.rounds[round_index];
    if (!round.mass.is_positive() || round.round_identity.empty()) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_shared_round_invalid",
          "each shared-round atom needs positive mass and an identity"));
    }
    for (std::size_t earlier = 0U; earlier < round_index; ++earlier) {
      if (authored.rounds[earlier].round_identity == round.round_identity) {
        return Result<std::vector<ArrivalRow>>::failure(make_error(
            "oracle_arrival_shared_round_invalid",
            "shared-round identities must be unique"));
      }
    }
    for (std::size_t emission_index = 0U;
         emission_index < round.emissions.size(); ++emission_index) {
      const SharedRoundEmission& emission = round.emissions[emission_index];
      if (emission.delay >= authored.round_length ||
          !batch_has_shape(emission.arrivals, dimension)) {
        return Result<std::vector<ArrivalRow>>::failure(make_error(
            "oracle_arrival_shared_round_invalid",
            "a shared-round emission has invalid delay or batch"));
      }
      for (std::size_t earlier = 0U; earlier < emission_index; ++earlier) {
        if (round.emissions[earlier].delay == emission.delay) {
          return Result<std::vector<ArrivalRow>>::failure(make_error(
              "oracle_arrival_shared_round_invalid",
              "a round may have at most one joint emission at each delay"));
        }
      }
    }
    total = total + round.mass;
  }
  if (total != Rational::one()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_mass_not_one",
        "the shared-round categorical law must have mass one"));
  }

  const std::size_t selected_offsets = authored.round_length - 1U;
  auto product = checked_state_product(authored.rounds.size(),
                                       selected_offsets, limits,
                                       "the shared-round pending state");
  if (!product) {
    return Result<std::vector<ArrivalRow>>::failure(product.error());
  }
  if (product.value() >= limits.maximum_states) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_budget_exhausted",
        "the shared-round pending phases exceed the state budget"));
  }
  const std::size_t state_count = 1U + product.value();
  std::vector<ArrivalRow> rows(state_count);
  const Backlog zero(dimension, BigInt{0});
  const auto pending_phase = [&](const std::size_t round_index,
                                 const std::size_t delay) {
    return 1U + round_index * selected_offsets + (delay - 1U);
  };

  for (std::size_t round_index = 0U; round_index < authored.rounds.size();
       ++round_index) {
    const SharedRoundAtom& round = authored.rounds[round_index];
    const SharedRoundEmission* emission = shared_emission_at(round, 0U);
    Backlog arrivals = emission == nullptr ? zero : emission->arrivals;
    std::vector<ExactJointMark> marks =
        emission == nullptr ? std::vector<ExactJointMark>{}
                            : emission->joint_marks;
    if (std::any_of(marks.begin(), marks.end(), [](const ExactJointMark& mark) {
          return mark.id == "shared-round-index";
        })) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_arrival_shared_round_invalid",
          "shared-round-index is reserved for oracle branch identity"));
    }
    marks.push_back(
        ExactJointMark{"shared-round-index", BigInt{round_index}});
    const std::size_t next = authored.round_length == 1U
                                 ? 0U
                                 : pending_phase(round_index, 1U);
    rows[0U].atoms.push_back(ArrivalAtom{std::move(arrivals), next,
                                         round.mass, std::nullopt,
                                         std::move(marks)});
  }
  for (std::size_t round_index = 0U; round_index < authored.rounds.size();
       ++round_index) {
    for (std::size_t delay = 1U; delay < authored.round_length; ++delay) {
      const SharedRoundEmission* emission =
          shared_emission_at(authored.rounds[round_index], delay);
      const std::size_t next = delay + 1U == authored.round_length
                                   ? 0U
                                   : pending_phase(round_index, delay + 1U);
      rows[pending_phase(round_index, delay)].atoms.push_back(
          deterministic_arrival_atom(
              emission == nullptr ? zero : emission->arrivals, next,
              emission == nullptr ? std::vector<ExactJointMark>{}
                                  : emission->joint_marks));
    }
  }
  return Result<std::vector<ArrivalRow>>::success(std::move(rows));
}

[[nodiscard]] bool authored_family_matches(
    const FiniteArrivalFamily family, const AuthoredFiniteArrival& authored) {
  return std::visit(
      [&](const auto& concrete) {
        using Arrival = std::decay_t<decltype(concrete)>;
        if constexpr (std::is_same_v<Arrival, DeterministicTraceArrival>) {
          return family == FiniteArrivalFamily::deterministic_trace;
        } else if constexpr (std::is_same_v<Arrival,
                                            GlobalPeriodicArrival>) {
          return family == FiniteArrivalFamily::global_periodic;
        } else if constexpr (std::is_same_v<Arrival,
                                            SourceDelayPeriodicArrival>) {
          return family == FiniteArrivalFamily::source_delay_periodic;
        } else if constexpr (std::is_same_v<Arrival,
                                            FactorizedRenewalArrival> ||
                             std::is_same_v<Arrival, JointRenewalArrival>) {
          return family == FiniteArrivalFamily::finite_renewal;
        } else if constexpr (std::is_same_v<
                                 Arrival, PrivateMarkovRenewalArrival>) {
          return family == FiniteArrivalFamily::private_markov_renewal;
        } else {
          return family == FiniteArrivalFamily::shared_round_renewal;
        }
      },
      authored);
}

[[nodiscard]] Result<std::vector<ArrivalRow>> materialize_arrival_rows(
    const SmallPhysicalModel& model, const std::size_t dimension) {
  if (!model.authored_arrival.has_value()) {
    return Result<std::vector<ArrivalRow>>::success(model.arrival_rows);
  }
  if (!model.arrival_rows.empty()) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_representation_ambiguous",
        "a physical model cannot supply both authored input and phase rows"));
  }
  if (!authored_family_matches(model.arrival_family,
                               *model.authored_arrival)) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_arrival_family_shape",
        "the authored arrival type does not match its declared family"));
  }
  auto materialized = std::visit(
      [&](const auto& authored) -> Result<std::vector<ArrivalRow>> {
        using Arrival = std::decay_t<decltype(authored)>;
        if constexpr (std::is_same_v<Arrival, DeterministicTraceArrival>) {
          return materialize_deterministic_trace(authored, dimension,
                                                 model.limits);
        } else if constexpr (std::is_same_v<Arrival,
                                            GlobalPeriodicArrival>) {
          return materialize_global_periodic(authored, dimension,
                                             model.limits);
        } else if constexpr (std::is_same_v<Arrival,
                                            SourceDelayPeriodicArrival>) {
          return materialize_source_delay_periodic(authored, dimension,
                                                   model.limits);
        } else if constexpr (std::is_same_v<Arrival,
                                            FactorizedRenewalArrival>) {
          return materialize_factorized_renewal(authored, dimension,
                                                model.limits);
        } else if constexpr (std::is_same_v<Arrival,
                                            JointRenewalArrival>) {
          return materialize_joint_renewal(authored, dimension, model.limits);
        } else if constexpr (std::is_same_v<
                                 Arrival, PrivateMarkovRenewalArrival>) {
          return materialize_private_markov_renewal(authored, dimension,
                                                    model.limits);
        } else {
          return materialize_shared_round(authored, dimension, model.limits);
        }
      },
      *model.authored_arrival);
  if (!materialized) {
    return materialized;
  }
  const auto& rows = materialized.value();
  if (rows.size() > model.limits.maximum_states) {
    return Result<std::vector<ArrivalRow>>::failure(make_error(
        "oracle_budget_exhausted",
        "the authored arrival expansion exceeds the predictive-state "
        "budget"));
  }
  std::size_t branches = 0U;
  for (const ArrivalRow& row : rows) {
    if (row.atoms.size() > model.limits.maximum_branches - branches) {
      return Result<std::vector<ArrivalRow>>::failure(make_error(
          "oracle_budget_exhausted",
          "the authored arrival expansion exceeds the branch budget", 0U,
          branches));
    }
    branches += row.atoms.size();
  }
  return materialized;
}

[[nodiscard]] bool family_requires_deterministic_rows(
    const FiniteArrivalFamily family) {
  return family == FiniteArrivalFamily::deterministic_trace ||
         family == FiniteArrivalFamily::global_periodic ||
         family == FiniteArrivalFamily::source_delay_periodic;
}

[[nodiscard]] bool valid_priority(const PriorityOrder& priority,
                                  const std::size_t dimension) {
  if (priority.size() != dimension) {
    return false;
  }
  std::vector<bool> seen(dimension, false);
  for (const std::size_t coordinate : priority) {
    if (coordinate >= dimension || seen[coordinate]) {
      return false;
    }
    seen[coordinate] = true;
  }
  return true;
}

[[nodiscard]] const TieRow* find_tie_row(
    const std::vector<TieRow>& rows,
    const std::vector<BigInt>& controller_memory) {
  const auto found = std::find_if(
      rows.begin(), rows.end(), [&](const TieRow& row) {
        return row.current_controller == controller_memory;
      });
  return found == rows.end() ? nullptr : &*found;
}

struct ValidatedModelShape final {
  std::size_t dimension{0U};
  std::size_t controller_width{0U};
  std::vector<ArrivalRow> arrival_rows;
};

[[nodiscard]] Result<ValidatedModelShape> validate_model(
    const SmallPhysicalModel& model, const FiniteCoupledInitialLaw& initial,
    const std::size_t horizon) {
  if (horizon == std::numeric_limits<std::size_t>::max()) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_horizon_overflow",
        "the requested horizon would overflow the admission-boundary index"));
  }
  if (horizon > model.limits.maximum_horizon) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_horizon_limit", "the requested horizon exceeds the oracle limit"));
  }
  if (!model.tie_and_arrival_conditionally_independent) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_joint_innovation_unsupported",
        "tie and arrival rows may be multiplied only under the declared "
        "conditional-independence premise"));
  }
  if (!model.residence_rule.prefix_adapted) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_nonadapted_stop",
        "the residence stopping rule must use only the revealed prefix"));
  }
  if (!valid_arrival_family(model.arrival_family)) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_arrival_family_invalid", "the finite arrival family is invalid"));
  }

  const std::size_t dimension = constraint_dimension(model.constraint);
  if (dimension == 0U) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_dimension_invalid", "a physical model needs at least one queue"));
  }
  if (dimension > model.limits.maximum_path_dimension) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_dimension_limit",
        "the physical path dimension exceeds the oracle path limit"));
  }
  if ((model.residence_rule.kind ==
           ResidenceRuleKind::target_queue_empty_after_slot ||
       model.residence_rule.kind ==
           ResidenceRuleKind::target_queue_becomes_empty_after_slot ||
       model.residence_rule.kind == ResidenceRuleKind::target_departure) &&
      model.residence_rule.target >= dimension) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_residence_target_invalid",
        "the residence target is outside the physical queue dimension"));
  }

  const auto initial_atoms = initial.atoms();
  if (initial_atoms.empty()) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_initial_law_empty", "the coupled initial law is empty"));
  }
  if (initial_atoms.size() > model.limits.maximum_states) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_budget_exhausted",
        "the initial frontier exceeds the state budget", 0U, 0U));
  }
  const std::size_t controller_width =
      initial_atoms.front().state.controller_memory.size();
  for (const auto& atom : initial_atoms) {
    if (atom.state.queue.size() != dimension ||
        !nonnegative_backlog(atom.state.queue)) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_initial_state_invalid",
          "an initial atom has the wrong queue dimension or a negative queue"));
    }
    if (atom.state.controller_memory.size() != controller_width) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_controller_schema_mismatch",
          "all initial atoms must use one controller-memory schema"));
    }
  }

  auto materialized_rows = materialize_arrival_rows(model, dimension);
  if (!materialized_rows) {
    return Result<ValidatedModelShape>::failure(materialized_rows.error());
  }
  std::vector<ArrivalRow> arrival_rows =
      std::move(materialized_rows).value();
  if (arrival_rows.empty()) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_arrival_rows_empty", "the finite arrival model has no rows"));
  }
  for (std::size_t phase = 0U; phase < arrival_rows.size(); ++phase) {
    const auto& row = arrival_rows[phase];
    if (row.atoms.empty()) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_arrival_row_empty", "every arrival phase needs a finite row"));
    }
    // The current generic phase-row type has no authored gap, private-state,
    // source, or round fields from which stronger renewal semantics could be
    // reconstructed.  It can, however, enforce that the three deterministic
    // families really do have one exact successor at every phase.
    if (!model.authored_arrival.has_value() &&
        family_requires_deterministic_rows(model.arrival_family) &&
        row.atoms.size() != 1U) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_arrival_family_shape",
          "a deterministic or periodic oracle family requires exactly one "
          "arrival atom per predictive phase"));
    }
    Rational row_mass = Rational::zero();
    for (const auto& atom : row.atoms) {
      if (!atom.mass.is_positive()) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_arrival_mass_nonpositive",
            "arrival-row atoms must have strictly positive rational mass"));
      }
      if (atom.arrivals.size() != dimension ||
          !nonnegative_backlog(atom.arrivals)) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_arrival_atom_invalid",
            "an arrival atom has the wrong dimension or a negative batch"));
      }
      if (atom.next_phase >= arrival_rows.size()) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_arrival_phase_invalid",
            "an arrival atom names a nonexistent successor phase"));
      }
      if (atom.controller_after_arrival.has_value() &&
          atom.controller_after_arrival->size() != controller_width) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_controller_schema_mismatch",
            "a post-arrival controller update has the wrong schema"));
      }
      for (std::size_t mark = 0U; mark < atom.joint_marks.size(); ++mark) {
        if (atom.joint_marks[mark].id.empty()) {
          return Result<ValidatedModelShape>::failure(make_error(
              "oracle_mark_id_empty",
              "every exact joint arrival mark needs a nonempty identifier"));
        }
        for (std::size_t earlier = 0U; earlier < mark; ++earlier) {
          if (atom.joint_marks[earlier].id == atom.joint_marks[mark].id) {
            return Result<ValidatedModelShape>::failure(make_error(
                "oracle_mark_id_duplicate",
                "exact joint arrival mark identifiers must be unique within "
                "an atom"));
          }
        }
      }
      row_mass = row_mass + atom.mass;
    }
    if (row_mass != Rational::one()) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_mass_not_one",
          "every finite arrival row must have exact total mass one"));
    }
  }

  if (model.tie_rows.empty()) {
    return Result<ValidatedModelShape>::failure(make_error(
        "oracle_tie_rows_empty", "the physical model has no finite tie rows"));
  }
  for (std::size_t row_index = 0U; row_index < model.tie_rows.size();
       ++row_index) {
    const auto& row = model.tie_rows[row_index];
    if (row.current_controller.size() != controller_width) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_controller_schema_mismatch",
          "a tie-row controller key has the wrong schema"));
    }
    for (std::size_t earlier = 0U; earlier < row_index; ++earlier) {
      if (model.tie_rows[earlier].current_controller ==
          row.current_controller) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_tie_row_duplicate",
            "controller-memory keys must identify unique tie rows"));
      }
    }
    if (row.branches.empty()) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_tie_row_empty", "every controller state needs a finite tie row"));
    }
    Rational row_mass = Rational::zero();
    for (const auto& branch : row.branches) {
      if (!branch.mass.is_positive()) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_tie_mass_nonpositive",
            "tie-row atoms must have strictly positive rational mass"));
      }
      if (!valid_priority(branch.priority, dimension)) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_priority_invalid",
            "a tie branch priority is not a queue permutation"));
      }
      if (branch.controller_after_decision.size() != controller_width) {
        return Result<ValidatedModelShape>::failure(make_error(
            "oracle_controller_schema_mismatch",
            "a pre-arrival controller update has the wrong schema"));
      }
      row_mass = row_mass + branch.mass;
    }
    if (row_mass != Rational::one()) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_mass_not_one",
          "every finite tie row must have exact total mass one"));
    }
  }

  for (const auto& atom : initial_atoms) {
    if (atom.state.arrival_phase >= arrival_rows.size()) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_initial_phase_invalid",
          "an initial atom names a nonexistent arrival phase"));
    }
    if (find_tie_row(model.tie_rows, atom.state.controller_memory) == nullptr) {
      return Result<ValidatedModelShape>::failure(make_error(
          "oracle_missing_tie_row",
          "an initial controller state has no configured tie row"));
    }
  }

  // F-C26-02 relies on F-C26-01 for the independent structural feasibility
  // predicates.  Exercise one harmless row up front so even horizon zero
  // rejects a malformed constraint rather than silently accepting it.
  Backlog zero_backlog(dimension, BigInt{0});
  EligibilityMask no_eligible(dimension, std::uint8_t{0});
  PriorityOrder identity_priority(dimension);
  for (std::size_t index = 0U; index < dimension; ++index) {
    identity_priority[index] = index;
  }
  auto constraint_check = oracle_enumerate_schedule_face(
      model.constraint, zero_backlog, no_eligible, identity_priority,
      model.limits);
  if (!constraint_check) {
    return Result<ValidatedModelShape>::failure(constraint_check.error());
  }

  return Result<ValidatedModelShape>::success(ValidatedModelShape{
      dimension, controller_width, std::move(arrival_rows)});
}

[[nodiscard]] bool residence_stops(const AdaptedResidenceRule& rule,
                                   const SlotRecord& slot) {
  switch (rule.kind) {
    case ResidenceRuleKind::none:
      return false;
    case ResidenceRuleKind::target_queue_empty_after_slot:
      return slot.postarrival.queue[rule.target] == 0;
    case ResidenceRuleKind::target_queue_becomes_empty_after_slot:
      return slot.predecision.queue[rule.target] > 0 &&
             slot.postarrival.queue[rule.target] == 0;
    case ResidenceRuleKind::target_departure:
      return slot.departures[rule.target] != 0U;
    case ResidenceRuleKind::arrival_phase_change:
      return slot.predecision.arrival_phase !=
             slot.postarrival.arrival_phase;
  }
  return false;
}

[[nodiscard]] std::vector<ResidenceWord> make_residence_words(
    const PathHistory& history, const AdaptedResidenceRule& rule) {
  std::vector<ResidenceWord> words;
  ResidenceWord current;
  for (const auto& slot : history.slots) {
    current.slots.push_back(slot);
    if (residence_stops(rule, slot)) {
      current.right_censored = false;
      words.push_back(std::move(current));
      current = ResidenceWord{};
    }
  }
  if (!current.slots.empty()) {
    current.right_censored = true;
    words.push_back(std::move(current));
  }
  return words;
}

[[nodiscard]] Result<std::vector<ResidencePathAtom>> make_residence_paths(
    const ExactPathFrontier& frontier,
    const AdaptedResidenceRule& residence_rule) {
  std::vector<ResidencePathAtom> projected;
  projected.reserve(frontier.atoms.size());
  for (const auto& atom : frontier.atoms) {
    projected.push_back(ResidencePathAtom{
        make_residence_words(atom.history, residence_rule), atom.mass});
  }
  std::sort(projected.begin(), projected.end(),
            [](const ResidencePathAtom& lhs, const ResidencePathAtom& rhs) {
              return compare_residence_path(lhs, rhs) < 0;
            });

  std::vector<ResidencePathAtom> merged;
  merged.reserve(projected.size());
  for (auto& atom : projected) {
    if (!atom.mass.is_positive()) {
      return Result<std::vector<ResidencePathAtom>>::failure(make_error(
          "oracle_residence_mass_nonpositive",
          "a projected residence path has nonpositive mass"));
    }
    if (!merged.empty() &&
        compare_residence_path(merged.back(), atom) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  if (total_residence_mass(merged) != Rational::one()) {
    return Result<std::vector<ResidencePathAtom>>::failure(make_error(
        "oracle_mass_not_conserved",
        "residence projection did not preserve exact total mass one"));
  }
  return Result<std::vector<ResidencePathAtom>>::success(std::move(merged));
}

[[nodiscard]] ResidenceWord canonical_complete_word(
    const ResidenceWord& word) {
  ResidenceWord canonical = word;
  canonical.right_censored = false;
  for (std::size_t offset = 0U; offset < canonical.slots.size(); ++offset) {
    canonical.slots[offset].decision_slot = offset;
    canonical.slots[offset].admission_boundary = offset + 1U;
  }
  return canonical;
}

[[nodiscard]] Result<std::vector<ResidenceWordLawAtom>>
merge_residence_word_atoms(std::vector<ResidenceWordLawAtom> atoms) {
  std::sort(atoms.begin(), atoms.end(),
            [](const ResidenceWordLawAtom& lhs,
               const ResidenceWordLawAtom& rhs) {
              return compare_residence_word_law_key(lhs, rhs) < 0;
            });
  std::vector<ResidenceWordLawAtom> merged;
  merged.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!atom.mass.is_positive() || atom.word.right_censored ||
        atom.word.slots.empty()) {
      return Result<std::vector<ResidenceWordLawAtom>>::failure(make_error(
          "oracle_residence_word_invalid",
          "a complete residence atom needs positive mass and a nonempty "
          "uncensored word"));
    }
    if (!merged.empty() &&
        compare_residence_word_law_key(merged.back(), atom) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  return Result<std::vector<ResidenceWordLawAtom>>::success(
      std::move(merged));
}

[[nodiscard]] Result<std::vector<ConcatenatedResidencePathAtom>>
merge_concatenated_paths(std::vector<ConcatenatedResidencePathAtom> atoms) {
  std::sort(atoms.begin(), atoms.end(),
            [](const ConcatenatedResidencePathAtom& lhs,
               const ConcatenatedResidencePathAtom& rhs) {
              return compare_concatenated_residence_key(lhs, rhs) < 0;
            });
  std::vector<ConcatenatedResidencePathAtom> merged;
  merged.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!atom.mass.is_positive()) {
      return Result<std::vector<ConcatenatedResidencePathAtom>>::failure(
          make_error("oracle_residence_mass_nonpositive",
                     "a concatenated residence path has nonpositive mass"));
    }
    if (!merged.empty() &&
        compare_concatenated_residence_key(merged.back(), atom) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  return Result<std::vector<ConcatenatedResidencePathAtom>>::success(
      std::move(merged));
}

struct StateMassAtom final {
  FullState state;
  Rational mass;
};

[[nodiscard]] std::vector<StateMassAtom> merge_state_mass_atoms(
    std::vector<StateMassAtom> atoms) {
  std::sort(atoms.begin(), atoms.end(),
            [](const StateMassAtom& lhs, const StateMassAtom& rhs) {
              return compare_full_state(lhs.state, rhs.state) < 0;
            });
  std::vector<StateMassAtom> merged;
  merged.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!merged.empty() &&
        compare_full_state(merged.back().state, atom.state) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  return merged;
}

[[nodiscard]] bool same_state_mass_law(
    const std::vector<StateMassAtom>& lhs,
    const std::vector<StateMassAtom>& rhs) {
  if (lhs.size() != rhs.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < lhs.size(); ++index) {
    if (compare_full_state(lhs[index].state, rhs[index].state) != 0 ||
        lhs[index].mass != rhs[index].mass) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] ResidenceMarkedEdge marked_edge_from_slot(
    const SlotRecord& slot) {
  return ResidenceMarkedEdge{
      slot.predecision,       slot.schedule,
      slot.departures,        slot.arrivals,
      slot.joint_marks,       slot.postarrival,
      slot.tie_branch_identity, slot.timing};
}

[[nodiscard]] Result<std::vector<StationaryMarkedEdgeAtom>>
merge_marked_edges(std::vector<StationaryMarkedEdgeAtom> atoms) {
  std::sort(atoms.begin(), atoms.end(),
            [](const StationaryMarkedEdgeAtom& lhs,
               const StationaryMarkedEdgeAtom& rhs) {
              return compare_marked_edge(lhs.edge, rhs.edge) < 0;
            });
  std::vector<StationaryMarkedEdgeAtom> merged;
  merged.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!atom.mass.is_positive()) {
      return Result<std::vector<StationaryMarkedEdgeAtom>>::failure(
          make_error("oracle_residence_mass_nonpositive",
                     "a stationary marked-edge atom has nonpositive mass"));
    }
    if (!merged.empty() && compare_marked_edge(merged.back().edge,
                                                atom.edge) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  return Result<std::vector<StationaryMarkedEdgeAtom>>::success(
      std::move(merged));
}

[[nodiscard]] Result<ExactResidenceDerivation> derive_residence_laws(
    const std::vector<ResidencePathAtom>& paths) {
  ExactResidenceDerivation result;
  std::vector<ResidenceWordLawAtom> occurrences;
  std::vector<ResidenceWordLawAtom> first_words;
  std::vector<ConcatenatedResidencePathAtom> concatenated;
  concatenated.reserve(paths.size());

  for (const ResidencePathAtom& path : paths) {
    ConcatenatedResidencePathAtom concatenated_atom;
    concatenated_atom.mass = path.mass;
    bool seen_censored = false;
    for (std::size_t word_index = 0U; word_index < path.words.size();
         ++word_index) {
      const ResidenceWord& word = path.words[word_index];
      if (word.slots.empty()) {
        return Result<ExactResidenceDerivation>::failure(make_error(
            "oracle_residence_word_invalid",
            "a finite path contains an empty residence word"));
      }
      if (seen_censored) {
        return Result<ExactResidenceDerivation>::failure(make_error(
            "oracle_residence_word_invalid",
            "a censored residence suffix must be the last word"));
      }
      concatenated_atom.slots.insert(concatenated_atom.slots.end(),
                                     word.slots.begin(), word.slots.end());
      if (word.right_censored) {
        if (word_index + 1U != path.words.size()) {
          return Result<ExactResidenceDerivation>::failure(make_error(
              "oracle_residence_word_invalid",
              "a censored residence suffix must be the last word"));
        }
        seen_censored = true;
        concatenated_atom.right_censored = true;
        continue;
      }

      concatenated_atom.complete_word_boundaries.push_back(
          concatenated_atom.slots.size());
      const FullState entrance = word.slots.front().predecision;
      const FullState endpoint = word.slots.back().postarrival;
      ResidenceWordLawAtom occurrence{
          entrance, canonical_complete_word(word), endpoint, path.mass};
      if (word_index == 0U) {
        first_words.push_back(occurrence);
      }
      occurrences.push_back(std::move(occurrence));
    }
    if (seen_censored) {
      result.right_censored_path_mass =
          result.right_censored_path_mass + path.mass;
    }
    concatenated.push_back(std::move(concatenated_atom));
  }

  auto merged_concatenated = merge_concatenated_paths(std::move(concatenated));
  if (!merged_concatenated) {
    return Result<ExactResidenceDerivation>::failure(
        merged_concatenated.error());
  }
  result.concatenated_slot_law =
      std::move(merged_concatenated).value();
  Rational concatenated_mass = Rational::zero();
  for (const auto& atom : result.concatenated_slot_law) {
    concatenated_mass = concatenated_mass + atom.mass;
  }
  if (concatenated_mass != Rational::one()) {
    return Result<ExactResidenceDerivation>::failure(make_error(
        "oracle_mass_not_conserved",
        "concatenating residence words changed exact path mass"));
  }

  auto merged_first = merge_residence_word_atoms(std::move(first_words));
  if (!merged_first) {
    return Result<ExactResidenceDerivation>::failure(merged_first.error());
  }
  result.first_complete_word_law = std::move(merged_first).value();
  for (const auto& atom : result.first_complete_word_law) {
    result.first_word_survival_mass =
        result.first_word_survival_mass + atom.mass;
  }
  if (result.first_word_survival_mass > Rational::one()) {
    return Result<ExactResidenceDerivation>::failure(make_error(
        "oracle_mass_not_conserved",
        "the first complete residence sublaw exceeds mass one"));
  }
  result.first_word_defective_mass =
      Rational::one() - result.first_word_survival_mass;

  auto merged_occurrences =
      merge_residence_word_atoms(std::move(occurrences));
  if (!merged_occurrences) {
    return Result<ExactResidenceDerivation>::failure(
        merged_occurrences.error());
  }
  for (const auto& atom : merged_occurrences.value()) {
    result.complete_event_occurrence_mass =
        result.complete_event_occurrence_mass + atom.mass;
  }
  if (result.complete_event_occurrence_mass.is_zero()) {
    result.stationary_status =
        ResidenceStationaryStatus::no_complete_residence;
    return Result<ExactResidenceDerivation>::success(std::move(result));
  }

  result.event_word_law = std::move(merged_occurrences).value();
  for (auto& atom : result.event_word_law) {
    auto normalized =
        checked_divide(atom.mass, result.complete_event_occurrence_mass);
    if (!normalized) {
      return Result<ExactResidenceDerivation>::failure(normalized.error());
    }
    atom.mass = std::move(normalized).value();
  }

  Rational mean_length = Rational::zero();
  for (const auto& atom : result.event_word_law) {
    mean_length = mean_length +
                  atom.mass * Rational(BigInt{atom.word.slots.size()});
  }
  if (!mean_length.is_positive()) {
    return Result<ExactResidenceDerivation>::failure(make_error(
        "oracle_residence_word_invalid",
        "the normalized residence law has zero mean length"));
  }
  result.mean_word_length = mean_length;

  for (const auto& atom : result.event_word_law) {
    auto offset_mass = checked_divide(atom.mass, mean_length);
    if (!offset_mass) {
      return Result<ExactResidenceDerivation>::failure(offset_mass.error());
    }
    for (std::size_t offset = 0U; offset < atom.word.slots.size(); ++offset) {
      result.length_biased_occupation.push_back(ResidenceSuspensionAtom{
          atom.entrance, atom.word, atom.endpoint, offset,
          offset_mass.value()});
    }
  }
  Rational occupation_mass = Rational::zero();
  for (const auto& atom : result.length_biased_occupation) {
    occupation_mass = occupation_mass + atom.mass;
  }
  if (occupation_mass != Rational::one()) {
    return Result<ExactResidenceDerivation>::failure(make_error(
        "oracle_mass_not_conserved",
        "the length-biased residence suspension does not have mass one"));
  }

  for (const auto& atom : result.event_word_law) {
    if (result.event_kernel.empty() ||
        compare_full_state(result.event_kernel.back().entrance,
                           atom.entrance) != 0) {
      result.event_kernel.push_back(
          ResidenceKernelRow{atom.entrance, Rational::zero(), {}});
    }
    auto& row = result.event_kernel.back();
    row.entrance_mass = row.entrance_mass + atom.mass;
    row.transitions.push_back(
        ResidenceKernelTransition{atom.word, atom.endpoint, atom.mass});
  }
  for (auto& row : result.event_kernel) {
    for (auto& transition : row.transitions) {
      auto conditional = checked_divide(transition.mass, row.entrance_mass);
      if (!conditional) {
        return Result<ExactResidenceDerivation>::failure(conditional.error());
      }
      transition.mass = std::move(conditional).value();
    }
  }

  std::vector<StateMassAtom> entrances;
  std::vector<StateMassAtom> endpoints;
  entrances.reserve(result.event_word_law.size());
  endpoints.reserve(result.event_word_law.size());
  for (const auto& atom : result.event_word_law) {
    entrances.push_back(StateMassAtom{atom.entrance, atom.mass});
    endpoints.push_back(StateMassAtom{atom.endpoint, atom.mass});
  }
  entrances = merge_state_mass_atoms(std::move(entrances));
  endpoints = merge_state_mass_atoms(std::move(endpoints));
  result.entrance_endpoint_flow_balanced =
      same_state_mass_law(entrances, endpoints);
  if (!result.entrance_endpoint_flow_balanced) {
    result.stationary_status =
        ResidenceStationaryStatus::endpoint_flow_not_stationary;
    return Result<ExactResidenceDerivation>::success(std::move(result));
  }

  std::vector<StationaryMarkedEdgeAtom> marked_edges;
  marked_edges.reserve(result.length_biased_occupation.size());
  for (const auto& atom : result.length_biased_occupation) {
    marked_edges.push_back(StationaryMarkedEdgeAtom{
        marked_edge_from_slot(atom.word.slots[atom.offset]), atom.mass});
  }
  auto merged_edges = merge_marked_edges(std::move(marked_edges));
  if (!merged_edges) {
    return Result<ExactResidenceDerivation>::failure(merged_edges.error());
  }
  result.stationary_marked_edge_law = std::move(merged_edges).value();
  Rational edge_mass = Rational::zero();
  for (const auto& atom : result.stationary_marked_edge_law) {
    edge_mass = edge_mass + atom.mass;
  }
  if (edge_mass != Rational::one()) {
    return Result<ExactResidenceDerivation>::failure(make_error(
        "oracle_mass_not_conserved",
        "the stationary marked-edge image does not have mass one"));
  }
  result.stationary_status = ResidenceStationaryStatus::established;
  return Result<ExactResidenceDerivation>::success(std::move(result));
}

[[nodiscard]] OracleError budget_error(const std::string& detail,
                                       const std::size_t states,
                                       const std::size_t branches) {
  return make_error("oracle_budget_exhausted", detail, states, branches);
}

}  // namespace

Result<FiniteCoupledInitialLaw> FiniteCoupledInitialLaw::create(
    std::vector<InitialAtom> atoms) {
  if (atoms.empty()) {
    return Result<FiniteCoupledInitialLaw>::failure(make_error(
        "oracle_initial_law_empty", "the coupled initial law is empty"));
  }

  const std::size_t dimension = atoms.front().state.queue.size();
  const std::size_t controller_width =
      atoms.front().state.controller_memory.size();
  if (dimension == 0U) {
    return Result<FiniteCoupledInitialLaw>::failure(make_error(
        "oracle_initial_state_invalid",
        "initial atoms must contain at least one queue"));
  }

  Rational input_mass = Rational::zero();
  for (const auto& atom : atoms) {
    if (!atom.mass.is_positive()) {
      return Result<FiniteCoupledInitialLaw>::failure(make_error(
          "oracle_initial_mass_nonpositive",
          "initial atoms must have strictly positive rational mass"));
    }
    if (atom.state.queue.size() != dimension ||
        !nonnegative_backlog(atom.state.queue) ||
        atom.state.controller_memory.size() != controller_width) {
      return Result<FiniteCoupledInitialLaw>::failure(make_error(
          "oracle_initial_state_invalid",
          "initial atoms must share one complete state schema and nonnegative "
          "queue dimension"));
    }
    input_mass = input_mass + atom.mass;
  }
  if (input_mass != Rational::one()) {
    return Result<FiniteCoupledInitialLaw>::failure(make_error(
        "oracle_mass_not_one",
        "the coupled initial masses must sum exactly to one"));
  }

  std::sort(atoms.begin(), atoms.end(),
            [](const InitialAtom& lhs, const InitialAtom& rhs) {
              return compare_initial_atom_key(lhs, rhs) < 0;
            });
  std::vector<InitialAtom> merged;
  merged.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!merged.empty() &&
        compare_initial_atom_key(merged.back(), atom) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  if (total_initial_mass(merged) != input_mass) {
    return Result<FiniteCoupledInitialLaw>::failure(make_error(
        "oracle_mass_not_conserved",
        "coalescing the coupled initial law changed its exact mass"));
  }
  return Result<FiniteCoupledInitialLaw>::success(
      FiniteCoupledInitialLaw(std::move(merged)));
}

Result<ExactPathFrontier> oracle_merge_equal_states(
    ExactPathFrontier frontier) {
  if (frontier.atoms.empty()) {
    return Result<ExactPathFrontier>::failure(make_error(
        "oracle_frontier_empty", "an exact path frontier cannot be empty",
        frontier.states_examined, frontier.branches_examined));
  }

  const std::size_t dimension = frontier.atoms.front().state.queue.size();
  const std::size_t controller_width =
      frontier.atoms.front().state.controller_memory.size();
  Rational input_mass = Rational::zero();
  for (const auto& atom : frontier.atoms) {
    if (!atom.mass.is_positive()) {
      return Result<ExactPathFrontier>::failure(make_error(
          "oracle_frontier_mass_nonpositive",
          "path-frontier atoms must have strictly positive mass",
          frontier.states_examined, frontier.branches_examined));
    }
    if (dimension == 0U || atom.state.queue.size() != dimension ||
        !nonnegative_backlog(atom.state.queue) ||
        atom.state.controller_memory.size() != controller_width) {
      return Result<ExactPathFrontier>::failure(make_error(
          "oracle_frontier_state_invalid",
          "path-frontier atoms do not share one valid full-state schema",
          frontier.states_examined, frontier.branches_examined));
    }
    input_mass = input_mass + atom.mass;
  }
  if (input_mass != Rational::one()) {
    return Result<ExactPathFrontier>::failure(make_error(
        "oracle_mass_not_one",
        "an exact path frontier must have total mass one",
        frontier.states_examined, frontier.branches_examined));
  }

  std::sort(frontier.atoms.begin(), frontier.atoms.end(),
            [](const PathAtom& lhs, const PathAtom& rhs) {
              return compare_path_atom_key(lhs, rhs) < 0;
            });
  std::vector<PathAtom> merged;
  merged.reserve(frontier.atoms.size());
  for (auto& atom : frontier.atoms) {
    if (!merged.empty() && compare_path_atom_key(merged.back(), atom) == 0) {
      merged.back().mass = merged.back().mass + atom.mass;
    } else {
      merged.push_back(std::move(atom));
    }
  }
  if (total_path_mass(merged) != input_mass) {
    return Result<ExactPathFrontier>::failure(make_error(
        "oracle_mass_not_conserved",
        "frontier coalescing changed the exact path mass",
        frontier.states_examined, frontier.branches_examined));
  }
  frontier.atoms = std::move(merged);
  return Result<ExactPathFrontier>::success(std::move(frontier));
}

Result<ExactPathLaw> oracle_enumerate_finite_paths(
    const SmallPhysicalModel& model, const FiniteCoupledInitialLaw& initial,
    const std::size_t horizon) {
  auto validated = validate_model(model, initial, horizon);
  if (!validated) {
    return Result<ExactPathLaw>::failure(validated.error());
  }
  auto shape = std::move(validated).value();

  ExactPathFrontier current;
  current.atoms.reserve(initial.atoms().size());
  for (const auto& atom : initial.atoms()) {
    current.atoms.push_back(PathAtom{atom.state, PathHistory{}, atom.mass});
  }
  auto merged_initial = oracle_merge_equal_states(std::move(current));
  if (!merged_initial) {
    return Result<ExactPathLaw>::failure(merged_initial.error());
  }
  current = std::move(merged_initial).value();

  ExactPathLaw law;
  law.horizon = horizon;
  law.frontiers.reserve(horizon + 1U);
  law.frontiers.push_back(current);

  std::size_t states_examined = 0U;
  std::size_t branches_examined = 0U;
  for (std::size_t slot = 0U; slot < horizon; ++slot) {
    ExactPathFrontier expanded;
    for (const auto& path_atom : current.atoms) {
      if (states_examined >= model.limits.maximum_states) {
        return Result<ExactPathLaw>::failure(budget_error(
            "the exact path expansion exhausted its state budget",
            states_examined, branches_examined));
      }
      ++states_examined;

      const TieRow* const tie_row =
          find_tie_row(model.tie_rows,
                       path_atom.state.controller_memory);
      if (tie_row == nullptr) {
        return Result<ExactPathLaw>::failure(make_error(
            "oracle_missing_tie_row",
            "a reachable controller state has no configured tie row",
            states_examined, branches_examined));
      }
      if (path_atom.state.arrival_phase >= shape.arrival_rows.size()) {
        return Result<ExactPathLaw>::failure(make_error(
            "oracle_arrival_phase_invalid",
            "a reachable state has no configured arrival row",
            states_examined, branches_examined));
      }
      const ArrivalRow& arrival_row =
          shape.arrival_rows[path_atom.state.arrival_phase];

      EligibilityMask eligibility(shape.dimension, std::uint8_t{0});
      for (std::size_t coordinate = 0U; coordinate < shape.dimension;
           ++coordinate) {
        eligibility[coordinate] =
            path_atom.state.queue[coordinate] > 0 ? std::uint8_t{1}
                                                   : std::uint8_t{0};
      }

      for (const auto& tie_branch : tie_row->branches) {
        auto face = oracle_enumerate_schedule_face(
            model.constraint, path_atom.state.queue, eligibility,
            tie_branch.priority, model.limits);
        if (!face) {
          OracleError error = face.error();
          error.states_examined = states_examined;
          error.branches_examined = branches_examined;
          return Result<ExactPathLaw>::failure(std::move(error));
        }
        const Schedule schedule = face.value().priority_choice;
        if (schedule.size() != shape.dimension ||
            std::any_of(schedule.begin(), schedule.end(),
                        [](const std::uint8_t bit) { return bit > 1U; })) {
          return Result<ExactPathLaw>::failure(make_error(
              "oracle_schedule_artifact_invalid",
              "the schedule oracle returned a malformed binary choice",
              states_examined, branches_examined));
        }
        Schedule departures(shape.dimension, std::uint8_t{0});
        for (std::size_t coordinate = 0U; coordinate < shape.dimension;
             ++coordinate) {
          departures[coordinate] =
              schedule[coordinate] != 0U &&
                      path_atom.state.queue[coordinate] > 0
                  ? std::uint8_t{1}
                  : std::uint8_t{0};
        }

        for (const auto& arrival_atom : arrival_row.atoms) {
          if (branches_examined >= model.limits.maximum_branches) {
            return Result<ExactPathLaw>::failure(budget_error(
                "the exact path expansion exhausted its branch budget",
                states_examined, branches_examined));
          }
          ++branches_examined;

          FullState successor;
          successor.queue.resize(shape.dimension);
          for (std::size_t coordinate = 0U; coordinate < shape.dimension;
               ++coordinate) {
            successor.queue[coordinate] =
                path_atom.state.queue[coordinate] -
                BigInt{departures[coordinate]} +
                arrival_atom.arrivals[coordinate];
          }
          successor.arrival_phase = arrival_atom.next_phase;
          successor.controller_memory =
              arrival_atom.controller_after_arrival.value_or(
                  tie_branch.controller_after_decision);

          SlotRecord record;
          record.predecision = path_atom.state;
          record.schedule = schedule;
          record.departures = departures;
          record.arrivals = arrival_atom.arrivals;
          record.joint_marks = arrival_atom.joint_marks;
          record.postarrival = successor;
          record.tie_branch_identity = tie_branch.branch_identity;
          record.decision_slot = slot;
          record.admission_boundary = slot + 1U;
          record.timing = SlotTiming::early_service_late_admission;

          PathHistory successor_history = path_atom.history;
          successor_history.slots.push_back(std::move(record));
          const Rational successor_mass =
              path_atom.mass * tie_branch.mass * arrival_atom.mass;
          expanded.atoms.push_back(PathAtom{
              std::move(successor), std::move(successor_history),
              successor_mass});
        }
      }
    }

    expanded.states_examined = states_examined;
    expanded.branches_examined = branches_examined;
    auto merged = oracle_merge_equal_states(std::move(expanded));
    if (!merged) {
      return Result<ExactPathLaw>::failure(merged.error());
    }
    if (merged.value().atoms.size() > model.limits.maximum_states) {
      return Result<ExactPathLaw>::failure(budget_error(
          "the merged path frontier exceeds the state budget",
          states_examined, branches_examined));
    }
    current = std::move(merged).value();
    law.frontiers.push_back(current);
  }

  auto residence_paths = make_residence_paths(current, model.residence_rule);
  if (!residence_paths) {
    OracleError error = residence_paths.error();
    error.states_examined = states_examined;
    error.branches_examined = branches_examined;
    return Result<ExactPathLaw>::failure(std::move(error));
  }
  law.residence_paths = std::move(residence_paths).value();
  auto residence = derive_residence_laws(law.residence_paths);
  if (!residence) {
    OracleError error = residence.error();
    error.states_examined = states_examined;
    error.branches_examined = branches_examined;
    return Result<ExactPathLaw>::failure(std::move(error));
  }
  law.residence = std::move(residence).value();
  law.states_examined = states_examined;
  law.branches_examined = branches_examined;
  return Result<ExactPathLaw>::success(std::move(law));
}

Result<ResidenceRewardRatio> oracle_residence_mark_reward_ratio(
    const ExactResidenceDerivation& residence,
    const std::string_view mark_identity) {
  if (mark_identity.empty()) {
    return Result<ResidenceRewardRatio>::failure(make_error(
        "oracle_mark_id_empty",
        "a residence reward needs a nonempty exact mark identity"));
  }
  if (residence.event_word_law.empty() ||
      !residence.mean_word_length.has_value()) {
    return Result<ResidenceRewardRatio>::failure(make_error(
        "oracle_residence_no_complete_word",
        "a renewal-reward ratio needs a nonempty complete residence law"));
  }

  Rational law_mass = Rational::zero();
  Rational expected_reward = Rational::zero();
  for (const ResidenceWordLawAtom& atom : residence.event_word_law) {
    law_mass = law_mass + atom.mass;
    BigInt word_reward = 0;
    for (const SlotRecord& slot : atom.word.slots) {
      bool found = false;
      for (const ExactJointMark& mark : slot.joint_marks) {
        if (mark.id != mark_identity) {
          continue;
        }
        if (found) {
          return Result<ResidenceRewardRatio>::failure(make_error(
              "oracle_mark_id_duplicate",
              "one completed slot contains the requested reward mark more "
              "than once"));
        }
        found = true;
        word_reward += mark.value;
      }
    }
    expected_reward =
        expected_reward + atom.mass * Rational(std::move(word_reward));
  }
  if (law_mass != Rational::one() ||
      !residence.mean_word_length->is_positive()) {
    return Result<ResidenceRewardRatio>::failure(make_error(
        "oracle_residence_law_invalid",
        "the complete event law or its mean length is not normalized"));
  }
  auto reward_ratio =
      checked_divide(expected_reward, *residence.mean_word_length);
  if (!reward_ratio) {
    return Result<ResidenceRewardRatio>::failure(reward_ratio.error());
  }
  return Result<ResidenceRewardRatio>::success(ResidenceRewardRatio{
      expected_reward, *residence.mean_word_length,
      std::move(reward_ratio).value(),
      residence.stationary_status == ResidenceStationaryStatus::established});
}

}  // namespace mwperf_oracle
