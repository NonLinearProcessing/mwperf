#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <numeric>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/reduction/opportunity.hpp"
#include "mwperf_oracle/full_state_oracle.hpp"

namespace {

enum class FamilyFixture : std::uint8_t {
  crossbar,
  interval,
  node_exclusive,
  conflict,
  packing,
};

struct ProductionFamilyCase final {
  FamilyFixture fixture;
  mwperf::ServiceFamily family;
  mwperf::OptimizerId backend;
  std::string_view name;
};

[[nodiscard]] constexpr std::array<ProductionFamilyCase, 5U>
production_cases() {
  return {{{FamilyFixture::crossbar,
            mwperf::ServiceFamily::crossbar_matching,
            mwperf::OptimizerId::hungarian_exact, "crossbar"},
           {FamilyFixture::interval,
            mwperf::ServiceFamily::nonoverlapping_intervals,
            mwperf::OptimizerId::weighted_interval_dp_exact, "interval"},
           {FamilyFixture::node_exclusive,
            mwperf::ServiceFamily::node_exclusive_matching,
            mwperf::OptimizerId::edmonds_blossom_exact,
            "node-exclusive"},
           {FamilyFixture::conflict,
            mwperf::ServiceFamily::pairwise_conflicts,
            mwperf::OptimizerId::mwis_branch_memo_exact, "conflict"},
           {FamilyFixture::packing,
            mwperf::ServiceFamily::resource_packing,
            mwperf::OptimizerId::binary_packing_memo_exact, "packing"}}};
}

[[nodiscard]] std::filesystem::path write_input(const std::string_view stem,
                                                const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
      "c26-schedule-production-grounding";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory /
      (std::string(stem) + '-' + std::to_string(next.fetch_add(1U)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string priority_json(
    const mwperf_oracle::PriorityOrder& priority) {
  std::string result{"["};
  for (std::size_t rank = 0U; rank < priority.size(); ++rank) {
    if (rank != 0U) {
      result.push_back(',');
    }
    result += "\"q" + std::to_string(priority[rank]) + "\"";
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string scheduler_json(
    const FamilyFixture fixture,
    const mwperf_oracle::PriorityOrder& priority,
    const std::optional<std::uint64_t> conflict_edge_mask = std::nullopt,
    const std::optional<std::uint64_t> search_budget = std::nullopt) {
  const std::string authored_priority = priority_json(priority);
  const std::size_t dimension = priority.size();
  std::ostringstream constraint;
  switch (fixture) {
    case FamilyFixture::crossbar: {
      constraint << R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i"],"outputs":[)json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        if (queue != 0U) {
          constraint << ',';
        }
        constraint << "\"o" << queue << "\"";
      }
      constraint << R"json(],"edges":[)json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        if (queue != 0U) {
          constraint << ',';
        }
        constraint << "{\"queue_id\":\"q" << queue
                   << "\",\"input\":\"i\",\"output\":\"o" << queue
                   << "\"}";
      }
      constraint << "]},\"priority\":" << authored_priority << "}}";
      return constraint.str();
    }
    case FamilyFixture::interval: {
      constraint << R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[)json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        if (queue != 0U) {
          constraint << ',';
        }
        // All intervals overlap, giving the same single-server feasible set
        // as the other four family fixtures.
        constraint << "{\"queue_id\":\"q" << queue
                   << "\",\"left\":0,\"right\":2}";
      }
      constraint << "]},\"priority\":" << authored_priority << "}}";
      return constraint.str();
    }
    case FamilyFixture::node_exclusive: {
      constraint << R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["hub")json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        constraint << ",\"v" << queue << "\"";
      }
      constraint << R"json(],"links":[)json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        if (queue != 0U) {
          constraint << ',';
        }
        constraint << "{\"queue_id\":\"q" << queue
                   << "\",\"u\":\"hub\",\"v\":\"v" << queue
                   << "\"}";
      }
      constraint << "]},\"priority\":" << authored_priority << "}}";
      return constraint.str();
    }
    case FamilyFixture::conflict: {
      constraint << R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[)json";
      std::size_t edge_index = 0U;
      bool first_edge = true;
      for (std::size_t first = 0U; first < dimension; ++first) {
        for (std::size_t second = first + 1U; second < dimension;
             ++second, ++edge_index) {
          const bool included = conflict_edge_mask.has_value()
                                    ? ((*conflict_edge_mask >> edge_index) &
                                       std::uint64_t{1U}) != 0U
                                    : true;
          if (!included) {
            continue;
          }
          if (!first_edge) {
            constraint << ',';
          }
          first_edge = false;
          constraint << "[\"q" << first << "\",\"q" << second << "\"]";
        }
      }
      constraint << "]},\"priority\":" << authored_priority
                 << ",\"max_search_states\":";
      if (search_budget.has_value()) {
        constraint << *search_budget;
      } else {
        constraint << "null";
      }
      constraint << "}}";
      return constraint.str();
    }
    case FamilyFixture::packing: {
      constraint << R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[1],"demands":[)json";
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        if (queue != 0U) {
          constraint << ',';
        }
        constraint << "{\"queue_id\":\"q" << queue
                   << "\",\"demand\":[1]}";
      }
      constraint << "]},\"priority\":" << authored_priority
                 << ",\"max_search_states\":";
      if (search_budget.has_value()) {
        constraint << *search_budget;
      } else {
        constraint << "null";
      }
      constraint << "}}";
      return constraint.str();
    }
  }
  return {};
}

[[nodiscard]] mwperf_oracle::SmallConstraint oracle_constraint(
    const FamilyFixture fixture, const std::size_t dimension = 2U,
    const std::optional<std::uint64_t> conflict_edge_mask = std::nullopt) {
  switch (fixture) {
    case FamilyFixture::crossbar: {
      mwperf_oracle::CrossbarConstraint result;
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        result.edges.push_back({0U, queue});
      }
      return result;
    }
    case FamilyFixture::interval: {
      auto zero = mwperf_oracle::Rational::make(0, 1);
      auto two = mwperf_oracle::Rational::make(2, 1);
      REQUIRE(zero);
      REQUIRE(two);
      mwperf_oracle::IntervalConstraint result;
      result.intervals.assign(
          dimension, mwperf_oracle::HalfOpenInterval{zero.value(),
                                                      two.value()});
      return result;
    }
    case FamilyFixture::node_exclusive: {
      mwperf_oracle::NodeExclusiveConstraint result;
      for (std::size_t queue = 0U; queue < dimension; ++queue) {
        result.links.push_back({0U, queue + 1U});
      }
      return result;
    }
    case FamilyFixture::conflict: {
      mwperf_oracle::ConflictConstraint result;
      result.adjacency.assign(
          dimension, std::vector<std::uint8_t>(dimension, 0U));
      std::size_t edge_index = 0U;
      for (std::size_t first = 0U; first < dimension; ++first) {
        for (std::size_t second = first + 1U; second < dimension;
             ++second, ++edge_index) {
          const bool included = conflict_edge_mask.has_value()
                                    ? ((*conflict_edge_mask >> edge_index) &
                                       std::uint64_t{1U}) != 0U
                                    : true;
          if (included) {
            result.adjacency[first][second] = 1U;
            result.adjacency[second][first] = 1U;
          }
        }
      }
      return result;
    }
    case FamilyFixture::packing: {
      mwperf_oracle::PackingConstraint result;
      result.demands.assign(
          dimension, std::vector<mwperf_oracle::BigInt>{
                         mwperf_oracle::BigInt{1}});
      result.capacity = {mwperf_oracle::BigInt{1}};
      return result;
    }
  }
  return mwperf_oracle::ConflictConstraint{};
}

[[nodiscard]] std::string model_text(const std::string& scheduler,
                                     const std::size_t dimension) {
  std::ostringstream queues;
  queues << '[';
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    if (queue != 0U) {
      queues << ',';
    }
    queues << "{\"id\":\"q" << queue << "\"}";
  }
  queues << ']';
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":26,"slots":2,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":)json") + queues.str() + R"json(},
    "scheduler":)json" +
         scheduler + R"json(,
    "arrival":{"family":"deterministic_trace","events":[],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] std::string analysis_text(const std::size_t dimension) {
  std::ostringstream initial_backlog;
  initial_backlog << '[';
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    if (queue != 0U) {
      initial_backlog << ',';
    }
    initial_backlog << "{\"queue_id\":\"q" << queue
                    << "\",\"value\":0}";
  }
  initial_backlog << ']';
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"law","kind":"transient_backlog_law",
                "parameters":{"horizons":[0,1]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":16,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{
      "atoms":[{"probability":1,
        "backlog":)json") + initial_backlog.str() + R"json(,
        "controller_state":{},"arrival_state":{"kind":"trace_origin"},
        "static_context":{},"surrogate_initial":{}}]}}},
    "solver":{"kind":"enumerated",
              "parameters":{"linear_method":"dense_pivoted",
                            "max_iterations":null}}
  })json";
}

[[nodiscard]] mwperf::ResolvedInstance resolve_instance(
    const FamilyFixture fixture,
    const mwperf_oracle::PriorityOrder& priority,
    const std::optional<std::uint64_t> conflict_edge_mask = std::nullopt,
    const std::optional<std::uint64_t> search_budget = std::nullopt) {
  const std::size_t dimension = priority.size();
  auto model_document = mwperf::load_document(
      write_input("model", model_text(scheduler_json(
                                          fixture, priority,
                                          conflict_edge_mask, search_budget),
                                      dimension)));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document =
      mwperf::load_document(
          write_input("analysis", analysis_text(dimension)));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " +
                       analysis.error().message));
  REQUIRE(analysis);

  const mwperf::CanonicalInputPair canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const mwperf::InputFingerprintBundle fingerprints =
      mwperf::fingerprint_inputs(canonical);
  auto instance = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((instance ? std::string{}
                 : instance.error().code + ": " +
                       instance.error().message));
  REQUIRE(instance);
  return std::move(instance).value();
}

[[nodiscard]] mwperf::Backlog production_backlog(
    const mwperf::ResolvedInstance& instance,
    const std::vector<std::uint64_t>& values) {
  std::vector<mwperf::BigNat> exact;
  exact.reserve(values.size());
  for (const std::uint64_t value : values) {
    exact.emplace_back(value);
  }
  auto result = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(instance), exact);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Backlog production_backlog(
    const mwperf::ResolvedInstance& instance, const std::uint64_t first,
    const std::uint64_t second) {
  return production_backlog(instance, {first, second});
}

[[nodiscard]] mwperf::OptimizerExecutionContext execution_context(
    const mwperf::ResolvedInstance& instance) {
  auto result =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TargetIndex target_zero(
    const mwperf::ResolvedInstance& instance) {
  auto result = mwperf::TargetIndex::from_instance(instance, 0U);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<std::uint8_t> schedule_bytes(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::string bit_vector(
    const std::vector<std::uint8_t>& bits) {
  std::string result;
  result.reserve(bits.size());
  for (const std::uint8_t bit : bits) {
    result.push_back(bit == 0U ? '0' : '1');
  }
  return result;
}

[[nodiscard]] std::string comparison_product_identity(
    const std::string_view kind, const ProductionFamilyCase& family_case,
    const std::uint64_t first, const std::uint64_t second,
    const mwperf_oracle::PriorityOrder& priority) {
  return "c26.fixture." + std::string(kind) + '.' +
         std::string(family_case.name) + ".q=" + std::to_string(first) + ',' +
         std::to_string(second) + ".priority=" + priority_json(priority);
}

[[nodiscard]] std::string comparison_product_identity(
    const std::string_view kind, const std::string_view family,
    const std::vector<std::uint64_t>& backlog,
    const mwperf_oracle::PriorityOrder& priority,
    const std::optional<std::uint64_t> graph = std::nullopt) {
  std::string result = "c26.fixture." + std::string(kind) + '.' +
                       std::string(family) + ".q=";
  for (std::size_t queue = 0U; queue < backlog.size(); ++queue) {
    if (queue != 0U) {
      result.push_back(',');
    }
    result += std::to_string(backlog[queue]);
  }
  result += ".priority=" + priority_json(priority);
  if (graph.has_value()) {
    result += ".graph=" + std::to_string(*graph);
  }
  return result;
}

[[nodiscard]] std::size_t power(const std::size_t base,
                                const std::size_t exponent) {
  std::size_t result = 1U;
  for (std::size_t index = 0U; index < exponent; ++index) {
    result *= base;
  }
  return result;
}

[[nodiscard]] std::vector<std::uint64_t> backlog_from_index(
    const std::size_t dimension, std::size_t index) {
  std::vector<std::uint64_t> result(dimension, 0U);
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    result[queue] = static_cast<std::uint64_t>(index % 4U);
    index /= 4U;
  }
  return result;
}

[[nodiscard]] mwperf_oracle::Backlog oracle_backlog(
    const std::vector<std::uint64_t>& values) {
  mwperf_oracle::Backlog result;
  result.reserve(values.size());
  for (const std::uint64_t value : values) {
    result.emplace_back(value);
  }
  return result;
}

[[nodiscard]] mwperf_oracle::EligibilityMask caller_eligibility(
    const std::size_t dimension) {
  // Deliberately pass a permissive caller mask. The independent oracle must
  // still suppress empty queues through its physical backlog eligibility.
  return mwperf_oracle::EligibilityMask(dimension, 1U);
}

[[nodiscard]] std::size_t simple_graph_edge_count(
    const std::size_t dimension) {
  return dimension * (dimension - 1U) / 2U;
}

void require_exact_discrete_conformance(
    mwperf_oracle::ArtifactDomain domain,
    const std::string& projection_identity,
    const std::string& product_identity,
    std::vector<std::string> expected_coordinates,
    std::vector<std::string> actual_coordinates);

void compare_schedule_result(
    const mwperf_oracle::ExactScheduleFace& oracle,
    const mwperf::ScheduleDecision& production,
    const mwperf_oracle::PriorityOrder& priority,
    const std::string& product_identity) {
  const std::vector<std::uint8_t> actual =
      schedule_bytes(production.schedule);
  require_exact_discrete_conformance(
      mwperf_oracle::ArtifactDomain::schedule,
      "physical-maxweight-primary-face-priority-choice-v1", product_identity,
      {"primary=" + oracle.primary_objective.str(),
       "choice=" + bit_vector(oracle.priority_choice),
       "composite=" +
           mwperf_oracle::oracle_composite_score_identity(
               oracle.primary_objective, oracle.priority_choice, priority)
               .str()},
      {"primary=" + production.primary_objective.to_decimal_string(),
       "choice=" + bit_vector(actual),
       "composite=" + production.composite_objective.to_decimal_string()});
}

void require_capability_rejection_conformance(
    const std::string& product_identity,
    const std::string& oracle_reason,
    const std::string& production_reason) {
  mwperf_oracle::OracleArtifact expected;
  expected.domain = mwperf_oracle::ArtifactDomain::capability;
  expected.scope = mwperf_oracle::ScientificScope::physical_model;
  expected.projection_identity = "exact-schedule-budget-capability-v1";
  expected.product_identity = product_identity;
  expected.payload = mwperf_oracle::CapabilityArtifact{oracle_reason};

  mwperf_oracle::ProductionArtifact actual;
  actual.domain = mwperf_oracle::ArtifactDomain::capability;
  actual.scope = mwperf_oracle::ScientificScope::physical_model;
  actual.projection_identity = expected.projection_identity;
  actual.product_identity = product_identity;
  actual.payload = mwperf_oracle::CapabilityArtifact{production_reason};

  mwperf_oracle::ComparisonContract contract;
  contract.arithmetic = mwperf_oracle::ArithmeticMode::capability_rejection;
  contract.domain = mwperf_oracle::ArtifactDomain::capability;
  contract.scope = mwperf_oracle::ScientificScope::physical_model;
  contract.projection_identity = expected.projection_identity;
  const auto report =
      mwperf_oracle::oracle_compare_production(expected, actual, contract);
  INFO(report.code << ": " << report.message);
  REQUIRE(report.conformant);
  REQUIRE_FALSE(report.physical_fidelity_inferred);
}

void require_exact_discrete_conformance(
    const mwperf_oracle::ArtifactDomain domain,
    const std::string& projection_identity,
    const std::string& product_identity,
    std::vector<std::string> expected_coordinates,
    std::vector<std::string> actual_coordinates) {
  mwperf_oracle::OracleArtifact expected;
  expected.domain = domain;
  expected.scope = mwperf_oracle::ScientificScope::physical_model;
  expected.projection_identity = projection_identity;
  expected.product_identity = product_identity;
  expected.payload = mwperf_oracle::ExactDiscreteArtifact{
      std::move(expected_coordinates)};

  mwperf_oracle::ProductionArtifact actual;
  actual.domain = domain;
  actual.scope = mwperf_oracle::ScientificScope::physical_model;
  actual.projection_identity = projection_identity;
  actual.product_identity = product_identity;
  actual.payload = mwperf_oracle::ExactDiscreteArtifact{
      std::move(actual_coordinates)};

  mwperf_oracle::ComparisonContract contract;
  contract.arithmetic = mwperf_oracle::ArithmeticMode::exact_discrete;
  contract.domain = domain;
  contract.scope = mwperf_oracle::ScientificScope::physical_model;
  contract.projection_identity = projection_identity;

  const auto report =
      mwperf_oracle::oracle_compare_production(expected, actual, contract);
  INFO(report.code << ": " << report.message);
  REQUIRE(report.conformant);
  REQUIRE_FALSE(report.physical_fidelity_inferred);
}

}  // namespace

TEST_CASE("C26 independent schedules ground all production optimizer families",
          "[c26][integration][schedule][production]") {
  // For each preferred optimizer family, exhaust every queue dimension up to
  // four, backlog in {0,1,2,3}^d, and configured priority permutation. The
  // five constraints all represent the same single-server conflict geometry,
  // so this also checks that family-specific implementations agree on one
  // common physical face without the oracle importing any production solver.
  for (std::size_t dimension = 1U; dimension <= 4U; ++dimension) {
    mwperf_oracle::PriorityOrder priority(dimension, 0U);
    std::iota(priority.begin(), priority.end(), 0U);
    do {
      for (const ProductionFamilyCase& family_case : production_cases()) {
        INFO("family=" << family_case.name);
        INFO("dimension=" << dimension);
        INFO("priority=" << priority_json(priority));
        const mwperf::ResolvedInstance instance =
            resolve_instance(family_case.fixture, priority);
        REQUIRE(instance.constraint().family() == family_case.family);
        REQUIRE(instance.constraint().identity().optimizer ==
                family_case.backend);
        const mwperf_oracle::SmallConstraint constraint =
            oracle_constraint(family_case.fixture, dimension);

        const std::size_t backlog_count = power(4U, dimension);
        for (std::size_t backlog_index = 0U;
             backlog_index < backlog_count; ++backlog_index) {
          const std::vector<std::uint64_t> backlog =
              backlog_from_index(dimension, backlog_index);
          INFO("backlog-index=" << backlog_index);
          auto oracle = mwperf_oracle::oracle_enumerate_schedule_face(
              constraint, oracle_backlog(backlog),
              caller_eligibility(dimension), priority);
          INFO((oracle ? std::string{}
                       : oracle.error().code + ": " +
                             oracle.error().message));
          REQUIRE(oracle);

          auto context = execution_context(instance);
          auto production = mwperf::resolve_maxweight_schedule(
              instance, production_backlog(instance, backlog),
              mwperf::TieContext::configured_priority(), context);
          INFO((production ? std::string{}
                           : production.error().code + ": " +
                                 production.error().message));
          REQUIRE(production);
          REQUIRE(production.value().family == family_case.family);
          REQUIRE(production.value().backend_id == family_case.backend);

          compare_schedule_result(
              oracle.value(), production.value(), priority,
              comparison_product_identity(
                  "configured-priority-face", family_case.name, backlog,
                  priority));
        }
      }
    } while (std::next_permutation(priority.begin(), priority.end()));
  }
}

TEST_CASE("C26 every simple conflict graph through dimension four is grounded",
          "[c26][property][schedule][production][conflict-graphs]") {
  for (std::size_t dimension = 1U; dimension <= 4U; ++dimension) {
    const std::size_t graph_count =
        std::size_t{1U} << simple_graph_edge_count(dimension);
    for (std::size_t graph = 0U; graph < graph_count; ++graph) {
      mwperf_oracle::PriorityOrder priority(dimension, 0U);
      std::iota(priority.begin(), priority.end(), 0U);
      do {
        INFO("dimension=" << dimension);
        INFO("graph=" << graph);
        INFO("priority=" << priority_json(priority));
        const mwperf::ResolvedInstance instance = resolve_instance(
            FamilyFixture::conflict, priority,
            static_cast<std::uint64_t>(graph));
        const mwperf_oracle::SmallConstraint constraint = oracle_constraint(
            FamilyFixture::conflict, dimension,
            static_cast<std::uint64_t>(graph));
        const std::size_t backlog_count = power(4U, dimension);
        for (std::size_t backlog_index = 0U;
             backlog_index < backlog_count; ++backlog_index) {
          INFO("backlog-index=" << backlog_index);
          const std::vector<std::uint64_t> backlog =
              backlog_from_index(dimension, backlog_index);
          auto oracle = mwperf_oracle::oracle_enumerate_schedule_face(
              constraint, oracle_backlog(backlog),
              caller_eligibility(dimension), priority);
          REQUIRE(oracle);
          auto context = execution_context(instance);
          auto production = mwperf::resolve_maxweight_schedule(
              instance, production_backlog(instance, backlog),
              mwperf::TieContext::configured_priority(), context);
          INFO((production ? std::string{}
                           : production.error().code + ": " +
                                 production.error().message));
          REQUIRE(production);
          compare_schedule_result(
              oracle.value(), production.value(), priority,
              comparison_product_identity(
                  "simple-conflict-graph-face", "conflict", backlog,
                  priority, static_cast<std::uint64_t>(graph)));
        }
      } while (std::next_permutation(priority.begin(), priority.end()));
    }
  }
}

TEST_CASE("C26 structural opportunities ground all production families",
          "[c26][integration][schedule][opportunity][production]") {
  const mwperf_oracle::PriorityOrder priority{1U, 0U};
  for (const ProductionFamilyCase& family_case : production_cases()) {
    const mwperf::ResolvedInstance instance =
        resolve_instance(family_case.fixture, priority);
    const mwperf_oracle::SmallConstraint constraint =
        oracle_constraint(family_case.fixture);
    INFO(family_case.name);

    for (std::uint64_t first = 0U; first <= 3U; ++first) {
      for (std::uint64_t second = 0U; second <= 3U; ++second) {
        INFO("backlog=(" << first << ',' << second << ')');
        const mwperf_oracle::Backlog oracle_queue{
            mwperf_oracle::BigInt{first}, mwperf_oracle::BigInt{second}};
        const mwperf_oracle::EligibilityMask eligibility{
            static_cast<std::uint8_t>(first > 0U),
            static_cast<std::uint8_t>(second > 0U)};
        auto oracle = mwperf_oracle::oracle_enumerate_schedule_face(
            constraint, oracle_queue, eligibility, priority);
        REQUIRE(oracle);
        REQUIRE(oracle.value().opportunities.size() == 2U);
        const mwperf_oracle::ForcedOpportunity& expected =
            oracle.value().opportunities.front();
        REQUIRE(expected.forced_zero_feasible);
        REQUIRE(expected.forced_one_feasible);
        REQUIRE(expected.psi_zero.has_value());
        REQUIRE(expected.psi_one.has_value());
        REQUIRE(expected.theta.has_value());
        REQUIRE(expected.margin.has_value());

        auto context = execution_context(instance);
        auto production = mwperf::compute_target_opportunity(
            instance, production_backlog(instance, first, second),
            target_zero(instance), context);
        INFO((production ? std::string{}
                         : production.error().code + ": " +
                               production.error().message));
        REQUIRE(production);
        REQUIRE(production.value().psi0().value() == *expected.psi_zero);
        REQUIRE(production.value().psi1().value() == *expected.psi_one);
        REQUIRE(production.value().theta().value() == *expected.theta);
        REQUIRE(production.value().margin() == *expected.margin);
        REQUIRE(production.value().cross_class_outcome().target_eligible ==
                (first > 0U));
        // The target is structurally serviceable even when its physical queue
        // is empty.  The forced-in face therefore remains an algebraic face;
        // only the physical eligibility bit changes at the boundary.
        if (first == 0U) {
          REQUIRE(production.value().forced_in_certificate().side ==
                  mwperf::ForcedTargetBit::one);
          REQUIRE(production.value().forced_in_certificate().witness
                      .bytes()[0U] == 1U);
        }

        const std::string product_identity = comparison_product_identity(
            "target-zero-opportunity", family_case, first, second, priority);
        require_exact_discrete_conformance(
            mwperf_oracle::ArtifactDomain::opportunity,
            "structural-target-opportunity-values-v1", product_identity,
            {"target=0", "forced-zero-feasible=1",
             "forced-one-feasible=1", "psi0=" + expected.psi_zero->str(),
             "psi1=" + expected.psi_one->str(),
             "theta=" + expected.theta->str(),
             "margin=" + expected.margin->str(),
             std::string("target-eligible=") +
                 (first > 0U ? "1" : "0")},
            {"target=0", "forced-zero-feasible=1",
             "forced-one-feasible=1",
             "psi0=" + production.value().psi0().to_decimal_string(),
             "psi1=" + production.value().psi1().to_decimal_string(),
             "theta=" + production.value().theta().to_decimal_string(),
             "margin=" + production.value().margin().str(),
             std::string("target-eligible=") +
                 (production.value().cross_class_outcome().target_eligible
                      ? "1"
                      : "0")});
      }
    }
  }
}

TEST_CASE("C26 caller masks may prune a positive queue but never enable an empty one",
          "[c26][unit][schedule][eligibility]") {
  const mwperf_oracle::SmallConstraint constraint =
      mwperf_oracle::ConflictConstraint{
          .adjacency = {{0U, 1U}, {1U, 0U}},
      };
  auto pruned = mwperf_oracle::oracle_enumerate_schedule_face(
      constraint,
      {mwperf_oracle::BigInt{1}, mwperf_oracle::BigInt{9}},
      {1U, 0U}, {0U, 1U});
  REQUIRE(pruned);
  REQUIRE(pruned.value().primary_objective == mwperf_oracle::BigInt{1});
  REQUIRE(pruned.value().priority_choice ==
          mwperf_oracle::Schedule{1U, 0U});

  auto empty_enabled = mwperf_oracle::oracle_enumerate_schedule_face(
      constraint,
      {mwperf_oracle::BigInt{0}, mwperf_oracle::BigInt{9}},
      {1U, 1U}, {0U, 1U});
  REQUIRE(empty_enabled);
  REQUIRE(empty_enabled.value().primary_objective ==
          mwperf_oracle::BigInt{9});
  REQUIRE(empty_enabled.value().priority_choice ==
          mwperf_oracle::Schedule{0U, 1U});

  auto explicitly_suppressed = mwperf_oracle::oracle_enumerate_schedule_face(
      constraint,
      {mwperf_oracle::BigInt{0}, mwperf_oracle::BigInt{9}},
      {0U, 1U}, {0U, 1U});
  REQUIRE(explicitly_suppressed);
  REQUIRE(empty_enabled.value().maximizing_face ==
          explicitly_suppressed.value().maximizing_face);

  auto tied = mwperf_oracle::oracle_enumerate_schedule_face(
      constraint,
      {mwperf_oracle::BigInt{2}, mwperf_oracle::BigInt{2}},
      {1U, 1U}, {0U, 1U});
  REQUIRE(tied);
  REQUIRE(tied.value().maximizing_face ==
          std::vector<mwperf_oracle::Schedule>{{0U, 1U}, {1U, 0U}});
  REQUIRE(tied.value().priority_choice ==
          mwperf_oracle::Schedule{1U, 0U});
}

TEST_CASE("C26 exact schedule budget exhaustion is compared as capability",
          "[c26][negative][schedule][production][budget]") {
  const mwperf_oracle::PriorityOrder priority{0U, 1U, 2U, 3U};
  // Edge-index order is 01,02,03,12,13,23.  This is the branching fixture
  // with edges 02 and 12 used by the production MWIS accounting tests.
  constexpr std::uint64_t graph = 10U;
  const mwperf_oracle::SmallConstraint constraint = oracle_constraint(
      FamilyFixture::conflict, priority.size(), graph);
  mwperf_oracle::OracleLimits limits;
  limits.maximum_branches = 15U;
  auto oracle = mwperf_oracle::oracle_enumerate_schedule_face(
      constraint,
      {mwperf_oracle::BigInt{1}, mwperf_oracle::BigInt{1},
       mwperf_oracle::BigInt{1}, mwperf_oracle::BigInt{1}},
      {1U, 1U, 1U, 1U}, priority, limits);
  REQUIRE_FALSE(oracle);
  REQUIRE(oracle.error().code == "oracle_budget_exhausted");
  REQUIRE(oracle.error().branches_examined == 15U);

  const mwperf::ResolvedInstance instance =
      resolve_instance(FamilyFixture::conflict, priority, graph, 1U);
  auto context = execution_context(instance);
  auto production = mwperf::resolve_maxweight_schedule(
      instance, production_backlog(instance, {1U, 1U, 1U, 1U}),
      mwperf::TieContext::configured_priority(), context);
  REQUIRE_FALSE(production);
  REQUIRE(production.error().code == "search_state_limit_exhausted");

  // The adapter retains each raw diagnostic above, then maps both independent
  // mechanisms to the one comparison-contract capability reason.
  require_capability_rejection_conformance(
      "c26.fixture.schedule-budget.conflict.graph=10.limit=1",
      "exact_schedule_search_budget_exhausted",
      production.error().code == "search_state_limit_exhausted"
          ? "exact_schedule_search_budget_exhausted"
          : production.error().code);
}
