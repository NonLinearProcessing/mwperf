#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "c22/support/temporal_metrics_fixture.hpp"
#include "fixtures/c21/stationary_suspension_fixture.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/metrics/palm_fifo.hpp"
#include "mwperf/metrics/temporal.hpp"
#include "mwperf/stationary/analytic.hpp"
#include "mwperf/stationary/flux.hpp"
#include "mwperf/stationary/suspension.hpp"
#include "mwperf_oracle/full_state_oracle.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

namespace c17 = mwperf::testing::c17;
namespace c21 = mwperf::testing::c21;
namespace c22 = mwperf::testing::c22;

using mwperf_oracle::ArithmeticMode;
using mwperf_oracle::ArtifactDomain;
using mwperf_oracle::ComparisonContract;
using mwperf_oracle::ExactLawArtifact;
using mwperf_oracle::FiniteModelSemantics;
using mwperf_oracle::NumericalImageArtifact;
using mwperf_oracle::OracleArtifact;
using mwperf_oracle::ProductionArtifact;
using mwperf_oracle::Rational;
using mwperf_oracle::ScientificScope;
using mwperf_oracle::SmallFiniteModel;
using mwperf_oracle::StoppedLawArtifact;

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto value = Rational::make(mwperf_oracle::BigInt{numerator},
                              mwperf_oracle::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] mwperf::ExactRational er(const std::int64_t numerator,
                                       const std::int64_t denominator = 1) {
  auto value = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                           mwperf::BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] Rational from_exact(const mwperf::ExactRational& value) {
  auto converted = Rational::make(value.numerator(), value.denominator());
  REQUIRE(converted);
  return std::move(converted).value();
}

template <typename T>
[[nodiscard]] T require_production(mwperf::Result<T> value) {
  INFO((value ? std::string{}
              : value.error().code + ": " + value.error().message));
  REQUIRE(value);
  return std::move(value).value();
}

template <typename T>
[[nodiscard]] const T& require_optional(const std::optional<T>& value) {
  REQUIRE(value.has_value());
  return *value;
}

[[nodiscard]] mwperf::SourceNode source(const std::string& pointer) {
  return mwperf::SourceNode::make_null(
      mwperf::SourceLocation{"c26-production-readout", 1U, 1U, 0U},
      pointer);
}

[[nodiscard]] mwperf::ReducedStateV1 c18_state(const std::uint8_t value) {
  return {{"c26.production-readout.c18-state", 1U},
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] mwperf::ArrivalPhaseIdentityV1 phase(
    const std::uint8_t value) {
  return {mwperf::ArrivalFamily::periodic_global_phase,
          {static_cast<std::byte>(value)}};
}

[[nodiscard]] mwperf::SolverPolicy c18_policy() {
  return {mwperf::LinearMethod::dense_pivoted, std::nullopt,
          er(1, 1000000000000000LL), mwperf::ExactRational::zero(),
          c22::digest("c26.production-readout.c18-policy")};
}

[[nodiscard]] mwperf::SelectionSpec unique_selection() {
  return mwperf::StationaryUniqueSelection{source("/selection/unique")};
}

[[nodiscard]] OracleArtifact oracle_artifact(
    const ArtifactDomain domain, std::string projection,
    std::string product, mwperf_oracle::ArtifactPayload payload,
    std::optional<FiniteModelSemantics> semantics = std::nullopt) {
  OracleArtifact result;
  result.domain = domain;
  result.scope = ScientificScope::surrogate_law;
  result.finite_semantics = semantics;
  result.projection_identity = std::move(projection);
  result.product_identity = std::move(product);
  result.payload = std::move(payload);
  return result;
}

[[nodiscard]] ProductionArtifact production_artifact(
    const ArtifactDomain domain, std::string projection,
    std::string product, mwperf_oracle::ArtifactPayload payload,
    std::optional<FiniteModelSemantics> semantics = std::nullopt) {
  ProductionArtifact result;
  result.domain = domain;
  result.scope = ScientificScope::surrogate_law;
  result.finite_semantics = semantics;
  result.projection_identity = std::move(projection);
  result.product_identity = std::move(product);
  result.payload = std::move(payload);
  return result;
}

[[nodiscard]] ComparisonContract comparison_contract(
    const ArtifactDomain domain, const ArithmeticMode arithmetic,
    std::string projection, const long double tolerance = 0.0L,
    const bool require_numerics = false) {
  ComparisonContract result;
  result.arithmetic = arithmetic;
  result.domain = domain;
  result.scope = ScientificScope::surrogate_law;
  result.projection_identity = std::move(projection);
  result.numerical_absolute_tolerance = tolerance;
  result.require_residual_and_conditioning = require_numerics;
  return result;
}

void require_conformant(const OracleArtifact& oracle,
                        const ProductionArtifact& production,
                        const ComparisonContract& contract) {
  const auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.code + ": " + report.message);
  REQUIRE(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);
}

[[nodiscard]] std::string palm_label(const mwperf_oracle::BigInt& batch,
                                     const mwperf_oracle::BigInt& rank) {
  return batch.convert_to<std::string>() + ":" +
         rank.convert_to<std::string>();
}

[[nodiscard]] std::string palm_label(const mwperf::BigNat& batch,
                                     const mwperf::BigNat& rank) {
  return batch.to_decimal_string() + ":" + rank.to_decimal_string();
}

}  // namespace

TEST_CASE("C26 exact invariant grounds the released C18 numerical image",
          "[c26][integration][production-readout][c18]") {
  SmallFiniteModel oracle_model;
  oracle_model.semantics = FiniteModelSemantics::closed_abstract_kernel;
  oracle_model.state_labels = {"zero", "one"};
  oracle_model.state_and_mark_convention =
      "predecision-state/unmarked-transition";
  oracle_model.rows = {
      {{0U, r(1, 2), ""}, {1U, r(1, 2), ""}},
      {{0U, r(1, 4), ""}, {1U, r(3, 4), ""}},
  };
  auto oracle_matrix =
      mwperf_oracle::oracle_build_rational_matrix(oracle_model);
  REQUIRE(oracle_matrix);
  auto oracle_law = mwperf_oracle::oracle_solve_rational_invariant(
      oracle_matrix.value(), mwperf_oracle::ExactSelection{});
  REQUIRE(oracle_law);
  CHECK(oracle_law.value().probabilities ==
        std::vector<Rational>{r(1, 3), r(2, 3)});

  const std::vector<mwperf::ReducedStateV1> states{c18_state(0U),
                                                   c18_state(1U)};
  const mwperf::SelectionSpec selection = unique_selection();
  const mwperf::SolverPolicy policy = c18_policy();
  mwperf::C18ExactMatrixFixtureV1 fixture{
      states,
      {er(1, 2), er(1, 2), er(1, 4), er(3, 4)},
      selection,
      policy,
      std::nullopt,
      {},
      mwperf::BoundaryCompletionKindV1::exact_closed,
      std::nullopt,
      true,
      std::nullopt,
      std::nullopt,
      std::nullopt,
      c22::digest("c26.production-readout.c18-exact-state"),
      c22::digest("c26.production-readout.c18-reduced-state"),
      {},
      {},
      std::nullopt,
      {phase(0U), phase(1U)}};
  auto matrix = require_production(
      mwperf::testing::C18FixtureAccess::transition_matrix(
          std::move(fixture)));
  auto selected = require_production(mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(matrix), selection));
  auto production_law = require_production(
      mwperf::solve_invariant_distribution(matrix, selected, policy));
  REQUIRE(production_law.masses().size() == 2U);

  const auto& diagnostics = production_law.solve_diagnostics();
  REQUIRE(diagnostics.class_solves.size() == 1U);
  const auto& class_solve = diagnostics.class_solves.front();
  CHECK(class_solve.status == mwperf::StationaryLinearSolveStatusV1::solved);
  CHECK(std::isfinite(class_solve.reciprocal_condition_estimate));
  CHECK(class_solve.reciprocal_condition_estimate > 0.0L);
  CHECK(diagnostics.normalization_residual <=
        diagnostics.normalization_bound);
  CHECK(diagnostics.l1_invariance_residual <=
        diagnostics.l1_invariance_bound);
  CHECK(diagnostics.maximum_invariance_residual <=
        diagnostics.maximum_invariance_bound);
  const long double residual =
      std::max({diagnostics.normalization_residual,
                diagnostics.l1_invariance_residual,
                diagnostics.maximum_invariance_residual});

  const std::string projection = "c26.c18.invariant-law-v1";
  const auto oracle = oracle_artifact(
      ArtifactDomain::invariant_law, projection, "independent-rational-c18",
      // Numeric prefixes make the exact projection order explicit because
      // numerical-image comparison canonicalizes law labels before taking
      // their high-precision image.
      ExactLawArtifact{{{"0-zero", r(1, 3)}, {"1-one", r(2, 3)}}},
      FiniteModelSemantics::closed_abstract_kernel);
  const auto production = production_artifact(
      ArtifactDomain::invariant_law, projection, "released-c18-solver",
      NumericalImageArtifact{
          {production_law.masses()[0U], production_law.masses()[1U]},
          residual, class_solve.reciprocal_condition_estimate},
      FiniteModelSemantics::closed_abstract_kernel);
  require_conformant(
      oracle, production,
      comparison_contract(ArtifactDomain::invariant_law,
                          ArithmeticMode::numerical_image_of_exact_law,
                          projection, 1.0e-14L, true));
}

TEST_CASE("C26 ROMR summary grounds C21 event and slot readouts",
          "[c26][integration][production-readout][c21]") {
  const std::vector<std::pair<std::vector<mwperf_oracle::BigInt>, Rational>>
      words{{{mwperf_oracle::BigInt{10}}, r(1, 2)},
            {{mwperf_oracle::BigInt{1}, mwperf_oracle::BigInt{2},
              mwperf_oracle::BigInt{3}},
             r(1, 2)}};
  auto oracle_summary =
      mwperf_oracle::oracle_summarize_length_biased_words(words);
  REQUIRE(oracle_summary);

  auto fixture = c21::make_fixture(
      c21::EventSelectionFixtureV1::equal_mixture, c21::rational(1, 4),
      c21::rational(3, 4));
  auto event_law = require_production(mwperf::select_event_invariant_law(
      fixture.kernel, c21::configured_selection(fixture),
      c21::solver_policy(fixture)));
  auto residence_mean = require_production(
      mwperf::compute_mean_residence(event_law, fixture.provider));
  REQUIRE(residence_mean.exact_value().has_value());
  CHECK(*residence_mean.exact_value() == er(2));
  CHECK(from_exact(*residence_mean.exact_value()) ==
        oracle_summary.value().mean_word_length);

  std::vector<Rational> event_phase_mass(2U, Rational::zero());
  for (const auto& atom : event_law.masses()) {
    REQUIRE(atom.state_index < event_law.domain().states().size());
    const std::size_t event_phase =
        c21::phase(event_law.domain().states()[atom.state_index]);
    REQUIRE(event_phase < event_phase_mass.size());
    event_phase_mass[event_phase] =
        event_phase_mass[event_phase] + from_exact(atom.exact_mass);
  }
  const std::string event_projection = "c26.c21.event-law-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::romr_word_law, event_projection,
          "independent-alternating-event-law",
          ExactLawArtifact{{{"length-one", r(1, 2)},
                            {"length-three", r(1, 2)}}}),
      production_artifact(
          ArtifactDomain::romr_word_law, event_projection,
          "released-c21-event-law",
          ExactLawArtifact{{{"length-one", event_phase_mass[0U]},
                            {"length-three", event_phase_mass[1U]}}}),
      comparison_contract(ArtifactDomain::romr_word_law,
                          ArithmeticMode::exact_projected_law,
                          event_projection));

  auto projection = require_production(
      mwperf::build_stationary_temporal_projection(
          event_law, fixture.provider, residence_mean));
  std::vector<Rational> slot_phase_mass(2U, Rational::zero());
  const auto temporal_atoms =
      mwperf::testing::C21FixtureAccess::temporal_atoms(
          projection.temporal_law());
  for (const auto& atom : temporal_atoms) {
    const std::size_t slot_phase = c21::phase(atom.stationary_left_state);
    REQUIRE(slot_phase < slot_phase_mass.size());
    slot_phase_mass[slot_phase] =
        slot_phase_mass[slot_phase] + from_exact(atom.exact_mass);
  }
  const std::string slot_projection = "c26.c21.slot-occupation-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::suspension_occupation, slot_projection,
          "independent-length-biased-occupation",
          ExactLawArtifact{{
              {"length-one", oracle_summary.value()
                                 .slot_word_probabilities[0U]},
              {"length-three", oracle_summary.value()
                                   .slot_word_probabilities[1U]}}}),
      production_artifact(
          ArtifactDomain::suspension_occupation, slot_projection,
          "released-c21-suspension",
          ExactLawArtifact{{{"length-one", slot_phase_mass[0U]},
                            {"length-three", slot_phase_mass[1U]}}}),
      comparison_contract(ArtifactDomain::suspension_occupation,
                          ArithmeticMode::exact_projected_law,
                          slot_projection));

  const mwperf::RewardDecoder reward{
      mwperf::StationaryRewardDomainV1::state,
      mwperf::StationaryRewardIntegrabilityV1::finite_absolute,
      false,
      {},
      [](const mwperf::StationaryRewardArgumentV1& argument) {
        const std::uint8_t reward_phase = c21::phase(argument.state);
        const long double reward_value =
            reward_phase == 0U
                ? 10.0L
                : static_cast<long double>(c21::age(argument.state) + 1U);
        return mwperf::Result<long double>::success(reward_value);
      },
      {"c26.production-readout.c21-reward", 1U}};
  const auto metric = require_production(mwperf::suspend_event_law_to_slots(
      event_law, fixture.provider, residence_mean, reward));
  const auto envelope = require_production(
      mwperf::testing::C21FixtureAccess::decode_metric_envelope(metric));
  REQUIRE(envelope.exact_numerator.has_value());
  REQUIRE(envelope.exact_ratio.has_value());
  CHECK(*envelope.exact_numerator == er(8));
  CHECK(envelope.exact_denominator == er(2));
  CHECK(*envelope.exact_ratio == er(4));

  const std::string reward_projection = "c26.c21.slot-reward-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::scalar_metric, reward_projection,
          "independent-renewal-reward",
          mwperf_oracle::ExactVectorArtifact{
              {oracle_summary.value().slot_reward_mean}}),
      production_artifact(
          ArtifactDomain::scalar_metric, reward_projection,
          "released-c21-reward",
          mwperf_oracle::ExactVectorArtifact{
              {from_exact(*envelope.exact_ratio)}}),
      comparison_contract(ArtifactDomain::scalar_metric,
                          ArithmeticMode::distributional_identity,
                          reward_projection));
}

TEST_CASE("C26 stopped oracle grounds C22 survival exits and defect",
          "[c26][integration][production-readout][c22]") {
  const auto source = c22::exact_killed_chain(
      "c26.production-readout.c22-exact");
  const mwperf::AbsorptionMarks exits{{
      c22::backlog_exit("hit", 1U), c22::backlog_exit("kill", 2U)}};
  const auto killed = require_production(mwperf::construct_killed_kernel(
      require_optional(source.kernel), c22::zero_backlog_safe_set(), exits));
  REQUIRE(killed.row_diagnostics().size() == 2U);
  for (const auto& row : killed.row_diagnostics()) {
    mwperf::ExactRational classified = row.exact_survivor_mass;
    for (const auto& exit : row.exact_typed_exit_masses) {
      classified = classified + exit;
    }
    CHECK(classified == row.exact_source_mass);
    CHECK(row.exact_balance_residual.is_zero());
  }
  const auto stopped = require_production(
      mwperf::evaluate_hit_survival_absorption(
          killed, require_optional(source.entrance),
          {mwperf::BigNat{2U}, true, true},
          c22::solver_policy("c26.production-readout.c22-exact")));

  const std::vector<Rational> expected_survival{r(1), r(3, 4), r(1, 2)};
  REQUIRE(stopped.survival_tails.size() == expected_survival.size());
  for (std::size_t index = 0U; index < expected_survival.size(); ++index) {
    CHECK(from_exact(stopped.survival_tails[index].exact_probability) ==
          expected_survival[index]);
  }
  const std::vector<std::string> expected_type{"hit", "kill", "hit",
                                                "kill"};
  const std::vector<Rational> expected_absorption{r(1, 8), r(1, 8),
                                                  r(5, 32), r(3, 32)};
  REQUIRE(stopped.absorption_masses.size() == expected_absorption.size());
  for (std::size_t index = 0U; index < expected_absorption.size(); ++index) {
    CHECK(stopped.absorption_masses[index].type_id == expected_type[index]);
    CHECK(from_exact(stopped.absorption_masses[index].exact_probability) ==
          expected_absorption[index]);
  }
  CHECK(expected_survival[1U] + expected_absorption[0U] +
            expected_absorption[1U] ==
        Rational::one());
  CHECK(expected_survival[2U] + expected_absorption[0U] +
            expected_absorption[1U] + expected_absorption[2U] +
            expected_absorption[3U] ==
        Rational::one());
  CHECK(stopped.exact_defect_probability.is_zero());
  REQUIRE(stopped.eventual_typed_exit_probabilities.size() == 2U);
  CHECK(from_exact(stopped.eventual_typed_exit_probabilities[0U]
                       .exact_probability) == r(5, 8));
  CHECK(from_exact(stopped.eventual_typed_exit_probabilities[1U]
                       .exact_probability) == r(3, 8));

  const std::string stopped_projection = "c26.c22.stopped-law-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::stopped_survival_and_defect, stopped_projection,
          "independent-c22-killed-law",
          StoppedLawArtifact{{{"safe-after-two", r(1, 2)}}, r(1, 2)}),
      production_artifact(
          ArtifactDomain::stopped_survival_and_defect, stopped_projection,
          "released-c22-killed-law",
          StoppedLawArtifact{
              {{"safe-after-two",
                from_exact(stopped.survival_tails[2U].exact_probability)}},
              Rational::one() -
                  from_exact(stopped.survival_tails[2U]
                                 .exact_probability)}),
      comparison_contract(ArtifactDomain::stopped_survival_and_defect,
                          ArithmeticMode::exact_projected_law,
                          stopped_projection));

  const auto defective_source = c22::defective_killed_chain(
      "c26.production-readout.c22-defective");
  const mwperf::AbsorptionMarks hit{{c22::backlog_exit("hit", 1U)}};
  const auto defective_kernel = require_production(
      mwperf::construct_killed_kernel(
          require_optional(defective_source.kernel),
          c22::zero_backlog_safe_set(), hit));
  const auto defective = require_production(
      mwperf::evaluate_hit_survival_absorption(
          defective_kernel, require_optional(defective_source.entrance),
          {mwperf::BigNat{3U}, true, true},
          c22::solver_policy("c26.production-readout.c22-defective")));
  REQUIRE(defective.survival_tails.size() == 4U);
  CHECK(from_exact(defective.survival_tails.back().exact_probability) ==
        r(1, 2));
  CHECK(from_exact(defective.absorption_masses.front().exact_probability) ==
        r(1, 2));
  CHECK(from_exact(defective.exact_defect_probability) == r(1, 2));
  CHECK(defective.absorption_status == mwperf::AbsorptionStatusV1::defective);
  CHECK(defective.mean_stopping_time.status ==
        mwperf::ExtendedNonnegativeStatusV1::positive_infinity);
  // The surviving trap mass remains one half.  It is not conditioned back to
  // a unit law merely because the other half has already hit.
  CHECK(from_exact(defective.survival_tails.back().exact_probability) !=
        Rational::one());
}

TEST_CASE("C26 independent Palm and FIFO laws ground C23 readouts",
          "[c26][integration][production-readout][c23]") {
  using AdmissionEdge = mwperf::testing::C23SyntheticAdmissionEdgeV1;
  const std::vector<std::pair<mwperf_oracle::BigInt, Rational>> batch_law{
      {mwperf_oracle::BigInt{0}, r(1, 2)},
      {mwperf_oracle::BigInt{1}, r(1, 4)},
      {mwperf_oracle::BigInt{2}, r(1, 4)}};
  auto oracle_palm = mwperf_oracle::oracle_packet_palm_ranks(batch_law);
  REQUIRE(oracle_palm);
  const auto production_palm = require_production(
      mwperf::testing::C23FixtureAccess::inspect_admission_palm(
          {AdmissionEdge{er(1, 2), mwperf::BigNat{0U}, 0U,
                         mwperf::BigNat{0U}},
           AdmissionEdge{er(1, 4), mwperf::BigNat{0U}, 0U,
                         mwperf::BigNat{1U}},
           AdmissionEdge{er(1, 4), mwperf::BigNat{0U}, 0U,
                         mwperf::BigNat{2U}}}));
  CHECK(from_exact(production_palm.exact_intensity) == r(3, 4));

  ExactLawArtifact oracle_palm_law;
  for (const auto& atom : oracle_palm.value()) {
    oracle_palm_law.atoms.push_back(
        {palm_label(atom.batch, atom.rank), atom.mass});
  }
  ExactLawArtifact production_palm_law;
  for (const auto& atom : production_palm.atoms) {
    production_palm_law.atoms.push_back(
        {palm_label(atom.batch_size, atom.rank), from_exact(atom.exact_mass)});
  }
  const std::string palm_projection = "c26.c23.packet-palm-v1";
  require_conformant(
      oracle_artifact(ArtifactDomain::palm_entrance, palm_projection,
                      "independent-packet-palm",
                      std::move(oracle_palm_law)),
      production_artifact(ArtifactDomain::palm_entrance, palm_projection,
                          "released-c23-admission-palm",
                          std::move(production_palm_law)),
      comparison_contract(ArtifactDomain::palm_entrance,
                          ArithmeticMode::exact_projected_law,
                          palm_projection));

  using ServiceState = mwperf::testing::C23SyntheticServiceStateV1;
  using ServiceTransition =
      mwperf::testing::C23SyntheticServiceTransitionV1;
  using Entrance = mwperf::testing::C23SyntheticPolynomialEntranceV1;
  const std::vector<ServiceState> service_states{{
      {ServiceTransition{0U, 0U, er(1, 2)},
       ServiceTransition{0U, 1U, er(1, 2)}}}};
  constexpr std::size_t maximum_tail = 8U;
  const auto production_tails = require_production(
      mwperf::testing::C23FixtureAccess::departure_polynomial_tails(
          service_states, {Entrance{0U, 1U, er(1)}}, maximum_tail));
  REQUIRE(production_tails.size() == maximum_tail + 1U);

  std::vector<Rational> oracle_tails;
  oracle_tails.reserve(maximum_tail + 1U);
  for (std::size_t slot = 0U; slot <= maximum_tail; ++slot) {
    auto tail = mwperf_oracle::oracle_fifo_tail_one_predecessor(slot,
                                                                r(1, 2));
    REQUIRE(tail);
    oracle_tails.push_back(tail.value());
    CHECK(from_exact(production_tails[slot]) == tail.value());
  }
  auto fifo_mean = mwperf_oracle::oracle_fifo_mean_one_predecessor(r(1, 2));
  REQUIRE(fifo_mean);
  CHECK(fifo_mean.value() == r(4));

  ExactLawArtifact oracle_delay;
  ExactLawArtifact production_delay;
  for (std::size_t time = 1U; time <= maximum_tail; ++time) {
    const std::string label = "departure-at-" + std::to_string(time);
    oracle_delay.atoms.push_back(
        {label, oracle_tails[time - 1U] - oracle_tails[time]});
    production_delay.atoms.push_back(
        {label, from_exact(production_tails[time - 1U]) -
                    from_exact(production_tails[time])});
  }
  oracle_delay.atoms.push_back(
      {"unresolved-after-eight", oracle_tails.back()});
  production_delay.atoms.push_back(
      {"unresolved-after-eight", from_exact(production_tails.back())});
  const std::string fifo_projection = "c26.c23.fifo-delay-v1";
  require_conformant(
      oracle_artifact(ArtifactDomain::fifo_delay, fifo_projection,
                      "independent-bernoulli-fifo",
                      std::move(oracle_delay)),
      production_artifact(ArtifactDomain::fifo_delay, fifo_projection,
                          "released-c23-polynomial-fifo",
                          std::move(production_delay)),
      comparison_contract(ArtifactDomain::fifo_delay,
                          ArithmeticMode::exact_projected_law,
                          fifo_projection));
}

TEST_CASE("C26 phase-free response composes with the configured temporal law",
          "[c26][integration][production-readout][c17][c18][temporal]") {
  // The service response is deliberately nonconstant.  The external target
  // arrival alternates deterministically between one and zero, so replacing
  // it by IID replay of its one-slot marginal would change both the rows and
  // the invariant law checked below.
  const mwperf_oracle::ThreeBinScalarResponse oracle_response{
      r(1, 2), r(1), r(1)};
  const mwperf_oracle::ScalarTemporalArrival oracle_arrival{{
      {{mwperf_oracle::BigInt{1}, 1U, r(1)}},
      {{mwperf_oracle::BigInt{0}, 0U, r(1)}},
  }};
  auto fixture = c17::make_three_bin_framework_v1(
      {c17::rational(1, 2), c17::rational(1, 1),
       c17::rational(1, 1)},
      false, 3U);
  const auto audited_response = require_production(
      mwperf::audited_three_bin_response(fixture.framework));
  CHECK(require_production(
            audited_response.service_probability(mwperf::BigNat{1U})) ==
        er(1, 2));
  CHECK(require_production(
            audited_response.service_probability(mwperf::BigNat{2U})) ==
        er(1));
  CHECK(require_production(
            audited_response.service_probability(mwperf::BigNat{3U})) ==
        er(1));
  auto provider = require_production(
      mwperf::audited_row_provider(fixture.framework));

  constexpr std::size_t phase_count = 2U;
  constexpr std::size_t backlog_count = 3U;
  constexpr std::size_t state_count = phase_count * backlog_count;
  const auto state_index = [](const std::size_t backlog,
                              const std::size_t arrival_phase) {
    return arrival_phase * backlog_count + backlog;
  };

  std::vector<Rational> independent_entries(
      state_count * state_count, Rational::zero());
  for (std::size_t arrival_phase = 0U; arrival_phase < phase_count;
       ++arrival_phase) {
    for (std::size_t backlog = 0U; backlog < backlog_count; ++backlog) {
      auto law = mwperf_oracle::oracle_enumerate_scalar_temporal(
          oracle_response, oracle_arrival,
          {{{mwperf_oracle::BigInt{backlog}, arrival_phase}, r(1)}}, 1U);
      REQUIRE(law);
      REQUIRE(law.value().frontiers.size() == 2U);
      for (const auto& atom : law.value().frontiers[1U]) {
        REQUIRE(atom.state.backlog >= 0);
        REQUIRE(atom.state.backlog < mwperf_oracle::BigInt{backlog_count});
        const auto destination_backlog =
            atom.state.backlog.convert_to<std::size_t>();
        independent_entries[state_index(backlog, arrival_phase) *
                                state_count +
                            state_index(destination_backlog,
                                        atom.state.phase)] =
            independent_entries[state_index(backlog, arrival_phase) *
                                    state_count +
                                state_index(destination_backlog,
                                            atom.state.phase)] +
            atom.mass;
      }
    }
  }

  const auto phase_zero_state = c17::reduced_state(
      fixture.ordered_targets, {0U}, false, 0U);
  const auto phase_one_state = c17::reduced_state(
      fixture.ordered_targets, {0U}, true, 1U);
  const auto phase_zero_coordinates =
      require_production(fixture.state_schema.decode(phase_zero_state));
  const auto phase_one_coordinates =
      require_production(fixture.state_schema.decode(phase_one_state));
  REQUIRE_FALSE(c17::same_phase(phase_zero_coordinates.arrival_phase,
                                phase_one_coordinates.arrival_phase));

  std::vector<mwperf::ExactRational> production_entries(
      state_count * state_count, mwperf::ExactRational::zero());
  for (std::size_t arrival_phase = 0U; arrival_phase < phase_count;
       ++arrival_phase) {
    for (std::size_t backlog = 0U; backlog < backlog_count; ++backlog) {
      const auto source_state = c17::reduced_state(
          fixture.ordered_targets,
          {static_cast<std::uint8_t>(backlog)}, arrival_phase == 1U,
          static_cast<std::uint8_t>(arrival_phase));
      const auto row = require_production(
          mwperf::compile_reduced_kernel_row(provider, source_state));
      CHECK(row.exact_total_mass() == mwperf::ExactRational::one());
      for (const auto& atom : row.atoms()) {
        if (atom.exact_mass.is_zero()) {
          CHECK_FALSE(atom.structural_support);
          continue;
        }
        const auto successor = require_production(
            fixture.state_schema.decode(atom.edge.successor_state()));
        const auto& successor_backlog =
            successor.backlog.value_at_target_ordinal(0U).value();
        INFO("source phase=" << arrival_phase << ", backlog=" << backlog
                              << ", successor=" << successor_backlog
                              << ", mass="
                              << atom.exact_mass.to_canonical_string());
        REQUIRE(successor_backlog >= 0);
        REQUIRE(successor_backlog < mwperf::BigInt{backlog_count});
        const auto destination_backlog =
            successor_backlog.convert_to<std::size_t>();
        const bool is_phase_zero = c17::same_phase(
            successor.arrival_phase, phase_zero_coordinates.arrival_phase);
        const bool is_phase_one = c17::same_phase(
            successor.arrival_phase, phase_one_coordinates.arrival_phase);
        REQUIRE(is_phase_zero != is_phase_one);
        const std::size_t destination_phase = is_phase_one ? 1U : 0U;
        auto& entry =
            production_entries[state_index(backlog, arrival_phase) *
                                   state_count +
                               state_index(destination_backlog,
                                           destination_phase)];
        entry = entry + atom.exact_mass;
      }
    }
  }

  REQUIRE(production_entries.size() == independent_entries.size());
  for (std::size_t index = 0U; index < independent_entries.size(); ++index) {
    CHECK(from_exact(production_entries[index]) ==
          independent_entries[index]);
  }

  SmallFiniteModel oracle_model;
  oracle_model.semantics = FiniteModelSemantics::closed_abstract_kernel;
  oracle_model.state_and_mark_convention =
      "predecision-(backlog,arrival-phase)/unmarked-transition";
  oracle_model.state_labels = {"h0-n0", "h0-n1", "h0-n2",
                               "h1-n0", "h1-n1", "h1-n2"};
  oracle_model.rows.resize(state_count);
  for (std::size_t source_state = 0U; source_state < state_count;
       ++source_state) {
    for (std::size_t destination_state = 0U;
         destination_state < state_count; ++destination_state) {
      const Rational& mass =
          independent_entries[source_state * state_count +
                              destination_state];
      if (!mass.is_zero()) {
        oracle_model.rows[source_state].push_back(
            {destination_state, mass, ""});
      }
    }
  }
  auto oracle_matrix =
      mwperf_oracle::oracle_build_rational_matrix(oracle_model);
  REQUIRE(oracle_matrix);
  auto oracle_invariant = mwperf_oracle::oracle_solve_rational_invariant(
      oracle_matrix.value(), mwperf_oracle::ExactSelection{});
  REQUIRE(oracle_invariant);
  const std::vector<Rational> expected_invariant{
      r(1, 6), r(1, 3), r(0), r(0), r(1, 3), r(1, 6)};
  CHECK(oracle_invariant.value().probabilities == expected_invariant);

  std::vector<mwperf::ReducedStateV1> c18_states;
  c18_states.reserve(state_count);
  for (std::size_t index = 0U; index < state_count; ++index) {
    c18_states.push_back(c18_state(static_cast<std::uint8_t>(index)));
  }
  const mwperf::SelectionSpec selection = unique_selection();
  const mwperf::SolverPolicy policy = c18_policy();
  mwperf::C18ExactMatrixFixtureV1 c18_fixture{
      .states = std::move(c18_states),
      .exact_entries = production_entries,
      .bound_selection = selection,
      .bound_solver_policy = policy,
      .numerical_entries = std::nullopt,
      .marked_rows = {},
      .completion_kind = mwperf::BoundaryCompletionKindV1::exact_closed,
      .completion_identity = std::nullopt,
      .physical_mark_preserving = true,
      .bound_instance = std::nullopt,
      .bound_configured_arrival = std::nullopt,
      .bound_target_selection = std::nullopt,
      .exact_state_schema_digest = std::nullopt,
      .reduced_state_schema_digest = std::nullopt,
      .configured_phase_states = {},
      .configured_phase_masses = {},
      .configured_phase_kernel = std::nullopt,
      .state_phases = {}};
  auto matrix = require_production(
      mwperf::testing::C18FixtureAccess::transition_matrix(
          std::move(c18_fixture)));
  auto selected = require_production(mwperf::select_invariant_class(
      mwperf::analyze_communicating_classes(matrix), selection));
  auto production_invariant = require_production(
      mwperf::solve_invariant_distribution(matrix, selected, policy));
  REQUIRE(production_invariant.masses().size() == state_count);
  const auto& diagnostics = production_invariant.solve_diagnostics();
  REQUIRE(diagnostics.class_solves.size() == 1U);
  const auto& class_solve = diagnostics.class_solves.front();
  CHECK(class_solve.status ==
        mwperf::StationaryLinearSolveStatusV1::solved);
  CHECK(class_solve.reciprocal_condition_estimate > 0.0L);
  const long double residual =
      std::max({diagnostics.normalization_residual,
                diagnostics.l1_invariance_residual,
                diagnostics.maximum_invariance_residual});

  const std::string invariant_projection =
      "c26.temporal-response.augmented-invariant-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::invariant_law, invariant_projection,
          "independent-phase-free-response-plus-temporal-arrival",
          ExactLawArtifact{{{"0-h0-n0", r(1, 6)},
                            {"1-h0-n1", r(1, 3)},
                            {"2-h1-n1", r(1, 3)},
                            {"3-h1-n2", r(1, 6)}}},
          FiniteModelSemantics::closed_abstract_kernel),
      production_artifact(
          ArtifactDomain::invariant_law, invariant_projection,
          "released-c17-rows-plus-c18-solver",
          NumericalImageArtifact{
              {production_invariant.masses()[0U],
               production_invariant.masses()[1U],
               production_invariant.masses()[4U],
               production_invariant.masses()[5U]},
              residual, class_solve.reciprocal_condition_estimate},
          FiniteModelSemantics::closed_abstract_kernel),
      comparison_contract(ArtifactDomain::invariant_law,
                          ArithmeticMode::numerical_image_of_exact_law,
                          invariant_projection, 1.0e-14L, true));

  auto false_iid = mwperf::ArrivalLaw::from_audited(audited_response);
  REQUIRE_FALSE(false_iid);
  CHECK(false_iid.error().code == "c19.temporal_iid_not_established");
  const std::string capability_projection =
      "c26.temporal-response.iid-route-rejection-v1";
  require_conformant(
      oracle_artifact(
          ArtifactDomain::capability, capability_projection,
          "independent-temporal-arrival-capability",
          mwperf_oracle::CapabilityArtifact{
              "c19.temporal_iid_not_established"}),
      production_artifact(
          ArtifactDomain::capability, capability_projection,
          "released-c19-capability-rejection",
          mwperf_oracle::CapabilityArtifact{false_iid.error().code}),
      comparison_contract(ArtifactDomain::capability,
                          ArithmeticMode::capability_rejection,
                          capability_projection));
}
