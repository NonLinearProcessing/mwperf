#include "mwperf_oracle/full_state_oracle.hpp"

#include <catch2/catch_test_macros.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace {

using mwperf_oracle::AdaptedResidenceRule;
using mwperf_oracle::ArrivalAtom;
using mwperf_oracle::ArrivalRow;
using mwperf_oracle::Backlog;
using mwperf_oracle::BigInt;
using mwperf_oracle::ConflictConstraint;
using mwperf_oracle::FiniteCoupledInitialLaw;
using mwperf_oracle::InitialAtom;
using mwperf_oracle::Rational;
using mwperf_oracle::ResidenceRuleKind;
using mwperf_oracle::ResidenceStationaryStatus;
using mwperf_oracle::SmallPhysicalModel;
using mwperf_oracle::TieBranch;
using mwperf_oracle::TieRow;

[[nodiscard]] Rational r(const long long numerator,
                         const long long denominator = 1) {
  auto value = Rational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return value.value();
}

[[nodiscard]] ConflictConstraint singleton_constraint() {
  return ConflictConstraint{{{std::uint8_t{0}}}};
}

[[nodiscard]] TieRow deterministic_tie_row() {
  return TieRow{{}, {TieBranch{{0U}, {}, r(1), "priority-0"}}};
}

[[nodiscard]] ArrivalAtom arrival_atom(
    const std::size_t next_phase, const long long reward,
    const bool emit_reward = true, const long long arrivals = 0) {
  ArrivalAtom atom;
  atom.arrivals = Backlog{BigInt{arrivals}};
  atom.next_phase = next_phase;
  atom.mass = r(1);
  if (emit_reward) {
    atom.joint_marks.push_back({"reward", BigInt{reward}});
  }
  return atom;
}

[[nodiscard]] FiniteCoupledInitialLaw coupled_initial(
    std::vector<InitialAtom> atoms) {
  auto law = FiniteCoupledInitialLaw::create(std::move(atoms));
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] Rational total_mass(
    const std::vector<mwperf_oracle::StationaryMarkedEdgeAtom>& atoms) {
  Rational total = Rational::zero();
  for (const auto& atom : atoms) {
    total = total + atom.mass;
  }
  return total;
}

}  // namespace

TEST_CASE("C26 path ROMR derives word kernels endpoints and renewal reward",
          "[c26][unit][romr][path-oracle]") {
  SmallPhysicalModel model;
  model.constraint = singleton_constraint();
  model.arrival_rows = {
      ArrivalRow{{arrival_atom(1U, 10)}},
      ArrivalRow{{arrival_atom(1U, 0, false)}},
      ArrivalRow{{arrival_atom(3U, 1)}},
      ArrivalRow{{arrival_atom(4U, 2)}},
      ArrivalRow{{arrival_atom(4U, 3)}},
  };
  model.tie_rows = {deterministic_tie_row()};
  model.residence_rule = AdaptedResidenceRule{
      ResidenceRuleKind::target_queue_becomes_empty_after_slot, 0U, true};

  const auto initial = coupled_initial({
      InitialAtom{{Backlog{BigInt{1}}, 0U, {}}, r(1, 2)},
      InitialAtom{{Backlog{BigInt{3}}, 2U, {}}, r(1, 2)},
  });
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 3U);
  REQUIRE(law);
  const auto& romr = law.value().residence;

  CHECK(romr.complete_event_occurrence_mass == r(1));
  REQUIRE(romr.event_word_law.size() == 2U);
  CHECK(romr.event_word_law[0U].mass == r(1, 2));
  CHECK(romr.event_word_law[1U].mass == r(1, 2));
  CHECK(romr.event_word_law[0U].word.slots.size() == 1U);
  CHECK(romr.event_word_law[1U].word.slots.size() == 3U);
  CHECK(romr.event_word_law[0U].entrance.queue == Backlog{BigInt{1}});
  CHECK(romr.event_word_law[1U].entrance.queue == Backlog{BigInt{3}});
  CHECK(romr.event_word_law[0U].endpoint.queue == Backlog{BigInt{0}});
  CHECK(romr.event_word_law[1U].endpoint.queue == Backlog{BigInt{0}});

  REQUIRE(romr.mean_word_length.has_value());
  CHECK(*romr.mean_word_length == r(2));
  REQUIRE(romr.length_biased_occupation.size() == 4U);
  Rational short_word_slot_mass = Rational::zero();
  Rational long_word_slot_mass = Rational::zero();
  for (const auto& atom : romr.length_biased_occupation) {
    if (atom.word.slots.size() == 1U) {
      short_word_slot_mass = short_word_slot_mass + atom.mass;
    } else {
      long_word_slot_mass = long_word_slot_mass + atom.mass;
    }
  }
  CHECK(short_word_slot_mass == r(1, 4));
  CHECK(long_word_slot_mass == r(3, 4));

  auto reward =
      mwperf_oracle::oracle_residence_mark_reward_ratio(romr, "reward");
  REQUIRE(reward);
  CHECK(reward.value().expected_reward_per_event == r(8));
  CHECK(reward.value().mean_word_length == r(2));
  CHECK(reward.value().slot_reward_ratio == r(4));
  CHECK_FALSE(reward.value().stationary_interpretation);

  CHECK(romr.first_word_survival_mass == r(1));
  CHECK(romr.first_word_defective_mass == r(0));
  CHECK(romr.right_censored_path_mass == r(1, 2));
  CHECK_FALSE(romr.entrance_endpoint_flow_balanced);
  CHECK(romr.stationary_status ==
        ResidenceStationaryStatus::endpoint_flow_not_stationary);
  CHECK(romr.stationary_marked_edge_law.empty());
}

TEST_CASE("C26 path ROMR retains finite-horizon residence defect",
          "[c26][negative][romr][stopped]") {
  SmallPhysicalModel model;
  model.constraint = singleton_constraint();
  model.arrival_rows = {
      ArrivalRow{{arrival_atom(1U, 10)}},
      ArrivalRow{{arrival_atom(1U, 0, false)}},
      ArrivalRow{{arrival_atom(3U, 1)}},
      ArrivalRow{{arrival_atom(4U, 2)}},
      ArrivalRow{{arrival_atom(4U, 3)}},
  };
  model.tie_rows = {deterministic_tie_row()};
  model.residence_rule = AdaptedResidenceRule{
      ResidenceRuleKind::target_queue_becomes_empty_after_slot, 0U, true};

  const auto initial = coupled_initial({
      InitialAtom{{Backlog{BigInt{1}}, 0U, {}}, r(1, 2)},
      InitialAtom{{Backlog{BigInt{3}}, 2U, {}}, r(1, 2)},
  });
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 2U);
  REQUIRE(law);
  const auto& romr = law.value().residence;

  REQUIRE(romr.first_complete_word_law.size() == 1U);
  CHECK(romr.first_complete_word_law[0U].mass == r(1, 2));
  CHECK(romr.first_word_survival_mass == r(1, 2));
  CHECK(romr.first_word_defective_mass == r(1, 2));
  CHECK(romr.first_word_survival_mass + romr.first_word_defective_mass ==
        Rational::one());
  // The complete sublaw is deliberately not renormalized to one.
  CHECK(romr.first_complete_word_law[0U].mass != Rational::one());
  CHECK(romr.right_censored_path_mass == Rational::one());

  REQUIRE(romr.concatenated_slot_law.size() == 2U);
  for (const auto& atom : romr.concatenated_slot_law) {
    CHECK(atom.slots.size() == 2U);
    CHECK(atom.right_censored);
  }
}

TEST_CASE("C26 path ROMR emits a stationary marked-edge image only after flow",
          "[c26][integration][romr][stationary-edge]") {
  SmallPhysicalModel model;
  model.constraint = singleton_constraint();
  model.arrival_rows = {
      ArrivalRow{{arrival_atom(1U, 2, true, 1)}},
      ArrivalRow{{arrival_atom(0U, 4, true, 1)}},
  };
  model.tie_rows = {deterministic_tie_row()};
  model.residence_rule = AdaptedResidenceRule{
      ResidenceRuleKind::arrival_phase_change, 0U, true};

  const auto initial = coupled_initial({
      InitialAtom{{Backlog{BigInt{1}}, 0U, {}}, r(1, 2)},
      InitialAtom{{Backlog{BigInt{1}}, 1U, {}}, r(1, 2)},
  });
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 2U);
  REQUIRE(law);
  const auto& romr = law.value().residence;

  CHECK(romr.complete_event_occurrence_mass == r(2));
  REQUIRE(romr.event_kernel.size() == 2U);
  for (const auto& row : romr.event_kernel) {
    CHECK(row.entrance_mass == r(1, 2));
    REQUIRE(row.transitions.size() == 1U);
    CHECK(row.transitions[0U].mass == Rational::one());
  }
  CHECK(romr.entrance_endpoint_flow_balanced);
  CHECK(romr.stationary_status == ResidenceStationaryStatus::established);
  CHECK(total_mass(romr.stationary_marked_edge_law) == Rational::one());
  REQUIRE(romr.stationary_marked_edge_law.size() == 2U);

  auto reward =
      mwperf_oracle::oracle_residence_mark_reward_ratio(romr, "reward");
  REQUIRE(reward);
  CHECK(reward.value().expected_reward_per_event == r(3));
  CHECK(reward.value().mean_word_length == r(1));
  CHECK(reward.value().slot_reward_ratio == r(3));
  CHECK(reward.value().stationary_interpretation);

  REQUIRE(romr.concatenated_slot_law.size() == 2U);
  for (const auto& atom : romr.concatenated_slot_law) {
    CHECK(atom.slots.size() == 2U);
    CHECK(atom.complete_word_boundaries == std::vector<std::size_t>{1U, 2U});
    CHECK_FALSE(atom.right_censored);
  }
}

TEST_CASE("C26 path ROMR refuses to condition an all-censored word",
          "[c26][negative][romr][censoring]") {
  SmallPhysicalModel model;
  model.constraint = singleton_constraint();
  model.arrival_rows = {ArrivalRow{{arrival_atom(0U, 1)}}};
  model.tie_rows = {deterministic_tie_row()};
  model.residence_rule = AdaptedResidenceRule{
      ResidenceRuleKind::target_queue_becomes_empty_after_slot, 0U, true};

  const auto initial = coupled_initial(
      {InitialAtom{{Backlog{BigInt{5}}, 0U, {}}, r(1)}});
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 2U);
  REQUIRE(law);
  const auto& romr = law.value().residence;
  CHECK(romr.complete_event_occurrence_mass == Rational::zero());
  CHECK(romr.event_word_law.empty());
  CHECK(romr.event_kernel.empty());
  CHECK(romr.length_biased_occupation.empty());
  CHECK(romr.first_word_survival_mass == Rational::zero());
  CHECK(romr.first_word_defective_mass == Rational::one());
  CHECK(romr.stationary_status ==
        ResidenceStationaryStatus::no_complete_residence);

  auto reward =
      mwperf_oracle::oracle_residence_mark_reward_ratio(romr, "reward");
  REQUIRE_FALSE(reward);
  CHECK(reward.error().code == "oracle_residence_no_complete_word");
}
