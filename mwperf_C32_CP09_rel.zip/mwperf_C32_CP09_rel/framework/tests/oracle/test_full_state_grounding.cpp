#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <numeric>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf_oracle/full_state_oracle.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"
#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "support/c19_math_carriers.hpp"
#include "support/c19_math_test_util.hpp"

namespace {

using mwperf_oracle::AdaptedResidenceRule;
using mwperf_oracle::ArithmeticMode;
using mwperf_oracle::ArtifactDomain;
using mwperf_oracle::Backlog;
using mwperf_oracle::BigInt;
using mwperf_oracle::ComparisonContract;
using mwperf_oracle::ConflictConstraint;
using mwperf_oracle::CrossbarConstraint;
using mwperf_oracle::CrossbarEdge;
using mwperf_oracle::EligibilityMask;
using mwperf_oracle::ExactDiscreteArtifact;
using mwperf_oracle::ExactLawArtifact;
using mwperf_oracle::ExactSelection;
using mwperf_oracle::ExactVectorArtifact;
using mwperf_oracle::FiniteArrivalFamily;
using mwperf_oracle::FiniteCoupledInitialLaw;
using mwperf_oracle::FiniteModelSemantics;
using mwperf_oracle::FullState;
using mwperf_oracle::HalfOpenInterval;
using mwperf_oracle::InitialAtom;
using mwperf_oracle::IntervalConstraint;
using mwperf_oracle::NodeExclusiveConstraint;
using mwperf_oracle::OracleArtifact;
using mwperf_oracle::OracleLimits;
using mwperf_oracle::PackingConstraint;
using mwperf_oracle::PathAtom;
using mwperf_oracle::PathHistory;
using mwperf_oracle::PriorityOrder;
using mwperf_oracle::ProductionArtifact;
using mwperf_oracle::Rational;
using mwperf_oracle::ResidenceRuleKind;
using mwperf_oracle::ScalarState;
using mwperf_oracle::ScalarStateAtom;
using mwperf_oracle::ScalarTemporalArrival;
using mwperf_oracle::ScalarTemporalArrivalAtom;
using mwperf_oracle::Schedule;
using mwperf_oracle::ScientificScope;
using mwperf_oracle::SelectionKind;
using mwperf_oracle::SmallConstraint;
using mwperf_oracle::SmallFiniteModel;
using mwperf_oracle::SmallPhysicalModel;
using mwperf_oracle::ThreeBinScalarResponse;
using mwperf_oracle::TieBranch;
using mwperf_oracle::TieRow;
using mwperf_oracle::UndirectedLink;

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto result = Rational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] Rational from_production(
    const mwperf::ExactRational& value) {
  auto result = Rational::make(value.numerator(), value.denominator());
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] ThreeBinScalarResponse response_from_c15_projection(
    const mwperf::testing::ModeErasedLawProjectionV1& projection) {
  REQUIRE(projection.projection_version == 1U);
  REQUIRE(projection.deployed_law.payload_family_tag ==
          mwperf::PayloadClassTagV1::three_bin_scalar_response_v1);
  REQUIRE(projection.deployed_law.semantic_tag ==
          mwperf::SemanticTagV1::scalar_backlog_response);
  REQUIRE(projection.timing_convention.decision_service_arrival_order ==
          mwperf::TimingConvention::early_service_late_admission);
  const auto& parameters = projection.deployed_law.canonical_law_parameters;
  REQUIRE(parameters[0U].is_zero());
  return {from_production(parameters[1U]), from_production(parameters[2U]),
          from_production(parameters[3U])};
}

[[nodiscard]] CrossbarConstraint two_queue_crossbar(
    const bool conflicting) {
  return CrossbarConstraint{{CrossbarEdge{0U, 0U},
                             conflicting ? CrossbarEdge{0U, 1U}
                                         : CrossbarEdge{1U, 1U}}};
}

[[nodiscard]] IntervalConstraint two_queue_intervals(
    const bool conflicting) {
  return IntervalConstraint{{HalfOpenInterval{r(0), r(2)},
                             conflicting ? HalfOpenInterval{r(1), r(3)}
                                         : HalfOpenInterval{r(2), r(4)}}};
}

[[nodiscard]] NodeExclusiveConstraint two_queue_links(
    const bool conflicting) {
  return NodeExclusiveConstraint{{UndirectedLink{0U, 1U},
                                  conflicting ? UndirectedLink{1U, 2U}
                                              : UndirectedLink{2U, 3U}}};
}

[[nodiscard]] ConflictConstraint two_queue_conflict(const bool conflicting) {
  return ConflictConstraint{{{0U, static_cast<std::uint8_t>(conflicting)},
                             {static_cast<std::uint8_t>(conflicting), 0U}}};
}

[[nodiscard]] PackingConstraint two_queue_packing(const bool conflicting) {
  return conflicting
             ? PackingConstraint{{{BigInt{1}}, {BigInt{1}}}, {BigInt{1}}}
             : PackingConstraint{{{BigInt{1}, BigInt{0}},
                                  {BigInt{0}, BigInt{1}}},
                                 {BigInt{1}, BigInt{1}}};
}

[[nodiscard]] std::vector<SmallConstraint> two_queue_families(
    const bool conflicting) {
  return {two_queue_crossbar(conflicting),
          two_queue_intervals(conflicting),
          two_queue_links(conflicting),
          two_queue_conflict(conflicting),
          two_queue_packing(conflicting)};
}

[[nodiscard]] SmallConstraint isolated_queues(const std::size_t dimension) {
  PackingConstraint packing;
  packing.capacity.assign(dimension, BigInt{1});
  packing.demands.assign(dimension,
                         std::vector<BigInt>(dimension, BigInt{0}));
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    packing.demands[queue][queue] = 1;
  }
  return packing;
}

[[nodiscard]] FiniteCoupledInitialLaw initial_law(
    std::vector<InitialAtom> atoms) {
  auto result = FiniteCoupledInitialLaw::create(std::move(atoms));
  INFO((result ? std::string{} : result.error().code));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SmallPhysicalModel deterministic_one_queue_model(
    const std::vector<std::uint64_t>& arrivals) {
  SmallPhysicalModel model;
  model.constraint = isolated_queues(1U);
  model.arrival_family = FiniteArrivalFamily::deterministic_trace;
  model.arrival_rows.resize(arrivals.size());
  for (std::size_t phase = 0U; phase < arrivals.size(); ++phase) {
    model.arrival_rows[phase].atoms.push_back(
        {{BigInt{arrivals[phase]}},
         phase + 1U == arrivals.size() ? phase : phase + 1U, r(1),
         std::nullopt});
  }
  model.tie_rows.push_back(
      TieRow{{}, {TieBranch{{0U}, {}, r(1), "fixed-priority"}}});
  model.residence_rule =
      AdaptedResidenceRule{ResidenceRuleKind::target_departure, 0U, true};
  return model;
}

[[nodiscard]] bool schedule_less_in_priority(const Schedule& left,
                                             const Schedule& right,
                                             const PriorityOrder& priority) {
  for (const std::size_t queue : priority) {
    if (left[queue] != right[queue]) {
      return left[queue] < right[queue];
    }
  }
  return false;
}

}  // namespace

TEST_CASE("C26 rational arithmetic is canonical and exact",
          "[c26][unit][rational]") {
  CHECK(r(2, 4).canonical() == "1/2");
  CHECK(r(-2, -4).canonical() == "1/2");
  CHECK(r(0, -91).canonical() == "0/1");
  CHECK(r(1, 3) + r(1, 6) == r(1, 2));
  CHECK(r(7, 9) - r(2, 9) == r(5, 9));
  CHECK(r(7, 11) * r(22, 21) == r(2, 3));
  auto quotient = checked_divide(r(3, 5), r(9, 10));
  REQUIRE(quotient);
  CHECK(quotient.value() == r(2, 3));

  const auto zero_denominator = Rational::make(BigInt{1}, BigInt{0});
  REQUIRE_FALSE(zero_denominator);
  CHECK(zero_denominator.error().code == "oracle_zero_denominator");
}

TEST_CASE("C26 five constraint families expose the same two-queue face",
          "[c26][unit][schedule]") {
  const Backlog backlog{BigInt{2}, BigInt{2}};
  const EligibilityMask eligible{1U, 1U};

  for (const SmallConstraint& constraint : two_queue_families(true)) {
    auto first = mwperf_oracle::oracle_enumerate_schedule_face(
        constraint, backlog, eligible, PriorityOrder{0U, 1U});
    REQUIRE(first);
    CHECK(first.value().primary_objective == 2);
    CHECK(first.value().maximizing_face ==
          std::vector<Schedule>{{0U, 1U}, {1U, 0U}});
    CHECK(first.value().priority_choice == Schedule{1U, 0U});
    CHECK(first.value().schedules_examined == 4U);

    auto second = mwperf_oracle::oracle_enumerate_schedule_face(
        constraint, backlog, eligible, PriorityOrder{1U, 0U});
    REQUIRE(second);
    CHECK(second.value().priority_choice == Schedule{0U, 1U});
  }

  for (const SmallConstraint& constraint : two_queue_families(false)) {
    auto result = mwperf_oracle::oracle_enumerate_schedule_face(
        constraint, backlog, eligible, PriorityOrder{0U, 1U});
    REQUIRE(result);
    CHECK(result.value().primary_objective == 4);
    CHECK(result.value().maximizing_face ==
          std::vector<Schedule>{{1U, 1U}});
    CHECK(result.value().priority_choice == Schedule{1U, 1U});
  }
}

TEST_CASE("C26 opportunity enumeration is structural rather than eligible",
          "[c26][unit][opportunity]") {
  auto single_server = mwperf_oracle::oracle_enumerate_schedule_face(
      two_queue_conflict(true), Backlog{BigInt{0}, BigInt{7}},
      EligibilityMask{0U, 1U}, PriorityOrder{0U, 1U});
  REQUIRE(single_server);
  REQUIRE(single_server.value().opportunities.size() == 2U);
  const auto& target = single_server.value().opportunities[0U];
  CHECK(target.forced_one_feasible);
  REQUIRE(target.psi_zero);
  REQUIRE(target.psi_one);
  REQUIRE(target.theta);
  REQUIRE(target.margin);
  CHECK(*target.psi_zero == 7);
  CHECK(*target.psi_one == 0);
  CHECK(*target.theta == 7);
  CHECK(*target.margin == -7);
  CHECK(single_server.value().priority_choice == Schedule{0U, 1U});

  auto compatible = mwperf_oracle::oracle_enumerate_schedule_face(
      two_queue_conflict(false), Backlog{BigInt{3}, BigInt{9}},
      EligibilityMask{1U, 1U}, PriorityOrder{0U, 1U});
  REQUIRE(compatible);
  REQUIRE(compatible.value().opportunities[0U].theta);
  CHECK(*compatible.value().opportunities[0U].theta == 0);

  ConflictConstraint path{{{0U, 1U, 0U},
                           {1U, 0U, 1U},
                           {0U, 1U, 0U}}};
  auto positive = mwperf_oracle::oracle_enumerate_schedule_face(
      path, Backlog{BigInt{1}, BigInt{5}, BigInt{2}},
      EligibilityMask{1U, 1U, 1U}, PriorityOrder{0U, 1U, 2U});
  REQUIRE(positive);
  REQUIRE(positive.value().opportunities[0U].theta);
  CHECK(*positive.value().opportunities[0U].theta == 3);

  auto zero = mwperf_oracle::oracle_enumerate_schedule_face(
      path, Backlog{BigInt{1}, BigInt{2}, BigInt{5}},
      EligibilityMask{1U, 1U, 1U}, PriorityOrder{0U, 1U, 2U});
  REQUIRE(zero);
  REQUIRE(zero.value().opportunities[0U].theta);
  CHECK(*zero.value().opportunities[0U].theta == 0);
}

TEST_CASE("C26 composite identity stays exact beyond 128 bits",
          "[c26][unit][schedule]") {
  const ConflictConstraint reduced_conflict{
      {{0U, 1U, 0U}, {1U, 0U, 1U}, {0U, 1U, 0U}}};
  auto reduced_face = mwperf_oracle::oracle_enumerate_schedule_face(
      reduced_conflict, Backlog{BigInt{7}, BigInt{14}, BigInt{7}},
      EligibilityMask{1U, 1U, 1U}, PriorityOrder{0U, 1U, 2U});
  REQUIRE(reduced_face);
  REQUIRE(reduced_face.value().maximizing_face ==
          std::vector<Schedule>{{0U, 1U, 0U}, {1U, 0U, 1U}});
  REQUIRE(reduced_face.value().priority_choice ==
          Schedule{1U, 0U, 1U});

  Schedule schedule(70U, 0U);
  const std::array<std::size_t, 3U> embedded_indices{0U, 64U, 69U};
  for (std::size_t reduced = 0U; reduced < embedded_indices.size();
       ++reduced) {
    schedule[embedded_indices[reduced]] =
        reduced_face.value().priority_choice[reduced];
  }
  PriorityOrder priority(70U);
  std::iota(priority.begin(), priority.end(), 0U);
  const BigInt primary =
      (BigInt{1} << 140U) + reduced_face.value().primary_objective;
  const BigInt composite = mwperf_oracle::oracle_composite_score_identity(
      primary, schedule, priority);
  CHECK(composite > (BigInt{1} << 200U));
  CHECK((composite >> 70U) == primary);
}

TEST_CASE("C26 maximal-support opportunity is the smaller competitor",
          "[c26][unit][opportunity]") {
  const PackingConstraint capacity_two{
      {{BigInt{1}}, {BigInt{1}}, {BigInt{1}}}, {BigInt{2}}};
  auto face = mwperf_oracle::oracle_enumerate_schedule_face(
      capacity_two, Backlog{BigInt{0}, BigInt{7}, BigInt{11}},
      EligibilityMask{0U, 1U, 1U}, PriorityOrder{0U, 1U, 2U});
  REQUIRE(face);
  REQUIRE(face.value().opportunities.size() == 3U);
  const auto& target = face.value().opportunities[0U];
  REQUIRE(target.psi_zero);
  REQUIRE(target.psi_one);
  REQUIRE(target.theta);
  CHECK(*target.psi_zero == 18);
  CHECK(*target.psi_one == 11);
  CHECK(*target.theta == 7);
}

TEST_CASE("C26 physical paths use early service and late joint admission",
          "[c26][unit][path]") {
  SmallPhysicalModel model =
      deterministic_one_queue_model({2U, 0U, 1U, 0U});
  auto initial = initial_law({{{{BigInt{0}}, 0U, {}}, r(1)}});
  auto law =
      mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 4U);
  REQUIRE(law);
  REQUIRE(law.value().frontiers.size() == 5U);

  const std::array<std::uint64_t, 5U> expected{0U, 2U, 1U, 1U, 0U};
  for (std::size_t boundary = 0U; boundary < expected.size(); ++boundary) {
    REQUIRE(law.value().frontiers[boundary].atoms.size() == 1U);
    CHECK(law.value().frontiers[boundary].atoms[0U].state.queue[0U] ==
          expected[boundary]);
    CHECK(law.value().frontiers[boundary].atoms[0U].mass == r(1));
  }
  const auto& slots = law.value().frontiers.back().atoms[0U].history.slots;
  REQUIRE(slots.size() == 4U);
  CHECK(slots[0U].departures == Schedule{0U});
  CHECK(slots[1U].departures == Schedule{1U});
  CHECK(slots[2U].departures == Schedule{1U});
  CHECK(slots[3U].departures == Schedule{1U});
  for (std::size_t slot = 0U; slot < slots.size(); ++slot) {
    CHECK(slots[slot].decision_slot == slot);
    CHECK(slots[slot].admission_boundary == slot + 1U);
  }
  REQUIRE_FALSE(law.value().residence_paths.empty());
  CHECK(law.value().residence_paths[0U].words.back().right_censored == false);
}

TEST_CASE("C26 coupled initialization never reconstructs marginal products",
          "[c26][unit][path][coupling]") {
  SmallPhysicalModel model = deterministic_one_queue_model({0U, 1U});
  model.arrival_family = FiniteArrivalFamily::finite_joint_iid;
  model.arrival_rows[0U].atoms = {{{BigInt{0}}, 0U, r(1), std::nullopt}};
  model.arrival_rows[1U].atoms = {{{BigInt{1}}, 1U, r(1), std::nullopt}};
  const auto initial = initial_law(
      {{{{BigInt{0}}, 0U, {}}, r(1, 2)},
       {{{BigInt{2}}, 1U, {}}, r(1, 2)}});
  auto law =
      mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 1U);
  REQUIRE(law);
  const auto& final = law.value().frontiers.back().atoms;
  REQUIRE(final.size() == 2U);
  CHECK(final[0U].state.queue[0U] == 0);
  CHECK(final[0U].mass == r(1, 2));
  CHECK(final[1U].state.queue[0U] == 2);
  CHECK(final[1U].mass == r(1, 2));
  CHECK(std::none_of(final.begin(), final.end(), [](const auto& atom) {
    return atom.state.queue[0U] == 1;
  }));
}

TEST_CASE("C26 frontier merging preserves full histories and exact mass",
          "[c26][unit][path]") {
  mwperf_oracle::ExactPathFrontier frontier;
  frontier.atoms = {
      {{{BigInt{1}}, 0U, {}}, PathHistory{}, r(1, 6)},
      {{{BigInt{1}}, 0U, {}}, PathHistory{}, r(1, 3)},
      {{{BigInt{2}}, 1U, {}}, PathHistory{}, r(1, 2)},
  };
  auto merged =
      mwperf_oracle::oracle_merge_equal_states(std::move(frontier));
  REQUIRE(merged);
  REQUIRE(merged.value().atoms.size() == 2U);
  CHECK(merged.value().atoms[0U].mass == r(1, 2));
  CHECK(merged.value().atoms[1U].mass == r(1, 2));
  CHECK(merged.value().atoms[0U].state != merged.value().atoms[1U].state);
}

TEST_CASE("C26 rational matrices find closed classes and exact invariants",
          "[c26][unit][matrix]") {
  SmallFiniteModel model;
  model.semantics = FiniteModelSemantics::intrinsically_finite;
  model.state_labels = {"a", "b", "c"};
  model.state_and_mark_convention = "predecision-state/unmarked-edge";
  model.rows = {
      {{0U, r(1, 2), ""}, {1U, r(1, 2), ""}},
      {{0U, r(1, 3), ""}, {1U, r(1, 3), ""},
       {2U, r(1, 3), ""}},
      {{1U, r(1, 4), ""}, {2U, r(3, 4), ""}},
  };
  auto matrix = mwperf_oracle::oracle_build_rational_matrix(model);
  REQUIRE(matrix);
  CHECK(matrix.value().states_examined == 3U);
  CHECK(matrix.value().branches_examined == 7U);
  REQUIRE(matrix.value().closed_classes.size() == 1U);
  CHECK(matrix.value().closed_classes[0U] ==
        std::vector<std::size_t>{0U, 1U, 2U});

  auto invariant = mwperf_oracle::oracle_solve_rational_invariant(
      matrix.value(), ExactSelection{});
  REQUIRE(invariant);
  CHECK(invariant.value().probabilities ==
        std::vector<Rational>{r(2, 9), r(1, 3), r(4, 9)});

  SmallFiniteModel reducible;
  reducible.semantics = FiniteModelSemantics::closed_abstract_kernel;
  reducible.state_labels = {"transient", "left", "right"};
  reducible.state_and_mark_convention = "closed abstract selector";
  reducible.rows = {
      {{1U, r(1, 2), ""}, {2U, r(1, 2), ""}},
      {{1U, r(1), ""}},
      {{2U, r(1), ""}},
  };
  auto reducible_matrix =
      mwperf_oracle::oracle_build_rational_matrix(reducible);
  REQUIRE(reducible_matrix);
  REQUIRE(reducible_matrix.value().closed_classes.size() == 2U);

  auto unselected = mwperf_oracle::oracle_solve_rational_invariant(
      reducible_matrix.value(), ExactSelection{});
  REQUIRE_FALSE(unselected);
  CHECK(unselected.error().code == "oracle_unselected_closed_classes");

  ExactSelection mixture;
  mixture.kind = SelectionKind::exact_closed_class_mixture;
  mixture.mixture = {{0U, r(1, 3)}, {1U, r(2, 3)}};
  auto selected = mwperf_oracle::oracle_solve_rational_invariant(
      reducible_matrix.value(), mixture);
  REQUIRE(selected);
  CHECK(selected.value().probabilities ==
        std::vector<Rational>{r(0), r(1, 3), r(2, 3)});
}

TEST_CASE("C26 response oracle solves exact infinite constant tails",
          "[c26][unit][stationary]") {
  const ThreeBinScalarResponse constant{r(1, 2), r(1, 2), r(1, 2)};
  auto law =
      mwperf_oracle::oracle_solve_three_bin_bernoulli(constant, r(1, 4));
  REQUIRE(law);
  CHECK(law.value().pi0 == r(1, 2));
  for (std::size_t level = 1U; level <= 7U; ++level) {
    BigInt denominator = 1;
    for (std::size_t index = 0U; index < level; ++index) {
      denominator *= 3;
    }
    auto expected = Rational::make(BigInt{1}, denominator);
    REQUIRE(expected);
    CHECK(law.value().probability(level) == expected.value());
  }
  CHECK(law.value().mean_backlog == r(3, 4));
  CHECK(law.value().mean_departures == r(1, 4));

  const ThreeBinScalarResponse nonmonotone{r(3, 4), r(1, 4), r(2, 3)};
  auto nonmonotone_law = mwperf_oracle::oracle_solve_three_bin_bernoulli(
      nonmonotone, r(1, 4));
  REQUIRE(nonmonotone_law);
  CHECK(nonmonotone_law.value().pi0 == r(135, 224));
  CHECK(nonmonotone_law.value().pi1 == r(15, 56));
  CHECK(nonmonotone_law.value().pi2 == r(5, 56));
  CHECK(nonmonotone_law.value().pi3 == r(15, 448));
  CHECK(nonmonotone_law.value().tail_ratio == r(1, 6));
  CHECK(nonmonotone_law.value().mean_backlog == r(23, 40));
  CHECK(nonmonotone_law.value().mean_departures == r(1, 4));
}

TEST_CASE("C26 independent three-bin law grounds the production C19 image",
          "[c26][integration][stationary]") {
  namespace c19 = mwperf::testing::c19_math;
  auto spec = c19::scalar_carrier(
      c19::lineage("c26-independent-three-bin"),
      c19::bernoulli_atoms(c19::rational(1, 4)),
      {mwperf::ExactRational::zero(), c19::rational(3, 4),
       c19::rational(1, 4)},
      mwperf::BigNat{3U}, c19::rational(2, 3));
  auto response = c19::mint_three_bin_response(std::move(spec));
  REQUIRE(response);
  auto arrival = mwperf::ArrivalLaw::from_audited(response.value());
  REQUIRE(arrival);
  auto production_summary = mwperf::summarize_three_bin_iid_response(
      response.value(), arrival.value());
  REQUIRE(production_summary);
  REQUIRE(production_summary.value().pi_zero());
  REQUIRE(production_summary.value().pi_one());
  REQUIRE(production_summary.value().pi_two());
  REQUIRE(production_summary.value().tail_mass_from_three());
  REQUIRE(production_summary.value().exact_mean_backlog());

  const ThreeBinScalarResponse oracle_response{r(3, 4), r(1, 4), r(2, 3)};
  auto exact = mwperf_oracle::oracle_solve_three_bin_bernoulli(
      oracle_response, r(1, 4));
  REQUIRE(exact);
  const Rational oracle_tail =
      r(1) - exact.value().pi0 - exact.value().pi1 - exact.value().pi2;

  OracleArtifact oracle{
      ArtifactDomain::invariant_law,
      ScientificScope::surrogate_law,
      std::nullopt,
      "three-bin-stationary-regions-v1",
      "phase-free-three-bin",
      ExactLawArtifact{{{"pi0", exact.value().pi0},
                        {"pi1", exact.value().pi1},
                        {"pi2", exact.value().pi2},
                        {"tail", oracle_tail}}},
      false};
  ProductionArtifact production{
      ArtifactDomain::invariant_law,
      ScientificScope::surrogate_law,
      std::nullopt,
      "three-bin-stationary-regions-v1",
      "phase-free-three-bin",
      ExactLawArtifact{{
          {"pi0", from_production(*production_summary.value().pi_zero())},
          {"pi1", from_production(*production_summary.value().pi_one())},
          {"pi2", from_production(*production_summary.value().pi_two())},
          {"tail", from_production(
                       *production_summary.value().tail_mass_from_three())}}},
      false};
  ComparisonContract contract{ArithmeticMode::exact_projected_law,
                              ArtifactDomain::invariant_law,
                              ScientificScope::surrogate_law,
                              "three-bin-stationary-regions-v1", false,
                              0.0L, true};
  const auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.message);
  CHECK(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);

  oracle.domain = ArtifactDomain::scalar_metric;
  oracle.projection_identity = "three-bin-mean-backlog-v1";
  oracle.product_identity = "oracle-three-bin-mean";
  oracle.payload = ExactVectorArtifact{{exact.value().mean_backlog}};
  production.domain = ArtifactDomain::scalar_metric;
  production.projection_identity = "three-bin-mean-backlog-v1";
  production.product_identity = "production-three-bin-mean";
  production.payload = ExactVectorArtifact{{from_production(
      *production_summary.value().exact_mean_backlog())}};
  contract.arithmetic = ArithmeticMode::distributional_identity;
  contract.domain = ArtifactDomain::scalar_metric;
  contract.projection_identity = "three-bin-mean-backlog-v1";
  const auto mean_report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(mean_report.message);
  CHECK(mean_report.conformant);
}

TEST_CASE("C26 consumes C15's sole mode-erased law projection",
          "[c26][integration][surrogate]") {
  namespace c19 = mwperf::testing::c19_math;
  const mwperf::testing::ModeErasedLawProjectionV1 projection{
      1U,
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1,
       1U,
       mwperf::SemanticTagV1::scalar_backlog_response,
       mwperf::testing::ModeErasedStateDomainV1::
           nonnegative_integer_singleton_backlog,
       mwperf::testing::ModeErasedTargetConventionV1::
           selected_target_relative_three_bins,
       {mwperf::ExactRational::zero(), c19::rational(3, 4),
        c19::rational(1, 4), c19::rational(2, 3)},
       mwperf::testing::ModeErasedServiceRandomizationV1::
           independent_fresh_uniform_given_current_backlog},
      {mwperf::PortableArrivalLawSchema::deterministic_trace_v1,
       {std::byte{0x01}},
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival,
       std::nullopt},
      {mwperf::TimingConvention::early_service_late_admission, {}},
      {{}, {}, mwperf::PortableStationaryUniqueSelectionV1{}, {}}};

  const ThreeBinScalarResponse response =
      response_from_c15_projection(projection);
  CHECK(response.s1 == r(3, 4));
  CHECK(response.s2 == r(1, 4));
  CHECK(response.tail == r(2, 3));
  auto law =
      mwperf_oracle::oracle_solve_three_bin_bernoulli(response, r(1, 4));
  REQUIRE(law);
  CHECK(law.value().mean_backlog == r(23, 40));
}

TEST_CASE("C26 temporal response keeps predictive phase outside mu",
          "[c26][unit][temporal]") {
  const ThreeBinScalarResponse response{r(3, 4), r(1, 4), r(2, 3)};
  ScalarTemporalArrival arrival{{
      {{BigInt{1}, 1U, r(1)}},
      {{BigInt{0}, 0U, r(1)}},
  }};

  auto phase_zero = mwperf_oracle::oracle_enumerate_scalar_temporal(
      response, arrival, {{ScalarState{BigInt{2}, 0U}, r(1)}}, 1U);
  REQUIRE(phase_zero);
  REQUIRE(phase_zero.value().frontiers.back().size() == 2U);
  CHECK(phase_zero.value().frontiers.back()[0U].state.phase == 1U);
  CHECK(phase_zero.value().frontiers.back()[0U].state.backlog == 2);
  CHECK(phase_zero.value().frontiers.back()[0U].mass == r(1, 4));
  CHECK(phase_zero.value().frontiers.back()[1U].state.backlog == 3);
  CHECK(phase_zero.value().frontiers.back()[1U].mass == r(3, 4));

  auto phase_one = mwperf_oracle::oracle_enumerate_scalar_temporal(
      response, arrival, {{ScalarState{BigInt{2}, 1U}, r(1)}}, 1U);
  REQUIRE(phase_one);
  REQUIRE(phase_one.value().frontiers.back().size() == 2U);
  CHECK(phase_one.value().frontiers.back()[0U].state.phase == 0U);
  CHECK(phase_one.value().frontiers.back()[0U].state.backlog == 1);
  CHECK(phase_one.value().frontiers.back()[0U].mass == r(1, 4));
  CHECK(phase_one.value().frontiers.back()[1U].state.backlog == 2);
  CHECK(phase_one.value().frontiers.back()[1U].mass == r(3, 4));
}

TEST_CASE("C26 ROMR Palm and FIFO goldens retain their measures",
          "[c26][unit][romr][palm][fifo]") {
  const std::vector<std::pair<std::vector<BigInt>, Rational>> words{
      {{BigInt{10}}, r(1, 2)},
      {{BigInt{1}, BigInt{2}, BigInt{3}}, r(1, 2)},
  };
  auto reward = mwperf_oracle::oracle_length_biased_reward_mean(words);
  REQUIRE(reward);
  CHECK(reward.value() == r(4));

  const std::vector<std::pair<BigInt, Rational>> batches{
      {BigInt{0}, r(1, 2)}, {BigInt{1}, r(1, 4)},
      {BigInt{2}, r(1, 4)}};
  auto palm = mwperf_oracle::oracle_packet_palm_ranks(batches);
  REQUIRE(palm);
  REQUIRE(palm.value().size() == 3U);
  CHECK(palm.value()[0U].batch == 1);
  CHECK(palm.value()[0U].rank == 1);
  CHECK(palm.value()[1U].batch == 2);
  CHECK(palm.value()[1U].rank == 1);
  CHECK(palm.value()[2U].batch == 2);
  CHECK(palm.value()[2U].rank == 2);
  for (const auto& atom : palm.value()) {
    CHECK(atom.mass == r(1, 3));
  }

  for (std::size_t slots = 0U; slots <= 6U; ++slots) {
    auto tail = mwperf_oracle::oracle_fifo_tail_one_predecessor(slots,
                                                                r(1, 2));
    REQUIRE(tail);
    BigInt denominator = BigInt{1} << slots;
    auto expected = Rational::make(BigInt{slots + 1U}, denominator);
    REQUIRE(expected);
    CHECK(tail.value() == expected.value());
  }
}

TEST_CASE("C26 comparison contracts keep domains and scopes separated",
          "[c26][integration][conformance]") {
  OracleArtifact oracle{
      ArtifactDomain::invariant_law,
      ScientificScope::surrogate_law,
      FiniteModelSemantics::closed_abstract_kernel,
      "backlog-law-v1",
      "oracle-surrogate",
      ExactLawArtifact{{{"0", r(1, 2)}, {"2", r(1, 2)}}},
      false};
  ProductionArtifact production{
      ArtifactDomain::invariant_law,
      ScientificScope::surrogate_law,
      FiniteModelSemantics::closed_abstract_kernel,
      "backlog-law-v1",
      "production-surrogate",
      ExactLawArtifact{{{"1", r(1)}}},
      false};
  ComparisonContract contract{ArithmeticMode::distributional_identity,
                              ArtifactDomain::invariant_law,
                              ScientificScope::surrogate_law,
                              "backlog-law-v1", false, 0.0L, true};
  auto mismatch = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(mismatch.conformant);
  CHECK(mismatch.code == "oracle_distribution_mismatch");
  REQUIRE(mismatch.first_mismatch_path);

  production.payload = oracle.payload;
  auto match = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK(match.conformant);
  CHECK_FALSE(match.physical_fidelity_inferred);

  production.scope = ScientificScope::physical_model;
  auto scope = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(scope.conformant);
  CHECK(scope.code == "oracle_scope_mismatch");

  OracleArtifact capped = oracle;
  capped.scope = ScientificScope::physical_model;
  capped.finite_semantics = FiniteModelSemantics::capped_with_drops;
  ProductionArtifact capped_production = production;
  capped_production.scope = ScientificScope::physical_model;
  capped_production.finite_semantics =
      FiniteModelSemantics::capped_with_drops;
  capped_production.payload = capped.payload;
  contract.scope = ScientificScope::physical_model;
  contract.infinite_buffer_physical_semantics = true;
  auto semantics = mwperf_oracle::oracle_compare_production(
      capped, capped_production, contract);
  CHECK_FALSE(semantics.conformant);
  CHECK(semantics.code == "oracle_semantics_mismatch");
  REQUIRE(semantics.finite_semantics.has_value());
  CHECK(*semantics.finite_semantics ==
        FiniteModelSemantics::capped_with_drops);
}

TEST_CASE("C26 numerical comparison requires diagnostics",
          "[c26][integration][conformance]") {
  OracleArtifact oracle{
      ArtifactDomain::scalar_metric,
      ScientificScope::surrogate_law,
      std::nullopt,
      "mean-backlog-v1",
      "exact-oracle",
      ExactVectorArtifact{{r(23, 40)}},
      false};
  ProductionArtifact production{
      ArtifactDomain::scalar_metric,
      ScientificScope::surrogate_law,
      std::nullopt,
      "mean-backlog-v1",
      "numeric-production",
      mwperf_oracle::NumericalImageArtifact{{23.0L / 40.0L}, std::nullopt,
                                             std::nullopt},
      false};
  ComparisonContract contract{ArithmeticMode::numerical_image_of_exact_law,
                              ArtifactDomain::scalar_metric,
                              ScientificScope::surrogate_law,
                              "mean-backlog-v1", false, 1.0e-18L, true};
  auto missing = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(missing.conformant);
  CHECK(missing.code == "oracle_numerical_report_missing");

  production.payload = mwperf_oracle::NumericalImageArtifact{
      {23.0L / 40.0L}, 0.0L, 1.0L};
  auto match = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK(match.conformant);
}

TEST_CASE("C26 rejects malformed exact fixtures and atomic budget exhaustion",
          "[c26][negative]") {
  auto bad_probability = FiniteCoupledInitialLaw::create(
      {{{{BigInt{0}}, 0U, {}}, r(-1)}});
  REQUIRE_FALSE(bad_probability);

  auto bad_mass = FiniteCoupledInitialLaw::create(
      {{{{BigInt{0}}, 0U, {}}, r(1, 2)}});
  REQUIRE_FALSE(bad_mass);
  CHECK(bad_mass.error().code == "oracle_mass_not_one");

  OracleLimits schedule_budget;
  schedule_budget.maximum_branches = 7U;
  auto exhausted = mwperf_oracle::oracle_enumerate_schedule_face(
      isolated_queues(3U), Backlog{BigInt{1}, BigInt{1}, BigInt{1}},
      EligibilityMask{1U, 1U, 1U}, PriorityOrder{0U, 1U, 2U},
      schedule_budget);
  REQUIRE_FALSE(exhausted);
  CHECK(exhausted.error().code == "oracle_budget_exhausted");

  OracleLimits dimension_limit;
  dimension_limit.maximum_schedule_dimension = 2U;
  auto dimension = mwperf_oracle::oracle_enumerate_schedule_face(
      isolated_queues(3U), Backlog{BigInt{1}, BigInt{1}, BigInt{1}},
      EligibilityMask{1U, 1U, 1U}, PriorityOrder{0U, 1U, 2U},
      dimension_limit);
  REQUIRE_FALSE(dimension);
  CHECK(dimension.error().code == "oracle_invalid_dimension");

  SmallPhysicalModel nonadapted = deterministic_one_queue_model({0U});
  nonadapted.residence_rule.prefix_adapted = false;
  auto one = initial_law({{{{BigInt{0}}, 0U, {}}, r(1)}});
  auto nonadapted_result =
      mwperf_oracle::oracle_enumerate_finite_paths(nonadapted, one, 1U);
  REQUIRE_FALSE(nonadapted_result);
  CHECK(nonadapted_result.error().code == "oracle_nonadapted_stop");

  SmallFiniteModel bad_matrix;
  bad_matrix.state_labels = {"only"};
  bad_matrix.state_and_mark_convention = "bad-row";
  bad_matrix.rows = {{{0U, r(1, 2), ""}}};
  auto row = mwperf_oracle::oracle_build_rational_matrix(bad_matrix);
  REQUIRE_FALSE(row);
  CHECK(row.error().code == "oracle_mass_not_one");

  SmallFiniteModel matrix_budget;
  matrix_budget.state_labels = {"left", "right"};
  matrix_budget.state_and_mark_convention = "budgeted-row";
  matrix_budget.rows = {{{0U, r(1), ""}}, {{1U, r(1), ""}}};
  matrix_budget.limits.maximum_matrix_cells = 3U;
  auto exhausted_matrix =
      mwperf_oracle::oracle_build_rational_matrix(matrix_budget);
  REQUIRE_FALSE(exhausted_matrix);
  CHECK(exhausted_matrix.error().code == "oracle_budget_exhausted");
}

TEST_CASE("C26 schedule faces are exhaustive over all four-node graphs",
          "[c26][property][schedule]") {
  constexpr std::size_t dimension = 4U;
  constexpr std::array<std::pair<std::size_t, std::size_t>, 6U> edges{{
      {0U, 1U}, {0U, 2U}, {0U, 3U},
      {1U, 2U}, {1U, 3U}, {2U, 3U},
  }};
  PriorityOrder priority{0U, 1U, 2U, 3U};
  std::size_t checked = 0U;
  for (std::uint32_t graph = 0U; graph < (1U << edges.size()); ++graph) {
    ConflictConstraint constraint;
    constraint.adjacency.assign(
        dimension, std::vector<std::uint8_t>(dimension, 0U));
    for (std::size_t bit = 0U; bit < edges.size(); ++bit) {
      if ((graph & (1U << bit)) != 0U) {
        const auto [first, second] = edges[bit];
        constraint.adjacency[first][second] = 1U;
        constraint.adjacency[second][first] = 1U;
      }
    }
    for (std::uint32_t encoded = 0U; encoded < 256U; ++encoded) {
      std::uint32_t value = encoded;
      Backlog backlog(dimension);
      for (BigInt& queue : backlog) {
        queue = value & 3U;
        value >>= 2U;
      }
      do {
        EligibilityMask eligible(dimension, 0U);
        for (std::size_t queue = 0U; queue < dimension; ++queue) {
          eligible[queue] = backlog[queue] > 0 ? 1U : 0U;
        }
        auto face = mwperf_oracle::oracle_enumerate_schedule_face(
            constraint, backlog, eligible, priority);
        REQUIRE(face);
        REQUIRE_FALSE(face.value().maximizing_face.empty());
        CHECK(std::find(face.value().maximizing_face.begin(),
                        face.value().maximizing_face.end(),
                        face.value().priority_choice) !=
              face.value().maximizing_face.end());
        const auto expected = *std::max_element(
            face.value().maximizing_face.begin(),
            face.value().maximizing_face.end(),
            [&priority](const Schedule& left, const Schedule& right) {
              return schedule_less_in_priority(left, right, priority);
            });
        CHECK(face.value().priority_choice == expected);
        ++checked;
      } while (std::next_permutation(priority.begin(), priority.end()));
    }
  }
  CHECK(checked == 64U * 256U * 24U);
}
