#pragma once

#include <boost/multiprecision/cpp_int.hpp>

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace mwperf {
class PhysicalFidelityAnchor;
}

namespace mwperf_oracle {

using BigInt = boost::multiprecision::cpp_int;

struct OracleError final {
  std::string code;
  std::string message;
  std::size_t states_examined{0U};
  std::size_t branches_examined{0U};

  friend bool operator==(const OracleError&, const OracleError&) = default;
};

template <typename T>
class [[nodiscard]] Result final {
 public:
  [[nodiscard]] static Result success(T value) {
    return Result(std::variant<T, OracleError>(std::in_place_index<0>,
                                                std::move(value)));
  }
  [[nodiscard]] static Result failure(OracleError error) {
    return Result(std::variant<T, OracleError>(std::in_place_index<1>,
                                                std::move(error)));
  }

  [[nodiscard]] bool has_value() const noexcept { return storage_.index() == 0U; }
  explicit operator bool() const noexcept { return has_value(); }
  [[nodiscard]] T& value() & { return std::get<0>(storage_); }
  [[nodiscard]] const T& value() const& { return std::get<0>(storage_); }
  [[nodiscard]] T&& value() && { return std::get<0>(std::move(storage_)); }
  [[nodiscard]] OracleError& error() & { return std::get<1>(storage_); }
  [[nodiscard]] const OracleError& error() const& {
    return std::get<1>(storage_);
  }

 private:
  explicit Result(std::variant<T, OracleError> storage)
      : storage_(std::move(storage)) {}
  std::variant<T, OracleError> storage_;
};

template <>
class [[nodiscard]] Result<void> final {
 public:
  [[nodiscard]] static Result success() { return Result(std::nullopt); }
  [[nodiscard]] static Result failure(OracleError error) {
    return Result(std::move(error));
  }
  [[nodiscard]] bool has_value() const noexcept { return !error_.has_value(); }
  explicit operator bool() const noexcept { return has_value(); }
  [[nodiscard]] OracleError& error() & { return error_.value(); }
  [[nodiscard]] const OracleError& error() const& { return error_.value(); }

 private:
  explicit Result(std::optional<OracleError> error) : error_(std::move(error)) {}
  explicit Result(OracleError error) : error_(std::move(error)) {}
  std::optional<OracleError> error_;
};

// Canonical arbitrary-precision rational used only by the independent oracle.
// The denominator is positive, gcd-reduced, and zero is represented as 0/1.
class Rational final {
 public:
  Rational() = default;
  explicit Rational(BigInt integer) : numerator_(std::move(integer)) {}

  [[nodiscard]] static Result<Rational> make(BigInt numerator,
                                              BigInt denominator);
  [[nodiscard]] static Rational zero() { return Rational{}; }
  [[nodiscard]] static Rational one() { return Rational(BigInt{1}); }

  [[nodiscard]] const BigInt& numerator() const noexcept { return numerator_; }
  [[nodiscard]] const BigInt& denominator() const noexcept {
    return denominator_;
  }
  [[nodiscard]] bool is_zero() const noexcept { return numerator_ == 0; }
  [[nodiscard]] bool is_positive() const noexcept { return numerator_ > 0; }
  [[nodiscard]] bool is_nonnegative() const noexcept { return numerator_ >= 0; }
  [[nodiscard]] std::string canonical() const;
  [[nodiscard]] long double to_long_double() const;

  friend Rational operator+(const Rational& lhs, const Rational& rhs);
  friend Rational operator-(const Rational& lhs, const Rational& rhs);
  friend Rational operator*(const Rational& lhs, const Rational& rhs);
  friend Result<Rational> checked_divide(const Rational& numerator,
                                          const Rational& denominator);
  friend bool operator==(const Rational&, const Rational&) = default;
  friend bool operator<(const Rational& lhs, const Rational& rhs) {
    return lhs.numerator_ * rhs.denominator_ <
           rhs.numerator_ * lhs.denominator_;
  }
  friend bool operator>(const Rational& lhs, const Rational& rhs) {
    return rhs < lhs;
  }
  friend bool operator<=(const Rational& lhs, const Rational& rhs) {
    return !(rhs < lhs);
  }
  friend bool operator>=(const Rational& lhs, const Rational& rhs) {
    return !(lhs < rhs);
  }

 private:
  struct ReducedTag final {};
  Rational(BigInt numerator, BigInt denominator, ReducedTag)
      : numerator_(std::move(numerator)), denominator_(std::move(denominator)) {}
  [[nodiscard]] static Rational reduced(BigInt numerator, BigInt denominator);

  BigInt numerator_{0};
  BigInt denominator_{1};
};

struct OracleLimits final {
  std::size_t maximum_schedule_dimension{8U};
  std::size_t maximum_path_dimension{5U};
  std::size_t maximum_horizon{6U};
  std::size_t maximum_states{100000U};
  std::size_t maximum_branches{1000000U};
  std::size_t maximum_matrix_cells{1000000U};

  friend bool operator==(const OracleLimits&, const OracleLimits&) = default;
};

using Schedule = std::vector<std::uint8_t>;
using Backlog = std::vector<BigInt>;
using EligibilityMask = std::vector<std::uint8_t>;
// Highest-priority queue first. It must be a permutation of [0,d).
using PriorityOrder = std::vector<std::size_t>;

struct CrossbarEdge final {
  std::size_t input;
  std::size_t output;
  friend bool operator==(const CrossbarEdge&, const CrossbarEdge&) = default;
};
struct CrossbarConstraint final {
  std::vector<CrossbarEdge> edges;
};

struct HalfOpenInterval final {
  Rational left;
  Rational right;
  friend bool operator==(const HalfOpenInterval&, const HalfOpenInterval&) =
      default;
};
struct IntervalConstraint final {
  std::vector<HalfOpenInterval> intervals;
};

struct UndirectedLink final {
  std::size_t first;
  std::size_t second;
  friend bool operator==(const UndirectedLink&, const UndirectedLink&) =
      default;
};
struct NodeExclusiveConstraint final {
  std::vector<UndirectedLink> links;
};

struct ConflictConstraint final {
  // Square symmetric zero-diagonal adjacency matrix.
  std::vector<std::vector<std::uint8_t>> adjacency;
};

struct PackingConstraint final {
  // One demand row per queue and one entry per capacity component.
  std::vector<std::vector<BigInt>> demands;
  std::vector<BigInt> capacity;
};

using SmallConstraint =
    std::variant<CrossbarConstraint, IntervalConstraint,
                 NodeExclusiveConstraint, ConflictConstraint,
                 PackingConstraint>;

struct ForcedOpportunity final {
  std::size_t target{0U};
  bool forced_zero_feasible{false};
  bool forced_one_feasible{false};
  std::optional<BigInt> psi_zero;
  std::optional<BigInt> psi_one;
  std::optional<BigInt> theta;
  std::optional<BigInt> margin;
};

struct ExactScheduleFace final {
  std::size_t dimension{0U};
  BigInt primary_objective{0};
  std::vector<Schedule> maximizing_face;
  Schedule priority_choice;
  std::vector<ForcedOpportunity> opportunities;
  std::size_t schedules_examined{0U};
};

// F-C26-01. Physical maximizers are eligibility pruned; forced opportunity
// values are computed separately on the unpruned structural family.
[[nodiscard]] Result<ExactScheduleFace> oracle_enumerate_schedule_face(
    const SmallConstraint& constraint, const Backlog& backlog,
    const EligibilityMask& eligibility, const PriorityOrder& priority,
    OracleLimits limits = {});

[[nodiscard]] BigInt oracle_composite_score_identity(
    const BigInt& primary_objective, const Schedule& schedule,
    const PriorityOrder& priority);

struct FullState final {
  Backlog queue;
  std::size_t arrival_phase{0U};
  std::vector<BigInt> controller_memory;

  friend bool operator==(const FullState&, const FullState&) = default;
};

struct InitialAtom final {
  FullState state;
  Rational mass;
};

class FiniteCoupledInitialLaw final {
 public:
  FiniteCoupledInitialLaw() = delete;
  [[nodiscard]] static Result<FiniteCoupledInitialLaw> create(
      std::vector<InitialAtom> atoms);
  [[nodiscard]] std::span<const InitialAtom> atoms() const noexcept {
    return atoms_;
  }

 private:
  explicit FiniteCoupledInitialLaw(std::vector<InitialAtom> atoms)
      : atoms_(std::move(atoms)) {}
  std::vector<InitialAtom> atoms_;
};

// An exact auxiliary mark emitted by the same finite joint innovation as the
// arrival vector.  The arbitrary-precision integer value keeps path-oracle
// comparisons exact while the nonempty identifier supplies its semantics.
struct ExactJointMark final {
  std::string id;
  BigInt value;

  friend bool operator==(const ExactJointMark&, const ExactJointMark&) =
      default;
};

struct ArrivalAtom final {
  Backlog arrivals;
  std::size_t next_phase{0U};
  Rational mass;
  // When present this is an explicitly declared post-arrival controller
  // update; otherwise the selected tie branch's pre-arrival update is kept.
  std::optional<std::vector<BigInt>> controller_after_arrival;
  // These marks are part of this exact joint atom; they are never sampled or
  // reconstructed independently from the selected arrival vector.
  std::vector<ExactJointMark> joint_marks{};
};
struct ArrivalRow final {
  std::vector<ArrivalAtom> atoms;
};

// Compact, authored finite arrival specifications.  These are deliberately
// not pre-expanded phase rows: the oracle materializes their predictive-state
// chains locally, using exact rational arithmetic, before path enumeration.
// The resulting phase identifier remains part of FullState, so pending
// renewal/round events survive a caller's finite-horizon boundary.
struct DeterministicTraceArrival final {
  // Slot-zero is slots[0].  After the last authored slot the process enters an
  // absorbing zero-arrival phase rather than repeating the last batch.
  std::vector<Backlog> slots;
};

struct GlobalPeriodicArrival final {
  std::vector<Backlog> period;
};

struct SourcePeriodicPattern final {
  std::vector<BigInt> period;
  std::size_t phase_offset{0U};
};

struct SourceDelayPeriodicArrival final {
  // Exactly one pattern per queue.  The joint period is derived by checked
  // least-common-multiple arithmetic; it is never supplied as a flattened
  // table by the fixture author.
  std::vector<SourcePeriodicPattern> sources;
};

struct ExactGapAtom final {
  // gap==1 means an event following a renewal is due in the immediately next
  // decision slot.  Every finite gap law has exact mass one.
  std::size_t gap{0U};
  Rational mass;
};

struct FactorizedRenewalSource final {
  BigInt batch{1};
  std::vector<ExactGapAtom> gap_law;
};

struct FactorizedRenewalArrival final {
  // Sources renew independently only because this type explicitly declares
  // the factorization.  All sources are due in authored slot zero.
  std::vector<FactorizedRenewalSource> sources;
};

struct JointRenewalAtom final {
  Backlog arrivals;
  std::size_t gap{0U};
  Rational mass;
  std::vector<ExactJointMark> joint_marks{};
};

struct JointRenewalArrival final {
  // One common renewal clock and a joint (batch,next-gap,marks) atom.  The
  // first renewal is due in authored slot zero.
  std::vector<JointRenewalAtom> law;
};

struct PrivateMarkovTransition final {
  std::size_t next_state{0U};
  Rational mass;
};

struct PrivateMarkovRenewalState final {
  BigInt event_batch{1};
  std::vector<PrivateMarkovTransition> transitions;
  // After the transition, the new gap is drawn from the entered state's law.
  std::vector<ExactGapAtom> entered_gap_law;
};

struct PrivateMarkovRenewalSource final {
  std::size_t initial_state{0U};
  // An initial gap of one produces the first renewal in decision slot zero.
  std::size_t initial_gap{0U};
  std::vector<PrivateMarkovRenewalState> states;
};

struct PrivateMarkovRenewalArrival final {
  // Source memories are private and factorized.  Each local (Markov state,
  // countdown) coordinate is retained in the materialized predictive phase.
  std::vector<PrivateMarkovRenewalSource> sources;
};

struct SharedRoundEmission final {
  std::size_t delay{0U};
  Backlog arrivals;
  std::vector<ExactJointMark> joint_marks{};
};

struct SharedRoundAtom final {
  Rational mass;
  std::string round_identity;
  // At most one joint emission per delay.  Omitting a delay means the exact
  // all-zero vector at that offset; no coordinatewise marginal is sampled.
  std::vector<SharedRoundEmission> emissions;
};

struct SharedRoundArrival final {
  std::size_t round_length{0U};
  std::vector<SharedRoundAtom> rounds;
};

using AuthoredFiniteArrival =
    std::variant<DeterministicTraceArrival, GlobalPeriodicArrival,
                 SourceDelayPeriodicArrival, FactorizedRenewalArrival,
                 JointRenewalArrival, PrivateMarkovRenewalArrival,
                 SharedRoundArrival>;

enum class FiniteArrivalFamily : std::uint8_t {
  finite_joint_iid,
  deterministic_trace,
  global_periodic,
  source_delay_periodic,
  finite_renewal,
  private_markov_renewal,
  shared_round_renewal,
};

struct TieBranch final {
  PriorityOrder priority;
  std::vector<BigInt> controller_after_decision;
  Rational mass;
  std::string branch_identity;
};
struct TieRow final {
  std::vector<BigInt> current_controller;
  std::vector<TieBranch> branches;
};

enum class ResidenceRuleKind : std::uint8_t {
  none,
  target_queue_empty_after_slot,
  // Unlike target_queue_empty_after_slot, this does not repeatedly stop on
  // every later empty slot.  It records the adapted transition from a
  // positive target queue to an empty postarrival target queue.
  target_queue_becomes_empty_after_slot,
  target_departure,
  arrival_phase_change,
};
struct AdaptedResidenceRule final {
  ResidenceRuleKind kind{ResidenceRuleKind::none};
  std::size_t target{0U};
  bool prefix_adapted{true};
};

struct SmallPhysicalModel final {
  SmallConstraint constraint;
  FiniteArrivalFamily arrival_family{FiniteArrivalFamily::finite_joint_iid};
  // Generic exact rows remain the representation for a finite joint IID law
  // and for inherited comparison fixtures.  New family-grounding fixtures use
  // authored_arrival so renewal, private-memory, and shared-round semantics
  // are independently expanded rather than asserted by a family tag.
  std::vector<ArrivalRow> arrival_rows;
  std::optional<AuthoredFiniteArrival> authored_arrival;
  std::vector<TieRow> tie_rows;
  AdaptedResidenceRule residence_rule;
  // The released oracle multiplies these two finite exact rows only when this
  // conditional-independence premise is explicit. Coupled innovations require
  // a future jointly-authored row type and are rejected here.
  bool tie_and_arrival_conditionally_independent{true};
  OracleLimits limits;
};

enum class SlotTiming : std::uint8_t {
  early_service_late_admission,
};

struct SlotRecord final {
  FullState predecision;
  Schedule schedule;
  Schedule departures;
  Backlog arrivals;
  // Exact marks copied from the selected joint arrival atom for this slot.
  std::vector<ExactJointMark> joint_marks{};
  FullState postarrival;
  std::string tie_branch_identity;
  std::size_t decision_slot{0U};
  std::size_t admission_boundary{1U};
  SlotTiming timing{SlotTiming::early_service_late_admission};

  friend bool operator==(const SlotRecord&, const SlotRecord&) = default;
};

struct PathHistory final {
  std::vector<SlotRecord> slots;
  friend bool operator==(const PathHistory&, const PathHistory&) = default;
};

struct PathAtom final {
  FullState state;
  PathHistory history;
  Rational mass;
};

struct ExactPathFrontier final {
  std::vector<PathAtom> atoms;
  std::size_t states_examined{0U};
  std::size_t branches_examined{0U};
};

struct ResidenceWord final {
  std::vector<SlotRecord> slots;
  bool right_censored{false};

  friend bool operator==(const ResidenceWord&, const ResidenceWord&) =
      default;
};
struct ResidencePathAtom final {
  std::vector<ResidenceWord> words;
  Rational mass;

  friend bool operator==(const ResidencePathAtom&,
                         const ResidencePathAtom&) = default;
};

// A complete residence word carries both endpoint states explicitly.  The
// event_word_law below is normalized by the exact expected number of complete
// words in the enumerated finite window.  The separately stored occurrence
// normalizer makes that finite-window normalization visible.
struct ResidenceWordLawAtom final {
  FullState entrance;
  ResidenceWord word;
  FullState endpoint;
  Rational mass;

  friend bool operator==(const ResidenceWordLawAtom&,
                         const ResidenceWordLawAtom&) = default;
};

struct ResidenceKernelTransition final {
  ResidenceWord word;
  FullState endpoint;
  Rational mass;

  friend bool operator==(const ResidenceKernelTransition&,
                         const ResidenceKernelTransition&) = default;
};

struct ResidenceKernelRow final {
  FullState entrance;
  // Entrance probability under the normalized finite-window event law.
  Rational entrance_mass;
  std::vector<ResidenceKernelTransition> transitions;

  friend bool operator==(const ResidenceKernelRow&,
                         const ResidenceKernelRow&) = default;
};

// Concatenation retains the original physical slot indices and the one-past
// offsets of every complete residence boundary.  A trailing censored word is
// retained instead of silently conditioning the path on termination.
struct ConcatenatedResidencePathAtom final {
  std::vector<SlotRecord> slots;
  std::vector<std::size_t> complete_word_boundaries;
  bool right_censored{false};
  Rational mass;

  friend bool operator==(const ConcatenatedResidencePathAtom&,
                         const ConcatenatedResidencePathAtom&) = default;
};

// Exact length-biased suspension atom.  Each offset in a complete word has
// mass event_word_mass / E[L], so the complete vector has exact mass one.
struct ResidenceSuspensionAtom final {
  FullState entrance;
  ResidenceWord word;
  FullState endpoint;
  std::size_t offset{0U};
  Rational mass;

  friend bool operator==(const ResidenceSuspensionAtom&,
                         const ResidenceSuspensionAtom&) = default;
};

// The ordinary-slot marked edge deliberately omits the absolute enumeration
// slot number.  It is the exact image of the suspension observable and keeps
// the complete service/arrival/mark tuple rather than only its endpoint.
struct ResidenceMarkedEdge final {
  FullState predecision;
  Schedule schedule;
  Schedule departures;
  Backlog arrivals;
  std::vector<ExactJointMark> joint_marks;
  FullState postarrival;
  std::string tie_branch_identity;
  SlotTiming timing{SlotTiming::early_service_late_admission};

  friend bool operator==(const ResidenceMarkedEdge&,
                         const ResidenceMarkedEdge&) = default;
};

struct StationaryMarkedEdgeAtom final {
  ResidenceMarkedEdge edge;
  Rational mass;

  friend bool operator==(const StationaryMarkedEdgeAtom&,
                         const StationaryMarkedEdgeAtom&) = default;
};

enum class ResidenceStationaryStatus : std::uint8_t {
  established,
  no_complete_residence,
  endpoint_flow_not_stationary,
};

struct ExactResidenceDerivation final {
  // Expected number of complete residence words in the finite path window;
  // unlike a probability it may exceed one.
  Rational complete_event_occurrence_mass;
  std::vector<ResidenceWordLawAtom> event_word_law;
  std::vector<ResidenceKernelRow> event_kernel;

  // This first-word law is a subprobability.  Its missing mass is retained as
  // a finite-horizon stopping defect and is never conditioned away.
  std::vector<ResidenceWordLawAtom> first_complete_word_law;
  Rational first_word_survival_mass;
  Rational first_word_defective_mass;
  Rational right_censored_path_mass;

  std::vector<ConcatenatedResidencePathAtom> concatenated_slot_law;
  std::optional<Rational> mean_word_length;
  std::vector<ResidenceSuspensionAtom> length_biased_occupation;

  bool entrance_endpoint_flow_balanced{false};
  ResidenceStationaryStatus stationary_status{
      ResidenceStationaryStatus::no_complete_residence};
  std::vector<StationaryMarkedEdgeAtom> stationary_marked_edge_law;
};

struct ResidenceRewardRatio final {
  Rational expected_reward_per_event;
  Rational mean_word_length;
  Rational slot_reward_ratio;
  bool stationary_interpretation{false};
};

struct ExactPathLaw final {
  std::size_t horizon{0U};
  std::vector<ExactPathFrontier> frontiers;
  std::vector<ResidencePathAtom> residence_paths;
  ExactResidenceDerivation residence;
  std::size_t states_examined{0U};
  std::size_t branches_examined{0U};
};

// F-C26-02
[[nodiscard]] Result<ExactPathLaw> oracle_enumerate_finite_paths(
    const SmallPhysicalModel& model, const FiniteCoupledInitialLaw& initial,
    std::size_t horizon);

// Private-theorem helper beneath F-C26-02: evaluate a named exact joint mark
// under the derived event and length-biased measures.  Missing marks contribute
// zero; duplicate occurrences of the same identifier in one slot are rejected.
[[nodiscard]] Result<ResidenceRewardRatio>
oracle_residence_mark_reward_ratio(const ExactResidenceDerivation& residence,
                                   std::string_view mark_identity);

// F-C26-03
[[nodiscard]] Result<ExactPathFrontier> oracle_merge_equal_states(
    ExactPathFrontier frontier);

enum class FiniteModelSemantics : std::uint8_t {
  intrinsically_finite,
  capped_with_drops,
  capped_with_blocking,
  closed_abstract_kernel,
};

struct FiniteTransitionAtom final {
  std::size_t destination{0U};
  Rational mass;
  std::string mark;
};
struct SmallFiniteModel final {
  FiniteModelSemantics semantics{FiniteModelSemantics::intrinsically_finite};
  std::vector<std::string> state_labels;
  std::string state_and_mark_convention;
  std::vector<std::vector<FiniteTransitionAtom>> rows;
  OracleLimits limits;
};

struct ExactTransitionMatrix final {
  FiniteModelSemantics semantics{FiniteModelSemantics::intrinsically_finite};
  std::vector<std::string> state_labels;
  std::string state_and_mark_convention;
  std::vector<std::vector<Rational>> probabilities;
  std::vector<std::vector<FiniteTransitionAtom>> marked_rows;
  std::vector<std::vector<std::size_t>> closed_classes;
  std::size_t states_examined{0U};
  std::size_t branches_examined{0U};
};

// F-C26-04
[[nodiscard]] Result<ExactTransitionMatrix> oracle_build_rational_matrix(
    const SmallFiniteModel& model);

enum class SelectionKind : std::uint8_t {
  require_unique_closed_class,
  closed_class_index,
  exact_closed_class_mixture,
};
struct ExactSelection final {
  SelectionKind kind{SelectionKind::require_unique_closed_class};
  std::optional<std::size_t> closed_class;
  std::vector<std::pair<std::size_t, Rational>> mixture;
};

struct ExactInvariantLaw final {
  std::vector<Rational> probabilities;
  std::vector<std::vector<std::size_t>> closed_classes;
  ExactSelection selection;
};

// F-C26-05
[[nodiscard]] Result<ExactInvariantLaw> oracle_solve_rational_invariant(
    const ExactTransitionMatrix& matrix, const ExactSelection& selection);

enum class ScientificScope : std::uint8_t {
  physical_model,
  surrogate_law,
  proposal_raw,
  physical_bound,
};
enum class ArtifactDomain : std::uint8_t {
  schedule,
  opportunity,
  physical_path,
  kernel_row,
  invariant_law,
  romr_word_law,
  romr_concatenated_slots,
  suspension_occupation,
  stationary_marked_edge,
  stopped_survival_and_defect,
  palm_entrance,
  fifo_delay,
  scalar_metric,
  proposal_coefficient,
  capability,
};
enum class ArithmeticMode : std::uint8_t {
  exact_discrete,
  exact_projected_law,
  numerical_image_of_exact_law,
  distributional_identity,
  capability_rejection,
};

struct ExactDiscreteArtifact final {
  std::vector<std::string> coordinates;
};
struct ExactLawArtifact final {
  std::vector<std::pair<std::string, Rational>> atoms;
};
// A stopped law is intentionally distinct from an ordinary probability law.
// `surviving_atoms` carries the defective subprobability measure and
// `defective_mass` carries the killed/missing mass; together they must have
// exact mass one.  This prevents a stopped comparison from silently
// conditioning away its defect or from weakening ordinary law validation.
struct StoppedLawArtifact final {
  std::vector<std::pair<std::string, Rational>> surviving_atoms;
  Rational defective_mass;
};
struct ExactVectorArtifact final {
  std::vector<Rational> values;
};
struct ConstantTailLawArtifact final {
  std::vector<Rational> boundary_masses;
  std::size_t tail_start{0U};
  Rational tail_anchor;
  Rational tail_ratio;
  Rational normalization;
  Rational mean_backlog;
  Rational mean_departures;
};
struct NumericalImageArtifact final {
  std::vector<long double> values;
  std::optional<long double> residual;
  std::optional<long double> conditioning;
};
struct CapabilityArtifact final {
  std::string unsupported_reason;
};

enum class ProposalCoefficientBin : std::uint8_t {
  backlog_one,
  backlog_two,
  tail_from_three,
};

enum class ProposalRawValueStatus : std::uint8_t {
  exact_point,
  interval_only,
};

// Only an interval tied to one exact frozen raw proposal coefficient is
// admissible here.  The other values are explicit negative-test carriers:
// neither a recoded coefficient band nor a physical-model interval can be
// relabelled as proposal-raw evidence.
enum class ProposalBandScope : std::uint8_t {
  exact_frozen_raw_coefficient,
  recoded_response,
  physical_model,
};

struct ProposalRawArtifact final {
  std::string frozen_build_identity;
  std::string target_identity;
  ProposalCoefficientBin bin{ProposalCoefficientBin::backlog_one};
  ProposalRawValueStatus value_status{ProposalRawValueStatus::exact_point};
  ProposalBandScope band_scope{
      ProposalBandScope::exact_frozen_raw_coefficient};
  std::optional<Rational> exact_point;
  std::optional<Rational> interval_lower;
  std::optional<Rational> interval_upper;
  std::string evidence_identity;
};
using ArtifactPayload =
    std::variant<ExactDiscreteArtifact, ExactLawArtifact, StoppedLawArtifact,
                 ExactVectorArtifact, ConstantTailLawArtifact,
                 NumericalImageArtifact, CapabilityArtifact,
                 ProposalRawArtifact>;

class PhysicalBoundCertificateRef;

// This adapter is defined only by the production-linked C26 comparison
// runner.  Its exact argument type is C25's nonconstructible, established
// PhysicalFidelityAnchor, so raw C25 evidence or a caller-authored boolean
// cannot mint physical-bound authority for the independent oracle archive.
[[nodiscard]] Result<PhysicalBoundCertificateRef>
bind_validated_c25_physical_fidelity(
    const mwperf::PhysicalFidelityAnchor& anchor);

class PhysicalBoundCertificateRef final {
 public:
  PhysicalBoundCertificateRef() = default;
  // Kept only so pre-C26 aggregate fixtures can spell the absent value as
  // `false`.  Even `true` deliberately remains absent: positive authority is
  // available exclusively through bind_validated_c25_physical_fidelity().
  PhysicalBoundCertificateRef(const bool /*legacy_absence_literal*/) {}

  PhysicalBoundCertificateRef& operator=(const bool /*legacy_absence_literal*/) {
    declared_ = false;
    validated_c25_authority_ = false;
    identity_.clear();
    domain_.reset();
    projection_identity_.clear();
    source_product_identity_.clear();
    destination_product_identity_.clear();
    return *this;
  }
  explicit operator bool() const noexcept { return declared_; }
  [[nodiscard]] const std::string& identity() const noexcept {
    return identity_;
  }
  [[nodiscard]] bool binds(const ArtifactDomain domain,
                           const std::string_view projection_identity,
                           const std::string_view source_product_identity,
                           const std::string_view destination_product_identity)
      const noexcept {
    return declared_ && validated_c25_authority_ && !identity_.empty() &&
           domain_.has_value() &&
           *domain_ == domain &&
           !projection_identity_.empty() &&
           projection_identity_ == projection_identity &&
           !source_product_identity_.empty() &&
           source_product_identity_ == source_product_identity &&
           !destination_product_identity_.empty() &&
           destination_product_identity_ == destination_product_identity;
  }

 private:
  bool declared_{false};
  bool validated_c25_authority_{false};
  std::string identity_;
  std::optional<ArtifactDomain> domain_;
  std::string projection_identity_;
  std::string source_product_identity_;
  std::string destination_product_identity_;

  friend Result<PhysicalBoundCertificateRef>
  bind_validated_c25_physical_fidelity(
      const mwperf::PhysicalFidelityAnchor& anchor);
};

struct OracleArtifact final {
  ArtifactDomain domain{ArtifactDomain::physical_path};
  ScientificScope scope{ScientificScope::physical_model};
  std::optional<FiniteModelSemantics> finite_semantics;
  std::string projection_identity;
  std::string product_identity;
  ArtifactPayload payload;
  PhysicalBoundCertificateRef explicit_physical_bound_certificate;
};
struct ProductionArtifact final {
  ArtifactDomain domain{ArtifactDomain::physical_path};
  ScientificScope scope{ScientificScope::physical_model};
  std::optional<FiniteModelSemantics> finite_semantics;
  std::string projection_identity;
  std::string product_identity;
  ArtifactPayload payload;
  PhysicalBoundCertificateRef explicit_physical_bound_certificate;
};

struct ComparisonContract final {
  ArithmeticMode arithmetic{ArithmeticMode::exact_discrete};
  ArtifactDomain domain{ArtifactDomain::physical_path};
  ScientificScope scope{ScientificScope::physical_model};
  std::string projection_identity;
  bool infinite_buffer_physical_semantics{false};
  long double numerical_absolute_tolerance{0.0L};
  bool require_residual_and_conditioning{true};
  // A comparison derived from F-C26-04/F-C26-05 must set this bit.  Both
  // artifacts must then carry matching explicit finite semantics; omitting
  // both cannot erase a capped/drop/blocking model's scientific scope.
  bool finite_model_comparison{false};
};

struct ConformanceReport final {
  bool conformant{false};
  std::string code;
  std::string message;
  std::optional<std::size_t> first_mismatch;
  std::optional<std::string> first_mismatch_path;
  ArtifactDomain domain{ArtifactDomain::physical_path};
  ScientificScope scope{ScientificScope::physical_model};
  // Retain the reference model's declared finite semantics on every report.
  // This keeps capped/drop/blocking fixtures visibly scoped even when the
  // comparison fails before reaching the payload arithmetic.
  std::optional<FiniteModelSemantics> finite_semantics;
  bool physical_fidelity_inferred{false};
};

// F-C26-06
[[nodiscard]] ConformanceReport oracle_compare_production(
    const OracleArtifact& oracle, const ProductionArtifact& production,
    const ComparisonContract& contract);

// Independent phase-free three-bin response helpers used by the C26 fixtures.
struct ThreeBinScalarResponse final {
  Rational s1;
  Rational s2;
  Rational tail;

  [[nodiscard]] Rational service(const BigInt& backlog) const;
  friend bool operator==(const ThreeBinScalarResponse&,
                         const ThreeBinScalarResponse&) = default;
};

struct BernoulliScalarStationaryLaw final {
  Rational lambda;
  ThreeBinScalarResponse response;
  Rational pi0;
  Rational pi1;
  Rational pi2;
  Rational pi3;
  Rational tail_ratio;
  Rational mean_backlog;
  Rational mean_departures;

  [[nodiscard]] Rational probability(std::size_t level) const;
};

[[nodiscard]] Result<BernoulliScalarStationaryLaw>
oracle_solve_three_bin_bernoulli(const ThreeBinScalarResponse& response,
                                 const Rational& lambda);

// Exact work-conserving early-service/late-admission closure for a batch law
// supported on {0,1,2}.  Levels at and above two have one geometric tail.
struct Batch012StationaryLaw final {
  Rational arrival_zero;
  Rational arrival_one;
  Rational arrival_two;
  Rational pi0;
  Rational pi1;
  Rational pi2;
  Rational tail_ratio;
  Rational mean_backlog;
  Rational mean_departures;

  [[nodiscard]] Rational probability(std::size_t level) const;
};

[[nodiscard]] Result<Batch012StationaryLaw>
oracle_solve_work_conserving_batch_012(
    std::span<const Rational> batch_probabilities);

struct ScalarTemporalArrivalAtom final {
  BigInt arrivals{0};
  std::size_t next_phase{0U};
  Rational mass;
};
struct ScalarTemporalArrival final {
  std::vector<std::vector<ScalarTemporalArrivalAtom>> rows;
};
struct ScalarState final {
  BigInt backlog{0};
  std::size_t phase{0U};
  friend bool operator==(const ScalarState&, const ScalarState&) = default;
};
struct ScalarStateAtom final {
  ScalarState state;
  Rational mass;
};
struct ScalarTransientLaw final {
  std::vector<std::vector<ScalarStateAtom>> frontiers;
};

[[nodiscard]] Result<ScalarTransientLaw> oracle_enumerate_scalar_temporal(
    const ThreeBinScalarResponse& response,
    const ScalarTemporalArrival& arrivals,
    std::vector<ScalarStateAtom> initial, std::size_t horizon,
    OracleLimits limits = {});

[[nodiscard]] Result<Rational> oracle_length_biased_reward_mean(
    std::span<const std::pair<std::vector<BigInt>, Rational>> event_words);

struct LengthBiasedWordSummary final {
  std::vector<Rational> event_word_probabilities;
  std::vector<Rational> slot_word_probabilities;
  Rational mean_word_length;
  Rational slot_reward_mean;
};

[[nodiscard]] Result<LengthBiasedWordSummary>
oracle_summarize_length_biased_words(
    std::span<const std::pair<std::vector<BigInt>, Rational>> event_words);

struct PalmRankAtom final {
  BigInt batch{0};
  BigInt rank{0};
  Rational mass;
};
[[nodiscard]] Result<std::vector<PalmRankAtom>> oracle_packet_palm_ranks(
    std::span<const std::pair<BigInt, Rational>> batch_law);

[[nodiscard]] Result<Rational> oracle_fifo_tail_one_predecessor(
    std::size_t slots, const Rational& service_probability);

[[nodiscard]] Result<Rational> oracle_fifo_mean_one_predecessor(
    const Rational& service_probability);

struct PermanentActivityPalmSummary final {
  Rational stationary_active_mass;
  Rational stationary_event_intensity;
  Rational palm_active_mass;
  Rational palm_next_gap_mean;
};

[[nodiscard]] Result<PermanentActivityPalmSummary>
oracle_permanent_activity_palm(const Rational& stationary_active_mass);

// Independent fixture metadata used to check the generic C15 three-bin
// binding boundary.  These records deliberately carry no production artifact
// type: the oracle validates identities and provenance before it evaluates the
// phase-free law, and C15's ModeErasedLawProjectionV1 remains the sole
// cross-producer mathematical projection.
enum class ScalarCoefficientBin : std::uint8_t {
  one,
  two,
  tail_from_three,
};

enum class ScalarCoefficientStage : std::uint8_t {
  raw_response,
  nominal_response,
  recoded_response,
  projection_center,
  projected_mean,
};

enum class ScalarObservationSource : std::uint8_t {
  exact_population,
  empirical_average,
};

enum class ScalarPopulationConditioningStatus : std::uint8_t {
  proved_positive,
  proved_zero,
  positive_with_confidence,
  unresolved,
};

enum class ScalarRawValueStatus : std::uint8_t {
  exact_point,
  interval_only,
  absent,
};

enum class ScalarProposalBandScope : std::uint8_t {
  proposal_raw,
  deployed_surrogate,
  physical_bound,
};

enum class ScalarProposalBankDependence : std::uint8_t {
  not_applicable,
  iid,
  serial_non_iid,
};

enum class ScalarProposalAsymptoticPremise : std::uint8_t {
  not_applicable,
  iid_lln,
  dependence_adjusted,
};

enum class ScalarProposalCoverage : std::uint8_t {
  deterministic,
  marginal,
  simultaneous,
};

enum class ScalarProducerMode : std::uint8_t {
  inline_immediate,
  in_process_builder,
  local_executable_builder,
};

struct ScalarProposalBand final {
  Rational lower;
  Rational upper;
  ScalarProposalBandScope scope{ScalarProposalBandScope::proposal_raw};
  std::string source_product_identity;
  std::string frozen_build_identity;
  std::string evidence_identity;
  ScalarProposalAsymptoticPremise asymptotic_premise{
      ScalarProposalAsymptoticPremise::not_applicable};
  ScalarProposalCoverage coverage{ScalarProposalCoverage::deterministic};
  std::optional<std::string> simultaneous_allocation_identity;
  std::size_t simultaneous_family_size{0U};

  friend bool operator==(const ScalarProposalBand&,
                         const ScalarProposalBand&) = default;
};

struct ScalarCoefficientEvidence final {
  ScalarCoefficientBin bin{ScalarCoefficientBin::one};
  ScalarObservationSource observation_source{
      ScalarObservationSource::exact_population};
  ScalarPopulationConditioningStatus population_conditioning{
      ScalarPopulationConditioningStatus::unresolved};
  ScalarRawValueStatus raw_value_status{ScalarRawValueStatus::absent};
  std::optional<Rational> raw_point;
  std::optional<ScalarProposalBand> proposal_band;
  std::string evidence_identity;
  std::string frozen_build_identity;
  std::string source_product_identity;
};

struct ScalarDeployedResponsePoint final {
  ScalarCoefficientStage stage{ScalarCoefficientStage::raw_response};
  std::string product_identity;
  ThreeBinScalarResponse response;
  std::optional<std::string> completion_identity;
  std::optional<std::string> recoding_identity;
};

struct ScalarProjectionCenterProduct final {
  std::string product_identity;
  std::vector<std::string> ordered_construction_targets;
  std::vector<Rational> exact_values;
  std::string response_source_product_identity;

  friend bool operator==(const ScalarProjectionCenterProduct&,
                         const ScalarProjectionCenterProduct&) = default;
};

struct ScalarProjectedMeanProduct final {
  std::string product_identity;
  std::vector<std::string> ordered_construction_targets;
  std::vector<Rational> exact_values;
  std::string projection_center_parent_identity;

  friend bool operator==(const ScalarProjectedMeanProduct&,
                         const ScalarProjectedMeanProduct&) = default;
};

enum class ScalarMetricRequestKind : std::uint8_t {
  stationary_mean_backlog,
  stationary_mean_departures,
  backlog_conditioned_service,
  joint_schedule,
  cross_target_law,
  lagged_correlation,
  arbitrary_queue_tail,
  physical_fifo_delay,
};

enum class ScalarMetricBackendKind : std::uint8_t {
  iid_scalar_analytic,
  finite_augmented_temporal,
};

struct ScalarMetricCapabilityManifest final {
  ScalarMetricBackendKind backend{
      ScalarMetricBackendKind::iid_scalar_analytic};
  std::string backend_identity;
  std::vector<ScalarMetricRequestKind> supported_requests;

  friend bool operator==(const ScalarMetricCapabilityManifest&,
                         const ScalarMetricCapabilityManifest&) = default;
};

enum class ScalarMetricCapabilityReason : std::uint8_t {
  supported,
  request_not_declared,
  joint_schedule_not_in_scalar_contract,
  cross_target_law_not_in_scalar_contract,
  lagged_correlation_not_in_scalar_contract,
  arbitrary_tail_not_in_scalar_contract,
  physical_fifo_not_in_scalar_contract,
};

struct ScalarMetricCapabilityDecision final {
  bool supported{false};
  ScalarMetricCapabilityReason reason{
      ScalarMetricCapabilityReason::request_not_declared};
};

struct ScalarDeployedStationaryConditioning final {
  std::string stationary_law_identity;
  std::string selection_identity;
  std::string deployed_response_product_identity;
  std::array<std::optional<Rational>, 3U> bin_mass;

  friend bool operator==(const ScalarDeployedStationaryConditioning&,
                         const ScalarDeployedStationaryConditioning&) =
      default;
};

struct ScalarResponseFixture final {
  std::string provider_identity;
  std::string construction_method_identity;
  ScalarProducerMode producer_mode{ScalarProducerMode::inline_immediate};
  std::string request_identity;
  std::string artifact_identity;
  std::string plug_identity;
  std::string descriptor_identity;
  std::string runtime_target;
  std::string request_target;
  std::vector<std::string> deployed_targets;
  std::string configured_arrival_binding;
  std::string frozen_build_identity;
  std::string raw_product_identity;
  std::optional<std::string> nominal_product_identity;
  std::optional<std::string> recoded_product_identity;
  ScientificScope scientific_scope{ScientificScope::surrogate_law};
  ScalarProposalBankDependence proposal_bank_dependence{
      ScalarProposalBankDependence::not_applicable};
  std::array<ScalarCoefficientEvidence, 3U> coefficients;
  ScalarDeployedResponsePoint deployed;
  std::optional<ScalarProjectionCenterProduct> projection_center;
  std::optional<ScalarProjectedMeanProduct> projected_mean;
  ScalarMetricCapabilityManifest metric_capabilities;
  // This is a deployed-law quantity, not the proposal population measure
  // named by ScalarCoefficientEvidence.  The law, selection, and exact
  // deployed product are mandatory parts of the identity; no implication is
  // permitted in either direction.
  std::optional<ScalarDeployedStationaryConditioning>
      deployed_stationary_conditioning;
};

struct ScalarResponseFixtureBindingContract final {
  std::string expected_provider_identity;
  std::string expected_construction_method_identity;
  ScalarProducerMode expected_producer_mode{
      ScalarProducerMode::inline_immediate};
  std::string expected_request_identity;
  std::string expected_artifact_identity;
  std::string expected_plug_identity;
  std::string expected_descriptor_identity;
  std::string expected_runtime_target;
  std::string expected_configured_arrival_binding;
  std::string expected_frozen_build_identity;
  std::string expected_raw_product_identity;
  std::string expected_deployed_product_identity;
  ThreeBinScalarResponse expected_deployed_response;
  ScalarProposalBankDependence expected_proposal_bank_dependence{
      ScalarProposalBankDependence::not_applicable};
  std::array<std::string, 3U> expected_coefficient_evidence_identity;
  std::array<std::optional<std::string>, 3U>
      expected_proposal_band_evidence_identity;
  std::array<std::optional<ScalarProposalBand>, 3U>
      expected_proposal_bands;
  std::optional<std::string> expected_completion_identity;
  std::optional<std::string> expected_recoding_identity;
  std::optional<ScalarProjectionCenterProduct> expected_projection_center;
  std::optional<ScalarProjectedMeanProduct> expected_projected_mean;
  ScalarMetricCapabilityManifest expected_metric_capabilities;
  std::optional<ScalarDeployedStationaryConditioning>
      expected_deployed_stationary_conditioning;
  ScientificScope expected_scope{ScientificScope::surrogate_law};
};

struct ValidatedScalarResponseFixture final {
  ThreeBinScalarResponse response;
  ScalarCoefficientStage deployed_stage{ScalarCoefficientStage::raw_response};
  std::string deployed_product_identity;
  std::array<ScalarPopulationConditioningStatus, 3U> proposal_conditioning;
  // Preserve rather than summarize the construction-stage provenance.
  std::array<ScalarCoefficientEvidence, 3U> coefficient_evidence;
  std::optional<std::string> completion_identity;
  std::optional<std::string> recoding_identity;
  std::optional<ScalarProjectionCenterProduct> projection_center;
  std::optional<ScalarProjectedMeanProduct> projected_mean;
  ScalarMetricCapabilityManifest metric_capabilities;
  std::optional<ScalarDeployedStationaryConditioning>
      deployed_stationary_conditioning;
};

[[nodiscard]] Result<ValidatedScalarResponseFixture>
oracle_validate_scalar_response_fixture(
    const ScalarResponseFixture& fixture,
    const ScalarResponseFixtureBindingContract& contract);

[[nodiscard]] ScalarMetricCapabilityDecision
oracle_scalar_fixture_metric_capability(
    const ValidatedScalarResponseFixture& fixture,
    ScalarMetricRequestKind request) noexcept;

}  // namespace mwperf_oracle
