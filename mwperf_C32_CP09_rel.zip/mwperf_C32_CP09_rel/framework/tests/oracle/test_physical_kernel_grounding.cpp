#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/direct_v0_fixture.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf_oracle/full_state_oracle.hpp"

namespace {

using mwperf_oracle::AdaptedResidenceRule;
using mwperf_oracle::ArithmeticMode;
using mwperf_oracle::ArtifactDomain;
using mwperf_oracle::BigInt;
using mwperf_oracle::ComparisonContract;
using mwperf_oracle::ExactDiscreteArtifact;
using mwperf_oracle::ExactLawArtifact;
using mwperf_oracle::FiniteArrivalFamily;
using mwperf_oracle::FiniteCoupledInitialLaw;
using mwperf_oracle::InitialAtom;
using mwperf_oracle::OracleArtifact;
using mwperf_oracle::PackingConstraint;
using mwperf_oracle::ProductionArtifact;
using mwperf_oracle::Rational;
using mwperf_oracle::ResidenceRuleKind;
using mwperf_oracle::ScientificScope;
using mwperf_oracle::SmallPhysicalModel;
using mwperf_oracle::TieBranch;
using mwperf_oracle::TieRow;

struct C12PathFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  std::shared_ptr<const mwperf::InitialPhysicalLaw> initial;
};

[[nodiscard]] Rational exact_one() { return Rational::one(); }

[[nodiscard]] Rational from_production(const mwperf::ExactRational& value) {
  auto converted = Rational::make(value.numerator(), value.denominator());
  REQUIRE(converted);
  return std::move(converted).value();
}

[[nodiscard]] std::filesystem::path write_c26_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> sequence{0U};
  const auto directory = std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) /
                         "c26-physical-grounding";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const auto path =
      directory /
      (std::string(stem) + '-' +
       std::to_string(sequence.fetch_add(1U, std::memory_order_relaxed)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] C12PathFixture make_c12_path_fixture() {
  static constexpr std::string_view model_text = R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":4,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,
              "queues":[{"id":"q0"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[]},"priority":["q0"],
      "max_search_states":null}},
    "arrival":{"family":"deterministic_trace","events":[
      {"slot":0,"queue_id":"q0","count":2},
      {"slot":2,"queue_id":"q0","count":1}],"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
  static constexpr std::string_view analysis_text = R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"law","kind":"transient_backlog_law",
                "parameters":{"horizons":[0,1,2,3,4]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":128,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{
      "atoms":[{"probability":1,
                "backlog":[{"queue_id":"q0","value":0}],
                "controller_state":{},
                "arrival_state":{"kind":"trace_origin"},
                "static_context":{},"surrogate_initial":{}}]}}},
    "solver":{"kind":"enumerated","parameters":{
      "linear_method":"dense_pivoted","max_iterations":null}}
  })json";

  auto model_document =
      mwperf::load_document(write_c26_input("model", model_text));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document =
      mwperf::load_document(write_c26_input("analysis", analysis_text));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);

  const auto canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const auto fingerprints = mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_law());

  mwperf::ResolvedInstance instance = std::move(resolved).value();
  auto arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.arrival());
  auto initial = mwperf::detail::CompiledInitialLawAccess::get(
      *instance.initial_law());
  REQUIRE(arrival);
  REQUIRE(initial);
  return {std::move(instance), std::move(arrival).value(),
          std::move(initial).value()};
}

[[nodiscard]] SmallPhysicalModel deterministic_oracle_model(
    const std::vector<std::uint64_t>& arrivals) {
  SmallPhysicalModel model;
  model.constraint = PackingConstraint{{{BigInt{1}}}, {BigInt{1}}};
  model.arrival_family = FiniteArrivalFamily::deterministic_trace;
  model.arrival_rows.resize(arrivals.size());
  for (std::size_t phase = 0U; phase < arrivals.size(); ++phase) {
    model.arrival_rows[phase].atoms.push_back(
        {{BigInt{arrivals[phase]}},
         phase + 1U == arrivals.size() ? phase : phase + 1U, exact_one(),
         std::nullopt});
  }
  model.tie_rows.push_back(TieRow{
      {}, {TieBranch{{0U}, {}, exact_one(), "fixed-priority"}}});
  model.residence_rule =
      AdaptedResidenceRule{ResidenceRuleKind::none, 0U, true};
  return model;
}

[[nodiscard]] FiniteCoupledInitialLaw oracle_initial(
    const std::uint64_t backlog) {
  auto law = FiniteCoupledInitialLaw::create(
      {InitialAtom{{{BigInt{backlog}}, 0U, {}}, exact_one()}});
  REQUIRE(law);
  return std::move(law).value();
}

[[nodiscard]] std::string projected_row_label(const std::string& pre,
                                               const std::string& post,
                                               const std::uint8_t departure) {
  return "pre=" + pre + ";post=" + post +
         ";departure=" + std::to_string(departure);
}

[[nodiscard]] std::vector<std::string> oracle_path_coordinates(
    const mwperf_oracle::ExactPathLaw& law) {
  std::vector<std::string> result;
  result.reserve(law.frontiers.size() + law.horizon);
  for (std::size_t boundary = 0U; boundary < law.frontiers.size();
       ++boundary) {
    REQUIRE(law.frontiers[boundary].atoms.size() == 1U);
    const auto& atom = law.frontiers[boundary].atoms.front();
    REQUIRE(atom.mass == exact_one());
    result.push_back("Q[" + std::to_string(boundary) + "]=" +
                     atom.state.queue.front().convert_to<std::string>());
  }
  const auto& slots = law.frontiers.back().atoms.front().history.slots;
  REQUIRE(slots.size() == law.horizon);
  for (std::size_t slot = 0U; slot < slots.size(); ++slot) {
    result.push_back("D[" + std::to_string(slot) + "]=" +
                     std::to_string(slots[slot].departures.front()));
  }
  return result;
}

[[nodiscard]] std::vector<std::string> production_path_coordinates(
    const mwperf::PhysicalPath& path) {
  std::vector<std::string> result;
  result.reserve(path.edges().size() * 2U + 1U);
  result.push_back("Q[0]=" + path.initial_state()
                                  .backlog()
                                  .values()
                                  .front()
                                  .to_decimal_string());
  for (std::size_t slot = 0U; slot < path.edges().size(); ++slot) {
    result.push_back("Q[" + std::to_string(slot + 1U) + "]=" +
                     path.edges()[slot]
                         .post_state()
                         .backlog()
                         .values()
                         .front()
                         .to_decimal_string());
  }
  for (std::size_t slot = 0U; slot < path.edges().size(); ++slot) {
    result.push_back("D[" + std::to_string(slot) + "]=" +
                     std::to_string(
                         path.edges()[slot].departure().bytes().front()));
  }
  return result;
}

}  // namespace

TEST_CASE("C26 independent path law grounds the deterministic C12 path",
          "[c26][integration][physical-grounding]") {
  auto fixture = make_c12_path_fixture();
  auto optimizer =
      mwperf::OptimizerExecutionContext::from_resolved_instance(
          fixture.instance);
  REQUIRE(optimizer);
  auto production_path = mwperf::execute_reference_path(
      fixture.instance, *fixture.arrival, *fixture.initial,
      mwperf::BigNat{4U}, mwperf::MasterSeed{0xC2601U}, optimizer.value());
  INFO((production_path
            ? std::string{}
            : production_path.error().code + ": " +
                  production_path.error().message));
  REQUIRE(production_path);

  auto oracle_path = mwperf_oracle::oracle_enumerate_finite_paths(
      deterministic_oracle_model({2U, 0U, 1U, 0U}), oracle_initial(0U),
      4U);
  REQUIRE(oracle_path);

  OracleArtifact expected{
      ArtifactDomain::physical_path,
      ScientificScope::physical_model,
      std::nullopt,
      "q0-boundary-and-departure-v1",
      "c12-deterministic-physical-path",
      ExactDiscreteArtifact{oracle_path_coordinates(oracle_path.value())},
      false};
  ProductionArtifact actual{
      ArtifactDomain::physical_path,
      ScientificScope::physical_model,
      std::nullopt,
      "q0-boundary-and-departure-v1",
      "c12-deterministic-physical-path",
      ExactDiscreteArtifact{
          production_path_coordinates(production_path.value())},
      false};
  const ComparisonContract contract{
      ArithmeticMode::exact_discrete,
      ArtifactDomain::physical_path,
      ScientificScope::physical_model,
      "q0-boundary-and-departure-v1",
      true,
      0.0L,
      true};
  const auto report =
      mwperf_oracle::oracle_compare_production(expected, actual, contract);
  INFO(report.code + ": " + report.message);
  REQUIRE(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);
}

TEST_CASE("C26 exact projected row grounds one V0-sealed C17 factor row",
          "[c26][integration][kernel-grounding]") {
  namespace direct = mwperf::testing::c17_direct;

  auto scenarios = direct::make_scenarios();
  auto factor = direct::make_factor_framework(scenarios.factor);
  const auto& v0 = mwperf::v0_witness_report(factor.framework);
  REQUIRE(v0.passed());

  auto provider = mwperf::audited_row_provider(factor.framework);
  REQUIRE(provider);
  auto production_row = mwperf::compile_reduced_kernel_row(
      provider.value(), factor.initial_state);
  INFO((production_row
            ? std::string{}
            : production_row.error().code + ": " +
                  production_row.error().message));
  REQUIRE(production_row);
  REQUIRE(production_row.value().exact_total_mass() ==
          mwperf::ExactRational::one());

  auto oracle_path = mwperf_oracle::oracle_enumerate_finite_paths(
      deterministic_oracle_model({0U}), oracle_initial(1U), 1U);
  REQUIRE(oracle_path);
  REQUIRE(oracle_path.value().frontiers.size() == 2U);
  REQUIRE(oracle_path.value().frontiers.back().atoms.size() == 1U);
  const auto& oracle_atom =
      oracle_path.value().frontiers.back().atoms.front();
  REQUIRE(oracle_atom.history.slots.size() == 1U);
  const auto& oracle_slot = oracle_atom.history.slots.front();
  const std::string oracle_label = projected_row_label(
      oracle_slot.predecision.queue.front().convert_to<std::string>(),
      oracle_slot.postarrival.queue.front().convert_to<std::string>(),
      oracle_slot.departures.front());

  std::vector<std::pair<std::string, Rational>> production_atoms;
  production_atoms.reserve(production_row.value().atoms().size());
  for (const auto& atom : production_row.value().atoms()) {
    auto pre = factor.state_schema.decode(atom.edge.pre_state());
    auto post = factor.state_schema.decode(atom.edge.successor_state());
    REQUIRE(pre);
    REQUIRE(post);
    REQUIRE(pre.value().backlog.size() == 1U);
    REQUIRE(post.value().backlog.size() == 1U);
    REQUIRE_FALSE(atom.edge.action().actual_departure.bytes().empty());
    production_atoms.emplace_back(
        projected_row_label(
            pre.value()
                .backlog.value_at_target_ordinal(0U)
                .to_decimal_string(),
            post.value()
                .backlog.value_at_target_ordinal(0U)
                .to_decimal_string(),
            atom.edge.action().actual_departure.bytes().front()),
        from_production(atom.exact_mass));
  }

  OracleArtifact expected{
      ArtifactDomain::kernel_row,
      ScientificScope::surrogate_law,
      std::nullopt,
      "target-backlog-departure-row-v1",
      "independent-c26-projected-row",
      ExactLawArtifact{{{oracle_label, exact_one()}}},
      false};
  ProductionArtifact actual{
      ArtifactDomain::kernel_row,
      ScientificScope::surrogate_law,
      std::nullopt,
      "target-backlog-departure-row-v1",
      "production-c17-v0-row",
      ExactLawArtifact{std::move(production_atoms)},
      false};
  const ComparisonContract contract{
      ArithmeticMode::exact_projected_law,
      ArtifactDomain::kernel_row,
      ScientificScope::surrogate_law,
      "target-backlog-departure-row-v1",
      false,
      0.0L,
      true};
  const auto report =
      mwperf_oracle::oracle_compare_production(expected, actual, contract);
  INFO(report.code + ": " + report.message);
  REQUIRE(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);
}
