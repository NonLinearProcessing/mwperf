#include <concepts>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf_oracle/full_state_oracle.hpp"
#include "support/c17_spy_plugs.hpp"

namespace mwperf_oracle {

Result<PhysicalBoundCertificateRef> bind_validated_c25_physical_fidelity(
    const mwperf::PhysicalFidelityAnchor& anchor) {
  if (anchor.kind() != mwperf::PhysicalFidelityKindV1::exact &&
      anchor.kind() != mwperf::PhysicalFidelityKindV1::bounded) {
    return Result<PhysicalBoundCertificateRef>::failure(
        {"c26.physical_bound_not_established",
         "C26 physical-bound scope requires C25 exact or bounded physical "
         "fidelity evidence",
         0U, 0U});
  }
  if (anchor.kind() == mwperf::PhysicalFidelityKindV1::bounded &&
      (!anchor.finite_bound().has_value() ||
       !std::isfinite(*anchor.finite_bound()) ||
       *anchor.finite_bound() < 0.0L)) {
    return Result<PhysicalBoundCertificateRef>::failure(
        {"c26.physical_bound_value_unavailable",
         "C25 bounded physical fidelity must carry a finite nonnegative "
         "bound",
         0U, 0U});
  }
  PhysicalBoundCertificateRef result;
  result.declared_ = true;
  result.validated_c25_authority_ = true;
  result.identity_ =
      "sha256:" + anchor.comparison_theorem_identity().hex();
  result.domain_ = ArtifactDomain::scalar_metric;
  result.projection_identity_ = "sha256:" + anchor.metric_identity().hex();
  result.source_product_identity_ =
      "sha256:" + anchor.subject_product_identity().hex();
  result.destination_product_identity_ =
      "sha256:" + anchor.physical_reference_law_identity().hex();
  return Result<PhysicalBoundCertificateRef>::success(std::move(result));
}

}  // namespace mwperf_oracle

namespace {

using mwperf_oracle::ArithmeticMode;
using mwperf_oracle::ArtifactDomain;
using mwperf_oracle::ComparisonContract;
using mwperf_oracle::ExactDiscreteArtifact;
using mwperf_oracle::ExactLawArtifact;
using mwperf_oracle::ExactVectorArtifact;
using mwperf_oracle::FiniteModelSemantics;
using mwperf_oracle::OracleArtifact;
using mwperf_oracle::PhysicalBoundCertificateRef;
using mwperf_oracle::ProductionArtifact;
using mwperf_oracle::ProposalBandScope;
using mwperf_oracle::ProposalCoefficientBin;
using mwperf_oracle::ProposalRawArtifact;
using mwperf_oracle::ProposalRawValueStatus;
using mwperf_oracle::Rational;
using mwperf_oracle::ScientificScope;
using mwperf_oracle::StoppedLawArtifact;

static_assert(!std::default_initializable<mwperf::PhysicalFidelityAnchor>);
using PhysicalBinder = mwperf_oracle::Result<PhysicalBoundCertificateRef> (*)(
    const mwperf::PhysicalFidelityAnchor&);
static_assert(!std::invocable<PhysicalBinder,
                              const mwperf::PhysicalFidelityEvidenceV1&>);

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto result = Rational::make(numerator, denominator);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Digest256 digest(const std::string_view text) {
  auto result = mwperf::sha256(
      std::as_bytes(std::span<const char>(text.data(), text.size())));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TypedLabel label(const std::string_view text) {
  auto result = mwperf::TypedLabel::text(std::string(text));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object(
    const std::string_view text) {
  return {label(text), digest(text)};
}

[[nodiscard]] mwperf::PhysicalFidelityAnchor validated_physical_anchor() {
  auto carrier =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto baseline = mwperf::Evidence::bind(carrier.framework, {});
  REQUIRE(baseline);

  const auto evidence_id = object("c26.physical-bound.evidence");
  const auto premise_id = object("c26.physical-bound.premise");
  const auto subject_product = digest("c26.physical-bound.subject-product");
  const auto subject_law = digest("c26.physical-bound.subject-law");
  std::vector<mwperf::CertificateEvidenceNodeV1> nodes{
      mwperf::CertificatePremiseEvidenceV1{
          .evidence_id = premise_id,
          .supported_claim =
              mwperf::CertificateClaimKindV1::physical_fidelity,
          .subject_product_identity = subject_product,
          .subject_law_identity = subject_law,
          .premise_identity = digest("c26.physical-bound.premise-statement"),
          .provenance_identity = object("c26.physical-bound.provenance"),
          .coverage =
              mwperf::CertificateCoverageV1::global_declared_domain,
          .origin =
              mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          .dependencies = {},
      },
      mwperf::PhysicalFidelityEvidenceV1{
          evidence_id,
          mwperf::CodecIdentityV1{"mwperf.c25.physical-fidelity", 1U},
          baseline.value()
              .framework_bindings()
              .problem_fingerprints.resolved_instance,
          subject_product,
          subject_law,
          digest("c26.physical-bound.reference-law"),
          digest("c26.physical-bound.metric"),
          digest("c26.physical-bound.regime"),
          digest("c26.physical-bound.theorem"),
          mwperf::PhysicalFidelityKindV1::bounded,
          mwperf::CertificateEvidenceOriginV1::independent_a_priori,
          false,
          0.125L,
          {premise_id}}};
  auto evidence = mwperf::Evidence::bind(carrier.framework, std::move(nodes));
  REQUIRE(evidence);
  auto bundle = mwperf::CertificateBundle::v0_only(evidence.value());
  bundle.physical_fidelity = evidence_id;
  auto validated = mwperf::validate_certificate_bundle(
      bundle, carrier.framework, evidence.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto anchor = validated.value().physical_fidelity_anchor();
  REQUIRE(anchor);
  return std::move(anchor).value();
}

[[nodiscard]] ComparisonContract law_contract(const ArtifactDomain domain) {
  ComparisonContract contract;
  contract.arithmetic = ArithmeticMode::exact_projected_law;
  contract.domain = domain;
  contract.scope = ScientificScope::surrogate_law;
  contract.projection_identity = "c26-law-projection";
  return contract;
}

[[nodiscard]] OracleArtifact oracle_artifact(
    const ArtifactDomain domain, mwperf_oracle::ArtifactPayload payload) {
  OracleArtifact artifact;
  artifact.domain = domain;
  artifact.scope = ScientificScope::surrogate_law;
  artifact.projection_identity = "c26-law-projection";
  artifact.product_identity = "oracle-product";
  artifact.payload = std::move(payload);
  return artifact;
}

[[nodiscard]] ProductionArtifact production_artifact(
    const ArtifactDomain domain, mwperf_oracle::ArtifactPayload payload) {
  ProductionArtifact artifact;
  artifact.domain = domain;
  artifact.scope = ScientificScope::surrogate_law;
  artifact.projection_identity = "c26-law-projection";
  artifact.product_identity = "production-product";
  artifact.payload = std::move(payload);
  return artifact;
}

}  // namespace

TEST_CASE("C26 ordinary exact laws require nonnegative unit mass",
          "[c26][negative][conformance]") {
  const auto domain = ArtifactDomain::invariant_law;
  const auto contract = law_contract(domain);
  const auto valid = ExactLawArtifact{{{"left", r(1, 4)},
                                        {"left", r(1, 4)},
                                        {"right", r(1, 2)}}};
  auto production = production_artifact(
      domain, ExactLawArtifact{{{"right", r(1, 2)}, {"left", r(1, 2)}}});

  auto report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(domain, valid), production, contract);
  INFO(report.message);
  CHECK(report.conformant);

  for (const ExactLawArtifact& invalid : {
           ExactLawArtifact{},
           ExactLawArtifact{{{"negative", r(-1)}, {"excess", r(2)}}},
           ExactLawArtifact{{{"half", r(1, 2)}}},
       }) {
    report = mwperf_oracle::oracle_compare_production(
        oracle_artifact(domain, invalid), production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code == "oracle_invalid_exact_law");
  }
}

TEST_CASE("C26 stopped laws retain their defective mass as a typed field",
          "[c26][unit][conformance][stopped]") {
  const auto domain = ArtifactDomain::stopped_survival_and_defect;
  const auto contract = law_contract(domain);
  const StoppedLawArtifact oracle_law{
      {{"alive-a", r(1, 4)}, {"alive-b", r(1, 4)}}, r(1, 2)};
  const StoppedLawArtifact production_law{
      {{"alive-b", r(1, 4)}, {"alive-a", r(1, 4)}}, r(1, 2)};

  auto report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(domain, oracle_law),
      production_artifact(domain, production_law), contract);
  INFO(report.message);
  CHECK(report.conformant);

  report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(domain,
                      StoppedLawArtifact{{{"alive", r(1, 2)}}, r(1, 4)}),
      production_artifact(domain, production_law), contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_invalid_stopped_law");

  report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(domain, ExactLawArtifact{{{"alive", r(1)}}}),
      production_artifact(domain, ExactLawArtifact{{{"alive", r(1)}}}),
      contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_payload_domain_mismatch");

  const auto invariant_contract =
      law_contract(ArtifactDomain::invariant_law);
  report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(ArtifactDomain::invariant_law, oracle_law),
      production_artifact(ArtifactDomain::invariant_law, production_law),
      invariant_contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_payload_domain_mismatch");
}

TEST_CASE("C26 arithmetic modes reject incompatible payload kinds",
          "[c26][negative][conformance]") {
  ComparisonContract contract;
  contract.arithmetic = ArithmeticMode::exact_discrete;
  contract.domain = ArtifactDomain::physical_path;
  contract.scope = ScientificScope::surrogate_law;
  contract.projection_identity = "c26-law-projection";

  auto oracle = oracle_artifact(ArtifactDomain::physical_path,
                                ExactVectorArtifact{{r(1)}});
  auto production = production_artifact(ArtifactDomain::physical_path,
                                        ExactVectorArtifact{{r(1)}});
  production.product_identity = oracle.product_identity;
  auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_arithmetic_mode_mismatch");

  contract.arithmetic = ArithmeticMode::exact_projected_law;
  report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(ArtifactDomain::physical_path,
                      ExactDiscreteArtifact{{"path"}}),
      production_artifact(ArtifactDomain::physical_path,
                          ExactDiscreteArtifact{{"path"}}),
      contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_arithmetic_mode_mismatch");

  contract.arithmetic = ArithmeticMode::distributional_identity;
  contract.domain = ArtifactDomain::scalar_metric;
  report = mwperf_oracle::oracle_compare_production(
      oracle_artifact(ArtifactDomain::scalar_metric,
                      ExactLawArtifact{{{"metric-as-law", r(1)}}}),
      production_artifact(ArtifactDomain::scalar_metric,
                          ExactLawArtifact{{{"metric-as-law", r(1)}}}),
      contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_payload_domain_mismatch");
}

TEST_CASE("C26 proposal raw comparison preserves exact frozen coefficient scope",
          "[c26][negative][conformance][proposal-raw]") {
  ComparisonContract contract;
  contract.arithmetic = ArithmeticMode::distributional_identity;
  contract.domain = ArtifactDomain::proposal_coefficient;
  contract.scope = ScientificScope::proposal_raw;
  contract.projection_identity = "c26.raw-coefficient-projection";

  const ProposalRawArtifact exact{
      "frozen-build-a", "target-q0", ProposalCoefficientBin::backlog_two,
      ProposalRawValueStatus::exact_point,
      ProposalBandScope::exact_frozen_raw_coefficient, r(1, 3), std::nullopt,
      std::nullopt, "exact-population-evidence-a"};
  auto oracle = oracle_artifact(contract.domain, exact);
  auto production = production_artifact(contract.domain, exact);
  oracle.scope = contract.scope;
  production.scope = contract.scope;
  oracle.projection_identity = contract.projection_identity;
  production.projection_identity = contract.projection_identity;
  oracle.product_identity = "raw-product-q0-bin2-build-a";
  production.product_identity = oracle.product_identity;

  auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.message);
  CHECK(report.conformant);

  const ProposalRawArtifact interval{
      "frozen-build-a", "target-q0", ProposalCoefficientBin::tail_from_three,
      ProposalRawValueStatus::interval_only,
      ProposalBandScope::exact_frozen_raw_coefficient, std::nullopt, r(1, 4),
      r(1, 2), "simultaneous-band-evidence-a"};
  oracle.payload = interval;
  production.payload = interval;
  oracle.product_identity = "raw-product-q0-tail-build-a";
  production.product_identity = oracle.product_identity;
  report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.message);
  CHECK(report.conformant);

  SECTION("frozen build target and bin mutations are binding failures") {
    for (std::size_t mutation = 0U; mutation < 3U; ++mutation) {
      auto mutated = interval;
      if (mutation == 0U) {
        mutated.frozen_build_identity = "frozen-build-b";
      } else if (mutation == 1U) {
        mutated.target_identity = "target-q1";
      } else {
        mutated.bin = ProposalCoefficientBin::backlog_one;
      }
      production.payload = std::move(mutated);
      report = mwperf_oracle::oracle_compare_production(
          oracle, production, contract);
      CHECK_FALSE(report.conformant);
      CHECK(report.code == "oracle_proposal_binding_mismatch");
    }
  }

  SECTION("a raw proposal band cannot be relabelled as recoded or physical") {
    auto invalid = interval;
    invalid.band_scope = ProposalBandScope::physical_model;
    production.payload = std::move(invalid);
    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code == "oracle_invalid_proposal_raw");
  }

  SECTION("interval-only evidence cannot smuggle a designated point") {
    auto invalid = interval;
    invalid.exact_point = r(3, 8);
    production.payload = std::move(invalid);
    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code == "oracle_invalid_proposal_raw");
  }

  SECTION("product identity remains part of the frozen proposal binding") {
    production.product_identity = "raw-product-q0-tail-build-b";
    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code == "oracle_product_mismatch");
  }
}

TEST_CASE("C26 finite comparison semantics cannot be erased by omission",
          "[c26][negative][conformance][finite-semantics]") {
  ComparisonContract contract = law_contract(ArtifactDomain::invariant_law);
  contract.finite_model_comparison = true;
  auto oracle = oracle_artifact(
      contract.domain, ExactLawArtifact{{{"finite-state", r(1)}}});
  auto production = production_artifact(
      contract.domain, ExactLawArtifact{{{"finite-state", r(1)}}});

  auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_finite_semantics_missing");
  CHECK_FALSE(report.finite_semantics.has_value());

  oracle.finite_semantics = FiniteModelSemantics::capped_with_drops;
  production.finite_semantics = FiniteModelSemantics::capped_with_drops;
  report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.message);
  CHECK(report.conformant);
  REQUIRE(report.finite_semantics.has_value());
  CHECK(*report.finite_semantics ==
        FiniteModelSemantics::capped_with_drops);

  production.finite_semantics.reset();
  report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_finite_semantics_missing");
  REQUIRE(report.finite_semantics.has_value());
  CHECK(*report.finite_semantics ==
        FiniteModelSemantics::capped_with_drops);

  production.finite_semantics = FiniteModelSemantics::capped_with_blocking;
  report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_semantics_mismatch");
  REQUIRE(report.finite_semantics.has_value());
  CHECK(*report.finite_semantics ==
        FiniteModelSemantics::capped_with_drops);
}

TEST_CASE("C26 physical-bound comparison binds a certificate identity",
          "[c26][negative][conformance][physical-bound]") {
  const auto anchor = validated_physical_anchor();
  auto certificate =
      mwperf_oracle::bind_validated_c25_physical_fidelity(anchor);
  REQUIRE(certificate);

  ComparisonContract contract;
  contract.arithmetic = ArithmeticMode::distributional_identity;
  contract.domain = ArtifactDomain::scalar_metric;
  contract.scope = ScientificScope::physical_bound;
  contract.projection_identity = "sha256:" + anchor.metric_identity().hex();

  OracleArtifact oracle =
      oracle_artifact(contract.domain, ExactVectorArtifact{{r(1, 3)}});
  ProductionArtifact production =
      production_artifact(contract.domain, ExactVectorArtifact{{r(1, 3)}});
  oracle.scope = contract.scope;
  production.scope = contract.scope;
  oracle.projection_identity = contract.projection_identity;
  production.projection_identity = contract.projection_identity;
  oracle.product_identity =
      "sha256:" + anchor.subject_product_identity().hex();
  production.product_identity =
      "sha256:" + anchor.physical_reference_law_identity().hex();
  oracle.explicit_physical_bound_certificate = true;
  production.explicit_physical_bound_certificate = true;

  auto report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_physical_bound_certificate_missing");

  oracle.explicit_physical_bound_certificate = certificate.value();
  production.explicit_physical_bound_certificate = certificate.value();
  report = mwperf_oracle::oracle_compare_production(
      oracle, production, contract);
  INFO(report.message);
  CHECK(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);

  SECTION("a copied certificate cannot survive projection relabelling") {
    contract.projection_identity = "relabelled-projection";
    oracle.projection_identity = contract.projection_identity;
    production.projection_identity = contract.projection_identity;

    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code ==
          "oracle_physical_bound_certificate_binding_mismatch");
  }

  SECTION("a copied certificate cannot survive domain relabelling") {
    contract.domain = ArtifactDomain::physical_path;
    oracle.domain = contract.domain;
    production.domain = contract.domain;

    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code ==
          "oracle_physical_bound_certificate_binding_mismatch");
  }

  SECTION("a copied certificate cannot survive source-product relabelling") {
    oracle.product_identity = "relabelled-source-product";

    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code ==
          "oracle_physical_bound_certificate_binding_mismatch");
  }

  SECTION(
      "a copied certificate cannot survive destination-product relabelling") {
    production.product_identity = "relabelled-destination-product";

    report = mwperf_oracle::oracle_compare_production(
        oracle, production, contract);
    CHECK_FALSE(report.conformant);
    CHECK(report.code ==
          "oracle_physical_bound_certificate_binding_mismatch");
  }
}

TEST_CASE("C26 physical and surrogate comparisons remain separate scopes",
          "[c26][integration][conformance][scope-firewall]") {
  const auto make_pair = [](const ScientificScope scope,
                            const std::string& atom) {
    OracleArtifact oracle;
    oracle.domain = ArtifactDomain::invariant_law;
    oracle.scope = scope;
    oracle.projection_identity = "c26-scope-projection";
    oracle.product_identity = "oracle-scope-product";
    oracle.payload = ExactLawArtifact{{{atom, r(1)}}};

    ProductionArtifact production;
    production.domain = oracle.domain;
    production.scope = scope;
    production.projection_identity = oracle.projection_identity;
    production.product_identity = "production-scope-product";
    production.payload = ExactLawArtifact{{{atom, r(1)}}};
    return std::pair{std::move(oracle), std::move(production)};
  };

  ComparisonContract contract;
  contract.arithmetic = ArithmeticMode::exact_projected_law;
  contract.domain = ArtifactDomain::invariant_law;
  contract.projection_identity = "c26-scope-projection";

  auto [physical_oracle, physical_production] =
      make_pair(ScientificScope::physical_model, "physical-state");
  contract.scope = ScientificScope::physical_model;
  auto report = mwperf_oracle::oracle_compare_production(
      physical_oracle, physical_production, contract);
  INFO(report.message);
  CHECK(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);

  auto [surrogate_oracle, surrogate_production] =
      make_pair(ScientificScope::surrogate_law, "surrogate-state");
  contract.scope = ScientificScope::surrogate_law;
  report = mwperf_oracle::oracle_compare_production(
      surrogate_oracle, surrogate_production, contract);
  INFO(report.message);
  CHECK(report.conformant);
  CHECK_FALSE(report.physical_fidelity_inferred);

  // Both internally conformant reports remain valid even though their laws
  // deliberately disagree.  Relabelling one scope as the other is rejected
  // before any numerical comparison and cannot become fidelity evidence.
  report = mwperf_oracle::oracle_compare_production(
      physical_oracle, surrogate_production, contract);
  CHECK_FALSE(report.conformant);
  CHECK(report.code == "oracle_scope_mismatch");
  CHECK_FALSE(report.physical_fidelity_inferred);
}
