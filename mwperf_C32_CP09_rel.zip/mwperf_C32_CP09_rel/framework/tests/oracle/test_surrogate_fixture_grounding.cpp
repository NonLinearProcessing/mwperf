#include <array>
#include <cstddef>
#include <cstdint>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c15/mode_erased_law_projection.hpp"
#include "mwperf_oracle/full_state_oracle.hpp"
#include "support/c16_designated_payload_fixture.hpp"

namespace {

using mwperf_oracle::BigInt;
using mwperf_oracle::Rational;
using mwperf_oracle::ScalarCoefficientBin;
using mwperf_oracle::ScalarCoefficientEvidence;
using mwperf_oracle::ScalarCoefficientStage;
using mwperf_oracle::ScalarMetricCapabilityReason;
using mwperf_oracle::ScalarMetricRequestKind;
using mwperf_oracle::ScalarObservationSource;
using mwperf_oracle::ScalarPopulationConditioningStatus;
using mwperf_oracle::ScalarProducerMode;
using mwperf_oracle::ScalarProposalAsymptoticPremise;
using mwperf_oracle::ScalarProposalBand;
using mwperf_oracle::ScalarProposalBandScope;
using mwperf_oracle::ScalarProposalBankDependence;
using mwperf_oracle::ScalarProposalCoverage;
using mwperf_oracle::ScalarRawValueStatus;
using mwperf_oracle::ScalarResponseFixture;
using mwperf_oracle::ScalarResponseFixtureBindingContract;
using mwperf_oracle::ScientificScope;
using mwperf_oracle::ThreeBinScalarResponse;

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto value = Rational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] std::string bin_name(const std::size_t bin) {
  static constexpr std::array<const char*, 3U> kNames{
      "one", "two", "tail-from-three"};
  return kNames.at(bin);
}

[[nodiscard]] ThreeBinScalarResponse common_response() {
  return {r(3, 4), r(1, 4), r(2, 3)};
}

[[nodiscard]] Rational oracle_r(const mwperf::ExactRational& value) {
  auto converted = Rational::make(value.numerator(), value.denominator());
  REQUIRE(converted);
  return std::move(converted).value();
}

// Produce the released C15 test-only projection through its real issuer.  C26
// consumes this value; it does not define or extend a second projection.
[[nodiscard]] mwperf::testing::ModeErasedLawProjectionV1
c15_mode_erased_projection(
    const std::array<mwperf::PortableScientificScalar, 3U>& values) {
  using Stage = mwperf::testing::C16DesignatedResponseStageV1;
  auto scenario =
      mwperf::testing::make_c16_designated_scenario_v1(Stage::recoded);
  auto response = mwperf::testing::make_c16_designated_response_v1(
      scenario,
      mwperf::testing::c16_designated_payload_options_v1(Stage::recoded));
  REQUIRE(response.nominal_response.has_value());
  REQUIRE(response.recoded_response.has_value());
  for (std::size_t index = 0U; index < values.size(); ++index) {
    response.raw_response.identifications[index].raw_point = values[index];
    response.nominal_response->coefficients[index].value = values[index];
    response.recoded_response->coefficients[index].value = values[index];
  }
  auto artifact = mwperf::testing::rebuild_c16_designated_artifact_v1(
      scenario, std::move(response));
  auto validated =
      mwperf::testing::validate_and_adapt_c16_designated_artifact_v1(
          scenario, artifact);
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  auto projection = mwperf::testing::make_mode_erased_law_projection_v1(
      validated.value().artifact, scenario.request, scenario.contract);
  INFO((projection ? std::string{}
                   : projection.error().code + ": " +
                         projection.error().message));
  REQUIRE(projection);
  return std::move(projection).value();
}

[[nodiscard]] mwperf::testing::ModeErasedLawProjectionV1
common_c15_mode_erased_projection() {
  return c15_mode_erased_projection(
      {mwperf::testing::c16_designated_detail::scalar(3, 4),
       mwperf::testing::c16_designated_detail::scalar(1, 4),
       mwperf::testing::c16_designated_detail::scalar(2, 3)});
}

void require_matches_c15_projection(
    const mwperf_oracle::ValidatedScalarResponseFixture& fixture,
    const mwperf::testing::ModeErasedLawProjectionV1& projection) {
  REQUIRE(projection.projection_version == 1U);
  REQUIRE(projection.deployed_law.payload_family_tag ==
          mwperf::PayloadClassTagV1::three_bin_scalar_response_v1);
  REQUIRE(projection.deployed_law.semantic_tag ==
          mwperf::SemanticTagV1::scalar_backlog_response);
  REQUIRE(projection.deployed_law.mathematical_state_domain ==
          mwperf::testing::ModeErasedStateDomainV1::
              nonnegative_integer_singleton_backlog);
  REQUIRE(projection.deployed_law.target_relative_state_and_mark_convention ==
          mwperf::testing::ModeErasedTargetConventionV1::
              selected_target_relative_three_bins);
  REQUIRE(projection.deployed_law.service_randomization_convention ==
          mwperf::testing::ModeErasedServiceRandomizationV1::
              independent_fresh_uniform_given_current_backlog);
  REQUIRE(projection.timing_convention.decision_service_arrival_order ==
          mwperf::TimingConvention::early_service_late_admission);
  // The designated C15 carrier deliberately has no configured arrivals.
  // C26 composes the validated phase-free response with its independently
  // declared Bernoulli or temporal arrival fixture after this projection.
  REQUIRE(projection.configured_arrival_math.predictive_phase_semantics ==
          mwperf::ConfiguredArrivalCompositionV1::no_arrival_composition);
  const auto& parameters =
      projection.deployed_law.canonical_law_parameters;
  REQUIRE(parameters[0U].is_zero());
  CHECK(fixture.response.s1 == oracle_r(parameters[1U]));
  CHECK(fixture.response.s2 == oracle_r(parameters[2U]));
  CHECK(fixture.response.tail == oracle_r(parameters[3U]));
}

void bind_stationary_conditioning_from_oracle(
    ScalarResponseFixture& fixture, const Rational& arrival_probability,
    std::string arrival_binding, std::string stationary_law_identity) {
  auto law = mwperf_oracle::oracle_solve_three_bin_bernoulli(
      fixture.deployed.response, arrival_probability);
  REQUIRE(law);
  auto tail_mass = checked_divide(
      law.value().pi3, Rational::one() - law.value().tail_ratio);
  REQUIRE(tail_mass);
  fixture.configured_arrival_binding = std::move(arrival_binding);
  fixture.deployed_stationary_conditioning =
      mwperf_oracle::ScalarDeployedStationaryConditioning{
          std::move(stationary_law_identity), "stationary.unique",
          fixture.deployed.product_identity,
          {std::optional<Rational>{law.value().pi1},
           std::optional<Rational>{law.value().pi2},
           std::optional<Rational>{std::move(tail_mass).value()}}};
}

[[nodiscard]] ScalarResponseFixture make_fixture(
    const std::string& profile, const bool sampling,
    const ScalarProducerMode producer_mode) {
  ScalarResponseFixture fixture;
  fixture.provider_identity = "provider." + profile;
  fixture.construction_method_identity =
      sampling ? "sampling-constructed" : "engineered";
  fixture.producer_mode = producer_mode;
  fixture.request_identity = "request." + profile;
  fixture.artifact_identity = "artifact." + profile;
  fixture.plug_identity = "plug." + profile;
  fixture.descriptor_identity = "descriptor." + profile;
  fixture.runtime_target = "queue.target";
  fixture.request_target = "queue.target";
  fixture.deployed_targets = {"queue.target"};
  fixture.configured_arrival_binding = "arrival.bernoulli.one-quarter";
  fixture.frozen_build_identity = "build." + profile;
  fixture.raw_product_identity = "raw-product." + profile;
  fixture.scientific_scope = ScientificScope::surrogate_law;
  fixture.proposal_bank_dependence =
      sampling ? ScalarProposalBankDependence::serial_non_iid
               : ScalarProposalBankDependence::not_applicable;
  fixture.deployed.response = common_response();
  fixture.projection_center =
      mwperf_oracle::ScalarProjectionCenterProduct{
          "projection-center." + profile,
          {"queue.target", "queue.calibration"}, {r(1, 2), r(3, 4)},
          fixture.raw_product_identity};
  fixture.projected_mean = mwperf_oracle::ScalarProjectedMeanProduct{
      "projected-mean." + profile,
      fixture.projection_center->ordered_construction_targets,
      {r(7, 16), r(11, 16)}, fixture.projection_center->product_identity};
  fixture.metric_capabilities = {
      mwperf_oracle::ScalarMetricBackendKind::iid_scalar_analytic,
      "backend.iid-three-bin",
      {ScalarMetricRequestKind::stationary_mean_backlog,
       ScalarMetricRequestKind::stationary_mean_departures,
       ScalarMetricRequestKind::backlog_conditioned_service}};

  const std::array<Rational, 3U> values{
      fixture.deployed.response.s1, fixture.deployed.response.s2,
      fixture.deployed.response.tail};
  for (std::size_t index = 0U; index < fixture.coefficients.size(); ++index) {
    ScalarCoefficientEvidence coefficient;
    coefficient.bin = static_cast<ScalarCoefficientBin>(index);
    coefficient.observation_source =
        sampling ? ScalarObservationSource::empirical_average
                 : ScalarObservationSource::exact_population;
    coefficient.population_conditioning =
        sampling
            ? ScalarPopulationConditioningStatus::positive_with_confidence
            : ScalarPopulationConditioningStatus::proved_positive;
    coefficient.raw_value_status =
        sampling ? ScalarRawValueStatus::interval_only
                 : ScalarRawValueStatus::exact_point;
    coefficient.raw_point = sampling ? std::nullopt
                                     : std::optional<Rational>{values[index]};
    coefficient.proposal_band =
        sampling
            ? std::optional<ScalarProposalBand>{ScalarProposalBand{
                  r(0), r(1), ScalarProposalBandScope::proposal_raw,
                  "raw-product." + profile, "build." + profile,
                  "band-evidence." + profile + "." + bin_name(index),
                  ScalarProposalAsymptoticPremise::dependence_adjusted,
                  ScalarProposalCoverage::simultaneous,
                  "simultaneous-allocation." + profile, 3U}}
            : std::nullopt;
    coefficient.evidence_identity =
        "coefficient-evidence." + profile + "." + bin_name(index);
    coefficient.frozen_build_identity = "build." + profile;
    coefficient.source_product_identity = "raw-product." + profile;
    fixture.coefficients[index] = std::move(coefficient);
  }

  if (sampling) {
    fixture.recoded_product_identity = "recoded-product." + profile;
    fixture.deployed.stage = ScalarCoefficientStage::recoded_response;
    fixture.deployed.product_identity = *fixture.recoded_product_identity;
    fixture.deployed.completion_identity = "completion." + profile;
    fixture.deployed.recoding_identity = "recoding." + profile;
  } else {
    fixture.deployed.stage = ScalarCoefficientStage::raw_response;
    fixture.deployed.product_identity = fixture.raw_product_identity;
  }
  bind_stationary_conditioning_from_oracle(
      fixture, r(1, 4), "arrival.bernoulli.one-quarter",
      "stationary-law." + profile);
  return fixture;
}

[[nodiscard]] ScalarResponseFixtureBindingContract contract_for(
    const ScalarResponseFixture& fixture) {
  ScalarResponseFixtureBindingContract contract;
  contract.expected_provider_identity = fixture.provider_identity;
  contract.expected_construction_method_identity =
      fixture.construction_method_identity;
  contract.expected_producer_mode = fixture.producer_mode;
  contract.expected_request_identity = fixture.request_identity;
  contract.expected_artifact_identity = fixture.artifact_identity;
  contract.expected_plug_identity = fixture.plug_identity;
  contract.expected_descriptor_identity = fixture.descriptor_identity;
  contract.expected_runtime_target = fixture.runtime_target;
  contract.expected_configured_arrival_binding =
      fixture.configured_arrival_binding;
  contract.expected_frozen_build_identity = fixture.frozen_build_identity;
  contract.expected_raw_product_identity = fixture.raw_product_identity;
  contract.expected_deployed_product_identity =
      fixture.deployed.product_identity;
  contract.expected_deployed_response = fixture.deployed.response;
  contract.expected_proposal_bank_dependence =
      fixture.proposal_bank_dependence;
  for (std::size_t index = 0U; index < fixture.coefficients.size(); ++index) {
    contract.expected_coefficient_evidence_identity[index] =
        fixture.coefficients[index].evidence_identity;
    if (fixture.coefficients[index].proposal_band.has_value()) {
      contract.expected_proposal_band_evidence_identity[index] =
          fixture.coefficients[index].proposal_band->evidence_identity;
      contract.expected_proposal_bands[index] =
          fixture.coefficients[index].proposal_band;
    }
  }
  contract.expected_completion_identity =
      fixture.deployed.completion_identity;
  contract.expected_recoding_identity = fixture.deployed.recoding_identity;
  contract.expected_projection_center = fixture.projection_center;
  contract.expected_projected_mean = fixture.projected_mean;
  contract.expected_metric_capabilities = fixture.metric_capabilities;
  contract.expected_deployed_stationary_conditioning =
      fixture.deployed_stationary_conditioning;
  contract.expected_scope = ScientificScope::surrogate_law;
  return contract;
}

void require_failure(const ScalarResponseFixture& fixture,
                     const ScalarResponseFixtureBindingContract& contract,
                     const std::string& code) {
  const auto result = mwperf_oracle::oracle_validate_scalar_response_fixture(
      fixture, contract);
  REQUIRE_FALSE(result);
  CHECK(result.error().code == code);
}

[[nodiscard]] bool bound_stationary_bin_supports_conditioned_service(
    const mwperf_oracle::ValidatedScalarResponseFixture& fixture,
    const std::size_t bin, const std::string& stationary_law_identity,
    const std::string& selection_identity) {
  if (!fixture.deployed_stationary_conditioning.has_value() || bin >= 3U) {
    return false;
  }
  const auto& conditioning =
      *fixture.deployed_stationary_conditioning;
  return conditioning.stationary_law_identity == stationary_law_identity &&
         conditioning.selection_identity == selection_identity &&
         conditioning.deployed_response_product_identity ==
             fixture.deployed_product_identity &&
         conditioning.bin_mass[bin].has_value() &&
         conditioning.bin_mass[bin]->is_positive();
}

}  // namespace

TEST_CASE("C26 six synthetic profiles share only their phase-free law",
          "[c26][integration][surrogate]") {
  const auto c15_projection = common_c15_mode_erased_projection();
  // Consume the six released C16 synthetic profile identities directly.
  // Their provider algorithms are deliberately not reimplemented here;
  // C26 exercises the common emitted wire/law boundary.
  const std::array<std::size_t, 6U> profile_indices{4U, 5U, 6U,
                                                   7U, 8U, 9U};

  std::set<std::string> providers;
  std::set<std::string> requests;
  std::set<std::string> artifacts;
  std::set<std::string> raw_products;
  std::set<std::string> deployed_products;
  std::set<std::string> projection_centers;
  std::set<std::string> projected_means;
  std::set<std::string> plugs;
  std::set<std::string> descriptors;
  std::set<std::string> evidence;
  for (const std::size_t profile_index : profile_indices) {
    const auto& profile = mwperf::testing::kC16TestProfiles[profile_index];
    CAPTURE(profile.provider_id);
    const bool sampling = profile.construction_method ==
                          mwperf::ConstructionMethodV1::sampled_offline;
    auto provider_id =
        mwperf::SurrogateId::parse(std::string(profile.provider_id));
    REQUIRE(provider_id);
    auto provider = mwperf::lookup_surrogate_provider(provider_id.value());
    REQUIRE(provider);
    const auto& manifest = provider.value().manifest().value();
    CHECK(manifest.provider.provider_id == profile.provider_id);
    CHECK(manifest.construction_method == profile.construction_method);
    const auto& pairs = manifest.optimizer_constraint_applicability
                            .scheduler_optimizer_pairs;
    REQUIRE(pairs.size() == 1U);
    CHECK(pairs.front().service_family == profile.family);
    CHECK(pairs.front().optimizer == profile.optimizer);

    ScalarResponseFixture fixture = make_fixture(
        std::string(profile.provider_id), sampling,
        ScalarProducerMode::in_process_builder);
    fixture.provider_identity = std::string(profile.provider_id);
    const auto validated =
        mwperf_oracle::oracle_validate_scalar_response_fixture(
            fixture, contract_for(fixture));
    INFO((validated ? std::string{} : validated.error().message));
    REQUIRE(validated);

    require_matches_c15_projection(validated.value(), c15_projection);
    REQUIRE(validated.value().projection_center.has_value());
    REQUIRE(validated.value().projected_mean.has_value());
    CHECK(validated.value().projection_center == fixture.projection_center);
    CHECK(validated.value().projected_mean == fixture.projected_mean);
    CHECK(validated.value().projection_center->product_identity !=
          fixture.raw_product_identity);
    CHECK(validated.value().projected_mean->product_identity !=
          validated.value().projection_center->product_identity);
    CHECK(validated.value().projection_center->ordered_construction_targets
              .size() == 2U);
    CHECK(fixture.deployed_targets.size() == 1U);
    CHECK(validated.value().response.s1 == r(3, 4));
    CHECK(validated.value().response.s2 == r(1, 4));
    CHECK(validated.value().response.tail == r(2, 3));
    auto stationary = mwperf_oracle::oracle_solve_three_bin_bernoulli(
        validated.value().response, r(1, 4));
    REQUIRE(stationary);
    CHECK(stationary.value().mean_backlog == r(23, 40));

    providers.insert(fixture.provider_identity);
    requests.insert(fixture.request_identity);
    artifacts.insert(fixture.artifact_identity);
    raw_products.insert(fixture.raw_product_identity);
    deployed_products.insert(fixture.deployed.product_identity);
    projection_centers.insert(fixture.projection_center->product_identity);
    projected_means.insert(fixture.projected_mean->product_identity);
    plugs.insert(fixture.plug_identity);
    descriptors.insert(fixture.descriptor_identity);
    evidence.insert(fixture.coefficients.front().evidence_identity);
  }
  CHECK(providers.size() == profile_indices.size());
  CHECK(requests.size() == profile_indices.size());
  CHECK(artifacts.size() == profile_indices.size());
  CHECK(raw_products.size() == profile_indices.size());
  CHECK(deployed_products.size() == profile_indices.size());
  CHECK(projection_centers.size() == profile_indices.size());
  CHECK(projected_means.size() == profile_indices.size());
  CHECK(plugs.size() == profile_indices.size());
  CHECK(descriptors.size() == profile_indices.size());
  CHECK(evidence.size() == profile_indices.size());
}

TEST_CASE("C26 three producer modes preserve mathematical equality and identity",
          "[c26][property][surrogate]") {
  const auto c15_projection = common_c15_mode_erased_projection();
  const std::array<ScalarProducerMode, 3U> modes{
      ScalarProducerMode::inline_immediate,
      ScalarProducerMode::in_process_builder,
      ScalarProducerMode::local_executable_builder};
  std::set<ScalarProducerMode> observed_modes;
  std::set<std::string> identity_tuples;
  for (std::size_t index = 0U; index < modes.size(); ++index) {
    const std::string profile = "mode-fixture." + std::to_string(index);
    const ScalarResponseFixture fixture =
        make_fixture(profile, false, modes[index]);
    auto validated = mwperf_oracle::oracle_validate_scalar_response_fixture(
        fixture, contract_for(fixture));
    REQUIRE(validated);
    require_matches_c15_projection(validated.value(), c15_projection);
    CHECK(validated.value().response.s1 == r(3, 4));
    CHECK(validated.value().response.s2 == r(1, 4));
    CHECK(validated.value().response.tail == r(2, 3));
    observed_modes.insert(fixture.producer_mode);
    identity_tuples.insert(
        fixture.provider_identity + "|" + fixture.request_identity + "|" +
        fixture.artifact_identity + "|" + fixture.raw_product_identity +
        "|" + fixture.plug_identity + "|" + fixture.descriptor_identity +
        "|" + fixture.coefficients.front().evidence_identity);
  }
  CHECK(observed_modes.size() == modes.size());
  CHECK(identity_tuples.size() == modes.size());
}

TEST_CASE("C26 three producer modes share the constant half-service law",
          "[c26][integration][surrogate][c19-carrier]") {
  const auto projection = c15_mode_erased_projection(
      {mwperf::testing::c16_designated_detail::scalar(1, 2),
       mwperf::testing::c16_designated_detail::scalar(1, 2),
       mwperf::testing::c16_designated_detail::scalar(1, 2)});
  const std::array<ScalarProducerMode, 3U> modes{
      ScalarProducerMode::inline_immediate,
      ScalarProducerMode::in_process_builder,
      ScalarProducerMode::local_executable_builder};
  std::set<std::string> identities;
  for (std::size_t index = 0U; index < modes.size(); ++index) {
    auto fixture = make_fixture("constant-half-mode." +
                                    std::to_string(index),
                                false, modes[index]);
    fixture.deployed.response = {r(1, 2), r(1, 2), r(1, 2)};
    for (auto& coefficient : fixture.coefficients) {
      coefficient.raw_point = r(1, 2);
    }
    bind_stationary_conditioning_from_oracle(
        fixture, r(1, 4), "arrival.bernoulli.one-quarter",
        "stationary-law.constant-half." + std::to_string(index));
    auto validated = mwperf_oracle::oracle_validate_scalar_response_fixture(
        fixture, contract_for(fixture));
    REQUIRE(validated);
    require_matches_c15_projection(validated.value(), projection);
    auto law = mwperf_oracle::oracle_solve_three_bin_bernoulli(
        validated.value().response, r(1, 4));
    REQUIRE(law);
    CHECK(law.value().pi0 == r(1, 2));
    CHECK(law.value().probability(1U) == r(1, 3));
    CHECK(law.value().probability(2U) == r(1, 9));
    CHECK(law.value().mean_backlog == r(3, 4));
    CHECK(law.value().mean_departures == r(1, 4));
    identities.insert(
        fixture.provider_identity + "|" + fixture.request_identity + "|" +
        fixture.artifact_identity + "|" + fixture.deployed.product_identity +
        "|" + fixture.plug_identity + "|" + fixture.descriptor_identity);
  }
  CHECK(identities.size() == modes.size());
}

TEST_CASE("C26 raw nominal and recoded coefficient stages stay typed",
          "[c26][unit][surrogate]") {
  const auto raw = make_fixture("stage.raw", false,
                                ScalarProducerMode::inline_immediate);
  auto raw_validated = mwperf_oracle::oracle_validate_scalar_response_fixture(
      raw, contract_for(raw));
  REQUIRE(raw_validated);
  CHECK(raw_validated.value().deployed_stage ==
        ScalarCoefficientStage::raw_response);

  auto nominal = make_fixture("stage.nominal", true,
                              ScalarProducerMode::in_process_builder);
  nominal.nominal_product_identity = "nominal-product.stage.nominal";
  nominal.recoded_product_identity = std::nullopt;
  nominal.deployed.stage = ScalarCoefficientStage::nominal_response;
  nominal.deployed.product_identity = *nominal.nominal_product_identity;
  nominal.deployed.recoding_identity = std::nullopt;
  nominal.deployed_stationary_conditioning
      ->deployed_response_product_identity = nominal.deployed.product_identity;
  // An exact population-zero/absent proposal origin is a valid retained
  // status, but only the separately authorized nominal completion deploys.
  nominal.coefficients.front().observation_source =
      ScalarObservationSource::exact_population;
  nominal.coefficients.front().population_conditioning =
      ScalarPopulationConditioningStatus::proved_zero;
  nominal.coefficients.front().raw_value_status = ScalarRawValueStatus::absent;
  nominal.coefficients.front().proposal_band = std::nullopt;
  auto nominal_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          nominal, contract_for(nominal));
  REQUIRE(nominal_validated);
  CHECK(nominal_validated.value().deployed_stage ==
        ScalarCoefficientStage::nominal_response);
  CHECK(nominal_validated.value().proposal_conditioning.front() ==
        ScalarPopulationConditioningStatus::proved_zero);

  const auto recoded = make_fixture(
      "stage.recoded", true, ScalarProducerMode::local_executable_builder);
  auto recoded_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          recoded, contract_for(recoded));
  REQUIRE(recoded_validated);
  CHECK(recoded_validated.value().deployed_stage ==
        ScalarCoefficientStage::recoded_response);
  CHECK(recoded_validated.value().response.s1 ==
        nominal_validated.value().response.s1);
}

TEST_CASE("C26 scalar metric capability reasons never strengthen the payload",
          "[c26][negative][surrogate][capability]") {
  const auto fixture = make_fixture(
      "capability.scalar", false, ScalarProducerMode::inline_immediate);
  auto validated = mwperf_oracle::oracle_validate_scalar_response_fixture(
      fixture, contract_for(fixture));
  REQUIRE(validated);

  const auto accepted = mwperf_oracle::oracle_scalar_fixture_metric_capability(
      validated.value(), ScalarMetricRequestKind::stationary_mean_backlog);
  CHECK(accepted.supported);
  CHECK(accepted.reason == ScalarMetricCapabilityReason::supported);

  const std::array<std::pair<ScalarMetricRequestKind,
                             ScalarMetricCapabilityReason>,
                   5U>
      unsupported{{
          {ScalarMetricRequestKind::joint_schedule,
           ScalarMetricCapabilityReason::
               joint_schedule_not_in_scalar_contract},
          {ScalarMetricRequestKind::cross_target_law,
           ScalarMetricCapabilityReason::
               cross_target_law_not_in_scalar_contract},
          {ScalarMetricRequestKind::lagged_correlation,
           ScalarMetricCapabilityReason::
               lagged_correlation_not_in_scalar_contract},
          {ScalarMetricRequestKind::arbitrary_queue_tail,
           ScalarMetricCapabilityReason::arbitrary_tail_not_in_scalar_contract},
          {ScalarMetricRequestKind::physical_fifo_delay,
           ScalarMetricCapabilityReason::physical_fifo_not_in_scalar_contract},
      }};
  for (const auto& [request, reason] : unsupported) {
    const auto decision =
        mwperf_oracle::oracle_scalar_fixture_metric_capability(
            validated.value(), request);
    CHECK_FALSE(decision.supported);
    CHECK(decision.reason == reason);
  }

  auto narrowed = fixture;
  narrowed.metric_capabilities.supported_requests.pop_back();
  auto narrowed_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          narrowed, contract_for(narrowed));
  REQUIRE(narrowed_validated);
  const auto undeclared =
      mwperf_oracle::oracle_scalar_fixture_metric_capability(
          narrowed_validated.value(),
          ScalarMetricRequestKind::backlog_conditioned_service);
  CHECK_FALSE(undeclared.supported);
  CHECK(undeclared.reason ==
        ScalarMetricCapabilityReason::request_not_declared);
}

TEST_CASE("C26 scalar fixture binding mutations fail at their typed boundary",
          "[c26][negative][surrogate]") {
  const ScalarResponseFixture valid = make_fixture(
      "mwis.sampling", true, ScalarProducerMode::in_process_builder);
  const ScalarResponseFixtureBindingContract contract = contract_for(valid);
  REQUIRE(mwperf_oracle::oracle_validate_scalar_response_fixture(valid,
                                                                  contract));

  SECTION("singleton runtime target") {
    auto mutated = valid;
    mutated.runtime_target = "queue.other";
    require_failure(mutated, contract, "oracle_scalar_target_binding");
    mutated = valid;
    mutated.deployed_targets.push_back("queue.other");
    require_failure(mutated, contract, "oracle_scalar_target_binding");
  }
  SECTION("configured arrival") {
    auto mutated = valid;
    mutated.configured_arrival_binding = "arrival.iid-marginal-replay";
    require_failure(mutated, contract, "oracle_scalar_arrival_binding");
  }
  SECTION("identity-bearing fixture context") {
    auto mutated = valid;
    mutated.provider_identity = "provider.other";
    require_failure(mutated, contract, "oracle_scalar_identity_binding");
    mutated = valid;
    mutated.construction_method_identity = "engineered";
    require_failure(mutated, contract,
                    "oracle_scalar_construction_binding");
    mutated = valid;
    mutated.producer_mode = ScalarProducerMode::local_executable_builder;
    require_failure(mutated, contract,
                    "oracle_scalar_producer_mode_binding");
  }
  SECTION("frozen build") {
    auto mutated = valid;
    mutated.coefficients.front().frozen_build_identity = "build.other";
    require_failure(mutated, contract, "oracle_scalar_build_binding");
    mutated = valid;
    mutated.coefficients.front().proposal_band->frozen_build_identity =
        "build.other";
    require_failure(mutated, contract, "oracle_scalar_build_binding");
  }
  SECTION("raw and deployed products") {
    auto mutated = valid;
    mutated.coefficients.front().source_product_identity = "raw-product.other";
    require_failure(mutated, contract, "oracle_scalar_product_binding");
    mutated = valid;
    mutated.deployed.product_identity = "recoded-product.other";
    require_failure(mutated, contract, "oracle_scalar_product_binding");
    mutated = valid;
    mutated.coefficients.front().proposal_band->source_product_identity =
        "raw-product.other";
    require_failure(mutated, contract, "oracle_scalar_product_binding");
  }
  SECTION("evidence references") {
    auto mutated = valid;
    mutated.coefficients.front().evidence_identity = "evidence.other";
    require_failure(mutated, contract, "oracle_scalar_evidence_binding");
    mutated = valid;
    mutated.coefficients.front().proposal_band->evidence_identity =
        "band-evidence.other";
    require_failure(mutated, contract, "oracle_scalar_evidence_binding");
  }
  SECTION("surrogate and proposal scopes") {
    auto mutated = valid;
    mutated.scientific_scope = ScientificScope::physical_bound;
    require_failure(mutated, contract, "oracle_scalar_scope_binding");
    mutated = valid;
    mutated.coefficients.front().proposal_band->scope =
        ScalarProposalBandScope::physical_bound;
    require_failure(mutated, contract, "oracle_scalar_scope_binding");
  }
  SECTION("serial proposal banks cannot advertise IID LLN coverage") {
    auto mutated = valid;
    mutated.coefficients.front().proposal_band->asymptotic_premise =
        ScalarProposalAsymptoticPremise::iid_lln;
    require_failure(mutated, contract, "oracle_scalar_dependence_claim");
  }
  SECTION("simultaneous coverage retains its allocation") {
    auto mutated = valid;
    mutated.coefficients.front()
        .proposal_band->simultaneous_allocation_identity = std::nullopt;
    require_failure(mutated, contract,
                    "oracle_scalar_simultaneous_allocation");
    mutated = valid;
    mutated.coefficients.front().proposal_band->coverage =
        ScalarProposalCoverage::marginal;
    mutated.coefficients.front()
        .proposal_band->simultaneous_allocation_identity = std::nullopt;
    mutated.coefficients.front().proposal_band->simultaneous_family_size = 0U;
    require_failure(mutated, contract, "oracle_scalar_band_binding");
  }
  SECTION("mean-stage products are not coefficients") {
    auto mutated = valid;
    mutated.deployed.stage = ScalarCoefficientStage::projection_center;
    require_failure(mutated, contract, "oracle_scalar_mean_stage_product");
    mutated = valid;
    mutated.deployed.stage = ScalarCoefficientStage::projected_mean;
    require_failure(mutated, contract, "oracle_scalar_mean_stage_product");
  }
  SECTION("empirical zero is never a population proof") {
    auto mutated = valid;
    mutated.coefficients.front().population_conditioning =
        ScalarPopulationConditioningStatus::proved_zero;
    mutated.coefficients.front().raw_value_status =
        ScalarRawValueStatus::absent;
    mutated.coefficients.front().proposal_band = std::nullopt;
    require_failure(mutated, contract, "oracle_scalar_empirical_proved_zero");
  }
  SECTION("observation source and population status form a closed tuple") {
    auto mutated = valid;
    mutated.coefficients.front().observation_source =
        ScalarObservationSource::exact_population;
    require_failure(mutated, contract, "oracle_scalar_status_combination");
    mutated = valid;
    mutated.coefficients.front().population_conditioning =
        ScalarPopulationConditioningStatus::proved_positive;
    require_failure(mutated, contract, "oracle_scalar_status_combination");
  }
  SECTION("an interval-only raw response cannot deploy") {
    auto mutated = valid;
    mutated.deployed.stage = ScalarCoefficientStage::raw_response;
    mutated.deployed.product_identity = mutated.raw_product_identity;
    mutated.deployed.completion_identity = std::nullopt;
    mutated.deployed.recoding_identity = std::nullopt;
    auto raw_contract = contract_for(mutated);
    require_failure(mutated, raw_contract,
                    "oracle_scalar_interval_not_deployable");
  }
  SECTION("completion and recoding remain explicit") {
    auto mutated = valid;
    mutated.deployed.completion_identity = std::nullopt;
    require_failure(mutated, contract, "oracle_scalar_completion_binding");
    mutated = valid;
    mutated.deployed.recoding_identity = std::nullopt;
    require_failure(mutated, contract, "oracle_scalar_recoding_binding");
    mutated = valid;
    mutated.deployed.completion_identity = "completion.other";
    require_failure(mutated, contract, "oracle_scalar_completion_binding");
    mutated = valid;
    mutated.deployed.recoding_identity = "recoding.other";
    require_failure(mutated, contract, "oracle_scalar_recoding_binding");
  }
  SECTION("designated raw value remains exact") {
    auto engineered = make_fixture("mwis.engineered", false,
                                   ScalarProducerMode::in_process_builder);
    const auto engineered_contract = contract_for(engineered);
    engineered.coefficients.front().raw_point = r(1, 2);
    require_failure(engineered, engineered_contract,
                    "oracle_scalar_coefficient_value");
  }
  SECTION("every deployed stage binds the exact phase-free triple") {
    auto raw = make_fixture("value.raw", false,
                            ScalarProducerMode::inline_immediate);
    const auto raw_contract = contract_for(raw);
    raw.deployed.response.s1 = r(1, 2);
    require_failure(raw, raw_contract,
                    "oracle_scalar_deployed_value_binding");

    auto nominal = make_fixture("value.nominal", true,
                                ScalarProducerMode::in_process_builder);
    nominal.nominal_product_identity = "nominal-product.value.nominal";
    nominal.recoded_product_identity = std::nullopt;
    nominal.deployed.stage = ScalarCoefficientStage::nominal_response;
    nominal.deployed.product_identity = *nominal.nominal_product_identity;
    nominal.deployed.recoding_identity = std::nullopt;
    nominal.deployed_stationary_conditioning
        ->deployed_response_product_identity =
        nominal.deployed.product_identity;
    const auto nominal_contract = contract_for(nominal);
    nominal.deployed.response.s2 = r(1, 2);
    require_failure(nominal, nominal_contract,
                    "oracle_scalar_deployed_value_binding");

    auto recoded = valid;
    recoded.deployed.response.tail = r(1, 2);
    require_failure(recoded, contract,
                    "oracle_scalar_deployed_value_binding");
  }
  SECTION("stationary conditioning is law selection and product bound") {
    auto mutated = valid;
    mutated.deployed_stationary_conditioning->bin_mass.front() = r(1, 8);
    require_failure(mutated, contract, "oracle_scalar_stationary_binding");
    mutated = valid;
    mutated.deployed_stationary_conditioning
        ->deployed_response_product_identity = "recoded-product.other";
    require_failure(mutated, contract, "oracle_scalar_stationary_binding");
  }
}

TEST_CASE("C26 proposal conditioning and deployed stationary mass are separate",
          "[c26][unit][surrogate]") {
  auto exact = make_fixture("conditioning.exact", false,
                            ScalarProducerMode::inline_immediate);
  bind_stationary_conditioning_from_oracle(
      exact, r(0), "arrival.bernoulli.zero",
      "stationary-law.conditioning.exact.zero");
  auto exact_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          exact, contract_for(exact));
  REQUIRE(exact_validated);
  CHECK(exact_validated.value().proposal_conditioning.front() ==
        ScalarPopulationConditioningStatus::proved_positive);
  CHECK_FALSE(bound_stationary_bin_supports_conditioned_service(
      exact_validated.value(), 0U,
      "stationary-law.conditioning.exact.zero", "stationary.unique"));

  auto unresolved = make_fixture("conditioning.unresolved", true,
                                 ScalarProducerMode::in_process_builder);
  unresolved.coefficients.front().population_conditioning =
      ScalarPopulationConditioningStatus::unresolved;
  auto unresolved_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          unresolved, contract_for(unresolved));
  REQUIRE(unresolved_validated);
  CHECK(unresolved_validated.value().proposal_conditioning.front() ==
        ScalarPopulationConditioningStatus::unresolved);
  CHECK(bound_stationary_bin_supports_conditioned_service(
      unresolved_validated.value(), 0U,
      "stationary-law.conditioning.unresolved", "stationary.unique"));
  CHECK(unresolved_validated.value().response.s1 ==
        exact_validated.value().response.s1);
  CHECK(unresolved_validated.value()
            .coefficient_evidence.front()
            .observation_source == ScalarObservationSource::empirical_average);
  CHECK(unresolved_validated.value()
            .coefficient_evidence.front()
            .raw_value_status == ScalarRawValueStatus::interval_only);
  REQUIRE(unresolved_validated.value()
              .coefficient_evidence.front()
              .proposal_band.has_value());
  CHECK(unresolved_validated.value()
            .coefficient_evidence.front()
            .frozen_build_identity == unresolved.frozen_build_identity);
  CHECK(unresolved_validated.value()
            .coefficient_evidence.front()
            .source_product_identity == unresolved.raw_product_identity);
  CHECK(unresolved_validated.value().completion_identity ==
        unresolved.deployed.completion_identity);
  CHECK(unresolved_validated.value().recoding_identity ==
        unresolved.deployed.recoding_identity);
}

TEST_CASE("C26 exact-zero absence is Unavailable until authorized completion",
          "[c26][integration][surrogate][c15-carrier]") {
  using Stage = mwperf::testing::C16DesignatedResponseStageV1;
  auto scenario =
      mwperf::testing::make_c16_designated_scenario_v1(Stage::nominal);
  const auto build_report =
      mwperf::testing::c16_designated_detail::report(scenario);
  const auto& clause =
      scenario.contract.structural_manifest().clauses().front().clause_id;
  const mwperf::UnavailableSurrogateResultV1 unavailable{
      {1U, scenario.request.request_digest().value(),
       scenario.provider.identity(), build_report},
      {{mwperf::UnavailableReasonKindV1::coefficient_proved_zero,
        "c26.required_coefficient_not_deployable",
        "an exact-population zero origin has no authorized deployed point",
        clause,
        mwperf::testing::c16_designated_detail::object(
            "c26.exact-zero.coefficient")}},
      std::nullopt};
  auto bytes =
      mwperf::artifact::detail::canonical_surrogate_build_result_bytes_v1(
          mwperf::SurrogateBuildResultV1{unavailable});
  REQUIRE(bytes);
  const mwperf::ArtifactParseLimits limits{
      1U << 20U, 64U, 1U << 14U, 1U << 14U,
      1U << 16U, 1U << 16U, 8U << 20U};
  auto parsed =
      mwperf::parse_surrogate_build_result(bytes.value(), limits);
  REQUIRE(parsed);
  auto trusted_report = mwperf::validate_surrogate_build_report(
      parsed.value(), scenario.request, scenario.budget);
  REQUIRE(trusted_report);
  auto validated = mwperf::validate_surrogate_build_result(
      parsed.value(), scenario.request, scenario.manifest, scenario.contract,
      trusted_report.value());
  INFO((validated ? std::string{}
                  : validated.error().code + ": " +
                        validated.error().message));
  REQUIRE(validated);
  const auto* unavailable_terminal =
      std::get_if<mwperf::ValidatedUnavailableResultV1>(
          &validated.value().value());
  REQUIRE(unavailable_terminal != nullptr);
  CHECK(unavailable_terminal->result.reasons == unavailable.reasons);
  CHECK(std::get_if<mwperf::ValidatedBuiltResultV1>(
            &validated.value().value()) == nullptr);
  const auto realized = mwperf::resolve_realized_metric_capabilities(
      validated.value(), scenario.requirements);
  CHECK(std::get_if<mwperf::RealizedUnavailableCapabilitiesV1>(&realized) !=
        nullptr);
  CHECK(std::get_if<mwperf::RealizedBuiltCapabilitiesV1>(&realized) ==
        nullptr);

  // The independent C26 carrier checks the exact-zero completion rule
  // directly: an absent raw coefficient can become a deployed point only
  // through a separately identified nominal product and completion policy.
  auto completed = make_fixture("completion.proved-zero", false,
                                ScalarProducerMode::in_process_builder);
  auto& completed_origin = completed.coefficients.front();
  completed_origin.population_conditioning =
      ScalarPopulationConditioningStatus::proved_zero;
  completed_origin.raw_value_status = ScalarRawValueStatus::absent;
  completed_origin.raw_point = std::nullopt;
  completed.nominal_product_identity =
      "nominal-product.completion.proved-zero";
  completed.deployed.stage = ScalarCoefficientStage::nominal_response;
  completed.deployed.product_identity = *completed.nominal_product_identity;
  completed.deployed.completion_identity =
      "completion-policy.preview-authorized";
  completed.deployed.recoding_identity = std::nullopt;
  completed.deployed_stationary_conditioning
      ->deployed_response_product_identity = completed.deployed.product_identity;
  auto completed_validated =
      mwperf_oracle::oracle_validate_scalar_response_fixture(
          completed, contract_for(completed));
  INFO((completed_validated
            ? std::string{}
            : completed_validated.error().code + ": " +
                  completed_validated.error().message));
  REQUIRE(completed_validated);
  CHECK(completed_validated.value().proposal_conditioning.front() ==
        ScalarPopulationConditioningStatus::proved_zero);
  CHECK(completed_validated.value().deployed_stage ==
        ScalarCoefficientStage::nominal_response);
  CHECK(completed_validated.value().completion_identity ==
        completed.deployed.completion_identity);

  // Also exercise the released C15/C16 Built carrier and its real projection
  // issuer.  Its internally consistent nominal fixture proves that a
  // completed point is serialized and projected as a point law rather than
  // an interval-only raw product.
  const auto built = mwperf::testing::make_c16_designated_payload_fixture_v1(
      mwperf::testing::c16_designated_payload_options_v1(Stage::nominal));
  CHECK(std::get_if<mwperf::ValidatedBuiltResultV1>(
            &built.validated_result.value()) != nullptr);
  auto completed_projection =
      mwperf::testing::make_mode_erased_law_projection_v1(
          built.validated_artifact, built.scenario.request,
          built.scenario.contract);
  REQUIRE(completed_projection);
}
