#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf_oracle/full_state_oracle.hpp"

namespace {

using mwperf_oracle::BigInt;
using mwperf_oracle::Rational;

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto value = Rational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(value);
  return std::move(value).value();
}

[[nodiscard]] Rational divide(const Rational& numerator,
                              const Rational& denominator) {
  auto value = checked_divide(numerator, denominator);
  REQUIRE(value);
  return std::move(value).value();
}

}  // namespace

TEST_CASE("C26 exact batch invariant satisfies every boundary and tail row",
          "[c26][unit][stationary][rational-grounding]") {
  const std::vector<Rational> arrivals{r(3, 4), r(0), r(1, 4)};
  auto result =
      mwperf_oracle::oracle_solve_work_conserving_batch_012(arrivals);
  REQUIRE(result);
  const auto& law = result.value();

  CHECK(law.pi0 == r(1, 2));
  CHECK(law.pi1 == r(1, 6));
  CHECK(law.pi2 == r(2, 9));
  CHECK(law.tail_ratio == r(1, 3));
  CHECK(law.mean_backlog == r(1));
  CHECK(law.mean_departures == r(1, 2));

  BigInt power_of_three = 9;
  for (std::size_t level = 2U; level <= 9U; ++level) {
    auto expected = Rational::make(BigInt{2}, power_of_three);
    REQUIRE(expected);
    CHECK(law.probability(level) == expected.value());
    power_of_three *= 3;
  }

  const Rational p0 = arrivals[0U];
  const Rational p1 = arrivals[1U];
  const Rational p2 = arrivals[2U];
  const Rational pi3 = law.probability(3U);

  // The boundary rows differ from the homogeneous tail because states zero
  // and one both finish service at zero before the new batch is admitted.
  CHECK(law.pi0 == p0 * (law.pi0 + law.pi1));
  CHECK(law.pi1 == p1 * (law.pi0 + law.pi1) + p0 * law.pi2);
  CHECK(law.pi2 == p2 * (law.pi0 + law.pi1) + p1 * law.pi2 +
                       p0 * pi3);

  for (std::size_t level = 3U; level <= 8U; ++level) {
    CHECK(law.probability(level) ==
          p2 * law.probability(level - 1U) +
              p1 * law.probability(level) +
              p0 * law.probability(level + 1U));
    CHECK(law.probability(level + 1U) ==
          law.tail_ratio * law.probability(level));
  }

  const Rational one_minus_ratio = Rational::one() - law.tail_ratio;
  const Rational normalization =
      law.pi0 + law.pi1 + divide(law.pi2, one_minus_ratio);
  CHECK(normalization == Rational::one());
  const Rational exact_first_moment =
      law.pi1 +
      law.pi2 *
          (divide(r(2), one_minus_ratio) +
           divide(law.tail_ratio, one_minus_ratio * one_minus_ratio));
  CHECK(exact_first_moment == law.mean_backlog);

  const std::vector<Rational> critical{r(1, 2), r(0), r(1, 2)};
  const auto unavailable =
      mwperf_oracle::oracle_solve_work_conserving_batch_012(critical);
  REQUIRE_FALSE(unavailable);
  CHECK(unavailable.error().code == "oracle_tail_not_stable");
}

TEST_CASE("C26 three-bin closure exposes full boundary and tail identities",
          "[c26][unit][stationary][rational-grounding]") {
  const mwperf_oracle::ThreeBinScalarResponse response{r(3, 4), r(1, 4),
                                                       r(2, 3)};
  const Rational lambda = r(1, 4);
  auto result =
      mwperf_oracle::oracle_solve_three_bin_bernoulli(response, lambda);
  REQUIRE(result);
  const auto& law = result.value();
  const Rational no_arrival = Rational::one() - lambda;

  CHECK(law.pi0 * lambda == law.pi1 * no_arrival * response.s1);
  CHECK(law.pi1 * lambda * (Rational::one() - response.s1) ==
        law.pi2 * no_arrival * response.s2);
  CHECK(law.pi2 * lambda * (Rational::one() - response.s2) ==
        law.pi3 * no_arrival * response.tail);

  for (std::size_t level = 3U; level <= 8U; ++level) {
    CHECK(law.probability(level + 1U) ==
          law.tail_ratio * law.probability(level));
  }
  const Rational one_minus_ratio = Rational::one() - law.tail_ratio;
  const Rational tail_mass = divide(law.pi3, one_minus_ratio);
  CHECK(tail_mass == r(9, 224));
  CHECK(law.pi0 + law.pi1 + law.pi2 + tail_mass == Rational::one());

  const Rational exact_first_moment =
      law.pi1 + r(2) * law.pi2 +
      law.pi3 *
          (divide(r(3), one_minus_ratio) +
           divide(law.tail_ratio, one_minus_ratio * one_minus_ratio));
  CHECK(exact_first_moment == r(23, 40));
  CHECK(exact_first_moment == law.mean_backlog);
  CHECK(law.mean_departures == lambda);
}

TEST_CASE("C26 alternating ROMR law keeps event and slot measures distinct",
          "[c26][unit][romr][rational-grounding]") {
  const std::vector<std::pair<std::vector<BigInt>, Rational>> words{
      {{BigInt{10}}, r(1, 2)},
      {{BigInt{1}, BigInt{2}, BigInt{3}}, r(1, 2)},
  };
  auto result = mwperf_oracle::oracle_summarize_length_biased_words(words);
  REQUIRE(result);
  const auto& summary = result.value();

  REQUIRE(summary.event_word_probabilities.size() == 2U);
  REQUIRE(summary.slot_word_probabilities.size() == 2U);
  CHECK(summary.event_word_probabilities[0U] == r(1, 2));
  CHECK(summary.event_word_probabilities[1U] == r(1, 2));
  CHECK(summary.mean_word_length == r(2));
  CHECK(summary.slot_word_probabilities[0U] == r(1, 4));
  CHECK(summary.slot_word_probabilities[1U] == r(3, 4));
  CHECK(summary.slot_word_probabilities[0U] +
            summary.slot_word_probabilities[1U] ==
        Rational::one());
  CHECK(summary.slot_reward_mean == r(4));

  auto legacy_mean = mwperf_oracle::oracle_length_biased_reward_mean(words);
  REQUIRE(legacy_mean);
  CHECK(legacy_mean.value() == summary.slot_reward_mean);
}

TEST_CASE("C26 Palm and FIFO goldens use packet and event Palm measures",
          "[c26][unit][palm][fifo][rational-grounding]") {
  const std::vector<std::pair<BigInt, Rational>> batches{
      {BigInt{0}, r(1, 2)},
      {BigInt{1}, r(1, 4)},
      {BigInt{2}, r(1, 4)},
  };
  auto ranks = mwperf_oracle::oracle_packet_palm_ranks(batches);
  REQUIRE(ranks);
  REQUIRE(ranks.value().size() == 3U);
  CHECK(ranks.value()[0U].batch == 1);
  CHECK(ranks.value()[0U].rank == 1);
  CHECK(ranks.value()[1U].batch == 2);
  CHECK(ranks.value()[1U].rank == 1);
  CHECK(ranks.value()[2U].batch == 2);
  CHECK(ranks.value()[2U].rank == 2);
  for (const auto& atom : ranks.value()) {
    CHECK(atom.mass == r(1, 3));
  }

  const Rational service = r(1, 2);
  BigInt power_of_two = 1;
  for (std::size_t slots = 0U; slots <= 9U; ++slots) {
    auto tail =
        mwperf_oracle::oracle_fifo_tail_one_predecessor(slots, service);
    REQUIRE(tail);
    auto expected = Rational::make(BigInt{slots + 1U}, power_of_two);
    REQUIRE(expected);
    CHECK(tail.value() == expected.value());
    power_of_two *= 2;
  }
  auto fifo_mean =
      mwperf_oracle::oracle_fifo_mean_one_predecessor(service);
  REQUIRE(fifo_mean);
  CHECK(fifo_mean.value() == r(4));
  const Rational no_service = Rational::one() - service;
  const Rational summed_tail_identity =
      divide(Rational::one(), Rational::one() - no_service) +
      divide(service,
             (Rational::one() - no_service) *
                 (Rational::one() - no_service));
  CHECK(summed_tail_identity == fifo_mean.value());

  const auto infinite =
      mwperf_oracle::oracle_fifo_mean_one_predecessor(Rational::zero());
  REQUIRE_FALSE(infinite);
  CHECK(infinite.error().code == "oracle_infinite_fifo_mean");

  auto mixture = mwperf_oracle::oracle_permanent_activity_palm(r(1, 5));
  REQUIRE(mixture);
  CHECK(mixture.value().stationary_active_mass == r(1, 5));
  CHECK(mixture.value().stationary_event_intensity == r(1, 5));
  CHECK(mixture.value().palm_active_mass == Rational::one());
  CHECK(mixture.value().palm_next_gap_mean == Rational::one());
  CHECK(mixture.value().palm_next_gap_mean !=
        divide(Rational::one(),
               mixture.value().stationary_event_intensity));
}
