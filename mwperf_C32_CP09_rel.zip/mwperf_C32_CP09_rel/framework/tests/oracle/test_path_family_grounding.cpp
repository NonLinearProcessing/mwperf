#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf_oracle/full_state_oracle.hpp"

namespace {

using mwperf_oracle::AdaptedResidenceRule;
using mwperf_oracle::ArrivalAtom;
using mwperf_oracle::ArrivalRow;
using mwperf_oracle::Backlog;
using mwperf_oracle::BigInt;
using mwperf_oracle::ConflictConstraint;
using mwperf_oracle::DeterministicTraceArrival;
using mwperf_oracle::ExactJointMark;
using mwperf_oracle::ExactGapAtom;
using mwperf_oracle::FactorizedRenewalArrival;
using mwperf_oracle::FactorizedRenewalSource;
using mwperf_oracle::FiniteArrivalFamily;
using mwperf_oracle::FiniteCoupledInitialLaw;
using mwperf_oracle::FullState;
using mwperf_oracle::GlobalPeriodicArrival;
using mwperf_oracle::InitialAtom;
using mwperf_oracle::JointRenewalArrival;
using mwperf_oracle::JointRenewalAtom;
using mwperf_oracle::PackingConstraint;
using mwperf_oracle::PrivateMarkovRenewalArrival;
using mwperf_oracle::PrivateMarkovRenewalSource;
using mwperf_oracle::PrivateMarkovRenewalState;
using mwperf_oracle::PrivateMarkovTransition;
using mwperf_oracle::PriorityOrder;
using mwperf_oracle::Rational;
using mwperf_oracle::ResidenceRuleKind;
using mwperf_oracle::Schedule;
using mwperf_oracle::SharedRoundArrival;
using mwperf_oracle::SharedRoundAtom;
using mwperf_oracle::SharedRoundEmission;
using mwperf_oracle::SlotTiming;
using mwperf_oracle::SmallConstraint;
using mwperf_oracle::SmallPhysicalModel;
using mwperf_oracle::SourceDelayPeriodicArrival;
using mwperf_oracle::SourcePeriodicPattern;
using mwperf_oracle::SlotRecord;
using mwperf_oracle::TieBranch;
using mwperf_oracle::TieRow;

[[nodiscard]] Rational r(const std::int64_t numerator,
                         const std::int64_t denominator = 1) {
  auto result = Rational::make(BigInt{numerator}, BigInt{denominator});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] SmallConstraint isolated_queues(const std::size_t dimension) {
  PackingConstraint packing;
  packing.capacity.assign(dimension, BigInt{1});
  packing.demands.assign(dimension,
                         std::vector<BigInt>(dimension, BigInt{0}));
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    packing.demands[queue][queue] = 1;
  }
  return packing;
}

[[nodiscard]] SmallConstraint single_server(const std::size_t dimension) {
  ConflictConstraint conflict;
  conflict.adjacency.assign(
      dimension, std::vector<std::uint8_t>(dimension, std::uint8_t{1}));
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    conflict.adjacency[queue][queue] = 0U;
  }
  return conflict;
}

[[nodiscard]] PriorityOrder identity_priority(const std::size_t dimension) {
  PriorityOrder result(dimension);
  for (std::size_t queue = 0U; queue < dimension; ++queue) {
    result[queue] = queue;
  }
  return result;
}

[[nodiscard]] TieRow fixed_priority_row(const std::size_t dimension) {
  return TieRow{{}, {TieBranch{identity_priority(dimension), {}, r(1),
                              "c26.path.fixed-priority"}}};
}

[[nodiscard]] SmallPhysicalModel make_model(
    const FiniteArrivalFamily family, SmallConstraint constraint,
    std::vector<ArrivalRow> rows) {
  const std::size_t dimension = std::visit(
      [](const auto& concrete) -> std::size_t {
        if constexpr (requires { concrete.edges; }) {
          return concrete.edges.size();
        } else if constexpr (requires { concrete.intervals; }) {
          return concrete.intervals.size();
        } else if constexpr (requires { concrete.links; }) {
          return concrete.links.size();
        } else if constexpr (requires { concrete.adjacency; }) {
          return concrete.adjacency.size();
        } else {
          return concrete.demands.size();
        }
      },
      constraint);
  SmallPhysicalModel model;
  model.constraint = std::move(constraint);
  model.arrival_family = family;
  model.arrival_rows = std::move(rows);
  model.tie_rows.push_back(fixed_priority_row(dimension));
  model.residence_rule =
      AdaptedResidenceRule{ResidenceRuleKind::none, 0U, true};
  return model;
}

[[nodiscard]] SmallPhysicalModel make_authored_model(
    const FiniteArrivalFamily family, SmallConstraint constraint,
    mwperf_oracle::AuthoredFiniteArrival authored) {
  SmallPhysicalModel model =
      make_model(family, std::move(constraint), std::vector<ArrivalRow>{});
  model.authored_arrival = std::move(authored);
  return model;
}

[[nodiscard]] FiniteCoupledInitialLaw initial_law(
    std::vector<InitialAtom> atoms) {
  auto result = FiniteCoupledInitialLaw::create(std::move(atoms));
  INFO((result ? std::string{} : result.error().code));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<Backlog> arrival_word(
    const mwperf_oracle::PathHistory& history) {
  std::vector<Backlog> result;
  result.reserve(history.slots.size());
  for (const auto& slot : history.slots) {
    result.push_back(slot.arrivals);
  }
  return result;
}

[[nodiscard]] BigInt dot(const std::vector<BigInt>& left,
                         const std::vector<BigInt>& right) {
  REQUIRE(left.size() == right.size());
  BigInt result = 0;
  for (std::size_t index = 0U; index < left.size(); ++index) {
    result += left[index] * right[index];
  }
  return result;
}

[[nodiscard]] std::vector<BigInt> schedule_as_bigints(
    const Schedule& schedule) {
  std::vector<BigInt> result;
  result.reserve(schedule.size());
  for (const std::uint8_t bit : schedule) {
    result.emplace_back(bit);
  }
  return result;
}

[[nodiscard]] const BigInt* joint_mark_value(const SlotRecord& slot,
                                             const std::string& id) {
  const auto found = std::find_if(
      slot.joint_marks.begin(), slot.joint_marks.end(),
      [&](const ExactJointMark& mark) { return mark.id == id; });
  return found == slot.joint_marks.end() ? nullptr : &found->value;
}

}  // namespace

TEST_CASE("C26 deterministic and periodic authored inputs retain exact order",
          "[c26][unit][path-family]") {
  SECTION("deterministic trace") {
    auto model = make_authored_model(
        FiniteArrivalFamily::deterministic_trace, isolated_queues(1U),
        DeterministicTraceArrival{{{BigInt{2}}, {BigInt{0}}, {BigInt{1}},
                                   {BigInt{0}}}});
    const auto initial =
        initial_law({InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});
    auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 5U);
    REQUIRE(law);
    const std::array<std::uint64_t, 6U> expected{0U, 2U, 1U, 1U, 0U, 0U};
    for (std::size_t boundary = 0U; boundary < expected.size(); ++boundary) {
      REQUIRE(law.value().frontiers[boundary].atoms.size() == 1U);
      CHECK(law.value().frontiers[boundary].atoms[0U].state.queue[0U] ==
            expected[boundary]);
    }
    CHECK(law.value().frontiers.back().atoms[0U].history.slots.back().arrivals ==
          Backlog{BigInt{0}});
  }

  SECTION("global periodic") {
    auto model = make_authored_model(
        FiniteArrivalFamily::global_periodic, isolated_queues(1U),
        GlobalPeriodicArrival{{{BigInt{1}}, {BigInt{0}}}});
    const auto initial =
        initial_law({InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});
    auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 4U);
    REQUIRE(law);
    CHECK(arrival_word(law.value().frontiers.back().atoms[0U].history) ==
          std::vector<Backlog>{{BigInt{1}}, {BigInt{0}}, {BigInt{1}},
                               {BigInt{0}}});
  }

  SECTION("source-delay periodic product") {
    auto model = make_authored_model(
        FiniteArrivalFamily::source_delay_periodic, isolated_queues(2U),
        SourceDelayPeriodicArrival{
            {SourcePeriodicPattern{{BigInt{1}, BigInt{0}}, 0U},
             SourcePeriodicPattern{{BigInt{0}, BigInt{1}, BigInt{0}}, 0U}}});
    const auto initial = initial_law(
        {InitialAtom{FullState{{BigInt{0}, BigInt{0}}, 0U, {}}, r(1)}});
    auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 6U);
    REQUIRE(law);
    CHECK(arrival_word(law.value().frontiers.back().atoms[0U].history) ==
          std::vector<Backlog>{{BigInt{1}, BigInt{0}},
                               {BigInt{0}, BigInt{1}},
                               {BigInt{1}, BigInt{0}},
                               {BigInt{0}, BigInt{0}},
                               {BigInt{1}, BigInt{1}},
                               {BigInt{0}, BigInt{0}}});
  }
}

TEST_CASE("C26 renewal gap one starts in decision slot zero",
          "[c26][unit][path-family][renewal]") {
  const auto initial =
      initial_law({InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});

  SECTION("gap one is due in authored slot zero") {
    auto gap_one = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        FactorizedRenewalArrival{
            {FactorizedRenewalSource{BigInt{1}, {ExactGapAtom{1U, r(1)}}}}});
    auto law =
        mwperf_oracle::oracle_enumerate_finite_paths(gap_one, initial, 3U);
    REQUIRE(law);
    const auto& history = law.value().frontiers.back().atoms[0U].history;
    CHECK(arrival_word(history) ==
          std::vector<Backlog>{{BigInt{1}}, {BigInt{1}}, {BigInt{1}}});
    CHECK(history.slots.front().decision_slot == 0U);
    CHECK(history.slots.front().admission_boundary == 1U);
    CHECK(history.slots.front().arrivals == Backlog{BigInt{1}});
  }

  SECTION("factorized and joint finite rational laws agree exactly") {
    auto factorized = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        FactorizedRenewalArrival{{FactorizedRenewalSource{
            BigInt{1},
            {ExactGapAtom{1U, r(1, 3)}, ExactGapAtom{2U, r(2, 3)}}}}});
    auto joint = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        JointRenewalArrival{
            {JointRenewalAtom{{BigInt{1}}, 1U, r(1, 3), {}},
             JointRenewalAtom{{BigInt{1}}, 2U, r(2, 3), {}}}});
    auto first =
        mwperf_oracle::oracle_enumerate_finite_paths(factorized, initial, 4U);
    auto second =
        mwperf_oracle::oracle_enumerate_finite_paths(joint, initial, 4U);
    REQUIRE(first);
    REQUIRE(second);
    REQUIRE(first.value().frontiers.size() == second.value().frontiers.size());
    for (std::size_t boundary = 0U;
         boundary < first.value().frontiers.size(); ++boundary) {
      const auto& left = first.value().frontiers[boundary].atoms;
      const auto& right = second.value().frontiers[boundary].atoms;
      REQUIRE(left.size() == right.size());
      for (std::size_t atom = 0U; atom < left.size(); ++atom) {
        CHECK(left[atom].state == right[atom].state);
        CHECK(left[atom].history == right[atom].history);
        CHECK(left[atom].mass == right[atom].mass);
      }
    }
  }
}

TEST_CASE("C26 private Markov renewal uses the entered state's new gap",
          "[c26][unit][path-family][private-markov]") {
  // State A first emits after gap two (slot 1), transitions to B, and then B's
  // gap three schedules the next event at slot 4.  Reusing A's old gap would
  // incorrectly emit at slot 3 and is caught by the exact word.
  const PrivateMarkovRenewalState state_a{
      BigInt{1}, {PrivateMarkovTransition{1U, r(1)}},
      {ExactGapAtom{2U, r(1)}}};
  const PrivateMarkovRenewalState state_b{
      BigInt{1}, {PrivateMarkovTransition{1U, r(1)}},
      {ExactGapAtom{3U, r(1)}}};
  auto model = make_authored_model(
      FiniteArrivalFamily::private_markov_renewal, isolated_queues(1U),
      PrivateMarkovRenewalArrival{{PrivateMarkovRenewalSource{
          0U, 2U, {state_a, state_b}}}});
  const auto initial =
      initial_law({InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 5U);
  REQUIRE(law);
  const auto& history = law.value().frontiers.back().atoms[0U].history;
  CHECK(arrival_word(history) ==
        std::vector<Backlog>{{BigInt{0}}, {BigInt{1}}, {BigInt{0}},
                             {BigInt{0}}, {BigInt{1}}});
  CHECK(history.slots[1U].postarrival.arrival_phase !=
        history.slots[1U].predecision.arrival_phase);
  CHECK(history.slots[3U].arrivals == Backlog{BigInt{0}});
  CHECK(history.slots[4U].arrivals == Backlog{BigInt{1}});
}

TEST_CASE("C26 shared-round rows preserve correlation and pending events",
          "[c26][unit][path-family][shared-round]") {
  // The one categorical round at phase 0 chooses either a q0-fast/q2-slot-2
  // outcome or a q1-fast/q2-slot-3 outcome.  The predictive successor phase
  // retains which slow event is pending across a shorter caller horizon.
  const Backlog first_fast{BigInt{1}, BigInt{0}, BigInt{0}};
  const Backlog second_fast{BigInt{0}, BigInt{1}, BigInt{0}};
  const Backlog slow{BigInt{0}, BigInt{0}, BigInt{1}};
  auto model = make_authored_model(
      FiniteArrivalFamily::shared_round_renewal, isolated_queues(3U),
      SharedRoundArrival{
          5U,
          {SharedRoundAtom{
               r(1, 2), "fast-q0",
               {SharedRoundEmission{0U, first_fast, {}},
                SharedRoundEmission{2U, slow, {}}}},
           SharedRoundAtom{
               r(1, 2), "fast-q1",
               {SharedRoundEmission{0U, second_fast, {}},
                SharedRoundEmission{3U, slow, {}}}}}});
  const auto initial = initial_law({InitialAtom{
      FullState{{BigInt{0}, BigInt{0}, BigInt{0}}, 0U, {}}, r(1)}});

  auto prefix =
      mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 1U);
  REQUIRE(prefix);
  REQUIRE(prefix.value().frontiers.back().atoms.size() == 2U);
  CHECK(prefix.value().frontiers.back().atoms[0U].mass == r(1, 2));
  CHECK(prefix.value().frontiers.back().atoms[1U].mass == r(1, 2));
  std::vector<std::size_t> pending_phases;
  for (const auto& atom : prefix.value().frontiers.back().atoms) {
    pending_phases.push_back(atom.state.arrival_phase);
    const auto& first_slot = atom.history.slots.front();
    const auto& batch = first_slot.arrivals;
    CHECK_FALSE((batch[0U] == 1 && batch[1U] == 1));
    CHECK(batch[2U] == 0);
    REQUIRE(joint_mark_value(first_slot, "shared-round-index") != nullptr);
  }
  std::sort(pending_phases.begin(), pending_phases.end());
  CHECK(pending_phases[0U] != pending_phases[1U]);

  auto full = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 4U);
  REQUIRE(full);
  REQUIRE(full.value().frontiers.back().atoms.size() == 2U);
  for (const auto& atom : full.value().frontiers.back().atoms) {
    const auto word = arrival_word(atom.history);
    REQUIRE(word.size() == 4U);
    const bool first_fast = word[0U][0U] == 1;
    const bool second_fast = word[0U][1U] == 1;
    REQUIRE(first_fast != second_fast);
    if (first_fast) {
      CHECK(word[2U][2U] == 1);
      CHECK(word[3U][2U] == 0);
    } else {
      CHECK(word[2U][2U] == 0);
      CHECK(word[3U][2U] == 1);
    }
  }

  std::vector<InitialAtom> continued_atoms;
  for (const auto& atom : prefix.value().frontiers.back().atoms) {
    continued_atoms.push_back(InitialAtom{atom.state, atom.mass});
  }
  const auto continued_initial = initial_law(std::move(continued_atoms));
  auto continued = mwperf_oracle::oracle_enumerate_finite_paths(
      model, continued_initial, 3U);
  REQUIRE(continued);
  REQUIRE(continued.value().frontiers.back().atoms.size() == 2U);
  for (const auto& atom : continued.value().frontiers.back().atoms) {
    const auto word = arrival_word(atom.history);
    REQUIRE(word.size() == 3U);
    CHECK(word[1U][2U] + word[2U][2U] == 1);
  }
}

TEST_CASE("C26 exact joint arrival marks survive expansion and merging",
          "[c26][unit][path-family][marks]") {
  SECTION("arrival and shared-round admission resource marks stay joint") {
    const auto marks = [](const std::int64_t round,
                          const std::int64_t resource) {
      return std::vector<ExactJointMark>{
          {"shared-round", BigInt{round}},
          {"admission-count", BigInt{1}},
          {"resource-load", BigInt{resource}},
      };
    };
    // Each equal-arrival pair differs only in its auxiliary round mark. The
    // exact frontier merger must retain four joint atoms instead of erasing
    // their marks into two arrival-only atoms.
    auto model = make_authored_model(
        FiniteArrivalFamily::shared_round_renewal, isolated_queues(2U),
        SharedRoundArrival{
            2U,
            {SharedRoundAtom{
                 r(1, 4), "q0-round-101",
                 {SharedRoundEmission{0U, {BigInt{1}, BigInt{0}},
                                      marks(101, 2)}}},
             SharedRoundAtom{
                 r(1, 4), "q0-round-102",
                 {SharedRoundEmission{0U, {BigInt{1}, BigInt{0}},
                                      marks(102, 2)}}},
             SharedRoundAtom{
                 r(1, 4), "q1-round-201",
                 {SharedRoundEmission{0U, {BigInt{0}, BigInt{1}},
                                      marks(201, 1)}}},
             SharedRoundAtom{
                 r(1, 4), "q1-round-202",
                 {SharedRoundEmission{0U, {BigInt{0}, BigInt{1}},
                                      marks(202, 1)}}}}});
    const auto initial = initial_law(
        {InitialAtom{FullState{{BigInt{0}, BigInt{0}}, 0U, {}}, r(1)}});

    auto law =
        mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 2U);
    REQUIRE(law);
    REQUIRE(law.value().frontiers[1U].atoms.size() == 4U);
    REQUIRE(law.value().frontiers[2U].atoms.size() == 4U);
    for (const auto& atom : law.value().frontiers[2U].atoms) {
      CHECK(atom.state.queue == Backlog{BigInt{0}, BigInt{0}});
      CHECK(atom.mass == r(1, 4));
      REQUIRE(atom.history.slots.size() == 2U);
      const auto& selected = atom.history.slots[0U];
      REQUIRE(selected.joint_marks.size() == 4U);
      const BigInt* const round = joint_mark_value(selected, "shared-round");
      const BigInt* const admissions =
          joint_mark_value(selected, "admission-count");
      const BigInt* const resource =
          joint_mark_value(selected, "resource-load");
      REQUIRE(round != nullptr);
      REQUIRE(admissions != nullptr);
      REQUIRE(resource != nullptr);
      REQUIRE(joint_mark_value(selected, "shared-round-index") != nullptr);
      CHECK(*admissions == 1);
      if (selected.arrivals == Backlog{BigInt{1}, BigInt{0}}) {
        CHECK((*round == 101 || *round == 102));
        CHECK(*resource == 2);
      } else {
        REQUIRE(selected.arrivals == Backlog{BigInt{0}, BigInt{1}});
        CHECK((*round == 201 || *round == 202));
        CHECK(*resource == 1);
      }
      CHECK(atom.history.slots[1U].joint_marks.empty());
    }
  }

  SECTION("mark identifiers are nonempty and unique within a joint atom") {
    const auto initial = initial_law(
        {InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});
    std::vector<ArrivalRow> empty_id_rows(1U);
    empty_id_rows[0U].atoms.push_back(ArrivalAtom{
        {BigInt{0}}, 0U, r(1), std::nullopt, {{"", BigInt{7}}}});
    auto empty_id_model = make_model(FiniteArrivalFamily::finite_joint_iid,
                                     isolated_queues(1U),
                                     std::move(empty_id_rows));
    auto empty_id = mwperf_oracle::oracle_enumerate_finite_paths(
        empty_id_model, initial, 1U);
    REQUIRE_FALSE(empty_id);
    CHECK(empty_id.error().code == "oracle_mark_id_empty");

    std::vector<ArrivalRow> duplicate_rows(1U);
    duplicate_rows[0U].atoms.push_back(ArrivalAtom{
        {BigInt{0}}, 0U, r(1), std::nullopt,
        {{"round", BigInt{7}}, {"round", BigInt{8}}}});
    auto duplicate_model = make_model(FiniteArrivalFamily::finite_joint_iid,
                                      isolated_queues(1U),
                                      std::move(duplicate_rows));
    auto duplicate = mwperf_oracle::oracle_enumerate_finite_paths(
        duplicate_model, initial, 1U);
    REQUIRE_FALSE(duplicate);
    CHECK(duplicate.error().code == "oracle_mark_id_duplicate");
  }
}

TEST_CASE("C26 coupled initialization and timing remain joint invariants",
          "[c26][unit][path-family][coupling]") {
  std::vector<ArrivalRow> rows(2U);
  rows[0U].atoms.push_back({{BigInt{0}}, 0U, r(1), std::nullopt});
  rows[1U].atoms.push_back({{BigInt{1}}, 1U, r(1), std::nullopt});
  auto model = make_model(FiniteArrivalFamily::finite_joint_iid,
                          isolated_queues(1U), std::move(rows));
  const auto initial = initial_law(
      {InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1, 4)},
       InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1, 4)},
       InitialAtom{FullState{{BigInt{2}}, 1U, {}}, r(1, 4)},
       InitialAtom{FullState{{BigInt{2}}, 1U, {}}, r(1, 4)}});
  CHECK(initial.atoms().size() == 2U);
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 1U);
  REQUIRE(law);
  const auto& final = law.value().frontiers.back().atoms;
  REQUIRE(final.size() == 2U);
  CHECK(final[0U].state.queue[0U] == 0);
  CHECK(final[1U].state.queue[0U] == 2);
  CHECK(std::none_of(final.begin(), final.end(), [](const auto& atom) {
    return atom.state.queue[0U] == 1;
  }));
  for (const auto& atom : final) {
    REQUIRE(atom.history.slots.size() == 1U);
    CHECK(atom.history.slots[0U].decision_slot == 0U);
    CHECK(atom.history.slots[0U].admission_boundary == 1U);
    CHECK(atom.history.slots[0U].timing ==
          SlotTiming::early_service_late_admission);
  }
}

TEST_CASE("C26 family tags enforce only representable structural promises",
          "[c26][negative][path-family]") {
  std::vector<ArrivalRow> branched(1U);
  branched[0U].atoms = {
      {{BigInt{0}}, 0U, r(1, 2), std::nullopt},
      {{BigInt{1}}, 0U, r(1, 2), std::nullopt},
  };
  auto deterministic = make_model(FiniteArrivalFamily::deterministic_trace,
                                  isolated_queues(1U), branched);
  auto periodic = make_model(FiniteArrivalFamily::global_periodic,
                             isolated_queues(1U), std::move(branched));
  const auto initial =
      initial_law({InitialAtom{FullState{{BigInt{0}}, 0U, {}}, r(1)}});
  auto deterministic_result = mwperf_oracle::oracle_enumerate_finite_paths(
      deterministic, initial, 1U);
  auto periodic_result = mwperf_oracle::oracle_enumerate_finite_paths(
      periodic, initial, 1U);
  REQUIRE_FALSE(deterministic_result);
  REQUIRE_FALSE(periodic_result);
  CHECK(deterministic_result.error().code == "oracle_arrival_family_shape");
  CHECK(periodic_result.error().code == "oracle_arrival_family_shape");

  SECTION("authored type and family tag must agree") {
    auto mismatch = make_authored_model(
        FiniteArrivalFamily::global_periodic, isolated_queues(1U),
        DeterministicTraceArrival{{{BigInt{0}}}});
    auto result = mwperf_oracle::oracle_enumerate_finite_paths(
        mismatch, initial, 1U);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "oracle_arrival_family_shape");
  }

  SECTION("authored and flattened representations cannot compete") {
    auto ambiguous = make_authored_model(
        FiniteArrivalFamily::deterministic_trace, isolated_queues(1U),
        DeterministicTraceArrival{{{BigInt{0}}}});
    ambiguous.arrival_rows =
        {{{ArrivalAtom{{BigInt{0}}, 0U, r(1), std::nullopt}}}};
    auto result = mwperf_oracle::oracle_enumerate_finite_paths(
        ambiguous, initial, 1U);
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "oracle_arrival_representation_ambiguous");
  }

  SECTION("gap zero and nonunit exact gap mass are rejected") {
    auto zero_gap = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        FactorizedRenewalArrival{{FactorizedRenewalSource{
            BigInt{1}, {ExactGapAtom{0U, r(1)}}}}});
    auto zero_result = mwperf_oracle::oracle_enumerate_finite_paths(
        zero_gap, initial, 1U);
    REQUIRE_FALSE(zero_result);
    CHECK(zero_result.error().code == "oracle_arrival_gap_invalid");

    auto half_mass = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        FactorizedRenewalArrival{{FactorizedRenewalSource{
            BigInt{1}, {ExactGapAtom{1U, r(1, 2)}}}}});
    auto half_result = mwperf_oracle::oracle_enumerate_finite_paths(
        half_mass, initial, 1U);
    REQUIRE_FALSE(half_result);
    CHECK(half_result.error().code == "oracle_mass_not_one");
  }

  SECTION("authored materialization obeys exact state and branch budgets") {
    auto state_limited = make_authored_model(
        FiniteArrivalFamily::source_delay_periodic, isolated_queues(2U),
        SourceDelayPeriodicArrival{
            {SourcePeriodicPattern{{BigInt{0}, BigInt{1}}, 0U},
             SourcePeriodicPattern{{BigInt{0}, BigInt{0}, BigInt{1}}, 0U}}});
    state_limited.limits.maximum_states = 5U;
    auto state_result = mwperf_oracle::oracle_enumerate_finite_paths(
        state_limited,
        initial_law({InitialAtom{
            FullState{{BigInt{0}, BigInt{0}}, 0U, {}}, r(1)}}),
        1U);
    REQUIRE_FALSE(state_result);
    CHECK(state_result.error().code == "oracle_budget_exhausted");

    auto branch_limited = make_authored_model(
        FiniteArrivalFamily::finite_renewal, isolated_queues(1U),
        FactorizedRenewalArrival{{FactorizedRenewalSource{
            BigInt{1},
            {ExactGapAtom{1U, r(1, 2)}, ExactGapAtom{2U, r(1, 2)}}}}});
    branch_limited.limits.maximum_branches = 2U;
    auto branch_result = mwperf_oracle::oracle_enumerate_finite_paths(
        branch_limited, initial, 1U);
    REQUIRE_FALSE(branch_result);
    CHECK(branch_result.error().code == "oracle_budget_exhausted");
  }
}

TEST_CASE("C26 path fixtures reproduce the exact resource identity",
          "[c26][unit][path-family][resource]") {
  std::vector<ArrivalRow> rows(1U);
  rows[0U].atoms.push_back(
      {{BigInt{1}, BigInt{0}}, 0U, r(1), std::nullopt});
  auto model = make_model(FiniteArrivalFamily::deterministic_trace,
                          single_server(2U), std::move(rows));
  const auto initial = initial_law(
      {InitialAtom{FullState{{BigInt{1}, BigInt{2}}, 0U, {}}, r(1)}});
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 1U);
  REQUIRE(law);
  const auto& slot = law.value().frontiers.back().atoms[0U].history.slots[0U];
  CHECK(slot.departures == Schedule{0U, 1U});

  const std::vector<BigInt> resource{BigInt{2}, BigInt{1}};
  const BigInt capacity = 2;
  const BigInt workload = dot(resource, slot.predecision.queue);
  const BigInt served = dot(resource, schedule_as_bigints(slot.departures));
  const BigInt lost_opportunity = capacity - served;
  const BigInt projected_arrival = dot(resource, slot.arrivals);
  const BigInt next_workload = dot(resource, slot.postarrival.queue);
  CHECK(workload == 4);
  CHECK(lost_opportunity == 1);
  CHECK(next_workload ==
        workload + projected_arrival - capacity + lost_opportunity);
  CHECK(next_workload == 5);

  const BigInt virtual_before = 4;
  const BigInt residual = virtual_before - capacity;
  const BigInt virtual_after =
      std::max(BigInt{0}, residual) + projected_arrival;
  CHECK(virtual_after == 4);
  CHECK(virtual_after <= next_workload);
}

TEST_CASE("C26 path fixtures retain the exact margin-exit correction",
          "[c26][unit][path-family][margin]") {
  std::vector<ArrivalRow> rows(1U);
  rows[0U].atoms.push_back(
      {{BigInt{2}, BigInt{0}, BigInt{4}}, 0U, r(1), std::nullopt});
  auto model = make_model(FiniteArrivalFamily::deterministic_trace,
                          single_server(3U), std::move(rows));
  const auto initial = initial_law({InitialAtom{
      FullState{{BigInt{10}, BigInt{9}, BigInt{8}}, 0U, {}}, r(1)}});
  auto law = mwperf_oracle::oracle_enumerate_finite_paths(model, initial, 1U);
  REQUIRE(law);
  const auto& slot = law.value().frontiers.back().atoms[0U].history.slots[0U];
  CHECK(slot.departures == Schedule{1U, 0U, 0U});
  CHECK(slot.postarrival.queue ==
        Backlog{BigInt{11}, BigInt{9}, BigInt{12}});

  const std::vector<BigInt> old_pair_signature{BigInt{1}, BigInt{-1},
                                                BigInt{0}};
  const BigInt old_start = dot(old_pair_signature, slot.predecision.queue);
  const BigInt old_endpoint = dot(old_pair_signature, slot.postarrival.queue);
  const BigInt old_increment = old_endpoint - old_start;
  const auto reoptimized_margin = [](const Backlog& queue) {
    return queue[0U] - std::max(queue[1U], queue[2U]);
  };
  const BigInt new_start = reoptimized_margin(slot.predecision.queue);
  const BigInt new_endpoint = reoptimized_margin(slot.postarrival.queue);
  const BigInt reoptimized_increment = new_endpoint - new_start;
  const BigInt exit_correction = new_endpoint - old_endpoint;
  CHECK(old_start == 1);
  CHECK(old_increment == 1);
  CHECK(reoptimized_increment == -2);
  CHECK(exit_correction == -3);
}
