#include <algorithm>
#include <atomic>
#include <utility>

#include <catch2/catch_test_macros.hpp>

#include "fixtures/c17/direct_v0_fixture.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"

TEST_CASE("C17 seals direct decoding only after its finite V0 factor passes",
          "[c17][integration][direct]") {
  namespace direct = mwperf::testing::c17_direct;
  namespace matrix = mwperf::testing::c16_registered_pair_matrix;

  matrix::reset_c17_direct_runtime_counters();
  auto scenarios = direct::make_scenarios();
  auto failed_factor = direct::make_factor_recipe(
      scenarios.direct, scenarios.direct_materialization);
  auto prepared_failure = direct::prepare_direct_candidate(
      scenarios.direct, scenarios.direct_materialization,
      failed_factor.state_schema, failed_factor.initial_state,
      std::move(failed_factor.recipe),
      direct::fresh_direct_access(
          scenarios.direct, scenarios.direct_materialization));
  auto rejected = mwperf::audit_v0_direct_composite(
      std::move(prepared_failure.candidate));
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c17.access_binding_mismatch");
  const auto counters = matrix::c17_direct_runtime_counters();
  CHECK(counters->request_encoder.load(std::memory_order_relaxed) == 0U);
  CHECK(counters->decoder.load(std::memory_order_relaxed) == 0U);
  CHECK(counters->result_validator.load(std::memory_order_relaxed) == 0U);
  const unsigned factor_audits_before_success =
      counters->factor_cminus_enumerator.load(std::memory_order_relaxed);
  CHECK(factor_audits_before_success > 0U);

  auto factor = direct::make_factor_recipe(
      scenarios.direct, scenarios.direct_materialization);
  auto prepared = direct::prepare_direct_candidate(
      scenarios.direct, scenarios.direct_materialization,
      factor.state_schema, factor.initial_state,
      std::move(factor.recipe));
  auto framework = mwperf::audit_v0_direct_composite(
      std::move(prepared.candidate));
  INFO((framework ? std::string{}
                  : framework.error().code + ": " +
                        framework.error().message));
  REQUIRE(framework);
  CHECK(counters->factor_cminus_enumerator.load(
            std::memory_order_relaxed) > factor_audits_before_success);
  CHECK(prepared.optimizer_observer.snapshot().context_active());
  CHECK(prepared.optimizer_observer.snapshot().calls_reserved() ==
        mwperf::BigNat{0U});

  const auto& report = mwperf::v0_witness_report(framework.value());
  REQUIRE(report.passed());
  REQUIRE(report.entries().size() == 11U);
  for (std::size_t index = 0U; index < report.entries().size(); ++index) {
    CAPTURE(index);
    CHECK(static_cast<std::size_t>(report.entries()[index].obligation) ==
          index);
    CHECK(report.entries()[index].passed);
    if (report.entries()[index].obligation ==
        mwperf::V0ObligationV1::framework_unit_residence) {
      CHECK(report.entries()[index].evidence_scope ==
            mwperf::V0EvidenceScopeV1::not_applicable);
    } else {
      CHECK(report.entries()[index].evidence_scope !=
            mwperf::V0EvidenceScopeV1::not_applicable);
    }
  }

  auto initial = mwperf::audited_initial_mapper(framework.value());
  auto row_view = mwperf::audited_row_provider(framework.value());
  auto slot_view = mwperf::audited_slot_executor(framework.value());
  auto analytic = mwperf::audited_response_law(framework.value());
  auto temporal = mwperf::audited_temporal_framework(framework.value());
  auto sampler = mwperf::audited_sampler_descriptor(framework.value());
  REQUIRE_FALSE(initial);
  REQUIRE_FALSE(row_view);
  REQUIRE_FALSE(slot_view);
  REQUIRE_FALSE(analytic);
  REQUIRE_FALSE(temporal);
  REQUIRE_FALSE(sampler);
  CHECK(initial.error().code == "c17.audited_initial_mapper_unavailable");
  CHECK(row_view.error().code == "c17.audited_row_unavailable");
  CHECK(slot_view.error().code == "c17.audited_slot_unavailable");
  CHECK(analytic.error().code == "c17.audited_response_law_unavailable");
  CHECK(temporal.error().code ==
        "c17.audited_temporal_framework_unavailable");
  CHECK(sampler.error().code ==
        "c17.audited_sampler_descriptor_unavailable");

  auto direct_access =
      mwperf::audited_direct_metric_access(framework.value());
  REQUIRE(direct_access);
  CHECK(counters->request_encoder.load(std::memory_order_relaxed) == 0U);
  CHECK(counters->decoder.load(std::memory_order_relaxed) == 0U);
  CHECK(counters->result_validator.load(std::memory_order_relaxed) == 0U);
  auto value = mwperf::execute_direct_metric_decoder(
      framework.value(), direct_access.value(),
      scenarios.direct.metric_request);
  INFO((value ? std::string{}
              : value.error().code + ": " + value.error().message));
  REQUIRE(value);
  CHECK(value.value().codec ==
        mwperf::CodecIdentityV1{"mwperf.c16.direct_metric_value", 1U});
  CHECK(value.value().canonical_value == matrix::c17_direct_half_bytes());
  CHECK(counters->request_encoder.load(std::memory_order_relaxed) == 1U);
  CHECK(counters->decoder.load(std::memory_order_relaxed) == 1U);
  CHECK(counters->result_validator.load(std::memory_order_relaxed) == 1U);
  CHECK(matrix::c17_direct_factor_row_calls()->load(
            std::memory_order_relaxed) == 0U);
}
