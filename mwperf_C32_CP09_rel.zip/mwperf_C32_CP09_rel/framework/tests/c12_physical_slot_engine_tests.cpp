#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/physical/slot_engine.hpp"

namespace {

struct EngineFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  std::shared_ptr<const mwperf::InitialPhysicalLaw> initial;
};

struct PathRun final {
  mwperf::PhysicalPath path;
  mwperf::BigNat calls_reserved;
};

struct LiveRun final {
  mwperf::RngBank bank;
  mwperf::InitializedPhysicalRun initialized;
  mwperf::OptimizerExecutionContext optimizer;
};

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c12-physical";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory /
      (std::string(stem) + '-' + std::to_string(next.fetch_add(1U)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string queue_json(
    const std::span<const std::string> queue_ids) {
  std::string result{"["};
  for (std::size_t index = 0U; index < queue_ids.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += "{\"id\":\"" + queue_ids[index] + "\"}";
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string backlog_json(
    const std::span<const std::string> queue_ids,
    const std::span<const std::string> values) {
  REQUIRE(queue_ids.size() == values.size());
  std::string result{"["};
  for (std::size_t index = 0U; index < queue_ids.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += "{\"queue_id\":\"" + queue_ids[index] +
              "\",\"value\":" + values[index] + "}";
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string single_initial_atom(
    const std::span<const std::string> queue_ids,
    const std::span<const std::string> backlog,
    const std::string_view arrival_state) {
  return "[{\"probability\":1,\"backlog\":" +
         backlog_json(queue_ids, backlog) +
         ",\"controller_state\":{},\"arrival_state\":" +
         std::string(arrival_state) +
         ",\"static_context\":{},\"surrogate_initial\":{}}]";
}

[[nodiscard]] std::string model_text(
    const std::span<const std::string> queue_ids,
    const std::string_view scheduler, const std::string_view arrival) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,"queues":)json") +
         queue_json(queue_ids) + R"json(},
    "scheduler":)json" + std::string(scheduler) + R"json(,
    "arrival":)json" + std::string(arrival) + R"json(,
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] std::string analysis_text(
    const std::string_view initial_atoms,
    const std::string_view max_calls = "128") {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"law","kind":"transient_backlog_law",
                "parameters":{"horizons":[0,1,2,3]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":)json") + std::string(max_calls) +
         R"json(,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{
      "atoms":)json" + std::string(initial_atoms) + R"json(}}},
    "solver":{"kind":"enumerated",
              "parameters":{"linear_method":"dense_pivoted",
                            "max_iterations":null}}
  })json";
}

[[nodiscard]] EngineFixture make_fixture_with_atoms(
    std::vector<std::string> queue_ids, const std::string_view scheduler,
    const std::string_view arrival, const std::string_view initial_atoms,
    const std::string_view max_calls = "128") {
  auto model_document = mwperf::load_document(
      write_input("model", model_text(queue_ids, scheduler, arrival)));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document = mwperf::load_document(
      write_input("analysis", analysis_text(initial_atoms, max_calls)));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);
  const mwperf::CanonicalInputPair canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const mwperf::InputFingerprintBundle fingerprints =
      mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_law().has_value());

  mwperf::ResolvedInstance instance = std::move(resolved).value();
  auto compiled_arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.arrival());
  auto compiled_initial = mwperf::detail::CompiledInitialLawAccess::get(
      *instance.initial_law());
  REQUIRE(compiled_arrival);
  REQUIRE(compiled_initial);
  return EngineFixture{std::move(instance), compiled_arrival.value(),
                       compiled_initial.value()};
}

[[nodiscard]] EngineFixture make_fixture(
    std::vector<std::string> queue_ids, const std::string_view scheduler,
    const std::string_view arrival, const std::string_view arrival_state,
    std::vector<std::string> backlog,
    const std::string_view max_calls = "128") {
  const std::string atoms =
      single_initial_atom(queue_ids, backlog, arrival_state);
  return make_fixture_with_atoms(std::move(queue_ids), scheduler, arrival,
                                 atoms, max_calls);
}

[[nodiscard]] std::string independent_scheduler(const std::size_t count) {
  std::string priority{"["};
  for (std::size_t index = 0U; index < count; ++index) {
    if (index != 0U) {
      priority.push_back(',');
    }
    priority += "\"q" + std::to_string(index) + "\"";
  }
  priority.push_back(']');
  return R"json({"name":"conflict_graph_max_weight","params":{
    "constraint":{"conflicts":[]},"priority":)json" + priority +
         R"json(,"max_search_states":null}})json";
}

[[nodiscard]] mwperf::OptimizerExecutionContext optimizer_context(
    const mwperf::ResolvedInstance& instance) {
  auto result =
      mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] PathRun run_path(const EngineFixture& fixture,
                               const std::uint64_t horizon,
                               const std::uint64_t seed = 12012U) {
  auto context = optimizer_context(fixture.instance);
  auto path = mwperf::execute_reference_path(
      fixture.instance, *fixture.arrival, *fixture.initial,
      mwperf::BigNat(horizon), mwperf::MasterSeed(seed), context);
  INFO((path ? std::string{}
             : path.error().code + ": " + path.error().message));
  REQUIRE(path);
  const mwperf::BigNat calls = context.ledger_snapshot().calls_reserved();
  return PathRun{std::move(path).value(), calls};
}

[[nodiscard]] std::vector<std::uint8_t> bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::vector<mwperf::BigNat> dense_arrival(
    const mwperf::ArrivalBatch& batch, const std::size_t size) {
  std::vector<mwperf::BigNat> result(size, mwperf::BigNat(0U));
  for (const mwperf::ArrivalBatchEntry& entry : batch.entries()) {
    REQUIRE(entry.queue.ordinal() < size);
    result[entry.queue.ordinal()] += entry.count;
  }
  return result;
}

[[nodiscard]] mwperf::ArrivalBatch make_batch(
    const EngineFixture& fixture,
    const std::initializer_list<std::pair<std::size_t, std::uint64_t>> values) {
  std::vector<mwperf::ArrivalAtom> atoms;
  atoms.reserve(values.size());
  const mwperf::ArrivalBinding& binding =
      mwperf::arrival_law_binding(*fixture.arrival);
  for (const auto& [ordinal, count] : values) {
    auto queue = fixture.instance.queues().index_at(ordinal);
    REQUIRE(queue);
    auto atom = mwperf::ArrivalAtom::make(
        queue.value(), mwperf::BigNat(count), binding);
    REQUIRE(atom);
    atoms.push_back(std::move(atom).value());
  }
  auto batch = mwperf::aggregate_arrival_batch(atoms);
  REQUIRE(batch);
  return std::move(batch).value();
}

[[nodiscard]] mwperf::Backlog make_backlog(
    const EngineFixture& fixture, std::vector<mwperf::BigNat> values) {
  auto backlog = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values));
  REQUIRE(backlog);
  return std::move(backlog).value();
}

[[nodiscard]] mwperf::Schedule make_schedule(
    const EngineFixture& fixture, std::vector<std::uint8_t> values) {
  auto schedule = mwperf::Schedule::from_bytes(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values));
  REQUIRE(schedule);
  return std::move(schedule).value();
}

[[nodiscard]] mwperf::Diagnostic injected_error(const std::string& code) {
  return mwperf::Diagnostic{
      .category = mwperf::DiagnosticCategory::internal,
      .code = code,
      .message = "injected C12 transactional test failure",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] bool same_arrival_snapshot(
    const mwperf::testing::ArrivalProcessSnapshot& left,
    const mwperf::testing::ArrivalProcessSnapshot& right) {
  return left.expected_slot == right.expected_slot &&
         left.phase_digest == right.phase_digest &&
         left.rng.rng_version() == right.rng.rng_version() &&
         left.rng.stream_identity() == right.rng.stream_identity() &&
         left.rng.state_words() == right.rng.state_words() &&
         left.rng.consumed_words() == right.rng.consumed_words();
}

[[nodiscard]] LiveRun make_live_run(const EngineFixture& fixture,
                                    const std::uint64_t seed = 812U) {
  auto bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed(seed));
  REQUIRE(bank);
  auto initialized = mwperf::initialize_physical_run(
      fixture.instance, *fixture.arrival, *fixture.initial, bank.value());
  INFO((initialized ? std::string{}
                    : initialized.error().code + ": " +
                          initialized.error().message));
  REQUIRE(initialized);
  auto context = optimizer_context(fixture.instance);
  return LiveRun{std::move(bank).value(), std::move(initialized).value(),
                 std::move(context)};
}

[[nodiscard]] mwperf::testing::PhysicalSlotServices ordinary_services(
    std::size_t* arrival_calls = nullptr) {
  return mwperf::testing::PhysicalSlotServices{
      .resolve = [](const mwperf::ResolvedInstance& instance,
                    const mwperf::Backlog& backlog,
                    const mwperf::TieContext& tie,
                    mwperf::OptimizerExecutionContext& context) {
        return mwperf::resolve_maxweight_schedule(instance, backlog, tie,
                                                  context);
      },
      .arrival = [arrival_calls](mwperf::ArrivalProcess& process,
                                 const mwperf::BigNat& slot) {
        if (arrival_calls != nullptr) {
          ++(*arrival_calls);
        }
        return mwperf::next_arrival_step(process, slot);
      },
      .post_arrival_validate = [](const mwperf::ArrivalStep&) {
        return mwperf::Result<void>::success();
      },
  };
}

}  // namespace

TEST_CASE("C12 queue recursion exposes actual departures and late admission",
          "[c12][unit]") {
  const EngineFixture fixture = make_fixture(
      {"q0", "q1", "q2"}, independent_scheduler(3U),
      R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
      R"json({"kind":"trace_origin"})json", {"0", "0", "0"});
  const mwperf::Schedule schedule = make_schedule(fixture, {1U, 1U, 0U});
  const mwperf::ArrivalBatch batch = make_batch(fixture, {{0U, 1U}, {2U, 5U}});

  SECTION("empty scheduled coordinate is not served from the fresh batch") {
    const mwperf::Backlog backlog = make_backlog(
        fixture, {mwperf::BigNat(0U), mwperf::BigNat(4U),
                  mwperf::BigNat(0U)});
    auto departure = mwperf::compute_actual_departure(backlog, schedule);
    auto successor =
        mwperf::apply_queue_recursion(backlog, schedule, batch);
    REQUIRE(departure);
    REQUIRE(successor);
    CHECK(bits(departure.value()) ==
          std::vector<std::uint8_t>{0U, 1U, 0U});
    CHECK(std::vector<mwperf::BigNat>(successor.value().values().begin(),
                                      successor.value().values().end()) ==
          std::vector<mwperf::BigNat>{mwperf::BigNat(1U),
                                      mwperf::BigNat(3U),
                                      mwperf::BigNat(5U)});
  }

  SECTION("a prearrival packet is served before the same fresh batch") {
    const mwperf::Backlog backlog = make_backlog(
        fixture, {mwperf::BigNat(1U), mwperf::BigNat(4U),
                  mwperf::BigNat(0U)});
    auto departure = mwperf::compute_actual_departure(backlog, schedule);
    auto successor =
        mwperf::apply_queue_recursion(backlog, schedule, batch);
    REQUIRE(departure);
    REQUIRE(successor);
    CHECK(bits(departure.value()) ==
          std::vector<std::uint8_t>{1U, 1U, 0U});
    CHECK(std::vector<mwperf::BigNat>(successor.value().values().begin(),
                                      successor.value().values().end()) ==
          std::vector<mwperf::BigNat>{mwperf::BigNat(1U),
                                      mwperf::BigNat(3U),
                                      mwperf::BigNat(5U)});
  }

  SECTION("arbitrary precision is preserved across subtraction and addition") {
    mwperf::BigInt value = 1;
    value <<= 512U;
    auto huge = mwperf::BigNat::from_big_int(std::move(value));
    REQUIRE(huge);
    const mwperf::Backlog backlog = make_backlog(
        fixture, {huge.value(), mwperf::BigNat(0U), mwperf::BigNat(0U)});
    const mwperf::Schedule serve_first =
        make_schedule(fixture, {1U, 0U, 0U});
    const mwperf::ArrivalBatch one = make_batch(fixture, {{0U, 1U}});
    auto successor =
        mwperf::apply_queue_recursion(backlog, serve_first, one);
    REQUIRE(successor);
    CHECK(successor.value().values()[0U] == huge.value());
    CHECK(successor.value().values()[0U].bit_length() == 513U);
  }

  SECTION("same-slot source contributions are aggregated once") {
    const mwperf::ArrivalBatch collision =
        make_batch(fixture, {{0U, 2U}, {0U, 3U}});
    REQUIRE(collision.entries().size() == 1U);
    CHECK(collision.entries()[0U].count == mwperf::BigNat(5U));
    const mwperf::Backlog zero = make_backlog(
        fixture, {mwperf::BigNat(0U), mwperf::BigNat(0U),
                  mwperf::BigNat(0U)});
    auto successor = mwperf::apply_queue_recursion(
        zero, make_schedule(fixture, {0U, 0U, 0U}), collision);
    REQUIRE(successor);
    CHECK(successor.value().values()[0U] == mwperf::BigNat(5U));
  }

  SECTION("typed vector boundaries reject malformed dimensions and bits") {
    auto nonbinary = mwperf::Schedule::from_bytes(
        mwperf::QueueDimensionToken::from_instance(fixture.instance),
        {0U, 2U, 0U});
    REQUIRE_FALSE(nonbinary);
    CHECK(nonbinary.error().code == "schedule_not_binary");

    const EngineFixture foreign = make_fixture(
        {"q0", "q1", "q2"}, independent_scheduler(3U),
        R"json({"family":"deterministic_trace","events":[{"slot":4,"queue_id":"q0","count":1}],"metadata":{}})json",
        R"json({"kind":"trace_origin"})json", {"0", "0", "0"});
    const mwperf::Backlog backlog = make_backlog(
        fixture, {mwperf::BigNat(0U), mwperf::BigNat(0U),
                  mwperf::BigNat(0U)});
    auto mismatch = mwperf::compute_actual_departure(
        backlog, make_schedule(foreign, {0U, 0U, 0U}));
    REQUIRE_FALSE(mismatch);
    CHECK(mismatch.error().code == "queue_recursion_dimension_mismatch");
  }
}

TEST_CASE("C12 trace path is a marked early-service physical oracle",
          "[c12][integration]") {
  const std::string scheduler =
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":["q0","q1"],"max_search_states":null}})json";
  const EngineFixture fixture = make_fixture(
      {"q0", "q1"}, scheduler,
      R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q1","count":3},{"slot":2,"queue_id":"q0","count":2}],"metadata":{}})json",
      R"json({"kind":"trace_origin"})json", {"1", "1"});
  const PathRun run = run_path(fixture, 3U, 99U);
  CHECK(run.calls_reserved == mwperf::BigNat(3U));
  REQUIRE(run.path.edges().size() == 3U);

  const std::filesystem::path expected_path =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) /
      "tests/fixtures/c12/trace_path_expected.json";
  std::ifstream input(expected_path, std::ios::binary);
  REQUIRE(input.is_open());
  const nlohmann::json expected = nlohmann::json::parse(input);
  REQUIRE(expected.at("slots").size() == run.path.edges().size());

  for (std::size_t index = 0U; index < run.path.edges().size(); ++index) {
    const mwperf::PhysicalEdge& edge = run.path.edges()[index];
    const nlohmann::json& row = expected.at("slots").at(index);
    CHECK(edge.slot_index().to_decimal_string() ==
          row.at("slot").get<std::string>());
    CHECK(bits(edge.decision().schedule) ==
          row.at("schedule").get<std::vector<std::uint8_t>>());
    CHECK(bits(edge.departure()) ==
          row.at("departure").get<std::vector<std::uint8_t>>());
    const auto arrivals = dense_arrival(edge.arrival_step().batch, 2U);
    for (std::size_t queue = 0U; queue < 2U; ++queue) {
      CHECK(arrivals[queue] == mwperf::BigNat(
                                   row.at("arrival").at(queue)
                                       .get<std::uint64_t>()));
      CHECK(edge.post_state().backlog().values()[queue].to_decimal_string() ==
            row.at("post_backlog").at(queue).get<std::string>());
    }
    CHECK(edge.arrival_step().physical_arrival_epoch() ==
          edge.slot_index() + mwperf::BigNat(1U));
    CHECK(bits(edge.decision().schedule) == bits(edge.departure()));
    for (std::size_t queue = 0U; queue < 2U; ++queue) {
      CHECK(edge.decision().schedule.bytes()[queue] <=
            edge.decision().eligibility.bytes()[queue]);
    }
    if (index != 0U) {
      CHECK(mwperf::same_physical_state(
          run.path.edges()[index - 1U].post_state(), edge.pre_state()));
    }
  }

  const std::vector<mwperf::PhysicalMarkEvidence> expected_marks{
      {mwperf::PhysicalMarkKind::controller_memory_before,
       mwperf::RevealStage::boundary_observation},
      {mwperf::PhysicalMarkKind::static_context,
       mwperf::RevealStage::boundary_observation},
      {mwperf::PhysicalMarkKind::predictive_phase_before,
       mwperf::RevealStage::boundary_observation},
      {mwperf::PhysicalMarkKind::schedule,
       mwperf::RevealStage::decision_completed},
      {mwperf::PhysicalMarkKind::departure,
       mwperf::RevealStage::decision_completed},
      {mwperf::PhysicalMarkKind::controller_memory_after,
       mwperf::RevealStage::decision_completed},
      {mwperf::PhysicalMarkKind::arrival_batch,
       mwperf::RevealStage::late_admission},
      {mwperf::PhysicalMarkKind::predictive_phase_after,
       mwperf::RevealStage::late_admission},
  };
  CHECK(std::vector<mwperf::PhysicalMarkEvidence>(
            run.path.edges()[0U].marks().begin(),
            run.path.edges()[0U].marks().end()) == expected_marks);

  const mwperf::PhysicalEdge rebuilt = mwperf::make_physical_edge(
      run.path.edges()[0U].pre_state(), run.path.edges()[0U].decision(),
      run.path.edges()[0U].arrival_step(),
      run.path.edges()[0U].post_state());
  CHECK(mwperf::same_physical_edge(rebuilt, run.path.edges()[0U]));
  CHECK_THROWS_AS(
      mwperf::make_physical_edge(
          run.path.edges()[0U].pre_state(), run.path.edges()[0U].decision(),
          run.path.edges()[0U].arrival_step(),
          run.path.edges()[1U].post_state()),
      std::invalid_argument);
  const std::string serialized = mwperf::serialize_physical_path(run.path);
  CHECK(serialized.find("\"type\":\"string\",\"value\":\"q0\"") !=
        std::string::npos);
  CHECK(serialized.find("\"physical_epoch\":\"1\"") !=
        std::string::npos);
  CHECK(serialized.find("\"stage\":\"late_admission\"") !=
        std::string::npos);
}

TEST_CASE("C12 dispatches all five exact optimizer families",
          "[c12][integration]") {
  struct Case final {
    std::vector<std::string> queues;
    std::string scheduler;
    std::vector<std::string> backlog;
    std::vector<std::uint8_t> expected;
    std::uint64_t primary;
    mwperf::ServiceFamily family;
    mwperf::OptimizerId backend;
  };
  const std::vector<Case> cases{
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"},{"queue_id":"q3","input":"i1","output":"o1"}]},"priority":["q0","q1","q2","q3"]}})json",
       {"8", "7", "6", "5"}, {1U, 0U, 0U, 1U}, 13U,
       mwperf::ServiceFamily::crossbar_matching,
       mwperf::OptimizerId::hungarian_exact},
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3},{"queue_id":"q2","left":2,"right":4},{"queue_id":"q3","left":3,"right":5}]},"priority":["q0","q1","q2","q3"]}})json",
       {"5", "8", "7", "4"}, {1U, 0U, 1U, 0U}, 12U,
       mwperf::ServiceFamily::nonoverlapping_intervals,
       mwperf::OptimizerId::weighted_interval_dp_exact},
      {{"q0", "q1", "q2", "q3", "q4"},
       R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C","D","E"],"links":[{"queue_id":"q0","u":"A","v":"B"},{"queue_id":"q1","u":"B","v":"A"},{"queue_id":"q2","u":"C","v":"D"},{"queue_id":"q3","u":"A","v":"C"},{"queue_id":"q4","u":"B","v":"E"}]},"priority":["q1","q0","q2","q3","q4"]}})json",
       {"7", "7", "6", "5", "5"}, {0U, 1U, 1U, 0U, 0U}, 13U,
       mwperf::ServiceFamily::node_exclusive_matching,
       mwperf::OptimizerId::edmonds_blossom_exact},
      {{"q0", "q1", "q2"},
       R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
       {"3", "5", "3"}, {1U, 0U, 1U}, 6U,
       mwperf::ServiceFamily::pairwise_conflicts,
       mwperf::OptimizerId::mwis_branch_memo_exact},
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["cpu","ram"],"capacity":[4,4],"demands":[{"queue_id":"q0","demand":[4,1]},{"queue_id":"q1","demand":[1,4]},{"queue_id":"q2","demand":[2,2]},{"queue_id":"q3","demand":[2,2]}]},"priority":["q0","q1","q2","q3"],"max_search_states":null}})json",
       {"7", "7", "6", "6"}, {0U, 0U, 1U, 1U}, 12U,
       mwperf::ServiceFamily::resource_packing,
       mwperf::OptimizerId::binary_packing_memo_exact},
  };

  for (const Case& item : cases) {
    CAPTURE(item.family, item.backend);
    const EngineFixture fixture = make_fixture(
        item.queues, item.scheduler,
        R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
        R"json({"kind":"trace_origin"})json", item.backlog);
    const PathRun run = run_path(fixture, 1U, 51U);
    REQUIRE(run.path.edges().size() == 1U);
    const mwperf::ScheduleDecision& decision = run.path.edges()[0U].decision();
    CHECK(bits(decision.schedule) == item.expected);
    CHECK(bits(run.path.edges()[0U].departure()) == item.expected);
    CHECK(decision.primary_objective == mwperf::BigNat(item.primary));
    CHECK(decision.family == item.family);
    CHECK(decision.backend_id == item.backend);
    CHECK(fixture.instance.service_identity().family == item.family);
    CHECK(fixture.instance.service_identity().optimizer == item.backend);
  }
}

TEST_CASE("C12 physical path preserves all six arrival-family timings",
          "[c12][integration]") {
  using Dense = std::array<std::uint64_t, 3U>;
  struct Case final {
    std::string arrival;
    std::string initial_state;
    mwperf::ArrivalFamily family;
    std::vector<Dense> expected;
  };
  const std::vector<Case> cases{
      {R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":2},{"slot":2,"queue_id":"q1","count":1}],"metadata":{}})json",
       R"json({"kind":"trace_origin"})json",
       mwperf::ArrivalFamily::deterministic_trace,
       {{2U, 0U, 0U}, {0U, 0U, 0U}, {0U, 1U, 0U},
        {0U, 0U, 0U}, {0U, 0U, 0U}}},
      {R"json({"family":"periodic_global_phase","period":4,"phase":1,"sources":[{"id":"first","entries":[{"offset":0,"queue_id":"q0","count":1},{"offset":3,"queue_id":"q1","count":2}]},{"id":"second","entries":[{"offset":0,"queue_id":"q0","count":2}]}],"metadata":{}})json",
       R"json({"kind":"global_periodic_origin"})json",
       mwperf::ArrivalFamily::periodic_global_phase,
       {{0U, 2U, 0U}, {3U, 0U, 0U}, {0U, 0U, 0U},
        {0U, 0U, 0U}, {0U, 2U, 0U}, {3U, 0U, 0U}}},
      {R"json({"family":"periodic_source_delays","period":3,"sources":[{"id":"first","delay":2,"entries":[{"offset":0,"queue_id":"q0","count":1}]},{"id":"second","delay":1,"entries":[{"offset":2,"queue_id":"q1","count":2}]}],"metadata":{}})json",
       R"json({"kind":"source_delay_origin"})json",
       mwperf::ArrivalFamily::periodic_source_delays,
       {{0U, 0U, 0U}, {0U, 0U, 0U}, {1U, 0U, 0U},
        {0U, 2U, 0U}, {0U, 0U, 0U}, {1U, 0U, 0U},
        {0U, 2U, 0U}}},
      {R"json({"family":"independent_marked_renewal","sources":[{"id":"renewal","interarrival":{"kind":"deterministic","d":1},"destination_pmf":[{"queue_id":"q0","probability":1}]}],"metadata":{}})json",
       R"json({"kind":"renewal_origin"})json",
       mwperf::ArrivalFamily::independent_marked_renewal,
       {{1U, 0U, 0U}, {1U, 0U, 0U}, {1U, 0U, 0U},
        {1U, 0U, 0U}, {1U, 0U, 0U}}},
      {R"json({"family":"independent_private_markov_renewal","sources":[{"id":"private","states":["fast","slow"],"initial":{"state":"fast"},"gaps":[{"state":"fast","d":1},{"state":"slow","d":3}],"transitions":[{"state":"fast","next_state":"slow","probability":1},{"state":"slow","next_state":"fast","probability":1}],"destination_pmf":[{"queue_id":"q1","probability":1}]}],"metadata":{}})json",
       R"json({"kind":"private_markov_states","states":[{"source_id":"private","state":"fast"}]})json",
       mwperf::ArrivalFamily::independent_private_markov_renewal,
       {{0U, 1U, 0U}, {0U, 0U, 0U}, {0U, 0U, 0U},
        {0U, 1U, 0U}, {0U, 1U, 0U}}},
      {R"json({"family":"shared_joint_round_markov_renewal","sources":[{"id":"fast"},{"id":"slow"}],"states":["on"],"initial":{"state":"on"},"outcomes":[{"state":"on","next_state":"on","probability":1,"emissions":[{"source_id":"fast","d":1,"queue_id":"q0"},{"source_id":"slow","d":3,"queue_id":"q1"}]}],"metadata":{}})json",
       R"json({"kind":"shared_round_state","state":"on"})json",
       mwperf::ArrivalFamily::shared_joint_round_markov_renewal,
       {{1U, 0U, 0U}, {1U, 0U, 0U}, {1U, 1U, 0U},
        {1U, 0U, 0U}, {1U, 0U, 0U}}},
  };

  for (const Case& item : cases) {
    CAPTURE(item.family);
    const EngineFixture fixture = make_fixture(
        {"q0", "q1", "q2"}, independent_scheduler(3U), item.arrival,
        item.initial_state, {"0", "0", "0"});
    const PathRun run = run_path(
        fixture, static_cast<std::uint64_t>(item.expected.size()), 3301U);
    REQUIRE(run.path.edges().size() == item.expected.size());
    for (std::size_t slot = 0U; slot < item.expected.size(); ++slot) {
      const mwperf::ArrivalStep& step =
          run.path.edges()[slot].arrival_step();
      CHECK(mwperf::arrival_phase_family(step.phase_before) == item.family);
      CHECK(mwperf::arrival_phase_family(step.phase_after) == item.family);
      const auto actual = dense_arrival(step.batch, 3U);
      for (std::size_t queue = 0U; queue < 3U; ++queue) {
        CHECK(actual[queue] == mwperf::BigNat(item.expected[slot][queue]));
      }
    }
  }
}

TEST_CASE("C12 replay prefixes and pathwise recursion are exact",
          "[c12][property]") {
  const EngineFixture fixture = make_fixture(
      {"q0", "q1", "q2"}, independent_scheduler(3U),
      R"json({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kind":"finite_pmf","outcomes":[{"d":1,"probability":0.5},{"d":2,"probability":0.5}]},"destination_pmf":[{"queue_id":"q0","probability":0.5},{"queue_id":"q1","probability":0.5}]}],"metadata":{}})json",
      R"json({"kind":"renewal_origin"})json", {"2", "1", "0"});
  const PathRun first = run_path(fixture, 7U, 424242U);
  const PathRun replay = run_path(fixture, 7U, 424242U);
  const PathRun prefix = run_path(fixture, 3U, 424242U);
  const PathRun zero = run_path(fixture, 0U, 424242U);

  CHECK(first.calls_reserved == mwperf::BigNat(7U));
  CHECK(prefix.calls_reserved == mwperf::BigNat(3U));
  CHECK(zero.calls_reserved.is_zero());
  CHECK(zero.path.edges().empty());
  CHECK(mwperf::same_physical_state(zero.path.initial_state(),
                                    zero.path.final_state()));
  CHECK(mwperf::same_physical_path(first.path, replay.path));
  CHECK(mwperf::serialize_physical_path(first.path) ==
        mwperf::serialize_physical_path(replay.path));
  REQUIRE(prefix.path.edges().size() == 3U);
  for (std::size_t index = 0U; index < prefix.path.edges().size(); ++index) {
    CHECK(mwperf::same_physical_edge(prefix.path.edges()[index],
                                     first.path.edges()[index]));
  }

  std::vector<mwperf::BigNat> cumulative(
      first.path.initial_state().backlog().size(), mwperf::BigNat(0U));
  for (std::size_t slot = 0U; slot < first.path.edges().size(); ++slot) {
    const mwperf::PhysicalEdge& edge = first.path.edges()[slot];
    const auto arrival = dense_arrival(edge.arrival_step().batch,
                                       cumulative.size());
    for (std::size_t queue = 0U; queue < cumulative.size(); ++queue) {
      cumulative[queue] += arrival[queue];
      auto remaining = mwperf::checked_subtract(
          edge.pre_state().backlog().values()[queue],
          mwperf::BigNat(edge.departure().bytes()[queue]));
      REQUIRE(remaining);
      const mwperf::BigNat expected = remaining.value() + arrival[queue];
      CHECK(edge.post_state().backlog().values()[queue] == expected);
      CHECK(edge.post_state().backlog().values()[queue] <=
            first.path.initial_state().backlog().values()[queue] +
                cumulative[queue]);
    }
    CHECK(mwperf::arrival_phase_digest(edge.pre_state().arrival_phase()) ==
          mwperf::arrival_phase_digest(edge.arrival_step().phase_before));
    CHECK(mwperf::arrival_phase_digest(edge.post_state().arrival_phase()) ==
          mwperf::arrival_phase_digest(edge.arrival_step().phase_after));
    CHECK(edge.slot_index() == mwperf::BigNat(slot));
    if (slot != 0U) {
      CHECK(mwperf::same_physical_state(
          first.path.edges()[slot - 1U].post_state(), edge.pre_state()));
    }
  }
  CHECK(mwperf::same_physical_state(first.path.edges().back().post_state(),
                                    first.path.final_state()));
}

TEST_CASE("C12 rejects non-retained initialization identities before a draw",
          "[c12][negative]") {
  const EngineFixture fixture = make_fixture(
      {"q0", "q1"}, independent_scheduler(2U),
      R"json({"family":"deterministic_trace","events":[{"slot":0,"queue_id":"q0","count":1}],"metadata":{}})json",
      R"json({"kind":"trace_origin"})json", {"0", "0"});

  SECTION("a separately compiled law with identical values is foreign") {
    auto duplicate = mwperf::compile_arrival_law(
        fixture.instance.authored_model().arrival, fixture.instance.queues());
    REQUIRE(duplicate);
    auto bank = mwperf::RngBank::for_physical_reference(
        fixture.instance, mwperf::MasterSeed(7U));
    REQUIRE(bank);
    const mwperf::RngBankSnapshot before = bank.value().snapshot();
    auto rejected = mwperf::initialize_physical_run(
        fixture.instance, duplicate.value(), *fixture.initial, bank.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "physical_initialization_binding_mismatch");
    CHECK(bank.value().snapshot() == before);
  }

  SECTION("a copied-by-recompilation initial law is not the retained owner") {
    auto duplicate = mwperf::compile_initial_physical_law(
        fixture.instance.initial_law()->law(), *fixture.arrival);
    REQUIRE(duplicate);
    auto bank = mwperf::RngBank::for_physical_reference(
        fixture.instance, mwperf::MasterSeed(8U));
    REQUIRE(bank);
    const mwperf::RngBankSnapshot before = bank.value().snapshot();
    auto rejected = mwperf::initialize_physical_run(
        fixture.instance, *fixture.arrival, duplicate.value(), bank.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "physical_initial_law_identity_mismatch");
    CHECK(bank.value().snapshot() == before);
  }

  SECTION("one bank cannot sample a second initial atom") {
    auto bank = mwperf::RngBank::for_physical_reference(
        fixture.instance, mwperf::MasterSeed(9U));
    REQUIRE(bank);
    auto initialized = mwperf::initialize_physical_run(
        fixture.instance, *fixture.arrival, *fixture.initial, bank.value());
    REQUIRE(initialized);
    const mwperf::RngBankSnapshot before = bank.value().snapshot();
    auto rejected = mwperf::initialize_physical_run(
        fixture.instance, *fixture.arrival, *fixture.initial, bank.value());
    REQUIRE_FALSE(rejected);
    CHECK(rejected.error().code == "physical_rng_bank_already_initialized");
    CHECK(bank.value().snapshot() == before);
  }
}

TEST_CASE("C12 joint initialization never productizes backlog and cursor",
          "[c12][integration]") {
  const std::vector<std::string> queues{"q0"};
  const std::string atoms = R"json([
    {"probability":0.5,
     "backlog":[{"queue_id":"q0","value":1}],
     "controller_state":{},
     "arrival_state":{"kind":"private_markov_states","states":[
       {"source_id":"s","state":"fast"}]},
     "static_context":{},"surrogate_initial":{}},
    {"probability":0.5,
     "backlog":[{"queue_id":"q0","value":9}],
     "controller_state":{},
     "arrival_state":{"kind":"private_markov_states","states":[
       {"source_id":"s","state":"slow"}]},
     "static_context":{},"surrogate_initial":{}}
  ])json";
  const EngineFixture fixture = make_fixture_with_atoms(
      queues, independent_scheduler(1U),
      R"json({"family":"independent_private_markov_renewal","sources":[{
        "id":"s","states":["fast","slow"],
        "initial":{"distribution":[
          {"state":"fast","probability":0.5},
          {"state":"slow","probability":0.5}]},
        "gaps":[{"state":"fast","d":1},{"state":"slow","d":3}],
        "transitions":[
          {"state":"fast","next_state":"fast","probability":1},
          {"state":"slow","next_state":"slow","probability":1}],
        "destination_pmf":[{"queue_id":"q0","probability":1}]}],
        "metadata":{}})json",
      atoms);

  std::array<bool, 2U> seen{false, false};
  for (std::uint64_t seed = 0U; seed < 32U; ++seed) {
    const PathRun run = run_path(fixture, 1U, seed);
    const std::size_t original =
        run.path.initial_state().run_identity().initial_original_row_index;
    const std::size_t coalesced =
        run.path.initial_state().run_identity().initial_coalesced_atom_index;
    REQUIRE(original < seen.size());
    CHECK(coalesced == original);
    seen[original] = true;
    const mwperf::BigNat expected_backlog(original == 0U ? 1U : 9U);
    CHECK(run.path.initial_state().backlog().values()[0U] ==
          expected_backlog);
    const auto arrival = dense_arrival(
        run.path.edges()[0U].arrival_step().batch, 1U);
    CHECK(arrival[0U] == mwperf::BigNat(original == 0U ? 1U : 0U));
  }
  CHECK(seen[0U]);
  CHECK(seen[1U]);
}

TEST_CASE("C12 slot failures roll back state cursor and RNG bank",
          "[c12][negative]") {
  const EngineFixture fixture = make_fixture(
      {"q0", "q1"}, independent_scheduler(2U),
      R"json({"family":"independent_marked_renewal","sources":[{"id":"s","interarrival":{"kind":"finite_pmf","outcomes":[{"d":1,"probability":0.5},{"d":2,"probability":0.5}]},"destination_pmf":[{"queue_id":"q0","probability":0.5},{"queue_id":"q1","probability":0.5}]}],"metadata":{}})json",
      R"json({"kind":"renewal_origin"})json", {"1", "0"});

  SECTION("a successful slot completes its decision before one arrival call") {
    LiveRun live = make_live_run(fixture, 900U);
    mwperf::PhysicalState state = live.initialized.state();
    enum class ObservedStage : std::uint8_t { boundary, decision, arrival };
    ObservedStage stage = ObservedStage::boundary;
    std::size_t arrival_calls = 0U;
    mwperf::testing::PhysicalSlotServices services = ordinary_services();
    services.resolve = [&stage](
                           const mwperf::ResolvedInstance& instance,
                           const mwperf::Backlog& backlog,
                           const mwperf::TieContext& tie,
                           mwperf::OptimizerExecutionContext& context) {
      CHECK(stage == ObservedStage::boundary);
      auto decision = mwperf::resolve_maxweight_schedule(
          instance, backlog, tie, context);
      if (decision) {
        stage = ObservedStage::decision;
      }
      return decision;
    };
    services.arrival = [&stage, &arrival_calls](
                           mwperf::ArrivalProcess& process,
                           const mwperf::BigNat& slot) {
      CHECK(stage == ObservedStage::decision);
      ++arrival_calls;
      stage = ObservedStage::arrival;
      return mwperf::next_arrival_step(process, slot);
    };
    services.post_arrival_validate = [&stage](const mwperf::ArrivalStep&) {
      CHECK(stage == ObservedStage::arrival);
      return mwperf::Result<void>::success();
    };
    auto edge = mwperf::testing::execute_physical_slot_with_services(
        fixture.instance, state, live.initialized.arrival_process(), live.bank,
        live.optimizer, services);
    REQUIRE(edge);
    CHECK(stage == ObservedStage::arrival);
    CHECK(arrival_calls == 1U);
  }

  SECTION("resolver failure invokes no arrival transition") {
    LiveRun live = make_live_run(fixture, 901U);
    mwperf::PhysicalState state = live.initialized.state();
    const mwperf::PhysicalState before_state = state;
    const mwperf::RngBankSnapshot before_bank = live.bank.snapshot();
    auto before_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(before_process);
    std::size_t arrival_calls = 0U;
    mwperf::testing::PhysicalSlotServices services =
        ordinary_services(&arrival_calls);
    services.resolve = [](const mwperf::ResolvedInstance&,
                          const mwperf::Backlog&,
                          const mwperf::TieContext&,
                          mwperf::OptimizerExecutionContext&) {
      return mwperf::Result<mwperf::ScheduleDecision>::failure(
          injected_error("c12_injected_resolver_failure"));
    };
    auto failed = mwperf::testing::execute_physical_slot_with_services(
        fixture.instance, state, live.initialized.arrival_process(), live.bank,
        live.optimizer, services);
    REQUIRE_FALSE(failed);
    CHECK(failed.error().code == "c12_injected_resolver_failure");
    CHECK(arrival_calls == 0U);
    CHECK(mwperf::same_physical_state(state, before_state));
    CHECK(live.bank.snapshot() == before_bank);
    auto after_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(after_process);
    CHECK(same_arrival_snapshot(before_process.value(),
                                after_process.value()));
    CHECK(live.optimizer.ledger_snapshot().calls_reserved().is_zero());
  }

  SECTION("post-arrival failure discards the successfully advanced clone") {
    LiveRun live = make_live_run(fixture, 902U);
    mwperf::PhysicalState state = live.initialized.state();
    const mwperf::PhysicalState before_state = state;
    const mwperf::RngBankSnapshot before_bank = live.bank.snapshot();
    auto before_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(before_process);
    std::size_t arrival_calls = 0U;
    mwperf::testing::PhysicalSlotServices services =
        ordinary_services(&arrival_calls);
    services.post_arrival_validate = [](const mwperf::ArrivalStep&) {
      return mwperf::Result<void>::failure(
          injected_error("c12_injected_postarrival_failure"));
    };
    auto failed = mwperf::testing::execute_physical_slot_with_services(
        fixture.instance, state, live.initialized.arrival_process(), live.bank,
        live.optimizer, services);
    REQUIRE_FALSE(failed);
    CHECK(failed.error().code == "c12_injected_postarrival_failure");
    CHECK(arrival_calls == 1U);
    CHECK(mwperf::same_physical_state(state, before_state));
    CHECK(live.bank.snapshot() == before_bank);
    auto after_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(after_process);
    CHECK(same_arrival_snapshot(before_process.value(),
                                after_process.value()));
    CHECK(live.optimizer.ledger_snapshot().calls_reserved() ==
          mwperf::BigNat(1U));
  }

  SECTION("foreign optimizer context is rejected before solve or arrival") {
    LiveRun live = make_live_run(fixture, 903U);
    const EngineFixture foreign = make_fixture(
        {"q0", "q1"}, independent_scheduler(2U),
        R"json({"family":"deterministic_trace","events":[],"metadata":{}})json",
        R"json({"kind":"trace_origin"})json", {"1", "0"});
    auto foreign_context = optimizer_context(foreign.instance);
    mwperf::PhysicalState state = live.initialized.state();
    const mwperf::PhysicalState before_state = state;
    auto before_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(before_process);
    std::size_t arrival_calls = 0U;
    const auto services = ordinary_services(&arrival_calls);
    auto failed = mwperf::testing::execute_physical_slot_with_services(
        fixture.instance, state, live.initialized.arrival_process(), live.bank,
        foreign_context, services);
    REQUIRE_FALSE(failed);
    CHECK(failed.error().code == "physical_optimizer_context_mismatch");
    CHECK(arrival_calls == 0U);
    CHECK(mwperf::same_physical_state(state, before_state));
    auto after_process = mwperf::testing::snapshot_arrival_process(
        live.initialized.arrival_process());
    REQUIRE(after_process);
    CHECK(same_arrival_snapshot(before_process.value(),
                                after_process.value()));
    CHECK(foreign_context.ledger_snapshot().calls_reserved().is_zero());
  }
}
