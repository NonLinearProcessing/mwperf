#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace {

using mwperf::BigNat;

class TemporaryAnalysis final {
 public:
  TemporaryAnalysis(const std::string_view contents,
                    const std::string_view extension = ".json") {
    static std::atomic<unsigned int> next_id{0U};
    const std::filesystem::path directory =
        std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c14-metrics";
    std::error_code error;
    std::filesystem::create_directories(directory, error);
    REQUIRE_FALSE(error);
    path_ = directory /
            ("analysis-" + std::to_string(next_id.fetch_add(1U)) +
             std::string(extension));
    std::ofstream output(path_, std::ios::binary | std::ios::trunc);
    REQUIRE(output.is_open());
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    REQUIRE(output.good());
  }

  TemporaryAnalysis(const TemporaryAnalysis&) = delete;
  TemporaryAnalysis& operator=(const TemporaryAnalysis&) = delete;

  ~TemporaryAnalysis() {
    std::error_code ignored;
    std::filesystem::remove(path_, ignored);
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  std::filesystem::path path_;
};

[[nodiscard]] mwperf::ModelProvenance provenance(std::string pointer) {
  return mwperf::ModelProvenance{std::nullopt, std::move(pointer), false};
}

[[nodiscard]] mwperf::TypedLabel text_label(const std::string& value) {
  auto result = mwperf::TypedLabel::text(value);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::QueueId queue_id(const std::string& value) {
  return mwperf::QueueId(text_label(value));
}

[[nodiscard]] BigNat exact_nat(const std::string& lexeme) {
  auto result = mwperf::parse_exact_nonnegative_integer(
      mwperf::JsonNumber(lexeme), mwperf::BoundPolicy::unbounded());
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational exact_ratio(const std::int64_t numerator,
                                                const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt{numerator},
                                             mwperf::BigInt{denominator});
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::AuthoredQueue authored_queue(
    const std::string& value, const std::size_t ordinal) {
  const std::string base = "/switch/queues/" + std::to_string(ordinal);
  return mwperf::AuthoredQueue{
      mwperf::AuthoredField<mwperf::QueueId>{queue_id(value),
                                             provenance(base + "/id")},
      mwperf::AuthoredField<std::optional<mwperf::LegacyVoqCoordinate>>{
          std::nullopt, provenance(base + "/legacy_voq")},
      provenance(base)};
}

[[nodiscard]] mwperf::QueueCatalog make_catalog() {
  mwperf::AuthoredSwitchConfig authored = mwperf::GeneralizedSwitchConfig{
      mwperf::AuthoredField<std::optional<BigNat>>{
          std::nullopt, provenance("/switch/queue_capacity")},
      mwperf::AuthoredField<std::vector<mwperf::AuthoredQueue>>{
          {authored_queue("q0", 0U), authored_queue("q1", 1U),
           authored_queue("q2", 2U)},
          provenance("/switch/queues")},
      mwperf::AuthoredField<std::optional<BigNat>>{
          std::nullopt, provenance("/switch/legacy_n_ports")},
      provenance("/switch")};
  auto catalog = mwperf::build_queue_catalog(authored);
  REQUIRE(catalog);
  return std::move(catalog).value();
}

[[nodiscard]] std::string stationary_selection() {
  return R"json({"kind":"stationary_unique","parameters":{}})json";
}

[[nodiscard]] std::string transient_selection() {
  return R"json({"kind":"transient","parameters":{"initial_law":{"atoms":[{"probability":1,"backlog":[{"queue_id":"q0","value":0},{"queue_id":"q1","value":0}],"controller_state":{},"arrival_state":{"kind":"trace_origin"},"static_context":{},"surrogate_initial":{}}]}}})json";
}

[[nodiscard]] std::string enumerated_solver() {
  return R"json({"kind":"enumerated","parameters":{"linear_method":"dense_pivoted","max_iterations":101}})json";
}

[[nodiscard]] std::string analytic_solver() {
  return R"json({"kind":"analytic","parameters":{"precision_bits":192,"max_iterations":103}})json";
}

[[nodiscard]] std::string monte_carlo_solver(
    const std::string_view interval = "exact_binomial") {
  return std::string(
             R"json({"kind":"monte_carlo","parameters":{"replications":257,"confidence_level":0.95,"interval_method":")json") +
         std::string(interval) + R"json("}})json";
}

[[nodiscard]] std::string direct_solver() {
  return R"json({"kind":"direct","parameters":{}})json";
}

[[nodiscard]] std::string analysis_json(
    const std::string_view metric, const bool coupled,
    const std::string& selection = stationary_selection(),
    const std::string& solver = enumerated_solver()) {
  const std::string targets = coupled ? R"json(["q0","q1"])json"
                                      : R"json(["q0"])json";
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":)json") +
         targets + R"json(,
    "metrics":[)json" + std::string(metric) + R"json(],
    "surrogate":{"id":"c14-test-provider","version":"1","parameters":{}},
    "resolution":{
      "level":{"max_states":1000,"max_row_atoms":2000},
      "tail":{"kind":"certified_truncation","parameters":{"max_level":64,"max_tail_mass":1e-9}},
      "phase":{"max_phase_states":128},
      "optimizer":{"max_calls":4096,"max_search_states_per_call":65536},
      "sampling":{"max_generator_draws":100000},
      "tolerance":{"linear_residual_abs":1e-12,"integration_abs":2e-12,
                   "tail_abs":3e-12,"fixed_point_abs":4e-12}},
    "selection":)json" + selection + R"json(,
    "solver":)json" + solver + "}";
}

[[nodiscard]] mwperf::Result<mwperf::AnalysisSpec> parse_analysis(
    const std::string& text, const std::string_view extension = ".json") {
  TemporaryAnalysis file(text, extension);
  auto document = mwperf::load_document(file.path());
  if (!document) {
    return mwperf::Result<mwperf::AnalysisSpec>::failure(document.error());
  }
  return mwperf::parse_analysis_spec_v1(document.value());
}

[[nodiscard]] mwperf::Result<mwperf::MetricRequest> parse_request(
    const mwperf::QueueCatalog& catalog, const std::string_view metric,
    const bool coupled = false,
    const std::string& selection = stationary_selection(),
    const std::string& solver = enumerated_solver()) {
  auto analysis =
      parse_analysis(analysis_json(metric, coupled, selection, solver));
  if (!analysis) {
    return mwperf::Result<mwperf::MetricRequest>::failure(analysis.error());
  }
  return mwperf::parse_metric_request(analysis.value().metrics.front(),
                                      catalog);
}

struct MetricCase final {
  const char* id;
  const char* json;
  mwperf::MetricKindV1 kind;
  bool coupled;
  bool transient;
};

constexpr std::array<MetricCase, 29U> kMetricCases{{
    {"m01", R"json({"id":"m01","kind":"stationary_throughput","parameters":{}})json", mwperf::MetricKindV1::stationary_throughput, false, false},
    {"m02", R"json({"id":"m02","kind":"stationary_empty_probability","parameters":{}})json", mwperf::MetricKindV1::stationary_empty_probability, false, false},
    {"m03", R"json({"id":"m03","kind":"mean_sojourn","parameters":{}})json", mwperf::MetricKindV1::mean_sojourn, false, false},
    {"m04", R"json({"id":"m04","kind":"service_persistence","parameters":{}})json", mwperf::MetricKindV1::service_persistence, false, false},
    {"m05", R"json({"id":"m05","kind":"joint_backlog_covariance","parameters":{}})json", mwperf::MetricKindV1::joint_backlog_covariance, true, false},
    {"m06", R"json({"id":"m06","kind":"stationary_backlog_pmf","parameters":{"max_level":10}})json", mwperf::MetricKindV1::stationary_backlog_pmf, false, false},
    {"m07", R"json({"id":"m07","kind":"stationary_backlog_pgf","parameters":{"points":[0,0.5,1]}})json", mwperf::MetricKindV1::stationary_backlog_pgf, false, false},
    {"m08", R"json({"id":"m08","kind":"stationary_backlog_moment","parameters":{"order":2}})json", mwperf::MetricKindV1::stationary_backlog_moment, false, false},
    {"m09", R"json({"id":"m09","kind":"stationary_backlog_quantile","parameters":{"probability":0.95}})json", mwperf::MetricKindV1::stationary_backlog_quantile, false, false},
    {"m10", R"json({"id":"m10","kind":"stationary_backlog_tail","parameters":{"threshold":7}})json", mwperf::MetricKindV1::stationary_backlog_tail, false, false},
    {"m11", R"json({"id":"m11","kind":"backlog_conditioned_service","parameters":{"levels":[0,1,4]}})json", mwperf::MetricKindV1::backlog_conditioned_service, false, false},
    {"m12", R"json({"id":"m12","kind":"stationary_edge_reward","parameters":{"reward":"increment","moment_order":2}})json", mwperf::MetricKindV1::stationary_edge_reward, false, false},
    {"m13", R"json({"id":"m13","kind":"service_autocovariance","parameters":{"lags":[1,3,8]}})json", mwperf::MetricKindV1::service_autocovariance, false, false},
    {"m14", R"json({"id":"m14","kind":"lagged_cross_queue_covariance","parameters":{"lags":[1,2]}})json", mwperf::MetricKindV1::lagged_cross_queue_covariance, true, false},
    {"m15", R"json({"id":"m15","kind":"service_spectrum","parameters":{"frequencies":[0,0.5,1],"truncation_lag":9}})json", mwperf::MetricKindV1::service_spectrum, false, false},
    {"m16", R"json({"id":"m16","kind":"service_window_count","parameters":{"width":5}})json", mwperf::MetricKindV1::service_window_count, false, false},
    {"m17", R"json({"id":"m17","kind":"mean_event_gap","parameters":{"event":"departure"}})json", mwperf::MetricKindV1::mean_event_gap, false, false},
    {"m18", R"json({"id":"m18","kind":"event_gap_distribution","parameters":{"event":"admission","horizon":20}})json", mwperf::MetricKindV1::event_gap_distribution, false, false},
    {"m19", R"json({"id":"m19","kind":"mean_binary_run","parameters":{"predicate":"threshold_above","threshold":3}})json", mwperf::MetricKindV1::mean_binary_run, false, false},
    {"m20", R"json({"id":"m20","kind":"binary_run_distribution","parameters":{"predicate":"busy","horizon":11}})json", mwperf::MetricKindV1::binary_run_distribution, false, false},
    {"m21", R"json({"id":"m21","kind":"first_hit","parameters":{"set":{"kind":"equal","level":4},"horizon":12,"include_mean":true}})json", mwperf::MetricKindV1::first_hit, false, true},
    {"m22", R"json({"id":"m22","kind":"threshold_excursion","parameters":{"set":{"kind":"at_or_above","level":8},"horizon":13,"include_mean":false}})json", mwperf::MetricKindV1::threshold_excursion, false, true},
    {"m23", R"json({"id":"m23","kind":"transient_backlog_law","parameters":{"horizons":[0,2,7]}})json", mwperf::MetricKindV1::transient_backlog_law, false, true},
    {"m24", R"json({"id":"m24","kind":"fifo_delay","parameters":{"output":"quantile","probability":0.9}})json", mwperf::MetricKindV1::fifo_delay, false, false},
    {"m25", R"json({"id":"m25","kind":"fifo_delay_conditioned","parameters":{"output":"tail","horizon":50,"condition":{"kind":"rank","value":2}}})json", mwperf::MetricKindV1::fifo_delay_conditioned, false, false},
    {"m26", R"json({"id":"m26","kind":"counterfactual_opportunity_gap","parameters":{"convention_id":"empty-ok","horizon":6}})json", mwperf::MetricKindV1::counterfactual_opportunity_gap, false, false},
    {"m27", R"json({"id":"m27","kind":"joint_backlog_event","parameters":{"relation":"any_at_or_above","thresholds":[3,3]}})json", mwperf::MetricKindV1::joint_backlog_event, true, false},
    {"m28", R"json({"id":"m28","kind":"joint_delay","parameters":{"sampling":"lagged","lag":2,"horizon":30}})json", mwperf::MetricKindV1::joint_delay, true, false},
    {"m29", R"json({"id":"m29","kind":"ordered_schedule_sequence","parameters":{"horizon":10,"retain_full_schedule":true}})json", mwperf::MetricKindV1::ordered_schedule_sequence, true, true},
}};

[[nodiscard]] std::vector<mwperf::MetricRequest> parsed_requests(
    const mwperf::QueueCatalog& catalog,
    const std::span<const std::size_t> indices) {
  std::vector<mwperf::MetricRequest> result;
  result.reserve(indices.size());
  for (const std::size_t index : indices) {
    const MetricCase& fixture = kMetricCases.at(index);
    auto request = parse_request(
        catalog, fixture.json, fixture.coupled,
        fixture.transient ? transient_selection() : stationary_selection());
    INFO(fixture.id);
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    result.push_back(std::move(request).value());
  }
  return result;
}

template <typename T>
[[nodiscard]] bool contains(const std::vector<T>& values, const T& value) {
  return std::find(values.begin(), values.end(), value) != values.end();
}

[[nodiscard]] bool has_hypothesis(
    const mwperf::MetricRequirementClause& clause,
    const mwperf::HypothesisKindV1 kind) {
  return std::any_of(
      clause.hypotheses.begin(), clause.hypotheses.end(),
      [kind](const mwperf::HypothesisRequirementV1& value) {
        return value.claim.kind == kind;
      });
}

[[nodiscard]] bool has_mark(const mwperf::MetricRequirementClause& clause,
                            const mwperf::MetricMarkKindV1 kind,
                            const mwperf::MetricRevealStageV1 stage) {
  return std::any_of(clause.marks.begin(), clause.marks.end(),
                     [kind, stage](const mwperf::MarkRequirementV1& value) {
                       return value.kind == kind &&
                              value.latest_reveal_stage == stage;
                     });
}

[[nodiscard]] bool has_law_kind(
    const mwperf::MetricRequirementClause& clause,
    const mwperf::ReusableMetricLawKindV1 kind) {
  return std::any_of(
      clause.semantic_alternatives.begin(),
      clause.semantic_alternatives.end(),
      [kind](const mwperf::SemanticContractAlternativeV1& value) {
        return value.law.index() == static_cast<std::size_t>(kind);
      });
}

[[nodiscard]] std::filesystem::path c14_fixture_path(
    const std::string_view name) {
  return std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) / "tests" /
         "fixtures" / "c14" / std::string(name);
}

[[nodiscard]] mwperf::Digest256 digest_of(const std::string_view value) {
  const auto* data = reinterpret_cast<const std::byte*>(value.data());
  auto result = mwperf::sha256(std::span<const std::byte>(data, value.size()));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1 object_reference(
    const std::string& id) {
  return mwperf::ArtifactObjectReferenceV1{text_label(id), digest_of(id)};
}

template <typename... Values>
[[nodiscard]] constexpr std::uint32_t target_scope_mask(
    const Values... values) noexcept {
  return (std::uint32_t{0U} | ... |
          mwperf::metric_target_scope_bit_v1(values));
}

template <typename... Values>
[[nodiscard]] constexpr std::uint32_t result_scope_mask(
    const Values... values) noexcept {
  return (std::uint32_t{0U} | ... |
          mwperf::metric_result_scope_bit_v1(values));
}

template <typename... Values>
[[nodiscard]] constexpr std::uint32_t evidence_scope_mask(
    const Values... values) noexcept {
  return (std::uint32_t{0U} | ... |
          mwperf::metric_evidence_scope_bit_v1(values));
}

template <typename... Values>
[[nodiscard]] constexpr std::uint32_t role_mask(
    const Values... values) noexcept {
  return (std::uint32_t{0U} | ... |
          mwperf::metric_support_role_bit_v1(values));
}

template <typename... Values>
[[nodiscard]] constexpr std::uint64_t internal_mask(
    const Values... values) noexcept {
  return (std::uint64_t{0U} | ... |
          mwperf::internal_reference_purpose_bit_v1(values));
}

template <typename... Values>
[[nodiscard]] constexpr std::uint8_t conditional_mask(
    const Values... values) noexcept {
  return (std::uint8_t{0U} | ... |
          mwperf::metric_role_conditional_bit_v1(values));
}

// This is a literal test-side copy of C14's authoritative twenty-five-row
// role contract.  It deliberately does not consult metric_support_role_schema_v1
// while constructing the expected values, so a production-table regression
// cannot make both sides of the assertion change together.
[[nodiscard]] constexpr std::array<mwperf::MetricSupportRoleSchemaV1, 25U>
expected_role_schemas() noexcept {
  using R = mwperf::MetricSupportRoleV1;
  using A = mwperf::RealizedReferenceAlternativeV1;
  using T = mwperf::MetricTargetScopeV1;
  using O = mwperf::MetricResultScopeV1;
  using E = mwperf::MetricEvidenceScopeV1;
  using I = mwperf::InternalReferencePurposeV1;
  using C = mwperf::MetricRoleConditionalRuleV1;

  constexpr std::uint32_t all_targets = target_scope_mask(
      T::payload_targets, T::deployed_singleton_target,
      T::ordered_metric_targets, T::ordered_construction_targets,
      T::exact_request_targets);
  constexpr std::uint32_t all_results = result_scope_mask(
      O::not_a_metric_result, O::surrogate_law, O::proposal_raw,
      O::response_envelope, O::physical_bound);
  constexpr std::uint32_t all_evidence = evidence_scope_mask(
      E::none, E::raw_static_proposal, E::nominal_static_proposal,
      E::projection_center, E::projected_surrogate_mean,
      E::recoded_static_proposal, E::optimizer_interval_raw,
      E::deployed_surrogate_law, E::numerical_result,
      E::validity_or_lift, E::physical_system);

  const auto base = [](const R role, const A alternative,
                       const std::uint32_t targets,
                       const std::uint32_t results,
                       const std::uint32_t evidence) constexpr {
    mwperf::MetricSupportRoleSchemaV1 row{};
    row.role = role;
    row.reference_alternative = alternative;
    row.allowed_target_scopes = targets;
    row.allowed_result_scopes = results;
    row.allowed_evidence_scopes = evidence;
    return row;
  };
  std::array<mwperf::MetricSupportRoleSchemaV1, 25U> rows{};
  const auto put = [&rows](mwperf::MetricSupportRoleSchemaV1 row) constexpr {
    rows.at(mwperf::metric_support_role_rank_v1(row.role)) = row;
  };

  put(base(R::deployed_payload, A::deployed_payload_reference,
           target_scope_mask(T::payload_targets), all_results,
           evidence_scope_mask(E::none)));

  auto row = base(R::deployed_response, A::deployed_response_reference,
                  target_scope_mask(T::deployed_singleton_target),
                  result_scope_mask(O::surrogate_law),
                  evidence_scope_mask(E::deployed_surrogate_law));
  row.allowed_binding_roles = row.required_binding_roles =
      role_mask(R::deployed_payload);
  row.allowed_subject_roles =
      role_mask(R::raw_response, R::nominal_response, R::recoded_response);
  row.conditional_rules = conditional_mask(
      C::selected_response_product_must_match_deployment_policy);
  put(row);

  row = base(R::raw_response, A::raw_response_product_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::proposal_raw),
             evidence_scope_mask(E::raw_static_proposal));
  row.allowed_binding_roles = row.required_binding_roles =
      role_mask(R::deployed_payload);
  row.allowed_evidence_roles = role_mask(R::raw_response_bound_evidence);
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents =
          internal_mask(I::coefficient_origin);
  row.conditional_rules =
      conditional_mask(C::interval_raw_requires_bound_evidence);
  put(row);

  row = base(R::nominal_response, A::nominal_response_product_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::nominal_static_proposal));
  row.allowed_lineage_parent_roles = role_mask(R::raw_response);
  row.allowed_evidence_roles =
      role_mask(R::raw_response_bound_evidence, R::optimizer_evidence,
                R::statistical_evidence, R::numerical_evidence,
                R::calibration_evidence);
  row.allowed_internal_lineage_parents = internal_mask(I::completion_source);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::completion_policy);
  row.conditional_rules =
      conditional_mask(C::policy_selected_derivation_parents);
  put(row);

  row = base(R::projection_center, A::projection_center_product_reference,
             target_scope_mask(T::ordered_construction_targets),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::projection_center));
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents =
          internal_mask(I::projection_source);
  put(row);

  row = base(R::projected_mean, A::projected_mean_product_reference,
             target_scope_mask(T::ordered_construction_targets),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::projected_surrogate_mean));
  row.allowed_lineage_parent_roles = row.required_lineage_parent_roles =
      role_mask(R::projection_center);
  row.allowed_evidence_roles =
      role_mask(R::optimizer_evidence, R::numerical_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::projection_policy);
  row.conditional_rules =
      conditional_mask(C::policy_selected_derivation_parents);
  put(row);

  row = base(R::recoded_response, A::recoded_response_product_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::recoded_static_proposal));
  row.allowed_lineage_parent_roles =
      role_mask(R::raw_response, R::nominal_response, R::projected_mean);
  row.allowed_evidence_roles =
      role_mask(R::raw_response_bound_evidence, R::optimizer_evidence,
                R::statistical_evidence, R::numerical_evidence,
                R::calibration_evidence, R::compression_evidence);
  row.allowed_internal_lineage_parents = internal_mask(I::completion_source);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::recoding_policy);
  row.conditional_rules =
      conditional_mask(C::policy_selected_derivation_parents);
  put(row);

  const auto add_law_dependencies = [](auto& value) constexpr {
    value.allowed_binding_roles = value.required_binding_roles =
        role_mask(R::deployed_payload);
    value.allowed_evidence_roles = value.required_evidence_roles =
        role_mask(R::reported_validity_or_lift_evidence);
  };
  const std::uint32_t law_targets =
      target_scope_mask(T::ordered_metric_targets);
  const std::uint32_t law_result = result_scope_mask(O::surrogate_law);
  const std::uint32_t law_evidence =
      evidence_scope_mask(E::deployed_surrogate_law);

  row = base(R::stationary_marked_edge_law,
             A::stationary_marked_edge_law_reference, law_targets,
             law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_evidence_roles |= role_mask(R::stability_certificate);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::state_codec, I::mark_codec,
                    I::configured_arrival_binding, I::selection_binding);
  row.conditional_rules =
      conditional_mask(C::stationary_hypothesis_requires_stability);
  put(row);

  row = base(R::staged_opportunity_flux_law,
             A::staged_opportunity_flux_law_reference, law_targets,
             law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::stage_law, I::mark_codec, I::reveal_order);
  put(row);

  row = base(R::temporal_continuation_law,
             A::temporal_continuation_law_reference, law_targets,
             law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_internal_bindings = internal_mask(
      I::one_slot_continuation, I::state_codec, I::mark_codec,
      I::configured_arrival_binding, I::initial_binding,
      I::selection_binding);
  row.required_internal_bindings = internal_mask(
      I::one_slot_continuation, I::state_codec, I::mark_codec,
      I::configured_arrival_binding);
  put(row);

  row = base(R::residence_word_law, A::residence_word_law_reference,
             law_targets, law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::entrance, I::one_slot_continuation,
                    I::adapted_positive_stop, I::word, I::terminal,
                    I::reentry);
  put(row);

  row = base(R::stopped_path_law, A::stopped_path_law_reference,
             law_targets, law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::entrance, I::one_slot_continuation,
                    I::adapted_positive_stop, I::terminal,
                    I::killed_projection, I::mark_codec);
  put(row);

  row = base(R::coupled_schedule_law, A::coupled_schedule_law_reference,
             law_targets, law_result, law_evidence);
  add_law_dependencies(row);
  row.allowed_internal_bindings =
      internal_mask(I::projected_schedule, I::feasibility_domain_codec,
                    I::full_schedule);
  row.required_internal_bindings =
      internal_mask(I::projected_schedule, I::feasibility_domain_codec);
  row.conditional_rules = conditional_mask(
      C::full_schedule_when_projection_is_not_sufficient);
  put(row);

  row = base(R::direct_metric_value, A::direct_metric_value_reference,
             target_scope_mask(T::exact_request_targets), all_results,
             evidence_scope_mask(E::deployed_surrogate_law));
  row.allowed_binding_roles = row.required_binding_roles =
      role_mask(R::deployed_payload);
  row.allowed_evidence_roles = row.required_evidence_roles =
      role_mask(R::reported_validity_or_lift_evidence);
  row.allowed_evidence_roles |= role_mask(R::physical_transfer_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::normalized_request, I::selection_binding,
                    I::configured_arrival_binding, I::validity_basis);
  row.conditional_rules =
      conditional_mask(C::physical_scope_requires_transfer);
  put(row);

  row = base(R::response_envelope, A::response_envelope_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::response_envelope, O::physical_bound),
             all_evidence);
  row.allowed_binding_roles = row.required_binding_roles =
      role_mask(R::deployed_payload);
  row.allowed_evidence_roles =
      role_mask(R::raw_response_bound_evidence,
                R::response_order_evidence,
                R::physical_transfer_evidence);
  row.required_evidence_roles = role_mask(
      R::raw_response_bound_evidence, R::response_order_evidence);
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents = internal_mask(
          I::lower_response_product, I::upper_response_product);
  row.conditional_rules =
      conditional_mask(C::physical_scope_requires_transfer);
  put(row);

  row = base(R::raw_response_bound_evidence,
             A::raw_response_bound_evidence_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::raw_static_proposal,
                                 E::optimizer_interval_raw));
  row.allowed_subject_roles = row.required_subject_roles =
      role_mask(R::raw_response);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::evaluation_identity, I::proposal_identity);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::coefficient_origin);
  put(row);

  row = base(R::response_order_evidence,
             A::response_order_evidence_reference,
             target_scope_mask(T::deployed_singleton_target),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::deployed_surrogate_law));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::comparison_domain, I::transfer_direction,
                    I::validity_basis);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::lower_response_product, I::upper_response_product);
  put(row);

  row = base(R::optimizer_evidence, A::optimizer_evidence_reference,
             target_scope_mask(T::ordered_construction_targets),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::optimizer_interval_raw));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::solver_identity, I::constraint_identity,
                    I::call_report_identity, I::evaluation_identity);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::certified_product_or_envelope);
  put(row);

  row = base(R::statistical_evidence, A::statistical_evidence_reference,
             all_targets, result_scope_mask(O::not_a_metric_result),
             all_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::sampling_bank, I::sampling_probe,
                    I::evaluation_identity, I::coverage_family);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::estimand);
  put(row);

  row = base(R::numerical_evidence, A::numerical_evidence_reference,
             all_targets, result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::numerical_result));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::algorithm_tolerance_policy,
                    I::residual_or_enclosure, I::representation_domain);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::law_or_result);
  put(row);

  row = base(R::calibration_evidence, A::calibration_evidence_reference,
             target_scope_mask(T::ordered_construction_targets),
             result_scope_mask(O::not_a_metric_result), all_evidence);
  row.allowed_internal_bindings =
      internal_mask(I::sampling_bank, I::exact_population,
                    I::calibration_rule);
  row.required_internal_bindings = internal_mask(I::calibration_rule);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::calibration_source);
  row.conditional_rules = conditional_mask(
      C::calibration_input_must_be_sampling_or_population);
  put(row);

  row = base(R::compression_evidence, A::compression_evidence_reference,
             all_targets, result_scope_mask(O::not_a_metric_result),
             all_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::compression_rule);
  row.allowed_internal_evidence = row.required_internal_evidence =
      internal_mask(I::error_object);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::compression_source, I::compression_destination);
  put(row);

  row = base(R::stability_certificate, A::stability_certificate_reference,
             target_scope_mask(T::ordered_metric_targets),
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::deployed_surrogate_law));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::configured_arrival_binding, I::state_domain,
                    I::class_domain, I::selection_binding,
                    I::stability_statement);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::deployed_law);
  put(row);

  row = base(R::reported_validity_or_lift_evidence,
             A::reported_validity_or_lift_evidence_reference, all_targets,
             result_scope_mask(O::not_a_metric_result),
             evidence_scope_mask(E::validity_or_lift));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::coordinate_codec, I::mark_codec,
                    I::configured_arrival_binding, I::selection_binding,
                    I::timing_binding, I::validity_basis);
  row.allowed_internal_evidence = row.required_internal_evidence =
      internal_mask(I::validity_witness);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::artifact_payload, I::law_or_result);
  put(row);

  row = base(R::physical_transfer_evidence,
             A::physical_transfer_evidence_reference,
             target_scope_mask(T::ordered_metric_targets),
             result_scope_mask(O::physical_bound),
             evidence_scope_mask(E::physical_system));
  row.allowed_internal_bindings = row.required_internal_bindings =
      internal_mask(I::transfer_theorem, I::transfer_assumption,
                    I::transfer_direction);
  row.allowed_internal_evidence = row.required_internal_evidence =
      internal_mask(I::error_object);
  row.allowed_internal_subjects = row.required_internal_subjects =
      internal_mask(I::surrogate_source, I::physical_model,
                    I::physical_metric);
  put(row);

  return rows;
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1 role_requirement(
    const mwperf::MetricSupportRoleV1 role,
    const mwperf::MetricTargetScopeV1 target_scope,
    const mwperf::MetricResultScopeV1 result_scope,
    const mwperf::MetricEvidenceScopeV1 evidence_scope) {
  const auto* schema = mwperf::metric_support_role_schema_v1(role);
  REQUIRE(schema != nullptr);
  REQUIRE((schema->allowed_target_scopes &
           mwperf::metric_target_scope_bit_v1(target_scope)) != 0U);
  REQUIRE((schema->allowed_result_scopes &
           mwperf::metric_result_scope_bit_v1(result_scope)) != 0U);
  REQUIRE((schema->allowed_evidence_scopes &
           mwperf::metric_evidence_scope_bit_v1(evidence_scope)) != 0U);

  std::vector<mwperf::MetricRoleRelationRequirementV1> role_relations;
  const auto append_roles =
      [&role_relations](const std::uint32_t mask,
                        const mwperf::MetricRoleRelationKindV1 relation) {
        for (const auto candidate : mwperf::all_metric_support_roles_v1()) {
          if ((mask & mwperf::metric_support_role_bit_v1(candidate)) != 0U) {
            role_relations.push_back({relation, candidate});
          }
        }
      };
  append_roles(schema->required_lineage_parent_roles,
               mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_roles(schema->required_binding_roles,
               mwperf::MetricRoleRelationKindV1::binding);
  append_roles(schema->required_evidence_roles,
               mwperf::MetricRoleRelationKindV1::evidence);
  append_roles(schema->required_subject_roles,
               mwperf::MetricRoleRelationKindV1::subject);

  std::vector<mwperf::InternalRelationRequirementV1> internal_relations;
  const auto append_internal =
      [&internal_relations](const std::uint64_t mask,
                            const mwperf::MetricRoleRelationKindV1 relation) {
        const std::uint8_t last = static_cast<std::uint8_t>(
            mwperf::InternalReferencePurposeV1::error_object);
        for (std::uint8_t index = 0U; index <= last; ++index) {
          const auto purpose =
              static_cast<mwperf::InternalReferencePurposeV1>(index);
          if ((mask & mwperf::internal_reference_purpose_bit_v1(purpose)) !=
              0U) {
            internal_relations.push_back({relation, purpose});
          }
        }
      };
  append_internal(schema->required_internal_lineage_parents,
                  mwperf::MetricRoleRelationKindV1::lineage_parent);
  append_internal(schema->required_internal_bindings,
                  mwperf::MetricRoleRelationKindV1::binding);
  append_internal(schema->required_internal_evidence,
                  mwperf::MetricRoleRelationKindV1::evidence);
  append_internal(schema->required_internal_subjects,
                  mwperf::MetricRoleRelationKindV1::subject);

  return mwperf::MetricSupportRoleRequirementV1{
      role, target_scope, result_scope, evidence_scope,
      std::move(role_relations), std::move(internal_relations)};
}

[[nodiscard]] mwperf::MetricSupportClauseV1 minimal_support_clause(
    const std::vector<mwperf::MetricSupportRoleRequirementV1>& roles) {
  return mwperf::MetricSupportClauseV1{
      mwperf::MetricClauseIdV1{"supported", 0U},
      mwperf::MetricKindV1::stationary_empty_probability,
      mwperf::ExactMetricParameterSetV1{{
          mwperf::StationaryEmptyProbabilityParametersV1{}}},
      {queue_id("q0")},
      mwperf::TargetCouplingV1::scalar_target,
      {{mwperf::StateFieldKindV1::target_backlog,
        mwperf::FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      {},
      {{mwperf::SelectionKindV1::stationary_unique}, {}, {}},
      {mwperf::PayloadPhaseKindV1::phase_free,
       mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival, false,
       std::nullopt, mwperf::FiniteHorizonCoverageKindV1::none, std::nullopt},
      {mwperf::PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      mwperf::SemanticTagV1::scalar_backlog_response,
      mwperf::RuntimeAccessTagV1::finite_parameter_analytic_family,
      {},
      {},
      mwperf::SolverRegimeV1::enumerated,
      mwperf::EnumeratedAccuracyV1{{}},
      {mwperf::StructuralErrorFormV1::exact,
       mwperf::MetricEvidenceScopeV1::none, mwperf::ExactRational::zero()},
      mwperf::MetricResultScopeV1::surrogate_law,
      {mwperf::V0DeclarationKindV1::structural_witness_required,
       "c14.test.factor", 1U},
      roles};
}

template <typename Enum>
[[nodiscard]] Enum first_set_enum(const std::uint32_t mask,
                                  const std::uint8_t count) {
  for (std::uint8_t index = 0U; index < count; ++index) {
    if ((mask & (std::uint32_t{1U} << index)) != 0U) {
      return static_cast<Enum>(index);
    }
  }
  FAIL("closed schema contains an empty allowed-scope mask");
  return static_cast<Enum>(0U);
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1
canonical_role_requirement(const mwperf::MetricSupportRoleV1 role) {
  const auto* schema = mwperf::metric_support_role_schema_v1(role);
  REQUIRE(schema != nullptr);
  auto target = first_set_enum<mwperf::MetricTargetScopeV1>(
      schema->allowed_target_scopes, 5U);
  auto result = first_set_enum<mwperf::MetricResultScopeV1>(
      schema->allowed_result_scopes, 5U);
  auto evidence = first_set_enum<mwperf::MetricEvidenceScopeV1>(
      schema->allowed_evidence_scopes, 11U);

  // Manifest-selected roles are pinned to this fixture's surrogate-law
  // clause.  The response envelope deliberately stays a surrogate envelope;
  // physical transfer is exercised by its own typed role.
  if (role == mwperf::MetricSupportRoleV1::deployed_payload ||
      role == mwperf::MetricSupportRoleV1::direct_metric_value) {
    result = mwperf::MetricResultScopeV1::surrogate_law;
  } else if (role == mwperf::MetricSupportRoleV1::response_envelope) {
    result = mwperf::MetricResultScopeV1::response_envelope;
  }
  return role_requirement(role, target, result, evidence);
}

[[nodiscard]] mwperf::MetricSupportRoleRequirementV1 matrix_role_requirement(
    const mwperf::MetricSupportRoleV1 role,
    const bool envelope_clause = false,
    const bool physical_clause = false) {
  auto requirement = canonical_role_requirement(role);
  if (role == mwperf::MetricSupportRoleV1::deployed_payload) {
    requirement = role_requirement(
        role, mwperf::MetricTargetScopeV1::payload_targets,
        physical_clause
            ? mwperf::MetricResultScopeV1::physical_bound
            : (envelope_clause ? mwperf::MetricResultScopeV1::response_envelope
                               : mwperf::MetricResultScopeV1::surrogate_law),
        mwperf::MetricEvidenceScopeV1::none);
  } else if (role == mwperf::MetricSupportRoleV1::deployed_response) {
    requirement.role_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::subject,
         mwperf::MetricSupportRoleV1::raw_response});
  } else if (role == mwperf::MetricSupportRoleV1::nominal_response ||
             role == mwperf::MetricSupportRoleV1::recoded_response) {
    requirement.role_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::lineage_parent,
         mwperf::MetricSupportRoleV1::raw_response});
  } else if (role ==
             mwperf::MetricSupportRoleV1::temporal_continuation_law) {
    requirement.internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::selection_binding});
  } else if (role == mwperf::MetricSupportRoleV1::calibration_evidence) {
    requirement.internal_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::binding,
         mwperf::InternalReferencePurposeV1::exact_population});
  } else if (role == mwperf::MetricSupportRoleV1::response_envelope &&
             physical_clause) {
    requirement.result_scope = mwperf::MetricResultScopeV1::physical_bound;
    requirement.evidence_scope = mwperf::MetricEvidenceScopeV1::physical_system;
    requirement.role_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::evidence,
         mwperf::MetricSupportRoleV1::physical_transfer_evidence});
  }
  return requirement;
}

[[nodiscard]] mwperf::MetricSupportClauseV1 role_matrix_clause(
    const mwperf::MetricSupportRoleV1 selected_role) {
  const bool envelope =
      selected_role == mwperf::MetricSupportRoleV1::response_envelope ||
      selected_role ==
          mwperf::MetricSupportRoleV1::physical_transfer_evidence;
  const bool physical =
      selected_role ==
      mwperf::MetricSupportRoleV1::physical_transfer_evidence;
  std::vector<mwperf::MetricSupportRoleRequirementV1> roles;
  const auto ensure_role = [&](const auto& self,
                               const mwperf::MetricSupportRoleV1 role) -> void {
    if (std::any_of(roles.begin(), roles.end(), [role](const auto& value) {
          return value.role == role;
        })) {
      return;
    }
    auto requirement = matrix_role_requirement(role, envelope, physical);
    const auto related = requirement.role_relations;
    roles.push_back(std::move(requirement));
    for (const auto& relation : related) {
      self(self, relation.other_role);
    }
  };

  ensure_role(ensure_role, mwperf::MetricSupportRoleV1::deployed_payload);
  if (envelope) {
    ensure_role(ensure_role, mwperf::MetricSupportRoleV1::response_envelope);
  } else {
    ensure_role(ensure_role, mwperf::MetricSupportRoleV1::deployed_response);
    ensure_role(ensure_role, mwperf::MetricSupportRoleV1::raw_response);
    ensure_role(ensure_role, selected_role);
  }

  mwperf::MetricSupportClauseV1 clause = minimal_support_clause(roles);
  if (envelope) {
    clause.payload_class =
        {mwperf::PayloadClassTagV1::finite_law_tables_v1, 1U};
    clause.semantic = mwperf::SemanticTagV1::response_envelope_law;
    clause.result_scope = physical
                              ? mwperf::MetricResultScopeV1::physical_bound
                              : mwperf::MetricResultScopeV1::response_envelope;
    clause.error_promise.scope =
        physical ? mwperf::MetricEvidenceScopeV1::physical_system
                 : mwperf::MetricEvidenceScopeV1::none;
  }
  return clause;
}

[[nodiscard]] mwperf::PreviewPoliciesV1 role_matrix_policies(
    const mwperf::MetricSupportRoleV1 role) {
  const bool envelope =
      role == mwperf::MetricSupportRoleV1::response_envelope ||
      role == mwperf::MetricSupportRoleV1::physical_transfer_evidence;
  const bool law_or_decoder =
      (role >= mwperf::MetricSupportRoleV1::stationary_marked_edge_law &&
       role <= mwperf::MetricSupportRoleV1::direct_metric_value);
  const bool evidence_role =
      role >= mwperf::MetricSupportRoleV1::raw_response_bound_evidence;
  return {
      envelope ? mwperf::PointDeploymentPolicyV1::not_applicable
               : mwperf::PointDeploymentPolicyV1::deploy_raw_point,
      role == mwperf::MetricSupportRoleV1::nominal_response
          ? mwperf::CoefficientCompletionPolicyV1::declared_nominal_completion
          : mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
      role == mwperf::MetricSupportRoleV1::projected_mean ||
              role == mwperf::MetricSupportRoleV1::projection_center
          ? mwperf::ProjectionPolicyV1::convex_feasible_mean
          : mwperf::ProjectionPolicyV1::not_applicable,
      role == mwperf::MetricSupportRoleV1::recoded_response
          ? mwperf::RecodingPolicyV1::identity
          : mwperf::RecodingPolicyV1::not_applicable,
      envelope || law_or_decoder || evidence_role
          ? mwperf::EvidenceRolePolicyV1::exact_manifest_roles
          : mwperf::EvidenceRolePolicyV1::not_applicable};
}

[[nodiscard]] std::vector<mwperf::ArtifactObjectReferenceV1>
all_role_subjects() {
  std::vector<mwperf::ArtifactObjectReferenceV1> subjects;
  subjects.reserve(mwperf::all_metric_support_roles_v1().size());
  for (const auto role : mwperf::all_metric_support_roles_v1()) {
    subjects.push_back(object_reference(
        "role-subject-" +
        std::to_string(mwperf::metric_support_role_rank_v1(role))));
  }
  // A deployed raw response must reuse, not copy, the exact raw product
  // ledger identity.
  subjects[mwperf::metric_support_role_rank_v1(
      mwperf::MetricSupportRoleV1::deployed_response)] =
      subjects[mwperf::metric_support_role_rank_v1(
          mwperf::MetricSupportRoleV1::raw_response)];
  return subjects;
}

[[nodiscard]] mwperf::RealizedReferenceCoreV1& mutable_realized_core(
    mwperf::RealizedReferenceV1& reference) {
  return std::visit(
      [](auto& typed) -> mwperf::RealizedReferenceCoreV1& {
        return typed.core;
      },
      reference);
}

[[nodiscard]] mwperf::ArtifactObjectReferenceV1* mutable_internal_object(
    mwperf::RealizedReferenceCoreV1& core,
    const mwperf::InternalReferencePurposeV1 purpose) {
  const auto found = std::find_if(
      core.internal_relations.begin(), core.internal_relations.end(),
      [purpose](const auto& relation) { return relation.purpose == purpose; });
  return found == core.internal_relations.end() ? nullptr
                                                : &found->referenced_object;
}

[[nodiscard]] mwperf::RealizedReferenceCoreV1 fully_realized_core(
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const std::vector<mwperf::ArtifactObjectReferenceV1>& subjects,
    const mwperf::MetricClauseIdV1& clause_id = {"all-roles", 0U}) {
  std::vector<mwperf::RealizedRoleRelationV1> role_relations;
  role_relations.reserve(requirement.role_relations.size());
  for (const auto& relation : requirement.role_relations) {
    role_relations.push_back(
        {relation.relation,
         {clause_id, relation.other_role},
         subjects.at(mwperf::metric_support_role_rank_v1(
             relation.other_role))});
  }

  std::vector<mwperf::RealizedInternalReferenceV1> internal_relations;
  internal_relations.reserve(requirement.internal_relations.size());
  for (std::size_t index = 0U; index < requirement.internal_relations.size();
       ++index) {
    const auto& relation = requirement.internal_relations[index];
    mwperf::ArtifactObjectReferenceV1 referenced = object_reference(
        "internal-" +
        std::to_string(
            mwperf::metric_support_role_rank_v1(requirement.role)) +
        "-" + std::to_string(index));
    if (requirement.role ==
            mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence &&
        relation.purpose ==
            mwperf::InternalReferencePurposeV1::law_or_result) {
      referenced = subjects.at(mwperf::metric_support_role_rank_v1(
          mwperf::MetricSupportRoleV1::direct_metric_value));
    }
    internal_relations.push_back(
        {relation.relation, relation.purpose, std::move(referenced)});
  }
  return mwperf::RealizedReferenceCoreV1{
      {queue_id("q0")}, requirement.target_scope, requirement.result_scope,
      requirement.evidence_scope, std::move(role_relations),
      std::move(internal_relations)};
}

[[nodiscard]] mwperf::RealizedReferenceV1 realized_reference_for_role(
    const mwperf::MetricSupportRoleRequirementV1& requirement,
    const std::vector<mwperf::ArtifactObjectReferenceV1>& subjects,
    const mwperf::MetricClauseIdV1& clause_id = {"all-roles", 0U}) {
  const auto role = requirement.role;
  const auto& subject =
      subjects.at(mwperf::metric_support_role_rank_v1(role));
  auto core = fully_realized_core(requirement, subjects, clause_id);
  switch (role) {
    case mwperf::MetricSupportRoleV1::deployed_payload:
      return mwperf::DeployedPayloadReferenceV1{
          std::move(core), mwperf::ArtifactPayloadRef{subject}};
    case mwperf::MetricSupportRoleV1::deployed_response:
      return mwperf::DeployedResponseReferenceV1{
          std::move(core),
          mwperf::RawResponseProductRef{
              subject, mwperf::ResponseProductValueFormV1::exact_point}};
    case mwperf::MetricSupportRoleV1::raw_response:
      return mwperf::RawResponseProductReferenceV1{
          std::move(core),
          mwperf::RawResponseProductRef{
              subject, mwperf::ResponseProductValueFormV1::exact_point}};
    case mwperf::MetricSupportRoleV1::nominal_response:
      return mwperf::NominalResponseProductReferenceV1{
          std::move(core), mwperf::NominalResponseProductRef{subject}};
    case mwperf::MetricSupportRoleV1::projection_center:
      return mwperf::ProjectionCenterProductReferenceV1{
          std::move(core), mwperf::ProjectionCenterProductRef{subject}};
    case mwperf::MetricSupportRoleV1::projected_mean:
      return mwperf::ProjectedMeanProductReferenceV1{
          std::move(core), mwperf::ProjectedMeanProductRef{subject}};
    case mwperf::MetricSupportRoleV1::recoded_response:
      return mwperf::RecodedResponseProductReferenceV1{
          std::move(core), mwperf::RecodedResponseProductRef{subject}};
    case mwperf::MetricSupportRoleV1::stationary_marked_edge_law:
      return mwperf::StationaryMarkedEdgeLawReferenceV1{
          std::move(core), mwperf::StationaryMarkedEdgeLawRef{subject}};
    case mwperf::MetricSupportRoleV1::staged_opportunity_flux_law:
      return mwperf::StagedOpportunityFluxLawReferenceV1{
          std::move(core), mwperf::StagedOpportunityFluxLawRef{subject}};
    case mwperf::MetricSupportRoleV1::temporal_continuation_law:
      return mwperf::TemporalContinuationLawReferenceV1{
          std::move(core), mwperf::TemporalContinuationLawRef{subject}};
    case mwperf::MetricSupportRoleV1::residence_word_law:
      return mwperf::ResidenceWordLawReferenceV1{
          std::move(core), mwperf::ResidenceWordLawRef{subject}};
    case mwperf::MetricSupportRoleV1::stopped_path_law:
      return mwperf::StoppedPathLawReferenceV1{
          std::move(core), mwperf::StoppedPathLawRef{subject}};
    case mwperf::MetricSupportRoleV1::coupled_schedule_law:
      return mwperf::CoupledScheduleLawReferenceV1{
          std::move(core), mwperf::CoupledScheduleLawRef{subject}};
    case mwperf::MetricSupportRoleV1::direct_metric_value:
      return mwperf::DirectMetricValueReferenceV1{
          std::move(core), mwperf::DirectMetricValueRef{subject}};
    case mwperf::MetricSupportRoleV1::response_envelope:
      return mwperf::ResponseEnvelopeReferenceV1{
          std::move(core), mwperf::ResponseEnvelopeRef{subject}};
    case mwperf::MetricSupportRoleV1::raw_response_bound_evidence:
      return mwperf::RawResponseBoundEvidenceReferenceV1{
          std::move(core), mwperf::RawResponseBoundEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::response_order_evidence:
      return mwperf::ResponseOrderEvidenceReferenceV1{
          std::move(core), mwperf::ResponseOrderEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::optimizer_evidence:
      return mwperf::OptimizerEvidenceReferenceV1{
          std::move(core), mwperf::OptimizerEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::statistical_evidence:
      return mwperf::StatisticalEvidenceReferenceV1{
          std::move(core), mwperf::StatisticalEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::numerical_evidence:
      return mwperf::NumericalEvidenceReferenceV1{
          std::move(core), mwperf::NumericalEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::calibration_evidence:
      return mwperf::CalibrationEvidenceReferenceV1{
          std::move(core), mwperf::CalibrationEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::compression_evidence:
      return mwperf::CompressionEvidenceReferenceV1{
          std::move(core), mwperf::CompressionEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::stability_certificate:
      return mwperf::StabilityCertificateReferenceV1{
          std::move(core), mwperf::StabilityCertificateRef{subject}};
    case mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return mwperf::ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core),
          mwperf::ReportedValidityOrLiftEvidenceRef{subject}};
    case mwperf::MetricSupportRoleV1::physical_transfer_evidence:
      return mwperf::PhysicalTransferEvidenceReferenceV1{
          std::move(core), mwperf::PhysicalTransferEvidenceRef{subject}};
  }
  FAIL("unreachable closed role");
  return mwperf::DeployedPayloadReferenceV1{
      std::move(core), mwperf::ArtifactPayloadRef{subject}};
}

[[nodiscard]] std::vector<mwperf::RealizedMetricBindingV1>
realize_role_matrix_clause(const mwperf::MetricSupportClauseV1& clause) {
  const auto subjects = all_role_subjects();
  std::vector<mwperf::RealizedMetricBindingV1> bindings;
  bindings.reserve(clause.required_roles.size());
  for (const auto& role : clause.required_roles) {
    bindings.push_back(
        {{clause.clause_id, role.role},
         realized_reference_for_role(role, subjects, clause.clause_id)});
  }

  const auto find_binding = [&bindings](const mwperf::MetricSupportRoleV1 role)
      -> mwperf::RealizedMetricBindingV1* {
    const auto found = std::find_if(
        bindings.begin(), bindings.end(), [role](const auto& binding) {
          return binding.key.role == role;
        });
    return found == bindings.end() ? nullptr : &*found;
  };

  if (auto* validity = find_binding(
          mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence)) {
    auto* payload = find_binding(mwperf::MetricSupportRoleV1::deployed_payload);
    REQUIRE(payload != nullptr);
    auto* named_payload = mutable_internal_object(
        mutable_realized_core(validity->reference),
        mwperf::InternalReferencePurposeV1::artifact_payload);
    REQUIRE(named_payload != nullptr);
    *named_payload =
        mwperf::realized_reference_subject_v1(payload->reference);
  }

  if (auto* bound = find_binding(
          mwperf::MetricSupportRoleV1::raw_response_bound_evidence)) {
    auto* raw = find_binding(mwperf::MetricSupportRoleV1::raw_response);
    REQUIRE(raw != nullptr);
    auto* raw_origin = mutable_internal_object(
        mutable_realized_core(raw->reference),
        mwperf::InternalReferencePurposeV1::coefficient_origin);
    auto* bound_origin = mutable_internal_object(
        mutable_realized_core(bound->reference),
        mwperf::InternalReferencePurposeV1::coefficient_origin);
    REQUIRE(raw_origin != nullptr);
    REQUIRE(bound_origin != nullptr);
    *bound_origin = *raw_origin;
  }

  // Evidence edges bind exact object identities rather than merely matching
  // a role tag.  Materialize the two dependency-closed families used by this
  // table fixture with the shared objects required by the v1 schema.
  for (const auto& requirement : clause.required_roles) {
    for (const auto& relation : requirement.role_relations) {
      if (relation.relation != mwperf::MetricRoleRelationKindV1::evidence) {
        continue;
      }
      auto* source = find_binding(requirement.role);
      auto* evidence = find_binding(relation.other_role);
      REQUIRE(source != nullptr);
      REQUIRE(evidence != nullptr);
      const auto source_subject =
          mwperf::realized_reference_subject_v1(source->reference);
      auto& evidence_core = mutable_realized_core(evidence->reference);
      if (relation.other_role ==
          mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence) {
        auto* object = mutable_internal_object(
            evidence_core, mwperf::InternalReferencePurposeV1::law_or_result);
        REQUIRE(object != nullptr);
        *object = source_subject;
        auto& source_core = mutable_realized_core(source->reference);
        const auto align = [&](const mwperf::InternalReferencePurposeV1 source_purpose,
                               const mwperf::InternalReferencePurposeV1 evidence_purpose) {
          auto* source_object =
              mutable_internal_object(source_core, source_purpose);
          if (source_object == nullptr) {
            return;
          }
          auto* evidence_object =
              mutable_internal_object(evidence_core, evidence_purpose);
          REQUIRE(evidence_object != nullptr);
          *evidence_object = *source_object;
        };
        align(mwperf::InternalReferencePurposeV1::configured_arrival_binding,
              mwperf::InternalReferencePurposeV1::configured_arrival_binding);
        align(mwperf::InternalReferencePurposeV1::selection_binding,
              mwperf::InternalReferencePurposeV1::selection_binding);
        align(mwperf::InternalReferencePurposeV1::mark_codec,
              mwperf::InternalReferencePurposeV1::mark_codec);
        align(mwperf::InternalReferencePurposeV1::state_codec,
              mwperf::InternalReferencePurposeV1::coordinate_codec);
        align(mwperf::InternalReferencePurposeV1::validity_basis,
              mwperf::InternalReferencePurposeV1::validity_basis);
      } else if (relation.other_role ==
                     mwperf::MetricSupportRoleV1::response_order_evidence &&
                 requirement.role ==
                     mwperf::MetricSupportRoleV1::response_envelope) {
        auto& source_core = mutable_realized_core(source->reference);
        for (const auto purpose :
             {mwperf::InternalReferencePurposeV1::lower_response_product,
              mwperf::InternalReferencePurposeV1::upper_response_product}) {
          auto* source_object = mutable_internal_object(source_core, purpose);
          auto* evidence_object =
              mutable_internal_object(evidence_core, purpose);
          REQUIRE(source_object != nullptr);
          REQUIRE(evidence_object != nullptr);
          *evidence_object = *source_object;
        }
      } else if (relation.other_role ==
                 mwperf::MetricSupportRoleV1::physical_transfer_evidence) {
        auto* source_object = mutable_internal_object(
            evidence_core,
            mwperf::InternalReferencePurposeV1::surrogate_source);
        REQUIRE(source_object != nullptr);
        *source_object = source_subject;
      }
    }
  }
  return bindings;
}

[[nodiscard]] bool route_has_arrival(
    const mwperf::MetricRouteAlternativeV1& route,
    const mwperf::ArrivalNeedKindV1 kind) {
  return std::any_of(
      route.arrival.all_of.begin(), route.arrival.all_of.end(),
      [kind](const mwperf::ArrivalAssumptionV1& value) {
        return value.kind == kind;
      });
}

[[nodiscard]] mwperf::SemanticTagV1 deployed_semantic(
    const mwperf::ReusableMetricLawRequirementV1& law) {
  return std::visit(
      [](const auto& value) -> mwperf::SemanticTagV1 {
        using Law = std::decay_t<decltype(value)>;
        if constexpr (
            std::is_same_v<Law, mwperf::FrameworkDerivedScalarRequirementV1> ||
            std::is_same_v<Law,
                           mwperf::SelectedInvariantMarginalRequirementV1> ||
            std::is_same_v<Law, mwperf::ExactPointResponseRequirementV1>) {
          return mwperf::SemanticTagV1::scalar_backlog_response;
        } else if constexpr (
            std::is_same_v<Law, mwperf::StationaryMarkedEdgeRequirementV1>) {
          return mwperf::SemanticTagV1::stationary_marked_edge;
        } else if constexpr (
            std::is_same_v<Law, mwperf::FiniteCylinderRequirementV1> ||
            std::is_same_v<Law, mwperf::PushforwardCountLawRequirementV1>) {
          return mwperf::SemanticTagV1::temporal_one_slot_continuation;
        } else if constexpr (
            std::is_same_v<Law, mwperf::ResidenceWordRequirementV1>) {
          return mwperf::SemanticTagV1::romr_residence_word_law;
        } else if constexpr (
            std::is_same_v<Law, mwperf::StoppedPathRequirementV1>) {
          return mwperf::SemanticTagV1::stopped_path_law;
        } else if constexpr (
            std::is_same_v<Law, mwperf::ExactRequestDecoderRequirementV1>) {
          return mwperf::SemanticTagV1::direct_metric_decoder;
        } else {
          return mwperf::SemanticTagV1::coupled_target_schedule_law;
        }
      },
      law);
}

enum class ConditioningFixtureModeV1 : std::uint8_t {
  positive_mass,
  declared_off_support,
  omitted,
};

struct PreviewFixtureOptionsV1 final {
  std::optional<mwperf::MetricMarkKindV1> omitted_mark;
  ConditioningFixtureModeV1 conditioning{
      ConditioningFixtureModeV1::positive_mass};
  bool prefer_predictive_arrival{false};
  bool prefer_exact_procedural_romr{false};
  bool wrong_fifo_label_codec{false};
  std::optional<mwperf::DistributionScope> preferred_transform_scope;
};

[[nodiscard]] mwperf::ArrivalCapabilities complete_arrival_capabilities() {
  mwperf::ArrivalCapabilities result;
  result.exact_positive_support = mwperf::CapabilityAvailability::available;
  result.sequential_normalized_sampler =
      mwperf::CapabilityAvailability::available;
  result.finite_enumerated_predictive_phase =
      mwperf::CapabilityAvailability::available;
  result.finite_enumerated_transition_row =
      mwperf::CapabilityAvailability::available;
  result.analytic_transform = mwperf::TransformCapability{
      mwperf::TransformKind::exact_pgf,
      mwperf::DistributionScope::joint_vector,
      {mwperf::ExactRational::zero(), mwperf::ExactRational::one(), true,
       true},
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_only};
  result.analytic_moments = mwperf::MomentCapability{
      BigNat{2U}, true, false,
      mwperf::AccessProvision::portable_only};
  result.stationary_phase_law =
      mwperf::StationaryPhaseLawStatus::proved_unique;
  result.exact_iid_joint_vector = mwperf::ExactIidJointVectorCapability{
      true, mwperf::AccessProvision::portable_only};
  result.exact_factorized_iid_generator =
      mwperf::ExactFactorizedIidGeneratorCapability{
          mwperf::AccessProvision::portable_only};
  result.exact_joint_moments = mwperf::MomentCapability{
      BigNat{2U}, true, false,
      mwperf::AccessProvision::portable_only};
  result.exact_coordinate_moments = mwperf::MomentCapability{
      BigNat{2U}, false, false,
      mwperf::AccessProvision::portable_only};
  result.exact_covariance = mwperf::CapabilityAvailability::available;
  result.exact_cross_moments = mwperf::CapabilityAvailability::available;
  result.exact_joint_distribution = mwperf::TransformCapability{
      mwperf::TransformKind::exact_pmf,
      mwperf::DistributionScope::joint_vector,
      {mwperf::ExactRational::zero(), mwperf::ExactRational::one(), true,
       true},
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_only};
  result.exact_coordinate_distributions = mwperf::TransformCapability{
      mwperf::TransformKind::exact_pmf,
      mwperf::DistributionScope::per_coordinate,
      {mwperf::ExactRational::zero(), mwperf::ExactRational::one(), true,
       true},
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_only};
  result.adjacent_batch_replay = mwperf::ReplayCapability{
      true, true, true, true,
      mwperf::AccessProvision::portable_and_process_local};
  result.unit_cube_transform = mwperf::UnitCubeCapability{
      BigNat{2U}, mwperf::UnitCubeBoundary::left_closed_right_open,
      mwperf::InverseCdfConvention::first_cumulative_mass_strictly_greater,
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_and_process_local};
  return result;
}

[[nodiscard]] mwperf::PlugDescriptorPreview preview_for_clause(
    const mwperf::MetricRequirements& requirements,
    const mwperf::ConstructionMethodV1 method =
        mwperf::ConstructionMethodV1::engineered_deterministic,
    const mwperf::ProducerModeV1 producer =
        mwperf::ProducerModeV1::in_process_builder,
    std::vector<mwperf::OptionalReportedEvidenceV1> optional_evidence = {},
    std::string provider_id = "c14.test.provider",
    const PreviewFixtureOptionsV1& options = {}) {
  REQUIRE(requirements.clauses().size() == 1U);
  const auto& clause = requirements.clauses().front();
  auto route_it = std::find_if(
      clause.route_alternatives.begin(), clause.route_alternatives.end(),
      [&options](const mwperf::MetricRouteAlternativeV1& route) {
        const bool matching_arrival =
            options.preferred_transform_scope.has_value()
                ? std::any_of(
                      route.arrival.all_of.begin(), route.arrival.all_of.end(),
                      [&options](const auto& assumption) {
                        return assumption.kind ==
                                   mwperf::ArrivalNeedKindV1::transform &&
                               assumption.distribution_scope ==
                                   options.preferred_transform_scope;
                      })
                : route_has_arrival(
                      route,
                      options.prefer_predictive_arrival
                          ? mwperf::ArrivalNeedKindV1::predictive_phase
                          : mwperf::ArrivalNeedKindV1::exact_iid_late);
        const auto expected_access =
            options.prefer_exact_procedural_romr
                ? mwperf::RuntimeAccessTagV1::procedural_residence_generator
                : mwperf::RuntimeAccessTagV1::finite_enumerated_row;
        return route.access.runtime_access == expected_access &&
               matching_arrival;
      });
  if (route_it == clause.route_alternatives.end() &&
      !clause.route_alternatives.empty()) {
    route_it = clause.route_alternatives.begin();
  }
  REQUIRE(route_it != clause.route_alternatives.end());
  const auto& route = *route_it;
  const auto semantic =
      options.prefer_exact_procedural_romr
          ? mwperf::SemanticTagV1::romr_residence_word_law
          : deployed_semantic(route.semantic.law);

  std::vector<mwperf::QueueId> targets;
  targets.reserve(clause.origin.ordered_targets.size());
  for (const auto& target : clause.origin.ordered_targets) {
    targets.push_back(target.queue_id);
  }

  std::vector<mwperf::MarkDescriptorV1> marks;
  marks.reserve(route.marks.size());
  for (const auto& mark : route.marks) {
    if (options.omitted_mark.has_value() &&
        mark.kind == *options.omitted_mark) {
      continue;
    }
    std::string common_group;
    if (mark.relation != mwperf::MarkRelationRequirementV1::individual) {
      common_group = "common-edge";
    }
    const bool fifo_label =
        mark.kind == mwperf::MetricMarkKindV1::class_label ||
        mark.kind == mwperf::MetricMarkKindV1::phase_label;
    const mwperf::CodecIdentityV1 codec =
        fifo_label && !options.wrong_fifo_label_codec
            ? mwperf::CodecIdentityV1{"mwperf.c23.typed_label", 1U}
            : mwperf::CodecIdentityV1{"c14.mark", 1U};
    mwperf::MarkDescriptorV1 descriptor{
        mark.kind, mark.latest_reveal_stage, codec, std::move(common_group)};
    // One provider mark may satisfy more than one requirement relation. The
    // manifest is a canonical descriptor set, so do not repeat the descriptor
    // when distinct requirements project to the same offered mark.
    if (std::find(marks.begin(), marks.end(), descriptor) == marks.end()) {
      marks.push_back(std::move(descriptor));
    }
  }

  std::vector<mwperf::HypothesisClaimV1> hypotheses;
  hypotheses.reserve(route.hypotheses.size());
  for (const auto& hypothesis : route.hypotheses) {
    mwperf::HypothesisClaimV1 claim = hypothesis.claim;
    if (claim.kind == mwperf::HypothesisKindV1::positive_conditioning_mass) {
      if (options.conditioning == ConditioningFixtureModeV1::omitted) {
        continue;
      }
      if (options.conditioning ==
          ConditioningFixtureModeV1::declared_off_support) {
        claim.convention_or_class = text_label("c14.off-support.return-zero");
      }
    }
    hypotheses.push_back(std::move(claim));
  }
  if (semantic ==
          mwperf::SemanticTagV1::temporal_one_slot_continuation &&
      clause.origin.selection_regime !=
          mwperf::MetricSelectionRegimeV1::transient &&
      std::none_of(hypotheses.begin(), hypotheses.end(), [](const auto& claim) {
        return claim.kind ==
               mwperf::HypothesisKindV1::c21_suspension_inversion;
      })) {
    hypotheses.push_back(
        {mwperf::HypothesisKindV1::c21_suspension_inversion, std::nullopt,
         std::nullopt, std::nullopt});
  }
  std::sort(hypotheses.begin(), hypotheses.end(),
            [](const auto& left, const auto& right) {
              return left.kind < right.kind;
            });

  // Descriptor-core collections are canonical sets even when the selected
  // requirements route was authored in a different (equivalent) order.
  // ArrivalNeedKindV1 is the first field in the canonical v1 encoding, and a
  // route cannot repeat one need kind.
  std::vector<mwperf::ArrivalAssumptionV1> arrival_assumptions =
      route.arrival.all_of;
  std::sort(arrival_assumptions.begin(), arrival_assumptions.end(),
            [](const auto& left, const auto& right) {
              return left.kind < right.kind;
            });
  std::sort(optional_evidence.begin(), optional_evidence.end(),
            [](const auto& left, const auto& right) {
              return left.kind < right.kind;
            });

  std::vector<mwperf::StateFieldDescriptorV1> state_fields{{
      mwperf::StateFieldKindV1::target_backlog,
      mwperf::FieldOwnershipV1::framework_exact,
      {"queue.big_nat", 1U}}};
  mwperf::PhaseSupportV1 phase{
      mwperf::PayloadPhaseKindV1::phase_free,
      mwperf::ConfiguredArrivalCompositionV1::iid_late_arrival,
      false,
      std::nullopt,
      mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
      std::nullopt};
  if (route_has_arrival(route,
                        mwperf::ArrivalNeedKindV1::predictive_phase)) {
    state_fields.push_back(
        {mwperf::StateFieldKindV1::configured_arrival_predictive_phase,
         mwperf::FieldOwnershipV1::framework_exact,
         {"arrival.phase", 1U}});
    phase = {mwperf::PayloadPhaseKindV1::predictive_phase_indexed,
             mwperf::ConfiguredArrivalCompositionV1::sequential_predictive_phase,
             true, mwperf::CodecIdentityV1{"arrival.phase", 1U},
             mwperf::FiniteHorizonCoverageKindV1::every_finite_horizon,
             std::nullopt};
  }

  const mwperf::PayloadClassV1 payload{
      semantic == mwperf::SemanticTagV1::scalar_backlog_response
          ? mwperf::PayloadClassTagV1::three_bin_scalar_response_v1
          : (semantic == mwperf::SemanticTagV1::direct_metric_decoder
                 ? mwperf::PayloadClassTagV1::direct_metric_payload_v1
                 : (semantic ==
                            mwperf::SemanticTagV1::romr_residence_word_law &&
                        route.access.runtime_access ==
                            mwperf::RuntimeAccessTagV1::
                                procedural_residence_generator
                    ? mwperf::PayloadClassTagV1::
                          registered_runtime_recipe_v1
                    : mwperf::PayloadClassTagV1::finite_law_tables_v1)),
      1U};
  const mwperf::V0DeclarationV1 v0{
      mwperf::V0DeclarationKindV1::structural_witness_required,
      "c14.test.factor", 1U};
  mwperf::MetricParameterDomainV1 parameter_domain =
      semantic == mwperf::SemanticTagV1::direct_metric_decoder
          ? mwperf::MetricParameterDomainV1{
                mwperf::ExactMetricDecoderDomainV1{
                    mwperf::ExactMetricDecoderKeyV1{
                        text_label("c14.test.exact-decoder")},
                    clause.origin.parameters}}
          : mwperf::MetricParameterDomainV1{
                mwperf::ExactMetricParameterSetV1{{
                    clause.origin.parameters}}};
  std::vector<mwperf::SelectionKindV1> selection_kinds =
      clause.selection.accepted_analysis_selections;
  switch (route.semantic.entrance) {
    case mwperf::EntranceLawRequirementV1::none:
      break;
    case mwperf::EntranceLawRequirementV1::configured_transient_initial:
      selection_kinds.push_back(mwperf::SelectionKindV1::transient_initial);
      break;
    case mwperf::EntranceLawRequirementV1::prescribed_entrance:
      selection_kinds.push_back(mwperf::SelectionKindV1::prescribed_entrance);
      break;
    case mwperf::EntranceLawRequirementV1::event_palm:
      selection_kinds.push_back(mwperf::SelectionKindV1::event_palm);
      break;
    case mwperf::EntranceLawRequirementV1::run_start_palm:
      selection_kinds.push_back(mwperf::SelectionKindV1::start_palm);
      break;
    case mwperf::EntranceLawRequirementV1::admission_palm:
      selection_kinds.push_back(mwperf::SelectionKindV1::admission_palm);
      break;
    case mwperf::EntranceLawRequirementV1::threshold_crossing_palm:
      selection_kinds.push_back(
          mwperf::SelectionKindV1::threshold_crossing_palm);
      break;
  }
  std::sort(selection_kinds.begin(), selection_kinds.end());
  selection_kinds.erase(
      std::unique(selection_kinds.begin(), selection_kinds.end()),
      selection_kinds.end());
  std::vector<mwperf::MetricSupportRoleRequirementV1> required_roles;
  if (semantic == mwperf::SemanticTagV1::direct_metric_decoder) {
    required_roles = {
        role_requirement(mwperf::MetricSupportRoleV1::deployed_payload,
                         mwperf::MetricTargetScopeV1::payload_targets,
                         mwperf::MetricResultScopeV1::surrogate_law,
                         mwperf::MetricEvidenceScopeV1::none),
        role_requirement(mwperf::MetricSupportRoleV1::direct_metric_value,
                         mwperf::MetricTargetScopeV1::exact_request_targets,
                         mwperf::MetricResultScopeV1::surrogate_law,
                         mwperf::MetricEvidenceScopeV1::deployed_surrogate_law),
        role_requirement(
            mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
            mwperf::MetricTargetScopeV1::exact_request_targets,
            mwperf::MetricResultScopeV1::not_a_metric_result,
            mwperf::MetricEvidenceScopeV1::validity_or_lift),
    };
  } else if (semantic == mwperf::SemanticTagV1::scalar_backlog_response) {
    auto deployed = role_requirement(
        mwperf::MetricSupportRoleV1::deployed_response,
        mwperf::MetricTargetScopeV1::deployed_singleton_target,
        mwperf::MetricResultScopeV1::surrogate_law,
        mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
    deployed.role_relations.push_back(
        {mwperf::MetricRoleRelationKindV1::subject,
         mwperf::MetricSupportRoleV1::raw_response});
    required_roles = {
        role_requirement(mwperf::MetricSupportRoleV1::deployed_payload,
                         mwperf::MetricTargetScopeV1::payload_targets,
                         mwperf::MetricResultScopeV1::surrogate_law,
                         mwperf::MetricEvidenceScopeV1::none),
        std::move(deployed),
        role_requirement(mwperf::MetricSupportRoleV1::raw_response,
                         mwperf::MetricTargetScopeV1::deployed_singleton_target,
                         mwperf::MetricResultScopeV1::proposal_raw,
                         mwperf::MetricEvidenceScopeV1::raw_static_proposal),
        role_requirement(
            mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
            mwperf::MetricTargetScopeV1::deployed_singleton_target,
            mwperf::MetricResultScopeV1::not_a_metric_result,
            mwperf::MetricEvidenceScopeV1::validity_or_lift),
    };
  } else {
    mwperf::MetricSupportRoleV1 primary_role =
        mwperf::MetricSupportRoleV1::temporal_continuation_law;
    switch (semantic) {
      case mwperf::SemanticTagV1::stationary_marked_edge:
        primary_role = mwperf::MetricSupportRoleV1::stationary_marked_edge_law;
        break;
      case mwperf::SemanticTagV1::staged_opportunity_flux_law:
        primary_role =
            mwperf::MetricSupportRoleV1::staged_opportunity_flux_law;
        break;
      case mwperf::SemanticTagV1::temporal_one_slot_continuation:
        primary_role = mwperf::MetricSupportRoleV1::temporal_continuation_law;
        break;
      case mwperf::SemanticTagV1::romr_residence_word_law:
        primary_role = mwperf::MetricSupportRoleV1::residence_word_law;
        break;
      case mwperf::SemanticTagV1::stopped_path_law:
        primary_role = mwperf::MetricSupportRoleV1::stopped_path_law;
        break;
      case mwperf::SemanticTagV1::coupled_target_schedule_law:
        primary_role = mwperf::MetricSupportRoleV1::coupled_schedule_law;
        break;
      case mwperf::SemanticTagV1::scalar_backlog_response:
      case mwperf::SemanticTagV1::direct_metric_decoder:
      case mwperf::SemanticTagV1::response_envelope_law:
        FAIL("unexpected semantic in reusable-law fixture");
        break;
    }
    auto primary = role_requirement(
        primary_role, mwperf::MetricTargetScopeV1::ordered_metric_targets,
        mwperf::MetricResultScopeV1::surrogate_law,
        mwperf::MetricEvidenceScopeV1::deployed_surrogate_law);
    if (primary_role ==
        mwperf::MetricSupportRoleV1::temporal_continuation_law) {
      primary.internal_relations.push_back(
          {mwperf::MetricRoleRelationKindV1::binding,
           clause.origin.selection_regime ==
                   mwperf::MetricSelectionRegimeV1::transient
               ? mwperf::InternalReferencePurposeV1::initial_binding
               : mwperf::InternalReferencePurposeV1::selection_binding});
    }
    required_roles = {
        role_requirement(mwperf::MetricSupportRoleV1::deployed_payload,
                         mwperf::MetricTargetScopeV1::payload_targets,
                         mwperf::MetricResultScopeV1::surrogate_law,
                         mwperf::MetricEvidenceScopeV1::none),
        std::move(primary),
        role_requirement(
            mwperf::MetricSupportRoleV1::reported_validity_or_lift_evidence,
            mwperf::MetricTargetScopeV1::ordered_metric_targets,
            mwperf::MetricResultScopeV1::not_a_metric_result,
            mwperf::MetricEvidenceScopeV1::validity_or_lift),
    };
    if (primary_role ==
        mwperf::MetricSupportRoleV1::stationary_marked_edge_law) {
      const auto primary_it = std::find_if(
          required_roles.begin(), required_roles.end(),
          [primary_role](const auto& role) { return role.role == primary_role; });
      REQUIRE(primary_it != required_roles.end());
      primary_it->role_relations.push_back(
          {mwperf::MetricRoleRelationKindV1::evidence,
           mwperf::MetricSupportRoleV1::stability_certificate});
      required_roles.push_back(role_requirement(
          mwperf::MetricSupportRoleV1::stability_certificate,
          mwperf::MetricTargetScopeV1::ordered_metric_targets,
          mwperf::MetricResultScopeV1::not_a_metric_result,
          mwperf::MetricEvidenceScopeV1::deployed_surrogate_law));
    }
  }
  mwperf::MetricSupportClauseV1 support{
      clause.origin.clause_id,
      clause.origin.kind,
      std::move(parameter_domain),
      targets,
      route.semantic.coupling,
      state_fields,
      marks,
      {selection_kinds, {}, {}},
      phase,
      payload,
      semantic,
      route.access.runtime_access,
      arrival_assumptions,
      hypotheses,
      clause.access.solver_regime,
      clause.accuracy.contract,
      {mwperf::StructuralErrorFormV1::exact,
       mwperf::MetricEvidenceScopeV1::none, mwperf::ExactRational::zero()},
      mwperf::MetricResultScopeV1::surrogate_law,
      v0,
      std::move(required_roles)};
  auto manifest_result =
      mwperf::MetricSupportManifest::from_clauses({std::move(support)});
  INFO((manifest_result
            ? std::string{}
            : manifest_result.error().code + ": " +
                  manifest_result.error().message));
  REQUIRE(manifest_result);
  auto manifest = std::make_shared<const mwperf::MetricSupportManifest>(
      std::move(manifest_result).value());

  mwperf::PlugDescriptorCore core{
      1U,
      {std::move(provider_id), "1"},
      {{{mwperf::ServiceFamily::pairwise_conflicts,
         mwperf::OptimizerId::mwis_branch_memo_exact}},
       {mwperf::TimingConvention::early_service_late_admission}},
      payload,
      semantic,
      route.access.runtime_access,
      targets,
      route.semantic.coupling,
      std::move(state_fields),
      std::move(marks),
      {std::move(selection_kinds), {}, {}},
      phase,
      {mwperf::TailRepresentationKindV1::exact_unbounded, std::nullopt,
       std::nullopt},
      std::move(arrival_assumptions),
      std::move(hypotheses),
      v0,
      std::move(optional_evidence),
      {clause.accuracy.contract},
      {mwperf::ConstructionResultScopeV1::surrogate_law,
       mwperf::ConstructionErrorScopeV1::deployed_surrogate_law},
      manifest->canonical_digest(),
      digest_of("core-placeholder")};
  auto core_digest = mwperf::canonical_plug_descriptor_core_digest_v1(core);
  REQUIRE(core_digest);
  core.core_digest = std::move(core_digest).value();

  const mwperf::PreviewPoliciesV1 policies{
      semantic != mwperf::SemanticTagV1::scalar_backlog_response
          ? mwperf::PointDeploymentPolicyV1::not_applicable
          : mwperf::PointDeploymentPolicyV1::deploy_raw_point,
      semantic != mwperf::SemanticTagV1::scalar_backlog_response
          ? mwperf::CoefficientCompletionPolicyV1::not_applicable
          : mwperf::CoefficientCompletionPolicyV1::require_complete_raw_points,
      mwperf::ProjectionPolicyV1::not_applicable,
      mwperf::RecodingPolicyV1::not_applicable,
      mwperf::EvidenceRolePolicyV1::exact_manifest_roles};
  mwperf::PlugDescriptorPreview preview{
      1U,
      std::move(core),
      method,
      producer,
      targets,
      policies,
      {{}, std::nullopt, std::nullopt, std::nullopt},
      std::move(manifest),
      digest_of("problem"),
      digest_of("parameters"),
      digest_of("budget"),
      digest_of("preview-placeholder")};
  auto preview_digest =
      mwperf::canonical_plug_descriptor_preview_digest_v1(preview);
  REQUIRE(preview_digest);
  preview.preview_digest = std::move(preview_digest).value();
  return preview;
}

void reseal_preview(mwperf::PlugDescriptorPreview& preview) {
  REQUIRE(preview.metric_support_manifest != nullptr);
  preview.core.metric_support_manifest_digest =
      preview.metric_support_manifest->canonical_digest();
  auto core_digest =
      mwperf::canonical_plug_descriptor_core_digest_v1(preview.core);
  REQUIRE(core_digest);
  preview.core.core_digest = std::move(core_digest).value();
  auto preview_digest =
      mwperf::canonical_plug_descriptor_preview_digest_v1(preview);
  REQUIRE(preview_digest);
  preview.preview_digest = std::move(preview_digest).value();
}

}  // namespace

static_assert(std::variant_size_v<mwperf::MetricRequest> == 29U);
static_assert(std::variant_size_v<mwperf::MetricRequestParametersV1> == 29U);
static_assert(std::variant_size_v<mwperf::RealizedReferenceV1> == 25U);
static_assert(
    std::variant_size_v<mwperf::DeployedResponseProductReferenceV1> == 3U);
static_assert(std::is_same_v<
              std::variant_alternative_t<
                  0U, mwperf::DeployedResponseProductReferenceV1>,
              mwperf::RawResponseProductRef>);
static_assert(std::is_same_v<
              std::variant_alternative_t<
                  1U, mwperf::DeployedResponseProductReferenceV1>,
              mwperf::NominalResponseProductRef>);
static_assert(std::is_same_v<
              std::variant_alternative_t<
                  2U, mwperf::DeployedResponseProductReferenceV1>,
              mwperf::RecodedResponseProductRef>);
static_assert(!std::is_constructible_v<
              mwperf::DeployedResponseProductReferenceV1,
              mwperf::ProjectionCenterProductRef>);
static_assert(!std::is_constructible_v<
              mwperf::DeployedResponseProductReferenceV1,
              mwperf::ProjectedMeanProductRef>);
static_assert(std::is_same_v<
              decltype(std::declval<const mwperf::FifoDelayRequestV1&>()
                           .header()),
              const mwperf::MetricRequestHeader&>);
static_assert(std::is_same_v<
              decltype(std::declval<const mwperf::FifoDelayRequestV1&>()
                           .parameters()),
              const mwperf::FifoDelayParametersV1&>);
static_assert(!std::is_assignable_v<
              decltype(std::declval<const mwperf::FifoDelayRequestV1&>()
                           .parameters()),
              mwperf::FifoDelayParametersV1>);
static_assert(!std::is_constructible_v<
              mwperf::StationaryEmptyProbabilityRequestV1,
              mwperf::MetricRequestHeader,
              mwperf::StationaryEmptyProbabilityParametersV1>);
static_assert(!std::is_default_constructible_v<
              mwperf::AcceptedCapabilityContract>);
static_assert(!std::is_aggregate_v<mwperf::AcceptedCapabilityContract>);
static_assert(!std::is_default_constructible_v<mwperf::MetricRequirements>);
static_assert(!std::is_aggregate_v<mwperf::MetricRequirements>);
static_assert(std::is_same_v<
              decltype(std::declval<const mwperf::MetricRequirements&>()
                           .clauses()),
              std::span<const mwperf::MetricRequirementClause>>);
static_assert(std::is_same_v<
              decltype(std::declval<const mwperf::AcceptedCapabilityContract&>()
                           .provider()),
              const mwperf::ProviderIdentityV1&>);
static_assert(std::is_same_v<
              decltype(std::declval<const mwperf::AcceptedCapabilityContract&>()
                           .structural_manifest()),
              const mwperf::MetricSupportManifest&>);

TEST_CASE("C14 parses every closed metric request alternative exactly",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  for (const MetricCase& fixture : kMetricCases) {
    CAPTURE(fixture.id, fixture.json);
    auto request = parse_request(
        catalog, fixture.json, fixture.coupled,
        fixture.transient ? transient_selection() : stationary_selection());
    INFO((request ? std::string{}
                  : request.error().code + ": " + request.error().message));
    REQUIRE(request);
    const mwperf::MetricRequestHeader& header =
        mwperf::metric_request_header(request.value());
    CHECK(header.metric_id == fixture.id);
    CHECK(header.kind == fixture.kind);
    CHECK(header.authored_index == 0U);
    CHECK(header.ordered_targets.size() == (fixture.coupled ? 2U : 1U));
    CHECK(header.context != nullptr);
    CHECK(header.context->resolution.level.max_states == BigNat{1000U});
    CHECK(header.provenance.json_pointer == "/metrics/0");
  }
}

TEST_CASE("C14 set-like request parameters canonicalize independently of order",
          "[c14][unit][property]") {
  struct SetCase final {
    const char* sorted;
    const char* permuted;
    bool coupled;
    bool transient;
  };
  const std::array<SetCase, 6U> cases{{
      {R"json({"id":"set","kind":"stationary_backlog_pgf","parameters":{"points":[0,0.5,1.1]}})json",
       R"json({"id":"set","kind":"stationary_backlog_pgf","parameters":{"points":[1.1,0,0.5]}})json",
       false, false},
      {R"json({"id":"set","kind":"backlog_conditioned_service","parameters":{"levels":[0,1,4]}})json",
       R"json({"id":"set","kind":"backlog_conditioned_service","parameters":{"levels":[4,0,1]}})json",
       false, false},
      {R"json({"id":"set","kind":"service_autocovariance","parameters":{"lags":[1,3,8]}})json",
       R"json({"id":"set","kind":"service_autocovariance","parameters":{"lags":[8,1,3]}})json",
       false, false},
      {R"json({"id":"set","kind":"lagged_cross_queue_covariance","parameters":{"lags":[1,2,7]}})json",
       R"json({"id":"set","kind":"lagged_cross_queue_covariance","parameters":{"lags":[7,1,2]}})json",
       true, false},
      {R"json({"id":"set","kind":"service_spectrum","parameters":{"frequencies":[0,0.5,1],"truncation_lag":9}})json",
       R"json({"id":"set","kind":"service_spectrum","parameters":{"frequencies":[1,0,0.5],"truncation_lag":9}})json",
       false, false},
      {R"json({"id":"set","kind":"transient_backlog_law","parameters":{"horizons":[0,2,7]}})json",
       R"json({"id":"set","kind":"transient_backlog_law","parameters":{"horizons":[7,0,2]}})json",
       false, true},
  }};

  const mwperf::QueueCatalog catalog = make_catalog();
  for (const auto& item : cases) {
    const std::string selection =
        item.transient ? transient_selection() : stationary_selection();
    auto sorted =
        parse_request(catalog, item.sorted, item.coupled, selection);
    auto permuted =
        parse_request(catalog, item.permuted, item.coupled, selection);
    REQUIRE(sorted);
    REQUIRE(permuted);
    CHECK(mwperf::metric_request_parameters(sorted.value()) ==
          mwperf::metric_request_parameters(permuted.value()));
    const auto sorted_requirements =
        mwperf::requirements_for_metric(sorted.value());
    const auto permuted_requirements =
        mwperf::requirements_for_metric(permuted.value());
    CHECK(mwperf::equivalent_metric_requirements(sorted_requirements,
                                                  permuted_requirements));
    const auto sorted_digest =
        mwperf::canonical_metric_requirements_digest(sorted_requirements);
    const auto permuted_digest =
        mwperf::canonical_metric_requirements_digest(permuted_requirements);
    REQUIRE(sorted_digest);
    REQUIRE(permuted_digest);
    CHECK(sorted_digest.value() == permuted_digest.value());
  }
}

TEST_CASE("C14 refines conditional request shapes without nullable ambiguity",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::array<std::string_view, 4U> fifo{{
      R"json({"id":"f0","kind":"fifo_delay","parameters":{"output":"pmf","horizon":8}})json",
      R"json({"id":"f1","kind":"fifo_delay","parameters":{"output":"tail","horizon":8}})json",
      R"json({"id":"f2","kind":"fifo_delay","parameters":{"output":"quantile","probability":0.75}})json",
      R"json({"id":"f3","kind":"fifo_delay","parameters":{"output":"moment","order":3}})json",
  }};
  for (std::size_t index = 0; index < fifo.size(); ++index) {
    auto request = parse_request(catalog, fifo[index]);
    REQUIRE(request);
    const auto* typed = std::get_if<mwperf::FifoDelayRequestV1>(&request.value());
    REQUIRE(typed != nullptr);
    CHECK(typed->parameters().output.index() == index);
  }

  const std::array<std::string_view, 4U> conditioned{{
      R"json({"id":"c0","kind":"fifo_delay_conditioned","parameters":{"output":"pmf","horizon":8,"condition":{"kind":"rank","value":1}}})json",
      R"json({"id":"c1","kind":"fifo_delay_conditioned","parameters":{"output":"tail","horizon":8,"condition":{"kind":"batch","value":2}}})json",
      R"json({"id":"c2","kind":"fifo_delay_conditioned","parameters":{"output":"quantile","probability":0.75,"condition":{"kind":"class","value":"gold"}}})json",
      R"json({"id":"c3","kind":"fifo_delay_conditioned","parameters":{"output":"moment","order":3,"condition":{"kind":"phase","value":"red"}}})json",
  }};
  for (std::size_t index = 0; index < conditioned.size(); ++index) {
    auto request = parse_request(catalog, conditioned[index]);
    REQUIRE(request);
    const auto* typed =
        std::get_if<mwperf::FifoDelayConditionedRequestV1>(&request.value());
    REQUIRE(typed != nullptr);
    CHECK(typed->parameters().condition.index() == index);
  }

  const std::array<std::string_view, 3U> joint_delay{{
      R"json({"id":"j0","kind":"joint_delay","parameters":{"sampling":"coincident","horizon":5}})json",
      R"json({"id":"j1","kind":"joint_delay","parameters":{"sampling":"independent_palm","horizon":5}})json",
      R"json({"id":"j2","kind":"joint_delay","parameters":{"sampling":"lagged","lag":0,"horizon":5}})json",
  }};
  for (std::size_t index = 0; index < joint_delay.size(); ++index) {
    auto request = parse_request(catalog, joint_delay[index], true);
    REQUIRE(request);
    const auto* typed = std::get_if<mwperf::JointDelayRequestV1>(&request.value());
    REQUIRE(typed != nullptr);
    CHECK(typed->parameters().sampling.index() == index);
  }
}

TEST_CASE("C14 parser preserves analysis solver and tolerance identity",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string_view metric =
      R"json({"id":"m","kind":"stationary_empty_probability","parameters":{}})json";

  const std::array<std::pair<std::string, mwperf::MetricSolverRegimeV1>, 4U>
      solvers{{
          {enumerated_solver(), mwperf::MetricSolverRegimeV1::enumerated},
          {analytic_solver(), mwperf::MetricSolverRegimeV1::analytic},
          {monte_carlo_solver(), mwperf::MetricSolverRegimeV1::monte_carlo},
          {direct_solver(), mwperf::MetricSolverRegimeV1::direct},
      }};
  for (const auto& [solver, expected] : solvers) {
    auto request = parse_request(catalog, metric, false,
                                 stationary_selection(), solver);
    REQUIRE(request);
    const auto& header = mwperf::metric_request_header(request.value());
    CHECK(header.solver_regime == expected);
    CHECK(header.context->resolution.tolerance.linear_residual_abs.has_value());
    CHECK(header.context->resolution.tolerance.integration_abs.has_value());
    CHECK(header.context->resolution.tolerance.tail_abs.has_value());
    CHECK(header.context->resolution.tolerance.fixed_point_abs.has_value());
  }
}

TEST_CASE("C14 JSON and YAML requests have the same semantic projection",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string metric =
      R"json({"id":"portable","kind":"service_spectrum","parameters":{"frequencies":[0,0.5],"truncation_lag":4}})json";
  auto json_analysis = parse_analysis(analysis_json(metric, false));
  REQUIRE(json_analysis);

  const std::string yaml = R"yaml(
analysis_schema_version: 1.0.0
targets: [q0]
metrics:
  - id: portable
    kind: service_spectrum
    parameters:
      frequencies: [0, 0.5]
      truncation_lag: 4
surrogate:
  id: c14-test-provider
  version: "1"
  parameters: {}
resolution:
  level: {max_states: 1000, max_row_atoms: 2000}
  tail:
    kind: certified_truncation
    parameters: {max_level: 64, max_tail_mass: 1e-9}
  phase: {max_phase_states: 128}
  optimizer: {max_calls: 4096, max_search_states_per_call: 65536}
  sampling: {max_generator_draws: 100000}
  tolerance:
    linear_residual_abs: 1e-12
    integration_abs: 2e-12
    tail_abs: 3e-12
    fixed_point_abs: 4e-12
selection: {kind: stationary_unique, parameters: {}}
solver:
  kind: enumerated
  parameters: {linear_method: dense_pivoted, max_iterations: 101}
)yaml";
  auto yaml_analysis = parse_analysis(yaml, ".yaml");
  REQUIRE(yaml_analysis);

  auto json_request = mwperf::parse_metric_request(
      json_analysis.value().metrics.front(), catalog);
  auto yaml_request = mwperf::parse_metric_request(
      yaml_analysis.value().metrics.front(), catalog);
  REQUIRE(json_request);
  REQUIRE(yaml_request);
  CHECK(mwperf::metric_request_header(json_request.value()).metric_id ==
        mwperf::metric_request_header(yaml_request.value()).metric_id);
  CHECK(mwperf::metric_request_header(json_request.value()).kind ==
        mwperf::metric_request_header(yaml_request.value()).kind);
  CHECK(mwperf::metric_request_header(json_request.value()).ordered_targets ==
        mwperf::metric_request_header(yaml_request.value()).ordered_targets);
  CHECK(mwperf::metric_request_parameters(json_request.value()) ==
        mwperf::metric_request_parameters(yaml_request.value()));
  const auto json_requirements =
      mwperf::requirements_for_metric(json_request.value());
  const auto yaml_requirements =
      mwperf::requirements_for_metric(yaml_request.value());
  CHECK(mwperf::equivalent_metric_requirements(json_requirements,
                                                yaml_requirements));
}

TEST_CASE("C14 authored metric indices come only from contextual source paths",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string first =
      R"json({"id":"first","kind":"stationary_throughput","parameters":{}})json";
  const std::string second =
      R"json({"id":"second","kind":"stationary_empty_probability","parameters":{}})json";
  const std::string joined = first + "," + second;
  auto analysis = parse_analysis(analysis_json(joined, false));
  REQUIRE(analysis);
  REQUIRE(analysis.value().metrics.size() == 2U);
  auto parsed_first =
      mwperf::parse_metric_request(analysis.value().metrics[0], catalog);
  auto parsed_second =
      mwperf::parse_metric_request(analysis.value().metrics[1], catalog);
  REQUIRE(parsed_first);
  REQUIRE(parsed_second);
  CHECK(mwperf::metric_request_header(parsed_first.value()).authored_index ==
        0U);
  CHECK(mwperf::metric_request_header(parsed_second.value()).authored_index ==
        1U);
}

TEST_CASE("C14 parser rejects unresolved targets cardinality and selection",
          "[c14][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();

  CHECK_FALSE(parse_request(
      catalog,
      R"json({"id":"scalar","kind":"stationary_throughput","parameters":{}})json",
      true));
  CHECK_FALSE(parse_request(
      catalog,
      R"json({"id":"coupled","kind":"joint_backlog_covariance","parameters":{}})json",
      false));

  auto unknown_analysis = parse_analysis(analysis_json(
      R"json({"id":"unknown","kind":"stationary_throughput","parameters":{}})json",
      false));
  REQUIRE(unknown_analysis);
  auto unknown_context = std::make_shared<mwperf::AnalysisContext>(
      *unknown_analysis.value().context);
  unknown_context->targets.queue_ids = {text_label("missing")};
  mwperf::MetricNode unknown = unknown_analysis.value().metrics.front();
  unknown.context = std::move(unknown_context);
  CHECK_FALSE(mwperf::parse_metric_request(unknown, catalog));

  CHECK_FALSE(parse_request(
      catalog,
      R"json({"id":"stationary","kind":"stationary_empty_probability","parameters":{}})json",
      false, transient_selection()));
  CHECK_FALSE(parse_request(
      catalog,
      R"json({"id":"transient","kind":"transient_backlog_law","parameters":{"horizons":[0]}})json",
      false, stationary_selection()));

  auto ordinary = parse_analysis(analysis_json(
      R"json({"id":"guarded","kind":"stationary_throughput","parameters":{}})json",
      false));
  REQUIRE(ordinary);
  mwperf::MetricNode null_context = ordinary.value().metrics.front();
  null_context.context.reset();
  const auto null_result =
      mwperf::parse_metric_request(null_context, catalog);
  REQUIRE_FALSE(null_result);
  CHECK(null_result.error().code == "metric_request_null_context");

  mwperf::MetricNode mismatched_id = ordinary.value().metrics.front();
  mismatched_id.id = "different";
  const auto mismatch_result =
      mwperf::parse_metric_request(mismatched_id, catalog);
  REQUIRE_FALSE(mismatch_result);
  CHECK(mismatch_result.error().code ==
        "metric_request_source_identity_mismatch");
}

TEST_CASE("C03 and C14 reject malformed closed wire combinations",
          "[c14][negative]") {
  const std::array<std::string_view, 12U> malformed{{
      R"json({"id":"x","kind":"unknown_metric","parameters":{}})json",
      R"json({"id":"x","kind":"stationary_throughput","parameters":{"evidence":"v2"}})json",
      R"json({"id":"x","kind":"service_autocovariance","parameters":{"lags":[]}})json",
      R"json({"id":"x","kind":"service_autocovariance","parameters":{"lags":[0]}})json",
      R"json({"id":"x","kind":"service_window_count","parameters":{"width":0}})json",
      R"json({"id":"x","kind":"fifo_delay","parameters":{"output":"quantile","probability":0}})json",
      R"json({"id":"x","kind":"fifo_delay","parameters":{"output":"pmf","horizon":null}})json",
      R"json({"id":"x","kind":"fifo_delay_conditioned","parameters":{"output":"pmf","horizon":3,"condition":{"kind":"rank","value":0}}})json",
      R"json({"id":"x","kind":"fifo_delay_conditioned","parameters":{"output":"pmf","horizon":3,"condition":{"kind":"batch","value":"2"}}})json",
      R"json({"id":"x","kind":"mean_binary_run","parameters":{"predicate":"busy","threshold":1}})json",
      R"json({"id":"x","kind":"mean_binary_run","parameters":{"predicate":"threshold_above"}})json",
      R"json({"id":"x","kind":"joint_delay","parameters":{"sampling":"coincident","lag":1,"horizon":2}})json",
  }};
  for (const std::string_view metric : malformed) {
    CAPTURE(metric);
    CHECK_FALSE(parse_analysis(analysis_json(metric, false)));
  }

  const std::string duplicate_targets = analysis_json(
      R"json({"id":"x","kind":"joint_backlog_covariance","parameters":{}})json",
      true);
  std::string duplicate = duplicate_targets;
  const std::size_t position = duplicate.find("[\"q0\",\"q1\"]");
  REQUIRE(position != std::string::npos);
  duplicate.replace(position, std::string("[\"q0\",\"q1\"]").size(),
                    "[\"q0\",\"q0\"]");
  CHECK_FALSE(parse_analysis(duplicate));

  std::string duplicate_key = analysis_json(
      R"json({"id":"x","kind":"stationary_throughput","kind":"stationary_empty_probability","parameters":{}})json",
      false);
  TemporaryAnalysis duplicate_file(duplicate_key);
  CHECK_FALSE(mwperf::load_document(duplicate_file.path()));
}

TEST_CASE("C14 maps all request kinds to nonvacuous V0 clauses",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  for (const MetricCase& fixture : kMetricCases) {
    CAPTURE(fixture.id);
    auto request = parse_request(
        catalog, fixture.json, fixture.coupled,
        fixture.transient ? transient_selection() : stationary_selection());
    REQUIRE(request);
    const mwperf::MetricRequirements requirements =
        mwperf::requirements_for_metric(request.value());
    REQUIRE(requirements.clauses().size() == 1U);
    const mwperf::MetricRequirementClause& clause = requirements.clauses()[0];
    CHECK(clause.origin.kind == fixture.kind);
    CHECK(clause.origin.clause_id.metric_id == fixture.id);
    CHECK_FALSE(clause.route_alternatives.empty());
    CHECK(clause.validity.mandatory_v0);
    CHECK(requirements.mandatory_v0());
    CHECK(requirements.regime_compatibility().kind ==
          mwperf::RegimeCompatibilityKindV1::compatible);
  }
}

TEST_CASE("C14 requirements preserve stationary temporal edge and Palm distinctions",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();

  auto backlog_pmf = parse_request(
      catalog,
      R"json({"id":"pmf","kind":"stationary_backlog_pmf","parameters":{}})json");
  auto persistence = parse_request(
      catalog,
      R"json({"id":"persist","kind":"service_persistence","parameters":{}})json");
  auto increment = parse_request(
      catalog,
      R"json({"id":"inc","kind":"stationary_edge_reward","parameters":{"reward":"increment","moment_order":1}})json");
  auto fifo = parse_request(
      catalog,
      R"json({"id":"fifo","kind":"fifo_delay","parameters":{"output":"tail","horizon":20}})json");
  auto first_hit = parse_request(
      catalog,
      R"json({"id":"hit","kind":"first_hit","parameters":{"set":{"kind":"equal","level":2},"horizon":10,"include_mean":false}})json",
      false, transient_selection());
  auto run = parse_request(
      catalog,
      R"json({"id":"run","kind":"mean_binary_run","parameters":{"predicate":"busy"}})json");
  auto mean_gap = parse_request(
      catalog,
      R"json({"id":"mean-gap","kind":"mean_event_gap","parameters":{"event":"departure"}})json");
  auto gap_distribution = parse_request(
      catalog,
      R"json({"id":"gap-law","kind":"event_gap_distribution","parameters":{"event":"departure","horizon":11}})json");
  REQUIRE(backlog_pmf);
  REQUIRE(persistence);
  REQUIRE(increment);
  REQUIRE(fifo);
  REQUIRE(first_hit);
  REQUIRE(run);
  REQUIRE(mean_gap);
  REQUIRE(gap_distribution);

  const auto pmf_req = mwperf::requirements_for_metric(backlog_pmf.value());
  const auto persistence_req =
      mwperf::requirements_for_metric(persistence.value());
  const auto increment_req = mwperf::requirements_for_metric(increment.value());
  const auto fifo_req = mwperf::requirements_for_metric(fifo.value());
  const auto hit_req = mwperf::requirements_for_metric(first_hit.value());
  const auto run_req = mwperf::requirements_for_metric(run.value());
  const auto mean_gap_req =
      mwperf::requirements_for_metric(mean_gap.value());
  const auto gap_distribution_req =
      mwperf::requirements_for_metric(gap_distribution.value());

  CHECK(has_law_kind(pmf_req.clauses()[0],
                     mwperf::ReusableMetricLawKindV1::selected_invariant_marginal));
  CHECK_FALSE(has_law_kind(
      pmf_req.clauses()[0],
      mwperf::ReusableMetricLawKindV1::finite_cylinder_from_temporal_continuation));
  CHECK(has_law_kind(
      persistence_req.clauses()[0],
      mwperf::ReusableMetricLawKindV1::finite_cylinder_from_temporal_continuation));
  CHECK(has_mark(persistence_req.clauses()[0],
                 mwperf::MetricMarkKindV1::actual_departure,
                 mwperf::MetricRevealStageV1::decision));
  CHECK(has_mark(increment_req.clauses()[0],
                 mwperf::MetricMarkKindV1::actual_departure,
                 mwperf::MetricRevealStageV1::decision));
  CHECK(has_mark(increment_req.clauses()[0],
                 mwperf::MetricMarkKindV1::arrival_batch,
                 mwperf::MetricRevealStageV1::arrival));
  CHECK(fifo_req.clauses()[0].selection.entrance ==
        mwperf::EntranceLawRequirementV1::admission_palm);
  CHECK(has_hypothesis(fifo_req.clauses()[0], mwperf::HypothesisKindV1::fifo));
  CHECK_FALSE(has_hypothesis(hit_req.clauses()[0],
                             mwperf::HypothesisKindV1::proper_stationary));
  CHECK(run_req.clauses()[0].selection.entrance ==
        mwperf::EntranceLawRequirementV1::none);
  CHECK(has_hypothesis(run_req.clauses()[0],
                       mwperf::HypothesisKindV1::positive_start_intensity));
  CHECK(has_hypothesis(run_req.clauses()[0],
                       mwperf::HypothesisKindV1::finite_start_component));
  CHECK(has_mark(mean_gap_req.clauses()[0],
                 mwperf::MetricMarkKindV1::active_component,
                 mwperf::MetricRevealStageV1::predecision));
  CHECK_FALSE(has_mark(gap_distribution_req.clauses()[0],
                       mwperf::MetricMarkKindV1::active_component,
                       mwperf::MetricRevealStageV1::entrance_label));

  auto run_distribution = parse_request(
      catalog,
      R"json({"id":"run-law","kind":"binary_run_distribution","parameters":{"predicate":"busy","horizon":11}})json");
  REQUIRE(run_distribution);
  const auto run_distribution_requirements =
      mwperf::requirements_for_metric(run_distribution.value());
  CHECK_FALSE(has_hypothesis(
      run_distribution_requirements.clauses()[0],
      mwperf::HypothesisKindV1::finite_start_component));
}

TEST_CASE("C14 negotiates every exact procedural ROMR suspension route",
          "[c14][integration][romr]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  std::vector<mwperf::MetricKindV1> accepted_kinds;
  for (const MetricCase& fixture : kMetricCases) {
    auto request = parse_request(
        catalog, fixture.json, fixture.coupled,
        fixture.transient ? transient_selection() : stationary_selection());
    REQUIRE(request);
    const auto requirements =
        mwperf::requirements_for_metric(request.value());
    REQUIRE(requirements.clauses().size() == 1U);
    const bool has_procedural_romr_route = std::ranges::any_of(
        requirements.clauses().front().route_alternatives,
        [](const mwperf::MetricRouteAlternativeV1& route) {
          return route.access.runtime_access ==
                 mwperf::RuntimeAccessTagV1::procedural_residence_generator;
        });
    if (!has_procedural_romr_route) {
      continue;
    }

    PreviewFixtureOptionsV1 options;
    options.prefer_exact_procedural_romr = true;
    CAPTURE(fixture.id);
    const auto preview = preview_for_clause(
        requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
        mwperf::ProducerModeV1::in_process_builder, {},
        std::string{"c14.test.romr."} + fixture.id, options);
    const auto decision = mwperf::negotiate_capabilities(
        requirements, preview, complete_arrival_capabilities());
    INFO(mwperf::explain_capability_failure(decision).message);
    REQUIRE(mwperf::capability_decision_is_accepted(decision));
    const auto* contract = mwperf::accepted_capability_contract(decision);
    REQUIRE(contract != nullptr);
    CHECK(contract->semantic() ==
          mwperf::SemanticTagV1::romr_residence_word_law);
    CHECK(contract->runtime_access() ==
          mwperf::RuntimeAccessTagV1::procedural_residence_generator);
    accepted_kinds.push_back(fixture.kind);
  }

  // This is the complete set of analysis-v1 routes deliberately marked
  // residence-capable. A new route must opt in explicitly and join this
  // normal-negotiation regression rather than inheriting ROMR compatibility
  // from an axis-wise semantic shortcut.
  CHECK(accepted_kinds.size() == 21U);
}

TEST_CASE("C14 does not promote inexact or sampler ROMR access",
          "[c14][integration][negative][romr]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"persist","kind":"service_persistence","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  PreviewFixtureOptionsV1 options;
  options.prefer_exact_procedural_romr = true;
  const auto exact = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.romr-negative", options);

  const auto mutate = [&](const mwperf::StructuralErrorFormV1 error_form,
                          const mwperf::RuntimeAccessTagV1 access) {
    auto preview = exact;
    std::vector<mwperf::MetricSupportClauseV1> clauses(
        preview.metric_support_manifest->clauses().begin(),
        preview.metric_support_manifest->clauses().end());
    REQUIRE(clauses.size() == 1U);
    clauses.front().runtime_access = access;
    clauses.front().error_promise.form = error_form;
    auto manifest =
        mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
    REQUIRE(manifest);
    preview.metric_support_manifest =
        std::make_shared<const mwperf::MetricSupportManifest>(
            std::move(manifest).value());
    preview.core.runtime_access = access;
    reseal_preview(preview);
    return mwperf::negotiate_capabilities(
        requirements, preview, complete_arrival_capabilities());
  };

  const auto uncertified = mutate(
      mwperf::StructuralErrorFormV1::numerical_residual,
      mwperf::RuntimeAccessTagV1::procedural_residence_generator);
  CHECK_FALSE(mwperf::capability_decision_is_accepted(uncertified));

  const auto sampler = mutate(
      mwperf::StructuralErrorFormV1::exact,
      mwperf::RuntimeAccessTagV1::normalized_conditional_sampler);
  CHECK_FALSE(mwperf::capability_decision_is_accepted(sampler));
}

TEST_CASE("C14 exact procedural ROMR requires packet class labels",
          "[c14][integration][negative][romr][marks]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"class-delay","kind":"fifo_delay_conditioned","parameters":{"output":"quantile","probability":0.75,"condition":{"kind":"class","value":"gold"}}})json");
  REQUIRE(request);
  const auto requirements =
      mwperf::requirements_for_metric(request.value());

  PreviewFixtureOptionsV1 positive_options;
  positive_options.prefer_exact_procedural_romr = true;
  const auto positive = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.romr-class-label", positive_options);
  CHECK(std::ranges::any_of(
      positive.core.marks, [](const mwperf::MarkDescriptorV1& mark) {
        return mark.kind == mwperf::MetricMarkKindV1::class_label;
      }));
  const auto positive_decision = mwperf::negotiate_capabilities(
      requirements, positive, complete_arrival_capabilities());
  INFO(mwperf::explain_capability_failure(positive_decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(positive_decision));

  PreviewFixtureOptionsV1 wrong_codec_options = positive_options;
  wrong_codec_options.wrong_fifo_label_codec = true;
  const auto wrong_codec = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.romr-wrong-class-label-codec", wrong_codec_options);
  const auto wrong_codec_decision = mwperf::negotiate_capabilities(
      requirements, wrong_codec, complete_arrival_capabilities());
  REQUIRE_FALSE(
      mwperf::capability_decision_is_accepted(wrong_codec_decision));

  PreviewFixtureOptionsV1 missing_options = positive_options;
  missing_options.omitted_mark = mwperf::MetricMarkKindV1::class_label;
  const auto missing = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.romr-missing-class-label", missing_options);
  const auto missing_decision = mwperf::negotiate_capabilities(
      requirements, missing, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(missing_decision));
  const auto* rejected =
      mwperf::rejected_capability_decision(missing_decision);
  REQUIRE(rejected != nullptr);
  CHECK(std::ranges::any_of(
      rejected->ordered_failures,
      [](const mwperf::CapabilityFailureV1& failure) {
        return failure.axis == mwperf::CapabilityAxisV1::mark &&
               failure.kind ==
                   mwperf::CapabilityFailureKindV1::missing_mark;
      }));
}

TEST_CASE("C14 spectrum keeps a symbolic inclusive finite-cylinder range",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string enormous = "184467440737095516170000000000000000001";
  auto request = parse_request(
      catalog,
      std::string(R"json({"id":"s","kind":"service_spectrum","parameters":{"frequencies":[0,1],"truncation_lag":)json") +
          enormous + "}}");
  REQUIRE(request);
  const mwperf::MetricRequirements requirements =
      mwperf::requirements_for_metric(request.value());
  REQUIRE(requirements.cylinder_summaries().size() == 1U);
  const auto* range = std::get_if<mwperf::InclusiveCylinderThroughV1>(
      &requirements.cylinder_summaries()[0].coverage);
  REQUIRE(range != nullptr);
  CHECK(range->maximum_offset == exact_nat(enormous));
  CHECK(requirements.cylinder_summaries()[0].maximum_offset ==
        exact_nat(enormous));
}

TEST_CASE("C14 PGF points above one remain exact provider-domain requests",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"pgf","kind":"stationary_backlog_pgf","parameters":{"points":[1.1]}})json");
  REQUIRE(request);
  const auto* typed = std::get_if<mwperf::StationaryBacklogPgfRequestV1>(
      &request.value());
  REQUIRE(typed != nullptr);
  REQUIRE(typed->parameters().points.size() == 1U);
  auto expected = mwperf::ExactRational::make(mwperf::BigInt{11},
                                               mwperf::BigInt{10});
  REQUIRE(expected);
  CHECK(typed->parameters().points[0] == expected.value());

  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto preview = preview_for_clause(requirements);
  REQUIRE(preview.metric_support_manifest != nullptr);
  REQUIRE(preview.metric_support_manifest->clauses().size() == 1U);
  const auto* parameter_set =
      std::get_if<mwperf::ExactMetricParameterSetV1>(
          &preview.metric_support_manifest->clauses()[0].parameter_domain);
  REQUIRE(parameter_set != nullptr);
  REQUIRE(parameter_set->values.size() == 1U);
  const auto& manifest_parameters =
      std::get<mwperf::StationaryBacklogPgfParametersV1>(
          parameter_set->values[0]);
  CHECK(manifest_parameters.points[0] == expected.value());
}

TEST_CASE("C14 PGF transform routes distinguish coordinate and joint domains",
          "[c14][integration][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"pgf-domain","kind":"stationary_backlog_pgf","parameters":{"points":[1.1,1.2]}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());

  PreviewFixtureOptionsV1 coordinate_options;
  coordinate_options.preferred_transform_scope =
      mwperf::DistributionScope::per_coordinate;
  const auto coordinate_preview = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.coordinate-pgf", coordinate_options);
  auto coordinate_arrivals = complete_arrival_capabilities();
  coordinate_arrivals.analytic_transform = mwperf::TransformCapability{
      mwperf::TransformKind::exact_pgf,
      mwperf::DistributionScope::per_coordinate,
      {exact_ratio(11, 10), exact_ratio(6, 5), true, true},
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_only};
  const auto coordinate_decision = mwperf::negotiate_capabilities(
      requirements, coordinate_preview, coordinate_arrivals);
  INFO(mwperf::explain_capability_failure(coordinate_decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(coordinate_decision));

  PreviewFixtureOptionsV1 joint_options;
  joint_options.preferred_transform_scope =
      mwperf::DistributionScope::joint_vector;
  const auto joint_preview = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.joint-pgf", joint_options);
  auto joint_missing_one = complete_arrival_capabilities();
  joint_missing_one.analytic_transform = mwperf::TransformCapability{
      mwperf::TransformKind::exact_pgf,
      mwperf::DistributionScope::joint_vector,
      {exact_ratio(11, 10), exact_ratio(6, 5), true, true},
      mwperf::PhaseArgumentRequirement::phase_free,
      mwperf::AccessProvision::portable_only};
  const auto missing_one_decision = mwperf::negotiate_capabilities(
      requirements, joint_preview, joint_missing_one);
  REQUIRE_FALSE(
      mwperf::capability_decision_is_accepted(missing_one_decision));
  const auto* missing_one =
      mwperf::rejected_capability_decision(missing_one_decision);
  REQUIRE(missing_one != nullptr);
  CHECK(std::any_of(
      missing_one->ordered_failures.begin(),
      missing_one->ordered_failures.end(), [](const auto& failure) {
        return failure.axis == mwperf::CapabilityAxisV1::arrival;
      }));

  joint_missing_one.analytic_transform->domain =
      {mwperf::ExactRational::one(), exact_ratio(6, 5), true, true};
  const auto joint_decision = mwperf::negotiate_capabilities(
      requirements, joint_preview, joint_missing_one);
  INFO(mwperf::explain_capability_failure(joint_decision).message);
  CHECK(mwperf::capability_decision_is_accepted(joint_decision));
}

TEST_CASE("C14 requirement map keeps scalar coupled and hypothesis boundaries",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto sojourn = parse_request(
      catalog,
      R"json({"id":"sojourn","kind":"mean_sojourn","parameters":{}})json");
  auto counterfactual = parse_request(
      catalog,
      R"json({"id":"cf","kind":"counterfactual_opportunity_gap","parameters":{"convention_id":"empty-service-zero","horizon":3}})json");
  auto joint = parse_request(
      catalog,
      R"json({"id":"joint","kind":"joint_backlog_event","parameters":{"relation":"all_at_or_above","thresholds":[1,1]}})json",
      true);
  auto schedule = parse_request(
      catalog,
      R"json({"id":"schedule","kind":"ordered_schedule_sequence","parameters":{"horizon":2,"retain_full_schedule":true}})json",
      true, transient_selection());
  auto quantile = parse_request(
      catalog,
      R"json({"id":"q","kind":"stationary_backlog_quantile","parameters":{"probability":0.5}})json");
  REQUIRE(sojourn);
  REQUIRE(counterfactual);
  REQUIRE(joint);
  REQUIRE(schedule);
  REQUIRE(quantile);

  const auto sojourn_req = mwperf::requirements_for_metric(sojourn.value());
  CHECK_FALSE(has_hypothesis(sojourn_req.clauses()[0],
                             mwperf::HypothesisKindV1::fifo));
  CHECK(has_hypothesis(sojourn_req.clauses()[0],
                       mwperf::HypothesisKindV1::lossless));
  CHECK(has_hypothesis(sojourn_req.clauses()[0],
                       mwperf::HypothesisKindV1::positive_finite_intensity));
  REQUIRE_FALSE(sojourn_req.clauses()[0].moments.empty());
  CHECK(sojourn_req.clauses()[0].moments[0].variable ==
        mwperf::MomentVariableV1::backlog);

  const auto counterfactual_req =
      mwperf::requirements_for_metric(counterfactual.value());
  CHECK(has_hypothesis(
      counterfactual_req.clauses()[0],
      mwperf::HypothesisKindV1::counterfactual_empty_convention));
  const auto joint_req = mwperf::requirements_for_metric(joint.value());
  CHECK(joint_req.clauses()[0].coupling ==
        mwperf::TargetCouplingV1::common_schedule_projection);
  CHECK(has_hypothesis(joint_req.clauses()[0],
                       mwperf::HypothesisKindV1::common_schedule));
  const auto schedule_req =
      mwperf::requirements_for_metric(schedule.value());
  CHECK(schedule_req.clauses()[0].coupling ==
        mwperf::TargetCouplingV1::full_schedule_identity);
  CHECK(has_mark(schedule_req.clauses()[0],
                 mwperf::MetricMarkKindV1::full_schedule,
                 mwperf::MetricRevealStageV1::decision));

  const auto* typed_quantile =
      std::get_if<mwperf::StationaryBacklogQuantileRequestV1>(
          &quantile.value());
  REQUIRE(typed_quantile != nullptr);
  CHECK(typed_quantile->parameters().convention ==
        mwperf::DiscreteQuantileConventionV1::lower_inverse_cdf);
}

TEST_CASE("C14 Monte Carlo accuracy keeps interval assumptions distinct",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string metric =
      R"json({"id":"binary","kind":"stationary_empty_probability","parameters":{}})json";
  auto exact = parse_request(catalog, metric, false, stationary_selection(),
                             monte_carlo_solver("exact_binomial"));
  auto hoeffding = parse_request(catalog, metric, false,
                                 stationary_selection(),
                                 monte_carlo_solver("hoeffding"));
  auto none = parse_request(catalog, metric, false, stationary_selection(),
                            monte_carlo_solver("none"));
  REQUIRE(exact);
  REQUIRE(hoeffding);
  REQUIRE(none);
  const auto exact_req = mwperf::requirements_for_metric(exact.value());
  const auto hoeffding_req =
      mwperf::requirements_for_metric(hoeffding.value());
  const auto none_req = mwperf::requirements_for_metric(none.value());
  const auto& exact_accuracy = std::get<mwperf::MonteCarloAccuracyV1>(
      exact_req.clauses()[0].accuracy.contract);
  const auto& hoeffding_accuracy = std::get<mwperf::MonteCarloAccuracyV1>(
      hoeffding_req.clauses()[0].accuracy.contract);
  const auto& none_accuracy = std::get<mwperf::MonteCarloAccuracyV1>(
      none_req.clauses()[0].accuracy.contract);
  CHECK(exact_accuracy.interval ==
        mwperf::StatisticalIntervalKindV1::exact_binomial);
  CHECK(exact_accuracy.estimand ==
        mwperf::StatisticalEstimandKindV1::binary_proportion);
  CHECK(exact_accuracy.almost_sure_lower == mwperf::ExactRational::zero());
  CHECK(exact_accuracy.almost_sure_upper == mwperf::ExactRational::one());
  CHECK(hoeffding_accuracy.interval ==
        mwperf::StatisticalIntervalKindV1::hoeffding);
  CHECK(hoeffding_accuracy.almost_sure_lower.has_value());
  CHECK(hoeffding_accuracy.almost_sure_upper.has_value());
  CHECK(none_accuracy.interval == mwperf::StatisticalIntervalKindV1::none);
  CHECK_FALSE(none_req.clauses()[0]
                  .accuracy.require_declared_error_or_certificate);
}

TEST_CASE("C14 aggregation is commutative associative and idempotent",
          "[c14][property]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::array<std::size_t, 3U> indices{{5U, 12U, 14U}};
  std::vector<mwperf::MetricRequest> requests = parsed_requests(catalog, indices);

  const auto abc = mwperf::aggregate_metric_requirements(requests);
  std::reverse(requests.begin(), requests.end());
  const auto cba = mwperf::aggregate_metric_requirements(requests);
  CHECK(mwperf::equivalent_metric_requirements(abc, cba));
  REQUIRE(mwperf::canonical_metric_requirements_digest(abc));
  REQUIRE(mwperf::canonical_metric_requirements_digest(cba));
  CHECK(mwperf::canonical_metric_requirements_digest(abc).value() ==
        mwperf::canonical_metric_requirements_digest(cba).value());

  std::vector<mwperf::MetricRequest> duplicate = requests;
  duplicate.push_back(requests.front());
  const auto with_duplicate =
      mwperf::aggregate_metric_requirements(duplicate);
  CHECK(mwperf::equivalent_metric_requirements(abc, with_duplicate));

  const std::array<std::size_t, 2U> first_two{{5U, 12U}};
  const auto ab = mwperf::aggregate_metric_requirements(
      parsed_requests(catalog, first_two));
  CHECK(ab.clauses().size() == 2U);
  CHECK(abc.clauses().size() == 3U);
  CHECK(abc.target_union().size() >= ab.target_union().size());
  CHECK(abc.mark_union().size() >= ab.mark_union().size());
  CHECK(abc.cylinder_summaries().size() >= ab.cylinder_summaries().size());
}

TEST_CASE("C14 aggregation records incompatible regimes without dropping clauses",
          "[c14][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto stationary = parse_request(
      catalog,
      R"json({"id":"stationary","kind":"stationary_backlog_pmf","parameters":{}})json");
  auto transient = parse_request(
      catalog,
      R"json({"id":"transient","kind":"transient_backlog_law","parameters":{"horizons":[0,2]}})json",
      false, transient_selection());
  REQUIRE(stationary);
  REQUIRE(transient);
  std::array<mwperf::MetricRequest, 2U> selection_mix{
      stationary.value(), transient.value()};
  const auto selection_join =
      mwperf::aggregate_metric_requirements(selection_mix);
  CHECK(selection_join.clauses().size() == 2U);
  CHECK(selection_join.regime_compatibility().kind ==
        mwperf::RegimeCompatibilityKindV1::incompatible_selection);

  auto enumerated = parse_request(
      catalog,
      R"json({"id":"enum","kind":"stationary_backlog_pmf","parameters":{}})json");
  auto analytic = parse_request(
      catalog,
      R"json({"id":"analytic","kind":"stationary_backlog_pmf","parameters":{}})json",
      false, stationary_selection(), analytic_solver());
  REQUIRE(enumerated);
  REQUIRE(analytic);
  std::array<mwperf::MetricRequest, 2U> solver_mix{enumerated.value(),
                                                  analytic.value()};
  const auto solver_join = mwperf::aggregate_metric_requirements(solver_mix);
  CHECK(solver_join.clauses().size() == 2U);
  CHECK(solver_join.regime_compatibility().kind ==
        mwperf::RegimeCompatibilityKindV1::incompatible_solver);

  const std::span<const mwperf::MetricRequest> empty;
  const auto empty_join = mwperf::aggregate_metric_requirements(empty);
  CHECK(empty_join.clauses().empty());
  CHECK(empty_join.regime_compatibility().kind ==
        mwperf::RegimeCompatibilityKindV1::invalid_empty_request_set);
}

TEST_CASE("C14 aggregation takes maxima only within compatible families",
          "[c14][property]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto lag2 = parse_request(
      catalog,
      R"json({"id":"lag2","kind":"service_autocovariance","parameters":{"lags":[2]}})json");
  auto lag7 = parse_request(
      catalog,
      R"json({"id":"lag7","kind":"service_autocovariance","parameters":{"lags":[7]}})json");
  auto moment2 = parse_request(
      catalog,
      R"json({"id":"moment2","kind":"stationary_backlog_moment","parameters":{"order":2}})json");
  auto moment5 = parse_request(
      catalog,
      R"json({"id":"moment5","kind":"stationary_backlog_moment","parameters":{"order":5}})json");
  REQUIRE(lag2);
  REQUIRE(lag7);
  REQUIRE(moment2);
  REQUIRE(moment5);
  std::array<mwperf::MetricRequest, 4U> requests{
      lag2.value(), lag7.value(), moment2.value(), moment5.value()};
  const auto joined = mwperf::aggregate_metric_requirements(requests);
  REQUIRE(joined.clauses().size() == 4U);
  REQUIRE(joined.cylinder_summaries().size() == 1U);
  CHECK(joined.cylinder_summaries()[0].maximum_offset == BigNat{7U});
  const auto* offsets = std::get_if<mwperf::ExplicitCylinderOffsetsV1>(
      &joined.cylinder_summaries()[0].coverage);
  REQUIRE(offsets != nullptr);
  CHECK(contains(offsets->offsets, BigNat{0U}));
  CHECK(contains(offsets->offsets, BigNat{2U}));
  CHECK(contains(offsets->offsets, BigNat{7U}));
  REQUIRE(joined.moment_summaries().size() == 1U);
  CHECK(joined.moment_summaries()[0].maximum_order == BigNat{5U});
}

TEST_CASE("C14 closed catalogs contain exactly nine seven and twenty-five tags",
          "[c14][unit]") {
  CHECK(mwperf::all_semantic_tags_v1().size() == 9U);
  CHECK(mwperf::all_runtime_access_tags_v1().size() == 7U);
  CHECK(mwperf::all_metric_support_roles_v1().size() == 25U);
  constexpr auto expected = expected_role_schemas();

  for (std::size_t index = 0U;
       index < mwperf::all_metric_support_roles_v1().size(); ++index) {
    const mwperf::MetricSupportRoleV1 role =
        mwperf::all_metric_support_roles_v1()[index];
    CHECK(mwperf::metric_support_role_rank_v1(role) == index);
    const auto* schema = mwperf::metric_support_role_schema_v1(role);
    REQUIRE(schema != nullptr);
    CHECK(schema->role == role);
    CHECK(static_cast<std::size_t>(schema->reference_alternative) == index);
    CHECK(*schema == expected[index]);
  }

  CHECK(mwperf::metric_support_role_schema_v1(
            static_cast<mwperf::MetricSupportRoleV1>(255U)) == nullptr);
}

TEST_CASE("C14 exact metric decoder domains remain direct-only",
          "[c14][negative][manifest]") {
  auto clause = minimal_support_clause({});
  clause.parameter_domain = mwperf::ExactMetricDecoderDomainV1{
      mwperf::ExactMetricDecoderKeyV1(
          text_label("c14.test.not-an-analytic-transform-decoder")),
      mwperf::StationaryEmptyProbabilityParametersV1{}};
  clause.runtime_access = mwperf::RuntimeAccessTagV1::analytic_transform;
  clause.solver_route = mwperf::SolverRegimeV1::analytic;

  auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "metric_manifest_decoder_domain_invalid");
}

TEST_CASE("C14 manifest rejects a payload role without a primary result",
          "[c14][negative]") {
  const auto payload_requirement = role_requirement(
      mwperf::MetricSupportRoleV1::deployed_payload,
      mwperf::MetricTargetScopeV1::payload_targets,
      mwperf::MetricResultScopeV1::surrogate_law,
      mwperf::MetricEvidenceScopeV1::none);
  auto manifest_result = mwperf::MetricSupportManifest::from_clauses(
      {minimal_support_clause({payload_requirement})});
  REQUIRE_FALSE(manifest_result);
  CHECK(manifest_result.error().code == "metric_manifest_primary_role_missing");
}

TEST_CASE("C14 all twenty-five role tags map to one closed reference alternative",
          "[c14][unit]") {
  std::vector<mwperf::MetricSupportRoleRequirementV1> requirements;
  requirements.reserve(mwperf::all_metric_support_roles_v1().size());
  for (const auto role : mwperf::all_metric_support_roles_v1()) {
    requirements.push_back(canonical_role_requirement(role));
  }
  const auto subjects = all_role_subjects();
  for (const auto& requirement : requirements) {
    mwperf::RealizedReferenceV1 reference =
        realized_reference_for_role(requirement, subjects);
    CHECK(mwperf::realized_reference_role_v1(reference) == requirement.role);
    CHECK(mwperf::realized_reference_alternative_v1(reference) ==
          mwperf::metric_support_role_schema_v1(requirement.role)
              ->reference_alternative);
    CHECK(mwperf::realized_reference_core_v1(reference).target_scope ==
          requirement.target_scope);
    CHECK(mwperf::realized_reference_subject_v1(reference) ==
          subjects[mwperf::metric_support_role_rank_v1(requirement.role)]);
  }
}

TEST_CASE("C14 validates dependency-closed realized graphs for every role tag",
          "[c14][unit][property]") {
  for (const auto selected_role : mwperf::all_metric_support_roles_v1()) {
    INFO("role rank " << mwperf::metric_support_role_rank_v1(selected_role));
    auto manifest_result = mwperf::MetricSupportManifest::from_clauses(
        {role_matrix_clause(selected_role)});
    INFO((manifest_result
              ? std::string{}
              : manifest_result.error().code + ": " +
                    manifest_result.error().message));
    REQUIRE(manifest_result);
    const auto& manifest = manifest_result.value();
    REQUIRE(manifest.clauses().size() == 1U);
    const auto& clause = manifest.clauses().front();
    const auto selected = std::find_if(
        clause.required_roles.begin(), clause.required_roles.end(),
        [selected_role](const auto& value) {
          return value.role == selected_role;
        });
    REQUIRE(selected != clause.required_roles.end());
    const auto* schema = mwperf::metric_support_role_schema_v1(selected_role);
    REQUIRE(schema != nullptr);
    CHECK((schema->allowed_target_scopes &
           mwperf::metric_target_scope_bit_v1(selected->target_scope)) != 0U);
    CHECK((schema->allowed_result_scopes &
           mwperf::metric_result_scope_bit_v1(selected->result_scope)) != 0U);
    CHECK((schema->allowed_evidence_scopes &
           mwperf::metric_evidence_scope_bit_v1(selected->evidence_scope)) !=
          0U);

    auto bindings = realize_role_matrix_clause(clause);
    const mwperf::RealizedBindingValidationContextV1 context{
        {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}},
        role_matrix_policies(selected_role)};
    const auto validated = mwperf::validate_realized_metric_bindings_v1(
        manifest, context, bindings);
    INFO((validated ? std::string{}
                    : validated.error().code + ": " +
                          validated.error().message));
    REQUIRE(validated);

    const auto selected_binding = std::find_if(
        bindings.begin(), bindings.end(), [selected_role](const auto& value) {
          return value.key.role == selected_role;
        });
    REQUIRE(selected_binding != bindings.end());
    const std::size_t binding_index = static_cast<std::size_t>(
        selected_binding - bindings.begin());
    const auto original_core =
        mwperf::realized_reference_core_v1(selected_binding->reference);
    const auto original_subject =
        mwperf::realized_reference_subject_v1(selected_binding->reference);

    auto wrong_alternative = bindings;
    if (selected_role == mwperf::MetricSupportRoleV1::deployed_payload) {
      wrong_alternative[binding_index].reference =
          mwperf::RawResponseProductReferenceV1{
              original_core,
              {original_subject,
               mwperf::ResponseProductValueFormV1::exact_point}};
    } else {
      wrong_alternative[binding_index].reference =
          mwperf::DeployedPayloadReferenceV1{
              original_core, mwperf::ArtifactPayloadRef{original_subject}};
    }
    CHECK_FALSE(mwperf::validate_realized_metric_bindings_v1(
        manifest, context, std::move(wrong_alternative)));

    auto wrong_scope = bindings;
    mutable_realized_core(wrong_scope[binding_index].reference).result_scope =
        static_cast<mwperf::MetricResultScopeV1>(255U);
    CHECK_FALSE(mwperf::validate_realized_metric_bindings_v1(
        manifest, context, std::move(wrong_scope)));

    if (!selected->role_relations.empty() ||
        !selected->internal_relations.empty()) {
      auto absent_parent = bindings;
      auto& core = mutable_realized_core(absent_parent[binding_index].reference);
      if (!core.role_relations.empty()) {
        core.role_relations.pop_back();
      } else {
        core.internal_relations.pop_back();
      }
      CHECK_FALSE(mwperf::validate_realized_metric_bindings_v1(
          manifest, context, std::move(absent_parent)));
    }
  }
}

TEST_CASE("C14 role graphs reject forbidden scopes edges and missing parents",
          "[c14][negative]") {
  auto missing_parent = role_matrix_clause(
      mwperf::MetricSupportRoleV1::temporal_continuation_law);
  auto temporal = std::find_if(
      missing_parent.required_roles.begin(),
      missing_parent.required_roles.end(), [](const auto& value) {
        return value.role ==
               mwperf::MetricSupportRoleV1::temporal_continuation_law;
      });
  REQUIRE(temporal != missing_parent.required_roles.end());
  REQUIRE_FALSE(temporal->role_relations.empty());
  temporal->role_relations.erase(temporal->role_relations.begin());
  auto missing_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(missing_parent)});
  REQUIRE_FALSE(missing_result);
  CHECK(missing_result.error().code ==
        "metric_manifest_role_relation_missing");

  auto forbidden_edge =
      role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
  auto raw = std::find_if(
      forbidden_edge.required_roles.begin(),
      forbidden_edge.required_roles.end(), [](const auto& value) {
        return value.role == mwperf::MetricSupportRoleV1::raw_response;
      });
  REQUIRE(raw != forbidden_edge.required_roles.end());
  raw->role_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::subject,
       mwperf::MetricSupportRoleV1::deployed_payload});
  auto forbidden_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(forbidden_edge)});
  REQUIRE_FALSE(forbidden_result);
  CHECK(forbidden_result.error().code ==
        "metric_manifest_role_relation_invalid");

  auto invalid_scope = role_matrix_clause(
      mwperf::MetricSupportRoleV1::raw_response_bound_evidence);
  auto bound = std::find_if(
      invalid_scope.required_roles.begin(), invalid_scope.required_roles.end(),
      [](const auto& value) {
        return value.role ==
               mwperf::MetricSupportRoleV1::raw_response_bound_evidence;
      });
  REQUIRE(bound != invalid_scope.required_roles.end());
  bound->result_scope = mwperf::MetricResultScopeV1::physical_bound;
  auto scope_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(invalid_scope)});
  REQUIRE_FALSE(scope_result);
  CHECK(scope_result.error().code == "metric_manifest_role_scope_invalid");

  auto invalid_target =
      role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
  auto target_raw = std::find_if(
      invalid_target.required_roles.begin(),
      invalid_target.required_roles.end(), [](const auto& value) {
        return value.role == mwperf::MetricSupportRoleV1::raw_response;
      });
  REQUIRE(target_raw != invalid_target.required_roles.end());
  target_raw->target_scope =
      mwperf::MetricTargetScopeV1::ordered_metric_targets;
  auto target_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(invalid_target)});
  REQUIRE_FALSE(target_result);
  CHECK(target_result.error().code == "metric_manifest_role_scope_invalid");

  auto invalid_evidence = role_matrix_clause(
      mwperf::MetricSupportRoleV1::response_order_evidence);
  auto order = std::find_if(
      invalid_evidence.required_roles.begin(),
      invalid_evidence.required_roles.end(), [](const auto& value) {
        return value.role ==
               mwperf::MetricSupportRoleV1::response_order_evidence;
      });
  REQUIRE(order != invalid_evidence.required_roles.end());
  order->evidence_scope = mwperf::MetricEvidenceScopeV1::raw_static_proposal;
  auto evidence_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(invalid_evidence)});
  REQUIRE_FALSE(evidence_result);
  CHECK(evidence_result.error().code ==
        "metric_manifest_role_scope_invalid");

  auto invalid_internal =
      role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
  auto internal_raw = std::find_if(
      invalid_internal.required_roles.begin(),
      invalid_internal.required_roles.end(), [](const auto& value) {
        return value.role == mwperf::MetricSupportRoleV1::raw_response;
      });
  REQUIRE(internal_raw != invalid_internal.required_roles.end());
  internal_raw->internal_relations.push_back(
      {mwperf::MetricRoleRelationKindV1::binding,
       mwperf::InternalReferencePurposeV1::state_codec});
  auto internal_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(invalid_internal)});
  REQUIRE_FALSE(internal_result);
  CHECK(internal_result.error().code ==
        "metric_manifest_internal_relation_invalid");
}

TEST_CASE("C14 realized bindings reject valid but unfrozen scope values",
          "[c14][negative]") {
  auto clause = role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
  auto manifest_result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  REQUIRE(manifest_result);
  const auto& manifest = manifest_result.value();
  const auto bindings = realize_role_matrix_clause(manifest.clauses().front());
  const mwperf::RealizedBindingValidationContextV1 context{
      {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}},
      role_matrix_policies(mwperf::MetricSupportRoleV1::raw_response)};
  const auto verify_scope_rejected = [&](auto mutate) {
    auto candidate = bindings;
    const auto raw = std::find_if(
        candidate.begin(), candidate.end(), [](const auto& binding) {
          return binding.key.role ==
                 mwperf::MetricSupportRoleV1::raw_response;
        });
    REQUIRE(raw != candidate.end());
    mutate(mutable_realized_core(raw->reference));
    const auto result = mwperf::validate_realized_metric_bindings_v1(
        manifest, context, std::move(candidate));
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "metric_binding_scope_mismatch");
  };
  verify_scope_rejected([](auto& core) {
    core.target_scope = mwperf::MetricTargetScopeV1::ordered_metric_targets;
  });
  verify_scope_rejected([](auto& core) {
    core.result_scope = mwperf::MetricResultScopeV1::not_a_metric_result;
  });
  verify_scope_rejected([](auto& core) {
    core.evidence_scope =
        mwperf::MetricEvidenceScopeV1::nominal_static_proposal;
  });
}

TEST_CASE("C14 realized lineage rejects a two-role derivation cycle",
          "[c14][negative]") {
  auto clause =
      role_matrix_clause(mwperf::MetricSupportRoleV1::nominal_response);
  auto manifest_result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  REQUIRE(manifest_result);
  const auto& manifest = manifest_result.value();
  auto bindings = realize_role_matrix_clause(manifest.clauses().front());
  const auto raw = std::find_if(
      bindings.begin(), bindings.end(), [](const auto& binding) {
        return binding.key.role == mwperf::MetricSupportRoleV1::raw_response;
      });
  const auto nominal = std::find_if(
      bindings.begin(), bindings.end(), [](const auto& binding) {
        return binding.key.role ==
               mwperf::MetricSupportRoleV1::nominal_response;
      });
  REQUIRE(raw != bindings.end());
  REQUIRE(nominal != bindings.end());
  auto* coefficient_origin = mutable_internal_object(
      mutable_realized_core(raw->reference),
      mwperf::InternalReferencePurposeV1::coefficient_origin);
  REQUIRE(coefficient_origin != nullptr);
  *coefficient_origin =
      mwperf::realized_reference_subject_v1(nominal->reference);

  mwperf::PreviewPoliciesV1 policies =
      role_matrix_policies(mwperf::MetricSupportRoleV1::nominal_response);
  const mwperf::RealizedBindingValidationContextV1 context{
      {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}}, policies};
  const auto result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(bindings));
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "metric_binding_lineage_cycle");
}

TEST_CASE("C14 deployed response freezes raw nominal and recoded identity",
          "[c14][unit][negative]") {
  using R = mwperf::MetricSupportRoleV1;
  struct DeploymentCase final {
    R source_role;
    mwperf::PointDeploymentPolicyV1 policy;
    mwperf::PointDeploymentPolicyV1 wrong_policy;
  };
  constexpr std::array<DeploymentCase, 3U> cases{{
      {R::raw_response, mwperf::PointDeploymentPolicyV1::deploy_raw_point,
       mwperf::PointDeploymentPolicyV1::deploy_nominal_point},
      {R::nominal_response,
       mwperf::PointDeploymentPolicyV1::deploy_nominal_point,
       mwperf::PointDeploymentPolicyV1::deploy_raw_point},
      {R::recoded_response,
       mwperf::PointDeploymentPolicyV1::deploy_recoded_point,
       mwperf::PointDeploymentPolicyV1::deploy_raw_point},
  }};

  for (const auto& item : cases) {
    INFO("source role rank "
         << mwperf::metric_support_role_rank_v1(item.source_role));
    auto clause = role_matrix_clause(item.source_role);
    auto deployed_requirement = std::find_if(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const auto& requirement) {
          return requirement.role == R::deployed_response;
        });
    REQUIRE(deployed_requirement != clause.required_roles.end());
    auto subject_relation = std::find_if(
        deployed_requirement->role_relations.begin(),
        deployed_requirement->role_relations.end(), [](const auto& relation) {
          return relation.relation ==
                 mwperf::MetricRoleRelationKindV1::subject;
        });
    REQUIRE(subject_relation != deployed_requirement->role_relations.end());
    subject_relation->other_role = item.source_role;

    auto manifest_result =
        mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
    INFO((manifest_result ? std::string{}
                          : manifest_result.error().code + ": " +
                                manifest_result.error().message));
    REQUIRE(manifest_result);
    const auto& manifest = manifest_result.value();
    auto bindings = realize_role_matrix_clause(manifest.clauses().front());
    const auto deployed = std::find_if(
        bindings.begin(), bindings.end(), [](const auto& binding) {
          return binding.key.role == R::deployed_response;
        });
    const auto source = std::find_if(
        bindings.begin(), bindings.end(), [&](const auto& binding) {
          return binding.key.role == item.source_role;
        });
    REQUIRE(deployed != bindings.end());
    REQUIRE(source != bindings.end());
    const auto selected_identity =
        mwperf::realized_reference_subject_v1(source->reference);
    auto deployed_core =
        mwperf::realized_reference_core_v1(deployed->reference);
    switch (item.source_role) {
      case R::raw_response:
        deployed->reference = mwperf::DeployedResponseReferenceV1{
            std::move(deployed_core),
            mwperf::RawResponseProductRef{
                selected_identity,
                mwperf::ResponseProductValueFormV1::exact_point}};
        break;
      case R::nominal_response:
        deployed->reference = mwperf::DeployedResponseReferenceV1{
            std::move(deployed_core),
            mwperf::NominalResponseProductRef{selected_identity}};
        break;
      case R::recoded_response:
        deployed->reference = mwperf::DeployedResponseReferenceV1{
            std::move(deployed_core),
            mwperf::RecodedResponseProductRef{selected_identity}};
        break;
      default:
        FAIL("deployment fixture must select raw, nominal, or recoded");
    }

    mwperf::PreviewPoliciesV1 policies = role_matrix_policies(item.source_role);
    policies.point_deployment = item.policy;
    const auto make_context = [](const mwperf::PreviewPoliciesV1& value) {
      return mwperf::RealizedBindingValidationContextV1{
          {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}}, value};
    };
    REQUIRE(mwperf::validate_realized_metric_bindings_v1(
        manifest, make_context(policies), bindings));

    auto wrong_policy = policies;
    wrong_policy.point_deployment = item.wrong_policy;
    const auto policy_result = mwperf::validate_realized_metric_bindings_v1(
        manifest, make_context(wrong_policy), bindings);
    REQUIRE_FALSE(policy_result);
    CHECK(policy_result.error().code ==
          "metric_binding_deployment_policy_mismatch");

    auto copied = bindings;
    auto copied_deployed = std::find_if(
        copied.begin(), copied.end(), [](const auto& binding) {
          return binding.key.role == R::deployed_response;
        });
    REQUIRE(copied_deployed != copied.end());
    auto& selected =
        std::get<mwperf::DeployedResponseReferenceV1>(
            copied_deployed->reference)
            .selected_product;
    std::visit(
        [](auto& product) {
          product.identity = object_reference("copied-deployed-product");
        },
        selected);
    const auto copied_result = mwperf::validate_realized_metric_bindings_v1(
        manifest, make_context(policies), std::move(copied));
    REQUIRE_FALSE(copied_result);
    CHECK(copied_result.error().code ==
          "metric_binding_deployed_product_identity_mismatch");

    if (item.source_role == R::raw_response) {
      auto interval = bindings;
      auto interval_deployed = std::find_if(
          interval.begin(), interval.end(), [](const auto& binding) {
            return binding.key.role == R::deployed_response;
          });
      REQUIRE(interval_deployed != interval.end());
      auto& raw_product = std::get<mwperf::RawResponseProductRef>(
          std::get<mwperf::DeployedResponseReferenceV1>(
              interval_deployed->reference)
              .selected_product);
      raw_product.value_form =
          mwperf::ResponseProductValueFormV1::interval_only;
      const auto interval_result =
          mwperf::validate_realized_metric_bindings_v1(
              manifest, make_context(policies), std::move(interval));
      REQUIRE_FALSE(interval_result);
      CHECK(interval_result.error().code ==
            "metric_binding_interval_raw_not_deployable");
    }

    if (item.source_role == R::nominal_response) {
      auto wrong_completion = policies;
      wrong_completion.coefficient_completion =
          mwperf::CoefficientCompletionPolicyV1::
              authorized_endpoint_completion;
      const auto completion_result =
          mwperf::validate_realized_metric_bindings_v1(
              manifest, make_context(wrong_completion), bindings);
      REQUIRE_FALSE(completion_result);
      CHECK(completion_result.error().code ==
            "metric_binding_completion_policy_mismatch");
    }

    if (item.source_role == R::recoded_response) {
      auto wrong_recoding = policies;
      wrong_recoding.recoding = mwperf::RecodingPolicyV1::mean_inversion;
      const auto recoding_result =
          mwperf::validate_realized_metric_bindings_v1(
              manifest, make_context(wrong_recoding), bindings);
      REQUIRE_FALSE(recoding_result);
      CHECK(recoding_result.error().code ==
            "metric_binding_recoding_parent_mismatch");
    }
  }
}

TEST_CASE("C14 manifest rejects malformed arrival and hypothesis fields",
          "[c14][negative]") {
  const std::array<mwperf::ArrivalAssumptionV1, 4U> malformed_arrivals{{
      {mwperf::ArrivalNeedKindV1::target_intensity,
       mwperf::ArrivalCapabilityUseV1::runtime,
       mwperf::CapabilityProvisionNeedV1::any, BigNat{1U}, false, false,
       std::nullopt, std::nullopt, std::nullopt},
      {mwperf::ArrivalNeedKindV1::arrival_moment,
       mwperf::ArrivalCapabilityUseV1::runtime,
       mwperf::CapabilityProvisionNeedV1::any, std::nullopt, false, false,
       std::nullopt, std::nullopt, std::nullopt},
      {mwperf::ArrivalNeedKindV1::full_common_batch,
       mwperf::ArrivalCapabilityUseV1::runtime,
       mwperf::CapabilityProvisionNeedV1::any, std::nullopt, false, true,
       std::nullopt, std::nullopt, std::nullopt},
      {mwperf::ArrivalNeedKindV1::transform,
       mwperf::ArrivalCapabilityUseV1::runtime,
       mwperf::CapabilityProvisionNeedV1::portable, std::nullopt, false,
       false, mwperf::TransformKind::exact_pgf,
       mwperf::DistributionScope::per_coordinate, std::nullopt},
  }};
  for (const auto& assumption : malformed_arrivals) {
    auto clause =
        role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
    clause.arrival_assumptions = {assumption};
    const auto result =
        mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
    REQUIRE_FALSE(result);
    CHECK(result.error().code ==
          "metric_manifest_arrival_assumption_invalid");
  }

  const std::array<mwperf::HypothesisClaimV1, 4U> malformed_hypotheses{{
      {mwperf::HypothesisKindV1::proper_stationary,
       mwperf::MomentVariableV1::backlog, std::nullopt, std::nullopt},
      {mwperf::HypothesisKindV1::proper_stationary, std::nullopt, BigNat{1U},
       std::nullopt},
      {mwperf::HypothesisKindV1::moment_finite, std::nullopt, BigNat{1U},
       std::nullopt},
      {mwperf::HypothesisKindV1::moment_finite,
       mwperf::MomentVariableV1::arrival, BigNat{0U}, std::nullopt},
  }};
  for (const auto& hypothesis : malformed_hypotheses) {
    auto clause =
        role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
    clause.hypotheses = {hypothesis};
    const auto result =
        mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
    REQUIRE_FALSE(result);
    CHECK(result.error().code == "metric_manifest_hypothesis_invalid");
  }
}

TEST_CASE("C14 nonphysical primary rejects physical-system error scope",
          "[c14][negative]") {
  auto clause = role_matrix_clause(mwperf::MetricSupportRoleV1::raw_response);
  REQUIRE(clause.result_scope == mwperf::MetricResultScopeV1::surrogate_law);
  clause.error_promise.scope = mwperf::MetricEvidenceScopeV1::physical_system;
  const auto result =
      mwperf::MetricSupportManifest::from_clauses({std::move(clause)});
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "metric_manifest_physical_transfer_invalid");
}

TEST_CASE("C14 physical transfer is attached to its exact primary result",
          "[c14][negative]") {
  auto physical_clause = role_matrix_clause(
      mwperf::MetricSupportRoleV1::physical_transfer_evidence);
  auto manifest_result = mwperf::MetricSupportManifest::from_clauses(
      {physical_clause});
  REQUIRE(manifest_result);
  const auto& manifest = manifest_result.value();
  const auto& clause = manifest.clauses().front();
  auto bindings = realize_role_matrix_clause(clause);
  const mwperf::RealizedBindingValidationContextV1 context{
      {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}},
      role_matrix_policies(
          mwperf::MetricSupportRoleV1::physical_transfer_evidence)};
  REQUIRE(mwperf::validate_realized_metric_bindings_v1(manifest, context,
                                                        bindings));

  const auto transfer = std::find_if(
      bindings.begin(), bindings.end(), [](const auto& value) {
        return value.key.role ==
               mwperf::MetricSupportRoleV1::physical_transfer_evidence;
      });
  REQUIRE(transfer != bindings.end());
  auto* surrogate_source = mutable_internal_object(
      mutable_realized_core(transfer->reference),
      mwperf::InternalReferencePurposeV1::surrogate_source);
  REQUIRE(surrogate_source != nullptr);
  *surrogate_source = object_reference("unrelated-surrogate-source");
  const auto unrelated = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(bindings));
  REQUIRE_FALSE(unrelated);
  CHECK(unrelated.error().code ==
        "metric_binding_cross_role_identity_mismatch");

  auto orphan = std::move(physical_clause);
  auto primary = std::find_if(
      orphan.required_roles.begin(), orphan.required_roles.end(),
      [](const auto& value) {
        return value.role == mwperf::MetricSupportRoleV1::response_envelope;
      });
  REQUIRE(primary != orphan.required_roles.end());
  primary->role_relations.erase(
      std::remove_if(primary->role_relations.begin(),
                     primary->role_relations.end(), [](const auto& relation) {
                       return relation.relation ==
                                  mwperf::MetricRoleRelationKindV1::evidence &&
                              relation.other_role ==
                                  mwperf::MetricSupportRoleV1::
                                      physical_transfer_evidence;
                     }),
      primary->role_relations.end());
  const auto orphan_result = mwperf::MetricSupportManifest::from_clauses(
      {std::move(orphan)});
  REQUIRE_FALSE(orphan_result);
  CHECK(orphan_result.error().code ==
        "metric_manifest_physical_transfer_invalid");
}

TEST_CASE("C23 mean sojourn does not grant an edge-only provider FIFO tails",
          "[c14][integration][c23][fifo][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const auto mean_request = parse_request(
      catalog,
      R"json({"id":"mean","kind":"mean_sojourn","parameters":{}})json");
  const auto tail_request = parse_request(
      catalog,
      R"json({"id":"tail","kind":"fifo_delay","parameters":{"output":"tail","horizon":4}})json");
  REQUIRE(mean_request);
  REQUIRE(tail_request);

  const auto mean_requirements =
      mwperf::requirements_for_metric(mean_request.value());
  const auto tail_requirements =
      mwperf::requirements_for_metric(tail_request.value());
  const auto edge_only = preview_for_clause(mean_requirements);
  const auto arrivals = complete_arrival_capabilities();

  const auto mean_decision = mwperf::negotiate_capabilities(
      mean_requirements, edge_only, arrivals);
  INFO(mwperf::explain_capability_failure(mean_decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(mean_decision));

  const auto tail_decision = mwperf::negotiate_capabilities(
      tail_requirements, edge_only, arrivals);
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(tail_decision));
  const auto* rejection =
      mwperf::rejected_capability_decision(tail_decision);
  REQUIRE(rejection != nullptr);
  CHECK_FALSE(rejection->ordered_failures.empty());
}

TEST_CASE("C14 direct manifest bindings require one exact typed reference per role",
          "[c14][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"direct-bind","kind":"stationary_empty_probability","parameters":{}})json",
      false, stationary_selection(), direct_solver());
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto preview = preview_for_clause(requirements);
  REQUIRE(preview.metric_support_manifest != nullptr);
  const auto& manifest = *preview.metric_support_manifest;
  REQUIRE(manifest.clauses().size() == 1U);
  const auto& clause = manifest.clauses()[0];
  REQUIRE(clause.required_roles.size() == 3U);

  std::vector<mwperf::RealizedMetricBindingV1> bindings =
      realize_role_matrix_clause(clause);
  const mwperf::RealizedBindingValidationContextV1 context{
      {{queue_id("q0")}, queue_id("q0"), {queue_id("q0")}},
      preview.policies};
  auto realized = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, bindings);
  INFO((realized ? std::string{}
                 : realized.error().code + ": " + realized.error().message));
  REQUIRE(realized);
  REQUIRE(realized.value().bindings().size() == 3U);
  REQUIRE(mwperf::canonical_realized_metric_bindings_bytes_v1(
      realized.value()));
  REQUIRE(mwperf::digest_realized_metric_bindings_v1(realized.value()));

  auto missing = bindings;
  missing.pop_back();
  const auto missing_result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(missing));
  REQUIRE_FALSE(missing_result);
  CHECK(missing_result.error().code == "metric_binding_key_missing");

  auto duplicate = bindings;
  duplicate.push_back(bindings.front());
  const auto duplicate_result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(duplicate));
  REQUIRE_FALSE(duplicate_result);
  CHECK(duplicate_result.error().code == "metric_binding_key_duplicate");

  auto extra = bindings;
  mwperf::RealizedMetricBindingV1 extra_binding = bindings.front();
  extra_binding.key.role = mwperf::MetricSupportRoleV1::raw_response;
  extra.push_back(std::move(extra_binding));
  const auto extra_result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(extra));
  REQUIRE_FALSE(extra_result);
  CHECK(extra_result.error().code == "metric_binding_key_extra");

  auto mistyped = bindings;
  const auto original_core =
      mwperf::realized_reference_core_v1(mistyped.back().reference);
  mistyped.back().reference = mwperf::DeployedPayloadReferenceV1{
      original_core,
      mwperf::ArtifactPayloadRef{
          mwperf::realized_reference_subject_v1(bindings.back().reference)}};
  const auto type_result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(mistyped));
  REQUIRE_FALSE(type_result);
  CHECK(type_result.error().code ==
        "metric_binding_reference_type_mismatch");

  auto wrong_target = bindings;
  auto wrong_core =
      mwperf::realized_reference_core_v1(wrong_target.front().reference);
  wrong_core.ordered_targets = {queue_id("q1")};
  wrong_target.front().reference = mwperf::DeployedPayloadReferenceV1{
      std::move(wrong_core),
      mwperf::ArtifactPayloadRef{
          mwperf::realized_reference_subject_v1(bindings.front().reference)}};
  const auto target_result = mwperf::validate_realized_metric_bindings_v1(
      manifest, context, std::move(wrong_target));
  REQUIRE_FALSE(target_result);
  CHECK(target_result.error().code ==
        "metric_binding_target_scope_mismatch");
}

TEST_CASE("C14 negotiation accepts and freezes one complete route",
          "[c14][integration]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const mwperf::MetricRequirements requirements =
      mwperf::requirements_for_metric(request.value());
  mwperf::PlugDescriptorPreview preview = preview_for_clause(requirements);
  const mwperf::ArrivalCapabilities arrivals =
      complete_arrival_capabilities();
  const mwperf::ProviderIdentityV1 frozen_provider = preview.core.provider;
  const std::vector<mwperf::QueueId> frozen_scope =
      preview.construction_target_scope;
  const mwperf::PreviewPoliciesV1 frozen_policies = preview.policies;
  const mwperf::Digest256 frozen_preview_digest = preview.preview_digest;

  const mwperf::CapabilityDecision decision =
      mwperf::negotiate_capabilities(requirements, preview, arrivals);
  INFO(mwperf::explain_capability_failure(decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(decision));
  const auto* contract = mwperf::accepted_capability_contract(decision);
  REQUIRE(contract != nullptr);
  CHECK(contract->provider() == frozen_provider);
  CHECK(std::vector<mwperf::QueueId>(
            contract->construction_target_scope().begin(),
            contract->construction_target_scope().end()) == frozen_scope);
  CHECK(contract->policies() == frozen_policies);
  CHECK(contract->preview_digest() == frozen_preview_digest);
  CHECK(contract->structural_manifest() == *preview.metric_support_manifest);
  CHECK(mwperf::equivalent_metric_requirements(contract->requirements(),
                                                requirements));
  REQUIRE(contract->metric_contracts().size() == 1U);

  // The accepted value owns a snapshot.  Later caller-side edits or replacing
  // the shared preview manifest cannot mutate the plan already accepted.
  preview.core.provider.provider_id = "mutated-after-acceptance";
  preview.construction_target_scope = {queue_id("q2")};
  preview.policies.point_deployment =
      mwperf::PointDeploymentPolicyV1::deploy_nominal_point;
  preview.metric_support_manifest.reset();
  CHECK(contract->provider() == frozen_provider);
  CHECK(std::vector<mwperf::QueueId>(
            contract->construction_target_scope().begin(),
            contract->construction_target_scope().end()) == frozen_scope);
  CHECK(contract->policies() == frozen_policies);
  CHECK(contract->preview_digest() == frozen_preview_digest);

  const mwperf::Diagnostic accepted_diagnostic =
      mwperf::explain_capability_failure(decision);
  CHECK(accepted_diagnostic.code == "c14_capability_decision_is_accepted");
}

TEST_CASE("C14 accepts each exactly integrable stationary edge reward",
          "[c14][integration]") {
  struct RewardCase final {
    const char* wire_name;
    mwperf::EdgeRewardKind kind;
    mwperf::MetricMarkKindV1 mark;
    mwperf::MetricRevealStageV1 stage;
  };
  const std::array<RewardCase, 3U> cases{{
      {"increment", mwperf::EdgeRewardKind::increment,
       mwperf::MetricMarkKindV1::edge_increment,
       mwperf::MetricRevealStageV1::completed_edge},
      {"departure", mwperf::EdgeRewardKind::departure,
       mwperf::MetricMarkKindV1::actual_departure,
       mwperf::MetricRevealStageV1::decision},
      {"arrival", mwperf::EdgeRewardKind::arrival,
       mwperf::MetricMarkKindV1::arrival_batch,
       mwperf::MetricRevealStageV1::arrival},
  }};
  const mwperf::QueueCatalog catalog = make_catalog();
  for (const auto& item : cases) {
    const std::string metric =
        std::string(
            R"json({"id":"reward","kind":"stationary_edge_reward","parameters":{"reward":")json") +
        item.wire_name + R"json(","moment_order":2}})json";
    auto request = parse_request(catalog, metric);
    REQUIRE(request);
    const auto parameters =
        mwperf::metric_request_parameters(request.value());
    const auto& reward =
        std::get<mwperf::StationaryEdgeRewardParametersV1>(parameters);
    CHECK(reward.reward == item.kind);
    CHECK(reward.moment_order == BigNat{2U});
    const auto requirements =
        mwperf::requirements_for_metric(request.value());
    REQUIRE(requirements.clauses().size() == 1U);
    const auto& clause = requirements.clauses().front();
    CHECK(has_mark(clause, item.mark, item.stage));
    const auto integrability = std::find_if(
        clause.hypotheses.begin(), clause.hypotheses.end(),
        [](const auto& value) {
          return value.claim.kind ==
                 mwperf::HypothesisKindV1::reward_integrable;
        });
    REQUIRE(integrability != clause.hypotheses.end());
    CHECK(integrability->satisfaction ==
          mwperf::HypothesisSatisfactionKindV1::required_evidence);
    CHECK(integrability->claim.variable ==
          std::optional<mwperf::MomentVariableV1>{
              mwperf::MomentVariableV1::edge_reward});
    CHECK(integrability->claim.order ==
          std::optional<BigNat>{BigNat{2U}});
    const auto preview = preview_for_clause(requirements);
    const auto decision = mwperf::negotiate_capabilities(
        requirements, preview, complete_arrival_capabilities());
    INFO(mwperf::explain_capability_failure(decision).message);
    CHECK(mwperf::capability_decision_is_accepted(decision));
  }
}

TEST_CASE("C14 service-window continuation retains the departure word",
          "[c14][integration][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"window","kind":"service_window_count","parameters":{"width":5}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  PreviewFixtureOptionsV1 positive_options;
  positive_options.prefer_predictive_arrival = true;
  const auto positive = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.window-positive", positive_options);
  const auto positive_decision = mwperf::negotiate_capabilities(
      requirements, positive, complete_arrival_capabilities());
  INFO(mwperf::explain_capability_failure(positive_decision).message);
  CHECK(mwperf::capability_decision_is_accepted(positive_decision));
  CHECK(std::all_of(
      positive.core.marks.begin(), positive.core.marks.end(),
      [](const auto& mark) {
        return mark.common_realization_group == "common-edge";
      }));

  auto without_c21 = positive;
  auto support_clauses = std::vector<mwperf::MetricSupportClauseV1>(
      without_c21.metric_support_manifest->clauses().begin(),
      without_c21.metric_support_manifest->clauses().end());
  REQUIRE(support_clauses.size() == 1U);
  const auto erase_c21 = [](auto& values) {
    values.erase(std::remove_if(values.begin(), values.end(),
                                [](const auto& claim) {
                                  return claim.kind ==
                                         mwperf::HypothesisKindV1::
                                             c21_suspension_inversion;
                                }),
                 values.end());
  };
  erase_c21(support_clauses[0].hypotheses);
  erase_c21(without_c21.core.hypothesis_claims);
  auto no_c21_manifest = mwperf::MetricSupportManifest::from_clauses(
      std::move(support_clauses));
  REQUIRE(no_c21_manifest);
  without_c21.metric_support_manifest =
      std::make_shared<const mwperf::MetricSupportManifest>(
          std::move(no_c21_manifest).value());
  reseal_preview(without_c21);
  const auto no_c21_decision = mwperf::negotiate_capabilities(
      requirements, without_c21, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(no_c21_decision));
  const auto* no_c21_rejected =
      mwperf::rejected_capability_decision(no_c21_decision);
  REQUIRE(no_c21_rejected != nullptr);
  CHECK(std::any_of(
      no_c21_rejected->ordered_failures.begin(),
      no_c21_rejected->ordered_failures.end(), [](const auto& failure) {
        return failure.axis == mwperf::CapabilityAxisV1::hypothesis &&
               failure.kind == mwperf::CapabilityFailureKindV1::
                                   hypothesis_evidence_missing;
      }));

  PreviewFixtureOptionsV1 missing_options = positive_options;
  missing_options.omitted_mark = mwperf::MetricMarkKindV1::actual_departure;
  const auto missing = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.window-missing-departure", missing_options);
  const auto decision = mwperf::negotiate_capabilities(
      requirements, missing, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(decision));
  const auto* rejected = mwperf::rejected_capability_decision(decision);
  REQUIRE(rejected != nullptr);
  CHECK(std::any_of(
      rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
      [](const auto& failure) {
        return failure.axis == mwperf::CapabilityAxisV1::mark &&
               failure.kind ==
                   mwperf::CapabilityFailureKindV1::missing_mark;
      }));

  auto transient = parse_request(
      catalog,
      R"json({"id":"transient-cylinder","kind":"transient_backlog_law","parameters":{"horizons":[0,2,7]}})json",
      false, transient_selection());
  REQUIRE(transient);
  const auto transient_requirements =
      mwperf::requirements_for_metric(transient.value());
  const auto transient_preview = preview_for_clause(transient_requirements);
  CHECK(mwperf::capability_decision_is_accepted(
      mwperf::negotiate_capabilities(transient_requirements,
                                     transient_preview,
                                     complete_arrival_capabilities())));
}

TEST_CASE("C14 scalar responses need no live opportunity decoder",
          "[c14][integration]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"scalar","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  PreviewFixtureOptionsV1 options;
  options.prefer_predictive_arrival = true;
  options.omitted_mark = mwperf::MetricMarkKindV1::opportunity;
  const auto preview = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.scalar-without-opportunity", options);
  const auto decision = mwperf::negotiate_capabilities(
      requirements, preview, complete_arrival_capabilities());
  INFO(mwperf::explain_capability_failure(decision).message);
  CHECK(mwperf::capability_decision_is_accepted(decision));
}

TEST_CASE("C14 stationary boundary marks share one predictive realization",
          "[c14][integration][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"joint-boundary","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  PreviewFixtureOptionsV1 options;
  options.prefer_predictive_arrival = true;
  auto preview = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.joint-boundary", options);
  const auto positive = mwperf::negotiate_capabilities(
      requirements, preview, complete_arrival_capabilities());
  INFO(mwperf::explain_capability_failure(positive).message);
  REQUIRE(mwperf::capability_decision_is_accepted(positive));

  auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
      preview.metric_support_manifest->clauses().begin(),
      preview.metric_support_manifest->clauses().end());
  REQUIRE(clauses.size() == 1U);
  const auto split_manifest_mark = std::find_if(
      clauses[0].marks.begin(), clauses[0].marks.end(), [](const auto& mark) {
        return mark.kind == mwperf::MetricMarkKindV1::opportunity;
      });
  const auto split_core_mark = std::find_if(
      preview.core.marks.begin(), preview.core.marks.end(),
      [](const auto& mark) {
        return mark.kind == mwperf::MetricMarkKindV1::opportunity;
      });
  REQUIRE(split_manifest_mark != clauses[0].marks.end());
  REQUIRE(split_core_mark != preview.core.marks.end());
  split_manifest_mark->common_realization_group = "split-opportunity";
  split_core_mark->common_realization_group = "split-opportunity";
  auto manifest = mwperf::MetricSupportManifest::from_clauses(
      std::move(clauses));
  REQUIRE(manifest);
  preview.metric_support_manifest =
      std::make_shared<const mwperf::MetricSupportManifest>(
          std::move(manifest).value());
  reseal_preview(preview);

  const auto rejected = mwperf::negotiate_capabilities(
      requirements, preview, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(rejected));
  const auto* failure = mwperf::rejected_capability_decision(rejected);
  REQUIRE(failure != nullptr);
  CHECK(std::any_of(
      failure->ordered_failures.begin(), failure->ordered_failures.end(),
      [](const auto& value) {
        return value.axis == mwperf::CapabilityAxisV1::mark &&
               value.kind == mwperf::CapabilityFailureKindV1::
                                 marks_not_from_common_realization;
      }));
}

TEST_CASE("C14 finite arrival composition requires both portable row flags",
          "[c14][integration][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"finite-arrival","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  PreviewFixtureOptionsV1 options;
  options.prefer_predictive_arrival = true;
  auto preview = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.finite-arrival", options);
  auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
      preview.metric_support_manifest->clauses().begin(),
      preview.metric_support_manifest->clauses().end());
  REQUIRE(clauses.size() == 1U);
  clauses[0].phase_domain.arrival_composition =
      mwperf::ConfiguredArrivalCompositionV1::
          finite_enumerated_predictive_phase;
  preview.core.phase.arrival_composition =
      mwperf::ConfiguredArrivalCompositionV1::
          finite_enumerated_predictive_phase;
  auto manifest = mwperf::MetricSupportManifest::from_clauses(
      std::move(clauses));
  REQUIRE(manifest);
  preview.metric_support_manifest =
      std::make_shared<const mwperf::MetricSupportManifest>(
          std::move(manifest).value());
  reseal_preview(preview);

  auto finite_rows = complete_arrival_capabilities();
  finite_rows.sequential_normalized_sampler =
      mwperf::CapabilityAvailability::unavailable;
  // The fixture intentionally proves a portable finite-row route with no
  // process-local sampler.  Drop the independently advertised local replay
  // carrier as well: retaining it without its sampler would make the entire
  // C09 capability record malformed before route matching begins.
  finite_rows.adjacent_batch_replay.reset();
  const auto positive = mwperf::negotiate_capabilities(
      requirements, preview, finite_rows);
  INFO(mwperf::explain_capability_failure(positive).message);
  if (const auto* rejected =
          mwperf::rejected_capability_decision(positive)) {
    for (const auto& failure : rejected->ordered_failures) {
      INFO(failure.provided << " -> " << failure.required);
    }
  }
  REQUIRE(mwperf::capability_decision_is_accepted(positive));

  for (const bool omit_phase : {true, false}) {
    auto missing = complete_arrival_capabilities();
    if (omit_phase) {
      missing.finite_enumerated_predictive_phase =
          mwperf::CapabilityAvailability::unavailable;
    } else {
      missing.finite_enumerated_transition_row =
          mwperf::CapabilityAvailability::unavailable;
    }
    const auto negative = mwperf::negotiate_capabilities(
        requirements, preview, missing);
    REQUIRE_FALSE(mwperf::capability_decision_is_accepted(negative));
    const auto* rejected = mwperf::rejected_capability_decision(negative);
    REQUIRE(rejected != nullptr);
    CHECK(std::any_of(
        rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
        [](const auto& failure) {
          return failure.axis == mwperf::CapabilityAxisV1::arrival;
        }));
  }
}

TEST_CASE("C14 conditioned service requires mass or a frozen off-support rule",
          "[c14][integration][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"conditioned","kind":"backlog_conditioned_service","parameters":{"levels":[0,1,4]}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto positive = preview_for_clause(requirements);
  CHECK(mwperf::capability_decision_is_accepted(
      mwperf::negotiate_capabilities(
          requirements, positive, complete_arrival_capabilities())));

  PreviewFixtureOptionsV1 off_support_options;
  off_support_options.conditioning =
      ConditioningFixtureModeV1::declared_off_support;
  const auto off_support = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.conditioned-off-support", off_support_options);
  CHECK(mwperf::capability_decision_is_accepted(
      mwperf::negotiate_capabilities(
          requirements, off_support, complete_arrival_capabilities())));

  PreviewFixtureOptionsV1 missing_options;
  missing_options.conditioning = ConditioningFixtureModeV1::omitted;
  const auto missing = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder, {},
      "c14.test.conditioned-no-mass", missing_options);
  const auto decision = mwperf::negotiate_capabilities(
      requirements, missing, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(decision));
  const auto* rejected = mwperf::rejected_capability_decision(decision);
  REQUIRE(rejected != nullptr);
  CHECK(std::any_of(
      rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
      [](const auto& failure) {
        return failure.axis == mwperf::CapabilityAxisV1::hypothesis &&
               failure.kind == mwperf::CapabilityFailureKindV1::
                                   hypothesis_evidence_missing;
      }));
}

TEST_CASE("C14 admission-Palm delay routes require target intensity",
          "[c14][integration][negative]") {
  struct DelayCase final {
    const char* metric;
    bool coupled;
  };
  const std::array<DelayCase, 2U> cases{{
      {R"json({"id":"fifo-intensity","kind":"fifo_delay","parameters":{"output":"tail","horizon":20}})json",
       false},
      {R"json({"id":"joint-intensity","kind":"joint_delay","parameters":{"sampling":"coincident","horizon":20}})json",
       true},
  }};
  const mwperf::QueueCatalog catalog = make_catalog();
  for (const auto& item : cases) {
    auto request = parse_request(catalog, item.metric, item.coupled);
    REQUIRE(request);
    const auto requirements =
        mwperf::requirements_for_metric(request.value());
    REQUIRE(requirements.clauses().size() == 1U);
    REQUIRE_FALSE(requirements.clauses()[0].route_alternatives.empty());
    CHECK(std::all_of(
        requirements.clauses()[0].route_alternatives.begin(),
        requirements.clauses()[0].route_alternatives.end(),
        [](const auto& route) {
          return route_has_arrival(
              route, mwperf::ArrivalNeedKindV1::target_intensity);
        }));

    const auto preview = preview_for_clause(requirements);
    auto no_replay = complete_arrival_capabilities();
    no_replay.adjacent_batch_replay.reset();
    const auto positive = mwperf::negotiate_capabilities(
        requirements, preview, no_replay);
    INFO(mwperf::explain_capability_failure(positive).message);
    REQUIRE(mwperf::capability_decision_is_accepted(positive));

    auto without_intensity = complete_arrival_capabilities();
    without_intensity.adjacent_batch_replay.reset();
    without_intensity.exact_coordinate_moments.reset();
    without_intensity.analytic_moments.reset();
    const auto negative = mwperf::negotiate_capabilities(
        requirements, preview, without_intensity);
    REQUIRE_FALSE(mwperf::capability_decision_is_accepted(negative));
    const auto* rejected = mwperf::rejected_capability_decision(negative);
    REQUIRE(rejected != nullptr);
    CHECK(std::any_of(
        rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
        [](const auto& failure) {
          return failure.axis == mwperf::CapabilityAxisV1::arrival;
        }));
  }
}

TEST_CASE("C14 throughput derives its first moment from target intensity",
          "[c14][integration]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"throughput-intensity","kind":"stationary_throughput","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  auto preview = preview_for_clause(requirements);
  REQUIRE(preview.metric_support_manifest != nullptr);

  auto clauses = std::vector<mwperf::MetricSupportClauseV1>(
      preview.metric_support_manifest->clauses().begin(),
      preview.metric_support_manifest->clauses().end());
  REQUIRE(clauses.size() == 1U);
  CHECK(std::any_of(
      clauses[0].arrival_assumptions.begin(),
      clauses[0].arrival_assumptions.end(), [](const auto& assumption) {
        return assumption.kind == mwperf::ArrivalNeedKindV1::target_intensity;
      }));
  const auto is_redundant_arrival_moment = [](const auto& claim) {
    return claim.kind == mwperf::HypothesisKindV1::moment_finite &&
           claim.variable == std::optional<mwperf::MomentVariableV1>{
                                 mwperf::MomentVariableV1::arrival} &&
           claim.order == std::optional<BigNat>{BigNat{1U}};
  };
  REQUIRE(std::any_of(clauses[0].hypotheses.begin(),
                      clauses[0].hypotheses.end(),
                      is_redundant_arrival_moment));
  clauses[0].hypotheses.erase(
      std::remove_if(clauses[0].hypotheses.begin(),
                     clauses[0].hypotheses.end(),
                     is_redundant_arrival_moment),
      clauses[0].hypotheses.end());
  preview.core.hypothesis_claims.erase(
      std::remove_if(preview.core.hypothesis_claims.begin(),
                     preview.core.hypothesis_claims.end(),
                     is_redundant_arrival_moment),
      preview.core.hypothesis_claims.end());
  auto manifest =
      mwperf::MetricSupportManifest::from_clauses(std::move(clauses));
  REQUIRE(manifest);
  preview.metric_support_manifest =
      std::make_shared<const mwperf::MetricSupportManifest>(
          std::move(manifest).value());
  reseal_preview(preview);

  auto arrivals = complete_arrival_capabilities();
  arrivals.analytic_moments.reset();
  const auto decision = mwperf::negotiate_capabilities(
      requirements, preview, arrivals);
  INFO(mwperf::explain_capability_failure(decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(decision));
}

TEST_CASE("C14 optional V1 and V2 metadata never changes v1 acceptance",
          "[c14][integration]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto arrivals = complete_arrival_capabilities();
  auto v0_only = preview_for_clause(requirements);
  auto stronger = preview_for_clause(
      requirements, mwperf::ConstructionMethodV1::engineered_deterministic,
      mwperf::ProducerModeV1::in_process_builder,
      {{mwperf::OptionalReportedEvidenceKindV1::v1_fibre_realizability,
        "v1.test", 1U},
       {mwperf::OptionalReportedEvidenceKindV1::v2_dynamic_lift, "v2.test",
        1U}});
  const auto v0_decision =
      mwperf::negotiate_capabilities(requirements, v0_only, arrivals);
  const auto stronger_decision =
      mwperf::negotiate_capabilities(requirements, stronger, arrivals);
  CHECK(mwperf::capability_decision_is_accepted(v0_decision));
  CHECK(mwperf::capability_decision_is_accepted(stronger_decision));
  REQUIRE(mwperf::accepted_capability_contract(v0_decision) != nullptr);
  REQUIRE(mwperf::accepted_capability_contract(stronger_decision) != nullptr);
  const auto v0_contracts =
      mwperf::accepted_capability_contract(v0_decision)->metric_contracts();
  const auto stronger_contracts =
      mwperf::accepted_capability_contract(stronger_decision)
          ->metric_contracts();
  CHECK(std::vector<mwperf::ResolvedMetricContractV1>(v0_contracts.begin(),
                                                       v0_contracts.end()) ==
        std::vector<mwperf::ResolvedMetricContractV1>(
            stronger_contracts.begin(), stronger_contracts.end()));
}

TEST_CASE("C14 direct decoding is exact-request-only and homogeneous",
          "[c14][integration]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  const std::string metric =
      R"json({"id":"direct","kind":"stationary_empty_probability","parameters":{}})json";
  auto direct = parse_request(catalog, metric, false, stationary_selection(),
                              direct_solver());
  REQUIRE(direct);
  const auto direct_requirements =
      mwperf::requirements_for_metric(direct.value());
  const auto direct_preview = preview_for_clause(direct_requirements);
  const auto accepted = mwperf::negotiate_capabilities(
      direct_requirements, direct_preview, complete_arrival_capabilities());
  INFO(mwperf::explain_capability_failure(accepted).message);
  REQUIRE(mwperf::capability_decision_is_accepted(accepted));
  const auto* contract = mwperf::accepted_capability_contract(accepted);
  REQUIRE(contract != nullptr);
  CHECK(contract->semantic() ==
        mwperf::SemanticTagV1::direct_metric_decoder);
  CHECK(contract->runtime_access() ==
        mwperf::RuntimeAccessTagV1::direct_metric_decoder);
  REQUIRE(contract->metric_contracts().size() == 1U);
  CHECK(contract->metric_contracts()[0].backend_route ==
        mwperf::BackendRouteKindV1::exact_direct);

  auto reusable = parse_request(
      catalog,
      R"json({"id":"reusable","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(reusable);
  std::array<mwperf::MetricRequest, 2U> mixed{direct.value(),
                                             reusable.value()};
  const auto mixed_requirements =
      mwperf::aggregate_metric_requirements(mixed);
  CHECK(mixed_requirements.regime_compatibility().kind ==
        mwperf::RegimeCompatibilityKindV1::incompatible_solver);
  const auto rejected = mwperf::negotiate_capabilities(
      mixed_requirements, direct_preview, complete_arrival_capabilities());
  CHECK_FALSE(mwperf::capability_decision_is_accepted(rejected));
}

TEST_CASE("C14 negotiation rejects route-axis cross products deterministically",
          "[c14][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto preview = preview_for_clause(requirements);

  mwperf::ArrivalCapabilities missing_iid = complete_arrival_capabilities();
  // Remove every complete exact-IID-law witness.  The portable recipe, the
  // factorized generator and the legacy explicit joint table are alternatives.
  missing_iid.exact_iid_joint_vector.reset();
  missing_iid.exact_factorized_iid_generator.reset();
  missing_iid.exact_portable_iid_recipe.reset();
  // Temporal access remains advertised by the configured arrival.  It cannot
  // be cross-combined with the preview's phase-free IID route.
  const auto first =
      mwperf::negotiate_capabilities(requirements, preview, missing_iid);
  const auto second =
      mwperf::negotiate_capabilities(requirements, preview, missing_iid);
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(first));
  const auto* rejected = mwperf::rejected_capability_decision(first);
  const auto* rejected_second = mwperf::rejected_capability_decision(second);
  REQUIRE(rejected != nullptr);
  REQUIRE(rejected_second != nullptr);
  CHECK(rejected->ordered_failures == rejected_second->ordered_failures);
  CHECK(rejected->alternatives == rejected_second->alternatives);
  CHECK(rejected->requirements_digest ==
        rejected_second->requirements_digest);
  CHECK(rejected->arrival_capabilities_digest ==
        rejected_second->arrival_capabilities_digest);
  CHECK(rejected->preview_digest == rejected_second->preview_digest);
  REQUIRE_FALSE(rejected->ordered_failures.empty());
  CHECK(std::is_sorted(
      rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
      [](const mwperf::CapabilityFailureV1& left,
         const mwperf::CapabilityFailureV1& right) {
        return std::pair{left.authored_metric_index, left.axis} <
               std::pair{right.authored_metric_index, right.axis};
      }));
  CHECK(rejected->ordered_failures.front().metric_id == "empty");
  CHECK(rejected->ordered_failures.front().axis ==
        mwperf::CapabilityAxisV1::arrival);
  const mwperf::Diagnostic first_diagnostic =
      mwperf::explain_capability_failure(first);
  const mwperf::Diagnostic second_diagnostic =
      mwperf::explain_capability_failure(second);
  CHECK(first_diagnostic == second_diagnostic);
  CHECK(first_diagnostic.code == "c14_capability_arrival_capability_missing");
  CHECK(first_diagnostic.json_pointer == "/metrics/0");
}

TEST_CASE("C32 portable IID recipe alone admits exact late-IID routes",
          "[c14][c32][cp09][unit]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto preview = preview_for_clause(requirements);

  mwperf::ArrivalCapabilities recipe_only = complete_arrival_capabilities();
  recipe_only.exact_iid_joint_vector.reset();
  recipe_only.exact_factorized_iid_generator.reset();
  recipe_only.exact_portable_iid_recipe =
      mwperf::ExactPortableIidRecipeCapability{
          mwperf::AccessProvision::portable_only};

  const auto decision = mwperf::negotiate_capabilities(
      requirements, preview, recipe_only);
  INFO(mwperf::explain_capability_failure(decision).message);
  REQUIRE(mwperf::capability_decision_is_accepted(decision));
}

TEST_CASE("C14 negotiation rejects malformed arrival capability records",
          "[c14][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"empty","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto preview = preview_for_clause(requirements);
  std::vector<mwperf::ArrivalCapabilities> malformed_cases;
  const auto append_case = [&malformed_cases](const auto& mutate) {
    auto value = complete_arrival_capabilities();
    mutate(value);
    malformed_cases.push_back(std::move(value));
  };
  // None of these fields is needed by the selected IID route.  Closed-record
  // validation is nevertheless whole-value validation, never lazy inspection
  // of only the fields a successful route happens to use.
  append_case([](auto& value) {
    value.exact_positive_support =
        mwperf::CapabilityAvailability::unavailable;
  });
  append_case([](auto& value) {
    value.finite_enumerated_predictive_phase =
        mwperf::CapabilityAvailability::unavailable;
    value.finite_enumerated_transition_row =
        mwperf::CapabilityAvailability::available;
  });
  append_case([](auto& value) {
    value.adjacent_batch_replay->explicit_initial_state = false;
    value.adjacent_batch_replay->explicit_phase = false;
    value.adjacent_batch_replay->normalized_initial_law = false;
    value.adjacent_batch_replay->named_stationary_initialization = false;
  });
  append_case([](auto& value) {
    value.sequential_normalized_sampler =
        mwperf::CapabilityAvailability::unavailable;
    value.adjacent_batch_replay->provision =
        mwperf::AccessProvision::process_local_only;
  });
  append_case([](auto& value) {
    value.stationary_phase_law =
        mwperf::StationaryPhaseLawStatus::unavailable;
    value.adjacent_batch_replay->named_stationary_initialization = true;
  });
  append_case([](auto& value) {
    value.stationary_phase_law =
        static_cast<mwperf::StationaryPhaseLawStatus>(255U);
  });
  append_case([](auto& value) {
    value.analytic_moments->maximum_order.reset();
  });
  append_case([](auto& value) {
    value.analytic_moments->maximum_order = BigNat{0U};
  });
  append_case([](auto& value) {
    value.analytic_moments->maximum_order = BigNat{3U};
  });
  append_case([](auto& value) {
    value.analytic_moments->conditioned_on_phase = true;
  });
  append_case([](auto& value) {
    value.exact_iid_joint_vector->finite_support = false;
  });
  append_case([](auto& value) {
    value.exact_iid_joint_vector->provision =
        mwperf::AccessProvision::process_local_only;
  });
  append_case([](auto& value) {
    value.exact_factorized_iid_generator->provision =
        mwperf::AccessProvision::process_local_only;
  });
  append_case([](auto& value) {
    value.exact_portable_iid_recipe =
        mwperf::ExactPortableIidRecipeCapability{
            mwperf::AccessProvision::process_local_only};
  });
  append_case([](auto& value) {
    value.analytic_transform->provision =
        mwperf::AccessProvision::process_local_only;
  });
  append_case([](auto& value) {
    value.exact_joint_distribution->scope =
        mwperf::DistributionScope::per_coordinate;
  });
  append_case([](auto& value) {
    value.exact_coordinate_distributions->scope =
        mwperf::DistributionScope::joint_vector;
  });
  append_case([](auto& value) { value.exact_joint_moments->joint = false; });
  append_case(
      [](auto& value) { value.exact_coordinate_moments->joint = true; });
  append_case([](auto& value) {
    value.unit_cube_transform->dimension = BigNat{0U};
  });

  for (std::size_t index = 0U; index < malformed_cases.size(); ++index) {
    INFO("malformed arrival case " << index);
    const auto decision = mwperf::negotiate_capabilities(
        requirements, preview, malformed_cases[index]);
    REQUIRE_FALSE(mwperf::capability_decision_is_accepted(decision));
    const auto* rejected = mwperf::rejected_capability_decision(decision);
    REQUIRE(rejected != nullptr);
    REQUIRE_FALSE(rejected->ordered_failures.empty());
    CHECK(rejected->ordered_failures.front().axis ==
          mwperf::CapabilityAxisV1::arrival);
    CHECK(rejected->ordered_failures.front().kind ==
          mwperf::CapabilityFailureKindV1::arrival_capability_missing);
  }
}

TEST_CASE("C14 multi-metric negotiation is transactional all-or-error",
          "[c14][negative]") {
  const mwperf::QueueCatalog catalog = make_catalog();
  auto first = parse_request(
      catalog,
      R"json({"id":"first","kind":"stationary_empty_probability","parameters":{}})json");
  auto second = parse_request(
      catalog,
      R"json({"id":"second","kind":"stationary_backlog_tail","parameters":{"threshold":4}})json");
  REQUIRE(first);
  REQUIRE(second);
  const auto first_requirements =
      mwperf::requirements_for_metric(first.value());
  std::array<mwperf::MetricRequest, 2U> requests{first.value(),
                                                second.value()};
  const auto aggregate = mwperf::aggregate_metric_requirements(requests);
  const auto preview = preview_for_clause(first_requirements);
  const auto decision = mwperf::negotiate_capabilities(
      aggregate, preview, complete_arrival_capabilities());
  REQUIRE_FALSE(mwperf::capability_decision_is_accepted(decision));
  CHECK(mwperf::accepted_capability_contract(decision) == nullptr);
  const auto* rejected = mwperf::rejected_capability_decision(decision);
  REQUIRE(rejected != nullptr);
  CHECK(std::any_of(
      rejected->ordered_failures.begin(), rejected->ordered_failures.end(),
      [](const mwperf::CapabilityFailureV1& failure) {
        return failure.metric_id == "second";
      }));
}

TEST_CASE("C14 engineered and sampling fixture modes are law-orthogonal",
          "[c14][integration]") {
  std::ifstream input(c14_fixture_path("mode_orthogonality_profiles.json"));
  REQUIRE(input.is_open());
  const nlohmann::json fixture = nlohmann::json::parse(input);
  REQUIRE(fixture.at("profiles").is_array());
  REQUIRE(fixture.at("profiles").size() == 10U);

  const mwperf::QueueCatalog catalog = make_catalog();
  auto request = parse_request(
      catalog,
      R"json({"id":"baseline","kind":"stationary_empty_probability","parameters":{}})json");
  REQUIRE(request);
  const auto requirements = mwperf::requirements_for_metric(request.value());
  const auto arrivals = complete_arrival_capabilities();

  const auto construction_method = [](const std::string& text) {
    if (text == "engineered_hybrid") {
      return mwperf::ConstructionMethodV1::engineered_hybrid;
    }
    if (text == "sampled_offline") {
      return mwperf::ConstructionMethodV1::sampled_offline;
    }
    return mwperf::ConstructionMethodV1::engineered_deterministic;
  };
  const auto producer_mode = [](const std::string& text) {
    return text == "local_executable_builder"
               ? mwperf::ProducerModeV1::local_executable_builder
               : mwperf::ProducerModeV1::in_process_builder;
  };

  for (const std::string family :
       {"crossbar", "interval", "blossom", "mwis", "packing"}) {
    std::vector<nlohmann::json> pair;
    for (const auto& profile : fixture.at("profiles")) {
      if (profile.at("family") == family) {
        pair.push_back(profile);
      }
    }
    REQUIRE(pair.size() == 2U);
    CHECK(pair[0].at("provider_id") != pair[1].at("provider_id"));
    CHECK(pair[0].at("construction_method") !=
          pair[1].at("construction_method"));
    CHECK(pair[0].at("semantic") == pair[1].at("semantic"));
    CHECK(pair[0].at("runtime_access") == pair[1].at("runtime_access"));
    CHECK(pair[0].at("payload_class") == pair[1].at("payload_class"));
    CHECK(pair[0].at("accepted_metrics") == pair[1].at("accepted_metrics"));
    CHECK(pair[0].at("rejected_metrics") == pair[1].at("rejected_metrics"));

    const auto first_preview = preview_for_clause(
        requirements,
        construction_method(pair[0].at("construction_method").get<std::string>()),
        producer_mode(pair[0].at("producer_mode").get<std::string>()), {},
        pair[0].at("provider_id").get<std::string>());
    const auto second_preview = preview_for_clause(
        requirements,
        construction_method(pair[1].at("construction_method").get<std::string>()),
        producer_mode(pair[1].at("producer_mode").get<std::string>()), {},
        pair[1].at("provider_id").get<std::string>());
    const auto first_decision =
        mwperf::negotiate_capabilities(requirements, first_preview, arrivals);
    const auto second_decision =
        mwperf::negotiate_capabilities(requirements, second_preview, arrivals);
    REQUIRE(mwperf::capability_decision_is_accepted(first_decision));
    REQUIRE(mwperf::capability_decision_is_accepted(second_decision));
    const auto* first_contract =
        mwperf::accepted_capability_contract(first_decision);
    const auto* second_contract =
        mwperf::accepted_capability_contract(second_decision);
    REQUIRE(first_contract != nullptr);
    REQUIRE(second_contract != nullptr);
    CHECK(first_contract->provider() != second_contract->provider());
    CHECK(first_contract->construction_method() !=
          second_contract->construction_method());
    CHECK(first_contract->semantic() == second_contract->semantic());
    CHECK(first_contract->runtime_access() == second_contract->runtime_access());
    CHECK(first_contract->payload_class() == second_contract->payload_class());
    CHECK(first_contract->structural_manifest() ==
          second_contract->structural_manifest());
  }
}
