#include <algorithm>
#include <array>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/kernel/arrival_capability.hpp"
#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/kernel/reduced_edge.hpp"
#include "mwperf/kernel/resolved_action.hpp"
#include "mwperf/kernel/stage_context.hpp"
#include "mwperf/kernel/v0_witness.hpp"
#include "fixtures/c17/generic_temporal_fixture.hpp"
#include "support/c17_spy_plugs.hpp"

namespace {

using mwperf::testing::c17::NamesArrivalCapability;
using mwperf::testing::c17::NamesFreshArrival;
using mwperf::testing::c17::NamesPhysicalFidelity;
using mwperf::testing::c17::NamesStability;
using mwperf::testing::c17::NamesV1Witness;
using mwperf::testing::c17::NamesV2Witness;
using mwperf::testing::c17::PubliclyEnumerableLaw;
using mwperf::testing::c17::PubliclySampleableLaw;

static_assert(!std::default_initializable<mwperf::PreArrivalContext>);
static_assert(!std::default_initializable<mwperf::ResolverContext>);
static_assert(!std::default_initializable<mwperf::PostArrivalContext>);
static_assert(!NamesFreshArrival<mwperf::PreArrivalContext>);
static_assert(!NamesFreshArrival<mwperf::ResolverContext>);
static_assert(NamesFreshArrival<mwperf::PostArrivalContext>);
static_assert(!NamesArrivalCapability<mwperf::PreArrivalContext>);
static_assert(!NamesArrivalCapability<mwperf::ResolverContext>);
static_assert(!NamesArrivalCapability<mwperf::PostArrivalContext>);

static_assert(!std::default_initializable<mwperf::ArrivalCapability>);
static_assert(!std::copy_constructible<mwperf::ArrivalCapability>);
static_assert(std::move_constructible<mwperf::ArrivalCapability>);
static_assert(!std::is_move_assignable_v<mwperf::ArrivalCapability>);

static_assert(!PubliclyEnumerableLaw<mwperf::OpportunityLaw>);
static_assert(!PubliclyEnumerableLaw<mwperf::ActionLaw>);
static_assert(!PubliclyEnumerableLaw<mwperf::ArrivalTransitionLaw>);
static_assert(!PubliclyEnumerableLaw<mwperf::PostClosureLaw>);
static_assert(!PubliclySampleableLaw<mwperf::OpportunityLaw>);
static_assert(!PubliclySampleableLaw<mwperf::ActionLaw>);
static_assert(!PubliclySampleableLaw<mwperf::ArrivalTransitionLaw>);
static_assert(!PubliclySampleableLaw<mwperf::PostClosureLaw>);

static_assert(!std::default_initializable<mwperf::AuditedRowProvider>);
static_assert(!std::default_initializable<mwperf::AuditedSlotExecutor>);
static_assert(!std::default_initializable<mwperf::AuditedThreeBinResponse>);
static_assert(!std::default_initializable<
              mwperf::AuditedFinitePrefixConstantTailResponse>);
static_assert(!std::default_initializable<mwperf::AuditedRomrView>);
static_assert(!std::default_initializable<mwperf::AuditedResidenceProvider>);
static_assert(!std::default_initializable<mwperf::AuditedTemporalFramework>);
static_assert(!NamesV1Witness<mwperf::V0WitnessReport>);
static_assert(!NamesV2Witness<mwperf::V0WitnessReport>);
static_assert(!NamesPhysicalFidelity<mwperf::V0WitnessReport>);
static_assert(!NamesStability<mwperf::V0WitnessReport>);

mwperf::CompensatedNumericalRowImageV1 recompute_numerical_row_image(
    const mwperf::MarkedKernelRow& row) {
  long double sum = 0.0L;
  long double correction = 0.0L;
  auto status = mwperf::NumericalProbabilityImageStatusV1::finite;
  for (const auto& atom : row.atoms()) {
    const long double updated = sum + atom.numerical_image;
    if (std::fabs(sum) >= std::fabs(atom.numerical_image)) {
      correction += (sum - updated) + atom.numerical_image;
    } else {
      correction += (atom.numerical_image - updated) + sum;
    }
    sum = updated;
    if (atom.numerical_image_status ==
        mwperf::NumericalProbabilityImageStatusV1::overflow) {
      status = mwperf::NumericalProbabilityImageStatusV1::overflow;
    } else if (
        status == mwperf::NumericalProbabilityImageStatusV1::finite &&
        atom.numerical_image_status ==
            mwperf::NumericalProbabilityImageStatusV1::positive_underflow) {
      status =
          mwperf::NumericalProbabilityImageStatusV1::positive_underflow;
    }
  }
  const long double compensated_total = sum + correction;
  return {compensated_total, compensated_total - 1.0L, status};
}

void check_same_row(const mwperf::MarkedKernelRow& left,
                    const mwperf::MarkedKernelRow& right) {
  REQUIRE(left.atoms().size() == right.atoms().size());
  CHECK(left.exact_total_mass() == right.exact_total_mass());
  CHECK(left.categorical() == right.categorical());
  CHECK(left.numerical_row_image() == right.numerical_row_image());
  CHECK(std::equal(left.stage_mass_diagnostics().begin(),
                   left.stage_mass_diagnostics().end(),
                   right.stage_mass_diagnostics().begin(),
                   right.stage_mass_diagnostics().end()));
  for (std::size_t index = 0U; index < left.atoms().size(); ++index) {
    const auto& left_atom = left.atoms()[index];
    const auto& right_atom = right.atoms()[index];
    CHECK(left_atom.edge == right_atom.edge);
    CHECK(left_atom.exact_mass == right_atom.exact_mass);
    CHECK(left_atom.structural_support == right_atom.structural_support);
    CHECK(left_atom.numerical_image == right_atom.numerical_image);
    CHECK(left_atom.numerical_image_status ==
          right_atom.numerical_image_status);
    CHECK(left_atom.exact_cumulative_mass ==
          right_atom.exact_cumulative_mass);
  }
}

mwperf::Digest256 exact_reduced_state_identity(
    const mwperf::ReducedStateV1& state) {
  mwperf::Sha256 hash;
  REQUIRE(hash.update(std::as_bytes(
      std::span(state.codec.id.data(), state.codec.id.size()))));
  const std::array<std::byte, 4U> version{
      static_cast<std::byte>((state.codec.version >> 24U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 16U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 8U) & 0xffU),
      static_cast<std::byte>(state.codec.version & 0xffU)};
  REQUIRE(hash.update(version));
  REQUIRE(hash.update(state.canonical_value));
  return hash.finalize();
}

mwperf::PlugDescriptor unmarked_descriptor(
    const mwperf::PlugDescriptor& source) {
  mwperf::PlugDescriptor descriptor = source;
  descriptor.marks.clear();
  return descriptor;
}

mwperf::PlugDescriptor c_plus_mark_descriptor(
    const mwperf::PlugDescriptor& source) {
  mwperf::PlugDescriptor descriptor = source;
  REQUIRE(descriptor.marks.size() == 1U);
  descriptor.marks.front().c14_mark.reveal_stage =
      mwperf::MetricRevealStageV1::postarrival;
  descriptor.marks.front().c14_mark.codec = {"c17.fixture.mark", 1U};
  descriptor.marks.front().decoder_source =
      mwperf::MarkDecoderSourceV1::c_plus_joint_output;
  descriptor.marks.front().decoder_input_codec =
      {"c17.fixture.postclosure", 1U};
  return descriptor;
}

TEST_CASE("C17 stage types expose exactly the causal public surface",
          "[c17][unit]") {
  const std::array expected{
      mwperf::CausalStageV1::c_minus, mwperf::CausalStageV1::resolver,
      mwperf::CausalStageV1::arrival, mwperf::CausalStageV1::c_plus,
      mwperf::CausalStageV1::psi};
  CHECK(mwperf::kCausalStageOrderV1 == expected);
}

TEST_CASE("C17 arrival capability is consumed by one common application",
          "[c17][unit]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto branch = mwperf::testing::c17::branch("arrival-once", {0U, 1U});
  auto prepared = mwperf::prepare_configured_arrival_law(
      base.configured_arrival, base.phase_zero);
  REQUIRE(prepared);
  CHECK(prepared.value().enumerable());
  CHECK(prepared.value().realizable());
  CHECK(prepared.value().support_size() == 0U);
  CHECK(prepared.value().raw_sum() == nullptr);

  auto capability =
      mwperf::testing::C17FixtureAccess::arrival_capability(branch);
  auto first =
      mwperf::testing::C17FixtureAccess::apply_arrival_enumeration(
          prepared.value(), std::move(capability),
          mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(first);
  const auto enumerated =
      mwperf::testing::C17FixtureAccess::atoms(first.value());
  REQUIRE(enumerated.size() == 2U);
  const auto half = mwperf::testing::c17::rational(1, 2);
  CHECK(enumerated[0U].raw_mass == half);
  CHECK(enumerated[1U].raw_mass == half);
  CHECK(first.value().raw_sum() != nullptr);
  CHECK(*first.value().raw_sum() == mwperf::ExactRational::one());

  auto reused =
      mwperf::testing::C17FixtureAccess::apply_arrival_enumeration(
          prepared.value(), std::move(capability),
          mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE_FALSE(reused);
  CHECK(reused.error().code ==
        "c17.arrival_capability_reused_or_mismatched");

  auto instance_key = mwperf::make_physical_reference_instance_key(
      base.instance.fingerprints().combined, mwperf::BigNat{0U});
  REQUIRE(instance_key);
  auto rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed{0xC1703U},
      mwperf::StageTag::configured_arrival, instance_key.value());
  auto realized =
      mwperf::testing::C17FixtureAccess::apply_arrival_realization(
          prepared.value(),
          mwperf::testing::C17FixtureAccess::arrival_capability(branch),
          rng, mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(realized);
  const auto same_transition = std::count_if(
      enumerated.begin(), enumerated.end(),
      [&](const mwperf::ArrivalTransitionLawAtomV1& atom) {
        return mwperf::same_arrival_transition_value(
            atom.outcome, realized.value());
      });
  CHECK(same_transition == 1);

  auto mismatched = mwperf::testing::C17FixtureAccess::arrival_capability(
      branch);
  CHECK_FALSE(mwperf::testing::C17FixtureAccess::consume_arrival_capability(
      mismatched,
      mwperf::testing::c17::branch("another-arrival-branch", {0U, 1U})));
}

TEST_CASE("C17 configured realization consumes borrowed schema-4 IID atoms",
          "[c17][unit][c32][arrival]") {
  static constexpr std::string_view model = R"json({
    "schema_version":"4.0.0",
    "switch":{"kind":"generalized","queue_capacity":"NoDrop",
              "queues":[{"id":"q0"},{"id":"q1"}]},
    "scheduler":{"name":"conflict_graph_max_weight","params":{
      "constraint":{"conflicts":[["q0","q1"]]},"priority":null,
      "max_search_states":null}},
    "arrival":{"family":"iid_count_table","outcomes":[
      {"id":"certain","probability":1,"counts":[
        {"queue_id":"q0","count":2},{"queue_id":"q1","count":1}]}],
      "metadata":{}},
    "telemetry":{"observation":{"enabled":false,"block_slots":null,
                                  "targets":[]}}
  })json";
  auto document = mwperf::load_document(
      mwperf::testing::c16_designated_detail::write_input(
          "c17-schema4-borrowed-arrival", model));
  REQUIRE(document);
  auto model_node = mwperf::extract_executable_model(document.value());
  REQUIRE(model_node);
  auto authored = mwperf::parse_model_config(model_node.value());
  REQUIRE(authored);
  auto queues = mwperf::build_queue_catalog(authored.value().switch_config);
  REQUIRE(queues);
  auto law =
      mwperf::compile_arrival_law(authored.value().arrival, queues.value());
  REQUIRE(law);

  const auto& base = mwperf::testing::c17::math_base();
  auto instance_key = mwperf::make_physical_reference_instance_key(
      base.instance.fingerprints().combined, mwperf::BigNat{0U});
  REQUIRE(instance_key);
  auto stream = mwperf::make_configured_arrival_stream_key(
      law.value(),
      mwperf::derive_rng_stream(
          mwperf::MasterSeed{UINT64_C(0xC1732)},
          mwperf::StageTag::configured_arrival, instance_key.value()));
  REQUIRE(stream);
  auto process = mwperf::instantiate_arrival_process(
      law.value(), mwperf::ArrivalInitialState{mwperf::RenewalOrigin{}},
      std::move(stream).value());
  REQUIRE(process);
  auto first = mwperf::next_arrival_step(process.value(), mwperf::BigNat{0U});
  REQUIRE(first);

  auto prepared = mwperf::prepare_configured_arrival_law(
      law.value(), first.value().phase_before);
  REQUIRE(prepared);
  REQUIRE(prepared.value().realizable());
  const auto branch =
      mwperf::testing::c17::branch("schema4-borrowed-arrival", {0U, 1U});
  auto realization_rng = mwperf::derive_rng_stream(
      mwperf::MasterSeed{UINT64_C(0xC1733)},
      mwperf::StageTag::configured_arrival, instance_key.value());
  auto realized =
      mwperf::testing::C17FixtureAccess::apply_arrival_realization(
          prepared.value(),
          mwperf::testing::C17FixtureAccess::arrival_capability(branch),
          realization_rng, mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(realized);

  const auto q0 = queues.value().index_at(0U);
  const auto q1 = queues.value().index_at(1U);
  REQUIRE(q0);
  REQUIRE(q1);
  const auto& binding = mwperf::arrival_law_binding(law.value());
  auto q0_count = mwperf::project_arrival_count(
      realized.value().batch, q0.value(), binding);
  auto q1_count = mwperf::project_arrival_count(
      realized.value().batch, q1.value(), binding);
  REQUIRE(q0_count);
  REQUIRE(q1_count);
  CHECK(q0_count.value() == mwperf::BigNat{2U});
  CHECK(q1_count.value() == mwperf::BigNat{1U});
}

TEST_CASE("C17 conditional rows retain exact authored mass diagnostics",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {0U});
  const auto half = mwperf::testing::c17::rational(1, 2);
  const auto accepted_delta = mwperf::testing::c17::rational(1, 2'000'000'000);
  const auto second = half + accepted_delta;
  const auto authored_sum = mwperf::ExactRational::one() + accepted_delta;

  auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
      {mwperf::testing::c17::opportunity_atom(
           "normalization-a", prearrival_backlog, half, true, {0U}),
       mwperf::testing::c17::opportunity_atom(
           "normalization-b", prearrival_backlog, second, true, {1U})},
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(law);
  REQUIRE(law.value().raw_sum() != nullptr);
  REQUIRE(law.value().signed_delta_from_one() != nullptr);
  CHECK(*law.value().raw_sum() == authored_sum);
  CHECK(*law.value().signed_delta_from_one() == accepted_delta);

  const auto atoms = mwperf::testing::C17FixtureAccess::atoms(law.value());
  REQUIRE(atoms.size() == 2U);
  CHECK(atoms[0].raw_mass == half);
  CHECK(atoms[1].raw_mass == second);

  const auto* pmf = mwperf::testing::C17FixtureAccess::pmf(law.value());
  REQUIRE(pmf != nullptr);
  REQUIRE(pmf->normalized_weights().size() == 2U);
  const auto normalized_first = mwperf::checked_divide(half, authored_sum);
  const auto normalized_second = mwperf::checked_divide(second, authored_sum);
  REQUIRE(normalized_first);
  REQUIRE(normalized_second);
  CHECK(pmf->normalized_weights()[0] == normalized_first.value());
  CHECK(pmf->normalized_weights()[1] == normalized_second.value());
  CHECK(pmf->normalized_weights()[0] + pmf->normalized_weights()[1] ==
        mwperf::ExactRational::one());
}

TEST_CASE("C17 empty-target pruning preserves the emitted algebraic face",
          "[c17][unit]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {0U});
  const auto backlog = mwperf::testing::c17::target_backlog(base, {0U});
  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto q0_id = base.instance.queues().entries()[0U].id;
  const auto zero = mwperf::ExactRational::zero();
  const auto five = mwperf::testing::c17::rational(5, 1);
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, zero},
      {{q0_id}, {}, five},
  }};
  const mwperf::OpportunityMark opportunity{
      {exact_reduced_state_identity(state), {}}, backlog, face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.emitted-face", {0x01U}), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  const auto ledger_before = optimizer.value().ledger_snapshot();

  auto law = mwperf::prepare_reduced_action_law(
      base.instance, state, opportunity, optimizer.value());
  INFO((law ? std::string{} : law.error().code + ": " + law.error().message));
  REQUIRE(law);
  const auto atoms = mwperf::testing::C17FixtureAccess::atoms(law.value());
  REQUIRE(atoms.size() == 1U);
  const auto& action = atoms.front().outcome;

  CHECK_FALSE(action.schedule.at(q0));
  CHECK_FALSE(action.actual_departure.at(q0));
  CHECK(action.evidence.resolution_kind ==
        mwperf::ActionResolutionKindV1::emitted_schedule_face);
  CHECK(action.evidence.common_feasible_schedule);
  REQUIRE(action.evidence.exact_target_class.has_value());
  CHECK(*action.evidence.exact_target_class ==
        mwperf::AlgebraicTargetClass::forced_in);
  REQUIRE(action.evidence.emitted_face.has_value());
  const auto& decision = *action.evidence.emitted_face;
  REQUIRE(decision.ordered_target_faces.size() == 1U);
  const auto& target = decision.ordered_target_faces.front();
  CHECK(target.target.ordinal() == q0.ordinal());
  CHECK(target.forced_out_residual_max == zero);
  CHECK(target.forced_in_residual_max == five);
  CHECK(target.algebraic_margin == five);
  CHECK(target.exact_class == mwperf::AlgebraicTargetClass::forced_in);
  CHECK_FALSE(target.target_eligible);
  CHECK(decision.selected_primary_score == five);
  CHECK_FALSE(opportunity.exact_opportunity_evidence.has_value());

  mwperf::OpportunityMark reordered = opportunity;
  std::reverse(reordered.resolver_face->alternatives.begin(),
               reordered.resolver_face->alternatives.end());
  auto reordered_law = mwperf::prepare_reduced_action_law(
      base.instance, state, reordered, optimizer.value());
  REQUIRE(reordered_law);
  const auto reordered_atoms =
      mwperf::testing::C17FixtureAccess::atoms(reordered_law.value());
  REQUIRE(reordered_atoms.size() == 1U);
  CHECK(reordered_atoms.front().outcome == action);
  CHECK(optimizer.value().ledger_snapshot() == ledger_before);
}

TEST_CASE("C17 resolver is bound to its exact predecision state branch",
          "[c17][negative]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {1U});
  const auto foreign_state =
      mwperf::testing::c17::reduced_state(base, {2U});
  const auto backlog = mwperf::testing::c17::target_backlog(base, {1U});
  const auto q0 = base.instance.queues().entries().front().id;
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, mwperf::ExactRational::zero()},
      {{q0}, {}, mwperf::ExactRational::zero()},
  }};
  const mwperf::OpportunityMark opportunity{
      {exact_reduced_state_identity(state), {}}, backlog, face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.branch-bound-face", {0x01U}),
      {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);

  auto accepted = mwperf::prepare_reduced_action_law(
      base.instance, state, opportunity, optimizer.value());
  REQUIRE(accepted);
  auto rejected = mwperf::prepare_reduced_action_law(
      base.instance, foreign_state, opportunity, optimizer.value());
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c17.resolver_state_branch_mismatch");
}

TEST_CASE("C17 resolves a coupled emitted face by one common exact maximum",
          "[c17][unit]") {
  const auto& instance =
      mwperf::testing::c17::conflicting_face_instance();
  const auto entries = instance.queues().entries();
  REQUIRE(entries.size() == 2U);
  const std::vector<mwperf::QueueId> targets{entries[0U].id,
                                             entries[1U].id};
  const auto backlog = mwperf::testing::c17::target_backlog(
      instance, targets, {1U, 1U});
  const auto state =
      mwperf::testing::c17::reduced_state(targets, {1U, 1U});
  const auto zero = mwperf::ExactRational::zero();
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, zero},
      {{targets[0U]}, {}, zero},
      {{targets[1U]}, {}, zero},
  }};

  const auto resolve = [&](mwperf::V0EmittedOpportunityFaceV1 supplied) {
    const mwperf::OpportunityMark opportunity{
        {exact_reduced_state_identity(state), {}}, backlog,
        std::move(supplied), std::nullopt,
        mwperf::testing::c17::value("c17.fixture.emitted-face", {0x02U}),
        {}};
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
    REQUIRE(optimizer);
    const auto ledger_before = optimizer.value().ledger_snapshot();
    auto law = mwperf::prepare_reduced_action_law(
        instance, state, opportunity, optimizer.value());
    INFO((law ? std::string{}
              : law.error().code + ": " + law.error().message));
    REQUIRE(law);
    const auto atoms = mwperf::testing::C17FixtureAccess::atoms(law.value());
    REQUIRE(atoms.size() == 1U);
    CHECK(optimizer.value().ledger_snapshot() == ledger_before);
    return atoms.front().outcome;
  };

  const auto selected = resolve(face);
  const auto q0 = instance.queues().index_at(0U).value();
  const auto q1 = instance.queues().index_at(1U).value();
  CHECK(selected.schedule.at(q0));
  CHECK_FALSE(selected.schedule.at(q1));
  CHECK(selected.actual_departure.at(q0));
  CHECK_FALSE(selected.actual_departure.at(q1));
  REQUIRE(selected.evidence.emitted_face.has_value());
  const auto& decision = *selected.evidence.emitted_face;
  REQUIRE(decision.ordered_target_faces.size() == 2U);
  for (std::size_t target = 0U; target < 2U; ++target) {
    CAPTURE(target);
    const auto& evidence = decision.ordered_target_faces[target];
    CHECK(evidence.target.ordinal() == target);
    CHECK(evidence.forced_out_residual_max ==
          mwperf::testing::c17::rational(1, 1));
    CHECK(evidence.forced_in_residual_max == zero);
    CHECK(evidence.algebraic_margin == zero);
    CHECK(evidence.exact_class == mwperf::AlgebraicTargetClass::tie);
    CHECK(evidence.target_eligible);
  }
  CHECK(decision.selected_primary_score ==
        mwperf::testing::c17::rational(1, 1));
  CHECK(decision.configured_secondary_code == mwperf::BigNat{2U});

  auto reordered_face = face;
  std::reverse(reordered_face.alternatives.begin(),
               reordered_face.alternatives.end());
  CHECK(resolve(std::move(reordered_face)) == selected);
}

TEST_CASE("C17 rejects malformed emitted common faces",
          "[c17][negative]") {
  const auto& instance =
      mwperf::testing::c17::conflicting_face_instance();
  const auto entries = instance.queues().entries();
  REQUIRE(entries.size() == 2U);
  const std::vector<mwperf::QueueId> targets{entries[0U].id,
                                             entries[1U].id};
  const auto backlog = mwperf::testing::c17::target_backlog(
      instance, targets, {1U, 1U});
  const auto state =
      mwperf::testing::c17::reduced_state(targets, {1U, 1U});
  const auto zero = mwperf::ExactRational::zero();
  const auto reject = [&](mwperf::V0EmittedOpportunityFaceV1 face) {
    const mwperf::OpportunityMark opportunity{
        {exact_reduced_state_identity(state), {}}, backlog, std::move(face),
        std::nullopt,
        mwperf::testing::c17::value("c17.fixture.emitted-face", {0x03U}),
        {}};
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(instance);
    REQUIRE(optimizer);
    auto law = mwperf::prepare_reduced_action_law(
        instance, state, opportunity, optimizer.value());
    REQUIRE_FALSE(law);
    return law.error().code;
  };

  SECTION("noncanonical selected schedule") {
    CHECK(reject({{{{targets[1U], targets[0U]}, {}, zero}}}) ==
          "c17.emitted_face_schedule_not_canonical");
  }
  SECTION("duplicate complete schedule") {
    CHECK(reject(mwperf::V0EmittedOpportunityFaceV1{
                     {{{}, {}, zero},
                      {{}, {}, zero},
                      {{targets[0U]}, {}, zero},
                      {{targets[1U]}, {}, zero}}}) ==
          "c17.emitted_face_duplicate_schedule");
  }
  SECTION("missing target side") {
    CHECK(reject(mwperf::V0EmittedOpportunityFaceV1{
                     {{{}, {}, zero}, {{targets[0U]}, {}, zero}}}) ==
          "c17.emitted_face_target_side_missing");
  }
  SECTION("infeasible common schedule") {
    CHECK(reject(mwperf::V0EmittedOpportunityFaceV1{
                     {{{}, {}, zero},
                      {{targets[0U]}, {}, zero},
                      {{targets[1U]}, {}, zero},
                      {{targets[0U], targets[1U]}, {}, zero}}}) ==
          "c17.action_schedule_infeasible");
  }
}

TEST_CASE("C17 composes the exact four-factor law without final renormalization",
          "[c17][integration]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state =
      mwperf::testing::c17::reduced_state(base, {2U});
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {2U});
  const auto trace = std::make_shared<mwperf::testing::c17::SpyTrace>();
  const auto mark_id = base.descriptor.marks.front().id;

  const auto half = mwperf::testing::c17::rational(1, 2);
  const auto accepted_delta = mwperf::testing::c17::rational(1, 2'000'000'000);
  const auto authored_pre_sum = mwperf::ExactRational::one() + accepted_delta;
  const auto pre_second = half + accepted_delta;
  const auto one_third = mwperf::testing::c17::rational(1, 3);
  const auto two_thirds = mwperf::testing::c17::rational(2, 3);
  const auto arrival_half = mwperf::testing::c17::rational(1, 2);
  const auto two_fifths = mwperf::testing::c17::rational(2, 5);
  const auto three_fifths = mwperf::testing::c17::rational(3, 5);

  mwperf::C17GenericCallbackProgramV1 callbacks{
      [trace, prearrival_backlog, half, pre_second](
          const mwperf::PreArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_minus);
        return mwperf::Result<std::vector<mwperf::OpportunityLawAtomV1>>::
            success({{{context.branch(), prearrival_backlog, std::nullopt,
                       std::nullopt,
                       mwperf::testing::c17::value(
                           "c17.fixture.opportunity", {0x10U}),
                       {}},
                      half,
                      true},
                     {{context.branch(), prearrival_backlog, std::nullopt,
                       std::nullopt,
                       mwperf::testing::c17::value(
                           "c17.fixture.opportunity", {0x20U}),
                       {}},
                      pre_second,
                      true}});
      },
      {},
      [trace, base_ptr = &base, one_third, two_thirds](
          const mwperf::ResolverContext& context,
          mwperf::OptimizerExecutionContext&) {
        trace->enter(mwperf::CausalStageV1::resolver);
        const auto& backlog_value =
            *context.opportunity().prearrival_backlog;
        return mwperf::Result<std::vector<mwperf::ActionLawAtomV1>>::success(
            {{mwperf::testing::c17::action(
                  *base_ptr, context.opportunity().branch, backlog_value,
                  {1U, 0U, 0U}, 0x30U),
              one_third, true},
             {mwperf::testing::c17::action(
                  *base_ptr, context.opportunity().branch, backlog_value,
                  {0U, 1U, 0U}, 0x40U),
              two_thirds, true}});
      },
      {},
      [trace, mark_id, two_fifths, three_fifths](
          const mwperf::PostArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_plus);
        return mwperf::Result<
            std::vector<mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0x70U)}},
              two_fifths, true},
             {{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0x80U)}},
              three_fifths, true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 fixture{
      base.instance, base.configured_arrival,
      mwperf::testing::c17::exact_state_schema(base), std::move(program),
      std::move(callbacks),
      std::move(optimizer).value()};
  const auto descriptor = c_plus_mark_descriptor(base.descriptor);

  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      fixture, descriptor, state);
  INFO((row ? std::string{} : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  REQUIRE(row.value().atoms().size() == 16U);
  CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());

  const auto normalized_pre_first =
      mwperf::checked_divide(half, authored_pre_sum);
  const auto normalized_pre_second =
      mwperf::checked_divide(pre_second, authored_pre_sum);
  REQUIRE(normalized_pre_first);
  REQUIRE(normalized_pre_second);
  std::vector<mwperf::ExactRational> expected;
  for (const auto& pre :
       {normalized_pre_first.value(), normalized_pre_second.value()}) {
    for (const auto& action : {one_third, two_thirds}) {
      for (const auto& arrival : {arrival_half, arrival_half}) {
        for (const auto& post : {two_fifths, three_fifths}) {
          expected.push_back(pre * action * arrival * post);
        }
      }
    }
  }
  std::vector<mwperf::ExactRational> actual;
  mwperf::ExactRational cumulative = mwperf::ExactRational::zero();
  for (std::size_t index = 0U; index < row.value().atoms().size(); ++index) {
    const auto& atom = row.value().atoms()[index];
    actual.push_back(atom.exact_mass);
    cumulative = cumulative + atom.exact_mass;
    CHECK(atom.exact_cumulative_mass == cumulative);
    CHECK(atom.numerical_image == atom.exact_mass.to_long_double());
    CHECK(atom.edge.stage_trace() == mwperf::kCausalStageOrderV1);

    auto categorical_mass = mwperf::ExactRational::make(
        row.value().categorical().integral_masses[index].value(),
        row.value().categorical().integral_denominator.value());
    auto categorical_cumulative = mwperf::ExactRational::make(
        row.value().categorical().cumulative_masses[index].value(),
        row.value().categorical().integral_denominator.value());
    REQUIRE(categorical_mass);
    REQUIRE(categorical_cumulative);
    CHECK(categorical_mass.value() == atom.exact_mass);
    CHECK(categorical_cumulative.value() == atom.exact_cumulative_mass);
  }
  std::sort(expected.begin(), expected.end());
  std::sort(actual.begin(), actual.end());
  CHECK(actual == expected);
  CHECK(cumulative == mwperf::ExactRational::one());
  CHECK(row.value().numerical_row_image() ==
        recompute_numerical_row_image(row.value()));
  CHECK(row.value().numerical_row_image().status ==
        mwperf::NumericalProbabilityImageStatusV1::finite);
  CHECK(row.value().numerical_row_image().signed_residual_from_one ==
        row.value().numerical_row_image().compensated_total - 1.0L);

  CHECK(trace->opportunity_applications == 1U);
  CHECK(trace->resolver_applications == 2U);
  CHECK(trace->postclosure_applications == 8U);

  const auto diagnostics = row.value().stage_mass_diagnostics();
  REQUIRE(diagnostics.size() == 15U);
  CHECK(diagnostics.front().stage == mwperf::CausalStageV1::c_minus);
  CHECK(diagnostics.front().raw_sum == authored_pre_sum);
  CHECK(diagnostics.front().signed_delta_from_one == accepted_delta);

  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto q1 = base.instance.queues().index_at(1U).value();
  const auto& binding = mwperf::arrival_law_binding(base.configured_arrival);
  for (const auto& atom : row.value().atoms()) {
    auto projected_q0 =
        mwperf::project_arrival_count(atom.edge.arrival().batch, q0, binding);
    auto projected_q1 =
        mwperf::project_arrival_count(atom.edge.arrival().batch, q1, binding);
    REQUIRE(projected_q0);
    REQUIRE(projected_q1);
    const bool first_joint_atom =
        projected_q0.value() == mwperf::BigNat{1U} &&
        projected_q1.value() == mwperf::BigNat{4U};
    const bool second_joint_atom =
        projected_q0.value() == mwperf::BigNat{3U} &&
        projected_q1.value() == mwperf::BigNat{2U};
    CHECK(first_joint_atom != second_joint_atom);

    auto successor = fixture.exact_state_schema.decode(
        atom.edge.successor_state());
    REQUIRE(successor);
    REQUIRE(successor.value().backlog.size() == 1U);
    CHECK(successor.value().backlog.target_at_target_ordinal(0U).ordinal() ==
          q0.ordinal());
    const mwperf::BigNat departure{
        atom.edge.action().actual_departure.at(q0) ? 1U : 0U};
    auto after_early_service =
        mwperf::checked_subtract(mwperf::BigNat{2U}, departure);
    REQUIRE(after_early_service);
    CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
          after_early_service.value() + projected_q0.value());
  }
}

TEST_CASE("C17 applies early service and late common admission exactly",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state =
      mwperf::testing::c17::reduced_state(base, {0U});
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {0U});
  const auto trace = std::make_shared<mwperf::testing::c17::SpyTrace>();

  mwperf::C17GenericCallbackProgramV1 callbacks{
      [trace, prearrival_backlog](
          const mwperf::PreArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_minus);
        return mwperf::Result<std::vector<mwperf::OpportunityLawAtomV1>>::
            success({{{context.branch(), prearrival_backlog, std::nullopt,
                       std::nullopt,
                       mwperf::testing::c17::value(
                           "c17.fixture.favorable-opportunity", {0x01U}),
                       {}},
                      mwperf::ExactRational::one(),
                      true}});
      },
      {},
      [trace, base_ptr = &base](const mwperf::ResolverContext& context,
                                mwperf::OptimizerExecutionContext&) {
        trace->enter(mwperf::CausalStageV1::resolver);
        return mwperf::Result<std::vector<mwperf::ActionLawAtomV1>>::success(
            {{mwperf::testing::c17::action(
                  *base_ptr, context.opportunity().branch,
                  *context.opportunity().prearrival_backlog,
                  {1U, 0U, 0U}, 0x01U),
              mwperf::ExactRational::one(), true}});
      },
      {},
      [trace](const mwperf::PostArrivalContext& context) {
        trace->enter(mwperf::CausalStageV1::c_plus);
        return mwperf::Result<
            std::vector<mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {}, {}},
              mwperf::ExactRational::one(), true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 fixture{
      base.instance, base.configured_arrival,
      mwperf::testing::c17::exact_state_schema(base), std::move(program),
      std::move(callbacks),
      std::move(optimizer).value()};
  const auto descriptor = unmarked_descriptor(base.descriptor);

  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      fixture, descriptor, state);
  INFO((row ? std::string{} : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  REQUIRE(row.value().atoms().size() == 2U);
  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto& binding = mwperf::arrival_law_binding(base.configured_arrival);
  bool saw_unit_arrival = false;
  for (const auto& atom : row.value().atoms()) {
    const auto& edge = atom.edge;
    CHECK(edge.opportunity().prearrival_backlog
              ->value_at_target_ordinal(0U) ==
          mwperf::BigNat{0U});
    CHECK(edge.action().schedule.at(q0));
    CHECK_FALSE(edge.action().actual_departure.at(q0));
    auto admitted =
        mwperf::project_arrival_count(edge.arrival().batch, q0, binding);
    REQUIRE(admitted);
    auto successor =
        fixture.exact_state_schema.decode(edge.successor_state());
    REQUIRE(successor);
    CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
          admitted.value());
    CHECK(successor.value().boundary_index == mwperf::BigNat{1U});
    CHECK(mwperf::testing::c17::same_phase(
        successor.value().arrival_phase, edge.arrival().phase_after));
    CHECK(edge.stage_trace() == mwperf::kCausalStageOrderV1);
    if (admitted.value() == mwperf::BigNat{1U}) {
      saw_unit_arrival = true;
      CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
            mwperf::BigNat{1U});
    }
  }
  CHECK(saw_unit_arrival);
  CHECK(trace->opportunity_applications == 1U);
  CHECK(trace->resolver_applications == 1U);
  CHECK(trace->postclosure_applications == 2U);
}

TEST_CASE("C17 postarrival marks are exact CPlus-measurable readouts",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {2U});
  const auto backlog = mwperf::testing::c17::target_backlog(base, {2U});
  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto q0_id = base.instance.queues().entries().front().id;
  const mwperf::CausalBranchIdentityV1 branch{
      exact_reduced_state_identity(state), {}};
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, mwperf::ExactRational::zero()},
      {{q0_id}, {}, mwperf::ExactRational::zero()},
  }};
  const mwperf::OpportunityMark opportunity{
      branch, backlog, face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.postarrival-face", {0x01U}),
      {}};

  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  auto action_law = mwperf::prepare_reduced_action_law(
      base.instance, state, opportunity, optimizer.value());
  REQUIRE(action_law);
  const auto action_atoms =
      mwperf::testing::C17FixtureAccess::atoms(action_law.value());
  REQUIRE(action_atoms.size() == 1U);
  const auto action = action_atoms.front().outcome;
  REQUIRE(action.actual_departure.at(q0));

  auto prepared_arrival = mwperf::prepare_configured_arrival_law(
      base.configured_arrival, base.phase_zero);
  REQUIRE(prepared_arrival);
  auto arrival_law =
      mwperf::testing::C17FixtureAccess::apply_arrival_enumeration(
          prepared_arrival.value(),
          mwperf::testing::C17FixtureAccess::arrival_capability(branch),
          mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(arrival_law);
  const auto arrival_atoms =
      mwperf::testing::C17FixtureAccess::atoms(arrival_law.value());
  REQUIRE_FALSE(arrival_atoms.empty());
  const auto arrival = arrival_atoms.front().outcome;

  const auto backlog_mark = mwperf::RuntimeMarkIdV1(
      mwperf::testing::c17::label("c17.mark.successor-backlog"));
  const auto phase_mark = mwperf::RuntimeMarkIdV1(
      mwperf::testing::c17::label("c17.mark.successor-arrival-phase"));
  mwperf::PlugDescriptor descriptor = base.descriptor;
  descriptor.marks = {
      {backlog_mark,
       {mwperf::MetricMarkKindV1::successor_backlog,
        mwperf::MetricRevealStageV1::postarrival,
        {"queue.big_nat", 1U}, ""},
       mwperf::RuntimeDecoderIdV1(
           mwperf::testing::c17::label("c17.decoder.successor-backlog")),
       mwperf::MarkDecoderSourceV1::postarrival_state,
       mwperf::RuntimeDomainKindV1::countable,
       mwperf::testing::c17::kReducedStateCodec, {}, {}},
      {phase_mark,
       {mwperf::MetricMarkKindV1::predictive_phase,
        mwperf::MetricRevealStageV1::postarrival,
        {"arrival.phase", 1U}, ""},
       mwperf::RuntimeDecoderIdV1(
           mwperf::testing::c17::label("c17.decoder.successor-phase")),
       mwperf::MarkDecoderSourceV1::postarrival_state,
       mwperf::RuntimeDomainKindV1::countable,
       mwperf::testing::c17::kReducedStateCodec, {}, {}}};

  auto schema = mwperf::testing::c17::exact_state_schema(base);
  schema.postarrival_mark_decoder = {
      {{descriptor.marks[0U].decoder_id,
        descriptor.marks[0U].id,
        descriptor.marks[0U].decoder_source,
        descriptor.marks[0U].decoder_input_codec,
        descriptor.marks[0U].c14_mark.codec},
       {descriptor.marks[1U].decoder_id,
        descriptor.marks[1U].id,
        descriptor.marks[1U].decoder_source,
        descriptor.marks[1U].decoder_input_codec,
        descriptor.marks[1U].c14_mark.codec}},
      [backlog_mark, phase_mark, q0,
       binding = mwperf::arrival_law_binding(base.configured_arrival)](
          const mwperf::ExactReducedCoordinatesV1& before,
          const mwperf::ExactReducedCoordinatesV1& after,
          const mwperf::ResolvedAction& selected,
          const mwperf::ArrivalTransition& selected_arrival)
      -> mwperf::Result<std::vector<mwperf::RuntimeDecodedMarkV1>> {
    auto after_service = mwperf::checked_subtract(
        before.backlog.value_at_target_ordinal(0U),
        mwperf::BigNat{selected.actual_departure.at(q0) ? 1U : 0U});
    auto admitted = mwperf::project_arrival_count(
        selected_arrival.batch, q0, binding);
    if (!after_service || !admitted) {
      return mwperf::testing::c17::failure<std::vector<
          mwperf::RuntimeDecodedMarkV1>>(
          "c17.fixture.postarrival_formula",
          "the postarrival readout could not evaluate N-D+A");
    }
    const auto& successor =
        after.backlog.value_at_target_ordinal(0U);
    if (successor != after_service.value() + admitted.value() ||
        !mwperf::testing::c17::same_phase(
            after.arrival_phase, selected_arrival.phase_after) ||
        successor.bit_length() > 8U) {
      return mwperf::testing::c17::failure<std::vector<
          mwperf::RuntimeDecodedMarkV1>>(
          "c17.fixture.postarrival_formula",
          "the CPlus readout differs from exact N-D+A or phase_after");
    }
    std::vector<std::byte> phase_bytes(
        mwperf::arrival_phase_canonical_state(after.arrival_phase).begin(),
        mwperf::arrival_phase_canonical_state(after.arrival_phase).end());
    return mwperf::Result<
        std::vector<mwperf::RuntimeDecodedMarkV1>>::success(
        {{backlog_mark,
          {{"queue.big_nat", 1U},
           {static_cast<std::byte>(
               successor.value().convert_to<std::uint8_t>())}}},
         {phase_mark,
          {{"arrival.phase", 1U}, std::move(phase_bytes)}}});
  }};

  auto post_law = mwperf::testing::C17FixtureAccess::postclosure_law(
      {{{branch, {}, {}}, mwperf::ExactRational::one(), true}}, descriptor,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(post_law);
  const auto post_atoms =
      mwperf::testing::C17FixtureAccess::atoms(post_law.value());
  REQUIRE(post_atoms.size() == 1U);
  auto edge = mwperf::apply_exact_reduced_update(
      mwperf::testing::C17FixtureAccess::resolved_state_inputs(
          base.instance, state, opportunity, action, arrival,
          post_atoms.front().outcome, descriptor, schema,
          optimizer.value()));
  INFO((edge ? std::string{}
             : edge.error().code + ": " + edge.error().message));
  REQUIRE(edge);

  auto after_service = mwperf::checked_subtract(
      mwperf::BigNat{2U},
      mwperf::BigNat{action.actual_departure.at(q0) ? 1U : 0U});
  auto admitted = mwperf::project_arrival_count(
      arrival.batch, q0,
      mwperf::arrival_law_binding(base.configured_arrival));
  REQUIRE(after_service);
  REQUIRE(admitted);
  const auto expected_backlog = after_service.value() + admitted.value();
  REQUIRE(expected_backlog.bit_length() <= 8U);
  const auto expected_backlog_byte = static_cast<std::byte>(
      expected_backlog.value().convert_to<std::uint8_t>());
  const auto expected_phase =
      mwperf::arrival_phase_canonical_state(arrival.phase_after);
  const std::vector<std::byte> expected_phase_bytes(expected_phase.begin(),
                                                     expected_phase.end());

  REQUIRE(edge.value().marks().size() == 2U);
  const auto find_mark = [&](const mwperf::RuntimeMarkIdV1& id)
      -> const mwperf::CausalMarkV1& {
    const auto found = std::find_if(
        edge.value().marks().begin(), edge.value().marks().end(),
        [&](const mwperf::CausalMarkV1& mark) {
          return mark.mark.mark == id;
        });
    REQUIRE(found != edge.value().marks().end());
    return *found;
  };
  const auto& backlog_readout = find_mark(backlog_mark);
  CHECK(backlog_readout.reveal_stage == mwperf::CausalStageV1::c_plus);
  CHECK(backlog_readout.mark.value.canonical_value ==
        std::vector<std::byte>{expected_backlog_byte});
  const auto& phase_readout = find_mark(phase_mark);
  CHECK(phase_readout.reveal_stage == mwperf::CausalStageV1::c_plus);
  CHECK(phase_readout.mark.value.canonical_value == expected_phase_bytes);
}

TEST_CASE("C17 generic temporal seal retains entrance marks outside ordinary edges",
          "[c17][integration]") {
  auto fixture =
      mwperf::testing::c17_temporal::make_generic_temporal_framework();
  const auto& report = mwperf::v0_witness_report(fixture.framework);
  REQUIRE(report.passed());
  const auto row_concatenation = std::ranges::find_if(
      report.entries(), [](const mwperf::V0WitnessEntryV1& entry) {
        return entry.obligation ==
               mwperf::V0ObligationV1::row_concatenation;
      });
  const auto mark_observability = std::ranges::find_if(
      report.entries(), [](const mwperf::V0WitnessEntryV1& entry) {
        return entry.obligation ==
               mwperf::V0ObligationV1::requested_mark_observability;
      });
  REQUIRE(row_concatenation != report.entries().end());
  REQUIRE(mark_observability != report.entries().end());
  CHECK(row_concatenation->evidence_scope ==
        mwperf::V0EvidenceScopeV1::declared);
  CHECK(mark_observability->evidence_scope ==
        mwperf::V0EvidenceScopeV1::declared);
  CHECK(fixture.entrance_decoder_calls->load(std::memory_order_relaxed) ==
        0U);
  CHECK(fixture.residence_generator_calls->load(std::memory_order_relaxed) ==
        0U);

  auto romr = mwperf::audited_romr_view(fixture.framework);
  auto temporal = mwperf::audited_temporal_framework(fixture.framework);
  auto enumerable_residence =
      mwperf::audited_residence_provider(fixture.framework);
  REQUIRE(romr);
  REQUIRE(temporal);
  REQUIRE_FALSE(enumerable_residence);
  CHECK(enumerable_residence.error().code ==
        "c17.audited_residence_provider_unavailable");
  auto temporal_romr = mwperf::audited_romr_view(temporal.value());
  auto slot_executor = mwperf::audited_slot_executor(temporal.value());
  REQUIRE(temporal_romr);
  REQUIRE(slot_executor);

  auto bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{0xC1712U});
  REQUIRE(bank);
  auto edge = mwperf::execute_reduced_slot(
      slot_executor.value(), fixture.initial_state, bank.value());
  REQUIRE(edge);
  CHECK(edge.value().stage_trace() == mwperf::kCausalStageOrderV1);
  CHECK(std::ranges::none_of(
      edge.value().marks(), [&](const mwperf::CausalMarkV1& mark) {
        return mark.mark.mark == fixture.entrance_mark;
      }));
  CHECK(fixture.entrance_decoder_calls->load(std::memory_order_relaxed) ==
        0U);
  CHECK(fixture.residence_generator_calls->load(std::memory_order_relaxed) ==
        0U);
}

TEST_CASE("C17 stage failures publish no later stage or partial row",
          "[c17][negative]") {
  enum class FailedStage { c_minus, resolver, arrival, c_plus, psi };
  struct Counts final {
    std::size_t c_minus{0U};
    std::size_t resolver{0U};
    std::size_t c_plus{0U};
  };

  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {1U});
  const auto immutable_state = state;
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {1U});

  const auto exercise = [&](const FailedStage failure,
                            const std::string& expected_code) {
    auto counts = std::make_shared<Counts>();
    mwperf::C17GenericCallbackProgramV1 callbacks{
        [counts, failure, prearrival_backlog](
            const mwperf::PreArrivalContext& context) {
          ++counts->c_minus;
          if (failure == FailedStage::c_minus) {
            return mwperf::testing::c17::failure<
                std::vector<mwperf::OpportunityLawAtomV1>>(
                "c17.fixture.cminus_failure", "injected C-minus failure");
          }
          return mwperf::Result<
              std::vector<mwperf::OpportunityLawAtomV1>>::success(
              {{{context.branch(), prearrival_backlog, std::nullopt,
                 std::nullopt,
                 mwperf::testing::c17::value(
                     "c17.fixture.failure-opportunity", {0x01U}),
                 {}},
                mwperf::ExactRational::one(), true}});
        },
        {},
        [counts, failure, base_ptr = &base](
            const mwperf::ResolverContext& context,
            mwperf::OptimizerExecutionContext& optimizer_context) {
          ++counts->resolver;
          auto reservation = mwperf::begin_search_budget(optimizer_context);
          if (!reservation) {
            return mwperf::Result<
                std::vector<mwperf::ActionLawAtomV1>>::failure(
                reservation.error());
          }
          if (failure == FailedStage::resolver) {
            return mwperf::testing::c17::failure<
                std::vector<mwperf::ActionLawAtomV1>>(
                "c17.fixture.resolver_failure", "injected resolver failure");
          }
          return mwperf::Result<
              std::vector<mwperf::ActionLawAtomV1>>::success(
              {{mwperf::testing::c17::action(
                    *base_ptr, context.opportunity().branch,
                    *context.opportunity().prearrival_backlog,
                    {0U, 0U, 0U}, 0x01U),
                mwperf::ExactRational::one(), true}});
        },
        {},
        [counts, failure](const mwperf::PostArrivalContext& context) {
          ++counts->c_plus;
          if (failure == FailedStage::c_plus) {
            return mwperf::testing::c17::failure<std::vector<
                mwperf::PostClosureCandidateLawAtomV1>>(
                "c17.fixture.cplus_failure", "injected C-plus failure");
          }
          return mwperf::Result<std::vector<
              mwperf::PostClosureCandidateLawAtomV1>>::success(
              {{{context.arrival().branch, {}, {}},
                mwperf::ExactRational::one(), true}});
        },
        {}};

    mwperf::CompiledArrivalLaw configured_arrival = base.configured_arrival;
    if (failure == FailedStage::arrival) {
      auto weighted = mwperf::testing::make_c09_weighted_correlated_fixture_law(
          base.instance.queues(), mwperf::testing::c17::rational(1, 3));
      REQUIRE(weighted);
      configured_arrival = std::move(weighted).value();
    }
    auto schema = mwperf::testing::c17::exact_state_schema(base);
    if (failure == FailedStage::psi) {
      schema.rebuild = [](const mwperf::ExactReducedCoordinatesV1&,
                          const mwperf::UnresolvedPatch&) {
        return mwperf::testing::c17::failure<mwperf::ReducedStateV1>(
            "c17.fixture.psi_failure", "injected Psi failure");
      };
    }
    mwperf::ExactCausalProgramV1 program{
        mwperf::ExactCausalProgramModeV1::generic_bound_operations,
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded(), {}};
    auto optimizer =
        mwperf::OptimizerExecutionContext::from_resolved_instance(
            base.instance);
    REQUIRE(optimizer);
    mwperf::C17GenericComposerFixtureV1 fixture{
        base.instance, std::move(configured_arrival), std::move(schema),
        std::move(program), std::move(callbacks),
        std::move(optimizer).value()};
    const auto ledger_before = fixture.optimizer_context.ledger_snapshot();
    const auto descriptor = unmarked_descriptor(base.descriptor);

    for (std::size_t attempt = 0U; attempt < 2U; ++attempt) {
      auto row = mwperf::testing::C17FixtureAccess::compose_generic(
          fixture, descriptor, state);
      REQUIRE_FALSE(row);
      CHECK(row.error().code == expected_code);
      CHECK(state == immutable_state);
    }
    const auto ledger_after = fixture.optimizer_context.ledger_snapshot();
    CHECK(ledger_after.assigned_max_calls() ==
          ledger_before.assigned_max_calls());
    CHECK(ledger_after.context_active() == ledger_before.context_active());
    CHECK(ledger_after.calls_reserved() ==
          mwperf::BigNat{failure == FailedStage::c_minus ? 0U : 2U});
    CHECK(counts->c_minus == 2U);
    CHECK(counts->resolver ==
          (failure == FailedStage::c_minus ? 0U : 2U));
    CHECK(counts->c_plus ==
          (failure == FailedStage::c_plus || failure == FailedStage::psi
               ? 2U
               : 0U));
  };

  SECTION("C-minus") {
    exercise(FailedStage::c_minus, "c17.fixture.cminus_failure");
  }
  SECTION("resolver") {
    exercise(FailedStage::resolver, "c17.fixture.resolver_failure");
  }
  SECTION("arrival") {
    exercise(FailedStage::arrival,
             "c17.configured_arrival_phase_mismatch");
  }
  SECTION("C-plus") {
    exercise(FailedStage::c_plus, "c17.fixture.cplus_failure");
  }
  SECTION("Psi") {
    exercise(FailedStage::psi, "c17.fixture.psi_failure");
  }
}

TEST_CASE("C17 Psi applies the exact C13 resource and margin recursions",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto backlog = mwperf::testing::c17::target_backlog(base, {1U});
  const auto q0 = base.instance.queues().index_at(0U).value();
  const auto q0_id = base.instance.queues().entries()[0U].id;
  const auto branch_state =
      mwperf::testing::c17::reduced_state(base, {1U});
  const mwperf::CausalBranchIdentityV1 branch{
      exact_reduced_state_identity(branch_state), {}};
  const mwperf::V0EmittedOpportunityFaceV1 face{{
      {{}, {}, mwperf::ExactRational::zero()},
      {{q0_id}, {}, mwperf::ExactRational::zero()},
  }};
  const mwperf::OpportunityMark opportunity{
      branch, backlog, face, std::nullopt,
      mwperf::testing::c17::value("c17.fixture.resource-face", {0x01U}), {}};

  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  auto action_law = mwperf::prepare_reduced_action_law(
      base.instance, branch_state, opportunity, optimizer.value());
  REQUIRE(action_law);
  const auto action_atoms =
      mwperf::testing::C17FixtureAccess::atoms(action_law.value());
  REQUIRE(action_atoms.size() == 1U);
  const auto action = action_atoms.front().outcome;
  REQUIRE(action.actual_departure.at(q0));

  auto prepared_arrival = mwperf::prepare_configured_arrival_law(
      base.configured_arrival, base.phase_zero);
  REQUIRE(prepared_arrival);
  auto arrival_law =
      mwperf::testing::C17FixtureAccess::apply_arrival_enumeration(
          prepared_arrival.value(),
          mwperf::testing::C17FixtureAccess::arrival_capability(branch),
          mwperf::physical_pmf_tolerance(),
          mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(arrival_law);
  const auto arrival_atoms =
      mwperf::testing::C17FixtureAccess::atoms(arrival_law.value());
  REQUIRE_FALSE(arrival_atoms.empty());
  const auto arrival = arrival_atoms.front().outcome;

  auto direction = mwperf::NonnegativeIntegralDirection::from_values(
      mwperf::QueueDimensionToken::from_instance(base.instance),
      {mwperf::BigNat{1U}, mwperf::BigNat{0U}, mwperf::BigNat{0U}});
  REQUIRE(direction);
  auto coordinate = mwperf::ResourceCoordinate::make(
      std::move(direction).value(), mwperf::BigNat{1U},
      mwperf::BigNat{1U}, mwperf::BigNat{0U}, mwperf::BigNat{0U}, true);
  REQUIRE(coordinate);
  auto resources = mwperf::ResourceState::from_coordinates(
      {std::move(coordinate).value()});
  REQUIRE(resources);
  const auto resources_before = resources.value();
  auto resources_after = mwperf::update_resource_coordinates(
      resources_before, action.actual_departure, arrival.batch);
  REQUIRE(resources_after);
  CHECK_FALSE(resources_after.value() == resources_before);

  auto full_backlog = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(base.instance),
      {mwperf::BigNat{1U}, mwperf::BigNat{2U}, mwperf::BigNat{3U}});
  REQUIRE(full_backlog);
  auto target = mwperf::TargetIndex::from_instance(base.instance, 0U);
  REQUIRE(target);
  auto opportunity_optimizer =
      mwperf::OptimizerExecutionContext::from_resolved_instance(
          base.instance);
  REQUIRE(opportunity_optimizer);
  auto exact_opportunity = mwperf::compute_target_opportunity(
      base.instance, full_backlog.value(), target.value(),
      opportunity_optimizer.value());
  REQUIRE(exact_opportunity);
  auto pair = mwperf::SchedulePair::make(
      base.instance, target.value(),
      mwperf::testing::c17::schedule(base.instance, {0U, 1U, 1U}),
      mwperf::testing::c17::schedule(base.instance, {1U, 1U, 1U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      full_backlog.value(), pair.value(), exact_opportunity.value());
  REQUIRE(margin);
  auto full_successor = mwperf::apply_queue_recursion(
      full_backlog.value(), action.schedule, arrival.batch);
  REQUIRE(full_successor);
  const mwperf::ExactMarginEdgeInputs margin_edge(
      full_backlog.value(), action.actual_departure, arrival.batch,
      full_successor.value());
  auto margin_optimizer =
      mwperf::OptimizerExecutionContext::from_resolved_instance(
          base.instance);
  REQUIRE(margin_optimizer);
  auto margin_transition = mwperf::update_margin_from_exact_edge(
      margin.value(), margin_edge, base.instance, margin_optimizer.value());
  REQUIRE(margin_transition);
  const std::vector<mwperf::PairMargin> margins_before{margin.value()};
  const std::vector<mwperf::PairMargin> margins_after{
      margin_transition.value().next()};
  CHECK_FALSE(margins_after == margins_before);

  auto plain_schema = mwperf::testing::c17::exact_state_schema(base);
  auto plain_decode = plain_schema.decode;
  auto plain_rebuild = plain_schema.rebuild;
  auto plain_domain = plain_schema.validate_domain;
  auto state = branch_state;
  state.canonical_value.push_back(std::byte{0U});
  plain_schema.exact_state_schema_digest =
      mwperf::testing::c17::digest("c17.fixture.resource-exact-schema");
  plain_schema.reduced_state_schema_digest =
      mwperf::testing::c17::digest("c17.fixture.resource-state-schema");
  plain_schema.exact_update_schema_digest =
      mwperf::testing::c17::digest("c17.fixture.resource-margin-update");
  plain_schema.decode =
      [plain_decode, resources_before, margins_before, margins_after,
       expected = resources_after.value()](const mwperf::ReducedStateV1& value)
      -> mwperf::Result<mwperf::ExactReducedCoordinatesV1> {
    if (value.canonical_value.size() != 4U) {
      return mwperf::testing::c17::failure<
          mwperf::ExactReducedCoordinatesV1>(
          "c17.fixture.resource_state_shape",
          "resource fixture state must contain one selector");
    }
    const auto selector =
        std::to_integer<std::uint8_t>(value.canonical_value.back());
    if (selector > 1U) {
      return mwperf::testing::c17::failure<
          mwperf::ExactReducedCoordinatesV1>(
          "c17.fixture.resource_state_selector",
          "resource fixture selector must be before or after");
    }
    mwperf::ReducedStateV1 projected = value;
    projected.canonical_value.pop_back();
    auto decoded = plain_decode(projected);
    if (!decoded) {
      return mwperf::Result<mwperf::ExactReducedCoordinatesV1>::failure(
          decoded.error());
    }
    decoded.value().resources = selector == 0U ? resources_before : expected;
    decoded.value().margins =
        selector == 0U ? margins_before : margins_after;
    return decoded;
  };
  plain_schema.rebuild =
      [plain_rebuild, resources_before, margins_before, margins_after,
       expected = resources_after.value()](
          const mwperf::ExactReducedCoordinatesV1& coordinates,
          const mwperf::UnresolvedPatch& unresolved)
      -> mwperf::Result<mwperf::ReducedStateV1> {
    if (!coordinates.resources.has_value()) {
      return mwperf::testing::c17::failure<mwperf::ReducedStateV1>(
          "c17.fixture.resource_missing",
          "resource fixture rebuild requires its exact coordinate");
    }
    std::uint8_t selector = 0U;
    if (*coordinates.resources == expected &&
        coordinates.margins == margins_after) {
      selector = 1U;
    } else if (!(*coordinates.resources == resources_before &&
                 coordinates.margins == margins_before)) {
      return mwperf::testing::c17::failure<mwperf::ReducedStateV1>(
          "c17.fixture.resource_value",
          "resource/margin rebuild received neither exact endpoint");
    }
    auto projected = coordinates;
    projected.resources.reset();
    projected.margins.clear();
    auto rebuilt = plain_rebuild(projected, unresolved);
    if (!rebuilt) {
      return rebuilt;
    }
    rebuilt.value().canonical_value.push_back(
        static_cast<std::byte>(selector));
    return rebuilt;
  };
  plain_schema.validate_domain =
      [plain_domain](const mwperf::ReducedStateV1& value) {
    if (value.canonical_value.size() != 4U ||
        std::to_integer<std::uint8_t>(value.canonical_value.back()) > 1U) {
      return mwperf::testing::c17::failure<void>(
          "c17.fixture.resource_domain",
          "resource fixture state lies outside its two exact endpoints");
    }
    mwperf::ReducedStateV1 projected = value;
    projected.canonical_value.pop_back();
    return plain_domain(projected);
  };

  const auto descriptor = unmarked_descriptor(base.descriptor);
  auto post_law = mwperf::testing::C17FixtureAccess::postclosure_law(
      {{{branch, {}, {}}, mwperf::ExactRational::one(), true}},
      descriptor, mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded());
  REQUIRE(post_law);
  const auto post_atoms =
      mwperf::testing::C17FixtureAccess::atoms(post_law.value());
  REQUIRE(post_atoms.size() == 1U);
  auto edge = mwperf::apply_exact_reduced_update(
      mwperf::testing::C17FixtureAccess::resolved_state_inputs(
          base.instance, state, opportunity, action, arrival,
          post_atoms.front().outcome, descriptor, plain_schema,
          optimizer.value()));
  INFO((edge ? std::string{}
             : edge.error().code + ": " + edge.error().message));
  REQUIRE(edge);
  auto successor = plain_schema.decode(edge.value().successor_state());
  REQUIRE(successor);
  REQUIRE(successor.value().resources.has_value());
  CHECK(*successor.value().resources == resources_after.value());
  CHECK(successor.value().margins == margins_after);
  auto after_service =
      mwperf::checked_subtract(mwperf::BigNat{1U}, mwperf::BigNat{1U});
  auto admitted = mwperf::project_arrival_count(
      arrival.batch, q0,
      mwperf::arrival_law_binding(base.configured_arrival));
  REQUIRE(after_service);
  REQUIRE(admitted);
  CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
        after_service.value() + admitted.value());
}

TEST_CASE("C17 merges only identical complete marked edge outcomes",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state =
      mwperf::testing::c17::reduced_state(base, {2U});
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {2U});
  const auto half = mwperf::testing::c17::rational(1, 2);
  const auto mark_id = base.descriptor.marks.front().id;

  mwperf::C17GenericCallbackProgramV1 callbacks{
      [prearrival_backlog, half](const mwperf::PreArrivalContext& context) {
        const mwperf::OpportunityMark identical{
            context.branch(), prearrival_backlog, std::nullopt,
            std::nullopt,
            mwperf::testing::c17::value("c17.fixture.merge-opportunity",
                                        {0x01U}),
            {}};
        return mwperf::Result<
            std::vector<mwperf::OpportunityLawAtomV1>>::success(
            {{identical, half, true}, {identical, half, true}});
      },
      {},
      [base_ptr = &base](const mwperf::ResolverContext& context,
                         mwperf::OptimizerExecutionContext&) {
        return mwperf::Result<
            std::vector<mwperf::ActionLawAtomV1>>::success(
            {{mwperf::testing::c17::action(
                  *base_ptr, context.opportunity().branch,
                  *context.opportunity().prearrival_backlog,
                  {1U, 0U, 0U}, 0x02U),
              mwperf::ExactRational::one(), true}});
      },
      {},
      [half, mark_id](const mwperf::PostArrivalContext& context) {
        return mwperf::Result<
            std::vector<mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0x70U)}},
              half, true},
             {{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0x80U)}},
              half, true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 fixture{
      base.instance, base.configured_arrival,
      mwperf::testing::c17::exact_state_schema(base), std::move(program),
      std::move(callbacks),
      std::move(optimizer).value()};
  const auto descriptor = c_plus_mark_descriptor(base.descriptor);

  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      fixture, descriptor, state);
  INFO((row ? std::string{} : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  REQUIRE(row.value().atoms().size() == 4U);
  for (const auto& atom : row.value().atoms()) {
    CHECK(atom.exact_mass == mwperf::testing::c17::rational(1, 4));
  }

  std::size_t low_mark_count = 0U;
  std::size_t high_mark_count = 0U;
  for (const auto& atom : row.value().atoms()) {
    REQUIRE(atom.edge.postclosure().marks.size() == 1U);
    const auto byte = atom.edge.postclosure()
                          .marks.front()
                          .value.canonical_value.front();
    low_mark_count += byte == std::byte{0x70U} ? 1U : 0U;
    high_mark_count += byte == std::byte{0x80U} ? 1U : 0U;
  }
  CHECK(low_mark_count == 2U);
  CHECK(high_mark_count == 2U);
}

TEST_CASE("C17 retains positive underflow atoms in the exact categorical row",
          "[c17][property]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {1U});
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {1U});
  mwperf::BigInt denominator{1};
  for (std::size_t exponent = 0U; exponent < 6000U; ++exponent) {
    denominator *= 10;
  }
  auto epsilon_result =
      mwperf::ExactRational::make(mwperf::BigInt{1}, denominator);
  REQUIRE(epsilon_result);
  const auto epsilon = std::move(epsilon_result).value();
  const auto arrival_remainder = mwperf::ExactRational::one() - epsilon;
  auto weighted_arrival =
      mwperf::testing::make_c09_weighted_correlated_fixture_law(
          base.instance.queues(), epsilon);
  REQUIRE(weighted_arrival);
  const auto configured_arrival = std::move(weighted_arrival).value();

  auto instance_key = mwperf::make_physical_reference_instance_key(
      base.instance.fingerprints().combined, mwperf::BigNat{0U});
  REQUIRE(instance_key);
  const auto phase = [&](std::string shared_state,
                         const std::uint64_t seed) {
    auto stream = mwperf::make_configured_arrival_stream_key(
        configured_arrival,
        mwperf::derive_rng_stream(
            mwperf::MasterSeed{seed}, mwperf::StageTag::configured_arrival,
            instance_key.value()));
    REQUIRE(stream);
    auto process = mwperf::instantiate_arrival_process(
        configured_arrival,
        mwperf::ArrivalInitialState{
            mwperf::SharedRoundState{std::move(shared_state)}},
        std::move(stream).value());
    REQUIRE(process);
    auto first = mwperf::next_arrival_step(process.value(),
                                           mwperf::BigNat{0U});
    REQUIRE(first);
    return first.value().phase_before;
  };
  const auto phase_zero = phase("h0", 0xC1711U);
  const auto phase_one = phase("h1", 0xC1712U);
  auto state_schema = mwperf::testing::c17::exact_state_schema(
      base.instance, base.descriptor.core.deployed_targets,
      phase_zero, phase_one);

  auto binary64_mass = mwperf::ProbabilityMass::canonical_binary64_bits(
      UINT64_C(0x0000000000000001), true);
  REQUIRE(binary64_mass);
  CHECK(binary64_mass.value().kind() ==
        mwperf::ProbabilityMassKindV1::canonical_binary64_bits);
  const auto dyadic = binary64_mass.value().exact_value();
  auto exact_complement = mwperf::ProbabilityMass::exact_rational(
      mwperf::ExactRational::one() - dyadic, true);
  REQUIRE(exact_complement);
  const auto closure_remainder = exact_complement.value().exact_value();
  const auto mark_id = base.descriptor.marks.front().id;

  mwperf::C17GenericCallbackProgramV1 callbacks{
      [prearrival_backlog](const mwperf::PreArrivalContext& context) {
        return mwperf::Result<
            std::vector<mwperf::OpportunityLawAtomV1>>::success(
            {{{context.branch(), prearrival_backlog, std::nullopt,
               std::nullopt,
               mwperf::testing::c17::value(
                   "c17.fixture.underflow", {0x01U}), {}},
              mwperf::ExactRational::one(), true}});
      },
      {},
      [base_ptr = &base](const mwperf::ResolverContext& context,
                         mwperf::OptimizerExecutionContext&) {
        return mwperf::Result<
            std::vector<mwperf::ActionLawAtomV1>>::success(
            {{mwperf::testing::c17::action(
                  *base_ptr, context.opportunity().branch,
                  *context.opportunity().prearrival_backlog,
                  {0U, 0U, 0U}, 0x01U),
              mwperf::ExactRational::one(), true}});
      },
      {},
      [dyadic, closure_remainder, mark_id](
          const mwperf::PostArrivalContext& context) {
        return mwperf::Result<std::vector<
            mwperf::PostClosureCandidateLawAtomV1>>::success(
            {{{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0xA1U)}},
              dyadic, true},
             {{context.arrival().branch, {},
               {mwperf::testing::c17::mark(mark_id, 0xA2U)}},
              closure_remainder, true}});
      },
      {}};
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 fixture{
      base.instance, configured_arrival, std::move(state_schema),
      std::move(program),
      std::move(callbacks), std::move(optimizer).value()};
  const auto descriptor = c_plus_mark_descriptor(base.descriptor);
  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      fixture, descriptor, state);
  INFO((row ? std::string{} : row.error().code + ": " + row.error().message));
  REQUIRE(row);
  REQUIRE(row.value().atoms().size() == 4U);
  CHECK(row.value().exact_total_mass() == mwperf::ExactRational::one());

  std::vector<mwperf::ExactRational> expected{
      epsilon * dyadic, epsilon * closure_remainder,
      arrival_remainder * dyadic,
      arrival_remainder * closure_remainder};
  std::vector<mwperf::ExactRational> actual;
  std::size_t underflow_count = 0U;
  bool tiny_cross_product_selectable = false;
  for (std::size_t index = 0U; index < row.value().atoms().size(); ++index) {
    const auto& atom = row.value().atoms()[index];
    actual.push_back(atom.exact_mass);
    if (atom.numerical_image_status ==
        mwperf::NumericalProbabilityImageStatusV1::positive_underflow) {
      ++underflow_count;
      CHECK(atom.exact_mass.is_positive());
      CHECK(atom.numerical_image == 0.0L);
      CHECK(row.value().categorical().integral_masses[index] >
            mwperf::BigNat{0U});
    }
    if (atom.exact_mass == epsilon * dyadic) {
      tiny_cross_product_selectable = true;
      CHECK(atom.structural_support);
      CHECK(atom.numerical_image_status ==
            mwperf::NumericalProbabilityImageStatusV1::positive_underflow);
      auto categorical_mass = mwperf::ExactRational::make(
          row.value().categorical().integral_masses[index].value(),
          row.value().categorical().integral_denominator.value());
      REQUIRE(categorical_mass);
      CHECK(categorical_mass.value() == atom.exact_mass);
    }
  }
  std::sort(expected.begin(), expected.end());
  std::sort(actual.begin(), actual.end());
  CHECK(actual == expected);
  CHECK(underflow_count == 2U);
  CHECK(tiny_cross_product_selectable);
  CHECK(row.value().categorical().cumulative_masses.back() ==
        row.value().categorical().integral_denominator);
  const auto arrival_diagnostic = std::ranges::find_if(
      row.value().stage_mass_diagnostics(),
      [](const mwperf::StageMassDiagnosticV1& diagnostic) {
        return diagnostic.stage == mwperf::CausalStageV1::arrival;
      });
  REQUIRE(arrival_diagnostic != row.value().stage_mass_diagnostics().end());
  REQUIRE(arrival_diagnostic->raw_masses.size() == 2U);
  CHECK(arrival_diagnostic->raw_masses[0U] == epsilon);
  CHECK(arrival_diagnostic->raw_masses[1U] == arrival_remainder);
  CHECK(arrival_diagnostic->raw_sum == mwperf::ExactRational::one());
  CHECK(row.value().numerical_row_image() ==
        recompute_numerical_row_image(row.value()));
  CHECK(row.value().numerical_row_image().status ==
        mwperf::NumericalProbabilityImageStatusV1::positive_underflow);
  CHECK(row.value().numerical_row_image().signed_residual_from_one ==
        row.value().numerical_row_image().compensated_total - 1.0L);
}

TEST_CASE("C17 rejects an over-budget partial product before duplicate merge",
          "[c17][negative]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto state = mwperf::testing::c17::reduced_state(base, {1U});
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {1U});
  const auto half = mwperf::testing::c17::rational(1, 2);

  const auto make_fixture = [&](const mwperf::PmfRepresentationBudget budget) {
    mwperf::C17GenericCallbackProgramV1 callbacks{
        [prearrival_backlog, half](
            const mwperf::PreArrivalContext& context) {
          const mwperf::OpportunityMark outcome{
              context.branch(), prearrival_backlog, std::nullopt,
              std::nullopt,
              mwperf::testing::c17::value(
                  "c17.fixture.budget-opportunity", {0x01U}),
              {}};
          return mwperf::Result<
              std::vector<mwperf::OpportunityLawAtomV1>>::success(
              {{outcome, half, true}, {outcome, half, true}});
        },
        {},
        [base_ptr = &base, half](const mwperf::ResolverContext& context,
                                 mwperf::OptimizerExecutionContext&) {
          const auto outcome = mwperf::testing::c17::action(
              *base_ptr, context.opportunity().branch,
              *context.opportunity().prearrival_backlog,
              {0U, 0U, 0U}, 0x01U);
          return mwperf::Result<
              std::vector<mwperf::ActionLawAtomV1>>::success(
              {{outcome, half, true}, {outcome, half, true}});
        },
        {},
        [half](const mwperf::PostArrivalContext& context) {
          const mwperf::PostClosureCandidateV1 outcome{
              context.arrival().branch, {}, {}};
          return mwperf::Result<std::vector<
              mwperf::PostClosureCandidateLawAtomV1>>::success(
              {{outcome, half, true}, {outcome, half, true}});
        },
        {}};
    mwperf::ExactCausalProgramV1 program{
        mwperf::ExactCausalProgramModeV1::generic_bound_operations,
        mwperf::physical_pmf_tolerance(), budget, {}};
    auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
        base.instance);
    REQUIRE(optimizer);
    return mwperf::C17GenericComposerFixtureV1{
        base.instance, base.configured_arrival,
        mwperf::testing::c17::exact_state_schema(base), std::move(program),
        std::move(callbacks), std::move(optimizer).value()};
  };

  auto unbounded = make_fixture(mwperf::PmfRepresentationBudget::unbounded());
  const auto descriptor = unmarked_descriptor(base.descriptor);
  auto merged = mwperf::testing::C17FixtureAccess::compose_generic(
      unbounded, descriptor, state);
  REQUIRE(merged);
  REQUIRE(merged.value().atoms().size() == 2U);
  CHECK(merged.value().atoms()[0U].exact_mass == half);
  CHECK(merged.value().atoms()[1U].exact_mass == half);

  auto bounded = make_fixture(mwperf::PmfRepresentationBudget{3U});
  auto rejected = mwperf::testing::C17FixtureAccess::compose_generic(
      bounded, descriptor, state);
  REQUIRE_FALSE(rejected);
  CHECK(rejected.error().code == "c17.branch_mass_budget_exhausted");
}

TEST_CASE("C17 closed three-bin law and unit residence are exact",
          "[c17][integration]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  const auto& report = mwperf::v0_witness_report(fixture.framework);
  REQUIRE(report.passed());
  REQUIRE(report.entries().size() == 11U);
  const auto unit_entry = std::find_if(
      report.entries().begin(), report.entries().end(),
      [](const mwperf::V0WitnessEntryV1& entry) {
        return entry.obligation ==
               mwperf::V0ObligationV1::framework_unit_residence;
      });
  REQUIRE(unit_entry != report.entries().end());
  CHECK(unit_entry->evidence_scope ==
        mwperf::V0EvidenceScopeV1::construction_enforced);
  const auto observability_entry = std::find_if(
      report.entries().begin(), report.entries().end(),
      [](const mwperf::V0WitnessEntryV1& entry) {
        return entry.obligation ==
               mwperf::V0ObligationV1::requested_mark_observability;
      });
  REQUIRE(observability_entry != report.entries().end());
  CHECK(observability_entry->passed);
  CHECK(observability_entry->evidence_scope ==
        mwperf::V0EvidenceScopeV1::reachable_enumerated);

  REQUIRE(fixture.descriptor.marks.size() == 1U);
  const auto& departure_descriptor = fixture.descriptor.marks.front();
  CHECK(departure_descriptor.c14_mark.kind ==
        mwperf::MetricMarkKindV1::actual_departure);
  CHECK(departure_descriptor.c14_mark.reveal_stage ==
        mwperf::MetricRevealStageV1::completed_edge);
  CHECK(departure_descriptor.decoder_source ==
        mwperf::MarkDecoderSourceV1::decision_schedule);
  CHECK(departure_descriptor.decoder_input_codec ==
        mwperf::CodecIdentityV1{"schedule.realization", 1U});
  CHECK(departure_descriptor.c14_mark.codec ==
        mwperf::CodecIdentityV1{"service.bit", 1U});

  auto response = mwperf::audited_three_bin_response(fixture.framework);
  REQUIRE(response);
  auto analytic_response = mwperf::audited_response_law(fixture.framework);
  REQUIRE_FALSE(analytic_response);
  CHECK(analytic_response.error().code ==
        "c17.audited_response_law_unavailable");
  const std::array expected{
      std::pair{std::uint64_t{0U}, mwperf::ExactRational::zero()},
      std::pair{std::uint64_t{1U},
                mwperf::testing::c17::rational(3, 4)},
      std::pair{std::uint64_t{2U},
                mwperf::testing::c17::rational(1, 4)},
      std::pair{std::uint64_t{3U},
                mwperf::testing::c17::rational(2, 3)},
      std::pair{std::uint64_t{10U},
                mwperf::testing::c17::rational(2, 3)}};
  for (const auto& [backlog_value, expected_probability] : expected) {
    auto probability = response.value().service_probability(
        mwperf::BigNat{backlog_value});
    REQUIRE(probability);
    CHECK(probability.value() == expected_probability);
  }

  auto row_provider = mwperf::audited_row_provider(fixture.framework);
  auto slot_executor = mwperf::audited_slot_executor(fixture.framework);
  auto residence_provider =
      mwperf::audited_residence_provider(fixture.framework);
  auto temporal_framework =
      mwperf::audited_temporal_framework(fixture.framework);
  REQUIRE(row_provider);
  REQUIRE(slot_executor);
  REQUIRE(residence_provider);
  REQUIRE(temporal_framework);
  auto residence_row_provider =
      mwperf::audited_row_provider(residence_provider.value());
  auto residence_slot_executor =
      mwperf::audited_slot_executor(temporal_framework.value());
  auto residence = mwperf::audited_romr_view(residence_provider.value());
  REQUIRE(residence_row_provider);
  REQUIRE(residence_slot_executor);
  REQUIRE(residence);

  const auto empty =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {0U});
  auto empty_row = mwperf::compile_reduced_kernel_row(
      row_provider.value(), empty);
  REQUIRE(empty_row);
  REQUIRE(empty_row.value().atoms().size() == 1U);
  const auto q0 = fixture.instance.queues().index_at(0U).value();
  const auto check_departure_mark =
      [&](const mwperf::CompletedReducedEdge& edge) {
        REQUIRE(edge.action().marks.size() == 1U);
        const auto& action_mark = edge.action().marks.front();
        CHECK(action_mark.mark == departure_descriptor.id);
        CHECK(action_mark.value.codec == departure_descriptor.c14_mark.codec);
        REQUIRE(action_mark.value.canonical_value.size() == 1U);
        CHECK(std::to_integer<std::uint8_t>(
                  action_mark.value.canonical_value.front()) ==
              (edge.action().actual_departure.at(q0) ? 1U : 0U));
        REQUIRE(edge.marks().size() == 1U);
        CHECK(edge.marks().front().mark == action_mark);
        CHECK(edge.marks().front().reveal_stage ==
              mwperf::CausalStageV1::resolver);
      };
  for (const auto& atom : empty_row.value().atoms()) {
    CHECK_FALSE(atom.edge.action().schedule.at(q0));
    CHECK_FALSE(atom.edge.action().actual_departure.at(q0));
    check_departure_mark(atom.edge);
  }

  const auto entrance =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto residence_row = mwperf::compile_reduced_kernel_row(
      residence_row_provider.value(), entrance);
  REQUIRE(residence_row);
  REQUIRE(residence_row.value().atoms().size() == 2U);

  const auto one_fourth = mwperf::testing::c17::rational(1, 4);
  const auto three_fourths = mwperf::testing::c17::rational(3, 4);
  const auto phase_one_entrance = mwperf::testing::c17::reduced_state(
      fixture.ordered_targets, {2U}, true, 1U);
  auto phase_one_row = mwperf::compile_reduced_kernel_row(
      residence_row_provider.value(), phase_one_entrance);
  REQUIRE(phase_one_row);
  REQUIRE(phase_one_row.value().atoms().size() == 2U);
  const auto phase_zero_coordinates = fixture.state_schema.decode(entrance);
  const auto phase_one_coordinates =
      fixture.state_schema.decode(phase_one_entrance);
  REQUIRE(phase_zero_coordinates);
  REQUIRE(phase_one_coordinates);
  REQUIRE_FALSE(mwperf::testing::c17::same_phase(
      phase_zero_coordinates.value().arrival_phase,
      phase_one_coordinates.value().arrival_phase));

  const auto departure_mass =
      [q0](const mwperf::MarkedKernelRow& row) {
        mwperf::ExactRational mass = mwperf::ExactRational::zero();
        for (const auto& atom : row.atoms()) {
          if (atom.edge.action().actual_departure.at(q0)) {
            mass = mass + atom.exact_mass;
          }
        }
        return mass;
      };
  CHECK(departure_mass(residence_row.value()) == one_fourth);
  CHECK(departure_mass(phase_one_row.value()) == one_fourth);

  const auto check_phase_row =
      [&](const mwperf::MarkedKernelRow& row,
          const mwperf::ExactReducedCoordinatesV1& before,
          const mwperf::ExactReducedCoordinatesV1& expected_phase,
          const mwperf::BigNat& expected_target_arrival) {
        for (const auto& atom : row.atoms()) {
          REQUIRE(atom.edge.arrival().batch.binding().has_value());
          auto admitted = mwperf::project_arrival_count(
              atom.edge.arrival().batch, q0,
              *atom.edge.arrival().batch.binding());
          REQUIRE(admitted);
          CHECK(admitted.value() == expected_target_arrival);
          CHECK(mwperf::testing::c17::same_phase(
              atom.edge.arrival().phase_before, before.arrival_phase));
          CHECK(mwperf::testing::c17::same_phase(
              atom.edge.arrival().phase_after,
              expected_phase.arrival_phase));
          auto successor = fixture.state_schema.decode(
              atom.edge.successor_state());
          REQUIRE(successor);
          CHECK(successor.value().boundary_index ==
                before.boundary_index + mwperf::BigNat{1U});
          CHECK(mwperf::testing::c17::same_phase(
              successor.value().arrival_phase,
              atom.edge.arrival().phase_after));
          auto after_service = mwperf::checked_subtract(
              before.backlog.value_at_target_ordinal(0U),
              mwperf::BigNat{
                  atom.edge.action().actual_departure.at(q0) ? 1U : 0U});
          REQUIRE(after_service);
          CHECK(successor.value().backlog.value_at_target_ordinal(0U) ==
                after_service.value() + admitted.value());
        }
      };
  const auto phase_two_state = mwperf::testing::c17::reduced_state(
      fixture.ordered_targets, {2U}, false, 2U);
  const auto phase_two_coordinates =
      fixture.state_schema.decode(phase_two_state);
  REQUIRE(phase_two_coordinates);
  CHECK(mwperf::testing::c17::same_phase(
      phase_zero_coordinates.value().arrival_phase,
      phase_two_coordinates.value().arrival_phase));
  check_phase_row(residence_row.value(), phase_zero_coordinates.value(),
                  phase_one_coordinates.value(), mwperf::BigNat{1U});
  check_phase_row(phase_one_row.value(), phase_one_coordinates.value(),
                  phase_two_coordinates.value(), mwperf::BigNat{0U});

  std::size_t selected_count = 0U;
  for (const auto& atom : residence_row.value().atoms()) {
    CHECK(atom.edge.stage_trace() == mwperf::kCausalStageOrderV1);
    check_departure_mark(atom.edge);
    if (atom.edge.action().schedule.at(q0)) {
      ++selected_count;
      CHECK(atom.exact_mass == one_fourth);
    } else {
      CHECK(atom.exact_mass == three_fourths);
    }
    auto successor = fixture.state_schema.decode(
        atom.edge.successor_state());
    REQUIRE(successor);
    CHECK(mwperf::testing::c17::same_phase(
        successor.value().arrival_phase,
        atom.edge.arrival().phase_after));
  }
  CHECK(selected_count == 1U);

  auto residence_bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{0xC1708U});
  REQUIRE(residence_bank);
  auto residence_edge = mwperf::execute_reduced_slot(
      residence_slot_executor.value(), entrance, residence_bank.value());
  REQUIRE(residence_edge);
  CHECK(residence_edge.value().stage_trace() == mwperf::kCausalStageOrderV1);
  check_departure_mark(residence_edge.value());
  auto realized_successor = fixture.state_schema.decode(
      residence_edge.value().successor_state());
  REQUIRE(realized_successor);
  CHECK(realized_successor.value().boundary_index == mwperf::BigNat{1U});
  CHECK(mwperf::testing::c17::same_phase(
      realized_successor.value().arrival_phase,
      residence_edge.value().arrival().phase_after));
  CHECK(std::count_if(
            residence_row.value().atoms().begin(),
            residence_row.value().atoms().end(),
            [&](const mwperf::MarkedKernelRowAtomV1& atom) {
              return atom.edge == residence_edge.value();
            }) == 1);

  auto second_residence_row = mwperf::compile_reduced_kernel_row(
      residence_row_provider.value(), residence_edge.value().successor_state());
  REQUIRE(second_residence_row);
  check_phase_row(second_residence_row.value(),
                  realized_successor.value(),
                  phase_two_coordinates.value(), mwperf::BigNat{0U});
  auto second_residence_edge = mwperf::execute_reduced_slot(
      residence_slot_executor.value(),
      residence_edge.value().successor_state(), residence_bank.value());
  REQUIRE(second_residence_edge);
  auto second_successor = fixture.state_schema.decode(
      second_residence_edge.value().successor_state());
  REQUIRE(second_successor);
  CHECK(second_successor.value().boundary_index == mwperf::BigNat{2U});
  CHECK(mwperf::testing::c17::same_phase(
      residence_edge.value().arrival().phase_after,
      second_residence_edge.value().arrival().phase_before));
  CHECK(mwperf::testing::c17::same_phase(
      second_residence_edge.value().arrival().phase_after,
      phase_zero_coordinates.value().arrival_phase));
  CHECK(std::count_if(
            second_residence_row.value().atoms().begin(),
            second_residence_row.value().atoms().end(),
            [&](const mwperf::MarkedKernelRowAtomV1& atom) {
              return atom.edge == second_residence_edge.value();
            }) == 1);
}

TEST_CASE(
    "C17 closed finite-prefix constant-tail lookup is exact at every boundary",
    "[c17][integration]") {
  const std::vector<mwperf::ExactRational> prefix{
      mwperf::ExactRational::zero(),
      mwperf::testing::c17::rational(1, 8),
      mwperf::ExactRational::zero(),
      mwperf::testing::c17::rational(3, 8),
      mwperf::testing::c17::rational(1, 2),
      mwperf::testing::c17::rational(7, 8)};
  const auto tail = mwperf::testing::c17::rational(2, 3);
  auto fixture =
      mwperf::testing::c17::make_finite_prefix_constant_tail_framework(
          prefix, tail);
  REQUIRE(mwperf::v0_witness_report(fixture.framework).passed());

  auto response =
      mwperf::audited_finite_prefix_constant_tail_response(
          fixture.framework);
  REQUIRE(response);
  auto legacy = mwperf::audited_three_bin_response(fixture.framework);
  REQUIRE_FALSE(legacy);
  CHECK(legacy.error().code == "c17.audited_three_bin_unavailable");

  for (std::size_t level = 0U; level < prefix.size(); ++level) {
    auto probability = response.value().service_probability(
        mwperf::BigNat{static_cast<std::uint64_t>(level)});
    INFO("level=" << level);
    REQUIRE(probability);
    CHECK(probability.value() == prefix[level]);
  }

  // K=5 is the final exact level.  The first and every later tail level use
  // the one native constant-tail coefficient, without a K=2 compatibility
  // fold.
  for (const std::uint64_t level : {6U, 7U, 19U}) {
    auto probability =
        response.value().service_probability(mwperf::BigNat{level});
    INFO("tail level=" << level);
    REQUIRE(probability);
    CHECK(probability.value() == tail);
  }
}

TEST_CASE("C17 closed unit residence rejects hidden unresolved state",
          "[c17][negative]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework(true);
  auto row_provider = mwperf::audited_row_provider(fixture.framework);
  auto slot_executor = mwperf::audited_slot_executor(fixture.framework);
  REQUIRE(row_provider);
  REQUIRE(slot_executor);
  const auto hidden_state = mwperf::testing::c17::reduced_state(
      fixture.ordered_targets, {2U}, false,
      mwperf::testing::c17::kHiddenUnitStateFlagV1);

  auto row = mwperf::compile_reduced_kernel_row(row_provider.value(),
                                                hidden_state);
  REQUIRE_FALSE(row);
  CHECK(row.error().code == "c17.unit_residence_extra_state");

  auto bank = mwperf::RngBank::for_physical_reference(
      fixture.instance, mwperf::MasterSeed{0xC1709U});
  REQUIRE(bank);
  auto edge = mwperf::execute_reduced_slot(
      slot_executor.value(), hidden_state, bank.value());
  REQUIRE_FALSE(edge);
  CHECK(edge.error().code == "c17.unit_residence_extra_state");
}

TEST_CASE("C17 repeated exact row compilation has no drift",
          "[c17][property]") {
  auto fixture =
      mwperf::testing::c17::make_nonmonotone_three_bin_framework();
  auto provider = mwperf::audited_row_provider(fixture.framework);
  REQUIRE(provider);
  const auto state =
      mwperf::testing::c17::reduced_state(fixture.ordered_targets, {2U});
  auto first = mwperf::compile_reduced_kernel_row(provider.value(), state);
  auto second = mwperf::compile_reduced_kernel_row(provider.value(), state);
  REQUIRE(first);
  REQUIRE(second);
  check_same_row(first.value(), second.value());
}

TEST_CASE("C17 exact row compilation rejects a missing stage enumerator",
          "[c17][negative]") {
  const auto& base = mwperf::testing::c17::math_base();
  mwperf::ExactCausalProgramV1 program{
      mwperf::ExactCausalProgramModeV1::generic_bound_operations,
      mwperf::physical_pmf_tolerance(),
      mwperf::PmfRepresentationBudget::unbounded(), {}};
  mwperf::C17GenericCallbackProgramV1 callbacks{{}, {}, {}, {}, {}, {}};
  auto optimizer = mwperf::OptimizerExecutionContext::from_resolved_instance(
      base.instance);
  REQUIRE(optimizer);
  mwperf::C17GenericComposerFixtureV1 fixture{
      base.instance, base.configured_arrival,
      mwperf::testing::c17::exact_state_schema(base), std::move(program),
      std::move(callbacks),
      std::move(optimizer).value()};
  auto row = mwperf::testing::C17FixtureAccess::compose_generic(
      fixture, base.descriptor,
      mwperf::testing::c17::reduced_state(base, {1U}));
  REQUIRE_FALSE(row);
  CHECK(row.error().code == "c17.row_requires_exact_enumeration");
}

TEST_CASE("C17 rejects mathematically invalid component masses",
          "[c17][negative]") {
  const auto& base = mwperf::testing::c17::math_base();
  const auto prearrival_backlog =
      mwperf::testing::c17::target_backlog(base, {0U});
  const auto zero = mwperf::ExactRational::zero();
  const auto one = mwperf::ExactRational::one();
  const auto negative = mwperf::testing::c17::rational(-1, 2);

  SECTION("negative mass") {
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
            "negative", prearrival_backlog, negative)},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded());
    CHECK_FALSE(law);
  }

  SECTION("zero total mass") {
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
            "zero-total", prearrival_backlog, zero, false)},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded());
    CHECK_FALSE(law);
  }

  SECTION("claimed-positive atom with zero mass") {
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
             "positive-zero", prearrival_backlog, zero, true),
         mwperf::testing::c17::opportunity_atom(
             "positive-one", prearrival_backlog, one, true)},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded());
    CHECK_FALSE(law);
  }

  SECTION("positive mass outside structural support") {
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
            "nonstructural-positive", prearrival_backlog, one, false)},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded());
    REQUIRE_FALSE(law);
    CHECK(law.error().code == "c17.nonstructural_positive_mass");
  }

  SECTION("out-of-tolerance total is not repaired") {
    const auto excess = mwperf::testing::c17::rational(1, 1'000'000);
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
            "excess", prearrival_backlog, one + excess)},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget::unbounded());
    CHECK_FALSE(law);
  }

  SECTION("exact representation budget exhaustion drops no atom") {
    auto law = mwperf::testing::C17FixtureAccess::opportunity_law(
        {mwperf::testing::c17::opportunity_atom(
             "budget-one", prearrival_backlog,
             mwperf::testing::c17::rational(1, 3)),
         mwperf::testing::c17::opportunity_atom(
             "budget-two", prearrival_backlog,
             mwperf::testing::c17::rational(2, 3))},
        mwperf::physical_pmf_tolerance(),
        mwperf::PmfRepresentationBudget{1U});
    CHECK_FALSE(law);
  }
}

TEST_CASE("C17 V0 reports retain only explicit obligation scopes",
          "[c17][unit]") {
  using Obligation = mwperf::V0ObligationV1;
  using Scope = mwperf::V0EvidenceScopeV1;

  const std::vector<mwperf::V0WitnessEntryV1> entries{
      {Obligation::normalized_typed_laws, Scope::exhaustive, true, {}},
      {Obligation::causal_factorization, Scope::reachable_enumerated, true,
       {}},
      {Obligation::configured_arrival_exactly_once,
       Scope::construction_enforced, true, {}},
      {Obligation::requested_mark_observability, Scope::declared, true, {}}};
  auto report = mwperf::testing::C17FixtureAccess::v0_report(
      {mwperf::testing::c17::digest("v0.instance"),
       mwperf::testing::c17::digest("v0.descriptor"),
       mwperf::testing::c17::digest("v0.access"),
       mwperf::testing::c17::digest("v0.ownership"),
       mwperf::testing::c17::digest("v0.update")},
      entries, true);

  REQUIRE(report.passed());
  REQUIRE(report.entries().size() == entries.size());
  CHECK(report.entries()[0].evidence_scope == Scope::exhaustive);
  CHECK(report.entries()[1].evidence_scope == Scope::reachable_enumerated);
  CHECK(report.entries()[2].evidence_scope == Scope::construction_enforced);
  CHECK(report.entries()[3].evidence_scope == Scope::declared);
}

}  // namespace
