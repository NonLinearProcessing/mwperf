#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/stationary/three_bin_summary.hpp"
#include "support/c19_math_test_util.hpp"

namespace {

using namespace mwperf;
using namespace mwperf::testing::c19_math;

struct PgfConformancePoint final {
  ExactRational point;
  ExactRational expected;
};

struct FinitePrefixFixture final {
  std::string name;
  std::vector<ExactRational> arrival_pmf;
  std::vector<ExactRational> service_by_level;
  ExactRational tail_service;
  std::vector<ExactRational> expected_cut_weights;
  ExactRational expected_b_one;
  std::vector<ExactRational> expected_prefix_masses;
  ExactRational expected_tail_mass;
  ExactRational expected_mean;
  std::vector<PgfConformancePoint> pgf_points;
};

[[nodiscard]] std::vector<FinitePrefixFixture> finite_prefix_fixtures() {
  return {
      {"finite-prefix-k2-bernoulli",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4)},
       rational(2, 3),
       {rational(1), rational(4, 9), rational(4, 27)},
       rational(56, 81),
       {rational(135, 224), rational(15, 56), rational(5, 56)},
       rational(9, 224),
       rational(23, 40),
       {{rational(1, 2), rational(1075, 1408)},
        {rational(2, 3), rational(3355, 4032)}}},
      {"finite-prefix-k3-batch",
       {rational(3, 4), rational(0), rational(1, 4)},
       {rational(0), rational(1, 2), rational(3, 4), rational(1)},
       rational(3, 4),
       {rational(1), rational(2, 3), rational(20, 27), rational(29, 81)},
       rational(67, 81),
       {rational(81, 268), rational(27, 134), rational(15, 67),
        rational(29, 268)},
       rational(11, 67),
       rational(503, 268),
       {{rational(1, 2), rational(27703, 57888)},
        {rational(2, 3), rational(226331, 383508)}}},
      {"finite-prefix-k4-bernoulli",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4), rational(4, 5),
        rational(1, 2)},
       rational(2, 3),
       {rational(1), rational(4, 9), rational(4, 27), rational(5, 108),
        rational(1, 162)},
       rational(667, 972),
       {rational(405, 667), rational(180, 667), rational(60, 667),
        rational(75, 2668), rational(5, 1334)},
       rational(3, 2668),
       rational(7403, 13340),
       {{rational(1, 2), rational(360815, 469568)},
        {rational(2, 3), rational(90365, 108054)}}},
      {"finite-prefix-k5-anti-fold",
       {rational(3, 4), rational(1, 4)},
       {rational(0), rational(3, 4), rational(1, 4), rational(4, 5),
        rational(1, 2), rational(5, 6)},
       rational(2, 3),
       {rational(1), rational(4, 9), rational(4, 27), rational(5, 108),
        rational(1, 162), rational(1, 810)},
       rational(1667, 2430),
       {rational(2025, 3334), rational(450, 1667), rational(150, 1667),
        rational(375, 13336), rational(25, 6668), rational(5, 6668)},
       rational(1, 13336),
       rational(18453, 33340),
       {{rational(1, 2), rational(3608115, 4694272)},
        {rational(2, 3), rational(338855, 405081)}}},
  };
}

[[nodiscard]] std::vector<ScalarArrivalMassV1> arrival_atoms(
    const std::vector<ExactRational>& dense_pmf) {
  std::vector<ScalarArrivalMassV1> atoms;
  for (std::size_t count = 0U; count < dense_pmf.size(); ++count) {
    if (dense_pmf[count].is_positive()) {
      atoms.push_back(
          {BigNat{static_cast<std::uint64_t>(count)}, dense_pmf[count]});
    }
  }
  return atoms;
}

[[nodiscard]] ExactRational arrival_survival(
    const std::vector<ExactRational>& dense_pmf,
    const std::size_t threshold) {
  ExactRational result = ExactRational::zero();
  for (std::size_t count = threshold; count < dense_pmf.size(); ++count) {
    result = result + dense_pmf[count];
  }
  return result;
}

[[nodiscard]] ExactRational arrival_moment(
    const std::vector<ExactRational>& dense_pmf, const std::uint8_t order) {
  ExactRational result = ExactRational::zero();
  for (std::size_t count = 0U; count < dense_pmf.size(); ++count) {
    const ExactRational value =
        rational(static_cast<std::int64_t>(count));
    result = result + dense_pmf[count] *
                          (order == 1U ? value : value * value);
  }
  return result;
}

// SF.19 evaluated directly from the cut-balance equation. This oracle does
// not call the production recursion or its arrival-survival implementation.
[[nodiscard]] ExactRational cut_crossing_flux(
    const FinitePrefixFixture& fixture,
    const std::vector<ExactRational>& cut_weights, const std::size_t cut) {
  ExactRational result = ExactRational::zero();
  for (std::size_t source = 0U; source < cut; ++source) {
    const std::size_t distance = cut - source;
    result =
        result +
        cut_weights[source] *
            ((ExactRational::one() - fixture.service_by_level[source]) *
                 arrival_survival(fixture.arrival_pmf, distance) +
             fixture.service_by_level[source] *
                 arrival_survival(fixture.arrival_pmf, distance + 1U));
  }
  return result;
}

[[nodiscard]] ExactRational polynomial(
    const std::vector<ExactRational>& coefficients,
    const ExactRational& point) {
  ExactRational value = ExactRational::zero();
  ExactRational power = ExactRational::one();
  for (const ExactRational& coefficient : coefficients) {
    value = value + coefficient * power;
    power = power * point;
  }
  return value;
}

// The stationary queue balance gives
// G(z) = A(z)(z-1)C(z) / [z-A(z){z+c(1-z)}], where
// C(z) = sum_{j=0}^K pi_j(c-mu(j))z^j.
[[nodiscard]] ExactRational constant_tail_pgf(
    const FinitePrefixFixture& fixture,
    const std::vector<ExactRational>& prefix_masses,
    const ExactRational& point) {
  std::vector<ExactRational> correction;
  correction.reserve(prefix_masses.size());
  for (std::size_t level = 0U; level < prefix_masses.size(); ++level) {
    correction.push_back(prefix_masses[level] *
                         (fixture.tail_service -
                          fixture.service_by_level[level]));
  }
  const ExactRational arrival = polynomial(fixture.arrival_pmf, point);
  const ExactRational numerator =
      arrival * (point - ExactRational::one()) *
      polynomial(correction, point);
  const ExactRational denominator =
      point - arrival *
                  (point + fixture.tail_service *
                               (ExactRational::one() - point));
  return divide(numerator, denominator);
}

[[nodiscard]] AuditedResponseLaw response_for(
    const std::string& identity,
    const std::vector<ExactRational>& arrival_pmf,
    const std::vector<ExactRational>& service_by_level,
    const ExactRational& tail_service_value,
    const bool second_moment_available = true,
    const bool include_selection_seed = true) {
  auto spec = scalar_carrier(
      lineage(identity), arrival_atoms(arrival_pmf), service_by_level,
      BigNat{static_cast<std::uint64_t>(service_by_level.size())},
      tail_service_value, second_moment_available);
  if (!include_selection_seed) {
    spec.selection_seed.clear();
  }
  auto response = mint_scalar_response(std::move(spec));
  INFO((response ? std::string{} : response.error().code));
  REQUIRE(response);
  return std::move(response).value();
}

[[nodiscard]] ArrivalLaw arrival_for(const AuditedResponseLaw& response) {
  auto arrival = ArrivalLaw::from_audited(response);
  INFO((arrival ? std::string{} : arrival.error().code));
  REQUIRE(arrival);
  return std::move(arrival).value();
}

[[nodiscard]] ScalarStationaryLaw solve_finite_prefix(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival,
    const std::size_t cutoff, const ExactRational& tail_service_value) {
  auto law = solve_constant_tail_response(
      response, arrival,
      Cutoff{BigNat{static_cast<std::uint64_t>(cutoff)}},
      tail_service(tail_service_value));
  INFO((law ? std::string{} : law.error().code));
  REQUIRE(law);
  return std::move(law).value();
}

}  // namespace

TEST_CASE("C19 finite-prefix IID fixtures independently prove K two through five",
          "[c19][math][finite-prefix][sf19][sf22]") {
  bool covered_batch_arrival = false;
  bool covered_nonmonotone_response = false;
  bool covered_prefix_service_above_tail = false;

  for (const FinitePrefixFixture& fixture : finite_prefix_fixtures()) {
    CAPTURE(fixture.name);
    const std::size_t cutoff = fixture.service_by_level.size() - 1U;
    REQUIRE(fixture.expected_cut_weights.size() == cutoff + 1U);
    REQUIRE(fixture.expected_prefix_masses.size() == cutoff + 1U);
    CHECK(fixture.expected_cut_weights.front() == ExactRational::one());

    if (fixture.arrival_pmf.size() > 2U) {
      covered_batch_arrival = true;
    }
    for (std::size_t level = 2U;
         level < fixture.service_by_level.size(); ++level) {
      covered_nonmonotone_response =
          covered_nonmonotone_response ||
          fixture.service_by_level[level] <
              fixture.service_by_level[level - 1U];
    }
    for (const ExactRational& service : fixture.service_by_level) {
      covered_prefix_service_above_tail =
          covered_prefix_service_above_tail ||
          service > fixture.tail_service;
    }

    const ExactRational a_zero = fixture.arrival_pmf.front();
    for (std::size_t cut = 1U; cut <= cutoff; ++cut) {
      CAPTURE(cut);
      const ExactRational crossing = cut_crossing_flux(
          fixture, fixture.expected_cut_weights, cut);
      const ExactRational denominator =
          a_zero * fixture.service_by_level[cut];
      CHECK(denominator * fixture.expected_cut_weights[cut] == crossing);
      CHECK(divide(crossing, denominator) ==
            fixture.expected_cut_weights[cut]);
    }

    ExactRational b_one = ExactRational::zero();
    for (std::size_t level = 0U; level <= cutoff; ++level) {
      b_one = b_one +
              fixture.expected_cut_weights[level] *
                  (fixture.tail_service -
                   fixture.service_by_level[level]);
    }
    CHECK(b_one == fixture.expected_b_one);

    const ExactRational lambda = arrival_moment(fixture.arrival_pmf, 1U);
    const ExactRational second_moment =
        arrival_moment(fixture.arrival_pmf, 2U);
    const ExactRational pi_zero =
        divide(fixture.tail_service - lambda, b_one);
    CHECK(pi_zero == fixture.expected_prefix_masses.front());

    std::vector<ExactRational> prefix_masses;
    prefix_masses.reserve(cutoff + 1U);
    ExactRational prefix_total = ExactRational::zero();
    ExactRational correction_derivative = ExactRational::zero();
    for (std::size_t level = 0U; level <= cutoff; ++level) {
      const ExactRational mass =
          pi_zero * fixture.expected_cut_weights[level];
      prefix_masses.push_back(mass);
      prefix_total = prefix_total + mass;
      correction_derivative =
          correction_derivative +
          rational(static_cast<std::int64_t>(level)) * mass *
              (fixture.tail_service - fixture.service_by_level[level]);
      CHECK(mass == fixture.expected_prefix_masses[level]);
    }
    const ExactRational aggregate_tail =
        ExactRational::one() - prefix_total;
    CHECK(aggregate_tail == fixture.expected_tail_mass);

    const ExactRational mean = divide(
        second_moment + lambda - rational(2) * lambda * lambda +
            rational(2) * correction_derivative,
        rational(2) * (fixture.tail_service - lambda));
    CHECK(mean == fixture.expected_mean);

    const AuditedResponseLaw response = response_for(
        fixture.name, fixture.arrival_pmf, fixture.service_by_level,
        fixture.tail_service);
    const ArrivalLaw arrival = arrival_for(response);
    const ScalarStationaryLaw law = solve_finite_prefix(
        response, arrival, cutoff, fixture.tail_service);
    CHECK(law.status() == AnalyticStationaryStatusV1::strict_tail_stable);
    CHECK(law.normalized_law_established());
    REQUIRE(law.identity().cutoff());
    REQUIRE(law.identity().tail_service());
    CHECK(*law.identity().cutoff() ==
          BigNat{static_cast<std::uint64_t>(cutoff)});
    CHECK(*law.identity().tail_service() == fixture.tail_service);
    for (std::size_t level = 0U; level <= cutoff; ++level) {
      CHECK(scalar_mass(law, static_cast<std::uint64_t>(level)) ==
            fixture.expected_prefix_masses[level]);
    }
    REQUIRE(law.exact_tail_mass());
    REQUIRE(law.exact_mean_backlog());
    CHECK(*law.exact_tail_mass() == fixture.expected_tail_mass);
    CHECK(*law.exact_mean_backlog() == fixture.expected_mean);
    REQUIRE(law.diagnostics().tail_slack);
    REQUIRE(law.diagnostics().terms_evaluated);
    CHECK(*law.diagnostics().tail_slack == fixture.tail_service - lambda);
    CHECK(*law.diagnostics().terms_evaluated ==
          BigNat{static_cast<std::uint64_t>(cutoff + 1U)});
    CHECK(law.diagnostics().normalization_residual.is_zero());
    CHECK(law.diagnostics().invariance_residual.is_zero());

    ExactRational flow = fixture.tail_service * fixture.expected_tail_mass;
    for (std::size_t level = 0U; level <= cutoff; ++level) {
      flow = flow + fixture.service_by_level[level] *
                        fixture.expected_prefix_masses[level];
    }
    CHECK(flow == lambda);

    for (const PgfConformancePoint& conformance : fixture.pgf_points) {
      CAPTURE(conformance.point.numerator_decimal(),
              conformance.point.denominator_decimal());
      CHECK(constant_tail_pgf(fixture, prefix_masses,
                              conformance.point) == conformance.expected);
      auto readout = evaluate_scalar_pgf_and_moments(
          law, ArrivalTransform::from(arrival),
          evaluation_point(conformance.point));
      INFO((readout ? std::string{} : readout.error().code));
      REQUIRE(readout);
      REQUIRE(readout.value().exact_pgf());
      REQUIRE(readout.value().exact_mean_backlog());
      CHECK(*readout.value().exact_pgf() == conformance.expected);
      CHECK(*readout.value().exact_mean_backlog() == fixture.expected_mean);
    }

    if (cutoff == 5U) {
      // Levels three through five are pairwise distinct and differ from the
      // K=2 compatibility curve. Their exact masses and the native cutoff
      // therefore make an accidental K=2 fold observable.
      CHECK(fixture.service_by_level[3U] == rational(4, 5));
      CHECK(fixture.service_by_level[4U] == rational(1, 2));
      CHECK(fixture.service_by_level[5U] == rational(5, 6));
      CHECK(scalar_mass(law, 3U) == rational(375, 13336));
      CHECK(scalar_mass(law, 4U) == rational(25, 6668));
      CHECK(scalar_mass(law, 5U) == rational(5, 6668));
      CHECK(scalar_mass(law, 0U) != rational(135, 224));
      CHECK(*law.exact_tail_mass() != rational(9, 224));
    }
  }

  CHECK(covered_batch_arrival);
  CHECK(covered_nonmonotone_response);
  CHECK(covered_prefix_service_above_tail);
}

TEST_CASE("C19 K two generic constant-tail law agrees with ThreeBin summary",
          "[c19][math][finite-prefix][three-bin-compatibility]") {
  const FinitePrefixFixture fixture = finite_prefix_fixtures().front();
  const AuditedResponseLaw generic_response = response_for(
      "finite-prefix-k2-generic-compatibility", fixture.arrival_pmf,
      fixture.service_by_level, fixture.tail_service);
  const ArrivalLaw generic_arrival = arrival_for(generic_response);
  const ScalarStationaryLaw generic_law = solve_finite_prefix(
      generic_response, generic_arrival, 2U, fixture.tail_service);

  auto legacy_spec = scalar_carrier(
      lineage("finite-prefix-k2-legacy-compatibility"),
      arrival_atoms(fixture.arrival_pmf), fixture.service_by_level,
      BigNat{3U}, fixture.tail_service);
  auto legacy_response = mint_three_bin_response(std::move(legacy_spec));
  INFO((legacy_response ? std::string{} : legacy_response.error().code));
  REQUIRE(legacy_response);
  auto legacy_arrival = ArrivalLaw::from_audited(legacy_response.value());
  INFO((legacy_arrival ? std::string{} : legacy_arrival.error().code));
  REQUIRE(legacy_arrival);
  auto legacy_summary = summarize_three_bin_iid_response(
      legacy_response.value(), legacy_arrival.value());
  INFO((legacy_summary ? std::string{} : legacy_summary.error().code));
  REQUIRE(legacy_summary);

  REQUIRE(legacy_summary.value().pi_zero());
  REQUIRE(legacy_summary.value().pi_one());
  REQUIRE(legacy_summary.value().pi_two());
  REQUIRE(legacy_summary.value().tail_mass_from_three());
  REQUIRE(legacy_summary.value().exact_mean_backlog());
  CHECK(scalar_mass(generic_law, 0U) ==
        *legacy_summary.value().pi_zero());
  CHECK(scalar_mass(generic_law, 1U) ==
        *legacy_summary.value().pi_one());
  CHECK(scalar_mass(generic_law, 2U) ==
        *legacy_summary.value().pi_two());
  REQUIRE(generic_law.exact_tail_mass());
  REQUIRE(generic_law.exact_mean_backlog());
  CHECK(*generic_law.exact_tail_mass() ==
        *legacy_summary.value().tail_mass_from_three());
  CHECK(*generic_law.exact_mean_backlog() ==
        *legacy_summary.value().exact_mean_backlog());
}

TEST_CASE("C19 finite-prefix zero denominators preserve availability semantics",
          "[c19][math][finite-prefix][zero-denominator]") {
  SECTION("positive crossing flux with a zero coefficient is unsupported") {
    const ExactRational lambda = rational(1, 4);
    const ExactRational tail = rational(3, 4);
    const AuditedResponseLaw response = response_for(
        "finite-prefix-zero-positive-crossing",
        {rational(3, 4), lambda},
        {rational(0), rational(0), rational(1, 2)}, tail);
    const ArrivalLaw arrival = arrival_for(response);
    const ScalarStationaryLaw law =
        solve_finite_prefix(response, arrival, 2U, tail);

    CHECK(arrival_survival({rational(3, 4), lambda}, 1U) == lambda);
    CHECK(law.status() ==
          AnalyticStationaryStatusV1::unsupported_assumptions);
    CHECK_FALSE(law.normalized_law_established());
    CHECK_FALSE(law.exact_tail_mass());
    CHECK_FALSE(law.exact_mean_backlog());
    REQUIRE(law.diagnostics().tail_slack);
    REQUIRE(law.diagnostics().terms_evaluated);
    CHECK(*law.diagnostics().tail_slack == rational(1, 2));
    CHECK(*law.diagnostics().terms_evaluated == BigNat{1U});
  }

  SECTION("zero crossing flux with a zero coefficient remains degenerate") {
    const ExactRational tail = rational(3, 4);
    const AuditedResponseLaw response = response_for(
        "finite-prefix-zero-zero-crossing", {rational(1)},
        {rational(0), rational(0), rational(1, 2)}, tail, true, false);
    const ArrivalLaw arrival = arrival_for(response);
    const ScalarStationaryLaw law =
        solve_finite_prefix(response, arrival, 2U, tail);

    CHECK(arrival_survival({rational(1)}, 1U).is_zero());
    CHECK(law.status() ==
          AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
    CHECK_FALSE(law.normalized_law_established());
    CHECK_FALSE(law.exact_tail_mass());
    CHECK_FALSE(law.exact_mean_backlog());
    REQUIRE(law.diagnostics().tail_slack);
    REQUIRE(law.diagnostics().terms_evaluated);
    CHECK(*law.diagnostics().tail_slack == tail);
    CHECK(*law.diagnostics().terms_evaluated == BigNat{1U});
  }
}

TEST_CASE("C19 finite-prefix tail and moment premises keep their typed statuses",
          "[c19][math][finite-prefix][classification]") {
  SECTION("a reachable nonpositive tail slack establishes no law") {
    const ExactRational lambda = rational(3, 4);
    const ExactRational tail = rational(1, 2);
    const AuditedResponseLaw response = response_for(
        "finite-prefix-nonpositive-slack",
        {rational(1, 4), lambda},
        {rational(0), rational(3, 4), rational(1, 4)}, tail);
    const ArrivalLaw arrival = arrival_for(response);
    const ScalarStationaryLaw law =
        solve_finite_prefix(response, arrival, 2U, tail);

    CHECK(law.status() ==
          AnalyticStationaryStatusV1::outside_strict_tail_profile);
    CHECK_FALSE(law.normalized_law_established());
    CHECK_FALSE(law.exact_tail_mass());
    CHECK_FALSE(law.exact_mean_backlog());
    REQUIRE(law.diagnostics().tail_slack);
    REQUIRE(law.diagnostics().terms_evaluated);
    CHECK(*law.diagnostics().tail_slack == rational(-1, 4));
    CHECK(*law.diagnostics().terms_evaluated == BigNat{3U});
  }

  SECTION("a missing second moment retains the normalized K-wide law") {
    const FinitePrefixFixture fixture = finite_prefix_fixtures()[2U];
    const std::size_t cutoff = fixture.service_by_level.size() - 1U;
    const AuditedResponseLaw response = response_for(
        "finite-prefix-missing-second-moment", fixture.arrival_pmf,
        fixture.service_by_level, fixture.tail_service, false);
    const ArrivalLaw arrival = arrival_for(response);
    CHECK_FALSE(arrival.second_moment());
    const ScalarStationaryLaw law = solve_finite_prefix(
        response, arrival, cutoff, fixture.tail_service);

    CHECK(law.status() ==
          AnalyticStationaryStatusV1::required_moment_unavailable);
    CHECK(law.normalized_law_established());
    for (std::size_t level = 0U; level <= cutoff; ++level) {
      CHECK(scalar_mass(law, static_cast<std::uint64_t>(level)) ==
            fixture.expected_prefix_masses[level]);
    }
    REQUIRE(law.exact_tail_mass());
    CHECK(*law.exact_tail_mass() == fixture.expected_tail_mass);
    CHECK_FALSE(law.exact_mean_backlog());
    CHECK_FALSE(law.numerical_mean_backlog());

    auto readout = evaluate_scalar_pgf_and_moments(
        law, ArrivalTransform::from(arrival),
        evaluation_point(rational(1, 2)));
    INFO((readout ? std::string{} : readout.error().code));
    REQUIRE(readout);
    REQUIRE(readout.value().exact_pgf());
    CHECK(*readout.value().exact_pgf() == rational(360815, 469568));
    CHECK_FALSE(readout.value().exact_mean_backlog());
  }

  SECTION("zero arrival intensity yields delta zero when descent is strict") {
    const ExactRational tail = rational(3, 4);
    const AuditedResponseLaw response = response_for(
        "finite-prefix-zero-intensity", {rational(1)},
        {rational(0), rational(1, 2), rational(1, 3)}, tail, true, false);
    const ArrivalLaw arrival = arrival_for(response);
    const ScalarStationaryLaw law =
        solve_finite_prefix(response, arrival, 2U, tail);

    CHECK(arrival.mean().is_zero());
    CHECK(law.status() == AnalyticStationaryStatusV1::strict_tail_stable);
    CHECK(law.normalized_law_established());
    CHECK(scalar_mass(law, 0U) == ExactRational::one());
    CHECK(scalar_mass(law, 1U).is_zero());
    CHECK(scalar_mass(law, 2U).is_zero());
    REQUIRE(law.exact_tail_mass());
    REQUIRE(law.exact_mean_backlog());
    CHECK(law.exact_tail_mass()->is_zero());
    CHECK(law.exact_mean_backlog()->is_zero());

    auto summary_spec = scalar_carrier(
        lineage("finite-prefix-zero-intensity-sojourn"),
        {{BigNat{0U}, ExactRational::one()}},
        {rational(0), rational(1, 2), rational(1, 3)}, BigNat{3U}, tail);
    auto summary_response = mint_three_bin_response(std::move(summary_spec));
    REQUIRE(summary_response);
    auto summary_arrival = ArrivalLaw::from_audited(summary_response.value());
    REQUIRE(summary_arrival);
    auto summary = summarize_three_bin_iid_response(
        summary_response.value(), summary_arrival.value());
    REQUIRE(summary);
    REQUIRE(summary.value().exact_mean_backlog());
    CHECK(summary.value().exact_mean_backlog()->is_zero());
    CHECK_FALSE(summary.value().exact_mean_sojourn());
    CHECK_FALSE(summary.value().numerical_mean_sojourn());
  }
}
