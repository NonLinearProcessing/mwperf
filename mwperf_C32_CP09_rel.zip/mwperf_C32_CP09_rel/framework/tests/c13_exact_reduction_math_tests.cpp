#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>
#include <nlohmann/json.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/reduction/exact_reductions.hpp"

namespace {

struct ReductionFixture final {
  mwperf::ResolvedInstance instance;
  std::shared_ptr<const mwperf::CompiledArrivalLaw> arrival;
  std::shared_ptr<const mwperf::InitialPhysicalLaw> initial;
};

[[nodiscard]] std::filesystem::path write_input(
    const std::string_view stem, const std::string_view text) {
  static std::atomic<unsigned int> next{0U};
  const std::filesystem::path directory =
      std::filesystem::path(MWPERF_TEST_TEMP_DIRECTORY) / "c13-reduction";
  std::error_code error;
  std::filesystem::create_directories(directory, error);
  REQUIRE_FALSE(error);
  const std::filesystem::path path =
      directory /
      (std::string(stem) + '-' + std::to_string(next.fetch_add(1U)) +
       ".json");
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  REQUIRE(output.is_open());
  output.write(text.data(), static_cast<std::streamsize>(text.size()));
  REQUIRE(output.good());
  return path;
}

[[nodiscard]] std::string queue_json(
    const std::span<const std::string> queue_ids) {
  std::string result{"["};
  for (std::size_t index = 0U; index < queue_ids.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += "{\"id\":\"" + queue_ids[index] + "\"}";
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string backlog_json(
    const std::span<const std::string> queue_ids,
    const std::span<const std::string> values) {
  REQUIRE(queue_ids.size() == values.size());
  std::string result{"["};
  for (std::size_t index = 0U; index < queue_ids.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += "{\"queue_id\":\"" + queue_ids[index] +
              "\",\"value\":" + values[index] + "}";
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string model_text(
    const std::span<const std::string> queue_ids,
    const std::string_view scheduler, const std::string_view events) {
  return std::string(R"json({
    "schema_version":"3.0.0",
    "run":{"seed":17,"slots":8,"warmup_slots":0,
           "termination":"fixed_slots"},
    "switch":{"kind":"generalized","queue_capacity":null,"queues":)json") +
         queue_json(queue_ids) + R"json(},
    "scheduler":)json" + std::string(scheduler) + R"json(,
    "arrival":{"family":"deterministic_trace","events":)json" +
         std::string(events) + R"json(,"metadata":{}},
    "telemetry":{"format":"jsonl","queue_snapshot":"disabled",
                 "include_packet_events":false,
                 "include_scheduler_state":false,
                 "write_slot_trace":false},
    "metadata":{}
  })json";
}

[[nodiscard]] std::string analysis_text(
    const std::span<const std::string> queue_ids,
    const std::span<const std::string> backlog,
    const std::string_view maximum_calls = "256") {
  return std::string(R"json({
    "analysis_schema_version":"1.0.0",
    "targets":["q0"],
    "metrics":[{"id":"law","kind":"transient_backlog_law",
                "parameters":{"horizons":[0,1,2]}}],
    "surrogate":{"id":"future","version":null,"parameters":{}},
    "resolution":{
      "level":{"max_states":null,"max_row_atoms":null},
      "tail":{"kind":"none","parameters":{}},
      "phase":{"max_phase_states":null},
      "optimizer":{"max_calls":)json") + std::string(maximum_calls) +
         R"json(,"max_search_states_per_call":null},
      "sampling":{"max_generator_draws":null},
      "tolerance":{"linear_residual_abs":null,"integration_abs":null,
                   "tail_abs":null,"fixed_point_abs":null}},
    "selection":{"kind":"transient","parameters":{"initial_law":{
      "atoms":[{"probability":1,"backlog":)json" +
         backlog_json(queue_ids, backlog) + R"json(,
        "controller_state":{},"arrival_state":{"kind":"trace_origin"},
        "static_context":{},"surrogate_initial":{}}]}}},
    "solver":{"kind":"enumerated",
              "parameters":{"linear_method":"dense_pivoted",
                            "max_iterations":null}}
  })json";
}

[[nodiscard]] ReductionFixture make_fixture(
    std::vector<std::string> queue_ids, const std::string_view scheduler,
    std::vector<std::string> backlog,
    const std::string_view events = "[]",
    const std::string_view maximum_calls = "256") {
  auto model_document = mwperf::load_document(
      write_input("model", model_text(queue_ids, scheduler, events)));
  REQUIRE(model_document);
  auto model_node = mwperf::extract_executable_model(model_document.value());
  REQUIRE(model_node);
  auto model = mwperf::parse_model_config_v3(model_node.value());
  INFO((model ? std::string{}
              : model.error().code + ": " + model.error().message));
  REQUIRE(model);

  auto analysis_document = mwperf::load_document(write_input(
      "analysis", analysis_text(queue_ids, backlog, maximum_calls)));
  REQUIRE(analysis_document);
  auto analysis = mwperf::parse_analysis_spec_v1(analysis_document.value());
  INFO((analysis ? std::string{}
                 : analysis.error().code + ": " + analysis.error().message));
  REQUIRE(analysis);
  const mwperf::CanonicalInputPair canonical =
      mwperf::canonicalize_authored_inputs(model.value(), analysis.value());
  const mwperf::InputFingerprintBundle fingerprints =
      mwperf::fingerprint_inputs(canonical);
  auto resolved = mwperf::resolve_physical_instance(
      model.value(), analysis.value(), fingerprints);
  INFO((resolved ? std::string{}
                 : resolved.error().code + ": " + resolved.error().message));
  REQUIRE(resolved);
  REQUIRE(resolved.value().initial_law().has_value());

  mwperf::ResolvedInstance instance = std::move(resolved).value();
  auto compiled_arrival =
      mwperf::detail::CompiledArrivalAccess::get(instance.arrival());
  auto compiled_initial = mwperf::detail::CompiledInitialLawAccess::get(
      *instance.initial_law());
  REQUIRE(compiled_arrival);
  REQUIRE(compiled_initial);
  return ReductionFixture{std::move(instance), compiled_arrival.value(),
                          compiled_initial.value()};
}

[[nodiscard]] mwperf::OptimizerExecutionContext optimizer_context(
    const mwperf::ResolvedInstance& instance,
    std::optional<mwperf::BigNat> maximum_calls = std::nullopt) {
  auto result = mwperf::OptimizerExecutionContext::from_resolved_instance(
      instance, std::move(maximum_calls));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Backlog make_backlog(
    const ReductionFixture& fixture, std::vector<mwperf::BigNat> values) {
  auto result = mwperf::Backlog::from_values(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::Schedule make_schedule(
    const ReductionFixture& fixture, std::vector<std::uint8_t> values) {
  auto result = mwperf::Schedule::from_bytes(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::TargetIndex target(const ReductionFixture& fixture,
                                         const std::size_t ordinal = 0U) {
  auto result = mwperf::TargetIndex::from_instance(fixture.instance, ordinal);
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::NonnegativeIntegralDirection make_direction(
    const ReductionFixture& fixture, std::vector<mwperf::BigNat> values) {
  auto result = mwperf::NonnegativeIntegralDirection::from_values(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactRational rational(const std::int64_t numerator,
                                             const std::int64_t denominator) {
  auto result = mwperf::ExactRational::make(mwperf::BigInt(numerator),
                                            mwperf::BigInt(denominator));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] mwperf::ExactNonnegativeRationalWeights make_weights(
    const ReductionFixture& fixture,
    std::vector<mwperf::ExactRational> values,
    mwperf::RationalSupportRepresentationBudget budget =
        mwperf::RationalSupportRepresentationBudget::unbounded()) {
  auto result = mwperf::ExactNonnegativeRationalWeights::from_values(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      std::move(values), std::move(budget));
  REQUIRE(result);
  return std::move(result).value();
}

[[nodiscard]] std::vector<std::uint8_t> bits(
    const mwperf::Schedule& schedule) {
  return {schedule.bytes().begin(), schedule.bytes().end()};
}

[[nodiscard]] std::vector<mwperf::BigNat> values(
    const std::span<const mwperf::BigNat> input) {
  return {input.begin(), input.end()};
}

[[nodiscard]] mwperf::PhysicalPath run_path(
    const ReductionFixture& fixture, const std::uint64_t horizon,
    const std::uint64_t seed = 1313U) {
  auto context = optimizer_context(fixture.instance);
  auto path = mwperf::execute_reference_path(
      fixture.instance, *fixture.arrival, *fixture.initial,
      mwperf::BigNat(horizon), mwperf::MasterSeed(seed), context);
  INFO((path ? std::string{}
             : path.error().code + ": " + path.error().message));
  REQUIRE(path);
  return std::move(path).value();
}

[[nodiscard]] nlohmann::json golden_cases() {
  const std::filesystem::path path =
      std::filesystem::path(MWPERF_TEST_SOURCE_DIRECTORY) /
      "tests/fixtures/c13/exact_reduction_cases.json";
  std::ifstream input(path, std::ios::binary);
  REQUIRE(input.is_open());
  return nlohmann::json::parse(input);
}

[[nodiscard]] mwperf::BigInt decimal_int(const nlohmann::json& value) {
  return mwperf::BigInt(value.get<std::string>());
}

[[nodiscard]] std::string clique_scheduler(
    const std::string_view priority) {
  return std::string(
             R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q0","q2"],["q1","q2"]]},"priority":)json") +
         std::string(priority) +
         R"json(,"max_search_states":null}})json";
}

[[nodiscard]] std::string two_queue_clique_scheduler(
    const std::string_view priority = R"json(["q0","q1"])json") {
  return std::string(
             R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"]]},"priority":)json") +
         std::string(priority) +
         R"json(,"max_search_states":null}})json";
}

}  // namespace

TEST_CASE("C13 opportunity is the exact difference of two forced faces",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(R"json(["q1","q0"])json"),
      {"3", "5"});
  const mwperf::Backlog queue = make_backlog(
      fixture, {mwperf::BigNat(3U), mwperf::BigNat(5U)});
  auto context = optimizer_context(fixture.instance);
  auto result = mwperf::compute_target_opportunity(
      fixture.instance, queue, target(fixture), context);
  REQUIRE(result);
  const mwperf::Opportunity& opportunity = result.value();

  CHECK(opportunity.psi0() == mwperf::BigNat(5U));
  CHECK(opportunity.psi1() == mwperf::BigNat(0U));
  CHECK(opportunity.theta() == mwperf::BigNat(5U));
  CHECK(opportunity.margin() == mwperf::BigInt(-2));
  CHECK(opportunity.cross_class_outcome().algebraic_class ==
        mwperf::AlgebraicTargetClass::forced_out);
  CHECK(opportunity.cross_class_outcome().configured_winning_side ==
        mwperf::ForcedTargetBit::zero);
  CHECK(bits(opportunity.cross_class_outcome().configured_winning_schedule) ==
        std::vector<std::uint8_t>{0U, 1U});
  CHECK(opportunity.forced_out_certificate().value == mwperf::BigNat(5U));
  CHECK(opportunity.forced_in_certificate().value == mwperf::BigNat(0U));
  CHECK(context.ledger_snapshot().calls_reserved() == mwperf::BigNat(2U));

  struct Classification final {
    std::uint64_t backlog;
    mwperf::AlgebraicTargetClass expected_class;
    std::int64_t expected_margin;
    bool eligible;
  };
  for (const Classification& item :
       std::vector<Classification>{
           {0U, mwperf::AlgebraicTargetClass::forced_out, -5, false},
           {3U, mwperf::AlgebraicTargetClass::forced_out, -2, true},
           {5U, mwperf::AlgebraicTargetClass::tie, 0, true},
           {8U, mwperf::AlgebraicTargetClass::forced_in, 3, true}}) {
    const mwperf::TargetClass classified = mwperf::classify_target_decision(
        opportunity, mwperf::TargetBacklog(mwperf::BigNat(item.backlog)));
    CHECK(classified.algebraic_class == item.expected_class);
    CHECK(classified.algebraic_margin == mwperf::BigInt(item.expected_margin));
    CHECK(classified.eligible == item.eligible);
  }

  const mwperf::Backlog equality = make_backlog(
      fixture, {mwperf::BigNat(5U), mwperf::BigNat(5U)});
  auto resolver_context = optimizer_context(fixture.instance);
  auto decision = mwperf::resolve_maxweight_schedule(
      fixture.instance, equality, mwperf::TieContext::configured_priority(),
      resolver_context);
  REQUIRE(decision);
  CHECK(bits(decision.value().schedule) ==
        bits(opportunity.equality_winner_if_qe_eq_theta().winning_schedule));
  CHECK(opportunity.equality_winner_if_qe_eq_theta().winning_side ==
        mwperf::ForcedTargetBit::zero);

  const ReductionFixture reversed = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"3", "5"});
  auto reversed_context = optimizer_context(reversed.instance);
  auto reversed_opportunity = mwperf::compute_target_opportunity(
      reversed.instance,
      make_backlog(reversed, {mwperf::BigNat(3U), mwperf::BigNat(5U)}),
      target(reversed), reversed_context);
  REQUIRE(reversed_opportunity);
  CHECK(reversed_opportunity.value().psi0() == opportunity.psi0());
  CHECK(reversed_opportunity.value().psi1() == opportunity.psi1());
  CHECK(reversed_opportunity.value().theta() == opportunity.theta());
  CHECK(reversed_opportunity.value()
            .equality_winner_if_qe_eq_theta()
            .winning_side == mwperf::ForcedTargetBit::one);
  CHECK(bits(reversed_opportunity.value()
                 .equality_winner_if_qe_eq_theta()
                 .winning_schedule) == std::vector<std::uint8_t>{1U, 0U});
}

TEST_CASE("C13 opportunity thresholds cover all exact optimizer families",
          "[c13][integration]") {
  struct Case final {
    std::vector<std::string> queues;
    std::string scheduler;
    std::vector<std::string> authored_backlog;
    std::vector<mwperf::BigNat> backlog;
    std::uint64_t psi0;
    std::uint64_t psi1;
    std::uint64_t theta;
    std::int64_t margin;
  };
  const std::vector<Case> cases{
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"crossbar_max_weight","params":{"constraint":{"inputs":["i0","i1"],"outputs":["o0","o1"],"edges":[{"queue_id":"q0","input":"i0","output":"o0"},{"queue_id":"q1","input":"i0","output":"o1"},{"queue_id":"q2","input":"i1","output":"o0"},{"queue_id":"q3","input":"i1","output":"o1"}]},"priority":["q0","q1","q2","q3"]}})json",
       {"8", "7", "6", "5"},
       {mwperf::BigNat(8U), mwperf::BigNat(7U), mwperf::BigNat(6U),
        mwperf::BigNat(5U)},
       13U, 5U, 8U, 0},
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"interval_max_weight","params":{"constraint":{"intervals":[{"queue_id":"q0","left":0,"right":2},{"queue_id":"q1","left":1,"right":3},{"queue_id":"q2","left":2,"right":4},{"queue_id":"q3","left":3,"right":5}]},"priority":["q0","q1","q2","q3"]}})json",
       {"5", "8", "7", "4"},
       {mwperf::BigNat(5U), mwperf::BigNat(8U), mwperf::BigNat(7U),
        mwperf::BigNat(4U)},
       12U, 7U, 5U, 0},
      {{"q0", "q1", "q2", "q3", "q4"},
       R"json({"name":"node_exclusive_max_weight","params":{"constraint":{"vertices":["A","B","C","D","E"],"links":[{"queue_id":"q0","u":"A","v":"B"},{"queue_id":"q1","u":"B","v":"A"},{"queue_id":"q2","u":"C","v":"D"},{"queue_id":"q3","u":"A","v":"C"},{"queue_id":"q4","u":"B","v":"E"}]},"priority":["q1","q0","q2","q3","q4"]}})json",
       {"7", "7", "6", "5", "5"},
       {mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(6U),
        mwperf::BigNat(5U), mwperf::BigNat(5U)},
       13U, 6U, 7U, 0},
      {{"q0", "q1", "q2"},
       R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
       {"3", "5", "3"},
       {mwperf::BigNat(3U), mwperf::BigNat(5U), mwperf::BigNat(3U)},
       5U, 3U, 2U, 1},
      {{"q0", "q1", "q2", "q3"},
       R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["cpu","ram"],"capacity":[4,4],"demands":[{"queue_id":"q0","demand":[4,1]},{"queue_id":"q1","demand":[1,4]},{"queue_id":"q2","demand":[2,2]},{"queue_id":"q3","demand":[2,2]}]},"priority":["q0","q1","q2","q3"],"max_search_states":null}})json",
       {"7", "7", "6", "6"},
       {mwperf::BigNat(7U), mwperf::BigNat(7U), mwperf::BigNat(6U),
        mwperf::BigNat(6U)},
       12U, 0U, 12U, -5},
  };

  for (const Case& item : cases) {
    const ReductionFixture fixture = make_fixture(
        item.queues, item.scheduler, item.authored_backlog);
    auto context = optimizer_context(fixture.instance);
    auto opportunity = mwperf::compute_target_opportunity(
        fixture.instance, make_backlog(fixture, item.backlog), target(fixture),
        context);
    INFO((opportunity ? std::string{}
                      : opportunity.error().code + ": " +
                            opportunity.error().message));
    REQUIRE(opportunity);
    CHECK(opportunity.value().psi0() == mwperf::BigNat(item.psi0));
    CHECK(opportunity.value().psi1() == mwperf::BigNat(item.psi1));
    CHECK(opportunity.value().theta() == mwperf::BigNat(item.theta));
    CHECK(opportunity.value().margin() == mwperf::BigInt(item.margin));
    CHECK(context.ledger_snapshot().calls_reserved() == mwperf::BigNat(2U));
  }
}

TEST_CASE("C13 opportunity preserves arbitrary precision and is not convex",
          "[c13][property]") {
  SECTION("integer-scaled opportunity is nonconvex") {
    const ReductionFixture fixture = make_fixture(
        {"q0", "q1", "q2"},
        R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
        {"0", "0", "0"});
    const std::vector<std::vector<std::uint64_t>> residuals{
        {2U, 0U}, {1U, 1U}, {0U, 2U}};
    const std::vector<std::uint64_t> expected{0U, 1U, 0U};
    for (std::size_t index = 0U; index < residuals.size(); ++index) {
      auto context = optimizer_context(fixture.instance);
      auto opportunity = mwperf::compute_target_opportunity(
          fixture.instance,
          make_backlog(fixture,
                       {mwperf::BigNat(0U),
                        mwperf::BigNat(residuals[index][0U]),
                        mwperf::BigNat(residuals[index][1U])}),
          target(fixture), context);
      REQUIRE(opportunity);
      CHECK(opportunity.value().theta() == mwperf::BigNat(expected[index]));
    }
  }

  SECTION("a threshold larger than 128 bits keeps its exact sign") {
    mwperf::BigInt huge_value = 1;
    huge_value <<= 130U;
    auto huge = mwperf::BigNat::from_big_int(huge_value);
    auto below = mwperf::BigNat::from_big_int(huge_value - 1);
    REQUIRE(huge);
    REQUIRE(below);
    const ReductionFixture fixture = make_fixture(
        {"q0", "q1"}, two_queue_clique_scheduler(), {"0", "0"});
    const mwperf::Backlog queue = make_backlog(
        fixture, {below.value(), huge.value()});
    auto context = optimizer_context(fixture.instance);
    auto opportunity = mwperf::compute_target_opportunity(
        fixture.instance, queue, target(fixture), context);
    REQUIRE(opportunity);
    CHECK(opportunity.value().theta() == huge.value());
    CHECK(opportunity.value().margin() == mwperf::BigInt(-1));
    CHECK(opportunity.value().theta().bit_length() == 131U);
  }
}

TEST_CASE("C13 tiny conflict oracle exhausts opportunities capacities and regrets",
          "[c13][property]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"0", "0", "0"});
  const auto feasible = [](const std::uint8_t mask) {
    const bool first = (mask & 1U) != 0U;
    const bool middle = (mask & 2U) != 0U;
    const bool last = (mask & 4U) != 0U;
    return !(first && middle) && !(middle && last);
  };
  const auto schedule_for = [&fixture](const std::uint8_t mask) {
    return make_schedule(fixture,
                         {static_cast<std::uint8_t>(mask & 1U),
                          static_cast<std::uint8_t>((mask >> 1U) & 1U),
                          static_cast<std::uint8_t>((mask >> 2U) & 1U)});
  };

  for (std::uint64_t q0 = 0U; q0 <= 3U; ++q0) {
    for (std::uint64_t q1 = 0U; q1 <= 3U; ++q1) {
      for (std::uint64_t q2 = 0U; q2 <= 3U; ++q2) {
        std::uint64_t oracle0 = 0U;
        std::uint64_t oracle1 = 0U;
        for (std::uint8_t mask = 0U; mask < 8U; ++mask) {
          if (!feasible(mask)) {
            continue;
          }
          const std::uint64_t residual =
              (((mask >> 1U) & 1U) * q1) +
              (((mask >> 2U) & 1U) * q2);
          if ((mask & 1U) == 0U) {
            oracle0 = std::max(oracle0, residual);
          } else {
            oracle1 = std::max(oracle1, residual);
          }
        }
        REQUIRE(oracle0 >= oracle1);
        const mwperf::Backlog backlog = make_backlog(
            fixture, {mwperf::BigNat(q0), mwperf::BigNat(q1),
                      mwperf::BigNat(q2)});
        auto context = optimizer_context(fixture.instance,
                                         mwperf::BigNat(2U));
        auto opportunity = mwperf::compute_target_opportunity(
            fixture.instance, backlog, target(fixture), context);
        CAPTURE(q0, q1, q2);
        REQUIRE(opportunity);
        CHECK(opportunity.value().psi0() == mwperf::BigNat(oracle0));
        CHECK(opportunity.value().psi1() == mwperf::BigNat(oracle1));
        CHECK(opportunity.value().theta() ==
              mwperf::BigNat(oracle0 - oracle1));
        CHECK(opportunity.value().margin() ==
              mwperf::BigInt(q0) - mwperf::BigInt(oracle0 - oracle1));

        for (std::uint8_t out_mask = 0U; out_mask < 8U; ++out_mask) {
          if (!feasible(out_mask) || (out_mask & 1U) != 0U) {
            continue;
          }
          for (std::uint8_t in_mask = 0U; in_mask < 8U; ++in_mask) {
            if (!feasible(in_mask) || (in_mask & 1U) == 0U) {
              continue;
            }
            auto pair = mwperf::SchedulePair::make(
                fixture.instance, target(fixture), schedule_for(out_mask),
                schedule_for(in_mask));
            REQUIRE(pair);
            auto margin = mwperf::evaluate_margin_pair(
                backlog, pair.value(), opportunity.value());
            REQUIRE(margin);
            const std::uint64_t fixed0 =
                (((out_mask >> 1U) & 1U) * q1) +
                (((out_mask >> 2U) & 1U) * q2);
            const std::uint64_t fixed1 =
                (((in_mask >> 1U) & 1U) * q1) +
                (((in_mask >> 2U) & 1U) * q2);
            CHECK(margin.value().fixed_out_objective() ==
                  mwperf::BigNat(fixed0));
            CHECK(margin.value().fixed_in_objective() ==
                  mwperf::BigNat(fixed1));
            CHECK(margin.value().regret0() ==
                  mwperf::BigNat(oracle0 - fixed0));
            CHECK(margin.value().regret1() ==
                  mwperf::BigNat(oracle1 - fixed1));
            CHECK(margin.value().pair_valid() ==
                  (fixed0 == oracle0 && fixed1 == oracle1));
            CHECK(margin.value().old_pair_linear_coordinate() +
                      margin.value().regret1().value() -
                      margin.value().regret0().value() ==
                  opportunity.value().margin());
          }
        }
      }
    }
  }

  for (std::uint64_t r0 = 0U; r0 <= 2U; ++r0) {
    for (std::uint64_t r1 = 0U; r1 <= 2U; ++r1) {
      for (std::uint64_t r2 = 0U; r2 <= 2U; ++r2) {
        if (r0 == 0U && r1 == 0U && r2 == 0U) {
          continue;
        }
        std::uint64_t oracle = 0U;
        for (std::uint8_t mask = 0U; mask < 8U; ++mask) {
          if (!feasible(mask)) {
            continue;
          }
          oracle = std::max(
              oracle, ((mask & 1U) * r0) +
                          (((mask >> 1U) & 1U) * r1) +
                          (((mask >> 2U) & 1U) * r2));
        }
        auto context = optimizer_context(fixture.instance,
                                         mwperf::BigNat(1U));
        auto capacity = mwperf::compute_resource_capacity(
            fixture.instance,
            make_direction(fixture,
                           {mwperf::BigNat(r0), mwperf::BigNat(r1),
                            mwperf::BigNat(r2)}),
            context);
        CAPTURE(r0, r1, r2);
        REQUIRE(capacity);
        CHECK(capacity.value() == mwperf::BigNat(oracle));
        CHECK(context.ledger_snapshot().calls_reserved() ==
              mwperf::BigNat(1U));
      }
    }
  }
}

TEST_CASE("C13 resource capacity and physical-edge recursions are exact",
          "[c13][unit]") {
  const nlohmann::json golden = golden_cases().at("resource_edge");
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"1", "2"},
      R"json([{"slot":0,"queue_id":"q0","count":4},{"slot":0,"queue_id":"q1","count":1}])json");
  const mwperf::NonnegativeIntegralDirection direction = make_direction(
      fixture, {mwperf::BigNat(2U), mwperf::BigNat(3U)});
  auto capacity_context = optimizer_context(fixture.instance);
  auto capacity = mwperf::compute_resource_capacity(
      fixture.instance, direction, capacity_context);
  REQUIRE(capacity);
  CHECK(capacity.value() == mwperf::BigNat(3U));
  CHECK(capacity_context.ledger_snapshot().calls_reserved() ==
        mwperf::BigNat(1U));

  auto coordinate = mwperf::ResourceCoordinate::make(
      direction, capacity.value(), mwperf::BigNat(8U), mwperf::BigNat(0U),
      mwperf::BigNat(1U), true);
  REQUIRE(coordinate);
  auto state = mwperf::ResourceState::from_coordinates(
      {std::move(coordinate).value()});
  REQUIRE(state);
  const mwperf::ResourceState before = state.value();
  const mwperf::PhysicalPath path = run_path(fixture, 1U);
  REQUIRE(path.edges().size() == 1U);
  const mwperf::PhysicalEdge& edge = path.edges()[0U];
  CHECK(bits(edge.departure()) ==
        golden.at("departure").get<std::vector<std::uint8_t>>());

  auto updated = mwperf::update_resource_coordinates(
      state.value(), edge.departure(), edge.arrival_step().batch);
  REQUIRE(updated);
  REQUIRE(updated.value().coordinates().size() == 1U);
  const mwperf::ResourceCoordinate& next = updated.value().coordinates()[0U];
  CHECK(next.workload().to_decimal_string() ==
        golden.at("next_workload").get<std::string>());
  CHECK(next.unused_capacity().to_decimal_string() ==
        golden.at("unused_capacity").get<std::string>());
  CHECK(next.lower_queue().to_decimal_string() ==
        golden.at("next_lower").get<std::string>());
  CHECK(state.value() == before);

  const mwperf::NonnegativeIntegralDirection scaled = make_direction(
      fixture, {mwperf::BigNat(14U), mwperf::BigNat(21U)});
  auto scaled_capacity_context = optimizer_context(fixture.instance);
  auto scaled_capacity = mwperf::compute_resource_capacity(
      fixture.instance, scaled, scaled_capacity_context);
  REQUIRE(scaled_capacity);
  CHECK(scaled_capacity.value() == mwperf::BigNat(21U));
}

TEST_CASE("C13 resource update is transactional across coordinates",
          "[c13][negative]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"1", "1"});
  auto first = mwperf::ResourceCoordinate::make(
      make_direction(fixture, {mwperf::BigNat(1U), mwperf::BigNat(1U)}),
      mwperf::BigNat(1U), mwperf::BigNat(2U), mwperf::BigNat(0U),
      mwperf::BigNat(0U), true);
  auto second = mwperf::ResourceCoordinate::make(
      make_direction(fixture, {mwperf::BigNat(0U), mwperf::BigNat(1U)}),
      mwperf::BigNat(1U), mwperf::BigNat(0U), mwperf::BigNat(0U),
      mwperf::BigNat(0U), true);
  REQUIRE(first);
  REQUIRE(second);
  auto state = mwperf::ResourceState::from_coordinates(
      {std::move(first).value(), std::move(second).value()});
  REQUIRE(state);
  const mwperf::ResourceState before = state.value();
  auto failed = mwperf::update_resource_coordinates(
      state.value(), make_schedule(fixture, {0U, 1U}),
      mwperf::ArrivalBatch::empty());
  REQUIRE_FALSE(failed);
  CHECK(failed.error().code == "resource_service_exceeds_workload");
  CHECK(state.value() == before);

  auto zero = mwperf::NonnegativeIntegralDirection::from_values(
      mwperf::QueueDimensionToken::from_instance(fixture.instance),
      {mwperf::BigNat(0U), mwperf::BigNat(0U)});
  REQUIRE_FALSE(zero);
  CHECK(zero.error().code == "resource_direction_zero");
}

TEST_CASE("C13 rational support clears denominators once and reads back",
          "[c13][unit]") {
  const nlohmann::json golden = golden_cases().at("rational_support");
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"0", "0", "0"});
  const mwperf::ExactNonnegativeRationalWeights weights = make_weights(
      fixture, {rational(2, 3), rational(5, 4), rational(7, 6)});
  auto context = optimizer_context(fixture.instance);
  auto certificate = mwperf::compute_rational_support(
      fixture.instance, weights, context);
  REQUIRE(certificate);
  CHECK(certificate.value().clearing_denominator().to_decimal_string() ==
        golden.at("clearing_denominator").get<std::string>());
  CHECK(values(certificate.value().cleared_integral_weights().values()) ==
        std::vector<mwperf::BigNat>{mwperf::BigNat(8U), mwperf::BigNat(15U),
                                    mwperf::BigNat(14U)});
  CHECK(bits(certificate.value().selected_witness()) ==
        golden.at("witness").get<std::vector<std::uint8_t>>());
  CHECK(certificate.value().support_value().to_canonical_string() ==
        golden.at("support").get<std::string>());
  CHECK(context.ledger_snapshot().calls_reserved() == mwperf::BigNat(1U));
  CHECK(certificate.value().combined_input_identity() ==
        fixture.instance.fingerprints().combined);
  CHECK(certificate.value().family() ==
        mwperf::ServiceFamily::pairwise_conflicts);

  const mwperf::ExactNonnegativeRationalWeights scaled = make_weights(
      fixture, {rational(10, 21), rational(25, 28), rational(5, 6)});
  auto scaled_context = optimizer_context(fixture.instance);
  auto scaled_certificate = mwperf::compute_rational_support(
      fixture.instance, scaled, scaled_context);
  REQUIRE(scaled_certificate);
  CHECK(scaled_certificate.value().support_value() == rational(55, 42));
  CHECK(bits(scaled_certificate.value().selected_witness()) ==
        bits(certificate.value().selected_witness()));
}

TEST_CASE("C13 rational support honors priority ties and representation budgets",
          "[c13][negative]") {
  const std::string scheduler =
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json";
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"}, scheduler, {"0", "0", "0"});

  SECTION("equal support uses only the configured complete priority") {
    const auto weights = make_weights(
        fixture, {rational(2, 3), rational(4, 3), rational(2, 3)});
    auto context = optimizer_context(fixture.instance);
    auto certificate = mwperf::compute_rational_support(
        fixture.instance, weights, context);
    REQUIRE(certificate);
    CHECK(certificate.value().support_value() == rational(4, 3));
    CHECK(bits(certificate.value().selected_witness()) ==
          std::vector<std::uint8_t>{1U, 0U, 1U});

    const ReductionFixture reversed = make_fixture(
        {"q0", "q1", "q2"},
        R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q1","q0","q2"],"max_search_states":null}})json",
        {"0", "0", "0"});
    auto reversed_context = optimizer_context(reversed.instance);
    auto reversed_certificate = mwperf::compute_rational_support(
        reversed.instance,
        make_weights(reversed,
                     {rational(2, 3), rational(4, 3), rational(2, 3)}),
        reversed_context);
    REQUIRE(reversed_certificate);
    CHECK(reversed_certificate.value().support_value() == rational(4, 3));
    CHECK(bits(reversed_certificate.value().selected_witness()) ==
          std::vector<std::uint8_t>{0U, 1U, 0U});
  }

  SECTION("operational budgets do not alter rational-vector identity") {
    const auto unbounded = make_weights(
        fixture, {rational(2, 3), rational(5, 4), rational(7, 6)});
    const mwperf::RationalSupportRepresentationBudget finite_budget{
        .maximum_clearing_denominator_bits = 64U,
        .maximum_cleared_weight_bits = 32U,
    };
    const auto bounded = make_weights(
        fixture, {rational(2, 3), rational(5, 4), rational(7, 6)},
        finite_budget);
    CHECK(unbounded.identity_digest() == bounded.identity_digest());
    CHECK(unbounded == bounded);
    CHECK(unbounded.representation_budget() ==
          mwperf::RationalSupportRepresentationBudget::unbounded());
    CHECK(bounded.representation_budget() == finite_budget);
  }

  SECTION("LCM failure happens before an optimizer call") {
    mwperf::BigInt two_to_40 = 1;
    mwperf::BigInt three_to_40 = 1;
    two_to_40 <<= 40U;
    for (std::size_t index = 0U; index < 40U; ++index) {
      three_to_40 *= 3;
    }
    auto first = mwperf::ExactRational::make(1, two_to_40);
    auto second = mwperf::ExactRational::make(1, three_to_40);
    REQUIRE(first);
    REQUIRE(second);
    const mwperf::RationalSupportRepresentationBudget budget{
        .maximum_clearing_denominator_bits = 64U,
        .maximum_cleared_weight_bits = std::nullopt,
    };
    const auto weights = make_weights(
        fixture,
        {std::move(first).value(), std::move(second).value(),
         mwperf::ExactRational::zero()},
        budget);
    auto context = optimizer_context(fixture.instance);
    auto failed = mwperf::compute_rational_support(
        fixture.instance, weights, context);
    REQUIRE_FALSE(failed);
    CHECK(failed.error().code ==
          "rational_support_clearing_denominator_budget_exceeded");
    CHECK(context.ledger_snapshot().calls_reserved().is_zero());
  }

  SECTION("negative rational weights are rejected by their typed boundary") {
    auto invalid = mwperf::ExactNonnegativeRationalWeights::from_values(
        mwperf::QueueDimensionToken::from_instance(fixture.instance),
        {rational(-1, 3), rational(0, 1), rational(0, 1)},
        mwperf::RationalSupportRepresentationBudget::unbounded());
    REQUIRE_FALSE(invalid);
    CHECK(invalid.error().code == "rational_support_negative_weight");
  }

  SECTION("unbounded clearing remains exact beyond 128 bits") {
    mwperf::BigInt two_to_70 = 1;
    mwperf::BigInt three_to_50 = 1;
    two_to_70 <<= 70U;
    for (std::size_t index = 0U; index < 50U; ++index) {
      three_to_50 *= 3;
    }
    auto first = mwperf::ExactRational::make(1, two_to_70);
    auto last = mwperf::ExactRational::make(1, three_to_50);
    REQUIRE(first);
    REQUIRE(last);
    const mwperf::ExactRational expected_support =
        first.value() + last.value();
    const auto weights = make_weights(
        fixture, {first.value(), mwperf::ExactRational::zero(), last.value()});
    auto context = optimizer_context(fixture.instance);
    auto certificate = mwperf::compute_rational_support(
        fixture.instance, weights, context);
    REQUIRE(certificate);
    CHECK(certificate.value().clearing_denominator().value() ==
          two_to_70 * three_to_50);
    CHECK(certificate.value().clearing_denominator().bit_length() > 128U);
    CHECK(certificate.value().cleared_integral_weights().values()[0U].value() ==
          three_to_50);
    CHECK(certificate.value().cleared_integral_weights().values()[1U].is_zero());
    CHECK(certificate.value().cleared_integral_weights().values()[2U].value() ==
          two_to_70);
    CHECK(bits(certificate.value().selected_witness()) ==
          std::vector<std::uint8_t>{1U, 0U, 1U});
    CHECK(certificate.value().support_value() == expected_support);
  }
}

TEST_CASE("C13 isolated target and zero rational support retain algebraic evidence",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0"},
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[]},"priority":["q0"],"max_search_states":null}})json",
      {"0"});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, make_backlog(fixture, {mwperf::BigNat(0U)}),
      target(fixture), opportunity_context);
  REQUIRE(opportunity);
  CHECK(opportunity.value().psi0().is_zero());
  CHECK(opportunity.value().psi1().is_zero());
  CHECK(opportunity.value().theta().is_zero());
  CHECK(opportunity.value().margin() == mwperf::BigInt(0));
  const mwperf::TargetClass zero_class = mwperf::classify_target_decision(
      opportunity.value(), mwperf::TargetBacklog(mwperf::BigNat(0U)));
  CHECK(zero_class.algebraic_class == mwperf::AlgebraicTargetClass::tie);
  CHECK_FALSE(zero_class.eligible);
  const mwperf::TargetClass positive_class = mwperf::classify_target_decision(
      opportunity.value(), mwperf::TargetBacklog(mwperf::BigNat(7U)));
  CHECK(positive_class.algebraic_class ==
        mwperf::AlgebraicTargetClass::forced_in);
  CHECK(positive_class.algebraic_margin == mwperf::BigInt(7));
  CHECK(positive_class.eligible);

  const auto zero_weights = make_weights(
      fixture, {mwperf::ExactRational::zero()});
  auto support_context = optimizer_context(fixture.instance);
  auto support = mwperf::compute_rational_support(
      fixture.instance, zero_weights, support_context);
  REQUIRE(support);
  CHECK(support.value().clearing_denominator() == mwperf::BigNat(1U));
  CHECK(support.value().cleared_integral_weights().values()[0U].is_zero());
  CHECK(support.value().support_value() == mwperf::ExactRational::zero());
  CHECK(support_context.ledger_snapshot().calls_reserved() ==
        mwperf::BigNat(1U));
}

TEST_CASE("C13 local margin follows the old pair inside its cell",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"8", "3"},
      R"json([{"slot":0,"queue_id":"q1","count":1}])json");
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(8U), mwperf::BigNat(3U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(fixture, {0U, 1U}),
      make_schedule(fixture, {1U, 0U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  CHECK(margin.value().pair_valid());
  CHECK(margin.value().old_pair_linear_coordinate() == mwperf::BigInt(5));
  CHECK(margin.value().reoptimized_margin() == mwperf::BigInt(5));
  CHECK(margin.value().regret0().is_zero());
  CHECK(margin.value().regret1().is_zero());

  const mwperf::PhysicalPath path = run_path(fixture, 1U, 17U);
  REQUIRE(path.edges().size() == 1U);
  auto transition_context = optimizer_context(fixture.instance);
  auto transition = mwperf::update_or_reoptimize_margin(
      margin.value(), path.edges()[0U], fixture.instance,
      transition_context);
  REQUIRE(transition);
  CHECK(transition.value().old_pair_increment() == mwperf::BigInt(-2));
  CHECK(transition.value().old_linear_next() == mwperf::BigInt(3));
  CHECK(transition.value().reoptimized_next() == mwperf::BigInt(3));
  CHECK(transition.value().signed_exit_correction() == mwperf::BigInt(0));
  CHECK(transition.value().next_pair_valid());
  CHECK(transition.value().used_linear_endpoint());
  CHECK_FALSE(transition.value().pair_cell_exit());
  CHECK_FALSE(transition.value().representative_mismatch());
  CHECK(transition.value().reoptimization_performed());
  CHECK(transition_context.ledger_snapshot().calls_reserved() ==
        mwperf::BigNat(2U));

  const mwperf::Opportunity& successor =
      transition.value().successor_opportunity();
  CHECK(successor.evaluation_backlog() ==
        transition.value().next().evaluation_backlog());
  CHECK(successor.target() == transition.value().next().pair().target());
  CHECK(successor.margin() ==
        transition.value().next().reoptimized_margin());
  CHECK(successor.certificate_digest() ==
        transition.value().next().opportunity_certificate_digest());
  const mwperf::SearchAccounting& forced_zero =
      successor.forced_out_certificate().accounting;
  const mwperf::SearchAccounting& forced_one =
      successor.forced_in_certificate().accounting;
  CHECK(forced_zero.query_kind() == mwperf::OptimizerQueryKind::forced_zero);
  CHECK(forced_one.query_kind() == mwperf::OptimizerQueryKind::forced_one);
  CHECK(forced_zero.call_ordinal() == mwperf::BigNat(1U));
  CHECK(forced_one.call_ordinal() == mwperf::BigNat(2U));
  REQUIRE(forced_zero.target().has_value());
  REQUIRE(forced_one.target().has_value());
  CHECK(*forced_zero.target() == transition.value().next().pair().target());
  CHECK(*forced_one.target() == transition.value().next().pair().target());
  CHECK_FALSE(forced_zero.exhausted());
  CHECK_FALSE(forced_one.exhausted());
}

TEST_CASE("C13 corrected margin exits a stale schedule-pair cell exactly",
          "[c13][property]") {
  const nlohmann::json golden = golden_cases().at("margin_exit");
  for (const nlohmann::json& branch : golden.at("branches")) {
    const bool exiting =
        branch.at("correction").get<std::string>() != "0";
    const std::string events = exiting
        ? R"json([{"slot":0,"queue_id":"q0","count":2},{"slot":0,"queue_id":"q2","count":4}])json"
        : "[]";
    const ReductionFixture fixture = make_fixture(
        {"q0", "q1", "q2"}, clique_scheduler(R"json(["q0","q1","q2"])json"),
        {"10", "9", "8"}, events);
    const mwperf::Backlog pre = make_backlog(
        fixture, {mwperf::BigNat(10U), mwperf::BigNat(9U),
                  mwperf::BigNat(8U)});
    auto opportunity_context = optimizer_context(fixture.instance);
    auto opportunity = mwperf::compute_target_opportunity(
        fixture.instance, pre, target(fixture), opportunity_context);
    REQUIRE(opportunity);
    auto pair = mwperf::SchedulePair::make(
        fixture.instance, target(fixture),
        make_schedule(fixture, {0U, 1U, 0U}),
        make_schedule(fixture, {1U, 0U, 0U}));
    REQUIRE(pair);
    auto margin = mwperf::evaluate_margin_pair(
        pre, pair.value(), opportunity.value());
    REQUIRE(margin);
    REQUIRE(margin.value().pair_valid());
    CHECK(margin.value().reoptimized_margin() == mwperf::BigInt(1));

    const mwperf::PhysicalPath path = run_path(fixture, 1U, 313U);
    REQUIRE(path.edges().size() == 1U);
    auto transition_context = optimizer_context(fixture.instance);
    auto transition = mwperf::update_or_reoptimize_margin(
        margin.value(), path.edges()[0U], fixture.instance,
        transition_context);
    REQUIRE(transition);
    CHECK(transition.value().old_pair_increment() ==
          decimal_int(branch.at("old_increment")));
    CHECK(transition.value().old_linear_next() ==
          decimal_int(branch.at("old_linear_next")));
    CHECK(transition.value().reoptimized_next() ==
          decimal_int(branch.at("reoptimized_next")));
    CHECK(transition.value().a0().value() == decimal_int(branch.at("a0")));
    CHECK(transition.value().a1().value() == decimal_int(branch.at("a1")));
    CHECK(transition.value().signed_exit_correction() ==
          decimal_int(branch.at("correction")));
    CHECK(transition.value().pair_cell_exit() == exiting);
    CHECK(transition.value().next_pair_valid() == !exiting);
    CHECK(transition.value().used_linear_endpoint() == !exiting);
    CHECK(transition.value().reoptimization_performed());
    CHECK(transition.value().reoptimized_next() -
              transition.value().previous().reoptimized_margin() ==
          decimal_int(branch.at("reoptimized_increment")));
  }
}

TEST_CASE("C13 detects representative mismatch without confusing cell exit",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"10", "5", "5"});
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(10U), mwperf::BigNat(5U),
                mwperf::BigNat(5U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture),
      make_schedule(fixture, {0U, 1U, 1U}),
      make_schedule(fixture, {1U, 0U, 1U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  REQUIRE(margin.value().pair_valid());
  CHECK(margin.value().reoptimized_margin() == mwperf::BigInt(5));

  const mwperf::PhysicalPath path = run_path(fixture, 1U, 99U);
  REQUIRE(path.edges().size() == 1U);
  CHECK(bits(path.edges()[0U].departure()) ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  auto transition_context = optimizer_context(fixture.instance);
  auto transition = mwperf::update_or_reoptimize_margin(
      margin.value(), path.edges()[0U], fixture.instance,
      transition_context);
  REQUIRE(transition);
  CHECK(transition.value().representative_mismatch());
  CHECK_FALSE(transition.value().pair_cell_exit());
  CHECK(transition.value().next_pair_valid());
  CHECK(transition.value().old_linear_next() == mwperf::BigInt(5));
  CHECK(transition.value().reoptimized_next() == mwperf::BigInt(5));
}

TEST_CASE("C13 cross-class tie uses the physical departure in margin recursion",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"resource_packing_max_weight","params":{"constraint":{"resources":["r"],"capacity":[2],"demands":[{"queue_id":"q0","demand":[1]},{"queue_id":"q1","demand":[1]},{"queue_id":"q2","demand":[1]}]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"5", "5", "5"});
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(5U), mwperf::BigNat(5U),
                mwperf::BigNat(5U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  REQUIRE(opportunity.value().margin() == mwperf::BigInt(0));
  REQUIRE(opportunity.value().cross_class_outcome().algebraic_class ==
          mwperf::AlgebraicTargetClass::tie);

  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture),
      make_schedule(fixture, {0U, 1U, 1U}),
      make_schedule(fixture, {1U, 0U, 1U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  REQUIRE(margin.value().pair_valid());

  const mwperf::PhysicalPath path = run_path(fixture, 1U, 1500U);
  REQUIRE(path.edges().size() == 1U);
  const mwperf::PhysicalEdge& edge = path.edges()[0U];
  CHECK(bits(edge.departure()) ==
        std::vector<std::uint8_t>{1U, 1U, 0U});
  CHECK(bits(edge.departure()) !=
        bits(pair.value().forced_out_representative()));
  CHECK(bits(edge.departure()) !=
        bits(pair.value().forced_in_representative()));

  auto transition_context = optimizer_context(fixture.instance);
  auto transition = mwperf::update_or_reoptimize_margin(
      margin.value(), edge, fixture.instance, transition_context);
  REQUIRE(transition);
  // c=(1,-1,0). The actual tied departure has c.D=0; assuming s0 or s1
  // would instead produce increments +1 or -1.
  CHECK(transition.value().old_pair_increment() == mwperf::BigInt(0));
  CHECK(transition.value().old_pair_increment() != mwperf::BigInt(1));
  CHECK(transition.value().old_pair_increment() != mwperf::BigInt(-1));
  CHECK(transition.value().old_linear_next() == mwperf::BigInt(0));
  CHECK(transition.value().reoptimized_next() == mwperf::BigInt(0));
  CHECK_FALSE(transition.value().representative_mismatch());
  CHECK_FALSE(transition.value().pair_cell_exit());
  CHECK(transition.value().next_pair_valid());
}

TEST_CASE("C13 failed successor reoptimization publishes no transition",
          "[c13][negative]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"8", "3"},
      R"json([{"slot":0,"queue_id":"q1","count":1}])json");
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(8U), mwperf::BigNat(3U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(fixture, {0U, 1U}),
      make_schedule(fixture, {1U, 0U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  const mwperf::BigInt before_linear =
      margin.value().old_pair_linear_coordinate();
  const mwperf::BigInt before_reoptimized =
      margin.value().reoptimized_margin();
  const mwperf::PhysicalPath path = run_path(fixture, 1U, 181U);
  REQUIRE(path.edges().size() == 1U);

  auto one_call = optimizer_context(fixture.instance, mwperf::BigNat(1U));
  auto failed = mwperf::update_or_reoptimize_margin(
      margin.value(), path.edges()[0U], fixture.instance, one_call);
  REQUIRE_FALSE(failed);
  CHECK(failed.error().code == "optimizer_call_limit_exhausted");
  CHECK(one_call.ledger_snapshot().calls_reserved() == mwperf::BigNat(1U));
  CHECK(margin.value().old_pair_linear_coordinate() == before_linear);
  CHECK(margin.value().reoptimized_margin() == before_reoptimized);
}

TEST_CASE("C13 margin recursion remains algebraic at an empty target",
          "[c13][property]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"}, clique_scheduler(R"json(["q0","q1","q2"])json"),
      {"0", "5", "4"},
      R"json([{"slot":0,"queue_id":"q2","count":10}])json");
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(0U), mwperf::BigNat(5U),
                mwperf::BigNat(4U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  CHECK(opportunity.value().margin() == mwperf::BigInt(-5));
  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture),
      make_schedule(fixture, {0U, 1U, 0U}),
      make_schedule(fixture, {1U, 0U, 0U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  REQUIRE(margin.value().pair_valid());
  CHECK_FALSE(margin.value().target_eligible());

  const mwperf::PhysicalPath path = run_path(fixture, 1U, 1300U);
  REQUIRE(path.edges().size() == 1U);
  CHECK(bits(path.edges()[0U].departure()) ==
        std::vector<std::uint8_t>{0U, 1U, 0U});
  CHECK(path.edges()[0U].departure().bytes()[0U] == 0U);
  auto transition_context = optimizer_context(fixture.instance);
  auto transition = mwperf::update_or_reoptimize_margin(
      margin.value(), path.edges()[0U], fixture.instance,
      transition_context);
  REQUIRE(transition);
  CHECK(transition.value().old_pair_increment() == mwperf::BigInt(1));
  CHECK(transition.value().old_linear_next() == mwperf::BigInt(-4));
  CHECK(transition.value().a0() == mwperf::BigNat(10U));
  CHECK(transition.value().a1().is_zero());
  CHECK(transition.value().signed_exit_correction() == mwperf::BigInt(-10));
  CHECK(transition.value().reoptimized_next() == mwperf::BigInt(-14));
  CHECK_FALSE(transition.value().pair_cell_exit());
  CHECK_FALSE(transition.value().next_pair_valid());
  CHECK_FALSE(transition.value().target_became_ineligible());
  CHECK_FALSE(transition.value().representative_mismatch());
  CHECK(transition_context.ledger_snapshot().calls_reserved() ==
        mwperf::BigNat(2U));
}

TEST_CASE("C13 eligibility loss emits edge-triggered margin metadata",
          "[c13][unit]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"1", "0"});
  const mwperf::Backlog pre = make_backlog(
      fixture, {mwperf::BigNat(1U), mwperf::BigNat(0U)});
  auto opportunity_context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, pre, target(fixture), opportunity_context);
  REQUIRE(opportunity);
  auto pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(fixture, {0U, 1U}),
      make_schedule(fixture, {1U, 0U}));
  REQUIRE(pair);
  auto margin = mwperf::evaluate_margin_pair(
      pre, pair.value(), opportunity.value());
  REQUIRE(margin);
  REQUIRE(margin.value().pair_valid());
  REQUIRE(margin.value().target_eligible());

  const mwperf::PhysicalPath path = run_path(fixture, 1U, 1301U);
  REQUIRE(path.edges().size() == 1U);
  CHECK(bits(path.edges()[0U].departure()) ==
        std::vector<std::uint8_t>{1U, 0U});
  CHECK(path.edges()[0U].post_state().backlog().values()[0U].is_zero());
  auto transition_context = optimizer_context(fixture.instance);
  auto transition = mwperf::update_or_reoptimize_margin(
      margin.value(), path.edges()[0U], fixture.instance,
      transition_context);
  REQUIRE(transition);
  CHECK(transition.value().old_pair_increment() == mwperf::BigInt(-1));
  CHECK(transition.value().old_linear_next() == mwperf::BigInt(0));
  CHECK(transition.value().reoptimized_next() == mwperf::BigInt(0));
  CHECK(transition.value().signed_exit_correction() == mwperf::BigInt(0));
  CHECK(transition.value().target_became_ineligible());
  CHECK(transition.value().pair_cell_exit());
  CHECK(transition.value().next_pair_valid());
  CHECK_FALSE(transition.value().representative_mismatch());
}

TEST_CASE("C13 exact queries reject identities before reserving a call",
          "[c13][negative]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"3", "5"});
  const ReductionFixture foreign = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"3", "5"},
      R"json([{"slot":7,"queue_id":"q0","count":1}])json");
  const mwperf::Backlog foreign_backlog = make_backlog(
      foreign, {mwperf::BigNat(3U), mwperf::BigNat(5U)});
  auto context = optimizer_context(fixture.instance);
  auto bad_opportunity = mwperf::compute_target_opportunity(
      fixture.instance, foreign_backlog, target(foreign), context);
  REQUIRE_FALSE(bad_opportunity);
  CHECK(bad_opportunity.error().code ==
        "opportunity_instance_identity_mismatch");
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());

  const auto foreign_direction = make_direction(
      foreign, {mwperf::BigNat(2U), mwperf::BigNat(3U)});
  auto bad_capacity = mwperf::compute_resource_capacity(
      fixture.instance, foreign_direction, context);
  REQUIRE_FALSE(bad_capacity);
  CHECK(bad_capacity.error().code ==
        "resource_capacity_instance_identity_mismatch");
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());

  const auto foreign_weights = make_weights(
      foreign, {rational(1, 2), rational(1, 3)});
  auto bad_support = mwperf::compute_rational_support(
      fixture.instance, foreign_weights, context);
  REQUIRE_FALSE(bad_support);
  CHECK(bad_support.error().code ==
        "rational_support_instance_identity_mismatch");
  CHECK(context.ledger_snapshot().calls_reserved().is_zero());

  auto one_call = optimizer_context(fixture.instance, mwperf::BigNat(1U));
  auto partial = mwperf::compute_target_opportunity(
      fixture.instance,
      make_backlog(fixture, {mwperf::BigNat(3U), mwperf::BigNat(5U)}),
      target(fixture), one_call);
  REQUIRE_FALSE(partial);
  CHECK(partial.error().code == "optimizer_call_limit_exhausted");
  CHECK(one_call.ledger_snapshot().calls_reserved() == mwperf::BigNat(1U));

  auto no_capacity_calls =
      optimizer_context(fixture.instance, mwperf::BigNat(0U));
  auto no_capacity = mwperf::compute_resource_capacity(
      fixture.instance,
      make_direction(fixture, {mwperf::BigNat(2U), mwperf::BigNat(3U)}),
      no_capacity_calls);
  REQUIRE_FALSE(no_capacity);
  CHECK(no_capacity.error().code == "optimizer_call_limit_exhausted");
  CHECK(no_capacity_calls.ledger_snapshot().calls_reserved().is_zero());

  auto no_support_calls =
      optimizer_context(fixture.instance, mwperf::BigNat(0U));
  auto no_support = mwperf::compute_rational_support(
      fixture.instance,
      make_weights(fixture, {rational(1, 2), rational(1, 3)}),
      no_support_calls);
  REQUIRE_FALSE(no_support);
  CHECK(no_support.error().code == "optimizer_call_limit_exhausted");
  CHECK(no_support_calls.ledger_snapshot().calls_reserved().is_zero());
}

TEST_CASE("C13 schedule pairs and opportunity certificates cannot be crossed",
          "[c13][negative]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"3", "5", "3"});
  const mwperf::Backlog backlog = make_backlog(
      fixture, {mwperf::BigNat(3U), mwperf::BigNat(5U),
                mwperf::BigNat(3U)});
  auto context = optimizer_context(fixture.instance);
  auto opportunity = mwperf::compute_target_opportunity(
      fixture.instance, backlog, target(fixture), context);
  REQUIRE(opportunity);

  auto invalid_bits = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(fixture, {1U, 0U, 0U}),
      make_schedule(fixture, {1U, 0U, 0U}));
  REQUIRE_FALSE(invalid_bits);
  CHECK(invalid_bits.error().code == "schedule_pair_target_bits_invalid");

  auto infeasible = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(fixture, {0U, 1U, 1U}),
      make_schedule(fixture, {1U, 0U, 0U}));
  REQUIRE_FALSE(infeasible);
  CHECK(infeasible.error().code == "schedule_pair_endpoint_infeasible");

  const ReductionFixture foreign = make_fixture(
      {"q0", "q1", "q2"},
      R"json({"name":"conflict_graph_max_weight","params":{"constraint":{"conflicts":[["q0","q1"],["q1","q2"]]},"priority":["q0","q1","q2"],"max_search_states":null}})json",
      {"3", "5", "3"},
      R"json([{"slot":9,"queue_id":"q2","count":1}])json");
  auto wrong_dimension = mwperf::SchedulePair::make(
      fixture.instance, target(fixture), make_schedule(foreign, {0U, 1U, 0U}),
      make_schedule(fixture, {1U, 0U, 0U}));
  REQUIRE_FALSE(wrong_dimension);
  CHECK(wrong_dimension.error().code ==
        "schedule_pair_dimension_identity_mismatch");

  auto valid_pair = mwperf::SchedulePair::make(
      fixture.instance, target(fixture),
      opportunity.value().forced_out_certificate().witness,
      opportunity.value().forced_in_certificate().witness);
  REQUIRE(valid_pair);
  auto wrong_backlog = mwperf::evaluate_margin_pair(
      make_backlog(fixture, {mwperf::BigNat(4U), mwperf::BigNat(5U),
                             mwperf::BigNat(3U)}),
      valid_pair.value(), opportunity.value());
  REQUIRE_FALSE(wrong_backlog);
  CHECK(wrong_backlog.error().code == "margin_opportunity_backlog_mismatch");

  auto target_one = mwperf::TargetIndex::from_instance(fixture.instance, 1U);
  REQUIRE(target_one);
  auto other_pair = mwperf::SchedulePair::make(
      fixture.instance, target_one.value(),
      make_schedule(fixture, {1U, 0U, 1U}),
      make_schedule(fixture, {0U, 1U, 0U}));
  REQUIRE(other_pair);
  auto wrong_target = mwperf::evaluate_margin_pair(
      backlog, other_pair.value(), opportunity.value());
  REQUIRE_FALSE(wrong_target);
  CHECK(wrong_target.error().code == "margin_opportunity_target_mismatch");
}

TEST_CASE("C13 construction facade enforces its 2/1/1 local subgrant",
          "[c13][integration]") {
  const ReductionFixture fixture = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"3", "5"});
  const ReductionFixture foreign = make_fixture(
      {"q0", "q1"}, two_queue_clique_scheduler(), {"3", "5"},
      R"json([{"slot":7,"queue_id":"q0","count":1}])json");
  auto construction_context =
      optimizer_context(fixture.instance, mwperf::BigNat(8U));
  auto deployed_context = optimizer_context(fixture.instance);
  const auto deployed_before = deployed_context.ledger_snapshot();
  const mwperf::BuildIdentityDigest build_identity(
      fixture.instance.fingerprints().combined);
  auto services_result = mwperf::testing::C13ConstructionServiceAccess::bind(
      fixture.instance, build_identity, construction_context,
      mwperf::BigNat(4U));
  REQUIRE(services_result);
  mwperf::ConstructionExactQueryServices services =
      std::move(services_result).value();
  const mwperf::ConstructionScopeToken scope = services.scope_token();
  const mwperf::Backlog backlog = make_backlog(
      fixture, {mwperf::BigNat(3U), mwperf::BigNat(5U)});
  const auto direction = make_direction(
      fixture, {mwperf::BigNat(2U), mwperf::BigNat(3U)});
  const auto weights = make_weights(
      fixture, {rational(2, 3), rational(5, 4)});

  auto opportunity = services.query_opportunity(
      scope, backlog, target(fixture));
  REQUIRE(opportunity);
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(2U));
  auto capacity = services.query_integral_capacity(scope, direction);
  REQUIRE(capacity);
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(3U));
  auto support = services.query_rational_support(scope, weights);
  REQUIRE(support);
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(4U));
  CHECK(deployed_context.ledger_snapshot() == deployed_before);

  auto exhausted = services.query_integral_capacity(scope, direction);
  REQUIRE_FALSE(exhausted);
  CHECK(exhausted.error().code == "construction_call_subgrant_exhausted");
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(4U));

  const mwperf::ConstructionScopeToken wrong_scope =
      mwperf::testing::C13ConstructionServiceAccess::mutated_token(
          services, mwperf::testing::ConstructionTokenMutation::scope);
  auto scope_failure = services.query_integral_capacity(wrong_scope, direction);
  REQUIRE_FALSE(scope_failure);
  CHECK(scope_failure.error().code == "construction_scope_token_mismatch");
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(4U));

  const mwperf::ConstructionScopeToken wrong_instance =
      mwperf::testing::C13ConstructionServiceAccess::mutated_token(
          services, mwperf::testing::ConstructionTokenMutation::instance,
          &foreign.instance);
  auto instance_failure =
      services.query_integral_capacity(wrong_instance, direction);
  REQUIRE_FALSE(instance_failure);
  CHECK(instance_failure.error().code ==
        "construction_instance_identity_mismatch");
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(4U));

  const mwperf::ConstructionScopeToken wrong_tie =
      mwperf::testing::C13ConstructionServiceAccess::mutated_token(
          services, mwperf::testing::ConstructionTokenMutation::tie);
  auto tie_failure = services.query_integral_capacity(wrong_tie, direction);
  REQUIRE_FALSE(tie_failure);
  CHECK(tie_failure.error().code == "construction_tie_identity_mismatch");
  CHECK(services.ledger_snapshot().calls_reserved() == mwperf::BigNat(4U));

  auto repeat_context =
      optimizer_context(fixture.instance, mwperf::BigNat(4U));
  auto repeat_services_result =
      mwperf::testing::C13ConstructionServiceAccess::bind(
          fixture.instance, build_identity, repeat_context,
          mwperf::BigNat(2U));
  REQUIRE(repeat_services_result);
  mwperf::ConstructionExactQueryServices repeat_services =
      std::move(repeat_services_result).value();
  const mwperf::ConstructionScopeToken repeat_scope =
      repeat_services.scope_token();
  REQUIRE(repeat_services.query_integral_capacity(repeat_scope, direction));
  REQUIRE(repeat_services.query_integral_capacity(repeat_scope, direction));
  CHECK(repeat_services.ledger_snapshot().calls_reserved() ==
        mwperf::BigNat(2U));
}
