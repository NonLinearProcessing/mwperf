#include <chrono>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <catch2/catch_test_macros.hpp>

#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_id.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "surrogate/providers/full_orbit_sampler_provider.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace {

[[nodiscard]] mwperf::SurrogateId full_orbit_id() {
  auto id = mwperf::SurrogateId::parse("full_orbit_framework_sampler");
  REQUIRE(id);
  return std::move(id).value();
}

[[nodiscard]] mwperf::SurrogateVersion full_orbit_k_wide_version() {
  auto version = mwperf::SurrogateVersion::parse("1.2.0");
  REQUIRE(version);
  return std::move(version).value();
}

[[nodiscard]] mwperf::SurrogateVersion full_orbit_observation_version() {
  auto version = mwperf::SurrogateVersion::parse("1.3.0");
  REQUIRE(version);
  return std::move(version).value();
}

[[nodiscard]] mwperf::SurrogateVersion full_orbit_cp09_version() {
  auto version = mwperf::SurrogateVersion::parse("1.4.0");
  REQUIRE(version);
  return std::move(version).value();
}

}  // namespace

TEST_CASE("C27.1 production registry follows the Full Orbit build gate",
          "[c27_1][c30][c32][cp09][registry]") {
  const auto id = full_orbit_id();
  const auto k_wide_version = full_orbit_k_wide_version();
  const auto observation_version = full_orbit_observation_version();
  const auto cp09_version = full_orbit_cp09_version();

#if defined(MWPERF_C27_1_FULL_ORBIT_PROVIDER_ENABLED)
  auto explicit_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{k_wide_version});
  INFO((explicit_provider
            ? std::string{}
            : explicit_provider.error().code + ": " +
                  explicit_provider.error().message));
  REQUIRE(explicit_provider);
  CHECK(explicit_provider.value().identity().provider_id ==
        "full_orbit_framework_sampler");
  CHECK(explicit_provider.value().identity().provider_version == "1.2.0");
  CHECK(explicit_provider.value().is_default());

  auto default_provider = mwperf::lookup_surrogate_provider(id);
  REQUIRE(default_provider);
  CHECK(default_provider.value().identity() ==
        explicit_provider.value().identity());

  const auto* executable =
      explicit_provider.value().registered_executable();
  REQUIRE(executable != nullptr);
  CHECK(executable->provider_identity() ==
        explicit_provider.value().identity());
  CHECK(executable->manifest_digest() ==
        explicit_provider.value().manifest().value().manifest_digest);
  CHECK(executable->executable_id() == "fofs.cp06.c27.local");
  CHECK(executable->argv_grammar_version() == 1U);
  CHECK(executable->fixed_arguments() ==
        std::vector<std::string>{"--host-contract", "c27-local-v1"});
  CHECK(executable->wall_time_limit() == std::chrono::hours(1));
  REQUIRE(executable->maximum_wall_time_limit().has_value());
  CHECK(*executable->maximum_wall_time_limit() ==
        mwperf::kNonScientificWallTimeCeiling);
  REQUIRE(executable->maximum_worker_count().has_value());
  CHECK(*executable->maximum_worker_count() == 64U);
  CHECK(executable->absolute_executable().is_absolute());
  CHECK_FALSE(explicit_provider.value().has_framework_activation_factory());

  const auto& registry = mwperf::detail::production_surrogate_registry();
  REQUIRE(registry);
  REQUIRE(registry.value().providers().size() == 3U);
  CHECK(registry.value().providers().front().identity() ==
        explicit_provider.value().identity());

  auto observation_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{observation_version});
  INFO((observation_provider
            ? std::string{}
            : observation_provider.error().code + ": " +
                  observation_provider.error().message));
  REQUIRE(observation_provider);
  CHECK(observation_provider.value().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.3.0"});
  CHECK_FALSE(observation_provider.value().is_default());
  CHECK(observation_provider.value().result_protocol_version() == 2U);
  const auto* observation_executable =
      observation_provider.value().registered_executable();
  REQUIRE(observation_executable != nullptr);
  CHECK(observation_executable->fixed_arguments() ==
        std::vector<std::string>{"--host-contract", "c30-local-v2"});
  CHECK(observation_executable->absolute_executable() ==
        executable->absolute_executable());
  auto cp09_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{cp09_version});
  INFO((cp09_provider
            ? std::string{}
            : cp09_provider.error().code + ": " +
                  cp09_provider.error().message));
  REQUIRE(cp09_provider);
  CHECK(cp09_provider.value().identity() ==
        mwperf::ProviderIdentityV1{"full_orbit_framework_sampler", "1.4.0"});
  CHECK_FALSE(cp09_provider.value().is_default());
  CHECK(cp09_provider.value().result_protocol_version() == 3U);
  const auto* cp09_executable =
      cp09_provider.value().registered_executable();
  REQUIRE(cp09_executable != nullptr);
  CHECK(cp09_executable->fixed_arguments() ==
        std::vector<std::string>{"--host-contract", "c32-local-v3"});
  CHECK(cp09_executable->absolute_executable() ==
        executable->absolute_executable());
  CHECK(cp09_executable->wall_time_limit() ==
        mwperf::kNonScientificWallTimeCeiling);
  REQUIRE(cp09_executable->maximum_wall_time_limit().has_value());
  CHECK(*cp09_executable->maximum_wall_time_limit() ==
        mwperf::kNonScientificWallTimeCeiling);
  CHECK(registry.value().providers().back().identity() ==
        cp09_provider.value().identity());

  // The former CP06 ThreeBin registration is not retained as a fallback.
  auto wrong_version_value = mwperf::SurrogateVersion::parse("1.1.0");
  REQUIRE(wrong_version_value);
  auto wrong_version = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{
              std::move(wrong_version_value).value()});
  REQUIRE_FALSE(wrong_version);
  CHECK(wrong_version.error().code == "c16.unknown_surrogate_version");

  // The scientific route is solely CP07.1 K-wide.  The executable identity
  // remains the frozen host-transport compatibility name.
  auto hosted_route =
      mwperf::detail::full_orbit_sampler_k_wide_hosted_route();
  REQUIRE(hosted_route);
  CHECK_FALSE(hosted_route.value().production_registration_deferred);
  CHECK(hosted_route.value().executable_id == executable->executable_id());
  auto k_wide_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{k_wide_version});
  INFO((k_wide_provider
            ? std::string{}
            : k_wide_provider.error().code + ": " +
                  k_wide_provider.error().message));
  REQUIRE(k_wide_provider);
  CHECK(k_wide_provider.value().identity().provider_id ==
        "full_orbit_framework_sampler");
  CHECK(k_wide_provider.value().identity().provider_version == "1.2.0");
  CHECK(k_wide_provider.value().is_default());
  const auto* k_wide_executable =
      k_wide_provider.value().registered_executable();
  REQUIRE(k_wide_executable != nullptr);
  CHECK(k_wide_executable->provider_identity() ==
        k_wide_provider.value().identity());
  CHECK(k_wide_executable->executable_id() == executable->executable_id());
  CHECK(k_wide_executable->absolute_executable() ==
        executable->absolute_executable());
  CHECK(k_wide_provider.value().manifest().value().payload_class.tag ==
        mwperf::PayloadClassTagV1::finite_prefix_constant_tail_response_v1);
  CHECK(registry.value().providers().front().identity() ==
        k_wide_provider.value().identity());
  CHECK(default_provider.value().identity() ==
        k_wide_provider.value().identity());
#else
  auto omitted = mwperf::lookup_surrogate_provider(id);
  REQUIRE_FALSE(omitted);
  CHECK(omitted.error().code == "c16.unknown_surrogate_id");

  auto explicit_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{k_wide_version});
  REQUIRE_FALSE(explicit_provider);
  CHECK(explicit_provider.error().code == "c16.unknown_surrogate_id");

  auto observation_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{observation_version});
  REQUIRE_FALSE(observation_provider);
  CHECK(observation_provider.error().code == "c16.unknown_surrogate_id");

  auto cp09_provider = mwperf::lookup_surrogate_provider(
      id, std::optional<mwperf::SurrogateVersion>{cp09_version});
  REQUIRE_FALSE(cp09_provider);
  CHECK(cp09_provider.error().code == "c16.unknown_surrogate_id");

  const auto& registry = mwperf::detail::production_surrogate_registry();
  REQUIRE(registry);
  CHECK(registry.value().providers().empty());
#endif
}

TEST_CASE("C27.1 production registry preserves typed unknown identities",
          "[c27_1][negative]") {
  auto unknown = mwperf::SurrogateId::parse("c27_1.unknown.provider");
  REQUIRE(unknown);
  auto result = mwperf::lookup_surrogate_provider(unknown.value());
  REQUIRE_FALSE(result);
  CHECK(result.error().code == "c16.unknown_surrogate_id");
}
