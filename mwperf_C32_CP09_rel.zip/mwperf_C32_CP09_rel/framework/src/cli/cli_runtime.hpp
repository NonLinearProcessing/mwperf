#pragma once

#include <iosfwd>

#include "mwperf/cli.hpp"

namespace mwperf::detail {

using AnalyzeEntrypoint = Result<void> (*)(const Analyze& request);
using CompareCompressionEntrypoint =
    Result<void> (*)(const CompareCompression& request);

// C27's published analysis states are deliberately distinct from diagnostic
// categories.  In particular a pre-plan "unavailable" diagnostic is still a
// process failure, while a successfully published scientific-unavailability
// result has the stable process exit code 3.
enum class PublishedAnalysisStatus {
  success,
  unavailable,
  failed,
};

using PublishedAnalyzeEntrypoint =
    Result<PublishedAnalysisStatus> (*)(const Analyze& request);

[[nodiscard]] Result<void> c01_pipeline_not_implemented(
    const Analyze& request);

[[nodiscard]] int run_cli_boundary(int argc, char* const* argv,
                                   std::ostream& standard_output,
                                   std::ostream& standard_error,
                                   AnalyzeEntrypoint analyze,
                                   CompareCompressionEntrypoint compare =
                                       nullptr) noexcept;

[[nodiscard]] int run_cli_boundary(int argc, char* const* argv,
                                   std::ostream& standard_output,
                                   std::ostream& standard_error,
                                   PublishedAnalyzeEntrypoint analyze,
                                   CompareCompressionEntrypoint compare =
                                       nullptr) noexcept;

}  // namespace mwperf::detail
