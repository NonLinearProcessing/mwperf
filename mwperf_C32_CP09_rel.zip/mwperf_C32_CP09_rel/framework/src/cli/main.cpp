#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

#include "cli_runtime.hpp"
#include "mwperf/app/execution_plan.hpp"
#include "mwperf/app/resolved_request.hpp"
#include "mwperf/app/result_artifact.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/diagnostics/compression_comparison.hpp"
#include "mwperf/diagnostics/observation_artifact.hpp"

namespace {

const auto kProgramStartedAt = std::chrono::steady_clock::now();

[[nodiscard]] mwperf::Diagnostic comparison_error(std::string code,
                                                  std::string message,
                                                  const std::filesystem::path& path = {}) {
  return mwperf::Diagnostic{
      .category = mwperf::DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = path.empty()
                           ? std::nullopt
                           : std::optional<std::string>(path.string()),
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] mwperf::Result<std::vector<std::byte>> read_bounded_file(
    const std::filesystem::path& path, const std::size_t maximum_bytes) {
  std::error_code size_error;
  const std::uintmax_t size = std::filesystem::file_size(path, size_error);
  if (size_error || size > maximum_bytes ||
      size > static_cast<std::uintmax_t>(
                 std::numeric_limits<std::streamsize>::max())) {
    return mwperf::Result<std::vector<std::byte>>::failure(comparison_error(
        "comparison_input_size_invalid",
        "comparison input is unreadable or exceeds its bounded parser cap",
        path));
  }
  std::ifstream stream(path, std::ios::binary);
  if (!stream.is_open()) {
    return mwperf::Result<std::vector<std::byte>>::failure(comparison_error(
        "comparison_input_open_failed",
        "comparison input could not be opened", path));
  }
  std::vector<std::byte> bytes(static_cast<std::size_t>(size));
  if (!bytes.empty()) {
    stream.read(reinterpret_cast<char*>(bytes.data()),
                static_cast<std::streamsize>(bytes.size()));
  }
  if ((!bytes.empty() &&
       stream.gcount() != static_cast<std::streamsize>(bytes.size())) ||
      (!stream.good() && !stream.eof())) {
    return mwperf::Result<std::vector<std::byte>>::failure(comparison_error(
        "comparison_input_read_failed",
        "comparison input could not be read completely", path));
  }
  if (stream.peek() != std::char_traits<char>::eof() || stream.bad()) {
    return mwperf::Result<std::vector<std::byte>>::failure(comparison_error(
        "comparison_input_changed_during_read",
        "comparison input grew or changed while it was being read", path));
  }
  return mwperf::Result<std::vector<std::byte>>::success(std::move(bytes));
}

struct LoadedComparisonObservation final {
  std::shared_ptr<const mwperf::ValidatedConstructionObservationBundleV1>
      observation;
  std::optional<mwperf::ResultArtifactVersionV1> result_version;
  std::shared_ptr<const mwperf::CompressionAnalysisOptionsV1>
      analysis_options;
  std::shared_ptr<const mwperf::SuppliedResponseProfileV1>
      provider_supplied_profile;
  std::shared_ptr<const mwperf::SuppliedResponseProfileV1> decoder_profile;
  std::optional<mwperf::Digest256> provider_result_digest;
  std::optional<mwperf::Digest256> decoder_semantics_digest;
};

enum class ComparisonInputKind : std::uint8_t {
  observation_v1,
  result_v2,
  result_v3,
};

[[nodiscard]] mwperf::Result<ComparisonInputKind>
detect_comparison_input_kind(
    const std::filesystem::path& path) {
  constexpr std::string_view v2_prefix = "{\"result_version\":2,";
  constexpr std::string_view v3_prefix = "{\"result_version\":3,";
  static_assert(v2_prefix.size() == v3_prefix.size());
  std::ifstream stream(path, std::ios::binary);
  if (!stream.is_open()) {
    return mwperf::Result<ComparisonInputKind>::failure(comparison_error(
        "comparison_input_open_failed",
        "comparison input could not be opened", path));
  }
  std::array<char, v2_prefix.size()> bytes{};
  stream.read(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  const std::streamsize received = stream.gcount();
  if (received < 0 || (!stream.good() && !stream.eof())) {
    return mwperf::Result<ComparisonInputKind>::failure(comparison_error(
        "comparison_input_read_failed",
        "comparison input prefix could not be read", path));
  }
  if (received != static_cast<std::streamsize>(bytes.size())) {
    return mwperf::Result<ComparisonInputKind>::success(
        ComparisonInputKind::observation_v1);
  }
  const std::string_view prefix(bytes.data(), bytes.size());
  if (prefix == v2_prefix) {
    return mwperf::Result<ComparisonInputKind>::success(
        ComparisonInputKind::result_v2);
  }
  if (prefix == v3_prefix) {
    return mwperf::Result<ComparisonInputKind>::success(
        ComparisonInputKind::result_v3);
  }
  if (prefix.starts_with("{\"result_version\":")) {
    return mwperf::Result<ComparisonInputKind>::failure(comparison_error(
        "comparison_result_version_unsupported",
        "comparison input names an unsupported result artifact version",
        path));
  }
  return mwperf::Result<ComparisonInputKind>::success(
      ComparisonInputKind::observation_v1);
}

[[nodiscard]] mwperf::Result<LoadedComparisonObservation>
load_comparison_observation(const mwperf::CliPath& input,
                            const bool permit_result_artifact) {
  const mwperf::ResultArtifactParseLimitsV2 result_limits =
      mwperf::default_result_artifact_parse_limits_v2();
  const mwperf::ObservationParseLimitsV1 observation_limits =
      mwperf::default_observation_parse_limits_v1();
  auto input_kind = detect_comparison_input_kind(input.path);
  if (!input_kind) {
    return mwperf::Result<LoadedComparisonObservation>::failure(
        input_kind.error());
  }
  const bool is_result =
      input_kind.value() != ComparisonInputKind::observation_v1;
  if (is_result && !permit_result_artifact) {
    return mwperf::Result<LoadedComparisonObservation>::failure(
        comparison_error(
            "comparison_reference_requires_observation_artifact",
            "ordinary references must be standalone observation-v1 artifacts",
            input.path));
  }
  auto bytes = read_bounded_file(
      input.path, is_result ? result_limits.maximum_bytes
                            : observation_limits.maximum_bytes);
  if (!bytes) {
    return mwperf::Result<LoadedComparisonObservation>::failure(bytes.error());
  }
  if (input_kind.value() == ComparisonInputKind::result_v2) {
    auto parsed = mwperf::parse_result_artifact_v2(bytes.value(), result_limits);
    if (!parsed) {
      return mwperf::Result<LoadedComparisonObservation>::failure(
          parsed.error());
    }
    if (!parsed.value().observation()) {
      return mwperf::Result<LoadedComparisonObservation>::failure(
          comparison_error(
              "comparison_result_has_no_observation",
              "result-v2 has no authenticated diagnostic observation",
              input.path));
    }
    auto observation = parsed.value().observation();
    return mwperf::Result<LoadedComparisonObservation>::success(
        LoadedComparisonObservation{
            .observation = std::move(observation),
            .result_version = mwperf::ResultArtifactVersionV1::v2,
            .analysis_options = parsed.value().analysis_options(),
            .provider_supplied_profile =
                parsed.value().provider_supplied_profile(),
            .decoder_profile = parsed.value().decoder_profile(),
            .provider_result_digest = parsed.value().provider_result_digest(),
            .decoder_semantics_digest =
                parsed.value().decoder_semantics_digest(),
        });
  }
  if (input_kind.value() == ComparisonInputKind::result_v3) {
    auto parsed = mwperf::parse_result_artifact_v3(bytes.value(), result_limits);
    if (!parsed) {
      return mwperf::Result<LoadedComparisonObservation>::failure(
          parsed.error());
    }
    if (!parsed.value().observation()) {
      return mwperf::Result<LoadedComparisonObservation>::failure(
          comparison_error(
              "comparison_result_has_no_observation",
              "result-v3 has no authenticated diagnostic observation",
              input.path));
    }
    auto observation = parsed.value().observation();
    return mwperf::Result<LoadedComparisonObservation>::success(
        LoadedComparisonObservation{
            .observation = std::move(observation),
            .result_version = mwperf::ResultArtifactVersionV1::v3,
            .analysis_options = parsed.value().analysis_options(),
            .provider_supplied_profile = nullptr,
            .decoder_profile = nullptr,
            .provider_result_digest = parsed.value().provider_result_digest(),
            .decoder_semantics_digest = std::nullopt,
        });
  }

  auto parsed = mwperf::parse_and_validate_observation_artifact_v1(
      bytes.value(), observation_limits);
  if (!parsed) {
    return mwperf::Result<LoadedComparisonObservation>::failure(
        parsed.error());
  }
  return mwperf::Result<LoadedComparisonObservation>::success(
      LoadedComparisonObservation{
          .observation =
              std::make_shared<
                  const mwperf::ValidatedConstructionObservationBundleV1>(
                  std::move(parsed).value()),
          .result_version = std::nullopt,
          .analysis_options = nullptr,
          .provider_supplied_profile = nullptr,
          .decoder_profile = nullptr,
          .provider_result_digest = std::nullopt,
          .decoder_semantics_digest = std::nullopt,
      });
}

[[nodiscard]] mwperf::CompressionAnalysisOptionsV1 comparison_analysis_options(
    const mwperf::CompareCompression& request,
    const bool stationary_reference,
    const std::optional<mwperf::SuppliedResponseProfileV1>& supplied_profile,
    const std::shared_ptr<const mwperf::CompressionAnalysisOptionsV1>&
        source_options = nullptr) {
  mwperf::CompressionAnalysisOptionsV1 options;
  options.cutoffs = request.cutoffs;

  // Preserve frozen finite-prefix comparison behavior for historical inputs.
  // K=0, cutoffs beyond the fit limit, and an authenticated result-v3 source
  // select CP09's sparse raw projection: the requested BigNat remains only a
  // threshold and cannot drive a dense [0,K] allocation.
  const mwperf::BigNat maximum_fitted_cutoff{
      static_cast<std::uint64_t>(options.fit_limits.maximum_cutoff)};
  const bool source_is_empirical =
      source_options &&
      source_options->projection_mode ==
          mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response;
  const bool requires_empirical_projection =
      source_is_empirical ||
      std::any_of(request.cutoffs.begin(), request.cutoffs.end(),
                  [&maximum_fitted_cutoff](const mwperf::BigNat& cutoff) {
                    return cutoff.is_zero() ||
                           cutoff > maximum_fitted_cutoff;
                  });
  if (requires_empirical_projection) {
    options.projection_mode =
        mwperf::CompressionAnalysisOptionsV1::ProjectionMode::
            empirical_finite_window_response;
    if (source_is_empirical) {
      options.ensemble_population_size =
          source_options->ensemble_population_size;
      options.poisson_overshoot = source_options->poisson_overshoot;
      options.ill_conditioned_slack_threshold =
          source_options->ill_conditioned_slack_threshold;
    }
    options.run_diagnostic_fits = false;
    options.compute_delete_one_replication_jackknife = false;
  } else if (supplied_profile.has_value()) {
    options.provider_supplied_profiles.push_back(*supplied_profile);
  }
  if (!requires_empirical_projection) {
    options.run_diagnostic_fits = true;
    options.compute_delete_one_replication_jackknife = true;
  }
  options.stationary_coefficients_established = stationary_reference;
  options.prefix_preservation_established = stationary_reference;
  return options;
}

[[nodiscard]] mwperf::Result<mwperf::Digest256>
unspecified_decoder_semantics_digest() {
  constexpr std::string_view marker = "decoder-result-not-supplied";
  return mwperf::sha256_domain_separated(
      "mwperf.compression_comparison.decoder_semantics.v1",
      std::as_bytes(std::span(marker.data(), marker.size())));
}

[[nodiscard]] mwperf::Result<mwperf::DecoderTransformedProfileV1>
make_transformed_profile(
    const LoadedComparisonObservation& decoder,
    const mwperf::ValidatedConstructionObservationBundleV1& weighted,
    const mwperf::CompareCompression& request) {
  if (!decoder.observation || !decoder.decoder_profile ||
      !decoder.provider_result_digest || !decoder.decoder_semantics_digest ||
      decoder.observation->digest() != weighted.digest()) {
    return mwperf::Result<mwperf::DecoderTransformedProfileV1>::failure(
        comparison_error(
            "comparison_decoder_binding_invalid",
            "decoder result must retain an available profile and both bindings for the weighted-ensemble observation"));
  }
  const mwperf::ConstructionObservationBundleV1& body = weighted.value();
  const auto* arrival = std::get_if<mwperf::ExactTargetArrivalMarginalV1>(
      &body.bindings.arrival.target_arrival);
  if (arrival == nullptr) {
    return mwperf::Result<mwperf::DecoderTransformedProfileV1>::failure(
        comparison_error(
            "comparison_decoder_arrival_unavailable",
            "decoder transformation fit requires the authenticated exact target-arrival marginal"));
  }

  mwperf::DecoderTransformedProfileV1 transformed{
      .experiment_digest = body.bindings.experiment_digest,
      .source_observation_digest = weighted.digest(),
      .provider_result_digest = *decoder.provider_result_digest,
      .decoder_semantics_digest = *decoder.decoder_semantics_digest,
      .cutoffs = {},
  };
  const mwperf::SuppliedResponseProfileV1& profile =
      *decoder.decoder_profile;
  const bool cutoff_requested = std::any_of(
      request.cutoffs.begin(), request.cutoffs.end(),
      [&profile](const mwperf::BigNat& cutoff) {
        return profile.cutoff == cutoff;
      });
  if (!cutoff_requested) {
    return mwperf::Result<mwperf::DecoderTransformedProfileV1>::success(
        std::move(transformed));
  }
  std::vector<mwperf::FinitePrefixFitArrivalAtomV1> atoms;
  atoms.reserve(arrival->atoms.size());
  for (const mwperf::ExactTargetArrivalAtomV1& atom : arrival->atoms) {
    atoms.push_back({atom.batch_size, atom.probability});
  }
  auto effective_options = mwperf::effective_compression_analysis_options_v1(
      weighted, mwperf::CompressionAnalysisOptionsV1{});
  if (!effective_options) {
    return mwperf::Result<mwperf::DecoderTransformedProfileV1>::failure(
        effective_options.error());
  }
  mwperf::FinitePrefixFitInputV1 input{
      .target_arrival_atoms = std::move(atoms),
      .second_arrival_moment_available =
          body.capabilities.finite_arrival_second_moment.available,
      .third_arrival_moment_available =
          body.capabilities.exact_target_arrival_marginal.available &&
          body.capabilities.finite_arrival_second_moment.available,
      .selection_seed =
          std::move(effective_options).value().selection_seed,
      .service_by_level = profile.service_by_level,
      .constant_tail_service = profile.constant_tail_service,
      .binding =
          mwperf::FinitePrefixFitBindingV1{
              *decoder.provider_result_digest,
              body.bindings.arrival.configured_law_digest},
      .limits = mwperf::FinitePrefixFitLimitsV1{},
      .analytic_arrival_moments = std::nullopt,
      .arrival_support_extends_beyond_projection = false,
  };
  auto fit = mwperf::fit_finite_prefix_constant_tail(std::move(input));
  mwperf::DecoderTransformedFitPointV1 point{
      .cutoff = profile.cutoff,
      .fit = std::nullopt,
      .fit_failure = std::nullopt,
      .fitted_mean_jackknife = std::nullopt,
      .fit_resamples = std::nullopt,
      .transformation_jackknife = std::nullopt,
  };
  if (fit) {
    point.fit = std::move(fit).value();
  } else {
    point.fit_failure = fit.error();
  }
  // The provider result contains only the full-sample decoder profile.  It
  // does not carry independently recomputed delete-one decoder profiles, so
  // repeating the full-sample fit for every omission would fabricate zero
  // decoder variance and destroy the required covariance interpretation.
  // Leave both jackknife fields absent; the comparison engine reports the
  // transformation uncertainty with its typed
  // insufficient_independent_replications reason while retaining the exact
  // full-sample transformation term.
  transformed.cutoffs.push_back(std::move(point));
  return mwperf::Result<mwperf::DecoderTransformedProfileV1>::success(
      std::move(transformed));
}

[[nodiscard]] mwperf::Result<mwperf::detail::PublishedAnalysisStatus>
run_c27_analysis(const mwperf::Analyze& request) {
  auto resolved = mwperf::load_and_resolve_request(
      mwperf::CliRequest{.mode = request});
  if (!resolved) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        resolved.error());
  }

  auto plan = mwperf::build_execution_plan(resolved.value());
  if (!plan) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        plan.error());
  }
  auto valid_plan = mwperf::validate_execution_plan(plan.value());
  if (!valid_plan) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        valid_plan.error());
  }
  if (request.result_version == mwperf::ResultVersionSelectionV1::v1 &&
      plan.value().provider().result_protocol_version() == 2U) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        comparison_error(
            "c30.result_v1_forbidden_for_diagnostics_provider",
            "result-v1 cannot be selected for a provider-result-v2 diagnostics route"));
  }
  if ((request.result_version == mwperf::ResultVersionSelectionV1::v1 ||
       request.result_version == mwperf::ResultVersionSelectionV1::v2) &&
      plan.value().provider().result_protocol_version() == 3U) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        comparison_error(
            "c32.result_v3_required",
            "provider-result-v3 Observed requires outer result-v3 publication"));
  }

  mwperf::AnalysisBundle analysis =
      mwperf::detail::execute_analysis_from(plan.value(), kProgramStartedAt);
  auto artifact = mwperf::assemble_selected_result_artifact(
      resolved.value(), plan.value(), analysis, request.result_version);
  if (!artifact) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        artifact.error());
  }
  auto published = mwperf::write_published_result_artifact(
      artifact.value(), resolved.value().output_path().path);
  if (!published) {
    return mwperf::Result<mwperf::detail::PublishedAnalysisStatus>::failure(
        published.error());
  }

  using Published = mwperf::detail::PublishedAnalysisStatus;
  switch (artifact.value().status()) {
    case mwperf::ResultStatusV1::success:
      return mwperf::Result<Published>::success(Published::success);
    case mwperf::ResultStatusV1::unavailable:
      return mwperf::Result<Published>::success(Published::unavailable);
    case mwperf::ResultStatusV1::failed:
      return mwperf::Result<Published>::success(Published::failed);
  }
  return mwperf::Result<Published>::failure(mwperf::Diagnostic{
      .category = mwperf::DiagnosticCategory::internal,
      .code = "result_status_invalid",
      .message = "the assembled result has an unknown status",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  });
}

[[nodiscard]] mwperf::Result<void> run_compression_comparison(
    const mwperf::CompareCompression& request) {
  auto stationary =
      load_comparison_observation(request.stationary_reference, false);
  if (!stationary) return mwperf::Result<void>::failure(stationary.error());
  auto finite_window =
      load_comparison_observation(request.finite_window_reference, false);
  if (!finite_window) {
    return mwperf::Result<void>::failure(finite_window.error());
  }
  auto weighted = load_comparison_observation(request.weighted_ensemble, true);
  if (!weighted) return mwperf::Result<void>::failure(weighted.error());

  std::optional<LoadedComparisonObservation> explicit_decoder;
  if (request.decoder_result.has_value()) {
    auto loaded = load_comparison_observation(*request.decoder_result, true);
    if (!loaded) return mwperf::Result<void>::failure(loaded.error());
    if (loaded.value().result_version !=
        mwperf::ResultArtifactVersionV1::v2) {
      return mwperf::Result<void>::failure(comparison_error(
          "comparison_decoder_requires_result_v2",
          "--decoder-result must name a canonical result-v2 artifact",
          request.decoder_result->path));
    }
    explicit_decoder = std::move(loaded).value();
  }
  const LoadedComparisonObservation* decoder = nullptr;
  if (explicit_decoder.has_value()) {
    decoder = &*explicit_decoder;
  } else if (weighted.value().result_version ==
             mwperf::ResultArtifactVersionV1::v2) {
    decoder = &weighted.value();
  }

  std::optional<mwperf::SuppliedResponseProfileV1> supplied_profile;
  const LoadedComparisonObservation* provider_profile_source = nullptr;
  if (weighted.value().provider_supplied_profile) {
    provider_profile_source = &weighted.value();
  } else if (decoder != nullptr && decoder->provider_supplied_profile) {
    provider_profile_source = decoder;
  }
  if (provider_profile_source != nullptr) {
    if (!provider_profile_source->observation ||
        provider_profile_source->observation->digest() !=
            weighted.value().observation->digest()) {
      return mwperf::Result<void>::failure(comparison_error(
          "comparison_provider_profile_binding_invalid",
          "provider-supplied profile is not bound to the weighted-ensemble observation"));
    }
    supplied_profile = *provider_profile_source->provider_supplied_profile;
  }
  auto stationary_analysis = mwperf::analyze_compression_observations_v1(
      *stationary.value().observation,
      comparison_analysis_options(request, true, std::nullopt));
  if (!stationary_analysis) {
    return mwperf::Result<void>::failure(stationary_analysis.error());
  }
  auto finite_analysis = mwperf::analyze_compression_observations_v1(
      *finite_window.value().observation,
      comparison_analysis_options(request, false, std::nullopt));
  if (!finite_analysis) {
    return mwperf::Result<void>::failure(finite_analysis.error());
  }
  auto weighted_analysis = mwperf::analyze_compression_observations_v1(
      *weighted.value().observation,
      comparison_analysis_options(request, false, supplied_profile,
                                  weighted.value().analysis_options));
  if (!weighted_analysis) {
    return mwperf::Result<void>::failure(weighted_analysis.error());
  }

  auto unspecified_semantics = unspecified_decoder_semantics_digest();
  if (!unspecified_semantics) {
    return mwperf::Result<void>::failure(unspecified_semantics.error());
  }
  mwperf::CompressionComparisonOptionsV1 options{
      .decoder_semantics_digest =
          decoder != nullptr && decoder->decoder_semantics_digest
              ? *decoder->decoder_semantics_digest
              : std::move(unspecified_semantics).value(),
      .decoder_consumed_empirical_profile_unchanged = false,
      .transformed_profile = std::nullopt,
  };
  if (decoder != nullptr && decoder->decoder_profile) {
    auto transformed = make_transformed_profile(
        *decoder, *weighted.value().observation, request);
    if (!transformed) {
      return mwperf::Result<void>::failure(transformed.error());
    }
    options.transformed_profile = std::move(transformed).value();
  }

  auto comparison = mwperf::compare_compression_profiles_v1(
      stationary_analysis.value(), finite_analysis.value(),
      weighted_analysis.value(), options);
  if (!comparison) {
    return mwperf::Result<void>::failure(comparison.error());
  }
  return mwperf::write_compression_comparison_artifact_v1(
      comparison.value(), request.output_path.path);
}

}  // namespace

int main(const int argc, char* argv[]) {
  return mwperf::detail::run_cli_boundary(
      argc, argv, std::cout, std::cerr,
      &run_c27_analysis, &run_compression_comparison);
}
