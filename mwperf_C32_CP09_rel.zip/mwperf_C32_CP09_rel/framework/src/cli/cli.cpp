#include "mwperf/cli.hpp"

#include <algorithm>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <optional>
#include <ostream>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include "cli_runtime.hpp"
#include "mwperf/build_information.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

constexpr std::string_view kUsageText =
    "Usage:\n"
    "  mwperf --model <schema-3-or-4.yaml|json> --target <queue-id> "
    "--output <result.json> [--workers <positive-u32>] "
    "[--timeout-seconds <seconds>] [--output_resources] "
    "[--report_unavailable_diagnostics] [--result-version <auto|1|2|3>]\n"
    "  mwperf --model <schema-3-or-4.yaml|json> --analysis "
    "<analysis-v1.yaml|json> --output <result.json> "
    "[--workers <positive-u32>] [--timeout-seconds <seconds>] "
    "[--output_resources] [--report_unavailable_diagnostics] "
    "[--result-version <auto|1|2|3>]\n"
    "  mwperf compare-compression --stationary-reference "
    "<observation-v1.json> --finite-window-reference "
    "<observation-v1.json> --weighted-ensemble "
    "<observation-v1-or-result-v2-or-result-v3.json> [--decoder-result "
    "<result-v2.json>] [--cutoff <K> ...] --output <comparison.json>\n"
    "  mwperf --help\n"
    "  mwperf --version\n";

enum class ExclusiveMode {
  help,
  version,
};

constexpr std::uint32_t kDefaultWorkerCount = 1U;
constexpr std::uint32_t kMaximumWorkerCount =
    std::numeric_limits<std::uint32_t>::max();
constexpr std::uint64_t kDefaultTimeoutSeconds = 3600U;

[[nodiscard]] Diagnostic usage_diagnostic(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::cli_usage,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] bool is_option_like(const std::string_view token) noexcept {
  return token.starts_with("--");
}

[[nodiscard]] std::optional<BigNat> parse_canonical_big_nat(
    const std::string_view text) {
  if (text.empty() || (text.size() > 1U && text.front() == '0') ||
      !std::all_of(text.begin(), text.end(), [](const char byte) {
        return byte >= '0' && byte <= '9';
      })) {
    return std::nullopt;
  }
  auto parsed = BigNat::from_big_int(BigInt(std::string(text)));
  if (!parsed) {
    return std::nullopt;
  }
  return std::move(parsed).value();
}

template <typename Integer>
[[nodiscard]] std::optional<Integer> parse_positive_integer(
    const std::string_view text, const Integer maximum) noexcept {
  if (text.empty() || (text.size() > 1U && text.front() == '0')) {
    return std::nullopt;
  }
  Integer value{};
  const auto [end, error] =
      std::from_chars(text.data(), text.data() + text.size(), value);
  if (error != std::errc{} || end != text.data() + text.size() ||
      value == 0 || value > maximum) {
    return std::nullopt;
  }
  return value;
}

[[nodiscard]] CliPath make_cli_path(const std::string_view authored) {
  std::string owned(authored);
  return CliPath{
      .authored = owned,
      .path = std::filesystem::path(std::move(owned)),
  };
}

[[nodiscard]] std::string render_version_information(
    const BuildInformation& information) {
  std::string rendered;
  rendered.reserve(256U);

  const auto append = [&rendered](const std::string_view key,
                                  const std::string& value) {
    rendered += key;
    rendered += ": ";
    rendered += value;
    rendered += '\n';
  };

  rendered += "mwperf build information\n";
  append("program_version", information.program_version);
  append("source_tree_version", information.source_tree_version);
  append("compiler_id", information.compiler_id);
  append("compiler_version", information.compiler_version);
  append("enabled_features", information.enabled_features);
  append("physical_schema_version", information.physical_schema_version);
  append("analysis_schema_version", information.analysis_schema_version);
  append("rng_algorithm_version", information.rng_algorithm_version);
  append("function_interface_manifest_version",
         information.function_interface_manifest_version);
  return rendered;
}

[[nodiscard]] Result<CliRequest> parse_compare_compression(
    const std::span<const std::string_view> arguments) {
  std::optional<CliPath> stationary;
  std::optional<CliPath> finite_window;
  std::optional<CliPath> weighted_ensemble;
  std::optional<CliPath> decoder_result;
  std::optional<CliPath> output;
  std::vector<BigNat> cutoffs;

  for (std::size_t index = 0U; index < arguments.size(); ++index) {
    const std::string_view token = arguments[index];
    if (token == "--cutoff") {
      if (index + 1U >= arguments.size() ||
          is_option_like(arguments[index + 1U])) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_missing_value", "an option requires a nonempty value",
            {std::string(token)}));
      }
      auto cutoff = parse_canonical_big_nat(arguments[++index]);
      if (!cutoff.has_value()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_invalid_compression_cutoff",
            "compression cutoff must be a canonical nonnegative integer",
            {std::string(token)}));
      }
      cutoffs.push_back(std::move(*cutoff));
      continue;
    }

    std::optional<CliPath>* destination = nullptr;
    if (token == "--stationary-reference") {
      destination = &stationary;
    } else if (token == "--finite-window-reference") {
      destination = &finite_window;
    } else if (token == "--weighted-ensemble") {
      destination = &weighted_ensemble;
    } else if (token == "--decoder-result") {
      destination = &decoder_result;
    } else if (token == "--output") {
      destination = &output;
    }
    if (destination == nullptr) {
      return Result<CliRequest>::failure(usage_diagnostic(
          token.starts_with('-') ? "cli_unknown_option"
                                 : "cli_unexpected_argument",
          token.starts_with('-') ? "an unknown option was provided"
                                 : "a positional argument was provided",
          {std::string(token)}));
    }
    if (destination->has_value()) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_duplicate_option", "an option was specified more than once",
          {std::string(token)}));
    }
    if (index + 1U >= arguments.size() ||
        is_option_like(arguments[index + 1U])) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_missing_value", "an option requires a nonempty value",
          {std::string(token)}));
    }
    const std::string_view value = arguments[++index];
    if (value.empty()) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_empty_value", "an option value must not be empty",
          {std::string(token)}));
    }
    *destination = make_cli_path(value);
  }

  std::vector<std::string> missing;
  if (!stationary) missing.emplace_back("missing --stationary-reference");
  if (!finite_window) {
    missing.emplace_back("missing --finite-window-reference");
  }
  if (!weighted_ensemble) missing.emplace_back("missing --weighted-ensemble");
  if (!output) missing.emplace_back("missing --output");
  if (!missing.empty()) {
    return Result<CliRequest>::failure(usage_diagnostic(
        "cli_missing_required_option",
        "compare-compression requires three observations and an output",
        std::move(missing)));
  }
  if (cutoffs.empty()) {
    cutoffs = {BigNat{4U}, BigNat{8U}, BigNat{12U}};
  } else {
    std::sort(cutoffs.begin(), cutoffs.end());
    if (std::adjacent_find(cutoffs.begin(), cutoffs.end()) != cutoffs.end()) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_duplicate_cutoff",
          "each compression cutoff may be requested only once"));
    }
  }
  return Result<CliRequest>::success(CliRequest{.mode = CompareCompression{
      .stationary_reference = std::move(*stationary),
      .finite_window_reference = std::move(*finite_window),
      .weighted_ensemble = std::move(*weighted_ensemble),
      .decoder_result = std::move(decoder_result),
      .cutoffs = std::move(cutoffs),
      .output_path = std::move(*output),
  }});
}

[[nodiscard]] int render_internal_exception(std::ostream& standard_error) {
  constexpr std::string_view diagnostic =
      "mwperf: internal[internal_exception]: \"an unexpected exception "
      "crossed the process boundary\"\n";
  try {
    standard_error << diagnostic;
  } catch (...) {
    // There is no safe secondary reporting path if rendering itself fails.
  }
  return 1;
}

}  // namespace

Result<CliRequest> parse_cli(
    const std::span<const std::string_view> arguments) {
  if (arguments.empty()) {
    return Result<CliRequest>::failure(usage_diagnostic(
        "cli_no_arguments",
        "no command-line mode or analysis operands were provided"));
  }
  if (arguments.front() == "compare-compression") {
    return parse_compare_compression(arguments.subspan(1U));
  }

  std::optional<ExclusiveMode> exclusive_mode;
  std::optional<CliPath> model_path;
  std::optional<CliPath> analysis_path;
  std::optional<CliPath> output_path;
  std::optional<std::string> target_queue;
  std::optional<std::uint32_t> worker_count;
  std::optional<std::uint64_t> timeout_seconds;
  std::optional<ResultVersionSelectionV1> result_version;
  bool output_resources = false;
  bool report_unavailable_diagnostics = false;
  bool saw_analysis_option = false;

  for (std::size_t index = 0; index < arguments.size(); ++index) {
    const std::string_view token = arguments[index];

    if (token == "--help" || token == "--version") {
      const ExclusiveMode requested = token == "--help"
                                          ? ExclusiveMode::help
                                          : ExclusiveMode::version;
      if (exclusive_mode.has_value() && *exclusive_mode == requested) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      if (exclusive_mode.has_value() || saw_analysis_option) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_mixed_mode",
            "help and version are exclusive modes and cannot be combined",
            {std::string(token)}));
      }
      exclusive_mode = requested;
      continue;
    }

    if (exclusive_mode.has_value()) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_mixed_mode",
          "help and version are exclusive modes and cannot be combined",
          {std::string(token)}));
    }

    if (token == "--output_resources") {
      saw_analysis_option = true;
      if (output_resources) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      output_resources = true;
      continue;
    }

    if (token == "--report_unavailable_diagnostics") {
      saw_analysis_option = true;
      if (report_unavailable_diagnostics) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      report_unavailable_diagnostics = true;
      continue;
    }

    if (token == "--target") {
      saw_analysis_option = true;
      if (target_queue.has_value()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      if (index + 1U >= arguments.size() ||
          is_option_like(arguments[index + 1U])) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_missing_value", "an option requires a nonempty value",
            {std::string(token)}));
      }
      const std::string_view value = arguments[++index];
      if (value.empty()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_empty_value", "an option value must not be empty",
            {std::string(token)}));
      }
      target_queue = std::string(value);
      continue;
    }

    if (token == "--result-version") {
      saw_analysis_option = true;
      if (result_version.has_value()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      if (index + 1U >= arguments.size() ||
          is_option_like(arguments[index + 1U])) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_missing_value", "an option requires a nonempty value",
            {std::string(token)}));
      }
      const std::string_view value = arguments[++index];
      if (value == "auto") {
        result_version = ResultVersionSelectionV1::automatic;
      } else if (value == "1") {
        result_version = ResultVersionSelectionV1::v1;
      } else if (value == "2") {
        result_version = ResultVersionSelectionV1::v2;
      } else if (value == "3") {
        result_version = ResultVersionSelectionV1::v3;
      } else {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_invalid_result_version",
            "result version must be one of auto, 1, 2, or 3",
            {std::string(token)}));
      }
      continue;
    }

    if (token == "--workers" || token == "--timeout-seconds") {
      saw_analysis_option = true;
      const bool is_workers = token == "--workers";
      if ((is_workers && worker_count.has_value()) ||
          (!is_workers && timeout_seconds.has_value())) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      if (index + 1U >= arguments.size() ||
          is_option_like(arguments[index + 1U])) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_missing_value", "an option requires a nonempty value",
            {std::string(token)}));
      }
      const std::string_view value = arguments[++index];
      if (is_workers) {
        worker_count =
            parse_positive_integer<std::uint32_t>(value, kMaximumWorkerCount);
      } else {
        timeout_seconds = parse_positive_integer<std::uint64_t>(
            value, kNonScientificTimeoutSecondsCeiling);
      }
      if ((is_workers && !worker_count.has_value()) ||
          (!is_workers && !timeout_seconds.has_value())) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_invalid_execution_control",
            "an execution control must be a canonical positive integer "
            "within its supported bound",
            {std::string(token),
             is_workers
                 ? "allowed range: 1.." +
                       std::to_string(kMaximumWorkerCount)
                 : "allowed range: 1.." +
                       std::to_string(kNonScientificTimeoutSecondsCeiling) +
                       " seconds"}));
      }
      continue;
    }

    std::optional<CliPath>* destination = nullptr;
    if (token == "--model") {
      destination = &model_path;
    } else if (token == "--analysis") {
      destination = &analysis_path;
    } else if (token == "--output") {
      destination = &output_path;
    }

    if (destination != nullptr) {
      saw_analysis_option = true;
      if (destination->has_value()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_duplicate_option", "an option was specified more than once",
            {std::string(token)}));
      }
      if (index + 1U >= arguments.size() ||
          is_option_like(arguments[index + 1U])) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_missing_value", "an option requires a nonempty value",
            {std::string(token)}));
      }

      const std::string_view value = arguments[++index];
      if (value.empty()) {
        return Result<CliRequest>::failure(usage_diagnostic(
            "cli_empty_value", "an option value must not be empty",
            {std::string(token)}));
      }
      *destination = make_cli_path(value);
      continue;
    }

    if (token.starts_with('-')) {
      return Result<CliRequest>::failure(usage_diagnostic(
          "cli_unknown_option", "an unknown option was provided",
          {std::string(token)}));
    }
    return Result<CliRequest>::failure(usage_diagnostic(
        "cli_unexpected_argument", "a positional argument was provided",
        {std::string(token)}));
  }

  if (exclusive_mode.has_value()) {
    if (*exclusive_mode == ExclusiveMode::help) {
      return Result<CliRequest>::success(CliRequest{.mode = Help{}});
    }
    return Result<CliRequest>::success(CliRequest{.mode = Version{}});
  }

  std::vector<std::string> missing;
  if (!model_path.has_value()) {
    missing.emplace_back("missing --model");
  }
  if (!analysis_path.has_value() && !target_queue.has_value()) {
    missing.emplace_back("missing exactly one of --target or --analysis");
  }
  if (!output_path.has_value()) {
    missing.emplace_back("missing --output");
  }
  if (!missing.empty()) {
    return Result<CliRequest>::failure(usage_diagnostic(
        "cli_missing_required_option",
        "analysis mode requires a model, an output, and exactly one analysis "
        "source",
        std::move(missing)));
  }
  if (analysis_path.has_value() && target_queue.has_value()) {
    return Result<CliRequest>::failure(usage_diagnostic(
        "cli_conflicting_analysis_source",
        "--target and --analysis are mutually exclusive",
        {"use --target for the built-in Full Orbit profile",
         "use --analysis only for an explicit advanced profile"}));
  }

  return Result<CliRequest>::success(CliRequest{.mode = Analyze{
                                                    .model_path =
                                                        std::move(*model_path),
                                                    .analysis_path =
                                                        analysis_path.value_or(
                                                            CliPath{}),
                                                    .output_path =
                                                        std::move(*output_path),
                                                    .target_queue =
                                                        std::move(target_queue),
                                                    .worker_count =
                                                        worker_count.value_or(
                                                            kDefaultWorkerCount),
                                                    .timeout_seconds =
                                                        timeout_seconds.value_or(
                                                            kDefaultTimeoutSeconds),
                                                    .output_resources =
                                                        output_resources,
                                                    .report_unavailable_diagnostics =
                                                        report_unavailable_diagnostics,
                                                    .result_version =
                                                        result_version.value_or(
                                                            ResultVersionSelectionV1::automatic),
                                                }});
}

namespace detail {

Result<void> c01_pipeline_not_implemented(const Analyze& request) {
  static_cast<void>(request);
  return Result<void>::failure(Diagnostic{
      .category = DiagnosticCategory::unavailable,
      .code = "pipeline_not_implemented",
      .message = "the analysis pipeline is not implemented at checkpoint C01",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {"checkpoint C27 will replace this temporary seam"},
  });
}

int run_cli_boundary(const int argc, char* const* argv,
                     std::ostream& standard_output,
                     std::ostream& standard_error,
                     const AnalyzeEntrypoint analyze,
                     const CompareCompressionEntrypoint compare) noexcept {
  try {
    if (argc < 0 || (argc > 0 && argv == nullptr)) {
      return render_internal_exception(standard_error);
    }

    std::vector<std::string_view> arguments;
    if (argc > 1) {
      arguments.reserve(static_cast<std::size_t>(argc - 1));
    }
    for (int index = 1; index < argc; ++index) {
      if (argv[index] == nullptr) {
        return render_internal_exception(standard_error);
      }
      arguments.emplace_back(argv[index]);
    }

    Result<CliRequest> parsed = parse_cli(arguments);
    if (!parsed.has_value()) {
      standard_error << render_cli_diagnostic(parsed.error());
      return 2;
    }

    const CliMode& mode = parsed.value().mode;
    if (std::holds_alternative<Help>(mode)) {
      standard_output << kUsageText;
      return 0;
    }
    if (std::holds_alternative<Version>(mode)) {
      standard_output << render_version_information(build_information());
      return 0;
    }
    if (const auto* comparison = std::get_if<CompareCompression>(&mode)) {
      if (compare == nullptr) {
        return render_internal_exception(standard_error);
      }
      Result<void> result = compare(*comparison);
      if (!result) {
        standard_error << render_cli_diagnostic(result.error());
        return 1;
      }
      return 0;
    }

    if (analyze == nullptr) {
      return render_internal_exception(standard_error);
    }
    Result<void> result = analyze(std::get<Analyze>(mode));
    if (!result.has_value()) {
      standard_error << render_cli_diagnostic(result.error());
      return 1;
    }
    return 0;
  } catch (...) {
    return render_internal_exception(standard_error);
  }
}

int run_cli_boundary(const int argc, char* const* argv,
                     std::ostream& standard_output,
                     std::ostream& standard_error,
                     const PublishedAnalyzeEntrypoint analyze,
                     const CompareCompressionEntrypoint compare) noexcept {
  try {
    if (argc < 0 || (argc > 0 && argv == nullptr)) {
      return render_internal_exception(standard_error);
    }

    std::vector<std::string_view> arguments;
    if (argc > 1) {
      arguments.reserve(static_cast<std::size_t>(argc - 1));
    }
    for (int index = 1; index < argc; ++index) {
      if (argv[index] == nullptr) {
        return render_internal_exception(standard_error);
      }
      arguments.emplace_back(argv[index]);
    }

    Result<CliRequest> parsed = parse_cli(arguments);
    if (!parsed.has_value()) {
      standard_error << render_cli_diagnostic(parsed.error());
      return 2;
    }

    const CliMode& mode = parsed.value().mode;
    if (std::holds_alternative<Help>(mode)) {
      standard_output << kUsageText;
      return 0;
    }
    if (std::holds_alternative<Version>(mode)) {
      standard_output << render_version_information(build_information());
      return 0;
    }
    if (const auto* comparison = std::get_if<CompareCompression>(&mode)) {
      if (compare == nullptr) {
        return render_internal_exception(standard_error);
      }
      Result<void> result = compare(*comparison);
      if (!result) {
        standard_error << render_cli_diagnostic(result.error());
        return 1;
      }
      return 0;
    }

    if (analyze == nullptr) {
      return render_internal_exception(standard_error);
    }
    Result<PublishedAnalysisStatus> result =
        analyze(std::get<Analyze>(mode));
    if (!result.has_value()) {
      standard_error << render_cli_diagnostic(result.error());
      return 1;
    }
    switch (result.value()) {
      case PublishedAnalysisStatus::success: return 0;
      case PublishedAnalysisStatus::unavailable: return 3;
      case PublishedAnalysisStatus::failed: return 1;
    }
    return render_internal_exception(standard_error);
  } catch (...) {
    return render_internal_exception(standard_error);
  }
}

}  // namespace detail
}  // namespace mwperf
