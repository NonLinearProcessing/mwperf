#include "mwperf/kernel/causal_kernel_compiler.hpp"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "../arrival/core_internal.hpp"
#include "kernel/c17_core_internal.hpp"
#include "kernel/c17_temporal_bridge_internal.hpp"
#include "temporal/temporal_contract_internal.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/reduction/local_margin.hpp"
#include "mwperf/reduction/resource_coordinates.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic c17_diagnostic(
    const DiagnosticCategory category, std::string code,
    std::string message, std::vector<std::string> notes = {}) {
  return Diagnostic{.category = category,
                    .code = std::move(code),
                    .message = std::move(message),
                    .authored_path = std::nullopt,
                    .json_pointer = std::nullopt,
                    .notes = std::move(notes)};
}

template <typename T>
[[nodiscard]] Result<T> c17_invalid(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(c17_diagnostic(
      DiagnosticCategory::input_validation, std::move(code),
      std::move(message), std::move(notes)));
}

template <typename T>
[[nodiscard]] Result<T> c17_internal(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(c17_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

template <typename T>
[[nodiscard]] Result<T> c17_resource(std::string code,
                                     std::string message) {
  return Result<T>::failure(c17_diagnostic(
      DiagnosticCategory::resource_limit, std::move(code),
      std::move(message)));
}

[[nodiscard]] bool same_phase(const ArrivalPhase& left,
                              const ArrivalPhase& right) {
  const auto left_bytes = arrival_phase_canonical_state(left);
  const auto right_bytes = arrival_phase_canonical_state(right);
  return arrival_phase_family(left) == arrival_phase_family(right) &&
         std::equal(left_bytes.begin(), left_bytes.end(),
                    right_bytes.begin(), right_bytes.end());
}

[[nodiscard]] bool same_exact_phase(const ArrivalPhase& left,
                                    const ArrivalPhase& right) {
  const auto left_core = detail::ArrivalCoreAccess::phase_core(left);
  const auto right_core = detail::ArrivalCoreAccess::phase_core(right);
  return left_core && right_core && same_phase(left, right) &&
         left_core->binding == right_core->binding &&
         left_core->next_authored_slot == right_core->next_authored_slot;
}

[[nodiscard]] Result<Digest256> reduced_state_identity(
    const ReducedStateV1& state) {
  Sha256 hash;
  const auto append = [&hash](const std::span<const std::byte> bytes)
      -> Result<void> { return hash.update(bytes); };
  const auto codec_bytes =
      std::as_bytes(std::span(state.codec.id.data(), state.codec.id.size()));
  auto updated = append(codec_bytes);
  if (!updated) {
    return Result<Digest256>::failure(updated.error());
  }
  const std::array<std::byte, 4U> version{
      static_cast<std::byte>((state.codec.version >> 24U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 16U) & 0xffU),
      static_cast<std::byte>((state.codec.version >> 8U) & 0xffU),
      static_cast<std::byte>(state.codec.version & 0xffU)};
  updated = append(version);
  if (!updated) {
    return Result<Digest256>::failure(updated.error());
  }
  updated = append(state.canonical_value);
  if (!updated) {
    return Result<Digest256>::failure(updated.error());
  }
  return Result<Digest256>::success(hash.finalize());
}

[[nodiscard]] CausalBranchIdentityV1 child_branch(
    const CausalBranchIdentityV1& parent, const std::size_t atom) {
  CausalBranchIdentityV1 result = parent;
  result.atom_path.push_back(atom);
  return result;
}

[[nodiscard]] Result<void> require_upstream_branch(
    const CausalBranchIdentityV1& returned,
    const CausalBranchIdentityV1& expected, const CausalStageV1 stage) {
  if (!(returned == expected)) {
    return c17_invalid<void>(
        "c17.stage_branch_identity_mismatch",
        "a conditional-law outcome is not bound to its upstream branch",
        {"stage " + std::to_string(static_cast<unsigned int>(stage))});
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> require_child_branch(
    const CausalBranchIdentityV1& returned,
    const CausalBranchIdentityV1& parent, const CausalStageV1 stage) {
  if (returned.state_identity != parent.state_identity ||
      returned.atom_path.size() != parent.atom_path.size() + 1U ||
      !std::equal(parent.atom_path.begin(), parent.atom_path.end(),
                  returned.atom_path.begin())) {
    return c17_internal<void>(
        "c17.applied_stage_branch_invalid",
        "a realized stage did not retain its actual selected atom address",
        {"stage " + std::to_string(static_cast<unsigned int>(stage))});
  }
  return Result<void>::success();
}

template <typename Atom>
[[nodiscard]] Result<NormalizedPmf> normalize_atoms_once(
    const std::span<const Atom> atoms, const ExactRational& tolerance,
    PmfRepresentationBudget budget) {
  try {
    std::vector<AuthoredProbability> probabilities;
    probabilities.reserve(atoms.size());
    for (const Atom& atom : atoms) {
      if (atom.structural_support && atom.raw_mass.is_zero()) {
        return c17_invalid<NormalizedPmf>(
            "c17.claimed_positive_zero_mass",
            "a conditional-law atom with zero exact mass claimed positive "
            "structural support");
      }
      if (!atom.structural_support && atom.raw_mass.is_positive()) {
        return c17_invalid<NormalizedPmf>(
            "c17.nonstructural_positive_mass",
            "a conditional-law atom outside structural support has positive "
            "exact mass");
      }
      auto probability = AuthoredProbability::from_exact(atom.raw_mass);
      if (!probability) {
        return Result<NormalizedPmf>::failure(probability.error());
      }
      probabilities.push_back(std::move(probability).value());
    }
    return validate_and_normalize_pmf_with_budget(
        probabilities, tolerance, std::move(budget));
  } catch (const std::bad_alloc&) {
    return c17_resource<NormalizedPmf>(
        "c17.conditional_row_allocation_exhausted",
        "allocating an exact conditional row exceeded the host resource "
        "envelope");
  }
}

template <typename Atom>
[[nodiscard]] StageMassDiagnosticV1 stage_diagnostic(
    const CausalStageV1 stage,
    const CausalBranchIdentityV1& upstream,
    const std::span<const Atom> atoms, const NormalizedPmf& pmf) {
  std::vector<ExactRational> masses;
  std::vector<std::uint8_t> support;
  masses.reserve(atoms.size());
  support.reserve(atoms.size());
  for (const Atom& atom : atoms) {
    masses.push_back(atom.raw_mass);
    support.push_back(atom.structural_support ? 1U : 0U);
  }
  return StageMassDiagnosticV1{stage,
                               upstream,
                               std::move(masses),
                               std::move(support),
                               pmf.authored_sum(),
                               pmf.normalization_delta()};
}

[[nodiscard]] Result<Digest256> checked_schedule_identity(
    const ResolvedInstance& instance, const Schedule& schedule) {
  Sha256 hash;
  auto updated = hash.update(instance.fingerprints().combined.bytes());
  if (!updated) {
    return Result<Digest256>::failure(updated.error());
  }
  updated = hash.update(std::as_bytes(schedule.bytes()));
  if (!updated) {
    return Result<Digest256>::failure(updated.error());
  }
  return Result<Digest256>::success(hash.finalize());
}

[[nodiscard]] Result<void> validate_schedule_feasibility(
    const ResolvedInstance& instance, const Schedule& schedule) {
  const QueueDimensionToken dimension =
      QueueDimensionToken::from_instance(instance);
  if (!(schedule.dimension() == dimension) ||
      schedule.size() != dimension.cardinality()) {
    return c17_invalid<void>(
        "c17.action_schedule_dimension_mismatch",
        "the resolved action schedule is not bound to the compiled "
        "instance");
  }

  const bool feasible = std::visit(
      [&schedule]<typename Constraint>(const Constraint& constraint) {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::same_as<Type, ResolvedCrossbarConstraint>) {
          std::vector<std::uint8_t> inputs(constraint.inputs.size(), 0U);
          std::vector<std::uint8_t> outputs(constraint.outputs.size(), 0U);
          for (const ResolvedCrossbarEdge& edge : constraint.edges) {
            if (!schedule.at(edge.queue)) {
              continue;
            }
            const std::size_t in = edge.input.ordinal();
            const std::size_t out = edge.output.ordinal();
            if (in >= inputs.size() || out >= outputs.size() ||
                inputs[in] != 0U || outputs[out] != 0U) {
              return false;
            }
            inputs[in] = 1U;
            outputs[out] = 1U;
          }
          return true;
        } else if constexpr (std::same_as<Type,
                                          ResolvedIntervalConstraint>) {
          std::vector<const ResolvedInterval*> selected;
          for (const ResolvedInterval& interval : constraint.intervals) {
            if (schedule.at(interval.queue)) {
              selected.push_back(&interval);
            }
          }
          std::ranges::sort(
              selected, [](const ResolvedInterval* left,
                           const ResolvedInterval* right) {
                if (left->left != right->left) {
                  return left->left < right->left;
                }
                if (left->right != right->right) {
                  return left->right < right->right;
                }
                return left->queue < right->queue;
              });
          for (std::size_t index = 1U; index < selected.size(); ++index) {
            if (!(selected[index - 1U]->right <= selected[index]->left)) {
              return false;
            }
          }
          return true;
        } else if constexpr (std::same_as<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          std::vector<std::uint8_t> vertices(constraint.vertices.size(), 0U);
          for (const ResolvedNodeExclusiveLink& link : constraint.links) {
            if (!schedule.at(link.queue)) {
              continue;
            }
            const std::size_t u = link.u.ordinal();
            const std::size_t v = link.v.ordinal();
            if (u >= vertices.size() || v >= vertices.size() || u == v ||
                vertices[u] != 0U || vertices[v] != 0U) {
              return false;
            }
            vertices[u] = 1U;
            vertices[v] = 1U;
          }
          return true;
        } else if constexpr (std::same_as<Type,
                                          ResolvedConflictConstraint>) {
          for (const ResolvedConflictPair& conflict : constraint.conflicts) {
            if (schedule.at(conflict.first) &&
                schedule.at(conflict.second)) {
              return false;
            }
          }
          return true;
        } else {
          std::vector<BigInt> used(constraint.resources.size(), BigInt{0});
          if (constraint.capacity.size() != used.size()) {
            return false;
          }
          for (const ResolvedPackingDemand& demand : constraint.demands) {
            if (!schedule.at(demand.queue)) {
              continue;
            }
            if (demand.demand.size() != used.size()) {
              return false;
            }
            for (std::size_t resource = 0U; resource < used.size();
                 ++resource) {
              used[resource] += demand.demand[resource].value();
              if (used[resource] >
                  constraint.capacity[resource].value()) {
                return false;
              }
            }
          }
          return true;
        }
      },
      instance.constraint().value());
  if (!feasible) {
    return c17_invalid<void>(
        "c17.action_schedule_infeasible",
        "the resolved action is outside the configured common feasible "
        "schedule family");
  }
  return Result<void>::success();
}

[[nodiscard]] const PortableThreeBinScalarResponseV1* three_bin_payload(
    const SurrogatePlug& plug) {
  if (semantic_tag_v1(plug) != SemanticTagV1::scalar_backlog_response) {
    return nullptr;
  }
  return std::get_if<PortableThreeBinScalarResponseV1>(
      &portable_source_v1(plug).value());
}

[[nodiscard]] const PortableFinitePrefixConstantTailResponseV1*
finite_prefix_constant_tail_payload(const SurrogatePlug& plug) {
  if (semantic_tag_v1(plug) != SemanticTagV1::scalar_backlog_response) {
    return nullptr;
  }
  return std::get_if<PortableFinitePrefixConstantTailResponseV1>(
      &portable_source_v1(plug).value());
}

[[nodiscard]] Result<void> validate_target_backlog_binding(
    const ResolvedInstance& instance, const PlugDescriptor& descriptor,
    const TargetBacklogV1& backlog) {
  if (!backlog.matches(instance)) {
    return c17_invalid<void>(
        "c17.target_backlog_instance_mismatch",
        "the reduced target backlog is not bound to the resolved instance");
  }
  std::vector<BigNat> values(backlog.values().begin(),
                             backlog.values().end());
  auto expected = TargetBacklogV1::from_values(
      instance, descriptor.core.deployed_targets, std::move(values));
  if (!expected ||
      !backlog.has_target_order(expected.value().ordered_targets())) {
    return c17_invalid<void>(
        "c17.target_backlog_order_mismatch",
        "the reduced target backlog does not use the descriptor's exact "
        "deployed-target order");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::size_t> three_bin_target_ordinal(
    const PortableThreeBinScalarResponseV1& response,
    const ResolvedInstance& instance) {
  if (response.context.semantic != SemanticTagV1::scalar_backlog_response ||
      response.context.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      response.context.ordered_deployed_targets.size() != 1U ||
      !(response.context.ordered_deployed_targets.front() ==
        response.deployed_target) ||
      instance.targets().size() != 1U) {
    return c17_invalid<std::size_t>(
        "c17.three_bin_singleton_contract_required",
        "the version-1 three-bin adapter requires exactly one deployed "
        "runtime target");
  }
  for (std::size_t ordinal = 0U; ordinal < instance.queues().size();
       ++ordinal) {
    auto dense = instance.queues().index_at(ordinal);
    if (!dense) {
      return Result<std::size_t>::failure(dense.error());
    }
    if (instance.queues().queue_id(dense.value()) ==
        response.deployed_target) {
      if (instance.targets().values().front().queue != dense.value()) {
        return c17_invalid<std::size_t>(
            "c17.three_bin_target_binding_mismatch",
            "the deployed three-bin target differs from the resolved "
            "analysis target");
      }
      return Result<std::size_t>::success(ordinal);
    }
  }
  return c17_invalid<std::size_t>(
      "c17.three_bin_target_binding_mismatch",
      "the deployed three-bin target is absent from the resolved queue "
      "catalog");
}

[[nodiscard]] Result<ExactRational> three_bin_probability(
    const PortableThreeBinScalarResponseV1& response,
    const BigNat& backlog) {
  for (const ExactRational& coefficient : response.coefficients) {
    if (!coefficient.is_nonnegative() ||
        coefficient > ExactRational::one()) {
      return c17_invalid<ExactRational>(
          "c17.three_bin_probability_out_of_range",
          "each of s1, s2, and c must lie in the exact interval [0,1]");
    }
  }
  if (backlog.is_zero()) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  if (backlog.value() == 1) {
    return Result<ExactRational>::success(response.coefficients[0U]);
  }
  if (backlog.value() == 2) {
    return Result<ExactRational>::success(response.coefficients[1U]);
  }
  return Result<ExactRational>::success(response.coefficients[2U]);
}

[[nodiscard]] Result<std::size_t>
finite_prefix_constant_tail_target_ordinal(
    const PortableFinitePrefixConstantTailResponseV1& response,
    const ResolvedInstance& instance) {
  if (response.context.semantic != SemanticTagV1::scalar_backlog_response ||
      response.context.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      response.context.ordered_deployed_targets.size() != 1U ||
      !(response.context.ordered_deployed_targets.front() ==
        response.deployed_target) ||
      instance.targets().size() != 1U) {
    return c17_invalid<std::size_t>(
        "c17.finite_prefix_constant_tail_singleton_contract_required",
        "the version-1 finite-prefix/constant-tail adapter requires exactly "
        "one deployed runtime target");
  }
  for (std::size_t ordinal = 0U; ordinal < instance.queues().size();
       ++ordinal) {
    auto dense = instance.queues().index_at(ordinal);
    if (!dense) {
      return Result<std::size_t>::failure(dense.error());
    }
    if (instance.queues().queue_id(dense.value()) ==
        response.deployed_target) {
      if (instance.targets().values().front().queue != dense.value()) {
        return c17_invalid<std::size_t>(
            "c17.finite_prefix_constant_tail_target_binding_mismatch",
            "the deployed finite-prefix/constant-tail target differs from "
            "the resolved analysis target");
      }
      return Result<std::size_t>::success(ordinal);
    }
  }
  return c17_invalid<std::size_t>(
      "c17.finite_prefix_constant_tail_target_binding_mismatch",
      "the deployed finite-prefix/constant-tail target is absent from the "
      "resolved queue catalog");
}

[[nodiscard]] Result<ExactRational>
finite_prefix_constant_tail_probability(
    const PortableFinitePrefixConstantTailResponseV1& response,
    const BigNat& backlog) {
  auto cutoff = checked_index(response.response_cutoff, 6U);
  if (!cutoff || cutoff.value() < 2U || cutoff.value() > 5U ||
      response.service_by_level.size() != cutoff.value() + 1U ||
      response.constant_tail_from != response.response_cutoff + BigNat{1U} ||
      response.service_by_level.empty() ||
      !response.service_by_level.front().is_zero()) {
    return c17_invalid<ExactRational>(
        "c17.finite_prefix_constant_tail_shape_invalid",
        "the closed scalar response requires K in [2,5], mu(0)=0, exact "
        "levels through K, and one tail beginning at K+1");
  }
  const auto probability = [](const ExactRational& value) {
    return value.is_nonnegative() && value <= ExactRational::one();
  };
  if (!std::ranges::all_of(response.service_by_level, probability) ||
      !probability(response.constant_tail_service)) {
    return c17_invalid<ExactRational>(
        "c17.finite_prefix_constant_tail_probability_out_of_range",
        "every finite-prefix and constant-tail coefficient must lie in the "
        "exact interval [0,1]");
  }
  if (backlog <= response.response_cutoff) {
    auto level = checked_index(backlog, response.service_by_level.size());
    if (!level) {
      return Result<ExactRational>::failure(level.error());
    }
    return Result<ExactRational>::success(
        response.service_by_level[level.value()]);
  }
  if (backlog >= response.constant_tail_from) {
    return Result<ExactRational>::success(response.constant_tail_service);
  }
  return c17_invalid<ExactRational>(
      "c17.finite_prefix_constant_tail_level_unavailable",
      "the closed scalar response does not cover the requested backlog "
      "level");
}

[[nodiscard]] Result<void> validate_closed_three_bin_unit_state(
    const ExactCausalProgramV1& program,
    const ExactReducedCoordinatesV1& coordinates) {
  if (closed_scalar_response_mode_v1(program.mode) &&
      !coordinates.unresolved_fields.empty()) {
    return c17_invalid<void>(
        "c17.unit_residence_extra_state",
        "the framework-derived three-bin unit residence cannot retain "
        "provider Z or another surrogate-unresolved coordinate");
  }
  return Result<void>::success();
}

[[nodiscard]] CodecIdentityV1 closed_scalar_response_codec(
    const ExactCausalProgramModeV1 mode) {
  return mode == ExactCausalProgramModeV1::closed_three_bin_scalar
             ? CodecIdentityV1{
                   std::string(kThreeBinServiceResponseCodecIdV1), 1U}
             : CodecIdentityV1{
                   std::string(
                       kFinitePrefixConstantTailServiceResponseCodecIdV1),
                   1U};
}

[[nodiscard]] CanonicalRuntimeValueV1 closed_scalar_class_value(
    CodecIdentityV1 codec, const std::size_t target, const bool forced_in) {
  std::vector<std::byte> bytes(9U, std::byte{0});
  std::uint64_t ordinal = static_cast<std::uint64_t>(target);
  for (std::size_t offset = 0U; offset < 8U; ++offset) {
    bytes[7U - offset] = static_cast<std::byte>(ordinal & 0xffU);
    ordinal >>= 8U;
  }
  bytes[8U] = forced_in ? std::byte{1} : std::byte{0};
  return CanonicalRuntimeValueV1{
      std::move(codec), std::move(bytes)};
}

struct PreparedOpportunityParts final {
  std::vector<OpportunityLawAtomV1> atoms;
  PreparedOpportunitySamplerV1 sampler;
};

struct PreparedActionParts final {
  std::vector<ActionLawAtomV1> atoms;
  PreparedActionSamplerV1 sampler;
};

struct PreparedArrivalParts final {
  std::vector<ArrivalTransitionLawAtomV1> atoms;
  bool enumerable;
};

[[nodiscard]] Result<CanonicalRuntimeValueV1>
canonical_resolved_action_source(const ResolvedAction& action);

[[nodiscard]] Result<PreparedOpportunityParts>
prepare_closed_scalar_prearrival_parts(
    const SurrogatePlug& plug, const ResolvedInstance& instance,
    const ExactCausalProgramModeV1 mode,
    const ExactReducedCoordinatesV1& coordinates,
    const CausalBranchIdentityV1& branch,
    PreparedOpportunitySamplerV1 sampler = {}) {
  if (!closed_scalar_response_mode_v1(mode)) {
    return c17_invalid<PreparedOpportunityParts>(
        "c17.closed_scalar_program_required",
        "the framework-owned scalar composer requires a closed scalar "
        "program mode");
  }
  Result<std::size_t> target = [&]() -> Result<std::size_t> {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      const auto* response = three_bin_payload(plug);
      if (response == nullptr) {
        return c17_invalid<std::size_t>(
            "c17.three_bin_payload_required",
            "the closed three-bin program is not bound to a portable "
            "three-bin response");
      }
      return three_bin_target_ordinal(*response, instance);
    }
    const auto* response = finite_prefix_constant_tail_payload(plug);
    if (response == nullptr) {
      return c17_invalid<std::size_t>(
          "c17.finite_prefix_constant_tail_payload_required",
          "the closed finite-prefix/constant-tail program is not bound to "
          "its portable response");
    }
    return finite_prefix_constant_tail_target_ordinal(*response, instance);
  }();
  if (!target) {
    return Result<PreparedOpportunityParts>::failure(target.error());
  }
  if (!coordinates.backlog.matches(instance) ||
      coordinates.backlog.size() != 1U ||
      coordinates.backlog.target_at_target_ordinal(0U).ordinal() !=
          target.value()) {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return c17_invalid<PreparedOpportunityParts>(
          "c17.three_bin_target_projection_mismatch",
          "the singleton three-bin backlog is not bound to its deployed "
          "physical target");
    }
    return c17_invalid<PreparedOpportunityParts>(
        "c17.finite_prefix_constant_tail_target_projection_mismatch",
        "the singleton finite-prefix/constant-tail backlog is not bound to "
        "its deployed physical target");
  }
  const BigNat& target_backlog =
      coordinates.backlog.value_at_target_ordinal(0U);
  Result<ExactRational> probability = [&]() -> Result<ExactRational> {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return three_bin_probability(*three_bin_payload(plug), target_backlog);
    }
    return finite_prefix_constant_tail_probability(
        *finite_prefix_constant_tail_payload(plug), target_backlog);
  }();
  if (!probability) {
    return Result<PreparedOpportunityParts>::failure(probability.error());
  }

  std::vector<OpportunityLawAtomV1> atoms;
  const auto append = [&](const bool forced_in, ExactRational mass) {
    const bool support = mass.is_positive();
    atoms.push_back(OpportunityLawAtomV1{
        OpportunityMark{branch, coordinates.backlog, std::nullopt,
                        std::nullopt,
                        closed_scalar_class_value(
                            closed_scalar_response_codec(mode),
                            target.value(), forced_in), {}},
        std::move(mass), support});
  };
  if (target_backlog.is_zero()) {
    append(false, ExactRational::one());
  } else {
    append(false, ExactRational::one() - probability.value());
    append(true, probability.value());
  }
  return Result<PreparedOpportunityParts>::success(
      PreparedOpportunityParts{std::move(atoms), std::move(sampler)});
}

[[nodiscard]] Result<ResolvedAction> resolve_closed_scalar_action(
    const ResolvedInstance& instance,
    const ExactReducedCoordinatesV1& coordinates,
    const OpportunityMark& opportunity,
    const ExactCausalProgramModeV1 mode) {
  if (!closed_scalar_response_mode_v1(mode) ||
      opportunity.opportunity.codec != closed_scalar_response_codec(mode) ||
      opportunity.opportunity.canonical_value.size() != 9U) {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return c17_invalid<ResolvedAction>(
          "c17.three_bin_opportunity_codec_mismatch",
          "the closed three-bin resolver received an opportunity outside "
          "its singleton forced-class codec");
    }
    return c17_invalid<ResolvedAction>(
        "c17.finite_prefix_constant_tail_opportunity_codec_mismatch",
        "the closed finite-prefix/constant-tail resolver received an "
        "opportunity outside its singleton forced-class codec");
  }
  std::uint64_t target = 0U;
  for (std::size_t offset = 0U; offset < 8U; ++offset) {
    target = (target << 8U) |
             std::to_integer<std::uint8_t>(
                 opportunity.opportunity.canonical_value[offset]);
  }
  if (!coordinates.backlog.matches(instance) ||
      coordinates.backlog.size() != 1U ||
      target >= instance.queues().size() ||
      coordinates.backlog.target_at_target_ordinal(0U).ordinal() != target) {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return c17_invalid<ResolvedAction>(
          "c17.three_bin_target_binding_mismatch",
          "the three-bin forced-class target lies outside the reduced "
          "backlog");
    }
    return c17_invalid<ResolvedAction>(
        "c17.finite_prefix_constant_tail_target_binding_mismatch",
        "the finite-prefix/constant-tail forced-class target lies outside "
        "the reduced backlog");
  }
  const std::uint8_t class_bit = std::to_integer<std::uint8_t>(
      opportunity.opportunity.canonical_value[8U]);
  if (class_bit > 1U) {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return c17_invalid<ResolvedAction>(
          "c17.three_bin_forced_class_invalid",
          "the three-bin opportunity class must be forced-out or forced-in");
    }
    return c17_invalid<ResolvedAction>(
        "c17.finite_prefix_constant_tail_forced_class_invalid",
        "the finite-prefix/constant-tail opportunity class must be "
        "forced-out or forced-in");
  }
  const bool forced_in = class_bit != 0U;
  auto dense = instance.queues().index_at(static_cast<std::size_t>(target));
  if (!dense) {
    return Result<ResolvedAction>::failure(dense.error());
  }
  if (forced_in &&
      (!instance.serviceable().at(dense.value()) ||
       coordinates.backlog.value_at_target_ordinal(0U).is_zero())) {
    if (mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return c17_invalid<ResolvedAction>(
          "c17.three_bin_forced_in_ineligible",
          "a three-bin forced-in action requires an individually "
          "serviceable nonempty target");
    }
    return c17_invalid<ResolvedAction>(
        "c17.finite_prefix_constant_tail_forced_in_ineligible",
        "a finite-prefix/constant-tail forced-in action requires an "
        "individually serviceable nonempty target");
  }

  std::vector<std::uint8_t> bits(instance.queues().size(), 0U);
  bits[static_cast<std::size_t>(target)] = forced_in ? 1U : 0U;
  auto schedule = Schedule::from_bytes(
      QueueDimensionToken::from_instance(instance), std::move(bits));
  if (!schedule) {
    return Result<ResolvedAction>::failure(schedule.error());
  }
  auto feasible = validate_schedule_feasibility(instance, schedule.value());
  if (!feasible) {
    return Result<ResolvedAction>::failure(feasible.error());
  }
  const Schedule departure = schedule.value();
  auto identity = checked_schedule_identity(instance, schedule.value());
  if (!identity) {
    return Result<ResolvedAction>::failure(identity.error());
  }
  ResolvedAction action{
      opportunity.branch,
      schedule.value(),
      departure,
      std::move(identity).value(),
      ResolvedActionEvidenceV1{
          forced_in ? ActionResolutionKindV1::three_bin_forced_in
                    : ActionResolutionKindV1::three_bin_forced_out,
          false,
          forced_in ? AlgebraicTargetClass::forced_in
                    : AlgebraicTargetClass::forced_out,
          std::nullopt},
      CanonicalRuntimeValueV1{
          CodecIdentityV1{std::string(kC17ResolvedActionCodecIdV1),
                          kC17ResolvedActionCodecVersionV1},
          {}},
      std::nullopt,
      std::nullopt,
      {}};
  auto canonical = canonical_resolved_action_source(action);
  if (!canonical) {
    return Result<ResolvedAction>::failure(canonical.error());
  }
  action.decision = std::move(canonical).value();
  return Result<ResolvedAction>::success(std::move(action));
}

[[nodiscard]] Result<PreparedActionParts> prepare_closed_scalar_action_parts(
    const ResolvedInstance& instance,
    const ExactReducedCoordinatesV1& coordinates,
    const OpportunityMark& opportunity,
    const ExactCausalProgramModeV1 mode,
    PreparedActionSamplerV1 sampler = {}) {
  auto action = resolve_closed_scalar_action(instance, coordinates,
                                             opportunity, mode);
  if (!action) {
    return Result<PreparedActionParts>::failure(action.error());
  }
  std::vector<ActionLawAtomV1> atoms;
  atoms.push_back(ActionLawAtomV1{std::move(action).value(),
                                  ExactRational::one(), true});
  return Result<PreparedActionParts>::success(
      PreparedActionParts{std::move(atoms), std::move(sampler)});
}

[[nodiscard]] std::vector<PostClosureCandidateLawAtomV1>
identity_postclosure_atoms(const CausalBranchIdentityV1& branch) {
  std::vector<PostClosureCandidateLawAtomV1> atoms;
  atoms.push_back(PostClosureCandidateLawAtomV1{
      PostClosureCandidateV1{branch, {}, {}}, ExactRational::one(), true});
  return atoms;
}

void append_u64(std::vector<std::byte>& bytes, std::uint64_t value) {
  for (std::size_t offset = 0U; offset < 8U; ++offset) {
    bytes.push_back(static_cast<std::byte>((value >> (56U - 8U * offset)) &
                                           0xffU));
  }
}

class C17RuntimeValueEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }

  void boolean(const bool value) { byte(value ? 1U : 0U); }

  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  void count(const std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }

  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(const Enum value) {
    using Underlying = std::underlying_type_t<Enum>;
    using Unsigned = std::make_unsigned_t<Underlying>;
    u64(static_cast<std::uint64_t>(static_cast<Unsigned>(value)));
  }

  void raw(const std::span<const std::byte> value) {
    count(value.size());
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }

  void raw_u8(const std::span<const std::uint8_t> value) {
    count(value.size());
    for (const std::uint8_t item : value) {
      byte(item);
    }
  }

  void string(const std::string_view value) {
    count(value.size());
    for (const char character : value) {
      byte(static_cast<std::uint8_t>(
          static_cast<unsigned char>(character)));
    }
  }

  void digest(const Digest256& value) { raw(value.bytes()); }

  void codec(const CodecIdentityV1& value) {
    string(value.id);
    u32(value.version);
  }

  template <StrongIdDomainName Domain>
  void id(const StrongId<Domain>& value) {
    const std::vector<std::uint8_t> bytes = value.canonical_bytes();
    raw_u8(bytes);
  }

  void natural(const BigNat& value) {
    const std::vector<std::uint8_t> bytes =
        value.canonical_magnitude_bytes();
    raw_u8(bytes);
  }

  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }

  void runtime_value(const CanonicalRuntimeValueV1& value) {
    codec(value.codec);
    raw(value.canonical_value);
  }

  void optional_runtime_value(
      const std::optional<CanonicalRuntimeValueV1>& value) {
    boolean(value.has_value());
    if (value.has_value()) {
      runtime_value(*value);
    }
  }

  [[nodiscard]] std::vector<std::byte> finish() && {
    return std::move(bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

void encode_arrival_binding(C17RuntimeValueEncoder& encoder,
                            const ArrivalBinding& binding) {
  encoder.enumeration(binding.family);
  encoder.enumeration(binding.timing);
  encoder.count(binding.queue_cardinality);
  encoder.digest(binding.law_digest.value());
  encoder.digest(binding.catalog_digest.value());
}

void encode_schedule(C17RuntimeValueEncoder& encoder,
                     const Schedule& schedule) {
  encoder.raw_u8(schedule.bytes());
}

[[nodiscard]] bool queue_id_list_less(
    const std::span<const QueueId> left,
    const std::span<const QueueId> right) {
  return std::lexicographical_compare(
      left.begin(), left.end(), right.begin(), right.end(),
      [](const QueueId& a, const QueueId& b) {
        const std::vector<std::uint8_t> a_bytes = a.canonical_bytes();
        const std::vector<std::uint8_t> b_bytes = b.canonical_bytes();
        return std::lexicographical_compare(
            a_bytes.begin(), a_bytes.end(), b_bytes.begin(), b_bytes.end());
      });
}

void canonicalize_emitted_face(V0EmittedOpportunityFaceV1& face) {
  std::sort(face.alternatives.begin(), face.alternatives.end(),
            [](const V0ScheduleFaceAtomV1& left,
               const V0ScheduleFaceAtomV1& right) {
              return queue_id_list_less(left.selected_full_schedule,
                                        right.selected_full_schedule);
            });
}

void encode_emitted_face(C17RuntimeValueEncoder& encoder,
                         const V0EmittedOpportunityFaceV1& face) {
  V0EmittedOpportunityFaceV1 canonical = face;
  canonicalize_emitted_face(canonical);
  encoder.count(canonical.alternatives.size());
  for (const V0ScheduleFaceAtomV1& alternative : canonical.alternatives) {
    encoder.count(alternative.selected_full_schedule.size());
    for (const QueueId& queue : alternative.selected_full_schedule) {
      encoder.id(queue);
    }
    encoder.count(alternative.non_target_departures.size());
    for (const QueueId& queue : alternative.non_target_departures) {
      encoder.id(queue);
    }
    encoder.rational(alternative.target_free_primary_score);
  }
}

[[nodiscard]] Result<CanonicalRuntimeValueV1>
canonical_emitted_opportunity_source(const OpportunityMark& opportunity) {
  if (!opportunity.resolver_face.has_value()) {
    return c17_invalid<CanonicalRuntimeValueV1>(
        "c17.cplus_emitted_opportunity_face_missing",
        "C-plus requires the complete emitted resolver face selected at "
        "C-minus");
  }
  try {
    C17RuntimeValueEncoder encoder;
    encoder.u32(kC17EmittedOpportunityCodecVersionV1);
    encoder.runtime_value(opportunity.opportunity);
    encode_emitted_face(encoder, *opportunity.resolver_face);
    return Result<CanonicalRuntimeValueV1>::success(
        CanonicalRuntimeValueV1{
            CodecIdentityV1{std::string(kC17EmittedOpportunityCodecIdV1),
                            kC17EmittedOpportunityCodecVersionV1},
            std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return c17_resource<CanonicalRuntimeValueV1>(
        "c17.emitted_opportunity_source_allocation_exhausted",
        "forming the lossless emitted-opportunity source exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<CanonicalRuntimeValueV1>
canonical_resolved_action_source(const ResolvedAction& action) {
  try {
    C17RuntimeValueEncoder encoder;
    encoder.u32(kC17ResolvedActionCodecVersionV1);
    encode_schedule(encoder, action.schedule);
    encode_schedule(encoder, action.actual_departure);
    encoder.digest(action.schedule_identity);
    encoder.enumeration(action.evidence.resolution_kind);
    encoder.boolean(action.evidence.common_feasible_schedule);
    encoder.boolean(action.evidence.exact_target_class.has_value());
    if (action.evidence.exact_target_class.has_value()) {
      encoder.enumeration(*action.evidence.exact_target_class);
    }
    encoder.boolean(action.evidence.emitted_face.has_value());
    if (action.evidence.emitted_face.has_value()) {
      const EmittedScheduleFaceDecisionV1& face =
          *action.evidence.emitted_face;
      encoder.count(face.ordered_target_faces.size());
      for (const EmittedTargetFaceEvidenceV1& target :
           face.ordered_target_faces) {
        encoder.count(target.target.ordinal());
        encoder.rational(target.forced_out_residual_max);
        encoder.rational(target.forced_in_residual_max);
        encoder.rational(target.algebraic_margin);
        encoder.enumeration(target.exact_class);
        encoder.boolean(target.target_eligible);
      }
      encoder.rational(face.selected_primary_score);
      encoder.natural(face.configured_secondary_code);
    }
    encoder.optional_runtime_value(action.interim_controller);
    encoder.optional_runtime_value(action.postupdate_controller_tape);
    return Result<CanonicalRuntimeValueV1>::success(
        CanonicalRuntimeValueV1{
            CodecIdentityV1{std::string(kC17ResolvedActionCodecIdV1),
                            kC17ResolvedActionCodecVersionV1},
            std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return c17_resource<CanonicalRuntimeValueV1>(
        "c17.resolved_action_source_allocation_exhausted",
        "forming the lossless resolved-action source exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<CanonicalRuntimeValueV1>
canonical_arrival_transition_source(
    const BigNat& authored_slot, const ArrivalBatch& batch,
    const ArrivalPhase& before, const ArrivalPhase& after,
    const ArrivalLawDigest& law_digest,
    const Digest256& realization_identity) {
  const auto before_core = detail::ArrivalCoreAccess::phase_core(before);
  const auto after_core = detail::ArrivalCoreAccess::phase_core(after);
  if (!before_core || !after_core || !batch.binding().has_value()) {
    return c17_invalid<CanonicalRuntimeValueV1>(
        "c17.arrival_source_record_incomplete",
        "the canonical configured-arrival source requires complete bound "
        "batch and phase records");
  }
  const ArrivalBinding& binding = *batch.binding();
  BigNat expected_after_slot = authored_slot;
  ++expected_after_slot;
  if (!(before_core->binding == binding) ||
      !(after_core->binding == binding) ||
      before_core->family != binding.family ||
      after_core->family != binding.family ||
      !(law_digest == binding.law_digest) ||
      !(before_core->next_authored_slot == authored_slot) ||
      !(after_core->next_authored_slot == expected_after_slot) ||
      !arrival_phases_share_cursor(before, after)) {
    return c17_invalid<CanonicalRuntimeValueV1>(
        "c17.arrival_source_record_binding_mismatch",
        "the canonical configured-arrival source must retain one binding, "
        "slot progression, and cursor lineage");
  }
  try {
    C17RuntimeValueEncoder encoder;
    encoder.u32(kC17ConfiguredArrivalTransitionCodecVersionV1);
    encoder.natural(authored_slot);
    encode_arrival_binding(encoder, binding);
    encoder.count(batch.entries().size());
    for (const ArrivalBatchEntry& entry : batch.entries()) {
      encoder.count(entry.queue.ordinal());
      encoder.natural(entry.count);
    }
    encoder.enumeration(before_core->family);
    encoder.raw(before_core->canonical_state);
    encoder.natural(before_core->next_authored_slot);
    encoder.enumeration(after_core->family);
    encoder.raw(after_core->canonical_state);
    encoder.natural(after_core->next_authored_slot);
    encoder.boolean(true);
    encoder.digest(law_digest.value());
    encoder.digest(realization_identity);
    return Result<CanonicalRuntimeValueV1>::success(
        CanonicalRuntimeValueV1{
            CodecIdentityV1{
                std::string(kC17ConfiguredArrivalTransitionCodecIdV1),
                kC17ConfiguredArrivalTransitionCodecVersionV1},
            std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return c17_resource<CanonicalRuntimeValueV1>(
        "c17.arrival_source_record_allocation_exhausted",
        "forming the lossless configured-arrival source exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<std::vector<std::size_t>>
canonical_queue_ordinals(const ResolvedInstance& instance,
                         const std::span<const QueueId> queue_ids,
                         const std::string_view diagnostic_code,
                         const std::string_view subject) {
  std::vector<std::size_t> ordinals;
  ordinals.reserve(queue_ids.size());
  for (const QueueId& queue_id : queue_ids) {
    std::optional<std::size_t> ordinal;
    const auto entries = instance.queues().entries();
    for (std::size_t index = 0U; index < entries.size(); ++index) {
      if (entries[index].id == queue_id) {
        ordinal = index;
        break;
      }
    }
    if (!ordinal.has_value() ||
        (!ordinals.empty() && ordinals.back() >= *ordinal)) {
      return c17_invalid<std::vector<std::size_t>>(
          std::string(diagnostic_code),
          std::string(subject) +
              " must be a unique queue-ID list in canonical catalog order");
    }
    ordinals.push_back(*ordinal);
  }
  return Result<std::vector<std::size_t>>::success(std::move(ordinals));
}

[[nodiscard]] std::optional<std::size_t> target_position(
    const TargetBacklogV1& backlog, const std::size_t physical_ordinal) {
  for (std::size_t target = 0U; target < backlog.size(); ++target) {
    if (backlog.target_at_target_ordinal(target).ordinal() ==
        physical_ordinal) {
      return target;
    }
  }
  return std::nullopt;
}

[[nodiscard]] Result<BigNat> configured_priority_code(
    const ResolvedInstance& instance, const Schedule& actual_departure) {
  if (!actual_departure.dimension().matches(instance) ||
      actual_departure.size() != instance.priority().size()) {
    return c17_invalid<BigNat>(
        "c17.emitted_face_priority_dimension_mismatch",
        "the emitted-face departure does not match the configured priority "
        "dimension");
  }
  BigInt next_bit = 1;
  next_bit <<= instance.priority().size();
  if (instance.priority().size() != 0U) {
    next_bit >>= 1U;
  }
  BigInt code = 0;
  for (std::size_t rank = 0U; rank < instance.priority().size(); ++rank) {
    const std::size_t physical =
        instance.priority().queue_at_rank(rank).ordinal();
    if (actual_departure.bytes()[physical] != 0U) {
      code += next_bit;
    }
    next_bit >>= 1U;
  }
  return BigNat::from_big_int(std::move(code));
}

struct ResolvedFaceCandidate final {
  Schedule original_schedule;
  Schedule executable_schedule;
  Schedule actual_departure;
  ExactRational exact_score;
  BigNat secondary_code;
};

[[nodiscard]] Result<void> corroborate_exact_opportunity_evidence(
    const ResolvedInstance& instance, const TargetBacklogV1& backlog,
    const Opportunity& exact,
    const EmittedScheduleFaceDecisionV1& emitted,
    const ResolvedAction& action) {
  if (backlog.size() != 1U ||
      emitted.ordered_target_faces.size() != 1U ||
      emitted.ordered_target_faces.front().target !=
          backlog.target_at_target_ordinal(0U) ||
      exact.target() != backlog.target_at_target_ordinal(0U) ||
      !exact.target().matches(instance) ||
      !backlog.matches_full_backlog_projection(
          exact.evaluation_backlog())) {
    return c17_invalid<void>(
        "c17.resolver_opportunity_evidence_binding_mismatch",
        "optional physical opportunity evidence must agree with the emitted "
        "face target projection");
  }
  const auto target = std::ranges::find_if(
      emitted.ordered_target_faces,
      [&](const EmittedTargetFaceEvidenceV1& candidate) {
        return candidate.target == exact.target();
      });
  if (target == emitted.ordered_target_faces.end()) {
    return c17_invalid<void>(
        "c17.resolver_opportunity_evidence_target_missing",
        "optional physical opportunity evidence names no emitted target "
        "face");
  }
  const auto integer_rational = [](const BigInt& value) {
    return ExactRational::make(value, BigInt{1});
  };
  auto psi0 = integer_rational(exact.psi0().value());
  auto psi1 = integer_rational(exact.psi1().value());
  auto margin = integer_rational(exact.margin());
  if (!psi0 || !psi1 || !margin) {
    return c17_internal<void>(
        "c17.resolver_opportunity_integer_encoding_failed",
        "an exact integer opportunity value could not be represented as a "
        "rational");
  }
  const CrossClassOutcome& outcome = exact.cross_class_outcome();
  if (!(target->forced_out_residual_max == psi0.value()) ||
      !(target->forced_in_residual_max == psi1.value()) ||
      !(target->algebraic_margin == margin.value()) ||
      target->exact_class != outcome.algebraic_class ||
      target->target_eligible != outcome.target_eligible) {
    return c17_invalid<void>(
        "c17.resolver_opportunity_evidence_mismatch",
        "optional physical opportunity evidence does not corroborate the "
        "emitted face maxima, sign, or eligibility");
  }
  auto departure =
      compute_actual_departure(exact.evaluation_backlog(), action.schedule);
  if (!departure || !(departure.value() == action.actual_departure)) {
    return c17_invalid<void>(
        "c17.resolver_opportunity_departure_mismatch",
        "optional physical opportunity evidence does not reproduce the "
        "emitted action's common departure");
  }
  if (outcome.target_eligible &&
      (!(outcome.configured_winning_schedule == action.schedule) ||
       !(outcome.configured_winning_secondary_code ==
         emitted.configured_secondary_code))) {
    return c17_invalid<void>(
        "c17.resolver_opportunity_winner_mismatch",
        "optional eligible physical opportunity evidence names another "
        "configured schedule winner");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ResolvedAction> resolve_emitted_face_action(
    const ResolvedInstance& instance, const TargetBacklogV1& backlog,
    const OpportunityMark& opportunity) {
  if (!backlog.matches(instance)) {
    return c17_invalid<ResolvedAction>(
        "c17.resolver_target_backlog_binding_mismatch",
        "the emitted-face resolver target backlog is not bound to the "
        "resolved instance");
  }
  if (!opportunity.resolver_face.has_value() ||
      opportunity.resolver_face->alternatives.empty()) {
    return c17_invalid<ResolvedAction>(
        "c17.resolver_emitted_face_required",
        "the generic configured resolver requires a nonempty emitted "
        "schedule face");
  }
  const QueueDimensionToken dimension =
      QueueDimensionToken::from_instance(instance);
  const V0EmittedOpportunityFaceV1& face = *opportunity.resolver_face;
  std::vector<ResolvedFaceCandidate> candidates;
  candidates.reserve(face.alternatives.size());
  std::vector<std::optional<ExactRational>> forced_out(backlog.size());
  std::vector<std::optional<ExactRational>> forced_in(backlog.size());

  for (const V0ScheduleFaceAtomV1& alternative : face.alternatives) {
    auto selected_ordinals = canonical_queue_ordinals(
        instance, alternative.selected_full_schedule,
        "c17.emitted_face_schedule_not_canonical",
        "an emitted-face selected schedule");
    if (!selected_ordinals) {
      return Result<ResolvedAction>::failure(selected_ordinals.error());
    }
    std::vector<std::uint8_t> original_bits(instance.queues().size(), 0U);
    for (const std::size_t ordinal : selected_ordinals.value()) {
      original_bits[ordinal] = 1U;
    }
    auto original = Schedule::from_bytes(dimension, original_bits);
    if (!original) {
      return Result<ResolvedAction>::failure(original.error());
    }
    for (const ResolvedFaceCandidate& prior : candidates) {
      if (prior.original_schedule == original.value()) {
        return c17_invalid<ResolvedAction>(
            "c17.emitted_face_duplicate_schedule",
            "an emitted resolver face may contain each complete schedule "
            "only once");
      }
    }
    auto feasible = validate_schedule_feasibility(instance, original.value());
    if (!feasible) {
      return Result<ResolvedAction>::failure(feasible.error());
    }

    auto non_target_ordinals = canonical_queue_ordinals(
        instance, alternative.non_target_departures,
        "c17.emitted_face_departures_not_canonical",
        "an emitted-face non-target departure set");
    if (!non_target_ordinals) {
      return Result<ResolvedAction>::failure(non_target_ordinals.error());
    }
    std::vector<std::uint8_t> departure_bits(instance.queues().size(), 0U);
    for (const std::size_t ordinal : non_target_ordinals.value()) {
      if (target_position(backlog, ordinal).has_value() ||
          original_bits[ordinal] == 0U) {
        return c17_invalid<ResolvedAction>(
            "c17.emitted_face_non_target_departure_invalid",
            "declared non-target departures must be target-disjoint members "
            "of the selected complete schedule");
      }
      departure_bits[ordinal] = 1U;
    }
    for (std::size_t target = 0U; target < backlog.size(); ++target) {
      const std::size_t physical =
          backlog.target_at_target_ordinal(target).ordinal();
      departure_bits[physical] =
          original_bits[physical] != 0U &&
                  !backlog.value_at_target_ordinal(target).is_zero()
              ? 1U
              : 0U;
    }
    auto departure = Schedule::from_bytes(dimension, std::move(departure_bits));
    if (!departure) {
      return Result<ResolvedAction>::failure(departure.error());
    }
    feasible = validate_schedule_feasibility(instance, departure.value());
    if (!feasible) {
      return Result<ResolvedAction>::failure(feasible.error());
    }

    ExactRational score = alternative.target_free_primary_score;
    for (std::size_t target = 0U; target < backlog.size(); ++target) {
      auto target_value = ExactRational::make(
          backlog.value_at_target_ordinal(target).value(), BigInt{1});
      if (!target_value) {
        return Result<ResolvedAction>::failure(target_value.error());
      }
      ExactRational residual = alternative.target_free_primary_score;
      for (std::size_t other = 0U; other < backlog.size(); ++other) {
        if (other == target) {
          continue;
        }
        const std::size_t physical =
            backlog.target_at_target_ordinal(other).ordinal();
        if (original_bits[physical] != 0U) {
          auto other_value = ExactRational::make(
              backlog.value_at_target_ordinal(other).value(), BigInt{1});
          if (!other_value) {
            return Result<ResolvedAction>::failure(other_value.error());
          }
          residual = residual + other_value.value();
        }
      }
      const std::size_t physical =
          backlog.target_at_target_ordinal(target).ordinal();
      std::optional<ExactRational>& maximum =
          original_bits[physical] == 0U ? forced_out[target]
                                        : forced_in[target];
      if (!maximum.has_value() || residual > *maximum) {
        maximum = std::move(residual);
      }
      if (original_bits[physical] != 0U) {
        score = score + target_value.value();
      }
    }
    auto secondary = configured_priority_code(instance, departure.value());
    if (!secondary) {
      return Result<ResolvedAction>::failure(secondary.error());
    }
    candidates.push_back(ResolvedFaceCandidate{
        std::move(original).value(), departure.value(),
        std::move(departure).value(), std::move(score),
        std::move(secondary).value()});
  }

  std::size_t selected = 0U;
  for (std::size_t index = 1U; index < candidates.size(); ++index) {
    if (candidates[index].exact_score > candidates[selected].exact_score ||
        (candidates[index].exact_score == candidates[selected].exact_score &&
         candidates[index].secondary_code >
             candidates[selected].secondary_code)) {
      selected = index;
    }
  }
  for (std::size_t index = 0U; index < candidates.size(); ++index) {
    if (index == selected ||
        !(candidates[index].exact_score ==
          candidates[selected].exact_score) ||
        !(candidates[index].secondary_code ==
          candidates[selected].secondary_code)) {
      continue;
    }
    if (!(candidates[index].executable_schedule ==
          candidates[selected].executable_schedule) ||
        !(candidates[index].actual_departure ==
          candidates[selected].actual_departure)) {
      return c17_invalid<ResolvedAction>(
          "c17.emitted_face_incomplete_priority_tie",
          "exact primary score and configured priority do not select one "
          "observable emitted-face action");
    }
  }

  std::vector<EmittedTargetFaceEvidenceV1> target_faces;
  target_faces.reserve(backlog.size());
  for (std::size_t target = 0U; target < backlog.size(); ++target) {
    if (!forced_out[target].has_value() || !forced_in[target].has_value()) {
      return c17_invalid<ResolvedAction>(
          "c17.emitted_face_target_side_missing",
          "the emitted resolver face must contain both target-bit sides for "
          "every deployed target");
    }
    auto target_value = ExactRational::make(
        backlog.value_at_target_ordinal(target).value(), BigInt{1});
    if (!target_value) {
      return Result<ResolvedAction>::failure(target_value.error());
    }
    ExactRational margin = target_value.value() + *forced_in[target] -
                           *forced_out[target];
    AlgebraicTargetClass exact_class = AlgebraicTargetClass::tie;
    if (margin < ExactRational::zero()) {
      exact_class = AlgebraicTargetClass::forced_out;
    } else if (margin > ExactRational::zero()) {
      exact_class = AlgebraicTargetClass::forced_in;
    }
    target_faces.push_back(EmittedTargetFaceEvidenceV1{
        backlog.target_at_target_ordinal(target), *forced_out[target],
        *forced_in[target], std::move(margin), exact_class,
        !backlog.value_at_target_ordinal(target).is_zero()});
  }

  EmittedScheduleFaceDecisionV1 emitted{
      std::move(target_faces), candidates[selected].exact_score,
      candidates[selected].secondary_code};
  std::optional<AlgebraicTargetClass> single_target_class;
  if (emitted.ordered_target_faces.size() == 1U) {
    single_target_class = emitted.ordered_target_faces.front().exact_class;
  }
  auto identity = checked_schedule_identity(
      instance, candidates[selected].executable_schedule);
  if (!identity) {
    return Result<ResolvedAction>::failure(identity.error());
  }
  ResolvedAction action{
      opportunity.branch,
      candidates[selected].executable_schedule,
      candidates[selected].actual_departure,
      std::move(identity).value(),
      ResolvedActionEvidenceV1{
          ActionResolutionKindV1::emitted_schedule_face, true,
          std::move(single_target_class), emitted},
      CanonicalRuntimeValueV1{
          CodecIdentityV1{std::string(kC17ResolvedActionCodecIdV1),
                          kC17ResolvedActionCodecVersionV1},
          {}},
      std::nullopt,
      std::nullopt,
      {}};
  if (opportunity.exact_opportunity_evidence.has_value()) {
    auto corroborated = corroborate_exact_opportunity_evidence(
        instance, backlog, *opportunity.exact_opportunity_evidence,
        emitted, action);
    if (!corroborated) {
      return Result<ResolvedAction>::failure(corroborated.error());
    }
  }
  auto canonical = canonical_resolved_action_source(action);
  if (!canonical) {
    return Result<ResolvedAction>::failure(canonical.error());
  }
  action.decision = std::move(canonical).value();
  return Result<ResolvedAction>::success(std::move(action));
}

[[nodiscard]] Result<Digest256> arrival_transition_identity(
    const BigNat& slot, const ArrivalBatch& batch,
    const ArrivalPhase& before, const ArrivalPhase& after,
    const ArrivalLawDigest& law_digest) {
  try {
    std::vector<std::byte> bytes;
    const auto append_framed = [&bytes](const std::span<const std::byte> value) {
      append_u64(bytes, static_cast<std::uint64_t>(value.size()));
      bytes.insert(bytes.end(), value.begin(), value.end());
    };
    const std::vector<std::uint8_t> slot_bytes =
        slot.canonical_magnitude_bytes();
    append_framed(std::as_bytes(std::span(slot_bytes)));
    append_framed(arrival_phase_canonical_state(before));
    append_framed(arrival_phase_canonical_state(after));
    append_framed(law_digest.value().bytes());
    append_u64(bytes, static_cast<std::uint64_t>(batch.entries().size()));
    for (const ArrivalBatchEntry& entry : batch.entries()) {
      append_u64(bytes, static_cast<std::uint64_t>(entry.queue.ordinal()));
      const std::vector<std::uint8_t> count =
          entry.count.canonical_magnitude_bytes();
      append_framed(std::as_bytes(std::span(count)));
    }
    return sha256_domain_separated("mwperf.c17.arrival-transition.v1",
                                   bytes);
  } catch (const std::bad_alloc&) {
    return c17_resource<Digest256>(
        "c17.arrival_identity_allocation_exhausted",
        "forming the exact arrival-transition identity exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<ArrivalPhase> make_successor_phase(
    const std::shared_ptr<const detail::CompiledArrivalLawCore>& law,
    const std::shared_ptr<const detail::ArrivalPhaseCore>& before,
    std::vector<std::byte> canonical_after,
    detail::ArrivalCursorState cursor = {}) {
  if (!law->runtime.encode_phase) {
    return c17_invalid<ArrivalPhase>(
        "c17.configured_arrival_phase_codec_unavailable",
        "an exact C09 transition requires a canonical phase encoder");
  }
  if (cursor) {
    // A realized C09 transition supplies its immutable successor cursor.
    // Validate it directly so sequential laws need not invent a decoder.
    auto supplied = law->runtime.encode_phase(law->payload, cursor);
    if (!supplied) {
      return Result<ArrivalPhase>::failure(supplied.error());
    }
    if (supplied.value() != canonical_after) {
      return c17_invalid<ArrivalPhase>(
          "c17.configured_arrival_successor_cursor_mismatch",
          "the realized configured-arrival successor cursor does not encode "
          "to its returned canonical phase");
    }
  } else {
    // Pure enumerated atoms carry bytes rather than a live cursor and must
    // therefore remain reconstructible through the full exact codec.
    if (!law->runtime.decode_phase) {
      return c17_invalid<ArrivalPhase>(
          "c17.configured_arrival_phase_codec_unavailable",
          "a canonical configured-arrival successor without an owned cursor "
          "requires an exact phase decoder");
    }
    auto decoded = law->runtime.decode_phase(law->payload, canonical_after);
    if (!decoded) {
      return Result<ArrivalPhase>::failure(decoded.error());
    }
    if (!decoded.value()) {
      return c17_invalid<ArrivalPhase>(
          "c17.configured_arrival_successor_cursor_missing",
          "the canonical configured-arrival successor decoded to no cursor");
    }
    auto round_trip =
        law->runtime.encode_phase(law->payload, decoded.value());
    if (!round_trip) {
      return Result<ArrivalPhase>::failure(round_trip.error());
    }
    if (round_trip.value() != canonical_after) {
      return c17_invalid<ArrivalPhase>(
          "c17.configured_arrival_successor_phase_noncanonical",
          "a configured-arrival successor phase does not survive its exact "
          "decoder/encoder round trip");
    }
    cursor = std::move(decoded).value();
  }
  auto digest = detail::digest_arrival_state(canonical_after);
  if (!digest) {
    return Result<ArrivalPhase>::failure(digest.error());
  }
  BigNat next_slot = before->next_authored_slot;
  ++next_slot;
  auto core = std::make_shared<const detail::ArrivalPhaseCore>(
      detail::ArrivalPhaseCore{law->binding.family,
                               law->binding,
                               ArrivalStateDigest(std::move(digest).value()),
                               std::move(canonical_after),
                               std::move(next_slot),
                               std::move(cursor),
                               before->cursor_owner});
  return Result<ArrivalPhase>::success(
      detail::ArrivalCoreAccess::make_phase(law->binding.family,
                                            std::move(core)));
}

[[nodiscard]] Result<ArrivalBatch> aggregate_bound_arrival(
    const std::span<const ArrivalAtom> atoms,
    const ArrivalBinding& binding,
    const QueueMask& positive_support) {
  auto batch = aggregate_arrival_batch(atoms);
  if (!batch) {
    return Result<ArrivalBatch>::failure(batch.error());
  }
  if (batch.value().empty_batch()) {
    return Result<ArrivalBatch>::success(
        detail::ArrivalCoreAccess::bind_empty_batch(
            std::move(batch).value(), binding));
  }
  if (!batch.value().binding().has_value() ||
      !(*batch.value().binding() == binding)) {
    return c17_invalid<ArrivalBatch>(
        "c17.arrival_atom_binding_mismatch",
        "the configured joint arrival atom is not bound to the compiled "
        "arrival law");
  }
  for (const ArrivalBatchEntry& entry : batch.value().entries()) {
    if (!positive_support.at(entry.queue)) {
      return c17_invalid<ArrivalBatch>(
          "c17.arrival_emission_outside_positive_support",
          "the configured arrival transition emitted a queue absent from "
          "its exact positive-support mask");
    }
  }
  return batch;
}

[[nodiscard]] Result<detail::ArrivalCursorState>
validated_canonical_phase_cursor(
    const std::shared_ptr<const detail::CompiledArrivalLawCore>& law,
    const std::shared_ptr<const detail::ArrivalPhaseCore>& phase) {
  if (!law->runtime.encode_phase) {
    return c17_invalid<detail::ArrivalCursorState>(
        "c17.configured_arrival_phase_codec_unavailable",
        "configured-arrival application requires an exact canonical phase "
        "encoder");
  }
  // Sequential countable-phase laws may intentionally have no canonical
  // decoder.  Their immutable phase still owns the exact cursor produced by
  // C09; the encoder is the audit boundary that binds it to canonical bytes.
  if (phase->cursor_state) {
    auto round_trip =
        law->runtime.encode_phase(law->payload, phase->cursor_state);
    if (!round_trip) {
      return Result<detail::ArrivalCursorState>::failure(
          round_trip.error());
    }
    if (round_trip.value() != phase->canonical_state) {
      return c17_invalid<detail::ArrivalCursorState>(
          "c17.configured_arrival_phase_noncanonical",
          "the configured predictive phase's owned cursor does not encode "
          "to its canonical state");
    }
    return Result<detail::ArrivalCursorState>::success(
        phase->cursor_state);
  }
  if (!law->runtime.decode_phase) {
    return c17_invalid<detail::ArrivalCursorState>(
        "c17.configured_arrival_phase_codec_unavailable",
        "a configured predictive phase without an owned cursor requires an "
        "exact canonical phase decoder");
  }
  auto decoded =
      law->runtime.decode_phase(law->payload, phase->canonical_state);
  if (!decoded) {
    return Result<detail::ArrivalCursorState>::failure(decoded.error());
  }
  if (!decoded.value()) {
    return c17_invalid<detail::ArrivalCursorState>(
        "c17.configured_arrival_phase_cursor_missing",
        "the configured predictive phase decoded to no cursor");
  }
  auto round_trip =
      law->runtime.encode_phase(law->payload, decoded.value());
  if (!round_trip) {
    return Result<detail::ArrivalCursorState>::failure(round_trip.error());
  }
  if (round_trip.value() != phase->canonical_state) {
    return c17_invalid<detail::ArrivalCursorState>(
        "c17.configured_arrival_phase_noncanonical",
        "the configured predictive phase does not survive its exact "
        "decoder/encoder round trip");
  }
  return decoded;
}

[[nodiscard]] Result<ArrivalTransition> realize_c09_arrival(
    const CompiledArrivalLaw& arrival, const ArrivalPhase& phase,
    const CausalBranchIdentityV1& branch, DeterministicRng& rng) {
  const auto law = detail::ArrivalCoreAccess::law_core(arrival);
  const auto phase_core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!law || !phase_core || law->binding.family != phase_core->family ||
      !(law->binding == phase_core->binding)) {
    return c17_invalid<ArrivalTransition>(
        "c17.configured_arrival_phase_mismatch",
        "the predictive phase is not owned by the configured arrival law");
  }
  if (!law->runtime.propose) {
    return c17_invalid<ArrivalTransition>(
        "c17.configured_arrival_realizer_unavailable",
        "the configured C09 law has no sequential realization operation");
  }
  auto cursor = validated_canonical_phase_cursor(law, phase_core);
  if (!cursor) {
    return Result<ArrivalTransition>::failure(cursor.error());
  }
  auto proposed = law->runtime.propose(
      law->payload, cursor.value(), phase_core->next_authored_slot,
      law->binding, rng);
  if (!proposed) {
    return Result<ArrivalTransition>::failure(proposed.error());
  }
  detail::ProposedArrivalTransition proposed_value =
      std::move(proposed).value();
  if (!proposed_value.successor_state) {
    return c17_invalid<ArrivalTransition>(
        "c17.configured_arrival_successor_cursor_missing",
        "the configured C09 transition returned no successor cursor");
  }
  if (proposed_value.borrowed_atoms.has_value() &&
      !proposed_value.atoms.empty()) {
    return c17_internal<ArrivalTransition>(
        "c17.arrival_proposal_storage_ambiguous",
        "a configured-arrival transition populated both owning and borrowed "
        "atom storage");
  }
  const std::span<const ArrivalAtom> proposed_atoms =
      proposed_value.borrowed_atoms.has_value()
          ? *proposed_value.borrowed_atoms
          : std::span<const ArrivalAtom>(proposed_value.atoms);
  auto batch = aggregate_bound_arrival(proposed_atoms,
                                       law->binding, law->positive_support);
  if (!batch) {
    return Result<ArrivalTransition>::failure(batch.error());
  }
  auto canonical_after = law->runtime.encode_phase(
      law->payload, proposed_value.successor_state);
  if (!canonical_after) {
    return Result<ArrivalTransition>::failure(canonical_after.error());
  }
  auto after = make_successor_phase(law, phase_core,
                                    std::move(canonical_after).value(),
                                    proposed_value.successor_state);
  if (!after) {
    return Result<ArrivalTransition>::failure(after.error());
  }
  auto identity = arrival_transition_identity(
      phase_core->next_authored_slot, batch.value(), phase, after.value(),
      law->binding.law_digest);
  if (!identity) {
    return Result<ArrivalTransition>::failure(identity.error());
  }
  auto canonical_source = canonical_arrival_transition_source(
      phase_core->next_authored_slot, batch.value(), phase, after.value(),
      law->binding.law_digest, identity.value());
  if (!canonical_source) {
    return Result<ArrivalTransition>::failure(canonical_source.error());
  }
  return Result<ArrivalTransition>::success(ArrivalTransition{
      branch,
      phase_core->next_authored_slot,
      std::move(batch).value(),
      phase,
      std::move(after).value(),
      law->binding.law_digest,
      std::move(identity).value(),
      std::move(canonical_source).value(),
      {}});
}

[[nodiscard]] Result<PreparedArrivalParts> prepare_c09_arrival_parts(
    const CompiledArrivalLaw& arrival, const ArrivalPhase& phase,
    const CausalBranchIdentityV1& branch) {
  const auto law = detail::ArrivalCoreAccess::law_core(arrival);
  const auto phase_core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!law || !phase_core || law->binding.family != phase_core->family ||
      !(law->binding == phase_core->binding)) {
    return c17_invalid<PreparedArrivalParts>(
        "c17.configured_arrival_phase_mismatch",
        "the predictive phase is not owned by the configured arrival law");
  }

  if (!law->runtime.enumerate &&
      !law->runtime.enumerate_time_homogeneous) {
    return Result<PreparedArrivalParts>::success(
        PreparedArrivalParts{{}, false});
  }
  auto cursor = validated_canonical_phase_cursor(law, phase_core);
  if (!cursor) {
    return Result<PreparedArrivalParts>::failure(cursor.error());
  }
  auto enumerated = law->runtime.enumerate_time_homogeneous
                        ? law->runtime.enumerate_time_homogeneous(
                              law->payload, cursor.value(), law->binding)
                        : law->runtime.enumerate(
                              law->payload, cursor.value(),
                              phase_core->next_authored_slot, law->binding);
  if (!enumerated) {
    return Result<PreparedArrivalParts>::failure(enumerated.error());
  }

  try {
    std::vector<ArrivalTransitionLawAtomV1> atoms;
    atoms.reserve(enumerated.value().size());
    for (detail::ExactArrivalTransitionAtom& atom : enumerated.value()) {
      if (!std::equal(atom.phase_before.begin(), atom.phase_before.end(),
                      phase_core->canonical_state.begin(),
                      phase_core->canonical_state.end())) {
        return c17_invalid<PreparedArrivalParts>(
            "c17.configured_arrival_before_phase_mismatch",
            "an exact configured-arrival atom changed its conditioning "
            "predictive phase");
      }
      auto batch = aggregate_bound_arrival(
          std::span<const ArrivalAtom>(atom.atoms), law->binding,
          law->positive_support);
      if (!batch) {
        return Result<PreparedArrivalParts>::failure(batch.error());
      }
      auto after = make_successor_phase(law, phase_core,
                                        std::move(atom.phase_after));
      if (!after) {
        return Result<PreparedArrivalParts>::failure(after.error());
      }
      auto identity = arrival_transition_identity(
          phase_core->next_authored_slot, batch.value(), phase,
          after.value(), law->binding.law_digest);
      if (!identity) {
        return Result<PreparedArrivalParts>::failure(identity.error());
      }
      auto canonical_source = canonical_arrival_transition_source(
          phase_core->next_authored_slot, batch.value(), phase,
          after.value(), law->binding.law_digest, identity.value());
      if (!canonical_source) {
        return Result<PreparedArrivalParts>::failure(
            canonical_source.error());
      }
      const bool support = atom.structural_support;
      atoms.push_back(ArrivalTransitionLawAtomV1{
          ArrivalTransition{branch,
                            phase_core->next_authored_slot,
                            std::move(batch).value(),
                            phase,
                            std::move(after).value(),
                            law->binding.law_digest,
                            std::move(identity).value(),
                            std::move(canonical_source).value(),
                            {}},
          std::move(atom.mass), support});
    }
    return Result<PreparedArrivalParts>::success(
        PreparedArrivalParts{std::move(atoms), true});
  } catch (const std::bad_alloc&) {
    return c17_resource<PreparedArrivalParts>(
        "c17.arrival_row_allocation_exhausted",
        "forming the configured exact arrival row exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] bool field_is_unresolved_and_writable(
    const PlugDescriptor& descriptor, const RuntimeFieldIdV1& field) {
  const auto declaration = std::ranges::find_if(
      descriptor.state_fields,
      [&field](const RuntimeStateFieldV1& candidate) {
        return candidate.id == field;
      });
  if (declaration == descriptor.state_fields.end() ||
      declaration->c14_field.ownership != FieldOwnershipV1::surrogate_owned ||
      !descriptor.c_plus.has_value()) {
    return false;
  }
  return std::ranges::find(descriptor.c_plus->writable_unresolved_fields,
                           field) !=
         descriptor.c_plus->writable_unresolved_fields.end();
}

[[nodiscard]] bool field_patch_matches_descriptor(
    const PlugDescriptor& descriptor, const RuntimeFieldPatchV1& patch) {
  const auto declaration = std::ranges::find_if(
      descriptor.state_fields,
      [&patch](const RuntimeStateFieldV1& candidate) {
        return candidate.id == patch.field;
      });
  return declaration != descriptor.state_fields.end() &&
         descriptor.c_plus.has_value() &&
         field_is_unresolved_and_writable(descriptor, patch.field) &&
         patch.value.codec == declaration->c14_field.codec;
}

[[nodiscard]] Result<void> validate_emitted_mark_ids(
    const std::span<const RuntimeDecodedMarkV1> marks,
    const std::span<const RuntimeMarkIdV1> declared,
    const std::string_view stage_name) {
  if (marks.size() != declared.size()) {
    return c17_invalid<void>(
        "c17.operation_mark_set_mismatch",
        std::string(stage_name) +
            " output does not contain exactly its declared mark IDs");
  }
  for (std::size_t index = 0U; index < marks.size(); ++index) {
    if (std::ranges::find_if(
            marks.begin(), marks.begin() + index,
            [&](const RuntimeDecodedMarkV1& prior) {
              return prior.mark == marks[index].mark;
            }) != marks.begin() + index ||
        std::ranges::find(declared, marks[index].mark) == declared.end()) {
      return c17_invalid<void>(
          "c17.operation_mark_set_mismatch",
          std::string(stage_name) +
              " output contains a duplicate or undeclared mark ID");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_cminus_output_schema(
    const CMinusOperationSchemaV1& schema,
    const CMinusOutputV1& output) {
  if (!(output.opportunity.codec == schema.opportunity_codec)) {
    return c17_invalid<void>(
        "c17.cminus_opportunity_codec_mismatch",
        "C-minus output does not use its declared opportunity codec");
  }
  return validate_emitted_mark_ids(output.jointly_emitted_marks,
                                   schema.jointly_emitted_marks,
                                   "C-minus");
}

[[nodiscard]] Result<void> validate_cplus_output_schema(
    const CPlusOperationSchemaV1& schema, const CPlusOutputV1& output) {
  return validate_emitted_mark_ids(output.jointly_emitted_marks,
                                   schema.jointly_emitted_marks,
                                   "C-plus");
}

[[nodiscard]] bool same_exact_coordinates(
    const ExactReducedCoordinatesV1& expected,
    const ExactReducedCoordinatesV1& actual) {
  const auto same_margin = [](const PairMargin& left,
                              const PairMargin& right) {
    return left.pair() == right.pair() &&
           left.evaluation_backlog() == right.evaluation_backlog() &&
           left.opportunity_certificate_digest() ==
               right.opportunity_certificate_digest() &&
           left.old_pair_linear_coordinate() ==
               right.old_pair_linear_coordinate() &&
           left.reoptimized_margin() == right.reoptimized_margin() &&
           left.fixed_out_objective() == right.fixed_out_objective() &&
           left.fixed_in_objective() == right.fixed_in_objective() &&
           left.regret0() == right.regret0() &&
           left.regret1() == right.regret1() &&
           left.forced_out_valid() == right.forced_out_valid() &&
           left.forced_in_valid() == right.forced_in_valid() &&
           left.pair_valid() == right.pair_valid() &&
           left.target_eligible() == right.target_eligible() &&
           left.representative_selection() ==
               right.representative_selection();
  };
  return expected.backlog == actual.backlog &&
         same_exact_phase(expected.arrival_phase, actual.arrival_phase) &&
         expected.boundary_index == actual.boundary_index &&
         expected.resources == actual.resources &&
         expected.margins.size() == actual.margins.size() &&
         std::equal(expected.margins.begin(), expected.margins.end(),
                    actual.margins.begin(), same_margin) &&
         expected.controller == actual.controller;
}

[[nodiscard]] bool same_unresolved_coordinates(
    const std::span<const RuntimeFieldPatchV1> expected,
    const std::span<const RuntimeFieldPatchV1> actual) {
  if (expected.size() != actual.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < expected.size(); ++index) {
    if (std::ranges::find_if(
            expected.begin(), expected.begin() + index,
            [&](const RuntimeFieldPatchV1& prior) {
              return prior.field == expected[index].field;
            }) != expected.begin() + index) {
      return false;
    }
    const auto found = std::ranges::find_if(
        actual, [&](const RuntimeFieldPatchV1& candidate) {
          return candidate.field == expected[index].field;
        });
    if (found == actual.end() || !(found->value == expected[index].value)) {
      return false;
    }
  }
  for (std::size_t index = 0U; index < actual.size(); ++index) {
    if (std::ranges::find_if(
            actual.begin(), actual.begin() + index,
            [&](const RuntimeFieldPatchV1& prior) {
              return prior.field == actual[index].field;
            }) != actual.begin() + index) {
      return false;
    }
  }
  return true;
}

// The finite event-clock quotient is an exact-row authority, not permission
// for a provider callback to inspect the absolute physical slot.  Build a
// callback-only representative with the same mathematical coordinates and
// predictive phase, anchored at slot zero.  The raw state remains the source
// of branch identity, Psi, edge storage, arrival provenance, and word
// digests.
[[nodiscard]] Result<ArrivalPhase> callback_phase_at_slot_zero(
    const ArrivalPhase& phase) {
  const auto core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!core) {
    return c17_invalid<ArrivalPhase>(
        "c17.quotient_arrival_phase_missing",
        "the finite event-clock quotient requires a complete configured "
        "arrival phase");
  }
  try {
    auto anchored = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{
            core->family, core->binding, core->state_digest,
            core->canonical_state, BigNat{0U}, core->cursor_state,
            core->cursor_owner});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(core->family,
                                              std::move(anchored)));
  } catch (const std::bad_alloc&) {
    return c17_resource<ArrivalPhase>(
        "c17.quotient_phase_allocation_exhausted",
        "constructing the slot-erased callback phase exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<ReducedStateV1> callback_clock_erased_state(
    const ExactReducedStateSchemaV1& schema,
    const ReducedStateV1& raw_state,
    const UnresolvedPatch& no_patch) {
  auto decoded = schema.decode(raw_state);
  if (!decoded) {
    return Result<ReducedStateV1>::failure(decoded.error());
  }
  ExactReducedCoordinatesV1 anchored = decoded.value();
  auto phase = callback_phase_at_slot_zero(anchored.arrival_phase);
  if (!phase) {
    return Result<ReducedStateV1>::failure(phase.error());
  }
  anchored.arrival_phase = std::move(phase).value();
  anchored.boundary_index = BigNat{0U};
  auto rebuilt = schema.rebuild(anchored, no_patch);
  if (!rebuilt) {
    return Result<ReducedStateV1>::failure(rebuilt.error());
  }
  auto valid = schema.validate_domain(rebuilt.value());
  if (!valid) {
    return Result<ReducedStateV1>::failure(valid.error());
  }
  auto round_trip = schema.decode(rebuilt.value());
  const auto anchored_phase = detail::ArrivalCoreAccess::phase_core(
      anchored.arrival_phase);
  const auto round_trip_phase = round_trip
                                    ? detail::ArrivalCoreAccess::phase_core(
                                          round_trip.value().arrival_phase)
                                    : nullptr;
  if (!round_trip || !anchored_phase || !round_trip_phase ||
      !(round_trip_phase->binding == anchored_phase->binding) ||
      !(round_trip_phase->next_authored_slot == BigNat{0U}) ||
      !same_exact_coordinates(anchored, round_trip.value()) ||
      !same_unresolved_coordinates(anchored.unresolved_fields,
                                   round_trip.value().unresolved_fields)) {
    return c17_invalid<ReducedStateV1>(
        "c17.quotient_callback_state_round_trip_mismatch",
        "the exact state schema cannot produce a unique slot-zero callback "
        "representative without changing a retained coordinate");
  }
  return rebuilt;
}

[[nodiscard]] Result<ArrivalPhase> callback_phase_at_slot(
    const ArrivalPhase& phase, BigNat slot,
    std::shared_ptr<const detail::CursorOwnerToken> cursor_owner) {
  const auto core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!core || !cursor_owner) {
    return c17_invalid<ArrivalPhase>(
        "c17.quotient_arrival_phase_missing",
        "the finite event-clock quotient requires a complete configured "
        "arrival phase and callback cursor lineage");
  }
  try {
    auto anchored = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{
            core->family, core->binding, core->state_digest,
            core->canonical_state, std::move(slot), core->cursor_state,
            std::move(cursor_owner)});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(core->family,
                                              std::move(anchored)));
  } catch (const std::bad_alloc&) {
    return c17_resource<ArrivalPhase>(
        "c17.quotient_phase_allocation_exhausted",
        "constructing the slot-erased callback phase exceeded the host "
        "resource envelope");
  }
}

[[nodiscard]] Result<ArrivalTransition> callback_clock_erased_arrival(
    const ArrivalTransition& raw,
    const ArrivalPhase& callback_state_phase) {
  const auto raw_before =
      detail::ArrivalCoreAccess::phase_core(raw.phase_before);
  const auto raw_after =
      detail::ArrivalCoreAccess::phase_core(raw.phase_after);
  const auto callback_before =
      detail::ArrivalCoreAccess::phase_core(callback_state_phase);
  BigNat raw_after_slot = raw.authored_slot;
  ++raw_after_slot;
  if (!raw_before || !raw_after || !callback_before ||
      !raw.batch.binding().has_value() ||
      !(raw_before->binding == *raw.batch.binding()) ||
      !(raw_after->binding == *raw.batch.binding()) ||
      !(callback_before->binding == *raw.batch.binding()) ||
      !(raw.law_digest == raw.batch.binding()->law_digest) ||
      raw_before->next_authored_slot != raw.authored_slot ||
      raw_after->next_authored_slot != raw_after_slot ||
      callback_before->next_authored_slot != BigNat{0U} ||
      !arrival_phases_share_cursor(raw.phase_before, raw.phase_after) ||
      !same_phase(raw.phase_before, callback_state_phase) ||
      !callback_before->cursor_owner) {
    return c17_invalid<ArrivalTransition>(
        "c17.quotient_arrival_cursor_rebase_mismatch",
        "the slot-erased arrival transition is not the same configured "
        "phase row as the decoded callback-state representative");
  }

  // The schema is the authority for the callback representative.  In
  // particular, rebuilding a slot-zero state may replace the raw physical
  // cursor owner with the canonical slot-zero owner's lineage.  Rebase the
  // callback successor onto that same owner rather than mixing it with the
  // raw later-slot owner; Psi continues to enforce cursor identity normally.
  ArrivalPhase before = callback_state_phase;
  auto after = callback_phase_at_slot(
      raw.phase_after, BigNat{1U}, callback_before->cursor_owner);
  if (!after) {
    return Result<ArrivalTransition>::failure(after.error());
  }
  if (!arrival_phases_share_cursor(before, after.value()) ||
      !same_phase(raw.phase_after, after.value())) {
    return c17_invalid<ArrivalTransition>(
        "c17.quotient_arrival_cursor_rebase_mismatch",
        "the slot-erased successor phase did not retain the callback-state "
        "cursor lineage and configured phase value");
  }
  auto identity = arrival_transition_identity(
      BigNat{0U}, raw.batch, before, after.value(), raw.law_digest);
  if (!identity) {
    return Result<ArrivalTransition>::failure(identity.error());
  }
  auto source = canonical_arrival_transition_source(
      BigNat{0U}, raw.batch, before, after.value(), raw.law_digest,
      identity.value());
  if (!source) {
    return Result<ArrivalTransition>::failure(source.error());
  }
  return Result<ArrivalTransition>::success(
      ArrivalTransition{raw.branch,
                        BigNat{0U},
                        raw.batch,
                        std::move(before),
                        std::move(after).value(),
                        raw.law_digest,
                        std::move(identity).value(),
                        std::move(source).value(),
                        raw.marks});
}

// The exact row quotient is callback-only.  Psi and every typed state/edge
// mark decoder must execute on the slot-zero representative as well; after
// that sealed computation succeeds, this helper restores only the physical
// boundary and configured-arrival cursor on the successor.  All other
// coordinates come from the quotient Psi result and are round-tripped through
// the exact schema before the clockful edge is published.
[[nodiscard]] Result<ReducedStateV1> lift_clock_erased_row_successor(
    const ExactReducedStateSchemaV1& schema,
    const ReducedStateV1& raw_pre_state,
    const ArrivalTransition& raw_arrival,
    const CompletedReducedEdge& callback_edge,
    const UnresolvedPatch& no_patch) {
  auto raw_before = schema.decode(raw_pre_state);
  auto callback_before = schema.decode(callback_edge.pre_state());
  auto callback_after = schema.decode(callback_edge.successor_state());
  if (!raw_before) {
    return Result<ReducedStateV1>::failure(raw_before.error());
  }
  if (!callback_before) {
    return Result<ReducedStateV1>::failure(callback_before.error());
  }
  if (!callback_after) {
    return Result<ReducedStateV1>::failure(callback_after.error());
  }

  const ArrivalTransition& callback_arrival = callback_edge.arrival();
  const auto raw_before_phase = detail::ArrivalCoreAccess::phase_core(
      raw_before.value().arrival_phase);
  const auto raw_arrival_before = detail::ArrivalCoreAccess::phase_core(
      raw_arrival.phase_before);
  const auto raw_arrival_after = detail::ArrivalCoreAccess::phase_core(
      raw_arrival.phase_after);
  const auto callback_before_phase = detail::ArrivalCoreAccess::phase_core(
      callback_before.value().arrival_phase);
  const auto callback_arrival_before = detail::ArrivalCoreAccess::phase_core(
      callback_arrival.phase_before);
  const auto callback_arrival_after = detail::ArrivalCoreAccess::phase_core(
      callback_arrival.phase_after);
  const auto callback_after_phase = detail::ArrivalCoreAccess::phase_core(
      callback_after.value().arrival_phase);
  BigNat raw_successor_boundary = raw_before.value().boundary_index;
  ++raw_successor_boundary;
  auto raw_realization_identity = arrival_transition_identity(
      raw_arrival.authored_slot, raw_arrival.batch,
      raw_arrival.phase_before, raw_arrival.phase_after,
      raw_arrival.law_digest);
  if (!raw_realization_identity) {
    return Result<ReducedStateV1>::failure(
        raw_realization_identity.error());
  }
  auto raw_canonical_source = canonical_arrival_transition_source(
      raw_arrival.authored_slot, raw_arrival.batch,
      raw_arrival.phase_before, raw_arrival.phase_after,
      raw_arrival.law_digest, raw_realization_identity.value());
  if (!raw_canonical_source) {
    return Result<ReducedStateV1>::failure(raw_canonical_source.error());
  }
  if (!raw_before_phase || !raw_arrival_before || !raw_arrival_after ||
      !callback_before_phase || !callback_arrival_before ||
      !callback_arrival_after || !callback_after_phase ||
      !(callback_edge.pre_state().codec == schema.reduced_state_codec) ||
      !(callback_edge.successor_state().codec ==
        schema.reduced_state_codec) ||
      raw_arrival.authored_slot != raw_before.value().boundary_index ||
      raw_before_phase->next_authored_slot !=
          raw_before.value().boundary_index ||
      raw_arrival_before->next_authored_slot != raw_arrival.authored_slot ||
      raw_arrival_after->next_authored_slot != raw_successor_boundary ||
      !same_exact_phase(raw_before.value().arrival_phase,
                        raw_arrival.phase_before) ||
      !arrival_phases_share_cursor(raw_before.value().arrival_phase,
                                   raw_arrival.phase_before) ||
      !arrival_phases_share_cursor(raw_arrival.phase_before,
                                   raw_arrival.phase_after) ||
      raw_realization_identity.value() !=
          raw_arrival.realization_identity ||
      raw_canonical_source.value() != raw_arrival.canonical_source ||
      callback_before.value().boundary_index != BigNat{0U} ||
      callback_arrival.authored_slot != BigNat{0U} ||
      callback_before_phase->next_authored_slot != BigNat{0U} ||
      callback_arrival_before->next_authored_slot != BigNat{0U} ||
      callback_arrival_after->next_authored_slot != BigNat{1U} ||
      callback_after.value().boundary_index != BigNat{1U} ||
      callback_after_phase->next_authored_slot != BigNat{1U} ||
      !same_exact_phase(callback_before.value().arrival_phase,
                        callback_arrival.phase_before) ||
      !same_exact_phase(callback_after.value().arrival_phase,
                        callback_arrival.phase_after) ||
      !same_phase(raw_arrival.phase_before,
                  callback_arrival.phase_before) ||
      !same_phase(raw_arrival.phase_after, callback_arrival.phase_after) ||
      !(raw_arrival.batch == callback_arrival.batch) ||
      raw_arrival.law_digest != callback_arrival.law_digest ||
      raw_arrival.branch != callback_arrival.branch ||
      raw_arrival.marks != callback_arrival.marks) {
    return c17_invalid<ReducedStateV1>(
        "c17.quotient_row_clock_lift_mismatch",
        "the clock-erased row result cannot be lifted onto its raw physical "
        "configured-arrival boundary without changing provenance");
  }

  ExactReducedCoordinatesV1 lifted = callback_after.value();
  lifted.arrival_phase = raw_arrival.phase_after;
  lifted.boundary_index = raw_successor_boundary;
  auto rebuilt = schema.rebuild(lifted, no_patch);
  if (!rebuilt) {
    return Result<ReducedStateV1>::failure(rebuilt.error());
  }
  auto valid = schema.validate_domain(rebuilt.value());
  if (!valid) {
    return Result<ReducedStateV1>::failure(valid.error());
  }
  auto round_trip = schema.decode(rebuilt.value());
  if (!round_trip ||
      !same_exact_coordinates(lifted, round_trip.value()) ||
      !same_unresolved_coordinates(lifted.unresolved_fields,
                                   round_trip.value().unresolved_fields)) {
    return c17_invalid<ReducedStateV1>(
        "c17.quotient_row_clock_lift_round_trip_mismatch",
        "lifting the exact row successor changed a backlog, predictive "
        "phase, controller, resource, margin, or unresolved coordinate");
  }
  return rebuilt;
}

[[nodiscard]] Result<void> validate_action_evidence(
    const ResolvedInstance& instance, const TargetBacklogV1& backlog,
    const OpportunityMark& opportunity, const ResolvedAction& action,
    const bool require_emitted_face) {
  if (!require_emitted_face) {
    return Result<void>::success();
  }
  if (!opportunity.prearrival_backlog.has_value() ||
      !(*opportunity.prearrival_backlog == backlog) ||
      !opportunity.resolver_face.has_value()) {
    return c17_invalid<void>(
        "c17.generic_action_emitted_face_required",
        "a generic exact action requires the immutable target backlog and "
        "complete emitted resolver face");
  }
  auto expected = resolve_emitted_face_action(instance, backlog, opportunity);
  if (!expected) {
    return Result<void>::failure(expected.error());
  }
  const ResolvedAction& selected = expected.value();
  if (!(action.schedule == selected.schedule) ||
      !(action.actual_departure == selected.actual_departure) ||
      !(action.schedule_identity == selected.schedule_identity) ||
      !(action.evidence == selected.evidence) ||
      !(action.decision == selected.decision) ||
      action.interim_controller != selected.interim_controller ||
      action.postupdate_controller_tape !=
          selected.postupdate_controller_tape) {
    return c17_invalid<void>(
        "c17.action_emitted_face_resolution_mismatch",
        "the resolved action differs from the exact emitted-face maximum "
        "or configured priority winner");
  }
  return Result<void>::success();
}

struct PreparedRuntimeMarkDecoderV1 final {
  DeterministicRuntimeMarkDecoderSchemaV1 schema;
  DeterministicRuntimeMarkDecoderCallbackV1 operation;
};

[[nodiscard]] Result<std::vector<RuntimeDecodedMarkV1>>
apply_prepared_mark_decoders(
    const std::span<const PreparedRuntimeMarkDecoderV1> decoders,
    const MarkDecoderSourceV1 source,
    const CanonicalRuntimeValueV1& input) {
  std::vector<RuntimeDecodedMarkV1> marks;
  try {
    for (const PreparedRuntimeMarkDecoderV1& decoder : decoders) {
      if (decoder.schema.source != source) {
        continue;
      }
      if (!(input.codec == decoder.schema.input_codec) ||
          !decoder.operation) {
        return c17_invalid<std::vector<RuntimeDecodedMarkV1>>(
            "c17.mark_decoder_input_binding_mismatch",
            "a deterministic mark decoder is absent or received a source "
            "outside its declared input codec");
      }
      auto decoded = decoder.operation(input);
      if (!decoded) {
        return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
            decoded.error());
      }
      if (!(decoded.value().codec == decoder.schema.output_codec)) {
        return c17_invalid<std::vector<RuntimeDecodedMarkV1>>(
            "c17.mark_decoder_output_codec_mismatch",
            "a deterministic mark decoder returned a value outside its "
            "declared output codec");
      }
      marks.push_back(RuntimeDecodedMarkV1{decoder.schema.mark,
                                           std::move(decoded).value()});
    }
    return Result<std::vector<RuntimeDecodedMarkV1>>::success(
        std::move(marks));
  } catch (const std::bad_alloc&) {
    return c17_resource<std::vector<RuntimeDecodedMarkV1>>(
        "c17.mark_decoder_output_allocation_exhausted",
        "forming deterministic causal marks exceeded the host resource "
        "envelope");
  }
}

[[nodiscard]] std::optional<CausalStageV1> direct_mark_source_stage(
    const MarkDecoderSourceV1 source) {
  switch (source) {
    case MarkDecoderSourceV1::predecision_state:
    case MarkDecoderSourceV1::c_minus_joint_output:
      return CausalStageV1::c_minus;
    case MarkDecoderSourceV1::decision_schedule:
      return CausalStageV1::resolver;
    case MarkDecoderSourceV1::configured_arrival:
      return CausalStageV1::arrival;
    case MarkDecoderSourceV1::c_plus_joint_output:
      return CausalStageV1::c_plus;
    case MarkDecoderSourceV1::postarrival_state:
    case MarkDecoderSourceV1::completed_edge:
    case MarkDecoderSourceV1::entrance_realization:
      return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] std::optional<CausalStageV1> completed_mark_source_stage(
    const MarkDecoderSourceV1 source) {
  switch (source) {
    case MarkDecoderSourceV1::predecision_state:
    case MarkDecoderSourceV1::c_minus_joint_output:
      return CausalStageV1::c_minus;
    case MarkDecoderSourceV1::decision_schedule:
      return CausalStageV1::resolver;
    case MarkDecoderSourceV1::configured_arrival:
      return CausalStageV1::arrival;
    case MarkDecoderSourceV1::c_plus_joint_output:
    case MarkDecoderSourceV1::postarrival_state:
      return CausalStageV1::c_plus;
    case MarkDecoderSourceV1::completed_edge:
      return CausalStageV1::psi;
    case MarkDecoderSourceV1::entrance_realization:
      return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] bool mark_source_reveal_matches(
    const RuntimeMarkDescriptorV1& descriptor) {
  if (descriptor.decoder_source ==
      MarkDecoderSourceV1::entrance_realization) {
    return descriptor.c14_mark.reveal_stage ==
           MetricRevealStageV1::entrance_label;
  }
  const auto source = completed_mark_source_stage(descriptor.decoder_source);
  const auto reveal = [&]() -> std::optional<CausalStageV1> {
    switch (descriptor.c14_mark.reveal_stage) {
      case MetricRevealStageV1::predecision:
        return CausalStageV1::c_minus;
      case MetricRevealStageV1::decision:
        return CausalStageV1::resolver;
      case MetricRevealStageV1::arrival:
        return CausalStageV1::arrival;
      case MetricRevealStageV1::postarrival:
        return CausalStageV1::c_plus;
      case MetricRevealStageV1::completed_edge:
        return CausalStageV1::psi;
      case MetricRevealStageV1::entrance_label:
        return std::nullopt;
    }
    return std::nullopt;
  }();
  return source.has_value() && reveal.has_value() &&
         static_cast<std::uint8_t>(*source) <=
             static_cast<std::uint8_t>(*reveal);
}

[[nodiscard]] bool closed_three_bin_descriptor(
    const PlugDescriptor& descriptor) noexcept {
  return descriptor.core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         descriptor.core.runtime_access ==
             RuntimeAccessTagV1::finite_parameter_analytic_family;
}

[[nodiscard]] bool framework_three_bin_actual_departure_mark(
    const PlugDescriptor& descriptor,
    const RuntimeMarkDescriptorV1& mark) {
  return closed_three_bin_descriptor(descriptor) &&
         mark.c14_mark.kind == MetricMarkKindV1::actual_departure &&
         mark.decoder_source == MarkDecoderSourceV1::decision_schedule &&
         mark.decoder_input_codec ==
             CodecIdentityV1{"schedule.realization", 1U} &&
         mark.c14_mark.codec == CodecIdentityV1{"service.bit", 1U};
}

[[nodiscard]] Result<std::vector<RuntimeDecodedMarkV1>>
framework_three_bin_action_marks(
    const ResolvedInstance& instance,
    const PlugDescriptor& descriptor,
    const ExactReducedCoordinatesV1& coordinates,
    const ResolvedAction& action) {
  std::vector<RuntimeDecodedMarkV1> marks;
  for (const RuntimeMarkDescriptorV1& declared : descriptor.marks) {
    if (direct_mark_source_stage(declared.decoder_source) !=
        CausalStageV1::resolver) {
      continue;
    }
    if (!framework_three_bin_actual_departure_mark(descriptor, declared) ||
        coordinates.backlog.size() != 1U) {
      return c17_invalid<std::vector<RuntimeDecodedMarkV1>>(
          "c17.unsupported_three_bin_framework_mark",
          "the closed three-bin adapter owns only the singleton service-bit "
          "readout of its full eligible departure realization");
    }
    const auto target = instance.queues().index_at(
        coordinates.backlog.target_at_target_ordinal(0U).ordinal());
    if (!target) {
      return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
          target.error());
    }
    std::vector<std::byte> schedule_bytes;
    schedule_bytes.reserve(action.actual_departure.bytes().size());
    for (const std::uint8_t bit : action.actual_departure.bytes()) {
      schedule_bytes.push_back(static_cast<std::byte>(bit));
    }
    const CanonicalRuntimeValueV1 schedule_realization{
        declared.decoder_input_codec, std::move(schedule_bytes)};
    marks.push_back(RuntimeDecodedMarkV1{
        declared.id,
        CanonicalRuntimeValueV1{
            declared.c14_mark.codec,
            {schedule_realization.canonical_value.at(target.value().ordinal())}}});
  }
  return Result<std::vector<RuntimeDecodedMarkV1>>::success(
      std::move(marks));
}

[[nodiscard]] Result<void> validate_stage_marks(
    const PlugDescriptor& descriptor, const CausalStageV1 stage,
    const std::span<const RuntimeDecodedMarkV1> marks) {
  std::vector<RuntimeMarkIdV1> seen;
  seen.reserve(marks.size());
  for (const RuntimeDecodedMarkV1& mark : marks) {
    if (std::ranges::find(seen, mark.mark) != seen.end()) {
      return c17_invalid<void>(
          "c17.duplicate_stage_mark",
          "a causal stage emitted the same declared mark more than once");
    }
    seen.push_back(mark.mark);
    const auto declared = std::ranges::find_if(
        descriptor.marks, [&](const RuntimeMarkDescriptorV1& candidate) {
          return candidate.id == mark.mark;
        });
    if (declared == descriptor.marks.end() ||
        direct_mark_source_stage(declared->decoder_source) != stage ||
        !mark_source_reveal_matches(*declared) ||
        !(mark.value.codec == declared->c14_mark.codec)) {
      return c17_invalid<void>(
          "c17.stage_mark_descriptor_mismatch",
          "a causal-stage mark differs from its declared source, reveal "
          "stage, or value codec");
    }
  }
  for (const RuntimeMarkDescriptorV1& declared : descriptor.marks) {
    if (direct_mark_source_stage(declared.decoder_source) == stage &&
        std::ranges::find(seen, declared.id) == seen.end()) {
      return c17_invalid<void>(
          "c17.required_stage_mark_missing",
          "a causal stage omitted a mark declared for every completed edge");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_complete_edge_marks(
    const PlugDescriptor& descriptor, const CompletedReducedEdge& edge) {
  std::vector<RuntimeMarkIdV1> seen;
  seen.reserve(edge.marks().size());
  for (const CausalMarkV1& mark : edge.marks()) {
    if (std::ranges::find(seen, mark.mark.mark) != seen.end()) {
      return c17_invalid<void>(
          "c17.duplicate_completed_edge_mark",
          "a completed reduced edge carries a mark more than once");
    }
    seen.push_back(mark.mark.mark);
    const auto declared = std::ranges::find_if(
        descriptor.marks, [&](const RuntimeMarkDescriptorV1& candidate) {
          return candidate.id == mark.mark.mark;
        });
    if (declared == descriptor.marks.end() ||
        completed_mark_source_stage(declared->decoder_source) !=
            mark.reveal_stage ||
        !mark_source_reveal_matches(*declared) ||
        !(mark.mark.value.codec == declared->c14_mark.codec)) {
      return c17_invalid<void>(
          "c17.completed_edge_mark_descriptor_mismatch",
          "a completed-edge mark differs from its declared source, reveal "
          "stage, or value codec");
    }
  }
  for (const RuntimeMarkDescriptorV1& declared : descriptor.marks) {
    if (declared.decoder_source ==
        MarkDecoderSourceV1::entrance_realization) {
      continue;
    }
    if (std::ranges::find(seen, declared.id) == seen.end()) {
      return c17_invalid<void>(
          "c17.completed_edge_mark_set_incomplete",
          "the completed reduced edge omits a requested non-entrance mark");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::vector<CausalMarkV1>>
bind_framework_mark_set(
    const PlugDescriptor& descriptor, const MarkDecoderSourceV1 source,
    const CausalStageV1 stage,
    std::vector<RuntimeDecodedMarkV1> decoded) {
  const std::size_t required = static_cast<std::size_t>(
      std::ranges::count_if(
          descriptor.marks,
          [&](const RuntimeMarkDescriptorV1& mark) {
            return mark.decoder_source == source;
          }));
  if (decoded.size() != required) {
    return c17_invalid<std::vector<CausalMarkV1>>(
        "c17.framework_mark_set_mismatch",
        "a framework decoder must return exactly its declared source-mark "
        "set");
  }
  std::vector<CausalMarkV1> result;
  result.reserve(decoded.size());
  std::vector<RuntimeMarkIdV1> seen;
  seen.reserve(decoded.size());
  for (RuntimeDecodedMarkV1& mark : decoded) {
    if (std::ranges::find(seen, mark.mark) != seen.end()) {
      return c17_invalid<std::vector<CausalMarkV1>>(
          "c17.framework_mark_duplicate",
          "a framework decoder returned one declared mark more than once");
    }
    const auto declared = std::ranges::find_if(
        descriptor.marks,
        [&](const RuntimeMarkDescriptorV1& candidate) {
          return candidate.id == mark.mark;
        });
    if (declared == descriptor.marks.end() ||
        declared->decoder_source != source ||
        !(declared->c14_mark.codec == mark.value.codec)) {
      return c17_invalid<std::vector<CausalMarkV1>>(
          "c17.framework_mark_descriptor_mismatch",
          "a framework-decoded mark differs from its declared source or "
          "value codec");
    }
    seen.push_back(mark.mark);
    result.push_back(CausalMarkV1{std::move(mark), stage});
  }
  return Result<std::vector<CausalMarkV1>>::success(std::move(result));
}

[[nodiscard]] Result<void> validate_actual_stage_trace(
    const std::span<const CausalStageV1> trace) {
  if (trace.size() != kCausalStageOrderV1.size() ||
      !std::equal(trace.begin(), trace.end(), kCausalStageOrderV1.begin(),
                  kCausalStageOrderV1.end())) {
    return c17_internal<void>(
        "c17.causal_stage_trace_mismatch",
        "the executed causal stages differ from C-minus, resolver, arrival, "
        "C-plus, Psi");
  }
  return Result<void>::success();
}

[[nodiscard]] std::vector<CausalMarkV1> collect_marks(
    const OpportunityMark& opportunity, const ResolvedAction& action,
    const ArrivalTransition& arrival, const PostClosure& postclosure) {
  std::vector<CausalMarkV1> marks;
  marks.reserve(opportunity.marks.size() + action.marks.size() +
                arrival.marks.size() + postclosure.marks.size());
  for (const RuntimeDecodedMarkV1& mark : opportunity.marks) {
    marks.push_back(CausalMarkV1{mark, CausalStageV1::c_minus});
  }
  for (const RuntimeDecodedMarkV1& mark : action.marks) {
    marks.push_back(CausalMarkV1{mark, CausalStageV1::resolver});
  }
  for (const RuntimeDecodedMarkV1& mark : arrival.marks) {
    marks.push_back(CausalMarkV1{mark, CausalStageV1::arrival});
  }
  for (const RuntimeDecodedMarkV1& mark : postclosure.marks) {
    marks.push_back(CausalMarkV1{mark, CausalStageV1::c_plus});
  }
  return marks;
}

[[nodiscard]] BigInt gcd_nonnegative(BigInt left, BigInt right) {
  if (left < 0) {
    left = -left;
  }
  if (right < 0) {
    right = -right;
  }
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  return left;
}

[[nodiscard]] std::size_t c17_nonnegative_bit_length(
    const BigInt& value) noexcept {
  if (value == 0) {
    return 0U;
  }
  return static_cast<std::size_t>(boost::multiprecision::msb(value)) + 1U;
}

// A positive product has either a_bits+b_bits-1 or a_bits+b_bits bits.  The
// lower bound rejects a definitely over-budget scratch product before that
// product is allocated; the exact post-check resolves the one-bit ambiguity.
[[nodiscard]] bool c17_product_provably_exceeds_budget(
    const BigInt& left, const BigInt& right,
    const PmfRepresentationBudget& budget) noexcept {
  if (!budget.maximum_integral_bits.has_value()) {
    return false;
  }
  const std::size_t maximum = *budget.maximum_integral_bits;
  const std::size_t left_bits = c17_nonnegative_bit_length(left);
  const std::size_t right_bits = c17_nonnegative_bit_length(right);
  if (left_bits == 0U || right_bits == 0U) {
    return false;
  }
  if (left_bits > maximum || right_bits > maximum) {
    return true;
  }
  return left_bits > maximum - right_bits + 1U;
}

// For two already bounded nonnegative integers, decide whether their sum is
// outside the same bit envelope without first allocating an over-budget sum.
[[nodiscard]] bool c17_sum_exceeds_budget(
    const BigInt& left, const BigInt& right,
    const PmfRepresentationBudget& budget) {
  if (!budget.maximum_integral_bits.has_value()) {
    return false;
  }
  const std::size_t maximum = *budget.maximum_integral_bits;
  const std::size_t left_bits = c17_nonnegative_bit_length(left);
  const std::size_t right_bits = c17_nonnegative_bit_length(right);
  if (left_bits > maximum || right_bits > maximum) {
    return true;
  }
  const std::size_t larger_bits = std::max(left_bits, right_bits);
  if (larger_bits < maximum || larger_bits == 0U) {
    return false;
  }
  const BigInt& larger = left_bits >= right_bits ? left : right;
  const BigInt& smaller = left_bits >= right_bits ? right : left;
  BigInt high_bit = 1;
  high_bit <<= maximum - 1U;
  const BigInt excess = larger - high_bit;
  return smaller >= high_bit - excess;
}

[[nodiscard]] Result<void> enforce_c17_integral_budget(
    const BigInt& value, const PmfRepresentationBudget& budget,
    std::string_view role) {
  if (value < 0) {
    return c17_internal<void>(
        "c17.final_categorical_negative_integer",
        "the final exact categorical image produced a negative integer");
  }
  if (budget.maximum_integral_bits.has_value() &&
      c17_nonnegative_bit_length(value) >
          *budget.maximum_integral_bits) {
    return c17_resource<void>(
        "c17.final_categorical_budget_exhausted",
        "the final exact categorical " + std::string(role) +
            " exceeds the authored integral-bit budget");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> enforce_c17_exact_mass_budget(
    const ExactRational& mass, const PmfRepresentationBudget& budget,
    const std::string_view role) {
  if (!mass.is_nonnegative()) {
    return c17_internal<void>(
        "c17.branch_mass_negative",
        "an exact branch mass became negative during " +
            std::string(role));
  }
  if (!budget.maximum_integral_bits.has_value()) {
    return Result<void>::success();
  }
  if (c17_nonnegative_bit_length(mass.numerator()) >
          *budget.maximum_integral_bits ||
      c17_nonnegative_bit_length(mass.denominator()) >
          *budget.maximum_integral_bits) {
    return c17_resource<void>(
        "c17.branch_mass_budget_exhausted",
        "the exact " + std::string(role) +
            " exceeds the authored integral-bit budget");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ExactRational> multiply_branch_mass(
    const ExactRational& left, const ExactRational& right,
    const PmfRepresentationBudget& budget) {
  if (!left.is_nonnegative() || !right.is_nonnegative()) {
    return c17_internal<ExactRational>(
        "c17.branch_mass_negative",
        "a conditional probability factor became negative");
  }
  if (c17_product_provably_exceeds_budget(
          left.numerator(), right.numerator(), budget) ||
      c17_product_provably_exceeds_budget(
          left.denominator(), right.denominator(), budget)) {
    return c17_resource<ExactRational>(
        "c17.branch_mass_budget_exhausted",
        "an exact branch-product scratch integer provably exceeds the "
        "authored integral-bit budget");
  }
  BigInt numerator = left.numerator() * right.numerator();
  BigInt denominator = left.denominator() * right.denominator();
  auto numerator_within = enforce_c17_integral_budget(
      numerator, budget, "branch-product numerator scratch");
  auto denominator_within = enforce_c17_integral_budget(
      denominator, budget, "branch-product denominator scratch");
  if (!numerator_within) {
    return Result<ExactRational>::failure(numerator_within.error());
  }
  if (!denominator_within) {
    return Result<ExactRational>::failure(denominator_within.error());
  }
  auto product = ExactRational::make(std::move(numerator),
                                     std::move(denominator));
  if (!product) {
    return Result<ExactRational>::failure(product.error());
  }
  auto within = enforce_c17_exact_mass_budget(
      product.value(), budget, "branch product");
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  return product;
}

[[nodiscard]] Result<ExactRational> add_branch_mass(
    const ExactRational& left, const ExactRational& right,
    const PmfRepresentationBudget& budget, const std::string_view role) {
  if (!left.is_nonnegative() || !right.is_nonnegative()) {
    return c17_internal<ExactRational>(
        "c17.branch_mass_negative",
        "a probability mass became negative before " + std::string(role));
  }
  const BigInt divisor =
      gcd_nonnegative(left.denominator(), right.denominator());
  const BigInt reduced_left_denominator = left.denominator() / divisor;
  if (c17_product_provably_exceeds_budget(
          reduced_left_denominator, right.denominator(), budget)) {
    return c17_resource<ExactRational>(
        "c17.branch_mass_budget_exhausted",
        "the exact " + std::string(role) +
            " denominator scratch provably exceeds the authored "
            "integral-bit budget");
  }
  const BigInt common =
      reduced_left_denominator * right.denominator();
  auto within = enforce_c17_integral_budget(
      common, budget, std::string(role) + " denominator scratch");
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  const BigInt left_multiplier = common / left.denominator();
  const BigInt right_multiplier = common / right.denominator();
  if (c17_product_provably_exceeds_budget(
          left.numerator(), left_multiplier, budget) ||
      c17_product_provably_exceeds_budget(
          right.numerator(), right_multiplier, budget)) {
    return c17_resource<ExactRational>(
        "c17.branch_mass_budget_exhausted",
        "the exact " + std::string(role) +
            " numerator scratch provably exceeds the authored integral-bit "
            "budget");
  }
  const BigInt scaled_left = left.numerator() * left_multiplier;
  const BigInt scaled_right = right.numerator() * right_multiplier;
  within = enforce_c17_integral_budget(
      scaled_left, budget, std::string(role) + " left numerator scratch");
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  within = enforce_c17_integral_budget(
      scaled_right, budget, std::string(role) + " right numerator scratch");
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  if (c17_sum_exceeds_budget(scaled_left, scaled_right, budget)) {
    return c17_resource<ExactRational>(
        "c17.branch_mass_budget_exhausted",
        "the exact " + std::string(role) +
            " numerator sum exceeds the authored integral-bit budget");
  }
  BigInt numerator = scaled_left + scaled_right;
  within = enforce_c17_integral_budget(
      numerator, budget, std::string(role) + " numerator scratch");
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  auto sum = ExactRational::make(std::move(numerator), common);
  if (!sum) {
    return Result<ExactRational>::failure(sum.error());
  }
  within = enforce_c17_exact_mass_budget(sum.value(), budget, role);
  if (!within) {
    return Result<ExactRational>::failure(within.error());
  }
  return sum;
}

struct FinalCategoricalBuild final {
  ExactCategoricalImageV1 categorical;
  std::vector<ExactRational> cumulative;
  std::vector<long double> numerical;
  std::vector<NumericalProbabilityImageStatusV1> numerical_status;
};

[[nodiscard]] Result<FinalCategoricalBuild> build_final_categorical(
    const std::span<const ExactRational> masses,
    const PmfRepresentationBudget& budget) {
  if (masses.empty()) {
    return c17_internal<FinalCategoricalBuild>(
        "c17.final_row_empty",
        "the composed exact kernel row has no complete outcomes");
  }
  BigInt common_denominator = 1;
  for (const ExactRational& mass : masses) {
    if (!mass.is_nonnegative()) {
      return c17_internal<FinalCategoricalBuild>(
          "c17.final_row_negative_mass",
          "an exact branch product became negative");
    }
    const BigInt divisor =
        gcd_nonnegative(common_denominator, mass.denominator());
    const BigInt reduced_common = common_denominator / divisor;
    if (c17_product_provably_exceeds_budget(
            reduced_common, mass.denominator(), budget)) {
      return c17_resource<FinalCategoricalBuild>(
          "c17.final_categorical_budget_exhausted",
          "the final exact denominator LCM provably exceeds the authored "
          "integral-bit budget");
    }
    common_denominator = reduced_common * mass.denominator();
    auto within = enforce_c17_integral_budget(
        common_denominator, budget, "denominator LCM");
    if (!within) {
      return Result<FinalCategoricalBuild>::failure(within.error());
    }
  }

  std::vector<BigInt> integer_masses;
  integer_masses.reserve(masses.size());
  BigInt mass_gcd = 0;
  for (const ExactRational& mass : masses) {
    const BigInt multiplier =
        common_denominator / mass.denominator();
    if (c17_product_provably_exceeds_budget(
            mass.numerator(), multiplier, budget)) {
      return c17_resource<FinalCategoricalBuild>(
          "c17.final_categorical_budget_exhausted",
          "a final exact integral mass provably exceeds the authored "
          "integral-bit budget");
    }
    BigInt integer_mass = mass.numerator() * multiplier;
    auto within = enforce_c17_integral_budget(
        integer_mass, budget, "integral mass");
    if (!within) {
      return Result<FinalCategoricalBuild>::failure(within.error());
    }
    mass_gcd = gcd_nonnegative(mass_gcd, integer_mass);
    integer_masses.push_back(std::move(integer_mass));
  }
  if (mass_gcd == 0) {
    return c17_internal<FinalCategoricalBuild>(
        "c17.final_row_zero_mass",
        "the composed row has zero exact total mass");
  }

  std::vector<BigNat> primitive_masses;
  std::vector<BigNat> cumulative_masses;
  std::vector<ExactRational> exact_cumulative;
  std::vector<long double> numerical;
  std::vector<NumericalProbabilityImageStatusV1> numerical_status;
  primitive_masses.reserve(masses.size());
  cumulative_masses.reserve(masses.size());
  exact_cumulative.reserve(masses.size());
  numerical.reserve(masses.size());
  numerical_status.reserve(masses.size());
  BigInt integral_cumulative = 0;
  ExactRational rational_cumulative = ExactRational::zero();
  for (std::size_t index = 0U; index < masses.size(); ++index) {
    BigInt primitive = integer_masses[index] / mass_gcd;
    if (c17_sum_exceeds_budget(integral_cumulative, primitive, budget)) {
      return c17_resource<FinalCategoricalBuild>(
          "c17.final_categorical_budget_exhausted",
          "the final exact cumulative mass exceeds the authored "
          "integral-bit budget");
    }
    integral_cumulative += primitive;
    auto within = enforce_c17_integral_budget(
        primitive, budget, "primitive mass");
    if (!within) {
      return Result<FinalCategoricalBuild>::failure(within.error());
    }
    within = enforce_c17_integral_budget(
        integral_cumulative, budget, "cumulative mass");
    if (!within) {
      return Result<FinalCategoricalBuild>::failure(within.error());
    }
    auto primitive_nat = BigNat::from_big_int(std::move(primitive));
    auto cumulative_nat = BigNat::from_big_int(integral_cumulative);
    if (!primitive_nat || !cumulative_nat) {
      return c17_internal<FinalCategoricalBuild>(
          "c17.final_categorical_integer_invalid",
          "the final exact categorical masses are not natural numbers");
    }
    primitive_masses.push_back(std::move(primitive_nat).value());
    cumulative_masses.push_back(std::move(cumulative_nat).value());
    auto next_cumulative = add_branch_mass(
        rational_cumulative, masses[index], budget,
        "final exact cumulative addition");
    if (!next_cumulative) {
      return Result<FinalCategoricalBuild>::failure(
          next_cumulative.error());
    }
    rational_cumulative = std::move(next_cumulative).value();
    exact_cumulative.push_back(rational_cumulative);
    long double image = masses[index].to_long_double();
    if (image < 0.0L) {
      return c17_internal<FinalCategoricalBuild>(
          "c17.final_numerical_image_invalid",
          "a nonnegative exact mass produced a negative numerical image");
    }
    NumericalProbabilityImageStatusV1 status =
        NumericalProbabilityImageStatusV1::finite;
    if (!std::isfinite(image) || image > 1.0L) {
      status = NumericalProbabilityImageStatusV1::overflow;
    } else if (masses[index].is_positive() && image == 0.0L) {
      status = NumericalProbabilityImageStatusV1::positive_underflow;
    }
    numerical.push_back(image);
    numerical_status.push_back(status);
  }

  const BigInt primitive_denominator = common_denominator / mass_gcd;
  if (integral_cumulative != primitive_denominator) {
    return c17_internal<FinalCategoricalBuild>(
        "c17.final_categorical_mass_mismatch",
        "the final exact masses do not reproduce their common denominator");
  }
  auto denominator = BigNat::from_big_int(primitive_denominator);
  auto extent = BigNat::from_big_int(primitive_denominator - 1);
  if (!denominator || !extent) {
    return c17_internal<FinalCategoricalBuild>(
        "c17.final_categorical_denominator_invalid",
        "the final exact categorical denominator is not positive");
  }
  auto within = enforce_c17_integral_budget(
      denominator.value().value(), budget, "primitive denominator");
  if (!within) {
    return Result<FinalCategoricalBuild>::failure(within.error());
  }
  ExactCategoricalImageV1 categorical{
      std::move(denominator).value(), std::move(primitive_masses),
      std::move(cumulative_masses), extent.value().bit_length()};
  return Result<FinalCategoricalBuild>::success(FinalCategoricalBuild{
      std::move(categorical), std::move(exact_cumulative),
      std::move(numerical), std::move(numerical_status)});
}

}  // namespace

namespace detail {

Result<void> validate_resolved_action_math(
    const ResolvedInstance& instance, const TargetBacklogV1& backlog,
    const ResolvedAction& action) {
  if (!backlog.matches(instance) ||
      !action.schedule.dimension().matches(instance) ||
      !action.actual_departure.dimension().matches(instance)) {
    return c17_invalid<void>(
        "c17.resolved_action_dimension_mismatch",
        "the target backlog and common schedule/departure must bind the "
        "same resolved instance");
  }
  auto feasible = validate_schedule_feasibility(instance, action.schedule);
  if (!feasible) {
    return feasible;
  }
  for (std::size_t physical = 0U; physical < action.schedule.size();
       ++physical) {
    if (action.actual_departure.bytes()[physical] != 0U &&
        action.schedule.bytes()[physical] == 0U) {
      return c17_invalid<void>(
          "c17.resolved_action_departure_outside_schedule",
          "every realized departure bit must be contained in the common "
          "attempted schedule");
    }
  }
  feasible = validate_schedule_feasibility(instance,
                                           action.actual_departure);
  if (!feasible) {
    return feasible;
  }
  for (std::size_t target_ordinal = 0U;
       target_ordinal < backlog.size(); ++target_ordinal) {
    const std::size_t physical =
        backlog.target_at_target_ordinal(target_ordinal).ordinal();
    const bool expected = action.schedule.bytes()[physical] != 0U &&
                          !backlog.value_at_target_ordinal(
                                      target_ordinal).is_zero();
    if ((action.actual_departure.bytes()[physical] != 0U) != expected) {
      return c17_invalid<void>(
          "c17.resolved_action_target_departure_mismatch",
          "the resolved action does not retain D_e=s_e*1{N_e>0} on every "
          "target coordinate");
    }
  }
  auto identity = checked_schedule_identity(instance, action.schedule);
  if (!identity) {
    return Result<void>::failure(identity.error());
  }
  if (!(identity.value() == action.schedule_identity)) {
    return c17_invalid<void>(
        "c17.resolved_action_schedule_identity_mismatch",
        "the resolved action schedule identity is not canonical for the "
        "configured instance");
  }
  return Result<void>::success();
}

PreArrivalContext C17CoreAccess::prearrival_context(
    const ReducedStateV1& state, CausalBranchIdentityV1 branch) {
  return PreArrivalContext(state, std::move(branch));
}

ResolverContext C17CoreAccess::resolver_context(
    const ReducedStateV1& state, const OpportunityMark& opportunity) {
  return ResolverContext(state, opportunity);
}

PostArrivalContext C17CoreAccess::postarrival_context(
    const ReducedStateV1& state, const OpportunityMark& opportunity,
    const ResolvedAction& action, const ArrivalTransition& arrival) {
  return PostArrivalContext(state, opportunity, action, arrival);
}

Result<OpportunityLaw> C17CoreAccess::opportunity_law(
    std::vector<OpportunityLawAtomV1> atoms,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  auto pmf = normalize_atoms_once(std::span<const OpportunityLawAtomV1>(atoms),
                                  tolerance, std::move(budget));
  if (!pmf) {
    return Result<OpportunityLaw>::failure(pmf.error());
  }
  return Result<OpportunityLaw>::success(OpportunityLaw(
      std::move(atoms), std::move(pmf).value()));
}

OpportunityLaw C17CoreAccess::prepared_opportunity_law(
    PreparedOpportunityEnumeratorV1 enumerator,
    PreparedOpportunitySamplerV1 sampler) {
  return OpportunityLaw(std::move(enumerator), std::move(sampler));
}

Result<ActionLaw> C17CoreAccess::action_law(
    std::vector<ActionLawAtomV1> atoms, const ExactRational& tolerance,
    PmfRepresentationBudget budget, PreparedActionSamplerV1 sampler) {
  auto pmf = normalize_atoms_once(std::span<const ActionLawAtomV1>(atoms),
                                  tolerance, std::move(budget));
  if (!pmf) {
    return Result<ActionLaw>::failure(pmf.error());
  }
  return Result<ActionLaw>::success(ActionLaw(
      std::move(atoms), std::move(pmf).value(), std::move(sampler)));
}

Result<ArrivalTransitionLaw> C17CoreAccess::arrival_law(
    std::vector<ArrivalTransitionLawAtomV1> atoms,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  auto pmf = normalize_atoms_once(
      std::span<const ArrivalTransitionLawAtomV1>(atoms), tolerance,
      std::move(budget));
  if (!pmf) {
    return Result<ArrivalTransitionLaw>::failure(pmf.error());
  }
  return Result<ArrivalTransitionLaw>::success(ArrivalTransitionLaw(
      std::move(atoms), std::move(pmf).value()));
}

ArrivalTransitionLaw C17CoreAccess::prepared_arrival_law(
    PreparedArrivalEnumeratorV1 enumerator,
    PreparedArrivalSamplerV1 sampler) {
  return ArrivalTransitionLaw(std::move(enumerator), std::move(sampler));
}

Result<PostClosureLaw> C17CoreAccess::postclosure_law(
    std::vector<PostClosureCandidateLawAtomV1> atoms,
    const PlugDescriptor& descriptor, const ExactRational& tolerance,
    PmfRepresentationBudget budget) {
  auto pmf = normalize_atoms_once(
      std::span<const PostClosureCandidateLawAtomV1>(atoms), tolerance,
      std::move(budget));
  if (!pmf) {
    return Result<PostClosureLaw>::failure(pmf.error());
  }
  try {
    std::vector<PostClosureLawAtomV1> checked;
    checked.reserve(atoms.size());
    for (PostClosureCandidateLawAtomV1& atom : atoms) {
      std::vector<RuntimeFieldIdV1> seen;
      seen.reserve(atom.outcome.unresolved_patch.size());
      for (const RuntimeFieldPatchV1& patch :
           atom.outcome.unresolved_patch) {
        if (!field_patch_matches_descriptor(descriptor, patch) ||
            std::ranges::find(seen, patch.field) != seen.end()) {
          return c17_invalid<PostClosureLaw>(
              "c17.cplus_field_codec_or_duplicate_patch",
              "C-plus may write each descriptor-declared surrogate-owned "
              "coordinate at most once and with its exact field codec");
        }
        seen.push_back(patch.field);
      }
      auto marks = validate_stage_marks(
          descriptor, CausalStageV1::c_plus, atom.outcome.marks);
      if (!marks) {
        return Result<PostClosureLaw>::failure(marks.error());
      }
      checked.push_back(PostClosureLawAtomV1{
          PostClosure{std::move(atom.outcome.branch),
                      UnresolvedPatch(
                          std::move(atom.outcome.unresolved_patch)),
                      std::move(atom.outcome.marks)},
          std::move(atom.raw_mass), atom.structural_support});
    }
    return Result<PostClosureLaw>::success(PostClosureLaw(
        std::move(checked), std::move(pmf).value()));
  } catch (const std::bad_alloc&) {
    return c17_resource<PostClosureLaw>(
        "c17.postclosure_row_allocation_exhausted",
        "forming the checked C-plus row exceeded the host resource "
        "envelope");
  }
}

PostClosureLaw C17CoreAccess::prepared_postclosure_law(
    PreparedPostClosureEnumeratorV1 enumerator,
    PreparedPostClosureSamplerV1 sampler) {
  return PostClosureLaw(std::move(enumerator), std::move(sampler));
}

ActionLaw C17CoreAccess::action_sampler(PreparedActionSamplerV1 sampler) {
  return ActionLaw({}, std::nullopt, std::move(sampler));
}

std::span<const OpportunityLawAtomV1> C17CoreAccess::atoms(
    const OpportunityLaw& law) noexcept {
  return law.atoms_;
}

std::span<const ActionLawAtomV1> C17CoreAccess::atoms(
    const ActionLaw& law) noexcept {
  return law.atoms_;
}

std::span<const ArrivalTransitionLawAtomV1> C17CoreAccess::atoms(
    const ArrivalTransitionLaw& law) noexcept {
  return law.atoms_;
}

std::span<const PostClosureLawAtomV1> C17CoreAccess::atoms(
    const PostClosureLaw& law) noexcept {
  return law.atoms_;
}

const NormalizedPmf* C17CoreAccess::pmf(
    const OpportunityLaw& law) noexcept {
  return law.pmf_ ? &*law.pmf_ : nullptr;
}

const NormalizedPmf* C17CoreAccess::pmf(const ActionLaw& law) noexcept {
  return law.pmf_ ? &*law.pmf_ : nullptr;
}

const NormalizedPmf* C17CoreAccess::pmf(
    const ArrivalTransitionLaw& law) noexcept {
  return law.pmf_ ? &*law.pmf_ : nullptr;
}

const NormalizedPmf* C17CoreAccess::pmf(
    const PostClosureLaw& law) noexcept {
  return law.pmf_ ? &*law.pmf_ : nullptr;
}

Result<OpportunityLaw> C17CoreAccess::apply_opportunity_enumeration(
    const OpportunityLaw& law,
    const TargetBacklogV1& exact_prearrival_backlog,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  if (law.state_ != OpportunityLaw::State::prepared || !law.enumerator_) {
    return c17_invalid<OpportunityLaw>(
        "c17.opportunity_law_not_prepared_enumerable",
        "C-minus enumeration requires one unapplied prepared law");
  }
  auto enumerated = law.enumerator_();
  if (!enumerated) {
    return Result<OpportunityLaw>::failure(enumerated.error());
  }
  for (OpportunityLawAtomV1& atom : enumerated.value()) {
    if (atom.outcome.prearrival_backlog.has_value() &&
        !(*atom.outcome.prearrival_backlog == exact_prearrival_backlog)) {
      return c17_invalid<OpportunityLaw>(
          "c17.opportunity_exact_backlog_mismatch",
          "C-minus changed its framework-supplied exact pre-arrival "
          "backlog");
    }
    if (atom.outcome.exact_opportunity_evidence.has_value() &&
        !exact_prearrival_backlog.matches_full_backlog_projection(
            atom.outcome.exact_opportunity_evidence->evaluation_backlog())) {
      return c17_invalid<OpportunityLaw>(
          "c17.opportunity_evidence_backlog_mismatch",
          "C-minus exact opportunity evidence uses another backlog");
    }
    atom.outcome.prearrival_backlog = exact_prearrival_backlog;
  }
  return opportunity_law(std::move(enumerated).value(), tolerance,
                         std::move(budget));
}

Result<OpportunityMark> C17CoreAccess::apply_opportunity_realization(
    const OpportunityLaw& law,
    const TargetBacklogV1& exact_prearrival_backlog,
    DeterministicRng& rng, const ExactRational& tolerance,
    PmfRepresentationBudget budget) {
  if (law.state_ != OpportunityLaw::State::prepared) {
    return c17_invalid<OpportunityMark>(
        "c17.opportunity_law_already_applied",
        "a C-minus law cannot be applied more than once");
  }
  if (law.enumerator_) {
    auto materialized = apply_opportunity_enumeration(
        law, exact_prearrival_backlog, tolerance, std::move(budget));
    if (!materialized) {
      return Result<OpportunityMark>::failure(materialized.error());
    }
    const std::size_t selected =
        sample_categorical(*materialized.value().pmf_, rng);
    OpportunityMark outcome = materialized.value().atoms_[selected].outcome;
    outcome.branch = child_branch(outcome.branch, selected);
    return Result<OpportunityMark>::success(std::move(outcome));
  }
  if (!law.sampler_) {
    return c17_invalid<OpportunityMark>(
        "c17.opportunity_law_not_realizable",
        "the prepared C-minus law has no exact row or sampler");
  }
  auto sampled = law.sampler_(rng);
  if (!sampled) {
    return Result<OpportunityMark>::failure(sampled.error());
  }
  OpportunityMark outcome = std::move(sampled).value();
  if (outcome.prearrival_backlog.has_value() &&
      !(*outcome.prearrival_backlog == exact_prearrival_backlog)) {
    return c17_invalid<OpportunityMark>(
        "c17.opportunity_exact_backlog_mismatch",
        "C-minus changed its framework-supplied exact pre-arrival backlog");
  }
  if (outcome.exact_opportunity_evidence.has_value() &&
      !exact_prearrival_backlog.matches_full_backlog_projection(
          outcome.exact_opportunity_evidence->evaluation_backlog())) {
    return c17_invalid<OpportunityMark>(
        "c17.opportunity_evidence_backlog_mismatch",
        "C-minus exact opportunity evidence uses another backlog");
  }
  outcome.prearrival_backlog = exact_prearrival_backlog;
  outcome.branch = child_branch(outcome.branch, 0U);
  return Result<OpportunityMark>::success(std::move(outcome));
}

Result<ResolvedAction> C17CoreAccess::realize(
    const ActionLaw& law, DeterministicRng& rng) {
  if (law.sampler_) {
    return law.sampler_(rng);
  }
  if (!law.pmf_.has_value() || law.atoms_.size() != law.pmf_->size()) {
    return c17_internal<ResolvedAction>(
        "c17.action_law_not_realizable",
        "the prepared resolver law has neither a sampler nor an exact row");
  }
  const std::size_t selected = sample_categorical(*law.pmf_, rng);
  return Result<ResolvedAction>::success(law.atoms_[selected].outcome);
}

Result<ArrivalTransitionLaw> C17CoreAccess::apply_arrival_enumeration(
    const ArrivalTransitionLaw& law, ArrivalCapability capability,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  if (law.state_ != ArrivalTransitionLaw::State::prepared ||
      !law.enumerator_) {
    return c17_invalid<ArrivalTransitionLaw>(
        "c17.arrival_law_not_prepared_enumerable",
        "configured-arrival enumeration requires one unapplied prepared "
        "law");
  }
  const CausalBranchIdentityV1 branch = capability.branch_;
  auto consumed = consume_arrival_capability(capability, branch);
  if (!consumed) {
    return Result<ArrivalTransitionLaw>::failure(consumed.error());
  }
  auto enumerated = law.enumerator_(branch);
  if (!enumerated) {
    return Result<ArrivalTransitionLaw>::failure(enumerated.error());
  }
  for (const ArrivalTransitionLawAtomV1& atom : enumerated.value()) {
    auto valid_branch = require_upstream_branch(
        atom.outcome.branch, branch, CausalStageV1::arrival);
    if (!valid_branch) {
      return Result<ArrivalTransitionLaw>::failure(valid_branch.error());
    }
  }
  return arrival_law(std::move(enumerated).value(), tolerance,
                     std::move(budget));
}

Result<ArrivalTransition> C17CoreAccess::apply_arrival_realization(
    const ArrivalTransitionLaw& law, ArrivalCapability capability,
    DeterministicRng& rng, const ExactRational& tolerance,
    PmfRepresentationBudget budget) {
  if (law.state_ != ArrivalTransitionLaw::State::prepared) {
    return c17_invalid<ArrivalTransition>(
        "c17.arrival_law_already_applied",
        "a configured-arrival law cannot be applied more than once");
  }
  const CausalBranchIdentityV1 branch = capability.branch_;
  auto consumed = consume_arrival_capability(capability, branch);
  if (!consumed) {
    return Result<ArrivalTransition>::failure(consumed.error());
  }
  if (law.enumerator_) {
    auto enumerated = law.enumerator_(branch);
    if (!enumerated) {
      return Result<ArrivalTransition>::failure(enumerated.error());
    }
    for (const ArrivalTransitionLawAtomV1& atom : enumerated.value()) {
      auto valid_branch = require_upstream_branch(
          atom.outcome.branch, branch, CausalStageV1::arrival);
      if (!valid_branch) {
        return Result<ArrivalTransition>::failure(valid_branch.error());
      }
    }
    auto materialized = arrival_law(
        std::move(enumerated).value(), tolerance, std::move(budget));
    if (!materialized) {
      return Result<ArrivalTransition>::failure(materialized.error());
    }
    const std::size_t selected =
        sample_categorical(*materialized.value().pmf_, rng);
    ArrivalTransition outcome = materialized.value().atoms_[selected].outcome;
    outcome.branch = child_branch(branch, selected);
    return Result<ArrivalTransition>::success(std::move(outcome));
  }
  if (!law.sampler_) {
    return c17_invalid<ArrivalTransition>(
        "c17.arrival_law_not_realizable",
        "the prepared configured-arrival law has no exact row or sampler");
  }
  auto sampled = law.sampler_(branch, rng);
  if (!sampled) {
    return Result<ArrivalTransition>::failure(sampled.error());
  }
  auto valid_branch = require_upstream_branch(
      sampled.value().branch, branch, CausalStageV1::arrival);
  if (!valid_branch) {
    return Result<ArrivalTransition>::failure(valid_branch.error());
  }
  ArrivalTransition outcome = std::move(sampled).value();
  outcome.branch = child_branch(branch, 0U);
  return Result<ArrivalTransition>::success(std::move(outcome));
}

Result<PostClosureLaw> C17CoreAccess::apply_postclosure_enumeration(
    const PostClosureLaw& law, const PlugDescriptor& descriptor,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  if (law.state_ != PostClosureLaw::State::prepared || !law.enumerator_) {
    return c17_invalid<PostClosureLaw>(
        "c17.postclosure_law_not_prepared_enumerable",
        "C-plus enumeration requires one unapplied prepared law");
  }
  auto enumerated = law.enumerator_();
  if (!enumerated) {
    return Result<PostClosureLaw>::failure(enumerated.error());
  }
  return postclosure_law(std::move(enumerated).value(), descriptor,
                         tolerance, std::move(budget));
}

Result<PostClosure> C17CoreAccess::apply_postclosure_realization(
    const PostClosureLaw& law, const PlugDescriptor& descriptor,
    DeterministicRng& rng, const ExactRational& tolerance,
    PmfRepresentationBudget budget) {
  if (law.state_ != PostClosureLaw::State::prepared) {
    return c17_invalid<PostClosure>(
        "c17.postclosure_law_already_applied",
        "a C-plus law cannot be applied more than once");
  }
  if (law.enumerator_) {
    auto materialized = apply_postclosure_enumeration(
        law, descriptor, tolerance, std::move(budget));
    if (!materialized) {
      return Result<PostClosure>::failure(materialized.error());
    }
    const std::size_t selected =
        sample_categorical(*materialized.value().pmf_, rng);
    PostClosure outcome = materialized.value().atoms_[selected].outcome;
    outcome.branch = child_branch(outcome.branch, selected);
    return Result<PostClosure>::success(std::move(outcome));
  }
  if (!law.sampler_) {
    return c17_invalid<PostClosure>(
        "c17.postclosure_law_not_realizable",
        "the prepared C-plus law has no exact row or sampler");
  }
  auto sampled = law.sampler_(rng);
  if (!sampled) {
    return Result<PostClosure>::failure(sampled.error());
  }
  PostClosure outcome = std::move(sampled).value();
  std::vector<RuntimeFieldIdV1> seen;
  for (const RuntimeFieldPatchV1& patch : outcome.unresolved_patch.fields()) {
    if (!field_patch_matches_descriptor(descriptor, patch) ||
        std::ranges::find(seen, patch.field) != seen.end()) {
      return c17_invalid<PostClosure>(
          "c17.cplus_field_codec_or_duplicate_patch",
          "C-plus may write each descriptor-declared surrogate-owned "
          "coordinate at most once and with its exact field codec");
    }
    seen.push_back(patch.field);
  }
  auto marks = validate_stage_marks(
      descriptor, CausalStageV1::c_plus, outcome.marks);
  if (!marks) {
    return Result<PostClosure>::failure(marks.error());
  }
  outcome.branch = child_branch(outcome.branch, 0U);
  return Result<PostClosure>::success(std::move(outcome));
}

ArrivalCapability C17CoreAccess::arrival_capability(
    CausalBranchIdentityV1 branch) {
  return ArrivalCapability(std::move(branch));
}

Result<void> C17CoreAccess::consume_arrival_capability(
    ArrivalCapability& capability,
    const CausalBranchIdentityV1& branch) {
  if (!capability.available_ || !(capability.branch_ == branch)) {
    return c17_invalid<void>(
        "c17.arrival_capability_reused_or_mismatched",
        "the one-use configured-arrival capability was reused or belongs "
        "to another upstream branch");
  }
  capability.available_ = false;
  return Result<void>::success();
}

ResolvedStateInputs C17CoreAccess::resolved_state_inputs(
    const ResolvedInstance& instance, ReducedStateV1 pre_state,
    OpportunityMark opportunity, ResolvedAction action,
    ArrivalTransition arrival, PostClosure postclosure,
    const PlugDescriptor& descriptor,
    ExactReducedStateSchemaV1 state_schema,
    OptimizerExecutionContext& optimizer_context) {
  return ResolvedStateInputs(instance, std::move(pre_state),
                             std::move(opportunity), std::move(action),
                             std::move(arrival), std::move(postclosure),
                             descriptor, std::move(state_schema),
                             optimizer_context);
}

CompletedReducedEdge C17CoreAccess::completed_edge(
    ReducedStateV1 pre_state, ReducedStateV1 successor_state,
    OpportunityMark opportunity, ResolvedAction action,
    ArrivalTransition arrival, PostClosure postclosure,
    std::vector<CausalMarkV1> marks) {
  return CompletedReducedEdge(
      std::move(pre_state), std::move(successor_state),
      std::move(opportunity), std::move(action), std::move(arrival),
      std::move(postclosure), std::move(marks));
}

MarkedKernelRow C17CoreAccess::marked_row(
    std::vector<MarkedKernelRowAtomV1> atoms,
    ExactRational exact_total_mass,
    std::vector<StageMassDiagnosticV1> stage_mass_diagnostics,
    ExactCategoricalImageV1 categorical) {
  long double sum = 0.0L;
  long double correction = 0.0L;
  NumericalProbabilityImageStatusV1 status =
      NumericalProbabilityImageStatusV1::finite;
  for (const MarkedKernelRowAtomV1& atom : atoms) {
    const long double value = atom.numerical_image;
    const long double updated = sum + value;
    if (std::fabs(sum) >= std::fabs(value)) {
      correction += (sum - updated) + value;
    } else {
      correction += (value - updated) + sum;
    }
    sum = updated;
    if (atom.numerical_image_status ==
        NumericalProbabilityImageStatusV1::overflow) {
      status = NumericalProbabilityImageStatusV1::overflow;
    } else if (status == NumericalProbabilityImageStatusV1::finite &&
               atom.numerical_image_status ==
                   NumericalProbabilityImageStatusV1::positive_underflow) {
      status = NumericalProbabilityImageStatusV1::positive_underflow;
    }
  }
  const long double compensated_total = sum + correction;
  return MarkedKernelRow(std::move(atoms), std::move(exact_total_mass),
                         std::move(stage_mass_diagnostics),
                         std::move(categorical),
                         CompensatedNumericalRowImageV1{
                             compensated_total,
                             compensated_total - 1.0L, status});
}

V0WitnessReport C17CoreAccess::v0_report(
    V0WitnessBindingsV1 bindings,
    std::vector<V0WitnessEntryV1> entries, const bool passed) {
  return V0WitnessReport(std::move(bindings), std::move(entries), passed);
}

Digest256 C17CoreAccess::schedule_identity(
    const ResolvedInstance& instance, const Schedule& schedule) {
  auto identity = checked_schedule_identity(instance, schedule);
  assert(identity.has_value());
  return std::move(identity).value();
}

}  // namespace detail

Result<OpportunityLaw> C17AuditedFrameworkMint::prepare_cminus_law(
    const SurrogatePlug& plug, const ReducedStateV1& state) {
  const CausalSurrogateOperationsV1* operations =
      causal_operations_v1(plug);
  if (operations == nullptr || !operations->c_minus.has_value() ||
      (!operations->c_minus->has_operation() &&
       !operations->c_minus->has_exact_enumerator())) {
    return c17_invalid<OpportunityLaw>(
        "c17.cminus_operation_unavailable",
        "the active surrogate plug has no C-minus sampler or exact law");
  }
  const CMinusOperationSchemaV1 schema = operations->c_minus->schema();
  if (!(state.codec == schema.predecision_state_codec)) {
    return c17_invalid<OpportunityLaw>(
        "c17.cminus_state_codec_mismatch",
        "C-minus received a predecision state outside its declared codec");
  }
  auto state_digest = reduced_state_identity(state);
  if (!state_digest) {
    return Result<OpportunityLaw>::failure(state_digest.error());
  }
  CausalBranchIdentityV1 branch{std::move(state_digest).value(), {}};
  const CMinusInputV1 input{state};
  PreparedOpportunityEnumeratorV1 enumerator;
  if (operations->c_minus->has_exact_enumerator()) {
    EnumerateCMinusExactLawV1 operation =
        operations->c_minus->fresh_exact_enumerator();
    enumerator = [operation = std::move(operation), input, branch,
                  schema]() mutable
        -> Result<std::vector<OpportunityLawAtomV1>> {
      auto output = operation(input);
      if (!output) {
        return Result<std::vector<OpportunityLawAtomV1>>::failure(
            output.error());
      }
      std::vector<OpportunityLawAtomV1> atoms;
      atoms.reserve(output.value().size());
      for (EnumeratedCMinusAtomV1& raw : output.value()) {
        auto valid = validate_cminus_output_schema(schema, raw.output);
        if (!valid) {
          return Result<std::vector<OpportunityLawAtomV1>>::failure(
              valid.error());
        }
        if (raw.output.resolver_face.has_value()) {
          canonicalize_emitted_face(*raw.output.resolver_face);
        }
        atoms.push_back(OpportunityLawAtomV1{
            OpportunityMark{branch, std::nullopt,
                            std::move(raw.output.resolver_face),
                            std::move(raw.output.exact_opportunity_evidence),
                            std::move(raw.output.opportunity),
                            std::move(raw.output.jointly_emitted_marks)},
            raw.mass.exact_value(), raw.mass.structural_support()});
      }
      return Result<std::vector<OpportunityLawAtomV1>>::success(
          std::move(atoms));
    };
  }
  PreparedOpportunitySamplerV1 sampler;
  if (operations->c_minus->has_operation()) {
    CMinusCallbackV1 operation = operations->c_minus->fresh_operation();
    sampler = [operation = std::move(operation), input, branch, schema](
                  DeterministicRng& rng) mutable -> Result<OpportunityMark> {
      auto output = operation(input, rng);
      if (!output) {
        return Result<OpportunityMark>::failure(output.error());
      }
      auto valid = validate_cminus_output_schema(schema, output.value());
      if (!valid) {
        return Result<OpportunityMark>::failure(valid.error());
      }
      auto value = std::move(output).value();
      if (value.resolver_face.has_value()) {
        canonicalize_emitted_face(*value.resolver_face);
      }
      return Result<OpportunityMark>::success(OpportunityMark{
          branch, std::nullopt, std::move(value.resolver_face),
          std::move(value.exact_opportunity_evidence),
          std::move(value.opportunity),
          std::move(value.jointly_emitted_marks)});
    };
  }
  return Result<OpportunityLaw>::success(
      detail::C17CoreAccess::prepared_opportunity_law(
          std::move(enumerator), std::move(sampler)));
}

Result<PostClosureLaw> C17AuditedFrameworkMint::prepare_cplus_law(
    const SurrogatePlug& plug, const ReducedStateV1& state,
    const OpportunityMark& opportunity, const ResolvedAction& action,
    const ArrivalTransition& arrival) {
  if (!(opportunity.branch == action.branch) ||
      !(opportunity.branch == arrival.branch)) {
    return c17_invalid<PostClosureLaw>(
        "c17.cplus_context_branch_mismatch",
        "C-plus inputs must belong to one common upstream branch");
  }
  const CausalSurrogateOperationsV1* operations =
      causal_operations_v1(plug);
  if (operations == nullptr || !operations->c_plus.has_value() ||
      (!operations->c_plus->has_operation() &&
       !operations->c_plus->has_exact_enumerator())) {
    if (semantic_tag_v1(plug) !=
        SemanticTagV1::scalar_backlog_response) {
      return c17_invalid<PostClosureLaw>(
          "c17.cplus_operation_unavailable",
          "the active surrogate plug has no C-plus operation");
    }
    PreparedPostClosureEnumeratorV1 exact_identity =
        [branch = arrival.branch]()
        -> Result<std::vector<PostClosureCandidateLawAtomV1>> {
      return Result<std::vector<PostClosureCandidateLawAtomV1>>::success(
          {PostClosureCandidateLawAtomV1{
              PostClosureCandidateV1{branch, {}, {}},
              ExactRational::one(), true}});
    };
    PreparedPostClosureSamplerV1 sampled_identity =
        [branch = arrival.branch](DeterministicRng&)
        -> Result<PostClosure> {
      return Result<PostClosure>::success(
          PostClosure{branch,
                      UnresolvedPatch(std::vector<RuntimeFieldPatchV1>{}),
                      {}});
    };
    return Result<PostClosureLaw>::success(
        detail::C17CoreAccess::prepared_postclosure_law(
            std::move(exact_identity), std::move(sampled_identity)));
  }

  const CPlusOperationSchemaV1 schema = operations->c_plus->schema();
  const CodecIdentityV1 emitted_opportunity_codec{
      std::string(kC17EmittedOpportunityCodecIdV1),
      kC17EmittedOpportunityCodecVersionV1};
  const CodecIdentityV1 resolved_action_codec{
      std::string(kC17ResolvedActionCodecIdV1),
      kC17ResolvedActionCodecVersionV1};
  const CodecIdentityV1 configured_arrival_codec{
      std::string(kC17ConfiguredArrivalTransitionCodecIdV1),
      kC17ConfiguredArrivalTransitionCodecVersionV1};
  if (!(schema.opportunity_codec == emitted_opportunity_codec) ||
      !(schema.decision_codec == resolved_action_codec) ||
      !(schema.configured_arrival_codec == configured_arrival_codec)) {
    return c17_invalid<PostClosureLaw>(
        "c17.cplus_fixed_input_codec_mismatch",
        "C-plus must consume the three fixed lossless C17 source codecs");
  }
  auto emitted_opportunity =
      canonical_emitted_opportunity_source(opportunity);
  if (!emitted_opportunity) {
    return Result<PostClosureLaw>::failure(emitted_opportunity.error());
  }
  auto expected_decision = canonical_resolved_action_source(action);
  if (!expected_decision) {
    return Result<PostClosureLaw>::failure(expected_decision.error());
  }
  if (!(expected_decision.value() == action.decision)) {
    return c17_invalid<PostClosureLaw>(
        "c17.cplus_resolved_action_source_mismatch",
        "C-plus received a resolved action whose canonical decision record "
        "does not match its typed coordinates");
  }
  auto expected_arrival = canonical_arrival_transition_source(
      arrival.authored_slot, arrival.batch, arrival.phase_before,
      arrival.phase_after, arrival.law_digest,
      arrival.realization_identity);
  if (!expected_arrival) {
    return Result<PostClosureLaw>::failure(expected_arrival.error());
  }
  if (!(expected_arrival.value() == arrival.canonical_source)) {
    return c17_invalid<PostClosureLaw>(
        "c17.cplus_configured_arrival_source_mismatch",
        "C-plus received a configured arrival whose canonical source does "
        "not match its typed transition");
  }
  std::vector<RuntimeDecodedMarkV1> emitted = opportunity.marks;
  emitted.insert(emitted.end(), action.marks.begin(), action.marks.end());
  emitted.insert(emitted.end(), arrival.marks.begin(), arrival.marks.end());
  std::vector<RuntimeDecodedMarkV1> available;
  available.reserve(schema.read_marks.size());
  for (const RuntimeMarkIdV1& required : schema.read_marks) {
    const auto found = std::ranges::find_if(
        emitted, [&](const RuntimeDecodedMarkV1& mark) {
          return mark.mark == required;
        });
    if (found == emitted.end() ||
        std::ranges::find_if(
            std::next(found), emitted.end(),
            [&](const RuntimeDecodedMarkV1& mark) {
              return mark.mark == required;
            }) != emitted.end()) {
      return c17_invalid<PostClosureLaw>(
          "c17.cplus_read_mark_missing_or_ambiguous",
          "C-plus cannot obtain exactly one copy of each declared input "
          "mark");
    }
    available.push_back(*found);
  }
  CPlusInputV1 input{state, std::move(emitted_opportunity).value(),
                     action.decision, arrival.canonical_source,
                     std::move(available)};
  if (!(input.prearrival_state.codec == schema.prearrival_state_codec) ||
      !(input.opportunity.codec == schema.opportunity_codec) ||
      !(input.decision.codec == schema.decision_codec) ||
      !(input.configured_arrival.codec == schema.configured_arrival_codec)) {
    return c17_invalid<PostClosureLaw>(
        "c17.cplus_input_codec_mismatch",
        "C-plus received state, emitted opportunity, decision, or "
        "configured arrival outside its declared input codecs");
  }
  PreparedPostClosureEnumeratorV1 enumerator;
  if (operations->c_plus->has_exact_enumerator()) {
    EnumerateCPlusExactLawV1 operation =
        operations->c_plus->fresh_exact_enumerator();
    enumerator = [operation = std::move(operation), input, branch = arrival.branch,
                  schema]() mutable
        -> Result<std::vector<PostClosureCandidateLawAtomV1>> {
      auto output = operation(input);
      if (!output) {
        return Result<std::vector<PostClosureCandidateLawAtomV1>>::failure(
            output.error());
      }
      std::vector<PostClosureCandidateLawAtomV1> atoms;
      atoms.reserve(output.value().size());
      for (EnumeratedCPlusAtomV1& raw : output.value()) {
        auto valid = validate_cplus_output_schema(schema, raw.output);
        if (!valid) {
          return Result<std::vector<PostClosureCandidateLawAtomV1>>::failure(
              valid.error());
        }
        atoms.push_back(PostClosureCandidateLawAtomV1{
            PostClosureCandidateV1{
                branch, std::move(raw.output.unresolved_patch),
                std::move(raw.output.jointly_emitted_marks)},
            raw.mass.exact_value(), raw.mass.structural_support()});
      }
      return Result<std::vector<PostClosureCandidateLawAtomV1>>::success(
          std::move(atoms));
    };
  }
  PreparedPostClosureSamplerV1 sampler;
  if (operations->c_plus->has_operation()) {
    CPlusCallbackV1 operation = operations->c_plus->fresh_operation();
    sampler = [operation = std::move(operation), input,
               branch = arrival.branch, schema](DeterministicRng& rng) mutable
        -> Result<PostClosure> {
      auto output = operation(input, rng);
      if (!output) {
        return Result<PostClosure>::failure(output.error());
      }
      auto valid = validate_cplus_output_schema(schema, output.value());
      if (!valid) {
        return Result<PostClosure>::failure(valid.error());
      }
      auto value = std::move(output).value();
      return Result<PostClosure>::success(PostClosure{
          branch, UnresolvedPatch(std::move(value.unresolved_patch)),
          std::move(value.jointly_emitted_marks)});
    };
  }
  return Result<PostClosureLaw>::success(
      detail::C17CoreAccess::prepared_postclosure_law(
          std::move(enumerator), std::move(sampler)));
}

Result<OpportunityLaw> prepare_prearrival_closure(
    const SurrogatePlug& plug, const ReducedStateV1& state) {
  return C17AuditedFrameworkMint::prepare_cminus_law(plug, state);
}

Result<ActionLaw> prepare_reduced_action_law(
    const ResolvedInstance& instance, const ReducedStateV1& state,
    const OpportunityMark& opportunity,
    OptimizerExecutionContext& optimizer_context) {
  auto state_identity = reduced_state_identity(state);
  if (!state_identity) {
    return Result<ActionLaw>::failure(state_identity.error());
  }
  if (!(state_identity.value() == opportunity.branch.state_identity)) {
    return c17_invalid<ActionLaw>(
        "c17.resolver_state_branch_mismatch",
        "the resolver state and opportunity must belong to the same "
        "predecision branch");
  }
  if (!optimizer_context.active() ||
      !optimizer_context.matches_dimension(
          QueueDimensionToken::from_instance(instance))) {
    return c17_invalid<ActionLaw>(
        "c17.resolver_optimizer_context_mismatch",
        "the retained optimizer ledger must bind the resolved instance");
  }
  if (!opportunity.prearrival_backlog.has_value()) {
    return c17_invalid<ActionLaw>(
        "c17.resolver_exact_backlog_required",
        "the configured resolver requires the exact pre-arrival backlog");
  }
  auto resolved = resolve_emitted_face_action(
      instance, *opportunity.prearrival_backlog, opportunity);
  if (!resolved) {
    return Result<ActionLaw>::failure(resolved.error());
  }
  std::vector<ActionLawAtomV1> atoms;
  atoms.push_back(ActionLawAtomV1{std::move(resolved).value(),
                                  ExactRational::one(), true});
  return detail::C17CoreAccess::action_law(
      std::move(atoms), physical_pmf_tolerance(),
      PmfRepresentationBudget::unbounded());
}

Result<ArrivalTransitionLaw> prepare_configured_arrival_law(
    const CompiledArrivalLaw& arrival, const ArrivalPhase& phase) {
  const auto law = detail::ArrivalCoreAccess::law_core(arrival);
  const auto phase_core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!law || !phase_core || law->binding.family != phase_core->family ||
      !(law->binding == phase_core->binding)) {
    return c17_invalid<ArrivalTransitionLaw>(
        "c17.configured_arrival_phase_mismatch",
        "the predictive phase is not owned by the configured arrival law");
  }
  PreparedArrivalEnumeratorV1 enumerator;
  if (law->runtime.enumerate ||
      law->runtime.enumerate_time_homogeneous) {
    enumerator = [arrival, phase](const CausalBranchIdentityV1& branch)
        -> Result<std::vector<ArrivalTransitionLawAtomV1>> {
      auto parts = prepare_c09_arrival_parts(arrival, phase, branch);
      if (!parts) {
        return Result<std::vector<ArrivalTransitionLawAtomV1>>::failure(
            parts.error());
      }
      if (!parts.value().enumerable) {
        return c17_internal<std::vector<ArrivalTransitionLawAtomV1>>(
            "c17.configured_arrival_enumerator_disappeared",
            "the prepared C09 exact enumerator became unavailable");
      }
      return Result<std::vector<ArrivalTransitionLawAtomV1>>::success(
          std::move(parts).value().atoms);
    };
  }
  PreparedArrivalSamplerV1 sampler;
  if (law->runtime.propose) {
    sampler = [arrival, phase](const CausalBranchIdentityV1& branch,
                               DeterministicRng& rng) {
      return realize_c09_arrival(arrival, phase, branch, rng);
    };
  }
  return Result<ArrivalTransitionLaw>::success(
      detail::C17CoreAccess::prepared_arrival_law(
          std::move(enumerator), std::move(sampler)));
}

Result<PostClosureLaw> prepare_postarrival_closure(
    const SurrogatePlug& plug, const ReducedStateV1& state,
    const OpportunityMark& opportunity, const ResolvedAction& action,
    const ArrivalTransition& arrival) {
  return C17AuditedFrameworkMint::prepare_cplus_law(
      plug, state, opportunity, action, arrival);
}

Result<CompletedReducedEdge> apply_exact_reduced_update(
    ResolvedStateInputs inputs) {
  if (inputs.optimizer_context_ == nullptr || inputs.descriptor_ == nullptr ||
      !inputs.state_schema_.decode || !inputs.state_schema_.rebuild ||
      !inputs.state_schema_.validate_domain) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.exact_update_schema_incomplete",
        "the deterministic reduced update requires complete state decode, "
        "rebuild, domain, and optimizer-ledger bindings");
  }
  if (!(inputs.pre_state_.codec ==
        inputs.state_schema_.reduced_state_codec)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.reduced_state_codec_mismatch",
        "the reduced prestate does not use the sealed state codec");
  }
  if (!(inputs.opportunity_.branch == inputs.action_.branch) ||
      !(inputs.opportunity_.branch == inputs.arrival_.branch) ||
      !(inputs.opportunity_.branch == inputs.postclosure_.branch)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_branch_identity_mismatch",
        "Psi received values from different conditional branches");
  }

  auto domain = inputs.state_schema_.validate_domain(inputs.pre_state_);
  if (!domain) {
    return Result<CompletedReducedEdge>::failure(domain.error());
  }
  auto decoded = inputs.state_schema_.decode(inputs.pre_state_);
  if (!decoded) {
    return Result<CompletedReducedEdge>::failure(decoded.error());
  }
  const ExactReducedCoordinatesV1 before = decoded.value();
  ExactReducedCoordinatesV1 next = before;
  const QueueDimensionToken physical_dimension =
      QueueDimensionToken::from_instance(inputs.instance_);
  if (!next.backlog.matches(inputs.instance_) ||
      !(inputs.action_.schedule.dimension() == physical_dimension) ||
      !(inputs.action_.actual_departure.dimension() == physical_dimension)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_action_dimension_mismatch",
        "the target backlog and common schedule/departure are not bound to "
        "the same resolved instance");
  }
  auto action_math = detail::validate_resolved_action_math(
      inputs.instance_, next.backlog, inputs.action_);
  if (!action_math) {
    return Result<CompletedReducedEdge>::failure(action_math.error());
  }
  auto action_evidence = validate_action_evidence(
      inputs.instance_, next.backlog, inputs.opportunity_, inputs.action_,
      inputs.opportunity_.resolver_face.has_value());
  if (!action_evidence) {
    return Result<CompletedReducedEdge>::failure(action_evidence.error());
  }
  const auto current_phase_core =
      detail::ArrivalCoreAccess::phase_core(next.arrival_phase);
  const auto before_phase_core =
      detail::ArrivalCoreAccess::phase_core(inputs.arrival_.phase_before);
  const auto after_phase_core =
      detail::ArrivalCoreAccess::phase_core(inputs.arrival_.phase_after);
  if (!current_phase_core || !before_phase_core || !after_phase_core ||
      !inputs.arrival_.batch.binding().has_value()) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_configured_arrival_binding_mismatch",
        "Psi requires complete configured phase and batch source records");
  }
  const ArrivalBinding& batch_binding =
      *inputs.arrival_.batch.binding();
  auto catalog_digest = detail::digest_queue_catalog(
      inputs.instance_.queues());
  if (!catalog_digest) {
    return Result<CompletedReducedEdge>::failure(catalog_digest.error());
  }
  BigNat expected_after_slot = inputs.arrival_.authored_slot;
  ++expected_after_slot;
  if (!same_phase(next.arrival_phase, inputs.arrival_.phase_before) ||
      !arrival_phases_share_cursor(next.arrival_phase,
                                   inputs.arrival_.phase_before) ||
      !arrival_phases_share_cursor(inputs.arrival_.phase_before,
                                   inputs.arrival_.phase_after) ||
      inputs.arrival_.authored_slot != next.boundary_index ||
      !(current_phase_core->next_authored_slot ==
        inputs.arrival_.authored_slot) ||
      !(before_phase_core->next_authored_slot ==
        inputs.arrival_.authored_slot) ||
      !(after_phase_core->next_authored_slot == expected_after_slot) ||
      !(current_phase_core->binding == batch_binding) ||
      !(before_phase_core->binding == batch_binding) ||
      !(after_phase_core->binding == batch_binding) ||
      batch_binding.family != inputs.instance_.arrival().family() ||
      batch_binding.queue_cardinality != inputs.instance_.queues().size() ||
      batch_binding.timing !=
          TimingConvention::early_service_late_admission ||
      !(batch_binding.catalog_digest == catalog_digest.value()) ||
      !(batch_binding.law_digest == inputs.arrival_.law_digest)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_configured_arrival_binding_mismatch",
        "Psi received an arrival transition outside the configured phase, "
        "cursor lineage, slot, catalog, timing, or law identity");
  }
  auto realization_identity = arrival_transition_identity(
      inputs.arrival_.authored_slot, inputs.arrival_.batch,
      inputs.arrival_.phase_before, inputs.arrival_.phase_after,
      inputs.arrival_.law_digest);
  if (!realization_identity) {
    return Result<CompletedReducedEdge>::failure(
        realization_identity.error());
  }
  if (!(realization_identity.value() ==
        inputs.arrival_.realization_identity)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_arrival_transition_identity_mismatch",
        "the configured arrival transition does not retain its canonical "
        "full source-record identity");
  }
  auto canonical_arrival = canonical_arrival_transition_source(
      inputs.arrival_.authored_slot, inputs.arrival_.batch,
      inputs.arrival_.phase_before, inputs.arrival_.phase_after,
      inputs.arrival_.law_digest,
      inputs.arrival_.realization_identity);
  if (!canonical_arrival) {
    return Result<CompletedReducedEdge>::failure(canonical_arrival.error());
  }
  if (!(canonical_arrival.value() == inputs.arrival_.canonical_source)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_arrival_canonical_source_mismatch",
        "the configured arrival transition does not retain its unique "
        "lossless canonical source record");
  }

  const TargetBacklogV1 pre_target_backlog = next.backlog;
  std::vector<BigNat> target_values(next.backlog.values().begin(),
                                    next.backlog.values().end());
  for (std::size_t target_ordinal = 0U;
       target_ordinal < target_values.size(); ++target_ordinal) {
    const std::size_t physical =
        next.backlog.target_at_target_ordinal(target_ordinal).ordinal();
    auto after_service = checked_subtract(
        target_values[target_ordinal],
        BigNat(inputs.action_.actual_departure.bytes()[physical]));
    if (!after_service) {
      return Result<CompletedReducedEdge>::failure(after_service.error());
    }
    auto dense = inputs.instance_.queues().index_at(physical);
    if (!dense) {
      return Result<CompletedReducedEdge>::failure(dense.error());
    }
    auto admitted = project_arrival_count(
        inputs.arrival_.batch, dense.value(),
        *inputs.arrival_.batch.binding());
    if (!admitted) {
      return Result<CompletedReducedEdge>::failure(admitted.error());
    }
    target_values[target_ordinal] = std::move(after_service).value();
    target_values[target_ordinal] += admitted.value();
  }
  auto next_backlog = next.backlog.with_values(std::move(target_values));
  if (!next_backlog) {
    return Result<CompletedReducedEdge>::failure(next_backlog.error());
  }
  next.backlog = std::move(next_backlog).value();
  next.arrival_phase = inputs.arrival_.phase_after;
  ++next.boundary_index;
  const ExactReducedCoordinatesV1 postarrival = next;

  if (next.resources.has_value()) {
    auto resources = update_resource_coordinates(
        *next.resources, inputs.action_.actual_departure,
        inputs.arrival_.batch);
    if (!resources) {
      return Result<CompletedReducedEdge>::failure(resources.error());
    }
    next.resources = std::move(resources).value();
  }

  if (!next.margins.empty()) {
    std::vector<PairMargin> margins;
    margins.reserve(next.margins.size());
    for (const PairMargin& margin : next.margins) {
      const Backlog& margin_pre = margin.evaluation_backlog();
      if (!pre_target_backlog.matches_full_backlog_projection(margin_pre)) {
        return c17_invalid<CompletedReducedEdge>(
            "c17.margin_target_projection_mismatch",
            "a retained margin full evaluation backlog disagrees with the "
            "common reduced target prestate");
      }
      auto margin_departure = compute_actual_departure(
          margin_pre, inputs.action_.schedule);
      if (!margin_departure ||
          !(margin_departure.value() == inputs.action_.actual_departure)) {
        return c17_invalid<CompletedReducedEdge>(
            "c17.margin_common_departure_mismatch",
            "a retained margin full evaluation backlog does not reproduce "
            "the edge's common actual departure");
      }
      auto margin_post = apply_queue_recursion(
          margin_pre, inputs.action_.schedule, inputs.arrival_.batch);
      if (!margin_post) {
        return Result<CompletedReducedEdge>::failure(margin_post.error());
      }
      ExactMarginEdgeInputs edge(
          margin_pre, inputs.action_.actual_departure,
          inputs.arrival_.batch, margin_post.value());
      auto transition = update_margin_from_exact_edge(
          margin, edge, inputs.instance_, *inputs.optimizer_context_);
      if (!transition) {
        return Result<CompletedReducedEdge>::failure(transition.error());
      }
      PairMargin successor_margin = transition.value().next();
      if (!next.backlog.matches_full_backlog_projection(
              successor_margin.evaluation_backlog())) {
        return c17_invalid<CompletedReducedEdge>(
            "c17.margin_successor_target_projection_mismatch",
            "a retained margin successor disagrees with the common reduced "
            "target successor");
      }
      margins.push_back(std::move(successor_margin));
    }
    next.margins = std::move(margins);
  }

  if (inputs.action_.postupdate_controller_tape.has_value()) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.controller_post_map_required",
        "an opaque split-controller tape cannot be committed without its "
        "declared deterministic post-arrival map");
  }
  if (inputs.action_.interim_controller.has_value()) {
    next.controller = inputs.action_.interim_controller;
  }

  const std::size_t required_postarrival_marks =
      static_cast<std::size_t>(std::ranges::count_if(
          inputs.descriptor_->marks,
          [](const RuntimeMarkDescriptorV1& mark) {
            return mark.decoder_source ==
                   MarkDecoderSourceV1::postarrival_state;
          }));
  if (required_postarrival_marks != 0U &&
      !inputs.state_schema_.postarrival_mark_decoder.decode) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.postarrival_mark_decoder_required",
        "postarrival-state marks require the sealed framework C-plus "
        "decoder");
  }
  std::vector<CausalMarkV1> postarrival_marks;
  if (inputs.state_schema_.postarrival_mark_decoder.decode) {
    auto decoded_marks =
        inputs.state_schema_.postarrival_mark_decoder.decode(
            before, postarrival, inputs.action_, inputs.arrival_);
    if (!decoded_marks) {
      return Result<CompletedReducedEdge>::failure(decoded_marks.error());
    }
    auto bound_marks = bind_framework_mark_set(
        *inputs.descriptor_, MarkDecoderSourceV1::postarrival_state,
        CausalStageV1::c_plus, std::move(decoded_marks).value());
    if (!bound_marks) {
      return Result<CompletedReducedEdge>::failure(bound_marks.error());
    }
    postarrival_marks = std::move(bound_marks).value();
  }

  std::vector<RuntimeFieldPatchV1> expected_unresolved =
      next.unresolved_fields;
  for (const RuntimeFieldPatchV1& patch :
       inputs.postclosure_.unresolved_patch.fields()) {
    auto current = std::ranges::find_if(
        expected_unresolved, [&](const RuntimeFieldPatchV1& candidate) {
          return candidate.field == patch.field;
        });
    if (current == expected_unresolved.end()) {
      expected_unresolved.push_back(patch);
    } else {
      current->value = patch.value;
    }
  }

  auto successor = inputs.state_schema_.rebuild(
      next, inputs.postclosure_.unresolved_patch);
  if (!successor) {
    return Result<CompletedReducedEdge>::failure(successor.error());
  }
  if (!(successor.value().codec ==
        inputs.state_schema_.reduced_state_codec)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_successor_codec_mismatch",
        "the rebuilt successor left the sealed reduced-state codec");
  }
  domain = inputs.state_schema_.validate_domain(successor.value());
  if (!domain) {
    return Result<CompletedReducedEdge>::failure(domain.error());
  }
  auto decoded_successor = inputs.state_schema_.decode(successor.value());
  if (!decoded_successor) {
    return Result<CompletedReducedEdge>::failure(
        decoded_successor.error());
  }
  if (!same_exact_coordinates(next, decoded_successor.value())) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_exact_precedence_violation",
        "the rebuilt successor changed a framework-exact Psi coordinate");
  }
  if (!same_unresolved_coordinates(expected_unresolved,
                                   decoded_successor.value().unresolved_fields)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.psi_unresolved_patch_mismatch",
        "the rebuilt successor does not equal the declared unresolved C-plus "
        "patch on every surrogate-owned coordinate");
  }

  std::vector<CausalMarkV1> marks = collect_marks(
      inputs.opportunity_, inputs.action_, inputs.arrival_,
      inputs.postclosure_);
  marks.insert(marks.end(),
               std::make_move_iterator(postarrival_marks.begin()),
               std::make_move_iterator(postarrival_marks.end()));
  const std::size_t required_completed_marks =
      static_cast<std::size_t>(std::ranges::count_if(
          inputs.descriptor_->marks,
          [](const RuntimeMarkDescriptorV1& mark) {
            return mark.decoder_source ==
                   MarkDecoderSourceV1::completed_edge;
          }));
  if (required_completed_marks != 0U &&
      !inputs.state_schema_.completed_edge_mark_decoder.decode) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.completed_edge_mark_decoder_required",
        "completed-edge marks require the sealed full-edge decoder");
  }
  if (inputs.state_schema_.completed_edge_mark_decoder.decode) {
    auto decoded_marks =
        inputs.state_schema_.completed_edge_mark_decoder.decode(
            before, decoded_successor.value(), inputs.opportunity_,
            inputs.action_, inputs.arrival_, inputs.postclosure_);
    if (!decoded_marks) {
      return Result<CompletedReducedEdge>::failure(
          decoded_marks.error());
    }
    auto bound_marks = bind_framework_mark_set(
        *inputs.descriptor_, MarkDecoderSourceV1::completed_edge,
        CausalStageV1::psi, std::move(decoded_marks).value());
    if (!bound_marks) {
      return Result<CompletedReducedEdge>::failure(bound_marks.error());
    }
    marks.insert(marks.end(),
                 std::make_move_iterator(bound_marks.value().begin()),
                 std::make_move_iterator(bound_marks.value().end()));
  }
  CompletedReducedEdge edge = detail::C17CoreAccess::completed_edge(
      std::move(inputs.pre_state_), std::move(successor).value(),
      std::move(inputs.opportunity_), std::move(inputs.action_),
      std::move(inputs.arrival_), std::move(inputs.postclosure_),
      std::move(marks));
  auto complete_marks = validate_complete_edge_marks(*inputs.descriptor_,
                                                      edge);
  if (!complete_marks) {
    return Result<CompletedReducedEdge>::failure(complete_marks.error());
  }
  return Result<CompletedReducedEdge>::success(std::move(edge));
}

namespace detail {

Result<MarkedKernelRow> C17CoreAccess::compose_program_row(
    const SurrogatePlug* plug, const PlugDescriptor& descriptor,
    ResolvedInstance& instance, CompiledArrivalLaw& configured_arrival,
    ExactReducedStateSchemaV1& state_schema,
    ExactCausalProgramV1& program,
    OptimizerExecutionContext& optimizer_context,
    const ReducedStateV1& state
#if defined(MWPERF_C17_TEST_SEAMS)
    , const C17GenericCallbackProgramV1* test_callbacks
#endif
    ) {
  OptimizerCallLedgerTransaction ledger_transaction(optimizer_context);
  if (!state_schema.decode || !state_schema.rebuild ||
      !state_schema.validate_domain ||
      !(state.codec == state_schema.reduced_state_codec)) {
    return c17_invalid<MarkedKernelRow>(
        "c17.row_state_schema_incomplete",
        "row composition requires the sealed exact reduced-state schema");
  }
#if defined(MWPERF_C17_TEST_SEAMS)
  const bool direct_test_callbacks = plug == nullptr &&
                                     test_callbacks != nullptr;
  if (direct_test_callbacks &&
      (!test_callbacks->enumerate_prearrival ||
       !test_callbacks->enumerate_action ||
       !test_callbacks->enumerate_postarrival)) {
    return c17_invalid<MarkedKernelRow>(
        "c17.row_requires_exact_enumeration",
        "the direct equation fixture requires all three test enumerators");
  }
#else
  constexpr bool direct_test_callbacks = false;
#endif
  if (program.mode == ExactCausalProgramModeV1::generic_bound_operations &&
      plug == nullptr && !direct_test_callbacks) {
    return c17_invalid<MarkedKernelRow>(
        "c17.bound_causal_operations_required",
        "production generic composition requires the active sealed C16 "
        "operations");
  }
  if (closed_scalar_response_mode_v1(program.mode) &&
      plug == nullptr) {
    return c17_invalid<MarkedKernelRow>(
        "c17.three_bin_payload_required",
        "the closed three-bin composer requires its sealed response plug");
  }
  std::vector<PreparedRuntimeMarkDecoderV1> framework_decoders;
  for (const DeterministicRuntimeMarkDecoderOperationV1& decoder :
       state_schema.framework_mark_decoders) {
    if (decoder.schema().source ==
            MarkDecoderSourceV1::predecision_state ||
        decoder.schema().source ==
            MarkDecoderSourceV1::decision_schedule ||
        decoder.schema().source ==
            MarkDecoderSourceV1::configured_arrival) {
      framework_decoders.push_back(PreparedRuntimeMarkDecoderV1{
          decoder.schema(), decoder.fresh_operation()});
    }
  }
  auto domain = state_schema.validate_domain(state);
  if (!domain) {
    return Result<MarkedKernelRow>::failure(domain.error());
  }
  auto decoded = state_schema.decode(state);
  if (!decoded) {
    return Result<MarkedKernelRow>::failure(decoded.error());
  }
  const ExactReducedCoordinatesV1& coordinates = decoded.value();
  ReducedStateV1 callback_state = state;
  if (program.event_clock_semantics ==
      EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
    const UnresolvedPatch no_patch(
        std::vector<RuntimeFieldPatchV1>{});
    auto erased = callback_clock_erased_state(state_schema, state,
                                              no_patch);
    if (!erased) {
      return Result<MarkedKernelRow>::failure(erased.error());
    }
    callback_state = std::move(erased).value();
  }
  auto callback_decoded = state_schema.decode(callback_state);
  if (!callback_decoded) {
    return Result<MarkedKernelRow>::failure(callback_decoded.error());
  }
  const ExactReducedCoordinatesV1& callback_coordinates =
      callback_decoded.value();
  auto unit_state = validate_closed_three_bin_unit_state(program, coordinates);
  if (!unit_state) {
    return Result<MarkedKernelRow>::failure(unit_state.error());
  }
  auto target_binding =
      validate_target_backlog_binding(instance, descriptor,
                                      coordinates.backlog);
  if (!target_binding) {
    return Result<MarkedKernelRow>::failure(target_binding.error());
  }
  const ArrivalBinding& arrival_binding =
      arrival_law_binding(configured_arrival);
  if (arrival_binding.family != instance.arrival().family() ||
      arrival_binding.timing != instance.timing() ||
      arrival_binding.queue_cardinality != instance.queues().size() ||
      arrival_binding.timing !=
          TimingConvention::early_service_late_admission) {
    return c17_invalid<MarkedKernelRow>(
        "c17.row_configured_arrival_binding_mismatch",
        "the C09 law is not the configured early-service/late-admission "
        "arrival law for this instance");
  }
  auto state_id = reduced_state_identity(state);
  if (!state_id) {
    return Result<MarkedKernelRow>::failure(state_id.error());
  }
  const CausalBranchIdentityV1 root{std::move(state_id).value(), {}};

  Result<OpportunityLaw> opportunity_law_value =
      closed_scalar_response_mode_v1(program.mode)
          ? [&]() -> Result<OpportunityLaw> {
              auto prepared = prepare_closed_scalar_prearrival_parts(
                  *plug, instance, program.mode, coordinates, root);
              if (!prepared) {
                return Result<OpportunityLaw>::failure(
                    prepared.error());
              }
              return opportunity_law(
                  std::move(prepared).value().atoms,
                  program.conditional_row_tolerance,
                  program.representation_budget);
            }()
          : [&]() -> Result<OpportunityLaw> {
#if defined(MWPERF_C17_TEST_SEAMS)
              if (direct_test_callbacks) {
                auto atoms_value = test_callbacks->enumerate_prearrival(
                    prearrival_context(callback_state, root));
                if (!atoms_value) {
                  return Result<OpportunityLaw>::failure(
                      atoms_value.error());
                }
                return opportunity_law(
                    std::move(atoms_value).value(),
                    program.conditional_row_tolerance,
                    program.representation_budget);
              }
#endif
              auto prepared = prepare_prearrival_closure(*plug,
                                                          callback_state);
              if (!prepared) {
                return Result<OpportunityLaw>::failure(prepared.error());
              }
              auto materialized = apply_opportunity_enumeration(
                  prepared.value(), coordinates.backlog,
                  program.conditional_row_tolerance,
                  program.representation_budget);
              if (!materialized) {
                return materialized;
              }
              if (program.event_clock_semantics ==
                  EventClockSemanticsV1::
                      finite_phase_time_homogeneous_quotient) {
                // C-minus must see only the clock-erased structural state,
                // but branch/RNG/provenance identities remain rooted in the
                // raw clockful state.  The prepared adapter derives its
                // opaque branch from its callback input, so re-anchor only
                // that framework-owned branch envelope after enumeration.
                // The provider's outputs, masses, marks, and exact backlog
                // evidence are otherwise unchanged.
                for (OpportunityLawAtomV1& atom :
                     materialized.value().atoms_) {
                  atom.outcome.branch = root;
                }
              }
              return materialized;
            }();
  if (!opportunity_law_value) {
    return Result<MarkedKernelRow>::failure(opportunity_law_value.error());
  }
  OpportunityLaw opportunity_prepared =
      std::move(opportunity_law_value).value();
  const NormalizedPmf* opportunity_pmf = pmf(opportunity_prepared);
  if (opportunity_pmf == nullptr) {
    return c17_invalid<MarkedKernelRow>(
        "c17.row_requires_exact_enumeration",
        "C-minus supplied only a sampler to the exact row compiler");
  }
  const CanonicalRuntimeValueV1 predecision_source{
      callback_state.codec, callback_state.canonical_value};
  auto framework_predecision_marks = apply_prepared_mark_decoders(
      framework_decoders, MarkDecoderSourceV1::predecision_state,
      predecision_source);
  if (!framework_predecision_marks) {
    return Result<MarkedKernelRow>::failure(
        framework_predecision_marks.error());
  }

  std::vector<StageMassDiagnosticV1> diagnostics;
  diagnostics.push_back(stage_diagnostic(
      CausalStageV1::c_minus, root, atoms(opportunity_prepared),
      *opportunity_pmf));
  struct AggregatedBranch final {
    CompletedReducedEdge edge;
    ExactRational mass;
    bool structural_support;
  };
  std::vector<AggregatedBranch> aggregated;

  const auto opportunity_support = atoms(opportunity_prepared);
  for (std::size_t opportunity_index = 0U;
       opportunity_index < opportunity_support.size();
       ++opportunity_index) {
    OpportunityMark opportunity =
        opportunity_support[opportunity_index].outcome;
    auto branch_ok = require_upstream_branch(
        opportunity.branch, root, CausalStageV1::c_minus);
    if (!branch_ok) {
      return Result<MarkedKernelRow>::failure(branch_ok.error());
    }
    opportunity.branch = child_branch(root, opportunity_index);
    opportunity.marks.insert(
        opportunity.marks.end(), framework_predecision_marks.value().begin(),
        framework_predecision_marks.value().end());
    if (!opportunity.prearrival_backlog.has_value() ||
        !(*opportunity.prearrival_backlog == coordinates.backlog) ||
        (opportunity.exact_opportunity_evidence.has_value() &&
         !coordinates.backlog.matches_full_backlog_projection(
             opportunity.exact_opportunity_evidence->evaluation_backlog()))) {
      return c17_invalid<MarkedKernelRow>(
          "c17.opportunity_exact_backlog_mismatch",
          "a C-minus atom is not bound to the immutable exact pre-arrival "
          "backlog");
    }
    auto stage_marks = validate_stage_marks(
        descriptor, CausalStageV1::c_minus, opportunity.marks);
    if (!stage_marks) {
      return Result<MarkedKernelRow>::failure(stage_marks.error());
    }
    std::vector<CausalStageV1> action_trace{CausalStageV1::c_minus};
    action_trace.push_back(CausalStageV1::resolver);

    Result<ActionLaw> action_law_value =
        closed_scalar_response_mode_v1(program.mode)
            ? [&]() -> Result<ActionLaw> {
                auto prepared = prepare_closed_scalar_action_parts(
                    instance, coordinates, opportunity, program.mode);
                if (!prepared) {
                  return Result<ActionLaw>::failure(
                      prepared.error());
                }
                return action_law(
                    std::move(prepared).value().atoms,
                    program.conditional_row_tolerance,
                    program.representation_budget);
              }()
            : [&]() -> Result<ActionLaw> {
#if defined(MWPERF_C17_TEST_SEAMS)
                if (direct_test_callbacks) {
                  auto atoms_value = test_callbacks->enumerate_action(
                      resolver_context(callback_state, opportunity),
                      optimizer_context);
                  if (!atoms_value) {
                    return Result<ActionLaw>::failure(atoms_value.error());
                  }
                  return action_law(
                      std::move(atoms_value).value(),
                      program.conditional_row_tolerance,
                      program.representation_budget);
                }
#endif
                return prepare_reduced_action_law(
                    instance, state, opportunity, optimizer_context);
              }();
    if (!action_law_value) {
      return Result<MarkedKernelRow>::failure(action_law_value.error());
    }
    ActionLaw action_prepared = std::move(action_law_value).value();
    const NormalizedPmf* action_pmf = pmf(action_prepared);
    if (action_pmf == nullptr) {
      return c17_invalid<MarkedKernelRow>(
          "c17.row_requires_exact_enumeration",
          "the resolver supplied only a sampler to the exact row compiler");
    }
    diagnostics.push_back(stage_diagnostic(
        CausalStageV1::resolver, opportunity.branch, atoms(action_prepared),
        *action_pmf));

    const auto action_support = atoms(action_prepared);
    for (std::size_t action_index = 0U;
         action_index < action_support.size(); ++action_index) {
      ResolvedAction action = action_support[action_index].outcome;
      branch_ok = require_upstream_branch(
          action.branch, opportunity.branch, CausalStageV1::resolver);
      if (!branch_ok) {
        return Result<MarkedKernelRow>::failure(branch_ok.error());
      }
      action.branch = child_branch(opportunity.branch, action_index);
      if (closed_scalar_response_mode_v1(program.mode)) {
        auto framework_marks = framework_three_bin_action_marks(
            instance, descriptor, coordinates, action);
        if (!framework_marks) {
          return Result<MarkedKernelRow>::failure(
              framework_marks.error());
        }
        action.marks.insert(action.marks.end(),
                            framework_marks.value().begin(),
                            framework_marks.value().end());
      }
      auto decoded_action_marks = apply_prepared_mark_decoders(
          framework_decoders, MarkDecoderSourceV1::decision_schedule,
          action.decision);
      if (!decoded_action_marks) {
        return Result<MarkedKernelRow>::failure(
            decoded_action_marks.error());
      }
      action.marks.insert(action.marks.end(),
                          decoded_action_marks.value().begin(),
                          decoded_action_marks.value().end());
      auto action_math = validate_resolved_action_math(
          instance, coordinates.backlog, action);
      if (!action_math) {
        return Result<MarkedKernelRow>::failure(action_math.error());
      }
      auto action_evidence = validate_action_evidence(
          instance, coordinates.backlog, opportunity, action,
          program.mode ==
                  ExactCausalProgramModeV1::generic_bound_operations &&
              !direct_test_callbacks);
      if (!action_evidence) {
        return Result<MarkedKernelRow>::failure(action_evidence.error());
      }
      stage_marks = validate_stage_marks(
          descriptor, CausalStageV1::resolver, action.marks);
      if (!stage_marks) {
        return Result<MarkedKernelRow>::failure(stage_marks.error());
      }
      std::vector<CausalStageV1> arrival_trace = action_trace;
      arrival_trace.push_back(CausalStageV1::arrival);

      auto prepared_arrival = prepare_configured_arrival_law(
          configured_arrival, coordinates.arrival_phase);
      if (!prepared_arrival) {
        return Result<MarkedKernelRow>::failure(prepared_arrival.error());
      }
      if (!prepared_arrival.value().enumerable()) {
        return c17_invalid<MarkedKernelRow>(
            "c17.row_requires_exact_enumeration",
            "the configured C09 arrival law has no exact transition row");
      }
      auto arrival_law_value = apply_arrival_enumeration(
          prepared_arrival.value(), arrival_capability(action.branch),
          program.conditional_row_tolerance, program.representation_budget);
      if (!arrival_law_value) {
        return Result<MarkedKernelRow>::failure(arrival_law_value.error());
      }
      ArrivalTransitionLaw arrival_prepared =
          std::move(arrival_law_value).value();
      const NormalizedPmf* arrival_pmf = pmf(arrival_prepared);
      if (arrival_pmf == nullptr) {
        return c17_internal<MarkedKernelRow>(
            "c17.configured_arrival_row_missing",
            "C09 advertised enumeration but produced no exact row");
      }
      diagnostics.push_back(stage_diagnostic(
          CausalStageV1::arrival, action.branch, atoms(arrival_prepared),
          *arrival_pmf));

      const auto arrival_support = atoms(arrival_prepared);
      for (std::size_t arrival_index = 0U;
           arrival_index < arrival_support.size(); ++arrival_index) {
        ArrivalTransition arrival = arrival_support[arrival_index].outcome;
        branch_ok = require_upstream_branch(
            arrival.branch, action.branch, CausalStageV1::arrival);
        if (!branch_ok) {
          return Result<MarkedKernelRow>::failure(branch_ok.error());
        }
        arrival.branch = child_branch(action.branch, arrival_index);
        ArrivalTransition callback_arrival = arrival;
        if (program.event_clock_semantics ==
            EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient) {
          auto erased = callback_clock_erased_arrival(
              arrival, callback_coordinates.arrival_phase);
          if (!erased) {
            return Result<MarkedKernelRow>::failure(erased.error());
          }
          callback_arrival = std::move(erased).value();
        }
        auto decoded_arrival_marks = apply_prepared_mark_decoders(
            framework_decoders, MarkDecoderSourceV1::configured_arrival,
            callback_arrival.canonical_source);
        if (!decoded_arrival_marks) {
          return Result<MarkedKernelRow>::failure(
              decoded_arrival_marks.error());
        }
        arrival.marks.insert(arrival.marks.end(),
                             decoded_arrival_marks.value().begin(),
                             decoded_arrival_marks.value().end());
        callback_arrival.marks = arrival.marks;
        stage_marks = validate_stage_marks(
            descriptor, CausalStageV1::arrival, arrival.marks);
        if (!stage_marks) {
          return Result<MarkedKernelRow>::failure(stage_marks.error());
        }
        std::vector<CausalStageV1> post_trace = arrival_trace;
        post_trace.push_back(CausalStageV1::c_plus);
        OpportunityMark post_opportunity = opportunity;
        ResolvedAction post_action = action;
        post_opportunity.branch = arrival.branch;
        post_action.branch = arrival.branch;

        Result<PostClosureLaw> post_law_value =
            closed_scalar_response_mode_v1(program.mode)
                ? postclosure_law(
                      identity_postclosure_atoms(arrival.branch), descriptor,
                      program.conditional_row_tolerance,
                      program.representation_budget)
                : [&]() -> Result<PostClosureLaw> {
#if defined(MWPERF_C17_TEST_SEAMS)
                    if (direct_test_callbacks) {
                      auto atoms_value =
                          test_callbacks->enumerate_postarrival(
                              postarrival_context(
                                  callback_state, post_opportunity,
                                  post_action, callback_arrival));
                      if (!atoms_value) {
                        return Result<PostClosureLaw>::failure(
                            atoms_value.error());
                      }
                      return postclosure_law(
                          std::move(atoms_value).value(), descriptor,
                          program.conditional_row_tolerance,
                          program.representation_budget);
                    }
#endif
                    auto prepared = prepare_postarrival_closure(
                        *plug, callback_state, post_opportunity, post_action,
                        callback_arrival);
                    if (!prepared) {
                      return Result<PostClosureLaw>::failure(
                          prepared.error());
                    }
                    return apply_postclosure_enumeration(
                        prepared.value(), descriptor,
                        program.conditional_row_tolerance,
                        program.representation_budget);
                  }();
        if (!post_law_value) {
          return Result<MarkedKernelRow>::failure(post_law_value.error());
        }
        PostClosureLaw post_prepared = std::move(post_law_value).value();
        const NormalizedPmf* post_pmf = pmf(post_prepared);
        if (post_pmf == nullptr) {
          return c17_invalid<MarkedKernelRow>(
              "c17.row_requires_exact_enumeration",
              "C-plus supplied only a sampler to the exact row compiler");
        }
        diagnostics.push_back(stage_diagnostic(
            CausalStageV1::c_plus, arrival.branch, atoms(post_prepared),
            *post_pmf));

        const auto post_support = atoms(post_prepared);
        for (std::size_t post_index = 0U;
             post_index < post_support.size(); ++post_index) {
          PostClosure post = post_support[post_index].outcome;
          branch_ok = require_upstream_branch(
              post.branch, arrival.branch, CausalStageV1::c_plus);
          if (!branch_ok) {
            return Result<MarkedKernelRow>::failure(branch_ok.error());
          }
          post.branch = child_branch(arrival.branch, post_index);
          stage_marks = validate_stage_marks(
              descriptor, CausalStageV1::c_plus, post.marks);
          if (!stage_marks) {
            return Result<MarkedKernelRow>::failure(stage_marks.error());
          }
          std::vector<CausalStageV1> psi_trace = post_trace;
          psi_trace.push_back(CausalStageV1::psi);
          auto trace_valid = validate_actual_stage_trace(psi_trace);
          if (!trace_valid) {
            return Result<MarkedKernelRow>::failure(trace_valid.error());
          }
          OpportunityMark edge_opportunity = post_opportunity;
          ResolvedAction edge_action = post_action;
          ArrivalTransition edge_arrival = arrival;
          edge_opportunity.branch = post.branch;
          edge_action.branch = post.branch;
          edge_arrival.branch = post.branch;
          const bool clock_quotient =
              program.event_clock_semantics ==
              EventClockSemanticsV1::
                  finite_phase_time_homogeneous_quotient;
          const ArrivalTransition raw_edge_arrival = edge_arrival;
          ArrivalTransition callback_edge_arrival = callback_arrival;
          callback_edge_arrival.branch = post.branch;
          auto edge = apply_exact_reduced_update(resolved_state_inputs(
              instance, clock_quotient ? callback_state : state,
              std::move(edge_opportunity), std::move(edge_action),
              clock_quotient ? callback_edge_arrival : edge_arrival,
              std::move(post), descriptor, state_schema,
              optimizer_context));
          if (!edge) {
            return Result<MarkedKernelRow>::failure(edge.error());
          }
          if (clock_quotient) {
            const UnresolvedPatch no_patch(
                std::vector<RuntimeFieldPatchV1>{});
            auto raw_successor = lift_clock_erased_row_successor(
                state_schema, state, raw_edge_arrival, edge.value(),
                no_patch);
            if (!raw_successor) {
              return Result<MarkedKernelRow>::failure(
                  raw_successor.error());
            }
            const CompletedReducedEdge callback_edge =
                std::move(edge).value();
            ArrivalTransition lifted_arrival = raw_edge_arrival;
            lifted_arrival.marks = callback_edge.arrival().marks;
            edge = Result<CompletedReducedEdge>::success(completed_edge(
                state, std::move(raw_successor).value(),
                callback_edge.opportunity(), callback_edge.action(),
                std::move(lifted_arrival), callback_edge.postclosure(),
                std::vector<CausalMarkV1>(callback_edge.marks().begin(),
                                          callback_edge.marks().end())));
          }
          auto complete_marks =
              validate_complete_edge_marks(descriptor, edge.value());
          if (!complete_marks) {
            return Result<MarkedKernelRow>::failure(
                complete_marks.error());
          }
          auto opportunity_action_mass = multiply_branch_mass(
              opportunity_pmf->normalized_weights()[opportunity_index],
              action_pmf->normalized_weights()[action_index],
              program.representation_budget);
          if (!opportunity_action_mass) {
            return Result<MarkedKernelRow>::failure(
                opportunity_action_mass.error());
          }
          auto through_arrival_mass = multiply_branch_mass(
              opportunity_action_mass.value(),
              arrival_pmf->normalized_weights()[arrival_index],
              program.representation_budget);
          if (!through_arrival_mass) {
            return Result<MarkedKernelRow>::failure(
                through_arrival_mass.error());
          }
          auto complete_mass = multiply_branch_mass(
              through_arrival_mass.value(),
              post_pmf->normalized_weights()[post_index],
              program.representation_budget);
          if (!complete_mass) {
            return Result<MarkedKernelRow>::failure(
                complete_mass.error());
          }
          ExactRational mass = std::move(complete_mass).value();
          const bool structural =
              opportunity_support[opportunity_index].structural_support &&
              action_support[action_index].structural_support &&
              arrival_support[arrival_index].structural_support &&
              post_support[post_index].structural_support;
          auto duplicate = std::ranges::find_if(
              aggregated, [&](const AggregatedBranch& candidate) {
                return same_completed_reduced_outcome(candidate.edge,
                                                      edge.value());
              });
          if (duplicate == aggregated.end()) {
            aggregated.push_back(AggregatedBranch{
                std::move(edge).value(), std::move(mass), structural});
          } else {
            auto merged_mass = add_branch_mass(
                duplicate->mass, mass, program.representation_budget,
                "duplicate-outcome mass addition");
            if (!merged_mass) {
              return Result<MarkedKernelRow>::failure(
                  merged_mass.error());
            }
            duplicate->mass = std::move(merged_mass).value();
            duplicate->structural_support =
                duplicate->structural_support || structural;
          }
        }
      }
    }
  }

  ExactRational total = ExactRational::zero();
  std::vector<ExactRational> masses;
  masses.reserve(aggregated.size());
  for (const AggregatedBranch& branch : aggregated) {
    auto next_total = add_branch_mass(
        total, branch.mass, program.representation_budget,
        "final-row total addition");
    if (!next_total) {
      return Result<MarkedKernelRow>::failure(next_total.error());
    }
    total = std::move(next_total).value();
    masses.push_back(branch.mass);
  }
  if (!(total == ExactRational::one())) {
    return c17_internal<MarkedKernelRow>(
        "c17.final_row_mass_not_one",
        "the exact product-and-merge row does not have total mass one",
        {"exact total " + total.to_canonical_string()});
  }
  auto categorical = build_final_categorical(masses,
                                              program.representation_budget);
  if (!categorical) {
    return Result<MarkedKernelRow>::failure(categorical.error());
  }
  FinalCategoricalBuild image = std::move(categorical).value();
  std::vector<MarkedKernelRowAtomV1> row_atoms;
  row_atoms.reserve(aggregated.size());
  for (std::size_t index = 0U; index < aggregated.size(); ++index) {
    row_atoms.push_back(MarkedKernelRowAtomV1{
        std::move(aggregated[index].edge), aggregated[index].mass,
        aggregated[index].structural_support, image.numerical[index],
        image.numerical_status[index],
        image.cumulative[index]});
  }
  MarkedKernelRow result = marked_row(
      std::move(row_atoms), std::move(total), std::move(diagnostics),
      std::move(image.categorical));
  ledger_transaction.commit();
  return Result<MarkedKernelRow>::success(std::move(result));
}

Result<MarkedKernelRow> C17CoreAccess::compose_candidate_row(
    const SurrogatePlug& plug, const PlugDescriptor& descriptor,
    CompiledFrameworkCandidateInputsV1& inputs,
    const ReducedStateV1& state) {
  return compose_program_row(
      &plug, descriptor, inputs.instance, inputs.configured_arrival,
      inputs.exact_state_schema, inputs.causal_program,
      inputs.optimizer_context, state);
}

Result<MarkedKernelRow> C17CoreAccess::compose_for_audit_probe(
    CompiledFrameworkCandidate& candidate,
    const PlugDescriptor& descriptor, const ReducedStateV1& state) {
  return compose_candidate_row(candidate.plug_, descriptor,
                               candidate.inputs_, state);
}

Result<CompletedReducedEdge> C17CoreAccess::execute_candidate_slot(
    surrogate::detail::SealedFrameworkCore& core,
    const ReducedStateV1& state, RngBank& rng_bank) {
  CompiledFrameworkCandidateInputsV1& inputs = core.inputs();
  OptimizerCallLedgerTransaction ledger_transaction(
      inputs.optimizer_context);
  ExactReducedStateSchemaV1& state_schema = inputs.exact_state_schema;
  ExactCausalProgramV1& program = inputs.causal_program;
  if (!state_schema.decode || !state_schema.rebuild ||
      !state_schema.validate_domain ||
      !(state.codec == state_schema.reduced_state_codec) ||
      !(rng_bank.combined_input() == inputs.instance.fingerprints().combined)) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.slot_execution_binding_mismatch",
        "slot execution requires one sealed state schema, instance, and RNG "
        "bank binding");
  }
  if (rng_bank.temporal_path_ &&
      (!rng_bank.initialized_ ||
       !rng_bank.temporal_framework_digest_.has_value() ||
       *rng_bank.temporal_framework_digest_ !=
           core.execution_seal_digest() ||
       !rng_bank.reduced_initial_law_digest_.has_value() ||
       !rng_bank.temporal_advance_address_.has_value())) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.temporal_rng_context_binding_mismatch",
        "a temporal-path slot requires its matching initialized framework "
        "root and one active cursor/residence/slot address");
  }
  std::vector<PreparedRuntimeMarkDecoderV1> framework_decoders;
  for (const DeterministicRuntimeMarkDecoderOperationV1& decoder :
       state_schema.framework_mark_decoders) {
    if (decoder.schema().source ==
            MarkDecoderSourceV1::predecision_state ||
        decoder.schema().source ==
            MarkDecoderSourceV1::decision_schedule ||
        decoder.schema().source ==
            MarkDecoderSourceV1::configured_arrival) {
      framework_decoders.push_back(PreparedRuntimeMarkDecoderV1{
          decoder.schema(), decoder.fresh_operation()});
    }
  }
  auto domain = state_schema.validate_domain(state);
  if (!domain) {
    return Result<CompletedReducedEdge>::failure(domain.error());
  }
  auto decoded = state_schema.decode(state);
  if (!decoded) {
    return Result<CompletedReducedEdge>::failure(decoded.error());
  }
  const ExactReducedCoordinatesV1& coordinates = decoded.value();
  auto unit_state = validate_closed_three_bin_unit_state(program, coordinates);
  if (!unit_state) {
    return Result<CompletedReducedEdge>::failure(unit_state.error());
  }
  auto target_binding = validate_target_backlog_binding(
      inputs.instance, core.descriptor(), coordinates.backlog);
  if (!target_binding) {
    return Result<CompletedReducedEdge>::failure(target_binding.error());
  }
  if (inputs.framework_seed.target_selection.ordered_targets !=
      core.descriptor().core.deployed_targets) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.slot_target_order_binding_mismatch",
        "the sealed target-selection order differs from the descriptor "
        "target backlog order");
  }
  const ArrivalBinding& arrival_binding =
      arrival_law_binding(inputs.configured_arrival);
  if (arrival_binding.family != inputs.instance.arrival().family() ||
      arrival_binding.timing != inputs.instance.timing() ||
      arrival_binding.queue_cardinality != inputs.instance.queues().size() ||
      arrival_binding.timing !=
          TimingConvention::early_service_late_admission) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.slot_configured_arrival_binding_mismatch",
        "the slot does not retain the configured common C09 arrival law");
  }
  auto state_identity = reduced_state_identity(state);
  if (!state_identity) {
    return Result<CompletedReducedEdge>::failure(state_identity.error());
  }
  const CausalBranchIdentityV1 root{state_identity.value(), {}};
  const auto stage_rng = [&](const StageTag stage,
                             const CausalBranchIdentityV1& branch,
                             const Digest256& coordinate_digest,
                             const std::string_view stage_name)
      -> Result<DeterministicRng> {
    const Digest256* root_digest = &core.execution_seal_digest();
    const Digest256* addressed_digest = &coordinate_digest;
    std::string address;
    if (rng_bank.temporal_path_) {
      const RngBank::TemporalAdvanceAddress& temporal =
          *rng_bank.temporal_advance_address_;
      root_digest = &rng_bank.instance_key_.digest();
      addressed_digest = &temporal.cursor_digest;
      address = "event/";
      address += temporal.residence_index.to_decimal_string();
      address += "/residence/";
      address += temporal.residence_index.to_decimal_string();
      address += "/slot/";
      address += temporal.slot_offset.to_decimal_string();
      address += "/stage/";
      address += stage_name;
      address += "/coordinate/";
      address += coordinate_digest.hex();
      for (const std::size_t atom : branch.atom_path) {
        address += "/atom/";
        address += std::to_string(atom);
      }
    } else {
      // Preserve the released C17 key preimage exactly for every non-temporal
      // caller.
      address.assign(stage_name);
      for (const std::size_t atom : branch.atom_path) {
        address.push_back('/');
        address += std::to_string(atom);
      }
    }
    auto key = make_internal_draw_instance_key(
        *root_digest, *addressed_digest, address);
    if (!key) {
      return Result<DeterministicRng>::failure(key.error());
    }
    return Result<DeterministicRng>::success(
        derive_rng_stream(rng_bank.seed(), stage, key.value()));
  };

  auto pre_rng_result = stage_rng(StageTag::prearrival_closure, root,
                                  root.state_identity,
                                  "cminus");
  if (!pre_rng_result) {
    return Result<CompletedReducedEdge>::failure(pre_rng_result.error());
  }
  DeterministicRng pre_rng = std::move(pre_rng_result).value();
  std::vector<CausalStageV1> actual_trace;
  actual_trace.push_back(CausalStageV1::c_minus);
  std::size_t opportunity_atom_index = 0U;
  Result<OpportunityMark> opportunity_result =
      closed_scalar_response_mode_v1(program.mode)
          ? [&]() -> Result<OpportunityMark> {
              auto parts = prepare_closed_scalar_prearrival_parts(
                  core.plug(), inputs.instance, program.mode, coordinates,
                  root);
              if (!parts) {
                return Result<OpportunityMark>::failure(parts.error());
              }
              PreparedOpportunityParts values = std::move(parts).value();
              auto law = opportunity_law(
                  std::move(values.atoms),
                  program.conditional_row_tolerance,
                  program.representation_budget);
              if (!law) {
                return Result<OpportunityMark>::failure(law.error());
              }
              const NormalizedPmf* normalized = pmf(law.value());
              if (normalized == nullptr) {
                return c17_internal<OpportunityMark>(
                    "c17.opportunity_enumerable_image_missing",
                    "a once-normalized C-minus row has no categorical "
                    "image");
              }
              opportunity_atom_index =
                  sample_categorical(*normalized, pre_rng);
              return Result<OpportunityMark>::success(
                  atoms(law.value())[opportunity_atom_index].outcome);
            }()
          : [&]() -> Result<OpportunityMark> {
              auto law = prepare_prearrival_closure(core.plug(), state);
              if (!law) {
                return Result<OpportunityMark>::failure(law.error());
              }
              return apply_opportunity_realization(
                  law.value(), coordinates.backlog, pre_rng,
                  program.conditional_row_tolerance,
                  program.representation_budget);
            }();
  if (!opportunity_result) {
    return Result<CompletedReducedEdge>::failure(opportunity_result.error());
  }
  OpportunityMark opportunity = std::move(opportunity_result).value();
  const CanonicalRuntimeValueV1 predecision_source{
      state.codec, state.canonical_value};
  auto framework_predecision_marks = apply_prepared_mark_decoders(
      framework_decoders, MarkDecoderSourceV1::predecision_state,
      predecision_source);
  if (!framework_predecision_marks) {
    return Result<CompletedReducedEdge>::failure(
        framework_predecision_marks.error());
  }
  opportunity.marks.insert(
      opportunity.marks.end(), framework_predecision_marks.value().begin(),
      framework_predecision_marks.value().end());
  auto branch_ok =
      closed_scalar_response_mode_v1(program.mode)
          ? require_upstream_branch(
                opportunity.branch, root, CausalStageV1::c_minus)
          : require_child_branch(
                opportunity.branch, root, CausalStageV1::c_minus);
  if (!branch_ok) {
    return Result<CompletedReducedEdge>::failure(branch_ok.error());
  }
  if (closed_scalar_response_mode_v1(program.mode)) {
    opportunity.branch = child_branch(root, opportunity_atom_index);
  }
  if (!opportunity.prearrival_backlog.has_value() ||
      !(*opportunity.prearrival_backlog == coordinates.backlog) ||
      (opportunity.exact_opportunity_evidence.has_value() &&
       !coordinates.backlog.matches_full_backlog_projection(
           opportunity.exact_opportunity_evidence->evaluation_backlog()))) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.opportunity_exact_backlog_mismatch",
        "the realized C-minus value changed the exact pre-arrival backlog");
  }
  auto stage_marks = validate_stage_marks(
      core.descriptor(), CausalStageV1::c_minus, opportunity.marks);
  if (!stage_marks) {
    return Result<CompletedReducedEdge>::failure(stage_marks.error());
  }

  actual_trace.push_back(CausalStageV1::resolver);
  auto action_rng_result = stage_rng(
      StageTag::tie_resolution, opportunity.branch,
      opportunity.branch.state_identity, "resolver");
  if (!action_rng_result) {
    return Result<CompletedReducedEdge>::failure(action_rng_result.error());
  }
  DeterministicRng action_rng = std::move(action_rng_result).value();
  std::size_t action_atom_index = 0U;
  Result<ResolvedAction> action_result =
      closed_scalar_response_mode_v1(program.mode)
          ? resolve_closed_scalar_action(inputs.instance, coordinates,
                                         opportunity, program.mode)
          : [&]() -> Result<ResolvedAction> {
              auto law = prepare_reduced_action_law(
                  inputs.instance, state, opportunity,
                  inputs.optimizer_context);
              if (!law) {
                return Result<ResolvedAction>::failure(law.error());
              }
              const NormalizedPmf* normalized = pmf(law.value());
              if (normalized == nullptr) {
                return c17_internal<ResolvedAction>(
                    "c17.action_enumerable_image_missing",
                    "a once-normalized resolver row has no categorical "
                    "image");
              }
              action_atom_index = sample_categorical(*normalized, action_rng);
              return Result<ResolvedAction>::success(
                  atoms(law.value())[action_atom_index].outcome);
            }();
  if (!action_result) {
    return Result<CompletedReducedEdge>::failure(action_result.error());
  }
  ResolvedAction action = std::move(action_result).value();
  branch_ok = require_upstream_branch(
      action.branch, opportunity.branch, CausalStageV1::resolver);
  if (!branch_ok) {
    return Result<CompletedReducedEdge>::failure(branch_ok.error());
  }
  action.branch = child_branch(opportunity.branch, action_atom_index);
  if (closed_scalar_response_mode_v1(program.mode)) {
    auto framework_marks = framework_three_bin_action_marks(
        inputs.instance, core.descriptor(), coordinates, action);
    if (!framework_marks) {
      return Result<CompletedReducedEdge>::failure(
          framework_marks.error());
    }
    action.marks.insert(action.marks.end(),
                        framework_marks.value().begin(),
                        framework_marks.value().end());
  }
  auto decoded_action_marks = apply_prepared_mark_decoders(
      framework_decoders, MarkDecoderSourceV1::decision_schedule,
      action.decision);
  if (!decoded_action_marks) {
    return Result<CompletedReducedEdge>::failure(
        decoded_action_marks.error());
  }
  action.marks.insert(action.marks.end(),
                      decoded_action_marks.value().begin(),
                      decoded_action_marks.value().end());
  auto action_math = validate_resolved_action_math(
      inputs.instance, coordinates.backlog, action);
  if (!action_math) {
    return Result<CompletedReducedEdge>::failure(action_math.error());
  }
  auto evidence = validate_action_evidence(
      inputs.instance, coordinates.backlog, opportunity, action,
      program.mode == ExactCausalProgramModeV1::generic_bound_operations);
  if (!evidence) {
    return Result<CompletedReducedEdge>::failure(evidence.error());
  }
  stage_marks = validate_stage_marks(
      core.descriptor(), CausalStageV1::resolver, action.marks);
  if (!stage_marks) {
    return Result<CompletedReducedEdge>::failure(stage_marks.error());
  }

  actual_trace.push_back(CausalStageV1::arrival);
  auto prepared_arrival = prepare_configured_arrival_law(
      inputs.configured_arrival, coordinates.arrival_phase);
  if (!prepared_arrival) {
    return Result<CompletedReducedEdge>::failure(prepared_arrival.error());
  }
  auto arrival_rng_result = stage_rng(
      StageTag::configured_arrival, action.branch,
      root.state_identity, "arrival");
  if (!arrival_rng_result) {
    return Result<CompletedReducedEdge>::failure(arrival_rng_result.error());
  }
  DeterministicRng arrival_rng = std::move(arrival_rng_result).value();
  auto arrival_result = apply_arrival_realization(
      prepared_arrival.value(), arrival_capability(action.branch), arrival_rng,
      program.conditional_row_tolerance, program.representation_budget);
  if (!arrival_result) {
    return Result<CompletedReducedEdge>::failure(arrival_result.error());
  }
  ArrivalTransition arrival = std::move(arrival_result).value();
  branch_ok = require_child_branch(
      arrival.branch, action.branch, CausalStageV1::arrival);
  if (!branch_ok) {
    return Result<CompletedReducedEdge>::failure(branch_ok.error());
  }
  auto decoded_arrival_marks = apply_prepared_mark_decoders(
      framework_decoders, MarkDecoderSourceV1::configured_arrival,
      arrival.canonical_source);
  if (!decoded_arrival_marks) {
    return Result<CompletedReducedEdge>::failure(
        decoded_arrival_marks.error());
  }
  arrival.marks.insert(arrival.marks.end(),
                       decoded_arrival_marks.value().begin(),
                       decoded_arrival_marks.value().end());
  stage_marks = validate_stage_marks(
      core.descriptor(), CausalStageV1::arrival, arrival.marks);
  if (!stage_marks) {
    return Result<CompletedReducedEdge>::failure(stage_marks.error());
  }
  OpportunityMark post_opportunity = opportunity;
  ResolvedAction post_action = action;
  post_opportunity.branch = arrival.branch;
  post_action.branch = arrival.branch;

  actual_trace.push_back(CausalStageV1::c_plus);
  auto post_rng_result = stage_rng(
      StageTag::postarrival_closure, arrival.branch,
      arrival.branch.state_identity, "cplus");
  if (!post_rng_result) {
    return Result<CompletedReducedEdge>::failure(post_rng_result.error());
  }
  DeterministicRng post_rng = std::move(post_rng_result).value();
  Result<PostClosure> post_result =
      closed_scalar_response_mode_v1(program.mode)
          ? Result<PostClosure>::success(PostClosure{
                arrival.branch,
                UnresolvedPatch(std::vector<RuntimeFieldPatchV1>{}), {}})
          : [&]() -> Result<PostClosure> {
              auto law = prepare_postarrival_closure(
                  core.plug(), state, post_opportunity, post_action, arrival);
              if (!law) {
                return Result<PostClosure>::failure(law.error());
              }
              return apply_postclosure_realization(
                  law.value(), core.descriptor(), post_rng,
                  program.conditional_row_tolerance,
                  program.representation_budget);
            }();
  if (!post_result) {
    return Result<CompletedReducedEdge>::failure(post_result.error());
  }
  PostClosure post = std::move(post_result).value();
  branch_ok =
      closed_scalar_response_mode_v1(program.mode)
          ? require_upstream_branch(
                post.branch, arrival.branch, CausalStageV1::c_plus)
          : require_child_branch(
                post.branch, arrival.branch, CausalStageV1::c_plus);
  if (!branch_ok) {
    return Result<CompletedReducedEdge>::failure(branch_ok.error());
  }
  if (closed_scalar_response_mode_v1(program.mode)) {
    post.branch = child_branch(arrival.branch, 0U);
  }
  stage_marks = validate_stage_marks(
      core.descriptor(), CausalStageV1::c_plus, post.marks);
  if (!stage_marks) {
    return Result<CompletedReducedEdge>::failure(stage_marks.error());
  }
  actual_trace.push_back(CausalStageV1::psi);
  auto trace_valid = validate_actual_stage_trace(actual_trace);
  if (!trace_valid) {
    return Result<CompletedReducedEdge>::failure(trace_valid.error());
  }
  post_opportunity.branch = post.branch;
  post_action.branch = post.branch;
  arrival.branch = post.branch;
  auto completed = apply_exact_reduced_update(resolved_state_inputs(
      inputs.instance, state, std::move(post_opportunity),
      std::move(post_action), std::move(arrival), std::move(post),
      core.descriptor(), state_schema, inputs.optimizer_context));
  if (!completed) {
    return Result<CompletedReducedEdge>::failure(completed.error());
  }
  auto complete_marks =
      validate_complete_edge_marks(core.descriptor(), completed.value());
  if (!complete_marks) {
    return Result<CompletedReducedEdge>::failure(complete_marks.error());
  }
  ledger_transaction.commit();
  return completed;
}

Result<ExactRational> C17CoreAccess::three_bin_service_probability(
    const surrogate::detail::SealedFrameworkCore& core,
    const BigNat& backlog) {
  if (!core.report().passed() || !core.is_three_bin()) {
    return c17_invalid<ExactRational>(
        "c17.audited_three_bin_view_unavailable",
        "service probability requires a passing closed three-bin seal");
  }
  const auto* response = three_bin_payload(core.plug());
  if (response == nullptr) {
    return c17_invalid<ExactRational>(
        "c17.three_bin_payload_required",
        "the sealed framework has no final three-bin response payload");
  }
  auto target = three_bin_target_ordinal(*response, core.inputs().instance);
  if (!target) {
    return Result<ExactRational>::failure(target.error());
  }
  const bool full_orbit_law_binding =
      core.descriptor().core.provider.provider_id ==
          "full_orbit_framework_sampler" &&
      core.inputs()
          .accepted_contract.arrival_capabilities()
          .exact_factorized_iid_generator.has_value();
  const Digest256& expected_arrival_binding =
      full_orbit_law_binding
          ? arrival_law_binding(core.inputs().configured_arrival)
                .law_digest.value()
          : core.inputs()
                .framework_seed.bindings.problem_fingerprints
                .compiled_arrival;
  if (!(response->normalized_record.configured_arrival_binding ==
        expected_arrival_binding)) {
    return c17_invalid<ExactRational>(
        "c17.three_bin_arrival_binding_mismatch",
        "the final response is not bound to the seal's configured arrival");
  }
  return three_bin_probability(*response, backlog);
}

Result<ExactRational>
C17CoreAccess::finite_prefix_constant_tail_service_probability(
    const surrogate::detail::SealedFrameworkCore& core,
    const BigNat& backlog) {
  if (!core.report().passed() ||
      !core.is_finite_prefix_constant_tail()) {
    return c17_invalid<ExactRational>(
        "c17.audited_finite_prefix_constant_tail_view_unavailable",
        "service probability requires a passing closed "
        "finite-prefix/constant-tail seal");
  }
  const auto* response = finite_prefix_constant_tail_payload(core.plug());
  if (response == nullptr) {
    return c17_invalid<ExactRational>(
        "c17.finite_prefix_constant_tail_payload_required",
        "the sealed framework has no final finite-prefix/constant-tail "
        "response payload");
  }
  auto target = finite_prefix_constant_tail_target_ordinal(
      *response, core.inputs().instance);
  if (!target) {
    return Result<ExactRational>::failure(target.error());
  }
  const bool full_orbit_law_binding =
      core.descriptor().core.provider.provider_id ==
          "full_orbit_framework_sampler" &&
      core.inputs()
          .accepted_contract.arrival_capabilities()
          .exact_factorized_iid_generator.has_value();
  const Digest256& expected_arrival_binding =
      full_orbit_law_binding
          ? arrival_law_binding(core.inputs().configured_arrival)
                .law_digest.value()
          : core.inputs()
                .framework_seed.bindings.problem_fingerprints
                .compiled_arrival;
  if (!(response->normalized_record.configured_arrival_binding ==
        expected_arrival_binding)) {
    return c17_invalid<ExactRational>(
        "c17.finite_prefix_constant_tail_arrival_binding_mismatch",
        "the final finite-prefix/constant-tail response is not bound to the "
        "seal's configured arrival");
  }
  return finite_prefix_constant_tail_probability(*response, backlog);
}

#if defined(MWPERF_C17_TEST_SEAMS)
Result<MarkedKernelRow> C17CoreAccess::compose_generic_for_testing(
    C17GenericComposerFixtureV1& fixture,
    const PlugDescriptor& descriptor, const ReducedStateV1& state) {
  if (fixture.causal_program.mode !=
      ExactCausalProgramModeV1::generic_bound_operations) {
    return c17_invalid<MarkedKernelRow>(
        "c17.test_fixture_generic_mode_required",
        "the direct equation fixture accepts only the generic exact program");
  }
  return compose_program_row(
      nullptr, descriptor, fixture.instance, fixture.configured_arrival,
      fixture.exact_state_schema, fixture.causal_program,
      fixture.optimizer_context, state, &fixture.callbacks);
}
#endif

}  // namespace detail

Result<MarkedKernelRow> compile_reduced_kernel_row(
    const AuditedRowProvider& provider, const ReducedStateV1& state) {
  auto core = detail::C17CoreAccess::core(provider);
  if (!core || !core->report().passed() || !core->row_available()) {
    return c17_invalid<MarkedKernelRow>(
        "c17.audited_row_provider_unavailable",
        "the supplied audited view does not authorize exact row composition");
  }
  return detail::C17CoreAccess::compose_candidate_row(
      core->plug(), core->descriptor(), core->inputs(), state);
}

namespace kernel::detail {

namespace {

template <typename T>
[[nodiscard]] Result<T> temporal_bridge_fail(std::string code,
                                             std::string message,
                                             DiagnosticCategory category =
                                                 DiagnosticCategory::input_validation) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  });
}

[[nodiscard]] SolverRegimeV1 bridge_solver_regime(
    const MetricSolverRegimeV1 value) {
  switch (value) {
    case MetricSolverRegimeV1::enumerated:
      return SolverRegimeV1::enumerated;
    case MetricSolverRegimeV1::analytic:
      return SolverRegimeV1::analytic;
    case MetricSolverRegimeV1::monte_carlo:
      return SolverRegimeV1::monte_carlo;
    case MetricSolverRegimeV1::direct:
      return SolverRegimeV1::direct;
  }
  return SolverRegimeV1::direct;
}

[[nodiscard]] TargetCouplingV1 bridge_target_coupling(
    const MetricTargetCouplingV1 value) {
  return value == MetricTargetCouplingV1::scalar_singleton
             ? TargetCouplingV1::scalar_target
             : TargetCouplingV1::common_schedule_projection;
}

[[nodiscard]] Result<Digest256> temporal_continuation_schema_identity(
    const surrogate::detail::SealedFrameworkCore& core) {
  const CompiledFrameworkCandidateInputsV1& inputs = core.inputs();
  const ExactCausalProgramV1& program = inputs.causal_program;
  const FrameworkProblemFingerprintsV1& problem =
      inputs.framework_seed.bindings.problem_fingerprints;

  C17RuntimeValueEncoder encoder;
  encoder.u32(1U);
  encoder.digest(core.execution_seal_digest());
  encoder.digest(core.descriptor().descriptor_digest);
  encoder.codec(inputs.exact_state_schema.reduced_state_codec);
  encoder.digest(inputs.exact_state_schema.exact_state_schema_digest);
  encoder.digest(inputs.exact_state_schema.reduced_state_schema_digest);
  encoder.digest(inputs.exact_state_schema.ownership_schema_digest);
  encoder.digest(inputs.exact_state_schema.exact_update_schema_digest);
  encoder.enumeration(program.mode);
  encoder.boolean(program.representation_budget.maximum_integral_bits
                      .has_value());
  if (program.representation_budget.maximum_integral_bits.has_value()) {
    encoder.count(
        *program.representation_budget.maximum_integral_bits);
  }
  encoder.boolean(program.maximum_residence_slots.has_value());
  if (program.maximum_residence_slots.has_value()) {
    encoder.count(*program.maximum_residence_slots);
  }
  encoder.boolean(program.finite_event_domain_states.has_value());
  if (program.finite_event_domain_states.has_value()) {
    encoder.count(program.finite_event_domain_states->size());
    for (const ReducedStateV1& state :
         *program.finite_event_domain_states) {
      encoder.runtime_value(state);
    }
  }
  encoder.boolean(program.event_entry_domain_is_exact_state_domain);
  encoder.enumeration(program.event_clock_semantics);
  encoder.digest(problem.compiled_arrival);
  encoder.digest(problem.tie_and_timing);
  const std::vector<std::byte> bytes = std::move(encoder).finish();
  return sha256_domain_separated(
      "mwperf.c17.temporal-continuation-schema.v1", bytes);
}

// This encoding is intentionally byte-for-byte identical to C20's
// c20_target_service_schema_identity.  The common domain makes a C17 direct
// temporal source and a C20/C21 suspension source comparable only when their
// selected target-service schemas truly agree.
[[nodiscard]] Result<Digest256> temporal_target_service_schema_identity(
    const surrogate::detail::SealedFrameworkCore& core) {
  const CompiledFrameworkCandidateInputsV1& inputs = core.inputs();
  const AuditedFrameworkBindingsV1& bindings =
      inputs.framework_seed.bindings;
  const DerivedServiceIdentity& service = inputs.instance.service_identity();

  C17RuntimeValueEncoder encoder;
  encoder.u32(1U);
  encoder.digest(bindings.problem_fingerprints.constraint);
  encoder.digest(bindings.problem_fingerprints.target_selection);
  encoder.digest(bindings.ordered_target_digest);
  encoder.enumeration(service.scheduler);
  encoder.enumeration(service.family);
  encoder.enumeration(service.optimizer);
  encoder.enumeration(core.descriptor().core.target_coupling);
  encoder.count(core.descriptor().core.deployed_targets.size());
  for (const QueueId& target : core.descriptor().core.deployed_targets) {
    encoder.id(target);
  }
  const std::vector<std::byte> bytes = std::move(encoder).finish();
  return sha256_domain_separated(
      "mwperf.c20.target-service-schema.v1", bytes);
}

[[nodiscard]] bool same_seal_owner(
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        left,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        right) noexcept {
  return left && right && left.get() == right.get() &&
         !left.owner_before(right) && !right.owner_before(left);
}

[[nodiscard]] bool nonzero_temporal_digest(
    const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

}  // namespace

class C17TemporalBridgeAccess final {
 public:
  C17TemporalBridgeAccess() = delete;

  [[nodiscard]] static auto core(
      const AuditedCompiledFramework& framework) noexcept {
    return ::mwperf::detail::C17CoreAccess::core(framework);
  }

  [[nodiscard]] static Result<MarkedKernelRow> compose_row(
      surrogate::detail::SealedFrameworkCore& core,
      const ReducedStateV1& state) {
    return ::mwperf::detail::C17CoreAccess::compose_candidate_row(
        core.plug(), core.descriptor(), core.inputs(), state);
  }

  template <typename View>
  [[nodiscard]] static auto view_core(const View& view) noexcept {
    return ::mwperf::detail::C17CoreAccess::core(view);
  }

  template <typename View>
  [[nodiscard]] static const std::shared_ptr<const
      metrics::detail::TemporalSourceCore>& temporal_source(
      const View& view) noexcept {
    return view.temporal_source_;
  }

  [[nodiscard]] static const std::shared_ptr<const
      surrogate::detail::AuditedConsumerSealIdentity>& initial_seal(
      const ReducedInitialLaw& law) noexcept {
    return law.seal_;
  }

  [[nodiscard]] static AuditedCylinderLaw transient_cylinder(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
      const Digest256& source_fingerprint) {
    return AuditedCylinderLaw(
        std::move(core), AuditedTemporalSourceKindV1::transient_dispatch,
        std::move(source), source_fingerprint, source_fingerprint);
  }

  [[nodiscard]] static AuditedTemporalKernel transient_kernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
      const Digest256& source_fingerprint) {
    return AuditedTemporalKernel(
        std::move(core), AuditedTemporalSourceKindV1::transient_dispatch,
        std::move(source), source_fingerprint, source_fingerprint);
  }

  [[nodiscard]] static AuditedCylinderLaw framework_cylinder(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
    const Digest256 fingerprint = source->binding.source_fingerprint;
    return AuditedCylinderLaw(
        std::move(core), AuditedTemporalSourceKindV1::framework_v0,
        std::move(source), fingerprint, fingerprint);
  }

  [[nodiscard]] static AuditedTemporalKernel framework_kernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
    const Digest256 fingerprint = source->binding.source_fingerprint;
    return AuditedTemporalKernel(
        std::move(core), AuditedTemporalSourceKindV1::framework_v0,
        std::move(source), fingerprint, fingerprint);
  }

  [[nodiscard]] static AuditedTemporalLaw framework_law(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
    const Digest256 fingerprint = source->binding.source_fingerprint;
    return AuditedTemporalLaw(
        std::move(core), AuditedTemporalSourceKindV1::framework_v0,
        std::move(source), fingerprint, fingerprint);
  }
};

Result<C17TemporalBindingV1> c17_temporal_binding(
    const AuditedCompiledFramework& framework) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed()) {
    return temporal_bridge_fail<C17TemporalBindingV1>(
        "c22.framework_v0_source_unavailable",
        "C22 requires one live passing C17 V0 audit",
        DiagnosticCategory::unavailable);
  }
  const auto& inputs = core->inputs();
  const auto& bindings = inputs.framework_seed.bindings;
  const auto& problem = bindings.problem_fingerprints;
  auto continuation = temporal_continuation_schema_identity(*core);
  if (!continuation) {
    return Result<C17TemporalBindingV1>::failure(continuation.error());
  }
  auto target_service = temporal_target_service_schema_identity(*core);
  if (!target_service) {
    return Result<C17TemporalBindingV1>::failure(target_service.error());
  }
  return Result<C17TemporalBindingV1>::success(C17TemporalBindingV1{
      core->consumer_seal_identity(),
      core->execution_seal_digest(),
      core->validated_contract_digest(),
      bindings.normalized_metric_requirements_digest,
      problem.authored_inputs.analysis,
      problem.resolved_instance,
      problem.target_selection,
      problem.compiled_arrival,
      bindings.selection_digest,
      inputs.exact_state_schema.exact_state_schema_digest,
      inputs.exact_state_schema.reduced_state_schema_digest,
      core->descriptor().descriptor_digest,
      std::move(continuation).value(),
      std::move(target_service).value(),
      problem.tie_and_timing,
      inputs.exact_state_schema.reduced_state_codec,
      core->row_available()});
}

namespace {

template <typename View>
[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> temporal_source_impl(
    const View& view) {
  const auto& source = C17TemporalBridgeAccess::temporal_source(view);
  if (!source) {
    return temporal_bridge_fail<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>(
        "c22.temporal_view_source_missing",
        "the audited temporal restriction has no immutable value source",
        DiagnosticCategory::unavailable);
  }
  return Result<std::shared_ptr<const
      metrics::detail::TemporalSourceCore>>::success(source);
}

template <typename View>
[[nodiscard]] bool temporal_view_has_framework_core_impl(
    const View& view) noexcept {
  return static_cast<bool>(C17TemporalBridgeAccess::view_core(view));
}

template <typename View>
[[nodiscard]] Result<void> require_temporal_view_seal_impl(
    const View& view,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal) {
  const auto core = C17TemporalBridgeAccess::view_core(view);
  if (!core || !core->report().passed() ||
      !same_seal_owner(core->consumer_seal_identity(), expected_seal)) {
    return temporal_bridge_fail<void>(
        "c22.temporal_view_v0_seal_mismatch",
        "the audited temporal restriction does not retain the exact live V0 "
        "consumer seal named by its source binding",
        DiagnosticCategory::unavailable);
  }
  return Result<void>::success();
}

enum class FrameworkTemporalViewRoleV1 : std::uint8_t {
  cylinder,
  kernel,
  law,
};

[[nodiscard]] bool stationary_selection_for_f05(
    const MetricSelectionRegimeV1 selection) noexcept {
  switch (selection) {
    case MetricSelectionRegimeV1::stationary_unique:
    case MetricSelectionRegimeV1::stationary_class:
    case MetricSelectionRegimeV1::stationary_mixture:
      return true;
    case MetricSelectionRegimeV1::transient:
    case MetricSelectionRegimeV1::fixed_point_unique:
    case MetricSelectionRegimeV1::fixed_point_id:
      return false;
  }
  return false;
}

[[nodiscard]] bool accepted_framework_f05_authorization(
    const surrogate::detail::SealedFrameworkCore& framework,
    const metrics::detail::F05AuthorizationV1& authorization) {
  const auto supported_kind = [](const MetricKindV1 kind) {
    switch (kind) {
      case MetricKindV1::service_persistence:
      case MetricKindV1::service_autocovariance:
      case MetricKindV1::service_spectrum:
      case MetricKindV1::service_window_count:
      case MetricKindV1::mean_event_gap:
      case MetricKindV1::mean_binary_run:
        return true;
      default:
        return false;
    }
  };
  if (!supported_kind(authorization.request_kind)) {
    return false;
  }
  const auto& accepted = framework.inputs().accepted_contract;
  const auto& descriptor = framework.descriptor().core;
  for (const ResolvedMetricContractV1& contract :
       accepted.metric_contracts()) {
    if (contract.semantic != descriptor.semantic ||
        contract.runtime_access != descriptor.runtime_access ||
        contract.target_coupling != descriptor.target_coupling) {
      continue;
    }
    const auto clause = std::find_if(
        accepted.requirements().clauses().begin(),
        accepted.requirements().clauses().end(),
        [&](const MetricRequirementClause& candidate) {
          return candidate.origin.clause_id == contract.clause_id &&
                 candidate.origin.clause_id.authored_index ==
                     contract.authored_metric_index &&
                 candidate.origin.ordered_targets ==
                     contract.ordered_targets;
        });
    if (clause == accepted.requirements().clauses().end() ||
        clause->origin.kind != authorization.request_kind ||
        clause->origin.parameters != authorization.parameters ||
        clause->origin.wire_coupling !=
            MetricTargetCouplingV1::scalar_singleton ||
        clause->origin.ordered_targets.size() != 1U ||
        !stationary_selection_for_f05(
            clause->origin.selection_regime)) {
      continue;
    }
    const QueueId& target =
        clause->origin.ordered_targets.front().queue_id;
    if (authorization.target_ordinal >= descriptor.deployed_targets.size() ||
        !(descriptor.deployed_targets[authorization.target_ordinal] ==
          target) ||
        std::count(descriptor.deployed_targets.begin(),
                   descriptor.deployed_targets.end(), target) != 1) {
      continue;
    }
    std::vector<const MetricRouteAlternativeV1*> routes;
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route == contract.backend_route &&
          route.semantic.coupling == contract.target_coupling) {
        routes.push_back(&route);
      }
    }
    if (routes.empty()) {
      continue;
    }
    const bool exact_temporal_route = std::all_of(
        routes.begin(), routes.end(),
        [&](const MetricRouteAlternativeV1* route) {
          switch (contract.backend_route) {
            case BackendRouteKindV1::finite_temporal_cylinder:
              return std::holds_alternative<FiniteCylinderRequirementV1>(
                  route->semantic.law);
            case BackendRouteKindV1::residence_or_stopped_law:
              return std::holds_alternative<ResidenceWordRequirementV1>(
                  route->semantic.law);
            case BackendRouteKindV1::analytic_metric_family:
              if (authorization.request_kind ==
                  MetricKindV1::service_window_count) {
                return std::holds_alternative<
                    PushforwardCountLawRequirementV1>(
                    route->semantic.law);
              }
              if (authorization.request_kind == MetricKindV1::mean_event_gap ||
                  authorization.request_kind == MetricKindV1::mean_binary_run) {
                return std::holds_alternative<
                    FrameworkDerivedScalarRequirementV1>(
                    route->semantic.law);
              }
              return false;
            default:
              return false;
          }
        });
    if (exact_temporal_route) {
      return true;
    }
  }
  return false;
}

[[nodiscard]] Result<void> require_framework_v0_source(
    const AuditedCompiledFramework& framework,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>& source,
    const FrameworkTemporalViewRoleV1 role) {
  auto expected = c17_temporal_binding(framework);
  if (!expected) {
    return Result<void>::failure(expected.error());
  }
  if (!source || source->nodes.empty() || !source->exact_rows ||
      !source->projectively_consistent ||
      source->binding.kind != AuditedTemporalSourceKindV1::framework_v0 ||
      source->binding.projection_fingerprint.has_value() ||
      !nonzero_temporal_digest(source->binding.source_fingerprint) ||
      !same_seal_owner(source->binding.seal_token,
                       expected.value().seal_token) ||
      source->binding.accepted_contract_identity !=
          expected.value().accepted_contract_identity ||
      source->binding.normalized_requirements_identity !=
          expected.value().normalized_requirements_identity ||
      source->binding.authored_analysis_identity !=
          expected.value().authored_analysis_identity ||
      source->binding.resolved_instance_identity !=
          expected.value().resolved_instance_identity ||
      source->binding.target_selection_identity !=
          expected.value().target_selection_identity ||
      source->binding.configured_arrival_identity !=
          expected.value().configured_arrival_identity ||
      source->binding.selection_identity !=
          expected.value().selection_identity ||
      source->binding.exact_state_schema_identity !=
          expected.value().exact_state_schema_identity ||
      source->binding.reduced_state_schema_identity !=
          expected.value().reduced_state_schema_identity ||
      source->binding.mark_schema_identity !=
          expected.value().mark_schema_identity ||
      source->binding.continuation_schema_identity !=
          expected.value().continuation_schema_identity ||
      source->binding.target_service_schema_identity !=
          expected.value().target_service_schema_identity ||
      source->binding.timing_identity != expected.value().timing_identity ||
      !(source->binding.state_codec == expected.value().state_codec)) {
    return temporal_bridge_fail<void>(
        "c22.framework_v0_mint_binding_mismatch",
        "a framework_v0 temporal restriction must retain the exact live "
        "C17 seal, contract, instance, arrival, selection, schema, target, "
        "and timing identities without claiming a C21 projection",
        DiagnosticCategory::unavailable);
  }
  if ((role == FrameworkTemporalViewRoleV1::kernel ||
       role == FrameworkTemporalViewRoleV1::law) &&
      !source->complete_rows) {
    return temporal_bridge_fail<void>(
        "c22.framework_v0_continuation_incomplete",
        "a framework_v0 temporal kernel or law requires a complete exact "
        "one-slot continuation domain",
        DiagnosticCategory::unavailable);
  }
  if ((role == FrameworkTemporalViewRoleV1::cylinder ||
       role == FrameworkTemporalViewRoleV1::law) &&
      source->stationary_entrance.empty()) {
    return temporal_bridge_fail<void>(
        "c22.framework_v0_entrance_missing",
        "a framework_v0 cylinder or temporal law requires its sealed "
        "normalized predictive entrance",
        DiagnosticCategory::unavailable);
  }
  const auto framework_core = C17TemporalBridgeAccess::core(framework);
  if (!framework_core) {
    return temporal_bridge_fail<void>(
        "c22.framework_v0_authorization_source_missing",
        "a framework_v0 temporal restriction has no live C17 source for "
        "authorization validation",
        DiagnosticCategory::unavailable);
  }
  for (std::size_t index = 0U;
       index < source->f05_authorizations.size(); ++index) {
    const auto& authorization = source->f05_authorizations[index];
    if (std::find(source->f05_authorizations.begin(),
                  source->f05_authorizations.begin() +
                      static_cast<std::ptrdiff_t>(index),
                  authorization) !=
            source->f05_authorizations.begin() +
                static_cast<std::ptrdiff_t>(index) ||
        !accepted_framework_f05_authorization(*framework_core,
                                              authorization)) {
      return temporal_bridge_fail<void>(
          "c22.framework_v0_f05_authorization_mismatch",
          "a framework_v0 temporal restriction claims a duplicate or "
          "nonaccepted F-C22-05 request authorization",
          DiagnosticCategory::unavailable);
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> require_transient_dispatch_source(
    const AuditedCompiledFramework& framework,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>& source,
    const Digest256& source_fingerprint) {
  auto expected = c17_temporal_binding(framework);
  if (!expected) {
    return Result<void>::failure(expected.error());
  }
  if (!source || source->nodes.empty() || source->stationary_entrance.empty() ||
      !source->exact_rows || !source->projectively_consistent ||
      source->binding.kind !=
          AuditedTemporalSourceKindV1::transient_dispatch ||
      source->binding.projection_fingerprint.has_value() ||
      !nonzero_temporal_digest(source_fingerprint) ||
      source->binding.source_fingerprint != source_fingerprint ||
      !expected.value().exact_row_available ||
      !same_seal_owner(source->binding.seal_token,
                       expected.value().seal_token) ||
      source->binding.accepted_contract_identity !=
          expected.value().accepted_contract_identity ||
      source->binding.normalized_requirements_identity !=
          expected.value().normalized_requirements_identity ||
      source->binding.authored_analysis_identity !=
          expected.value().authored_analysis_identity ||
      source->binding.resolved_instance_identity !=
          expected.value().resolved_instance_identity ||
      source->binding.target_selection_identity !=
          expected.value().target_selection_identity ||
      source->binding.configured_arrival_identity !=
          expected.value().configured_arrival_identity ||
      source->binding.selection_identity !=
          expected.value().selection_identity ||
      source->binding.exact_state_schema_identity !=
          expected.value().exact_state_schema_identity ||
      source->binding.reduced_state_schema_identity !=
          expected.value().reduced_state_schema_identity ||
      source->binding.mark_schema_identity !=
          expected.value().mark_schema_identity ||
      source->binding.continuation_schema_identity !=
          expected.value().continuation_schema_identity ||
      source->binding.target_service_schema_identity !=
          expected.value().target_service_schema_identity ||
      source->binding.timing_identity != expected.value().timing_identity ||
      !(source->binding.state_codec == expected.value().state_codec)) {
    return temporal_bridge_fail<void>(
        "c22.transient_mint_binding_mismatch",
        "a transient temporal restriction must retain the exact live C17 "
        "seal and all contract, request, instance, arrival, selection, "
        "schema, target, and timing identities",
        DiagnosticCategory::unavailable);
  }
  return Result<void>::success();
}

}  // namespace

Result<std::shared_ptr<const metrics::detail::TemporalSourceCore>>
c17_temporal_source(const AuditedCylinderLaw& law) {
  return temporal_source_impl(law);
}

Result<std::shared_ptr<const metrics::detail::TemporalSourceCore>>
c17_temporal_source(const AuditedTemporalKernel& kernel) {
  return temporal_source_impl(kernel);
}

Result<std::shared_ptr<const metrics::detail::TemporalSourceCore>>
c17_temporal_source(const AuditedTemporalLaw& law) {
  return temporal_source_impl(law);
}

bool c17_temporal_view_has_framework_core(
    const AuditedCylinderLaw& law) noexcept {
  return temporal_view_has_framework_core_impl(law);
}

bool c17_temporal_view_has_framework_core(
    const AuditedTemporalKernel& kernel) noexcept {
  return temporal_view_has_framework_core_impl(kernel);
}

bool c17_temporal_view_has_framework_core(
    const AuditedTemporalLaw& law) noexcept {
  return temporal_view_has_framework_core_impl(law);
}

Result<void> c17_require_temporal_view_seal(
    const AuditedCylinderLaw& law,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal) {
  return require_temporal_view_seal_impl(law, expected_seal);
}

Result<void> c17_require_transient_initial_seal(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed() ||
      !same_seal_owner(core->consumer_seal_identity(),
                       C17TemporalBridgeAccess::initial_seal(initial_law))) {
    return temporal_bridge_fail<void>(
        "c22.transient_initial_law_v0_seal_mismatch",
        "the transient predictive entrance was not minted by the exact live "
        "V0 framework supplied to C22",
        DiagnosticCategory::unavailable);
  }
  return Result<void>::success();
}

Result<AuditedCylinderLaw> c17_mint_transient_cylinder_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
    const Digest256& source_fingerprint) {
  auto valid = require_transient_dispatch_source(
      framework, source, source_fingerprint);
  if (!valid) {
    return Result<AuditedCylinderLaw>::failure(valid.error());
  }
  return Result<AuditedCylinderLaw>::success(
      C17TemporalBridgeAccess::transient_cylinder(
          C17TemporalBridgeAccess::core(framework), std::move(source),
          source_fingerprint));
}

Result<AuditedTemporalKernel> c17_mint_transient_temporal_kernel(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
    const Digest256& source_fingerprint) {
  auto valid = require_transient_dispatch_source(
      framework, source, source_fingerprint);
  if (!valid) {
    return Result<AuditedTemporalKernel>::failure(valid.error());
  }
  return Result<AuditedTemporalKernel>::success(
      C17TemporalBridgeAccess::transient_kernel(
          C17TemporalBridgeAccess::core(framework), std::move(source),
          source_fingerprint));
}

Result<AuditedCylinderLaw> c17_mint_framework_v0_cylinder_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
  auto valid = require_framework_v0_source(
      framework, source, FrameworkTemporalViewRoleV1::cylinder);
  if (!valid) {
    return Result<AuditedCylinderLaw>::failure(valid.error());
  }
  return Result<AuditedCylinderLaw>::success(
      C17TemporalBridgeAccess::framework_cylinder(
          C17TemporalBridgeAccess::core(framework), std::move(source)));
}

Result<AuditedTemporalKernel> c17_mint_framework_v0_temporal_kernel(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
  auto valid = require_framework_v0_source(
      framework, source, FrameworkTemporalViewRoleV1::kernel);
  if (!valid) {
    return Result<AuditedTemporalKernel>::failure(valid.error());
  }
  return Result<AuditedTemporalKernel>::success(
      C17TemporalBridgeAccess::framework_kernel(
          C17TemporalBridgeAccess::core(framework), std::move(source)));
}

Result<AuditedTemporalLaw> c17_mint_framework_v0_temporal_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source) {
  auto valid = require_framework_v0_source(
      framework, source, FrameworkTemporalViewRoleV1::law);
  if (!valid) {
    return Result<AuditedTemporalLaw>::failure(valid.error());
  }
  return Result<AuditedTemporalLaw>::success(
      C17TemporalBridgeAccess::framework_law(
          C17TemporalBridgeAccess::core(framework), std::move(source)));
}

Result<void> c17_require_temporal_view_seal(
    const AuditedTemporalKernel& kernel,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal) {
  return require_temporal_view_seal_impl(kernel, expected_seal);
}

Result<void> c17_require_temporal_view_seal(
    const AuditedTemporalLaw& law,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal) {
  return require_temporal_view_seal_impl(law, expected_seal);
}

Result<void> c17_require_temporal_request_match(
    const AuditedCompiledFramework& framework, const MetricRequest& request) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed()) {
    return temporal_bridge_fail<void>(
        "c22.framework_v0_source_unavailable",
        "transient dispatch requires one live passing C17 V0 audit",
        DiagnosticCategory::unavailable);
  }
  const MetricRequestHeader& header = metric_request_header(request);
  if (header.kind != metric_request_kind(request) || !header.context ||
      header.solver_regime == MetricSolverRegimeV1::monte_carlo) {
    return temporal_bridge_fail<void>(
        "c22.transient_request_not_deterministic",
        "C22 accepts only a well-formed deterministic analysis-v1 request",
        DiagnosticCategory::unavailable);
  }
  const auto parameters = metric_request_parameters(request);
  const auto& accepted = core->inputs().accepted_contract;
  const auto contract = std::find_if(
      accepted.metric_contracts().begin(),
      accepted.metric_contracts().end(),
      [&](const ResolvedMetricContractV1& candidate) {
        return candidate.authored_metric_index == header.authored_index &&
               candidate.metric_id == header.metric_id &&
               candidate.ordered_targets == header.ordered_targets &&
               candidate.target_coupling ==
                   bridge_target_coupling(header.coupling) &&
               candidate.solver_regime ==
                   bridge_solver_regime(header.solver_regime) &&
               (candidate.backend_route ==
                    BackendRouteKindV1::finite_temporal_cylinder ||
                candidate.backend_route ==
                    BackendRouteKindV1::residence_or_stopped_law);
      });
  if (contract == accepted.metric_contracts().end()) {
    return temporal_bridge_fail<void>(
        "c22.transient_request_contract_mismatch",
        "the transient request has no matching accepted deterministic "
        "temporal contract",
        DiagnosticCategory::unavailable);
  }
  const auto clause = std::find_if(
      accepted.requirements().clauses().begin(),
      accepted.requirements().clauses().end(),
      [&](const MetricRequirementClause& candidate) {
        return candidate.origin.clause_id == contract->clause_id;
      });
  if (clause == accepted.requirements().clauses().end() ||
      clause->origin.kind != header.kind ||
      clause->origin.parameters != parameters ||
      clause->origin.wire_coupling != header.coupling ||
      clause->origin.ordered_targets != header.ordered_targets ||
      clause->origin.selection_regime != header.selection_regime ||
      clause->origin.solver_regime != header.solver_regime ||
      !clause->origin.context ||
      clause->origin.context.get() != header.context.get()) {
    return temporal_bridge_fail<void>(
        "c22.transient_request_requirement_mismatch",
        "the transient request differs from its accepted C14 requirement "
        "clause");
  }
  return Result<void>::success();
}

Result<std::size_t> c17_scalar_request_target_ordinal(
    const AuditedCompiledFramework& framework, const MetricRequest& request) {
  auto request_match = c17_require_temporal_request_match(framework, request);
  if (!request_match) {
    return Result<std::size_t>::failure(request_match.error());
  }
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed()) {
    return temporal_bridge_fail<std::size_t>(
        "c22.framework_v0_source_unavailable",
        "scalar target resolution requires one live passing C17 V0 audit",
        DiagnosticCategory::unavailable);
  }

  const MetricRequestHeader& header = metric_request_header(request);
  if (header.coupling != MetricTargetCouplingV1::scalar_singleton ||
      header.ordered_targets.size() != 1U) {
    return temporal_bridge_fail<std::size_t>(
        "c22.transient_scalar_target_required",
        "a C22 scalar transient request must retain exactly one resolved "
        "target identity");
  }
  const ResolvedMetricTargetV1& requested = header.ordered_targets.front();
  const auto queues = core->inputs().instance.queues().entries();
  if (requested.dense_index.ordinal() >= queues.size() ||
      !(queues[requested.dense_index.ordinal()].id == requested.queue_id)) {
    return temporal_bridge_fail<std::size_t>(
        "c22.transient_target_physical_ordinal_mismatch",
        "the scalar request's QueueId and resolved physical dense ordinal do "
        "not identify one queue in the sealed instance");
  }

  const auto& deployed = core->descriptor().core.deployed_targets;
  std::optional<std::size_t> target_ordinal;
  for (std::size_t ordinal = 0U; ordinal < deployed.size(); ++ordinal) {
    if (!(deployed[ordinal] == requested.queue_id)) {
      continue;
    }
    if (target_ordinal.has_value()) {
      return temporal_bridge_fail<std::size_t>(
          "c22.transient_target_ambiguous_in_deployed_order",
          "the scalar request target occurs more than once in the sealed "
          "deployed-target order");
    }
    target_ordinal = ordinal;
  }
  if (!target_ordinal.has_value()) {
    return temporal_bridge_fail<std::size_t>(
        "c22.transient_target_absent_from_deployed_order",
        "the scalar request target is absent from the sealed deployed-target "
        "order");
  }

  // The V0 audit already binds TargetSelection to the descriptor.  Recheck
  // the value relation here so this narrow bridge remains self-contained and
  // cannot return an ordinal from a same-shaped but foreign selection.
  if (core->inputs().framework_seed.target_selection.ordered_targets !=
      deployed) {
    return temporal_bridge_fail<std::size_t>(
        "c22.transient_target_selection_order_mismatch",
        "the sealed target selection and descriptor deployed-target order "
        "differ");
  }
  return Result<std::size_t>::success(*target_ordinal);
}

Result<std::vector<BigNat>> c17_authored_transient_horizons(
    const AuditedCompiledFramework& framework, const MetricRequest& request) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed()) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.framework_v0_source_unavailable",
        "authored transient horizons require one live passing C17 V0 audit",
        DiagnosticCategory::unavailable);
  }

  const MetricRequestHeader& header = metric_request_header(request);
  if (header.kind != MetricKindV1::transient_backlog_law ||
      metric_request_kind(request) != MetricKindV1::transient_backlog_law) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.authored_transient_horizon_kind_mismatch",
        "authored transient horizons may be recovered only for a transient "
        "backlog-law request");
  }

  const auto& metrics = core->inputs().instance.analysis_spec().metrics;
  if (header.authored_index >= metrics.size()) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.authored_transient_horizon_index_mismatch",
        "the transient request's authored metric index is outside the "
        "immutable resolved analysis");
  }
  const MetricNode& node = metrics[header.authored_index];
  const auto* authored = std::get_if<TransientBacklogLawMetric>(&node.metric);
  if (node.id != header.metric_id || authored == nullptr) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.authored_transient_horizon_identity_mismatch",
        "the transient request does not identify the same authored metric id "
        "and kind in the immutable resolved analysis");
  }
  return Result<std::vector<BigNat>>::success(authored->horizons);
}

Result<std::vector<BigNat>> c17_decode_audited_temporal_backlog(
    const AuditedCompiledFramework& framework,
    const ReducedStateV1& state) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed() ||
      !core->consumer_seal_identity()) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.framework_v0_source_unavailable",
        "temporal state decoding requires one live passing C17 V0 audit",
        DiagnosticCategory::unavailable);
  }
  const ExactReducedStateSchemaV1& schema =
      core->inputs().exact_state_schema;
  if (!(state.codec == schema.reduced_state_codec) || !schema.decode ||
      !schema.validate_domain) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.temporal_state_decoder_binding_mismatch",
        "the reduced state does not match the sealed exact state decoder");
  }
  auto domain = schema.validate_domain(state);
  if (!domain) {
    return Result<std::vector<BigNat>>::failure(domain.error());
  }
  auto decoded = schema.decode(state);
  if (!decoded) {
    return Result<std::vector<BigNat>>::failure(decoded.error());
  }
  const TargetBacklogV1& backlog = decoded.value().backlog;
  if (!backlog.matches(core->inputs().instance) ||
      backlog.size() != core->descriptor().core.deployed_targets.size()) {
    return temporal_bridge_fail<std::vector<BigNat>>(
        "c22.temporal_state_backlog_binding_mismatch",
        "the decoded predictive backlog is not bound to the audited target "
        "order");
  }
  return Result<std::vector<BigNat>>::success(
      std::vector<BigNat>(backlog.values().begin(), backlog.values().end()));
}

Result<MarkedKernelRow> c17_enumerate_audited_temporal_row(
    const AuditedCompiledFramework& framework, const ReducedStateV1& state) {
  const auto core = C17TemporalBridgeAccess::core(framework);
  if (!core || !core->report().passed() || !core->row_available()) {
    return temporal_bridge_fail<MarkedKernelRow>(
        "c22.exact_temporal_row_unavailable",
        "the V0-sealed source has no exact enumerable temporal row",
        DiagnosticCategory::unavailable);
  }
  return C17TemporalBridgeAccess::compose_row(*core, state);
}

}  // namespace kernel::detail

Result<CompletedReducedEdge> execute_reduced_slot(
    const AuditedSlotExecutor& executor, const ReducedStateV1& state,
    RngBank& rng_bank) {
  auto core = detail::C17CoreAccess::core(executor);
  if (!core || !core->report().passed() || !core->slot_available()) {
    return c17_invalid<CompletedReducedEdge>(
        "c17.audited_slot_executor_unavailable",
        "the supplied audited view does not authorize realized slot "
        "execution");
  }
  return detail::C17CoreAccess::execute_candidate_slot(
      *core, state, rng_bank);
}

Result<ExactRational> AuditedThreeBinResponse::service_probability(
    const BigNat& target_backlog) const {
  auto core = detail::C17CoreAccess::core(*this);
  if (!core) {
    return c17_invalid<ExactRational>(
        "c17.audited_three_bin_view_unavailable",
        "the audited three-bin response has no sealed framework");
  }
  return detail::C17CoreAccess::three_bin_service_probability(
      *core, target_backlog);
}

Result<ExactRational>
AuditedFinitePrefixConstantTailResponse::service_probability(
    const BigNat& target_backlog) const {
  auto core = detail::C17CoreAccess::core(*this);
  if (!core) {
    return c17_invalid<ExactRational>(
        "c17.audited_finite_prefix_constant_tail_view_unavailable",
        "the audited finite-prefix/constant-tail response has no sealed "
        "framework");
  }
  return detail::C17CoreAccess::
      finite_prefix_constant_tail_service_probability(*core,
                                                      target_backlog);
}

}  // namespace mwperf
