#pragma once

#include <memory>
#include <utility>

#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "../arrival/core_internal.hpp"

namespace mwperf::surrogate::detail {

// Immutable post-V0 event authority.  C20 can invoke only these five narrow
// operations; it cannot recover a raw C16 operation prototype, plug, access
// carrier, RNG, or mutable C17 optimizer context from this object.
class SealedRomrOpsAuthority final {
 public:
  SealedRomrOpsAuthority(const SealedRomrOpsAuthority&) = delete;
  SealedRomrOpsAuthority& operator=(const SealedRomrOpsAuthority&) = delete;

  [[nodiscard]] Result<CanonicalRuntimeValueV1> initialize(
      const CanonicalRuntimeValueV1& value) const;
  [[nodiscard]] Result<CanonicalRuntimeValueV1> stop(
      const CanonicalRuntimeValueV1& value) const;
  [[nodiscard]] Result<CanonicalRuntimeValueV1> terminal(
      const EventTerminalReentryInputV1& input) const;
  [[nodiscard]] Result<CanonicalRuntimeValueV1> predecision(
      const EventPredecisionProjectionInputV1& input) const;
  [[nodiscard]] Result<CanonicalRuntimeValueV1> completed(
      const EventCompletedEdgeProjectionInputV1& input) const;

 private:
  SealedRomrOpsAuthority(
      bool unit_residence, CodecIdentityV1 state_codec,
      CodecIdentityV1 unit_indicator_codec,
      std::vector<std::byte> unit_true_value,
      std::optional<TemporalEventOperationsV1> event_operations)
      : unit_residence_(unit_residence),
        state_codec_(std::move(state_codec)),
        unit_indicator_codec_(std::move(unit_indicator_codec)),
        unit_true_value_(std::move(unit_true_value)),
        event_operations_(std::move(event_operations)) {}

  bool unit_residence_;
  CodecIdentityV1 state_codec_;
  CodecIdentityV1 unit_indicator_codec_;
  std::vector<std::byte> unit_true_value_;
  std::optional<TemporalEventOperationsV1> event_operations_;

  friend class ::mwperf::C17AuditedFrameworkMint;
};

// The single post-V0 owner of the executable candidate.  Public audited views
// retain only shared ownership of this type and cannot recover any raw
// callback or KernelAccess alternative.
class SealedFrameworkCore final {
 public:
  SealedFrameworkCore(
      SurrogatePlug plug,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 validated_contract_digest,
      MetricSupportManifest validated_structural_manifest,
      Digest256 execution_seal_digest,
      std::shared_ptr<const AuditedConsumerSealIdentity>
          consumer_seal_identity,
      std::shared_ptr<const SealedRomrOpsAuthority> romr_ops_authority,
      CompiledFrameworkCandidateInputsV1 inputs,
      PlugDescriptor descriptor, KernelAccess access,
      V0WitnessReport report)
      : plug_(std::move(plug)),
        artifact_bindings_(std::move(artifact_bindings)),
        validated_contract_digest_(std::move(validated_contract_digest)),
        validated_structural_manifest_(
            std::move(validated_structural_manifest)),
        execution_seal_digest_(std::move(execution_seal_digest)),
        consumer_seal_identity_(std::move(consumer_seal_identity)),
        romr_ops_authority_(std::move(romr_ops_authority)),
        inputs_(std::move(inputs)),
        descriptor_(std::move(descriptor)),
        access_(std::move(access)),
        report_(std::move(report)) {}

  [[nodiscard]] const SurrogatePlug& plug() const noexcept { return plug_; }
  [[nodiscard]] const ArtifactValidationBindingsV1& artifact_bindings()
      const noexcept {
    return artifact_bindings_;
  }
  [[nodiscard]] const Digest256& validated_contract_digest() const noexcept {
    return validated_contract_digest_;
  }
  [[nodiscard]] const MetricSupportManifest& structural_manifest()
      const noexcept {
    return validated_structural_manifest_;
  }
  [[nodiscard]] const Digest256& execution_seal_digest() const noexcept {
    return execution_seal_digest_;
  }
  [[nodiscard]] const std::shared_ptr<const AuditedConsumerSealIdentity>&
  consumer_seal_identity() const noexcept {
    return consumer_seal_identity_;
  }
  [[nodiscard]] const std::shared_ptr<const SealedRomrOpsAuthority>&
  romr_ops_authority() const noexcept {
    return romr_ops_authority_;
  }
  [[nodiscard]] CompiledFrameworkCandidateInputsV1& inputs() noexcept {
    return inputs_;
  }
  [[nodiscard]] const CompiledFrameworkCandidateInputsV1& inputs()
      const noexcept {
    return inputs_;
  }
  [[nodiscard]] const PlugDescriptor& descriptor() const noexcept {
    return descriptor_;
  }
  [[nodiscard]] const KernelAccess& access() const noexcept { return access_; }
  [[nodiscard]] const V0WitnessReport& report() const noexcept {
    return report_;
  }

  [[nodiscard]] bool row_available() const noexcept {
    const ExactCausalProgramV1& program = inputs_.causal_program;
    if (program.mode == ExactCausalProgramModeV1::bound_direct_decoder) {
      return false;
    }
    const auto law =
        ::mwperf::detail::ArrivalCoreAccess::law_core(
            inputs_.configured_arrival);
    const bool c09_row = law && static_cast<bool>(law->runtime.enumerate);
    const bool quotient_row =
        program.event_clock_semantics !=
            EventClockSemanticsV1::finite_phase_time_homogeneous_quotient ||
        (law &&
         static_cast<bool>(law->runtime.enumerate_time_homogeneous));
    if (closed_scalar_response_mode_v1(program.mode)) {
      return c09_row && quotient_row;
    }
    // A procedural residence carrier can still own an exact composed row on
    // the explicitly audited finite-phase quotient: the representation tag
    // describes how complete residences are exposed, while row exactness is
    // established independently by the C-minus, configured-arrival, and
    // C-plus enumerators below.  Keeping the procedural case quotient-only
    // preserves the released physical-clock generator boundary; a sampler
    // remains excluded in both cases.
    const bool exact_quotient_procedural =
        program.event_clock_semantics ==
            EventClockSemanticsV1::finite_phase_time_homogeneous_quotient &&
        std::holds_alternative<ProceduralResidenceGeneratorAccess>(access_);
    const bool exact_row_access =
        std::holds_alternative<FiniteEnumeratedRowAccess>(access_) ||
        std::holds_alternative<SparseRowAccess>(access_) ||
        exact_quotient_procedural;
    const CausalSurrogateOperationsV1* operations =
        causal_operations_v1(plug_);
    return exact_row_access && c09_row && quotient_row &&
           operations != nullptr &&
           operations->c_minus.has_value() &&
           operations->c_minus->has_exact_enumerator() &&
           operations->c_plus.has_value() &&
           operations->c_plus->has_exact_enumerator();
  }

  [[nodiscard]] bool slot_available() const noexcept {
    const ExactCausalProgramV1& program = inputs_.causal_program;
    if (program.event_clock_semantics ==
        EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
      // A quotient seal is deliberately row-only.  A realized path must keep
      // the monotonically advancing physical clock in its continuation state
      // and RNG/provenance address.
      return false;
    }
    if (program.mode == ExactCausalProgramModeV1::bound_direct_decoder) {
      return false;
    }
    const auto law =
        ::mwperf::detail::ArrivalCoreAccess::law_core(
            inputs_.configured_arrival);
    const bool arrival = law &&
                         (static_cast<bool>(law->runtime.enumerate) ||
                          static_cast<bool>(law->runtime.propose));
    if (closed_scalar_response_mode_v1(program.mode)) {
      return arrival;
    }
    const bool generative_access =
        std::holds_alternative<FiniteEnumeratedRowAccess>(access_) ||
        std::holds_alternative<SparseRowAccess>(access_) ||
        std::holds_alternative<NormalizedConditionalSamplerAccess>(access_) ||
        std::holds_alternative<ProceduralResidenceGeneratorAccess>(access_);
    const CausalSurrogateOperationsV1* operations =
        causal_operations_v1(plug_);
    const bool pre = operations != nullptr &&
                     operations->c_minus.has_value() &&
                     (operations->c_minus->has_operation() ||
                      operations->c_minus->has_exact_enumerator());
    const bool post = operations != nullptr &&
                      operations->c_plus.has_value() &&
                      (operations->c_plus->has_operation() ||
                       operations->c_plus->has_exact_enumerator());
    return generative_access && pre && arrival && post;
  }

  [[nodiscard]] bool is_three_bin() const noexcept {
    return inputs_.causal_program.mode ==
           ExactCausalProgramModeV1::closed_three_bin_scalar;
  }

  [[nodiscard]] bool is_finite_prefix_constant_tail() const noexcept {
    return inputs_.causal_program.mode ==
           ExactCausalProgramModeV1::
               closed_finite_prefix_constant_tail_scalar;
  }

  [[nodiscard]] bool is_closed_scalar_response() const noexcept {
    return closed_scalar_response_mode_v1(inputs_.causal_program.mode);
  }

 private:
  SurrogatePlug plug_;
  ArtifactValidationBindingsV1 artifact_bindings_;
  Digest256 validated_contract_digest_;
  MetricSupportManifest validated_structural_manifest_;
  Digest256 execution_seal_digest_;
  std::shared_ptr<const AuditedConsumerSealIdentity> consumer_seal_identity_;
  std::shared_ptr<const SealedRomrOpsAuthority> romr_ops_authority_;
  CompiledFrameworkCandidateInputsV1 inputs_;
  PlugDescriptor descriptor_;
  KernelAccess access_;
  V0WitnessReport report_;
};

}  // namespace mwperf::surrogate::detail

namespace mwperf::detail {

// Shared by the composer and V0: exact D, common feasibility, and canonical
// schedule identity are one mathematical obligation.
[[nodiscard]] Result<void> validate_resolved_action_math(
    const ResolvedInstance& instance, const TargetBacklogV1& backlog,
    const ResolvedAction& action);

}  // namespace mwperf::detail
