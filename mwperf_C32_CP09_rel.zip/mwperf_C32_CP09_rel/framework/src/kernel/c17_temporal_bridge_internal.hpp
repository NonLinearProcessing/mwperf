#pragma once

#include <memory>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"

namespace mwperf::kernel::detail {

// Narrow value-only C17 -> C22 handoff.  It deliberately omits the sealed
// framework core, raw plug/access variant, row callback, and slot executor.
struct C17TemporalBindingV1 final {
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
      seal_token;
  Digest256 source_fingerprint;
  Digest256 accepted_contract_identity;
  Digest256 normalized_requirements_identity;
  Digest256 authored_analysis_identity;
  Digest256 resolved_instance_identity;
  Digest256 target_selection_identity;
  Digest256 configured_arrival_identity;
  Digest256 selection_identity;
  Digest256 exact_state_schema_identity;
  Digest256 reduced_state_schema_identity;
  Digest256 mark_schema_identity;
  Digest256 continuation_schema_identity;
  Digest256 target_service_schema_identity;
  Digest256 timing_identity;
  CodecIdentityV1 state_codec;
  bool exact_row_available;
};

[[nodiscard]] Result<C17TemporalBindingV1> c17_temporal_binding(
    const AuditedCompiledFramework& framework);

[[nodiscard]] Result<void> c17_require_temporal_request_match(
    const AuditedCompiledFramework& framework, const MetricRequest& request);

// Resolves a scalar request's target into the accepted deployed-target order.
// The bridge checks all three identities independently: the authored QueueId,
// its resolved physical dense ordinal, and its unique position in the sealed
// descriptor's deployed-target vector.  C22 therefore never assumes that a
// scalar request addresses deployed-target ordinal zero.
[[nodiscard]] Result<std::size_t> c17_scalar_request_target_ordinal(
    const AuditedCompiledFramework& framework, const MetricRequest& request);

// Recovers authored transient horizons from the immutable resolved C03 input,
// rather than widening C14's normalized MetricRequest parameter schema merely
// to preserve presentation order.  The request's authored identity is checked
// before the raw order is returned.
[[nodiscard]] Result<std::vector<BigNat>> c17_authored_transient_horizons(
    const AuditedCompiledFramework& framework, const MetricRequest& request);

// Decodes only the public predictive backlog coordinate from one V0-sealed
// reduced state.  No rebuild function, raw schema callback, or hidden state is
// returned to C22.
[[nodiscard]] Result<std::vector<BigNat>>
c17_decode_audited_temporal_backlog(
    const AuditedCompiledFramework& framework, const ReducedStateV1& state);

// Checks the C16-minted predictive entrance against the same live C17 seal.
// No ReducedInitialLaw internals or framework core leave this bridge.
[[nodiscard]] Result<void> c17_require_transient_initial_seal(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law);

// Read-only value-graph access for C22.  The returned source contains only
// decoded states, marks, exact masses, budgets, and proof identities; no raw
// C16 callback or sealed framework core is exposed.
[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> c17_temporal_source(
    const AuditedCylinderLaw& law);
[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> c17_temporal_source(
    const AuditedTemporalKernel& kernel);
[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> c17_temporal_source(
    const AuditedTemporalLaw& law);

[[nodiscard]] bool c17_temporal_view_has_framework_core(
    const AuditedCylinderLaw& law) noexcept;
[[nodiscard]] bool c17_temporal_view_has_framework_core(
    const AuditedTemporalKernel& kernel) noexcept;
[[nodiscard]] bool c17_temporal_view_has_framework_core(
    const AuditedTemporalLaw& law) noexcept;

// The only C17-authorized transient carrier mints.  They preserve the live V0
// core internally but expose no raw access or callback to C22.
[[nodiscard]] Result<AuditedCylinderLaw> c17_mint_transient_cylinder_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
    const Digest256& source_fingerprint);
[[nodiscard]] Result<AuditedTemporalKernel> c17_mint_transient_temporal_kernel(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source,
    const Digest256& source_fingerprint);

// Strict C17-authorized framework-v0 restrictions.  These private mints do
// not create a catalog edge and cannot be reached from raw C16 access.  The
// source must already carry the exact live C17 seal and a framework_v0
// binding with no stationary-projection claim.
[[nodiscard]] Result<AuditedCylinderLaw> c17_mint_framework_v0_cylinder_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source);
[[nodiscard]] Result<AuditedTemporalKernel>
c17_mint_framework_v0_temporal_kernel(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source);
[[nodiscard]] Result<AuditedTemporalLaw> c17_mint_framework_v0_temporal_law(
    const AuditedCompiledFramework& framework,
    std::shared_ptr<const metrics::detail::TemporalSourceCore> source);

// Confirms that an audited temporal restriction still names the exact live V0
// consumer seal recorded by its dependency-neutral source binding.  C22 never
// receives the underlying SealedFrameworkCore through this bridge.
[[nodiscard]] Result<void> c17_require_temporal_view_seal(
    const AuditedCylinderLaw& law,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal);
[[nodiscard]] Result<void> c17_require_temporal_view_seal(
    const AuditedTemporalKernel& kernel,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal);
[[nodiscard]] Result<void> c17_require_temporal_view_seal(
    const AuditedTemporalLaw& law,
    const std::shared_ptr<const
                          surrogate::detail::AuditedConsumerSealIdentity>&
        expected_seal);

// Enumerates one exact V0-composed predictive row.  This private restriction
// is part of the F-C17-07 audited source handoff; it is not F-C17-06 and cannot
// be obtained from an unaudited carrier.
[[nodiscard]] Result<MarkedKernelRow> c17_enumerate_audited_temporal_row(
    const AuditedCompiledFramework& framework, const ReducedStateV1& state);

}  // namespace mwperf::kernel::detail
