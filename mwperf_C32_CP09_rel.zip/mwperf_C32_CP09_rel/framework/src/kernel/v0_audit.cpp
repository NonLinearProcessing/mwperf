#include "mwperf/kernel/causal_kernel_compiler.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <ranges>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "../arrival/core_internal.hpp"
#include "c17_core_internal.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> audit_failure(std::string code,
                                      std::string message) {
  return Result<T>::failure(
      Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), std::nullopt, std::nullopt, {}});
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::ranges::any_of(digest.bytes(), [](const std::byte value) {
    return value != std::byte{0};
  });
}

[[nodiscard]] bool valid_codec(const CodecIdentityV1& codec) noexcept {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] bool valid_sampler_reveal_stage(
    const ConditionalSamplerRevealStageV1 value) noexcept {
  switch (value) {
    case ConditionalSamplerRevealStageV1::prearrival_residual:
    case ConditionalSamplerRevealStageV1::postarrival_residual:
    case ConditionalSamplerRevealStageV1::generic_row_residual:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_sampler_dependence(
    const ConditionalSampleDependenceV1 value) noexcept {
  switch (value) {
    case ConditionalSampleDependenceV1::iid_cold_replications:
    case ConditionalSampleDependenceV1::correlated_trace:
    case ConditionalSampleDependenceV1::iid_proposal:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_sampler_support_kind(
    const ConditionalSupportKindV1 value) noexcept {
  switch (value) {
    case ConditionalSupportKindV1::finite_declared:
    case ConditionalSupportKindV1::membership_query:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_sampler_evidence_scope(
    const SamplerEvidenceScopeV1 value) noexcept {
  switch (value) {
    case SamplerEvidenceScopeV1::declared:
    case SamplerEvidenceScopeV1::construction_enforced:
    case SamplerEvidenceScopeV1::independently_audited:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_runtime_sampling_provenance(
    const RuntimeSamplingProvenanceV1 value) noexcept {
  switch (value) {
    case RuntimeSamplingProvenanceV1::deployed_generator:
    case RuntimeSamplingProvenanceV1::physical_trace:
    case RuntimeSamplingProvenanceV1::arrival_only_replay:
    case RuntimeSamplingProvenanceV1::modified_compatible_state:
    case RuntimeSamplingProvenanceV1::proposal:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_sampler_v1_evidence_scope(
    const SamplerV1EvidenceScopeV1 value) noexcept {
  switch (value) {
    case SamplerV1EvidenceScopeV1::none:
    case SamplerV1EvidenceScopeV1::row_conditional:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_sampler_v2_evidence_scope(
    const SamplerV2EvidenceScopeV1 value) noexcept {
  switch (value) {
    case SamplerV2EvidenceScopeV1::none:
    case SamplerV2EvidenceScopeV1::marked_path_dynamic_lift:
      return true;
  }
  return false;
}

class C17IdentityEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void boolean(const bool value) { byte(value ? 1U : 0U); }
  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void count(const std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }
  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(const Enum value) {
    using Underlying = std::underlying_type_t<Enum>;
    using Unsigned = std::make_unsigned_t<Underlying>;
    u64(static_cast<std::uint64_t>(static_cast<Unsigned>(value)));
  }
  void raw(const std::span<const std::byte> value) {
    count(value.size());
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void raw_u8(const std::span<const std::uint8_t> value) {
    count(value.size());
    for (const std::uint8_t item : value) {
      byte(item);
    }
  }
  void string(const std::string_view value) {
    count(value.size());
    for (const char character : value) {
      byte(static_cast<std::uint8_t>(
          static_cast<unsigned char>(character)));
    }
  }
  void digest(const Digest256& value) { raw(value.bytes()); }
  void codec(const CodecIdentityV1& value) {
    string(value.id);
    u32(value.version);
  }
  void runtime_value(const CanonicalRuntimeValueV1& value) {
    codec(value.codec);
    raw(value.canonical_value);
  }
  template <StrongIdDomainName Domain>
  void id(const StrongId<Domain>& value) {
    raw_u8(value.canonical_bytes());
  }
  void optional_count(const std::optional<std::size_t>& value) {
    boolean(value.has_value());
    if (value.has_value()) {
      count(*value);
    }
  }
  [[nodiscard]] std::span<const std::byte> bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

void encode_transition_shape(C17IdentityEncoder& encoder,
                             const TransitionKernelAccessShapeV1& shape) {
  encoder.codec(shape.conditioning_state_codec);
  encoder.codec(shape.successor_state_codec);
  encoder.count(shape.ordered_mark_codecs.size());
  for (const CodecIdentityV1& codec : shape.ordered_mark_codecs) {
    encoder.codec(codec);
  }
  encoder.optional_count(shape.maximum_row_atoms);
  encoder.boolean(shape.event_generator_identity.has_value());
  if (shape.event_generator_identity.has_value()) {
    encoder.id(shape.event_generator_identity->operation_id);
    encoder.u32(shape.event_generator_identity->operation_version);
  }
}

void encode_optional_digest(C17IdentityEncoder& encoder,
                            const std::optional<Digest256>& value) {
  encoder.boolean(value.has_value());
  if (value.has_value()) {
    encoder.digest(*value);
  }
}

void encode_sampler_contract(C17IdentityEncoder& encoder,
                             const ConditionalSamplerContractV1& contract) {
  encoder.u32(contract.schema_version);
  encoder.enumeration(contract.reveal_stage);
  encoder.enumeration(contract.dependence);
  encoder.enumeration(contract.support_kind);
  encoder.optional_count(contract.finite_support_cardinality);
  encoder.digest(contract.persistent_state_schema);
  encoder.digest(contract.support_identity);
  encoder.digest(contract.proposal_law_identity);
  encoder.digest(contract.residual_schema);
  encoder.digest(contract.output_schema);
  encoder.digest(contract.configured_arrival_law);
  encode_optional_digest(encoder, contract.common_projection_identity);
  encoder.boolean(contract.normalized_probability_law);
  encoder.boolean(contract.almost_sure_return);
  encoder.boolean(contract.persistent_memory_is_explicit);
  encoder.boolean(contract.no_hidden_warm_state);
  encoder.boolean(contract.prearrival_excludes_fresh_arrival);
  encoder.enumeration(contract.normalization_evidence);
  encoder.enumeration(contract.termination_evidence);
  encoder.enumeration(contract.v1_evidence_scope);
  encode_optional_digest(encoder, contract.v1_evidence_reference);
  encoder.enumeration(contract.v2_evidence_scope);
  encode_optional_digest(encoder, contract.v2_evidence_reference);
  encode_optional_digest(encoder, contract.foreign_construction_evidence);
  encoder.enumeration(contract.runtime_provenance);
}

void encode_ratio_contract(
    C17IdentityEncoder& encoder,
    const ConditionalTargetRatioContractV1& contract) {
  encoder.u32(contract.schema_version);
  encoder.enumeration(contract.target_kind);
  encoder.digest(contract.target_law_identity);
  encoder.digest(contract.metric_target_digest);
  encoder.digest(contract.reward_decoder_digest);
  encoder.digest(contract.residual_schema);
  encoder.digest(contract.output_schema);
  encoder.boolean(contract.proposal_dominates_target);
  encoder.boolean(contract.positive_finite_weight_mean);
  encoder.boolean(contract.weighted_reward_integrable);
  encoder.boolean(contract.iid_proposal);
  encoder.boolean(contract.weighted_second_moment);
  encoder.boolean(contract.transition_ratio_only);
}

void encode_innovation_contract(
    C17IdentityEncoder& encoder,
    const ConditionalExactInnovationContractV1& contract) {
  encoder.u32(contract.schema_version);
  encoder.digest(contract.representation_identity);
  encoder.digest(contract.metric_target_digest);
  encoder.digest(contract.configured_arrival_law);
  encoder.digest(contract.reward_decoder_digest);
  encoder.digest(contract.residual_schema);
  encoder.digest(contract.output_schema);
  encoder.boolean(contract.configured_joint_innovation);
  encoder.string(
      contract.maximum_absolute_integration_error.to_canonical_string());
}

[[nodiscard]] Result<void> validate_sealed_sampler_contract(
    const KernelAccess& access) {
  const auto* sampler =
      std::get_if<NormalizedConditionalSamplerAccess>(&access);
  if (sampler == nullptr) {
    return Result<void>::success();
  }
  if (!sampler->contract().has_value()) {
    return audit_failure<void>(
        "c17.missing_conditional_sampler_contract",
        "a normalized conditional sampler must declare the complete C24 "
        "support, provenance, persistence, normalization, and return "
        "contract before V0 can seal it");
  }
  const ConditionalSamplerContractV1& contract = *sampler->contract();
  if (contract.schema_version != 1U ||
      !valid_sampler_reveal_stage(contract.reveal_stage) ||
      !valid_sampler_dependence(contract.dependence) ||
      !valid_sampler_support_kind(contract.support_kind) ||
      !valid_sampler_evidence_scope(contract.normalization_evidence) ||
      !valid_sampler_evidence_scope(contract.termination_evidence) ||
      !valid_sampler_v1_evidence_scope(contract.v1_evidence_scope) ||
      !valid_sampler_v2_evidence_scope(contract.v2_evidence_scope) ||
      !valid_runtime_sampling_provenance(contract.runtime_provenance) ||
      !nonzero_digest(contract.persistent_state_schema) ||
      !nonzero_digest(contract.support_identity) ||
      !nonzero_digest(contract.proposal_law_identity) ||
      !nonzero_digest(contract.residual_schema) ||
      !nonzero_digest(contract.output_schema) ||
      !nonzero_digest(contract.configured_arrival_law) ||
      (contract.common_projection_identity.has_value() &&
       !nonzero_digest(*contract.common_projection_identity)) ||
      !contract.normalized_probability_law ||
      !contract.almost_sure_return ||
      !contract.persistent_memory_is_explicit ||
      !contract.no_hidden_warm_state ||
      !sampler->has_sample_validator()) {
    return audit_failure<void>(
        "c17.incomplete_conditional_sampler_contract",
        "the C24 sampler contract must be version 1, bind every schema and "
        "law and provenance identity, and affirm normalization, "
        "almost-sure return, and fully explicit persistent memory");
  }
  const bool has_v1_scope =
      contract.v1_evidence_scope != SamplerV1EvidenceScopeV1::none;
  const bool has_v2_scope =
      contract.v2_evidence_scope != SamplerV2EvidenceScopeV1::none;
  if (has_v1_scope != contract.v1_evidence_reference.has_value() ||
      has_v2_scope != contract.v2_evidence_reference.has_value() ||
      (contract.v1_evidence_reference.has_value() &&
       !nonzero_digest(*contract.v1_evidence_reference)) ||
      (contract.v2_evidence_reference.has_value() &&
       !nonzero_digest(*contract.v2_evidence_reference))) {
    return audit_failure<void>(
        "c17.invalid_sampler_fidelity_evidence_binding",
        "V1 row evidence and V2 dynamic-path evidence must each carry one "
        "nonzero reference if and only if its typed scope is present");
  }
  if (contract.reveal_stage ==
          ConditionalSamplerRevealStageV1::prearrival_residual &&
      !contract.prearrival_excludes_fresh_arrival) {
    return audit_failure<void>(
        "c17.prearrival_sampler_claims_fresh_arrival",
        "a prearrival residual generator must structurally exclude every "
        "fresh configured-arrival field");
  }
  if (contract.support_kind ==
      ConditionalSupportKindV1::finite_declared) {
    if (!contract.finite_support_cardinality.has_value() ||
        *contract.finite_support_cardinality == 0U ||
        !sampler->has_support_enumerator()) {
      return audit_failure<void>(
          "c17.incomplete_finite_sampler_support",
          "finite sampler support requires a positive declared cardinality "
          "and an exact row support enumerator");
    }
  } else if (contract.finite_support_cardinality.has_value() ||
             !sampler->has_support_query()) {
    return audit_failure<void>(
        "c17.incomplete_sampler_support_query",
        "nonfinite sampler support requires a membership query and cannot "
        "claim a finite cardinality");
  }
  // Ratio and exact-innovation services are optional estimator authorities,
  // not prerequisites for the normalized sampler itself.  Their raw fields
  // remain sealed into the execution identity, while C24 validates each
  // contract/operation pair and converts an invalid pair to typed
  // Unavailable.  A defect in one optional estimator must not disable an
  // otherwise valid deployed sampler.
  return Result<void>::success();
}

[[nodiscard]] Result<Digest256> execution_seal_digest(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor,
    const Digest256& raw_access_identity,
    const DirectFactorWitnessV1* direct_factor) {
  const AuditedFrameworkBindingsV1& bindings =
      inputs.framework_seed.bindings;
  const auto arrival_core =
      detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
  if (!arrival_core) {
    return audit_failure<Digest256>(
        "c17.execution_seal_missing_arrival",
        "the execution seal requires the immutable configured-arrival law "
        "identity");
  }
  if (descriptor.descriptor_digest != bindings.descriptor_digest ||
      raw_access_identity != bindings.access_digest) {
    return audit_failure<Digest256>(
        "c17.execution_seal_binding_mismatch",
        "the canonical descriptor and raw-access identities must equal the "
        "already audited framework bindings before sealing");
  }

  C17IdentityEncoder encoder;
  const FrameworkProblemFingerprintsV1& problem =
      bindings.problem_fingerprints;
  encoder.digest(problem.authored_inputs.model);
  encoder.digest(problem.authored_inputs.analysis);
  encoder.digest(problem.authored_inputs.combined);
  encoder.digest(problem.resolved_instance);
  encoder.digest(problem.constraint);
  encoder.digest(problem.target_selection);
  encoder.digest(problem.tie_and_timing);
  encoder.digest(problem.compiled_arrival);
  encoder.digest(bindings.problem_view_digest.value());
  encoder.digest(bindings.exact_state_schema_digest);
  encoder.digest(bindings.reduced_state_schema_digest);
  encoder.digest(bindings.descriptor_digest);
  encoder.digest(bindings.access_digest);
  encoder.digest(bindings.accepted_contract_digest);
  encoder.digest(bindings.normalized_metric_requirements_digest);
  encoder.digest(bindings.ordered_target_digest);
  encoder.digest(bindings.selection_digest);
  encoder.digest(bindings.build_request_digest);
  encoder.boolean(bindings.direct_metric_decoder_domain.has_value());
  if (bindings.direct_metric_decoder_domain.has_value()) {
    encoder.id(bindings.direct_metric_decoder_domain->decoder_key);
    // validate_direct_metric_services proves that the exact parameter is the
    // sole accepted C14 clause parameter.  Its canonical requirements digest
    // is therefore the canonical parameter identity rather than a second,
    // locally invented MetricRequestParameters encoder.
    encoder.digest(bindings.normalized_metric_requirements_digest);
  }
  encoder.digest(inputs.exact_state_schema.ownership_schema_digest);
  encoder.digest(inputs.exact_state_schema.exact_update_schema_digest);
  encoder.digest(inputs.build_identity.digest());
  encoder.digest(arrival_core->binding.law_digest.value());
  const ExactCausalProgramV1& program = inputs.causal_program;
  encoder.enumeration(program.mode);
  encoder.string(program.conditional_row_tolerance.to_canonical_string());
  encoder.optional_count(
      program.representation_budget.maximum_integral_bits);
  encoder.count(program.reachable_audit_states.size());
  for (const ReducedStateV1& state : program.reachable_audit_states) {
    encoder.runtime_value(state);
  }
  encoder.optional_count(program.maximum_residence_slots);
  encoder.boolean(program.finite_event_domain_states.has_value());
  if (program.finite_event_domain_states.has_value()) {
    encoder.count(program.finite_event_domain_states->size());
    for (const ReducedStateV1& state :
         *program.finite_event_domain_states) {
      encoder.runtime_value(state);
    }
  }
  encoder.boolean(program.event_entry_domain_is_exact_state_domain);
  encoder.enumeration(program.event_clock_semantics);
  encoder.boolean(static_cast<bool>(direct_factor));
  if (inputs.direct_metric_services.has_value()) {
    if (direct_factor == nullptr) {
      return audit_failure<Digest256>(
          "c17.execution_seal_missing_direct_factor",
          "a direct execution seal requires its bound passing causal factor");
    }
    encoder.digest(direct_factor->execution_seal_digest());
  }
  return sha256_domain_separated("mwperf.c17.execution-seal.v1",
                                 encoder.bytes());
}

[[nodiscard]] const PortablePayloadContextV1& portable_context(
    const SurrogatePlug& plug) {
  return std::visit(
      [](const auto& payload) -> const PortablePayloadContextV1& {
        return payload.context;
      },
      portable_source_v1(plug).value());
}

template <typename Left, typename Right>
[[nodiscard]] bool equal_span(const Left& left, const Right& right) {
  return left.size() == right.size() &&
         std::ranges::equal(left, right);
}

[[nodiscard]] bool same_complete_marked_row(
    const MarkedKernelRow& left, const MarkedKernelRow& right) {
  if (left.atoms().size() != right.atoms().size()) {
    return false;
  }
  for (std::size_t index = 0U; index < left.atoms().size(); ++index) {
    const MarkedKernelRowAtomV1& left_atom = left.atoms()[index];
    const MarkedKernelRowAtomV1& right_atom = right.atoms()[index];
    if (!(left_atom.edge == right_atom.edge) ||
        left_atom.exact_mass != right_atom.exact_mass ||
        left_atom.structural_support != right_atom.structural_support ||
        left_atom.numerical_image != right_atom.numerical_image ||
        left_atom.numerical_image_status !=
            right_atom.numerical_image_status ||
        left_atom.exact_cumulative_mass !=
            right_atom.exact_cumulative_mass) {
      return false;
    }
  }
  return left.exact_total_mass() == right.exact_total_mass() &&
         equal_span(left.stage_mass_diagnostics(),
                    right.stage_mass_diagnostics()) &&
         left.categorical() == right.categorical() &&
         left.numerical_row_image() == right.numerical_row_image();
}

[[nodiscard]] bool program_has_row(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  const auto& arrival_core =
      detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
  const bool c09_row = arrival_core &&
                       static_cast<bool>(arrival_core->runtime.enumerate);
  if (closed_scalar_response_mode_v1(program.mode)) {
    return c09_row;
  }
  if (program.mode == ExactCausalProgramModeV1::bound_direct_decoder) {
    return false;
  }
  const CausalSurrogateOperationsV1* operations =
      causal_operations_v1(plug);
  return c09_row && operations != nullptr &&
         operations->c_minus.has_value() &&
         operations->c_minus->has_exact_enumerator() &&
         operations->c_plus.has_value() &&
         operations->c_plus->has_exact_enumerator();
}

[[nodiscard]] bool program_has_slot(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  const auto& arrival_core =
      detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
  const bool c09_slot =
      arrival_core && (static_cast<bool>(arrival_core->runtime.enumerate) ||
                       static_cast<bool>(arrival_core->runtime.propose));
  if (closed_scalar_response_mode_v1(program.mode)) {
    return c09_slot;
  }
  if (program.mode == ExactCausalProgramModeV1::bound_direct_decoder) {
    return false;
  }
  const CausalSurrogateOperationsV1* operations =
      causal_operations_v1(plug);
  if (operations == nullptr || !operations->c_minus.has_value() ||
      !operations->c_plus.has_value()) {
    return false;
  }
  const bool prearrival = operations->c_minus->has_operation() ||
                          operations->c_minus->has_exact_enumerator();
  const bool postarrival = operations->c_plus->has_operation() ||
                           operations->c_plus->has_exact_enumerator();
  return prearrival && c09_slot && postarrival;
}

[[nodiscard]] Result<void> validate_exact_state_schema(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor) {
  const ExactReducedStateSchemaV1& schema = inputs.exact_state_schema;
  const AuditedFrameworkSeedV1& seed = inputs.framework_seed;

  if (!valid_codec(schema.reduced_state_codec) ||
      schema.reduced_state_codec != seed.reduced_state_codec ||
      !schema.decode || !schema.rebuild || !schema.validate_domain) {
    return audit_failure<void>(
        "c17.incomplete_exact_state_operations",
        "the V0 candidate requires one codec-bound decode, exact rebuild, "
        "and complete reduced-state domain predicate");
  }
  if (!nonzero_digest(schema.exact_state_schema_digest) ||
      !nonzero_digest(schema.reduced_state_schema_digest) ||
      !nonzero_digest(schema.ownership_schema_digest) ||
      !nonzero_digest(schema.exact_update_schema_digest) ||
      schema.exact_state_schema_digest !=
          seed.bindings.exact_state_schema_digest ||
      schema.reduced_state_schema_digest !=
          seed.bindings.reduced_state_schema_digest) {
    return audit_failure<void>(
        "c17.exact_state_schema_binding_mismatch",
        "exact-state, reduced-state, ownership, and exact-update identities "
        "must be nonzero and retain their distinct audited bindings");
  }
  if (!seed.initial_mapper || !seed.exact_state_schema_validator ||
      !seed.reduced_state_domain_validator ||
      !seed.physical_atom_projection_validator) {
    return audit_failure<void>(
        "c17.incomplete_initial_state_operations",
        "the C17 seal must retain all C16 exact initial-state operations");
  }
  if (descriptor.core.selection != seed.selection_support) {
    return audit_failure<void>(
        "c17.selection_support_binding_mismatch",
        "the sealed initial selection support must equal the accepted "
        "descriptor support");
  }
  if (descriptor.transition_state_schema.has_value() &&
      (descriptor.transition_state_schema->conditioning_state_codec !=
           schema.reduced_state_codec ||
       descriptor.transition_state_schema->successor_state_codec !=
           schema.reduced_state_codec)) {
    return audit_failure<void>(
        "c17.transition_state_codec_mismatch",
        "both ends of a reduced transition must use the exact sealed "
        "reduced-state codec");
  }
  if ((descriptor.c_minus.has_value() &&
       descriptor.c_minus->predecision_state_codec !=
           schema.reduced_state_codec) ||
      (descriptor.c_plus.has_value() &&
       descriptor.c_plus->prearrival_state_codec !=
           schema.reduced_state_codec)) {
    return audit_failure<void>(
        "c17.causal_state_codec_binding_mismatch",
        "C-minus and C-plus state inputs must equal the sealed reduced-state "
        "codec");
  }

  if (descriptor.c_plus.has_value()) {
    const CodecIdentityV1 emitted_opportunity_codec{
        std::string(kC17EmittedOpportunityCodecIdV1),
        kC17EmittedOpportunityCodecVersionV1};
    const CodecIdentityV1 resolved_action_codec{
        std::string(kC17ResolvedActionCodecIdV1),
        kC17ResolvedActionCodecVersionV1};
    const CodecIdentityV1 configured_arrival_codec{
        std::string(kC17ConfiguredArrivalTransitionCodecIdV1),
        kC17ConfiguredArrivalTransitionCodecVersionV1};
    if (descriptor.c_plus->opportunity_codec !=
            emitted_opportunity_codec ||
        descriptor.c_plus->decision_codec != resolved_action_codec ||
        descriptor.c_plus->configured_arrival_codec !=
            configured_arrival_codec) {
      return audit_failure<void>(
          "c17.cplus_fixed_input_codec_mismatch",
          "C-plus must consume the fixed lossless emitted-opportunity, "
          "resolved-action, and configured-arrival carriers");
    }
    for (const RuntimeMarkIdV1& read_mark :
         descriptor.c_plus->read_marks) {
      const auto declared = std::ranges::find_if(
          descriptor.marks,
          [&](const RuntimeMarkDescriptorV1& mark) {
            return mark.id == read_mark;
          });
      if (declared != descriptor.marks.end() &&
          declared->decoder_source ==
              MarkDecoderSourceV1::entrance_realization) {
        return audit_failure<void>(
            "c17.cplus_entrance_mark_unavailable",
            "C-plus may read only marks carried by its current five-stage "
            "slot branch, not a separate temporal entrance realization");
      }
    }
  }

  for (const RuntimeStateFieldV1& field : descriptor.state_fields) {
    if (field.c14_field.ownership == FieldOwnershipV1::framework_exact &&
        descriptor.c_plus.has_value() &&
        std::ranges::find(
            descriptor.c_plus->writable_unresolved_fields, field.id) !=
            descriptor.c_plus->writable_unresolved_fields.end()) {
      return audit_failure<void>(
          "c17.exact_field_ownership_overlap",
          "C-plus cannot name a framework-exact coordinate in its "
          "unresolved write set");
    }
  }

  if (!inputs.optimizer_context.active() ||
      !inputs.optimizer_context.matches_dimension(
          QueueDimensionToken::from_instance(inputs.instance))) {
    return audit_failure<void>(
        "c17.optimizer_context_binding_mismatch",
        "the candidate must own the active execution-local optimizer ledger "
        "for the same resolved queue dimension");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_candidate_bindings(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs,
    const Digest256& validated_descriptor_digest,
    const ArtifactValidationBindingsV1& artifact_bindings,
    const Digest256& validated_contract_digest,
    const MetricSupportManifest& structural_manifest,
    const PlugDescriptor& descriptor, const KernelAccess& access,
    const bool access_matches_plug,
    const Digest256& canonical_access_identity,
    const bool auxiliary_direct_factor = false) {
  const PortablePayloadContextV1& source = portable_context(plug);
  const AuditedFrameworkSeedV1& seed = inputs.framework_seed;

  if (descriptor.descriptor_digest != validated_descriptor_digest ||
      descriptor.descriptor_digest != seed.bindings.descriptor_digest) {
    return audit_failure<void>(
        "c17.descriptor_binding_mismatch",
        "the supplied runtime descriptor must equal both the C16-validated "
        "descriptor identity retained by the candidate and the V0 seed");
  }
  if (!access_matches_plug ||
      runtime_access_tag_v1(access) != descriptor.core.runtime_access) {
    return audit_failure<void>(
        "c17.access_binding_mismatch",
        "the separately consumed raw access must share the exact immutable "
        "operation and complete typed domain of the validated plug access");
  }
  if (!nonzero_digest(canonical_access_identity) ||
      seed.bindings.access_digest != canonical_access_identity) {
    return audit_failure<void>(
        "c17.access_identity_binding_mismatch",
      "the V0 seed access identity must equal the canonical callback-free "
      "identity of the exact owner-matched raw access selection");
  }

  if (auxiliary_direct_factor) {
    const bool finite_row =
        std::holds_alternative<FiniteEnumeratedRowAccess>(access) ||
        std::holds_alternative<SparseRowAccess>(access);
    PlugDescriptorCore expected_factor_core =
        inputs.accepted_contract.descriptor_core();
    expected_factor_core.semantic =
        SemanticTagV1::stationary_marked_edge;
    expected_factor_core.runtime_access =
        descriptor.core.runtime_access;
    // validate_plug_descriptor_v1 has already proved that the factor core's
    // digest is canonical.  Ignore only that derived field while requiring
    // every other outer-request axis to remain byte-for-byte unchanged.
    expected_factor_core.core_digest = descriptor.core.core_digest;
    if (!finite_row ||
        descriptor.core.semantic !=
            SemanticTagV1::stationary_marked_edge ||
        semantic_tag_v1(plug) != descriptor.core.semantic ||
        descriptor.core != expected_factor_core ||
        inputs.accepted_contract.semantic() !=
            SemanticTagV1::direct_metric_decoder ||
        inputs.accepted_contract.runtime_access() !=
            RuntimeAccessTagV1::direct_metric_decoder ||
        artifact_bindings.semantic !=
            inputs.accepted_contract.semantic() ||
        source.semantic != inputs.accepted_contract.semantic() ||
        artifact_bindings.runtime_access !=
            inputs.accepted_contract.runtime_access() ||
        source.runtime_access !=
            inputs.accepted_contract.runtime_access() ||
        artifact_bindings.payload_class !=
            inputs.accepted_contract.payload_class() ||
        source.payload_class != inputs.accepted_contract.payload_class() ||
        descriptor.core.provider != artifact_bindings.provider ||
        descriptor.core.provider != inputs.accepted_contract.provider() ||
        artifact_bindings.construction_method !=
            inputs.accepted_contract.construction_method() ||
        artifact_bindings.producer_mode !=
            inputs.accepted_contract.producer_mode()) {
      return audit_failure<void>(
          "c17.direct_factor_outer_binding_mismatch",
          "the auxiliary stationary row factor may change only the direct "
          "semantic/access pair and must retain the exact provider, payload, "
          "targets, selection, phase, state, mark, and construction axes of "
          "the one validated direct request");
    }

    if (validated_contract_digest !=
            inputs.accepted_contract.contract_digest() ||
        artifact_bindings.accepted_contract_digest !=
            inputs.accepted_contract.contract_digest() ||
        seed.bindings.accepted_contract_digest !=
            inputs.accepted_contract.contract_digest() ||
        artifact_bindings.requirements_digest !=
            inputs.accepted_contract.requirements_digest() ||
        seed.bindings.normalized_metric_requirements_digest !=
            inputs.accepted_contract.requirements_digest() ||
        artifact_bindings.arrival_capabilities_digest !=
            inputs.accepted_contract.arrival_capabilities_digest() ||
        artifact_bindings.preview_digest !=
            inputs.accepted_contract.preview_digest() ||
        artifact_bindings.parameter_digest !=
            inputs.accepted_contract.parameter_digest() ||
        artifact_bindings.budget_digest !=
            inputs.accepted_contract.budget_digest()) {
      return audit_failure<void>(
          "c17.direct_factor_contract_binding_mismatch",
          "the auxiliary factor must retain the one direct request's exact "
          "accepted contract, arrival capabilities, parameters, preview, "
          "and construction budget identities");
    }

    if (!(structural_manifest ==
          inputs.accepted_contract.structural_manifest()) ||
        structural_manifest.canonical_digest() !=
            inputs.accepted_contract.structural_manifest()
                .canonical_digest() ||
        structural_manifest.canonical_digest() !=
            artifact_bindings.structural_manifest_digest ||
        structural_manifest.canonical_digest() !=
            descriptor.core.metric_support_manifest_digest ||
        source.structural_manifest_echo.manifest_digest !=
            structural_manifest.canonical_digest()) {
      return audit_failure<void>(
          "c17.direct_factor_manifest_binding_mismatch",
          "the auxiliary factor must retain the direct artifact's exact "
          "registered structural manifest identity");
    }

    if (inputs.build_identity.digest() !=
            artifact_bindings.build_identity_digest ||
        inputs.build_identity.digest() != source.build_identity_digest ||
        inputs.final_request_identity != artifact_bindings.request_digest ||
        inputs.final_request_identity != source.request_digest ||
        inputs.final_request_identity !=
            seed.bindings.build_request_digest ||
        source.framework_problem_view_digest !=
            artifact_bindings.framework_problem_view_digest ||
        source.framework_problem_view_digest !=
            seed.bindings.problem_view_digest.value()) {
      return audit_failure<void>(
          "c17.direct_factor_request_binding_mismatch",
          "the auxiliary factor must retain the validated direct artifact's "
          "build, final-request, and framework-problem identities");
    }

    auto problem = build_framework_problem_view_matching_arrival_projection(
        inputs.instance, inputs.configured_arrival, seed.target_selection,
        seed.bindings.problem_fingerprints.compiled_arrival);
    if (!problem) {
      return Result<void>::failure(problem.error());
    }
    if (problem.value().configured_arrival().capabilities() !=
        inputs.accepted_contract.arrival_capabilities()) {
      return audit_failure<void>(
          "c17.direct_factor_contract_binding_mismatch",
          "the auxiliary factor must retain the provider-bound configured "
          "arrival capabilities accepted for the direct contract");
    }
    if (problem.value().fingerprints() !=
            seed.bindings.problem_fingerprints ||
        problem.value().canonical_digest() !=
            seed.bindings.problem_view_digest ||
        problem.value().target_selection() != seed.target_selection ||
        descriptor.core.deployed_targets !=
            seed.target_selection.ordered_targets ||
        source.ordered_deployed_targets !=
            seed.target_selection.ordered_targets) {
      return audit_failure<void>(
          "c17.direct_factor_problem_binding_mismatch",
          "the auxiliary factor must reconstruct the direct request's exact "
          "problem, target order, configured arrival, and selection");
    }

    auto ordered_target_digest =
        mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
            seed.target_selection.ordered_targets);
    if (!inputs.instance.analysis_spec().context) {
      return audit_failure<void>(
          "c17.direct_factor_selection_missing",
          "the auxiliary factor requires the direct request's configured "
          "analysis selection");
    }
    auto selection_digest =
        mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
            inputs.instance.analysis_spec().context->selection);
    if (!ordered_target_digest) {
      return Result<void>::failure(ordered_target_digest.error());
    }
    if (!selection_digest) {
      return Result<void>::failure(selection_digest.error());
    }
    if (ordered_target_digest.value() !=
            seed.bindings.ordered_target_digest ||
        selection_digest.value() != seed.bindings.selection_digest ||
        selection_digest.value() !=
            artifact_bindings.analysis_selection_digest ||
        seed.bindings.direct_metric_decoder_domain.has_value()) {
      return audit_failure<void>(
          "c17.direct_factor_selection_binding_mismatch",
          "the auxiliary factor must retain exact target and selection "
          "digests and cannot acquire direct-decoder authority");
    }

    if (source.realized_metric_bindings.request_digest !=
            inputs.final_request_identity ||
        !equal_span(source.realized_metric_bindings.bindings,
                    inputs.realized_metric_bindings.bindings())) {
      return audit_failure<void>(
          "c17.direct_factor_realized_binding_mismatch",
          "the auxiliary factor must retain the exact realized bindings of "
          "the validated direct payload");
    }
    return validate_exact_state_schema(inputs, descriptor);
  }

  if (semantic_tag_v1(plug) != descriptor.core.semantic ||
      artifact_bindings.semantic != descriptor.core.semantic ||
      inputs.accepted_contract.semantic() != descriptor.core.semantic ||
      source.semantic != descriptor.core.semantic ||
      artifact_bindings.runtime_access != descriptor.core.runtime_access ||
      inputs.accepted_contract.runtime_access() !=
          descriptor.core.runtime_access ||
      source.runtime_access != descriptor.core.runtime_access ||
      artifact_bindings.payload_class != descriptor.core.payload_class ||
      inputs.accepted_contract.payload_class() !=
          descriptor.core.payload_class ||
      source.payload_class != descriptor.core.payload_class) {
    return audit_failure<void>(
        "c17.semantic_access_binding_mismatch",
        "plug, payload, artifact, accepted contract, descriptor, and access "
        "must retain one semantic/access/payload tuple");
  }
  if (descriptor.core != inputs.accepted_contract.descriptor_core() ||
      descriptor.core.provider != artifact_bindings.provider ||
      descriptor.core.provider != inputs.accepted_contract.provider() ||
      artifact_bindings.construction_method !=
          inputs.accepted_contract.construction_method() ||
      artifact_bindings.producer_mode !=
          inputs.accepted_contract.producer_mode()) {
    return audit_failure<void>(
        "c17.accepted_descriptor_binding_mismatch",
        "the runtime descriptor must be the exact C14/C15 accepted "
        "descriptor and provider construction tuple");
  }

  if (validated_contract_digest != inputs.accepted_contract.contract_digest() ||
      artifact_bindings.accepted_contract_digest !=
          inputs.accepted_contract.contract_digest() ||
      seed.bindings.accepted_contract_digest !=
          inputs.accepted_contract.contract_digest() ||
      artifact_bindings.requirements_digest !=
          inputs.accepted_contract.requirements_digest() ||
      seed.bindings.normalized_metric_requirements_digest !=
          inputs.accepted_contract.requirements_digest() ||
      artifact_bindings.arrival_capabilities_digest !=
          inputs.accepted_contract.arrival_capabilities_digest() ||
      artifact_bindings.preview_digest !=
          inputs.accepted_contract.preview_digest() ||
      artifact_bindings.parameter_digest !=
          inputs.accepted_contract.parameter_digest() ||
      artifact_bindings.budget_digest !=
          inputs.accepted_contract.budget_digest()) {
    return audit_failure<void>(
        "c17.accepted_contract_binding_mismatch",
        "the candidate must retain the exact accepted contract, metric, "
        "arrival-capability, parameter, preview, and budget identities");
  }
  if (!(structural_manifest ==
        inputs.accepted_contract.structural_manifest()) ||
      structural_manifest.canonical_digest() !=
          inputs.accepted_contract.structural_manifest().canonical_digest() ||
      structural_manifest.canonical_digest() !=
          artifact_bindings.structural_manifest_digest ||
      structural_manifest.canonical_digest() !=
          descriptor.core.metric_support_manifest_digest ||
      source.structural_manifest_echo.manifest_digest !=
          structural_manifest.canonical_digest()) {
    return audit_failure<void>(
        "c17.structural_manifest_binding_mismatch",
        "the V0 candidate must retain the exact validated structural "
        "manifest and its canonical digest");
  }

  if (inputs.build_identity.digest() !=
          artifact_bindings.build_identity_digest ||
      inputs.build_identity.digest() != source.build_identity_digest ||
      inputs.final_request_identity != artifact_bindings.request_digest ||
      inputs.final_request_identity != source.request_digest ||
      inputs.final_request_identity != seed.bindings.build_request_digest) {
    return audit_failure<void>(
        "c17.build_request_binding_mismatch",
        "the executable candidate must retain the validated build identity "
        "and final request identity");
  }

  if (source.framework_problem_view_digest !=
          artifact_bindings.framework_problem_view_digest ||
      source.framework_problem_view_digest !=
          seed.bindings.problem_view_digest.value()) {
    return audit_failure<void>(
        "c17.problem_view_binding_mismatch",
        "the portable payload and audited seed must identify one framework "
        "problem view");
  }

  auto problem = build_framework_problem_view_matching_arrival_projection(
      inputs.instance, inputs.configured_arrival, seed.target_selection,
      seed.bindings.problem_fingerprints.compiled_arrival);
  if (!problem) {
    return Result<void>::failure(problem.error());
  }
  if (problem.value().configured_arrival().capabilities() !=
      inputs.accepted_contract.arrival_capabilities()) {
    return audit_failure<void>(
        "c17.configured_arrival_capability_mismatch",
        "the provider-bound configured-arrival projection must expose "
        "exactly the capabilities accepted for the executable contract");
  }
  if (problem.value().fingerprints() != seed.bindings.problem_fingerprints ||
      problem.value().canonical_digest() != seed.bindings.problem_view_digest ||
      problem.value().target_selection() != seed.target_selection ||
      descriptor.core.deployed_targets !=
          seed.target_selection.ordered_targets ||
      source.ordered_deployed_targets !=
          seed.target_selection.ordered_targets) {
    return audit_failure<void>(
        "c17.resolved_problem_binding_mismatch",
        "resolved instance, configured arrival, target selection, descriptor, "
        "and payload must reconstruct the bound framework problem exactly");
  }

  auto ordered_target_digest =
      mwperf::artifact::detail::canonical_ordered_metric_targets_digest_v1(
          seed.target_selection.ordered_targets);
  if (!inputs.instance.analysis_spec().context) {
    return audit_failure<void>(
        "c17.missing_analysis_selection",
        "the resolved instance must retain its configured analysis "
        "selection");
  }
  auto selection_digest =
      mwperf::artifact::detail::canonical_analysis_selection_digest_v1(
          inputs.instance.analysis_spec().context->selection);
  if (!ordered_target_digest) {
    return Result<void>::failure(ordered_target_digest.error());
  }
  if (!selection_digest) {
    return Result<void>::failure(selection_digest.error());
  }
  if (ordered_target_digest.value() != seed.bindings.ordered_target_digest ||
      selection_digest.value() != seed.bindings.selection_digest ||
      selection_digest.value() !=
          artifact_bindings.analysis_selection_digest) {
    return audit_failure<void>(
        "c17.target_selection_binding_mismatch",
        "ordered deployed targets and the configured analysis selection have "
        "distinct canonical identities and both must match");
  }

  if (source.realized_metric_bindings.request_digest !=
          inputs.final_request_identity ||
      !equal_span(source.realized_metric_bindings.bindings,
                  inputs.realized_metric_bindings.bindings())) {
    return audit_failure<void>(
        "c17.realized_metric_binding_mismatch",
        "the sealed realized metric-role bindings must be exactly those "
        "validated with the portable payload");
  }

  return validate_exact_state_schema(inputs, descriptor);
}

[[nodiscard]] Result<void> validate_direct_metric_services(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const KernelAccess& access) {
  const auto* raw = std::get_if<RawDirectDecoderAccess>(&access);
  if (raw == nullptr) {
    if (inputs.direct_metric_services.has_value() ||
        inputs.framework_seed.bindings.direct_metric_decoder_domain
            .has_value()) {
      return audit_failure<void>(
          "c17.direct_metric_services_without_raw_access",
          "sealed direct-metric services are defined only for the audited "
          "raw direct decoder alternative");
    }
    return Result<void>::success();
  }

  if (!inputs.direct_metric_services.has_value() || !raw->has_operation() ||
      !inputs.framework_seed.bindings.direct_metric_decoder_domain
           .has_value()) {
    return audit_failure<void>(
        "c17.incomplete_direct_metric_seal",
        "raw direct access requires its owner-bound request encoder, decoder, "
        "result validator, typed request domain, and passing causal factor "
        "before V0 can pass");
  }

  const RawDirectDecoderDomainV1& raw_domain = raw->domain();
  const DirectMetricRequestDomainV1& sealed_domain =
      inputs.direct_metric_services->domain();
  const auto clauses = inputs.accepted_contract.requirements().clauses();
  if (clauses.size() != 1U ||
      sealed_domain.metric_domain != raw_domain.metric_domain ||
      sealed_domain.metric_domain !=
          *inputs.framework_seed.bindings.direct_metric_decoder_domain ||
      sealed_domain.normalized_metric_request_digest !=
          inputs.framework_seed.bindings
              .normalized_metric_requirements_digest ||
      sealed_domain.canonical_request_domain_digest !=
          raw_domain.canonical_request_domain_digest ||
      sealed_domain.ordered_targets != clauses.front().origin.ordered_targets ||
      sealed_domain.ordered_target_digest !=
          raw_domain.ordered_target_digest ||
      sealed_domain.ordered_target_digest !=
          inputs.framework_seed.bindings.ordered_target_digest ||
      sealed_domain.selection_digest != raw_domain.selection_digest ||
      sealed_domain.selection_digest !=
          inputs.framework_seed.bindings.selection_digest ||
      sealed_domain.selection_regime !=
          clauses.front().origin.selection_regime ||
      sealed_domain.metric_domain.exact_parameters !=
          clauses.front().origin.parameters ||
      clauses.front().origin.solver_regime !=
          MetricSolverRegimeV1::direct ||
      sealed_domain.result_codec != raw_domain.result_codec ||
      raw_domain.build_request_digest != inputs.final_request_identity ||
      raw_domain.build_request_digest !=
          inputs.framework_seed.bindings.build_request_digest ||
      raw_domain.target_selection_digest !=
          inputs.framework_seed.bindings.problem_fingerprints
              .target_selection ||
      raw_domain.configured_arrival_digest !=
          inputs.framework_seed.bindings.problem_fingerprints
              .compiled_arrival ||
      raw_domain.accepted_contract_digest !=
          inputs.accepted_contract.contract_digest()) {
    return audit_failure<void>(
        "c17.direct_metric_domain_binding_mismatch",
        "the sealed direct decoder must retain the exact C14 request, C15 "
        "build, target, selection, configured-arrival, and accepted-contract "
        "domain of the moved raw access");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<const DirectFactorWitnessV1*>
validate_direct_underlying_factor(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const KernelAccess& access) {
  if (!std::holds_alternative<RawDirectDecoderAccess>(access)) {
    return Result<const DirectFactorWitnessV1*>::success(nullptr);
  }
  if (!inputs.direct_metric_services.has_value()) {
    return audit_failure<const DirectFactorWitnessV1*>(
        "c17.direct_metric_factor_missing",
        "a raw direct decoder must bind one passing composite causal-factor "
        "witness");
  }

  const DirectFactorWitnessV1& factor =
      inputs.direct_metric_services->factor_witness();
  if (!factor.report().passed() || !factor.row_available() ||
      factor.runtime_access() == RuntimeAccessTagV1::direct_metric_decoder ||
      factor.causal_program_mode() ==
          ExactCausalProgramModeV1::bound_direct_decoder) {
    return audit_failure<const DirectFactorWitnessV1*>(
        "c17.direct_metric_factor_not_audited_row",
        "the direct decoder's factor witness must project a distinct passing "
        "V0 enumerable generative audit");
  }

  const AuditedFrameworkBindingsV1& direct_bindings =
      inputs.framework_seed.bindings;
  const AuditedFrameworkBindingsV1& factor_bindings =
      factor.framework_bindings();
  const auto direct_arrival =
      detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
  const V0WitnessBindingsV1& factor_report =
      factor.report().bindings();

  if (direct_bindings.problem_fingerprints !=
          factor_bindings.problem_fingerprints ||
      direct_bindings.problem_view_digest !=
          factor_bindings.problem_view_digest ||
      direct_bindings.exact_state_schema_digest !=
          factor_bindings.exact_state_schema_digest ||
      direct_bindings.reduced_state_schema_digest !=
          factor_bindings.reduced_state_schema_digest ||
      direct_bindings.accepted_contract_digest !=
          factor_bindings.accepted_contract_digest ||
      direct_bindings.normalized_metric_requirements_digest !=
          factor_bindings.normalized_metric_requirements_digest ||
      direct_bindings.ordered_target_digest !=
          factor_bindings.ordered_target_digest ||
      direct_bindings.selection_digest !=
          factor_bindings.selection_digest ||
      direct_bindings.build_request_digest !=
          factor_bindings.build_request_digest ||
      factor_bindings.direct_metric_decoder_domain.has_value() ||
      inputs.framework_seed.target_selection !=
          factor.target_selection() ||
      factor.deployed_targets() !=
          inputs.framework_seed.target_selection.ordered_targets ||
      inputs.exact_state_schema.ownership_schema_digest !=
          factor.ownership_schema_digest() ||
      inputs.exact_state_schema.exact_update_schema_digest !=
          factor.exact_update_schema_digest() ||
      !direct_arrival ||
      direct_arrival->binding != factor.configured_arrival_binding() ||
      factor_report.resolved_instance !=
          direct_bindings.problem_fingerprints.resolved_instance ||
      factor_report.descriptor != factor_bindings.descriptor_digest ||
      factor_report.access != factor_bindings.access_digest ||
      factor_report.ownership_schema !=
          inputs.exact_state_schema.ownership_schema_digest ||
      factor_report.exact_update_schema !=
          inputs.exact_state_schema.exact_update_schema_digest) {
    return audit_failure<const DirectFactorWitnessV1*>(
        "c17.direct_metric_factor_binding_mismatch",
        "the passing causal factor must retain the direct seal's exact "
        "problem, problem view, targets, selection, configured arrival, "
        "state schemas, ownership, and exact-update identities");
  }
  constexpr std::size_t obligation_count =
      static_cast<std::size_t>(V0ObligationV1::framework_unit_residence) +
      1U;
  std::array<bool, obligation_count> seen{};
  for (const V0WitnessEntryV1& witness : factor.report().entries()) {
    const std::size_t index =
        static_cast<std::size_t>(witness.obligation);
    if (index >= obligation_count || seen[index] || !witness.passed) {
      return audit_failure<const DirectFactorWitnessV1*>(
          "c17.direct_metric_factor_failed_obligation",
          "the bound causal factor must contain one passing entry for every "
          "V0 obligation and no duplicate obligation");
    }
    seen[index] = true;
  }
  if (std::ranges::any_of(seen, [](const bool present) { return !present; })) {
    return audit_failure<const DirectFactorWitnessV1*>(
        "c17.direct_metric_factor_incomplete_report",
        "the bound causal factor's V0 report omits an obligation scope");
  }
  return Result<const DirectFactorWitnessV1*>::success(&factor);
}

[[nodiscard]] Result<void> validate_program_capabilities(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const KernelAccess& access) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  const bool direct_plug =
      std::holds_alternative<DirectMetricDecoderPlugV1>(plug);
  const bool direct_access =
      std::holds_alternative<RawDirectDecoderAccess>(access);
  const bool direct_mode =
      program.mode == ExactCausalProgramModeV1::bound_direct_decoder;
  const bool absolute_event_clock =
      program.event_clock_semantics ==
      EventClockSemanticsV1::absolute_physical_slot;
  const bool finite_phase_clock_quotient =
      program.event_clock_semantics ==
      EventClockSemanticsV1::finite_phase_time_homogeneous_quotient;
  if (!absolute_event_clock && !finite_phase_clock_quotient) {
    return audit_failure<void>(
        "c17.invalid_event_clock_semantics",
        "the causal program selected an unknown event-clock semantics");
  }
  if (direct_mode != direct_plug || direct_mode != direct_access ||
      direct_mode !=
          (descriptor.core.semantic ==
           SemanticTagV1::direct_metric_decoder) ||
      direct_mode !=
          (descriptor.core.runtime_access ==
           RuntimeAccessTagV1::direct_metric_decoder)) {
    return audit_failure<void>(
        "c17.direct_causal_program_mode_mismatch",
        "bound-direct mode is valid exactly for the direct semantic and its "
        "raw decoder access");
  }
  if (direct_mode) {
    if (causal_operations_v1(plug) != nullptr ||
        !program.reachable_audit_states.empty() ||
        program.maximum_residence_slots.has_value() ||
        program.finite_event_domain_states.has_value() ||
        program.event_entry_domain_is_exact_state_domain ||
        !absolute_event_clock) {
      return audit_failure<void>(
          "c17.direct_candidate_contains_causal_program",
          "a direct-only candidate binds an already-audited factor and owns "
          "no candidate row, closure operation, residence bound, event "
          "domain, or reachable audit state");
    }
    return Result<void>::success();
  }
  if (program.conditional_row_tolerance != physical_pmf_tolerance()) {
    return audit_failure<void>(
        "c17.nonphysical_conditional_row_tolerance",
        "every C17 conditional-law normalization must use C02's exact "
        "physical PMF tolerance");
  }
  if (program.maximum_residence_slots.has_value() &&
      *program.maximum_residence_slots == 0U) {
    return audit_failure<void>(
        "c17.nonpositive_maximum_residence",
        "a declared finite residence-support bound must be positive");
  }
  if (program.finite_event_domain_states.has_value()) {
    const std::vector<ReducedStateV1>& domain =
        *program.finite_event_domain_states;
    if (domain.empty()) {
      return audit_failure<void>(
          "c17.empty_finite_event_domain",
          "an explicitly finite event-entry domain must be nonempty");
    }
    for (std::size_t index = 0U; index < domain.size(); ++index) {
      if (!(domain[index].codec ==
            inputs.exact_state_schema.reduced_state_codec)) {
        return audit_failure<void>(
            "c17.finite_event_domain_codec_mismatch",
            "every finite event-domain member must use the sealed exact "
            "reduced-state codec");
      }
      auto valid = inputs.exact_state_schema.validate_domain(domain[index]);
      if (!valid) {
        return Result<void>::failure(valid.error());
      }
      if (std::ranges::find(domain.begin(), domain.begin() + index,
                            domain[index]) != domain.begin() + index) {
        return audit_failure<void>(
            "c17.duplicate_finite_event_domain_state",
            "the explicitly finite event-entry domain must be duplicate-free");
      }
    }
  }
  if (program.finite_event_domain_states.has_value() &&
      program.event_entry_domain_is_exact_state_domain) {
    return audit_failure<void>(
        "c17.ambiguous_event_entry_domain",
        "an event-entry domain must be either its explicit finite ordered "
        "support or the sealed exact-state domain, not both");
  }
  if (const auto* residence =
          std::get_if<ProceduralResidenceGeneratorAccess>(&access);
      residence != nullptr &&
      program.maximum_residence_slots !=
          residence->shape().maximum_residence_slots) {
    return audit_failure<void>(
        "c17.residence_bound_binding_mismatch",
        "the causal program and procedural raw-access shape must declare the "
        "same finite residence bound, including joint absence");
  }

  const bool row = program_has_row(plug, inputs);
  const bool slot = program_has_slot(plug, inputs);
  const RuntimeAccessTagV1 tag = runtime_access_tag_v1(access);

  if (program.finite_event_domain_states.has_value() &&
      !finite_phase_clock_quotient) {
    return audit_failure<void>(
        "c17.finite_event_domain_requires_clock_quotient",
        "an exact reduced state retains the monotonically advancing physical "
        "slot; a finite event domain therefore requires the explicit audited "
        "finite-phase time-homogeneous quotient");
  }
  if (finite_phase_clock_quotient) {
    const auto law =
        detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
    const ArrivalCapabilities& capabilities =
        inputs.accepted_contract.arrival_capabilities();
    const bool enumerable_access =
        tag == RuntimeAccessTagV1::finite_enumerated_row ||
        tag == RuntimeAccessTagV1::sparse_row;
    const bool exact_procedural_residence =
        tag == RuntimeAccessTagV1::procedural_residence_generator && row;
    const auto* finite_tables =
        std::get_if<PortableFiniteLawTablesV1>(
            &portable_source_v1(plug).value());
    const bool portable_romr_word_table =
        finite_tables != nullptr &&
        std::holds_alternative<RomrResidenceWordTableV1>(
            finite_tables->normalized_record.table);
    // In the generic quotient lane C17/C20 invoke every provider operation
    // through their clock-erased callback ABI.  A portable ROMR word table is
    // one exact authority.  A procedural residence recipe is also exact on
    // this narrowly audited lane only when program_has_row() has proved exact
    // C-minus, configured-arrival, and C-plus enumerators.  In particular a
    // normalized sampler, or a procedural recipe lacking any one exact
    // enumerator, cannot acquire the quotient merely from a finite cutoff.
    const bool generic_romr =
        program.mode == ExactCausalProgramModeV1::generic_bound_operations &&
        descriptor.core.semantic ==
            SemanticTagV1::romr_residence_word_law &&
        ((enumerable_access && portable_romr_word_table) ||
         exact_procedural_residence);
    const bool unit_romr = closed_scalar_response_mode_v1(program.mode);
    const bool accepted_c18_scalar_route = std::ranges::any_of(
        inputs.accepted_contract.metric_contracts(),
        [&](const ResolvedMetricContractV1& contract) {
          return contract.semantic == descriptor.core.semantic &&
                 contract.runtime_access ==
                     descriptor.core.runtime_access &&
                 contract.target_coupling ==
                     descriptor.core.target_coupling &&
                 contract.backend_route ==
                     BackendRouteKindV1::framework_scalar_identity;
        });
    // C18's finite stationary matrix is a separate one-step quotient lane.
    // It has no residence/event domain: C17 executes every provider callback
    // on the slot-zero representative, retains the physical one-step edge,
    // and C18 later verifies finite closure while erasing only its endpoint
    // clock.  Keep this authority on the stationary marked-edge semantic and
    // an already accepted finite/sparse scalar-identity route.
    const bool c18_stationary_row =
        program.mode == ExactCausalProgramModeV1::generic_bound_operations &&
        descriptor.core.semantic == SemanticTagV1::stationary_marked_edge &&
        enumerable_access && accepted_c18_scalar_route &&
        !descriptor.event_contract.has_value() &&
        !program.finite_event_domain_states.has_value() &&
        !program.maximum_residence_slots.has_value() &&
        !program.event_entry_domain_is_exact_state_domain;
    const bool finite_descriptors =
        law && law->builder_view.finite_phase().has_value() &&
        law->builder_view.transition_rows().has_value() &&
        law->builder_view.finite_phase()->row_clock_semantics ==
            ArrivalRowClockSemanticsV1::finite_phase_time_homogeneous &&
        capabilities.finite_enumerated_predictive_phase ==
            CapabilityAvailability::available &&
        capabilities.finite_enumerated_transition_row ==
            CapabilityAvailability::available;
    const bool descriptor_retains_finite_phase =
        descriptor.core.phase.arrival_composition ==
            ConfiguredArrivalCompositionV1::
                finite_enumerated_predictive_phase &&
        descriptor.core.phase.retains_configured_predictive_phase;
    // Typed edge decoders remain admissible only for explicitly declared
    // residence-local/resettable fields.  Their callback ABI receives the
    // audited postarrival/completed-edge value and has no physical-slot
    // argument.  Requiring every declared dependency to be local prevents a
    // generic state decoder from smuggling the absolute clock into the finite
    // quotient while retaining legitimate local-age marks.
    const bool typed_edge_marks_are_clock_blind =
        std::ranges::all_of(
            descriptor.marks, [&](const RuntimeMarkDescriptorV1& mark) {
              if (mark.decoder_source !=
                      MarkDecoderSourceV1::postarrival_state &&
                  mark.decoder_source !=
                      MarkDecoderSourceV1::completed_edge) {
                return true;
              }
              const bool expected_input =
                  descriptor.event_contract.has_value() &&
                  ((mark.decoder_source ==
                        MarkDecoderSourceV1::postarrival_state &&
                    mark.decoder_input_codec ==
                        descriptor.event_contract->continuation_space) ||
                   (mark.decoder_source ==
                        MarkDecoderSourceV1::completed_edge &&
                    mark.decoder_input_codec == descriptor.event_contract
                                                    ->completed_edge_projection));
              return expected_input && !mark.field_dependencies.empty() &&
                     std::ranges::all_of(
                         mark.field_dependencies,
                         [&](const RuntimeFieldIdV1& field) {
                           return std::ranges::find(
                                      descriptor.event_contract
                                          ->residence_local_reset_fields,
                                      field) !=
                                  descriptor.event_contract
                                      ->residence_local_reset_fields.end();
                         });
            });
    const bool event_quotient =
        program.finite_event_domain_states.has_value() &&
        !program.event_entry_domain_is_exact_state_domain &&
        program.maximum_residence_slots.has_value() && row &&
        (generic_romr || unit_romr) && finite_descriptors &&
        descriptor_retains_finite_phase &&
        law->runtime.enumerate_time_homogeneous &&
        typed_edge_marks_are_clock_blind;
    const bool stationary_quotient =
        c18_stationary_row && row && finite_descriptors &&
        law->runtime.enumerate_time_homogeneous &&
        law->builder_view.stationary_phase_law().has_value() &&
        capabilities.stationary_phase_law !=
            StationaryPhaseLawStatus::unavailable;
    if (!event_quotient && !stationary_quotient) {
      return audit_failure<void>(
          c18_stationary_row
              ? "c17.unaudited_stationary_clock_quotient"
              : "c17.unaudited_finite_event_clock_quotient",
          c18_stationary_row
              ? "the C18 stationary clock quotient requires its accepted "
                "finite/sparse marked-edge scalar route, C09 finite "
                "phase/transition descriptors, a proper stationary phase "
                "law, and a slot-free exact arrival-row operation"
              : "the event-clock quotient requires a finite explicit "
                "domain, a positive finite residence bound, an exact "
                "row-only ROMR route, either a portable finite ROMR word "
                "table or an exact procedural residence recipe, with no "
                "clock-bearing typed edge decoder, C09 finite "
                "phase/transition descriptors, an explicitly retained "
                "finite predictive phase, and a slot-free exact "
                "arrival-row operation");
    }

    if (event_quotient) {
      const auto& finite_phase = *law->builder_view.finite_phase();
      std::vector<ExactReducedCoordinatesV1> decoded_domain;
      decoded_domain.reserve(program.finite_event_domain_states->size());
      for (const ReducedStateV1& state :
           *program.finite_event_domain_states) {
        auto decoded = inputs.exact_state_schema.decode(state);
        if (!decoded) {
          return Result<void>::failure(decoded.error());
        }
        const auto phase = detail::ArrivalCoreAccess::phase_core(
            decoded.value().arrival_phase);
        const bool phase_is_enumerated =
            phase && phase->family == law->binding.family &&
            phase->binding == law->binding &&
            std::ranges::find(finite_phase.canonical_states,
                              phase->canonical_state) !=
                finite_phase.canonical_states.end();
        if (!phase_is_enumerated ||
            !(decoded.value().boundary_index == BigNat{0U}) ||
            !(phase->next_authored_slot == BigNat{0U})) {
          return audit_failure<void>(
              "c17.invalid_finite_event_clock_representative",
              "every finite quotient-domain state must use authored slot zero "
              "and one canonical phase from the bound C09 finite phase domain");
        }
        const auto same_quotient_coordinates =
            [](const ExactReducedCoordinatesV1& left,
               const ExactReducedCoordinatesV1& right) {
              const auto left_phase =
                  detail::ArrivalCoreAccess::phase_core(left.arrival_phase);
              const auto right_phase =
                  detail::ArrivalCoreAccess::phase_core(right.arrival_phase);
              return left_phase && right_phase &&
                     left.backlog == right.backlog &&
                     left_phase->family == right_phase->family &&
                     left_phase->canonical_state ==
                         right_phase->canonical_state &&
                     left.resources == right.resources &&
                     left.margins == right.margins &&
                     left.controller == right.controller &&
                     left.unresolved_fields == right.unresolved_fields;
            };
        if (std::ranges::any_of(
                decoded_domain,
                [&](const ExactReducedCoordinatesV1& prior) {
                  return same_quotient_coordinates(prior, decoded.value());
                })) {
          return audit_failure<void>(
              "c17.duplicate_finite_event_clock_class",
              "the finite event domain contains two representatives of the "
              "same exact non-clock coordinate class");
        }
        decoded_domain.push_back(std::move(decoded).value());
      }
    }
  }
  if ((tag == RuntimeAccessTagV1::finite_enumerated_row ||
       tag == RuntimeAccessTagV1::sparse_row) &&
      !row) {
    return audit_failure<void>(
        "c17.missing_enumerable_causal_factor",
        "finite and sparse raw access require exact companions on the active "
        "C16 C-minus/C-plus operations and C09's exact transition row before "
        "an audited row view can be issued");
  }
  if ((tag == RuntimeAccessTagV1::normalized_conditional_sampler ||
       tag == RuntimeAccessTagV1::procedural_residence_generator) &&
      !slot) {
    return audit_failure<void>(
        "c17.missing_realized_causal_factor",
        "sampler and procedural access require active C16 C-minus/C-plus "
        "operations and an actual C09 enumerator or proposer for a complete "
        "five-stage slot route");
  }
  if (!row && !slot) {
    return audit_failure<void>(
        "c17.missing_v0_causal_backend",
        "V0 requires at least one complete enumerable or realized causal "
        "factorization; a raw decoder alone is not a queue law");
  }

  const bool scalar_plug =
      std::holds_alternative<ScalarBacklogResponsePlugV1>(plug);
  if (closed_scalar_response_mode_v1(program.mode) != scalar_plug) {
    if (program.mode == ExactCausalProgramModeV1::
                            closed_finite_prefix_constant_tail_scalar) {
      return audit_failure<void>(
          "c17.causal_program_mode_mismatch",
          "only the validated scalar-backlog-response plug may select the "
          "closed finite-prefix/constant-tail causal adapter");
    }
    return audit_failure<void>(
        "c17.causal_program_mode_mismatch",
        "only the validated scalar-backlog-response plug may select the "
        "closed three-bin causal adapter");
  }
  if (closed_scalar_response_mode_v1(program.mode) &&
      causal_operations_v1(plug) != nullptr) {
    if (program.mode == ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return audit_failure<void>(
          "c17.three_bin_external_service_path",
          "the closed three-bin adapter owns its service/action/identity "
          "closures and cannot invoke a plug callback or optimizer path");
    }
    return audit_failure<void>(
        "c17.finite_prefix_constant_tail_external_service_path",
        "the closed finite-prefix/constant-tail adapter owns its "
        "service/action/identity closures and cannot invoke a plug callback "
        "or optimizer path");
  }

  (void)descriptor;
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_three_bin_adapter(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const KernelAccess& access) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  if (program.mode != ExactCausalProgramModeV1::closed_three_bin_scalar) {
    return Result<void>::success();
  }

  const auto* scalar = std::get_if<ScalarBacklogResponsePlugV1>(&plug);
  const auto* family =
      std::get_if<FiniteParameterAnalyticFamilyAccess>(&access);
  if (scalar == nullptr || family == nullptr ||
      descriptor.core.semantic != SemanticTagV1::scalar_backlog_response ||
      descriptor.core.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      descriptor.core.target_coupling != TargetCouplingV1::scalar_target ||
      descriptor.core.deployed_targets.size() != 1U ||
      descriptor.core.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      descriptor.core.tail.kind !=
          TailRepresentationKindV1::constant_response ||
      !descriptor.core.tail.boundary.has_value() ||
      descriptor.core.tail.boundary->value() != BigInt{3}) {
    return audit_failure<void>(
        "c17.invalid_three_bin_contract",
        "the canonical adapter requires the singleton, phase-free, "
        "constant-from-backlog-three scalar response contract");
  }

  const auto* response = std::get_if<PortableThreeBinScalarResponseV1>(
      &portable_source_v1(plug).value());
  if (response == nullptr ||
      response->context.ordered_deployed_targets.size() != 1U ||
      response->deployed_target != descriptor.core.deployed_targets.front() ||
      response->context.ordered_deployed_targets.front() !=
          response->deployed_target ||
      response->selected_product !=
          response->normalized_record.deployed_response_product_id ||
      response->normalized_record.deployed_target !=
          response->deployed_target ||
      response->normalized_record.configured_arrival_binding !=
          response->normalized_record.raw_response.configured_arrival_binding) {
    return audit_failure<void>(
        "c17.three_bin_final_product_binding_mismatch",
        "the adapter must consume exactly one artifact-designated final "
        "response product for the requested singleton target and configured "
        "arrival");
  }

  const ExactRational zero = ExactRational::zero();
  const ExactRational one = ExactRational::one();
  if (std::ranges::any_of(response->coefficients,
                          [&](const ExactRational& coefficient) {
                            return coefficient < zero || coefficient > one;
                          })) {
    return audit_failure<void>(
        "c17.three_bin_coefficient_out_of_range",
        "each final s1, s2, and constant-tail coefficient must be an exact "
        "canonical probability");
  }

  const CodecIdentityV1 expected_parameter_schema{
      std::string(kThreeBinResponseParameterSchemaIdV1), 1U};
  const CodecIdentityV1 expected_response_codec{
      std::string(kThreeBinServiceResponseCodecIdV1), 1U};
  if (family->family().family_id != kThreeBinResponseFamilyIdV1 ||
      family->family().family_version != 1U ||
      family->family().parameter_schema != expected_parameter_schema ||
      family->shape().response_codec != expected_response_codec) {
    return audit_failure<void>(
        "c17.three_bin_family_identity_mismatch",
        "the closed adapter requires C16's fixed three-bin analytic-family "
        "and final response codec identities");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_finite_prefix_constant_tail_adapter(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const KernelAccess& access) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  if (program.mode != ExactCausalProgramModeV1::
                          closed_finite_prefix_constant_tail_scalar) {
    return Result<void>::success();
  }

  const auto* scalar = std::get_if<ScalarBacklogResponsePlugV1>(&plug);
  const auto* family =
      std::get_if<FiniteParameterAnalyticFamilyAccess>(&access);
  const auto* response =
      scalar == nullptr
          ? nullptr
          : std::get_if<PortableFinitePrefixConstantTailResponseV1>(
                &portable_source_v1(plug).value());
  if (scalar == nullptr || family == nullptr || response == nullptr ||
      descriptor.core.semantic != SemanticTagV1::scalar_backlog_response ||
      descriptor.core.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      descriptor.core.target_coupling != TargetCouplingV1::scalar_target ||
      descriptor.core.deployed_targets.size() != 1U ||
      descriptor.core.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      descriptor.core.tail.kind !=
          TailRepresentationKindV1::constant_response ||
      !descriptor.core.tail.boundary.has_value()) {
    return audit_failure<void>(
        "c17.invalid_finite_prefix_constant_tail_contract",
        "the canonical adapter requires a singleton, phase-free, "
        "finite-prefix/constant-tail scalar response contract");
  }

  auto cutoff = checked_index(response->response_cutoff, 6U);
  const auto& normalized = response->normalized_record;
  const auto& raw = normalized.raw_response;
  const BigNat expected_tail = response->response_cutoff + BigNat{1U};
  if (!cutoff || cutoff.value() < 2U || cutoff.value() > 5U ||
      response->context.payload_class.tag !=
          PayloadClassTagV1::finite_prefix_constant_tail_response_v1 ||
      response->context.payload_class.version != 1U ||
      response->context.ordered_deployed_targets.size() != 1U ||
      response->deployed_target != descriptor.core.deployed_targets.front() ||
      response->context.ordered_deployed_targets.front() !=
          response->deployed_target ||
      response->selected_product != normalized.deployed_response_product_id ||
      response->selected_product != raw.product_id ||
      normalized.deployed_target != response->deployed_target ||
      raw.deployed_target != response->deployed_target ||
      normalized.response_cutoff != response->response_cutoff ||
      raw.response_cutoff != response->response_cutoff ||
      response->constant_tail_from != expected_tail ||
      *descriptor.core.tail.boundary != expected_tail ||
      normalized.configured_arrival_binding !=
          raw.configured_arrival_binding ||
      response->service_by_level.size() != cutoff.value() + 1U ||
      raw.identifications.size() != cutoff.value() + 2U ||
      response->service_by_level.empty() ||
      !response->service_by_level.front().is_zero()) {
    return audit_failure<void>(
        "c17.finite_prefix_constant_tail_final_product_binding_mismatch",
        "the adapter must consume exactly one complete native product whose "
        "target, K, ordered prefix, tail boundary, and configured arrival "
        "match the audited descriptor");
  }

  const ExactRational zero = ExactRational::zero();
  const ExactRational one = ExactRational::one();
  const auto in_range = [&](const ExactRational& coefficient) {
    return coefficient >= zero && coefficient <= one;
  };
  if (!std::ranges::all_of(response->service_by_level, in_range) ||
      !in_range(response->constant_tail_service)) {
    return audit_failure<void>(
        "c17.finite_prefix_constant_tail_coefficient_out_of_range",
        "every final prefix and constant-tail coefficient must be an exact "
        "canonical probability");
  }

  for (std::size_t level = 0U; level <= cutoff.value(); ++level) {
    const auto& identification = raw.identifications[level];
    const auto expected_kind =
        level == 0U
            ? FinitePrefixResponseCoordinateKindV1::structural_level_zero
            : FinitePrefixResponseCoordinateKindV1::exact_level;
    if (identification.coordinate.kind != expected_kind ||
        identification.coordinate.level_or_tail_from != BigNat{level} ||
        identification.raw_point.kind() !=
            PortableScientificScalarKind::rational ||
        identification.raw_point.rational_value() !=
            response->service_by_level[level]) {
      return audit_failure<void>(
          "c17.finite_prefix_constant_tail_coordinate_mismatch",
          "the normalized raw product must retain structural level zero and "
          "every consecutive exact level through K");
    }
  }
  const auto& tail = raw.identifications.back();
  if (tail.coordinate.kind !=
          FinitePrefixResponseCoordinateKindV1::constant_tail ||
      tail.coordinate.level_or_tail_from != expected_tail ||
      tail.raw_point.kind() != PortableScientificScalarKind::rational ||
      tail.raw_point.rational_value() != response->constant_tail_service) {
    return audit_failure<void>(
        "c17.finite_prefix_constant_tail_coordinate_mismatch",
        "the normalized raw product must retain exactly one constant tail "
        "beginning at K+1");
  }

  const CodecIdentityV1 expected_parameter_schema{
      std::string(kFinitePrefixConstantTailResponseParameterSchemaIdV1), 1U};
  const CodecIdentityV1 expected_response_codec{
      std::string(kFinitePrefixConstantTailServiceResponseCodecIdV1), 1U};
  if (family->family().family_id !=
          kFinitePrefixConstantTailResponseFamilyIdV1 ||
      family->family().family_version != 1U ||
      family->family().parameter_schema != expected_parameter_schema ||
      family->shape().response_codec != expected_response_codec) {
    return audit_failure<void>(
        "c17.finite_prefix_constant_tail_family_identity_mismatch",
        "the closed adapter requires C16's finite-prefix/constant-tail "
        "analytic-family and response-codec identities");
  }
  return Result<void>::success();
}

[[nodiscard]] std::optional<CausalStageV1> declared_stage(
    const MetricRevealStageV1 stage) {
  switch (stage) {
    case MetricRevealStageV1::predecision:
      return CausalStageV1::c_minus;
    case MetricRevealStageV1::decision:
      return CausalStageV1::resolver;
    case MetricRevealStageV1::arrival:
      return CausalStageV1::arrival;
    case MetricRevealStageV1::postarrival:
      return CausalStageV1::c_plus;
    case MetricRevealStageV1::completed_edge:
      return CausalStageV1::psi;
    case MetricRevealStageV1::entrance_label:
      return std::nullopt;
  }
  return std::nullopt;
}

// Only sources for which the C17 composer carries the actual decoded value
// are admitted.  A descriptor declaration is not a substitute for a decoder
// applied to the generated branch.
[[nodiscard]] bool framework_three_bin_mark(
    const PlugDescriptor& descriptor,
    const RuntimeMarkDescriptorV1& mark) {
  return descriptor.core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         descriptor.core.runtime_access ==
             RuntimeAccessTagV1::finite_parameter_analytic_family &&
         mark.c14_mark.kind == MetricMarkKindV1::actual_departure &&
         mark.decoder_source == MarkDecoderSourceV1::decision_schedule &&
         mark.decoder_input_codec ==
             CodecIdentityV1{"schedule.realization", 1U} &&
         mark.c14_mark.codec == CodecIdentityV1{"service.bit", 1U};
}

[[nodiscard]] std::optional<CausalStageV1> generated_mark_stage(
    const MarkDecoderSourceV1 source, const bool framework_decoder,
    const bool postarrival_decoder, const bool completed_edge_decoder) {
  switch (source) {
    case MarkDecoderSourceV1::predecision_state:
      return framework_decoder ? std::optional{CausalStageV1::c_minus}
                               : std::nullopt;
    case MarkDecoderSourceV1::c_minus_joint_output:
      return CausalStageV1::c_minus;
    case MarkDecoderSourceV1::decision_schedule:
      return framework_decoder ? std::optional{CausalStageV1::resolver}
                               : std::nullopt;
    case MarkDecoderSourceV1::configured_arrival:
      return framework_decoder ? std::optional{CausalStageV1::arrival}
                               : std::nullopt;
    case MarkDecoderSourceV1::c_plus_joint_output:
      return CausalStageV1::c_plus;
    case MarkDecoderSourceV1::postarrival_state:
      return postarrival_decoder ? std::optional{CausalStageV1::c_plus}
                                 : std::nullopt;
    case MarkDecoderSourceV1::completed_edge:
      return completed_edge_decoder ? std::optional{CausalStageV1::psi}
                                    : std::nullopt;
    case MarkDecoderSourceV1::entrance_realization:
      return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] Result<void> validate_mark_carriers(
    const PlugDescriptor& descriptor,
    const ExactReducedStateSchemaV1& state_schema) {
  const auto scalar_source = [](const MarkDecoderSourceV1 source) {
    return source == MarkDecoderSourceV1::predecision_state ||
           source == MarkDecoderSourceV1::decision_schedule ||
           source == MarkDecoderSourceV1::configured_arrival ||
           source == MarkDecoderSourceV1::entrance_realization;
  };
  for (const DeterministicRuntimeMarkDecoderOperationV1& decoder :
       state_schema.framework_mark_decoders) {
    const auto matching = std::ranges::find_if(
        descriptor.marks, [&](const RuntimeMarkDescriptorV1& mark) {
          const DeterministicRuntimeMarkDecoderSchemaV1& schema =
              decoder.schema();
          return mark.id == schema.mark &&
                 mark.decoder_id == schema.decoder_id &&
                 mark.decoder_source == schema.source &&
                 mark.decoder_input_codec == schema.input_codec &&
                 mark.c14_mark.codec == schema.output_codec;
        });
    if (!scalar_source(decoder.schema().source) ||
        !decoder.has_operation() || matching == descriptor.marks.end() ||
        framework_three_bin_mark(descriptor, *matching)) {
      return audit_failure<void>(
          "c17.unbound_framework_mark_decoder",
          "every sealed framework decoder must exactly match one "
          "framework-owned descriptor source and its codecs");
    }
  }
  const auto expected_typed_schemas =
      [&](const MarkDecoderSourceV1 source) {
        std::vector<DeterministicRuntimeMarkDecoderSchemaV1> expected;
        for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
          if (mark.decoder_source == source) {
            expected.push_back(DeterministicRuntimeMarkDecoderSchemaV1{
                mark.decoder_id, mark.id, mark.decoder_source,
                mark.decoder_input_codec, mark.c14_mark.codec});
          }
        }
        return expected;
      };
  const auto expected_postarrival =
      expected_typed_schemas(MarkDecoderSourceV1::postarrival_state);
  const auto expected_completed =
      expected_typed_schemas(MarkDecoderSourceV1::completed_edge);
  const bool postarrival_decoder = static_cast<bool>(
      state_schema.postarrival_mark_decoder.decode);
  const bool completed_edge_decoder = static_cast<bool>(
      state_schema.completed_edge_mark_decoder.decode);
  if (state_schema.postarrival_mark_decoder.ordered_mark_schemas !=
          expected_postarrival ||
      state_schema.completed_edge_mark_decoder.ordered_mark_schemas !=
          expected_completed ||
      postarrival_decoder != !expected_postarrival.empty() ||
      completed_edge_decoder != !expected_completed.empty()) {
    return audit_failure<void>(
        "c17.typed_framework_mark_decoder_schema_mismatch",
        "the postarrival and completed-edge typed decoders must each bind "
        "the exact ordered decoder IDs, marks, sources, and input/output "
        "codecs declared for that source");
  }
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    const std::size_t matching_decoders = static_cast<std::size_t>(
        std::ranges::count_if(
            state_schema.framework_mark_decoders,
            [&](const DeterministicRuntimeMarkDecoderOperationV1& decoder) {
              const DeterministicRuntimeMarkDecoderSchemaV1& schema =
                  decoder.schema();
              return mark.id == schema.mark &&
                     mark.decoder_id == schema.decoder_id &&
                     mark.decoder_source == schema.source &&
                     mark.decoder_input_codec == schema.input_codec &&
                     mark.c14_mark.codec == schema.output_codec &&
                     decoder.has_operation();
            }));
    const bool framework_owned = framework_three_bin_mark(descriptor, mark);
    const bool bound_decoder = matching_decoders == 1U;
    if ((scalar_source(mark.decoder_source) && !framework_owned &&
         !bound_decoder) ||
        (framework_owned && matching_decoders != 0U) ||
        (!scalar_source(mark.decoder_source) && matching_decoders != 0U)) {
      return audit_failure<void>(
          "c17.requested_mark_decoder_binding_mismatch",
          "a framework-owned scalar-source mark requires exactly one sealed "
          "decoder, except for the fixed three-bin service-bit readout");
    }
    if (mark.decoder_source ==
        MarkDecoderSourceV1::entrance_realization) {
      if (!descriptor.event_contract.has_value() || !bound_decoder ||
          mark.c14_mark.reveal_stage !=
              MetricRevealStageV1::entrance_label) {
        return audit_failure<void>(
            "c17.entrance_mark_decoder_binding_mismatch",
            "an entrance mark requires one sealed entry decoder and the "
            "audited temporal entrance space");
      }
      continue;
    }
    const std::optional<CausalStageV1> generated =
        generated_mark_stage(mark.decoder_source,
                             bound_decoder || framework_owned,
                             postarrival_decoder,
                             completed_edge_decoder);
    const std::optional<CausalStageV1> declared =
        declared_stage(mark.c14_mark.reveal_stage);
    if (!generated.has_value()) {
      return audit_failure<void>(
          "c17.unsupported_requested_mark_source",
          "V0 cannot claim a requested mark whose declared decoder source "
          "is absent from the five-stage composer");
    }
    if (!declared.has_value() ||
        static_cast<std::uint8_t>(*generated) >
            static_cast<std::uint8_t>(*declared)) {
      return audit_failure<void>(
          "c17.requested_mark_reveal_mismatch",
          "the realized decoder source must occur no later than the C14 "
          "declared reveal stage");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_audited_row(
    const MarkedKernelRow& row, const ReducedStateV1& source,
    const PlugDescriptor& descriptor,
    const ExactReducedStateSchemaV1& state_schema,
    const ResolvedInstance& instance, const bool closed_three_bin) {
  if (row.atoms().empty() ||
      row.exact_total_mass() != ExactRational::one()) {
    return audit_failure<void>(
        "c17.nonunit_composed_audit_row",
        "an inspected composed row must be nonempty and have "
        "exact total mass one");
  }

  ExactRational sum = ExactRational::zero();
  for (const MarkedKernelRowAtomV1& atom : row.atoms()) {
    if (atom.exact_mass < ExactRational::zero() ||
        (atom.structural_support &&
         atom.exact_mass == ExactRational::zero()) ||
        atom.edge.pre_state() != source ||
        atom.edge.stage_trace() != kCausalStageOrderV1) {
      return audit_failure<void>(
          "c17.invalid_composed_audit_atom",
          "every audited atom must retain nonnegative exact mass, claimed "
          "support, its source state, and the five-stage trace");
    }
    sum = sum + atom.exact_mass;

    auto successor_domain =
        state_schema.validate_domain(atom.edge.successor_state());
    if (!successor_domain) {
      return Result<void>::failure(successor_domain.error());
    }
    auto decoded = state_schema.decode(atom.edge.pre_state());
    if (!decoded) {
      return Result<void>::failure(decoded.error());
    }
    const ResolvedAction& action = atom.edge.action();
    auto action_math = detail::validate_resolved_action_math(
        instance, decoded.value().backlog, action);
    if (!action_math) {
      return Result<void>::failure(action_math.error());
    }
    if (!closed_three_bin &&
        (!action.evidence.common_feasible_schedule ||
         action.evidence.resolution_kind !=
             ActionResolutionKindV1::emitted_schedule_face ||
         !action.evidence.emitted_face.has_value())) {
      return audit_failure<void>(
          "c17.missing_common_schedule_evidence",
          "every generic resolved action must retain the exact emitted-face "
          "maximum and configured common schedule tie evidence");
    }
    if (!closed_three_bin) {
      const TargetBacklogV1& backlog = decoded.value().backlog;
      const EmittedScheduleFaceDecisionV1& emitted =
          *action.evidence.emitted_face;
      if (emitted.ordered_target_faces.size() != backlog.size()) {
        return audit_failure<void>(
            "c17.emitted_face_target_evidence_mismatch",
            "the emitted action must retain one exact face comparison for "
            "each deployed target in reduced-state order");
      }
      for (std::size_t target = 0U; target < backlog.size(); ++target) {
        const EmittedTargetFaceEvidenceV1& evidence =
            emitted.ordered_target_faces[target];
        auto target_value = ExactRational::make(
            backlog.value_at_target_ordinal(target).value(), BigInt{1});
        if (!target_value) {
          return Result<void>::failure(target_value.error());
        }
        const ExactRational expected_margin =
            target_value.value() + evidence.forced_in_residual_max -
            evidence.forced_out_residual_max;
        AlgebraicTargetClass expected_class = AlgebraicTargetClass::tie;
        if (expected_margin < ExactRational::zero()) {
          expected_class = AlgebraicTargetClass::forced_out;
        } else if (expected_margin > ExactRational::zero()) {
          expected_class = AlgebraicTargetClass::forced_in;
        }
        if (evidence.target !=
                backlog.target_at_target_ordinal(target) ||
            !(evidence.algebraic_margin == expected_margin) ||
            evidence.exact_class != expected_class ||
            evidence.target_eligible !=
                !backlog.value_at_target_ordinal(target).is_zero()) {
          return audit_failure<void>(
              "c17.emitted_face_target_evidence_mismatch",
              "each retained target face must satisfy the exact signed "
              "margin and empty-queue eligibility equations");
        }
      }
      if ((backlog.size() == 1U &&
           action.evidence.exact_target_class !=
               emitted.ordered_target_faces.front().exact_class) ||
          (backlog.size() != 1U &&
           action.evidence.exact_target_class.has_value())) {
        return audit_failure<void>(
            "c17.emitted_face_target_class_mismatch",
            "the optional scalar target class must be exactly the singleton "
            "face class and absent for a coupled target face");
      }
    }
    if (closed_three_bin &&
        (action.evidence.common_feasible_schedule ||
         action.evidence.emitted_face.has_value() ||
         !action.evidence.exact_target_class.has_value() ||
         (action.evidence.resolution_kind !=
              ActionResolutionKindV1::three_bin_forced_in &&
          action.evidence.resolution_kind !=
              ActionResolutionKindV1::three_bin_forced_out) ||
         (action.evidence.resolution_kind ==
                  ActionResolutionKindV1::three_bin_forced_in &&
          *action.evidence.exact_target_class !=
              AlgebraicTargetClass::forced_in) ||
         (action.evidence.resolution_kind ==
                  ActionResolutionKindV1::three_bin_forced_out &&
          *action.evidence.exact_target_class !=
              AlgebraicTargetClass::forced_out))) {
      return audit_failure<void>(
          "c17.invalid_three_bin_action_evidence",
          "the singleton three-bin resolver records only its forced class "
          "and cannot claim a multi-target optimizer witness");
    }
    std::vector<RuntimeMarkIdV1> seen_marks;
    seen_marks.reserve(atom.edge.marks().size());
    for (const CausalMarkV1& emitted : atom.edge.marks()) {
      const auto required = std::ranges::find_if(
          descriptor.marks, [&](const RuntimeMarkDescriptorV1& mark) {
            return mark.id == emitted.mark.mark;
          });
      if (required == descriptor.marks.end()) {
        return audit_failure<void>(
            "c17.undeclared_generated_mark",
            "a composed edge cannot publish a runtime mark absent from the "
            "audited descriptor");
      }
      const std::optional<CausalStageV1> generated =
          generated_mark_stage(
              required->decoder_source, true,
              static_cast<bool>(
                  state_schema.postarrival_mark_decoder.decode),
              static_cast<bool>(
                  state_schema.completed_edge_mark_decoder.decode));
      if (!generated.has_value() || emitted.reveal_stage != *generated ||
          emitted.mark.value.codec != required->c14_mark.codec ||
          std::ranges::find(seen_marks, emitted.mark.mark) !=
              seen_marks.end()) {
        return audit_failure<void>(
            "c17.generated_mark_carrier_mismatch",
            "each generated runtime mark must occur exactly once at its "
            "actual decoder-source stage with the declared value codec");
      }
      seen_marks.push_back(emitted.mark.mark);
    }
    for (const RuntimeMarkDescriptorV1& required : descriptor.marks) {
      if (required.decoder_source ==
          MarkDecoderSourceV1::entrance_realization) {
        continue;
      }
      if (std::ranges::find(seen_marks, required.id) == seen_marks.end()) {
        return audit_failure<void>(
            "c17.requested_mark_not_observable",
            "every requested runtime mark must be decoded from the same "
            "generated branch");
      }
    }
  }
  if (sum != ExactRational::one()) {
    return audit_failure<void>(
        "c17.composed_atom_sum_mismatch",
        "the exact stored atom masses must themselves sum to one");
  }
  return Result<void>::success();
}

template <std::size_t N>
[[nodiscard]] bool has_accepted_backend_route(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor,
    const std::array<BackendRouteKindV1, N>& routes) {
  return std::ranges::any_of(
      inputs.accepted_contract.metric_contracts(),
      [&](const ResolvedMetricContractV1& contract) {
        return contract.semantic == descriptor.core.semantic &&
               contract.runtime_access == descriptor.core.runtime_access &&
               contract.target_coupling == descriptor.core.target_coupling &&
               std::ranges::find(routes, contract.backend_route) !=
                   routes.end();
      });
}

[[nodiscard]] bool exact_romr_chronological_analytic_semantic(
    const MetricKindV1 kind,
    const SemanticContractAlternativeV1& semantic) {
  if (!semantic.require_temporal_one_slot_source ||
      !semantic.require_full_history_predictive_sufficiency ||
      semantic.entrance != EntranceLawRequirementV1::none) {
    return false;
  }
  if (kind == MetricKindV1::service_window_count) {
    return std::holds_alternative<PushforwardCountLawRequirementV1>(
        semantic.law);
  }
  const auto* scalar =
      std::get_if<FrameworkDerivedScalarRequirementV1>(&semantic.law);
  return scalar != nullptr &&
         ((kind == MetricKindV1::mean_event_gap &&
           scalar->scalar ==
               FrameworkScalarKindV1::event_intensity_active_fraction) ||
          (kind == MetricKindV1::mean_binary_run &&
           scalar->scalar ==
               FrameworkScalarKindV1::binary_occupation_start_ratio));
}

[[nodiscard]] bool stationary_selection(
    const MetricSelectionRegimeV1 selection) noexcept {
  switch (selection) {
    case MetricSelectionRegimeV1::stationary_unique:
    case MetricSelectionRegimeV1::stationary_class:
    case MetricSelectionRegimeV1::stationary_mixture:
      return true;
    case MetricSelectionRegimeV1::transient:
    case MetricSelectionRegimeV1::fixed_point_unique:
    case MetricSelectionRegimeV1::fixed_point_id:
      return false;
  }
  return false;
}

[[nodiscard]] bool same_ordered_target_ids(
    const std::span<const QueueId> ids,
    const std::span<const ResolvedMetricTargetV1> targets) {
  if (ids.size() != targets.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < ids.size(); ++index) {
    if (ids[index] != targets[index].queue_id) {
      return false;
    }
  }
  return true;
}

// An analytic backend label normally describes a direct analytic response and
// grants no temporal authority. C20 has one deliberately narrower case: an
// exact, enumerable procedural ROMR source can evaluate a service-window or
// occupation/start ratio from its complete chronological words. Correlate the
// frozen accepted contract back to that exact requirement tuple before C17
// treats the route as residence-backed. This never grants a raw slot executor.
[[nodiscard]] bool has_accepted_exact_romr_chronological_analytic_route(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const bool exact_row_available) {
  const ExactCausalProgramV1& program = inputs.causal_program;
  if (!exact_row_available ||
      descriptor.core.semantic != SemanticTagV1::romr_residence_word_law ||
      descriptor.core.runtime_access !=
          RuntimeAccessTagV1::procedural_residence_generator ||
      !program.maximum_residence_slots.has_value() ||
      *program.maximum_residence_slots == 0U ||
      !program.finite_event_domain_states.has_value() ||
      program.finite_event_domain_states->empty() ||
      program.event_clock_semantics != EventClockSemanticsV1::
                                           finite_phase_time_homogeneous_quotient) {
    return false;
  }

  const AcceptedCapabilityContract& accepted = inputs.accepted_contract;
  const auto& requirements = accepted.requirements();
  const auto& manifest = accepted.structural_manifest();
  return std::ranges::any_of(
      accepted.metric_contracts(), [&](const ResolvedMetricContractV1& contract) {
        if (contract.semantic != descriptor.core.semantic ||
            contract.runtime_access != descriptor.core.runtime_access ||
            contract.target_coupling != descriptor.core.target_coupling ||
            contract.backend_route !=
                BackendRouteKindV1::analytic_metric_family) {
          return false;
        }

        const auto clause = std::ranges::find_if(
            requirements.clauses(), [&](const MetricRequirementClause& value) {
              return value.origin.clause_id == contract.clause_id &&
                     value.origin.clause_id.authored_index ==
                         contract.authored_metric_index &&
                     value.origin.clause_id.metric_id == contract.metric_id &&
                     value.origin.ordered_targets == contract.ordered_targets &&
                     value.access.solver_regime == contract.solver_regime &&
                     value.coupling == contract.target_coupling &&
                     value.selection.require_unique_or_explicit_selection &&
                     stationary_selection(value.origin.selection_regime);
            });
        if (clause == requirements.clauses().end()) {
          return false;
        }

        const auto support = std::ranges::find_if(
            manifest.clauses(), [&](const MetricSupportClauseV1& value) {
              return value.clause_id == contract.clause_id &&
                     value.metric_kind == clause->origin.kind &&
                     same_ordered_target_ids(value.ordered_targets,
                                             contract.ordered_targets) &&
                     value.target_coupling == contract.target_coupling &&
                     value.semantic == descriptor.core.semantic &&
                     value.runtime_access == descriptor.core.runtime_access &&
                     value.solver_route == contract.solver_regime &&
                     value.error_promise.form == StructuralErrorFormV1::exact &&
                     (!value.error_promise.maximum_error.has_value() ||
                      value.error_promise.maximum_error->is_zero());
            });
        if (support == manifest.clauses().end()) {
          return false;
        }

        bool found_correlated_route = false;
        for (const MetricRouteAlternativeV1& route :
             clause->route_alternatives) {
          if (route.access.runtime_access != contract.runtime_access ||
              route.access.backend_route != contract.backend_route ||
              route.semantic.coupling != contract.target_coupling) {
            continue;
          }
          found_correlated_route = true;
          if (route.access.c24_row_or_reward_only ||
              route.access.exact_request_only ||
              !exact_romr_chronological_analytic_semantic(
                  clause->origin.kind, route.semantic)) {
            return false;
          }
        }
        return found_correlated_route;
      });
}

inline constexpr std::array<BackendRouteKindV1, 5U>
    kAcceptedTemporalRoutesV1{
        BackendRouteKindV1::stationary_invariant,
        BackendRouteKindV1::stationary_edge_reward,
        BackendRouteKindV1::finite_temporal_cylinder,
        BackendRouteKindV1::residence_or_stopped_law,
        BackendRouteKindV1::palm_or_fifo_law};

inline constexpr std::array<BackendRouteKindV1, 5U>
    kAcceptedRowRoutesV1{
        BackendRouteKindV1::stationary_invariant,
        BackendRouteKindV1::stationary_edge_reward,
        BackendRouteKindV1::finite_temporal_cylinder,
        BackendRouteKindV1::residence_or_stopped_law,
        BackendRouteKindV1::palm_or_fifo_law};

inline constexpr std::array<BackendRouteKindV1, 1U>
    kAcceptedC18ScalarRowRoutesV1{
        BackendRouteKindV1::framework_scalar_identity};

inline constexpr std::array<BackendRouteKindV1, 5U>
    kAcceptedSlotRoutesV1{
        BackendRouteKindV1::finite_temporal_cylinder,
        BackendRouteKindV1::residence_or_stopped_law,
        BackendRouteKindV1::palm_or_fifo_law,
        BackendRouteKindV1::conditional_row_monte_carlo,
        BackendRouteKindV1::conditional_reward_monte_carlo};

inline constexpr std::array<BackendRouteKindV1, 1U>
    kAcceptedAnalyticRoutesV1{
        BackendRouteKindV1::analytic_metric_family};

inline constexpr std::array<BackendRouteKindV1, 2U>
    kAcceptedSamplerRoutesV1{
        BackendRouteKindV1::conditional_row_monte_carlo,
        BackendRouteKindV1::conditional_reward_monte_carlo};

[[nodiscard]] bool has_accepted_unit_residence_route(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor) {
  return has_accepted_backend_route(inputs, descriptor,
                                    kAcceptedTemporalRoutesV1);
}

[[nodiscard]] bool arrival_composition_available(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const ConfiguredArrivalCompositionV1 composition) {
  const ArrivalCapabilities& capabilities =
      inputs.accepted_contract.arrival_capabilities();
  switch (composition) {
    case ConfiguredArrivalCompositionV1::no_arrival_composition:
      return false;
    case ConfiguredArrivalCompositionV1::iid_late_arrival:
      return capabilities.exact_iid_joint_vector.has_value() ||
             capabilities.exact_factorized_iid_generator.has_value() ||
             capabilities.exact_portable_iid_recipe.has_value();
    case ConfiguredArrivalCompositionV1::finite_enumerated_predictive_phase:
      return capabilities.finite_enumerated_predictive_phase ==
                 CapabilityAvailability::available &&
             capabilities.finite_enumerated_transition_row ==
                 CapabilityAvailability::available;
    case ConfiguredArrivalCompositionV1::sequential_predictive_phase:
      return capabilities.sequential_normalized_sampler ==
             CapabilityAvailability::available;
  }
  return false;
}

[[nodiscard]] std::optional<EventContractKindV1> expected_event_kind(
    const SemanticTagV1 semantic) {
  switch (semantic) {
    case SemanticTagV1::temporal_one_slot_continuation:
      return EventContractKindV1::one_slot_continuation;
    case SemanticTagV1::romr_residence_word_law:
      return EventContractKindV1::romr_residence;
    case SemanticTagV1::stopped_path_law:
      return EventContractKindV1::stopped_path;
    default:
      return std::nullopt;
  }
}

[[nodiscard]] bool valid_operation_identity(
    const RuntimeOperationIdentityV1& identity) {
  return !identity.operation_id.canonical_bytes().empty() &&
         identity.operation_version == 1U;
}

[[nodiscard]] bool exact_ordered_mark_codecs(
    const PlugDescriptor& descriptor,
    const std::span<const CodecIdentityV1> codecs) {
  if (codecs.size() != descriptor.marks.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < codecs.size(); ++index) {
    if (codecs[index] != descriptor.marks[index].c14_mark.codec) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool accepted_residence_evidence_is_declared(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor) {
  for (const HypothesisRequirementV1& requirement :
       inputs.accepted_contract.requirements().hypothesis_union()) {
    const HypothesisClaimV1& claim = requirement.claim;
    const bool residence_evidence =
        claim.kind == HypothesisKindV1::nondefective ||
        (claim.kind == HypothesisKindV1::moment_finite &&
         claim.variable ==
             std::optional<MomentVariableV1>{MomentVariableV1::stopped_time});
    if (residence_evidence &&
        std::ranges::find(descriptor.core.hypothesis_claims, claim) ==
            descriptor.core.hypothesis_claims.end()) {
      return false;
    }
  }
  return true;
}

struct AcceptedStoppedPathConstraintsV1 final {
  bool present{false};
  bool may_be_defective{false};
  bool finite_mean_requested{false};
};

[[nodiscard]] AcceptedStoppedPathConstraintsV1
accepted_stopped_path_constraints(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor) {
  AcceptedStoppedPathConstraintsV1 result;
  for (const ResolvedMetricContractV1& accepted :
       inputs.accepted_contract.metric_contracts()) {
    if (accepted.semantic != descriptor.core.semantic ||
        accepted.runtime_access != descriptor.core.runtime_access ||
        accepted.target_coupling != descriptor.core.target_coupling) {
      continue;
    }
    const auto clause = std::ranges::find_if(
        inputs.accepted_contract.requirements().clauses(),
        [&](const MetricRequirementClause& candidate) {
          return candidate.origin.clause_id == accepted.clause_id;
        });
    if (clause == inputs.accepted_contract.requirements().clauses().end()) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.runtime_access != accepted.runtime_access ||
          route.access.backend_route != accepted.backend_route) {
        continue;
      }
      const auto* stopped =
          std::get_if<StoppedPathRequirementV1>(&route.semantic.law);
      if (stopped == nullptr) {
        continue;
      }
      result.present = true;
      result.may_be_defective =
          result.may_be_defective || stopped->may_be_defective;
      result.finite_mean_requested =
          result.finite_mean_requested || stopped->finite_mean_requested;
    }
  }
  return result;
}

[[nodiscard]] bool exact_event_operation_topology(
    const CausalSurrogateOperationsV1& operations,
    const TemporalEventContractV1& contract) {
  if (!operations.event.has_value()) {
    return false;
  }
  const TemporalEventOperationsV1& event = *operations.event;
  const EventEntryInitializerSchemaV1 expected_entry{
      contract.entry_initializer_operation, contract.entrance_space,
      contract.continuation_space};
  const EventStoppingIndicatorSchemaV1 expected_stopping{
      contract.stopping_indicator_operation, contract.stopping_filtration,
      contract.continuation_space, contract.stopping_indicator};
  const EventTerminalReentrySchemaV1 expected_terminal{
      contract.terminal_reentry_operation, contract.terminal_space,
      contract.continuation_space, contract.reentry_space};
  const EventPredecisionProjectionSchemaV1 expected_predecision{
      contract.predecision_projection_operation, contract.entrance_space,
      contract.continuation_space, contract.predecision_projection};
  const EventCompletedEdgeProjectionSchemaV1 expected_completed_edge{
      contract.completed_edge_projection_operation,
      contract.predecision_projection, contract.continuation_space,
      contract.completed_edge_projection};
  return event.entry_initializer.has_operation() &&
         event.stopping_indicator.has_operation() &&
         event.terminal_reentry.has_operation() &&
         event.predecision_projection.has_operation() &&
         event.completed_edge_projection.has_operation() &&
         event.entry_initializer.schema() == expected_entry &&
         event.stopping_indicator.schema() == expected_stopping &&
         event.terminal_reentry.schema() == expected_terminal &&
         event.predecision_projection.schema() == expected_predecision &&
         event.completed_edge_projection.schema() == expected_completed_edge;
}

[[nodiscard]] bool exact_event_access_binding(
    const KernelAccess& access, const PlugDescriptor& descriptor,
    const TemporalEventContractV1& event) {
  return std::visit(
      [&](const auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, FiniteEnumeratedRowAccess> ||
                      std::same_as<Active, SparseRowAccess> ||
                      std::same_as<Active,
                                   NormalizedConditionalSamplerAccess>) {
          const TransitionKernelAccessShapeV1& shape = active.shape();
          return active.has_operation() &&
                 descriptor.transition_state_schema.has_value() &&
                 shape.conditioning_state_codec ==
                     descriptor.transition_state_schema
                         ->conditioning_state_codec &&
                 shape.successor_state_codec ==
                     descriptor.transition_state_schema
                         ->successor_state_codec &&
                 exact_ordered_mark_codecs(descriptor,
                                           shape.ordered_mark_codecs) &&
                 shape.event_generator_identity.has_value() &&
                 shape.event_generator_identity->operation_id.label() ==
                     event.event_generator_operation.operation_id.label() &&
                 shape.event_generator_identity->operation_version ==
                     event.event_generator_operation.operation_version;
        } else if constexpr (
            std::same_as<Active, ProceduralResidenceGeneratorAccess>) {
          const ResidenceGeneratorAccessShapeV1& shape = active.shape();
          return active.has_operation() &&
                 active.positive_residence_declared() &&
                 shape.entrance_state_codec == event.entrance_space &&
                 shape.continuation_state_codec == event.continuation_space &&
                 shape.terminal_state_codec == event.terminal_space &&
                 shape.reentry_state_codec == event.reentry_space &&
                 exact_ordered_mark_codecs(descriptor,
                                           shape.ordered_mark_codecs) &&
                 (!shape.maximum_residence_slots.has_value() ||
                  *shape.maximum_residence_slots != 0U) &&
                 active.operation_identity().operation_id.label() ==
                     event.event_generator_operation.operation_id.label() &&
                 active.operation_identity().operation_version ==
                     event.event_generator_operation.operation_version &&
                 active.operation_identity().event_schema ==
                     event.stopping_indicator;
        }
        return false;
      },
      access);
}

// This check is intentionally structural.  In particular it never copies or
// invokes a row, sampler, residence generator, or temporal event callback.
// Procedural normalization, measurability, and termination therefore remain
// declared V0 evidence rather than being mislabeled exhaustive.
[[nodiscard]] Result<bool> validate_declared_residence_contract(
    const SurrogatePlug& plug,
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const KernelAccess& access) {
  const std::optional<EventContractKindV1> expected =
      expected_event_kind(descriptor.core.semantic);
  if (!expected.has_value()) {
    if (descriptor.event_contract.has_value()) {
      return audit_failure<bool>(
          "c17.event_contract_on_non_temporal_semantic",
          "only a temporal, residence, or stopped semantic can carry an "
          "event contract");
    }
    return Result<bool>::success(false);
  }
  const CausalSurrogateOperationsV1* operations = causal_operations_v1(plug);
  if (!descriptor.event_contract.has_value() || operations == nullptr) {
    return audit_failure<bool>(
        "c17.missing_declared_residence_contract",
        "a temporal semantic requires one complete event contract and its "
        "five immutable event operations");
  }
  const TemporalEventContractV1& event = *descriptor.event_contract;
  const std::array<const RuntimeOperationIdentityV1*, 6U> identities{
      &event.event_generator_operation, &event.entry_initializer_operation,
      &event.stopping_indicator_operation, &event.terminal_reentry_operation,
      &event.predecision_projection_operation,
      &event.completed_edge_projection_operation};
  bool distinct_operations = true;
  for (std::size_t left = 0U; left < identities.size(); ++left) {
    distinct_operations =
        distinct_operations && valid_operation_identity(*identities[left]);
    for (std::size_t right = left + 1U; right < identities.size(); ++right) {
      distinct_operations =
          distinct_operations &&
          *identities[left] != *identities[right];
    }
  }
  const std::array<const CodecIdentityV1*, 7U> codecs{
      &event.continuation_space, &event.entrance_space,
      &event.terminal_space, &event.reentry_space,
      &event.stopping_indicator, &event.predecision_projection,
      &event.completed_edge_projection};
  const bool valid_codecs =
      std::ranges::all_of(codecs, [](const CodecIdentityV1* codec) {
        return valid_codec(*codec);
      });
  const AcceptedStoppedPathConstraintsV1 stopped_constraints =
      accepted_stopped_path_constraints(inputs, descriptor);
  const bool defect_matches_accepted_contract =
      event.kind != EventContractKindV1::stopped_path
          ? !event.defective_hitting_law
          : (stopped_constraints.present &&
             (!event.defective_hitting_law ||
              (stopped_constraints.may_be_defective &&
               !stopped_constraints.finite_mean_requested)));
  const bool kind_matches = event.kind == *expected;
  const bool natural_filtration =
      event.stopping_filtration ==
      EventFiltrationV1::generated_slot_natural_filtration;
  const bool positive_adapted_stop =
      event.stopping_rule_adapted && event.first_stop_strictly_positive;
  const bool exact_reentry =
      event.terminal_reentry_exact &&
      event.entrance_space == event.reentry_space;
  const bool operation_topology =
      exact_event_operation_topology(*operations, event);
  const bool access_binding =
      exact_event_access_binding(access, descriptor, event);
  const bool evidence_declared =
      accepted_residence_evidence_is_declared(inputs, descriptor);
  const bool accepted_route =
      has_accepted_backend_route(inputs, descriptor,
                                 kAcceptedTemporalRoutesV1) ||
      (descriptor.core.runtime_access ==
           RuntimeAccessTagV1::normalized_conditional_sampler &&
       has_accepted_backend_route(inputs, descriptor,
                                  kAcceptedSamplerRoutesV1)) ||
      has_accepted_exact_romr_chronological_analytic_route(
          inputs, descriptor, program_has_row(plug, inputs));
  const bool arrival_composition = arrival_composition_available(
      inputs, descriptor.core.phase.arrival_composition);
  if (!kind_matches || !natural_filtration || !distinct_operations ||
      !valid_codecs || !positive_adapted_stop || !exact_reentry ||
      !defect_matches_accepted_contract || !operation_topology ||
      !access_binding || !evidence_declared || !accepted_route ||
      !arrival_composition) {
    const auto flag = [](const bool value) -> std::string_view {
      return value ? "1" : "0";
    };
    return audit_failure<bool>(
        "c17.invalid_declared_residence_contract",
        "a temporal V0 contract requires its exact event kind, six operation "
        "identities, five operation schemas, codec topology, natural adapted "
        "positive stop, exact terminal re-entry, accepted temporal backend, "
        "configured-arrival composition, and declared finite/nondefective "
        "evidence where requested; checks(kind=" +
            std::string(flag(kind_matches)) + ",filtration=" +
            std::string(flag(natural_filtration)) + ",operations=" +
            std::string(flag(distinct_operations)) + ",codecs=" +
            std::string(flag(valid_codecs)) + ",stop=" +
            std::string(flag(positive_adapted_stop)) + ",reentry=" +
            std::string(flag(exact_reentry)) + ",defect=" +
            std::string(flag(defect_matches_accepted_contract)) +
            ",topology=" + std::string(flag(operation_topology)) +
            ",access=" + std::string(flag(access_binding)) +
            ",evidence=" + std::string(flag(evidence_declared)) +
            ",route=" + std::string(flag(accepted_route)) +
            ",arrival=" + std::string(flag(arrival_composition)) + ")");
  }
  return Result<bool>::success(true);
}

[[nodiscard]] bool unit_residence_applicable(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const bool row_available,
    const bool slot_available) {
  const bool framework_only_state = std::ranges::all_of(
      descriptor.state_fields, [](const RuntimeStateFieldV1& field) {
        return field.c14_field.ownership ==
               FieldOwnershipV1::framework_exact;
      });
  return has_accepted_unit_residence_route(inputs, descriptor) &&
         framework_only_state && !descriptor.c_minus.has_value() &&
         !descriptor.c_plus.has_value() &&
         !descriptor.event_contract.has_value() &&
         (row_available || slot_available);
}

[[nodiscard]] Result<bool> validate_unit_residence_contract(
    const CompiledFrameworkCandidateInputsV1& inputs,
    const PlugDescriptor& descriptor, const bool closed_three_bin,
    const bool row_available, const bool slot_available) {
  if (!closed_three_bin ||
      !has_accepted_unit_residence_route(inputs, descriptor)) {
    return Result<bool>::success(false);
  }
  if (!unit_residence_applicable(inputs, descriptor, row_available,
                                 slot_available)) {
    return audit_failure<bool>(
        "c17.invalid_framework_unit_residence_contract",
        "an accepted temporal three-bin route requires only framework-exact "
        "state, no provider closure/event operation, and an actual C09 "
        "enumerator or proposer");
  }
  for (const ReducedStateV1& state :
       inputs.causal_program.reachable_audit_states) {
    auto decoded = inputs.exact_state_schema.decode(state);
    if (!decoded) {
      return Result<bool>::failure(decoded.error());
    }
    if (!decoded.value().unresolved_fields.empty()) {
      return audit_failure<bool>(
          "c17.unit_residence_extra_state",
          "the framework-derived unit residence cannot retain provider Z or "
          "another surrogate-unresolved coordinate");
    }
  }
  return Result<bool>::success(true);
}

[[nodiscard]] bool passing_core(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& core) {
  return core && core->report().passed();
}

[[nodiscard]] bool initial_mapper_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.inputs().causal_program.mode !=
             ExactCausalProgramModeV1::bound_direct_decoder &&
         static_cast<bool>(core.inputs().framework_seed.initial_mapper);
}

[[nodiscard]] bool row_provider_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  const PlugDescriptor& descriptor = core.descriptor();
  // A framework scalar identity does not generally grant row authority.
  // Its C18 proof lane is the narrow exception: C27 has already selected an
  // exact finite/sparse stationary law as the existence proof.
  const bool c18_framework_scalar_row =
      (descriptor.core.runtime_access ==
           RuntimeAccessTagV1::finite_enumerated_row ||
       descriptor.core.runtime_access == RuntimeAccessTagV1::sparse_row) &&
      has_accepted_backend_route(
          core.inputs(), descriptor, kAcceptedC18ScalarRowRoutesV1);
  return core.row_available() &&
         (has_accepted_backend_route(core.inputs(), descriptor,
                                     kAcceptedRowRoutesV1) ||
          c18_framework_scalar_row);
}

[[nodiscard]] bool slot_executor_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.slot_available() &&
         has_accepted_backend_route(core.inputs(), core.descriptor(),
                                    kAcceptedSlotRoutesV1);
}

[[nodiscard]] bool response_law_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.descriptor().core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         core.descriptor().core.phase.payload_phase ==
             PayloadPhaseKindV1::phase_free &&
         has_accepted_backend_route(core.inputs(), core.descriptor(),
                                    kAcceptedAnalyticRoutesV1);
}

[[nodiscard]] bool three_bin_response_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.is_three_bin() &&
         core.descriptor().core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         core.descriptor().core.runtime_access ==
             RuntimeAccessTagV1::finite_parameter_analytic_family &&
         core.descriptor().core.phase.payload_phase ==
             PayloadPhaseKindV1::phase_free &&
         core.descriptor().core.deployed_targets.size() == 1U &&
         std::holds_alternative<FiniteParameterAnalyticFamilyAccess>(
             core.access());
}

[[nodiscard]] bool finite_prefix_constant_tail_response_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.is_finite_prefix_constant_tail() &&
         core.descriptor().core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         core.descriptor().core.payload_class ==
             PayloadClassV1{
                 PayloadClassTagV1::
                     finite_prefix_constant_tail_response_v1,
                 1U} &&
         core.descriptor().core.runtime_access ==
             RuntimeAccessTagV1::finite_parameter_analytic_family &&
         core.descriptor().core.phase.payload_phase ==
             PayloadPhaseKindV1::phase_free &&
         core.descriptor().core.deployed_targets.size() == 1U &&
         std::holds_alternative<PortableFinitePrefixConstantTailResponseV1>(
             portable_source_v1(core.plug()).value()) &&
         std::holds_alternative<FiniteParameterAnalyticFamilyAccess>(
             core.access());
}

[[nodiscard]] bool phase_response_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  const PhaseSupportV1& phase = core.descriptor().core.phase;
  const bool predictive_composition =
      phase.arrival_composition ==
          ConfiguredArrivalCompositionV1::finite_enumerated_predictive_phase ||
      phase.arrival_composition ==
          ConfiguredArrivalCompositionV1::sequential_predictive_phase;
  return core.descriptor().core.semantic ==
             SemanticTagV1::scalar_backlog_response &&
         phase.payload_phase ==
             PayloadPhaseKindV1::predictive_phase_indexed &&
         phase.retains_configured_predictive_phase &&
         phase.predictive_phase_codec.has_value() &&
         valid_codec(*phase.predictive_phase_codec) &&
         predictive_composition &&
         arrival_composition_available(core.inputs(),
                                       phase.arrival_composition) &&
         has_accepted_backend_route(core.inputs(), core.descriptor(),
                                    kAcceptedAnalyticRoutesV1);
}

[[nodiscard]] bool fixed_point_family_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  const RuntimeAccessTagV1 access = core.descriptor().core.runtime_access;
  const bool analytic_access =
      access == RuntimeAccessTagV1::analytic_transform ||
      access == RuntimeAccessTagV1::finite_parameter_analytic_family;
  const bool fixed_point_selection = std::ranges::any_of(
      core.descriptor().core.selection.kinds,
      [](const SelectionKindV1 selection) {
        return selection == SelectionKindV1::fixed_point_unique ||
               selection == SelectionKindV1::fixed_point_id;
      });
  return analytic_access && fixed_point_selection &&
         has_accepted_backend_route(core.inputs(), core.descriptor(),
                                    kAcceptedAnalyticRoutesV1);
}

[[nodiscard]] bool unit_romr_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return core.is_closed_scalar_response() &&
         unit_residence_applicable(core.inputs(), core.descriptor(),
                                   core.row_available(),
                                   core.slot_available());
}

[[nodiscard]] bool declared_romr_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  const PlugDescriptor& descriptor = core.descriptor();
  const auto expected = expected_event_kind(descriptor.core.semantic);
  const CausalSurrogateOperationsV1* operations =
      causal_operations_v1(core.plug());
  const bool supported_c20_access =
      std::holds_alternative<FiniteEnumeratedRowAccess>(core.access()) ||
      std::holds_alternative<SparseRowAccess>(core.access()) ||
      std::holds_alternative<ProceduralResidenceGeneratorAccess>(
          core.access());
  const bool declared_entry_domain =
      core.inputs().causal_program.finite_event_domain_states.has_value() ||
      core.inputs().causal_program
          .event_entry_domain_is_exact_state_domain;
  return expected.has_value() && descriptor.event_contract.has_value() &&
         descriptor.event_contract->kind == *expected &&
         !descriptor.event_contract->defective_hitting_law &&
         operations != nullptr && supported_c20_access &&
         declared_entry_domain &&
         exact_event_operation_topology(
             *operations, *descriptor.event_contract) &&
         exact_event_access_binding(core.access(), descriptor,
                                    *descriptor.event_contract) &&
         (has_accepted_backend_route(core.inputs(), descriptor,
                                     kAcceptedTemporalRoutesV1) ||
          has_accepted_exact_romr_chronological_analytic_route(
              core.inputs(), descriptor, core.row_available()));
}

[[nodiscard]] bool romr_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return unit_romr_applicable(core) || declared_romr_applicable(core);
}

[[nodiscard]] bool residence_provider_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  if (unit_romr_applicable(core)) {
    return row_provider_applicable(core);
  }
  const bool exact_c20_access =
      std::holds_alternative<FiniteEnumeratedRowAccess>(core.access()) ||
      std::holds_alternative<SparseRowAccess>(core.access()) ||
      (std::holds_alternative<ProceduralResidenceGeneratorAccess>(
           core.access()) &&
       core.row_available());
  return declared_romr_applicable(core) && exact_c20_access &&
         (row_provider_applicable(core) ||
          has_accepted_exact_romr_chronological_analytic_route(
              core.inputs(), core.descriptor(), core.row_available()));
}

[[nodiscard]] bool temporal_framework_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  if (unit_romr_applicable(core)) {
    return slot_executor_applicable(core);
  }
  return declared_romr_applicable(core) &&
         slot_executor_applicable(core);
}

[[nodiscard]] bool sampler_descriptor_applicable(
    const surrogate::detail::SealedFrameworkCore& core) {
  return std::holds_alternative<NormalizedConditionalSamplerAccess>(
             core.access()) &&
         core.slot_available() &&
         has_accepted_backend_route(core.inputs(), core.descriptor(),
                                    kAcceptedSamplerRoutesV1);
}

[[nodiscard]] V0WitnessEntryV1 entry(
    const V0ObligationV1 obligation, const V0EvidenceScopeV1 scope,
    std::string note) {
  return V0WitnessEntryV1{obligation, scope, true, {std::move(note)}};
}

[[nodiscard]] std::vector<V0WitnessEntryV1> direct_factor_entries(
    const DirectFactorWitnessV1& factor) {
  std::vector<V0WitnessEntryV1> inherited;
  inherited.reserve(factor.report().entries().size());
  for (const V0WitnessEntryV1& factor_entry :
       factor.report().entries()) {
    if (factor_entry.obligation ==
        V0ObligationV1::framework_unit_residence) {
      inherited.push_back(entry(
          V0ObligationV1::framework_unit_residence,
          V0EvidenceScopeV1::not_applicable,
          "a direct-only seal grants no row, slot, residence, metric-backend, "
          "or estimator authority from its bound causal factor"));
      continue;
    }
    V0WitnessEntryV1 cited = factor_entry;
    cited.notes.push_back(
        "scope inherited from the exactly bound passing causal row factor");
    inherited.push_back(std::move(cited));
  }
  return inherited;
}

[[nodiscard]] Result<void> validate_direct_factor_raw_topology(
    const SurrogatePlug& plug, const PlugDescriptor& descriptor,
    const KernelAccess& access) {
  const auto* operations = causal_operations_v1(plug);
  if (descriptor.core.semantic !=
          SemanticTagV1::stationary_marked_edge ||
      semantic_tag_v1(plug) != descriptor.core.semantic ||
      operations == nullptr || !operations->c_minus.has_value() ||
      !operations->c_plus.has_value() || operations->event.has_value() ||
      !descriptor.c_minus.has_value() || !descriptor.c_plus.has_value() ||
      descriptor.event_contract.has_value() ||
      operations->c_minus->schema() != *descriptor.c_minus ||
      operations->c_plus->schema() != *descriptor.c_plus ||
      !operations->c_minus->has_exact_enumerator() ||
      !operations->c_plus->has_exact_enumerator()) {
    return audit_failure<void>(
        "c17.direct_factor_operation_topology_mismatch",
        "the private direct factor requires one stationary marked-edge "
        "plug with exact descriptor-bound C-minus and C-plus enumerators "
        "and no temporal operation");
  }
  const auto transition_matches = [&](const auto& row) {
    if (!descriptor.transition_state_schema.has_value()) return false;
    const TransitionKernelAccessShapeV1& shape = row.shape();
    if (!row.has_operation() ||
        shape.conditioning_state_codec !=
            descriptor.transition_state_schema
                ->conditioning_state_codec ||
        shape.successor_state_codec !=
            descriptor.transition_state_schema->successor_state_codec ||
        shape.ordered_mark_codecs.size() != descriptor.marks.size() ||
        shape.event_generator_identity.has_value()) {
      return false;
    }
    for (std::size_t index = 0U;
         index < shape.ordered_mark_codecs.size(); ++index) {
      if (shape.ordered_mark_codecs[index] !=
          descriptor.marks[index].c14_mark.codec) {
        return false;
      }
    }
    return true;
  };
  const bool access_matches = std::visit(
      [&](const auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, FiniteEnumeratedRowAccess> ||
                      std::same_as<Active, SparseRowAccess>) {
          return transition_matches(active);
        }
        return false;
      },
      access);
  if (!access_matches) {
    return audit_failure<void>(
        "c17.direct_factor_access_topology_mismatch",
        "the private direct factor requires one callable finite or sparse "
        "row access whose state and ordered-mark codecs exactly equal its "
        "descriptor");
  }
  return Result<void>::success();
}

[[nodiscard]] std::vector<V0WitnessEntryV1>
direct_factor_audit_entries() {
  std::vector<V0WitnessEntryV1> entries;
  entries.reserve(11U);
  entries.push_back(entry(
      V0ObligationV1::normalized_typed_laws,
      V0EvidenceScopeV1::reachable_enumerated,
      "the same exact composer inspected every supplied factor audit state"));
  entries.push_back(entry(
      V0ObligationV1::causal_factorization,
      V0EvidenceScopeV1::construction_enforced,
      "the private factor publishes C-minus, resolver, arrival, C-plus, and Psi"));
  entries.push_back(entry(
      V0ObligationV1::configured_arrival_exactly_once,
      V0EvidenceScopeV1::construction_enforced,
      "one move-only arrival capability is consumed per factor action"));
  entries.push_back(entry(
      V0ObligationV1::common_action_feasibility,
      V0EvidenceScopeV1::reachable_enumerated,
      "resolved factor actions retain one common feasible schedule"));
  entries.push_back(entry(
      V0ObligationV1::empty_queue_eligibility,
      V0EvidenceScopeV1::reachable_enumerated,
      "actual departure is D=s times the positive-backlog indicator"));
  entries.push_back(entry(
      V0ObligationV1::exact_sign_and_tie_resolution,
      V0EvidenceScopeV1::reachable_enumerated,
      "the configured exact resolver evidence is retained on each factor action"));
  entries.push_back(entry(
      V0ObligationV1::exact_update_and_ownership,
      V0EvidenceScopeV1::construction_enforced,
      "Psi alone rebuilds exact coordinates and C-plus writes only unresolved fields"));
  entries.push_back(entry(
      V0ObligationV1::reduced_state_domain_closure,
      V0EvidenceScopeV1::reachable_enumerated,
      "every factor successor passes the sealed reduced-state predicate"));
  entries.push_back(entry(
      V0ObligationV1::row_concatenation,
      V0EvidenceScopeV1::reachable_enumerated,
      "factor successors inhabit the next predecision state domain"));
  entries.push_back(entry(
      V0ObligationV1::requested_mark_observability,
      V0EvidenceScopeV1::reachable_enumerated,
      "factor runtime marks retain their common causal path and reveal stage"));
  entries.push_back(entry(
      V0ObligationV1::framework_unit_residence,
      V0EvidenceScopeV1::not_applicable,
      "the private stationary causal factor grants no unit-residence authority"));
  return entries;
}

}  // namespace

Result<DirectFactorWitnessV1>
C17AuditedFrameworkMint::audit_direct_factor_recipe(
    RuntimePlugCandidateV1 raw_candidate,
    CompiledFrameworkCandidateInputsV1& inputs,
    const ValidatedSurrogatePlug& direct_validated_plug) {
  PlugDescriptor descriptor = std::move(raw_candidate.descriptor);
  SurrogatePlug plug = std::move(raw_candidate.plug);
  KernelAccess access = kernel_access_v1(plug);

  auto descriptor_shape = validate_plug_descriptor_v1(descriptor);
  if (!descriptor_shape) {
    return Result<DirectFactorWitnessV1>::failure(
        descriptor_shape.error());
  }
  auto access_shape = validate_kernel_access_shape_v1(access);
  if (!access_shape) {
    return Result<DirectFactorWitnessV1>::failure(
        access_shape.error());
  }
  auto topology =
      validate_direct_factor_raw_topology(plug, descriptor, access);
  if (!topology) {
    return Result<DirectFactorWitnessV1>::failure(
        topology.error());
  }
  auto access_identity = canonical_raw_access_identity(access);
  if (!access_identity) {
    return Result<DirectFactorWitnessV1>::failure(
        access_identity.error());
  }
  // Descriptor/access identities for the auxiliary factor are derived by
  // C17 from the fresh raw recipe itself.  The activation is not a second
  // C15/C16 boundary and therefore cannot pre-mint these C17 identities.
  inputs.framework_seed.bindings.descriptor_digest =
      descriptor.descriptor_digest;
  inputs.framework_seed.bindings.access_digest = access_identity.value();
  inputs.framework_seed.bindings.direct_metric_decoder_domain.reset();
  auto bindings = validate_candidate_bindings(
      plug, inputs, descriptor.descriptor_digest,
      direct_validated_plug.artifact_bindings_,
      direct_validated_plug.accepted_contract_digest_,
      direct_validated_plug.accepted_structural_manifest_, descriptor,
      access, true, access_identity.value(), true);
  if (!bindings) {
    return Result<DirectFactorWitnessV1>::failure(
        bindings.error());
  }
  auto marks = validate_mark_carriers(
      descriptor, inputs.exact_state_schema);
  if (!marks) {
    return Result<DirectFactorWitnessV1>::failure(marks.error());
  }
  auto capabilities =
      validate_program_capabilities(plug, inputs, descriptor, access);
  if (!capabilities) {
    return Result<DirectFactorWitnessV1>::failure(
        capabilities.error());
  }
  auto three_bin =
      validate_three_bin_adapter(plug, inputs, descriptor, access);
  if (!three_bin) {
    return Result<DirectFactorWitnessV1>::failure(
        three_bin.error());
  }
  auto finite_prefix = validate_finite_prefix_constant_tail_adapter(
      plug, inputs, descriptor, access);
  if (!finite_prefix) {
    return Result<DirectFactorWitnessV1>::failure(
        finite_prefix.error());
  }
  auto residence = validate_declared_residence_contract(
      plug, inputs, descriptor, access);
  if (!residence) {
    return Result<DirectFactorWitnessV1>::failure(
        residence.error());
  }
  if (residence.value() || !program_has_row(plug, inputs) ||
      inputs.causal_program.mode !=
          ExactCausalProgramModeV1::generic_bound_operations ||
      inputs.causal_program.reachable_audit_states.empty()) {
    return audit_failure<DirectFactorWitnessV1>(
        "c17.direct_factor_not_enumerable",
        "the private direct factor must expose an ordinary exact row "
        "composer and at least one request-bound reachable audit state");
  }

  for (const ReducedStateV1& state :
       inputs.causal_program.reachable_audit_states) {
    auto source_domain = inputs.exact_state_schema.validate_domain(state);
    if (!source_domain) {
      return Result<DirectFactorWitnessV1>::failure(
          source_domain.error());
    }
    auto replay = detail::C17CoreAccess::compose_program_row(
        &plug, descriptor, inputs.instance, inputs.configured_arrival,
        inputs.exact_state_schema, inputs.causal_program,
        inputs.optimizer_context, state);
    if (!replay) {
      return Result<DirectFactorWitnessV1>::failure(
          replay.error());
    }
    auto row = detail::C17CoreAccess::compose_program_row(
        &plug, descriptor, inputs.instance, inputs.configured_arrival,
        inputs.exact_state_schema, inputs.causal_program,
        inputs.optimizer_context, state);
    if (!row) {
      return Result<DirectFactorWitnessV1>::failure(row.error());
    }
    if (!same_complete_marked_row(replay.value(), row.value())) {
      return audit_failure<DirectFactorWitnessV1>(
          "c17.direct_factor_operation_not_immutable",
          "replaying the private factor's exact five-stage row changed its "
          "canonical atoms, masses, marks, diagnostics, or row image");
    }
    auto row_shape = validate_audited_row(
        row.value(), state, descriptor, inputs.exact_state_schema,
        inputs.instance, false);
    if (!row_shape) {
      return Result<DirectFactorWitnessV1>::failure(
          row_shape.error());
    }
  }

  auto seal = execution_seal_digest(
      inputs, descriptor, access_identity.value(), nullptr);
  if (!seal) {
    return Result<DirectFactorWitnessV1>::failure(seal.error());
  }
  V0WitnessBindingsV1 report_bindings{
      inputs.framework_seed.bindings.problem_fingerprints.resolved_instance,
      descriptor.descriptor_digest, access_identity.value(),
      inputs.exact_state_schema.ownership_schema_digest,
      inputs.exact_state_schema.exact_update_schema_digest};
  V0WitnessReport report = detail::C17CoreAccess::v0_report(
      std::move(report_bindings), direct_factor_audit_entries(), true);
  const auto arrival = detail::ArrivalCoreAccess::law_core(
      inputs.configured_arrival);
  if (!arrival) {
    return audit_failure<DirectFactorWitnessV1>(
        "c17.direct_factor_arrival_missing",
        "the passing private factor lost its configured-arrival binding "
        "before immutable witness projection");
  }
  return Result<DirectFactorWitnessV1>::success(DirectFactorWitnessV1(
      std::move(seal).value(), std::move(report),
      inputs.framework_seed.bindings,
      inputs.framework_seed.target_selection,
      descriptor.core.deployed_targets,
      inputs.exact_state_schema.ownership_schema_digest,
      inputs.exact_state_schema.exact_update_schema_digest,
      arrival->binding, inputs.causal_program.mode,
      runtime_access_tag_v1(access), true));
}

Result<CanonicalRuntimeValueV1>
surrogate::detail::SealedRomrOpsAuthority::initialize(
    const CanonicalRuntimeValueV1& value) const {
  if (unit_residence_) {
    if (!(value.codec == state_codec_)) {
      return audit_failure<CanonicalRuntimeValueV1>(
          "c17.unit_romr_initializer_codec_mismatch",
          "the framework unit-residence initializer requires its exact "
          "reduced-state codec");
    }
    return Result<CanonicalRuntimeValueV1>::success(value);
  }
  if (!event_operations_.has_value()) {
    return audit_failure<CanonicalRuntimeValueV1>(
        "c17.sealed_romr_initializer_unavailable",
        "the sealed framework has no declared event initializer authority");
  }
  auto operation = event_operations_->entry_initializer.fresh_operation();
  return operation(value);
}

Result<CanonicalRuntimeValueV1>
surrogate::detail::SealedRomrOpsAuthority::stop(
    const CanonicalRuntimeValueV1& value) const {
  if (unit_residence_) {
    if (!(value.codec == state_codec_)) {
      return audit_failure<CanonicalRuntimeValueV1>(
          "c17.unit_romr_stop_codec_mismatch",
          "the framework unit-residence stop requires its exact successor "
          "state codec");
    }
    return Result<CanonicalRuntimeValueV1>::success(
        CanonicalRuntimeValueV1{unit_indicator_codec_, unit_true_value_});
  }
  if (!event_operations_.has_value()) {
    return audit_failure<CanonicalRuntimeValueV1>(
        "c17.sealed_romr_stop_unavailable",
        "the sealed framework has no declared stopping authority");
  }
  auto operation = event_operations_->stopping_indicator.fresh_operation();
  return operation(value);
}

Result<CanonicalRuntimeValueV1>
surrogate::detail::SealedRomrOpsAuthority::terminal(
    const EventTerminalReentryInputV1& input) const {
  if (unit_residence_) {
    if (!(input.successor_state.codec == state_codec_)) {
      return audit_failure<CanonicalRuntimeValueV1>(
          "c17.unit_romr_terminal_codec_mismatch",
          "the framework unit-residence terminal requires its exact "
          "successor-state codec");
    }
    return Result<CanonicalRuntimeValueV1>::success(input.successor_state);
  }
  if (!event_operations_.has_value()) {
    return audit_failure<CanonicalRuntimeValueV1>(
        "c17.sealed_romr_terminal_unavailable",
        "the sealed framework has no declared terminal authority");
  }
  auto operation = event_operations_->terminal_reentry.fresh_operation();
  return operation(input);
}

Result<CanonicalRuntimeValueV1>
surrogate::detail::SealedRomrOpsAuthority::predecision(
    const EventPredecisionProjectionInputV1& input) const {
  if (unit_residence_) {
    if (!(input.current_predecision_state.codec == state_codec_)) {
      return audit_failure<CanonicalRuntimeValueV1>(
          "c17.unit_romr_predecision_codec_mismatch",
          "the framework unit-residence projection requires its exact "
          "predecision-state codec");
    }
    return Result<CanonicalRuntimeValueV1>::success(
        input.current_predecision_state);
  }
  if (!event_operations_.has_value()) {
    return audit_failure<CanonicalRuntimeValueV1>(
        "c17.sealed_romr_predecision_unavailable",
        "the sealed framework has no declared predecision projection "
        "authority");
  }
  auto operation = event_operations_->predecision_projection.fresh_operation();
  return operation(input);
}

Result<CanonicalRuntimeValueV1>
surrogate::detail::SealedRomrOpsAuthority::completed(
    const EventCompletedEdgeProjectionInputV1& input) const {
  if (unit_residence_) {
    if (!(input.completed_edge.successor_state.codec == state_codec_)) {
      return audit_failure<CanonicalRuntimeValueV1>(
          "c17.unit_romr_completed_codec_mismatch",
          "the framework unit-residence completed projection requires its "
          "exact successor-state codec");
    }
    return Result<CanonicalRuntimeValueV1>::success(
        input.completed_edge.successor_state);
  }
  if (!event_operations_.has_value()) {
    return audit_failure<CanonicalRuntimeValueV1>(
        "c17.sealed_romr_completed_unavailable",
        "the sealed framework has no declared completed-edge projection "
        "authority");
  }
  auto operation =
      event_operations_->completed_edge_projection.fresh_operation();
  return operation(input);
}

Result<AuditedCompiledFramework> audit_v0_causality(
    CompiledFrameworkCandidate candidate, PlugDescriptor descriptor,
    KernelAccess access) {
  auto descriptor_shape = validate_plug_descriptor_v1(descriptor);
  if (!descriptor_shape) {
    return Result<AuditedCompiledFramework>::failure(
        descriptor_shape.error());
  }
  auto access_shape = validate_kernel_access_shape_v1(access);
  if (!access_shape) {
    return Result<AuditedCompiledFramework>::failure(access_shape.error());
  }
  auto sampler_contract = validate_sealed_sampler_contract(access);
  if (!sampler_contract) {
    return Result<AuditedCompiledFramework>::failure(
        sampler_contract.error());
  }
  const SurrogatePlug& candidate_plug =
      detail::C17CoreAccess::plug(candidate);
  CompiledFrameworkCandidateInputsV1& inputs =
      detail::C17CoreAccess::inputs(candidate);
  if (const auto* sampler =
          std::get_if<NormalizedConditionalSamplerAccess>(&access);
      sampler != nullptr && sampler->contract().has_value()) {
    if (sampler->contract()->persistent_state_schema !=
        inputs.exact_state_schema.reduced_state_schema_digest) {
      return audit_failure<AuditedCompiledFramework>(
          "c17.sampler_persistent_state_schema_mismatch",
          "the conditional sampler persistent-state identity must equal "
          "the exact reduced-state schema retained by the V0 candidate");
    }
    if (sampler->contract()->configured_arrival_law !=
        inputs.framework_seed.bindings.problem_fingerprints
            .compiled_arrival) {
      return audit_failure<AuditedCompiledFramework>(
          "c17.sampler_configured_arrival_binding_mismatch",
          "the normalized sampler must bind the exact configured-arrival "
          "fingerprint retained by the V0 framework seed");
    }
    if (descriptor.core.deployed_targets.size() > 1U &&
        !sampler->contract()->common_projection_identity.has_value()) {
      return audit_failure<AuditedCompiledFramework>(
          "c17.missing_common_sampler_projection_identity",
          "a multi-target conditional sampler must bind the common action "
          "and arrival projection shared by every target output");
    }
  }
  const Digest256& validated_descriptor_digest =
      detail::C17CoreAccess::validated_descriptor_digest(candidate);
  const ArtifactValidationBindingsV1& artifact_bindings =
      detail::C17CoreAccess::artifact_bindings(candidate);
  const Digest256& validated_contract_digest =
      detail::C17CoreAccess::validated_contract_digest(candidate);
  const MetricSupportManifest& structural_manifest =
      detail::C17CoreAccess::structural_manifest(candidate);
  const bool access_matches_plug =
      C17AuditedFrameworkMint::same_raw_access(candidate_plug, access);
  auto canonical_access_identity =
      C17AuditedFrameworkMint::canonical_raw_access_identity(access);
  if (!canonical_access_identity) {
    return Result<AuditedCompiledFramework>::failure(
        canonical_access_identity.error());
  }
  auto bindings = validate_candidate_bindings(
      candidate_plug, inputs, validated_descriptor_digest, artifact_bindings,
      validated_contract_digest, structural_manifest, descriptor, access,
      access_matches_plug, canonical_access_identity.value());
  if (!bindings) {
    return Result<AuditedCompiledFramework>::failure(bindings.error());
  }
  auto direct_services = validate_direct_metric_services(inputs, access);
  if (!direct_services) {
    return Result<AuditedCompiledFramework>::failure(
        direct_services.error());
  }
  auto direct_factor = validate_direct_underlying_factor(inputs, access);
  if (!direct_factor) {
    return Result<AuditedCompiledFramework>::failure(
        direct_factor.error());
  }
  auto mark_carriers =
      validate_mark_carriers(descriptor, inputs.exact_state_schema);
  if (!mark_carriers) {
    return Result<AuditedCompiledFramework>::failure(mark_carriers.error());
  }
  auto capabilities = validate_program_capabilities(
      candidate_plug, inputs, descriptor, access);
  if (!capabilities) {
    return Result<AuditedCompiledFramework>::failure(capabilities.error());
  }
  auto three_bin =
      validate_three_bin_adapter(candidate_plug, inputs, descriptor, access);
  if (!three_bin) {
    return Result<AuditedCompiledFramework>::failure(three_bin.error());
  }
  auto finite_prefix = validate_finite_prefix_constant_tail_adapter(
      candidate_plug, inputs, descriptor, access);
  if (!finite_prefix) {
    return Result<AuditedCompiledFramework>::failure(
        finite_prefix.error());
  }
  auto declared_residence = validate_declared_residence_contract(
      candidate_plug, inputs, descriptor, access);
  if (!declared_residence) {
    return Result<AuditedCompiledFramework>::failure(
        declared_residence.error());
  }

  const bool enumerable = program_has_row(candidate_plug, inputs);
  const bool realizable = program_has_slot(candidate_plug, inputs);
  const bool closed_scalar =
      closed_scalar_response_mode_v1(inputs.causal_program.mode);
  const bool direct_only =
      inputs.causal_program.mode ==
      ExactCausalProgramModeV1::bound_direct_decoder;
  const bool inspected_rows =
      enumerable && !inputs.causal_program.reachable_audit_states.empty();
  const OptimizerCallLedgerSnapshot optimizer_before =
      inputs.optimizer_context.ledger_snapshot();
  if (enumerable) {
    for (const ReducedStateV1& state :
         inputs.causal_program.reachable_audit_states) {
      auto source_domain = inputs.exact_state_schema.validate_domain(state);
      if (!source_domain) {
        return Result<AuditedCompiledFramework>::failure(
            source_domain.error());
      }
      auto replay_probe = detail::C17CoreAccess::compose_for_audit_probe(
          candidate, descriptor, state);
      if (!replay_probe) {
        return Result<AuditedCompiledFramework>::failure(
            replay_probe.error());
      }
      auto row = detail::C17CoreAccess::compose_for_audit(
          candidate, descriptor, state);
      if (!row) {
        return Result<AuditedCompiledFramework>::failure(row.error());
      }
      if (!same_complete_marked_row(replay_probe.value(), row.value())) {
        return audit_failure<AuditedCompiledFramework>(
            "c17.enumerable_operation_not_immutable",
            "replaying the same exact five-stage row changed canonical atom "
            "order, complete outcomes, masses, marks, diagnostics, or "
            "derived row images");
      }
      auto row_shape = validate_audited_row(
          row.value(), state, descriptor, inputs.exact_state_schema,
          inputs.instance, closed_scalar);
      if (!row_shape) {
        return Result<AuditedCompiledFramework>::failure(row_shape.error());
      }
    }
  }
  if (closed_scalar &&
      inputs.optimizer_context.ledger_snapshot() != optimizer_before) {
    if (inputs.causal_program.mode ==
        ExactCausalProgramModeV1::closed_three_bin_scalar) {
      return audit_failure<AuditedCompiledFramework>(
          "c17.three_bin_optimizer_path_invoked",
          "the closed three-bin audit must not invoke the physical optimizer "
          "or consume its execution ledger");
    }
    return audit_failure<AuditedCompiledFramework>(
        "c17.finite_prefix_constant_tail_optimizer_path_invoked",
        "the closed finite-prefix/constant-tail audit must not invoke the "
        "physical optimizer or consume its execution ledger");
  }

  auto unit_residence_result = validate_unit_residence_contract(
      inputs, descriptor, closed_scalar, enumerable, realizable);
  if (!unit_residence_result) {
    return Result<AuditedCompiledFramework>::failure(
        unit_residence_result.error());
  }
  const bool unit_residence = unit_residence_result.value();

  auto seal_identity = execution_seal_digest(
      inputs, descriptor, canonical_access_identity.value(),
      direct_factor.value());
  if (!seal_identity) {
    return Result<AuditedCompiledFramework>::failure(seal_identity.error());
  }

  const V0EvidenceScopeV1 inspected_scope =
      V0EvidenceScopeV1::reachable_enumerated;
  const V0EvidenceScopeV1 law_scope =
      declared_residence.value()
          ? V0EvidenceScopeV1::declared
          : (inspected_rows ? inspected_scope
                            : V0EvidenceScopeV1::declared);
  const V0EvidenceScopeV1 action_scope =
      inspected_rows ? inspected_scope
                     : (closed_scalar
                            ? V0EvidenceScopeV1::construction_enforced
                            : V0EvidenceScopeV1::declared);
  const bool entrance_mark_declared = std::ranges::any_of(
      descriptor.marks, [](const RuntimeMarkDescriptorV1& mark) {
        return mark.decoder_source ==
               MarkDecoderSourceV1::entrance_realization;
      });
  std::vector<V0WitnessEntryV1> entries;
  if (direct_only) {
    entries = direct_factor_entries(*direct_factor.value());
  } else {
    entries.reserve(11U);
    entries.push_back(entry(
      V0ObligationV1::normalized_typed_laws, law_scope,
      inspected_rows
          ? "the same exact composer inspected every supplied audit state"
          : "normalization is retained at its declared procedural scope"));
    entries.push_back(entry(
      V0ObligationV1::causal_factorization,
      V0EvidenceScopeV1::construction_enforced,
      "the only composer publishes C-minus, resolver, arrival, C-plus, Psi"));
    entries.push_back(entry(
      V0ObligationV1::configured_arrival_exactly_once,
      V0EvidenceScopeV1::construction_enforced,
      "one move-only arrival capability is consumed per upstream action"));
    entries.push_back(entry(
      V0ObligationV1::common_action_feasibility, action_scope,
      closed_scalar
          ? "the singleton action is individually feasible and makes no common multi-target schedule claim"
          : "resolved actions retain one common feasible schedule"));
    entries.push_back(entry(
        V0ObligationV1::empty_queue_eligibility, action_scope,
        "actual departure is D=s times the positive-backlog indicator"));
    entries.push_back(entry(
        V0ObligationV1::exact_sign_and_tie_resolution, action_scope,
        closed_scalar
            ? "the closed forced-class adapter performs no second tie or optimizer query"
            : "the configured exact resolver evidence is retained on each action"));
    entries.push_back(entry(
        V0ObligationV1::exact_update_and_ownership,
        V0EvidenceScopeV1::construction_enforced,
        "Psi alone rebuilds exact coordinates and C-plus can write only unresolved fields"));
    entries.push_back(entry(
        V0ObligationV1::reduced_state_domain_closure,
        inspected_rows ? inspected_scope : V0EvidenceScopeV1::declared,
        "every published successor passes the sealed reduced-state predicate"));
    entries.push_back(entry(
        V0ObligationV1::row_concatenation,
        declared_residence.value()
            ? V0EvidenceScopeV1::declared
            : (inspected_rows ? inspected_scope
                              : V0EvidenceScopeV1::declared),
        declared_residence.value()
            ? "event entry, adapted positive stop, terminal re-entry, and both slot projections retain their exact declared topology; procedural termination remains declared"
            : "successors inhabit the next predecision state domain"));
    entries.push_back(entry(
        V0ObligationV1::requested_mark_observability,
        entrance_mark_declared
            ? V0EvidenceScopeV1::declared
            : (inspected_rows ? inspected_scope
                              : V0EvidenceScopeV1::declared),
        entrance_mark_declared
            ? "within-slot marks retain their causal stage and the entrance label retains one exactly bound framework entry decoder"
            : "runtime marks retain their common path and reveal stage"));
    entries.push_back(entry(
        V0ObligationV1::framework_unit_residence,
        unit_residence ? V0EvidenceScopeV1::construction_enforced
                       : V0EvidenceScopeV1::not_applicable,
        unit_residence
            ? "identity entry, one completed slot, post-edge stop, and exact successor terminal are framework fixed"
            : (closed_scalar
                   ? "the accepted contract contains no temporal route requiring the unit wrapper"
                   : "the framework unit wrapper applies only to a closed scalar law")));
  }

  const ExactReducedStateSchemaV1& schema = inputs.exact_state_schema;
  V0WitnessBindingsV1 report_bindings{
      inputs.framework_seed.bindings.problem_fingerprints.resolved_instance,
      descriptor.descriptor_digest,
      canonical_access_identity.value(),
      schema.ownership_schema_digest,
      schema.exact_update_schema_digest};
  auto report = detail::C17CoreAccess::v0_report(
      std::move(report_bindings), std::move(entries), true);
  return C17AuditedFrameworkMint::seal(
      std::move(candidate), std::move(descriptor), std::move(access),
      std::move(report), std::move(seal_identity).value());
}

Result<AuditedCompiledFramework> audit_v0_direct_composite(
    DirectMetricCompositeCandidateV1 candidate) {
  const OptimizerCallLedgerSnapshot optimizer_before =
      candidate.optimizer_context_.ledger_snapshot();
  if (!optimizer_before.context_active()) {
    return audit_failure<AuditedCompiledFramework>(
        "c17.direct_composite_optimizer_inactive",
        "the direct composite candidate must own the active request-local "
        "optimizer context before auditing its causal factor");
  }

  RuntimeDirectFactorRecipeV1& factor_recipe =
      candidate.direct_activation_.factor_recipe_;
  OptimizerFreeFrameworkCandidateInputsV1& factor_source =
      factor_recipe.inputs_;
  CompiledFrameworkCandidateInputsV1 factor_inputs{
      std::move(factor_source.build_identity),
      std::move(factor_source.final_request_identity),
      std::move(factor_source.instance),
      std::move(factor_source.configured_arrival),
      std::move(factor_source.accepted_contract),
      std::move(factor_source.realized_metric_bindings),
      std::move(factor_source.exact_state_schema),
      std::move(factor_source.causal_program),
      std::nullopt,
      std::move(candidate.optimizer_context_),
      std::move(factor_source.framework_seed)};
  auto factor_result =
      C17AuditedFrameworkMint::audit_direct_factor_recipe(
      std::move(factor_recipe.raw_candidate_), factor_inputs,
      candidate.direct_validated_plug_);
  const OptimizerCallLedgerSnapshot optimizer_after =
      factor_inputs.optimizer_context.ledger_snapshot();
  auto factor_calls = checked_subtract(
      optimizer_after.calls_reserved(), optimizer_before.calls_reserved());
  if (!factor_calls || !optimizer_after.context_active() ||
      optimizer_after.assigned_max_calls() !=
          optimizer_before.assigned_max_calls()) {
    return audit_failure<AuditedCompiledFramework>(
        "c17.direct_composite_optimizer_ledger_changed",
        "the causal-factor audit must preserve the one optimizer ledger, "
        "its assignment, and monotone call accounting");
  }
  if (factor_calls.value() >
      candidate.maximum_factor_optimizer_calls_) {
    return audit_failure<AuditedCompiledFramework>(
        "c17.direct_factor_optimizer_bound_exceeded",
        "the causal-factor V0 audit exceeded its callback-free registered "
        "optimizer-call bound");
  }
  if (!factor_result) {
    return Result<AuditedCompiledFramework>::failure(
        factor_result.error());
  }
  DirectFactorWitnessV1 factor_witness =
      std::move(factor_result).value();

  // Recover the same move-only context.  The raw recipe and every factor
  // callback were destroyed inside the private audit above; only immutable
  // witness data survives into the direct seal.
  OptimizerExecutionContext optimizer_context(
      std::move(factor_inputs.optimizer_context));

  PlugDescriptor direct_descriptor =
      candidate.direct_validated_plug_.descriptor();
  OptimizerFreeFrameworkCandidateInputsV1& direct_source =
      candidate.direct_inputs_;
  DirectMetricSealServicesV1 direct_services(
      std::move(candidate.direct_activation_.domain_),
      std::move(factor_witness));
  CompiledFrameworkCandidateInputsV1 direct_inputs{
      std::move(direct_source.build_identity),
      std::move(direct_source.final_request_identity),
      std::move(direct_source.instance),
      std::move(direct_source.configured_arrival),
      std::move(direct_source.accepted_contract),
      std::move(direct_source.realized_metric_bindings),
      std::move(direct_source.exact_state_schema),
      std::move(direct_source.causal_program),
      std::optional<DirectMetricSealServicesV1>{
          std::move(direct_services)},
      std::move(optimizer_context),
      std::move(direct_source.framework_seed)};
  CompiledFrameworkCandidate direct_candidate =
      C17AuditedFrameworkMint::make_candidate(
          std::move(candidate.direct_validated_plug_),
          std::move(direct_inputs));
  return audit_v0_causality(
      std::move(direct_candidate), std::move(direct_descriptor),
      std::move(candidate.direct_kernel_access_));
}

Result<AuditedCompiledFramework> C17AuditedFrameworkMint::seal(
    CompiledFrameworkCandidate candidate, PlugDescriptor descriptor,
    KernelAccess access, V0WitnessReport report,
    Digest256 execution_seal_identity) {
  if (!report.passed()) {
    return audit_failure<AuditedCompiledFramework>(
        "c17.cannot_seal_failed_v0_report",
        "the production mint accepts only a passing complete V0 report");
  }

  AuditedFrameworkSeedV1 seed = candidate.inputs_.framework_seed;
  const bool unit_romr = closed_scalar_response_mode_v1(
      candidate.inputs_.causal_program.mode);
  std::optional<TemporalEventOperationsV1> event_operations;
  if (const CausalSurrogateOperationsV1* operations =
          causal_operations_v1(candidate.plug_);
      operations != nullptr && operations->event.has_value()) {
    event_operations = *operations->event;
  }
  std::shared_ptr<const surrogate::detail::SealedRomrOpsAuthority>
      romr_ops_authority;
  if (unit_romr || event_operations.has_value()) {
    CodecIdentityV1 indicator_codec{
        "mwperf.c20.unit-stop-indicator", 1U};
    std::vector<std::byte> true_value{std::byte{0x01}};
    romr_ops_authority =
        std::shared_ptr<const surrogate::detail::SealedRomrOpsAuthority>(
            new surrogate::detail::SealedRomrOpsAuthority(
                unit_romr,
                candidate.inputs_.exact_state_schema.reduced_state_codec,
                std::move(indicator_codec), std::move(true_value),
                std::move(event_operations)));
  }
  // The C16 plug union necessarily embeds the raw access.  V0 has already
  // proved that the separately supplied value shares that exact immutable
  // operation.  Detach and destroy the embedded alias before sealing so the
  // core retains exactly one callable access owner.
  detach_raw_access(candidate.plug_);

  AuditedCompiledFramework framework(
      std::move(seed.bindings), std::move(seed.target_selection),
      std::move(seed.reduced_state_codec), std::move(seed.selection_support),
      std::move(seed.initial_selection_authority),
      std::move(seed.initial_mapper),
      std::move(seed.exact_state_schema_validator),
      std::move(seed.reduced_state_domain_validator),
      std::move(seed.physical_atom_projection_validator));
  auto core = std::make_shared<surrogate::detail::SealedFrameworkCore>(
      std::move(candidate.plug_), std::move(candidate.artifact_bindings_),
      std::move(candidate.validated_contract_digest_),
      std::move(candidate.validated_structural_manifest_),
      std::move(execution_seal_identity),
      framework.seal_,
      std::move(romr_ops_authority),
      std::move(candidate.inputs_), std::move(descriptor), std::move(access),
      std::move(report));
  framework.c17_core_ = std::move(core);
  return Result<AuditedCompiledFramework>::success(std::move(framework));
}

bool C17AuditedFrameworkMint::same_raw_access(
    const SurrogatePlug& plug, const KernelAccess& supplied) noexcept {
  const KernelAccess& embedded = kernel_access_v1(plug);
  if (embedded.index() != supplied.index()) {
    return false;
  }
  return std::visit(
      [](const auto& left, const auto& right) noexcept {
        using Left = std::remove_cvref_t<decltype(left)>;
        using Right = std::remove_cvref_t<decltype(right)>;
        if constexpr (!std::same_as<Left, Right>) {
          return false;
        } else if constexpr (
            std::same_as<Left, FiniteEnumeratedRowAccess> ||
            std::same_as<Left, SparseRowAccess>) {
          return left.shape() == right.shape() &&
                 left.operation_.shares_operation_with(right.operation_);
        } else if constexpr (
            std::same_as<Left, NormalizedConditionalSamplerAccess>) {
          const auto same_optional_operation = [](const auto& lhs,
                                                  const auto& rhs) {
            return lhs.has_value() == rhs.has_value() &&
                   (!lhs.has_value() ||
                    lhs->shares_operation_with(*rhs));
          };
          return left.shape() == right.shape() &&
                 left.contract_ == right.contract_ &&
                 left.ratio_contract_ == right.ratio_contract_ &&
                 left.innovation_contract_ == right.innovation_contract_ &&
                 left.operation_.shares_operation_with(right.operation_) &&
                 left.sample_validator_.shares_operation_with(
                     right.sample_validator_) &&
                 same_optional_operation(left.support_enumerator_,
                                         right.support_enumerator_) &&
                 same_optional_operation(left.support_query_,
                                         right.support_query_) &&
                 same_optional_operation(left.ratio_, right.ratio_) &&
                 same_optional_operation(left.innovation_,
                                         right.innovation_);
        } else if constexpr (std::same_as<Left, AnalyticTransformAccess>) {
          return left.shape() == right.shape() &&
                 equal_span(left.decoder_ids(), right.decoder_ids()) &&
                 left.operation_.shares_operation_with(right.operation_);
        } else if constexpr (
            std::same_as<Left, FiniteParameterAnalyticFamilyAccess>) {
          return left.shape() == right.shape() &&
                 left.family() == right.family() &&
                 left.operation_.shares_operation_with(right.operation_);
        } else if constexpr (
            std::same_as<Left, ProceduralResidenceGeneratorAccess>) {
          return left.shape() == right.shape() &&
                 left.operation_identity() == right.operation_identity() &&
                 left.positive_residence_declared() ==
                     right.positive_residence_declared() &&
                 left.operation_.shares_operation_with(right.operation_);
        } else {
          static_assert(std::same_as<Left, RawDirectDecoderAccess>);
          return left.domain() == right.domain() &&
                 left.request_encoder_.shares_operation_with(
                     right.request_encoder_) &&
                 left.operation_.shares_operation_with(right.operation_) &&
                 left.result_validator_.shares_operation_with(
                     right.result_validator_);
        }
      },
      embedded, supplied);
}

Result<Digest256> C17AuditedFrameworkMint::canonical_raw_access_identity(
    const KernelAccess& access) {
  C17IdentityEncoder encoder;
  encoder.enumeration(runtime_access_tag_v1(access));
  std::visit(
      [&encoder](const auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, FiniteEnumeratedRowAccess> ||
                      std::same_as<Active, SparseRowAccess>) {
          encode_transition_shape(encoder, active.shape());
        } else if constexpr (
            std::same_as<Active, NormalizedConditionalSamplerAccess>) {
          encode_transition_shape(encoder, active.shape());
          encoder.boolean(active.contract().has_value());
          if (active.contract().has_value()) {
            encode_sampler_contract(encoder, *active.contract());
          }
          encoder.boolean(active.has_sample_validator());
          encoder.boolean(active.ratio_contract().has_value());
          if (active.ratio_contract().has_value()) {
            encode_ratio_contract(encoder, *active.ratio_contract());
          }
          encoder.boolean(active.innovation_contract().has_value());
          if (active.innovation_contract().has_value()) {
            encode_innovation_contract(
                encoder, *active.innovation_contract());
          }
        } else if constexpr (std::same_as<Active,
                                             AnalyticTransformAccess>) {
          encoder.codec(active.shape().argument_codec);
          encoder.codec(active.shape().result_codec);
          encoder.count(active.decoder_ids().size());
          for (const RuntimeDecoderIdV1& decoder : active.decoder_ids()) {
            encoder.id(decoder);
          }
        } else if constexpr (
            std::same_as<Active, FiniteParameterAnalyticFamilyAccess>) {
          encoder.codec(active.shape().argument_codec);
          encoder.codec(active.shape().response_codec);
          encoder.string(active.family().family_id);
          encoder.u32(active.family().family_version);
          encoder.codec(active.family().parameter_schema);
          encoder.codec(active.family().domain_schema);
        } else if constexpr (
            std::same_as<Active, ProceduralResidenceGeneratorAccess>) {
          encoder.codec(active.shape().entrance_state_codec);
          encoder.codec(active.shape().continuation_state_codec);
          encoder.codec(active.shape().terminal_state_codec);
          encoder.codec(active.shape().reentry_state_codec);
          encoder.count(active.shape().ordered_mark_codecs.size());
          for (const CodecIdentityV1& codec :
               active.shape().ordered_mark_codecs) {
            encoder.codec(codec);
          }
          encoder.optional_count(active.shape().maximum_residence_slots);
          encoder.id(active.operation_identity().operation_id);
          encoder.u32(active.operation_identity().operation_version);
          encoder.codec(active.operation_identity().event_schema);
          encoder.boolean(active.positive_residence_declared());
        } else {
          static_assert(std::same_as<Active, RawDirectDecoderAccess>);
          const RawDirectDecoderDomainV1& domain = active.domain();
          encoder.id(domain.metric_domain.decoder_key);
          // The normalized canonical request digest already binds the exact
          // MetricRequestParametersV1 alternative and value.
          encoder.digest(domain.canonical_request_domain_digest);
          encoder.digest(domain.build_request_digest);
          encoder.digest(domain.target_selection_digest);
          encoder.digest(domain.ordered_target_digest);
          encoder.digest(domain.selection_digest);
          encoder.digest(domain.configured_arrival_digest);
          encoder.digest(domain.accepted_contract_digest);
          encoder.codec(domain.request_codec);
          encoder.codec(domain.result_codec);
        }
      },
      access);
  return sha256_domain_separated("mwperf.c17.raw-access.v1",
                                 encoder.bytes());
}

Result<Digest256> detail::canonical_kernel_access_identity_for_candidate(
    const KernelAccess& access) {
  return C17AuditedFrameworkMint::canonical_raw_access_identity(access);
}

Result<Digest256> detail::audited_framework_execution_seal_digest(
    const AuditedCompiledFramework& framework) {
  const auto core = framework.c17_core_;
  if (!core || !core->report().passed()) {
    return audit_failure<Digest256>(
        "c17.execution_seal_requires_v0",
        "the execution-seal identity is available only from a passing V0-audited framework");
  }
  return Result<Digest256>::success(core->execution_seal_digest());
}

void C17AuditedFrameworkMint::detach_raw_access(SurrogatePlug& plug) {
  std::visit(
      [](auto& active) {
        KernelAccess embedded_alias = std::move(active.access);
        (void)embedded_alias;
      },
      plug);
}

Result<DirectMetricAccess>
C17AuditedFrameworkMint::issue_direct_metric_access(
    const AuditedCompiledFramework& framework) {
  const auto core = framework.c17_core_;
  if (!core || !core->report().passed()) {
    return audit_failure<DirectMetricAccess>(
        "c17.direct_metric_access_requires_v0",
        "direct metric access can be issued only by its passing V0 seal");
  }
  const auto* raw = std::get_if<RawDirectDecoderAccess>(&core->access());
  const auto& services = core->inputs().direct_metric_services;
  if (raw == nullptr || !services.has_value() || !raw->has_operation() ||
      core->inputs().causal_program.mode !=
          ExactCausalProgramModeV1::bound_direct_decoder) {
    return audit_failure<DirectMetricAccess>(
        "c17.direct_metric_access_unavailable",
        "the sealed framework does not own a complete audited raw direct "
        "decoder domain");
  }

  RawDirectRequestEncoderV1 request_encoder =
      raw->fresh_request_encoder();
  RawDirectDecoderCallbackV1 raw_decoder = raw->fresh_operation();
  RawDirectResultValidatorV1 result_validator =
      raw->fresh_result_validator();
  const CodecIdentityV1 request_codec = raw->domain().request_codec;
  SealedDirectMetricDecoderV1 decoder =
      [encode = std::move(request_encoder),
       raw_decoder = std::move(raw_decoder),
       request_codec](const MetricRequest& request) {
        auto encoded = encode(request);
        if (!encoded) {
          return Result<MetricValue>::failure(encoded.error());
        }
        if (encoded.value().codec != request_codec) {
          return audit_failure<MetricValue>(
              "c17.direct_metric_request_codec_mismatch",
              "the sealed request encoder returned a value outside the "
              "moved raw decoder's exact request codec");
        }
        return raw_decoder(encoded.value());
      };
  return Result<DirectMetricAccess>::success(DirectMetricAccess(
      framework.seal_, framework.bindings_, services->domain(),
      std::move(decoder), std::move(result_validator)));
}

namespace detail {

const SurrogatePlug& C17CoreAccess::plug(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.plug_;
}

const Digest256& C17CoreAccess::validated_descriptor_digest(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.validated_descriptor_digest_;
}

CompiledFrameworkCandidateInputsV1& C17CoreAccess::inputs(
    CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.inputs_;
}

const CompiledFrameworkCandidateInputsV1& C17CoreAccess::inputs(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.inputs_;
}

const ArtifactValidationBindingsV1& C17CoreAccess::artifact_bindings(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.artifact_bindings_;
}

const Digest256& C17CoreAccess::validated_contract_digest(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.validated_contract_digest_;
}

const MetricSupportManifest& C17CoreAccess::structural_manifest(
    const CompiledFrameworkCandidate& candidate) noexcept {
  return candidate.validated_structural_manifest_;
}

Result<MarkedKernelRow> C17CoreAccess::compose_for_audit(
    CompiledFrameworkCandidate& candidate, const PlugDescriptor& descriptor,
    const ReducedStateV1& state) {
  return compose_candidate_row(candidate.plug_, descriptor, candidate.inputs_,
                               state);
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedCompiledFramework& framework) noexcept {
  return framework.c17_core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedInitialMapper& mapper) noexcept {
  return mapper.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedRowProvider& provider) noexcept {
  return provider.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedSlotExecutor& executor) noexcept {
  return executor.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedResponseLaw& response) noexcept {
  return response.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedThreeBinResponse& response) noexcept {
  return response.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedFinitePrefixConstantTailResponse& response) noexcept {
  return response.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedPhaseResponse& response) noexcept {
  return response.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedFixedPointFamily& family) noexcept {
  return family.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedRomrView& view) noexcept {
  return view.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedResidenceProvider& provider) noexcept {
  return provider.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedTemporalFramework& framework) noexcept {
  return framework.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedCylinderLaw& law) noexcept {
  return law.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedTemporalKernel& kernel) noexcept {
  return kernel.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedTemporalLaw& law) noexcept {
  return law.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedSamplerDescriptor& descriptor) noexcept {
  return descriptor.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedExactInnovationKernel& kernel) noexcept {
  return kernel.core_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore> C17CoreAccess::core(
    const AuditedTargetDensityRatio& ratio) noexcept {
  return ratio.core_;
}

AuditedInitialMapper C17CoreAccess::initial_mapper(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedInitialMapper(std::move(core));
}

AuditedRowProvider C17CoreAccess::row_provider(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedRowProvider(std::move(core));
}

AuditedSlotExecutor C17CoreAccess::slot_executor(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedSlotExecutor(std::move(core));
}

AuditedResponseLaw C17CoreAccess::response_law(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedResponseLaw(std::move(core));
}

AuditedThreeBinResponse C17CoreAccess::three_bin_response(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedThreeBinResponse(std::move(core));
}

AuditedFinitePrefixConstantTailResponse
C17CoreAccess::finite_prefix_constant_tail_response(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedFinitePrefixConstantTailResponse(std::move(core));
}

AuditedPhaseResponse C17CoreAccess::phase_response(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedPhaseResponse(std::move(core));
}

AuditedFixedPointFamily C17CoreAccess::fixed_point_family(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedFixedPointFamily(std::move(core));
}

AuditedRomrView C17CoreAccess::romr_view(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedRomrView(std::move(core));
}

AuditedResidenceProvider C17CoreAccess::residence_provider(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedResidenceProvider(std::move(core));
}

AuditedTemporalFramework C17CoreAccess::temporal_framework(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedTemporalFramework(std::move(core));
}

AuditedSamplerDescriptor C17CoreAccess::sampler_descriptor(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core) {
  return AuditedSamplerDescriptor(std::move(core));
}

AuditedExactInnovationKernel C17CoreAccess::exact_innovation_kernel(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
    Digest256 representation_binding) {
  return AuditedExactInnovationKernel(
      std::move(core), std::move(representation_binding));
}

AuditedTargetDensityRatio C17CoreAccess::target_density_ratio(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
    Digest256 plan_binding) {
  return AuditedTargetDensityRatio(std::move(core),
                                   std::move(plan_binding));
}

}  // namespace detail

Result<AuditedInitialMapper> audited_initial_mapper(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !initial_mapper_applicable(*core)) {
    return audit_failure<AuditedInitialMapper>(
        "c17.audited_initial_mapper_unavailable",
        "only a passing causal seal with its validated initial mapping "
        "authority can issue an initial-mapper view");
  }
  return Result<AuditedInitialMapper>::success(
      detail::C17CoreAccess::initial_mapper(core));
}

Result<AuditedRowProvider> audited_row_provider(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !row_provider_applicable(*core)) {
    return audit_failure<AuditedRowProvider>(
        "c17.audited_row_unavailable",
        "the sealed framework has no V0-approved enumerable causal row for "
        "an accepted deterministic row backend");
  }
  return Result<AuditedRowProvider>::success(
      detail::C17CoreAccess::row_provider(core));
}

Result<AuditedSlotExecutor> audited_slot_executor(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !slot_executor_applicable(*core)) {
    return audit_failure<AuditedSlotExecutor>(
        "c17.audited_slot_unavailable",
        "the sealed framework has no V0-approved realized causal slot for "
        "an accepted temporal or conditional Monte Carlo backend");
  }
  return Result<AuditedSlotExecutor>::success(
      detail::C17CoreAccess::slot_executor(core));
}

Result<AuditedResponseLaw> audited_response_law(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !response_law_applicable(*core)) {
    return audit_failure<AuditedResponseLaw>(
        "c17.audited_response_law_unavailable",
        "a response-law view requires a phase-free scalar response and an "
        "accepted analytic metric-family route");
  }
  return Result<AuditedResponseLaw>::success(
      detail::C17CoreAccess::response_law(core));
}

Result<AuditedThreeBinResponse> audited_three_bin_response(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !three_bin_response_applicable(*core)) {
    return audit_failure<AuditedThreeBinResponse>(
        "c17.audited_three_bin_unavailable",
        "the sealed framework is not the V0-approved closed three-bin "
        "scalar response");
  }
  return Result<AuditedThreeBinResponse>::success(
      detail::C17CoreAccess::three_bin_response(core));
}

Result<AuditedFinitePrefixConstantTailResponse>
audited_finite_prefix_constant_tail_response(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) ||
      !finite_prefix_constant_tail_response_applicable(*core)) {
    return audit_failure<AuditedFinitePrefixConstantTailResponse>(
        "c17.audited_finite_prefix_constant_tail_unavailable",
        "the sealed framework is not the V0-approved closed "
        "finite-prefix/constant-tail scalar response");
  }
  return Result<AuditedFinitePrefixConstantTailResponse>::success(
      detail::C17CoreAccess::finite_prefix_constant_tail_response(core));
}

Result<AuditedPhaseResponse> audited_phase_response(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !phase_response_applicable(*core)) {
    return audit_failure<AuditedPhaseResponse>(
        "c17.audited_phase_response_unavailable",
        "a phase-response view requires an accepted analytic scalar law "
        "indexed by the configured predictive phase");
  }
  return Result<AuditedPhaseResponse>::success(
      detail::C17CoreAccess::phase_response(core));
}

Result<AuditedFixedPointFamily> audited_fixed_point_family(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !fixed_point_family_applicable(*core)) {
    return audit_failure<AuditedFixedPointFamily>(
        "c17.audited_fixed_point_family_unavailable",
        "a fixed-point-family view requires analytic access, an accepted "
        "analytic route, and explicit fixed-point selection support");
  }
  return Result<AuditedFixedPointFamily>::success(
      detail::C17CoreAccess::fixed_point_family(core));
}

Result<AuditedRomrView> audited_romr_view(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !romr_applicable(*core)) {
    return audit_failure<AuditedRomrView>(
        "c17.audited_romr_view_unavailable",
        "a ROMR view requires either the framework-owned three-bin unit "
        "residence or an exact audited temporal event contract");
  }
  return Result<AuditedRomrView>::success(
      detail::C17CoreAccess::romr_view(core));
}

Result<AuditedResidenceProvider> audited_residence_provider(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !residence_provider_applicable(*core)) {
    return audit_failure<AuditedResidenceProvider>(
        "c17.audited_residence_provider_unavailable",
        "an enumerable residence provider requires an audited ROMR "
        "contract and its exact composed row");
  }
  return Result<AuditedResidenceProvider>::success(
      detail::C17CoreAccess::residence_provider(core));
}

Result<AuditedTemporalFramework> audited_temporal_framework(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !temporal_framework_applicable(*core)) {
    return audit_failure<AuditedTemporalFramework>(
        "c17.audited_temporal_framework_unavailable",
        "a temporal framework requires an audited ROMR contract and its "
        "composed realized-slot capability");
  }
  return Result<AuditedTemporalFramework>::success(
      detail::C17CoreAccess::temporal_framework(core));
}

Result<AuditedSamplerDescriptor> audited_sampler_descriptor(
    const AuditedCompiledFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !sampler_descriptor_applicable(*core)) {
    return audit_failure<AuditedSamplerDescriptor>(
        "c17.audited_sampler_descriptor_unavailable",
        "a sampler descriptor requires the deployed normalized conditional "
        "sampler access and an accepted C24 row/reward route");
  }
  return Result<AuditedSamplerDescriptor>::success(
      detail::C17CoreAccess::sampler_descriptor(core));
}

Result<AuditedRowProvider> audited_row_provider(
    const AuditedResidenceProvider& provider) {
  const auto core = detail::C17CoreAccess::core(provider);
  if (!passing_core(core) || !residence_provider_applicable(*core)) {
    return audit_failure<AuditedRowProvider>(
        "c17.audited_residence_row_unavailable",
        "the residence provider does not retain its exact unit-residence "
        "row capability");
  }
  return Result<AuditedRowProvider>::success(
      detail::C17CoreAccess::row_provider(core));
}

Result<AuditedRomrView> audited_romr_view(
    const AuditedResidenceProvider& provider) {
  const auto core = detail::C17CoreAccess::core(provider);
  if (!passing_core(core) || !residence_provider_applicable(*core)) {
    return audit_failure<AuditedRomrView>(
        "c17.audited_residence_romr_unavailable",
        "the residence provider does not retain its audited ROMR "
        "operations");
  }
  return Result<AuditedRomrView>::success(
      detail::C17CoreAccess::romr_view(core));
}

Result<AuditedSlotExecutor> audited_slot_executor(
    const AuditedTemporalFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !temporal_framework_applicable(*core)) {
    return audit_failure<AuditedSlotExecutor>(
        "c17.audited_temporal_slot_unavailable",
        "the temporal framework does not retain its unit-residence slot "
        "capability");
  }
  return Result<AuditedSlotExecutor>::success(
      detail::C17CoreAccess::slot_executor(core));
}

Result<AuditedRomrView> audited_romr_view(
    const AuditedTemporalFramework& framework) {
  const auto core = detail::C17CoreAccess::core(framework);
  if (!passing_core(core) || !temporal_framework_applicable(*core)) {
    return audit_failure<AuditedRomrView>(
        "c17.audited_temporal_romr_unavailable",
        "the temporal framework does not retain its audited ROMR "
        "operations");
  }
  return Result<AuditedRomrView>::success(
      detail::C17CoreAccess::romr_view(core));
}

Result<DirectMetricAccess> audited_direct_metric_access(
    const AuditedCompiledFramework& framework) {
  return C17AuditedFrameworkMint::issue_direct_metric_access(framework);
}

const V0WitnessReport& v0_witness_report(
    const AuditedCompiledFramework& framework) {
  return framework.c17_core_->report();
}

}  // namespace mwperf
