#include "mwperf/math/probability.hpp"

#include <array>
#include <charconv>
#include <cmath>
#include <cstddef>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic input_error(std::string code, std::string message,
                                     std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic invariant_error(std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = "pmf_internal_invariant",
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic resource_error(
    const PmfRepresentationBudget& budget, std::string phase) {
  std::vector<std::string> notes;
  if (budget.maximum_integral_bits.has_value()) {
    notes.push_back("maximum_integral_bits " +
                    std::to_string(*budget.maximum_integral_bits));
  }
  notes.push_back("construction phase " + std::move(phase));
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "pmf_integral_bit_budget_exceeded",
      .message =
          "the exact PMF integral representation exceeds its bit budget",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] BigInt absolute(BigInt value) {
  return value < 0 ? -value : value;
}

[[nodiscard]] BigInt gcd_nonnegative(BigInt left, BigInt right) {
  left = absolute(std::move(left));
  right = absolute(std::move(right));
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  return left;
}

[[nodiscard]] std::size_t nonnegative_bit_length(
    const BigInt& value) noexcept {
  if (value == 0) {
    return 0U;
  }
  return static_cast<std::size_t>(boost::multiprecision::msb(value)) + 1U;
}

[[nodiscard]] Result<void> enforce_integral_budget(
    const BigInt& value, const PmfRepresentationBudget& budget,
    std::string phase) {
  if (value < 0) {
    return Result<void>::failure(
        invariant_error("PMF budget check received a negative exact value"));
  }
  if (budget.maximum_integral_bits.has_value() &&
      nonnegative_bit_length(value) > *budget.maximum_integral_bits) {
    return Result<void>::failure(
        resource_error(budget, std::move(phase)));
  }
  return Result<void>::success();
}

// A product of positive integers has either a_bits+b_bits-1 or
// a_bits+b_bits bits.  This lower-bound check rejects provably over-budget LCM
// products before allocating the product itself.  The exact post-check handles
// the one-bit ambiguous case.
[[nodiscard]] bool product_provably_exceeds_budget(
    const BigInt& left, const BigInt& right,
    const PmfRepresentationBudget& budget) noexcept {
  if (!budget.maximum_integral_bits.has_value()) {
    return false;
  }
  const std::size_t maximum = *budget.maximum_integral_bits;
  const std::size_t left_bits = nonnegative_bit_length(left);
  const std::size_t right_bits = nonnegative_bit_length(right);
  if (left_bits == 0U || right_bits == 0U) {
    return false;
  }
  if (left_bits > maximum || right_bits > maximum) {
    return true;
  }
  // left_bits + right_bits - 1 > maximum, written without overflow.
  return left_bits > maximum - right_bits + 1U;
}

[[nodiscard]] bool rational_equal(const ExactRational& left,
                                  const ExactRational& right) {
  return left.numerator() == right.numerator() &&
         left.denominator() == right.denominator();
}

[[nodiscard]] bool is_probability_value(const ExactRational& value) {
  return value.numerator() >= 0 && value.numerator() <= value.denominator();
}

[[nodiscard]] bool absolute_value_at_most(const ExactRational& value,
                                          const ExactRational& bound) {
  if (bound.numerator() < 0) {
    return false;
  }
  return absolute(value.numerator()) * bound.denominator() <=
         bound.numerator() * value.denominator();
}

[[nodiscard]] Result<ExactRational> make_rational(BigInt numerator,
                                                  BigInt denominator) {
  auto value = ExactRational::make(std::move(numerator),
                                   std::move(denominator));
  if (!value.has_value()) {
    return Result<ExactRational>::failure(
        invariant_error("exact PMF arithmetic produced an invalid rational"));
  }
  return value;
}

[[nodiscard]] Result<BigNat> make_big_nat(BigInt value) {
  auto result = BigNat::from_big_int(std::move(value));
  if (!result.has_value()) {
    return Result<BigNat>::failure(invariant_error(
        "exact PMF arithmetic produced a negative integral mass"));
  }
  return result;
}

[[nodiscard]] long double compensated_sum(
    const std::span<const long double> values) noexcept {
  long double sum = 0.0L;
  long double correction = 0.0L;
  for (const long double value : values) {
    const long double next = sum + value;
    if (std::fabs(sum) >= std::fabs(value)) {
      correction += (sum - next) + value;
    } else {
      correction += (value - next) + sum;
    }
    sum = next;
  }
  return sum + correction;
}

[[nodiscard]] long double compensated_authored_mass(
    const std::span<const AuthoredProbability> authored) noexcept {
  long double sum = 0.0L;
  long double correction = 0.0L;
  for (const AuthoredProbability& probability : authored) {
    const long double value = probability.numerical_image();
    const long double next = sum + value;
    if (std::fabs(sum) >= std::fabs(value)) {
      correction += (sum - next) + value;
    } else {
      correction += (value - next) + sum;
    }
    sum = next;
  }
  return sum + correction;
}

[[nodiscard]] std::string format_long_double(const long double value) {
  std::array<char, 128> buffer{};
  const auto converted = std::to_chars(
      buffer.data(), buffer.data() + buffer.size(), value,
      std::chars_format::scientific,
      std::numeric_limits<long double>::max_digits10);
  if (converted.ec != std::errc{}) {
    return "unavailable";
  }
  return std::string(buffer.data(), converted.ptr);
}

[[nodiscard]] Result<ExactRational> exact_sum(
    const std::span<const AuthoredProbability> probabilities) {
  auto sum_result = make_rational(BigInt(0), BigInt(1));
  if (!sum_result.has_value()) {
    return sum_result;
  }
  ExactRational sum = std::move(sum_result).value();

  for (const AuthoredProbability& probability : probabilities) {
    const ExactRational& addend = probability.exact_value();
    auto next = make_rational(
        sum.numerator() * addend.denominator() +
            addend.numerator() * sum.denominator(),
        sum.denominator() * addend.denominator());
    if (!next.has_value()) {
      return next;
    }
    sum = std::move(next).value();
  }
  return Result<ExactRational>::success(std::move(sum));
}

[[nodiscard]] bool is_physical_tolerance(const ExactRational& tolerance) {
  return rational_equal(tolerance, physical_pmf_tolerance());
}

[[nodiscard]] Result<void> check_tolerance(
    const ExactRational& tolerance) {
  if (!is_physical_tolerance(tolerance)) {
    return Result<void>::failure(input_error(
        "pmf_invalid_tolerance",
        "the physical PMF tolerance must be exactly 1e-9",
        {"received exact tolerance " + tolerance.to_canonical_string()}));
  }
  return Result<void>::success();
}

[[nodiscard]] ProbabilityNumericalDiagnostics make_numerical_diagnostics(
    const std::span<const AuthoredProbability> authored,
    const std::span<const long double> normalized) noexcept {
  const long double authored_mass = compensated_authored_mass(authored);
  const long double normalized_mass = compensated_sum(normalized);
  return ProbabilityNumericalDiagnostics{
      .authored_mass = authored_mass,
      .authored_residual = authored_mass - 1.0L,
      .normalized_mass = normalized_mass,
      .normalized_residual = normalized_mass - 1.0L,
  };
}

}  // namespace

AuthoredProbability::AuthoredProbability(ExactRational exact_value,
                                         const long double numerical_image)
    : exact_value_(std::move(exact_value)), numerical_image_(numerical_image) {}

AuthoredProbability::AuthoredProbability(AuthoredProbability&& other) noexcept
    : exact_value_(std::move(other.exact_value_)),
      numerical_image_(other.numerical_image_) {
  other.numerical_image_ = 0.0L;
}

AuthoredProbability& AuthoredProbability::operator=(
    AuthoredProbability&& other) noexcept {
  if (this != &other) {
    const long double image = other.numerical_image_;
    exact_value_ = std::move(other.exact_value_);
    numerical_image_ = image;
    other.numerical_image_ = 0.0L;
  }
  return *this;
}

Result<AuthoredProbability> AuthoredProbability::from_exact(
    ExactRational exact_value) {
  if (!is_probability_value(exact_value)) {
    return Result<AuthoredProbability>::failure(input_error(
        "probability_out_of_range",
        "an authored probability must be in the exact interval [0,1]",
        {"received exact value " + exact_value.to_canonical_string()}));
  }

  long double image = exact_value.to_long_double();
  if (exact_value.numerator() == 0) {
    image = 0.0L;
  }
  if (!std::isfinite(image) || image < 0.0L || image > 1.0L) {
    return Result<AuthoredProbability>::failure(invariant_error(
        "conversion of a valid exact probability produced an invalid "
        "numerical image"));
  }
  return Result<AuthoredProbability>::success(
      AuthoredProbability(std::move(exact_value), image));
}

const ExactRational& AuthoredProbability::exact_value() const noexcept {
  return exact_value_;
}

long double AuthoredProbability::numerical_image() const noexcept {
  return numerical_image_;
}

NormalizedPmf::NormalizedPmf(
    std::vector<AuthoredProbability> authored_probabilities,
    ExactRational authored_sum, ExactRational normalization_delta,
    std::vector<ExactRational> normalized_weights,
    std::vector<BigNat> integral_masses,
    std::vector<BigNat> cumulative_masses, BigNat integral_denominator,
    const std::size_t sampling_bit_width,
    const std::size_t sampling_limb_count,
    PmfRepresentationBudget representation_budget,
    std::vector<long double> numerical_image,
    ProbabilityNumericalDiagnostics numerical_diagnostics)
    : authored_probabilities_(std::move(authored_probabilities)),
      authored_sum_(std::move(authored_sum)),
      normalization_delta_(std::move(normalization_delta)),
      normalized_weights_(std::move(normalized_weights)),
      integral_masses_(std::move(integral_masses)),
      cumulative_masses_(std::move(cumulative_masses)),
      integral_denominator_(std::move(integral_denominator)),
      sampling_bit_width_(sampling_bit_width),
      sampling_limb_count_(sampling_limb_count),
      representation_budget_(std::move(representation_budget)),
      numerical_image_(std::move(numerical_image)),
      numerical_diagnostics_(numerical_diagnostics) {}

NormalizedPmf::NormalizedPmf(NormalizedPmf&& other)
    : NormalizedPmf(static_cast<const NormalizedPmf&>(other)) {}

NormalizedPmf& NormalizedPmf::operator=(const NormalizedPmf& other) {
  if (this != &other) {
    NormalizedPmf replacement(other);
    swap(replacement);
  }
  return *this;
}

NormalizedPmf& NormalizedPmf::operator=(NormalizedPmf&& other) {
  return operator=(static_cast<const NormalizedPmf&>(other));
}

void NormalizedPmf::swap(NormalizedPmf& other) noexcept {
  using std::swap;
  swap(authored_probabilities_, other.authored_probabilities_);
  swap(authored_sum_, other.authored_sum_);
  swap(normalization_delta_, other.normalization_delta_);
  swap(normalized_weights_, other.normalized_weights_);
  swap(integral_masses_, other.integral_masses_);
  swap(cumulative_masses_, other.cumulative_masses_);
  swap(integral_denominator_, other.integral_denominator_);
  swap(sampling_bit_width_, other.sampling_bit_width_);
  swap(sampling_limb_count_, other.sampling_limb_count_);
  swap(representation_budget_, other.representation_budget_);
  swap(numerical_image_, other.numerical_image_);
  swap(numerical_diagnostics_, other.numerical_diagnostics_);
}

bool operator==(const NormalizedPmf& left, const NormalizedPmf& right) {
  return left.authored_probabilities_ == right.authored_probabilities_ &&
         left.authored_sum_ == right.authored_sum_ &&
         left.normalization_delta_ == right.normalization_delta_ &&
         left.normalized_weights_ == right.normalized_weights_ &&
         left.integral_masses_ == right.integral_masses_ &&
         left.cumulative_masses_ == right.cumulative_masses_ &&
         left.integral_denominator_ == right.integral_denominator_ &&
         left.sampling_bit_width_ == right.sampling_bit_width_ &&
         left.sampling_limb_count_ == right.sampling_limb_count_ &&
         left.numerical_image_ == right.numerical_image_ &&
         left.numerical_diagnostics_ == right.numerical_diagnostics_;
}

std::size_t NormalizedPmf::size() const noexcept {
  return authored_probabilities_.size();
}

const std::vector<AuthoredProbability>& NormalizedPmf::authored_probabilities()
    const noexcept {
  return authored_probabilities_;
}

const ExactRational& NormalizedPmf::authored_sum() const noexcept {
  return authored_sum_;
}

const ExactRational& NormalizedPmf::normalization_delta() const noexcept {
  return normalization_delta_;
}

const std::vector<ExactRational>& NormalizedPmf::normalized_weights()
    const noexcept {
  return normalized_weights_;
}

const std::vector<BigNat>& NormalizedPmf::integral_masses() const noexcept {
  return integral_masses_;
}

const std::vector<BigNat>& NormalizedPmf::cumulative_masses() const noexcept {
  return cumulative_masses_;
}

const BigNat& NormalizedPmf::integral_denominator() const noexcept {
  return integral_denominator_;
}

std::size_t NormalizedPmf::sampling_bit_width() const noexcept {
  return sampling_bit_width_;
}

std::size_t NormalizedPmf::sampling_limb_count() const noexcept {
  return sampling_limb_count_;
}

const PmfRepresentationBudget& NormalizedPmf::representation_budget()
    const noexcept {
  return representation_budget_;
}

const std::vector<long double>& NormalizedPmf::numerical_image()
    const noexcept {
  return numerical_image_;
}

const ProbabilityNumericalDiagnostics&
NormalizedPmf::numerical_diagnostics() const noexcept {
  return numerical_diagnostics_;
}

const ExactRational& physical_pmf_tolerance() {
  static const ExactRational tolerance = [] {
    auto result = ExactRational::make(BigInt(1), BigInt(1000000000));
    // Both arguments are compile-time-known valid mathematical integers.
    return std::move(result).value();
  }();
  return tolerance;
}

Result<NormalizedPmf> validate_and_normalize_pmf(
    const std::span<const AuthoredProbability> probabilities,
    const ExactRational& tolerance) {
  return validate_and_normalize_pmf_with_budget(
      probabilities, tolerance, PmfRepresentationBudget::unbounded());
}

Result<NormalizedPmf> validate_and_normalize_pmf_with_budget(
    const std::span<const AuthoredProbability> probabilities,
    const ExactRational& tolerance, PmfRepresentationBudget budget) {
  const auto tolerance_result = check_tolerance(tolerance);
  if (!tolerance_result.has_value()) {
    return Result<NormalizedPmf>::failure(tolerance_result.error());
  }
  if (probabilities.empty()) {
    return Result<NormalizedPmf>::failure(input_error(
        "pmf_empty", "a categorical probability row must be nonempty"));
  }

  auto sum_result = exact_sum(probabilities);
  if (!sum_result.has_value()) {
    return Result<NormalizedPmf>::failure(sum_result.error());
  }
  ExactRational authored_sum = std::move(sum_result).value();
  const long double authored_numerical_mass =
      compensated_authored_mass(probabilities);
  const std::string numerical_residual_note =
      "compensated long-double residual " +
      format_long_double(authored_numerical_mass - 1.0L);
  if (authored_sum.numerator() == 0) {
    return Result<NormalizedPmf>::failure(input_error(
        "pmf_zero_total_mass",
        "a categorical probability row must have positive exact total mass",
        {numerical_residual_note}));
  }

  auto delta_result = make_rational(
      authored_sum.numerator() - authored_sum.denominator(),
      authored_sum.denominator());
  if (!delta_result.has_value()) {
    return Result<NormalizedPmf>::failure(delta_result.error());
  }
  ExactRational normalization_delta = std::move(delta_result).value();
  if (!absolute_value_at_most(normalization_delta, tolerance)) {
    return Result<NormalizedPmf>::failure(input_error(
        "pmf_mass_outside_tolerance",
        "the exact categorical mass differs from one by more than 1e-9",
        {"exact mass " + authored_sum.to_canonical_string(),
         "exact signed delta " +
             normalization_delta.to_canonical_string(),
         numerical_residual_note}));
  }

  std::vector<ExactRational> normalized_weights;
  normalized_weights.reserve(probabilities.size());
  for (const AuthoredProbability& probability : probabilities) {
    const ExactRational& exact = probability.exact_value();
    auto weight = make_rational(
        exact.numerator() * authored_sum.denominator(),
        exact.denominator() * authored_sum.numerator());
    if (!weight.has_value()) {
      return Result<NormalizedPmf>::failure(weight.error());
    }
    normalized_weights.push_back(std::move(weight).value());
  }

  BigInt common_denominator = 1;
  for (const ExactRational& weight : normalized_weights) {
    const BigInt divisor =
        gcd_nonnegative(common_denominator, weight.denominator());
    const BigInt reduced_common = common_denominator / divisor;
    if (product_provably_exceeds_budget(reduced_common,
                                        weight.denominator(), budget)) {
      return Result<NormalizedPmf>::failure(
          resource_error(budget, "normalized-denominator LCM"));
    }
    BigInt next_denominator = reduced_common * weight.denominator();
    const auto lcm_budget = enforce_integral_budget(
        next_denominator, budget, "normalized-denominator LCM");
    if (!lcm_budget.has_value()) {
      return Result<NormalizedPmf>::failure(lcm_budget.error());
    }
    common_denominator = std::move(next_denominator);
  }

  std::vector<BigInt> raw_masses;
  raw_masses.reserve(normalized_weights.size());
  BigInt mass_gcd = 0;
  for (const ExactRational& weight : normalized_weights) {
    BigInt mass = weight.numerator() *
                  (common_denominator / weight.denominator());
    const auto mass_budget =
        enforce_integral_budget(mass, budget, "integral mass");
    if (!mass_budget.has_value()) {
      return Result<NormalizedPmf>::failure(mass_budget.error());
    }
    mass_gcd = gcd_nonnegative(mass_gcd, mass);
    raw_masses.push_back(std::move(mass));
  }
  if (mass_gcd == 0) {
    return Result<NormalizedPmf>::failure(
        invariant_error("positive PMF mass produced no positive integer mass"));
  }

  std::vector<BigNat> integral_masses;
  std::vector<BigNat> cumulative_masses;
  integral_masses.reserve(raw_masses.size());
  cumulative_masses.reserve(raw_masses.size());
  BigInt cumulative = 0;
  for (const BigInt& raw_mass : raw_masses) {
    BigInt primitive_mass = raw_mass / mass_gcd;
    cumulative += primitive_mass;
    const auto primitive_budget =
        enforce_integral_budget(primitive_mass, budget, "primitive mass");
    if (!primitive_budget.has_value()) {
      return Result<NormalizedPmf>::failure(primitive_budget.error());
    }
    const auto cumulative_budget = enforce_integral_budget(
        cumulative, budget, "cumulative integral mass");
    if (!cumulative_budget.has_value()) {
      return Result<NormalizedPmf>::failure(cumulative_budget.error());
    }

    auto mass = make_big_nat(std::move(primitive_mass));
    auto cumulative_mass = make_big_nat(cumulative);
    if (!mass.has_value()) {
      return Result<NormalizedPmf>::failure(mass.error());
    }
    if (!cumulative_mass.has_value()) {
      return Result<NormalizedPmf>::failure(cumulative_mass.error());
    }
    integral_masses.push_back(std::move(mass).value());
    cumulative_masses.push_back(std::move(cumulative_mass).value());
  }
  if (cumulative <= 0 ||
      cumulative != common_denominator / mass_gcd) {
    return Result<NormalizedPmf>::failure(invariant_error(
        "primitive integral masses are inconsistent with exact normalized "
        "weights"));
  }
  auto denominator_result = make_big_nat(cumulative);
  if (!denominator_result.has_value()) {
    return Result<NormalizedPmf>::failure(denominator_result.error());
  }
  BigNat integral_denominator = std::move(denominator_result).value();
  const auto denominator_budget = enforce_integral_budget(
      integral_denominator.value(), budget, "primitive denominator");
  if (!denominator_budget.has_value()) {
    return Result<NormalizedPmf>::failure(denominator_budget.error());
  }
  auto sampling_extent_result = make_big_nat(cumulative - 1);
  if (!sampling_extent_result.has_value()) {
    return Result<NormalizedPmf>::failure(sampling_extent_result.error());
  }
  const std::size_t sampling_bit_width =
      sampling_extent_result.value().bit_length();
  const std::size_t sampling_limb_count =
      (sampling_bit_width / 64U) +
      (sampling_bit_width % 64U == 0U ? 0U : 1U);

  // Construct the numerical image only after the exact normalized law and
  // primitive mass representation have been fixed.
  std::vector<long double> numerical_image;
  numerical_image.reserve(normalized_weights.size());
  for (const ExactRational& weight : normalized_weights) {
    long double image = weight.to_long_double();
    if (weight.numerator() == 0) {
      image = 0.0L;
    }
    if (!std::isfinite(image) || image < 0.0L || image > 1.0L) {
      return Result<NormalizedPmf>::failure(invariant_error(
          "conversion of an exact normalized weight produced an invalid "
          "numerical image"));
    }
    numerical_image.push_back(image);
  }
  const ProbabilityNumericalDiagnostics diagnostics =
      make_numerical_diagnostics(probabilities, numerical_image);

  std::vector<AuthoredProbability> authored_copy(probabilities.begin(),
                                                  probabilities.end());
  return Result<NormalizedPmf>::success(NormalizedPmf(
      std::move(authored_copy), std::move(authored_sum),
      std::move(normalization_delta), std::move(normalized_weights),
      std::move(integral_masses), std::move(cumulative_masses),
      std::move(integral_denominator), sampling_bit_width,
      sampling_limb_count, std::move(budget), std::move(numerical_image),
      diagnostics));
}

Result<NormalizedPmf> revalidate_normalized_pmf(
    const NormalizedPmf& pmf, const ExactRational& tolerance) {
  const auto tolerance_result = check_tolerance(tolerance);
  if (!tolerance_result.has_value()) {
    return Result<NormalizedPmf>::failure(tolerance_result.error());
  }
  if (pmf.size() == 0 ||
      pmf.normalized_weights().size() != pmf.size() ||
      pmf.integral_masses().size() != pmf.size() ||
      pmf.cumulative_masses().size() != pmf.size() ||
      pmf.numerical_image().size() != pmf.size()) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF vector sizes are inconsistent"));
  }

  const auto sum_result = exact_sum(pmf.authored_probabilities());
  if (!sum_result.has_value() ||
      !rational_equal(sum_result.value(), pmf.authored_sum())) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF authored sum is inconsistent"));
  }
  auto delta_result = make_rational(
      pmf.authored_sum().numerator() - pmf.authored_sum().denominator(),
      pmf.authored_sum().denominator());
  if (!delta_result.has_value() ||
      !rational_equal(delta_result.value(), pmf.normalization_delta())) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF exact delta is inconsistent"));
  }
  if (!absolute_value_at_most(pmf.normalization_delta(), tolerance)) {
    return Result<NormalizedPmf>::failure(input_error(
        "pmf_mass_outside_tolerance",
        "the exact categorical mass differs from one by more than 1e-9"));
  }

  BigInt normalized_numerator = 0;
  BigInt normalized_denominator = 1;
  BigInt cumulative = 0;
  BigInt mass_gcd = 0;
  const BigInt& denominator = pmf.integral_denominator().value();
  if (denominator <= 0) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF denominator is not positive"));
  }
  if (pmf.representation_budget().maximum_integral_bits.has_value() &&
      pmf.integral_denominator().bit_length() >
          *pmf.representation_budget().maximum_integral_bits) {
    return Result<NormalizedPmf>::failure(invariant_error(
        "normalized PMF violates its retained representation budget"));
  }
  auto sampling_extent_result = make_big_nat(denominator - 1);
  if (!sampling_extent_result.has_value()) {
    return Result<NormalizedPmf>::failure(sampling_extent_result.error());
  }
  const std::size_t expected_sampling_bit_width =
      sampling_extent_result.value().bit_length();
  const std::size_t expected_sampling_limb_count =
      (expected_sampling_bit_width / 64U) +
      (expected_sampling_bit_width % 64U == 0U ? 0U : 1U);
  if (pmf.sampling_bit_width() != expected_sampling_bit_width ||
      pmf.sampling_limb_count() != expected_sampling_limb_count) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF sampling-width metadata is invalid"));
  }

  std::vector<long double> expected_image;
  expected_image.reserve(pmf.size());
  for (std::size_t index = 0; index < pmf.size(); ++index) {
    const ExactRational& weight = pmf.normalized_weights()[index];
    const ExactRational& authored =
        pmf.authored_probabilities()[index].exact_value();
    const BigInt& mass = pmf.integral_masses()[index].value();
    if (weight.numerator() < 0 || mass < 0 ||
        weight.numerator() * denominator !=
            mass * weight.denominator() ||
        weight.numerator() * authored.denominator() *
                pmf.authored_sum().numerator() !=
            weight.denominator() * authored.numerator() *
                pmf.authored_sum().denominator()) {
      return Result<NormalizedPmf>::failure(invariant_error(
          "normalized PMF rational and integral masses disagree"));
    }

    normalized_numerator =
        normalized_numerator * weight.denominator() +
        weight.numerator() * normalized_denominator;
    normalized_denominator *= weight.denominator();
    const BigInt reduction =
        gcd_nonnegative(normalized_numerator, normalized_denominator);
    normalized_numerator /= reduction;
    normalized_denominator /= reduction;

    cumulative += mass;
    if (pmf.cumulative_masses()[index].value() != cumulative) {
      return Result<NormalizedPmf>::failure(
          invariant_error("normalized PMF cumulative masses disagree"));
    }
    mass_gcd = gcd_nonnegative(mass_gcd, mass);

    long double image = weight.to_long_double();
    if (weight.numerator() == 0) {
      image = 0.0L;
    }
    expected_image.push_back(image);
    if (image != pmf.numerical_image()[index]) {
      return Result<NormalizedPmf>::failure(
          invariant_error("normalized PMF numerical image is inconsistent"));
    }
  }
  if (normalized_numerator != normalized_denominator ||
      cumulative != denominator || mass_gcd != 1) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF mass representation is not primitive"));
  }

  const ProbabilityNumericalDiagnostics expected_diagnostics =
      make_numerical_diagnostics(pmf.authored_probabilities(), expected_image);
  if (!(expected_diagnostics == pmf.numerical_diagnostics())) {
    return Result<NormalizedPmf>::failure(
        invariant_error("normalized PMF numerical diagnostics are inconsistent"));
  }

  return Result<NormalizedPmf>::success(pmf);
}

}  // namespace mwperf
