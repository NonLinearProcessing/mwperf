#include "mwperf/math/big_nat.hpp"

#include <algorithm>
#include <bit>
#include <cmath>
#include <compare>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <limits>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <boost/multiprecision/cpp_int/import_export.hpp>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

static_assert(std::numeric_limits<std::size_t>::digits <= 64,
              "version-1 canonical lengths require size_t no wider than u64");
static_assert(sizeof(double) == sizeof(std::uint64_t) &&
                  std::numeric_limits<double>::is_iec559 &&
                  std::numeric_limits<double>::digits == 53 &&
                  std::numeric_limits<double>::max_exponent == 1024,
              "PortableScientificScalar requires IEEE-754 binary64 double");

[[nodiscard]] Diagnostic input_error(std::string code, std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic resource_error(std::string code,
                                        std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] BigInt absolute_big_int(BigInt value) {
  if (value < 0) {
    value = -value;
  }
  return value;
}

[[nodiscard]] BigInt gcd_big_int(BigInt lhs, BigInt rhs) {
  lhs = absolute_big_int(std::move(lhs));
  rhs = absolute_big_int(std::move(rhs));
  while (rhs != 0) {
    BigInt remainder = lhs % rhs;
    lhs = std::move(rhs);
    rhs = std::move(remainder);
  }
  return lhs;
}

struct ParsedDecimal final {
  bool negative;
  std::string digits;
  std::size_t fractional_digits;
  BigInt exponent;
};

[[nodiscard]] bool is_ascii_digit(const char value) noexcept {
  return value >= '0' && value <= '9';
}

[[nodiscard]] Result<ParsedDecimal> parse_json_decimal(
    const std::string_view text) {
  if (text.empty()) {
    return Result<ParsedDecimal>::failure(input_error(
        "number_empty", "an exact number requires a nonempty source lexeme"));
  }

  std::size_t cursor = 0;
  bool negative = false;
  if (text[cursor] == '-') {
    negative = true;
    ++cursor;
    if (cursor == text.size()) {
      return Result<ParsedDecimal>::failure(input_error(
          "number_invalid_decimal", "the numeric lexeme is not a JSON decimal"));
    }
  }

  std::string digits;
  digits.reserve(text.size());
  if (text[cursor] == '0') {
    digits.push_back('0');
    ++cursor;
    if (cursor < text.size() && is_ascii_digit(text[cursor])) {
      return Result<ParsedDecimal>::failure(input_error(
          "number_noncanonical_leading_zero",
          "a JSON decimal may not contain a leading integer zero"));
    }
  } else if (text[cursor] >= '1' && text[cursor] <= '9') {
    do {
      digits.push_back(text[cursor]);
      ++cursor;
    } while (cursor < text.size() && is_ascii_digit(text[cursor]));
  } else {
    return Result<ParsedDecimal>::failure(input_error(
        "number_invalid_decimal", "the numeric lexeme is not a JSON decimal"));
  }

  std::size_t fractional_digits = 0;
  if (cursor < text.size() && text[cursor] == '.') {
    ++cursor;
    const std::size_t fraction_start = cursor;
    while (cursor < text.size() && is_ascii_digit(text[cursor])) {
      digits.push_back(text[cursor]);
      ++cursor;
    }
    fractional_digits = cursor - fraction_start;
    if (fractional_digits == 0U) {
      return Result<ParsedDecimal>::failure(input_error(
          "number_invalid_decimal",
          "a decimal point must be followed by at least one digit"));
    }
  }

  BigInt exponent = 0;
  if (cursor < text.size() &&
      (text[cursor] == 'e' || text[cursor] == 'E')) {
    ++cursor;
    bool exponent_negative = false;
    if (cursor < text.size() &&
        (text[cursor] == '+' || text[cursor] == '-')) {
      exponent_negative = text[cursor] == '-';
      ++cursor;
    }
    const std::size_t exponent_start = cursor;
    while (cursor < text.size() && is_ascii_digit(text[cursor])) {
      exponent *= 10;
      exponent += static_cast<unsigned int>(text[cursor] - '0');
      ++cursor;
    }
    if (cursor == exponent_start) {
      return Result<ParsedDecimal>::failure(input_error(
          "number_invalid_decimal",
          "an exponent marker must be followed by decimal digits"));
    }
    if (exponent_negative) {
      exponent = -exponent;
    }
  }

  if (cursor != text.size()) {
    return Result<ParsedDecimal>::failure(input_error(
        "number_invalid_decimal",
        "the numeric lexeme contains a non-JSON decimal character"));
  }

  return Result<ParsedDecimal>::success(
      ParsedDecimal{negative, std::move(digits), fractional_digits,
                    std::move(exponent)});
}

[[nodiscard]] std::string remove_leading_zeroes(std::string digits) {
  const std::size_t first_nonzero = digits.find_first_not_of('0');
  if (first_nonzero == std::string::npos) {
    return "0";
  }
  digits.erase(0, first_nonzero);
  return digits;
}

[[nodiscard]] BigInt decimal_digits_to_big_int(const std::string_view digits) {
  BigInt value = 0;
  for (const char digit : digits) {
    value *= 10;
    value += static_cast<unsigned int>(digit - '0');
  }
  return value;
}

[[nodiscard]] Result<std::size_t> nonnegative_big_int_to_size(
    const BigInt& value, const std::string_view code) {
  const BigInt maximum = std::numeric_limits<std::size_t>::max();
  if (value < 0 || value > maximum) {
    return Result<std::size_t>::failure(resource_error(
        std::string(code),
        "the decimal exponent exceeds the host representation range"));
  }
  return Result<std::size_t>::success(value.convert_to<std::size_t>());
}

[[nodiscard]] BigInt power_of_ten(std::size_t exponent) {
  BigInt result = 1;
  BigInt base = 10;
  while (exponent != 0U) {
    if ((exponent & 1U) != 0U) {
      result *= base;
    }
    exponent >>= 1U;
    if (exponent != 0U) {
      base *= base;
    }
  }
  return result;
}

[[nodiscard]] std::size_t big_int_bit_length(const BigInt& value) {
  if (value == 0) {
    return 0U;
  }
  const BigInt magnitude = value < 0 ? -value : value;
  return static_cast<std::size_t>(boost::multiprecision::msb(magnitude)) + 1U;
}

[[nodiscard]] std::size_t big_int_decimal_digits(const BigInt& value) {
  const std::string encoded = value.convert_to<std::string>();
  return !encoded.empty() && encoded[0] == '-' ? encoded.size() - 1U
                                                : encoded.size();
}

[[nodiscard]] Result<void> preflight_rational_positive_scale(
    const std::size_t significand_digits, const BigInt& scale,
    const RationalBoundPolicy& policy) {
  const BigInt final_digit_count = BigInt(significand_digits) + scale;
  if (policy.maximum_decimal_digits.has_value() &&
      final_digit_count > *policy.maximum_decimal_digits) {
    return Result<void>::failure(resource_error(
        "rational_decimal_digit_budget_exceeded",
        "the exact rational exceeds the decimal-digit representation budget"));
  }
  if (policy.maximum_bits.has_value()) {
    const BigInt lower_bit_length =
        final_digit_count == 1 ? BigInt(1)
                               : BigInt(3) * (final_digit_count - 1) + 1;
    if (lower_bit_length > *policy.maximum_bits) {
      return Result<void>::failure(resource_error(
          "rational_bit_budget_exceeded",
          "the exact rational exceeds the bit representation budget"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> preflight_rational_negative_scale(
    const BigInt& numerator, const BigInt& denominator_power,
    const RationalBoundPolicy& policy) {
  // Reducing n/10^k can cancel at most bit_length(|n|) factors of either 2
  // or 5.  Consequently the reduced denominator still contains at least
  // 10^(k-bit_length(|n|)) when that exponent is positive.  This lower bound
  // is deliberately conservative, but it safely rejects hostile exponents
  // before constructing their power of ten.
  const BigInt cancellation_upper = big_int_bit_length(numerator);
  const BigInt residual_power =
      denominator_power > cancellation_upper
          ? denominator_power - cancellation_upper
          : BigInt(0);
  const BigInt lower_decimal_digits = residual_power + 1;
  const BigInt lower_bit_length = BigInt(3) * residual_power + 1;

  if (policy.maximum_decimal_digits.has_value() &&
      lower_decimal_digits > *policy.maximum_decimal_digits) {
    return Result<void>::failure(resource_error(
        "rational_decimal_digit_budget_exceeded",
        "the exact rational exceeds the decimal-digit representation budget"));
  }
  if (policy.maximum_bits.has_value() &&
      lower_bit_length > *policy.maximum_bits) {
    return Result<void>::failure(resource_error(
        "rational_bit_budget_exceeded",
        "the exact rational exceeds the bit representation budget"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ExactRational> enforce_rational_bound_policy(
    ExactRational value, const RationalBoundPolicy& policy) {
  if (policy.maximum_decimal_digits.has_value() &&
      (big_int_decimal_digits(value.numerator()) >
           *policy.maximum_decimal_digits ||
       big_int_decimal_digits(value.denominator()) >
           *policy.maximum_decimal_digits)) {
    return Result<ExactRational>::failure(resource_error(
        "rational_decimal_digit_budget_exceeded",
        "the reduced rational exceeds the decimal-digit representation budget"));
  }
  if (policy.maximum_bits.has_value() &&
      (big_int_bit_length(value.numerator()) > *policy.maximum_bits ||
       big_int_bit_length(value.denominator()) > *policy.maximum_bits)) {
    return Result<ExactRational>::failure(resource_error(
        "rational_bit_budget_exceeded",
        "the reduced rational exceeds the bit representation budget"));
  }
  return Result<ExactRational>::success(std::move(value));
}

[[nodiscard]] bool canonical_signed_integer(const std::string_view text) {
  if (text.empty()) {
    return false;
  }
  std::size_t cursor = 0;
  if (text[0] == '-') {
    cursor = 1;
    if (cursor == text.size() || text[cursor] == '0') {
      return false;
    }
  } else if (text[0] == '+') {
    return false;
  }
  if (text[cursor] == '0') {
    return cursor + 1U == text.size();
  }
  if (text[cursor] < '1' || text[cursor] > '9') {
    return false;
  }
  return std::all_of(text.begin() + static_cast<std::ptrdiff_t>(cursor),
                     text.end(), is_ascii_digit);
}

[[nodiscard]] bool canonical_positive_integer(const std::string_view text) {
  return !text.empty() && text[0] >= '1' && text[0] <= '9' &&
         std::all_of(text.begin(), text.end(), is_ascii_digit);
}

[[nodiscard]] Result<void> preflight_canonical_rational_component(
    const std::string_view magnitude,
    const RationalBoundPolicy& policy) {
  if (policy.maximum_decimal_digits.has_value() &&
      magnitude.size() > *policy.maximum_decimal_digits) {
    return Result<void>::failure(resource_error(
        "rational_decimal_digit_budget_exceeded",
        "the portable rational exceeds the decimal-digit representation budget"));
  }
  if (policy.maximum_bits.has_value()) {
    const std::size_t maximum_bits = *policy.maximum_bits;
    if (maximum_bits == 0U ||
        (magnitude.size() > 1U &&
         magnitude.size() - 1U > (maximum_bits - 1U) / 3U)) {
      return Result<void>::failure(resource_error(
          "rational_bit_budget_exceeded",
          "the portable rational exceeds the bit representation budget"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] BigInt canonical_signed_to_big_int(
    const std::string_view text) {
  const bool negative = text[0] == '-';
  const std::string_view magnitude = negative ? text.substr(1) : text;
  BigInt result = decimal_digits_to_big_int(magnitude);
  return negative ? -result : result;
}

[[nodiscard]] bool is_finite_binary64(const std::uint64_t bits) noexcept {
  constexpr std::uint64_t exponent_mask = UINT64_C(0x7ff0000000000000);
  return (bits & exponent_mask) != exponent_mask;
}

[[nodiscard]] bool is_negative_zero_binary64(
    const std::uint64_t bits) noexcept {
  return bits == UINT64_C(0x8000000000000000);
}

[[nodiscard]] ExactRational binary_bits_to_rational(const std::uint64_t bits) {
  constexpr std::uint64_t sign_mask = UINT64_C(0x8000000000000000);
  constexpr std::uint64_t fraction_mask = UINT64_C(0x000fffffffffffff);
  const bool negative = (bits & sign_mask) != 0U;
  const std::uint64_t exponent_bits = (bits >> 52U) & UINT64_C(0x7ff);
  const std::uint64_t fraction = bits & fraction_mask;

  if (exponent_bits == 0U && fraction == 0U) {
    return ExactRational::zero();
  }

  BigInt significand;
  int binary_exponent;
  if (exponent_bits == 0U) {
    significand = fraction;
    binary_exponent = -1074;
  } else {
    significand = (BigInt(1) << 52U) + fraction;
    binary_exponent = static_cast<int>(exponent_bits) - 1023 - 52;
  }
  if (negative) {
    significand = -significand;
  }

  BigInt numerator = std::move(significand);
  BigInt denominator = 1;
  if (binary_exponent >= 0) {
    numerator <<= static_cast<unsigned int>(binary_exponent);
  } else {
    denominator <<= static_cast<unsigned int>(-binary_exponent);
  }
  auto result = ExactRational::make(std::move(numerator),
                                    std::move(denominator));
  return std::move(result).value();
}

void append_u64be(std::vector<std::uint8_t>& bytes, std::uint64_t value) {
  for (unsigned int shift = 56U;; shift -= 8U) {
    bytes.push_back(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    if (shift == 0U) {
      break;
    }
  }
}

}  // namespace

BigNat::BigNat(const std::uint64_t value) : value_(value) {}

BigNat::BigNat(BigNat&& other) noexcept : value_(std::move(other.value_)) {
  other.value_ = 0;
}

BigNat& BigNat::operator=(BigNat&& other) noexcept {
  if (this != &other) {
    value_ = std::move(other.value_);
    other.value_ = 0;
  }
  return *this;
}

Result<BigNat> BigNat::from_big_int(BigInt value) {
  if (value < 0) {
    return Result<BigNat>::failure(input_error(
        "big_nat_negative", "a BigNat cannot contain a negative value"));
  }
  return Result<BigNat>::success(BigNat(std::move(value), ValidatedTag{}));
}

std::size_t BigNat::bit_length() const noexcept {
  if (is_zero()) {
    return 0U;
  }
  return static_cast<std::size_t>(boost::multiprecision::msb(value_)) + 1U;
}

std::string BigNat::to_decimal_string() const {
  return value_.convert_to<std::string>();
}

std::vector<std::uint8_t> BigNat::canonical_magnitude_bytes() const {
  if (is_zero()) {
    return {0U};
  }
  std::vector<std::uint8_t> bytes;
  bytes.reserve((bit_length() + 7U) / 8U);
  boost::multiprecision::export_bits(value_, std::back_inserter(bytes), 8U,
                                     true);
  return bytes;
}

BigNat& BigNat::operator+=(const BigNat& other) {
  value_ += other.value_;
  return *this;
}

BigNat& BigNat::operator*=(const BigNat& other) {
  value_ *= other.value_;
  return *this;
}

BigNat& BigNat::operator++() {
  ++value_;
  return *this;
}

std::strong_ordering operator<=>(const BigNat& lhs,
                                 const BigNat& rhs) noexcept {
  if (lhs.value_ < rhs.value_) {
    return std::strong_ordering::less;
  }
  if (lhs.value_ > rhs.value_) {
    return std::strong_ordering::greater;
  }
  return std::strong_ordering::equal;
}

Result<BigNat> checked_subtract(const BigNat& lhs, const BigNat& rhs) {
  if (lhs < rhs) {
    return Result<BigNat>::failure(input_error(
        "big_nat_subtraction_negative",
        "BigNat subtraction would produce a negative value"));
  }
  return BigNat::from_big_int(lhs.value() - rhs.value());
}

std::string to_string(const BigNat& value) {
  return value.to_decimal_string();
}

std::vector<std::uint8_t> canonical_big_nat_bytes(const BigNat& value) {
  return value.canonical_magnitude_bytes();
}

JsonNumber JsonNumber::boolean(const bool value) {
  return JsonNumber(JsonNumberKind::boolean, value ? "true" : "false");
}

JsonNumber JsonNumber::other(std::string authored_text) {
  return JsonNumber(JsonNumberKind::other, std::move(authored_text));
}

Result<BigNat> parse_exact_nonnegative_integer(JsonNumber number,
                                               BoundPolicy policy) {
  if (number.kind() == JsonNumberKind::boolean) {
    return Result<BigNat>::failure(input_error(
        "integer_boolean", "a boolean is not an exact nonnegative integer"));
  }
  if (number.kind() != JsonNumberKind::number) {
    return Result<BigNat>::failure(input_error(
        "integer_wrong_type",
        "the value is not an authored JSON numeric lexeme"));
  }

  auto parsed_result = parse_json_decimal(number.lexeme());
  if (!parsed_result) {
    return Result<BigNat>::failure(parsed_result.error());
  }
  ParsedDecimal parsed = std::move(parsed_result).value();
  if (parsed.negative) {
    return Result<BigNat>::failure(input_error(
        "integer_negative",
        "a nonnegative integer may not use a negative sign"));
  }

  std::string digits = remove_leading_zeroes(std::move(parsed.digits));
  if (digits == "0") {
    if (policy.maximum_decimal_digits.has_value() &&
        *policy.maximum_decimal_digits < 1U) {
      return Result<BigNat>::failure(resource_error(
          "integer_decimal_digit_budget_exceeded",
          "the canonical integer exceeds the decimal-digit resource budget"));
    }
    return Result<BigNat>::success(BigNat(0U));
  }

  const BigInt scale = parsed.exponent - parsed.fractional_digits;
  if (scale < 0) {
    const BigInt required_zeroes_big = -scale;
    if (required_zeroes_big > digits.size()) {
      return Result<BigNat>::failure(input_error(
          "integer_nonintegral",
          "the authored number does not have an integral exact value"));
    }
    const std::size_t required_zeroes =
        required_zeroes_big.convert_to<std::size_t>();
    const auto first_removed =
        digits.end() - static_cast<std::ptrdiff_t>(required_zeroes);
    if (!std::all_of(first_removed, digits.end(),
                     [](const char digit) { return digit == '0'; })) {
      return Result<BigNat>::failure(input_error(
          "integer_nonintegral",
          "the authored number does not have an integral exact value"));
    }
    digits.erase(first_removed, digits.end());
    digits = remove_leading_zeroes(std::move(digits));
  } else if (scale > 0) {
    const BigInt final_digit_count = BigInt(digits.size()) + scale;
    if (policy.mathematical_maximum.has_value()) {
      const std::size_t maximum_digits =
          policy.mathematical_maximum->to_decimal_string().size();
      if (final_digit_count > maximum_digits) {
        return Result<BigNat>::failure(input_error(
            "integer_mathematical_bound_exceeded",
            "the exact integer exceeds its mathematical upper bound"));
      }
    }
    if (policy.maximum_decimal_digits.has_value() &&
        final_digit_count > *policy.maximum_decimal_digits) {
      return Result<BigNat>::failure(resource_error(
          "integer_decimal_digit_budget_exceeded",
          "the canonical integer exceeds the decimal-digit resource budget"));
    }
    if (policy.maximum_bits.has_value()) {
      const BigInt maximum_bits = *policy.maximum_bits;
      // A d-digit positive integer is at least 10^(d-1), which is strictly
      // greater than 2^(3(d-1)) for d > 1.  Reject before expansion whenever
      // this proves the configured bit budget cannot hold the value.
      if (maximum_bits == 0 ||
          (final_digit_count > 1 &&
           BigInt(3) * (final_digit_count - 1) >= maximum_bits)) {
        return Result<BigNat>::failure(resource_error(
            "integer_bit_budget_exceeded",
            "the exact integer exceeds the representation bit budget"));
      }
    }
    const BigInt maximum_append =
        std::numeric_limits<std::size_t>::max() - digits.size();
    if (scale > maximum_append) {
      return Result<BigNat>::failure(resource_error(
          "integer_representation_budget_exceeded",
          "the integral exponent exceeds the host representation range"));
    }
    const std::size_t append_count = scale.convert_to<std::size_t>();
    digits.append(append_count, '0');
  }

  if (policy.mathematical_maximum.has_value()) {
    const std::string maximum =
        policy.mathematical_maximum->to_decimal_string();
    if (digits.size() > maximum.size() ||
        (digits.size() == maximum.size() && digits > maximum)) {
      return Result<BigNat>::failure(input_error(
          "integer_mathematical_bound_exceeded",
          "the exact integer exceeds its mathematical upper bound"));
    }
  }

  if (policy.maximum_decimal_digits.has_value() &&
      digits.size() > *policy.maximum_decimal_digits) {
    return Result<BigNat>::failure(resource_error(
        "integer_decimal_digit_budget_exceeded",
        "the canonical integer exceeds the decimal-digit resource budget"));
  }

  if (policy.maximum_bits.has_value()) {
    const std::size_t maximum_bits = *policy.maximum_bits;
    // 10^(d-1) >= 2^(3(d-1)).  This conservative check prevents a huge
    // allocation whenever decimal length alone proves the bit budget fails.
    if (maximum_bits == 0U ||
        (digits.size() > 1U &&
         (digits.size() - 1U) > (maximum_bits - 1U) / 3U)) {
      return Result<BigNat>::failure(resource_error(
          "integer_bit_budget_exceeded",
          "the exact integer exceeds the representation bit budget"));
    }
  }

  BigNat value =
      std::move(BigNat::from_big_int(decimal_digits_to_big_int(digits))).value();
  if (policy.mathematical_maximum.has_value() &&
      value > *policy.mathematical_maximum) {
    return Result<BigNat>::failure(input_error(
        "integer_mathematical_bound_exceeded",
        "the exact integer exceeds its mathematical upper bound"));
  }
  if (policy.maximum_bits.has_value() &&
      value.bit_length() > *policy.maximum_bits) {
    return Result<BigNat>::failure(resource_error(
        "integer_bit_budget_exceeded",
        "the exact integer exceeds the representation bit budget"));
  }
  return Result<BigNat>::success(std::move(value));
}

Result<std::size_t> checked_index(const BigNat& value,
                                  const std::size_t upper_exclusive) {
  const BigInt native_maximum = std::numeric_limits<std::size_t>::max();
  if (value.value() > native_maximum) {
    return Result<std::size_t>::failure(resource_error(
        "index_not_representable",
        "the exact index is not representable as size_t"));
  }
  const std::size_t native = value.value().convert_to<std::size_t>();
  if (native >= upper_exclusive) {
    return Result<std::size_t>::failure(input_error(
        "index_out_of_range",
        "the exact index is outside the requested half-open domain"));
  }
  return Result<std::size_t>::success(native);
}

Result<ExactRational> ExactRational::make(BigInt numerator,
                                         BigInt denominator) {
  if (denominator == 0) {
    return Result<ExactRational>::failure(input_error(
        "rational_zero_denominator",
        "an exact rational requires a nonzero denominator"));
  }
  return Result<ExactRational>::success(
      make_reduced(std::move(numerator), std::move(denominator)));
}

ExactRational::ExactRational(ExactRational&& other) noexcept
    : numerator_(std::move(other.numerator_)),
      denominator_(std::move(other.denominator_)) {
  other.numerator_ = 0;
  other.denominator_ = 1;
}

ExactRational& ExactRational::operator=(ExactRational&& other) noexcept {
  if (this != &other) {
    numerator_ = std::move(other.numerator_);
    denominator_ = std::move(other.denominator_);
    other.numerator_ = 0;
    other.denominator_ = 1;
  }
  return *this;
}

ExactRational ExactRational::make_reduced(BigInt numerator,
                                          BigInt denominator) {
  if (denominator < 0) {
    numerator = -numerator;
    denominator = -denominator;
  }
  if (numerator == 0) {
    return ExactRational(0, 1, ReducedTag{});
  }
  const BigInt divisor = gcd_big_int(numerator, denominator);
  numerator /= divisor;
  denominator /= divisor;
  return ExactRational(std::move(numerator), std::move(denominator),
                       ReducedTag{});
}

ExactRational ExactRational::zero() {
  return ExactRational(0, 1, ReducedTag{});
}

ExactRational ExactRational::one() {
  return ExactRational(1, 1, ReducedTag{});
}

std::string ExactRational::numerator_decimal() const {
  return numerator_.convert_to<std::string>();
}

std::string ExactRational::denominator_decimal() const {
  return denominator_.convert_to<std::string>();
}

std::string ExactRational::to_canonical_string() const {
  return numerator_decimal() + "/" + denominator_decimal();
}

long double ExactRational::to_long_double() const {
  if (numerator_ == 0) {
    return 0.0L;
  }

  const bool negative = numerator_ < 0;
  const BigInt magnitude = negative ? -numerator_ : numerator_;
  const std::size_t numerator_bits = big_int_bit_length(magnitude);
  const std::size_t denominator_bits = big_int_bit_length(denominator_);
  constexpr std::size_t guard_bits = 32U;
  constexpr std::size_t retained_bits =
      2U * static_cast<std::size_t>(
               std::numeric_limits<long double>::digits) +
      guard_bits;

  // Decide ratios far outside the long-double exponent range without ever
  // converting either enormous integer independently.  The two-bit margin
  // covers the possible leading-significand ratio around the bit-length
  // boundary; ldexp performs the final platform-format overflow/underflow.
  if (numerator_bits >= denominator_bits) {
    const std::size_t difference = numerator_bits - denominator_bits;
    const std::size_t overflow_limit =
        static_cast<std::size_t>(
            std::numeric_limits<long double>::max_exponent) +
        2U;
    if (difference > overflow_limit) {
      const long double infinity =
          std::numeric_limits<long double>::infinity();
      return negative ? -infinity : infinity;
    }
  } else {
    const std::size_t difference = denominator_bits - numerator_bits;
    const std::size_t underflow_limit =
        static_cast<std::size_t>(
            -std::numeric_limits<long double>::min_exponent) +
        static_cast<std::size_t>(
            std::numeric_limits<long double>::digits) +
        2U;
    if (difference > underflow_limit) {
      return negative ? -0.0L : 0.0L;
    }
  }

  const std::size_t numerator_shift =
      numerator_bits > retained_bits ? numerator_bits - retained_bits : 0U;
  const std::size_t denominator_shift =
      denominator_bits > retained_bits ? denominator_bits - retained_bits
                                        : 0U;
  const BigInt numerator_head = magnitude >> numerator_shift;
  const BigInt denominator_head = denominator_ >> denominator_shift;
  const long double head_ratio =
      numerator_head.convert_to<long double>() /
      denominator_head.convert_to<long double>();

  int binary_scale;
  if (numerator_shift >= denominator_shift) {
    binary_scale =
        static_cast<int>(numerator_shift - denominator_shift);
  } else {
    binary_scale =
        -static_cast<int>(denominator_shift - numerator_shift);
  }
  const long double converted = std::ldexp(head_ratio, binary_scale);
  return negative ? -converted : converted;
}

ExactRational ExactRational::operator-() const {
  return ExactRational(-numerator_, denominator_, ReducedTag{});
}

ExactRational operator+(const ExactRational& lhs, const ExactRational& rhs) {
  return ExactRational::make_reduced(
      lhs.numerator_ * rhs.denominator_ + rhs.numerator_ * lhs.denominator_,
      lhs.denominator_ * rhs.denominator_);
}

ExactRational operator-(const ExactRational& lhs, const ExactRational& rhs) {
  return ExactRational::make_reduced(
      lhs.numerator_ * rhs.denominator_ - rhs.numerator_ * lhs.denominator_,
      lhs.denominator_ * rhs.denominator_);
}

ExactRational operator*(const ExactRational& lhs, const ExactRational& rhs) {
  return ExactRational::make_reduced(lhs.numerator_ * rhs.numerator_,
                                     lhs.denominator_ * rhs.denominator_);
}

std::strong_ordering operator<=>(const ExactRational& lhs,
                                 const ExactRational& rhs) {
  const BigInt left_product = lhs.numerator_ * rhs.denominator_;
  const BigInt right_product = rhs.numerator_ * lhs.denominator_;
  if (left_product < right_product) {
    return std::strong_ordering::less;
  }
  if (left_product > right_product) {
    return std::strong_ordering::greater;
  }
  return std::strong_ordering::equal;
}

Result<ExactRational> checked_divide(const ExactRational& numerator,
                                     const ExactRational& denominator) {
  if (denominator.is_zero()) {
    return Result<ExactRational>::failure(input_error(
        "rational_division_by_zero",
        "exact rational division requires a nonzero divisor"));
  }
  return ExactRational::make(
      numerator.numerator() * denominator.denominator(),
      numerator.denominator() * denominator.numerator());
}

ExactRational absolute_value(const ExactRational& value) {
  return value.numerator() < 0 ? -value : value;
}

std::string to_string(const ExactRational& value) {
  return value.to_canonical_string();
}

Result<ExactRational> parse_decimal_rational(NumericLexeme lexeme) {
  auto parsed_result = parse_json_decimal(lexeme.text());
  if (!parsed_result) {
    return Result<ExactRational>::failure(parsed_result.error());
  }
  ParsedDecimal parsed = std::move(parsed_result).value();
  std::string digits = remove_leading_zeroes(std::move(parsed.digits));
  if (digits == "0") {
    return enforce_rational_bound_policy(ExactRational::zero(),
                                         lexeme.bound_policy());
  }

  BigInt numerator = decimal_digits_to_big_int(digits);
  if (parsed.negative) {
    numerator = -numerator;
  }
  BigInt denominator = 1;
  const BigInt scale = parsed.exponent - parsed.fractional_digits;
  if (scale >= 0) {
    auto preflight = preflight_rational_positive_scale(
        digits.size(), scale, lexeme.bound_policy());
    if (!preflight) {
      return Result<ExactRational>::failure(preflight.error());
    }
    auto scale_result =
        nonnegative_big_int_to_size(scale, "rational_exponent_too_large");
    if (!scale_result) {
      return Result<ExactRational>::failure(scale_result.error());
    }
    numerator *= power_of_ten(scale_result.value());
  } else {
    auto preflight = preflight_rational_negative_scale(
        numerator, -scale, lexeme.bound_policy());
    if (!preflight) {
      return Result<ExactRational>::failure(preflight.error());
    }
    auto scale_result = nonnegative_big_int_to_size(
        -scale, "rational_exponent_too_large");
    if (!scale_result) {
      return Result<ExactRational>::failure(scale_result.error());
    }
    denominator = power_of_ten(scale_result.value());
  }
  auto result =
      ExactRational::make(std::move(numerator), std::move(denominator));
  if (!result) {
    return result;
  }
  return enforce_rational_bound_policy(std::move(result).value(),
                                       lexeme.bound_policy());
}

PortableScientificScalar PortableScientificScalar::rational(
    ExactRational value) {
  return PortableScientificScalar(std::move(value));
}

Result<PortableScientificScalar> PortableScientificScalar::from_binary64(
    const double value) {
  std::uint64_t bits = std::bit_cast<std::uint64_t>(value);
  if (!is_finite_binary64(bits)) {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_nonfinite_binary64",
        "a portable binary64 scalar must be finite"));
  }
  if (is_negative_zero_binary64(bits)) {
    bits = 0U;
  }
  return Result<PortableScientificScalar>::success(
      PortableScientificScalar(Binary64Bits{bits}));
}

Result<PortableScientificScalar> PortableScientificScalar::parse_rational(
    const std::string_view numerator, const std::string_view denominator,
    RationalBoundPolicy bound_policy) {
  if (!canonical_signed_integer(numerator) ||
      !canonical_positive_integer(denominator)) {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_noncanonical_rational",
        "a portable rational requires canonical signed numerator and positive denominator encodings"));
  }
  const std::string_view numerator_magnitude =
      numerator.front() == '-' ? numerator.substr(1U) : numerator;
  auto numerator_preflight =
      preflight_canonical_rational_component(numerator_magnitude,
                                             bound_policy);
  if (!numerator_preflight) {
    return Result<PortableScientificScalar>::failure(
        numerator_preflight.error());
  }
  auto denominator_preflight =
      preflight_canonical_rational_component(denominator, bound_policy);
  if (!denominator_preflight) {
    return Result<PortableScientificScalar>::failure(
        denominator_preflight.error());
  }
  auto rational_result = ExactRational::make(
      canonical_signed_to_big_int(numerator),
      decimal_digits_to_big_int(denominator));
  if (!rational_result) {
    return Result<PortableScientificScalar>::failure(rational_result.error());
  }
  ExactRational value = std::move(rational_result).value();
  if (value.numerator_decimal() != numerator ||
      value.denominator_decimal() != denominator) {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_noncanonical_rational",
        "a portable rational must already be reduced to lowest terms"));
  }
  auto bounded = enforce_rational_bound_policy(std::move(value), bound_policy);
  if (!bounded) {
    return Result<PortableScientificScalar>::failure(bounded.error());
  }
  return Result<PortableScientificScalar>::success(
      PortableScientificScalar::rational(std::move(bounded).value()));
}

Result<PortableScientificScalar> PortableScientificScalar::parse_binary64(
    const std::string_view encoded_bits) {
  if (encoded_bits.size() != 18U || encoded_bits.substr(0, 2) != "0x") {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_noncanonical_binary64",
        "a portable binary64 requires 0x followed by sixteen lowercase hexadecimal digits"));
  }
  std::uint64_t bits = 0;
  for (const char digit : encoded_bits.substr(2)) {
    std::uint8_t nibble;
    if (digit >= '0' && digit <= '9') {
      nibble = static_cast<std::uint8_t>(digit - '0');
    } else if (digit >= 'a' && digit <= 'f') {
      nibble = static_cast<std::uint8_t>(digit - 'a' + 10);
    } else {
      return Result<PortableScientificScalar>::failure(input_error(
          "portable_scalar_noncanonical_binary64",
          "a portable binary64 requires lowercase hexadecimal digits"));
    }
    bits = (bits << 4U) | nibble;
  }
  if (!is_finite_binary64(bits)) {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_nonfinite_binary64",
        "a portable binary64 scalar must be finite"));
  }
  if (is_negative_zero_binary64(bits)) {
    return Result<PortableScientificScalar>::failure(input_error(
        "portable_scalar_negative_zero",
        "negative zero is not a canonical portable binary64"));
  }
  return Result<PortableScientificScalar>::success(
      PortableScientificScalar(Binary64Bits{bits}));
}

PortableScientificScalarKind PortableScientificScalar::kind() const noexcept {
  return std::holds_alternative<ExactRational>(value_)
             ? PortableScientificScalarKind::rational
             : PortableScientificScalarKind::binary64;
}

const ExactRational& PortableScientificScalar::rational_value() const {
  return std::get<ExactRational>(value_);
}

std::uint64_t PortableScientificScalar::binary64_bits() const {
  return std::get<Binary64Bits>(value_).value;
}

double PortableScientificScalar::binary64_value() const {
  return std::bit_cast<double>(binary64_bits());
}

std::string PortableScientificScalar::binary64_encoding() const {
  constexpr char hex[] = "0123456789abcdef";
  const std::uint64_t bits = binary64_bits();
  std::string encoded(18U, '0');
  encoded[0] = '0';
  encoded[1] = 'x';
  for (std::size_t index = 0; index < 16U; ++index) {
    const unsigned int shift =
        static_cast<unsigned int>((15U - index) * 4U);
    encoded[index + 2U] = hex[(bits >> shift) & 0x0fU];
  }
  return encoded;
}

std::string PortableScientificScalar::canonical_tagged_encoding() const {
  if (kind() == PortableScientificScalarKind::rational) {
    return "rational:" + rational_value().to_canonical_string();
  }
  return "binary64:" + binary64_encoding();
}

std::vector<std::uint8_t> PortableScientificScalar::canonical_bytes() const {
  std::vector<std::uint8_t> bytes;
  if (kind() == PortableScientificScalarKind::rational) {
    const std::string numerator = rational_value().numerator_decimal();
    const std::string denominator = rational_value().denominator_decimal();
    bytes.reserve(1U + 8U + numerator.size() + 8U + denominator.size());
    bytes.push_back(0U);
    append_u64be(bytes, static_cast<std::uint64_t>(numerator.size()));
    bytes.insert(bytes.end(), numerator.begin(), numerator.end());
    append_u64be(bytes, static_cast<std::uint64_t>(denominator.size()));
    bytes.insert(bytes.end(), denominator.begin(), denominator.end());
  } else {
    bytes.reserve(9U);
    bytes.push_back(1U);
    append_u64be(bytes, binary64_bits());
  }
  return bytes;
}

ExactRational binary64_as_exact_rational(
    const PortableScientificScalar& scalar) {
  return binary_bits_to_rational(scalar.binary64_bits());
}

Result<void> validate_in_closed_interval(
    const PortableScientificScalar& scalar, const ExactRational& lower,
    const ExactRational& upper) {
  if (upper < lower) {
    return Result<void>::failure(input_error(
        "portable_scalar_invalid_range",
        "a closed scalar range requires lower not greater than upper"));
  }
  const ExactRational value =
      scalar.kind() == PortableScientificScalarKind::rational
          ? scalar.rational_value()
          : binary64_as_exact_rational(scalar);
  if (value < lower || value > upper) {
    return Result<void>::failure(input_error(
        "portable_scalar_out_of_range",
        "the decoded scalar is outside the required closed interval"));
  }
  return Result<void>::success();
}

}  // namespace mwperf
