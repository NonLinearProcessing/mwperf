#include "mwperf/reduction/exact_reductions.hpp"

#include <algorithm>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <boost/multiprecision/cpp_int.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/physical/physical_edge.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic reduction_error(
    DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic invalid_request(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return reduction_error(DiagnosticCategory::input_validation,
                         std::move(code), std::move(message),
                         std::move(notes));
}

[[nodiscard]] Diagnostic invariant_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return reduction_error(DiagnosticCategory::internal, std::move(code),
                         std::move(message), std::move(notes));
}

[[nodiscard]] Diagnostic representation_failure(
    std::string code, std::string message) {
  return reduction_error(DiagnosticCategory::resource_limit,
                         std::move(code), std::move(message));
}

void append_framed(std::string& bytes, const std::string_view value) {
  bytes += std::to_string(value.size());
  bytes.push_back(':');
  bytes.append(value);
}

void append_nat(std::string& bytes, const BigNat& value) {
  append_framed(bytes, value.to_decimal_string());
}

void append_int(std::string& bytes, const BigInt& value) {
  append_framed(bytes, value.convert_to<std::string>());
}

void append_schedule(std::string& bytes, const Schedule& schedule) {
  bytes += std::to_string(schedule.size());
  bytes.push_back(':');
  for (const std::uint8_t bit : schedule.bytes()) {
    bytes.push_back(bit == 0U ? '0' : '1');
  }
}

[[nodiscard]] Result<Digest256> digest_text(
    const std::string_view domain, const std::string& bytes) {
  const std::span<const char> characters(bytes.data(), bytes.size());
  return sha256_domain_separated(domain, std::as_bytes(characters));
}

[[nodiscard]] Result<Digest256> digest_integral_vector(
    const std::string_view domain, const QueueDimensionToken& dimension,
    const std::span<const BigNat> values) {
  std::string bytes;
  append_framed(bytes, dimension.combined_input().hex());
  append_framed(bytes, std::string(to_string(dimension.family())));
  append_framed(bytes, std::to_string(dimension.cardinality()));
  for (const BigNat& value : values) {
    append_nat(bytes, value);
  }
  return digest_text(domain, bytes);
}

[[nodiscard]] Result<Digest256> digest_priority(
    const PriorityOrder& priority) {
  std::string bytes;
  append_framed(bytes, std::to_string(priority.size()));
  for (const DenseQueueIndex queue : priority.rank_to_queue()) {
    append_framed(bytes, std::to_string(queue.ordinal()));
  }
  return digest_text("mwperf.c13.priority.v1", bytes);
}

[[nodiscard]] Result<Digest256> digest_rational_vector(
    const QueueDimensionToken& dimension,
    const std::span<const ExactRational> values) {
  std::string bytes;
  append_framed(bytes, dimension.combined_input().hex());
  append_framed(bytes, std::string(to_string(dimension.family())));
  append_framed(bytes, std::to_string(dimension.cardinality()));
  for (const ExactRational& value : values) {
    append_framed(bytes, value.numerator_decimal());
    append_framed(bytes, value.denominator_decimal());
  }
  return digest_text("mwperf.c13.rational_weights.v1", bytes);
}

[[nodiscard]] std::size_t positive_bit_length(const BigInt& value) {
  if (value == 0) {
    return 0U;
  }
  return static_cast<std::size_t>(boost::multiprecision::msb(value)) + 1U;
}

// A positive product has bit length either a_bits+b_bits-1 or
// a_bits+b_bits. This preflight rejects every product whose lower bound is
// already over budget, so the remaining exact multiplication can exceed the
// authored limit by at most one bit before the exact postcheck rejects it.
[[nodiscard]] bool product_definitely_exceeds_bit_limit(
    const BigInt& left, const BigInt& right, const std::size_t limit) {
  if (left == 0 || right == 0) {
    return false;
  }
  const std::size_t left_bits = positive_bit_length(left);
  const std::size_t right_bits = positive_bit_length(right);
  if (left_bits > limit || right_bits > limit) {
    return true;
  }
  return left_bits > (limit - right_bits) + 1U;
}

[[nodiscard]] BigInt exact_gcd(BigInt left, BigInt right) {
  if (left < 0) {
    left = -left;
  }
  if (right < 0) {
    right = -right;
  }
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  return left;
}

[[nodiscard]] bool same_schedule_bytes(const Schedule& left,
                                       const Schedule& right) noexcept {
  return left.dimension() == right.dimension() &&
         std::ranges::equal(left.bytes(), right.bytes());
}

[[nodiscard]] BigNat exact_dot(const std::span<const BigNat> weights,
                               const Schedule& schedule) {
  BigNat result(std::uint64_t{0U});
  for (std::size_t index = 0U; index < weights.size(); ++index) {
    if (schedule.bytes()[index] != 0U) {
      result += weights[index];
    }
  }
  return result;
}

[[nodiscard]] BigNat residual_schedule_objective(
    const Backlog& backlog, const Schedule& schedule,
    const TargetIndex& target) {
  BigNat result(std::uint64_t{0U});
  for (std::size_t index = 0U; index < backlog.size(); ++index) {
    if (index != target.ordinal() && schedule.bytes()[index] != 0U) {
      result += backlog.values()[index];
    }
  }
  return result;
}

[[nodiscard]] BigInt signed_dot_backlog(
    const std::span<const std::int8_t> signature,
    const Backlog& backlog) {
  BigInt result = 0;
  for (std::size_t index = 0U; index < signature.size(); ++index) {
    if (signature[index] > 0) {
      result += backlog.values()[index].value();
    } else if (signature[index] < 0) {
      result -= backlog.values()[index].value();
    }
  }
  return result;
}

[[nodiscard]] BigInt signed_dot_schedule(
    const std::span<const std::int8_t> signature,
    const Schedule& schedule) {
  BigInt result = 0;
  for (std::size_t index = 0U; index < signature.size(); ++index) {
    if (schedule.bytes()[index] != 0U) {
      result += signature[index];
    }
  }
  return result;
}

[[nodiscard]] Result<BigInt> signed_dot_arrival(
    const std::span<const std::int8_t> signature,
    const ArrivalBatch& arrival_batch) {
  BigInt result = 0;
  for (const ArrivalBatchEntry& entry : arrival_batch.entries()) {
    if (entry.queue.ordinal() >= signature.size()) {
      return Result<BigInt>::failure(invalid_request(
          "margin_arrival_dimension_mismatch",
          "an arrival coordinate lies outside the margin dimension"));
    }
    const std::int8_t coefficient = signature[entry.queue.ordinal()];
    if (coefficient > 0) {
      result += entry.count.value();
    } else if (coefficient < 0) {
      result -= entry.count.value();
    }
  }
  return Result<BigInt>::success(std::move(result));
}

[[nodiscard]] Result<void> validate_schedule_feasible(
    const ConstraintDescriptor& descriptor, const Schedule& schedule) {
  if (!schedule.dimension().matches(descriptor)) {
    return Result<void>::failure(invalid_request(
        "schedule_pair_constraint_identity_mismatch",
        "a schedule-pair endpoint is not bound to the supplied constraint"));
  }

  return std::visit(
      [&schedule]<typename Constraint>(const Constraint& constraint)
          -> Result<void> {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::same_as<Type, ResolvedCrossbarConstraint>) {
          std::vector<std::uint8_t> inputs(constraint.inputs.size(), 0U);
          std::vector<std::uint8_t> outputs(constraint.outputs.size(), 0U);
          for (const ResolvedCrossbarEdge& edge : constraint.edges) {
            if (!schedule.at(edge.queue)) {
              continue;
            }
            if (inputs.at(edge.input.ordinal()) != 0U ||
                outputs.at(edge.output.ordinal()) != 0U) {
              return Result<void>::failure(invalid_request(
                  "schedule_pair_endpoint_infeasible",
                  "a schedule-pair endpoint selects conflicting crossbar "
                  "edges"));
            }
            inputs[edge.input.ordinal()] = 1U;
            outputs[edge.output.ordinal()] = 1U;
          }
        } else if constexpr (std::same_as<Type,
                                          ResolvedIntervalConstraint>) {
          std::vector<const ResolvedInterval*> selected;
          for (const ResolvedInterval& interval : constraint.intervals) {
            if (schedule.at(interval.queue)) {
              selected.push_back(&interval);
            }
          }
          std::ranges::sort(selected, [](const ResolvedInterval* left,
                                         const ResolvedInterval* right) {
            if (left->left != right->left) {
              return left->left < right->left;
            }
            return left->right < right->right;
          });
          for (std::size_t index = 1U; index < selected.size(); ++index) {
            if (!(selected[index - 1U]->right <= selected[index]->left)) {
              return Result<void>::failure(invalid_request(
                  "schedule_pair_endpoint_infeasible",
                  "a schedule-pair endpoint selects overlapping intervals"));
            }
          }
        } else if constexpr (std::same_as<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          std::vector<std::uint8_t> vertices(constraint.vertices.size(), 0U);
          for (const ResolvedNodeExclusiveLink& link : constraint.links) {
            if (!schedule.at(link.queue)) {
              continue;
            }
            if (vertices.at(link.u.ordinal()) != 0U ||
                vertices.at(link.v.ordinal()) != 0U) {
              return Result<void>::failure(invalid_request(
                  "schedule_pair_endpoint_infeasible",
                  "a schedule-pair endpoint selects links sharing a vertex"));
            }
            vertices[link.u.ordinal()] = 1U;
            vertices[link.v.ordinal()] = 1U;
          }
        } else if constexpr (std::same_as<Type,
                                          ResolvedConflictConstraint>) {
          for (const ResolvedConflictPair& conflict : constraint.conflicts) {
            if (schedule.at(conflict.first) &&
                schedule.at(conflict.second)) {
              return Result<void>::failure(invalid_request(
                  "schedule_pair_endpoint_infeasible",
                  "a schedule-pair endpoint contains a configured conflict"));
            }
          }
        } else {
          std::vector<BigNat> used(constraint.resources.size(), BigNat(0U));
          for (const ResolvedPackingDemand& demand : constraint.demands) {
            if (!schedule.at(demand.queue)) {
              continue;
            }
            for (std::size_t resource = 0U;
                 resource < constraint.resources.size(); ++resource) {
              used[resource] += demand.demand.at(resource);
              if (used[resource] > constraint.capacity.at(resource)) {
                return Result<void>::failure(invalid_request(
                    "schedule_pair_endpoint_infeasible",
                    "a schedule-pair endpoint exceeds a packing capacity"));
              }
            }
          }
        }
        return Result<void>::success();
      },
      descriptor.value());
}

struct IntegralSupportSolve final {
  BigNat value;
  OptimizerSolution certificate;
};

[[nodiscard]] Result<IntegralSupportSolve> solve_integral_support(
    const ResolvedInstance& instance, const PrimaryWeights& primary,
    const OptimizerQueryKind query_kind,
    OptimizerExecutionContext& optimizer_context) {
  if (!primary.dimension().matches(instance)) {
    return Result<IntegralSupportSolve>::failure(invalid_request(
        "support_instance_identity_mismatch",
        "the support weights do not belong to the supplied resolved "
        "instance"));
  }
  if (!optimizer_context.matches_dimension(primary.dimension())) {
    return Result<IntegralSupportSolve>::failure(invalid_request(
        "support_optimizer_context_mismatch",
        "the optimizer context is not bound to the support query instance"));
  }

  EligibilityMask eligibility = EligibilityMask::all(primary.dimension());
  auto lex_result = compose_lexicographic_weights(
      primary, instance.priority(), eligibility);
  if (!lex_result) {
    return Result<IntegralSupportSolve>::failure(
        std::move(lex_result.error()));
  }
  LexWeights weights = std::move(lex_result).value();

  auto budget_result = begin_search_budget(optimizer_context);
  if (!budget_result) {
    return Result<IntegralSupportSolve>::failure(
        std::move(budget_result.error()));
  }
  SearchBudget budget = std::move(budget_result).value();
  auto identity = budget.set_query_kind(query_kind);
  if (!identity) {
    return Result<IntegralSupportSolve>::failure(
        std::move(identity.error()));
  }

  auto solution_result =
      solve_exact(instance.constraint(), eligibility, weights, budget);
  if (!solution_result) {
    return Result<IntegralSupportSolve>::failure(
        std::move(solution_result.error()));
  }
  OptimizerSolution solution = std::move(solution_result).value();
  if (solution.accounting() != budget.accounting() ||
      solution.accounting().query_kind() != query_kind ||
      solution.accounting().target().has_value()) {
    return Result<IntegralSupportSolve>::failure(invariant_failure(
        "support_accounting_mismatch",
        "the exact support result is not tied to its classified live solve"));
  }

  const BigNat unaugmented = exact_dot(primary.values(), solution.schedule());
  BigNat secondary(std::uint64_t{0U});
  BigNat composite(std::uint64_t{0U});
  for (std::size_t index = 0U; index < solution.schedule().size(); ++index) {
    if (solution.schedule().bytes()[index] != 0U) {
      secondary += weights.secondary_weights()[index];
      composite += weights.values()[index];
    }
  }
  BigNat reconstructed = unaugmented * weights.primary_scale();
  reconstructed += secondary;
  if (composite != solution.composite_objective() ||
      reconstructed != composite) {
    return Result<IntegralSupportSolve>::failure(invariant_failure(
        "support_objective_decomposition_mismatch",
        "the selected support witness does not reproduce its exact composite "
        "objective"));
  }

  return Result<IntegralSupportSolve>::success(
      IntegralSupportSolve{unaugmented, std::move(solution)});
}

[[nodiscard]] Result<void> validate_arrival_dimension(
    const ArrivalBatch& arrival_batch, const std::size_t dimension,
    const std::string_view code) {
  if (arrival_batch.binding().has_value() &&
      arrival_batch.binding()->queue_cardinality != dimension) {
    return Result<void>::failure(invalid_request(
        std::string(code),
        "the arrival batch binding does not match the exact coordinate "
        "dimension"));
  }
  for (const ArrivalBatchEntry& entry : arrival_batch.entries()) {
    if (entry.queue.ordinal() >= dimension) {
      return Result<void>::failure(invalid_request(
          std::string(code),
          "an arrival entry lies outside the exact coordinate dimension"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<BigNat> arrival_dot(
    const std::span<const BigNat> direction,
    const ArrivalBatch& arrival_batch) {
  auto valid = validate_arrival_dimension(
      arrival_batch, direction.size(), "resource_arrival_dimension_mismatch");
  if (!valid) {
    return Result<BigNat>::failure(std::move(valid.error()));
  }
  BigNat value(std::uint64_t{0U});
  for (const ArrivalBatchEntry& entry : arrival_batch.entries()) {
    value += direction[entry.queue.ordinal()] * entry.count;
  }
  return Result<BigNat>::success(std::move(value));
}

}  // namespace

Result<NonnegativeIntegralDirection>
NonnegativeIntegralDirection::from_values(QueueDimensionToken dimension,
                                          std::vector<BigNat> values) {
  try {
    if (values.size() != dimension.cardinality()) {
      return Result<NonnegativeIntegralDirection>::failure(invalid_request(
          "resource_direction_dimension_mismatch",
          "the integral resource direction does not match its queue "
          "dimension"));
    }
    if (std::ranges::all_of(values,
                            [](const BigNat& value) { return value.is_zero(); })) {
      return Result<NonnegativeIntegralDirection>::failure(invalid_request(
          "resource_direction_zero",
          "an integral resource direction must contain a positive "
          "coordinate"));
    }
    auto digest = digest_integral_vector(
        "mwperf.c13.resource_direction.v1", dimension, values);
    if (!digest) {
      return Result<NonnegativeIntegralDirection>::failure(
          std::move(digest.error()));
    }
    return Result<NonnegativeIntegralDirection>::success(
        NonnegativeIntegralDirection(std::move(dimension), std::move(values),
                                     std::move(digest).value()));
  } catch (const std::bad_alloc&) {
    return Result<NonnegativeIntegralDirection>::failure(
        representation_failure("resource_direction_allocation_failure",
                               "allocation failed while binding an exact "
                               "resource direction"));
  } catch (const std::length_error&) {
    return Result<NonnegativeIntegralDirection>::failure(
        representation_failure("resource_direction_representation_failure",
                               "the exact resource direction exceeds a host "
                               "container limit"));
  }
}

Result<ResourceCoordinate> ResourceCoordinate::make(
    NonnegativeIntegralDirection direction, BigNat capacity,
    BigNat workload, BigNat unused_capacity, BigNat lower_queue,
    const bool lower_domination_declared) {
  try {
    BigNat direction_one_norm(std::uint64_t{0U});
    for (const BigNat& value : direction.values()) {
      direction_one_norm += value;
    }
    if (capacity.is_zero() || capacity > direction_one_norm) {
      return Result<ResourceCoordinate>::failure(invalid_request(
          "resource_capacity_invalid",
          "a nonzero individually serviceable direction requires positive "
          "capacity no larger than its exact one-norm"));
    }
    if (unused_capacity > capacity) {
      return Result<ResourceCoordinate>::failure(invalid_request(
          "resource_unused_capacity_exceeds_capacity",
          "unused capacity cannot exceed the resource support capacity"));
    }
    if (lower_domination_declared && lower_queue > workload) {
      return Result<ResourceCoordinate>::failure(invalid_request(
          "resource_lower_domination_invalid",
          "a declared lower resource queue exceeds its workload"));
    }
    return Result<ResourceCoordinate>::success(ResourceCoordinate(
        std::move(direction), std::move(capacity), std::move(workload),
        std::move(unused_capacity), std::move(lower_queue),
        lower_domination_declared));
  } catch (const std::bad_alloc&) {
    return Result<ResourceCoordinate>::failure(representation_failure(
        "resource_coordinate_allocation_failure",
        "allocation failed while binding an exact resource coordinate"));
  } catch (const std::length_error&) {
    return Result<ResourceCoordinate>::failure(representation_failure(
        "resource_coordinate_representation_failure",
        "the exact resource coordinate exceeds a host representation limit"));
  }
}

Result<ResourceState> ResourceState::from_coordinates(
    std::vector<ResourceCoordinate> coordinates) {
  if (coordinates.empty()) {
    return Result<ResourceState>::failure(invalid_request(
        "resource_state_empty",
        "a resource state must contain at least one selected coordinate"));
  }
  const QueueDimensionToken dimension =
      coordinates.front().direction().dimension();
  for (const ResourceCoordinate& coordinate : coordinates) {
    if (coordinate.direction().dimension() != dimension) {
      return Result<ResourceState>::failure(invalid_request(
          "resource_state_dimension_identity_mismatch",
          "all selected resource coordinates must share one exact queue "
          "dimension"));
    }
    if (coordinate.unused_capacity() > coordinate.capacity()) {
      return Result<ResourceState>::failure(invalid_request(
          "resource_state_unused_capacity_invalid",
          "a selected coordinate has unused capacity above its support "
          "capacity"));
    }
    if (coordinate.lower_domination_declared() &&
        coordinate.lower_queue() > coordinate.workload()) {
      return Result<ResourceState>::failure(invalid_request(
          "resource_state_lower_domination_invalid",
          "a selected coordinate violates its declared lower-queue "
          "domination"));
    }
  }
  return Result<ResourceState>::success(
      ResourceState(std::move(coordinates)));
}

Result<ExactNonnegativeRationalWeights>
ExactNonnegativeRationalWeights::from_values(
    QueueDimensionToken dimension, std::vector<ExactRational> values,
    RationalSupportRepresentationBudget representation_budget) {
  try {
    if (values.size() != dimension.cardinality()) {
      return Result<ExactNonnegativeRationalWeights>::failure(invalid_request(
          "rational_support_dimension_mismatch",
          "the rational support vector does not match its queue dimension"));
    }
    for (const ExactRational& value : values) {
      if (!value.is_nonnegative()) {
        return Result<ExactNonnegativeRationalWeights>::failure(
            invalid_request("rational_support_negative_weight",
                            "rational support weights must be nonnegative"));
      }
      if (value.denominator() <= 0 ||
          exact_gcd(value.numerator(), value.denominator()) != 1 ||
          (value.numerator() == 0 && value.denominator() != 1)) {
        return Result<ExactNonnegativeRationalWeights>::failure(
            invalid_request("rational_support_noncanonical_weight",
                            "every rational support weight must be finite and "
                            "in reduced canonical form"));
      }
    }
    auto digest = digest_rational_vector(dimension, values);
    if (!digest) {
      return Result<ExactNonnegativeRationalWeights>::failure(
          std::move(digest.error()));
    }
    return Result<ExactNonnegativeRationalWeights>::success(
        ExactNonnegativeRationalWeights(
            std::move(dimension), std::move(values),
            std::move(representation_budget), std::move(digest).value()));
  } catch (const std::bad_alloc&) {
    return Result<ExactNonnegativeRationalWeights>::failure(
        representation_failure("rational_support_allocation_failure",
                               "allocation failed while binding exact rational "
                               "support weights"));
  } catch (const std::length_error&) {
    return Result<ExactNonnegativeRationalWeights>::failure(
        representation_failure("rational_support_representation_failure",
                               "the rational support vector exceeds a host "
                               "container limit"));
  }
}

Result<Opportunity> compute_target_opportunity(
    const ResolvedInstance& instance, const Backlog& backlog,
    TargetIndex target, OptimizerExecutionContext& optimizer_context) {
  try {
    if (!backlog.dimension().matches(instance)) {
      return Result<Opportunity>::failure(invalid_request(
          "opportunity_instance_identity_mismatch",
          "the backlog does not belong to the supplied resolved instance"));
    }
    if (!target.matches(backlog.dimension())) {
      return Result<Opportunity>::failure(invalid_request(
          "opportunity_target_identity_mismatch",
          "the target and backlog belong to different queue dimensions"));
    }
    if (!optimizer_context.matches_dimension(backlog.dimension())) {
      return Result<Opportunity>::failure(invalid_request(
          "opportunity_optimizer_context_mismatch",
          "the optimizer context is not bound to the opportunity instance"));
    }

    auto primary_result = PrimaryWeights::from_values(
        backlog.dimension(),
        std::vector<BigNat>(backlog.values().begin(), backlog.values().end()));
    if (!primary_result) {
      return Result<Opportunity>::failure(
          std::move(primary_result.error()));
    }
    PrimaryWeights primary = std::move(primary_result).value();

    // Removing a zero-weight non-target coordinate cannot change Psi, while
    // matching the physical eligibility convention gives witnesses usable by
    // the configured priority resolver. solve_forced_target independently
    // overrides the target side and removes the target primary contribution.
    std::vector<std::uint8_t> eligible_bytes(backlog.size(), 0U);
    for (std::size_t index = 0U; index < backlog.size(); ++index) {
      eligible_bytes[index] = backlog.values()[index].is_zero() ? 0U : 1U;
    }
    auto eligibility_result = EligibilityMask::from_bytes(
        backlog.dimension(), std::move(eligible_bytes));
    if (!eligibility_result) {
      return Result<Opportunity>::failure(
          std::move(eligibility_result.error()));
    }
    EligibilityMask physical_residual_eligibility =
        std::move(eligibility_result).value();
    auto out_result = solve_forced_target(
        optimizer_context, instance.constraint(),
        physical_residual_eligibility, primary, target,
        ForcedTargetBit::zero, instance.priority());
    if (!out_result) {
      return Result<Opportunity>::failure(std::move(out_result.error()));
    }
    PrimaryOptimum forced_out = std::move(out_result).value();

    auto in_result = solve_forced_target(
        optimizer_context, instance.constraint(),
        physical_residual_eligibility, primary, target,
        ForcedTargetBit::one, instance.priority());
    if (!in_result) {
      return Result<Opportunity>::failure(std::move(in_result.error()));
    }
    PrimaryOptimum forced_in = std::move(in_result).value();

    if (forced_out.target != target || forced_in.target != target ||
        forced_out.side != ForcedTargetBit::zero ||
        forced_in.side != ForcedTargetBit::one ||
        forced_out.family != instance.constraint().family() ||
        forced_in.family != instance.constraint().family() ||
        forced_out.backend_id != instance.service_identity().optimizer ||
        forced_in.backend_id != instance.service_identity().optimizer) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_forced_certificate_identity_mismatch",
          "a forced-face certificate does not identify the requested target, "
          "side, service family, and exact backend"));
    }
    const SearchAccounting& out_accounting = forced_out.accounting;
    const SearchAccounting& in_accounting = forced_in.accounting;
    BigNat expected_in_ordinal = out_accounting.call_ordinal();
    expected_in_ordinal += BigNat(1U);
    if (out_accounting.query_kind() != OptimizerQueryKind::forced_zero ||
        in_accounting.query_kind() != OptimizerQueryKind::forced_one ||
        !out_accounting.target().has_value() ||
        !in_accounting.target().has_value() ||
        *out_accounting.target() != target ||
        *in_accounting.target() != target ||
        !out_accounting.family().has_value() ||
        !in_accounting.family().has_value() ||
        *out_accounting.family() != instance.constraint().family() ||
        *in_accounting.family() != instance.constraint().family() ||
        out_accounting.exhausted() || in_accounting.exhausted() ||
        in_accounting.call_ordinal() != expected_in_ordinal) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_forced_accounting_mismatch",
          "the two forced-face certificates do not retain consecutive live "
          "forced-zero/forced-one optimizer accounting"));
    }
    if (forced_out.witness.bytes()[target.ordinal()] != 0U ||
        forced_in.witness.bytes()[target.ordinal()] != 1U) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_forced_witness_side_mismatch",
          "a forced-face witness has the wrong target bit"));
    }

    auto theta_result = checked_subtract(forced_out.value, forced_in.value);
    if (!theta_result) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_downward_closure_invariant_broken",
          "the forced-out objective is below the forced-in residual "
          "objective"));
    }
    BigNat theta = std::move(theta_result).value();

    BigNat competitor_sum(std::uint64_t{0U});
    for (std::size_t index = 0U; index < backlog.size(); ++index) {
      if (index != target.ordinal()) {
        competitor_sum += backlog.values()[index];
      }
    }
    if (theta > competitor_sum) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_elementary_bound_broken",
          "the exact opportunity threshold exceeds the competitor backlog "
          "one-norm"));
    }

    const BigInt margin =
        backlog.values()[target.ordinal()].value() - theta.value();
    const BigInt lower_bound =
        backlog.values()[target.ordinal()].value() - competitor_sum.value();
    if (margin < lower_bound ||
        margin > backlog.values()[target.ordinal()].value()) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_margin_bound_broken",
          "the exact target margin violates its global elementary bounds"));
    }

    const BigNat out_complete = forced_out.value;
    BigNat in_complete = forced_in.value;
    in_complete += backlog.values()[target.ordinal()];

    ForcedTargetBit equality_side = ForcedTargetBit::zero;
    const PrimaryOptimum* equality_certificate = &forced_out;
    if (forced_in.secondary_code > forced_out.secondary_code) {
      equality_side = ForcedTargetBit::one;
      equality_certificate = &forced_in;
    } else if (forced_in.secondary_code == forced_out.secondary_code) {
      return Result<Opportunity>::failure(invariant_failure(
          "opportunity_equality_priority_not_unique",
          "the configured complete priority code does not distinguish the "
          "two forced classes"));
    }
    EqualityWinnerEvidence equality_winner{
        .winning_side = equality_side,
        .winning_schedule = equality_certificate->witness,
        .common_primary_objective = forced_out.value,
        .winning_secondary_code = equality_certificate->secondary_code,
    };

    AlgebraicTargetClass algebraic_class = AlgebraicTargetClass::tie;
    ForcedTargetBit actual_side = equality_side;
    const PrimaryOptimum* actual_certificate = equality_certificate;
    if (margin < 0) {
      algebraic_class = AlgebraicTargetClass::forced_out;
      actual_side = ForcedTargetBit::zero;
      actual_certificate = &forced_out;
    } else if (margin > 0) {
      algebraic_class = AlgebraicTargetClass::forced_in;
      actual_side = ForcedTargetBit::one;
      actual_certificate = &forced_in;
    }
    CrossClassOutcome outcome{
        .algebraic_class = algebraic_class,
        .target_eligible =
            !backlog.values()[target.ordinal()].is_zero(),
        .configured_winning_side = actual_side,
        .configured_winning_schedule = actual_certificate->witness,
        .forced_out_complete_objective = out_complete,
        .forced_in_complete_objective = in_complete,
        .configured_winning_secondary_code =
            actual_certificate->secondary_code,
    };

    std::string certificate_bytes;
    append_framed(certificate_bytes, instance.fingerprints().combined.hex());
    append_framed(certificate_bytes,
                  std::string(to_string(instance.constraint().family())));
    append_framed(certificate_bytes, std::to_string(target.ordinal()));
    for (const BigNat& value : backlog.values()) {
      append_nat(certificate_bytes, value);
    }
    append_nat(certificate_bytes, forced_out.value);
    append_nat(certificate_bytes, forced_in.value);
    append_nat(certificate_bytes, theta);
    append_int(certificate_bytes, margin);
    append_schedule(certificate_bytes, forced_out.witness);
    append_schedule(certificate_bytes, forced_in.witness);
    append_nat(certificate_bytes, forced_out.secondary_code);
    append_nat(certificate_bytes, forced_in.secondary_code);
    auto digest = digest_text("mwperf.c13.opportunity.v1",
                              certificate_bytes);
    if (!digest) {
      return Result<Opportunity>::failure(std::move(digest.error()));
    }

    BigNat psi0 = forced_out.value;
    BigNat psi1 = forced_in.value;
    return Result<Opportunity>::success(Opportunity(
        std::move(target), backlog, std::move(digest).value(),
        std::move(psi0), std::move(psi1), std::move(theta), margin,
        std::move(outcome), std::move(equality_winner),
        std::move(forced_out), std::move(forced_in)));
  } catch (const std::bad_alloc&) {
    return Result<Opportunity>::failure(representation_failure(
        "opportunity_allocation_failure",
        "allocation failed while computing an exact target opportunity"));
  } catch (const std::length_error&) {
    return Result<Opportunity>::failure(representation_failure(
        "opportunity_representation_failure",
        "the exact target opportunity exceeds a host container limit"));
  }
}

TargetClass classify_target_decision(const Opportunity& opportunity,
                                     TargetBacklog target_backlog) {
  BigInt margin =
      target_backlog.value().value() - opportunity.theta().value();
  AlgebraicTargetClass algebraic_class = AlgebraicTargetClass::tie;
  if (margin < 0) {
    algebraic_class = AlgebraicTargetClass::forced_out;
  } else if (margin > 0) {
    algebraic_class = AlgebraicTargetClass::forced_in;
  }
  return TargetClass{
      .algebraic_class = algebraic_class,
      .eligible = !target_backlog.value().is_zero(),
      .algebraic_margin = std::move(margin),
  };
}

Result<BigNat> compute_resource_capacity(
    const ResolvedInstance& instance,
    const NonnegativeIntegralDirection& direction,
    OptimizerExecutionContext& optimizer_context) {
  try {
    if (!direction.dimension().matches(instance)) {
      return Result<BigNat>::failure(invalid_request(
          "resource_capacity_instance_identity_mismatch",
          "the resource direction does not belong to the supplied resolved "
          "instance"));
    }
    auto primary_result = PrimaryWeights::from_values(
        direction.dimension(),
        std::vector<BigNat>(direction.values().begin(),
                            direction.values().end()));
    if (!primary_result) {
      return Result<BigNat>::failure(std::move(primary_result.error()));
    }
    auto solve = solve_integral_support(
        instance, primary_result.value(), OptimizerQueryKind::integral_support,
        optimizer_context);
    if (!solve) {
      return Result<BigNat>::failure(std::move(solve.error()));
    }
    BigNat capacity = std::move(solve).value().value;
    BigNat direction_one_norm(std::uint64_t{0U});
    for (const BigNat& value : direction.values()) {
      direction_one_norm += value;
    }
    if (capacity.is_zero() || capacity > direction_one_norm) {
      return Result<BigNat>::failure(invariant_failure(
          "resource_capacity_postcondition_broken",
          "individual serviceability and binary scheduling require a positive "
          "capacity no larger than the direction one-norm"));
    }
    return Result<BigNat>::success(std::move(capacity));
  } catch (const std::bad_alloc&) {
    return Result<BigNat>::failure(representation_failure(
        "resource_capacity_allocation_failure",
        "allocation failed during the exact integral support query"));
  } catch (const std::length_error&) {
    return Result<BigNat>::failure(representation_failure(
        "resource_capacity_representation_failure",
        "the exact integral support query exceeds a host container limit"));
  }
}

Result<ResourceState> update_resource_coordinates(
    const ResourceState& state, const Schedule& schedule,
    const ArrivalBatch& arrival_batch) {
  try {
    if (schedule.dimension() != state.dimension()) {
      return Result<ResourceState>::failure(invalid_request(
          "resource_update_schedule_dimension_mismatch",
          "the actual departure vector and resource state belong to different "
          "queue dimensions"));
    }
    auto arrival_validation = validate_arrival_dimension(
        arrival_batch, schedule.size(),
        "resource_update_arrival_dimension_mismatch");
    if (!arrival_validation) {
      return Result<ResourceState>::failure(
          std::move(arrival_validation.error()));
    }

    std::vector<ResourceCoordinate> next;
    next.reserve(state.coordinates().size());
    for (const ResourceCoordinate& coordinate : state.coordinates()) {
      const BigNat served =
          exact_dot(coordinate.direction().values(), schedule);
      if (served > coordinate.capacity()) {
        return Result<ResourceState>::failure(invalid_request(
            "resource_service_exceeds_capacity",
            "the supplied actual departure exceeds a selected resource "
            "capacity"));
      }
      if (served > coordinate.workload()) {
        return Result<ResourceState>::failure(invalid_request(
            "resource_service_exceeds_workload",
            "the supplied departure cannot be actual for the selected exact "
            "workload"));
      }
      auto arrived = arrival_dot(coordinate.direction().values(),
                                 arrival_batch);
      if (!arrived) {
        return Result<ResourceState>::failure(std::move(arrived.error()));
      }
      auto remaining = checked_subtract(coordinate.workload(), served);
      auto unused = checked_subtract(coordinate.capacity(), served);
      if (!remaining || !unused) {
        return Result<ResourceState>::failure(invariant_failure(
            "resource_checked_subtraction_failed",
            "a validated resource update unexpectedly underflowed"));
      }
      BigNat next_workload = std::move(remaining).value();
      next_workload += arrived.value();

      BigNat next_lower(std::uint64_t{0U});
      if (coordinate.lower_queue() > coordinate.capacity()) {
        auto lower_remaining = checked_subtract(coordinate.lower_queue(),
                                                coordinate.capacity());
        if (!lower_remaining) {
          return Result<ResourceState>::failure(invariant_failure(
              "resource_lower_checked_subtraction_failed",
              "a validated lower-queue update unexpectedly underflowed"));
        }
        next_lower = std::move(lower_remaining).value();
      }
      next_lower += arrived.value();
      if (coordinate.lower_domination_declared() &&
          next_lower > next_workload) {
        return Result<ResourceState>::failure(invariant_failure(
            "resource_lower_domination_broken",
            "the timing-matched lower resource queue exceeds the exact "
            "workload successor"));
      }

      next.push_back(ResourceCoordinate(
          coordinate.direction(), coordinate.capacity(),
          std::move(next_workload), std::move(unused).value(),
          std::move(next_lower), coordinate.lower_domination_declared()));
    }
    return Result<ResourceState>::success(ResourceState(std::move(next)));
  } catch (const std::bad_alloc&) {
    return Result<ResourceState>::failure(representation_failure(
        "resource_update_allocation_failure",
        "allocation failed during the transactional resource update"));
  } catch (const std::length_error&) {
    return Result<ResourceState>::failure(representation_failure(
        "resource_update_representation_failure",
        "the transactional resource update exceeds a host container limit"));
  }
}

Result<RationalSupportCertificate> compute_rational_support(
    const ResolvedInstance& instance,
    const ExactNonnegativeRationalWeights& weights,
    OptimizerExecutionContext& optimizer_context) {
  try {
    if (!weights.dimension().matches(instance)) {
      return Result<RationalSupportCertificate>::failure(invalid_request(
          "rational_support_instance_identity_mismatch",
          "the rational support vector does not belong to the supplied "
          "resolved instance"));
    }
    if (!optimizer_context.matches_dimension(weights.dimension())) {
      return Result<RationalSupportCertificate>::failure(invalid_request(
          "rational_support_optimizer_context_mismatch",
          "the optimizer context is not bound to the rational support "
          "instance"));
    }

    BigInt clearing = 1;
    for (const ExactRational& value : weights.values()) {
      const BigInt divisor = exact_gcd(clearing, value.denominator());
      const BigInt reduced_clearing = clearing / divisor;
      const auto& clearing_limit =
          weights.representation_budget()
              .maximum_clearing_denominator_bits;
      if (clearing_limit.has_value() &&
          product_definitely_exceeds_bit_limit(
              reduced_clearing, value.denominator(), *clearing_limit)) {
        return Result<RationalSupportCertificate>::failure(
            representation_failure(
                "rational_support_clearing_denominator_budget_exceeded",
                "the exact least common denominator exceeds its authored "
                "representation budget"));
      }
      clearing = reduced_clearing * value.denominator();
      if (clearing_limit.has_value() &&
          positive_bit_length(clearing) > *clearing_limit) {
        return Result<RationalSupportCertificate>::failure(
            representation_failure(
                "rational_support_clearing_denominator_budget_exceeded",
                "the exact least common denominator exceeds its authored "
                "representation budget"));
      }
    }

    std::vector<BigNat> cleared_values;
    cleared_values.reserve(weights.values().size());
    for (const ExactRational& value : weights.values()) {
      const BigInt clearing_factor = clearing / value.denominator();
      const auto& weight_limit =
          weights.representation_budget().maximum_cleared_weight_bits;
      if (weight_limit.has_value() &&
          product_definitely_exceeds_bit_limit(
              value.numerator(), clearing_factor, *weight_limit)) {
        return Result<RationalSupportCertificate>::failure(
            representation_failure(
                "rational_support_cleared_weight_budget_exceeded",
                "a cleared exact support weight exceeds its authored "
                "representation budget"));
      }
      const BigInt cleared = value.numerator() * clearing_factor;
      if (cleared < 0) {
        return Result<RationalSupportCertificate>::failure(
            invariant_failure("rational_support_clearing_negative",
                              "denominator clearing produced a negative "
                              "integral weight"));
      }
      if (weight_limit.has_value() &&
          positive_bit_length(cleared) > *weight_limit) {
        return Result<RationalSupportCertificate>::failure(
            representation_failure(
                "rational_support_cleared_weight_budget_exceeded",
                "a cleared exact support weight exceeds its authored "
                "representation budget"));
      }
      auto exact = BigNat::from_big_int(cleared);
      if (!exact) {
        return Result<RationalSupportCertificate>::failure(invariant_failure(
            "rational_support_clearing_nonnegative_invariant_broken",
            "denominator clearing could not form a nonnegative integral "
            "weight"));
      }
      cleared_values.push_back(std::move(exact).value());
    }

    auto clearing_nat = BigNat::from_big_int(clearing);
    if (!clearing_nat) {
      return Result<RationalSupportCertificate>::failure(invariant_failure(
          "rational_support_denominator_positive_invariant_broken",
          "the clearing denominator is not positive"));
    }
    auto primary_result = PrimaryWeights::from_values(
        weights.dimension(), std::move(cleared_values));
    if (!primary_result) {
      return Result<RationalSupportCertificate>::failure(
          std::move(primary_result.error()));
    }
    PrimaryWeights primary = std::move(primary_result).value();
    auto cleared_digest = digest_integral_vector(
        "mwperf.c13.cleared_rational_weights.v1", primary.dimension(),
        primary.values());
    if (!cleared_digest) {
      return Result<RationalSupportCertificate>::failure(
          std::move(cleared_digest.error()));
    }

    auto solve = solve_integral_support(
        instance, primary, OptimizerQueryKind::rational_support,
        optimizer_context);
    if (!solve) {
      return Result<RationalSupportCertificate>::failure(
          std::move(solve.error()));
    }
    IntegralSupportSolve solved = std::move(solve).value();
    auto support = ExactRational::make(solved.value.value(), clearing);
    if (!support) {
      return Result<RationalSupportCertificate>::failure(
          invariant_failure("rational_support_readout_failure",
                            "the selected integral witness could not be read "
                            "back as an exact rational support value"));
    }
    auto priority_identity = digest_priority(instance.priority());
    if (!priority_identity) {
      return Result<RationalSupportCertificate>::failure(
          std::move(priority_identity.error()));
    }

    return Result<RationalSupportCertificate>::success(
        RationalSupportCertificate(
            weights, std::move(clearing_nat).value(), std::move(primary),
            std::move(cleared_digest).value(), std::move(support).value(),
            std::move(solved.certificate),
            std::move(priority_identity).value(),
            instance.fingerprints().combined, instance.constraint().family()));
  } catch (const std::bad_alloc&) {
    return Result<RationalSupportCertificate>::failure(
        representation_failure("rational_support_allocation_failure",
                               "allocation failed during the exact rational "
                               "support query"));
  } catch (const std::length_error&) {
    return Result<RationalSupportCertificate>::failure(
        representation_failure("rational_support_representation_failure",
                               "the exact rational support query exceeds a "
                               "host container limit"));
  }
}

Result<SchedulePair> SchedulePair::make(
    const ResolvedInstance& instance, TargetIndex target,
    Schedule forced_out_representative,
    Schedule forced_in_representative) {
  try {
    const QueueDimensionToken dimension =
        QueueDimensionToken::from_instance(instance);
    if (!target.matches(dimension) ||
        forced_out_representative.dimension() != dimension ||
        forced_in_representative.dimension() != dimension) {
      return Result<SchedulePair>::failure(invalid_request(
          "schedule_pair_dimension_identity_mismatch",
          "the schedule pair, target, and resolved instance do not share one "
          "exact queue dimension"));
    }
    if (forced_out_representative.bytes()[target.ordinal()] != 0U ||
        forced_in_representative.bytes()[target.ordinal()] != 1U) {
      return Result<SchedulePair>::failure(invalid_request(
          "schedule_pair_target_bits_invalid",
          "a schedule pair must contain one forced-out and one forced-in "
          "target endpoint"));
    }
    auto out_feasible = validate_schedule_feasible(
        instance.constraint(), forced_out_representative);
    if (!out_feasible) {
      return Result<SchedulePair>::failure(std::move(out_feasible.error()));
    }
    auto in_feasible = validate_schedule_feasible(
        instance.constraint(), forced_in_representative);
    if (!in_feasible) {
      return Result<SchedulePair>::failure(std::move(in_feasible.error()));
    }

    std::vector<std::int8_t> signature(dimension.cardinality(), 0);
    for (std::size_t index = 0U; index < signature.size(); ++index) {
      signature[index] = static_cast<std::int8_t>(
          static_cast<int>(forced_in_representative.bytes()[index]) -
          static_cast<int>(forced_out_representative.bytes()[index]));
      if (signature[index] < -1 || signature[index] > 1) {
        return Result<SchedulePair>::failure(invariant_failure(
            "schedule_pair_signature_domain_broken",
            "a binary schedule pair produced a signature outside {-1,0,1}"));
      }
    }
    if (signature[target.ordinal()] != 1) {
      return Result<SchedulePair>::failure(invariant_failure(
          "schedule_pair_target_signature_broken",
          "the target coefficient of a forced schedule pair is not one"));
    }

    std::string identity_bytes;
    append_framed(identity_bytes, instance.fingerprints().combined.hex());
    append_framed(identity_bytes,
                  std::string(to_string(instance.constraint().family())));
    append_framed(identity_bytes, std::to_string(target.ordinal()));
    append_schedule(identity_bytes, forced_out_representative);
    append_schedule(identity_bytes, forced_in_representative);
    auto identity = digest_text("mwperf.c13.schedule_pair.v1",
                                identity_bytes);
    if (!identity) {
      return Result<SchedulePair>::failure(std::move(identity.error()));
    }
    return Result<SchedulePair>::success(SchedulePair(
        std::move(target), std::move(forced_out_representative),
        std::move(forced_in_representative), std::move(signature),
        std::move(identity).value()));
  } catch (const std::bad_alloc&) {
    return Result<SchedulePair>::failure(representation_failure(
        "schedule_pair_allocation_failure",
        "allocation failed while validating an exact schedule pair"));
  } catch (const std::length_error&) {
    return Result<SchedulePair>::failure(representation_failure(
        "schedule_pair_representation_failure",
        "the exact schedule pair exceeds a host container limit"));
  } catch (const std::out_of_range&) {
    return Result<SchedulePair>::failure(invariant_failure(
        "schedule_pair_constraint_representation_invalid",
        "the resolved constraint contains an out-of-range coordinate"));
  }
}

Result<PairMargin> evaluate_margin_pair(
    const Backlog& backlog, const SchedulePair& pair,
    const Opportunity& opportunity) {
  try {
    if (backlog != opportunity.evaluation_backlog()) {
      return Result<PairMargin>::failure(invalid_request(
          "margin_opportunity_backlog_mismatch",
          "the opportunity certificate was evaluated at a different exact "
          "backlog"));
    }
    if (pair.target() != opportunity.target()) {
      return Result<PairMargin>::failure(invalid_request(
          "margin_opportunity_target_mismatch",
          "the schedule pair and opportunity certificate identify different "
          "targets"));
    }
    if (pair.forced_out_representative().dimension() !=
            backlog.dimension() ||
        pair.forced_in_representative().dimension() != backlog.dimension()) {
      return Result<PairMargin>::failure(invalid_request(
          "margin_pair_dimension_identity_mismatch",
          "the schedule pair and evaluation backlog belong to different "
          "queue dimensions"));
    }

    BigNat fixed_out = residual_schedule_objective(
        backlog, pair.forced_out_representative(), pair.target());
    BigNat fixed_in = residual_schedule_objective(
        backlog, pair.forced_in_representative(), pair.target());
    auto regret0_result = checked_subtract(opportunity.psi0(), fixed_out);
    auto regret1_result = checked_subtract(opportunity.psi1(), fixed_in);
    if (!regret0_result || !regret1_result) {
      return Result<PairMargin>::failure(invariant_failure(
          "margin_fixed_objective_exceeds_optimum",
          "a structurally feasible schedule-pair endpoint exceeds its exact "
          "forced-class optimum"));
    }
    BigNat regret0 = std::move(regret0_result).value();
    BigNat regret1 = std::move(regret1_result).value();
    const bool side0_valid = regret0.is_zero();
    const bool side1_valid = regret1.is_zero();
    const bool pair_valid = side0_valid && side1_valid;
    const BigInt linear = signed_dot_backlog(pair.signature(), backlog);
    const BigInt exact_correction = regret1.value() - regret0.value();
    if (linear + exact_correction != opportunity.margin()) {
      return Result<PairMargin>::failure(invariant_failure(
          "margin_regret_identity_broken",
          "the fixed-pair coordinate and exact regrets do not reproduce "
          "equation (5.21)"));
    }
    if (pair_valid && linear != opportunity.margin()) {
      return Result<PairMargin>::failure(invariant_failure(
          "margin_pair_identity_broken",
          "a pair-valid schedule signature does not reproduce the exact "
          "opportunity margin"));
    }
    const bool eligible =
        !backlog.values()[pair.target().ordinal()].is_zero();

    const CrossClassOutcome& outcome = opportunity.cross_class_outcome();
    const Schedule& pair_endpoint =
        outcome.configured_winning_side == ForcedTargetBit::zero
            ? pair.forced_out_representative()
            : pair.forced_in_representative();
    RepresentativeSelectionEvidence representative{
        .algebraic_class = outcome.algebraic_class,
        .configured_winning_side = outcome.configured_winning_side,
        .configured_winning_schedule = outcome.configured_winning_schedule,
        .configured_winner_matches_pair_endpoint = same_schedule_bytes(
            outcome.configured_winning_schedule, pair_endpoint),
        .strict_class_comparison =
            outcome.algebraic_class != AlgebraicTargetClass::tie,
    };

    return Result<PairMargin>::success(PairMargin(
        pair, backlog, opportunity.certificate_digest(), linear,
        opportunity.margin(), std::move(fixed_out),
        std::move(fixed_in), std::move(regret0),
        std::move(regret1), side0_valid, side1_valid, pair_valid, eligible,
        std::move(representative)));
  } catch (const std::bad_alloc&) {
    return Result<PairMargin>::failure(representation_failure(
        "margin_evaluation_allocation_failure",
        "allocation failed during exact schedule-pair evaluation"));
  } catch (const std::length_error&) {
    return Result<PairMargin>::failure(representation_failure(
        "margin_evaluation_representation_failure",
        "the exact schedule-pair evaluation exceeds a host container limit"));
  }
}

Result<MarginTransition> update_or_reoptimize_margin(
    const PairMargin& margin, const PhysicalEdge& edge,
    const ResolvedInstance& instance,
    OptimizerExecutionContext& optimizer_context) {
  const ExactMarginEdgeInputs exact_edge(
      edge.pre_state().backlog(), edge.departure(), edge.arrival_step().batch,
      edge.post_state().backlog());
  return update_margin_from_exact_edge(margin, exact_edge, instance,
                                       optimizer_context);
}

Result<MarginTransition> update_margin_from_exact_edge(
    const PairMargin& margin, const ExactMarginEdgeInputs& edge,
    const ResolvedInstance& instance,
    OptimizerExecutionContext& optimizer_context) {
  try {
    const QueueDimensionToken dimension =
        QueueDimensionToken::from_instance(instance);
    if (margin.pair().target().dimension() != dimension ||
        edge.pre_backlog().dimension() != dimension ||
        edge.post_backlog().dimension() != dimension ||
        edge.departure().dimension() != dimension) {
      return Result<MarginTransition>::failure(invalid_request(
          "margin_transition_instance_identity_mismatch",
          "the margin, physical edge, and resolved instance do not share one "
          "exact queue dimension"));
    }
    if (!optimizer_context.matches_dimension(dimension)) {
      return Result<MarginTransition>::failure(invalid_request(
          "margin_transition_optimizer_context_mismatch",
          "the optimizer context is not bound to the margin-transition "
          "instance"));
    }
    if (margin.evaluation_backlog() != edge.pre_backlog()) {
      return Result<MarginTransition>::failure(invalid_request(
          "margin_transition_prestate_mismatch",
          "the margin was not evaluated at the physical edge prestate"));
    }
    if (!margin.pair_valid()) {
      return Result<MarginTransition>::failure(invalid_request(
          "margin_transition_current_pair_invalid",
          "equation (5.22) requires a pair-valid current endpoint"));
    }
    auto arrival_increment = signed_dot_arrival(
        margin.pair().signature(), edge.arrival_batch());
    if (!arrival_increment) {
      return Result<MarginTransition>::failure(
          std::move(arrival_increment.error()));
    }
    const BigInt departure_increment =
        signed_dot_schedule(margin.pair().signature(), edge.departure());
    const BigInt old_increment =
        arrival_increment.value() - departure_increment;
    const BigInt old_linear_next =
        margin.old_pair_linear_coordinate() + old_increment;
    const BigInt direct_linear_next = signed_dot_backlog(
        margin.pair().signature(), edge.post_backlog());
    if (old_linear_next != direct_linear_next) {
      return Result<MarginTransition>::failure(invariant_failure(
          "margin_transition_linear_recursion_broken",
          "the old-pair coordinate does not satisfy the exact edge update"));
    }

    const bool current_eligible = margin.target_eligible();
    bool representative_mismatch = false;
    if (current_eligible && margin.reoptimized_margin() > 0) {
      representative_mismatch = !same_schedule_bytes(
          edge.departure(),
          margin.pair().forced_in_representative());
    } else if (current_eligible && margin.reoptimized_margin() < 0) {
      representative_mismatch = !same_schedule_bytes(
          edge.departure(),
          margin.pair().forced_out_representative());
    }

    auto next_opportunity = compute_target_opportunity(
        instance, edge.post_backlog(), margin.pair().target(),
        optimizer_context);
    if (!next_opportunity) {
      return Result<MarginTransition>::failure(
          std::move(next_opportunity.error()));
    }
    Opportunity successor_opportunity =
        std::move(next_opportunity).value();
    auto next_margin = evaluate_margin_pair(
        edge.post_backlog(), margin.pair(), successor_opportunity);
    if (!next_margin) {
      return Result<MarginTransition>::failure(
          std::move(next_margin.error()));
    }

    const BigNat a0 = next_margin.value().regret0();
    const BigNat a1 = next_margin.value().regret1();
    const BigInt correction = a1.value() - a0.value();
    const BigInt reoptimized_next = old_linear_next + correction;
    if (reoptimized_next != successor_opportunity.margin() ||
        reoptimized_next != next_margin.value().reoptimized_margin()) {
      return Result<MarginTransition>::failure(invariant_failure(
          "margin_transition_exit_correction_broken",
          "the old-pair endpoint plus exact regrets does not reproduce the "
          "reoptimized opportunity margin"));
    }
    const BigInt transition_delta =
        reoptimized_next - margin.reoptimized_margin();
    if (transition_delta != old_increment + correction) {
      return Result<MarginTransition>::failure(invariant_failure(
          "margin_transition_equation_5_22_broken",
          "the exact successor violates the corrected local-margin "
          "recursion"));
    }

    const bool next_valid = next_margin.value().pair_valid();
    const bool next_eligible = next_margin.value().target_eligible();
    const bool target_became_ineligible =
        current_eligible && !next_eligible;
    const bool pair_cell_exit =
        current_eligible && (!next_valid || !next_eligible);
    PairMargin next_value = std::move(next_margin).value();
    return Result<MarginTransition>::success(MarginTransition(
        margin, std::move(next_value), std::move(successor_opportunity),
        old_increment, old_linear_next, reoptimized_next, a0, a1, correction,
        next_valid, true, next_valid, representative_mismatch,
        pair_cell_exit, target_became_ineligible));
  } catch (const std::bad_alloc&) {
    return Result<MarginTransition>::failure(representation_failure(
        "margin_transition_allocation_failure",
        "allocation failed during the exact margin transition"));
  } catch (const std::length_error&) {
    return Result<MarginTransition>::failure(representation_failure(
        "margin_transition_representation_failure",
        "the exact margin transition exceeds a host container limit"));
  }
}

OptimizerCallLedgerSnapshot ConstructionExactQueryServices::ledger_snapshot()
    const {
  return optimizer_context_->ledger_snapshot();
}

ConstructionExactQueryServices::ConstructionExactQueryServices(
    ConstructionExactQueryServices&& other) noexcept
    : instance_(std::move(other.instance_)),
      scope_token_(std::move(other.scope_token_)),
      optimizer_context_(std::exchange(other.optimizer_context_, nullptr)),
      baseline_calls_reserved_(std::move(other.baseline_calls_reserved_)),
      construction_max_calls_(std::move(other.construction_max_calls_)) {}

ConstructionExactQueryServices& ConstructionExactQueryServices::operator=(
    ConstructionExactQueryServices&& other) noexcept {
  if (this != &other) {
    instance_ = std::move(other.instance_);
    scope_token_ = std::move(other.scope_token_);
    optimizer_context_ = std::exchange(other.optimizer_context_, nullptr);
    baseline_calls_reserved_ = std::move(other.baseline_calls_reserved_);
    construction_max_calls_ = std::move(other.construction_max_calls_);
  }
  return *this;
}

Result<ConstructionExactQueryServices>
ConstructionExactQueryServices::bind(
    const ResolvedInstance& instance, BuildIdentityDigest build_identity,
    OptimizerExecutionContext& optimizer_context,
    std::optional<BigNat> construction_max_calls) {
  try {
    const QueueDimensionToken dimension =
        QueueDimensionToken::from_instance(instance);
    if (!optimizer_context.matches_dimension(dimension)) {
      return Result<ConstructionExactQueryServices>::failure(invalid_request(
          "construction_service_optimizer_context_mismatch",
          "the construction service requires a live optimizer context bound "
          "to the resolved instance"));
    }
    const OptimizerCallLedgerSnapshot snapshot =
        optimizer_context.ledger_snapshot();
    if (!snapshot.context_active()) {
      return Result<ConstructionExactQueryServices>::failure(invalid_request(
          "construction_service_optimizer_context_inactive",
          "the construction service cannot borrow an inactive optimizer "
          "context"));
    }
    if (construction_max_calls.has_value() &&
        snapshot.assigned_max_calls().has_value()) {
      auto remaining = checked_subtract(*snapshot.assigned_max_calls(),
                                        snapshot.calls_reserved());
      if (!remaining || *construction_max_calls > remaining.value()) {
        return Result<ConstructionExactQueryServices>::failure(
            reduction_error(
                DiagnosticCategory::resource_limit,
                "construction_service_subgrant_exceeds_remaining_calls",
                "the construction-only call subgrant exceeds the remaining "
                "caller-owned optimizer ledger"));
      }
    }
    auto priority_identity = digest_priority(instance.priority());
    if (!priority_identity) {
      return Result<ConstructionExactQueryServices>::failure(
          std::move(priority_identity.error()));
    }
    std::shared_ptr<const void> anchor =
        std::make_shared<const std::uint8_t>(0U);
    ConstructionScopeToken token(
        std::move(build_identity), dimension, instance.timing(),
        std::move(priority_identity).value(), std::move(anchor));
    return Result<ConstructionExactQueryServices>::success(
        ConstructionExactQueryServices(
            instance, std::move(token), optimizer_context,
            snapshot.calls_reserved(), std::move(construction_max_calls)));
  } catch (const std::bad_alloc&) {
    return Result<ConstructionExactQueryServices>::failure(
        representation_failure(
            "construction_service_allocation_failure",
            "allocation failed while binding the exact construction query "
            "service"));
  } catch (const std::length_error&) {
    return Result<ConstructionExactQueryServices>::failure(
        representation_failure(
            "construction_service_representation_failure",
            "the exact construction query service exceeds a host container "
            "limit"));
  }
}

Result<void> ConstructionExactQueryServices::validate_query(
    const ConstructionScopeToken& scope,
    const QueueDimensionToken& input,
    const BigNat& required_calls) const {
  try {
    if (scope.anchor_ != scope_token_.anchor_) {
      return Result<void>::failure(invalid_request(
          "construction_scope_token_mismatch",
          "the query does not carry this process-local construction scope"));
    }
    if (scope.build_identity_ != scope_token_.build_identity_) {
      return Result<void>::failure(invalid_request(
          "construction_build_identity_mismatch",
          "the query carries a different opaque construction build identity"));
    }
    if (scope.dimension_ != scope_token_.dimension_ ||
        input != scope_token_.dimension_) {
      return Result<void>::failure(invalid_request(
          "construction_instance_identity_mismatch",
          "the construction scope, exact request, and service do not share "
          "one resolved-instance identity"));
    }
    if (scope.timing_ != scope_token_.timing_) {
      return Result<void>::failure(invalid_request(
          "construction_timing_identity_mismatch",
          "the construction scope carries a different physical timing "
          "identity"));
    }
    if (scope.priority_identity_ != scope_token_.priority_identity_) {
      return Result<void>::failure(invalid_request(
          "construction_tie_identity_mismatch",
          "the construction scope carries a different deterministic tie "
          "identity"));
    }
    if (optimizer_context_ == nullptr ||
        !optimizer_context_->matches_dimension(scope_token_.dimension_)) {
      return Result<void>::failure(invalid_request(
          "construction_optimizer_context_mismatch",
          "the borrowed optimizer context is no longer live for this service"));
    }

    const OptimizerCallLedgerSnapshot snapshot =
        optimizer_context_->ledger_snapshot();
    if (!snapshot.context_active()) {
      return Result<void>::failure(invalid_request(
          "construction_optimizer_context_inactive",
          "the borrowed optimizer context is inactive"));
    }
    auto used_result = checked_subtract(snapshot.calls_reserved(),
                                        baseline_calls_reserved_);
    if (!used_result) {
      return Result<void>::failure(invariant_failure(
          "construction_call_ledger_moved_backwards",
          "the caller-owned optimizer call ledger predates the service "
          "baseline"));
    }
    BigNat used_after_query = std::move(used_result).value();
    used_after_query += required_calls;
    if (construction_max_calls_.has_value() &&
        used_after_query > *construction_max_calls_) {
      return Result<void>::failure(reduction_error(
          DiagnosticCategory::resource_limit,
          "construction_call_subgrant_exhausted",
          "the exact construction query would exceed its process-local call "
          "subgrant"));
    }
    if (snapshot.assigned_max_calls().has_value()) {
      BigNat global_after_query = snapshot.calls_reserved();
      global_after_query += required_calls;
      if (global_after_query > *snapshot.assigned_max_calls()) {
        return Result<void>::failure(reduction_error(
            DiagnosticCategory::resource_limit,
            "construction_optimizer_call_ledger_exhausted",
            "the exact construction query would exceed the caller-owned "
            "optimizer call ledger"));
      }
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(representation_failure(
        "construction_query_allocation_failure",
        "allocation failed while checking an exact construction subgrant"));
  } catch (const std::length_error&) {
    return Result<void>::failure(representation_failure(
        "construction_query_representation_failure",
        "the exact construction subgrant check exceeds a host representation "
        "limit"));
  }
}

Result<Opportunity> ConstructionExactQueryServices::query_opportunity(
    const ConstructionScopeToken& scope, const Backlog& backlog,
    TargetIndex target) {
  auto validation = validate_query(scope, backlog.dimension(), BigNat(2U));
  if (!validation) {
    return Result<Opportunity>::failure(std::move(validation.error()));
  }
  return compute_target_opportunity(instance_, backlog, std::move(target),
                                    *optimizer_context_);
}

Result<BigNat> ConstructionExactQueryServices::query_integral_capacity(
    const ConstructionScopeToken& scope,
    const NonnegativeIntegralDirection& direction) {
  auto validation = validate_query(scope, direction.dimension(), BigNat(1U));
  if (!validation) {
    return Result<BigNat>::failure(std::move(validation.error()));
  }
  return compute_resource_capacity(instance_, direction, *optimizer_context_);
}

Result<RationalSupportCertificate>
ConstructionExactQueryServices::query_rational_support(
    const ConstructionScopeToken& scope,
    const ExactNonnegativeRationalWeights& weights) {
  auto validation = validate_query(scope, weights.dimension(), BigNat(1U));
  if (!validation) {
    return Result<RationalSupportCertificate>::failure(
        std::move(validation.error()));
  }
  return compute_rational_support(instance_, weights, *optimizer_context_);
}

Result<ConstructionExactQueryServices>
detail::ConstructionExactQueryBindingAccess::bind(
    const ResolvedInstance& instance, BuildIdentityDigest build_identity,
    OptimizerExecutionContext& optimizer_context,
    std::optional<BigNat> construction_max_calls) {
  return ConstructionExactQueryServices::bind(
      instance, std::move(build_identity), optimizer_context,
      std::move(construction_max_calls));
}

bool detail::ConstructionExactQueryBindingAccess::is_live(
    const ConstructionExactQueryServices& services) noexcept {
  return services.optimizer_context_ != nullptr &&
         static_cast<bool>(services.scope_token_.anchor_) &&
         services.optimizer_context_->matches_dimension(
             services.scope_token_.dimension_);
}

const ResolvedInstance*
detail::ConstructionExactQueryBindingAccess::bound_instance(
    const ConstructionExactQueryServices& services) noexcept {
  return is_live(services) ? &services.instance_ : nullptr;
}

const std::optional<BigNat>&
detail::ConstructionExactQueryBindingAccess::construction_subgrant(
    const ConstructionExactQueryServices& services) noexcept {
  return services.construction_max_calls_;
}

Result<BigNat> detail::ConstructionExactQueryBindingAccess::calls_consumed(
    const ConstructionExactQueryServices& services) {
  if (!is_live(services)) {
    return Result<BigNat>::failure(invalid_request(
        "construction_service_inactive",
        "the exact construction query service is moved-from or its borrowed optimizer context is inactive"));
  }
  const OptimizerCallLedgerSnapshot snapshot =
      services.optimizer_context_->ledger_snapshot();
  if (!snapshot.context_active()) {
    return Result<BigNat>::failure(invalid_request(
        "construction_service_optimizer_context_inactive",
        "the exact construction query service borrows an inactive optimizer context"));
  }
  auto consumed = checked_subtract(snapshot.calls_reserved(),
                                   services.baseline_calls_reserved_);
  if (!consumed) {
    return Result<BigNat>::failure(invariant_failure(
        "construction_call_ledger_moved_backwards",
        "the caller-owned optimizer call ledger predates the service baseline"));
  }
  return consumed;
}

#if defined(MWPERF_C13_TEST_SEAMS)
Result<ConstructionExactQueryServices>
testing::C13ConstructionServiceAccess::bind(
    const ResolvedInstance& instance, BuildIdentityDigest build_identity,
    OptimizerExecutionContext& optimizer_context,
    std::optional<BigNat> construction_max_calls) {
  return ConstructionExactQueryServices::bind(
      instance, std::move(build_identity), optimizer_context,
      std::move(construction_max_calls));
}

ConstructionScopeToken testing::C13ConstructionServiceAccess::mutated_token(
    const ConstructionExactQueryServices& services,
    const ConstructionTokenMutation mutation,
    const ResolvedInstance* foreign_instance) {
  const ConstructionScopeToken& original = services.scope_token_;
  BuildIdentityDigest build_identity = original.build_identity_;
  QueueDimensionToken dimension = original.dimension_;
  TimingConvention timing = original.timing_;
  Digest256 priority_identity = original.priority_identity_;
  std::shared_ptr<const void> anchor = original.anchor_;

  switch (mutation) {
    case ConstructionTokenMutation::scope:
      anchor = std::make_shared<const std::uint8_t>(1U);
      break;
    case ConstructionTokenMutation::instance:
      if (foreign_instance == nullptr) {
        throw std::invalid_argument(
            "an instance-token mutation requires a foreign instance");
      }
      dimension = QueueDimensionToken::from_instance(*foreign_instance);
      timing = foreign_instance->timing();
      break;
    case ConstructionTokenMutation::tie: {
      auto changed = digest_text("mwperf.c13.test.tie_mutation.v1",
                                 priority_identity.hex());
      if (!changed) {
        throw std::logic_error("the static tie mutation digest failed");
      }
      priority_identity = std::move(changed).value();
      break;
    }
  }
  return ConstructionScopeToken(
      std::move(build_identity), std::move(dimension), timing,
      std::move(priority_identity), std::move(anchor));
}
#endif

}  // namespace mwperf
