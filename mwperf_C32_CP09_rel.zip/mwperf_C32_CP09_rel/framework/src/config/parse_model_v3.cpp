#include "mwperf/config/authored_model.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/schema_versions.hpp"

namespace mwperf {
namespace {

enum class PhysicalSchemaDialect : std::uint8_t {
  v3,
  v4,
};

template <typename T>
[[nodiscard]] Result<T> fail(Diagnostic diagnostic) {
  return Result<T>::failure(std::move(diagnostic));
}

[[nodiscard]] Diagnostic diagnostic_at(
    const SourceNode& node, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  notes.insert(notes.begin(),
               "line " + std::to_string(node.location().line) +
                   ", column " + std::to_string(node.location().column));
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    node.location().authored_path,
                    std::string(node.json_pointer()),
                    std::move(notes)};
}

[[nodiscard]] Diagnostic contextualize(Diagnostic diagnostic,
                                       const SourceNode& node) {
  diagnostic.authored_path = node.location().authored_path;
  diagnostic.json_pointer = std::string(node.json_pointer());
  diagnostic.notes.insert(
      diagnostic.notes.begin(),
      "line " + std::to_string(node.location().line) + ", column " +
          std::to_string(node.location().column));
  return diagnostic;
}

[[nodiscard]] std::string kind_name(const SourceNodeKind kind) {
  switch (kind) {
    case SourceNodeKind::null_value:
      return "null";
    case SourceNodeKind::boolean:
      return "boolean";
    case SourceNodeKind::number:
      return "number";
    case SourceNodeKind::string:
      return "string";
    case SourceNodeKind::array:
      return "array";
    case SourceNodeKind::object:
      return "object";
  }
  return "unknown";
}

[[nodiscard]] Result<void> require_kind(const SourceNode& node,
                                        const SourceNodeKind expected,
                                        const std::string_view description) {
  if (node.kind() == expected) {
    return Result<void>::success();
  }
  return Result<void>::failure(diagnostic_at(
      node, "model_wrong_type",
      std::string(description) + " must be a " + kind_name(expected) +
          "; found " + kind_name(node.kind())));
}

template <typename Key, std::size_t N>
[[nodiscard]] Result<void> exact_keys(
    const SourceNode& node, const std::array<Key, N>& keys) {
  Result<void> object = require_kind(node, SourceNodeKind::object, "value");
  if (!object) {
    return object;
  }
  std::array<std::string_view, N> views{};
  std::transform(keys.begin(), keys.end(), views.begin(),
                 [](const auto& key) { return std::string_view(key); });
  return validate_exact_keys(node, std::span<const std::string_view>(views),
                             node.json_pointer());
}

[[nodiscard]] Result<const SourceNode*> required(const SourceNode& object,
                                                 const std::string_view key) {
  const SourceNode* value = object.find(key);
  if (value != nullptr) {
    return Result<const SourceNode*>::success(value);
  }
  return fail<const SourceNode*>(diagnostic_at(
      object, "model_missing_key", "required key '" + std::string(key) +
                                       "' is missing",
      {"required pointer " + std::string(object.json_pointer()) + "/" +
       escape_json_pointer_token(key)}));
}

[[nodiscard]] Result<void> reject_alias_key(
    const SourceNode& object, const std::string_view alias,
    const std::string_view replacement) {
  const SourceNode* value = object.find(alias);
  if (value == nullptr) {
    return Result<void>::success();
  }
  return Result<void>::failure(diagnostic_at(
      *value, "model_noncanonical_alias",
      "field alias '" + std::string(alias) +
          "' is not accepted in canonical-only mode",
      {"use canonical field '" + std::string(replacement) + "'"}));
}

[[nodiscard]] Result<void> reject_tag_alias(
    const SourceNode& node, const std::string_view authored,
    const std::string_view replacement) {
  return Result<void>::failure(diagnostic_at(
      node, "model_noncanonical_alias",
      "tag alias '" + std::string(authored) +
          "' is not accepted in canonical-only mode",
      {"use canonical tag '" + std::string(replacement) + "'"}));
}

[[nodiscard]] Result<std::string> parse_string(const SourceNode& node,
                                               const std::string_view what) {
  const std::string* text = node.string_value();
  if (text == nullptr) {
    return fail<std::string>(diagnostic_at(
        node, "model_wrong_type",
        std::string(what) + " must be a string; found " +
            kind_name(node.kind())));
  }
  return Result<std::string>::success(*text);
}

[[nodiscard]] Result<std::string> parse_trimmed_string(
    const SourceNode& node, const std::string_view what) {
  Result<std::string> text = parse_string(node, what);
  if (!text) {
    return text;
  }
  Result<TypedLabel> checked = TypedLabel::text(text.value());
  if (!checked) {
    return fail<std::string>(contextualize(std::move(checked.error()), node));
  }
  return text;
}

[[nodiscard]] Result<bool> parse_boolean(const SourceNode& node,
                                         const std::string_view what) {
  const bool* value = node.boolean_value();
  if (value == nullptr) {
    return fail<bool>(diagnostic_at(
        node, "model_wrong_type", std::string(what) +
                                      " must be a boolean; found " +
                                      kind_name(node.kind())));
  }
  return Result<bool>::success(*value);
}

[[nodiscard]] Result<BigNat> parse_natural(
    const SourceNode& node, BoundPolicy policy = BoundPolicy::unbounded()) {
  const std::string* lexeme = node.number_lexeme();
  if (lexeme == nullptr) {
    return fail<BigNat>(diagnostic_at(
        node, "model_expected_integer",
        "expected an exact nonnegative integer; found " +
            kind_name(node.kind())));
  }
  Result<BigNat> value =
      parse_exact_nonnegative_integer(JsonNumber(*lexeme), std::move(policy));
  if (!value) {
    return fail<BigNat>(contextualize(std::move(value.error()), node));
  }
  return value;
}

[[nodiscard]] Result<BigNat> parse_positive_natural(
    const SourceNode& node, BoundPolicy policy = BoundPolicy::unbounded()) {
  Result<BigNat> value = parse_natural(node, std::move(policy));
  if (!value) {
    return value;
  }
  if (value.value().is_zero()) {
    return fail<BigNat>(diagnostic_at(
        node, "model_expected_positive_integer", "integer must be positive"));
  }
  return value;
}

[[nodiscard]] BoundPolicy bounded_by(const std::uint64_t maximum) {
  BoundPolicy policy;
  policy.mathematical_maximum = BigNat(maximum);
  return policy;
}

[[nodiscard]] Result<ExactRational> parse_rational(const SourceNode& node) {
  const std::string* lexeme = node.number_lexeme();
  if (lexeme == nullptr) {
    return fail<ExactRational>(diagnostic_at(
        node, "model_expected_decimal",
        "expected a finite JSON decimal; found " + kind_name(node.kind())));
  }
  Result<ExactRational> value = parse_decimal_rational(NumericLexeme(*lexeme));
  if (!value) {
    return fail<ExactRational>(contextualize(std::move(value.error()), node));
  }
  return value;
}

[[nodiscard]] Result<ExactRational> parse_nonnegative_rational(
    const SourceNode& node, const std::string_view what) {
  Result<ExactRational> value = parse_rational(node);
  if (!value) {
    return value;
  }
  if (!value.value().is_nonnegative()) {
    return fail<ExactRational>(diagnostic_at(
        node, "model_negative_exact_decimal",
        std::string(what) + " must be an exact nonnegative decimal"));
  }
  return value;
}

[[nodiscard]] Result<AuthoredProbability> parse_probability(
    const SourceNode& node, const bool require_positive = false) {
  Result<ExactRational> exact = parse_rational(node);
  if (!exact) {
    return fail<AuthoredProbability>(std::move(exact.error()));
  }
  Result<AuthoredProbability> probability =
      AuthoredProbability::from_exact(std::move(exact.value()));
  if (!probability) {
    return fail<AuthoredProbability>(
        contextualize(std::move(probability.error()), node));
  }
  if (require_positive && !probability.value().exact_value().is_positive()) {
    return fail<AuthoredProbability>(diagnostic_at(
        node, "model_probability_not_positive",
        "probability must lie in the exact interval (0,1]"));
  }
  return probability;
}

[[nodiscard]] JsonValue label_json_value(const SourceNode& node) {
  if (const std::string* number = node.number_lexeme(); number != nullptr) {
    return JsonValue::number(*number);
  }
  if (const std::string* text = node.string_value(); text != nullptr) {
    return JsonValue::string(*text);
  }
  if (const bool* value = node.boolean_value(); value != nullptr) {
    return JsonValue::boolean(*value);
  }
  if (node.kind() == SourceNodeKind::null_value) {
    return JsonValue::null();
  }
  if (node.kind() == SourceNodeKind::array) {
    return JsonValue::array();
  }
  return JsonValue::object();
}

[[nodiscard]] Result<TypedLabel> parse_label(const SourceNode& node) {
  Result<TypedLabel> label = parse_typed_label(label_json_value(node));
  if (!label) {
    return fail<TypedLabel>(contextualize(std::move(label.error()), node));
  }
  return label;
}

template <typename Id>
[[nodiscard]] Result<Id> parse_id(const SourceNode& node) {
  Result<TypedLabel> label = parse_label(node);
  if (!label) {
    return fail<Id>(std::move(label.error()));
  }
  return Result<Id>::success(Id(std::move(label.value())));
}

[[nodiscard]] bool is_unicode_whitespace(const std::uint32_t code_point) {
  return (code_point >= 0x0009U && code_point <= 0x000DU) ||
         code_point == 0x0020U || code_point == 0x0085U ||
         code_point == 0x00A0U || code_point == 0x1680U ||
         (code_point >= 0x2000U && code_point <= 0x200AU) ||
         code_point == 0x2028U || code_point == 0x2029U ||
         code_point == 0x202FU || code_point == 0x205FU ||
         code_point == 0x3000U;
}

struct DecodedCodePoint final {
  std::uint32_t value;
  std::size_t begin;
  std::size_t end;
};

[[nodiscard]] bool decode_utf8(const std::string_view text,
                               std::vector<DecodedCodePoint>& decoded) {
  std::size_t offset = 0U;
  while (offset < text.size()) {
    const std::size_t begin = offset;
    const auto byte = [&text](const std::size_t index) {
      return static_cast<std::uint8_t>(
          static_cast<unsigned char>(text[index]));
    };
    const auto continuation = [](const std::uint8_t value) {
      return (value & 0xc0U) == 0x80U;
    };
    const std::uint8_t first = byte(offset);
    std::uint32_t cp = 0U;
    if (first <= 0x7fU) {
      cp = first;
      ++offset;
    } else if (first >= 0xc2U && first <= 0xdfU &&
               text.size() - offset >= 2U && continuation(byte(offset + 1U))) {
      cp = (static_cast<std::uint32_t>(first & 0x1fU) << 6U) |
           static_cast<std::uint32_t>(byte(offset + 1U) & 0x3fU);
      offset += 2U;
    } else if (first >= 0xe0U && first <= 0xefU &&
               text.size() - offset >= 3U && continuation(byte(offset + 1U)) &&
               continuation(byte(offset + 2U)) &&
               !(first == 0xe0U && byte(offset + 1U) < 0xa0U) &&
               !(first == 0xedU && byte(offset + 1U) > 0x9fU)) {
      cp = (static_cast<std::uint32_t>(first & 0x0fU) << 12U) |
           (static_cast<std::uint32_t>(byte(offset + 1U) & 0x3fU) << 6U) |
           static_cast<std::uint32_t>(byte(offset + 2U) & 0x3fU);
      offset += 3U;
    } else if (first >= 0xf0U && first <= 0xf4U &&
               text.size() - offset >= 4U && continuation(byte(offset + 1U)) &&
               continuation(byte(offset + 2U)) && continuation(byte(offset + 3U)) &&
               !(first == 0xf0U && byte(offset + 1U) < 0x90U) &&
               !(first == 0xf4U && byte(offset + 1U) > 0x8fU)) {
      cp = (static_cast<std::uint32_t>(first & 0x07U) << 18U) |
           (static_cast<std::uint32_t>(byte(offset + 1U) & 0x3fU) << 12U) |
           (static_cast<std::uint32_t>(byte(offset + 2U) & 0x3fU) << 6U) |
           static_cast<std::uint32_t>(byte(offset + 3U) & 0x3fU);
      offset += 4U;
    } else {
      return false;
    }
    decoded.push_back(DecodedCodePoint{cp, begin, offset});
  }
  return true;
}

[[nodiscard]] Result<NormalizedToken> normalize_token_impl(
    const SourceNode& node, const std::string_view what) {
  Result<std::string> text_result = parse_string(node, what);
  if (!text_result) {
    return fail<NormalizedToken>(std::move(text_result.error()));
  }
  const std::string& authored = text_result.value();
  std::vector<DecodedCodePoint> code_points;
  if (!decode_utf8(authored, code_points)) {
    return fail<NormalizedToken>(diagnostic_at(
        node, "model_token_invalid_utf8", std::string(what) +
                                              " must be valid UTF-8"));
  }
  std::size_t first = 0U;
  while (first < code_points.size() &&
         is_unicode_whitespace(code_points[first].value)) {
    ++first;
  }
  std::size_t last = code_points.size();
  while (last > first && is_unicode_whitespace(code_points[last - 1U].value)) {
    --last;
  }

  std::string normalized;
  bool previous_underscore = false;
  for (std::size_t index = first; index < last; ++index) {
    const DecodedCodePoint& cp = code_points[index];
    const bool separator = cp.value == static_cast<std::uint32_t>('-') ||
                           is_unicode_whitespace(cp.value);
    if (separator || cp.value == static_cast<std::uint32_t>('_')) {
      if (!previous_underscore && !normalized.empty()) {
        normalized.push_back('_');
      }
      previous_underscore = true;
      continue;
    }
    if (cp.value >= static_cast<std::uint32_t>('A') &&
        cp.value <= static_cast<std::uint32_t>('Z')) {
      normalized.push_back(static_cast<char>(cp.value -
                                             static_cast<std::uint32_t>('A') +
                                             static_cast<std::uint32_t>('a')));
    } else {
      normalized.append(authored, cp.begin, cp.end - cp.begin);
    }
    previous_underscore = false;
  }
  while (!normalized.empty() && normalized.back() == '_') {
    normalized.pop_back();
  }
  if (normalized.empty()) {
    return fail<NormalizedToken>(diagnostic_at(
        node, "model_token_empty_after_normalization",
        std::string(what) + " is empty after canonical token normalization"));
  }
  return Result<NormalizedToken>::success(
      NormalizedToken{normalized, authored, authored_provenance(node)});
}

[[nodiscard]] Result<NormalizedToken> parse_normalized_token(
    const SourceNode& node, const std::string_view what) {
  return normalize_source_state_token(node, what);
}

[[nodiscard]] Result<void> record_unique_token(
    const NormalizedToken& token,
    std::map<std::string, ModelProvenance>& seen,
    const std::string_view namespace_name) {
  const auto [first, inserted] =
      seen.emplace(token.value, token.provenance);
  if (inserted) {
    return Result<void>::success();
  }
  Diagnostic diagnostic{DiagnosticCategory::input_validation,
                        "model_normalized_token_collision",
                        "two authored " + std::string(namespace_name) +
                            " tokens normalize to '" + token.value + "'",
                        std::nullopt,
                        token.provenance.json_pointer,
                        {}};
  if (token.provenance.location.has_value()) {
    diagnostic.authored_path = token.provenance.location->authored_path;
    diagnostic.notes.push_back(
        "line " + std::to_string(token.provenance.location->line) +
        ", column " + std::to_string(token.provenance.location->column));
  }
  if (first->second.location.has_value()) {
    diagnostic.notes.push_back(
        "first definition: " + first->second.location->authored_path + ":" +
        std::to_string(first->second.location->line) + ":" +
        std::to_string(first->second.location->column) + " at " +
        first->second.json_pointer);
  }
  return Result<void>::failure(std::move(diagnostic));
}

[[nodiscard]] Result<AuthoredMetadata> parse_metadata(
    const SourceNode& owner, const std::string_view pointer) {
  const SourceNode* node = owner.find("metadata");
  if (node == nullptr) {
    return Result<AuthoredMetadata>::success(
        AuthoredMetadata{std::nullopt,
                         defaulted_provenance(std::string(pointer))});
  }
  Result<void> object = require_kind(*node, SourceNodeKind::object, "metadata");
  if (!object) {
    return fail<AuthoredMetadata>(std::move(object.error()));
  }
  return Result<AuthoredMetadata>::success(
      AuthoredMetadata{*node, authored_provenance(*node)});
}

template <typename T, typename Parser>
[[nodiscard]] Result<std::vector<T>> parse_array(const SourceNode& node,
                                                 const std::string_view what,
                                                 Parser parser) {
  Result<void> array = require_kind(node, SourceNodeKind::array, what);
  if (!array) {
    return fail<std::vector<T>>(std::move(array.error()));
  }
  std::vector<T> values;
  values.reserve(node.array_items().size());
  for (const SourceNode& item : node.array_items()) {
    Result<T> value = parser(item);
    if (!value) {
      return fail<std::vector<T>>(std::move(value.error()));
    }
    values.push_back(std::move(value.value()));
  }
  return Result<std::vector<T>>::success(std::move(values));
}

[[nodiscard]] Result<SeedSpec> parse_seed(const SourceNode& node) {
  Result<ExactRational> rational = parse_rational(node);
  if (!rational) {
    return fail<SeedSpec>(std::move(rational.error()));
  }
  if (rational.value().denominator() != 1) {
    return fail<SeedSpec>(diagnostic_at(
        node, "model_seed_not_integer", "seed must have an exact integer value"));
  }
  if (rational.value().numerator() == -1) {
    return Result<SeedSpec>::success(SeedSpec::automatic());
  }
  if (rational.value().numerator() < 0 ||
      rational.value().numerator() >
          BigInt(std::numeric_limits<std::uint64_t>::max())) {
    return fail<SeedSpec>(diagnostic_at(
        node, "model_seed_out_of_range", "seed must be -1 or lie in 0..2^64-1"));
  }
  return Result<SeedSpec>::success(SeedSpec::fixed(
      rational.value().numerator().convert_to<std::uint64_t>()));
}

[[nodiscard]] Result<std::uint64_t> parse_concrete_seed(
    const SourceNode& node) {
  Result<BigNat> value =
      parse_natural(node, bounded_by(std::numeric_limits<std::uint64_t>::max()));
  if (!value) {
    return fail<std::uint64_t>(std::move(value.error()));
  }
  return Result<std::uint64_t>::success(
      value.value().value().convert_to<std::uint64_t>());
}

[[nodiscard]] Result<AuthoredRunConfig> parse_run(const SourceNode* node) {
  if (node == nullptr) {
    return Result<AuthoredRunConfig>::success(AuthoredRunConfig{
        {SeedSpec::automatic(), defaulted_provenance("/run/seed")},
        {BigNat(1000U), defaulted_provenance("/run/slots")},
        {BigNat(0U), defaulted_provenance("/run/warmup_slots")},
        {TerminationPolicy::fixed_slots,
         defaulted_provenance("/run/termination")},
        {std::nullopt, defaulted_provenance("/run/output_dir")},
        {std::nullopt, defaulted_provenance("/run/requested_seed")},
        {std::nullopt, defaulted_provenance("/run/actual_seed")},
        defaulted_provenance("/run")});
  }
  constexpr std::array keys{"seed", "slots", "warmup_slots", "termination",
                            "output_dir", "requested_seed", "actual_seed"};
  Result<void> closed = exact_keys(*node, keys);
  if (!closed) {
    return fail<AuthoredRunConfig>(std::move(closed.error()));
  }
  if (node->find("seed") != nullptr && node->find("requested_seed") != nullptr) {
    return fail<AuthoredRunConfig>(diagnostic_at(
        *node, "model_seed_fields_conflict",
        "run.seed and run.requested_seed are mutually exclusive"));
  }

  AuthoredField<SeedSpec> seed{SeedSpec::automatic(),
                               defaulted_provenance("/run/seed")};
  if (const SourceNode* field = node->find("seed"); field != nullptr) {
    Result<SeedSpec> parsed = parse_seed(*field);
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    seed = {std::move(parsed.value()), authored_provenance(*field)};
  }

  AuthoredField<BigNat> slots{BigNat(1000U),
                              defaulted_provenance("/run/slots")};
  if (const SourceNode* field = node->find("slots"); field != nullptr) {
    Result<BigNat> parsed = parse_positive_natural(*field);
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    slots = {std::move(parsed.value()), authored_provenance(*field)};
  }

  AuthoredField<BigNat> warmup{BigNat(0U),
                               defaulted_provenance("/run/warmup_slots")};
  if (const SourceNode* field = node->find("warmup_slots"); field != nullptr) {
    Result<BigNat> parsed = parse_natural(*field);
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    warmup = {std::move(parsed.value()), authored_provenance(*field)};
  }
  if (warmup.value > slots.value) {
    return fail<AuthoredRunConfig>(diagnostic_at(
        *node, "model_warmup_exceeds_slots",
        "run.warmup_slots must not exceed run.slots"));
  }

  AuthoredField<TerminationPolicy> termination{
      TerminationPolicy::fixed_slots,
      defaulted_provenance("/run/termination")};
  if (const SourceNode* field = node->find("termination"); field != nullptr) {
    Result<std::string> parsed = parse_string(*field, "run.termination");
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    if (parsed.value() == "fixed_slots") {
      termination = {TerminationPolicy::fixed_slots,
                     authored_provenance(*field)};
    } else if (parsed.value() == "fixed_slots_then_drain") {
      termination = {TerminationPolicy::fixed_slots_then_drain,
                     authored_provenance(*field)};
    } else {
      return fail<AuthoredRunConfig>(diagnostic_at(
          *field, "model_unknown_termination",
          "termination must be 'fixed_slots' or 'fixed_slots_then_drain'"));
    }
  }

  AuthoredField<std::optional<std::string>> output{
      std::nullopt, defaulted_provenance("/run/output_dir")};
  if (const SourceNode* field = node->find("output_dir"); field != nullptr) {
    if (field->kind() == SourceNodeKind::null_value) {
      output = {std::nullopt, authored_provenance(*field)};
    } else {
      Result<std::string> parsed =
          parse_trimmed_string(*field, "run.output_dir");
      if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
      output = {std::move(parsed.value()), authored_provenance(*field)};
    }
  }

  AuthoredField<std::optional<SeedSpec>> requested{
      std::nullopt, defaulted_provenance("/run/requested_seed")};
  if (const SourceNode* field = node->find("requested_seed"); field != nullptr) {
    Result<SeedSpec> parsed = parse_seed(*field);
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    requested = {std::move(parsed.value()), authored_provenance(*field)};
  }

  AuthoredField<std::optional<std::uint64_t>> actual{
      std::nullopt, defaulted_provenance("/run/actual_seed")};
  if (const SourceNode* field = node->find("actual_seed"); field != nullptr) {
    if (!requested.value.has_value()) {
      return fail<AuthoredRunConfig>(diagnostic_at(
          *field, "model_actual_seed_without_requested",
          "run.actual_seed requires run.requested_seed"));
    }
    Result<std::uint64_t> parsed = parse_concrete_seed(*field);
    if (!parsed) return fail<AuthoredRunConfig>(std::move(parsed.error()));
    actual = {parsed.value(), authored_provenance(*field)};
    if (requested.value->mode == SeedMode::fixed &&
        requested.value->fixed_value != parsed.value()) {
      return fail<AuthoredRunConfig>(diagnostic_at(
          *field, "model_seed_replay_mismatch",
          "actual_seed must equal a fixed requested_seed"));
    }
  }

  return Result<AuthoredRunConfig>::success(AuthoredRunConfig{
      std::move(seed), std::move(slots), std::move(warmup),
      std::move(termination), std::move(output), std::move(requested),
      std::move(actual), authored_provenance(*node)});
}

[[nodiscard]] Result<AuthoredQueue> parse_queue(const SourceNode& node) {
  if (node.kind() != SourceNodeKind::object) {
    Result<QueueId> id = parse_id<QueueId>(node);
    if (!id) {
      return fail<AuthoredQueue>(std::move(id.error()));
    }
    return Result<AuthoredQueue>::success(AuthoredQueue{
        {std::move(id.value()), authored_provenance(node)},
        {std::nullopt,
         defaulted_provenance(std::string(node.json_pointer()) +
                              "/legacy_voq")},
        authored_provenance(node)});
  }
  Result<void> alias = reject_alias_key(node, "queue_id", "id");
  if (!alias) return fail<AuthoredQueue>(std::move(alias.error()));
  constexpr std::array keys{"id", "legacy_voq"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<AuthoredQueue>(std::move(closed.error()));
  Result<const SourceNode*> id_node = required(node, "id");
  if (!id_node) return fail<AuthoredQueue>(std::move(id_node.error()));
  Result<QueueId> id = parse_id<QueueId>(*id_node.value());
  if (!id) return fail<AuthoredQueue>(std::move(id.error()));

  AuthoredField<std::optional<LegacyVoqCoordinate>> coordinate{
      std::nullopt,
      defaulted_provenance(std::string(node.json_pointer()) +
                           "/legacy_voq")};
  if (const SourceNode* value = node.find("legacy_voq"); value != nullptr) {
    Result<void> array =
        require_kind(*value, SourceNodeKind::array, "queue.legacy_voq");
    if (!array) return fail<AuthoredQueue>(std::move(array.error()));
    if (value->array_items().size() != 2U) {
      return fail<AuthoredQueue>(diagnostic_at(
          *value, "model_legacy_voq_arity",
          "legacy_voq must contain exactly [source,destination]"));
    }
    Result<BigNat> source = parse_natural(value->array_items()[0]);
    if (!source) return fail<AuthoredQueue>(std::move(source.error()));
    Result<BigNat> destination = parse_natural(value->array_items()[1]);
    if (!destination)
      return fail<AuthoredQueue>(std::move(destination.error()));
    coordinate = {
        LegacyVoqCoordinate{
            {std::move(source.value()),
             authored_provenance(value->array_items()[0])},
            {std::move(destination.value()),
             authored_provenance(value->array_items()[1])},
            authored_provenance(*value)},
        authored_provenance(*value)};
  }
  return Result<AuthoredQueue>::success(
      AuthoredQueue{{std::move(id.value()), authored_provenance(*id_node.value())},
                    std::move(coordinate), authored_provenance(node)});
}

[[nodiscard]] Result<GeneralizedSwitchConfig> parse_generalized_switch(
    const SourceNode& node, const PhysicalSchemaDialect dialect) {
  constexpr std::array keys{"kind", "queue_capacity", "queues",
                            "legacy_n_ports"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<GeneralizedSwitchConfig>(std::move(closed.error()));

  AuthoredField<std::optional<BigNat>> capacity{
      std::nullopt, defaulted_provenance("/switch/queue_capacity")};
  if (const SourceNode* field = node.find("queue_capacity"); field != nullptr) {
    if (field->kind() == SourceNodeKind::null_value) {
      if (dialect == PhysicalSchemaDialect::v4) {
        return fail<GeneralizedSwitchConfig>(diagnostic_at(
            *field, "model_schema4_queue_capacity_not_canonical",
            "schema-4 lossless queue capacity must be spelled 'NoDrop'"));
      }
      capacity = {std::nullopt, authored_provenance(*field)};
    } else if (dialect == PhysicalSchemaDialect::v4 &&
               field->kind() == SourceNodeKind::string) {
      Result<std::string> parsed =
          parse_string(*field, "switch.queue_capacity");
      if (!parsed) {
        return fail<GeneralizedSwitchConfig>(std::move(parsed.error()));
      }
      if (parsed.value() != "NoDrop") {
        return fail<GeneralizedSwitchConfig>(diagnostic_at(
            *field, "model_queue_capacity_invalid",
            "schema-4 queue_capacity must be 'NoDrop' or a positive integer"));
      }
      capacity = {std::nullopt, authored_provenance(*field)};
    } else {
      Result<BigNat> parsed = parse_positive_natural(
          *field, bounded_by(static_cast<std::uint64_t>(
                      std::numeric_limits<std::int64_t>::max())));
      if (!parsed)
        return fail<GeneralizedSwitchConfig>(std::move(parsed.error()));
      capacity = {std::move(parsed.value()), authored_provenance(*field)};
    }
  }

  Result<const SourceNode*> queues_node = required(node, "queues");
  if (!queues_node)
    return fail<GeneralizedSwitchConfig>(std::move(queues_node.error()));
  Result<std::vector<AuthoredQueue>> queues = parse_array<AuthoredQueue>(
      *queues_node.value(), "switch.queues", parse_queue);
  if (!queues)
    return fail<GeneralizedSwitchConfig>(std::move(queues.error()));
  if (queues.value().empty()) {
    return fail<GeneralizedSwitchConfig>(diagnostic_at(
        *queues_node.value(), "model_empty_queue_catalog",
        "a generalized switch requires a nonempty ordered queues array"));
  }

  AuthoredField<std::optional<BigNat>> legacy_n_ports{
      std::nullopt, defaulted_provenance("/switch/legacy_n_ports")};
  if (const SourceNode* field = node.find("legacy_n_ports"); field != nullptr) {
    if (field->kind() == SourceNodeKind::null_value) {
      legacy_n_ports = {std::nullopt, authored_provenance(*field)};
    } else {
      Result<BigNat> parsed = parse_positive_natural(*field);
      if (!parsed)
        return fail<GeneralizedSwitchConfig>(std::move(parsed.error()));
      legacy_n_ports = {std::move(parsed.value()), authored_provenance(*field)};
    }
  }
  return Result<GeneralizedSwitchConfig>::success(GeneralizedSwitchConfig{
      std::move(capacity),
      {std::move(queues.value()), authored_provenance(*queues_node.value())},
      std::move(legacy_n_ports), authored_provenance(node)});
}

[[nodiscard]] Result<LegacyCrossbarSwitchConfig> parse_legacy_switch(
    const SourceNode& node) {
  constexpr std::array keys{"kind", "n_ports", "voq_capacity",
                            "allow_self_traffic"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<LegacyCrossbarSwitchConfig>(std::move(closed.error()));
  Result<const SourceNode*> n_ports_node = required(node, "n_ports");
  if (!n_ports_node)
    return fail<LegacyCrossbarSwitchConfig>(std::move(n_ports_node.error()));
  Result<BigNat> n_ports = parse_positive_natural(*n_ports_node.value());
  if (!n_ports)
    return fail<LegacyCrossbarSwitchConfig>(std::move(n_ports.error()));
  Result<const SourceNode*> capacity_node = required(node, "voq_capacity");
  if (!capacity_node)
    return fail<LegacyCrossbarSwitchConfig>(std::move(capacity_node.error()));
  Result<BigNat> capacity = parse_positive_natural(
      *capacity_node.value(),
      bounded_by(static_cast<std::uint64_t>(
          std::numeric_limits<std::int64_t>::max())));
  if (!capacity)
    return fail<LegacyCrossbarSwitchConfig>(std::move(capacity.error()));

  AuthoredField<bool> allow{true,
                            defaulted_provenance("/switch/allow_self_traffic")};
  if (const SourceNode* field = node.find("allow_self_traffic"); field != nullptr) {
    Result<bool> parsed = parse_boolean(*field, "switch.allow_self_traffic");
    if (!parsed)
      return fail<LegacyCrossbarSwitchConfig>(std::move(parsed.error()));
    allow = {parsed.value(), authored_provenance(*field)};
  }
  return Result<LegacyCrossbarSwitchConfig>::success(
      LegacyCrossbarSwitchConfig{
          {std::move(n_ports.value()), authored_provenance(*n_ports_node.value())},
          {std::move(capacity.value()),
           authored_provenance(*capacity_node.value())},
          std::move(allow), authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredSwitchConfig> parse_switch(
    const SourceNode& node, const PhysicalSchemaDialect dialect) {
  Result<void> object = require_kind(node, SourceNodeKind::object, "switch");
  if (!object) return fail<AuthoredSwitchConfig>(std::move(object.error()));
  // Validate the union of both closed switch alternatives before reading the
  // discriminator so a misspelled `kind` is diagnosed at the authored typo,
  // not misreported as an omitted default/required field.
  constexpr std::array union_keys{"kind", "queue_capacity", "queues",
                                  "legacy_n_ports", "n_ports",
                                  "voq_capacity", "allow_self_traffic",
                                  "capacity"};
  Result<void> union_closed = exact_keys(node, union_keys);
  if (!union_closed) {
    return fail<AuthoredSwitchConfig>(std::move(union_closed.error()));
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  if (!kind_node) return fail<AuthoredSwitchConfig>(std::move(kind_node.error()));
  Result<std::string> kind = parse_string(*kind_node.value(), "switch.kind");
  if (!kind) return fail<AuthoredSwitchConfig>(std::move(kind.error()));
  if (kind.value() == "generic") {
    Result<void> alias = reject_tag_alias(*kind_node.value(), kind.value(),
                                         "generalized");
    return fail<AuthoredSwitchConfig>(std::move(alias.error()));
  }
  if (kind.value() == "crossbar" || kind.value() == "legacy") {
    Result<void> alias = reject_tag_alias(*kind_node.value(), kind.value(),
                                         "legacy_crossbar");
    return fail<AuthoredSwitchConfig>(std::move(alias.error()));
  }
  Result<void> capacity_alias = reject_alias_key(
      node, "capacity",
      kind.value() == "legacy_crossbar" ? "voq_capacity" : "queue_capacity");
  if (!capacity_alias)
    return fail<AuthoredSwitchConfig>(std::move(capacity_alias.error()));
  if (kind.value() == "generalized") {
    Result<GeneralizedSwitchConfig> parsed =
        parse_generalized_switch(node, dialect);
    if (!parsed) return fail<AuthoredSwitchConfig>(std::move(parsed.error()));
    return Result<AuthoredSwitchConfig>::success(std::move(parsed.value()));
  }
  if (kind.value() == "legacy_crossbar") {
    Result<LegacyCrossbarSwitchConfig> parsed = parse_legacy_switch(node);
    if (!parsed) return fail<AuthoredSwitchConfig>(std::move(parsed.error()));
    return Result<AuthoredSwitchConfig>::success(std::move(parsed.value()));
  }
  return fail<AuthoredSwitchConfig>(diagnostic_at(
      *kind_node.value(), "model_unknown_switch_kind",
      "switch.kind must be 'generalized' or 'legacy_crossbar'"));
}

[[nodiscard]] Result<AuthoredPriority> parse_priority(const SourceNode& params) {
  const std::string pointer = std::string(params.json_pointer()) + "/priority";
  const SourceNode* node = params.find("priority");
  if (node == nullptr) {
    return Result<AuthoredPriority>::success(
        AuthoredPriority{std::nullopt, defaulted_provenance(pointer)});
  }
  if (node->kind() == SourceNodeKind::null_value) {
    return Result<AuthoredPriority>::success(
        AuthoredPriority{std::nullopt, authored_provenance(*node)});
  }
  Result<std::vector<AuthoredField<QueueId>>> values =
      parse_array<AuthoredField<QueueId>>(
          *node, "scheduler priority", [](const SourceNode& item) {
            Result<QueueId> value = parse_id<QueueId>(item);
            if (!value)
              return fail<AuthoredField<QueueId>>(std::move(value.error()));
            return Result<AuthoredField<QueueId>>::success(
                {std::move(value.value()), authored_provenance(item)});
          });
  if (!values) return fail<AuthoredPriority>(std::move(values.error()));
  return Result<AuthoredPriority>::success(
      AuthoredPriority{std::move(values.value()), authored_provenance(*node)});
}

template <typename Id>
[[nodiscard]] Result<std::vector<AuthoredField<Id>>> parse_id_array(
    const SourceNode& node, const std::string_view what,
    const bool require_nonempty) {
  Result<std::vector<AuthoredField<Id>>> ids =
      parse_array<AuthoredField<Id>>(
          node, what, [](const SourceNode& item) {
            Result<Id> value = parse_id<Id>(item);
            if (!value)
              return fail<AuthoredField<Id>>(std::move(value.error()));
            return Result<AuthoredField<Id>>::success(
                {std::move(value.value()), authored_provenance(item)});
          });
  if (!ids) return ids;
  if (require_nonempty && ids.value().empty()) {
    return fail<std::vector<AuthoredField<Id>>>(diagnostic_at(
        node, "model_empty_constraint_array",
        std::string(what) + " must be nonempty"));
  }
  return ids;
}

[[nodiscard]] Result<CrossbarConstraint> parse_crossbar_constraint(
    const SourceNode& node) {
  constexpr std::array keys{"inputs", "outputs", "edges"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<CrossbarConstraint>(std::move(closed.error()));
  Result<const SourceNode*> inputs_node = required(node, "inputs");
  if (!inputs_node) return fail<CrossbarConstraint>(std::move(inputs_node.error()));
  Result<std::vector<AuthoredField<PortId>>> inputs =
      parse_id_array<PortId>(*inputs_node.value(), "crossbar inputs", true);
  if (!inputs) return fail<CrossbarConstraint>(std::move(inputs.error()));
  Result<const SourceNode*> outputs_node = required(node, "outputs");
  if (!outputs_node)
    return fail<CrossbarConstraint>(std::move(outputs_node.error()));
  Result<std::vector<AuthoredField<PortId>>> outputs =
      parse_id_array<PortId>(*outputs_node.value(), "crossbar outputs", true);
  if (!outputs) return fail<CrossbarConstraint>(std::move(outputs.error()));
  Result<const SourceNode*> edges_node = required(node, "edges");
  if (!edges_node) return fail<CrossbarConstraint>(std::move(edges_node.error()));
  Result<std::vector<CrossbarEdge>> edges = parse_array<CrossbarEdge>(
      *edges_node.value(), "crossbar edges", [](const SourceNode& edge) {
        constexpr std::array edge_keys{"queue_id", "input", "output"};
        Result<void> edge_closed = exact_keys(edge, edge_keys);
        if (!edge_closed) return fail<CrossbarEdge>(std::move(edge_closed.error()));
        Result<const SourceNode*> queue_node = required(edge, "queue_id");
        if (!queue_node) return fail<CrossbarEdge>(std::move(queue_node.error()));
        Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
        if (!queue) return fail<CrossbarEdge>(std::move(queue.error()));
        Result<const SourceNode*> input_node = required(edge, "input");
        if (!input_node) return fail<CrossbarEdge>(std::move(input_node.error()));
        Result<PortId> input = parse_id<PortId>(*input_node.value());
        if (!input) return fail<CrossbarEdge>(std::move(input.error()));
        Result<const SourceNode*> output_node = required(edge, "output");
        if (!output_node) return fail<CrossbarEdge>(std::move(output_node.error()));
        Result<PortId> output = parse_id<PortId>(*output_node.value());
        if (!output) return fail<CrossbarEdge>(std::move(output.error()));
        return Result<CrossbarEdge>::success(CrossbarEdge{
            {std::move(queue.value()), authored_provenance(*queue_node.value())},
            {std::move(input.value()), authored_provenance(*input_node.value())},
            {std::move(output.value()), authored_provenance(*output_node.value())},
            authored_provenance(edge)});
      });
  if (!edges) return fail<CrossbarConstraint>(std::move(edges.error()));
  if (edges.value().empty()) {
    return fail<CrossbarConstraint>(diagnostic_at(
        *edges_node.value(), "model_empty_crossbar_edges",
        "crossbar constraint edges must be nonempty"));
  }
  return Result<CrossbarConstraint>::success(CrossbarConstraint{
      {std::move(inputs.value()), authored_provenance(*inputs_node.value())},
      {std::move(outputs.value()), authored_provenance(*outputs_node.value())},
      {std::move(edges.value()), authored_provenance(*edges_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<IntervalConstraint> parse_interval_constraint(
    const SourceNode& node) {
  constexpr std::array keys{"intervals"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<IntervalConstraint>(std::move(closed.error()));
  Result<const SourceNode*> intervals_node = required(node, "intervals");
  if (!intervals_node)
    return fail<IntervalConstraint>(std::move(intervals_node.error()));
  Result<std::vector<IntervalRecord>> intervals = parse_array<IntervalRecord>(
      *intervals_node.value(), "interval constraint records",
      [](const SourceNode& interval) {
        constexpr std::array item_keys{"queue_id", "left", "right"};
        Result<void> item_closed = exact_keys(interval, item_keys);
        if (!item_closed)
          return fail<IntervalRecord>(std::move(item_closed.error()));
        Result<const SourceNode*> queue_node = required(interval, "queue_id");
        if (!queue_node)
          return fail<IntervalRecord>(std::move(queue_node.error()));
        Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
        if (!queue) return fail<IntervalRecord>(std::move(queue.error()));
        Result<const SourceNode*> left_node = required(interval, "left");
        if (!left_node)
          return fail<IntervalRecord>(std::move(left_node.error()));
        Result<ExactRational> left = parse_rational(*left_node.value());
        if (!left) return fail<IntervalRecord>(std::move(left.error()));
        Result<const SourceNode*> right_node = required(interval, "right");
        if (!right_node)
          return fail<IntervalRecord>(std::move(right_node.error()));
        Result<ExactRational> right = parse_rational(*right_node.value());
        if (!right) return fail<IntervalRecord>(std::move(right.error()));
        if (!(left.value() < right.value())) {
          return fail<IntervalRecord>(diagnostic_at(
              interval, "model_invalid_interval",
              "interval endpoints must satisfy exact left < right"));
        }
        return Result<IntervalRecord>::success(IntervalRecord{
            {std::move(queue.value()), authored_provenance(*queue_node.value())},
            {std::move(left.value()), authored_provenance(*left_node.value())},
            {std::move(right.value()), authored_provenance(*right_node.value())},
            authored_provenance(interval)});
      });
  if (!intervals)
    return fail<IntervalConstraint>(std::move(intervals.error()));
  if (intervals.value().empty()) {
    return fail<IntervalConstraint>(diagnostic_at(
        *intervals_node.value(), "model_empty_intervals",
        "interval constraint records must be nonempty"));
  }
  return Result<IntervalConstraint>::success(IntervalConstraint{
      {std::move(intervals.value()),
       authored_provenance(*intervals_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<NodeExclusiveConstraint> parse_node_constraint(
    const SourceNode& node) {
  constexpr std::array keys{"vertices", "links"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<NodeExclusiveConstraint>(std::move(closed.error()));
  Result<const SourceNode*> vertices_node = required(node, "vertices");
  if (!vertices_node)
    return fail<NodeExclusiveConstraint>(std::move(vertices_node.error()));
  Result<std::vector<AuthoredField<VertexId>>> vertices = parse_id_array<VertexId>(
      *vertices_node.value(), "node-exclusive vertices", true);
  if (!vertices)
    return fail<NodeExclusiveConstraint>(std::move(vertices.error()));
  Result<const SourceNode*> links_node = required(node, "links");
  if (!links_node)
    return fail<NodeExclusiveConstraint>(std::move(links_node.error()));
  Result<std::vector<NodeExclusiveLink>> links =
      parse_array<NodeExclusiveLink>(
          *links_node.value(), "node-exclusive links",
          [](const SourceNode& link) {
            constexpr std::array item_keys{"queue_id", "u", "v"};
            Result<void> item_closed = exact_keys(link, item_keys);
            if (!item_closed)
              return fail<NodeExclusiveLink>(std::move(item_closed.error()));
            Result<const SourceNode*> queue_node = required(link, "queue_id");
            if (!queue_node)
              return fail<NodeExclusiveLink>(std::move(queue_node.error()));
            Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
            if (!queue)
              return fail<NodeExclusiveLink>(std::move(queue.error()));
            Result<const SourceNode*> u_node = required(link, "u");
            if (!u_node)
              return fail<NodeExclusiveLink>(std::move(u_node.error()));
            Result<VertexId> u = parse_id<VertexId>(*u_node.value());
            if (!u) return fail<NodeExclusiveLink>(std::move(u.error()));
            Result<const SourceNode*> v_node = required(link, "v");
            if (!v_node)
              return fail<NodeExclusiveLink>(std::move(v_node.error()));
            Result<VertexId> v = parse_id<VertexId>(*v_node.value());
            if (!v) return fail<NodeExclusiveLink>(std::move(v.error()));
            return Result<NodeExclusiveLink>::success(NodeExclusiveLink{
                {std::move(queue.value()),
                 authored_provenance(*queue_node.value())},
                {std::move(u.value()), authored_provenance(*u_node.value())},
                {std::move(v.value()), authored_provenance(*v_node.value())},
                authored_provenance(link)});
          });
  if (!links) return fail<NodeExclusiveConstraint>(std::move(links.error()));
  if (links.value().empty()) {
    return fail<NodeExclusiveConstraint>(diagnostic_at(
        *links_node.value(), "model_empty_node_links",
        "node-exclusive links must be nonempty"));
  }
  return Result<NodeExclusiveConstraint>::success(NodeExclusiveConstraint{
      {std::move(vertices.value()), authored_provenance(*vertices_node.value())},
      {std::move(links.value()), authored_provenance(*links_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<ConflictConstraint> parse_conflict_constraint(
    const SourceNode& node) {
  constexpr std::array keys{"conflicts"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<ConflictConstraint>(std::move(closed.error()));
  Result<const SourceNode*> conflicts_node = required(node, "conflicts");
  if (!conflicts_node)
    return fail<ConflictConstraint>(std::move(conflicts_node.error()));
  Result<std::vector<ConflictPair>> conflicts = parse_array<ConflictPair>(
      *conflicts_node.value(), "conflict pairs", [](const SourceNode& pair) {
        Result<void> array =
            require_kind(pair, SourceNodeKind::array, "conflict pair");
        if (!array) return fail<ConflictPair>(std::move(array.error()));
        if (pair.array_items().size() != 2U) {
          return fail<ConflictPair>(diagnostic_at(
              pair, "model_conflict_pair_arity",
              "every conflict row must contain exactly two queue labels"));
        }
        Result<QueueId> first = parse_id<QueueId>(pair.array_items()[0]);
        if (!first) return fail<ConflictPair>(std::move(first.error()));
        Result<QueueId> second = parse_id<QueueId>(pair.array_items()[1]);
        if (!second) return fail<ConflictPair>(std::move(second.error()));
        return Result<ConflictPair>::success(ConflictPair{
            {std::move(first.value()),
             authored_provenance(pair.array_items()[0])},
            {std::move(second.value()),
             authored_provenance(pair.array_items()[1])},
            authored_provenance(pair)});
      });
  if (!conflicts) return fail<ConflictConstraint>(std::move(conflicts.error()));
  return Result<ConflictConstraint>::success(ConflictConstraint{
      {std::move(conflicts.value()),
       authored_provenance(*conflicts_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<PackingConstraint> parse_packing_constraint(
    const SourceNode& node) {
  constexpr std::array keys{"resources", "capacity", "demands"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<PackingConstraint>(std::move(closed.error()));
  Result<const SourceNode*> resources_node = required(node, "resources");
  if (!resources_node)
    return fail<PackingConstraint>(std::move(resources_node.error()));
  Result<std::vector<AuthoredField<ResourceId>>> resources = parse_id_array<ResourceId>(
      *resources_node.value(), "packing resources", false);
  if (!resources) return fail<PackingConstraint>(std::move(resources.error()));
  Result<const SourceNode*> capacity_node = required(node, "capacity");
  if (!capacity_node)
    return fail<PackingConstraint>(std::move(capacity_node.error()));
  Result<std::vector<AuthoredField<BigNat>>> capacity =
      parse_array<AuthoredField<BigNat>>(
          *capacity_node.value(), "packing capacity",
          [](const SourceNode& item) {
            Result<BigNat> value = parse_natural(item);
            if (!value)
              return fail<AuthoredField<BigNat>>(std::move(value.error()));
            return Result<AuthoredField<BigNat>>::success(
                {std::move(value.value()), authored_provenance(item)});
          });
  if (!capacity) return fail<PackingConstraint>(std::move(capacity.error()));
  Result<const SourceNode*> demands_node = required(node, "demands");
  if (!demands_node)
    return fail<PackingConstraint>(std::move(demands_node.error()));
  Result<std::vector<PackingDemand>> demands = parse_array<PackingDemand>(
      *demands_node.value(), "packing demands", [](const SourceNode& demand) {
        constexpr std::array item_keys{"queue_id", "demand"};
        Result<void> item_closed = exact_keys(demand, item_keys);
        if (!item_closed)
          return fail<PackingDemand>(std::move(item_closed.error()));
        Result<const SourceNode*> queue_node = required(demand, "queue_id");
        if (!queue_node)
          return fail<PackingDemand>(std::move(queue_node.error()));
        Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
        if (!queue) return fail<PackingDemand>(std::move(queue.error()));
        Result<const SourceNode*> vector_node = required(demand, "demand");
        if (!vector_node)
          return fail<PackingDemand>(std::move(vector_node.error()));
        Result<std::vector<AuthoredField<BigNat>>> values =
            parse_array<AuthoredField<BigNat>>(
                *vector_node.value(), "packing demand vector",
                [](const SourceNode& item) {
                  Result<BigNat> value = parse_natural(item);
                  if (!value)
                    return fail<AuthoredField<BigNat>>(
                        std::move(value.error()));
                  return Result<AuthoredField<BigNat>>::success(
                      {std::move(value.value()), authored_provenance(item)});
                });
        if (!values) return fail<PackingDemand>(std::move(values.error()));
        return Result<PackingDemand>::success(PackingDemand{
            {std::move(queue.value()), authored_provenance(*queue_node.value())},
            {std::move(values.value()),
             authored_provenance(*vector_node.value())},
            authored_provenance(demand)});
      });
  if (!demands) return fail<PackingConstraint>(std::move(demands.error()));
  return Result<PackingConstraint>::success(PackingConstraint{
      {std::move(resources.value()),
       authored_provenance(*resources_node.value())},
      {std::move(capacity.value()), authored_provenance(*capacity_node.value())},
      {std::move(demands.value()), authored_provenance(*demands_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredField<std::optional<BigNat>>> parse_search_limit(
    const SourceNode& params) {
  const SourceNode* node = params.find("max_search_states");
  if (node == nullptr) {
    return Result<AuthoredField<std::optional<BigNat>>>::success(
        {std::nullopt, defaulted_provenance(
                           std::string(params.json_pointer()) +
                           "/max_search_states")});
  }
  if (node->kind() == SourceNodeKind::null_value) {
    return Result<AuthoredField<std::optional<BigNat>>>::success(
        {std::nullopt, authored_provenance(*node)});
  }
  Result<BigNat> value = parse_positive_natural(*node);
  if (!value)
    return fail<AuthoredField<std::optional<BigNat>>>(std::move(value.error()));
  return Result<AuthoredField<std::optional<BigNat>>>::success(
      {std::move(value.value()), authored_provenance(*node)});
}

[[nodiscard]] Result<void> validate_compatibility_scheduler_params(
    const CompatibilitySchedulerKind kind, const SourceNode& params) {
  if (kind == CompatibilitySchedulerKind::random_maximal) {
    constexpr std::array<std::string_view, 0> keys{};
    return exact_keys(params, keys);
  }
  if (kind == CompatibilitySchedulerKind::round_robin) {
    constexpr std::array keys{"input_offset", "output_offset"};
    Result<void> closed = exact_keys(params, keys);
    if (!closed) return closed;
    for (const std::string_view key : keys) {
      if (const SourceNode* node = params.find(key); node != nullptr) {
        Result<BigNat> value = parse_natural(*node);
        if (!value) return Result<void>::failure(std::move(value.error()));
      }
    }
    return Result<void>::success();
  }
  Result<void> rounds = reject_alias_key(params, "rounds", "k");
  if (!rounds) return rounds;
  Result<void> num_rounds = reject_alias_key(params, "num_rounds", "k");
  if (!num_rounds) return num_rounds;
  if (kind == CompatibilitySchedulerKind::islip_rga) {
    constexpr std::array keys{"k"};
    Result<void> closed = exact_keys(params, keys);
    if (!closed) return closed;
    if (const SourceNode* node = params.find("k"); node != nullptr) {
      Result<BigNat> value = parse_positive_natural(*node);
      if (!value) return Result<void>::failure(std::move(value.error()));
    }
    return Result<void>::success();
  }
  constexpr std::array keys{"k", "initial_grant_pointers",
                            "initial_accept_pointers"};
  Result<void> closed = exact_keys(params, keys);
  if (!closed) return closed;
  if (const SourceNode* node = params.find("k"); node != nullptr) {
    Result<BigNat> value = parse_positive_natural(*node);
    if (!value) return Result<void>::failure(std::move(value.error()));
  }
  for (const std::string_view key : {std::string_view("initial_grant_pointers"),
                                     std::string_view("initial_accept_pointers")}) {
    if (const SourceNode* node = params.find(key); node != nullptr) {
      Result<std::vector<BigNat>> values = parse_array<BigNat>(
          *node, key,
          [](const SourceNode& item) { return parse_natural(item); });
      if (!values) return Result<void>::failure(std::move(values.error()));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<CompatibilitySchedulerParams>
parse_compatibility_scheduler_params(const CompatibilitySchedulerKind kind,
                                     const SourceNode& params) {
  Result<void> valid = validate_compatibility_scheduler_params(kind, params);
  if (!valid)
    return fail<CompatibilitySchedulerParams>(std::move(valid.error()));
  if (kind == CompatibilitySchedulerKind::random_maximal) {
    return Result<CompatibilitySchedulerParams>::success(
        RandomMaximalCompatibilityParams{authored_provenance(params)});
  }
  if (kind == CompatibilitySchedulerKind::round_robin) {
    AuthoredField<BigNat> input{
        BigNat(0U), defaulted_provenance(
                        std::string(params.json_pointer()) + "/input_offset")};
    if (const SourceNode* node = params.find("input_offset"); node != nullptr) {
      Result<BigNat> value = parse_natural(*node);
      if (!value)
        return fail<CompatibilitySchedulerParams>(std::move(value.error()));
      input = {std::move(value.value()), authored_provenance(*node)};
    }
    AuthoredField<BigNat> output{
        BigNat(0U), defaulted_provenance(
                        std::string(params.json_pointer()) + "/output_offset")};
    if (const SourceNode* node = params.find("output_offset"); node != nullptr) {
      Result<BigNat> value = parse_natural(*node);
      if (!value)
        return fail<CompatibilitySchedulerParams>(std::move(value.error()));
      output = {std::move(value.value()), authored_provenance(*node)};
    }
    return Result<CompatibilitySchedulerParams>::success(
        RoundRobinCompatibilityParams{std::move(input), std::move(output),
                                      authored_provenance(params)});
  }
  AuthoredField<BigNat> k{
      BigNat(1U), defaulted_provenance(std::string(params.json_pointer()) +
                                      "/k")};
  if (const SourceNode* node = params.find("k"); node != nullptr) {
    Result<BigNat> value = parse_positive_natural(*node);
    if (!value)
      return fail<CompatibilitySchedulerParams>(std::move(value.error()));
    k = {std::move(value.value()), authored_provenance(*node)};
  }
  if (kind == CompatibilitySchedulerKind::islip_rga) {
    return Result<CompatibilitySchedulerParams>::success(
        IslipRgaCompatibilityParams{std::move(k),
                                    authored_provenance(params)});
  }
  const auto pointers = [&params](const std::string_view name)
      -> Result<AuthoredField<
          std::optional<std::vector<AuthoredField<BigNat>>>>> {
    const SourceNode* node = params.find(name);
    if (node == nullptr) {
      return Result<AuthoredField<
          std::optional<std::vector<AuthoredField<BigNat>>>>>::success(
          {std::nullopt,
           defaulted_provenance(std::string(params.json_pointer()) + "/" +
                                std::string(name))});
    }
    Result<std::vector<AuthoredField<BigNat>>> values =
        parse_array<AuthoredField<BigNat>>(
            *node, name, [](const SourceNode& item) {
              Result<BigNat> value = parse_natural(item);
              if (!value)
                return fail<AuthoredField<BigNat>>(std::move(value.error()));
              return Result<AuthoredField<BigNat>>::success(
                  {std::move(value.value()), authored_provenance(item)});
            });
    if (!values) {
      return fail<AuthoredField<
          std::optional<std::vector<AuthoredField<BigNat>>>>>(
          std::move(values.error()));
    }
    return Result<AuthoredField<
        std::optional<std::vector<AuthoredField<BigNat>>>>>::success(
        {std::move(values.value()), authored_provenance(*node)});
  };
  Result<AuthoredField<std::optional<std::vector<AuthoredField<BigNat>>>>>
      grant = pointers("initial_grant_pointers");
  if (!grant)
    return fail<CompatibilitySchedulerParams>(std::move(grant.error()));
  Result<AuthoredField<std::optional<std::vector<AuthoredField<BigNat>>>>>
      accept = pointers("initial_accept_pointers");
  if (!accept)
    return fail<CompatibilitySchedulerParams>(std::move(accept.error()));
  return Result<CompatibilitySchedulerParams>::success(
      IslipCanonicalCompatibilityParams{
          std::move(k), std::move(grant.value()), std::move(accept.value()),
          authored_provenance(params)});
}

[[nodiscard]] Result<AuthoredSchedulerConfig> parse_scheduler(
    const SourceNode* node, const bool legacy_switch,
    const SourceNode& switch_node) {
  if (node == nullptr) {
    if (!legacy_switch) {
      return fail<AuthoredSchedulerConfig>(diagnostic_at(
          switch_node, "model_generalized_scheduler_required",
          "a generalized switch requires an explicit scheduler section"));
    }
    SourceLocation location = switch_node.location();
    SourceNode empty_params = SourceNode::make_object(
        {}, location, "/scheduler/params");
    UnsupportedCompatibilityScheduler unsupported{
        CompatibilitySchedulerKind::random_maximal,
        defaulted_provenance("/scheduler/name"),
        RandomMaximalCompatibilityParams{
            defaulted_provenance("/scheduler/params")},
        std::move(empty_params), defaulted_provenance("/scheduler")};
    return Result<AuthoredSchedulerConfig>::success(AuthoredSchedulerConfig{
        std::move(unsupported), defaulted_provenance("/scheduler")});
  }
  Result<void> parameters_alias =
      reject_alias_key(*node, "parameters", "params");
  if (!parameters_alias)
    return fail<AuthoredSchedulerConfig>(std::move(parameters_alias.error()));
  constexpr std::array wrapper_keys{"name", "params"};
  Result<void> closed = exact_keys(*node, wrapper_keys);
  if (!closed) return fail<AuthoredSchedulerConfig>(std::move(closed.error()));
  const SourceNode* name_node = node->find("name");
  if (name_node == nullptr) {
    if (!legacy_switch) {
      Result<const SourceNode*> required_name = required(*node, "name");
      return fail<AuthoredSchedulerConfig>(std::move(required_name.error()));
    }
    Result<const SourceNode*> params_node = required(*node, "params");
    if (!params_node) {
      return fail<AuthoredSchedulerConfig>(std::move(params_node.error()));
    }
    Result<void> params_object =
        require_kind(*params_node.value(), SourceNodeKind::object,
                     "scheduler.params");
    if (!params_object) {
      return fail<AuthoredSchedulerConfig>(std::move(params_object.error()));
    }
    Result<CompatibilitySchedulerParams> parsed_params =
        parse_compatibility_scheduler_params(
            CompatibilitySchedulerKind::random_maximal,
            *params_node.value());
    if (!parsed_params) {
      return fail<AuthoredSchedulerConfig>(std::move(parsed_params.error()));
    }
    UnsupportedCompatibilityScheduler value{
        CompatibilitySchedulerKind::random_maximal,
        defaulted_provenance(std::string(node->json_pointer()) + "/name"),
        std::move(parsed_params.value()), *params_node.value(),
        authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }
  Result<std::string> name = parse_string(*name_node, "scheduler.name");
  if (!name) return fail<AuthoredSchedulerConfig>(std::move(name.error()));
  if (name.value() == "roundrobin") {
    Result<void> alias = reject_tag_alias(*name_node, name.value(),
                                         "round_robin");
    return fail<AuthoredSchedulerConfig>(std::move(alias.error()));
  }
  if (name.value() == "canonical_islip") {
    Result<void> alias = reject_tag_alias(*name_node, name.value(),
                                         "islip_canonical");
    return fail<AuthoredSchedulerConfig>(std::move(alias.error()));
  }
  if (name.value() == "islip" || name.value() == "max_weight" ||
      name.value() == "maxweight") {
    const std::string replacement =
        name.value() == "islip" ? "islip_rga or islip_canonical"
                                 : "crossbar_max_weight";
    Result<void> alias =
        reject_tag_alias(*name_node, name.value(), replacement);
    return fail<AuthoredSchedulerConfig>(std::move(alias.error()));
  }
  Result<const SourceNode*> params_node = required(*node, "params");
  if (!params_node)
    return fail<AuthoredSchedulerConfig>(std::move(params_node.error()));
  Result<void> params_object =
      require_kind(*params_node.value(), SourceNodeKind::object,
                   "scheduler.params");
  if (!params_object)
    return fail<AuthoredSchedulerConfig>(std::move(params_object.error()));

  if (name.value() == "crossbar_max_weight") {
    if (legacy_switch) {
      constexpr std::array keys{"priority"};
      Result<void> params_closed = exact_keys(*params_node.value(), keys);
      if (!params_closed)
        return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
      Result<AuthoredPriority> priority = parse_priority(*params_node.value());
      if (!priority)
        return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
      CrossbarMaxWeightScheduler value{
          {std::nullopt, defaulted_provenance(
                             std::string(params_node.value()->json_pointer()) +
                             "/constraint")},
          std::move(priority.value()), true, authored_provenance(*node)};
      return Result<AuthoredSchedulerConfig>::success(
          {std::move(value), authored_provenance(*node)});
    }
    constexpr std::array keys{"constraint", "priority"};
    Result<void> params_closed = exact_keys(*params_node.value(), keys);
    if (!params_closed)
      return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
    Result<const SourceNode*> constraint_node =
        required(*params_node.value(), "constraint");
    if (!constraint_node)
      return fail<AuthoredSchedulerConfig>(std::move(constraint_node.error()));
    Result<CrossbarConstraint> constraint =
        parse_crossbar_constraint(*constraint_node.value());
    if (!constraint)
      return fail<AuthoredSchedulerConfig>(std::move(constraint.error()));
    Result<AuthoredPriority> priority = parse_priority(*params_node.value());
    if (!priority)
      return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
    CrossbarMaxWeightScheduler value{
        {std::move(constraint.value()),
         authored_provenance(*constraint_node.value())},
        std::move(priority.value()), false, authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }

  if (name.value() == "interval_max_weight") {
    constexpr std::array keys{"constraint", "priority"};
    Result<void> params_closed = exact_keys(*params_node.value(), keys);
    if (!params_closed)
      return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
    Result<const SourceNode*> constraint_node =
        required(*params_node.value(), "constraint");
    if (!constraint_node)
      return fail<AuthoredSchedulerConfig>(std::move(constraint_node.error()));
    Result<IntervalConstraint> constraint =
        parse_interval_constraint(*constraint_node.value());
    if (!constraint)
      return fail<AuthoredSchedulerConfig>(std::move(constraint.error()));
    Result<AuthoredPriority> priority = parse_priority(*params_node.value());
    if (!priority)
      return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
    IntervalMaxWeightScheduler value{
        {std::move(constraint.value()),
         authored_provenance(*constraint_node.value())},
        std::move(priority.value()), authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }

  if (name.value() == "node_exclusive_max_weight") {
    constexpr std::array keys{"constraint", "priority"};
    Result<void> params_closed = exact_keys(*params_node.value(), keys);
    if (!params_closed)
      return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
    Result<const SourceNode*> constraint_node =
        required(*params_node.value(), "constraint");
    if (!constraint_node)
      return fail<AuthoredSchedulerConfig>(std::move(constraint_node.error()));
    Result<NodeExclusiveConstraint> constraint =
        parse_node_constraint(*constraint_node.value());
    if (!constraint)
      return fail<AuthoredSchedulerConfig>(std::move(constraint.error()));
    Result<AuthoredPriority> priority = parse_priority(*params_node.value());
    if (!priority)
      return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
    NodeExclusiveMaxWeightScheduler value{
        {std::move(constraint.value()),
         authored_provenance(*constraint_node.value())},
        std::move(priority.value()), authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }

  if (name.value() == "conflict_graph_max_weight") {
    constexpr std::array keys{"constraint", "priority", "max_search_states"};
    Result<void> params_closed = exact_keys(*params_node.value(), keys);
    if (!params_closed)
      return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
    Result<const SourceNode*> constraint_node =
        required(*params_node.value(), "constraint");
    if (!constraint_node)
      return fail<AuthoredSchedulerConfig>(std::move(constraint_node.error()));
    Result<ConflictConstraint> constraint =
        parse_conflict_constraint(*constraint_node.value());
    if (!constraint)
      return fail<AuthoredSchedulerConfig>(std::move(constraint.error()));
    Result<AuthoredPriority> priority = parse_priority(*params_node.value());
    if (!priority)
      return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
    Result<AuthoredField<std::optional<BigNat>>> limit =
        parse_search_limit(*params_node.value());
    if (!limit) return fail<AuthoredSchedulerConfig>(std::move(limit.error()));
    ConflictGraphMaxWeightScheduler value{
        {std::move(constraint.value()),
         authored_provenance(*constraint_node.value())},
        std::move(priority.value()), std::move(limit.value()),
        authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }

  if (name.value() == "resource_packing_max_weight") {
    constexpr std::array keys{"constraint", "priority", "max_search_states"};
    Result<void> params_closed = exact_keys(*params_node.value(), keys);
    if (!params_closed)
      return fail<AuthoredSchedulerConfig>(std::move(params_closed.error()));
    Result<const SourceNode*> constraint_node =
        required(*params_node.value(), "constraint");
    if (!constraint_node)
      return fail<AuthoredSchedulerConfig>(std::move(constraint_node.error()));
    Result<PackingConstraint> constraint =
        parse_packing_constraint(*constraint_node.value());
    if (!constraint)
      return fail<AuthoredSchedulerConfig>(std::move(constraint.error()));
    Result<AuthoredPriority> priority = parse_priority(*params_node.value());
    if (!priority)
      return fail<AuthoredSchedulerConfig>(std::move(priority.error()));
    Result<AuthoredField<std::optional<BigNat>>> limit =
        parse_search_limit(*params_node.value());
    if (!limit) return fail<AuthoredSchedulerConfig>(std::move(limit.error()));
    ResourcePackingMaxWeightScheduler value{
        {std::move(constraint.value()),
         authored_provenance(*constraint_node.value())},
        std::move(priority.value()), std::move(limit.value()),
        authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }

  std::optional<CompatibilitySchedulerKind> compatibility;
  if (name.value() == "random_maximal") {
    compatibility = CompatibilitySchedulerKind::random_maximal;
  } else if (name.value() == "round_robin") {
    compatibility = CompatibilitySchedulerKind::round_robin;
  } else if (name.value() == "islip_rga") {
    compatibility = CompatibilitySchedulerKind::islip_rga;
  } else if (name.value() == "islip_canonical") {
    compatibility = CompatibilitySchedulerKind::islip_canonical;
  }
  if (compatibility.has_value()) {
    Result<CompatibilitySchedulerParams> parsed_params =
        parse_compatibility_scheduler_params(
            *compatibility, *params_node.value());
    if (!parsed_params)
      return fail<AuthoredSchedulerConfig>(std::move(parsed_params.error()));
    UnsupportedCompatibilityScheduler value{
        *compatibility, authored_provenance(*name_node),
        std::move(parsed_params.value()), *params_node.value(),
        authored_provenance(*node)};
    return Result<AuthoredSchedulerConfig>::success(
        {std::move(value), authored_provenance(*node)});
  }
  return fail<AuthoredSchedulerConfig>(diagnostic_at(
      *name_node, "model_unknown_scheduler",
      "scheduler.name is not a registered canonical scheduler tag"));
}

[[nodiscard]] Result<DestinationProbability> parse_destination_probability(
    const SourceNode& node) {
  constexpr std::array keys{"queue_id", "probability"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<DestinationProbability>(std::move(closed.error()));
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node)
    return fail<DestinationProbability>(std::move(queue_node.error()));
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) return fail<DestinationProbability>(std::move(queue.error()));
  Result<const SourceNode*> probability_node = required(node, "probability");
  if (!probability_node)
    return fail<DestinationProbability>(std::move(probability_node.error()));
  Result<AuthoredProbability> probability =
      parse_probability(*probability_node.value());
  if (!probability)
    return fail<DestinationProbability>(std::move(probability.error()));
  return Result<DestinationProbability>::success(DestinationProbability{
      {std::move(queue.value()), authored_provenance(*queue_node.value())},
      {std::move(probability.value()),
       authored_provenance(*probability_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<StateProbability> parse_state_probability(
    const SourceNode& node) {
  constexpr std::array keys{"state", "probability"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<StateProbability>(std::move(closed.error()));
  Result<const SourceNode*> state_node = required(node, "state");
  if (!state_node) return fail<StateProbability>(std::move(state_node.error()));
  Result<NormalizedToken> state =
      parse_normalized_token(*state_node.value(), "state identifier");
  if (!state) return fail<StateProbability>(std::move(state.error()));
  Result<const SourceNode*> probability_node = required(node, "probability");
  if (!probability_node)
    return fail<StateProbability>(std::move(probability_node.error()));
  Result<AuthoredProbability> probability =
      parse_probability(*probability_node.value());
  if (!probability)
    return fail<StateProbability>(std::move(probability.error()));
  return Result<StateProbability>::success(StateProbability{
      std::move(state.value()),
      {std::move(probability.value()),
       authored_provenance(*probability_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredInitialState> parse_initial_state(
    const SourceNode& node) {
  Result<void> object =
      require_kind(node, SourceNodeKind::object, "initial state");
  if (!object) return fail<AuthoredInitialState>(std::move(object.error()));
  constexpr std::array union_keys{"state", "distribution"};
  Result<void> union_closed = exact_keys(node, union_keys);
  if (!union_closed) {
    return fail<AuthoredInitialState>(std::move(union_closed.error()));
  }
  const bool has_state = node.find("state") != nullptr;
  const bool has_distribution = node.find("distribution") != nullptr;
  if (has_state == has_distribution) {
    return fail<AuthoredInitialState>(diagnostic_at(
        node, "model_initial_state_variant",
        "initial must contain exactly one of 'state' or 'distribution'"));
  }
  if (has_state) {
    constexpr std::array keys{"state"};
    Result<void> closed = exact_keys(node, keys);
    if (!closed) return fail<AuthoredInitialState>(std::move(closed.error()));
    const SourceNode* state_node = node.find("state");
    Result<NormalizedToken> state =
        parse_normalized_token(*state_node, "initial state identifier");
    if (!state) return fail<AuthoredInitialState>(std::move(state.error()));
    return Result<AuthoredInitialState>::success(
        InitialExactState{std::move(state.value()), authored_provenance(node)});
  }
  constexpr std::array keys{"distribution"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<AuthoredInitialState>(std::move(closed.error()));
  const SourceNode* distribution_node = node.find("distribution");
  Result<std::vector<StateProbability>> values =
      parse_array<StateProbability>(*distribution_node,
                                    "initial state distribution",
                                    parse_state_probability);
  if (!values) return fail<AuthoredInitialState>(std::move(values.error()));
  if (values.value().empty()) {
    return fail<AuthoredInitialState>(diagnostic_at(
        *distribution_node, "model_empty_initial_distribution",
        "initial state distribution must be nonempty"));
  }
  return Result<AuthoredInitialState>::success(InitialStateDistribution{
      {std::move(values.value()), authored_provenance(*distribution_node)},
      authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredInterarrival> parse_interarrival(
    const SourceNode& node) {
  Result<void> object =
      require_kind(node, SourceNodeKind::object, "interarrival law");
  if (!object) return fail<AuthoredInterarrival>(std::move(object.error()));
  constexpr std::array union_keys{"kind", "d", "outcomes", "d_min",
                                  "delta", "p"};
  Result<void> union_closed = exact_keys(node, union_keys);
  if (!union_closed) {
    return fail<AuthoredInterarrival>(std::move(union_closed.error()));
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  if (!kind_node) return fail<AuthoredInterarrival>(std::move(kind_node.error()));
  Result<std::string> kind =
      parse_string(*kind_node.value(), "interarrival.kind");
  if (!kind) return fail<AuthoredInterarrival>(std::move(kind.error()));
  if (kind.value() == "deterministic") {
    constexpr std::array keys{"kind", "d"};
    Result<void> closed = exact_keys(node, keys);
    if (!closed) return fail<AuthoredInterarrival>(std::move(closed.error()));
    Result<const SourceNode*> d_node = required(node, "d");
    if (!d_node) return fail<AuthoredInterarrival>(std::move(d_node.error()));
    Result<BigNat> d = parse_positive_natural(*d_node.value());
    if (!d) return fail<AuthoredInterarrival>(std::move(d.error()));
    return Result<AuthoredInterarrival>::success(DeterministicInterarrival{
        {std::move(d.value()), authored_provenance(*d_node.value())},
        authored_provenance(node)});
  }
  if (kind.value() == "finite_pmf") {
    constexpr std::array keys{"kind", "outcomes"};
    Result<void> closed = exact_keys(node, keys);
    if (!closed) return fail<AuthoredInterarrival>(std::move(closed.error()));
    Result<const SourceNode*> outcomes_node = required(node, "outcomes");
    if (!outcomes_node)
      return fail<AuthoredInterarrival>(std::move(outcomes_node.error()));
    Result<std::vector<GapProbability>> outcomes = parse_array<GapProbability>(
        *outcomes_node.value(), "finite interarrival outcomes",
        [](const SourceNode& outcome) {
          constexpr std::array item_keys{"d", "probability"};
          Result<void> item_closed = exact_keys(outcome, item_keys);
          if (!item_closed)
            return fail<GapProbability>(std::move(item_closed.error()));
          Result<const SourceNode*> d_node = required(outcome, "d");
          if (!d_node)
            return fail<GapProbability>(std::move(d_node.error()));
          Result<BigNat> d = parse_positive_natural(*d_node.value());
          if (!d) return fail<GapProbability>(std::move(d.error()));
          Result<const SourceNode*> probability_node =
              required(outcome, "probability");
          if (!probability_node)
            return fail<GapProbability>(std::move(probability_node.error()));
          Result<AuthoredProbability> probability =
              parse_probability(*probability_node.value());
          if (!probability)
            return fail<GapProbability>(std::move(probability.error()));
          return Result<GapProbability>::success(GapProbability{
              {std::move(d.value()), authored_provenance(*d_node.value())},
              {std::move(probability.value()),
               authored_provenance(*probability_node.value())},
              authored_provenance(outcome)});
        });
    if (!outcomes)
      return fail<AuthoredInterarrival>(std::move(outcomes.error()));
    if (outcomes.value().empty()) {
      return fail<AuthoredInterarrival>(diagnostic_at(
          *outcomes_node.value(), "model_empty_interarrival_pmf",
          "finite interarrival outcomes must be nonempty"));
    }
    return Result<AuthoredInterarrival>::success(FinitePmfInterarrival{
        {std::move(outcomes.value()),
         authored_provenance(*outcomes_node.value())},
        authored_provenance(node)});
  }
  if (kind.value() == "geometric_grid") {
    constexpr std::array keys{"kind", "d_min", "delta", "p"};
    Result<void> closed = exact_keys(node, keys);
    if (!closed) return fail<AuthoredInterarrival>(std::move(closed.error()));
    Result<const SourceNode*> d_min_node = required(node, "d_min");
    if (!d_min_node)
      return fail<AuthoredInterarrival>(std::move(d_min_node.error()));
    Result<BigNat> d_min = parse_positive_natural(*d_min_node.value());
    if (!d_min) return fail<AuthoredInterarrival>(std::move(d_min.error()));
    Result<const SourceNode*> delta_node = required(node, "delta");
    if (!delta_node)
      return fail<AuthoredInterarrival>(std::move(delta_node.error()));
    Result<BigNat> delta = parse_positive_natural(*delta_node.value());
    if (!delta) return fail<AuthoredInterarrival>(std::move(delta.error()));
    Result<const SourceNode*> p_node = required(node, "p");
    if (!p_node) return fail<AuthoredInterarrival>(std::move(p_node.error()));
    Result<AuthoredProbability> p = parse_probability(*p_node.value(), true);
    if (!p) return fail<AuthoredInterarrival>(std::move(p.error()));
    return Result<AuthoredInterarrival>::success(GeometricGridInterarrival{
        {std::move(d_min.value()), authored_provenance(*d_min_node.value())},
        {std::move(delta.value()), authored_provenance(*delta_node.value())},
        {std::move(p.value()), authored_provenance(*p_node.value())},
        authored_provenance(node)});
  }
  return fail<AuthoredInterarrival>(diagnostic_at(
      *kind_node.value(), "model_unknown_interarrival_kind",
      "interarrival.kind is not deterministic, finite_pmf, or geometric_grid"));
}

[[nodiscard]] Result<TraceEvent> parse_trace_event(const SourceNode& node) {
  constexpr std::array keys{"slot", "queue_id", "count"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<TraceEvent>(std::move(closed.error()));
  Result<const SourceNode*> slot_node = required(node, "slot");
  if (!slot_node) return fail<TraceEvent>(std::move(slot_node.error()));
  Result<BigNat> slot = parse_natural(*slot_node.value());
  if (!slot) return fail<TraceEvent>(std::move(slot.error()));
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node) return fail<TraceEvent>(std::move(queue_node.error()));
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) return fail<TraceEvent>(std::move(queue.error()));
  Result<const SourceNode*> count_node = required(node, "count");
  if (!count_node) return fail<TraceEvent>(std::move(count_node.error()));
  Result<BigNat> count = parse_positive_natural(
      *count_node.value(), bounded_by(static_cast<std::uint64_t>(
                               std::numeric_limits<std::int64_t>::max())));
  if (!count) return fail<TraceEvent>(std::move(count.error()));
  return Result<TraceEvent>::success(TraceEvent{
      {std::move(slot.value()), authored_provenance(*slot_node.value())},
      {std::move(queue.value()), authored_provenance(*queue_node.value())},
      {std::move(count.value()), authored_provenance(*count_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<PeriodicEntry> parse_periodic_entry(
    const SourceNode& node, const BigNat& period) {
  constexpr std::array keys{"offset", "queue_id", "count"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<PeriodicEntry>(std::move(closed.error()));
  Result<const SourceNode*> offset_node = required(node, "offset");
  if (!offset_node) return fail<PeriodicEntry>(std::move(offset_node.error()));
  Result<BigNat> offset = parse_natural(*offset_node.value());
  if (!offset) return fail<PeriodicEntry>(std::move(offset.error()));
  if (!(offset.value() < period)) {
    return fail<PeriodicEntry>(diagnostic_at(
        *offset_node.value(), "model_periodic_offset_out_of_range",
        "periodic offset must be strictly below period"));
  }
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node) return fail<PeriodicEntry>(std::move(queue_node.error()));
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) return fail<PeriodicEntry>(std::move(queue.error()));
  Result<const SourceNode*> count_node = required(node, "count");
  if (!count_node) return fail<PeriodicEntry>(std::move(count_node.error()));
  Result<BigNat> count = parse_positive_natural(
      *count_node.value(), bounded_by(static_cast<std::uint64_t>(
                               std::numeric_limits<std::int64_t>::max())));
  if (!count) return fail<PeriodicEntry>(std::move(count.error()));
  return Result<PeriodicEntry>::success(PeriodicEntry{
      {std::move(offset.value()), authored_provenance(*offset_node.value())},
      {std::move(queue.value()), authored_provenance(*queue_node.value())},
      {std::move(count.value()), authored_provenance(*count_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<DeterministicTraceArrival> parse_trace_arrival(
    const SourceNode& node) {
  constexpr std::array keys{"family", "events", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<DeterministicTraceArrival>(std::move(closed.error()));
  Result<const SourceNode*> events_node = required(node, "events");
  if (!events_node)
    return fail<DeterministicTraceArrival>(std::move(events_node.error()));
  Result<std::vector<TraceEvent>> events = parse_array<TraceEvent>(
      *events_node.value(), "deterministic trace events", parse_trace_event);
  if (!events)
    return fail<DeterministicTraceArrival>(std::move(events.error()));
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<DeterministicTraceArrival>(std::move(metadata.error()));
  return Result<DeterministicTraceArrival>::success(
      DeterministicTraceArrival{
          {std::move(events.value()), authored_provenance(*events_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<PeriodicGlobalPhaseArrival> parse_global_phase_arrival(
    const SourceNode& node) {
  constexpr std::array keys{"family", "period", "phase", "sources",
                            "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<PeriodicGlobalPhaseArrival>(std::move(closed.error()));
  Result<const SourceNode*> period_node = required(node, "period");
  if (!period_node)
    return fail<PeriodicGlobalPhaseArrival>(std::move(period_node.error()));
  Result<BigNat> period = parse_positive_natural(*period_node.value());
  if (!period)
    return fail<PeriodicGlobalPhaseArrival>(std::move(period.error()));
  Result<const SourceNode*> phase_node = required(node, "phase");
  if (!phase_node)
    return fail<PeriodicGlobalPhaseArrival>(std::move(phase_node.error()));
  Result<BigNat> phase = parse_natural(*phase_node.value());
  if (!phase)
    return fail<PeriodicGlobalPhaseArrival>(std::move(phase.error()));
  if (!(phase.value() < period.value())) {
    return fail<PeriodicGlobalPhaseArrival>(diagnostic_at(
        *phase_node.value(), "model_phase_out_of_range",
        "periodic phase must be strictly below period"));
  }
  Result<const SourceNode*> sources_node = required(node, "sources");
  if (!sources_node)
    return fail<PeriodicGlobalPhaseArrival>(std::move(sources_node.error()));
  const BigNat period_copy = period.value();
  Result<std::vector<GlobalPhaseSource>> sources =
      parse_array<GlobalPhaseSource>(
          *sources_node.value(), "periodic sources",
          [&period_copy](const SourceNode& source) {
            constexpr std::array source_keys{"id", "entries"};
            Result<void> source_closed = exact_keys(source, source_keys);
            if (!source_closed)
              return fail<GlobalPhaseSource>(std::move(source_closed.error()));
            Result<const SourceNode*> id_node = required(source, "id");
            if (!id_node)
              return fail<GlobalPhaseSource>(std::move(id_node.error()));
            Result<NormalizedToken> id =
                parse_normalized_token(*id_node.value(), "source id");
            if (!id)
              return fail<GlobalPhaseSource>(std::move(id.error()));
            Result<const SourceNode*> entries_node = required(source, "entries");
            if (!entries_node)
              return fail<GlobalPhaseSource>(std::move(entries_node.error()));
            Result<std::vector<PeriodicEntry>> entries =
                parse_array<PeriodicEntry>(
                    *entries_node.value(), "periodic source entries",
                    [&period_copy](const SourceNode& entry) {
                      return parse_periodic_entry(entry, period_copy);
                    });
            if (!entries)
              return fail<GlobalPhaseSource>(std::move(entries.error()));
            return Result<GlobalPhaseSource>::success(GlobalPhaseSource{
                std::move(id.value()),
                {std::move(entries.value()),
                 authored_provenance(*entries_node.value())},
                authored_provenance(source)});
          });
  if (!sources)
    return fail<PeriodicGlobalPhaseArrival>(std::move(sources.error()));
  std::map<std::string, ModelProvenance> source_ids;
  for (const GlobalPhaseSource& source : sources.value()) {
    Result<void> unique =
        record_unique_token(source.id, source_ids, "source-id");
    if (!unique)
      return fail<PeriodicGlobalPhaseArrival>(std::move(unique.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<PeriodicGlobalPhaseArrival>(std::move(metadata.error()));
  return Result<PeriodicGlobalPhaseArrival>::success(
      PeriodicGlobalPhaseArrival{
          {std::move(period.value()), authored_provenance(*period_node.value())},
          {std::move(phase.value()), authored_provenance(*phase_node.value())},
          {std::move(sources.value()),
           authored_provenance(*sources_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<PeriodicSourceDelaysArrival> parse_delays_arrival(
    const SourceNode& node) {
  constexpr std::array keys{"family", "period", "sources", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<PeriodicSourceDelaysArrival>(std::move(closed.error()));
  Result<const SourceNode*> period_node = required(node, "period");
  if (!period_node)
    return fail<PeriodicSourceDelaysArrival>(std::move(period_node.error()));
  Result<BigNat> period = parse_positive_natural(*period_node.value());
  if (!period)
    return fail<PeriodicSourceDelaysArrival>(std::move(period.error()));
  Result<const SourceNode*> sources_node = required(node, "sources");
  if (!sources_node)
    return fail<PeriodicSourceDelaysArrival>(std::move(sources_node.error()));
  const BigNat period_copy = period.value();
  Result<std::vector<DelayedPeriodicSource>> sources =
      parse_array<DelayedPeriodicSource>(
          *sources_node.value(), "delayed periodic sources",
          [&period_copy](const SourceNode& source) {
            constexpr std::array source_keys{"id", "delay", "entries"};
            Result<void> source_closed = exact_keys(source, source_keys);
            if (!source_closed)
              return fail<DelayedPeriodicSource>(
                  std::move(source_closed.error()));
            Result<const SourceNode*> id_node = required(source, "id");
            if (!id_node)
              return fail<DelayedPeriodicSource>(std::move(id_node.error()));
            Result<NormalizedToken> id =
                parse_normalized_token(*id_node.value(), "source id");
            if (!id)
              return fail<DelayedPeriodicSource>(std::move(id.error()));
            Result<const SourceNode*> delay_node = required(source, "delay");
            if (!delay_node)
              return fail<DelayedPeriodicSource>(std::move(delay_node.error()));
            Result<BigNat> delay = parse_natural(*delay_node.value());
            if (!delay)
              return fail<DelayedPeriodicSource>(std::move(delay.error()));
            Result<const SourceNode*> entries_node = required(source, "entries");
            if (!entries_node)
              return fail<DelayedPeriodicSource>(std::move(entries_node.error()));
            Result<std::vector<PeriodicEntry>> entries =
                parse_array<PeriodicEntry>(
                    *entries_node.value(), "periodic source entries",
                    [&period_copy](const SourceNode& entry) {
                      return parse_periodic_entry(entry, period_copy);
                    });
            if (!entries)
              return fail<DelayedPeriodicSource>(std::move(entries.error()));
            return Result<DelayedPeriodicSource>::success(
                DelayedPeriodicSource{
                    std::move(id.value()),
                    {std::move(delay.value()),
                     authored_provenance(*delay_node.value())},
                    {std::move(entries.value()),
                     authored_provenance(*entries_node.value())},
                    authored_provenance(source)});
          });
  if (!sources)
    return fail<PeriodicSourceDelaysArrival>(std::move(sources.error()));
  std::map<std::string, ModelProvenance> source_ids;
  for (const DelayedPeriodicSource& source : sources.value()) {
    Result<void> unique =
        record_unique_token(source.id, source_ids, "source-id");
    if (!unique)
      return fail<PeriodicSourceDelaysArrival>(std::move(unique.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<PeriodicSourceDelaysArrival>(std::move(metadata.error()));
  return Result<PeriodicSourceDelaysArrival>::success(
      PeriodicSourceDelaysArrival{
          {std::move(period.value()), authored_provenance(*period_node.value())},
          {std::move(sources.value()),
           authored_provenance(*sources_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<MarkedRenewalSource> parse_marked_source(
    const SourceNode& source) {
  Result<void> object =
      require_kind(source, SourceNodeKind::object, "renewal source");
  if (!object) return fail<MarkedRenewalSource>(std::move(object.error()));
  constexpr std::array union_keys{"id", "interarrival", "destination_pmf",
                                  "joint_pmf"};
  Result<void> union_closed = exact_keys(source, union_keys);
  if (!union_closed) {
    return fail<MarkedRenewalSource>(std::move(union_closed.error()));
  }
  const bool factorized = source.find("interarrival") != nullptr ||
                          source.find("destination_pmf") != nullptr;
  const bool joint = source.find("joint_pmf") != nullptr;
  if (factorized == joint) {
    return fail<MarkedRenewalSource>(diagnostic_at(
        source, "model_renewal_source_variant",
        "renewal source must use exactly one factorized or joint form"));
  }
  if (factorized) {
    constexpr std::array keys{"id", "interarrival", "destination_pmf"};
    Result<void> closed = exact_keys(source, keys);
    if (!closed) return fail<MarkedRenewalSource>(std::move(closed.error()));
    Result<const SourceNode*> id_node = required(source, "id");
    if (!id_node) return fail<MarkedRenewalSource>(std::move(id_node.error()));
    Result<NormalizedToken> id =
        parse_normalized_token(*id_node.value(), "source id");
    if (!id) return fail<MarkedRenewalSource>(std::move(id.error()));
    Result<const SourceNode*> interarrival_node =
        required(source, "interarrival");
    if (!interarrival_node)
      return fail<MarkedRenewalSource>(std::move(interarrival_node.error()));
    Result<AuthoredInterarrival> interarrival =
        parse_interarrival(*interarrival_node.value());
    if (!interarrival)
      return fail<MarkedRenewalSource>(std::move(interarrival.error()));
    Result<const SourceNode*> destination_node =
        required(source, "destination_pmf");
    if (!destination_node)
      return fail<MarkedRenewalSource>(std::move(destination_node.error()));
    Result<std::vector<DestinationProbability>> destination =
        parse_array<DestinationProbability>(*destination_node.value(),
                                            "destination PMF",
                                            parse_destination_probability);
    if (!destination)
      return fail<MarkedRenewalSource>(std::move(destination.error()));
    if (destination.value().empty()) {
      return fail<MarkedRenewalSource>(diagnostic_at(
          *destination_node.value(), "model_empty_destination_pmf",
          "destination PMF must be nonempty"));
    }
    return Result<MarkedRenewalSource>::success(FactorizedRenewalSource{
        std::move(id.value()),
        {std::move(interarrival.value()),
         authored_provenance(*interarrival_node.value())},
        {std::move(destination.value()),
         authored_provenance(*destination_node.value())},
        authored_provenance(source)});
  }
  constexpr std::array keys{"id", "joint_pmf"};
  Result<void> closed = exact_keys(source, keys);
  if (!closed) return fail<MarkedRenewalSource>(std::move(closed.error()));
  Result<const SourceNode*> id_node = required(source, "id");
  if (!id_node) return fail<MarkedRenewalSource>(std::move(id_node.error()));
  Result<NormalizedToken> id =
      parse_normalized_token(*id_node.value(), "source id");
  if (!id) return fail<MarkedRenewalSource>(std::move(id.error()));
  Result<const SourceNode*> pmf_node = required(source, "joint_pmf");
  if (!pmf_node) return fail<MarkedRenewalSource>(std::move(pmf_node.error()));
  Result<std::vector<JointRenewalMass>> pmf = parse_array<JointRenewalMass>(
      *pmf_node.value(), "joint renewal PMF", [](const SourceNode& row) {
        constexpr std::array row_keys{"d", "queue_id", "probability"};
        Result<void> row_closed = exact_keys(row, row_keys);
        if (!row_closed)
          return fail<JointRenewalMass>(std::move(row_closed.error()));
        Result<const SourceNode*> d_node = required(row, "d");
        if (!d_node) return fail<JointRenewalMass>(std::move(d_node.error()));
        Result<BigNat> d = parse_positive_natural(*d_node.value());
        if (!d) return fail<JointRenewalMass>(std::move(d.error()));
        Result<const SourceNode*> queue_node = required(row, "queue_id");
        if (!queue_node)
          return fail<JointRenewalMass>(std::move(queue_node.error()));
        Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
        if (!queue) return fail<JointRenewalMass>(std::move(queue.error()));
        Result<const SourceNode*> probability_node = required(row, "probability");
        if (!probability_node)
          return fail<JointRenewalMass>(std::move(probability_node.error()));
        Result<AuthoredProbability> probability =
            parse_probability(*probability_node.value());
        if (!probability)
          return fail<JointRenewalMass>(std::move(probability.error()));
        return Result<JointRenewalMass>::success(JointRenewalMass{
            {std::move(d.value()), authored_provenance(*d_node.value())},
            {std::move(queue.value()), authored_provenance(*queue_node.value())},
            {std::move(probability.value()),
             authored_provenance(*probability_node.value())},
            authored_provenance(row)});
      });
  if (!pmf) return fail<MarkedRenewalSource>(std::move(pmf.error()));
  if (pmf.value().empty()) {
    return fail<MarkedRenewalSource>(diagnostic_at(
        *pmf_node.value(), "model_empty_joint_pmf",
        "joint renewal PMF must be nonempty"));
  }
  return Result<MarkedRenewalSource>::success(JointRenewalSource{
      std::move(id.value()),
      {std::move(pmf.value()), authored_provenance(*pmf_node.value())},
      authored_provenance(source)});
}

[[nodiscard]] const NormalizedToken& marked_source_id(
    const MarkedRenewalSource& source) {
  return std::visit(
      [](const auto& value) -> const NormalizedToken& { return value.id; },
      source);
}

[[nodiscard]] Result<IndependentMarkedRenewalArrival> parse_marked_arrival(
    const SourceNode& node) {
  constexpr std::array keys{"family", "sources", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<IndependentMarkedRenewalArrival>(std::move(closed.error()));
  Result<const SourceNode*> sources_node = required(node, "sources");
  if (!sources_node)
    return fail<IndependentMarkedRenewalArrival>(std::move(sources_node.error()));
  Result<std::vector<MarkedRenewalSource>> sources =
      parse_array<MarkedRenewalSource>(*sources_node.value(), "renewal sources",
                                       parse_marked_source);
  if (!sources)
    return fail<IndependentMarkedRenewalArrival>(std::move(sources.error()));
  if (sources.value().empty()) {
    return fail<IndependentMarkedRenewalArrival>(diagnostic_at(
        *sources_node.value(), "model_empty_renewal_sources",
        "independent marked renewal requires at least one source"));
  }
  std::map<std::string, ModelProvenance> source_ids;
  for (const MarkedRenewalSource& source : sources.value()) {
    Result<void> unique =
        record_unique_token(marked_source_id(source), source_ids, "source-id");
    if (!unique)
      return fail<IndependentMarkedRenewalArrival>(std::move(unique.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<IndependentMarkedRenewalArrival>(std::move(metadata.error()));
  return Result<IndependentMarkedRenewalArrival>::success(
      IndependentMarkedRenewalArrival{
          {std::move(sources.value()),
           authored_provenance(*sources_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<StateGap> parse_state_gap(const SourceNode& node) {
  constexpr std::array keys{"state", "d"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<StateGap>(std::move(closed.error()));
  Result<const SourceNode*> state_node = required(node, "state");
  if (!state_node) return fail<StateGap>(std::move(state_node.error()));
  Result<NormalizedToken> state =
      parse_normalized_token(*state_node.value(), "state identifier");
  if (!state) return fail<StateGap>(std::move(state.error()));
  Result<const SourceNode*> d_node = required(node, "d");
  if (!d_node) return fail<StateGap>(std::move(d_node.error()));
  Result<BigNat> d = parse_positive_natural(*d_node.value());
  if (!d) return fail<StateGap>(std::move(d.error()));
  return Result<StateGap>::success(StateGap{
      std::move(state.value()),
      {std::move(d.value()), authored_provenance(*d_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<StateTransition> parse_state_transition(
    const SourceNode& node) {
  constexpr std::array keys{"state", "next_state", "probability"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<StateTransition>(std::move(closed.error()));
  Result<const SourceNode*> state_node = required(node, "state");
  if (!state_node) return fail<StateTransition>(std::move(state_node.error()));
  Result<NormalizedToken> state =
      parse_normalized_token(*state_node.value(), "state identifier");
  if (!state) return fail<StateTransition>(std::move(state.error()));
  Result<const SourceNode*> next_node = required(node, "next_state");
  if (!next_node) return fail<StateTransition>(std::move(next_node.error()));
  Result<NormalizedToken> next =
      parse_normalized_token(*next_node.value(), "next-state identifier");
  if (!next) return fail<StateTransition>(std::move(next.error()));
  Result<const SourceNode*> probability_node = required(node, "probability");
  if (!probability_node)
    return fail<StateTransition>(std::move(probability_node.error()));
  Result<AuthoredProbability> probability =
      parse_probability(*probability_node.value());
  if (!probability)
    return fail<StateTransition>(std::move(probability.error()));
  return Result<StateTransition>::success(StateTransition{
      std::move(state.value()), std::move(next.value()),
      {std::move(probability.value()),
       authored_provenance(*probability_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<PrivateMarkovRenewalSource> parse_private_source(
    const SourceNode& source) {
  constexpr std::array keys{"id",          "states",      "initial",
                            "gaps",        "transitions", "destination_pmf"};
  Result<void> closed = exact_keys(source, keys);
  if (!closed)
    return fail<PrivateMarkovRenewalSource>(std::move(closed.error()));
  Result<const SourceNode*> id_node = required(source, "id");
  if (!id_node)
    return fail<PrivateMarkovRenewalSource>(std::move(id_node.error()));
  Result<NormalizedToken> id =
      parse_normalized_token(*id_node.value(), "source id");
  if (!id) return fail<PrivateMarkovRenewalSource>(std::move(id.error()));
  Result<const SourceNode*> states_node = required(source, "states");
  if (!states_node)
    return fail<PrivateMarkovRenewalSource>(std::move(states_node.error()));
  Result<std::vector<NormalizedToken>> states = parse_array<NormalizedToken>(
      *states_node.value(), "source states", [](const SourceNode& item) {
        return parse_normalized_token(item, "state identifier");
      });
  if (!states)
    return fail<PrivateMarkovRenewalSource>(std::move(states.error()));
  if (states.value().empty()) {
    return fail<PrivateMarkovRenewalSource>(diagnostic_at(
        *states_node.value(), "model_empty_state_catalog",
        "private Markov source states must be nonempty"));
  }
  std::map<std::string, ModelProvenance> state_ids;
  for (const NormalizedToken& state : states.value()) {
    Result<void> unique =
        record_unique_token(state, state_ids, "state-id");
    if (!unique)
      return fail<PrivateMarkovRenewalSource>(std::move(unique.error()));
  }
  Result<const SourceNode*> initial_node = required(source, "initial");
  if (!initial_node)
    return fail<PrivateMarkovRenewalSource>(std::move(initial_node.error()));
  Result<AuthoredInitialState> initial = parse_initial_state(*initial_node.value());
  if (!initial)
    return fail<PrivateMarkovRenewalSource>(std::move(initial.error()));
  Result<const SourceNode*> gaps_node = required(source, "gaps");
  if (!gaps_node)
    return fail<PrivateMarkovRenewalSource>(std::move(gaps_node.error()));
  Result<std::vector<StateGap>> gaps =
      parse_array<StateGap>(*gaps_node.value(), "state gaps", parse_state_gap);
  if (!gaps) return fail<PrivateMarkovRenewalSource>(std::move(gaps.error()));
  Result<const SourceNode*> transitions_node = required(source, "transitions");
  if (!transitions_node)
    return fail<PrivateMarkovRenewalSource>(std::move(transitions_node.error()));
  Result<std::vector<StateTransition>> transitions =
      parse_array<StateTransition>(*transitions_node.value(),
                                   "state transitions",
                                   parse_state_transition);
  if (!transitions)
    return fail<PrivateMarkovRenewalSource>(std::move(transitions.error()));
  if (transitions.value().empty()) {
    return fail<PrivateMarkovRenewalSource>(diagnostic_at(
        *transitions_node.value(), "model_empty_transition_rows",
        "private Markov transitions must be nonempty"));
  }
  Result<const SourceNode*> destination_node =
      required(source, "destination_pmf");
  if (!destination_node)
    return fail<PrivateMarkovRenewalSource>(std::move(destination_node.error()));
  Result<std::vector<DestinationProbability>> destination =
      parse_array<DestinationProbability>(*destination_node.value(),
                                          "destination PMF",
                                          parse_destination_probability);
  if (!destination)
    return fail<PrivateMarkovRenewalSource>(std::move(destination.error()));
  if (destination.value().empty()) {
    return fail<PrivateMarkovRenewalSource>(diagnostic_at(
        *destination_node.value(), "model_empty_destination_pmf",
        "destination PMF must be nonempty"));
  }
  return Result<PrivateMarkovRenewalSource>::success(
      PrivateMarkovRenewalSource{
          std::move(id.value()),
          {std::move(states.value()), authored_provenance(*states_node.value())},
          {std::move(initial.value()),
           authored_provenance(*initial_node.value())},
          {std::move(gaps.value()), authored_provenance(*gaps_node.value())},
          {std::move(transitions.value()),
           authored_provenance(*transitions_node.value())},
          {std::move(destination.value()),
           authored_provenance(*destination_node.value())},
          authored_provenance(source)});
}

[[nodiscard]] Result<IndependentPrivateMarkovRenewalArrival>
parse_private_arrival(const SourceNode& node) {
  constexpr std::array keys{"family", "sources", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<IndependentPrivateMarkovRenewalArrival>(
        std::move(closed.error()));
  Result<const SourceNode*> sources_node = required(node, "sources");
  if (!sources_node)
    return fail<IndependentPrivateMarkovRenewalArrival>(
        std::move(sources_node.error()));
  Result<std::vector<PrivateMarkovRenewalSource>> sources =
      parse_array<PrivateMarkovRenewalSource>(
          *sources_node.value(), "private Markov sources",
          parse_private_source);
  if (!sources)
    return fail<IndependentPrivateMarkovRenewalArrival>(
        std::move(sources.error()));
  if (sources.value().empty()) {
    return fail<IndependentPrivateMarkovRenewalArrival>(diagnostic_at(
        *sources_node.value(), "model_empty_private_sources",
        "independent private Markov renewal requires at least one source"));
  }
  std::map<std::string, ModelProvenance> source_ids;
  for (const PrivateMarkovRenewalSource& source : sources.value()) {
    Result<void> unique =
        record_unique_token(source.id, source_ids, "source-id");
    if (!unique)
      return fail<IndependentPrivateMarkovRenewalArrival>(
          std::move(unique.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<IndependentPrivateMarkovRenewalArrival>(
        std::move(metadata.error()));
  return Result<IndependentPrivateMarkovRenewalArrival>::success(
      IndependentPrivateMarkovRenewalArrival{
          {std::move(sources.value()),
           authored_provenance(*sources_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<SharedRenewalSource> parse_shared_source(
    const SourceNode& node) {
  constexpr std::array keys{"id"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<SharedRenewalSource>(std::move(closed.error()));
  Result<const SourceNode*> id_node = required(node, "id");
  if (!id_node) return fail<SharedRenewalSource>(std::move(id_node.error()));
  Result<NormalizedToken> id =
      parse_normalized_token(*id_node.value(), "source id");
  if (!id) return fail<SharedRenewalSource>(std::move(id.error()));
  return Result<SharedRenewalSource>::success(
      SharedRenewalSource{std::move(id.value()), authored_provenance(node)});
}

[[nodiscard]] Result<SharedEmission> parse_shared_emission(
    const SourceNode& node) {
  constexpr std::array keys{"source_id", "d", "queue_id"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<SharedEmission>(std::move(closed.error()));
  Result<const SourceNode*> source_node = required(node, "source_id");
  if (!source_node) return fail<SharedEmission>(std::move(source_node.error()));
  Result<NormalizedToken> source =
      parse_normalized_token(*source_node.value(), "source id");
  if (!source) return fail<SharedEmission>(std::move(source.error()));
  Result<const SourceNode*> d_node = required(node, "d");
  if (!d_node) return fail<SharedEmission>(std::move(d_node.error()));
  Result<BigNat> d = parse_positive_natural(*d_node.value());
  if (!d) return fail<SharedEmission>(std::move(d.error()));
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node) return fail<SharedEmission>(std::move(queue_node.error()));
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) return fail<SharedEmission>(std::move(queue.error()));
  return Result<SharedEmission>::success(SharedEmission{
      std::move(source.value()),
      {std::move(d.value()), authored_provenance(*d_node.value())},
      {std::move(queue.value()), authored_provenance(*queue_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<SharedOutcome> parse_shared_outcome(
    const SourceNode& node) {
  constexpr std::array keys{"state", "next_state", "probability",
                            "emissions"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return fail<SharedOutcome>(std::move(closed.error()));
  Result<const SourceNode*> state_node = required(node, "state");
  if (!state_node) return fail<SharedOutcome>(std::move(state_node.error()));
  Result<NormalizedToken> state =
      parse_normalized_token(*state_node.value(), "state identifier");
  if (!state) return fail<SharedOutcome>(std::move(state.error()));
  Result<const SourceNode*> next_node = required(node, "next_state");
  if (!next_node) return fail<SharedOutcome>(std::move(next_node.error()));
  Result<NormalizedToken> next =
      parse_normalized_token(*next_node.value(), "next-state identifier");
  if (!next) return fail<SharedOutcome>(std::move(next.error()));
  Result<const SourceNode*> probability_node = required(node, "probability");
  if (!probability_node)
    return fail<SharedOutcome>(std::move(probability_node.error()));
  Result<AuthoredProbability> probability =
      parse_probability(*probability_node.value());
  if (!probability)
    return fail<SharedOutcome>(std::move(probability.error()));
  Result<const SourceNode*> emissions_node = required(node, "emissions");
  if (!emissions_node)
    return fail<SharedOutcome>(std::move(emissions_node.error()));
  Result<std::vector<SharedEmission>> emissions =
      parse_array<SharedEmission>(*emissions_node.value(), "shared emissions",
                                  parse_shared_emission);
  if (!emissions) return fail<SharedOutcome>(std::move(emissions.error()));
  return Result<SharedOutcome>::success(SharedOutcome{
      std::move(state.value()), std::move(next.value()),
      {std::move(probability.value()),
       authored_provenance(*probability_node.value())},
      {std::move(emissions.value()),
       authored_provenance(*emissions_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<SharedJointRoundMarkovRenewalArrival>
parse_shared_arrival(const SourceNode& node) {
  constexpr std::array keys{"family", "sources", "states", "initial",
                            "outcomes", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed)
    return fail<SharedJointRoundMarkovRenewalArrival>(
        std::move(closed.error()));
  Result<const SourceNode*> sources_node = required(node, "sources");
  if (!sources_node)
    return fail<SharedJointRoundMarkovRenewalArrival>(
        std::move(sources_node.error()));
  Result<std::vector<SharedRenewalSource>> sources =
      parse_array<SharedRenewalSource>(*sources_node.value(), "shared sources",
                                       parse_shared_source);
  if (!sources)
    return fail<SharedJointRoundMarkovRenewalArrival>(std::move(sources.error()));
  if (sources.value().empty()) {
    return fail<SharedJointRoundMarkovRenewalArrival>(diagnostic_at(
        *sources_node.value(), "model_empty_shared_sources",
        "shared joint renewal requires at least one source"));
  }
  std::map<std::string, ModelProvenance> source_ids;
  for (const SharedRenewalSource& source : sources.value()) {
    Result<void> unique =
        record_unique_token(source.id, source_ids, "source-id");
    if (!unique)
      return fail<SharedJointRoundMarkovRenewalArrival>(
          std::move(unique.error()));
  }
  Result<const SourceNode*> states_node = required(node, "states");
  if (!states_node)
    return fail<SharedJointRoundMarkovRenewalArrival>(
        std::move(states_node.error()));
  Result<std::vector<NormalizedToken>> states = parse_array<NormalizedToken>(
      *states_node.value(), "shared states", [](const SourceNode& item) {
        return parse_normalized_token(item, "state identifier");
      });
  if (!states)
    return fail<SharedJointRoundMarkovRenewalArrival>(std::move(states.error()));
  if (states.value().empty()) {
    return fail<SharedJointRoundMarkovRenewalArrival>(diagnostic_at(
        *states_node.value(), "model_empty_state_catalog",
        "shared Markov states must be nonempty"));
  }
  std::map<std::string, ModelProvenance> state_ids;
  for (const NormalizedToken& state : states.value()) {
    Result<void> unique =
        record_unique_token(state, state_ids, "state-id");
    if (!unique)
      return fail<SharedJointRoundMarkovRenewalArrival>(
          std::move(unique.error()));
  }
  Result<const SourceNode*> initial_node = required(node, "initial");
  if (!initial_node)
    return fail<SharedJointRoundMarkovRenewalArrival>(
        std::move(initial_node.error()));
  Result<AuthoredInitialState> initial = parse_initial_state(*initial_node.value());
  if (!initial)
    return fail<SharedJointRoundMarkovRenewalArrival>(std::move(initial.error()));
  Result<const SourceNode*> outcomes_node = required(node, "outcomes");
  if (!outcomes_node)
    return fail<SharedJointRoundMarkovRenewalArrival>(
        std::move(outcomes_node.error()));
  Result<std::vector<SharedOutcome>> outcomes = parse_array<SharedOutcome>(
      *outcomes_node.value(), "shared outcomes", parse_shared_outcome);
  if (!outcomes)
    return fail<SharedJointRoundMarkovRenewalArrival>(std::move(outcomes.error()));
  if (outcomes.value().empty()) {
    return fail<SharedJointRoundMarkovRenewalArrival>(diagnostic_at(
        *outcomes_node.value(), "model_empty_shared_outcomes",
        "shared Markov outcomes must be nonempty"));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<SharedJointRoundMarkovRenewalArrival>(std::move(metadata.error()));
  return Result<SharedJointRoundMarkovRenewalArrival>::success(
      SharedJointRoundMarkovRenewalArrival{
          {std::move(sources.value()),
           authored_provenance(*sources_node.value())},
          {std::move(states.value()), authored_provenance(*states_node.value())},
          {std::move(initial.value()),
           authored_provenance(*initial_node.value())},
          {std::move(outcomes.value()),
           authored_provenance(*outcomes_node.value())},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<void> validate_legacy_edge(const SourceNode& edge) {
  Result<void> array = require_kind(edge, SourceNodeKind::array, "legacy edge");
  if (!array) return array;
  if (edge.array_items().size() != 2U) {
    return Result<void>::failure(diagnostic_at(
        edge, "model_legacy_edge_arity",
        "legacy edge must contain exactly [source,destination]"));
  }
  for (const SourceNode& coordinate : edge.array_items()) {
    Result<BigNat> value = parse_natural(coordinate);
    if (!value) return Result<void>::failure(std::move(value.error()));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_legacy_edges_array(const SourceNode& node) {
  Result<void> array =
      require_kind(node, SourceNodeKind::array, "legacy edges");
  if (!array) return array;
  for (const SourceNode& edge : node.array_items()) {
    Result<void> valid = validate_legacy_edge(edge);
    if (!valid) return valid;
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_allowed_edges(const SourceNode* node) {
  if (node == nullptr) return Result<void>::success();
  constexpr std::array keys{"mode", "edges"};
  Result<void> closed = exact_keys(*node, keys);
  if (!closed) return closed;
  Result<const SourceNode*> mode_node = required(*node, "mode");
  if (!mode_node) return Result<void>::failure(std::move(mode_node.error()));
  Result<std::string> mode =
      parse_string(*mode_node.value(), "allowed_edges.mode");
  if (!mode) return Result<void>::failure(std::move(mode.error()));
  if (mode.value() != "full" && mode.value() != "explicit") {
    return Result<void>::failure(diagnostic_at(
        *mode_node.value(), "model_unknown_allowed_edges_mode",
        "allowed_edges.mode must be 'full' or 'explicit'"));
  }
  const SourceNode* edges = node->find("edges");
  if (mode.value() == "explicit" && edges == nullptr) {
    return Result<void>::failure(diagnostic_at(
        *node, "model_missing_key",
        "explicit allowed_edges requires an edges array"));
  }
  if (edges != nullptr) {
    Result<void> valid = validate_legacy_edges_array(*edges);
    if (!valid) return valid;
    if (mode.value() == "full" && !edges->array_items().empty()) {
      return Result<void>::failure(diagnostic_at(
          *edges, "model_full_edges_not_empty",
          "full allowed_edges must omit edges or use an empty array"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_alphabet_constraint(
    const SourceNode* node, const bool require_unrestricted = false) {
  if (node == nullptr) return Result<void>::success();
  Result<std::string> value = parse_string(*node, "alphabet_constraint");
  if (!value) return Result<void>::failure(std::move(value.error()));
  if (value.value() != "unrestricted" &&
      value.value() != "per_input_line_rate" &&
      value.value() != "global_one_hot") {
    return Result<void>::failure(diagnostic_at(
        *node, "model_unknown_alphabet_constraint",
        "alphabet_constraint is not a registered canonical tag"));
  }
  if (require_unrestricted && value.value() != "unrestricted") {
    return Result<void>::failure(diagnostic_at(
        *node, "model_factorized_constraint_not_unrestricted",
        "factorized_bernoulli requires alphabet_constraint 'unrestricted'"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_iid_table(const SourceNode& node) {
  constexpr std::array keys{"family", "allowed_edges", "alphabet_constraint",
                            "alphabet", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return closed;
  Result<void> allowed = validate_allowed_edges(node.find("allowed_edges"));
  if (!allowed) return allowed;
  Result<void> constraint =
      validate_alphabet_constraint(node.find("alphabet_constraint"));
  if (!constraint) return constraint;
  Result<const SourceNode*> alphabet_node = required(node, "alphabet");
  if (!alphabet_node) return Result<void>::failure(std::move(alphabet_node.error()));
  Result<void> array = require_kind(*alphabet_node.value(), SourceNodeKind::array,
                                    "iid_table alphabet");
  if (!array) return array;
  if (alphabet_node.value()->array_items().empty()) {
    return Result<void>::failure(diagnostic_at(
        *alphabet_node.value(), "model_empty_compatibility_alphabet",
        "iid_table alphabet must be nonempty"));
  }
  std::map<std::string, ModelProvenance> ids;
  for (const SourceNode& atom : alphabet_node.value()->array_items()) {
    constexpr std::array atom_keys{"id", "edges", "probability"};
    Result<void> atom_closed = exact_keys(atom, atom_keys);
    if (!atom_closed) return atom_closed;
    if (const SourceNode* id_node = atom.find("id"); id_node != nullptr) {
      Result<NormalizedToken> id =
          parse_normalized_token(*id_node, "alphabet id");
      if (!id) return Result<void>::failure(std::move(id.error()));
      Result<void> unique = record_unique_token(id.value(), ids, "alphabet-id");
      if (!unique) return unique;
    }
    Result<const SourceNode*> edges_node = required(atom, "edges");
    if (!edges_node) return Result<void>::failure(std::move(edges_node.error()));
    Result<void> edges = validate_legacy_edges_array(*edges_node.value());
    if (!edges) return edges;
    Result<const SourceNode*> probability_node = required(atom, "probability");
    if (!probability_node)
      return Result<void>::failure(std::move(probability_node.error()));
    Result<AuthoredProbability> probability =
        parse_probability(*probability_node.value());
    if (!probability)
      return Result<void>::failure(std::move(probability.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) return Result<void>::failure(std::move(metadata.error()));
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_markov_kernel(const SourceNode& node) {
  constexpr std::array keys{"family",  "allowed_edges", "alphabet_constraint",
                            "states",  "alphabet",      "kernel",
                            "initial", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return closed;
  Result<void> allowed = validate_allowed_edges(node.find("allowed_edges"));
  if (!allowed) return allowed;
  Result<void> constraint =
      validate_alphabet_constraint(node.find("alphabet_constraint"));
  if (!constraint) return constraint;
  Result<const SourceNode*> states_node = required(node, "states");
  if (!states_node) return Result<void>::failure(std::move(states_node.error()));
  Result<std::vector<NormalizedToken>> states = parse_array<NormalizedToken>(
      *states_node.value(), "markov_kernel states",
      [](const SourceNode& item) {
        return parse_normalized_token(item, "state identifier");
      });
  if (!states) return Result<void>::failure(std::move(states.error()));
  if (states.value().empty()) {
    return Result<void>::failure(diagnostic_at(
        *states_node.value(), "model_empty_state_catalog",
        "markov_kernel states must be nonempty"));
  }
  std::map<std::string, ModelProvenance> state_ids;
  for (const NormalizedToken& state : states.value()) {
    Result<void> unique = record_unique_token(state, state_ids, "state-id");
    if (!unique) return unique;
  }
  Result<const SourceNode*> alphabet_node = required(node, "alphabet");
  if (!alphabet_node) return Result<void>::failure(std::move(alphabet_node.error()));
  Result<void> alphabet_array = require_kind(
      *alphabet_node.value(), SourceNodeKind::array, "markov_kernel alphabet");
  if (!alphabet_array) return alphabet_array;
  if (alphabet_node.value()->array_items().empty()) {
    return Result<void>::failure(diagnostic_at(
        *alphabet_node.value(), "model_empty_compatibility_alphabet",
        "markov_kernel alphabet must be nonempty"));
  }
  std::map<std::string, ModelProvenance> mask_ids;
  for (const SourceNode& mask : alphabet_node.value()->array_items()) {
    constexpr std::array mask_keys{"id", "edges"};
    Result<void> mask_closed = exact_keys(mask, mask_keys);
    if (!mask_closed) return mask_closed;
    Result<const SourceNode*> id_node = required(mask, "id");
    if (!id_node) return Result<void>::failure(std::move(id_node.error()));
    Result<NormalizedToken> id =
        parse_normalized_token(*id_node.value(), "mask id");
    if (!id) return Result<void>::failure(std::move(id.error()));
    Result<void> unique = record_unique_token(id.value(), mask_ids, "mask-id");
    if (!unique) return unique;
    Result<const SourceNode*> edges_node = required(mask, "edges");
    if (!edges_node) return Result<void>::failure(std::move(edges_node.error()));
    Result<void> edges = validate_legacy_edges_array(*edges_node.value());
    if (!edges) return edges;
  }
  Result<const SourceNode*> kernel_node = required(node, "kernel");
  if (!kernel_node) return Result<void>::failure(std::move(kernel_node.error()));
  Result<void> kernel_array = require_kind(*kernel_node.value(),
                                           SourceNodeKind::array,
                                           "markov_kernel kernel");
  if (!kernel_array) return kernel_array;
  if (kernel_node.value()->array_items().empty()) {
    return Result<void>::failure(diagnostic_at(
        *kernel_node.value(), "model_empty_kernel",
        "markov_kernel kernel must be nonempty"));
  }
  for (const SourceNode& row : kernel_node.value()->array_items()) {
    Result<void> alias = reject_alias_key(row, "mask", "mask_id");
    if (!alias) return alias;
    constexpr std::array row_keys{"state", "mask_id", "next_state",
                                  "probability"};
    Result<void> row_closed = exact_keys(row, row_keys);
    if (!row_closed) return row_closed;
    for (const std::string_view key : {std::string_view("state"),
                                       std::string_view("mask_id"),
                                       std::string_view("next_state")}) {
      Result<const SourceNode*> token_node = required(row, key);
      if (!token_node)
        return Result<void>::failure(std::move(token_node.error()));
      Result<NormalizedToken> token =
          parse_normalized_token(*token_node.value(), key);
      if (!token) return Result<void>::failure(std::move(token.error()));
    }
    Result<const SourceNode*> probability_node = required(row, "probability");
    if (!probability_node)
      return Result<void>::failure(std::move(probability_node.error()));
    Result<AuthoredProbability> probability =
        parse_probability(*probability_node.value());
    if (!probability)
      return Result<void>::failure(std::move(probability.error()));
  }
  Result<const SourceNode*> initial_node = required(node, "initial");
  if (!initial_node) return Result<void>::failure(std::move(initial_node.error()));
  Result<AuthoredInitialState> initial = parse_initial_state(*initial_node.value());
  if (!initial) return Result<void>::failure(std::move(initial.error()));
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) return Result<void>::failure(std::move(metadata.error()));
  return Result<void>::success();
}

[[nodiscard]] bool parse_override_coordinate_key(const std::string_view key) {
  if (key.size() < 5U || key.front() != '[' || key.back() != ']') return false;
  const std::size_t comma = key.find(',');
  if (comma == std::string_view::npos || comma <= 1U ||
      comma + 1U >= key.size() - 1U || key.find(',', comma + 1U) != std::string_view::npos) {
    return false;
  }
  const auto canonical_nat = [](const std::string_view value) {
    if (value.empty() || (value.size() > 1U && value.front() == '0')) return false;
    return std::all_of(value.begin(), value.end(), [](const char byte) {
      return byte >= '0' && byte <= '9';
    });
  };
  return canonical_nat(key.substr(1U, comma - 1U)) &&
         canonical_nat(key.substr(comma + 1U, key.size() - comma - 2U));
}

[[nodiscard]] Result<void> validate_factorized_bernoulli(
    const SourceNode& node) {
  Result<void> old_default =
      reject_alias_key(node, "lambda_default", "lambda.default");
  if (!old_default) return old_default;
  Result<void> old_overrides =
      reject_alias_key(node, "lambda_overrides", "lambda.overrides");
  if (!old_overrides) return old_overrides;
  constexpr std::array keys{"family", "allowed_edges", "alphabet_constraint",
                            "lambda", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) return closed;
  Result<void> allowed = validate_allowed_edges(node.find("allowed_edges"));
  if (!allowed) return allowed;
  Result<void> constraint = validate_alphabet_constraint(
      node.find("alphabet_constraint"), true);
  if (!constraint) return constraint;
  Result<const SourceNode*> lambda_node = required(node, "lambda");
  if (!lambda_node) return Result<void>::failure(std::move(lambda_node.error()));
  if (lambda_node.value()->kind() == SourceNodeKind::number) {
    return Result<void>::failure(diagnostic_at(
        *lambda_node.value(), "model_noncanonical_alias",
        "a scalar factorized_bernoulli lambda is not canonical",
        {"use {\"default\": value, \"overrides\": {}}"}));
  }
  constexpr std::array lambda_keys{"default", "overrides"};
  Result<void> lambda_closed = exact_keys(*lambda_node.value(), lambda_keys);
  if (!lambda_closed) return lambda_closed;
  Result<const SourceNode*> default_node = required(*lambda_node.value(), "default");
  if (!default_node) return Result<void>::failure(std::move(default_node.error()));
  Result<AuthoredProbability> default_rate = parse_probability(*default_node.value());
  if (!default_rate) return Result<void>::failure(std::move(default_rate.error()));
  const SourceNode* overrides = lambda_node.value()->find("overrides");
  if (overrides != nullptr) {
    Result<void> object = require_kind(*overrides, SourceNodeKind::object,
                                       "lambda.overrides");
    if (!object) return object;
    for (const SourceObjectMember& member : overrides->object_members()) {
      if (!parse_override_coordinate_key(member.key)) {
        return Result<void>::failure(diagnostic_at(
            member.value, "model_noncanonical_override_coordinate",
            "lambda override key must be canonical '[i,j]' with nonnegative integers"));
      }
      Result<AuthoredProbability> rate = parse_probability(member.value);
      if (!rate) return Result<void>::failure(std::move(rate.error()));
    }
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) return Result<void>::failure(std::move(metadata.error()));
  return Result<void>::success();
}

[[nodiscard]] Result<std::vector<LegacyEdgeCoordinate>>
parse_legacy_edges_typed(const SourceNode& node) {
  Result<void> valid = validate_legacy_edges_array(node);
  if (!valid)
    return fail<std::vector<LegacyEdgeCoordinate>>(std::move(valid.error()));
  std::vector<LegacyEdgeCoordinate> edges;
  edges.reserve(node.array_items().size());
  for (const SourceNode& edge : node.array_items()) {
    Result<BigNat> source = parse_natural(edge.array_items()[0]);
    if (!source)
      return fail<std::vector<LegacyEdgeCoordinate>>(std::move(source.error()));
    Result<BigNat> destination = parse_natural(edge.array_items()[1]);
    if (!destination)
      return fail<std::vector<LegacyEdgeCoordinate>>(
          std::move(destination.error()));
    edges.push_back(LegacyEdgeCoordinate{
        {std::move(source.value()),
         authored_provenance(edge.array_items()[0])},
        {std::move(destination.value()),
         authored_provenance(edge.array_items()[1])},
        authored_provenance(edge)});
  }
  return Result<std::vector<LegacyEdgeCoordinate>>::success(std::move(edges));
}

[[nodiscard]] Result<CompatibilityAllowedEdges> parse_allowed_edges_typed(
    const SourceNode& arrival) {
  const SourceNode* node = arrival.find("allowed_edges");
  if (node == nullptr) {
    return Result<CompatibilityAllowedEdges>::success(
        CompatibilityAllowedEdges{
            {AllowedEdgesMode::full,
             defaulted_provenance("/arrival/allowed_edges/mode")},
            {{}, defaulted_provenance("/arrival/allowed_edges/edges")},
            defaulted_provenance("/arrival/allowed_edges")});
  }
  Result<void> valid = validate_allowed_edges(node);
  if (!valid)
    return fail<CompatibilityAllowedEdges>(std::move(valid.error()));
  const SourceNode* mode_node = node->find("mode");
  const std::string mode = *mode_node->string_value();
  AuthoredField<std::vector<LegacyEdgeCoordinate>> edges{
      {}, defaulted_provenance(std::string(node->json_pointer()) + "/edges")};
  if (const SourceNode* edges_node = node->find("edges"); edges_node != nullptr) {
    Result<std::vector<LegacyEdgeCoordinate>> values =
        parse_legacy_edges_typed(*edges_node);
    if (!values)
      return fail<CompatibilityAllowedEdges>(std::move(values.error()));
    edges = {std::move(values.value()), authored_provenance(*edges_node)};
  }
  return Result<CompatibilityAllowedEdges>::success(CompatibilityAllowedEdges{
      {mode == "full" ? AllowedEdgesMode::full
                      : AllowedEdgesMode::explicit_list,
       authored_provenance(*mode_node)},
      std::move(edges), authored_provenance(*node)});
}

[[nodiscard]] Result<AuthoredField<AlphabetConstraintMode>>
parse_alphabet_constraint_typed(const SourceNode& arrival) {
  const SourceNode* node = arrival.find("alphabet_constraint");
  if (node == nullptr) {
    return Result<AuthoredField<AlphabetConstraintMode>>::success(
        {AlphabetConstraintMode::unrestricted,
         defaulted_provenance("/arrival/alphabet_constraint")});
  }
  Result<void> valid = validate_alphabet_constraint(node);
  if (!valid)
    return fail<AuthoredField<AlphabetConstraintMode>>(std::move(valid.error()));
  const std::string& value = *node->string_value();
  AlphabetConstraintMode mode = AlphabetConstraintMode::unrestricted;
  if (value == "per_input_line_rate") {
    mode = AlphabetConstraintMode::per_input_line_rate;
  } else if (value == "global_one_hot") {
    mode = AlphabetConstraintMode::global_one_hot;
  }
  return Result<AuthoredField<AlphabetConstraintMode>>::success(
      {mode, authored_provenance(*node)});
}

[[nodiscard]] Result<CompatibilityArrivalCommon> parse_compatibility_common(
    const SourceNode& node) {
  Result<CompatibilityAllowedEdges> allowed = parse_allowed_edges_typed(node);
  if (!allowed)
    return fail<CompatibilityArrivalCommon>(std::move(allowed.error()));
  Result<AuthoredField<AlphabetConstraintMode>> alphabet =
      parse_alphabet_constraint_typed(node);
  if (!alphabet)
    return fail<CompatibilityArrivalCommon>(std::move(alphabet.error()));
  return Result<CompatibilityArrivalCommon>::success(
      CompatibilityArrivalCommon{std::move(allowed.value()),
                                 std::move(alphabet.value())});
}

[[nodiscard]] Result<IidTableCompatibilityArrival> parse_iid_table_typed(
    const SourceNode& node) {
  Result<void> valid = validate_iid_table(node);
  if (!valid)
    return fail<IidTableCompatibilityArrival>(std::move(valid.error()));
  Result<CompatibilityArrivalCommon> common = parse_compatibility_common(node);
  if (!common)
    return fail<IidTableCompatibilityArrival>(std::move(common.error()));
  const SourceNode* alphabet_node = node.find("alphabet");
  std::vector<IidTableAtom> atoms;
  atoms.reserve(alphabet_node->array_items().size());
  for (const SourceNode& atom : alphabet_node->array_items()) {
    AuthoredField<std::optional<NormalizedToken>> id{
        std::nullopt, defaulted_provenance(
                          std::string(atom.json_pointer()) + "/id")};
    if (const SourceNode* id_node = atom.find("id"); id_node != nullptr) {
      Result<NormalizedToken> value =
          parse_normalized_token(*id_node, "alphabet id");
      if (!value)
        return fail<IidTableCompatibilityArrival>(std::move(value.error()));
      id = {std::move(value.value()), authored_provenance(*id_node)};
    }
    const SourceNode* edges_node = atom.find("edges");
    Result<std::vector<LegacyEdgeCoordinate>> edges =
        parse_legacy_edges_typed(*edges_node);
    if (!edges)
      return fail<IidTableCompatibilityArrival>(std::move(edges.error()));
    const SourceNode* probability_node = atom.find("probability");
    Result<AuthoredProbability> probability =
        parse_probability(*probability_node);
    if (!probability)
      return fail<IidTableCompatibilityArrival>(std::move(probability.error()));
    atoms.push_back(IidTableAtom{
        std::move(id),
        {std::move(edges.value()), authored_provenance(*edges_node)},
        {std::move(probability.value()),
         authored_provenance(*probability_node)},
        authored_provenance(atom)});
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<IidTableCompatibilityArrival>(std::move(metadata.error()));
  return Result<IidTableCompatibilityArrival>::success(
      IidTableCompatibilityArrival{
          std::move(common.value()),
          {std::move(atoms), authored_provenance(*alphabet_node)},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<MarkovKernelCompatibilityArrival>
parse_markov_kernel_typed(const SourceNode& node) {
  Result<void> valid = validate_markov_kernel(node);
  if (!valid)
    return fail<MarkovKernelCompatibilityArrival>(std::move(valid.error()));
  Result<CompatibilityArrivalCommon> common = parse_compatibility_common(node);
  if (!common)
    return fail<MarkovKernelCompatibilityArrival>(std::move(common.error()));
  const SourceNode* states_node = node.find("states");
  Result<std::vector<NormalizedToken>> states = parse_array<NormalizedToken>(
      *states_node, "markov_kernel states", [](const SourceNode& item) {
        return parse_normalized_token(item, "state identifier");
      });
  if (!states)
    return fail<MarkovKernelCompatibilityArrival>(std::move(states.error()));
  const SourceNode* alphabet_node = node.find("alphabet");
  std::vector<MarkovKernelMask> masks;
  masks.reserve(alphabet_node->array_items().size());
  for (const SourceNode& mask : alphabet_node->array_items()) {
    const SourceNode* id_node = mask.find("id");
    Result<NormalizedToken> id =
        parse_normalized_token(*id_node, "mask id");
    if (!id)
      return fail<MarkovKernelCompatibilityArrival>(std::move(id.error()));
    const SourceNode* edges_node = mask.find("edges");
    Result<std::vector<LegacyEdgeCoordinate>> edges =
        parse_legacy_edges_typed(*edges_node);
    if (!edges)
      return fail<MarkovKernelCompatibilityArrival>(std::move(edges.error()));
    masks.push_back(MarkovKernelMask{
        std::move(id.value()),
        {std::move(edges.value()), authored_provenance(*edges_node)},
        authored_provenance(mask)});
  }
  const SourceNode* kernel_node = node.find("kernel");
  std::vector<MarkovKernelRow> rows;
  rows.reserve(kernel_node->array_items().size());
  for (const SourceNode& row : kernel_node->array_items()) {
    const SourceNode* state_node = row.find("state");
    Result<NormalizedToken> state =
        parse_normalized_token(*state_node, "state identifier");
    if (!state)
      return fail<MarkovKernelCompatibilityArrival>(std::move(state.error()));
    const SourceNode* mask_node = row.find("mask_id");
    Result<NormalizedToken> mask =
        parse_normalized_token(*mask_node, "mask id");
    if (!mask)
      return fail<MarkovKernelCompatibilityArrival>(std::move(mask.error()));
    const SourceNode* next_node = row.find("next_state");
    Result<NormalizedToken> next =
        parse_normalized_token(*next_node, "next-state identifier");
    if (!next)
      return fail<MarkovKernelCompatibilityArrival>(std::move(next.error()));
    const SourceNode* probability_node = row.find("probability");
    Result<AuthoredProbability> probability =
        parse_probability(*probability_node);
    if (!probability)
      return fail<MarkovKernelCompatibilityArrival>(
          std::move(probability.error()));
    rows.push_back(MarkovKernelRow{
        std::move(state.value()), std::move(mask.value()),
        std::move(next.value()),
        {std::move(probability.value()),
         authored_provenance(*probability_node)},
        authored_provenance(row)});
  }
  const SourceNode* initial_node = node.find("initial");
  Result<AuthoredInitialState> initial = parse_initial_state(*initial_node);
  if (!initial)
    return fail<MarkovKernelCompatibilityArrival>(std::move(initial.error()));
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<MarkovKernelCompatibilityArrival>(std::move(metadata.error()));
  return Result<MarkovKernelCompatibilityArrival>::success(
      MarkovKernelCompatibilityArrival{
          std::move(common.value()),
          {std::move(states.value()), authored_provenance(*states_node)},
          {std::move(masks), authored_provenance(*alphabet_node)},
          {std::move(rows), authored_provenance(*kernel_node)},
          {std::move(initial.value()), authored_provenance(*initial_node)},
          std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<FactorizedBernoulliCompatibilityArrival>
parse_factorized_bernoulli_typed(const SourceNode& node) {
  Result<void> valid = validate_factorized_bernoulli(node);
  if (!valid)
    return fail<FactorizedBernoulliCompatibilityArrival>(
        std::move(valid.error()));
  Result<CompatibilityArrivalCommon> common = parse_compatibility_common(node);
  if (!common)
    return fail<FactorizedBernoulliCompatibilityArrival>(
        std::move(common.error()));
  const SourceNode* lambda_node = node.find("lambda");
  const SourceNode* default_node = lambda_node->find("default");
  Result<AuthoredProbability> default_probability =
      parse_probability(*default_node);
  if (!default_probability)
    return fail<FactorizedBernoulliCompatibilityArrival>(
        std::move(default_probability.error()));
  AuthoredField<std::vector<BernoulliOverride>> overrides{
      {}, defaulted_provenance(std::string(lambda_node->json_pointer()) +
                               "/overrides")};
  if (const SourceNode* overrides_node = lambda_node->find("overrides");
      overrides_node != nullptr) {
    std::vector<BernoulliOverride> values;
    values.reserve(overrides_node->object_members().size());
    for (const SourceObjectMember& member : overrides_node->object_members()) {
      const std::size_t comma = member.key.find(',');
      Result<BigNat> source = parse_exact_nonnegative_integer(
          JsonNumber(member.key.substr(1U, comma - 1U)),
          BoundPolicy::unbounded());
      Result<BigNat> destination = parse_exact_nonnegative_integer(
          JsonNumber(member.key.substr(
              comma + 1U, member.key.size() - comma - 2U)),
          BoundPolicy::unbounded());
      if (!source || !destination) {
        return fail<FactorizedBernoulliCompatibilityArrival>(diagnostic_at(
            member.value, "model_invalid_override_coordinate",
            "validated override coordinate failed exact integer conversion"));
      }
      Result<AuthoredProbability> probability =
          parse_probability(member.value);
      if (!probability)
        return fail<FactorizedBernoulliCompatibilityArrival>(
            std::move(probability.error()));
      values.push_back(BernoulliOverride{
          {std::move(source.value()), authored_provenance(member.value)},
          {std::move(destination.value()), authored_provenance(member.value)},
          {std::move(probability.value()), authored_provenance(member.value)},
          authored_provenance(member.value)});
    }
    overrides = {std::move(values), authored_provenance(*overrides_node)};
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata)
    return fail<FactorizedBernoulliCompatibilityArrival>(
        std::move(metadata.error()));
  return Result<FactorizedBernoulliCompatibilityArrival>::success(
      FactorizedBernoulliCompatibilityArrival{
          std::move(common.value()),
          {std::move(default_probability.value()),
           authored_provenance(*default_node)},
          std::move(overrides), std::move(metadata.value()),
          authored_provenance(node)});
}

[[nodiscard]] Result<ExactRational> parse_schema4_rate(
    const SourceNode& node, const bool bounded_probability) {
  if (bounded_probability) {
    Result<AuthoredProbability> probability = parse_probability(node);
    if (!probability) {
      return fail<ExactRational>(std::move(probability.error()));
    }
    return Result<ExactRational>::success(
        probability.value().exact_value());
  }
  return parse_nonnegative_rational(node, "Poisson rate");
}

[[nodiscard]] Result<ExactQueueRates> parse_schema4_rates(
    const SourceNode& arrival, const bool bounded_probability) {
  Result<const SourceNode*> rates_node = required(arrival, "rates");
  if (!rates_node) {
    return fail<ExactQueueRates>(std::move(rates_node.error()));
  }
  constexpr std::array rate_keys{"default", "overrides"};
  Result<void> rates_closed = exact_keys(*rates_node.value(), rate_keys);
  if (!rates_closed) {
    return fail<ExactQueueRates>(std::move(rates_closed.error()));
  }
  Result<const SourceNode*> default_node =
      required(*rates_node.value(), "default");
  if (!default_node) {
    return fail<ExactQueueRates>(std::move(default_node.error()));
  }
  Result<ExactRational> default_rate =
      parse_schema4_rate(*default_node.value(), bounded_probability);
  if (!default_rate) {
    return fail<ExactQueueRates>(std::move(default_rate.error()));
  }

  Result<const SourceNode*> overrides_node =
      required(*rates_node.value(), "overrides");
  if (!overrides_node) {
    return fail<ExactQueueRates>(std::move(overrides_node.error()));
  }
  Result<void> overrides_array = require_kind(
      *overrides_node.value(), SourceNodeKind::array, "arrival.rates.overrides");
  if (!overrides_array) {
    return fail<ExactQueueRates>(std::move(overrides_array.error()));
  }

  std::vector<QueueRateOverride> overrides;
  overrides.reserve(overrides_node.value()->array_items().size());
  std::vector<QueueId> seen;
  seen.reserve(overrides_node.value()->array_items().size());
  for (const SourceNode& item : overrides_node.value()->array_items()) {
    constexpr std::array override_keys{"queue_id", "rate"};
    Result<void> item_closed = exact_keys(item, override_keys);
    if (!item_closed) {
      return fail<ExactQueueRates>(std::move(item_closed.error()));
    }
    Result<const SourceNode*> queue_node = required(item, "queue_id");
    if (!queue_node) {
      return fail<ExactQueueRates>(std::move(queue_node.error()));
    }
    Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
    if (!queue) {
      return fail<ExactQueueRates>(std::move(queue.error()));
    }
    if (std::find(seen.begin(), seen.end(), queue.value()) != seen.end()) {
      return fail<ExactQueueRates>(diagnostic_at(
          *queue_node.value(), "model_duplicate_rate_override",
          "arrival.rates may override each typed queue ID at most once"));
    }
    seen.push_back(queue.value());

    Result<const SourceNode*> rate_node = required(item, "rate");
    if (!rate_node) {
      return fail<ExactQueueRates>(std::move(rate_node.error()));
    }
    Result<ExactRational> rate =
        parse_schema4_rate(*rate_node.value(), bounded_probability);
    if (!rate) {
      return fail<ExactQueueRates>(std::move(rate.error()));
    }
    overrides.push_back(QueueRateOverride{
        {std::move(queue.value()), authored_provenance(*queue_node.value())},
        {std::move(rate.value()), authored_provenance(*rate_node.value())},
        authored_provenance(item)});
  }

  return Result<ExactQueueRates>::success(ExactQueueRates{
      {std::move(default_rate.value()),
       authored_provenance(*default_node.value())},
      {std::move(overrides), authored_provenance(*overrides_node.value())},
      authored_provenance(*rates_node.value())});
}

[[nodiscard]] Result<IidIndependentBernoulliArrival>
parse_iid_independent_bernoulli(const SourceNode& node) {
  constexpr std::array keys{"family", "rates", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<IidIndependentBernoulliArrival>(std::move(closed.error()));
  }
  Result<ExactQueueRates> rates = parse_schema4_rates(node, true);
  if (!rates) {
    return fail<IidIndependentBernoulliArrival>(std::move(rates.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) {
    return fail<IidIndependentBernoulliArrival>(std::move(metadata.error()));
  }
  return Result<IidIndependentBernoulliArrival>::success(
      IidIndependentBernoulliArrival{std::move(rates.value()),
                                     std::move(metadata.value()),
                                     authored_provenance(node)});
}

[[nodiscard]] Result<IidCountEntry> parse_iid_count_entry(
    const SourceNode& node) {
  constexpr std::array keys{"queue_id", "count"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<IidCountEntry>(std::move(closed.error()));
  }
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node) {
    return fail<IidCountEntry>(std::move(queue_node.error()));
  }
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) {
    return fail<IidCountEntry>(std::move(queue.error()));
  }
  Result<const SourceNode*> count_node = required(node, "count");
  if (!count_node) {
    return fail<IidCountEntry>(std::move(count_node.error()));
  }
  Result<BigNat> count = parse_positive_natural(
      *count_node.value(), bounded_by(static_cast<std::uint64_t>(
                               std::numeric_limits<std::uint64_t>::max())));
  if (!count) {
    return fail<IidCountEntry>(std::move(count.error()));
  }
  return Result<IidCountEntry>::success(IidCountEntry{
      {std::move(queue.value()), authored_provenance(*queue_node.value())},
      {std::move(count.value()), authored_provenance(*count_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<IidCountTableArrival> parse_iid_count_table(
    const SourceNode& node) {
  constexpr std::array keys{"family", "outcomes", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<IidCountTableArrival>(std::move(closed.error()));
  }
  Result<const SourceNode*> outcomes_node = required(node, "outcomes");
  if (!outcomes_node) {
    return fail<IidCountTableArrival>(std::move(outcomes_node.error()));
  }
  Result<void> outcomes_array = require_kind(
      *outcomes_node.value(), SourceNodeKind::array, "arrival.outcomes");
  if (!outcomes_array) {
    return fail<IidCountTableArrival>(std::move(outcomes_array.error()));
  }
  if (outcomes_node.value()->array_items().empty()) {
    return fail<IidCountTableArrival>(diagnostic_at(
        *outcomes_node.value(), "model_empty_iid_count_table",
        "iid_count_table requires at least one ordered outcome"));
  }

  std::vector<IidCountOutcome> outcomes;
  outcomes.reserve(outcomes_node.value()->array_items().size());
  std::map<std::string, ModelProvenance> seen_ids;
  ExactRational probability_sum = ExactRational::zero();
  for (const SourceNode& outcome_node : outcomes_node.value()->array_items()) {
    constexpr std::array outcome_keys{"id", "probability", "counts"};
    Result<void> outcome_closed = exact_keys(outcome_node, outcome_keys);
    if (!outcome_closed) {
      return fail<IidCountTableArrival>(std::move(outcome_closed.error()));
    }
    Result<const SourceNode*> id_node = required(outcome_node, "id");
    if (!id_node) {
      return fail<IidCountTableArrival>(std::move(id_node.error()));
    }
    Result<NormalizedToken> id =
        parse_normalized_token(*id_node.value(), "iid_count_table outcome id");
    if (!id) {
      return fail<IidCountTableArrival>(std::move(id.error()));
    }
    Result<void> unique_id =
        record_unique_token(id.value(), seen_ids, "iid_count_table outcome");
    if (!unique_id) {
      return fail<IidCountTableArrival>(std::move(unique_id.error()));
    }

    Result<const SourceNode*> probability_node =
        required(outcome_node, "probability");
    if (!probability_node) {
      return fail<IidCountTableArrival>(std::move(probability_node.error()));
    }
    Result<AuthoredProbability> probability =
        parse_probability(*probability_node.value(), true);
    if (!probability) {
      return fail<IidCountTableArrival>(std::move(probability.error()));
    }
    probability_sum = probability_sum + probability.value().exact_value();

    Result<const SourceNode*> counts_node = required(outcome_node, "counts");
    if (!counts_node) {
      return fail<IidCountTableArrival>(std::move(counts_node.error()));
    }
    Result<std::vector<IidCountEntry>> counts = parse_array<IidCountEntry>(
        *counts_node.value(), "iid_count_table outcome counts",
        parse_iid_count_entry);
    if (!counts) {
      return fail<IidCountTableArrival>(std::move(counts.error()));
    }
    std::vector<QueueId> seen_queues;
    seen_queues.reserve(counts.value().size());
    for (const IidCountEntry& count : counts.value()) {
      if (std::find(seen_queues.begin(), seen_queues.end(),
                    count.queue_id.value) != seen_queues.end()) {
        return fail<IidCountTableArrival>(diagnostic_at(
            outcome_node, "model_duplicate_iid_count_queue",
            "an iid_count_table outcome may name each typed queue ID at most once"));
      }
      seen_queues.push_back(count.queue_id.value);
    }
    outcomes.push_back(IidCountOutcome{
        std::move(id.value()),
        {std::move(probability.value()),
         authored_provenance(*probability_node.value())},
        {std::move(counts.value()), authored_provenance(*counts_node.value())},
        authored_provenance(outcome_node)});
  }
  if (!(probability_sum == ExactRational::one())) {
    return fail<IidCountTableArrival>(diagnostic_at(
        *outcomes_node.value(), "model_iid_count_probability_sum",
        "iid_count_table outcome probabilities must sum exactly to one",
        {"exact sum was " + probability_sum.to_canonical_string()}));
  }

  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) {
    return fail<IidCountTableArrival>(std::move(metadata.error()));
  }
  return Result<IidCountTableArrival>::success(IidCountTableArrival{
      {std::move(outcomes), authored_provenance(*outcomes_node.value())},
      std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<IidIndependentPoissonArrival>
parse_iid_independent_poisson(const SourceNode& node) {
  constexpr std::array keys{"family", "rates", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<IidIndependentPoissonArrival>(std::move(closed.error()));
  }
  Result<ExactQueueRates> rates = parse_schema4_rates(node, false);
  if (!rates) {
    return fail<IidIndependentPoissonArrival>(std::move(rates.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) {
    return fail<IidIndependentPoissonArrival>(std::move(metadata.error()));
  }
  return Result<IidIndependentPoissonArrival>::success(
      IidIndependentPoissonArrival{std::move(rates.value()),
                                   std::move(metadata.value()),
                                   authored_provenance(node)});
}

[[nodiscard]] Result<MixedPoissonState> parse_mixed_poisson_state(
    const SourceNode& node) {
  constexpr std::array keys{"id", "probability", "multiplier"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<MixedPoissonState>(std::move(closed.error()));
  }
  Result<const SourceNode*> id_node = required(node, "id");
  if (!id_node) {
    return fail<MixedPoissonState>(std::move(id_node.error()));
  }
  Result<NormalizedToken> id =
      parse_normalized_token(*id_node.value(), "mixed-Poisson state id");
  if (!id) {
    return fail<MixedPoissonState>(std::move(id.error()));
  }
  Result<const SourceNode*> probability_node = required(node, "probability");
  if (!probability_node) {
    return fail<MixedPoissonState>(std::move(probability_node.error()));
  }
  Result<AuthoredProbability> probability =
      parse_probability(*probability_node.value());
  if (!probability) {
    return fail<MixedPoissonState>(std::move(probability.error()));
  }
  Result<const SourceNode*> multiplier_node = required(node, "multiplier");
  if (!multiplier_node) {
    return fail<MixedPoissonState>(std::move(multiplier_node.error()));
  }
  Result<ExactRational> multiplier = parse_nonnegative_rational(
      *multiplier_node.value(), "mixed-Poisson multiplier");
  if (!multiplier) {
    return fail<MixedPoissonState>(std::move(multiplier.error()));
  }
  return Result<MixedPoissonState>::success(MixedPoissonState{
      std::move(id.value()),
      {std::move(probability.value()),
       authored_provenance(*probability_node.value())},
      {std::move(multiplier.value()),
       authored_provenance(*multiplier_node.value())},
      authored_provenance(node)});
}

[[nodiscard]] Result<MixedPoissonModulation> parse_mixed_poisson_modulation(
    const SourceNode& node) {
  constexpr std::array keys{"scope", "states", "mean_multiplier",
                            "second_moment_multiplier"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<MixedPoissonModulation>(std::move(closed.error()));
  }
  Result<const SourceNode*> scope_node = required(node, "scope");
  if (!scope_node) {
    return fail<MixedPoissonModulation>(std::move(scope_node.error()));
  }
  Result<std::string> scope_text =
      parse_string(*scope_node.value(), "mixed-Poisson modulation.scope");
  if (!scope_text) {
    return fail<MixedPoissonModulation>(std::move(scope_text.error()));
  }
  MixedPoissonScope scope;
  if (scope_text.value() == "shared") {
    scope = MixedPoissonScope::shared;
  } else if (scope_text.value() == "independent_queue") {
    scope = MixedPoissonScope::independent_queue;
  } else {
    return fail<MixedPoissonModulation>(diagnostic_at(
        *scope_node.value(), "model_mixed_poisson_scope_invalid",
        "mixed-Poisson scope must be 'shared' or 'independent_queue'"));
  }

  Result<const SourceNode*> states_node = required(node, "states");
  if (!states_node) {
    return fail<MixedPoissonModulation>(std::move(states_node.error()));
  }
  Result<std::vector<MixedPoissonState>> states =
      parse_array<MixedPoissonState>(*states_node.value(),
                                     "mixed-Poisson modulation states",
                                     parse_mixed_poisson_state);
  if (!states) {
    return fail<MixedPoissonModulation>(std::move(states.error()));
  }
  if (states.value().empty()) {
    return fail<MixedPoissonModulation>(diagnostic_at(
        *states_node.value(), "model_empty_mixed_poisson_states",
        "mixed-Poisson modulation requires at least one ordered state"));
  }

  std::map<std::string, ModelProvenance> seen_ids;
  ExactRational probability_sum = ExactRational::zero();
  ExactRational mean = ExactRational::zero();
  ExactRational second = ExactRational::zero();
  for (const MixedPoissonState& state : states.value()) {
    Result<void> unique =
        record_unique_token(state.id, seen_ids, "mixed-Poisson state");
    if (!unique) {
      return fail<MixedPoissonModulation>(std::move(unique.error()));
    }
    const ExactRational& probability = state.probability.value.exact_value();
    probability_sum = probability_sum + probability;
    mean = mean + probability * state.multiplier.value;
    second = second + probability * state.multiplier.value *
                          state.multiplier.value;
  }
  if (!(probability_sum == ExactRational::one())) {
    return fail<MixedPoissonModulation>(diagnostic_at(
        *states_node.value(), "model_mixed_poisson_probability_sum",
        "mixed-Poisson state probabilities must sum exactly to one",
        {"exact sum was " + probability_sum.to_canonical_string()}));
  }
  if (!(mean == ExactRational::one())) {
    return fail<MixedPoissonModulation>(diagnostic_at(
        *states_node.value(), "model_mixed_poisson_mean_multiplier",
        "mixed-Poisson multiplier mean must equal exactly one",
        {"exact mean was " + mean.to_canonical_string()}));
  }

  const auto parse_declared_moment =
      [&](const std::string_view key, const ExactRational& derived)
      -> Result<AuthoredField<ExactRational>> {
    const SourceNode* value = node.find(key);
    if (value == nullptr) {
      return Result<AuthoredField<ExactRational>>::success(
          {derived, defaulted_provenance(std::string(node.json_pointer()) +
                                         "/" + std::string(key))});
    }
    Result<ExactRational> parsed =
        parse_nonnegative_rational(*value, key);
    if (!parsed) {
      return fail<AuthoredField<ExactRational>>(std::move(parsed.error()));
    }
    if (!(parsed.value() == derived)) {
      return fail<AuthoredField<ExactRational>>(diagnostic_at(
          *value, "model_mixed_poisson_declared_moment_mismatch",
          std::string(key) + " does not equal the exact derived value",
          {"derived value is " + derived.to_canonical_string()}));
    }
    return Result<AuthoredField<ExactRational>>::success(
        {std::move(parsed.value()), authored_provenance(*value)});
  };
  Result<AuthoredField<ExactRational>> declared_mean =
      parse_declared_moment("mean_multiplier", mean);
  if (!declared_mean) {
    return fail<MixedPoissonModulation>(std::move(declared_mean.error()));
  }
  Result<AuthoredField<ExactRational>> declared_second =
      parse_declared_moment("second_moment_multiplier", second);
  if (!declared_second) {
    return fail<MixedPoissonModulation>(std::move(declared_second.error()));
  }
  return Result<MixedPoissonModulation>::success(MixedPoissonModulation{
      {scope, authored_provenance(*scope_node.value())},
      {std::move(states.value()), authored_provenance(*states_node.value())},
      std::move(declared_mean.value()), std::move(declared_second.value()),
      authored_provenance(node)});
}

[[nodiscard]] Result<IidMixedPoissonArrival> parse_iid_mixed_poisson(
    const SourceNode& node) {
  constexpr std::array keys{"family", "rates", "modulation", "metadata"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<IidMixedPoissonArrival>(std::move(closed.error()));
  }
  Result<ExactQueueRates> rates = parse_schema4_rates(node, false);
  if (!rates) {
    return fail<IidMixedPoissonArrival>(std::move(rates.error()));
  }
  Result<const SourceNode*> modulation_node = required(node, "modulation");
  if (!modulation_node) {
    return fail<IidMixedPoissonArrival>(std::move(modulation_node.error()));
  }
  Result<MixedPoissonModulation> modulation =
      parse_mixed_poisson_modulation(*modulation_node.value());
  if (!modulation) {
    return fail<IidMixedPoissonArrival>(std::move(modulation.error()));
  }
  Result<AuthoredMetadata> metadata = parse_metadata(node, "/arrival/metadata");
  if (!metadata) {
    return fail<IidMixedPoissonArrival>(std::move(metadata.error()));
  }
  return Result<IidMixedPoissonArrival>::success(IidMixedPoissonArrival{
      std::move(rates.value()), std::move(modulation.value()),
      std::move(metadata.value()), authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredArrivalConfig> parse_arrival(
    const SourceNode& node, const PhysicalSchemaDialect dialect) {
  Result<void> object = require_kind(node, SourceNodeKind::object, "arrival");
  if (!object) return fail<AuthoredArrivalConfig>(std::move(object.error()));
  for (const auto& [alias, replacement] :
       std::array<std::pair<std::string_view, std::string_view>, 4>{
           {{"mean_rate", "a registered family parameter"},
            {"persistence", "a registered family parameter"},
            {"parameterization", "the selected family's canonical fields"},
            {"init", "initial"}}}) {
    Result<void> canonical = reject_alias_key(node, alias, replacement);
    if (!canonical) return fail<AuthoredArrivalConfig>(std::move(canonical.error()));
  }
  // This is only the union of keys belonging to the closed preferred and
  // compatibility alternatives.  The selected family still receives its
  // narrower exact-key validation below.
  constexpr std::array v3_union_keys{
      "family", "events", "metadata", "period", "phase", "sources",
      "states", "initial", "outcomes", "allowed_edges",
      "alphabet_constraint", "alphabet", "kernel", "lambda"};
  constexpr std::array v4_union_keys{
      "family", "events", "metadata", "period", "phase", "sources",
      "states", "initial", "outcomes", "allowed_edges",
      "alphabet_constraint", "alphabet", "kernel", "lambda", "rates",
      "modulation"};
  Result<void> union_closed = dialect == PhysicalSchemaDialect::v4
                                  ? exact_keys(node, v4_union_keys)
                                  : exact_keys(node, v3_union_keys);
  if (!union_closed) {
    return fail<AuthoredArrivalConfig>(std::move(union_closed.error()));
  }
  Result<const SourceNode*> family_node = required(node, "family");
  if (!family_node) return fail<AuthoredArrivalConfig>(std::move(family_node.error()));
  Result<std::string> family =
      parse_string(*family_node.value(), "arrival.family");
  if (!family) return fail<AuthoredArrivalConfig>(std::move(family.error()));
  if (family.value() == "bernoulli") {
    Result<void> alias = reject_tag_alias(*family_node.value(), family.value(),
                                         "factorized_bernoulli");
    return fail<AuthoredArrivalConfig>(std::move(alias.error()));
  }
  if (family.value() == "markov_onoff") {
    Result<void> alias = reject_tag_alias(*family_node.value(), family.value(),
                                         "markov_kernel");
    return fail<AuthoredArrivalConfig>(std::move(alias.error()));
  }

  if (family.value() == "deterministic_trace") {
    Result<DeterministicTraceArrival> value = parse_trace_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (family.value() == "periodic_global_phase") {
    Result<PeriodicGlobalPhaseArrival> value = parse_global_phase_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (family.value() == "periodic_source_delays") {
    Result<PeriodicSourceDelaysArrival> value = parse_delays_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (family.value() == "independent_marked_renewal") {
    Result<IndependentMarkedRenewalArrival> value = parse_marked_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (family.value() == "independent_private_markov_renewal") {
    Result<IndependentPrivateMarkovRenewalArrival> value =
        parse_private_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (family.value() == "shared_joint_round_markov_renewal") {
    Result<SharedJointRoundMarkovRenewalArrival> value =
        parse_shared_arrival(node);
    if (!value) return fail<AuthoredArrivalConfig>(std::move(value.error()));
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }

  if (dialect == PhysicalSchemaDialect::v4 &&
      family.value() == "iid_independent_bernoulli") {
    Result<IidIndependentBernoulliArrival> value =
        parse_iid_independent_bernoulli(node);
    if (!value) {
      return fail<AuthoredArrivalConfig>(std::move(value.error()));
    }
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (dialect == PhysicalSchemaDialect::v4 &&
      family.value() == "iid_count_table") {
    Result<IidCountTableArrival> value = parse_iid_count_table(node);
    if (!value) {
      return fail<AuthoredArrivalConfig>(std::move(value.error()));
    }
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (dialect == PhysicalSchemaDialect::v4 &&
      family.value() == "iid_independent_poisson") {
    Result<IidIndependentPoissonArrival> value =
        parse_iid_independent_poisson(node);
    if (!value) {
      return fail<AuthoredArrivalConfig>(std::move(value.error()));
    }
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }
  if (dialect == PhysicalSchemaDialect::v4 &&
      family.value() == "iid_mixed_poisson") {
    Result<IidMixedPoissonArrival> value = parse_iid_mixed_poisson(node);
    if (!value) {
      return fail<AuthoredArrivalConfig>(std::move(value.error()));
    }
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value.value()), authored_provenance(node)});
  }

  if (family.value() == "iid_table") {
    Result<IidTableCompatibilityArrival> payload = parse_iid_table_typed(node);
    if (!payload)
      return fail<AuthoredArrivalConfig>(std::move(payload.error()));
    UnsupportedCompatibilityArrival value{
        CompatibilityArrivalKind::iid_table, std::move(payload.value()), node,
        authored_provenance(node)};
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value), authored_provenance(node)});
  }
  if (family.value() == "markov_kernel") {
    Result<MarkovKernelCompatibilityArrival> payload =
        parse_markov_kernel_typed(node);
    if (!payload)
      return fail<AuthoredArrivalConfig>(std::move(payload.error()));
    UnsupportedCompatibilityArrival value{
        CompatibilityArrivalKind::markov_kernel, std::move(payload.value()),
        node, authored_provenance(node)};
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value), authored_provenance(node)});
  }
  if (family.value() == "factorized_bernoulli") {
    Result<FactorizedBernoulliCompatibilityArrival> payload =
        parse_factorized_bernoulli_typed(node);
    if (!payload)
      return fail<AuthoredArrivalConfig>(std::move(payload.error()));
    UnsupportedCompatibilityArrival value{
        CompatibilityArrivalKind::factorized_bernoulli,
        std::move(payload.value()), node, authored_provenance(node)};
    return Result<AuthoredArrivalConfig>::success(
        {std::move(value), authored_provenance(node)});
  }
  return fail<AuthoredArrivalConfig>(diagnostic_at(
      *family_node.value(), "model_unknown_arrival_family",
      "arrival.family is not a registered canonical arrival tag"));
}

[[nodiscard]] AuthoredObservationTelemetry default_observation_telemetry() {
  return AuthoredObservationTelemetry{
      {false, defaulted_provenance("/telemetry/observation/enabled")},
      {std::nullopt,
       defaulted_provenance("/telemetry/observation/block_slots")},
      {{}, defaulted_provenance("/telemetry/observation/targets")},
      defaulted_provenance("/telemetry/observation")};
}

[[nodiscard]] Result<AuthoredObservationTarget> parse_observation_target(
    const SourceNode& node) {
  constexpr std::array keys{"queue_id", "gap"};
  Result<void> closed = exact_keys(node, keys);
  if (!closed) {
    return fail<AuthoredObservationTarget>(std::move(closed.error()));
  }
  Result<const SourceNode*> queue_node = required(node, "queue_id");
  if (!queue_node) {
    return fail<AuthoredObservationTarget>(std::move(queue_node.error()));
  }
  Result<QueueId> queue = parse_id<QueueId>(*queue_node.value());
  if (!queue) {
    return fail<AuthoredObservationTarget>(std::move(queue.error()));
  }
  Result<const SourceNode*> gap_node = required(node, "gap");
  if (!gap_node) {
    return fail<AuthoredObservationTarget>(std::move(gap_node.error()));
  }
  Result<std::string> gap_text =
      parse_string(*gap_node.value(), "telemetry.observation target gap");
  if (!gap_text) {
    return fail<AuthoredObservationTarget>(std::move(gap_text.error()));
  }
  ObservationGapMode gap;
  if (gap_text.value() == "none") {
    gap = ObservationGapMode::none;
  } else if (gap_text.value() == "exact") {
    gap = ObservationGapMode::exact;
  } else {
    return fail<AuthoredObservationTarget>(diagnostic_at(
        *gap_node.value(), "model_observation_gap_invalid",
        "telemetry.observation target gap must be 'none' or 'exact'"));
  }
  return Result<AuthoredObservationTarget>::success(
      AuthoredObservationTarget{
          {std::move(queue.value()), authored_provenance(*queue_node.value())},
          {gap, authored_provenance(*gap_node.value())},
          authored_provenance(node)});
}

[[nodiscard]] Result<AuthoredObservationTelemetry> parse_observation_telemetry(
    const SourceNode* node) {
  if (node == nullptr) {
    return Result<AuthoredObservationTelemetry>::success(
        default_observation_telemetry());
  }
  constexpr std::array keys{"enabled", "block_slots", "targets"};
  Result<void> closed = exact_keys(*node, keys);
  if (!closed) {
    return fail<AuthoredObservationTelemetry>(std::move(closed.error()));
  }
  Result<const SourceNode*> enabled_node = required(*node, "enabled");
  if (!enabled_node) {
    return fail<AuthoredObservationTelemetry>(std::move(enabled_node.error()));
  }
  Result<bool> enabled =
      parse_boolean(*enabled_node.value(), "telemetry.observation.enabled");
  if (!enabled) {
    return fail<AuthoredObservationTelemetry>(std::move(enabled.error()));
  }

  Result<const SourceNode*> block_node = required(*node, "block_slots");
  if (!block_node) {
    return fail<AuthoredObservationTelemetry>(std::move(block_node.error()));
  }
  AuthoredField<std::optional<BigNat>> block_slots{
      std::nullopt, authored_provenance(*block_node.value())};
  if (block_node.value()->kind() != SourceNodeKind::null_value) {
    Result<BigNat> parsed = parse_positive_natural(*block_node.value());
    if (!parsed) {
      return fail<AuthoredObservationTelemetry>(std::move(parsed.error()));
    }
    block_slots.value = std::move(parsed.value());
  }

  Result<const SourceNode*> targets_node = required(*node, "targets");
  if (!targets_node) {
    return fail<AuthoredObservationTelemetry>(std::move(targets_node.error()));
  }
  Result<std::vector<AuthoredObservationTarget>> targets =
      parse_array<AuthoredObservationTarget>(
          *targets_node.value(), "telemetry.observation.targets",
          parse_observation_target);
  if (!targets) {
    return fail<AuthoredObservationTelemetry>(std::move(targets.error()));
  }
  std::vector<QueueId> seen;
  seen.reserve(targets.value().size());
  for (const AuthoredObservationTarget& target : targets.value()) {
    if (std::find(seen.begin(), seen.end(), target.queue_id.value) !=
        seen.end()) {
      return fail<AuthoredObservationTelemetry>(diagnostic_at(
          *node, "model_duplicate_observation_target",
          "telemetry.observation may name each typed queue ID at most once"));
    }
    seen.push_back(target.queue_id.value);
  }
  if (enabled.value() && targets.value().empty()) {
    return fail<AuthoredObservationTelemetry>(diagnostic_at(
        *targets_node.value(), "model_empty_observation_targets",
        "enabled telemetry.observation requires at least one target"));
  }
  return Result<AuthoredObservationTelemetry>::success(
      AuthoredObservationTelemetry{
          {enabled.value(), authored_provenance(*enabled_node.value())},
          std::move(block_slots),
          {std::move(targets.value()),
           authored_provenance(*targets_node.value())},
          authored_provenance(*node)});
}

[[nodiscard]] Result<AuthoredTelemetryConfig> parse_telemetry(
    const SourceNode* node, const PhysicalSchemaDialect dialect) {
  if (node == nullptr) {
    return Result<AuthoredTelemetryConfig>::success(AuthoredTelemetryConfig{
        {"jsonl", defaulted_provenance("/telemetry/format")},
        {QueueSnapshotMode::sparse_nonzero,
         defaulted_provenance("/telemetry/queue_snapshot")},
        {true, defaulted_provenance("/telemetry/include_packet_events")},
        {false, defaulted_provenance("/telemetry/include_scheduler_state")},
        {true, defaulted_provenance("/telemetry/write_slot_trace")},
        defaulted_provenance("/telemetry"),
        dialect == PhysicalSchemaDialect::v4
            ? std::optional<AuthoredObservationTelemetry>(
                  default_observation_telemetry())
            : std::nullopt});
  }
  constexpr std::array v3_keys{"format", "queue_snapshot",
                               "include_packet_events",
                               "include_scheduler_state",
                               "write_slot_trace"};
  constexpr std::array v4_keys{"format", "queue_snapshot",
                               "include_packet_events",
                               "include_scheduler_state",
                               "write_slot_trace", "observation"};
  Result<void> closed = dialect == PhysicalSchemaDialect::v4
                            ? exact_keys(*node, v4_keys)
                            : exact_keys(*node, v3_keys);
  if (!closed)
    return fail<AuthoredTelemetryConfig>(std::move(closed.error()));
  AuthoredField<std::string> format{
      "jsonl", defaulted_provenance("/telemetry/format")};
  if (const SourceNode* field = node->find("format"); field != nullptr) {
    Result<std::string> parsed = parse_string(*field, "telemetry.format");
    if (!parsed)
      return fail<AuthoredTelemetryConfig>(std::move(parsed.error()));
    if (parsed.value() != "jsonl") {
      return fail<AuthoredTelemetryConfig>(diagnostic_at(
          *field, "model_unknown_telemetry_format",
          "telemetry.format must be 'jsonl'"));
    }
    format = {std::move(parsed.value()), authored_provenance(*field)};
  }
  AuthoredField<QueueSnapshotMode> snapshot{
      QueueSnapshotMode::sparse_nonzero,
      defaulted_provenance("/telemetry/queue_snapshot")};
  if (const SourceNode* field = node->find("queue_snapshot"); field != nullptr) {
    Result<std::string> parsed =
        parse_string(*field, "telemetry.queue_snapshot");
    if (!parsed)
      return fail<AuthoredTelemetryConfig>(std::move(parsed.error()));
    if (parsed.value() == "sparse_non_zero") {
      Result<void> alias =
          reject_tag_alias(*field, parsed.value(), "sparse_nonzero");
      return fail<AuthoredTelemetryConfig>(std::move(alias.error()));
    }
    if (parsed.value() == "dense") {
      snapshot = {QueueSnapshotMode::dense, authored_provenance(*field)};
    } else if (parsed.value() == "sparse_nonzero") {
      snapshot = {QueueSnapshotMode::sparse_nonzero,
                  authored_provenance(*field)};
    } else if (parsed.value() == "disabled") {
      snapshot = {QueueSnapshotMode::disabled, authored_provenance(*field)};
    } else {
      return fail<AuthoredTelemetryConfig>(diagnostic_at(
          *field, "model_unknown_queue_snapshot",
          "queue_snapshot must be dense, sparse_nonzero, or disabled"));
    }
  }
  const auto default_boolean = [](const SourceNode& owner,
                                  const std::string_view key,
                                  const bool default_value)
      -> Result<AuthoredField<bool>> {
    const SourceNode* field = owner.find(key);
    if (field == nullptr) {
      return Result<AuthoredField<bool>>::success(
          {default_value, defaulted_provenance(
                              "/telemetry/" + std::string(key))});
    }
    Result<bool> parsed = parse_boolean(*field, key);
    if (!parsed)
      return fail<AuthoredField<bool>>(std::move(parsed.error()));
    return Result<AuthoredField<bool>>::success(
        {parsed.value(), authored_provenance(*field)});
  };
  Result<AuthoredField<bool>> packet_events =
      default_boolean(*node, "include_packet_events", true);
  if (!packet_events)
    return fail<AuthoredTelemetryConfig>(std::move(packet_events.error()));
  Result<AuthoredField<bool>> scheduler_state =
      default_boolean(*node, "include_scheduler_state", false);
  if (!scheduler_state)
    return fail<AuthoredTelemetryConfig>(std::move(scheduler_state.error()));
  Result<AuthoredField<bool>> slot_trace =
      default_boolean(*node, "write_slot_trace", true);
  if (!slot_trace)
    return fail<AuthoredTelemetryConfig>(std::move(slot_trace.error()));
  std::optional<AuthoredObservationTelemetry> observation;
  if (dialect == PhysicalSchemaDialect::v4) {
    Result<AuthoredObservationTelemetry> parsed =
        parse_observation_telemetry(node->find("observation"));
    if (!parsed) {
      return fail<AuthoredTelemetryConfig>(std::move(parsed.error()));
    }
    observation = std::move(parsed.value());
  }
  return Result<AuthoredTelemetryConfig>::success(AuthoredTelemetryConfig{
      std::move(format), std::move(snapshot), std::move(packet_events.value()),
      std::move(scheduler_state.value()), std::move(slot_trace.value()),
      authored_provenance(*node), std::move(observation)});
}

[[nodiscard]] Result<AuthoredModelConfig> parse_model_config_for_dialect(
    const ModelNode& model, const PhysicalSchemaDialect dialect) {
  const SourceNode& root = model.node;
  constexpr std::array top_keys{"schema_version", "run", "switch",
                                "scheduler", "arrival", "telemetry",
                                "metadata"};
  Result<void> closed = exact_keys(root, top_keys);
  if (!closed) return fail<AuthoredModelConfig>(std::move(closed.error()));

  const std::string_view expected_version =
      dialect == PhysicalSchemaDialect::v4 ? kPhysicalSchemaVersionV4
                                           : kPhysicalSchemaVersionV3;
  AuthoredField<std::string> schema_version{
      std::string(expected_version), defaulted_provenance("/schema_version")};
  if (const SourceNode* node = root.find("schema_version"); node != nullptr) {
    Result<std::string> version = parse_string(*node, "schema_version");
    if (!version) return fail<AuthoredModelConfig>(std::move(version.error()));
    if (version.value() != expected_version) {
      return fail<AuthoredModelConfig>(diagnostic_at(
          *node, "model_schema_version_unsupported",
          "physical schema_version must be exactly " +
              std::string(expected_version),
          {dialect == PhysicalSchemaDialect::v3 &&
                   version.value() == "2.1.0"
               ? "schema 2.1.0 migration is not part of canonical-only C03"
               : "no schema-version fallback is performed"}));
    }
    schema_version = {std::move(version.value()), authored_provenance(*node)};
  } else if (dialect == PhysicalSchemaDialect::v4) {
    return fail<AuthoredModelConfig>(diagnostic_at(
        root, "model_missing_key",
        "schema-4 input requires an authored schema_version",
        {"required pointer /schema_version"}));
  }

  Result<AuthoredRunConfig> run = parse_run(root.find("run"));
  if (!run) return fail<AuthoredModelConfig>(std::move(run.error()));

  Result<const SourceNode*> switch_node = required(root, "switch");
  if (!switch_node)
    return fail<AuthoredModelConfig>(std::move(switch_node.error()));
  Result<AuthoredSwitchConfig> switch_config =
      parse_switch(*switch_node.value(), dialect);
  if (!switch_config)
    return fail<AuthoredModelConfig>(std::move(switch_config.error()));
  const bool legacy_switch =
      std::holds_alternative<LegacyCrossbarSwitchConfig>(switch_config.value());

  Result<AuthoredSchedulerConfig> scheduler =
      parse_scheduler(root.find("scheduler"), legacy_switch,
                      *switch_node.value());
  if (!scheduler)
    return fail<AuthoredModelConfig>(std::move(scheduler.error()));

  Result<const SourceNode*> arrival_node = required(root, "arrival");
  if (!arrival_node)
    return fail<AuthoredModelConfig>(std::move(arrival_node.error()));
  Result<AuthoredArrivalConfig> arrival =
      parse_arrival(*arrival_node.value(), dialect);
  if (!arrival) return fail<AuthoredModelConfig>(std::move(arrival.error()));

  Result<AuthoredTelemetryConfig> telemetry =
      parse_telemetry(root.find("telemetry"), dialect);
  if (!telemetry)
    return fail<AuthoredModelConfig>(std::move(telemetry.error()));

  Result<AuthoredMetadata> metadata = parse_metadata(root, "/metadata");
  if (!metadata) return fail<AuthoredModelConfig>(std::move(metadata.error()));

  return Result<AuthoredModelConfig>::success(AuthoredModelConfig{
      std::move(schema_version), std::move(run.value()),
      std::move(switch_config.value()), std::move(scheduler.value()),
      std::move(arrival.value()), std::move(telemetry.value()),
      std::move(metadata.value()), authored_provenance(root)});
}

}  // namespace

Result<NormalizedToken> normalize_source_state_token(
    const SourceNode& node, const std::string_view role) {
  return normalize_token_impl(node, role);
}

Result<AuthoredModelConfig> parse_model_config_v3(const ModelNode& model) {
  return parse_model_config_for_dialect(model, PhysicalSchemaDialect::v3);
}

Result<AuthoredModelConfig> parse_model_config_v4(const ModelNode& model) {
  return parse_model_config_for_dialect(model, PhysicalSchemaDialect::v4);
}

Result<AuthoredModelConfig> parse_model_config(const ModelNode& model) {
  const SourceNode* schema = model.node.find("schema_version");
  if (schema == nullptr) {
    return parse_model_config_v3(model);
  }
  Result<std::string> version = parse_string(*schema, "schema_version");
  if (!version) {
    return fail<AuthoredModelConfig>(std::move(version.error()));
  }
  if (version.value() == kPhysicalSchemaVersionV3) {
    return parse_model_config_v3(model);
  }
  if (version.value() == kPhysicalSchemaVersionV4) {
    return parse_model_config_v4(model);
  }
  return fail<AuthoredModelConfig>(diagnostic_at(
      *schema, "model_schema_version_unsupported",
      "physical schema_version must be exactly 3.0.0 or 4.0.0",
      {"no schema-version fallback is performed"}));
}

}  // namespace mwperf
