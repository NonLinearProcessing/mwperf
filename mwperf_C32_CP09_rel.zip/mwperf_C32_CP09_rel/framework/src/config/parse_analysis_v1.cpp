#include "mwperf/config/analysis_spec.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/schema_versions.hpp"

namespace mwperf {
namespace {

using namespace std::literals::string_view_literals;

[[nodiscard]] Diagnostic analysis_error(const SourceNode& node,
                                        std::string code,
                                        std::string message) {
  Diagnostic diagnostic{DiagnosticCategory::input_validation, std::move(code),
                        std::move(message), node.location().authored_path,
                        std::string(node.json_pointer()), {}};
  diagnostic.notes.push_back("line " + std::to_string(node.location().line) +
                             ", column " +
                             std::to_string(node.location().column));
  return diagnostic;
}

template <typename T>
[[nodiscard]] Result<T> fail(const SourceNode& node, std::string code,
                             std::string message) {
  return Result<T>::failure(
      analysis_error(node, std::move(code), std::move(message)));
}

[[nodiscard]] Result<void> closed_object(
    const SourceNode& node, const std::span<const std::string_view> keys) {
  if (node.kind() != SourceNodeKind::object) {
    return Result<void>::failure(analysis_error(
        node, "analysis.expected_object", "expected an object"));
  }
  return validate_exact_keys(node, keys, node.json_pointer());
}

template <std::size_t Extent>
[[nodiscard]] Result<void> closed_object(
    const SourceNode& node,
    const std::array<std::string_view, Extent>& keys) {
  return closed_object(node, std::span<const std::string_view>(keys));
}

[[nodiscard]] Result<const SourceNode*> required(const SourceNode& object,
                                                 std::string_view key) {
  if (const SourceNode* value = object.find(key); value != nullptr) {
    return Result<const SourceNode*>::success(value);
  }
  return fail<const SourceNode*>(
      object, "analysis.missing_key",
      "missing required key '" + std::string(key) + "'");
}

[[nodiscard]] Result<std::string> trimmed_string(const SourceNode& node,
                                                 std::string_view role) {
  if (node.kind() != SourceNodeKind::string) {
    return fail<std::string>(node, "analysis.expected_string",
                             std::string(role) + " must be a string");
  }
  const std::string& value = *node.string_value();
  // Reuse C02's locale-independent UTF-8/Unicode White_Space boundary so all
  // v1 "trimmed string" fields have one definition.
  Result<TypedLabel> checked = TypedLabel::text(value);
  if (!checked) {
    return fail<std::string>(
        node, "analysis.noncanonical_string",
        std::string(role) + " must be nonempty and already trimmed");
  }
  return Result<std::string>::success(value);
}

[[nodiscard]] Result<bool> boolean_value(const SourceNode& node,
                                         std::string_view role) {
  if (node.kind() != SourceNodeKind::boolean) {
    return fail<bool>(node, "analysis.expected_boolean",
                      std::string(role) + " must be a boolean");
  }
  return Result<bool>::success(*node.boolean_value());
}

[[nodiscard]] Result<BigNat> natural(const SourceNode& node,
                                     std::string_view role) {
  if (node.kind() != SourceNodeKind::number) {
    return fail<BigNat>(node, "analysis.expected_natural",
                        std::string(role) +
                            " must be an exact nonnegative integer");
  }
  Result<BigNat> parsed = parse_exact_nonnegative_integer(
      JsonNumber(*node.number_lexeme()), BoundPolicy::unbounded());
  if (!parsed) {
    Diagnostic diagnostic = parsed.error();
    diagnostic.authored_path = node.location().authored_path;
    diagnostic.json_pointer = std::string(node.json_pointer());
    diagnostic.notes.push_back("line " +
                               std::to_string(node.location().line) +
                               ", column " +
                               std::to_string(node.location().column));
    return Result<BigNat>::failure(std::move(diagnostic));
  }
  return Result<BigNat>::success(std::move(parsed).value());
}

[[nodiscard]] Result<BigNat> positive_natural(const SourceNode& node,
                                              std::string_view role) {
  Result<BigNat> parsed = natural(node, role);
  if (!parsed) {
    return parsed;
  }
  if (parsed.value().is_zero()) {
    return fail<BigNat>(node, "analysis.expected_positive_integer",
                        std::string(role) + " must be positive");
  }
  return parsed;
}

[[nodiscard]] Result<std::optional<BigNat>> optional_positive_natural(
    const SourceNode& node, std::string_view role) {
  if (node.kind() == SourceNodeKind::null_value) {
    return Result<std::optional<BigNat>>::success(std::nullopt);
  }
  Result<BigNat> parsed = positive_natural(node, role);
  if (!parsed) {
    return Result<std::optional<BigNat>>::failure(parsed.error());
  }
  return Result<std::optional<BigNat>>::success(
      std::optional<BigNat>(std::move(parsed).value()));
}

[[nodiscard]] Result<ExactRational> decimal(const SourceNode& node,
                                            std::string_view role) {
  if (node.kind() != SourceNodeKind::number) {
    return fail<ExactRational>(node, "analysis.expected_decimal",
                               std::string(role) +
                                   " must be an exact finite decimal");
  }
  Result<ExactRational> parsed =
      parse_decimal_rational(NumericLexeme(*node.number_lexeme()));
  if (!parsed) {
    Diagnostic diagnostic = parsed.error();
    diagnostic.authored_path = node.location().authored_path;
    diagnostic.json_pointer = std::string(node.json_pointer());
    diagnostic.notes.push_back("line " +
                               std::to_string(node.location().line) +
                               ", column " +
                               std::to_string(node.location().column));
    return Result<ExactRational>::failure(std::move(diagnostic));
  }
  return Result<ExactRational>::success(std::move(parsed).value());
}

[[nodiscard]] Result<ExactRational> nonnegative_decimal(
    const SourceNode& node, std::string_view role) {
  Result<ExactRational> parsed = decimal(node, role);
  if (!parsed) {
    return parsed;
  }
  if (!parsed.value().is_nonnegative()) {
    return fail<ExactRational>(node, "analysis.decimal_out_of_range",
                               std::string(role) + " must be nonnegative");
  }
  return parsed;
}

[[nodiscard]] Result<ExactRational> open_probability(
    const SourceNode& node, std::string_view role) {
  Result<ExactRational> parsed = decimal(node, role);
  if (!parsed) {
    return parsed;
  }
  if (!(parsed.value() > ExactRational::zero()) ||
      !(parsed.value() < ExactRational::one())) {
    return fail<ExactRational>(node, "analysis.probability_out_of_range",
                               std::string(role) + " must be in (0,1)");
  }
  return parsed;
}

[[nodiscard]] Result<AuthoredProbability> closed_probability(
    const SourceNode& node, std::string_view role) {
  Result<ExactRational> parsed = decimal(node, role);
  if (!parsed) {
    return Result<AuthoredProbability>::failure(parsed.error());
  }
  Result<AuthoredProbability> probability =
      AuthoredProbability::from_exact(std::move(parsed).value());
  if (!probability) {
    Diagnostic diagnostic = probability.error();
    diagnostic.authored_path = node.location().authored_path;
    diagnostic.json_pointer = std::string(node.json_pointer());
    diagnostic.notes.push_back("line " +
                               std::to_string(node.location().line) +
                               ", column " +
                               std::to_string(node.location().column));
    return Result<AuthoredProbability>::failure(std::move(diagnostic));
  }
  return probability;
}

[[nodiscard]] Result<TypedLabel> typed_label(const SourceNode& node,
                                             std::string_view role) {
  JsonValue carrier = JsonValue::null();
  switch (node.kind()) {
    case SourceNodeKind::number:
      carrier = JsonValue::number(*node.number_lexeme());
      break;
    case SourceNodeKind::string:
      carrier = JsonValue::string(*node.string_value());
      break;
    case SourceNodeKind::boolean:
      carrier = JsonValue::boolean(*node.boolean_value());
      break;
    case SourceNodeKind::null_value:
      carrier = JsonValue::null();
      break;
    case SourceNodeKind::array:
      carrier = JsonValue::array();
      break;
    case SourceNodeKind::object:
      carrier = JsonValue::object();
      break;
  }
  Result<TypedLabel> parsed = parse_typed_label(carrier);
  if (!parsed) {
    Diagnostic diagnostic = parsed.error();
    diagnostic.message = std::string(role) + ": " + diagnostic.message;
    diagnostic.authored_path = node.location().authored_path;
    diagnostic.json_pointer = std::string(node.json_pointer());
    diagnostic.notes.push_back("line " +
                               std::to_string(node.location().line) +
                               ", column " +
                               std::to_string(node.location().column));
    return Result<TypedLabel>::failure(std::move(diagnostic));
  }
  return parsed;
}

template <typename T>
[[nodiscard]] bool contains_value(const std::vector<T>& values,
                                  const T& candidate) {
  return std::find(values.begin(), values.end(), candidate) != values.end();
}

[[nodiscard]] bool is_forbidden_provider_key(std::string_view key) {
  // The closed registry owns transport.  This exact, case-sensitive denylist
  // avoids interpreting or second-guessing provider mathematical key names.
  constexpr std::array<std::string_view, 17> forbidden{
      "executable",       "executable_path", "command",
      "argv",             "url",             "service_url",
      "endpoint",         "transport",       "artifact_transport",
      "working_directory", "workdir",         "environment",
      "env",              "shell",           "shell_fragment",
      "command_line",     "cwd"};
  return std::find(forbidden.begin(), forbidden.end(), key) !=
         forbidden.end();
}

[[nodiscard]] Result<void> validate_opaque_provider_object(
    const SourceNode& node) {
  if (node.kind() != SourceNodeKind::object) {
    return Result<void>::failure(analysis_error(
        node, "analysis.provider_payload_not_object",
        "a provider-owned payload must be an object"));
  }

  const auto visit = [](const auto& self,
                        const SourceNode& current) -> Result<void> {
    if (current.kind() == SourceNodeKind::object) {
      for (const SourceObjectMember& member : current.object_members()) {
        if (is_forbidden_provider_key(member.key)) {
          return Result<void>::failure(analysis_error(
              member.value, "analysis.provider_transport_forbidden",
              "provider-owned input cannot select executable code, a "
              "command, environment, endpoint, or transport (forbidden key "
              "'" +
                  member.key + "')"));
        }
        Result<void> nested = self(self, member.value);
        if (!nested) {
          return nested;
        }
      }
    } else if (current.kind() == SourceNodeKind::array) {
      for (const SourceNode& item : current.array_items()) {
        Result<void> nested = self(self, item);
        if (!nested) {
          return nested;
        }
      }
    }
    return Result<void>::success();
  };
  return visit(visit, node);
}

[[nodiscard]] Result<TargetSet> parse_targets(const SourceNode& node) {
  if (node.kind() != SourceNodeKind::array || node.array_items().empty()) {
    return fail<TargetSet>(node, "analysis.targets_nonempty",
                           "targets must be a nonempty array");
  }
  std::vector<TypedLabel> targets;
  targets.reserve(node.array_items().size());
  for (const SourceNode& item : node.array_items()) {
    Result<TypedLabel> parsed = typed_label(item, "target queue id");
    if (!parsed) {
      return Result<TargetSet>::failure(parsed.error());
    }
    if (contains_value(targets, parsed.value())) {
      return fail<TargetSet>(item, "analysis.duplicate_target",
                             "targets must be duplicate-free under typed "
                             "label identity");
    }
    targets.push_back(std::move(parsed).value());
  }
  return Result<TargetSet>::success(TargetSet{std::move(targets), node});
}

[[nodiscard]] Result<LevelResolution> parse_level_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"max_states"sv, "max_row_atoms"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<LevelResolution>::failure(shape.error());
  }
  Result<const SourceNode*> states_node = required(node, "max_states");
  Result<const SourceNode*> atoms_node = required(node, "max_row_atoms");
  if (!states_node) {
    return Result<LevelResolution>::failure(states_node.error());
  }
  if (!atoms_node) {
    return Result<LevelResolution>::failure(atoms_node.error());
  }
  Result<std::optional<BigNat>> states =
      optional_positive_natural(*states_node.value(), "max_states");
  Result<std::optional<BigNat>> atoms =
      optional_positive_natural(*atoms_node.value(), "max_row_atoms");
  if (!states) {
    return Result<LevelResolution>::failure(states.error());
  }
  if (!atoms) {
    return Result<LevelResolution>::failure(atoms.error());
  }
  return Result<LevelResolution>::success(LevelResolution{
      std::move(states).value(), std::move(atoms).value(), node});
}

[[nodiscard]] Result<TailResolution> parse_tail_resolution(
    const SourceNode& node) {
  constexpr std::array wrapper_keys{"kind"sv, "parameters"sv};
  Result<void> shape = closed_object(node, wrapper_keys);
  if (!shape) {
    return Result<TailResolution>::failure(shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  Result<const SourceNode*> params_node = required(node, "parameters");
  if (!kind_node) {
    return Result<TailResolution>::failure(kind_node.error());
  }
  if (!params_node) {
    return Result<TailResolution>::failure(params_node.error());
  }
  Result<std::string> kind = trimmed_string(*kind_node.value(), "tail kind");
  if (!kind) {
    return Result<TailResolution>::failure(kind.error());
  }
  const SourceNode& parameters = *params_node.value();
  if (kind.value() == "none") {
    constexpr std::array<std::string_view, 0> no_keys{};
    Result<void> params_shape = closed_object(parameters, no_keys);
    if (!params_shape) {
      return Result<TailResolution>::failure(params_shape.error());
    }
    return Result<TailResolution>::success(NoTailResolution{node});
  }
  if (kind.value() == "finite_closed") {
    constexpr std::array keys{"max_level"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<TailResolution>::failure(params_shape.error());
    }
    Result<const SourceNode*> value_node = required(parameters, "max_level");
    if (!value_node) {
      return Result<TailResolution>::failure(value_node.error());
    }
    Result<BigNat> value = natural(*value_node.value(), "max_level");
    if (!value) {
      return Result<TailResolution>::failure(value.error());
    }
    return Result<TailResolution>::success(FiniteClosedTailResolution{
        std::move(value).value(), node});
  }
  if (kind.value() == "constant_response") {
    constexpr std::array keys{"cutoff"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<TailResolution>::failure(params_shape.error());
    }
    Result<const SourceNode*> value_node = required(parameters, "cutoff");
    if (!value_node) {
      return Result<TailResolution>::failure(value_node.error());
    }
    Result<BigNat> value = natural(*value_node.value(), "cutoff");
    if (!value) {
      return Result<TailResolution>::failure(value.error());
    }
    return Result<TailResolution>::success(ConstantResponseTailResolution{
        std::move(value).value(), node});
  }
  if (kind.value() == "certified_truncation") {
    constexpr std::array keys{"max_level"sv, "max_tail_mass"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<TailResolution>::failure(params_shape.error());
    }
    Result<const SourceNode*> level_node = required(parameters, "max_level");
    Result<const SourceNode*> mass_node =
        required(parameters, "max_tail_mass");
    if (!level_node) {
      return Result<TailResolution>::failure(level_node.error());
    }
    if (!mass_node) {
      return Result<TailResolution>::failure(mass_node.error());
    }
    Result<BigNat> level = natural(*level_node.value(), "max_level");
    Result<ExactRational> mass =
        open_probability(*mass_node.value(), "max_tail_mass");
    if (!level) {
      return Result<TailResolution>::failure(level.error());
    }
    if (!mass) {
      return Result<TailResolution>::failure(mass.error());
    }
    return Result<TailResolution>::success(CertifiedTruncationTailResolution{
        std::move(level).value(), std::move(mass).value(), node});
  }
  return fail<TailResolution>(*kind_node.value(), "analysis.unknown_tail_kind",
                              "unknown tail kind '" + kind.value() + "'");
}

[[nodiscard]] Result<PhaseResolution> parse_phase_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"max_phase_states"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<PhaseResolution>::failure(shape.error());
  }
  Result<const SourceNode*> value_node = required(node, "max_phase_states");
  if (!value_node) {
    return Result<PhaseResolution>::failure(value_node.error());
  }
  Result<std::optional<BigNat>> value = optional_positive_natural(
      *value_node.value(), "max_phase_states");
  if (!value) {
    return Result<PhaseResolution>::failure(value.error());
  }
  return Result<PhaseResolution>::success(
      PhaseResolution{std::move(value).value(), node});
}

[[nodiscard]] Result<OptimizerResolution> parse_optimizer_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"max_calls"sv,
                            "max_search_states_per_call"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<OptimizerResolution>::failure(shape.error());
  }
  Result<const SourceNode*> calls_node = required(node, "max_calls");
  Result<const SourceNode*> states_node =
      required(node, "max_search_states_per_call");
  if (!calls_node) {
    return Result<OptimizerResolution>::failure(calls_node.error());
  }
  if (!states_node) {
    return Result<OptimizerResolution>::failure(states_node.error());
  }
  Result<std::optional<BigNat>> calls =
      optional_positive_natural(*calls_node.value(), "max_calls");
  Result<std::optional<BigNat>> states = optional_positive_natural(
      *states_node.value(), "max_search_states_per_call");
  if (!calls) {
    return Result<OptimizerResolution>::failure(calls.error());
  }
  if (!states) {
    return Result<OptimizerResolution>::failure(states.error());
  }
  return Result<OptimizerResolution>::success(OptimizerResolution{
      std::move(calls).value(), std::move(states).value(), node});
}

[[nodiscard]] Result<SamplingResolution> parse_sampling_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"max_generator_draws"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<SamplingResolution>::failure(shape.error());
  }
  Result<const SourceNode*> value_node = required(node, "max_generator_draws");
  if (!value_node) {
    return Result<SamplingResolution>::failure(value_node.error());
  }
  Result<std::optional<BigNat>> value = optional_positive_natural(
      *value_node.value(), "max_generator_draws");
  if (!value) {
    return Result<SamplingResolution>::failure(value.error());
  }
  return Result<SamplingResolution>::success(
      SamplingResolution{std::move(value).value(), node});
}

[[nodiscard]] Result<std::optional<ExactRational>> optional_nonnegative_decimal(
    const SourceNode& node, std::string_view role) {
  if (node.kind() == SourceNodeKind::null_value) {
    return Result<std::optional<ExactRational>>::success(std::nullopt);
  }
  Result<ExactRational> value = nonnegative_decimal(node, role);
  if (!value) {
    return Result<std::optional<ExactRational>>::failure(value.error());
  }
  return Result<std::optional<ExactRational>>::success(
      std::optional<ExactRational>(std::move(value).value()));
}

[[nodiscard]] Result<ToleranceResolution> parse_tolerance_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"linear_residual_abs"sv, "integration_abs"sv,
                            "tail_abs"sv, "fixed_point_abs"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<ToleranceResolution>::failure(shape.error());
  }
  Result<const SourceNode*> linear_node =
      required(node, "linear_residual_abs");
  Result<const SourceNode*> integration_node =
      required(node, "integration_abs");
  Result<const SourceNode*> tail_node = required(node, "tail_abs");
  Result<const SourceNode*> fixed_node = required(node, "fixed_point_abs");
  if (!linear_node) {
    return Result<ToleranceResolution>::failure(linear_node.error());
  }
  if (!integration_node) {
    return Result<ToleranceResolution>::failure(integration_node.error());
  }
  if (!tail_node) {
    return Result<ToleranceResolution>::failure(tail_node.error());
  }
  if (!fixed_node) {
    return Result<ToleranceResolution>::failure(fixed_node.error());
  }
  Result<std::optional<ExactRational>> linear = optional_nonnegative_decimal(
      *linear_node.value(), "linear_residual_abs");
  Result<std::optional<ExactRational>> integration =
      optional_nonnegative_decimal(*integration_node.value(),
                                   "integration_abs");
  Result<std::optional<ExactRational>> tail =
      optional_nonnegative_decimal(*tail_node.value(), "tail_abs");
  Result<std::optional<ExactRational>> fixed = optional_nonnegative_decimal(
      *fixed_node.value(), "fixed_point_abs");
  if (!linear) {
    return Result<ToleranceResolution>::failure(linear.error());
  }
  if (!integration) {
    return Result<ToleranceResolution>::failure(integration.error());
  }
  if (!tail) {
    return Result<ToleranceResolution>::failure(tail.error());
  }
  if (!fixed) {
    return Result<ToleranceResolution>::failure(fixed.error());
  }
  return Result<ToleranceResolution>::success(ToleranceResolution{
      std::move(linear).value(), std::move(integration).value(),
      std::move(tail).value(), std::move(fixed).value(), node});
}

[[nodiscard]] Result<ResolutionEnvelope> parse_resolution(
    const SourceNode& node) {
  constexpr std::array keys{"level"sv,      "tail"sv,     "phase"sv,
                            "optimizer"sv,  "sampling"sv, "tolerance"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<ResolutionEnvelope>::failure(shape.error());
  }
  const std::array<std::string_view, 6> names{"level", "tail", "phase",
                                              "optimizer", "sampling",
                                              "tolerance"};
  for (const std::string_view name : names) {
    Result<const SourceNode*> field = required(node, name);
    if (!field) {
      return Result<ResolutionEnvelope>::failure(field.error());
    }
  }
  Result<LevelResolution> level = parse_level_resolution(*node.find("level"));
  Result<TailResolution> tail = parse_tail_resolution(*node.find("tail"));
  Result<PhaseResolution> phase = parse_phase_resolution(*node.find("phase"));
  Result<OptimizerResolution> optimizer =
      parse_optimizer_resolution(*node.find("optimizer"));
  Result<SamplingResolution> sampling =
      parse_sampling_resolution(*node.find("sampling"));
  Result<ToleranceResolution> tolerance =
      parse_tolerance_resolution(*node.find("tolerance"));
  if (!level) {
    return Result<ResolutionEnvelope>::failure(level.error());
  }
  if (!tail) {
    return Result<ResolutionEnvelope>::failure(tail.error());
  }
  if (!phase) {
    return Result<ResolutionEnvelope>::failure(phase.error());
  }
  if (!optimizer) {
    return Result<ResolutionEnvelope>::failure(optimizer.error());
  }
  if (!sampling) {
    return Result<ResolutionEnvelope>::failure(sampling.error());
  }
  if (!tolerance) {
    return Result<ResolutionEnvelope>::failure(tolerance.error());
  }
  return Result<ResolutionEnvelope>::success(ResolutionEnvelope{
      std::move(level).value(), std::move(tail).value(),
      std::move(phase).value(), std::move(optimizer).value(),
      std::move(sampling).value(), std::move(tolerance).value(), node});
}

[[nodiscard]] Result<ArrivalInitialState> parse_arrival_initial_state(
    const SourceNode& node) {
  if (node.kind() != SourceNodeKind::object) {
    return fail<ArrivalInitialState>(node, "analysis.arrival_state_object",
                                     "arrival_state must be an object");
  }
  constexpr std::array union_keys{"kind"sv, "states"sv, "state"sv};
  Result<void> union_shape = closed_object(node, union_keys);
  if (!union_shape) {
    return Result<ArrivalInitialState>::failure(union_shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  if (!kind_node) {
    return Result<ArrivalInitialState>::failure(kind_node.error());
  }
  Result<std::string> kind =
      trimmed_string(*kind_node.value(), "arrival_state kind");
  if (!kind) {
    return Result<ArrivalInitialState>::failure(kind.error());
  }
  if (kind.value() == "trace_origin" ||
      kind.value() == "global_periodic_origin" ||
      kind.value() == "source_delay_origin" ||
      kind.value() == "renewal_origin") {
    constexpr std::array keys{"kind"sv};
    Result<void> shape = closed_object(node, keys);
    if (!shape) {
      return Result<ArrivalInitialState>::failure(shape.error());
    }
    if (kind.value() == "trace_origin") {
      return Result<ArrivalInitialState>::success(TraceOrigin{});
    }
    if (kind.value() == "global_periodic_origin") {
      return Result<ArrivalInitialState>::success(GlobalPeriodicOrigin{});
    }
    if (kind.value() == "source_delay_origin") {
      return Result<ArrivalInitialState>::success(SourceDelayOrigin{});
    }
    return Result<ArrivalInitialState>::success(RenewalOrigin{});
  }
  if (kind.value() == "private_markov_states") {
    constexpr std::array keys{"kind"sv, "states"sv};
    Result<void> shape = closed_object(node, keys);
    if (!shape) {
      return Result<ArrivalInitialState>::failure(shape.error());
    }
    Result<const SourceNode*> states_node = required(node, "states");
    if (!states_node) {
      return Result<ArrivalInitialState>::failure(states_node.error());
    }
    if (states_node.value()->kind() != SourceNodeKind::array) {
      return fail<ArrivalInitialState>(*states_node.value(),
                                       "analysis.states_array",
                                       "states must be an array");
    }
    std::vector<PrivateMarkovState> states;
    std::vector<std::string> seen_sources;
    states.reserve(states_node.value()->array_items().size());
    for (const SourceNode& state_node : states_node.value()->array_items()) {
      constexpr std::array state_keys{"source_id"sv, "state"sv};
      Result<void> state_shape = closed_object(state_node, state_keys);
      if (!state_shape) {
        return Result<ArrivalInitialState>::failure(state_shape.error());
      }
      Result<const SourceNode*> source_node = required(state_node, "source_id");
      Result<const SourceNode*> value_node = required(state_node, "state");
      if (!source_node) {
        return Result<ArrivalInitialState>::failure(source_node.error());
      }
      if (!value_node) {
        return Result<ArrivalInitialState>::failure(value_node.error());
      }
      Result<NormalizedToken> source = normalize_source_state_token(
          *source_node.value(), "source_id");
      Result<NormalizedToken> value = normalize_source_state_token(
          *value_node.value(), "state");
      if (!source) {
        return Result<ArrivalInitialState>::failure(source.error());
      }
      if (!value) {
        return Result<ArrivalInitialState>::failure(value.error());
      }
      NormalizedToken source_token = std::move(source).value();
      NormalizedToken state_token = std::move(value).value();
      if (contains_value(seen_sources, source_token.value)) {
        return fail<ArrivalInitialState>(
            *source_node.value(), "analysis.duplicate_arrival_source_state",
            "private_markov_states contains more than one state for source '" +
                source_token.value + "'");
      }
      seen_sources.push_back(source_token.value);
      states.push_back(PrivateMarkovState{std::move(source_token.value),
                                          std::move(state_token.value),
                                          state_node});
    }
    return Result<ArrivalInitialState>::success(
        PrivateMarkovStates{std::move(states)});
  }
  if (kind.value() == "shared_round_state") {
    constexpr std::array keys{"kind"sv, "state"sv};
    Result<void> shape = closed_object(node, keys);
    if (!shape) {
      return Result<ArrivalInitialState>::failure(shape.error());
    }
    Result<const SourceNode*> state_node = required(node, "state");
    if (!state_node) {
      return Result<ArrivalInitialState>::failure(state_node.error());
    }
    Result<NormalizedToken> state =
        normalize_source_state_token(*state_node.value(), "state");
    if (!state) {
      return Result<ArrivalInitialState>::failure(state.error());
    }
    NormalizedToken state_token = std::move(state).value();
    return Result<ArrivalInitialState>::success(
        SharedRoundState{std::move(state_token.value)});
  }
  return fail<ArrivalInitialState>(*kind_node.value(),
                                   "analysis.unknown_arrival_state_kind",
                                   "unknown arrival_state kind '" +
                                       kind.value() + "'");
}

[[nodiscard]] Result<TransientInitialAtom> parse_transient_atom(
    const SourceNode& node) {
  constexpr std::array keys{"probability"sv,      "backlog"sv,
                            "controller_state"sv, "arrival_state"sv,
                            "static_context"sv,   "surrogate_initial"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<TransientInitialAtom>::failure(shape.error());
  }
  for (const std::string_view key : keys) {
    Result<const SourceNode*> field = required(node, key);
    if (!field) {
      return Result<TransientInitialAtom>::failure(field.error());
    }
  }

  Result<AuthoredProbability> probability =
      closed_probability(*node.find("probability"), "initial atom probability");
  if (!probability) {
    return Result<TransientInitialAtom>::failure(probability.error());
  }

  const SourceNode& backlog_node = *node.find("backlog");
  if (backlog_node.kind() != SourceNodeKind::array) {
    return fail<TransientInitialAtom>(backlog_node, "analysis.backlog_array",
                                      "backlog must be an array");
  }
  std::vector<InitialBacklogEntry> backlog;
  std::vector<TypedLabel> seen_queue_ids;
  backlog.reserve(backlog_node.array_items().size());
  for (const SourceNode& entry_node : backlog_node.array_items()) {
    constexpr std::array entry_keys{"queue_id"sv, "value"sv};
    Result<void> entry_shape = closed_object(entry_node, entry_keys);
    if (!entry_shape) {
      return Result<TransientInitialAtom>::failure(entry_shape.error());
    }
    Result<const SourceNode*> queue_node = required(entry_node, "queue_id");
    Result<const SourceNode*> value_node = required(entry_node, "value");
    if (!queue_node) {
      return Result<TransientInitialAtom>::failure(queue_node.error());
    }
    if (!value_node) {
      return Result<TransientInitialAtom>::failure(value_node.error());
    }
    Result<TypedLabel> queue = typed_label(*queue_node.value(), "queue_id");
    Result<BigNat> value = natural(*value_node.value(), "backlog value");
    if (!queue) {
      return Result<TransientInitialAtom>::failure(queue.error());
    }
    if (!value) {
      return Result<TransientInitialAtom>::failure(value.error());
    }
    if (contains_value(seen_queue_ids, queue.value())) {
      return fail<TransientInitialAtom>(
          *queue_node.value(), "analysis.duplicate_backlog_queue",
          "backlog contains a duplicate typed queue_id");
    }
    seen_queue_ids.push_back(queue.value());
    backlog.push_back(InitialBacklogEntry{
        std::move(queue).value(), std::move(value).value(), entry_node});
  }

  const SourceNode& controller_state = *node.find("controller_state");
  const SourceNode& static_context = *node.find("static_context");
  constexpr std::array<std::string_view, 0> no_keys{};
  Result<void> controller_shape = closed_object(controller_state, no_keys);
  Result<void> context_shape = closed_object(static_context, no_keys);
  if (!controller_shape) {
    return Result<TransientInitialAtom>::failure(controller_shape.error());
  }
  if (!context_shape) {
    return Result<TransientInitialAtom>::failure(context_shape.error());
  }

  Result<ArrivalInitialState> arrival_state =
      parse_arrival_initial_state(*node.find("arrival_state"));
  if (!arrival_state) {
    return Result<TransientInitialAtom>::failure(arrival_state.error());
  }

  const SourceNode& surrogate_initial = *node.find("surrogate_initial");
  Result<void> opaque = validate_opaque_provider_object(surrogate_initial);
  if (!opaque) {
    return Result<TransientInitialAtom>::failure(opaque.error());
  }
  return Result<TransientInitialAtom>::success(TransientInitialAtom{
      std::move(probability).value(), std::move(backlog),
      std::move(arrival_state).value(), controller_state, static_context,
      surrogate_initial, node});
}

[[nodiscard]] Result<SelectionSpec> parse_selection(const SourceNode& node) {
  constexpr std::array wrapper_keys{"kind"sv, "parameters"sv};
  Result<void> shape = closed_object(node, wrapper_keys);
  if (!shape) {
    return Result<SelectionSpec>::failure(shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  Result<const SourceNode*> params_node = required(node, "parameters");
  if (!kind_node) {
    return Result<SelectionSpec>::failure(kind_node.error());
  }
  if (!params_node) {
    return Result<SelectionSpec>::failure(params_node.error());
  }
  Result<std::string> kind = trimmed_string(*kind_node.value(), "selection kind");
  if (!kind) {
    return Result<SelectionSpec>::failure(kind.error());
  }
  const SourceNode& parameters = *params_node.value();
  if (kind.value() == "stationary_unique") {
    constexpr std::array<std::string_view, 0> no_keys{};
    Result<void> params_shape = closed_object(parameters, no_keys);
    if (!params_shape) {
      return Result<SelectionSpec>::failure(params_shape.error());
    }
    return Result<SelectionSpec>::success(
        StationaryUniqueSelection{node});
  }
  if (kind.value() == "stationary_class") {
    constexpr std::array keys{"class_id"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SelectionSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> class_node = required(parameters, "class_id");
    if (!class_node) {
      return Result<SelectionSpec>::failure(class_node.error());
    }
    Result<TypedLabel> class_id =
        typed_label(*class_node.value(), "stationary class_id");
    if (!class_id) {
      return Result<SelectionSpec>::failure(class_id.error());
    }
    return Result<SelectionSpec>::success(StationaryClassSelection{
        std::move(class_id).value(), node});
  }
  if (kind.value() == "stationary_mixture") {
    constexpr std::array keys{"components"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SelectionSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> components_node =
        required(parameters, "components");
    if (!components_node) {
      return Result<SelectionSpec>::failure(components_node.error());
    }
    if (components_node.value()->kind() != SourceNodeKind::array ||
        components_node.value()->array_items().empty()) {
      return fail<SelectionSpec>(*components_node.value(),
                                 "analysis.components_nonempty",
                                 "stationary mixture components must be a "
                                 "nonempty array");
    }
    std::vector<StationaryMixtureComponent> components;
    components.reserve(components_node.value()->array_items().size());
    for (const SourceNode& component_node :
         components_node.value()->array_items()) {
      constexpr std::array component_keys{"class_id"sv, "probability"sv};
      Result<void> component_shape =
          closed_object(component_node, component_keys);
      if (!component_shape) {
        return Result<SelectionSpec>::failure(component_shape.error());
      }
      Result<const SourceNode*> class_node =
          required(component_node, "class_id");
      Result<const SourceNode*> probability_node =
          required(component_node, "probability");
      if (!class_node) {
        return Result<SelectionSpec>::failure(class_node.error());
      }
      if (!probability_node) {
        return Result<SelectionSpec>::failure(probability_node.error());
      }
      Result<TypedLabel> class_id =
          typed_label(*class_node.value(), "stationary class_id");
      Result<AuthoredProbability> probability = closed_probability(
          *probability_node.value(), "stationary mixture probability");
      if (!class_id) {
        return Result<SelectionSpec>::failure(class_id.error());
      }
      if (!probability) {
        return Result<SelectionSpec>::failure(probability.error());
      }
      components.push_back(StationaryMixtureComponent{
          std::move(class_id).value(), std::move(probability).value(),
          component_node});
    }
    return Result<SelectionSpec>::success(StationaryMixtureSelection{
        std::move(components), node});
  }
  if (kind.value() == "transient") {
    constexpr std::array keys{"initial_law"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SelectionSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> law_node = required(parameters, "initial_law");
    if (!law_node) {
      return Result<SelectionSpec>::failure(law_node.error());
    }
    constexpr std::array law_keys{"atoms"sv};
    Result<void> law_shape = closed_object(*law_node.value(), law_keys);
    if (!law_shape) {
      return Result<SelectionSpec>::failure(law_shape.error());
    }
    Result<const SourceNode*> atoms_node =
        required(*law_node.value(), "atoms");
    if (!atoms_node) {
      return Result<SelectionSpec>::failure(atoms_node.error());
    }
    if (atoms_node.value()->kind() != SourceNodeKind::array ||
        atoms_node.value()->array_items().empty()) {
      return fail<SelectionSpec>(*atoms_node.value(),
                                 "analysis.initial_atoms_nonempty",
                                 "transient initial atoms must be a nonempty "
                                 "array");
    }
    std::vector<TransientInitialAtom> atoms;
    atoms.reserve(atoms_node.value()->array_items().size());
    for (const SourceNode& atom_node : atoms_node.value()->array_items()) {
      Result<TransientInitialAtom> atom = parse_transient_atom(atom_node);
      if (!atom) {
        return Result<SelectionSpec>::failure(atom.error());
      }
      atoms.push_back(std::move(atom).value());
    }
    return Result<SelectionSpec>::success(
        TransientSelection{std::move(atoms), node});
  }
  if (kind.value() == "fixed_point") {
    constexpr std::array allowed{"mode"sv, "solution_id"sv};
    Result<void> params_shape = closed_object(parameters, allowed);
    if (!params_shape) {
      return Result<SelectionSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> mode_node = required(parameters, "mode");
    if (!mode_node) {
      return Result<SelectionSpec>::failure(mode_node.error());
    }
    Result<std::string> mode =
        trimmed_string(*mode_node.value(), "fixed-point mode");
    if (!mode) {
      return Result<SelectionSpec>::failure(mode.error());
    }
    if (mode.value() == "unique") {
      if (parameters.find("solution_id") != nullptr) {
        return fail<SelectionSpec>(
            *parameters.find("solution_id"), "analysis.unexpected_key",
            "solution_id is forbidden when fixed-point mode is unique");
      }
      return Result<SelectionSpec>::success(FixedPointSelection(
          FixedPointUniqueSelection{node}));
    }
    if (mode.value() == "id") {
      Result<const SourceNode*> solution_node =
          required(parameters, "solution_id");
      if (!solution_node) {
        return Result<SelectionSpec>::failure(solution_node.error());
      }
      Result<TypedLabel> solution_id =
          typed_label(*solution_node.value(), "fixed-point solution_id");
      if (!solution_id) {
        return Result<SelectionSpec>::failure(solution_id.error());
      }
      return Result<SelectionSpec>::success(FixedPointSelection(
          FixedPointIdSelection{std::move(solution_id).value(), node}));
    }
    return fail<SelectionSpec>(*mode_node.value(),
                               "analysis.unknown_fixed_point_mode",
                               "fixed-point mode must be 'unique' or 'id'");
  }
  return fail<SelectionSpec>(*kind_node.value(),
                             "analysis.unknown_selection_kind",
                             "unknown selection kind '" + kind.value() + "'");
}

[[nodiscard]] Result<SolverSpec> parse_solver(const SourceNode& node) {
  constexpr std::array wrapper_keys{"kind"sv, "parameters"sv};
  Result<void> shape = closed_object(node, wrapper_keys);
  if (!shape) {
    return Result<SolverSpec>::failure(shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  Result<const SourceNode*> params_node = required(node, "parameters");
  if (!kind_node) {
    return Result<SolverSpec>::failure(kind_node.error());
  }
  if (!params_node) {
    return Result<SolverSpec>::failure(params_node.error());
  }
  Result<std::string> kind = trimmed_string(*kind_node.value(), "solver kind");
  if (!kind) {
    return Result<SolverSpec>::failure(kind.error());
  }
  const SourceNode& parameters = *params_node.value();
  if (kind.value() == "direct") {
    constexpr std::array<std::string_view, 0> no_keys{};
    Result<void> params_shape = closed_object(parameters, no_keys);
    if (!params_shape) {
      return Result<SolverSpec>::failure(params_shape.error());
    }
    return Result<SolverSpec>::success(DirectSolver{node});
  }
  if (kind.value() == "enumerated") {
    constexpr std::array keys{"linear_method"sv, "max_iterations"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SolverSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> method_node = required(parameters, "linear_method");
    Result<const SourceNode*> iterations_node =
        required(parameters, "max_iterations");
    if (!method_node) {
      return Result<SolverSpec>::failure(method_node.error());
    }
    if (!iterations_node) {
      return Result<SolverSpec>::failure(iterations_node.error());
    }
    Result<std::string> method =
        trimmed_string(*method_node.value(), "linear_method");
    if (!method) {
      return Result<SolverSpec>::failure(method.error());
    }
    LinearMethod parsed_method;
    if (method.value() == "dense_pivoted") {
      parsed_method = LinearMethod::dense_pivoted;
    } else if (method.value() == "sparse_iterative") {
      parsed_method = LinearMethod::sparse_iterative;
    } else {
      return fail<SolverSpec>(*method_node.value(),
                              "analysis.unknown_linear_method",
                              "linear_method must be 'dense_pivoted' or "
                              "'sparse_iterative'");
    }
    Result<std::optional<BigNat>> iterations = optional_positive_natural(
        *iterations_node.value(), "max_iterations");
    if (!iterations) {
      return Result<SolverSpec>::failure(iterations.error());
    }
    return Result<SolverSpec>::success(EnumeratedSolver{
        parsed_method, std::move(iterations).value(), node});
  }
  if (kind.value() == "analytic") {
    constexpr std::array keys{"precision_bits"sv, "max_iterations"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SolverSpec>::failure(params_shape.error());
    }
    Result<const SourceNode*> precision_node =
        required(parameters, "precision_bits");
    Result<const SourceNode*> iterations_node =
        required(parameters, "max_iterations");
    if (!precision_node) {
      return Result<SolverSpec>::failure(precision_node.error());
    }
    if (!iterations_node) {
      return Result<SolverSpec>::failure(iterations_node.error());
    }
    Result<BigNat> precision =
        positive_natural(*precision_node.value(), "precision_bits");
    Result<std::optional<BigNat>> iterations = optional_positive_natural(
        *iterations_node.value(), "max_iterations");
    if (!precision) {
      return Result<SolverSpec>::failure(precision.error());
    }
    if (!iterations) {
      return Result<SolverSpec>::failure(iterations.error());
    }
    return Result<SolverSpec>::success(AnalyticSolver{
        std::move(precision).value(), std::move(iterations).value(), node});
  }
  if (kind.value() == "monte_carlo") {
    constexpr std::array keys{"replications"sv, "confidence_level"sv,
                              "interval_method"sv};
    Result<void> params_shape = closed_object(parameters, keys);
    if (!params_shape) {
      return Result<SolverSpec>::failure(params_shape.error());
    }
    for (const std::string_view key : keys) {
      Result<const SourceNode*> field = required(parameters, key);
      if (!field) {
        return Result<SolverSpec>::failure(field.error());
      }
    }
    Result<BigNat> replications =
        positive_natural(*parameters.find("replications"), "replications");
    Result<ExactRational> confidence = open_probability(
        *parameters.find("confidence_level"), "confidence_level");
    Result<std::string> interval = trimmed_string(
        *parameters.find("interval_method"), "interval_method");
    if (!replications) {
      return Result<SolverSpec>::failure(replications.error());
    }
    if (!confidence) {
      return Result<SolverSpec>::failure(confidence.error());
    }
    if (!interval) {
      return Result<SolverSpec>::failure(interval.error());
    }
    MonteCarloIntervalMethod interval_method;
    if (interval.value() == "exact_binomial") {
      interval_method = MonteCarloIntervalMethod::exact_binomial;
    } else if (interval.value() == "hoeffding") {
      interval_method = MonteCarloIntervalMethod::hoeffding;
    } else if (interval.value() == "none") {
      interval_method = MonteCarloIntervalMethod::none;
    } else {
      return fail<SolverSpec>(
          *parameters.find("interval_method"),
          "analysis.unknown_interval_method",
          "interval_method must be 'exact_binomial', 'hoeffding', or 'none'");
    }
    return Result<SolverSpec>::success(MonteCarloSolver{
        std::move(replications).value(), std::move(confidence).value(),
        interval_method, node});
  }
  return fail<SolverSpec>(*kind_node.value(), "analysis.unknown_solver_kind",
                          "unknown solver kind '" + kind.value() + "'");
}

[[nodiscard]] Result<std::vector<BigNat>> natural_array(
    const SourceNode& node, bool positive, std::string_view role) {
  if (node.kind() != SourceNodeKind::array || node.array_items().empty()) {
    return fail<std::vector<BigNat>>(
        node, "analysis.metric_array_nonempty",
        std::string(role) + " must be a nonempty array");
  }
  std::vector<BigNat> values;
  values.reserve(node.array_items().size());
  for (const SourceNode& item : node.array_items()) {
    Result<BigNat> value = positive ? positive_natural(item, role)
                                    : natural(item, role);
    if (!value) {
      return Result<std::vector<BigNat>>::failure(value.error());
    }
    if (contains_value(values, value.value())) {
      return fail<std::vector<BigNat>>(
          item, "analysis.duplicate_metric_query",
          std::string(role) + " must be duplicate-free");
    }
    values.push_back(std::move(value).value());
  }
  return Result<std::vector<BigNat>>::success(std::move(values));
}

[[nodiscard]] Result<std::vector<ExactRational>> decimal_array(
    const SourceNode& node, std::string_view role) {
  if (node.kind() != SourceNodeKind::array || node.array_items().empty()) {
    return fail<std::vector<ExactRational>>(
        node, "analysis.metric_array_nonempty",
        std::string(role) + " must be a nonempty array");
  }
  std::vector<ExactRational> values;
  values.reserve(node.array_items().size());
  for (const SourceNode& item : node.array_items()) {
    Result<ExactRational> value = decimal(item, role);
    if (!value) {
      return Result<std::vector<ExactRational>>::failure(value.error());
    }
    if (contains_value(values, value.value())) {
      return fail<std::vector<ExactRational>>(
          item, "analysis.duplicate_metric_query",
          std::string(role) + " must be duplicate-free");
    }
    values.push_back(std::move(value).value());
  }
  return Result<std::vector<ExactRational>>::success(std::move(values));
}

template <typename EmptyMetric>
[[nodiscard]] Result<MetricWire> empty_metric_parameters(
    const SourceNode& parameters) {
  constexpr std::array<std::string_view, 0> no_keys{};
  Result<void> shape = closed_object(parameters, no_keys);
  if (!shape) {
    return Result<MetricWire>::failure(shape.error());
  }
  return Result<MetricWire>::success(EmptyMetric{});
}

[[nodiscard]] Result<GapEventKind> gap_event(const SourceNode& node) {
  Result<std::string> value = trimmed_string(node, "event");
  if (!value) {
    return Result<GapEventKind>::failure(value.error());
  }
  if (value.value() == "departure") {
    return Result<GapEventKind>::success(GapEventKind::departure);
  }
  if (value.value() == "admission") {
    return Result<GapEventKind>::success(GapEventKind::admission);
  }
  if (value.value() == "busy_denial") {
    return Result<GapEventKind>::success(GapEventKind::busy_denial);
  }
  return fail<GapEventKind>(
      node, "analysis.unknown_event",
      "event must be 'departure', 'admission', or 'busy_denial'");
}

[[nodiscard]] Result<BinaryPredicateKind> binary_predicate(
    const SourceNode& node) {
  Result<std::string> value = trimmed_string(node, "predicate");
  if (!value) {
    return Result<BinaryPredicateKind>::failure(value.error());
  }
  if (value.value() == "busy") {
    return Result<BinaryPredicateKind>::success(BinaryPredicateKind::busy);
  }
  if (value.value() == "idle") {
    return Result<BinaryPredicateKind>::success(BinaryPredicateKind::idle);
  }
  if (value.value() == "busy_denial") {
    return Result<BinaryPredicateKind>::success(
        BinaryPredicateKind::busy_denial);
  }
  if (value.value() == "threshold_above") {
    return Result<BinaryPredicateKind>::success(
        BinaryPredicateKind::threshold_above);
  }
  return fail<BinaryPredicateKind>(
      node, "analysis.unknown_predicate",
      "predicate must be 'busy', 'idle', 'busy_denial', or "
      "'threshold_above'");
}

[[nodiscard]] Result<HitSet> hit_set(const SourceNode& node) {
  constexpr std::array keys{"kind"sv, "level"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<HitSet>::failure(shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  Result<const SourceNode*> level_node = required(node, "level");
  if (!kind_node) {
    return Result<HitSet>::failure(kind_node.error());
  }
  if (!level_node) {
    return Result<HitSet>::failure(level_node.error());
  }
  Result<std::string> kind = trimmed_string(*kind_node.value(), "set kind");
  Result<BigNat> level = natural(*level_node.value(), "set level");
  if (!kind) {
    return Result<HitSet>::failure(kind.error());
  }
  if (!level) {
    return Result<HitSet>::failure(level.error());
  }
  HitSetKind parsed_kind;
  if (kind.value() == "at_or_above") {
    parsed_kind = HitSetKind::at_or_above;
  } else if (kind.value() == "at_or_below") {
    parsed_kind = HitSetKind::at_or_below;
  } else if (kind.value() == "equal") {
    parsed_kind = HitSetKind::equal;
  } else {
    return fail<HitSet>(*kind_node.value(), "analysis.unknown_hit_set",
                        "set kind must be 'at_or_above', 'at_or_below', or "
                        "'equal'");
  }
  return Result<HitSet>::success(
      HitSet{parsed_kind, std::move(level).value()});
}

[[nodiscard]] Result<FifoDelayWire> fifo_delay_wire(
    const SourceNode& parameters, bool conditioned) {
  if (parameters.kind() != SourceNodeKind::object) {
    return fail<FifoDelayWire>(parameters, "analysis.expected_object",
                               "FIFO delay parameters must be an object");
  }
  if (conditioned) {
    constexpr std::array union_keys{"output"sv, "horizon"sv,
                                    "probability"sv, "order"sv,
                                    "condition"sv};
    Result<void> union_shape = closed_object(parameters, union_keys);
    if (!union_shape) {
      return Result<FifoDelayWire>::failure(union_shape.error());
    }
  } else {
    constexpr std::array union_keys{"output"sv, "horizon"sv,
                                    "probability"sv, "order"sv};
    Result<void> union_shape = closed_object(parameters, union_keys);
    if (!union_shape) {
      return Result<FifoDelayWire>::failure(union_shape.error());
    }
  }
  Result<const SourceNode*> output_node = required(parameters, "output");
  if (!output_node) {
    return Result<FifoDelayWire>::failure(output_node.error());
  }
  Result<std::string> output =
      trimmed_string(*output_node.value(), "FIFO output");
  if (!output) {
    return Result<FifoDelayWire>::failure(output.error());
  }
  if (output.value() == "pmf" || output.value() == "tail") {
    if (conditioned) {
      constexpr std::array keys{"output"sv, "horizon"sv, "condition"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
      if (parameters.find("condition") == nullptr) {
        return fail<FifoDelayWire>(parameters, "analysis.missing_key",
                                   "missing required key 'condition'");
      }
    } else {
      constexpr std::array keys{"output"sv, "horizon"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
    }
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    if (!horizon_node) {
      return Result<FifoDelayWire>::failure(horizon_node.error());
    }
    Result<BigNat> horizon = natural(*horizon_node.value(), "FIFO horizon");
    if (!horizon) {
      return Result<FifoDelayWire>::failure(horizon.error());
    }
    if (output.value() == "pmf") {
      return Result<FifoDelayWire>::success(
          FifoDelayPmfMetric{std::move(horizon).value()});
    }
    return Result<FifoDelayWire>::success(
        FifoDelayTailMetric{std::move(horizon).value()});
  }
  if (output.value() == "quantile") {
    if (conditioned) {
      constexpr std::array keys{"output"sv, "probability"sv,
                                "condition"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
      if (parameters.find("condition") == nullptr) {
        return fail<FifoDelayWire>(parameters, "analysis.missing_key",
                                   "missing required key 'condition'");
      }
    } else {
      constexpr std::array keys{"output"sv, "probability"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
    }
    Result<const SourceNode*> probability_node =
        required(parameters, "probability");
    if (!probability_node) {
      return Result<FifoDelayWire>::failure(probability_node.error());
    }
    Result<ExactRational> probability = open_probability(
        *probability_node.value(), "FIFO quantile probability");
    if (!probability) {
      return Result<FifoDelayWire>::failure(probability.error());
    }
    return Result<FifoDelayWire>::success(
        FifoDelayQuantileMetric{std::move(probability).value()});
  }
  if (output.value() == "moment") {
    if (conditioned) {
      constexpr std::array keys{"output"sv, "order"sv, "condition"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
      if (parameters.find("condition") == nullptr) {
        return fail<FifoDelayWire>(parameters, "analysis.missing_key",
                                   "missing required key 'condition'");
      }
    } else {
      constexpr std::array keys{"output"sv, "order"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<FifoDelayWire>::failure(shape.error());
      }
    }
    Result<const SourceNode*> order_node = required(parameters, "order");
    if (!order_node) {
      return Result<FifoDelayWire>::failure(order_node.error());
    }
    Result<BigNat> order = positive_natural(*order_node.value(), "FIFO order");
    if (!order) {
      return Result<FifoDelayWire>::failure(order.error());
    }
    return Result<FifoDelayWire>::success(
        FifoDelayMomentMetric{std::move(order).value()});
  }
  return fail<FifoDelayWire>(
      *output_node.value(), "analysis.unknown_fifo_output",
      "FIFO output must be 'pmf', 'tail', 'quantile', or 'moment'");
}

[[nodiscard]] Result<FifoCondition> fifo_condition(const SourceNode& node) {
  constexpr std::array keys{"kind"sv, "value"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<FifoCondition>::failure(shape.error());
  }
  Result<const SourceNode*> kind_node = required(node, "kind");
  Result<const SourceNode*> value_node = required(node, "value");
  if (!kind_node) {
    return Result<FifoCondition>::failure(kind_node.error());
  }
  if (!value_node) {
    return Result<FifoCondition>::failure(value_node.error());
  }
  Result<std::string> kind = trimmed_string(*kind_node.value(), "condition kind");
  if (!kind) {
    return Result<FifoCondition>::failure(kind.error());
  }
  if (kind.value() == "rank" || kind.value() == "batch") {
    Result<BigNat> value = positive_natural(*value_node.value(),
                                            "condition value");
    if (!value) {
      return Result<FifoCondition>::failure(value.error());
    }
    if (kind.value() == "rank") {
      return Result<FifoCondition>::success(
          RankCondition{std::move(value).value()});
    }
    return Result<FifoCondition>::success(
        BatchCondition{std::move(value).value()});
  }
  if (kind.value() == "class" || kind.value() == "phase") {
    Result<TypedLabel> value =
        typed_label(*value_node.value(), "condition value");
    if (!value) {
      return Result<FifoCondition>::failure(value.error());
    }
    if (kind.value() == "class") {
      return Result<FifoCondition>::success(
          ClassCondition{std::move(value).value()});
    }
    return Result<FifoCondition>::success(
        PhaseCondition{std::move(value).value()});
  }
  return fail<FifoCondition>(*kind_node.value(),
                             "analysis.unknown_fifo_condition",
                             "condition kind must be 'rank', 'batch', "
                             "'class', or 'phase'");
}

[[nodiscard]] Result<MetricWire> parse_metric_wire(
    std::string_view kind, const SourceNode& parameters,
    const SourceNode& kind_node) {
  if (kind == "stationary_throughput") {
    return empty_metric_parameters<StationaryThroughputMetric>(parameters);
  }
  if (kind == "stationary_empty_probability") {
    return empty_metric_parameters<StationaryEmptyProbabilityMetric>(
        parameters);
  }
  if (kind == "mean_sojourn") {
    return empty_metric_parameters<MeanSojournMetric>(parameters);
  }
  if (kind == "service_persistence") {
    return empty_metric_parameters<ServicePersistenceMetric>(parameters);
  }
  if (kind == "joint_backlog_covariance") {
    return empty_metric_parameters<JointBacklogCovarianceMetric>(parameters);
  }
  if (kind == "stationary_backlog_pmf") {
    constexpr std::array keys{"max_level"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    if (const SourceNode* max_level = parameters.find("max_level");
        max_level != nullptr) {
      Result<BigNat> parsed = natural(*max_level, "max_level");
      if (!parsed) {
        return Result<MetricWire>::failure(parsed.error());
      }
      return Result<MetricWire>::success(StationaryBacklogPmfMetric{
          std::optional<BigNat>(std::move(parsed).value())});
    }
    return Result<MetricWire>::success(
        StationaryBacklogPmfMetric{std::nullopt});
  }
  if (kind == "stationary_backlog_pgf") {
    constexpr std::array keys{"points"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> points_node = required(parameters, "points");
    if (!points_node) {
      return Result<MetricWire>::failure(points_node.error());
    }
    Result<std::vector<ExactRational>> points =
        decimal_array(*points_node.value(), "PGF points");
    if (!points) {
      return Result<MetricWire>::failure(points.error());
    }
    return Result<MetricWire>::success(
        StationaryBacklogPgfMetric{std::move(points).value()});
  }
  if (kind == "stationary_backlog_moment") {
    constexpr std::array keys{"order"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> order_node = required(parameters, "order");
    if (!order_node) {
      return Result<MetricWire>::failure(order_node.error());
    }
    Result<BigNat> order = positive_natural(*order_node.value(), "order");
    if (!order) {
      return Result<MetricWire>::failure(order.error());
    }
    return Result<MetricWire>::success(
        StationaryBacklogMomentMetric{std::move(order).value()});
  }
  if (kind == "stationary_backlog_quantile") {
    constexpr std::array keys{"probability"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> probability_node =
        required(parameters, "probability");
    if (!probability_node) {
      return Result<MetricWire>::failure(probability_node.error());
    }
    Result<ExactRational> probability = open_probability(
        *probability_node.value(), "quantile probability");
    if (!probability) {
      return Result<MetricWire>::failure(probability.error());
    }
    return Result<MetricWire>::success(
        StationaryBacklogQuantileMetric{std::move(probability).value()});
  }
  if (kind == "stationary_backlog_tail") {
    constexpr std::array keys{"threshold"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> threshold_node = required(parameters, "threshold");
    if (!threshold_node) {
      return Result<MetricWire>::failure(threshold_node.error());
    }
    Result<BigNat> threshold = natural(*threshold_node.value(), "threshold");
    if (!threshold) {
      return Result<MetricWire>::failure(threshold.error());
    }
    return Result<MetricWire>::success(
        StationaryBacklogTailMetric{std::move(threshold).value()});
  }
  if (kind == "backlog_conditioned_service") {
    constexpr std::array keys{"levels"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> levels_node = required(parameters, "levels");
    if (!levels_node) {
      return Result<MetricWire>::failure(levels_node.error());
    }
    Result<std::vector<BigNat>> levels =
        natural_array(*levels_node.value(), false, "levels");
    if (!levels) {
      return Result<MetricWire>::failure(levels.error());
    }
    return Result<MetricWire>::success(
        BacklogConditionedServiceMetric{std::move(levels).value()});
  }
  if (kind == "stationary_edge_reward") {
    constexpr std::array keys{"reward"sv, "moment_order"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> reward_node = required(parameters, "reward");
    Result<const SourceNode*> order_node = required(parameters, "moment_order");
    if (!reward_node) {
      return Result<MetricWire>::failure(reward_node.error());
    }
    if (!order_node) {
      return Result<MetricWire>::failure(order_node.error());
    }
    Result<std::string> reward =
        trimmed_string(*reward_node.value(), "reward");
    Result<BigNat> order =
        positive_natural(*order_node.value(), "moment_order");
    if (!reward) {
      return Result<MetricWire>::failure(reward.error());
    }
    if (!order) {
      return Result<MetricWire>::failure(order.error());
    }
    EdgeRewardKind reward_kind;
    if (reward.value() == "increment") {
      reward_kind = EdgeRewardKind::increment;
    } else if (reward.value() == "departure") {
      reward_kind = EdgeRewardKind::departure;
    } else if (reward.value() == "arrival") {
      reward_kind = EdgeRewardKind::arrival;
    } else {
      return fail<MetricWire>(*reward_node.value(),
                              "analysis.unknown_edge_reward",
                              "reward must be 'increment', 'departure', or "
                              "'arrival'");
    }
    return Result<MetricWire>::success(StationaryEdgeRewardMetric{
        reward_kind, std::move(order).value()});
  }
  if (kind == "service_autocovariance" ||
      kind == "lagged_cross_queue_covariance") {
    constexpr std::array keys{"lags"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> lags_node = required(parameters, "lags");
    if (!lags_node) {
      return Result<MetricWire>::failure(lags_node.error());
    }
    Result<std::vector<BigNat>> lags =
        natural_array(*lags_node.value(), true, "lags");
    if (!lags) {
      return Result<MetricWire>::failure(lags.error());
    }
    if (kind == "service_autocovariance") {
      return Result<MetricWire>::success(
          ServiceAutocovarianceMetric{std::move(lags).value()});
    }
    return Result<MetricWire>::success(
        LaggedCrossQueueCovarianceMetric{std::move(lags).value()});
  }
  if (kind == "service_spectrum") {
    constexpr std::array keys{"frequencies"sv, "truncation_lag"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> frequencies_node =
        required(parameters, "frequencies");
    Result<const SourceNode*> lag_node = required(parameters, "truncation_lag");
    if (!frequencies_node) {
      return Result<MetricWire>::failure(frequencies_node.error());
    }
    if (!lag_node) {
      return Result<MetricWire>::failure(lag_node.error());
    }
    Result<std::vector<ExactRational>> frequencies =
        decimal_array(*frequencies_node.value(), "frequencies");
    Result<BigNat> lag =
        positive_natural(*lag_node.value(), "truncation_lag");
    if (!frequencies) {
      return Result<MetricWire>::failure(frequencies.error());
    }
    if (!lag) {
      return Result<MetricWire>::failure(lag.error());
    }
    return Result<MetricWire>::success(ServiceSpectrumMetric{
        std::move(frequencies).value(), std::move(lag).value()});
  }
  if (kind == "service_window_count") {
    constexpr std::array keys{"width"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> width_node = required(parameters, "width");
    if (!width_node) {
      return Result<MetricWire>::failure(width_node.error());
    }
    Result<BigNat> width = positive_natural(*width_node.value(), "width");
    if (!width) {
      return Result<MetricWire>::failure(width.error());
    }
    return Result<MetricWire>::success(
        ServiceWindowCountMetric{std::move(width).value()});
  }
  if (kind == "mean_event_gap") {
    constexpr std::array keys{"event"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> event_node = required(parameters, "event");
    if (!event_node) {
      return Result<MetricWire>::failure(event_node.error());
    }
    Result<GapEventKind> event = gap_event(*event_node.value());
    if (!event) {
      return Result<MetricWire>::failure(event.error());
    }
    return Result<MetricWire>::success(MeanEventGapMetric{event.value()});
  }
  if (kind == "event_gap_distribution") {
    constexpr std::array keys{"event"sv, "horizon"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> event_node = required(parameters, "event");
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    if (!event_node) {
      return Result<MetricWire>::failure(event_node.error());
    }
    if (!horizon_node) {
      return Result<MetricWire>::failure(horizon_node.error());
    }
    Result<GapEventKind> event = gap_event(*event_node.value());
    Result<BigNat> horizon = natural(*horizon_node.value(), "horizon");
    if (!event) {
      return Result<MetricWire>::failure(event.error());
    }
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    return Result<MetricWire>::success(EventGapDistributionMetric{
        event.value(), std::move(horizon).value()});
  }
  if (kind == "mean_binary_run" || kind == "binary_run_distribution") {
    if (kind == "mean_binary_run") {
      constexpr std::array union_keys{"predicate"sv, "threshold"sv};
      Result<void> union_shape = closed_object(parameters, union_keys);
      if (!union_shape) {
        return Result<MetricWire>::failure(union_shape.error());
      }
    } else {
      constexpr std::array union_keys{"predicate"sv, "threshold"sv,
                                      "horizon"sv};
      Result<void> union_shape = closed_object(parameters, union_keys);
      if (!union_shape) {
        return Result<MetricWire>::failure(union_shape.error());
      }
    }
    Result<const SourceNode*> predicate_node =
        required(parameters, "predicate");
    if (!predicate_node) {
      return Result<MetricWire>::failure(predicate_node.error());
    }
    Result<BinaryPredicateKind> predicate =
        binary_predicate(*predicate_node.value());
    if (!predicate) {
      return Result<MetricWire>::failure(predicate.error());
    }
    const bool threshold =
        predicate.value() == BinaryPredicateKind::threshold_above;
    if (kind == "mean_binary_run") {
      if (threshold) {
        constexpr std::array keys{"predicate"sv, "threshold"sv};
        Result<void> shape = closed_object(parameters, keys);
        if (!shape) {
          return Result<MetricWire>::failure(shape.error());
        }
        Result<const SourceNode*> threshold_node =
            required(parameters, "threshold");
        if (!threshold_node) {
          return Result<MetricWire>::failure(threshold_node.error());
        }
        Result<BigNat> value = natural(*threshold_node.value(), "threshold");
        if (!value) {
          return Result<MetricWire>::failure(value.error());
        }
        return Result<MetricWire>::success(MeanBinaryRunMetric{
            predicate.value(), std::optional<BigNat>(std::move(value).value())});
      }
      constexpr std::array keys{"predicate"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<MetricWire>::failure(shape.error());
      }
      return Result<MetricWire>::success(
          MeanBinaryRunMetric{predicate.value(), std::nullopt});
    }

    if (threshold) {
      constexpr std::array keys{"predicate"sv, "threshold"sv, "horizon"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<MetricWire>::failure(shape.error());
      }
      Result<const SourceNode*> threshold_node =
          required(parameters, "threshold");
      Result<const SourceNode*> horizon_node = required(parameters, "horizon");
      if (!threshold_node) {
        return Result<MetricWire>::failure(threshold_node.error());
      }
      if (!horizon_node) {
        return Result<MetricWire>::failure(horizon_node.error());
      }
      Result<BigNat> threshold_value =
          natural(*threshold_node.value(), "threshold");
      Result<BigNat> horizon = natural(*horizon_node.value(), "horizon");
      if (!threshold_value) {
        return Result<MetricWire>::failure(threshold_value.error());
      }
      if (!horizon) {
        return Result<MetricWire>::failure(horizon.error());
      }
      return Result<MetricWire>::success(BinaryRunDistributionMetric{
          predicate.value(),
          std::optional<BigNat>(std::move(threshold_value).value()),
          std::move(horizon).value()});
    }
    constexpr std::array keys{"predicate"sv, "horizon"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    if (!horizon_node) {
      return Result<MetricWire>::failure(horizon_node.error());
    }
    Result<BigNat> horizon = natural(*horizon_node.value(), "horizon");
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    return Result<MetricWire>::success(BinaryRunDistributionMetric{
        predicate.value(), std::nullopt, std::move(horizon).value()});
  }
  if (kind == "first_hit" || kind == "threshold_excursion") {
    constexpr std::array keys{"set"sv, "horizon"sv, "include_mean"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    for (const std::string_view key : keys) {
      Result<const SourceNode*> field = required(parameters, key);
      if (!field) {
        return Result<MetricWire>::failure(field.error());
      }
    }
    Result<HitSet> set = hit_set(*parameters.find("set"));
    Result<BigNat> horizon = natural(*parameters.find("horizon"), "horizon");
    Result<bool> include_mean =
        boolean_value(*parameters.find("include_mean"), "include_mean");
    if (!set) {
      return Result<MetricWire>::failure(set.error());
    }
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    if (!include_mean) {
      return Result<MetricWire>::failure(include_mean.error());
    }
    if (kind == "first_hit") {
      return Result<MetricWire>::success(FirstHitMetric{
          std::move(set).value(), std::move(horizon).value(),
          include_mean.value()});
    }
    return Result<MetricWire>::success(ThresholdExcursionMetric{
        std::move(set).value(), std::move(horizon).value(),
        include_mean.value()});
  }
  if (kind == "transient_backlog_law") {
    constexpr std::array keys{"horizons"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> horizons_node = required(parameters, "horizons");
    if (!horizons_node) {
      return Result<MetricWire>::failure(horizons_node.error());
    }
    Result<std::vector<BigNat>> horizons =
        natural_array(*horizons_node.value(), false, "horizons");
    if (!horizons) {
      return Result<MetricWire>::failure(horizons.error());
    }
    return Result<MetricWire>::success(
        TransientBacklogLawMetric{std::move(horizons).value()});
  }
  if (kind == "fifo_delay") {
    Result<FifoDelayWire> request = fifo_delay_wire(parameters, false);
    if (!request) {
      return Result<MetricWire>::failure(request.error());
    }
    return Result<MetricWire>::success(
        FifoDelayMetric{std::move(request).value()});
  }
  if (kind == "fifo_delay_conditioned") {
    Result<FifoDelayWire> request = fifo_delay_wire(parameters, true);
    if (!request) {
      return Result<MetricWire>::failure(request.error());
    }
    Result<const SourceNode*> condition_node =
        required(parameters, "condition");
    if (!condition_node) {
      return Result<MetricWire>::failure(condition_node.error());
    }
    Result<FifoCondition> condition = fifo_condition(*condition_node.value());
    if (!condition) {
      return Result<MetricWire>::failure(condition.error());
    }
    return Result<MetricWire>::success(FifoDelayConditionedMetric{
        std::move(request).value(), std::move(condition).value()});
  }
  if (kind == "counterfactual_opportunity_gap") {
    constexpr std::array keys{"convention_id"sv, "horizon"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> convention_node =
        required(parameters, "convention_id");
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    if (!convention_node) {
      return Result<MetricWire>::failure(convention_node.error());
    }
    if (!horizon_node) {
      return Result<MetricWire>::failure(horizon_node.error());
    }
    Result<TypedLabel> convention =
        typed_label(*convention_node.value(), "convention_id");
    Result<BigNat> horizon = natural(*horizon_node.value(), "horizon");
    if (!convention) {
      return Result<MetricWire>::failure(convention.error());
    }
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    return Result<MetricWire>::success(CounterfactualOpportunityGapMetric{
        std::move(convention).value(), std::move(horizon).value()});
  }
  if (kind == "joint_backlog_event") {
    constexpr std::array keys{"relation"sv, "thresholds"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> relation_node = required(parameters, "relation");
    Result<const SourceNode*> thresholds_node =
        required(parameters, "thresholds");
    if (!relation_node) {
      return Result<MetricWire>::failure(relation_node.error());
    }
    if (!thresholds_node) {
      return Result<MetricWire>::failure(thresholds_node.error());
    }
    Result<std::string> relation =
        trimmed_string(*relation_node.value(), "relation");
    if (!relation) {
      return Result<MetricWire>::failure(relation.error());
    }
    JointBacklogRelation relation_value;
    if (relation.value() == "all_at_or_above") {
      relation_value = JointBacklogRelation::all_at_or_above;
    } else if (relation.value() == "any_at_or_above") {
      relation_value = JointBacklogRelation::any_at_or_above;
    } else {
      return fail<MetricWire>(*relation_node.value(),
                              "analysis.unknown_joint_relation",
                              "relation must be 'all_at_or_above' or "
                              "'any_at_or_above'");
    }
    if (thresholds_node.value()->kind() != SourceNodeKind::array ||
        thresholds_node.value()->array_items().empty()) {
      return fail<MetricWire>(*thresholds_node.value(),
                              "analysis.thresholds_nonempty",
                              "thresholds must be a nonempty positional array");
    }
    std::vector<BigNat> thresholds;
    thresholds.reserve(thresholds_node.value()->array_items().size());
    for (const SourceNode& threshold_node :
         thresholds_node.value()->array_items()) {
      Result<BigNat> threshold = natural(threshold_node, "threshold");
      if (!threshold) {
        return Result<MetricWire>::failure(threshold.error());
      }
      // Positional thresholds may repeat by design.
      thresholds.push_back(std::move(threshold).value());
    }
    return Result<MetricWire>::success(JointBacklogEventMetric{
        relation_value, std::move(thresholds)});
  }
  if (kind == "joint_delay") {
    constexpr std::array union_keys{"sampling"sv, "lag"sv, "horizon"sv};
    Result<void> union_shape = closed_object(parameters, union_keys);
    if (!union_shape) {
      return Result<MetricWire>::failure(union_shape.error());
    }
    Result<const SourceNode*> sampling_node = required(parameters, "sampling");
    if (!sampling_node) {
      return Result<MetricWire>::failure(sampling_node.error());
    }
    Result<std::string> sampling =
        trimmed_string(*sampling_node.value(), "joint delay sampling");
    if (!sampling) {
      return Result<MetricWire>::failure(sampling.error());
    }
    JointDelaySampling sampling_value;
    std::optional<BigNat> lag;
    if (sampling.value() == "lagged") {
      constexpr std::array keys{"sampling"sv, "lag"sv, "horizon"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<MetricWire>::failure(shape.error());
      }
      Result<const SourceNode*> lag_node = required(parameters, "lag");
      if (!lag_node) {
        return Result<MetricWire>::failure(lag_node.error());
      }
      Result<BigNat> parsed_lag = natural(*lag_node.value(), "lag");
      if (!parsed_lag) {
        return Result<MetricWire>::failure(parsed_lag.error());
      }
      lag = std::move(parsed_lag).value();
      sampling_value = JointDelaySampling::lagged;
    } else if (sampling.value() == "coincident" ||
               sampling.value() == "independent_palm") {
      constexpr std::array keys{"sampling"sv, "horizon"sv};
      Result<void> shape = closed_object(parameters, keys);
      if (!shape) {
        return Result<MetricWire>::failure(shape.error());
      }
      sampling_value = sampling.value() == "coincident"
                           ? JointDelaySampling::coincident
                           : JointDelaySampling::independent_palm;
    } else {
      return fail<MetricWire>(
          *sampling_node.value(), "analysis.unknown_joint_delay_sampling",
          "joint delay sampling must be 'coincident', 'independent_palm', or "
          "'lagged'");
    }
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    if (!horizon_node) {
      return Result<MetricWire>::failure(horizon_node.error());
    }
    Result<BigNat> horizon = natural(*horizon_node.value(), "horizon");
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    return Result<MetricWire>::success(JointDelayMetric{
        sampling_value, std::move(lag), std::move(horizon).value()});
  }
  if (kind == "ordered_schedule_sequence") {
    constexpr std::array keys{"horizon"sv, "retain_full_schedule"sv};
    Result<void> shape = closed_object(parameters, keys);
    if (!shape) {
      return Result<MetricWire>::failure(shape.error());
    }
    Result<const SourceNode*> horizon_node = required(parameters, "horizon");
    Result<const SourceNode*> retain_node =
        required(parameters, "retain_full_schedule");
    if (!horizon_node) {
      return Result<MetricWire>::failure(horizon_node.error());
    }
    if (!retain_node) {
      return Result<MetricWire>::failure(retain_node.error());
    }
    Result<BigNat> horizon =
        positive_natural(*horizon_node.value(), "horizon");
    Result<bool> retain =
        boolean_value(*retain_node.value(), "retain_full_schedule");
    if (!horizon) {
      return Result<MetricWire>::failure(horizon.error());
    }
    if (!retain) {
      return Result<MetricWire>::failure(retain.error());
    }
    return Result<MetricWire>::success(OrderedScheduleSequenceMetric{
        std::move(horizon).value(), retain.value()});
  }
  return fail<MetricWire>(kind_node, "analysis.unknown_metric_kind",
                          "unknown analysis-v1 metric kind '" +
                              std::string(kind) + "'");
}

struct MetricDraft final {
  std::string id;
  MetricWire metric;
  SourceNode source;
};

[[nodiscard]] Result<std::vector<MetricDraft>> parse_metrics(
    const SourceNode& node) {
  if (node.kind() != SourceNodeKind::array || node.array_items().empty()) {
    return fail<std::vector<MetricDraft>>(
        node, "analysis.metrics_nonempty",
        "metrics must be a nonempty ordered array");
  }
  std::vector<MetricDraft> metrics;
  std::vector<std::string> ids;
  metrics.reserve(node.array_items().size());
  for (const SourceNode& metric_node : node.array_items()) {
    constexpr std::array keys{"id"sv, "kind"sv, "parameters"sv};
    Result<void> shape = closed_object(metric_node, keys);
    if (!shape) {
      return Result<std::vector<MetricDraft>>::failure(shape.error());
    }
    for (const std::string_view key : keys) {
      Result<const SourceNode*> field = required(metric_node, key);
      if (!field) {
        return Result<std::vector<MetricDraft>>::failure(field.error());
      }
    }
    Result<std::string> id =
        trimmed_string(*metric_node.find("id"), "metric id");
    Result<std::string> kind =
        trimmed_string(*metric_node.find("kind"), "metric kind");
    if (!id) {
      return Result<std::vector<MetricDraft>>::failure(id.error());
    }
    if (!kind) {
      return Result<std::vector<MetricDraft>>::failure(kind.error());
    }
    if (contains_value(ids, id.value())) {
      return fail<std::vector<MetricDraft>>(
          *metric_node.find("id"), "analysis.duplicate_metric_id",
          "metric ids must be unique");
    }
    Result<MetricWire> metric = parse_metric_wire(
        kind.value(), *metric_node.find("parameters"),
        *metric_node.find("kind"));
    if (!metric) {
      return Result<std::vector<MetricDraft>>::failure(metric.error());
    }
    ids.push_back(id.value());
    metrics.push_back(MetricDraft{std::move(id).value(),
                                  std::move(metric).value(), metric_node});
  }
  return Result<std::vector<MetricDraft>>::success(std::move(metrics));
}

[[nodiscard]] Result<SurrogateSelection> parse_surrogate(
    const SourceNode& node) {
  constexpr std::array keys{"id"sv, "version"sv, "parameters"sv};
  Result<void> shape = closed_object(node, keys);
  if (!shape) {
    return Result<SurrogateSelection>::failure(shape.error());
  }
  for (const std::string_view key : keys) {
    Result<const SourceNode*> field = required(node, key);
    if (!field) {
      return Result<SurrogateSelection>::failure(field.error());
    }
  }
  Result<std::string> id = trimmed_string(*node.find("id"), "surrogate id");
  if (!id) {
    return Result<SurrogateSelection>::failure(id.error());
  }
  std::optional<std::string> version;
  const SourceNode& version_node = *node.find("version");
  if (version_node.kind() != SourceNodeKind::null_value) {
    if (version_node.kind() != SourceNodeKind::string ||
        version_node.string_value()->empty()) {
      return fail<SurrogateSelection>(
          version_node, "analysis.invalid_surrogate_version",
          "surrogate version must be null or a nonempty string");
    }
    version = *version_node.string_value();
  }
  const SourceNode& parameters = *node.find("parameters");
  Result<void> safe = validate_opaque_provider_object(parameters);
  if (!safe) {
    return Result<SurrogateSelection>::failure(safe.error());
  }
  return Result<SurrogateSelection>::success(SurrogateSelection{
      std::move(id).value(), std::move(version), parameters, node});
}

}  // namespace

Result<AnalysisSpec> parse_analysis_spec_v1(const ParsedDocument& document) {
  const SourceNode& root = document.root;
  constexpr std::array keys{
      "analysis_schema_version"sv, "targets"sv,   "metrics"sv,
      "surrogate"sv,               "resolution"sv, "selection"sv,
      "solver"sv};
  Result<void> shape = closed_object(root, keys);
  if (!shape) {
    return Result<AnalysisSpec>::failure(shape.error());
  }
  for (const std::string_view key : keys) {
    Result<const SourceNode*> field = required(root, key);
    if (!field) {
      return Result<AnalysisSpec>::failure(field.error());
    }
  }

  Result<std::string> version = trimmed_string(
      *root.find("analysis_schema_version"), "analysis_schema_version");
  if (!version) {
    return Result<AnalysisSpec>::failure(version.error());
  }
  if (version.value() != kAnalysisSchemaVersion) {
    return fail<AnalysisSpec>(
        *root.find("analysis_schema_version"),
        "analysis.unsupported_schema_version",
        "analysis_schema_version must be exactly '" +
            std::string(kAnalysisSchemaVersion) + "'");
  }

  Result<TargetSet> targets = parse_targets(*root.find("targets"));
  Result<std::vector<MetricDraft>> metric_drafts =
      parse_metrics(*root.find("metrics"));
  Result<SurrogateSelection> surrogate =
      parse_surrogate(*root.find("surrogate"));
  Result<ResolutionEnvelope> resolution =
      parse_resolution(*root.find("resolution"));
  Result<SelectionSpec> selection = parse_selection(*root.find("selection"));
  Result<SolverSpec> solver = parse_solver(*root.find("solver"));
  if (!targets) {
    return Result<AnalysisSpec>::failure(targets.error());
  }
  if (!metric_drafts) {
    return Result<AnalysisSpec>::failure(metric_drafts.error());
  }
  if (!surrogate) {
    return Result<AnalysisSpec>::failure(surrogate.error());
  }
  if (!resolution) {
    return Result<AnalysisSpec>::failure(resolution.error());
  }
  if (!selection) {
    return Result<AnalysisSpec>::failure(selection.error());
  }
  if (!solver) {
    return Result<AnalysisSpec>::failure(solver.error());
  }

  // This is a wire-shape relation, not metric capability semantics: the
  // positional threshold vector has exactly one entry per authored target.
  for (const MetricDraft& draft : metric_drafts.value()) {
    const auto* joint = std::get_if<JointBacklogEventMetric>(&draft.metric);
    if (joint != nullptr &&
        joint->thresholds.size() != targets.value().queue_ids.size()) {
      const SourceNode* parameters = draft.source.find("parameters");
      const SourceNode* thresholds =
          parameters == nullptr ? nullptr : parameters->find("thresholds");
      return fail<AnalysisSpec>(
          thresholds == nullptr ? draft.source : *thresholds,
          "analysis.joint_threshold_target_count",
          "joint_backlog_event requires exactly one positional threshold "
          "per analysis target");
    }
  }

  if (std::holds_alternative<MonteCarloSolver>(solver.value()) &&
      !resolution.value().sampling.max_generator_draws.has_value()) {
    return fail<AnalysisSpec>(
        *root.find("resolution")->find("sampling")
             ->find("max_generator_draws"),
        "analysis.monte_carlo_requires_draw_grant",
        "monte_carlo requires a nonnull "
        "resolution.sampling.max_generator_draws hard grant");
  }

  auto context = std::make_shared<const AnalysisContext>(AnalysisContext{
      std::move(targets).value(), std::move(resolution).value(),
      std::move(selection).value(), std::move(solver).value()});
  std::vector<MetricNode> metrics;
  metrics.reserve(metric_drafts.value().size());
  for (MetricDraft& draft : metric_drafts.value()) {
    metrics.push_back(MetricNode{std::move(draft.id), std::move(draft.metric),
                                 std::move(draft.source), context});
  }

  return Result<AnalysisSpec>::success(AnalysisSpec{
      std::move(version).value(), std::move(context), std::move(metrics),
      std::move(surrogate).value(), root});
}

}  // namespace mwperf
