#include "mwperf/config/document.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>
#include <variant>
#include <vector>

#include <yaml-cpp/yaml.h>
#include <yaml-cpp/eventhandler.h>
#include <yaml-cpp/parser.h>

#include "mwperf/diagnostic.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct SourceNode::Storage final {
  using Value = std::variant<std::monostate, bool, std::string,
                             std::vector<SourceNode>,
                             std::vector<SourceObjectMember>>;

  SourceNodeKind kind;
  SourceLocation location;
  std::string json_pointer;
  Value value;
};

SourceNode::SourceNode(std::shared_ptr<const Storage> storage) noexcept
    : storage_(std::move(storage)) {}

SourceNode SourceNode::make_null(SourceLocation location,
                                 std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::null_value, std::move(location), std::move(json_pointer),
      std::monostate{}}));
}

SourceNode SourceNode::make_boolean(const bool value, SourceLocation location,
                                    std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::boolean, std::move(location), std::move(json_pointer),
      value}));
}

SourceNode SourceNode::make_number(std::string lexeme,
                                   SourceLocation location,
                                   std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::number, std::move(location), std::move(json_pointer),
      std::move(lexeme)}));
}

SourceNode SourceNode::make_string(std::string value, SourceLocation location,
                                   std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::string, std::move(location), std::move(json_pointer),
      std::move(value)}));
}

SourceNode SourceNode::make_array(std::vector<SourceNode> items,
                                  SourceLocation location,
                                  std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::array, std::move(location), std::move(json_pointer),
      std::move(items)}));
}

SourceNode SourceNode::make_object(
    std::vector<SourceObjectMember> members, SourceLocation location,
    std::string json_pointer) {
  return SourceNode(std::make_shared<Storage>(Storage{
      SourceNodeKind::object, std::move(location), std::move(json_pointer),
      std::move(members)}));
}

SourceNodeKind SourceNode::kind() const noexcept { return storage_->kind; }

const SourceLocation& SourceNode::location() const noexcept {
  return storage_->location;
}

std::string_view SourceNode::json_pointer() const noexcept {
  return storage_->json_pointer;
}

const bool* SourceNode::boolean_value() const noexcept {
  return storage_->kind == SourceNodeKind::boolean
             ? std::get_if<bool>(&storage_->value)
             : nullptr;
}

const std::string* SourceNode::number_lexeme() const noexcept {
  return storage_->kind == SourceNodeKind::number
             ? std::get_if<std::string>(&storage_->value)
             : nullptr;
}

const std::string* SourceNode::string_value() const noexcept {
  return storage_->kind == SourceNodeKind::string
             ? std::get_if<std::string>(&storage_->value)
             : nullptr;
}

std::span<const SourceNode> SourceNode::array_items() const noexcept {
  if (storage_->kind != SourceNodeKind::array) {
    return {};
  }
  const auto* items = std::get_if<std::vector<SourceNode>>(&storage_->value);
  return items == nullptr ? std::span<const SourceNode>{}
                          : std::span<const SourceNode>{*items};
}

std::span<const SourceObjectMember> SourceNode::object_members() const
    noexcept {
  if (storage_->kind != SourceNodeKind::object) {
    return {};
  }
  const auto* members =
      std::get_if<std::vector<SourceObjectMember>>(&storage_->value);
  return members == nullptr ? std::span<const SourceObjectMember>{}
                            : std::span<const SourceObjectMember>{*members};
}

const SourceObjectMember* SourceNode::find_member(
    const std::string_view key) const noexcept {
  for (const SourceObjectMember& member : object_members()) {
    if (member.key == key) {
      return &member;
    }
  }
  return nullptr;
}

const SourceNode* SourceNode::find(const std::string_view key) const noexcept {
  const SourceObjectMember* member = find_member(key);
  return member == nullptr ? nullptr : &member->value;
}

SourceProvenance authored_provenance(const SourceNode& node) {
  return SourceProvenance{node.location(), std::string(node.json_pointer()),
                          false};
}

SourceProvenance defaulted_provenance(std::string canonical_json_pointer) {
  return SourceProvenance{std::nullopt, std::move(canonical_json_pointer), true};
}

std::string escape_json_pointer_token(const std::string_view token) {
  std::string escaped;
  escaped.reserve(token.size());
  for (const char byte : token) {
    if (byte == '~') {
      escaped += "~0";
    } else if (byte == '/') {
      escaped += "~1";
    } else {
      escaped.push_back(byte);
    }
  }
  return escaped;
}

namespace {

constexpr std::size_t kMaximumDocumentNesting = 1024U;

[[nodiscard]] std::string source_note(const SourceLocation& location) {
  return "line " + std::to_string(location.line) + ", column " +
         std::to_string(location.column) + ", byte " +
         std::to_string(location.byte_offset);
}

[[nodiscard]] Diagnostic located_error(const std::string& code,
                                       const std::string& message,
                                       const SourceLocation& location,
                                       const std::string_view pointer,
                                       std::vector<std::string> notes = {}) {
  notes.insert(notes.begin(), source_note(location));
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = code,
      .message = message,
      .authored_path = location.authored_path,
      .json_pointer = std::string(pointer),
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic path_error(const std::string& code,
                                    const std::string& message,
                                    const std::string& path) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = code,
      .message = message,
      .authored_path = path,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] bool is_utf8_continuation(const unsigned char byte) noexcept {
  return (byte & 0xc0U) == 0x80U;
}

[[nodiscard]] std::optional<std::size_t> first_invalid_utf8(
    const std::string_view text) noexcept {
  std::size_t index = 0;
  while (index < text.size()) {
    const auto lead = static_cast<unsigned char>(text[index]);
    if (lead <= 0x7fU) {
      ++index;
      continue;
    }

    std::size_t width = 0;
    std::uint32_t minimum = 0;
    std::uint32_t value = 0;
    if (lead >= 0xc2U && lead <= 0xdfU) {
      width = 2U;
      minimum = 0x80U;
      value = lead & 0x1fU;
    } else if (lead >= 0xe0U && lead <= 0xefU) {
      width = 3U;
      minimum = 0x800U;
      value = lead & 0x0fU;
    } else if (lead >= 0xf0U && lead <= 0xf4U) {
      width = 4U;
      minimum = 0x10000U;
      value = lead & 0x07U;
    } else {
      return index;
    }
    if (text.size() - index < width) {
      return index;
    }
    for (std::size_t offset = 1U; offset < width; ++offset) {
      const auto continuation =
          static_cast<unsigned char>(text[index + offset]);
      if (!is_utf8_continuation(continuation)) {
        return index;
      }
      value = (value << 6U) | (continuation & 0x3fU);
    }
    if (value < minimum || value > 0x10ffffU ||
        (value >= 0xd800U && value <= 0xdfffU)) {
      return index;
    }
    index += width;
  }
  return std::nullopt;
}

void append_utf8(std::string& destination, const std::uint32_t value) {
  if (value <= 0x7fU) {
    destination.push_back(static_cast<char>(value));
  } else if (value <= 0x7ffU) {
    destination.push_back(static_cast<char>(0xc0U | (value >> 6U)));
    destination.push_back(static_cast<char>(0x80U | (value & 0x3fU)));
  } else if (value <= 0xffffU) {
    destination.push_back(static_cast<char>(0xe0U | (value >> 12U)));
    destination.push_back(
        static_cast<char>(0x80U | ((value >> 6U) & 0x3fU)));
    destination.push_back(static_cast<char>(0x80U | (value & 0x3fU)));
  } else {
    destination.push_back(static_cast<char>(0xf0U | (value >> 18U)));
    destination.push_back(
        static_cast<char>(0x80U | ((value >> 12U) & 0x3fU)));
    destination.push_back(
        static_cast<char>(0x80U | ((value >> 6U) & 0x3fU)));
    destination.push_back(static_cast<char>(0x80U | (value & 0x3fU)));
  }
}

[[nodiscard]] std::string append_pointer(const std::string_view parent,
                                         const std::string_view token) {
  std::string pointer(parent);
  pointer.push_back('/');
  pointer += escape_json_pointer_token(token);
  return pointer;
}

class JsonParser final {
 public:
  JsonParser(std::string_view text, std::string path)
      : text_(text), path_(std::move(path)) {}

  [[nodiscard]] Result<SourceNode> parse() {
    skip_whitespace();
    if (at_end()) {
      return Result<SourceNode>::failure(error_here(
          "document_empty", "a JSON document may not be empty", ""));
    }
    auto root = parse_value("", 0U);
    if (!root) {
      return root;
    }
    skip_whitespace();
    if (!at_end()) {
      return Result<SourceNode>::failure(error_here(
          "json_trailing_content",
          "a JSON document must contain exactly one root value", ""));
    }
    return root;
  }

 private:
  [[nodiscard]] bool at_end() const noexcept { return position_ == text_.size(); }

  [[nodiscard]] char peek() const noexcept {
    return at_end() ? '\0' : text_[position_];
  }

  [[nodiscard]] SourceLocation location() const {
    return SourceLocation{path_, line_, column_, position_};
  }

  void advance() noexcept {
    if (at_end()) {
      return;
    }
    const char byte = text_[position_++];
    if (byte == '\r') {
      ++line_;
      column_ = 1U;
      previous_was_carriage_return_ = true;
    } else if (byte == '\n') {
      if (!previous_was_carriage_return_) {
        ++line_;
      }
      column_ = 1U;
      previous_was_carriage_return_ = false;
    } else {
      ++column_;
      previous_was_carriage_return_ = false;
    }
  }

  void skip_whitespace() noexcept {
    while (!at_end()) {
      const char byte = peek();
      if (byte != ' ' && byte != '\t' && byte != '\r' && byte != '\n') {
        return;
      }
      advance();
    }
  }

  [[nodiscard]] Diagnostic error_here(const std::string& code,
                                      const std::string& message,
                                      const std::string_view pointer) const {
    return located_error(code, message, location(), pointer);
  }

  [[nodiscard]] Result<SourceNode> parse_value(const std::string& pointer,
                                                const std::size_t depth) {
    if (depth > kMaximumDocumentNesting) {
      Diagnostic diagnostic = error_here(
          "document_nesting_limit",
          "the document exceeds the supported structural nesting depth",
          pointer);
      diagnostic.category = DiagnosticCategory::resource_limit;
      return Result<SourceNode>::failure(std::move(diagnostic));
    }
    if (at_end()) {
      return Result<SourceNode>::failure(error_here(
          "json_unexpected_end", "a JSON value is missing", pointer));
    }

    const SourceLocation start = location();
    switch (peek()) {
      case '{':
        return parse_object(pointer, depth);
      case '[':
        return parse_array(pointer, depth);
      case '"': {
        auto value = parse_string(pointer);
        if (!value) {
          return Result<SourceNode>::failure(std::move(value.error()));
        }
        return Result<SourceNode>::success(SourceNode::make_string(
            std::move(value.value()), start, pointer));
      }
      case 't':
        return parse_literal("true", SourceNode::make_boolean(true, start, pointer),
                             pointer);
      case 'f':
        return parse_literal("false",
                             SourceNode::make_boolean(false, start, pointer),
                             pointer);
      case 'n':
        return parse_literal("null", SourceNode::make_null(start, pointer),
                             pointer);
      default:
        break;
    }

    if (text_.substr(position_, 3U) == "NaN" ||
        text_.substr(position_, 8U) == "Infinity" ||
        text_.substr(position_, 9U) == "-Infinity") {
      return Result<SourceNode>::failure(error_here(
          "document_nonfinite_number",
          "NaN and infinity are not accepted document scalars", pointer));
    }
    if (peek() == '-' || (peek() >= '0' && peek() <= '9')) {
      return parse_number(pointer, start);
    }
    return Result<SourceNode>::failure(error_here(
        "json_expected_value", "the token is not a JSON value", pointer));
  }

  [[nodiscard]] Result<SourceNode> parse_literal(
      const std::string_view spelling, SourceNode value,
      const std::string_view pointer) {
    if (text_.substr(position_, spelling.size()) != spelling) {
      return Result<SourceNode>::failure(error_here(
          "json_invalid_literal", "the token is not a JSON literal", pointer));
    }
    for (std::size_t index = 0; index < spelling.size(); ++index) {
      advance();
    }
    return Result<SourceNode>::success(std::move(value));
  }

  [[nodiscard]] Result<SourceNode> parse_object(const std::string& pointer,
                                                 const std::size_t depth) {
    const SourceLocation start = location();
    advance();
    skip_whitespace();
    std::vector<SourceObjectMember> members;
    std::unordered_map<std::string, SourceLocation> definitions;
    if (peek() == '}') {
      advance();
      return Result<SourceNode>::success(
          SourceNode::make_object({}, start, pointer));
    }

    while (true) {
      if (peek() != '"') {
        return Result<SourceNode>::failure(error_here(
            "json_object_key_not_string",
            "a JSON object key must be a double-quoted string", pointer));
      }
      const SourceLocation key_location = location();
      auto key_result = parse_string(pointer);
      if (!key_result) {
        return Result<SourceNode>::failure(std::move(key_result.error()));
      }
      std::string key = std::move(key_result.value());
      const std::string child_pointer = append_pointer(pointer, key);
      const auto [definition, inserted] =
          definitions.emplace(key, key_location);
      if (!inserted) {
        return Result<SourceNode>::failure(located_error(
            "duplicate_object_key", "duplicate object key '" + key + "'",
            key_location, child_pointer,
            {"first definition: " + source_note(definition->second),
             "duplicate definition: " + source_note(key_location)}));
      }

      skip_whitespace();
      if (peek() != ':') {
        return Result<SourceNode>::failure(error_here(
            "json_missing_colon",
            "an object key must be followed by a colon", child_pointer));
      }
      advance();
      skip_whitespace();
      auto value_result = parse_value(child_pointer, depth + 1U);
      if (!value_result) {
        return Result<SourceNode>::failure(std::move(value_result.error()));
      }
      members.push_back(SourceObjectMember{std::move(key), key_location,
                                           std::move(value_result.value())});

      skip_whitespace();
      if (peek() == '}') {
        advance();
        break;
      }
      if (peek() != ',') {
        return Result<SourceNode>::failure(error_here(
            "json_missing_comma",
            "object members must be separated by a comma", pointer));
      }
      advance();
      skip_whitespace();
      if (peek() == '}') {
        return Result<SourceNode>::failure(error_here(
            "json_trailing_comma", "JSON objects may not end with a comma",
            pointer));
      }
    }
    return Result<SourceNode>::success(
        SourceNode::make_object(std::move(members), start, pointer));
  }

  [[nodiscard]] Result<SourceNode> parse_array(const std::string& pointer,
                                                const std::size_t depth) {
    const SourceLocation start = location();
    advance();
    skip_whitespace();
    std::vector<SourceNode> items;
    if (peek() == ']') {
      advance();
      return Result<SourceNode>::success(
          SourceNode::make_array({}, start, pointer));
    }

    while (true) {
      const std::string child_pointer =
          append_pointer(pointer, std::to_string(items.size()));
      auto item = parse_value(child_pointer, depth + 1U);
      if (!item) {
        return Result<SourceNode>::failure(std::move(item.error()));
      }
      items.push_back(std::move(item.value()));
      skip_whitespace();
      if (peek() == ']') {
        advance();
        break;
      }
      if (peek() != ',') {
        return Result<SourceNode>::failure(error_here(
            "json_missing_comma",
            "array elements must be separated by a comma", pointer));
      }
      advance();
      skip_whitespace();
      if (peek() == ']') {
        return Result<SourceNode>::failure(error_here(
            "json_trailing_comma", "JSON arrays may not end with a comma",
            pointer));
      }
    }
    return Result<SourceNode>::success(
        SourceNode::make_array(std::move(items), start, pointer));
  }

  [[nodiscard]] static int hex_value(const char byte) noexcept {
    if (byte >= '0' && byte <= '9') {
      return byte - '0';
    }
    if (byte >= 'a' && byte <= 'f') {
      return 10 + byte - 'a';
    }
    if (byte >= 'A' && byte <= 'F') {
      return 10 + byte - 'A';
    }
    return -1;
  }

  [[nodiscard]] Result<std::uint32_t> parse_hex_quad(
      const std::string_view pointer) {
    if (text_.size() - position_ < 4U) {
      return Result<std::uint32_t>::failure(error_here(
          "json_invalid_unicode_escape",
          "a Unicode escape requires exactly four hexadecimal digits",
          pointer));
    }
    std::uint32_t value = 0;
    for (std::size_t index = 0; index < 4U; ++index) {
      const int digit = hex_value(peek());
      if (digit < 0) {
        return Result<std::uint32_t>::failure(error_here(
            "json_invalid_unicode_escape",
            "a Unicode escape contains a non-hexadecimal digit", pointer));
      }
      value = (value << 4U) | static_cast<std::uint32_t>(digit);
      advance();
    }
    return Result<std::uint32_t>::success(value);
  }

  [[nodiscard]] Result<std::string> parse_string(
      const std::string_view pointer) {
    advance();
    std::string decoded;
    while (!at_end()) {
      const auto byte = static_cast<unsigned char>(peek());
      if (byte == static_cast<unsigned char>('"')) {
        advance();
        return Result<std::string>::success(std::move(decoded));
      }
      if (byte < 0x20U) {
        return Result<std::string>::failure(error_here(
            "json_unescaped_control",
            "a JSON string contains an unescaped control byte", pointer));
      }
      if (byte != static_cast<unsigned char>('\\')) {
        decoded.push_back(peek());
        advance();
        continue;
      }

      advance();
      if (at_end()) {
        break;
      }
      const char escape = peek();
      advance();
      switch (escape) {
        case '"':
        case '\\':
        case '/':
          decoded.push_back(escape);
          break;
        case 'b':
          decoded.push_back('\b');
          break;
        case 'f':
          decoded.push_back('\f');
          break;
        case 'n':
          decoded.push_back('\n');
          break;
        case 'r':
          decoded.push_back('\r');
          break;
        case 't':
          decoded.push_back('\t');
          break;
        case 'u': {
          auto first_result = parse_hex_quad(pointer);
          if (!first_result) {
            return Result<std::string>::failure(
                std::move(first_result.error()));
          }
          std::uint32_t scalar = first_result.value();
          if (scalar >= 0xd800U && scalar <= 0xdbffU) {
            if (text_.size() - position_ < 2U || peek() != '\\' ||
                text_[position_ + 1U] != 'u') {
              return Result<std::string>::failure(error_here(
                  "json_unpaired_surrogate",
                  "a high surrogate must be followed by a low surrogate",
                  pointer));
            }
            advance();
            advance();
            auto second_result = parse_hex_quad(pointer);
            if (!second_result) {
              return Result<std::string>::failure(
                  std::move(second_result.error()));
            }
            const std::uint32_t second = second_result.value();
            if (second < 0xdc00U || second > 0xdfffU) {
              return Result<std::string>::failure(error_here(
                  "json_unpaired_surrogate",
                  "a high surrogate must be followed by a low surrogate",
                  pointer));
            }
            scalar = 0x10000U + ((scalar - 0xd800U) << 10U) +
                     (second - 0xdc00U);
          } else if (scalar >= 0xdc00U && scalar <= 0xdfffU) {
            return Result<std::string>::failure(error_here(
                "json_unpaired_surrogate",
                "a low surrogate may not appear without a high surrogate",
                pointer));
          }
          append_utf8(decoded, scalar);
          break;
        }
        default:
          return Result<std::string>::failure(error_here(
              "json_invalid_escape", "the JSON string escape is not valid",
              pointer));
      }
    }
    return Result<std::string>::failure(error_here(
        "json_unterminated_string", "the JSON string is not terminated",
        pointer));
  }

  [[nodiscard]] Result<SourceNode> parse_number(
      const std::string& pointer, const SourceLocation& start) {
    const std::size_t begin = position_;
    if (peek() == '-') {
      advance();
      if (at_end()) {
        return Result<SourceNode>::failure(error_here(
            "json_invalid_number", "a minus sign must precede digits",
            pointer));
      }
    }
    if (peek() == '0') {
      advance();
      if (peek() >= '0' && peek() <= '9') {
        return Result<SourceNode>::failure(error_here(
            "json_invalid_number", "a JSON number may not have a leading zero",
            pointer));
      }
    } else if (peek() >= '1' && peek() <= '9') {
      while (peek() >= '0' && peek() <= '9') {
        advance();
      }
    } else {
      return Result<SourceNode>::failure(error_here(
          "json_invalid_number", "a JSON number requires an integer part",
          pointer));
    }
    if (peek() == '.') {
      advance();
      if (peek() < '0' || peek() > '9') {
        return Result<SourceNode>::failure(error_here(
            "json_invalid_number",
            "a decimal point must be followed by at least one digit", pointer));
      }
      while (peek() >= '0' && peek() <= '9') {
        advance();
      }
    }
    if (peek() == 'e' || peek() == 'E') {
      advance();
      if (peek() == '+' || peek() == '-') {
        advance();
      }
      if (peek() < '0' || peek() > '9') {
        return Result<SourceNode>::failure(error_here(
            "json_invalid_number",
            "an exponent marker must be followed by decimal digits", pointer));
      }
      while (peek() >= '0' && peek() <= '9') {
        advance();
      }
    }
    return Result<SourceNode>::success(SourceNode::make_number(
        std::string(text_.substr(begin, position_ - begin)), start, pointer));
  }

  std::string_view text_;
  std::string path_;
  std::size_t position_{0U};
  std::size_t line_{1U};
  std::size_t column_{1U};
  bool previous_was_carriage_return_{false};
};

[[nodiscard]] bool is_ascii_digit(const char value) noexcept {
  return value >= '0' && value <= '9';
}

[[nodiscard]] bool is_json_number_lexeme(const std::string_view text) noexcept {
  if (text.empty()) {
    return false;
  }
  std::size_t cursor = 0U;
  if (text[cursor] == '-') {
    ++cursor;
    if (cursor == text.size()) {
      return false;
    }
  }
  if (text[cursor] == '0') {
    ++cursor;
    if (cursor < text.size() && is_ascii_digit(text[cursor])) {
      return false;
    }
  } else if (text[cursor] >= '1' && text[cursor] <= '9') {
    do {
      ++cursor;
    } while (cursor < text.size() && is_ascii_digit(text[cursor]));
  } else {
    return false;
  }
  if (cursor < text.size() && text[cursor] == '.') {
    ++cursor;
    const std::size_t start = cursor;
    while (cursor < text.size() && is_ascii_digit(text[cursor])) {
      ++cursor;
    }
    if (cursor == start) {
      return false;
    }
  }
  if (cursor < text.size() &&
      (text[cursor] == 'e' || text[cursor] == 'E')) {
    ++cursor;
    if (cursor < text.size() &&
        (text[cursor] == '+' || text[cursor] == '-')) {
      ++cursor;
    }
    const std::size_t start = cursor;
    while (cursor < text.size() && is_ascii_digit(text[cursor])) {
      ++cursor;
    }
    if (cursor == start) {
      return false;
    }
  }
  return cursor == text.size();
}

[[nodiscard]] std::string ascii_lower(std::string_view value) {
  std::string lowered;
  lowered.reserve(value.size());
  for (const unsigned char byte : value) {
    lowered.push_back(static_cast<char>(
        byte >= static_cast<unsigned char>('A') &&
                byte <= static_cast<unsigned char>('Z')
            ? byte + (static_cast<unsigned char>('a') -
                      static_cast<unsigned char>('A'))
            : byte));
  }
  return lowered;
}

[[nodiscard]] bool looks_like_timestamp(const std::string_view text) noexcept {
  if (text.size() < 8U || !is_ascii_digit(text[0]) ||
      !is_ascii_digit(text[1]) || !is_ascii_digit(text[2]) ||
      !is_ascii_digit(text[3]) || text[4] != '-') {
    return false;
  }
  std::size_t cursor = 5U;
  const std::size_t month_begin = cursor;
  while (cursor < text.size() && cursor - month_begin < 2U &&
         is_ascii_digit(text[cursor])) {
    ++cursor;
  }
  if (cursor == month_begin || cursor >= text.size() || text[cursor] != '-') {
    return false;
  }
  ++cursor;
  const std::size_t day_begin = cursor;
  while (cursor < text.size() && cursor - day_begin < 2U &&
         is_ascii_digit(text[cursor])) {
    ++cursor;
  }
  if (cursor == day_begin) {
    return false;
  }
  return cursor == text.size() || text[cursor] == 'T' ||
         text[cursor] == 't' || text[cursor] == ' ';
}

[[nodiscard]] bool looks_like_sexagesimal(const std::string_view text) noexcept {
  if (text.find(':') == std::string_view::npos) {
    return false;
  }
  bool has_digit = false;
  for (const char byte : text) {
    has_digit = has_digit || is_ascii_digit(byte);
    if (!is_ascii_digit(byte) && byte != ':' && byte != '.' && byte != '+' &&
        byte != '-') {
      return false;
    }
  }
  return has_digit;
}

[[nodiscard]] std::string_view without_numeric_sign(
    std::string_view text) noexcept {
  if (!text.empty() && (text.front() == '+' || text.front() == '-')) {
    text.remove_prefix(1U);
  }
  return text;
}

[[nodiscard]] bool looks_like_yaml_only_number(
    const std::string_view text) noexcept {
  const std::string_view magnitude = without_numeric_sign(text);
  if (magnitude.empty()) {
    return false;
  }
  const bool numeric_lead =
      is_ascii_digit(magnitude.front()) ||
      (magnitude.front() == '.' && magnitude.size() > 1U &&
       is_ascii_digit(magnitude[1]));
  if (!numeric_lead) {
    return false;
  }
  const bool radix = magnitude.starts_with("0x") ||
                     magnitude.starts_with("0X") ||
                     magnitude.starts_with("0o") ||
                     magnitude.starts_with("0O") ||
                     magnitude.starts_with("0b") ||
                     magnitude.starts_with("0B");
  const bool leading_dot = magnitude.front() == '.';
  const bool leading_zero =
      magnitude.size() > 1U && magnitude.front() == '0' &&
      is_ascii_digit(magnitude[1]);
  const bool trailing_dot =
      magnitude.size() > 1U && magnitude.back() == '.' &&
      std::all_of(magnitude.begin(), magnitude.end() - 1,
                  [](const char byte) { return is_ascii_digit(byte); });
  const std::size_t exponent_mark = magnitude.find_first_of("eE");
  bool dot_before_exponent = false;
  if (exponent_mark != std::string_view::npos && exponent_mark > 1U &&
      magnitude[exponent_mark - 1U] == '.') {
    const std::string_view mantissa = magnitude.substr(0U, exponent_mark - 1U);
    std::string_view exponent = magnitude.substr(exponent_mark + 1U);
    if (!exponent.empty() &&
        (exponent.front() == '+' || exponent.front() == '-')) {
      exponent.remove_prefix(1U);
    }
    dot_before_exponent =
        !exponent.empty() &&
        std::all_of(mantissa.begin(), mantissa.end(), is_ascii_digit) &&
        std::all_of(exponent.begin(), exponent.end(), is_ascii_digit);
  }
  return text.front() == '+' || radix || leading_dot || leading_zero ||
         trailing_dot || dot_before_exponent ||
         text.find('_') != std::string_view::npos ||
         looks_like_sexagesimal(text);
}

enum class PlainScalarKind {
  null_value,
  boolean_true,
  boolean_false,
  number,
  string,
  forbidden_implicit,
  nonfinite,
};

[[nodiscard]] PlainScalarKind classify_plain_scalar(
    const std::string_view text) {
  if (text == "null") {
    return PlainScalarKind::null_value;
  }
  if (text == "true") {
    return PlainScalarKind::boolean_true;
  }
  if (text == "false") {
    return PlainScalarKind::boolean_false;
  }
  if (is_json_number_lexeme(text)) {
    return PlainScalarKind::number;
  }

  const std::string lowered = ascii_lower(text);
  if (lowered == ".nan" || lowered == ".inf" || lowered == "+.inf" ||
      lowered == "-.inf" || lowered == "nan" || lowered == "infinity" ||
      lowered == "+infinity" || lowered == "-infinity") {
    return PlainScalarKind::nonfinite;
  }
  if (lowered == "~" || lowered == "null" || lowered == "true" ||
      lowered == "false" || lowered == "yes" || lowered == "no" ||
      lowered == "on" || lowered == "off" || lowered == "y" ||
      lowered == "n" || looks_like_timestamp(text) ||
      looks_like_yaml_only_number(text)) {
    return PlainScalarKind::forbidden_implicit;
  }
  return PlainScalarKind::string;
}

[[nodiscard]] SourceLocation location_from_byte_offset(
    const std::string_view content, const std::string& path,
    const std::size_t requested_offset) {
  const std::size_t offset = std::min(requested_offset, content.size());
  std::size_t line = 1U;
  std::size_t column = 1U;
  bool previous_was_carriage_return = false;
  for (std::size_t index = 0U; index < offset; ++index) {
    const char byte = content[index];
    if (byte == '\r') {
      ++line;
      column = 1U;
      previous_was_carriage_return = true;
    } else if (byte == '\n') {
      if (!previous_was_carriage_return) {
        ++line;
      }
      column = 1U;
      previous_was_carriage_return = false;
    } else {
      ++column;
      previous_was_carriage_return = false;
    }
  }
  return SourceLocation{path, line, column, offset};
}

[[nodiscard]] SourceLocation yaml_location(const YAML::Mark& mark,
                                           const std::string& path,
                                           const std::string_view content) {
  const std::size_t offset =
      mark.pos < 0 ? 0U : static_cast<std::size_t>(mark.pos);
  return location_from_byte_offset(content, path, offset);
}

struct YamlPreflightProblem final {
  std::string code;
  std::string message;
  YAML::Mark mark;
  std::string pointer;
  std::optional<YAML::Mark> first_definition;
};

// Duplicate mapping keys and aliases must be rejected before a Node/DOM
// implementation has an opportunity to collapse or resolve them.  This small
// event-state machine also preserves the decoded-key JSON pointer and both
// source marks for a duplicate.  Full scalar/subset conversion remains in
// YamlConverter below.
class YamlPreflight final : public YAML::EventHandler {
 public:
  void OnDocumentStart(const YAML::Mark& mark) override {
    ++document_count_;
    if (document_count_ > 1U) {
      record_problem("yaml_multiple_documents",
                     "exactly one YAML document is accepted per input file",
                     mark, "");
    }
  }
  void OnDocumentEnd() override { frames_.clear(); }

  void OnNull(const YAML::Mark& mark, YAML::anchor_t) override {
    scalar_node(mark, {}, false);
  }

  void OnAlias(const YAML::Mark& mark, YAML::anchor_t) override {
    record_problem("yaml_alias_not_allowed",
                   "YAML aliases and cyclic/shared node structure are not "
                   "accepted",
                   mark, current_value_pointer());
  }

  void OnScalar(const YAML::Mark& mark, const std::string& tag,
                YAML::anchor_t, const std::string& value) override {
    if (problem_.has_value()) {
      return;
    }
    if (!frames_.empty() && frames_.back().kind == FrameKind::mapping &&
        frames_.back().expecting_key) {
      Frame& mapping = frames_.back();
      const std::string pointer = append_pointer(mapping.pointer, value);
      if (value == "<<" && tag != "!") {
        record_problem("yaml_merge_key_not_allowed",
                       "YAML merge keys are not accepted", mark, pointer);
        return;
      }
      if ((!tag.empty() && tag != "?" && tag != "!") ||
          (tag != "!" &&
           classify_plain_scalar(value) != PlainScalarKind::string)) {
        record_problem("yaml_mapping_key_not_string",
                       "a YAML mapping key must resolve to a string", mark,
                       pointer);
        return;
      }
      const auto [definition, inserted] =
          mapping.definitions.emplace(value, mark);
      if (!inserted) {
        problem_ = YamlPreflightProblem{
            "duplicate_object_key", "duplicate object key '" + value + "'",
            mark, pointer, definition->second};
        return;
      }
      mapping.current_key = value;
      mapping.expecting_key = false;
      return;
    }
    const std::string pointer = consume_value_node();
    if (!tag.empty() && tag != "?" && tag != "!") {
      record_problem("yaml_custom_tag_not_allowed",
                     "explicit YAML tags are not accepted in the "
                     "JSON-compatible subset",
                     mark, pointer);
    }
  }

  void OnSequenceStart(const YAML::Mark& mark, const std::string& tag,
                       YAML::anchor_t, YAML::EmitterStyle::value) override {
    container_start(FrameKind::sequence, mark, tag);
  }

  void OnSequenceEnd() override { container_end(); }

  void OnMapStart(const YAML::Mark& mark, const std::string& tag,
                  YAML::anchor_t, YAML::EmitterStyle::value) override {
    container_start(FrameKind::mapping, mark, tag);
  }

  void OnMapEnd() override { container_end(); }

  [[nodiscard]] const std::optional<YamlPreflightProblem>& problem()
      const noexcept {
    return problem_;
  }

 private:
  enum class FrameKind { sequence, mapping };

  struct Frame final {
    FrameKind kind;
    std::string pointer;
    std::size_t next_index{0U};
    bool expecting_key{true};
    std::string current_key;
    std::unordered_map<std::string, YAML::Mark> definitions;
  };

  [[nodiscard]] std::string current_value_pointer() {
    if (frames_.empty()) {
      return "";
    }
    Frame& parent = frames_.back();
    if (parent.kind == FrameKind::sequence) {
      return append_pointer(parent.pointer,
                            std::to_string(parent.next_index));
    }
    return parent.expecting_key
               ? parent.pointer
               : append_pointer(parent.pointer, parent.current_key);
  }

  [[nodiscard]] std::string consume_value_node() {
    if (frames_.empty()) {
      return "";
    }
    Frame& parent = frames_.back();
    if (parent.kind == FrameKind::sequence) {
      const std::string pointer =
          append_pointer(parent.pointer, std::to_string(parent.next_index));
      ++parent.next_index;
      return pointer;
    }
    if (parent.expecting_key) {
      return parent.pointer;
    }
    const std::string pointer =
        append_pointer(parent.pointer, parent.current_key);
    parent.current_key.clear();
    parent.expecting_key = true;
    return pointer;
  }

  void scalar_node(const YAML::Mark& mark, const std::string_view value,
                   const bool is_string) {
    if (problem_.has_value()) {
      return;
    }
    if (!frames_.empty() && frames_.back().kind == FrameKind::mapping &&
        frames_.back().expecting_key && !is_string) {
      record_problem("yaml_mapping_key_not_string",
                     "a YAML mapping key must resolve to a string", mark,
                     frames_.back().pointer);
      return;
    }
    static_cast<void>(value);
    static_cast<void>(consume_value_node());
  }

  void container_start(const FrameKind kind, const YAML::Mark& mark,
                       const std::string& tag) {
    if (problem_.has_value()) {
      return;
    }
    if (!tag.empty() && tag != "?" && tag != "!") {
      record_problem("yaml_custom_tag_not_allowed",
                     "explicit YAML tags are not accepted in the "
                     "JSON-compatible subset",
                     mark, current_value_pointer());
      return;
    }
    if (!frames_.empty() && frames_.back().kind == FrameKind::mapping &&
        frames_.back().expecting_key) {
      record_problem("yaml_mapping_key_not_string",
                     "a YAML mapping key must be a string scalar", mark,
                     frames_.back().pointer);
      return;
    }
    const std::string pointer = consume_value_node();
    frames_.push_back(Frame{kind, pointer, 0U, true, {}, {}});
  }

  void container_end() {
    if (!problem_.has_value() && !frames_.empty()) {
      frames_.pop_back();
    }
  }

  void record_problem(std::string code, std::string message,
                      const YAML::Mark& mark, std::string pointer) {
    if (!problem_.has_value()) {
      problem_ = YamlPreflightProblem{std::move(code), std::move(message),
                                      mark, std::move(pointer), std::nullopt};
    }
  }

  std::vector<Frame> frames_;
  std::optional<YamlPreflightProblem> problem_;
  std::size_t document_count_{0U};
};

class YamlConverter final {
 public:
  YamlConverter(std::string path, const std::string_view content)
      : path_(std::move(path)), content_(content) {}

  [[nodiscard]] Result<SourceNode> convert(const YAML::Node& root) {
    return convert_node(root, "", 0U);
  }

 private:
  [[nodiscard]] bool was_seen(const YAML::Node& node) const {
    return std::any_of(seen_.begin(), seen_.end(),
                       [&node](const YAML::Node& seen) {
                         return node.is(seen);
                       });
  }

  [[nodiscard]] Result<SourceNode> convert_node(const YAML::Node& node,
                                                 const std::string& pointer,
                                                 const std::size_t depth) {
    const SourceLocation location = yaml_location(node.Mark(), path_, content_);
    if (depth > kMaximumDocumentNesting) {
      Diagnostic diagnostic = located_error(
          "document_nesting_limit",
          "the document exceeds the supported structural nesting depth",
          location, pointer);
      diagnostic.category = DiagnosticCategory::resource_limit;
      return Result<SourceNode>::failure(std::move(diagnostic));
    }
    if (was_seen(node)) {
      return Result<SourceNode>::failure(located_error(
          "yaml_alias_not_allowed",
          "YAML aliases and cyclic/shared node structure are not accepted",
          location, pointer));
    }
    seen_.push_back(node);

    const std::string tag = node.Tag();
    if (!tag.empty() && tag != "?" && tag != "!") {
      return Result<SourceNode>::failure(located_error(
          "yaml_custom_tag_not_allowed",
          "explicit YAML tags are not accepted in the JSON-compatible subset",
          location, pointer, {"tag: " + tag}));
    }

    if (!node.IsDefined()) {
      return Result<SourceNode>::failure(located_error(
          "yaml_non_json_implicit_scalar",
          "an omitted YAML value is not a JSON-compatible scalar", location,
          pointer));
    }
    if (node.IsNull()) {
      const std::string_view token = plain_token_at(location.byte_offset);
      if (token != "null") {
        return Result<SourceNode>::failure(located_error(
            "yaml_non_json_implicit_scalar",
            "only the lowercase 'null' spelling is accepted as a YAML null",
            location, pointer,
            {"scalar: " + (token.empty() ? std::string{"<omitted>"}
                                         : std::string{token})}));
      }
      return Result<SourceNode>::success(
          SourceNode::make_null(location, pointer));
    }
    if (node.IsSequence()) {
      std::vector<SourceNode> items;
      items.reserve(node.size());
      for (std::size_t index = 0U; index < node.size(); ++index) {
        const std::string child_pointer =
            append_pointer(pointer, std::to_string(index));
        auto child = convert_node(node[index], child_pointer, depth + 1U);
        if (!child) {
          return Result<SourceNode>::failure(std::move(child.error()));
        }
        items.push_back(std::move(child.value()));
      }
      return Result<SourceNode>::success(
          SourceNode::make_array(std::move(items), location, pointer));
    }
    if (node.IsMap()) {
      std::vector<SourceObjectMember> members;
      members.reserve(node.size());
      std::unordered_map<std::string, SourceLocation> definitions;
      for (auto iterator = node.begin(); iterator != node.end(); ++iterator) {
        const YAML::Node key_node = iterator->first;
        const SourceLocation key_location =
            yaml_location(key_node.Mark(), path_, content_);
        if (!key_node.IsScalar()) {
          return Result<SourceNode>::failure(located_error(
              "yaml_mapping_key_not_string",
              "a YAML mapping key must be a string scalar", key_location,
              pointer));
        }
        const std::string key_tag = key_node.Tag();
        const std::string key = key_node.Scalar();
        if (key == "<<" && key_tag != "!") {
          return Result<SourceNode>::failure(located_error(
              "yaml_merge_key_not_allowed",
              "YAML merge keys are not accepted", key_location,
              append_pointer(pointer, key)));
        }
        if (!key_tag.empty() && key_tag != "?" && key_tag != "!") {
          return Result<SourceNode>::failure(located_error(
              "yaml_custom_tag_not_allowed",
              "explicit YAML tags are not accepted in the JSON-compatible "
              "subset",
              key_location, append_pointer(pointer, key),
              {"tag: " + key_tag}));
        }
        if (key_tag != "!" &&
            classify_plain_scalar(key) != PlainScalarKind::string) {
          return Result<SourceNode>::failure(located_error(
              "yaml_mapping_key_not_string",
              "a YAML mapping key must resolve to a string", key_location,
              append_pointer(pointer, key), {"key: " + key}));
        }
        const std::string child_pointer = append_pointer(pointer, key);
        const auto [definition, inserted] =
            definitions.emplace(key, key_location);
        if (!inserted) {
          return Result<SourceNode>::failure(located_error(
              "duplicate_object_key", "duplicate object key '" + key + "'",
              key_location, child_pointer,
              {"first definition: " + source_note(definition->second),
               "duplicate definition: " + source_note(key_location)}));
        }
        auto value =
            convert_node(iterator->second, child_pointer, depth + 1U);
        if (!value) {
          return Result<SourceNode>::failure(std::move(value.error()));
        }
        members.push_back(SourceObjectMember{key, key_location,
                                             std::move(value.value())});
      }
      return Result<SourceNode>::success(
          SourceNode::make_object(std::move(members), location, pointer));
    }
    if (!node.IsScalar()) {
      return Result<SourceNode>::failure(located_error(
          "yaml_unsupported_node", "the YAML node is not JSON-compatible",
          location, pointer));
    }

    const std::string scalar = node.Scalar();
    if (tag == "!") {
      return Result<SourceNode>::success(
          SourceNode::make_string(scalar, location, pointer));
    }
    switch (classify_plain_scalar(scalar)) {
      case PlainScalarKind::null_value:
        return Result<SourceNode>::success(
            SourceNode::make_null(location, pointer));
      case PlainScalarKind::boolean_true:
        return Result<SourceNode>::success(
            SourceNode::make_boolean(true, location, pointer));
      case PlainScalarKind::boolean_false:
        return Result<SourceNode>::success(
            SourceNode::make_boolean(false, location, pointer));
      case PlainScalarKind::number:
        return Result<SourceNode>::success(
            SourceNode::make_number(scalar, location, pointer));
      case PlainScalarKind::string:
        return Result<SourceNode>::success(
            SourceNode::make_string(scalar, location, pointer));
      case PlainScalarKind::nonfinite:
        return Result<SourceNode>::failure(located_error(
            "document_nonfinite_number",
            "NaN and infinity are not accepted document scalars", location,
            pointer));
      case PlainScalarKind::forbidden_implicit:
        return Result<SourceNode>::failure(located_error(
            "yaml_non_json_implicit_scalar",
            "the YAML scalar uses a non-JSON implicit type or spelling",
            location, pointer, {"scalar: " + scalar}));
    }
    return Result<SourceNode>::failure(located_error(
        "yaml_unsupported_node", "the YAML scalar is not JSON-compatible",
        location, pointer));
  }

  [[nodiscard]] std::string_view plain_token_at(
      const std::size_t byte_offset) const noexcept {
    if (byte_offset >= content_.size()) {
      return {};
    }
    std::size_t end = byte_offset;
    while (end < content_.size()) {
      const char byte = content_[end];
      if (byte == ' ' || byte == '\t' || byte == '\r' || byte == '\n' ||
          byte == ',' || byte == ']' || byte == '}' || byte == '#') {
        break;
      }
      ++end;
    }
    return content_.substr(byte_offset, end - byte_offset);
  }

  std::string path_;
  std::string_view content_;
  std::vector<YAML::Node> seen_;
};

[[nodiscard]] std::size_t first_significant_offset(
    const std::string_view content) noexcept {
  std::size_t offset = 0U;
  while (offset < content.size() &&
         (content[offset] == ' ' || content[offset] == '\t' ||
          content[offset] == '\r' || content[offset] == '\n')) {
    ++offset;
  }
  return offset;
}

[[nodiscard]] bool looks_like_block_yaml(const std::string_view content) {
  const std::size_t start = first_significant_offset(content);
  if (start == content.size()) {
    return false;
  }
  const std::string_view tail = content.substr(start);
  if (tail.starts_with("---") || tail.starts_with("%YAML") ||
      tail.starts_with("%TAG")) {
    return true;
  }
  const std::size_t line_end = tail.find_first_of("\r\n");
  const std::string_view first_line = tail.substr(0U, line_end);
  if (first_line.empty() || first_line.front() == '{' ||
      first_line.front() == '[') {
    return false;
  }
  const std::size_t colon = first_line.find(':');
  return colon != std::string_view::npos && colon > 0U &&
         first_line.front() != '"';
}

[[nodiscard]] Result<SourceNode> parse_yaml_document(
    const std::string& content, const std::string& path) {
  try {
    std::istringstream event_input(content);
    YAML::Parser event_parser(event_input);
    YamlPreflight preflight;
    while (event_parser.HandleNextDocument(preflight)) {
    }
    if (preflight.problem().has_value()) {
      const YamlPreflightProblem& problem = *preflight.problem();
      const SourceLocation location =
          yaml_location(problem.mark, path, content);
      std::vector<std::string> notes;
      if (problem.first_definition.has_value()) {
        const SourceLocation first =
            yaml_location(*problem.first_definition, path, content);
        notes.push_back("first definition: " + source_note(first));
        notes.push_back("duplicate definition: " + source_note(location));
      }
      return Result<SourceNode>::failure(located_error(
          problem.code, problem.message, location, problem.pointer,
          std::move(notes)));
    }
  } catch (const YAML::ParserException& exception) {
    return Result<SourceNode>::failure(located_error(
        "yaml_syntax_error", "the YAML document is not syntactically valid",
        yaml_location(exception.mark, path, content), "", {exception.msg}));
  }

  std::vector<YAML::Node> documents;
  try {
    documents = YAML::LoadAll(content);
  } catch (const YAML::ParserException& exception) {
    const SourceLocation location =
        yaml_location(exception.mark, path, content);
    return Result<SourceNode>::failure(located_error(
        "yaml_syntax_error", "the YAML document is not syntactically valid",
        location, "", {exception.msg}));
  } catch (const YAML::Exception& exception) {
    return Result<SourceNode>::failure(path_error(
        "yaml_syntax_error", "the YAML document could not be decoded: " +
                                 std::string(exception.what()),
        path));
  }
  if (documents.empty()) {
    return Result<SourceNode>::failure(path_error(
        "document_empty", "a YAML document may not be empty", path));
  }
  if (documents.size() != 1U) {
    const SourceLocation location =
        yaml_location(documents[1].Mark(), path, content);
    return Result<SourceNode>::failure(located_error(
        "yaml_multiple_documents",
        "exactly one YAML document is accepted per input file", location,
        ""));
  }

  return YamlConverter(path, content).convert(documents.front());
}

[[nodiscard]] bool equals_one_of(const std::string_view value,
                                 const KeySet candidates) noexcept {
  return std::find(candidates.begin(), candidates.end(), value) !=
         candidates.end();
}

[[nodiscard]] Diagnostic node_error(const SourceNode& node,
                                    const std::string& code,
                                    const std::string& message,
                                    const std::string_view pointer = {}) {
  return located_error(code, message, node.location(),
                       pointer.empty() ? node.json_pointer() : pointer);
}

}  // namespace

Result<ParsedDocument> load_document(const std::filesystem::path& path) {
  const std::string authored_path = path.string();
  const std::string extension = path.extension().string();
  DocumentSyntax syntax;
  if (extension == ".json") {
    syntax = DocumentSyntax::json;
  } else if (extension == ".yaml" || extension == ".yml") {
    syntax = DocumentSyntax::yaml;
  } else {
    return Result<ParsedDocument>::failure(path_error(
        "document_suffix_unsupported",
        "input documents must use a .json, .yaml, or .yml suffix",
        authored_path));
  }

  std::ifstream input(path, std::ios::binary);
  if (!input.is_open()) {
    return Result<ParsedDocument>::failure(path_error(
        "document_open_failed", "the input document could not be opened",
        authored_path));
  }
  std::string content{std::istreambuf_iterator<char>(input),
                      std::istreambuf_iterator<char>()};
  if (input.bad()) {
    return Result<ParsedDocument>::failure(path_error(
        "document_read_failed", "the input document could not be read",
        authored_path));
  }
  if (content.starts_with("\xef\xbb\xbf")) {
    return Result<ParsedDocument>::failure(path_error(
        "document_utf8_bom_not_allowed",
        "the input must be UTF-8 without a byte-order mark", authored_path));
  }
  if (const auto invalid = first_invalid_utf8(content); invalid.has_value()) {
    const SourceLocation location =
        location_from_byte_offset(content, authored_path, *invalid);
    return Result<ParsedDocument>::failure(located_error(
        "document_invalid_utf8", "the input is not valid UTF-8", location,
        ""));
  }

  Result<SourceNode> root = [&]() {
    if (syntax == DocumentSyntax::json) {
      if (looks_like_block_yaml(content)) {
        return Result<SourceNode>::failure(path_error(
            "document_suffix_content_mismatch",
            "the .json suffix does not agree with YAML-form content",
            authored_path));
      }
      return JsonParser(content, authored_path).parse();
    }
    return parse_yaml_document(content, authored_path);
  }();
  if (!root) {
    return Result<ParsedDocument>::failure(std::move(root.error()));
  }
  return Result<ParsedDocument>::success(
      ParsedDocument{syntax, authored_path, std::move(root.value())});
}

Result<void> validate_exact_keys(const SourceNode& node,
                                 const KeySet allowed_keys,
                                 const std::string_view json_pointer) {
  if (node.kind() != SourceNodeKind::object) {
    return Result<void>::failure(node_error(
        node, "expected_object", "the value must be an object", json_pointer));
  }
  for (const SourceObjectMember& member : node.object_members()) {
    if (!equals_one_of(member.key, allowed_keys)) {
      const std::string pointer = append_pointer(
          json_pointer.empty() ? node.json_pointer() : json_pointer, member.key);
      return Result<void>::failure(located_error(
          "unknown_object_key", "unknown object key '" + member.key + "'",
          member.key_location, pointer));
    }
  }
  return Result<void>::success();
}

}  // namespace mwperf
