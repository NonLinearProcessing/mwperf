#include "mwperf/config/canonical_input.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/schema_versions.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/typed_label.hpp"

namespace mwperf {
namespace {

using JsonField = std::pair<std::string, std::string>;

template <typename... Callables>
struct Overloaded : Callables... {
  using Callables::operator()...;
};
template <typename... Callables>
Overloaded(Callables...) -> Overloaded<Callables...>;

[[nodiscard]] bool unsigned_utf8_less(const std::string_view left,
                                      const std::string_view right) noexcept {
  return std::lexicographical_compare(
      left.begin(), left.end(), right.begin(), right.end(),
      [](const char lhs, const char rhs) {
        return static_cast<unsigned char>(lhs) <
               static_cast<unsigned char>(rhs);
      });
}

[[nodiscard]] std::string json_string(const std::string_view value) {
  constexpr char hex[] = "0123456789abcdef";
  std::string result;
  result.reserve(value.size() + 2U);
  result.push_back('"');
  for (const char character : value) {
    const auto byte = static_cast<unsigned char>(character);
    switch (byte) {
      case '"':
        result += "\\\"";
        break;
      case '\\':
        result += "\\\\";
        break;
      case '\b':
        result += "\\b";
        break;
      case '\f':
        result += "\\f";
        break;
      case '\n':
        result += "\\n";
        break;
      case '\r':
        result += "\\r";
        break;
      case '\t':
        result += "\\t";
        break;
      default:
        if (byte < 0x20U) {
          result += "\\u00";
          result.push_back(hex[(byte >> 4U) & 0x0fU]);
          result.push_back(hex[byte & 0x0fU]);
        } else {
          result.push_back(character);
        }
        break;
    }
  }
  result.push_back('"');
  return result;
}

[[nodiscard]] std::string json_object(std::vector<JsonField> fields) {
  std::stable_sort(fields.begin(), fields.end(),
                   [](const JsonField& left, const JsonField& right) {
                     return unsigned_utf8_less(left.first, right.first);
                   });

  std::size_t reserve = 2U;
  for (const auto& [key, value] : fields) {
    reserve += key.size() + value.size() + 4U;
  }
  std::string result;
  result.reserve(reserve);
  result.push_back('{');
  for (std::size_t index = 0U; index < fields.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += json_string(fields[index].first);
    result.push_back(':');
    result += fields[index].second;
  }
  result.push_back('}');
  return result;
}

[[nodiscard]] std::string json_array(const std::vector<std::string>& items) {
  std::size_t reserve = 2U;
  for (const std::string& item : items) {
    reserve += item.size() + 1U;
  }
  std::string result;
  result.reserve(reserve);
  result.push_back('[');
  for (std::size_t index = 0U; index < items.size(); ++index) {
    if (index != 0U) {
      result.push_back(',');
    }
    result += items[index];
  }
  result.push_back(']');
  return result;
}

template <typename T, typename Encoder>
[[nodiscard]] std::string encode_array(const std::vector<T>& values,
                                       Encoder encode) {
  std::vector<std::string> encoded;
  encoded.reserve(values.size());
  for (const T& value : values) {
    encoded.push_back(encode(value));
  }
  return json_array(encoded);
}

[[nodiscard]] BigInt positive_power(BigInt base, std::size_t exponent) {
  BigInt result = 1;
  while (exponent != 0U) {
    if ((exponent & 1U) != 0U) {
      result *= base;
    }
    exponent >>= 1U;
    if (exponent != 0U) {
      base *= base;
    }
  }
  return result;
}

// Every ExactRational reaching this function originated in a finite decimal
// source token.  A non-2/5 denominator would therefore be an internal C03
// invariant violation, not authored-input recovery work.
[[nodiscard]] std::string exact_decimal(const ExactRational& value) {
  BigInt remaining = value.denominator();
  std::size_t twos = 0U;
  std::size_t fives = 0U;
  while ((remaining % 2) == 0) {
    remaining /= 2;
    ++twos;
  }
  while ((remaining % 5) == 0) {
    remaining /= 5;
    ++fives;
  }
  if (remaining != 1) {
    throw std::logic_error(
        "C03 canonicalization received a nonterminating exact rational");
  }

  const std::size_t scale = std::max(twos, fives);
  BigInt scaled = value.numerator();
  scaled *= positive_power(2, scale - twos);
  scaled *= positive_power(5, scale - fives);
  if (scaled == 0) {
    return "0";
  }

  const bool negative = scaled < 0;
  if (negative) {
    scaled = -scaled;
  }
  std::string digits = scaled.convert_to<std::string>();
  std::string result;
  if (scale == 0U) {
    result = std::move(digits);
  } else if (digits.size() <= scale) {
    result = "0.";
    result.append(scale - digits.size(), '0');
    result += digits;
  } else {
    const std::size_t point = digits.size() - scale;
    result.assign(digits.begin(),
                  digits.begin() + static_cast<std::ptrdiff_t>(point));
    result.push_back('.');
    result.append(digits.begin() + static_cast<std::ptrdiff_t>(point),
                  digits.end());
  }

  if (const std::size_t point = result.find('.'); point != std::string::npos) {
    while (result.back() == '0') {
      result.pop_back();
    }
    if (result.back() == '.') {
      result.pop_back();
    }
  }
  if (negative) {
    result.insert(result.begin(), '-');
  }
  return result;
}

[[nodiscard]] std::string encode(const BigNat& value) {
  return value.to_decimal_string();
}

[[nodiscard]] std::string encode(const ExactRational& value) {
  return exact_decimal(value);
}

[[nodiscard]] std::string encode(const AuthoredProbability& value) {
  return encode(value.exact_value());
}

[[nodiscard]] std::string encode(const TypedLabel& label) {
  if (const BigNat* numeric = label.numeric_value(); numeric != nullptr) {
    return encode(*numeric);
  }
  return json_string(*label.text_value());
}

template <StrongIdDomainName Domain>
[[nodiscard]] std::string encode(const StrongId<Domain>& identifier) {
  return encode(identifier.label());
}

[[nodiscard]] std::string encode(const NormalizedToken& token) {
  return json_string(token.value);
}

[[nodiscard]] std::string encode_source_node(const SourceNode& node) {
  switch (node.kind()) {
    case SourceNodeKind::null_value:
      return "null";
    case SourceNodeKind::boolean:
      return *node.boolean_value() ? "true" : "false";
    case SourceNodeKind::number: {
      Result<ExactRational> parsed =
          parse_decimal_rational(NumericLexeme(*node.number_lexeme()));
      if (!parsed) {
        std::terminate();
      }
      return exact_decimal(parsed.value());
    }
    case SourceNodeKind::string:
      return json_string(*node.string_value());
    case SourceNodeKind::array: {
      std::vector<std::string> items;
      items.reserve(node.array_items().size());
      for (const SourceNode& item : node.array_items()) {
        items.push_back(encode_source_node(item));
      }
      return json_array(items);
    }
    case SourceNodeKind::object: {
      std::vector<JsonField> fields;
      fields.reserve(node.object_members().size());
      for (const SourceObjectMember& member : node.object_members()) {
        fields.emplace_back(member.key, encode_source_node(member.value));
      }
      return json_object(std::move(fields));
    }
  }
  std::terminate();
}

template <typename T, typename Encoder>
[[nodiscard]] std::string encode_optional(const std::optional<T>& value,
                                          Encoder encoder) {
  return value.has_value() ? encoder(*value) : "null";
}

[[nodiscard]] std::string encode_seed(const SeedSpec& seed) {
  if (seed.mode == SeedMode::automatic) {
    return "-1";
  }
  return std::to_string(seed.fixed_value);
}

[[nodiscard]] std::string encode_metadata(const AuthoredMetadata& metadata) {
  return metadata.value.has_value() ? encode_source_node(*metadata.value)
                                    : "{}";
}

[[nodiscard]] std::string encode_queue(const AuthoredQueue& queue) {
  std::vector<JsonField> fields{{"id", encode(queue.id.value)}};
  if (queue.legacy_voq.value.has_value()) {
    const LegacyVoqCoordinate& coordinate = *queue.legacy_voq.value;
    fields.emplace_back(
        "legacy_voq",
        json_array({encode(coordinate.source.value),
                    encode(coordinate.destination.value)}));
  }
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_switch(const AuthoredSwitchConfig& config,
                                        const bool schema4) {
  return std::visit(
      Overloaded{
          [schema4](const GeneralizedSwitchConfig& value) {
            return json_object({
                {"kind", json_string("generalized")},
                {"legacy_n_ports",
                 encode_optional(value.legacy_n_ports.value,
                                 [](const BigNat& item) { return encode(item); })},
                {"queue_capacity",
                 value.queue_capacity.value.has_value()
                     ? encode(*value.queue_capacity.value)
                     : (schema4 ? json_string("NoDrop") : "null")},
                {"queues", encode_array(value.queues.value, encode_queue)},
            });
          },
          [](const LegacyCrossbarSwitchConfig& value) {
            return json_object({
                {"allow_self_traffic",
                 value.allow_self_traffic.value ? "true" : "false"},
                {"kind", json_string("legacy_crossbar")},
                {"n_ports", encode(value.n_ports.value)},
                {"voq_capacity", encode(value.voq_capacity.value)},
            });
          }},
      config);
}

[[nodiscard]] std::string encode_priority(const AuthoredPriority& priority) {
  return encode_optional(
      priority.value, [](const std::vector<AuthoredField<QueueId>>& values) {
        return encode_array(values, [](const AuthoredField<QueueId>& value) {
          return encode(value.value);
        });
      });
}

[[nodiscard]] std::string encode_crossbar_constraint(
    const CrossbarConstraint& constraint) {
  return json_object({
      {"edges", encode_array(constraint.edges.value,
                             [](const CrossbarEdge& edge) {
                               return json_object({
                                   {"input", encode(edge.input.value)},
                                   {"output", encode(edge.output.value)},
                                   {"queue_id", encode(edge.queue_id.value)},
                               });
                             })},
      {"inputs", encode_array(
                     constraint.inputs.value,
                     [](const AuthoredField<PortId>& value) {
                       return encode(value.value);
                     })},
      {"outputs",
       encode_array(constraint.outputs.value,
                    [](const AuthoredField<PortId>& value) {
                      return encode(value.value);
                    })},
  });
}

[[nodiscard]] std::string encode_interval_constraint(
    const IntervalConstraint& constraint) {
  return json_object({
      {"intervals", encode_array(constraint.intervals.value,
                                 [](const IntervalRecord& interval) {
                                   return json_object({
                                       {"left", encode(interval.left.value)},
                                       {"queue_id", encode(interval.queue_id.value)},
                                       {"right", encode(interval.right.value)},
                                   });
                                 })},
  });
}

[[nodiscard]] std::string encode_node_constraint(
    const NodeExclusiveConstraint& constraint) {
  return json_object({
      {"links", encode_array(constraint.links.value,
                             [](const NodeExclusiveLink& link) {
                               return json_object({
                                   {"queue_id", encode(link.queue_id.value)},
                                   {"u", encode(link.u.value)},
                                   {"v", encode(link.v.value)},
                               });
                             })},
      {"vertices",
       encode_array(constraint.vertices.value,
                    [](const AuthoredField<VertexId>& value) {
                      return encode(value.value);
                    })},
  });
}

[[nodiscard]] std::string encode_conflict_constraint(
    const ConflictConstraint& constraint) {
  return json_object({
      {"conflicts", encode_array(constraint.conflicts.value,
                                 [](const ConflictPair& pair) {
                                   return json_array({encode(pair.first.value),
                                                      encode(pair.second.value)});
                                 })},
  });
}

[[nodiscard]] std::string encode_packing_constraint(
    const PackingConstraint& constraint) {
  return json_object({
      {"capacity",
       encode_array(constraint.capacity.value,
                    [](const AuthoredField<BigNat>& item) {
                      return encode(item.value);
                    })},
      {"demands", encode_array(constraint.demands.value,
                               [](const PackingDemand& demand) {
                                 return json_object({
                                     {"demand", encode_array(
                                                    demand.demand.value,
                                                    [](const AuthoredField<BigNat>& item) {
                                                      return encode(item.value);
                                                    })},
                                     {"queue_id", encode(demand.queue_id.value)},
                                 });
                               })},
      {"resources",
       encode_array(constraint.resources.value,
                    [](const AuthoredField<ResourceId>& value) {
                      return encode(value.value);
                    })},
  });
}

[[nodiscard]] std::string compatibility_scheduler_name(
    const CompatibilitySchedulerKind kind) {
  switch (kind) {
    case CompatibilitySchedulerKind::random_maximal:
      return "random_maximal";
    case CompatibilitySchedulerKind::round_robin:
      return "round_robin";
    case CompatibilitySchedulerKind::islip_rga:
      return "islip_rga";
    case CompatibilitySchedulerKind::islip_canonical:
      return "islip_canonical";
  }
  std::terminate();
}

[[nodiscard]] std::string encode_compatibility_scheduler_params(
    const UnsupportedCompatibilityScheduler& scheduler) {
  const bool kind_matches_payload =
      (scheduler.kind == CompatibilitySchedulerKind::random_maximal &&
       std::holds_alternative<RandomMaximalCompatibilityParams>(
           scheduler.params)) ||
      (scheduler.kind == CompatibilitySchedulerKind::round_robin &&
       std::holds_alternative<RoundRobinCompatibilityParams>(
           scheduler.params)) ||
      (scheduler.kind == CompatibilitySchedulerKind::islip_rga &&
       std::holds_alternative<IslipRgaCompatibilityParams>(
           scheduler.params)) ||
      (scheduler.kind == CompatibilitySchedulerKind::islip_canonical &&
       std::holds_alternative<IslipCanonicalCompatibilityParams>(
           scheduler.params));
  if (!kind_matches_payload) {
    std::terminate();
  }
  return std::visit(
      Overloaded{
          [](const RandomMaximalCompatibilityParams&) { return std::string("{}"); },
          [](const RoundRobinCompatibilityParams& value) {
            return json_object({
                {"input_offset", encode(value.input_offset.value)},
                {"output_offset", encode(value.output_offset.value)},
            });
          },
          [](const IslipRgaCompatibilityParams& value) {
            return json_object({{"k", encode(value.k.value)}});
          },
          [](const IslipCanonicalCompatibilityParams& value) {
            std::vector<JsonField> fields{{"k", encode(value.k.value)}};
            const auto encode_pointers = [](const auto& pointers) {
              return encode_array(
                  pointers, [](const AuthoredField<BigNat>& pointer) {
                    return encode(pointer.value);
                  });
            };
            if (value.initial_grant_pointers.value.has_value()) {
              fields.emplace_back(
                  "initial_grant_pointers",
                  encode_pointers(*value.initial_grant_pointers.value));
            }
            if (value.initial_accept_pointers.value.has_value()) {
              fields.emplace_back(
                  "initial_accept_pointers",
                  encode_pointers(*value.initial_accept_pointers.value));
            }
            return json_object(std::move(fields));
          }},
      scheduler.params);
}

[[nodiscard]] std::string encode_scheduler(
    const AuthoredSchedulerConfig& scheduler) {
  return std::visit(
      Overloaded{
          [](const CrossbarMaxWeightScheduler& value) {
            std::vector<JsonField> params{{"priority", encode_priority(value.priority)}};
            if (value.constraint.value.has_value()) {
              params.emplace_back("constraint",
                                  encode_crossbar_constraint(
                                      *value.constraint.value));
            }
            return json_object({
                {"name", json_string("crossbar_max_weight")},
                {"params", json_object(std::move(params))},
            });
          },
          [](const IntervalMaxWeightScheduler& value) {
            return json_object({
                {"name", json_string("interval_max_weight")},
                {"params", json_object({
                               {"constraint", encode_interval_constraint(
                                                  value.constraint.value)},
                               {"priority", encode_priority(value.priority)},
                           })},
            });
          },
          [](const NodeExclusiveMaxWeightScheduler& value) {
            return json_object({
                {"name", json_string("node_exclusive_max_weight")},
                {"params", json_object({
                               {"constraint", encode_node_constraint(
                                                  value.constraint.value)},
                               {"priority", encode_priority(value.priority)},
                           })},
            });
          },
          [](const ConflictGraphMaxWeightScheduler& value) {
            return json_object({
                {"name", json_string("conflict_graph_max_weight")},
                {"params", json_object({
                               {"constraint", encode_conflict_constraint(
                                                  value.constraint.value)},
                               {"max_search_states",
                                encode_optional(value.max_search_states.value,
                                                [](const BigNat& item) {
                                                  return encode(item);
                                                })},
                               {"priority", encode_priority(value.priority)},
                           })},
            });
          },
          [](const ResourcePackingMaxWeightScheduler& value) {
            return json_object({
                {"name", json_string("resource_packing_max_weight")},
                {"params", json_object({
                               {"constraint", encode_packing_constraint(
                                                  value.constraint.value)},
                               {"max_search_states",
                                encode_optional(value.max_search_states.value,
                                                [](const BigNat& item) {
                                                  return encode(item);
                                                })},
                               {"priority", encode_priority(value.priority)},
                           })},
            });
          },
          [](const UnsupportedCompatibilityScheduler& value) {
            return json_object({
                {"name", json_string(compatibility_scheduler_name(value.kind))},
                {"params", encode_compatibility_scheduler_params(value)},
            });
          }},
      scheduler.value);
}

[[nodiscard]] std::string encode_destination_probability(
    const DestinationProbability& row) {
  return json_object({
      {"probability", encode(row.probability.value)},
      {"queue_id", encode(row.queue_id.value)},
  });
}

[[nodiscard]] std::string encode_initial_state(
    const AuthoredInitialState& initial) {
  return std::visit(
      Overloaded{
          [](const InitialExactState& value) {
            return json_object({{"state", encode(value.state)}});
          },
          [](const InitialStateDistribution& value) {
            return json_object({
                {"distribution",
                 encode_array(value.distribution.value,
                              [](const StateProbability& row) {
                                return json_object({
                                    {"probability", encode(row.probability.value)},
                                    {"state", encode(row.state)},
                                });
                              })},
            });
          }},
      initial);
}

[[nodiscard]] std::string encode_interarrival(
    const AuthoredInterarrival& interarrival) {
  return std::visit(
      Overloaded{
          [](const DeterministicInterarrival& value) {
            return json_object({
                {"d", encode(value.d.value)},
                {"kind", json_string("deterministic")},
            });
          },
          [](const FinitePmfInterarrival& value) {
            return json_object({
                {"kind", json_string("finite_pmf")},
                {"outcomes", encode_array(value.outcomes.value,
                                          [](const GapProbability& row) {
                                            return json_object({
                                                {"d", encode(row.d.value)},
                                                {"probability", encode(
                                                                    row.probability.value)},
                                            });
                                          })},
            });
          },
          [](const GeometricGridInterarrival& value) {
            return json_object({
                {"d_min", encode(value.d_min.value)},
                {"delta", encode(value.delta.value)},
                {"kind", json_string("geometric_grid")},
                {"p", encode(value.p.value)},
            });
          }},
      interarrival);
}

[[nodiscard]] std::string encode_periodic_entry(const PeriodicEntry& entry) {
  return json_object({
      {"count", encode(entry.count.value)},
      {"offset", encode(entry.offset.value)},
      {"queue_id", encode(entry.queue_id.value)},
  });
}

[[nodiscard]] std::string compatibility_arrival_name(
    const CompatibilityArrivalKind kind) {
  switch (kind) {
    case CompatibilityArrivalKind::iid_table:
      return "iid_table";
    case CompatibilityArrivalKind::markov_kernel:
      return "markov_kernel";
    case CompatibilityArrivalKind::factorized_bernoulli:
      return "factorized_bernoulli";
  }
  std::terminate();
}

[[nodiscard]] std::string encode_legacy_edge(
    const LegacyEdgeCoordinate& edge) {
  return json_array(
      {encode(edge.source.value), encode(edge.destination.value)});
}

[[nodiscard]] std::string encode_allowed_edges(
    const CompatibilityAllowedEdges& allowed) {
  std::vector<JsonField> fields{{
      "mode", json_string(allowed.mode.value == AllowedEdgesMode::full
                              ? "full"
                              : "explicit"),
  }};
  if (allowed.mode.value == AllowedEdgesMode::explicit_list) {
    fields.emplace_back(
        "edges", encode_array(allowed.edges.value, encode_legacy_edge));
  }
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_alphabet_constraint(
    const AlphabetConstraintMode mode) {
  switch (mode) {
    case AlphabetConstraintMode::unrestricted:
      return json_string("unrestricted");
    case AlphabetConstraintMode::per_input_line_rate:
      return json_string("per_input_line_rate");
    case AlphabetConstraintMode::global_one_hot:
      return json_string("global_one_hot");
  }
  std::terminate();
}

[[nodiscard]] std::vector<JsonField> encode_compatibility_common(
    const CompatibilityArrivalCommon& common) {
  return {
      {"allowed_edges", encode_allowed_edges(common.allowed_edges)},
      {"alphabet_constraint",
       encode_alphabet_constraint(common.alphabet_constraint.value)},
  };
}

[[nodiscard]] std::string encode_iid_table_atom(const IidTableAtom& atom) {
  std::vector<JsonField> fields{
      {"edges", encode_array(atom.edges.value, encode_legacy_edge)},
      {"probability", encode(atom.probability.value)},
  };
  if (atom.id.value.has_value()) {
    fields.emplace_back("id", encode(*atom.id.value));
  }
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_markov_mask(const MarkovKernelMask& mask) {
  return json_object({
      {"edges", encode_array(mask.edges.value, encode_legacy_edge)},
      {"id", encode(mask.id)},
  });
}

[[nodiscard]] std::string encode_markov_row(const MarkovKernelRow& row) {
  return json_object({
      {"mask_id", encode(row.mask_id)},
      {"next_state", encode(row.next_state)},
      {"probability", encode(row.probability.value)},
      {"state", encode(row.state)},
  });
}

[[nodiscard]] std::string encode_compatibility_arrival(
    const UnsupportedCompatibilityArrival& arrival) {
  const bool kind_matches_payload =
      (arrival.kind == CompatibilityArrivalKind::iid_table &&
       std::holds_alternative<IidTableCompatibilityArrival>(arrival.value)) ||
      (arrival.kind == CompatibilityArrivalKind::markov_kernel &&
       std::holds_alternative<MarkovKernelCompatibilityArrival>(
           arrival.value)) ||
      (arrival.kind == CompatibilityArrivalKind::factorized_bernoulli &&
       std::holds_alternative<FactorizedBernoulliCompatibilityArrival>(
           arrival.value));
  if (!kind_matches_payload) {
    std::terminate();
  }

  std::vector<JsonField> fields = std::visit(
      Overloaded{
          [](const IidTableCompatibilityArrival& value) {
            std::vector<JsonField> result =
                encode_compatibility_common(value.common);
            result.emplace_back(
                "alphabet",
                encode_array(value.alphabet.value, encode_iid_table_atom));
            result.emplace_back("metadata", encode_metadata(value.metadata));
            return result;
          },
          [](const MarkovKernelCompatibilityArrival& value) {
            std::vector<JsonField> result =
                encode_compatibility_common(value.common);
            result.emplace_back(
                "alphabet",
                encode_array(value.alphabet.value, encode_markov_mask));
            result.emplace_back("initial",
                                encode_initial_state(value.initial.value));
            result.emplace_back(
                "kernel", encode_array(value.kernel.value, encode_markov_row));
            result.emplace_back("metadata", encode_metadata(value.metadata));
            result.emplace_back(
                "states",
                encode_array(value.states.value,
                             [](const NormalizedToken& state) {
                               return encode(state);
                             }));
            return result;
          },
          [](const FactorizedBernoulliCompatibilityArrival& value) {
            std::vector<JsonField> result =
                encode_compatibility_common(value.common);
            std::vector<JsonField> overrides;
            overrides.reserve(value.overrides.value.size());
            for (const BernoulliOverride& item : value.overrides.value) {
              std::string key = "[";
              key += item.source.value.to_decimal_string();
              key.push_back(',');
              key += item.destination.value.to_decimal_string();
              key.push_back(']');
              overrides.emplace_back(std::move(key),
                                     encode(item.probability.value));
            }
            result.emplace_back(
                "lambda",
                json_object({
                    {"default", encode(value.default_probability.value)},
                    {"overrides", json_object(std::move(overrides))},
                }));
            result.emplace_back("metadata", encode_metadata(value.metadata));
            return result;
          }},
      arrival.value);
  fields.emplace_back("family",
                      json_string(compatibility_arrival_name(arrival.kind)));
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_exact_queue_rates(
    const ExactQueueRates& rates) {
  return json_object({
      {"default", encode(rates.default_rate.value)},
      {"overrides", encode_array(
                        rates.overrides.value,
                        [](const QueueRateOverride& value) {
                          return json_object({
                              {"queue_id", encode(value.queue_id.value)},
                              {"rate", encode(value.rate.value)},
                          });
                        })},
  });
}

[[nodiscard]] std::string encode_arrival(const AuthoredArrivalConfig& arrival) {
  return std::visit(
      Overloaded{
          [](const DeterministicTraceArrival& value) {
            return json_object({
                {"events", encode_array(value.events.value,
                                        [](const TraceEvent& event) {
                                          return json_object({
                                              {"count", encode(event.count.value)},
                                              {"queue_id", encode(event.queue_id.value)},
                                              {"slot", encode(event.slot.value)},
                                          });
                                        })},
                {"family", json_string("deterministic_trace")},
                {"metadata", encode_metadata(value.metadata)},
            });
          },
          [](const PeriodicGlobalPhaseArrival& value) {
            return json_object({
                {"family", json_string("periodic_global_phase")},
                {"metadata", encode_metadata(value.metadata)},
                {"period", encode(value.period.value)},
                {"phase", encode(value.phase.value)},
                {"sources", encode_array(value.sources.value,
                                         [](const GlobalPhaseSource& source) {
                                           return json_object({
                                               {"entries", encode_array(
                                                               source.entries.value,
                                                               encode_periodic_entry)},
                                               {"id", encode(source.id)},
                                           });
                                         })},
            });
          },
          [](const PeriodicSourceDelaysArrival& value) {
            return json_object({
                {"family", json_string("periodic_source_delays")},
                {"metadata", encode_metadata(value.metadata)},
                {"period", encode(value.period.value)},
                {"sources", encode_array(value.sources.value,
                                         [](const DelayedPeriodicSource& source) {
                                           return json_object({
                                               {"delay", encode(source.delay.value)},
                                               {"entries", encode_array(
                                                               source.entries.value,
                                                               encode_periodic_entry)},
                                               {"id", encode(source.id)},
                                           });
                                         })},
            });
          },
          [](const IndependentMarkedRenewalArrival& value) {
            return json_object({
                {"family", json_string("independent_marked_renewal")},
                {"metadata", encode_metadata(value.metadata)},
                {"sources", encode_array(value.sources.value,
                                         [](const MarkedRenewalSource& source) {
                                           return std::visit(
                                               Overloaded{
                                                   [](const FactorizedRenewalSource& item) {
                                                     return json_object({
                                                         {"destination_pmf", encode_array(
                                                                                 item.destination_pmf.value,
                                                                                 encode_destination_probability)},
                                                         {"id", encode(item.id)},
                                                         {"interarrival", encode_interarrival(
                                                                              item.interarrival.value)},
                                                     });
                                                   },
                                                   [](const JointRenewalSource& item) {
                                                     return json_object({
                                                         {"id", encode(item.id)},
                                                         {"joint_pmf", encode_array(
                                                                           item.joint_pmf.value,
                                                                           [](const JointRenewalMass& row) {
                                                                             return json_object({
                                                                                 {"d", encode(row.d.value)},
                                                                                 {"probability", encode(row.probability.value)},
                                                                                 {"queue_id", encode(row.queue_id.value)},
                                                                             });
                                                                           })},
                                                     });
                                                   }},
                                               source);
                                         })},
            });
          },
          [](const IndependentPrivateMarkovRenewalArrival& value) {
            return json_object({
                {"family", json_string("independent_private_markov_renewal")},
                {"metadata", encode_metadata(value.metadata)},
                {"sources", encode_array(
                                value.sources.value,
                                [](const PrivateMarkovRenewalSource& source) {
                                  return json_object({
                                      {"destination_pmf", encode_array(
                                                              source.destination_pmf.value,
                                                              encode_destination_probability)},
                                      {"gaps", encode_array(
                                                   source.gaps.value,
                                                   [](const StateGap& gap) {
                                                     return json_object({
                                                         {"d", encode(gap.d.value)},
                                                         {"state", encode(gap.state)},
                                                     });
                                                   })},
                                      {"id", encode(source.id)},
                                      {"initial", encode_initial_state(
                                                      source.initial.value)},
                                      {"states", encode_array(
                                                     source.states.value,
                                                     [](const NormalizedToken& state) {
                                                       return encode(state);
                                                     })},
                                      {"transitions", encode_array(
                                                          source.transitions.value,
                                                          [](const StateTransition& row) {
                                                            return json_object({
                                                                {"next_state", encode(row.next_state)},
                                                                {"probability", encode(row.probability.value)},
                                                                {"state", encode(row.state)},
                                                            });
                                                          })},
                                  });
                                })},
            });
          },
          [](const SharedJointRoundMarkovRenewalArrival& value) {
            return json_object({
                {"family", json_string("shared_joint_round_markov_renewal")},
                {"initial", encode_initial_state(value.initial.value)},
                {"metadata", encode_metadata(value.metadata)},
                {"outcomes", encode_array(
                                 value.outcomes.value,
                                 [](const SharedOutcome& outcome) {
                                   return json_object({
                                       {"emissions", encode_array(
                                                         outcome.emissions.value,
                                                         [](const SharedEmission& emission) {
                                                           return json_object({
                                                               {"d", encode(emission.d.value)},
                                                               {"queue_id", encode(emission.queue_id.value)},
                                                               {"source_id", encode(emission.source_id)},
                                                           });
                                                         })},
                                       {"next_state", encode(outcome.next_state)},
                                       {"probability", encode(outcome.probability.value)},
                                       {"state", encode(outcome.state)},
                                   });
                                 })},
                {"sources", encode_array(value.sources.value,
                                         [](const SharedRenewalSource& source) {
                                           return json_object({{"id", encode(source.id)}});
                                         })},
                {"states", encode_array(value.states.value,
                                        [](const NormalizedToken& state) {
                                          return encode(state);
                                        })},
            });
          },
          [](const IidIndependentBernoulliArrival& value) {
            return json_object({
                {"family", json_string("iid_independent_bernoulli")},
                {"metadata", encode_metadata(value.metadata)},
                {"rates", encode_exact_queue_rates(value.rates)},
            });
          },
          [](const IidCountTableArrival& value) {
            return json_object({
                {"family", json_string("iid_count_table")},
                {"metadata", encode_metadata(value.metadata)},
                {"outcomes", encode_array(
                                 value.outcomes.value,
                                 [](const IidCountOutcome& outcome) {
                                   return json_object({
                                       {"counts", encode_array(
                                                      outcome.counts.value,
                                                      [](const IidCountEntry& count) {
                                                        return json_object({
                                                            {"count", encode(count.count.value)},
                                                            {"queue_id", encode(count.queue_id.value)},
                                                        });
                                                      })},
                                       {"id", encode(outcome.id)},
                                       {"probability", encode(outcome.probability.value)},
                                   });
                                 })},
            });
          },
          [](const IidIndependentPoissonArrival& value) {
            return json_object({
                {"family", json_string("iid_independent_poisson")},
                {"metadata", encode_metadata(value.metadata)},
                {"rates", encode_exact_queue_rates(value.rates)},
            });
          },
          [](const IidMixedPoissonArrival& value) {
            const MixedPoissonModulation& modulation = value.modulation;
            return json_object({
                {"family", json_string("iid_mixed_poisson")},
                {"metadata", encode_metadata(value.metadata)},
                {"modulation", json_object({
                    {"mean_multiplier", encode(modulation.mean_multiplier.value)},
                    {"scope", json_string(
                                  modulation.scope.value ==
                                          MixedPoissonScope::shared
                                      ? "shared"
                                      : "independent_queue")},
                    {"second_moment_multiplier",
                     encode(modulation.second_moment_multiplier.value)},
                    {"states", encode_array(
                                   modulation.states.value,
                                   [](const MixedPoissonState& state) {
                                     return json_object({
                                         {"id", encode(state.id)},
                                         {"multiplier", encode(state.multiplier.value)},
                                         {"probability", encode(state.probability.value)},
                                     });
                                   })},
                })},
                {"rates", encode_exact_queue_rates(value.rates)},
            });
          },
          [](const UnsupportedCompatibilityArrival& value) {
            return encode_compatibility_arrival(value);
          }},
      arrival.value);
}

[[nodiscard]] std::string encode_telemetry(
    const AuthoredTelemetryConfig& telemetry, const bool schema4) {
  std::string snapshot;
  switch (telemetry.queue_snapshot.value) {
    case QueueSnapshotMode::dense:
      snapshot = "dense";
      break;
    case QueueSnapshotMode::sparse_nonzero:
      snapshot = "sparse_nonzero";
      break;
    case QueueSnapshotMode::disabled:
      snapshot = "disabled";
      break;
  }
  std::vector<JsonField> fields{
      {"format", json_string(telemetry.format.value)},
      {"include_packet_events",
       telemetry.include_packet_events.value ? "true" : "false"},
      {"include_scheduler_state",
       telemetry.include_scheduler_state.value ? "true" : "false"},
      {"queue_snapshot", json_string(snapshot)},
      {"write_slot_trace",
       telemetry.write_slot_trace.value ? "true" : "false"},
  };
  if (schema4) {
    if (!telemetry.observation.has_value()) {
      std::terminate();
    }
    const AuthoredObservationTelemetry& observation = *telemetry.observation;
    fields.emplace_back(
        "observation",
        json_object({
            {"block_slots", encode_optional(
                                observation.block_slots.value,
                                [](const BigNat& value) { return encode(value); })},
            {"enabled", observation.enabled.value ? "true" : "false"},
            {"targets", encode_array(
                            observation.targets.value,
                            [](const AuthoredObservationTarget& target) {
                              return json_object({
                                  {"gap", json_string(
                                              target.gap.value ==
                                                      ObservationGapMode::exact
                                                  ? "exact"
                                                  : "none")},
                                  {"queue_id", encode(target.queue_id.value)},
                              });
                            })},
        }));
  }
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_run(const AuthoredRunConfig& run) {
  std::vector<JsonField> fields{
      {"output_dir",
       encode_optional(run.output_dir.value,
                       [](const std::string& value) { return json_string(value); })},
      {"slots", encode(run.slots.value)},
      {"termination",
       json_string(run.termination.value == TerminationPolicy::fixed_slots
                       ? "fixed_slots"
                       : "fixed_slots_then_drain")},
      {"warmup_slots", encode(run.warmup_slots.value)},
  };
  if (run.requested_seed.value.has_value()) {
    fields.emplace_back("requested_seed",
                        encode_seed(*run.requested_seed.value));
  } else {
    // `seed` and `requested_seed` are mutually exclusive on the wire.  The
    // typed parser still materializes the ordinary seed default for resolved
    // behavior, but a replay-form document must remain reparsable.
    fields.emplace_back("seed", encode_seed(run.seed.value));
  }
  if (run.actual_seed.value.has_value()) {
    fields.emplace_back("actual_seed",
                        std::to_string(*run.actual_seed.value));
  }
  return json_object(std::move(fields));
}

[[nodiscard]] std::string encode_model(const AuthoredModelConfig& model) {
  const bool schema4 = model.schema_version.value == kPhysicalSchemaVersionV4;
  return json_object({
      {"arrival", encode_arrival(model.arrival)},
      {"metadata", encode_metadata(model.metadata)},
      {"run", encode_run(model.run)},
      {"scheduler", encode_scheduler(model.scheduler)},
      {"schema_version", json_string(model.schema_version.value)},
      {"switch", encode_switch(model.switch_config, schema4)},
      {"telemetry", encode_telemetry(model.telemetry, schema4)},
  });
}

// Analysis-v1 serialization follows below.  Unlike opaque provider payloads,
// every C03-owned variant is reconstructed from its typed representation.

[[nodiscard]] std::string encode_big_nat_array(
    const std::vector<BigNat>& values) {
  return encode_array(values,
                      [](const BigNat& value) { return encode(value); });
}

[[nodiscard]] std::string encode_rational_array(
    const std::vector<ExactRational>& values) {
  return encode_array(values,
                      [](const ExactRational& value) { return encode(value); });
}

[[nodiscard]] std::string encode_tail(const TailResolution& tail) {
  return std::visit(
      Overloaded{
          [](const NoTailResolution&) {
            return json_object({
                {"kind", json_string("none")},
                {"parameters", "{}"},
            });
          },
          [](const FiniteClosedTailResolution& value) {
            return json_object({
                {"kind", json_string("finite_closed")},
                {"parameters", json_object(
                                   {{"max_level", encode(value.max_level)}})},
            });
          },
          [](const ConstantResponseTailResolution& value) {
            return json_object({
                {"kind", json_string("constant_response")},
                {"parameters",
                 json_object({{"cutoff", encode(value.cutoff)}})},
            });
          },
          [](const CertifiedTruncationTailResolution& value) {
            return json_object({
                {"kind", json_string("certified_truncation")},
                {"parameters", json_object({
                                   {"max_level", encode(value.max_level)},
                                   {"max_tail_mass",
                                    encode(value.max_tail_mass)},
                               })},
            });
          }},
      tail);
}

[[nodiscard]] std::string encode_resolution(
    const ResolutionEnvelope& resolution) {
  const auto optional_nat = [](const std::optional<BigNat>& value) {
    return encode_optional(value,
                           [](const BigNat& item) { return encode(item); });
  };
  const auto optional_decimal = [](const std::optional<ExactRational>& value) {
    return encode_optional(value, [](const ExactRational& item) {
      return encode(item);
    });
  };
  return json_object({
      {"level", json_object({
                    {"max_row_atoms",
                     optional_nat(resolution.level.max_row_atoms)},
                    {"max_states", optional_nat(resolution.level.max_states)},
                })},
      {"optimizer", json_object({
                        {"max_calls",
                         optional_nat(resolution.optimizer.max_calls)},
                        {"max_search_states_per_call",
                         optional_nat(
                             resolution.optimizer.max_search_states_per_call)},
                    })},
      {"phase", json_object({
                    {"max_phase_states",
                     optional_nat(resolution.phase.max_phase_states)},
                })},
      {"sampling", json_object({
                       {"max_generator_draws",
                        optional_nat(
                            resolution.sampling.max_generator_draws)},
                   })},
      {"tail", encode_tail(resolution.tail)},
      {"tolerance", json_object({
                        {"fixed_point_abs",
                         optional_decimal(
                             resolution.tolerance.fixed_point_abs)},
                        {"integration_abs",
                         optional_decimal(
                             resolution.tolerance.integration_abs)},
                        {"linear_residual_abs",
                         optional_decimal(
                             resolution.tolerance.linear_residual_abs)},
                        {"tail_abs",
                         optional_decimal(resolution.tolerance.tail_abs)},
                    })},
  });
}

[[nodiscard]] std::string encode_arrival_initial_state(
    const ArrivalInitialState& state) {
  return std::visit(
      Overloaded{
          [](const TraceOrigin&) {
            return json_object({{"kind", json_string("trace_origin")}});
          },
          [](const GlobalPeriodicOrigin&) {
            return json_object(
                {{"kind", json_string("global_periodic_origin")}});
          },
          [](const SourceDelayOrigin&) {
            return json_object(
                {{"kind", json_string("source_delay_origin")}});
          },
          [](const RenewalOrigin&) {
            return json_object({{"kind", json_string("renewal_origin")}});
          },
          [](const PrivateMarkovStates& value) {
            return json_object({
                {"kind", json_string("private_markov_states")},
                {"states", encode_array(
                               value.states,
                               [](const PrivateMarkovState& item) {
                                 return json_object({
                                     {"source_id", json_string(item.source_id)},
                                     {"state", json_string(item.state)},
                                 });
                               })},
            });
          },
          [](const SharedRoundState& value) {
            return json_object({
                {"kind", json_string("shared_round_state")},
                {"state", json_string(value.state)},
            });
          }},
      state);
}

[[nodiscard]] std::string encode_selection(const SelectionSpec& selection) {
  return std::visit(
      Overloaded{
          [](const TransientSelection& value) {
            return json_object({
                {"kind", json_string("transient")},
                {"parameters", json_object({
                                   {"initial_law", json_object({
                                                       {"atoms", encode_array(
                                                                     value.atoms,
                                                                     [](const TransientInitialAtom& atom) {
                                                                       return json_object({
                                                                           {"arrival_state", encode_arrival_initial_state(atom.arrival_state)},
                                                                           {"backlog", encode_array(
                                                                                           atom.backlog,
                                                                                           [](const InitialBacklogEntry& entry) {
                                                                                             return json_object({
                                                                                                 {"queue_id", encode(entry.queue_id)},
                                                                                                 {"value", encode(entry.value)},
                                                                                             });
                                                                                           })},
                                                                           {"controller_state", encode_source_node(atom.controller_state)},
                                                                           {"probability", encode(atom.probability)},
                                                                           {"static_context", encode_source_node(atom.static_context)},
                                                                           {"surrogate_initial", encode_source_node(atom.surrogate_initial)},
                                                                       });
                                                                     })},
                                                   })},
                               })},
            });
          },
          [](const StationaryUniqueSelection&) {
            return json_object({
                {"kind", json_string("stationary_unique")},
                {"parameters", "{}"},
            });
          },
          [](const StationaryClassSelection& value) {
            return json_object({
                {"kind", json_string("stationary_class")},
                {"parameters", json_object(
                                   {{"class_id", encode(value.class_id)}})},
            });
          },
          [](const StationaryMixtureSelection& value) {
            return json_object({
                {"kind", json_string("stationary_mixture")},
                {"parameters", json_object({
                                   {"components", encode_array(
                                                      value.components,
                                                      [](const StationaryMixtureComponent& component) {
                                                        return json_object({
                                                            {"class_id", encode(component.class_id)},
                                                            {"probability", encode(component.probability)},
                                                        });
                                                      })},
                               })},
            });
          },
          [](const FixedPointSelection& value) {
            return std::visit(
                Overloaded{
                    [](const FixedPointUniqueSelection&) {
                      return json_object({
                          {"kind", json_string("fixed_point")},
                          {"parameters", json_object(
                                             {{"mode", json_string("unique")}})},
                      });
                    },
                    [](const FixedPointIdSelection& item) {
                      return json_object({
                          {"kind", json_string("fixed_point")},
                          {"parameters", json_object({
                                             {"mode", json_string("id")},
                                             {"solution_id", encode(item.solution_id)},
                                         })},
                      });
                    }},
                value);
          }},
      selection);
}

[[nodiscard]] std::string encode_solver(const SolverSpec& solver) {
  const auto optional_nat = [](const std::optional<BigNat>& value) {
    return encode_optional(value,
                           [](const BigNat& item) { return encode(item); });
  };
  return std::visit(
      Overloaded{
          [&optional_nat](const EnumeratedSolver& value) {
            return json_object({
                {"kind", json_string("enumerated")},
                {"parameters", json_object({
                                   {"linear_method",
                                    json_string(value.linear_method ==
                                                        LinearMethod::dense_pivoted
                                                    ? "dense_pivoted"
                                                    : "sparse_iterative")},
                                   {"max_iterations",
                                    optional_nat(value.max_iterations)},
                               })},
            });
          },
          [&optional_nat](const AnalyticSolver& value) {
            return json_object({
                {"kind", json_string("analytic")},
                {"parameters", json_object({
                                   {"max_iterations",
                                    optional_nat(value.max_iterations)},
                                   {"precision_bits",
                                    encode(value.precision_bits)},
                               })},
            });
          },
          [](const MonteCarloSolver& value) {
            std::string interval_method;
            switch (value.interval_method) {
              case MonteCarloIntervalMethod::exact_binomial:
                interval_method = "exact_binomial";
                break;
              case MonteCarloIntervalMethod::hoeffding:
                interval_method = "hoeffding";
                break;
              case MonteCarloIntervalMethod::none:
                interval_method = "none";
                break;
            }
            return json_object({
                {"kind", json_string("monte_carlo")},
                {"parameters", json_object({
                                   {"confidence_level",
                                    encode(value.confidence_level)},
                                   {"interval_method",
                                    json_string(interval_method)},
                                   {"replications", encode(value.replications)},
                               })},
            });
          },
          [](const DirectSolver&) {
            return json_object({
                {"kind", json_string("direct")},
                {"parameters", "{}"},
            });
          }},
      solver);
}

[[nodiscard]] std::string edge_reward_name(const EdgeRewardKind value) {
  switch (value) {
    case EdgeRewardKind::increment:
      return "increment";
    case EdgeRewardKind::departure:
      return "departure";
    case EdgeRewardKind::arrival:
      return "arrival";
  }
  std::terminate();
}

[[nodiscard]] std::string gap_event_name(const GapEventKind value) {
  switch (value) {
    case GapEventKind::departure:
      return "departure";
    case GapEventKind::admission:
      return "admission";
    case GapEventKind::busy_denial:
      return "busy_denial";
  }
  std::terminate();
}

[[nodiscard]] std::string predicate_name(const BinaryPredicateKind value) {
  switch (value) {
    case BinaryPredicateKind::busy:
      return "busy";
    case BinaryPredicateKind::idle:
      return "idle";
    case BinaryPredicateKind::busy_denial:
      return "busy_denial";
    case BinaryPredicateKind::threshold_above:
      return "threshold_above";
  }
  std::terminate();
}

[[nodiscard]] std::string encode_hit_set(const HitSet& set) {
  std::string kind;
  switch (set.kind) {
    case HitSetKind::at_or_above:
      kind = "at_or_above";
      break;
    case HitSetKind::at_or_below:
      kind = "at_or_below";
      break;
    case HitSetKind::equal:
      kind = "equal";
      break;
  }
  return json_object({
      {"kind", json_string(kind)},
      {"level", encode(set.level)},
  });
}

[[nodiscard]] std::vector<JsonField> encode_fifo_fields(
    const FifoDelayWire& request) {
  return std::visit(
      Overloaded{
          [](const FifoDelayPmfMetric& value) {
            return std::vector<JsonField>{
                {"horizon", encode(value.horizon)},
                {"output", json_string("pmf")},
            };
          },
          [](const FifoDelayTailMetric& value) {
            return std::vector<JsonField>{
                {"horizon", encode(value.horizon)},
                {"output", json_string("tail")},
            };
          },
          [](const FifoDelayQuantileMetric& value) {
            return std::vector<JsonField>{
                {"output", json_string("quantile")},
                {"probability", encode(value.probability)},
            };
          },
          [](const FifoDelayMomentMetric& value) {
            return std::vector<JsonField>{
                {"order", encode(value.order)},
                {"output", json_string("moment")},
            };
          }},
      request);
}

[[nodiscard]] std::string encode_fifo_condition(
    const FifoCondition& condition) {
  return std::visit(
      Overloaded{
          [](const RankCondition& value) {
            return json_object({
                {"kind", json_string("rank")},
                {"value", encode(value.value)},
            });
          },
          [](const BatchCondition& value) {
            return json_object({
                {"kind", json_string("batch")},
                {"value", encode(value.value)},
            });
          },
          [](const ClassCondition& value) {
            return json_object({
                {"kind", json_string("class")},
                {"value", encode(value.value)},
            });
          },
          [](const PhaseCondition& value) {
            return json_object({
                {"kind", json_string("phase")},
                {"value", encode(value.value)},
            });
          }},
      condition);
}

struct EncodedMetric final {
  std::string kind;
  std::string parameters;
};

[[nodiscard]] EncodedMetric encode_metric_wire(const MetricWire& metric) {
  return std::visit(
      Overloaded{
          [](const StationaryThroughputMetric&) {
            return EncodedMetric{"stationary_throughput", "{}"};
          },
          [](const StationaryEmptyProbabilityMetric&) {
            return EncodedMetric{"stationary_empty_probability", "{}"};
          },
          [](const MeanSojournMetric&) {
            return EncodedMetric{"mean_sojourn", "{}"};
          },
          [](const ServicePersistenceMetric&) {
            return EncodedMetric{"service_persistence", "{}"};
          },
          [](const JointBacklogCovarianceMetric&) {
            return EncodedMetric{"joint_backlog_covariance", "{}"};
          },
          [](const StationaryBacklogPmfMetric& value) {
            std::vector<JsonField> fields;
            if (value.max_level.has_value()) {
              fields.emplace_back("max_level", encode(*value.max_level));
            }
            return EncodedMetric{"stationary_backlog_pmf",
                                 json_object(std::move(fields))};
          },
          [](const StationaryBacklogPgfMetric& value) {
            return EncodedMetric{
                "stationary_backlog_pgf",
                json_object({{"points", encode_rational_array(value.points)}})};
          },
          [](const StationaryBacklogMomentMetric& value) {
            return EncodedMetric{
                "stationary_backlog_moment",
                json_object({{"order", encode(value.order)}})};
          },
          [](const StationaryBacklogQuantileMetric& value) {
            return EncodedMetric{
                "stationary_backlog_quantile",
                json_object({{"probability", encode(value.probability)}})};
          },
          [](const StationaryBacklogTailMetric& value) {
            return EncodedMetric{
                "stationary_backlog_tail",
                json_object({{"threshold", encode(value.threshold)}})};
          },
          [](const BacklogConditionedServiceMetric& value) {
            return EncodedMetric{
                "backlog_conditioned_service",
                json_object({{"levels", encode_big_nat_array(value.levels)}})};
          },
          [](const StationaryEdgeRewardMetric& value) {
            return EncodedMetric{
                "stationary_edge_reward",
                json_object({
                    {"moment_order", encode(value.moment_order)},
                    {"reward", json_string(edge_reward_name(value.reward))},
                })};
          },
          [](const ServiceAutocovarianceMetric& value) {
            return EncodedMetric{
                "service_autocovariance",
                json_object({{"lags", encode_big_nat_array(value.lags)}})};
          },
          [](const LaggedCrossQueueCovarianceMetric& value) {
            return EncodedMetric{
                "lagged_cross_queue_covariance",
                json_object({{"lags", encode_big_nat_array(value.lags)}})};
          },
          [](const ServiceSpectrumMetric& value) {
            return EncodedMetric{
                "service_spectrum",
                json_object({
                    {"frequencies", encode_rational_array(value.frequencies)},
                    {"truncation_lag", encode(value.truncation_lag)},
                })};
          },
          [](const ServiceWindowCountMetric& value) {
            return EncodedMetric{
                "service_window_count",
                json_object({{"width", encode(value.width)}})};
          },
          [](const MeanEventGapMetric& value) {
            return EncodedMetric{
                "mean_event_gap",
                json_object({{"event", json_string(gap_event_name(value.event))}})};
          },
          [](const EventGapDistributionMetric& value) {
            return EncodedMetric{
                "event_gap_distribution",
                json_object({
                    {"event", json_string(gap_event_name(value.event))},
                    {"horizon", encode(value.horizon)},
                })};
          },
          [](const MeanBinaryRunMetric& value) {
            std::vector<JsonField> fields{
                {"predicate", json_string(predicate_name(value.predicate))}};
            if (value.threshold.has_value()) {
              fields.emplace_back("threshold", encode(*value.threshold));
            }
            return EncodedMetric{"mean_binary_run",
                                 json_object(std::move(fields))};
          },
          [](const BinaryRunDistributionMetric& value) {
            std::vector<JsonField> fields{
                {"horizon", encode(value.horizon)},
                {"predicate", json_string(predicate_name(value.predicate))}};
            if (value.threshold.has_value()) {
              fields.emplace_back("threshold", encode(*value.threshold));
            }
            return EncodedMetric{"binary_run_distribution",
                                 json_object(std::move(fields))};
          },
          [](const FirstHitMetric& value) {
            return EncodedMetric{
                "first_hit",
                json_object({
                    {"horizon", encode(value.horizon)},
                    {"include_mean", value.include_mean ? "true" : "false"},
                    {"set", encode_hit_set(value.set)},
                })};
          },
          [](const ThresholdExcursionMetric& value) {
            return EncodedMetric{
                "threshold_excursion",
                json_object({
                    {"horizon", encode(value.horizon)},
                    {"include_mean", value.include_mean ? "true" : "false"},
                    {"set", encode_hit_set(value.set)},
                })};
          },
          [](const TransientBacklogLawMetric& value) {
            return EncodedMetric{
                "transient_backlog_law",
                json_object({{"horizons",
                              encode_big_nat_array(value.horizons)}})};
          },
          [](const FifoDelayMetric& value) {
            return EncodedMetric{"fifo_delay",
                                 json_object(encode_fifo_fields(value.request))};
          },
          [](const FifoDelayConditionedMetric& value) {
            std::vector<JsonField> fields = encode_fifo_fields(value.request);
            fields.emplace_back("condition",
                                encode_fifo_condition(value.condition));
            return EncodedMetric{"fifo_delay_conditioned",
                                 json_object(std::move(fields))};
          },
          [](const CounterfactualOpportunityGapMetric& value) {
            return EncodedMetric{
                "counterfactual_opportunity_gap",
                json_object({
                    {"convention_id", encode(value.convention_id)},
                    {"horizon", encode(value.horizon)},
                })};
          },
          [](const JointBacklogEventMetric& value) {
            return EncodedMetric{
                "joint_backlog_event",
                json_object({
                    {"relation",
                     json_string(value.relation ==
                                         JointBacklogRelation::all_at_or_above
                                     ? "all_at_or_above"
                                     : "any_at_or_above")},
                    {"thresholds", encode_big_nat_array(value.thresholds)},
                })};
          },
          [](const JointDelayMetric& value) {
            std::string sampling;
            switch (value.sampling) {
              case JointDelaySampling::coincident:
                sampling = "coincident";
                break;
              case JointDelaySampling::independent_palm:
                sampling = "independent_palm";
                break;
              case JointDelaySampling::lagged:
                sampling = "lagged";
                break;
            }
            std::vector<JsonField> fields{
                {"horizon", encode(value.horizon)},
                {"sampling", json_string(sampling)},
            };
            if (value.lag.has_value()) {
              fields.emplace_back("lag", encode(*value.lag));
            }
            return EncodedMetric{"joint_delay", json_object(std::move(fields))};
          },
          [](const OrderedScheduleSequenceMetric& value) {
            return EncodedMetric{
                "ordered_schedule_sequence",
                json_object({
                    {"horizon", encode(value.horizon)},
                    {"retain_full_schedule",
                     value.retain_full_schedule ? "true" : "false"},
                })};
          }},
      metric);
}

[[nodiscard]] std::string encode_metric(const MetricNode& metric) {
  EncodedMetric encoded = encode_metric_wire(metric.metric);
  return json_object({
      {"id", json_string(metric.id)},
      {"kind", json_string(encoded.kind)},
      {"parameters", std::move(encoded.parameters)},
  });
}

[[nodiscard]] std::string encode_analysis(const AnalysisSpec& analysis) {
  const AnalysisContext& context = *analysis.context;
  return json_object({
      {"analysis_schema_version",
       json_string(analysis.analysis_schema_version)},
      {"metrics", encode_array(analysis.metrics, encode_metric)},
      {"resolution", encode_resolution(context.resolution)},
      {"selection", encode_selection(context.selection)},
      {"solver", encode_solver(context.solver)},
      {"surrogate", json_object({
                        {"id", json_string(analysis.surrogate.id)},
                        {"parameters",
                         encode_source_node(analysis.surrogate.parameters)},
                        {"version",
                         encode_optional(
                             analysis.surrogate.version,
                             [](const std::string& value) {
                               return json_string(value);
                             })},
                    })},
      {"targets", encode_array(
                      context.targets.queue_ids,
                      [](const TypedLabel& value) { return encode(value); })},
  });
}

}  // namespace

CanonicalInputPair canonicalize_authored_inputs(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis) {
  return CanonicalInputPair{
      .model = encode_model(model),
      .analysis = encode_analysis(analysis),
  };
}

}  // namespace mwperf
