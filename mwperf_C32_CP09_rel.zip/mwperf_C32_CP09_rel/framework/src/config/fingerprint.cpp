#include "mwperf/config/canonical_input.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <span>
#include <string>
#include <string_view>
#include <utility>

#include "mwperf/core/sha256.hpp"

namespace mwperf {
namespace {

static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t),
              "canonical input lengths must fit the version-1 u64 frame");

void update_or_terminate(Sha256& hash, const std::span<const std::byte> bytes) {
  // A materialized std::string on a supported host cannot exceed the SHA-256
  // byte-length bound.  Failure is therefore an internal representation
  // invariant, not recoverable authored input.
  if (!hash.update(bytes)) {
    std::terminate();
  }
}

void update_ascii(Sha256& hash, const std::string_view text) {
  update_or_terminate(
      hash, std::as_bytes(std::span<const char>(text.data(), text.size())));
}

void update_u64be(Sha256& hash, const std::uint64_t value) {
  std::array<std::byte, 8U> bytes{};
  for (std::size_t index = 0U; index < bytes.size(); ++index) {
    const auto shift = static_cast<unsigned>((7U - index) * 8U);
    bytes[index] = static_cast<std::byte>((value >> shift) & 0xffU);
  }
  update_or_terminate(hash, bytes);
}

[[nodiscard]] Digest256 fingerprint_document(const std::string_view domain,
                                             const std::string& document) {
  Sha256 hash;
  update_ascii(hash, domain);
  constexpr std::array<std::byte, 1U> separator{std::byte{0U}};
  update_or_terminate(hash, separator);
  update_u64be(hash, static_cast<std::uint64_t>(document.size()));
  update_or_terminate(
      hash,
      std::as_bytes(std::span<const char>(document.data(), document.size())));
  return hash.finalize();
}

[[nodiscard]] Digest256 fingerprint_pair(const Digest256& model,
                                         const Digest256& analysis) {
  Sha256 hash;
  update_ascii(hash, "mwperf.input_pair.v1");
  constexpr std::array<std::byte, 1U> separator{std::byte{0U}};
  update_or_terminate(hash, separator);
  update_or_terminate(hash, model.bytes());
  update_or_terminate(hash, analysis.bytes());
  return hash.finalize();
}

}  // namespace

InputFingerprintBundle fingerprint_inputs(const CanonicalInputPair& inputs) {
  Digest256 model = fingerprint_document("mwperf.model.v1", inputs.model);
  Digest256 analysis =
      fingerprint_document("mwperf.analysis.v1", inputs.analysis);
  Digest256 combined = fingerprint_pair(model, analysis);
  return InputFingerprintBundle{
      .model = std::move(model),
      .analysis = std::move(analysis),
      .combined = std::move(combined),
  };
}

}  // namespace mwperf
