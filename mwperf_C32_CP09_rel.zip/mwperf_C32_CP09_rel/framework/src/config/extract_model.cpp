#include "mwperf/config/document.hpp"

#include <algorithm>
#include <array>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] std::string source_note(const SourceLocation& location) {
  return "line " + std::to_string(location.line) + ", column " +
         std::to_string(location.column) + ", byte " +
         std::to_string(location.byte_offset);
}

[[nodiscard]] Diagnostic model_error(const SourceNode& node,
                                     std::string code, std::string message,
                                     const std::string_view pointer = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = node.location().authored_path,
      .json_pointer = std::string(pointer.empty() ? node.json_pointer()
                                                  : pointer),
      .notes = {source_note(node.location())},
  };
}

[[nodiscard]] bool equals_one_of(const std::string_view value,
                                 const std::span<const std::string_view> set) {
  return std::find(set.begin(), set.end(), value) != set.end();
}

}  // namespace

Result<ModelNode> extract_executable_model(const ParsedDocument& document) {
  const SourceNode& root = document.root;
  if (root.kind() != SourceNodeKind::object) {
    return Result<ModelNode>::failure(model_error(
        root, "physical_root_not_object",
        "the physical input root must be an object"));
  }

  static constexpr std::array<std::string_view, 7U> executable_keys{
      "schema_version", "run",       "switch",  "scheduler",
      "arrival",        "telemetry", "metadata"};

  const SourceNode* manifest_kind = root.find("manifest_kind");
  bool has_executable_key = false;
  bool all_executable_keys = true;
  for (const SourceObjectMember& member : root.object_members()) {
    const bool executable = equals_one_of(member.key, executable_keys);
    has_executable_key = has_executable_key || executable;
    all_executable_keys = all_executable_keys && executable;
  }

  if (manifest_kind != nullptr) {
    if (has_executable_key) {
      return Result<ModelNode>::failure(model_error(
          root, "physical_root_ambiguous",
          "physical executable keys may not be mixed with manifest keys"));
    }
    const std::string* kind = manifest_kind->string_value();
    if (kind == nullptr || *kind != "switchsim_config_template") {
      return Result<ModelNode>::failure(model_error(
          *manifest_kind, "manifest_kind_invalid",
          "manifest_kind must be 'switchsim_config_template'"));
    }
    const SourceNode* execution_contract = root.find("execution_contract");
    if (execution_contract == nullptr) {
      return Result<ModelNode>::failure(model_error(
          root, "manifest_execution_contract_missing",
          "an approved template manifest requires an execution_contract "
          "object",
          "/execution_contract"));
    }
    if (execution_contract->kind() != SourceNodeKind::object) {
      return Result<ModelNode>::failure(model_error(
          *execution_contract, "manifest_execution_contract_invalid",
          "execution_contract must be an object"));
    }
    const SourceNode* pointer =
        execution_contract->find("executable_config_pointer");
    if (pointer == nullptr) {
      return Result<ModelNode>::failure(model_error(
          *execution_contract, "manifest_executable_pointer_invalid",
          "the manifest requires executable_config_pointer",
          "/execution_contract/executable_config_pointer"));
    }
    if (pointer->string_value() == nullptr ||
        *pointer->string_value() != "/selected_config") {
      return Result<ModelNode>::failure(model_error(
          *pointer, "manifest_executable_pointer_invalid",
          "the manifest executable pointer must be '/selected_config'"));
    }
    const SourceNode* selected = root.find("selected_config");
    if (selected == nullptr) {
      return Result<ModelNode>::failure(model_error(
          root, "manifest_selected_config_missing",
          "the manifest must contain an object at /selected_config",
          "/selected_config"));
    }
    if (selected->kind() != SourceNodeKind::object) {
      return Result<ModelNode>::failure(model_error(
          *selected, "manifest_selected_config_invalid",
          "the manifest value at /selected_config must be an object"));
    }
    return Result<ModelNode>::success(ModelNode{*selected});
  }

  if (all_executable_keys) {
    return Result<ModelNode>::success(ModelNode{root});
  }
  return Result<ModelNode>::failure(model_error(
      root, "physical_root_unrecognized",
      "the physical input is neither a raw schema-3 executable object nor an "
      "approved canonical template manifest"));
}

}  // namespace mwperf
