#include "full_orbit_default_analysis.hpp"

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/config/document.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/core/non_scientific_limits.hpp"

namespace mwperf::detail {
namespace {

constexpr const char* kBuiltinPath = "<builtin:full-orbit-default-v1>";
constexpr std::uint64_t kCp09DefaultWarmupSlots = 0U;
constexpr std::uint64_t kCp09DefaultHorizonSlots = 400U;
constexpr std::uint64_t kCp09DefaultPopulationSize = 64U;
constexpr std::uint64_t kCp09DefaultReportingBlocks = 1U;
constexpr std::uint64_t kCp09DefaultAttainableRowsPerReplication =
    kCp09DefaultPopulationSize *
        (kCp09DefaultHorizonSlots - kCp09DefaultWarmupSlots) +
    2U * kCp09DefaultPopulationSize * kCp09DefaultReportingBlocks;

[[nodiscard]] SourceLocation location() {
  return {kBuiltinPath, 1U, 1U, 0U};
}

[[nodiscard]] SourceNode null_node(std::string pointer) {
  return SourceNode::make_null(location(), std::move(pointer));
}

[[nodiscard]] SourceNode number_node(std::string value,
                                     std::string pointer) {
  return SourceNode::make_number(std::move(value), location(),
                                 std::move(pointer));
}

[[nodiscard]] SourceNode string_node(std::string value,
                                     std::string pointer) {
  return SourceNode::make_string(std::move(value), location(),
                                 std::move(pointer));
}

[[nodiscard]] SourceObjectMember member(std::string key, SourceNode value) {
  return {std::move(key), location(), std::move(value)};
}

[[nodiscard]] SourceNode object_node(
    std::string pointer, std::vector<SourceObjectMember> members = {}) {
  return SourceNode::make_object(std::move(members), location(),
                                 std::move(pointer));
}

[[nodiscard]] SourceNode array_node(std::string pointer,
                                    std::vector<SourceNode> items) {
  return SourceNode::make_array(std::move(items), location(),
                                std::move(pointer));
}

[[nodiscard]] SourceNode target_node(const QueueId& target,
                                     std::string pointer) {
  const TypedLabel& label = target.label();
  if (label.is_text()) {
    return string_node(*label.text_value(), std::move(pointer));
  }
  return number_node(label.numeric_value()->to_decimal_string(),
                     std::move(pointer));
}

[[nodiscard]] SourceNode metric(
    const std::size_t index, std::string id, std::string kind,
    SourceNode parameters) {
  const std::string pointer = "/metrics/" + std::to_string(index);
  return object_node(
      pointer,
      {member("id", string_node(std::move(id), pointer + "/id")),
       member("kind", string_node(std::move(kind), pointer + "/kind")),
       member("parameters", std::move(parameters))});
}

[[nodiscard]] SourceNode legacy_surrogate_node() {
  return object_node(
      "/surrogate",
      {member("id", string_node("full_orbit_framework_sampler",
                                  "/surrogate/id")),
       member("version", string_node("1.2.0", "/surrogate/version")),
       member(
           "parameters",
           object_node(
               "/surrogate/parameters",
               {member("schema_version",
                       number_node("2", "/surrogate/parameters/schema_version")),
                member("warmup_slots",
                       number_node("20", "/surrogate/parameters/warmup_slots")),
                member("horizon_slots",
                       number_node("100", "/surrogate/parameters/horizon_slots")),
                member("replications",
                       number_node("8", "/surrogate/parameters/replications")),
                // P is a deterministic CP07.1 scientific parameter, not a
                // search-state or resource cap.
                member("population_size",
                       number_node("64", "/surrogate/parameters/population_size")),
                member(
                    "familywise_alpha",
                    object_node(
                        "/surrogate/parameters/familywise_alpha",
                        {member("kind", string_node(
                                            "rational",
                                            "/surrogate/parameters/familywise_alpha/kind")),
                         member("numerator", string_node(
                                                 "1",
                                                 "/surrogate/parameters/familywise_alpha/numerator")),
                         member("denominator", string_node(
                                                   "20",
                                                   "/surrogate/parameters/familywise_alpha/denominator"))})),
                // K=2 is only the released schema-3 built-in default.
                member("response_cutoff",
                       number_node("2", "/surrogate/parameters/response_cutoff"))}))});
}

[[nodiscard]] SourceNode cp09_surrogate_node(
    const ObservationGapMode target_gap_mode) {
  return object_node(
      "/surrogate",
      {member("id", string_node("full_orbit_framework_sampler",
                                  "/surrogate/id")),
       member("version", string_node("1.4.0", "/surrogate/version")),
       member(
           "parameters",
           object_node(
               "/surrogate/parameters",
               {member("schema_version",
                       number_node("4", "/surrogate/parameters/schema_version")),
                member(
                    "construction",
                    object_node(
                        "/surrogate/parameters/construction",
                        {member("warmup_slots", number_node(
                                                    "0", "/surrogate/parameters/construction/warmup_slots")),
                         member("horizon_slots", number_node(
                                                     "400", "/surrogate/parameters/construction/horizon_slots")),
                         member("replications", number_node(
                                                   "16", "/surrogate/parameters/construction/replications")),
                         member("population_size", number_node(
                                                      "64", "/surrogate/parameters/construction/population_size"))})),
                member(
                    "observation",
                    object_node(
                        "/surrogate/parameters/observation",
                        {member("emit", SourceNode::make_boolean(
                                            true, location(),
                                            "/surrogate/parameters/observation/emit")),
                         member("reporting_block_boundaries",
                                array_node(
                                    "/surrogate/parameters/observation/reporting_block_boundaries",
                                    {number_node(
                                         "0", "/surrogate/parameters/observation/reporting_block_boundaries/0"),
                                     number_node(
                                         "400", "/surrogate/parameters/observation/reporting_block_boundaries/1")})),
                         member(
                             "gap_telemetry",
                             string_node(
                                 target_gap_mode == ObservationGapMode::exact
                                     ? "required"
                                     : "disabled",
                                 "/surrogate/parameters/observation/gap_telemetry")),
                         member(
                             "maximum_rows_per_replication",
                             number_node(
                                 std::to_string(
                                     kCp09DefaultAttainableRowsPerReplication),
                                 "/surrogate/parameters/observation/maximum_rows_per_replication")),
                         member(
                             "maximum_bytes",
                             number_node(
                                 std::to_string(kNonScientificByteCeiling),
                                 "/surrogate/parameters/observation/maximum_bytes"))})),
                member(
                    "projection",
                    object_node(
                        "/surrogate/parameters/projection",
                        {member("mode", string_node(
                                            "raw_observed", "/surrogate/parameters/projection/mode")),
                         member("cutoffs", array_node(
                                               "/surrogate/parameters/projection/cutoffs",
                                               {number_node("4", "/surrogate/parameters/projection/cutoffs/0"),
                                                number_node("8", "/surrogate/parameters/projection/cutoffs/1"),
                                                number_node("16", "/surrogate/parameters/projection/cutoffs/2")})),
                         member("deployment_cutoff", null_node(
                                                         "/surrogate/parameters/projection/deployment_cutoff")),
                         member(
                             "familywise_alpha",
                             object_node(
                                 "/surrogate/parameters/projection/familywise_alpha",
                                 {member("numerator", string_node(
                                                          "1", "/surrogate/parameters/projection/familywise_alpha/numerator")),
                                  member("denominator", string_node(
                                                            "20", "/surrogate/parameters/projection/familywise_alpha/denominator"))}))}))}))});
}

[[nodiscard]] ParsedDocument builtin_document(
    const QueueId& target, const bool cp09,
    const ObservationGapMode cp09_target_gap_mode =
        ObservationGapMode::none) {
  std::vector<SourceNode> metrics;
  metrics.reserve(6U);
  metrics.push_back(metric(
      0U, "fofs.iid.pi0.v1", "stationary_empty_probability",
      object_node("/metrics/0/parameters")));
  metrics.push_back(metric(
      1U, "fofs.iid.pmf.v1", "stationary_backlog_pmf",
      object_node("/metrics/1/parameters",
                  {member("max_level",
                          number_node("2", "/metrics/1/parameters/max_level"))})));
  metrics.push_back(metric(
      2U, "fofs.iid.tail3.v1", "stationary_backlog_tail",
      object_node("/metrics/2/parameters",
                  {member("threshold",
                          number_node("3", "/metrics/2/parameters/threshold"))})));
  metrics.push_back(metric(
      3U, "fofs.iid.mean.v1", "stationary_backlog_moment",
      object_node("/metrics/3/parameters",
                  {member("order",
                          number_node("1", "/metrics/3/parameters/order"))})));
  metrics.push_back(metric(4U, "fofs.iid.sojourn.v1", "mean_sojourn",
                           object_node("/metrics/4/parameters")));
  metrics.push_back(metric(
      5U, "fofs.iid.bcs.v1", "backlog_conditioned_service",
      object_node(
          "/metrics/5/parameters",
          {member("levels",
                  array_node("/metrics/5/parameters/levels",
                             {number_node("0", "/metrics/5/parameters/levels/0"),
                              number_node("1", "/metrics/5/parameters/levels/1"),
                              number_node("2", "/metrics/5/parameters/levels/2")}))})));

  SourceNode root = object_node(
      "",
      {member("analysis_schema_version",
              string_node("1.0.0", "/analysis_schema_version")),
       member("targets",
              array_node("/targets", {target_node(target, "/targets/0")})),
       member("metrics", array_node("/metrics", std::move(metrics))),
       member("surrogate",
              cp09 ? cp09_surrogate_node(cp09_target_gap_mode)
                   : legacy_surrogate_node()),
       member(
           "resolution",
           object_node(
               "/resolution",
               {member("level",
                       object_node(
                           "/resolution/level",
                           {member("max_states", number_node(
                                                     "64", "/resolution/level/max_states")),
                            member("max_row_atoms", number_node(
                                                        "65536", "/resolution/level/max_row_atoms"))})),
                member("tail",
                       object_node(
                           "/resolution/tail",
                           {member("kind", string_node(
                                               "constant_response", "/resolution/tail/kind")),
                            member("parameters",
                                   object_node(
                                       "/resolution/tail/parameters",
                                       {member("cutoff", number_node(
                                                             "2", "/resolution/tail/parameters/cutoff"))}))})),
                member("phase",
                       object_node(
                           "/resolution/phase",
                           {member("max_phase_states", number_node(
                                                           "64", "/resolution/phase/max_phase_states"))})),
                member("optimizer",
                       object_node(
                           "/resolution/optimizer",
                           {member("max_calls", number_node(
                                                    cp09 ? "819200" : "51200",
                                                    "/resolution/optimizer/max_calls")),
                            member("max_search_states_per_call",
                                   null_node(
                                       "/resolution/optimizer/max_search_states_per_call"))})),
                member("sampling",
                       object_node(
                           "/resolution/sampling",
                           {member("max_generator_draws", null_node(
                                                               "/resolution/sampling/max_generator_draws"))})),
                member("tolerance",
                       object_node(
                           "/resolution/tolerance",
                           {member("linear_residual_abs", number_node(
                                                              "1e-12", "/resolution/tolerance/linear_residual_abs")),
                            member("integration_abs", null_node(
                                                          "/resolution/tolerance/integration_abs")),
                            member("tail_abs", null_node(
                                                   "/resolution/tolerance/tail_abs")),
                            member("fixed_point_abs", null_node(
                                                          "/resolution/tolerance/fixed_point_abs"))}))})),
       member("selection",
              object_node(
                  "/selection",
                  {member("kind", string_node("stationary_unique",
                                               "/selection/kind")),
                   member("parameters", object_node("/selection/parameters"))})),
       member("solver",
              object_node(
                  "/solver",
                  {member("kind", string_node("analytic", "/solver/kind")),
                   member("parameters",
                          object_node(
                              "/solver/parameters",
                              {member("precision_bits", number_node(
                                                            "128", "/solver/parameters/precision_bits")),
                               member("max_iterations", null_node(
                                                            "/solver/parameters/max_iterations"))}))}))});

  return {DocumentSyntax::json, kBuiltinPath, std::move(root)};
}

}  // namespace

Result<AnalysisSpec> make_full_orbit_default_analysis_v1(
    const QueueId& target, const AuthoredSchedulerConfig& scheduler) {
  // Optimizer search-state counts are execution telemetry.  The physical
  // scheduler may still carry an explicit max_search_states value, but the
  // built-in Full Orbit analysis does not add a scenario-eligibility cap.
  (void)scheduler;
  ParsedDocument document = builtin_document(target, false);
  return parse_analysis_spec_v1(document);
}

Result<AnalysisSpec> make_full_orbit_cp09_default_analysis_v1(
    const QueueId& target, const AuthoredSchedulerConfig& scheduler,
    const AuthoredTelemetryConfig& telemetry) {
  (void)scheduler;
  ObservationGapMode target_gap_mode = ObservationGapMode::none;
  if (telemetry.observation.has_value() &&
      telemetry.observation->enabled.value) {
    for (const AuthoredObservationTarget& declared :
         telemetry.observation->targets.value) {
      if (declared.queue_id.value == target) {
        target_gap_mode = declared.gap.value;
        break;
      }
    }
  }
  ParsedDocument document = builtin_document(target, true, target_gap_mode);
  return parse_analysis_spec_v1(document);
}

}  // namespace mwperf::detail
